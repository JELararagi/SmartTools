# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

import re
from collections import OrderedDict

import bpy

# -----------------------------------------------------------------------------
# Localization helpers
# -----------------------------------------------------------------------------

JA_TRANSLATIONS = {
    "Smart Animation": "Smart Animation",
    "Workspace": "ワークスペース",
    "User Mode": "利用モード",
    "Internal record of the workspace suggested by Smart Assist. To change what the N-panel shows, use the Task selector in Overview Task.": "スマートアシストが勧めた作業場所の内部記録です。Nパネルの表示を切り替えるには「概要タスク」の「タスク」を使います。",
    "Beginner": "初心者",
    "Expert": "上級者",
    "Show beginner-oriented explanations and safer defaults, or reduce guidance for a denser expert view.": "初心者向けの説明と安全寄りの初期値を使うか、説明を減らして上級者向けの密度にするかを選びます。",
    "Show Inline Help": "インラインヘルプを表示",
    "Show short beginner-friendly explanations inside each section in addition to tooltips.": "ツールチップに加えて、各セクション内にも初心者向けの短い説明を表示します。",
    "Auto Backup Action": "アクションを自動バックアップ",
    "Before destructive cleanup operations, duplicate the current action as a safety backup.": "破壊的な整理処理の前に、現在のアクションを安全用バックアップとして複製します。",
    "Preview Only": "プレビューのみ",
    "When enabled, cleanup tools do not modify data and instead report how many keys or channels would change.": "有効にすると、整理ツールはデータを変更せず、何個のキーやチャンネルが変わるかだけを報告します。",
    "Only Selected Curves": "選択カーブのみ",
    "When enabled, cleanup tools affect only selected F-Curves in the active action.": "有効にすると、整理ツールはアクティブアクション内で選択中の F カーブだけを対象にします。",
    "Simplify Factor": "簡略化係数",
    "Allowed value deviation when removing in-between keys. Larger values remove more keys.": "中間キーを削除するときに許容する値の誤差です。大きいほど多くのキーを削除します。",
    "Threshold": "しきい値",
    "Small numerical threshold used to detect flat channels or duplicate values.": "フラットなチャンネルや重複値を判定するための小さな数値しきい値です。",
    "Marker Name": "マーカー名",
    "Name used when adding a new timeline marker on the current frame.": "現在フレームに新しいタイムラインマーカーを追加するときの名前です。",
    "Bake Range": "ベイク範囲",
    "Choose whether baking uses the scene range, preview range, or a custom range.": "ベイクにシーン範囲、プレビュー範囲、またはカスタム範囲のどれを使うか選びます。",
    "Scene": "シーン",
    "Preview": "プレビュー",
    "Custom": "カスタム",
    "Custom Start": "開始フレーム",
    "Custom End": "終了フレーム",
    "Start frame used when Bake Range is set to Custom.": "ベイク範囲がカスタムのときに使う開始フレームです。",
    "End frame used when Bake Range is set to Custom.": "ベイク範囲がカスタムのときに使う終了フレームです。",
    "Bake Step": "ベイク間隔",
    "Frame step used by baking tools. 1 means every frame.": "ベイク時のフレーム間隔です。1 は毎フレームを意味します。",
    "Snapshot Name": "スナップショット名",
    "Name used when storing a pose snapshot. If empty, a default name is generated.": "ポーズスナップショット保存時の名前です。空欄なら自動名が付きます。",
    "Pose Profile Text": "ポーズプロファイルテキスト",
    "Blender text datablock name used when exporting or importing pose snapshot JSON profiles.": "ポーズスナップショット JSON プロファイルの書き出し・読み込みに使う Blender テキストデータ名です。",
    "Source Rig": "ソースリグ",
    "Armature object that contains the source skeleton for retarget preparation.": "リターゲット準備で元になるスケルトンを持つアーマチュアオブジェクトです。",
    "Target Rig": "ターゲットリグ",
    "Armature object that will receive the mapped source skeleton names.": "ソーススケルトン名の対応を受け取るアーマチュアオブジェクトです。",
    "Strip Namespaces": "名前空間を除去",
    "Ignore namespace prefixes like CharacterA:Arm.L when trying to match bones.": "ボーン対応時に CharacterA:Arm.L のような名前空間接頭辞を無視します。",
    "Use Side Aliases": "左右エイリアスを使う",
    "Treat common left/right naming styles like .L, _R, Left, and Right as equivalent.": " .L、_R、Left、Right などの一般的な左右命名を同等として扱います。",
    "Log Limit": "ログ保持数",
    "Maximum number of recent operations kept in the in-panel activity log.": "パネル内のアクティビティログに保持する最近の操作数です。",
    "Smart Animation Report": "Smart Animation レポート",
    "Smart Animation Retarget Profile": "Smart Animation リターゲットプロファイル",
    "Pose Snapshots": "ポーズスナップショット",
    "Bone Mapping Preview": "ボーン対応プレビュー",
    "Operation Log": "操作ログ",
    "Smart Animation adds quick animation tools to the standard Sidebar N-panel.": "Smart Animation は標準のサイドバーNパネルに高速アニメーションツールを追加します。",
    "Replace Existing SAS Constraints": "既存の SAS 制約を置き換える",
    "Before building a live retarget preview, remove older Smart Animation retarget constraints from the target rig so the preview stays clean and predictable.": "ライブリターゲットプレビュー作成前に、ターゲットリグ上の古い Smart Animation 制約を削除して、結果を分かりやすく安定させます。",
    "Retarget Influence": "リターゲット影響度",
    "Live retarget constraints created by Smart Animation. 1.0 means full influence, smaller values allow blending with the target rig's existing motion.": "Smart Animation が作成するライブリターゲット制約の影響度です。1.0 で完全適用、より小さい値では既存モーションとブレンドできます。",
    "Build a live preview retarget by adding Copy Transforms constraints on matching target bones. This is a practical preview layer, not a final solver like full HumanIK-class retargeting.": "一致したターゲットボーンに Copy Transforms 制約を追加して、ライブプレビューのリターゲットを作成します。これは実用的なプレビュー層であり、完全な HumanIK 級ソルバーそのものではありません。",
    "Remove Smart Animation live retarget constraints from the target rig so you can return to the original target controls.": "ターゲットリグから Smart Animation のライブリターゲット制約を削除し、元のターゲット操作へ戻します。",
    "Create missing animation data or an action on the active object, repair an invalid preview range, and clear invalid retarget object assignments.": "アクティブオブジェクトに不足しているアニメーションデータやアクションを作成し、不正なプレビュー範囲を修正し、無効なリターゲット割り当てを解除します。",
    "Live Retarget": "ライブリターゲット",
    "Clear Live Retarget": "ライブリターゲット解除",
    "Auto-Fix Basics": "基本自動修復",
    "Action Slot": "アクションスロット",
    "Readiness": "準備状態",
    "Matched Bones": "一致ボーン数",
    "High Confidence": "高信頼一致",
    "Live Constraints": "ライブ制約数",
    "Cleanup Preview": "整理プレビュー",
    "Recommended Actions": "おすすめ操作",
    "Retarget Summary": "リターゲット概要",
    "Current Action Slot": "現在のアクションスロット",
    "Serialized pose snapshot data stored internally by Smart Animation.": "Smart Animation が内部保持するシリアライズ済みポーズスナップショットデータです。",
    "Matched target bone name used by the current retarget preview row.": "現在のリターゲットプレビュー行で使われる一致先ターゲットボーン名です。",
    "Matching state for this bone-map row, such as matched, guessed, or unmatched.": "このボーン対応行の一致状態です。matched、guessed、unmatched などを示します。",
    "Localized message shown in the recent operation log list.": "最近の操作ログ一覧に表示するローカライズ済みメッセージです。",
    "Original Japanese log text kept internally for bilingual log display.": "英日両対応ログ表示のために内部保持する日本語ログ原文です。",
    "Currently selected pose snapshot row in the Smart Animation workspace list.": "Smart Animation ワークスペース一覧で現在選択中のポーズスナップショット行です。",
    "Currently selected bone mapping row in the retarget preview list.": "リターゲットプレビュー一覧で現在選択中のボーン対応行です。",
    "Currently selected entry in the recent operation log list.": "最近の操作ログ一覧で現在選択中の項目です。",
    "Currently selected action in the in-panel motion library list.": "パネル内モーションライブラリ一覧で現在選択中のアクションです。",
    "Show the active action field directly so beginners can see what clip is currently being edited and experts can swap actions quickly.": "現在編集中のクリップを初心者でも見やすく、上級者は素早く切り替えられるよう、アクティブアクション欄を直接表示します。",
}


JA_TRANSLATIONS.update({
    "Find Tool": "ツール検索",
    "Filter visible sections by keyword. Search in English or Japanese to focus the panel on tools like bake, retarget, cleanup, or root motion.": "キーワードで表示セクションを絞り込みます。英語でも日本語でも検索でき、ベイク、リターゲット、整理、ルートモーションなど必要な機能へ素早く絞れます。",
    "Show Safety Hints": "安全ヒントを表示",
    "Show risk badges and safety reminders around destructive and retarget-related actions.": "破壊的処理やリターゲット関連の操作の近くに、リスク表示と安全リマインダーを表示します。",
    "Retarget Profile Text": "リターゲットプロファイルテキスト",
    "Blender text datablock name used when exporting or importing bone-map JSON profiles.": "ボーン対応表 JSON プロファイルの書き出し・読み込みに使う Blender テキストデータ名です。",
    "Root Bone": "ルートボーン",
    "Root or hips bone name used by root-motion utilities. Leave empty to operate on the object transform instead of a pose bone.": "ルートモーション系ユーティリティで使う Root または Hips ボーン名です。空欄にするとポーズボーンではなくオブジェクト変換を対象にします。",
    "Root Motion X": "ルートモーション X",
    "Preserve or isolate movement on the X axis when generating root-motion helper actions.": "ルートモーション補助アクション作成時に X 軸移動を保持または抽出します。",
    "Root Motion Y": "ルートモーション Y",
    "Preserve or isolate movement on the Y axis when generating root-motion helper actions.": "ルートモーション補助アクション作成時に Y 軸移動を保持または抽出します。",
    "Root Motion Z": "ルートモーション Z",
    "Preserve or isolate movement on the Z axis when generating root-motion helper actions.": "ルートモーション補助アクション作成時に Z 軸移動を保持または抽出します。",
    "Safety Status": "安全状態",
    "Protected": "保護済み",
    "Review": "要確認",
    "Risky": "注意",
    "Smart Assist": "スマートアシスト",
    "Let Smart Animation switch to the most relevant workspace based on the current context.": "現在の状況に合わせて、最も関連の高いワークスペースへ Smart Animation が切り替えます。",
    "Retarget Profile": "リターゲットプロファイル",
    "Profile Text": "プロファイルテキスト",
    "Import JSON": "JSON 読み込み",
    "Import the current retarget JSON profile from a Blender text datablock and rebuild the in-panel bone map list.": "Blender テキストデータから現在のリターゲット JSON プロファイルを読み込み、パネル内のボーン対応表を再構築します。",
    "Create Root Motion Action": "ルートモーションアクション作成",
    "Create a non-destructive copy of the current action that keeps only the configured root-motion translation curves.": "設定したルートモーション移動カーブだけを残した非破壊コピーアクションを作成します。",
    "Create In-Place Copy": "インプレース複製を作成",
    "Create a safe duplicated action and zero the configured root-motion translation curves in that copy, making an in-place version while preserving the original.": "元アクションを残したまま安全な複製アクションを作成し、その中で指定ルートモーション移動カーブをゼロ化してインプレース版を作成します。",
    "Root Motion": "ルートモーション",
    "Axes": "軸",
    "Matched Root Curves": "一致ルートカーブ数",
    "No section matches the current search filter.": "現在の検索条件に一致するセクションはありません。",
    "Quick Focus": "クイックフォーカス",
    "Use the search field to reduce the interface to only the sections related to a task. Example: bake, marker, retarget, root, cleanup.": '検索欄を使うと、今の作業に関係するセクションだけに画面を絞れます。例：ベイク、マーカー、リターゲット、ルート、整理。',
    "The configured root-motion bone was not found on the active armature.": "設定されたルートモーション用ボーンがアクティブアーマチュア上に見つかりません。",
    "Export the current retarget preview as JSON into the configured Blender text data-block and copy the JSON to the clipboard.": "現在のリターゲットプレビューを、設定した Blender テキストデータへ JSON として書き出し、同時にクリップボードにもコピーします。",
})

JA_TRANSLATIONS.update({
    "Timing Range": "タイミング範囲",
    "Use Range": "範囲を使用",
    "When enabled, timing tools affect only keys inside the configured frame range. When disabled, they affect the full active action.": "有効にすると、タイミングツールは設定したフレーム範囲内のキーだけを対象にします。無効ならアクティブアクション全体を対象にします。",
    "Range Start": "範囲開始",
    "Start frame used by timing tools when Timing Range is enabled.": "タイミング範囲が有効なときに使う開始フレームです。",
    "Range End": "範囲終了",
    "End frame used by timing tools when Timing Range is enabled.": "タイミング範囲が有効なときに使う終了フレームです。",
    "Shift Frames": '移動フレーム数',
    "Number of frames used by Shift Keys. Positive values move keys later, negative values move keys earlier.": "Shift Keys で使うフレーム移動量です。正の値は後ろへ、負の値は前へ動かします。",
    "Scale Factor": "スケール係数",
    "Timing scale multiplier used by Scale Key Timing. Values above 1.0 expand timing, values below 1.0 compress it.": "Scale Key Timing で使うタイミング倍率です。1.0 より大きいと伸ばし、1.0 より小さいと詰めます。",
    "Pivot": "ピボット",
    "Choose which frame acts as the pivot when scaling timing.": "タイミングを拡大縮小するとき、どのフレームを基準点にするか選びます。",
    "Current Frame": "現在フレーム",
    "Range Start": "範囲開始",
    "Range Center": "範囲中央",
    "Custom Frame": "カスタムフレーム",
    "Custom Pivot": "カスタムピボット",
    "Custom pivot frame used when Pivot is set to Custom Frame.": "ピボットがカスタムフレームのときに使う基準フレームです。",
    "Timing Tools": "タイミングツール",
    "Shift all keys in the active action by the configured frame offset. Use this when you need the whole motion to start earlier or later without editing values.": "アクティブアクションの全キーを、設定したフレーム量だけ移動します。動きの値は変えず、開始タイミングだけ前後させたいときに使います。",
    "Scale the timing of keys in the active action around the chosen pivot frame. Use values above 1.0 to stretch timing and values below 1.0 to compress it.": "アクティブアクション内のキータイミングを、選んだ基準フレームを中心に拡大縮小します。1.0 より大きいと伸ばし、小さいと圧縮します。",
    "Affected Keys": "対象キー数",
    "Frame Range": "フレーム範囲",
    "Shape Keys": "シェイプキー",
    "Insert shape-key values as keyframes on the current frame. Use this for facial controls, visemes, or corrective blendshapes on the active object.": "現在フレームにシェイプキー値をキーフレームとして記録します。アクティブオブジェクトのフェイシャル、口形素、補正ブレンドシェイプに使います。",
    "All Shape Keys": "全シェイプキー",
    "Key all non-Basis shape keys on the active object at the current frame.": "アクティブオブジェクトの Basis 以外の全シェイプキーに、現在フレームでキーを打ちます。",
    "Active Shape Key": "アクティブシェイプキー",
    "Key only the currently active shape key on the active object at the current frame.": "アクティブオブジェクトで現在選択中のシェイプキーだけに、現在フレームでキーを打ちます。",
    "Available Shape Keys": "利用可能シェイプキー数",
    "Timing tools help you move or scale key timing without changing pose values. Use Auto Backup when you want a safe duplicate before retiming.": "タイミングツールは、ポーズ値を変えずにキーの時間だけ移動・拡大縮小します。安全のため、必要なら自動バックアップを有効にして使ってください。",
    "Shape-key tools give facial and corrective animation a quick entry point without leaving the Smart Animation workspace.": "シェイプキーツールにより、Smart Animation ワークスペースから離れずにフェイシャルや補正アニメーションをすぐ扱えます。",
})

JA_TRANSLATIONS.update({
    "Name": "名前",
    "Data": "データ",
    "Source": "ソース",
    "Target": "ターゲット",
    "Confidence": "信頼度",
    "Status": "状態",
    "Level": "レベル",
    "Message": "メッセージ",
    "English": "英語",
    "Japanese": "日本語",
    "Action": "アクション",
    "Action Library": "アクションライブラリ",
    "Note": "メモ",
    "User-facing snapshot label shown in the Pose snapshot list.": "ポーズスナップショット一覧に表示される、ユーザー向けの名前です。",
    "Source bone name for this retarget row.": "このリターゲット行で使うソースボーン名です。",
    "Confidence score for name-based matching in this retarget row.": "この行の名前ベース一致に対する信頼度スコアです。",
    "Severity level used by the recent operation log row.": "最近の操作ログ行で使う重要度レベルです。",
    "Original English log text kept internally for bilingual log display.": "英日両対応ログ表示のために内部保持する英語ログ原文です。",
    "Action data-block name stored in the in-panel motion library.": "パネル内モーションライブラリに保存された Action データブロック名です。",
    "Object name associated with the stored action when it was added to the motion library.": "そのアクションをモーションライブラリへ追加した時点で関連付けられていたオブジェクト名です。",
    "Optional short note shown next to the stored library action.": "保存済みライブラリアクションの横に表示する任意の短いメモです。",
    "Stored pose snapshots available for quick reapplication.": "すばやく再適用できる保存済みポーズスナップショット一覧です。",
    "Preview list of source-to-target bone matches used by retarget tools.": "リターゲットツールが使う、ソースからターゲットへのボーン対応プレビュー一覧です。",
    "Recent Smart Animation operations shown in the workspace log.": "ワークスペースのログに表示する Smart Animation の最近の操作一覧です。",
    "In-panel action library entries for reuse and NLA pushing.": "再利用や NLA 送出に使う、パネル内アクションライブラリ項目です。",
})


JA_TRANSLATIONS.update({
    "NLA Blend": "NLA ブレンド",
    "Blend mode used when Smart Animation pushes an action into NLA. Replace behaves like a normal layer, while Add and Combine are useful for layer-style animation stacking.": "Smart Animation がアクションを NLA へ送る際に使うブレンド方式です。Replace は通常の置換レイヤー、Add と Combine はレイヤー型の重ね合わせに向いています。",
    "Replace": "置換",
    "Use a standard replacing strip.": "通常の置換ストリップとして使います。",
    "Combine": "結合",
    "Combine compatible channels additively where possible.": "互換性のあるチャンネルを可能な範囲で加算的に結合します。",
    "Add": "加算",
    "Add the strip on top of lower animation.": "下のアニメーションの上にストリップを加算します。",
    "Subtract": "減算",
    "Subtract the strip from lower animation.": "下のアニメーションからストリップを差し引きます。",
    "Multiply": "乗算",
    "Layer Action Name": "レイヤーアクション名",
    "Create the editable action name used when Smart Animation builds a new non-destructive animation layer.": "Smart Animation が非破壊アニメーションレイヤーを作成するときに使う、編集用アクション名です。",
    "Multiply compatible channels.": "互換性のあるチャンネルを乗算します。",
    "Tween Factor": "トゥイーン係数",
    "Blend between neighboring keys on the current frame. 0.0 matches the previous key, 1.0 matches the next key, and values outside that range create anticipation or overshoot.": "現在フレームで前後のキーをブレンドします。0.0 は前キー、1.0 は次キーに一致し、範囲外の値は予備動作やオーバーシュートを作ります。",
    "Push/Pull Factor": "プッシュ/プル係数",
    "animBot-style push or pull amount applied around the current frame. Positive values exaggerate spacing away from the straight interpolation, while negative values pull the key back toward the in-between line.": "現在フレーム周辺で使う、animBot 風のプッシュ/プル量です。正の値は直線補間からさらに離してスペーシングを強調し、負の値は中間線へ引き戻します。",
    "Pose Blend": "ポーズブレンド",
    "Blend strength used when applying the highlighted pose snapshot. 1.0 applies the full stored pose, while smaller values partially blend from the current pose.": "選択中のポーズスナップショットを適用するときのブレンド強度です。1.0 は保存ポーズを完全適用し、小さい値では現在ポーズから部分的にブレンドします。",
    "Step Size": "ステップ幅",
    "Number of frames held by the stepped tools. 1 works every frame, 2 approximates animating on twos, 3 on threes, 4 on fours, and larger values create longer held timing.": "ステップ系ツールで値を保持するフレーム数です。1 は毎フレーム、2 は 2 コマ打ち、3 は 3 コマ打ち、4 は 4 コマ打ちの近似で、さらに大きい値はより長い保持になります。",
    "Replace SAS Step": "既存 SAS ステップ置換",
    "Remove older Smart Animation stepped-preview modifiers before adding a new one so the result stays predictable.": "新しい段階プレビューを追加する前に古い Smart Animation の段階プレビュー用モディファイアを削除し、結果を予測しやすくします。",
    "Noise Strength": "ノイズ強度",
    "Amplitude used by the procedural noise modifier helper. Small values are useful for handheld camera shake and subtle organic motion.": "手続き型ノイズモディファイア補助で使う振幅です。小さい値は手持ちカメラの揺れや微妙な有機的モーションに向いています。",
    "Noise Scale": "ノイズスケール",
    "Time scale of the procedural noise modifier. Larger values create slower, broader motion and smaller values create tighter vibration.": "手続き型ノイズモディファイアの時間スケールです。大きい値はゆっくり大きな動き、小さい値は細かい振動を作ります。",
    "Noise Phase": "ノイズ位相",
    "Phase offset used when creating or refreshing the procedural noise modifier.": "手続き型ノイズモディファイアを作成または更新するときに使う位相オフセットです。",
    "Noise Depth": "ノイズ深度",
    "Number of noise layers used by the procedural modifier. Higher values create more complex motion but may be harder to art-direct.": "手続き型モディファイアで使うノイズ層の数です。高いほど複雑な動きになりますが、演出調整は難しくなります。",
    "Smooth Factor": "スムーズ係数",
    "How strongly the curve smoothing tool moves key values toward a local average. Smaller values are safer for preserving performance detail.": "カーブスムージングがキー値を局所平均へどれだけ寄せるかを決めます。小さい値ほど演技の細部を残しやすくなります。",
    "Smooth Iterations": "スムーズ反復数",
    "How many passes the curve smoothing tool performs over each F-Curve.": "カーブスムージングが各 F カーブに対して何回処理を行うかです。",
    "Cascade Delay": "カスケード遅延",
    "Overlap Frames": "オーバーラップフレーム",
    "Frame delay used by the baked overlap helper. Larger values create more drag and follow-through on later target groups.": "ベイク式オーバーラップ補助で使うフレーム遅延です。大きいほど後続ターゲット群にドラッグとフォロースルーが強く出ます。",
    "Overlap Blend": "オーバーラップ強度",
    "How strongly the overlap helper pulls keys toward earlier motion. Higher values exaggerate drag, lower values preserve more of the original timing.": "オーバーラップ補助がキーを過去の動きへ引く強さです。大きいほどドラッグ感が強くなり、小さいほど元のタイミングを保ちます。",
    "Overlap Decay": "オーバーラップ減衰",
    "How much the overlap strength decreases for each successive target group. Lower values make deeper chains settle sooner, while 1.0 keeps the same strength on every group.": "後続ターゲット群ごとにオーバーラップ強度をどれだけ減衰させるかです。小さいほど深いチェーンが早く収まり、1.0 では全グループで同じ強度を保ちます。",
    "Frame offset added progressively to selected targets when using the cascade delay helper. Useful for overlap, follow-through, and staggered timing.": "カスケード遅延補助を使う際に、選択ターゲットへ段階的に追加するフレームオフセットです。オーバーラップ、フォロースルー、段差タイミングに便利です。",
    "Random Seed": "ランダムシード",
    "Seed used by random timing tools so you can reproduce or vary a staggered result.": "ランダムタイミングツールが使うシード値です。同じ結果の再現や結果の変化に使えます。",
    "Random Min": "ランダム最小",
    "Minimum frame offset used by the random timing helper.": "ランダムタイミング補助で使う最小フレームオフセットです。",
    "Random Max": "ランダム最大",
    "Maximum frame offset used by the random timing helper.": "ランダムタイミング補助で使う最大フレームオフセットです。",
})


JA_TRANSLATIONS.update({
    "Unbake Tolerance": "アンベイク許容値",
    "Allowed value deviation when converting dense baked curves into a sparse editable result. Smaller values preserve more detail, larger values remove more in-betweens.": "高密度にベイクされたカーブを疎な編集向け結果へ変換する際に許容する値の誤差です。小さいほど細部を残し、大きいほど中間キーを多く削減します。",
    "Preserve Extremes": "極値を保持",
    "Keep obvious peaks, valleys, and plateau transition keys while simplifying baked curves into a sparse editable pass.": "ベイク済みカーブを疎で編集しやすい状態へ簡略化するときに、明確な山・谷・停滞からの切り替えキーを保持します。",
    "Tangent Mode": "接線モード",
    "Tangent and interpolation preset used by the tangent utility buttons. Flat makes plateau keys easier to clean, Broken creates a discontinuity-style sharp change, Auto and Auto Clamped restore smoothing, Vector creates straight handles, Linear changes interpolation, and Constant is useful for blocking.": "接線ユーティリティボタンで使う接線・補間プリセットです。Flat は平坦な接地整理、Broken は不連続風の鋭い変化、Auto / Auto Clamped は滑らかさ復元、Vector は直線的ハンドル、Linear は補間をリニア化、Constant はブロッキング向けです。",
    "Broken": "ブロークン",
    "Break the left and right handles so a key can change direction sharply like a discontinuity key.": "左右ハンドルを分離し、不連続キーのような鋭い方向転換を作ります。",
    "Tangent and interpolation preset used by the tangent utility buttons. Flat makes plateau keys easier to clean, Auto and Auto Clamped restore smoothing, Vector creates straight handles, Linear changes interpolation, and Constant is useful for blocking.": "接線ユーティリティボタンで使う、接線と補間のプリセットです。Flat は接地や停止、Auto と Auto Clamped は滑らかさの復元、Vector は直線的なハンドル、Linear は補間変更、Constant はブロッキングに便利です。",
    "Flat": "フラット",
    "Flatten selected or all key handles horizontally for cleanup or planted contacts.": "選択または対象のキーハンドルを水平にし、接地や停止の整理をしやすくします。",
    "Trail Step": "トレイル間隔",
    "Frame increment used when sampling trail curves. 1 captures every frame, larger values create lighter preview trails.": "トレイルカーブのサンプリングで使うフレーム間隔です。1 は毎フレームを取得し、大きいほど軽いプレビュートレイルになります。",
    "Trail Resolution": "トレイル解像度",
    "Viewport and render resolution used for generated trail curves.": "生成したトレイルカーブに使うビューポートおよびレンダー解像度です。",
    "Trail Radius": "トレイル半径",
    "Bevel radius used for generated trail curves. Small values work well for motion accents and sword arcs.": "生成したトレイルカーブに使うベベル半径です。小さい値はモーション強調や剣の軌跡に向いています。",
    "Keep Previous Trails": "以前のトレイルを保持",
    "When disabled, older Smart Animation trail objects are removed before a new trail is generated.": "無効時は、新しいトレイル生成前に以前の Smart Animation トレイルオブジェクトを削除します。",
    "Camera Shake Preset": "カメラシェイクプリセット",
    "Preset used by the camera-shake helper. Subtle suits handheld polish, Heavy is useful for energetic cameras, and Impact is for hits or landings.": "カメラシェイク補助で使うプリセットです。Subtle は軽い手持ち感、Heavy は動きの強いカメラ、Impact は被弾や着地向けです。",
    "Subtle": "控えめ",
    "Gentle handheld noise for light camera polish.": "軽い手持ち風の揺れを付ける、穏やかなノイズです。",
    "Heavy": "強め",
    "Stronger handheld noise for active camera motion.": "動きの大きいカメラ向けの、より強い手持ちノイズです。",
    "Impact": "インパクト",
    "Short, sharper shake intended for hits or landings.": "被弾や着地を想定した、短く鋭い揺れです。",
})

JA_TRANSLATIONS.update({
    "Apply Default easing preset to selected keyframes": "選択中のキーフレームに「デフォルト」のイージングを適用します。",
    "Apply Just Fine easing preset to selected keyframes": "選択中のキーフレームに「ジャストファイン」のイージングを適用します。",
    "Apply Cubic easing preset to selected keyframes": "選択中のキーフレームに「キュービック」のイージングを適用します。",
    "Apply Exponential easing preset to selected keyframes": "選択中のキーフレームに「指数」のイージングを適用します。",
    "Apply Extreme easing preset to selected keyframes": "選択中のキーフレームに「極端」のイージングを適用します。",
    "Apply Smooth easing preset to selected keyframes": "選択中のキーフレームに「スムーズ」のイージングを適用します。",
    "Apply Easy easing preset to selected keyframes": "選択中のキーフレームに「イージー」のイージングを適用します。",
    "Apply Super Smooth easing preset to selected keyframes": "選択中のキーフレームに「超スムーズ」のイージングを適用します。",
    "Apply Ease In Only easing preset to selected keyframes": "選択中のキーフレームに「イーズインのみ」のイージングを適用します。",
    "Apply Ease Out Only easing preset to selected keyframes": "選択中のキーフレームに「イーズアウトのみ」のイージングを適用します。",
    "Apply Smooth Out easing preset to selected keyframes": "選択中のキーフレームに「スムーズアウト」のイージングを適用します。",
    "Apply Easy Out easing preset to selected keyframes": "選択中のキーフレームに「イージーアウト」のイージングを適用します。",
    "Apply Super Smooth Out easing preset to selected keyframes": "選択中のキーフレームに「超スムーズアウト」のイージングを適用します。",
    "Apply Linear easing preset to selected keyframes": "選択中のキーフレームに「リニア」のイージングを適用します。",
    "Apply Max easing preset to selected keyframes": "選択中のキーフレームに「最大」のイージングを適用します。",
    "Apply Explosive easing preset to selected keyframes": "選択中のキーフレームに「爆発的」のイージングを適用します。",
    "Apply Overshoot 1 easing preset to selected keyframes": "選択中のキーフレームに「オーバーシュート 1」のイージングを適用します。",
    "Apply Overshoot 2 easing preset to selected keyframes": "選択中のキーフレームに「オーバーシュート 2」のイージングを適用します。",
    "Apply Easy Going easing preset to selected keyframes": "選択中のキーフレームに「ゆったり」のイージングを適用します。",
    "Apply Anticipation + Overshoot easing preset to selected keyframes": "選択中のキーフレームに「予備動作 + オーバーシュート」のイージングを適用します。",
    "Apply Anticipation 1 easing preset to selected keyframes": "選択中のキーフレームに「予備動作 1」のイージングを適用します。",
    "Apply Anticipation 2 easing preset to selected keyframes": "選択中のキーフレームに「予備動作 2」のイージングを適用します。",
    "Apply Anticipation 3 easing preset to selected keyframes": "選択中のキーフレームに「予備動作 3」のイージングを適用します。",
    "Apply Agitated easing preset to selected keyframes": "選択中のキーフレームに「アジテート」のイージングを適用します。",
    "Apply Springy easing preset to selected keyframes": "選択中のキーフレームに「スプリング風」のイージングを適用します。",
    "Apply Very Late Stop easing preset to selected keyframes": "選択中のキーフレームに「非常に遅い停止」のイージングを適用します。",
    "Apply Weird easing preset to selected keyframes": "選択中のキーフレームに「変則」のイージングを適用します。",
    "Apply Overshoot x3 easing preset to selected keyframes": "選択中のキーフレームに「オーバーシュート x3」のイージングを適用します。",
    "Apply Spring Back easing preset to selected keyframes": "選択中のキーフレームに「スプリングバック」のイージングを適用します。",
    "Apply Bouncy easing preset to selected keyframes": "選択中のキーフレームに「バウンス」のイージングを適用します。",
    "Anticipation + Overshoot": "予備動作 + オーバーシュート",
})

TRANSLATIONS = {"ja_JP": {("*", en): ja for en, ja in JA_TRANSLATIONS.items()}}


def sas_current_locale(context=None):
    # Blender's interface language setting is the source of truth. Do not infer
    # Japanese from the OS/Python locale when Blender is configured for English
    # or interface translation is disabled.
    try:
        prefs = (context or bpy.context).preferences.view
        if not getattr(prefs, "use_translate_interface", True):
            return "en_US"
        language = str(getattr(prefs, "language", "") or "")
        if language and language.upper() != 'DEFAULT':
            return language
    except Exception:
        pass
    try:
        locale = str(getattr(bpy.app.translations, "locale", "") or "")
        if locale:
            return locale
    except Exception:
        pass
    return "en_US"



def sas_is_japanese(context=None):
    return sas_current_locale(context).lower().startswith("ja")



def sas_text(en_text, ja_text, context=None):
    chosen = ja_text if sas_is_japanese(context) else en_text
    try:
        return sanitize_bilingual_text(chosen, context)
    except Exception:
        return chosen



def sas_info(layout, context, en_text, ja_text, icon='NONE'):
    box = layout.box()
    box.label(text=sas_text(en_text, ja_text, context), icon=icon)


_JA_CHAR_RE = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uff66-\uff9f]")



_JA_ERROR_REASONS = (
    (('poll()', 'context is incorrect', 'incorrect context'), '今の状態では実行できません。モードと選択を確かめてください'),
    (('read-only', 'readonly', 'read only'), '読み取り専用のため変更できません'),
    (('permission denied',), 'ファイルに書き込む権限がありません'),
    (('no such file', 'cannot open', 'could not open'), 'ファイルを開けません'),
    (('not found', 'could not be found', 'not available'), '必要なデータが見つかりません'),
    (('expecting ', 'extra data', 'json', 'delimiter'), 'ファイルの形式が正しくありません'),
    (('expecting ', 'extra data', 'json', 'delimiter'), 'ファイルの形式が正しくありません'),
)


def sas_error_reason(exc) -> str:
    """Return the reason shown after a Japanese failure message."""
    text = str(exc or '')
    if _JA_CHAR_RE.search(text):
        return text
    lowered = text.lower()
    for needles, reason in _JA_ERROR_REASONS:
        if any(needle in lowered for needle in needles):
            return reason
    return '処理を続けられませんでした'


def sas_has_japanese(text) -> bool:
    return bool(_JA_CHAR_RE.search(str(text or '')))



_BILINGUAL_SEPARATOR_RE = re.compile(r"\s*(?:/|／|\||｜)\s*")
_TRANSLATION_PLACEHOLDER_RE = re.compile(r"\{[^{}]*\}")
_MAX_TEMPLATE_REGEX_CACHE = 256
_TEMPLATE_REGEX_CACHE = OrderedDict()


def _split_bilingual_pair(text):
    value = str(text or '')
    if not value:
        return None
    # Only split clear two-part English/Japanese pairs.  Technical labels such
    # as "Grab / Rotate / Scale" or Japanese text containing "Undo / Redo" are
    # left untouched because they are not bilingual duplicate labels.
    for sep in (' / ', ' ／ ', ' | ', ' ｜ ', '／', '｜'):
        if sep not in value:
            continue
        parts = [part.strip() for part in value.split(sep)]
        if len(parts) != 2 or not parts[0] or not parts[1]:
            continue
        left_is_ja = sas_has_japanese(parts[0])
        right_is_ja = sas_has_japanese(parts[1])
        if left_is_ja != right_is_ja:
            return parts[0], parts[1]
    if value.count('/') + value.count('|') + value.count('／') + value.count('｜') == 1:
        parts = [part.strip() for part in _BILINGUAL_SEPARATOR_RE.split(value, maxsplit=1)]
        if len(parts) == 2 and parts[0] and parts[1]:
            left_is_ja = sas_has_japanese(parts[0])
            right_is_ja = sas_has_japanese(parts[1])
            if left_is_ja != right_is_ja:
                return parts[0], parts[1]
    return None


def _select_bilingual_variant(value, context=None, *, prefer_japanese=None):
    text = str(value or '')
    pair = _split_bilingual_pair(text)
    if pair is None:
        return text
    left, right = pair
    left_is_ja = sas_has_japanese(left)
    want_ja = sas_is_japanese(context) if prefer_japanese is None else bool(prefer_japanese)
    if want_ja:
        return left if left_is_ja else right
    return right if left_is_ja else left


def _is_translation_template(text):
    return bool(_TRANSLATION_PLACEHOLDER_RE.search(str(text or '')))


def _template_regex(template):
    template = str(template or '')
    if template in _TEMPLATE_REGEX_CACHE:
        cached = _TEMPLATE_REGEX_CACHE[template]
        try:
            _TEMPLATE_REGEX_CACHE.move_to_end(template)
        except Exception:
            pass
        return cached
    pieces = []
    last = 0
    for match in _TRANSLATION_PLACEHOLDER_RE.finditer(template):
        pieces.append(re.escape(template[last:match.start()]))
        pieces.append('(.*?)')
        last = match.end()
    pieces.append(re.escape(template[last:]))
    try:
        compiled = re.compile('^' + ''.join(pieces) + '$', re.DOTALL)
    except Exception:
        compiled = None
    _TEMPLATE_REGEX_CACHE[template] = compiled
    try:
        _TEMPLATE_REGEX_CACHE.move_to_end(template)
    except Exception:
        pass
    while len(_TEMPLATE_REGEX_CACHE) > _MAX_TEMPLATE_REGEX_CACHE:
        try:
            _TEMPLATE_REGEX_CACHE.popitem(last=False)
        except Exception:
            break
    return compiled


def _fill_translation_template(template, groups):
    values = list(groups or ())
    index = 0

    def repl(_match):
        nonlocal index
        if index >= len(values):
            return ''
        value = values[index]
        index += 1
        return str(value)

    return _TRANSLATION_PLACEHOLDER_RE.sub(repl, str(template or ''))


def _match_translation_template(source_text, target_template, value):
    source_text = str(source_text or '')
    target_template = str(target_template or '')
    value = str(value or '')
    if not source_text or not target_template or not value or not _is_translation_template(source_text):
        return None
    regex = _template_regex(source_text)
    if regex is None:
        return None
    match = regex.match(value)
    if match is None:
        return None
    try:
        return _fill_translation_template(target_template, match.groups())
    except Exception:
        return None


def _template_specificity(source_text):
    text = str(source_text or '')
    literal = _TRANSLATION_PLACEHOLDER_RE.sub('', text)
    placeholders = len(_TRANSLATION_PLACEHOLDER_RE.findall(text))
    return (len(literal), len(text), -placeholders)


def _translate_template_to_japanese(value):
    value = str(value or '')
    fallback = None
    pairs = sorted(_iter_translation_pairs(include_dynamic=True), key=lambda item: _template_specificity(item[0]), reverse=True)
    for en, ja in pairs:
        result = _match_translation_template(en, ja, value)
        if result is None:
            continue
        if result != value:
            return result
        if fallback is None:
            fallback = result
    return fallback


def _translate_template_to_english(value):
    value = str(value or '')
    fallback = None
    pairs = sorted(_iter_translation_pairs(include_dynamic=True), key=lambda item: _template_specificity(item[1]), reverse=True)
    for en, ja in pairs:
        result = _match_translation_template(ja, en, value)
        if result is None:
            continue
        if result != value:
            return result
        if fallback is None:
            fallback = result
    return fallback


def sanitize_bilingual_text(text, context=None):
    value = _select_bilingual_variant(text, context)
    translator = globals().get('sas_translate_text')
    if callable(translator):
        try:
            return translator(value, context, split_bilingual=False)
        except Exception:
            return value
    return value



def _load_auto_translations():
    result = {}
    for module_name, attr_name in (
        ('translation_auto', 'AUTO_UI_JA_TRANSLATIONS'),
        ('translation_supplement', 'SUPPLEMENTAL_UI_JA_TRANSLATIONS'),
    ):
        try:
            module = __import__(f'{__package__}.{module_name}', fromlist=[attr_name])
            mapping = getattr(module, attr_name, {})
            iterator = mapping.items()
        except Exception:
            continue
        for en, ja in iterator:
            en_text = str(en or '').strip()
            ja_text = str(ja or '').strip()
            if en_text and ja_text:
                result[en_text] = ja_text
    return result



try:
    for _auto_en, _auto_ja in _load_auto_translations().items():
        JA_TRANSLATIONS.setdefault(_auto_en, _auto_ja)
except Exception:
    pass


_TRANSLATION_CONTEXTS = (
    '*',
    'Operator',
    'Property',
    'Tooltip',
    'UI',
    'Panel',
    'Menu',
    'Addon',
    'WindowManager',
    'Scene',
)
_DYNAMIC_TRANSLATION_OWNER = f"{(__package__ or __name__ or 'smart_animation_suite')}.dynamic_ui_translation"
_DYNAMIC_JA_TRANSLATIONS = {}



def _iter_translation_pairs(include_dynamic=True):
    for en, ja in JA_TRANSLATIONS.items():
        en_text = str(en or '').strip()
        ja_text = str(ja or '').strip()
        if en_text and ja_text:
            yield en_text, ja_text
    if include_dynamic:
        for en, ja in _DYNAMIC_JA_TRANSLATIONS.items():
            en_text = str(en or '').strip()
            ja_text = str(ja or '').strip()
            if en_text and ja_text:
                yield en_text, ja_text



def _english_from_japanese(ja_text):
    value = str(ja_text or '').strip()
    if not value:
        return value
    for en, ja in _iter_translation_pairs(include_dynamic=True):
        if str(ja or '').strip() == value:
            return en
    templated = _translate_template_to_english(value)
    if templated:
        return templated
    return value



def _dynamic_ja_for_text(text):
    value = _select_bilingual_variant(text, None, prefer_japanese=False).strip()
    if not value:
        return ''
    if sas_has_japanese(value):
        return value
    exact = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
    if exact:
        return str(exact)
    suffix = ' details'
    if value.endswith(suffix):
        base = value[:-len(suffix)].strip()
        base_ja = JA_TRANSLATIONS.get(base) or _DYNAMIC_JA_TRANSLATIONS.get(base) or base
        return f'{base_ja} 詳細'
    prefix = 'Expand to view the overview and usage guide for '
    if value.startswith(prefix) and value.endswith('.'):
        base = value[len(prefix):-1].strip()
        base_ja = JA_TRANSLATIONS.get(base) or _DYNAMIC_JA_TRANSLATIONS.get(base) or base
        return f'{base_ja} の概要と使い方を表示します。'
    return _translate_dynamic_phrase_to_japanese(value)


def _translate_dynamic_phrase_to_japanese(value):
    text = str(value or '')
    if not text:
        return ''
    match = re.match(r'^(\s*)([0-9]+(?:\.[0-9]+)?)(\s*)Frames?$', text)
    if match:
        return f"{match.group(1)}{match.group(2)}{match.group(3)}フレーム"
    match = re.match(r'^Time Per Panel:\s*([0-9]+(?:\.[0-9]+)?)\s*seconds$', text)
    if match:
        return f"パネルあたりの時間: {match.group(1)} 秒"
    match = re.match(r'^Number of panel frames:\s*(.+)$', text)
    if match:
        return f"パネルフレーム数: {match.group(1)}"
    match = re.match(r'^Loaded now:\s*(.+?)\s*\|\s*Ready:\s*(.+)$', text)
    if match:
        return f"現在読み込み中: {match.group(1)}  |  読み込み待ち: {match.group(2)}"
    match = re.match(r'^Status:\s*(.+)$', text)
    if match:
        inner = sas_translate_text(match.group(1), None)
        return f"状態: {inner}"
    return ''



def sas_translate_text(text, context=None, *, split_bilingual=True):
    value = str(text or '')
    if split_bilingual:
        value = _select_bilingual_variant(value, context)
    if not value:
        return value
    if sas_is_japanese(context):
        translated = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
        if translated:
            return str(translated)
        templated = _translate_template_to_japanese(value)
        if templated and templated != value:
            return templated
        dynamic = _translate_dynamic_phrase_to_japanese(value)
        if dynamic and dynamic != value:
            return dynamic
        return value
    if sas_has_japanese(value):
        return _english_from_japanese(value)
    return value



def sas_localize_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)



def sas_english_source_text(text, context=None):
    value = _select_bilingual_variant(text, context, prefer_japanese=False)
    if sas_has_japanese(value):
        return _english_from_japanese(value)
    return value



def _build_translation_table(include_dynamic=True):
    table = {}
    for en, ja in _iter_translation_pairs(include_dynamic=include_dynamic):
        for ctx in _TRANSLATION_CONTEXTS:
            table[(ctx, en)] = ja
    return {'ja_JP': table, 'ja': dict(table)}



def register_dynamic_ui_translations(texts):
    changed = False
    for item in texts or ():
        value = str(item or '').strip()
        if not value:
            continue
        pair = _split_bilingual_pair(value)
        if pair is not None:
            left, right = pair
            if sas_has_japanese(left):
                en_text, ja_text = right, left
            else:
                en_text, ja_text = left, right
        else:
            selected = value.strip()
            if not selected:
                continue
            if sas_has_japanese(selected):
                en_text = _english_from_japanese(selected)
                ja_text = selected
                if not en_text or en_text == ja_text:
                    continue
            else:
                en_text = selected
                ja_text = _dynamic_ja_for_text(selected)
                if not ja_text:
                    continue
        if _DYNAMIC_JA_TRANSLATIONS.get(en_text) == ja_text:
            continue
        _DYNAMIC_JA_TRANSLATIONS[en_text] = ja_text
        changed = True
    if not changed:
        return
    try:
        bpy.app.translations.unregister(_DYNAMIC_TRANSLATION_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_DYNAMIC_TRANSLATION_OWNER, _build_translation_table(include_dynamic=True))
    except Exception:
        pass



def unregister_dynamic_ui_translations():
    try:
        bpy.app.translations.unregister(_DYNAMIC_TRANSLATION_OWNER)
    except Exception:
        pass
    try:
        _DYNAMIC_JA_TRANSLATIONS.clear()
    except Exception:
        pass


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

TAB_ITEMS = [
    ('DASHBOARD', "Dashboard", "Visual scene summary and recommended next steps.", 'HOME', 0),
    ('QUICK', "Quick", "Daily keying, baking, and timeline helpers.", 'KEY_HLT', 1),
    ('CLEAN', "Clean", "Safe cleanup for imported, baked, or dense animation.", 'IPO_BEZIER', 2),
    ('POSE', "Pose", "Mirror, reset, store, and reuse poses.", 'POSE_HLT', 3),
    ('NLA', "NLA", "Action duplication and non-linear clip workflow.", 'NLA', 4),
    ('RETARGET', "Retarget", "Rig mapping preview and retarget profile export.", 'ARROW_LEFTRIGHT', 5),
    ('TOOLS', "Tools", "Diagnostics, reports, and operation history.", 'TOOL_SETTINGS', 6),
]

BAKE_RANGE_ITEMS = [
    ('SCENE', "Scene", "Use the scene start and end frames."),
    ('PREVIEW', "Preview", "Use the scene preview range when enabled; otherwise fall back to the scene range."),
    ('CUSTOM', "Custom", "Use custom start and end frames from the add-on settings."),
]


# -----------------------------------------------------------------------------

JA_TRANSLATIONS.update({
    "Ghost Past": "過去ゴースト数",
    "How many past ghost samples to generate on the active object or its driven meshes. Larger values show more history but create more preview objects.": "アクティブオブジェクトまたはそれに追従するメッシュに対して、過去方向へ何枚のゴーストを生成するかです。値が大きいほど履歴を多く見られますが、プレビューオブジェクトも増えます。",
    "Ghost Future": "未来ゴースト数",
    "How many future ghost samples to generate on the active object or its driven meshes. Use this to inspect spacing and silhouette progression ahead of the current frame.": "アクティブオブジェクトまたはそれに追従するメッシュに対して、未来方向へ何枚のゴーストを生成するかです。現在フレームより先のスペーシングやシルエット変化の確認に使います。",
    "Ghost Step": "ゴースト間隔",
    "Frame spacing between ghost samples. 1 uses every frame, 2 approximates twos, and larger values create lighter previews.": "ゴーストサンプル間のフレーム間隔です。1 は毎フレーム、2 は 2 コマ風、大きい値ほど軽いプレビューになります。",
    "Keep Previous Ghosts": "以前のゴーストを保持",
    "When disabled, older Smart Animation ghost preview objects are removed before new ghosts are generated.": "無効時は、新しいゴーストを生成する前に古い Smart Animation ゴーストプレビューオブジェクトを削除します。",
    "Loop Mode": "ループモード",
    "Cycles modifier preset used by the loop helper. Repeat loops cleanly, Repeat Offset keeps value offsets, and Ping-Pong mirrors the motion back and forth.": "ループ補助で使う Cycles モディファイアのプリセットです。Repeat は綺麗にループし、Repeat Offset は値のオフセットを保ち、Ping-Pong は往復するように反転ループします。",
    "Repeat": "繰り返し",
    "Repeat the motion with a seamless loop.": "モーションを継ぎ目なく繰り返します。",
    "Repeat Offset": "オフセット繰り返し",
    "Repeat while preserving the value offset between loop cycles.": "ループごとの値オフセットを保持したまま繰り返します。",
    "Ping-Pong": "ピンポン",
    "Mirror the motion back and forth like a ping-pong loop.": "ピンポンのように往復する形でモーションを反転ループします。",
    "Loop Scope": "ループ範囲",
    "Choose whether the loop helper extends before the first key, after the last key, or in both directions.": "ループ補助を最初のキーより前、最後のキーより後、または両方向へ適用するか選びます。",
    "After": "後ろ",
    "Loop after the final key range.": "最後のキー範囲より後ろにループを適用します。",
    "Before": "前",
    "Loop before the first key range.": "最初のキー範囲より前にループを適用します。",
    "Both": "両方向",
    "Loop in both directions.": "両方向にループを適用します。",
})



JA_TRANSLATIONS.update({
    "Contact Hold Start": "コンタクト保持開始",
    "Start frame of the planted-contact or fulcrum hold range. Use this to keep feet, hands, or held props stable while they stay in contact.": "接地や支点保持に使う範囲の開始フレームです。足、手、保持中の小物などを接触中に安定させる用途に使います。",
    "Contact Hold End": "コンタクト保持終了",
    "End frame of the planted-contact or fulcrum hold range. Use this to keep feet, hands, or held props stable while they stay in contact.": "接地や支点保持に使う範囲の終了フレームです。足、手、保持中の小物などを接触中に安定させる用途に使います。",
    "Ballistic Step": "弾道間隔",
    "Frame step used when drawing the ballistic guide. Smaller values create denser arcs and larger values create lighter previews.": "弾道ガイドを描くときのフレーム間隔です。小さい値は密な弧を作り、大きい値は軽いプレビューになります。",
    "Keep Previous Ballistics": "以前の弾道ガイドを保持",
    "When disabled, older Smart Animation ballistic guide curves are removed before a new ballistic guide is generated.": "無効時は、新しい弾道ガイドを生成する前に古い Smart Animation の弾道ガイドカーブを削除します。",
})

try:
    TRANSLATIONS["ja_JP"].update({("*", en): ja for en, ja in JA_TRANSLATIONS.items()})
except Exception:
    pass


JA_TRANSLATIONS.update({
    "Cycles Before": "前方向サイクル数",
    "Cycle count limit applied before the keyed range when the loop helper affects the Before or Both directions.": "ループ補助が Before または Both に作用するとき、キーフレーム範囲より前に適用するサイクル数の上限です。",
    "Cycles After": "後方向サイクル数",
    "Cycle count limit applied after the keyed range when the loop helper affects the After or Both directions.": "ループ補助が After または Both に作用するとき、キーフレーム範囲より後に適用するサイクル数の上限です。",
    "Pose Snapshot Text": "ポーズスナップショット用テキスト",
    "Blender text datablock used when exporting or importing pose snapshot JSON so poses can be shared between scenes without extra files.": "外部ファイルを増やさずにシーン間でポーズ共有できるよう、ポーズスナップショット JSON の書き出し・読み込みに使う Blender テキストデータです。",
    "Library Manifest Text": "ライブラリ一覧用テキスト",
    "Blender text datablock used when exporting or importing the motion-library manifest JSON.": "モーションライブラリ一覧 JSON の書き出し・読み込みに使う Blender テキストデータです。",
    "Export Pose JSON": 'ポーズ JSON を書き出し',
    "Import Pose JSON": 'ポーズ JSON を読み込み',
    "Export the current pose snapshots as JSON into Blender text data and copy the JSON to the clipboard.": "現在のポーズスナップショットを JSON として Blender テキストデータへ書き出し、同時にクリップボードへコピーします。",
    "Import pose snapshots from the configured Blender text datablock and append them with unique names.": "設定した Blender テキストデータからポーズスナップショットを読み込み、重複しない名前で追加します。",
    "Import Library Manifest": "ライブラリ一覧読み込み",
    "Read the motion-library manifest JSON from Blender text data and rebuild matching library entries for actions that exist in the current file.": "Blender テキストデータからモーションライブラリ一覧 JSON を読み込み、現在のファイルに存在するアクションだけでライブラリエントリを再構築します。",
    "Prune Missing Entries": "欠損エントリ整理",
    "Remove duplicate or missing motion-library entries so the library stays compact and predictable.": "重複または欠損したモーションライブラリエントリを削除し、一覧をコンパクトで分かりやすい状態に保ちます。",
    "Pose Snapshot I/O": "ポーズスナップショット入出力",
    "Motion Library I/O": "モーションライブラリ入出力",
})

try:
    TRANSLATIONS["ja_JP"].update({("*", en): ja for en, ja in JA_TRANSLATIONS.items()})
except Exception:
    pass

JA_TRANSLATIONS.update({
    "Pose Profile": "ポーズプロファイル",
    "Export Pose Snapshots": "ポーズスナップショット書き出し",
    "Import Pose Snapshots": "ポーズスナップショット読み込み",
    "Export the current in-panel pose snapshots as JSON into the configured Blender text datablock and copy the JSON to the clipboard.": "現在パネル内にあるポーズスナップショットを、設定した Blender テキストデータへ JSON として書き出し、同時にクリップボードへもコピーします。",
    "Import pose snapshot JSON from the configured Blender text datablock and rebuild the in-panel pose snapshot list.": "設定した Blender テキストデータからポーズスナップショット JSON を読み込み、パネル内のスナップショット一覧を再構築します。",
    "Overlap Pass": "オーバーラップパス",
    "Create a lightweight baked overlap pass by lagging selected targets toward their earlier motion. This is useful for tails, straps, props, and broad follow-through polish.": "選択ターゲットを過去の動きへ遅らせることで、軽量なベイク式オーバーラップパスを作成します。尻尾、ストラップ、小物、大まかなフォロースルー調整に便利です。",
    "Baked overlap writes delayed motion back into keys so you can keep editing without staying dependent on a live simulation.": "ベイク式オーバーラップは遅延した動きをキーへ書き戻すため、ライブシミュレーションに依存せずそのまま編集を続けられます。",
})



JA_TRANSLATIONS.update({
    "Selection Set Name": "選択セット名",
    "Name used when storing the current object or pose-bone selection as a reusable set. If empty, a default name is generated.": "現在のオブジェクト選択またはポーズボーン選択を再利用セットとして保存するときの名前です。空欄なら自動名が付きます。",
    "Selection Sets": "選択セット",
    "Reusable object or pose-bone selection sets stored in the current scene.": "現在のシーンに保存される、再利用可能なオブジェクト選択またはポーズボーン選択セットです。",
    "Currently selected selection-set row in the Smart Animation workspace list.": "Smart Animation ワークスペース一覧で現在選択中の選択セット行です。",
    "Mode": "モード",
    "Stored selection type: OBJECT or POSE.": "保存された選択タイプです。OBJECT または POSE を表します。",
    "Stored Object": "保存対象オブジェクト",
    "Active object or armature name associated with this selection set.": "この選択セットに関連付けられたアクティブオブジェクトまたはアーマチュア名です。",
    "Targets": "対象名一覧",
    "Serialized object or bone names kept internally for the stored selection set.": "保存された選択セットの内部保持用シリアライズ済みオブジェクト名またはボーン名一覧です。",
    "Selection Sets": "選択セット",
    "Store Set": "セット保存",
    "Apply Set": "セット適用",
    "Remove Set": "セット削除",
    "Key Marks": "選択キーをマーク",
    "Mark Selected Keys": "選択キーをマーク",
})



JA_TRANSLATIONS.update({
    "Overlap Pass": "オーバーラップ処理",
    "Apply Overlap Pass": "オーバーラップ適用",
})


JA_TRANSLATIONS.update({
    "Selection Set Text": "選択セット用テキスト",
    "Blender text datablock used when exporting or importing selection-set JSON so picker-style sets can move between shots or scenes.": "ピッカー風の選択セット JSON をショットやシーン間で移動できるよう、書き出し・読み込みに使う Blender テキストデータです。",
    "Selection Set I/O": "選択セット入出力",
    "Export Selection Sets": "選択セット書き出し",
    "Import Selection Sets": "選択セット読み込み",
    "Export Set JSON": "セット JSON 書き出し",
    "Import Set JSON": "セット JSON 読み込み",
    "Export the current reusable selection sets as JSON into Blender text data and copy the JSON to the clipboard.": "現在の再利用用選択セットを JSON として Blender テキストデータへ書き出し、同時にクリップボードへコピーします。",
    "Import reusable selection sets from the configured Blender text datablock and append them with unique names.": "設定した Blender テキストデータから再利用用選択セットを読み込み、重複しない名前で追加します。",
    "Contact Hold Range from Keys": "選択キーからコンタクト範囲",
    "Range from Selected Keys": "選択キーから範囲設定",
    "Read the selected keyframes and use their first and last frames as the Contact Hold range. This is useful before applying planted-foot or fulcrum cleanup.": "選択中のキーフレームを読み取り、最初と最後のフレームをコンタクト保持範囲として設定します。接地足や支点クリーンアップの前準備に便利です。",
})

try:
    TRANSLATIONS["ja_JP"].update({("*", en): ja for en, ja in JA_TRANSLATIONS.items()})
except Exception:
    pass

JA_TRANSLATIONS.update({
    "Skip Locked Curves": "ロックカーブを除外",
    "Do not edit F-Curves that are locked in the Graph Editor. This helps prevent accidental changes to protected channels.": "グラフエディターでロックされた F カーブを編集対象から外します。保護したチャンネルの誤編集を防ぐ助けになります。",
    "Skip Muted Curves": "ミュートカーブを除外",
    "Do not edit muted F-Curves. This keeps intentionally disabled channels untouched during cleanup and procedural passes.": "ミュートされた F カーブを編集対象から外します。意図的に無効化したチャンネルを整理やプロシージャル処理から守れます。",
    "Skip Hidden Curves": "非表示カーブを除外",
    "Do not edit hidden F-Curves. Enable this for a safer compact workflow where only visible channels are changed.": "非表示の F カーブを編集対象から外します。見えているチャンネルだけを安全に扱いたい場合に便利です。",
    "Limited Step": "保持ステップ",
    "Step size used by the limited-animation baker. 2 creates an editable on-twos style copy, 4 approximates on-fours, and larger values create stronger held timing.": "リミテッドアニメーションベイカーで使う保持ステップ幅です。2 なら 2 コマ打ち風、4 なら 4 コマ打ち風の編集可能な複製を作り、さらに大きい値ほど強い保持感になります。",
    "Limited Interpolation": "リミテッド補間",
    "Interpolation used by the baked limited-animation copy. Constant gives the clearest held look, Linear is a lighter stepped feel, and Bezier keeps editable handles.": "ベイクしたリミテッドアニメーション複製で使う補間です。Constant は最も保持感が強く、Linear は軽い段階感、Bezier はハンドル編集のしやすさを残します。",
    "Constant": "コンスタント",
    "Bake held timing with constant interpolation for a clear limited-animation look.": "はっきりしたリミテッドアニメーションの見た目になるよう、保持タイミングをコンスタント補間でベイクします。",
    "Bake held timing with linear interpolation for simple straight breakdowns.": "シンプルな直線的ブレイクダウンになるよう、保持タイミングをリニア補間でベイクします。",
    "Bake held timing with Bezier interpolation for a softer editable result.": "やわらかく編集しやすい結果になるよう、保持タイミングをベジェ補間でベイクします。",
    "Spring Stiffness": "スプリング剛性",
    "How strongly the baked spring pass chases the original motion. Higher values react faster and lower values create softer drag.": "ベイクしたスプリングパスが元の動きをどれだけ強く追うかです。高いほど反応が速く、低いほどやわらかいドラッグになります。",
    "Spring Damping": "スプリング減衰",
    "How quickly the baked spring pass settles down. Higher values keep more motion and lower values damp the motion faster.": "ベイクしたスプリングパスがどれだけ早く収束するかです。高いほど動きを残し、低いほど早く減衰します。",
    "Spring Blend": "スプリングブレンド",
    "Blend between the original animation and the baked spring result. 0 keeps the original motion and 1 applies the full spring pass.": "元アニメーションとベイクしたスプリング結果の混合率です。0 は元の動き、1 は完全なスプリング結果になります。",
    "Spring Sample Step": "スプリングサンプル間隔",
    "Frame step used while baking the spring dynamics pass. 1 samples every frame for the most detail, larger values create lighter results.": "スプリングダイナミクスをベイクするときのサンプル間隔です。1 は毎フレームで最も詳細、大きい値ほど軽い結果になります。",
    "Spring Auto Simplify": "スプリング自動簡略化",
    "After baking the spring pass, simplify the resulting dense keys using the Smart Unbake tolerance settings.": "スプリングパスをベイクした後、Smart Unbake の許容値設定を使って密なキーを簡略化します。",
    "Trail Radius Mode": "トレイル半径モード",
    "Choose whether the trail keeps a constant thickness or scales its thickness based on sampled speed. Speed mode is useful for accenting fast arcs and heavier impacts.": "トレイルを一定の太さにするか、サンプリングした速度に応じて太さを変えるかを選びます。速度モードは速いアークや強いインパクトの強調に便利です。",
    "Keep one consistent trail thickness.": "トレイルの太さを一定に保ちます。",
    "Scale trail point radius from sampled motion speed.": "サンプリングした動きの速度からトレイル各点の半径を変化させます。",
    "Trail Speed Scale": "トレイル速度スケール",
    "Extra thickness added in Speed mode when the sampled motion becomes faster. Larger values exaggerate velocity changes in the trail.": "速度モードで、速い動きほどどれだけ太くするかを決めます。大きい値ほど速度差を強調します。",
    "Curve Safety Filters": "カーブ安全フィルター",
    "These filters keep protected channels out of destructive tools and procedural passes.": "これらのフィルターは、保護したチャンネルを破壊的処理やプロシージャル処理の対象外にします。",
    "Skip Locked": "ロックを除外",
    "Skip Muted": "ミュートを除外",
    "Skip Hidden": "非表示を除外",
    "Advanced Baked Helpers": "高度なベイク補助",
    "Limited Animation Bake": "リミテッドアニメーションベイク",
    "Create a safe on-twos or on-fours style duplicate action with real editable held keys.": "2 コマ打ちや 4 コマ打ち風の保持キーを、実際に編集できる安全な複製アクションとして作成します。",
    "Interpolation": "補間",
    "Bake Limited Copy": "リミテッド複製を作成",
    "Spring Dynamics Bake": "スプリングダイナミクスベイク",
    "Bake spring-style drag, jiggle, and soft follow-through directly back into editable curves.": "スプリング風のドラッグ、ジグル、やわらかいフォロースルーを、編集可能なカーブへ直接ベイクします。",
    "Stiffness": "剛性",
    "Damping": "減衰",
    "Blend": "ブレンド",
    "Sample Step": "サンプル間隔",
    "Auto Simplify": "自動簡略化",
    "Bake Spring Dynamics": 'スプリングをベイク',
    "Radius Mode": "半径モード",
    "Speed Scale": "速度スケール",
    "Bake Limited Animation": "リミテッドアニメーションをベイク",
    "Create a safe duplicate of the active action and re-bake it on held steps such as twos or fours. This turns the stepped-preview idea into real editable keys while preserving the original action.": "アクティブアクションを安全に複製し、2 コマ打ちや 4 コマ打ちのような保持ステップで実キーとして焼き直します。元アクションを残したまま、段階プレビューの見た目を編集可能な実キーへ変換します。",
    "Bake Spring Dynamics": 'スプリングをベイク',
    "Bake a lightweight spring-follow pass onto the current curves. This is a practical superset of overlap, jiggle, drag, and soft follow-through helpers, writing the result back into editable keyframes.": "現在のカーブへ軽量なスプリング追従パスをベイクします。オーバーラップ、ジグル、ドラッグ、やわらかいフォロースルーをまとめた実用的な上位補助で、結果を編集可能なキーフレームへ書き戻します。",
})

try:
    TRANSLATIONS["ja_JP"].update({("*", en): ja for en, ja in JA_TRANSLATIONS.items()})
except Exception:
    pass


JA_TRANSLATIONS.update({
    "Clear Constraints After Bake": "ベイク後に制約解除",
    "After baking a live retarget preview into keys, automatically remove Smart Animation retarget constraints from the target rig.": "ライブリターゲットプレビューをキーへベイクした後、ターゲットリグから Smart Animation のリターゲット制約を自動的に削除します。",
    "Library Assign Mode": "ライブラリ割り当て方式",
    "Choose whether a library action is assigned as a linked original or as a duplicated editable copy.": "ライブラリアクションをリンクされた元データとして割り当てるか、編集用に複製したコピーとして割り当てるかを選びます。",
    "Copy": "コピー",
    "Assign a safe duplicated copy so edits do not affect the library source.": "編集してもライブラリ元データへ影響しない、安全な複製コピーとして割り当てます。",
    "Link": "リンク",
    "Assign the original action directly.": "元のアクションを直接割り当てます。",
    "Retarget Space": "リターゲット空間",
    "Choose whether live retarget preview constraints copy pose-space transforms or world-space transforms. Pose is usually better for similarly structured rigs, World is a fallback for unusual setups.": "ライブリターゲットプレビュー制約で、ポーズ空間変形をコピーするかワールド空間変形をコピーするかを選びます。似た構造のリグでは Pose が適しており、特殊なセットアップでは World が代替になります。",
    "Pose": "ポーズ",
    "Copy pose-space transforms for bone-to-bone preview.": "ボーン同士のプレビュー用にポーズ空間変形をコピーします。",
    "World": "ワールド",
    "Copy world-space transforms for bone-to-bone preview.": "ボーン同士のプレビュー用にワールド空間変形をコピーします。",
    "Shot Start": "ショット開始",
    "Start frame used by the camera-sequence builder. This is the first cut marker frame when generating a compact shot board from selected cameras.": "カメラシーケンス作成で使う開始フレームです。選択カメラからコンパクトなショットボードを作る際の最初のカットマーカーフレームになります。",
    "Shot Length": "ショット長",
    "Number of frames assigned to each camera when creating a camera-shot marker sequence.": "カメラショットマーカー列を作成する際に、各カメラへ割り当てるフレーム数です。",
    "Shot Gap": "ショットギャップ",
    "Number of empty frames inserted between generated camera shots. Use 0 for back-to-back cuts.": "生成されたカメラショット同士の間に挿入する空フレーム数です。連続カットにする場合は 0 を使います。",
    "Clear Older SAS Shots": "古い SAS ショットを整理",
    "Before building a new camera sequence, remove older Smart Animation shot markers so the generated shot board stays compact and predictable.": "新しいカメラシーケンスを作る前に、古い Smart Animation ショットマーカーを削除して、生成されるショットボードをコンパクトで予測しやすく保ちます。",
    "Preview Range from Shots": "ショットからプレビュー範囲設定",
    "After building a camera-shot sequence, set the scene preview range to the generated shot range.": "カメラショットシーケンスを作成した後、シーンのプレビュー範囲を生成されたショット範囲に設定します。",
    "Sequence Start": "シーケンス開始",
    "Start frame used when laying out motion-library actions sequentially into NLA clips.": "モーションライブラリアクションを順番に NLA クリップへ並べるときの開始フレームです。",
    "Sequence Gap": "シーケンスギャップ",
    "Frame gap inserted between motion-library clips when sequencing them into NLA.": "モーションライブラリクリップを NLA へ並べる際に、クリップ間へ挿入するフレームギャップです。",
    "Clear Older SAS Sequences": "古い SAS シーケンスを整理",
    "Before sequencing the library into NLA, remove older Smart Animation sequence tracks so the result stays readable.": "ライブラリを NLA へ並べる前に、古い Smart Animation シーケンストラックを削除して、結果を見やすく保ちます。",
    "Scale To Neighbors": "近傍基準で拡縮",
    "Scale selected keys, or the active timing range when no keys are selected, around the straight line formed by the surrounding anchor keys. 1.0 keeps the current shape, 0.0 flattens to the neighboring span, and values above 1 exaggerate the shape.": "選択キー、またはキー未選択時は現在のタイミング範囲を、外側アンカーキーで作られる直線を基準に拡大縮小します。1.0 は現在形状を維持し、0.0 は近傍スパンへ平坦化し、1 より大きい値は形状を誇張します。",
    "Fulcrum Threshold": "フルクラムしきい値",
    "Maximum frame-to-frame value change treated as planted motion by the automatic fulcrum cleanup. Lower values are stricter and safer.": "自動フルクラム整理で接地モーションとみなす、フレーム間値変化の最大量です。値が低いほど厳密で安全です。",
    "Minimum Hold": "最小保持",
    "Minimum number of consecutive frames that must stay under the fulcrum threshold before Smart Animation converts them into a planted hold.": "Smart Animation が接地ホールドへ変換する前に、フルクラムしきい値以下で維持される必要がある連続フレームの最小数です。",
    "Location Only": "位置のみ",
    "Limit automatic fulcrum cleanup to location-style curves. Keep this enabled for safer foot-lock and prop-contact cleanup.": "自動フルクラム整理を位置系カーブのみに限定します。足ロックや小物接触の整理を安全に行うには有効のまま使ってください。",
    "Reveal Distance": "リビール距離",
    "How far selected objects start away from their final position when creating a transform reveal.": "Transform Reveal 作成時に、選択オブジェクトが最終位置からどれだけ離れた位置から始まるかを決めます。",
    "Reveal Axis": "リビール軸",
    "Axis used by the transform reveal helper when offsetting selected objects before they animate back into place.": "選択オブジェクトを元位置へ戻す前にオフセットしておく際、Transform Reveal 補助が使う軸です。",
    "+X": "+X",
    "Offset reveals from the positive X axis.": "正の X 軸方向からリビールします。",
    "-X": "-X",
    "Offset reveals from the negative X axis.": "負の X 軸方向からリビールします。",
    "+Y": "+Y",
    "Offset reveals from the positive Y axis.": "正の Y 軸方向からリビールします。",
    "-Y": "-Y",
    "Offset reveals from the negative Y axis.": "負の Y 軸方向からリビールします。",
    "+Z": "+Z",
    "Offset reveals from the positive Z axis.": "正の Z 軸方向からリビールします。",
    "-Z": "-Z",
    "Offset reveals from the negative Z axis.": "負の Z 軸方向からリビールします。",
    "Reveal Stagger": "リビール段差",
    "Frame delay added between each selected object when building a transform reveal.": "Transform Reveal 作成時に、各選択オブジェクト間へ追加するフレーム遅延です。",
    "Reveal Duration": "リビール時間",
    "Number of frames each object takes to travel from its reveal offset back to its stored final position.": "各オブジェクトがリビール用オフセット位置から保存済み最終位置へ戻るまでにかけるフレーム数です。",
    "Reveal Order": "リビール順序",
    "How selected objects are ordered when creating a staggered transform reveal.": "段差付き Transform Reveal を作成する際に、選択オブジェクトをどの順序で並べるかを決めます。",
    "Selection": "選択順",
    "Use the current selected-object order.": "現在の選択オブジェクト順を使います。",
    "Sort selected objects by name before creating the reveal.": "リビール作成前に、選択オブジェクトを名前順で並べます。",
    "Sort selected objects by X location.": "選択オブジェクトを X 位置順で並べます。",
    "Sort selected objects by Y location.": "選択オブジェクトを Y 位置順で並べます。",
    "Sort selected objects by Z location.": "選択オブジェクトを Z 位置順で並べます。",
    "X": "X",
    "Y": "Y",
    "Z": "Z",
    "User-facing name shown in the selection-set list.": "選択セット一覧に表示されるユーザー向け名称です。",
    "Selection Set Index": "選択セットインデックス",
    "Optional stored selection-set index to apply directly from compact picker buttons. Leave at -1 to use the current list selection.": "コンパクトなピッカーボタンから直接適用するための任意の保存済み選択セット番号です。現在の一覧選択を使う場合は -1 のままにします。",
    "Auto": "オート",
    "Use Blender's automatic Bezier handles for smooth motion.": "滑らかな動きのために Blender の自動ベジェハンドルを使います。",
    "Auto Clamped": "オートクランプ",
    "Use clamped automatic handles to reduce overshoot.": "オーバーシュートを減らすため、クランプ付き自動ハンドルを使います。",
    "Vector": "ベクター",
    "Use straight vector handles for sharper directional changes.": "方向変化をより鋭くするため、直線ベクターハンドルを使います。",
    "Linear": "リニア",
    "Change interpolation to linear for even timing between keys.": "キー間のタイミングを均一にするため、補間をリニアに変更します。",
    "Bezier": "ベジェ",
    "Auto": "オート",
    "Speed": "速度",
    "Use the current scene frame as the timing pivot.": "現在のシーンフレームをタイミングピボットとして使います。",
    "Use the timing range start frame as the pivot.": "タイミング範囲の開始フレームをピボットとして使います。",
    "Use the center of the timing range as the pivot.": "タイミング範囲の中央をピボットとして使います。",
    "Use a custom frame number as the pivot.": "カスタムフレーム番号をピボットとして使います。",
    "Change interpolation to constant for blocking or stepped results.": "ブロッキングや段階的結果のため、補間をコンスタントに変更します。",
})


JA_TRANSLATIONS.update({
    "Stretch Axis": "ストレッチ軸",
    "Axis that receives the main stretch when Motion Stretch writes editable delta-scale keys. Match this to the visual long direction of the object.": "Motion Stretch が編集可能な delta scale キーを書き込む際に、主な伸びを与える軸です。オブジェクトの見た目上の長手方向に合わせてください。",
    "Stretch along the local X axis.": "ローカル X 軸方向へ伸ばします。",
    "Stretch along the local Y axis.": "ローカル Y 軸方向へ伸ばします。",
    "Stretch along the local Z axis.": "ローカル Z 軸方向へ伸ばします。",
    "Stretch Plane": "ストレッチ平面",
    "World-space movement plane sampled when Motion Stretch estimates speed. Use XY for ground motion, XZ or YZ for side views, and XYZ for full 3D movement.": "Motion Stretch が速度推定に使う、ワールド空間での移動平面です。地面移動なら XY、横向きなら XZ または YZ、完全な 3D 移動なら XYZ を使います。",
    "Use horizontal XY motion when estimating stretch speed.": "ストレッチ速度の推定に XY 平面移動を使います。",
    "Use XZ motion when estimating stretch speed.": "ストレッチ速度の推定に XZ 平面移動を使います。",
    "Use YZ motion when estimating stretch speed.": "ストレッチ速度の推定に YZ 平面移動を使います。",
    "Use full 3D motion when estimating stretch speed.": "ストレッチ速度の推定に完全な 3D 移動を使います。",
    "Stretch Strength": "ストレッチ強度",
    "How strongly sampled travel speed is converted into stretch length. Increase this for stronger smear-style exaggeration and reduce it for subtle polish.": "サンプリングした移動速度を、どれだけ伸び量へ変換するかを決めます。大きくするとスミア風の誇張が強くなり、小さくすると控えめな磨き込みになります。",
    "Squash": "スクワッシュ",
    "How much the two non-stretch axes compress while Motion Stretch elongates the chosen stretch axis. Lower values keep volume changes subtle and higher values create a more cartoon look.": "Motion Stretch が選択軸を伸ばす際に、他の 2 軸をどれだけ圧縮するかを決めます。低い値は体積変化を控えめにし、高い値はよりカートゥーン調になります。",
    "Max Stretch": "最大ストレッチ",
    "Maximum total stretch multiplier written by Motion Stretch. 1.0 disables extra stretch, 2.0 allows doubling the chosen axis, and larger values create more extreme smear.": "Motion Stretch が書き込む総合ストレッチ倍率の上限です。1.0 は追加の伸びなし、2.0 は選択軸を 2 倍まで許可し、さらに大きい値はより極端なスミアを作ります。",
    "Replace Older SAS Stretch": "古い SAS ストレッチを置換",
    "Before writing new Motion Stretch curves, clear older Smart Animation stretch curves on the same objects. Non-SAS delta-scale animation is never removed automatically.": "新しい Motion Stretch カーブを書き込む前に、同じオブジェクト上の古い Smart Animation ストレッチカーブを削除します。非 SAS の delta scale アニメーションは自動削除されません。",
    "Wheel Axis": "ホイール軸",
    "Rotation axis used when baking wheel spin. Match this to the local spin axis of the selected wheel objects.": "車輪回転をベイクするときに使う回転軸です。選択した車輪オブジェクトのローカル回転軸に合わせてください。",
    "Spin the wheels around the local X axis.": "ローカル X 軸まわりに車輪を回転させます。",
    "Spin the wheels around the local Y axis.": "ローカル Y 軸まわりに車輪を回転させます。",
    "Spin the wheels around the local Z axis.": "ローカル Z 軸まわりに車輪を回転させます。",
    "Motion Plane": "移動平面",
    "World-space plane sampled from the active source object's travel when calculating wheel distance. Use XY for top-down motion, XZ for most ground vehicles, and XYZ for unusual full-3D setups.": "車輪移動距離の計算時に、アクティブなソースオブジェクトの移動からサンプリングするワールド空間平面です。見下ろし移動なら XY、多くの地上車両は XZ、特殊な完全 3D セットアップは XYZ を使います。",
    "Use XY travel when accumulating wheel distance.": "車輪移動距離の累積に XY 平面移動を使います。",
    "Use XZ travel when accumulating wheel distance.": "車輪移動距離の累積に XZ 平面移動を使います。",
    "Use YZ travel when accumulating wheel distance.": "車輪移動距離の累積に YZ 平面移動を使います。",
    "Use full 3D travel when accumulating wheel distance.": "車輪移動距離の累積に完全な 3D 移動を使います。",
    "Radius Mode": "半径モード",
    "Choose whether wheel radius is estimated automatically from the selected wheel objects or forced to a single manual value.": "ホイール半径を選択した車輪オブジェクトから自動推定するか、単一の手動値へ固定するかを選びます。",
    "Estimate each wheel radius from its dimensions.": "各ホイールの寸法から半径を自動推定します。",
    "Manual": "手動",
    "Use the manual wheel radius value for every selected wheel.": "すべての選択ホイールに手動ホイール半径を使います。",
    "Manual Wheel Radius": "手動ホイール半径",
    "Manual wheel radius used when Radius Mode is set to Manual. This value is measured in scene units.": "Radius Mode が Manual のときに使うホイール半径です。この値はシーン単位で扱います。",
    "Spin Direction": "回転方向",
    "Base spin direction used by the wheel baker before any optional side flipping is applied.": "任意の左右反転が適用される前に、車輪ベイカーが使う基本の回転方向です。",
    "Forward": "前進",
    "Spin wheels in the forward direction.": "車輪を前進方向へ回転させます。",
    "Reverse": "反転",
    "Spin wheels in the opposite direction.": "車輪を逆方向へ回転させます。",
    "Auto Side Flip": "自動左右反転",
    "Automatically invert the spin sign on obvious right-side wheel names such as .R or Right. This helps mirrored wheel setups that use opposite local axis orientation.": " .R や Right など、明確に右側と分かるホイール名では自動的に回転符号を反転します。ローカル軸向きが左右で逆になるミラー車輪セットアップを補助します。",
    "Replace Older SAS Wheel Drive": "古い SAS ホイールドライブを置換",
    "Before writing new wheel-drive curves, clear older Smart Animation wheel curves on the same objects. Non-SAS delta-rotation animation is never removed automatically.": "新しいホイールドライブカーブを書き込む前に、同じオブジェクト上の古い Smart Animation 車輪カーブを削除します。非 SAS の delta rotation アニメーションは自動削除されません。",
    "Apply Motion Stretch": "モーションストレッチ適用",
    "Clear Motion Stretch": "モーションストレッチ解除",
    "Bake Vehicle Wheel Rotation": "車輪回転をベイク",
    "Clear Vehicle Wheel Rotation": "車輪回転を解除",
    "Motion Stretch": "モーションストレッチ",
    "Bake editable smear-like stretch onto delta scale from sampled object travel. Great for fast VFX sweeps, cartoony impacts, and broad action accents without touching the original transforms.": "サンプリングしたオブジェクト移動から、スミア風の伸びを delta scale に編集可能なキーとしてベイクします。元の変形を壊さず、VFX 的なスイープ、カートゥーン調のインパクト、広いアクションの強調に向いています。",
    "Plane": "平面",
    "Strength": "強さ",
    "Max": "最大",
    "Replace SAS": "SAS を置換",
    "Vehicle Wheel Drive": "車輪ドライブ",
    "Use the active object as the moving vehicle source and bake wheel spin on the other selected objects. This is the compact practical answer to Drive-style wheel helpers when you want editable keys fast.": "アクティブオブジェクトを移動する車体ソースとして使い、他の選択オブジェクトへ車輪回転をベイクします。素早く編集可能なキーが欲しいときに便利な、Drive 系車輪補助のコンパクトな実務解です。",
    "Radius": "半径",
    "Direction": "方向",
    "Manual Wheel Radius": "手動ホイール半径",
})


JA_TRANSLATIONS.update({
    "Tween Mode": "トゥイーンモード",
    "Choose how Tween computes the in-between. Linear matches classic tween tools, Ease softens the ends with a smoothstep curve, and Hermite uses surrounding keys to preserve motion flow for a smarter breakdown.": "Tween が中間値をどう計算するかを選びます。Linear は従来型トゥイーン、Ease は端をなめらかにし、Hermite は周囲キーの流れを保ってより賢いブレイクダウンを作ります。",
    "Ease": 'イーズ',
    "Hermite": 'エルミート',
    "Blend the previous and next keys directly. This matches classic tween tools.": "前キーと次キーを直接ブレンドします。従来型トゥイーンと同じ挙動です。",
    "Use a smoothstep ease between the neighboring keys for softer breakdowns near the ends.": "前後キーの間を smoothstep で補間し、端でやわらかいブレイクダウンを作ります。",
    "Use surrounding keys to preserve motion flow and create a smarter in-between.": "周囲キーも使って動きの流れを保ち、より賢い中間値を作ります。",
    "Ballistic Blend": "弾道ブレンド",
    "Blend between the original sampled motion and the predicted ballistic arc when baking ballistic keys. 0 keeps the original motion, 1 writes the full physics arc, and values in-between act like a lightweight AutoPhysics-style correction.": "弾道キーをベイクする際に、元のサンプル動作と予測弾道アークをブレンドします。0 は元動作を維持し、1 は完全な物理弾道を書き込み、中間値は軽量な AutoPhysics 風補正として働きます。",
    "Clear Existing Ballistic Range": "既存弾道範囲を消去",
    "Before baking ballistic keys, remove existing location keys inside the bake range on the source so the new arc stays clean and editable.": "弾道キーをベイクする前に、ソースのベイク範囲内にある既存の位置キーを削除し、新しいアークを整理された編集しやすい状態に保ちます。",
    "Bake Ballistic Keys": "弾道キーをベイク",
    "Deformer Reveal Mode": "デフォーマーリビールモード",
    "Choose whether Deformer Reveal uses a Build modifier or a Bend-based Roll setup. Build is simple and light, while Roll is better for scrolls, sheets, and rolled objects.": "Deformer Reveal で Build モディファイアを使うか、Bend ベースの Roll セットアップを使うかを選びます。Build は軽く単純で、Roll は巻物・シート・ロール状オブジェクト向きです。",
    "Build": "Build",
    "Use a Build modifier reveal. This is compact and light for many mesh objects.": "Build モディファイアによるリビールを使います。多くのメッシュに対して軽量でコンパクトです。",
    "Roll": "Roll",
    "Use a Bend-based roll reveal with editable angle keys. Useful for scrolls, paper, cloth cards, and rolled sheets.": "編集可能な角度キーを使う Bend ベースのロールリビールを使います。巻物、紙、布カード、ロールシートに便利です。",
    "Deformer Reveal Axis": "デフォーマーリビール軸",
    "Axis used by the Build or Roll reveal helper. For Roll, this is the bend axis; for Build, it is stored for consistent setup and future editing.": "Build または Roll リビール補助が使う軸です。Roll では曲げ軸、Build では一貫した設定と後編集のために保持されます。",
    "Roll Angle": "ロール角",
    "Starting bend angle used by Roll mode. Larger values create tighter initial rolls before the object opens out.": "Roll モードで使う開始曲げ角です。大きい値ほど、開く前の巻き始めが強くなります。",
    "Replace Existing SAS Deformer Reveal": "既存 SAS デフォーマーリビールを置換",
    "Before applying a new Deformer Reveal, remove older Smart Animation Build or Roll helpers on the same objects so the result stays predictable.": "新しい Deformer Reveal を適用する前に、同じオブジェクト上の古い Smart Animation Build / Roll 補助を削除して結果を予測しやすく保ちます。",
    "Apply Deformer Reveal": "デフォーマーリビール適用",
    "Clear Deformer Reveal": "デフォーマーリビール解除",
    "Deformer Reveal FX": "デフォーマーリビール FX",
    "Create modifier-based Build or Roll reveals for mesh objects. This gives Blender a compact answer to Transform, Scroll Roll, and Unfolder style reveal workflows without building a heavy rig.": "メッシュオブジェクトへモディファイアベースの Build / Roll リビールを作成します。重い専用リグを作らず、Transform / Scroll Roll / Unfolder 系のリビールワークフローへコンパクトに対応できます。",
    "Ballistic Keys Preview — source '{label}', frames {start}-{end}, {len(frames)} samples, blend {float(settings.ballistic_blend):.3f}, clear range {bool(settings.ballistic_clear_range)}.": '弾道キーのプレビュー：ソース「{label}」、フレーム {start}-{end}、サンプル {len(frames)}、ブレンド {float(settings.ballistic_blend):.3f}、範囲のクリア {bool(settings.ballistic_clear_range)}。',
})


JA_TRANSLATIONS.update({
    "Choose a modifier-based reveal workflow. Build creates sequential polygon reveals, while Roll adds a bend-driven scroll or roll style reveal.": "モディファイアベースのリビール方式を選びます。Build はポリゴンを順次表示し、Roll は Bend を使った巻物・ロール風リビールを作ります。",
    "Create a Build modifier reveal for sequential polygon appearance.": "Build モディファイアでポリゴンが順番に現れるリビールを作成します。",
    "Create a bend-driven scroll or roll style reveal.": "Bend を使った巻物・ロール風リビールを作成します。",
    "Axis used by the deformer reveal helper. For Roll mode, match this to the main roll axis of the selected mesh.": "デフォーマーリビール補助が使う軸です。Roll モードでは、選択メッシュの主な巻き軸に合わせてください。",
    "Use the X axis for the roll-based reveal.": "ロールベースのリビールに X 軸を使います。",
    "Use the Y axis for the roll-based reveal.": "ロールベースのリビールに Y 軸を使います。",
    "Use the Z axis for the roll-based reveal.": "ロールベースのリビールに Z 軸を使います。",
    "Total bend angle used by the Roll deformer reveal. 6.283 approximates one full revolution, while larger values create tighter rolls.": "Roll デフォーマーリビールで使う総曲げ角です。6.283 は約 1 回転に相当し、さらに大きい値はより強い巻きを作ります。",
    "Replace Older SAS Deformer Reveal": "古い SAS デフォーマーリビールを置換",
    "Before creating a new modifier-based reveal, remove older Smart Animation reveal modifiers and helper empties from the same objects.": "新しいモディファイアベースのリビールを作成する前に、同じオブジェクト上の古い Smart Animation リビールモディファイアと補助 Empty を削除します。",
    "Choose how Tween computes the in-between. Linear matches classic tween tools, Ease softens the ends with a smoothstep curve, and Hermite uses surrounding keys to preserve motion flow for a smarter breakdown.": "Tween が中間値をどう計算するかを選びます。Linear は従来型トゥイーン、Ease は端をなめらかにし、Hermite は周囲キーの流れを保ってより賢いブレイクダウンを作ります。",
    "Blend between the original sampled motion and the predicted ballistic arc when baking ballistic keys. 0 keeps the original motion, 1 writes the full physics arc, and values in-between act like a lightweight AutoPhysics-style correction.": "弾道キーをベイクする際に、元のサンプル動作と予測弾道アークをブレンドします。0 は元動作を維持し、1 は完全な物理弾道を書き込み、中間値は軽量な AutoPhysics 風補正として働きます。",
    "Before baking ballistic keys, remove existing location keys inside the bake range on the source so the new arc stays clean and editable.": "弾道キーをベイクする前に、ソースのベイク範囲内にある既存の位置キーを削除し、新しいアークを整理された編集しやすい状態に保ちます。",
})

JA_TRANSLATIONS.update({
    "Signal Mode": "シグナルモード",
    "Choose the procedural signal shape used by Motion Signal. Sine creates smooth looping motion, Noise creates organic drift, Pulse creates square-wave hits, and Step creates held stop-motion style motion.": "Motion Signal が使うプロシージャル信号の形を選びます。Sine は滑らかなループ、Noise は有機的な揺らぎ、Pulse は四角波のヒット、Step は保持付きのストップモーション風動きを作ります。",
    "Sine": "サイン",
    "Use a smooth sine wave for looping procedural motion.": "滑らかなサイン波でループするプロシージャル動きを作ります。",
    "Noise": "ノイズ",
    "Use layered pseudo-noise for organic wobble and drift.": "重ねた疑似ノイズで有機的な揺れや漂いを作ります。",
    "Pulse": "パルス",
    "Use a square-wave style pulse for snappy on/off motion.": "四角波風のパルスでオン/オフがはっきりした動きを作ります。",
    "Step": "ステップ",
    "Use held stop-motion style motion sampled on stepped frames.": "段階的にサンプルした保持付きのストップモーション風動きを使います。",
    "Signal Target": "シグナル対象",
    "Choose which delta-transform channel Motion Signal writes to. Delta channels keep the original animation intact and make the generated signal easy to clear.": "Motion Signal がどの delta 変換チャンネルへ書き込むかを選びます。delta チャンネルを使うことで元アニメーションを保ち、生成した信号を簡単に解除できます。",
    "Location": "位置",
    "Write the signal to delta location for offset motion.": '信号を差分の位置に書き込み、ずらす動きを作ります。',
    "Rotation": "回転",
    "Write the signal to delta rotation for oscillation or shake.": '信号を差分の回転に書き込み、揺れや振動を作ります。',
    "Scale": "スケール",
    "Write the signal to delta scale for pulsing or squash-and-stretch style motion.": "信号を delta scale に書き込み、脈動やスクワッシュ&ストレッチ風の動きを作ります。",
    "Signal Axes": "シグナル軸",
    "Axes affected by Motion Signal on the chosen delta channel.": "選択した delta チャンネル上で Motion Signal が影響する軸です。",
    "Affect the X axis only.": "X 軸だけに影響させます。",
    "Affect the Y axis only.": "Y 軸だけに影響させます。",
    "Affect the Z axis only.": "Z 軸だけに影響させます。",
    "Affect the X and Y axes.": "X と Y 軸に影響させます。",
    "Affect the X and Z axes.": "X と Z 軸に影響させます。",
    "Affect the Y and Z axes.": "Y と Z 軸に影響させます。",
    "Affect all three axes.": "3 軸すべてに影響させます。",
    "Signal Time Mode": "シグナル時間モード",
    "Choose whether Motion Signal interprets its rate as cycles per second or as beats per minute.": "Motion Signal の速度を、毎秒サイクル数として解釈するか、BPM として解釈するかを選びます。",
    "Frequency": "周波数",
    "Interpret the signal rate as cycles per second.": "信号速度を毎秒サイクル数として解釈します。",
    "Interpret the signal rate as beats per minute for music-synced timing.": "音楽同期タイミング用に、信号速度を BPM として解釈します。",
    "Signal Amplitude": "シグナル振幅",
    "Amplitude of the Motion Signal on the chosen delta channel. For location this is distance, for rotation this is radians, and for scale this acts as a multiplier around 1.0.": "選択した delta チャンネル上での Motion Signal の振幅です。位置では距離、回転ではラジアン、スケールでは 1.0 を中心とした倍率として働きます。",
    "Signal Frequency": "シグナル周波数",
    "Cycles per second used by Motion Signal when Signal Time Mode is set to Frequency.": '信号の時間モードが「周波数」の時に Motion Signal が使う、1 秒あたりの周期数です。',
    "Signal BPM": "シグナル BPM",
    "Beats per minute used by Motion Signal when Signal Time Mode is set to BPM.": "Signal Time Mode が BPM のときに Motion Signal が使う 1 分あたりの拍数です。",
    "Signal Phase": "シグナル位相",
    "Global cycle offset applied to Motion Signal before it is written as keys. Use this to line up the loop with a beat or pose accent.": "Motion Signal がキーとして書かれる前に適用される全体のサイクルオフセットです。ループを拍やポーズのアクセントに合わせるのに使います。",
    "Object Phase Offset": "オブジェクト位相オフセット",
    "Extra cycle offset added per selected object order. This creates delay-chain or MoGraph-style cascades from one object to the next.": "選択オブジェクト順ごとに追加されるサイクルオフセットです。オブジェクト間でディレイ連鎖や MoGraph 風カスケードを作れます。",
    "Signal Step Frames": '信号のステップのフレーム数',
    "Number of frames held by the Step signal mode before a new value is sampled. Higher values create a stronger stop-motion feel.": "Step シグナルモードで次の値をサンプルするまで保持するフレーム数です。大きい値ほどストップモーション感が強くなります。",
    "Signal Noise Seed": "シグナルノイズシード",
    "Seed offset used by the Motion Signal pseudo-noise generator. Change this when you want a different organic wobble pattern.": "Motion Signal の疑似ノイズ生成で使うシードオフセットです。別の有機的な揺れパターンが欲しいときに変更します。",
    "Signal Order": "シグナル順序",
    "How selected objects are ordered before Motion Signal applies the per-object phase offset.": "Motion Signal がオブジェクトごとの位相オフセットを適用する前に、選択オブジェクトをどの順序で並べるかを決めます。",
    "Sort selected objects by name before offsetting the signal.": "信号をずらす前に、選択オブジェクトを名前順で並べます。",
    "Sort selected objects by X location before offsetting the signal.": "信号をずらす前に、選択オブジェクトを X 位置順で並べます。",
    "Sort selected objects by Y location before offsetting the signal.": "信号をずらす前に、選択オブジェクトを Y 位置順で並べます。",
    "Sort selected objects by Z location before offsetting the signal.": "信号をずらす前に、選択オブジェクトを Z 位置順で並べます。",
    "Replace Older SAS Signal": "古い SAS シグナルを置換",
    "Before writing new Motion Signal curves, clear older Smart Animation signal curves on the same objects. Non-SAS delta animation is never removed automatically.": "新しい Motion Signal カーブを書き込む前に、同じオブジェクト上の古い Smart Animation シグナルカーブを削除します。非 SAS の delta アニメーションは自動削除されません。",
    "Apply Motion Signal": "モーションシグナル適用",
    "Clear Motion Signal": "モーションシグナル解除",
    "Motion Signal": "モーションシグナル",
    "Enable Steering": "ステアリングを有効",
    "Also bake path-following steering onto the chosen steering axis. Select only the steering wheels or steering controls when you want front-only steering.": "移動経路に追従するステアリングも、選択したステアリング軸へベイクします。前輪だけを曲げたい場合は、ステアリング対象のホイールまたは操舵コントロールだけを選択してください。",
    "Steering Axis": "ステアリング軸",
    "Rotation axis used for steering when Enable Steering is active.": "Enable Steering が有効なときに、ステアリングへ使う回転軸です。",
    "Use the X axis for steering.": "ステアリングに X 軸を使います。",
    "Use the Y axis for steering.": "ステアリングに Y 軸を使います。",
    "Use the Z axis for steering.": "ステアリングに Z 軸を使います。",
    "Max Steering": "最大ステアリング",
    "Maximum steering angle written by the vehicle helper. This clamps the path-based steering so the result stays art-directable.": "車両補助が書き込む最大ステアリング角です。経路ベースのステアリングを制限し、結果を演出しやすく保ちます。",
    "Reverse Steering": "ステアリング反転",
    "Invert the steering sign when the selected steering controls use the opposite local rotation direction.": "選択したステアリングコントロールが逆のローカル回転方向を使う場合に、ステアリング符号を反転します。",
    "Choose a modifier-based reveal workflow. Build creates sequential polygon reveals, Roll adds a bend-driven scroll or roll style reveal, and Unfold adds a lighter sheet-opening pass for cards or panels.": "モディファイアベースのリビール方式を選びます。Build はポリゴンを順次表示し、Roll は Bend を使った巻物・ロール風リビール、Unfold はカードやパネル向けの軽量な折り開き風パスを追加します。",
    "Unfold": "展開",
    "Create a bend-driven unfold reveal for sheet, card, and panel style assets.": "シート、カード、パネル系アセット向けに、Bend を使った展開リビールを作成します。",
})

JA_TRANSLATIONS.update({
    "Pose Snapshot Index": "ポーズスナップショット番号",
    "Optional stored pose-snapshot index to apply directly from compact picker buttons. Leave at -1 to use the current list selection.": "コンパクトなピッカーボタンから直接適用するときに使う、保存済みポーズスナップショット番号です。-1 のままなら現在の一覧選択を使います。",
    "Library Action Index": "ライブラリアクション番号",
    "Optional motion-library index to assign directly from compact picker buttons. Leave at -1 to use the current list selection.": "コンパクトなピッカーボタンから直接割り当てるときに使う、モーションライブラリ番号です。-1 のままなら現在の一覧選択を使います。",
    "Optional motion-library index to push directly from compact picker buttons. Leave at -1 to use the current list selection.": "コンパクトなピッカーボタンから直接 NLA へ積むときに使う、モーションライブラリ番号です。-1 のままなら現在の一覧選択を使います。",
    "Review Split Ratio": "レビュー分割比率",
    "Fraction used when splitting the current 3D View for camera review. Lower values keep a smaller camera side, while larger values make the split more even.": "カメラレビュー用に現在の 3D ビューを分割するときの比率です。小さい値はカメラ側を小さくし、大きい値はより均等な分割になります。",
    "Review Split Direction": "レビュー分割方向",
    "Choose whether the review split opens side-by-side or top-and-bottom.": "レビュー分割を左右に開くか、上下に開くかを選びます。",
    "Vertical": "縦分割",
    "Split the current 3D View left/right so one side can stay free and the other can show the scene camera.": "現在の 3D ビューを左右に分割し、片側を自由ビュー、もう片側をシーンカメラ表示にします。",
    "Horizontal": "横分割",
    "Split the current 3D View top/bottom so one side can stay free and the other can show the scene camera.": "現在の 3D ビューを上下に分割し、片側を自由ビュー、もう片側をシーンカメラ表示にします。",
    "Lock Camera Review": "カメラレビューを固定",
    "Lock the camera side of the split to the scene camera so orbiting in the free view does not disturb the shot-review side.": "分割したカメラ側をシーンカメラへ固定し、自由ビュー側で視点を回してもショット確認側が崩れないようにします。",
    "Physics Bake Clear Existing Range": "物理ベイク時に既存範囲を消去",
    "Before baking rigid-body motion, remove existing editable transform keys inside the bake range on the selected objects so the result stays clean and predictable.": "リジッドボディ動作をベイクする前に、選択オブジェクトのベイク範囲内にある既存の編集可能な変形キーを削除し、結果を整理された予測しやすい状態に保ちます。",
    "Create Camera Review Split": "カメラレビュー分割を作成",
    "Bake Rigid Body Keys": "リジッドボディキーをベイク",
})

JA_TRANSLATIONS.update({
    "Spring Magic Bake": "Spring Magic ベイク",
    "Bake Spring Magic": "Spring Magic をベイク",
    "Spring Magic Axis": "Spring Magic 軸",
    "Local chain axis used by Spring Magic. For Blender bones this is usually Y, while linked helper objects may use X depending on how their pivots are aligned.": "Spring Magic が使うローカルチェーン軸です。Blender のボーンでは通常 Y が安全で、リンクした補助オブジェクトではピボット配置に応じて X を使う場合があります。",
    "Use the positive local X axis as the chain direction. Useful for linked helper objects aligned to X.": "正のローカル X 軸をチェーン方向として使います。X 向きに整列したリンク補助オブジェクトに向いています。",
    "Use the negative local X axis as the chain direction.": "負のローカル X 軸をチェーン方向として使います。",
    "Use the positive local Y axis as the chain direction. This is the safest default for Blender pose bones.": "正のローカル Y 軸をチェーン方向として使います。Blender のポーズボーンではこれが最も安全な初期値です。",
    "Use the negative local Y axis as the chain direction.": "負のローカル Y 軸をチェーン方向として使います。",
    "Use the positive local Z axis as the chain direction.": "正のローカル Z 軸をチェーン方向として使います。",
    "Use the negative local Z axis as the chain direction.": "負のローカル Z 軸をチェーン方向として使います。",
    "Spring Magic Mode": "Spring Magic モード",
    "Choose how much of the Spring Magic style result is baked. Swing rotates the chain only, Swing + Twist adds springy roll around the chain axis, and Swing + Twist + Scale also writes squash-and-stretch style scale.": "Spring Magic 風結果のどこまでをベイクするか選びます。Swing はチェーン回転のみ、Swing + Twist はチェーン軸まわりのバネ的ロールを追加し、Swing + Twist + Scale はさらにスクワッシュ＆ストレッチ風スケールも書き込みます。",
    "Swing": "スイング",
    "Bake swing and follow-through rotation only.": "スイングとフォロースルー回転だけをベイクします。",
    "Swing + Twist": "スイング + ツイスト",
    "Bake swing plus delayed twist around the chosen chain axis.": "スイングに加えて、選択したチェーン軸まわりの遅延ツイストをベイクします。",
    "Swing + Twist + Scale": "スイング + ツイスト + スケール",
    "Bake swing, twist, and squash-and-stretch style scale for a fuller Spring Magic style pass.": "より完成度の高い Spring Magic 風パスとして、スイング、ツイスト、スクワッシュ＆ストレッチ風スケールをベイクします。",
    "Spring Magic Twist": "Spring Magic ツイスト",
    "How strongly Spring Magic delays twist around the chosen chain axis. Higher values exaggerate corkscrew style follow-through.": "選択したチェーン軸まわりのツイストを Spring Magic がどれだけ遅延させるかです。大きい値ほどコルクスクリュー風のフォロースルーが強くなります。",
    "Spring Magic Scale": "Spring Magic スケール",
    "How strongly Spring Magic adds squash-and-stretch from the spring lag amount. 0 disables scale exaggeration even in the Scale mode.": "スプリング遅れ量から Spring Magic がどれだけスクワッシュ＆ストレッチを加えるかです。0 にすると Scale モードでもスケール誇張を無効化します。",
    "Spring Magic Scale Max": "Spring Magic 最大スケール",
    "Maximum stretch multiplier written by Spring Magic when scale mode is active. Lower values are safer, higher values create broader cartoony deformation.": "Scale モード有効時に Spring Magic が書き込む最大伸長倍率です。小さい値は安全寄り、大きい値はより広いカートゥーン変形になります。",
    "Spring Magic Clear Range": "Spring Magic 範囲消去",
    "Before baking Spring Magic, remove existing editable rotation and scale keys for the targeted channels inside the bake range so the result stays predictable.": "Spring Magic をベイクする前に、対象チャンネルのベイク範囲内にある既存の編集可能な回転・スケールキーを削除し、結果を予測しやすく保ちます。",
    "Spring Magic Collision": "Spring Magic 衝突",
    "Choose whether Spring Magic uses no collision, a simple global floor plane, a collider collection, or both together.": "Spring Magic で衝突を使わないか、単純なグローバル床面を使うか、コライダーコレクションを使うか、その両方を使うかを選びます。",
    "None": "なし",
    "Do not apply collision during Spring Magic baking.": "Spring Magic ベイク中に衝突を適用しません。",
    "Floor": "床",
    "Use a simple world-space floor plane for collision.": "単純なワールド空間の床平面を衝突に使います。",
    "Collection": "コレクション",
    "Use mesh objects from the chosen collection as Spring Magic colliders.": "選択したコレクション内のメッシュ系オブジェクトを Spring Magic のコライダーとして使います。",
    "Floor + Collection": "床 + コレクション",
    "Use both the floor plane and the collider collection together.": "床平面とコライダーコレクションの両方を一緒に使います。",
    "Spring Magic Collider Collection": "Spring Magic コライダーコレクション",
    "Collection whose mesh-like objects are treated as Spring Magic collision surfaces. This is useful for floors, walls, torsos, helmets, or any simple collision blockers.": "メッシュ系オブジェクトを Spring Magic の衝突面として扱うコレクションです。床、壁、胴体、ヘルメット、その他の簡易的な衝突ブロッカーに使えます。",
    "Spring Magic Collision Radius": "Spring Magic 衝突半径",
    "Sphere radius used around each simulated Spring Magic tip when testing collisions. Increase this to keep tails, ears, straps, or linked helpers farther away from colliders.": "衝突判定時に各 Spring Magic シミュレーション先端の周囲へ使う球半径です。大きくすると、尻尾、耳、ストラップ、リンク補助をコライダーからより離せます。",
    "Spring Magic Collision Margin": "Spring Magic 衝突余白",
    "Extra collision padding added on top of the collision radius when Spring Magic pushes simulated tips away from colliders.": "Spring Magic がシミュレーション先端をコライダーから押し戻すときに、衝突半径へ追加する余白です。",
    "Spring Magic Floor Height": "Spring Magic 床高さ",
    "World-space Z height used by the simple Spring Magic floor collider. Use 0 for a standard ground plane, or raise/lower it to match your scene.": "単純な Spring Magic 床コライダーに使うワールド空間 Z 高さです。標準の地面なら 0、シーンに合わせて上下させて使います。",
    "Spring Magic Substeps": "Spring Magic サブステップ",
    "Internal substeps used inside each baked Spring Magic sample. Higher values improve stability, reduce tunneling, and make collision and fast motion more accurate, but they also increase bake time.": "各ベイクサンプルの内部で使う Spring Magic のサブステップ数です。値を上げると安定性が増し、すり抜けが減り、衝突や高速動作の精度が上がりますが、ベイク時間も長くなります。",
    "Spring Magic Collision Iterations": "Spring Magic 衝突反復",
    "How many push-out passes Spring Magic performs after each simulation substep. Higher values help tips settle more reliably against colliders with less clipping, especially around corners or thin blockers.": "各シミュレーションサブステップ後に Spring Magic が行う押し戻し反復回数です。値を上げると角や薄いブロッカーでも先端がより安定して収まり、めり込みが減ります。",
    "Spring Magic Use Collider Object": "Spring Magic コライダーオブジェクト使用",
    "Also treat one explicitly chosen object as a Spring Magic collider. This is useful when you want a single torso, helmet, wall, or proxy object to collide without building a dedicated collection first.": "明示的に選んだ 1 つのオブジェクトも Spring Magic のコライダーとして扱います。専用コレクションを作らずに、胴体、ヘルメット、壁、プロキシなど 1 つの当たり対象だけを使いたいときに便利です。",
    "Spring Magic Collider Object": "Spring Magic コライダーオブジェクト",
    "Explicit object used as an extra Spring Magic collider. Mesh-like objects use their evaluated surface, while other objects fall back to a bounds-based blocker so ordinary scene objects can still act as colliders.": "追加の Spring Magic コライダーとして使う明示指定オブジェクトです。メッシュ系オブジェクトは評価後の表面を使い、それ以外のオブジェクトは境界ベースのブロッカーへフォールバックするため、通常のシーンオブジェクトもコライダーとして使えます。",
    "Collider Collection": "コライダーコレクション",
    "Floor Height": "床高さ",
    "Clear Range": "範囲消去",
    "Scale Max": "最大スケール",
    "Bake Spring Magic style secondary motion on selected object or pose-bone chains, with optional twist, squash-stretch, finer internal substeps, and collision support against floor, collection, and explicit object colliders. This is designed as a Blender-friendly answer to Spring Magic style quick secondary animation for linked objects and bones.": "選択したオブジェクトまたはポーズボーンのチェーンへ、ツイスト・スクワッシュストレッチ・より細かい内部サブステップ・床/コレクション/明示オブジェクトコライダー対応を含む Spring Magic 風セカンダリモーションをベイクします。リンクオブジェクトやボーンへ素早く二次モーションを付ける Spring Magic 系ワークフローを、Blender 向けに扱いやすくした機能です。",
    "Bake Spring Magic style secondary motion for selected object or pose-bone chains. It supports swing, twist, optional squash-and-stretch, finer internal substeps, and collision against a floor plane, collider collection, or explicit collider object.": "選択したオブジェクトまたはポーズボーンのチェーンへ、Spring Magic 風の二次モーションをベイクします。スイング、ツイスト、必要に応じたスクワッシュ＆ストレッチ、より細かい内部サブステップ、床面・コライダーコレクション・明示指定したコライダーオブジェクトへの衝突に対応します。",
    "Pose Mode bakes selected bone chains. Object Mode bakes linked helper-object chains. Use +Y for Blender bones unless your controls are aligned differently. Raise Substeps and Iterations when you need tighter collision and less clipping.": "Pose モードでは選択ボーンチェーン、Object モードではリンクされた補助オブジェクトチェーンをベイクします。Blender ボーンは特別な向きでない限り +Y を使うのが安全です。衝突精度やめり込みをさらに抑えたい場合は、サブステップと反復回数を上げてください。",
    "Substeps": "サブステップ",
    "Iterations": "反復",
    "Use Object": "オブジェクト使用",
    "Collider Object": "コライダーオブジェクト",
})


JA_TRANSLATIONS.update({
    'Add Animation Layer': 'アニメーションレイヤー追加',
    'Add Camera Marker': 'カメラマーカー追加',
    'Add Current Action to Library': '現在のアクションをライブラリへ追加',
    'Add Marker': 'マーカー追加',
    'Add a camera marker from the active or scene camera.': 'アクティブカメラまたはシーンカメラからカメラマーカーを追加します。',
    'Add a named marker on the current frame.': '現在フレームに名前付きマーカーを追加します。',
    'Add markers on the selected keyframes.': '選択中キーフレームにマーカーを追加します。',
    'All': '全て',
    'All Camera Marks': '全カメラマーカー',
    'Animate': 'アニメート',
    'Apply Camera Shake Preset': 'カメラシェイクプリセット適用',
    'Apply Contact Hold': 'コンタクトホールド適用',
    'Apply Current Map': '現在のマップを適用',
    'Apply Live Retarget': 'ライブリターゲット適用',
    'Apply Loop Preset': 'ループプリセット適用',
    'Apply Noise Modifier': 'ノイズモディファイア適用',
    'Apply Playback Preset': '再生プリセット適用',
    'Apply Pose Snapshot': 'ポーズスナップショット適用',
    'Apply Selection Set': '選択セット適用',
    'Apply Stepped Preview': 'ステッププレビュー適用',
    'Apply Tangent Preset': 'タンジェントプリセット適用',
    'Apply Tween': 'トゥイーン適用',
    'Apply a camera shake preset.': 'カメラシェイクプリセットを適用します。',
    'Apply a cycles-based loop preset.': 'Cycles ベースのループプリセットを適用します。',
    'Apply a lightweight overlap pass to selected keys.': '選択キーに軽量なオーバーラップ処理を適用します。',
    'Apply a procedural noise modifier.': 'プロシージャルノイズモディファイアを適用します。',
    'Apply blocking-friendly playback settings.': 'ブロッキング向けの再生設定を適用します。',
    'Apply lip-sync-friendly playback settings.': 'リップシンク向けの再生設定を適用します。',
    'Apply review-friendly playback settings.': 'レビュー向けの再生設定を適用します。',
    'Apply the current bone map without rebuilding it first.': '対応表を再構築せず、現在のボーンマップをそのまま適用します。',
    'Apply the selected tangent or interpolation preset.': '選択したタンジェントまたは補間プリセットを適用します。',
    'Assets': 'アセット',
    'Assign Library Action': 'ライブラリアクション割り当て',
    'Audit': '監査',
    'Auto Fix': '自動修復',
    'Auto Fulcrum': '自動フルクラム',
    'Auto Fulcrum Cleanup': '自動フルクラム整理',
    'Auto-clean planted contacts and fulcrum-style holds.': '接地コンタクトや支点保持を自動整理します。',
    'BPM': 'BPM',
    'Bake Live Retarget': 'ライブリターゲットをベイク',
    'Bake Preview': 'プレビューをベイク',
    'Bake Step Keys': 'ステップキーをベイク',
    'Bake Visual Keys': 'ビジュアルキーをベイク',
    'Bake Visual Range': 'ビジュアル範囲ベイク',
    'Bake a ballistic correction back into keys.': '弾道補正をキーへベイクし戻します。',
    'Bake higher-precision chain secondary motion with optional collision.': '必要に応じて衝突も使いながら、高精度なチェーン二次モーションをベイクします。',
    'Bake overlap, drag, and jiggle into editable curves.': 'オーバーラップ、ドラッグ、ジグルを編集可能なカーブへベイクします。',
    'Bake rigid-body transforms back into editable keys.': 'リジッドボディ変形を編集可能なキーへベイクし戻します。',
    'Bake smear-like delta scale from motion travel.': '移動量からスミア風の delta スケールをベイクします。',
    'Bake the current live retarget preview into regular keys.': '現在のライブリターゲットプレビューを通常キーへベイクします。',
    'Bake the current selection to editable visual keys across the chosen frame range.': '選択したフレーム範囲で現在の選択を編集可能なビジュアルキーへベイクします。',
    'Bake wheel spin and optional steering from a moving vehicle source.': '移動する車体ソースから車輪回転と必要に応じた操舵をベイクします。',
    'Ballistic Bake': '弾道ベイク',
    'Ballistic Guide': '弾道ガイド',
    'Blend Pose Snapshot': 'ポーズスナップショットをブレンド',
    'Block Smart Animation Header Clicks': 'Smart Animation コンテキストヘッダーのクリックを遮断',
    'Blocking': 'ブロッキング',
    'Blocking-friendly playback and keying settings': 'ブロッキング向けの再生 / キー設定',
    'Break left and right handles for a sharp discontinuity-style change.': '左右ハンドルを分離し、急な変化を作りやすくします。',
    'Build Bone Map': 'ボーンマップ作成',
    'Build Camera Sequence': 'カメラシーケンス作成',
    'Build Layer Stack': 'レイヤースタック作成',
    'Build a modifier-based reveal or unfold effect.': 'モディファイアベースのリビールまたは展開エフェクトを作成します。',
    'Build a name-based source-to-target preview mapping.': '名前ベースのソースからターゲットへのプレビュー対応表を作成します。',
    'Build evenly spaced camera cut markers from selected cameras.': '選択カメラから等間隔のカットマーカーを作成します。',
    'Calculate Motion Paths': 'モーションパス計算',
    'Calculate motion paths.': 'モーションパスを計算します。',
    'Camera Marker Direction': 'カメラマーカー方向',
    'Camera Range Mode': 'カメラ範囲モード',
    'Camera Sequence': 'カメラシーケンス',
    'Camera Shake': 'カメラシェイク',
    'Change interpolation to constant.': '補間をコンスタントに変更します。',
    'Change interpolation to linear.': '補間をリニアに変更します。',
    'Choose a combined timeline or review action from the compact animation hub.': 'コンパクトアニメーションハブで使うタイムライン / レビュー操作を選びます。',
    'Choose a ready-made playback setup for blocking, review, or lip-sync passes so the timeline behaves the way that task needs.': 'ブロッキング、レビュー、リップシンク用に用意された再生設定を選び、その作業に合うタイムライン動作へ切り替えます。',
    'Choose the asset or retarget import/export task used by the compact data hub.': 'コンパクトデータハブで使うアセット / リターゲット入出力タスクを選びます。',
    'Choose the cleanup or curve-fix task used by the compact cleanup hub.': 'コンパクト整理ハブで使う整理 / カーブ修正タスクを選びます。',
    'Choose the one-click diagnostic or reporting action used by the compact overview hub.': 'コンパクト概要ハブで使うワンクリック診断 / レポート処理を選びます。',
    'Choose the retarget or root-motion action used by the compact transfer hub.': 'コンパクト転送ハブで使うリターゲット / ルートモーション操作を選びます。',
    'Choose the secondary-motion, helper, or baked-FX task used by the compact FX hub.': 'コンパクト FX ハブで使う二次モーション / 補助 / ベイク FX タスクを選びます。',
    'Choose the timing or spacing tool used by the compact timing hub.': 'コンパクトタイミングハブで使うタイミング / スペーシングツールを選びます。',
    'Choose whether Jump Camera Marker moves backward or forward through camera-bound cut markers.': 'Jump Camera Marker がカメラ付きカットマーカーを前後どちらに移動するか選びます。',
    'Choose whether Jump Marker moves backward or forward through the timeline-marker list.': 'Jump Marker がタイムラインマーカー一覧を前方向へ進むか後方向へ戻るかを選びます。',
    'Choose whether Shot Range isolates the current shot only or spans every camera marker in the scene.': 'Shot Range で現在のショットだけを対象にするか、シーン内の全カメラマーカー範囲を対象にするかを選びます。',
    'Choose whether to key every non-Basis shape key or only the active one on the current frame.': 'Basis 以外の全シェイプキーにキーを打つか、現在アクティブなものだけに打つかを選びます。',
    'Choose which tangent or interpolation preset is applied to the targeted keys.': '対象キーへ適用するタンジェントまたは補間プリセットを選びます。',
    'Choose which transform channels are keyed by Insert Keys. Use Visual when constraints or parenting mean you want the evaluated pose baked instead of raw local values.': 'Insert Keys でどの変形チャンネルにキーを打つか選びます。コンストレイントや親子付けの結果をそのまま焼き込みたい場合は、ローカル値ではなく評価後の見た目を使う Visual を選びます。',
    'Cleanup Mode': '整理モード',
    'Clear Ballistic Guides': '弾道ガイド解除',
    'Clear Ballistics': '弾道解除',
    'Clear Camera Shake': 'カメラシェイク解除',
    'Clear Dynamic Parent': '動的な親を解除',
    'Clear Existing': '既存をクリア',
    'Clear Ghost Preview': 'ゴーストプレビュー解除',
    'Clear Ghosts': 'ゴースト解除',
    'Clear Log': 'ログを消去',
    'Clear Loop': 'ループ解除',
    'Clear Loop Preset': 'ループプリセット解除',
    'Clear Motion Paths': 'モーションパス解除',
    'Clear Noise': 'ノイズ解除',
    'Clear Noise Modifier': 'ノイズモディファイア解除',
    'Clear Operation Log': '操作ログを消去',
    'Clear Paths': 'パス解除',
    'Clear Preview': 'プレビュー解除',
    'Clear Preview Range': 'プレビュー範囲解除',
    'Clear Shake': 'シェイク解除',
    'Clear Smart Animation dynamic parenting.': 'Smart Animation のダイナミック親子付けを解除します。',
    'Clear Step Preview': 'ステッププレビュー解除',
    'Clear Stepped Preview': 'ステッププレビュー解除',
    'Clear Trail Curves': 'トレイルカーブ解除',
    'Clear Trails': 'トレイル解除',
    'Clear motion paths.': 'モーションパスを解除します。',
    'Clear the compact operation log.': 'コンパクト操作ログを消去します。',
    'Clear the preview range.': 'プレビュー範囲を解除します。',
    'Compact Smart Animation workspace shown in the Sidebar N-panel.': 'サイドバーNパネル内に表示されるコンパクトな Smart Animation ワークスペースです。',
    'Compact Workspace': 'コンパクトワークスペース',
    'Contact Hold': 'コンタクトホールド',
    'Copy Global': 'グローバルコピー',
    'Copy Global Transform': 'グローバル変形をコピー',
    'Copy the current global transform.': '現在のグローバル変形をコピーします。',
    'Create Ballistic Guide': '弾道ガイド作成',
    'Create Ghost Preview': 'ゴーストプレビュー作成',
    'Create In Place': 'インプレース作成',
    'Create Trail Curve': 'トレイルカーブ作成',
    'Create a new action on the active object.': 'アクティブオブジェクトに新しいアクションを作成します。',
    'Create a root-motion helper action.': 'ルートモーション補助アクションを作成します。',
    'Create a staggered transform-based reveal on selected objects.': '選択オブジェクトに段階的な Transform ベースのリビールを作成します。',
    'Create a stepped preview pass for blocking review.': 'ブロッキング確認用のステッププレビューを作成します。',
    'Create an editable on-twos / on-fours style duplicate action.': '2コマ打ち / 4コマ打ち風の編集可能な複製アクションを作成します。',
    'Create an in-place version of the current action.': '現在のアクションのインプレース版を作成します。',
    'Create or refresh an in-between on the current frame.': '現在フレームに中割りを作成または更新します。',
    'Current Shot': '現在ショット',
    'Daily timeline, timing, cleanup, and motion-FX tools.': '日常的なタイムライン操作、タイミング調整、整理、モーション FX をまとめたツールです。',
    'Data Mode': 'データモード',
    'Deformer Reveal': 'デフォーマーリビール',
    'Delay the selected objects or controls in sequence.': '選択オブジェクトまたはコントロールを順番に遅らせます。',
    'Delete Static': '静的チャンネル削除',
    'Delete Static Channels': '静的チャンネル削除',
    'Delete static channels with no meaningful change.': '意味のある変化がない静的チャンネルを削除します。',
    'Diagnostics Mode': '診断モード',
    'Distribute the affected keys evenly.': '対象キーを等間隔に並べます。',
    'Dual View Review': 'デュアルビュー確認',
    'Duplicate Action': 'アクションを複製',
    'Duplicate the current action for safe variation work.': '現在のアクションを複製し、安全にバリエーション作業を行えるようにします。',
    'Dynamic Parent': 'ダイナミック親子付け',
    'Estimate what the cleanup tools would change.': '整理ツールが何を変更するか見積もります。',
    'Euler Filter': 'オイラーフィルター',
    'Even Key Timing': 'キータイミングを均等化',
    'Even Timing': '等間隔タイミング',
    'Export Bone Map': 'ボーンマップを書き出し',
    'Export Library': 'ライブラリを書き出し',
    'Export Library Manifest': 'ライブラリマニフェスト書き出し',
    'Export Poses': 'ポーズを書き出し',
    'Export Report': 'レポート書き出し',
    'Export Selections': '選択セットを書き出し',
    'Export pose snapshots to Blender text data and the clipboard.': 'ポーズスナップショットを Blender テキストデータとクリップボードへ書き出します。',
    'Export selection sets to Blender text data and the clipboard.': '選択セットを Blender テキストデータとクリップボードへ書き出します。',
    'Export the motion library manifest.': 'モーションライブラリのマニフェストを書き出します。',
    'Export the retarget bone map.': 'リターゲット用ボーンマップを書き出します。',
    'Extract Root Motion': 'ルートモーション抽出',
    'FX Mode': 'FX モード',
    'Fix Euler flips in rotation curves.': '回転カーブのオイラーフリップを修正します。',
    'Flatten curves across a hold range from the current value.': '現在値を基準にホールド範囲のカーブを平坦化します。',
    'Flatten selected or all key handles horizontally.': '選択キーまたは全キーのハンドルを水平に平坦化します。',
    'Generate a ballistic guide arc.': '弾道ガイドの軌道を生成します。',
    'Generate a sampled trail curve.': 'サンプリングしたトレイルカーブを生成します。',
    'Generate editable signal-based delta motion.': '編集可能な信号ベースの delta モーションを生成します。',
    'Generate past and future ghost preview copies.': '過去と未来のゴーストプレビューコピーを生成します。',
    'Ghost Preview': 'ゴーストプレビュー',
    'Import Bone Map': 'ボーンマップを読み込み',
    'Import Library': 'ライブラリを読み込み',
    'Import Poses': 'ポーズを読み込み',
    'Import Selections': '選択セットを読み込み',
    'Import pose snapshots from Blender text data.': 'Blender テキストデータからポーズスナップショットを読み込みます。',
    'Import selection sets from Blender text data.': 'Blender テキストデータから選択セットを読み込みます。',
    'Import the motion library manifest.': 'モーションライブラリのマニフェストを読み込みます。',
    'Import the retarget bone map.': 'リターゲット用ボーンマップを読み込みます。',
    'Insert All Keys': '全キーを挿入',
    'Insert Key Mode': 'キー挿入モード',
    'Insert Keys': 'キーを挿入',
    'Insert Location Keys': '位置キーを挿入',
    'Insert Rotation Keys': '回転キーを挿入',
    'Insert Scale Keys': 'スケールキーを挿入',
    'Insert Shape Keys': 'シェイプキーを挿入',
    'Insert Visual Keys': 'ビジュアルキーを挿入',
    'Insert a key on the active shape key only.': 'アクティブなシェイプキーだけにキーを挿入します。',
    'Insert keys on all available shape keys.': '利用可能な全シェイプキーにキーを挿入します。',
    'Insert location keys only.': '位置キーだけを挿入します。',
    'Insert location, rotation, and scale keys on the current frame.': '現在フレームに位置・回転・スケールキーを挿入します。',
    'Insert location, rotation, and scale keys.': '位置・回転・スケールキーを挿入します。',
    'Insert only location keys on the current frame.': '現在フレームに位置キーだけを挿入します。',
    'Insert only rotation keys on the current frame.': '現在フレームに回転キーだけを挿入します。',
    'Insert only scale keys on the current frame.': '現在フレームにスケールキーだけを挿入します。',
    'Insert rotation keys only.': '回転キーだけを挿入します。',
    'Insert scale keys only.': 'スケールキーだけを挿入します。',
    'Insert visually evaluated location, rotation, and scale keys.': '見た目評価後の位置・回転・スケールキーを挿入します。',
    'Insert visually evaluated transform keys on the current frame.': '現在フレームに見た目評価後の変形キーを挿入します。',
    'Jump Camera Marker': 'カメラマーカー移動',
    'Jump Marker': 'マーカー移動',
    'Jump Next Camera Marker': '次のカメラマーカーへ移動',
    'Jump Next Marker': '次のマーカーへ移動',
    'Jump Prev Camera Marker': '前のカメラマーカーへ移動',
    'Jump Prev Marker': '前のマーカーへ移動',
    'Jump to the most relevant compact workspace for the current context.': '現在の状況に最も合うコンパクトワークスペースへ移動します。',
    'Jump to the next camera marker.': '次のカメラマーカーへ移動します。',
    'Jump to the next camera-bound marker.': '次のカメラ付きマーカーへ移動します。',
    'Jump to the next marker.': '次のマーカーへ移動します。',
    'Jump to the next timeline marker.': '次のタイムラインマーカーへ移動します。',
    'Jump to the previous camera marker.': '前のカメラマーカーへ移動します。',
    'Jump to the previous camera-bound marker.': '前のカメラ付きマーカーへ移動します。',
    'Jump to the previous marker.': '前のマーカーへ移動します。',
    'Jump to the previous timeline marker.': '前のタイムラインマーカーへ移動します。',
    'Limited Bake': 'リミテッドベイク',
    'Lip Sync': 'リップシンク',
    'Loop Helper': 'ループ補助',
    'Marker Direction': 'マーカー方向',
    'Mirror Pose': 'ポーズをミラー',
    'Motion Paths': 'モーションパス',
    'New Action': '新規アクション',
    'Next': '次',
    'No Smart Animation installed': 'Smart Animation がインストールされていません',
    'Noise Modifier': 'ノイズモディファイア',
    'Offset keys forward or backward in time.': 'キーを時間方向に前後へ移動します。',
    'Open Smart Animation controls in the Sidebar N-panel.': 'サイドバーNパネル内に Smart Animation の操作画面を表示します。',
    'Open a Smart Animation add-on page in the N-panel': 'Smart Animation Nパネル内で各 Smart Animation アドオンのページを開きます。',
    'Open the Smart Animation settings in the N-panel': 'Nパネル内のSmart Animation設定を開きます。',
    'Optimize Shape Key Curves': 'シェイプキーカーブ最適化',
    'Optimize shape-key curves.': 'シェイプキーカーブを最適化します。',
    'Optional hold length used by quick stepped-preview buttons. Leave at 0 to use the main Stepped Preview setting instead.': 'クイックステッププレビュー用ボタンで使う任意の保持フレーム数です。0 のままならメインの Stepped Preview 設定を使います。',
    'Overview': '概要',
    'Paste Global': 'グローバル貼り付け',
    'Paste Global Transform': 'グローバル変形を貼り付け',
    'Paste the copied global transform.': 'コピーしたグローバル変形を貼り付けます。',
    'Physics Bake': '物理ベイク',
    'Playback Preset': '再生プリセット',
    'Playback settings tuned for lip-sync review': 'リップシンク確認向けに調整した再生設定',
    'Playback: Blocking': '再生: ブロッキング',
    'Playback: Lip Sync': '再生: リップシンク',
    'Playback: Review': '再生: レビュー',
    'Preview Cleanup': '整理プレビュー',
    'Preview Range from Keys': 'キーからプレビュー範囲設定',
    'Preview from All Shots': '全ショットからプレビュー範囲設定',
    'Preview from Current Shot': '現在ショットからプレビュー範囲設定',
    'Preview from Keys': 'キーからプレビュー範囲設定',
    'Preview from Sound': 'サウンドからプレビュー範囲設定',
    'Previous': '前',
    'Internal record of the task suggested by Smart Assist. To change what the N-panel shows, use the Task selector in Overview Task.': 'スマートアシストが勧めたタスクの内部記録です。Nパネルの表示を切り替えるには「概要タスク」の「タスク」を使います。',
    'Prune Library': 'ライブラリ整理',
    'Push / Pull Keys': 'キーをプッシュ / プル',
    'Push Action to NLA': 'アクションを NLA へ送る',
    'Push Library Action to NLA': 'ライブラリアクションを NLA へ送る',
    'Push Pull': 'プッシュ / プル',
    'Push or pull keyed values away from their current pose.': 'キーフレーム値を現在のポーズから押し出す / 引き寄せます。',
    'Randomize Key Timing': 'キータイミングをランダム化',
    'Randomize Timing': 'タイミングをランダム化',
    'Randomize key timing inside the configured range.': '設定範囲内のキータイミングをランダム化します。',
    'Rebuild + Live': '再構築 + ライブ',
    'Rebuild the mapping and apply a live retarget preview.': '対応表を再構築し、ライブリターゲットプレビューを適用します。',
    'Reduce dense baked animation into lighter editable keys.': '密にベイクされたアニメーションを、より軽い編集可能キーへ整理します。',
    'Refresh Live Retarget': 'ライブリターゲット更新',
    'Refresh Preview': 'プレビュー更新',
    'Refresh the current live retarget preview.': '現在のライブリターゲットプレビューを更新します。',
    'Remove Action from Library': 'アクションをライブラリから削除',
    'Remove Duplicate Keys': '重複キー削除',
    'Remove Duplicates': '重複を削除',
    'Remove Pose Snapshot': 'ポーズスナップショット削除',
    'Remove Selection Set': '選択セット削除',
    'Remove Smart Animation ballistic guides.': 'Smart Animation の弾道ガイドを削除します。',
    'Remove Smart Animation camera shake keys or modifiers.': 'Smart Animation のカメラシェイクキーまたはモディファイアを削除します。',
    'Remove Smart Animation ghost preview objects.': 'Smart Animation のゴーストプレビューオブジェクトを削除します。',
    'Remove Smart Animation loop modifiers.': 'Smart Animation のループモディファイアを削除します。',
    'Remove Smart Animation noise modifiers.': 'Smart Animation のノイズモディファイアを削除します。',
    'Remove Smart Animation stepped preview keys.': 'Smart Animation のステッププレビューキーを削除します。',
    'Remove Smart Animation trail objects.': 'Smart Animation のトレイルオブジェクトを削除します。',
    'Remove duplicate keys.': '重複キーを削除します。',
    'Remove in-between keys using the simplify threshold.': '簡略化しきい値を使って中間キーを削除します。',
    'Remove invalid motion-library entries.': '無効なモーションライブラリエントリを削除します。',
    'Remove the current live retarget preview constraints.': '現在のライブリターゲットプレビュー拘束を削除します。',
    'Repair common scene-state problems like missing actions or invalid preview ranges.': 'アクション欠落や不正なプレビュー範囲など、よくあるシーン状態の問題を修復します。',
    'Reset Selected Pose': '選択ポーズをリセット',
    'Retarget, root motion, and mapping tools.': 'リターゲット、ルートモーション、マッピング用ツールです。',
    'Reusable poses, selections, and motion-library tools.': '再利用できるポーズ、選択セット、モーションライブラリ用ツールです。',
    'Run Cleanup Hub': '整理ハブを実行',
    'Run Data I/O Hub': 'データ入出力ハブを実行',
    'Run Diagnostics Hub': '診断ハブを実行',
    'Run FX Hub': 'FX ハブを実行',
    'Run Scene Audit': 'シーン監査を実行',
    'Run Timeline Hub': 'タイムラインハブを実行',
    'Run Timing Hub': 'タイミングハブを実行',
    'Run Transfer Hub': '転送ハブを実行',
    'Run the matching clear/remove action for the current compact FX mode when available.': '現在のコンパクト FX モードに対応する解除 / 削除処理がある場合、その処理を実行します。',
    'Scale Key Timing': 'キータイミング拡縮',
    'Scale Timing': 'タイミング拡縮',
    'Scale key timing around a pivot.': '基準点を中心にキーのタイミングを拡大縮小します。',
    'Scale selected keys relative to the surrounding anchors.': '周囲のアンカーキーを基準に選択キーを拡大縮小します。',
    'Scale to Neighbors': '隣接キー基準で拡縮',
    'Scan the current scene for common animation issues.': '現在のシーンを走査し、よくあるアニメーション問題を確認します。',
    'Scene summary, diagnostics, and one-click guidance.': 'シーン概要、診断、ワンクリック案内をまとめて表示します。',
    'Select a Smart Tool': 'Smart ツールを選択してください',
    'Sequence Library to NLA': 'ライブラリを NLA へ並べる',
    'Set the preview range from all camera markers.': '全てのカメラマーカーからプレビュー範囲を設定します。',
    'Set the preview range from the active key span.': 'アクティブなキー範囲からプレビュー範囲を設定します。',
    'Set the preview range from the active sound strip.': 'アクティブなサウンドストリップからプレビュー範囲を設定します。',
    'Set the preview range from the current camera-marker shot.': '現在のカメラマーカーショットからプレビュー範囲を設定します。',
    'Shape Key Insert Mode': 'シェイプキー挿入モード',
    'Shape Keys: Active': 'シェイプキー: アクティブ',
    'Shape Keys: All': 'シェイプキー: 全て',
    'Shape Optimize': 'シェイプ最適化',
    'Shape Smooth': 'シェイプスムーズ',
    'Shift Keys': 'キーを移動',
    'Shot Range': 'ショット範囲',
    'Shot review playback settings': 'ショット確認向けの再生設定',
    'Simplify Curves': 'カーブ簡略化',
    'Smart Animation': 'Smart Animation',
    'Smart Unbake': 'スマートアンベイク',
    'Smooth Curves': 'カーブをスムーズ化',
    'Smooth Shape Key Curves': 'シェイプキーカーブをスムーズ化',
    'Smooth editable curves.': '編集可能なカーブをスムーズ化します。',
    'Smooth shape-key curves.': 'シェイプキーカーブをスムーズ化します。',
    'Sound Range': 'サウンド範囲',
    'Split the 3D View into free and camera-locked review panes.': '3D ビューを自由ビューとカメラ固定レビュー画面に分割します。',
    'Spring Dynamics': 'スプリングダイナミクス',
    'Spring Magic': 'Spring Magic',
    'Step Override': 'ステップ上書き',
    'Stepped Preview': 'ステッププレビュー',
    'Store Pose Snapshot': 'ポーズスナップショット保存',
    'Store Selection Set': '選択セット保存',
    'Switch Dynamic Parent': 'ダイナミック親子切り替え',
    'Switch dynamic parenting for the current selection.': '現在の選択のダイナミック親子付けを切り替えます。',
    'Switch the scene shown in this Smart Animation N-panel': 'この Smart Animation Nパネルに表示するシーンを切り替えます。',
    'Tangent Preset': 'タンジェントプリセット',
    'Timeline Mode': 'タイムラインモード',
    'Timing Mode': 'タイミングモード',
    'Show Smart Animation controls in the standard Sidebar N-panel': '標準のサイドバーNパネルに Smart Animation の操作を表示します。',
    'Trail Curve': 'トレイルカーブ',
    'Transfer': '転送',
    'Transfer Mode': '転送モード',
    'Transform Reveal': '変形リビール',
    'Tween': 'トゥイーン',
    'Use automatic Bezier handles.': '自動 Bezier ハンドルを使います。',
    'Use clamped automatic handles.': 'クランプ付き自動ハンドルを使います。',
    'Use the current camera cut and the next one.': '現在のカメラカットから次のカットまでを使います。',
    'Use the full span of all camera markers.': '全カメラマーカーの全体範囲を使います。',
    'Use vector handles for straighter transitions.': 'より直線的な遷移になるベクターハンドルを使います。',
    'Vehicle Drive': '車両ドライブ',
    'Visual': 'ビジュアル',
    'Write a scene report into Blender text data.': 'シーンレポートを Blender テキストデータに書き出します。',
    'XY': 'XY',
    'XYZ': 'XYZ',
    'XZ': 'XZ',
    'YZ': 'YZ',
    '→': '→',
})


JA_TRANSLATIONS.update({
    "Overview Task": "概要タスク",
    "Choose a compact overview action or a migrated bundled tool. Diagnostic and report tasks are listed first; bundled tools are grouped by animation genre.": "コンパクトな概要アクション、または移植済みの同梱ツールを選びます。診断・レポート系を先頭に置き、同梱ツールはアニメーション用途のジャンル別に並べています。",
    "Check the current scene and jump to the most relevant compact workspace for what you are doing now.": "現在のシーンを確認し、いまの作業に最も合うコンパクトワークスペースへ移動します。",
    "Repair common scene-state problems such as missing actions, invalid preview ranges, or unsafe setup values before you continue animating.": "作業を続ける前に、アクション欠落、不正なプレビュー範囲、安全でない設定値など、よくあるシーン状態の問題を修復します。",
    "Scan the current scene for common animation issues and show what should be fixed before timing, cleanup, transfer, or export work.": "現在のシーンを走査し、タイミング調整、整理、転送、書き出し前に直すべき一般的なアニメーション問題を表示します。",
    "Write a scene report into Blender text data so you can review or share the current animation setup and diagnostic results.": "現在のアニメーション設定と診断結果を確認・共有できるように、Blender のテキストデータへシーンレポートを書き出します。",
    "Clear the compact operation log when you want to remove old messages before running new checks.": "新しいチェックを実行する前に古いメッセージを消したい場合、コンパクト操作ログをクリアします。",
    "Run Overview Task": "概要タスクを実行",
    "Legacy command for the selected overview task. The N-panel now switches displayed tools immediately when the Overview Task dropdown changes.": "選択中の概要タスク用の互換コマンドです。現在は概要タスクのドロップダウン変更時に、Nパネル内の表示ツールが即時切り替わります。",
    "Integrated overview task is not recognized.": "概要タスクに移行した統合ツールを識別できません。",
    "Integrated overview task runner is not available.": "概要タスク用の統合ツール実行機能が見つかりません。",
    "Integrated Overview Task": "統合概要タスク",
    "Show the migrated bundled tool group inside the Overview Task N-panel section.": "概要タスクのNパネル表示内に移植済み同梱ツールグループを表示します。",
    "The selected migrated tool was not found.": "選択された移植済みツールが見つかりません。",
    "Pose: Ani Offset": "ポーズ: Ani Offset",
    "Pose: Sakura PoseLib": "ポーズ: Sakura PoseLib",
    "Key Data: AnimAll": "キーデータ: AnimAll",
    "Transform: Animation Transform Offset": "変形: Animation Transform Offset",
    "Timing: EaseIt": "タイミング: EaseIt",
    "Timing: Stop Motion Style Animator": 'タイミング：ストップモーション風アニメーター',
    "Curve: Bezier Curve Editor Overlay": 'カーブ：ベジェカーブエディター オーバーレイ',
    "Curve: Simplify Curves+": 'カーブ：Simplify Curves+',
    "Camera: Camera Shakify": "カメラ: Camera Shakify",
    "Storyboard: Storytools - Storyboard Tools": "ストーリーボード: Storytools - Storyboard Tools",
    "Capture a reference pose, then propagate the transform delta to keyed pose-bone channels inside the selected Action and slot frame range. How to use: Select an armature in Pose Mode, choose the target Action and slot, set the frame range, capture the reference pose, move the bones, then run Propagate Offset once.": "基準ポーズを記録し、変更後の差分を選択中 Action / スロットの指定フレーム範囲へ一括反映するポーズ補正ツールです。使い方: Pose モードのアーマチュアを選択し、対象 Action とスロット、反映範囲を指定して基準ポーズを記録し、ボーンを動かしたあとで Propagate Offset を 1 回実行してください。",
    "Animate mesh, curve, lattice, UV, attribute, bevel, crease, and other element-level data that standard object transforms do not cover. How to use: Enter the supported edit mode, enable the element channels you want, edit the data, then insert or delete keys from the migrated AnimAll panel or operators.": "通常のオブジェクト変形では扱えない頂点・UV・属性・ベベル・クリースなど、要素単位データへキーフレームを打てるツールです。使い方: 対応する編集モードに入り、記録したい要素チャンネルを有効にしてデータを編集し、移植済み AnimAll パネルまたはオペレーターからキーの挿入・削除を行ってください。",
    "Move, rotate, or scale animated objects while applying the same transform offset to their existing location, rotation, or scale keyframes. How to use: Select animated objects, run Grab / Rotate / Scale Offset or use the bundled Shift+G / Shift+R / Shift+S shortcuts, then confirm the transform to bake the delta into the action.": "アニメーション済みオブジェクトを移動・回転・拡縮しつつ、その差分を既存の位置・回転・スケールキーへまとめて反映するツールです。使い方: アニメーション済みオブジェクトを選択し、Grab / Rotate / Scale Offset か Shift+G / Shift+R / Shift+S を実行して変形を確定すると、その差分がアクションへ焼き込まれます。",
    "Display an overlay editor for selected keyframe handles so you can adjust Bezier easing directly with an on-screen curve widget. How to use: Open the migrated Bezier Curve Editor panel in the relevant animation editor, select keyframes, then use the overlay controls to reshape easing and handle behavior.": "選択キーフレームのハンドルをオーバーレイ上で直接編集し、ベジェ補間のイージング形状を視覚的に調整できるツールです。使い方: 対応するアニメーションエディターで移植済み Bezier Curve Editor パネルを開き、キーフレームを選択してオーバーレイ操作でイージングやハンドル挙動を調整してください。",
    "Add layered camera shake, wobble, and captured handheld motion patterns to cameras through reusable shake actions and controls. How to use: Select a camera, open the migrated Camera Shakify controls, choose a shake preset or generated action, then adjust amplitude, timing, and blend settings as needed.": "再利用可能なシェイクアクションを使い、カメラへ揺れ・手持ち風モーション・ワブルを重ね掛けできるカメラ演出ツールです。使い方: カメラを選択して移植済み Camera Shakify 設定を開き、プリセットまたは生成アクションを選んでから、強さ・タイミング・ブレンドを調整してください。",
    "Apply curated easing presets to selected animation keyframes from icon-based controls in the Graph Editor or related animation editors. How to use: Select editable keyframes in the Graph Editor, open the migrated EaseIt panel, then click a preset icon to update the selected keyframe easing.": "グラフエディターなどで選択したキーフレームへ、アイコン付きプリセットから各種イージングを素早く適用できるツールです。使い方: グラフエディターで編集可能なキーフレームを選択し、移植済み EaseIt パネルからプリセットアイコンを押してイージングを適用してください。",
    "Manage reusable armature pose books, pose sliders, conversion utilities, and pose maintenance helpers for character animation workflows. How to use: Select an armature, open the migrated Sakura PoseLib panels, create or update a pose book, then store, organize, apply, mix, or convert poses as needed.": "アーマチュア用の再利用ポーズ集、スライダー制御、変換補助、保守機能をまとめたキャラクター向けポーズライブラリツールです。使い方: アーマチュアを選択して移植済み Sakura PoseLib パネルを開き、ポーズブックを作成・更新したうえで、ポーズの保存・整理・適用・ミックス・変換を行ってください。",
    "Reduce point counts in curve objects and selected animation F-Curves with distance-based or curvature-based simplification. How to use: Select the target curve object or animation F-Curves, choose the simplification mode and tolerance, then execute the migrated Simplify operator.": "距離基準または曲率基準の簡略化で、カーブオブジェクトや選択 F-Curve の点数を削減する軽量化ツールです。使い方: 対象のカーブオブジェクトまたはアニメーション F-Curve を選択し、簡略化モードと許容値を決めてから移植済み Simplify オペレーターを実行してください。",
    "Convert animation to a stepped stop-motion look by thinning keys, forcing constant interpolation, and optionally adding jitter noise. How to use: Select an animated object, set the frame step, offset, and jitter strength, then run Apply Stop Motion. Use Reset / Clean to remove the generated jitter.": "キーの間引き、コンスタント補間化、任意のジッターノイズ付与により、アニメーションをストップモーション風に変換するツールです。使い方: アニメーション済みオブジェクトを選択し、フレーム間隔・オフセット・ジッター強度を設定して Apply Stop Motion を実行してください。生成したジッターは Reset / Clean で除去できます。",
    "Provide storyboard-oriented Grease Pencil, camera, object, map, and setup tools for rapid shot planning and previs workflows. How to use: Open the migrated Storytools panels or menus inside the Overview Task N-panel section and use the sub-tools that match your storyboard task, such as camera setup, layer sync, map placement, or shot organization.": "Grease Pencil、カメラ、オブジェクト、マップ、初期設定をまとめ、ショット設計やプリビズを素早く進めるためのストーリーボード支援ツール群です。使い方: 概要タスク内の移植済み Storytools パネルやメニューを開き、カメラ設定、レイヤー同期、マップ配置、ショット整理など、目的に合うサブツールを使用してください。",
})

JA_TRANSLATIONS.update({
    "Integrated Tools": "統合ツール",
    "All Commands": "全コマンド",
    "Properties": "プロパティ",
    "Settings": "設定",
    "Toggle Feature": "機能を切り替え",
    "Switch an always-on feature on or off and save the setting immediately.": "常時起動機能の有効・無効を切り替え、設定を即時保存します。",
})


JA_TRANSLATIONS.update({
    "3D View / Dope Sheet": "3Dビュー / ドープシート",
    "3D Viewport Side Panel -> Sakura -> Sakura PoseLib": "3Dビューポートサイドパネル -> Sakura -> Sakura PoseLib",
    "Add captured camera shake/wobble to your cameras": "カメラへシェイクやワブルを追加します。",
    "Animate mesh and element-level data such as vertices, UVs, attributes, bevel, and crease values": "頂点、UV、属性、ベベル、クリース値などのメッシュおよび要素単位データをアニメートします。",
    "Animation": "アニメーション",
    "Animation Transform Offset": "Animation Transform Offset",
    "Apply easing presets to selected keyframes": "選択したキーフレームへイージングプリセットを適用します。",
    "Bezier curve overlay editor for Timeline keyframe easing": "タイムラインキーフレームのイージングを調整するベジェカーブオーバーレイエディターです。",
    "Camera properties": "カメラプロパティ",
    "Curve": "カーブ",
    "Dope Sheet > Sidebar": "ドープシート > サイドバー",
    "Dope Sheet > StopMotion": 'ドープシート > ストップモーション',
    "EaseIt": "EaseIt",
    "Extensions / Smart Animation": "拡張機能 / Smart Animation",
    "Graph Editor > Sidebar > Easing": "グラフエディター > サイドバー > イージング",
    "Offset entire animation when transforming objects": "オブジェクト変形時にアニメーション全体をオフセットします。",
    "Propagate pose offsets to keyframes inside the selected Action+Slot frame range once per click.": "クリックごとに、選択した Action+Slot のフレーム範囲内にあるキーフレームへポーズオフセットを反映します。",
    "Sakura PoseLib": "Sakura PoseLib",
    "Simplify curve objects and selected animation F-Curves": "カーブオブジェクトと選択中のアニメーションFカーブを簡略化します。",
    "Smart Animation exposes its Smart Animation settings in the Sidebar N-panel category Smart Animation.": "Smart Animation は Smart Animation 設定をサイドバーの Nパネルカテゴリ Smart Animation に表示します。",
    "Standalone Smart Animation package with a unified root layout and standard N-panel UI.": "統一ルートレイアウトと標準NパネルUIを備えた単体版 Smart Animation パッケージです。",
    "Stop-motion tools: Step, Jitter, and Offset": "ステップ、ジッター、オフセットを扱うストップモーションツールです。",
    "Storyboard-oriented Grease Pencil, camera, and shot setup tools": "ストーリーボード向けの Grease Pencil、カメラ、ショット設定ツールです。",
    "Storytools - Storyboard Tools": 'Storytools',
    "View3D > Sidebar > Ani Offset": "3Dビュー > サイドバー > Ani Offset",
    "View3D > Sidebar > Animation > AnimAll": "3Dビュー > サイドバー > アニメーション > AnimAll",
    "View3D > Sidebar > Animation > Animation Offset": "3Dビュー > サイドバー > アニメーション > Animation Offset",
    "Sidebar > Smart Animation": "サイドバー > Smart Animation",
    "View3D > Sidebar > Smart Animation": "3Dビュー > サイドバー > Smart Animation",
})



# -----------------------------------------------------------------------------
# Comprehensive UI text normalization and runtime translation helpers
# -----------------------------------------------------------------------------

JA_TRANSLATIONS.update({
    "3D View / Dope Sheet": "3Dビュー / ドープシート",
    "3D Viewport Side Panel -> Sakura -> Sakura PoseLib": '3Dビューポートサイドパネル -> Sakura -> Sakura PoseLib',
    "Add captured camera shake/wobble to your cameras": "記録済みのカメラシェイクやワブルをカメラへ追加します。",
    "Animate mesh and element-level data such as vertices, UVs, attributes, bevel, and crease values": "頂点、UV、属性、ベベル、クリース値など、メッシュおよび要素単位のデータをアニメーション化します。",
    "Animation": "アニメーション",
    "Animation Transform Offset": "Animation Transform Offset",
    "Apply easing presets to selected keyframes": "選択キーフレームへイージングプリセットを適用します。",
    "Bezier curve overlay editor for Timeline keyframe easing": "タイムラインのキーフレームイージング用ベジェカーブ・オーバーレイエディターです。",
    "Camera properties": "カメラプロパティ",
    "Curve": "カーブ",
    "Dope Sheet > Sidebar": "ドープシート > サイドバー",
    "Dope Sheet > StopMotion": 'ドープシート > ストップモーション',
    "EaseIt": "EaseIt",
    "Extensions / Smart Animation": "拡張機能 / Smart Animation",
    "Graph Editor > Sidebar > Easing": "グラフエディター > サイドバー > イージング",
    "Offset entire animation when transforming objects": "オブジェクト変形時にアニメーション全体をオフセットします。",
    "Propagate pose offsets to keyframes inside the selected Action+Slot frame range once per click.": "1クリックで、選択した Action+Slot のフレーム範囲内にあるキーフレームへポーズオフセットを伝播します。",
    "Sakura PoseLib": "Sakura PoseLib",
    "Simplify curve objects and selected animation F-Curves": "カーブオブジェクトと選択したアニメーション F カーブを簡略化します。",
    "Smart Animation exposes its Smart Animation settings in the Sidebar N-panel category Smart Animation.": "Smart Animation は、サイドバーの N パネルカテゴリ Smart Animation に Smart Animation 設定を表示します。",
    "Standalone Smart Animation package with a unified root layout and standard N-panel UI.": "統一ルートレイアウトと標準NパネルUIを備えた、単体版 Smart Animation パッケージです。",
    "Stop-motion tools: Step, Jitter, and Offset": "ステップ、ジッター、オフセットを扱うストップモーション用ツールです。",
    "Storyboard-oriented Grease Pencil, camera, and shot setup tools": "ストーリーボード向けの Grease Pencil、カメラ、ショット設定ツールです。",
    "Storytools - Storyboard Tools": 'Storytools',
    "View3D > Sidebar > Ani Offset": "3Dビュー > サイドバー > Ani Offset",
    "View3D > Sidebar > Animation > AnimAll": "3Dビュー > サイドバー > Animation > AnimAll",
    "View3D > Sidebar > Animation > Animation Offset": "3Dビュー > サイドバー > Animation > Animation Offset",
    "Sidebar > Smart Animation": "サイドバー > Smart Animation",
    "View3D > Sidebar > Smart Animation": "3Dビュー > サイドバー > Smart Animation",
})


def _split_bilingual_pair(value):
    """Return (english, japanese) for clear English/Japanese paired UI text."""
    text = str(value or '')
    if not text:
        return None
    separators = (' / ', ' ／ ', ' | ', ' ｜ ', '／', '｜')
    for sep in separators:
        if sep not in text:
            continue
        parts = [part.strip() for part in text.split(sep)]
        if len(parts) != 2 or not parts[0] or not parts[1]:
            continue
        left_is_ja = sas_has_japanese(parts[0])
        right_is_ja = sas_has_japanese(parts[1])
        if left_is_ja == right_is_ja:
            continue
        return (parts[1], parts[0]) if left_is_ja else (parts[0], parts[1])
    if text.count('/') + text.count('|') + text.count('／') + text.count('｜') == 1:
        parts = [part.strip() for part in _BILINGUAL_SEPARATOR_RE.split(text, maxsplit=1)]
        if len(parts) == 2 and parts[0] and parts[1]:
            left_is_ja = sas_has_japanese(parts[0])
            right_is_ja = sas_has_japanese(parts[1])
            if left_is_ja != right_is_ja:
                return (parts[1], parts[0]) if left_is_ja else (parts[0], parts[1])
    return None


def _reverse_translation_map():
    result = {}
    for en, ja in _iter_translation_pairs(include_dynamic=True):
        en_text = str(en or '').strip()
        ja_text = str(ja or '').strip()
        if en_text and ja_text:
            result.setdefault(ja_text, en_text)
    return result


def _english_from_japanese(ja_text):
    value = str(ja_text or '').strip()
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[0]
    direct = _reverse_translation_map().get(value)
    if direct:
        return direct
    try:
        templated = _translate_template_to_english(value)
        if templated:
            return templated
    except Exception:
        pass
    return value


def sas_source_text(text):
    """Normalize user-facing source strings to English for Blender registration.

    Blender's translation system expects stable source text.  This function keeps
    registered class labels, categories, property names, and enum labels in the
    English source language while the translation table supplies Japanese output.
    """
    value = str(text or '')
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[0]
    if sas_has_japanese(value):
        return _english_from_japanese(value)
    return value




def sas_english_source_text(text, context=None):
    return sas_source_text(text)

def sas_target_japanese(text):
    value = str(text or '')
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[1]
    if sas_has_japanese(value):
        return value
    return str(JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value) or _dynamic_ja_for_text(value) or value)


_DYNAMIC_PREFIX_JA = {
    'Status': '状態',
    'Panels': 'パネル',
    'Panel': 'パネル',
    'Commands': 'コマンド',
    'Operators': 'オペレーター',
    'Menus': 'メニュー',
    'Prefs': '設定',
    'Props': 'プロパティ',
    'Runtime': '実行状態',
    'Loaded now': '現在読み込み中',
    'Ready': '読み込み待ち',
    'Load error': '読み込みエラー',
    'Note': 'メモ',
    'Function': '機能',
    'How to use': '使い方',
}
_DYNAMIC_PREFIX_EN = {ja: en for en, ja in _DYNAMIC_PREFIX_JA.items()}


def _localize_dynamic_prefix_text(value, context=None):
    text = str(value or '')
    if not text:
        return text
    if sas_is_japanese(context):
        # Translate simple dynamic labels such as "Panels: 8" that cannot be
        # represented as exact message ids because the count changes at runtime.
        for en, ja in sorted(_DYNAMIC_PREFIX_JA.items(), key=lambda item: len(item[0]), reverse=True):
            if text == en:
                return ja
            if text.startswith(en + ':'):
                tail = text[len(en) + 1:]
                stripped = tail.strip()
                if stripped:
                    translated_tail = sas_translate_text(stripped, context)
                    if translated_tail != stripped:
                        spacing = tail[:len(tail) - len(tail.lstrip())]
                        return f'{ja}:{spacing}{translated_tail}'
                return ja + text[len(en):]
        text = re.sub(r'\s*\|\s*Ready:', ' | 読み込み待ち:', text)
        return text
    text = re.sub(r'\s*\|\s*読み込み待ち:', ' | Ready:', text)
    for ja, en in sorted(_DYNAMIC_PREFIX_EN.items(), key=lambda item: len(item[0]), reverse=True):
        if text == ja:
            return en
        if text.startswith(ja + ':'):
            tail = text[len(ja) + 1:]
            stripped = tail.strip()
            if stripped and '|' not in tail:
                translated_tail = sas_translate_text(stripped, context)
                if translated_tail != stripped:
                    spacing = tail[:len(tail) - len(tail.lstrip())]
                    return f'{en}:{spacing}{translated_tail}'
            return en + text[len(ja):]
    return text


def sas_translate_text(text, context=None, *, split_bilingual=True):
    value = str(text or '')
    if split_bilingual:
        pair = _split_bilingual_pair(value)
        if pair:
            value = pair[1] if sas_is_japanese(context) else pair[0]
        else:
            value = _select_bilingual_variant(value, context)
    if not value:
        return value
    if sas_is_japanese(context):
        translated = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
        if translated:
            return str(translated)
        try:
            templated = _translate_template_to_japanese(value)
            if templated and templated != value:
                return templated
        except Exception:
            pass
        try:
            dynamic = _translate_dynamic_phrase_to_japanese(value)
            if dynamic:
                return dynamic
        except Exception:
            pass
        return _localize_dynamic_prefix_text(value, context)
    if sas_has_japanese(value):
        try:
            templated = _translate_template_to_english(value)
            if templated and templated != value:
                return templated
        except Exception:
            pass
        return _english_from_japanese(value)
    return _localize_dynamic_prefix_text(value, context)


def sas_localize_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


def sanitize_bilingual_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


def _normalize_enum_items_for_source(items, target_texts):
    if not isinstance(items, (list, tuple)):
        return items
    changed = False
    normalized = []
    for item in items:
        if not isinstance(item, (list, tuple)):
            normalized.append(item)
            continue
        values = list(item)
        for index in (1, 2):
            if len(values) > index and isinstance(values[index], str):
                original = values[index]
                if original:
                    target_texts.append(original)
                source = sas_source_text(original)
                if source != original:
                    values[index] = source
                    changed = True
        normalized.append(tuple(values) if isinstance(item, tuple) else values)
    if not changed:
        return items
    return tuple(normalized) if isinstance(items, tuple) else normalized


def _property_keywords(prop_def):
    try:
        keywords = getattr(prop_def, 'keywords', None)
        if isinstance(keywords, dict):
            return keywords
    except Exception:
        pass
    if isinstance(prop_def, tuple) and len(prop_def) >= 2 and isinstance(prop_def[1], dict):
        return prop_def[1]
    return None


def collect_class_ui_texts(classes):
    texts = []
    def append(value):
        value = str(value or '').strip()
        if value and value not in texts:
            texts.append(value)
    for cls in classes or ():
        if not isinstance(cls, type):
            continue
        for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_name'):
            append(getattr(cls, attr, None))
        annotations = getattr(cls, '__annotations__', {}) or {}
        if isinstance(annotations, dict):
            for prop_def in annotations.values():
                keywords = _property_keywords(prop_def)
                if not isinstance(keywords, dict):
                    continue
                for key in ('name', 'description', 'text', 'placeholder', 'heading'):
                    append(keywords.get(key))
                items = keywords.get('items')
                if isinstance(items, (list, tuple)):
                    for item in items:
                        if isinstance(item, (list, tuple)):
                            if len(item) > 1:
                                append(item[1])
                            if len(item) > 2:
                                append(item[2])
    return texts


def normalize_class_ui_metadata(cls):
    """Keep Blender-registered UI metadata in English source form.

    This prevents Japanese-only or English/Japanese combined labels from being
    frozen into RNA metadata. Japanese display is handled exclusively by the
    translation table, so switching Blender's language shows only the active
    interface language.
    """
    if not isinstance(cls, type):
        return cls
    texts = collect_class_ui_texts((cls,))
    for attr in ('bl_label', 'bl_description', 'bl_category', 'bl_name'):
        try:
            value = getattr(cls, attr, None)
        except Exception:
            continue
        if isinstance(value, str) and value:
            try:
                setattr(cls, attr, sas_source_text(value))
            except Exception:
                pass
    annotations = getattr(cls, '__annotations__', {}) or {}
    if isinstance(annotations, dict):
        for prop_def in annotations.values():
            keywords = _property_keywords(prop_def)
            if not isinstance(keywords, dict):
                continue
            for key in ('name', 'description', 'text', 'placeholder', 'heading'):
                value = keywords.get(key)
                if isinstance(value, str) and value:
                    texts.append(value)
                    keywords[key] = sas_source_text(value)
            if 'items' in keywords:
                keywords['items'] = _normalize_enum_items_for_source(keywords.get('items'), texts)
    try:
        register_dynamic_ui_translations(texts)
    except Exception:
        pass
    return cls


def register_dynamic_ui_translations(texts):
    changed = False
    for item in texts or ():
        value = str(item or '').strip()
        if not value:
            continue
        pair = _split_bilingual_pair(value)
        if pair:
            en_text, ja_text = pair
        elif sas_has_japanese(value):
            ja_text = value
            en_text = _english_from_japanese(value)
            if not en_text or en_text == ja_text:
                continue
        else:
            en_text = value
            ja_text = _dynamic_ja_for_text(value)
            if not ja_text:
                continue
        en_text = str(en_text or '').strip()
        ja_text = str(ja_text or '').strip()
        if not en_text or not ja_text or en_text == ja_text:
            continue
        if _DYNAMIC_JA_TRANSLATIONS.get(en_text) == ja_text:
            continue
        _DYNAMIC_JA_TRANSLATIONS[en_text] = ja_text
        changed = True
    if not changed:
        return
    try:
        bpy.app.translations.unregister(_DYNAMIC_TRANSLATION_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_DYNAMIC_TRANSLATION_OWNER, _build_translation_table(include_dynamic=True))
    except Exception:
        pass


JA_TRANSLATIONS.update({
    "All Functions": "全機能",
    "Show every Smart Animation section and every migrated bundled tool group directly in the N-panel.": "Smart Animation の全セクションと移植済み同梱ツールグループを、Nパネル内に直接すべて表示します。",
    "Overview / Diagnostics": "概要 / 診断",
    "Show scene summary, diagnostics, setup checks, recommendations, report export, and the operation log in the N-panel.": "シーン要約、診断、設定チェック、おすすめ操作、レポート書き出し、操作ログをNパネル内に表示します。",
    "Animation Tools": "アニメーションツール",
    "Show timeline, timing, cleanup, and motion-FX tools in the N-panel.": "タイムライン、タイミング、整理、モーションFXツールをNパネル内に表示します。",
    "Asset Tools": "アセットツール",
    "Show selection sets, pose snapshots, motion-library tools, and data I/O tools in the N-panel.": "選択セット、ポーズスナップショット、モーションライブラリ、データ入出力ツールをNパネル内に表示します。",
    "Transfer Tools": "転送ツール",
    "Show retargeting, root-motion, bone-map, and transfer tools in the N-panel.": "リターゲット、ルートモーション、ボーン対応表、転送ツールをNパネル内に表示します。",
    "Choose which Smart Animation function group is displayed in the N-panel. All Functions shows every built-in section and every migrated bundled tool group.": "Smart Animation のどの機能グループをNパネルに表示するかを選びます。全機能では、すべての標準セクションと移植済み同梱ツールグループを表示します。",
    "Show migrated pose-library and pose-offset tools in the N-panel.": "ポーズライブラリとポーズオフセット系の移植済みツールをNパネル内に表示します。",
    "Show migrated mesh, curve, UV, attribute, and element-keying tools in the N-panel.": "メッシュ、カーブ、UV、属性、要素単位キーイング系の移植済みツールをNパネル内に表示します。",
    "Show migrated transform-offset tools for animated objects in the N-panel.": "アニメーション済みオブジェクト用の変形オフセット系移植済みツールをNパネル内に表示します。",
    "Show migrated timing, easing, and stepped-animation tools in the N-panel.": "タイミング、イージング、コマ打ちアニメーション系の移植済みツールをNパネル内に表示します。",
    "Show migrated curve-editing and curve-simplification tools in the N-panel.": "カーブ編集とカーブ簡略化系の移植済みツールをNパネル内に表示します。",
    "Show migrated camera-motion and camera-shake tools in the N-panel.": "カメラモーションとカメラシェイク系の移植済みツールをNパネル内に表示します。",
    "Show migrated storyboard, Grease Pencil, camera, map, and shot-planning tools in the N-panel.": "ストーリーボード、Grease Pencil、カメラ、マップ、ショット設計系の移植済みツールをNパネル内に表示します。",
    "Pose Tools": "ポーズツール",
    "Key Data Tools": "キーデータツール",
    "Transform Tools": "変形ツール",
    "Timing Tools": "タイミングツール",
    "Curve Tools": "カーブツール",
    "Camera Tools": "カメラツール",
    "Storyboard Tools": "ストーリーボードツール",
    "Migrated Bundled Tools": "移植済み同梱ツール",
    "Overview Actions": "概要アクション",
    "Use these buttons when you want to run diagnostics, repair common setup issues, export a report, or clear the operation log from the N-panel.": "診断、よくある設定問題の修復、レポート書き出し、操作ログの消去をNパネル内から実行したいときに使用します。",
    "Check the current scene and switch the Task to the most relevant one.": "現在のシーンを確認し、作業に合うタスクへ切り替えます。",
    "Repair common setup problems such as missing actions or invalid preview ranges.": "アクション欠落や不正なプレビュー範囲など、よくある設定問題を修復します。",
    "Scan the scene for animation issues that should be checked before editing or export.": "編集や書き出し前に確認すべきアニメーション上の問題を検査します。",
    "Write the current scene summary and diagnostic result to a Blender text datablock.": "現在のシーン要約と診断結果を Blender テキストデータへ書き出します。",
    "Remove old messages from the in-panel operation log.": "Nパネル内の操作ログから古いメッセージを消去します。",
    "No migrated tool is assigned to this overview task.": "この概要タスクに割り当てられた移植済みツールはありません。",
    "Selected overview task group was not found.": "選択された概要タスクグループが見つかりません。",
    "Integrated tool UI renderer is not available.": "統合ツールUI描画機能が見つかりません。",
    "This tool is currently loaded for the Overview Task N-panel section.": "このツールは現在、概要タスクのNパネル表示用に読み込まれています。",
    "This tool is available from the Smart Animation Overview Task N-panel menu.": "このツールは Smart Animation の概要タスクNパネルメニューから利用できます。",
    "Choose a category from Overview Task, then use the migrated panels, commands, properties, or settings shown directly in the N-panel.": "概要タスクで該当カテゴリを選び、Nパネル内に直接表示される移植済みパネル、コマンド、プロパティ、設定から操作してください。",
    "These are the original tool panels, rendered directly inside the Overview Task N-panel section. Some panels require the matching editor, object selection, or mode before their controls become usable.": "元ツールのパネルを概要タスクのNパネル内に直接表示しています。一部のパネルは、対応エディター、選択状態、モードがそろった場合のみ操作できます。",
    "This panel is not active in the current context. Change selection, mode, or editor as required by the original tool, then select or refresh this overview task again.": "現在のコンテキストではこのパネルは有効になっていません。元ツールが必要とする選択、モード、エディターへ切り替えてから、この概要タスクを選び直すかNパネルを更新してください。",
    "Show the migrated bundled tool group inside the Overview Task N-panel section.": "概要タスクのNパネル表示内に移植済み同梱ツールグループを表示します。",
})

# Rebuild translations after all incremental updates so late-added strings are included.

JA_TRANSLATIONS.update({
    "Animation Recipes": "アニメーション レシピ",
    "Smart Recipe": "Smart レシピ",
    "Choose the upgraded Animation Recipe to run. Each recipe is a Blender-native equivalent of one or more researched animation-assistance tools, such as animBot, BroDynamics, MotionBuilder Story, Cascadeur AutoPhysics, or Cinema 4D Signal.": "実行する アニメーション レシピ の上位互換レシピを選びます。各レシピは animBot、BroDynamics、MotionBuilder Story、Cascadeur AutoPhysics、Cinema 4D Signal など、調査済みアニメーション補助ツールの1つ以上に相当する Blender 内蔵ワークフローです。",
    "Coverage Text": "対応表テキスト",
    "Text datablock name used when Animation Recipes writes the feature coverage report that maps every researched source function to its built-in equivalent.": "アニメーション レシピ が、調査元機能と内蔵相当機能の対応表を書き出すときに使うテキストデータブロック名です。",
    "Motion Director Mode": "モーションディレクターモード",
    "Choose which animBot/AnimAide-style pose refinement pass Smart Motion Director runs. Full Director runs tween, push/pull, and scale-to-neighbor in sequence.": "Smart Motion Director が実行する animBot / AnimAide 風のポーズ調整処理を選びます。フルディレクターではトゥイーン、プッシュ / プル、近隣スケールを順に実行します。",
    "Graph Include Unbake": "グラフにアンベイクを含める",
    "When enabled, Smart Graph Optimizer also runs Smart Unbake after safer cleanup passes, reducing dense baked curves into editable keyframes where possible.": "有効にすると、Smart Graph Optimizer が安全な整理処理の後に Smart Unbake も実行し、高密度ベイク済みカーブを可能な範囲で編集しやすいキーへ減らします。",
    "Graph Auto Clamped Handles": "グラフハンドルを自動クランプ",
    "After Smart Graph Optimizer runs, set edited key handles to Auto Clamped Bezier so smoothed curves avoid common overshoot while staying editable.": "Smart Graph Optimizer の実行後、編集済みキーのハンドルを自動クランプベジェにし、編集性を保ちながら一般的なオーバーシュートを抑えます。",
    "Visualizer Mode": "可視化モード",
    "Choose which motion review helpers Smart Visualize Motion creates: trails and ghosts, motion paths, ballistic guides, or all supported helpers.": "Smart Visualize Motion が作成する確認用ヘルパーを選びます。トレイルとゴースト、モーションパス、弾道ガイド、または対応する全ヘルパーを作成できます。",
    "Physics Director Mode": '物理ディレクターのモード',
    "Choose the Cascadeur/BroDynamics-style physics-assist pass: automatic safe mix, ballistic guide, ballistic bake, fulcrum contact cleanup, spring motion, or rigid-body bake.": "Cascadeur / BroDynamics 風の物理補助処理を選びます。自動安全ミックス、弾道ガイド、弾道ベイク、支点接地整理、スプリングモーション、剛体ベイクを選択できます。",
    "Locomotion Axis": "ロコモーション軸",
    "World axis used as the forward travel direction when Smart Locomotion generates editable cyclic movement keys.": "Smart Locomotion が編集可能なサイクル移動キーを生成するときの前進方向ワールド軸です。",
    "Locomotion Distance": "ロコモーション距離",
    "Total travel distance written over the selected bake range by the Smart Locomotion generator.": "Smart Locomotion 生成機能が選択ベイク範囲へ書き込む総移動距離です。",
    "Locomotion Cycle": "ロコモーション周期",
    "Cycle length in frames used by Smart Locomotion for bobbing and optional loop helper timing.": "Smart Locomotion が上下動と任意のループ補助タイミングに使う周期フレーム数です。",
    "Locomotion Bob": "ロコモーション上下動",
    "Vertical bob amount added to generated Smart Locomotion keys. Use 0 for straight mechanical movement.": "生成される Smart Locomotion キーへ加える上下動量です。機械的な直線移動にしたい場合は 0 にします。",
    "Locomotion Yaw": "ロコモーションヨー",
    "Optional side-to-side yaw amount in degrees for generated Smart Locomotion keys. Use 0 to keep rotation unchanged.": "生成される Smart Locomotion キーに追加する左右ヨー量です。回転を変えない場合は 0 にします。",
    "Add Cycle Modifier": "サイクルモディファイアを追加",
    "After Smart Locomotion writes keys, add Cycles modifiers to generated curves so the base motion can repeat like CMotion-style procedural movement.": "Smart Locomotion がキーを書き込んだ後、生成カーブにサイクルモディファイアを追加し、CMotion 風のプロシージャル移動のように繰り返せるようにします。",
    "IFL Start": "IFL 開始",
    "Start frame applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する開始フレームです。",
    "IFL Duration": "IFL 長さ",
    "Playback duration in frames applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する再生長です。",
    "IFL Offset": "IFL オフセット",
    "Frame offset applied to image texture sequence users. Key this value to synchronize monitor screens or 2D effects with animation timing.": "画像テクスチャシーケンスユーザーへ適用するフレームオフセットです。モニター画面や2Dエフェクトをアニメーションタイミングと同期する場合は、この値へキーを打ちます。",
    "IFL Cyclic": "IFL 循環",
    "Enable cyclic playback on compatible image texture sequence users.": "対応する画像テクスチャシーケンスユーザーで循環再生を有効にします。",
    "Key IFL Offset": "IFL オフセットにキー",
    "Insert a keyframe on the image sequence frame offset at the current frame after applying IFL settings.": "IFL 設定の適用後、現在フレームで画像シーケンスのフレームオフセットにキーを挿入します。",
    "Shape Control Prefix": "シェイプ制御接頭辞",
    "Prefix used for the custom properties created by Smart Shape Control Mixer. These properties drive matching shape-key values and can be keyed like normal controls.": "Smart Shape Control Mixer が作成するカスタムプロパティの接頭辞です。これらのプロパティは対応するシェイプキー値を駆動し、通常の制御と同じようにキーを打てます。",
    "Smart Feature Coverage Report": "Smart 機能対応表",
    "Smart Graph Optimizer": "Smart グラフ最適化",
    "Smart Motion Director": 'スマートモーションディレクター',
    "Smart Visualize Motion": 'スマートモーション可視化',
    "Smart Physics Director": 'スマート物理ディレクター',
    "Generate Smart Locomotion Cycle": "Smart ロコモーションサイクル生成",
    "Smart Image Sequence Manager": "Smart 画像シーケンス管理",
    "Smart Shape Control Mixer": "Smart シェイプ制御ミキサー",
    "Smart AutoPose Assistant": "Smart AutoPose アシスタント",
    "Smart Retarget Director": "Smart リターゲットディレクター",
    "Run Animation Recipe": "アニメーション レシピ実行",
})


JA_TRANSLATIONS.update({
    "Smart Precision Profile": "Smart 精度プロファイル",
    "Choose how strongly Animation Recipes removes visually redundant keys during adaptive cleanup. Safe preserves the most hand-made detail, Balanced suits most production shots, and Aggressive is intended for dense baked data.": "適応整理で、視覚的に不要なキーをどの程度削減するかを選びます。Safe は手付けの細部を最も多く残し、Balanced は多くの制作ショット向け、Aggressive は高密度ベイクデータ向けです。",
    "Adaptive Precision": "適応精度",
    "Enable range-aware sparse-key cleanup inside Smart Graph Optimizer and Precision Polish. The pass preserves endpoints and obvious extremes while reducing redundant in-between keys.": "Smart Graph Optimizer と Precision Polish 内で、値幅に応じた疎キー整理を有効にします。端点と明確な極値を保持しながら、冗長な中間キーを削減します。",
    "Preserve Flow Handles": "流れ保持ハンドル",
    "After Motion Director creates or adjusts keys, set editable Bezier handles to Auto Clamped so pose changes keep smooth spacing without common overshoot artifacts.": "Motion Director がキーを作成または調整した後、編集可能なベジェハンドルを自動クランプにして、一般的なオーバーシュートを抑えつつ滑らかなスペーシングを保ちます。",
    "Quality Report Text": "品質レポートテキスト",
    "Text datablock name used when Smart Quality Report writes key density, duplicate, static-channel, Euler, and spacing diagnostics into the current Blender file.": "Smart Quality Report がキー密度、重複、静的チャンネル、オイラー、スペーシング診断を現在の Blender ファイルへ書き込むときのテキストデータブロック名です。",
    "Quality Sample Step": "品質サンプル間隔",
    "Frame interval used when Smart Quality Report samples selected object motion to estimate maximum speed and acceleration. Smaller values are more precise but slower on long scenes.": "Smart Quality Report が選択オブジェクトの動きをサンプリングし、最大速度と加速度を見積もる際のフレーム間隔です。小さい値ほど精密ですが、長いシーンでは遅くなります。",
    "Locomotion Style": "ロコモーションスタイル",
    "Choose the procedural blocking style used by Smart Locomotion. Walk, Run, Mechanical, and Cinematic produce different bob, yaw, and travel-ease patterns while still writing ordinary editable keys.": "Smart Locomotion が使うプロシージャルなブロッキングスタイルを選びます。Walk、Run、Mechanical、Cinematic は上下動、ヨー、移動イーズの異なるパターンを作り、結果は通常の編集可能キーとして書き込まれます。",
    "IFL Match Scene Range": "IFL をシーン範囲に合わせる",
    "Before applying image-sequence timing, copy the current scene frame start and frame duration into the IFL start and duration settings so monitor or 2D-effect playback matches the shot length.": "画像シーケンスタイミングの適用前に、現在のシーン開始フレームと長さを IFL の開始と長さへ反映し、モニター表示や2Dエフェクト再生をショット尺に合わせます。",
    "Key Shape Controls": "シェイプ制御にキー",
    "When creating or refreshing Smart Shape Control drivers, also insert a keyframe on each generated custom property at the current frame. This makes the controls immediately visible in the Dope Sheet and Graph Editor.": "Smart Shape Control ドライバーの作成または更新時に、生成された各カスタムプロパティへ現在フレームでキーを挿入します。これにより、制御がドープシートとグラフエディターですぐ確認できます。",
    "Smart Quality Report": "Smart 品質レポート",
    "Smart Precision Polish": "Smart 精密ポリッシュ",
    "Run adaptive cleanup, flow-safe handles, sparse unbake, and quality reporting in one pass.": "適応整理、流れを保つハンドル、疎キー化アンベイク、品質レポートを1回で実行します。",
    "Analyze key density, duplicate keys, static channels, Euler jumps, spacing speed, and polish risks.": "キー密度、重複キー、静的チャンネル、オイラー飛び、スペーシング速度、ポリッシュリスクを解析します。",
    "Safe": "安全",
    "Balanced": "バランス",
    "Aggressive": "強め",
    "Walk": "歩き",
    "Run": "走り",
    "Mechanical": "機械的",
    "Cinematic": "シネマティック",
    "Precision": "精度",
    "Adaptive": "適応",
    "Precision Polish": "精密ポリッシュ",
    "Quality": "品質診断",
    "Report": "レポート",
    "Style": "スタイル",
    "Key Controls": "制御にキー",
    "Match Scene": "シーン一致",
    "Use conservative adaptive cleanup and preserve more keys for hand-polished shots.": "保守的な適応整理を使い、手付けで磨いたショットのキーをより多く残します。",
    "Use balanced adaptive cleanup for most mocap, retarget, and hand-keyed shots.": "多くのモーキャプ、リターゲット、手付けショットに適したバランス型の適応整理を使います。",
    "Remove more visually redundant keys after dense baking while preserving extremes.": "極値を保ちながら、高密度ベイク後の視覚的に冗長なキーをより多く削除します。",
    "Two contact-like bobs per cycle for a walk-style blocking base.": "歩き風のブロッキングベースとして、1周期に2回の接地感ある上下動を作ります。",
    "One stronger airborne bounce per cycle for a run or jumpy action base.": "走りや跳ねる動作用のベースとして、1周期に1回の強めの浮遊上下動を作ります。",
    "Linear mechanical travel without bob or yaw swing.": "上下動やヨー揺れのない、機械的な直線移動を作ります。",
    "Smooth-eased travel inside each cycle for director-friendly blocking.": "各周期内でイーズ付きの移動を作り、演出確認しやすいブロッキングにします。",
})

JA_TRANSLATIONS.update({
    "Smart Workflow Stage": "Smart 作業段階",
    "Choose the production stage used by Smart Stage Director. Auto inspects the current context and selects a suitable pass; the other stages force a specific professional workflow.": "Smart Stage Director が使う制作段階を選びます。Auto は現在のコンテキストを解析して適切な処理を選び、他の段階では特定のプロ向けワークフローを強制します。",
    "Smart UI Density": "Smart UI 密度",
    "Choose how dense the Animation Recipes N-panel should be. Compact keeps the panel fast and clean, Balanced exposes common controls, and Studio exposes the full professional control surface.": "アニメーション レシピ のNパネル密度を選びます。Compact は高速で整理された表示、Balanced は一般的な設定表示、Studio は全てのプロ向け操作面を表示します。",
    "Smart Advanced Controls": "Smart 詳細操作",
    "Show deep Animation Recipes control groups even when the UI Density is Compact. Enable this when you need per-feature tuning instead of the dashboard workflow.": "UI密度が Compact の場合でも、アニメーション レシピ の詳細グループを表示します。ダッシュボード操作ではなく機能ごとの細かな調整が必要な場合に有効にします。",
    "Smart Preflight Before Run": "Smart 実行前診断",
    "Before context-aware Smart Stage Director operations, run a lightweight quality check so dense curves, Euler jumps, static channels, and duplicate keys can steer the selected pass.": "文脈対応の Smart Stage Director 実行前に軽量な品質チェックを行い、高密度カーブ、オイラー飛び、静的チャンネル、重複キーを処理選択に反映します。",
    "Smart Quality Gate": "Smart 品質ゲート",
    "Minimum acceptable Smart Quality Report score for final review. When the score is below this value, Smart Stage Director writes a report and recommends polish before handoff.": "最終確認で許容する Smart Quality Report の最低スコアです。スコアがこの値を下回る場合、Smart Stage Director はレポートを作成し、受け渡し前のポリッシュを推奨します。",
    "Curvature Guard": "曲率保護",
    "During adaptive cleanup, preserve keys that define strong curvature, holds, slope direction changes, or high acceleration. This keeps arcs, impacts, and hand-made timing from being over-simplified.": "適応整理中に、強い曲率、ホールド、傾き方向変化、高加速度を定義するキーを保持します。アーク、インパクト、手付けタイミングの過度な簡略化を防ぎます。",
    "Locomotion Sample Density": "ロコモーションサンプル密度",
    "Number of generated samples per locomotion cycle. Higher values create smoother editable blocking keys and better contact timing at the cost of more keys.": "ロコモーション1周期あたりに生成するサンプル数です。値を大きくするとキー数は増えますが、より滑らかで編集しやすいブロッキングキーと接地タイミングを作れます。",
    "Locomotion Contact Lock": "ロコモーション接地ロック",
    "Flatten the generated bob around walk or run contact phases so the blocking pass has more planted, less floaty contact timing.": "歩きや走りの接地位相付近で生成上下動を平坦化し、浮遊感を抑えた接地タイミングのブロッキングにします。",
    "Locomotion Stride Width": "ロコモーション歩幅横揺れ",
    "Optional side-to-side offset added to generated locomotion for a clearer weight-shift read. Use 0 to keep the original centerline.": "生成ロコモーションに追加する任意の左右オフセットです。体重移動を読みやすくできます。元の中心線を維持する場合は 0 にします。",
    "Smart Stage Director": "Smart 段階ディレクター",
    "Run a context-aware studio pass that selects the best Animation Recipes workflow for the current shot stage.": "現在のショット段階に最適な アニメーション レシピ ワークフローを選ぶ文脈対応スタジオ処理を実行します。",
    "Run a context-aware studio pass that chooses blocking, spline, mocap, physics, polish, or review actions from the current shot state.": "現在のショット状態から、ブロッキング、スプライン、モーキャプ、物理、ポリッシュ、レビュー用アクションを選ぶ文脈対応スタジオ処理を実行します。",
    "Hero": "ヒーロー",
    "Mocap Cleanup": "モーキャプ整理",
    "Auto Stage": "自動段階",
    "Blocking": "ブロッキング",
    "Spline": "スプライン",
    "Mocap / Retarget": "モーキャプ / リターゲット",
    "Physics / Overlap": "物理 / オーバーラップ",
    "Final Polish": "最終ポリッシュ",
    "Review": "レビュー",
    "Compact": "コンパクト",
    "Studio": "スタジオ",
    "Stage": "段階",
    "UI Density": "UI密度",
    "Stage Director": "段階ディレクター",
    "Quality Gate": "品質ゲート",
    "Visual Review": "可視レビュー",
    "Gate": "ゲート",
    "Preflight": "事前診断",
    "Advanced Controls": "詳細操作",
    "Samples": "サンプル",
    "Contact Lock": "接地ロック",
    "Stride Width": "歩幅横揺れ",
    "Use the most conservative cleanup for final hero shots and highly intentional hand-polished arcs.": "最終ヒーローショットや意図の強い手付けアーク向けに、最も保守的な整理を使います。",
    "Use stronger but curvature-aware cleanup for retargeted or densely baked motion-capture data.": "リターゲット済みまたは高密度ベイク済みのモーキャプデータ向けに、曲率を保護しながら強めの整理を使います。",
    "Let Smart Stage Director choose the best pass from the current action, selection, density, and quality score.": "現在のアクション、選択、密度、品質スコアから Smart Stage Director が最適な処理を選びます。",
    "Prioritize pose checkpoints, tweening, and safe key insertion while roughing out the shot.": "ショットのラフ作成中に、ポーズチェックポイント、トゥイーン、安全なキー挿入を優先します。",
    "Prioritize curve flow, in-between control, and auto-clamped handles while converting blocking to polished motion.": "ブロッキングを磨いた動きへ移行する際に、カーブの流れ、中割り制御、自動クランプハンドルを優先します。",
    "Prioritize Euler continuity, dense-curve cleanup, unbaking, and quality reporting.": "オイラー連続性、高密度カーブ整理、アンベイク、品質レポートを優先します。",
    "Prioritize ballistic, contact, spring, and visual review helpers.": "弾道、接地、スプリング、可視レビューヘルパーを優先します。",
    "Prioritize precision cleanup, quality gates, and non-destructive reports before handoff.": "受け渡し前に、精密整理、品質ゲート、非破壊レポートを優先します。",
    "Prioritize diagnostics and visual helpers without unnecessary destructive edits.": "不要な破壊編集を避け、診断と可視ヘルパーを優先します。",
    "Show a cleaner production dashboard with the main controls and hide deep controls unless Advanced Controls is enabled.": "主要操作だけを持つ整理された制作ダッシュボードを表示し、詳細操作が有効でない限り深い設定を隠します。",
    "Show the dashboard plus the commonly used control groups.": "ダッシュボードとよく使う操作グループを表示します。",
    "Show the full professional control surface for precise shot work.": "精密なショット作業向けのプロ用全操作面を表示します。",
})

TRANSLATIONS = _build_translation_table(include_dynamic=False)

# -----------------------------------------------------------------------------
# Final translation pass: keep the effective definitions below the legacy
# compatibility helpers above, so late duplicate definitions cannot override
# language switching behavior.
# -----------------------------------------------------------------------------

JA_TRANSLATIONS.update({
    "1.85:1 - Academy Flat": "1.85:1 - アカデミーフラット",
    "1.85:1 aspect ratio (1.850)": "1.85:1 のアスペクト比 (1.850)",
    "16:10 - Computer Monitor": "16:10 - コンピューターモニター",
    "16:10 aspect ratio (1.600)": "16:10 のアスペクト比 (1.600)",
    "16:9 - Widescreen": "16:9 - ワイドスクリーン",
    "16:9 aspect ratio (1.778)": "16:9 のアスペクト比 (1.778)",
    "16:9 format (20 x 11.25)": "16:9 形式 (20 x 11.25)",
    "1:1 - Square": "1:1 - 正方形",
    "2.35:1 - CinemaScope": "2.35:1 - シネマスコープ",
    "2.35:1 aspect ratio (2.350)": "2.35:1 のアスペクト比 (2.350)",
    "3:2 - 35mm Film": "3:2 - 35mm フィルム",
    "3:2 aspect ratio (1.500)": "3:2 のアスペクト比 (1.500)",
    "4:3 - Standard TV": "4:3 - 標準テレビ",
    "4:3 aspect ratio (1.333)": "4:3 のアスペクト比 (1.333)",
    "9:16 - Portrait": "9:16 - 縦長",
    "A4 Landscape": "A4 横",
    "A4 Portrait": "A4 縦",
    "Accessible": "アクセス可能",
    "All keyframe types": "すべてのキーフレームタイプ",
    "Already in camera view": "すでにカメラビューです",
    "Animatic Resolution X": "アニマティック解像度 X",
    "Animatic:": "アニマティック:",
    "Antic + Over": "予備+オーバー",
    "Background transparency:": "背景の透明度:",
    "Bottom": "下",
    "Breakdown": "ブレークダウン",
    "Build": "ビルド",
    "Can't display this panel here!": "このパネルはここに表示できません！",
    "Select a valid 3D View tool first.": "有効な3Dビューのツールを先に選択してください。",
    "Cat": "猫",
    "Center footer text": "フッターテキストを中央揃えにします",
    "Center header text": "ヘッダーテキストを中央揃えにします",
    "Common aspect ratio presets": "一般的なアスペクト比プリセット",
    "Description": "説明",
    "Do Nothing": "何もしない",
    "Do not set any tools": "ツールを設定しません",
    "Down": "下へ",
    "Draw": "描画",
    "Ease": "イーズ",
    "Edit": "編集",
    "Excluded Collections:": "除外コレクション:",
    "Filtered": "フィルター済み",
    "Footer Locations:": "フッター位置:",
    "For internal use only": "内部使用専用",
    "Front (X-Z)": "正面 (X-Z)",
    "GP control bar behavior:": "GP制御バーの動作:",
    "Generated": "生成済み",
    "Hermite": "エルミート",
    "Human Female": "女性人体",
    "Human Male": "男性人体",
    "Imperfection:": "不完全さ:",
    "Insert": "挿入",
    "Make the new camera active": "新しいカメラをアクティブにします",
    "Missing exclusion properties": "除外プロパティが見つかりません",
    "Moving Hold": "ムービングホールド",
    "Multiple Data Users:": "複数データユーザー:",
    "Multiple Users State": "複数ユーザー状態",
    "Need to enter draw mode once": "一度ドローモードに入る必要があります",
    "No Sync": "同期なし",
    "No active camera": "アクティブカメラなし",
    "No active material": "アクティブマテリアルなし",
    "No change": "変更なし",
    "No title in text area": "テキストエリアにタイトルなし",
    "Not in camera": "カメラ内ではありません",
    "Nothing": "なし",
    "Number of columns in the grid": "グリッドの列数",
    "Number of pages to add": "追加するページ数",
    "Number of rows in the grid": "グリッドの行数",
    "On visible and unlocked layers": "表示中でロックされていないレイヤー",
    "Only on active layer ": "アクティブレイヤーのみ",
    "Only on active layer": "アクティブレイヤーのみ",
    "Only on all visible layers": "すべての表示レイヤーのみ",
    "Operation": "操作",
    "Operation mode": "操作モード",
    "Output": "出力",
    "Output splines": "出力スプライン",
    "Palette": "パレット",
    "Portrait 9:16 (0.563)": "縦長 9:16 (0.563)",
    "Position:": "位置:",
    "Predefined canvas sizes": "定義済みキャンバスサイズ",
    "Push markers to the left": "マーカーを左へ押し出します",
    "Push markers to the right": "マーカーを右へ押し出します",
    "Read Direction": "読み方向",
    "Replicate": "複製",
    "Restore keymap item": "キーマップ項目を復元",
    "Roll": "ロール",
    "Rows": "行",
    "Search": "検索",
    "Setup Drawing": "描画設定",
    "Side (Y-Z)": "側面 (Y-Z)",
    "Simplify F-Curves": "Fカーブを簡略化",
    "Sort By": "並び替え基準",
    "Sort poses by name or category": "ポーズを名前またはカテゴリで並び替えます",
    "Split Editor": "エディター分割",
    "Square": "正方形",
    "Square aspect ratio (1.000)": "正方形のアスペクト比 (1.000)",
    "Stick stroke to other strokes": "ストロークを他のストロークに吸着",
    "Stick stroke to surfaces": "ストロークをサーフェスに吸着",
    "Stroke": "ストローク",
    "Subdivision": "細分化",
    "Surface": "サーフェス",
    "Swap": "入れ替え",
    "Swap two panels": "2つのパネルを入れ替えます",
    "Text": "テキスト",
    "Thickness of the lines": "線の太さ",
    "This is the only viewport!": "これが唯一のビューポートです！",
    "Timing:": "タイミング:",
    "Top": "上",
    "Top (X-Y)": "上面 (X-Y)",
    "Top To Bottom": "上から下",
    "Track To Constraint:": 'Track To コンストレイント：',
    "Tweak": "微調整",
    "Unique Data User": "単一データユーザー",
    "Up": "上へ",
    "Vertical spacing between pages": "ページ間の垂直間隔",
    "Visibility State": "表示状態",
    "Visible": "表示",
    "Visible and unlocked layers": "表示中でロックされていないレイヤー",
    "Visibles layers": "表示レイヤー",
    "Workspace:": "ワークスペース:",
    "square format (15 x 15)": "正方形形式 (15 x 15)",
    "In Camera view: Toggle 'lock camera to view' (active viewport)        \nIn free view: Go to camera (create new when none in scene)        \n+ Ctrl : Center and resize view to fit camera bounds        \n+ Shift : Match view zoom to render resolution": "カメラビューでは、現在のビューポートの「カメラをビューにロック」を切り替えます。\n自由ビューではカメラビューへ移動します。シーンにカメラがない場合は新規作成します。\n+ Ctrl: ビューを中央へ合わせ、カメラ範囲に収まるよう調整します。\n+ Shift: ビューのズームをレンダー解像度に合わせます。",
    "Add and place a new Grease Pencil object        \nClick to start modal then click again to place        \nAlternatively drag to position        \nShift: Place on ground level instead of camera view level": "新しい Grease Pencil オブジェクトを追加して配置します。\nクリックでモーダル配置を開始し、もう一度クリックして配置します。\nドラッグでも位置を指定できます。\nShift: カメラビュー基準ではなく地面レベルに配置します。",
    "Load a custom font for text objects            \nAllow use of Bold, Italic and Bold-Italic styles in notes            \nFont is packed into blend file to avoid linking issues": "テキストオブジェクト用のカスタムフォントを読み込みます。\nノートで太字、斜体、太字斜体を使用できるようにします。\nリンク切れを避けるため、フォントは blend ファイルへパックされます。",
    "Simplify the existing Curve based upon the chosen settings\nNotes: Needs an existing Curve object,\nOutputs a new Curve with the Simple prefix in the name": "選択した設定に基づいて既存のカーブを簡略化します。\n注意: 既存のカーブオブジェクトが必要です。\n名前に Simple プレフィックスが付いた新しいカーブを出力します。",
    "Create animatic scene from the current marker pages and storyboard frames        \nEverything is linked into an 'Animatic' scene to setup different camera markers": "現在のマーカーページとストーリーボードフレームからアニマティックシーンを作成します。\nすべてを「Animatic」シーンへリンクし、別のカメラマーカー構成を作成します。",
    "Dolly/vertigo zoom effect: change focal length while adapting camera position to compensate        \nFocus on active object or 3D cursor if there is None": "ドリー / バーティゴズーム効果です。焦点距離を変更しながら、見え方を補正するためにカメラ位置を調整します。\nアクティブオブジェクトを注視します。対象がない場合は 3D カーソルを注視します。",
    "Move object Forward/backward (Slide left-right)                    \n+ Ctrl : Adjust Scale (Retain same size in camera framing)                    \n+ Shift : Precision mode                    \n+ Alt : Constraint on horizontal plane": "オブジェクトを前後へ移動します（左右ドラッグでスライド）。\n+ Ctrl: スケールを調整し、カメラ構図内の見かけのサイズを保ちます。\n+ Shift: 精密モード。\n+ Alt: 水平平面に拘束します。",
    "Edit line opacity for newly created objects            \nSome users prefer to set it to 0 (show only selected line in edit mode)            \nBlender default is 0.5": "新規作成オブジェクトの編集線の不透明度を設定します。\n編集モードで選択線だけを表示したい場合は 0 にする運用もあります。\nBlender の初期値は 0.5 です。",
    "Generate a modulable storyboard grid        \nAdjust settings in redo panel        \nFor performance, set the number of pages after everything else (leave at 1 during setup)": "調整可能なストーリーボードグリッドを生成します。\n設定はリドゥパネルで調整します。\nパフォーマンスのため、ページ数は他の設定後に変更してください（設定中は 1 のままにします）。",
    "Setup current viewport as minimap        \nAdjust viewport settings so viewport is considered as minimap        \n(determined by viewport orientation and combination of tool-specific settings)": "現在のビューポートをミニマップとして設定します。\nこのビューポートがミニマップとして扱われるように表示設定を調整します。\n判定にはビューポートの向きとツール固有設定の組み合わせを使います。",
    "Name of Brush to set            \nIf it's a User brush, need to enter the relative asset path            \nExample: 'Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill'            \nEmpty field = no change": "設定するブラシの名前\nユーザーのブラシなら、アセットの相対パスを入力します\n例：'Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill'\n空欄は変更なし",
    "Define in wich layers keys should be added            \nand where to check for existing keys (offset if key already at current frame)": "どのレイヤーへキーを追加するかを指定します。\n既存キーの確認対象も指定します（現在フレームにキーがある場合はオフセットします）。",
    "On GP object: Switch between draw mode and object mode        \nEnter first GP object available or pop-up creation menu        \n+ Shift : pop-up creation menu": "Grease Pencil オブジェクトではドローモードとオブジェクトモードを切り替えます。\n使用可能な最初の Grease Pencil オブジェクトへ入るか、作成メニューを表示します。\n+ Shift: 作成メニューを表示します。",
    "Pan Camera, X/Y to lock on axis                    \n+ Shift : Precision mode                    \n+ Ctrl (During) : Autolock on moved axis                    \n+ Ctrl (Start) : Camera Shift instead of Pan": "カメラをパンします。X / Y で軸をロックします。\n+ Shift: 精密モード。\n+ Ctrl（操作中）: 移動軸を自動ロックします。\n+ Ctrl（開始時）: パンではなくカメラシフトを調整します。",
    "Create 'Track-to' constraint on camera, also known as 'Look at'        \nIf an empty is selected, used as target, else create a new empty": 'カメラに Track To コンストレイントを作成します（「注視」とも呼ばれます）\nエンプティを選択していれば対象に使い、無ければ新しいエンプティを作ります',
    "Reload the toolpreset topbar gizmos in viewport        \nNecessary if 'set draw tool' shortcuts have just been customized": "ビューポート内のツールプリセット用トップバーギズモを再読み込みします。\n「描画ツール設定」ショートカットを変更した直後に必要です。",
    "Translate active object, X/Y to lock on axis                    \n+ Ctrl : autolock on major axis                    \n+ Shift : Precision mode                    \n+ Alt : Constraint on horizontal plane": "アクティブオブジェクトを移動します。X / Y で軸をロックします。\n+ Ctrl: 主軸へ自動ロックします。\n+ Shift: 精密モード。\n+ Alt: 水平平面に拘束します。",
    "Use alternative pose names (PoseData.name_alt) instead of default pose names (mainly intended for translation purposes)": "標準のポーズ名ではなく、代替ポーズ名（PoseData.name_alt）を使用します。主に翻訳用途を想定しています。",
    "Frame offset to apply when creating new frame above an existing one            \nOr when applying offset to all subsequents frames": "既存フレームの上に新規フレームを作成するときに適用するフレームオフセットです。\n後続フレーム全体へオフセットを適用するときにも使います。",
    "Load a material palette on the current GP object        \nif material name already exists in scene it will uses these": "現在の Grease Pencil オブジェクトへマテリアルパレットを読み込みます。\n同名マテリアルがシーン内に既にある場合は、それを使用します。",
})


def _split_bilingual_pair(text):
    value = str(text or '')
    if not value:
        return None
    for sep in (' / ', ' ／ ', ' | ', ' ｜ ', '／', '｜'):
        if sep not in value:
            continue
        parts = [part.strip() for part in value.split(sep)]
        if len(parts) != 2 or not parts[0] or not parts[1]:
            continue
        left_is_ja = sas_has_japanese(parts[0])
        right_is_ja = sas_has_japanese(parts[1])
        if left_is_ja != right_is_ja:
            return (parts[1], parts[0]) if left_is_ja else (parts[0], parts[1])
    if value.count('/') + value.count('|') + value.count('／') + value.count('｜') == 1:
        parts = [part.strip() for part in _BILINGUAL_SEPARATOR_RE.split(value, maxsplit=1)]
        if len(parts) == 2 and parts[0] and parts[1]:
            left_is_ja = sas_has_japanese(parts[0])
            right_is_ja = sas_has_japanese(parts[1])
            if left_is_ja != right_is_ja:
                return (parts[1], parts[0]) if left_is_ja else (parts[0], parts[1])
    return None


def _english_from_japanese(ja_text):
    value = str(ja_text or '').strip()
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[0]
    for en, ja in _iter_translation_pairs(include_dynamic=True):
        if str(ja or '').strip() == value:
            return str(en or '').strip()
    templated = _translate_template_to_english(value)
    if templated:
        return templated
    return value


def sas_source_text(text, context=None):
    value = str(text or '')
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[0]
    if sas_has_japanese(value):
        return _english_from_japanese(value)
    return value


def sas_english_source_text(text, context=None):
    return sas_source_text(text, context)


def sas_target_japanese(text):
    value = str(text or '')
    if not value:
        return value
    pair = _split_bilingual_pair(value)
    if pair:
        return pair[1]
    if sas_has_japanese(value):
        return value
    translated = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
    if translated:
        return str(translated)
    templated = _translate_template_to_japanese(value)
    if templated:
        return templated
    return str(_translate_dynamic_phrase_to_japanese(value) or _localize_dynamic_prefix_text(value, None) or value)


def sas_translate_text(text, context=None, *, split_bilingual=True):
    value = str(text or '')
    if split_bilingual:
        pair = _split_bilingual_pair(value)
        if pair:
            value = pair[1] if sas_is_japanese(context) else pair[0]
        else:
            value = _select_bilingual_variant(value, context)
    if not value:
        return value
    if sas_is_japanese(context):
        translated = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
        if translated:
            return str(translated)
        templated = _translate_template_to_japanese(value)
        if templated and templated != value:
            return templated
        dynamic = _translate_dynamic_phrase_to_japanese(value)
        if dynamic and dynamic != value:
            return dynamic
        return _localize_dynamic_prefix_text(value, context)
    if sas_has_japanese(value):
        templated = _translate_template_to_english(value)
        if templated and templated != value:
            return templated
        converted = _english_from_japanese(value)
        if converted != value:
            return converted
        return _localize_dynamic_prefix_text(value, context)
    return _localize_dynamic_prefix_text(value, context)


def sas_localize_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


def sanitize_bilingual_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


def register_dynamic_ui_translations(texts):
    changed = False
    for item in texts or ():
        value = str(item or '').strip()
        if not value:
            continue
        pair = _split_bilingual_pair(value)
        if pair is not None:
            en_text, ja_text = pair
        elif sas_has_japanese(value):
            ja_text = value
            en_text = _english_from_japanese(value)
            if not en_text or en_text == ja_text:
                continue
        else:
            en_text = value
            ja_text = _dynamic_ja_for_text(value)
            if not ja_text:
                continue
        en_text = str(en_text or '').strip()
        ja_text = str(ja_text or '').strip()
        if not en_text or not ja_text or en_text == ja_text:
            continue
        if _DYNAMIC_JA_TRANSLATIONS.get(en_text) == ja_text:
            continue
        _DYNAMIC_JA_TRANSLATIONS[en_text] = ja_text
        changed = True
    if not changed:
        return
    try:
        bpy.app.translations.unregister(_DYNAMIC_TRANSLATION_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_DYNAMIC_TRANSLATION_OWNER, _build_translation_table(include_dynamic=True))
    except Exception:
        pass



JA_TRANSLATIONS.update({
    "Animation Recipes": "アニメーション レシピ",
    "Smart Recipe": "Smart レシピ",
    "Choose the upgraded Animation Recipe to run. Each recipe is a Blender-native equivalent of one or more researched animation-assistance tools, such as animBot, BroDynamics, MotionBuilder Story, Cascadeur AutoPhysics, or Cinema 4D Signal.": "実行する アニメーション レシピ の上位互換レシピを選びます。各レシピは animBot、BroDynamics、MotionBuilder Story、Cascadeur AutoPhysics、Cinema 4D Signal など、調査済みアニメーション補助ツールの1つ以上に相当する Blender 内蔵ワークフローです。",
    "Coverage Text": "対応表テキスト",
    "Text datablock name used when Animation Recipes writes the feature coverage report that maps every researched source function to its built-in equivalent.": "アニメーション レシピ が、調査元機能と内蔵相当機能の対応表を書き出すときに使うテキストデータブロック名です。",
    "Motion Director Mode": "モーションディレクターモード",
    "Choose which animBot/AnimAide-style pose refinement pass Smart Motion Director runs. Full Director runs tween, push/pull, and scale-to-neighbor in sequence.": "Smart Motion Director が実行する animBot / AnimAide 風のポーズ調整処理を選びます。フルディレクターではトゥイーン、プッシュ / プル、近隣スケールを順に実行します。",
    "Graph Include Unbake": "グラフにアンベイクを含める",
    "When enabled, Smart Graph Optimizer also runs Smart Unbake after safer cleanup passes, reducing dense baked curves into editable keyframes where possible.": "有効にすると、Smart Graph Optimizer が安全な整理処理の後に Smart Unbake も実行し、高密度ベイク済みカーブを可能な範囲で編集しやすいキーへ減らします。",
    "Graph Auto Clamped Handles": "グラフハンドルを自動クランプ",
    "After Smart Graph Optimizer runs, set edited key handles to Auto Clamped Bezier so smoothed curves avoid common overshoot while staying editable.": "Smart Graph Optimizer の実行後、編集済みキーのハンドルを自動クランプベジェにし、編集性を保ちながら一般的なオーバーシュートを抑えます。",
    "Visualizer Mode": "可視化モード",
    "Choose which motion review helpers Smart Visualize Motion creates: trails and ghosts, motion paths, ballistic guides, or all supported helpers.": "Smart Visualize Motion が作成する確認用ヘルパーを選びます。トレイルとゴースト、モーションパス、弾道ガイド、または対応する全ヘルパーを作成できます。",
    "Physics Director Mode": '物理ディレクターのモード',
    "Choose the Cascadeur/BroDynamics-style physics-assist pass: automatic safe mix, ballistic guide, ballistic bake, fulcrum contact cleanup, spring motion, or rigid-body bake.": "Cascadeur / BroDynamics 風の物理補助処理を選びます。自動安全ミックス、弾道ガイド、弾道ベイク、支点接地整理、スプリングモーション、剛体ベイクを選択できます。",
    "Locomotion Axis": "ロコモーション軸",
    "World axis used as the forward travel direction when Smart Locomotion generates editable cyclic movement keys.": "Smart Locomotion が編集可能なサイクル移動キーを生成するときの前進方向ワールド軸です。",
    "Locomotion Distance": "ロコモーション距離",
    "Total travel distance written over the selected bake range by the Smart Locomotion generator.": "Smart Locomotion 生成機能が選択ベイク範囲へ書き込む総移動距離です。",
    "Locomotion Cycle": "ロコモーション周期",
    "Cycle length in frames used by Smart Locomotion for bobbing and optional loop helper timing.": "Smart Locomotion が上下動と任意のループ補助タイミングに使う周期フレーム数です。",
    "Locomotion Bob": "ロコモーション上下動",
    "Vertical bob amount added to generated Smart Locomotion keys. Use 0 for straight mechanical movement.": "生成される Smart Locomotion キーへ加える上下動量です。機械的な直線移動にしたい場合は 0 にします。",
    "Locomotion Yaw": "ロコモーションヨー",
    "Optional side-to-side yaw amount in degrees for generated Smart Locomotion keys. Use 0 to keep rotation unchanged.": "生成される Smart Locomotion キーに追加する左右ヨー量です。回転を変えない場合は 0 にします。",
    "Add Cycle Modifier": "サイクルモディファイアを追加",
    "After Smart Locomotion writes keys, add Cycles modifiers to generated curves so the base motion can repeat like CMotion-style procedural movement.": "Smart Locomotion がキーを書き込んだ後、生成カーブにサイクルモディファイアを追加し、CMotion 風のプロシージャル移動のように繰り返せるようにします。",
    "IFL Start": "IFL 開始",
    "Start frame applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する開始フレームです。",
    "IFL Duration": "IFL 長さ",
    "Playback duration in frames applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する再生長です。",
    "IFL Offset": "IFL オフセット",
    "Frame offset applied to image texture sequence users. Key this value to synchronize monitor screens or 2D effects with animation timing.": "画像テクスチャシーケンスユーザーへ適用するフレームオフセットです。モニター画面や2Dエフェクトをアニメーションタイミングと同期する場合は、この値へキーを打ちます。",
    "IFL Cyclic": "IFL 循環",
    "Enable cyclic playback on compatible image texture sequence users.": "対応する画像テクスチャシーケンスユーザーで循環再生を有効にします。",
    "Key IFL Offset": "IFL オフセットにキー",
    "Insert a keyframe on the image sequence frame offset at the current frame after applying IFL settings.": "IFL 設定の適用後、現在フレームで画像シーケンスのフレームオフセットにキーを挿入します。",
    "Shape Control Prefix": "シェイプ制御接頭辞",
    "Prefix used for the custom properties created by Smart Shape Control Mixer. These properties drive matching shape-key values and can be keyed like normal controls.": "Smart Shape Control Mixer が作成するカスタムプロパティの接頭辞です。これらのプロパティは対応するシェイプキー値を駆動し、通常の制御と同じようにキーを打てます。",
    "Smart Feature Coverage Report": "Smart 機能対応表",
    "Smart Graph Optimizer": "Smart グラフ最適化",
    "Smart Motion Director": 'スマートモーションディレクター',
    "Smart Visualize Motion": 'スマートモーション可視化',
    "Smart Physics Director": 'スマート物理ディレクター',
    "Generate Smart Locomotion Cycle": "Smart ロコモーションサイクル生成",
    "Smart Image Sequence Manager": "Smart 画像シーケンス管理",
    "Smart Shape Control Mixer": "Smart シェイプ制御ミキサー",
    "Smart AutoPose Assistant": "Smart AutoPose アシスタント",
    "Smart Retarget Director": "Smart リターゲットディレクター",
    "Run Animation Recipe": "アニメーション レシピ実行",
})


JA_TRANSLATIONS.update({
    "Smart Precision Profile": "Smart 精度プロファイル",
    "Choose how strongly Animation Recipes removes visually redundant keys during adaptive cleanup. Safe preserves the most hand-made detail, Balanced suits most production shots, and Aggressive is intended for dense baked data.": "適応整理で、視覚的に不要なキーをどの程度削減するかを選びます。Safe は手付けの細部を最も多く残し、Balanced は多くの制作ショット向け、Aggressive は高密度ベイクデータ向けです。",
    "Adaptive Precision": "適応精度",
    "Enable range-aware sparse-key cleanup inside Smart Graph Optimizer and Precision Polish. The pass preserves endpoints and obvious extremes while reducing redundant in-between keys.": "Smart Graph Optimizer と Precision Polish 内で、値幅に応じた疎キー整理を有効にします。端点と明確な極値を保持しながら、冗長な中間キーを削減します。",
    "Preserve Flow Handles": "流れ保持ハンドル",
    "After Motion Director creates or adjusts keys, set editable Bezier handles to Auto Clamped so pose changes keep smooth spacing without common overshoot artifacts.": "Motion Director がキーを作成または調整した後、編集可能なベジェハンドルを自動クランプにして、一般的なオーバーシュートを抑えつつ滑らかなスペーシングを保ちます。",
    "Quality Report Text": "品質レポートテキスト",
    "Text datablock name used when Smart Quality Report writes key density, duplicate, static-channel, Euler, and spacing diagnostics into the current Blender file.": "Smart Quality Report がキー密度、重複、静的チャンネル、オイラー、スペーシング診断を現在の Blender ファイルへ書き込むときのテキストデータブロック名です。",
    "Quality Sample Step": "品質サンプル間隔",
    "Frame interval used when Smart Quality Report samples selected object motion to estimate maximum speed and acceleration. Smaller values are more precise but slower on long scenes.": "Smart Quality Report が選択オブジェクトの動きをサンプリングし、最大速度と加速度を見積もる際のフレーム間隔です。小さい値ほど精密ですが、長いシーンでは遅くなります。",
    "Locomotion Style": "ロコモーションスタイル",
    "Choose the procedural blocking style used by Smart Locomotion. Walk, Run, Mechanical, and Cinematic produce different bob, yaw, and travel-ease patterns while still writing ordinary editable keys.": "Smart Locomotion が使うプロシージャルなブロッキングスタイルを選びます。Walk、Run、Mechanical、Cinematic は上下動、ヨー、移動イーズの異なるパターンを作り、結果は通常の編集可能キーとして書き込まれます。",
    "IFL Match Scene Range": "IFL をシーン範囲に合わせる",
    "Before applying image-sequence timing, copy the current scene frame start and frame duration into the IFL start and duration settings so monitor or 2D-effect playback matches the shot length.": "画像シーケンスタイミングの適用前に、現在のシーン開始フレームと長さを IFL の開始と長さへ反映し、モニター表示や2Dエフェクト再生をショット尺に合わせます。",
    "Key Shape Controls": "シェイプ制御にキー",
    "When creating or refreshing Smart Shape Control drivers, also insert a keyframe on each generated custom property at the current frame. This makes the controls immediately visible in the Dope Sheet and Graph Editor.": "Smart Shape Control ドライバーの作成または更新時に、生成された各カスタムプロパティへ現在フレームでキーを挿入します。これにより、制御がドープシートとグラフエディターですぐ確認できます。",
    "Smart Quality Report": "Smart 品質レポート",
    "Smart Precision Polish": "Smart 精密ポリッシュ",
    "Run adaptive cleanup, flow-safe handles, sparse unbake, and quality reporting in one pass.": "適応整理、流れを保つハンドル、疎キー化アンベイク、品質レポートを1回で実行します。",
    "Analyze key density, duplicate keys, static channels, Euler jumps, spacing speed, and polish risks.": "キー密度、重複キー、静的チャンネル、オイラー飛び、スペーシング速度、ポリッシュリスクを解析します。",
    "Safe": "安全",
    "Balanced": "バランス",
    "Aggressive": "強め",
    "Walk": "歩き",
    "Run": "走り",
    "Mechanical": "機械的",
    "Cinematic": "シネマティック",
    "Precision": "精度",
    "Adaptive": "適応",
    "Precision Polish": "精密ポリッシュ",
    "Quality": "品質診断",
    "Report": "レポート",
    "Style": "スタイル",
    "Key Controls": "制御にキー",
    "Match Scene": "シーン一致",
    "Use conservative adaptive cleanup and preserve more keys for hand-polished shots.": "保守的な適応整理を使い、手付けで磨いたショットのキーをより多く残します。",
    "Use balanced adaptive cleanup for most mocap, retarget, and hand-keyed shots.": "多くのモーキャプ、リターゲット、手付けショットに適したバランス型の適応整理を使います。",
    "Remove more visually redundant keys after dense baking while preserving extremes.": "極値を保ちながら、高密度ベイク後の視覚的に冗長なキーをより多く削除します。",
    "Two contact-like bobs per cycle for a walk-style blocking base.": "歩き風のブロッキングベースとして、1周期に2回の接地感ある上下動を作ります。",
    "One stronger airborne bounce per cycle for a run or jumpy action base.": "走りや跳ねる動作用のベースとして、1周期に1回の強めの浮遊上下動を作ります。",
    "Linear mechanical travel without bob or yaw swing.": "上下動やヨー揺れのない、機械的な直線移動を作ります。",
    "Smooth-eased travel inside each cycle for director-friendly blocking.": "各周期内でイーズ付きの移動を作り、演出確認しやすいブロッキングにします。",
})

TRANSLATIONS = _build_translation_table(include_dynamic=False)

# Last-resort cleanup for legacy bundled add-on translations that were generated
# from English sources. This prevents machine-mixed Japanese/English tooltips from
# leaking when Blender is set to Japanese, while keeping proper tool names intact.
_MIXED_TRANSLATION_RE = re.compile(r"[A-Za-z]{4,}")
_TRANSLATION_KEEP_WORDS = {
    'Blender', 'Smart', 'Animation', 'Toolset', 'Smart Animation', 'Storytools',
    'Grease', 'Pencil', 'Bezier', 'Sakura', 'PoseLib', 'AnimAll', 'EaseIt',
    'Camera', 'Shakify', 'Action', 'Slot', 'F-Curve', 'F-Curves', 'NLA',
    'MMD', 'PMX', 'UV', 'BPM', 'Ctrl', 'Shift', 'Alt', 'None', 'Track', 'To',
}
_PHRASE_JA_FALLBACKS = {
    "Setup current viewport as minimap        \nAdjust viewport settings so viewport is considered as minimap        \n(determined by viewport orientation and combination of tool-settings": "現在のビューポートをミニマップとして設定します。\nこのビューポートがミニマップとして扱われるように表示設定を調整します。\nビューポートの向きとツール設定の組み合わせで判定します。",
    "Pan Camera, X/Y to lock on axis                    \n+ Shift : Precision mode                    \n+ Ctrl (During) : Autolock on moved axis                    \n+ Ctrl (Start) : Camera Shift instead of Pan                    \n+ Alt  (During Shift): Snap to half-frame offset": "カメラをパンします。X / Y で軸をロックします。\n+ Shift: 精密モード。\n+ Ctrl（操作中）: 移動軸を自動ロックします。\n+ Ctrl（開始時）: パンではなくカメラシフトを調整します。\n+ Alt（Shift中）: 半フレームオフセットへスナップします。",
    "Add a tool preset shortcut in user keymap        \nAdd new keymap entry: Grease pencil > Grease Pencil Draw Mode        \nWith operator idname 'storytools.set_draw_tool' and default value": "ユーザーキーマップへツールプリセットのショートカットを追加します。\n新しいキーマップ項目を Grease Pencil > Grease Pencil Draw Mode に追加します。\nオペレーター ID 名は 'storytools.set_draw_tool'、値は初期値を使います。",
    "Show object user data when object has multiple user (when object have multiple users)": "オブジェクトに複数ユーザーがある場合、オブジェクトユーザーデータを表示します。",
    "Material to set (exact name, case sensitive)            \nEmpty field = No change or use layer-material synchronisation if enabled": "設定するマテリアル名です（完全一致・大文字小文字を区別）。\n空欄の場合は変更しないか、有効な場合はレイヤー・マテリアル同期を使用します。",
    "Add a track to constraint pointing at active camera            \nThis makes object's always face camera": 'アクティブカメラを向く Track To コンストレイントを追加します\nオブジェクトが常にカメラの方を向きます',
    "Snap 3D Cursor        \nClick: Cursor to selected        \nShift + Click: Send Selection to cursor        \nClick-Drag: Cursor on GP drawing plane or geometry": "3Dカーソルをスナップします。\nクリック: カーソルを選択物へ移動。\nShift + クリック: 選択物をカーソルへ移動。\nクリックドラッグ: Grease Pencil の描画平面またはジオメトリ上にカーソルを配置します。",
    "Choose if layers should have use light on when creating a grease pencil object using N-panel section": "Nパネル表示で Grease Pencil オブジェクトを作成するとき、レイヤーでライト使用を有効にするかを選びます。",
    "Simplify selected Curves\nDoes not operate on short Splines (less than 3 points)": "選択したカーブを簡略化します。\n短いスプライン（3点未満）は処理しません。",
    "Move Camera Depth (forward and backward)        \n+ Alt : Lock Z axis movements (After call)        \n+ Ctrl : Adjust focal length / orthographic scale": "カメラの奥行きを前後に移動します。\n+ Alt: 呼び出し後に Z 軸移動をロックします。\n+ Ctrl: 焦点距離または平行投影スケールを調整します。",
    "Locked Pan, a wrapper for pan operation                    \nOnly valid when viewport has locked rotation (region_3d.lock_rotation)": "ロック付きパン操作です。\nビューポートの回転がロックされている場合（region_3d.lock_rotation）のみ有効です。",
    "Align object with view        \n+ Ctrl : Also set object Z axis pointing up        \n+ Shift : Bring in front of camera": "オブジェクトをビューに合わせます。\n+ Ctrl: オブジェクトの Z 軸も上向きにします。\n+ Shift: カメラの前へ移動します。",
    "Jump to prev/next keyframe on active and selected layers of active grease pencil object": "アクティブな Grease Pencil オブジェクトのアクティブレイヤーと選択レイヤーで、前後のキーフレームへ移動します。",
    "Create object at cursor location, else centered position at cursor 'distance' facing view": "カーソル位置にオブジェクトを作成します。無効な場合は、ビュー方向を向いたままカーソル距離の中央位置に作成します。",
    "Choose if layer autolock is enabled when creating a grease pencil object using N-panel section": "Nパネル表示で Grease Pencil オブジェクトを作成するとき、レイヤー自動ロックを有効にするかを選びます。",
}
_WORD_JA_REPLACEMENTS = (
    ('Grease Pencil', 'Grease Pencil'), ('grease pencil', 'Grease Pencil'),
    ('keyframes', 'キーフレーム'), ('keyframe', 'キーフレーム'),
    ('viewport', 'ビューポート'), ('viewports', 'ビューポート'), ('view', 'ビュー'),
    ('camera', 'カメラ'), ('cameras', 'カメラ'), ('object', 'オブジェクト'), ('objects', 'オブジェクト'),
    ('selected', '選択済み'), ('active', 'アクティブ'), ('layer', 'レイヤー'), ('layers', 'レイヤー'),
    ('material', 'マテリアル'), ('materials', 'マテリアル'), ('frame', 'フレーム'), ('frames', 'フレーム'),
    ('cursor', 'カーソル'), ('mode', 'モード'), ('draw', '描画'), ('edit', '編集'), ('sculpt', 'スカルプト'),
    ('shortcut', 'ショートカット'), ('shortcuts', 'ショートカット'), ('keymap', 'キーマップ'),
    ('entry', '項目'), ('operator', 'オペレーター'), ('idname', 'ID名'),
    ('constraint', 'コンストレイント'), ('axis', '軸'), ('horizontal', '水平'), ('vertical', '垂直'),
    ('position', '位置'), ('location', '位置'), ('rotation', '回転'), ('scale', 'スケール'),
    ('opacity', '不透明度'), ('transparency', '透明度'), ('settings', '設定'), ('setting', '設定'),
    ('preset', 'プリセット'), ('presets', 'プリセット'), ('toolbar', 'ツールバー'), ('topbar', 'トップバー'),
    ('gizmo', 'ギズモ'), ('gizmos', 'ギズモ'), ('selection', '選択'), ('empty', 'Empty'),
    ('collection', 'コレクション'), ('collections', 'コレクション'), ('visibility', '表示状態'),
    ('visible', '表示'), ('hidden', '非表示'), ('locked', 'ロック'), ('unlocked', 'ロック解除'),
    ('render', 'レンダー'), ('resolution', '解像度'), ('font', 'フォント'), ('text', 'テキスト'),
    ('line', '線'), ('lines', '線'), ('page', 'ページ'), ('pages', 'ページ'), ('panel', 'パネル'), ('panels', 'パネル'),
    ('grid', 'グリッド'), ('row', '行'), ('rows', '行'), ('column', '列'), ('columns', '列'),
    ('marker', 'マーカー'), ('markers', 'マーカー'), ('storyboard', 'ストーリーボード'), ('animatic', 'アニマティック'),
    ('create', '作成'), ('creating', '作成'), ('add', '追加'), ('remove', '削除'), ('delete', '削除'),
    ('show', '表示'), ('hide', '非表示'), ('toggle', '切り替え'), ('switch', '切り替え'), ('set', '設定'),
    ('move', '移動'), ('translate', '移動'), ('rotate', '回転'), ('snap', 'スナップ'), ('align', '整列'),
    ('select', '選択'), ('load', '読み込み'), ('save', '保存'), ('reload', '再読み込み'),
    ('enable', '有効化'), ('enabled', '有効'), ('disable', '無効化'), ('disabled', '無効'),
    ('adjust', '調整'), ('generate', '生成'), ('use', '使用'), ('using', '使用'), ('apply', '適用'),
    ('current', '現在の'), ('new', '新規'), ('existing', '既存'), ('default', '初期値'),
    ('name', '名前'), ('names', '名前'), ('path', 'パス'), ('asset', 'アセット'),
    ('precision', '精密'), ('during', '操作中'), ('start', '開始'), ('click', 'クリック'), ('drag', 'ドラッグ'),
)


def _translation_looks_machine_mixed(source, translated):
    text = str(translated or '')
    if not text or not sas_has_japanese(text):
        return False
    words = _MIXED_TRANSLATION_RE.findall(text)
    suspicious = [word for word in words if word not in _TRANSLATION_KEEP_WORDS and not (word.upper() == word and len(word) <= 5)]
    return ('に関する設定です' in text and bool(suspicious)) or len(suspicious) >= 6


def _fallback_translate_english_to_japanese(value):
    source = str(value or '')
    if not source:
        return source
    exact = _PHRASE_JA_FALLBACKS.get(source)
    if exact:
        return exact
    # Do not alter compact identifiers, operator ids, or proper tool names.
    if re.fullmatch(r'[A-Za-z0-9_.:+\- ]{1,32}', source) and not any(ch in source for ch in (' ', ':')):
        return source
    text = source.replace('        ', '\n').replace('    ', '\n')
    replacements = sorted(_WORD_JA_REPLACEMENTS, key=lambda item: len(item[0]), reverse=True)
    for en, ja in replacements:
        text = re.sub(r'(?<![A-Za-z])' + re.escape(en) + r'(?![A-Za-z])', ja, text, flags=re.IGNORECASE)
    text = re.sub(r'\bto\b', 'へ', text, flags=re.IGNORECASE)
    text = re.sub(r'\bfrom\b', 'から', text, flags=re.IGNORECASE)
    text = re.sub(r'\band\b', 'と', text, flags=re.IGNORECASE)
    text = re.sub(r'\bor\b', 'または', text, flags=re.IGNORECASE)
    text = re.sub(r'\bif\b', 'もし', text, flags=re.IGNORECASE)
    text = re.sub(r'\bwhen\b', 'の場合', text, flags=re.IGNORECASE)
    text = re.sub(r'\n{3,}', '\n', text)
    return text.strip()


_previous_sas_translate_text = sas_translate_text

def sas_translate_text(text, context=None, *, split_bilingual=True):
    value = str(text or '')
    if split_bilingual:
        pair = _split_bilingual_pair(value)
        if pair:
            value = pair[1] if sas_is_japanese(context) else pair[0]
        else:
            value = _select_bilingual_variant(value, context)
    if not value:
        return value
    if sas_is_japanese(context):
        translated = JA_TRANSLATIONS.get(value) or _DYNAMIC_JA_TRANSLATIONS.get(value)
        if translated:
            if _translation_looks_machine_mixed(value, translated):
                fallback = _fallback_translate_english_to_japanese(value)
                if fallback and fallback != value and sas_has_japanese(fallback):
                    return fallback
            return str(translated)
        templated = _translate_template_to_japanese(value)
        if templated and templated != value:
            return templated
        dynamic = _translate_dynamic_phrase_to_japanese(value)
        if dynamic and dynamic != value:
            return dynamic
        fallback = _fallback_translate_english_to_japanese(value)
        if fallback and fallback != value and sas_has_japanese(fallback):
            return fallback
        return _localize_dynamic_prefix_text(value, context)
    if sas_has_japanese(value):
        templated = _translate_template_to_english(value)
        if templated and templated != value:
            return templated
        converted = _english_from_japanese(value)
        if converted != value:
            return converted
        return _localize_dynamic_prefix_text(value, context)
    return _localize_dynamic_prefix_text(value, context)


def sas_localize_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


def sanitize_bilingual_text(text, context=None):
    return sas_translate_text(text, context, split_bilingual=True)


JA_TRANSLATIONS.update({
    ' x {}': ' x {}',
    'F_{}': 'F_{}',
    '{}+_bonemorph': '{}+_bonemorph',
    '{}_Build': '{}_Build',
    '{}_target': '{}_target',
    '{}_{}': '{}_{}',
})


JA_TRANSLATIONS.update({
    "Animation Recipes": "アニメーション レシピ",
    "Smart Recipe": "Smart レシピ",
    "Choose the upgraded Animation Recipe to run. Each recipe is a Blender-native equivalent of one or more researched animation-assistance tools, such as animBot, BroDynamics, MotionBuilder Story, Cascadeur AutoPhysics, or Cinema 4D Signal.": "実行する アニメーション レシピ の上位互換レシピを選びます。各レシピは animBot、BroDynamics、MotionBuilder Story、Cascadeur AutoPhysics、Cinema 4D Signal など、調査済みアニメーション補助ツールの1つ以上に相当する Blender 内蔵ワークフローです。",
    "Coverage Text": "対応表テキスト",
    "Text datablock name used when Animation Recipes writes the feature coverage report that maps every researched source function to its built-in equivalent.": "アニメーション レシピ が、調査元機能と内蔵相当機能の対応表を書き出すときに使うテキストデータブロック名です。",
    "Motion Director Mode": "モーションディレクターモード",
    "Choose which animBot/AnimAide-style pose refinement pass Smart Motion Director runs. Full Director runs tween, push/pull, and scale-to-neighbor in sequence.": "Smart Motion Director が実行する animBot / AnimAide 風のポーズ調整処理を選びます。フルディレクターではトゥイーン、プッシュ / プル、近隣スケールを順に実行します。",
    "Graph Include Unbake": "グラフにアンベイクを含める",
    "When enabled, Smart Graph Optimizer also runs Smart Unbake after safer cleanup passes, reducing dense baked curves into editable keyframes where possible.": "有効にすると、Smart Graph Optimizer が安全な整理処理の後に Smart Unbake も実行し、高密度ベイク済みカーブを可能な範囲で編集しやすいキーへ減らします。",
    "Graph Auto Clamped Handles": "グラフハンドルを自動クランプ",
    "After Smart Graph Optimizer runs, set edited key handles to Auto Clamped Bezier so smoothed curves avoid common overshoot while staying editable.": "Smart Graph Optimizer の実行後、編集済みキーのハンドルを自動クランプベジェにし、編集性を保ちながら一般的なオーバーシュートを抑えます。",
    "Visualizer Mode": "可視化モード",
    "Choose which motion review helpers Smart Visualize Motion creates: trails and ghosts, motion paths, ballistic guides, or all supported helpers.": "Smart Visualize Motion が作成する確認用ヘルパーを選びます。トレイルとゴースト、モーションパス、弾道ガイド、または対応する全ヘルパーを作成できます。",
    "Physics Director Mode": '物理ディレクターのモード',
    "Choose the Cascadeur/BroDynamics-style physics-assist pass: automatic safe mix, ballistic guide, ballistic bake, fulcrum contact cleanup, spring motion, or rigid-body bake.": "Cascadeur / BroDynamics 風の物理補助処理を選びます。自動安全ミックス、弾道ガイド、弾道ベイク、支点接地整理、スプリングモーション、剛体ベイクを選択できます。",
    "Locomotion Axis": "ロコモーション軸",
    "World axis used as the forward travel direction when Smart Locomotion generates editable cyclic movement keys.": "Smart Locomotion が編集可能なサイクル移動キーを生成するときの前進方向ワールド軸です。",
    "Locomotion Distance": "ロコモーション距離",
    "Total travel distance written over the selected bake range by the Smart Locomotion generator.": "Smart Locomotion 生成機能が選択ベイク範囲へ書き込む総移動距離です。",
    "Locomotion Cycle": "ロコモーション周期",
    "Cycle length in frames used by Smart Locomotion for bobbing and optional loop helper timing.": "Smart Locomotion が上下動と任意のループ補助タイミングに使う周期フレーム数です。",
    "Locomotion Bob": "ロコモーション上下動",
    "Vertical bob amount added to generated Smart Locomotion keys. Use 0 for straight mechanical movement.": "生成される Smart Locomotion キーへ加える上下動量です。機械的な直線移動にしたい場合は 0 にします。",
    "Locomotion Yaw": "ロコモーションヨー",
    "Optional side-to-side yaw amount in degrees for generated Smart Locomotion keys. Use 0 to keep rotation unchanged.": "生成される Smart Locomotion キーに追加する左右ヨー量です。回転を変えない場合は 0 にします。",
    "Add Cycle Modifier": "サイクルモディファイアを追加",
    "After Smart Locomotion writes keys, add Cycles modifiers to generated curves so the base motion can repeat like CMotion-style procedural movement.": "Smart Locomotion がキーを書き込んだ後、生成カーブにサイクルモディファイアを追加し、CMotion 風のプロシージャル移動のように繰り返せるようにします。",
    "IFL Start": "IFL 開始",
    "Start frame applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する開始フレームです。",
    "IFL Duration": "IFL 長さ",
    "Playback duration in frames applied to image texture sequence users by Smart Image Sequence Manager.": "Smart Image Sequence Manager が画像テクスチャシーケンスユーザーへ適用する再生長です。",
    "IFL Offset": "IFL オフセット",
    "Frame offset applied to image texture sequence users. Key this value to synchronize monitor screens or 2D effects with animation timing.": "画像テクスチャシーケンスユーザーへ適用するフレームオフセットです。モニター画面や2Dエフェクトをアニメーションタイミングと同期する場合は、この値へキーを打ちます。",
    "IFL Cyclic": "IFL 循環",
    "Enable cyclic playback on compatible image texture sequence users.": "対応する画像テクスチャシーケンスユーザーで循環再生を有効にします。",
    "Key IFL Offset": "IFL オフセットにキー",
    "Insert a keyframe on the image sequence frame offset at the current frame after applying IFL settings.": "IFL 設定の適用後、現在フレームで画像シーケンスのフレームオフセットにキーを挿入します。",
    "Shape Control Prefix": "シェイプ制御接頭辞",
    "Prefix used for the custom properties created by Smart Shape Control Mixer. These properties drive matching shape-key values and can be keyed like normal controls.": "Smart Shape Control Mixer が作成するカスタムプロパティの接頭辞です。これらのプロパティは対応するシェイプキー値を駆動し、通常の制御と同じようにキーを打てます。",
    "Smart Feature Coverage Report": "Smart 機能対応表",
    "Smart Graph Optimizer": "Smart グラフ最適化",
    "Smart Motion Director": 'スマートモーションディレクター',
    "Smart Visualize Motion": 'スマートモーション可視化',
    "Smart Physics Director": 'スマート物理ディレクター',
    "Generate Smart Locomotion Cycle": "Smart ロコモーションサイクル生成",
    "Smart Image Sequence Manager": "Smart 画像シーケンス管理",
    "Smart Shape Control Mixer": "Smart シェイプ制御ミキサー",
    "Smart AutoPose Assistant": "Smart AutoPose アシスタント",
    "Smart Retarget Director": "Smart リターゲットディレクター",
    "Run Animation Recipe": "アニメーション レシピ実行",
})


JA_TRANSLATIONS.update({
    "Smart Precision Profile": "Smart 精度プロファイル",
    "Choose how strongly Animation Recipes removes visually redundant keys during adaptive cleanup. Safe preserves the most hand-made detail, Balanced suits most production shots, and Aggressive is intended for dense baked data.": "適応整理で、視覚的に不要なキーをどの程度削減するかを選びます。Safe は手付けの細部を最も多く残し、Balanced は多くの制作ショット向け、Aggressive は高密度ベイクデータ向けです。",
    "Adaptive Precision": "適応精度",
    "Enable range-aware sparse-key cleanup inside Smart Graph Optimizer and Precision Polish. The pass preserves endpoints and obvious extremes while reducing redundant in-between keys.": "Smart Graph Optimizer と Precision Polish 内で、値幅に応じた疎キー整理を有効にします。端点と明確な極値を保持しながら、冗長な中間キーを削減します。",
    "Preserve Flow Handles": "流れ保持ハンドル",
    "After Motion Director creates or adjusts keys, set editable Bezier handles to Auto Clamped so pose changes keep smooth spacing without common overshoot artifacts.": "Motion Director がキーを作成または調整した後、編集可能なベジェハンドルを自動クランプにして、一般的なオーバーシュートを抑えつつ滑らかなスペーシングを保ちます。",
    "Quality Report Text": "品質レポートテキスト",
    "Text datablock name used when Smart Quality Report writes key density, duplicate, static-channel, Euler, and spacing diagnostics into the current Blender file.": "Smart Quality Report がキー密度、重複、静的チャンネル、オイラー、スペーシング診断を現在の Blender ファイルへ書き込むときのテキストデータブロック名です。",
    "Quality Sample Step": "品質サンプル間隔",
    "Frame interval used when Smart Quality Report samples selected object motion to estimate maximum speed and acceleration. Smaller values are more precise but slower on long scenes.": "Smart Quality Report が選択オブジェクトの動きをサンプリングし、最大速度と加速度を見積もる際のフレーム間隔です。小さい値ほど精密ですが、長いシーンでは遅くなります。",
    "Locomotion Style": "ロコモーションスタイル",
    "Choose the procedural blocking style used by Smart Locomotion. Walk, Run, Mechanical, and Cinematic produce different bob, yaw, and travel-ease patterns while still writing ordinary editable keys.": "Smart Locomotion が使うプロシージャルなブロッキングスタイルを選びます。Walk、Run、Mechanical、Cinematic は上下動、ヨー、移動イーズの異なるパターンを作り、結果は通常の編集可能キーとして書き込まれます。",
    "IFL Match Scene Range": "IFL をシーン範囲に合わせる",
    "Before applying image-sequence timing, copy the current scene frame start and frame duration into the IFL start and duration settings so monitor or 2D-effect playback matches the shot length.": "画像シーケンスタイミングの適用前に、現在のシーン開始フレームと長さを IFL の開始と長さへ反映し、モニター表示や2Dエフェクト再生をショット尺に合わせます。",
    "Key Shape Controls": "シェイプ制御にキー",
    "When creating or refreshing Smart Shape Control drivers, also insert a keyframe on each generated custom property at the current frame. This makes the controls immediately visible in the Dope Sheet and Graph Editor.": "Smart Shape Control ドライバーの作成または更新時に、生成された各カスタムプロパティへ現在フレームでキーを挿入します。これにより、制御がドープシートとグラフエディターですぐ確認できます。",
    "Smart Quality Report": "Smart 品質レポート",
    "Smart Precision Polish": "Smart 精密ポリッシュ",
    "Run adaptive cleanup, flow-safe handles, sparse unbake, and quality reporting in one pass.": "適応整理、流れを保つハンドル、疎キー化アンベイク、品質レポートを1回で実行します。",
    "Analyze key density, duplicate keys, static channels, Euler jumps, spacing speed, and polish risks.": "キー密度、重複キー、静的チャンネル、オイラー飛び、スペーシング速度、ポリッシュリスクを解析します。",
    "Safe": "安全",
    "Balanced": "バランス",
    "Aggressive": "強め",
    "Walk": "歩き",
    "Run": "走り",
    "Mechanical": "機械的",
    "Cinematic": "シネマティック",
    "Precision": "精度",
    "Adaptive": "適応",
    "Precision Polish": "精密ポリッシュ",
    "Quality": "品質診断",
    "Report": "レポート",
    "Style": "スタイル",
    "Key Controls": "制御にキー",
    "Match Scene": "シーン一致",
    "Use conservative adaptive cleanup and preserve more keys for hand-polished shots.": "保守的な適応整理を使い、手付けで磨いたショットのキーをより多く残します。",
    "Use balanced adaptive cleanup for most mocap, retarget, and hand-keyed shots.": "多くのモーキャプ、リターゲット、手付けショットに適したバランス型の適応整理を使います。",
    "Remove more visually redundant keys after dense baking while preserving extremes.": "極値を保ちながら、高密度ベイク後の視覚的に冗長なキーをより多く削除します。",
    "Two contact-like bobs per cycle for a walk-style blocking base.": "歩き風のブロッキングベースとして、1周期に2回の接地感ある上下動を作ります。",
    "One stronger airborne bounce per cycle for a run or jumpy action base.": "走りや跳ねる動作用のベースとして、1周期に1回の強めの浮遊上下動を作ります。",
    "Linear mechanical travel without bob or yaw swing.": "上下動やヨー揺れのない、機械的な直線移動を作ります。",
    "Smooth-eased travel inside each cycle for director-friendly blocking.": "各周期内でイーズ付きの移動を作り、演出確認しやすいブロッキングにします。",
})

TRANSLATIONS = _build_translation_table(include_dynamic=False)

JA_TRANSLATIONS.update({
    "Smart Superior Director": 'スマート総合ディレクター',
    "Smart Contact Stabilizer": 'スマート接地安定化',
    "Smart Timing Intent Solver": 'スマートタイミング意図',
    "Smart Timing Intent": "Smart タイミング意図",
    "Contact Floor Epsilon": "接地床許容値",
    "Contact Minimum Span": "接地最小連続数",
    "Flatten Contact Handles": "接地ハンドル平坦化",
    "Super Pass Visual Review": "最強パス可視レビュー",
    "Auto Intent": "自動意図",
    "Choose the interpolation intent used by Smart Timing Intent Solver. Auto follows the workflow stage; Blocking creates stepped holds, Spline creates auto-clamped flow, Impact protects hits, Float softens drift, and Mechanical keeps linear motion.": 'スマートタイミング意図 で使う補間の意図を選びます。自動は作業段階に合わせ、ブロッキングはコマ止めの保持、スプラインは自動クランプの滑らかな流れ、インパクトは当たりの保護、フロートは漂いの和らげ、メカニカルは直線の動きを作ります。',
    "Vertical tolerance used by Smart Contact Stabilizer and Quality Report when detecting planted contact keys. Larger values catch more contacts, smaller values avoid flattening intentional lift-off.": 'スマート接地安定化 と品質レポートが接地キーを検出するときの上下許容値です。大きい値は多くの接地を拾い、小さい値は意図的な離陸まで平坦化することを避けます。',
    "Minimum number of neighboring contact keys that must be detected before Smart Contact Stabilizer flattens the vertical channel. Use higher values to avoid changing one-frame taps.": 'スマート接地安定化 が上下チャンネルを平坦化する前に必要な、隣接接地キーの最小数です。1フレームだけの接触を変更したくない場合は大きくします。',
    "When Smart Contact Stabilizer flattens contact keys, also flatten Bezier handles at the contact floor to reduce foot sliding, floating, and rebound jitter.": 'スマート接地安定化 が接地キーを平坦化するとき、接地床に合わせてベジェハンドルも平坦化し、足滑り、浮き、跳ね返りジッターを抑えます。',
    "After Smart Superior Director runs precision and timing passes, also create motion visual helpers so arcs, contact, and spacing can be reviewed immediately.": 'スマート総合ディレクター が精密処理とタイミング処理を実行した後、アーク、接地、スペーシングをすぐ確認できるようモーション可視化ヘルパーも作成します。',
    "Choose the interpolation intent used by Smart Timing Intent Solver.": 'スマートタイミング意図 で使う補間の意図を選びます。',
    "Choose the interpolation intent from the current workflow stage.": "現在の作業段階から補間意図を選びます。",
    "Blocking Holds": "ブロッキング保持",
    "Use stepped holds for readable blocking poses.": "読みやすいブロッキングポーズ用にステップ保持を使います。",
    "Spline Flow": "スプラインの流れ",
    "Use auto-clamped Bezier handles for polished spline motion.": "磨き込んだスプラインモーション用に自動クランプのベジェハンドルを使います。",
    "Impact Control": "インパクト制御",
    "Use stronger linear-to-clamped treatment around abrupt value changes.": "急な値変化の周辺で、より強いリニアからクランプへの処理を使います。",
    "Float / Drift": "浮遊 / 漂い",
    "Use smooth Bezier handles for soft drifting motion.": "柔らかく漂う動き用に滑らかなベジェハンドルを使います。",
    "Mechanical Linear": "機械的リニア",
    "Use linear interpolation for mechanical timing and procedural rigs.": "機械的なタイミングやプロシージャルリグ用にリニア補間を使います。",
    "Superior Director": "最強統合ディレクター",
    "Contact / Timing Stabilizer": "接地 / タイミング安定化",
    "Stabilize Contact": "接地安定化",
    "Solve Timing": "タイミング適用",
    "Timing Intent": "タイミング意図",
    "Contact ε": "接地ε",
    "Min Span": "最小連続",
    "Flatten Handles": "ハンドル平坦化",
    "Superior": "最強統合",
    "Stage": "段階",
    "Precision": "精密",
    "Quality": "品質",
    "Motion": "動き",
    "Graph": "カーブ",
    "Contact": "接地",
    "Visual": "可視化",
})

TRANSLATIONS = _build_translation_table(include_dynamic=False)


JA_TRANSLATIONS.update({
    "Smart Icon Button Scale": "スマートアイコンボタンサイズ",
    "Controls the height of the custom borderless Animation Recipes icon buttons. Higher values make the generated icon figures fill the N-panel button area more aggressively for faster visual recognition.": "アニメーション レシピ の枠無し独自アイコンボタンの高さを調整します。値を大きくすると、生成済みの図形が N パネルのボタン領域いっぱいに近い大きさで表示され、視認性が上がります。",
    "Show Icon Labels": "アイコンラベルを表示",
    "Show a small localized label below each large Animation Recipes icon button. Disable this when you want a cleaner icon-first dashboard.": "大型の アニメーション レシピ アイコンボタンの下に、言語設定に合った短いラベルを表示します。アイコン中心のすっきりしたダッシュボードにしたい場合は無効にします。",
    "Preserve Selected Keys": "選択キーを保護",
    "Protect selected keyframes during adaptive precision cleanup so intentional hand-edited timing and poses are not removed by automatic key reduction.": "適応型の精密整理中に選択済みキーフレームを保護し、手作業で意図的に調整したタイミングやポーズが自動キー削減で消えないようにします。",
    "Preserve Extremes": "極値を保護",
    "Protect local extremes, hold boundaries, and obvious direction changes during adaptive key reduction. This keeps animation arcs and acting accents editable.": "適応キー削減中に、局所的な極値、ホールド境界、明確な方向転換を保護します。アニメーションのアークや演技上のアクセントを編集可能なまま残します。",
    "Overshoot Tolerance": "オーバーシュート許容値",
    "Relative tolerance used by Smart Quality Report when detecting Bezier overshoot candidates between neighboring keys. Lower values flag subtler overshoot; higher values ignore small artistic ease overshoot.": "Smart Quality Report が隣接キー間のベジェオーバーシュート候補を検出するときに使う相対許容値です。小さい値ほど微細なオーバーシュートも検出し、大きい値ほど演出的な小さなイーズ超過を無視します。",
    "Icon Size": "アイコンサイズ",
    "Icon Labels": "アイコンラベル",
    "Preserve Selected": "選択キー保護",
    "Preserve Extremes": "極値保護",
    "Overshoot Tol.": "オーバーシュート許容",
    "Overshoot Candidates": "オーバーシュート候補",
    "Handle Risks": "ハンドルリスク",
})


# Always-on toggle centralization translations.
JA_TRANSLATIONS.update({
    'Add Simplify Curves+ commands to Graph Editor and Curve context menus. The same operators remain accessible from the Smart Animation N-panel when this is disabled.': 'Simplify Curves+ のコマンドを Graph Editor とカーブのコンテキストメニューへ追加します。無効でも同じオペレーターは Smart Animation のNパネルから使用できます。',
    'Add Storytools extra Grease Pencil overlay options to Blender overlay panels. Disable this to keep overlay controls outside Smart Animation unchanged.': 'Blender のオーバーレイパネルへ Storytools の追加 Grease Pencil オーバーレイ項目を表示します。Smart Animation 以外のオーバーレイ操作を変更したくない場合は無効にしてください。',
    'Always-on Toggles': '常時機能切り替え',
    'Attribute Migration Load Handler': '属性移行ロードハンドラー',
    'Bezier Editor Header Buttons': 'ベジェ編集ヘッダーボタン',
    'Bottom Control-Bar Gizmo': '下部コントロールバーギズモ',
    'Camera Exclusion Auto Update': 'カメラ除外の自動更新',
    'Centralized switches for N-panel state saving and optional background features that genuinely need persistent callbacks or draw handlers to work continuously. One-shot tools are intentionally excluded so they stay UI-only until executed.': 'Nパネル状態保存と、継続動作に本当に常駐コールバックまたは描画ハンドラーが必要な任意機能だけを集約した切り替え欄です。単発実行ツールは除外し、実行するまでUI表示だけにしています。',
    'Curve Menu Entries': 'カーブメニュー項目',
    'Disabled': '無効',
    'Draw Tool Number Hotkeys': '描画ツール番号ホットキー',
    'Enable Sakura PoseLib shortcuts for opening the pose menu and previewing poses. Disable this when you want to use the pose tools only from the N-panel.': 'ポーズメニューの呼び出しとポーズプレビュー用の Sakura PoseLib ショートカットを有効にします。ポーズツールをNパネルだけで使いたい場合は無効にしてください。',
    'Enable Sakura PoseLib timer/msgbus maintenance for linked armature proxy upkeep, action maintenance, and bone-rename tracking.': 'Sakura PoseLib のタイマー / msgbus 保守を有効化し、リンクアーマチュア用プロキシ維持、アクション保守、ボーン名変更追跡を行います。',
    'Enable Shift+G, Shift+R, and Shift+S shortcuts for moving, rotating, or scaling animated objects while offsetting their animation keys. Disable this when you want the commands available only as N-panel buttons.': 'アニメーション済みオブジェクトの移動・回転・拡縮とキーのオフセットを行う Shift+G、Shift+R、Shift+S ショートカットを有効にします。Nパネルボタンだけで使いたい場合は無効にしてください。',
    'Enable Storytools background msgbus/timer callbacks that keep Grease Pencil layer and material sync updated while you work.': 'Storytools のバックグラウンド msgbus / タイマー処理を有効化し、Grease Pencil のレイヤーとマテリアルの同期を作業中も自動更新します。',
    'Enable Storytools locked-view pan shortcuts and the load handler that restores those shortcuts after Blender finishes loading. Disable this when you do not need the persistent locked-view navigation shortcut.': 'Storytools のロックビュー移動ショートカットと、Blender 読み込み後にそのショートカットを復元するロードハンドラーを有効にします。常駐のロックビュー移動ショートカットが不要な場合は無効にしてください。',
    'Enable Storytools number-key shortcuts for switching Grease Pencil draw presets. Disable this when you want draw preset switching only from N-panel buttons.': 'Grease Pencil 描画プリセットを切り替える Storytools の番号キーショートカットを有効にします。Nパネルボタンだけで切り替えたい場合は無効にしてください。',
    'Enable the Storytools camera-change watcher so object and collection exclusion visibility updates automatically when the active camera changes.': 'Storytools のカメラ変更監視を有効化し、アクティブカメラ切替時にオブジェクト / コレクション除外表示を自動更新します。',
    'Enable the Storytools persistent 3D View gizmo bar for Grease Pencil tool presets. Disable this when you want no persistent viewport gizmo from Storytools.': 'Grease Pencil ツールプリセット用の Storytools 常駐3Dビューギズモバーを有効化します。Storytools の常駐ビューポートギズモを表示したくない場合は無効にしてください。',
    'Enable the Storytools persistent bottom control-bar gizmo in the 3D View. Disable this when you do not want Storytools to keep a viewport gizmo toolbar active.': '3Dビューに Storytools の常駐下部コントロールバーギズモを表示します。Storytools のビューポートギズモツールバーを常駐させたくない場合は無効にしてください。',
    'Enable the Storytools persistent minimap toolbar gizmo in minimap viewports. Disable this when you want no persistent minimap gizmo controls.': 'ミニマップ用ビューポートに Storytools の常駐ミニマップツールバーギズモを表示します。常駐ミニマップギズモ操作が不要な場合は無効にしてください。',
    'Enable the Storytools viewport draw handler that keeps the minimap overlay available in minimap viewports. Disable this when you do not use the minimap overlay.': 'ミニマップ用ビューポートでミニマップオーバーレイを表示し続ける Storytools のビューポート描画ハンドラーを有効にします。ミニマップオーバーレイを使わない場合は無効にしてください。',
    'Enable the Storytools viewport draw handler that shows scale reference figures for Grease Pencil scenes. Disable this when you do not need persistent scale guides.': 'Grease Pencil シーン用のスケール参照図を表示し続ける Storytools のビューポート描画ハンドラーを有効にします。常駐のスケールガイドが不要な場合は無効にしてください。',
    'Enabled': '有効',
    'Function: Add Simplify Curves+ commands to Graph Editor and Curve context menus. The same operators remain accessible from the Smart Animation N-panel when this is disabled. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Simplify Curves+ のコマンドを Graph Editor とカーブのコンテキストメニューへ追加します。無効でも同じオペレーターは Smart Animation のNパネルから使用できます。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Add Storytools extra Grease Pencil overlay options to Blender overlay panels. Disable this to keep overlay controls outside Smart Animation unchanged. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Blender のオーバーレイパネルへ Storytools の追加 Grease Pencil オーバーレイ項目を表示します。Smart Animation 以外のオーバーレイ操作を変更したくない場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Sakura PoseLib shortcuts for opening the pose menu and previewing poses. Disable this when you want to use the pose tools only from the N-panel. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: ポーズメニューの呼び出しとポーズプレビュー用の Sakura PoseLib ショートカットを有効にします。ポーズツールをNパネルだけで使いたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Sakura PoseLib timer/msgbus maintenance for linked armature proxy upkeep, action maintenance, and bone-rename tracking. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Sakura PoseLib のタイマー / msgbus 保守を有効化し、リンクアーマチュア用プロキシ維持、アクション保守、ボーン名変更追跡を行います。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Shift+G, Shift+R, and Shift+S shortcuts for moving, rotating, or scaling animated objects while offsetting their animation keys. Disable this when you want the commands available only as N-panel buttons. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: アニメーション済みオブジェクトの移動・回転・拡縮とキーのオフセットを行う Shift+G、Shift+R、Shift+S ショートカットを有効にします。Nパネルボタンだけで使いたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Storytools background msgbus/timer callbacks that keep Grease Pencil layer and material sync updated while you work. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Storytools のバックグラウンド msgbus / タイマー処理を有効化し、Grease Pencil のレイヤーとマテリアルの同期を作業中も自動更新します。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Storytools locked-view pan shortcuts and the load handler that restores those shortcuts after Blender finishes loading. Disable this when you do not need the persistent locked-view navigation shortcut. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Storytools のロックビュー移動ショートカットと、Blender 読み込み後にそのショートカットを復元するロードハンドラーを有効にします。常駐のロックビュー移動ショートカットが不要な場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable Storytools number-key shortcuts for switching Grease Pencil draw presets. Disable this when you want draw preset switching only from N-panel buttons. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Grease Pencil 描画プリセットを切り替える Storytools の番号キーショートカットを有効にします。Nパネルボタンだけで切り替えたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools camera-change watcher so object and collection exclusion visibility updates automatically when the active camera changes. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Storytools のカメラ変更監視を有効化し、アクティブカメラ切替時にオブジェクト / コレクション除外表示を自動更新します。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools persistent 3D View gizmo bar for Grease Pencil tool presets. Disable this when you want no persistent viewport gizmo from Storytools. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Grease Pencil ツールプリセット用の Storytools 常駐3Dビューギズモバーを有効化します。Storytools の常駐ビューポートギズモを表示したくない場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools persistent bottom control-bar gizmo in the 3D View. Disable this when you do not want Storytools to keep a viewport gizmo toolbar active. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: 3Dビューに Storytools の常駐下部コントロールバーギズモを表示します。Storytools のビューポートギズモツールバーを常駐させたくない場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools persistent minimap toolbar gizmo in minimap viewports. Disable this when you want no persistent minimap gizmo controls. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: ミニマップ用ビューポートに Storytools の常駐ミニマップツールバーギズモを表示します。常駐ミニマップギズモ操作が不要な場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools viewport draw handler that keeps the minimap overlay available in minimap viewports. Disable this when you do not use the minimap overlay. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: ミニマップ用ビューポートでミニマップオーバーレイを表示し続ける Storytools のビューポート描画ハンドラーを有効にします。ミニマップオーバーレイを使わない場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Enable the Storytools viewport draw handler that shows scale reference figures for Grease Pencil scenes. Disable this when you do not need persistent scale guides. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Grease Pencil シーン用のスケール参照図を表示し続ける Storytools のビューポート描画ハンドラーを有効にします。常駐のスケールガイドが不要な場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Run AnimAll compatibility maintenance after loading a file so old vertex-color, bevel-weight, and crease animation paths can be converted to the current attribute format. Disable this when you only want to run AnimAll commands manually from the N-panel. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: ファイル読み込み後に AnimAll の互換保守を実行し、古い頂点カラー、ベベルウェイト、クリースのアニメーションパスを現在の属性形式へ変換します。Nパネルから手動コマンドだけを使いたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Show Bezier Curve Editor buttons in the Dope Sheet and Info editor headers. Disable this when you want the tool to appear only in the Smart Animation N-panel. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: Dope Sheet と Info エディターのヘッダーに Bezier Curve Editor のボタンを表示します。Smart Animation のNパネル内だけで使いたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Function: Show Storytools drawing setup and marker-management buttons in the 3D View and Dope Sheet headers. Disable this when you want those controls only inside the Smart Animation N-panel. How to use: enable this only when you need the feature to stay active continuously. Keep it disabled for manual N-panel operation and lighter startup.': '機能: 3DビューとDope Sheetのヘッダーに Storytools の描画設定・マーカー管理ボタンを表示します。Smart Animation のNパネル内だけで使いたい場合は無効にしてください。 使い方: この機能を継続して常時動作させる必要がある場合だけ有効にします。Nパネルから手動実行するだけなら無効にして、起動と待機状態を軽く保ちます。',
    'Grease Pencil Overlay Options': 'グリースペンシルのオーバーレイ項目',
    'Layer / Material Auto Sync Callbacks': 'レイヤー / マテリアル自動同期コールバック',
    'Locked View Pan Hotkeys': 'ロックビュー移動ホットキー',
    'Minimap Draw Handler': 'ミニマップ描画ハンドラー',
    'Minimap Toolbar Gizmo': 'ミニマップツールバーギズモ',
    'No always-on item is currently registered.': '現在登録されている常時起動項目はありません。',
    'Open the centralized always-on toggle group at the top of the Sidebar N-panel. This is disabled by default when the add-on is installed so the group starts closed.': 'サイドバーNパネル最上部の常時機能切り替えグループを開閉します。通常描画を軽く保つため、アドオン導入直後は閉じた状態です。',
    "Open the group only when needed. The left side shows only the tool and feature name; the right side is the saved Enabled/Disabled BoolProperty toggle. Because the actual property is drawn as a toggle button, enabled items consistently keep Blender's blue active overlay.": '必要な時だけグループを開きます。左にはツール名と機能名だけを表示し、右には保存対象の有効 / 無効 BoolProperty トグルを配置しています。実際のプロパティをトグルボタンとして描画するため、有効時はBlender標準の青いアクティブ表示が安定して維持されます。',
    'Pose Library Background Maintenance': 'ポーズライブラリのバックグラウンド保守',
    'Pose Library Hotkeys': 'ポーズライブラリホットキー',
    'Run AnimAll compatibility maintenance after loading a file so old vertex-color, bevel-weight, and crease animation paths can be converted to the current attribute format. Disable this when you only want to run AnimAll commands manually from the N-panel.': 'ファイル読み込み後に AnimAll の互換保守を実行し、古い頂点カラー、ベベルウェイト、クリースのアニメーションパスを現在の属性形式へ変換します。Nパネルから手動コマンドだけを使いたい場合は無効にしてください。',
    'Scale Figure Draw Handler': 'スケールフィギュア描画ハンドラー',
    'Show Always-on Toggle Group': '常時機能切り替えグループを表示',
    'Show Bezier Curve Editor buttons in the Dope Sheet and Info editor headers. Disable this when you want the tool to appear only in the Smart Animation N-panel.': 'Dope Sheet と Info エディターのヘッダーに Bezier Curve Editor のボタンを表示します。Smart Animation のNパネル内だけで使いたい場合は無効にしてください。',
    'Show Storytools drawing setup and marker-management buttons in the 3D View and Dope Sheet headers. Disable this when you want those controls only inside the Smart Animation N-panel.': '3DビューとDope Sheetのヘッダーに Storytools の描画設定・マーカー管理ボタンを表示します。Smart Animation のNパネル内だけで使いたい場合は無効にしてください。',
    'Storyboard Header Buttons': 'ストーリーボードヘッダーボタン',
    'Tool Preset Gizmo Bar': 'ツールプリセットギズモバー',
    'Transform Offset Hotkeys': '変形オフセットホットキー',
})

TRANSLATIONS = _build_translation_table(include_dynamic=False)

# Animation Recipes lazy-help enum description translations.
JA_TRANSLATIONS.update({
    "Move forward along world +X.": "ワールド +X 方向へ前進します。",
    "Move forward along world +Y.": "ワールド +Y 方向へ前進します。",
    "Move forward along world +Z.": "ワールド +Z 方向へ前進します。",
    "Move forward along world -X.": "ワールド -X 方向へ前進します。",
    "Move forward along world -Y.": "ワールド -Y 方向へ前進します。",
    "Move forward along world -Z.": "ワールド -Z 方向へ前進します。",
    "Full Director": "フルディレクター",
    "Run tween, push/pull, and scale-to-neighbor passes.": "トゥイーン、プッシュ/プル、近隣基準スケールをまとめて実行します。",
    "Tween Only": "トゥイーンのみ",
    "Create an intelligent in-between key from neighboring keys.": "近隣キーから自然な中割りキーを作成します。",
    "Push/Pull Only": "プッシュ/プルのみ",
    "Exaggerate or soften the current-frame key.": "現在フレームのキーを誇張または弱めます。",
    "Scale To Neighbors Only": "近隣基準スケールのみ",
    "Scale selected key values around neighboring anchors.": "近隣アンカーを基準に、選択キー値をスケールします。",
    "Run a safe combination of ballistic guide, fulcrum cleanup, and spring pass where possible.": "可能な範囲で弾道ガイド、接地支点整理、スプリング処理を安全に組み合わせます。",
    "Create a ballistic trajectory guide.": "弾道軌道ガイドを作成します。",
    "Bake a ballistic correction into editable location keys.": "弾道補正を編集可能な位置キーとしてベイクします。",
    "Fulcrum / Contact": "支点 / 接地",
    "Clean planted-contact ranges and contact holds.": "接地範囲と接地ホールドを整理します。",
    "Spring": "スプリング",
    "Bake secondary spring or Spring Magic motion.": "二次的なスプリング動作またはSpring Magic動作をベイクします。",
    "Rigid Body": "剛体",
    "Bake rigid-body simulation to editable keys.": "剛体シミュレーションを編集可能なキーへベイクします。",
    "animBot / AnimAide Motion Director": "animBot / AnimAide モーションディレクター",
    "Tween, push/pull, and scale-to-neighbor recipe for current-frame pose refinement.": "現在フレームのポーズ調整用に、トゥイーン、プッシュ/プル、近隣基準スケールを行うレシピです。",
    "GraphKit / Key Manager Optimizer": "GraphKit / Key Manager 最適化",
    "Euler filter, duplicate/static cleanup, smoothing, and unbake-style graph optimization.": "オイラーフィルター、重複/静的整理、平滑化、アンベイク風のグラフ最適化を行います。",
    "Motion Trail / Ghost / Ballistic Visualizer": "モーショントレイル / ゴースト / 弾道可視化",
    "Motion trails, ghosts, motion paths, and ballistic spacing review.": "モーショントレイル、ゴースト、モーションパス、弾道スペーシング確認を行います。",
    "BroDynamics / Cascadeur AutoPhysics": "BroDynamics / Cascadeur AutoPhysics",
    "Ballistic, fulcrum, spring, and rigid-body-to-key physics-assist recipe.": "弾道、支点、スプリング、剛体からキーへの物理補助レシピです。",
    "Twosify / OmniStep Limited Animation": "Twosify / OmniStep リミテッドアニメーション",
    "Stepped preview and editable held-key baking.": "ステッププレビューと編集可能なホールドキーベイクを行います。",
    "Overlapper / Jiggle / Spring": "Overlapper / Jiggle / Spring",
    "Overlap, cascade delay, and spring secondary-motion recipe.": "オーバーラップ、カスケード遅延、スプリング二次動作のレシピです。",
    "Studio Library / Pose Manager": "Studio Library / Pose Manager",
    "Store reusable poses and add current motion to the action library.": "再利用ポーズを保存し、現在のモーションをアクションライブラリへ追加します。",
    "AnimSchool Picker / Skin Controls": "AnimSchool Picker / Skin Controls",
    "Store the current object or pose-bone selection as a reusable picker set.": "現在のオブジェクトまたはポーズボーン選択を、再利用可能なピッカーセットとして保存します。",
    "Dynamic Parent Plus": '動的な親 Plus',
    "Switch dynamic parent constraints while preserving the current transform.": "現在の見た目の変形を保ったまま、ダイナミック親子制約を切り替えます。",
    "MotionBuilder Story / NLA Mixer": "MotionBuilder Story / NLA ミキサー",
    "Push current actions to NLA and sequence library clips.": "現在のアクションをNLAへ送信し、ライブラリクリップを順番に配置します。",
    "Red9 / KineFX / MotionBuilder Retarget": "Red9 / KineFX / MotionBuilder リターゲット",
    "Build a bone map and create a live retarget preview.": "ボーン対応表を作成し、ライブリターゲットプレビューを生成します。",
    "MotionMaker / CMotion Locomotion": "MotionMaker / CMotion ロコモーション",
    "Generate an editable cyclic locomotion base.": "編集可能な周期ロコモーションベースを生成します。",
    "Signal / MoGraph Procedural Motion": "Signal / MoGraph プロシージャルモーション",
    "Apply procedural signal and loop helpers.": "プロシージャルな信号モーションとループ補助を適用します。",
    "Transform / Unfolder / Scroll Roll": "Transform / Unfolder / Scroll Roll",
    "Create transform or deformer reveal animation.": "変形またはデフォーマーのリビールアニメーションを作成します。",
    "Camera Animator / GorillaCam": "Camera Animator / GorillaCam",
    "Create camera story markers, review split, and shake polish.": "カメラストーリーマーカー、レビュー分割、カメラ揺れの仕上げを作成します。",
    "Pose Morph / OverMorpher / Dorito": 'ポーズモーフ / OverMorpher / Dorito',
    "Create custom-property shape-key controls and drivers.": "カスタムプロパティのシェイプキー制御とドライバーを作成します。",
    "IFL Playback Manager": "IFL再生管理",
    "Synchronize image-sequence texture timing.": "画像シーケンステクスチャのタイミングを同期します。",
    "Cascadeur Animation Unbaking": "Cascadeur アニメーションアンベイク",
    "Convert dense baked curves into sparse editable keys.": "高密度ベイクカーブを疎な編集可能キーへ変換します。",
    "Run stage resolution, contact stabilization, timing intent, precision polish, quality gate, and optional visual review in one pass.": "段階判定、接地安定化、タイミング意図、精密ポリッシュ、品質ゲート、任意の可視レビューを1回で実行します。",
    "Flatten planted vertical contact keys and reduce contact drift while preserving editable keyframes.": "編集可能なキーフレームを保ちながら、接地中の垂直キーを平坦化し、接地ドリフトを減らします。",
    "Apply blocking, spline, impact, float, or mechanical interpolation intent to editable curves.": "ブロッキング、スプライン、インパクト、浮遊、機械的補間の意図を編集可能カーブへ適用します。",
    "Feature Coverage Report": "機能対応レポート",
    "Write the full source-tool mapping to a Text datablock.": "元ツールとの対応表全体をテキストデータブロックへ書き出します。",
    "All Visuals": "全可視化",
    "Create trails, ghosts, motion paths, and ballistic guides where possible.": "可能な範囲でトレイル、ゴースト、モーションパス、弾道ガイドを作成します。",
    "Trail + Ghost": "トレイル + ゴースト",
    "Create motion trail and ghost preview helpers.": "モーショントレイルとゴーストプレビュー補助を作成します。",
    "Calculate Blender motion paths for selected animated targets.": "選択したアニメーション対象のBlenderモーションパスを計算します。",
    "Ballistic": "弾道",
    "Create ballistic trajectory guides.": "弾道軌道ガイドを作成します。",
})
