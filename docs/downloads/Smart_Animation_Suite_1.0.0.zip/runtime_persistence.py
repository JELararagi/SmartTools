# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
import json
from collections import OrderedDict
from typing import Any, Iterable

import bpy
from bpy.app.handlers import persistent

from .storage import addon_data_path

_PERSIST_VERSION = 3
_GLOBAL_OWNERS = {'Scene', 'WindowManager'}
_ID_OWNERS: set[str] = set()
_BONE_OWNERS: set[str] = set()
_SUPPORTED_OWNERS = set(_GLOBAL_OWNERS)
_MAX_TRACKED_PROPS = 512
_MAX_SCENE_HASHES = 128
_MAX_COLLECTION_ITEMS = 256
_MAX_MAPPING_ITEMS = 256
_MAX_STRING_CHARS = 65536
_MAX_VALUE_DEPTH = 8
_MAX_LEGACY_CONFIG_BYTES = 8 * 1024 * 1024
_REJECTED_ID_OWNERS = {'Object', 'Material', 'Armature', 'Camera', 'Bone', 'PoseBone', 'Window', 'Screen'}
_PROTECTED_TRANSFORM_PROPERTY_NAMES = {
    'location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle',
    'scale', 'matrix_world', 'matrix_local', 'matrix_basis', 'matrix_parent_inverse',
}
_TRANSIENT_RUNTIME_PROPERTY_NAMES = {
    # Bezier editor modal/hover state changes every mouse event.  It is neither
    # a user preference nor useful after restart and must never trigger JSON I/O.
    'tlfc_pan_start_x', 'tlfc_pan_start_y',
    'tlfc_pan_origin_x', 'tlfc_pan_origin_y',
    'tlfc_mouse_editing', 'tlfc_hover_sidebar',
    'tlfc_hover_sidebar_edge', 'tlfc_dragging_sidebar',
    'tlfc_hover_button', 'tlfc_pressed_button', 'tlfc_hover_handle',
}
_TRACKED: set[tuple[str, str]] = set()
_LAST_DUMP = ''
_LAST_HASH = ''
_APPLYING = False
_TIMER_REGISTERED = False
_HANDLERS_REGISTERED = False
_SCENE_MARKER = '_sas_runtime_npanel_settings_hash'
_SCENE_HASHES: OrderedDict[int, str] = OrderedDict()
_MSGBUS_OWNER = object()


def _scene_key(scene) -> int:
    try:
        return int(scene.as_pointer())
    except Exception:
        try:
            return id(scene)
        except Exception:
            return 0


def _scene_hash(scene) -> str:
    key = _scene_key(scene)
    if not key:
        return ''
    value = str(_SCENE_HASHES.get(key, '') or '')
    if key in _SCENE_HASHES:
        try:
            _SCENE_HASHES.move_to_end(key)
        except Exception:
            pass
    return value


def _mark_scene_hash(scene, value: str) -> None:
    key = _scene_key(scene)
    if not key:
        return
    _SCENE_HASHES[key] = str(value or '')
    try:
        _SCENE_HASHES.move_to_end(key)
    except Exception:
        pass
    while len(_SCENE_HASHES) > _MAX_SCENE_HASHES:
        try:
            _SCENE_HASHES.popitem(last=False)
        except Exception:
            break


def _legacy_settings_path():
    try:
        return addon_data_path('settings', 'smart_animation_suite_runtime_npanel_properties.json', create=True)
    except Exception:
        return None


def _clean_prop_record(item: Any) -> tuple[str, str] | None:
    if not isinstance(item, dict):
        return None
    owner = str(item.get('owner') or '').strip()
    name = str(item.get('name') or '').strip()
    lower_name = name.lower()
    if owner not in _SUPPORTED_OWNERS or not name or name.startswith('_'):
        return None
    if lower_name in _PROTECTED_TRANSFORM_PROPERTY_NAMES:
        return None
    if lower_name in _TRANSIENT_RUNTIME_PROPERTY_NAMES:
        return None
    return owner, name


def _sanitize_stored_value(value: Any, *, depth: int = 0) -> Any:
    if depth > _MAX_VALUE_DEPTH:
        return None
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:_MAX_STRING_CHARS]
    if isinstance(value, list):
        clean_list = []
        for index, item in enumerate(value):
            if index >= _MAX_COLLECTION_ITEMS:
                break
            clean_item = _sanitize_stored_value(item, depth=depth + 1)
            if clean_item is not None or item is None:
                clean_list.append(clean_item)
        return clean_list
    if isinstance(value, dict):
        kind = str(value.get('__kind__') or '')
        if kind in {'id', 'collection'}:
            return None
        if kind == 'struct':
            data = value.get('data') if isinstance(value.get('data'), dict) else {}
            clean_data = {}
            for index, (key, child) in enumerate(data.items()):
                if index >= _MAX_MAPPING_ITEMS:
                    break
                clean_child = _sanitize_stored_value(child, depth=depth + 1)
                if clean_child is not None or child is None:
                    clean_data[str(key)[:_MAX_STRING_CHARS]] = clean_child
            return {'__kind__': 'struct', 'data': clean_data}
        clean_dict = {}
        for index, (key, child) in enumerate(value.items()):
            if index >= _MAX_MAPPING_ITEMS:
                break
            if str(key) == '__id_type__':
                continue
            clean_child = _sanitize_stored_value(child, depth=depth + 1)
            if clean_child is not None or child is None:
                clean_dict[str(key)[:_MAX_STRING_CHARS]] = clean_child
        return clean_dict
    return None


def _add_tracked_record(record: tuple[str, str] | None) -> None:
    if record is None:
        return
    _TRACKED.add(record)
    if len(_TRACKED) <= _MAX_TRACKED_PROPS:
        return
    for stale in sorted(_TRACKED)[_MAX_TRACKED_PROPS:]:
        _TRACKED.discard(stale)


def track_registered_props(items: Iterable[dict[str, str]] | None) -> None:
    for item in items or ():
        _add_tracked_record(_clean_prop_record(item))
    # Remove subscriptions left by an older build. Persistence now runs only
    # from exact property update callbacks and the core event handlers.
    _register_setting_subscriptions(getattr(bpy, 'context', None))


def _on_setting_changed() -> None:
    if _APPLYING:
        return
    context = getattr(bpy, 'context', None)
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is not None and _scene_hash(scene) != _LAST_HASH:
        _on_active_scene_changed()
    save_runtime_properties_if_changed(context=context, force=False)


def _on_active_scene_changed() -> None:
    """Restore portable settings through Blender's real Scene-change event."""
    if _APPLYING:
        return
    context = getattr(bpy, 'context', None)
    try:
        from . import core as _core
        scene = getattr(context, 'scene', None) if context is not None else None
        _core.apply_saved_settings_to_scene(scene, force=False)
    except Exception:
        pass
    apply_saved_runtime_properties(context=context, force=False)


def _subscribe_struct(owner: Any, *, depth: int = 0, seen: set[str] | None = None) -> None:
    # Compatibility symbol retained for older callers. Broad RNA msgbus
    # subscriptions are intentionally disabled: exact property update callbacks
    # and the core load/save event boundary own persistence.
    del owner, depth, seen
    return None


def _register_setting_subscriptions(context=None) -> None:
    del context
    # Clear subscriptions left by versions that watched every persisted RNA
    # field. Exact update callbacks now perform immediate saves without an idle
    # watcher or active-Scene msgbus subscription.
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    return None




def clear_runtime_caches() -> None:
    """Release bounded scalar persistence caches at load/reload boundaries."""
    global _LAST_DUMP, _LAST_HASH, _APPLYING, _TIMER_REGISTERED, _HANDLERS_REGISTERED
    _TRACKED.clear()
    _SCENE_HASHES.clear()
    _LAST_DUMP = ''
    _LAST_HASH = ''
    _APPLYING = False
    _TIMER_REGISTERED = False
    _HANDLERS_REGISTERED = False
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass

def tracked_props() -> tuple[tuple[str, str], ...]:
    return tuple(sorted(_TRACKED))


def _prop_by_name(instance: Any, name: str):
    try:
        props = getattr(getattr(instance, 'bl_rna', None), 'properties', None)
        if props is not None:
            try:
                return props.get(name)
            except Exception:
                return props[name]
    except Exception:
        return None
    return None


def _prop_type(prop: Any) -> str:
    try:
        return str(getattr(prop, 'type', '') or '').upper()
    except Exception:
        return ''


def _prop_skip(prop: Any) -> bool:
    try:
        # PointerProperty containers are read-only as references (the pointer
        # itself cannot be replaced) but their PropertyGroup children are
        # editable N-panel settings.  Skipping those containers silently
        # dropped every lazy AnimAll/Storytools setting from canonical JSON.
        if bool(getattr(prop, 'is_readonly', False)) and _prop_type(prop) not in {'POINTER', 'COLLECTION'}:
            return True
    except Exception:
        pass
    # SKIP_SAVE controls Blender's .blend serialization, not this canonical
    # external N-panel profile.  Several visible bundled controls deliberately
    # use SKIP_SAVE because Smart_Animation_Suite.json is their authority.
    return False


def _is_id_datablock(value: Any) -> bool:
    try:
        return isinstance(value, bpy.types.ID)
    except Exception:
        pass
    try:
        return hasattr(value, 'name') and getattr(value, 'id_data', None) is value
    except Exception:
        return False


def _id_type(value: Any) -> str:
    try:
        return str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or '')
    except Exception:
        return ''


def _simple_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:_MAX_STRING_CHARS]
    try:
        if not isinstance(value, (str, bytes, dict)):
            # mathutils.Color/Vector support the sequence protocol but do not
            # consistently expose __iter__ across Blender builds.
            out = []
            for index, child in enumerate(value):
                if index >= _MAX_COLLECTION_ITEMS:
                    break
                if isinstance(child, (bool, int, float)) or child is None:
                    out.append(child)
                else:
                    out.append(str(child)[:_MAX_STRING_CHARS])
            return out
    except Exception:
        pass
    try:
        return str(value)[:_MAX_STRING_CHARS]
    except Exception:
        return None


def _serialize_struct(ptr: Any, *, include_collections: bool = True, depth: int = 0) -> dict[str, Any]:
    if ptr is None or depth > _MAX_VALUE_DEPTH:
        return {}
    result: dict[str, Any] = {}
    try:
        props = getattr(getattr(ptr, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return result
    for prop in props:
        if len(result) >= _MAX_MAPPING_ITEMS:
            break
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in {'rna_type', 'name'}:
                continue
            if _prop_skip(prop):
                continue
            if _prop_type(prop) == 'COLLECTION' and not include_collections:
                continue
            if not hasattr(ptr, ident):
                continue
            value = getattr(ptr, ident)
            stored = _serialize_value(value, prop, include_collections=include_collections, depth=depth + 1)
            if stored is not None:
                result[ident[:_MAX_STRING_CHARS]] = _sanitize_stored_value(stored, depth=depth + 1)
        except Exception:
            continue
    return result


def _serialize_value(value: Any, prop: Any, *, include_collections: bool = True, depth: int = 0) -> Any:
    ptype = _prop_type(prop)
    if ptype in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
        return _simple_value(value)
    if ptype in {'BOOLEAN_ARRAY', 'INT_ARRAY', 'FLOAT_ARRAY'}:
        return _simple_value(value)
    if ptype == 'POINTER':
        if value is None:
            return {'__kind__': 'none'}
        if _is_id_datablock(value):
            # ID pointers are file/datablock-specific and are unsafe to restore
            # from a global user_default JSON after another .blend is opened.
            return None
        return {'__kind__': 'struct', 'data': _serialize_struct(value, include_collections=False, depth=depth + 1)}
    if ptype == 'COLLECTION':
        # Never persist runtime collections globally.  Restoring them would clear
        # and rebuild collection items, which can trigger update callbacks or
        # data loss in bundled tools.
        return None
    return _simple_value(value)


def _owner_instances(owner: str, *, context=None) -> list[Any]:
    ctx = context or getattr(bpy, 'context', None)
    if owner == 'Scene':
        try:
            scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', ()) or ())
        except Exception:
            scenes = []
        if scenes:
            return scenes
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        return [scene] if scene is not None else []
    if owner == 'WindowManager':
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        return [wm] if wm is not None else []
    if owner == 'Window':
        window = getattr(ctx, 'window', None) if ctx is not None else None
        return [window] if window is not None else []
    if owner == 'Screen':
        screen = getattr(ctx, 'screen', None) if ctx is not None else None
        return [screen] if screen is not None else []
    data = getattr(bpy, 'data', None)
    if owner == 'Object':
        return list(getattr(data, 'objects', ()) or ())
    if owner == 'Material':
        return list(getattr(data, 'materials', ()) or ())
    if owner == 'Armature':
        return list(getattr(data, 'armatures', ()) or ())
    if owner == 'Camera':
        return list(getattr(data, 'cameras', ()) or ())
    if owner == 'Bone':
        bones: list[Any] = []
        try:
            for armature in getattr(data, 'armatures', ()) or ():
                bones.extend(list(getattr(armature, 'bones', ()) or ()))
        except Exception:
            pass
        return bones
    if owner == 'PoseBone':
        pose_bones: list[Any] = []
        try:
            for obj in getattr(data, 'objects', ()) or ():
                pose = getattr(obj, 'pose', None)
                if pose is not None:
                    pose_bones.extend(list(getattr(pose, 'bones', ()) or ()))
        except Exception:
            pass
        return pose_bones
    return []


def _instance_key(owner: str, instance: Any) -> str:
    try:
        name = str(getattr(instance, 'name', '') or '').strip()
    except Exception:
        name = ''
    if not name:
        return ''
    if owner in _ID_OWNERS:
        return name
    if owner == 'Bone':
        try:
            parent = str(getattr(getattr(instance, 'id_data', None), 'name', '') or '').strip()
        except Exception:
            parent = ''
        return f'{parent}::{name}' if parent else name
    if owner == 'PoseBone':
        try:
            parent = str(getattr(getattr(instance, 'id_data', None), 'name', '') or '').strip()
        except Exception:
            parent = ''
        return f'{parent}::{name}' if parent else name
    return name


def _owner_instance_map(owner: str, *, context=None) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for instance in _owner_instances(owner, context=context):
        key = _instance_key(owner, instance)
        if key and key not in result:
            result[key] = instance
    return result


def _source_instance(owner: str, *, context=None):
    ctx = context or getattr(bpy, 'context', None)
    if owner == 'Scene':
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is not None:
            return scene
    instances = _owner_instances(owner, context=context)
    return instances[0] if instances else None


def _settings_payload(*, context=None) -> dict[str, Any]:
    values: dict[str, dict[str, Any]] = {}
    id_values: dict[str, dict[str, dict[str, Any]]] = {}
    for owner, name in sorted(_TRACKED):
        if owner not in _SUPPORTED_OWNERS or name.lower() in _PROTECTED_TRANSFORM_PROPERTY_NAMES:
            continue
        if owner in _GLOBAL_OWNERS:
            instance = _source_instance(owner, context=context)
            if instance is None or not hasattr(instance, name):
                continue
            prop = _prop_by_name(instance, name)
            if prop is None or _prop_skip(prop):
                continue
            try:
                value = getattr(instance, name)
            except Exception:
                continue
            stored = _serialize_value(value, prop, include_collections=True, depth=0)
            if stored is not None:
                values.setdefault(owner, {})[name] = stored
            continue

        if owner in _ID_OWNERS or owner in _BONE_OWNERS:
            for instance in _owner_instances(owner, context=context):
                if instance is None or not hasattr(instance, name):
                    continue
                key = _instance_key(owner, instance)
                if not key:
                    continue
                prop = _prop_by_name(instance, name)
                if prop is None or _prop_skip(prop):
                    continue
                try:
                    value = getattr(instance, name)
                except Exception:
                    continue
                stored = _serialize_value(value, prop, include_collections=True, depth=0)
                if stored is not None:
                    id_values.setdefault(owner, {}).setdefault(key, {})[name] = stored
    return {
        'version': _PERSIST_VERSION,
        'tracked': [
            {'owner': owner, 'name': name}
            for owner, name in sorted(_TRACKED)[:_MAX_TRACKED_PROPS]
        ],
        'values': values,
        'id_values': id_values,
    }


def _payload_dump(payload: dict[str, Any]) -> str:
    try:
        return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return ''


def save_runtime_properties_if_changed(*, context=None, force: bool = False) -> bool:
    global _LAST_DUMP, _LAST_HASH
    if _APPLYING:
        return False
    if not force:
        try:
            from . import core
            if not core.npanel_auto_save_enabled(context=context):
                return False
        except Exception:
            pass
    if not _TRACKED:
        return False
    payload = _settings_payload(context=context)
    # Lazy tools are intentionally absent until opened.  A base-runtime save
    # must retain their canonical values instead of treating unavailable RNA as
    # deletion; when the tool materialises it will restore and then refresh
    # those keys normally.
    try:
        from . import config_store
        existing = config_store.get_section('runtime_properties', {})
    except Exception:
        existing = {}
    if isinstance(existing, dict):
        existing_values = existing.get('values') if isinstance(existing.get('values'), dict) else {}
        payload_values = payload.setdefault('values', {})
        for owner, owner_values in existing_values.items():
            if owner not in _GLOBAL_OWNERS or not isinstance(owner_values, dict):
                continue
            target = payload_values.setdefault(owner, {})
            if not isinstance(target, dict):
                target = {}
                payload_values[owner] = target
            for name, value in owner_values.items():
                target.setdefault(str(name), value)
        tracked_records = {
            (str(item.get('owner') or ''), str(item.get('name') or ''))
            for item in payload.get('tracked', ()) if isinstance(item, dict)
        }
        for item in existing.get('tracked', ()) or ():
            record = _clean_prop_record(item)
            if record is None or record in tracked_records:
                continue
            payload.setdefault('tracked', []).append({'owner': record[0], 'name': record[1]})
            tracked_records.add(record)
    payload, _sanitized = _sanitize_payload(payload)
    if not payload.get('values') and not payload.get('id_values'):
        return False
    dump = _payload_dump(payload)
    if not dump or (not force and dump == _LAST_DUMP):
        return False
    try:
        from . import config_store
        if not config_store.set_section('runtime_properties', payload):
            return False
        _LAST_DUMP = dump
        _LAST_HASH = hashlib.sha1(dump.encode('utf-8')).hexdigest()
        return True
    except Exception:
        return False



def _sanitize_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    """Keep only bounded, portable global N-panel preference data."""
    changed = False
    if not isinstance(payload, dict):
        return {}, True
    clean: dict[str, Any] = dict(payload)

    tracked = []
    seen_records: set[tuple[str, str]] = set()
    for item in payload.get('tracked') or ():
        record = _clean_prop_record(item)
        if record is None or record in seen_records:
            changed = True
            continue
        if len(tracked) >= _MAX_TRACKED_PROPS:
            changed = True
            break
        seen_records.add(record)
        owner, name = record
        tracked.append({'owner': owner, 'name': name})
    if clean.get('tracked') != tracked:
        changed = True
    clean['tracked'] = tracked

    values = payload.get('values') if isinstance(payload.get('values'), dict) else {}
    clean_values: dict[str, dict[str, Any]] = {}
    for owner, data in values.items():
        if owner not in _GLOBAL_OWNERS or not isinstance(data, dict):
            changed = True
            continue
        owner_values: dict[str, Any] = {}
        for index, (name, stored) in enumerate(data.items()):
            if index >= _MAX_MAPPING_ITEMS:
                changed = True
                break
            if str(name or '').lower() in _PROTECTED_TRANSFORM_PROPERTY_NAMES:
                changed = True
                continue
            clean_stored = _sanitize_stored_value(stored, depth=0)
            if clean_stored is None and stored is not None:
                changed = True
                continue
            clean_name = str(name)[:_MAX_STRING_CHARS]
            owner_values[clean_name] = clean_stored
            if clean_name != str(name) or clean_stored != stored:
                changed = True
        if owner_values:
            clean_values[str(owner)] = owner_values
    if values != clean_values:
        changed = True
    clean['values'] = clean_values

    id_values = payload.get('id_values') if isinstance(payload.get('id_values'), dict) else {}
    if id_values:
        changed = True
    clean['id_values'] = {}
    clean['version'] = _PERSIST_VERSION
    return clean, changed


def _write_payload_safely(payload: dict[str, Any]) -> None:
    try:
        from . import config_store
        config_store.set_section('runtime_properties', payload)
    except Exception:
        pass

def _load_payload() -> dict[str, Any]:
    global _LAST_DUMP, _LAST_HASH
    payload = {}
    try:
        from . import config_store
        section = config_store.get_section('runtime_properties', {})
        if isinstance(section, dict):
            payload = section
    except Exception:
        payload = {}
    if not payload:
        path = _legacy_settings_path()
        if path is None or not path.exists():
            return {}
        try:
            if path.stat().st_size > _MAX_LEGACY_CONFIG_BYTES:
                return {}
            payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            return {}
    if not isinstance(payload, dict):
        return {}
    payload, sanitized = _sanitize_payload(payload)
    if sanitized:
        _write_payload_safely(payload)
    for item in payload.get('tracked') or ():
        record = _clean_prop_record(item)
        if record is not None:
            _add_tracked_record(record)
    dump = _payload_dump(payload)
    if dump:
        _LAST_DUMP = dump
        _LAST_HASH = hashlib.sha1(dump.encode('utf-8')).hexdigest()
    return payload


def _fixed_type(prop: Any) -> str:
    try:
        return str(getattr(getattr(prop, 'fixed_type', None), 'identifier', '') or '')
    except Exception:
        return ''


def _data_store_candidates(type_name: str):
    key = str(type_name or '').lower()
    mapping = {
        'object': 'objects', 'objects': 'objects',
        'collection': 'collections', 'collections': 'collections',
        'action': 'actions', 'actions': 'actions',
        'material': 'materials', 'materials': 'materials',
        'camera': 'cameras', 'cameras': 'cameras',
        'armature': 'armatures', 'armatures': 'armatures',
        'mesh': 'meshes', 'meshes': 'meshes',
        'curve': 'curves', 'curves': 'curves',
        'scene': 'scenes', 'scenes': 'scenes',
        'world': 'worlds', 'worlds': 'worlds',
    }
    ordered = []
    if key in mapping:
        ordered.append(mapping[key])
    ordered.extend(['objects', 'collections', 'actions', 'materials', 'cameras', 'armatures', 'meshes', 'curves', 'scenes', 'worlds'])
    seen = set()
    for attr in ordered:
        if attr in seen:
            continue
        seen.add(attr)
        yield getattr(getattr(bpy, 'data', None), attr, None)


def _resolve_id(prop: Any, payload: dict[str, Any]):
    name = str(payload.get('name') or '').strip()
    if not name:
        return None
    for type_name in (_fixed_type(prop), str(payload.get('__id_type__') or '')):
        for store in _data_store_candidates(type_name):
            if store is None:
                continue
            try:
                found = store.get(name)
            except Exception:
                found = None
            if found is not None:
                return found
    return None


def _runtime_values_equal(current: Any, stored: Any, ptype: str = '') -> bool:
    ptype = str(ptype or '').upper()
    try:
        if ptype == 'BOOLEAN':
            return bool(current) is bool(stored)
        if ptype == 'INT':
            return int(current) == int(stored)
        if ptype == 'FLOAT':
            left = float(current)
            right = float(stored)
            return abs(left - right) <= max(1.0e-8, 1.0e-7 * max(abs(left), abs(right)))
        if ptype in {'BOOLEAN_ARRAY', 'INT_ARRAY', 'FLOAT_ARRAY'}:
            left = tuple(current)
            right = tuple(stored)
            if len(left) != len(right):
                return False
            if ptype == 'FLOAT_ARRAY':
                return all(
                    abs(float(a) - float(b)) <= max(
                        1.0e-8, 1.0e-7 * max(abs(float(a)), abs(float(b))),
                    )
                    for a, b in zip(left, right)
                )
            return left == right
        if ptype == 'ENUM' and isinstance(current, (set, frozenset)):
            return set(current) == set(stored or ())
        return current == stored
    except Exception:
        return False


def _apply_struct(ptr: Any, data: dict[str, Any], *, depth: int = 0) -> bool:
    if ptr is None or not isinstance(data, dict) or depth > 6:
        return False
    try:
        props = getattr(getattr(ptr, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    changed = False
    for name, value in data.items():
        if not isinstance(name, str) or name in {'rna_type', 'name'}:
            continue
        prop = _prop_by_name(ptr, name)
        if prop is None or _prop_skip(prop):
            continue
        if _apply_value(ptr, name, prop, value, depth=depth + 1):
            changed = True
    return changed


def _apply_value(ptr: Any, name: str, prop: Any, value: Any, *, depth: int = 0) -> bool:
    if str(name or '').lower() in _PROTECTED_TRANSFORM_PROPERTY_NAMES:
        return False
    ptype = _prop_type(prop)
    try:
        if ptype == 'POINTER':
            if isinstance(value, dict) and value.get('__kind__') == 'id':
                return False
            if isinstance(value, dict) and value.get('__kind__') == 'none':
                if getattr(ptr, name, None) is None:
                    return False
                setattr(ptr, name, None)
                return True
            if isinstance(value, dict) and value.get('__kind__') == 'struct':
                target = getattr(ptr, name, None)
                return _apply_struct(
                    target,
                    value.get('data') if isinstance(value.get('data'), dict) else {},
                    depth=depth + 1,
                )
            return False
        if ptype == 'COLLECTION':
            return False
        current = getattr(ptr, name)
        assigned = value
        if ptype == 'ENUM' and isinstance(current, (set, frozenset)):
            assigned = set(value or ())
        if _runtime_values_equal(current, assigned, ptype):
            return False
        setattr(ptr, name, assigned)
        return True
    except Exception:
        return False



def _mark_all_scenes(payload_hash: str = '') -> None:
    try:
        scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', ()) or ())
    except Exception:
        scenes = []
    for scene in scenes:
        try:
            _mark_scene_hash(scene, payload_hash or _LAST_HASH)
        except Exception:
            pass


def apply_saved_runtime_properties(*, context=None, force: bool = False, payload: dict[str, Any] | None = None) -> bool:
    global _APPLYING
    payload = payload if isinstance(payload, dict) else _load_payload()
    values = payload.get('values') if isinstance(payload, dict) else None
    # ID-owner values are intentionally ignored. They are file/datablock data,
    # not portable UI preferences, and must not be restored from user_default.
    id_values: dict[str, Any] = {}
    if not isinstance(values, dict) or not values:
        return False
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    marker = _scene_hash(scene) if scene is not None else ''
    payload_dump = _payload_dump(payload) if isinstance(payload, dict) else ''
    payload_hash = hashlib.sha1(payload_dump.encode('utf-8')).hexdigest() if payload_dump else _LAST_HASH
    if marker and payload_hash and marker == payload_hash:
        return False
    previous_applying = bool(_APPLYING)
    _APPLYING = True
    changed = False
    try:
        if isinstance(values, dict):
            for owner, prop_values in values.items():
                if owner not in _GLOBAL_OWNERS or not isinstance(prop_values, dict):
                    continue
                for instance in _owner_instances(owner, context=ctx):
                    if instance is None:
                        continue
                    for name, value in prop_values.items():
                        if not hasattr(instance, name):
                            continue
                        prop = _prop_by_name(instance, name)
                        if prop is None or _prop_skip(prop):
                            continue
                        if _apply_value(instance, str(name), prop, value, depth=0):
                            changed = True

        if isinstance(id_values, dict):
            for owner, keyed_values in id_values.items():
                if owner not in _ID_OWNERS and owner not in _BONE_OWNERS:
                    continue
                if not isinstance(keyed_values, dict):
                    continue
                instances = _owner_instance_map(owner, context=ctx)
                for key, prop_values in keyed_values.items():
                    if not isinstance(prop_values, dict):
                        continue
                    instance = instances.get(str(key or ''))
                    if instance is None:
                        continue
                    for name, value in prop_values.items():
                        if not hasattr(instance, name):
                            continue
                        prop = _prop_by_name(instance, name)
                        if prop is None or _prop_skip(prop):
                            continue
                        if _apply_value(instance, str(name), prop, value, depth=0):
                            changed = True
        _mark_all_scenes(payload_hash)
    finally:
        _APPLYING = previous_applying
    return changed


@persistent
def _load_post(_dummy=None):
    apply_saved_runtime_properties(context=getattr(bpy, 'context', None), force=True)
    _register_setting_subscriptions(getattr(bpy, 'context', None))
    return None


@persistent
def _save_pre(_dummy=None):
    save_runtime_properties_if_changed(context=getattr(bpy, 'context', None), force=True)
    return None


def _autosave_timer():
    # Compatibility symbol only; Smart Animation 1.5.33 never registers it.
    return None

def register() -> None:
    global _TIMER_REGISTERED, _HANDLERS_REGISTERED
    _load_payload()
    _TIMER_REGISTERED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            while _load_post in handlers.load_post:
                handlers.load_post.remove(_load_post)
            while _save_pre in handlers.save_pre:
                handlers.save_pre.remove(_save_pre)
    except Exception:
        pass
    _register_setting_subscriptions(getattr(bpy, 'context', None))
    _HANDLERS_REGISTERED = False


def unregister() -> None:
    global _TIMER_REGISTERED, _HANDLERS_REGISTERED
    # Core save_pre is authoritative. Never snapshot torn-down RNA here.
    _TIMER_REGISTERED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            while _load_post in handlers.load_post:
                handlers.load_post.remove(_load_post)
            while _save_pre in handlers.save_pre:
                handlers.save_pre.remove(_save_pre)
    except Exception:
        pass
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    _TRACKED.clear()
    _SCENE_HASHES.clear()
    _HANDLERS_REGISTERED = False
