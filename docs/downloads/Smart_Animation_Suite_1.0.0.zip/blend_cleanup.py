# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Any

import bpy
from bpy.app.handlers import persistent

# These were implementation markers from older builds. They are only an
# in-memory optimization hint and must not remain in .blend files.
_LEGACY_SCENE_MARKER_KEYS = {
    '_sas_npanel_settings_global_hash',
    '_sas_runtime_npanel_settings_hash',
}

# Conservative prefix list for old Smart Animation proxy-panel leftovers only.
# Do not touch other suites' proxy data, because those may be functional data.
_LEGACY_SMART_ANIMATION_PROXY_PROP_PREFIXES = (
    '_sas_proxy_',
    'sas_proxy_',
    '_smart_animation_suite_proxy_',
    'smart_animation_suite_proxy_',
)

_SPL_PROXY_IDENTIFIER = 'is_spl_proxy'
_SPL_PROXY_OWNER = 'spl_proxy_owner'
_SPL_PROXY_SUFFIX = '_SPL_Proxy'

_HANDLERS_INSTALLED = False


def _id_key(id_block: Any) -> int:
    try:
        return int(id_block.as_pointer())
    except Exception:
        try:
            return id(id_block)
        except Exception:
            return 0


def _safe_del_idprop(id_block: Any, key: str) -> bool:
    try:
        if key in id_block:
            del id_block[key]
            return True
    except Exception:
        pass
    return False


def _cleanup_legacy_scene_markers() -> int:
    removed = 0
    try:
        scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', ()) or ())
    except Exception:
        scenes = []
    for scene in scenes:
        for key in _LEGACY_SCENE_MARKER_KEYS:
            if _safe_del_idprop(scene, key):
                removed += 1
        try:
            for key in list(scene.keys()):
                text = str(key or '')
                if text.startswith(_LEGACY_SMART_ANIMATION_PROXY_PROP_PREFIXES):
                    if _safe_del_idprop(scene, text):
                        removed += 1
        except Exception:
            pass
    return removed


def _cleanup_legacy_id_proxy_props() -> int:
    removed = 0
    id_collections = (
        getattr(bpy.data, 'workspaces', ()),
        getattr(bpy.data, 'screens', ()),
        getattr(bpy.data, 'objects', ()),
        getattr(bpy.data, 'collections', ()),
    )
    for coll in id_collections:
        try:
            items = list(coll or ())
        except Exception:
            items = ()
        for item in items:
            try:
                keys = list(item.keys())
            except Exception:
                continue
            for key in keys:
                text = str(key or '')
                if text.startswith(_LEGACY_SMART_ANIMATION_PROXY_PROP_PREFIXES):
                    if _safe_del_idprop(item, text):
                        removed += 1
    return removed


def _owner_is_valid(owner: Any) -> bool:
    if owner is None:
        return False
    try:
        return owner.name in bpy.data.objects and bpy.data.objects.get(owner.name) == owner
    except Exception:
        return False


def _is_stale_spl_proxy(obj: Any) -> bool:
    try:
        is_marked = bool(obj.get(_SPL_PROXY_IDENTIFIER, False))
        has_owner_prop = _SPL_PROXY_OWNER in obj
        suffix_name = str(getattr(obj, 'name', '') or '').endswith(_SPL_PROXY_SUFFIX)
    except Exception:
        return False

    # Only remove objects that are explicitly marked as Sakura PoseLib proxies or
    # have the old owner property. A user object that merely ends with the suffix
    # but has no proxy marker is left untouched.
    if not is_marked and not has_owner_prop:
        return False

    try:
        owner = obj.get(_SPL_PROXY_OWNER)
    except Exception:
        owner = None

    if not _owner_is_valid(owner):
        return True

    try:
        expected_name = str(owner.name) + _SPL_PROXY_SUFFIX
        if suffix_name and str(obj.name) != expected_name:
            return True
    except Exception:
        return True

    try:
        if getattr(obj, 'parent', None) is not None and obj.parent != owner:
            return True
    except Exception:
        return True

    return False


def _cleanup_stale_spl_proxy_objects() -> int:
    removed = 0
    try:
        objects = list(getattr(getattr(bpy, 'data', None), 'objects', ()) or ())
    except Exception:
        objects = []
    for obj in objects:
        if not _is_stale_spl_proxy(obj):
            continue
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            removed += 1
        except TypeError:
            try:
                bpy.data.objects.remove(obj)
                removed += 1
            except Exception:
                pass
        except Exception:
            pass
    return removed


def cleanup_stale_blend_proxy_data(*, context=None, reason: str = '', aggressive: bool = False) -> int:
    """Explicit legacy cleanup, never an automatic load/save operation.

    A broad database scan cannot prove exact generation ownership and may touch
    user data. Therefore normal registration, load_post and save_pre pass through
    without scanning. Legacy cleanup remains available only to an explicit caller
    that opts into ``aggressive=True``.
    """
    del context, reason
    if not bool(aggressive):
        return 0
    removed = 0
    removed += _cleanup_legacy_scene_markers()
    removed += _cleanup_legacy_id_proxy_props()
    removed += _cleanup_stale_spl_proxy_objects()
    return removed


@persistent
def _sas_cleanup_load_post(_dummy=None):
    cleanup_stale_blend_proxy_data(reason='load_post')
    return None


@persistent
def _sas_cleanup_save_pre(_dummy=None):
    cleanup_stale_blend_proxy_data(reason='save_pre')
    return None


def _append_handler_once(collection, handler) -> None:
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler) -> None:
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def install_cleanup_handlers() -> None:
    global _HANDLERS_INSTALLED
    # Retire exact callbacks from an older in-process generation, but do not scan
    # Blender data and do not install a new load/save handler.
    try:
        _remove_handler(bpy.app.handlers.load_post, _sas_cleanup_load_post)
        _remove_handler(bpy.app.handlers.save_pre, _sas_cleanup_save_pre)
    except Exception:
        pass
    _HANDLERS_INSTALLED = False


def uninstall_cleanup_handlers() -> None:
    global _HANDLERS_INSTALLED
    try:
        _remove_handler(bpy.app.handlers.load_post, _sas_cleanup_load_post)
        _remove_handler(bpy.app.handlers.save_pre, _sas_cleanup_save_pre)
    except Exception:
        pass
    _HANDLERS_INSTALLED = False
