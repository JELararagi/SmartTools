# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## io_scene_gltf2
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/io_scene_gltf2)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - offset/__init__.py

## pose_library
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/pose_library)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - __init__.py
  - stop_motion_style_animator/__init__.py

## rigify
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/rigify)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - storytools/map/map_roll.py

## bl_operators
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_operators)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - storytools/gizmos_camera/cam_shift.py
  - storytools/gpencil_operators/ui.py

## easeit (easeit_1_0_1_evidence)
- Origin / 出どころ: easeit (public upstream source) — https://github.com/andycuccaro/easeit-addon
- Copyright / 著作権者: Andy Cuccaro
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - easeit/__init__.py

## screencast (src)
- Origin / 出どころ: screencast (public upstream source) — https://github.com/nutti/Screencast-Keys
- Copyright / 著作権者: nutti, Paulo Gomes, Bart Crouch, John E. Herrenyo
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - storytools/object_operators/autolock_switch.py

## storytools (storytools_3_3_2_evidence)
- Origin / 出どころ: storytools (public upstream source) — https://github.com/Pullusb/storytools
- Copyright / 著作権者: Samuel Bernou <bernou.samuel@gmail.com>
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - storytools/__init__.py
  - storytools/camera_operators/cam_quick_track_to.py
  - storytools/constants.py
  - storytools/draw.py
  - storytools/fn.py
  - storytools/gizmo_toolbar.py
  - storytools/gizmo_toolpreset_bar.py
  - storytools/gizmos_camera/cam_dolly.py
  - storytools/gizmos_camera/cam_pan.py
  - storytools/gizmos_camera/view_locked_pan.py
  - storytools/gizmos_objects/obj_align_with_view.py
  - storytools/gpencil_operators/frame_jump.py
  - storytools/handles.py
  - storytools/keymaps.py
  - storytools/map/gizmo_map_toolbar.py
  - storytools/map/gizmos_map.py
  - storytools/map/map_operators.py
  - storytools/map/map_place_gp.py
  - storytools/object_operators/material_management.py
  - storytools/object_operators/snap_cursor.py
  - storytools/preferences.py
  - storytools/properties.py
  - storytools/scale_figure/draw_scale_figure.py
  - storytools/setup/story_palettes.py
  - storytools/ui.py

## blender__blender-addons
- Origin / 出どころ: blender blender addons (public upstream source) — https://github.com/BenjaminSauder/EdgeFlow
- Copyright / 著作権者: testscreenings, Michael Soluyanov
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - animall/__init__.py
  - simplify_curves_plus/__init__.py

## kafuji__Sakura_Poselib
- Origin / 出どころ: kafuji sakura poselib (public upstream source) — https://github.com/kafuji/Sakura_Poselib
- Copyright / 著作権者: Kafuji Sato
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - bezier_curve_editor/__init__.py
  - sakura_poselib/__init__.py
  - sakura_poselib/utils.py
  - storytools/camera_operators/__init__.py
  - storytools/gizmos_camera/__init__.py
  - storytools/gizmos_objects/__init__.py
  - storytools/gpencil_operators/__init__.py
  - storytools/map/__init__.py
  - storytools/object_operators/__init__.py
  - storytools/scale_figure/__init__.py
  - storytools/setup/__init__.py
