# SPDX-License-Identifier: GPL-3.0-or-later
"""Store and sample looping camera motion in Blender 5.1 Action slots."""
from math import ceil, floor, isfinite
import bpy
from ..action_compat import iter_action_fcurves


def _extent(curves):
    ranges = [curve.range() for curve in curves if len(curve.keyframe_points) or len(curve.sampled_points)]
    return (min(r[0] for r in ranges), max(r[1] for r in ranges)) if ranges else (0.0, 0.0)


def action_frame_range(action):
    return _extent(iter_action_fcurves(action))


def action_to_python_data_text(act, text_block_name):
    first, last = map(int, action_frame_range(act))
    values = {}
    for curve in iter_action_fcurves(act):
        values[curve.data_path, curve.array_index] = [
            (t, round(curve.evaluate(t), 6)) for t in range(first, last + 1)
        ]
    text = "{\n" + "".join(f"  {key!r}: {points!r},\n" for key, points in values.items()) + "}\n"
    return bpy.data.texts.new(text_block_name).from_string(text)


def _first_strip(action):
    layers = action.layers
    layer = layers[0] if layers else layers.new("Layer")
    strip = layer.strips[0] if layer.strips else layer.strips.new(type="KEYFRAME")
    if strip.type != "KEYFRAME":
        raise ValueError("Camera shake requires a keyframe strip")
    return strip


def ensure_action(action_name):
    # Include the library component of the RNA collection key to select local data.
    existing = bpy.data.actions.get((action_name, None))
    action = bpy.data.actions.new(action_name) if existing is None else existing
    try:
        _first_strip(action)
    except BaseException:
        if existing is None:
            bpy.data.actions.remove(action)
        raise
    return action


def _channels(data, rot_factor, loc_factor):
    channels = []
    for (path, index), samples in data.items():
        if not isinstance(path,str) or not path or type(index) is not int or index < 0:
            raise ValueError("Invalid camera channel")
        factor = rot_factor if path.startswith("rotation") else loc_factor if path.startswith("location") else 1.0
        points = [(float(t), float(value) * factor) for t, value in samples]
        if not points or not all(isfinite(t) and isfinite(value) for t, value in points):
            raise ValueError("Camera channel requires finite samples")
        points[-1] = (points[-1][0], points[0][1])
        channels.append((path, index, points))
    return channels


def ensure_shake_in_action(shake_name, action, data, rot_factor=1.0, loc_factor=1.0):
    strip = _first_strip(action)
    slot = action.slots.get("OB" + shake_name)
    if slot is not None and strip.channelbag(slot) is not None:
        return slot
    channels = _channels(data, rot_factor, loc_factor)
    new_slot = slot is None
    if new_slot:
        slot = action.slots.new("OBJECT", shake_name)
    bag = None
    try:
        bag = strip.channelbags.new(slot)
        for path, index, points in channels:
            curve = bag.fcurves.new(path, index=index)
            keys = curve.keyframe_points
            keys.add(len(points))
            keys.foreach_set("co", [component for sample in points for component in sample])
            for key in keys:
                key.handle_left_type = key.handle_right_type = 'AUTO'
            curve.modifiers.new(type='CYCLES')
            curve.update()
    except BaseException:
        if bag is not None:
            strip.channelbags.remove(bag)
        if new_slot:
            action.slots.remove(slot)
        raise
    return slot


def action_slot_frame_range(action, slot):
    if not action.layers or not action.layers[0].strips:
        return [0, 0]
    bag = action.layers[0].strips[0].channelbag(slot)
    first, last = _extent(bag.fcurves if bag is not None else ())
    return [floor(first), ceil(last)]
