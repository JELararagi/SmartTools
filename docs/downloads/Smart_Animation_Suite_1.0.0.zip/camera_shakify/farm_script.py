# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Generate a minimal standalone schema for the camera shake driver inputs."""

from math import isfinite

import bpy

FARM_SCRIPT_NAME = "camera_shakify_init.py"

_SCHEMA = (
    ("influence", "Influence", 1.0, {"min": 0.0, "soft_max": 1.0}),
    ("scale", "Scale", 1.0, {"min": 0.0, "soft_max": 2.0}),
    ("use_manual_timing", "Manual Timing", False, {}),
    ("time", "Time", 0.0, {"precision": 1}),
    ("speed", "Speed", 1.0, {"soft_min": 0.0, "soft_max": 4.0, "options": set()}),
    ("offset", "Frame Offset", 0.0, {"precision": 1}),
)

def _standalone_source(influence_limit, scale_limit):
    limits = {"influence": float(influence_limit), "scale": float(scale_limit)}
    if any(not isfinite(value) or value < 1 for value in limits.values()):
        raise ValueError("Invalid camera shake limit")
    lines = [
        "# SmartTools: standalone camera-driver schema",
        "# SPDX-License-Identifier: GPL-3.0-or-later",
        "import bpy",
        "",
        "def install_camera_inputs():",
        '    if hasattr(bpy.types.Object, "camera_shakes"):',
        "        return",
        "    class SmartToolsCameraInputs(bpy.types.PropertyGroup):",
    ]
    for key, label, default, options in _SCHEMA:
        settings = {"name": label, "default": default, **options}
        if key in limits:
            settings["max"] = limits[key]
        args = ", ".join(f"{name}={value!r}" for name, value in settings.items())
        rna_type = "BoolProperty" if isinstance(default, bool) else "FloatProperty"
        lines.append(f"        {key}: bpy.props.{rna_type}({args})")
    lines.extend((
        "    bpy.utils.register_class(SmartToolsCameraInputs)",
        "    bpy.types.Object.camera_shakes = bpy.props.CollectionProperty(type=SmartToolsCameraInputs)",
        "",
        'if __name__ == "__main__":',
        "    install_camera_inputs()",
        "",
    ))
    return "\n".join(lines)

def ensure_farm_script(influence_max, scale_max):
    source = _standalone_source(influence_max, scale_max)
    for text in bpy.data.texts:
        if (text.name == FARM_SCRIPT_NAME or text.name.startswith(FARM_SCRIPT_NAME + ".")) and text.as_string() == source:
            target = text
            break
    else:
        target = bpy.data.texts.new(FARM_SCRIPT_NAME)
        target.write(source)
    target.use_fake_user = True
    target.use_module = True
