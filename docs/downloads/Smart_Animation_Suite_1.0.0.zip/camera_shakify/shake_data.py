"""Procedurally generated 24 fps camera motion for SmartAnimation."""

from math import sin, tau


# Labels and frame ranges are retained for scene and preset compatibility.
# Amplitudes are in Blender units and radians before the UI influence scaling.
_presets = (
    ("INVESTIGATION", "Investigation", 0, 371, 15, 7, (0.16, 0.15, 0.10), (0.075, 0.07, 0.05)),
    ("THE_CLOSEUP", "The Closeup", -1, 437, 17, 2, (0.004, 0.003, 0.005), (0.011, 0.009, 0.006)),
    ("THE_WEDDING", "The Wedding", -10, 151, 31, 3, (0.004, 0.001, 0.003), (0.007, 0.004, 0.009)),
    ("WALK_TO_THE_STORE", "Walk to the Store", 1, 123, 47, 8, (0.05, 0.02, 0.04), (0.02, 0.009, 0.027)),
    ("HANDYCAM_RUN", "HandyCam Run", 0, 64, 61, 9, (0.042, 0.027, 0.0), (0.058, 0.05, 0.08)),
    ("OUT_CAR_WINDOW", "Out Car Window", -1, 159, 73, 16, (0.023, 0.027, 0.032), (0.039, 0.008, 0.007)),
    ("BIKE_ON_GRAVEL_2D", "Bike On Gravel (2D)", -1, 125, 89, 19, (), (0.23, 0.116, 0.052)),
    ("SPACESHIP_SHAKE_2D", "Spaceship Shake (2D)", 1, 144, 103, 12, (), (0.015, 0.027, 0.02)),
    ("THE_ZEEK_2D", "The Zeek (2D)", 0, 400, 127, 5, (), (0.0025, 0.003, 0.004)),
)


def _motion(first, last, seed, cadence, displacement):
    phase = seed * 0.754877666
    step = tau / (last - first)
    drift_cycles = max(1, cadence // 3)
    values = []
    for frame in range(first, last):
        angle = step * (frame - first)
        drift = sin(drift_cycles * angle + phase)
        sway = sin(cadence * angle - phase * 0.41)
        vibration = sin((cadence + 5) * angle + phase * 0.29)
        values.append(0.50 * drift + 0.38 * sway + 0.12 * vibration)
    low, high = min(values), max(values)
    mid = (high + low) / 2.0
    scale = displacement * 2.0 / (high - low)
    samples = [(first + index, (value - mid) * scale) for index, value in enumerate(values)]
    samples.append((last, samples[0][1]))
    return samples


def _channels(first, last, seed, cadence, location, rotation):
    output = {}
    for kind, magnitudes in (("location", location), ("rotation_euler", rotation)):
        phase = seed if kind == "location" else seed + 19
        for axis, magnitude in enumerate(magnitudes):
            output[kind, axis] = _motion(first, last, phase + 13 * axis, cadence, magnitude)
    return output


SHAKE_LIST = {
    key: (label, 24.0, _channels(first, last, seed, cadence, location, rotation))
    for key, label, first, last, seed, cadence, location, rotation in _presets
}
