# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Camera Shakify",
    "version": (0, 5, 0),
    "author": "JELararagi",
    "blender": (5, 1, 0),
    "description": "Add captured camera shake/wobble to your cameras",
    "location": "Camera properties",
    # "doc_url": "",
    "category": "Animation",
}

import re
import math

import bpy
from bpy.app.handlers import persistent
from bpy.types import Camera, Context
from .action_utils import action_to_python_data_text, ensure_shake_in_action, action_slot_frame_range, ensure_action
from .shake_data import SHAKE_LIST
from .farm_script import ensure_farm_script


# Note: the ".v#" number at the end is *not* the addon version.  This number is
# incremented when the way shakes are constructed changes to prevent
# compatibility problems, and generally spans multiple addon versions.
BASE_NAME = "CameraShakify.v3"
ACTION_NAME = BASE_NAME + " Shakes"
COLLECTION_NAME = BASE_NAME

# Note: the addon used to be called "Camera Wobble" before it was publicly
# released, and had a "v1" and "v2" base name under that name.  We don't include
# those here because those versions of the addon were only ever used internally
# by Ian, and there should be no files that exist anymore that use those base
# names.  But that's why there's also no "CameraShakify.v1", because that never
# existed.
BASE_NAMES_OLD = ["CameraShakify.v2"]

# Maximum values of our per-camera scaling/influence properties.
INFLUENCE_MAX = 4.0
SCALE_MAX = 100.0

# The maximum supported world unit scale.
UNIT_SCALE_MAX = 1000.0
_CAMERA_SHAKE_ACTIVE_INDEX_CACHE = {}


def _clear_camera_shake_active_index_cache():
    _CAMERA_SHAKE_ACTIVE_INDEX_CACHE.clear()


def _camera_shake_cache_key(camera):
    try:
        session_uid = int(getattr(camera, "session_uid", 0) or 0)
    except Exception:
        session_uid = 0
    if session_uid:
        return ("object_session_uid", session_uid)
    return None


def _prune_camera_shake_active_index_cache():
    if not _CAMERA_SHAKE_ACTIVE_INDEX_CACHE:
        return
    valid = set()
    try:
        for obj in getattr(getattr(bpy, "data", None), "objects", ()) or ():
            if obj is None or getattr(obj, "type", None) != 'CAMERA':
                continue
            key = _camera_shake_cache_key(obj)
            if key is not None:
                valid.add(key)
    except Exception:
        valid = set()
    if not valid:
        _clear_camera_shake_active_index_cache()
        return
    for key in tuple(_CAMERA_SHAKE_ACTIVE_INDEX_CACHE):
        if key not in valid:
            _CAMERA_SHAKE_ACTIVE_INDEX_CACHE.pop(key, None)


def _camera_shakes_active_index_get(camera):
    _prune_camera_shake_active_index_cache()
    key = _camera_shake_cache_key(camera)
    if key is None:
        return 0
    try:
        count = len(camera.camera_shakes)
    except Exception:
        count = 0
    if count <= 0:
        _CAMERA_SHAKE_ACTIVE_INDEX_CACHE.pop(key, None)
        return 0
    try:
        value = int(_CAMERA_SHAKE_ACTIVE_INDEX_CACHE.get(key, 0) or 0)
    except Exception:
        value = 0
    value = max(0, min(value, count - 1))
    if value <= 0:
        _CAMERA_SHAKE_ACTIVE_INDEX_CACHE.pop(key, None)
        return 0
    _CAMERA_SHAKE_ACTIVE_INDEX_CACHE[key] = value
    return value


def _camera_shakes_active_index_set(camera, value):
    _prune_camera_shake_active_index_cache()
    key = _camera_shake_cache_key(camera)
    if key is None:
        return
    try:
        count = len(camera.camera_shakes)
    except Exception:
        count = 0
    try:
        clean_value = int(value)
    except Exception:
        clean_value = 0
    clean_value = max(0, min(clean_value, max(count - 1, 0)))
    if clean_value <= 0:
        _CAMERA_SHAKE_ACTIVE_INDEX_CACHE.pop(key, None)
        return
    _CAMERA_SHAKE_ACTIVE_INDEX_CACHE[key] = clean_value


@persistent
def _camera_shake_load_post(*_args):
    _clear_camera_shake_active_index_cache()


#========================================================


class CameraShakifyPanel(bpy.types.Panel):
    """Add shake to your Cameras."""
    bl_label = "Camera Shakify"
    bl_idname = "DATA_PT_camera_shakify"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Animation'
    bl_context = "data"

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return obj is not None and getattr(obj, 'type', None) == 'CAMERA'

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout

        camera = context.active_object

        row = layout.row()
        row.template_list(
            listtype_name="OBJECT_UL_camera_shake_items",
            list_id="Camera Shakes",
            dataptr=camera,
            propname="camera_shakes",
            active_dataptr=camera,
            active_propname="camera_shakes_active_index",
        )
        col = row.column()
        col.operator("object.camera_shake_add", text="", icon='ADD')
        col.operator("object.camera_shake_remove", text="", icon='REMOVE')
        col.operator("object.camera_shake_move", text="", icon='TRIA_UP').type = 'UP'
        col.operator("object.camera_shake_move", text="", icon='TRIA_DOWN').type = 'DOWN'

        if camera.camera_shakes_active_index < len(camera.camera_shakes):
            shake = camera.camera_shakes[camera.camera_shakes_active_index]
            row = layout.row()
            col = row.column(align=True)
            col.alignment = 'RIGHT'
            col.use_property_split = True
            col.prop(shake, "shake_type", text="Shake")
            col.separator()
            col.prop(shake, "influence", slider=True)
            col.separator()
            col.prop(shake, "scale")
            col.separator()
            col.prop(shake, "use_manual_timing")
            if shake.use_manual_timing:
                col.prop(shake, "time")
            else:
                col.prop(shake, "speed")
                col.prop(shake, "offset")

        col.separator(factor=2.0)

        header, panel = layout.panel_prop(wm, "camera_shake_show_utils")
        header.label(text="Misc Utilities")
        help_button = header.operator('sas.show_help', text='', icon='QUESTION')
        help_button.topic_key = 'camera_shakify_utilities'
        if panel is not None:
            col = panel.column()
            col.operator("object.camera_shakes_fix_global")
            col.operator("wm.camera_shakify_prep_file_for_farm")


class OBJECT_UL_camera_shake_items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        list_item(layout, item, icon, self.layout_type)


#========================================================

# Creates a camera shake setup for the given camera and
# shake item index, using the given collection to store
# shake empties.
def build_single_shake(camera, shake_item_index, collection, context, *, action=None):
    shake = camera.camera_shakes[shake_item_index]
    shake_data = SHAKE_LIST[shake.shake_type]

    shake_name = shake.shake_type.lower()
    shake_object_name = BASE_NAME + "_" + camera.name + "_" + str(shake_item_index)

    # Ensure the needed action and shake slot exist.
    if action is None:
        action = _shake_action()
    slot = ensure_shake_in_action(
        shake_name,
        action,
        shake_data[2],
        INFLUENCE_MAX,
        INFLUENCE_MAX * SCALE_MAX * UNIT_SCALE_MAX
    )

    shake_object = bpy.data.objects.new(shake_object_name, None)
    shake_object[_SHAKE_DATA_MARKER] = "helper"
    collection.objects.link(shake_object)

    #----------------
    # Set up the constraints and drivers on the shake object.
    #----------------

    # Clear out all constraints and drivers, and fetch animation data block.
    shake_object.constraints.clear()
    shake_object.animation_data_clear()
    anim_data = shake_object.animation_data_create()

    # Some weird gymnastics needed because of a Blender bug.
    # Without first assigning an action to the animation data,
    # then on a fresh scene we won't be able to assign an action
    # to the action constraint (below).
    anim_data.action = action
    anim_data.action = None
    shake_object.location = (0,0,0)
    shake_object.rotation_euler = (0,0,0)
    shake_object.rotation_quaternion = (0,0,0,0)
    shake_object.rotation_axis_angle = (0,0,0,0)
    shake_object.scale = (1,1,1)

    # Get action info for calculations below.
    shake_fps = shake_data[1]
    shake_range = action_slot_frame_range(action, slot)
    shake_length = shake_range[1] - shake_range[0]

    # Create the action constraint.
    constraint = shake_object.constraints.new('ACTION')
    constraint.use_eval_time = True
    constraint.mix_mode = 'BEFORE'
    constraint.action = action
    constraint.action_slot = slot
    constraint.frame_start = shake_range[0]
    constraint.frame_end = shake_range[1]

    # Create the driver for the constraint's eval time.
    driver = constraint.driver_add("eval_time").driver
    driver.type = 'SCRIPTED'
    fps_factor = 1.0 / ((context.scene.render.fps / context.scene.render.fps_base) / shake_fps)
    driver.expression = \
        "((time if manual else ((-frame_offset + frame) * speed)) * {}) % 1.0" \
        .format(fps_factor / shake_length)

    manual_timing_var = driver.variables.new()
    manual_timing_var.name = "manual"
    manual_timing_var.type = 'SINGLE_PROP'
    manual_timing_var.targets[0].id_type = 'OBJECT'
    manual_timing_var.targets[0].id = camera
    manual_timing_var.targets[0].data_path = 'camera_shakes[{}].use_manual_timing'.format(shake_item_index)

    time_var = driver.variables.new()
    time_var.name = "time"
    time_var.type = 'SINGLE_PROP'
    time_var.targets[0].id_type = 'OBJECT'
    time_var.targets[0].id = camera
    time_var.targets[0].data_path = 'camera_shakes[{}].time'.format(shake_item_index)

    speed_var = driver.variables.new()
    speed_var.name = "speed"
    speed_var.type = 'SINGLE_PROP'
    speed_var.targets[0].id_type = 'OBJECT'
    speed_var.targets[0].id = camera
    speed_var.targets[0].data_path = 'camera_shakes[{}].speed'.format(shake_item_index)

    offset_var = driver.variables.new()
    offset_var.name = "frame_offset"
    offset_var.type = 'SINGLE_PROP'
    offset_var.targets[0].id_type = 'OBJECT'
    offset_var.targets[0].id = camera
    offset_var.targets[0].data_path = 'camera_shakes[{}].offset'.format(shake_item_index)

    #----------------
    # Set up the constraints and drivers on the camera object.
    #----------------

    loc_constraint_name = BASE_NAME + "_loc_" + str(shake_item_index)
    rot_constraint_name = BASE_NAME + "_rot_" + str(shake_item_index)

    # Create the new constraints.
    loc_constraint = camera.constraints.new(type='COPY_LOCATION')
    rot_constraint = camera.constraints.new(type='COPY_ROTATION')
    loc_constraint.name = loc_constraint_name
    rot_constraint.name = rot_constraint_name
    loc_constraint.show_expanded = False
    rot_constraint.show_expanded = False

    # Set up location constraint.
    loc_constraint.target = shake_object
    loc_constraint.target_space = 'WORLD'
    loc_constraint.owner_space = 'LOCAL'
    loc_constraint.use_offset = True

    # Set up rotation constraint.
    rot_constraint.target = shake_object
    rot_constraint.target_space = 'WORLD'
    rot_constraint.owner_space = 'LOCAL'
    rot_constraint.mix_mode = 'AFTER'

    # Set up the location constraint driver.
    #
    # Note: we clear the keyframes from the driver's fcurve to dodge some
    # small-value rounding that Blender does internally when evaluating fcurves.
    # This way the driver expression evaluation gets used directly, without any
    # intermediate steps that might interfere.
    fcurve = loc_constraint.driver_add("influence")
    fcurve.keyframe_points.clear()
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = "{} * influence * location_scale / unit_scale * int(\"1\")".format(1.0 / (UNIT_SCALE_MAX * INFLUENCE_MAX * SCALE_MAX))
    if "influence" not in driver.variables:
        var = driver.variables.new()
        var.name = "influence"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = 'OBJECT'
        var.targets[0].id = camera
        var.targets[0].data_path = 'camera_shakes[{}].influence'.format(shake_item_index)
    if "location_scale" not in driver.variables:
        var = driver.variables.new()
        var.name = "location_scale"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = 'OBJECT'
        var.targets[0].id = camera
        var.targets[0].data_path = 'camera_shakes[{}].scale'.format(shake_item_index)
    if "unit_scale" not in driver.variables:
        var = driver.variables.new()
        var.name = "unit_scale"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = 'SCENE'
        var.targets[0].id = context.scene
        var.targets[0].data_path ='unit_settings.scale_length'

    # Set up the rotation constraint driver.
    #
    # Note: see further-above note for why we clear the keyframes here.
    fcurve = rot_constraint.driver_add("influence")
    fcurve.keyframe_points.clear()
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    driver.expression = "influence * {}".format(1.0 / INFLUENCE_MAX)
    if "influence" not in driver.variables:
        var = driver.variables.new()
        var.name = "influence"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = 'OBJECT'
        var.targets[0].id = camera
        var.targets[0].data_path = 'camera_shakes[{}].influence'.format(shake_item_index)


# Only for use in rebuilding camera shakes, to ensure that constraints, etc.
# from previous Camera Shakify versions get removed.
def starts_with_any_base_name(text):
    base_names = BASE_NAMES_OLD + [BASE_NAME]

    for base_name in base_names:
        if text.startswith(base_name):
            return True

    return False

_SHAKE_DATA_MARKER = "_smart_animation_camera_shake"


def ensure_camera_shakify_collection(context):
    root = context.scene.collection
    collection = next((child for child in root.children
                       if child.library is None and child.get(_SHAKE_DATA_MARKER) == "collection"), None)
    if collection is None:
        collection = bpy.data.collections.new(COLLECTION_NAME)
        collection[_SHAKE_DATA_MARKER] = "collection"
        collection.hide_viewport = collection.hide_render = collection.hide_select = True
        root.children.link(collection)
    for view_layer in context.scene.view_layers:
        layer = view_layer.layer_collection.children.get(collection.name)
        if layer is not None:
            layer.exclude = True
    return collection


def _shake_action():
    action = next((item for item in bpy.data.actions
                   if item.library is None and item.get(_SHAKE_DATA_MARKER) == "action"), None)
    if action is None:
        action = bpy.data.actions.new(ACTION_NAME)
        action[_SHAKE_DATA_MARKER] = "action"
    return action


def _shake_driver_owns(helper, camera):
    if helper.library is not None or helper.type != 'EMPTY' or helper.animation_data is None:
        return False
    return any(
        target.id == camera and target.data_path.startswith("camera_shakes[")
        for curve in helper.animation_data.drivers if curve.data_path.endswith(".eval_time")
        for variable in curve.driver.variables for target in variable.targets
    )


def _shake_constraints(camera):
    for constraint in camera.constraints:
        if constraint.type not in {'COPY_LOCATION', 'COPY_ROTATION'}:
            continue
        target = constraint.target
        if target is None or target.type != 'EMPTY':
            continue
        channel = "loc" if constraint.type == 'COPY_LOCATION' else "rot"
        names = (fr"{re.escape(prefix)}_{channel}_[0-9]+(?:\.[0-9]+)?" for prefix in (BASE_NAME, *BASE_NAMES_OLD))
        if not any(re.fullmatch(expression, constraint.name) for expression in names):
            continue
        if target.get(_SHAKE_DATA_MARKER) == "helper" or _shake_driver_owns(target, camera):
            yield constraint, target


def _drop_unreferenced_shake(helper, *, scene):
    # Other scenes and user constraints may still link a generated helper.
    groups = helper.users_collection
    if helper.use_fake_user:
        return
    if helper.users > len(groups) or any(
        group not in scene.collection.children[:]
        or group.get(_SHAKE_DATA_MARKER) != "collection"
        and not (group.name in (COLLECTION_NAME, *BASE_NAMES_OLD)
                 and group.hide_select and group.hide_render and group.hide_viewport)
        for group in groups
    ):
        return
    bpy.data.objects.remove(helper, do_unlink=True)


def rebuild_camera_shakes(camera, context, *, action=None):
    if camera.library is not None:
        return

    connected = list(_shake_constraints(camera))
    helpers = {helper for _, helper in connected}
    for constraint, _ in connected:
        constraint.driver_remove("influence")
        camera.constraints.remove(constraint)
    for helper in helpers:
        _drop_unreferenced_shake(helper, scene=context.scene)

    if camera.camera_shakes:
        collection = ensure_camera_shakify_collection(context)
        for slot in range(len(camera.camera_shakes)):
            build_single_shake(camera, slot, collection, context, action=action)

    for collection in tuple(context.scene.collection.children):
        if collection.get(_SHAKE_DATA_MARKER) == "collection" and not collection.objects and not collection.children:
            if collection.users == 1:
                bpy.data.collections.remove(collection)


def fix_camera_shakes_globally(context):
    cameras = tuple(obj for obj in context.scene.objects if obj.type == 'CAMERA' and obj.library is None)
    previous = [item for item in bpy.data.actions
                if item.library is None and item.get(_SHAKE_DATA_MARKER) == "action"]
    # Build fresh channels during explicit repair, leaving any action from the
    # open scene that is still in use intact, including actions in other scenes.
    fresh = bpy.data.actions.new(ACTION_NAME) if any(camera.camera_shakes for camera in cameras) else None
    for camera in cameras:
        if camera.camera_shakes or any(_shake_constraints(camera)):
            rebuild_camera_shakes(camera, context, action=fresh)
    if fresh is not None:
        fresh[_SHAKE_DATA_MARKER] = "action"
        for item in previous:
            if item.users:
                item[_SHAKE_DATA_MARKER] = "retired_action"
            else:
                bpy.data.actions.remove(item)


def on_shake_type_update(shake_instance, context):
    rebuild_camera_shakes(shake_instance.id_data, context)


#class ActionToPythonData(bpy.types.Operator):
#    """Writes the action on the currently selected object to a text block as Python data"""
#    bl_idname = "object.action_to_python_data"
#    bl_label = "Action to Python Data"
#    bl_options = {'UNDO'}
#
#    @classmethod
#    def poll(cls, context):
#        return context.active_object is not None \
#               and context.active_object.animation_data is not None \
#               and context.active_object.animation_data.action is not None
#
#    def execute(self, context):
#        action_to_python_data_text(context.active_object.animation_data.action, "action_output.txt")
#        return {'FINISHED'}


class CameraShakeAdd(bpy.types.Operator):
    """Adds the selected camera shake to the list"""
    bl_idname = "object.camera_shake_add"
    bl_label = "Add Shake Item"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'CAMERA'

    def execute(self, context):
        camera = context.active_object
        shake = camera.camera_shakes.add()
        camera.camera_shakes_active_index = len(camera.camera_shakes) - 1
        rebuild_camera_shakes(camera, context)
        return {'FINISHED'}


class CameraShakeRemove(bpy.types.Operator):
    """Removes the selected camera shake item from the list"""
    bl_idname = "object.camera_shake_remove"
    bl_label = "Remove Shake Item"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'CAMERA' and len(obj.camera_shakes) > 0

    def execute(self, context):
        remove_item(context.active_object, context, rebuild_camera_shakes)
        return {"FINISHED"}


class CameraShakeMove(bpy.types.Operator):
    """Moves the selected camera shake up/down in the list"""
    bl_idname = "object.camera_shake_move"
    bl_label = "Move Shake Item"
    bl_options = {'UNDO'}

    type: bpy.props.EnumProperty(items = [
        ('UP', "", ""),
        ('DOWN', "", ""),
    ])

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'CAMERA' and len(obj.camera_shakes) > 1

    def execute(self, context):
        move_item(context.active_object, context, self.type, rebuild_camera_shakes)
        return {"FINISHED"}


class CameraShakesFixGlobal(bpy.types.Operator):
    """Ensures that all camera shakes in the scene are set up properly. This generally shouldn't be necessary, but if things are behaving strangely this should fix it"""
    bl_idname = "object.camera_shakes_fix_global"
    bl_label = "Fix All Camera Shakes"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        fix_camera_shakes_globally(context)
        return {'FINISHED'}


class CameraShakifyPrepFileForFarm(bpy.types.Operator):
    """Adds an auto-execute script to the blend file that makes Camera Shakes work even when the addon is not present. Particularly useful for sending files to a render farm. This only needs to be run once per file, not every time you submit a file to a farm"""
    bl_idname = "wm.camera_shakify_prep_file_for_farm"
    bl_label = "Prep Blend File For Render Farm"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        ensure_farm_script(INFLUENCE_MAX, SCALE_MAX)
        return {'FINISHED'}


# An actual instance of Camera shake added to a camera.
#
# IMPORTANT: when making changes here, make sure to also update the
# corresponding script text in farm_script.py.
class CameraShakeInstance(bpy.types.PropertyGroup):
    shake_type: bpy.props.EnumProperty(
        name = "Shake Type",
        items = [(id, SHAKE_LIST[id][0], "") for id in SHAKE_LIST.keys()],
        options = set(), # Not animatable.
        override = set(), # Not library overridable.
        update = on_shake_type_update,
    )
    influence: bpy.props.FloatProperty(
        name="Influence",
        description="How much the camera shake affects the camera",
        default=1.0,
        min=0.0, max=INFLUENCE_MAX,
        soft_min=0.0, soft_max=1.0,
    )
    scale: bpy.props.FloatProperty(
        name="Scale",
        description="The scale of the shake's location component",
        default=1.0,
        min=0.0, max=SCALE_MAX,
        soft_min=0.0, soft_max=2.0,
    )
    use_manual_timing: bpy.props.BoolProperty(
        name="Manual Timing",
        description="Manually animate the progression of time through the camera shake animation",
        default=False,
    )
    time: bpy.props.FloatProperty(
        name="Time",
        description="Current time (in frame number) of the shake animation",
        default=0.0,
        precision=1,
        step=100.0,
    )
    speed: bpy.props.FloatProperty(
        name="Speed",
        description="Multiplier for how fast the shake animation plays",
        default=1.0,
        soft_min=0.0, soft_max=4.0,
        options = set(), # Not animatable.
    )
    offset: bpy.props.FloatProperty(
        name="Frame Offset",
        description="How many frames to offset the shake animation",
        default=0.0,
        precision=1,
        step=100.0,
    )


#========================================================


def register():
    _clear_camera_shake_active_index_cache()
    bpy.utils.register_class(CameraShakifyPanel)
    bpy.utils.register_class(OBJECT_UL_camera_shake_items)
    bpy.utils.register_class(CameraShakeInstance)
    bpy.utils.register_class(CameraShakeAdd)
    bpy.utils.register_class(CameraShakeRemove)
    bpy.utils.register_class(CameraShakeMove)
    bpy.utils.register_class(CameraShakesFixGlobal)
    bpy.utils.register_class(CameraShakifyPrepFileForFarm)

    # # Only needed for creating new shakes to add to this addon. Not for end users.
    # bpy.utils.register_class(ActionToPythonData)
    # bpy.types.VIEW3D_MT_object.append(
    #     lambda self, context : self.layout.operator(ActionToPythonData.bl_idname)
    # )

    # The list of camera shakes active on an camera, along with each shake's parameters.
    bpy.types.Object.camera_shakes = bpy.props.CollectionProperty(type=CameraShakeInstance)
    bpy.types.Object.camera_shakes_active_index = bpy.props.IntProperty(
        name="Camera Shake List Active Item Index",
        get=_camera_shakes_active_index_get,
        set=_camera_shakes_active_index_set,
        options={'SKIP_SAVE'},
    )

    bpy.types.WindowManager.camera_shake_show_utils = bpy.props.BoolProperty(name="Show Camera Shake Utils UI", default=False)
    if _camera_shake_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_camera_shake_load_post)


def unregister():
    _clear_camera_shake_active_index_cache()
    if _camera_shake_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_camera_shake_load_post)
    del bpy.types.Object.camera_shakes
    del bpy.types.Object.camera_shakes_active_index
    # This foldout is registered dynamically with Camera Shakify and therefore
    # must be removed with the rest of that tool.  Leaving it on WindowManager
    # kept add-on-owned RNA alive after Smart Animation was disabled and made a
    # subsequent enable start from stale UI state.
    if hasattr(bpy.types.WindowManager, "camera_shake_show_utils"):
        del bpy.types.WindowManager.camera_shake_show_utils

    bpy.utils.unregister_class(CameraShakifyPanel)
    bpy.utils.unregister_class(OBJECT_UL_camera_shake_items)
    bpy.utils.unregister_class(CameraShakeInstance)
    bpy.utils.unregister_class(CameraShakeAdd)
    bpy.utils.unregister_class(CameraShakeRemove)
    bpy.utils.unregister_class(CameraShakeMove)
    bpy.utils.unregister_class(CameraShakesFixGlobal)
    bpy.utils.unregister_class(CameraShakifyPrepFileForFarm)

    #bpy.utils.unregister_class(ActionToPythonData)


if __name__ == "__main__":
    register()


def list_item(layout, item, icon, layout_type):
    if layout_type == 'GRID':
        layout.alignment = 'CENTER'
        layout.label(text="", icon_value=icon)
        return
    if layout_type not in ('DEFAULT', 'COMPACT'):
        return
    title = ' '.join(item.shake_type.split('_')).title()
    layout.column().label(text=title, icon='FCURVE_SNAPSHOT')
    gain = layout.column()
    gain.alignment = 'RIGHT'
    gain.prop(item, 'influence', text="", slider=True, emboss=False)


def remove_item(camera, context, rebuild):
    items = camera.camera_shakes
    active = camera.camera_shakes_active_index
    if not 0 <= active < len(items):
        return False
    items.remove(active)
    camera.camera_shakes_active_index = max(0, min(active, len(items)-1))
    rebuild(camera, context)
    return True


def move_item(camera, context, direction, rebuild):
    items = camera.camera_shakes
    active = camera.camera_shakes_active_index
    destination = active - 1 if direction == 'UP' else active + 1
    if 0 <= active < len(items) and 0 <= destination < len(items):
        items.move(active, destination)
        camera.camera_shakes_active_index = destination
        rebuild(camera, context)
        return True
    return False


