# Camera Shakify — upstream attribution and source notice

Original project: Camera Shakify, Nathan Vegdahl and Ian Hubert.

Original repository: https://github.com/EatTheFuture/camera_shakify

Compared source commit: `a59d9f91dd899dd5e8539dec1e7d5d2c69516920`.
The upstream extension manifest at this commit reports version 0.5.1 while
its legacy `bl_info` reports 0.5.0. Both identifiers are retained as source
evidence; the historically acquired ZIP has not been identified by hash.

## Code

`__init__.py`, `action_utils.py`, and `farm_script.py` correspond to upstream
code under GPL-3.0-or-later. The applicable terms are included in
`UPSTREAM_LICENSE_GPL-3.0.txt`. The upstream manifest records **2021-2025 Ian
Hubert & Nathan Vegdahl**. Smart Animation contains integration changes in the
first two files; `farm_script.py` is byte-identical to the compared source.
Original authorship is retained and is not replaced by the integration brand.

## Camera-shake data

This release generates new looping curves mathematically in `shake_data.py`.
The original recordings are not included. The existing preset IDs, labels and
frame ranges are retained for scene compatibility; the motion curves differ.
The prior release used upstream camera-shake samples dedicated under CC0.
`UPSTREAM_DATA_CC0.txt` remains as a provenance record. The code attribution
and applicable terms above remain in force.

## Integration record

The integration project is JELararagi. The seller reports human ideation and
AI implementation. This does not claim that JELararagi authored the original
code or captured the original camera-shake data. Whole-package licensing and
distribution clearance require separate review.
