# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Simplify Curves+",
    "author": "JELararagi",
    "version": (1, 1, 3),
    "blender": (5, 1, 0),
    "location": "Graph Editor / View3D",
    "description": "Simplify curve objects and selected animation F-Curves",
    "category": "Animation",
}

"""
This script simplifies Curve objects and animation F-Curves
This script will also Merge by Distance 3d view curves in edit mode
"""

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
)
import mathutils
from math import (
    sin,
    pow,
)
from bpy.types import Operator

from ..action_compat import iter_action_fcurves


def _iter_object_action_fcurves(obj):
    anim_data = getattr(obj, "animation_data", None)
    action = getattr(anim_data, "action", None) if anim_data else None
    if action is None:
        return []
    return list(iter_action_fcurves(action, datablock=obj))


def error_handlers(self, op_name, errors, reports="ERROR"):
    if self and reports:
        self.report({'INFO'},
                    bpy.app.translations.pgettext("{}: some operations could not be performed").format(reports))

    pass  # Console-silent bundled-tool diagnostic.


# Check for curve

# ### simplipoly algorithm ###

# get SplineVertIndices to keep
def simplypoly(points, options):
    width = options[3]
    scale = width - 1
    curvature_limit = options[2] * 0.01
    height_limit = options[6] * 0.1
    curvature_samples = [[] for _ in points]
    for first in range(len(points) - scale):
        window = points[first:first + width]
        velocity = getDerivative(window, 1.0 / scale, scale)
        acceleration = getDerivative(window, 1.0 / scale, scale - 1)
        curvature = getCurvature(velocity, acceleration)
        for index in range(first + 1, first + scale):
            curvature_samples[index].append(curvature)

    heights = [0.0] * len(points)
    for index in range(1, len(points) - 1):
        heights[index] = altitude(points[index - 1], points[index + 1], points[index])
    keep = [index for index, (samples, height) in
            enumerate(zip(curvature_samples, heights, strict=True))
            if sum(samples) / scale >= curvature_limit or height >= height_limit]
    return [0, *keep, len(points) - 1]


# get binomial coefficient
def binom(n, m):
    from math import comb
    # Keep Python list indexing semantics for callers using negative offsets.
    index = range(n + 1)[m]
    return comb(n, index)


# get nth derivative of order(len(verts)) bezier curve
def getDerivative(verts, t, nth):
    order = len(verts) - 1 - nth
    QVerts = []

    if nth:
        for i in range(nth):
            if QVerts:
                verts = QVerts
            derivVerts = []
            for i in range(len(verts) - 1):
                derivVerts.append(verts[i + 1] - verts[i])
            QVerts = derivVerts
    else:
        QVerts = verts

    if len(verts[0]) == 3:
        point = mathutils.Vector((0, 0, 0))
    if len(verts[0]) == 2:
        point = mathutils.Vector((0, 0))

    for i, vert in enumerate(QVerts):
        point += binom(order, i) * pow(t, i) * pow(1 - t, order - i) * vert
    deriv = point

    return deriv


# get curvature from first, second derivative
def getCurvature(deriv1, deriv2):
    if deriv1.length == 0:  # in case of points in straight line
        curvature = 0
        return curvature
    curvature = (deriv1.cross(deriv2)).length / pow(deriv1.length, 3)
    return curvature


from .distance_reduction import indices_within_error, perpendicular_line_distance as altitude


def simplify_RDP(splineVerts, options):
    return indices_within_error(splineVerts, options[4])


# ### CURVE GENERATION ###

# set bezierhandles to auto
def setBezierHandles(newCurve):
    # Faster:
    for spline in newCurve.data.splines:
        for p in spline.bezier_points:
            p.handle_left_type = 'AUTO'
            p.handle_right_type = 'AUTO'


# get array of new coords for new spline from vertindices
def vertsToPoints(indices, points, spline_type):
    from itertools import chain
    extra = {'BEZIER': (), 'NURBS': (1,)}.get(spline_type, (0,))
    return list(chain.from_iterable(points[index].to_tuple() + extra for index in indices))


# ### MAIN OPERATIONS ###

def main(context, obj, options, curve_dimension):
    mode, output, _, _, _, order, _, keep_short = options
    choose = {'DISTANCE': simplify_RDP, 'CURVATURE': simplypoly}[mode]
    curve_name = f"Simple_{obj.name}"
    plans = []
    for src in obj.data.splines:
        bezier = src.type == 'BEZIER'
        source_points = src.bezier_points if bezier else src.points
        if not source_points or (len(source_points) < 3 and not keep_short):
            continue
        coordinates = [point.co.copy() if bezier else point.co.to_3d() for point in source_points]
        retained = choose(coordinates, options)
        kind = src.type if output == 'INPUT' else output
        plans.append((kind, [coordinates[index] for index in retained], src.use_endpoint_u))

    curve = bpy.data.curves.new(curve_name, 'CURVE')
    curve.dimensions = curve_dimension
    for kind, coordinates, endpoint in plans:
        spline = curve.splines.new(kind)
        if kind == 'BEZIER':
            points = spline.bezier_points
            points.add(len(coordinates) - 1)
            for point, coordinate in zip(points, coordinates, strict=True):
                point.co = coordinate
                point.handle_left_type = 'AUTO'
                point.handle_right_type = 'AUTO'
        else:
            weight = 1.0 if kind == 'NURBS' else 0.0
            points = spline.points
            points.add(len(coordinates) - 1)
            for point, coordinate in zip(points, coordinates, strict=True):
                point.co = (*coordinate, weight)
        if output == 'NURBS':
            spline.order_u = order
        spline.use_endpoint_u = endpoint

    generated = bpy.data.objects.new(curve_name, curve)
    view_layer = context.view_layer
    view_layer.active_layer_collection.collection.objects.link(generated)
    generated.matrix_world = obj.matrix_world
    bpy.ops.object.select_all(action='DESELECT')
    generated.select_set(True)
    view_layer.objects.active = generated


# get preoperator fcurves
def getFcurveData(obj):
    fcurves = []
    for fc in _iter_object_action_fcurves(obj):
        if fc.select:
            fcVerts = [vcVert.co.to_3d()
                       for vcVert in fc.keyframe_points.values()]
            fcurves.append(fcVerts)
    return fcurves


def selectedfcurves(obj):
    fcurves_sel = []
    for i, fc in enumerate(_iter_object_action_fcurves(obj)):
        if fc.select:
            fcurves_sel.append(fc)
    return fcurves_sel


# fCurves Main
def fcurves_simplify(context, obj, options, fcurves):
    simplify = {'DISTANCE': simplify_RDP, 'CURVATURE': simplypoly}[options[0]]
    targets = selectedfcurves(obj)
    plans = [
        (channel.keyframe_points, [(samples[index].x, samples[index].y)
                                  for index in simplify(samples, options)])
        for channel, samples in zip(targets, fcurves)
        if len(samples) >= 3
    ]
    for points, positions in plans:
        for index in range(len(points) - 1, 0, -1):
            points.remove(points[index])
        for frame, value in positions:
            points.insert(frame=frame, value=value)


# ### MENU append ###

def menu_func(self, context):
    self.layout.operator("graph.simplify")


def menu(self, context):
    self.layout.operator("curve.simplify", text="Curve Simplify", icon="CURVE_DATA")



# ### ANIMATION CURVES OPERATOR ###

from enum import IntEnum

class SimplifyField(IntEnum):
    METHOD=0
    OUTPUT=1
    CURVATURE_LIMIT=2
    SAMPLE_WINDOW=3
    DISTANCE_LIMIT=4
    SPLINE_ORDER=5
    DISTANCE_GUARD=6
    KEEP_SHORT=7


def _simplification_fields(operator, *, output, preserve_short=True):
    arguments=[None] * len(SimplifyField)
    configured = {
        SimplifyField.METHOD: operator.mode,
        SimplifyField.OUTPUT: output,
        SimplifyField.CURVATURE_LIMIT: operator.k_thresh,
        SimplifyField.SAMPLE_WINDOW: operator.pointsNr,
        SimplifyField.DISTANCE_LIMIT: operator.error,
        SimplifyField.SPLINE_ORDER: operator.degreeOut,
        SimplifyField.DISTANCE_GUARD: operator.dis_error,
        SimplifyField.KEEP_SHORT: preserve_short,
    }
    for slot,item in configured.items():
        arguments[slot]=item
    return arguments


class GRAPH_OT_simplify(Operator):
    bl_idname = "graph.simplify"
    bl_label = "Simplify F-Curves"
    bl_description = ("Simplify selected Curves\n"
                      "Does not operate on short Splines (less than 3 points)")
    bl_options = {'UNDO'}

    # Properties
    opModes = [
            ('DISTANCE', 'Distance', 'Distance-based simplification (Poly)'),
            ('CURVATURE', 'Curvature', 'Curvature-based simplification (RDP)')]
    mode: EnumProperty(
            name="Mode",
            description="Choose algorithm to use",
            items=opModes
            )
    k_thresh: FloatProperty(
            name="k",
            min=0, soft_min=0,
            default=0, precision=5,
            description="Threshold"
            )
    pointsNr: IntProperty(
            name="n",
            min=5, soft_min=5,
            max=16, soft_max=9,
            default=5,
            description="Degree of curve to get averaged curvatures"
            )
    error: FloatProperty(
            name="Error",
            description="Maximum allowed distance error",
            min=0.0, soft_min=0.0,
            default=0, precision=5,
            step = 0.1
            )
    degreeOut: IntProperty(
            name="Degree",
            min=3, soft_min=3,
            max=7, soft_max=7,
            default=5,
            description="Degree of new curve"
            )
    dis_error: FloatProperty(
            name="Distance error",
            description="Maximum allowed distance error in Blender Units",
            min=0, soft_min=0,
            default=0.0, precision=5
            )
    fcurves = []

    def draw(self, context):
        layout = self.layout
        col = layout.column()

        col.label(text="Distance Error:")
        col.prop(self, "error", expand=True)

    @classmethod
    def poll(cls, context):
        # Check for animdata
        obj = context.active_object
        if not obj:
            return False
        return bool(_iter_object_action_fcurves(obj))

    def execute(self, context):
        animated=context.active_object
        channels=selectedfcurves(animated) if animated is not None else ()
        if not any(len(channel.keyframe_points)>=3 for channel in channels):
            self.report({'INFO'}, "Select an animation curve with at least three keys")
            return {'CANCELLED'}
        if not self.fcurves:
            self.fcurves = [[point.co.to_3d() for point in channel.keyframe_points] for channel in channels]
        options=_simplification_fields(self, output=self.mode)
        fcurves_simplify(context, animated, options, self.fcurves)
        return {'FINISHED'}


# ### Curves OPERATOR ###
class CURVE_OT_simplify(Operator):
    bl_idname = "curve.simplify"
    bl_label = "Simplify Curves"
    bl_description = ("Simplify the existing Curve based upon the chosen settings\n"
                      "Notes: Needs an existing Curve object,\n"
                      "Outputs a new Curve with the Simple prefix in the name")
    bl_options = {'UNDO'}

    # Properties
    opModes = [
            ('DISTANCE', 'Distance', 'Distance-based simplification (Poly)'),
            ('CURVATURE', 'Curvature', 'Curvature-based simplification (RDP)')
            ]
    mode: EnumProperty(
            name="Mode",
            description="Choose algorithm to use",
            items=opModes
            )
    SplineTypes = [
            ('INPUT', 'Input', 'Same type as input spline'),
            ('NURBS', 'Nurbs', 'NURBS'),
            ('BEZIER', 'Bezier', 'BEZIER'),
            ('POLY', 'Poly', 'POLY')
            ]
    output: EnumProperty(
            name="Output splines",
            description="Type of splines to output",
            items=SplineTypes
            )
    k_thresh: FloatProperty(
            name="k",
            min=0, soft_min=0,
            default=0, precision=5,
            description="Threshold"
            )
    pointsNr: IntProperty(
            name="n",
            min=5, soft_min=5,
            max=9, soft_max=9,
            default=5,
            description="Degree of curve to get averaged curvatures"
            )
    error: FloatProperty(
            name="Error",
            description="Maximum allowed distance error in Blender Units",
            min=0, soft_min=0,
            default=0.0, precision=5,
            step = 0.1
            )
    degreeOut: IntProperty(
            name="Degree",
            min=3, soft_min=3,
            max=7, soft_max=7,
            default=5,
            description="Degree of new curve"
            )
    dis_error: FloatProperty(
            name="Distance error",
            description="Maximum allowed distance error in Blender Units",
            min=0, soft_min=0,
            default=0.0
            )
    keepShort: BoolProperty(
            name="Keep short splines",
            description="Keep short splines (less than 3 points)",
            default=True
            )

    def draw(self, _context):
        controls=self.layout.column(align=True)
        controls.label(text="Distance Error:")
        for field, display in (("error", {"expand":True}),
                               ("output", {"text":"Output","icon":"OUTLINER_OB_CURVE"})):
            controls.prop(self, field, **display)
        if self.output == "NURBS":
            controls.prop(self, "degreeOut", expand=True)
        controls.separator()
        controls.prop(self, "keepShort", expand=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'CURVE')

    def execute(self, context):
        curve=context.active_object
        if curve is None or curve.type != 'CURVE':
            return {'CANCELLED'}
        record=_simplification_fields(self, output=self.output, preserve_short=self.keepShort)
        try:
            if curve.mode != 'OBJECT':
                if bpy.ops.object.mode_set(mode='OBJECT') != {'FINISHED'}:
                    return {'CANCELLED'}
            main(context, curve, record, curve.data.dimensions)
        except Exception as failure:
            error_handlers(self, self.bl_idname, failure, self.bl_label)
            return {'CANCELLED'}
        return {'FINISHED'}

## Initial use Curve Remove Doubles ##

def main_rd(context, distance=0.01):
    if context.mode != 'EDIT_CURVE':
        bpy.ops.object.mode_set(mode='EDIT')
    removed = []
    for obj in context.objects_in_mode_unique_data:
        for spline in obj.data.splines:
            bezier = spline.type == 'BEZIER'
            points = spline.bezier_points if bezier else spline.points
            selected = 'select_control_point' if bezier else 'select'
            count = len(points)
            if count < 2:
                continue
            discarded = set()
            start = 0 if spline.use_cyclic_u else 1
            for index in range(start, count):
                previous = (index - 1) % count
                while previous in discarded:
                    previous = (previous - 1) % count
                if previous == index:
                    continue
                current, retained = points[index], points[previous]
                if not (getattr(current, selected) and getattr(retained, selected)):
                    continue
                if (current.co - retained.co).length < distance:
                    if bezier:
                        retained.handle_right_type = 'FREE'
                        retained.handle_right = current.handle_right
                    retained.co = (retained.co + current.co) * 0.5
                    discarded.add(index)
                    removed.append((current, selected))
                elif bezier:
                    if (current.handle_left_type == 'VECTOR'
                            and (retained.handle_right - retained.co).length < distance):
                        retained.handle_right_type = 'VECTOR'
                    if (retained.handle_right_type == 'VECTOR'
                            and (current.handle_left - current.co).length < distance):
                        current.handle_left_type = 'VECTOR'

    bpy.ops.curve.select_all(action='DESELECT')
    if removed:
        for point, selected in removed:
            setattr(point, selected, True)
        bpy.ops.curve.delete(type='VERT')
        bpy.ops.curve.select_all(action='DESELECT')
    return len(removed)



class Curve_OT_CurveRemvDbs(bpy.types.Operator):
    """Merge consecutive points that are near to each other"""
    bl_idname = 'curve.remove_double'
    bl_label = 'Merge By Distance'
    bl_options = {'UNDO'}

    distance: bpy.props.FloatProperty(name = 'Distance', default = 0.01, soft_min = 0.001, step = 0.1)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'CURVE')

    def execute(self, context):
        removed=main_rd(context, self.distance)
        self.report({'INFO'}, bpy.app.translations.pgettext("Removed {} bezier points").format(removed))
        return {'FINISHED'}

def menu_func_rd(self, context):
    self.layout.operator(Curve_OT_CurveRemvDbs.bl_idname, text='Merge By Distance')

# Register
classes = [
    GRAPH_OT_simplify,
    CURVE_OT_simplify,
    Curve_OT_CurveRemvDbs,
]


_MENU_CALLBACKS_ENABLED = False


def _safe_append_menu(menu_type, callback, *, prepend=False):
    try:
        menu_type.remove(callback)
    except Exception:
        pass
    try:
        if prepend:
            menu_type.prepend(callback)
        else:
            menu_type.append(callback)
    except Exception:
        pass


def _safe_remove_menu(menu_type, callback):
    try:
        menu_type.remove(callback)
    except Exception:
        pass


def enable_menu_callbacks():
    """Enable optional Simplify Curves+ menu entries from the central always-on switch."""
    global _MENU_CALLBACKS_ENABLED
    _MENU_CALLBACKS_ENABLED = True
    _safe_append_menu(bpy.types.GRAPH_MT_channel, menu_func)
    _safe_append_menu(bpy.types.VIEW3D_MT_curve_add, menu)
    _safe_append_menu(bpy.types.VIEW3D_MT_edit_curve_context_menu, menu, prepend=True)
    _safe_append_menu(bpy.types.VIEW3D_MT_edit_curve_context_menu, menu_func_rd, prepend=True)


def disable_menu_callbacks():
    """Disable optional Simplify Curves+ menu entries from the central always-on switch."""
    global _MENU_CALLBACKS_ENABLED
    _MENU_CALLBACKS_ENABLED = False
    _safe_remove_menu(bpy.types.GRAPH_MT_channel, menu_func)
    _safe_remove_menu(bpy.types.VIEW3D_MT_curve_add, menu)
    _safe_remove_menu(bpy.types.VIEW3D_MT_edit_curve_context_menu, menu)
    _safe_remove_menu(bpy.types.VIEW3D_MT_edit_curve_context_menu, menu_func_rd)



def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    disable_menu_callbacks()


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

    disable_menu_callbacks()

if __name__ == "__main__":
    register()
