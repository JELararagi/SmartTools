# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bounded polyline reduction for recorded motion and spatial curves."""

from math import dist


def _chord_distance(start, end, point, bounded):
    direction = tuple(b - a for a, b in zip(start, end))
    offset = tuple(p - a for p, a in zip(point, start))
    length2 = sum(component * component for component in direction)
    if length2 == 0.0:
        return dist(point, start)
    projection = sum(u * v for u, v in zip(offset, direction)) / length2
    if bounded and projection <= 0.0:
        return dist(point, start)
    if bounded and projection >= 1.0:
        return dist(point, end)
    nearest = tuple(origin + projection * step for origin, step in zip(start, direction))
    return dist(point, nearest)


def perpendicular_line_distance(start, end, point):
    return _chord_distance(start, end, point, bounded=False)


def indices_within_error(points, tolerance):
    """Keep the endpoints and split a span whenever a sample lies outside it."""
    samples = [tuple(point) for point in points]
    if len(samples) < 3:
        return list(range(len(samples)))
    last = len(samples) - 1
    keep = {0, last}
    pending = [(0, last)]
    while pending:
        start, end = pending.pop()
        furthest_distance = tolerance
        split = None
        for index in range(start + 1, end):
            distance = _chord_distance(samples[start], samples[end], samples[index], bounded=True)
            if distance > furthest_distance:
                split, furthest_distance = index, distance
        if split is not None:
            keep.add(split)
            if split - start > 1:
                pending.append((start, split))
            if end - split > 1:
                pending.append((split, end))
    return sorted(keep)