# SPDX-License-Identifier: GPL-3.0-or-later
"""Register the integrated Sakura PoseLib tool as one unit."""
from importlib import import_module

bl_info = {
    "name": "Sakura PoseLib",
    "author": "JELararagi",
    "version": (1, 4, 4),
    "blender": (5, 1, 0),
    "location": "3D Viewport Side Panel -> Sakura -> Sakura PoseLib",
    "description": "Pose library for capturing and reusing poses",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

module_names = ["translation", "preferences", "spl", "operators", "panel", "menu", "hotkey", "handlers"]
modules = [import_module(f".{name}", __package__) for name in module_names]
_REGISTERED_MODULES = []


def register():
    if _REGISTERED_MODULES:
        return True
    for module in modules:
        try:
            if module.register() is False:
                unregister()
                return False
        except Exception:
            unregister()
            return False
        _REGISTERED_MODULES.append(module)
    return True


def unregister():
    healthy = True
    while _REGISTERED_MODULES:
        cleanup = _REGISTERED_MODULES.pop().unregister
        try:
            healthy = cleanup() is not False and healthy
        except Exception:
            healthy = False
    return healthy


if __name__ == "__main__":
    register()
