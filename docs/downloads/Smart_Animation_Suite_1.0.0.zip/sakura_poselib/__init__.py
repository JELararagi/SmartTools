# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
	"name": "Sakura PoseLib",
	"author": "JELararagi",
	"version": (1, 4, 4),
	"blender": (5, 1, 0),
	"location": "3D Viewport Side Panel -> Sakura -> Sakura PoseLib",
	"description": "Yet another pose library with handful of features",
	"warning": "",
	"doc_url": "",
	"category": "Animation",
}

# Modules (in order to load)
module_names = [
	"translation",
	"preferences",
	"spl",
	"operators",
	"panel",
	"menu",
	"hotkey",
	"handlers",
]


# Import and store modules in a list
modules = [__import__(__package__ + "." + name, fromlist=[name]) for name in module_names]

_REGISTERED_MODULES = []

# Register & Unregister
def register():
	_REGISTERED_MODULES.clear()
	healthy = True
	for module in modules:
		try:
			result = module.register()
		except Exception:
			result = False
		if result is False:
			healthy = False
			break
		_REGISTERED_MODULES.append(module)
	if not healthy:
		for module in reversed(tuple(_REGISTERED_MODULES)):
			try:
				module.unregister()
			except Exception:
				pass
		_REGISTERED_MODULES.clear()
		return False
	return True


def unregister():
	registered = list(_REGISTERED_MODULES)
	healthy = True
	for module in reversed(registered):
		try:
			result = module.unregister()
			if result is False:
				healthy = False
		except Exception:
			healthy = False
	_REGISTERED_MODULES.clear()
	return healthy


if __name__ == "__main__":
	register()
