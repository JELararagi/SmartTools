# SPDX-License-Identifier: GPL-3.0-or-later
"""Preference descriptors for the suite's integrated PoseLib."""
from bpy.props import BoolProperty

_DISPLAY = (
    ("show_alt_pose_names", "TEXT"),
    ("show_apply_buttons", "VIEWZOOM"),
    ("show_select_bones_buttons", "RESTRICT_SELECT_OFF"),
    ("show_replace_buttons", "GREASEPENCIL"),
)
_BEHAVIOUR = (
    ("activate_poses_on_book_change", "FILE_REFRESH"),
    ("confirm_on_replace", "CHECKMARK"),
)


class SPL_Preferences:
    bl_idname = __package__

    show_alt_pose_names: BoolProperty(
        name="Show Alt Names",
        description="Show alternative pose names. Mainly intended for translation. Not used as identifier in blender",
        default=True,
    )
    show_apply_buttons: BoolProperty(
        name="Show Apply Buttons", description="Show apply buttons in the pose list", default=False,
    )
    show_select_bones_buttons: BoolProperty(
        name="Show Select Bones Buttons", description="Show select bones buttons in the pose list", default=False,
    )
    show_replace_buttons: BoolProperty(
        name="Show Replace Buttons", description="Show replace buttons in the pose list", default=True,
    )
    activate_poses_on_book_change: BoolProperty(
        name="Activate Poses on Book Change",
        description="Activate the poses on the active book when the active book is changed",
        default=False,
    )
    confirm_on_replace: BoolProperty(
        name="Confirm on Replace Pose", description="Show a confirmation dialog when replacing a pose", default=False,
    )

    def draw(self, context):
        listing = self.layout.box()
        listing.label(text="Pose List Display Settings")
        cells = listing.grid_flow(columns=2, even_columns=True, even_rows=True)
        for name, icon in _DISPLAY:
            cells.prop(self, name, icon=icon)

        options = self.layout.box()
        options.label(text="Basic Behaviour Settings")
        for name, icon in _BEHAVIOUR:
            options.prop(self, name, icon=icon)


_classes = (SPL_Preferences,)


def register():
    """The containing suite manages preferences."""


def unregister():
    """The containing suite manages preferences."""
