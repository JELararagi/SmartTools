"""Own the two optional SmartAnimation shortcuts in the Pose keymap."""

import bpy


_pose_bindings = (
    ("wm.call_menu", {"shift": True}, "SPL_MT_PoseMenu"),
    ("spl.pose_preview", {"alt": True}, None),
)
_owned_items = {}


def _pose_keymap(create=False):
    config = bpy.context.window_manager.keyconfigs.addon
    if config is None:
        return None
    pose = config.keymaps.get("Pose")
    if pose is None and create:
        pose = config.keymaps.new(name="Pose", space_type="EMPTY")
    return pose


def _owned_item(keymap, operator):
    ownership = _owned_items.get(operator)
    if ownership is None or ownership[0] != keymap.as_pointer():
        return None
    item = keymap.keymap_items.from_id(ownership[1])
    if item is not None and item.as_pointer() == ownership[2]:
        return item
    return None


def register_keymaps():
    keymap = _pose_keymap(create=True)
    if keymap is None:
        return
    for operator, modifiers, menu in _pose_bindings:
        if _owned_item(keymap, operator) is not None:
            continue
        item = keymap.keymap_items.new(operator, "L", "PRESS", **modifiers)
        if menu is not None:
            item.properties.name = menu
        _owned_items[operator] = (keymap.as_pointer(), item.id, item.as_pointer())


def unregister_keymaps():
    keymap = _pose_keymap()
    if keymap is not None:
        for operator in _owned_items:
            item = _owned_item(keymap, operator)
            if item is not None:
                keymap.keymap_items.remove(item)
    _owned_items.clear()


def enable_hotkeys():
    register_keymaps()


def disable_hotkeys():
    unregister_keymaps()


def register():
    disable_hotkeys()


def unregister():
    disable_hotkeys()
