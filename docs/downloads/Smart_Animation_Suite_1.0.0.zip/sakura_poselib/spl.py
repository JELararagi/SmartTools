# Properties for Sakura Poselib
import re
import bpy
from .preferences import SPL_Preferences
from ..global_preferences import get_preferences as _get_integrated_preferences
from ..action_compat import assign_action_to_datablock, ensure_action_fcurve, supports_legacy_action_api
from bpy.types import PropertyGroup
from bpy.props import *
from mathutils import Vector, Quaternion, Euler, Matrix
from typing import Optional

from . import utils

# pose categories definition
POSE_CATEGORIES = [
			("ALL", "All", "Show All"), # For display purposes only
			("EYEBROW", "Eyebrow", "Show Eyebrow Poses"),
			("EYE", "Eye", "Show Eye Poses"),
			("MOUTH", "Mouth", "Show Mouth Poses"),
			("OTHER", "Other", "Show Other Poses (Body, FX, etc)"),
]


###################################################
# Internal Functions
###################################################

# Resolve naming collision in the collection. self is the item just renamed.
def resolve_naming_collision(self, collection):
    """Choose an unused numbered pose name while leaving sibling names intact."""
    occupied = {str(entry.name) for entry in collection if entry != self}
    name = str(self.name)
    if name not in occupied:
        return
    base = re.sub(r"\.[0-9]{3}$", "", name)
    for suffix in range(1, len(occupied) + 2):
        proposal = f"{base}.{suffix:03d}"
        if proposal not in occupied:
            self["name"] = proposal
            return


def _blend_constraint(pose):
    obj = pose.get("obj")
    name = pose.get("constraint_name")
    if obj is not None and name:
        return obj.constraints.get(name)
    return None


# Get armature object from ID datablock
def get_armature_from_id( data:bpy.types.ID ) -> Optional[bpy.types.Object]:
	obj:bpy.types.Object = data.id_data

	if obj.pose:
		return obj

	if obj.get(__PROXY_IDENTIFIER):
		return obj.get(__PROXY_OWNER)

	pass  # Console-silent bundled-tool diagnostic.
	return None

# Reset pose of armature
def armature_reset_pose(arm):
    neutral_values = {
        "location": (0, 0, 0),
        "rotation_euler": (0, 0, 0),
        "rotation_quaternion": (1, 0, 0, 0),
        "rotation_axis_angle": (0, 0, 0, 0),
        "scale": (1, 1, 1),
    }
    for bone in arm.pose.bones:
        for name, value in neutral_values.items():
            setattr(bone, name, value)


# Update Combined Pose
def update_combined_pose(book):
    rig = get_armature_from_id(book)
    library = get_poselib(rig)
    if library is None or library.enable_animation:
        return

    channels = {}
    for pose in book.poses:
        for entry in pose.bones:
            channels.setdefault(entry.name, []).append((pose.value, entry))

    for name, entries in channels.items():
        target = rig.pose.bones.get(name)
        if target is None:
            continue
        location = Vector((0.0, 0.0, 0.0))
        rotation = Vector((0.0, 0.0, 0.0))
        scale = Vector((1.0, 1.0, 1.0))
        for influence, entry in entries:
            if influence:
                location += influence * entry.location
                rotation += influence * Vector(entry.rotation.to_euler())
                for axis in range(3):
                    scale[axis] += influence * (entry.scale[axis] - 1.0)
        mode = target.rotation_mode
        target.rotation_mode = 'QUATERNION'
        try:
            target.location = location
            target.rotation_quaternion = Euler(rotation).to_quaternion()
            target.scale = scale
        finally:
            target.rotation_mode = mode


###################################################
# Property Groups
###################################################

# Transform Data for each bone
class BoneTransform(PropertyGroup):
	# callback for bone name change
	def update_bone_name(self, context):
		pose = self.get_pose()
		if not pose:
			return
		# resolve naming collision
		resolve_naming_collision(self, pose.bones)
		return

	name: StringProperty(name="Bone Name", update=update_bone_name)
	location: FloatVectorProperty(name="Location", size=3, default=(0, 0, 0), subtype='TRANSLATION' )
	rotation: FloatVectorProperty(name="Rotation", size=4, default=(1, 0, 0, 0), subtype='QUATERNION') # Quartanion
	scale: FloatVectorProperty(name="Scale", size=3, default=(1, 1, 1), subtype='XYZ')

	# get the pose this bone belongs to
	def get_pose(self) -> Optional["PoseData"]:
		path = self.path_from_id() # sakura_poselib.books[n].poses[n].bones[n]'
		# strip the last part
		path = re.sub(r"\.[^.]*$", "", path)
		# resolve the path
		return self.id_data.path_resolve(path)

	def copy_from(self, bone):
		self.name = bone.name
		self.location = bone.location
		self.rotation = bone.rotation
		self.scale = bone.scale


# Data for each pose
class PoseData(PropertyGroup):
	# callback for pose name change
	def update_pose_name(self, context):
		parent = self.get_book()
		resolve_naming_collision(self, parent.poses)
		linked = self.get_action()
		refreshed = self.make_action_name()
		self.action_name = refreshed
		if linked is None:
			self.action_uptodate = False
		else:
			linked.name = refreshed

	########################################################################################
	# Properties
	name: StringProperty(
		name="Pose Name",
		default="New Pose",
		update=update_pose_name,
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},
	)


	name_alt: StringProperty(
		name="Pose Name (Alt)",
		description="Alternative name. Mainly intended for translation. Not used as idetifier in blender",
		default="",
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},
	)

	category: EnumProperty(
		name="Category",
		items=POSE_CATEGORIES,
		default="OTHER",
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},
	)

	# callback for pose value change
	def update_pose_value(self, context):
		if self.get('obj') and self.get('constraint_name'):
			return

		book = self.get_book()
		update_combined_pose(book)
		return

	# callback for pose value change
	def set_pose_value(self, value):
		self["value"] = value
		apply_to = _blend_constraint(self)
		if apply_to is not None:
			apply_to.influence = value

	def get_pose_value(self):
		active = _blend_constraint(self)
		return active.influence if active is not None else self.get("value", 0.0)

	value: FloatProperty(
			name="Value", default=0.0, soft_min=0.0, soft_max=1.0,
			# get=get_pose_value, set=set_pose_value,
			update=update_pose_value,
			options=set(),
			override={'LIBRARY_OVERRIDABLE'},
		)
	bones: CollectionProperty(
		type=BoneTransform,
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE', 'USE_INSERTION'},
	)
	active_bone_index: IntProperty(
		override={'LIBRARY_OVERRIDABLE'},
	)

	########################################################################################
	# Basic Operations

	# returns the armature object of the pose belongs to
	def get_armature(self) -> Optional[bpy.types.Object]:
		return get_armature_from_id(self)

	def get_poselib(self) -> Optional["PoselibData"]:
		return self.id_data.sakura_poselib

	# returns the PoseBook object of the pose belongs to
	def get_book(self) -> Optional["PoseBook"]:
		path = self.path_from_id() # sakura_poselib.books[x].poses[x]

		# strip the last part
		path = re.sub(r"\.[^.]*$", "", path)

		# resolve the path
		book = self.id_data.path_resolve(path)
		return book

	def get_active_bone(self) -> Optional[BoneTransform]:
		if self.active_bone_index < 0 or self.active_bone_index >= len(self.bones):
			return None
		return self.bones[self.active_bone_index]

	def add_bone(self, name:str) -> BoneTransform:
		bone = self.bones.add()
		bone.name = name
		self.active_bone_index = len(self.bones) - 1
		return bone

	def remove_bone(self, name: str):
		index = self.bones.find(name)
		if index >= 0:
			self.bones.remove(index)
		self.active_bone_index = min(max(0, self.active_bone_index), max(0, len(self.bones) - 1))
		self.action_uptodate = False

	def get_bone_by_name(self, name:str) -> Optional[BoneTransform]:
		for bone in self.bones:
			if bone.name == name:
				return bone
		return None

	def copy_from(self, pose: "PoseData"):
		source = pose
		if source == self:
			return
		for field in ("name", "name_alt", "category"):
			setattr(self, field, getattr(source, field))
		self.bones.clear()
		for source_bone in source.bones:
			target = self.add_bone(source_bone.name)
			target.copy_from(source_bone)
		self.action_uptodate = False
		self.ensure_action()

	# helper: check if bone is driven by a driver
	def __is_bone_driver_driven( self, bone:bpy.types.PoseBone, valid_datapaths: list) -> bool:
		return any(f'bones["{bone.name}"]' in dp for dp in valid_datapaths)

	def from_current_pose(self, ignore_hidden_bones: bool = False, ignore_driven_bones: bool = True):
		rig = self.get_armature()
		if rig is None:
			return
		driven_paths = set()
		if ignore_driven_bones and rig.animation_data:
			driven_paths = {curve.data_path for curve in rig.animation_data.drivers if curve.is_valid}
		channels = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")
		identity = Matrix.Identity(4)
		snapshot = []
		for bone in rig.pose.bones:
			if bone.matrix_basis == identity:
				continue
			if ignore_hidden_bones and not utils.is_pose_bone_visible(bone):
				continue
			if any(bone.path_from_id(channel) in driven_paths for channel in channels):
				continue
			rotation = utils.get_pose_bone_rotation_quaternion(bone)
			snapshot.append((bone.name, tuple(bone.location), tuple(rotation), tuple(bone.scale)))
		self.bones.clear()
		for name, location, rotation, scale in snapshot:
			record = self.add_bone(name)
			record.location, record.rotation, record.scale = location, rotation, scale
		self.ensure_action(force_update=True)

	def apply_pose(self, influence: float = 1.0):
		if self.value != influence:
			self.value = influence

		con_name = self.get('constraint_name')
		if con_name:
			arm = self.get_armature()
			if con_name in arm.keys():
				arm[con_name] = influence
				arm.hide_render = arm.hide_render

	def reset_pose(self):
		self.apply_pose(0.0)

	########################################################################################
	# Action related properties
	action_uptodate: BoolProperty(
		default=False,
		options={'HIDDEN', 'SKIP_SAVE', 'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},
	) # This should be resetted on every load

	action_name: StringProperty(
		default="",
		options={'HIDDEN', 'SKIP_SAVE', 'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},
	) # This should be resetted on every load

	# Create action name
	def make_action_name( self ) -> str:
		arm = self.get_armature()
		book = self.get_book()
		return "SPL_" + arm.name.removesuffix("_arm") + "/" + book.name + "/" + self.name

	# Return action for pose
	def get_action(self) -> Optional[bpy.types.Action]:
		return bpy.data.actions.get(self.action_name)

	# Create action for pose
	def ensure_action(self, force_update:bool = False) -> Optional[bpy.types.Action]:
		#print("Ensure Action", self.name)

		spl = self.get_poselib()
		if not spl.enable_animation:
			return None

		action = self.get_action()
		if not action:
			self.action_uptodate = False

		if self.action_uptodate and force_update == False:
			return

		action_name = self.make_action_name()
		if self.action_name != action_name:
			if bpy.data.actions.get(self.action_name):
				#print("Remove Action", self.action_name)
				bpy.data.actions.remove(bpy.data.actions[self.action_name])

		self.action_name = action_name

		# Delete if the action already exists
		if action_name in bpy.data.actions:
			if force_update:
				#print("Remove Action (Forced)", action_name)
				bpy.data.actions.remove(bpy.data.actions[action_name])
			else:
				self.action_uptodate = True
				return bpy.data.actions[action_name]

		arm = self.get_armature()
		action = bpy.data.actions.new(name=action_name)
		orig_anim_data = getattr(arm, 'animation_data', None)
		orig_action = getattr(orig_anim_data, 'action', None) if orig_anim_data else None
		orig_slot = getattr(orig_anim_data, 'action_slot', None) if orig_anim_data else None

		assign_action_to_datablock(arm, action, name_hint=arm.name)
		legacy_action = supports_legacy_action_api(action)

		for bone in self.bones:
			bone_name = bone.name
			transforms = {
				'location': bone.location,
				'rotation': bone.rotation,
				'scale': bone.scale,
			}
			bone = arm.pose.bones.get(bone_name)
			if bone:
				channel_group = None
				if legacy_action:
					try:
						channel_group = action.groups.new(name=bone_name)
					except Exception:
						channel_group = None

				for attr, values in transforms.items() :
					if attr == 'name':
						continue

					# Convert rotation to euler if needed
					if attr == 'rotation':
						pbone = arm.pose.bones.get(bone_name)
						rot_mode = pbone.rotation_mode if pbone else 'QUATERNION' # Default to quaternion
						if rot_mode == 'QUATERNION':
							attr = 'rotation_quaternion'
							rot_conv = lambda x: x
						elif rot_mode == 'AXIS_ANGLE':
							attr = 'rotation_axis_angle'
							rot_conv = lambda x: x.to_axis_angle()
						elif rot_mode in ('XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'):
							attr = 'rotation_euler'
							rot_conv = lambda x: x.to_euler(rot_mode)

						values = rot_conv(Quaternion(values))

					# Create fcurve for each value
					for i, value in enumerate(values):
						if attr == 'scale' or (attr == 'rotation_quaternion' and i == 0):
							if value == 1.0:
								continue
						else:
							if value == 0.0:
								continue

						fcurve = ensure_action_fcurve(action, arm, data_path='pose.bones["'+bone_name+'"].'+attr, index=i, group_name=bone_name)
						if not fcurve:
							continue
						if len(fcurve.keyframe_points) == 0:
							fcurve.keyframe_points.add(1)
						fcurve.keyframe_points[0].co = 0, value
						fcurve.keyframe_points[0].interpolation = 'LINEAR'
						if legacy_action and channel_group is not None:
							try:
								fcurve.group = channel_group
							except Exception:
								pass

		anim_data = getattr(arm, 'animation_data', None)
		if anim_data is not None:
			anim_data.action = orig_action
			try:
				anim_data.action_slot = orig_slot
			except Exception:
				pass

		self.action_uptodate = True
		# print("Action Created", action_name)

		# Create constraints for each bone
		book = self.get_book()
		con_name = "SPL/" + book.name + "/" + self.name
		self['constraint_name'] = con_name

		for bone_data in self.bones:
			pbone: bpy.types.PoseBone = arm.pose.bones.get(bone_data.name)
			if not pbone:
				continue

			# Create constraints for each bone
			con: bpy.types.ActionConstraint = pbone.constraints.get(con_name) or pbone.constraints.new('ACTION')
			con.name = con_name
			con.use_eval_time = True
			con.mix_mode = 'BEFORE_FULL'
			con.action = action
			con.influence = 0.0

			# Create drivers for influence
			fc: bpy.types.FCurve = con.driver_add('influence')
			drv = fc.driver
			drv.type = 'SUM'
			drv.use_self = True
			drv.expression = "var"
			drv.variables.new()
			drv.variables[0].name = "var"
			drv.variables[0].targets[0].id_type = 'OBJECT'
			drv.variables[0].targets[0].id = arm

			# Create custom property for influence
			arm[con_name] = self.value
			ui_data = arm.id_properties_ui(con_name)
			ui_data.update(
				subtype='FACTOR',
				min=0.0,
				max=1.0,
				default=0.0,
				description="Pose Influence for "+con_name,
				precision = 2,
			)

			# Make this property overridable
			arm.property_overridable_library_set('["%s"]' % bpy.utils.escape_identifier(con_name), True)

			# Set driver variable
			drv.variables[0].targets[0].data_path = '["'+con_name+'"]'
		# end for bone_data

		return action

	def invalidate_action(self):
		self.action_uptodate = False

	def remove_action(self):
		name = self.get("constraint_name")
		if not name:
			return
		rig = self.get_armature()
		action = self.get_action()
		owned = False
		if rig is not None:
			for bone in rig.pose.bones:
				constraint = bone.constraints.get(name)
				if constraint is None or constraint.type != "ACTION":
					continue
				if action is not None and constraint.action != action:
					continue
				owned |= action is not None
				constraint.driver_remove("influence")
				bone.constraints.remove(constraint)
			if name in rig:
				del rig[name]
		del self["constraint_name"]
		if owned and action.library is None and action.users == 0:
			bpy.data.actions.remove(action)
		self.action_name = ""
		self.action_uptodate = False





# PoseBook (Collection of Poses)
class PoseBook(PropertyGroup):

	# callback for pose book name change
	def on_posebook_name_update(self, context):
		library = get_poselib(get_armature_from_id(self))
		if library is None:
			return
		entries = tuple(self.poses)
		for entry in entries:
			entry.remove_action()
		resolve_naming_collision(self, library.books)
		if library.enable_animation:
			for entry in entries:
				entry.ensure_action()

	name: StringProperty(
		name="Book Name",
		default="New Book",
		update=on_posebook_name_update,
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE'},

	)

	poses: CollectionProperty(
		type=PoseData,
		options={'LIBRARY_EDITABLE'},
		override={'LIBRARY_OVERRIDABLE', 'USE_INSERTION'},
	)

	active_pose_index: IntProperty(
			override={'LIBRARY_OVERRIDABLE'},
	)


	category_filter: EnumProperty(
		name="Category",
		items=POSE_CATEGORIES,
		default="ALL",
		override={'LIBRARY_OVERRIDABLE'},
	)

	show_alt_pose_names: BoolProperty(
		name="Show Alt Names",
		description="Show alternative pose names. Mainly intended for translation. Not used as idetifier in blender",
		default=False,
		options=set()
		)

	########################################################################################
	# Basic Operations

	def get_armature(self) -> Optional[bpy.types.Object]:
		return get_armature_from_id(self)

	def get_active_pose(self) -> Optional[PoseData]:
		if self.active_pose_index < 0 or self.active_pose_index >= len(self.poses):
			return None
		return self.poses[self.active_pose_index]

	def get_pose_by_name(self, name) -> Optional[PoseData]:
		for pose in self.poses:
			if pose.name == name:
				return pose
		return None

	def get_pose_by_index(self, index) -> Optional[PoseData]:
		if index < 0 or index >= len(self.poses):
			return None
		return self.poses[index]

	def add_pose(self, name:str = None) -> PoseData:
		pose = self.poses.add()
		if name:
			pose.name = name

		return pose

	def remove_pose_by_index(self, index):
		entries = self.poses
		if not 0 <= index < len(entries):
			return
		active = self.active_pose_index
		entries[index].remove_action()
		entries.remove(index)
		preferred = active - (active >= index)
		self.active_pose_index = max(0, min(preferred, len(entries) - 1))

	def remove_pose(self, pose: PoseData):
		index = self.poses.find(pose.name)
		if index >= 0:
			self.remove_pose_by_index(index)
		return

	def sort_poses(self, sort_by:str = 'NAME', reverse:bool = False):
		# CollectionProperty doesn't have sort method, so we need to sort manually
		# by using move(from_idx,to_idx) method

		active_pose_name = self.get_active_pose().name if self.get_active_pose() else None

		if sort_by == 'NAME':
			new_order = sorted(self.poses, key=lambda x: x.name, reverse=reverse)
		elif sort_by == 'CATEGORY':
			cat_order = {cat[0]: i for i, cat in enumerate(POSE_CATEGORIES[1:])}
			new_order = sorted(self.poses, key=lambda x: cat_order.get(x.category, 99), reverse=reverse)
			# for pose in new_order: # Debug
			# 	print(pose.category, pose.name)
		else:
			pass  # Console-silent bundled-tool diagnostic.
			return

		# Move items to new order
		name_idx = {pose.name: i for i, pose in enumerate(new_order)}
		for name, new_idx in name_idx.items():
			cur_idx = self.poses.find(name)
			self.poses.move(cur_idx, new_idx)

		# Restore active pose
		if active_pose_name:
			active_pose = self.get_pose_by_name(active_pose_name)
			if active_pose:
				self.active_pose_index = self.poses.find(active_pose.name)
			else:
				self.active_pose_index = 0
		else:
			self.active_pose_index = 0

		return


	# Copy entire data from another PoseBook
	def copy_from(self, src: "PoseBook"):
		source = src
		if source == self:
			return
		self.poses.clear()
		for entry in source.poses:
			self.add_pose(entry.name).copy_from(entry)
		for field in ("active_pose_index", "category_filter", "show_alt_pose_names"):
			setattr(self, field, getattr(source, field))

	# Apply single pose
	def apply_single_pose(self, pose: PoseData, influence: float = 1.0):
		for p in self.poses:
			p: PoseData
			if p == pose:
				p.apply_pose(influence)
			else:
				p.reset_pose()
		# A pose already at 1.0 fires no value update; rebuild so Apply always restores it.
		update_combined_pose(self)
		return

	# Applly entire book
	def apply_poses(self, reset_current_pose: bool = True):
		if reset_current_pose:
			arm = get_armature_from_id(self)
			armature_reset_pose(arm)
		update_combined_pose(self)
		return

	# Reset entire book
	def reset_poses(self):
		for pose in self.poses:
			pose: PoseData
			pose.reset_pose()
		return



# Root PoseLib Container
class PoselibData(PropertyGroup):
	books: CollectionProperty(
		type = PoseBook,
		override = {'LIBRARY_OVERRIDABLE', 'USE_INSERTION'},
	) # PoseBooks

	# callback for active book index change
	def on_update_active_book_index(self, context):
		prefs = _get_integrated_preferences(__package__, SPL_Preferences)
		if not prefs.activate_poses_on_book_change:
			return

		# apply new book
		book = self.get_active_book()
		if book:
			book.apply_poses( reset_current_pose = False )

	active_book_index: IntProperty(
		override = {'LIBRARY_OVERRIDABLE'},
		update = on_update_active_book_index,
	)

	# controller name generator
	def make_controller_name(self) -> str:
		arm = self.get_armature()
		return arm.name + "_SPL_Controller"

	# callback for enable_animation change
	def on_enable_animation_update(self, context):
		if self.enable_animation:
			# reset pose
			armature_reset_pose(self.get_armature())

			# create actions for all poses (and this will constrain pose bones using the actions)
			self.ensure_actions()

		else: # animation disabled
			# remove all actions (and this will remove constraints from pose bones)
			self.purge_actions()
			# restore combined pose
			update_combined_pose(self.get_active_book())

		return

	enable_animation: BoolProperty(
		name="Enable Animation",
		description= "Make this Poselib animatable/keyable. Pose editing will be disabled in this mode. Armature bones will be constrained by Actions",
		default=False,
		update=on_enable_animation_update,
		override={'LIBRARY_OVERRIDABLE'},
	)

	########################################################################################
	# Basic Operations

	# Get Armature Object
	def get_armature(self) -> Optional[bpy.types.Object]:
		return get_armature_from_id(self)

	# add a new book
	def add_book(self, name: str = None) -> PoseBook:
		library = self.books
		assigned_name = name or "New Book"
		if not library:
			skeleton = self.get_armature()
			if skeleton is not None:
				backup_key = "spl_bone_name_backup"
				for source_bone in skeleton.data.bones:
					source_bone[backup_key] = source_bone.name
		created = library.add()
		created.name = assigned_name
		self.active_book_index = len(library) - 1
		return created

	# remove book by index
	def remove_book_by_index(self, index):
		library = self.books
		if not 0 <= index < len(library):
			return
		selected = self.active_book_index
		for entry in library[index].poses:
			entry.remove_action()
		library.remove(index)
		# Keep the same book selected when possible. Removing the selected book
		# moves to its predecessor, or the first remaining book at the start.
		position = selected - (index <= selected)
		self.active_book_index = max(0, min(position, len(library) - 1))

	# remove active book
	def remove_active_book(self):
		if self.active_book_index < 0 or self.active_book_index >= len(self.books):
			return
		self.remove_book_by_index(self.active_book_index)

	# remove book
	def remove_book(self, book: PoseBook):
		index = self.books.find(book.name)

		if index >= 0:
			self.remove_book_by_index(index)

	# get active book
	def get_active_book(self) -> Optional[PoseBook]:
		if self.active_book_index < 0 or self.active_book_index >= len(self.books):
			return None
		return self.books[self.active_book_index]

	# get book by name
	def get_book_by_name(self, name) -> Optional[PoseBook]:
		for book in self.books:
			if book.name == name:
				return book
		return None


	# Copy entire data from another PoselibData
	def copy_from(self, src: "PoselibData"):
		self.books.clear()
		for book in src.books:
			new_book = self.add_book(book.name)
			new_book.copy_from(book)

		self.active_book_index = src.active_book_index

	# Ensure the armature has proper actions
	def ensure_actions(self):
		#t = time.perf_counter()

		if self.enable_animation == False:
			return

		# Create actions for each pose
		book: PoseBook = self.get_active_book()
		pose: PoseData
		for book in self.books:
			for pose in book.poses:
				pose.ensure_action()

		# in milli seconds
		#print("Ensure Actions Time: ", (time.perf_counter() - t) * 1000, "ms")
		return

	def purge_actions(self):
		arm = self.get_armature()
		if not arm:
			return

		for book in self.books:
			for pose in book.poses:
				pose.remove_action()
		return


###################################################
# Helpers for user of this module
###################################################

__PROXY_SUFFIX = "_SPL_Proxy"
__PROXY_IDENTIFIER = "is_spl_proxy"
__PROXY_OWNER = "spl_proxy_owner"

# Get proxy object for a linked armature
def get_proxy_obj(arm: bpy.types.Armature) -> Optional[bpy.types.Object]:
	proxy_name = arm.name + __PROXY_SUFFIX
	proxy = bpy.data.objects.get(proxy_name)
	if proxy and proxy.get(__PROXY_IDENTIFIER) and proxy.get(__PROXY_OWNER):
		return proxy

	return None

# get or create a proxy object for a linked armature
def ensure_proxy_obj(arm):
    """Keep the current linked-file policy: do not create proxy scene objects."""
    return None


# Get Root PropertyGroup from Context
def get_poselib_from_context( context: bpy.types.Context ) -> Optional[PoselibData]:
	obj = context.object
	if not obj:
		return None

	return get_poselib(obj)

# Get Root PropertyGroup from Object
def get_poselib(obj) -> Optional[PoselibData]:
    if obj is None:
        return None
    rig = obj if obj.type == "ARMATURE" else obj.find_armature()
    if rig is None:
        return None
    if rig.library is not None or rig.override_library is not None:
        owner = get_proxy_obj(rig)
        if owner is not None:
            return owner.sakura_poselib
    return rig.sakura_poselib


###################################################
# Register & Unregister (called from __init__.py)
###################################################

classes = (
	BoneTransform,
	PoseData,
	PoseBook,
	PoselibData,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Object.sakura_poselib = PointerProperty(type=PoselibData)

def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)
	del bpy.types.Object.sakura_poselib
