# SPDX-License-Identifier: GPL-3.0-or-later
"""Load package-provided locale dictionaries into Blender."""

import csv
from pathlib import Path

import bpy

_LANGUAGE_ROOT = Path(__file__).with_name("language")
_SEPARATOR = {".tsv": "\t", ".csv": ","}
_MAX_INPUT_BYTES = 2 * 1024 * 1024
_MAX_ROWS = 20_000
_TRANSLATION_OWNER = None
_trans_table = {}


def _load_translation_table():
    translations = {}
    scanned = 0
    if not _LANGUAGE_ROOT.is_dir():
        return translations
    for locale in sorted(_LANGUAGE_ROOT.iterdir()):
        if not locale.is_dir():
            continue
        phrases = {}
        for catalog in sorted(locale.iterdir()):
            separator = _SEPARATOR.get(catalog.suffix.lower())
            if not separator or not catalog.is_file():
                continue
            try:
                if catalog.stat().st_size > _MAX_INPUT_BYTES:
                    continue
                with catalog.open(encoding="utf-8-sig", newline="") as file:
                    entries = csv.reader(file, delimiter=separator)
                    next(entries, None)  # skip column headings
                    for fields in entries:
                        scanned += 1
                        if scanned > _MAX_ROWS:
                            return translations
                        if len(fields) < 3:
                            continue
                        context, original, localized = (part.strip() for part in fields[:3])
                        if original and localized:
                            valid_context = {"": "*", "O": "Operator"}.get(context, context)
                            phrases[valid_context, original] = localized
            except (OSError, UnicodeError, csv.Error):
                continue
        if phrases:
            translations[locale.name] = phrases
    return translations


def register():
    global _TRANSLATION_OWNER, _trans_table
    if _TRANSLATION_OWNER is not None:
        return True
    table = _load_translation_table()
    if not table:
        return True
    domain = f"{__name__}.g{id(register):x}"
    try:
        if bpy.app.translations.register(domain, table) is False:
            return False
    except (RuntimeError, ValueError):
        return False
    _TRANSLATION_OWNER, _trans_table = domain, table
    return True


def unregister():
    global _TRANSLATION_OWNER, _trans_table
    if _TRANSLATION_OWNER is not None:
        try:
            bpy.app.translations.unregister(_TRANSLATION_OWNER)
        except (RuntimeError, ValueError):
            return False
        _TRANSLATION_OWNER, _trans_table = None, {}
    return True
