# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Pose transforms and MMD-oriented rotations using public mathutils APIs."""

import math
from typing import Tuple

import bpy
from mathutils import Euler, Quaternion, Vector


_EULER_ORDERS = frozenset(("XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"))


def is_pose_bone_visible(pbone: bpy.types.PoseBone) -> bool:
    bone = pbone.bone
    if bool(getattr(bone, "hide", False)) or bool(getattr(bone, "hide_select", False)):
        return False
    if bool(getattr(pbone, "hide", False)):
        return False
    memberships = tuple(getattr(bone, "collections", ()) or ())
    if memberships:
        return any(bool(getattr(group, "is_visible_effectively", getattr(group, "is_visible", True)))
                   for group in memberships)
    # Layers are only relevant to pre-4.0 files.
    if bpy.app.version < (4, 0, 0):
        flags = getattr(bone, "layers", None)
        shown = getattr(pbone.id_data.data, "layers", None)
        if flags is not None and shown is not None:
            return any(a and b for a, b in zip(flags, shown))
    return True


def get_pose_bone_rotation_quaternion(pbone: bpy.types.PoseBone) -> Quaternion:
    method = pbone.rotation_mode
    if method == "QUATERNION":
        return pbone.rotation_quaternion
    if method == "AXIS_ANGLE":
        values = pbone.rotation_axis_angle
        return Quaternion(Vector((values[1], values[2], values[3])), values[0])
    if method in _EULER_ORDERS:
        return pbone.rotation_euler.to_quaternion()
    return Quaternion()


def is_vector_almost_equal(v1, v2, threshold=1e-6):
    first, second = tuple(v1), tuple(v2)
    return len(first) == len(second) and all(
        abs(a - b) < threshold for a, b in zip(first, second)
    )


def is_matrix_almost_equal(m1, m2, threshold=1e-6):
    rows1, rows2 = tuple(m1), tuple(m2)
    if len(rows1) != len(rows2):
        return False
    return all(is_vector_almost_equal(a, b, threshold) for a, b in zip(rows1, rows2))


def has_rotation(q, threshold=1e-6):
    """Compare orientation with identity, treating both q and -q as identity."""
    norm = math.sqrt(sum(float(v) * float(v) for v in q))
    if norm < 1e-12:
        return False
    cosine_half = min(1.0, abs(float(q[0]) / norm))
    return 2.0 * math.acos(cosine_half) > threshold


def has_translation(v, threshold=1e-6):
    return any(abs(value) > threshold for value in v)


def has_scale(v, threshold=1e-6):
    return any(abs(value - 1.0) > threshold for value in v)


def has_transform(loc, rot, scale, threshold=1e-6):
    return (has_translation(loc, threshold)
            or has_rotation(rot, threshold)
            or has_scale(scale, threshold))


def to_armature_space(loc: Vector, rot: Quaternion, sca: Vector, pbone: bpy.types.PoseBone, invert: bool = False) -> Tuple[Vector, Quaternion, Vector]:
    if pbone is None:
        return (loc, rot, sca)
    orientation = pbone.bone.matrix_local.to_3x3()
    if invert:
        orientation = orientation.inverted()
    displacement = orientation @ Vector(loc)
    axis = -(orientation @ rot.axis)
    rotation = Quaternion(axis, rot.angle).normalized()
    deviation = Vector(sca) - Vector((1.0, 1.0, 1.0))
    stretch = Vector((1.0, 1.0, 1.0)) + (orientation @ deviation)
    return displacement, rotation, stretch


def quaternion_to_degrees(q: Quaternion, order: str = "XYZ") -> Vector:
    values = q.to_euler(order)
    return Vector(tuple(math.degrees(angle) % 360.0 for angle in values))


def degrees_to_quaternion(rot_deg: Vector, order: str = "XYZ") -> Quaternion:
    return Euler(tuple(math.radians(v) for v in rot_deg), order).to_quaternion().normalized()


def quat_to_euler_mmd(q: Tuple[float, float, float, float], degrees: bool = False) -> Tuple[float, float, float]:
    """Extract X, Y, Z angles inverse to euler_to_quat_mmd (Rx @ Ry @ Rz).

    R[0,2] = sin(Y), R[1,2] = -sin(X)cos(Y),
    R[0,1] = -cos(Y)sin(Z). At Y=+/-90 degrees, only a combined
    X/Z angle is observable: choose the canonical Z=0 solution.
    """
    rotation = Quaternion(q).normalized().to_matrix()
    sine_y = max(-1.0, min(1.0, rotation[0][2]))
    yaw = math.asin(sine_y)
    if abs(abs(sine_y) - 1.0) < 1e-10:
        pitch = math.atan2(
            (1.0 if sine_y >= 0.0 else -1.0) * rotation[1][0],
            rotation[1][1],
        )
        roll = 0.0
    else:
        pitch = math.atan2(-rotation[1][2], rotation[2][2])
        roll = math.atan2(-rotation[0][1], rotation[0][0])
    values = (pitch, yaw, roll)
    return tuple(math.degrees(angle) for angle in values) if degrees else values


def _normalize(q: Tuple[float, float, float, float]) -> Tuple[float, float, float, float]:
    length = math.sqrt(sum(v * v for v in q))
    return tuple(v / length for v in q) if length else tuple(q)


def euler_to_quat_mmd(euler: Tuple[float, float, float], *, degrees: bool = False) -> Tuple[float, float, float, float]:
    """Compose three public mathutils axis-angle rotations in X, Y, Z order."""
    angles = tuple(math.radians(v) for v in euler) if degrees else tuple(euler)
    rx = Quaternion((1.0, 0.0, 0.0), angles[0])
    ry = Quaternion((0.0, 1.0, 0.0), angles[1])
    rz = Quaternion((0.0, 0.0, 1.0), angles[2])
    return (rx @ ry @ rz).normalized()


def swap_axis(v: Vector, axis: Tuple[int, int, int]) -> Vector:
    permutation = tuple(axis)
    if len(permutation) != 3 or not all(isinstance(i, int) for i in permutation):
        raise ValueError("Axis must be a tuple of three integers")
    if sorted(permutation) != [0, 1, 2]:
        raise ValueError("Axis indices must be a permutation of 0, 1, 2")
    return Vector(tuple(v[i] for i in permutation))
