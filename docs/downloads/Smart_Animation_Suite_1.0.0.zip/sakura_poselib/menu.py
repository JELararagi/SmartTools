# SPDX-License-Identifier: GPL-3.0-or-later
"""Map the PoseLib shortcuts to pose capture and replacement."""
import bpy

from .spl import get_poselib_from_context


def _book(context):
    library = get_poselib_from_context(context)
    return library.get_active_book() if library is not None else None


def _replace_action(layout, text, index):
    command = layout.operator("spl.replace_pose", text=text, translate=False)
    command.pose_index = index


class SPL_MT_PoseMenu(bpy.types.Menu):
    bl_idname = "SPL_MT_PoseMenu"
    bl_label = "Sakura Poselib"

    def draw(self, context):
        self.layout.operator("spl.add_pose", text="Add Pose")
        book = _book(context)
        if book is not None:
            pose = book.get_active_pose()
            if pose is not None:
                replace = bpy.app.translations.pgettext("Replace")
                _replace_action(self.layout, f"{replace} {pose.name}", -1)
            if len(book.poses):
                self.layout.menu(SPL_MT_ReplacePoseMenu.bl_idname, text="Replace...")


class SPL_MT_ReplacePoseMenu(bpy.types.Menu):
    bl_idname = "SPL_MT_ReplacePoseMenu"
    bl_label = "Replace Pose"

    def draw(self, context):
        book = _book(context)
        if book is not None:
            for index, pose in enumerate(book.poses):
                _replace_action(self.layout, pose.name, index)


_classes = (SPL_MT_PoseMenu, SPL_MT_ReplacePoseMenu)


def register():
    registered = []
    try:
        for menu in _classes:
            bpy.utils.register_class(menu)
            registered.append(menu)
    except Exception:
        for menu in reversed(registered):
            bpy.utils.unregister_class(menu)
        raise


def unregister():
    for menu in reversed(_classes):
        bpy.utils.unregister_class(menu)
