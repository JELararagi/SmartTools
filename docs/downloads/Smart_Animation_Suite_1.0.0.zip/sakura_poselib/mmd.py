# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""MMD pose interoperability using VPD fields and public Blender APIs.

This module does not bundle, import, or reproduce mmd_tools source code.
VPD numeric quaternion components are stored in X, Y, Z, W order.
"""

import math
import re
from pathlib import Path
from typing import Tuple

import bpy
from mathutils import Matrix, Quaternion, Vector


_POSE_SIGNATURE = "Vocaloid Pose Data file"
_RECORD = re.compile(r"^(Bone|Morph)([0-9]+)\s*\{(.*)$")


class InvalidFileError(Exception):
    """A VPD document is incomplete, malformed, or inconsistent."""


def is_mmd_tools_installed():
    """Check enabled addons, without depending on the optional addon itself."""
    preferences = getattr(getattr(bpy, "context", None), "preferences", None)
    addon_registry = getattr(preferences, "addons", ())
    for entry in addon_registry.keys() if hasattr(addon_registry, "keys") else ():
        parts = str(entry).split(".")
        if entry == "mmd_tools" or (
            len(parts) == 3 and parts[0] == "bl_ext" and parts[-1] == "mmd_tools"
        ):
            return True
    return False


def get_model_root(obj: bpy.types.Object) -> bpy.types.Object:
    """Find the MMD ROOT ancestor, only when its integration is enabled."""
    if not is_mmd_tools_installed():
        return None
    ancestor = obj
    visited = set()
    while ancestor is not None:
        address = id(ancestor)
        if address in visited:
            break
        visited.add(address)
        if getattr(ancestor, "mmd_type", None) == "ROOT":
            return ancestor
        ancestor = getattr(ancestor, "parent", None)
    return None


def get_mmd_bone_name_j_e(bone) -> Tuple[str, str]:
    """Return Japanese and English MMD names, falling back to Blender name."""
    if bone is None:
        raise ValueError("bone is None")
    default_name = bone.name
    metadata = getattr(bone, "mmd_bone", None) if is_mmd_tools_installed() else None
    japanese = getattr(metadata, "name_j", None) or default_name
    english = getattr(metadata, "name_e", None) or default_name
    return japanese, english


def get_pose_bone_by_mmd_name(armature, name):
    if armature is None or getattr(armature, "type", None) != "ARMATURE":
        raise ValueError("armature is None or not an armature")
    bones = armature.pose.bones
    found = bones.get(name) if hasattr(bones, "get") else None
    if found is not None:
        return found
    if not is_mmd_tools_installed():
        return None
    return next((bone for bone in bones if name in get_mmd_bone_name_j_e(bone)), None)


class BoneConverter:
    """Transform a bone-local displacement into an MMD-axis displacement.

    MMD and Blender differ in local Y/Z orientation. The reflection and bone
    rest-basis change are expressed as a product of documented Matrix values.
    """

    def __init__(self, pose_bone, scale, invert=False):
        rest_orientation = pose_bone.bone.matrix_local.to_3x3()
        yz_reflection = Matrix(((1.0, 0.0, 0.0),
                                (0.0, 0.0, 1.0),
                                (0.0, 1.0, 0.0)))
        conversion = rest_orientation.transposed() @ yz_reflection
        self.__mat = conversion.inverted() if invert else conversion
        self.__scale = float(scale)

    def convert_location(self, location: Vector):
        return (self.__mat @ Vector(location)) * self.__scale

    def convert_rotation(self, rot: Quaternion):
        axis_in_target_space = -(self.__mat @ rot.axis)
        return Quaternion(axis_in_target_space, rot.angle).normalized()


class VpdBone:
    """One VPD bone: XYZ translation and XYZW quaternion components."""

    def __init__(self, bone_name, location, rotation):
        self.bone_name = str(bone_name)
        self.location = list(location)
        components = list(rotation)
        self.rotation = components if any(components) else [0.0, 0.0, 0.0, 1.0]

    def __repr__(self):
        return f"<VpdBone {self.bone_name!r}, loc {self.location!r}, rot {self.rotation!r}>"


class VpdMorph:
    def __init__(self, morph_name, weight):
        self.morph_name = str(morph_name)
        self.weight = float(weight)

    def __repr__(self):
        return f"<VpdMorph {self.morph_name!r}, weight {self.weight!r}>"


class VpdFile:
    """Single-pose Shift_JIS VPD reader and writer (bones plus optional morphs)."""

    def __init__(self):
        self.filepath = ""
        self.osm_name = None
        self.bones = []
        self.morphs = []

    def __repr__(self):
        return (f"<File {self.filepath!r}, osm {self.osm_name!r}, "
                f"bones {len(self.bones)}, morphs {len(self.morphs)}>")

    def load(self, **args):
        filepath = args["filepath"]
        lines = Path(filepath).read_bytes().decode("shift_jis", errors="replace").splitlines()
        if not lines or not lines[0].startswith(_POSE_SIGNATURE):
            raise InvalidFileError("Invalid Vocaloid pose signature")
        if len(lines) < 4:
            raise InvalidFileError("Missing VPD model name or bone count")
        parent = _pose_header_field(lines[2])
        try:
            declared = int(_pose_header_field(lines[3]))
        except ValueError as exc:
            raise InvalidFileError("VPD bone count must be an integer") from exc
        if declared < 0:
            raise InvalidFileError("VPD bone count cannot be negative")

        bones = []
        morphs = []
        for record in _pose_records(lines[4:]):
            if isinstance(record, VpdBone):
                bones.append(record)
            else:
                morphs.append(record)
        if len(bones) != declared:
            raise InvalidFileError("VPD bone count does not match records")

        # Commit only after validation, keeping any previous pose on failure.
        self.filepath = str(filepath)
        self.osm_name = parent
        self.bones = bones
        self.morphs = morphs
        return None

    def save(self, **args):
        filepath = args.get("filepath", self.filepath)
        if not filepath:
            raise ValueError("VPD output filepath is empty")
        model = self.osm_name if self.osm_name is not None else ""
        output = [_POSE_SIGNATURE, "", f"{model}; // parent model",
                  f"{len(self.bones)}; // bone count", ""]
        for index, bone in enumerate(self.bones):
            xyz = _numeric_sequence(bone.location, 3)
            xyzw = _numeric_sequence(bone.rotation, 4)
            output.extend((f"Bone{index}{{{bone.bone_name}",
                           "  " + ",".join(f"{value:.6f}" for value in xyz) + "; // trans x,y,z",
                           "  " + ",".join(f"{value:.6f}" for value in xyzw) + "; // Quaternion x,y,z,w",
                           "}", ""))
        for index, morph in enumerate(self.morphs):
            value = _numeric_sequence((morph.weight,), 1)[0]
            output.extend((f"Morph{index}{{{morph.morph_name}",
                           f"  {value:.6f}; // weight", "}", ""))
        encoded = ("\r\n".join(output) + "\r\n").encode("shift_jis", errors="replace")
        Path(filepath).write_bytes(encoded)
        self.filepath = str(filepath)
        return None


def _pose_header_field(row):
    """Remove a VPD trailing semicolon/comment from a scalar line."""
    return row.split(";", 1)[0].strip()


def _numeric_sequence(values, expected):
    try:
        numbers = [float(part) for part in values]
    except (TypeError, ValueError) as exc:
        raise InvalidFileError("VPD field contains a nonnumeric value") from exc
    if len(numbers) != expected or not all(math.isfinite(v) for v in numbers):
        raise InvalidFileError(f"VPD field needs {expected} finite values")
    return numbers


def _reading_vector(row, width):
    return _numeric_sequence(_pose_header_field(row).split(","), width)


def _pose_records(lines):
    """Read sequential Bone/Morph blocks; fail on truncation or bad delimiters."""
    rows = iter(lines)
    for row in rows:
        stripped = row.strip()
        if not stripped or stripped.startswith("//"):
            continue
        match = _RECORD.fullmatch(stripped)
        if match is None:
            raise InvalidFileError("Invalid VPD Bone/Morph header")
        category, _, label = match.groups()
        try:
            if category == "Bone":
                position = _reading_vector(next(rows), 3)
                quaternion = _reading_vector(next(rows), 4)
                entry = VpdBone(label.strip(), position, quaternion)
            else:
                value = _reading_vector(next(rows), 1)[0]
                entry = VpdMorph(label.strip(), value)
            closing = next(rows).strip()
        except StopIteration as exc:
            raise InvalidFileError("Truncated VPD record") from exc
        if not closing.startswith("}"):
            raise InvalidFileError("VPD record is missing its closing brace")
        yield entry
