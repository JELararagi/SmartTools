# Description: Internal functions for Sakura Poselib

import bpy
import math
import os

from mathutils import Vector, Quaternion, Euler, Matrix

from . import mmd, utils
from . import spl
from ..action_compat import get_action_channelbag, iter_action_fcurves, ensure_action_fcurve, assign_action_to_datablock


def _restore_original_action_binding(datablock, orig_action, orig_slot=None):
	anim_data = getattr(datablock, "animation_data", None)
	if anim_data is None:
		return
	anim_data.action = orig_action
	try:
		anim_data.action_slot = orig_slot
	except Exception:
		pass


# Extract pose data from pose library, returns list of poses
def marker_library_for(rig, preferred=""):
    """Use explicitly selected marker actions, then a compatible rig assignment."""
    if preferred:
        return bpy.data.actions.get(preferred)
    legacy = getattr(rig, "pose_library", None)
    if isinstance(legacy, bpy.types.Action):
        return legacy
    animation = rig.animation_data
    current = animation.action if animation is not None else None
    if current is not None and current.pose_markers:
        return current
    return None


def _pose_marker_curves(action, rig):
    slots = list(getattr(action, "slots", ()))
    active = rig.animation_data
    if len(slots) > 1 and (active is None or active.action != action or active.action_slot is None):
        raise ValueError("choose_rig_slot")
    if len(slots) > 1:
        bag = get_action_channelbag(action, datablock=rig)
        return [] if bag is None else bag.fcurves
    return iter_action_fcurves(action, datablock=rig)


def extract_pose_library_data(armature, action=None):
    action = action or marker_library_for(armature)
    if action is None or not action.pose_markers:
        return []

    properties = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")
    selected_frames = {marker.frame for marker in action.pose_markers}
    names = {bone.path_from_id(): bone.name for bone in armature.pose.bones}
    by_frame = {frame: {} for frame in selected_frames}
    for curve in _pose_marker_curves(action, armature):
        path, _, field = curve.data_path.rpartition(".")
        if field not in properties or path not in names:
            continue
        axis = curve.array_index
        limit = 4 if field in {"rotation_quaternion", "rotation_axis_angle"} else 3
        if not 0 <= axis < limit:
            continue
        name = names[path]
        for point in curve.keyframe_points:
            frame, value = point.co
            if frame in selected_frames:
                channels = by_frame[frame].setdefault(name, {}).setdefault(field, {})
                channels[axis] = value
    return [(marker.name, by_frame[marker.frame]) for marker in action.pose_markers]


def _pose_samples(armature, action):
    def values(channels, field, defaults):
        data = channels.get(field, {})
        return tuple(data.get(index, value) for index, value in enumerate(defaults))

    def row(channels):
        rotation = [
            Quaternion(values(channels, "rotation_quaternion", (1, 0, 0, 0))).normalized(),
            Euler(values(channels, "rotation_euler", (0, 0, 0))).to_quaternion(),
        ]
        if "rotation_axis_angle" in channels:
            angle, x, y, z = values(channels, "rotation_axis_angle", (0, 0, 0, 1))
            if x or y or z:
                rotation.append(Quaternion((x, y, z), angle))
        orientation = min(rotation, key=lambda q: abs(q.w))
        return (values(channels, "location", (0, 0, 0)), orientation, values(channels, "scale", (1, 1, 1)))

    return [(name, {bone: row(channels) for bone, channels in data.items()})
            for name, data in extract_pose_library_data(armature, action) if data]


def convert_from_poselib(book, remove_poselib=False, *, action=None, samples=None):
    rig = spl.get_armature_from_id(book)
    action = action or marker_library_for(rig)
    if action is None:
        return False
    samples = _pose_samples(rig, action) if samples is None else samples
    if not samples:
        return False

    book.reset_poses()
    for previous in book.poses:
        previous.remove_action()
    book.poses.clear()
    for title, records in samples:
        pose = book.add_pose(title)
        for name, (location, rotation, scale) in records.items():
            entry = pose.add_bone(name)
            entry.location, entry.rotation, entry.scale = location, rotation, scale
    book.active_pose_index = 0
    book.name = action.name
    if remove_poselib and action.library is None and action.users == 0:
        bpy.data.actions.remove(action)
    return True


def convert_to_poselib(book):
    rig = spl.get_armature_from_id(book)
    poses = [(pose.name, [(record, rig.pose.bones.get(record.name)) for record in pose.bones])
             for pose in book.poses]
    if not any(target is not None for _, records in poses for _, target in records):
        raise ValueError("no_pose_data")
    action = bpy.data.actions.new(f"{book.name or rig.name}_pose_library")
    animation = rig.animation_data
    original_action = animation.action if animation is not None else None
    original_slot = animation.action_slot if animation is not None else None
    try:
        try:
            assign_action_to_datablock(rig, action, name_hint=rig.name)
            for frame, (name, records) in enumerate(poses, start=1):
                marker = action.pose_markers.new(name)
                marker.frame = frame
                for record, target in records:
                    if target is None:
                        continue
                    for output_field, stored_field in (("location", "location"), ("rotation_quaternion", "rotation"), ("scale", "scale")):
                        path = target.path_from_id(output_field)
                        for index, value in enumerate(getattr(record, stored_field)):
                            curve = ensure_action_fcurve(action, rig, path, index=index, group_name=record.name)
                            if curve is None:
                                raise RuntimeError("write_curve")
                            curve.keyframe_points.insert(frame, value)
        finally:
            if animation is None:
                rig.animation_data_clear()
            else:
                _restore_original_action_binding(rig, original_action, original_slot)
    except BaseException:
        bpy.data.actions.remove(action)
        raise
    action.use_fake_user = True
    if hasattr(rig, "pose_library"):
        rig.pose_library = action
    return action


# Load from mmd_tools' bone morph
def load_poses_from_mmdtools( book: spl.PoseBook ):
	armature = book.id_data
	root = mmd.get_model_root( armature )
	if not root:
		return

	bone_morphs = root.mmd_root.bone_morphs
	if not bone_morphs:
		return

	book.poses.clear()

	# Read bone morphs and convert to Sakura Poselib' pose
	for morph in bone_morphs:
		pose: spl.PoseData = book.poses.add()
		pose.name = morph.name
		for bone_data in morph.data:
			bd = pose.bones.add()
			bd.name = bone_data.bone
			bd.location = bone_data.location
			bd.rotation = bone_data.rotation

	return


# Convert to MMD Tools' Bone Morph
def convert_poses_to_mmdtools( book: spl.PoseBook, use_alt_pose_names=False, clear_exsisting=False ):
	armature = book.id_data
	root = mmd.get_model_root( armature )
	if not root:
		return False

	poses = book.poses
	bone_morphs = root.mmd_root.bone_morphs

	if clear_exsisting:
		bone_morphs.clear()

	for pose in poses:
		pose_name = pose.name_alt if use_alt_pose_names and pose.name_alt else pose.name

		# find by name
		morph = bone_morphs.get( pose_name )
		if not morph:
			morph = bone_morphs.add()
			morph.name = pose_name
			morph.category = pose.category if pose.category in ('EYEBROW', 'EYE', 'MOUTH') else 'OTHER'

		# clear bone data
		morph.data.clear()
		for bone in pose.bones:
			md = morph.data.add()
			md.name = bone.name
			pbone = armature.pose.bones.get( bone.name )
			if pbone:
				bone_id = pbone.mmd_bone.bone_id
				if bone_id < 0:
					# create bone id for mmd_tools
					# bone id is max( bone_id within armature ) + 1
					bone_id = max( [b.mmd_bone.bone_id for b in armature.pose.bones] ) + 1
					pbone.mmd_bone.bone_id = bone_id

				md.bone_id = pbone.mmd_bone.bone_id # finally we have bone_id
			md.location = bone.location
			md.rotation = bone.rotation
	return


# Helper: Guess pose category from pose name
EYEBROW = {'eyebrow', 'eyebrows', 'brow', 'brows', 'mayu'}
EYE = {'eye', 'eyes', 'eyelid', 'eyelids', 'iris', 'pupil', 'pupils', 'me' }
MOUTH = {'mouth', 'lips', 'lip', 'kuchibiru', 'kuchi'}

import re

def guess_pose_category(name):
    tokens = set(name.lower().translate(str.maketrans(" ._/", "    ")).split(" "))
    return next(
        (label for label, words in (("EYEBROW", EYEBROW), ("EYE", EYE), ("MOUTH", MOUTH))
         if not tokens.isdisjoint(words)),
        "OTHER",
    )


# Json format
import json
# Save PoseBook into a file (JSON)
def save_book_to_json(book, filepath, use_armature_space=False):
    channels = book.get_armature().pose.bones if use_armature_space else None
    document = [
        dict(
            name=pose.name, name_alt=pose.name_alt, category=pose.category,
            space="ARMATURE" if use_armature_space else "LOCAL",
            bones=[_write_bone(entry, channels) for entry in pose.bones],
        )
        for pose in book.poses
    ]
    Path(filepath).write_text(json.dumps(document, indent=2), encoding="utf-8")


# Load PoseBook from a file (JSON)
def load_book_from_json(book, filepath, prepared=None):
    name, records, missing = (
        prepare_book_import(filepath, book.get_armature()) if prepared is None else prepared
    )
    book.poses.clear()
    for title, alternate, category, bones in records:
        pose = book.poses.add()
        pose.name, pose.name_alt, pose.category = title, alternate, category
        for name_of_bone, location, rotation, scale in bones:
            entry = pose.bones.add()
            entry.name, entry.location, entry.rotation, entry.scale = name_of_bone, location, rotation, scale
    book.name = name
    return missing


# CSV format
import csv

_POSE_CATEGORIES = [
	'NONE', 'EYEBROW', 'EYE', 'MOUTH', 'OTHER'
]


# Save PoseBook into a file (CSV)
def save_book_to_csv( book: spl.PoseBook, filename, scale=12.5, use_mmd_bone_names=True, use_alt_names=False ):
	poses = book.poses
	arm = book.get_armature()
	scale = scale * arm.matrix_world.to_scale()[0] # consider armature scale, only uniform scale is supported, using scale.x here

	converters = {b: mmd.BoneConverter(b, scale, invert=True) for b in arm.pose.bones}

	with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
		# write header
		header = ';PmxMorph,モーフ名,モーフ名(英),パネル(0:無効/1:眉(左下)/2:目(左上)/3:口(右上)/4:その他(右下)),モーフ種類(0:グループモーフ/1:頂点モーフ/2:ボーンモーフ/3:UV(Tex)モーフ/4:追加UV1モーフ/5:追加UV2モーフ/6:追加UV3モーフ/7:追加UV4モーフ/8:材質モーフ/9:フリップモーフ/10:インパルスモーフ)\n'
		csvfile.write(header)

		# write data
		for pose in poses:
			pose_name = pose.name_alt if use_alt_names and pose.name_alt else pose.name
			pose_name_alt = pose.name if use_alt_names and pose.name_alt else pose.name
			# Write a pose header
			# format: f"PmxMorph,{pose.name_j},{pose.name_e},{category_index},2(BoneMorph)"
			if pose.category not in _POSE_CATEGORIES:
				category_index = 4
			else:
				category_index = _POSE_CATEGORIES.index(pose.category)
			pose_header = f'PmxMorph,"{pose_name}","{pose_name_alt}",{category_index},2\n'
			csvfile.write(pose_header)

			# Write a bone list header
			# format: f";PmxBoneMorph,親モーフ名,オフセットIndex,ボーン名,移動量_x,移動量_y,移動量_z,回転量_x[deg],回転量_y[deg],回転量_z[deg]"
			bone_header = f';PmxBoneMorph,親モーフ名,オフセットIndex,ボーン名,移動量_x,移動量_y,移動量_z,回転量_x[deg],回転量_y[deg],回転量_z[deg]\n'
			csvfile.write(bone_header)

			# Write bone data
			for index, bone in enumerate(pose.bones):
				# Write a bone data
				# format: f"PmxBoneMorph,{pose.name},index,{bone.name},{loc.x},{loc.y},{loc.z},{rot.x},{rot.y},{rot.z}"

				pbone = arm.pose.bones.get(bone.name)
				if pbone is None:
					pass  # Console-silent bundled-tool diagnostic.
					continue

				if use_mmd_bone_names:
					bone_name_j, _ = mmd.get_mmd_bone_name_j_e(pbone)
				else:
					bone_name_j = pbone.name

				# Convet using mmd_tools' BoneConverter
				converter = converters[pbone]
				loc = converter.convert_location(bone.location)
				rot = converter.convert_rotation(bone.rotation)
				rot.x, rot.y, rot.z = utils.quat_to_euler_mmd(rot, degrees=True)

				# # convert to armature space
				# loc, rot, _  = utils.to_armature_space( bone.location, bone.rotation, bone.scale, pbone )
				# loc = loc * scale * arm.scale[0] # convert to MMD unit considering armature scale
				# rot = utils.quaternion_to_degrees( rot )

				# # Swap YZ axis for MMD
				# loc = utils.swap_axis( loc, (0, 2, 1) )
				# rot = utils.swap_axis( rot, (0, 2, 1) )

				bone_data = f'PmxBoneMorph,"{pose_name}",{index},"{bone_name_j}",{loc.x:.5g},{loc.y:.5g},{loc.z:.5g},{rot.x:.5g},{rot.y:.5g},{rot.z:.5g}\n'
				csvfile.write(bone_data)

		# Comment
		csvfile.write("\n;This file is generated by Sakura Poselib addon for Blender.\n")
	# end of with open()

	return


# Load PoseBook from a file (CSV)
def load_book_from_csv( book: spl.PoseBook, filename, scale=0.08 ):
	poses = book.poses
	arm = book.get_armature()
	scale = scale / arm.scale[0] # consider armature scale
	converters = {b: mmd.BoneConverter(b, scale) for b in arm.pose.bones}

	# Format:
	# line starts with ';' is comment. just discard.

	# Line starts with PMXMorh is a pose header
	#   PmxMorph,"{pose_name}","eng_name(discard)",category_index,4(BoneMorph)

	# Line starts with PmxBoneMorph is a bone data
	#   PmxBoneMorph,"{pose_name(which is this bone transform is belongs to)}",index(within the pose, sequential),"{bone_name}",loc_x,loc_y,loc_z,rot_x,rot_y,rot_z

	# loc is in MMD unit (1/12.5 of Blender unit)
	# rot is in degree (not radian)

	with open(filename, 'r', newline='', encoding='utf-8') as csvfile:
		reader = csv.reader(csvfile, delimiter=',', quotechar='"')

		for row in reader:
			if len(row) < 1:
				continue

			#print(f"row: {row}")
			# if the line is comment, discard
			if row[0].startswith(';'):
				continue

			def _add_pose(name, cat_index):
				pose = poses.get(name)
				if not pose:
					pose = poses.add()
					pose.name = name
				else: # warn if the pose is already exists
					pass  # Console-silent bundled-tool diagnostic.

				pose.category = _POSE_CATEGORIES[cat_index] if cat_index < len(_POSE_CATEGORIES) and cat_index >= 0 else 'OTHER'
				# if pose.category == 0:
				# 	pose.category = guess_pose_category(pose.name)
				return pose

			# if the line is PMXMorph header, create a new pose
			if row[0].startswith('PmxMorph'):
				pose_name = row[1].strip('"')
				pose_name_e = row[2].strip('"')
				cat_index = int(row[3])
				pose = _add_pose(pose_name, cat_index)
				pose.name_alt = pose_name_e
				continue

			# if the line is PmxBoneMorph, add a bone data to the pose indicated by the pose name
			if row[0].startswith('PmxBoneMorph'):
				pose_name = row[1].strip('"')
				index = int(row[2]) # TODO: use this to sort bones within pose (currently, it is not used)
				pose = poses.get(pose_name)

				if not pose: # warn if the pose is not found
					pose = _add_pose(pose_name, -1)
					pass  # Console-silent bundled-tool diagnostic.

				bone_name = row[3].strip('"')
				loc = Vector( (float(row[4]), float(row[5]), float(row[6])) )
				rot = Vector( (float(row[7]), float(row[8]), float(row[9])) )

				# convert to blender unit
				pbone = mmd.get_pose_bone_by_mmd_name(arm, bone_name)
				if pbone is None:
					pass  # Console-silent bundled-tool diagnostic.
					continue

				# # Convert using mmd_tools' BoneConverter
				converter = converters[pbone]
				loc = converter.convert_location(loc)
				rot = utils.euler_to_quat_mmd(rot, degrees=True) # convert to quaternion
				rot = converter.convert_rotation(rot)

				# Swap YZ axis for Blender
				# loc = utils.swap_axis( loc, (0, 2, 1) ) # still in MMD unit
				# rot = utils.swap_axis( rot, (0, 2, 1) )

				# # convert to Blender unit
				# loc = loc * scale / arm.scale[0] # convert to Blender unit (1/12.5 of MMD unit)
				# rot = utils.degrees_to_quaternion( rot )  # specify the order for conversion
				# # convert to bone local space
				# loc, rot, _ = utils.to_armature_space( loc, rot, Vector((1,1,1)), pbone, invert=True )

				bone = pose.bones.add()
				bone.name = pbone.name
				bone.location = loc
				bone.rotation = rot
				bone.scale = Vector((1.0,1.0,1.0)) # Not in MMD

				continue

		book.name = os.path.basename(filename)

	return


# Save a pose as VPD file
def export_pose_as_vpd( pose:spl.PoseData, filepath, scale=12.5 ):
	arm = pose.get_armature()

	vpd = mmd.VpdFile()

	for bone in pose.bones:
		bone: spl.BoneTransform

		pbone = arm.pose.bones.get(bone.name)
		if pbone is None:
			pass  # Console-silent bundled-tool diagnostic.
			continue

		converter = mmd.BoneConverter(pbone, scale, invert=True)
		loc = converter.convert_location(bone.location)
		rot = converter.convert_rotation(bone.rotation)
		rot = [rot.x, rot.y, rot.z, rot.w]

		bone_name, _ = mmd.get_mmd_bone_name_j_e(pbone)
		vpd.bones.append( mmd.VpdBone( bone_name, loc, rot ) )

	vpd.osm_name = arm.name
	vpd.save(filepath=filepath)
	return

# Load a pose from VPD file
def import_pose_from_vpd( pose:spl.PoseData, filepath, scale=12.5 ):
	arm = pose.get_armature()

	vpd = mmd.VpdFile()
	try:
		vpd.load(filepath=filepath)
	except mmd.InvalidFileError as e:
		pass  # Console-silent bundled-tool diagnostic.
		return None

	pose.bones.clear()

	for vpdbone in vpd.bones:
		vpdbone: mmd.VpdBone

		pbone = mmd.get_pose_bone_by_mmd_name(arm, vpdbone.bone_name)
		if pbone is None:
			pass  # Console-silent bundled-tool diagnostic.
			continue

		converter = mmd.BoneConverter(pbone, scale)
		loc = Vector(vpdbone.location)
		loc = converter.convert_location(loc)

		rot = vpdbone.rotation
		rot = Quaternion((rot[3], rot[0], rot[1], rot[2]))
		rot = converter.convert_rotation(rot)

		bd = pose.bones.add()
		bd.name = pbone.name
		bd.location = loc
		bd.rotation = rot
		bd.scale = Vector((1.0,1.0,1.0)) # Not in MMD

	pose.name = os.path.basename(filepath)
	return pose








from pathlib import Path

def _write_bone(entry, channels):
    location = Vector(entry.location)
    rotation = Quaternion(entry.rotation)
    scale = Vector(entry.scale)
    if channels is not None:
        location, rotation, scale = utils.to_armature_space(
            location, rotation, scale, channels.get(entry.name)
        )
    return dict(name=entry.name, location=tuple(location), rotation=tuple(rotation), scale=tuple(scale))

def _coordinates(value, length):
    if not isinstance(value, (list, tuple)) or len(value) != length:
        raise ValueError("Invalid pose transform dimensions")
    if any(type(part) not in (float, int) or not math.isfinite(part) for part in value):
        raise ValueError("Invalid pose transform value")
    return value

def prepare_book_import(filepath, armature):
    source = Path(filepath)
    document = json.loads(source.read_text(encoding="utf-8-sig"))
    if not isinstance(document, list):
        raise ValueError("A pose book must contain an array of poses")
    records = []
    missing = {}
    for pose in document:
        if not isinstance(pose, dict) or not isinstance(pose.get("bones"), list):
            raise ValueError("Invalid pose record")
        names = pose.get("name"), pose.get("name_alt")
        if not all(isinstance(field, str) for field in names):
            raise ValueError("Invalid pose name")
        category = pose.get("category", "OTHER")
        if category == "NONE":
            category = "OTHER"
        if category not in ("ALL", "EYEBROW", "EYE", "MOUTH", "OTHER"):
            raise ValueError("Invalid pose category")
        channels = armature.pose.bones
        in_armature_space = pose.get("space", "LOCAL") == "ARMATURE"
        collected = []
        for element in pose["bones"]:
            if not isinstance(element, dict) or not isinstance(element.get("name"), str):
                raise ValueError("Invalid pose bone")
            name = element["name"]
            position = Vector(_coordinates(element.get("location"), 3))
            rotation = Quaternion(_coordinates(element.get("rotation"), 4))
            scale = Vector(_coordinates(element.get("scale", (1, 1, 1)), 3))
            channel = channels.get(name)
            if channel is None:
                missing[name] = None
                if in_armature_space:
                    continue
            if in_armature_space:
                position, rotation, scale = utils.to_armature_space(position, rotation, scale, channel, invert=True)
            collected.append((name, position, rotation, scale))
        records.append((*names, category, collected))
    return source.stem, records, list(missing)
