"""Availability rules shared by the SmartAnimation pose controls."""
from functools import wraps

import bpy

from .spl import get_poselib_from_context


def _guard(func, available):
    @wraps(func)
    def evaluate(cls, context):
        if available(context):
            return func(cls, context)
        return False
    return evaluate


def _library_available(context):
    return get_poselib_from_context(context) is not None


def _can_edit(context):
    library = get_poselib_from_context(context)
    return library is not None and not library.enable_animation


def _selected_book(context):
    library = get_poselib_from_context(context)
    return library.get_active_book() if library is not None else None


def _selected_pose(context):
    book = _selected_book(context)
    return book is not None and book.get_active_pose() is not None


def _contains_poses(context):
    book = _selected_book(context)
    return book is not None and len(book.poses) > 0


def _native_pose_library_available(context):
    # The legacy import and export operators use Object.pose_library.
    return bpy.types.Object.bl_rna.properties.get("pose_library") is not None


def requires_active_armature(func):
    return _guard(func, _library_available)


def requires_animation_disabled(func):
    return _guard(func, _can_edit)


def requires_active_posebook(func):
    return _guard(func, _selected_book)


def requires_active_pose(func):
    return _guard(func, _selected_pose)


def requires_poses(func):
    return _guard(func, _contains_poses)


def requires_blender_pose_library(func):
    return _guard(func, _native_pose_library_available)
