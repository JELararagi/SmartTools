# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Permanent package-relative keys for the active Smart Animation icons."""

_NUMBERED = (f"n_{index:02}_icon" for index in range(1, 31))
_FEATURES = (f"sas_{name}" for name in (
    "locomotion", "motion", "precision", "recipe", "stage", "super", "visual",
))
ICON_RENAME_MAP = {
    f"icons/{name}.png": f"icons/{name}.png"
    for name in (*_NUMBERED, *_FEATURES)
}
