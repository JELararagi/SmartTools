# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

# Compatibility map for active PNG source names. Obsolete header/help/clock
# custom images are intentionally absent because they now use Blender built-ins.
ICON_RENAME_MAP = {
    'icons/n_01_icon.png': 'icons/n_01_icon.png',
    'icons/n_02_icon.png': 'icons/n_02_icon.png',
    'icons/n_03_icon.png': 'icons/n_03_icon.png',
    'icons/n_04_icon.png': 'icons/n_04_icon.png',
    'icons/n_05_icon.png': 'icons/n_05_icon.png',
    'icons/n_06_icon.png': 'icons/n_06_icon.png',
    'icons/n_07_icon.png': 'icons/n_07_icon.png',
    'icons/n_08_icon.png': 'icons/n_08_icon.png',
    'icons/n_09_icon.png': 'icons/n_09_icon.png',
    'icons/n_10_icon.png': 'icons/n_10_icon.png',
    'icons/n_11_icon.png': 'icons/n_11_icon.png',
    'icons/n_12_icon.png': 'icons/n_12_icon.png',
    'icons/n_13_icon.png': 'icons/n_13_icon.png',
    'icons/n_14_icon.png': 'icons/n_14_icon.png',
    'icons/n_15_icon.png': 'icons/n_15_icon.png',
    'icons/n_16_icon.png': 'icons/n_16_icon.png',
    'icons/n_17_icon.png': 'icons/n_17_icon.png',
    'icons/n_18_icon.png': 'icons/n_18_icon.png',
    'icons/n_19_icon.png': 'icons/n_19_icon.png',
    'icons/n_20_icon.png': 'icons/n_20_icon.png',
    'icons/n_21_icon.png': 'icons/n_21_icon.png',
    'icons/n_22_icon.png': 'icons/n_22_icon.png',
    'icons/n_23_icon.png': 'icons/n_23_icon.png',
    'icons/n_24_icon.png': 'icons/n_24_icon.png',
    'icons/n_25_icon.png': 'icons/n_25_icon.png',
    'icons/n_26_icon.png': 'icons/n_26_icon.png',
    'icons/n_27_icon.png': 'icons/n_27_icon.png',
    'icons/n_28_icon.png': 'icons/n_28_icon.png',
    'icons/n_29_icon.png': 'icons/n_29_icon.png',
    'icons/n_30_icon.png': 'icons/n_30_icon.png',
    'icons/sas_locomotion.png': 'icons/sas_locomotion.png',
    'icons/sas_motion.png': 'icons/sas_motion.png',
    'icons/sas_precision.png': 'icons/sas_precision.png',
    'icons/sas_recipe.png': 'icons/sas_recipe.png',
    'icons/sas_stage.png': 'icons/sas_stage.png',
    'icons/sas_super.png': 'icons/sas_super.png',
    'icons/sas_visual.png': 'icons/sas_visual.png',
}
