# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect Blender's extension lifecycle to the Smart Animation runtime."""

from contextlib import suppress

from . import runtime
from .runtime import ensure_runtime_initialized, get_preferences, preflight_cleanup, repair_runtime
from .smarttools_spec_guard import wrap


def _within_extension_boundary(operation, recover):
    try:
        operation()
    except BaseException as error:
        with suppress(BaseException):
            recover(error)


def register():
    _within_extension_boundary(runtime.register, runtime.registration_boundary_fallback)


def unregister():
    _within_extension_boundary(runtime.unregister, runtime.unregister_boundary_fallback)


if __name__ == "__main__":
    register()

register, unregister = wrap(register, unregister)
