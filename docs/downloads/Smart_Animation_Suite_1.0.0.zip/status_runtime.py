# SPDX-License-Identifier: GPL-3.0-or-later
"""Provide the legacy status interface through the current modal resource owner."""

from contextlib import nullcontext

from . import modal_registry


def instrument_operator_class(cls, owner="", label=""):
    return modal_registry.instrument_operator_class(cls)


def instrument_loaded_package_operators(*_args, **_kwargs):
    return ()


def capture_registration_callbacks(*_args, **_kwargs):
    return nullcontext()


capture_runtime_resources = capture_registration_callbacks


def restore_package_handlers(*_args, **_kwargs):
    return 0


def _no_legacy_status_state(*_args, **_kwargs):
    """New status records belong to the modal registry."""


clear_prefix = set_service = clear_service = register = unregister = _no_legacy_status_state


def get_status(*_args, **_kwargs):
    return dict(active_modals=modal_registry.active_count(), idle_polling=False)
