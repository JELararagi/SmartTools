# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

from .translation import sas_is_japanese, sas_text
from .storage import addon_data_path
try:
    from .panel_header_guard import harden_class_callbacks
except Exception:
    def harden_class_callbacks(cls):
        return cls

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_STATE_DIRTY = False
_MAX_STATE_ALIASES = 64
_MAX_FEATURES_PER_ALIAS = 128
_MAX_STATE_IDENTIFIER_CHARS = 128

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed, and then remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo / Redo、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。保存後はBlender再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed, and then remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。保存後はBlender再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'RNAメッセージバス監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed, and then remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する msgbus 購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。保存後はBlender再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed, and then remains after Blender restarts and scene changes.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。保存後はBlender再起動後やシーン切り替え後も維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed, and then remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。保存後はBlender再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)


def _clean_identifier(value: str, fallback: str = 'smart_animation_suite') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Animation'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_animation_suite'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _is_ja(context=None) -> bool:
    try:
        return bool(sas_is_japanese(context))
    except Exception:
        return False


def _t(context, en: str, ja: str) -> str:
    try:
        return str(sas_text(en, ja, context))
    except Exception:
        return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    # Static class/property metadata is registered in English and localized by
    # Blender's translation table so it never freezes in registration-time Japanese.
    return str(en)


def _draw_stateful_operator(layout, operator_id: str, *, text: str, icon: str, enabled: bool):
    try:
        return layout.operator(operator_id, text=text, icon=icon, depress=bool(enabled))
    except TypeError:
        return layout.operator(operator_id, text=text, icon=icon)


def _settings_path() -> Path | None:
    configure()
    try:
        return addon_data_path('settings', f'{_SUITE_KEY}_persistent_feature_toggles.json', create=True)
    except Exception:
        return None


def _sanitize_state(raw: Any) -> dict[str, dict[str, bool]]:
    if not isinstance(raw, dict):
        return {}
    clean: dict[str, dict[str, bool]] = {}
    for alias_raw in sorted(raw, key=lambda value: str(value)):
        if len(clean) >= _MAX_STATE_ALIASES:
            break
        alias = str(alias_raw or '').strip()[:_MAX_STATE_IDENTIFIER_CHARS]
        values = raw.get(alias_raw)
        if not alias or not isinstance(values, dict):
            continue
        alias_values: dict[str, bool] = {}
        for key_raw in sorted(values, key=lambda value: str(value)):
            if len(alias_values) >= _MAX_FEATURES_PER_ALIAS:
                break
            key = str(key_raw or '').strip()[:_MAX_STATE_IDENTIFIER_CHARS]
            if key:
                alias_values[key] = bool(values.get(key_raw))
        if alias_values:
            clean[alias] = alias_values
    return clean


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    try:
        from . import config_store
        raw = config_store.get_section('persistent_feature_toggles', {})
    except Exception:
        raw = {}
    if not isinstance(raw, dict):
        raw = {}
    if not raw:
        path = _settings_path()
        if path is not None and path.exists():
            try:
                if path.stat().st_size <= 8 * 1024 * 1024:
                    raw = json.loads(path.read_text(encoding='utf-8'))
            except Exception:
                raw = {}
    _STATE_CACHE = _sanitize_state(raw)
    return _STATE_CACHE


def _save_state(*, force: bool = False) -> bool:
    global _STATE_CACHE, _STATE_DIRTY
    _STATE_CACHE = _sanitize_state(_load_state())
    _STATE_DIRTY = True
    if not force:
        try:
            from . import core
            if not core.npanel_auto_save_enabled():
                return False
        except Exception:
            pass
    try:
        from . import config_store
        ok = bool(config_store.set_section('persistent_feature_toggles', _STATE_CACHE))
    except Exception:
        ok = False
    if ok:
        _STATE_DIRTY = False
    return ok


def commit_dirty_state() -> bool:
    if not _STATE_DIRTY:
        return True
    return _save_state(force=True)


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def _is_feature_enabled_cached(alias: str, feature_key: str) -> bool:
    """Pure scalar lookup for Panel.draw/tooltip paths; never performs file I/O."""
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    cache = _STATE_CACHE if isinstance(_STATE_CACHE, dict) else {}
    return bool(cache.get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    global _STATE_CACHE
    alias = str(alias or '').strip()[:_MAX_STATE_IDENTIFIER_CHARS]
    feature_key = str(feature_key or '').strip()[:_MAX_STATE_IDENTIFIER_CHARS]
    if not alias or not feature_key:
        return False
    state = _load_state()
    state.setdefault(alias, {})[feature_key] = bool(enabled)
    _STATE_CACHE = _sanitize_state(state)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    feature.setdefault('actions', []).append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = _is_feature_enabled_cached(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _snapshot_keymaps() -> set[int]:
    ids: set[int] = set()
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                ids.add(id(kmi))
    except Exception:
        pass
    return ids


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    props_out: dict[str, Any] = {}
    try:
        props = getattr(kmi, 'properties', None)
        bl_rna = getattr(props, 'bl_rna', None)
        for prop in getattr(bl_rna, 'properties', ()) or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type':
                continue
            try:
                value = getattr(props, ident)
            except Exception:
                continue
            if isinstance(value, (str, int, float, bool)):
                props_out[ident] = value
    except Exception:
        pass
    return props_out


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'km': km,
        'kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                if id(kmi) not in before:
                    actions.append(_describe_keymap_item(km, kmi))
    except Exception:
        pass
    return actions


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            if km is not None and kmi is not None:
                # Remove only the exact KeyMapItem captured by this generation.
                # Never match or delete by idname/key tuple, which could affect a
                # user or foreign add-on keymap item. The generation ledger also
                # records this same identity as the final disable/reload guard.
                try:
                    if any(candidate is kmi for candidate in km.keymap_items):
                        km.keymap_items.remove(kmi)
                except Exception:
                    try:
                        kmi.active = False
                    except Exception:
                        pass
            action['active_km'] = None
            action['active_kmi'] = None
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        km_name = str(action.get('km_name') or '')
        idname = str(action.get('idname') or '')
        if not km_name or not idname:
            return
        try:
            km = kc.keymaps.get(km_name)
        except Exception:
            km = None
        if km is None:
            try:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'), modal=bool(action.get('modal', False)))
            except TypeError:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'))
        kwargs = {
            'type': str(action.get('type') or 'NONE'),
            'value': str(action.get('value') or 'PRESS'),
            'any': bool(action.get('any', False)),
            'shift': bool(action.get('shift', False)),
            'ctrl': bool(action.get('ctrl', False)),
            'alt': bool(action.get('alt', False)),
            'oskey': bool(action.get('oskey', False)),
            'key_modifier': str(action.get('key_modifier') or 'NONE'),
            'direction': str(action.get('direction') or 'ANY'),
            'repeat': bool(action.get('repeat', False)),
        }
        try:
            kmi = km.keymap_items.new(idname, **kwargs)
        except TypeError:
            kwargs.pop('repeat', None)
            try:
                kmi = km.keymap_items.new(idname, **kwargs)
            except TypeError:
                kwargs.pop('direction', None)
                kmi = km.keymap_items.new(idname, **kwargs)
        for prop_name, value in (action.get('properties') or {}).items():
            try:
                _safe_safe_set_kmi_property_v60(kmi, prop_name, value)
            except Exception:
                pass
        action['active_km'] = km
        action['active_kmi'] = kmi
        action['active'] = True
    except Exception:
        action['active'] = False


def _apply_action(action: dict[str, Any]) -> None:
    """Re-enable only explicitly captured handler/keymap identities.

    Timers, msgbus subscriptions and draw handlers are controlled by each
    integrated tool's explicit event-driven enable/disable API.  No Blender
    process-global function is intercepted to discover them.
    """
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and not any(item is fn for item in seq):
                seq.append(fn)
                action['active'] = any(item is fn for item in seq)
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)




class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
                if not self.kind_enabled('handlers'):
                    _remove_action(action)
            for action in _collect_new_keymaps(self._before_keymaps):
                self.record_action('keymaps', action)
                if not self.kind_enabled('keymaps'):
                    _remove_action(action)
        finally:
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) in {'VIEW_3D', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR'}:
                    area.tag_redraw()
    except Exception:
        pass


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効 / 無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Animation feature. When N-panel State Save is enabled the setting is written immediately; otherwise it is saved when the scene is closed or Save Preferences is pressed.', 'Smart Animation の常時起動機能を切り替えます。Nパネル状態保存が有効な場合は即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に保存されます。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None, ledger=None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    # Explicit registration boundary: load and validate once before any draw call.
    _load_state()
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID

    class SAS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = _static_t('Toggle Always-on Feature', '常時起動機能を切り替え')
        bl_description = _static_t(
            'Switch an always-on feature on or off. The value follows N-panel State Save.',
            '常時起動機能の有効 / 無効を切り替えます。値はNパネル状態保存の設定に従います。',
        )
        bl_options = {'INTERNAL'}
        _sas_no_undo = True

        alias: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
        feature_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
        enabled: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            return {'FINISHED'}

    SAS_OT_toggle_persistent_feature.__name__ = f'SAS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE'
    SAS_OT_toggle_persistent_feature.__qualname__ = SAS_OT_toggle_persistent_feature.__name__
    SAS_OT_toggle_persistent_feature.__module__ = __name__
    harden_class_callbacks(SAS_OT_toggle_persistent_feature)
    if ledger is not None:
        ledger.register_class(SAS_OT_toggle_persistent_feature, required=True)
    else:
        bpy.utils.register_class(SAS_OT_toggle_persistent_feature)
    _REGISTERED_CLASSES.append(SAS_OT_toggle_persistent_feature)


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui(*, ledger_owned: bool = False) -> None:
    if not ledger_owned:
        for cls in reversed(_REGISTERED_CLASSES):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
    _REGISTERED_CLASSES.clear()


def unregister_all(*, ledger_owned: bool = False) -> None:
    commit_dirty_state()
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui(ledger_owned=ledger_owned)
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        props = getattr(kmi, 'properties', None)
        rna = getattr(props, 'bl_rna', None)
        prop_map = getattr(rna, 'properties', None)
        has_prop = False
        try:
            has_prop = str(prop_name) in set(prop_map.keys())
        except Exception:
            try:
                has_prop = prop_map.get(str(prop_name)) is not None
            except Exception:
                has_prop = hasattr(props, str(prop_name))
        if not has_prop:
            return False
        setattr(props, str(prop_name), value)
        return True
    except Exception:
        return False
