# SPDX-License-Identifier: GPL-3.0-or-later
"""Ownership of the callbacks and RNA classes enabled by each Storyboard section."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Step:
    enable: object
    disable: object


class Registration:
    def __init__(self):
        self._active = []
        self._ready = False

    def start(self, steps):
        if self._ready:
            return True
        if self._active and not self.stop():
            return False
        for step in steps:
            try:
                if step.enable() is False:
                    self.stop()
                    return False
            except Exception:
                self.stop()
                return False
            self._active.append(step)
        self._ready = True
        return True

    def stop(self):
        self._ready = False
        failures = []
        for step in reversed(self._active):
            try:
                cleared = step.disable() is not False
            except Exception:
                cleared = False
            if not cleared:
                failures.append(step)
        self._active = failures[::-1]
        return not failures
