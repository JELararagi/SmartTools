# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import json
import math
import hashlib
import numpy as np

from fnmatch import fnmatch
from math import pi, cos, sin
from pathlib import Path

from bpy_extras import view3d_utils
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils.geometry import intersect_line_plane
from mathutils import (Matrix,
                       Vector,
                       Color,
                       geometry,
                       )

from .constants import LAYERMAT_PREFIX
from ..global_preferences import get_preferences as _get_integrated_preferences
from ..action_compat import iter_action_fcurves


### ---
# region mapping

## Mapping of keymap items to their id
KEYNUM_MAP = {
    # Top row numbers
    "ONE": "1",
    "TWO": "2",
    "THREE": "3",
    "FOUR": "4",
    "FIVE": "5",
    "SIX": "6",
    "SEVEN": "7",
    "EIGHT": "8",
    "NINE": "9",
    "ZERO": "0",

    # Numpad numbers
    "NUMPAD_1": "1",
    "NUMPAD_2": "2",
    "NUMPAD_3": "3",
    "NUMPAD_4": "4",
    "NUMPAD_5": "5",
    "NUMPAD_6": "6",
    "NUMPAD_7": "7",
    "NUMPAD_8": "8",
    "NUMPAD_9": "9",
    "NUMPAD_0": "0"
}

### ---
# region prefs

def get_addon_prefs():
    from .preferences import STORYTOOLS_prefs
    return _get_integrated_preferences(__package__, STORYTOOLS_prefs)


def is_hosted_in_smart_animation_suite():
    '''Return True when Storytools runs as a nested package inside Smart Animation.'''
    package_name = str(__package__ or '')
    return '.storytools' in package_name and 'smart_animation_suite' in package_name


def hide_view3d_sidebar_panel(cls):
    '''Hide a standalone VIEW_3D Sidebar panel without suppressing the integrated suite body.'''
    if is_hosted_in_smart_animation_suite():
        return cls
    original_poll = getattr(cls, 'poll', None)

    @classmethod
    def _hidden_in_sidebar_poll(inner_cls, context):
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if getattr(area, 'type', None) == 'VIEW_3D' and getattr(region, 'type', None) == 'UI':
            return False
        if original_poll is None:
            return True
        try:
            return bool(original_poll(context))
        except TypeError:
            return bool(original_poll(inner_cls, context))
        except Exception:
            return True

    try:
        cls.poll = _hidden_in_sidebar_poll
    except Exception:
        pass
    return cls


### ---
# region Vector

def snap_to_step(value, step):
    # return (value//step)*step # Also valid
    return round(value / step) * step

def location_to_region(worldcoords) -> Vector:
    '''return 2d location'''
    return view3d_utils.location_3d_to_region_2d(
        bpy.context.region, bpy.context.space_data.region_3d, worldcoords)

def region_to_location(viewcoords, depthcoords) -> Vector:
    '''return normalized 3d vector'''
    return view3d_utils.region_2d_to_location_3d(
        bpy.context.region, bpy.context.space_data.region_3d, viewcoords, depthcoords)

def reset_draw_settings(context=None):
    """Apply the configured placement and orientation independently."""
    active = bpy.context if context is None else context
    tool_settings = active.scene.tool_settings
    options = get_addon_prefs()
    for target, attribute, choice in (
        (tool_settings, "gpencil_stroke_placement_view3d", options.default_placement),
        (tool_settings.gpencil_sculpt, "lock_axis", options.default_orientation),
    ):
        if choice != "NONE":
            setattr(target, attribute, choice)

def _view_axis_distance(world_from_view, point):
    axis = world_from_view.col[2].to_3d()
    if axis.length_squared == 0:
        return 0.0
    offset = Vector(point) - world_from_view.translation
    return abs(offset.dot(axis.normalized()))


def coord_distance_from_view(coord=None, context=None):
    """Measure world depth along the current viewport's forward direction."""
    ctx = context if context is not None else bpy.context
    viewport = ctx.region_data
    if viewport is None:
        return 0.0
    point = ctx.scene.cursor.location if coord is None else coord
    return _view_axis_distance(viewport.view_matrix.inverted(), point)

def get_camera_view_vector():
    '''return active camera view vector (normalized direction)
    return None if no active camera
    '''
    view_vector = Vector((0,0,-1))
    if not bpy.context.scene.camera:
        return
    view_vector.rotate(bpy.context.scene.camera.matrix_world)
    return view_vector

def get_viewport_view_vector(context=None):
    '''return current viewport view vector (normalized direction)'''
    context = context or bpy.context
    view_vector = Vector((0,0,-1))
    view_vector.rotate(context.space_data.region_3d.view_rotation)
    return view_vector

def coord_distance_from_cam(coord=None, context=None):
    """Measure world depth along the active camera's forward direction."""
    ctx = context if context is not None else bpy.context
    camera = ctx.scene.camera
    if camera is None:
        return 0.0
    point = ctx.scene.cursor.location if coord is None else coord
    return _view_axis_distance(camera.matrix_world, point)

def get_cam_frame_world(cam, scene=None):
    '''get camera frame center position in 3d space
    Need scene to get resolution ratio (default to active scene)
    ortho camera note: scale must be 1,1,1 (parent too)
    to fit right in cam-frame rectangle
    '''

    scene = scene or bpy.context.scene

    # Without scene passed, base on square
    frame = cam.data.view_frame(scene=scene)
    mat = cam.matrix_world
    frame = [mat @ v for v in frame]
    #-# Get center
    # import numpy as np
    # center = np.add.reduce(frame) / 4
    # center = np.sum(frame, axis=0) / 4
    return frame

def get_cam_frame_world_center(cam, scene=None):
    '''get camera frame center position in 3d space
    Need scene to get resolution ratio (default to active scene)
    ortho camera note: scale must be 1,1,1 (parent too)
    to fit right in cam-frame rectangle
    '''

    scene = scene or bpy.context.scene

    frame = get_cam_frame_world(cam, scene=scene)
    #-# Get center
    # return np.sum(frame, axis=0) / 4
    return np.add.reduce(frame) / 4

def calculate_dolly_zoom_position(old_position, target_position, old_focal_length, new_focal_length):
    """
    Calculates a new camera position for a dolly zoom effect based on focal length change.
    Designed to be used in a modal operator with a slider.

    Args:
        old_position: The previous/current camera position (mathutils.Vector)
        target_position: The target position (mathutils.Vector)
        old_focal_length: The previous/current focal length in mm
        new_focal_length: The new focal length in mm

    Returns:
        Vector: The new camera position
    """
    # Get direction vector from old camera position to target
    direction = (target_position - old_position).normalized()

    # Calculate current distance
    current_distance = (target_position - old_position).length

    # Calculate new distance to maintain same field of view for subject
    # The ratio of distances should equal the ratio of focal lengths
    new_distance = current_distance * (new_focal_length / old_focal_length)

    # Calculate new position
    return target_position - direction * new_distance

def replace_rotation_matrix(M1, M2):
    """Copy the source frame and replace its 3-by-3 orientation block."""
    result = M1.copy()
    count = min(3, len(M1), len(M2))
    for axis in range(count):
        first = tuple(M2[axis][:count])
        result[axis] = first + tuple(result[axis][count:])
    return result

def get_scale_matrix(scale) -> Matrix:
    return Matrix.Diagonal((*scale, 1))

def assign_rotation_from_ref_matrix(obj, ref_mat, rot_90=True):
    matrix_attr = "matrix_world" if obj.parent else "matrix_basis"
    position, _, scale = getattr(obj, matrix_attr).decompose()
    orientation = ref_mat.to_quaternion()
    if rot_90:
        from mathutils import Quaternion
        orientation = orientation @ Quaternion((1, 0, 0), -math.tau / 4)
    result = Matrix.LocRotScale(position, orientation, scale)
    setattr(obj, matrix_attr, result)
    return result

## -- used for static storyboard

def get_min_max_corner(positions, margin=0):
    """Enclose all projected X/Z points while retaining the panel's depth."""
    left = min(positions, key=lambda point: (point.x, point.z))
    right = max(positions, key=lambda point: (point.x, point.z))
    bottom = min(point.z for point in positions)
    top = max(point.z for point in positions)
    padding = 0.1 * ((right.x - left.x) ** 2 + (top - bottom) ** 2) ** 0.5 if margin else 0
    return Vector((left.x - padding, left.y, bottom - padding)), Vector((right.x + padding, right.y, top + padding))

## unused - need to test performance against any_point_in_box
def any_point_in_rectangle_numpy(stroke, bottom_left, upper_right):
    for entry in stroke.points:
        point = entry.position
        if bottom_left.x <= point.x <= upper_right.x and bottom_left.z <= point.z <= upper_right.z:
            return np.bool_(True)
    return np.bool_(False)

def any_point_in_box(coords, min_corner, max_corner):
    ''' Check if any point in coords list is within the X-Z bounding box defined by min_corner and max_corner
    coords : list of Vector3 or tuple coordinates
    min_corner : Vector3, lower left corner of the bounding box
    max_corner : Vector3, upper right corner of the bounding box
    '''
    return any(min_corner.x <= co.x <= max_corner.x and min_corner.z <= co.z <= max_corner.z for co in coords)

### ---
# region Camera/View Frustum

## User view calculation from Swann Martinez's Multi-user addon
def _drawing_plane_origin(context):
    scene = context.scene
    if scene.tool_settings.gpencil_stroke_placement_view3d == "CURSOR":
        return scene.cursor.location
    if context.object is not None:
        return context.object.matrix_world.translation
    return None

def _drawing_plane_orientation(context):
    locked = context.scene.tool_settings.gpencil_sculpt.lock_axis
    if locked == "VIEW":
        return context.space_data.region_3d.view_rotation
    if locked == "CURSOR":
        return context.scene.cursor.matrix.to_quaternion()
    if context.object is None:
        return Quaternion()
    return context.object.matrix_world.to_quaternion()


def project_to_viewport(region: bpy.types.Region, rv3d: bpy.types.RegionView3D, coords: tuple, distance: float = 1.0) -> Vector:
    """Place a screen position on its viewing ray at a given distance."""
    if region is None or rv3d is None or not coords:
        return Vector((0, 0, 0))
    anchor = view3d_utils.region_2d_to_origin_3d(region, rv3d, coords)
    step = view3d_utils.region_2d_to_vector_3d(region, rv3d, coords)
    anchor += step * distance
    return anchor

def generate_user_camera(area, region, rv3d) -> list:
    """Return viewport corners in clockwise order, center, orbit and rear origin."""
    if not (area and region and rv3d):
        return [[0, 0, 0] for _point in range(7)]
    right, top = region.width, region.height
    frame = [(right, top), (right, 0), (0, 0), (0, top)]
    center = (right / 2, top / 2)
    markers = [project_to_viewport(region, rv3d, point) for point in (*frame, center)]
    markers.append(rv3d.view_location.copy())
    markers.append(project_to_viewport(region, rv3d, center, distance=-0.8))
    return markers

# Unused, but could be called by get_frustum_lines()
def extrapolate_points_by_length(a, b, length):
    '''
    Return a third point C from by continuing in AB direction
    Length define BC distance. both vector2 and vector3
    '''
    # return b + ((b - a).normalized() * length)# one shot
    ab = b - a
    if not ab:
        return None
    return b + (ab.normalized() * length)

def circle_3d(x, y, radius, segments):
    return [Vector((*point, 0)) for point in circle_2d(x, y, radius, segments)]

def _clip_frustum_ray(anchor, ray, facing, plane):
    slope = ray.dot(facing)
    if abs(slope) <= 1e-6:
        return None
    return anchor + ray * ((plane - anchor).dot(facing) / slope)

def _map_frame_frustum(transform, origin, corners, clip, mode):
    # Frame order from Blender is right pair followed by left pair.
    right_edge = corners[0].lerp(corners[1], 0.5)
    left_edge = corners[2].lerp(corners[3], 0.5)
    facing = transform.to_quaternion() @ Vector((0.0, 0.0, 1.0))
    near, far = [transform @ Vector((0.0, 0.0, -value)) for value in clip]
    return get_frustum_lines(origin, left_edge, right_edge, facing, near, far, mode)


def get_frustum_lines(loc, left, right, orient, near_clip_point, far_clip_point, view_type):
    """Return four consecutive line pairs in the order expected by the map."""
    z_planes = near_clip_point, far_clip_point
    sides = []
    for edge in (left, right):
        base, ray = (edge, orient) if view_type == 'ORTHO' else (loc, edge - loc)
        sides.append([_clip_frustum_ray(base, ray, orient, plane) for plane in z_planes])
    near_left, far_left = sides[0]
    near_right, far_right = sides[1]
    return [near_left, far_left, near_right, far_right,
            near_left, near_right, far_left, far_right]

def get_camera_frustum(cam, context=None):
    if cam is None or cam.type != 'CAMERA':
        return []
    frame_scene = (bpy.context if context is None else context).scene
    pose = cam.matrix_world
    lens = cam.data
    frame = [pose @ corner for corner in lens.view_frame(scene=frame_scene)]
    return _map_frame_frustum(pose, pose.translation, frame,
                              (lens.clip_start, lens.clip_end), lens.type)

def get_viewport_frustum(area, region, rv3d, space):
    pose = rv3d.view_matrix.inverted()
    view_corners = generate_user_camera(area, region, rv3d)
    return _map_frame_frustum(pose, view_corners[6], view_corners[:4],
                              (space.clip_start, space.clip_end), rv3d.view_perspective)


### ---
# region Collection management

def get_view_layer_collection(col, vl_col=None, view_layer=None):
    if vl_col is None:
        vl_col = (view_layer or bpy.context.view_layer).layer_collection
    stack = list(reversed(vl_col.children))
    while stack:
        layer = stack.pop()
        if layer.collection == col:
            return layer
        stack.extend(reversed(layer.children))
    return None

### ---
# region Object

def empty_at(pos, name="Empty", type="PLAIN_AXES", size=1.0, show_name=False, link=True):
    """Create or reposition a named Empty used as a drawing or camera target."""
    objects = bpy.data.objects
    marker = objects.get(name)
    if marker is None or marker.type != "EMPTY":
        marker = objects.new(name, None)
        if link:
            bpy.context.collection.objects.link(marker)
    marker.location = pos
    marker.empty_display_type = type
    marker.empty_display_size = size
    marker.show_name = show_name
    return marker

def pack_images_in_object(obj, verbose=False):
    '''Pack all image textures used by object into the blend file.
    obj (Object): object containing materials with image textures.
    '''
    # Ensure the object has materials
    if not obj.data.materials:
        return

    # print(f"Packing images for object: {obj.name}")
    for mat in obj.data.materials:
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    node.image.pack()
                    if verbose:
                        pass  # Console-silent bundled-tool diagnostic.

### ---
# region GP

## Unused, but has potential for later utility
def get_gp_draw_plane(context):
    locked = context.scene.tool_settings.gpencil_sculpt.lock_axis
    axis = {"AXIS_X": (1, 0, 0), "AXIS_Y": (0, 1, 0)}.get(locked, (0, 0, 1))
    return _drawing_plane_origin(context), _drawing_plane_orientation(context) @ Vector(axis)

def get_gp_draw_plane_matrix(context):
    origin = _drawing_plane_origin(context)
    if origin is None:
        return None
    locked = context.scene.tool_settings.gpencil_sculpt.lock_axis
    quarter_turn = math.pi / 2
    facing = {
        "AXIS_X": ((0, 1, 0), -quarter_turn),
        "AXIS_Y": ((1, 0, 0), quarter_turn),
    }
    plane = _drawing_plane_orientation(context)
    if locked in facing:
        plane = plane @ Quaternion(*facing[locked])
    result = plane.to_matrix().to_4x4()
    result.translation = origin
    return result


def _drawing_normal(points):
    origin, second, last = points
    return (second - origin).cross(last - origin)


def create_default_layers(object, frame=None, use_lights=False, set_material_sync=True):
    frame_number = bpy.context.scene.frame_current if frame is None else frame
    defaults = (("Color", "fill_white"), ("Line", "line"),
                ("Sketch", "line"), ("Annotate", "line_red"))
    for label, material in defaults:
        entry = object.data.layers.new(label)
        entry.use_lights = use_lights
        entry.frames.new(frame_number)
        if set_material_sync:
            set_material_association(object, entry, material)

def _drawing_collection(context):
    collections = context.scene.collection.children_recursive
    for prefix in ("Drawings", "GP"):
        for collection in collections:
            if collection.name.startswith(prefix):
                return collection
    return context.collection

def _prepare_drawing_data(drawing, context, prefs, material_source, layer_source):
    data = drawing.data
    if material_source and material_source.data.materials:
        for material in material_source.data.materials:
            data.materials.append(material)
    else:
        load_default_palette(drawing)

    data.use_autolock_layers = prefs.use_autolock_layers
    if layer_source and layer_source.data.layers:
        for original in layer_source.data.layers:
            new_layer = data.layers.new(original.name)
            new_layer.use_lights = original.use_lights
            new_layer.opacity = original.opacity
            new_layer.frames.new(context.scene.frame_current)
        for key, value in layer_source.items():
            if key.startswith(LAYERMAT_PREFIX):
                drawing[key] = value
    else:
        create_default_layers(drawing, frame=context.scene.frame_current, use_lights=prefs.use_lights)
    if data.layers:
        data.layers.active = data.layers.get("Sketch") or data.layers[-1]


def create_gp_object(name="", parented=False, at_cursor=False, init_dist=8.0,
                     face_camera=True, track_to_cam=False, enter_draw_mode=True,
                     location=None, material_from_obj=None, layer_from_obj=None,
                     context=None):
    """Create and configure a drawing before selecting it for editing."""
    context = bpy.context if context is None else context
    scene = context.scene
    space = context.space_data
    view = space.region_3d
    camera = scene.camera
    orient_to_camera = camera and face_camera and view.view_perspective != "CAMERA"
    frame = camera.matrix_world if orient_to_camera else view.view_matrix.inverted()

    if location is None:
        location = scene.cursor.location.copy() if at_cursor else frame @ Vector((0, 0, -init_dist))
    drawing_rotation = frame.decompose()[1].to_matrix() @ Matrix.Rotation(-pi / 2, 3, "X")
    drawing_transform = Matrix.LocRotScale(location, drawing_rotation, (1, 1, 1))
    name = name.strip()
    if not name:
        next_number = 1 + sum(obj.type == "GREASEPENCIL" for obj in bpy.data.objects)
        name = f"Drawing_{next_number:03d}"

    collection = _drawing_collection(context)
    data = bpy.data.grease_pencils.new(name)
    drawing = None
    try:
        drawing = bpy.data.objects.new(name, data)
        collection.objects.link(drawing)
        if parented and camera:
            drawing.parent = camera
        drawing.matrix_world = drawing_transform
        if track_to_cam and camera:
            aim = drawing.constraints.new("TRACK_TO")
            aim.track_axis = "TRACK_Y"
            aim.up_axis = "UP_Z"
            aim.target = camera
        _prepare_drawing_data(drawing, context, get_addon_prefs(), material_from_obj, layer_from_obj)
    except Exception:
        if drawing is not None:
            bpy.data.objects.remove(drawing, do_unlink=True)
        bpy.data.grease_pencils.remove(data)
        raise

    previous = context.object
    if previous and previous.visible_get() and context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    if context.mode == "OBJECT":
        bpy.ops.object.select_all(action="DESELECT")
    context.view_layer.objects.active = drawing
    drawing.select_set(True)
    update_ui_prop_index(context)
    if enter_draw_mode:
        bpy.ops.object.mode_set(mode="PAINT_GREASE_PENCIL")
        reset_draw_settings(context)
    if sum(item.type == "GREASEPENCIL" for item in scene.objects) == 1:
        space.overlay.use_gpencil_grid = True
    return drawing

def get_coplanar_stroke_vector(obj, s, ensure_colplanar=True, tol=0.0003):
    count = len(s.points)
    if count < 4:
        return None
    transform = obj.matrix_world
    step = count // 3
    samples = tuple(transform @ s.points[index].position for index in (0, step, step * 2))
    normal = _drawing_normal(samples)
    if not ensure_colplanar:
        return normal
    if not normal.length_squared:
        return None
    direction = normal.normalized()
    if max(abs((transform @ point.position - samples[0]).dot(direction)) for point in s.points) > tol:
        return None
    return normal

def get_normal(obj, frame, tol=0.0003):
    strokes = frame.drawing.strokes
    count = len(strokes)
    if not count:
        return None
    if count < 3:
        return get_coplanar_stroke_vector(obj, strokes[0], ensure_colplanar=False)
    anchors = tuple(strokes[index].points for index in (0, 1, count - 1))
    if not all(len(points) for points in anchors):
        return None
    return _drawing_normal(tuple(obj.matrix_world @ points[0].position for points in anchors))

def get_coord(obj, frame):
    coords = [p.position for s in frame.drawing.strokes for p in s.points]
    mean_coord = sum(coords, Vector()) / len(coords)
    return obj.matrix_world @ mean_coord

def get_frame_coord_and_normal(obj, frame, tol=0.0003):
    '''Get a GP frame object return normal plane if strokes are coplanar (with a tolerance).
    return normal vector if coplanar else None
    '''

    ## get plane_co
    plane_co = get_coord(obj, frame)

    plane_no = get_normal(obj, frame, tol=tol)

    # if plane_no:
    #     ## Get bbox center
    #     bbox_center = sum([obj.matrix_world @ Vector(corner[:]) for corner in obj.bound_box], Vector()) / 8
    #     ## Project on plane found plane normal
    #     plane_co = intersect_line_plane(bbox_center, bbox_center + plane_no, obj.matrix_world @ frame.drawing.strokes[0].position, plane_no)
    #     plane_co = plane_co or bbox_center

    return plane_co, plane_no


### ---
# region Palette

def name_to_hue(name):
    # Use MD5 hash for consistency across sessions
    hash_value = hashlib.md5(name.encode()).hexdigest()
    # Convert first 8 characters of hash to integer and scale to 0-1
    return int(hash_value[:8], 16) / 0xffffffff

def load_palette(filepath, ob=None):
    with open(filepath, 'r') as fd:
        mat_dic = json.load(fd)
    # from pprint import pprint
    # pprint(mat_dic)

    if ob is None:
        ob = bpy.context.object

    for mat_name, attrs in mat_dic.items():
        curmat = bpy.data.materials.get(mat_name)
        if curmat:
            # exists
            if curmat.is_grease_pencil:
                if curmat not in ob.data.materials[:]: # add only if it's not already there
                    ob.data.materials.append(curmat)
                continue
            else:
                mat_name = mat_name + '.01' # rename to avoid conflict

        ## Create a GP mat
        mat = bpy.data.materials.new(name=mat_name)
        bpy.data.materials.create_gpencil_data(mat)

        ob.data.materials.append(mat)
        for attr, value in attrs.items():
            if bpy.app.version >= (5, 1, 0) and attr in ('show_fill', 'show_stroke'):
                ## Starting Blender 5.1, Those are transferred to stroke and are now deprecated.
                continue
            setattr(mat.grease_pencil, attr, value)


def load_default_palette(ob=None):
    folder = Path(__file__).with_name("palettes")
    base_palette = folder.joinpath("base.json")
    if base_palette.is_file():
        load_palette(base_palette, ob=ob)
        return "FINISHED", "Loaded base Palette"
    if folder.is_dir():
        return "ERROR", f"base.json palette not found in {folder.as_posix()}"
    return "ERROR", "Palette path not found"

def set_material_association(ob, layer, mat_name):
    '''Take an object, a gp layer and a material name
    Create custom prop for layer material association if possible
    '''
    if not ob.data.materials.get(mat_name):
        pass  # Console-silent bundled-tool diagnostic.
        return
    # create custom prop at object level
    ob[LAYERMAT_PREFIX + layer.name] = mat_name




def set_material_by_name(ob, mat_name) -> None:
    """Use the existing material slot with the requested material name."""
    if mat_name:
        for index, slot in enumerate(ob.material_slots):
            material = slot.material
            if material is not None and material.name == mat_name:
                ob.active_material_index = index
                break

def set_layer_by_name(ob, name):
    if name is None or name == '':
        return
    if target_layer := ob.data.layers.get(name):
        ob.data.layers.active = target_layer

### ---
# region Animation

def key_object(ob, loc=True, rot=True, scale=True, use_autokey=False, mode=None, options=set(), context=None):
    '''Keyframe object location, rotation, scale
    :ob: Object to key
    :loc: key location
    :rot: key rotation
    :scale: key scale
    :use_autokey: Respect auto_key (if enabled, key only if autokey is activated)
    :mode: in None (default), 'AVAILABLE' (add INSERTKEY_AVAILABLE), 'KEYING_SET' (respect keying set, not implemented)

    :options: Set in keyframe insert options:
    - ``INSERTKEY_NEEDED`` Only insert keyframes where they're needed in the relevant F-Curves.
    - ``INSERTKEY_VISUAL`` Insert keyframes based on 'visual transforms'.
    - ``INSERTKEY_XYZ_TO_RGB`` Color for newly added transformation F-Curves (Location, Rotation, Scale) is based on the transform axis.
    - ``INSERTKEY_REPLACE`` Only replace already existing keyframes.
    - ``INSERTKEY_AVAILABLE`` Only insert into already existing F-Curves.
    - ``INSERTKEY_CYCLE_AWARE`` Take cyclic extrapolation into account (Cycle-Aware Keying option).
    '''

    context = context or bpy.context

    ## Return if not autokeying
    if use_autokey and not context.scene.tool_settings.use_keyframe_insert_auto:
        return False
    if mode == 'AVAILABLE' and not options:
        options={'INSERTKEY_AVAILABLE',}

    act = None
    animation_data = ob.animation_data
    if animation_data:
        act = animation_data.action

    key_loc = False
    key_rot = False
    key_scale = False

    if mode is None:
        if loc: key_loc = True
        if rot: key_rot = True
        if scale: key_scale = True

    elif mode == 'AVAILABLE':
        if not act:
            return
        action_fcurves = list(iter_action_fcurves(act, datablock=ob))
        if loc: key_loc = next((fc for fc in action_fcurves if fc.data_path == 'location'), None)
        if rot: key_rot = next((fc for fc in action_fcurves if fc.data_path == 'rotation_euler'), None)
        if scale: key_scale = next((fc for fc in action_fcurves if fc.data_path == 'scale'), None)

    # if not act:
    #     if loc: key_loc = True
    #     if rot: key_rot = True
    #     if scale: key_scale = Truew

    text=[]
    if key_loc:
        ob.keyframe_insert('location', group='Object Transforms', options=options)
        text += ['location']
    if key_rot:
        ob.keyframe_insert('rotation_euler', group='Object Transforms', options=options)
        text += ['rotation']
    if key_scale:
        ob.keyframe_insert('scale', group='Object Transforms', options=options)
        text += ['scale']


    if text:
        return f'{ob.name}: Insert {", ".join(text)} keyframes'
    return

def key_data_path(ob, data_path, use_autokey=False, options=None, context=None):
    """Insert keys for individual RNA paths and report the paths that succeeded."""
    if use_autokey and not (context or bpy.context).scene.tool_settings.use_keyframe_insert_auto:
        return False
    paths = (data_path,) if isinstance(data_path, str) else data_path
    flags = set() if options is None else options
    inserted = [path for path in paths if ob.keyframe_insert(data_path=path, options=flags)]
    if inserted:
        return "{}: Insert {} keyframes".format(ob.name, ", ".join(inserted))
    return None

### ---
# region UI

def refresh_areas():
    for area in bpy.context.screen.areas:
        area.tag_redraw()

def show_message_box(_message="", _title="Message Box", _icon="NONE"):
    rows = (_message,) if isinstance(_message, str) else tuple(_message)

    def render_popup(menu, context):
        layout = menu.layout
        for entry in rows:
            if isinstance(entry, str):
                layout.label(text=entry)
                continue
            match entry:
                case label, icon:
                    layout.label(text=label, icon=icon)
                case operator_id, label, icon:
                    actions = layout.column(align=True)
                    actions.operator_context = "INVOKE_DEFAULT"
                    actions.operator(operator_id, text=label, icon=icon, emboss=False)
                case owner, key, label, icon:
                    property_line = layout.row(align=True)
                    property_line.label(text=label, icon=icon)
                    property_line.prop(owner, key, text="")

    manager = bpy.context.window_manager
    manager.popup_menu(render_popup, title=_title, icon=_icon)


def is_minimap_viewport(context=None, space_data=None):
    """Recognize the locked top-down viewport used by the storyboard map."""
    if space_data is None:
        area = (context or bpy.context).area
        space_data = area.spaces.active if area else None
    if space_data is None or space_data.type != "VIEW_3D":
        return False
    if space_data.region_quadviews or space_data.show_object_viewport_lattice or space_data.show_object_viewport_light_probe:
        return False
    view = space_data.region_3d
    if view is None or view.view_perspective != "ORTHO" or not view.lock_rotation:
        return False
    tilt = view.view_matrix.to_euler()
    return abs(tilt.x) < 1e-5 and abs(tilt.y) < 1e-5

def get_header_margin(context, bottom=True, overlap=False) -> int:
    return 0

def set_gizmo_settings(
    gz, icon, color=(0.0, 0.0, 0.0), color_highlight=(0.5, 0.5, 0.5),
    alpha=0.7, alpha_highlight=0.7, show_drag=False,
    draw_options=frozenset(("BACKDROP", "OUTLINE")), scale_basis=24,
):
    """Apply a complete style when constructing a toolbar button."""
    appearance = (
        ("icon", icon),
        ("color", color),
        ("color_highlight", color_highlight),
        ("alpha", alpha),
        ("alpha_highlight", alpha_highlight),
        ("draw_options", set(draw_options)),
        ("scale_basis", scale_basis),
    )
    for field, value in appearance:
        setattr(gz, field, value)
    gz.show_drag, gz.use_draw_offset_scale = show_drag, True
    # gz.line_width = 1.0 # no affect on 2D gizmo ?

def circle_2d(x, y, radius, segments):
    if segments < 2:
        return [(x + radius, y)] if segments == 1 else []
    angles = (math.tau * step / (segments - 1) for step in range(segments))
    return [(x + radius * math.cos(angle), y + radius * math.sin(angle)) for angle in angles]

def update_ui_prop_index(context):
    """Update the camera and drawing indices from the current scene order."""
    scene = context.scene
    index = {item.name: offset for offset, item in enumerate(scene.objects)}
    if scene.camera:
        scene.st_camera_props["index"] = index.get(scene.camera.name, 1)
    active = context.object
    if active and active.type == "GREASEPENCIL" and active.name in index:
        scene.gp_object_props["index"] = index[active.name]

### ---
# region keymap UI

def get_tool_presets_keymap():
    manager = bpy.context.window_manager
    config = manager.keyconfigs.user if manager is not None else None
    if config is None:
        return []

    def ranking(binding):
        _, item = binding
        rank = item.properties.order
        if rank:
            return (0, rank, "")
        return (1, 0, KEYNUM_MAP.get(item.type, item.type))

    bindings = []
    for keymap in config.keymaps:
        bindings.extend((keymap, item) for item in keymap.keymap_items
                        if item.idname == "storytools.set_draw_tool")
    return sorted(bindings, key=ranking)


def _indented_layout(layout, level):
    """Reserve a small spacer on the left of indented keymap entries."""
    width = max(1, getattr(bpy.context.region, "width", 0))
    gutter = min(0.9, max(0.000001, (16 * level) / width))
    columns = layout.split(factor=gutter)
    columns.column()
    return columns.column()

def draw_kmi_custom(km, kmi, layout):
    ## modified from rna_keymap_ui import draw_km, draw_kmi
    base_col = _indented_layout(layout, 0)
    # base_col = layout.column()
    if kmi.show_expanded:
        expanded_col = base_col.column(align=True)
        box = expanded_col.box()
    else:
        box = base_col.column()

    split = box.split()

    row = split.row(align=True)

    ## / Specific to Storytools keymap show order prop
    if hasattr(kmi.properties, "order"):
        subrow = row.row(align=True)
        subrow.prop(kmi.properties, "order", text="")
        subrow.scale_x = 0.2
    ## end keymap order /
    row.prop(kmi, "show_expanded", text="", emboss=False)
    row.prop(kmi, "active", text="", emboss=False)

    # if km.is_modal:
    #     row.separator()
    #     row.prop(kmi, "propvalue", text="")
    # else:
    #     row.label(text=kmi.name)
    row.label(text=kmi.name)

    row = split.row()
    map_type = kmi.map_type
    row.prop(kmi, "map_type", text="")
    if map_type == 'KEYBOARD':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'MOUSE':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'NDOF':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'TWEAK':
        subrow = row.row()
        subrow.prop(kmi, "type", text="")
        subrow.prop(kmi, "value", text="")
    elif map_type == 'TIMER':
        row.prop(kmi, "type", text="")
    else:
        row.label()

    # mod_list = [m for m in ('ctrl','shift','alt', 'oskey') if getattr(kmi, m)]
    # if mod_list:
    #     mods = ' + '.join(mod_list)
    #     row.label(text=f'{mods} + ')
    # else:
    #     row.label(text='Key:')
    # row.prop(kmi, "key_modifier", text="", event=True)
    # row.separator()
    # row.label(text='+ Click')

    if (not kmi.is_user_defined) and kmi.is_user_modified:
        ## Not defined by user and has been modified : allow revert to initial state

        ## User
        ## Native keyitem_restore is not accessible in addon prefs
        # row.operator('preferences.keyitem_restore', text="", icon='BACK').item_id = kmi.id

        ops = row.operator("storytools.restore_keymap_item", text="", icon='BACK') # modified
        ops.km_name = km.name
        ops.kmi_id = kmi.id

    elif kmi.is_user_defined:
        ## Defined by user : allow removal

        ## Native remove operator do not allow to remove when diplayed out of keymap window
        # row.operator(
        #     "preferences.keyitem_remove",
        #     text="",
        #     # Abusing the tracking icon, but it works pretty well here.
        #     icon=('TRACKING_CLEAR_BACKWARDS' if kmi.is_user_defined else 'X')
        # ).item_id = kmi.id

        ## Use a custom one
        ops = row.operator("storytools.remove_keymap_item", text="", icon='X') # modified
        ops.km_name = km.name
        ops.kmi_id = kmi.id

    else:
        # Not defined by user and not modified : no action (do not expose remove on addon listing it's own keymaps)
        row.label(text='', icon='BLANK1')

    # Expanded, additional event settings
    if kmi.show_expanded:
        col = col.column()
        box = col.box()

        split = box.column()
        # split = box.split(factor=0.4)

        ## Don't show idname (no place to change ops)
        # sub = split.row()
        # if km.is_modal:
        #     sub.prop(kmi, "propvalue", text="")
        # else:
        #     sub.prop(kmi, "idname", text="")

        if map_type not in {'TEXTINPUT', 'TIMER'}:
            sub = split.column()
            subrow = sub.row(align=True)

            if map_type == 'KEYBOARD':
                subrow.prop(kmi, "type", text="", event=True)
                subrow.prop(kmi, "value", text="")
                subrow_repeat = subrow.row(align=True)
                subrow_repeat.active = kmi.value in {'ANY', 'PRESS'}
                subrow_repeat.prop(kmi, "repeat", text="Repeat")
            elif map_type in {'MOUSE', 'NDOF'}:
                subrow.prop(kmi, "type", text="")
                subrow.prop(kmi, "value", text="")

            if map_type in {'KEYBOARD', 'MOUSE'} and kmi.value == 'CLICK_DRAG':
                subrow = sub.row()
                subrow.prop(kmi, "direction")

            # sub = split.column()
            sub = box.column()
            # sub.label(text='Modifiers:')
            subrow = sub.row()
            subrow.scale_x = 0.75
            subrow.prop(kmi, "any", toggle=True)
            if bpy.app.version >= (3,0,0):
                subrow.prop(kmi, "shift_ui", toggle=True)
                subrow.prop(kmi, "ctrl_ui", toggle=True)
                subrow.prop(kmi, "alt_ui", toggle=True)
                subrow.prop(kmi, "oskey_ui", text="Cmd", toggle=True)
            else:
                subrow.prop(kmi, "shift", toggle=True)
                subrow.prop(kmi, "ctrl", toggle=True)
                subrow.prop(kmi, "alt", toggle=True)
                subrow.prop(kmi, "oskey", text="Cmd", toggle=True)

            subrow.prop(kmi, "key_modifier", text="", event=True)

        # Operator properties
        box.template_keymap_item_properties(kmi)


### ---
# region Property dump

def convert_attr(Attr):
    """Convert numeric containers to structures JSON can encode."""
    transformations = (
        ((Vector, Color), tuple),
        ((Matrix,), lambda value: [tuple(row) for row in value]),
        ((bpy.types.bpy_prop_array, set), list),
    )
    for classes, transform in transformations:
        if isinstance(Attr, classes):
            return transform(Attr)
    return Attr

basic_exclusions = (
### add lines here to exclude specific attribute
## Basics
'bl_rna', 'identifier', 'name_property', 'rna_type', 'properties', 'id_data', 'children', 'children_recursive',

## To avoid recursion/crash on direct object call (comment for API check on deeper props)
'data', 'edges', 'faces', 'edge_keys', 'polygons', 'loops', 'face_maps', 'original',
'bl_idname',

##  Avoid some specific objects properties
#'matrix_local', 'matrix_parent_inverse', 'matrix_basis','location','rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale', 'translation',
)

## root exclusions to add
root_exclusions = ('active_section', 'is_dirty', 'studio_lights', 'solid_lights')

known_types = (int, float, bool, str, set, Vector, Color, Matrix)




def frame_objects(context, target="NONE", objects=None, apply=True):
    """Fit the map to the transformed bounds of its requested targets."""
    if objects is None:
        scene = context.scene
        if target == "ACTIVE":
            objects = (context.object,)
        else:
            objects = [item for item in scene.objects if item.type == "GREASEPENCIL" and item.visible_get()]
            if target == "ALL" and scene.camera:
                objects.append(scene.camera)
    view = context.region_data
    corners = [item.matrix_world @ Vector(corner) for item in objects if item is not None
               for corner in item.bound_box]
    if view is None or not corners:
        return {"CANCELLED"}
    ranges = [(min(values), max(values)) for values in zip(*corners)]
    center_x, center_y = ((low + high) * 0.5 for low, high in ranges[:2])
    distance = max(high - low for low, high in ranges[:2])
    if target == "ACTIVE":
        distance *= 1.2
    distance = max(2.0, distance)
    height = view.view_location.z
    if height < ranges[2][1]:
        height = ranges[2][1] + 0.2
    center = Vector((center_x, center_y, height))
    if apply:
        view.view_location = center
        view.view_distance = distance
    return distance, center

from mathutils import Quaternion
