# SPDX-License-Identifier: GPL-3.0-or-later
"""Track each successfully activated Storyboard child exactly once."""

from ._registration import Registration, Step


def bind(children):
    lifecycle = Registration()

    def register():
        return lifecycle.start(Step(child.register, child.unregister) for child in children)

    return register, lifecycle.stop
