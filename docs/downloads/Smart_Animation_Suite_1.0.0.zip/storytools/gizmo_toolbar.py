# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.types import (
    Operator,
    GizmoGroup,
    Gizmo
    )

from mathutils import Matrix, Vector
from gpu_extras.batch import batch_for_shader
from .fn import get_addon_prefs
from . import fn
from .. import smart_tools_manager_compat as manager_compat



## TESTS create a custom draw for 2d button
# r = 5
# button_shape_lines = [
#     (r, -r), (r, r), (-r, r),
#     (r, -r), (-r, r), (-r, -r),
# ]

# class VIEW3D_GT_button_widget(Gizmo):
#     bl_idname = "VIEW3D_GT_button_widget"

#     __slots__ = (
#         "button_shape",
#     )

#     def draw(self, context):
#         # self.color =  (0.2392, 0.2392, 0.2392) # non-gamma-corrected:(0.0466, 0.0466, 0.0466)
#         # self.color_highlight = (0.27, 0.27, 0.27)
#         self.draw_custom_shape(self.button_shape)

#     # def test_select(self, context, select_id):
#     #     pass

#     def test_select(self, context, select_id):
#             px_scale = context.preferences.system.ui_scale
#             x_min = self.matrix_basis.to_translation().x + (r * px_scale)
#             x_max = self.matrix_basis.to_translation().x + (r * px_scale)
#             y_min = self.matrix_basis.to_translation().y + (r * px_scale)
#             y_max = self.matrix_basis.to_translation().y + (r * px_scale)
#             select = 1 if x_min < select_id[0] < x_max and y_min < select_id[1] < y_max else -1

#             return select

#     def setup(self):
#         if not hasattr(self, "button_shape"):
#             self.button_shape = self.new_custom_shape('TRIS', button_shape_lines)

#     def invoke(self, context, event):
#         return {'RUNNING_MODAL'}

#     def exit(self, context, cancel):
#         pass

#     def modal(self, context, event, tweak):
#         return {'RUNNING_MODAL'}

class STORYTOOLS_GGT_toolbar(GizmoGroup):
    # bl_idname = "STORYTOOLS_GGT_toolbar"
    bl_label = "Story Tool Bar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'} # SHOW_MODAL_ALL ? 

    @classmethod
    def poll(cls, context):
        if not manager_compat.workspace_runtime_allows_context(context):
            return False
        if not context.space_data.show_gizmo:
            return False
        ## To only show in camera view
        # return context.space_data.region_3d.view_perspective == 'CAMERA'
        return not fn.is_minimap_viewport(context)

    def setup(self, context):
        groups = {
            "object_gizmos": (
                ("ob_pan", "object_pan", "VIEW_PAN", True, {}),
                ("ob_depth", "object_depth_move", "EMPTY_SINGLE_ARROW", True, {}),
                ("ob_rotate", "object_rotate", "FILE_REFRESH", True, {}),
                ("ob_scale", "object_scale", "FULLSCREEN_ENTER", True, {}),
                ("ob_align_to_view", "align_with_view", "AXIS_FRONT", False, {}),
                ("key_ob", "object_key_transform", "DECORATE_KEYFRAME", False, {}),
            ),
            "camera_gizmos": (
                ("cam_pan", "camera_pan", "VIEW_PAN", True, {}),
                ("cam_depth", "camera_depth", "EMPTY_SINGLE_ARROW", True, {}),
                ("cam_rot", "object_rotate", "FILE_REFRESH", True, {"camera": True}),
                ("lock_cam", "lock_camera_to_view_toggle", "OUTLINER_OB_CAMERA", False, {}),
                ("lock_view", "lock_view", "LOCKVIEW_ON", False, {}),
                ("key_cam", "camera_key_transform", "DECORATE_KEYFRAME", False, {}),
            ),
            "interact_gizmos": (
                ("autokey", "autokey_switch", "RECORD_OFF", False, {}),
                ("cursor_snap", "snap_3d_cursor", "CURSOR", False, {}),
                ("draw", "object_draw", "GREASEPENCIL", False, {}),
            ),
            "gpencil_gizmos": (
                ("gp_new_frame", "new_frame", "DECORATE_ANIMATE", False, {}),
                ("gp_new_additive_frame", "new_frame", "SHAPEKEY_DATA", False, {"duplicate": True}),
                ("gp_jump_prev", "greasepencil_frame_jump", "PREV_KEYFRAME", False, {"direction": "PREV"}),
                ("gp_jump_next", "greasepencil_frame_jump", "NEXT_KEYFRAME", False, {"direction": "NEXT"}),
                ("gp_setting", "wm.call_panel", "PREFERENCES", False, {"name": "STORYTOOLS_PT_gp_settings_ui"}),
            ),
        }
        for name, controls in groups.items():
            buttons = []
            for key, target, icon, drag, values in controls:
                button = self.gizmos.new("GIZMO_GT_button_2d")
                fn.set_gizmo_settings(button, icon, show_drag=drag)
                operator = target if "." in target else f"storytools.{target}"
                settings = button.target_set_operator(operator)
                for field, value in values.items():
                    setattr(settings, field, value)
                setattr(self, f"gz_{key}", button)
                buttons.append(button)
            setattr(self, name, buttons)

    def draw_prepare(self, context):
        space = context.space_data
        scene = context.scene
        visible = space.show_gizmo and scene.storytools_settings.show_session_toolbar
        for button in self.gizmos:
            button.hide = not visible
        if not visible:
            return

        prefs = get_addon_prefs()
        scale = context.preferences.system.ui_scale
        gap = prefs.toolbar_gap_size
        backdrop = prefs.toolbar_backdrop_size
        separator = gap // 2
        rows = (
            (self.object_gizmos, prefs.object_gz_color),
            (self.camera_gizmos, prefs.camera_gz_color),
            (self.interact_gizmos, prefs.object_gz_color),
        )
        width = context.region.width
        sidebar = next((region.width for region in context.area.regions if region.type == "UI"), 0)
        usable_width = max(width - sidebar, 1)
        span = scale * (gap * (sum(len(items) for items, _ in rows) - 1) + 2 * separator)
        start = min((width - span) * 0.5, usable_width - span - separator)
        if start < separator:
            ratio = usable_width / (usable_width + separator - start)
            start = separator
            backdrop = max(backdrop * ratio, 14)
            gap = max(gap * ratio, 2 * backdrop)
            separator = max(separator * ratio, gap / 2)
        step = scale * gap
        bottom = scale * prefs.toolbar_margin + fn.get_header_margin(context, overlap=False)

        x = start
        for items, rgb in rows:
            for button in items:
                button.scale_basis = backdrop
                button.color = rgb
                button.color_highlight = tuple(value + 0.1 for value in rgb)
                button.matrix_basis = Matrix.Translation((x, bottom, 0))
                x += step
            x += separator

        top = bottom + 2 * backdrop * scale
        show_drawing = context.object is not None and context.object.type == "GREASEPENCIL"
        for index, button in enumerate(self.gpencil_gizmos):
            button.scale_basis = backdrop
            button.hide = not show_drawing
            button.color = prefs.gp_gz_color
            button.color_highlight = tuple(value + 0.1 for value in prefs.gp_gz_color)
            button.matrix_basis = Matrix.Translation((start + (index + 0.5) * step, top, 0))

        options = self.gz_gp_setting
        options.scale_basis = 10
        options.matrix_basis = Matrix.Translation((start - separator / 1.5, top - separator / 3, 0))

        yellow_state = prefs.active_gz_color
        active_highlight = tuple(value + 0.1 for value in yellow_state)
        for active, control in (
            (space.region_3d.lock_rotation, self.gz_lock_view),
            (context.mode == "PAINT_GREASE_PENCIL", self.gz_draw),
        ):
            if active:
                control.color, control.color_highlight = yellow_state, active_highlight
        for active, control in (
            (space.lock_camera, self.gz_lock_cam),
            (scene.tool_settings.use_keyframe_insert_auto, self.gz_autokey),
        ):
            if active:
                control.color, control.color_highlight = (0.5, 0.1, 0.1), (0.7, 0.2, 0.2)


    # def refresh(self, context):
    #     self.gz_lock_cam.icon = 'LOCKVIEW_ON' if context.space_data.lock_camera else 'LOCKVIEW_OFF'
    #     context.area.tag_redraw()


## Toolbar switcher

## Long bar
# x_l = -300
# x_r = 300
# y_d = -4
# y_u = 4

# x_l = -8
# x_r = 8
x_l = -10 # X Left
x_r = 10 # X Right
y_d = -6 # Y Down
y_u = 6 # Y Up

toggler_shape_verts = (
    (x_l, y_d), (x_r, y_d), (x_r, y_u),
    (x_l, y_d), (x_r, y_u), (x_l, y_u),
    ## Square with diagonal in other direction (does not fix the issue)
    # (x_l, y_d), (x_r, y_d), (x_l, y_u),
    # (x_l, y_u), (x_r, y_u), (x_r, y_d),
                )

up_arrow_verts = [
    (4, -1), (0, 3), (0, 2),
    (-4, -2), (0, 2), (-4, -1),
    (4, -1), (0, 2), (4, -2),
    (0, 2), (0, 3), (-4, -1),
]

vertical_flip_mat = fn.get_scale_matrix((1, -1, 1))


class VIEW3D_GT_toggler_shape_widget(Gizmo):
    bl_idname = "VIEW3D_GT_toggler_shape_widget"
    # bl_target_properties = (
    #     {"id": "offset", "type": 'FLOAT', "array_length": 1},
    # )

    __slots__ = (
        "custom_shape",
        "arrow_shape",
        "arrow_batch",
        "init_mouse_x",
        "init_mouse_y",
        "mx",
        "my",
        "replace",
        "init_margin",
        # "init_value",
    )

    # def _update_offset_matrix(self):
    #     # offset behind the light
    #     self.matrix_offset.col[3][2] = self.target_get_value("offset") / -10.0

    def draw(self, context):
        layers = (
            (self.custom_shape, 0.2392, 0.27),
            (self.arrow_shape, 0.5568, 0.5568),
        )
        for shape, normal, highlighted in layers:
            self.color = (normal,) * 3
            self.color_highlight = (highlighted,) * 3
            self.draw_custom_shape(shape)

    # def draw_select(self, context, select_id):
    #     # self.draw_custom_shape(self.custom_shape)
    #     self.draw_custom_shape(self.custom_shape_select, select_id=select_id)
    #     return

    def test_select(self, context, location):
        scale = context.preferences.system.ui_scale
        if scale <= 0:
            return -1
        origin = self.matrix_basis.translation
        local_x = (location[0] - origin.x) / scale
        local_y = (location[1] - origin.y) / scale
        return 1 if x_l < local_x < x_r and y_d < local_y < y_u else -1

    def setup(self):
        if not hasattr(self, "custom_shape"):
            self.custom_shape = self.new_custom_shape('TRIS', toggler_shape_verts)

        if not hasattr(self, "arrow_shape"):
            self.arrow_shape = self.new_custom_shape('TRIS', up_arrow_verts)
        
        ## Keep default full alpha
        # self.alpha = 1.0
        # self.alpha_highlight = 1.0

    def invoke(self, context, event):
        self.mx = self.init_mouse_x = event.mouse_x
        self.my = self.init_mouse_y = event.mouse_y
        self.replace = False
        self.init_margin = get_addon_prefs().toolbar_margin
        # print(event.value, event.type)
        # self.init_value = self.target_get_value("offset")

        # if self.target_set_operator:
        #     context.window_manager.gizmo_operator_context = 'INVOKE_DEFAULT'
        #     return self.target_set_operator.invoke(context, event)

        return {'RUNNING_MODAL'}

    # def execute(self, context):
    #     print('test')
    #     return {'FINISHED'}


    def exit(self, context, cancel):
        if cancel:
            return
        motion = max(abs(self.mx - self.init_mouse_x), abs(self.my - self.init_mouse_y))
        if motion > 10:
            return
        scene_state = context.scene.storytools_settings
        scene_state.show_session_toolbar ^= True
        for region_owner in context.screen.areas:
            if region_owner.type == 'VIEW_3D':
                region_owner.tag_redraw()


    def modal(self, context, event, tweak):
        self.mx = event.mouse_x
        self.my = event.mouse_y

        ## Place when dragged
        # settings = context.scene.storytools_settings
        # offset = self.my - self.init_mouse_y
        # if abs(offset) > 10:
        #     # Trigger placement instead of toggle
        #     self.replace = True

        # if self.replace:
        #     prefs = get_addon_prefs()
        #     if settings.show_session_toolbar:
        #         prefs.toolbar_margin = self.init_margin + offset
        #     else:
        #         prefs.toolbar_margin = offset
        # context.area.tag_redraw()
        ## /


        ## Dragged opts
        # delta = (event.mouse_y - self.init_mouse_y) / 10.0
        # if 'SNAP' in tweak:
        #     delta = round(delta)
        # if 'PRECISE' in tweak:
        #     delta /= 10.0
        # value = self.init_value - delta
        # self.target_set_value("offset", value)
        # context.area.header_text_set("My Gizmo: %.4f" % value)
        return {'RUNNING_MODAL'}

class STORYTOOLS_GGT_toolbar_switch(GizmoGroup):
    # bl_idname = "STORYTOOLS_GGT_toolbar"
    bl_label = "Story Tool Bar Switch"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'} # SHOW_MODAL_ALL ? 
    # bl_options = {'3D', 'PERSISTENT'}

    @classmethod
    def poll(cls, context):
        if not manager_compat.workspace_runtime_allows_context(context):
            return False
        if not context.space_data.show_gizmo:
            return False
        return not fn.is_minimap_viewport(context)

    # @staticmethod
    # def my_target_operator(context):
    #     wm = context.window_manager
    #     op = wm.operators[-1] if wm.operators else None
    #     if isinstance(op, STORYTOOLS_OT_toggle_bottom_bar):
    #         return op
    #     return None

    def setup(self, context):
        button = self.gizmos.new("VIEW3D_GT_toggler_shape_widget")
        button.scale_basis = 1.0
        self.gz_toggle_bar = button

    def draw_prepare(self, context):
        center = context.region.width * 0.5
        bottom = fn.get_header_margin(context, overlap=True)
        bottom += context.preferences.system.ui_scale * 4
        flipped = context.scene.storytools_settings.show_session_toolbar
        transform = Matrix.Translation((center, bottom, 0))
        transform[1][1] = -1.0 if flipped else 1.0
        self.gz_toggle_bar.matrix_basis = transform

    # def refresh(self, context):
    #     pass


class STORYTOOLS_OT_toggle_bottom_bar(Operator):
    bl_idname = "storytools.toggle_bottom_bar"
    bl_label = 'Toggle Bottom Bar'
    bl_description = "Toggle Storytools Bar"
    bl_options = set() # , 'INTERNAL'
    _sms_no_undo = True

    prop_name : bpy.props.StringProperty(default='show_session_toolbar')

    def execute(self, context):
        # print('-- switch toolbar --')
        # print('prop_name: ', self.prop_name)
        settings = context.scene.storytools_settings
        # setattr(settings, self.prop_name, not getattr(settings, self.prop_name))
        settings.show_session_toolbar = not settings.show_session_toolbar
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        return {"FINISHED"}


_TOOLBAR_GIZMO_ENABLED = False
_TOOLBAR_GIZMO_REGISTERED = False


def _register_main_toolbar_classes():
    global _TOOLBAR_GIZMO_REGISTERED
    if _TOOLBAR_GIZMO_REGISTERED:
        return
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            pass
        except Exception:
            continue
    _TOOLBAR_GIZMO_REGISTERED = True
    try:
        bpy.context.scene.storytools_settings.show_session_toolbar = True
    except Exception:
        pass


def _unregister_main_toolbar_classes():
    global _TOOLBAR_GIZMO_REGISTERED
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _TOOLBAR_GIZMO_REGISTERED = False


def enable_main_toolbar_gizmo():
    """Enable the Storytools persistent bottom control-bar gizmo from the central always-on switch."""
    global _TOOLBAR_GIZMO_ENABLED
    _TOOLBAR_GIZMO_ENABLED = True
    _register_main_toolbar_classes()


def disable_main_toolbar_gizmo():
    """Disable the Storytools persistent bottom control-bar gizmo from the central always-on switch."""
    global _TOOLBAR_GIZMO_ENABLED
    _TOOLBAR_GIZMO_ENABLED = False
    _unregister_main_toolbar_classes()

classes=(
    # VIEW3D_GT_button_widget,
    STORYTOOLS_OT_toggle_bottom_bar,
    VIEW3D_GT_toggler_shape_widget,
    STORYTOOLS_GGT_toolbar_switch,
    STORYTOOLS_GGT_toolbar,
)

# These classes belong to an opt-in background feature and are intentionally
# absent while the default ``main_toolbar_gizmo`` option is disabled.
_SMARTTOOLS_OPTIONAL_CLASS_GROUPS = {'main_toolbar_gizmo': classes}

def register():
    disable_main_toolbar_gizmo()

def unregister():
    disable_main_toolbar_gizmo()
