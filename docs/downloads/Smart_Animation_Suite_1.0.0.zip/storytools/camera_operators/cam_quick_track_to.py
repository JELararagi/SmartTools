# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Camera tracking and object-selection operators for StoryTools.

Independently implemented against the Blender public Python API.
"""

import bpy
from bpy.types import Operator
from mathutils import Vector


_TRACK_TYPES = frozenset(("TRACK_TO", "DAMPED_TRACK", "LOCKED_TRACK"))


def _camera_forward(camera):
    """Calculate the world-space direction of a camera's negative local Z axis."""
    return camera.matrix_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))


def _make_target(camera, context):
    """Create one target in the camera's collection, without relying on selection."""
    location = camera.matrix_world.translation.copy()
    direction = _camera_forward(camera)
    focused = context.object
    if focused is not None and focused.type != "CAMERA":
        reference = focused.matrix_world.translation
        distance = (reference - location).dot(direction)
        location += direction * distance
    else:
        location += direction * 5.0

    target = bpy.data.objects.new(f"{camera.name}_target", None)
    target.empty_display_type = "SPHERE"
    target.empty_display_size = 0.25
    target.location = location
    linked = camera.users_collection
    destination = linked[0] if linked else context.scene.collection
    destination.objects.link(target)
    return target


class STORYTOOLS_OT_add_track_to_constraint(Operator):
    bl_idname = "storytools.add_track_to_constraint"
    bl_label = "Add TrackTo constraint"
    bl_description = (
        "Create 'Track-to' constraint on camera, also known as 'Look at'        \n"
        "If an empty is selected, used as target, else create a new empty"
    )
    bl_options = {"UNDO"}

    remove: bpy.props.BoolProperty(
        name="Remove",
        default=False,
        options={"SKIP_SAVE"},
        description="Remove all track to constraint on active camera",
    )

    @classmethod
    def poll(cls, context):
        scene = getattr(context, "scene", None)
        return bool(scene is not None and scene.camera is not None)

    def remove_track_to_constraints(self, camera):
        obsolete = tuple(c for c in camera.constraints if c.type in _TRACK_TYPES)
        for constraint in obsolete:
            camera.constraints.remove(constraint)
        return len(obsolete)

    def execute(self, context):
        camera = context.scene.camera
        if self.remove:
            count = self.remove_track_to_constraints(camera)
            if count:
                message = bpy.app.translations.pgettext(
                    "Removed {} track constraints on camera"
                ).format(count)
                self.report({"INFO"}, message)
            else:
                self.report({"WARNING"}, "No track constraints to remove on camera")
            return {"FINISHED"}

        empties = [obj for obj in context.selected_objects if obj.type == "EMPTY"]
        target = empties[0] if empties else _make_target(camera, context)
        new_constraint = camera.constraints.new(type="DAMPED_TRACK")
        new_constraint.track_axis = "TRACK_NEGATIVE_Z"
        new_constraint.target = target
        obsolete = tuple(
            constraint for constraint in camera.constraints
            if constraint != new_constraint and constraint.type in _TRACK_TYPES
        )
        for constraint in obsolete:
            camera.constraints.remove(constraint)
        if obsolete:
            message = bpy.app.translations.pgettext(
                "Removed {} track constraints on camera"
            ).format(len(obsolete))
            self.report({"INFO"}, message)
        return {"FINISHED"}


class STORYTOOLS_OT_make_active_and_select(Operator):
    bl_idname = "storytools.make_active_and_select"
    bl_label = "Select Passed Object"
    bl_description = "Make active and select an object"
    bl_options = {"INTERNAL", "UNDO"}

    name: bpy.props.StringProperty(
        name="Name", default="", options={"SKIP_SAVE"},
        description="Object name to select in object mode",
    )
    mode: bpy.props.StringProperty(
        name="Mode", default="OBJECT", options={"SKIP_SAVE"},
        description="Mode object should set",
    )

    @classmethod
    def poll(cls, context):
        scene = getattr(context, "scene", None)
        return bool(scene is not None and scene.camera is not None)

    def execute(self, context):
        chosen = context.scene.objects.get(self.name)
        if chosen is None:
            message = bpy.app.translations.pgettext('No "{}" object to select').format(
                self.name
            )
            self.report({"WARNING"}, message)
            return {"CANCELLED"}

        if context.mode != "OBJECT":
            previous = context.object
            was_hidden = bool(previous and previous.hide_viewport)
            if was_hidden:
                previous.hide_viewport = False
            try:
                if not bpy.ops.object.mode_set.poll():
                    self.report({"WARNING"}, "Cannot switch to Object Mode")
                    return {"CANCELLED"}
                bpy.ops.object.mode_set(mode="OBJECT")
            finally:
                if was_hidden:
                    previous.hide_viewport = True

        if context.view_layer.objects.get(chosen.name) is None:
            self.report({"WARNING"}, "Object is outside the current view layer")
            return {"CANCELLED"}
        if chosen.hide_viewport:
            chosen.hide_viewport = False
        if not chosen.visible_get():
            chosen.hide_set(False)
        for item in context.view_layer.objects:
            item.select_set(item == chosen)
        context.view_layer.objects.active = chosen
        return {"FINISHED"}


classes = (
    STORYTOOLS_OT_add_track_to_constraint,
    STORYTOOLS_OT_make_active_and_select,
)


def register():
    for operator_type in classes:
        bpy.utils.register_class(operator_type)


def unregister():
    for operator_type in reversed(classes):
        bpy.utils.unregister_class(operator_type)
