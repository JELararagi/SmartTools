# SPDX-License-Identifier: GPL-3.0-or-later
"""Toggle parenting to the scene camera while preserving the object's world matrix."""

import bpy

from .. import fn


class STORYTOOLS_OT_attach_toggle(bpy.types.Operator):
    bl_idname = "storytools.attach_toggle"
    bl_label = "Attach Toggle"
    bl_description = "Parent or unparent an object to the active camera without moving it"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def execute(self, context):
        obj = context.object
        camera = context.scene.camera
        if obj is None or obj == camera:
            self.report({"ERROR"}, "The active object is the camera" if obj else "No active object")
            return {"CANCELLED"}
        if obj.parent is None or obj.parent == camera:
            world = obj.matrix_world.copy()
            obj.parent = None if obj.parent == camera else camera
            obj.matrix_world = world
        fn.key_object(obj, use_autokey=True)
        return {"FINISHED"}


classes = (STORYTOOLS_OT_attach_toggle,)


def register():
    bpy.utils.register_class(STORYTOOLS_OT_attach_toggle)


def unregister():
    bpy.utils.unregister_class(STORYTOOLS_OT_attach_toggle)
