# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import cam_data, cam_toggle_parent, cam_quick_track_to, cam_create, cam_exclude_filter

modules = (cam_data, cam_toggle_parent, cam_quick_track_to, cam_create, cam_exclude_filter,)
register, unregister = bind(modules)
