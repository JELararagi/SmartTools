# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Camera creation and removal commands for StoryTools.

Independently implemented against the Blender public Python API.
"""

import bpy
from bpy.types import Operator

from .. import fn


def _view_region(context):
    """Return a 3D-view region if the operator was called from a 3D view."""
    space = getattr(context, "space_data", None)
    if getattr(space, "type", None) == "VIEW_3D":
        return getattr(space, "region_3d", None)
    return None


class STORYTOOLS_OT_create_camera(Operator):
    bl_idname = "storytools.create_camera"
    bl_label = "Create Camera"
    bl_description = "Create a camera with popup choices"
    bl_options = {"UNDO"}

    name: bpy.props.StringProperty(
        name="Name", description="Name of Grease pencil object"
    )
    create_marker: bpy.props.BoolProperty(
        name="Create Marker",
        description=(
            "Create a camera timeline marker             \n"
            "Active camera will be changed at this marker"
        ),
        default=False,
        options={"SKIP_SAVE"},
    )
    make_active: bpy.props.BoolProperty(
        name="Make Active", description="Make the new camera active", default=True
    )
    enter_camera: bpy.props.BoolProperty(
        name="Enter Camera", description="Enter in newly created camera view", default=True
    )

    def invoke(self, context, event):
        count = sum(obj.type == "CAMERA" for obj in bpy.data.objects)
        self.name = f"Camera_{count + 1:03d}"
        if any(marker.camera is not None for marker in context.scene.timeline_markers):
            self.create_marker = True
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "name")
        layout.prop(self, "make_active")
        region = _view_region(context)
        if region is not None and region.view_perspective == "CAMERA":
            column = layout.column(align=True)
            column.label(text="Already in camera view")
            column.label(
                text="New camera will be at same place and same focal", icon="BLANK1"
            )
        else:
            line = layout.row()
            line.prop(self, "enter_camera")
        line = layout.row()
        line.prop(self, "create_marker")
        info = line.operator("storytools.info_note", text="", icon="QUESTION")
        info.text = 'This will bind camera to a new marker at current frame            \nA camera-bound marker changes the active camera when playhead is at marker position            \nMarkers behave like keys,they can be selected/renamed/moved/deleted in timeline editors'
        if any(marker.camera is not None for marker in context.scene.timeline_markers):
            layout.label(text="There are camera markers in scene")
        if self.create_marker:
            column = layout.column(align=True)
            column.label(text="Add new marker and bind camera at current frame")

    def execute(self, context):
        scene = context.scene
        region = _view_region(context)
        in_camera_view = region is not None and region.view_perspective == "CAMERA"
        reference = scene.camera if in_camera_view else None

        data = bpy.data.cameras.new(self.name)
        camera = bpy.data.objects.new(self.name, data)
        if reference is not None and reference.type == "CAMERA":
            camera.matrix_world = reference.matrix_world.copy()
            data.lens = reference.data.lens
            data.clip_start = reference.data.clip_start
            data.clip_end = reference.data.clip_end
        elif region is not None:
            camera.matrix_world = region.view_matrix.inverted()

        collection_name = f"cam_{scene.name}"
        collections = scene.collection.children_recursive
        cameras = next((item for item in collections if item.name == collection_name), None)
        if cameras is None:
            cameras = next((item for item in collections
                            if item.get("storytools_camera_collection") == collection_name), None)
        if cameras is None:
            cameras = bpy.data.collections.new(collection_name)
            cameras["storytools_camera_collection"] = collection_name
            scene.collection.children.link(cameras)
        cameras.objects.link(camera)

        if self.make_active:
            scene.camera = camera
            if not in_camera_view and self.enter_camera and region is not None:
                region.view_perspective = "CAMERA"
        if self.create_marker:
            marker = scene.timeline_markers.new(
                name=f"F_{scene.frame_current}", frame=scene.frame_current
            )
            marker.camera = camera

        fn.update_ui_prop_index(context)
        title = bpy.app.translations.pgettext("{} Created").format(camera.name)
        self.report({"INFO"}, title)
        return {"FINISHED"}


class STORYTOOLS_OT_delete_camera(Operator):
    bl_idname = "storytools.delete_camera"
    bl_label = "Delete Camera"
    bl_description = "Delete active camera"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        scene = getattr(context, "scene", None)
        return bool(scene is not None and scene.camera is not None)

    def execute(self, context):
        scene = context.scene
        camera = scene.camera
        removed_name = camera.name
        bpy.data.objects.remove(camera, do_unlink=True)
        replacement = next((obj for obj in scene.objects if obj.type == "CAMERA"), None)
        scene.camera = replacement
        fn.update_ui_prop_index(context)
        message = bpy.app.translations.pgettext('Camera Removed: "{}"').format(
            removed_name
        )
        self.report({"INFO"}, message)
        return {"FINISHED"}


classes = (
    STORYTOOLS_OT_create_camera,
    STORYTOOLS_OT_delete_camera,
)


def register():
    for operator_type in classes:
        bpy.utils.register_class(operator_type)


def unregister():
    for operator_type in reversed(classes):
        bpy.utils.unregister_class(operator_type)
