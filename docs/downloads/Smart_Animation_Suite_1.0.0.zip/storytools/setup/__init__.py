# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import render_static_storyboard, workspace_setup, reset_draw_settings, story_palettes, create_static_storyboard, storyboard_add_pages, storyboard_panel_management, generate_marker_animatic, ui

modules = (workspace_setup, reset_draw_settings, story_palettes, create_static_storyboard, storyboard_add_pages, storyboard_panel_management, generate_marker_animatic, render_static_storyboard, ui,)
register, unregister = bind(modules)
