# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.types import (
    Operator,
    GizmoGroup,
    Gizmo
    )

from mathutils import Matrix, Vector
from gpu_extras.batch import batch_for_shader

from . import fn
from .. import smart_tools_manager_compat as manager_compat


class STORYTOOLS_GGT_toolpreset_bar(GizmoGroup):
    # bl_idname = "STORYTOOLS_GGT_toolbar"
    bl_label = "Story Tool Preset Bar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        if not manager_compat.workspace_runtime_allows_context(context):
            return False
        if not context.space_data.show_gizmo:
            return False
        # return 'GREASEPENCIL' in context.mode and not fn.is_minimap_viewport(context)
        return context.object and context.object.type == 'GREASEPENCIL' and not fn.is_minimap_viewport(context)

    def setup(self, context):

        self.tool_preset_gizmos = []

        ## Object Pan
        user_keymaps = bpy.context.window_manager.keyconfigs.user.keymaps
        
        ## List available icons to use fallback
        # available_icons = [i.identifier for i in bpy.types.UILayout.bl_rna.functions['prop'].parameters['icon'].enum_items]

        ## List all set_draw_tools keymap
        toolpreset_kmis = fn.get_tool_presets_keymap()

        # for km in user_keymaps:
        #     for kmi in reversed(km.keymap_items):
        #         if kmi.idname == 'storytools.set_draw_tool':

        for _km, kmi in toolpreset_kmis:
            props = kmi.properties
            if not kmi.active or not props.show:
                continue
            tool_id = str(getattr(props, 'tool', '') or '').strip()
            mode = str(getattr(props, 'mode', '') or '').strip()
            has_payload = any(str(getattr(props, name, '') or '').strip() for name in ('tool', 'brush', 'layer', 'material'))
            if not has_payload and mode in {'', 'NONE', 'PAINT_GREASE_PENCIL'}:
                continue
            if tool_id in {"''", '""'}:
                continue
            gz = self.gizmos.new("GIZMO_GT_button_2d")
            fn.set_gizmo_settings(gz, icon=props.icon, alpha=0, alpha_highlight=0.6) # , alpha=0.4, alpha_highlight=0.5

            op = gz.target_set_operator("storytools.set_draw_tool")
            op.name = props.name
            # op.mode = props.mode # Default Keymap currently limited to Paint mode
            op.tool = props.tool
            op.layer = props.layer
            op.material = props.material
            op.brush = props.brush
            op.description = props.description
            op.shortcut = kmi.to_string() # Shortcut text for description
            self.tool_preset_gizmos.append(gz)

    def draw_prepare(self, context):
        prefs = fn.get_addon_prefs()
        settings = context.scene.storytools_settings
        
        # icon_size = prefs.toolbar_icon_bounds
        gap_size = prefs.presetbar_gap_size
        backdrop_size = prefs.presetbar_backdrop_size
        
        section_separator = 20
        px_scale = context.preferences.system.ui_scale

        ## Toggle on/off with same session as bottom control bar
        for gz in self.gizmos:
            gz.hide = not settings.show_session_toolbar
        if not settings.show_session_toolbar:
            return
        
        region = context.region
        count = len(self.gizmos)

        ## Using only direct offsetn
        self.bar_width = (count - 1) * (gap_size * px_scale) + (section_separator * 2) * px_scale
        # self.bar_width = (count - 1) * (gap_size * px_scale)
        
        ## Need to set upper margin
        vertical_pos = region.height - (prefs.presetbar_margin * px_scale) - fn.get_header_margin(context, bottom=False, overlap=False)
        left_pos = region.width / 2 - self.bar_width / 2
        next_pos = gap_size * px_scale

        for i, gz in enumerate(self.tool_preset_gizmos):
            gz.scale_basis = backdrop_size
            gz.color = (0.4, 0.4, 0.4)
            gz.color_highlight = (0.5, 0.5, 0.5)

            ## Matrix world is readonly
            gz.matrix_basis = Matrix.Translation((left_pos + (i * next_pos), vertical_pos, 0))


classes=(
    STORYTOOLS_GGT_toolpreset_bar,
)

# The loader must not require this opt-in gizmo class while its default-off
# background option is disabled.
_SMARTTOOLS_OPTIONAL_CLASS_GROUPS = {'tool_preset_gizmo_bar': classes}

_GIZMO_BAR_ENABLED = False
_GIZMO_BAR_REGISTERED = False


def _register_toolpreset_bar_classes():
    global _GIZMO_BAR_REGISTERED
    if _GIZMO_BAR_REGISTERED:
        return
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            pass
        except Exception:
            continue
    _GIZMO_BAR_REGISTERED = True


def _unregister_toolpreset_bar_classes():
    global _GIZMO_BAR_REGISTERED
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _GIZMO_BAR_REGISTERED = False


def enable_toolpreset_bar():
    """Enable the optional Storytools persistent tool preset gizmo bar from the central always-on switch."""
    global _GIZMO_BAR_ENABLED
    _GIZMO_BAR_ENABLED = True
    _register_toolpreset_bar_classes()


def disable_toolpreset_bar():
    """Disable the optional Storytools persistent tool preset gizmo bar from the central always-on switch."""
    global _GIZMO_BAR_ENABLED
    _GIZMO_BAR_ENABLED = False
    _unregister_toolpreset_bar_classes()


def register():
    disable_toolpreset_bar()


def unregister():
    disable_toolpreset_bar()
