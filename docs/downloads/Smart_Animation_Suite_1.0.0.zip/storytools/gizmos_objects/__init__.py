# SPDX-License-Identifier: GPL-3.0-or-later
"""Register Storyboard's object-drag and view-alignment controls."""

from functools import partial

import bpy

from .._registration import Registration, Step
from . import obj_align_with_view, obj_move

modules = (obj_align_with_view, obj_move)
_registration = Registration()


def register():
    steps = (
        Step(partial(bpy.utils.register_class, rna), partial(bpy.utils.unregister_class, rna))
        for section in modules
        for rna in section.classes
    )
    return _registration.start(steps)


def unregister():
    return _registration.stop()
