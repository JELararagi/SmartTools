# SPDX-License-Identifier: GPL-3.0-or-later
"""Own the scale-figure bake operator and reset the disposable drawing overlay."""

from functools import partial

import bpy

from .._registration import Registration, Step
from . import bake_figure, draw_scale_figure

modules = (draw_scale_figure, bake_figure)
_registration = Registration()


def register():
    baker = bake_figure.STORYTOOLS_OT_bake_scale_figure_as_layer
    reset = draw_scale_figure.disable_scale_figure_draw_handler
    return _registration.start((
        Step(reset, reset),
        Step(partial(bpy.utils.register_class, baker), partial(bpy.utils.unregister_class, baker)),
    ))


def unregister():
    return _registration.stop()
