# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Storytools - Storyboard Tools",
    "author": "JELararagi",
    "version": (3, 3, 2),
    "blender": (5, 1, 0),
    "location": "3D View / Dope Sheet",
    "description": "Storyboard-oriented Grease Pencil, camera, and shot setup tools",
    "category": "Animation",
}

import bpy

from . import properties
from . import preferences
from . import setup
from . import gpencil_operators
from . import camera_operators
from . import object_operators
gpencil_ops = gpencil_operators
camera_ops = camera_operators
object_ops = object_operators
from . import gizmos_objects
from . import gizmos_camera
from . import gizmo_toolbar
from . import map
from . import scale_figure
from . import handles
from . import ui
from . import keymaps
from . import gizmo_toolpreset_bar
from .fn import get_addon_prefs

_REGISTERED_MODULES = []

modules = (
    map,
    scale_figure,
    setup,
    properties,
    preferences,
    gpencil_ops,
    camera_ops,
    handles,
    object_ops,
    gizmos_objects,
    gizmos_camera,
    gizmo_toolbar,
    ui,
    keymaps,
    gizmo_toolpreset_bar,
)


def register():
    # Deterministic, no-raise transaction. The Suite loader captures exact
    # identities and marks this lazy tool FAILED if False is returned.
    _REGISTERED_MODULES.clear()
    healthy = True
    for mod in modules:
        try:
            result = mod.register()
        except Exception:
            result = False
        if result is False:
            healthy = False
            break
        _REGISTERED_MODULES.append(mod)
    if not healthy:
        for mod in reversed(tuple(_REGISTERED_MODULES)):
            try:
                mod.unregister()
            except Exception:
                pass
        _REGISTERED_MODULES.clear()
        return False
    try:
        preferences.ui_in_sidebar_update(get_addon_prefs(), bpy.context)
    except Exception:
        # Optional category refresh must never block tool registration.
        pass
    return True


def unregister():
    registered = list(_REGISTERED_MODULES)
    healthy = True
    for mod in reversed(registered):
        try:
            result = mod.unregister()
            if result is False:
                healthy = False
        except Exception:
            healthy = False
    _REGISTERED_MODULES.clear()
    return healthy


if __name__ == "__main__":
    register()
