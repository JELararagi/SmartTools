import bpy
from bpy.props import (StringProperty,
                       IntProperty,
                        BoolProperty,
                        EnumProperty,)
from bpy.types import Context, OperatorProperties
from pathlib import Path
from . import fn

def get_blender_icons_as_enum():
    try:
        enum_items = bpy.types.UILayout.bl_rna.functions['prop'].parameters['icon'].enum_items
        items = tuple((i.identifier, i.name, '') for i in enum_items)
        if items:
            return items
    except Exception:
        pass
    return (
        ('NONE', 'None', ''),
        ('GREASEPENCIL', 'Grease Pencil', ''),
        ('BRUSH_DATA', 'Brush', ''),
        ('MATERIAL', 'Material', ''),
        ('KEY_HLT', 'Key', ''),
    )


def _draw_mode_keymap_name(keyconfig=None):
    candidates = ['Grease Pencil Draw Mode', 'Grease Pencil Paint Mode']
    try:
        keymaps = getattr(keyconfig, 'keymaps', None)
    except Exception:
        keymaps = None
    if keymaps is not None:
        for name in candidates:
            try:
                if keymaps.get(name):
                    return name
            except Exception:
                pass
    return candidates[0] if bpy.app.version >= (5, 1, 0) else candidates[1]


def _safe_kmi_set(kmi, name, value):
    props = getattr(kmi, 'properties', None)
    if props is None:
        return False
    try:
        bl_rna = getattr(props, 'bl_rna', None)
        prop_names = tuple(getattr(getattr(bl_rna, 'properties', None), 'keys', lambda: ())())
        if prop_names and name not in prop_names:
            return False
    except Exception:
        pass
    try:
        setattr(props, name, value)
        return True
    except Exception:
        return False



_EMPTY_TOOL_SENTINELS = {"", "''", '""', 'None', 'none', 'NULL', 'null'}


def _clean_view3d_tool_id(value) -> str:
    """Return a valid-looking workspace tool id or an empty string.

    Older saved keymap/preset data can contain an empty tool id. Passing that
    directly to bpy.ops.wm.tool_set_by_id makes Blender report that tool '' is
    missing from VIEW_3D, so blank values must mean "do not change tool".
    """
    tool_id = str(value or '').strip()
    if tool_id in _EMPTY_TOOL_SENTINELS:
        return ''
    if tool_id.upper() == 'NONE':
        return ''
    return tool_id


def _set_view3d_tool_by_id(tool_id: str) -> bool:
    """Set a VIEW_3D workspace tool only when the id is non-empty.

    Returns False for blank/invalid values instead of forwarding them to
    Blender's wm.tool_set_by_id operator.
    """
    tool_id = _clean_view3d_tool_id(tool_id)
    if not tool_id:
        return False
    try:
        bpy.ops.wm.tool_set_by_id(name=tool_id, space_type='VIEW_3D')
        return True
    except TypeError:
        # Older Blender builds may not expose the space_type keyword.
        try:
            bpy.ops.wm.tool_set_by_id(name=tool_id)
            return True
        except Exception:
            return False
    except Exception:
        return False


class STORYTOOLS_OT_set_draw_tool(bpy.types.Operator):
    bl_idname = "storytools.set_draw_tool"
    bl_label = "Set Draw Tool"
    bl_description = "Tool preset\
        \nChange tool / brush / layer / material to use"
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'GREASEPENCIL'

    name : StringProperty(
        name="Name", description="Name that define this preset (Optional).\
            \nJust for personal organisation",
        default="", options={'SKIP_SAVE'})

    mode : EnumProperty(
        name="Mode", description="Using shortcut will change to this mode",
        default='PAINT_GREASE_PENCIL', options={'HIDDEN', 'SKIP_SAVE'},
        items=(
            ('PAINT_GREASE_PENCIL', 'Draw', 'Switch to draw mode', 0),
            ('EDIT_GREASE_PENCIL', 'Edit', 'Switch to edit mode', 1),
            ('SCULPT_GREASE_PENCIL', 'Sculpt', 'Switch to Sculpt mode', 2),
            ('OBJECT', 'Object', 'Switch to Object mode', 3),
            ('NONE', 'Current', 'No change', 4),
            ))

    tool : StringProperty(
        name="Tool", description="Tool to set\
            \nEmpty field = no change",
        default="", # builtin.brush
        options={'SKIP_SAVE'})

    brush : StringProperty(
        name="Brush", description="Name of Brush to set\
            \nIf it's a User brush, need to enter the relative asset path\
            \nExample: 'Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill'\
            \nEmpty field = no change",
        default="",
        options={'SKIP_SAVE'})

    layer : StringProperty(
        name="Layer", description="Layer to set (exact name, case sensitive)\
            \nEmpty field = no change",
        default="", # Sketch
        options={'SKIP_SAVE'})

    material : StringProperty(
        name="Material", description="Material to set (exact name, case sensitive)\
            \nEmpty field = No change or use layer-material synchronisation if enabled",
        default="", # line
        options={'SKIP_SAVE'})

    ## Interface options
    show : BoolProperty(
        name='Show in UI', description='Show in brushbar',
        default=True,
        )

    icon : EnumProperty(
        name="Icon", description="Icon to display in interface",
        default='GREASEPENCIL',
        items=get_blender_icons_as_enum()
        )

    description : StringProperty(default='', options={'SKIP_SAVE'})

    ## Shortcut text : Internal use only for description
    shortcut : StringProperty(default='',
                            description='For internal use only',
                            options={'SKIP_SAVE', 'HIDDEN'})

    order : IntProperty(default=0, step=1)

    @classmethod
    def description(cls, context, properties):
        """Present the key binding and the values the preset will apply."""
        name, custom, shortcut = properties.name, properties.description, properties.shortcut
        if custom:
            return "\n".join(part for part in (name, custom, shortcut) if part)

        tool = properties.tool.replace("builtin_brush.", "")
        brush = properties.brush.rsplit("/", 1)[-1]
        action = " > ".join(
            f"{label}: {value}" for label, value, present in (
                ("Tool", tool, properties.tool),
                ("Brush", brush, properties.brush),
            ) if present
        )
        drawing = ", ".join(
            f"{label}: {value}" for label, value in (
                ("Layer", properties.layer),
                ("Material", properties.material),
            ) if value
        )
        lines = [name or "Tool Preset", ""]
        lines.extend(part for part in (action, drawing) if part)
        if shortcut:
            lines += ["", f"Shortcut: {shortcut}"]
        return "\n".join(lines)

    def execute(self, context):
        ## Mode needs to add shortcut to generic Gpencil (would conflict with Selection mask)
        # if self.mode != 'NONE' and context.mode != self.mode:
        #     bpy.ops.object.mode_set(mode=self.mode)

        prop_names = ('brush', 'layer', 'material')
        tool_id = _clean_view3d_tool_id(self.tool)
        has_payload = bool(tool_id or any(getattr(self, prop_name) for prop_name in prop_names))
        if not has_payload and self.mode in {'NONE', 'PAINT_GREASE_PENCIL'}:
            message = [
                'This Storytools keymap has no settings yet',
                'Customize or disable this keymap from the Smart Animation N-panel controls.',
                ]
            fn.show_message_box(message, 'Keymap not set', 'ERROR')
            return {"CANCELLED"}

        ob = context.object

        # Mode change (Need context aware shortcut protection to work well with other modes)...
        if self.mode != 'NONE':
            bpy.ops.object.mode_set(mode=self.mode)

        if tool_id:
            if not _set_view3d_tool_by_id(tool_id):
                self.report({'ERROR'}, bpy.app.translations.pgettext('Cannot set tool {}, need identifier (ex: "builtin.brush")').format(tool_id))
                return {"CANCELLED"}

        if '/' in self.brush:
            ## if the brush name is a path,  always Consider that this is a custom user brush to use with asset_activate
            try:
                bpy.ops.brush.asset_activate(asset_library_type='CUSTOM',
                    asset_library_identifier="User Library",
                    relative_asset_identifier=self.brush)
            except Exception as e:
                pass  # Console-silent bundled-tool diagnostic.
                self.report({'ERROR'}, bpy.app.translations.pgettext('Cannot load {}, need to be an asset path, ex: "Saved/Brushes/CustomFill.asset.blend/Brush/CustomFill"').format(self.brush))
                return {"CANCELLED"}

        elif self.brush:
            ## check if brush exists in essential library.
            # brush_exists = False
            # essential_brush_lib = Path(bpy.utils.resource_path('LOCAL')) / 'datafiles' / 'assets' / 'brushes' / 'essentials_brushes-gp_draw.blend'
            # with bpy.data.libraries.load(str(essential_brush_lib), assets_only=True, link=False) as (data_from, data_to):
            #     if self.brush in data_from.brushes:
            #         brush_exists = True
            try:
                bpy.ops.brush.asset_activate(asset_library_type='ESSENTIALS',
                    asset_library_identifier="",
                    relative_asset_identifier=f"brushes/essentials_brushes-gp_draw.blend/Brush/{self.brush}")
            except Exception as e:
                pass  # Console-silent bundled-tool diagnostic.
                self.report({'WARNING'}, bpy.app.translations.pgettext('Could not find brush named {}').format(self.brush))

        if self.layer:
            if self.material:
                # if material name is specified, prevent material sync on this layer change msg_bus update (avoid override)
                bpy.context.window_manager["skip_layer_sync_flag"] = True
            fn.set_layer_by_name(ob, self.layer)

        if self.material:
            # if material name is specified, prevent material pairing on this material change msg_bus update (avoid unwated pairing)
            bpy.context.window_manager["skip_material_sync_flag"] = True
            fn.set_material_by_name(ob, self.material)

        return {"FINISHED"}

'''
## Hardcoded shortcuts, Keymap only set preset number (behavior defined in ops)
class STORYTOOLS_OT_set_draw_tool(bpy.types.Operator):
    bl_idname = "storytools.set_draw_tool"
    bl_label = "Set Draw Tool"
    bl_description = "Set a draw tool, configuring brush / layer / material tool"
    bl_options = {"REGISTER", "INTERNAL"}

    # path_to_pal : bpy.props.StringProperty(name="paht to palette", description="path to the palette", default="")
    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'GREASEPENCIL'

    preset : bpy.props.IntProperty(name='Preset number', default=1, options={'SKIP_SAVE'})

    def execute(self, context):
        # if context.mode != 'OBJECT':
        #     bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')

        presets = {
            1: {'tool': 'builtin.brush', 'layer':'Sketch', 'mat': 'line'},
            2: {'tool': 'builtin_brush.Fill', 'layer':'Color', 'mat': 'fill_white'},
            3: {'tool': 'builtin.brush', 'layer':'Color', 'mat': 'fill_white'},
            4: {'tool': 'builtin_brush.Erase'},
        }

        preset_d = presets[self.preset]

        ob = context.object
        if 'tool' in preset_d.keys() and preset_d['tool']:
            bpy.ops.wm.tool_set_by_id(name=preset_d['tool'])
        if 'layer' in preset_d.keys() and preset_d['layer']:
            fn.set_layer_by_name(ob, preset_d['layer'])

        ## Material not forced for now, Already changed by layer synchro
        # if 'mat' in preset_d.keys() and preset_d['mat']:
        #     fn.set_material_by_name(ob, preset_d['mat'])

        return {"FINISHED"}
'''


addon_keymaps = []

def register_keymap():
    wm = getattr(bpy.context, 'window_manager', None)
    addon = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
    if addon is None:
        return
    draw_mode_name = _draw_mode_keymap_name(addon)
    km = addon.keymaps.new(name=draw_mode_name, space_type="EMPTY")
    '''
    ## Hardcoded
    numbers = ['ZERO', 'ONE', 'TWO', 'THREE', 'FOUR']
    for i, number in enumerate(numbers):
        if i == 0:
            continue
        kmi = km.keymap_items.new('storytools.set_draw_tool', type=number, value='PRESS')
        kmi.properties.preset=i
        addon_keymaps.append((km, kmi))
    '''

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='ONE', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Sketch Draw')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin.brush')
    _safe_kmi_set(kmi, 'brush', 'Pencil')
    _safe_kmi_set(kmi, 'layer', 'Sketch')
    # kmi.properties.material = '' # line
    # kmi.properties.icon = 'GPBRUSH_PEN'
    _safe_kmi_set(kmi, 'icon', 'GREASEPENCIL')
    _safe_kmi_set(kmi, 'order', 10)
    # kmi.properties.description = 'Set Pencil brush on "Sketch" layer'
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='TWO', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Line Draw')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin.brush')
    _safe_kmi_set(kmi, 'brush', 'Ink Pen')
    _safe_kmi_set(kmi, 'layer', 'Line')
    _safe_kmi_set(kmi, 'icon', 'LINE_DATA')
    _safe_kmi_set(kmi, 'order', 20)
    # kmi.properties.description = 'Set Ink Brush on "Line" layer'
    # kmi.properties.material = '' # line
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='THREE', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Bucket Fill')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin_brush.Fill')
    _safe_kmi_set(kmi, 'brush', 'Fill')
    _safe_kmi_set(kmi, 'layer', 'Color')
    # kmi.properties.material = '' # fill_white
    _safe_kmi_set(kmi, 'icon', 'SHADING_SOLID')
    _safe_kmi_set(kmi, 'order', 30)
    # kmi.properties.description = 'Set Fill tool on "Color" layer'
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='FOUR', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Fill Draw')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin.brush')
    _safe_kmi_set(kmi, 'layer', 'Color')
    _safe_kmi_set(kmi, 'icon', 'NODE_MATERIAL')
    _safe_kmi_set(kmi, 'order', 40)
    # kmi.properties.description = 'Set draw tool "Color" layer'
    # kmi.properties.material = '' # fill_white
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='FIVE', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Eraser by points')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin_brush.Erase')
    _safe_kmi_set(kmi, 'brush', 'Eraser Hard')
    _safe_kmi_set(kmi, 'icon', 'CLIPUV_DEHLT')
    _safe_kmi_set(kmi, 'order', 50)
    # kmi.properties.description = 'Set Point Eraser'
    addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='SIX', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Eraser by strokes')
    _safe_kmi_set(kmi, 'mode', 'PAINT_GREASE_PENCIL')
    _safe_kmi_set(kmi, 'tool', 'builtin_brush.Erase')
    _safe_kmi_set(kmi, 'brush', 'Eraser Stroke')
    _safe_kmi_set(kmi, 'icon', 'CON_TRACKTO')
    _safe_kmi_set(kmi, 'order', 60)
    # kmi.properties.description = 'Set Stroke Eraser'
    addon_keymaps.append((km, kmi))

    # kmi = km.keymap_items.new('storytools.set_draw_tool', type='SEVEN', value='PRESS')
    # addon_keymaps.append((km, kmi))

    kmi = km.keymap_items.new('storytools.set_draw_tool', type='SEVEN', value='PRESS')
    _safe_kmi_set(kmi, 'name', 'Annotate')
    _safe_kmi_set(kmi, 'tool', 'builtin.brush')
    _safe_kmi_set(kmi, 'layer', 'Annotate')
    _safe_kmi_set(kmi, 'material', 'line_red') # Sync override material
    _safe_kmi_set(kmi, 'order', 70)
    _safe_kmi_set(kmi, 'icon', 'SYNTAX_ON') # CURRENT_FILE, TEXT
    addon_keymaps.append((km, kmi))


def enable_draw_tool_hotkeys():
    """Enable Storytools draw-tool number hotkeys from the central always-on switch."""
    unregister_keymap()
    register_keymap()


def disable_draw_tool_hotkeys():
    """Disable Storytools draw-tool number hotkeys from the central always-on switch."""
    unregister_keymap()

def unregister_keymap():
    for km, kmi in list(addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()

def register():
    bpy.utils.register_class(STORYTOOLS_OT_set_draw_tool)
    disable_draw_tool_hotkeys()

def unregister():
    disable_draw_tool_hotkeys()
    bpy.utils.unregister_class(STORYTOOLS_OT_set_draw_tool)
