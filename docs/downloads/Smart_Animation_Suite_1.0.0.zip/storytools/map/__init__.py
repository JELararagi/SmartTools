# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import handler_draw_map, map_operators, map_roll, map_place_gp, gizmo_map_toolbar

map_ops = map_operators
modules = (handler_draw_map, map_operators, map_roll, map_place_gp, gizmo_map_toolbar,)
register, unregister = bind(modules)
