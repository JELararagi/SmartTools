import bpy
from bpy.app.handlers import persistent
from .constants import LAYERMAT_PREFIX
from .fn import get_addon_prefs, set_material_by_name

_BACKGROUND_ENABLED = False
_MSGBUS_OWNER = object()


def _append_load_post_once(handler):
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    if handler not in load_post:
        load_post.append(handler)



def _remove_load_post(handler):
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None)
    if load_post is None:
        return
    if handler in load_post:
        try:
            load_post.remove(handler)
        except Exception:
            pass





def get_object_and_scene():
    context = bpy.context
    preferred = (context.scene, context.object)
    windows = context.window_manager.windows if context.window_manager else ()
    candidates = (preferred, *((w.scene, w.view_layer.objects.active) for w in windows))
    for scene, obj in candidates:
        if scene is not None and obj is not None and obj.type == "GREASEPENCIL" and obj.data.layers.active is not None:
            return scene, obj
    return None, None


def layer_change_callback():
    if not _BACKGROUND_ENABLED:
        return

    ## Disable Sync when sidebar is not visible ?
    ## TODO: Add the settings also in material settings panel to keep sync when panel is disabled
    if not get_addon_prefs().show_sidebar_ui:
        return

    scn, ob = get_object_and_scene()
    if scn is None or ob is None:
        return

    wm = bpy.context.window_manager
    if wm.get("skip_layer_sync_flag"):
        del wm["skip_layer_sync_flag"]
        return

    mode = scn.storytools_settings.material_sync
    if mode == 'DISABLED':
        return

    ## FIXME store the material name in the layer custom property now that it's possible ?
    ## Maybe it's better to keep at object level to avoid sync issue using global mode..
    if mode == 'INDIVIDUAL':
        key_name = LAYERMAT_PREFIX + ob.data.layers.active.name
        if key_name in ob.keys():
            set_material_by_name(ob, ob[key_name])
    else:
        if not hasattr(scn, 'gp_mat_by_layer'):
            return
        set_material_by_name(ob, scn.gp_mat_by_layer.get(ob.data.layers.active.name))


def subscribe_layer():
    if not _BACKGROUND_ENABLED:
        return None
    subscribe_to = (bpy.types.GreasePencilv3Layers, "active") # Still named "v3", API may change later
    bpy.msgbus.subscribe_rna(
        key=subscribe_to,
        owner=_MSGBUS_OWNER,
        args=(),
        notify=layer_change_callback,
        options={'PERSISTENT'},
    )
    return None


@persistent
def subscribe_layer_handler(dummy):
    if not _BACKGROUND_ENABLED:
        return
    subscribe_layer()


## material callback
def material_change_callback():
    if not _BACKGROUND_ENABLED:
        return

    ## Disable Sync when sidebar is not visible
    ## TODO: add the settings also in material settings panel to keep sync when panel is disabled
    if not get_addon_prefs().show_sidebar_ui:
        return

    scn, ob = get_object_and_scene()
    if scn is None or ob is None:
        return
    if not ob.active_material:
        return

    wm = bpy.context.window_manager
    if wm.get("skip_material_sync_flag"):
        del wm["skip_material_sync_flag"]
        return

    mode = scn.storytools_settings.material_sync
    if mode == 'DISABLED':
        return

    if mode == 'INDIVIDUAL':
        ob[LAYERMAT_PREFIX + ob.data.layers.active.name] = ob.active_material.name
        all_keys = [k for k in ob.keys() if k.startswith(LAYERMAT_PREFIX)]
        for k in all_keys:
            if k.split(LAYERMAT_PREFIX)[1] not in [l.name for l in ob.data.layers]:
                del ob[k]
    else: # GLOBAL
        if not hasattr(scn, 'gp_mat_by_layer'):
            bpy.types.Scene.gp_mat_by_layer = {}

        layer_dict = scn.gp_mat_by_layer
        layer_dict[ob.data.layers.active.name] = ob.active_material.name


def subscribe_material():
    if not _BACKGROUND_ENABLED:
        return None
    subscribe_to = (bpy.types.Object, "active_material_index")
    bpy.msgbus.subscribe_rna(
        key=subscribe_to,
        owner=_MSGBUS_OWNER,
        args=(),
        notify=material_change_callback,
        options={'PERSISTENT'},
    )
    return None


@persistent
def subscribe_material_handler(dummy):
    if not _BACKGROUND_ENABLED:
        return
    subscribe_material()


def enable_background_callbacks():
    global _BACKGROUND_ENABLED
    _BACKGROUND_ENABLED = True
    _append_load_post_once(subscribe_layer_handler)
    _append_load_post_once(subscribe_material_handler)
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    subscribe_layer()
    subscribe_material()
    return True



def disable_background_callbacks():
    global _BACKGROUND_ENABLED
    _BACKGROUND_ENABLED = False
    _remove_load_post(subscribe_material_handler)
    _remove_load_post(subscribe_layer_handler)
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    return True



def register():
    disable_background_callbacks()
    return True



def unregister():
    disable_background_callbacks()
    return True
