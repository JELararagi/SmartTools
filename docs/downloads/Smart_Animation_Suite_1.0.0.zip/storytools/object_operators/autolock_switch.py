"""Set Blender's automatic keyframe insertion for the selected scene scope."""
import bpy


class STORYTOOLS_OT_autokey_switch(bpy.types.Operator):
    bl_idname = 'storytools.autokey_switch'
    bl_label = 'Autokey Toggle'
    bl_description = 'Toggle autokey (in all scenes)'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    all_scene: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        current_scene = context.scene
        enabled = not current_scene.tool_settings.use_keyframe_insert_auto
        if self.all_scene:
            for scene in bpy.data.scenes:
                scene.tool_settings.use_keyframe_insert_auto = enabled
        else:
            current_scene.tool_settings.use_keyframe_insert_auto = enabled

        active_area = context.area
        if active_area is not None:
            active_area.tag_redraw()
        if context.screen is not None:
            for editor in context.screen.areas:
                if editor.type == 'DOPESHEET_EDITOR' and editor != active_area:
                    editor.tag_redraw()
        return {'FINISHED'}


classes = (STORYTOOLS_OT_autokey_switch,)


def register():
    bpy.utils.register_class(STORYTOOLS_OT_autokey_switch)


def unregister():
    bpy.utils.unregister_class(STORYTOOLS_OT_autokey_switch)
