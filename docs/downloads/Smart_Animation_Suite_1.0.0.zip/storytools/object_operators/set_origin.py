# SPDX-License-Identifier: GPL-3.0-or-later
"""Position the object's origin at its lowest world-space bound."""

import bpy
from mathutils import Vector


class STORYTOOLS_OT_set_origin_bottom(bpy.types.Operator):
    bl_idname = "storytools.set_origin_bottom"
    bl_label = "Set Origin To Bottom"
    bl_description = "Set the origin of the selected Grease Pencil object to its bottom"
    bl_options = {"UNDO"}

    def invoke(self, context, event):
        animation = getattr(context.object, "animation_data", None)
        if animation is not None and animation.action is not None:
            return context.window_manager.invoke_confirm(
                self, event, title=self.bl_label, confirm_text="Set Origin Anyway", icon="ERROR",
                message="This object has animation data. Changing its origin may affect the animation.",
            )
        return self.execute(context)

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {"CANCELLED"}
        world = obj.matrix_world
        anchor = world.translation.copy()
        anchor.z = min((world @ Vector(corner)).z for corner in obj.bound_box)
        cursor = context.scene.cursor
        original = cursor.location.copy()
        try:
            cursor.location = anchor
            return bpy.ops.object.origin_set(type="ORIGIN_CURSOR", center="MEDIAN")
        finally:
            cursor.location = original


classes = (STORYTOOLS_OT_set_origin_bottom,)


def register():
    bpy.utils.register_class(STORYTOOLS_OT_set_origin_bottom)


def unregister():
    bpy.utils.unregister_class(STORYTOOLS_OT_set_origin_bottom)
