# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import obj_actions, autolock_switch, snap_cursor, set_origin, material_management

modules = (obj_actions, autolock_switch, snap_cursor, set_origin, material_management,)
register, unregister = bind(modules)
