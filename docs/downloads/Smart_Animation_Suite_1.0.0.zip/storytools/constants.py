# SPDX-License-Identifier: GPL-3.0-or-later
"""Resolve storyboard resources inside the installed suite."""

from pathlib import Path


LAYERMAT_PREFIX = "mat--"
MODULE_DIR = Path(__file__).parent
RESOURCES_DIR = MODULE_DIR.joinpath("resources")
FONT_DIR, PRESETS_DIR, IMAGES_DIR = (RESOURCES_DIR / folder for folder in ("fonts", "presets", "images"))
