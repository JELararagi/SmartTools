# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import frame_new, frame_jump, ui

modules = (frame_new, frame_jump, ui,)
register, unregister = bind(modules)
