# SPDX-License-Identifier: GPL-3.0-or-later
"""Present Grease Pencil frame and layer settings in the animation suite."""

import bpy

from .. import fn


class STORYTOOLS_PT_gp_settings_ui(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Animation"
    bl_label = "Grease pencil options"
    bl_options = {"INSTANCED"}

    def draw(self, context):
        self.layout.use_property_decorate = False
        column = self.layout.column()
        note = column.row().operator("storytools.info_note", text="Grease Pencil", emboss=False)
        note.title = note.text = ""
        settings = context.scene.storytools_gp_settings
        for heading, name, label in (
            ("Frame Settings:", "frame_offset", "Frame Offset"),
            ("Target Layers:", "frame_target_layers", ""),
            ("Keyframe Type:", "keyframe_type", ""),
            ("Sync Settings:", "sync_mode", ""),
        ):
            column.separator()
            column.label(text=heading)
            column.prop(settings, name, text=label)


classes = (STORYTOOLS_PT_gp_settings_ui,)


def register():
    bpy.utils.register_class(STORYTOOLS_PT_gp_settings_ui)
    fn.hide_view3d_sidebar_panel(STORYTOOLS_PT_gp_settings_ui)


def unregister():
    bpy.utils.unregister_class(STORYTOOLS_PT_gp_settings_ui)
