# SPDX-License-Identifier: GPL-3.0-or-later
"""Storyboard section registration."""

from .._section_lifecycle import bind
from . import cam_move, view_locked_pan, cam_dolly

modules = (cam_move, view_locked_pan, cam_dolly,)
register, unregister = bind(modules)
