# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Resolve the workspace owner to the installed extension package."""


def addon_owner_id():
    package = (__package__ or "").strip()
    if package:
        return package
    owner, _, _ = (__name__ or "").strip().rpartition(".")
    return owner or "smart_node_suite"
