# Smart Node 1.0.0

Open the sidebar with N in a node editor in Blender 5.1.2 and choose Smart Node.
See the accompanying guide for creating, arranging and wiring nodes.

Blender 5.1.2 のノードエディターで N キーを押し、Smart Node タブを開きます。
ノードの追加・整列・接続の手順は同梱の解説書をご覧ください。
