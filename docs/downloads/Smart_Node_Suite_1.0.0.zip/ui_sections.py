# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

try:
    import bpy
except Exception:  # pragma: no cover
    bpy = None

try:
    from .i18n import t as _t
except Exception:  # pragma: no cover
    def _t(en, ja=None):
        return ja if ja is not None else en


class _NoOpOperator:
    pass


class _NoOpLayout:
    def __init__(self):
        self.enabled = False
        self.active = False
        self.alert = False
        self.alignment = 'LEFT'
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.use_property_split = False
        self.use_property_decorate = False

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NoOpOperator()

    def __getattr__(self, _name):
        def _noop(*args, **kwargs):
            return self
        return _noop


_NOOP_LAYOUT = _NoOpLayout()


def _prop_name(key: str) -> str:
    clean = ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(key or '')).strip('_')
    return 'smart_node_suite_migrated_group_' + (clean or 'group')


def _state(context, key: str, default_open: bool) -> bool:
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            return bool(wm.get(_prop_name(key), default_open))
    except Exception:
        pass
    return bool(default_open)


def draw_group(layout, context, key: str, label: str, *, icon: str = 'NONE', topic: str | None = None, default_open: bool = True,
               expanded: bool | None = None, toggle_idname: str = 'smart_node_suite.toggle_migrated_group',
               heading_icon: str = 'NONE', translate: bool = False, with_body: bool = True):
    """The one top-level heading: arrow button, borderless title, separator, help."""
    del icon
    if expanded is None:
        expanded = _state(context, key, default_open)
    row = layout.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    if bpy is not None:
        try:
            op = row.operator(toggle_idname, text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True, depress=bool(expanded))
            op.key = key
            title_op = row.operator(toggle_idname, text=label, icon=heading_icon, emboss=False, depress=bool(expanded), translate=translate)
            title_op.key = key
            try:
                row.separator(factor=0.35)
            except Exception:
                pass
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_op = help_row.operator('smart_node_suite.section_help', text='', icon='QUESTION', emboss=True)
            help_op.key = str(topic or key)
        except Exception:
            row.label(text=label, icon='DOWNARROW_HLT' if expanded else 'RIGHTARROW', translate=False)
    if not with_body:
        return row, None, bool(expanded)
    if not expanded:
        return row, _NOOP_LAYOUT, False
    body = layout.column(align=True)
    return row, body, True
