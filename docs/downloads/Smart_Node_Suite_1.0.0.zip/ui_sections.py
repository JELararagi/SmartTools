# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Present optional sections without drawing their contents while collapsed."""

from __future__ import annotations

from types import SimpleNamespace

try:
    import bpy
except ImportError:
    bpy = None


class _CollapsedLayout:
    enabled = False
    active = False
    alert = False
    alignment = "LEFT"
    scale_x = 1.0
    scale_y = 1.0
    use_property_split = False
    use_property_decorate = False

    def row(self, *args, **kwargs):
        return self

    column = box = split = grid_flow = row

    def operator(self, *args, **kwargs):
        return SimpleNamespace()

    def __getattr__(self, name):
        return self.row


_COLLAPSED = _CollapsedLayout()


def _prop_name(key: str):
    normalized = "".join(c.lower() if c.isalnum() else "_" for c in str(key or "")).strip("_")
    return f"smart_node_suite_migrated_group_{normalized or 'group'}"


def _state(context, key: str, default_open: bool):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        try:
            return bool(window_manager.get(_prop_name(key), default_open))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    return bool(default_open)


def draw_group(layout, context, key: str, label: str, *, icon: str = "NONE",
               topic: str | None = None, default_open: bool = True):
    expanded = _state(context, key, default_open)
    arrow = "DOWNARROW_HLT" if expanded else "RIGHTARROW"
    header = layout.row(align=True)
    header.use_property_split = False
    header.use_property_decorate = False
    if bpy is not None:
        try:
            toggle = header.operator("smart_node_suite.toggle_migrated_group",
                                     text=label, icon=arrow, emboss=False, translate=False)
            toggle.key = key
        except (AttributeError, RuntimeError, TypeError, ValueError):
            header.label(text=label, icon=arrow, translate=False)
    body = layout.column(align=True) if expanded else _COLLAPSED
    return header, body, expanded
