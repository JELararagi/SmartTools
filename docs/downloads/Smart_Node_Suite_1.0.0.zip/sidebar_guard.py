# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Read the suite's UI registration without changing workspace state."""
from .unified_contract import ROOT_PANEL_IDS as _ROOT_PANEL_IDS


def _smart_node_panel_registered():
    try:
        from bpy import types
        return all(hasattr(types, name) for name in _ROOT_PANEL_IDS)
    except Exception:
        return False


def _addon_owner_ids():
    return tuple(dict.fromkeys((__package__ or "smart_node_suite", "smart_node_suite")))


def ensure_workspace_owner_filters():
    return 0


def _iter_visible_node_editor_ui_regions(context=None):
    return iter(())


def _region_is_drawn(region):
    return False


def _sidebar_is_visible(space, region):
    return False


def _set_active_category(region, category):
    return False


def refresh_smart_node_sidebars(context=None, *, force_if_active=True, activate_category=False):
    return 0


def register():
    return None


unregister = register
