# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import bpy

_OWNER = __package__ or __name__


def _locale() -> str:
    try:
        return str(getattr(bpy.app.translations, 'locale', '') or '')
    except Exception:
        return ''


def is_japanese_locale() -> bool:
    loc = _locale().lower().replace('-', '_')
    return loc.startswith('ja')


_JA = {
    # Brand / panel labels intentionally stay as the requested product name.
    'Smart Node Suite': 'Smart Node Suite',
    'Smart Node': 'Smart Node',
    'Node': 'ノード',
    'Node Editor > Sidebar (N) > Smart Node or Shift-W': 'ノードエディター > サイドバー (N) > Smart Node または Shift-W',
    'Smart Node tools for node creation, wiring, labels, layout, branch selection, and node-tree management.': 'ノード作成、配線、ラベル、レイアウト、ブランチ選択、ノードツリー管理のための Smart Node ツール。',
    'Smart Node Suite (Menu)': 'Smart Node Suite メニュー',
    'Smart Node Section Help': 'Smart Node セクションヘルプ',
    'Toggle Smart Node Section': 'Smart Node セクション切替',
    'Quick Access: Shift+W': 'クイックアクセス: Shift+W',

    # Section labels.
    'Overview': '概要',
    'Merge / Composite Nodes': '結合 / 合成ノード',
    'Texture Setup': 'テクスチャ設定',
    'Links / Reroutes': 'リンク / リルート',
    'Labels / Batch': 'ラベル / 一括変更',
    'Layout / Arrange': 'レイアウト / 整列',
    'Selection / Branches': '選択 / ブランチ',
    'Node Management': 'ノード管理',
    'No editable node tree is open.': '編集可能なノードツリーが開かれていません。',
    'Shader node tree only': 'シェーダーノードツリー専用です',

    'Node Editor View': 'ノードエディター表示',
    'Node Editor View Settings': 'ノードエディター表示設定',
    'Apply View Settings': '表示設定を適用',
    'Read Current Settings': '現在設定を読み込み',
    'Reset to Blender Default': 'Blender 初期値へリセット',
    'Soft Grid Preset': 'ソフトグリッドプリセット',
    'Strong Grid Preset': '強調グリッドプリセット',
    'Technical Preset': '技術表示プリセット',
    'Apply': '適用',
    'Read Current': '現在値を読み込み',
    'Reset': 'リセット',
    'Soft': 'ソフト',
    'Strong': '強調',
    'Technical': '技術表示',
    'Grid Color': 'グリッドカラー',
    'Background Color': '背景色',
    'Grid Levels': 'グリッドレベル',
    'Advanced View Colors': '詳細表示カラー',
    'Show Advanced View Colors': '詳細表示カラーを表示',
    'Node Backdrop Color': 'ノード背景色',
    'Wire Color': 'ワイヤカラー',
    'Selected Wire Color': '選択ワイヤカラー',
    'Selected Node Color': '選択ノードカラー',
    'Active Node Color': 'アクティブノードカラー',
    'Noodle Curving': 'リンク曲線',
    'Dash Alpha': '破線アルファ',
    'Major Grid Layout Spacing': '太いグリッド基準のレイアウト間隔',
    'Use Major Grid Spacing': '太いグリッド間隔を使用',
    'Major Grid Unit': '太いグリッド単位',
    'Column Major Dots': '列の太い点数',
    'Row Major Dots': '行の太い点数',
    'Minimum Bounds Gap Dots': '最小空き太点数',
    'Spacing Reference': '距離基準',
    'Snap Result to Major Grid': '結果を太いグリッドへスナップ',
    'Left/Top Edge with Size Guard': '左/上端 + サイズ保護',
    'Gap Between Node Bounds': 'ノード境界間の隙間',
    'Use Major Grid Unit': '太いグリッド単位を使用',
    'Smart Node Suite preferences were not found.': 'Smart Node Suite 設定が見つかりません。',
    'Read current node-editor view settings.': '現在のノードエディター表示設定を読み込みました。',
    'Could not read node-editor theme settings.': 'ノードエディターテーマ設定を読み込めませんでした。',
    'Applied node-editor view settings.': 'ノードエディター表示設定を適用しました。',
    'Could not apply node-editor theme settings.': 'ノードエディターテーマ設定を適用できませんでした。',

    # Common menu/operator labels.
    'Merge Selected Nodes': '選択ノードを結合',
    'Use Shaders': 'シェーダーを使用',
    'Use Geometry Nodes': 'ジオメトリノードを使用',
    'Use Math Nodes': '数式ノードを使用',
    'Use Mix Nodes': 'ミックスノードを使用',
    'Use Depth Combine Nodes': '深度合成ノードを使用',
    'Use Alpha Over Nodes': 'アルファオーバーノードを使用',
    'Merge Selected Nodes using Geometry Nodes': 'ジオメトリノードで選択ノードを結合',
    'Merge Selected Nodes using Shaders': 'シェーダーで選択ノードを結合',
    'Merge Selected Nodes using Mix': 'ミックスで選択ノードを結合',
    'Merge Selected Nodes using Math': '数式で選択ノードを結合',
    'Batch Change Selected Nodes': '選択ノードを一括変更',
    'Batch Change Blend Type': 'ブレンドタイプを一括変更',
    'Batch Change Math Operation': '数式演算を一括変更',
    'Copy to Selected': '選択ノードへコピー',
    'Copy Label': 'ラベルをコピー',
    'From Active Node\'s Label': 'アクティブノードのラベルから',
    'From Linked Node\'s Label': 'リンク元ノードのラベルから',
    'From Linked Output\'s Name': 'リンク元出力名から',
    'Add Reroutes': 'リルートを追加',
    'To All Outputs': 'すべての出力へ',
    'To Loose Outputs': '未接続の出力へ',
    'To Linked Outputs': '接続済みの出力へ',
    'Link Active to Selected': 'アクティブから選択へリンク',
    'To All Selected': 'すべての選択ノードへ',
    'Do Not Replace Links': '既存リンクを置換しない',
    'Replace Links': '既存リンクを置換',
    'Use Node Name/Label': 'ノード名 / ラベルを使用',
    'Use Output Names': '出力名を使用',
    'Attributes': '属性',
    'No attributes on objects with this material': 'このマテリアルを持つオブジェクトに属性がありません',
    'Select Frame Children': 'フレーム内ノードを選択',
    'Select Parent Frame': '親フレームを選択',
    'Multiple Images': '複数画像',
    'Image Sequence': '画像シーケンス',
    'Reset Nodes in Frame': 'フレーム内ノードをリセット',
    'Reset Node': 'ノードをリセット',

    'Add Attribute': '属性を追加',
    'Actions': '操作',
    'Grid': 'グリッド',
    'Node Arrange': 'ノード整列',
    'Import Sequence': '連番画像を読込',
    'Add Textures': 'テクスチャを追加',
    'Import Image Sequence': '画像シーケンスを読み込み',
    'Add Principled Texture Setup': 'Principled テクスチャ設定を追加',
    'Add Texture Setup': 'テクスチャ設定を追加',
    'Detach Outputs': '出力を切り離し',
    'Swap Links': 'リンクを入れ替え',
    'Connect to Output': '出力へ接続',
    'Clear Label': 'ラベルをクリア',
    'Modify Labels': 'ラベルを変更',
    'Batch Change': '一括変更',
    'Settings from Active': 'アクティブ設定から',
    'Reset Backdrop': '背景をリセット',
    'Reload Images': '画像を再読み込み',
    'Delete Unused Nodes': '未使用ノードを削除',
    'Align Nodes': 'ノード整列',
    'Center Nodes': 'ノードを中央へ',
    'Change Factor': '係数を変更',
    'Copy Settings': '設定をコピー',
    'Lazy Connect': '簡単コネクト',
    'Lazy Connect with Socket Menu': 'ソケットメニュー付き簡単コネクト',
    'Lazy Mix': '簡単ミックス',
    'Link Active Node to Selected': 'アクティブノードを選択ノードへリンク',
    'Merge Nodes': 'ノードを結合',
    'Reset Nodes': 'ノードをリセット',
    'Save Viewer Image': 'ビューアー画像を保存',
    'Select Parent or Children': '親または子を選択',
    'Make Link': 'リンクを作成',
    'Frame Selected Nodes': '選択ノードをフレーム化',

    # New layout and management labels.
    'Lay Out Children': '子を整列',
    'Lay Out All': 'すべて整列',
    'Smart Hierarchy Layout': '階層整列',
    'Align Node Edges': 'ノード端を整列',
    'Distribute Nodes': 'ノードを均等配置',
    'Snap Nodes to Grid': 'ノードをグリッドへスナップ',
    'Frame Branch': 'ブランチをフレーム化',
    'Collapse / Expand Nodes': 'ノードを折りたたみ / 展開',
    'Mute / Unmute Nodes': 'ノードをミュート / 解除',
    'Select Linked Branch': 'リンクブランチを選択',
    'Select Terminal Nodes': '端点ノードを選択',
    'Select Same Type': '同タイプを選択',
    'Create Backdrop Frame': '背景フレームを作成',
    'Frame Upstream': '上流まで囲む',
    'Frame Downstream': '下流まで囲む',
    'Frame Connected': '接続全体を囲む',
    'Smart Node Frame': 'Smart Node フレーム',
    'These nodes are already in one frame.': 'これらのノードはすでに 1 つのフレームに入っています。',
    'Left': '左',
    'Center X': '中央X',
    'Right': '右',
    'Top': '上',
    'Center Y': '中央Y',
    'Bottom': '下',
    'Horizontal': '水平',
    'Vertical': '垂直',
    'Selected': '選択中',
    'All': 'すべて',
    'Upstream': '上流',
    'Downstream': '下流',
    'Connected': '接続全体',
    'Both': '両方向',
    'Sources': 'ソース',
    'Sinks': '終端',
    'Collapse': '折りたたむ',
    'Expand': '展開',
    'Toggle': '切替',
    'Mute': 'ミュート',
    'Unmute': 'ミュート解除',
    'Layer Spacing': '階層間隔',
    'Node Spacing': 'ノード間隔',
    'Keep Center': '中心を維持',
    'Direction': '方向',
    'Scope': '対象範囲',
    'Spacing': '間隔',
    'Grid Size': 'グリッドサイズ',
    'Only Selected': '選択ノードのみ',
    'Frame Label': 'フレームラベル',
    'Margin': '余白',
    'Columns': '列数',
    'X Spacing': 'X 間隔',
    'Y Spacing': 'Y 間隔',
    'Select Nodes by Text': '文字でノードを選択',
    'Select by Text': '文字で選択',
    'Search Text': '検索文字',
    'Target': '対象',
    'Name / Label': '名前 / ラベル',
    'Node Type': 'ノードタイプ',
    'Sockets': 'ソケット',
    'All Text Fields': 'すべての文字フィールド',
    'Match Case': '大文字小文字を区別',
    'Select Nodes by State': '状態でノードを選択',
    'State': '状態',
    'Unconnected': '未接続',
    'Collapsed': '折りたたみ',
    'Framed': 'フレーム内',
    'Unframed': 'フレーム外',
    'Inside Frames': 'フレーム内',
    'Outside Frames': 'フレーム外',
    'Reroutes': 'リルート',
    'Rename Selected Nodes': '選択ノードをリネーム',
    'New Name': '新規名',
    'Prefix': '接頭辞',
    'Suffix': '接尾辞',
    'Find': '検索',
    'Replace': '置換',
    'Add Numbering': '連番を追加',
    'Start Index': '開始番号',
    'Digits': '桁数',
    'Rename Visible Label': '表示ラベルもリネーム',

    'Pin Parent': '親を固定',
    'Color Nodes': 'ノード色を適用',
    'Apply Color': '色を適用',
    'Reset Color': '色をリセット',
    'Color': '色',
    'No nodes are available for color changes.': '色変更できるノードがありません。',
    'Updated color on {count} nodes.': '{count} 個のノード色を更新しました。',

    # Preferences.
    'Hide Mix Nodes': 'ミックスノードを隠す',
    'Mix Node Position': 'ミックスノード位置',
    'Show Hotkey List': 'ホットキー一覧を表示',
    'Hide Hotkey List': 'ホットキー一覧を隠す',
    'Show Principled Naming Tags': 'Principled 命名タグを表示',
    'Edit tags for auto texture detection in Principled BSDF setup': 'Principled BSDF 設定の自動テクスチャ検出タグを編集',
    'Base Color': 'ベースカラー',
    'Metallic': 'メタリック',
    'Specular': 'スペキュラー',
    'Normal': 'ノーマル',
    'Bump': 'バンプ',
    'Roughness': 'ラフネス',
    'Gloss': 'グロス',
    'Displacement': 'ディスプレイスメント',
    'Transmission': '透過',
    'Emission': '発光',
    'Alpha': 'アルファ',
    'Ambient Occlusion': 'アンビエントオクルージョン',
    'Arrange Selected Nodes': '選択ノードを整列',
    'Sort Nodes': 'ノードをソート',
    'Sort All': 'すべてソート',
    'Sort Horizontally': '水平にソート',
    'Sort Vertically': '垂直にソート',
    'Sort H': '水平ソート',
    'Sort V': '垂直ソート',
    'Mode': 'モード',
    'Select at least two nodes to arrange.': '整列するノードを2つ以上選択してください。',
    'Arranged {count} selected nodes.': '選択ノードを {count} 個整列しました。',
    'Select at least two nodes to sort.': 'ソートするノードを2つ以上選択してください。',
    'Sorted {count} nodes.': '{count} 個のノードをソートしました。',
}



_JA.update({
    'Always': '常に',
    'Never': 'しない',
    '        Filter by Name': '        名前で絞り込み',
    'Filter by Name': '名前で絞り込み',
    'Left to Right': '左から右',
    'Right to Left': '右から左',
    'Top to Bottom': '上から下',
    'Bottom to Top': '下から上',
    'Distribute Node Grid': 'ノードをグリッド配置',
    'Quick Align': 'クイック整列',
    'Current Tree': '現在のツリー',
    'Nodes': 'ノード数',
    'Smart Node Drawing State': 'Smart Node 描画状態',

    'Merge Nodes (Automatic)': 'ノード結合（自動）',
    'Merge Nodes (Add)': 'ノード結合（加算）',
    'Merge Nodes (Multiply)': 'ノード結合（乗算）',
    'Merge Nodes (Subtract)': 'ノード結合（減算）',
    'Merge Nodes (Divide)': 'ノード結合（除算）',
    'Merge Nodes (Less Than)': 'ノード結合（小なり）',
    'Merge Nodes (Greater Than)': 'ノード結合（大なり）',
    'Merge Nodes (Depth Combine)': 'ノード結合（深度合成）',
    'Merge Nodes (Alpha Over)': 'ノード結合（アルファオーバー）',
    'Merge Nodes (Color, Add)': 'ノード結合（カラー加算）',
    'Merge Nodes (Color, Multiply)': 'ノード結合（カラー乗算）',
    'Merge Nodes (Color, Subtract)': 'ノード結合（カラー減算）',
    'Merge Nodes (Color, Divide)': 'ノード結合（カラー除算）',
    'Merge Nodes (Math, Add)': 'ノード結合（数式加算）',
    'Merge Nodes (Math, Multiply)': 'ノード結合（数式乗算）',
    'Merge Nodes (Math, Subtract)': 'ノード結合（数式減算）',
    'Merge Nodes (Math, Divide)': 'ノード結合（数式除算）',
    'Merge Nodes (Math, Less than)': 'ノード結合（数式小なり）',
    'Merge Nodes (Math, Greater than)': 'ノード結合（数式大なり）',
    'Batch Change Blend Type (Mix)': 'ブレンドタイプを一括変更（ミックス）',
    'Batch Change Blend Type (Add)': 'ブレンドタイプを一括変更（加算）',
    'Batch Change Blend Type (Multiply)': 'ブレンドタイプを一括変更（乗算）',
    'Batch Change Blend Type (Subtract)': 'ブレンドタイプを一括変更（減算）',
    'Batch Change Blend Type (Divide)': 'ブレンドタイプを一括変更（除算）',
    'Batch Change Blend Type (Current)': 'ブレンドタイプを一括変更（現在）',
    'Batch Change Blend Type (Next)': 'ブレンドタイプを一括変更（次）',
    'Batch Change Blend Type (Previous)': 'ブレンドタイプを一括変更（前）',
    "Link Active to Selected (Don't Replace Links)": 'アクティブを選択へリンク（既存リンクを置換しない）',
    'Link Active to Selected (Replace Links)': 'アクティブを選択へリンク（既存リンクを置換）',
    "Link Active to Selected (Don't Replace Links, Node Names)": 'アクティブを選択へリンク（ノード名、置換なし）',
    'Link Active to Selected (Replace Links, Node Names)': 'アクティブを選択へリンク（ノード名、置換）',
    "Link Active to Selected (Don't Replace Links, Output Names)": 'アクティブを選択へリンク（出力名、置換なし）',
    'Link Active to Selected (Replace Links, Output Names)': 'アクティブを選択へリンク（出力名、置換）',
    'Reduce Mix Factor by 0.1': 'ミックス係数を0.1下げる',
    'Increase Mix Factor by 0.1': 'ミックス係数を0.1上げる',
    'Reduce Mix Factor by 0.01': 'ミックス係数を0.01下げる',
    'Increase Mix Factor by 0.01': 'ミックス係数を0.01上げる',
    'Set Mix Factor to 0.0': 'ミックス係数を0.0に設定',
    'Mix Factor to 1.0': 'ミックス係数を1.0に設定',
    'Enter search text before selecting nodes.': 'ノード選択前に検索文字を入力してください。',
    'Selected {count} matching nodes.': '一致したノードを {count} 個選択しました。',
    'Selected {count} nodes by state.': '状態に一致するノードを {count} 個選択しました。',
    'Select nodes before renaming.': 'リネームするノードを選択してください。',
    'Enter the text to change.': '変更する文字を入力してください。',
    'Renamed {count} selected nodes.': '選択ノードを {count} 個リネームしました。',
    'Clear Node Labels': 'ノードラベルをクリア',
    'Modify Node Labels': 'ノードラベルを変更',
    'Copy label from active to selected': 'アクティブから選択へラベルをコピー',
    'Link to Output Node': '出力ノードへリンク',
    'Select Children': '子を選択',
    'Select Parent': '親を選択',
    'Reset Backdrop Image Zoom': '背景画像ズームをリセット',
    'Add Reroutes (Menu)': 'リルート追加（メニュー）',
    'Link Active to Selected (Menu)': 'アクティブから選択へリンク（メニュー）',
    'Copy to Selected (Menu)': '選択へコピー（メニュー）',
})

_JA.update({
    'Move Linked Branch': 'リンクブランチを移動',
    'Stream-Aware Align': 'ストリーム整列',
    'Stack Nodes': 'ノードを積む',
    'Swap Positions': '位置交換',
    'Optimize Link Reroutes': 'リルート最適化',
    'Hide / Show Child Tree': '子ツリー 表示/非表示',
    'Hide / Show Unused Sockets': '未使用ソケット 表示/非表示',
    'Bypass Delete Selected': 'バイパス削除',
    'Free From Frame': 'フレームから外す',
    'Select Objects Using Material': 'マテリアル使用オブジェクトを選択',
    'Show': '表示',
    'Inputs': '入力',
    'Outputs': '出力',
    'Style': 'スタイル',
    'Extend Selection': '選択を拡張',
    'Select at least one seed node.': '起点ノードを1つ以上選択してください。',
    'No nodes are available to move.': '移動できるノードがありません。',
    'Moved {count} nodes.': '{count} 個のノードを移動しました。',
    'Select a parent node first.': '先に親ノードを選択してください。',
    'No child nodes were found.': '子ノードが見つかりません。',
    'Updated child tree display for {count} nodes.': '{count} 個の子ノード表示を更新しました。',
    'No unused sockets were found.': '未使用ソケットが見つかりません。',
    'Updated {count} unused sockets.': '{count} 個の未使用ソケットを更新しました。',
    'Select exactly two nodes to swap positions.': '位置を交換するノードをちょうど2つ選択してください。',
    'Select at least two nodes to align.': '整列するには2つ以上のノードを選択してください。',
    'Stream-aligned {count} nodes.': '{count} 個のノードをストリーム単位で整列しました。',
    'Select at least two nodes to stack.': '積み直すには2つ以上のノードを選択してください。',
    'No links are available for reroute optimization.': 'リルート最適化できるリンクがありません。',
    'Added {count} reroute nodes.': '{count} 個のリルートノードを追加しました。',
    'Select nodes before bypass delete.': 'バイパス削除するノードを選択してください。',
    'Bypass-deleted {count} nodes.': '{count} 個のノードをバイパス削除しました。',
    'No selected framed nodes were found.': '選択中のフレーム内ノードが見つかりません。',
    'Freed {count} nodes from frames.': '{count} 個のノードをフレームから外しました。',
    'No edited material was found.': '編集中のマテリアルが見つかりません。',
    'Selected {count} material users.': '{count} 個のマテリアル使用オブジェクトを選択しました。',
})

_JA.update({
    # Labels not covered by Blender's native ja catalog (verified 5.1.2).
    'Toggle Smart Node Tool Group': 'Smart Node ツールグループ切替',
    'Show Socket Menu': 'ソケットメニューを表示',
    'Lazy Connect source node is no longer available.': '簡単コネクトのソースノードが利用できなくなりました。',
    'Lazy Connect socket state is no longer available.': '簡単コネクトのソケット状態が利用できなくなりました。',
    'Replace Existing Links': '既存リンクを置換',
    'N-panel State Save': 'Nパネル状態保存',
    'Always-on Toggles': '常時機能切り替え',

    # Operator labels shown in menus, search and the hotkey list.
    'Mix Nodes': 'ノードをミックス',
    'Refresh Material Attributes': 'マテリアル属性を更新',
    'Swap Node Positions': '位置交換',

    # Enum items.
    'Alpha Over Node': 'アルファオーバーノード',
    'Auto': '自動',
    'Between Selected': '選択の間',
    'Center': '中心',
    'Depth Combine Node': '深度合成ノード',
    'From Active': 'アクティブから',
    'From Node': 'ノードから',
    'From Socket': 'ソケットから',
    'Geometry': 'ジオメトリ',
    'Hide': '隠す',
    'Math Node': '数式ノード',
    'Midpoint': '中間点',
    'Mix Node': 'ミックスノード',
    'Muted': 'ミュート済み',
    'Non-Shader': 'シェーダー以外',
    'Shader': 'シェーダー',
    'To All': 'すべてへ',
    'To Linked': '接続済みへ',
    'To Loose': '未接続へ',
    'Touch Selected': '選択に接するもの',
    'Two Point': '2 点',

    # Property names.
    'Action': '動作',
    'Add Mapping Nodes': 'マッピングノードを追加',
    'Add to Beginning': '先頭に追加',
    'Add to End': '末尾に追加',
    'Attribute Name': '属性名',
    'Blend Type': 'ブレンドタイプ',
    'Delete Empty Frames': '空のフレームを削除',
    'Delete Muted': 'ミュートを削除',
    'Directory': 'フォルダー',
    'Factor Change': '係数の変更量',
    'File Name': 'ファイル名',
    'File Path': 'ファイルパス',
    'Format': '形式',
    'Group Key': 'グループキー',
    'Immediate Clear': 'すぐに消去',
    'Include Frames': 'フレームも含める',
    'Include Hidden': '非表示も含める',
    'Include Parent': '親も含める',
    'Legacy Proxy Cleanup': '旧プロキシ整理',
    'Match by Node Name': 'ノード名で合わせる',
    'Match by Output Name': '出力名で合わせる',
    'Merge Type': '結合の種類',
    'Node Preset Folder': 'ノードプリセットフォルダー',
    'Operation': '演算',
    'Option': 'オプション',
    'Precise Color Pie Key': '詳細カラーパイキー',
    'Precise Pie Alt': '詳細パイ Alt',
    'Precise Pie Ctrl': '詳細パイ Ctrl',
    'Precise Pie Shift': '詳細パイ Shift',
    'Quick Color Pie Key': '簡易カラーパイキー',
    'Quick Pie Alt': '簡易パイ Alt',
    'Quick Pie Ctrl': '簡易パイ Ctrl',
    'Quick Pie Shift': '簡易パイ Shift',
    'Relative Path': '相対パス',
    'Replace with': '置換後の文字',
    'Section Key': 'セクションキー',
    'Skip Existing Reroutes': '既存のリルートを除く',
    'Smart Node Lazy Source': 'Smart Node 簡単コネクト接続元',
    'Smart Node Lazy Target': 'Smart Node 簡単コネクト接続先',
    'Smart Node Source Socket': 'Smart Node 接続元ソケット',
    'Source Socket Index': '接続元ソケット番号',
    'Stack': '積む',
    'Start Frame': '開始フレーム',
    'Target Socket Index': '接続先ソケット番号',
    'Text to Replace': '置換する文字',
    'Use Active Node Axis': 'アクティブノードの軸を使う',
    'X Offset': 'X オフセット',
    'Y Offset': 'Y オフセット',

    # Reasons shown when a button cannot be pressed.
    'Current editor is not a node editor.': '今のエディターはノードエディターではありません。',
    'Current node has no visible outputs.': 'このノードには表示されている出力がありません。',
    'Current node tree does not contain any nodes.': 'このノードツリーにはノードがありません。',
    'Current node tree is linked from another .blend file.': 'このノードツリーは別の .blend ファイルからリンクされています。',
    'Lazy Connect source and target nodes are not available.': '接続元と接続先のノードがありません。',
    'No active node.': 'アクティブノードがありません。',
    'No node tree was found in the current node editor.': 'このノードエディターにノードツリーがありません。',
    'Smart Node is disabled in the current workspace.': 'このワークスペースでは Smart Node が無効です。',
    'Viewer image not found.': 'ビューアー画像が見つかりません。',
    "This operator does not work on the active node's type.": 'アクティブノードの種類では使えません。',
    'At least one node must be selected.': 'ノードを 1 つ以上選択してください。',
    'At least {:d} nodes must be selected.': 'ノードを {:d} つ以上選択してください。',
    'This command does not work in this type of node tree.': 'このノードツリーの種類では使えません。',
    '{:d} nodes are selected, but this operator can only work on {:d}.': '{:d} 個のノードが選択されています。この操作は {:d} 個までです。',
})

_JA.update({
    # Enum-item and property tooltips (auto-translated at display time).
    'Arrange selected nodes only. If nothing is selected, all nodes are arranged.': '選択ノードのみ整列します。何も選択されていない場合はすべてのノードを整列します。',
    'Arrange every node in the edited node tree.': '編集中のノードツリー内のすべてのノードを整列します。',
    'Arrange selected nodes and all input/dependency nodes feeding them.': '選択ノードと、それらへ入力する依存ノードすべてを整列します。',
    'Arrange selected nodes and all output/dependent nodes after them.': '選択ノードと、その後段の出力/従属ノードすべてを整列します。',
    'Arrange the full connected component around the selected or active nodes.': '選択またはアクティブノード周辺の接続成分全体を整列します。',
    'Treat input/dependency nodes as children. This is usually best for Blender shader graphs.': '入力/依存ノードを子として扱います。通常は Blender のシェーダーグラフに最適です。',
    'Treat output/dependent nodes as children.': '出力/従属ノードを子として扱います。',
    'Arrange both input and output branches around the selected parent.': '選択した親の周囲で入力と出力の両ブランチを整列します。',
    'Arrange nodes into dependency-aware rows and columns.': '依存関係を考慮した行と列にノードを整列します。',
    'Redistribute nodes evenly on the X axis without changing their Y positions.': 'Y位置を変えずにX軸方向へノードを均等に再配置します。',
    'Redistribute nodes evenly on the Y axis without changing their X positions.': 'X位置を変えずにY軸方向へノードを均等に再配置します。',
    'Sort selected nodes; if nothing is selected, sort all nodes.': '選択ノードをソートします。何も選択されていない場合はすべてのノードをソートします。',
    'Sort every node in the edited node tree.': '編集中のノードツリー内のすべてのノードをソートします。',
    'Sort the connected branch around the current selection or active node.': '現在の選択またはアクティブノード周辺の接続ブランチをソートします。',
    'Align the left edge of selected nodes to the leftmost selected node.': '選択ノードの左端を最も左の選択ノードへ揃えます。',
    'Align horizontal centers to the selected bounding-box center.': '水平中心を選択範囲のバウンディングボックス中心へ揃えます。',
    'Align the right edge of selected nodes to the rightmost selected node.': '選択ノードの右端を最も右の選択ノードへ揃えます。',
    'Align top edges to the highest selected node.': '上端を最も上の選択ノードへ揃えます。',
    'Align vertical centers to the selected bounding-box center.': '垂直中心を選択範囲のバウンディングボックス中心へ揃えます。',
    'Align bottom edges to the lowest selected node.': '下端を最も下の選択ノードへ揃えます。',
    'Distribute selected nodes from left to right.': '選択ノードを左から右へ均等配置します。',
    'Distribute selected nodes from top to bottom.': '選択ノードを上から下へ均等配置します。',
    'Select input/dependency nodes.': '入力/依存ノードを選択します。',
    'Select output/dependent nodes.': '出力/従属ノードを選択します。',
    'Select the full connected branch.': '接続ブランチ全体を選択します。',
    'Select nodes that have no incoming links.': '入力リンクを持たないノードを選択します。',
    'Select nodes that have no outgoing links.': '出力リンクを持たないノードを選択します。',
    'Select both source and sink nodes.': 'ソースノードと終端ノードの両方を選択します。',
    'Frame selected nodes only.': '選択ノードのみフレーム化します。',
    'Frame selected nodes and upstream dependencies.': '選択ノードと上流の依存ノードをフレーム化します。',
    'Frame selected nodes and downstream dependents.': '選択ノードと下流の従属ノードをフレーム化します。',
    'Frame the entire connected branch.': '接続ブランチ全体をフレーム化します。',
    'Collapse selected nodes.': '選択ノードを折りたたみます。',
    'Expand selected nodes.': '選択ノードを展開します。',
    'Toggle collapsed state for selected nodes.': '選択ノードの折りたたみ状態を切り替えます。',
    'Mute selected nodes.': '選択ノードをミュートします。',
    'Unmute selected nodes.': '選択ノードのミュートを解除します。',
    'Toggle mute state for selected nodes.': '選択ノードのミュート状態を切り替えます。',
    'Search node names, labels, and the names shown in node headers.': 'ノード名、ラベル、ノードの見出しの名前を検索します。',
    'Search the internal English type name, such as math or bsdf.': 'math や bsdf などの、内部の英語の種類名を検索します。',
    'Search input and output socket names.': '入力/出力ソケット名を検索します。',
    'Search names, labels, types, and socket names.': '名前、ラベル、タイプ、ソケット名を検索します。',
    'Select nodes with no incoming or outgoing links.': '入力リンクも出力リンクもないノードを選択します。',
    'Select muted nodes.': 'ミュート中のノードを選択します。',
    'Select collapsed node cards.': '折りたたまれたノードカードを選択します。',
    'Select nodes that have a parent frame.': '親フレームを持つノードを選択します。',
    'Select nodes that do not have a parent frame.': '親フレームを持たないノードを選択します。',
    'Select reroute nodes.': 'リルートノードを選択します。',
    'Move selected nodes only.': '選択ノードのみ移動します。',
    'Move selected nodes and input/dependency nodes feeding them.': '選択ノードと、それらへ入力する依存ノードを移動します。',
    'Move selected nodes and output/dependent nodes after them.': '選択ノードと、その後段の出力/従属ノードを移動します。',
    'Move the full connected branch around the selection.': '選択周辺の接続ブランチ全体を移動します。',
    'Hide/collapse child branch nodes.': '子ブランチノードを非表示/折りたたみます。',
    'Show/expand child branch nodes.': '子ブランチノードを表示/展開します。',
    'Toggle child branch visibility.': '子ブランチの表示状態を切り替えます。',
    'Treat input/dependency nodes as children.': '入力/依存ノードを子として扱います。',
    'Process the whole connected branch.': '接続ブランチ全体を処理します。',
    'Hide unused sockets.': '未使用ソケットを非表示にします。',
    'Show unused sockets.': '未使用ソケットを表示します。',
    'Toggle unused sockets.': '未使用ソケットの表示を切り替えます。',
    'Apply the chosen custom color to the target nodes.': '選択したカスタム色を対象ノードへ適用します。',
    'Disable custom colors on the target nodes so Blender displays the default node type colors.': '対象ノードのカスタム色を無効化し、Blender 標準のノードタイプ色で表示します。',
    'Change selected nodes only. If nothing is selected, all nodes are changed.': '選択ノードのみ変更します。何も選択されていない場合はすべてのノードを変更します。',
    'Change the linked branch around the selected or active seed node.': '選択またはアクティブな起点ノード周辺のリンクブランチを変更します。',
    'Change every node in the edited node tree.': '編集中のノードツリー内のすべてのノードを変更します。',
    'Use nodes that feed into the selected seed.': '選択した起点へ入力するノードを使用します。',
    'Use nodes driven by the selected seed.': '選択した起点から駆動されるノードを使用します。',
    'Use all connected nodes around the seed.': '起点周辺の接続ノードすべてを使用します。',
    'Align left edges inside each stream.': '各ストリーム内で左端を揃えます。',
    'Align horizontal centers inside each stream.': '各ストリーム内で水平中心を揃えます。',
    'Align right edges inside each stream.': '各ストリーム内で右端を揃えます。',
    'Align top edges inside each stream.': '各ストリーム内で上端を揃えます。',
    'Align vertical centers inside each stream.': '各ストリーム内で垂直中心を揃えます。',
    'Align bottom edges inside each stream.': '各ストリーム内で下端を揃えます。',
    'Stack from top to bottom.': '上から下へ積みます。',
    'Stack from left to right.': '左から右へ積みます。',
    'Process links touching selected nodes; if nothing is selected, process all links.': '選択ノードに接するリンクを処理します。何も選択されていない場合はすべてのリンクを処理します。',
    'Process only links whose source and target are both selected.': 'ソースとターゲットの両方が選択されているリンクのみ処理します。',
    'Process every link in the edited node tree.': '編集中のノードツリー内のすべてのリンクを処理します。',
    'Create two reroutes to make a clearer elbow-style path.': 'リルートを2つ作成し、見やすいエルボー型経路にします。',
    'Create one reroute at the middle of the link.': 'リンク中央にリルートを1つ作成します。',
    'Apply the panel values to the active Blender theme.': 'パネルの値をアクティブな Blender テーマへ適用します。',
    'Copy the active Blender theme values into the Smart Node panel fields.': 'アクティブな Blender テーマの値を Smart Node パネルの欄へ読み込みます。',
    'Restore the stored panel values to Blender default node-editor colors and apply them.': '保存されたパネル値を Blender 初期のノードエディター色へ戻して適用します。',
    'Apply a subdued grid preset for long material editing sessions.': '長時間のマテリアル編集向けの控えめなグリッドプリセットを適用します。',
    'Apply a high-contrast grid preset for precise alignment work.': '正確な整列作業向けの高コントラストグリッドプリセットを適用します。',
    'Apply a straighter, technical-diagram style preset.': 'より直線的な技術図面スタイルのプリセットを適用します。',
    'Function: saves Smart Node settings and section states to one schema-validated JSON file. How to use: enable for immediate atomic saving; disable to defer writes until the add-on is disabled or Blender closes normally.': '機能: Smart Node の設定とセクション状態をスキーマ検証付きの1つのJSONファイルへ保存します。使い方: 有効にすると即時アトミック保存を行い、無効にするとアドオン無効化または Blender の正常終了まで書き込みを遅延します。',
    'Function: makes the Run Legacy Cleanup Once button available. Turning this on does not scan or change the current file. How to use: enable this option, then click the button before saving normally in Blender.': '機能: 「旧プロキシ整理を1回実行」のボタンを使えるようにします。有効にするだけでは、現在のファイルを調べたり変えたりしません。使い方: 有効にしてから、Blender で保存する前にこのボタンを押します。',
    'Function: opens or closes the Always-on Toggles section at the top of the Smart Node N-panel. How to use: click its section header; the setting is saved by N-panel State Save.': '機能: Smart Node Nパネル上部の「常時機能切り替え」セクションを開閉します。使い方: セクション見出しをクリックします。この設定はNパネル状態保存で保存されます。',
    'Use major-dot distance between left/top edges, but expand automatically when node dimensions would overlap.': '左/上端間の太点距離を使用し、ノード寸法が重なる場合は自動的に間隔を広げます。',
    'Use major-dot distance as the empty gap between node bounds, adding node width or height automatically.': '太点距離をノード境界間の空きとして使用し、ノードの幅または高さを自動的に加算します。',
})

_TRANSLATIONS = {
    'ja_JP': {},
}

# While classes are defined and registered, labels and tooltips are stored in
# English and their Japanese goes into the table above: Blender translates them
# when it draws, so they follow a language change without a restart.
_definition_phase = True


def begin_definitions() -> None:
    global _definition_phase
    _definition_phase = True


def end_definitions() -> None:
    global _definition_phase
    _definition_phase = False


def _build_translations() -> None:
    table = _TRANSLATIONS['ja_JP']
    table.clear()
    for _en, _ja in _JA.items():
        for _ctx in ('*', 'Operator', 'Menu', 'Panel', 'Property', 'UI Interface', 'UI Tooltips'):
            table[(_ctx, _en)] = _ja


_build_translations()


def _clean(text) -> str:
    return str(text or '').replace('　', ' ')


def table_ja(en: str) -> str:
    return _JA.get(str(en), str(en))


def t(en: str, ja: str | None = None) -> str:
    if _definition_phase:
        text = _clean(en)
        if text and ja:
            _JA.setdefault(text, _clean(ja))
        return text
    if is_japanese_locale():
        value = ja if ja is not None else _JA.get(str(en), str(en))
    else:
        value = str(en)
    return _clean(value)


def tip(en: str, ja: str | None = None) -> str:
    return t(en, ja)


def register() -> None:
    _build_translations()
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_OWNER, _TRANSLATIONS)
    except Exception:
        pass


def unregister() -> None:
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass
