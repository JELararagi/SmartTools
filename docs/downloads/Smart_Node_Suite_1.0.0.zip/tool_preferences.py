# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Adapter between tools and the suite's registered preferences."""

from __future__ import annotations

import bpy

from .unified_contract import EXTENSION_ID

_RUNTIME_VALUES: dict[str, object] = {}


def _identifier(value):
    return "".join(character.lower() if character.isalnum() else "_"
                   for character in str(value or "")).strip("_")


def prop_name(alias: str, field: str):
    return f"integrated_{_identifier(alias)}_{_identifier(field)}"


def addon_preferences(context=None):
    context = context or bpy.context
    if context is None:
        return None
    try:
        addons = context.preferences.addons
    except AttributeError:
        return None
    for module_name in dict.fromkeys((__package__, EXTENSION_ID)):
        try:
            return addons[module_name].preferences
        except (KeyError, AttributeError, ReferenceError, TypeError):
            continue
    return None


def _has_rna_property(data, name: str):
    if data is None or not name:
        return False
    properties = getattr(getattr(data, "bl_rna", None), "properties", None)
    if properties is None:
        return False
    try:
        return properties.get(name) is not None
    except (AttributeError, RuntimeError, TypeError):
        try:
            return name in properties.keys()
        except (AttributeError, RuntimeError, TypeError):
            return False


def tool_value(alias: str, field: str, *, context=None, default=None):
    key = prop_name(alias, field)
    preferences = addon_preferences(context)
    if _has_rna_property(preferences, key):
        try:
            return getattr(preferences, key)
        except (AttributeError, RuntimeError, TypeError):
            pass
    return _RUNTIME_VALUES.get(key, default)


def set_tool_value(alias: str, field: str, value, *, context=None):
    from . import persistent_settings

    key = prop_name(alias, field)
    preferences = addon_preferences(context)
    if _has_rna_property(preferences, key):
        try:
            setattr(preferences, key, value)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    _RUNTIME_VALUES[key] = value
    if not persistent_settings.is_applying():
        try:
            persistent_settings.request_save(context, force=False)
        except (AttributeError, RuntimeError, TypeError):
            pass
