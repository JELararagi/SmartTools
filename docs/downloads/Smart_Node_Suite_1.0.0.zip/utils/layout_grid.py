# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Translate the editor's layout preferences into Blender node positions."""

from math import isfinite

import bpy
from mathutils import Vector


def addon_preferences(context=None):
    ctx = bpy.context if context is None else context
    addons = getattr(getattr(ctx, "preferences", None), "addons", {})
    package = (__package__ or "smart_node_suite.utils").rpartition(".")[0]
    for name in (package, "smart_node_suite"):
        addon = addons.get(name)
        if addon is not None:
            return addon.preferences
    return None


def _setting(context, name, default):
    return getattr(addon_preferences(context), "layout_" + name, default)


def _number(value, default, minimum):
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return max(minimum, number) if isfinite(number) else default


def major_grid_size(context=None):
    return _number(_setting(context, "major_grid_unit", 120), 120, 1)


def use_major_grid_spacing(context=None):
    return bool(_setting(context, "use_major_grid_spacing", True))


def layout_snap_after_arrange(context=None):
    return bool(_setting(context, "snap_after_arrange", False))


def spacing_reference(context=None):
    return "BOUNDS_GAP" if _setting(context, "spacing_reference", None) == "BOUNDS_GAP" else "EDGE_GUARDED"


def guard_gap(context=None):
    steps = _number(_setting(context, "min_gap_major_steps", 1), 1, 0)
    return major_grid_size(context) * steps


def major_axis_distance(context=None, axis="HORIZONTAL"):
    key, default = ("column_major_steps", 3) if axis == "HORIZONTAL" else ("row_major_steps", 2)
    return major_grid_size(context) * _number(_setting(context, key, default), default, 1)


def axis_advance(context, item_size, fallback_gap, axis="HORIZONTAL"):
    size = _number(item_size, 0, 0)
    if not use_major_grid_spacing(context):
        return size + _number(fallback_gap, 0, 0)
    step = major_axis_distance(context, axis)
    if spacing_reference(context) == "BOUNDS_GAP":
        return size + step
    return max(step, size + guard_gap(context))


def snap_value(value, size):
    step = _number(size, 1, 1)
    try:
        return round(float(value) / step) * step
    except (TypeError, ValueError, OverflowError):
        return value


def snap_vector_to_grid(location, size):
    point = Vector(location)
    return Vector((snap_value(point[0], size), snap_value(point[1], size)))


def _apply(node, position, setter):
    if setter is None:
        node.location.xy = position
    else:
        setter(node, position)


def snap_aligned_nodes_to_major_grid(nodes, context=None, get_location=None, set_location=None):
    """Translate the entire aligned group so the first node sits on the grid."""
    if not layout_snap_after_arrange(context):
        return
    group = [node for node in nodes if node is not None and getattr(node, "type", None) != "FRAME"]
    if not group:
        return
    read = get_location or (lambda node: node.location)
    origin = Vector(read(group[0]))[:2]
    target = snap_vector_to_grid(origin, major_grid_size(context))
    offset = target - Vector(origin)
    for node in group:
        _apply(node, Vector(read(node)[:2]) + offset, set_location)


def snap_nodes_to_major_grid(nodes, context=None, get_location=None, set_location=None, axes="XY"):
    if not layout_snap_after_arrange(context):
        return
    read = get_location or (lambda node: node.location)
    step = major_grid_size(context)
    for node in nodes:
        if node is None:
            continue
        try:
            point = Vector(read(node)[:2])
            target = Vector(tuple(snap_value(n, step) if axis in axes else n
                                  for axis, n in zip("XY", point)))
            _apply(node, target, set_location)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
