# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Match texture filenames to material channels using the user's channel tags."""

from pathlib import PurePath
import re

_WORD_END = re.compile(r"(?<=[a-z])(?=[A-Z])")
_DELIMITER = re.compile(r"[ ._#-]")
_DIRECTX = {"dx", "directx"}


def split_into_components(fname):
    stem = PurePath(fname).stem
    without_numbers = "".join(ch for ch in stem if not ch.isdigit())
    split_case = _WORD_END.sub(" ", without_numbers)
    return _DELIMITER.split(split_case.lower())


def _trim_common_edge(index, at_start):
    if not index or any(not tags for tags in index.values()):
        return False
    end = 0 if at_start else -1
    if len({tags[end] for tags in index.values()}) != 1:
        return False
    for key, tags in index.items():
        index[key] = tags[1:] if at_start else tags[:-1]
    return True


def remove_common_prefix(names_to_tag_lists):
    return _trim_common_edge(names_to_tag_lists, True)


def remove_common_suffix(names_to_tag_lists):
    return _trim_common_edge(names_to_tag_lists, False)


def files_to_clean_file_names_for_sockets(files, sockets):
    index = {file.name: split_into_components(file.name) for file in files}
    channels = {tag for _, tags, _ in sockets for tag in tags}
    while len(index) > 1:
        trimmed_head = remove_common_prefix(index)
        trimmed_tail = remove_common_suffix(index)
        useful = {name: words for name, words in index.items() if channels.intersection(words)}
        if len(useful) == len(index) and not (trimmed_head or trimmed_tail):
            return useful
        index = useful
    return index


def match_files_to_socket_names(files, sockets):
    index = files_to_clean_file_names_for_sockets(files, sockets)
    for channel in sockets:
        label, tags, _selected = channel
        for filename, words in index.items():
            if label == "Normal" and _DIRECTX.intersection(split_into_components(filename)):
                continue
            if set(tags).intersection(words):
                channel[2] = filename
                break
