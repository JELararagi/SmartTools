# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeStepNoiseNode(GeometryNode):
    bl_label = loc_text('Step Noise', 'ステップノイズ')
    ss_label_key = 'Geometry Step Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'step', True,
        (('Scale', 5), ('Detail', 0), ('Distortion', 0), ('min', 0), ('max', 1), ('Steps', 6)),
        ('W',),
    )
