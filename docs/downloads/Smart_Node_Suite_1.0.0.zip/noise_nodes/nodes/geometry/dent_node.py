# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeDentNoiseNode(GeometryNode):
    bl_label = loc_text('Dent Noise', 'デントノイズ')
    ss_label_key = 'Geometry Dent Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'dent', True,
        (('Detail', 0), ('Scale', 5), ('Distortion', 0)),
        ('W',),
    )
