# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeStreaksNoiseNode(GeometryNode):
    bl_label = loc_text('Streaks Noise', 'ストリークノイズ')
    ss_label_key = 'Geometry Streaks Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'streaks', True,
        (('Ratio', 10), ('Scale', 5), ('Count', 1), ('Variation', 0)),
        ('W',),
    )
