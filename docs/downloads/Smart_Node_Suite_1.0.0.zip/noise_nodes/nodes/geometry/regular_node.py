# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeRegularNoiseNode(GeometryNode):
    bl_label = loc_text('Regular Noise', 'レギュラーノイズ')
    ss_label_key = 'Geometry Regular Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'regular', True,
        (('Scale', 5), ('Fix Range', 1), ('Detail', 5)),
        ('W',),
    )
