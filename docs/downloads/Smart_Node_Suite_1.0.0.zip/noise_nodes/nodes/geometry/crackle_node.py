# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeCrackleNoiseNode(GeometryNode):
    bl_label = loc_text('Crackle Noise', 'クラックルノイズ')
    ss_label_key = 'Geometry Crackle Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'crackle', True,
        (('Detail', 5), ('Scale', 5), ('Range', 0.5)),
        ('W',),
    )
