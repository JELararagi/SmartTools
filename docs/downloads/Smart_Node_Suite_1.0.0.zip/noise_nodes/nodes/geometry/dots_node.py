# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeDotNoiseNode(GeometryNode):
    bl_label = loc_text('Dot Noise', 'ドットノイズ')
    ss_label_key = 'Geometry Dot Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'dots', True,
        (('Variation', 0), ('Scale', 5), ('Spread', 0.1), ('Count', 1)),
        ('W',),
    )
