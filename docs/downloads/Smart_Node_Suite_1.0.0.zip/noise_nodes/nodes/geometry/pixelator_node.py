# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodePixelatorNode(GeometryNode):
    bl_label = loc_text('Pixelator', 'ピクセレーター')
    ss_label_key = 'Geometry Pixelator Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'pixelator', True,
        (('Division', 10), ('Scale', (1, 1, 1))),
        (),
    )
