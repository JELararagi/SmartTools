# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeCranalNoiseNode(GeometryNode):
    bl_label = loc_text('Cranal Noise', 'クラナルノイズ')
    ss_label_key = 'Geometry Cranal Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'cranal', True,
        (('Scale', 5),),
        ('W',),
    )
