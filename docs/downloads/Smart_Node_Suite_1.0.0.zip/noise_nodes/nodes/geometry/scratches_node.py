# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import GeometryNode
from ....translation import loc_text


class GeometryNodeScratchesNoiseNode(GeometryNode):
    bl_label = loc_text('Scratches Noise', 'スクラッチノイズ')
    ss_label_key = 'Geometry Scratches Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'scratches', True,
        (('Ratio', 0.5), ('Scale', 5), ('Spread', 1), ('Detail', 2)),
        ('W',),
    )
