"""Cellular textures and coordinate quantization built with Blender nodes."""

from .native_noise import build_group


def cell_field(graph, vector, *, feature="F1"):
    voronoi = graph.node(
        "ShaderNodeTexVoronoi", 3, feature=feature,
        distance="EUCLIDEAN", voronoi_dimensions="3D", normalize=False,
    )
    graph.set(voronoi.inputs["Vector"], vector)
    # The W socket is labeled only in dimensions that use it.
    graph.set(voronoi.inputs[1], graph.inputs["W"])
    graph.set(voronoi.inputs["Scale"], graph.inputs["Scale"])
    return voronoi.outputs


def split_axes(graph, coordinate, *, column=2):
    node = graph.node("ShaderNodeSeparateXYZ", column)
    graph.set(node.inputs[0], coordinate)
    return tuple(node.outputs)


def join_axes(graph, axes, *, column=6):
    node = graph.node("ShaderNodeCombineXYZ", column)
    for socket, value in zip(node.inputs, axes, strict=True):
        graph.set(socket, value)
    return node.outputs[0]


def split_rgb(graph, color, *, column=4):
    kind = "FunctionNodeSeparateColor" if graph.is_geometry else "ShaderNodeSeparateColor"
    node = graph.node(kind, column, mode="RGB")
    graph.set(node.inputs[0], color)
    return tuple(node.outputs)[:3]


def join_rgb(graph, channels):
    kind = "FunctionNodeCombineColor" if graph.is_geometry else "ShaderNodeCombineColor"
    node = graph.node(kind, 6, mode="RGB")
    for socket, value in zip(tuple(node.inputs)[:3], channels, strict=True):
        graph.set(socket, value)
    return node.outputs[0]


def crackle(graph):
    inputs = graph.inputs
    color = graph.texture(Scale=inputs["Scale"], Detail=inputs["Detail"])["Color"]
    centered = graph.vector_math("SUBTRACT", color, (0.5, 0.5, 0.5), column=4)
    squared = graph.vector_math("MULTIPLY", centered, centered, column=4)
    gain = graph.math("MULTIPLY", 10.0, graph.math("POWER", inputs["Range"], 4.0))
    channels = split_axes(graph, graph.vector_scale(squared, gain, column=5), column=5)
    powers = tuple(graph.math("POWER", base, exponent, column=6)
                   for base, exponent in zip(channels, channels[1:] + channels[:1], strict=True))
    return {"Color": join_rgb(graph, powers), "Fac": powers[1]}


def cell_visibility(graph, color):
    cutoff = graph.math("SUBTRACT", 1.0, graph.inputs["Count"], clamp=True)
    red, green, _blue = split_rgb(graph, color)
    present = graph.math("GREATER_THAN", red, cutoff, column=5)
    gradual = graph.normalized_range(green, cutoff, 1.0)
    return graph.scalar_mix(present, gradual, graph.inputs["Variation"])


def dots(graph):
    nearest = cell_field(graph, graph.vector)
    radius_squared = graph.inputs["Spread"]
    distance = nearest["Distance"]
    inside = graph.math("SUBTRACT", radius_squared, graph.math("MULTIPLY", distance, distance, column=4), column=4)
    envelope = graph.math("DIVIDE", inside, radius_squared, column=5, clamp=True)
    opacity = graph.math("MULTIPLY", envelope, cell_visibility(graph, nearest["Color"]), column=6)
    return {"Value": opacity, "Color": graph.vector_scale(nearest["Color"], opacity, column=6)}


def distance_gap(graph, vector, first):
    next_distance = cell_field(graph, vector, feature="F2")["Distance"]
    first_squared = graph.math("MULTIPLY", first, first, column=4)
    next_squared = graph.math("MULTIPLY", next_distance, next_distance, column=4)
    return graph.math("SUBTRACT", next_squared, first_squared, column=5)


def streaks(graph):
    ratio = graph.inputs["Ratio"]
    x, y, z = split_axes(graph, graph.vector)
    stretched = join_axes(graph, (graph.math("MULTIPLY", x, ratio),
                                  graph.math("DIVIDE", y, ratio),
                                  graph.math("DIVIDE", z, ratio)), column=3)
    first = cell_field(graph, stretched)
    distance = distance_gap(graph, stretched, first["Distance"])
    value = graph.math("MULTIPLY", distance, cell_visibility(graph, first["Color"]), column=6)
    return {"Value": value, "Color": first["Color"]}


def scratches(graph):
    inputs = graph.inputs
    math = graph.math
    nearest = cell_field(graph, graph.vector)
    gap = distance_gap(graph, graph.vector, nearest["Distance"])
    falloff = math("POWER", gap, 0.4999999701976776, column=5, clamp=True)
    frequency = math("MULTIPLY", inputs["Scale"], inputs["Ratio"])
    warp_strength = math("DIVIDE", 10.0, inputs["Scale"])
    warp = graph.vector_scale(nearest["Color"], warp_strength, column=4)
    offset = graph.vector_math("ADD", graph.vector, warp, column=4)
    grain = graph.texture(vector=offset, Scale=frequency, Detail=inputs["Detail"], column=5)["Color"]
    centered = graph.vector_math("SUBTRACT", grain, (0.5, 0.5, 0.5), column=5)
    magnitudes = graph.vector_math("ABSOLUTE", centered, column=5)
    channel_gain = math("POWER", 10.0, math("ADD", inputs["Spread"], 1.0), column=5)
    channels = split_axes(graph, graph.vector_scale(magnitudes, channel_gain, column=6), column=6)
    red, green, blue = (graph.clamp_unit(channel) for channel in channels)
    grain_strength = math("MULTIPLY", math("MULTIPLY", red, green, column=6), blue, column=6)
    value = math("DIVIDE", grain_strength, falloff, column=6, clamp=True)
    return {"Value": value, "Cells": nearest["Color"], "Falloff": falloff}


def pixel_coordinate(graph, value, cell, origin):
    math = graph.math
    relative = math("SUBTRACT", value, origin)
    positive = math("GREATER_THAN", relative, 0.0)
    remainder = math("MODULO", math("ABSOLUTE", relative), cell, column=4)
    negative_remainder = math("SUBTRACT", cell, remainder, column=4)
    offset = graph.scalar_mix(negative_remainder, remainder, positive)
    return math("SUBTRACT", value, offset, column=6)


def pixelator(graph):
    width = graph.math("DIVIDE", 1.0, graph.inputs["Division"])
    origins = graph.vector_scale(graph.inputs["Offset"], width, column=2)
    widths = graph.vector_scale(graph.inputs["Scale"], width, column=2)
    values = split_axes(graph, graph.vector)
    axes = (pixel_coordinate(graph, value, cell, origin)
            for value, cell, origin in zip(values, split_axes(graph, widths),
                                           split_axes(graph, origins), strict=True))
    return {"Vector": join_axes(graph, axes)}


def voxel(graph):
    scale = graph.inputs["Scale"]
    scaled = graph.vector_scale(graph.vector, scale, column=3)
    local = graph.vector_math("FRACTION", scaled, column=4)
    whole = graph.vector_math("FLOOR", scaled, column=4)
    position = graph.vector_math("DIVIDE", whole, scale, column=4)
    cell = cell_field(graph, position)
    return {"Color": cell["Color"], "Fac": cell["Distance"],
            "Voxel Position": position, "Voxel Vector": local}


def wavy(graph):
    inputs = graph.inputs
    math = graph.math
    depth = inputs["Detail"]
    scale_of_layers = math("MINIMUM", math("SUBTRACT", depth, 1.0), 14.0)
    # The legacy dimension adjustment raised 1 to an exponent, leaving roughness fixed.
    noise = graph.texture(variant="MULTIFRACTAL", normalize=False, Scale=inputs["Scale"],
                          Detail=scale_of_layers, Roughness=1.0, Lacunarity=1.0)["Fac"]
    untextured = math("SUBTRACT", 1.0, depth, column=4, clamp=True)
    signal = math("ADD", math("MULTIPLY", noise, graph.clamp_unit(depth), column=5), untextured, column=5)
    mask = graph.node("ShaderNodeValToRGB", 5)
    mask.color_ramp.interpolation = "CONSTANT"
    mask.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    mask.color_ramp.elements[1].position = 0.5045453906059265
    mask.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
    graph.set(mask.inputs["Fac"], signal)
    contrast = graph.node("ShaderNodeBrightContrast", 5)
    graph.set(contrast.inputs["Color"], signal)
    graph.set(contrast.inputs["Bright"], 0.0)
    graph.set(contrast.inputs["Contrast"], inputs["Line Thickness"])
    tonal = graph.node("ShaderNodeMix", 6, data_type="RGBA", clamp_factor=True)
    graph.set(tonal.inputs[0], contrast.outputs["Color"])
    graph.set(tonal.inputs[6], (0.0, 0.0, 0.0, 1.0))
    graph.set(tonal.inputs[7], (1.0, 1.0, 1.0, 1.0))
    return {"Fac": math("COMPARE", mask.outputs["Color"], tonal.outputs[2], 0.0, column=6)}


BUILDERS = {build.__name__: build for build in (crackle, dots, streaks, scratches, pixelator, voxel, wavy)}


def build_spatial_noise(owner, name, variant, *, is_geometry):
    coordinate_port = "Input Map" if variant == "pixelator" else "Vector"
    build_group(owner, name, variant, BUILDERS[variant], is_geometry=is_geometry,
                coordinate_port=coordinate_port)
