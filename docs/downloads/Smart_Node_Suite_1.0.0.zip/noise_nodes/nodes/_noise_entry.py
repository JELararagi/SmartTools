# SPDX-License-Identifier: GPL-3.0-or-later
"""Apply a noise node's published defaults using its own tree and sockets."""


def bind_noise(engine, pattern, geometry, defaults, hidden):
    def init(node, context):
        node.getNodetree(f"{node.name}_node_tree")
        for name, value in defaults:
            node._input(name).default_value = value
        for name in hidden:
            node._input(name).hide = True

    def createNodetree(node, name):
        engine(node, name, pattern, is_geometry=geometry)

    return init, createNodetree
