"""Native Blender constructions for the basic Smart Node noise families."""

import bpy

from .socket_contracts import CONTRACTS


class NoiseGraph:
    def __init__(self, tree, is_geometry, coordinate_port):
        self.tree = tree
        self.is_geometry = is_geometry
        self.column_counts = {}
        self.source = self.node("NodeGroupInput", 0)
        self.output = self.node("NodeGroupOutput", 7)
        self.output.is_active_output = True
        self.inputs = self.source.outputs
        self.vector = self.inputs[coordinate_port]
        if not is_geometry:
            self.vector = self.generated_fallback(self.vector)

    def node(self, kind, column, **properties):
        node = self.tree.nodes.new(kind)
        row = self.column_counts.get(column, 0)
        self.column_counts[column] = row + 1
        node.location = (column * 230, -row * 360)
        for key, value in properties.items():
            setattr(node, key, value)
        return node

    def set(self, socket, value):
        if isinstance(value, bpy.types.NodeSocket):
            self.tree.links.new(value, socket)
        else:
            socket.default_value = value

    def math(self, operator, *args, column=3, clamp=False):
        op = self.node("ShaderNodeMath", column, operation=operator, use_clamp=clamp)
        for index, arg in enumerate(args):
            self.set(op.inputs[index], arg)
        return op.outputs[0]

    def vector_math(self, operator, *args, column=3):
        op = self.node("ShaderNodeVectorMath", column, operation=operator)
        for index, arg in enumerate(args):
            self.set(op.inputs[index], arg)
        return op.outputs["Vector"]

    def vector_scale(self, vector, scale, *, column=3):
        node = self.node("ShaderNodeVectorMath", column, operation="SCALE")
        self.set(node.inputs["Vector"], vector)
        self.set(node.inputs["Scale"], scale)
        return node.outputs["Vector"]

    def scalar_mix(self, before, after, factor, *, column=5):
        node = self.node("ShaderNodeMix", column, data_type="FLOAT", clamp_factor=True)
        self.set(node.inputs[0], factor)
        self.set(node.inputs[2], before)
        self.set(node.inputs[3], after)
        return node.outputs[0]

    def generated_fallback(self, vector):
        # Preserve the existing scalar check and its Blender vector conversion.
        strength = self.math("ABSOLUTE", vector, column=1)
        supplied = self.math("GREATER_THAN", strength, 0.0, column=1)
        coordinates = self.node("ShaderNodeTexCoord", 0)
        mix = self.node("ShaderNodeMix", 2, data_type="VECTOR")
        self.set(mix.inputs[0], supplied)
        vector_inputs = [socket for socket in mix.inputs if socket.enabled and socket.type == "VECTOR"]
        self.set(vector_inputs[0], coordinates.outputs["Generated"])
        self.set(vector_inputs[1], vector)
        return next(socket for socket in mix.outputs if socket.enabled)

    def texture(self, *, variant="FBM", normalize=True, vector=None, column=4, **inputs):
        noise = self.node("ShaderNodeTexNoise", column, noise_type=variant, normalize=normalize)
        self.set(noise.inputs["Vector"], self.vector if vector is None else vector)
        # W is the second native socket, with its label hidden in 2D/3D.
        self.set(noise.inputs[1], self.inputs["W"])
        for name, value in inputs.items():
            self.set(noise.inputs[name], value)
        return noise.outputs

    def normalized_range(self, value, low, high, *, steps=None, vector=False):
        interpolation = "LINEAR" if steps is None else "STEPPED"
        data_type = "FLOAT_VECTOR" if vector else "FLOAT"
        remap = self.node(
            "ShaderNodeMapRange", 6,
            clamp=True, data_type=data_type, interpolation_type=interpolation,
        )
        start = "Vector" if vector else "Value"
        self.set(remap.inputs[start], value)
        for name, source in (("From Min", low), ("From Max", high), ("Steps", steps)):
            if source is not None:
                socket = next(port for port in remap.inputs if port.name == name and port.enabled)
                self.set(socket, source)
        return remap.outputs["Vector" if vector else "Result"]

    def clamp_unit(self, value):
        clamp = self.node("ShaderNodeClamp", 3)
        self.set(clamp.inputs["Value"], value)
        return clamp.outputs["Result"]


def fractal(graph):
    inputs = graph.inputs
    noise = graph.texture(Scale=inputs["Scale"], Detail=inputs["Detail"],
                          Roughness=graph.clamp_unit(inputs["Roughness"]),
                          Distortion=inputs["Distortion"])
    kind = "FunctionNodeSeparateColor" if graph.is_geometry else "ShaderNodeSeparateColor"
    hue = graph.node(kind, 5, mode="HSV")
    graph.set(hue.inputs[0], noise["Color"])
    return {"Result": graph.normalized_range(hue.outputs[0], inputs["From Min"], inputs["From Max"])}


def perlin(graph):
    inputs = graph.inputs
    math = graph.math
    layers = inputs["Detail"]
    previous_layer = math("GREATER_THAN", layers, 1.0)
    depth = math("MINIMUM", math("SUBTRACT", layers, previous_layer), 14.0)
    lacunarity = math("MAXIMUM", inputs["Lacunarity"], -1e-5)
    exponent = math("MINIMUM", math("MULTIPLY", inputs["Dimension"], -1.0), 1e-5)
    roughness = math("POWER", lacunarity, exponent)
    ridge = graph.texture(
        variant="RIDGED_MULTIFRACTAL", normalize=False,
        Scale=inputs["Scale"], Detail=depth, Roughness=roughness,
        Lacunarity=lacunarity, Offset=inputs["Offset"], Gain=inputs["Gain"],
    )
    return {"Fac": graph.normalized_range(ridge["Fac"], inputs["Min"], inputs["Max"])}


def step(graph):
    inputs = graph.inputs
    noise = graph.texture(Scale=inputs["Scale"], Detail=inputs["Detail"],
                          Roughness=0.64, Distortion=inputs["Distortion"])
    minimum, maximum, steps = (inputs[name] for name in ("min", "max", "Steps"))
    return {
        "Fac": graph.normalized_range(noise["Fac"], minimum, maximum, steps=steps),
        "Color": graph.normalized_range(noise["Color"], minimum, maximum, steps=steps, vector=True),
    }


def regular(graph):
    inputs = graph.inputs
    math = graph.math
    detail = inputs["Detail"]
    depth = math("MINIMUM", math("SUBTRACT", detail, 1.0), 14.0)
    noise = graph.texture(normalize=False, Scale=inputs["Scale"], Detail=depth,
                          Roughness=0.999993085861206)
    squeeze = inputs["Fix Range"]
    amplitude = math("MULTIPLY", noise["Fac"], graph.clamp_unit(detail), column=5)
    shift = math("MULTIPLY_ADD", squeeze, 4.0, amplitude, column=5)
    width = math("MULTIPLY_ADD", squeeze, 7.0, 1.0, column=5)
    return {"Value": math("DIVIDE", shift, width, column=6)}


def centered_channels(graph):
    inputs = graph.inputs
    noise = graph.texture(Scale=inputs["Scale"], Detail=inputs["Detail"],
                          Distortion=inputs["Distortion"])
    centered = graph.vector_math("SUBTRACT", noise["Color"], (0.5, 0.5, 0.5), column=5)
    channels = graph.node("ShaderNodeSeparateXYZ", 5)
    graph.set(channels.inputs[0], centered)
    return tuple(channels.outputs)


def dent(graph):
    math = graph.math
    red, green, blue = (math("ABSOLUTE", port, column=5) for port in centered_channels(graph))
    distance = math("MAXIMUM", red, math("MAXIMUM", green, blue, column=5), column=6)
    return {"Value": math("POWER", math("MULTIPLY", distance, 2.0, column=6), 2.5, column=6)}


def cranal(graph):
    math = graph.math
    red, green, blue = centered_channels(graph)
    product = math("MULTIPLY", math("MULTIPLY", red, green, column=5), blue, column=6)
    return {"Value": math("POWER", math("ABSOLUTE", product, column=6), 0.2, column=6)}


def fluid(graph):
    inputs = graph.inputs
    math = graph.math
    ratio = math("SQRT", inputs["Scale Ratio"])
    low_frequency = math("DIVIDE", inputs["Scale"], ratio)
    high_frequency = math("MULTIPLY", inputs["Scale"], ratio)
    field = graph.texture(Scale=low_frequency, Detail=inputs["Detail 1"], column=3)
    displacement = math("SUBTRACT", field["Fac"], 0.5, column=4)
    displacement = math("MULTIPLY", displacement, inputs["Distortion"], column=4)
    warped = graph.vector_math("ADD", graph.vector, displacement, column=4)
    result = graph.texture(Scale=high_frequency, Detail=inputs["Detail 2"], vector=warped, column=5)
    return {"Color": result["Color"], "Fac": result["Fac"]}


BUILDERS = {build.__name__: build for build in (fractal, perlin, step, regular, dent, cranal, fluid)}


def build_noise(owner, name, variant, *, is_geometry):
    build_group(owner, name, variant, BUILDERS[variant], is_geometry=is_geometry)


def build_group(owner, name, variant, builder, *, is_geometry, coordinate_port="Vector"):
    tree_type = "GeometryNodeTree" if is_geometry else "ShaderNodeTree"
    tree = bpy.data.node_groups.new(name, tree_type)
    tree.color_tag = "TEXTURE"
    family = "geometry" if is_geometry else "core"
    for socket_name, direction, socket_type, properties in CONTRACTS[family, variant]:
        socket = tree.interface.new_socket(socket_name, in_out=direction, socket_type=socket_type)
        for key, value in properties.items():
            setattr(socket, key, value)
    try:
        graph = NoiseGraph(tree, is_geometry, coordinate_port)
        for port, value in builder(graph).items():
            graph.set(graph.output.inputs[port], value)
        owner.node_tree = tree
    except Exception:
        bpy.data.node_groups.remove(tree)
        raise
