# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeWavyNoiseNode(ShaderNode):
    bl_label = loc_text('Wavy Noise', '波状ノイズ')
    ss_label_key = 'Shader Wavy Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'wavy', False,
        (('Scale', 5), ('Detail', 5), ('Line Thickness', 2), ('Dimension', 0)),
        ('W',),
    )
