# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodePerlinNoiseNode(ShaderNode):
    bl_label = loc_text('Perlin Noise', 'パーリンノイズ')
    ss_label_key = 'Shader Perlin Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'perlin', False,
        (('Scale', 8), ('Detail', 10), ('Dimension', 0), ('Lacunarity', 2), ('Offset', 0), ('Gain', 60), ('Min', 0), ('Max', 1)),
        ('W',),
    )
