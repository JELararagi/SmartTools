# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeFractalNoiseNode(ShaderNode):
    bl_label = loc_text('Fractal Noise', 'フラクタルノイズ')
    ss_label_key = 'Shader Fractal Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'fractal', False,
        (('Detail', 1), ('Scale', 10), ('Roughness', 1), ('Distortion', 0.1), ('From Max', 1), ('From Min', 0.1)),
        ('W',),
    )
