# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeVoxelNoiseNode(ShaderNode):
    bl_label = loc_text('Voxel Noise', 'ボクセルノイズ')
    ss_label_key = 'Shader Voxel Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'voxel', False,
        (('Scale', 5),),
        ('W',),
    )
