# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeFluidNoiseNode(ShaderNode):
    bl_label = loc_text('Fluid Noise', '流体ノイズ')
    ss_label_key = 'Shader Fluid Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'fluid', False,
        (('Detail 1', 4), ('Detail 2', 4), ('Scale', 5), ('Scale Ratio', 1), ('Distortion', 1)),
        ('W',),
    )
