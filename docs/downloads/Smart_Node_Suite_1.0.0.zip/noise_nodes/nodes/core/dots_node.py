# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeDotNoiseNode(ShaderNode):
    bl_label = loc_text('Dot Noise', 'ドットノイズ')
    ss_label_key = 'Shader Dot Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'dots', False,
        (('Variation', 0), ('Scale', 5), ('Spread', 0.1), ('Count', 1)),
        ('W',),
    )
