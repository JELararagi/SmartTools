# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeRegularNoiseNode(ShaderNode):
    bl_label = loc_text('Regular Noise', 'レギュラーノイズ')
    ss_label_key = 'Shader Regular Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'regular', False,
        (('Scale', 5), ('Fix Range', 1), ('Detail', 5)),
        ('W',),
    )
