# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodePixelatorNode(ShaderNode):
    bl_label = loc_text('Pixelator', 'ピクセレーター')
    ss_label_key = 'Shader Pixelator Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'pixelator', False,
        (('Division', 10), ('Scale', (1, 1, 1))),
        (),
    )
