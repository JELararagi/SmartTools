# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeScratchesNoiseNode(ShaderNode):
    bl_label = loc_text('Scratches Noise', 'スクラッチノイズ')
    ss_label_key = 'Shader Scratches Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'scratches', False,
        (('Ratio', 0.5), ('Scale', 5), ('Spread', 1), ('Detail', 2)),
        ('W',),
    )
