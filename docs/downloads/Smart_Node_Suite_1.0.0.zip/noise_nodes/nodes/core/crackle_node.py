# SPDX-License-Identifier: GPL-3.0-or-later
from ..spatial_noise import build_spatial_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeCrackleNoiseNode(ShaderNode):
    bl_label = loc_text('Crackle Noise', 'クラックルノイズ')
    ss_label_key = 'Shader Crackle Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_spatial_noise, 'crackle', False,
        (('Detail', 5), ('Scale', 5), ('Range', 0.5)),
        ('W',),
    )
