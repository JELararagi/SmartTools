# SPDX-License-Identifier: GPL-3.0-or-later
from ..native_noise import build_noise
from .._noise_entry import bind_noise
from ..utils import ShaderNode
from ....translation import loc_text


class ShaderNodeCranalNoiseNode(ShaderNode):
    bl_label = loc_text('Cranal Noise', 'クラナルノイズ')
    ss_label_key = 'Shader Cranal Noise Node'
    bl_icon = 'NONE'
    init, createNodetree = bind_noise(
        build_noise, 'cranal', False,
        (('Scale', 5),),
        ('W',),
    )
