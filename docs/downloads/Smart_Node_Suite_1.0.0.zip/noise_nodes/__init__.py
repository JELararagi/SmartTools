# ============================================================================
# Noise Nodes
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from __future__ import annotations

import bpy

from .. import rna_ownership, ui_sections
from ..translation import loc_text as _lt

bl_info = {
    'name': 'Noise Nodes',
    'description': "Advanced Noise Nodes for Blender's Shader and Geometry Nodes integrated into Smart Node",
    'author': 'JELararagi',
    'version': (1, 4, 18),
    'blender': (5, 1, 0),
    'location': 'Smart Node > Noise Nodes',
    'warning': '',
    'doc_url': '',
    'tracker_url': '',
    'category': 'Node',
}

_registered_class_tokens = []
_registered_node_class_tokens = []
_SHADER_UI_ENTRIES: tuple[tuple[str, str], ...] = ()
_GEOMETRY_UI_ENTRIES: tuple[tuple[str, str], ...] = ()
_ENTRY_LABELS: dict[str, str] = {}
_owned_window_manager_properties = []


def _noise_nodes_background_enabled(context=None):
    context = context or getattr(bpy, 'context', None)
    wm = getattr(context, 'window_manager', None) if context is not None else None
    return bool(getattr(wm, 'noise_nodes_background_callbacks', False)) if wm is not None else False


def _noise_nodes_node_wrangler_override_enabled(context=None):
    context = context or getattr(bpy, 'context', None)
    wm = getattr(context, 'window_manager', None) if context is not None else None
    return bool(getattr(wm, 'noise_nodes_node_wrangler_override', False)) if wm is not None else False


def _sync_noise_nodes_background(context=None):
    """Compatibility entry point that never scans or mutates the current file.

    The historical function was reachable from property/update code and could
    perform a file-wide compatibility pass.  Keeping that behavior would make
    startup, preference restore, or third-party compatibility calls capable of
    doing heavy work while Smart Node is otherwise idle.  The public symbol is
    retained for callers, but the only mutating compatibility pass now lives in
    :class:`NOISENODES_OT_sync_runtime`, where Blender supplies one explicit
    Undo boundary.
    """
    _ = context
    return {'converted': 0, 'failures': ()}


def _sync_noise_nodes_node_wrangler_override(context=None):
    # Saved-setting/API compatibility only.  Third-party internals are never
    # imported or patched; Smart Node exposes its exact node types from
    # ``noise_nodes.override.noise_texture_node_types`` for explicit consumers.
    _ = context
    return False


def sync_runtime_from_properties(context=None):
    """Synchronize only lightweight, non-mutating compatibility state.

    This compatibility API deliberately does not call ``ng_register`` and does
    not scan Blender data.  File conversion is available only through the
    explicit ``noise_nodes.sync_runtime`` operator.
    """
    _sync_noise_nodes_node_wrangler_override(context)
    return {'converted': 0, 'failures': ()}


def sync_persistent_runtime_from_properties(context=None):
    """Restore only lightweight opt-in integrations after settings load.

    The legacy-node conversion toggle is persisted, but its expensive file-wide
    pass is never replayed at startup. Users explicitly run the pass by toggling
    the option or invoking ``noise_nodes.sync_runtime``.
    """
    _sync_noise_nodes_node_wrangler_override(context)


def _settings_update_allowed() -> bool:
    try:
        from .. import persistent_settings
        return not persistent_settings.is_applying()
    except Exception:
        return True


def _noise_nodes_background_update(_self, context):
    if not _settings_update_allowed():
        return
    # Persist the opt-in value only. File-wide compatibility conversion is a
    # Blend-data mutation and therefore runs exclusively from the explicit
    # UNDO operator below, never from a property callback or during startup.
    try:
        from .. import persistent_settings
        persistent_settings.request_save(context, force=False)
    except Exception:
        pass


def _noise_nodes_node_wrangler_override_update(_self, context):
    if not _settings_update_allowed():
        return
    _sync_noise_nodes_node_wrangler_override(context)
    try:
        from .. import persistent_settings
        persistent_settings.request_save(context, force=False)
    except Exception:
        pass


def _icon_id(label_key: str) -> int:
    try:
        from .icons import Icon
        return int(Icon.get_icon(label_key) or 0)
    except Exception:
        return 0


class NODE_MT_noise_node_menu(bpy.types.Menu):
    bl_idname = 'NODE_MT_noise_node_menu'
    bl_label = _lt('Noise Node Menu', 'ノイズノードメニュー')
    bl_description = _lt('EN: Add registered Noise Nodes to Shader or Geometry node trees. JP: 登録済みのノイズノードをシェーダーまたはジオメトリノードツリーへ追加します。')

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        return getattr(space, 'tree_type', '') in {'ShaderNodeTree', 'GeometryNodeTree'}

    def draw(self, context):
        layout = self.layout
        tree_type = getattr(getattr(context, 'space_data', None), 'tree_type', '')
        entries = _SHADER_UI_ENTRIES if tree_type == 'ShaderNodeTree' else _GEOMETRY_UI_ENTRIES
        if not entries:
            layout.label(text=_lt('No nodes available', '利用可能なノードがありません'), icon='ERROR')
            return
        for node_type, label_key in entries:
            icon_id = _icon_id(label_key)
            if icon_id:
                properties = layout.operator('node.add_node', text=_entry_label(node_type, label_key), icon_value=icon_id)
            else:
                properties = layout.operator('node.add_node', text=_entry_label(node_type, label_key), icon='NODETREE')
            properties.type = node_type
            properties.use_transform = True


def menu_draw(self, context):
    if NODE_MT_noise_node_menu.poll(context):
        self.layout.menu(NODE_MT_noise_node_menu.bl_idname)


class NOISENODES_OT_sync_runtime(bpy.types.Operator):
    bl_idname = 'noise_nodes.sync_runtime'
    bl_label = _lt('Sync Runtime', 'ランタイム同期')
    bl_description = _lt('EN: Convert old-format noise nodes and clean up old proxies once. Enable Noise Node Compatibility first. One Undo restores the changes. JP: 古い形式のノイズノードの変換と古いプロキシの整理を1回行います。先に「ノイズノード互換ツール」を有効にしてください。1回の Undo で戻せます。')
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _noise_nodes_background_enabled(context)

    def execute(self, _context):
        try:
            from .na import ng_register
            result = ng_register()
        except Exception as exc:
            self.report({'ERROR'}, _lt(f'Noise Nodes sync failed: {exc}', 'ノイズノードの同期に失敗しました。'))
            return {'CANCELLED'}
        converted = int(result.get('converted', 0)) if isinstance(result, dict) else 0
        failures = tuple(result.get('failures', ())) if isinstance(result, dict) else ()
        if failures:
            self.report(
                {'WARNING'},
                _lt(
                    f'Converted {converted} item(s); {len(failures)} incompatible item(s) were rolled back and skipped.',
                    f'{converted} 件を変換し、互換性のない {len(failures)} 件はロールバックしてスキップしました。',
                ),
            )
        else:
            self.report({'INFO'}, _lt(f'Noise Nodes sync completed; converted {converted} item(s).', f'ノイズノードの同期が完了し、{converted} 件を変換しました。'))
        return {'FINISHED'}


def _entry_label(node_type: str, label_key: str) -> str:
    # The added node's own title, so the menu and the node read the same in every language.
    return _ENTRY_LABELS.get(node_type) or _lt(label_key)


def _smarttools_noise_add_button(layout, label: str, node_type: str, *, icon_key: str = ''):
    icon_id = _icon_id(icon_key or label)
    if icon_id:
        operator = layout.operator('node.add_node', text=label, icon_value=icon_id)
    else:
        operator = layout.operator('node.add_node', text=label, icon='NODETREE')
    operator.type = node_type
    operator.use_transform = False
    return operator


def draw_smart_node_runtime_controls(layout, context):
    box = layout
    _group, runtime_box, _expanded = ui_sections.draw_group(
        box, context, 'noise_nodes_manual_runtime_sync',
        _lt('Manual Runtime Sync', '手動ランタイム同期'),
        icon='FILE_REFRESH', topic='noise_nodes', default_open=False,
    )
    row = runtime_box.row(align=True)
    row.enabled = _noise_nodes_background_enabled(context)
    row.operator('noise_nodes.sync_runtime', text=_lt('Sync Current File', '現在ファイル同期'), icon='FILE_REFRESH')
    if not row.enabled:
        runtime_box.label(text=_lt('Enable Noise Node Compatibility first.', '先に「ノイズノード互換ツール」を有効にしてください。'))

    _group, shader_panel, _expanded = ui_sections.draw_group(
        box, context, 'noise_nodes_shader_nodes',
        _lt('Shader Noise Nodes', 'シェーダーノイズノード'),
        icon='NODE_MATERIAL', topic='noise_nodes', default_open=False,
    )
    column = shader_panel.column(align=True)
    for node_type, label_key in _SHADER_UI_ENTRIES:
        _smarttools_noise_add_button(column, _entry_label(node_type, label_key), node_type, icon_key=label_key)

    _group, geometry_panel, _expanded = ui_sections.draw_group(
        box, context, 'noise_nodes_geometry_nodes',
        _lt('Geometry Noise Nodes', 'ジオメトリノイズノード'),
        icon='GEOMETRY_NODES', topic='noise_nodes', default_open=False,
    )
    column = geometry_panel.column(align=True)
    for node_type, label_key in _GEOMETRY_UI_ENTRIES:
        _smarttools_noise_add_button(column, _entry_label(node_type, label_key), node_type, icon_key=label_key)


def _register_class(cls) -> None:
    _registered_class_tokens.append(rna_ownership.register_class(cls))


def _prime_custom_group_wrappers() -> None:
    """Pin the CustomGroup base wrappers before the node modules are imported.

    Measured on Blender 5.1.2 (ec6e62d40fa9): the first registration of a
    ShaderNodeCustomGroup / GeometryNodeCustomGroup subclass in a session
    re-creates the ``bpy.types`` wrapper object for that base.  A node class
    whose module captured the pre-flip wrapper registers once, but the next
    enable of the add-on fails with ``TypeError: expected GeometryNodeCustomGroup
    subclass of class "..."`` because the cached class no longer inherits the
    current wrapper.  Registering and unregistering one throwaway subclass per
    base here -- before ``nodes/utils.py`` is first imported -- forces that
    one-time re-creation early, so every real node class captures the stable
    wrapper and enable -> disable -> enable cycles cleanly.
    """
    for base_name in ('ShaderNodeCustomGroup', 'GeometryNodeCustomGroup'):
        base = getattr(bpy.types, base_name, None)
        if base is None:
            continue
        probe = type('SNS_%s_WrapperProbe' % base_name, (base,), {
            'bl_label': 'Smart Node wrapper probe',
        })
        try:
            bpy.utils.register_class(probe)
        except Exception:
            continue
        try:
            bpy.utils.unregister_class(probe)
        except Exception:
            pass


def register():
    global _SHADER_UI_ENTRIES, _GEOMETRY_UI_ENTRIES, _ENTRY_LABELS
    if _registered_class_tokens or _registered_node_class_tokens or _owned_window_manager_properties:
        return
    try:
        _prime_custom_group_wrappers()

        from .icons import Icon
        from .node_imp import NodeLib
        from .translations import langs

        Icon.register_icons()
        _register_class(NODE_MT_noise_node_menu)
        _register_class(NOISENODES_OT_sync_runtime)

        geometry_nodes, shader_nodes = NodeLib.get_node_sets()
        for cls in tuple(geometry_nodes) + tuple(shader_nodes):
            _registered_node_class_tokens.append(rna_ownership.register_class(cls))
        _ENTRY_LABELS = {cls.__name__: str(getattr(cls, 'bl_label', '') or '') for cls in tuple(geometry_nodes) + tuple(shader_nodes)}
        _GEOMETRY_UI_ENTRIES = tuple(sorted(
            ((cls.__name__, str(getattr(cls, 'ss_label_key', getattr(cls, 'bl_label', cls.__name__)))) for cls in geometry_nodes),
            key=lambda item: item[1],
        ))
        _SHADER_UI_ENTRIES = tuple(sorted(
            ((cls.__name__, str(getattr(cls, 'ss_label_key', getattr(cls, 'bl_label', cls.__name__)))) for cls in shader_nodes),
            key=lambda item: item[1],
        ))

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, langs)
        acquired = []
        try:
            acquired.append(rna_ownership.install_property(
                bpy.types.WindowManager,
                'noise_nodes_background_callbacks',
                bpy.props.BoolProperty(
                    name=_lt('Noise Node Compatibility', 'ノイズノード互換ツール'),
                    description=_lt('EN: Makes Run One-shot Sync available. Turning this on does not scan or change the current file. JP: 「1回同期を実行」を使えるようにします。有効にするだけでは、現在のファイルを調べたり変えたりしません。'),
                    default=False,
                    update=_noise_nodes_background_update,
                ),
            ))
            acquired.append(rna_ownership.install_property(
                bpy.types.WindowManager,
                'noise_nodes_node_wrangler_override',
                bpy.props.BoolProperty(
                    name=_lt('Node Wrangler Override', 'Node Wrangler 上書き'),
                    description=_lt('EN: Keeps the compatibility setting without changing Node Wrangler itself. JP: Node Wrangler 本体を変えずに、互換の設定を残します。'),
                    default=False,
                    update=_noise_nodes_node_wrangler_override_update,
                ),
            ))
        except Exception:
            for token in reversed(acquired):
                rna_ownership.remove_property(token)
            raise
        _owned_window_manager_properties.extend(acquired)
    except Exception:
        unregister()
        raise


def unregister():
    global _SHADER_UI_ENTRIES, _GEOMETRY_UI_ENTRIES, _ENTRY_LABELS
    try:
        from .na import ng_unregister, unregister_proxy_cleanup
        unregister_proxy_cleanup()
        ng_unregister(run_conversion=False)
    except Exception:
        pass

    while _owned_window_manager_properties:
        token = _owned_window_manager_properties.pop()
        try:
            rna_ownership.remove_property(token)
        except Exception:
            pass
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    rna_ownership.unregister_classes(_registered_node_class_tokens)
    rna_ownership.unregister_classes(_registered_class_tokens)
    try:
        from .node_imp import NodeLib
        NodeLib.clear_cache()
    except Exception:
        pass
    try:
        from .icons import Icon
        Icon.unregister_icons()
    except Exception:
        pass
    _SHADER_UI_ENTRIES = ()
    _GEOMETRY_UI_ENTRIES = ()
    _ENTRY_LABELS = {}
