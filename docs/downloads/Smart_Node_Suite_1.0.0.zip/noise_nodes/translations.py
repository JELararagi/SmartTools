# SPDX-License-Identifier: GPL-3.0-or-later
"""Simplified Chinese menu strings for SmartNode's noise tools."""

_DISPLAY_NAMES = (
    ("Noise Nodes", "程序噪声节点"),
    ("Voxel Noise", "体素状噪声"),
    ("Cranal Noise", "Cranal 型噪声"),
    ("Pixelator", "像素化处理"),
    ("Scratches Noise", "刮擦纹理噪声"),
    ("Dot Noise", "圆点状噪声"),
    ("Regular Noise", "规则排列噪声"),
    ("Streaks Noise", "条带状噪声"),
    ("Fractal Noise", "分形纹理噪声"),
    ("Dent Noise", "凹痕状噪声"),
    ("Fluid Noise", "流动纹理噪声"),
    ("Crackle Noise", "龟裂纹理噪声"),
    ("Perlin Noise", "柏林梯度噪声"),
    ("Step Noise", "阶梯状噪声"),
    ("Wavy Noise", "波纹状噪声"),
)

specific_dict = {("*", label): display for label, display in _DISPLAY_NAMES}
you_dict = dict.fromkeys(specific_dict, "")
langs = dict.fromkeys(("zh_CN", "zh_HANS"), specific_dict)
