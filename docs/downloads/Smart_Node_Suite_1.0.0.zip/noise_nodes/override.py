# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Keep the former compatibility controls inert."""
_NOISE_TEXTURE_TYPES = tuple(
    f"ShaderNode{kind}Node"
    for kind in (
        "CrackleNoise", "CranalNoise", "DentNoise", "DotNoise", "FluidNoise",
        "FractalNoise", "PerlinNoise", "Pixelator", "RegularNoise", "ScratchesNoise",
        "StepNoise", "StreaksNoise", "VoxelNoise", "WavyNoise",
    )
)


def noise_texture_node_types():
    return _NOISE_TEXTURE_TYPES


def enable_override_node_wrangler():
    return False


def disable_override_node_wrangler():
    return None
