# ============================================================================
# Node Color Tools Pie
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from ..translation import loc_text as _lt
from .. import ui_sections
from ..addon_owner import addon_owner_id
from .. import tool_preferences as _st_prefs
from .. import manager_rules, rna_ownership, runtime_lifecycle
bl_info = {'name': 'Node Color Tools Pie', 'author': 'JELararagi', 'version': (1, 4, 18), 'blender': (5, 1, 0), 'location': 'Smart Node > Node Management', 'description': 'Quick, organized node colors with pie menu controls integrated into Smart Node Suite', 'category': 'Node'}
import bpy
import random
import colorsys
_NODECOLOR_PREF_DEFAULTS = {'enable_hotkeys': False, 'pie_menu_hotkey': 'Z', 'capturing_key': False, 'ctrl': False, 'alt': False, 'shift': False, 'pie_menu_hotkey_2': 'D', 'capturing_key_2': False, 'ctrl_2': False, 'alt_2': False, 'shift_2': False}
_NODECOLOR_RUNTIME_PREFS = dict(_NODECOLOR_PREF_DEFAULTS)
_NODECOLOR_ROOT_PREF_MAP = {
    'pie_menu_hotkey': _st_prefs.prop_name('node_color_tools', 'pie_menu_hotkey'),
    'ctrl': _st_prefs.prop_name('node_color_tools', 'ctrl'),
    'alt': _st_prefs.prop_name('node_color_tools', 'alt'),
    'shift': _st_prefs.prop_name('node_color_tools', 'shift'),
    'pie_menu_hotkey_2': _st_prefs.prop_name('node_color_tools', 'pie_menu_hotkey_2'),
    'ctrl_2': _st_prefs.prop_name('node_color_tools', 'ctrl_2'),
    'alt_2': _st_prefs.prop_name('node_color_tools', 'alt_2'),
    'shift_2': _st_prefs.prop_name('node_color_tools', 'shift_2'),
}

class _NodeColorFallbackPrefs:

    def __getattr__(self, name):
        if name in _NODECOLOR_RUNTIME_PREFS:
            return _NODECOLOR_RUNTIME_PREFS[name]
        raise AttributeError(name)

    def __setattr__(self, name, value):
        if name in _NODECOLOR_RUNTIME_PREFS:
            _NODECOLOR_RUNTIME_PREFS[name] = value
            return
        object.__setattr__(self, name, value)
_NODECOLOR_FALLBACK_PREFS = _NodeColorFallbackPrefs()
_NODECOLOR_PERSISTENCE_APPLYING = False
_NODECOLOR_CACHE: dict[str, object] | None = None
_NODECOLOR_PRESET_PROPS = ('nodecolor1', 'nodecolor2', 'nodecolor3', 'nodecolor4', 'nodecolor5')


def _nodecolor_has_rna_property(data, name: str) -> bool:
    if data is None or not name:
        return False
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(name)) is not None
    except Exception:
        pass
    try:
        return str(name) in props.keys()
    except Exception:
        return False


def _nodecolor_collect(data) -> dict[str, object]:
    result: dict[str, object] = {}
    if data is None:
        return result
    for name in _NODECOLOR_PRESET_PROPS:
        if not _nodecolor_has_rna_property(data, name):
            continue
        try:
            result[name] = list(getattr(data, name))
        except Exception:
            pass
    return result


def _nodecolor_read_settings() -> dict[str, object]:
    try:
        from .. import persistent_settings
        values = persistent_settings.load_named_group('node_color_tools')
        return values if isinstance(values, dict) else {}
    except Exception:
        return {}

def save_node_color_settings(data=None, context=None) -> None:
    global _NODECOLOR_CACHE
    if _NODECOLOR_PERSISTENCE_APPLYING:
        return
    if data is None:
        data = getattr(getattr(context or getattr(bpy, 'context', None), 'scene', None), 'node_color_tools', None)
    values = _nodecolor_collect(data)
    if not values or values == _NODECOLOR_CACHE:
        return
    try:
        from .. import persistent_settings
        if persistent_settings.save_named_group('node_color_tools', values, context=context, source=data):
            _NODECOLOR_CACHE = dict(values)
    except Exception:
        pass

def apply_node_color_settings(data=None) -> None:
    global _NODECOLOR_PERSISTENCE_APPLYING, _NODECOLOR_CACHE
    if data is None:
        try:
            data = getattr(getattr(bpy.context, 'scene', None), 'node_color_tools', None)
        except Exception:
            data = None
    if data is None:
        return
    saved = _nodecolor_read_settings()
    if not saved:
        _NODECOLOR_CACHE = _nodecolor_collect(data)
        return
    _NODECOLOR_PERSISTENCE_APPLYING = True
    try:
        for name, value in saved.items():
            if name in _NODECOLOR_PRESET_PROPS and _nodecolor_has_rna_property(data, name):
                try:
                    setattr(data, name, value)
                except Exception:
                    pass
    finally:
        _NODECOLOR_PERSISTENCE_APPLYING = False
    _NODECOLOR_CACHE = _nodecolor_collect(data)


def _nodecolor_preset_update(self, context):
    save_node_color_settings(self, context=context)


def _nodecolor_register_handler() -> None:
    return None


def _nodecolor_unregister_handler() -> None:
    return None


def _nodecolor_addon_preferences(context=None):
    prefs = _st_prefs.addon_preferences(context)
    if prefs is not None and _nodecolor_has_rna_property(prefs, _st_prefs.prop_name('node_color_tools', 'pie_menu_hotkey')):
        return prefs
    return None

def _nodecolor_prefs(context=None):
    return _NODECOLOR_FALLBACK_PREFS

def _nodecolor_set(name, value, context=None):
    prefs = _nodecolor_addon_preferences(context)
    root_name = _NODECOLOR_ROOT_PREF_MAP.get(name)
    stored = False
    if prefs is not None and root_name:
        try:
            setattr(prefs, root_name, value)
            stored = True
        except Exception:
            pass
    elif prefs is not None and _nodecolor_has_rna_property(prefs, name):
        try:
            setattr(prefs, name, value)
            stored = True
        except Exception:
            pass
    _NODECOLOR_RUNTIME_PREFS[name] = value
    if stored or name in _NODECOLOR_RUNTIME_PREFS:
        try:
            from .. import persistent_settings
            persistent_settings.request_save(context, force=False)
        except Exception:
            pass

class NodeColorTools(bpy.types.PropertyGroup):
    nodecolor1: bpy.props.FloatVectorProperty(name=_lt('Set Color Preset 1'), description=_lt('JP: プリセット色1です。選択ノードへ色を適用するパイメニューや直接適用コマンドで使用します。変更するとNパネルの状態として保存されます。\nEN: Preset color 1. Used by pie menus and direct color commands when applying colors to selected nodes. Changes are saved as N-panel state.'), subtype='COLOR', default=(0.8, 0.3, 0.25), min=0.0, max=1.0, update=_nodecolor_preset_update)
    nodecolor2: bpy.props.FloatVectorProperty(name=_lt('Set Color Preset 2'), description=_lt('JP: プリセット色2です。選択ノードへ色を適用するパイメニューや直接適用コマンドで使用します。変更するとNパネルの状態として保存されます。\nEN: Preset color 2. Used by pie menus and direct color commands when applying colors to selected nodes. Changes are saved as N-panel state.'), subtype='COLOR', default=(0.3, 0.6, 0.25), min=0.0, max=1.0, update=_nodecolor_preset_update)
    nodecolor3: bpy.props.FloatVectorProperty(name=_lt('Set Color Preset 3'), description=_lt('JP: プリセット色3です。選択ノードへ色を適用するパイメニューや直接適用コマンドで使用します。変更するとNパネルの状態として保存されます。\nEN: Preset color 3. Used by pie menus and direct color commands when applying colors to selected nodes. Changes are saved as N-panel state.'), subtype='COLOR', default=(0.0, 0.5, 0.9), min=0.0, max=1.0, update=_nodecolor_preset_update)
    nodecolor4: bpy.props.FloatVectorProperty(name=_lt('Set Color Preset 4'), description=_lt('JP: プリセット色4です。選択ノードへ色を適用するパイメニューや直接適用コマンドで使用します。変更するとNパネルの状態として保存されます。\nEN: Preset color 4. Used by pie menus and direct color commands when applying colors to selected nodes. Changes are saved as N-panel state.'), subtype='COLOR', default=(0.7, 0.6, 0.2), min=0.0, max=1.0, update=_nodecolor_preset_update)
    nodecolor5: bpy.props.FloatVectorProperty(name=_lt('Set Color Preset 5'), description=_lt('JP: プリセット色5です。選択ノードへ色を適用するパイメニューや直接適用コマンドで使用します。変更するとNパネルの状態として保存されます。\nEN: Preset color 5. Used by pie menus and direct color commands when applying colors to selected nodes. Changes are saved as N-panel state.'), subtype='COLOR', default=(0.4, 0.3, 0.8), min=0.0, max=1.0, update=_nodecolor_preset_update)

class NODE_PT_node_color_adjustment(bpy.types.Panel):
    bl_label = _lt('Node Color Adjustment', 'ノードカラー調整')
    bl_idname = 'NODE_PT_node_color_adjustment'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Node')

    @classmethod
    def poll(cls, context):
        if getattr(context, 'scene', None) is None:
            return False
        return manager_rules.panel_poll(
            context,
            physical_space='NODE_EDITOR',
            logical_keys=(
                'SHADER_EDITOR', 'COMPOSITOR',
                'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR',
            ),
        )

    def draw(self, context):
        layout = self.layout
        _box, layout, _expanded = ui_sections.draw_group(layout, context, 'node_color_adjustment_panel', _lt('Node Color Adjustment', 'ノードカラー調整'), icon='COLOR', topic='node_color_tools', default_open=False)
        try:
            nodeColorTools = context.scene.node_color_tools
        except Exception:
            return
        layout.operator('node.set_random_color', text=_lt('Randomize Color'))
        layout.operator('node.copy_active_node_color', text=_lt('Copy Active Node Color'))
        row = layout.column(align=True)
        col1 = row.column(align=True)
        color1_item = col1.operator('node.set_slot_color', text=_lt('Set Slot Color'))
        color1_item.color = nodeColorTools.nodecolor1
        color2_item = col1.operator('node.set_slot_color', text=_lt('Set Slot Color'))
        color2_item.color = nodeColorTools.nodecolor2
        color3_item = col1.operator('node.set_slot_color', text=_lt('Set Slot Color'))
        color3_item.color = nodeColorTools.nodecolor3
        col2 = row.column(align=True)
        col2.prop(nodeColorTools, 'nodecolor1', text='')
        col2.prop(nodeColorTools, 'nodecolor2', text='')
        col2.prop(nodeColorTools, 'nodecolor3', text='')
        col3 = row.column(align=True)
        color4_item = col3.operator('node.set_slot_color', text=_lt('Set Slot Color'))
        color4_item.color = nodeColorTools.nodecolor4
        color5_item = col3.operator('node.set_slot_color', text=_lt('Set Slot Color'))
        color5_item.color = nodeColorTools.nodecolor5
        col4 = row.column(align=True)
        col4.prop(nodeColorTools, 'nodecolor4', text='')
        col4.prop(nodeColorTools, 'nodecolor5', text='')
        layout.operator('node.remove_color', text=_lt('Remove Color'))

class NODE_OT_set_slot_color(bpy.types.Operator):
    bl_idname = 'node.set_slot_color'
    bl_label = _lt('Set Slot Color', 'スロット色設定')
    bl_options = {'UNDO'}
    color: bpy.props.FloatVectorProperty(name=_lt('Node Color', 'ノードカラー'), description=_lt('JP: 選択ノードへ適用する一時色です。オペレーター実行時にRGB値として渡されます。\nEN: Temporary color applied to selected nodes. The value is passed as RGB when the operator runs.'), subtype='COLOR', size=3)

    def execute(self, context):
        nodes = bpy.context.selected_nodes
        newColor = self.color
        for node in nodes:
            node.use_custom_color = True
            node.color = newColor
        return {'FINISHED'}

class NODE_OT_set_preset_color(bpy.types.Operator):
    bl_idname = 'node.set_preset_color'
    bl_label = _lt('Set Preset Color', 'プリセット色設定')
    bl_options = {'UNDO'}
    color: bpy.props.FloatVectorProperty(name=_lt('Node Color', 'ノードカラー'), description=_lt('JP: 選択ノードへ適用する一時色です。オペレーター実行時にRGB値として渡されます。\nEN: Temporary color applied to selected nodes. The value is passed as RGB when the operator runs.'), subtype='COLOR', size=3)

    def execute(self, context):
        nodes = bpy.context.selected_nodes
        newColor = self.color
        for node in nodes:
            node.use_custom_color = True
            node.color = newColor
        return {'FINISHED'}

class NODE_OT_remove_color(bpy.types.Operator):
    bl_idname = 'node.remove_color'
    bl_label = _lt('Remove Color', '色削除')
    bl_options = {'UNDO'}

    def execute(self, context):
        nodes = bpy.context.selected_nodes
        for node in nodes:
            node.use_custom_color = False
        return {'FINISHED'}

class NODE_OT_copy_active_node_color(bpy.types.Operator):
    bl_idname = 'node.copy_active_node_color'
    bl_label = _lt('Copy Active Node Color', 'アクティブノード色コピー')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            space = getattr(context, 'space_data', None)
            if getattr(space, 'type', '') != 'NODE_EDITOR':
                return False
            node_tree = getattr(space, 'node_tree', None)
            return bool(node_tree and getattr(getattr(node_tree, 'nodes', None), 'active', None))
        except Exception:
            return False

    def execute(self, context):
        nodes = bpy.context.selected_nodes
        activeColor = bpy.context.active_node.color
        for node in nodes:
            node.use_custom_color = True
            node.color = activeColor
        return {'FINISHED'}

class NODE_OT_set_random_color(bpy.types.Operator):
    bl_idname = 'node.set_random_color'
    bl_label = _lt('Set Random Color', 'ランダムカラーを設定')
    bl_options = {'UNDO'}

    def execute(self, context):
        nodes = bpy.context.selected_nodes
        for node in nodes:
            node.use_custom_color = True
            hue = random.random()
            saturation = random.random()
            value = random.random() / 1.7
            randomRGB = colorsys.hsv_to_rgb(hue, saturation, value)
            node.color = [randomRGB[0], randomRGB[1], randomRGB[2]]
        return {'FINISHED'}

class NODE_MT_precise_node_color_pie(bpy.types.Menu):
    bl_label = _lt('Precise Node Color Pie', '精密ノードカラーパイ')
    bl_idname = 'NODE_MT_precise_node_color_pie'

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        col3 = pie.column(align=True)
        color3_item = col3.operator('node.set_slot_color', text=_lt('Set Color Preset 3'))
        color3_item.color = context.scene.node_color_tools.nodecolor3
        col3.prop(context.scene.node_color_tools, 'nodecolor3', text='')
        col4 = pie.column(align=True)
        color4_item = col4.operator('node.set_slot_color', text=_lt('Set Color Preset 4'))
        color4_item.color = context.scene.node_color_tools.nodecolor4
        col4.prop(context.scene.node_color_tools, 'nodecolor4', text='')
        col7 = pie.column(align=True)
        col7.operator('node.copy_active_node_color', text=_lt('Copy Active Node Color'))
        col6 = pie.column(align=True)
        col6.operator('node.set_random_color', text=_lt('Randomize Color'))
        col1 = pie.column(align=True)
        color1_item = col1.operator('node.set_slot_color', text=_lt('Set Color Preset 1'))
        color1_item.color = context.scene.node_color_tools.nodecolor1
        col1.prop(context.scene.node_color_tools, 'nodecolor1', text='')
        col2 = pie.column(align=True)
        color2_item = col2.operator('node.set_slot_color', text=_lt('Set Color Preset 2'))
        color2_item.color = context.scene.node_color_tools.nodecolor2
        col2.prop(context.scene.node_color_tools, 'nodecolor2', text='')
        col5 = pie.column(align=True)
        color5_item = col5.operator('node.set_slot_color', text=_lt('Set Color Preset 5'))
        color5_item.color = context.scene.node_color_tools.nodecolor5
        col5.prop(context.scene.node_color_tools, 'nodecolor5', text='')
        col8 = pie.column(align=True)
        col8.operator('node.remove_color', text=_lt('Remove Color'))

class NODE_MT_quick_node_color_pie(bpy.types.Menu):
    bl_label = _lt('Quick Node Color Pie', 'クイックノードカラーパイ')
    bl_idname = 'NODE_MT_quick_node_color_pie'

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        color1 = (0.8, 0.3, 0.25)
        color2 = (0.3, 0.6, 0.25)
        color3 = (0.0, 0.5, 0.9)
        color4 = (0.7, 0.6, 0.2)
        color5 = (0.4, 0.3, 0.8)
        version = bpy.app.version
        if version >= (4, 4, 0):
            icon03 = 'STRIP_COLOR_05'
            icon04 = 'STRIP_COLOR_03'
            icon01 = 'STRIP_COLOR_01'
            icon02 = 'STRIP_COLOR_04'
            icon05 = 'STRIP_COLOR_06'
        else:
            icon03 = 'SEQUENCE_COLOR_05'
            icon04 = 'SEQUENCE_COLOR_03'
            icon01 = 'SEQUENCE_COLOR_01'
            icon02 = 'SEQUENCE_COLOR_04'
            icon05 = 'SEQUENCE_COLOR_06'
        color3_item = pie.operator('node.set_preset_color', text=_lt('Set Color Preset 3'), icon=icon03)
        color3_item.color = color3
        color4_item = pie.operator('node.set_preset_color', text=_lt('Set Color Preset 4'), icon=icon04)
        color4_item.color = color4
        pie.operator('node.copy_active_node_color', text=_lt('Copy Active Node Color'))
        pie.operator('node.set_random_color', text=_lt('Randomize Color'))
        color1_item = pie.operator('node.set_preset_color', text=_lt('Set Color Preset 1'), icon=icon01)
        color1_item.color = color1
        color2_item = pie.operator('node.set_preset_color', text=_lt('Set Color Preset 2'), icon=icon02)
        color2_item.color = color2
        color5_item = pie.operator('node.set_preset_color', text=_lt('Set Color Preset 5'), icon=icon05)
        color5_item.color = color5
        pie.operator('node.remove_color', text=_lt('Remove Color'))

def update_keymap(self, context):
    _ = (self, context)
    return None
addon_keymaps = []

def _nodecolor_pref_value(name: str, context=None):
    prefs = _nodecolor_addon_preferences(context)
    root_name = _NODECOLOR_ROOT_PREF_MAP.get(name)
    if prefs is not None and root_name:
        try:
            return getattr(prefs, root_name)
        except Exception:
            pass
    if prefs is not None and _nodecolor_has_rna_property(prefs, name):
        try:
            return getattr(prefs, name)
        except Exception:
            pass
    return _NODECOLOR_RUNTIME_PREFS.get(name, _NODECOLOR_PREF_DEFAULTS.get(name))

class NODECOLOR_OT_toggle_runtime_flag(bpy.types.Operator):
    bl_idname = 'nodecolor.toggle_runtime_flag'
    bl_label = _lt('Toggle Runtime Flag', 'ランタイムフラグ切替')
    bl_description = _lt('EN: Toggle one of the Node Color Tools hotkey modifier flags used by the Smart Node key buttons. JP: Smart Node のキー設定ボタンで使う Node Color Tools の修飾キー状態を切り替えます。')
    bl_options = {'INTERNAL'}
    pref_name: bpy.props.StringProperty(description=_lt('JP: 内部用の設定名です。ショートカット捕捉処理で対象キーを識別するために使用します。\nEN: Internal preference name used to identify the target key during shortcut capture.'), options={'SKIP_SAVE'})

    def execute(self, context):
        key = str(self.pref_name or '').strip()
        if not key:
            return {'CANCELLED'}
        current = bool(_nodecolor_pref_value(key, context))
        _nodecolor_set(key, not current, context)
        return {'FINISHED'}
SSS_DISABLE_PROXY_PANELS = True
SSS_HIDE_OPERATOR_IDS = {'node.set_slot_color', 'node.set_preset_color'}

def _smarttools_nodecolor_button(layout, op_id: str, text: str, *, icon: str='NONE', kwargs: dict | None=None):
    # Node Color Tools is a native bundled module, so its operators are already
    # registered when this UI is drawn.  Calling them directly avoids the stale
    # generic run-tool wrapper used by an earlier migration.
    op = layout.operator(op_id, text=text, icon=icon)
    for name, value in dict(kwargs or {}).items():
        try:
            setattr(op, name, value)
        except (AttributeError, TypeError, ValueError):
            pass
    return op

def _smarttools_modifier_toggle(layout, label: str, pref_name: str, context):
    state = bool(_nodecolor_pref_value(pref_name, context))
    op = layout.operator('nodecolor.toggle_runtime_flag', text=label, depress=state)
    op.pref_name = pref_name
    return op

def draw_smart_node_runtime_controls(layout, context):
    scene = getattr(context, 'scene', None)
    data = getattr(scene, 'node_color_tools', None) if scene is not None else None
    prefs = _nodecolor_prefs(context)

    _box, box, _expanded = ui_sections.draw_group(layout, context, 'node_color_runtime_root', _lt('Node Color Adjustment', 'ノードカラー調整'), icon='COLOR', topic='node_color_tools', default_open=False)

    _box, quick, _expanded = ui_sections.draw_group(box, context, 'node_color_quick_actions', _lt('Quick Actions', 'クイック操作'), icon='TOOL_SETTINGS', topic='node_color_tools', default_open=False)
    row = quick.column(align=True)
    _smarttools_nodecolor_button(row, 'node.set_random_color', _lt('Randomize Color', 'ランダム色設定'), icon='COLOR')
    _smarttools_nodecolor_button(row, 'node.copy_active_node_color', _lt('Copy Active Node Color', 'アクティブノード色コピー'), icon='COPYDOWN')
    _smarttools_nodecolor_button(row, 'node.remove_color', _lt('Remove Color', '色削除'), icon='X')

    if data is not None:
        _box, colors_box, _expanded = ui_sections.draw_group(box, context, 'node_color_preset_colors', _lt('Preset Colors', 'プリセット色'), icon='COLOR', topic='node_color_tools', default_open=False)
        for index in range(1, 6):
            prop_name = f'nodecolor{index}'
            row = colors_box.column(align=True)
            row.prop(data, prop_name, text=_lt(f'Color {index}', f'色{index}'))
            value = list(getattr(data, prop_name))
            _smarttools_nodecolor_button(row, 'node.set_slot_color', _lt(f'Apply {index}', f'適用 {index}'), icon='BRUSH_DATA', kwargs={'color': value})

    _box, pie_box, _expanded = ui_sections.draw_group(box, context, 'node_color_pie_menus', _lt('Pie Menus', 'パイメニュー'), icon='MENU_PANEL', topic='node_color_tools', default_open=False)
    row = pie_box.column(align=True)
    _smarttools_nodecolor_button(row, 'wm.main_panel', _lt('Precise Pie', '詳細パイ'), icon='PRESET')
    _smarttools_nodecolor_button(row, 'wm.open_quick_color_pie', _lt('Quick Pie', 'クイックパイ'), icon='PRESET')

    _box, key_box, _expanded = ui_sections.draw_group(box, context, 'node_color_manual_hotkey_setup', _lt('Manual Hotkey Setup', '手動ホットキー設定'), icon='EVENT_Z', topic='node_color_tools', default_open=False)
    key_box.label(text=_lt(f"Precise Pie: {str(_nodecolor_pref_value('pie_menu_hotkey', context) or '').upper() or '-'}", f"詳細パイ: {str(_nodecolor_pref_value('pie_menu_hotkey', context) or '').upper() or '-'}"))
    row = key_box.column(align=True)
    _smarttools_modifier_toggle(row, _lt('Ctrl'), 'ctrl', context)
    _smarttools_modifier_toggle(row, _lt('Alt'), 'alt', context)
    _smarttools_modifier_toggle(row, _lt('Shift'), 'shift', context)
    row.operator('nodecolor.set_manual_hotkey', text=_lt('Set Precise Hotkey', '詳細キー設定'), icon='KEY_HLT')
    key_box.separator(factor=0.3)
    key_box.label(text=_lt(f"Quick Pie: {str(_nodecolor_pref_value('pie_menu_hotkey_2', context) or '').upper() or '-'}", f"クイックパイ: {str(_nodecolor_pref_value('pie_menu_hotkey_2', context) or '').upper() or '-'}"))
    row = key_box.column(align=True)
    _smarttools_modifier_toggle(row, _lt('Ctrl'), 'ctrl_2', context)
    _smarttools_modifier_toggle(row, _lt('Alt'), 'alt_2', context)
    _smarttools_modifier_toggle(row, _lt('Shift'), 'shift_2', context)
    row.operator('nodecolor.set_quick_hotkey', text=_lt('Set Quick Hotkey', '簡易キー設定'), icon='KEY_HLT')


def _set_capture_flag(name: str, value: bool) -> None:
    if name in {'capturing_key', 'capturing_key_2'}:
        _NODECOLOR_RUNTIME_PREFS[name] = bool(value)


def _reset_capture_flags() -> None:
    _set_capture_flag('capturing_key', False)
    _set_capture_flag('capturing_key_2', False)


class NODECOLOR_OT_set_manual_hotkey(bpy.types.Operator):
    bl_idname = 'nodecolor.set_manual_hotkey'
    bl_label = _lt('Set Manual Hotkey', '手動ホットキーを設定')
    bl_description = _lt('EN: Capture one recommended manual shortcut key. Esc cancels without changing the stored key. JP: 推奨する手動ショートカットキーを1つ取得します。Esc では保存済みキーを変更せず終了します。')
    bl_options = set()

    def _finish(self, context):
        cleanup_id = getattr(self, '_cleanup_id', None)
        self._cleanup_id = None
        if cleanup_id is not None:
            runtime_lifecycle.unregister_cleanup(cleanup_id, run=False)
        _set_capture_flag('capturing_key', False)
        area = getattr(context, 'area', None)
        if area is not None:
            try:
                area.tag_redraw()
            except Exception:
                pass

    def modal(self, context, event):
        if not runtime_lifecycle.is_current(getattr(self, '_generation', -1)):
            self._finish(context)
            return {'CANCELLED'}
        if event.type == 'ESC':
            self._finish(context)
            return {'CANCELLED'}
        if event.value == 'PRESS' and event.type not in {'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL', 'LEFT_ALT', 'RIGHT_ALT'}:
            _nodecolor_set('pie_menu_hotkey', event.type, context)
            self._finish(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, _event):
        self._generation = runtime_lifecycle.generation_token()
        if not runtime_lifecycle.is_current(self._generation):
            return {'CANCELLED'}
        self._original_key = str(_nodecolor_pref_value('pie_menu_hotkey', context) or '')
        _set_capture_flag('capturing_key', True)
        self._cleanup_id = runtime_lifecycle.register_cleanup(
            lambda: _set_capture_flag('capturing_key', False))
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish(context)
            return {'CANCELLED'}
        area = getattr(context, 'area', None)
        if area is not None:
            try:
                area.tag_redraw()
            except Exception:
                pass
        return {'RUNNING_MODAL'}


class NODECOLOR_OT_set_quick_hotkey(bpy.types.Operator):
    bl_idname = 'nodecolor.set_quick_hotkey'
    bl_label = _lt('Set Manual Hotkey', '手動ホットキーを設定')
    bl_description = _lt('EN: Capture one recommended quick-pie shortcut key. Esc cancels without changing the stored key. JP: 推奨するクイックパイ用ショートカットキーを1つ取得します。Esc では保存済みキーを変更せず終了します。')
    bl_options = set()

    def _finish(self, context):
        cleanup_id = getattr(self, '_cleanup_id', None)
        self._cleanup_id = None
        if cleanup_id is not None:
            runtime_lifecycle.unregister_cleanup(cleanup_id, run=False)
        _set_capture_flag('capturing_key_2', False)
        area = getattr(context, 'area', None)
        if area is not None:
            try:
                area.tag_redraw()
            except Exception:
                pass

    def modal(self, context, event):
        if not runtime_lifecycle.is_current(getattr(self, '_generation', -1)):
            self._finish(context)
            return {'CANCELLED'}
        if event.type == 'ESC':
            self._finish(context)
            return {'CANCELLED'}
        if event.value == 'PRESS' and event.type not in {'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL', 'LEFT_ALT', 'RIGHT_ALT'}:
            _nodecolor_set('pie_menu_hotkey_2', event.type, context)
            self._finish(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, _event):
        self._generation = runtime_lifecycle.generation_token()
        if not runtime_lifecycle.is_current(self._generation):
            return {'CANCELLED'}
        self._original_key = str(_nodecolor_pref_value('pie_menu_hotkey_2', context) or '')
        _set_capture_flag('capturing_key_2', True)
        self._cleanup_id = runtime_lifecycle.register_cleanup(
            lambda: _set_capture_flag('capturing_key_2', False))
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish(context)
            return {'CANCELLED'}
        area = getattr(context, 'area', None)
        if area is not None:
            try:
                area.tag_redraw()
            except Exception:
                pass
        return {'RUNNING_MODAL'}

class SIMPLE_OT_main_panel(bpy.types.Operator):
    bl_idname = 'wm.main_panel'
    bl_label = _lt('Main Panel', 'メインパネル')
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return getattr(getattr(context, 'area', None), 'type', None) == 'NODE_EDITOR'

    def execute(self, context):
        if not bpy.ops.wm.call_menu_pie.poll():
            self.report({'WARNING'}, _lt('A node editor window is required', 'ノードエディターが必要です'))
            return {'CANCELLED'}
        bpy.ops.wm.call_menu_pie(name='NODE_MT_precise_node_color_pie')
        return {'FINISHED'}

class SIMPLE_OT_open_quick_color_pie(bpy.types.Operator):
    bl_idname = 'wm.open_quick_color_pie'
    bl_label = _lt('Open Quick Color Pie', 'クイックカラーパイを開く')
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return getattr(getattr(context, 'area', None), 'type', None) == 'NODE_EDITOR'

    def execute(self, context):
        if not bpy.ops.wm.call_menu_pie.poll():
            self.report({'WARNING'}, _lt('A node editor window is required', 'ノードエディターが必要です'))
            return {'CANCELLED'}
        bpy.ops.wm.call_menu_pie(name='NODE_MT_quick_node_color_pie')
        return {'FINISHED'}

def _nodecolor_hotkeys_enabled(context=None):
    _ = context
    return False


def _nodecolor_prune_empty_keymaps():
    return None


def register_keymap():
    return None


def sync_keymap_state(context=None):
    _ = context
    return None


def unregister_keymap():
    return None

_nodecolor_classes = (
    NodeColorTools,
    NODE_OT_set_slot_color,
    NODE_OT_remove_color,
    NODE_OT_copy_active_node_color,
    NODE_OT_set_random_color,
    NODE_MT_precise_node_color_pie,
    NODE_MT_quick_node_color_pie,
    NODE_OT_set_preset_color,
    SIMPLE_OT_main_panel,
    SIMPLE_OT_open_quick_color_pie,
    NODECOLOR_OT_set_manual_hotkey,
    NODECOLOR_OT_set_quick_hotkey,
    NODECOLOR_OT_toggle_runtime_flag,
)
_registered_nodecolor_class_tokens = []
_owned_nodecolor_property = None


def register():
    global _owned_nodecolor_property
    if _registered_nodecolor_class_tokens or _owned_nodecolor_property is not None:
        return
    _reset_capture_flags()
    try:
        # 1.4.14 could leave this pointer behind when its descriptor token no
        # longer matched after an in-process reload.  Release only when the
        # current fixed type is the exact prior Smart Node class provenance.
        rna_ownership.release_legacy_pointer_property(
            bpy.types.Scene, 'node_color_tools', NodeColorTools
        )
        _registered_nodecolor_class_tokens.extend(
            rna_ownership.register_classes(_nodecolor_classes)
        )
        _owned_nodecolor_property = rna_ownership.install_property(
            bpy.types.Scene,
            'node_color_tools',
            bpy.props.PointerProperty(
                type=NodeColorTools,
                description=_lt('JP: Node Color Tools のNパネル状態です。プリセット色は Smart Node の単一JSON設定へ保存されます。\nEN: N-panel state for Node Color Tools. Preset colors are saved in the single Smart Node JSON settings authority.'),
            ),
        )
    except Exception:
        unregister()
        raise


def unregister():
    global _owned_nodecolor_property
    _reset_capture_flags()
    try:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        save_node_color_settings(getattr(scene, 'node_color_tools', None), context=getattr(bpy, 'context', None))
    except Exception:
        pass
    token = _owned_nodecolor_property
    _owned_nodecolor_property = None
    if token is not None:
        try:
            rna_ownership.remove_property(token)
        except Exception:
            pass
    rna_ownership.unregister_classes(_registered_nodecolor_class_tokens)

