# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
import os
from collections import OrderedDict
from bpy.types import Panel, Menu
from bpy.props import EnumProperty, StringProperty
from bpy.app.translations import contexts as i18n_contexts

from .utils.constants import blend_types, geo_combine_operations, operations
from .utils.nodes import get_nodes_links, SNSBaseMenu
from .utils.layout_grid import addon_preferences
from .addon_owner import addon_owner_id
from . import manager_rules, node_presets, rna_ownership, ui_sections


def socket_to_icon(socket):
    socket_type = socket.type

    if socket_type == "CUSTOM":
        return "RADIOBUT_OFF"

    if socket_type == "VALUE":
        socket_type = "FLOAT"

    return "NODE_SOCKET_" + socket_type



# ------------------------------------------------------------------------------
# Smart Node N-panel section UI
# ------------------------------------------------------------------------------
from .i18n import t as _t, tip as _tip

_SECTION_DEFS = {
    'always_on': {
        'label': 'Always-on Toggles',
        'ja': '常時機能切り替え',
        'icon': 'TIME',
        'default': False,
        'help': (
            'Settings that affect how this add-on runs. You rarely need to change them. N-panel State Save stores the settings and the open or closed sections. Legacy Proxy Cleanup shows a button that removes old management data. Noise Node Compatibility makes Run One-shot Sync available. Node Wrangler Override keeps a compatibility setting.',
            'このアドオンの動きに関わる設定を切り替えます。ふだんは触らなくてかまいません。「Nパネル状態保存」は設定と見出しの開閉の保存、「旧プロキシ整理」は古い管理用データを片づけるボタンの表示、「ノイズノード互換ツール」は「1回同期を実行」を使えるようにする切り替え、「Node Wrangler 上書き」は互換の設定を残すための切り替えです。',
        ),
    },
    'overview': {
        'label': 'Overview',
        'ja': '概要',
        'icon': 'NODETREE',
        'default': False,
        'help': (
            'Smart Node is a node-editor sidebar that keeps the original workflow functions and adds graph layout and management tools. Use the groups from top to bottom: build or merge nodes, wire them, label them, arrange the graph, then clean up management tasks. While no node tree is open, the node buttons stay visible but cannot be pressed.',
            'Smart Node は、従来のノード作業機能を維持しながら、グラフ整列と管理機能を追加したノードエディター用サイドバーです。上から順に、ノード作成/結合、配線、ラベル、グラフ整列、管理/クリーンアップを行います。ノードツリーを開いていない時は、ノードを操作するボタンは見えていても押せません。',
        ),
    },
    'view': {
        'label': 'Node Editor View',
        'ja': 'ノードエディター表示',
        'icon': 'HIDE_OFF',
        'default': False,
        'help': (
            'Use this section to quickly adjust node-editor view settings such as grid color, background color, grid subdivision level, wire colors, and noodle curvature. The values are applied to the active Blender theme, so press Read before editing when you want to start from your current theme.',
            'このセクションでは、グリッドカラー、背景色、グリッド分割レベル、ワイヤカラー、リンク曲線など、ノードエディターの表示設定を簡単に変更します。値は現在の Blender テーマへ適用されるため、現在のテーマ値を基準にする場合は先に「読み込み」を押します。',
        ),
    },
    'merge': {
        'label': 'Merge / Composite Nodes',
        'ja': '結合 / 合成ノード',
        'icon': 'NODETREE',
        'default': False,
        'help': (
            'Use this section to insert Mix, Math, Shader, Geometry, Alpha Over, or Depth Combine nodes between selected nodes. Select two or more nodes, then choose the merge method that matches the current node tree type.',
            'このセクションでは、選択ノード間に ミックス、数式、シェーダー、ジオメトリ、アルファオーバー、深度で合成 などの結合ノードを挿入します。2つ以上のノードを選択し、現在のノードツリー種別に合う結合方法を選びます。',
        ),
    },
    'texture': {
        'label': 'Texture Setup',
        'ja': 'テクスチャ設定',
        'icon': 'TEXTURE',
        'default': False,
        'help': (
            'Use this section to create image texture setups, import image sequences, or build a Principled BSDF texture network from named texture maps. It is most useful in Shader node trees. Noise Node Compatibility is switched in Always-on Toggles.',
            'このセクションでは、画像テクスチャ設定、画像シーケンス読み込み、命名済みテクスチャマップからの Principled BSDF ネットワーク構築を行います。主にシェーダーノードツリーで有効です。「ノイズノード互換ツール」は「常時機能切り替え」で有効にします。',
        ),
    },
    'links': {
        'label': 'Links / Reroutes',
        'ja': 'リンク / リルート',
        'icon': 'LINKED',
        'default': False,
        'help': (
            'Use this section to detach outputs, swap links, add reroute nodes, link the active node to selected nodes, or connect the active node to an output. Use it when rebuilding node wiring without deleting nodes.',
            'このセクションでは、出力切り離し、リンク入れ替え、リルート追加、アクティブノードから選択ノードへのリンク、出力ノードへの接続を行います。ノードを削除せず配線を組み直す時に使います。',
        ),
    },
    'labels': {
        'label': 'Labels / Batch',
        'ja': 'ラベル / 一括変更',
        'icon': 'GREASEPENCIL',
        'default': False,
        'help': (
            'Use this section to clear, modify, or copy node labels, batch-change Mix and Math node operations, and adjust mix factors from compact buttons. These tools keep large graphs readable and consistent.',
            'このセクションでは、ノードラベルのクリア、変更、コピー、ミックス / 数式ノードの演算の一括変更、ミックス係数の簡易調整を行います。大きなグラフを読みやすく一貫した状態に保ちます。',
        ),
    },
    'layout': {
        'label': 'Layout / Arrange',
        'ja': 'レイアウト / 整列',
        'icon': 'CENTER_ONLY',
        'default': True,
        'help': (
            'Use this section for graph arrangement. Lay Out Children follows the selected parent branch, Move Linked Branch offsets parent/child branches together, Lay Out All arranges the full tree, stream-aware/stack tools preserve branch readability, and align/distribute/snap/reroute tools clean manual placement.',
            'このセクションでは、グラフ配置を整理します。「子を整列」は選択した親ブランチをたどり、「リンクブランチを移動」は親子ブランチをまとめてオフセットし、「すべて整列」はツリー全体を整理します。ストリーム整列、スタック、端整列、均等配置、グリッドスナップ、リルート最適化は手動配置の仕上げに使います。',
        ),
    },
    'selection': {
        'label': 'Selection / Branches',
        'ja': '選択 / ブランチ',
        'icon': 'RESTRICT_SELECT_OFF',
        'default': False,
        'help': (
            'Use this section to select upstream, downstream, connected, source, sink, or same-type nodes. It also creates backdrop-style Blender frames (Create Backdrop Frame frames the selected nodes only; Frame Upstream, Frame Downstream, and Frame Connected also include the linked nodes; a frame that holds only those nodes goes into the new frame as it is), collapses dense node cards, and toggles mute state for branch management. Select by Text opens a dialog where you enter the search text.',
            'このセクションでは、上流、下流、接続全体、ソース、終端、同タイプのノードを選択します。さらに、バックドロップ風の Blender フレーム作成（「背景フレームを作成」は選択ノードだけ、「上流まで囲む」「下流まで囲む」「接続全体を囲む」はつながるノードも一緒に囲みます。囲むノードだけが入った既存のフレームは、そのまま新しいフレームの中に入ります）、密なノードカードの折りたたみ、ブランチのミュート切替も行えます。「文字で選択」は、押すと開く画面に検索文字を入れて使います。',
        ),
    },
    'manage': {
        'label': 'Node Management',
        'ja': 'ノード管理',
        'icon': 'FILE_REFRESH',
        'default': False,
        'help': (
            'Use this section for maintenance: reload image nodes, reset compositor backdrop, frame selected nodes, reset active nodes, save viewer images, and delete unused nodes or empty frames. Rename Selected Nodes opens a dialog for the new name, prefix, suffix, find/replace, and numbering. Color Nodes gives the selected nodes (all nodes if nothing is selected) one shared marker color (blue) and does not color nodes by type; use Color 1 to Color 5 in Node Color Presets for other colors.',
            'このセクションでは、画像ノードの再読み込み、コンポジター背景リセット、選択ノードのフレーム化、アクティブノードのリセット、ビューアー画像保存、未使用ノードや空フレームの削除などの保守を行います。「選択ノードをリネーム」は、押すと開く画面で新規名、接頭辞、接尾辞、検索/置換、連番を指定します。「ノード色を適用」は選択ノード（何も選んでいない時は全ノード）を同じ1色（青）の目印にします。種類ごとの色分けはしません。別の色は「ノード色プリセット」の「色\u00a01」〜「色\u00a05」で付けます。',
        ),
    },
}
_SECTION_ORDER = ('always_on', 'overview', 'view', 'merge', 'texture', 'links', 'labels', 'layout', 'selection', 'manage')


def _section_prop(key: str) -> str:
    clean = ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(key or '')).strip('_')
    return f'smart_node_suite_section_{clean}' if clean else 'smart_node_suite_section_unknown'


def _section_state(context, key: str) -> bool:
    info = _SECTION_DEFS.get(key, {})
    default = bool(info.get('default', False))
    try:
        prop_name = _section_prop(key)
        if hasattr(context.window_manager, prop_name):
            return bool(getattr(context.window_manager, prop_name))
        return bool(context.window_manager.get(prop_name, default))
    except Exception:
        return default


def _set_section_state(context, key: str, value: bool) -> None:
    try:
        prop_name = _section_prop(key)
        if hasattr(context.window_manager, prop_name):
            setattr(context.window_manager, prop_name, bool(value))
        else:
            context.window_manager[prop_name] = bool(value)
    except Exception:
        pass
    try:
        from . import persistent_settings
        persistent_settings.request_save(context, force=False)
    except Exception:
        pass


class SNS_OT_toggle_section(bpy.types.Operator):
    bl_idname = 'smart_node_suite.toggle_section'
    bl_label = 'Toggle Smart Node Section'
    bl_description = _tip(
        'Function: opens or closes one Smart Node section in the N-panel. How to use: click the triangle at the left of a section header; the open/closed state is stored for the current Blender session.',
        '機能: Nパネル内の Smart Node セクションを開閉します。使い方: セクション見出し左側の三角アイコンをクリックします。開閉状態は現在の Blender セッション中に保持されます。',
    )
    bl_options = {'INTERNAL'}

    key: StringProperty(name='Section Key', description=_tip('Function: internal key for the section to toggle. How to use: this is filled automatically by the section header button.', '機能: 開閉するセクションの内部キーです。使い方: セクション見出しボタンが自動設定するため通常は編集不要です。'))

    def execute(self, context):
        key = str(self.key or '')
        _set_section_state(context, key, not _section_state(context, key))
        return {'FINISHED'}




class SNS_OT_toggle_migrated_group(bpy.types.Operator):
    bl_idname = 'smart_node_suite.toggle_migrated_group'
    bl_label = 'Toggle Smart Node Tool Group'
    bl_description = _tip(
        'Function: opens or closes an integrated migrated node-tool group inside an existing Smart Node section. How to use: click the triangle in the group header; this only changes the display state and does not alter node data.',
        '機能: 既存の Smart Node セクション内に統合された移植済みノードツールグループを開閉します。使い方: グループ見出しの三角アイコンをクリックします。表示状態のみを変え、ノードデータは変更しません。',
    )
    bl_options = {'INTERNAL'}

    key: StringProperty(name='Group Key', description=_tip('Function: internal key for the integrated tool group. How to use: this is filled automatically by the group header button.', '機能: 統合ツールグループ用の内部キーです。使い方: グループ見出しボタンが自動設定するため通常は編集不要です。'))

    def execute(self, context):
        clean = ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(self.key or '')).strip('_') or 'group'
        prop = 'smart_node_suite_migrated_group_' + clean
        try:
            current = bool(context.window_manager.get(prop, True))
            context.window_manager[prop] = not current
        except Exception:
            pass
        return {'FINISHED'}


class SNS_OT_section_help(bpy.types.Operator):
    bl_idname = 'smart_node_suite.section_help'
    bl_label = 'Smart Node Section Help'
    bl_description = _tip(
        'Function: opens beginner-friendly help for the selected Smart Node section. How to use: click the question-mark icon at the right of a section header to see what that group does and when to use it.',
        '機能: 選択した Smart Node セクションの初心者向けヘルプを開きます。使い方: セクション見出し右側の「？」アイコンをクリックし、そのグループの機能と使いどころを確認します。',
    )
    bl_options = {'INTERNAL'}

    key: StringProperty(name='Section Key', description=_tip('Function: internal key for the help topic. How to use: this is filled automatically by the question-mark button.', '機能: ヘルプトピックの内部キーです。使い方: 「？」ボタンが自動設定するため通常は編集不要です。'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=680)

    def draw(self, context):
        import textwrap
        layout = self.layout
        info = _SECTION_DEFS.get(str(self.key or ''), _SECTION_DEFS['overview'])
        title = _t(info.get('label', 'Smart Node'), info.get('ja'))
        layout.label(text=title, icon=info.get('icon', 'QUESTION'))
        layout.separator()
        help_en, help_ja = info.get('help', ('Smart Node help.', 'Smart Node ヘルプです。'))
        text = _t(help_en, help_ja)
        for line in textwrap.wrap(text, width=54 if _t('en', 'ja') == 'ja' else 78):
            layout.label(text=line)

    def execute(self, context):
        return {'FINISHED'}


def _populate_section_body(prepared):
    if not prepared or not bool(prepared.get('expanded')):
        return None
    body = prepared.get('body')
    if body is not None:
        return body
    box = prepared.get('box')
    if box is None:
        return None
    body = box.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    prepared['body'] = body
    return body


def _draw_section_header(layout, context, key: str, *, container=None, defer_body: bool = False):
    info = _SECTION_DEFS.get(key, {})
    label = _t(info.get('label', key), info.get('ja'))
    expanded = _section_state(context, key)
    box = container if container is not None else layout.box()
    # Shared Smart Tools section header (arrow, borderless icon+title, gap, compact help) lives in ui_sections.draw_group.
    ui_sections.draw_group(box, context, key, label, topic=key, expanded=bool(expanded), toggle_idname='smart_node_suite.toggle_section', heading_icon=info.get('icon', 'NONE'), translate=True, with_body=False)
    prepared = {
        'box': box,
        'expanded': bool(expanded),
        'body': None,
    }
    if defer_body:
        return prepared
    return _populate_section_body(prepared)


def _draw_runtime_toggle_row(layout, context, owner, prop_name: str, label_en: str, label_ja: str) -> bool:
    if owner is None or not hasattr(owner, prop_name):
        return False
    try:
        enabled = bool(getattr(owner, prop_name))
    except Exception:
        enabled = False
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=_t(label_en, label_ja))
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    right.row(align=True).prop(
        owner,
        prop_name,
        text=_t('On', '有効') if enabled else _t('Off', '無効'),
        icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
        toggle=True,
    )
    return True


def _draw_always_on_group(body, context) -> None:
    if body is None:
        return
    wm = getattr(context, 'window_manager', None)
    _draw_runtime_toggle_row(body, context, wm, 'smart_node_suite_npanel_state_save', 'N-panel State Save', 'Nパネル状態保存')
    try:
        body.separator(factor=0.5)
    except Exception:
        pass
    legacy_enabled = bool(getattr(wm, 'smart_node_suite_legacy_cleanup_enabled', False)) if wm is not None else False
    _draw_runtime_toggle_row(body, context, wm, 'smart_node_suite_legacy_cleanup_enabled', 'Legacy Proxy Cleanup', '旧プロキシ整理')
    if legacy_enabled:
        row = body.row(align=True)
        row.operator(
            'smart_node_suite.run_legacy_cleanup',
            text=_t('Run Legacy Cleanup Once', '旧プロキシ整理を1回実行'),
            icon='BRUSH_DATA',
        )
    _draw_runtime_toggle_row(body, context, wm, 'noise_nodes_background_callbacks', 'Noise Node Compatibility', 'ノイズノード互換ツール')
    _draw_runtime_toggle_row(body, context, wm, 'noise_nodes_node_wrangler_override', 'Node Wrangler Override', 'Node Wrangler 上書き')


def drawlayout(context, layout, mode='non-panel'):
    _draw_smart_panel(context, layout, mode=mode)




def _has_rna_property(data, name: str) -> bool:
    if data is None or not name:
        return False
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        if props is None:
            return False
        try:
            return props.get(name) is not None
        except Exception:
            return str(name) in props.keys()
    except Exception:
        return False


def _draw_node_preset_tools(layout, context, *, inline_entries=True):
    # ``node_presets`` is imported once during deterministic registration. Draw
    # reads only its bounded string cache and never triggers module or asset scans.
    box = layout.box()
    box.label(text=_t('Node Presets', 'ノードプリセット'), icon='ASSET_MANAGER')
    prefs = addon_preferences(context)
    prop = 'integrated_node_presets_search_path'
    if prefs is not None and _has_rna_property(prefs, prop):
        folder = box.column(align=True)
        folder.label(text=_t('Folder', 'フォルダー'))
        folder.prop(prefs, prop, text='')
    current_path = node_presets.node_search_path(context)
    if not current_path:
        box.label(text=_t('Folder not set', 'フォルダー未設定'))
    box.operator('node_presets.choose_preset_folder', text=_t('Choose Folder', 'フォルダーを選択'), icon='FILE_FOLDER')
    row = box.row(align=True)
    row.operator('node_presets.clear_preset_folder', text=_t('Clear', '解除'), icon='X')
    row.operator('node_presets.refresh_preset_cache', text=_t('Refresh', '更新'), icon='FILE_REFRESH')
    box.menu('NODE_MT_node_template_menu', text=_t('Template Menu', 'テンプレートメニュー'), icon='NODETREE')
    if not inline_entries:
        return
    if not current_path:
        return
    if not node_presets.node_template_cache_ready(context):
        box.label(text=_t('Press Refresh to list', '「更新」で一覧を作成'))
        return
    items = node_presets.node_template_cache(context, reload=False)
    if not items:
        box.label(text=_t('No node groups found', 'ノードグループがありません'))
        return
    grouped = {}
    for filepath, group_name in items:
        try:
            filename = os.path.basename(filepath)
        except Exception:
            filename = str(filepath)
        grouped.setdefault(filename, []).append((filepath, group_name))
    entries = box.column(align=True)
    total = 0
    for filename in sorted(grouped.keys()):
        entries.label(text=filename, icon='FILE_BLEND', translate=False)
        col = entries.column(align=True)
        for filepath, group_name in sorted(grouped[filename], key=lambda item: str(item[1]).lower()):
            op = col.operator('node.add_node_group_template', text=str(group_name), icon='NODETREE', translate=False)
            op.filepath = filepath
            op.group_name = group_name
            total += 1
            if total >= 64:
                entries.label(text=_t('First 64 only; see the menu', '先頭 64 件のみ。全件はメニューへ'))
                return


def _draw_noise_node_tools(layout, context, tree_type: str):
    box = layout.box()
    box.enabled = tree_type in {'ShaderNodeTree', 'GeometryNodeTree'}
    box.label(text=_t('Noise Nodes', 'ノイズノード'), icon='TEXTURE')
    box.menu('NODE_MT_noise_node_menu', text=_t('Add Noise Node', 'ノイズノードを追加'), icon='NODETREE')
    box.operator('noise_nodes.sync_runtime', text=_t('Run One-shot Sync', '1回同期を実行'), icon='FILE_REFRESH')


def _stacked_prop(layout, data, prop_name: str, label: str) -> None:
    # The name goes above a dropdown so neither is cut at the default sidebar width.
    col = layout.column(align=True)
    col.label(text=label)
    col.prop(data, prop_name, text='')


def _draw_migrated_arrange_settings(layout, context):
    settings = getattr(getattr(context, 'scene', None), 'na_settings', None)
    if settings is None:
        return
    box = layout.box()
    box.label(text=_t('Node Arrange', 'ノード整列'), icon='NODETREE')
    box.prop(settings, 'margin', text=_t('Spacing', '間隔'))
    _stacked_prop(box, settings, 'direction', _t('Node Alignment', 'ノード配置'))
    _stacked_prop(box, settings, 'socket_alignment', _t('Socket Alignment', 'ソケット整列'))
    box.prop(settings, 'iterations', text=_t('Crossing Reduction', '交差削減の反復'))
    box.prop(settings, 'add_reroutes', text=_t('Add Reroutes', 'リルートを追加'))
    if getattr(settings, 'add_reroutes', False):
        box.prop(settings, 'keep_reroutes_outside_frames', text=_t('Place Reroutes Outside Frames', 'リルートをフレーム外へ配置'))
    box.prop(settings, 'stack_collapsed', text=_t('Stack Collapsed Nodes', '折りたたみノードを積み重ね'))
    if getattr(settings, 'stack_collapsed', False):
        box.prop(settings, 'stack_margin_y_fac', text=_t('Collapsed Stack Y', '積み重ねY係数'))
    _stacked_prop(box, settings, 'origin', _t('Recenter Origin', '再センター基準'))
    col = box.column(align=True)
    col.operator('node.arrange_selected_nodes', text=_t('Arrange Selected Nodes', '選択ノードを整列'), icon='CENTER_ONLY')
    col.operator('node.arrange_all_trees', text=_t('Arrange All Trees', '全ツリーを整列'), icon='NODETREE')
    col = box.column(align=True)
    col.operator('node.recenter_selected_nodes', text=_t('Recenter Selected', '選択を再センター'), icon='ORIENTATION_VIEW')
    col.operator('node.recenter_all_trees', text=_t('Recenter All Trees', '全ツリーを再センター'), icon='PIVOT_MEDIAN')


def _draw_migrated_node_color_tools(layout, context):
    data = getattr(getattr(context, 'scene', None), 'node_color_tools', None)
    if data is None:
        return
    box = layout.box()
    box.label(text=_t('Node Color Presets', 'ノード色プリセット'), icon='BRUSH_DATA')
    row = box.row(align=True)
    row.operator('node.set_random_color', text=_t('Random', 'ランダム'), icon='BRUSH_DATA')
    row.operator('node.copy_active_node_color', text=_t('Copy Active', '色をコピー'), icon='COPYDOWN')
    row = box.row(align=True)
    row.operator('wm.main_panel', text=_t('Precise Pie', '詳細パイ'), icon='PRESET')
    row.operator('wm.open_quick_color_pie', text=_t('Quick Pie', 'クイックパイ'), icon='PRESET')
    for index in range(1, 6):
        prop_name = f'nodecolor{index}'
        if not _has_rna_property(data, prop_name):
            continue
        row = box.row(align=True)
        row.prop(data, prop_name, text=_t(f'Color {index}', f'色 {index}'))
        op = row.operator('node.set_slot_color', text=_t('Apply', '適用'), icon='BRUSH_DATA')
        try:
            op.color = list(getattr(data, prop_name))
        except Exception:
            pass


_EDITOR_NAMES = {
    'VIEW_3D': ('3D Viewport', '3Dビューポート'),
    'IMAGE_EDITOR': ('Image Editor', '画像エディター'),
    'UV_EDITOR': ('UV Editor', 'UVエディター'),
    'SHADER_EDITOR': ('Shader Editor', 'シェーダーエディター'),
    'COMPOSITOR': ('Compositor', 'コンポジター'),
    'GEOMETRY_NODE_EDITOR': ('Geometry Node Editor', 'ジオメトリノードエディター'),
    'TEXTURE_NODE_EDITOR': ('Texture Node Editor', 'テクスチャノードエディター'),
    'VIDEO_SEQUENCER': ('Video Sequencer', 'ビデオシーケンサー'),
    'MOVIE_CLIP_EDITOR': ('Movie Clip Editor', 'ムービークリップエディター'),
    'DOPE_SHEET': ('Dope Sheet', 'ドープシート'),
    'GRAPH_EDITOR': ('Graph Editor', 'グラフエディター'),
    'DRIVERS': ('Drivers', 'ドライバー'),
    'NLA_EDITOR': ('Nonlinear Animation', 'ノンリニアアニメーション'),
    'TEXT_EDITOR': ('Text Editor', 'テキストエディター'),
    'ASSET_BROWSER': ('Asset Browser', 'アセットブラウザー'),
    'FILE_BROWSER': ('File Browser', 'ファイルブラウザー'),
    'SPREADSHEET': ('Spreadsheet', 'スプレッドシート'),
}
_TREE_TYPE_NAMES = {
    'ShaderNodeTree': ('Shader', 'シェーダー'),
    'CompositorNodeTree': ('Compositor', 'コンポジター'),
    'GeometryNodeTree': ('Geometry', 'ジオメトリ'),
    'TextureNodeTree': ('Texture', 'テクスチャ'),
}


def _display_name(names, key: str) -> str:
    pair = names.get(key)
    return _t(pair[0], pair[1]) if pair else '-'


def _draw_smart_panel(context, layout, mode='panel', *, section=None, layout_part=None):
    layout.operator_context = 'INVOKE_DEFAULT'
    layout.use_property_split = False
    layout.use_property_decorate = False
    if section is not None:
        info = _SECTION_DEFS[section]
        layout.label(text=_t(info['label'], info['ja']), icon=info['icon'])
        help_op = layout.operator('smart_node_suite.section_help', text=_t('Help', 'ヘルプ'), icon='QUESTION')
        help_op.key = section
        section_bodies = dict.fromkeys(_SECTION_ORDER)
        section_bodies[section] = layout.column(align=True)
    else:
        section_bodies = _draw_panel_sections(layout, context)
    _draw_panel_bodies(context, section_bodies, layout_part=layout_part, inline_presets=section is None)


def _draw_panel_sections(layout, context):
    # Allocate every root box and header before any expanded body. Blender 5.1
    # otherwise lets a populated nested layout shift later root siblings.
    top_slots = {
        key: layout.row(align=False)
        for key in _SECTION_ORDER
    }
    top_boxes = {
        key: top_slots[key].box()
        for key in _SECTION_ORDER
    }
    prepared_sections = {
        key: _draw_section_header(
            top_slots[key],
            context,
            key,
            container=top_boxes[key],
            defer_body=True,
        )
        for key in _SECTION_ORDER
    }
    return {
        key: _populate_section_body(prepared_sections[key])
        for key in _SECTION_ORDER
    }


def _draw_layout_actions(body):
    body.operator('smart_node_suite.arrange_children', text=_t('Lay Out Children', '子を整列'), icon='OUTLINER')
    body.operator('smart_node_suite.offset_branch', text=_t('Move Linked Branch', 'リンクブランチを移動'), icon='CENTER_ONLY')
    body.operator('smart_node_suite.lay_out_all', text=_t('Lay Out All', 'すべて整列'), icon='NODETREE')
    body.operator('smart_node_suite.layout_hierarchy', text=_t('Smart Hierarchy Layout', '階層整列'), icon='CENTER_ONLY')
    row = body.row(align=True)
    op = row.operator('smart_node_suite.sort_nodes', text=_t('Sort All', '全ソート'))
    op.mode = 'SMART'
    op = row.operator('smart_node_suite.sort_nodes', text=_t('Sort H', '水平ソート'))
    op.mode = 'HORIZONTAL'
    op = row.operator('smart_node_suite.sort_nodes', text=_t('Sort V', '垂直ソート'))
    op.mode = 'VERTICAL'
    body.operator('smart_node_suite.stream_aware_align', text=_t('Stream-Aware Align', 'ストリーム整列'), icon='CENTER_ONLY')
    body.operator('smart_node_suite.stack_nodes', text=_t('Stack Nodes', 'ノードを積む'), icon='CENTER_ONLY')
    row = body.row(align=True)
    row.operator('smart_node_suite.align_nodes', text=_t('Quick Align', 'クイック整列'), icon='CENTER_ONLY')
    row.operator('smart_node_suite.center_nodes', text=_t('Center', '中央へ'), icon='SNAP_FACE_CENTER')
    row = body.row(align=True)
    op = row.operator('smart_node_suite.align_edges', text=_t('Left', '左'))
    op.mode = 'LEFT'
    op = row.operator('smart_node_suite.align_edges', text=_t('Center X', '中央X'))
    op.mode = 'CENTER_X'
    op = row.operator('smart_node_suite.align_edges', text=_t('Right', '右'))
    op.mode = 'RIGHT'
    row = body.row(align=True)
    op = row.operator('smart_node_suite.align_edges', text=_t('Top', '上'))
    op.mode = 'TOP'
    op = row.operator('smart_node_suite.align_edges', text=_t('Center Y', '中央Y'))
    op.mode = 'CENTER_Y'
    op = row.operator('smart_node_suite.align_edges', text=_t('Bottom', '下'))
    op.mode = 'BOTTOM'
    row = body.row(align=True)
    op = row.operator('smart_node_suite.distribute_nodes', text=_t('Horizontal', '水平'))
    op.axis = 'HORIZONTAL'
    op = row.operator('smart_node_suite.distribute_nodes', text=_t('Vertical', '垂直'))
    op.axis = 'VERTICAL'
    body.operator('smart_node_suite.distribute_grid', text=_t('Distribute Node Grid', 'ノードをグリッド配置'), icon='MESH_GRID')
    body.operator('smart_node_suite.snap_to_grid', text=_t('Snap Nodes to Grid', 'ノードをグリッドへスナップ'), icon='SNAP_GRID')
    body.operator('smart_node_suite.swap_node_positions', text=_t('Swap Positions', '位置交換'), icon='UV_SYNC_SELECT')
    body.operator('smart_node_suite.optimize_reroute_links', text=_t('Optimize Link Reroutes', 'リルート最適化'), icon='LAYER_USED')


def _draw_panel_bodies(context, section_bodies, *, layout_part, inline_presets):
    _draw_always_on_group(section_bodies['always_on'], context)
    space = getattr(context, 'space_data', None)
    node_tree = getattr(space, 'node_tree', None) if space is not None else None
    edit_tree = getattr(space, 'edit_tree', None) if space is not None else None
    node_context = bool(
        space is not None
        and getattr(space, 'type', '') == 'NODE_EDITOR'
        and node_tree is not None
        and edit_tree is not None
    )
    tree_type = str(getattr(space, 'tree_type', '') or '') if node_context else ''
    logical_editor = manager_rules.logical_editor_key(context) or ''

    body = section_bodies['overview']
    if body is not None:
        body.label(text=f"{_t('Quick Access: Shift+W', 'クイックアクセス: Shift+W')}", icon='EVENT_W')
        body.label(text=_display_name(_EDITOR_NAMES, logical_editor), icon='WINDOW', translate=False)
        if node_context:
            nodes, _links = get_nodes_links(context)
            body.label(text=_t('Current Tree', '現在のツリー') + f": {_display_name(_TREE_TYPE_NAMES, tree_type)}", icon='NODETREE', translate=False)
            body.label(text=_t('Nodes', 'ノード数') + f": {len(nodes)}", icon='DOT', translate=False)
        else:
            body.label(text=_t('No node tree is open', 'ノードツリーを開いていません'))

    body = section_bodies['view']
    if body is not None:
        prefs = addon_preferences(context)
        if prefs is None:
            body.label(text=_t('Smart Node Suite preferences were not found.', 'Smart Node Suite 設定が見つかりません。'), icon='ERROR')
        else:
            row = body.row(align=True)
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Apply', '適用'), icon='CHECKMARK')
            op.action = 'APPLY'
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Read', '読み込み'), icon='IMPORT')
            op.action = 'READ'
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Reset', 'リセット'), icon='LOOP_BACK')
            op.action = 'RESET'
            row = body.row(align=True)
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Soft', 'ソフト'))
            op.action = 'SOFT'
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Strong', '強調'))
            op.action = 'STRONG'
            op = row.operator('smart_node_suite.node_view_settings', text=_t('Technical', 'テクニカル'))
            op.action = 'TECHNICAL'
            body.separator()
            body.prop(prefs, 'view_grid_color', text=_t('Grid Color', 'グリッドカラー'))
            body.prop(prefs, 'view_background_color', text=_t('Background Color', '背景色'))
            body.prop(prefs, 'view_grid_levels', text=_t('Grid Levels', 'グリッドレベル'))
            body.prop(prefs, 'view_show_advanced', text=_t('Advanced View Colors', '詳細表示カラー'))
            if prefs.view_show_advanced:
                body.prop(prefs, 'view_node_backdrop_color', text=_t('Node Backdrop Color', 'ノード背景色'))
                body.prop(prefs, 'view_wire_color', text=_t('Wire Color', 'ワイヤカラー'))
                body.prop(prefs, 'view_wire_select_color', text=_t('Selected Wire Color', '選択ワイヤカラー'))
                body.prop(prefs, 'view_selected_node_color', text=_t('Selected Node Color', '選択ノードカラー'))
                body.prop(prefs, 'view_active_node_color', text=_t('Active Node Color', 'アクティブノードカラー'))
                body.prop(prefs, 'view_noodle_curving', text=_t('Noodle Curving', 'リンク曲線'))
                body.prop(prefs, 'view_dash_alpha', text=_t('Dash Alpha', '破線アルファ'))

    body = section_bodies['merge']
    if body is not None:
        body.enabled = node_context
        body.menu(SNSMergeNodesMenu.bl_idname, icon='NODETREE')

    body = section_bodies['texture']
    if body is not None:
        shader_tools = body.column(align=True)
        shader_tools.enabled = node_context and tree_type == 'ShaderNodeTree'
        shader_tools.operator('smart_node_suite.add_texture', icon='NODE_SEL')
        shader_tools.operator('smart_node_suite.add_textures_for_principled', text=_t('Add Principled Texture Setup', 'プリンシプルテクスチャを追加'), icon='NODE_SEL')
        image_tools = body.column(align=True)
        image_tools.enabled = node_context and tree_type in {'ShaderNodeTree', 'CompositorNodeTree'}
        image_tools.operator('node.add_image', text=_t('Multiple Images', '複数画像'), icon='IMAGE_DATA')
        image_tools.operator('smart_node_suite.add_sequence', text=_t('Image Sequence', '画像シーケンス'), icon='FILE_IMAGE')
        preset_tools = body.column(align=True)
        preset_tools.enabled = node_context and tree_type in {'ShaderNodeTree', 'CompositorNodeTree', 'GeometryNodeTree'}
        _draw_node_preset_tools(preset_tools, context, inline_entries=inline_presets)
        noise_tools = body.column(align=True)
        noise_tools.enabled = node_context
        _draw_noise_node_tools(noise_tools, context, tree_type)

    body = section_bodies['links']
    if body is not None:
        body.enabled = node_context
        body.operator('smart_node_suite.detach_outputs', icon='UNLINKED')
        body.operator('smart_node_suite.swap_links', icon='UV_SYNC_SELECT')
        body.menu(SNSAddReroutesMenu.bl_idname, icon='LAYER_USED')
        body.menu(SNSLinkActiveToSelectedMenu.bl_idname, icon='LINKED')
        output_row = body.row(align=True)
        output_row.enabled = tree_type != 'GeometryNodeTree'
        output_row.operator('smart_node_suite.link_out', icon='DRIVER')

    body = section_bodies['labels']
    if body is not None:
        body.enabled = node_context
        row = body.row(align=True)
        row.operator('smart_node_suite.clear_label', icon='X').option = True
        row.operator('smart_node_suite.modify_labels', icon='GREASEPENCIL')
        body.menu(SNSBatchChangeNodesMenu.bl_idname, text=_t('Batch Change', '一括変更'), icon='FILE_REFRESH', text_ctxt=i18n_contexts.operator_default)
        body.menu(SNSCopyToSelectedMenu.bl_idname, icon='COPYDOWN')
        row = body.row(align=True)
        op = row.operator('smart_node_suite.factor', text='0.0')
        op.option = 0.0
        op = row.operator('smart_node_suite.factor', text='-0.1')
        op.option = -0.1
        op = row.operator('smart_node_suite.factor', text='+0.1')
        op.option = 0.1
        op = row.operator('smart_node_suite.factor', text='1.0')
        op.option = 1.0

    body = section_bodies['layout']
    if body is not None:
        body.enabled = node_context
        prefs = addon_preferences(context)
        if prefs is not None and layout_part in (None, 'GRID'):
            grid_box = body.box()
            grid_box.label(text=_t('Major Grid Layout Spacing', '太いグリッド基準のレイアウト間隔'), icon='MESH_GRID')
            grid_box.prop(prefs, 'layout_use_major_grid_spacing', text=_t('Use Major Grid Spacing', '太いグリッド間隔を使用'))
            if prefs.layout_use_major_grid_spacing:
                grid_box.prop(prefs, 'layout_major_grid_unit', text=_t('Major Grid Unit', '太いグリッド単位'))
                grid_box.prop(prefs, 'layout_column_major_steps', text=_t('Column Major Dots', '列の太い点数'))
                grid_box.prop(prefs, 'layout_row_major_steps', text=_t('Row Major Dots', '行の太い点数'))
                grid_box.prop(prefs, 'layout_min_gap_major_steps', text=_t('Minimum Bounds Gap Dots', '最小空き太点数'))
                _stacked_prop(grid_box, prefs, 'layout_spacing_reference', _t('Spacing Reference', '距離基準'))
                grid_box.prop(prefs, 'layout_snap_after_arrange', text=_t('Snap Result to Major Grid', '結果を太いグリッドへスナップ'))
            body.separator()
        if layout_part in (None, 'ARRANGE'):
            _draw_migrated_arrange_settings(body, context)
        if layout_part in (None, 'ACTIONS'):
            _draw_layout_actions(body)



    body = section_bodies['selection']
    if body is not None:
        body.enabled = node_context
        row = body.row(align=True)
        op = row.operator('smart_node_suite.select_linked_branch', text=_t('Upstream', '上流'), icon='TRIA_LEFT')
        op.direction = 'UPSTREAM'
        op = row.operator('smart_node_suite.select_linked_branch', text=_t('Downstream', '下流'), icon='TRIA_RIGHT')
        op.direction = 'DOWNSTREAM'
        op = body.operator('smart_node_suite.select_linked_branch', text=_t('Connected', '接続全体'), icon='LINKED')
        op.direction = 'BOTH'
        row = body.row(align=True)
        op = row.operator('smart_node_suite.select_terminal_nodes', text=_t('Source Nodes', 'ソースノード'))
        op.mode = 'SOURCES'
        op = row.operator('smart_node_suite.select_terminal_nodes', text=_t('Sinks', '終端'))
        op.mode = 'SINKS'
        body.operator('smart_node_suite.select_same_type', text=_t('Select Same Type', '同タイプを選択'), icon='RESTRICT_SELECT_OFF')
        body.operator('smart_node_suite.select_by_text', text=_t('Select by Text', '文字で選択'), icon='VIEWZOOM')
        row = body.row(align=True)
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Unlinked', '未接続'))
        op.state = 'UNCONNECTED'
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Muted', 'ミュート済み'))
        op.state = 'MUTED'
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Collapsed', '折りたたみ'))
        op.state = 'COLLAPSED'
        row = body.row(align=True)
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Framed', 'フレーム内'))
        op.state = 'FRAMED'
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Unframed', 'フレーム外'))
        op.state = 'UNFRAMED'
        op = row.operator('smart_node_suite.select_graph_state', text=_t('Reroutes', 'リルート'))
        op.state = 'REROUTES'
        op = body.operator('smart_node_suite.frame_branch', text=_t('Create Backdrop Frame', '背景フレームを作成'), icon='STICKY_UVS_LOC')
        op.scope = 'SELECTED'
        row = body.row(align=True)
        op = row.operator('smart_node_suite.frame_branch', text=_t('Frame Upstream', '上流まで囲む'))
        op.scope = 'UPSTREAM'
        op = row.operator('smart_node_suite.frame_branch', text=_t('Frame Downstream', '下流まで囲む'))
        op.scope = 'DOWNSTREAM'
        op = body.operator('smart_node_suite.frame_branch', text=_t('Frame Connected', '接続全体を囲む'))
        op.scope = 'BOTH'
        body.operator('smart_node_suite.hide_child_tree', text=_t('Hide / Show Child Tree', '子ツリー 表示/非表示'), icon='HIDE_OFF')
        body.operator('smart_node_suite.hide_unused_sockets', text=_t('Hide / Show Unused Sockets', '未使用ソケット 表示/非表示'), icon='HIDE_OFF')
        row = body.row(align=True)
        op = row.operator('smart_node_suite.collapse_expand_nodes', text=_t('Collapse', '折りたたむ'))
        op.action = 'COLLAPSE'
        op = row.operator('smart_node_suite.collapse_expand_nodes', text=_t('Expand', '展開'))
        op.action = 'EXPAND'
        row = body.row(align=True)
        op = row.operator('smart_node_suite.mute_unmute_nodes', text=_t('Mute', 'ミュート'))
        op.action = 'MUTE'
        op = row.operator('smart_node_suite.mute_unmute_nodes', text=_t('Unmute', 'ミュート解除'))
        op.action = 'UNMUTE'

    body = section_bodies['manage']
    if body is not None:
        body.enabled = node_context
        material_row = body.row(align=True)
        material_row.enabled = tree_type == 'ShaderNodeTree'
        material_row.operator('smart_node_suite.select_material_users', text=_t('Select Objects Using Material', 'マテリアル使用オブジェクトを選択'), icon='MATERIAL')
        backdrop_row = body.row(align=True)
        backdrop_row.enabled = tree_type == 'CompositorNodeTree'
        backdrop_row.operator('smart_node_suite.bg_reset', icon='ZOOM_PREVIOUS')
        reload_row = body.row(align=True)
        reload_row.enabled = tree_type != 'GeometryNodeTree'
        reload_row.operator('smart_node_suite.reload_images', icon='FILE_REFRESH')
        body.operator('node.join', text=_t('Frame Selected Nodes', '選択ノードをフレーム化'), icon='STICKY_UVS_LOC')
        body.operator('smart_node_suite.free_from_frame', text=_t('Free From Frame', 'フレームから外す'), icon='STICKY_UVS_DISABLE')
        body.operator('smart_node_suite.rename_selected_nodes', text=_t('Rename Selected Nodes', '選択ノードをリネーム'), icon='SORTALPHA')
        row = body.row(align=True)
        op = row.operator('smart_node_suite.color_nodes', text=_t('Color Nodes', 'ノード色を適用'))
        op.action = 'APPLY'
        op = row.operator('smart_node_suite.color_nodes', text=_t('Reset Color', '色をリセット'))
        op.action = 'RESET'
        _draw_migrated_node_color_tools(body, context)
        body.operator('smart_node_suite.bypass_delete_nodes', text=_t('Bypass Delete Selected', 'バイパス削除'), icon='CANCEL')
        body.operator('smart_node_suite.reset_nodes', icon='FILE_REFRESH')
        viewer_row = body.row(align=True)
        viewer_row.enabled = tree_type == 'CompositorNodeTree'
        viewer_row.operator('smart_node_suite.save_viewer', icon='FILE_IMAGE')
        body.operator('smart_node_suite.del_unused', icon='CANCEL')



class SMART_NODE_SUITE_OT_run_legacy_cleanup(bpy.types.Operator):
    bl_idname = 'smart_node_suite.run_legacy_cleanup'
    bl_label = _t('Run Legacy Cleanup Once', '旧プロキシ整理を1回実行')
    bl_description = _tip(
        'Function: removes only old management data that Smart Node itself created and that matches exactly. How to use: enable Legacy Proxy Cleanup, click once, check the result, then save normally in Blender. One Undo restores the changes. Nothing keeps running afterwards.',
        '機能: Smart Node 自身が作った古い管理用データのうち、完全に一致する物だけを片づけます。使い方: 「旧プロキシ整理」を有効にして1回実行し、結果を確かめてから Blender で保存します。1回の Undo で戻せます。実行後に動き続ける処理はありません。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        wm = getattr(context, 'window_manager', None)
        return bool(getattr(wm, 'smart_node_suite_legacy_cleanup_enabled', False)) if wm is not None else False

    def execute(self, context):
        try:
            from . import legacy_cleanup
            removed = int(legacy_cleanup.cleanup_before_save(context))
            report = legacy_cleanup.last_report()
            if report.get('phase') not in {'complete'}:
                raise RuntimeError(str(report.get('error') or report.get('phase') or 'cleanup failed'))
        except Exception as exc:
            self.report(
                {'ERROR'},
                _t(
                    f'Legacy proxy cleanup failed: {exc}',
                    '旧プロキシ整理に失敗しました。',
                ),
            )
            return {'CANCELLED'}
        self.report(
            {'INFO'},
            _t(
                f'Legacy proxy cleanup completed; removed {removed} owned metadata record(s).',
                f'旧プロキシ整理が完了し、所有確認済みメタデータを {removed} 件削除しました。',
            ),
        )
        return {'FINISHED'}



class _SmartNodeRootPanelMixin:
    def draw_header_preset(self, context):
        op = self.layout.operator('smart_node_suite.section_help', text='', icon='QUESTION')
        op.key = 'overview'

    bl_label = 'Smart Node'
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys: tuple[str, ...] = ()
    bl_description = _tip(
        'Function: shows the Smart Node sidebar in the current editor when Smart Tools Manager allows it there. How to use: enable Smart Node for this workspace/editor in Smart Tools Manager, press N, choose Smart Node, and expand the required section. Node-only commands stay visible but disabled outside an editable node tree.',
        '機能: Smart Tools Manager で使う設定になっているエディターに、Smart Node のサイドバーを表示します。使い方: Smart Tools Manager で現在のワークスペース/エディターの Smart Node を有効にし、N キーから Smart Node タブを選んで必要なセクションを展開します。ノード専用コマンドは編集可能なノードツリー外でも表示を維持し、無効状態になります。',
    )

    @classmethod
    def poll(cls, context):
        return manager_rules.panel_poll(
            context,
            physical_space=str(cls.bl_space_type),
            logical_keys=tuple(cls._smart_tools_manager_editor_keys),
        )

    def draw(self, context):
        _draw_smart_panel(context, self.layout, mode='panel')
        return None


class VIEW3D_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'VIEW3D_PT_smart_node_suite'
    bl_space_type = 'VIEW_3D'
    _smart_tools_manager_editor_keys = ('VIEW_3D',)


class IMAGE_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'IMAGE_PT_smart_node_suite'
    bl_space_type = 'IMAGE_EDITOR'
    _smart_tools_manager_editor_keys = ('IMAGE_EDITOR', 'UV_EDITOR')


class NODE_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'NODE_PT_smart_node_suite'
    bl_space_type = 'NODE_EDITOR'
    _smart_tools_manager_editor_keys = (
        'SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR',
    )

    prepend: StringProperty(name='prepend', description=_tip('Function: internal menu helper field. How to use: Smart Node fills this automatically when drawing menus.', '機能: メニュー描画用の内部補助フィールドです。使い方: Smart Node が自動設定するため手動編集は不要です。'))
    append: StringProperty(name='append', description=_tip('Function: internal menu helper field. How to use: Smart Node fills this automatically when drawing menus.', '機能: メニュー描画用の内部補助フィールドです。使い方: Smart Node が自動設定するため手動編集は不要です。'))
    remove: StringProperty(name='remove', description=_tip('Function: internal menu helper field. How to use: Smart Node fills this automatically when drawing menus.', '機能: メニュー描画用の内部補助フィールドです。使い方: Smart Node が自動設定するため手動編集は不要です。'))


class SEQUENCER_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'SEQUENCER_PT_smart_node_suite'
    bl_space_type = 'SEQUENCE_EDITOR'
    _smart_tools_manager_editor_keys = ('VIDEO_SEQUENCER',)


class CLIP_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'CLIP_PT_smart_node_suite'
    bl_space_type = 'CLIP_EDITOR'
    _smart_tools_manager_editor_keys = ('MOVIE_CLIP_EDITOR',)


class DOPESHEET_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'DOPESHEET_PT_smart_node_suite'
    bl_space_type = 'DOPESHEET_EDITOR'
    _smart_tools_manager_editor_keys = ('DOPE_SHEET',)


class GRAPH_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'GRAPH_PT_smart_node_suite'
    bl_space_type = 'GRAPH_EDITOR'
    _smart_tools_manager_editor_keys = ('GRAPH_EDITOR', 'DRIVERS')


class NLA_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'NLA_PT_smart_node_suite'
    bl_space_type = 'NLA_EDITOR'
    _smart_tools_manager_editor_keys = ('NLA_EDITOR',)


class TEXT_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'TEXT_PT_smart_node_suite'
    bl_space_type = 'TEXT_EDITOR'
    _smart_tools_manager_editor_keys = ('TEXT_EDITOR',)


class FILEBROWSER_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'FILEBROWSER_PT_smart_node_suite'
    bl_space_type = 'FILE_BROWSER'
    _smart_tools_manager_editor_keys = ('FILE_BROWSER',)


class ASSETBROWSER_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_idname = 'ASSETBROWSER_PT_smart_node_suite'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_options = {'DEFAULT_CLOSED'}
    _smart_tools_manager_editor_keys = ('ASSET_BROWSER',)


class SPREADSHEET_PT_smart_node_suite(_SmartNodeRootPanelMixin, Panel):
    bl_region_type = 'UI'
    bl_category = 'Smart Node'
    _smart_tools_manager_tool_key = 'SMART_NODE'
    _smart_tools_manager_native_npanel_root = True
    bl_idname = 'SPREADSHEET_PT_smart_node_suite'
    bl_space_type = 'SPREADSHEET'
    _smart_tools_manager_editor_keys = ('SPREADSHEET',)


#
#  M E N U S
#
class SNS_OT_open_menu_section(bpy.types.Operator):
    bl_idname = 'smart_node_suite.open_menu_section'
    bl_label = 'Smart Node'
    bl_options = {'INTERNAL'}

    key: StringProperty(default='overview', options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, _event):
        if self.key not in _SECTION_DEFS:
            return {'CANCELLED'}
        return context.window_manager.invoke_popup(self, width=540)

    layout_part: EnumProperty(
        items=(
            ('ACTIONS', 'Actions', ''),
            ('GRID', 'Grid', ''),
            ('ARRANGE', 'Node Arrange', ''),
        ),
        options={'SKIP_SAVE'},
    )

    def draw(self, context):
        layout = self.layout
        if self.key == 'layout':
            layout.prop(self, 'layout_part', text=_t('Page', 'ページ'))
        _draw_smart_panel(context, layout, section=self.key, layout_part=self.layout_part)

    def execute(self, _context):
        return {'FINISHED'}


class SmartNodeSuiteMenu(Menu, SNSBaseMenu):
    bl_idname = 'SMART_NODE_SUITE_MT_smart_node_menu'
    bl_label = 'Smart Node'

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        for key in _SECTION_ORDER:
            info = _SECTION_DEFS[key]
            item = layout.operator('smart_node_suite.open_menu_section',
                                   text=_t(info['label'], info['ja']), icon=info['icon'])
            item.key = key


class SNSMergeNodesMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_merge_nodes_menu"
    bl_label = "Merge Selected Nodes"

    def draw(self, context):
        type = context.space_data.tree_type
        layout = self.layout
        if type == 'ShaderNodeTree':
            layout.menu(SNSMergeShadersMenu.bl_idname, text=_t('Use Shaders'))
        if type == 'GeometryNodeTree':
            layout.menu(SNSMergeGeometryMenu.bl_idname, text=_t('Use Geometry Nodes'))
            layout.menu(SNSMergeMathMenu.bl_idname, text=_t('Use Math Nodes'))
        else:
            layout.menu(SNSMergeMixMenu.bl_idname, text=_t('Use Mix Nodes'))
            layout.menu(SNSMergeMathMenu.bl_idname, text=_t('Use Math Nodes'))
            props = layout.operator("smart_node_suite.merge_nodes", text=_t('Use Depth Combine Nodes'))
            props.mode = 'MIX'
            props.merge_type = 'DEPTH_COMBINE'
            props = layout.operator("smart_node_suite.merge_nodes", text=_t('Use Alpha Over Nodes'))
            props.mode = 'MIX'
            props.merge_type = 'ALPHAOVER'


class SNSMergeGeometryMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_merge_geometry_menu"
    bl_label = "Merge Selected Nodes using Geometry Nodes"

    def draw(self, context):
        layout = self.layout
        # The boolean node + Join Geometry node
        for type, name, description in geo_combine_operations:
            props = layout.operator("smart_node_suite.merge_nodes", text=name, text_ctxt=i18n_contexts.id_nodetree)
            props.mode = type
            props.merge_type = 'GEOMETRY'


class SNSMergeShadersMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_merge_shaders_menu"
    bl_label = "Merge Selected Nodes using Shaders"

    def draw(self, context):
        layout = self.layout
        for type in ('MIX', 'ADD'):
            name = f'{type.capitalize()} Shader'
            props = layout.operator("smart_node_suite.merge_nodes", text=name, text_ctxt=i18n_contexts.default)
            props.mode = type
            props.merge_type = 'SHADER'


class SNSMergeMixMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_merge_mix_menu"
    bl_label = "Merge Selected Nodes using Mix"

    def draw(self, context):
        layout = self.layout
        for type, name, description in blend_types:
            props = layout.operator("smart_node_suite.merge_nodes", text=name, text_ctxt=i18n_contexts.id_nodetree)
            props.mode = type
            props.merge_type = 'MIX'


class SNSMergeMathMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_merge_math_menu"
    bl_label = "Merge Selected Nodes using Math"

    def draw(self, context):
        layout = self.layout
        for type, name, description in operations:
            props = layout.operator("smart_node_suite.merge_nodes", text=name, text_ctxt=i18n_contexts.id_nodetree)
            props.mode = type
            props.merge_type = 'MATH'


class SNSBatchChangeNodesMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_batch_change_nodes_menu"
    bl_label = "Batch Change Selected Nodes"

    def draw(self, context):
        layout = self.layout
        layout.menu(SNSBatchChangeBlendTypeMenu.bl_idname)
        layout.menu(SNSBatchChangeOperationMenu.bl_idname)


class SNSBatchChangeBlendTypeMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_batch_change_blend_type_menu"
    bl_label = "Batch Change Blend Type"

    def draw(self, context):
        layout = self.layout
        for type, name, description in blend_types:
            props = layout.operator(
                "smart_node_suite.batch_change",
                text=name,
                text_ctxt=i18n_contexts.id_nodetree,
            )
            props.blend_type = type
            props.operation = 'CURRENT'


class SNSBatchChangeOperationMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_batch_change_operation_menu"
    bl_label = "Batch Change Math Operation"

    def draw(self, context):
        layout = self.layout
        for type, name, description in operations:
            props = layout.operator("smart_node_suite.batch_change", text=name, text_ctxt=i18n_contexts.id_nodetree)
            props.blend_type = 'CURRENT'
            props.operation = type


class SNSCopyToSelectedMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_copy_node_properties_menu"
    bl_label = "Copy to Selected"

    def draw(self, context):
        layout = self.layout
        layout.operator("smart_node_suite.copy_settings", text=_t('Settings from Active'))
        layout.menu(SNSCopyLabelMenu.bl_idname)


class SNSCopyLabelMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_copy_label_menu"
    bl_label = "Copy Label"

    def draw(self, context):
        layout = self.layout
        layout.operator("smart_node_suite.copy_label", text=_t("From Active Node's Label")).option = 'FROM_ACTIVE'
        layout.operator("smart_node_suite.copy_label", text=_t("From Linked Node's Label")).option = 'FROM_NODE'
        layout.operator("smart_node_suite.copy_label", text=_t("From Linked Output's Name")).option = 'FROM_SOCKET'


class SNSAddReroutesMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_add_reroutes_menu"
    bl_label = "Add Reroutes"
    bl_description = _tip('Function: opens reroute insertion choices for selected node outputs. How to use: choose all, loose, or linked outputs depending on which wires need cleaner routing.', '機能: 選択ノード出力へリルートを挿入する選択肢を表示します。使い方: 配線を整理したい出力に応じて、すべて、未接続、接続済みを選びます。')

    def draw(self, context):
        layout = self.layout
        layout.operator("smart_node_suite.add_reroutes", text=_t('To All Outputs')).option = 'ALL'
        layout.operator("smart_node_suite.add_reroutes", text=_t('To Loose Outputs')).option = 'LOOSE'
        layout.operator("smart_node_suite.add_reroutes", text=_t('To Linked Outputs')).option = 'LINKED'


class SNSLinkActiveToSelectedMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_link_active_to_selected_menu"
    bl_label = "Link Active to Selected"

    def draw(self, context):
        layout = self.layout
        layout.menu(SNSLinkStandardMenu.bl_idname)
        layout.menu(SNSLinkUseNodeNameMenu.bl_idname)
        layout.menu(SNSLinkUseOutputsNamesMenu.bl_idname)


class SNSLinkStandardMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_link_standard_menu"
    bl_label = "To All Selected"

    def draw(self, context):
        layout = self.layout
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Do Not Replace Links'))
        props.replace = False
        props.use_node_name = False
        props.use_outputs_names = False
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Replace Links'))
        props.replace = True
        props.use_node_name = False
        props.use_outputs_names = False


class SNSLinkUseNodeNameMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_link_use_node_name_menu"
    bl_label = "Use Node Name/Label"

    def draw(self, context):
        layout = self.layout
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Do Not Replace Links'))
        props.replace = False
        props.use_node_name = True
        props.use_outputs_names = False
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Replace Links'))
        props.replace = True
        props.use_node_name = True
        props.use_outputs_names = False


class SNSLinkUseOutputsNamesMenu(Menu, SNSBaseMenu):
    bl_idname = "SMART_NODE_SUITE_MT_link_use_outputs_names_menu"
    bl_label = "Use Output Names"

    def draw(self, context):
        layout = self.layout
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Do Not Replace Links'))
        props.replace = False
        props.use_node_name = False
        props.use_outputs_names = True
        props = layout.operator("smart_node_suite.link_active_to_selected", text=_t('Replace Links'))
        props.replace = True
        props.use_node_name = False
        props.use_outputs_names = True


_ATTRIBUTE_CACHE_LIMIT = 16
_ATTRIBUTE_NAME_LIMIT = 256
_ATTRIBUTE_CACHE = OrderedDict()


def _active_material_cache_key(context) -> str:
    obj = getattr(context, 'object', None)
    material = getattr(obj, 'active_material', None)
    if material is None:
        return ''
    library = getattr(getattr(material, 'library', None), 'filepath', '')
    return f'{str(library or "")}::{str(getattr(material, "name_full", getattr(material, "name", "")) or "")}'


def _cache_attribute_names(key: str, names) -> None:
    if not key:
        return
    values = tuple(sorted({str(name)[:256] for name in names if str(name or '').strip()}))[:_ATTRIBUTE_NAME_LIMIT]
    _ATTRIBUTE_CACHE.pop(key, None)
    _ATTRIBUTE_CACHE[key] = values
    while len(_ATTRIBUTE_CACHE) > _ATTRIBUTE_CACHE_LIMIT:
        _ATTRIBUTE_CACHE.popitem(last=False)


class SNS_OT_refresh_attribute_cache(bpy.types.Operator):
    bl_idname = 'smart_node_suite.refresh_attribute_cache'
    bl_label = 'Refresh Material Attributes'
    bl_description = _tip(
        'Function: performs one explicit scan for geometry and color attributes on objects using the active material, then stores only bounded attribute-name strings for the menu. How to use: run this after attributes or material assignments change; no background scan remains active.',
        '機能: アクティブマテリアルを使うオブジェクトのジオメトリ/カラー属性を明示的に1回走査し、上限付きの属性名文字列だけをメニュー用に保存します。使い方: 属性やマテリアル割り当てを変更した後に実行します。バックグラウンド走査は残りません。',
    )
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return SNSAttributeMenu.poll(context)

    def execute(self, context):
        material = getattr(getattr(context, 'object', None), 'active_material', None)
        key = _active_material_cache_key(context)
        if material is None or not key:
            self.report({'WARNING'}, _t('No active material', 'アクティブマテリアルがありません'))
            return {'CANCELLED'}
        names = set()
        for obj in tuple(getattr(bpy.data, 'objects', ())):
            try:
                if not any(getattr(slot, 'material', None) == material for slot in obj.material_slots):
                    continue
                attributes = getattr(getattr(obj, 'data', None), 'attributes', None)
                if attributes is None:
                    continue
                for attr in attributes:
                    if not bool(getattr(attr, 'is_internal', False)):
                        names.add(str(getattr(attr, 'name', '') or ''))
                        if len(names) >= _ATTRIBUTE_NAME_LIMIT:
                            break
            except Exception:
                continue
            if len(names) >= _ATTRIBUTE_NAME_LIMIT:
                break
        _cache_attribute_names(key, names)
        self.report({'INFO'}, _t(f'Cached {len(names)} attribute names.', f'属性名を {len(names)} 件キャッシュしました。'))
        return {'FINISHED'}


class SNSAttributeMenu(bpy.types.Menu):
    bl_idname = 'SMART_NODE_SUITE_MT_node_attribute_menu'
    bl_label = 'Attributes'

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        return bool(
            getattr(space, 'type', '') == 'NODE_EDITOR'
            and getattr(space, 'node_tree', None) is not None
            and getattr(space.node_tree, 'library', None) is None
            and getattr(space, 'tree_type', '') == 'ShaderNodeTree'
            and getattr(space, 'shader_type', '') == 'OBJECT'
        )

    def draw(self, context):
        layout = self.layout
        layout.operator('smart_node_suite.refresh_attribute_cache', icon='FILE_REFRESH')
        key = _active_material_cache_key(context)
        attrs = _ATTRIBUTE_CACHE.get(key)
        if attrs is None:
            layout.label(text=_t('Refresh to list material attributes', '更新してマテリアル属性を一覧表示'))
            return
        if not attrs:
            layout.label(text=_t('No attributes on objects with this material', 'このマテリアルを持つオブジェクトに属性がありません'))
            return
        for attr in attrs:
            layout.operator('smart_node_suite.add_attr_node', text=attr, translate=False).attr_name = attr


#
#  APPENDAGES TO EXISTING UI
#


def select_parent_children_buttons(self, context):
    layout = self.layout
    layout.operator("smart_node_suite.select_parent_child", text=_t('Select Frame Children')).option = 'CHILD'
    layout.operator("smart_node_suite.select_parent_child", text=_t('Select Parent Frame')).option = 'PARENT'


def attr_nodes_menu_func(self, context):
    col = self.layout.column(align=True)
    col.menu("SMART_NODE_SUITE_MT_node_attribute_menu")
    col.separator()


def multipleimages_menu_func(self, context):
    col = self.layout.column(align=True)
    col.operator("node.add_image", text=_t('Multiple Images'))
    col.operator("smart_node_suite.add_sequence", text=_t('Image Sequence'))
    col.separator()


def bgreset_menu_func(self, context):
    self.layout.operator("smart_node_suite.bg_reset")


def save_viewer_menu_func(self, context):
    space = getattr(context, 'space_data', None)
    node_tree = getattr(space, 'node_tree', None)
    edit_tree = getattr(space, 'edit_tree', None)
    nodes = getattr(edit_tree, 'nodes', None)
    active_node = getattr(nodes, 'active', None)
    if (getattr(space, 'type', '') == 'NODE_EDITOR'
            and getattr(space, 'tree_type', '') == 'CompositorNodeTree'
            and getattr(space, 'node_tree_sub_type', '') == 'SCENE'
            and node_tree is not None
            and getattr(node_tree, 'library', None) is None
            and active_node is not None
            and getattr(active_node, 'type', '') == "VIEWER"):
        self.layout.operator("smart_node_suite.save_viewer", icon='FILE_IMAGE')


def reset_nodes_button(self, context):
    node_active = context.active_node
    node_selected = context.selected_nodes

    # Check if active node is in the selection, ignore some node types
    if (len(node_selected) != 1
            or node_active is None
            or not node_active.select
            or node_active.type in {"REROUTE", "GROUP"}):
        return

    row = self.layout.row()

    if node_active.type == "FRAME":
        row.operator("smart_node_suite.reset_nodes", text=_t('Reset Nodes in Frame'), icon="FILE_REFRESH")
    else:
        row.operator("smart_node_suite.reset_nodes", text=_t('Reset Node'), icon="FILE_REFRESH")

    self.layout.separator()


classes = (
    SNS_OT_toggle_section,
    SNS_OT_toggle_migrated_group,
    SNS_OT_section_help,
    SMART_NODE_SUITE_OT_run_legacy_cleanup,
    VIEW3D_PT_smart_node_suite,
    IMAGE_PT_smart_node_suite,
    NODE_PT_smart_node_suite,
    SEQUENCER_PT_smart_node_suite,
    CLIP_PT_smart_node_suite,
    DOPESHEET_PT_smart_node_suite,
    GRAPH_PT_smart_node_suite,
    NLA_PT_smart_node_suite,
    TEXT_PT_smart_node_suite,
    FILEBROWSER_PT_smart_node_suite,
    ASSETBROWSER_PT_smart_node_suite,
    SPREADSHEET_PT_smart_node_suite,
    SNS_OT_open_menu_section,
    SmartNodeSuiteMenu,
    SNSMergeNodesMenu,
    SNSMergeGeometryMenu,
    SNSMergeShadersMenu,
    SNSMergeMixMenu,
    SNSMergeMathMenu,
    SNSBatchChangeNodesMenu,
    SNSBatchChangeBlendTypeMenu,
    SNSBatchChangeOperationMenu,
    SNSCopyToSelectedMenu,
    SNSCopyLabelMenu,
    SNSAddReroutesMenu,
    SNSLinkActiveToSelectedMenu,
    SNSLinkStandardMenu,
    SNSLinkUseNodeNameMenu,
    SNSLinkUseOutputsNamesMenu,
    SNS_OT_refresh_attribute_cache,
    SNSAttributeMenu,
)


_registered_class_tokens = []
_registered_ui_hook_tokens = []


def _append_ui_hook(owner, method_name: str, callback, *, prepend: bool = False) -> None:
    del method_name
    _registered_ui_hook_tokens.append(
        rna_ownership.install_ui_hook(owner, callback, prepend=prepend)
    )


def _try_append_ui_hook(owner_name: str, callback, *, prepend: bool = False) -> bool:
    try:
        owner = getattr(bpy.types, owner_name, None)
        if owner is None:
            return False
        _append_ui_hook(
            owner,
            'prepend' if prepend else 'append',
            callback,
            prepend=prepend,
        )
    except Exception:
        # Built-in menus and panels vary by Blender build and enabled features.
        # A missing or unavailable target must not prevent the Suite-owned roots
        # and the remaining independent hooks from registering.
        return False
    return True


_UI_HOOK_SPECS = (
    ('NODE_MT_select', select_parent_children_buttons, False),
    ('NODE_MT_category_shader_input', attr_nodes_menu_func, True),
    ('NODE_PT_backdrop', bgreset_menu_func, False),
    ('NODE_PT_active_node_generic', save_viewer_menu_func, False),
    ('NODE_MT_category_shader_texture', multipleimages_menu_func, True),
    ('NODE_MT_category_compositor_input', multipleimages_menu_func, True),
    ('NODE_PT_active_node_generic', reset_nodes_button, True),
    ('NODE_MT_node', reset_nodes_button, True),
)


def register():
    if _registered_class_tokens or _registered_ui_hook_tokens:
        return
    try:
        _registered_class_tokens.extend(rna_ownership.register_classes(classes))
    except Exception:
        unregister()
        raise

    for owner_name, callback, prepend in _UI_HOOK_SPECS:
        _try_append_ui_hook(owner_name, callback, prepend=prepend)


def unregister():
    while _registered_ui_hook_tokens:
        token = _registered_ui_hook_tokens.pop()
        try:
            rna_ownership.remove_ui_hook(token)
        except Exception:
            pass
    _ATTRIBUTE_CACHE.clear()
    manager_rules.clear_runtime_state()
    rna_ownership.unregister_classes(_registered_class_tokens)
