# ============================================================================
# Node Presets
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

"""Node-group presets with explicit, bounded asset discovery."""

from __future__ import annotations

import os
from pathlib import Path

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Menu, Operator

from .. import tool_preferences as _st_prefs
from .. import rna_ownership
from .. import ui_sections
from ..translation import loc_text as _lt
from ..utils.node_transactions import (
    clone_node,
    link_if_compatible,
    restore_tree_links,
    snapshot_tree_links,
    socket_index,
)

bl_info = {
    'name': 'Node Presets',
    'author': 'JELararagi',
    'version': (1, 4, 18),
    'blender': (5, 1, 0),
    'location': 'Smart Node > Texture Setup',
    'description': 'Add node groups directly to active node editors from Smart Node Suite',
    'warning': '',
    'doc_url': '',
    'category': 'Node',
}

_CACHE_LIMIT = 512
_NODE_PRESET_RUNTIME_SEARCH_PATH = ''
_NODE_CACHE: tuple[tuple[str, str], ...] = ()
_NODE_CACHE_PATH = ''
_NODE_CACHE_READY = False


def _node_presets_fallback_property_description(kwargs):
    label = str(kwargs.get('name') or '').strip() or 'Node Preset setting'
    return _lt(
        f'JP: {label} のノードプリセット設定です。.blend 内の公開ノードグループを検索・追加するためのパスや内部選択値を扱います。Nパネルで指定したフォルダーのみ外部参照します。\n'
        f'EN: {label} Node Presets setting. It stores paths or internal choices used to search and add public node groups from .blend files. Only folders explicitly chosen in the N-panel are referenced externally.'
    )


def _node_presets_wrap_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _node_presets_fallback_property_description(kwargs)
        return factory(*args, **kwargs)
    return _wrapped


StringProperty = _node_presets_wrap_property(StringProperty)


def _node_preset_has_rna_property(data, name: str) -> bool:
    if data is None or not name:
        return False
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        return bool(props is not None and (props.get(str(name)) is not None))
    except Exception:
        return False


def _node_preset_preferences(context=None):
    prefs = _st_prefs.addon_preferences(context)
    prop = _st_prefs.prop_name('node_presets', 'search_path')
    return prefs if _node_preset_has_rna_property(prefs, prop) else None


def _invalidate_cache(path: str = '') -> None:
    global _NODE_CACHE, _NODE_CACHE_PATH, _NODE_CACHE_READY
    _NODE_CACHE = ()
    _NODE_CACHE_PATH = str(path or '')
    _NODE_CACHE_READY = False


def _normalize_search_path(value) -> str:
    text = str(value or '').strip()
    if not text:
        return ''
    try:
        text = bpy.path.abspath(text)
    except Exception:
        pass
    return os.path.normpath(text)


def _search_state_snapshot(context=None) -> tuple[str, str, tuple[tuple[str, str], ...], str, bool]:
    return (
        str(_st_prefs.tool_value('node_presets', 'search_path', context=context, default='') or ''),
        str(_NODE_PRESET_RUNTIME_SEARCH_PATH or ''),
        tuple(_NODE_CACHE),
        str(_NODE_CACHE_PATH or ''),
        bool(_NODE_CACHE_READY),
    )


def _restore_search_state(snapshot, context=None) -> None:
    global _NODE_PRESET_RUNTIME_SEARCH_PATH, _NODE_CACHE, _NODE_CACHE_PATH, _NODE_CACHE_READY
    saved_path, runtime_path, cache, cache_path, cache_ready = snapshot
    _st_prefs.set_tool_value('node_presets', 'search_path', saved_path, context=context)
    _NODE_PRESET_RUNTIME_SEARCH_PATH = runtime_path
    _NODE_CACHE = tuple(cache)
    _NODE_CACHE_PATH = cache_path
    _NODE_CACHE_READY = bool(cache_ready)
    try:
        from .. import persistent_settings
        persistent_settings.request_save(context, force=False)
    except Exception:
        pass


def _commit_search_state(path: str, cache: tuple[tuple[str, str], ...], context=None) -> bool:
    """Commit the chosen path and its already-built plain-value cache together."""

    global _NODE_PRESET_RUNTIME_SEARCH_PATH, _NODE_CACHE, _NODE_CACHE_PATH, _NODE_CACHE_READY
    normalized = _normalize_search_path(path)
    _st_prefs.set_tool_value('node_presets', 'search_path', normalized, context=context)
    stored = str(_st_prefs.tool_value('node_presets', 'search_path', context=context, default='') or '')
    if _normalize_search_path(stored) != normalized:
        return False
    try:
        from .. import persistent_settings
        if not persistent_settings.request_save(context, force=False):
            return False
    except Exception:
        return False
    _NODE_PRESET_RUNTIME_SEARCH_PATH = normalized
    _NODE_CACHE = tuple(cache[:_CACHE_LIMIT])
    _NODE_CACHE_PATH = normalized
    _NODE_CACHE_READY = True
    return True


def node_search_path(context=None):
    global _NODE_PRESET_RUNTIME_SEARCH_PATH
    direct = str(_st_prefs.tool_value('node_presets', 'search_path', context=context, default='') or '').strip()
    if not direct:
        direct = str(_NODE_PRESET_RUNTIME_SEARCH_PATH or '').strip()
    direct = _normalize_search_path(direct)
    _NODE_PRESET_RUNTIME_SEARCH_PATH = direct
    return direct if direct and os.path.isdir(direct) else ''


def _scan_template_directory(directory: str) -> tuple[tuple[str, str], ...]:
    """Explicit operator-time scan returning bounded plain string metadata."""

    normalized = _normalize_search_path(directory)
    if not normalized or not os.path.isdir(normalized):
        raise ValueError('The node preset folder is not a readable directory')
    items: list[tuple[str, str]] = []
    with os.scandir(normalized) as iterator:
        entries = sorted(tuple(iterator), key=lambda item: item.name.lower())
    for entry in entries:
        if len(items) >= _CACHE_LIMIT:
            break
        try:
            if not entry.is_file(follow_symlinks=False) or not entry.name.lower().endswith('.blend'):
                continue
            filepath = os.path.normpath(entry.path)
            with bpy.data.libraries.load(filepath, link=False) as (data_from, _data_to):
                for group_name in tuple(data_from.node_groups):
                    name = str(group_name or '')
                    if name and not name.startswith('_'):
                        items.append((filepath, name))
                        if len(items) >= _CACHE_LIMIT:
                            break
        except Exception:
            # A damaged/unreadable candidate file is skipped; the folder scan
            # itself is finite and never installs a retry callback.
            continue
    return tuple(items)


def node_template_cache(context=None, *, reload=False):
    """Return bounded cached strings; scanning is owned by explicit operators."""

    directory = node_search_path(context)
    if directory != _NODE_CACHE_PATH:
        _invalidate_cache(directory)
    # ``reload`` is retained for API compatibility but deliberately does not
    # perform I/O. Use node_presets.refresh_preset_cache for an explicit scan.
    del reload
    return _NODE_CACHE


def node_template_cache_ready(context=None) -> bool:
    directory = node_search_path(context)
    return bool(_NODE_CACHE_READY and directory == _NODE_CACHE_PATH)


class NODEPRESETS_OT_choose_preset_folder(Operator):
    bl_idname = 'node_presets.choose_preset_folder'
    bl_label = _lt('Choose Preset Folder', 'プリセットフォルダーを選択')
    bl_description = _lt('EN: Choose the folder that contains .blend files with node-group presets. The folder is scanned once after confirmation and never in panel draw. JP: ノードグループプリセットを含む .blend ファイルのフォルダーを選択します。確定後に1回だけ走査し、パネル描画中には走査しません。')
    bl_options = {'INTERNAL'}
    directory: StringProperty(
        name=_lt('Preset Folder', 'プリセットフォルダー'),
        description=_lt('EN: Folder containing .blend files whose public node groups should be listed as presets. Confirming the file browser changes the saved path; pressing Esc leaves the prior path and cache unchanged. JP: 公開ノードグループをプリセット一覧へ表示する .blend ファイル格納フォルダーです。ファイルブラウザーで確定した時だけ保存パスを変更し、Esc では以前のパスとキャッシュを変更しません。'),
        subtype='DIR_PATH',
    )

    def execute(self, context):
        snapshot = _search_state_snapshot(context)
        path = _normalize_search_path(self.directory)
        try:
            items = _scan_template_directory(path)
            if not _commit_search_state(path, items, context):
                raise RuntimeError('the schema-validated settings authority rejected the update')
        except Exception as exc:
            _restore_search_state(snapshot, context)
            self.report({'ERROR'}, _lt(f'Preset folder was not changed: {exc}', 'プリセットフォルダーは変更されませんでした。'))
            return {'CANCELLED'}
        self.report({'INFO'}, _lt(f'Node preset folder set; cached {len(items)} templates.', f'ノードプリセットフォルダーを設定し、{len(items)} 件をキャッシュしました。'))
        return {'FINISHED'}

    def invoke(self, context, _event):
        self.directory = node_search_path(context) or str(getattr(self, 'directory', '') or '')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class NODEPRESETS_OT_clear_preset_folder(Operator):
    bl_idname = 'node_presets.clear_preset_folder'
    bl_label = _lt('Clear Preset Folder', 'プリセットフォルダー解除')
    bl_description = _lt('EN: Clear the external node preset folder and its bounded metadata cache. JP: 外部ノードプリセットフォルダー設定と上限付きメタデータキャッシュを解除します。')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        snapshot = _search_state_snapshot(context)
        if not _commit_search_state('', (), context):
            _restore_search_state(snapshot, context)
            self.report({'ERROR'}, _lt('Preset folder was not cleared because settings could not be saved.', '設定を保存できなかったため、プリセットフォルダーは解除されませんでした。'))
            return {'CANCELLED'}
        self.report({'INFO'}, _lt('Node preset folder cleared.', 'ノードプリセットフォルダー設定を解除しました。'))
        return {'FINISHED'}


class NODEPRESETS_OT_refresh_preset_cache(Operator):
    bl_idname = 'node_presets.refresh_preset_cache'
    bl_label = _lt('Refresh Presets', 'プリセットを更新')
    bl_description = _lt('EN: Scan the selected folder once and cache at most 512 .blend node-group entries as plain strings. No timer, handler, thread, or draw-time scan is started. JP: 選択フォルダーを1回だけ走査し、最大512件の .blend ノードグループ情報を文字列としてキャッシュします。タイマー、ハンドラー、スレッド、描画時走査は開始しません。')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        global _NODE_CACHE, _NODE_CACHE_PATH, _NODE_CACHE_READY
        directory = node_search_path(context)
        if not directory:
            self.report({'WARNING'}, _lt('Set a valid preset folder first.', '先に有効なプリセットフォルダーを設定してください。'))
            return {'CANCELLED'}
        try:
            items = _scan_template_directory(directory)
        except Exception as exc:
            self.report({'ERROR'}, _lt(f'Preset cache was not changed: {exc}', 'プリセットキャッシュは変更されませんでした。'))
            return {'CANCELLED'}
        _NODE_CACHE = items
        _NODE_CACHE_PATH = directory
        _NODE_CACHE_READY = True
        self.report({'INFO'}, _lt(f'Cached {len(items)} node templates.', f'ノードテンプレートを {len(items)} 件キャッシュしました。'))
        return {'FINISHED'}


SSS_DISABLE_PROXY_PANELS = True
SSS_HIDE_OPERATOR_IDS = {'node.add_node_group_template'}


def _draw_template_entries(layout, context) -> None:
    current_path = node_search_path(context)
    if not current_path:
        layout.label(text=_lt('Set the folder above to expose template buttons.', '上でフォルダーを設定するとテンプレートボタンが表示されます。'))
        return
    row = layout.row(align=True)
    row.operator('node_presets.refresh_preset_cache', icon='FILE_REFRESH')
    if not node_template_cache_ready(context):
        layout.label(text=_lt('Refresh presets to build the list.', '「プリセットを更新」で一覧を作成してください。'))
        return
    items = node_template_cache(context, reload=False)
    if not items:
        layout.label(text=_lt('No public node groups were found in the folder.', 'フォルダー内に公開ノードグループが見つかりませんでした。'))
        return
    grouped: dict[str, list[tuple[str, str]]] = {}
    for filepath, group_name in items:
        grouped.setdefault(os.path.basename(filepath), []).append((filepath, group_name))
    for filename in sorted(grouped):
        _box, file_box, _expanded = ui_sections.draw_group(
            layout, context, 'node_presets_file_' + filename, filename,
            icon='FILE_BLEND', topic='node_presets', default_open=False,
        )
        col = file_box.column(align=True)
        for filepath, group_name in sorted(grouped[filename], key=lambda item: item[1].lower()):
            op = col.operator('node.add_node_group_template', text=group_name, icon='NODETREE', translate=False)
            op.filepath = filepath
            op.group_name = group_name


def draw_smart_node_runtime_controls(layout, context):
    _box, box, _expanded = ui_sections.draw_group(layout, context, 'node_presets_root', _lt('Node Templates', 'ノードテンプレート'), icon='NODETREE', topic='node_presets', default_open=False)
    _box, path_box, _expanded = ui_sections.draw_group(box, context, 'node_presets_template_folder', _lt('Template Folder', 'テンプレートフォルダー'), icon='FILE_FOLDER', topic='node_presets', default_open=False)
    current_path = node_search_path(context)
    prefs = _node_preset_preferences(context)
    path_box.label(text=current_path or _lt('Not set', '未設定'), translate=False)
    prop = _st_prefs.prop_name('node_presets', 'search_path')
    if prefs is not None:
        path_box.prop(prefs, prop, text=_lt('Folder', 'フォルダー'))
    row = path_box.column(align=True)
    row.operator('node_presets.choose_preset_folder', icon='FILE_FOLDER')
    row.operator('node_presets.clear_preset_folder', icon='X')
    row.operator('node_presets.refresh_preset_cache', icon='FILE_REFRESH')

    _box, entries_box, _expanded = ui_sections.draw_group(box, context, 'node_presets_templates', _lt('Templates', 'テンプレート一覧'), icon='ASSET_MANAGER', topic='node_presets', default_open=False)
    _draw_template_entries(entries_box, context)


def node_center(context):
    from mathutils import Vector
    location = Vector((0.0, 0.0))
    selected = tuple(getattr(context, 'selected_nodes', ()) or ())
    if selected:
        for node in selected:
            location += node.location
        location /= len(selected)
    return location


def _group_node_type(node_tree) -> str:
    tree_id = str(getattr(node_tree, 'bl_idname', '') or type(node_tree).__name__)
    mapping = {
        'ShaderNodeTree': 'ShaderNodeGroup',
        'CompositorNodeTree': 'CompositorNodeGroup',
        'TextureNodeTree': 'TextureNodeGroup',
        'GeometryNodeTree': 'GeometryNodeGroup',
    }
    if tree_id not in mapping:
        raise ValueError(f'Unsupported node tree type: {tree_id}')
    return mapping[tree_id]


def _socket_external_links(node_tree, group_node):
    incoming: dict[int, list[object]] = {}
    outgoing: dict[int, list[object]] = {}
    for link in tuple(node_tree.links):
        if link.to_node == group_node:
            index = socket_index(group_node.inputs, link.to_socket)
            if index >= 0:
                incoming.setdefault(index, []).append(link.from_socket)
        if link.from_node == group_node:
            index = socket_index(group_node.outputs, link.from_socket)
            if index >= 0:
                outgoing.setdefault(index, []).append(link.to_socket)
    return incoming, outgoing


def _ungroup_node_direct(node_tree, group_node):
    group_tree = getattr(group_node, 'node_tree', None)
    if group_tree is None:
        raise ValueError('Group node has no node tree')
    links_before = snapshot_tree_links(node_tree)
    incoming, outgoing = _socket_external_links(node_tree, group_node)
    source_nodes = tuple(group_tree.nodes)
    group_inputs = {node for node in source_nodes if getattr(node, 'type', '') == 'GROUP_INPUT'}
    group_outputs = {node for node in source_nodes if getattr(node, 'type', '') == 'GROUP_OUTPUT'}
    ordinary = [node for node in source_nodes if node not in group_inputs and node not in group_outputs]
    created = []
    mapping = {}
    base = group_node.location.copy()
    try:
        for source in ordinary:
            location = base + source.location
            clone = clone_node(node_tree, source, location=location, parent=None, select=True)
            mapping[source] = clone
            created.append(clone)
        for source, clone in mapping.items():
            parent = getattr(source, 'parent', None)
            if parent in mapping:
                clone.parent = mapping[parent]

        for link in tuple(group_tree.links):
            from_node = link.from_node
            to_node = link.to_node
            if from_node in group_inputs and to_node in group_outputs:
                input_index = socket_index(from_node.outputs, link.from_socket)
                output_index = socket_index(to_node.inputs, link.to_socket)
                for source_socket in incoming.get(input_index, ()):
                    for target_socket in outgoing.get(output_index, ()):
                        link_if_compatible(node_tree, source_socket, target_socket)
                continue
            if from_node in group_inputs and to_node in mapping:
                input_index = socket_index(from_node.outputs, link.from_socket)
                target_index = socket_index(to_node.inputs, link.to_socket)
                target_socket = mapping[to_node].inputs[target_index]
                sources = incoming.get(input_index, ())
                if sources:
                    for source_socket in sources:
                        link_if_compatible(node_tree, source_socket, target_socket)
                elif 0 <= input_index < len(group_node.inputs):
                    try:
                        target_socket.default_value = group_node.inputs[input_index].default_value
                    except Exception:
                        pass
                continue
            if from_node in mapping and to_node in group_outputs:
                source_index = socket_index(from_node.outputs, link.from_socket)
                output_index = socket_index(to_node.inputs, link.to_socket)
                source_socket = mapping[from_node].outputs[source_index]
                for target_socket in outgoing.get(output_index, ()):
                    link_if_compatible(node_tree, source_socket, target_socket)
                continue
            if from_node in mapping and to_node in mapping:
                from_index = socket_index(from_node.outputs, link.from_socket)
                to_index = socket_index(to_node.inputs, link.to_socket)
                link_if_compatible(node_tree, mapping[from_node].outputs[from_index], mapping[to_node].inputs[to_index])
        node_tree.nodes.remove(group_node)
        return tuple(created)
    except Exception:
        for node in reversed(created):
            try:
                node_tree.nodes.remove(node)
            except Exception:
                pass
        # Remove any links created before the failure and restore the exact
        # pre-expansion graph. The original group node has not yet been removed.
        restore_tree_links(node_tree, links_before)
        raise


def node_template_add(context, filepath, node_group_name, ungroup, report):
    from .preset_append import add
    return add(context, filepath, node_group_name,
               _ungroup_node_direct if ungroup else None, node_center, report)


class NODE_OT_add_node_group_template(Operator):
    bl_idname = 'node.add_node_group_template'
    bl_label = _lt('Add Node Group Template', 'ノードグループテンプレートを追加')
    bl_description = _lt('EN: Import the selected public node group into the active node tree. A normal click keeps the group node; Shift-click expands it directly without calling nested Blender operators. JP: 選択した公開ノードグループを現在のノードツリーへ読み込みます。通常クリックではグループノードを保持し、Shift クリックでは入れ子の Blender オペレーターを使わず直接展開します。')
    bl_options = {'UNDO'}
    filepath: StringProperty(
        name=_lt('Preset File', 'プリセットファイル'),
        description=_lt('EN: Internal path of the .blend file containing the selected public node group. The preset menu fills this automatically. JP: 選択した公開ノードグループを含む .blend ファイルの内部パスです。プリセットメニューが自動設定します。'),
        subtype='FILE_PATH',
    )
    group_name: StringProperty(
        name=_lt('Node Group', 'ノードグループ'),
        description=_lt('EN: Name of the public node group to import from the preset file. The preset button fills this automatically. JP: プリセットファイルから読み込む公開ノードグループ名です。プリセットボタンが自動設定します。'),
    )
    ungroup: BoolProperty(
        name=_lt('Expand Group', 'グループを展開'),
        description=_lt('EN: Expand the imported group directly into the current tree. Hold Shift while clicking a preset to enable this for that operation. JP: 読み込んだグループを現在のツリーへ直接展開します。プリセットを Shift クリックした操作で有効になります。'),
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        space = getattr(context, 'space_data', None)
        tree = getattr(space, 'node_tree', None)
        return bool(getattr(space, 'type', '') == 'NODE_EDITOR' and tree is not None and getattr(tree, 'library', None) is None)

    def execute(self, context):
        return {'FINISHED'} if node_template_add(context, self.filepath, self.group_name, bool(self.ungroup), self.report) else {'CANCELLED'}

    def invoke(self, context, event):
        self.ungroup = bool(event.shift)
        return self.execute(context)


class NODE_MT_node_template_menu(Menu):
    bl_idname = 'NODE_MT_node_template_menu'
    bl_label = _lt('Node Template Menu', 'ノードテンプレートメニュー')

    def draw(self, context):
        layout = self.layout
        directory = node_search_path(context)
        if not directory:
            layout.label(text=_lt('Set the template folder in Smart Node settings.', 'Smart Node 設定でテンプレートフォルダーを指定してください。'))
            return
        layout.operator('node_presets.refresh_preset_cache', icon='FILE_REFRESH')
        if not node_template_cache_ready(context):
            layout.label(text=_lt('Refresh presets to build the list.', 'プリセットを更新して一覧を作成してください。'))
            return
        items = node_template_cache(context, reload=False)
        if not items:
            layout.label(text=_lt('No public node groups found.', '公開ノードグループがありません。'))
            return
        for filepath, group_name in items:
            properties = layout.operator(NODE_OT_add_node_group_template.bl_idname, text=group_name, translate=False)
            properties.filepath = filepath
            properties.group_name = group_name


def add_node_button(self, context):
    self.layout.menu(NODE_MT_node_template_menu.__name__, text=_lt('Template', 'テンプレート'), icon='PLUGIN')


classes = (
    NODE_OT_add_node_group_template,
    NODE_MT_node_template_menu,
    NODEPRESETS_OT_choose_preset_folder,
    NODEPRESETS_OT_clear_preset_folder,
    NODEPRESETS_OT_refresh_preset_cache,
)
_registered_class_tokens = []


def register():
    if _registered_class_tokens:
        return
    _registered_class_tokens.extend(rna_ownership.register_classes(classes))


def unregister():
    _invalidate_cache('')
    rna_ownership.unregister_classes(_registered_class_tokens)
