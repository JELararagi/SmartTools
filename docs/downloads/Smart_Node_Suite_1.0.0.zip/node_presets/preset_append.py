"""Append a named node group from a Blender file to the active editable tree.

Independently implemented by Codex, 2026. Production name: JELararagi.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import os

import bpy


_NODE_CLASSES = {
    'ShaderNodeTree': 'ShaderNodeGroup',
    'CompositorNodeTree': 'CompositorNodeGroup',
    'GeometryNodeTree': 'GeometryNodeGroup',
    'TextureNodeTree': 'TextureNodeGroup',
}


class PresetError(ValueError):
    pass


def _message(english, japanese):
    return japanese if bpy.app.translations.locale.startswith('ja') else english


def _new_dependencies(root, prior):
    """Find only new datablocks that the appended root actually references."""
    owners = bpy.data.user_map()
    found = {root} - prior
    while found:
        extra = {item for item, users in owners.items()
                 if item not in prior and item not in found and users.intersection(found)}
        if not extra:
            break
        found.update(extra)
    return found


def _release_unused(owned):
    """Preserve anything now used outside this import, plus its dependencies."""
    if not owned:
        return
    users = bpy.data.user_map()
    remaining = owned.intersection(users)
    while remaining:
        retained = {item for item in remaining if users[item].difference(remaining)}
        if not retained:
            bpy.data.batch_remove(ids=remaining)
            return
        remaining.difference_update(retained)


def _read_group(filepath, name):
    with bpy.data.libraries.load(filepath, link=False) as (available, wanted):
        if name not in available.node_groups:
            raise PresetError(_message("No such group in the preset file.", "プリセットファイルに指定のグループがありません。"))
        wanted.node_groups = [name]
    group = wanted.node_groups[0]
    if group is None:
        raise PresetError(_message("Blender could not append this group.", "グループを読み込めませんでした。"))
    return group


def add(context, filepath, name, expand, center, report):
    """Return the public operator's boolean result; expand is its optional Shift callback."""
    space = getattr(context, 'space_data', None)
    tree = getattr(space, 'edit_tree', None)
    node_type = _NODE_CLASSES.get(getattr(tree, 'bl_idname', ''))
    if getattr(space, 'type', None) != 'NODE_EDITOR' or not node_type or not tree.is_editable:
        report({'WARNING'}, _message("Open an editable node tree first.", "編集可能なノードツリーを開いてください。"))
        return False
    path = bpy.path.abspath(filepath) if filepath else ''
    if not name or name.startswith('.') or not os.path.isfile(path):
        report({'WARNING'}, _message("Choose a preset file and a public group.", "プリセットファイルと公開グループを選んでください。"))
        return False

    original_active = tree.nodes.active
    selection = [(node, node.select) for node in tree.nodes]
    prior = set(bpy.data.user_map())
    owned = set()
    inserted = None
    expanding_from = None
    try:
        group = _read_group(path, name)
        owned = _new_dependencies(group, prior)
        if group.bl_idname != tree.bl_idname:
            raise PresetError(_message("This preset belongs to a different node editor type.",
                                       "このプリセットは別の種類のノードツリー用です。"))
        position = center(context)
        inserted = tree.nodes.new(node_type)
        inserted.node_tree = group
        inserted.location = position
        for node, _ in selection:
            node.select = False
        inserted.select = True
        tree.nodes.active = inserted
        if expand is not None:
            expanding_from = {node.as_pointer() for node in tree.nodes}
            # This is the existing operator's direct expansion contract.
            expanded = tuple(expand(tree, inserted))
            # An expansion callback may leave the temporary group instance in place.
            if any(node == inserted for node in tree.nodes):
                tree.nodes.remove(inserted)
            inserted = None
            for node in expanded:
                node.select = True
            if expanded:
                tree.nodes.active = expanded[0]
            _release_unused(owned)
        return True
    except (OSError, RuntimeError, ValueError, TypeError, AttributeError, KeyError, ReferenceError) as exc:
        if expanding_from is not None:
            for node in tuple(tree.nodes):
                if node.as_pointer() not in expanding_from:
                    tree.nodes.remove(node)
        if inserted is not None and any(node == inserted for node in tree.nodes):
            tree.nodes.remove(inserted)
        for node, was_selected in selection:
            node.select = was_selected
        tree.nodes.active = original_active
        _release_unused(owned)
        report({'WARNING'}, str(exc))
        return False
