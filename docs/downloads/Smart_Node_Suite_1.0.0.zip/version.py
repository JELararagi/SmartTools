# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Compatibility version for saved Node Suite settings."""
ADDON_VERSION = (1, 4, 33)
ADDON_VERSION_STRING = ".".join(map(str, ADDON_VERSION))
SCHEMA_VERSION = 2
