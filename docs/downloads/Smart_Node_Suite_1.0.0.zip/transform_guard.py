# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility boundary for conversions that operate on node data only."""
from contextlib import nullcontext


def preserve_object_transforms(reason=""):
    return nullcontext()
