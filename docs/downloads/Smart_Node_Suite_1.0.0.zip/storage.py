# SPDX-License-Identifier: GPL-3.0-or-later
"""Resolve Smart Node Suite settings without modifying the add-on files."""

from pathlib import Path
from tempfile import gettempdir

try:
    from bpy import utils as blender_utils
except ImportError:
    blender_utils = None

LEGACY_DIRECTORY = "smart_node_suite"
CANONICAL_DIRECTORY = "Smart_Node_Suite"
CANONICAL_FILE = "Smart_Node_Suite.json"
DEFAULT_FILE = "settings.json"


def _settings_root(name, create):
    if blender_utils is not None:
        try:
            location = blender_utils.user_resource("CONFIG", create=create)
            if location:
                path = Path(location, name)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
        except (OSError, RuntimeError, TypeError, ValueError):
            pass
    path = Path(gettempdir(), name)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def settings_dir(create=True):
    return _settings_root(LEGACY_DIRECTORY, create)


def settings_file(name, create=True):
    basename = "".join(char if char.isalnum() or char in "-_." else "_" for char in str(name or DEFAULT_FILE))
    if basename in {".", ".."}:
        basename = DEFAULT_FILE
    return settings_dir(create) / basename


def canonical_settings_dir(create=True):
    return _settings_root(CANONICAL_DIRECTORY, create)


def canonical_settings_file(create=True):
    return canonical_settings_dir(create) / CANONICAL_FILE
