# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Stable Smart Node Suite settings and editor panel identifiers."""

CONTRACT_VERSION = 2
EXTENSION_ID = "smart_node_suite"
CONFIG_FOLDER = "Smart_Node_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"

WINDOW_SETTINGS = "window_manager"
STATE_SAVE_PATH = f"{WINDOW_SETTINGS}.smart_node_suite_npanel_state_save"
SECTION_OPEN_PATH = f"{WINDOW_SETTINGS}.smart_node_suite_section_always_on"
RUNTIME_TOGGLE_PATHS = tuple(f"{WINDOW_SETTINGS}.{setting}" for setting in (
    "smart_node_suite_legacy_cleanup_enabled",
    "noise_nodes_background_callbacks",
    "noise_nodes_node_wrangler_override",
))
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (
    f"{WINDOW_SETTINGS}.smart_node_suite_*", f"{WINDOW_SETTINGS}.noise_nodes_*",
    "preferences", "scene.na_settings", "scene.node_color_tools",
)
EXCLUDED_TRANSIENT_PATHS = (
    "preferences.bl_idname", "scene.na_settings.name", "scene.node_color_tools.name",
)

ROOT_PANEL_IDS = tuple(f"{space}_PT_{EXTENSION_ID}" for space in (
    "VIEW3D", "IMAGE", "NODE", "SEQUENCER", "CLIP", "DOPESHEET", "GRAPH", "NLA",
    "TEXT", "FILEBROWSER", "ASSETBROWSER", "SPREADSHEET",
))
