# SPDX-License-Identifier: GPL-3.0-or-later
"""Node-space coordinates and grouping for the arrangement pass."""
from collections import defaultdict

import bpy
from mathutils import Vector

from . import config


def get_ntree():
    return bpy.context.space_data.edit_tree


def group_by(iterable, key, sort=False):
    groups = defaultdict(list)
    for value in iterable:
        groups[key(value)].append(value)
    ordered = sorted(groups) if sort else groups
    return {tuple(groups[label]): label for label in ordered}


def abs_loc(node):
    return node.location_absolute.copy()


REROUTE_DIM = Vector((8, 8))


def dimensions(node):
    if node.bl_idname == "NodeReroute":
        return REROUTE_DIM
    scale = bpy.context.preferences.system.ui_scale
    return node.dimensions / scale


def _vertical_edges(node, y_loc):
    baseline = abs_loc(node).y if y_loc is None else y_loc
    height = dimensions(node).y
    adjustment = height / 2 - 10 if node.hide else 0
    top = baseline + adjustment
    return top, top - height


def get_top(node, y_loc=None):
    return _vertical_edges(node, y_loc)[0]


def get_bottom(node, y_loc=None):
    return _vertical_edges(node, y_loc)[1]


def frame_padding():
    system = bpy.context.preferences.system
    unit_pixels = int(18 * system.ui_scale)
    padding_pixels = (unit_pixels + 2 * system.pixel_size) * 1.5
    return padding_pixels / system.ui_scale


def move(node, *, x=0, y=0):
    if not x and not y:
        return
    position = node.location + Vector((float(x), float(y)))
    limit = 100_000
    node.location = tuple(max(-limit, min(limit, coord)) for coord in position)
