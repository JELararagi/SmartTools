# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Compatibility callbacks. Shortcuts are configured explicitly by the user."""
addon_keymaps = []


def sync_from_settings(context=None):
    return None


def register():
    return None


unregister = register
