# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Scratch state for one arrangement pass, reset in place for clients."""
from collections import defaultdict

selected = []
linked_sockets = defaultdict(set)
multi_input_sort_ids = defaultdict(list)


def reset():
    global SETTINGS, MARGIN
    for collection in (selected, linked_sockets, multi_input_sort_ids):
        collection.clear()
    SETTINGS = MARGIN = None
