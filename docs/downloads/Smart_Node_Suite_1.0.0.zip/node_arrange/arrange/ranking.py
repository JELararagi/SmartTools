"""Column ranks for nested Blender node graphs."""

from collections import Counter, defaultdict

import networkx as nx

from .graph import Kind


def minimum_length_ranks(nodes, edges):
    """Minimize total edge span subject to one-column minimum separation."""
    flow_graph = nx.DiGraph()
    flow_graph.add_nodes_from(nodes)
    demand = Counter()
    for source, destination in edges:
        demand[source] -= 1
        demand[destination] += 1
        flow_graph.add_edge(source, destination, weight=-1)
    nx.set_node_attributes(flow_graph, demand, 'demand')
    if not flow_graph:
        return {}

    # Unit flow on every original edge is feasible. Minimum cost flow gives
    # the dual optimum; each arc carrying flow must have minimum span.
    _, flow = nx.network_simplex(flow_graph)
    constraints = nx.DiGraph()
    origin = object()
    constraints.add_node(origin)
    constraints.add_weighted_edges_from((origin, node, 0) for node in flow_graph)
    for source, destination in flow_graph.edges:
        constraints.add_edge(source, destination, weight=-1)
        if flow[source][destination] > 0:
            constraints.add_edge(destination, source, weight=1)
    distances = nx.single_source_bellman_ford_path_length(constraints, origin)
    return {node: -distances[node] for node in flow_graph}


def _frame_edges(tree):
    for parent, child in tree.edges:
        if parent.type != Kind.CLUSTER:
            continue
        left, right = (
            (child.left, child.right) if child.type == Kind.CLUSTER else (child, child)
        )
        yield parent.left, left
        yield right, parent.right


def _place_separate_islands(cluster_graph):
    graph = cluster_graph.G
    members = cluster_graph.T
    for island in nx.weakly_connected_components(graph):
        cluster = next(iter(island)).cluster
        if any(node.cluster != cluster for node in island):
            continue

        columns = sorted({node.rank for node in island})
        if cluster.node:
            first = min(node.rank for node in members[cluster] if node.type != Kind.CLUSTER)
        else:
            first = cluster.left.rank - (len(columns) - 1)
        mapped = {rank: first + position for position, rank in enumerate(columns)}
        for node in island:
            node.rank = mapped[node.rank]


def _compact_and_balance(graph):
    columns = defaultdict(list)
    for node in graph:
        columns[node.rank].append(node)
    for rank, old_rank in enumerate(sorted(columns)):
        for node in columns[old_rank]:
            node.rank = rank

    occupancy = Counter(node.rank for node in graph)
    for node in graph:
        incoming = len(graph.pred[node])
        outgoing = len(graph.succ[node])
        if not incoming or incoming != outgoing:
            continue
        left = 1 + max(neighbor.rank for neighbor in graph.pred[node])
        right = min(neighbor.rank for neighbor in graph.succ[node])
        if right <= left:
            continue
        best = min(range(left, right), key=lambda rank: (occupancy[rank], abs(rank-node.rank), rank))
        if occupancy[best] < occupancy[node.rank]:
            occupancy[node.rank] -= 1
            occupancy[best] += 1
            node.rank = best


def compute_ranks(cluster_graph):
    tree = cluster_graph.T
    for depth, level in enumerate(nx.topological_generations(tree)):
        for cluster in cluster_graph.S.intersection(level):
            cluster.nesting_level = depth

    graph = nx.MultiDiGraph(cluster_graph.G)
    graph.add_edges_from(_frame_edges(tree))
    ranks = minimum_length_ranks(graph.nodes, graph.edges(keys=False))
    for node, rank in ranks.items():
        node.rank = rank

    root = next(cluster for cluster in cluster_graph.S if not tree.pred[cluster])
    graph.remove_nodes_from((root.left, root.right))
    _place_separate_islands(cluster_graph)
    _compact_and_balance(graph)
