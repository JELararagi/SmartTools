from __future__ import annotations

from collections.abc import Sequence
from itertools import chain
from statistics import fmean

import networkx as nx
from bpy.types import NodeTree
from mathutils import Vector

from .. import config
from ..utils import abs_loc, get_ntree
from .graph import (
  FROM_SOCKET,
  TO_SOCKET,
  Cluster,
  ClusterGraph,
  Kind,
  Node,
  Socket,
  get_reroute_paths,
  is_real,
  node_name,
)
from .ordering import minimize_crossings
from .ranking import compute_ranks
from .realize import realize_layout, remove_reroutes
from .stacking import contracted_node_stacks, expand_node_stack
from .x_coords import assign_x_coords, route_edges
from .y_coords import bk_assign_y_coords

# -------------------------------------------------------------------


def precompute_links(ntree: NodeTree) -> None:
    sockets = config.linked_sockets
    viable = (link for link in ntree.links if link.is_valid and not link.is_hidden)
    for link in viable:
        endpoints = link.from_socket, link.to_socket
        for local, remote in (endpoints, endpoints[::-1]):
            sockets[local].add(remote)


def get_multidigraph() -> nx.MultiDiGraph[Node]:
    frames = dict.fromkeys(node.parent for node in get_ntree().nodes)
    ancestry = {frame: Cluster(frame, None) for frame in frames}
    for frame, group in ancestry.items():
        if frame is not None:
            group.cluster = ancestry[frame.parent]

    selected = {source: Node(source, ancestry[source.parent]) for source in config.selected
                if source.bl_idname != "NodeFrame"}
    result = nx.MultiDiGraph()
    result.add_nodes_from(selected.values())
    input_indices = {port: index for source in selected for index, port in enumerate(source.inputs)}
    for source, upstream in selected.items():
        for index, output in enumerate(source.outputs):
            port = Socket(upstream, index, True)
            for remote in config.linked_sockets[output]:
                if remote.node.select:
                    downstream = selected[remote.node]
                    target = Socket(downstream, input_indices[remote], False)
                    result.add_edge(upstream, downstream, **{FROM_SOCKET: port, TO_SOCKET: target})
    return result


def save_multi_input_orders(G: nx.MultiDiGraph[Node]) -> None:
    slots = {(link.from_socket, link.to_socket): link.multi_input_sort_id
             for link in get_ntree().links if link.to_socket.is_multi_input}
    for upstream, downstream, edge in G.edges.data():
        output, target = edge[FROM_SOCKET], edge[TO_SOCKET]
        physical_target = target.bpy
        if not physical_target.is_multi_input:
            continue
        source = output
        if upstream.is_reroute:
            link_origin, next_node = upstream, downstream
            for successor, predecessor in nx.bfs_edges(G, upstream, reverse=True):
                next_node, link_origin = successor, predecessor
                if not link_origin.is_reroute:
                    break
            source = G.edges[link_origin, next_node, 0][FROM_SOCKET]
        config.multi_input_sort_ids[target].append((source, slots[output.bpy, physical_target]))


def add_columns(G: nx.DiGraph[Node]) -> None:
    by_rank = {}
    for node in G:
        by_rank.setdefault(node.rank, []).append(node)

    def row_key(node):
        initial = abs_loc(node.node).y if is_real(node) and G.degree[node] == 0 else 0
        return -initial, node_name(node)

    columns = [sorted(by_rank[rank], key=row_key) for rank in sorted(by_rank)]
    for column in columns:
        for node in column:
            node.col = column
    G.graph["columns"] = columns


def dissolve_dummy_nodes(CG: ClusterGraph) -> None:
    def phantom(node):
        return node.is_reroute and not is_real(node)

    model = CG.G
    for route in get_reroute_paths(CG, phantom, preserve_reroute_clusters=False):
        first_link = next(iter(model.in_edges(route[0], data=FROM_SOCKET)), None)
        if first_link is not None:
            start, _, output = first_link
            ports = [port for _, _, port in model.out_edges(route[-1], data=TO_SOCKET)]
            model.add_edges_from((start, port.owner, {FROM_SOCKET: output, TO_SOCKET: port}) for port in ports)
        CG.remove_nodes_from(route)


# -------------------------------------------------------------------


def get_foreign_sockets_of(path: Sequence[Node], G: nx.DiGraph[Node]) -> list[Socket]:
    inputs = G.in_edges(path[0], data=FROM_SOCKET)
    outputs = G.out_edges(path[-1], data=TO_SOCKET)
    return [e[2] for e in chain(inputs, outputs)]


def align_reroutes_with_sockets(CG: ClusterGraph) -> None:
    def contacts(route):
        return get_foreign_sockets_of(route, CG.G)

    schedule = {tuple(route): contacts(route)
                for route in get_reroute_paths(CG, preserve_reroute_clusters=False, aligned=True, linear=False)}
    membership = {point: route for route in schedule for point in route}

    def available(route, destination, moves_up):
        margin = config.MARGIN.y
        for point in route:
            row = point.col.index(point)
            if moves_up and row:
                above = point.col[row - 1]
                if destination > above.y - above.height - margin:
                    return False
            elif not moves_up and row + 1 < len(point.col):
                below = point.col[row + 1]
                if below.y + margin > destination - route[0].height:
                    return False
        return True

    while schedule:
        advanced = False
        for route in tuple(schedule):
            if route not in schedule:
                continue
            candidates = schedule[route]
            height = route[0].y
            candidates.sort(key=lambda port: (not port.owner.is_reroute,
                                              height != port.owner.y, abs(height - port.y)))
            if not candidates or height == candidates[0].y:
                del schedule[route]
                continue
            target = candidates[0]
            distance = height - target.y
            if not available(route, height - distance, distance < 0):
                continue

            for point in route:
                point.y -= distance
            advanced = True
            if target.owner.is_reroute:
                adjacent = membership[target.owner]
                combined = route + adjacent if target.owner.rank > route[-1].rank else adjacent + route
                schedule[combined] = contacts(combined)
                del schedule[route]
                schedule.pop(adjacent, None)
                membership.update(dict.fromkeys(combined, combined))

        if not advanced:
            for candidates in schedule.values():
                del candidates[0]


# -------------------------------------------------------------------


def sugiyama_layout(ntree: NodeTree) -> None:
    locs = [abs_loc(n) for n in config.selected if n.bl_idname != 'NodeFrame']

    if not locs:
        return

    old_center = Vector(map(fmean, zip(*locs)))

    precompute_links(ntree)
    CG = ClusterGraph(get_multidigraph())
    G = CG.G
    T = CG.T

    save_multi_input_orders(G)
    if config.SETTINGS.add_reroutes:
        remove_reroutes(CG)

    if config.SETTINGS.stack_collapsed:
        node_stacks = contracted_node_stacks(CG)

    compute_ranks(CG)
    CG.merge_edges()
    CG.insert_dummy_nodes()

    add_columns(G)
    minimize_crossings(G, T)

    CG.add_vertical_border_nodes()
    CG.remove_nodes_from([v for v in G if v.is_fill_dummy])
    bk_assign_y_coords(G, T)

    if not config.SETTINGS.add_reroutes:
        dissolve_dummy_nodes(CG)

    align_reroutes_with_sockets(CG)
    CG.remove_nodes_from([v for v in G if v.type == Kind.VERTICAL_BORDER])
    assign_x_coords(G, T)
    if config.SETTINGS.add_reroutes:
        route_edges(G, T)

    if config.SETTINGS.stack_collapsed:
        for node_stack in node_stacks:
            expand_node_stack(CG, node_stack)

    realize_layout(CG, old_center)
