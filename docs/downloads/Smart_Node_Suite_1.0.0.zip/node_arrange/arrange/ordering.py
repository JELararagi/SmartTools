# https://link.springer.com/chapter/10.1007/3-540-36151-0_26
# https://doi.org/10.1016/j.jvlc.2013.11.005
# https://doi.org/10.1007/978-3-642-11805-0_14
# https://link.springer.com/chapter/10.1007/978-3-540-31843-9_22
# https://doi.org/10.7155/jgaa.00088

from __future__ import annotations

import random
from collections.abc import Callable, Collection, Iterable, Iterator, Sequence
from dataclasses import replace
from functools import cache
from itertools import pairwise
from math import inf
from operator import itemgetter
from statistics import fmean
from typing import TypeAlias, cast

import networkx as nx

from .. import config
from .graph import FROM_SOCKET, TO_SOCKET, Cluster, Kind, Node, Socket, socket_graph

# -------------------------------------------------------------------

_MixedGraph: TypeAlias = 'nx.DiGraph[Node | Cluster]'


def get_col_nesting_trees(
  columns: Sequence[Collection[Node]],
  T: _MixedGraph,
) -> list[_MixedGraph]:
    projections = []
    for column in columns:
        projection = nx.DiGraph()
        frontier = list(dict.fromkeys(node for node in column if node in T))
        scheduled = set(frontier)
        for descendant in frontier:
            for parent in T.predecessors(descendant):
                projection.add_edge(parent, descendant)
                if parent not in scheduled:
                    frontier.append(parent)
                    scheduled.add(parent)
        projections.append(projection)
    return projections


def expand_multi_inputs(G: nx.MultiDiGraph[Node]) -> None:
    ordering = config.multi_input_sort_ids
    if not ordering:
        return
    paths = socket_graph(G)
    pass_through = {port for port in paths if port.owner.is_reroute}
    for destination in dict.fromkeys(port.owner for port in ordering):
        arrivals = {}
        for _, _, attrs in G.in_edges(destination, data=True):
            arrivals.setdefault(attrs[TO_SOCKET], []).append(attrs)
        if not arrivals:
            continue
        target_ports = sorted(arrivals, key=lambda port: port.idx)
        rank = target_ports[0].idx
        for target in target_ports:
            if target not in ordering:
                if target.idx != rank:
                    arrivals[target][0][TO_SOCKET] = replace(target, idx=rank)
                rank += 1
                continue

            prior_links = sorted(ordering[target], key=itemgetter(1), reverse=True)
            region = paths.subgraph(pass_through | {target} | {source for source, _ in prior_links})
            consumed = set()
            candidates = {attrs[FROM_SOCKET]: attrs for attrs in reversed(arrivals[target])}
            for source, _ in prior_links:
                arrival = next(head for head, tail in nx.edge_dfs(region, source)
                               if tail == target and head not in consumed)
                candidates[arrival][TO_SOCKET] = replace(target, idx=rank)
                consumed.add(arrival)
                rank += 1


@cache
def reflexive_transitive_closure(LT: _MixedGraph) -> _MixedGraph:
    return cast(_MixedGraph, nx.transitive_closure(LT, reflexive=True))


@cache
def topologically_sorted_clusters(LT: _MixedGraph) -> list[Cluster]:
    return [h for h in nx.topological_sort(LT) if h.type == Kind.CLUSTER]


def crossing_reduction_graph(
    h: Cluster,
    LT: _MixedGraph,
    G: nx.MultiDiGraph[Node],
) -> nx.MultiDiGraph[Node | Cluster]:
    projection = nx.MultiDiGraph()
    branches = LT[h]
    projection.add_nodes_from(branches)
    reach = reflexive_transitive_closure(LT)
    child_for = {item: branch for branch in branches for item in reach[branch]}
    for source, destination, key, edge in G.in_edges(reach[h], data=True, keys=True):
        branch = child_for[destination]
        forward = edge[FROM_SOCKET].owner == source
        source_field, target_field = (FROM_SOCKET, TO_SOCKET) if forward else (TO_SOCKET, FROM_SOCKET)
        output = edge[source_field]
        existing = projection.get_edge_data(source, branch, key)
        if existing is not None and existing[source_field] == output:
            existing["weight"] += 1
            continue
        target = edge[target_field]
        if branch.type == Kind.CLUSTER:
            target = replace(target, owner=branch, idx=0)
        projection.add_edge(source, branch, from_socket=output, to_socket=target, weight=1)
    return projection


_BALANCING_FAC = 1


class _CrossingReductionGraph:
    graph: nx.MultiDiGraph[Node | Cluster]

    fixed_LT: _MixedGraph
    free_LT: _MixedGraph

    fixed_col: list[Node]
    free_col: list[Node]

    expanded_fixed_col: list[Node]
    reduced_free_col: list[Node | Cluster]

    fixed_sockets: dict[Node, list[Socket]]
    free_sockets: dict[Node | Cluster, list[Socket]]

    border_pairs: dict[tuple[Node, Node], list[Node]]
    constrained_clusters: list[Cluster]

    N: list[Socket]
    S: list[Socket]
    bipartite_edges: list[tuple[Socket, Socket, int]]

    __slots__ = tuple(__annotations__)

    def _insert_border_edges(self, is_forwards: bool) -> None:
        self.border_pairs = {}
        common = {item for item in self.reduced_free_col if item.type == Kind.CLUSTER} & self.fixed_LT.nodes
        for frame in common:
            fixed_children = nx.descendants(self.fixed_LT, frame)
            overlap = fixed_children.intersection(nx.descendants(self.free_LT, frame))
            weight = _BALANCING_FAC * (len(overlap) + 1) / 2
            borders = (Node(type=Kind.VERTICAL_BORDER), Node(type=Kind.VERTICAL_BORDER))
            frame_port = Socket(frame, 0, not is_forwards)
            self.expanded_fixed_col.extend(borders)
            self.border_pairs[borders] = [item for item in fixed_children if item.type != Kind.CLUSTER]
            self.graph.add_edges_from(
                (border, frame, {FROM_SOCKET: Socket(border, 0, is_forwards),
                                 TO_SOCKET: frame_port, "weight": weight})
                for border in borders
            )

    def _add_bipartite_edges(self) -> None:
        order = {}
        outgoing = {}
        incoming = {}
        for _, _, edge in self.graph.edges.data():
            start, end = edge[FROM_SOCKET], edge[TO_SOCKET]
            order.update(dict.fromkeys((start, end)))
            weight = edge.get("weight")
            outgoing.setdefault(start, {})[end] = weight
            incoming.setdefault(end, {})[start] = weight
        if len(incoming) > len(outgoing):
            outgoing, incoming = incoming, outgoing
        index = lambda port: port.idx
        self.N = sorted(set(outgoing), key=index)
        self.S = sorted(set(incoming), key=index)
        self.bipartite_edges = [
            (start, end, weight)
            for start in order
            for end, weight in outgoing.get(start, {}).items()
        ]

    def __init__(
        self,
        G: nx.MultiDiGraph[Node],
        h: Cluster,
        fixed_LT: _MixedGraph,
        free_LT: _MixedGraph,
        is_forwards: bool,
    ) -> None:
        self.fixed_LT, self.free_LT = fixed_LT, free_LT
        self.fixed_col, self.free_col = (
            next(item.col for item in tree if item.type != Kind.CLUSTER)
            for tree in (fixed_LT, free_LT)
        )
        projected = crossing_reduction_graph(h, free_LT, G)
        projected.add_nodes_from(self.fixed_col)
        self.graph = projected
        self.expanded_fixed_col = list(self.fixed_col)
        positions = {item: row for row, item in reversed(tuple(enumerate(self.free_col)))}
        self.reduced_free_col = sorted(free_LT[h], key=lambda item: positions.get(item, inf))
        self._insert_border_edges(is_forwards)

        self.fixed_sockets = {}
        for node in self.expanded_fixed_col:
            ports = {port for _, _, port in projected.out_edges(node, data=FROM_SOCKET)}
            if ports:
                self.fixed_sockets[node] = sorted(ports, key=lambda port: port.idx, reverse=is_forwards)
        self.free_sockets = {
            item: [port for _, _, port in projected.in_edges(item, data=FROM_SOCKET)]
            for item in self.reduced_free_col
        }
        self.constrained_clusters = [item for item in self.reduced_free_col if item in fixed_LT]
        self._add_bipartite_edges()


def crossing_reduction_items(
  trees: Iterable[_MixedGraph],
  G: nx.MultiDiGraph[Node],
  is_forwards: bool,
) -> list[list[_CrossingReductionGraph]]:
    items = []
    for fixed_LT, free_LT in pairwise(trees):
        crossing_reduction_graphs = [
          _CrossingReductionGraph(G, h, fixed_LT, free_LT, is_forwards)
          for h in topologically_sorted_clusters(free_LT)]
        items.append(crossing_reduction_graphs)

    return items


# -------------------------------------------------------------------


def sort_expanded_fixed_col(H: _CrossingReductionGraph) -> None:
    placements = {node: (row, 0) for row, node in enumerate(H.fixed_col)}
    for (upper, lower), interior in H.border_pairs.items():
        span = [placements[node][0] for node in interior]
        placements[upper] = min(span), -1
        placements[lower] = max(span), 1
    H.expanded_fixed_col.sort(key=placements.__getitem__)


def calc_socket_ranks(H: _CrossingReductionGraph, is_forwards: bool) -> None:
    placement = {node: i for i, node in enumerate(H.expanded_fixed_col, 1)}
    direction = -1 if is_forwards else 1
    for owner, sockets in H.fixed_sockets.items():
        step = direction / (len(sockets) + 1)
        rank = placement[owner]
        for port in sockets:
            rank += step
            owner.cr.socket_ranks[port] = rank


def random_perturbation() -> float:
    random_amount = random.uniform(-1, 1)
    return random.uniform(0, 1) * random_amount - random_amount / 2


def calc_barycenters(H: _CrossingReductionGraph) -> None:
    for w in H.reduced_free_col:
        if sockets := H.free_sockets[w]:
            w.cr.barycenter = (
              fmean([s.owner.cr.socket_ranks[s] for s in sockets]) + random_perturbation())


def get_barycenter(v: Node | Cluster) -> float:
    barycenter = v.cr.barycenter
    assert barycenter is not None
    return barycenter


def fill_in_unknown_barycenters(col: list[Node | Cluster], is_first_sweep: bool) -> None:
    if is_first_sweep:
        known = (entry.cr.barycenter for entry in col if entry.cr.barycenter is not None)
        ceiling = max(known, default=0) + 2
        for entry in col:
            if entry.cr.barycenter is None:
                entry.cr.barycenter = random.uniform(0, 1) * ceiling - 1 + random_perturbation()
        return

    next_known = {}
    upcoming = None
    for entry in reversed(col):
        if entry.cr.barycenter is None:
            next_known[entry] = upcoming
        else:
            upcoming = entry.cr.barycenter
    previous = 0
    for entry in col:
        if entry in next_known:
            right = next_known[entry]
            entry.cr.barycenter = (previous + (previous + 1 if right is None else right)) / 2 + random_perturbation()
        previous = get_barycenter(entry)


def handle_constraints(H: _CrossingReductionGraph) -> None:
    # The fixed column supplies a single ordered chain of frames. Pool locally
    # inverted runs before placing the unrelated siblings by their own scores.
    frames = H.constrained_clusters
    blocks = []
    for frame in frames:
        score = get_barycenter(frame)
        weight = H.graph.degree[frame]
        members = [frame]
        while blocks and blocks[-1][0] >= score:
            previous_score, previous_weight, previous_members = blocks.pop()
            total_weight = previous_weight + weight
            if total_weight:
                score = (previous_score * previous_weight + score * weight) / total_weight
            else:
                score = (previous_score + score) / 2
            weight = total_weight
            previous_members.extend(members)
            members = previous_members
        blocks.append((score, weight, members))

    positions = {item: row for row, item in enumerate(H.reduced_free_col)}
    constrained = set(frames)
    groups = [(score, positions[members[0]], members) for score, _, members in blocks]
    groups.extend((get_barycenter(item), positions[item], [item])
                  for item in H.reduced_free_col if item not in constrained)
    groups.sort(key=itemgetter(0, 1))
    row = 0
    for _, _, members in groups:
        for item in members:
            item.cr.barycenter = row
            row += 1


def get_cross_count(H: _CrossingReductionGraph) -> int | float:
    links = H.bipartite_edges
    if not links:
        return 0

    free_owners = set(H.reduced_free_col)
    fixed_positions = {owner: index for index, owner in reversed(tuple(enumerate(H.expanded_fixed_col)))}

    def rank(socket: Socket) -> float:
        owner = socket.owner
        if owner in free_owners:
            return owner.cr.barycenter
        return fixed_positions[owner]

    H.N.sort(key=rank)
    H.S.sort(key=rank)
    starts = {socket: index for index, socket in enumerate(H.N)}
    # Index from the far end. A prefix then contains precisely the ends
    # that precede this one in the sweep and lie strictly beyond it.
    ends = {socket: index for index, socket in enumerate(reversed(H.S), start=1)}
    links.sort(key=lambda link: (starts[link[0]], -ends[link[1]]))
    prefix = [0] * (len(ends) + 1)
    total = 0
    for _, target, weight in links:
        end = ends[target]
        cursor = end - 1
        beyond = 0
        while cursor:
            beyond += prefix[cursor]
            cursor &= cursor - 1
        total += weight * beyond

        cursor = end
        while cursor < len(prefix):
            prefix[cursor] += weight
            cursor += cursor & -cursor
    return total


def get_new_col_order(v: Node | Cluster, LT: _MixedGraph) -> Iterator[Node]:
    if v.type == Kind.CLUSTER:
        for w in sorted(LT[v], key=get_barycenter):
            yield from get_new_col_order(w, LT)
    else:
        yield v


@cache
def non_cluster_descendant(T: _MixedGraph, c: Cluster) -> Node:
    return next(v for _, v in nx.bfs_edges(T, c) if v.type != Kind.CLUSTER)


def sort_reduced_free_columns(items: Iterable[Sequence[_CrossingReductionGraph]]) -> None:
    for sweep in items:
        for layout in sweep:
            position = {entry: row for row, entry in enumerate(layout.free_col)}

            def sibling_position(entry: Node | Cluster) -> int:
                if entry.type == Kind.CLUSTER:
                    entry = non_cluster_descendant(layout.free_LT, entry)
                return position[entry]

            layout.reduced_free_col.sort(key=sibling_position)


# -------------------------------------------------------------------


def minimized_cross_count(
    columns: Sequence[list[Node]],
    forward_items: list[list[_CrossingReductionGraph]],
    backward_items: list[list[_CrossingReductionGraph]],
    T: _MixedGraph,
) -> float:
    best_score = inf
    best_columns = [tuple(column) for column in columns]
    forwards = random.choice((True, False))
    initial = True
    while True:
        for item in T:
            item.cr.reset()
        if best_score == 0:
            return 0

        forwards = not forwards
        score = 0
        sweep = forward_items if forwards else backward_items
        for row, layouts in enumerate(sweep):
            key = get_barycenter
            if row == 0:
                anchors = {}
                for index, item in enumerate(layouts[0].fixed_col):
                    anchors.update(dict.fromkeys(nx.ancestors(T, item), index))
                key = anchors.get
            for layout in layouts:
                layout.constrained_clusters.sort(key=key)
                sort_expanded_fixed_col(layout)
                calc_socket_ranks(layout, forwards)
                calc_barycenters(layout)
                fill_in_unknown_barycenters(layout.reduced_free_col, initial)
                handle_constraints(layout)
                score += get_cross_count(layout)

            target = layouts[-1]
            tree = target.free_LT
            root = topologically_sorted_clusters(tree)[0]
            order = {item: index for index, item in enumerate(get_new_col_order(root, tree))}
            target.free_col.sort(key=order.__getitem__)

        if score >= best_score:
            for column, accepted in zip(columns, best_columns):
                column[:] = accepted
            return best_score
        sort_reduced_free_columns(forward_items + backward_items)
        best_score = score
        best_columns = [tuple(column) for column in columns]
        initial = False


def minimize_crossings(G: nx.MultiDiGraph[Node], T: _MixedGraph) -> None:
    columns = G.graph["columns"]
    trees = get_col_nesting_trees(columns, T)
    working = G.copy()
    expand_multi_inputs(working)
    layouts = (
        crossing_reduction_items(trees, working, True),
        crossing_reduction_items(reversed(trees), nx.reverse_view(working), False),
    )

    random.seed(0)
    best = inf
    accepted = [tuple(column) for column in columns]
    for _ in range(config.SETTINGS.iterations):
        score = minimized_cross_count(columns, *layouts, T)
        if score == 0:
            return
        if score < best:
            best = score
            accepted = [tuple(column) for column in columns]
            continue
        for column, order in zip(columns, accepted):
            column[:] = order
        sort_reduced_free_columns(layouts[0] + layouts[1])
