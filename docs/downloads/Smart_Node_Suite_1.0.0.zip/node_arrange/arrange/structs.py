# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Binary-layout adapters for the native node-socket coordinates.

These types describe memory layout, not Blender-owned memory lifetimes.  The
layout is assembled from field specifications so offsets can be checked before
using a pointer supplied by Blender.  Never free or retain an as_pointer()
address after Blender invalidates the socket.
"""

from __future__ import annotations

import ctypes as C
import platform

import bpy


class bNodeStack(C.Structure):
    """Inline scalar and vector storage carried by a native node socket."""


class bNodeSocketRuntime(C.Structure):
    """Transient socket information, including its node-editor position."""


class bNodeSocket(C.Structure):
    """Non-owning view of a Blender-owned socket when used with from_address."""


# Named building blocks express the ABI independently of the declaration
# strategy used in older versions of the add-on.  Only the documented consumer
# path (socket.runtime.contents.location) requires native pointer access.
_SCALAR = {
    'address': C.c_void_p,
    'signed8': C.c_int8,
    'signed16': C.c_int16,
    'signed32': C.c_int32,
    'unsigned32': C.c_uint32,
    'float32': C.c_float,
    'character': C.c_char,
}


def _native_type(specification):
    """Turn a compact field specification into a ctypes storage type."""
    if specification == 'stack':
        return bNodeStack
    if specification == 'runtime_ptr':
        return C.POINTER(bNodeSocketRuntime)
    if specification == 'char_ptr':
        return C.POINTER(C.c_char)
    if '[' in specification:
        kind, width = specification[:-1].split('[', 1)
        return _SCALAR[kind] * int(width)
    return _SCALAR[specification]


def _declare(structure, specification):
    """Materialize ordered, typed C records once per imported module."""
    structure._fields_ = [
        (field_name, _native_type(field_type))
        for field_name, field_type in specification
    ]


_version = tuple(bpy.app.version[:3])
_pre_5 = _version < (5, 0, 0)
_pre_5_1 = _version < (5, 1, 0)
_windows = platform.system() == 'Windows'

# The inline stack is a value field: it is embedded, not a separately owned
# pointer.  Define it before the containing socket structure.
_declare(bNodeStack, (
    ('vec', 'float32[4]'),
    ('min', 'float32'),
    ('max', 'float32'),
    ('data', 'address'),
    ('hasinput', 'signed16'),
    ('hasoutput', 'signed16'),
    ('datatype', 'signed16'),
    ('sockettype', 'signed16'),
    ('is_copy', 'signed16'),
    ('external', 'signed16'),
    ('_pad', 'character[4]'),
))

runtime_layout = []
if _windows:
    runtime_layout.append(('_pad0', 'character[8]'))
runtime_layout.extend((
    ('declaration', 'address'),
    ('changed_flag', 'unsigned32'),
    ('total_inputs', 'signed16'),
))
if not _pre_5:
    runtime_layout.append(('inferred_structure_type', 'signed8'))
runtime_layout.extend((
    ('_pad1', 'signed8[1]'),
    ('location', 'float32[2]'),
))
_declare(bNodeSocketRuntime, runtime_layout)

socket_layout = [
    ('next', 'address'),
    ('prev', 'address'),
    ('prop', 'address'),
    ('identifier', 'character[64]'),
    ('name', 'character[64]'),
    ('storage', 'address'),
    ('type', 'signed16'),
    ('flag', 'signed16'),
    ('limit', 'signed16'),
    ('in_out', 'signed16'),
    ('typeinfo', 'address'),
    ('idname', 'character[64]'),
    ('default_value', 'address'),
    ('stack_index', 'signed16' if _pre_5 else 'signed32'),
    ('display_shape', 'character'),
    ('attribute_domain', 'character'),
    ('_pad', 'character[4]' if _pre_5 else 'character[2]'),
    ('label', 'character[64]'),
    ('description', 'character[64]'),
]
if _pre_5_1:
    socket_layout.append(('short_label', 'character[64]'))
socket_layout.extend((
    ('default_attribute_name', 'char_ptr'),
    ('own_index', 'signed32'),
    ('to_index', 'signed32'),
    ('link', 'address'),
    ('ns', 'stack'),
    ('runtime', 'runtime_ptr'),
))
_declare(bNodeSocket, socket_layout)

# No custom equality or setters: ctypes.Structure retains identity equality,
# positional/keyword constructors, mutable scalar/array members, and
# from_address() compatibility.  None of these structures owns Blender memory.
