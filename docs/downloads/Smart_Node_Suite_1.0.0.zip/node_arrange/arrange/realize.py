from __future__ import annotations

from math import isclose
from statistics import fmean

import networkx as nx
from bpy.types import Node as BlenderNode
from mathutils import Vector

from .. import config
from ..utils import get_ntree, move
from .graph import (
  FROM_SOCKET,
  TO_SOCKET,
  Cluster,
  ClusterGraph,
  Kind,
  Node,
  Socket,
  add_dummy_edge,
  get_reroute_paths,
  is_real,
  socket_graph,
)


def is_safe_to_remove(v: Node) -> bool:
    if not is_real(v):
        return True
    node = v.node
    if node.label:
        return False
    pinned = any(source.owner == v for assignments in config.multi_input_sort_ids.values()
                 for source, _ in assignments)
    if pinned:
        return False
    connected = config.linked_sockets[node.inputs[0]] | config.linked_sockets[node.outputs[0]]
    return not any(not port.node.select for port in connected)


def dissolve_reroute_edges(G: nx.DiGraph[Node], path: list[Node]) -> None:
    tail = path[-1]
    incoming = next(iter(G.in_edges(path[0], data=FROM_SOCKET)), None)
    if incoming is None or not G[tail]:
        return
    source, _, output = incoming
    destinations = [port for _, _, port in G.out_edges(tail, data=TO_SOCKET)]
    requested = set(destinations)
    direct = {edge[TO_SOCKET] for _, _, edge in G.out_edges(source, data=True)
              if edge[FROM_SOCKET] == output}
    if not requested.isdisjoint(direct):
        path[:] = []
        return

    change_links = get_ntree().links.new
    for port in destinations:
        G.add_edge(source, port.owner, **{FROM_SOCKET: output, TO_SOCKET: port})
        change_links(output.bpy, port.bpy)


def remove_reroutes(CG: ClusterGraph) -> None:
    protected = {
        frame for frame in CG.S
        if not any(node.type == Kind.CLUSTER or not node.is_reroute for node in CG.T[frame])
    }
    for route in get_reroute_paths(CG, is_safe_to_remove):
        if route[0].cluster not in protected:
            dissolve_reroute_edges(CG.G, route)
            CG.remove_nodes_from(route)
        elif route[2:]:
            add_dummy_edge(CG.G, route[0], route[-1])
            CG.remove_nodes_from(route[1:-1])


_Y_TOL = 5


def simplify_path(CG: ClusterGraph, path: list[Node]) -> None:
    network = CG.G

    def boundary(node, incoming):
        view, field = (network.in_edges, FROM_SOCKET) if incoming else (network.out_edges, TO_SOCKET)
        _, _, port = next(iter(view(node, data=field)))
        return port

    def same_height(first, second):
        return isclose(first, second, abs_tol=_Y_TOL, rel_tol=0)

    head, tail = path[0], path[-1]
    has_source, has_target = bool(network.pred[head]), network.out_degree[tail] == 1
    if len(path) == 1:
        if has_source and has_target and head.col is not None and not is_real(head):
            output, target = boundary(head, True), boundary(tail, False)
            if same_height(output.y, target.y):
                network.add_edge(output.owner, target.owner, **{FROM_SOCKET: output, TO_SOCKET: target})
                CG.remove_nodes_from(path)
                path[:] = []
        return

    output = boundary(head, True) if has_source else None
    target = boundary(tail, False) if has_target else None
    trim_head = output is not None and same_height(output.y, head.y)
    trim_tail = target is not None and same_height(tail.y, target.y)
    retained = ([] if trim_head else [head]) + ([] if trim_tail else [tail])
    removed = path[1:-1] + [node for node in (head, tail) if node not in retained]
    source_port = output if trim_head else Socket(head, 0, True)
    target_port = target if trim_tail else Socket(tail, 0, False)
    if removed or source_port.owner != head or target_port.owner != tail:
        network.add_edge(source_port.owner, target_port.owner, **{FROM_SOCKET: source_port, TO_SOCKET: target_port})
    CG.remove_nodes_from(removed)
    path[:] = retained


def add_reroute(v: Node) -> None:
    frame = v.cluster
    assert frame
    tree = get_ntree()
    v.node = tree.nodes.new("NodeReroute")
    v.node.parent = frame.node
    config.selected.append(v.node)
    v.type = Kind.NODE


def realize_edges(G: nx.DiGraph[Node]) -> None:
    connect = get_ntree().links.new
    routes = (data for source, target, data in G.edges.data() if source.is_reroute or target.is_reroute)
    for route in routes:
        output, input_port = (route[key].bpy for key in (FROM_SOCKET, TO_SOCKET))
        connect(output, input_port)


def realize_dummy_nodes(CG: ClusterGraph) -> None:
    for path in get_reroute_paths(CG, is_safe_to_remove, aligned=True):
        simplify_path(CG, path)

        for v in path:
            if not is_real(v):
                add_reroute(v)

    realize_edges(CG.G)


def restore_multi_input_orders(G: nx.MultiDiGraph[Node]) -> None:
    socket_network = socket_graph(G)
    links = get_ntree().links
    for port, wanted in config.multi_input_sort_ids.items():
        input_port = port.bpy
        assert input_port
        indexed = {link.from_socket: link for link in links if link.to_socket == input_port}
        sources = {source.bpy for source in socket_network.pred[port]}
        for source in sources.difference(indexed):
            assert source
            indexed[source] = links.new(source, input_port)

        slots = {link.multi_input_sort_id for link in indexed.values()}
        if len(slots) != len(indexed):
            for link in indexed.values():
                links.remove(link)
            indexed = {source: links.new(source, input_port) for source in indexed}

        endpoints = {start for start, _ in wanted} | {port}
        endpoints.update(socket for socket in socket_network if socket.owner.is_reroute)
        scope = socket_network.subgraph(endpoints)
        assigned = set()
        for start, slot in wanted:
            position = min(indexed.values(), key=lambda link: abs(slot - link.multi_input_sort_id))
            path = nx.edge_dfs(scope, start)
            available = (source for source, target in path if target == port and source not in assigned)
            source = next(available)
            indexed[source.bpy].swap_multi_input_sort_id(position)
            assigned.add(source)


def realize_locations(G: nx.DiGraph[Node], old_center: Vector) -> None:
    axes = zip(*((node.x, node.y) for node in G))
    correction = old_center - Vector(tuple(map(fmean, axes)))
    for entry in G:
        display = entry.node
        parent = entry.cluster
        assert isinstance(display, BlenderNode) and parent
        display.parent = None
        left, top = display.location
        entry.x += correction.x
        entry.y += correction.y
        move(display, x=entry.x - left, y=entry.corrected_y() - top)
        display.parent = parent.node


def resize_unshrunken_frame(CG: ClusterGraph, cluster: Cluster) -> None:
    parent = cluster.node
    if parent is None or parent.shrink:
        return
    children = [entry.node for entry in CG.T[cluster] if is_real(entry)]
    for child in children:
        child.parent = None
    try:
        for size_to_children in (False, True):
            parent.shrink = size_to_children
    finally:
        for child in children:
            child.parent = parent


def realize_layout(CG: ClusterGraph, old_center: Vector) -> None:
    if config.SETTINGS.add_reroutes:
        realize_dummy_nodes(CG)

    restore_multi_input_orders(CG.G)
    realize_locations(CG.G, old_center)
    for c in CG.S:
        resize_unshrunken_frame(CG, c)
