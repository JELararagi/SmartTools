from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field
from enum import Enum, auto
from functools import cached_property
from itertools import chain, pairwise, product
from math import inf
from typing import Any, Literal, Sequence, TypeGuard

import bpy
import networkx as nx
from bpy.types import Node as BlenderNode
from bpy.types import NodeFrame, NodeSocket

from .. import config
from ..utils import (
  REROUTE_DIM,
  abs_loc,
  dimensions,
  frame_padding,
  get_bottom,
  get_ntree,
  get_top,
  group_by,
)
from .structs import bNodeSocket

# -------------------------------------------------------------------


class Kind(Enum):
    NODE = auto()
    STACK = auto()
    DUMMY = auto()
    CLUSTER = auto()
    HORIZONTAL_BORDER = auto()
    VERTICAL_BORDER = auto()


_NonCluster = Literal[
  Kind.NODE,
  Kind.STACK,
  Kind.DUMMY,
  Kind.HORIZONTAL_BORDER,
  Kind.VERTICAL_BORDER,]


@dataclass(slots=True)
class CrossingReduction:
    socket_ranks: dict[Socket, float] = field(default_factory=dict)
    barycenter: float | None = None

    def reset(self) -> None:
        self.socket_ranks.clear()
        self.barycenter = None


class Node:
    node: BlenderNode | None
    cluster: Cluster | None
    type: _NonCluster

    is_reroute: bool
    width: float
    height: float

    rank: int
    po_num: int
    lowest_po_num: int
    is_fill_dummy: bool

    col: list[Node]
    cr: CrossingReduction

    x: float
    y: float

    root: Node
    aligned: Node
    inner_shift: float
    sink: Node
    shift: float

    __slots__ = tuple(__annotations__)

    def __init__(
      self,
      node: BlenderNode | None = None,
      cluster: Cluster | None = None,
      type: _NonCluster = Kind.NODE,
      rank: int | None = None,
    ) -> None:
        self.node = node
        self.cluster = cluster
        self.type = type
        self.rank = rank  # type: ignore

        native = isinstance(node, BlenderNode)
        point_sized = type == Kind.DUMMY or (native and node.bl_idname == "NodeReroute")
        self.is_reroute = point_sized or (not native and type == Kind.VERTICAL_BORDER)
        self.width, self.height = 0, 0
        if point_sized:
            self.width, self.height = REROUTE_DIM
        elif native:
            self.width = dimensions(node).x
            self.height = get_top(node) - get_bottom(node)

        self.x = self.col = self.po_num = self.lowest_po_num = None  # type: ignore
        self.is_fill_dummy = False
        self.cr = CrossingReduction()
        self.bk_reset()

    def __hash__(self) -> int:
        return id(self)

    def bk_reset(self) -> None:
        self.root = self
        self.aligned = self
        self.inner_shift = 0

        self.sink = self
        self.shift = inf

        self.y = None  # type: ignore

    def corrected_y(self) -> float:
        assert is_real(self)
        return self.y + (abs_loc(self.node).y - get_top(self.node))


class _RealNode(Node):
    node: BlenderNode  # type: ignore


def is_real(v: Node | Cluster) -> TypeGuard[_RealNode]:
    return isinstance(v.node, BlenderNode)


def node_name(v: Node) -> str:
    return getattr(v.node, 'name', '')


Edge = tuple[Node, Node]
MultiEdge = tuple[Node, Node, int]


def opposite(v: Node, e: tuple[Node, Node] | tuple[Node, Node, ...]) -> Node:
    return e[0] if v != e[0] else e[1]


@dataclass(slots=True)
class Cluster:
    node: NodeFrame | None
    cluster: Cluster
    nesting_level: int | None = None
    cr: CrossingReduction = field(default_factory=CrossingReduction)
    left: Node = field(init=False)
    right: Node = field(init=False)

    def __post_init__(self) -> None:
        self.left = Node(None, self, Kind.HORIZONTAL_BORDER)
        self.right = Node(None, self, Kind.HORIZONTAL_BORDER)

    def __hash__(self) -> int:
        return id(self)

    @property
    def type(self) -> Literal[Kind.CLUSTER]:
        return Kind.CLUSTER

    def label_height(self) -> float:
        frame = self.node
        if frame and frame.label:
            return -(frame_padding() / 2 - frame.label_size * 1.25)
        else:
            return 0


# -------------------------------------------------------------------


def get_nesting_relations(v: Node | Cluster) -> Iterator[tuple[Cluster, Node | Cluster]]:
    if c := v.cluster:
        yield (c, v)
        yield from get_nesting_relations(c)


def lowest_common_cluster(
  T: nx.DiGraph[Node | Cluster],
  edges: Iterable[tuple[Node, Node, Any]],
) -> dict[Edge, Cluster]:
    pairs = {(u, v) for u, v, _ in edges if u.cluster != v.cluster}
    return dict(nx.tree_all_pairs_lowest_common_ancestor(T, pairs=pairs))


def add_dummy_edge(G: nx.DiGraph[Node], u: Node, v: Node) -> None:
    G.add_edge(u, v, from_socket=Socket(u, 0, True), to_socket=Socket(v, 0, False))


def add_dummy_nodes_to_edge(
  G: nx.MultiDiGraph[Node],
  edge: MultiEdge,
  dummy_nodes: Sequence[Node],
) -> None:
    if len(dummy_nodes) == 0:
        return
    start, finish, key = edge
    payload = G[start][finish][key]
    source_port, target_port = payload[FROM_SOCKET], payload[TO_SOCKET]
    first, last = dummy_nodes[0], dummy_nodes[-1]
    for left, right in zip(dummy_nodes, dummy_nodes[1:]):
        if not G.has_edge(left, right):
            add_dummy_edge(G, left, right)
    if not G.has_edge(start, first):
        G.add_edge(start, first, from_socket=source_port, to_socket=Socket(first, 0, False))
    G.add_edge(last, finish, from_socket=Socket(last, 0, True), to_socket=target_port)
    G.remove_edge(start, finish, key)

    if is_real(start) and is_real(finish) and target_port.bpy.is_multi_input:
        original_ports = source_port.bpy, target_port.bpy
        links = get_ntree().links
        original = next(link for link in links
                        if link.from_socket == original_ports[0] and link.to_socket == original_ports[1])
        links.remove(original)


def assign_clusters(
  dummy_nodes: Iterable[Node],
  start: Cluster,
  stop: Cluster,
  is_within_cluster: Callable[[Node, Cluster], bool],
) -> None:
    c = start
    for w in dummy_nodes:
        while c != stop and not is_within_cluster(w, c):
            c = c.cluster

        if c == stop:
            break

        w.cluster = c


def improve_cluster_assignment(e: Edge, dummy_nodes: Sequence[Node]) -> None:
    if config.SETTINGS.keep_reroutes_outside_frames:
        return

    start, finish = e
    left, right = start.cluster, finish.cluster
    assert left is not None and right is not None
    assign_left = assign_right = False
    if left.node and right.node and left.right.rank < right.left.rank:
        while left.cluster.node and left.cluster.right.rank < right.left.rank:
            left = left.cluster
        while right.cluster.node and left.right.rank < right.cluster.left.rank:
            right = right.cluster
        assign_left = assign_right = True
    elif right.node and start.rank < right.left.rank:
        while right.cluster.node and start.rank < right.cluster.left.rank:
            right = right.cluster
        assign_right = True
    elif left.node and finish.rank > left.right.rank:
        while left.cluster.node and finish.rank > left.cluster.right.rank:
            left = left.cluster
        assign_left = True

    if assign_left:
        assign_clusters(dummy_nodes, start.cluster, left.cluster,
                        lambda node, frame: node.rank <= frame.right.rank)
    if assign_right:
        assign_clusters(reversed(dummy_nodes), finish.cluster, right.cluster,
                        lambda node, frame: node.rank >= frame.left.rank)


# https://api.semanticscholar.org/CorpusID:14932050
class ClusterGraph:
    G: nx.MultiDiGraph[Node]
    T: nx.DiGraph[Node | Cluster]
    S: set[Cluster]
    __slots__ = tuple(__annotations__)

    def __init__(self, G: nx.MultiDiGraph[Node]) -> None:
        self.G = G
        self.T = nx.DiGraph()
        for endpoint in G:
            child = endpoint
            while (parent := child.cluster) is not None:
                self.T.add_edge(parent, child)
                child = parent
        self.S = {entry for entry in self.T if isinstance(entry, Cluster)}

    def remove_nodes_from(self, nodes: Iterable[Node]) -> None:
        editor_nodes = get_ntree().nodes
        neighbors = config.linked_sockets
        for entry in nodes:
            self.G.remove_node(entry)
            self.T.remove_node(entry)
            if entry.col:
                entry.col.remove(entry)
            if is_real(entry):
                native = entry.node
                removed_ports = set(native.inputs).union(native.outputs)
                for port in removed_ports & neighbors.keys():
                    del neighbors[port]
                for connected in neighbors.values():
                    connected.difference_update(removed_ports)
                config.selected.remove(native)
                editor_nodes.remove(native)

    def merge_edges(self) -> None:
        by_source = {}
        for start, finish, identifier, attrs in self.G.edges(keys=True, data=True):
            fanout = by_source.setdefault(attrs[FROM_SOCKET], [])
            if finish.rank > start.rank + 1:
                fanout.append((start, finish, identifier))

        for output, fanout in by_source.items():
            if len(fanout) <= 1:
                continue
            fanout.sort(key=lambda edge: edge[1].rank)
            common_frames = lowest_common_cluster(self.T, fanout)
            junctions = {}
            for start, finish, key in fanout:
                assert start.cluster is not None
                level = finish.rank - 1
                if level not in junctions:
                    owner = common_frames.get((start, finish), start.cluster)
                    junctions[level] = Node(cluster=owner, type=Kind.DUMMY, rank=level)
                junction = junctions[level]
                add_dummy_nodes_to_edge(self.G, (start, finish, key), (junction,))
                self.G.remove_edge(start, junction)

            spine = list(junctions.values())
            for previous, following in zip(spine, spine[1:]):
                add_dummy_edge(self.G, previous, following)
            outlet = spine[0]
            self.G.add_edge(start, outlet, from_socket=output, to_socket=Socket(outlet, 0, False))
            improve_cluster_assignment((start, finish), spine)
            self.T.add_edges_from((junction.cluster, junction) for junction in spine)

    def insert_dummy_nodes(self) -> None:
        # Measure the frame intervals before splitting links.
        for frame in self.S:
            contents = [entry for entry in nx.descendants(self.T, frame) if entry.type != Kind.CLUSTER]
            by_rank = lambda entry: entry.rank
            frame.left, frame.right = min(contents, key=by_rank), max(contents, key=by_rank)

        spanning = tuple(edge for edge in self.G.edges(keys=True) if edge[1].rank - edge[0].rank > 1)
        enclosing = lowest_common_cluster(self.T, spanning)
        for edge in spanning:
            output, input_node, _ = edge
            owner = enclosing.get((output, input_node), output.cluster)
            assert owner is not None
            chain_nodes = [Node(cluster=owner, type=Kind.DUMMY, rank=rank)
                           for rank in range(output.rank + 1, input_node.rank)]
            improve_cluster_assignment((output, input_node), chain_nodes)
            add_dummy_nodes_to_edge(self.G, edge, chain_nodes)

        new_vertices = self.G.nodes - self.T.nodes
        self.T.add_edges_from((entry.cluster, entry) for entry in new_vertices)

        for frame in self.S:
            if not frame.node:
                continue
            occupied = {entry.rank for entry in nx.descendants(self.T, frame) if entry.type != Kind.CLUSTER}
            for rank in sorted(set(range(min(occupied), max(occupied))) - occupied):
                placeholder = Node(cluster=frame, type=Kind.DUMMY, rank=rank)
                placeholder.is_fill_dummy = True
                self.G.add_node(placeholder)
                self.T.add_edge(frame, placeholder)

    def add_vertical_border_nodes(self) -> None:
        columns = self.G.graph["columns"]
        column_index = {id(column): index for index, column in enumerate(columns)}
        for frame in self.S:
            if not frame.node:
                continue
            members = {}
            for entry in nx.descendants(self.T, frame):
                if entry.type != Kind.CLUSTER:
                    members.setdefault(column_index[id(entry.col)], []).append(entry)

            upper_nodes = []
            lower_nodes = []
            for index in sorted(members):
                column = columns[index]
                span = [column.index(entry) for entry in members[index]]
                edges = ((max(span) + 1, 0, lower_nodes), (min(span), frame.label_height(), upper_nodes))
                for row, label_space, vertical in edges:
                    anchor = Node(cluster=frame, type=Kind.VERTICAL_BORDER)
                    anchor.height += label_space
                    anchor.col = column
                    column.insert(row, anchor)
                    self.T.add_edge(frame, anchor)
                    vertical.append(anchor)

            for vertical in (lower_nodes, upper_nodes):
                self.G.add_nodes_from(vertical)
            for vertical in (lower_nodes, upper_nodes):
                for previous, following in zip(vertical, vertical[1:]):
                    add_dummy_edge(self.G, previous, following)


# -------------------------------------------------------------------


def get_socket_y(socket: NodeSocket) -> float:
    b_socket = bNodeSocket.from_address(socket.as_pointer())
    ui_scale = bpy.context.preferences.system.ui_scale  # type: ignore
    return b_socket.runtime.contents.location[1] / ui_scale


@dataclass(frozen=True)
class Socket:
    owner: Node
    idx: int
    is_output: bool
    prescribed_offset_y: float | None = field(default=None, hash=False, compare=False)

    @property
    def bpy(self) -> NodeSocket | None:
        v = self.owner

        if not is_real(v):
            return None

        sockets = v.node.outputs if self.is_output else v.node.inputs
        return sockets[self.idx]

    @property
    def x(self) -> float:
        v = self.owner
        return v.x + v.width if self.is_output else v.x

    @cached_property
    def _offset_y(self) -> float:
        override = self.prescribed_offset_y
        if override is not None:
            return override
        owner = self.owner
        if not owner.is_reroute and is_real(owner):
            port = self.bpy
            assert port is not None
            return get_socket_y(port) - get_top(owner.node)
        return 0.0

    @property
    def y(self) -> float:
        return self.owner.y + self._offset_y


FROM_SOCKET = 'from_socket'
TO_SOCKET = 'to_socket'


def socket_graph(G: nx.MultiDiGraph[Node]) -> nx.DiGraph[Socket]:
    result = nx.DiGraph()
    owner_ports = {}
    for _, _, attrs in G.edges.data():
        start = attrs[FROM_SOCKET]
        end = attrs[TO_SOCKET]
        result.add_edge(start, end)
        for socket in (start, end):
            inputs, outputs = owner_ports.setdefault(socket.owner, ({}, {}))
            (outputs if socket.is_output else inputs)[socket] = None
    for inputs, outputs in owner_ports.values():
        for incoming in inputs:
            for outgoing in outputs:
                result.add_edge(incoming, outgoing)
    return result



# -------------------------------------------------------------------


def get_reroute_paths(
    CG: ClusterGraph,
    function: Callable | None = None,
    *,
    preserve_reroute_clusters: bool = True,
    aligned: bool = False,
    linear: bool = True,
) -> list[list[Node]]:
    graph = CG.G
    parents = {node: node for node in graph if node.is_reroute and (function is None or function(node))}
    ranks = dict.fromkeys(parents, 0)
    protected = set()
    if preserve_reroute_clusters:
        for cluster in CG.S:
            visible_members = (node for node in CG.T[cluster] if node.type != Kind.CLUSTER)
            if all(node.is_reroute for node in visible_members):
                protected.add(cluster)

    def representative(node):
        while parents[node] != node:
            parents[node] = parents[parents[node]]
            node = parents[node]
        return node

    for head in parents:
        if linear and graph.out_degree[head] > 1:
            continue
        tails = [tail for tail in graph.successors(head) if tail in parents]
        if len(tails) > 1:
            continue
        for tail in tails:
            if head.cluster != tail.cluster and (head.cluster in protected or tail.cluster in protected):
                continue
            if aligned and head.y != tail.y:
                continue
            left, right = representative(head), representative(tail)
            if left != right:
                if ranks[left] < ranks[right]:
                    left, right = right, left
                parents[right] = left
                ranks[left] += int(ranks[left] == ranks[right])

    # Resolve equal scores in original insertion order, then order nodes by the layout DAG.
    paths = {representative(node): [] for node in parents}
    scores = dict.fromkeys(paths, 0)
    for index, node in enumerate(nx.topological_sort(graph)):
        if node in parents:
            key = representative(node)
            paths[key].append(node)
            scores[key] += index
    return [paths[key] for key in sorted(paths, key=scores.__getitem__)]

