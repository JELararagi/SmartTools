from __future__ import annotations

from collections import deque
from collections.abc import Hashable, Iterable
from dataclasses import dataclass, field
from math import inf
from typing import TypeVar

import networkx as nx

from .. import config
from ..utils import get_top
from .graph import (
  FROM_SOCKET,
  TO_SOCKET,
  ClusterGraph,
  Edge,
  Kind,
  MultiEdge,
  Node,
  Socket,
  get_socket_y,
  is_real,
  node_name,
)


@dataclass(slots=True)
class NodeStack:
    rep_node: Node
    path: list[Node]
    stack_sockets_to_originals: dict[Socket, Socket] = field(default_factory=dict)


T = TypeVar('T', bound=Hashable)


def deterministic_hopcroft_karp_matching(G: nx.Graph[T], top_nodes: Iterable[T]) -> dict[T, T]:
    """Choose a maximum set of distinct left-to-right pairs in stable input order."""
    left = tuple(dict.fromkeys(top_nodes))
    mate = {}
    for start in left:
        parents = {start: None}
        explored = set()
        pending = deque([start])
        while pending:
            current = pending.popleft()
            for neighbor in G[current]:
                if neighbor in explored:
                    continue
                explored.add(neighbor)
                incumbent = mate.get(neighbor)
                if incumbent is None:
                    # The free right endpoint opens an alternating path back to start.
                    right = neighbor
                    while current is not None:
                        incoming = parents[current]
                        mate[current] = right
                        mate[right] = current
                        if incoming is None:
                            break
                        current, right = incoming
                    pending.clear()
                    break
                if incumbent not in parents:
                    parents[incumbent] = (current, neighbor)
                    pending.append(incumbent)
    return {vertex: mate[vertex] for vertex in (*left, *G) if vertex in mate}


def max_linear_branching(G: nx.MultiDiGraph[Node]) -> nx.MultiDiGraph[Node]:
    ordered = sorted(G, key=node_name)
    names = {node: node_name(node) for node in ordered}
    left = {node: (node, "out") for node in ordered}
    right = {node: (node, "in") for node in ordered}
    options = nx.DiGraph()
    options.add_nodes_from(left.values())
    options.add_nodes_from(right.values())
    arcs = sorted(G.edges(keys=False), key=lambda endpoints: "".join(names[node] for node in endpoints))
    options.add_edges_from((left[source], right[target]) for source, target in arcs)

    pairs = deterministic_hopcroft_karp_matching(options, left.values())
    result = nx.MultiDiGraph()
    result.add_nodes_from(ordered)
    result.add_edges_from((node, pairs[tag][0]) for node, tag in left.items() if tag in pairs)
    return result


_WEIGHT = 'weight'


# http://dx.doi.org/10.1016/S0020-0190(02)00491-X
def minimum_feedback_arc_set(G: nx.MultiDiGraph[Node]) -> set[MultiEdge]:
    G_ = G.copy()
    while not nx.is_directed_acyclic_graph(G_):
        C = tuple((G_.subgraph(next(nx.simple_cycles(G_))).edges))
        min_weight = min([G.edges[e][_WEIGHT] for e in C])
        for u, v, k in C:
            d = G.edges[u, v, k]
            d[_WEIGHT] -= min_weight
            if d[_WEIGHT] == 0:
                G_.remove_edge(u, v, k)

    for u, v, k in G.edges:
        if (u, v, k) in G_.edges:
            continue

        G_.add_edge(u, v, k)
        if not nx.is_directed_acyclic_graph(G_):
            G_.remove_edge(u, v, k)

    return set(G.edges - G_.edges)


def edges_preventing_acyclic_contraction(
    G: nx.MultiDiGraph[Node], K: nx.MultiDiGraph[Node],
) -> list[Edge]:
    trial = G.copy()
    reversed_edges = set(K.edges)
    snapshot = tuple(trial.edges(keys=True, data=True))
    for source, target, key, data in snapshot:
        edge = source, target, key
        if edge not in reversed_edges:
            data[_WEIGHT] = inf
            continue
        trial.remove_edge(*edge)
        attrs = dict(data, **{_WEIGHT: 1})
        trial.add_edge(target, source, key, **attrs)

    blocked = minimum_feedback_arc_set(trial)
    return [(end, start) for start, end, _ in blocked]


def relabel_sockets(
    edges: nx.classes.reportviews.OutMultiEdgeView[Node], v: Node, node_stack: NodeStack, y: float,
) -> None:
    assert is_real(v)
    local = set(node_stack.path)
    exposed = [(source == v, data) for source, target, data in edges(v, data=True)
               if source not in local or target not in local]
    if not exposed:
        return
    output = exposed[0][0]
    field = FROM_SOCKET if output else TO_SOCKET
    ports = node_stack.stack_sockets_to_originals
    start = max((port.idx for port in ports), default=-1) + 1
    ordered = sorted((data for _, data in exposed), key=lambda data: data[field].idx)
    for index, data in enumerate(ordered, start):
        old = data[field]
        offset = get_socket_y(old.bpy) - get_top(v.node) - y
        new = Socket(node_stack.rep_node, index, output, offset)
        ports[new], data[field] = old, new


def contracted_node_stacks(CG: ClusterGraph) -> list[NodeStack]:
    network, tree = CG.G, CG.T
    mask = [node for node in network if is_real(node) and node.node.hide
            and node.node.bl_idname in {"ShaderNodeMath", "ShaderNodeVectorMath"}]
    chains = nx.MultiDiGraph(network.subgraph(mask))
    disallowed = [(a, b, key) for a, b, key in chains.edges
                  if a.cluster != b.cluster or len(chains[a][b]) != 1]
    chains.remove_edges_from(disallowed)
    for component in nx.weakly_connected_components(chains):
        part = chains.subgraph(component)
        kept = max_linear_branching(part)
        chains.remove_edges_from(part.edges - kept.edges)
    for component in nx.weakly_connected_components(chains):
        local = chains.subgraph(component)
        chains.remove_edges_from(edges_preventing_acyclic_contraction(network, local))
    chains.remove_edges_from(edges_preventing_acyclic_contraction(network, chains))

    placement = {node: index for index, node in enumerate(nx.topological_sort(chains))}
    stacks = []
    for component in nx.weakly_connected_components(chains):
        if len(component) < 2:
            continue
        path = sorted(component, key=placement.__getitem__)
        frame = path[0].cluster
        rep = Node(type=Kind.STACK)
        stack = NodeStack(rep, path)
        gap = config.MARGIN.y * config.SETTINGS.stack_margin_y_fac
        offset = 0
        for member in path:
            for facing in (network.in_edges, network.out_edges):
                relabel_sockets(facing, member, stack, offset)
            offset += member.height + gap
        rep.cluster, rep.width, rep.height = frame, max(member.width for member in path), offset
        tree.add_edge(frame, rep)

        exterior = []
        for view in (network.in_edges, network.out_edges):
            for start, end, key, data in view(path, keys=True, data=True):
                if (start in component) != (end in component):
                    anchor = (rep, end) if start in component else (start, rep)
                    exterior.append(((start, end, key), anchor, data))
        for old, new, data in exterior:
            network.remove_edge(*old)
            network.add_edge(*new, **data)
        for store in (network, tree):
            store.remove_nodes_from(path)
        stacks.append(stack)

    assert nx.is_directed_acyclic_graph(network)
    return stacks


def expand_node_stack(CG: ClusterGraph, node_stack: NodeStack) -> None:
    network = CG.G
    rep, members = node_stack.rep_node, node_stack.path
    incoming, outgoing = {}, {}
    for start, end, key, edge in network.in_edges(rep, data=True, keys=True):
        incoming.setdefault(edge[TO_SOCKET], (start, end, key, edge))
    for start, end, key, edge in network.out_edges(rep, data=True, keys=True):
        outgoing.setdefault(edge[FROM_SOCKET], []).append((start, end, key, edge))

    for proxy, original in node_stack.stack_sockets_to_originals.items():
        if proxy.is_output:
            for start, end, key, data in outgoing.get(proxy, ()):
                network.remove_edge(start, end, key)
                network.add_edge(original.owner, end, **{FROM_SOCKET: original, TO_SOCKET: data[TO_SOCKET]})
        else:
            start, end, key, data = incoming[proxy]
            network.remove_edge(start, end, key)
            network.add_edge(start, original.owner, **{FROM_SOCKET: data[FROM_SOCKET], TO_SOCKET: original})

    network.add_nodes_from(members)
    index = rep.col.index(rep)
    rep.col[index:index] = members
    level = rep.y
    gap = config.MARGIN.y * config.SETTINGS.stack_margin_y_fac
    for member in members:
        CG.T.add_edge(rep.cluster, member)
        member.x = rep.x + (rep.width - member.width) / 2
        member.y = level
        level -= member.height + gap
    CG.remove_nodes_from([rep])
