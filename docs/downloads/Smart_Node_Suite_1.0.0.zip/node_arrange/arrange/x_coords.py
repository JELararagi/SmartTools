from __future__ import annotations

from collections import defaultdict
from collections.abc import Collection, Sequence
from itertools import chain

import networkx as nx
from mathutils.geometry import intersect_line_line_2d

from .. import config
from ..utils import frame_padding
from .graph import (
  FROM_SOCKET,
  TO_SOCKET,
  Cluster,
  Kind,
  MultiEdge,
  Node,
  Socket,
  add_dummy_nodes_to_edge,
  lowest_common_cluster,
)


def frame_padding_of_col(
    columns: Sequence[Collection[Node]], i: int, T: nx.DiGraph[Node | Cluster],
) -> float:
    if columns[i] == columns[-1]:
        return 0
    frame_sets = [{node.cluster for node in column} for column in columns[i:i + 2]]
    if frame_sets[0] == frame_sets[1]:
        return 0

    def lineage(frame):
        path = set()
        while (parents := T.pred[frame]):
            parent = next(iter(parents))
            path.add((parent, frame))
            frame = parent
        return path

    paths = [[lineage(frame) for frame in frames] for frames in frame_sets]
    depth = 0
    for left, right in (paths, paths[::-1]):
        shared = set().union(*right)
        depth += max((len(path - shared) for path in left), default=0)
    return depth * frame_padding()


def assign_x_coords(G: nx.DiGraph[Node], T: nx.DiGraph[Node | Cluster]) -> None:
    columns = G.graph["columns"]
    left = 0
    margin = config.MARGIN.x
    for index, column in enumerate(columns):
        width = max(node.width for node in column)
        for node in column:
            inset = 0 if node.is_reroute else (width - node.width) / 2
            node.x = left + inset

        # https://doi.org/10.7155/jgaa.00220 (p. 139)
        steep = sum(abs(edge[TO_SOCKET].y - edge[FROM_SOCKET].y) >= margin * 3
                    for _, _, edge in G.out_edges(column, data=True))
        advance = width + margin * (1 + min(steep / 4, 2))
        left += advance + frame_padding_of_col(columns, index, T)


_MIN_X_DIFF = 30
_MIN_Y_DIFF = 8


def is_unnecessary_bend_point(socket: Socket, other_socket: Socket) -> bool:
    owner = socket.owner
    if owner.is_reroute:
        return False
    tilt_up = other_socket.y > socket.y
    adjacent = owner.col.index(owner) + (-1 if tilt_up else 1)
    if adjacent >= len(owner.col):
        return True
    neighbor = owner.col[adjacent]
    if neighbor.is_reroute:
        return True

    half_x, half_y = config.MARGIN / 2
    boundary = neighbor.y - neighbor.height - half_y if tilt_up else neighbor.y + half_y
    frame = neighbor.cluster
    assert frame
    if frame != owner.cluster and frame.node:
        padding = frame_padding()
        half_x += padding
        boundary += -padding if tilt_up else padding + frame.label_height()
    plate = (neighbor.x - half_x, boundary), (neighbor.x + neighbor.width + half_x, boundary)
    start, end = (socket.x, socket.y), (other_socket.x, other_socket.y)
    return intersect_line_line_2d(*plate, start, end) is None


def add_bend_points(
    G: nx.MultiDiGraph[Node], v: Node, bend_points: defaultdict[MultiEdge, list[Node]],
) -> None:
    wide = max(v.col, key=lambda node: node.width)
    arrivals = G.in_edges(v, data=True, keys=True)
    departures = G.out_edges(v, data=True, keys=True)
    for source, target, key, edge in chain(departures, arrivals):
        output, input_port = edge[FROM_SOCKET], edge[TO_SOCKET]
        port, remote = (output, input_port) if source == v else (input_port, output)
        boundary = wide.x + wide.width if port.is_output else wide.x
        needs_bend = (abs(port.x - boundary) > _MIN_X_DIFF
                      and abs(remote.y - port.y) > _MIN_Y_DIFF)
        if needs_bend and not is_unnecessary_bend_point(port, remote):
            bend = Node(type=Kind.DUMMY)
            bend.x, bend.y = boundary, port.y
            bend_points[source, target, key].append(bend)


def node_overlaps_edge(
    v: Node, edge_line: tuple[tuple[float, float], tuple[float, float]],
) -> bool:
    return not v.is_reroute and any(
        intersect_line_line_2d(*edge_line, (v.x, y), (v.x + v.width, y)) is not None
        for y in (v.y, v.y - v.height)
    )


def route_edges(G: nx.MultiDiGraph[Node], T: nx.DiGraph[Node | Cluster]) -> None:
    routes = defaultdict(list)
    for column in G.graph["columns"]:
        for node in column:
            add_bend_points(G, node, routes)

    shared = {}
    for key, bends in routes.items():
        source = G.edges[key][FROM_SOCKET]
        for index, bend in enumerate(bends):
            signature = source, bend.x, bend.y
            bends[index] = shared.setdefault(signature, bend)
    for (port, _, y), bend in shared.items():
        owner = port.owner
        if owner.is_reroute and G.out_degree[owner] >= 2:
            for key in G.out_edges(owner, keys=True):
                if bend not in routes[key] and G.edges[key][TO_SOCKET].y == y:
                    routes[key].append(bend)

    for key, bends in tuple(routes.items()):
        bends.sort(key=lambda point: point.x)
        source = G.edges[key][FROM_SOCKET]
        for other in G.out_edges(key[0], keys=True):
            edge = G.edges[other]
            if other in routes or edge[FROM_SOCKET] != source:
                continue
            last, target = bends[-1], edge[TO_SOCKET]
            if target.x > last.x:
                line = (last.x, last.y), (target.x, target.y)
                if not any(node_overlaps_edge(node, line) for node in key[1].col):
                    routes[other] = bends

    ancestors = lowest_common_cluster(T, routes)
    for key, bends in routes.items():
        add_dummy_nodes_to_edge(G, key, bends)
        source, target, _ = key
        frame = ancestors.get((source, target), source.cluster)
        for bend in bends:
            bend.cluster = frame
            T.add_edge(frame, bend)
