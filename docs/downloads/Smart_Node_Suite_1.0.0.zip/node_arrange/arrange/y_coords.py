# http://dx.doi.org/10.1007/3-540-45848-4_3
# http://dx.doi.org/10.1007/978-3-319-27261-0_12
# https://arxiv.org/abs/2008.01252

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Collection, Iterable, Iterator
from itertools import pairwise
from math import inf
from statistics import fmean
from typing import Any

import networkx as nx

from .. import config
from .graph import FROM_SOCKET, TO_SOCKET, Cluster, Kind, Node


def marked_conflicts(
    G: nx.DiGraph[Node], *, should_ensure_alignment: Callable[[Node], Any],
) -> set[frozenset[Node]]:
    result = set()
    columns = G.graph["columns"]
    ranks = {node: index for column in columns for index, node in enumerate(column)}
    for prior, column in pairwise(columns):
        anchors = [(position, ranks[next(iter(G.pred[node]))])
                   for position, node in enumerate(column) if should_ensure_alignment(node)]
        anchored_rows = {position for position, _ in anchors}
        if column and len(column) - 1 not in anchored_rows:
            anchors.append((len(column) - 1, len(prior) - 1))
        start, lower = 0, 0
        for stop, upper in anchors:
            for index in range(start, stop + 1):
                if index in anchored_rows:
                    continue
                node = column[index]
                result.update(frozenset((pred, node)) for pred in G.pred[node]
                              if not lower <= ranks[pred] <= upper)
            start, lower = stop + 1, upper
    return result


def horizontal_alignment(
    G: nx.DiGraph[Node], marked_edges: Collection[frozenset[Node]], marked_nodes: Collection[Node],
) -> None:
    cols = G.graph["columns"]
    ranks = {node: row for column in cols for row, node in enumerate(column)}
    for column in cols:
        preceding_row = -1
        for node in column:
            if node.aligned != node:
                continue
            candidates = sorted(G.pred[node], key=ranks.__getitem__)
            count = len(candidates)
            for pred in candidates[(count - 1) // 2:count // 2 + 1] if count else ():
                row = ranks[pred]
                if row <= preceding_row or frozenset((pred, node)) in marked_edges:
                    continue
                if pred.cluster != node.cluster and (pred in marked_nodes or node in marked_nodes):
                    continue
                pred.aligned = node
                node.root = node.aligned = pred.root
                preceding_row = row
                break


def iter_block(start: Node) -> Iterator[Node]:
    yield start
    w = start
    while (w := w.aligned) != start:
        yield w


def should_use_inner_shift(v: Node, w: Node, is_right: bool) -> bool:
    if v.is_reroute or w.is_reroute:
        return True
    mode = config.SETTINGS.socket_alignment
    if mode in ("NONE", "FULL"):
        return mode == "FULL"
    if v.cluster != w.cluster or v.type == Kind.STACK or w.type == Kind.STACK:
        return True

    first, last = (v, w) if is_right else (w, v)
    change = first.height - last.height
    can_shift = change <= 0 or getattr(last.node, "hide", False)
    threshold = fmean((first.height, last.height)) / 2
    return can_shift and abs(change) > threshold


def inner_shift(G: nx.MultiDiGraph[Node], is_right: bool, is_up: bool) -> None:
    for start in dict.fromkeys(node.root for node in G):
        for left, right in pairwise(iter_block(start)):
            baseline = left.inner_shift
            if not should_use_inner_shift(left, right, is_right):
                right.inner_shift = baseline
                continue

            offsets = []
            for edge in G[left][right].values():
                original = edge[FROM_SOCKET]
                destination = edge[TO_SOCKET]
                outgoing, incoming = (original, destination) if original.owner == left else (destination, original)
                direction = -1 if is_up else 1
                offsets.append(baseline + direction * outgoing._offset_y - direction * incoming._offset_y)
            right.inner_shift = fmean(offsets)


def place_block(v: Node, is_up: bool) -> None:
    if v.y is not None:
        return

    def constraints(root):
        root.y = 0
        block = tuple(iter_block(root))
        lower_bound = None
        for member in block:
            index = member.col.index(member)
            if index == 0:
                continue
            neighbor = member.col[index - 1]
            dependency = neighbor.root
            yield dependency
            if root.sink == root:
                root.sink = dependency.sink
            if root.sink == dependency.sink:
                height = (neighbor if is_up else member).height
                bound = dependency.y + neighbor.inner_shift - member.inner_shift + (height + config.MARGIN.y)
                lower_bound = bound if lower_bound is None else max(lower_bound, bound)
                root.y = lower_bound

        for member in block:
            member.y, member.sink = root.y, root.sink

    pending = [constraints(v)]
    while pending:
        dependency = next(pending[-1], None)
        if dependency is None:
            pending.pop()
        elif dependency.y is None:
            pending.append(constraints(dependency))


def vertical_compaction(G: nx.DiGraph[Node], is_up: bool) -> None:
    for root in (node for node in G if node.root == node):
        place_block(root, is_up)

    columns = G.graph["columns"]
    boundaries = defaultdict(set)
    for column in columns:
        for bottom, top in pairwise(reversed(column)):
            if top.sink != bottom.sink:
                boundaries[tuple(bottom.sink.col)].add((top, bottom))
    margin = config.MARGIN.y
    for column in columns:
        leader = column[0].sink
        if leader.shift == inf:
            leader.shift = 0
        for top, bottom in boundaries.get(tuple(column), ()):
            height = (top if is_up else bottom).height
            gap = bottom.y + bottom.inner_shift - top.y - top.inner_shift - (height + margin)
            top.sink.shift = min(top.sink.shift, bottom.sink.shift + gap)

    for node in G:
        node.y += node.sink.shift + node.inner_shift


def get_merged_lines(lines: Iterable[tuple[float, float]]) -> list[tuple[float, float]]:
    events = sorted((coordinate, step) for start, end in lines
                    for coordinate, step in ((start, -1), (end, 1)))
    merged = []
    active = 0
    for coordinate, step in events:
        if active == 0:
            start = coordinate
        active -= step
        if active == 0:
            merged.append((start, coordinate))
    return merged


def has_large_gaps_in_frame(cluster: Cluster, T: nx.DiGraph[Cluster | Node], is_up: bool) -> bool:
    ranges = []
    for child in T[cluster]:
        if child.type == Kind.VERTICAL_BORDER:
            continue
        low = high = child
        if child.type == Kind.CLUSTER:
            caps = {node.root for node in T[child] if node.type == Kind.VERTICAL_BORDER}
            low, high = sorted(caps, key=lambda node: node.y)
        mark = (low.y, high.y + high.height) if is_up else (low.y - low.height, high.y)
        ranges.append(mark)

    edges = get_merged_lines(ranges)
    clearance = config.MARGIN.y
    return any(below[0] > above[1] + clearance for above, below in pairwise(edges))


def get_marked_nodes(
    G: nx.DiGraph[Node], T: nx.DiGraph[Node | Cluster], old_marked_nodes: set[Node], is_up: bool,
) -> set[Node]:
    marked = set()
    frames = T.nodes - G.nodes
    for top in T:
        if top.type != Kind.CLUSTER or top.nesting_level != 1:
            continue
        subtree = nx.descendants(T, top).intersection(frames)
        subtree.add(top)
        for frame in sorted(subtree, key=lambda item: item.nesting_level, reverse=True):
            contents = {node for node in T[frame] if node.type != Kind.CLUSTER}
            if not contents - old_marked_nodes or not has_large_gaps_in_frame(frame, T, is_up):
                continue
            if not contents.isdisjoint(old_marked_nodes):
                marked |= contents
                continue

            for start in {item.root for item in contents}:
                block = tuple(iter_block(start))
                stops = contents.intersection(block)
                if any(left in stops and right in stops and left.is_reroute and right.is_reroute
                       for left, right in pairwise(block)):
                    continue
                marked |= stops
    return marked


def balance(G: nx.DiGraph[Node], layouts: list[list[float]]) -> None:
    heights = tuple(node.height for node in G)

    def bottom(values):
        return min(level - height for level, height in zip(values, heights))

    bounds = [(bottom(values), max(values)) for values in layouts]
    reference = min(range(len(layouts)), key=lambda index: bounds[index][1] - bounds[index][0])
    offset = bounds[reference][0]
    origin = layouts[reference]
    origin[:] = [value - offset for value in origin]
    floor_level, ceiling = bottom(origin), max(origin)
    for index, values in enumerate(layouts):
        if values != origin:
            low, high = bounds[index]
            shift = ceiling - high if index % 2 else floor_level - low
            values[:] = [value + shift for value in values]


_ITER_LIMIT = 20
_DIRECTION_TO_IDX = {'RIGHT_DOWN': 0, 'RIGHT_UP': 1, 'LEFT_DOWN': 2, 'LEFT_UP': 3}


def bk_assign_y_coords(G: nx.MultiDiGraph[Node], T: nx.DiGraph[Node | Cluster]) -> None:
    columns = G.graph["columns"]
    for column in columns:
        column.reverse()

    def routed_segment(node):
        return node.is_reroute and any(source.is_reroute for source in G.pred[node])

    def boundary_segment(node):
        return node.type == Kind.VERTICAL_BORDER and G.pred[node]

    conflicts = set().union(*(marked_conflicts(G, should_ensure_alignment=criterion)
                              for criterion in (routed_segment, boundary_segment)))
    layouts = []
    for forward, view in ((False, nx.reverse_view(G)), (True, G)):
        columns.reverse()
        for upwards in (False, True):
            locked = set()
            for attempt in range(_ITER_LIMIT):
                horizontal_alignment(view, conflicts, locked)
                inner_shift(view, forward, upwards)
                vertical_compaction(view, upwards)
                additional = get_marked_nodes(view, T, locked, upwards)
                if not additional:
                    break
                locked |= additional
                for node in G:
                    node.bk_reset()

            sign = -1 if upwards else 1
            layouts.append([sign * node.y for node in G])
            for node in G:
                node.bk_reset()
            for column in columns:
                column.reverse()

    for column in columns:
        column.reverse()
    mode = config.SETTINGS.direction
    if mode == "BALANCED":
        balance(G, layouts)
        levels = (fmean(sorted(values)[1:3]) for values in zip(*layouts))
    else:
        levels = layouts[_DIRECTION_TO_IDX[mode]]
    for node, level in zip(G, levels):
        node.y = level
