# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Connect the Node Arrange tools and controls to the shared node sidebar."""
from importlib import import_module

from ..translation import loc_text

bl_info = {
    "name": "Node Arrange",
    "author": "JELararagi",
    "version": (1, 4, 18),
    "blender": (5, 1, 0),
    "location": "Smart Node > Layout / Arrange",
    "description": "Arrange or recenter nodes from the Smart Node sidebar",
    "category": "Node",
}

SSS_DISABLE_PROXY_PANELS = True
_owned = []
_sections = (
    ("Spacing", "間隔", (("margin", " ", " ", ""),)),
    ("Alignment", "配置", (("direction", "Nodes", "ノード", ""),
                             ("socket_alignment", "Sockets", "ソケット", ""))),
    ("Crossed Links", "交差リンク", (("iterations", "Iterations", "反復回数", ""),)),
    ("Reroutes", "リルート", (("add_reroutes", "Add Reroutes", "リルートを追加", ""),
                              ("keep_reroutes_outside_frames", "Place Outside Frames", "フレーム外へ配置", "add_reroutes"))),
    ("Collapsed Nodes", "折りたたみノード", (("stack_collapsed", "Stack Collapsed", "折りたたみノードを積層", ""),
        ("stack_margin_y_fac", "Spacing Y Factor", "Y 間隔係数", "stack_collapsed"))),
)


def register():
    if _owned:
        return
    try:
        for name in ("properties", "operators", "keymaps", "ui"):
            feature = import_module("." + name, __name__)
            if name == "ui":
                continue
            feature.register()
            _owned.append(feature)
    except Exception:
        unregister()
        raise


def unregister():
    while _owned:
        feature = _owned.pop()
        try:
            feature.unregister()
        except (AttributeError, RuntimeError, ValueError):
            continue


def _buttons(layout, settings, property_name, icon, selected, all_trees):
    layout.column(align=True).prop(settings, property_name, expand=True)
    op, name, japanese = selected if getattr(settings, property_name, "NODES") == "NODES" else all_trees
    layout.column(align=True).operator(op, text=loc_text(name, japanese), icon=icon)


def draw_smart_node_runtime_controls(layout, context):
    panel = layout.box()
    panel.label(text=loc_text("Node Arrange", "ノード整列"), icon="NODETREE")
    settings = getattr(getattr(context, "scene", None), "na_settings", None)
    if settings is None:
        panel.label(text=loc_text("Settings are not available yet.", "設定はまだ利用できません。"), icon="ERROR")
        return
    panel.use_property_split = True
    for name, japanese, props in _sections:
        group = panel.box()
        group.label(text=loc_text(name, japanese))
        fields = group.column()
        for attr, en, ja, dependency in props:
            widget = fields
            if dependency:
                widget = fields.column()
                widget.active = bool(getattr(settings, dependency, False))
            widget.prop(settings, attr, text=loc_text(en, ja))
    panel.use_property_split = False
    panel.separator(factor=0.3)
    _buttons(panel, settings, "arrange_mode", "NODETREE",
             ("node.arrange_selected_nodes", "Arrange Selected Nodes", "選択ノードを整列"),
             ("node.arrange_all_trees", "Arrange All Trees", "全ツリーを整列"))
    panel.separator(factor=0.5)
    shortcut = panel.box()
    shortcut.label(text=loc_text("Hotkey Setup", "ホットキー設定"), icon="EVENT_G")
    panel.use_property_split = True
    panel.prop(settings, "origin", text=loc_text("Origin", "基準"))
    panel.use_property_split = False
    _buttons(panel, settings, "recenter_mode", "ORIENTATION_VIEW",
             ("node.recenter_selected_nodes", "Recenter Selected Nodes", "選択ノードを再センター"),
             ("node.recenter_all_trees", "Recenter All Trees", "全ツリーを再センター"))
