# ============================================================================
# Node Arrange
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from __future__ import annotations

import importlib

from ..translation import loc_text as _lt

bl_info = {
    'name': 'Node Arrange',
    'author': 'JELararagi',
    'version': (1, 4, 18),
    'blender': (5, 1, 0),
    'location': 'Smart Node > Layout / Arrange',
    'description': 'Node arranging and recentering tools integrated into Smart Node Suite',
    'category': 'Node',
}

_SUBMODULE_CACHE: dict[str, object] = {}
_registered_modules: list[object] = []


def _load_submodules() -> dict[str, object]:
    # The graph-layout implementation itself remains lazy inside the Arrange
    # operator. Registration imports only the small class/property surfaces.
    for module_name in ('properties', 'operators', 'keymaps', 'ui'):
        if module_name not in _SUBMODULE_CACHE:
            _SUBMODULE_CACHE[module_name] = importlib.import_module(f'.{module_name}', __name__)
    return _SUBMODULE_CACHE


def register() -> None:
    if _registered_modules:
        return
    modules = _load_submodules()
    try:
        for module_name in ('properties', 'operators', 'keymaps'):
            module = modules[module_name]
            register_fn = getattr(module, 'register', None)
            if callable(register_fn):
                register_fn()
                _registered_modules.append(module)
        # Standalone panels stay defined for compatibility and surface auditing,
        # but Smart Node's single root panel draws the full body.
    except Exception:
        unregister()
        raise


def unregister() -> None:
    while _registered_modules:
        module = _registered_modules.pop()
        unregister_fn = getattr(module, 'unregister', None)
        if callable(unregister_fn):
            try:
                unregister_fn()
            except Exception:
                pass


SSS_DISABLE_PROXY_PANELS = True


def _smarttools_node_op(layout, op_id: str, text: str, icon: str = 'NONE'):
    return layout.operator(op_id, text=text, icon=icon)


def draw_smart_node_runtime_controls(layout, context):
    settings = getattr(getattr(context, 'scene', None), 'na_settings', None)
    box = layout.box()
    box.label(text=_lt('Node Arrange', 'ノード整列'), icon='NODETREE')
    if settings is None:
        box.label(text=_lt('Settings are not available yet.', '設定はまだ利用できません。'), icon='ERROR')
        return
    box.use_property_split = True
    spacing = box.box()
    spacing.label(text=_lt('Spacing', '間隔'))
    spacing.prop(settings, 'margin', text=' ')
    align_box = box.box()
    align_box.label(text=_lt('Alignment', '配置'))
    col = align_box.column()
    col.prop(settings, 'direction', text=_lt('Nodes', 'ノード'))
    col.prop(settings, 'socket_alignment', text=_lt('Sockets', 'ソケット'))
    crossed = box.box()
    crossed.label(text=_lt('Crossed Links', '交差リンク'))
    crossed.prop(settings, 'iterations', text=_lt('Iterations', '反復回数'))
    reroutes = box.box()
    reroutes.label(text=_lt('Reroutes', 'リルート'))
    col = reroutes.column()
    col.prop(settings, 'add_reroutes', text=_lt('Add Reroutes', 'リルートを追加'))
    sub = col.column()
    sub.active = bool(getattr(settings, 'add_reroutes', False))
    sub.prop(settings, 'keep_reroutes_outside_frames', text=_lt('Place Outside Frames', 'フレーム外へ配置'))
    collapsed = box.box()
    collapsed.label(text=_lt('Collapsed Nodes', '折りたたみノード'))
    col = collapsed.column()
    col.prop(settings, 'stack_collapsed', text=_lt('Stack Collapsed', '折りたたみノードを積層'))
    sub = col.column()
    sub.active = bool(getattr(settings, 'stack_collapsed', False))
    sub.prop(settings, 'stack_margin_y_fac', text=_lt('Spacing Y Factor', 'Y 間隔係数'))
    box.use_property_split = False
    box.separator(factor=0.3)
    column = box.column(align=True)
    column.prop(settings, 'arrange_mode', expand=True)
    column = box.column(align=True)
    if getattr(settings, 'arrange_mode', 'NODES') == 'NODES':
        _smarttools_node_op(column, 'node.arrange_selected_nodes', _lt('Arrange Selected Nodes', '選択ノードを整列'), 'NODETREE')
    else:
        _smarttools_node_op(column, 'node.arrange_all_trees', _lt('Arrange All Trees', '全ツリーを整列'), 'NODETREE')
    box.separator(factor=0.5)
    hotkey_box = box.box()
    hotkey_box.label(text=_lt('Hotkey Setup', 'ホットキー設定'), icon='EVENT_G')
    box.use_property_split = True
    box.prop(settings, 'origin', text=_lt('Origin', '基準'))
    box.use_property_split = False
    column = box.column(align=True)
    column.prop(settings, 'recenter_mode', expand=True)
    column = box.column(align=True)
    if getattr(settings, 'recenter_mode', 'NODES') == 'NODES':
        _smarttools_node_op(column, 'node.recenter_selected_nodes', _lt('Recenter Selected Nodes', '選択ノードを再センター'), 'ORIENTATION_VIEW')
    else:
        _smarttools_node_op(column, 'node.recenter_all_trees', _lt('Recenter All Trees', '全ツリーを再センター'), 'ORIENTATION_VIEW')
