from bpy.props import BoolProperty
from bpy.types import Operator

from ..i18n import tip
from ..utils.nodes import SNSBase, sns_check_selected


class SMART_NODE_SUITE_OT_labels_clear(SNSBase, Operator):
    bl_idname = 'smart_node_suite.clear_label'
    bl_label = 'Clear Label'
    bl_description = tip('Clear the custom labels of the selected nodes.',
                         '選択したノードのカスタムラベルを消去します。')
    bl_options = {'UNDO'}

    option: BoolProperty(
        name='Immediate Clear',
        description=tip('Clear labels without a confirmation dialog.',
                        '確認ダイアログを表示せずにラベルを消去します。'),
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return super().poll(context) and sns_check_selected(cls, context)

    def execute(self, context):
        for node in context.space_data.edit_tree.nodes:
            if node.select:
                node.label = ''
        return {'FINISHED'}

    def invoke(self, context, event):
        if not self.option:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)
