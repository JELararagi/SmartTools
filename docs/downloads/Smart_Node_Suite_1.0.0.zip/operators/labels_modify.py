"""Batch-edit the displayed labels of selected nodes.

Independently implemented by Codex for JELararagi, 2026.
SPDX-License-Identifier: GPL-3.0-or-later
"""

from bpy.props import StringProperty
from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.nodes import SNSBase, sns_check, sns_check_selected


class SMART_NODE_SUITE_OT_labels_modify(Operator, SNSBase):
    bl_idname = "smart_node_suite.modify_labels"
    bl_label = "Modify Labels"
    bl_description = _tip(
        "Edit the text displayed on selected nodes",
        "選択したノードの表示ラベルを編集します",
    )
    bl_options = {"UNDO"}

    prepend: StringProperty(
        name="Add to Beginning", default="",
        description=_tip("Enter the text to insert before each label.", "各ラベルの先頭に入れる文字列です。"),
    )
    append: StringProperty(
        name="Add to End", default="",
        description=_tip("Enter the text to place after each label.", "各ラベルの末尾に付ける文字列です。"),
    )
    replace_from: StringProperty(
        name="Text to Replace", default="",
        description=_tip("Find this exact text in the label, matching letter case.", "大文字と小文字を区別して、ラベル内でこの文字列を探します。"),
    )
    replace_to: StringProperty(
        name="Replace with", default="",
        description=_tip("Enter new text or leave it blank to remove the match.", "新しい文字列を入力します。空欄にすると見つかった文字を削除します。"),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        changes = []
        for node in context.space_data.edit_tree.nodes:
            if node.select:
                label = node.label.replace(self.replace_from, self.replace_to)
                revised = self.prepend + label + self.append
                if revised != node.label:
                    changes.append((node, node.label, revised))

        applied = []
        try:
            for node, original, revised in changes:
                node.label = revised
                applied.append((node, original))
        except (AttributeError, RuntimeError, TypeError) as error:
            for node, original in reversed(applied):
                node.label = original
            self.report({"WARNING"}, str(error))
            return {"CANCELLED"}
        return {"FINISHED"}
