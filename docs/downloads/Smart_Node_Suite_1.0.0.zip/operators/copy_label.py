# SPDX-License-Identifier: GPL-3.0-or-later
"""Copy labels from the active node or the first incoming connection."""

from bpy.props import EnumProperty
from bpy.types import Operator
from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


class SMART_NODE_SUITE_OT_copy_label(Operator, SNSBase):
    bl_idname = "smart_node_suite.copy_label"
    bl_label = "Copy Label"
    bl_options = {"UNDO"}
    bl_description = tip(
        "Copy text from the active node or an incoming connection to selected node labels.",
        "アクティブノードや入力接続から、選択したノードのラベルへ文字列をコピーします。",
    )

    option: EnumProperty(
        name="Option",
        description=tip("Choose the text source", "コピー元の文字列を選びます"),
        items=(
            ("FROM_ACTIVE", "From Active", "Use the active node label"),
            ("FROM_NODE", "From Node", "Use the connected node label"),
            ("FROM_SOCKET", "From Socket", "Use the connected socket name"),
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context, min=2)

    def execute(self, context):
        nodes, _ = get_nodes_links(context)
        active = nodes.active
        for target in (node for node in nodes if node.select):
            if self.option == "FROM_ACTIVE":
                if active is not None and target != active:
                    target.label = active.label
                continue
            source = next((port.links[0] for port in target.inputs if port.links), None)
            if source is not None:
                target.label = source.from_socket.name if self.option == "FROM_SOCKET" else source.from_node.label
        return {"FINISHED"}
