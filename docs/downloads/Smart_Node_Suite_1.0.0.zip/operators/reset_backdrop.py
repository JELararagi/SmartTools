# SPDX-License-Identifier: GPL-3.0-or-later
"""Return the compositor backdrop to its initial zoom and origin."""

from bpy.types import Operator
from ..utils.nodes import SNSBase, sns_check, sns_check_space_type


class SMART_NODE_SUITE_OT_reset_backdrop(Operator, SNSBase):
    bl_idname = "smart_node_suite.bg_reset"
    bl_label = "Reset Backdrop"
    bl_description = "Return the compositor backdrop to its initial zoom and origin"

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(cls, context, {"CompositorNodeTree"})

    def execute(self, context):
        editor = context.space_data
        editor.backdrop_offset = (0, 0)
        editor.backdrop_zoom = 1.0
        return {"FINISHED"}
