# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Export the currently available compositor Viewer image without changing it."""

import os
import tempfile

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper

from ..i18n import tip as _tip
from ..utils.nodes import (
    get_viewer_image,
    sns_check,
    sns_check_space_type,
    sns_check_viewer_node,
)


_IMAGE_EXTENSIONS = (
    ('.bmp', 'BMP', ''),
    ('.rgb', 'IRIS', ''),
    ('.png', 'PNG', ''),
    ('.jpg', 'JPEG', ''),
    ('.jp2', 'JPEG2000', ''),
    ('.tga', 'TARGA', ''),
    ('.cin', 'CINEON', ''),
    ('.dpx', 'DPX', ''),
    ('.exr', 'OPEN_EXR', ''),
    ('.hdr', 'HDR', ''),
    ('.tif', 'TIFF', ''),
    ('.webp', 'WEBP', ''),
)
_FORMAT_BY_SUFFIX = {suffix: fmt for suffix, fmt, _ in _IMAGE_EXTENSIONS}
_FORMAT_BY_SUFFIX.update({'.jpeg': 'JPEG', '.tiff': 'TIFF'})


class SMART_NODE_SUITE_OT_save_viewer_image(Operator, ExportHelper):
    bl_idname = 'smart_node_suite.save_viewer'
    bl_label = 'Save Viewer Image'
    filepath: StringProperty(
        name='File Path',
        subtype='FILE_PATH',
        description=_tip(
            'Function: destination path used when saving the current Viewer image. How to use: choose a folder and filename in the file browser before confirming the export.',
            '機能: 現在のビューアー画像を保存する出力先パスです。使い方: 書き出し確認前にファイルブラウザーでフォルダーとファイル名を選びます。',
        ),
    )
    filename_ext: EnumProperty(
        name='Format',
        description=_tip(
            'Function: chooses the image format used when saving the compositor Viewer output. How to use: choose PNG for general use, EXR/HDR for high dynamic range data, or another format required by your pipeline.',
            '機能: コンポジターのビューアー出力を保存する画像形式を選びます。使い方: 通常は PNG、高ダイナミックレンジデータは EXR/HDR、パイプラインで指定がある場合はその形式を選びます。',
        ),
        items=_IMAGE_EXTENSIONS,
        default='.png',
    )

    @classmethod
    def poll(cls, context):
        return (
            sns_check(cls, context)
            and sns_check_space_type(cls, context, {'CompositorNodeTree'})
            and sns_check_viewer_node(cls)
        )

    def execute(self, context):
        # Never modify an existing file until save_render has completed elsewhere.
        requested = self.filepath
        image = get_viewer_image()
        if not requested or not requested.strip() or image is None:
            self.report({'ERROR'}, _tip('Choose a file and make the Viewer image available.', '保存先を選び、ビューアー画像を用意してください。'))
            return {'CANCELLED'}
        if not image.has_data or len(image.size) < 2 or any(size <= 0 for size in image.size[:2]):
            self.report({'ERROR'}, _tip('The Viewer image has no image data.', 'ビューアー画像に画像データがありません。'))
            return {'CANCELLED'}

        requested = bpy.path.abspath(requested)
        suffix = os.path.splitext(requested)[1].lower()
        if not suffix:
            suffix = self.filename_ext
            requested += suffix
        file_format = _FORMAT_BY_SUFFIX.get(suffix)
        if file_format is None:
            self.report({'ERROR'}, _tip('Unsupported image filename extension.', '対応していない画像ファイルの拡張子です。'))
            return {'CANCELLED'}
        directory = os.path.dirname(os.path.abspath(requested))
        if not os.path.isdir(directory):
            self.report({'ERROR'}, _tip('The destination folder does not exist.', '保存先フォルダーが存在しません。'))
            return {'CANCELLED'}

        settings = context.scene.render.image_settings
        old_format = settings.file_format
        old_media_type = getattr(settings, 'media_type', None)
        temporary_path = None
        try:
            fd, temporary_path = tempfile.mkstemp(prefix='.smart_node_viewer_', suffix=suffix, dir=directory)
            os.close(fd)
            if old_media_type is not None:
                settings.media_type = 'IMAGE'
            settings.file_format = file_format
            image.save_render(filepath=temporary_path, scene=context.scene)
            if not os.path.isfile(temporary_path) or os.path.getsize(temporary_path) == 0:
                raise OSError('Blender did not produce a nonempty image file')
            os.replace(temporary_path, requested)
            temporary_path = None
        except Exception as exc:
            self.report({'ERROR'}, _tip('Could not write image: {}', '画像を書き込めませんでした: {}').format(exc))
            return {'CANCELLED'}
        finally:
            if old_media_type is not None:
                settings.media_type = old_media_type
            settings.file_format = old_format
            if temporary_path is not None:
                try:
                    os.unlink(temporary_path)
                except FileNotFoundError:
                    pass
        return {'FINISHED'}
