# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from bpy.app.translations import pgettext_rpt as rpt_
from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.node_transactions import copy_rna_properties, copy_socket_defaults
from ..utils.nodes import SNSBase, sns_check, sns_check_active, sns_check_node_type, sns_check_selected


_NODE_COPY_SKIP = {
    'rna_type', 'type', 'bl_idname', 'bl_label', 'name', 'location', 'dimensions',
    'inputs', 'outputs', 'internal_links', 'parent', 'select', 'id_data', 'interface',
    'is_active_output', 'location_absolute',
}


class SMART_NODE_SUITE_OT_copy_settings(Operator, SNSBase):
    bl_idname = 'smart_node_suite.copy_settings'
    bl_label = 'Copy Settings'
    bl_description = _tip(
        'Function: copies compatible editable settings and socket defaults from the active node to other selected nodes of the same Blender node type without replacing node identities or links. How to use: select targets first and the source last, then run once for one Undo step.',
        '機能: アクティブノードの互換編集設定とソケット初期値を、ノード本体やリンクを置換せず同じ Blender ノード型の選択ノードへコピーします。使い方: 対象を先に、コピー元を最後に選択して実行します。操作全体が 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            sns_check(cls, context)
            and sns_check_active(cls, context)
            and sns_check_selected(cls, context, min=2)
            and sns_check_node_type(cls, context, 'FRAME', invert=True)
        )

    def execute(self, context):
        source = context.active_node
        selected = tuple(context.selected_nodes)
        targets = [node for node in selected if node != source and node.bl_idname == source.bl_idname]
        invalid = [node.name for node in selected if node != source and node.bl_idname != source.bl_idname]
        if not targets:
            self.report({'ERROR'}, rpt_('Selected nodes are not of the same type as {}').format(source.name))
            return {'CANCELLED'}
        if invalid:
            self.report(
                {'INFO'},
                rpt_('Ignored {} (not of the same type as {})').format(', '.join(sorted(invalid)), source.name),
            )

        success_names = []
        for target in targets:
            try:
                copy_rna_properties(source, target, skip=_NODE_COPY_SKIP)
                copy_socket_defaults(source.inputs, target.inputs)
                copy_socket_defaults(source.outputs, target.outputs)
                success_names.append(target.name)
            except Exception as exc:
                self.report({'WARNING'}, _tip('Could not copy settings to {name}: {exc}', '{name} へ設定をコピーできませんでした。').format(name=target.name, exc=exc))

        if not success_names:
            return {'CANCELLED'}
        self.report(
            {'INFO'},
            rpt_('Successfully copied attributes from {} to {}').format(source.name, ', '.join(success_names)),
        )
        return {'FINISHED'}
