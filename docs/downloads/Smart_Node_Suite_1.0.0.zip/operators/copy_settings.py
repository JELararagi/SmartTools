# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Copy editable attributes between selected nodes without replacing the graph."""
from bpy.app.translations import pgettext_rpt
from bpy.types import Operator

from ..i18n import tip
from ..utils.node_transactions import copy_rna_properties, copy_socket_defaults
from ..utils.nodes import SNSBase, sns_check, sns_check_active, sns_check_node_type, sns_check_selected

_NODE_COPY_SKIP = {
    "rna_type", "bl_idname", "bl_label", "type", "id_data", "interface", "name",
    "location", "location_absolute", "dimensions", "parent", "select", "is_active_output",
    "internal_links", "inputs", "outputs",
}


class SMART_NODE_SUITE_OT_copy_settings(Operator, SNSBase):
    bl_idname = "smart_node_suite.copy_settings"
    bl_label = "Copy Settings"
    bl_description = tip(
        "Select matching target nodes, select the source last, then copy its editable settings in one undo step.",
        "対象の同じ型のノードを選び、最後にコピー元を選択します。編集できる設定を一度の操作でコピーします。",
    )
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return all(check(cls, context) for check in (sns_check, sns_check_active)) and (
            sns_check_selected(cls, context, min=2) and sns_check_node_type(cls, context, "FRAME", invert=True)
        )

    def execute(self, context):
        source = context.active_node
        others = [node for node in context.selected_nodes if node != source]
        matching = [node for node in others if node.bl_idname == source.bl_idname]
        if not matching:
            self.report({"ERROR"}, pgettext_rpt("Selected nodes are not of the same type as {}").format(source.name))
            return {"CANCELLED"}
        skipped = sorted(node.name for node in others if node.bl_idname != source.bl_idname)
        if skipped:
            self.report({"INFO"}, pgettext_rpt("Ignored {} (not of the same type as {})").format(
                ", ".join(skipped), source.name))
        copied = []
        for node in matching:
            try:
                copy_rna_properties(source, node, skip=_NODE_COPY_SKIP)
                for side in ("inputs", "outputs"):
                    copy_socket_defaults(getattr(source, side), getattr(node, side))
            except Exception as error:
                self.report({"WARNING"}, tip(
                    "Could not copy settings to {name}: {exc}", "{name} へ設定をコピーできませんでした。"
                ).format(name=node.name, exc=error))
                continue
            copied.append(node.name)
        if not copied:
            return {"CANCELLED"}
        self.report({"INFO"}, pgettext_rpt("Successfully copied attributes from {} to {}").format(
            source.name, ", ".join(copied)))
        return {"FINISHED"}
