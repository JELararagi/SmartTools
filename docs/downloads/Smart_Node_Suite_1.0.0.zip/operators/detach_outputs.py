# SPDX-License-Identifier: GPL-3.0-or-later
"""Disconnect downstream wires without moving the selected nodes."""

from bpy.types import Operator

from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


class SMART_NODE_SUITE_OT_detach_outputs(Operator, SNSBase):
    bl_idname = "smart_node_suite.detach_outputs"
    bl_label = "Detach Outputs"
    bl_description = tip("Disconnect outgoing wires from the selection without moving any nodes",
                         "ノードを移動せずに、選択ノードの出力リンクを切り離します")
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        _, wires = get_nodes_links(context)
        selected = set(context.selected_nodes)
        outgoing = [wire for wire in wires if wire.from_node in selected]
        if not outgoing:
            self.report({"INFO"}, tip("There are no outgoing links", "出力リンクがありません"))
            return {"CANCELLED"}

        removed = []
        try:
            for wire in outgoing:
                record = wire.from_socket, wire.to_socket, wire.is_muted
                wires.remove(wire)
                removed.append(record)
        except (RuntimeError, ReferenceError) as exc:
            try:
                for source, destination, muted in removed:
                    new_wire = wires.new(source, destination)
                    new_wire.is_muted = muted
            except (RuntimeError, ReferenceError) as restore_error:
                raise RuntimeError("Unable to restore outgoing links") from restore_error
            self.report({"ERROR"}, tip("Unable to disconnect the selected outputs",
                                      "選択ノードの出力リンクを切り離せませんでした") + f": {exc}")
            return {"CANCELLED"}
        return {"FINISHED"}
