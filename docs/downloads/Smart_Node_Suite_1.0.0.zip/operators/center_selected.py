# SPDX-License-Identifier: GPL-3.0-or-later
"""Move the bounds of the top-level selected nodes to the view center."""

from bpy.types import Operator
from ..utils.nodes import SNSBase, abs_node_location, sns_check, sns_check_selected


def bounds(node, ui_scale):
    origin = abs_node_location(node)
    if node.type == "REROUTE":
        width = height = 0
    else:
        width = node.width
        height = node.height if node.type == "FRAME" else node.dimensions.y / ui_scale
    return origin.x, origin.y - height, origin.x + width, origin.y


def view_center(context, scale):
    region = next((r for r in context.area.regions if r.type == "WINDOW"), None) if context.area else None
    if region is None:
        return 0.0, 0.0
    x, y = region.view2d.region_to_view(region.width / 2, region.height / 2)
    return x / scale, y / scale


class SMART_NODE_SUITE_OT_center_selected(Operator, SNSBase):
    bl_idname = "smart_node_suite.center_nodes"
    bl_label = "Center Nodes"
    bl_options = {"UNDO"}
    bl_description = "Center the selected nodes in the current view"

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        roots = [node for node in context.selected_nodes if not (node.parent and node.parent.select)]
        if not roots:
            return {"CANCELLED"}
        scale = context.preferences.system.ui_scale
        left, bottom, right, top = zip(*(bounds(node, scale) for node in roots))
        x, y = view_center(context, scale)
        dx = x - (min(left) + max(right)) / 2
        dy = y - (min(bottom) + max(top)) / 2
        for node in roots:
            node.location.x += dx
            node.location.y += dy
        return {"FINISHED"}
