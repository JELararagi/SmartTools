# SPDX-License-Identifier: GPL-3.0-or-later
"""Refresh image datablocks referenced by the active node tree."""

import bpy
from bpy.app.translations import pgettext_rpt
from bpy.types import Operator
from ..i18n import tip
from ..utils.nodes import force_update, sns_check, sns_check_space_type


IMAGE_NODES = {
    "CompositorNodeImage", "GeometryNodeInputImage", "ShaderNodeTexEnvironment",
    "ShaderNodeTexImage", "TextureNodeImage",
}
SOCKET_NODES = {"GeometryNodeGroup", "GeometryNodeImageInfo", "GeometryNodeImageTexture"}
SUPPORTED_TREES = {"ShaderNodeTree", "CompositorNodeTree", "TextureNodeTree", "GeometryNodeTree"}


def tree_images(tree, scene):
    for node in tree.nodes:
        kind = node.bl_idname
        if kind in IMAGE_NODES:
            yield node.image
        elif kind == "TextureNodeTexture" and node.texture and node.texture.type == "IMAGE":
            yield node.texture.image
        elif kind in SOCKET_NODES:
            for socket in node.inputs:
                if socket.bl_idname == "NodeSocketImage":
                    yield socket.default_value

    if tree.bl_idname != "GeometryNodeTree":
        return
    image_keys = [socket.identifier for socket in tree.interface.items_tree
                  if isinstance(socket, bpy.types.NodeTreeInterfaceSocketImage) and socket.in_out == "INPUT"]
    if image_keys:
        for obj in scene.objects:
            for modifier in obj.modifiers:
                if modifier.type == "NODES" and modifier.node_group == tree:
                    for key in image_keys:
                        yield modifier.get(key)


class SMART_NODE_SUITE_OT_reload_images(Operator):
    bl_idname = "smart_node_suite.reload_images"
    bl_label = "Reload Images"
    bl_description = tip(
        "Refresh the image files referenced by the current node graph",
        "現在のノードグラフが参照する画像ファイルを再読み込みします。",
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(cls, context, SUPPORTED_TREES)

    def execute(self, context):
        tree = context.space_data.edit_tree
        images = {image for image in tree_images(tree, context.scene) if isinstance(image, bpy.types.Image)}
        if not images:
            self.report({"WARNING"}, tip("No images found to reload in this node tree", "再読み込みする画像がありません。"))
            return {"CANCELLED"}
        for image in images:
            image.reload()
        force_update(context)
        tree.interface_update(context)
        self.report({"INFO"}, pgettext_rpt("Reloaded {:d} image(s)").format(len(images)))
        return {"FINISHED"}
