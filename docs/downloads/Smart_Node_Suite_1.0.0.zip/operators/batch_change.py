# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Apply or step through node modes for the current selection."""

from bpy.app.translations import contexts
from bpy.props import EnumProperty
from bpy.types import Operator

from ..i18n import tip
from ..utils.constants import blend_types, navs, operations
from ..utils.nodes import SNSBase, sns_check, sns_check_selected, sns_check_space_type

_TREES = {"ShaderNodeTree", "CompositorNodeTree", "TextureNodeTree", "GeometryNodeTree"}
_NEIGHBOR = {"NEXT": 1, "PREV": -1}
_BLEND_MODES = tuple(item[0] for item in blend_types)
_MATH_MODES = tuple(item[0] for item in operations)


def _requested(choice, current, supported):
    step = _NEIGHBOR.get(choice)
    if step is None:
        return choice
    if current not in supported:
        return current
    return supported[(supported.index(current) + step) % len(supported)]


class SMART_NODE_SUITE_OT_batch_change(Operator, SNSBase):
    bl_idname = "smart_node_suite.batch_change"
    bl_label = "Batch Change"
    bl_description = tip(
        "Change the blend mode of selected color Mix nodes and the operation of selected Math nodes.",
        "選択したカラーミックスノードのブレンド方法と、数式ノードの演算をまとめて変更します。",
    )
    bl_options = {"UNDO"}

    blend_type: EnumProperty(
        name="Blend Type", items=blend_types + navs, translation_context=contexts.color,
        description=tip("Set a blend mode or step to the next or previous one.",
                        "ブレンド方法を指定するか、次または前の方法に切り替えます。"),
    )
    operation: EnumProperty(
        name="Operation", items=operations + navs, translation_context=contexts.id_nodetree,
        description=tip("Set a math operation or step to the next or previous one.",
                        "演算を指定するか、次または前の演算に切り替えます。"),
    )

    @classmethod
    def poll(cls, context):
        return (sns_check(cls, context) and sns_check_space_type(cls, context, _TREES)
                and sns_check_selected(cls, context))

    def execute(self, context):
        for node in context.selected_nodes:
            if node.type == "MIX_RGB" or (node.bl_idname == "ShaderNodeMix" and node.data_type == "RGBA"):
                node.blend_type = _requested(self.blend_type, node.blend_type, _BLEND_MODES)
            elif node.type == "MATH" or node.bl_idname == "ShaderNodeMath":
                node.operation = _requested(self.operation, node.operation, _MATH_MODES)
        return {"FINISHED"}
