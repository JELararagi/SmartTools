# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import EnumProperty
from bpy.app.translations import contexts as i18n_contexts

from ..i18n import tip as _tip

from ..utils.constants import (
    blend_types,
    operations,
    navs,
)
from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    sns_check_space_type,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_batch_change(Operator, SNSBase):
    bl_idname = "smart_node_suite.batch_change"
    bl_label = "Batch Change"
    bl_description = _tip('Function: changes blend modes or math operations on multiple selected compatible nodes at once. How to use: select Mix or Math nodes, choose the desired operation from the Smart Node menu, and apply it to the compatible selection.', '機能: 選択した複数の互換ノードのブレンドモードや数式演算をまとめて変更します。使い方: ミックスまたは数式ノードを選択し、Smart Node メニューから目的の演算を選んで適用します。')
    bl_options = {'UNDO'}

    blend_type: EnumProperty(
        name="Blend Type",
        description=_tip('Function: changes the blend mode on selected Mix RGB or Mix nodes in batch. How to use: choose a specific mode, or use the navigation entries to step through available blend modes.', '機能: 選択した カラーミックス / ミックスノードのブレンドモードをまとめて変更します。使い方: 指定モードを選ぶか、移動項目で利用可能なブレンドモードを順送りします。'),
        items=blend_types + navs,
        translation_context=i18n_contexts.color,
    )
    operation: EnumProperty(
        name="Operation",
        description=_tip('Function: changes the math operation on selected Math nodes in batch. How to use: choose an operation such as Add or Multiply, or step through operations with the navigation entries.', '機能: 選択した 数式ノードの演算種類をまとめて変更します。使い方: 加算や乗算 などの演算を選ぶか、移動項目で演算種類を順送りします。'),
        translation_context=i18n_contexts.id_nodetree,
        items=operations + navs,
    )

    @classmethod
    def poll(cls, context):
        return (sns_check(cls, context)
                and sns_check_space_type(cls, context, {'ShaderNodeTree', 'CompositorNodeTree',
                                        'TextureNodeTree', 'GeometryNodeTree'})
                and sns_check_selected(cls, context))

    def execute(self, context):
        blend_type = self.blend_type
        operation = self.operation
        for node in context.selected_nodes:
            if node.type == 'MIX_RGB' or (node.bl_idname == 'ShaderNodeMix' and node.data_type == 'RGBA'):
                if blend_type not in [nav[0] for nav in navs]:
                    node.blend_type = blend_type
                # Step only from a listed mode; an unlisted one has no list position.
                elif any(node.blend_type in entry for entry in blend_types):
                    if blend_type == 'NEXT':
                        index = [i for i, entry in enumerate(blend_types) if node.blend_type in entry][0]
                        # index = blend_types.index(node.blend_type)
                        if index == len(blend_types) - 1:
                            node.blend_type = blend_types[0][0]
                        else:
                            node.blend_type = blend_types[index + 1][0]

                    if blend_type == 'PREV':
                        index = [i for i, entry in enumerate(blend_types) if node.blend_type in entry][0]
                        if index == 0:
                            node.blend_type = blend_types[len(blend_types) - 1][0]
                        else:
                            node.blend_type = blend_types[index - 1][0]

            if node.type == 'MATH' or node.bl_idname == 'ShaderNodeMath':
                if operation not in [nav[0] for nav in navs]:
                    node.operation = operation
                elif any(node.operation in entry for entry in operations):
                    if operation == 'NEXT':
                        index = [i for i, entry in enumerate(operations) if node.operation in entry][0]
                        # index = operations.index(node.operation)
                        if index == len(operations) - 1:
                            node.operation = operations[0][0]
                        else:
                            node.operation = operations[index + 1][0]

                    if operation == 'PREV':
                        index = [i for i, entry in enumerate(operations) if node.operation in entry][0]
                        # index = operations.index(node.operation)
                        if index == 0:
                            node.operation = operations[len(operations) - 1][0]
                        else:
                            node.operation = operations[index - 1][0]

        return {'FINISHED'}
