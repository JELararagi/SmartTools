# SPDX-License-Identifier: GPL-3.0-or-later
"""Extend a node selection to neighboring levels of its frame hierarchy."""

from bpy.props import EnumProperty
from bpy.types import Operator
from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


class SMART_NODE_SUITE_OT_select_hierarchy(Operator, SNSBase):
    bl_idname = "smart_node_suite.select_parent_child"
    bl_label = "Select Parent or Children"
    parent_desc = "Select frame containing the selected nodes"
    child_desc = "Select members of the selected frame"

    option: EnumProperty(
        name="Option",
        description=tip("Choose which frame level to include", "選択に含めるフレーム階層を選びます"),
        items=(
            ("PARENT", "Select Parent", parent_desc),
            ("CHILD", "Select Children", child_desc),
        ),
    )

    @classmethod
    def description(cls, _context, properties):
        return {"PARENT": cls.parent_desc, "CHILD": cls.child_desc}.get(properties.option)

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        nodes, _ = get_nodes_links(context)
        selected = {node for node in nodes if node.select}
        if self.option == "PARENT":
            neighbors = {node.parent for node in selected} - {None}
        else:
            neighbors = {node for node in nodes if node.parent in selected}
        for neighbor in neighbors:
            neighbor.select = True
        return {"FINISHED"}
