# SPDX-License-Identifier: GPL-3.0-or-later
"""Insert one labelled-by-position waypoint per eligible outgoing socket."""

from bpy.props import EnumProperty
from bpy.types import NodeSocketVirtual, Operator
from bpy_extras.node_utils import connect_sockets

from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


def _destination_edges(output):
    return tuple((link.to_socket, link.is_muted, link) for link in output.links)


def _link(source, destination):
    wire = connect_sockets(source, destination)
    if wire is None or not wire.is_valid:
        raise RuntimeError("Blender could not connect the selected socket")
    return wire


def _restore(wires, originals, created):
    for node in reversed(created):
        nodes = node.id_data.nodes
        nodes.remove(node)
    for source, targets in originals:
        for target, muted in targets:
            if not any(wire.to_socket == target for wire in source.links):
                wires.new(source, target).is_muted = muted


class SMART_NODE_SUITE_OT_add_reroutes(Operator, SNSBase):
    bl_idname = "smart_node_suite.add_reroutes"
    bl_label = "Add Reroutes"
    bl_description = tip("Insert reroutes at all, unconnected, or linked outputs of selected nodes",
                         "選択ノードの全出力・未接続出力・接続済み出力にリルートを追加します")
    bl_options = {"UNDO"}

    option: EnumProperty(
        name="Option",
        description=tip("Choose which output sockets to process", "対象とする出力ソケットを選びます"),
        items=(
            ("ALL", "To All", "Add to all outputs"),
            ("LOOSE", "To Loose", "Add only to loose outputs"),
            ("LINKED", "To Linked", "Add only to linked outputs"),
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        nodes, wires = get_nodes_links(context)
        selected = [node for node in nodes if node.select]
        saved_active = nodes.active
        created, originals = [], []
        try:
            for node in selected:
                x = node.location.x + node.width + 20.0
                y = node.location.y if node.type == "REROUTE" else node.location.y - 35.0
                node_reroutes = []
                for output in node.outputs:
                    if output.is_unavailable or isinstance(output, NodeSocketVirtual):
                        continue
                    attached = _destination_edges(output)
                    eligible = (self.option == "ALL" or
                                (bool(attached) == (self.option == "LINKED")))
                    if eligible:
                        reroute = nodes.new("NodeReroute")
                        created.append(reroute)
                        node_reroutes.append(reroute)
                        reroute.location = x, y
                        originals.append((output, [(target, muted) for target, muted, _ in attached]))
                        _link(output, reroute.inputs[0])
                        for target, muted, previous in attached:
                            if target.is_multi_input:
                                replacement = _link(reroute.outputs[0], target)
                                replacement.swap_multi_input_sort_id(previous)
                                wires.remove(previous)
                            else:
                                replacement = _link(reroute.outputs[0], target)
                            replacement.is_muted = muted
                    if eligible or not output.hide:
                        y -= 22.0
                if node.hide and node.type != "REROUTE":
                    correction = (node.location.y - y - 35.0) / 2.0 + 13.0
                    for reroute in node_reroutes:
                        reroute.location.y += correction
        except (RuntimeError, ValueError, TypeError) as exc:
            _restore(wires, originals, created)
            for node in nodes:
                node.select = node in selected
            nodes.active = saved_active
            self.report({"ERROR"}, tip("Unable to insert reroutes", "リルートを追加できませんでした") + f": {exc}")
            return {"CANCELLED"}
        if not created:
            return {"CANCELLED"}
        for node in selected:
            if node.type == "REROUTE":
                node.hide = False
        for node in nodes:
            node.select = node in created
        nodes.active = created[-1]
        return {"FINISHED"}
