# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Adjust the factor on selected mix nodes in the active node tree."""
from bpy.props import FloatProperty
from bpy.types import Operator

from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


class SMART_NODE_SUITE_OT_change_factor(Operator, SNSBase):
    bl_idname = "smart_node_suite.factor"
    bl_label = "Change Factor"
    bl_description = tip(
        "Set the selected mix factors to 0 or 1, or apply an increment.",
        "選択したミックスノードの係数を 0・1 に設定するか、現在値から増減します。",
    )
    bl_options = {"UNDO"}

    option: FloatProperty(
        name="Factor Change",
        description=tip("0 and 1 set the factor; other values add to it.",
                        "0 と 1 は固定値を設定し、それ以外は現在値に加算します。"),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        nodes, _ = get_nodes_links(context)
        change = self.option
        absolute = change == 0.0 or change == 1.0
        for node in nodes:
            if not node.select:
                continue
            if node.type not in ("MIX_RGB", "MIX_SHADER") and node.bl_idname != "ShaderNodeMix":
                continue
            factor = node.inputs[0]
            node.hide = False
            factor.default_value = change if absolute else factor.default_value + change
        return {"FINISHED"}
