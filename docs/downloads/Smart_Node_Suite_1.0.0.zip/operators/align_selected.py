# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Lay out nodes along their dominant axis, retaining the active node anchor."""

from bpy.props import IntProperty
from bpy.types import Operator

from ..i18n import tip
from ..utils.layout_grid import axis_advance, snap_aligned_nodes_to_major_grid
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_not_empty
from .node_layout_tools import _socket_aware_vertical_order


def _center(node, horizontal):
    if horizontal:
        return node.location.x + node.dimensions.x / 2.0
    return node.location.y - node.dimensions.y / 2.0


def _interval(items, horizontal):
    centers = [_center(node, horizontal) for node in items]
    return min(centers), max(centers)


class SMART_NODE_SUITE_OT_align_selected(Operator, SNSBase):
    """Align selected nodes in a grid pattern."""

    bl_idname = "smart_node_suite.align_nodes"
    bl_label = "Align Nodes"
    bl_options = {"UNDO"}

    margin: IntProperty(
        name="Margin", default=50,
        description=tip("Space between aligned nodes. Increase it to leave more room for links.",
                        "整列したノードの間隔です。リンクを見やすくするには余白を広げます。"),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        selected = [node for node in nodes if node.select and node.type != "FRAME"]
        active = nodes.active
        anchor = active.location.copy() if active in selected else None
        items = selected or list(nodes)
        left, right = _interval(items, True)
        bottom, top = _interval(items, False)
        mid_x, mid_y = (left + right) / 2, (bottom + top) / 2

        horizontal = (right - left) > (top - bottom)
        ordered = (sorted(items, key=lambda node: _center(node, True))
                   if horizontal else _socket_aware_vertical_order(items, links))
        position = 0.0
        for node in ordered:
            width, height = node.dimensions
            gap = self.margin / 2 if node.hide else self.margin
            if horizontal:
                node.location = position, mid_y + height / 2
                position += axis_advance(context, width, gap, "HORIZONTAL")
            else:
                collapsed_offset = (height - node.bl_height_min - 6) / 2 if node.hide else 0
                node.location = mid_x - width / 2, position - collapsed_offset
                position -= axis_advance(context, height, 0.3 * gap, "VERTICAL")

        if anchor is not None:
            translation = anchor - active.location
            for node in items:
                node.location += translation
        else:
            lower, upper = _interval(items, horizontal)
            shift = (mid_x if horizontal else mid_y) - (lower + upper) / 2
            for node in items:
                if horizontal:
                    node.location.x += shift
                else:
                    node.location.y += shift
        snap_aligned_nodes_to_major_grid(ordered, context)
        return {"FINISHED"}
