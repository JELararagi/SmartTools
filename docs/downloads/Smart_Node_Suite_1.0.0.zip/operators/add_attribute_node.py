# SPDX-License-Identifier: GPL-3.0-or-later
"""Create and select a shader Attribute node at the editor cursor."""

from bpy.props import StringProperty
from bpy.types import Operator
from ..i18n import tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_space_type


class SMART_NODE_SUITE_OT_add_attribute_node(Operator, SNSBase):
    bl_idname = "smart_node_suite.add_attr_node"
    bl_label = "Add Attribute"
    bl_options = {"UNDO"}
    bl_description = tip(
        "Create an Attribute node for a named shader input",
        "名前を指定してシェーダーの属性ノードを作成します。",
    )

    attr_name: StringProperty(
        name="Attribute Name",
        description=tip("Name of the attribute to read", "読み込む属性の名前です"),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(cls, context, {"ShaderNodeTree"})

    def execute(self, context):
        nodes, _ = get_nodes_links(context)
        active = nodes.active
        selection = [(node, node.select) for node in nodes]
        created = None
        try:
            created = nodes.new("ShaderNodeAttribute")
            created.attribute_name = self.attr_name
            cursor = getattr(context.space_data, "cursor_location", None)
            if cursor is not None:
                created.location = cursor
            for node, _selected in selection:
                node.select = False
            created.select = True
            nodes.active = created
        except (AttributeError, RuntimeError, TypeError, ValueError) as error:
            if created is not None:
                nodes.remove(created)
            for node, selected in selection:
                node.select = selected
            nodes.active = active
            self.report({"ERROR"}, tip("Could not add Attribute node", "属性ノードを追加できませんでした。") + f": {error}")
            return {"CANCELLED"}
        return {"FINISHED"}
