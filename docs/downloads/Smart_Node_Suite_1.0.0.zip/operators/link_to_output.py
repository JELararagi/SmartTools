# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Connect an active node to the existing active output, or create an output."""

from __future__ import annotations

from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.nodes import (
    sns_check,
    sns_check_active,
    sns_check_space_type,
    sns_check_visible_outputs,
)


_TREE_TYPES = {
    'ShaderNodeTree',
    'CompositorNodeTree',
    'TextureNodeTree',
    'GeometryNodeTree',
}
_OUTPUT_TYPES = {
    'CompositorNodeTree': 'NodeGroupOutput',
    'TextureNodeTree': 'TextureNodeOutput',
    'GeometryNodeTree': 'NodeGroupOutput',
}
_SHADER_OUTPUT_TYPES = {
    'OBJECT': 'ShaderNodeOutputMaterial',
    'WORLD': 'ShaderNodeOutputWorld',
    'LINESTYLE': 'ShaderNodeOutputLineStyle',
}


def _visible_output(socket):
    return bool(socket.enabled and not socket.hide and socket.type != 'CUSTOM')


def _target_type(space):
    if space.tree_type == 'ShaderNodeTree':
        return _SHADER_OUTPUT_TYPES.get(getattr(space, 'shader_type', ''))
    return _OUTPUT_TYPES.get(space.tree_type)


def _destination(tree, node_type):
    matches = [node for node in tree.nodes if node.bl_idname == node_type]
    if not matches:
        return None
    return next((node for node in matches if getattr(node, 'is_active_output', False)), matches[0])


def _candidate_inputs(source, destination, tree_type):
    """Select sockets by their public RNA type, without attempting invalid links."""
    inputs = [socket for socket in destination.inputs if socket.enabled and socket.type != 'CUSTOM']
    if tree_type == 'ShaderNodeTree':
        preferred = {'Volume': 'Volume', 'Displacement': 'Displacement'}.get(source.name, 'Surface')
        inputs.sort(key=lambda socket: (socket.name != preferred, socket.name != 'Surface'))
    for socket in inputs:
        if source.type != socket.type:
            continue
        if tree_type == 'GeometryNodeTree' and source.type != 'GEOMETRY':
            continue
        yield socket


def _matching_sockets(source_node, target_node, tree_type):
    for source in source_node.outputs:
        if not _visible_output(source):
            continue
        for target in _candidate_inputs(source, target_node, tree_type):
            return source, target
    return None


def _has_link(links, source_socket, target_socket):
    return any(link.from_socket == source_socket and link.to_socket == target_socket for link in links)


def _restore_input(links, target_socket, old_links):
    """Undo any partial replacement of a pre-existing single-input connection."""
    for link in tuple(links):
        if link.to_socket == target_socket and not any(link.from_socket == previous[0] for previous in old_links):
            links.remove(link)
    for old_source, old_target in old_links:
        if not _has_link(links, old_source, old_target):
            links.new(old_source, old_target)


class SMART_NODE_SUITE_OT_link_to_output(Operator):
    bl_idname = 'smart_node_suite.link_out'
    bl_label = 'Connect to Output'
    bl_description = _tip(
        'Function: connects the first compatible visible output of the active node to an existing active output node, or creates one when needed. How to use: select the source node and run once; validation occurs before creation so a failed operation leaves no orphan output node.',
        '機能: アクティブノードの最初の互換表示出力を、既存のアクティブ出力ノードへ接続し、必要な場合だけ出力ノードを作成します。使い方: ソースノードを選択して実行します。作成前に検証するため、失敗時に孤立出力ノードを残しません。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            sns_check(cls, context)
            and sns_check_space_type(cls, context, _TREE_TYPES)
            and sns_check_active(cls, context)
            and sns_check_visible_outputs(cls, context)
        )

    def execute(self, context):
        space = context.space_data
        tree = getattr(space, 'edit_tree', None)
        node_type = _target_type(space)
        if tree is None or node_type is None or space.tree_type not in _TREE_TYPES:
            self.report({'ERROR'}, _tip('No supported output node type is available.', '対応する出力ノードタイプがありません。'))
            return {'CANCELLED'}

        nodes, links = tree.nodes, tree.links
        source_node = nodes.active
        if source_node is None:
            self.report({'ERROR'}, _tip('Choose an active source node.', '接続元のアクティブノードを選択してください。'))
            return {'CANCELLED'}
        visible = [socket for socket in source_node.outputs if _visible_output(socket)]
        if not visible:
            self.report({'ERROR'}, _tip('The active node has no visible output sockets.', 'アクティブノードに表示可能な出力ソケットがありません。'))
            return {'CANCELLED'}
        if space.tree_type == 'GeometryNodeTree' and not any(socket.type == 'GEOMETRY' for socket in visible):
            self.report({'ERROR'}, _tip('The active node has no visible Geometry output.', 'アクティブノードに表示可能なジオメトリー出力がありません。'))
            return {'CANCELLED'}

        output_node = _destination(tree, node_type)
        if output_node == source_node:
            self.report({'ERROR'}, _tip('Choose a source node other than the output node.', '出力ノード以外の接続元ノードを選択してください。'))
            return {'CANCELLED'}

        created = None
        input_socket = None
        old_links = []
        prior_active = nodes.active
        try:
            if output_node is None:
                created = nodes.new(type=node_type)
                output_node = created
                output_node.location = (source_node.location.x + max(source_node.dimensions.x, 140.0) + 160.0, source_node.location.y)
            match = _matching_sockets(source_node, output_node, space.tree_type)
            if match is None:
                raise ValueError('The output node has no compatible input socket')
            source_socket, input_socket = match
            if _has_link(links, source_socket, input_socket):
                return {'FINISHED'}
            old_links = [(link.from_socket, link.to_socket) for link in tuple(links) if link.to_socket == input_socket]
            links.new(source_socket, input_socket)
            if not _has_link(links, source_socket, input_socket):
                raise RuntimeError('Blender did not create the requested link')
        except Exception as exc:
            try:
                if created is not None:
                    nodes.remove(created)
                elif input_socket is not None:
                    _restore_input(links, input_socket, old_links)
            except Exception as restore_error:
                self.report({'ERROR'}, _tip('Could not restore the prior links: {}', '以前のリンクを復元できませんでした: {}').format(restore_error))
            self.report({'ERROR'}, _tip('Could not connect to output: {}', '出力へ接続できませんでした: {}').format(exc))
            return {'CANCELLED'}
        finally:
            if nodes.active != prior_active:
                nodes.active = prior_active
        tree.update_tag()
        return {'FINISHED'}
