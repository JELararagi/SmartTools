# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared single-slot status-bar runtime for the SmartTools family.

Every SmartTools package carries an identical copy of this module.  Runtime
state lives in ``bpy.app.driver_namespace`` so independently imported
Extension packages cooperate through one status slot instead of appending
duplicate STATUSBAR header callbacks.
"""
from __future__ import annotations

from contextlib import contextmanager
import inspect
import threading
import time
from typing import Any, Dict, Iterator, Optional

try:
    import bpy
except Exception:  # pragma: no cover - allows static tooling outside Blender.
    bpy = None  # type: ignore[assignment]

_NAMESPACE_KEY = "JELARARAGI_SMARTTOOLS_STATUS_RUNTIME_V2"
_STATE_VERSION = 4
_DEFAULT_TRANSIENT_SECONDS = 1.8
_MIN_TIMER_INTERVAL = 0.04
_UI_RETRY_INTERVAL = 0.10
_RESOURCE_MONITOR_INTERVAL = 0.10
_DRAW_HEARTBEAT_INTERVAL = 0.25
_DRAW_STALE_SECONDS = 0.75
_SELF_MANAGED_OPERATOR_IDS = {
    # These operators maintain richer live status text themselves.  Wrapping a
    # lazy proxy with a generic completion message would overwrite the feature's
    # single specialised status entry on the first invocation.
    "mesh.smart_vert_slide",
    "mesh.smart_vert_slide_modal",
    "mesh.smart_vert_slide_constraint_monitor",
}


def _new_state() -> Dict[str, Any]:
    return {
        "version": _STATE_VERSION,
        "lock": threading.RLock(),
        "sequence": 0,
        "entries": {},
        "workspace_text": {},
        "last_text": None,
        "timer_fn": None,
        "timer_registered": False,
        "stats": {},
        "registration_depth": {},
        "resource_capture_depth": 0,
        "resource_context_stack": [],
        "resource_original_apis": {},
        "resource_native_apis": {},
        "resource_monitor_fn": None,
        "resource_monitor_registered": False,
        "resource_monitor_running": False,
        "timer_records": {},
        "draw_records": {},
        "draw_space_classes": None,
        "handler_wrappers": {},
        "rna_boundary_depth": 0,
        "rna_boundary_resume_after": 0.0,
        "rna_boundary_handlers_installed": False,
    }


def _state() -> Dict[str, Any]:
    if bpy is None:
        # Static/unit-test fallback.  This attribute is local to the module and
        # intentionally not shared outside Blender.
        state = globals().get("_FALLBACK_STATE")
        if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
            state = _new_state()
            globals()["_FALLBACK_STATE"] = state
        return state
    namespace = bpy.app.driver_namespace
    state = namespace.get(_NAMESPACE_KEY)
    if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
        state = _new_state()
        namespace[_NAMESPACE_KEY] = state
    return state


def _now() -> float:
    return time.monotonic()


def _on_main_thread() -> bool:
    try:
        return threading.current_thread() is threading.main_thread()
    except Exception:
        return True


def _workspace_candidates(context=None):
    if bpy is None or bool(getattr(bpy.app, "background", False)) or not _on_main_thread():
        return []
    result = []
    seen = set()

    def _add(workspace):
        if workspace is None:
            return
        try:
            pointer = int(workspace.as_pointer())
        except Exception:
            pointer = id(workspace)
        if pointer in seen:
            return
        seen.add(pointer)
        result.append((pointer, workspace))

    try:
        _add(getattr(context, "workspace", None))
    except Exception:
        pass
    try:
        wm = getattr(bpy.context, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            screen = getattr(window, "screen", None)
            _add(getattr(screen, "workspace", None))
    except Exception:
        pass
    try:
        _add(getattr(bpy.context, "workspace", None))
    except Exception:
        pass
    return result


def _remove_expired_locked(state: Dict[str, Any], now: Optional[float] = None) -> None:
    now = _now() if now is None else now
    entries = state["entries"]
    expired = [key for key, value in tuple(entries.items())
               if value.get("expires_at") is not None and float(value["expires_at"]) <= now]
    for key in expired:
        entries.pop(key, None)


def _top_entry_locked(state: Dict[str, Any]):
    _remove_expired_locked(state)
    entries = tuple(state["entries"].values())
    if not entries:
        return None
    # A currently executing task wins over a short completion notice, and a
    # short notice wins over a passive always-on service.  Within one priority,
    # the most recent update wins.  Only that one entry is ever published.
    return max(entries, key=lambda item: (int(item.get("priority", 0)), int(item.get("sequence", 0))))


def _publish_locked(state: Dict[str, Any], context=None) -> bool:
    entry = _top_entry_locked(state)
    text = str(entry.get("text", "")) if entry is not None else ""
    workspaces = _workspace_candidates(context)
    if not workspaces:
        state["last_text"] = text or None
        return False

    live_pointers = set()
    for pointer, workspace in workspaces:
        live_pointers.add(pointer)
        previous = state["workspace_text"].get(pointer)
        normalized = text or None
        if previous == normalized:
            continue
        try:
            workspace.status_text_set(text if text else None)
            state["workspace_text"][pointer] = normalized
        except (ReferenceError, RuntimeError):
            state["workspace_text"].pop(pointer, None)
        except Exception:
            pass
    for pointer in tuple(state["workspace_text"]):
        if pointer not in live_pointers:
            state["workspace_text"].pop(pointer, None)
    state["last_text"] = text or None
    return True


def _next_delay_locked(state: Dict[str, Any]) -> Optional[float]:
    # Background Blender has no status bar and no GUI event loop that should
    # keep a transient clear/retry timer alive.  Status instrumentation remains
    # logically active, but UI entries are discarded at insertion time.
    if bpy is not None and bool(getattr(bpy.app, "background", False)):
        return None
    now = _now()
    deadlines = [float(value["expires_at"]) for value in state["entries"].values()
                 if value.get("expires_at") is not None]
    if deadlines:
        return max(_MIN_TIMER_INTERVAL, min(deadlines) - now)
    # If an entry is active but no GUI workspace was ready yet, retry only while
    # that entry exists.  There is no idle polling when the status queue is empty.
    if state["entries"] and not _workspace_candidates(None):
        return _UI_RETRY_INTERVAL
    return None


def _shared_timer():
    state = _state()
    lock = state["lock"]
    with lock:
        _remove_expired_locked(state)
        _publish_locked(state)
        delay = _next_delay_locked(state)
        if delay is None:
            state["timer_registered"] = False
            return None
        return delay


def _ensure_timer_locked(state: Dict[str, Any]) -> None:
    if bpy is None or bool(getattr(bpy.app, "background", False)):
        state["timer_registered"] = False
        return
    delay = _next_delay_locked(state)
    if delay is None:
        return
    timer_fn = state.get("timer_fn")
    if not callable(timer_fn):
        timer_fn = _shared_timer
        state["timer_fn"] = timer_fn
    try:
        timers = bpy.app.timers
        if timers.is_registered(timer_fn):
            state["timer_registered"] = True
            return
        timers.register(timer_fn, first_interval=max(_MIN_TIMER_INTERVAL, float(delay)))
        state["timer_registered"] = True
    except Exception:
        state["timer_registered"] = False


def _upsert(key: str, owner: str, text: str, *, priority: int,
            duration: Optional[float], kind: str, context=None) -> str:
    state = _state()
    lock = state["lock"]
    if bpy is not None and bool(getattr(bpy.app, "background", False)):
        # There is no visible status bar in background mode.  Keeping transient
        # entries would only leave a timer waiting for a GUI event loop that does
        # not exist, so discard any stale copy and avoid scheduling work.
        with lock:
            state["entries"].pop(key, None)
            state["last_text"] = None
            state["timer_registered"] = False
        return key
    with lock:
        existing = state["entries"].get(key)
        if (existing is not None and duration is None
                and existing.get("kind") == kind
                and existing.get("text") == str(text or "")
                and int(existing.get("priority", 0)) == int(priority)):
            _publish_locked(state, context)
            return key
        state["sequence"] = int(state.get("sequence", 0)) + 1
        sequence = state["sequence"]
        state["entries"][key] = {
            "key": key,
            "owner": owner,
            "text": str(text or ""),
            "priority": int(priority),
            "sequence": sequence,
            "kind": kind,
            "expires_at": None if duration is None else _now() + max(0.0, float(duration)),
        }
        _publish_locked(state, context)
        _ensure_timer_locked(state)
    return key


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None) -> str:
    """Replace the transient status owned by *owner*.

    Repeated calls use the same key and therefore cannot grow horizontally or
    create duplicate status-bar callbacks.
    """
    key = f"transient:{owner}"
    return _upsert(key, owner, text, priority=20, duration=duration, kind="transient", context=context)


def set_service(owner: str, text: str, *, context=None) -> str:
    """Show one persistent status for an actually running background service."""
    key = f"service:{owner}"
    return _upsert(key, owner, text, priority=10, duration=None, kind="service", context=context)


def begin_task(owner: str, text: str, *, context=None) -> str:
    """Begin a nested foreground task and return its unique token."""
    state = _state()
    with state["lock"]:
        state["sequence"] = int(state.get("sequence", 0)) + 1
        sequence = state["sequence"]
    token = f"task:{owner}:{sequence}"
    return _upsert(token, owner, text, priority=30, duration=None, kind="task", context=context)


def update_task(token: str, text: str, *, context=None) -> bool:
    state = _state()
    lock = state["lock"]
    with lock:
        entry = state["entries"].get(token)
        if entry is None:
            return False
        state["sequence"] = int(state.get("sequence", 0)) + 1
        entry["sequence"] = state["sequence"]
        entry["text"] = str(text or "")
        _publish_locked(state, context)
    return True


def finish_task(token: str, final_text: Optional[str] = None,
                duration: float = 0.12, *, context=None) -> None:
    state = _state()
    lock = state["lock"]
    with lock:
        entry = state["entries"].pop(token, None)
        owner = str(entry.get("owner", token)) if entry else str(token)
        _publish_locked(state, context)
    if final_text:
        set_transient(owner, final_text, duration=duration, context=context)


def _cancel_timer_if_idle_locked(state: Dict[str, Any]) -> None:
    if bpy is None or state["entries"]:
        return
    timer_fn = state.get("timer_fn")
    if not callable(timer_fn):
        state["timer_registered"] = False
        return
    try:
        timers = bpy.app.timers
        if timers.is_registered(timer_fn):
            timers.unregister(timer_fn)
    except Exception:
        pass
    state["timer_registered"] = False


def clear(owner_or_token: str, *, context=None) -> None:
    """Clear an exact task token or every status entry owned by the identifier."""
    state = _state()
    lock = state["lock"]
    with lock:
        entries = state["entries"]
        entries.pop(owner_or_token, None)
        for key, entry in tuple(entries.items()):
            if entry.get("owner") == owner_or_token:
                entries.pop(key, None)
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)
        _ensure_timer_locked(state)


def clear_prefix(prefix: str, *, context=None) -> None:
    _cleanup_resource_records(prefix)
    state = _state()
    lock = state["lock"]
    with lock:
        for key, entry in tuple(state["entries"].items()):
            if str(entry.get("owner", "")).startswith(prefix) or str(key).startswith(prefix):
                state["entries"].pop(key, None)
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)
        _ensure_timer_locked(state)


def clear_all(*, context=None) -> None:
    _cleanup_resource_records("")
    state = _state()
    lock = state["lock"]
    with lock:
        state["entries"].clear()
        _publish_locked(state, context)
        _cancel_timer_if_idle_locked(state)


def snapshot() -> Dict[str, Any]:
    """Return a serialisable runtime snapshot for regression tests."""
    state = _state()
    with state["lock"]:
        _remove_expired_locked(state)
        top = _top_entry_locked(state)
        return {
            "version": state.get("version"),
            "entry_count": len(state["entries"]),
            "entries": [dict(item) for item in state["entries"].values()],
            "visible_text": None if top is None else top.get("text"),
            "timer_registered": bool(state.get("timer_registered", False)),
            "captured_timer_count": len(state.get("timer_records", {})),
            "captured_draw_count": len(state.get("draw_records", {})),
            "resource_capture_depth": int(state.get("resource_capture_depth", 0)),
            "resource_monitor_registered": bool(state.get("resource_monitor_registered", False)),
            "stats": {suite: dict(values) for suite, values in state.get("stats", {}).items()},
        }


@contextmanager
def task_scope(owner: str, text: str, *, context=None,
               completed_text: Optional[str] = None,
               error_prefix: Optional[str] = None) -> Iterator[str]:
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception as exc:
        finish_task(
            token,
            f"{error_prefix or 'Error'}: {exc}",
            duration=2.5,
            context=context,
        )
        raise
    else:
        finish_task(token, completed_text, context=context)


def _is_japanese(context=None) -> bool:
    if bpy is None:
        return False
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, "preferences", None), "view", None)
        return str(getattr(view, "language", "") or "").startswith("ja")
    except Exception:
        return False


def _translated_label(value: str) -> str:
    text = str(value or "")
    if bpy is None or not text:
        return text
    try:
        return str(bpy.app.translations.pgettext_iface(text) or text)
    except Exception:
        return text


def _humanize_identifier(value: str) -> str:
    """Return a stable, readable label for an RNA identifier."""
    text = str(value or "").strip()
    if not text:
        return "Option"
    if "." in text:
        text = text.rsplit(".", 1)[-1]
    text = text.replace("_", " ").replace("-", " ")
    words = [word for word in text.split() if word]
    if not words:
        return "Option"
    return " ".join(word.upper() if len(word) <= 3 and word.isalpha() else word.capitalize() for word in words)


def _default_operator_description(cls, suite_label: str) -> str:
    del cls, suite_label
    return ""


def _default_property_description(display_name: str, property_kind: str) -> str:
    del display_name, property_kind
    return ""


def _ensure_rna_class_tooltips(cls, suite_label: str):
    """Fill only missing operator/property descriptions before RNA registration.

    Existing authored descriptions are never changed.  The fallback guarantees
    that every exposed RNA control has a beginner-readable tooltip in the
    language active when the Extension is registered.
    """
    if not isinstance(cls, type):
        return cls
    try:
        operator_base = getattr(getattr(bpy, "types", None), "Operator", None) if bpy is not None else None
        if operator_base is not None and issubclass(cls, operator_base):
            if not str(getattr(cls, "bl_description", "") or "").strip():
                cls.bl_description = _default_operator_description(cls, suite_label)
    except Exception:
        pass

    try:
        annotations = dict(vars(cls).get("__annotations__", {}) or {})
    except Exception:
        annotations = {}
    for property_name, deferred in annotations.items():
        try:
            keywords = getattr(deferred, "keywords", None)
            if not isinstance(keywords, dict):
                continue
            if str(keywords.get("description", "") or "").strip():
                continue
            function = getattr(deferred, "function", None)
            kind = getattr(function, "__name__", "Property")
            display_name = str(keywords.get("name", "") or "").strip() or _humanize_identifier(property_name)
            keywords["description"] = _default_property_description(display_name, kind)
        except Exception:
            continue
    return cls


def _operator_status_text(suite_label: str, operator_label: str, phase: str, context=None) -> str:
    suite = _translated_label(suite_label)
    operator = _translated_label(operator_label)
    japanese = _is_japanese(context)
    if phase == "running":
        return f"{suite}: 「{operator}」を実行中…" if japanese else f"{suite}: Running “{operator}”…"
    if phase == "completed":
        return f"{suite}: 「{operator}」が完了しました" if japanese else f"{suite}: Completed “{operator}”"
    if phase == "cancelled":
        return f"{suite}: 「{operator}」を取消しました" if japanese else f"{suite}: Cancelled “{operator}”"
    return f"{suite}: 「{operator}」でエラーが発生しました" if japanese else f"{suite}: Error in “{operator}”"


def _result_has(result, value: str) -> bool:
    try:
        return value in result
    except Exception:
        return False


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    """Instrument one Python Operator class without changing its Undo contract.

    The wrapper keeps one task token for the complete invoke/execute/modal
    lifecycle.  An ``invoke`` that calls ``execute`` therefore does not create a
    second visible entry, and a modal event does not update the status string on
    every mouse move.
    """
    if bpy is None or not isinstance(cls, type):
        return cls
    try:
        operator_base = getattr(bpy.types, "Operator", None)
        if operator_base is None or not issubclass(cls, operator_base):
            return cls
    except Exception:
        return cls
    _ensure_rna_class_tooltips(cls, suite_label)
    # Do not return solely because the class was instrumented earlier.  Lazy
    # SmartTools replace methods in-place after the proxy RNA class is already
    # registered.  Each method is checked independently below, so newly applied
    # real methods are wrapped while existing wrappers remain untouched.

    try:
        if bool(getattr(cls, "_jelararagi_status_managed_v2", False)):
            return cls
    except Exception:
        pass

    bl_idname = str(getattr(cls, "bl_idname", "") or "").strip()
    if not bl_idname:
        return cls
    if bl_idname in _SELF_MANAGED_OPERATOR_IDS:
        try:
            cls._jelararagi_status_managed_v2 = True
        except Exception:
            pass
        return cls
    operator_label = str(getattr(cls, "bl_label", "") or bl_idname)
    owner = f"{suite_id}.operator.{bl_idname}"
    token_attr = "_jelararagi_status_task_token_v2"

    def _get_token(instance):
        # Operator instances are not reused for an unrelated invocation.  The
        # instance attribute is therefore sufficient and avoids taking the
        # shared runtime lock on every MOUSEMOVE modal event.
        try:
            return getattr(instance, token_attr, None) or None
        except Exception:
            return None

    def _ensure_token(instance, context):
        token = _get_token(instance)
        if token:
            return token
        token = begin_task(
            owner,
            _operator_status_text(suite_label, operator_label, "running", context),
            context=context,
        )
        try:
            setattr(instance, token_attr, token)
        except Exception:
            pass
        return token

    def _finish(instance, context, *, cancelled=False, error=False):
        token = _get_token(instance)
        if not token:
            return
        try:
            setattr(instance, token_attr, None)
        except Exception:
            pass
        phase = "error" if error else ("cancelled" if cancelled else "completed")
        finish_task(
            token,
            _operator_status_text(suite_label, operator_label, phase, context),
            duration=0.12 if not error else 2.5,
            context=context,
        )

    def _wrap(name: str):
        original = getattr(cls, name, None)
        if not callable(original):
            return
        try:
            if bool(getattr(original, "_jelararagi_status_wrapper_v2", False)):
                return
        except Exception:
            pass

        if name == "modal":
            def _make_modal(_original):
                def wrapped(self, context, event):
                    _ensure_token(self, context)
                    try:
                        event_type = str(getattr(event, "type", "") or "")
                        if event_type in _RESOURCE_TERMINAL_MODAL_EVENTS:
                            with capture_runtime_resources(suite_id, suite_label):
                                result = _original(self, context, event)
                        else:
                            result = _original(self, context, event)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if _result_has(result, "CANCELLED"):
                        _finish(self, context, cancelled=True)
                    elif _result_has(result, "FINISHED"):
                        _finish(self, context)
                    return result
                return wrapped
            wrapped = _make_modal(original)
        elif name == "cancel":
            def _make_cancel(_original):
                def wrapped(self, context):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            return _original(self, context)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    finally:
                        _finish(self, context, cancelled=True)
                return wrapped
            wrapped = _make_cancel(original)
        elif name == "invoke":
            def _make_invoke(_original):
                def wrapped(self, context, event):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            result = _original(self, context, event)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if not _result_has(result, "RUNNING_MODAL"):
                        _finish(self, context, cancelled=_result_has(result, "CANCELLED"))
                    return result
                return wrapped
            wrapped = _make_invoke(original)
        else:  # execute
            def _make_execute(_original):
                def wrapped(self, context):
                    _ensure_token(self, context)
                    try:
                        with capture_runtime_resources(suite_id, suite_label):
                            result = _original(self, context)
                    except Exception:
                        _finish(self, context, error=True)
                        raise
                    if not _result_has(result, "RUNNING_MODAL"):
                        _finish(self, context, cancelled=_result_has(result, "CANCELLED"))
                    return result
                return wrapped
            wrapped = _make_execute(original)

        try:
            wrapped.__name__ = getattr(original, "__name__", name)
            wrapped.__doc__ = getattr(original, "__doc__", None)
            wrapped._jelararagi_status_wrapper_v2 = True
            wrapped._jelararagi_status_original_v2 = original
            setattr(cls, name, wrapped)
        except Exception:
            pass

    # Wrap execute first.  If invoke calls self.execute(), both methods reuse the
    # same instance token and still appear as a single status entry.
    for method_name in ("execute", "invoke", "modal", "cancel"):
        _wrap(method_name)
    try:
        cls._jelararagi_status_instrumented_v2 = True
    except Exception:
        pass
    _increment_stat(suite_id, "operator_class")
    return cls


def _iter_operator_subclasses():
    if bpy is None:
        return
    base = getattr(bpy.types, "Operator", None)
    if base is None:
        return
    seen = set()
    stack = list(base.__subclasses__())
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        yield cls
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str) -> int:
    """Instrument every currently loaded Operator class owned by one package."""
    marker = str(package_marker or suite_id).lower()
    count = 0
    for cls in _iter_operator_subclasses() or ():
        try:
            module_name = str(getattr(cls, "__module__", "") or "").lower()
            if marker not in module_name:
                continue
            if not str(getattr(cls, "bl_idname", "") or "").strip():
                continue
            instrument_operator_class(cls, suite_id, suite_label)
            count += 1
        except Exception:
            continue
    return count


def _callback_display_name(callback) -> str:
    try:
        return str(getattr(callback, "__name__", "") or getattr(callback, "__qualname__", "") or "Callback")
    except Exception:
        return "Callback"


def _suite_registration_active(suite_id: str) -> bool:
    try:
        state = _state()
        with state["lock"]:
            return int(state.setdefault("registration_depth", {}).get(suite_id, 0)) > 0
    except Exception:
        return False


_RESOURCE_TERMINAL_MODAL_EVENTS = frozenset({
    "TIMER", "LEFTMOUSE", "RIGHTMOUSE", "ESC", "RET", "NUMPAD_ENTER", "SPACE",
})


def _active_resource_context(state=None):
    state = state or _state()
    try:
        stack = state.setdefault("resource_context_stack", [])
        return stack[-1] if stack else None
    except Exception:
        return None


def _is_internal_status_timer(callback) -> bool:
    try:
        name = str(getattr(callback, "__name__", "") or "")
        globals_dict = getattr(callback, "__globals__", {})
        return (
            name in {"_shared_timer", "_resource_monitor_timer"}
            and isinstance(globals_dict, dict)
            and globals_dict.get("_NAMESPACE_KEY") == _NAMESPACE_KEY
        )
    except Exception:
        return False


def _resource_status_text(suite_label: str, callback, kind_en: str, kind_ja: str, *, active=False):
    label = _translated_label(_callback_display_name(callback))
    suite = _translated_label(suite_label)
    if _is_japanese(None):
        suffix = "が動作中" if active else "を実行中…"
        return f"{suite}: {kind_ja}「{label}」{suffix}"
    suffix = " active" if active else "…"
    return f"{suite}: {'Active ' if active else 'Running '}{kind_en} “{label}”{suffix}"


def _timer_record_for(callback, state=None, suite_id=None):
    state = state or _state()
    for record in tuple(state.setdefault("timer_records", {}).values()):
        if suite_id and record.get("suite_id") != suite_id:
            continue
        if record.get("original") is callback:
            return record
    return None


def _native_timer_apis(state=None):
    state = state or _state()
    native = state.setdefault("resource_native_apis", {})
    if bpy is not None and not native:
        try:
            native.update({
                "timer_register": bpy.app.timers.register,
                "timer_unregister": bpy.app.timers.unregister,
                "timer_is_registered": bpy.app.timers.is_registered,
            })
        except Exception:
            pass
    return native


def _cancel_resource_monitor_if_idle(state=None):
    state = state or _state()
    with state["lock"]:
        if state.setdefault("timer_records", {}) or state.setdefault("draw_records", {}):
            return
        monitor_fn = state.get("resource_monitor_fn")
        running = bool(state.get("resource_monitor_running", False))
        state["resource_monitor_registered"] = False
    if not callable(monitor_fn) or running or bpy is None:
        return
    native = _native_timer_apis(state)
    is_registered = native.get("timer_is_registered")
    unregister = native.get("timer_unregister")
    try:
        if callable(is_registered) and callable(unregister) and is_registered(monitor_fn):
            unregister(monitor_fn)
    except Exception:
        pass


def _drop_timer_record(record, *, clear_status=True):
    if not record:
        return
    state = _state()
    with state["lock"]:
        for key, value in tuple(state.setdefault("timer_records", {}).items()):
            if value is record:
                state["timer_records"].pop(key, None)
    if clear_status:
        clear(str(record.get("owner", "")))
    _cancel_resource_monitor_if_idle(state)
    _remove_global_draw_boundary_handlers_if_unused()


def _resource_monitor_timer():
    """Retire status records when native timers or draw callbacks stop.

    Add-on timer callbacks remain registered under their exact original identity.
    Draw services use a throttled heartbeat from the callback itself, so a
    handler removed through the native API outside a capture scope disappears
    from the status bar without a permanent draw-API monkey patch.
    """
    state = _state()
    with state["lock"]:
        state["resource_monitor_running"] = True
        timer_records = tuple(state.setdefault("timer_records", {}).values())
        draw_records = tuple(state.setdefault("draw_records", {}).values())
    try:
        for record in timer_records:
            callback = record.get("original")
            is_registered = record.get("native_is_registered")
            alive = False
            try:
                alive = bool(callable(callback) and callable(is_registered) and is_registered(callback))
            except Exception:
                alive = False
            if not alive:
                _drop_timer_record(record)

        now = _now()
        for record in draw_records:
            try:
                last_seen = float(record.get("last_seen", 0.0) or 0.0)
            except Exception:
                last_seen = 0.0
            if now - last_seen > float(record.get("stale_after", _DRAW_STALE_SECONDS)):
                _drop_draw_record(record)

        with state["lock"]:
            remaining = bool(
                state.setdefault("timer_records", {})
                or state.setdefault("draw_records", {})
            )
            state["resource_monitor_registered"] = remaining
        return _RESOURCE_MONITOR_INTERVAL if remaining else None
    finally:
        with state["lock"]:
            state["resource_monitor_running"] = False


def _ensure_resource_monitor(state=None, *, native_register=None, native_is_registered=None):
    return


def _captured_timer_register(function, *args, **kwargs):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_register = originals.get("timer_register")
    original_unregister = originals.get("timer_unregister")
    original_is_registered = originals.get("timer_is_registered")
    if not callable(original_register):
        return bpy.app.timers.register(function, *args, **kwargs)
    context = _active_resource_context(state)
    if not context or _is_internal_status_timer(function):
        return original_register(function, *args, **kwargs)

    # Register the exact original callback.  Replacing it with a wrapper breaks
    # later native ``unregister(original)`` calls after this capture ends.
    result = original_register(function, *args, **kwargs)
    suite_id, suite_label = context["suite_id"], context["suite_label"]
    record = _timer_record_for(function, state, suite_id)
    if record is None:
        owner = f"{suite_id}.timer.{id(function)}"
        record = {
            "suite_id": suite_id,
            "suite_label": suite_label,
            "original": function,
            "owner": owner,
            "native_unregister": original_unregister,
            "native_is_registered": original_is_registered,
        }
        with state["lock"]:
            state.setdefault("timer_records", {})[f"{suite_id}:{id(function)}"] = record
        _increment_stat(suite_id, "timer_callback")
    set_service(
        str(record.get("owner", "")),
        _resource_status_text(suite_label, function, "timer", "タイマー", active=True),
    )
    _ensure_resource_monitor(
        state,
        native_register=original_register,
        native_is_registered=original_is_registered,
    )
    return result


def _captured_timer_unregister(function):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_unregister = originals.get("timer_unregister")
    if not callable(original_unregister):
        return bpy.app.timers.unregister(function)
    record = _timer_record_for(function, state)
    try:
        return original_unregister(function)
    finally:
        if record:
            _drop_timer_record(record)


def _captured_timer_is_registered(function):
    state = _state()
    originals = state.setdefault("resource_original_apis", {})
    original_is_registered = originals.get("timer_is_registered")
    if not callable(original_is_registered):
        return bpy.app.timers.is_registered(function)
    return original_is_registered(function)


def _draw_boundary_handler_lists():
    if bpy is None:
        return ()
    handlers = bpy.app.handlers
    result = []
    for name, phase in (
        ("load_pre", "begin"), ("load_post", "end"),
        # Autosave and explicit saves can serialize/replace evaluated owners while
        # a region redraw is pending.  Treat save boundaries exactly like file-load
        # and undo boundaries so no SmartTools draw callback can enter RNA geometry
        # access during Blender's native save pipeline.
        ("save_pre", "begin"), ("save_post", "end"),
        ("undo_pre", "begin"), ("undo_post", "end"),
        ("redo_pre", "begin"), ("redo_post", "end"),
    ):
        handler_list = getattr(handlers, name, None)
        if handler_list is not None:
            result.append((handler_list, phase))
    return tuple(result)


def _global_draw_boundary_begin(*_args):
    state = _state()
    with state["lock"]:
        state["rna_boundary_depth"] = int(state.get("rna_boundary_depth", 0)) + 1
        state["rna_boundary_resume_after"] = float("inf")


def _global_draw_boundary_end(*_args):
    state = _state()
    with state["lock"]:
        depth = max(0, int(state.get("rna_boundary_depth", 0)) - 1)
        state["rna_boundary_depth"] = depth
        if depth == 0:
            # A draw may be requested from the same native file/undo callback.
            # Wait for a later UI event before any SmartTools draw callback runs.
            state["rna_boundary_resume_after"] = _now() + 0.20


for _callback, _phase in (
    (_global_draw_boundary_begin, "begin"),
    (_global_draw_boundary_end, "end"),
):
    try:
        _callback._jelararagi_global_draw_boundary_v1 = True
        _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
        _callback = bpy.app.handlers.persistent(_callback)
    except Exception:
        try:
            _callback._bpy_persistent = None
            _callback._jelararagi_global_draw_boundary_v1 = True
            _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
        except Exception:
            pass
# Rebind after applying persistent; assignment in the loop is local only.
try:
    _global_draw_boundary_begin = bpy.app.handlers.persistent(_global_draw_boundary_begin)
except Exception:
    pass
try:
    _global_draw_boundary_end = bpy.app.handlers.persistent(_global_draw_boundary_end)
except Exception:
    pass
for _callback, _phase in (
    (_global_draw_boundary_begin, "begin"),
    (_global_draw_boundary_end, "end"),
):
    try:
        _callback._jelararagi_global_draw_boundary_v1 = True
        _callback._jelararagi_global_draw_boundary_phase_v1 = _phase
    except Exception:
        pass
try:
    del _callback, _phase
except Exception:
    pass


def _ensure_global_draw_boundary_handlers():
    if bpy is None:
        return
    state = _state()
    for handler_list, phase in _draw_boundary_handler_lists():
        desired = _global_draw_boundary_begin if phase == "begin" else _global_draw_boundary_end
        try:
            for callback in tuple(handler_list):
                if not bool(getattr(callback, "_jelararagi_global_draw_boundary_v1", False)):
                    continue
                if callback is not desired:
                    handler_list.remove(callback)
            if desired not in handler_list:
                handler_list.append(desired)
        except Exception:
            continue
    state["rna_boundary_handlers_installed"] = True


def _remove_global_draw_boundary_handlers_if_unused():
    if bpy is None:
        return
    state = _state()
    with state["lock"]:
        if state.setdefault("draw_records", {}):
            return
    for handler_list, _phase in _draw_boundary_handler_lists():
        try:
            for callback in tuple(handler_list):
                if bool(getattr(callback, "_jelararagi_global_draw_boundary_v1", False)):
                    handler_list.remove(callback)
        except Exception:
            continue
    with state["lock"]:
        state["rna_boundary_handlers_installed"] = False
        state["rna_boundary_depth"] = 0
        state["rna_boundary_resume_after"] = 0.0


def _draw_callback_execution_safe(record=None):
    if bpy is None or bool(getattr(bpy.app, "background", False)) or not _on_main_thread():
        return False
    state = _state()
    with state["lock"]:
        if int(state.get("rna_boundary_depth", 0)) > 0:
            return False
        if _now() < float(state.get("rna_boundary_resume_after", 0.0) or 0.0):
            return False
    if record is not None and _now() < float(record.get("not_before", 0.0) or 0.0):
        return False
    try:
        ctx = bpy.context
        wm = getattr(ctx, "window_manager", None)
        if wm is None or bool(getattr(wm, "is_interface_locked", False)):
            return False
        return bool(getattr(ctx, "window", None) and getattr(ctx, "screen", None)
                    and getattr(ctx, "area", None) and getattr(ctx, "region", None))
    except Exception:
        return False

def _discover_draw_space_classes(state):
    cached = state.get("draw_space_classes")
    if isinstance(cached, tuple):
        return cached
    classes = []
    if bpy is not None:
        for name in dir(bpy.types):
            if not name.startswith("Space") or name == "Space":
                continue
            try:
                cls = getattr(bpy.types, name)
                if callable(getattr(cls, "draw_handler_add", None)) and callable(getattr(cls, "draw_handler_remove", None)):
                    classes.append((name, cls))
            except Exception:
                continue
    result = tuple(classes)
    state["draw_space_classes"] = result
    return result


def _drop_draw_record(record, *, clear_status=True):
    if not record:
        return
    state = _state()
    handle = record.get("handle")
    with state["lock"]:
        if handle is not None:
            state.setdefault("draw_records", {}).pop(id(handle), None)
        else:
            for key, value in tuple(state.setdefault("draw_records", {}).items()):
                if value is record:
                    state["draw_records"].pop(key, None)
    if clear_status:
        clear(str(record.get("owner", "")))
    _cancel_resource_monitor_if_idle(state)


def _refresh_draw_record(record):
    state = _state()
    now = _now()
    record["last_seen"] = now
    handle = record.get("handle")
    if handle is not None:
        with state["lock"]:
            state.setdefault("draw_records", {})[id(handle)] = record
    last_publish = float(record.get("last_publish", 0.0) or 0.0)
    if now - last_publish >= _DRAW_HEARTBEAT_INTERVAL:
        record["last_publish"] = now
        set_service(str(record.get("owner", "")), str(record.get("status_text", "")))
    _ensure_resource_monitor(state)


def _make_draw_callback_wrapper(record):
    original = record.get("callback")

    def wrapped(*args, **kwargs):
        if not _draw_callback_execution_safe(record):
            return None
        _refresh_draw_record(record)
        try:
            return original(*args, **kwargs)
        except ReferenceError:
            # RNA owners can disappear while Blender redraws during teardown.
            # Stop advertising the dead service; the owning suite will remove
            # the native handle during its normal cleanup path.
            _drop_draw_record(record)
            return None

    try:
        wrapped.__name__ = getattr(original, "__name__", "draw_callback")
        wrapped.__qualname__ = getattr(original, "__qualname__", wrapped.__name__)
        wrapped.__doc__ = getattr(original, "__doc__", None)
        wrapped.__module__ = getattr(original, "__module__", wrapped.__module__)
        wrapped._jelararagi_status_draw_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = original
    except Exception:
        pass
    return wrapped


def _make_captured_draw_add(space_name, original_add):
    def captured(*args, **kwargs):
        state = _state()
        context = _active_resource_context(state)
        if not context:
            return original_add(*args, **kwargs)

        callback = args[0] if args else kwargs.get("callback")
        if not callable(callback):
            return original_add(*args, **kwargs)
        suite_id, suite_label = context["suite_id"], context["suite_label"]
        record = {
            "suite_id": suite_id,
            "suite_label": suite_label,
            "space_name": space_name,
            "handle": None,
            "owner": "",
            "callback": callback,
            "wrapped_callback": None,
            "region_type": args[2] if len(args) > 2 else kwargs.get("region_type", "WINDOW"),
            "last_seen": _now(),
            "last_publish": 0.0,
            "stale_after": _DRAW_STALE_SECONDS,
            # Do not execute a newly registered draw callback in the same native
            # startup/load callback that created it.
            "not_before": _now() + 0.25,
        }
        _ensure_global_draw_boundary_handlers()
        wrapped_callback = _make_draw_callback_wrapper(record)
        record["wrapped_callback"] = wrapped_callback
        if args:
            call_args = (wrapped_callback,) + tuple(args[1:])
            call_kwargs = kwargs
        else:
            call_args = args
            call_kwargs = dict(kwargs)
            call_kwargs["callback"] = wrapped_callback
        handle = original_add(*call_args, **call_kwargs)
        record["handle"] = handle
        record["owner"] = f"{suite_id}.draw.{space_name}.{id(handle)}"
        record["status_text"] = _resource_status_text(
            suite_label, callback, f"{space_name} drawing", "描画処理", active=True,
        )
        with state["lock"]:
            state.setdefault("draw_records", {})[id(handle)] = record
        _refresh_draw_record(record)
        _increment_stat(suite_id, "draw_handler")
        return handle
    return captured


def _make_captured_draw_remove(space_name, original_remove):
    def captured(handle, *args, **kwargs):
        state = _state()
        with state["lock"]:
            record = state.setdefault("draw_records", {}).get(id(handle))
        try:
            return original_remove(handle, *args, **kwargs)
        finally:
            if record:
                _drop_draw_record(record)
    return captured


def _install_resource_api_capture(state):
    return


def _restore_one_draw_api(cls, name, owned, raw_value, fallback):
    return


def _restore_resource_api_capture(state):
    return


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    """Run an operation without patching Blender's process-global APIs."""
    yield


def _cleanup_resource_records(prefix: str):
    if bpy is None:
        return
    state = _state()
    timer_records = []
    draw_records = []
    with state["lock"]:
        for record in tuple(state.setdefault("timer_records", {}).values()):
            if not prefix or str(record.get("suite_id", "")).startswith(prefix):
                timer_records.append(record)
        for record in tuple(state.setdefault("draw_records", {}).values()):
            if not prefix or str(record.get("suite_id", "")).startswith(prefix):
                draw_records.append(record)
    for record in timer_records:
        callback = record.get("original")
        timer_is_registered = record.get("native_is_registered")
        timer_unregister = record.get("native_unregister")
        try:
            if callable(callback) and callable(timer_is_registered) and callable(timer_unregister):
                if timer_is_registered(callback):
                    timer_unregister(callback)
        except Exception:
            pass
        _drop_timer_record(record)
    for record in draw_records:
        handle = record.get("handle")
        space_name = record.get("space_name")
        region_type = record.get("region_type", "WINDOW")
        try:
            cls = getattr(bpy.types, str(space_name))
            cls.draw_handler_remove(handle, region_type)
        except Exception:
            pass
        _drop_draw_record(record)


def _callback_invocation_adapter(callback):
    """Return a safe positional/keyword adapter for Blender callbacks.

    Blender 5.1 may pass more positional values to application handlers than
    older handlers declared.  Calling the original callback with every value
    breaks otherwise valid ``def handler(_dummy=None)`` functions.  Inspect the
    original signature once and trim only the surplus arguments.  We do not
    catch ``TypeError`` from the callback itself, because doing so would hide
    genuine implementation errors raised inside the handler.
    """
    try:
        signature = inspect.signature(callback)
    except (TypeError, ValueError):
        return None

    positional = []
    keyword_names = set()
    accepts_varargs = False
    accepts_varkw = False
    for parameter in signature.parameters.values():
        if parameter.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            positional.append(parameter)
        if parameter.kind in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            keyword_names.add(parameter.name)
        elif parameter.kind is inspect.Parameter.VAR_POSITIONAL:
            accepts_varargs = True
        elif parameter.kind is inspect.Parameter.VAR_KEYWORD:
            accepts_varkw = True

    return {
        "max_positional": None if accepts_varargs else len(positional),
        "positional_names": tuple(
            parameter.name
            for parameter in positional
            if parameter.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
        ),
        "keyword_names": None if accepts_varkw else frozenset(keyword_names),
    }


def _adapt_callback_invocation(args, kwargs, adapter):
    if not adapter:
        return tuple(args), dict(kwargs)

    max_positional = adapter.get("max_positional")
    call_args = tuple(args) if max_positional is None else tuple(args[:max_positional])

    keyword_names = adapter.get("keyword_names")
    if keyword_names is None:
        call_kwargs = dict(kwargs)
    else:
        call_kwargs = {key: value for key, value in kwargs.items() if key in keyword_names}

    # Avoid passing a positional-or-keyword parameter twice.
    positional_names = adapter.get("positional_names") or ()
    for name in positional_names[:len(call_args)]:
        call_kwargs.pop(name, None)
    return call_args, call_kwargs


def _run_callback_with_status(callback, args, kwargs, *, owner: str, suite_label: str,
                              kind_en: str, kind_ja: str):
    suite_id = str(owner or "").split('.', 1)[0]
    # During add-on registration one parent status already names the complete
    # operation.  Thousands of RNA default/update callbacks must not each take
    # the shared lock or replace the status text; that was measurable startup
    # latency and made heavy workspaces several seconds slower.
    if _suite_registration_active(suite_id):
        return callback(*args, **kwargs)
    context = None
    for value in args:
        if value is not None and hasattr(value, "workspace") and hasattr(value, "window_manager"):
            context = value
            break
    label = _callback_display_name(callback)
    text = (
        f"{_translated_label(suite_label)}: {kind_ja}「{_translated_label(label)}」を実行中…"
        if _is_japanese(context)
        else f"{_translated_label(suite_label)}: Running {kind_en} “{_translated_label(label)}”…"
    )
    token = begin_task(owner, text, context=context)
    try:
        with capture_runtime_resources(suite_id, suite_label):
            return callback(*args, **kwargs)
    except Exception:
        finish_task(token, _operator_status_text(suite_label, label, "error", context), duration=2.5, context=context)
        raise
    finally:
        # If the error path already removed the token this is a no-op.
        finish_task(token, context=context)


def _increment_stat(suite_id: str, key: str, amount: int = 1) -> None:
    try:
        state = _state()
        with state["lock"]:
            suite_stats = state.setdefault("stats", {}).setdefault(suite_id, {})
            suite_stats[key] = int(suite_stats.get(key, 0)) + int(amount)
    except Exception:
        pass


def _wrap_property_callback(callback, suite_id: str, suite_label: str, callback_kind: str):
    if not callable(callback):
        return callback
    try:
        if bool(getattr(callback, "_jelararagi_status_property_wrapper_v2", False)):
            return callback
    except Exception:
        pass
    owner = f"{suite_id}.property.{callback_kind}"
    if callback_kind == "update":
        def wrapped(self, context):
            return _run_callback_with_status(
                callback, (self, context), {}, owner=owner,
                suite_label=suite_label, kind_en="property update", kind_ja="設定更新",
            )
    elif callback_kind == "set":
        def wrapped(self, value):
            return _run_callback_with_status(
                callback, (self, value), {}, owner=owner,
                suite_label=suite_label, kind_en="property setter", kind_ja="設定書き込み",
            )
    elif callback_kind == "search":
        def wrapped(self, context, edit_text):
            return _run_callback_with_status(
                callback, (self, context, edit_text), {}, owner=owner,
                suite_label=suite_label, kind_en="property search", kind_ja="設定検索",
            )
    else:
        return callback
    try:
        wrapped.__name__ = getattr(callback, "__name__", callback_kind)
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped._jelararagi_status_property_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = callback
    except Exception:
        pass
    _increment_stat(suite_id, f"property_{callback_kind}")
    return wrapped


def _wrap_msgbus_notify(callback, suite_id: str, suite_label: str):
    if not callable(callback):
        return callback
    try:
        if bool(getattr(callback, "_jelararagi_status_msgbus_wrapper_v2", False)):
            return callback
    except Exception:
        pass
    owner = f"{suite_id}.msgbus"
    def wrapped(*args, **kwargs):
        return _run_callback_with_status(
            callback, args, kwargs, owner=owner,
            suite_label=suite_label, kind_en="message-bus callback", kind_ja="メッセージ通知",
        )
    try:
        wrapped.__name__ = getattr(callback, "__name__", "msgbus_notify")
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped._jelararagi_status_msgbus_wrapper_v2 = True
        wrapped._jelararagi_status_original_v2 = callback
    except Exception:
        pass
    _increment_stat(suite_id, "msgbus_notify")
    return wrapped


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    """Track registration without replacing Blender process-global APIs."""
    if bpy is None:
        yield
        return
    state = _state()
    with state["lock"]:
        depths = state.setdefault("registration_depth", {})
        depths[suite_id] = int(depths.get(suite_id, 0)) + 1
    registration_token = begin_task(
        f"{suite_id}.registration",
        (f"{_translated_label(suite_label)}: 登録処理を実行中…"
         if _is_japanese(None) else f"{_translated_label(suite_label)}: Registering…"),
    )
    try:
        with capture_runtime_resources(suite_id, suite_label):
            yield
    finally:
        try:
            with state["lock"]:
                depths = state.setdefault("registration_depth", {})
                remaining = max(0, int(depths.get(suite_id, 0)) - 1)
                if remaining:
                    depths[suite_id] = remaining
                else:
                    depths.pop(suite_id, None)
        except Exception:
            pass
        finish_task(registration_token)


def _handler_lists():
    if bpy is None:
        return
    handlers = bpy.app.handlers
    for name in dir(handlers):
        if name.startswith("_"):
            continue
        try:
            value = getattr(handlers, name)
        except Exception:
            continue
        if isinstance(value, list):
            yield name, value


def _make_persistent_handler_status_marker(callback, owner: str, handler_name: str,
                                           suite_label: str, handler_list):
    """Create a real persistent *function* placed immediately before a handler.

    Blender only preserves Python function objects marked by
    ``bpy.app.handlers.persistent`` when a new ``.blend`` replaces the current
    file.  Callable proxy objects are removed even when they expose a
    ``_bpy_persistent`` attribute.  Replacing a persistent callback with the
    generic proxy therefore silently disabled that callback after the first file
    load.

    The marker leaves the original callback in the list, preserving its exact
    identity for feature toggles and unregister routines.  It only publishes a
    short single-slot status immediately before Blender invokes the real
    callback.  The status remains visible after the synchronous callback returns,
    which is sufficient for UI feedback without adding a second post-handler or
    a permanent polling service.
    """
    marker_owner = f"{owner}.persistent_marker"

    def marker(*args, **kwargs):
        try:
            if not any(value is callback for value in tuple(handler_list)):
                # The owning feature removed its real callback directly.  Retire
                # the companion on the next event instead of leaving a stale
                # persistent handler behind.
                while marker in handler_list:
                    handler_list.remove(marker)
                clear(marker_owner)
                return None
        except Exception:
            return None

        context = None
        for value in args:
            if value is not None and hasattr(value, "workspace") and hasattr(value, "window_manager"):
                context = value
                break
        label = _callback_display_name(callback)
        text = (
            f"{_translated_label(suite_label)}: {handler_name}イベント「{_translated_label(label)}」を実行中…"
            if _is_japanese(context)
            else f"{_translated_label(suite_label)}: Running {handler_name} handler “{_translated_label(label)}”…"
        )
        set_transient(marker_owner, text, duration=0.35, context=context)
        return None

    try:
        marker.__name__ = f"_jel_status_before_{getattr(callback, '__name__', 'handler')}"
        marker.__qualname__ = marker.__name__
        marker.__doc__ = getattr(callback, "__doc__", None)
        marker.__module__ = getattr(callback, "__module__", __name__)
        marker._jelararagi_status_handler_marker_v3 = True
        marker._jelararagi_status_original_v3 = callback
        marker._jelararagi_status_suite_id_v3 = str(owner or "").split(".", 1)[0]
        marker._jelararagi_status_suite_label_v3 = str(suite_label or "")
        marker._jelararagi_status_owner_v3 = marker_owner
        marker = bpy.app.handlers.persistent(marker)
    except Exception:
        try:
            marker._bpy_persistent = None
        except Exception:
            pass
    return marker


class _HandlerStatusProxy:
    """Callable handler proxy that remains removable through the original.

    Blender handler lists are ordinary Python lists.  Add-ons commonly call
    ``handlers.remove(original_callback)`` after registration.  A plain wrapper
    function breaks that contract.  Equality with the original lets list
    membership/index/remove operations continue to work while the proxy adds a
    status scope around execution.
    """
    def __init__(self, callback, owner: str, handler_name: str, suite_label: str):
        self._callback = callback
        self._owner = owner
        self._handler_name = handler_name
        self._suite_label = suite_label
        self._adapter = _callback_invocation_adapter(callback)
        self.__name__ = getattr(callback, "__name__", "handler")
        self.__qualname__ = getattr(callback, "__qualname__", self.__name__)
        self.__doc__ = getattr(callback, "__doc__", None)
        self.__module__ = getattr(callback, "__module__", __name__)
        self._jelararagi_status_handler_wrapper_v2 = True
        self._jelararagi_status_original_v2 = callback
        if hasattr(callback, "_bpy_persistent"):
            self._bpy_persistent = None

    def __call__(self, *args, **kwargs):
        call_args, call_kwargs = _adapt_callback_invocation(args, kwargs, self._adapter)
        return _run_callback_with_status(
            self._callback, call_args, call_kwargs, owner=self._owner,
            suite_label=self._suite_label,
            kind_en=f"{self._handler_name} handler",
            kind_ja=f"{self._handler_name}イベント",
        )

    def __eq__(self, other):
        if other is self or other is self._callback:
            return True
        if isinstance(other, _HandlerStatusProxy):
            return other._callback is self._callback
        return False

    def __hash__(self):
        return hash(self._callback)

    def __getattr__(self, name):
        return getattr(self._callback, name)


def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None) -> int:
    """Remove companions whose real persistent callback no longer exists.

    The scan is intentionally based on attributes stored on the marker function,
    not only on ``driver_namespace`` bookkeeping.  Blender may recreate that
    namespace while persistent functions survive a file load.
    """
    state = _state()
    mappings = state.setdefault("handler_wrappers", {})
    removed = 0
    for _handler_name, handler_list in _handler_lists() or ():
        for marker_fn in tuple(handler_list):
            try:
                if not bool(getattr(marker_fn, "_jelararagi_status_handler_marker_v3", False)):
                    continue
                marker_suite = str(getattr(marker_fn, "_jelararagi_status_suite_id_v3", "") or "")
                if suite_id is not None and marker_suite != suite_id:
                    continue
                original = getattr(marker_fn, "_jelararagi_status_original_v3", None)
                if any(value is original for value in tuple(handler_list)):
                    continue
                while marker_fn in handler_list:
                    handler_list.remove(marker_fn)
                    removed += 1
                clear(str(getattr(marker_fn, "_jelararagi_status_owner_v3", "") or ""))
                for key, record in tuple(mappings.items()):
                    if record.get("wrapper") is marker_fn:
                        mappings.pop(key, None)
            except Exception:
                continue
    return removed


def _restore_missing_persistent_handler_markers() -> int:
    """Re-create companions removed by feature load/re-registration logic.

    Some suites intentionally remove and re-add a persistent callback while a
    file is loading.  Blender preserves the original Python function identity,
    but the status companion that previously preceded it is removed with the
    old list entry.  Metadata is stored on the original function so the final
    global ``load_post`` callback can restore exactly one companion without a
    polling service or replacing the persistent callback itself.
    """
    state = _state()
    mappings = state.setdefault("handler_wrappers", {})
    restored = 0
    for handler_name, handler_list in _handler_lists() or ():
        snapshot = tuple(handler_list)
        for callback in snapshot:
            try:
                if bool(getattr(callback, "_jelararagi_status_handler_marker_v3", False)):
                    continue
                if bool(getattr(callback, "_jelararagi_status_global_prune_v3", False)):
                    continue
                if bool(getattr(callback, "_jelararagi_global_draw_boundary_v1", False)):
                    continue
                if not hasattr(callback, "_bpy_persistent"):
                    continue
                suite_id = str(getattr(callback, "_jelararagi_status_suite_id_v3", "") or "")
                suite_label = str(getattr(callback, "_jelararagi_status_suite_label_v3", "") or "")
                if not suite_id or not suite_label:
                    continue
                if any(
                    bool(getattr(value, "_jelararagi_status_handler_marker_v3", False))
                    and getattr(value, "_jelararagi_status_original_v3", None) is callback
                    for value in tuple(handler_list)
                ):
                    continue
                current_index = next(
                    (index for index, value in enumerate(tuple(handler_list)) if value is callback),
                    None,
                )
                if current_index is None:
                    continue
                owner = f"{suite_id}.handler.{handler_name}.{_callback_display_name(callback)}"
                marker = _make_persistent_handler_status_marker(
                    callback, owner, handler_name, suite_label, handler_list,
                )
                handler_list.insert(current_index, marker)
                mappings[id(marker)] = {
                    "suite_id": suite_id,
                    "handler_name": handler_name,
                    "list": handler_list,
                    "original": callback,
                    "wrapper": marker,
                    "mode": "persistent_marker",
                    "owner": f"{owner}.persistent_marker",
                }
                restored += 1
            except Exception:
                continue
    return restored


def _global_persistent_handler_prune_load_post(_filepath=None, *_args):
    prune_orphan_persistent_handler_markers()
    _restore_missing_persistent_handler_markers()


try:
    _global_persistent_handler_prune_load_post._jelararagi_status_global_prune_v3 = True
    _global_persistent_handler_prune_load_post = bpy.app.handlers.persistent(
        _global_persistent_handler_prune_load_post
    )
except Exception:
    try:
        _global_persistent_handler_prune_load_post._bpy_persistent = None
        _global_persistent_handler_prune_load_post._jelararagi_status_global_prune_v3 = True
    except Exception:
        pass


def _ensure_global_persistent_handler_prune_callback() -> None:
    if bpy is None:
        return
    handlers = bpy.app.handlers.load_post
    try:
        # Keep exactly one cleanup callback and move it to the end after every
        # instrumentation pass so it observes removals made by all load_post
        # callbacks registered so far.
        for callback in tuple(handlers):
            if bool(getattr(callback, "_jelararagi_status_global_prune_v3", False)):
                try:
                    handlers.remove(callback)
                except Exception:
                    pass
        # The prune now runs from the product's single load_post handler (settings._load_post_handler).
    except Exception:
        pass


def _remove_global_persistent_handler_prune_if_unused() -> None:
    if bpy is None:
        return
    has_markers = any(
        bool(getattr(callback, "_jelararagi_status_handler_marker_v3", False))
        for _name, handler_list in (_handler_lists() or ())
        for callback in tuple(handler_list)
    )
    if has_markers:
        return
    try:
        handlers = bpy.app.handlers.load_post
        for callback in tuple(handlers):
            if bool(getattr(callback, "_jelararagi_status_global_prune_v3", False)):
                handlers.remove(callback)
    except Exception:
        pass


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str) -> int:
    """Instrument package handlers without changing persistent callback identity.

    Non-persistent callbacks use the equality-compatible proxy.  Persistent
    callbacks remain untouched and receive a real persistent marker function
    immediately before them, because Blender discards callable proxy objects on
    file load even when they expose ``_bpy_persistent``.
    """
    package_token = str(package_marker or suite_id).lower()
    prune_orphan_persistent_handler_markers(suite_id)
    state = _state()
    mappings = state.setdefault("handler_wrappers", {})
    count = 0
    persistent_marker_added = False
    for handler_name, handler_list in _handler_lists() or ():
        for callback in tuple(handler_list):
            try:
                if bool(getattr(callback, "_jelararagi_status_handler_wrapper_v2", False)):
                    continue
                if bool(getattr(callback, "_jelararagi_status_handler_marker_v3", False)):
                    continue
                if bool(getattr(callback, "_jelararagi_status_global_prune_v3", False)):
                    continue
                if bool(getattr(callback, "_jelararagi_global_draw_boundary_v1", False)):
                    continue
                module_name = str(getattr(callback, "__module__", "") or "").lower()
                if package_token not in module_name:
                    continue
                if any(
                    record.get("suite_id") == suite_id
                    and record.get("original") is callback
                    and record.get("list") is handler_list
                    for record in mappings.values()
                ):
                    continue
                if any(
                    bool(getattr(value, "_jelararagi_status_handler_marker_v3", False))
                    and getattr(value, "_jelararagi_status_original_v3", None) is callback
                    for value in tuple(handler_list)
                ):
                    continue
                current_index = next(
                    (index for index, value in enumerate(tuple(handler_list)) if value is callback),
                    None,
                )
                if current_index is None:
                    continue
                owner = f"{suite_id}.handler.{handler_name}.{_callback_display_name(callback)}"
                if hasattr(callback, "_bpy_persistent"):
                    try:
                        callback._jelararagi_status_suite_id_v3 = str(suite_id)
                        callback._jelararagi_status_suite_label_v3 = str(suite_label)
                        callback._jelararagi_status_package_marker_v3 = str(package_marker or suite_id)
                    except Exception:
                        pass
                    status_marker = _make_persistent_handler_status_marker(
                        callback, owner, handler_name, suite_label, handler_list,
                    )
                    try:
                        handler_list.insert(current_index, status_marker)
                    except Exception:
                        continue
                    persistent_marker_added = True
                    mappings[id(status_marker)] = {
                        "suite_id": suite_id,
                        "handler_name": handler_name,
                        "list": handler_list,
                        "original": callback,
                        "wrapper": status_marker,
                        "mode": "persistent_marker",
                        "owner": f"{owner}.persistent_marker",
                    }
                else:
                    wrapper = _HandlerStatusProxy(callback, owner, handler_name, suite_label)
                    try:
                        handler_list[current_index] = wrapper
                    except Exception:
                        continue
                    mappings[id(wrapper)] = {
                        "suite_id": suite_id,
                        "handler_name": handler_name,
                        "list": handler_list,
                        "original": callback,
                        "wrapper": wrapper,
                        "mode": "proxy",
                    }
                count += 1
                _increment_stat(suite_id, "handler_callback")
            except Exception:
                continue
    if persistent_marker_added:
        _ensure_global_persistent_handler_prune_callback()
    return count


def restore_package_handlers(suite_id: str) -> int:
    state = _state()
    mappings = state.setdefault("handler_wrappers", {})
    restored = 0

    # Remove self-describing metadata first so a concurrent/future load-post
    # cleanup cannot re-create companions while this suite is being disabled.
    for _handler_name, handler_list in _handler_lists() or ():
        for callback in tuple(handler_list):
            try:
                if str(getattr(callback, "_jelararagi_status_suite_id_v3", "") or "") != suite_id:
                    continue
                if bool(getattr(callback, "_jelararagi_status_handler_marker_v3", False)):
                    continue
                for attr_name in (
                    "_jelararagi_status_suite_id_v3",
                    "_jelararagi_status_suite_label_v3",
                    "_jelararagi_status_package_marker_v3",
                ):
                    try:
                        delattr(callback, attr_name)
                    except Exception:
                        pass
            except Exception:
                pass

    for key, record in tuple(mappings.items()):
        if record.get("suite_id") != suite_id:
            continue
        handler_list = record.get("list")
        original = record.get("original")
        wrapper = record.get("wrapper")
        mode = record.get("mode", "proxy")
        try:
            wrapper_indices = [
                index for index, value in enumerate(tuple(handler_list))
                if value is wrapper
            ]
            if mode == "persistent_marker":
                for index in reversed(wrapper_indices):
                    handler_list.pop(index)
                    restored += 1
                clear(str(record.get("owner", "")))
            else:
                original_present = any(value is original for value in handler_list)
                for index in reversed(wrapper_indices):
                    if not original_present:
                        handler_list[index] = original
                        original_present = True
                    else:
                        handler_list.pop(index)
                    restored += 1
        except Exception:
            pass
        mappings.pop(key, None)

    # File loading may reset driver_namespace bookkeeping while the persistent
    # marker functions themselves correctly survive.  Remove them by their
    # self-describing suite attribute as a second, identity-independent pass.
    for _handler_name, handler_list in _handler_lists() or ():
        for callback in tuple(handler_list):
            try:
                if not bool(getattr(callback, "_jelararagi_status_handler_marker_v3", False)):
                    continue
                if str(getattr(callback, "_jelararagi_status_suite_id_v3", "") or "") != suite_id:
                    continue
                while callback in handler_list:
                    handler_list.remove(callback)
                    restored += 1
                clear(str(getattr(callback, "_jelararagi_status_owner_v3", "") or ""))
            except Exception:
                pass
    _remove_global_persistent_handler_prune_if_unused()
    return restored
