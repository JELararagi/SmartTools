# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Independent frame-list background renderer for the Smart Render suite.

The active Blender scene and its saved .blend are never modified by a render
request; the background renderer receives a validated, bounded frame list.
"""

import json
import os
import re
import subprocess
import time

import bpy
from bpy.props import StringProperty
from bpy.types import Operator, Panel

from ..help_operator import draw_help_button
from ..rna_safety import safe_register_class, safe_unregister_class
from ..translation import iface_text


bl_info = {
    'name': 'Frame Range Render',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': '3D View > Sidebar > Smart Render',
    'description': 'Render exact frame lists and ranges in a background Blender process.',
    'category': 'Render',
}

_MAX_FRAMES = 4096
_MAX_ARGUMENT_CHARS = 26000
_PART = re.compile(r'\s*(\d+)\s*(?:-\s*(\d+))?\s*\Z')
_bg_process = None
_owns_scene_property = False
_SPINNER = ('◐', '◓', '◑', '◒')


def _text(english, japanese):
    """Only one language is shown; never concatenate both translations."""
    try:
        language = str(bpy.app.translations.locale).lower().replace('-', '_')
    except (AttributeError, TypeError):
        language = ''
    return japanese if language.startswith('ja') else english


def parse_frame_ranges(ranges_str):
    """Return unique sorted frame numbers, or fail without partial results.

    Commas separate integer frames or inclusive ascending/descending ranges.
    Negative numbers are unsupported for compatibility with the public input
    syntax. Blank input is a valid empty selection, but malformed tokens are not.
    """
    if not isinstance(ranges_str, str):
        raise ValueError('Frame input must be text')
    if not ranges_str.strip():
        return []
    frames = set()
    for token in ranges_str.split(','):
        match = _PART.fullmatch(token)
        if match is None:
            raise ValueError(f'Invalid frame entry: {token.strip()!r}')
        first = int(match.group(1))
        last = int(match.group(2)) if match.group(2) is not None else first
        lower, upper = sorted((first, last))
        if upper - lower + 1 > _MAX_FRAMES:
            raise ValueError(f'Frame range exceeds {_MAX_FRAMES} frames')
        frames.update(range(lower, upper + 1))
        if len(frames) > _MAX_FRAMES:
            raise ValueError(f'More than {_MAX_FRAMES} distinct frames requested')
    return sorted(frames)


# This is newly authored application code executed only in the isolated child
# Blender process. Arguments are data, not interpolated into Python source.
_CHILD_SCRIPT = '''
import bpy
import json
import sys

def render_selected_frames():
    options = sys.argv[sys.argv.index('--') + 1:]
    if len(options) != 1:
        raise ValueError('Missing background frame list')
    frames = json.loads(options[0])
    if not isinstance(frames, list) or not frames or len(frames) > 4096:
        raise ValueError('Invalid frame list')
    if any(type(frame) is not int or frame < 0 for frame in frames):
        raise ValueError('Frames must be nonnegative integers')
    scene = bpy.context.scene
    previous_frame = int(scene.frame_current)
    previous_output = str(scene.render.filepath)
    try:
        for frame in frames:
            scene.frame_set(frame)
            scene.render.filepath = previous_output
            scene.render.filepath = scene.render.frame_path(frame=frame)
            bpy.ops.render.render(write_still=True)
    finally:
        scene.render.filepath = previous_output
        scene.frame_set(previous_frame)

render_selected_frames()
'''


def build_background_command(blender_path, blend_path, frames):
    """Pure planning operation: constructs argv, never launches a process."""
    if not isinstance(blender_path, str) or not blender_path.strip():
        raise ValueError('Blender executable path is missing')
    if not isinstance(blend_path, str) or not blend_path.strip():
        raise ValueError('Saved .blend path is missing')
    if not isinstance(frames, (list, tuple)) or not frames or len(frames) > _MAX_FRAMES:
        raise ValueError('The frame selection must contain 1-4096 frames')
    if any(type(value) is not int or value < 0 for value in frames):
        raise ValueError('Frame selection must contain nonnegative integers')
    payload = json.dumps(sorted(set(frames)), separators=(',', ':'), ensure_ascii=True)
    if len(payload) + len(_CHILD_SCRIPT) + len(blender_path) + len(blend_path) > _MAX_ARGUMENT_CHARS:
        raise ValueError('Frame selection is too large for the background command line')
    return [blender_path, '-b', blend_path, '--python-exit-code', '4', '--python-expr', _CHILD_SCRIPT, '--', payload]


def _is_running():
    return _bg_process is not None and _bg_process.poll() is None


def _redraw_panels():
    """One-shot recurring redraw while a background job is actually running."""
    try:
        manager = bpy.context.window_manager
        if manager is not None:
            for window in manager.windows:
                for area in window.screen.areas:
                    if area.type in {'PROPERTIES', 'VIEW_3D'}:
                        area.tag_redraw()
    except (AttributeError, ReferenceError):
        pass
    return 0.2 if _is_running() else None


class RENDER_OT_clear_frame_input(Operator):
    bl_idname = 'render.clear_frame_list'
    bl_label = 'Clear Frame List'
    bl_description = 'Clear the frame range input'
    bl_options = {'UNDO'}

    def execute(self, context):
        context.scene.frame_range_input = ''
        return {'FINISHED'}


class RENDER_OT_render_frame_ranges(Operator):
    bl_idname = 'render.render_frame_ranges'
    bl_label = 'Render Frame Ranges'
    bl_description = (
        'Render the listed frames in a separate background Blender instance. '
        'Use comma-separated numbers and inclusive ranges such as 1,3,5-8. '
        'Save the .blend first; cancel with Cancel Frame Render.'
    )
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        global _bg_process
        if _is_running():
            self.report({'WARNING'}, _text('A frame render is already running.', 'フレームレンダーがすでに実行中です。'))
            return {'CANCELLED'}
        try:
            frames = parse_frame_ranges(context.scene.frame_range_input)
        except (ValueError, TypeError) as exc:
            self.report({'ERROR'}, _text(f'Frame input error: {exc}', 'フレームの入力形式が正しくありません。数字、カンマ、範囲指定（例: 1,3,5-8）を確認してください。'))
            return {'CANCELLED'}
        if not frames:
            self.report({'WARNING'}, _text('Enter at least one valid frame.', 'レンダリングするフレームを入力してください。'))
            return {'CANCELLED'}
        blend_path = str(bpy.data.filepath or '')
        if not blend_path or not os.path.isfile(blend_path):
            self.report({'ERROR'}, _text('Save the Blender project before background rendering.', 'バックグラウンドレンダー前にBlenderファイルを保存してください。'))
            return {'CANCELLED'}
        try:
            command = build_background_command(str(bpy.app.binary_path), blend_path, frames)
            _bg_process = subprocess.Popen(command)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            _bg_process = None
            self.report({'ERROR'}, _text(f'Background render could not start: {exc}', f'バックグラウンドレンダーを開始できませんでした: {exc}'))
            return {'CANCELLED'}
        try:
            if not bpy.app.timers.is_registered(_redraw_panels):
                bpy.app.timers.register(_redraw_panels, first_interval=0.2)
        except (AttributeError, RuntimeError, ValueError):
            # The render has started, so failure to draw its spinner does not
            # cancel or duplicate the running job.
            pass
        self.report({'INFO'}, _text(f'Rendering {len(frames)} frames in background.', f'{len(frames)}フレームをバックグラウンドでレンダリングしています。'))
        return {'FINISHED'}


class RENDER_OT_cancel_frame_ranges(Operator):
    bl_idname = 'render.cancel_frame_render'
    bl_label = 'Cancel Frame Render'
    bl_description = 'Terminate the background Blender render process started by this tool'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        if not _is_running():
            self.report({'INFO'}, _text('No background frame render is running.', '実行中のフレームレンダーはありません。'))
            return {'FINISHED'}
        try:
            _bg_process.terminate()
        except (OSError, subprocess.SubprocessError) as exc:
            self.report({'ERROR'}, _text(f'Could not cancel frame render: {exc}', f'レンダーを停止できませんでした: {exc}'))
            return {'CANCELLED'}
        self.report({'INFO'}, _text('Frame render cancellation requested.', 'フレームレンダーの停止を要求しました。'))
        return {'FINISHED'}


class RENDER_PT_FRAME_RANGE_RENDERER(Panel):
    bl_label = 'Frame Range Renderer'
    bl_idname = 'RENDER_PT_FRAME_RANGE_RENDERER'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_context = 'output'
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:frame_range_renderer')

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        row = layout.row(align=True)
        row.prop(context.scene, 'frame_range_input', text=_text('Frames', 'フレーム'))
        row.operator('render.clear_frame_list', text='', icon='X')
        try:
            frames = parse_frame_ranges(context.scene.frame_range_input)
        except (TypeError, ValueError):
            frames = []
        if frames:
            layout.label(text=_text(f'{len(frames)} frame(s)  [{frames[0]}–{frames[-1]}]', f'{len(frames)}フレーム  [{frames[0]}～{frames[-1]}]'), icon='RENDER_ANIMATION')
        else:
            layout.label(text=_text('No valid frames.', '有効なフレームがありません。'), icon='ERROR', translate=False)
        layout.separator()
        row = layout.row()
        if _is_running():
            index = int(time.monotonic() * 5) % len(_SPINNER)
            layout.label(text=_text(f'{_SPINNER[index]}  Rendering in background…', f'{_SPINNER[index]}  バックグラウンドでレンダリング中…'))
            layout.separator()
            row.operator('render.cancel_frame_render', icon='CANCEL', text=_text('Cancel Frame Render', 'フレームレンダーを停止'))
        else:
            row.operator('render.render_frame_ranges', icon='RENDER_ANIMATION', text=_text('Render in Background', 'バックグラウンドでレンダリング'))


classes = (
    RENDER_OT_clear_frame_input,
    RENDER_OT_render_frame_ranges,
    RENDER_OT_cancel_frame_ranges,
    RENDER_PT_FRAME_RANGE_RENDERER,
)


def register():
    global _owns_scene_property
    added = []
    try:
        for cls in classes:
            safe_register_class(cls)
            added.append(cls)
        if not hasattr(bpy.types.Scene, 'frame_range_input'):
            bpy.types.Scene.frame_range_input = StringProperty(
                name='Frames',
                description="Frames to render. Use '-' for ranges and ',' to separate. E.g. '1,2,5-6,12-16'",
                default='1-10',
            )
            _owns_scene_property = True
    except Exception:
        if _owns_scene_property and hasattr(bpy.types.Scene, 'frame_range_input'):
            del bpy.types.Scene.frame_range_input
            _owns_scene_property = False
        for cls in reversed(added):
            safe_unregister_class(cls)
        raise


def unregister():
    global _bg_process, _owns_scene_property
    try:
        if bpy.app.timers.is_registered(_redraw_panels):
            bpy.app.timers.unregister(_redraw_panels)
    except (AttributeError, RuntimeError, ValueError):
        pass
    if _is_running():
        try:
            _bg_process.terminate()
        except (OSError, subprocess.SubprocessError):
            pass
    _bg_process = None
    if _owns_scene_property and hasattr(bpy.types.Scene, 'frame_range_input'):
        del bpy.types.Scene.frame_range_input
    _owns_scene_property = False
    for cls in reversed(classes):
        safe_unregister_class(cls)
