# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

from .compat import LEGACY_DEFAULT_MANIFEST_PATH, default_manifest_path
from .operators import OPERATOR_CLASSES
from .help_operator import HELP_OPERATOR_CLASSES
from .controls import PERSISTENT_CONTROL_CLASSES
from .planner import ensure_render_element_item_defaults
from .state import SRR_LogItem, SRR_QueueItem, SRR_Settings, SRR_VariantItem, SCENE_PROPERTY_DEFINITIONS
from .ui import UI_CLASSES, reset_smart_render_pseudo_tab_state


PROPERTY_GROUP_CLASSES = (
    SRR_LogItem,
    SRR_QueueItem,
    SRR_VariantItem,
    SRR_Settings,
)
RUNTIME_CLASSES = HELP_OPERATOR_CLASSES + PERSISTENT_CONTROL_CLASSES + OPERATOR_CLASSES + UI_CLASSES
CLASSES = PROPERTY_GROUP_CLASSES + RUNTIME_CLASSES

_REGISTERED = False
_UNREGISTERING = False
_RUNTIME_TIMER_HANDLES: set[object] = set()
_RUNTIME_REFRESH_TIMER = None
_INTEGRATED_TOOLS_REGISTERED = False


def _safe_class_dict(cls: type | None):
    if cls is None or not isinstance(cls, type):
        return {}
    try:
        namespace = type.__getattribute__(cls, "__dict__")
        return namespace if namespace is not None else {}
    except Exception:
        return {}


def _safe_class_name(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__name__") or "")
    except Exception:
        return ""


def _safe_class_module(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__module__") or "")
    except Exception:
        return ""


def _safe_class_attr_string(cls: type | None, name: str) -> str:
    if name == "__name__":
        return _safe_class_name(cls)
    if name == "__module__":
        return _safe_class_module(cls)
    try:
        value = _safe_class_dict(cls).get(name, "")
    except Exception:
        value = ""
    try:
        return str(value or "")
    except Exception:
        return ""


def _safe_class_attr_bool(cls: type | None, name: str) -> bool:
    try:
        return bool(_safe_class_dict(cls).get(name, False))
    except Exception:
        return False


_STALE_PANEL_NAVIGATION_LABELS = {
    "Panel Navigation",
    "パネルナビゲーション",
    'パネルナビゲーション',
}

_STALE_SMART_RENDER_SECTION_PANEL_IDS = {
    "SMART_RENDER_SUITE_PT_sidebar_anchor",
    "SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor",
    "SRR_PT_PANEL_NAVIGATION",
    "SRR_IMAGE_PT_MAIN_PANEL",
    "SRR_PT_dashboard",
    "SRR_PT_profile",
    "SRR_PT_render_elements",
    "SRR_PT_network_render",
    "SRR_PT_workflows",
    "SRR_PT_execution",
    "SRR_PT_variants",
    "SRR_PT_output",
    "SRR_PT_batch",
    "SRR_PT_extra_tools",
    "SRR_PT_bridge",
    "SRR_PT_logs",
    "SRR_IMAGE_PT_dashboard",
    "SRR_IMAGE_PT_profile",
    "SRR_IMAGE_PT_render_elements",
    "SRR_IMAGE_PT_network_render",
    "SRR_IMAGE_PT_workflows",
    "SRR_IMAGE_PT_execution",
    "SRR_IMAGE_PT_variants",
    "SRR_IMAGE_PT_output",
    "SRR_IMAGE_PT_batch",
    "SRR_IMAGE_PT_extra_tools",
    "SRR_IMAGE_PT_bridge",
    "SRR_IMAGE_PT_logs",
    "SMART_RENDER_PT_always_on",
    "SRR_PT_properties_nav",
}


def _rna_base_types() -> tuple[type, ...]:
    return tuple(
        base
        for base in (
            getattr(bpy.types, "Panel", None),
            getattr(bpy.types, "UIList", None),
            getattr(bpy.types, "Operator", None),
            getattr(bpy.types, "PropertyGroup", None),
            getattr(bpy.types, "Menu", None),
            getattr(bpy.types, "AddonPreferences", None),
            getattr(bpy.types, "Header", None),
            getattr(bpy.types, "RenderEngine", None),
            getattr(bpy.types, "Gizmo", None),
            getattr(bpy.types, "GizmoGroup", None),
            getattr(bpy.types, "Node", None),
            getattr(bpy.types, "NodeTree", None),
            getattr(bpy.types, "FileHandler", None),
            getattr(bpy.types, "AssetShelf", None),
        )
        if base is not None
    )


def _lookup_registered_class(candidate: type):
    try:
        from .rna_safety import lookup_registered_class
        return lookup_registered_class(candidate)
    except Exception:
        pass
    try:
        name = _safe_class_name(candidate).strip()
    except Exception:
        name = ""
    if not name or not name.isidentifier():
        return None
    try:
        existing = getattr(bpy.types, name, None)
    except Exception:
        return None
    return existing if isinstance(existing, type) else None

def _unregister_class_sequence(classes: tuple[type, ...] | list[type]) -> None:
    try:
        from .rna_safety import unregister_existing_class
    except Exception:
        unregister_existing_class = None
    for cls in reversed(tuple(classes or ())):
        try:
            if callable(unregister_existing_class):
                unregister_existing_class(cls)
                continue
            existing = _lookup_registered_class(cls)
            if existing is not None:
                bpy.utils.unregister_class(existing)
        except Exception:
            pass


def _clear_scene_properties() -> None:
    for name in reversed(tuple(SCENE_PROPERTY_DEFINITIONS.keys())):
        if hasattr(bpy.types.Scene, name):
            try:
                delattr(bpy.types.Scene, name)
            except Exception:
                pass


WINDOW_MANAGER_PROPERTY_NAMES = (
    "srr_persistent_toggle_state",
    "srr_properties_tab_active",
    "srr_properties_prev_context",
    "srr_properties_base_context",
)


def _clear_window_manager_properties() -> None:
    # Remove hidden state keys left by older builds if they exist.
    # No new WindowManager state is created for the normal N-panel UI.
    for name in WINDOW_MANAGER_PROPERTY_NAMES:
        if hasattr(bpy.types.WindowManager, name):
            try:
                delattr(bpy.types.WindowManager, name)
            except Exception:
                pass

def _clear_registered_keymaps() -> None:
    return None


def _prune_empty_addon_keymaps() -> None:
    return None


def _unregister_stale_classes() -> None:
    _unregister_class_sequence(CLASSES)
    try:
        from .domainless_naming import ID_RENAME_MAP
        from .rna_safety import unregister_existing_class
        for old_identifier in ID_RENAME_MAP.keys():
            if str(old_identifier).isidentifier():
                unregister_existing_class(str(old_identifier))
    except Exception:
        pass
    _unregister_legacy_smarttools_panels()


def _iter_panel_subclasses() -> tuple[type, ...]:
    try:
        panel_base = getattr(bpy.types, "Panel")
        stack = list(tuple(panel_base.__subclasses__()))
    except Exception:
        return tuple()
    result = []
    seen = set()
    while stack:
        cls = stack.pop()
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        result.append(cls)
        try:
            stack.extend(tuple(cls.__subclasses__()))
        except Exception:
            pass
    return tuple(result)


def _panel_class_from_idname(identifier: str):
    if not identifier:
        return None
    # Avoid Panel.recursive RNA subclass lookup; Blender 5.1 can crash inside the
    # recursive RNA lookup during add-on reload/UI event processing.
    try:
        if str(identifier).isidentifier():
            found = getattr(bpy.types, identifier, None)
            if isinstance(found, type):
                return found
    except Exception:
        pass
    for cls in _iter_panel_subclasses():
        try:
            if _safe_class_name(cls) == identifier:
                return cls
            if _safe_class_attr_string(cls, "bl_idname") == identifier:
                return cls
        except Exception:
            continue
    return None




def _is_current_runtime_panel_class(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        return any(cls is current for current in tuple(UI_CLASSES or ()) if isinstance(current, type))
    except Exception:
        return False


def _is_smart_render_owned_panel(cls: type | None) -> bool:
    """Return True only for Panel classes owned by Smart Render Suite.

    Older cleanup code treated any Smart Tools host panel with an empty clone
    owner as a stale Smart Render panel.  Native roots from other suites use the
    same host-panel marker, so that broad condition could unregister and hide
    their complete N-panel UI (Smart Overlay was a reproducible victim).
    Ownership must therefore be established from the module, explicit owner, or
    Smart Render-specific RNA identifiers; generic host/proxy flags are never
    sufficient on their own.
    """
    if cls is None or not isinstance(cls, type):
        return False
    module = _safe_class_module(cls).lower()
    owner = _safe_class_attr_string(cls, "_smart_suite_clone_owner").strip().lower()
    manager_tool_key = _safe_class_attr_string(cls, "_smart_tools_manager_tool_key").strip().lower()
    name = _safe_class_name(cls).strip()
    bl_idname = _safe_class_attr_string(cls, "bl_idname").strip()
    identifiers = (name, bl_idname)
    if "smart_render_suite" in module:
        return True
    if owner == "smart_render_suite" or manager_tool_key == "smart_render_suite":
        return True
    for identifier in identifiers:
        upper = identifier.upper()
        lower = identifier.lower()
        if (
            upper.startswith("SRR_")
            or upper.startswith("SMART_RENDER_")
            or upper.startswith("SMART_RENDER_SUITE_")
            or lower.startswith("smarttools_npanel_pt_smart_render_suite")
            or lower.startswith("smarttools_pt_int_smart_render_suite")
        ):
            return True
    return False


def _is_legacy_smarttools_panel(cls: type) -> bool:
    try:
        name = _safe_class_name(cls)
        bl_idname = _safe_class_attr_string(cls, "bl_idname")
        module = _safe_class_module(cls)
        owner = _safe_class_attr_string(cls, "_smart_suite_clone_owner")
        proxy = _safe_class_attr_bool(cls, "_smart_suite_npanel_proxy") or _safe_class_attr_bool(cls, "_smart_suite_host_panel")
        region = _safe_class_attr_string(cls, "bl_region_type")
    except Exception:
        return False
    if (bl_idname in _STALE_SMART_RENDER_SECTION_PANEL_IDS or name in _STALE_SMART_RENDER_SECTION_PANEL_IDS) and not _is_current_runtime_panel_class(cls):
        return True
    smart_render_owned = _is_smart_render_owned_panel(cls)
    if proxy and smart_render_owned:
        return True
    if _safe_class_attr_string(cls, "bl_category") == "Smart Render" and (
        name.startswith("SMARTTOOLS_PT_INT") or bl_idname.startswith("SMARTTOOLS_PT_INT")
    ):
        return True
    if name.startswith("SMARTTOOLS_NPANEL_PT_smart_render_suite") or bl_idname.startswith("SMARTTOOLS_NPANEL_PT_smart_render_suite"):
        return True
    if proxy and ("INTROOT" in name or "INTROOT" in bl_idname) and smart_render_owned:
        return True
    if "smart_render_suite.navigation_properties" in module and name.startswith(("SMARTTOOLS_NPANEL_PT_", "SMARTTOOLS_PT_")):
        return True
    if "smart_render_suite.ui" in module and region == "NAVIGATION_BAR":
        return True
    label = _safe_class_attr_string(cls, "bl_label")
    if smart_render_owned and not _is_current_runtime_panel_class(cls) and label in _STALE_PANEL_NAVIGATION_LABELS:
        return True
    if _safe_class_attr_string(cls, "bl_category") == "Smart Render" and not _safe_class_attr_string(cls, "bl_parent_id"):
        if not _is_current_runtime_panel_class(cls) and "smart_render_suite" in module and (label in {"Smart Render", "スマートレンダー"} or _safe_class_attr_bool(cls, "_smart_render_image_editor_panel")):
            return True
    return False


def _unregister_legacy_smarttools_panels() -> None:
    candidates = []
    for identifier in tuple(_STALE_SMART_RENDER_SECTION_PANEL_IDS) + (
        "SMARTTOOLS_NPANEL_PT_smart_render_suite_settings",
    ):
        found = _panel_class_from_idname(identifier)
        if isinstance(found, type) and not _is_current_runtime_panel_class(found):
            candidates.append(found)
    for cls in _iter_panel_subclasses():
        if _is_legacy_smarttools_panel(cls):
            candidates.append(cls)
    seen = set()
    for cls in reversed(tuple(candidates)):
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            # If Blender refuses to unregister a stale navigation/root panel during
            # a live Sidebar refresh, keep it outside the public Smart Render
            # category. poll=False alone is not sufficient on Blender 5.1 because
            # root panel headers can stay materialized during N-panel rebuilds.
            cls.bl_label = "Smart Render Compatibility"
            cls.bl_category = "SRS Hidden"
            cls.bl_region_type = "UI"
            try:
                cls.bl_options = {"HIDE_HEADER"}
            except Exception:
                pass
            cls.poll = classmethod(lambda _cls, _context: False)
        except Exception:
            pass
        try:
            # Anchor panels need a direct unregister attempt; rna_safety
            # intentionally keeps anchors patched in place for shutdown safety.
            # This function runs during normal register/update cleanup only.
            if 'bl_rna' in cls.__dict__:
                bpy.utils.unregister_class(cls)
        except Exception:
            try:
                from .rna_safety import unregister_existing_class
                unregister_existing_class(cls)
            except Exception:
                pass
            try:
                cls.bl_category = "SRS Hidden"
                cls.poll = classmethod(lambda _cls, _context: False)
            except Exception:
                pass


def _property_state_registered() -> bool:
    try:
        for cls in PROPERTY_GROUP_CLASSES:
            if _lookup_registered_class(cls) is None:
                return False
        for name in SCENE_PROPERTY_DEFINITIONS.keys():
            if not hasattr(bpy.types.Scene, name):
                return False
    except Exception:
        return False
    return True


def _register_property_state_if_needed() -> None:
    from .rna_safety import ensure_registered_class
    for cls in PROPERTY_GROUP_CLASSES:
        ensure_registered_class(cls)

    for name, factory in SCENE_PROPERTY_DEFINITIONS.items():
        if hasattr(bpy.types.Scene, name):
            continue
        setattr(bpy.types.Scene, name, factory())




def ensure_root_panel_classes() -> None:
    """Register each fixed physical editor root exactly once."""
    try:
        from .rna_safety import unregister_existing_class, ensure_registered_class
    except Exception:
        unregister_existing_class = None
        ensure_registered_class = None
    for cls in tuple(UI_CLASSES or ()):  # type: ignore[arg-type]
        try:
            identifier = _safe_class_attr_string(cls, 'bl_idname') or _safe_class_name(cls)
        except Exception:
            identifier = ''
        if not bool(getattr(cls, '_smart_render_full_body_root', False)):
            continue
        try:
            existing = getattr(bpy.types, identifier, None) if identifier.isidentifier() else None
        except Exception:
            existing = None
        if existing is cls:
            continue
        if isinstance(existing, type) and existing is not cls:
            try:
                if callable(unregister_existing_class):
                    unregister_existing_class(existing)
                else:
                    bpy.utils.unregister_class(existing)
            except Exception:
                pass
        # If this exact class had been registered and then removed by stale
        # cleanup, Blender may leave bl_rna on the Python class object.  One
        # unregister attempt clears that transient state before re-registering.
        try:
            if _safe_class_dict(cls).get('bl_rna') is not None and getattr(bpy.types, identifier, None) is not cls:
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
        try:
            if callable(ensure_registered_class):
                ensure_registered_class(cls)
            else:
                bpy.utils.register_class(cls)
        except Exception:
            # Last-resort direct retry after clearing a transient bl_rna state.
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            try:
                bpy.utils.register_class(cls)
            except Exception:
                pass



def _is_smart_tools_manager_proxy_panel(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        if bool(getattr(cls, '_smart_tools_manager_proxy', False)):
            return True
    except Exception:
        pass
    try:
        module = str(getattr(cls, '__module__', '') or '').lower()
        name = str(getattr(cls, '__name__', '') or '').lower()
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').lower()
    except Exception:
        return False
    return (
        'smart_tools_manager' in module
        or '_smart_tools_manager_proxy' in name
        or '_smart_tools_manager_proxy' in bl_idname
    )


def _is_public_smart_render_root_panel(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    if _is_smart_tools_manager_proxy_panel(cls):
        return False
    try:
        if _safe_class_attr_string(cls, "bl_region_type") != "UI":
            return False
        if _safe_class_attr_string(cls, "bl_category") != "Smart Render":
            return False
        if _safe_class_attr_string(cls, "bl_parent_id"):
            return False
        return True
    except Exception:
        return False


def enforce_single_smart_render_root_panel() -> None:
    """Quarantine only exact retired roots; keep all fixed editor roots."""
    if _UNREGISTERING:
        return
    candidates: list[type] = []
    for identifier in (
        'SMART_RENDER_SUITE_PT_sidebar_anchor',
        'SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor',
        'SRR_IMAGE_PT_MAIN_PANEL',
        'SRR_PT_PANEL_NAVIGATION',
        'SMART_RENDER_PT_always_on',
        'SRR_PT_properties_nav',
    ):
        found = _panel_class_from_idname(identifier)
        if isinstance(found, type):
            candidates.append(found)
    seen: set[int] = set()
    for cls in reversed(tuple(candidates)):
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            cls.bl_label = 'Smart Render Compatibility'
            cls.bl_category = 'SRS Hidden'
            cls.bl_region_type = 'UI'
            try:
                cls.bl_options = {'HIDE_HEADER'}
            except Exception:
                pass
            cls.poll = classmethod(lambda _cls, _context: False)
        except Exception:
            pass
        try:
            if 'bl_rna' in cls.__dict__:
                bpy.utils.unregister_class(cls)
        except Exception:
            try:
                cls.bl_category = 'SRS Hidden'
                cls.poll = classmethod(lambda _cls, _context: False)
            except Exception:
                pass

def _root_panel_repair_needed() -> bool:
    return False


def _schedule_root_panel_repair() -> None:
    return None

def _normalize_scene_storage_defaults() -> None:
    """Migrate only the active Scene at a finite registration/load boundary."""
    default_path = default_manifest_path()
    try:
        scene = getattr(getattr(bpy, "context", None), "scene", None)
    except Exception:
        scene = None
    if scene is None:
        return
    settings = getattr(scene, "srr_settings", None)
    if settings is None:
        return
    raw_value = str(getattr(settings, "manifest_path", "") or "").strip()
    if raw_value in {"", LEGACY_DEFAULT_MANIFEST_PATH}:
        try:
            settings.manifest_path = default_path
        except Exception:
            pass
    try:
        ensure_render_element_item_defaults(settings)
    except Exception:
        pass



def _smart_render_runtime_healthy() -> bool:
    if not _REGISTERED:
        return False
    try:
        return all(_lookup_registered_class(cls) is not None for cls in RUNTIME_CLASSES)
    except Exception:
        return False


def _smart_render_runtime_refresh(force: bool = False) -> None:
    # Standard N-panel mode needs no shared host or Properties-page repair.
    del force
    if not _REGISTERED:
        return
    try:
        for window in getattr(getattr(bpy.context, 'window_manager', None), 'windows', ()):  # type: ignore[attr-defined]
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) if screen is not None else ():
                if str(getattr(area, 'type', '') or '') in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    area.tag_redraw()
    except Exception:
        pass

def _register_runtime_timer(callback, *, first_interval: float = 0.05, persistent: bool = False) -> bool:
    del callback, first_interval, persistent
    return False



def _unregister_runtime_timer(callback) -> None:
    if not callable(callback):
        return
    try:
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    except Exception:
        pass
    _RUNTIME_TIMER_HANDLES.discard(callback)



def _clear_runtime_timers() -> None:
    global _RUNTIME_REFRESH_TIMER
    for callback in tuple(_RUNTIME_TIMER_HANDLES):
        _unregister_runtime_timer(callback)
    _RUNTIME_TIMER_HANDLES.clear()
    _RUNTIME_REFRESH_TIMER = None



def _schedule_smart_render_runtime_refresh(first_interval: float = 0.08, attempts: int = 1) -> None:
    del first_interval, attempts
    _smart_render_runtime_refresh(force=True)


@persistent
def _smart_render_load_post_handler(_dummy) -> None:
    # settings.py owns JSON replay.  This handler performs only the finite
    # active-Scene default migration and one redraw after file loading.
    _normalize_scene_storage_defaults()
    _schedule_smart_render_runtime_refresh(first_interval=0.12, attempts=1)


@persistent
def _smart_render_load_factory_startup_post_handler(_dummy) -> None:
    _normalize_scene_storage_defaults()
    _schedule_smart_render_runtime_refresh(first_interval=0.12, attempts=1)



def _append_handler_once(handler_list, fn) -> None:
    if fn not in handler_list:
        handler_list.append(fn)



def _remove_handler_if_present(handler_list, fn) -> None:
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass



def _install_runtime_resilience() -> None:
    # No shared host is used in standard N-panel mode.
    return None

def _remove_runtime_resilience() -> None:
    _clear_runtime_timers()




_INTEGRATED_TOOLS_REGISTER_ERROR = ''


def _register_integrated_tools() -> None:
    global _INTEGRATED_TOOLS_REGISTERED, _INTEGRATED_TOOLS_REGISTER_ERROR
    if _INTEGRATED_TOOLS_REGISTERED:
        return
    try:
        from . import tool_runtime
        tool_runtime.register()
    except Exception as exc:
        try:
            from . import tool_runtime
            tool_runtime.unregister()
        except Exception:
            pass
        _INTEGRATED_TOOLS_REGISTERED = False
        _INTEGRATED_TOOLS_REGISTER_ERROR = str(exc)
        # The core Smart Render N-panel must remain available even if an
        # embedded/on-demand tool registry fails during startup.
        return
    _INTEGRATED_TOOLS_REGISTER_ERROR = ''
    _INTEGRATED_TOOLS_REGISTERED = True


def _unregister_integrated_tools() -> None:
    global _INTEGRATED_TOOLS_REGISTERED
    if not _INTEGRATED_TOOLS_REGISTERED:
        return
    try:
        from . import tool_runtime
        tool_runtime.unregister()
    finally:
        _INTEGRATED_TOOLS_REGISTERED = False


def _register_core() -> None:
    global _REGISTERED, _UNREGISTERING

    _UNREGISTERING = False
    reset_smart_render_pseudo_tab_state()
    _clear_registered_keymaps()
    _prune_empty_addon_keymaps()
    _clear_runtime_timers()
    try:
        from . import controls as _controls
        _controls.unregister_runtime_properties()
    except Exception:
        pass
    _clear_window_manager_properties()
    _unregister_class_sequence(RUNTIME_CLASSES)
    _unregister_legacy_smarttools_panels()

    # Register the visible Sidebar root panels before any optional runtime state.
    # If a later PropertyGroup or embedded-tool registration fails, the Smart
    # Render N-panel category remains materialized and can display a safe
    # fallback instead of disappearing entirely.
    try:
        from .rna_safety import ensure_registered_class as _ensure_root_panel_class
        for _root_cls in tuple(UI_CLASSES or ()):  # type: ignore[name-defined]
            try:
                _identifier = _safe_class_attr_string(_root_cls, 'bl_idname') or _safe_class_name(_root_cls)
                if bool(getattr(_root_cls, '_smart_render_full_body_root', False)):
                    _ensure_root_panel_class(_root_cls)
            except Exception:
                continue
    except Exception:
        pass

    try:
        from .translation import localize_class_attributes
        localize_class_attributes(PROPERTY_GROUP_CLASSES + RUNTIME_CLASSES)
    except Exception:
        pass

    _register_property_state_if_needed()
    from .rna_safety import ensure_registered_class
    runtime_registration_errors: list[str] = []
    # Register the root N-panel first so a later non-critical class problem can
    # never remove the visible Smart Render Sidebar entry.
    priority_classes = []
    for cls in RUNTIME_CLASSES:
        try:
            if bool(getattr(cls, '_smart_render_full_body_root', False)):
                priority_classes.append(cls)
        except Exception:
            pass
    ordered_runtime_classes = tuple(priority_classes) + tuple(cls for cls in RUNTIME_CLASSES if cls not in priority_classes)
    for cls in ordered_runtime_classes:
        try:
            ensure_registered_class(cls)
        except Exception as exc:
            runtime_registration_errors.append(f"{_safe_class_name(cls) or cls}: {exc}")
            # Continue registration so the N-panel remains visible.  Missing
            # operators/panels are safer than a completely absent category.
            continue

    try:
        from . import controls as _controls
        _controls.register_runtime_properties()
    except Exception:
        pass

    _normalize_scene_storage_defaults()
    # load_post has one product callback (settings._load_post_handler), which calls _smart_render_load_post_handler.
    # load_factory_startup_post likewise has the single settings._load_post_handler.
    try:
        from . import settings as _settings
        _settings.install()
    except Exception:
        pass
    _register_integrated_tools()
    # A same-session extension update can leave old generated or mirrored root
    # panels registered after the fresh root has been restored. Remove those
    # non-current Smart Render panels once more without touching UI_CLASSES.
    _unregister_legacy_smarttools_panels()
    ensure_root_panel_classes()
    enforce_single_smart_render_root_panel()
    try:
        from . import controls as _controls
        _controls.schedule_enabled_always_on_startup(getattr(bpy, 'context', None))
    except Exception:
        pass
    _prune_empty_addon_keymaps()
    _REGISTERED = True



def _unregister_core() -> None:
    global _REGISTERED, _UNREGISTERING

    if _UNREGISTERING:
        return

    _UNREGISTERING = True
    try:
        reset_smart_render_pseudo_tab_state()
        _clear_registered_keymaps()
        _prune_empty_addon_keymaps()
        _clear_runtime_timers()
        _remove_handler_if_present(bpy.app.handlers.load_post, _smart_render_load_post_handler)
        try:
            _remove_handler_if_present(bpy.app.handlers.load_factory_startup_post, _smart_render_load_factory_startup_post_handler)
        except Exception:
            pass
        try:
            from . import controls as _controls
            _controls.cancel_enabled_always_on_startup()
        except Exception:
            pass
        try:
            from . import settings as _settings
            _settings.uninstall()
        except Exception:
            pass
        _unregister_integrated_tools()
        try:
            from . import controls as _controls
            _controls.unregister_runtime_properties()
        except Exception:
            pass
        _clear_window_manager_properties()
        _unregister_class_sequence(RUNTIME_CLASSES)
        _clear_window_manager_properties()
        _clear_scene_properties()
        _unregister_class_sequence(PROPERTY_GROUP_CLASSES)
        # Do not scan stale Panel subclasses during unregister/Blender exit.
        # Stale cleanup is handled during register/preflight; direct class
        # unregister above is sufficient here and avoids PyRNA access while
        # Blender is tearing down RNA/UI data.
        _prune_empty_addon_keymaps()
    finally:
        _REGISTERED = False
        _UNREGISTERING = False


# --- standard N-panel registration wrapper ---
_OLD_SMART_RENDER_REGISTER = _register_core
_OLD_SMART_RENDER_UNREGISTER = _unregister_core


def register() -> None:
    global _REGISTERED
    if _REGISTERED and not _UNREGISTERING:
        unregister()
    _OLD_SMART_RENDER_REGISTER()
    ensure_root_panel_classes()
    _install_runtime_resilience()


def unregister() -> None:
    _clear_registered_keymaps()
    _remove_runtime_resilience()
    try:
        from .help_operator import unload_help_icon_preview
        unload_help_icon_preview()
    except Exception:
        pass
    _OLD_SMART_RENDER_UNREGISTER()
