# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Product identity and native Blender integration metadata."""

ADDON_ID = "smart_render_suite"
ADDON_NAME = "Smart Render"
ADDON_VERSION = (1, 0, 0)
ADDON_VERSION_STR = "{}.{}.{}".format(*ADDON_VERSION)
BLENDER_MIN_VERSION = (5, 1, 0)

# Saved manifests keep their existing storage format identifier.
MANIFEST_SCHEMA_VERSION = "srs-manifest-3.15.34"

BL_INFO = dict(
    name=ADDON_NAME,
    version=ADDON_VERSION,
    blender=BLENDER_MIN_VERSION,
    author="JELararagi",
    category="Render",
    location="View3D > Sidebar > Smart Render",
    description="Set up lighting and cameras, manage passes and variants, and prepare render queues and pipeline exports.",
)
