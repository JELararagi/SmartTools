# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.props import BoolProperty, StringProperty

from .translation import localize_pair, tooltip

# Legacy nested pointer name kept only for cleanup. The runtime settings now use
# direct WindowManager RNA properties so install does not depend on registering a
# PropertyGroup during add-on enable.
_PROPERTY_NAME = "smart_render_suite_runtime_prefs"
_SEARCH_PROPERTY = "smart_render_suite_search_text"
_SHOW_PROPERTY = "smart_render_suite_show_integrated_tools"
_RUNTIME_PROPERTY_NAMES = (_SEARCH_PROPERTY, _SHOW_PROPERTY)
_REGISTER_ERROR = ""
_REGISTERED_DIRECT_PROPERTIES = False


def _txt(ja: str, en: str) -> str:
    return localize_pair(ja, en)


def _tag_supported_npanel_redraw() -> None:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        for window in getattr(wm, "windows", ()) or ():
            screen = getattr(window, "screen", None)
            for area in getattr(screen, "areas", ()) or ():
                if str(getattr(area, "type", "") or "") in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _snapshot_after_change(_self, context) -> None:
    try:
        from . import tool_registry
        tool_registry.clear_cache()
    except Exception:
        pass
    try:
        from . import settings as _settings
        ctx = context or getattr(bpy, "context", None)
        _settings.snapshot_context(ctx, force=_settings.is_npanel_state_save_enabled(ctx))
    except Exception:
        pass
    _tag_supported_npanel_redraw()


class _RuntimePreferencesProxy:
    """Small compatibility proxy for code that reads prefs.search_text values."""

    __slots__ = ("_wm",)

    def __init__(self, wm):
        self._wm = wm

    @property
    def search_text(self) -> str:
        try:
            return str(getattr(self._wm, _SEARCH_PROPERTY, "") or "")
        except Exception:
            return ""

    @search_text.setter
    def search_text(self, value: str) -> None:
        try:
            setattr(self._wm, _SEARCH_PROPERTY, str(value or ""))
        except Exception:
            pass

    @property
    def show_integrated_tools(self) -> bool:
        try:
            return bool(getattr(self._wm, _SHOW_PROPERTY, True))
        except Exception:
            return True

    @show_integrated_tools.setter
    def show_integrated_tools(self, value: bool) -> None:
        try:
            setattr(self._wm, _SHOW_PROPERTY, bool(value))
        except Exception:
            pass


def _runtime_owner(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None)
    if wm is None:
        return None
    try:
        if hasattr(wm, _SEARCH_PROPERTY) and hasattr(wm, _SHOW_PROPERTY):
            return wm
    except Exception:
        pass
    return None


def get_runtime_preferences(context=None):
    wm = _runtime_owner(context)
    return _RuntimePreferencesProxy(wm) if wm is not None else None


def draw_runtime_settings(layout, context) -> None:
    wm = _runtime_owner(context)
    if wm is None:
        layout.label(text=_txt("Smart Render のNパネル設定はまだ利用できません。", "Smart Render N-panel settings are not available yet."), icon="ERROR", translate=False)
        if _REGISTER_ERROR:
            layout.label(text=str(_REGISTER_ERROR)[:180], icon="ERROR")
        return
    col = layout.column(align=True)
    col.prop(wm, _SEARCH_PROPERTY, text="", icon="VIEWZOOM")
    col.prop(wm, _SHOW_PROPERTY, text=_txt("一覧を表示", "Show List"), toggle=True)


def register() -> None:
    global _REGISTER_ERROR, _REGISTERED_DIRECT_PROPERTIES
    _REGISTER_ERROR = ""
    _REGISTERED_DIRECT_PROPERTIES = False

    # Remove the legacy PointerProperty before installing direct RNA properties.
    try:
        delattr(bpy.types.WindowManager, _PROPERTY_NAME)
    except Exception:
        pass

    try:
        if not hasattr(bpy.types.WindowManager, _SEARCH_PROPERTY):
            setattr(
                bpy.types.WindowManager,
                _SEARCH_PROPERTY,
                StringProperty(
                    name=_txt("検索", "Search"),
                    description=tooltip(
                        "Smart Render Nパネル内のツール一覧を、ツール名、概要、使い方、説明文、エイリアス名で絞り込みます。",
                        "Filters the Smart Render tool list in the N-panel by tool name, overview, usage, description, and alias.",
                        usage_ja="Smart Render 内の検索欄へ文字を入力すると、一致するツールだけが表示されます。空欄に戻すと全件表示です。",
                        usage_en="Type in the search field in Smart Render. Matching tools remain visible; clearing the field shows all tools.",
                        tip_ja='この値は Nパネル状態保存が有効な場合、Blender の設定フォルダー内 Smart_Render_Suite/Smart_Render_Suite.json へ保存され、Blender再起動後や別シーン読込後も維持されます。',
                        tip_en="When N-panel State Save is enabled, this value is saved to Smart_Render_Suite/Smart_Render_Suite.json in Blender's config folder and restored after restarting Blender or opening another scene.",
                    ),
                    default="",
                    update=_snapshot_after_change,
                ),
            )
        if not hasattr(bpy.types.WindowManager, _SHOW_PROPERTY):
            setattr(
                bpy.types.WindowManager,
                _SHOW_PROPERTY,
                BoolProperty(
                    name=_txt("その他ツール", "Other Tools"),
                    description=tooltip(
                        "Smart Render Nパネル内のツール一覧を表示または非表示にします。",
                        "Shows or hides the Smart Render tool list inside the N-panel.",
                        usage_ja="一覧を普段使わない場合はオフにし、必要になった時だけオンに戻してください。各ツールの読み込み状態や検索結果の表示にだけ影響します。",
                        usage_en="Turn this off when you do not need the list, and turn it back on when you want to browse or load tools. It only affects the Smart Render tool list and search results.",
                        tip_ja="ツール本体の有効/無効を切り替える項目ではありません。非表示中も読み込み済み機能はNパネル内の既存パネルから使えます。",
                        tip_en="This does not enable or disable tool modules. Loaded tools remain available through their existing N-panel proxy panels.",
                    ),
                    default=True,
                    update=_snapshot_after_change,
                ),
            )
        _REGISTERED_DIRECT_PROPERTIES = True
    except Exception as exc:
        _REGISTER_ERROR = str(exc)
        _REGISTERED_DIRECT_PROPERTIES = False
        # These controls are optional. Do not block extension installation.
        return


def unregister() -> None:
    global _REGISTER_ERROR, _REGISTERED_DIRECT_PROPERTIES
    for name in (_PROPERTY_NAME,) + _RUNTIME_PROPERTY_NAMES:
        try:
            delattr(bpy.types.WindowManager, name)
        except Exception:
            pass
    _REGISTER_ERROR = ""
    _REGISTERED_DIRECT_PROPERTIES = False
