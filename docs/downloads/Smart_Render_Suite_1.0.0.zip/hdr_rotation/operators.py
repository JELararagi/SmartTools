# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
'''Rotate the lighting under the pointer using the Blender viewport and shader APIs.'''

from math import radians, remainder, tau

import bpy
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d

from ..rna_safety import safe_register_class, safe_unregister_class
from ..translation import localize_pair


def _matching_socket(sockets, identifier):
    return next((item for item in sockets if item.identifier == identifier), None)


def _source_sockets(inputs, groups=()):
    pending = [(socket, groups) for socket in inputs]
    visited = set()
    while pending:
        incoming, stack = pending.pop()
        for link in incoming.links:
            if link.is_muted:
                continue
            source = link.from_socket
            key = source.as_pointer(), tuple(group.as_pointer() for group in stack)
            if key in visited:
                continue
            visited.add(key)
            node = source.node
            yield source, stack
            if node.type == 'GROUP' and node.node_tree is not None:
                for output in node.node_tree.nodes:
                    if output.type == 'GROUP_OUTPUT' and output.is_active_output:
                        inside = _matching_socket(output.inputs, source.identifier)
                        if inside is not None:
                            pending.append((inside, stack + (node,)))
            elif node.type == 'GROUP_INPUT' and stack:
                outside = _matching_socket(stack[-1].inputs, source.identifier)
                if outside is not None:
                    pending.append((outside, stack[:-1]))
            else:
                pending.extend((socket, stack) for socket in node.inputs)


def _editable_rotation(socket, vector):
    if socket is None or socket.is_linked or getattr(socket, 'hide_value', False):
        return False
    value = getattr(socket, 'default_value', None)
    if vector:
        return hasattr(value, '__len__') and len(value) == 3
    return isinstance(value, (float, int))


def _world_rotations(tree):
    if tree is None:
        return
    rotation_names = {'Rotation', 'HDR Rotation', 'Z Rotation', 'HDR旋转', 'Z旋转'}
    active_outputs = (node for node in tree.nodes if
                      node.type == 'OUTPUT_WORLD' and node.is_active_output)
    for source, groups in _source_sockets(socket for node in active_outputs for socket in node.inputs):
        environment = source.node
        if environment.type != 'TEX_ENVIRONMENT':
            continue
        vector = environment.inputs['Vector']
        for driver, path in _source_sockets((vector,), groups):
            node = driver.node
            if node.type == 'MAPPING':
                rotation = node.inputs.get('Rotation')
                if _editable_rotation(rotation, vector=True):
                    yield rotation, True
            elif node.type == 'GROUP_INPUT' and path:
                exposed = _matching_socket(path[-1].inputs, driver.identifier)
                if exposed is None or exposed.name not in rotation_names:
                    continue
                is_vector = exposed.type == 'VECTOR'
                if _editable_rotation(exposed, vector=is_vector):
                    yield exposed, is_vector


def _hits_object(context, event):
    region = context.region
    if region is None or region.type != 'WINDOW':
        return False
    coords = (event.mouse_region_x, event.mouse_region_y)
    if not (0 <= coords[0] < region.width and 0 <= coords[1] < region.height):
        return False
    space = context.space_data
    direction = region_2d_to_vector_3d(region, space.region_3d, coords)
    origin = region_2d_to_origin_3d(region, space.region_3d, coords, clamp=space.clip_end)
    hit, _, _, _, _, _ = context.scene.ray_cast(
        context.evaluated_depsgraph_get(), origin, direction, distance=space.clip_end,
    )
    return hit


class HdrRotationOperator(bpy.types.Operator):
    bl_idname = 'hdr.rotate_hdri'
    bl_label = 'Rotate HDRI'
    bl_description = 'Drag horizontally to rotate the viewport or scene environment lighting'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space is not None and space.type == 'VIEW_3D' and space.shading.type in {'MATERIAL', 'RENDERED'}

    def invoke(self, context, event):
        if _hits_object(context, event):
            return {'PASS_THROUGH'}
        self._start_x = event.mouse_x
        self._window = context.window
        self._area = context.area
        self._shading = context.space_data.shading
        self._controls = []
        rendered = self._shading.type == 'RENDERED'
        self._scene_lighting = self._shading.use_scene_world_render if rendered else self._shading.use_scene_world
        if self._scene_lighting:
            world = context.scene.world
            targets = _world_rotations(world.node_tree if world and world.use_nodes else None)
            seen = set()
            for socket, vector in targets:
                key = socket.as_pointer()
                if key in seen:
                    continue
                seen.add(key)
                initial = socket.default_value[2] if vector else socket.default_value
                self._controls.append((socket, vector, initial))
            if not self._controls:
                self.report({'WARNING'}, localize_pair(
                    'ワールド環境に編集できる回転入力がありません。',
                    'The world environment has no editable rotation input.',
                ))
                return {'CANCELLED', 'PASS_THROUGH'}
        else:
            self._initial_angle = self._shading.studiolight_rotate_z
        context.window_manager.modal_handler_add(self)
        self._window.cursor_modal_set('MOVE_X')
        self._area.header_text_set(localize_pair(
            'HDRI 回転  |  ドラッグで回転、離して確定、Esc で戻す',
            'HDRI Rotation  |  Drag to rotate, release to confirm, Esc to restore',
        ))
        return {'RUNNING_MODAL'}

    def _set_angles(self, delta):
        def value(initial):
            return initial if delta is None else remainder(initial + delta, tau)
        if self._scene_lighting:
            for socket, vector, initial in self._controls:
                if vector:
                    socket.default_value[2] = value(initial)
                else:
                    socket.default_value = value(initial)
        else:
            self._shading.studiolight_rotate_z = value(self._initial_angle)

    def _close(self):
        self._window.cursor_modal_restore()
        self._area.header_text_set(None)

    def modal(self, context, event):
        if event.type == 'ESC':
            self.cancel(context)
            return {'CANCELLED'}
        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'RELEASE':
            self._close()
            return {'FINISHED'}
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            self._set_angles(radians((event.mouse_x - self._start_x) / 10))
        return {'RUNNING_MODAL'}

    def cancel(self, _context):
        try:
            self._set_angles(None)
        finally:
            self._close()


def register():
    safe_register_class(HdrRotationOperator)


def unregister():
    safe_unregister_class(HdrRotationOperator)
