(() => {
  "use strict";

  const find = (id) => document.getElementById(id);
  const all = (selector) => Array.from(document.querySelectorAll(selector));
  const modeButtons = all(".mode-btn");
  const switches = all(".report-tab");
  const panes = all(".tab-pane");
  const timeBlock = find("last-update-block");
  const error = find("report-error");
  const errorText = error?.querySelector(".report-error-text");

  const panesByState = {
    modifiers: "modifiers_html",
    heavy: "heavy_meshes_html",
    memory: "memory_html",
    textures: "textures_html",
    statistics: "statistics_html"
  };
  const emptyMessage = new Map([
    ["off", '<p class="report-message">Profiler is disabled.</p>'],
    ["viewport", '<p class="report-message">Profiler is in viewport mode. It will get data on any scene update.</p>'],
    ["render", '<p class="report-message">Profiler is in render mode. To get data, render the scene.</p>']
  ]);
  const disconnected = "Failed to update. The connection to Blender was lost — Blender may have been closed. This page will retry when Blender is running again with the add-on enabled.";
  const contextFields = [
    ["file_name", find("context-file-name")],
    ["scene_name", find("context-scene-name")],
    ["view_layer_name", find("context-view-layer-name")]
  ];
  const durations = [
    [604800, null, " weeks ago"],
    [86400, "1 day ago", " days ago"],
    [3600, "1 hour ago", " hours ago"],
    [60, "1 minute ago", " minutes ago"],
    [1, null, " seconds ago"]
  ];
  const htmlCache = new WeakMap();
  let readsBusy = false;
  let writeCount = 0;
  let writeQueue = Promise.resolve();
  let revision = 0;

  function updateHTML(element, markup) {
    if (element && htmlCache.get(element) !== markup) {
      element.innerHTML = markup;
      htmlCache.set(element, markup);
    }
  }

  function selectMode(mode) {
    for (const button of modeButtons) {
      button.classList.toggle("active", button.dataset.mode === mode);
    }
  }

  function selectTab(tab) {
    for (const button of switches) {
      button.classList.toggle("active", button.dataset.tab === tab);
    }
    for (const pane of panes) {
      pane.style.display = pane.dataset.tab === tab ? "block" : "none";
    }
  }

  function showConnection(connected) {
    if (!connected && errorText) {
      errorText.textContent = disconnected;
    }
    error?.classList.toggle("visible", !connected);
  }

  function describeTime(stamp) {
    if (stamp === 0) return "waiting for update…";
    const elapsed = Math.floor(Date.now() / 1000 - stamp);
    if (elapsed < 1) return "just now";
    for (const [size, singular, suffix] of durations) {
      if (elapsed >= size) {
        const count = Math.floor(elapsed / size);
        return count === 1 && singular ? singular : count + suffix;
      }
    }
    return "";
  }

  function applySnapshot(state) {
    if (!(state.mode || state.modifiers_html || state.title)) return;
    const mode = emptyMessage.has(state.mode) ? state.mode : "viewport";
    const showResults = mode !== "off" && Boolean(state.modifiers_html);
    selectMode(mode);
    for (const pane of panes) {
      const field = panesByState[pane.dataset.tab];
      updateHTML(pane, showResults ? state[field] || "" : emptyMessage.get(mode));
    }
    updateHTML(timeBlock, showResults ? state.last_update_html || "" : "");
    if (state.title !== undefined) document.title = state.title;
    for (const [field, element] of contextFields) {
      if (element && state[field] !== undefined) element.textContent = state[field];
    }
    if (state.last_update_time != null) {
      const relative = describeTime(state.last_update_time);
      for (const stamp of all(".last-update-ago")) stamp.textContent = relative;
    }
  }

  async function poll() {
    if (readsBusy || writeCount > 0) return;
    readsBusy = true;
    const requestRevision = revision;
    try {
      const response = await fetch("/state.json", { cache: "no-store" });
      if (!response.ok) throw new Error("Server error");
      const snapshot = await response.json();
      if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) {
        throw new Error("Server error");
      }
      if (requestRevision === revision) {
        applySnapshot(snapshot);
        showConnection(true);
      }
    } catch {
      if (requestRevision === revision) showConnection(false);
    } finally {
      readsBusy = false;
    }
  }

  function requestMode(mode) {
    const order = ++revision;
    writeCount++;
    writeQueue = writeQueue.then(async () => {
      try {
        const response = await fetch("/mode", {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({ mode }).toString()
        });
        if (!response.ok) throw new Error("Server error");
        if (order === revision) {
          selectMode(mode);
          for (const pane of panes) updateHTML(pane, "");
          showConnection(true);
        }
      } catch {
        if (order === revision) showConnection(false);
      } finally {
        writeCount--;
      }
    });
  }

  for (const button of modeButtons) {
    if (emptyMessage.has(button.dataset.mode)) {
      button.addEventListener("click", () => requestMode(button.dataset.mode));
    }
  }
  for (const button of switches) {
    button.addEventListener("click", () => selectTab(button.dataset.tab));
  }

  const warning = find("report-warning");
  const dismiss = warning?.querySelector(".report-warning-close");
  const warningKey = "reportWarningDismissed";
  const dismissedClass = "report-warning-dismissed";
  if (dismiss) {
    try {
      if (localStorage.getItem(warningKey) === "1") warning.classList.add(dismissedClass);
    } catch {
      // A blocked storage area does not prevent dismissal for this visit.
    }
    dismiss.addEventListener("click", () => {
      warning.classList.add(dismissedClass);
      try {
        localStorage.setItem(warningKey, "1");
      } catch {
        // The hidden state is still applied to the current document.
      }
    });
  }

  selectTab("modifiers");
  setInterval(poll, __POLL_INTERVAL_MS__);
  poll();
})();

