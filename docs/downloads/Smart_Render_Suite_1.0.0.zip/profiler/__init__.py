# SPDX-License-Identifier: GPL-3.0-or-later
"""Integrated entry point for Smart Render's performance report."""

from . import handlers, operators, preferences, properties, server_controller, ui


bl_info = {
    "name": "Render Profiler",
    "author": "JELararagi",
    "version": (0, 9, 4),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Measure scene and viewport performance in a live report",
    "category": "Render",
}

_services = (properties, operators, ui, handlers, preferences)
_registered = []


def register():
    if _registered:
        return
    try:
        for service in _services:
            service.register()
            _registered.append(service)
    except Exception:
        unregister()
        raise


def unregister():
    try:
        server_controller.stop_report_server()
    finally:
        errors = []
        while _registered:
            service = _registered.pop()
            try:
                service.unregister()
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise ExceptionGroup("Render Profiler could not fully unregister", errors)
