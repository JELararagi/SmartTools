# SPDX-License-Identifier: GPL-3.0-or-later
"""Retire the former menu hooks now that Smart Render owns the profiler entry."""

import bpy


_HOOKS = {
    "TOPBAR_MT_window": "_draw_window_menu_item",
    "TOPBAR_MT_file_context_menu": "_draw_window_menu_item",
    "TOPBAR_HT_upper_bar": "_draw_topbar_profiler",
}


def _remove_legacy(owner_name):
    owner = getattr(bpy.types, owner_name, None)
    draw = getattr(owner, "draw", None)
    for callback in tuple(getattr(draw, "_draw_funcs", ())):
        if (getattr(callback, "__module__", None) == __name__
                and getattr(callback, "__name__", None) == _HOOKS[owner_name]):
            try:
                owner.remove(callback)
            except ValueError:
                continue


def sync_runtime_ui(force=False):
    _remove_legacy("TOPBAR_HT_upper_bar")


def register():
    for owner_name in _HOOKS:
        _remove_legacy(owner_name)


def unregister():
    register()
