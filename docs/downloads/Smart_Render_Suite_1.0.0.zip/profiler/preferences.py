# SPDX-License-Identifier: GPL-3.0-or-later
"""Controls and defaults shared by the Blender and report interfaces."""

import bpy

from ..translation import localize_inline


def _settings(context):
    manager = getattr(context, "window_manager", None)
    return getattr(manager, "profiler", None)


def get_report_font_size():
    return int(getattr(_settings(bpy.context), "font_size", 14))


def draw_runtime_settings(layout, context):
    settings = _settings(context)
    if settings is None:
        layout.label(text=localize_inline("Render Profiler settings are not available yet."),
                     icon="ERROR", translate=False)
        return
    controls = layout.box()
    controls.label(text=localize_inline("Live Profiler Controls"), icon="PREFERENCES")
    controls.prop(settings, "font_size")
    actions = controls.row(align=True)
    actions.operator("profiler.open_report_in_browser", text=localize_inline("Open Report"), icon="WINDOW")
    actions.operator("profiler.stop_profiling", text=localize_inline("Stop"), icon="PANEL_CLOSE")


def register():
    """Runtime settings are registered with the Profiler RNA."""


def unregister():
    """Runtime settings are removed with the Profiler RNA."""
