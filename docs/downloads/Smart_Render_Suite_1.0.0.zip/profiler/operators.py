# SPDX-License-Identifier: GPL-3.0-or-later
"""Public Blender commands for opening and stopping a performance report."""

from bpy.types import Operator

from ..rna_safety import safe_register_class, safe_unregister_class
from ..translation import iface_text
from . import properties
from .server_controller import get_report_state, init_report_server, open_live_report_in_browser, set_report_state
from .utils import build_html_report


_REPORT_CONTENT = ("modifiers", "heavy_meshes", "textures", "statistics", "memory", "last_update")


class RENDER_PROFILER_OT_open_report(Operator):
    """Collect the current scene and open its live viewport report."""

    bl_idname = "profiler.open_report_in_browser"
    bl_label = "Open Report in Browser"
    bl_options = {"UNDO"}

    def execute(self, context):
        settings = context.window_manager.profiler
        settings.report_mode = properties.REPORT_MODE_VIEWPORT
        init_report_server()
        build_html_report(context.evaluated_depsgraph_get(), context.scene, mode="viewport")
        report = get_report_state()
        report["title"] = "Render Profiler Report"
        set_report_state(report)
        url = open_live_report_in_browser()
        if url:
            self.report({"INFO"}, iface_text(f"Report opened: {url}"))
            return {"FINISHED"}
        settings.report_mode = properties.REPORT_MODE_OFF
        self.report({"ERROR"}, iface_text("Could not start report server (ports in use?)"))
        return {"CANCELLED"}


class RENDER_PROFILER_OT_stop_profiling(Operator):
    """Disable profiling and clear the displayed live metrics."""

    bl_idname = "profiler.stop_profiling"
    bl_label = "Stop Profiling"
    bl_options = {"UNDO"}

    def execute(self, context):
        context.window_manager.profiler.report_mode = properties.REPORT_MODE_OFF
        state = get_report_state()
        state.update({f"{section}_html": "" for section in _REPORT_CONTENT})
        state["mode"] = "off"
        set_report_state(state)
        self.report({"INFO"}, iface_text("Profiling stopped."))
        return {"FINISHED"}


classes = (RENDER_PROFILER_OT_open_report, RENDER_PROFILER_OT_stop_profiling)


def register():
    for cls in classes:
        safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        safe_unregister_class(cls)
