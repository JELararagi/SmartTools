# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from ..translation import iface_text, localize_pair
bl_info = {
    "name": 'Three-Point Lighting',
    "author": "JELararagi",
    "version": (0, 2, 1),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Create a controllable three-point lighting setup from the Smart Render N-panel workflow.",
    "category": "Lighting",
}

import bpy
from ..rna_safety import (
        register_pointer_property,
        remove_rna_property,
        safe_register_class,
        safe_unregister_class,
        )
from bpy.types import Operator, PropertyGroup
from mathutils import Vector
from bpy.props import (
        EnumProperty,
        FloatProperty,
        IntProperty,
        StringProperty,
        )
from math import (
        sin, cos,
        radians,
        )


def _view_camera(context):
    view = getattr(context, 'space_data', None)
    if view is not None and view.type == 'VIEW_3D' and view.use_local_camera:
        return view.camera
    return context.scene.camera


def _front_direction(obj_position, camera):
    """Unit XY direction from the object toward the viewer.

    The lights are laid out on a horizontal circle, so only the XY part of the
    camera offset counts.  A camera at the object or straight above it has no
    horizontal direction; the object is then lit as if viewed from the front (-Y).
    """
    if camera:
        delta = camera.location - obj_position
        flat = Vector((delta.x, delta.y))
        if flat.length > 1e-6:
            return flat.normalized()
    return Vector((0.0, -1.0))


def _rotated(direction, angle_degrees):
    angle = radians(angle_degrees)
    return Vector((
        cos(angle) * direction.x - sin(angle) * direction.y,
        sin(angle) * direction.x + cos(angle) * direction.y,
    ))


def _energies(settings):
    """Return the (key, fill + back) energies. Contrast 0 makes the lights equal."""
    weaker = settings.energy * (100 - abs(settings.contrast)) / 100
    if settings.contrast >= 0:
        return settings.energy, weaker
    return weaker, settings.energy


def _apply_key_light(lamp, settings):
    lamp.data.type = settings.primarytype
    data = lamp.data
    if settings.primarytype == 'AREA':
        data.shape = settings.key_light_shape
        if settings.key_light_shape in {'RECTANGLE', 'ELLIPSE'}:
            data.size = settings.key_light_size_x
            data.size_y = settings.key_light_size_y
        else:
            data.size = settings.key_light_size
    if settings.primarytype == 'SPOT':
        data.spot_size = settings.spot_size_key
        data.spot_blend = settings.spot_blend_key
    if settings.primarytype in {'POINT', 'SPOT'}:
        data.shadow_soft_size = settings.shadow_soft_size_key


def _apply_secondary_light(lamp, settings):
    lamp.data.type = settings.secondarytype
    data = lamp.data
    if settings.secondarytype == 'AREA':
        data.shape = settings.secondary_light_shape
        if settings.secondary_light_shape in {'RECTANGLE', 'ELLIPSE'}:
            data.size = settings.secondary_light_size_x
            data.size_y = settings.secondary_light_size_y
        else:
            data.size = settings.secondary_light_size
    if settings.secondarytype == 'SPOT':
        data.spot_size = settings.spot_size_fill
        data.spot_blend = settings.spot_blend_fill
    if settings.secondarytype in {'POINT', 'SPOT'}:
        data.shadow_soft_size = settings.shadow_soft_size_fill


def _rig_light(settings, name):
    """Return a light made by the last Create while it is still in this scene.

    The lights are remembered by name: a pointer would count as a user and keep
    deleted lights and objects in the file.
    """
    lamp = bpy.data.objects.get(name) if name else None
    if lamp is None or lamp.type != 'LIGHT' or settings.id_data not in lamp.users_scene:
        return None
    return lamp


def _rig_target(lamp, settings):
    for constraint in lamp.constraints:
        if constraint.type == 'TRACK_TO':
            target = constraint.target
            if target is not None and settings.id_data in target.users_scene:
                return target
    return None


def _place_light(settings, context, name, angle):
    """Move a light on the horizontal circle around its object; its height stays."""
    lamp = _rig_light(settings, name)
    target = _rig_target(lamp, settings) if lamp is not None else None
    if target is None:
        return
    front = _front_direction(target.location, _view_camera(context))
    offset = _rotated(front, angle) * settings.distance
    lamp.location.x = target.location.x + offset.x
    lamp.location.y = target.location.y + offset.y


def _place_key(settings, context):
    _place_light(settings, context, settings.key_light_name, -settings.leftangle)


def _place_fill(settings, context):
    _place_light(settings, context, settings.fill_light_name, settings.rightangle)


def _place_back(settings, context):
    _place_light(settings, context, settings.back_light_name, settings.backangle)


def _apply_energies(settings):
    key_energy, secondary_energy = _energies(settings)
    for name, energy in (
        (settings.key_light_name, key_energy),
        (settings.fill_light_name, secondary_energy),
        (settings.back_light_name, secondary_energy),
    ):
        lamp = _rig_light(settings, name)
        if lamp is not None:
            lamp.data.energy = energy


def _apply_height(settings):
    for name in (settings.key_light_name, settings.fill_light_name, settings.back_light_name):
        lamp = _rig_light(settings, name)
        if lamp is not None:
            lamp.location.z = settings.height


def _apply_key_settings(settings):
    lamp = _rig_light(settings, settings.key_light_name)
    if lamp is not None:
        _apply_key_light(lamp, settings)


def _apply_secondary_settings(settings):
    for name in (settings.fill_light_name, settings.back_light_name):
        lamp = _rig_light(settings, name)
        if lamp is not None:
            _apply_secondary_light(lamp, settings)


# Each setting writes only what it is about, so changing the power does not undo
# a light moved by hand, and changing a size does not reset the power.
def _height_changed(self, _context):
    _apply_height(self)


def _distance_changed(self, context):
    _place_key(self, context)
    _place_fill(self, context)
    _place_back(self, context)


def _place_key_changed(self, context):
    _place_key(self, context)


def _place_fill_changed(self, context):
    _place_fill(self, context)


def _place_back_changed(self, context):
    _place_back(self, context)


def _energy_changed(self, _context):
    _apply_energies(self)


def _key_changed(self, _context):
    _apply_key_settings(self)


def _secondary_changed(self, _context):
    _apply_secondary_settings(self)


class SRR_TriLightingSettings(PropertyGroup):
    height: FloatProperty(
        name="Height",
        description="Height of the lights above the world origin",
        subtype="DISTANCE",
        default=5,
        update=_height_changed,
    )
    distance: FloatProperty(
        name="Distance",
        description="Horizontal distance from the object to the lights",
        subtype="DISTANCE",
        min=0.1,
        default=5,
        update=_distance_changed,
    )
    energy: IntProperty(
        name="Base Energy",
        description="Power of the brightest light",
        subtype='POWER',
        min=1,
        default=100,
        update=_energy_changed,
    )
    contrast: IntProperty(
        name="Contrast",
        description="Difference in brightness between the lights in percent. 0 makes them equal, positive dims Fill and Back, negative dims Key",
        subtype="PERCENTAGE",
        min=-100, max=100,
        default=50,
        update=_energy_changed,
    )
    leftangle: IntProperty(
        name="Left Angle",
        description="Angle of the Key light from the camera direction",
        subtype="ANGLE",
        min=1, max=90,
        default=26,
        update=_place_key_changed,
    )
    rightangle: IntProperty(
        name="Right Angle",
        description="Angle of the Fill light from the camera direction",
        subtype="ANGLE",
        min=1, max=90,
        default=45,
        update=_place_fill_changed,
    )
    backangle: IntProperty(
        name="Back Angle",
        description="Angle of the Back light from the camera direction",
        subtype="ANGLE",
        min=90, max=270,
        default=235,
        update=_place_back_changed,
    )

    # Light Type
    Light_Type_List = [
        ('POINT', "Point", "Point Light"),
        ('SUN', "Sun", "Sun Light"),
        ('SPOT', "Spot", "Spot Light"),
        ('AREA', "Area", "Area Light")
    ]
    primarytype: EnumProperty(
        name="Key Type",
        description="Type of the Key light",
        items=Light_Type_List,
        default='AREA',
        update=_key_changed,
    )
    secondarytype: EnumProperty(
        name="Fill + Back Type",
        description="Type of the Fill and Back lights",
        items=Light_Type_List,
        default="AREA",
        update=_secondary_changed,
    )

    # Light Shape
    Light_Shape_List = [
        ('SQUARE', "Square", "Square Light"),
        ('RECTANGLE', "Rectangle", "Rectangular Light"),
        ('DISK', "Disk", "Disk Light"),
        ('ELLIPSE', "Ellipse", "Elliptical Light")
    ]
    key_light_shape: EnumProperty(
        name="Key Light Shape",
        description="Shape of the Key light",
        items=Light_Shape_List,
        default='SQUARE',
        update=_key_changed,
    )
    secondary_light_shape: EnumProperty(
        name="Fill + Back Light Shape",
        description="Shape of the Fill and Back lights",
        items=Light_Shape_List,
        default='SQUARE',
        update=_secondary_changed,
    )

    # Light Properties
    # Key Light Size (Single size for SQUARE and DISK)
    key_light_size: FloatProperty(
        name="Key Light Size",
        description="Size of the Key light",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_key_changed,
    )

    # Fill + Back Light Size (Single size for SQUARE and DISK)
    secondary_light_size: FloatProperty(
        name="Fill + Back Light Size",
        description="Size of the Fill and Back lights",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_secondary_changed,
    )

    # Key Light Size (Separate X and Y for RECTANGLE and ELLIPSE)
    key_light_size_x: FloatProperty(
        name="Key Light Size X",
        description="Width of the Key light",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_key_changed,
    )

    key_light_size_y: FloatProperty(
        name="Key Light Size Y",
        description="Length of the Key light",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_key_changed,
    )

    # Fill + Back Light Size (Separate X and Y for RECTANGLE and ELLIPSE)
    secondary_light_size_x: FloatProperty(
        name="Fill + Back Light Size X",
        description="Width of the Fill and Back lights",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_secondary_changed,
    )

    secondary_light_size_y: FloatProperty(
        name="Fill + Back Light Size Y",
        description="Length of the Fill and Back lights",
        subtype='DISTANCE',
        min=0,
        default=1,
        update=_secondary_changed,
    )

    # Shadow Soft Size
    shadow_soft_size_key: FloatProperty(
        name="Key Light Shadow Soft Size",
        description="Radius of the Key light. A larger radius makes softer shadows",
        subtype='DISTANCE',
        default=0.0,
        min=0.0,
        update=_key_changed,
    )

    shadow_soft_size_fill: FloatProperty(
        name="Fill + Back Light Shadow Soft Size",
        description="Radius of the Fill and Back lights. A larger radius makes softer shadows",
        subtype='DISTANCE',
        default=0.0,
        min=0.0,
        update=_secondary_changed,
    )

    # Spot Light Size and Blend
    spot_size_key: FloatProperty(
        name="Key Spot Light Size",
        description="Cone angle of the Key spot light",
        subtype='ANGLE',
        min=0, max=3.14,
        default=0.7853982,
        update=_key_changed,
    )

    spot_blend_key: FloatProperty(
        name="Key Spot Light Blend",
        description="Softness of the edge of the Key spot light",
        min=0.0, max=1.0,
        default=0.150,
        update=_key_changed,
    )

    spot_size_fill: FloatProperty(
        name="Fill + Back Spot Light Size",
        description="Cone angle of the Fill and Back spot lights",
        subtype='ANGLE',
        min=0, max=3.14,
        default=0.7853982,
        update=_secondary_changed,
    )

    spot_blend_fill: FloatProperty(
        name="Fill + Back Spot Light Blend",
        description="Softness of the edge of the Fill and Back spot lights",
        min=0.0, max=1.0,
        default=0.150,
        update=_secondary_changed,
    )

    # The lights made by the last Create; the settings above keep driving them.
    key_light_name: StringProperty(description="", options={'HIDDEN'})
    fill_light_name: StringProperty(description="", options={'HIDDEN'})
    back_light_name: StringProperty(description="", options={'HIDDEN'})


def draw_runtime_settings(layout, context):
    settings = context.scene.srr_tri_lighting
    layout.use_property_split = True
    layout.use_property_decorate = False

    col = layout.column(align=True)
    col.prop(settings, "height", text=iface_text("Height"))
    col.prop(settings, "distance", text=iface_text("Distance"))
    layout.separator()

    col = layout.column(align=True)
    col.prop(settings, "energy", text=iface_text("Base Energy"))
    col.prop(settings, "contrast", text=iface_text("Contrast"))
    layout.separator()

    col = layout.column(align=True)
    col.prop(settings, "leftangle", text=iface_text("Left Angle"))
    col.prop(settings, "rightangle", text=iface_text("Right Angle"))
    col.prop(settings, "backangle", text=iface_text("Back Angle"))
    layout.separator()

    # Key Light Properties
    header, panel = layout.panel("srr_tri_lighting_key", default_closed=False)
    header.label(text=iface_text("Key Light"))

    if panel:
        col = panel.column()
        col.prop(settings, "primarytype", text=iface_text("Type"))

        # Area Light Shape & Size
        if settings.primarytype == 'AREA':
            col.prop(settings, "key_light_shape", text=iface_text("Shape"))

            col = panel.column(align=True)
            if settings.key_light_shape in {'SQUARE', 'DISK'}:
                col.prop(settings, "key_light_size", text=iface_text("Size"))
            elif settings.key_light_shape in {'RECTANGLE', 'ELLIPSE'}:
                col.prop(settings, "key_light_size_x", text=iface_text("Size X"))
                col.prop(settings, "key_light_size_y", text=iface_text("Size Y"))

        # Radius
        if settings.primarytype in {'POINT', 'SPOT'}:
            col.prop(settings, "shadow_soft_size_key", text=iface_text("Radius"))

        # Spot Light
        if settings.primarytype == 'SPOT':
            col.prop(settings, "spot_size_key", text=iface_text("Spot Size"))
            col.prop(settings, "spot_blend_key", text=iface_text("Blend"), slider=True)


    # Fill + Back Light Properties
    header, panel = layout.panel("srr_tri_lighting_fill_back", default_closed=False)
    header.label(text=iface_text("Fill & Back Light"))

    if panel:
        col = panel.column()
        col.prop(settings, "secondarytype", text=iface_text("Type"))

        # Area Light Shape & Size
        if settings.secondarytype == 'AREA':
            col.prop(settings, "secondary_light_shape", text=iface_text("Shape"))

            col = panel.column(align=True)
            if settings.secondary_light_shape in {'SQUARE', 'DISK'}:
                col.prop(settings, "secondary_light_size", text=iface_text("Size"))
            elif settings.secondary_light_shape in {'RECTANGLE', 'ELLIPSE'}:
                row = col.row()
                row.prop(settings, "secondary_light_size_x", text=iface_text("Size X"))
                row.prop(settings, "secondary_light_size_y", text=iface_text("Size Y"))

        # Radius
        if settings.secondarytype in {'POINT', 'SPOT'}:
            col.prop(settings, "shadow_soft_size_fill", text=iface_text("Radius"))

        # Spot Light
        if settings.secondarytype == 'SPOT':
            col.prop(settings, "spot_size_fill", text=iface_text("Spot Size"))
            col.prop(settings, "spot_blend_fill", text=iface_text("Blend"), slider=True)


class OBJECT_OT_TriLighting(Operator):
    bl_idname = "object.create_three_point_lighting"
    bl_label = "Create Three-Point Lighting"
    bl_description = ("Add 3 point lighting around selected object(s)")
    bl_options = {'UNDO'}
    COMPAT_ENGINES = {'CYCLES', 'EEVEE'}

    @classmethod
    def poll(cls, context):
        return getattr(context, 'active_object', None) is not None

    def execute(self, context):
        collection = context.collection
        settings = context.scene.srr_tri_lighting
        obj = bpy.context.view_layer.objects.active

        def new_lamp(name, light_type):
            data = bpy.data.lights.new(name=name, type=light_type)
            lamp = bpy.data.objects.new(name=name, object_data=data)
            collection.objects.link(lamp)
            track_to = lamp.constraints.new(type="TRACK_TO")
            track_to.target = obj
            track_to.track_axis = "TRACK_NEGATIVE_Z"
            track_to.up_axis = "UP_Y"
            return lamp

        back_lamp = new_lamp("TriLamp-Back", settings.secondarytype)
        fill_lamp = new_lamp("TriLamp-Fill", settings.secondarytype)
        key_lamp = new_lamp("TriLamp-Key", settings.primarytype)

        settings.back_light_name = back_lamp.name
        settings.fill_light_name = fill_lamp.name
        settings.key_light_name = key_lamp.name
        _apply_key_settings(settings)
        _apply_secondary_settings(settings)
        _apply_energies(settings)
        _place_key(settings, context)
        _place_fill(settings, context)
        _place_back(settings, context)
        _apply_height(settings)

        self.report({'INFO'}, localize_pair(
            "三点照明を作成しました。下の「設定」の値を変えると、このライトに反映されます。",
            "Three-point lighting created. Changing the Settings below updates these lights.",
        ))
        return {'FINISHED'}


# Menu
def menu_func(self, context):
    self.layout.operator(OBJECT_OT_TriLighting.bl_idname, icon='LIGHT')


def _unregister_external_light_add_menu() -> None:
    menu = getattr(getattr(bpy, 'types', None), 'VIEW3D_MT_light_add', None)
    remover = getattr(menu, 'remove', None)
    if not callable(remover):
        return
    for _ in range(8):
        try:
            remover(menu_func)
        except Exception:
            break


# Registration
def register():
    safe_register_class(SRR_TriLightingSettings)
    register_pointer_property(bpy.types.Scene, 'srr_tri_lighting', SRR_TriLightingSettings)
    safe_register_class(OBJECT_OT_TriLighting)
    # Integrated mode: keep the legacy Add > Light entry disabled so the
    # operator is launched only from the Smart Render N-panel.
    _unregister_external_light_add_menu()

def unregister():
    _unregister_external_light_add_menu()
    safe_unregister_class(OBJECT_OT_TriLighting)
    remove_rna_property(bpy.types.Scene, 'srr_tri_lighting')
    safe_unregister_class(SRR_TriLightingSettings)

if __name__ == "__main__":
    register()
