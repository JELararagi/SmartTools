# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Camera-relative placement for the three lights in a SmartRender rig."""

from math import atan2, cos, radians, sin


def light_xy(subject, camera, degrees, radius):
    """Return a world-space position on the horizontal circle about the subject."""
    azimuth = radians(-90)
    if camera is not None:
        dx, dy = camera.x - subject.x, camera.y - subject.y
        if dx * dx + dy * dy > 1e-12:
            azimuth = atan2(dy, dx)
    bearing = azimuth + radians(degrees)
    return subject.x + radius * cos(bearing), subject.y + radius * sin(bearing)
