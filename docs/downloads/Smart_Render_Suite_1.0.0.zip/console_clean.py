# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

# This module is intentionally defensive. It removes stale SmartTools keymap
# artifacts left by older builds and invalid empty tool-select shortcuts, but it
# never creates or clones Blender keymaps. It also never patches Panel.draw or
# other Blender UI drawing callbacks; standard N-panel panels must draw through
# Blender's normal API without runtime wrapping.

import sys
from typing import Iterable

import bpy

from .rna_safety import safe_register_class, safe_unregister_class

_INSTALLED = False
_LEGACY_OPERATOR_CLASSES: list[type] = []
_TIMER_TAGS: set[str] = set()

_STALE_EXTENSION_MODULES = (
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
)

_LEGACY_NPANEL_OPERATOR_IDS = (
    'wm.bl_ext_npanel_popup_menu',
    'wm.bl_ext_npanel_operator_enum_popup',
    'wm.bl_ext_npanel_call_menu_pie',
)

_STALE_OPERATOR_PREFIXES = (
    'wm.smart_tools_',
    'wm.smart_tools_window',
    'wm.smart_tools_browser',
    'wm.bl_ext_npanel_',
)

_COMPAT_PROP_NAMES = (
    'action', 'mode_to', 'mode', 'cut', 'reduce_mode', 'operator', 'operator_id',
    'menu', 'menu_id', 'pie', 'name', 'data_path', 'value', 'text', 'icon', 'addon_key',
)


def _addon_id() -> str:
    pkg = str(__package__ or __name__ or '').strip('.')
    parts = [p for p in pkg.split('.') if p]
    if 'user_default' in parts:
        idx = parts.index('user_default')
        if idx + 1 < len(parts):
            return parts[idx + 1]
    for part in reversed(parts):
        if part.startswith('smart_') and part.endswith('_suite'):
            return part
    return parts[-1] if parts else 'smart_tools'


def _suite_operator_prefixes() -> tuple[str, ...]:
    addon = _addon_id()
    base = addon[:-6] if addon.endswith('_suite') else addon
    return tuple(dict.fromkeys((
        addon + '.',
        base + '.',
        'wm.' + addon,
        'wm.' + base,
        'wm.' + addon.replace('_suite', '') + '_suite_',
    )))


def _iter_keyconfigs():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    except Exception:
        keyconfigs = None
    if keyconfigs is None:
        return ()
    out = []
    for name in ('user', 'addon', 'active', 'default'):
        try:
            kc = getattr(keyconfigs, name, None)
        except Exception:
            kc = None
        if kc is not None:
            out.append((name, kc))
    return tuple(out)


def _keymap_item_count(km) -> int:
    try:
        return len(getattr(km, 'keymap_items', ()) or ())
    except Exception:
        count = 0
        try:
            for _ in getattr(km, 'keymap_items', ()):
                count += 1
        except Exception:
            pass
        return count


def _kmi_signature(kmi):
    try:
        return (
            str(getattr(kmi, 'idname', '') or ''),
            str(getattr(kmi, 'type', '') or ''),
            str(getattr(kmi, 'value', '') or ''),
            bool(getattr(kmi, 'any', False)),
            bool(getattr(kmi, 'shift', False)),
            bool(getattr(kmi, 'ctrl', False)),
            bool(getattr(kmi, 'alt', False)),
            bool(getattr(kmi, 'oskey', False)),
            str(getattr(kmi, 'key_modifier', '') or ''),
        )
    except Exception:
        return None



def _tool_set_by_id_name(kmi) -> str:
    try:
        props = getattr(kmi, 'properties', None)
        return str(getattr(props, 'name', '') or '').strip()
    except Exception:
        return ''


def _remove_broken_tool_set_keymap_items() -> bool:
    """Remove invalid tool-select shortcuts left by older builds.

    Previous console-clean builds could clone Blender's User Interface keymap
    without preserving the ``wm.tool_set_by_id.name`` property.  Such a keymap
    item executes ``wm.tool_set_by_id(name='')`` and Blender reports:
    Tool '' is not in space 'VIEW_3D'.  Empty tool ids are never useful, so only
    those broken entries are removed.  No Blender default keymap is copied or
    recreated here.
    """
    changed = False
    for config_name, kc in _iter_keyconfigs():
        if config_name not in {'user', 'addon'}:
            continue
        try:
            maps = list(getattr(kc, 'keymaps', ()) or ())
        except Exception:
            maps = []
        for km in maps:
            try:
                items = list(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                items = []
            for kmi in items:
                try:
                    idname = str(getattr(kmi, 'idname', '') or '')
                except Exception:
                    idname = ''
                if idname != 'wm.tool_set_by_id':
                    continue
                if _tool_set_by_id_name(kmi):
                    continue
                try:
                    km.keymap_items.remove(kmi)
                    changed = True
                except Exception:
                    try:
                        kmi.active = False
                        changed = True
                    except Exception:
                        pass
    return changed


def _remove_empty_user_interface_keymaps() -> bool:
    changed = False
    for config_name, kc in _iter_keyconfigs():
        if config_name not in {'user', 'addon'}:
            continue
        try:
            maps = getattr(kc, 'keymaps', None)
            candidates = list(maps or ()) if maps is not None else []
        except Exception:
            maps = None
            candidates = []
        for km in candidates:
            try:
                if str(getattr(km, 'name', '') or '') != 'User Interface':
                    continue
            except Exception:
                continue
            if _keymap_item_count(km) <= 0:
                try:
                    maps.remove(km)
                    changed = True
                except Exception:
                    pass
    return changed


def _remove_empty_addon_user_interface_keymap() -> bool:
    # Compatibility alias for older wrapper calls.  Despite the old name, this
    # removes only empty keymaps and does not create or copy any keymap items.
    return _remove_empty_user_interface_keymaps()

def _kmi_should_remove(kmi, *, aggressive: bool = False) -> bool:
    try:
        idname = str(getattr(kmi, 'idname', '') or '')
    except Exception:
        idname = ''
    if not idname:
        return False
    if idname in _LEGACY_NPANEL_OPERATOR_IDS:
        return True
    if idname.startswith(_STALE_OPERATOR_PREFIXES):
        return True
    # User keymaps can keep stale shortcut entries for previous builds.  Removing
    # only package-owned entries avoids touching Blender defaults.
    if aggressive and any(idname.startswith(prefix) for prefix in _suite_operator_prefixes()):
        return True
    return False


def _remove_stale_keymap_items() -> bool:
    changed = False
    for config_name, kc in _iter_keyconfigs():
        aggressive = config_name == 'user'
        try:
            maps = list(getattr(kc, 'keymaps', ()) or ())
        except Exception:
            maps = []
        for km in maps:
            try:
                items = list(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                items = []
            for kmi in items:
                if not _kmi_should_remove(kmi, aggressive=aggressive):
                    continue
                try:
                    km.keymap_items.remove(kmi)
                    changed = True
                except Exception:
                    try:
                        kmi.active = False
                        changed = True
                    except Exception:
                        pass
            try:
                if str(getattr(km, 'name', '') or '') == 'User Interface' and _keymap_item_count(km) <= 0 and config_name == 'addon':
                    kc.keymaps.remove(km)
                    changed = True
            except Exception:
                pass
    return changed


def _purge_stale_addon_entries() -> bool:
    changed = False
    try:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        addons = getattr(prefs, 'addons', None) if prefs is not None else None
    except Exception:
        addons = None
    if addons is not None:
        for name in _STALE_EXTENSION_MODULES:
            entry = None
            try:
                entry = addons.get(name)
            except Exception:
                try:
                    entry = addons[name]
                except Exception:
                    entry = None
            if entry is not None:
                try:
                    addons.remove(entry)
                    changed = True
                except Exception:
                    pass
            try:
                sys.modules.pop(name, None)
            except Exception:
                pass
    return changed


def clean_keymaps_and_preferences(*, save: bool = True) -> bool:
    changed = False
    for fn in (_purge_stale_addon_entries, _remove_broken_tool_set_keymap_items, _remove_empty_user_interface_keymaps, _remove_stale_keymap_items):
        try:
            if fn():
                changed = True
        except Exception:
            pass
    if changed and save:
        _schedule_userpref_save()
    return changed


def _schedule_userpref_save() -> None:
    def _save_once():
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        return None
    try:
        bpy.app.timers.register(_save_once, first_interval=1.5)
    except Exception:
        pass


def _operator_registered(op_id: str) -> bool:
    try:
        namespace, name = str(op_id).split('.', 1)
        ops_ns = getattr(bpy.ops, namespace, None)
        op = getattr(ops_ns, name, None) if ops_ns is not None else None
        if op is None:
            return False
        op.get_rna_type()
        return True
    except Exception:
        return False


def _make_legacy_operator_class(class_name: str, bl_idname: str):
    return None


def register_legacy_operator_compatibility() -> None:
    return None


def _wrap_callable_returns_none(fn):
    # Kept only for compatibility with old callers.  The current build never
    # replaces Panel.draw/draw_header callables at runtime.
    return fn


def sanitize_panel_draws() -> int:
    # Runtime draw-method replacement is intentionally disabled.  Panel draw
    # methods remain the original methods registered by their classes.
    return 0

def _timer_install(tag: str, interval: float):
    # No recurring timers are installed.  Previous builds used timers to wrap
    # Panel.draw methods repeatedly, which is unsafe during UI redraw.
    del tag, interval
    return None


def install() -> None:
    global _INSTALLED
    # Do not scan or mutate global keymaps/preferences while the extension is
    # imported.  The explicit cleanup function remains available for a
    # user-invoked maintenance action.
    _INSTALLED = True

def uninstall() -> None:
    global _INSTALLED
    _INSTALLED = False
    return None
