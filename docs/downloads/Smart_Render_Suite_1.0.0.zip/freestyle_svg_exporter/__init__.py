# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
'''Settings and Blender registration for the SmartRender SVG output.'''

import bpy
from bpy.props import BoolProperty, EnumProperty

from ..help_operator import draw_help_button
from ..rna_safety import ensure_registered_class, register_pointer_property, unregister_existing_class
from ..translation import localize_pair as text
from . import export


def _changed(_settings, context):
    export.sync()
    from .. import settings
    if not settings.is_applying_context():
        settings.snapshot_context(context, force=False)


def _boolean(ja, en, description_ja, description_en, default=False, update=None):
    return BoolProperty(
        name=text(ja, en), description=text(description_ja, description_en),
        default=default, update=update,
    )


def _option(identifier, ja, en, description_ja, description_en, number):
    return identifier, text(ja, en), text(description_ja, description_en), number


class SVGExport(bpy.types.PropertyGroup):
    bl_idname = 'RENDER_PT_svg_export'

    auto_render_hooks: _boolean(
        'レンダー時SVGフック', 'Render-time SVG Hooks',
        'レンダー時の自動出力を有効にします。', 'Enable automatic SVG output during rendering.',
        update=_changed,
    )
    use_svg_export: _boolean('SVG書き出し', 'SVG Export', '線画をSVGで保存します。', 'Save the line drawing as SVG.')
    split_at_invisible: _boolean(
        '非表示部分で分割', 'Split at Invisible',
        '非表示の頂点をまたいで線をつなぎません。', 'Break paths across hidden vertices.',
    )
    object_fill: _boolean(
        '輪郭を塗りつぶす', 'Fill Contours',
        '閉じた輪郭を材質色で塗りつぶします。', 'Fill closed outlines with their material colors.',
    )
    mode: EnumProperty(
        name=text('モード', 'Mode'), items=(
            _option('FRAME','フレーム','Frame','各フレームを別ファイルに保存','Write individual frame files',0),
            _option('ANIMATION','アニメーション','Animation','連続フレームをひとつのSVGに保存','Write the sequence to a single SVG',1),
        ), default='FRAME',
    )
    line_join_type: EnumProperty(
        name=text('線の接合', 'Line Join'), items=(
            _option('MITER','角','Miter','尖った角','Sharp corner',0),
            _option('ROUND','丸','Round','丸い角','Rounded corner',1),
            _option('BEVEL','面取り','Bevel','切り落とした角','Beveled corner',2),
        ), default='ROUND',
    )


def _visible(context):
    scene = context.scene
    return bool(scene and scene.render.use_freestyle and hasattr(scene, 'svg_export'))


def _help(panel):
    draw_help_button(panel.layout, 'integrated:freestyle_svg_exporter')


class SVGExporterPanel(bpy.types.Panel):
    bl_idname = 'RENDER_PT_FREESTYLE_SVG_EXPORT'
    bl_label = 'Freestyle SVG Export'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'
    _srr_keep_popover_poll = True

    @classmethod
    def poll(cls, context):
        return _visible(context)

    def draw_header(self, context):
        self.layout.prop(context.scene.svg_export, 'use_svg_export', text='')

    def draw_header_preset(self, _context):
        _help(self)

    def draw(self, context):
        svg = context.scene.svg_export
        self.layout.active = svg.use_svg_export and context.view_layer.freestyle_settings.mode != 'SCRIPT'
        self.layout.prop(svg, 'mode', expand=True)
        self.layout.prop(svg, 'split_at_invisible')
        self.layout.prop(svg, 'object_fill')
        self.layout.prop(svg, 'line_join_type', expand=True)


class SVGExporterLinesetPanel(bpy.types.Panel):
    bl_idname = 'RENDER_PT_LINE_STYLE_SVG_EXPORT'
    bl_label = 'Line Style SVG Export'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'view_layer'
    _srr_keep_popover_poll = True

    @classmethod
    def poll(cls, context):
        return _visible(context)

    def draw_header_preset(self, _context):
        _help(self)

    def draw(self, context):
        layer = context.view_layer.freestyle_settings
        line = layer.linesets.active
        if line is None or line.linestyle is None:
            return
        svg = context.scene.svg_export
        self.layout.active = svg.use_svg_export and layer.mode != 'SCRIPT'
        style = line.linestyle
        self.layout.prop(style, 'use_export_strokes')
        row = self.layout.row()
        row.active = svg.object_fill
        row.prop(style, 'use_export_fills')
        self.layout.prop(style, 'stroke_color_mode', expand=True)


classes = (SVGExport, SVGExporterPanel, SVGExporterLinesetPanel)


def sync_runtime_hooks(_context=None, *, force_disable=False):
    export.sync(force_disable)


def register():
    style = bpy.types.FreestyleLineStyle
    style.use_export_strokes = _boolean(
        '線を書き出す','Export Strokes','このラインスタイルの線を保存します。','Save strokes of this line style.',True,
    )
    style.use_export_fills = _boolean(
        '塗りを書き出す','Export Fills','このラインスタイルの塗りを保存します。','Save fills of this line style.',
    )
    style.stroke_color_mode = EnumProperty(
        name=text('線の色','Stroke Color Mode'), items=(
            _option('BASE','基本色','Base Color','ラインスタイルの基本色','Line style base color',0),
            _option('FIRST','始点','First Vertex','始点の色','Color at the start of the stroke',1),
            _option('FINAL','終点','Final Vertex','終点の色','Color at the end of the stroke',2),
        ), default='BASE',
    )
    for cls in classes:
        ensure_registered_class(cls)
    register_pointer_property(bpy.types.Scene, 'svg_export', SVGExport)
    export.sync()


def unregister():
    export.sync(force_disable=True)
    if hasattr(bpy.types.Scene, 'svg_export'):
        del bpy.types.Scene.svg_export
    for name in ('use_export_strokes','use_export_fills','stroke_color_mode'):
        if hasattr(bpy.types.FreestyleLineStyle, name):
            delattr(bpy.types.FreestyleLineStyle, name)
    for cls in reversed(classes):
        unregister_existing_class(cls)
