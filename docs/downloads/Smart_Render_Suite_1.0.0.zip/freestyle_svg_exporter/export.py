# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
'''Publish Blender Freestyle strokes as SVG paths after each render frame.'''

from collections import defaultdict
from pathlib import Path
from tempfile import NamedTemporaryFile
import xml.etree.ElementTree as ET

import bpy
import parameter_editor
from bpy.app.handlers import persistent
from freestyle.functions import CurveMaterialF0D
from freestyle.predicates import (
    AndUP1D, ExternalContourUP1D, MaterialBP1D, OrUP1D,
    QuantitativeInvisibilityUP1D, TrueUP1D, pyNatureUP1D,
)
from freestyle.chainingiterators import ChainPredicateIterator
from freestyle.types import Interface0DIterator, Nature, Operators, StrokeShader

from ..compat import default_output_root, safe_name

SVG = 'http://www.w3.org/2000/svg'
INKSCAPE = 'http://www.inkscape.org/namespaces/inkscape'
ET.register_namespace('', SVG)
ET.register_namespace('inkscape', INKSCAPE)
_sessions = {}


def _element(parent, name, **attrs):
    return ET.SubElement(parent, f'{{{SVG}}}{name}', attrs)


def _rgb(color):
    return 'rgb(' + ', '.join(str(int(255 * min(1.0,max(0.0,c)))) for c in color[:3]) + ')'


def _point_list(vertices, height):
    return 'M ' + ' '.join(f'{p.point.x:.3f}, {height-p.point.y:.3f}' for p in vertices)


def _spans(vertices, split):
    if not split:
        if len(vertices) > 1:
            yield vertices
        return
    span = []
    for vertex in vertices:
        if vertex.attribute.visible:
            span.append(vertex)
        else:
            if len(span) > 1:
                yield span
            span = []
    if len(span) > 1:
        yield span


class Lines(StrokeShader):
    def __init__(self, group, style, options, height):
        super().__init__()
        self.group = group
        self.style = style
        self.options = options
        self.height = height

    def shade(self, stroke):
        vertices = list(stroke)
        if len(vertices) < 2:
            return
        style = self.style
        endpoint = vertices[-1] if style.stroke_color_mode == 'FINAL' else vertices[0]
        color = style.color if style.stroke_color_mode == 'BASE' else endpoint.attribute.color
        width = sum(endpoint.attribute.thickness)
        attrs = {
            'fill':'none', 'stroke':_rgb(color), 'stroke-width':str(width),
            'stroke-opacity':str(endpoint.attribute.alpha), 'stroke-linecap':style.caps.lower(),
            'stroke-linejoin':self.options.line_join_type.lower(),
        }
        if style.use_dashed_line:
            pattern = parameter_editor.get_dashed_pattern(style)
            if pattern:
                attrs['stroke-dasharray'] = ','.join(str(x) for x in pattern)
        for span in _spans(vertices, self.options.split_at_invisible):
            _element(self.group, 'path', d=_point_list(span, self.height), **attrs)


def _closed_rings(vertices):
    # Blender can continue chaining from the start of a closed silhouette
    # onto a junction. Keep the closed portion and discard open branches.
    walk = []
    offsets = {}
    for vertex in vertices:
        point = vertex.point
        key = (round(point.x, 3), round(point.y, 3))
        start = offsets.get(key)
        if start is None:
            offsets[key] = len(walk)
            walk.append((key, vertex))
            continue
        if len(walk) - start >= 3:
            yield [item[1] for item in walk[start:]]
        for visited, _ in walk[start+1:]:
            del offsets[visited]
        del walk[start+1:]


class Contours(StrokeShader):
    def __init__(self, height):
        super().__init__()
        self.height = height
        self.paths = defaultdict(list)

    def shade(self, stroke):
        vertices = list(stroke)
        if len(vertices) >= 3:
            material = CurveMaterialF0D()(Interface0DIterator(stroke))
            if material is not None:
                self.paths[_rgb(material.diffuse)].extend(
                    _point_list(ring, self.height) + ' Z' for ring in _closed_rings(vertices)
                )
        for vertex in vertices:
            vertex.attribute.visible = False


class Document:
    def __init__(self, scene):
        r = scene.render
        self.width = r.resolution_x*r.resolution_percentage//100
        self.height = r.resolution_y*r.resolution_percentage//100
        self.frames = {}
        self.groups = {}

    def layer(self, frame, layer, lineset):
        key = (frame, layer, lineset)
        group = self.groups.get(key)
        if group is None:
            frame_layers = self.frames.setdefault(frame, [])
            group = ET.Element(f'{{{SVG}}}g', {f'{{{INKSCAPE}}}label':f'{layer} / {lineset}'})
            frame_layers.append(group)
            self.groups[key] = group
        return group

    def write(self, scene):
        if not self.frames:
            return
        options = scene.svg_export
        animation = options.mode == 'ANIMATION'
        root = ET.Element(f'{{{SVG}}}svg',width=str(self.width),height=str(self.height),version='1.1',
                          viewBox=f'0 0 {self.width} {self.height}')
        selected = sorted(self.frames) if animation else [scene.frame_current]
        step = scene.frame_step
        fps = scene.render.fps/scene.render.fps_base
        for i, frame in enumerate(selected):
            layer = _element(root,'g', id=f'frame-{frame}')
            layer.extend(self.frames.get(frame, ()))
            if animation and len(selected) > 1:
                frame_count = len(selected)
                _element(layer, 'animate', attributeName='visibility', calcMode='discrete',
                         keyTimes=f'0;{1/frame_count:.9g}', values='visible;hidden',
                         begin=f'{i*step/fps:.9g}s', dur=f'{step*frame_count/fps:.9g}s',
                         repeatCount='indefinite')
                layer.set('visibility','visible' if i==0 else 'hidden')
        number = f'{scene.frame_start:04d}-{scene.frame_end:04d}' if animation else f'{scene.frame_current:04d}'
        basename = safe_name(bpy.path.basename(scene.render.filepath) or scene.name)
        folder = Path(default_output_root(create=True)) / 'freestyle_svg'
        folder.mkdir(exist_ok=True)
        destination = folder / f'{basename}{number}.svg'
        temporary = None
        try:
            with NamedTemporaryFile(dir=folder, prefix='.svg-', delete=False) as stream:
                temporary = Path(stream.name)
                ET.ElementTree(root).write(stream, encoding='utf-8', xml_declaration=True)
            temporary.replace(destination)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)


@persistent
def _start(scene):
    opts = getattr(scene,'svg_export',None)
    if opts and opts.use_svg_export and opts.auto_render_hooks and scene.render.use_freestyle:
        _sessions[scene.original.as_pointer()] = Document(scene)


@persistent
def _save_frame(scene):
    document = _sessions.get(scene.original.as_pointer())
    if document is not None and scene.svg_export.mode == 'FRAME':
        document.write(scene)
        document.frames.clear()
        document.groups.clear()


@persistent
def _finish(scene):
    document = _sessions.pop(scene.original.as_pointer(), None)
    if document is not None and scene.svg_export.mode == 'ANIMATION':
        document.write(scene)


@persistent
def _cancel(scene):
    _sessions.pop(scene.original.as_pointer(), None)


def _lines(scene, layer, lineset):
    document = _sessions.get(scene.original.as_pointer())
    style = lineset.linestyle
    if document is None or not style.use_export_strokes:
        return []
    group = document.layer(scene.frame_current,layer.name,lineset.name)
    return [Lines(group,style,scene.svg_export,document.height)]


def _fill(scene, layer, lineset):
    document = _sessions.get(scene.original.as_pointer())
    if document is None or not (scene.svg_export.object_fill and lineset.linestyle.use_export_fills):
        return
    contours = AndUP1D(QuantitativeInvisibilityUP1D(0),
                       OrUP1D(ExternalContourUP1D(),pyNatureUP1D(Nature.BORDER)))
    Operators.reset(delete_strokes=False)
    Operators.select(contours)
    Operators.bidirectional_chain(ChainPredicateIterator(contours,MaterialBP1D()))
    collector = Contours(document.height)
    Operators.create(TrueUP1D(),[collector])
    group = document.layer(scene.frame_current,layer.name,lineset.name)
    for color,paths in collector.paths.items():
        if not paths:
            continue
        group.insert(0,ET.Element(f'{{{SVG}}}path',{'d':' '.join(paths),'fill':color,'fill-rule':'evenodd','stroke':'none'}))


def sync(force_disable=False):
    enabled = not force_disable and any(
        getattr(getattr(scene,'svg_export',None),'auto_render_hooks',False) for scene in bpy.data.scenes
    )
    bindings = (
        (bpy.app.handlers.render_init, _start), (bpy.app.handlers.render_post, _save_frame),
        (bpy.app.handlers.render_complete, _finish), (bpy.app.handlers.render_cancel, _cancel),
        (parameter_editor.callbacks_modifiers_post,_lines),(parameter_editor.callbacks_lineset_post,_fill),
    )
    for sequence,callback in bindings:
        if enabled and callback not in sequence:
            sequence.append(callback)
        elif not enabled and callback in sequence:
            sequence.remove(callback)
    if not enabled:
        _sessions.clear()
