# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from typing import Any
import re
import sys

import bpy

from .translation import action_tooltip, localize_pair, source_text, t
from .tool_catalog import display_name as integrated_tool_display_name


_KNOWN_ALWAYS_ON_CONTROLS: tuple[dict[str, str], ...] = (
    {
        'alias': 'rendernames',
        'owner_key': 'scene.rendernames',
        'prop': 'enabled',
        'label_ja': 'レンダー命名フック',
        'label_en': 'Render Naming Hook',
        'description_ja': 'レンダー開始時だけテンプレートから出力パスを生成し、終了またはキャンセル後に元のパスへ戻す自動フックを有効化します。レンダー出力の命名で実際にレンダー出力名を差し替える時だけ有効にしてください。無効時はレンダーイベントハンドラーを登録しないため軽くなります。',
        'description_en': 'Enables the render-time hook that builds an output path from the template at render start and restores the original path after completion or cancel. Enable it only when Render Output Naming should actually replace render output names. When disabled, render event handlers are not registered.',
        'icon': 'FILE_REFRESH',
    },
    {
        'alias': 'freestyle_svg_exporter',
        'owner_key': 'scene.svg_export',
        'prop': 'auto_render_hooks',
        'label_ja': 'Freestyle SVGフック',
        'label_en': 'Freestyle SVG Hook',
        'description_ja': 'Freestyle SVG Export のレンダー開始・書き出し・完了フックを有効化します。Freestyle線画をレンダー時にSVGとして自動出力したい時だけ有効にしてください。無効時はレンダーイベントへ登録しないため通常作業が軽くなります。実際のSVG出力にはFreestyle SVG Exportパネル側のSVG 書き出しも有効にします。',
        'description_en': 'Enables render start/write/complete hooks for the Freestyle SVG Export. Enable it only when Freestyle line art should be exported automatically as SVG during rendering. When disabled, render event handlers are not registered. The panel-side SVG Export option must also be enabled to write SVG files.',
        'icon': 'FILE_REFRESH',
    },
    {
        'alias': 'sun_position',
        'owner_key': 'scene.sun_pos_properties',
        'prop': 'auto_update_callbacks',
        'label_ja': '太陽位置自動更新',
        'label_en': 'Sun Position Auto Update',
        'description_ja': 'タイムライン再生、フレーム変更、ファイル読込時に Sun Position Control の太陽・環境設定を自動更新します。手動更新で十分な場合は無効にしてください。',
        'description_en': 'Automatically updates Sun Position Control sun and environment settings during timeline playback, frame changes, and file loading. Disable it when manual updates are enough.',
        'icon': 'TIME',
    },
    {
        'alias': 'sun_position',
        'owner_key': 'scene.sun_pos_properties',
        'prop': 'show_north',
        'label_ja': '北方向オーバーレイ',
        'label_en': 'North Overlay',
        'description_ja': 'ビューポートに北方向を示すガイド線を常時描画します。方角確認が必要な時だけ有効にしてください。無効時は描画ハンドラーを停止して待機負荷を抑えます。',
        'description_en': 'Draws a persistent viewport guide line pointing north. Enable it only when directional reference is needed. Disabling it stops the draw handler and reduces idle work.',
        'icon': 'ORIENTATION_GLOBAL',
    },
    {
        'alias': 'sun_position',
        'owner_key': 'scene.sun_pos_properties',
        'prop': 'show_analemmas',
        'label_ja': 'アナレンマ表示',
        'label_en': 'Analemma Overlay',
        'description_ja': '年間を通した太陽位置の軌跡をビューポートに常時描画します。建築・採光検証などで必要な時だけ有効にしてください。無効時は関連描画を停止します。',
        'description_en': 'Continuously draws yearly sun-path analemma curves in the viewport. Enable it only for architectural or daylight studies that need this overlay. Disabling it stops the related drawing.',
        'icon': 'CURVE_PATH',
    },
    {
        'alias': 'sun_position',
        'owner_key': 'scene.sun_pos_properties',
        'prop': 'show_surface',
        'label_ja': '太陽軌道面表示',
        'label_en': 'Sun Path Surface',
        'description_ja': '太陽が空に描く軌道面をビューポートに常時描画します。可視化が必要な時だけ有効にしてください。無効時は関連描画を停止します。',
        'description_en': 'Continuously draws the sun-path surface in the viewport. Enable it only when this visualization is needed. Disabling it stops the related drawing.',
        'icon': 'MESH_GRID',
    },
    {
        'alias': 'profiler',
        'owner_key': 'wm.profiler',
        'prop': 'report_enabled',
        'label_ja': 'プロファイラーライブ更新',
        'label_en': 'Profiler Live Update',
        'description_ja': 'Render プロファイラーのバックグラウンド更新、タイマー、レンダー関連コールバックを有効化します。計測中だけ有効にし、通常作業では無効にすると負荷を抑えられます。',
        'description_en': 'Enables Render Profiler background updates, timers, and render-related callbacks. Enable it only while profiling; keep it disabled during normal work to reduce overhead.',
        'icon': 'TIME',
    },
)

_ON_DEMAND_REPLACED_ALWAYS_ON_CONTROLS: tuple[tuple[str, str, str], ...] = (
    ('camera_plane', 'wm.camera_plane_settings', 'auto_load_maintenance'),
    ('rendernames', 'scene.rendernames', 'auto_refresh_preview'),
    ('k_tools_render_preset_manager', 'scene.render_preset_settings', 'auto_sync_on_startup'),
)

_FEATURE_KIND_ORDER: tuple[str, ...] = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_FEATURE_KIND_INFO: dict[str, dict[str, str]] = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables Blender application handlers that run automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Enable this only when the tool must react in the background.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、元に戻す / やり直し、レンダー関連イベントで自動実行される Blender アプリケーションハンドラーを有効化します。バックグラウンド反応が必要な場合だけ有効にしてください。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Enable this only when the tool must keep checking or updating data automatically.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。自動チェックや自動更新が必要な場合だけ有効にしてください。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus',
        'label_ja': 'プロパティ変更の通知',
        'description_en': 'Enables RNA message-bus subscriptions that watch Blender data and run callbacks when watched properties change. Enable this only when realtime monitoring is needed.',
        'description_ja': 'Blender データの変更を監視し、対象プロパティが変わった時にコールバックを実行する プロパティ変更の通知購読を有効化します。リアルタイム監視が必要な場合だけ有効にしてください。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Enable this when the feature should respond to keyboard or mouse shortcuts.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで反応させたい場合に有効にしてください。',
    },
    'draw_handlers': {
        'label_en': 'Viewport Draw',
        'label_ja': 'ビューポート描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Enable this only when live guides or overlays are required.',
        'description_ja': 'ビューポートやエディターへオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。ライブガイドやオーバーレイが必要な場合だけ有効にしてください。',
    },
}

_UI_KNOWN_PROPS: dict[tuple[str, str], str] = {}
_UI_FEATURE_PROPS: dict[tuple[str, str], str] = {}
_UI_PROP_TO_KNOWN: dict[str, tuple[str, str, str]] = {}
_UI_PROP_TO_FEATURE: dict[str, tuple[str, str]] = {}


def _safe_prop_token(value: str) -> str:
    text = re.sub(r'[^0-9A-Za-z_]+', '_', str(value or '').strip().lower())
    text = re.sub(r'_+', '_', text).strip('_')
    return text or 'item'


def _known_ui_prop_name(alias: str, prop_name: str) -> str:
    return f'known__{_safe_prop_token(alias)}__{_safe_prop_token(prop_name)}'


def _feature_ui_prop_name(alias: str, feature_key: str) -> str:
    return f'feature__{_safe_prop_token(alias)}__{_safe_prop_token(feature_key)}'



def _resolve_owner(context, owner_key: str):
    try:
        if owner_key.startswith('wm.'):
            owner = getattr(context, 'window_manager', None)
            chain = owner_key[3:].split('.')
        elif owner_key.startswith('scene.'):
            owner = getattr(context, 'scene', None)
            chain = owner_key[6:].split('.')
        else:
            return None
        for name in chain:
            if not name:
                continue
            owner = getattr(owner, name, None)
            if owner is None:
                return None
        return owner
    except Exception:
        return None




def _snapshot_user_change(context=None) -> None:
    try:
        from . import settings
        settings.snapshot_context(context or getattr(bpy, 'context', None), force=False)
    except Exception:
        pass

def resolve_owner_for_persistence(context, owner_key: str):
    """Internal helper used by settings without exposing UI code."""
    return _resolve_owner(context, owner_key)


def _stored_enabled(alias: str, prop_name: str, owner=None) -> bool:
    try:
        from . import settings
        saved = settings.get_known_always_on(alias, prop_name, None)
        if saved is not None:
            return bool(saved)
    except Exception:
        pass
    # The canonical store is authoritative. An owner PropertyGroup may have a
    # legacy default=True, but a fresh install must never inherit that runtime
    # default and silently start resident work.
    return False


def _save_stored_enabled(alias: str, prop_name: str, enabled: bool) -> bool:
    try:
        from . import settings
        return bool(settings.set_known_always_on(alias, prop_name, bool(enabled), save=True))
    except Exception:
        return False


def _sync_known_runtime(alias: str, context=None, *, force_disable: bool = False) -> None:
    """Start or stop known background runtimes after a central toggle changes.

    This function only touches modules that are already loaded.  Disabled
    unloaded tools remain completely unloaded, so they add no handlers, timers,
    draw callbacks, imports, or Panel draw cost.
    """
    alias = str(alias or '').strip()
    if not alias:
        return
    try:
        if alias == 'camera_plane':
            from . import camera_plane
            sync = getattr(camera_plane, 'sync_load_handlers', None)
            if callable(sync):
                sync()
        elif alias == 'rendernames':
            from .rendernames import handlers as rendernames_handlers
            sync_path = getattr(rendernames_handlers, 'sync_render_path_hooks', None)
            if callable(sync_path):
                sync_path(context, force_disable=force_disable)
            sync = getattr(rendernames_handlers, 'sync_runtime_hooks', None)
            if callable(sync):
                sync(context)
        elif alias == 'freestyle_svg_exporter':
            from . import freestyle_svg_exporter
            sync = getattr(freestyle_svg_exporter, 'sync_runtime_hooks', None)
            if callable(sync):
                sync(context, force_disable=force_disable)
        elif alias == 'sun_position':
            from . import sun_position
            sync = getattr(sun_position, 'sync_runtime_handlers', None)
            if callable(sync):
                sync()
        elif alias == 'profiler':
            try:
                from .profiler import handlers as profiler_handlers
                sync = getattr(profiler_handlers, 'sync_runtime_hooks', None)
                if callable(sync):
                    sync(force=True)
            except Exception:
                pass
            try:
                from .profiler import ui as profiler_ui
                sync_ui = getattr(profiler_ui, 'sync_runtime_ui', None)
                if callable(sync_ui):
                    sync_ui(force=True)
            except Exception:
                pass
        elif alias == 'k_tools_render_preset_manager':
            # This tool uses a startup sync timer/function.  When disabled, make
            # sure no delayed sync remains registered; when enabled and already
            # loaded, run the sync explicitly instead of keeping an idle timer.
            try:
                from . import k_tools_render_preset_manager as rpm
                run = getattr(rpm, '_run_startup_sync', None)
                if force_disable and callable(run):
                    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
                    if timers is not None:
                        try:
                            if hasattr(timers, 'is_registered') and timers.is_registered(run):
                                timers.unregister(run)
                        except Exception:
                            try:
                                timers.unregister(run)
                            except Exception:
                                pass
                elif callable(run):
                    run()
            except Exception:
                pass
    except Exception:
        pass




def _set_owner_bool_safely(context, owner_key: str, prop_name: str, value: bool) -> bool:
    owner = _resolve_owner(context, owner_key)
    if owner is None or not hasattr(owner, prop_name):
        return False
    try:
        if bool(getattr(owner, prop_name, False)) != bool(value):
            setattr(owner, prop_name, bool(value))
        return True
    except Exception:
        try:
            owner[prop_name] = bool(value)
            return True
        except Exception:
            return False


def disable_on_demand_replaced_runtimes(context=None, *, save: bool = False) -> None:
    """Force-disable legacy always-on toggles that now have on-demand/manual equivalents.

    These items used to live in the centralized Always-on Toggles section. They
    can perform the same user-facing job through existing panel draw/manual
    refresh buttons, so keeping file-load timers/handlers for them is no longer
    necessary. This function is intentionally best-effort and never imports a
    tool just to turn it off.
    """
    ctx = context or getattr(bpy, 'context', None)
    for alias, owner_key, prop_name in _ON_DEMAND_REPLACED_ALWAYS_ON_CONTROLS:
        try:
            _set_owner_bool_safely(ctx, owner_key, prop_name, False)
        except Exception:
            pass
        try:
            from . import settings as _settings
            setter = getattr(_settings, 'set_known_always_on', None)
            if callable(setter):
                setter(alias, prop_name, False, save=False)
        except Exception:
            pass
    package = str(__package__ or '').strip()
    def _loaded_module(suffix: str):
        if not package:
            return None
        return sys.modules.get(f'{package}.{suffix}')

    # Do not import optional tools just to disable obsolete background work.
    # If a tool is already loaded, unregister its legacy timer/handler safely;
    # if it is not loaded, there is no active runtime to stop.
    try:
        camera_plane = _loaded_module('camera_plane')
        sync = getattr(camera_plane, 'sync_load_handlers', None) if camera_plane is not None else None
        if callable(sync):
            sync(context=ctx, force_disable=True)
    except Exception:
        pass
    try:
        rendernames_handlers = _loaded_module('rendernames.handlers')
        sync = getattr(rendernames_handlers, 'sync_runtime_hooks', None) if rendernames_handlers is not None else None
        if callable(sync):
            sync(ctx, force_disable=True)
    except Exception:
        pass
    try:
        rpm = _loaded_module('k_tools_render_preset_manager')
        run = getattr(rpm, '_run_startup_sync', None) if rpm is not None else None
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if callable(run) and timers is not None:
            try:
                if hasattr(timers, 'is_registered') and timers.is_registered(run):
                    timers.unregister(run)
            except Exception:
                try:
                    timers.unregister(run)
                except Exception:
                    pass
    except Exception:
        pass
    if save:
        try:
            from . import settings as _settings
            _settings.snapshot_context(ctx, force=False)
        except Exception:
            pass



def _tag_redraw_view3d(context=None) -> None:
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    area.tag_redraw()
    except Exception:
        pass


def _settings_from_context(context=None):
    try:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
        settings = getattr(scene, 'srr_settings', None)
        if settings is not None:
            return settings
    except Exception:
        pass
    return None


def _localized_toggle_state(settings, enabled: bool) -> str:
    return t(settings, '有効' if enabled else '無効', 'Enabled' if enabled else 'Disabled')


def _localized_bool_tooltip(settings, label_ja: str, label_en: str, description_ja: str, description_en: str, enabled: bool | None = None) -> str:
    label = t(settings, label_ja, label_en)
    description = t(settings, description_ja, description_en)
    action = t(
        settings,
        'クリックすると、この常時起動機能の有効・無効を切り替えます。設定はすぐ保存され、次回起動後も維持されます。',
        'Click to switch this always-on feature between enabled and disabled. The setting is saved immediately and kept after restarting Blender.',
    )
    if enabled is None:
        status = ''
    else:
        status = t(settings, f'現在の状態: {_localized_toggle_state(settings, enabled)}', f'Current state: {_localized_toggle_state(settings, enabled)}')
    parts = [part for part in (label, description, action, status) if part]
    return '\n'.join(parts)


def _operator_description_for_known_control(context, properties) -> str:
    settings = _settings_from_context(context)
    label_ja = str(getattr(properties, 'label_ja', '') or '常時起動項目')
    label_en = str(getattr(properties, 'label_en', '') or 'Always-on Entry')
    description_ja = str(getattr(properties, 'description_ja', '') or 'この項目の常時起動処理を切り替えます。')
    description_en = str(getattr(properties, 'description_en', '') or 'Toggle the always-on behavior for this entry.')
    alias = str(getattr(properties, 'alias', '') or '')
    owner_key = str(getattr(properties, 'owner_key', '') or '')
    prop_name = str(getattr(properties, 'prop_name', '') or '')
    owner = _resolve_owner(context, owner_key) if owner_key and prop_name else None
    enabled = _stored_enabled(alias, prop_name, owner)
    return _localized_bool_tooltip(settings, label_ja, label_en, description_ja, description_en, enabled)


def _safe_operator(layout, operator_id: str, *, text: str, icon: str, depress: bool = False):
    try:
        return layout.operator(operator_id, text=text, icon=icon, depress=depress)
    except TypeError:
        return layout.operator(operator_id, text=text, icon=icon)



def _get_known_toggle_value(alias: str, owner_key: str, prop_name: str) -> bool:
    context = getattr(bpy, 'context', None)
    owner = _resolve_owner(context, owner_key) if context is not None else None
    return _stored_enabled(alias, prop_name, owner)


def _set_known_toggle_value(alias: str, owner_key: str, prop_name: str, enabled: bool) -> None:
    context = getattr(bpy, 'context', None)
    alias = str(alias or '').strip()
    owner_key = str(owner_key or '').strip()
    prop_name = str(prop_name or '').strip()
    if not alias or not owner_key or not prop_name:
        return
    enabled = bool(enabled)
    _save_stored_enabled(alias, prop_name, enabled)
    owner = _resolve_owner(context, owner_key) if context is not None else None

    # Keep disabled unloaded tools completely unloaded. Enabling is the only
    # action that may lazy-load the owning tool so the real property and runtime
    # can be activated.
    if owner is None or not hasattr(owner, prop_name):
        if enabled:
            try:
                from . import settings, loader, ui_runtime
                loader.load_alias(alias, force=False)
                settings.apply_context(context, force=True)
                owner = _resolve_owner(context, owner_key) if context is not None else None
                schedule = getattr(ui_runtime, '_schedule_dynamic_ui_rebuild', None)
                if callable(schedule):
                    schedule()
            except Exception:
                _save_stored_enabled(alias, prop_name, False)
                _sync_known_runtime(alias, context, force_disable=True)
                _tag_redraw_view3d(context)
                return
        else:
            # Turning off an unloaded feature must not import that feature.  Its
            # saved state is already false, so no runtime exists to shut down.
            _snapshot_user_change(context)
            _tag_redraw_view3d(context)
            return

    if owner is not None and hasattr(owner, prop_name):
        try:
            # The profiler getter reads the canonical store that was updated
            # just above.  On an OFF -> ON transition it therefore already
            # reports True before its custom setter can initialize the saved
            # OFF mode to VIEWPORT.  Force only this documented ON setter;
            # normal controls and profiler OFF keep the existing comparison.
            force_owner_setter = (
                enabled
                and alias == 'profiler'
                and prop_name == 'report_enabled'
            )
            if force_owner_setter or bool(getattr(owner, prop_name, False)) != enabled:
                setattr(owner, prop_name, enabled)
        except Exception:
            if enabled:
                _save_stored_enabled(alias, prop_name, False)
                enabled = False

    _sync_known_runtime(alias, context, force_disable=not enabled)
    _snapshot_user_change(context)
    _tag_redraw_view3d(context)


def _get_feature_toggle_value(alias: str, feature_key: str) -> bool:
    try:
        from . import feature_toggle
        return bool(feature_toggle.is_feature_enabled(alias, feature_key))
    except Exception:
        return False


def _set_feature_toggle_value(alias: str, feature_key: str, enabled: bool) -> None:
    try:
        from . import feature_toggle
        feature_toggle.set_feature_enabled(alias, feature_key, bool(enabled))
    except Exception:
        pass
    _snapshot_user_change(getattr(bpy, 'context', None))
    _tag_redraw_view3d(getattr(bpy, 'context', None))


def _make_known_getter(alias: str, owner_key: str, prop_name: str):
    def _get(_self):
        return _get_known_toggle_value(alias, owner_key, prop_name)
    return _get


def _make_known_setter(alias: str, owner_key: str, prop_name: str):
    def _set(_self, value):
        _set_known_toggle_value(alias, owner_key, prop_name, bool(value))
    return _set


def _make_feature_getter(alias: str, feature_key: str):
    def _get(_self):
        return _get_feature_toggle_value(alias, feature_key)
    return _get


def _make_feature_setter(alias: str, feature_key: str):
    def _set(_self, value):
        _set_feature_toggle_value(alias, feature_key, bool(value))
    return _set


def _toggle_tooltip_text(label_ja: str, label_en: str, description_ja: str, description_en: str) -> str:
    return _localized_bool_tooltip(_settings_from_context(None), label_ja, label_en, description_ja, description_en, None)


class SRR_PersistentToggleState(bpy.types.PropertyGroup):
    """BoolProperty-backed UI state for the Always-on Toggles group."""


SRR_PersistentToggleState.__annotations__ = {}


# Add proxy bool properties before Blender class registration. Native boolean
# toggle drawing gives a consistent selected/blue overlay for enabled entries.
for _spec in _KNOWN_ALWAYS_ON_CONTROLS:
    _alias = str(_spec.get('alias') or '').strip()
    _owner_key = str(_spec.get('owner_key') or '').strip()
    _prop_name = str(_spec.get('prop') or '').strip()
    if not _alias or not _owner_key or not _prop_name:
        continue
    _ui_prop = _known_ui_prop_name(_alias, _prop_name)
    _UI_KNOWN_PROPS[(_alias, _prop_name)] = _ui_prop
    _UI_PROP_TO_KNOWN[_ui_prop] = (_alias, _owner_key, _prop_name)
    SRR_PersistentToggleState.__annotations__[_ui_prop] = bpy.props.BoolProperty(
        name=source_text(str(_spec.get('label_ja') or _prop_name), str(_spec.get('label_en') or _prop_name)),
        description=_toggle_tooltip_text(
            str(_spec.get('label_ja') or _prop_name),
            str(_spec.get('label_en') or _prop_name),
            str(_spec.get('description_ja') or ''),
            str(_spec.get('description_en') or ''),
        ),
        get=_make_known_getter(_alias, _owner_key, _prop_name),
        set=_make_known_setter(_alias, _owner_key, _prop_name),
        options={'SKIP_SAVE'},
    )

try:
    from .tool_catalog import tool_aliases as _tool_aliases_for_toggles
    _aliases_for_feature_toggles = tuple(_tool_aliases_for_toggles())
except Exception:
    _aliases_for_feature_toggles = ()

for _alias in _aliases_for_feature_toggles:
    _tool_label = integrated_tool_display_name(_alias, fallback=str(_alias).replace('_', ' ').title())
    for _feature_key in _FEATURE_KIND_ORDER:
        _info = _FEATURE_KIND_INFO.get(_feature_key, {})
        _ui_prop = _feature_ui_prop_name(str(_alias), _feature_key)
        _UI_FEATURE_PROPS[(str(_alias), _feature_key)] = _ui_prop
        _UI_PROP_TO_FEATURE[_ui_prop] = (str(_alias), _feature_key)
        _label_en = f'{_tool_label}: {str(_info.get("label_en") or _feature_key)}'
        _label_ja = f'{_tool_label}: {str(_info.get("label_ja") or _feature_key)}'
        SRR_PersistentToggleState.__annotations__[_ui_prop] = bpy.props.BoolProperty(
            name=source_text(_label_ja, _label_en),
            description=_toggle_tooltip_text(
                _label_ja,
                _label_en,
                str(_info.get('description_ja') or ''),
                str(_info.get('description_en') or ''),
            ),
            get=_make_feature_getter(str(_alias), _feature_key),
            set=_make_feature_setter(str(_alias), _feature_key),
            options={'SKIP_SAVE'},
        )


def _ui_toggle_state(context=None):
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        return getattr(wm, 'srr_persistent_toggle_state', None)
    except Exception:
        return None


def register_runtime_properties() -> None:
    try:
        from .rna_safety import register_pointer_property
        register_pointer_property(bpy.types.WindowManager, 'srr_persistent_toggle_state', SRR_PersistentToggleState)
    except Exception:
        pass


def unregister_runtime_properties() -> None:
    try:
        if hasattr(bpy.types.WindowManager, 'srr_persistent_toggle_state'):
            delattr(bpy.types.WindowManager, 'srr_persistent_toggle_state')
    except Exception:
        pass


class SRR_OT_toggle_known_persistent_control(bpy.types.Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = 'srr.toggle_startup_control'
    bl_label = "Toggle Startup Control"
    bl_label = source_text('常時起動を切り替え', 'Toggle Startup Control')
    bl_description = action_tooltip(
        '未読込の統合ツールは必要な時だけ読み込み、対象の常時起動機能を有効または無効にします。',
        'Load the integrated tool only when needed, then enable or disable the selected always-on feature.',
        usage_ja='常時機能切り替えグループで、必要な項目だけオンにしてください。未読込の項目をオンにすると、そのツールだけを遅延読み込みします。',
        usage_en='Use the Always-on Toggles group and enable only the entries you need. Enabling an unloaded entry lazy-loads only that tool.',
        tip_ja='起動時には統合ツールを一括読込しないため、Blender起動時のフリーズを避けやすくなります。',
        tip_en='Integrated tools are not batch-loaded at startup, which helps avoid Blender startup freezes.',
    )

    alias: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    owner_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    prop_name: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    label_ja: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    label_en: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    description_ja: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    description_en: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return _operator_description_for_known_control(context, properties)

    def execute(self, context):
        alias = str(getattr(self, 'alias', '') or '').strip()
        owner_key = str(getattr(self, 'owner_key', '') or '').strip()
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if not alias or not owner_key or not prop_name:
            self.report({'WARNING'}, localize_pair('対象の常時起動項目が不明です。', 'The target always-on entry is unknown.'))
            return {'CANCELLED'}

        owner = _resolve_owner(context, owner_key)
        current = _stored_enabled(alias, prop_name, owner)
        next_value = not current
        if not _save_stored_enabled(alias, prop_name, next_value):
            try:
                from . import settings as _settings
                _settings.set_known_always_on(alias, prop_name, current, save=False)
            except Exception:
                pass
            self.report({'ERROR'}, localize_pair('設定ファイルへ保存できませんでした。', 'The settings file could not be written.'))
            return {'CANCELLED'}

        # Enabling an unloaded always-on entry is the only case where this
        # operator imports a tool.  Disabling never imports the tool, so disabled
        # background features stay completely inactive and light.
        if owner is None or not hasattr(owner, prop_name):
            if next_value:
                try:
                    from . import loader, ui_runtime, settings
                    loader.load_alias(alias, force=False)
                    settings.apply_context(context, force=True)
                    owner = _resolve_owner(context, owner_key)
                    try:
                        schedule = getattr(ui_runtime, '_schedule_dynamic_ui_rebuild', None)
                        if callable(schedule):
                            schedule()
                    except Exception:
                        pass
                except Exception as exc:
                    _save_stored_enabled(alias, prop_name, False)
                    self.report({'ERROR'}, localize_pair('ツールを読み込めませんでした。', f'Failed to load tool: {exc}'))
                    return {'CANCELLED'}
            else:
                _tag_redraw_view3d(context)
                self.report({'INFO'}, localize_pair('常時起動設定を無効にしました。', 'Always-on setting disabled.'))
                return {'FINISHED'}

        owner = _resolve_owner(context, owner_key)
        if owner is not None and hasattr(owner, prop_name):
            try:
                setattr(owner, prop_name, bool(next_value))
            except Exception as exc:
                self.report({'ERROR'}, localize_pair('切り替えに失敗しました。', f'Failed to toggle: {exc}'))
                return {'CANCELLED'}
        elif next_value:
            self.report({'ERROR'}, localize_pair('対象プロパティが見つかりません。', 'The target property was not found.'))
            return {'CANCELLED'}

        _sync_known_runtime(alias, context, force_disable=not next_value)
        _snapshot_user_change(context)

        _tag_redraw_view3d(context)
        self.report({'INFO'}, localize_pair('常時起動設定を変更しました。', 'Always-on setting changed.'))
        return {'FINISHED'}


class SRR_OT_toggle_npanel_state_save(bpy.types.Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = 'srr.toggle_npanel_state_save'
    bl_label = source_text('Nパネル状態保存を切り替え', 'Toggle N-panel State Save')
    bl_description = action_tooltip(
        'Nパネルの状態保存を有効または無効にします。',
        'Enable or disable N-panel state saving.',
        usage_ja='常時機能切り替えセクションの「Nパネル状態保存」行でクリックします。',
        usage_en='Click the N-panel State Save row inside the Always-on Toggles section.',
        tip_ja='有効な場合はNパネルの設定変更をすぐ Smart_Render_Suite/Smart_Render_Suite.json に保存します。無効化操作だけを最後に1回保存し、その後の変更は再有効化まで書き込みません。',
        tip_en='When enabled, N-panel changes are saved immediately to Smart_Render_Suite/Smart_Render_Suite.json. Turning it off is saved once; later changes are not written until it is enabled again.',
    )

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        settings = getattr(scene, 'srr_settings', None) if scene is not None else None
        if settings is None or not hasattr(settings, 'n_panel_state_save'):
            self.report({'WARNING'}, localize_pair('Nパネル状態保存を変更できません。', 'N-panel State Save could not be changed.'))
            return {'CANCELLED'}
        try:
            next_value = not bool(getattr(settings, 'n_panel_state_save', True))
            setattr(settings, 'n_panel_state_save', bool(next_value))
            try:
                from . import settings as _smart_render_settings
                error = _smart_render_settings.last_write_error()
                if error:
                    raise RuntimeError(error)
            except Exception:
                raise
            _tag_redraw_view3d(context)
            self.report({'INFO'}, localize_pair('Nパネル状態保存を変更しました。', 'N-panel State Save changed.'))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, localize_pair('Nパネル状態保存を変更できませんでした。', f'N-panel State Save could not be changed: {exc}'))
            return {'CANCELLED'}


PERSISTENT_CONTROL_CLASSES = (
    SRR_PersistentToggleState,
    SRR_OT_toggle_known_persistent_control,
    SRR_OT_toggle_npanel_state_save,
)


def _npanel_text(ja: str, en: str) -> str:
    """Use Blender's interface locale for the cross-suite common section.

    Smart Render also has a tool-specific language preview preference.  That
    preference must not override the 21-suite common N-panel contract.
    """
    try:
        language = str(getattr(bpy.context.preferences.view, 'language', '') or '').strip()
        if not language or language.upper() in {'DEFAULT', 'AUTO', 'DEFAULT_AUTO'}:
            language = str(getattr(bpy.app.translations, 'locale', '') or '')
    except Exception:
        language = ''
    return str(ja if language.lower().startswith('ja') else en)


def _draw_toggle_operator_row(
    layout,
    settings,
    *,
    operator_id: str,
    label_ja: str,
    label_en: str,
    enabled: bool,
    setup_operator,
    data=None,
    prop_name: str = '',
) -> bool:
    try:
        row = layout.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=_npanel_text(label_ja, label_en))
        button_col = split.row(align=True)
        button_col.alignment = 'RIGHT'
        button_col.use_property_split = False
        button_col.use_property_decorate = False
        text = _npanel_text('有効' if enabled else '無効', 'On' if enabled else 'Off')
        icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'

        # Prefer native BoolProperty toggle drawing. This reliably uses
        # Blender's selected/blue overlay when the value is True.
        if data is not None and prop_name and hasattr(data, prop_name):
            try:
                actual_enabled = bool(getattr(data, prop_name))
                button_col.row(align=True).prop(
                    data,
                    prop_name,
                    text=_npanel_text('有効' if actual_enabled else '無効', 'On' if actual_enabled else 'Off'),
                    icon='CHECKBOX_HLT' if actual_enabled else 'CHECKBOX_DEHLT',
                    toggle=True,
                )
                return True
            except Exception:
                pass

        op = _safe_operator(
            button_col.row(align=True),
            operator_id,
            text=text,
            icon=icon,
            depress=enabled,
        )
        setup_operator(op)
        return True
    except Exception:
        return False

def _draw_known_control(layout, context, settings, spec: dict[str, str]) -> bool:
    owner = _resolve_owner(context, str(spec.get('owner_key') or ''))
    prop_name = str(spec.get('prop') or '').strip()
    label_ja = str(spec.get('label_ja') or prop_name)
    label_en = str(spec.get('label_en') or prop_name)
    description_ja = str(spec.get('description_ja') or '')
    description_en = str(spec.get('description_en') or '')
    alias = str(spec.get('alias') or '').strip()
    owner_key = str(spec.get('owner_key') or '').strip()

    enabled = _stored_enabled(alias, prop_name, owner)

    def _setup(op):
        op.alias = alias
        op.owner_key = owner_key
        op.prop_name = prop_name
        op.label_ja = label_ja
        op.label_en = label_en
        op.description_ja = description_ja
        op.description_en = description_en

    state = _ui_toggle_state(context)
    ui_prop = _UI_KNOWN_PROPS.get((alias, prop_name), '')
    return _draw_toggle_operator_row(
        layout,
        settings,
        operator_id=SRR_OT_toggle_known_persistent_control.bl_idname,
        label_ja=label_ja,
        label_en=label_en,
        enabled=enabled,
        setup_operator=_setup,
        data=state,
        prop_name=ui_prop,
    )


def _draw_explicit_runtime_controls(layout, context, settings) -> int:
    """Draw known always-on controls without importing all integrated tools.

    If a tool has not been loaded yet, its row is still shown in the centralized
    group as disabled. Clicking it lazy-loads only that tool and then toggles the
    real underlying property. This keeps Blender startup light while preserving a
    single location for all known always-on switches.
    """
    count = 0
    for spec in _KNOWN_ALWAYS_ON_CONTROLS:
        if _draw_known_control(layout, context, settings, spec):
            count += 1

    return count


def _feature_operator_id() -> str:
    try:
        from . import feature_toggle
        getter = getattr(feature_toggle, 'toggle_operator_id', None)
        if callable(getter):
            return str(getter())
        configure = getattr(feature_toggle, 'configure', None)
        if callable(configure):
            configure(suite_key='smart_render_suite', suite_label='Smart Render', category='Smart Render')
        return str(getattr(feature_toggle, '_OPERATOR_ID', '') or '')
    except Exception:
        return ''


def _runtime_feature_entries() -> list[dict[str, Any]]:
    try:
        from . import feature_toggle
        entries = getattr(feature_toggle, 'feature_entries', None)
        if callable(entries):
            return list(entries() or [])
    except Exception:
        return []
    return []


def _tool_label_for_entry(entry: dict[str, Any]) -> str:
    alias = str(entry.get('alias') or '').strip()
    raw = str(entry.get('tool_label') or '').strip()
    if raw:
        return raw
    if alias:
        return integrated_tool_display_name(alias, fallback=alias.replace('_', ' ').title())
    return 'Integrated Tool'


def _entry_display_label(settings, entry: dict[str, Any], feature_key: str) -> tuple[str, str]:
    tool_label = _tool_label_for_entry(entry)
    feature_ja = str(entry.get('label_ja') or feature_key)
    feature_en = str(entry.get('label_en') or feature_key)
    return f'{tool_label}: {feature_ja}', f'{tool_label}: {feature_en}'


def _draw_captured_runtime_controls(layout, context, settings) -> int:
    op_id = _feature_operator_id()
    entries = _runtime_feature_entries()
    if not op_id or not entries:
        return 0

    count = 0
    for item in entries:
        alias = str(item.get('alias') or '').strip()
        feature_key = str(item.get('key') or '').strip()
        if not alias or not feature_key:
            continue
        enabled = bool(item.get('enabled'))
        label_ja, label_en = _entry_display_label(settings, item, feature_key)

        def _setup(op, *, _alias=alias, _feature_key=feature_key):
            op.alias = _alias
            op.feature_key = _feature_key

        state = _ui_toggle_state(context)
        ui_prop = _UI_FEATURE_PROPS.get((alias, feature_key), '')
        if _draw_toggle_operator_row(
            layout,
            settings,
            operator_id=op_id,
            label_ja=label_ja,
            label_en=label_en,
            enabled=enabled,
            setup_operator=_setup,
            data=state,
            prop_name=ui_prop,
        ):
            count += 1
    return count


def prepare_controls(layout, context, settings=None, *, container=None):
    """Create the always-on box/header without drawing its expanded body.

    The header is the shared Smart Render top-level section header
    (ui._prepare_srr_npanel_section: triangle, borderless icon+title, 0.35 gap,
    compact help) so it lines up with every other top-level section.  The title
    keeps the Blender-interface-locale text from _npanel_text and is passed as
    both language variants so the shared header does not re-localize it.  The
    hand-drawn header below is only the fallback.
    """
    label = _npanel_text('常時機能切り替え', 'Always-on Toggles')
    if settings is not None and hasattr(settings, 'show_always_on_toggles'):
        try:
            from .ui import _prepare_srr_npanel_section
            prepared = _prepare_srr_npanel_section(
                layout,
                settings,
                'show_always_on_toggles',
                label,
                label,
                icon='TIME',
                help_key='always_on_toggles',
                default_open=False,
                container=container,
            )
        except Exception:
            prepared = None
        if isinstance(prepared, dict):
            return {
                'box': prepared.get('box'),
                'context': context,
                'settings': settings,
                'is_open': bool(prepared.get('opened')),
            }
    box = container if container is not None else layout.box()
    is_open = bool(getattr(settings, 'show_always_on_toggles', False)) if settings is not None else False

    header = box.row(align=True)
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    if settings is not None and hasattr(settings, 'show_always_on_toggles'):
        try:
            op = header.operator('srr.toggle_npanel_section', text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=True, depress=is_open)
            op.prop_name = 'show_always_on_toggles'
        except Exception:
            header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
        try:
            op = header.operator('srr.toggle_npanel_section', text=label, icon='TIME', emboss=False, depress=is_open)
            op.prop_name = 'show_always_on_toggles'
        except TypeError:
            try:
                op = header.operator('srr.toggle_npanel_section', text=label, icon='TIME', emboss=False)
                op.prop_name = 'show_always_on_toggles'
            except Exception:
                header.label(text=label, icon='TIME')
        except Exception:
            header.label(text=label, icon='TIME')
    else:
        header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
        header.label(text=label, icon='TIME')
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    try:
        from .help_operator import draw_help_button
        draw_help_button(header, 'always_on_toggles', tool_label=label)
    except Exception:
        pass

    return {
        'box': box,
        'context': context,
        'settings': settings,
        'is_open': bool(is_open),
    }


def populate_controls(prepared) -> int:
    if not isinstance(prepared, dict) or not prepared.get('is_open'):
        return 0
    box = prepared.get('box')
    context = prepared.get('context')
    settings = prepared.get('settings')
    if box is None:
        return 0
    col = box.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    if settings is not None and hasattr(settings, 'n_panel_state_save'):
        state = bool(getattr(settings, 'n_panel_state_save', True))
        try:
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            left = split.row(align=True)
            left.label(text=_npanel_text('Nパネル状態保存', 'N-panel State Save'))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.row(align=True).prop(
                settings,
                'n_panel_state_save',
                text=_npanel_text('有効' if state else '無効', 'On' if state else 'Off'),
                icon='CHECKBOX_HLT' if state else 'CHECKBOX_DEHLT',
                toggle=True,
            )
        except Exception:
            pass
        try:
            col.separator(factor=0.5)
        except Exception:
            pass
    explicit_count = _draw_explicit_runtime_controls(col, context, settings)
    captured_count = _draw_captured_runtime_controls(col, context, settings)
    total = explicit_count + captured_count

    if total == 0:
        box.label(text=t(settings, '項目なし', 'No Entries'))
    return total


def draw_controls(layout, context, settings=None) -> int:
    """Draw the centralized always-on switch group at the top of the N-panel."""
    return populate_controls(
        prepare_controls(layout, context, settings)
    )


def known_always_on_specs() -> tuple[dict[str, str], ...]:
    return tuple(dict(item) for item in _KNOWN_ALWAYS_ON_CONTROLS)


def _enabled_startup_aliases() -> list[str]:
    try:
        from . import settings
        enabled = settings.enabled_known_aliases()
    except Exception:
        enabled = set()
    aliases: list[str] = []
    for spec in _KNOWN_ALWAYS_ON_CONTROLS:
        alias = str(spec.get('alias') or '').strip()
        prop_name = str(spec.get('prop') or '').strip()
        if not alias or alias in aliases:
            continue
        if alias in enabled or _stored_enabled(alias, prop_name, None):
            aliases.append(alias)
    return aliases



def _set_known_control_value(owner, prop_name: str, desired: bool, *, suppress_transform_updates: bool = False, alias: str = '', context=None) -> None:
    """Set an always-on property without replaying transform-changing updates."""
    alias = str(alias or '')
    prop_name = str(prop_name or '')
    if (
        suppress_transform_updates
        and alias == 'sun_position'
        and prop_name in {'show_north', 'show_analemmas', 'show_surface'}
    ):
        try:
            owner[prop_name] = bool(desired)
        except Exception:
            try:
                setattr(owner, prop_name, bool(desired))
            except Exception:
                return
        # Refresh overlay handlers only. Do not call sun_update(), because it
        # also calls move_sun() and changes object transforms.
        try:
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
            from .sun_position import draw as sun_draw
            if prop_name == 'show_north':
                sun_draw.north_update(scene)
            else:
                sun_draw.analemmas_surface_update(scene)
        except Exception:
            pass
        return
    setattr(owner, prop_name, bool(desired))


def enforce_known_controls(context=None, *, load_missing: bool = False, suppress_transform_updates: bool = False) -> None:
    try:
        disable_on_demand_replaced_runtimes(context, save=False)
    except Exception:
        pass
    for spec in _KNOWN_ALWAYS_ON_CONTROLS:
        alias = str(spec.get('alias') or '').strip()
        owner_key = str(spec.get('owner_key') or '').strip()
        prop_name = str(spec.get('prop') or '').strip()
        if not alias or not owner_key or not prop_name:
            continue
        desired = _stored_enabled(alias, prop_name, None)
        owner = _resolve_owner(context, owner_key)
        if owner is None or not hasattr(owner, prop_name):
            if desired and load_missing:
                try:
                    from . import loader
                    loader.load_alias(alias, force=False)
                    owner = _resolve_owner(context, owner_key)
                except Exception:
                    owner = None
            else:
                continue
        if owner is None or not hasattr(owner, prop_name):
            continue
        try:
            if bool(getattr(owner, prop_name, False)) != desired:
                _set_known_control_value(
                    owner,
                    prop_name,
                    bool(desired),
                    suppress_transform_updates=suppress_transform_updates,
                    alias=alias,
                    context=context,
                )
        except Exception:
            pass
        _sync_known_runtime(alias, context, force_disable=not desired)


_STARTUP_LOAD_TIMER = None


def cancel_enabled_always_on_startup() -> None:
    global _STARTUP_LOAD_TIMER
    timer = _STARTUP_LOAD_TIMER
    _STARTUP_LOAD_TIMER = None
    if callable(timer):
        try:
            if bpy.app.timers.is_registered(timer):
                bpy.app.timers.unregister(timer)
        except Exception:
            pass


def schedule_enabled_always_on_startup(context=None) -> None:
    global _STARTUP_LOAD_TIMER
    cancel_enabled_always_on_startup()
    try:
        disable_on_demand_replaced_runtimes(context, save=False)
    except Exception:
        pass
    aliases = _enabled_startup_aliases()
    if not aliases:
        enforce_known_controls(context, load_missing=False, suppress_transform_updates=True)
        return

    queue = list(aliases)

    def _timer():
        global _STARTUP_LOAD_TIMER
        if not queue:
            _STARTUP_LOAD_TIMER = None
            return None
        alias = queue.pop(0)
        try:
            from . import loader, ui_runtime, settings
            loader.load_alias(alias, force=False)
            settings.apply_context(getattr(bpy, 'context', None), force=True)
            enforce_known_controls(getattr(bpy, 'context', None), load_missing=False, suppress_transform_updates=True)
            schedule = getattr(ui_runtime, '_schedule_dynamic_ui_rebuild', None)
            if callable(schedule):
                schedule()
        except Exception:
            pass
        return 0.20 if queue else None

    _STARTUP_LOAD_TIMER = _timer
    try:
        bpy.app.timers.register(_timer, first_interval=0.20)
    except Exception:
        try:
            _timer()
        except Exception:
            pass
