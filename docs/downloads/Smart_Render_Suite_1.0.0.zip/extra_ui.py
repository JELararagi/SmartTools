# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from .translation import localize_pair


def _txt(ja: str, en: str) -> str:
    return localize_pair(ja, en)


def runtime_settings_draw_for_record(record: dict):
    spec = dict(record.get("spec") or {})
    alias = str(spec.get("alias") or "").strip()
    if alias == "camera_rigs":
        from .camera_rigs import runtime_preferences as mod
        return getattr(mod, "draw_runtime_settings", None)
    if alias == "k_tools_render_preset_manager":
        from .k_tools_render_preset_manager import runtime_preferences as mod
        return getattr(mod, "draw_runtime_settings", None)
    if alias == "profiler":
        from .profiler import preferences as mod
        return getattr(mod, "draw_runtime_settings", None)
    if alias == "sun_position":
        from .sun_position import runtime_preferences as mod
        return getattr(mod, "draw_runtime_settings", None)
    if alias == "use_for_rendering_plus":
        from .use_for_rendering_plus import runtime_preferences as mod
        return getattr(mod, "draw_runtime_settings", None)
    if alias == "tri_lighting":
        from .tri_lighting import draw_runtime_settings as tri_lighting_draw_runtime_settings
        return tri_lighting_draw_runtime_settings
    if alias == "dynamic_sky":
        from .dynamic_sky import draw_world_controls as dynamic_sky_draw_world_controls
        return dynamic_sky_draw_world_controls
    if alias == "camera_plane":
        try:
            from .camera_plane.properties import draw_runtime_settings as camera_plane_draw_runtime_settings
            return camera_plane_draw_runtime_settings
        except Exception:
            return None
    return None


def panel_specs_for_record(record: dict) -> list[dict]:
    spec = dict(record.get("spec") or {})
    alias = str(spec.get("alias") or "").strip()
    specs: list[dict] = []

    # Do not add overview/usage/help text panels to the N-panel.
    # Detailed help is handled by smart_render_suite.help_content, which is
    # imported only when a Help popup is opened.
    if str(record.get("status") or "") == "loaded":
        settings_draw = runtime_settings_draw_for_record(record)
        if alias == "sun_position":
            from .sun_position.runtime_preferences import draw_integrated_controls
            specs.append({"key": "sun_position_controls", "label": _txt("太陽の位置", "Sun Position Control"), "draw": draw_integrated_controls})
        if alias == "camera_plane":
            from .camera_plane.ui import draw_integrated_controls
            specs.append({"key": "camera_plane_controls", "label": _txt("カメラプレーン", "Camera Plane"), "draw": draw_integrated_controls})
        if alias == "k_tools_render_preset_manager":
            from .k_tools_render_preset_manager.ui.panels import draw_main_addon_ui
            specs.append({"key": "render_preset_controls", "label": _txt("レンダープリセット", "Render Presets"), "draw": draw_main_addon_ui})
        if callable(settings_draw):
            specs.append({"key": f"{alias}_settings", "label": _txt("設定", "Settings"), "draw": settings_draw})

    return specs
