# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import sys

import bpy
from bpy.types import Panel, UIList

from .bridge_catalog import bridge_meta
from .translation import _text_width, action_tooltip, draw_prop, draw_prop_search, icon_for_status, info_line, is_japanese_locale, localize_class_attributes, localize_inline, localize_pair, render_summary_lines, source_text, status_card, status_value_text, stored_text, t, wrap_units, wrapped_lines
from .preview_cache import get_queue_item_snapshot, get_scene_snapshot, get_variant_snapshot, request_element_checks
from .token_metadata import grouped_token_metadata
from .recipes import workflow_recipe_meta
from .elements_catalog import RENDER_ELEMENT_CATALOG, RENDER_ELEMENT_GROUPS
from .controls import draw_controls, populate_controls, prepare_controls


SMART_RENDER_PSEUDO_ICON = 'RENDER_STILL'
# Blender N-panel area types supported through Smart Tools Manager proxy routing.
SMART_RENDER_NPANEL_SPACE_TYPES = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}


def _context_area_type(context) -> str:
    try:
        area = getattr(context, "area", None)
        if area is None:
            return ""
        return str(getattr(area, "type", "") or "")
    except Exception:
        return ""


def _is_standard_npanel_context(context) -> bool:
    """Return True only for an explicit supported Sidebar/N-panel area.

    Blender 5.1 can evaluate Panel.poll during Sidebar rebuilds with a
    partially populated context. Treating a missing area as supported allowed
    both the VIEW_3D root and the IMAGE_EDITOR mirror root to be shown in the
    same N-panel. Root panel visibility now requires a concrete editor type.
    """
    area = getattr(context, "area", None)
    if area is None:
        return False
    return str(getattr(area, "type", "") or "") in SMART_RENDER_NPANEL_SPACE_TYPES


def _logical_editor_key(context) -> str:
    """Map Blender's 11 physical Sidebar hosts to Manager's 17 editor cells."""
    try:
        area = getattr(context, 'area', None)
        space = getattr(context, 'space_data', None)
        area_type = str(getattr(area, 'type', '') or '').strip().upper()
        area_ui = str(getattr(area, 'ui_type', '') or '').strip().upper()
    except Exception:
        return ''
    if area_type == 'VIEW_3D':
        return 'VIEW_3D'
    if area_type == 'IMAGE_EDITOR':
        mode = str(getattr(space, 'mode', '') or '').strip().upper()
        return 'UV_EDITOR' if mode == 'UV' or area_ui in {'UV', 'UV_EDITOR'} or 'UV' in area_ui else 'IMAGE_EDITOR'
    if area_type == 'NODE_EDITOR':
        tree_type = str(
            getattr(space, 'tree_type', '')
            or getattr(space, 'ui_type', '')
            or area_ui
            or ''
        ).strip().upper()
        if tree_type in {'COMPOSITORNODETREE', 'COMPOSITOR'}:
            return 'COMPOSITOR'
        if tree_type in {'GEOMETRYNODETREE', 'GEOMETRY', 'GEOMETRY_NODES'}:
            return 'GEOMETRY_NODE_EDITOR'
        if tree_type in {'TEXTURENODETREE', 'TEXTURE'}:
            return 'TEXTURE_NODE_EDITOR'
        return 'SHADER_EDITOR'
    if area_type == 'SEQUENCE_EDITOR':
        return 'VIDEO_SEQUENCER'
    if area_type == 'CLIP_EDITOR':
        return 'MOVIE_CLIP_EDITOR'
    if area_type == 'DOPESHEET_EDITOR':
        return 'DOPE_SHEET'
    if area_type == 'GRAPH_EDITOR':
        mode = str(getattr(space, 'mode', '') or '').strip().upper()
        return 'DRIVERS' if mode == 'DRIVERS' or area_ui == 'DRIVERS' else 'GRAPH_EDITOR'
    if area_type == 'NLA_EDITOR':
        return 'NLA_EDITOR'
    if area_type == 'TEXT_EDITOR':
        return 'TEXT_EDITOR'
    if area_type == 'FILE_BROWSER':
        browse_mode = str(getattr(space, 'browse_mode', '') or '').strip().upper()
        return 'ASSET_BROWSER' if browse_mode == 'ASSETS' or area_ui in {'ASSETS', 'ASSET_BROWSER'} else 'FILE_BROWSER'
    if area_type == 'SPREADSHEET':
        return 'SPREADSHEET'
    return ''


def _manager_allows(context, editor_key: str) -> bool:
    """Use only Smart Tools Manager's public, in-memory placement API."""
    for module_name in (
        'bl_ext.user_default.smart_tools_manager',
        'smart_tools_manager',
    ):
        manager = sys.modules.get(module_name)
        placement_allowed = getattr(manager, 'placement_allowed', None)
        if not callable(placement_allowed):
            continue
        try:
            return bool(
                placement_allowed(
                    'SMART_RENDER',
                    context,
                    editor_key=editor_key,
                )
            )
        except Exception:
            return True
    return True


def _root_panel_poll(cls, context) -> bool:
    try:
        area_type = str(getattr(getattr(context, 'area', None), 'type', '') or '').strip().upper()
        expected = str(getattr(cls, 'bl_space_type', '') or '').strip().upper()
    except Exception:
        return False
    if area_type != expected:
        return False
    editor_key = _logical_editor_key(context)
    return bool(editor_key and _manager_allows(context, editor_key))


def activate_smart_render_pseudo_tab(context) -> bool:
    # Backward-compatible no-op for old operator calls. Standard N-panel panels
    # are always available in the Smart Render category while the add-on is enabled.
    return _is_standard_npanel_context(context)


def deactivate_smart_render_pseudo_tab(context, *, restore_context: bool = True) -> bool:
    del context, restore_context
    return False


def reset_smart_render_pseudo_tab_state():
    return None

def _planned_render_count(scene, settings, queue_items):
    del settings, queue_items
    return int(get_scene_snapshot(scene).get("planned_render_count", 0) or 0)

def _execution_preview_rows(context, scene, settings, limit: int = 3):
    del context, settings
    snapshot = get_scene_snapshot(scene)
    rows = list(snapshot.get("execution_rows", []) or [])[: max(1, int(limit))]
    return rows, int(snapshot.get("queue_count", 0) or 0)

def _execution_graph_preview(context, scene, settings):
    del context, settings
    graph = get_scene_snapshot(scene).get("execution_graph", {}) or {}
    return {
        "job_count": int(graph.get("job_count", 0) or 0),
        "render_node_count": int(graph.get("render_node_count", 0) or 0),
        "verify_node_count": int(graph.get("verify_node_count", 0) or 0),
        "movie_node_count": int(graph.get("movie_node_count", 0) or 0),
        "node_count": int(graph.get("node_count", 0) or 0),
        "edge_count": int(graph.get("edge_count", 0) or 0),
        "max_dependency_depth": int(graph.get("max_dependency_depth", 0) or 0),
    }

def _selector_preview_data(selector_text: str, available_names, limit: int = 4):
    from .compat import parse_name_list
    from .selectors import preview_selector_matches, resolve_selector_diagnostics

    selectors = parse_name_list(selector_text)
    if not selectors:
        return None
    diagnostics = resolve_selector_diagnostics(selectors, available_names)
    preview = preview_selector_matches(selectors, available_names, limit=limit)
    return {
        "selectors": selectors,
        "matches": list(diagnostics.get("resolved", []) or []),
        "missing": list(diagnostics.get("unmatched", []) or []),
        "invalid": list(diagnostics.get("invalid", []) or []),
        "preview": preview,
    }

def _draw_selector_preview(layout, settings, label_ja: str, label_en: str, selector_text: str, available_names, icon: str = 'NONE'):
    data = _selector_preview_data(selector_text, available_names, limit=(3 if settings.compact_mode else 5))
    if not data:
        return
    match_count = len(data["matches"])
    invalid_count = len(data["invalid"])
    suffix = ""
    if invalid_count:
        suffix = t(settings, f" / 無効 {invalid_count}", f" / invalid {invalid_count}")
    layout.label(
        text=t(settings, f"{label_ja}: {match_count} 件一致", f"{label_en}: {match_count} match(es)") + suffix,
        icon=('ERROR' if invalid_count else icon),
    )
    if data["preview"]:
        layout.label(text=", ".join(data["preview"]), icon='BLANK1', translate=False)
    for invalid in data["invalid"]:
        selector = str(invalid.get("selector", "") or "")
        error = str(invalid.get("error", "") or "")
        layout.label(
            text=t(settings, f"無効な正規表現: {selector} ({error})", f"Invalid regex: {selector} ({error})"),
            icon='ERROR',
        translate=False)
    for missing in data["missing"]:
        layout.label(
            text=t(settings, f"未一致: {missing}", f"No match: {missing}"),
            icon='ERROR',
        translate=False)


def _draw_cached_selector_preview(layout, settings, label_ja: str, label_en: str, data, icon: str = 'NONE'):
    if not data:
        return
    match_count = int(data.get("match_count", 0) or 0)
    invalid = list(data.get("invalid", []) or [])
    suffix = t(settings, f" / 無効 {len(invalid)}", f" / invalid {len(invalid)}") if invalid else ""
    layout.label(text=t(settings, f"{label_ja}: {match_count} 件一致", f"{label_en}: {match_count} match(es)") + suffix, icon=('ERROR' if invalid else icon))
    preview = list(data.get("preview", []) or [])
    if preview:
        layout.label(text=", ".join(str(value) for value in preview), icon='BLANK1', translate=False)
    for entry in invalid:
        selector = str(entry.get("selector", "") or "") if isinstance(entry, dict) else str(entry)
        error = str(entry.get("error", "") or "") if isinstance(entry, dict) else ""
        layout.label(text=t(settings, f"無効な正規表現: {selector} ({error})", f"Invalid regex: {selector} ({error})"), icon='ERROR', translate=False)
    for missing in list(data.get("missing", []) or []):
        layout.label(text=t(settings, f"未一致: {missing}", f"No match: {missing}"), icon='ERROR', translate=False)


def _draw_token_reference(layout, settings):
    for group in grouped_token_metadata():
        group_box = layout.box()
        group_box.label(text=t(settings, group["label_ja"], group["label_en"]), icon='BOOKMARKS', translate=False)
        if settings.compact_mode:
            grid = group_box.grid_flow(columns=2, even_columns=True, even_rows=True, align=True)
            for item in group["items"]:
                grid.label(text=item["token"])
            continue
        for item in group["items"]:
            row = group_box.split(factor=0.26, align=True)
            row.label(text=item["token"], icon='DOT')
            row.label(text=t(settings, item["description_ja"], item["description_en"]), translate=False)


def _safe_scene_settings(context):
    # Registration and scene/load handlers replay external settings before the
    # panel becomes visible.  Panel.draw must only read the already-materialized
    # RNA; applying settings here can register Sun Position draw handlers and
    # write state during an ordinary viewport redraw.
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "srr_settings", None) if scene is not None else None
    # Do not snapshot while drawing the N-panel. Panel draw can run during 3D
    # View redraws; saving/serializing here makes orbit, pan, and zoom feel
    # delayed. Settings persistence is handled by msgbus/update callbacks and
    # explicit save/close handlers in settings.py.
    return scene, settings



def _element_label(settings, name) -> str:
    """Name of a render element as the panel's check boxes show it."""
    from .planner import RENDER_ELEMENT_CATALOG, _render_element_item_display_name
    for item in RENDER_ELEMENT_CATALOG:
        if _render_element_item_display_name(item) == name:
            return t(settings, str(item.get("label_ja") or name), str(item.get("label_en") or name))
    return str(name)


def _wrapped_name_lines(names, separator, width) -> list:
    """Lines of a name list that break between names, never inside one."""
    lines = []
    current = ""
    last = len(names) - 1
    for index, name in enumerate(names):
        piece = str(name) + (separator if index < last else "")
        if current and _text_width((current + piece).rstrip()) > width:
            lines.append(current.rstrip())
            current = ""
        current += piece
        if _text_width(current.rstrip()) > width:
            pieces = wrapped_lines(current, width)
            lines.extend(pieces[:-1])
            current = pieces[-1] if pieces else ""
    if current.strip():
        lines.append(current.rstrip())
    return lines


def _button_flow(layout):
    """Buttons side by side while their text fits, stacked when it does not."""
    return layout.grid_flow(row_major=True, columns=0, even_columns=True, even_rows=True, align=True)


def _draw_runtime_unavailable(layout):
    try:
        layout.label(text=localize_inline("Data unavailable / データを読めません"), icon='ERROR', translate=False)
    except Exception:
        pass



def _advanced_ui_enabled(context) -> bool:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "srr_settings", None)
    return bool(settings is not None and getattr(settings, "show_advanced", False))


def _simple_ui_enabled(context) -> bool:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "srr_settings", None)
    return bool(settings is not None and not getattr(settings, "show_advanced", False))


def _smart_render_tab_active(context) -> bool:
    return _is_standard_npanel_context(context)


def _smart_render_nav_button_active(context) -> bool:
    return _smart_render_tab_active(context)


def _draw_render_element_group(layout, settings, group_id: str, columns: int = 2):
    group_meta = next((group for group in RENDER_ELEMENT_GROUPS if group[0] == group_id), None)
    items = [item for item in RENDER_ELEMENT_CATALOG if str(item.get("group", "")) == group_id]
    if not items:
        return
    box = layout.box()
    if group_meta is not None:
        box.label(text=t(settings, group_meta[1], group_meta[2]), icon='DOT', translate=False)
    grid = box.grid_flow(columns=max(1, int(columns)), even_columns=True, even_rows=True, align=True)
    for item in items:
        prop_name = str(item.get("prop", ""))
        if not prop_name:
            continue
        grid.prop(settings, prop_name, text=t(settings, str(item.get("label_ja", prop_name)), str(item.get("label_en", prop_name))), translate=False)


class SRR_PropertiesPageMixin:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw_header(self, _context):
        try:
            panel_id = str(getattr(self, 'bl_idname', '') or getattr(type(self), 'bl_idname', '') or '')
            if panel_id in {'SRR_PT_MAIN_PANEL', 'SRR_IMAGE_PT_MAIN_PANEL'}:
                return
            from .help_operator import draw_help_button
            draw_help_button(
                self.layout,
                str(getattr(self, 'srs_help_key', '') or getattr(self, 'bl_idname', '')),
                tool_label=str(getattr(self, 'bl_label', '') or ''),
            )
        except Exception:
            pass

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context)


class SRR_PT_PANEL_NAVIGATION(Panel):
    bl_label = "Smart Render Compatibility"
    bl_idname = "SRR_PT_PANEL_NAVIGATION"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'HIDE_HEADER'}

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        return None


class SRR_UL_queue(UIList):
    bl_idname = "SRR_UL_queue"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        source_icon = 'PRESET' if getattr(item, "source_mode", "PAIR") == "PAIR" else 'BOOKMARKS'
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "enabled", text="")
            row.label(text=getattr(item, "label", ""), icon=source_icon, translate=False)
            detail = getattr(item, "variant_name", "") or f"{getattr(item, 'camera_name', '')} | {getattr(item, 'view_layer_name', '')}"
            row.label(text=detail, translate=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon=source_icon)


class SRR_UL_variants(UIList):
    bl_idname = "SRR_UL_variants"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            scene = getattr(context, "scene", None)
            variant_snapshot = get_variant_snapshot(scene, index, getattr(item, "name", "")) if scene is not None else {}
            row = layout.row(align=True)
            row.prop(item, "enabled", text="")
            row.label(text=getattr(item, "name", "Variant"), icon='BOOKMARKS', translate=False)
            chain = list(variant_snapshot.get("chain", []) or [])
            if len(chain) > 1:
                row.label(text=" / ".join(chain), icon='LINKED', translate=False)
            else:
                row.label(text=f"{getattr(item, 'camera_name', '')} | {getattr(item, 'view_layer_name', '')}", translate=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='BOOKMARKS')


class SRR_UL_logs(UIList):
    bl_idname = "SRR_UL_logs"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        icon_name = {
            "INFO": 'DOT',
            "WARNING": 'ERROR',
            "ERROR": 'CANCEL',
        }.get(getattr(item, "level", "INFO"), 'DOT')
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=stored_text(getattr(item, "message", "")), icon=icon_name, translate=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon=icon_name)


def _draw_srr_root_header(self, context):
    _draw_srr_help_button(self.layout, 'SRR_PT_MAIN_PANEL', tool_label='Smart Render')


class SRR_PT_MAIN_PANEL(SRR_PropertiesPageMixin, Panel):
    draw_header_preset = _draw_srr_root_header
    bl_label = "Smart Render"
    bl_idname = "SRR_PT_MAIN_PANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True

    @classmethod
    def poll(cls, context):
        return _root_panel_poll(cls, context)

    def draw(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return
        # Every visible top-level item is drawn as a Smart Transform style
        # boxed section row: triangle button, section icon, section name, and
        # Help button.  The original child panel bodies are embedded below each
        # custom section so Blender's separate child headers do not duplicate
        # the UI.
        # Use the root panel layout directly. Blender's native collapsible
        # UILayout.panel() child groups require the full panel-region width and
        # cannot be nested inside a box/column. Top-level sections are still drawn
        # as Smart Transform style boxes; nested sections use Blender's standard >
        # disclosure rows.
        section_layout = layout
        controls_prepared = prepare_controls(section_layout, context, settings)
        _draw_srr_section_gap(section_layout)

        section_specs = [
            (
                'show_section_smart_render_overview',
                'スマートレンダー',
                'Smart Render',
                SMART_RENDER_PSEUDO_ICON,
                'SRR_PT_MAIN_PANEL',
                lambda body: _draw_smart_render_overview_body(body, context, scene, settings),
            ),
        ]
        for prop_name, label_ja, label_en, icon_name, help_key, panel_cls in _iter_srr_section_specs(settings):
            section_specs.append((
                prop_name,
                label_ja,
                label_en,
                icon_name,
                help_key,
                lambda body, _panel_cls=panel_cls: _draw_panel_class_body(_panel_cls, body, context, settings),
            ))
        section_specs.append((
            'show_section_integrated_tools',
            'その他ツール',
            'Other Tools',
            'TOOL_SETTINGS',
            'integrated_tools',
            lambda body: _draw_integrated_tools_section_body(body, context, settings),
        ))

        prepared_sections = []
        for section_index, spec in enumerate(section_specs):
            prop_name, label_ja, label_en, icon_name, help_key, draw_body = spec
            prepared_sections.append((
                _prepare_srr_npanel_section(
                    section_layout,
                    settings,
                    prop_name,
                    label_ja,
                    label_en,
                    icon=icon_name,
                    help_key=help_key,
                    default_open=False,
                ),
                draw_body,
            ))
            if section_index < len(section_specs) - 1:
                _draw_srr_section_gap(section_layout)

        populate_controls(controls_prepared)
        for prepared, draw_body in prepared_sections:
            body = _populate_srr_npanel_section(prepared)
            if body is not None:
                draw_body(body)


def _cross_editor_root_poll(cls, context):
    return _root_panel_poll(cls, context)


def _cross_editor_root_draw(self, context):
    """Delegate every physical root to the canonical View3D source body."""
    return SRR_PT_MAIN_PANEL.draw(self, context)


class SRR_IMAGE_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_IMAGE_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_NODE_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_NODE_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_SEQUENCER_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_SEQUENCER_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_CLIP_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_CLIP_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_DOPESHEET_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_DOPESHEET_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_GRAPH_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_GRAPH_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_NLA_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_NLA_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_TEXT_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_TEXT_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_FILEBROWSER_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_FILEBROWSER_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_SPREADSHEET_PT_ROOT(Panel):
    draw_header_preset = _draw_srr_root_header
    bl_idname = 'SRR_SPREADSHEET_PT_ROOT'
    bl_label = 'Smart Render'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = 'SMART_RENDER'
    _smart_tools_manager_disable_proxy = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_no_active_object_required = True
    _smart_tools_manager_cross_editor_safe = True
    _smart_render_full_body_root = True
    poll = classmethod(_cross_editor_root_poll)
    draw = _cross_editor_root_draw


class SRR_PT_dashboard(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "ダッシュボード"
    _srr_bl_label_en = "Dashboard"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _advanced_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        snapshot = get_scene_snapshot(scene)
        camera_count = int(snapshot.get("camera_count", 0) or 0)
        layer_count = int(snapshot.get("view_layer_count", 0) or 0)
        queue_count = int(snapshot.get("queue_count", 0) or 0)
        planned_renders = int(snapshot.get("planned_render_count", 0) or 0)
        output_root = str(snapshot.get("output_root", "") or getattr(settings, "output_root", "") or "—")
        path_ready = bool(snapshot.get("output_path_ready", False))
        analysis_status = getattr(scene, "srr_last_analysis_status", "NOT_RUN") or "NOT_RUN"
        analysis_icon = icon_for_status(analysis_status)
        analysis_time = getattr(scene, "srr_last_analysis_time", "") or "—"
        last_collision_count = getattr(scene, "srr_last_collision_count", 0)
        last_missing_asset_count = getattr(scene, "srr_last_missing_asset_count", 0)
        last_risk_score = getattr(scene, "srr_last_risk_score", 0)
        last_render_lines, last_render_failed = render_summary_lines(getattr(scene, "srr_last_render_summary", "") or "—", settings)
        counted = bool(snapshot.get("available", False))
        effective_compositing_mode = str(snapshot.get("effective_compositing_mode", "") or getattr(settings, "queue_compositing_mode", "AUTO"))
        requested_compositing_mode = str(snapshot.get("requested_compositing_mode", "") or getattr(settings, "queue_compositing_mode", "AUTO")).upper()
        effective_verify_scope = str(snapshot.get("effective_verification_scope", "") or getattr(settings, "verification_scope", "PRIMARY_AND_PASSES"))
        compositing_display = f"{requested_compositing_mode} → {effective_compositing_mode}" if requested_compositing_mode != effective_compositing_mode else effective_compositing_mode
        device_preview = dict(snapshot.get("device_preview", {}) or {})
        device_display = str(device_preview.get("display", getattr(settings, "execution_device_mode", "AUTO")) or getattr(settings, "execution_device_mode", "AUTO"))

        grid = layout.box().column(align=True)
        status_card(grid, t(settings, "エンジン", "Engine"), scene.render.engine, 'SCENE')
        status_card(grid, t(settings, "品質", "Quality"), settings.quality_mode, 'MODIFIER')
        status_card(grid, t(settings, "実行デバイス", "Execution Plan Device"), device_display, 'SETTINGS', alert=bool(device_preview.get("bridge_only", False)), wide=(" → " in device_display))
        status_card(grid, t(settings, "チャンクサイズ", "Chunk Size"), getattr(settings, "frame_chunk_size", 1), 'SEQUENCE')
        status_card(grid, t(settings, "実効コンポジット", "Effective Compositing"), compositing_display, 'NODE_COMPOSITING', alert=(requested_compositing_mode != "AUTO" and requested_compositing_mode != effective_compositing_mode))
        status_card(grid, t(settings, "実効検証範囲", "Effective Verify Scope"), effective_verify_scope, 'RENDERLAYERS', alert=(effective_verify_scope != str(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES") or "PRIMARY_AND_PASSES")))
        status_card(grid, t(settings, "カメラ数", "Cameras"), camera_count if counted else "—", 'CAMERA_DATA', alert=(counted and camera_count == 0))
        status_card(grid, t(settings, "ビューレイヤー", "View Layers"), layer_count if counted else "—", 'RENDERLAYERS', alert=(counted and layer_count == 0))
        status_card(grid, t(settings, "バリアントとテイク数", "Variants"), len(scene.srr_variants), 'BOOKMARKS')
        status_card(grid, t(settings, "キュー件数", "Queue Jobs"), queue_count if counted else "—", 'PRESET', alert=(counted and queue_count == 0))
        status_card(grid, t(settings, "予定レンダー数", "Planned Renders"), planned_renders if counted else "—", 'SEQUENCE', alert=(counted and planned_renders == 0))
        status_card(grid, t(settings, "再開モード", "Resume Mode"), t(settings, "既存をスキップ" if getattr(settings, "skip_existing_frames", False) else "通常", "Skip Existing" if getattr(settings, "skip_existing_frames", False) else "Normal"), 'CHECKMARK')
        status_card(grid, t(settings, "出力検証", "Output Verification"), t(settings, "オン" if getattr(settings, "verify_outputs_after_render", True) else "オフ", "On" if getattr(settings, "verify_outputs_after_render", True) else "Off"), 'CHECKMARK')
        status_card(grid, t(settings, "検証範囲", "Verify Scope"), getattr(settings, "verification_scope", "PRIMARY_AND_PASSES"), 'RENDERLAYERS')
        status_card(grid, t(settings, "最小サイズKB", "Min Size KB"), int(getattr(settings, "min_output_size_kb", 0) or 0), 'FILE_CACHE')
        status_card(grid, t(settings, "検証再試行", "Verify Retries"), int(getattr(settings, "verification_retry_count", 0) or 0), 'FILE_REFRESH')
        status_card(grid, t(settings, "ムービー化", "Movie Encode"), t(settings, "オン" if getattr(settings, "enable_movie_encode", False) else "オフ", "On" if getattr(settings, "enable_movie_encode", False) else "Off"), 'SEQUENCE')
        status_card(grid, t(settings, "保存先", "Output Root"), output_root, 'FILE_FOLDER', alert=(counted and not path_ready), wide=True)
        status_card(grid, t(settings, "監査状態", "Audit Status"), analysis_status, analysis_icon, alert=(analysis_status in {"WARNING", "ERROR"}))
        status_card(grid, t(settings, "リスクスコア", "Risk Score"), last_risk_score if analysis_status != "NOT_RUN" else "—", 'ERROR', alert=(last_risk_score >= 50))
        status_card(grid, t(settings, "衝突件数", "Collisions"), last_collision_count if analysis_status != "NOT_RUN" else "—", 'SORTALPHA', alert=(last_collision_count > 0))
        status_card(grid, t(settings, "欠落アセット", "Missing Assets"), last_missing_asset_count if analysis_status != "NOT_RUN" else "—", 'IMAGE_DATA', alert=(last_missing_asset_count > 0))
        status_card(grid, t(settings, "最終監査", "Last Audit"), analysis_time, 'TIME')
        status_card(grid, t(settings, "最終実行", "Last Queue Run"), last_render_lines, 'RENDER_ANIMATION', alert=last_render_failed, wide=True)


class SRR_PT_profile(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "レンダープロファイル"
    _srr_bl_label_en = "Render Profile"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        if not settings.show_advanced:
            box = layout.box()
            draw_prop(box, settings, settings, "compact_mode", "コンパクト表示", "Compact Mode", 'ALIGN_JUSTIFY')
            draw_prop(box, settings, settings, "show_advanced", "詳細項目を表示", "Show Advanced", 'PREFERENCES')

            core = layout.box()
            core.label(text=t(settings, "基本レンダー設定", "Core Render Settings"), icon='SCENE', translate=False)
            draw_prop(core, settings, settings, "engine_mode", "レンダーエンジン", "Render Engine", 'SCENE')
            draw_prop(core, settings, settings, "quality_mode", "品質プリセット", "Quality Preset", 'SCENE')
            draw_prop(core, settings, settings, "resolution_percentage", "解像度倍率", "Resolution Scale", 'IMAGE_DATA')
            draw_prop(core, settings, settings, "use_denoise", "ノイズ低減", "Denoise", 'SHADING_RENDERED')
            draw_prop(core, settings, settings, "use_motion_blur", "モーションブラー", "Motion Blur", 'MODIFIER')
            draw_prop(core, settings, settings, "pass_bundle", "パスバンドル", "Pass Bundle", 'RENDERLAYERS')
            draw_prop(core, settings, settings, "image_format", "画像形式", "Image Format", 'IMAGE_DATA')
            row = core.row(align=True)
            row.scale_y = 1.15
            row.operator("srr.apply_render_profile", text=t(settings, "基本設定を適用", "Apply Core Settings"), icon='CHECKMARK', translate=False)
            row.operator("srr.apply_pass_bundle", text=t(settings, "パスだけ適用", "Apply Passes"), icon='RENDERLAYERS', translate=False)
            return

        box = layout.box()
        draw_prop(box, settings, settings, "compact_mode", "コンパクト表示", "Compact Mode", 'ALIGN_JUSTIFY')
        draw_prop(box, settings, settings, "show_advanced", "詳細項目を表示", "Show Advanced", 'PREFERENCES')

        profile_box = layout.box()
        draw_prop(profile_box, settings, settings, "engine_mode", "レンダーエンジン", "Render Engine", 'SCENE')
        draw_prop(profile_box, settings, settings, "quality_mode", "品質プリセット", "Quality Preset", 'SCENE')
        draw_prop(profile_box, settings, settings, "sample_multiplier", "サンプル倍率", "Sample Multiplier", 'MODIFIER')
        draw_prop(profile_box, settings, settings, "resolution_percentage", "解像度倍率", "Resolution Scale", 'IMAGE_DATA')
        draw_prop(profile_box, settings, settings, "use_denoise", "ノイズ低減", "Denoise", 'SHADING_RENDERED')
        draw_prop(profile_box, settings, settings, "use_adaptive_sampling", "適応サンプリング", "Adaptive Sampling", 'MODIFIER')
        draw_prop(profile_box, settings, settings, "use_motion_blur", "モーションブラー", "Motion Blur", 'MODIFIER')
        draw_prop(profile_box, settings, settings, "use_freestyle", "線画", "Line Art", 'IPO_CONSTANT')
        draw_prop(profile_box, settings, settings, "pass_bundle", "パスバンドル", "Pass Bundle", 'RENDERLAYERS')
        draw_prop(profile_box, settings, settings, "image_format", "画像形式", "Image Format", 'IMAGE_DATA')

        row = profile_box.row(align=True)
        row.scale_y = 1.15
        row.operator("srr.apply_render_profile", text=t(settings, "レンダープロファイルを適用", "Apply Render Profile"), icon='CHECKMARK', translate=False)
        row = profile_box.row(align=True)
        row.scale_y = 1.15
        row.operator("srr.apply_pass_bundle", text=t(settings, "パスバンドルを適用", "Apply Passes"), icon='RENDERLAYERS', translate=False)



class SRR_PT_render_elements(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "レンダーエレメント"
    _srr_bl_label_en = "Render Elements"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return
        if not settings.render_elements_items_initialized:
            request_element_checks(scene)
        box = layout.box()
        box.label(text=t(settings, "3ds Max 風レンダーエレメント", "3ds Max style Render Elements"), icon='RENDERLAYERS', translate=False)
        draw_prop(box, settings, settings, "render_elements_enabled", "レンダーエレメントを有効化", "Enable Render Elements", 'CHECKMARK')
        draw_prop(box, settings, settings, "render_elements_output_mode", "出力モード", "Output Mode", 'IMAGE_DATA')
        draw_prop(box, settings, settings, "render_elements_preset", "クイックセット", "Quick Set", 'PRESET')

        quick_row = box.row(align=True)
        quick_row.operator("srr.apply_aov_quick_set", text=t(settings, "クイックセット読込", "Load Quick Set"), icon='IMPORT', translate=False).action = "LOAD_PRESET"
        quick_row = _button_flow(box)
        quick_row.operator("srr.apply_aov_quick_set", text=t(settings, "全部", "All"), icon='CHECKBOX_HLT', translate=False).action = "SELECT_ALL"
        quick_row.operator("srr.apply_aov_quick_set", text=t(settings, "ビューティーのみ", "Beauty Only"), icon='X', translate=False).action = "CLEAR"

        element_snapshot = dict(get_scene_snapshot(scene).get("render_elements", {}) or {})
        selected_count = int(element_snapshot.get("selected_count", 0) or 0)
        effective_bundle = str(element_snapshot.get("effective_bundle", "") or "BEAUTY")
        actual_format = str(element_snapshot.get("image_format", "") or getattr(settings, "image_format", ""))
        preview_names = list(element_snapshot.get("preview_names", []) or [])
        preview_total = int(element_snapshot.get("preview_name_count", len(preview_names)) or len(preview_names))
        preview_labels = [_element_label(settings, value) for value in preview_names[:8]]
        if preview_total > 8:
            preview_labels.append(t(settings, f"ほか {preview_total - 8} 件", f"+{preview_total - 8} more"))
        info_line(box, t(settings, f"選択エレメント数: {selected_count}", f"Selected elements: {selected_count}"), icon='RENDERLAYERS')
        info_line(box, t(settings, f"判定セット: {status_value_text(effective_bundle)}", f"Detected set: {status_value_text(effective_bundle)}"), icon='RENDERLAYERS')
        pass_folder = str(element_snapshot.get("pass_folder", "") or "—")
        info_line(box, t(settings, f"出力形式: {status_value_text(actual_format)}", f"Output format: {status_value_text(actual_format)}"), icon='IMAGE_DATA')
        info_line(box, t(settings, f"保存先: {pass_folder}", f"Folder: {pass_folder}"), icon='FILE_FOLDER')
        info_line(box, t(settings, "想定エレメント:", "Planned elements:"), icon='DOT')
        for line in _wrapped_name_lines(preview_labels, "、" if is_japanese_locale(settings) else ", ", wrap_units()):
            info_line(box, line, icon='BLANK1')
        if selected_count <= 0:
            info_line(box, t(settings, "未選択：ビューティーのみ", "No selection: Beauty only"), icon='ERROR')

        groups_layout = layout.column(align=True)
        column_count = 1
        for group_id, _label_ja, _label_en in RENDER_ELEMENT_GROUPS:
            _draw_render_element_group(groups_layout, settings, group_id, columns=column_count)

        row = layout.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.prepare_render_elements", text=t(settings, "レンダーエレメントを準備", "Prepare Render Elements"), icon='RENDERLAYERS', translate=False)
        row = layout.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.build_file_output_nodes", text=t(settings, "ノード更新", "Refresh Nodes"), icon='NODE_COMPOSITING', translate=False)


class SRR_PT_network_render(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "ネットワークレンダー"
    _srr_bl_label_en = "Network Render"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        box = layout.box()
        box.label(text=t(settings, "ネットワークレンダー出力", "Network Render Export"), icon='EXPORT', translate=False)
        draw_prop(box, settings, settings, "network_render_enabled", "ネットワーク用を有効化", "Enable Network Render", 'CHECKMARK')
        draw_prop(box, settings, settings, "network_render_target", "ネットワークターゲット", "Network Target", 'EXPORT')
        draw_prop(box, settings, settings, "frame_chunk_size", "フレーム分割", "Frame Chunk Size", 'SEQUENCE')
        draw_prop(box, settings, settings, "manifest_path", "書き出し先", "Export Path", 'FILE_SCRIPT')
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.prepare_network_render", text=t(settings, "ネットワークレンダーを準備", "Prepare Network Render"), icon='EXPORT', translate=False)
        if settings.show_advanced:
            row = box.row(align=True)
            row.scale_y = 1.1
            row.operator("srr.export_bridge_manifest", text=t(settings, "JSONのみ", "JSON Only"), icon='EXPORT', translate=False)


class SRR_PT_workflows(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "ワークフローレシピ"
    _srr_bl_label_en = "Workflow Recipes"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _advanced_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        recipe_box = layout.box()
        recipe_box.label(text=t(settings, "ワンクリック用途別レシピ", "One-click Workflow Recipes"), icon='PRESET', translate=False)
        recipe_grid = recipe_box.grid_flow(columns=1, even_columns=True, even_rows=True, align=True)
        for recipe_id, icon_name in [
            ("SAFE_REVIEW", 'IMAGE_DATA'),
            ("FINAL_EXR_COMPOSITE", 'NODE_COMPOSITING'),
            ("LOOKDEV_EXR", 'SHADING_RENDERED'),
            ("LIGHTING_BREAKDOWN", 'LIGHT'),
            ("NPR_LINEART", 'GREASEPENCIL'),
            ("DATASET_EXR", 'SEQ_SEQUENCER'),
            ("ANIMATIC_MOVIE", 'FILE_MOVIE'),
        ]:
            meta = workflow_recipe_meta(recipe_id)
            op = recipe_grid.operator("srr.apply_workflow_recipe", text=t(settings, meta["label_ja"], meta["label_en"]), icon=icon_name, translate=False)
            op.recipe_id = recipe_id


        repair_box = layout.box()
        repair_box.label(text=t(settings, "シーンの自動整理", "Safe Auto Repair Scene"), icon='FILE_REFRESH', translate=False)
        row = repair_box.row(align=True)
        row.scale_y = 1.15
        row.operator("srr.auto_repair_scene", text=t(settings, "安全に自動整理を実行", "Run Safe Auto Repair Scene"), icon='FILE_REFRESH', translate=False)

class SRR_PT_execution(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "実行計画"
    _srr_bl_label_en = "Execution Plan"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _advanced_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        box = layout.box()
        box.label(text=t(settings, "実行のヒント（共通）", "Execution Hints"), icon='SETTINGS', translate=False)
        draw_prop(box, settings, settings, "execution_device_mode", "実行デバイス方針", "Execution Plan Device", 'SETTINGS')
        device_preview = dict(get_scene_snapshot(scene).get("device_preview", {}) or {})
        if device_preview:
            if device_preview.get('bridge_only', False):
                info_line(box, t(settings, "このエンジンではヒントとして渡すだけです", "Passed on as a hint for this engine"), icon='DECORATE_OVERRIDE')
            else:
                info_line(box, t(settings, "この PC のレンダーにも使います", "Also used for local renders"), icon='CHECKMARK')
        draw_prop(box, settings, settings, "farm_priority", "優先度ヒント", "Priority Hint", 'SORTTIME')
        draw_prop(box, settings, settings, "frame_chunk_size", "フレーム分割単位", "Frame Chunk Size", 'SEQUENCE')

        if settings.show_advanced:
            advanced = layout.box()
            advanced.label(text=t(settings, "詳細な実行計画", "Advanced execution planning"), icon='PREFERENCES', translate=False)
            draw_prop(advanced, settings, settings, "concurrent_tasks", "同時タスク数ヒント", "Concurrent Tasks Hint", 'DECORATE_OVERRIDE')
            draw_prop(advanced, settings, settings, "memory_gb_hint", "メモリ見積り(GB)", "Memory Hint (GB)", 'MEMORY')
            draw_prop(advanced, settings, settings, "job_tags", "ジョブタグ", "Job Tags", 'BOOKMARKS')
            draw_prop(advanced, settings, settings, "temporal_subsamples", "時間サブサンプル", "Temporal Subsamples", 'TIME')
            draw_prop(advanced, settings, settings, "spatial_subsamples", "空間サブサンプル", "Spatial Subsamples", 'FULLSCREEN_EXIT')
            draw_prop(advanced, settings, settings, "accumulation_samples", "蓄積サンプル", "Accumulation Samples", 'MOD_PARTICLES')

        preview_box = layout.box()
        preview_box.label(text=t(settings, "実行プレビュー", "Execution Plan Preview"), icon='SEQUENCE', translate=False)
        preview_rows, total_jobs = _execution_preview_rows(context, scene, settings, limit=(2 if settings.compact_mode else 4))
        graph_preview = _execution_graph_preview(context, scene, settings)
        if preview_rows:
            movie_candidates = 0
            for row_data in preview_rows:
                preview_box.label(
                    text=t(
                        settings,
                        f"{row_data['label']} | {row_data['frame_count']} フレーム / 分割 {row_data['chunk_count']}",
                        f"{row_data['label']} | {row_data['frame_count']}f / {row_data['chunk_count']} chunk",
                    ),
                    icon='DOT',
                translate=False)
                if row_data["first_chunk"]:
                    preview_box.label(
                        text=t(settings, f"最初のチャンク: {row_data['first_chunk']}", f"First chunk: {row_data['first_chunk']}"),
                        icon='BLANK1',
                    translate=False)
                if row_data["movie_candidate"]:
                    movie_candidates += 1
            if total_jobs > len(preview_rows):
                preview_box.label(text=t(settings, f"ほか {total_jobs - len(preview_rows)} 件…", f"{total_jobs - len(preview_rows)} more…"), translate=False)
            if getattr(settings, "enable_movie_encode", False):
                preview_box.label(text=t(settings, f"FFmpeg ポストタスク候補: {movie_candidates}", f"FFmpeg post-task candidates: {movie_candidates}"), icon='FILE_MOVIE', translate=False)
            graph_box = layout.box()
            graph_box.label(text=t(settings, "推定タスクグラフ", "Estimated Task Graph"), icon='NODETREE', translate=False)
            info_line(graph_box, t(settings, f"レンダーのノード: {graph_preview['render_node_count']}", f"Render nodes: {graph_preview['render_node_count']}"), icon='RENDER_ANIMATION')
            info_line(graph_box, t(settings, f"検証のノード: {graph_preview['verify_node_count']}", f"Verify nodes: {graph_preview['verify_node_count']}"), icon='CHECKMARK')
            info_line(graph_box, t(settings, f"ムービーのノード: {graph_preview['movie_node_count']}", f"Movie nodes: {graph_preview['movie_node_count']}"), icon='FILE_MOVIE')
            info_line(graph_box, t(settings, f"依存エッジ: {graph_preview['edge_count']} / 深さ: {graph_preview['max_dependency_depth']}", f"Dependency edges: {graph_preview['edge_count']} / depth: {graph_preview['max_dependency_depth']}"), icon='LINKED')
        else:
            preview_box.label(text=t(settings, "有効なキューがまだありません。", "No enabled queue items yet."), translate=False)



class SRR_PT_variants(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "バリアントとテイク"
    _srr_bl_label_en = "Variants and Takes"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        if not settings.show_advanced:
            toolbar = layout.box()
            row = _button_flow(toolbar)
            row.scale_y = 1.05
            row.operator("srr.add_variant_from_current_state", text=t(settings, "新規保存", "Save Current"), icon='ADD', translate=False)
            row.operator("srr.capture_overrides", text=t(settings, "現在を反映", "Update From Current"), icon='IMPORT', translate=False)
            row = _button_flow(toolbar)
            row.scale_y = 1.05
            row.operator("srr.apply_variant", text=t(settings, "適用", "Apply"), icon='CHECKMARK', translate=False)
            row.operator("srr.remove_variant", text=t(settings, "削除", "Remove"), icon='TRASH', translate=False)
            mini = _button_flow(toolbar)
            mini.scale_y = 0.95
            mini.operator("srr.add_child_variant", text=t(settings, "子を追加", "Add Child"), icon='LINKED', translate=False)
            mini.operator("srr.duplicate_variant", text=t(settings, "複製", "Duplicate"), icon='SEQ_STRIP_DUPLICATE', translate=False)

            list_box = layout.box()
            list_row = list_box.row(align=True)
            list_row.template_list("SRR_UL_variants", "", scene, "srr_variants", scene, "srr_variant_index", rows=4)
            list_tools = list_row.column(align=True)
            list_tools.operator("srr.add_variant_from_current_state", text="", icon='ADD')
            list_tools.operator("srr.duplicate_variant", text="", icon='DUPLICATE')
            list_tools.operator("srr.remove_variant", text="", icon='REMOVE')
            if len(scene.srr_variants) == 0:
                list_box.label(text=t(settings, "バリアントがありません", "No variants yet"), translate=False)
                return

            variant_index = max(0, min(scene.srr_variant_index, len(scene.srr_variants) - 1))
            variant = scene.srr_variants[variant_index]
            variant_snapshot = get_variant_snapshot(scene, variant_index, getattr(variant, "name", ""))
            detail = layout.box()
            draw_prop(detail, settings, variant, "enabled", "有効", "Enabled", 'CHECKMARK')
            draw_prop(detail, settings, variant, "name", "名前", "Name", 'BOOKMARKS')
            draw_prop(detail, settings, variant, "description", "説明", "Description", 'TEXT')
            draw_prop_search(detail, settings, variant, "parent_variant_name", scene, "srr_variants", "親バリアントとテイク", "Parent Variant", 'LINKED')
            chain = list(variant_snapshot.get("chain", []) or [])
            if chain:
                info_line(detail, t(settings, f"継承チェーン: {' / '.join(chain)}", f"Inheritance chain: {' / '.join(chain)}"), icon='LINKED')
            draw_prop_search(detail, settings, variant, "camera_name", scene, "objects", "カメラ", "Camera", 'CAMERA_DATA')
            draw_prop_search(detail, settings, variant, "view_layer_name", scene, "view_layers", "ビューレイヤー", "View Layer", 'RENDERLAYERS')
            draw_prop(detail, settings, variant, "use_custom_frames", "専用フレーム範囲", "Custom Frames", 'TIME')
            if variant.use_custom_frames:
                draw_prop(detail, settings, variant, "frame_start", "開始フレーム", "Start Frame", 'TIME')
                draw_prop(detail, settings, variant, "frame_end", "終了フレーム", "End Frame", 'TIME')

            preview_box = detail.box()
            preview_box.label(text=t(settings, "このバリアントとテイクの出力例", "Variant Output Preview"), icon='FILE_FOLDER', translate=False)
            preview_paths = list(variant_snapshot.get("output_paths", []) or [])[:2]
            if preview_paths:
                for full_path in preview_paths:
                    preview_box.label(text=str(full_path), icon='DOT', translate=False)
            else:
                preview_box.label(text=t(settings, "プレビューできません", "No preview yet"), translate=False)

            return

        toolbar = layout.box()
        row = toolbar.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.add_variant_from_current_state", text=t(settings, "現在状態からバリアントを追加", "Add From Current"), icon='ADD', translate=False)
        row = _button_flow(toolbar)
        row.scale_y = 1.05
        row.operator("srr.add_child_variant", text=t(settings, "子を追加", "Add Child"), icon='LINKED', translate=False)
        row.operator("srr.duplicate_variant", text=t(settings, "複製", "Duplicate"), icon='SEQ_STRIP_DUPLICATE', translate=False)
        row.operator("srr.remove_variant", text=t(settings, "削除", "Remove"), icon='TRASH', translate=False)
        row = toolbar.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.capture_overrides", text=t(settings, "オーバーライドを取り込み", "Capture Current"), icon='IMPORT', translate=False)
        row = toolbar.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.apply_variant", text=t(settings, "バリアントを適用", "Apply Variant"), icon='CHECKMARK', translate=False)

        list_box = layout.box()
        list_row = list_box.row(align=True)
        list_row.template_list("SRR_UL_variants", "", scene, "srr_variants", scene, "srr_variant_index", rows=5)
        list_tools = list_row.column(align=True)
        list_tools.operator("srr.add_variant_from_current_state", text="", icon='ADD')
        list_tools.operator("srr.duplicate_variant", text="", icon='DUPLICATE')
        list_tools.operator("srr.remove_variant", text="", icon='REMOVE')

        if len(scene.srr_variants) == 0:
            list_box.label(text=t(settings, "バリアントがありません", "No variants yet"), translate=False)
            return

        variant_index = max(0, min(scene.srr_variant_index, len(scene.srr_variants) - 1))
        variant = scene.srr_variants[variant_index]
        variant_snapshot = get_variant_snapshot(scene, variant_index, getattr(variant, "name", ""))
        detail = layout.box()
        draw_prop(detail, settings, variant, "enabled", "有効", "Enabled", 'CHECKMARK')
        draw_prop(detail, settings, variant, "name", "名前", "Name", 'BOOKMARKS')
        draw_prop(detail, settings, variant, "description", "説明", "Description", 'TEXT')
        draw_prop_search(detail, settings, variant, "parent_variant_name", scene, "srr_variants", "親バリアントとテイク", "Parent Variant", 'LINKED')
        chain = list(variant_snapshot.get("chain", []) or [])
        if chain:
            info_line(detail, t(settings, f"継承チェーン: {' / '.join(chain)}", f"Inheritance chain: {' / '.join(chain)}"), icon='LINKED')
            resolved_path = str(variant_snapshot.get("path", "") or getattr(variant, "name", ""))
            info_line(detail, t(settings, f"解決テイクパス: {resolved_path}", f"Resolved take path: {resolved_path}"), icon='BOOKMARKS')
        draw_prop_search(detail, settings, variant, "camera_name", scene, "objects", "カメラ", "Camera", 'CAMERA_DATA')
        draw_prop_search(detail, settings, variant, "view_layer_name", scene, "view_layers", "ビューレイヤー", "View Layer", 'RENDERLAYERS')
        if variant_snapshot:
            info_line(detail, t(settings, f"解決カメラ: {variant_snapshot.get('camera_name', '') or 'シーンのカメラ'}", f"Resolved Camera: {variant_snapshot.get('camera_name', '') or 'Scene Camera'}"), icon='CAMERA_DATA')
            info_line(detail, t(settings, f"解決レイヤー: {variant_snapshot.get('view_layer_name', '') or 'アクティブなビューレイヤー'}", f"Resolved layer: {variant_snapshot.get('view_layer_name', '') or 'Active View Layer'}"), icon='RENDERLAYERS')
            info_line(detail, t(settings, f"解決解像度: {variant_snapshot.get('resolution_x', 0)} x {variant_snapshot.get('resolution_y', 0)}", f"Resolved resolution: {variant_snapshot.get('resolution_x', 0)} x {variant_snapshot.get('resolution_y', 0)}"), icon='IMAGE_DATA')
        draw_prop(detail, settings, variant, "engine_mode", "エンジン上書き", "Engine Override", 'SCENE')
        draw_prop(detail, settings, variant, "quality_mode", "品質上書き", "Quality Override", 'SCENE')
        draw_prop(detail, settings, variant, "resolution_percentage_override", "解像度上書き", "Resolution Override", 'IMAGE_DATA')
        draw_prop(detail, settings, variant, "resolution_x_override", "横解像度上書き", "Width Override", 'IMAGE_DATA')
        draw_prop(detail, settings, variant, "resolution_y_override", "縦解像度上書き", "Height Override", 'IMAGE_DATA')
        draw_prop(detail, settings, variant, "sample_multiplier_override", "サンプル倍率上書き", "Sample Override", 'MODIFIER')
        draw_prop(detail, settings, variant, "denoise_mode", "デノイズ上書き", "Denoise Override", 'SHADING_RENDERED')
        draw_prop(detail, settings, variant, "adaptive_sampling_mode", "適応サンプリング上書き", "Adaptive Override", 'MODIFIER')
        draw_prop(detail, settings, variant, "motion_blur_mode", "MB上書き", "Motion Blur Override", 'MODIFIER')
        draw_prop(detail, settings, variant, "freestyle_mode", "Freestyle上書き", "Freestyle Override", 'IPO_CONSTANT')
        draw_prop(detail, settings, variant, "pass_bundle", "パスバンドル上書き", "Pass Bundle Override", 'RENDERLAYERS')
        draw_prop(detail, settings, variant, "image_format_override", "形式上書き", "Format Override", 'IMAGE_DATA')
        draw_prop(detail, settings, variant, "use_custom_frames", "専用フレーム範囲", "Custom Frames", 'TIME')
        if variant.use_custom_frames:
            draw_prop(detail, settings, variant, "frame_start", "開始フレーム", "Start Frame", 'TIME')
            draw_prop(detail, settings, variant, "frame_end", "終了フレーム", "End Frame", 'TIME')
        draw_prop(detail, settings, variant, "material_override_mode", "マテリアル適用モード", "Material Override Mode", 'MATERIAL')
        if getattr(variant, "material_override_mode", "SCENE") == "OVERRIDE":
            draw_prop_search(detail, settings, variant, "material_override_name", bpy.data, "materials", "マテリアルオーバーライド", "Material Override", 'MATERIAL')
        draw_prop(detail, settings, variant, "world_override_mode", "ワールド適用モード", "World Override Mode", 'WORLD')
        if getattr(variant, "world_override_mode", "SCENE") == "OVERRIDE":
            draw_prop_search(detail, settings, variant, "world_override_name", bpy.data, "worlds", "ワールド上書き", "World Override", 'WORLD')
        draw_prop(detail, settings, variant, "collection_override_mode", "コレクション適用モード", "Collection Override Mode", 'OUTLINER_COLLECTION')
        if getattr(variant, "collection_override_mode", "SCENE") != "SCENE":
            draw_prop(detail, settings, variant, "include_collections", "表示に戻すコレクション", "Collections To Unhide", 'OUTLINER_COLLECTION')
            draw_prop(detail, settings, variant, "exclude_collections", "除外するコレクション", "Collections To Exclude", 'OUTLINER_COLLECTION')
            draw_prop(detail, settings, variant, "holdout_collections", "Holdout Collection", "Collections To Holdout", 'MOD_MASK')
            draw_prop(detail, settings, variant, "indirect_only_collections", "Indirect Only Collection", "Collections Indirect Only", 'LIGHT')
            if any(str(getattr(variant, prop_name, "") or "").strip() for prop_name in ("include_collections", "exclude_collections", "holdout_collections", "indirect_only_collections")):
                collection_preview = detail.box()
                collection_preview.label(text=t(settings, "コレクションのセレクターの確認", "Collection Selector Preview"), icon='OUTLINER_COLLECTION', translate=False)
                selector_data = dict(variant_snapshot.get("selectors", {}) or {})
                _draw_cached_selector_preview(collection_preview, settings, "表示に戻すコレクション", "Collections To Unhide", selector_data.get("include_collections"), icon='HIDE_OFF')
                _draw_cached_selector_preview(collection_preview, settings, "除外するコレクション", "Collections To Exclude", selector_data.get("exclude_collections"), icon='HIDE_ON')
                _draw_cached_selector_preview(collection_preview, settings, "Holdout Collection", "Collections To Holdout", selector_data.get("holdout_collections"), icon='MOD_MASK')
                _draw_cached_selector_preview(collection_preview, settings, "Indirect Only Collection", "Collections Indirect Only", selector_data.get("indirect_only_collections"), icon='LIGHT')
        draw_prop(detail, settings, variant, "object_visibility_override_mode", "オブジェクト可視モード", "Object Visibility Mode", 'OUTLINER_OB_EMPTY')
        if getattr(variant, "object_visibility_override_mode", "SCENE") != "SCENE":
            draw_prop(detail, settings, variant, "show_objects", "表示に戻すオブジェクト", "Objects To Show", 'HIDE_OFF')
            draw_prop(detail, settings, variant, "hide_objects", "隠すオブジェクト", "Objects To Hide", 'HIDE_ON')
            if any(str(getattr(variant, prop_name, "") or "").strip() for prop_name in ("show_objects", "hide_objects")):
                object_preview = detail.box()
                object_preview.label(text=t(settings, "オブジェクトのセレクターの確認", "Object Selector Preview"), icon='OUTLINER_OB_EMPTY', translate=False)
                selector_data = dict(variant_snapshot.get("selectors", {}) or {})
                _draw_cached_selector_preview(object_preview, settings, "表示に戻すオブジェクト", "Objects To Show", selector_data.get("show_objects"), icon='HIDE_OFF')
                _draw_cached_selector_preview(object_preview, settings, "隠すオブジェクト", "Objects To Hide", selector_data.get("hide_objects"), icon='HIDE_ON')
        draw_prop(detail, settings, variant, "representation_mode", '表現モード', "Representation Mode", 'OUTLINER_COLLECTION')
        if getattr(variant, "representation_mode", "SCENE") != "SCENE":
            draw_prop(detail, settings, variant, "proxy_collections", 'プロキシコレクション群', "Proxy Collections", 'OUTLINER_COLLECTION')
            draw_prop(detail, settings, variant, "render_collections", 'レンダーコレクション群', "Render Collections", 'OUTLINER_COLLECTION')
            if any(str(getattr(variant, prop_name, "") or "").strip() for prop_name in ("proxy_collections", "render_collections")):
                representation_preview = detail.box()
                representation_preview.label(text=t(settings, "表現切り替えのセレクターの確認", "Representation Selector Preview"), icon='OUTLINER_COLLECTION', translate=False)
                selector_data = dict(variant_snapshot.get("selectors", {}) or {})
                _draw_cached_selector_preview(representation_preview, settings, 'プロキシコレクション群', "Proxy Collections", selector_data.get("proxy_collections"), icon='OUTLINER_COLLECTION')
                _draw_cached_selector_preview(representation_preview, settings, 'レンダーコレクション群', "Render Collections", selector_data.get("render_collections"), icon='RESTRICT_RENDER_OFF')
        draw_prop(detail, settings, variant, "film_transparent_mode", "フィルム透過上書き", "Film Transparent Override", 'IMAGE_ALPHA')
        draw_prop(detail, settings, variant, "color_management_mode", "カラーマネジメント", "Color Management", 'COLOR')
        if getattr(variant, "color_management_mode", "SCENE") == "OVERRIDE":
            draw_prop(detail, settings, variant, "view_transform_override", "View Transform", "View Transform", 'COLOR')
            draw_prop(detail, settings, variant, "look_override", "Look", "Look", 'COLOR')
            draw_prop(detail, settings, variant, "use_exposure_override", "露出を上書き", "Override Exposure", 'COLOR')
            if getattr(variant, "use_exposure_override", False):
                draw_prop(detail, settings, variant, "exposure_override", "露出値", "Exposure", 'COLOR')
            draw_prop(detail, settings, variant, "use_gamma_override", "ガンマを上書き", "Override Gamma", 'COLOR')
            if getattr(variant, "use_gamma_override", False):
                draw_prop(detail, settings, variant, "gamma_override", "ガンマ値", "Gamma", 'COLOR')
        if settings.show_advanced:
            draw_prop(detail, settings, variant, "output_root_override", "保存先上書き", "Output Root Override", 'FILE_FOLDER')
            draw_prop(detail, settings, variant, "output_dir_pattern_override", "フォルダーパターン上書き", "Directory Pattern Override", 'NEWFOLDER')
            draw_prop(detail, settings, variant, "output_file_pattern_override", "ファイル名上書き", "File Pattern Override", 'FILE')
            draw_prop(detail, settings, variant, "stamp_note_override", "スタンプメモ上書き", "Stamp Note Override", 'TEXT')
            draw_prop(detail, settings, variant, "job_name_override", "ジョブ名上書き", "Job Name Override", 'FILE_FOLDER')
            draw_prop(detail, settings, variant, "job_tags_override", "ジョブタグ上書き", "Job Tags Override", 'BOOKMARKS')
            draw_prop(detail, settings, variant, "execution_device_mode_override", "実行デバイス上書き", "Execution Plan Device Override", 'SETTINGS')
            draw_prop(detail, settings, variant, "farm_priority_override", "優先度上書き", "Priority Override", 'SORTTIME')
            draw_prop(detail, settings, variant, "frame_chunk_size_override", "チャンクサイズ上書き", "Chunk Size Override", 'SEQUENCE')
            draw_prop(detail, settings, variant, "concurrent_tasks_override", "同時タスク数上書き", "Concurrent Tasks Override", 'DECORATE_OVERRIDE')
            draw_prop(detail, settings, variant, "memory_gb_hint_override", "メモリ見積り上書き", "Memory Override (GB)", 'MEMORY')
            draw_prop(detail, settings, variant, "temporal_subsamples_override", "時間サブサンプル上書き", "Temporal Subsamples Override", 'TIME')
            draw_prop(detail, settings, variant, "spatial_subsamples_override", "空間サブサンプル上書き", "Spatial Subsamples Override", 'FULLSCREEN_EXIT')
            draw_prop(detail, settings, variant, "accumulation_samples_override", "蓄積サンプル上書き", "Accumulation Samples Override", 'MOD_PARTICLES')
            info_line(detail, t(settings, f"解決実行: {status_value_text(variant_snapshot.get('execution_device', ''))} / 分割 {variant_snapshot.get('frame_chunk_size', 0)} / 優先度 {variant_snapshot.get('farm_priority', 0)}", f"Resolved execution: {variant_snapshot.get('execution_device', '')} / chunk {variant_snapshot.get('frame_chunk_size', 0)} / priority {variant_snapshot.get('farm_priority', 0)}"), icon='SETTINGS')

        preview_box = detail.box()
        preview_box.label(text=t(settings, "このバリアントとテイクの出力例", "Variant Output Preview"), icon='FILE_FOLDER', translate=False)
        preview_paths = list(variant_snapshot.get("output_paths", []) or [])[:3]
        if preview_paths:
            for full_path in preview_paths:
                preview_box.label(text=str(full_path), icon='DOT', translate=False)
        else:
            preview_box.label(text=t(settings, "プレビューできません", "No preview yet"), translate=False)



class SRR_PT_output(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "出力"
    _srr_bl_label_en = "Output"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        if getattr(getattr(scene, "rendernames", None), "enabled", False):
            from .rendernames.panels import RENDERNAMES_PT_NAMING
            from .ui_runtime import _call_draw

            _call_draw(RENDERNAMES_PT_NAMING.draw, RENDERNAMES_PT_NAMING, layout, context)

        if not settings.show_advanced:
            box = layout.box()
            draw_prop(box, settings, settings, "output_root", "親フォルダー", "Root Folder", 'FILE_FOLDER')
            draw_prop(box, settings, settings, "output_dir_pattern", "フォルダーパターン", "Directory Pattern", 'NEWFOLDER')
            draw_prop(box, settings, settings, "output_file_pattern", "ファイル名パターン", "File Pattern", 'FILE')
            draw_prop(box, settings, settings, "job_name", "ジョブ名", "Job Name", 'FILE_FOLDER')
            draw_prop(box, settings, settings, "skip_existing_frames", "既存フレームを再利用", "Skip Existing Frames", 'CHECKMARK')
            draw_prop(box, settings, settings, "auto_create_folders", "フォルダー自動作成", "Auto Create Folders", 'NEWFOLDER')
            draw_prop(box, settings, settings, "verify_outputs_after_render", "レンダー後に出力検証", "Verify Outputs After Render", 'CHECKMARK')
            if getattr(settings, "verify_outputs_after_render", True):
                draw_prop(box, settings, settings, "verification_scope", "検証対象", "Verification Scope", 'RENDERLAYERS')
                draw_prop(box, settings, settings, "min_output_size_kb", "最小サイズ(KB)", "Minimum Size (KB)", 'FILE_CACHE')

            movie_box = layout.box()
            movie_box.label(text=t(settings, "連番からムービー化", "Encode Movie From Frames"), icon='SEQUENCE', translate=False)
            draw_prop(movie_box, settings, settings, "enable_movie_encode", "ムービー化を有効", "Enable Movie Encode", 'RENDER_ANIMATION')
            if settings.enable_movie_encode:
                draw_prop(movie_box, settings, settings, "movie_preset", "ムービープリセット", "Movie Preset", 'SEQUENCE')
                draw_prop(movie_box, settings, settings, "movie_file_pattern", "ムービー名パターン", "Movie File Pattern", 'FILE_MOVIE')

            tools = layout.box()
            row = tools.row(align=True)
            row.scale_y = 1.1
            row.operator("srr.preview_output_paths", text=t(settings, "出力確認", "Preview Output Paths"), icon='FILE_FOLDER', translate=False)
            return

        box = layout.box()
        draw_prop(box, settings, settings, "output_root", "親フォルダー", "Root Folder", 'FILE_FOLDER')
        draw_prop(box, settings, settings, "output_dir_pattern", "フォルダーパターン", "Directory Pattern", 'NEWFOLDER')
        draw_prop(box, settings, settings, "output_file_pattern", "ファイル名パターン", "File Pattern", 'FILE')
        draw_prop(box, settings, settings, "job_name", "ジョブ名", "Job Name", 'FILE_FOLDER')
        draw_prop(box, settings, settings, "sequence_padding", "フレーム桁数", "Frame Padding", 'TIME')
        draw_prop(box, settings, settings, "overwrite_existing", "既存ファイル上書き", "Overwrite Existing", 'CHECKMARK')
        draw_prop(box, settings, settings, "skip_existing_frames", "既存フレームを再利用", "Skip Existing Frames", 'CHECKMARK')
        draw_prop(box, settings, settings, "use_placeholder", "プレースホルダー", "Placeholder", 'FILE')
        draw_prop(box, settings, settings, "auto_create_folders", "フォルダー自動作成", "Auto Create Folders", 'NEWFOLDER')
        draw_prop(box, settings, settings, "auto_unique_tokens", "自動一意化トークン", "Auto Unique Tokens", 'SORTALPHA')
        draw_prop(box, settings, settings, "abort_on_collisions", "衝突時は中止", "Abort On Collisions", 'CANCEL')
        draw_prop(box, settings, settings, "strict_missing_assets", "欠落アセットをエラー扱い", "Strict Missing Assets", 'ERROR')
        draw_prop(box, settings, settings, "use_stamp", "画像スタンプ", "Image Stamp", 'FONT_DATA')
        if settings.use_stamp:
            draw_prop(box, settings, settings, "stamp_note", "スタンプメモ", "Stamp Note", 'TEXT')

        tools = layout.box()
        row = tools.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.preview_output_paths", text=t(settings, "出力パスを確認", "Preview Output Paths"), icon='FILE_FOLDER', translate=False)
        row = tools.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.build_file_output_nodes", text=t(settings, "ファイル出力ノードを構築", "Build File Output Nodes"), icon='NODE_COMPOSITING', translate=False)


        movie_box = layout.box()
        movie_box.label(text=t(settings, "連番からムービー化", "Encode Movie From Frames"), icon='SEQUENCE', translate=False)
        draw_prop(movie_box, settings, settings, "enable_movie_encode", "ムービー化を有効", "Enable Movie Encode", 'RENDER_ANIMATION')
        if settings.enable_movie_encode:
            draw_prop(movie_box, settings, settings, "movie_preset", "ムービープリセット", "Movie Preset", 'SEQUENCE')
            draw_prop(movie_box, settings, settings, "movie_file_pattern", "ムービー名パターン", "Movie File Pattern", 'FILE_MOVIE')
            draw_prop(movie_box, settings, settings, "movie_overwrite_existing", "既存ムービー上書き", "Overwrite Existing Movie", 'CHECKMARK')
            if settings.show_advanced:
                draw_prop(movie_box, settings, settings, "ffmpeg_executable", "FFmpeg コマンド", "FFmpeg Command", 'CONSOLE')

        verify_box = layout.box()
        verify_box.label(text=t(settings, "出力検証と失敗防止", "Output Verification Guard"), icon='CHECKMARK', translate=False)
        draw_prop(verify_box, settings, settings, "verify_outputs_after_render", "レンダー後に出力検証", "Verify Outputs After Render", 'CHECKMARK')
        if getattr(settings, "verify_outputs_after_render", True):
            draw_prop(verify_box, settings, settings, "verification_scope", "検証対象", "Verification Scope", 'RENDERLAYERS')
            draw_prop(verify_box, settings, settings, "min_output_size_kb", "最小サイズ(KB)", "Minimum Size (KB)", 'FILE_CACHE')
            draw_prop(verify_box, settings, settings, "verification_retry_count", "検証再試行回数", "Verification Retry Count", 'FILE_REFRESH')
            draw_prop(verify_box, settings, settings, "verification_retry_delay", "検証再試行待機(秒)", "Verification Retry Delay (s)", 'TIME')
            draw_prop(verify_box, settings, settings, "cleanup_invalid_outputs", "壊れた出力を削除して再試行", "Delete Invalid Outputs Before Retry", 'TRASH')

        token_box = layout.box()
        token_box.label(text=t(settings, "使用できるトークン", "Available Tokens"), icon='TEXT', translate=False)
        _draw_token_reference(token_box, settings)


class SRR_PT_batch(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "レンダーキュー"
    _srr_bl_label_en = "Render Queue"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        if not settings.show_advanced:
            controls = layout.box()
            draw_prop(controls, settings, settings, "queue_source_mode", "キューソース", "Queue Source", 'FILE_REFRESH')
            draw_prop(controls, settings, settings, "frame_mode", "フレーム範囲", "Frame Mode", 'TIME')
            if settings.frame_mode == "CUSTOM":
                draw_prop(controls, settings, settings, "custom_frame_start", "開始フレーム", "Start Frame", 'TIME')
                draw_prop(controls, settings, settings, "custom_frame_end", "終了フレーム", "End Frame", 'TIME')
            draw_prop(controls, settings, settings, "queue_compositing_mode", "コンポジット出力", "Queue Compositing", 'NODE_COMPOSITING')
            draw_prop(controls, settings, settings, "view_layer_mode", "ビューレイヤー展開", "View Layers", 'RENDERLAYERS')

            row = controls.row(align=True)
            row.scale_y = 1.15
            row.operator("srr.sync_render_queue", text=t(settings, "レンダーキューを同期", "Sync Render Queue"), icon='FILE_REFRESH', translate=False)
            row = controls.row(align=True)
            row.scale_y = 1.15
            row.operator("srr.run_render_queue", text=t(settings, "レンダーキューを実行", "Run Render Queue"), icon='RENDER_ANIMATION', translate=False)
            row.operator("srr.clear_render_queue", text="", icon='TRASH')

            list_box = layout.box()
            row = list_box.row(align=True)
            row.template_list("SRR_UL_queue", "", scene, "srr_queue", scene, "srr_queue_index", rows=5)
            tools = row.column(align=True)
            tools.operator("srr.add_queue_item", text="", icon='ADD')
            tools.operator("srr.duplicate_queue_item", text="", icon='DUPLICATE')
            tools.operator("srr.remove_queue_item", text="", icon='REMOVE')
            move_up = tools.operator("srr.move_queue_item", text="", icon='TRIA_UP')
            move_up.direction = 'UP'
            move_down = tools.operator("srr.move_queue_item", text="", icon='TRIA_DOWN')
            move_down.direction = 'DOWN'
            queue_items = scene.srr_queue
            planned_renders = _planned_render_count(scene, settings, queue_items)
            info_line(list_box, t(settings, f"予定レンダー数: {planned_renders}", f"Planned renders: {planned_renders}"), icon='SEQUENCE')
            if len(scene.srr_queue) > 0:
                index = max(0, min(scene.srr_queue_index, len(scene.srr_queue) - 1))
                item = scene.srr_queue[index]
                detail = layout.box()
                detail.label(text=t(settings, "選択中キュー項目", "Selected Queue Item"), icon='PRESET', translate=False)
                draw_prop(detail, settings, item, "enabled", "この行を有効", "Enabled", 'CHECKMARK')
                draw_prop(detail, settings, item, "label", "表示名", "Label", 'FONT_DATA')
                draw_prop(detail, settings, item, "source_mode", "ソース種別", "Source Type", 'PRESET')
                if getattr(item, "source_mode", "PAIR") == "VARIANT":
                    draw_prop_search(detail, settings, item, "variant_name", scene, "srr_variants", "バリアントとテイク", "Variant", 'BOOKMARKS')
                else:
                    draw_prop_search(detail, settings, item, "camera_name", scene, "objects", "カメラ", "Camera", 'CAMERA_DATA')
                    draw_prop_search(detail, settings, item, "view_layer_name", scene, "view_layers", "ビューレイヤー", "View Layer", 'RENDERLAYERS')
                queue_snapshot = get_queue_item_snapshot(scene, index)
                preview_box = detail.box()
                preview_box.label(text=t(settings, "選択行の出力例", "Selected Queue Preview"), icon='FILE_FOLDER', translate=False)
                preview_paths = list(queue_snapshot.get("output_paths", []) or [])[:2]
                if preview_paths:
                    for full_path in preview_paths:
                        preview_box.label(text=str(full_path), icon='DOT', translate=False)
                else:
                    preview_box.label(text=t(settings, "プレビューできません", "No preview yet"), translate=False)
            return

        controls = layout.box()
        draw_prop(controls, settings, settings, "queue_source_mode", "キューソース", "Queue Source", 'FILE_REFRESH')
        draw_prop(controls, settings, settings, "frame_mode", "フレーム範囲", "Frame Mode", 'TIME')
        draw_prop(controls, settings, settings, "queue_compositing_mode", "コンポジット出力", "Queue Compositing", 'NODE_COMPOSITING')
        if settings.frame_mode == "CUSTOM":
            draw_prop(controls, settings, settings, "custom_frame_start", "開始フレーム", "Start Frame", 'TIME')
            draw_prop(controls, settings, settings, "custom_frame_end", "終了フレーム", "End Frame", 'TIME')
        draw_prop(controls, settings, settings, "selected_cameras_only", "選択カメラのみ", "Selected Cameras Only", 'RESTRICT_SELECT_OFF')
        draw_prop(controls, settings, settings, "renderable_cameras_only", "レンダー可能カメラのみ", "Renderable Cameras Only", 'HIDE_OFF')
        draw_prop(controls, settings, settings, "view_layer_mode", "ビューレイヤー展開", "View Layers", 'RENDERLAYERS')
        draw_prop(controls, settings, settings, "retry_on_failure", "失敗時は再試行", "Retry On Failure", 'RECOVER_LAST')
        if settings.retry_on_failure:
            draw_prop(controls, settings, settings, "retry_count", "再試行回数", "Retry Count", 'TIME')
        draw_prop(controls, settings, settings, "halt_on_first_error", "最初の失敗で停止", "Halt On First Error", 'ERROR')

        row = controls.row(align=True)
        row.scale_y = 1.15
        row.operator("srr.sync_render_queue", text=t(settings, "レンダーキューを同期", "Sync Render Queue"), icon='FILE_REFRESH', translate=False)
        row = controls.row(align=True)
        row.scale_y = 1.15
        row.operator("srr.clear_render_queue", text=t(settings, "レンダーキューを削除", "Clear Render Queue"), icon='TRASH', translate=False)

        list_box = layout.box()
        row = list_box.row(align=True)
        row.template_list("SRR_UL_queue", "", scene, "srr_queue", scene, "srr_queue_index", rows=6)
        tools = row.column(align=True)
        tools.operator("srr.add_queue_item", text="", icon='ADD')
        tools.operator("srr.duplicate_queue_item", text="", icon='DUPLICATE')
        tools.operator("srr.remove_queue_item", text="", icon='REMOVE')
        move_up = tools.operator("srr.move_queue_item", text="", icon='TRIA_UP')
        move_up.direction = 'UP'
        move_down = tools.operator("srr.move_queue_item", text="", icon='TRIA_DOWN')
        move_down.direction = 'DOWN'

        queue_items = scene.srr_queue
        planned_renders = _planned_render_count(scene, settings, queue_items)
        info_line(list_box, t(settings, f"予定レンダー数: {planned_renders}", f"Planned renders: {planned_renders}"), icon='SEQUENCE')
        if len(queue_items) > 0:
            index = max(0, min(scene.srr_queue_index, len(queue_items) - 1))
            item = queue_items[index]
            detail = layout.box()
            detail.label(text=t(settings, "選択中キュー項目", "Selected Queue Item"), icon='PRESET', translate=False)
            draw_prop(detail, settings, item, "enabled", "この行を有効", "Enabled", 'CHECKMARK')
            draw_prop(detail, settings, item, "label", "表示名", "Label", 'FONT_DATA')
            draw_prop(detail, settings, item, "source_mode", "ソース種別", "Source Type", 'PRESET')
            if getattr(item, "source_mode", "PAIR") == "VARIANT":
                draw_prop_search(detail, settings, item, "variant_name", scene, "srr_variants", "バリアントとテイク", "Variant", 'BOOKMARKS')
                queue_snapshot = get_queue_item_snapshot(scene, index)
                info_line(detail, t(settings, f"解決カメラ: {queue_snapshot.get('camera_name', '') or 'シーンのカメラ'}", f"Resolved Camera: {queue_snapshot.get('camera_name', '') or 'Scene Camera'}"), icon='CAMERA_DATA')
                info_line(detail, t(settings, f"解決レイヤー: {queue_snapshot.get('view_layer_name', '') or 'アクティブなビューレイヤー'}", f"Resolved layer: {queue_snapshot.get('view_layer_name', '') or 'Active View Layer'}"), icon='RENDERLAYERS')
                frame_label = str(queue_snapshot.get("frame_label", "") or "")
                if frame_label:
                    info_line(detail, t(settings, f"解決フレーム: {frame_label}", f"Resolved frames: {frame_label}"), icon='TIME')
            else:
                draw_prop_search(detail, settings, item, "camera_name", scene, "objects", "カメラ", "Camera", 'CAMERA_DATA')
                draw_prop_search(detail, settings, item, "view_layer_name", scene, "view_layers", "ビューレイヤー", "View Layer", 'RENDERLAYERS')

            queue_snapshot = get_queue_item_snapshot(scene, index)
            preview_box = detail.box()
            preview_box.label(text=t(settings, "この行の出力例", "Queue Item Output Preview"), icon='FILE_FOLDER', translate=False)
            preview_paths = list(queue_snapshot.get("output_paths", []) or [])[:3]
            if preview_paths:
                for full_path in preview_paths:
                    preview_box.label(text=str(full_path), icon='DOT', translate=False)
            else:
                preview_box.label(text=t(settings, "プレビューできません", "No preview yet"), translate=False)



class SRR_PT_extra_tools(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "統合ツール"
    _srr_bl_label_en = "Integrated Tools"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _simple_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        tools_box = layout.box()
        tools_box.label(text=t(settings, "シンプル表示中の追加機能", "Extra tools for the simplified UI"), icon='PREFERENCES', translate=False)
        row = tools_box.row(align=True)
        row.scale_y = 1.05
        row.operator("srr.analyze_scene", text=t(settings, "診断", "Analyze"), icon='VIEWZOOM', translate=False)
        row = _button_flow(tools_box)
        row.scale_y = 1.05
        row.operator("srr.auto_repair_scene", text=t(settings, "シーンを自動整理", "Repair"), icon='FILE_REFRESH', translate=False)
        row.operator("srr.build_file_output_nodes", text=t(settings, "AOVノード", "AOV Nodes"), icon='NODE_COMPOSITING', translate=False)

        recipe_box = layout.box()
        recipe_box.label(text=t(settings, "ワークフローレシピ", "Workflow Recipes"), icon='PRESET', translate=False)
        recipe_row = recipe_box.row(align=True)
        recipe_row.scale_y = 1.05
        recipe_row.operator("srr.workflow_recipes", text=t(settings, "レシピを選んで適用", "Choose and Apply Recipe"), icon='PRESET', translate=False)
        recipe_row = recipe_box.row(align=True)
        recipe_row.scale_y = 1.05
        recipe_row.operator("srr.apply_pass_bundle", text=t(settings, "パスバンドルを適用", "Apply Passes"), icon='RENDERLAYERS', translate=False)

        bridge_box = layout.box()
        bridge_box.label(text=t(settings, "ブリッジ書き出し", "Bridge Export"), icon='EXPORT', translate=False)
        draw_prop(bridge_box, settings, settings, "bridge_target", "書き出しターゲット", "Bridge Target", 'EXPORT')
        draw_prop(bridge_box, settings, settings, "manifest_path", "マニフェスト保存先", "Manifest Path", 'FILE_SCRIPT')
        bridge_row = _button_flow(bridge_box)
        bridge_row.scale_y = 1.05
        bridge_row.operator("srr.export_manifest", text=t(settings, "共通", "Manifest"), icon='EXPORT', translate=False)
        bridge_row.operator("srr.export_bridge_manifest", text=t(settings, "ブリッジ", "Bridge JSON"), icon='EXPORT', translate=False)
        bridge_row = bridge_box.row(align=True)
        bridge_row.scale_y = 1.05
        bridge_row.operator("srr.export_headless_scripts", text=t(settings, "スクリプト", "Scripts"), icon='CONSOLE', translate=False)
        bridge_row = bridge_box.row(align=True)
        bridge_row.scale_y = 1.05
        bridge_row.operator("srr.import_manifest", text=t(settings, "インポート", "Import"), icon='IMPORT', translate=False)

        status = getattr(scene, "srr_last_analysis_status", "NOT_RUN") or "NOT_RUN"
        log_box = layout.box()
        log_box.label(text=t(settings, "ログと詳細表示", "Logs and Full UI"), icon=icon_for_status(status), translate=False)
        status_text = status_value_text(status, settings)
        info_line(log_box, t(settings, f"最新監査: {status_text} / ログ {len(scene.srr_logs)} 件", f"Last audit: {status_text} / {len(scene.srr_logs)} log(s)"), icon=icon_for_status(status))
        row = _button_flow(log_box)
        row.operator("srr.clear_logs", text=t(settings, "ログを削除", "Clear Logs"), icon='TRASH', translate=False)
        row.prop(settings, "show_advanced", text=t(settings, "元の詳細表示", "Show Full Advanced UI"), toggle=True, icon='PREFERENCES', translate=False)



class SRR_PT_bridge(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "ブリッジ"
    _srr_bl_label_en = "Bridge"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _advanced_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        box = layout.box()
        draw_prop(box, settings, settings, "manifest_path", "マニフェスト保存先", "Manifest Path", 'FILE_SCRIPT')
        draw_prop(box, settings, settings, "bridge_target", "書き出しターゲット", "Bridge Target", 'EXPORT')
        draw_prop(box, settings, settings, "preview_limit", "プレビュー件数", "Preview Limit", 'PRESET')
        draw_prop(box, settings, settings, "analysis_detail_limit", "監査詳細件数", "Audit Detail Limit", 'PRESET')

        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.export_manifest", text=t(settings, "汎用ブリッジ書き出し", "Export Generic Manifest"), icon='EXPORT', translate=False)
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.import_manifest", text=t(settings, "インポート", "Import"), icon='IMPORT', translate=False)
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.export_bridge_manifest", text=t(settings, "ターゲット別JSON書き出し", "Export Target Bridge JSON"), icon='EXPORT', translate=False)
        row = box.row(align=True)
        row.scale_y = 1.1
        row.operator("srr.export_headless_scripts", text=t(settings, "ヘッドレススクリプトを書き出し", "Export Headless Scripts"), icon='CONSOLE', translate=False)




class SRR_PT_logs(SRR_PropertiesPageMixin, Panel):
    _srr_bl_label_ja = "ログ"
    _srr_bl_label_en = "Logs"
    bl_label = source_text(_srr_bl_label_ja, _srr_bl_label_en)
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _smart_render_tab_active(context) and _advanced_ui_enabled(context)

    def draw(self, context):
        layout = self.layout
        scene, settings = _safe_scene_settings(context)
        if scene is None or settings is None:
            _draw_runtime_unavailable(layout)
            return

        row = layout.row(align=True)
        row.operator("srr.clear_logs", text=t(settings, "ログを削除", "Clear Logs"), icon='TRASH', translate=False)

        box = layout.box()
        box.template_list("SRR_UL_logs", "", scene, "srr_logs", scene, "srr_log_index", rows=8)
        if len(scene.srr_logs) == 0:
            empty_parts = (["ログはまだありません。", "先に「シーンを診断」を", "押してください。"] if is_japanese_locale(settings) else ["No logs yet. ", "Try Analyze Scene first."])
            for line in _wrapped_name_lines(empty_parts, "", wrap_units()):
                box.label(text=line, translate=False)
        elif 0 <= scene.srr_log_index < len(scene.srr_logs):
            item = scene.srr_logs[scene.srr_log_index]
            detail = box.column(align=True)
            detail.label(text=str(getattr(item, "timestamp", "")), translate=False)
            for line in wrapped_lines(stored_text(getattr(item, "message", "")), wrap_units()):
                detail.label(text=line, translate=False)


class _SRRPanelDrawProxy:
    def __init__(self, layout):
        self.layout = layout


def _set_foldout_operator_prop(op, prop_name: str) -> None:
    try:
        op.prop_name = str(prop_name or '')
    except Exception:
        pass


def _draw_srr_help_button(layout, help_key: str, *, tool_label: str = '') -> None:
    try:
        from .help_operator import draw_help_button
        draw_help_button(layout, str(help_key or ''), tool_label=str(tool_label or ''))
    except Exception:
        try:
            button_row = layout.row(align=True)
            button_row.scale_x = 0.82
            button_row.scale_y = 1.0
            button_row.label(text='', icon='QUESTION')
        except Exception:
            try:
                layout.label(text='', icon='QUESTION')
            except Exception:
                pass


def _draw_srr_section_gap(layout, *, factor: float = 0.22) -> None:
    """Top-level sections use Blender's compact native panel spacing."""
    return None


def _draw_srr_section_help_button(row, help_key: str, *, tool_label: str = '') -> None:
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    _draw_srr_help_button(row, help_key, tool_label=tool_label)


def _prepare_srr_npanel_section(layout, settings, prop_name: str, label_ja: str, label_en: str, *, icon: str = 'NONE', help_key: str = '', default_open: bool = False, container=None):
    """Create one Smart Render section box/header without drawing its body."""
    if layout is None:
        return None
    prop_name = str(prop_name or '').strip()
    try:
        opened = bool(getattr(settings, prop_name, bool(default_open))) if settings is not None and prop_name else bool(default_open)
    except Exception:
        opened = bool(default_open)

    label = t(settings, str(label_ja or label_en or prop_name), str(label_en or label_ja or prop_name))
    icon_name = str(icon or 'NONE') or 'NONE'
    try:
        box = container if container is not None else layout.box()
    except Exception:
        box = layout
    try:
        header = box.row(align=True)
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        header = box

    operator_id = 'srr.toggle_npanel_section'
    if prop_name:
        try:
            op = header.operator(operator_id, text='', icon='TRIA_DOWN' if opened else 'TRIA_RIGHT', emboss=True, depress=opened)
            _set_foldout_operator_prop(op, prop_name)
        except Exception:
            try:
                header.label(text='', icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
            except Exception:
                pass
        try:
            op = header.operator(operator_id, text=label, icon=icon_name, emboss=False, depress=opened, translate=False)
            _set_foldout_operator_prop(op, prop_name)
        except TypeError:
            try:
                op = header.operator(operator_id, text=label, icon=icon_name, emboss=False, translate=False)
                _set_foldout_operator_prop(op, prop_name)
            except Exception:
                try:
                    header.label(text=label, icon=icon_name, translate=False)
                except Exception:
                    pass
        except Exception:
            try:
                header.label(text=label, icon=icon_name, translate=False)
            except Exception:
                pass
    else:
        try:
            header.label(text='', icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
            header.label(text=label, icon=icon_name, translate=False)
        except Exception:
            pass

    _draw_srr_section_help_button(header, help_key or prop_name, tool_label=label)

    return {
        'box': box,
        'opened': bool(opened),
    }


def _populate_srr_npanel_section(prepared):
    if not isinstance(prepared, dict) or not prepared.get('opened'):
        return None
    box = prepared.get('box')
    if box is None:
        return None
    try:
        body = box.column(align=True)
        body.use_property_split = False
        body.use_property_decorate = False
        return body
    except Exception:
        return box


def _draw_srr_npanel_section(layout, settings, prop_name: str, label_ja: str, label_en: str, *, icon: str = 'NONE', help_key: str = '', default_open: bool = False, body_in_box: bool = True):
    del body_in_box
    return _populate_srr_npanel_section(
        _prepare_srr_npanel_section(
            layout,
            settings,
            prop_name,
            label_ja,
            label_en,
            icon=icon,
            help_key=help_key,
            default_open=default_open,
        )
    )


def _draw_smart_render_overview_body(layout, context, scene, settings) -> None:
    del context
    snapshot = get_scene_snapshot(scene)
    queue_count = int(snapshot.get("queue_count", 0) or 0)
    analysis_status = getattr(scene, "srr_last_analysis_status", "NOT_RUN") or "NOT_RUN"
    output_root = str(snapshot.get("output_root", "") or getattr(settings, "output_root", "") or "—")

    toolbar = layout.row(align=True)
    toolbar.scale_y = 1.10
    toolbar.prop(settings, "compact_mode", text="", icon='ALIGN_JUSTIFY', toggle=True)
    toolbar.prop(settings, "show_advanced", text="", icon='PREFERENCES', toggle=True)

    counted = bool(snapshot.get("available", False))
    grid = layout.box().column(align=True)
    status_card(grid, t(settings, "品質", "Quality"), settings.quality_mode, 'MODIFIER')
    status_card(grid, t(settings, "パス", "Passes"), settings.pass_bundle, 'RENDERLAYERS')
    status_card(grid, t(settings, "キュー件数", "Queue Jobs"), queue_count if counted else "—", 'PRESET', alert=(counted and queue_count == 0))
    status_card(grid, t(settings, "監査状態", "Audit"), analysis_status, icon_for_status(analysis_status), alert=(analysis_status in {"WARNING", "ERROR"}))

    prepare_row = layout.row(align=True)
    prepare_row.scale_y = 1.15
    prepare_row.operator("srr.prepare_scene_setup", text=t(settings, "シーン基本設定を準備", "Prepare Scene Setup"), icon='SETTINGS', translate=False)
    action_row = _button_flow(layout)
    action_row.scale_y = 1.15
    action_row.operator("srr.preview_output_paths", text=t(settings, "出力確認", "Preview Output Paths"), icon='FILE_FOLDER', translate=False)
    action_row.operator("srr.run_render_queue", text=t(settings, "レンダー開始", "Run Render Queue"), icon='RENDER_ANIMATION', translate=False)

    if bool(getattr(settings, 'show_advanced', False)):
        sync_row = layout.row(align=True)
        sync_row.operator("srr.sync_render_queue", text=t(settings, "レンダーキューを同期のみ", "Sync Render Queue"), icon='FILE_REFRESH', translate=False)
        extra = _button_flow(layout)
        extra.operator("srr.analyze_scene", text=t(settings, "診断のみ", "Analyze Only"), icon='VIEWZOOM', translate=False)
        extra.operator("srr.build_file_output_nodes", text=t(settings, "AOVノード更新", "Refresh AOV Nodes"), icon='NODE_COMPOSITING', translate=False)

    info_line(
        layout,
        t(settings, f"保存先: {output_root}", f"Output root: {output_root}"),
        icon='FILE_FOLDER',
    )


def _draw_panel_class_body(panel_cls: type, layout, context, settings=None) -> None:
    draw_fn = getattr(panel_cls, 'draw', None)
    if not callable(draw_fn):
        try:
            layout.label(text=t(settings, "描画関数がありません", "No draw function"), icon='ERROR', translate=False)
        except Exception:
            pass
        return
    try:
        draw_fn(_SRRPanelDrawProxy(layout), context)
    except Exception as exc:
        try:
            warn = layout.box()
            warn.alert = True
            warn.label(text=t(settings, "このセクションを表示できませんでした。", f"Section draw failed: {exc}"), icon='ERROR', translate=False)
        except Exception:
            pass


def _draw_integrated_tools_section_body(layout, context, settings=None) -> None:
    try:
        from . import ui_runtime as _ui_runtime
        draw_embedded = getattr(_ui_runtime, 'draw_embedded_tools_section', None)
        if callable(draw_embedded):
            try:
                draw_embedded(layout, context, draw_header=False)
            except TypeError:
                draw_embedded(layout, context)
            return
    except Exception as exc:
        try:
            warn = layout.box()
            warn.alert = True
            warn.label(text=t(settings, "ツールを表示できません", "Tools could not be drawn"), icon='ERROR', translate=False)
        except Exception:
            pass


def _srr_native_section_panel_poll(cls, context):
    del cls, context
    return False


_SRR_NATIVE_SECTION_PANELS = (
    SRR_PT_dashboard,
    SRR_PT_profile,
    SRR_PT_render_elements,
    SRR_PT_network_render,
    SRR_PT_workflows,
    SRR_PT_execution,
    SRR_PT_variants,
    SRR_PT_output,
    SRR_PT_batch,
    SRR_PT_extra_tools,
    SRR_PT_bridge,
    SRR_PT_logs,
)


for _srr_section_panel_cls in _SRR_NATIVE_SECTION_PANELS:
    try:
        _srr_section_panel_cls.poll = classmethod(_srr_native_section_panel_poll)
    except Exception:
        pass


_SRR_SECTION_SPECS_ALWAYS = (
    ('show_section_dashboard', 'ダッシュボード', 'Dashboard', 'VIEWZOOM', 'SRR_PT_dashboard', SRR_PT_dashboard, 'advanced'),
    ('show_section_render_profile', 'レンダープロファイル', 'Render Profile', 'SCENE', 'SRR_PT_profile', SRR_PT_profile, 'always'),
    ('show_section_render_elements', 'レンダーエレメント', 'Render Elements', 'RENDERLAYERS', 'SRR_PT_render_elements', SRR_PT_render_elements, 'always'),
    ('show_section_network_render', 'ネットワークレンダー', 'Network Render', 'EXPORT', 'SRR_PT_network_render', SRR_PT_network_render, 'always'),
    ('show_section_workflows', 'ワークフローレシピ', 'Workflow Recipes', 'PRESET', 'SRR_PT_workflows', SRR_PT_workflows, 'advanced'),
    ('show_section_execution', '実行計画', 'Execution Plan', 'SETTINGS', 'SRR_PT_execution', SRR_PT_execution, 'advanced'),
    ('show_section_variants', 'バリアントとテイク', 'Variants and Takes', 'BOOKMARKS', 'SRR_PT_variants', SRR_PT_variants, 'always'),
    ('show_section_output', '出力と検証', 'Output and Verification', 'FILE_FOLDER', 'SRR_PT_output', SRR_PT_output, 'always'),
    ('show_section_batch', 'レンダーキュー', 'Render Queue', 'SEQUENCE', 'SRR_PT_batch', SRR_PT_batch, 'always'),
    ('show_section_extra_tools', '追加ツール入口', 'Extra Tools Entry', 'TOOL_SETTINGS', 'SRR_PT_extra_tools', SRR_PT_extra_tools, 'simple'),
    ('show_section_bridge', 'ブリッジ', 'Bridge', 'EXPORT', 'SRR_PT_bridge', SRR_PT_bridge, 'advanced'),
    ('show_section_logs', 'ログ', 'Logs', 'TEXT', 'SRR_PT_logs', SRR_PT_logs, 'advanced'),
)


def _iter_srr_section_specs(settings):
    advanced = bool(getattr(settings, 'show_advanced', False)) if settings is not None else False
    for prop_name, label_ja, label_en, icon_name, help_key, panel_cls, visibility in _SRR_SECTION_SPECS_ALWAYS:
        if visibility == 'advanced' and not advanced:
            continue
        if visibility == 'simple' and advanced:
            continue
        yield prop_name, label_ja, label_en, icon_name, help_key, panel_cls


_BASE_UI_CLASSES = (
    SRR_UL_queue,
    SRR_UL_variants,
    SRR_UL_logs,
    SRR_PT_MAIN_PANEL,
    SRR_IMAGE_PT_ROOT,
    SRR_NODE_PT_ROOT,
    SRR_SEQUENCER_PT_ROOT,
    SRR_CLIP_PT_ROOT,
    SRR_DOPESHEET_PT_ROOT,
    SRR_GRAPH_PT_ROOT,
    SRR_NLA_PT_ROOT,
    SRR_TEXT_PT_ROOT,
    SRR_FILEBROWSER_PT_ROOT,
    SRR_SPREADSHEET_PT_ROOT,
)


def _panel_bl_idname(cls: type) -> str:
    return str(getattr(cls, 'bl_idname', '') or getattr(cls, '__name__', '') or '')


# Fixed physical roots are declared above. No Panel RNA class is cloned or rebuilt
# after module import.
IMAGE_EDITOR_UI_CLASSES = tuple()
UI_CLASSES = _BASE_UI_CLASSES


def _materialize_inherited_panel_callbacks(classes: tuple[type, ...]) -> None:
    panel_base = getattr(bpy.types, 'Panel', None)
    if panel_base is None:
        return
    for cls in tuple(classes or ()):  # type: ignore[arg-type]
        if not isinstance(cls, type):
            continue
        try:
            if not issubclass(cls, panel_base):
                continue
        except Exception:
            continue
        for callback_name in ('poll', 'draw_header'):
            try:
                if callback_name in getattr(cls, '__dict__', {}):
                    continue
                for base in getattr(cls, '__mro__', ())[1:]:
                    if base is object or base is panel_base:
                        continue
                    raw = getattr(base, '__dict__', {}).get(callback_name)
                    if raw is not None:
                        setattr(cls, callback_name, raw)
                        break
            except Exception:
                pass


_materialize_inherited_panel_callbacks(UI_CLASSES)

try:
    localize_class_attributes(UI_CLASSES)
except Exception:
    pass


def _normalize_smart_render_npanel_classes() -> None:
    """Keep the suite UI as ordinary 3D View Sidebar panels.

    Older SmartTools/Properties-host builds stored ``bl_context='render'`` on
    the shared page mixin. That context is for the Properties editor and can
    prevent Blender from materializing the category as a normal VIEW_3D/UI
    N-panel tab. Standard N-panel classes need only VIEW_3D + UI + category.
    """
    for cls in tuple(UI_CLASSES or ()):  # type: ignore[name-defined]
        if not isinstance(cls, type):
            continue
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        try:
            cls.bl_region_type = 'UI'
            cls.bl_category = 'Smart Render'
            if bool(getattr(cls, '_smart_render_full_body_root', False)):
                cls.bl_label = 'Smart Render'
            if 'bl_context' in getattr(cls, '__dict__', {}):
                delattr(cls, 'bl_context')
        except Exception:
            pass


_normalize_smart_render_npanel_classes()


# --- standard 3D View N-panel runtime ---
_SMART_RENDER_ADDON_KEY = 'smart_render_suite'
_SMART_RENDER_LABEL = 'Smart Render'
_SMART_RENDER_TOOLTIP = action_tooltip(
    "Smart Tools Managerで許可されたエディターの通常Nパネル内にある Smart Render カテゴリを表示します。",
    "Show the Smart Render category in the ordinary N-panel of editors allowed by Smart Tools Manager.",
    usage_ja="対象エディターでNキーを押し、Smart Tools Managerが許可したSmart Renderタブを選ぶとツールを使えます。",
    usage_en="Press N in the target editor and choose the Smart Render tab allowed by Smart Tools Manager to use the tools.",
    tip_ja="Nパネル標準のパネル登録だけを使用し、Blender標準のNパネル表示を使います。",
    tip_en="Only standard N-panel Panel registration is used; Blender's standard N-panel display is used.",
)
_SMART_RENDER_PANEL_CLASSES = tuple(
    cls for cls in UI_CLASSES
    if isinstance(cls, type)
    and issubclass(cls, bpy.types.Panel)
    and cls is not SRR_PT_PANEL_NAVIGATION
)
UI_CLASSES = tuple(cls for cls in UI_CLASSES if cls is not SRR_PT_PANEL_NAVIGATION)
try:
    SRR_PT_PANEL_NAVIGATION.poll = classmethod(lambda cls, context: False)
except Exception:
    pass


def activate_smart_render_pseudo_tab(context) -> bool:
    return _is_standard_npanel_context(context)


def deactivate_smart_render_pseudo_tab(context, *, restore_context: bool = True) -> bool:
    del context, restore_context
    return False


def reset_smart_render_pseudo_tab_state():
    return None


def _smart_render_tab_active(context) -> bool:
    return _is_standard_npanel_context(context)


def _smart_render_nav_button_active(context) -> bool:
    return _smart_render_tab_active(context)


def _smart_render_install_properties_nav():
    # Compatibility entry point kept for old wrappers. Nothing is installed here;
    # the real UI is registered directly through UI_CLASSES.
    return True


def _smart_render_uninstall_properties_nav():
    return True

_normalize_smart_render_npanel_classes()
