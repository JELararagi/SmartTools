# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Stale .blend data cleanup for Smart Render Suite.

The add-on stores its UI/runtime state in the external
CONFIG/Smart_Render_Suite/Smart_Render_Suite.json file.  Older development
builds and manager/proxy experiments could leave internal panel/proxy ID
properties in a .blend file.  Those properties are not part of the render data
model and must not be allowed to accumulate.

This module deliberately removes only narrowly identified Smart Render internal
proxy/panel metadata.  It does not touch render queues, variants, scene render
settings, Camera Plane objects, Render Naming state, or other Smart Tool suites'
functional proxy data.
"""

from dataclasses import dataclass
import time
from typing import Any, Iterable

import bpy
from bpy.app.handlers import persistent


ADDON_ID = "smart_render_suite"
_CONFIG_FILENAME = "Smart_Render_Suite.json"
_CLEANUP_INTERVAL_SECONDS = 8.0

# Exact ID-property keys that were used by old Smart Render panel/proxy/runtime
# builds and have no effect in current external-JSON based builds.
_EXACT_STALE_KEYS = {
    "_smart_render_suite_panel_proxy_state",
    "_smart_render_suite_proxy_state",
    "_smart_render_suite_proxy_data",
    "_smart_render_suite_npanel_proxy_state",
    "_smart_render_suite_sidebar_proxy_state",
    "_smart_render_suite_sidebar_anchor_state",
    "_smart_render_suite_panel_navigation_state",
    "_smart_render_suite_dynamic_panel_state",
    "_smart_render_suite_runtime_panel_state",
    "_smart_render_suite_runtime_token",
    "_smart_render_suite_registering",
    "smart_render_suite_panel_proxy_state",
    "smart_render_suite_proxy_state",
    "smart_render_suite_proxy_data",
    "smart_render_suite_npanel_proxy_state",
    "smart_render_suite_sidebar_proxy_state",
    "smart_render_suite_sidebar_anchor_state",
    "smart_render_suite_panel_navigation_state",
    "smart_render_suite_dynamic_panel_state",
    "smart_render_suite_runtime_panel_state",
    "smart_render_suite_runtime_token",
    "srr_panel_proxy_state",
    "srr_proxy_state",
    "srr_npanel_proxy_state",
    "srr_sidebar_proxy_state",
    "srr_sidebar_anchor_state",
    "srr_panel_navigation_state",
    "srr_dynamic_panel_state",
    "srr_runtime_panel_state",
    "srr_runtime_token",
    # Old WindowManager-only navigation helpers.  Current builds do not store
    # these in .blend; the active N-panel state lives in external JSON.
    "srr_properties_tab_active",
    "srr_properties_prev_context",
    "srr_properties_base_context",
}

# Registered Scene properties that are part of the current data model.  Never
# delete these when they appear as regular RNA/ID property storage in a scene.
_CURRENT_SCENE_STORAGE_KEYS = {
    "srr_settings",
    "srr_queue",
    "srr_queue_index",
    "srr_variants",
    "srr_variant_index",
    "srr_logs",
    "srr_log_index",
    "srr_last_analysis_time",
    "srr_last_analysis_status",
    "srr_last_collision_count",
    "srr_last_missing_asset_count",
    "srr_last_risk_score",
    "srr_last_render_summary",
}

# Smart Render owns none of the mesh/object proxy properties used by other Smart
# Tool suites such as Smart Modeling.  These prefixes are explicitly protected.
_PROTECTED_FOREIGN_PROXY_PREFIXES = (
    "ms_shape_",
    "smart_modeling_",
    "smart_uv_",
    "uv_suite_",
    "smart_paint_",
    "workspace_manager_",
)

_STALE_KEY_TOKENS = (
    "proxy",
    "panel",
    "anchor",
    "navigation",
    "sidebar",
    "dynamic",
    "runtime_token",
    "rna",
    "ui_type",
    "manager_proxy",
    "npanel_proxy",
    "n_panel_proxy",
)

_STALE_VALUE_TOKENS = (
    "smart_render_suite",
    "smart render",
    "srr_pt_",
    "srr_image_pt_",
    "smart_render_suite_pt_sidebar_anchor",
    "smart_render_suite_image_pt_sidebar_anchor",
    "smarttools_npanel_pt_smart_render_suite",
    "smarttools_pt_int",
)

_LAST_CLEANUP_AT = 0.0
_PENDING_TIMER = None
_INSTALLED = False
_LAST_REPORT: dict[str, Any] = {"removed": 0, "reason": "not_run"}


@dataclass(slots=True)
class CleanupItem:
    owner_type: str
    owner_name: str
    key: str
    value_preview: str


def _is_exiting() -> bool:
    try:
        return bool(getattr(getattr(bpy, "app", None), "is_exiting", False))
    except Exception:
        return False


def _safe_name(obj: Any) -> str:
    try:
        return str(getattr(obj, "name", "") or "")
    except Exception:
        return ""


def _safe_keys(obj: Any) -> tuple[str, ...]:
    try:
        return tuple(str(k) for k in obj.keys())
    except Exception:
        return ()


def _safe_value_preview(obj: Any, key: str) -> str:
    try:
        return repr(obj[key])[:240]
    except Exception:
        return ""


def _text_contains_any(text: str, tokens: Iterable[str]) -> bool:
    lower = str(text or "").lower()
    return any(token in lower for token in tokens)


def _foreign_proxy_key(key: str) -> bool:
    lower = str(key or "").lower()
    return lower.startswith(_PROTECTED_FOREIGN_PROXY_PREFIXES)


def _is_stale_smart_render_idprop(key: str, value_preview: str = "") -> bool:
    lower_key = str(key or "").lower()
    if not lower_key:
        return False
    if lower_key in _CURRENT_SCENE_STORAGE_KEYS:
        return False
    if _foreign_proxy_key(lower_key):
        return False
    if lower_key in _EXACT_STALE_KEYS:
        return True

    lower_value = str(value_preview or "").lower()
    combined = f"{lower_key} {lower_value}"

    # Old SmartTools proxy panel identifiers for Smart Render.  These are Python
    # UI routing remnants, not scene/render data.
    if lower_key.startswith("smarttools_npanel_pt_smart_render_suite"):
        return True
    if lower_key.startswith("smarttools_pt_int") and "smart_render" in combined:
        return True

    # Smart Tools Manager metadata is owned by the manager.  Smart Render only
    # removes manager proxy metadata when it explicitly targets Smart Render.
    if lower_key.startswith("_smart_tools_manager") or lower_key.startswith("smart_tools_manager"):
        return "smart_render" in combined and _text_contains_any(combined, _STALE_KEY_TOKENS)

    # Current Smart Render state keys are not broad-deleted.  Only internal
    # proxy/panel/anchor/runtime UI metadata is considered stale.
    if lower_key.startswith(("_smart_render_suite", "smart_render_suite", "_srr_", "srr_")):
        if _text_contains_any(lower_key, _STALE_KEY_TOKENS):
            return True
        if _text_contains_any(combined, _STALE_VALUE_TOKENS) and _text_contains_any(combined, _STALE_KEY_TOKENS):
            return True

    return False


def _iter_id_owners(*, thorough: bool) -> Iterable[tuple[str, Any]]:
    data = getattr(bpy, "data", None)
    if data is None:
        return ()

    # Low-cost owners are where UI/proxy metadata is normally stored.
    collection_names = ["scenes", "screens", "workspaces", "window_managers"]

    # Thorough passes run only on register/load/save and may also clean object or
    # data-block leftovers from old tests.  This is intentionally not used from
    # draw code or frequent viewport events.
    if thorough:
        collection_names += [
            "objects",
            "collections",
            "materials",
            "meshes",
            "node_groups",
            "texts",
            "images",
        ]

    for collection_name in collection_names:
        try:
            collection = getattr(data, collection_name, None)
        except Exception:
            collection = None
        if collection is None:
            continue
        try:
            iterator = tuple(collection)
        except Exception:
            continue
        for obj in iterator:
            yield collection_name, obj

    # Also check active editor Space ID properties; these can survive in screen
    # layouts but are not reached through bpy.data.* collections directly.
    try:
        for screen in tuple(getattr(data, "screens", ()) or ()):  # type: ignore[attr-defined]
            for area in tuple(getattr(screen, "areas", ()) or ()):  # type: ignore[attr-defined]
                for space in tuple(getattr(area, "spaces", ()) or ()):  # type: ignore[attr-defined]
                    yield f"spaces:{_safe_name(screen)}:{getattr(area, 'type', '')}", space
    except Exception:
        pass

    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        if wm is not None:
            yield "context_window_manager", wm
    except Exception:
        pass


def _remove_idprop(obj: Any, key: str) -> bool:
    try:
        del obj[key]
        return True
    except Exception:
        return False


def cleanup_stale_proxy_data(*, reason: str = "manual", thorough: bool = False, force: bool = False) -> dict[str, Any]:
    """Remove obsolete Smart Render proxy/panel metadata from the open .blend.

    The function is safe to call repeatedly.  It does not access arbitrary RNA
    class objects and therefore is safe for file-load/save maintenance.  It is a
    no-op during Blender shutdown.
    """
    global _LAST_CLEANUP_AT, _LAST_REPORT
    if _is_exiting():
        return dict(_LAST_REPORT)
    now = time.monotonic()
    if not force and (now - _LAST_CLEANUP_AT) < _CLEANUP_INTERVAL_SECONDS:
        return dict(_LAST_REPORT)
    _LAST_CLEANUP_AT = now

    removed_items: list[CleanupItem] = []
    scanned = 0
    for owner_type, obj in tuple(_iter_id_owners(thorough=thorough)):
        scanned += 1
        owner_name = _safe_name(obj)
        for key in _safe_keys(obj):
            preview = _safe_value_preview(obj, key)
            if not _is_stale_smart_render_idprop(key, preview):
                continue
            if _remove_idprop(obj, key):
                removed_items.append(CleanupItem(owner_type, owner_name, key, preview))

    _LAST_REPORT = {
        "reason": str(reason or "manual"),
        "thorough": bool(thorough),
        "scanned_owners": scanned,
        "removed": len(removed_items),
        "items": [{"owner_type": item.owner_type, "owner_name": item.owner_name, "key": item.key, "value_preview": item.value_preview} for item in removed_items[:60]],
    }
    return dict(_LAST_REPORT)


def get_last_cleanup_report() -> dict[str, Any]:
    return dict(_LAST_REPORT)


def request_cleanup(*, reason: str = "deferred", thorough: bool = False, delay: float = 0.35, force: bool = False) -> None:
    global _PENDING_TIMER
    if _is_exiting():
        return
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    if timers is None:
        return
    if _PENDING_TIMER is not None:
        try:
            if timers.is_registered(_PENDING_TIMER):
                return
        except Exception:
            pass

    def _timer():
        global _PENDING_TIMER
        _PENDING_TIMER = None
        try:
            cleanup_stale_proxy_data(reason=reason, thorough=thorough, force=force)
        except Exception:
            pass
        return None

    _PENDING_TIMER = _timer
    try:
        timers.register(_timer, first_interval=max(0.05, float(delay)))
    except Exception:
        _PENDING_TIMER = None


def _cancel_pending_timer() -> None:
    global _PENDING_TIMER
    if _PENDING_TIMER is None:
        return
    try:
        timers = getattr(getattr(bpy, "app", None), "timers", None)
        if timers is not None and timers.is_registered(_PENDING_TIMER):
            timers.unregister(_PENDING_TIMER)
    except Exception:
        pass
    _PENDING_TIMER = None


@persistent
def _load_post(_dummy=None):
    request_cleanup(reason="load_post", thorough=True, delay=0.45, force=True)


@persistent
def _save_pre(_dummy=None):
    # Remove already-left proxy data before it is written back to disk.
    try:
        cleanup_stale_proxy_data(reason="save_pre", thorough=True, force=True)
    except Exception:
        pass


@persistent
def _undo_redo_post(_dummy=None):
    request_cleanup(reason="undo_redo_post", thorough=False, delay=0.55, force=False)


def _append_once(handler_list: Any, callback: Any) -> None:
    try:
        if callback not in handler_list:
            handler_list.append(callback)
    except Exception:
        pass


def _remove_handler(handler_list: Any, callback: Any) -> None:
    try:
        while callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        pass


def install() -> None:
    global _INSTALLED
    # Stale-proxy cleanup remains available as an explicit maintenance API, but
    # it must not scan bpy.data, register file handlers, or schedule timers merely
    # because Smart Render is enabled. Remove residents left by older builds.
    _cancel_pending_timer()
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is not None:
        _remove_handler(getattr(handlers, "load_post", []), _load_post)
        _remove_handler(getattr(handlers, "save_pre", []), _save_pre)
        _remove_handler(getattr(handlers, "undo_post", []), _undo_redo_post)
        _remove_handler(getattr(handlers, "redo_post", []), _undo_redo_post)
    _INSTALLED = True


def uninstall() -> None:
    global _INSTALLED
    _cancel_pending_timer()
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is not None:
        _remove_handler(getattr(handlers, "load_post", []), _load_post)
        _remove_handler(getattr(handlers, "save_pre", []), _save_pre)
        _remove_handler(getattr(handlers, "undo_post", []), _undo_redo_post)
        _remove_handler(getattr(handlers, "redo_post", []), _undo_redo_post)
    _INSTALLED = False
