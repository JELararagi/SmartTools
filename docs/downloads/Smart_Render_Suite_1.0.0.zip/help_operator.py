# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Lightweight Help operator.

Only this small module is registered at startup.  The detailed popup content is
kept in help_content.py and is imported only from invoke/draw after the user
clicks a Help button.
"""

import unicodedata
from pathlib import Path

import bpy

from .translation import action_tooltip, localize_pair, source_text


_ERROR_POPUP_WIDTH_PX = 720
_ERROR_POPUP_SIDE_PADDING_PX = 88
_ERROR_POPUP_ICON_RESERVE_PX = 24
_ERROR_BREAK_CHARS = set(' \t,.;:!?、。・／/）)]}〉》」』ー-–—')

_HELP_PREVIEW_COLLECTION = None
_HELP_PENDING_PREVIEW_REMOVALS = []


def _help_icon_value() -> int:
    """Return 0 so Help buttons use Blender's standard QUESTION icon."""
    return 0


def unload_help_icon_preview() -> None:
    global _HELP_PREVIEW_COLLECTION
    _HELP_PREVIEW_COLLECTION = None


def _remove_help_preview_collection_later(pcoll) -> None:
    # No custom Help preview icon is used.  Keep this as a no-op so unregister
    # cannot invalidate icon ids still referenced by live UI buttons.
    return None


def _ui_scale(context) -> float:
    try:
        scale = float(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'ui_scale', 1.0))
    except Exception:
        scale = 1.0
    if scale <= 0:
        return 1.0
    return min(4.0, max(0.5, scale))


def _visual_width(value: str) -> int:
    total = 0
    for char in str(value or ''):
        if char == '\t':
            total += 4
        elif unicodedata.east_asian_width(char) in {'F', 'W'}:
            total += 2
        else:
            total += 1
    return total


def _text_width_px(value: str, context=None) -> float:
    text = str(value or '')
    if not text:
        return 0.0
    scale = _ui_scale(context)
    try:
        import blf  # type: ignore

        font_id = 0
        font_size = max(8, int(round(11 * scale)))
        try:
            blf.size(font_id, font_size)
        except TypeError:
            blf.size(font_id, font_size, 72)
        return float(blf.dimensions(font_id, text)[0])
    except Exception:
        return float(_visual_width(text)) * max(6.0, 7.2 * scale)


def _available_text_width_px(context=None, *, icon: str = 'NONE', popup_width_px: int = _ERROR_POPUP_WIDTH_PX) -> int:
    scale = _ui_scale(context)
    try:
        popup_width = max(320, int(popup_width_px or _ERROR_POPUP_WIDTH_PX))
    except Exception:
        popup_width = _ERROR_POPUP_WIDTH_PX
    reserved = int(round(_ERROR_POPUP_SIDE_PADDING_PX * scale))
    if icon and icon != 'NONE':
        reserved += int(round(_ERROR_POPUP_ICON_RESERVE_PX * scale))
    return max(220, popup_width - reserved)


def _split_light_popup_line(value: str, context=None, *, first_icon: str = 'NONE', popup_width_px: int = _ERROR_POPUP_WIDTH_PX) -> list[str]:
    line = str(value or '').strip()
    if not line:
        return []
    first_limit = _available_text_width_px(context, icon=first_icon, popup_width_px=popup_width_px)
    plain_limit = _available_text_width_px(context, icon='NONE', popup_width_px=popup_width_px)
    if _text_width_px(line, context) <= first_limit:
        return [line]
    output: list[str] = []
    remaining = line
    first = True
    guard = 0
    while remaining and guard < 10000:
        guard += 1
        limit = first_limit if first else plain_limit
        if _text_width_px(remaining, context) <= limit:
            output.append(remaining)
            break
        last_break = 0
        split_at = 0
        for index, char in enumerate(remaining, start=1):
            segment = remaining[:index]
            if _text_width_px(segment, context) > limit:
                split_at = last_break if last_break > 0 else max(1, index - 1)
                break
            if char.isspace() or char in _ERROR_BREAK_CHARS:
                last_break = index
        if split_at <= 0:
            split_at = len(remaining)
        emit = remaining[:split_at].strip()
        if not emit:
            emit = remaining[:1]
            split_at = 1
        output.append(emit)
        remaining = remaining[split_at:].strip()
        first = False
    return output or [line]


def _draw_light_wrapped(layout, text: str, *, icon: str = "NONE", context=None, popup_width_px: int = _ERROR_POPUP_WIDTH_PX) -> None:
    value = str(text or "").strip()
    if not value:
        return
    first = True
    for raw_line in value.replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        line = raw_line.strip()
        if not line:
            continue
        first_icon = icon if first else 'NONE'
        for segment in _split_light_popup_line(line, context, first_icon=first_icon, popup_width_px=popup_width_px):
            layout.label(text=segment, icon=icon if first else "NONE")
            first = False


class SMART_RENDER_SUITE_OT_help_popup(bpy.types.Operator):
    _sms_no_undo = True
    POPUP_WIDTH_PX = _ERROR_POPUP_WIDTH_PX

    bl_idname = "smart_render_suite.help"
    bl_label = "Help"
    bl_label = source_text("ヘルプ", "Help")
    bl_description = action_tooltip(
        "選択したツールの機能概要、使用方法、設定項目をポップアップで表示します。",
        "Show a popup with the selected tool's function overview, usage, and setting items.",
        usage_ja="各ツールまたはグループのヘルプボタンを押すと、その項目の機能・使い方・設定項目を表示します。",
        usage_en="Click a tool or group Help button to display that item's function, usage, and settings.",
        tip_ja="迷ったときは、対象セクションのヘルプを開くと設定の目的と操作手順を確認できます。",
        tip_en="When unsure, open the target section Help to check what each setting does and how to use it.",
    )
    bl_options = {"INTERNAL"}

    help_key: bpy.props.StringProperty(default="", options={"SKIP_SAVE"})
    tool_label: bpy.props.StringProperty(default="", options={"SKIP_SAVE"})

    @classmethod
    def description(cls, _context, _properties):
        return action_tooltip(
            "選択したツールの機能概要、使用方法、設定項目を表示します。",
            "Show the selected tool's function overview, usage, and setting items.",
            usage_ja="クリックすると、この項目専用のヘルプをポップアップで開きます。",
            usage_en="Click to open the help popup for this item.",
            tip_ja="機能の目的、基本的な使い方、関連設定を確認できます。",
            tip_en="Shows the feature purpose, basic usage, and related settings.",
        )

    def invoke(self, context, _event):
        # Popup invocation requires a live window/region.  Blender 5.1 may crash
        # inside ``invoke_popup`` when an INTERNAL operator is executed from a
        # background process or a non-UI automation context.
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return {'CANCELLED'}
        window = getattr(context, 'window', None)
        region = getattr(context, 'region', None)
        window_manager = getattr(context, 'window_manager', None)
        if window is None or region is None or window_manager is None:
            return {'CANCELLED'}
        return window_manager.invoke_popup(self, width=self.POPUP_WIDTH_PX)

    def execute(self, context):
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return {'CANCELLED'}
        return self.invoke(context, None)

    def draw(self, context):
        try:
            from . import help_content
            help_content.draw_help_popup(
                self.layout,
                context,
                str(self.help_key or ""),
                str(self.tool_label or ""),
                popup_width_px=self.POPUP_WIDTH_PX,
            )
        except Exception as exc:
            box = self.layout.box()
            box.alert = True
            _draw_light_wrapped(
                box,
                localize_pair("ヘルプの表示に失敗しました。", "Failed to draw help."),
                icon="ERROR",
                context=context,
                popup_width_px=self.POPUP_WIDTH_PX,
            )
            _draw_light_wrapped(
                box,
                str(exc),
                icon="ERROR",
                context=context,
                popup_width_px=self.POPUP_WIDTH_PX,
            )


def _operator_registered(idname: str) -> bool:
    # Avoid Operator.recursive RNA subclass lookup; Blender 5.1 can crash inside the
    # recursive RNA lookup during UI/menu callbacks and add-on reloads.
    try:
        module, op_name = str(idname).split('.', 1)
        return hasattr(getattr(bpy.ops, module), op_name)
    except Exception:
        return False


def draw_help_button(layout, help_key: str, *, text: str | None = None, tool_label: str = "", icon: str = "QUESTION"):
    """Draw a fixed-size question-icon-only Help button.

    The optional ``text`` and ``icon`` arguments are kept for compatibility with
    older call sites, but all visible N-panel help buttons intentionally show
    only the question-mark icon. Detailed explanations remain in the tooltip
    and popup body.
    """
    _ = text, icon
    kwargs = {"text": ""}
    icon_value = _help_icon_value()
    if icon_value:
        kwargs["icon_value"] = icon_value
    else:
        kwargs["icon"] = "QUESTION"
    try:
        button_layout = layout.row(align=True)
        button_layout.scale_x = 0.82
        button_layout.scale_y = 1.0
    except Exception:
        button_layout = layout
    if not _operator_registered(SMART_RENDER_SUITE_OT_help_popup.bl_idname):
        try:
            button_layout.label(text="", icon="QUESTION")
        except Exception:
            pass
        return None
    op = button_layout.operator(
        SMART_RENDER_SUITE_OT_help_popup.bl_idname,
        **kwargs,
    )
    op.help_key = str(help_key or "")
    op.tool_label = str(tool_label or "")
    return op


HELP_OPERATOR_CLASSES = (
    SMART_RENDER_SUITE_OT_help_popup,
)
