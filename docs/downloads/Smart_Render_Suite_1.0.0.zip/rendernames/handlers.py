

def _smarttools_console_output(*_args, **_kwargs):
    return None
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

# ============================================================================
# Render Naming - Handlers
# ============================================================================
# Blender event handlers for render path management
# Strategy: Set path before render, restore after render completes

import os
from types import SimpleNamespace

import bpy
from bpy.app.handlers import persistent

from . import template_engine
from . import pathing


# ============================================================================
# Handler Functions
# ============================================================================

@persistent
def on_render_init(scene):
    """
    Called before rendering starts.

    Apply the template to render.filepath, but store the original
    so we can restore it after rendering completes.
    """
    if not hasattr(scene, "rendernames"):
        return

    props = scene.rendernames

    if not props.enabled:
        return

    if not props.template:
        return

    try:
        # Store original path ONLY on first render_init call
        if "_rendernames_original_filepath" not in scene:
            scene["_rendernames_original_filepath"] = scene.render.filepath

        # Render the template
        rendered = template_engine.render_template(
            props.template,
            scene,
            props,
        )

        # Build full path
        full_path = pathing.build_output_path(scene, props, rendered, create=True)

        # Apply to render
        scene.render.filepath = full_path
        _smarttools_console_output(f"Render Naming: Set render path to: {full_path}")

    except Exception as e:
        _smarttools_console_output(f"Render Naming: Error in render_init: {e}")


@persistent
def on_render_complete(scene):
    """
    Called after rendering completes.

    Restore the original filepath that user had set.
    """
    if not hasattr(scene, "rendernames"):
        return

    props = scene.rendernames

    if not props.enabled:
        return

    try:
        # Restore original path
        if "_rendernames_original_filepath" in scene:
            original = scene["_rendernames_original_filepath"]
            scene.render.filepath = original
            _smarttools_console_output(f"Render Naming: Restored original path: {original}")
            # Clear the stored original
            del scene["_rendernames_original_filepath"]

    except Exception as e:
        _smarttools_console_output(f"Render Naming: Error in render_complete: {e}")


@persistent
def on_render_cancel(scene):
    """
    Called when rendering is cancelled.

    Restore the original filepath.
    """
    if not hasattr(scene, "rendernames"):
        return

    try:
        # Restore original path
        if "_rendernames_original_filepath" in scene:
            original = scene["_rendernames_original_filepath"]
            scene.render.filepath = original
            _smarttools_console_output(f"Render Naming: Render cancelled - restored path: {original}")
            # Clear the stored original
            del scene["_rendernames_original_filepath"]

    except Exception as e:
        _smarttools_console_output(f"Render Naming: Error in render_cancel: {e}")


# ============================================================================
# Lazy runtime initialization
# ============================================================================

_LAST_FILE_TOKEN: str | None = None
_timer_registered = False
_render_handlers_registered = False


def _current_file_token() -> str:
    try:
        filepath = str(getattr(bpy.data, "filepath", "") or "").strip()
    except Exception:
        filepath = ""
    return filepath if filepath else "__startup__"



def _context_like(scene):
    wm = None
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
    except Exception:
        wm = None
    return SimpleNamespace(scene=scene, window_manager=wm)



def ensure_runtime_initialized(context=None, *, force: bool = False) -> None:
    """
    Refresh preset lists only when the Render Naming UI or operators are actually used.

    This avoids doing scene-wide preset scanning on every Blender file load.
    """
    global _LAST_FILE_TOKEN
    token = _current_file_token()
    if not force and token == _LAST_FILE_TOKEN:
        return
    _LAST_FILE_TOKEN = token

    first_global_scene = None
    try:
        from . import presets, properties
    except Exception:
        return

    for scene in getattr(bpy.data, "scenes", ()):
        try:
            if "_rendernames_original_filepath" in scene:
                del scene["_rendernames_original_filepath"]
        except Exception:
            pass

        scene_props = getattr(scene, "rendernames", None)
        if scene_props is None:
            continue

        try:
            presets.refresh_preset_list(scene_props)
        except Exception:
            pass

        try:
            if scene_props.use_global_settings and first_global_scene is None:
                first_global_scene = scene
        except Exception:
            pass

    if first_global_scene is not None:
        ctx = _context_like(first_global_scene)
        if getattr(ctx, "window_manager", None) is not None:
            try:
                # During lazy RNA registration the Scene values can still be
                # class defaults while the canonical WindowManager group has
                # not yet been replayed.  Copying them here would clobber the
                # saved global Render Names preferences in memory.
                from .. import settings as _suite_settings
                if not _suite_settings.is_applying_context():
                    properties._save_to_global_settings(ctx)
            except Exception:
                pass


@persistent
def _load_post_initialize(_dummy=None) -> None:
    """Perform finite Render Naming normalization at the file boundary."""
    try:
        ensure_runtime_initialized(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass


# ============================================================================
# Timer for Preview Updates
# ============================================================================


def _preview_timer():
    """
    Timer function for periodic preview updates.

    It stays disabled by default and runs only when the user explicitly enables
    automatic preview refresh from the Render Naming UI.
    """
    global _timer_registered

    if not _should_run_preview_timer():
        _timer_registered = False
        return None

    try:
        context = bpy.context
        if context and context.scene and hasattr(context.scene, "rendernames"):
            props = context.scene.rendernames

            if not bool(getattr(props, "auto_refresh_preview", False)):
                return 5.0

            # Update preview
            if props.template:
                preview = template_engine.render_template(
                    props.template,
                    context.scene,
                    props,
                )

                if props.preview != preview:
                    props["preview"] = preview
    except Exception:
        pass

    return 5.0



def _should_run_preview_timer() -> bool:
    # The preview is already computed on property changes and while the
    # Render Naming panel draws, so a background timer no longer provides
    # extra user-facing value. Keep any legacy auto_refresh_preview=True from
    # re-registering a timer after file load or same-session add-on updates.
    return False



def sync_runtime_hooks(_context=None, *, force_disable: bool = False) -> None:
    global _timer_registered
    should_run = False if force_disable else _should_run_preview_timer()

    if should_run and not _timer_registered:
        try:
            bpy.app.timers.register(_preview_timer, first_interval=1.0)
            _timer_registered = True
        except Exception:
            _timer_registered = False
        return

    if not should_run:
        try:
            if hasattr(bpy.app.timers, 'is_registered') and bpy.app.timers.is_registered(_preview_timer):
                bpy.app.timers.unregister(_preview_timer)
        except Exception:
            try:
                bpy.app.timers.unregister(_preview_timer)
            except Exception:
                pass
        _timer_registered = False



# ============================================================================
# Render path hook registration
# ============================================================================


def _append_handler_once(sequence, callback) -> None:
    try:
        if callback not in sequence:
            sequence.append(callback)
    except Exception:
        pass


def _remove_handler_if_present(sequence, callback) -> None:
    try:
        if callback in sequence:
            sequence.remove(callback)
    except Exception:
        pass


def _should_run_render_path_hooks() -> bool:
    """Return True only when at least one scene explicitly enables Render Naming."""
    for scene in getattr(bpy.data, "scenes", ()):  # no imports, no scene scanning beyond current data
        props = getattr(scene, "rendernames", None)
        if props is None:
            continue
        try:
            if bool(getattr(props, "enabled", False)):
                return True
        except Exception:
            continue
    return False


def sync_render_path_hooks(_context=None, *, force_disable: bool = False) -> None:
    """Register render-event handlers only while the central Render Naming switch is on."""
    global _render_handlers_registered
    should_run = False if force_disable else _should_run_render_path_hooks()

    if should_run:
        _append_handler_once(bpy.app.handlers.render_init, on_render_init)
        _append_handler_once(bpy.app.handlers.render_complete, on_render_complete)
        _append_handler_once(bpy.app.handlers.render_cancel, on_render_cancel)
        _render_handlers_registered = True
        return

    if (not should_run) and (
        _render_handlers_registered
        or on_render_init in bpy.app.handlers.render_init
        or on_render_complete in bpy.app.handlers.render_complete
        or on_render_cancel in bpy.app.handlers.render_cancel
    ):
        _remove_handler_if_present(bpy.app.handlers.render_init, on_render_init)
        _remove_handler_if_present(bpy.app.handlers.render_complete, on_render_complete)
        _remove_handler_if_present(bpy.app.handlers.render_cancel, on_render_cancel)
        _render_handlers_registered = False


# ============================================================================
# Registration
# ============================================================================


def register():
    """Register lightweight runtime synchronization only."""
    # Preset refresh/default migration is a registration/load-boundary task.
    # It must never be triggered by Panel.draw, which can run continuously while
    # the user orbits or pans the viewport.
    ensure_runtime_initialized(getattr(bpy, 'context', None), force=True)
    # Loading this tool is already an explicit action. Initialization is done
    # once here; no load_post monitor remains while the feature is OFF.
    _remove_handler_if_present(bpy.app.handlers.load_post, _load_post_initialize)
    # Render-event handlers are attached only when the centralized Always-on
    # switch for Render Naming is enabled.  Disabled tools therefore remain UI-only.
    sync_render_path_hooks()
    sync_runtime_hooks()



def unregister():
    """Unregister handlers."""
    global _timer_registered, _LAST_FILE_TOKEN, _render_handlers_registered

    sync_render_path_hooks(force_disable=True)
    _remove_handler_if_present(bpy.app.handlers.load_post, _load_post_initialize)

    if _timer_registered:
        try:
            if bpy.app.timers.is_registered(_preview_timer):
                bpy.app.timers.unregister(_preview_timer)
        except Exception:
            pass
        _timer_registered = False

    _LAST_FILE_TOKEN = None
    _render_handlers_registered = False
