# SPDX-License-Identifier: GPL-3.0-or-later
"""Resolve SmartRender template tokens from a single Blender scene and clock."""

from datetime import datetime
import os
from pathlib import Path
import re

import bpy

from .pathing import default_rendernames_base

_DESCRIPTIONS = {
    "scene": "Scene name",
    "blend_file": "Name of the saved project, without the extension",
    "frame": "Start frame. Blender appends frame numbers when writing animation.",
    "frame_start": "Start of the output range",
    "frame_end": "End of the output range",
    "frame_range": "Start and end of the output range joined with a dash",
    "date": "Date as year-month-day",
    "time": "Time as hour-minute-second",
    "datetime": "Date and time joined with an underscore",
    "year": "Four-digit year",
    "month": "Two-digit month",
    "day": "Two-digit day",
    "camera": "Active camera, or no_camera",
    "resolution": "Output width and height joined with x",
    "width": "Output width before resolution scaling",
    "height": "Output height before resolution scaling",
    "percent": "Resolution scale as a percentage",
    "fps": "Frame rate",
    "format": "Output file format",
    "engine": "Render engine",
    "samples": "Sample count where available",
}
_TOKEN = re.compile(r"\{\{(\w+)\}\}")
_REMOVED = str.maketrans("", "", '<>:"/\\|?*')


def _get_samples(scene):
    engine = scene.render.engine
    if engine == "CYCLES":
        return str(scene.cycles.samples)
    if engine in {"BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"}:
        return str(getattr(scene.eevee, "taa_render_samples", 64))
    return "n/a"


def _source_values(scene, props, now):
    render = scene.render
    padding = props.frame_padding
    first = str(scene.frame_start).zfill(padding)
    last = str(scene.frame_end).zfill(padding)
    width, height = str(render.resolution_x), str(render.resolution_y)
    filepath = bpy.data.filepath
    getters = {
        "scene": lambda: scene.name,
        "blend_file": lambda: Path(filepath).stem if filepath else "untitled",
        "frame": lambda: first,
        "frame_start": lambda: first,
        "frame_end": lambda: last,
        "frame_range": lambda: "-".join((first, last)),
        "date": lambda: now.strftime("%Y-%m-%d"),
        "time": lambda: now.strftime("%H-%M-%S"),
        "datetime": lambda: now.strftime("%Y-%m-%d_%H-%M-%S"),
        "year": lambda: now.strftime("%Y"),
        "month": lambda: now.strftime("%m"),
        "day": lambda: now.strftime("%d"),
        "camera": lambda: scene.camera.name if scene.camera else "no_camera",
        "resolution": lambda: "x".join((width, height)),
        "width": lambda: width,
        "height": lambda: height,
        "percent": lambda: str(render.resolution_percentage),
        "fps": lambda: str(render.fps),
        "format": lambda: render.image_settings.file_format.lower(),
        "engine": lambda: render.engine.lower().replace("blender_", ""),
        "samples": lambda: _get_samples(scene),
    }
    return getters


def get_variable_names():
    return list(_DESCRIPTIONS)


def get_variable_descriptions():
    return dict(_DESCRIPTIONS)


def sanitize_string(value):
    clean = value.replace(" ", "_").translate(_REMOVED).strip(". ")
    return re.sub("_+", "_", clean)


def render_template(template, scene, props, sample=False):
    sources = _source_values(scene, props, datetime.now())

    def substitute(match):
        name = match[1]
        if name not in sources:
            return match[0]
        try:
            value = sources[name]()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            value = f"[{name}]"
        if props.sanitize_names:
            value = sanitize_string(value)
        return value.lower() if props.lowercase else value

    return _TOKEN.sub(substitute, template)


def get_full_render_path(scene, props, base_path=None):
    folder = default_rendernames_base() if base_path is None else base_path
    return bpy.path.abspath(os.path.join(folder, render_template(props.template, scene, props)))


def validate_template(template):
    if not template:
        return False, "Template cannot be empty"
    if template.count("{{") != template.count("}}"):
        return False, "Unmatched braces in template"
    unsupported = [token for token in _TOKEN.findall(template) if token not in _DESCRIPTIONS]
    if unsupported:
        return False, "Unknown variables: " + ", ".join(unsupported)
    return True, ""
