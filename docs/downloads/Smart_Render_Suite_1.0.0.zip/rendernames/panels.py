# ============================================================================
# Render Naming - Panels
# ============================================================================
# UI Panel definitions - appears in Output Properties
# Clean, Blender-native look with progressive disclosure

from ..translation import iface_text
import os

import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
from bpy.types import Panel

from . import handlers, template_engine, pathing
from ..help_operator import draw_help_button


# ============================================================================
# Main Panel
# ============================================================================

class RENDERNAMES_PT_RENDER_NAMING(Panel):
    """Main Render Naming panel in Output Properties"""
    bl_idname = "RENDERNAMES_PT_RENDER_NAMING"
    bl_label = "Render Naming"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "output"
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw_header(self, context):
        # The Render Naming render-time hook is controlled only from the centralized
        # Always-on Toggles group at the top of the Smart Render N-panel.
        pass
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.rendernames
        
        # Settings Scope Toggle (Global vs Per-Scene)
        row = layout.row(align=True)
        row.prop(props, "use_global_settings", text="", icon="WORLD" if props.use_global_settings else "SCENE_DATA")
        if props.use_global_settings:
            row.label(text=iface_text("Global Settings (all scenes)"))
        else:
            row.label(text=iface_text(f"Local Settings ({scene.name} only)"))
        
        layout.separator()
        
        # Template Input
        col = layout.column(align=True)
        col.label(text=iface_text("Template:"), icon="TEXT")
        
        row = col.row(align=True)
        row.prop(props, "template", text="")
        row.menu("RENDERNAMES_MT_TOKENS", text="", icon="ADD")
        row.operator("rendernames.reset_naming_template", text="", icon="LOOP_BACK")
        
        # Base Path Section
        col.separator()
        
        box = col.box()
        row = box.row()
        row.prop(props, "use_base_path", text=iface_text("Custom Base Path"))
        
        if props.use_base_path:
            sub = box.row()
            sub.prop(props, "base_path", text="")
        else:
            sub = box.row()
            sub.enabled = False
            sub.scale_y = 0.8
            sub.label(text=iface_text("Output path: Smart_Render_Suite"), translate=False)
        
        # Live Preview
        col.separator()
        
        box = col.box()
        box.scale_y = 1.0
        
        # Calculate preview
        if props.template:
            rendered = template_engine.render_template(
                props.template,
                scene,
                props,
            )
            preview = pathing.build_output_path(scene, props, rendered, create=False)
        else:
            preview = "(empty template)"
        
        # Show full preview with expandable row
        row = box.row(align=True)
        row.label(text="", icon="FORWARD")
        row.label(text=preview)  # Full path without truncation
        row.operator("rendernames.copy_preview_path", text="", icon="COPYDOWN")

        runtime_box = col.box()
        runtime_box.label(text=iface_text("Manual Preview Update"), icon="FILE_REFRESH")
        runtime_box.operator("rendernames.refresh_presets", text=iface_text("Refresh Now"), icon="FILE_REFRESH")


# ============================================================================
# Options Sub-Panel
# ============================================================================

class RENDERNAMES_PT_OPTIONS(Panel):
    """Options panel for folder organization and naming"""
    bl_idname = "RENDERNAMES_PT_OPTIONS"
    bl_label = "Options"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "output"
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:rendernames')

    def draw(self, context):
        layout = self.layout
        props = context.scene.rendernames
        
        # Folder Organization
        col = layout.column()
        col.label(text=iface_text("Folder Structure:"), icon="FILE_FOLDER")
        
        flow = col.column_flow(columns=2, align=True)
        flow.prop(props, "use_blend_root", text=iface_text("Blend File Root"))
        flow.prop(props, "folder_per_scene", text=iface_text("Per Scene"))
        flow.prop(props, "folder_per_camera", text=iface_text("Per Camera"))
        flow.prop(props, "folder_per_date", text=iface_text("Per Date"))
        
        layout.separator()
        
        # Naming Options
        col = layout.column()
        col.label(text=iface_text("Naming:"), icon="SORTALPHA")
        
        flow = col.column_flow(columns=2, align=True)
        flow.prop(props, "sanitize_names", text=iface_text("Sanitize Names"))
        flow.prop(props, "lowercase", text=iface_text("Lowercase"))
        
        row = col.row(align=True)
        row.prop(props, "frame_padding", text=iface_text("Frame Padding"))


# ============================================================================
# Presets Sub-Panel
# ============================================================================

class RENDERNAMES_PT_PRESETS(Panel):
    """Presets panel for saving and loading configurations"""
    bl_idname = "RENDERNAMES_PT_PRESETS"
    bl_label = "Presets"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "output"
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:rendernames')

    def draw(self, context):
        layout = self.layout
        props = context.scene.rendernames
        
        # Quick access row
        row = layout.row(align=True)
        row.menu("RENDERNAMES_MT_PRESETS", text=iface_text("Load Preset"), icon="PRESET")
        
        layout.separator()
        
        # Save new preset
        col = layout.column(align=True)
        col.label(text=iface_text("Save Current Settings:"), icon="ADD")
        
        row = col.row(align=True)
        row.prop(props, "preset_name", text="")
        row.operator("rendernames.save_preset", text=iface_text("Save"))
        
        layout.separator()
        
        # Import/Export
        row = layout.row(align=True)
        row.operator("rendernames.import_preset", text=iface_text("Import"), icon="IMPORT")
        row.operator("rendernames.export_preset", text=iface_text("Export"), icon="EXPORT")


# ============================================================================
# Token Reference Sub-Panel
# ============================================================================

class RENDERNAMES_PT_TOKEN_REFERENCE(Panel):
    """Quick reference for available template variables"""
    bl_idname = "RENDERNAMES_PT_TOKEN_REFERENCE"
    bl_label = "Token Reference"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "output"
    bl_parent_id = ""
    bl_options = {"DEFAULT_CLOSED"}
    
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:rendernames')

    def draw(self, context):
        layout = self.layout
        props = context.scene.rendernames
        
        # Compact variable reference
        descriptions = template_engine.get_variable_descriptions()
        
        # Group by category for cleaner display
        categories = {
            "Scene": ["scene", "blend_file"],
            "Frame": ["frame", "frame_start", "frame_end", "frame_range"],
            "Time": ["date", "time", "datetime"],
            "Camera": ["camera"],
            "Resolution": ["resolution"],
            "Render": ["fps", "format", "engine", "samples"],
        }
        
        for category, var_names in categories.items():
            box = layout.box()
            box.scale_y = 0.7
            
            col = box.column(align=True)
            col.label(text=iface_text(f"{category}:"), icon="DOT")
            
            for name in var_names:
                if name in descriptions:
                    # Use split to properly align variable and description
                    split = col.split(factor=0.4, align=True)
                    
                    # Variable syntax (clickable - copies to clipboard)
                    op = split.operator(
                        "rendernames.copy_token",
                        text=f"{{{{{name}}}}}",
                        emboss=False,
                    )
                    op.variable = name
                    
                    # Description - takes remaining space
                    split.label(text=descriptions[name])


# ============================================================================
# Render Output Integration Notice
# ============================================================================

class RENDERNAMES_PT_NAMING(Panel):
    """Small notice panel in the standard Output section"""
    bl_idname = "RENDERNAMES_PT_NAMING"
    bl_label = "Naming:"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_context = "output"
    bl_options = {"HIDE_HEADER"}
    bl_order = 0  # Try to appear near the top
    
    @classmethod
    def poll(cls, context):
        # Only show if Render Naming is enabled
        return hasattr(context.scene, "rendernames") and context.scene.rendernames.enabled
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.rendernames
        
        if props.enabled:
            box = layout.box()
            box.scale_y = 0.7
            
            row = box.row()
            row.alert = False
            row.label(
                text=iface_text("Output path managed by Render Naming"),
                translate=False,
            )
            
            sub = row.row()
            sub.alignment = "RIGHT"
            sub.operator(
                "rendernames.apply_to_render_settings",
                text=iface_text("Apply"),
                icon="CHECKMARK",
            )


# ============================================================================
# Registration
# ============================================================================

_classes = (
    RENDERNAMES_PT_RENDER_NAMING,
    RENDERNAMES_PT_OPTIONS,
    RENDERNAMES_PT_PRESETS,
    RENDERNAMES_PT_TOKEN_REFERENCE,
    RENDERNAMES_PT_NAMING,
)


def register():
    """Register panel classes."""
    for cls in _classes:
        safe_register_class(cls)


def unregister():
    """Unregister panel classes."""
    for cls in reversed(_classes):
        safe_unregister_class(cls)
