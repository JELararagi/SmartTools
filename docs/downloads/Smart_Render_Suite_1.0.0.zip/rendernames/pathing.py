# SPDX-License-Identifier: GPL-3.0-or-later
"""Resolve preview paths without creating output directories."""

import os

from bpy import path as blender_path

from ..compat import abspath, default_output_root


def default_rendernames_base(*, create=True):
    destination = os.path.join(default_output_root(create=create), "rendernames")
    if create:
        os.makedirs(destination, exist_ok=True)
    return destination


def base_output_dir(scene, props, *, create=True):
    if getattr(props, "use_base_path", False):
        chosen = str(getattr(props, "base_path", "") or "").strip()
        if chosen:
            return chosen
    return default_rendernames_base(create=create)


def build_output_path(scene, props, rendered, *, create=True):
    root = base_output_dir(scene, props, create=create)
    fragment = (str(rendered) if rendered else "render").lstrip("/\\")
    destination = os.path.normpath(os.path.join(root, fragment))
    if create:
        parent = os.path.dirname(abspath(destination))
        if parent:
            try:
                os.makedirs(parent, exist_ok=True)
            except OSError:
                # Leave Blender to report the failed write when it renders.
                pass
    return destination


def absolute_output_path(scene, props, rendered, *, create=True):
    return blender_path.abspath(build_output_path(scene, props, rendered, create=create))
