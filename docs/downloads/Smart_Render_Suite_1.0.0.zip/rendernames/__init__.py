# SPDX-License-Identifier: GPL-3.0-or-later
"""Register SmartRender's output-naming tools and their render callbacks."""

from . import properties, operators, panels, handlers

bl_info = {
    "name": "Render Output Naming",
    "author": "JELararagi",
    "version": (1, 2, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Name render output from templates and saved presets.",
    "category": "Render",
}

_COMPONENTS = (properties, operators, panels, handlers)


def register():
    ready = []
    try:
        for component in _COMPONENTS:
            component.register()
            ready.append(component)
    except Exception:
        for component in reversed(ready):
            component.unregister()
        raise


def unregister():
    for component in reversed(_COMPONENTS):
        component.unregister()
