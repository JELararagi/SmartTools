# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from functools import wraps
from typing import Any
import sys

import bpy


_ANCHOR_PANEL_CLASS_NAMES = {
    "SMART_RENDER_SUITE_PT_sidebar_anchor",
    "SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor",
}
_GLOBAL_PANEL_POLL_GUARD_MARK = "_smart_render_suite_global_panel_poll_guard"
_GLOBAL_PANEL_POLL_PREVIOUS = None


def _safe_class_dict(cls: type | None):
    if cls is None or not isinstance(cls, type):
        return {}
    try:
        namespace = type.__getattribute__(cls, "__dict__")
        return namespace if namespace is not None else {}
    except Exception:
        return {}


def _safe_class_name(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__name__") or "")
    except Exception:
        return ""


def _safe_class_module(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__module__") or "")
    except Exception:
        return ""


def _safe_class_attr(cls: type | None, name: str, default=None):
    if name == "__name__":
        return _safe_class_name(cls)
    if name == "__module__":
        return _safe_class_module(cls)
    try:
        return _safe_class_dict(cls).get(name, default)
    except Exception:
        return default


def _safe_hidden_anchor_poll(_cls, _context):
    return False


def _is_anchor_panel_class(cls: type | str | None) -> bool:
    if cls is None:
        return False
    if isinstance(cls, str):
        return cls in _ANCHOR_PANEL_CLASS_NAMES
    try:
        return (
            _safe_class_name(cls) in _ANCHOR_PANEL_CLASS_NAMES
            or str(_safe_class_attr(cls, "bl_idname", "") or "") in _ANCHOR_PANEL_CLASS_NAMES
        )
    except Exception:
        return False


def _global_panel_poll_guard(cls, context):
    try:
        if _is_anchor_panel_class(cls):
            return False
    except Exception:
        pass
    previous = globals().get("_GLOBAL_PANEL_POLL_PREVIOUS", None)
    if previous is not None:
        try:
            if isinstance(previous, classmethod):
                return bool(previous.__get__(cls, type(cls))(context))
            if callable(previous):
                try:
                    return bool(previous(cls, context))
                except TypeError:
                    return bool(previous(context))
        except Exception:
            return True
    return True


try:
    setattr(_global_panel_poll_guard, _GLOBAL_PANEL_POLL_GUARD_MARK, True)
except Exception:
    pass


def install_panel_base_poll_guard() -> None:
    """Compatibility no-op; never replace Blender's base Panel.poll."""
    return None


try:
    install_panel_base_poll_guard()
except Exception:
    pass


def _repair_anchor_panel_class(cls: type | None) -> None:
    install_panel_base_poll_guard()
    if cls is None or not isinstance(cls, type):
        return
    try:
        setattr(cls, "poll", classmethod(_safe_hidden_anchor_poll))
    except Exception:
        pass
    try:
        cls.bl_label = "Smart Render Compatibility"
        cls.bl_category = "SRS Hidden"
        cls.bl_region_type = "UI"
        try:
            cls.bl_options = {"HIDE_HEADER"}
        except Exception:
            pass
    except Exception:
        pass



def _rna_base_types() -> tuple[type, ...]:
    bases: list[type] = []
    for name in (
        "Panel",
        "UIList",
        "Operator",
        "PropertyGroup",
        "Menu",
        "Header",
        "RenderEngine",
        "Gizmo",
        "GizmoGroup",
        "Node",
        "NodeTree",
        "FileHandler",
        "AssetShelf",
    ):
        try:
            base = getattr(bpy.types, name, None)
        except Exception:
            base = None
        if base is not None:
            bases.append(base)
    return tuple(bases)


def _safe_ui_fallback_for(name: str):
    # Returning False for poll is safer during mode changes than forcing a panel
    # to draw with an invalid context. Root Smart Render panels define explicit
    # stable poll methods, so the N-panel entry remains available.
    return False if name == "poll" else None


def _default_panel_poll(cls, context):
    del cls, context
    return True


def _materialize_inherited_ui_callback(cls: type, name: str) -> None:
    try:
        if name in _safe_class_dict(cls):
            return
        rna_bases = set(_rna_base_types())
        for base in _safe_class_attr(cls, "__mro__", ())[1:]:
            if base is object or base in rna_bases:
                continue
            if _safe_class_name(base) in {"Panel", "Menu", "UIList", "Header", "Operator", "PropertyGroup", "AddonPreferences"}:
                continue
            if _safe_class_module(base) == "bpy.types":
                continue
            raw = _safe_class_dict(base).get(name)
            if raw is not None:
                setattr(cls, name, raw)
                return
    except Exception:
        pass


def _ensure_panel_poll_target(cls: type | None) -> None:
    if cls is None:
        return
    try:
        panel_base = getattr(bpy.types, "Panel", None)
        if panel_base is None or not issubclass(cls, panel_base):
            return
    except Exception:
        return
    if _is_anchor_panel_class(cls):
        _repair_anchor_panel_class(cls)
        return
    _materialize_inherited_ui_callback(cls, "poll")
    try:
        if "poll" not in _safe_class_dict(cls):
            setattr(cls, "poll", classmethod(_default_panel_poll))
    except Exception:
        pass


def _wrap_ui_callback(cls: type, name: str) -> None:
    try:
        if name in {"poll", "draw_header"}:
            _materialize_inherited_ui_callback(cls, name)
        raw = _safe_class_dict(cls).get(name)
    except Exception:
        raw = None
    if raw is None:
        return
    try:
        if getattr(raw, "_srs_safe_wrapped", False):
            return
        if isinstance(raw, classmethod):
            func = raw.__func__
            if getattr(func, "_srs_safe_wrapped", False):
                return
            if name == "poll":
                @wraps(func)
                def _safe_poll(inner_cls, context):
                    try:
                        return func(inner_cls, context)
                    except Exception:
                        return _safe_ui_fallback_for(name)

                _safe_poll._srs_safe_wrapped = True  # type: ignore[attr-defined]
                setattr(cls, name, classmethod(_safe_poll))
            else:
                @wraps(func)
                def _safe_classmethod(inner_cls, context):
                    try:
                        return func(inner_cls, context)
                    except Exception:
                        return _safe_ui_fallback_for(name)

                _safe_classmethod._srs_safe_wrapped = True  # type: ignore[attr-defined]
                setattr(cls, name, classmethod(_safe_classmethod))
            return
        if not callable(raw):
            return

        if name in {"draw", "draw_header"}:
            @wraps(raw)
            def _safe_method(self, context):
                try:
                    return raw(self, context)
                except Exception:
                    return _safe_ui_fallback_for(name)

            _safe_method._srs_safe_wrapped = True  # type: ignore[attr-defined]
            setattr(cls, name, _safe_method)
            return

        if name == "draw_item":
            @wraps(raw)
            def _safe_draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
                try:
                    return raw(self, context, layout, data, item, icon, active_data, active_propname, index)
                except TypeError:
                    try:
                        return raw(self, context, layout, data, item, icon, active_data, active_propname)
                    except Exception:
                        return _safe_ui_fallback_for(name)
                except Exception:
                    return _safe_ui_fallback_for(name)

            _safe_draw_item._srs_safe_wrapped = True  # type: ignore[attr-defined]
            setattr(cls, name, _safe_draw_item)
            return

        if name == "draw_filter":
            @wraps(raw)
            def _safe_draw_filter(self, context, layout):
                try:
                    return raw(self, context, layout)
                except Exception:
                    return _safe_ui_fallback_for(name)

            _safe_draw_filter._srs_safe_wrapped = True  # type: ignore[attr-defined]
            setattr(cls, name, _safe_draw_filter)
            return

        @wraps(raw)
        def _safe_method(self, context):
            try:
                return raw(self, context)
            except Exception:
                return _safe_ui_fallback_for(name)

        _safe_method._srs_safe_wrapped = True  # type: ignore[attr-defined]
        setattr(cls, name, _safe_method)
    except Exception:
        pass


def ensure_operator_undo_option(cls: type | None) -> None:
    """Ensure every Smart Render operator class contributes one undo step."""
    if cls is None or not isinstance(cls, type):
        return
    try:
        operator_base = getattr(getattr(bpy, 'types', None), 'Operator', None)
        if operator_base is None or not issubclass(cls, operator_base):
            return
    except Exception:
        return
    try:
        options = set(getattr(cls, 'bl_options', set()) or set())
    except Exception:
        options = set()
    if bool(getattr(cls, '_sms_no_undo', False)):
        options.discard('UNDO')
        options.discard('UNDO_GROUPED')
    elif 'UNDO' not in options:
        options.add('UNDO')
    options.discard('REGISTER')
    try:
        setattr(cls, 'bl_options', options)
    except Exception:
        pass


def _wrap_ui_callbacks(cls: type | None) -> None:
    if cls is None:
        return
    try:
        bases = _rna_base_types()
        is_ui_class = any(
            base is not None and issubclass(cls, base)
            for base in bases
            if _safe_class_name(base) in {"Panel", "Menu", "UIList", "Header"}
        )
    except Exception:
        is_ui_class = False
    if not is_ui_class:
        return
    _ensure_panel_poll_target(cls)
    for callback_name in ("poll", "draw", "draw_header", "draw_item", "draw_filter"):
        _wrap_ui_callback(cls, callback_name)


def _identifier_candidates(candidate: type | str | None) -> tuple[str, ...]:
    identifiers: list[str] = []
    if candidate is None:
        return tuple()
    if isinstance(candidate, str):
        text = candidate.strip()
        if text:
            identifiers.append(text)
    else:
        try:
            name = _safe_class_name(candidate).strip()
        except Exception:
            name = ""
        if name:
            identifiers.append(name)
        try:
            bl_idname = _safe_class_attr(candidate, "bl_idname", None)
        except Exception:
            bl_idname = None
        if isinstance(bl_idname, str):
            text = bl_idname.strip()
            if text and text not in identifiers:
                identifiers.append(text)
    return tuple(identifiers)


def _safe_bpy_type_lookup(identifier: str | None):
    # Do not call recursive RNA subclass lookup. In Blender 5.1 that path can crash
    # inside pyrna_struct_bl_rna_find_subclass_recursive/strcmp when the RNA
    # registry is in a transient reload state. Attribute lookup by Python class
    # name is sufficient for registered add-on classes and avoids the C-side
    # recursive subclass search.
    text = str(identifier or "").strip()
    if not text or not text.isidentifier():
        return None
    try:
        existing = getattr(bpy.types, text, None)
    except Exception:
        return None
    return existing if isinstance(existing, type) else None




def _resolve_property_annotation_strings(cls: type | None) -> None:
    """Evaluate postponed bpy.props annotations before Blender registration.

    Some modules use ``from __future__ import annotations``. Blender RNA class
    registration expects annotation values to be the actual deferred property
    objects returned by ``StringProperty`` / ``BoolProperty`` / etc., not string
    expressions. Converting only strings that clearly name a bpy property keeps
    normal type hints untouched while preventing PointerProperty registration
    from receiving an incompletely registered PropertyGroup.
    """
    if cls is None:
        return
    try:
        annotations = getattr(cls, "__annotations__", None)
    except Exception:
        annotations = None
    if not isinstance(annotations, dict) or not annotations:
        return
    try:
        module = sys.modules.get(_safe_class_module(cls))
        globals_dict = dict(getattr(module, "__dict__", {}) or {})
        locals_dict = dict(_safe_class_dict(cls) or {})
    except Exception:
        globals_dict = {}
        locals_dict = {}
    changed = False
    for key, value in tuple(annotations.items()):
        if not isinstance(value, str):
            continue
        expr = value.strip()
        if "Property(" not in expr:
            continue
        if not (
            expr.startswith("bpy.props.")
            or expr.startswith((
                "BoolProperty(",
                "CollectionProperty(",
                "EnumProperty(",
                "FloatProperty(",
                "FloatVectorProperty(",
                "IntProperty(",
                "IntVectorProperty(",
                "PointerProperty(",
                "StringProperty(",
            ))
        ):
            continue
        try:
            annotations[key] = eval(expr, globals_dict, locals_dict)
            changed = True
        except Exception:
            # Leave the value unchanged; Blender will report a normal Python
            # registration error instead of this helper masking the issue.
            pass
    if changed:
        try:
            cls.__annotations__ = annotations
        except Exception:
            pass

def lookup_registered_class(candidate: type | str | None):
    for identifier in _identifier_candidates(candidate):
        existing = _safe_bpy_type_lookup(identifier)
        if isinstance(existing, type):
            return existing
    return None


def _has_own_bl_rna(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        return _safe_class_dict(cls).get("bl_rna") is not None
    except Exception:
        return False


def class_is_registered(cls: type | None) -> bool:
    if cls is None:
        return False
    try:
        existing = lookup_registered_class(cls)
        if isinstance(existing, type) and _has_own_bl_rna(existing):
            return True
    except Exception:
        pass
    try:
        return _has_own_bl_rna(cls)
    except Exception:
        return False


# PropertyGroup subclasses are not reachable through bpy.types, so the lookup
# below cannot see that this module already registered them.
_ENSURED_CLASSES: set[type] = set()


def unregister_existing_class(candidate: type | str | None) -> None:
    install_panel_base_poll_guard()
    existing = lookup_registered_class(candidate)
    _ENSURED_CLASSES.discard(candidate)
    _ENSURED_CLASSES.discard(existing)
    if existing is None and isinstance(candidate, type):
        # If Blender has a registered class object that is not exposed through
        # bpy.types for any reason, unregister_class will either remove it or
        # raise a normal Python exception that we safely ignore.
        existing = candidate
    if existing is None:
        return
    if _is_anchor_panel_class(existing) or _is_anchor_panel_class(candidate):
        _repair_anchor_panel_class(existing)
        return
    if isinstance(existing, type) and 'bl_rna' not in existing.__dict__:
        return  # Not registered: Blender keeps bl_rna on a class only while it is.
    try:
        _wrap_ui_callbacks(existing)
    except Exception:
        pass
    try:
        bpy.utils.unregister_class(existing)
    except Exception:
        pass
    finally:
        try:
            _wrap_ui_callbacks(existing)
        except Exception:
            pass


def ensure_registered_class(cls: type):
    """Return an RNA-registered class object usable by bpy.props.*Property."""
    install_panel_base_poll_guard()
    ensure_operator_undo_option(cls)
    _resolve_property_annotation_strings(cls)
    if _is_anchor_panel_class(cls):
        _repair_anchor_panel_class(cls)
    _wrap_ui_callbacks(cls)

    existing = lookup_registered_class(cls)
    if _is_anchor_panel_class(existing):
        _repair_anchor_panel_class(existing)
    if isinstance(existing, type) and _has_own_bl_rna(existing):
        _wrap_ui_callbacks(existing)
        return existing
    if cls in _ENSURED_CLASSES and _has_own_bl_rna(cls):
        return cls

    try:
        bpy.utils.register_class(cls)
        _ENSURED_CLASSES.add(cls)
    except (ValueError, RuntimeError):
        existing = lookup_registered_class(cls)
        if isinstance(existing, type) and _has_own_bl_rna(existing):
            _wrap_ui_callbacks(existing)
            return existing
        if _has_own_bl_rna(cls):
            _wrap_ui_callbacks(cls)
            return cls
        raise

    existing = lookup_registered_class(cls)
    if isinstance(existing, type) and _has_own_bl_rna(existing):
        _wrap_ui_callbacks(existing)
        return existing
    if _has_own_bl_rna(cls):
        _wrap_ui_callbacks(cls)
        return cls
    raise RuntimeError(f"{_safe_class_name(cls) or cls} did not receive bl_rna after registration")


def unregister_classes(classes: tuple[type, ...] | list[type]) -> None:
    for cls in reversed(tuple(classes or ())) :
        unregister_existing_class(cls)


def remove_rna_property(owner: Any, name: str) -> None:
    if owner is None or not name:
        return
    try:
        if hasattr(owner, name):
            delattr(owner, name)
    except Exception:
        pass


def _is_registered_property_group(cls: type | None) -> bool:
    if cls is None:
        return False
    try:
        property_group = getattr(bpy.types, 'PropertyGroup', None)
        if property_group is not None and not issubclass(cls, property_group):
            return False
    except Exception:
        return False
    try:
        return _has_own_bl_rna(cls)
    except Exception:
        return False


def register_pointer_property(owner: Any, prop_name: str, cls: type, **kwargs: Any) -> bool:
    if owner is None or not prop_name:
        return False

    # Legacy direct-runtime settings cleanup.  Older cached preferences.py
    # attempted to create this PointerProperty; the current build must never
    # recreate it because Blender 5.1 can leave it without a valid bl_rna type.
    try:
        if owner is getattr(bpy.types, 'WindowManager', None) and str(prop_name) == 'smart_render_suite_runtime_prefs':
            remove_rna_property(owner, prop_name)
            return False
    except Exception:
        pass

    remove_rna_property(owner, prop_name)
    try:
        registered_cls = ensure_registered_class(cls)
        if not _is_registered_property_group(registered_cls):
            raise RuntimeError(f"{getattr(cls, '__name__', cls)} is not a registered PropertyGroup")
        setattr(owner, prop_name, bpy.props.PointerProperty(type=registered_cls, **kwargs))
        return True
    except Exception:
        remove_rna_property(owner, prop_name)
        try:
            if owner is getattr(bpy.types, 'WindowManager', None):
                return False
        except Exception:
            pass
        raise


def safe_register_class(cls: type):
    """Register a Blender RNA class without unsafe recursive subclass lookup."""
    return ensure_registered_class(cls)


def safe_unregister_class(candidate: type | str | None) -> None:
    """Unregister a Blender RNA class by class object or Python class name."""
    unregister_existing_class(candidate)


def register_collection_property(owner: Any, name: str, cls: type, **kwargs: Any) -> bool:
    if owner is None or not name:
        return False
    remove_rna_property(owner, name)
    registered_cls = ensure_registered_class(cls)
    if not _is_registered_property_group(registered_cls):
        raise RuntimeError(f"{getattr(cls, '__name__', cls)} is not a registered PropertyGroup")
    setattr(owner, name, bpy.props.CollectionProperty(type=registered_cls, **kwargs))
    return True
