# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bind a unit-width image plane to the camera's projection."""

_PLATE_DISTANCE = '["camera_plane"].["distance"]'
_PLATE_SCALE = '["camera_plane"].["scale"]'
# The horizontal view at this depth extends by range * tan(half-angle) on
# either side of the optical axis. Blender shift is in full-width units.
_VISIBLE_WIDTH = "2 * (plane_depth * tan(view_angle / 2))"


def _drive(plane, path, index, expression, inputs):
    channel = plane.driver_add(path, index).driver
    channel.type = 'SCRIPTED'
    for name, owner, property_path in inputs:
        variable = channel.variables.new()
        variable.name = name
        variable.type = 'SINGLE_PROP'
        target = variable.targets[0]
        target.id_type = 'OBJECT'
        target.id = owner
        target.data_path = property_path
    channel.expression = expression


def create_drivers(plane, cam):
    depth = ("plane_depth", plane, _PLATE_DISTANCE)
    framing = (depth, ("view_angle", cam, "data.angle"))
    size = ("size_percent", plane, _PLATE_SCALE)
    _drive(plane, "delta_location", 2, "-plane_depth", (depth,))
    for index, camera_shift in enumerate(("data.shift_x", "data.shift_y")):
        offset = ("lens_shift", cam, camera_shift)
        _drive(plane, "delta_location", index, f"{_VISIBLE_WIDTH} * lens_shift", (*framing, offset))
        _drive(plane, "delta_scale", index, f"{_VISIBLE_WIDTH} * size_percent / 100", (*framing, size))
