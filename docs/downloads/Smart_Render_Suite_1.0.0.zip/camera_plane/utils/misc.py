# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Filename order for importing numbered camera plates."""

from itertools import groupby


def _ascii_number_character(character):
    return "0" <= character <= "9"


def natural_sort_key(filename):
    """Compare digit runs by value and surrounding text in lower case."""
    key = [""]
    for numeric, characters in groupby(filename, _ascii_number_character):
        token = "".join(characters)
        if numeric:
            key.extend((int(token), ""))
        else:
            key[-1] = int(token) if token.isdigit() else token.lower()
    return key
