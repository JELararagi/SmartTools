# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender image access and ordered RGBA compositing for camera planes."""

import numpy as np

from ...translation import iface_text


def get_blender_image_pixels(img):
    width, height = img.size
    pixels = np.empty(width * height * 4, dtype=np.float32)
    img.pixels.foreach_get(pixels)
    return pixels.reshape(width, height, 4)


def set_blender_image_pixels(img, array):
    width, height = img.size
    pixels = np.asarray(array, dtype=np.float32)
    if pixels.size != width * height * 4:
        raise ValueError("Buffer dimensions do not match the Blender image")
    img.pixels.foreach_set(pixels.ravel())


def _image_nodes(obj):
    for slot in obj.material_slots:
        material = slot.material
        if material is None or material.node_tree is None:
            continue
        for node in material.node_tree.nodes:
            if node.type == "TEX_IMAGE" and node.image is not None:
                yield material, node


def get_image_material(obj, image=None):
    return next(((material, node) for material, node in _image_nodes(obj)
                 if image is None or node.image == image), (None, None))


def get_selected_images(objects):
    owners, images = [], []
    seen = set()
    for obj in objects:
        for _, node in _image_nodes(obj):
            image = node.image
            if image not in seen:
                seen.add(image)
                owners.append(obj)
                images.append(image)
    return owners, images


def create_image_buffer(op, size, images_to_process):
    result = np.zeros((*size, 4), dtype=np.float32)
    for image in images_to_process:
        if tuple(image.size) != tuple(size):
            op.report({"ERROR"}, iface_text("Could not group layers"))
            return {"CANCELLED"}
        source = get_blender_image_pixels(image)
        opacity = source[..., 3:4]
        result *= 1.0 - opacity
        if image.alpha_mode == "STRAIGHT":
            result[..., :3] += source[..., :3] * opacity
            result[..., 3:4] += opacity
        else:
            result += source
    return result
