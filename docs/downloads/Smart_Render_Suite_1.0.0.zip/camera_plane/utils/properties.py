# SPDX-License-Identifier: GPL-3.0-or-later
"""RNA accessors preserving the ID properties used by older Camera Plane drivers."""

from idprop.types import IDPropertyGroup


def get_lock_status(obj):
    locks = [*obj.lock_location, *obj.lock_rotation, *obj.lock_scale]
    if obj.rotation_mode in {"QUATERNION", "AXIS_ANGLE"}:
        locks.append(obj.lock_rotation_w)
    if all(locks):
        return "LOCKED"
    if any(locks):
        return "MISMATCH"
    return "UNLOCKED"


def _read_driver_value(obj, name, default):
    metadata = obj.get("camera_plane")
    if isinstance(metadata, IDPropertyGroup) and name in metadata:
        return metadata[name]
    return obj.get(f"camera_plane_{name}", default)


def _write_driver_value(obj, name, value):
    metadata = obj.get("camera_plane")
    if not isinstance(metadata, IDPropertyGroup):
        obj["camera_plane"] = {name: value}
    else:
        metadata[name] = value
    legacy_key = f"camera_plane_{name}"
    if legacy_key in obj:
        obj[legacy_key] = value
    obj.update_tag()


def get_distance(self):
    return _read_driver_value(self.id_data, "distance", 0.0)


def set_distance(self, value):
    _write_driver_value(self.id_data, "distance", value)


def get_scale(self):
    return _read_driver_value(self.id_data, "scale", 1.0)


def set_scale(self, value):
    _write_driver_value(self.id_data, "scale", value)


def get_select(self):
    return self.id_data.select_get()


def set_select(self, value):
    self.id_data.select_set(value)


def get_hide(self):
    obj = self.id_data
    return obj.hide_viewport and obj.hide_render


def set_hide(self, value):
    obj = self.id_data
    obj.hide_viewport = value
    obj.hide_render = value


def get_lock(self):
    return get_lock_status(self.id_data) != "UNLOCKED"


def set_lock(self, value):
    obj = self.id_data
    for prop in ("lock_location", "lock_rotation", "lock_scale"):
        setattr(obj, prop, (value, value, value))
    obj.lock_rotation_w = value


def update_distance(self, context):
    originals = self.get("originals")
    if originals is None:
        return
    change = self.camera_plane.distance - self["original_distance"]
    for obj in originals:
        obj.camera_plane.distance = obj["original_distance"] + change
