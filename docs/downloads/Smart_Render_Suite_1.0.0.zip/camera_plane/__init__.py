# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": 'Camera Image Plane',
    "author": "JELararagi",
    "version": (3, 0, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Create and manage image planes, camera mapping helpers, and grouped camera-plane workflows inside the Smart Render N-panel.",
    "category": "Camera",
}

import bpy

from .handlers import camera_plane_group_handler, camera_plane_versioning_handler
from .operators import (
    CAMERA_OT_Camera_Mapping,
    CAMERA_OT_Camera_Plane,
    CAMERA_OT_Camera_Plane_Add_Opacity,
    CAMERA_OT_Camera_Plane_Apply,
    CAMERA_OT_Camera_Plane_Group,
    CAMERA_OT_Camera_Plane_Layers,
    CAMERA_OT_Camera_Plane_Reverse,
    CAMERA_OT_Camera_Plane_Run_Load_Maintenance,
    CAMERA_OT_Camera_Plane_Space,
    CAMERA_OT_Camera_Plane_Ungroup,
    CAMERA_OT_Camera_Plane_Update_Groups,
)
from .properties import CameraPlaneProperties, CameraPlaneSettings
from .ui import (
    CAMERA_MT_Camera_Plane_Context_Menu,
    draw_convert_to_camera_mapping,
)

classes = (
    CameraPlaneProperties,
    CameraPlaneSettings,
    CAMERA_MT_Camera_Plane_Context_Menu,
    CAMERA_OT_Camera_Mapping,
    CAMERA_OT_Camera_Plane,
    CAMERA_OT_Camera_Plane_Add_Opacity,
    CAMERA_OT_Camera_Plane_Apply,
    CAMERA_OT_Camera_Plane_Group,
    CAMERA_OT_Camera_Plane_Layers,
    CAMERA_OT_Camera_Plane_Reverse,
    CAMERA_OT_Camera_Plane_Run_Load_Maintenance,
    CAMERA_OT_Camera_Plane_Space,
    CAMERA_OT_Camera_Plane_Ungroup,
    CAMERA_OT_Camera_Plane_Update_Groups,
)


def _unregister_external_context_menu() -> None:
    menu = getattr(getattr(bpy, 'types', None), 'VIEW3D_MT_object_context_menu', None)
    remover = getattr(menu, 'remove', None)
    if not callable(remover):
        return
    for _ in range(8):
        try:
            remover(draw_convert_to_camera_mapping)
        except Exception:
            break


def _append_handler_once(handler_list, fn) -> None:
    if handler_list is None:
        return
    if fn not in handler_list:
        handler_list.append(fn)


def _remove_handler_if_present(handler_list, fn) -> None:
    if handler_list is None:
        return
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass


def _remove_stale_transform_versioning_handlers(handler_list) -> None:
    if handler_list is None:
        return
    try:
        for handler in tuple(handler_list):
            try:
                name = str(getattr(handler, '__name__', '') or '')
                module = str(getattr(handler, '__module__', '') or '')
            except Exception:
                continue
            if name == 'camera_plane_versioning_handler' and module.endswith('camera_plane.handlers'):
                try:
                    handler_list.remove(handler)
                except Exception:
                    pass
    except Exception:
        pass


def _maintenance_enabled(context=None) -> bool:
    # Camera Plane load maintenance now runs on demand from the N-panel button.
    # Returning False prevents file-load handlers from being registered even if
    # an older .blend or JSON file still contains auto_load_maintenance=True.
    return False


def sync_load_handlers(context=None, *, force_disable: bool = False) -> None:
    load_handlers = getattr(bpy.app.handlers, 'load_post', None)
    # Remove stale legacy versioning callbacks from previous builds. Those old
    # callbacks reset object location/scale during file load.
    _remove_stale_transform_versioning_handlers(load_handlers)
    # Always keep automatic file-load maintenance disabled. The existing
    # camera.run_maintenance operator performs the same group rebuild and
    # non-destructive legacy check only when the user requests it.
    _remove_handler_if_present(load_handlers, camera_plane_group_handler)
    _remove_handler_if_present(load_handlers, camera_plane_versioning_handler)


def register():
    from ..rna_safety import ensure_registered_class, register_pointer_property
    for c in classes:
        ensure_registered_class(c)
    register_pointer_property(
        bpy.types.WindowManager,
        "camera_plane_settings",
        CameraPlaneSettings,
    )
    register_pointer_property(bpy.types.Object, "camera_plane", CameraPlaneProperties)

    # Integrated mode: entry points stay inside the Smart Render N-panel, so the legacy
    # object context-menu injection remains disabled.
    _unregister_external_context_menu()

    sync_load_handlers(context=getattr(bpy, 'context', None))


def unregister():
    sync_load_handlers(context=None, force_disable=True)
    if hasattr(bpy.types, 'WindowManager') and hasattr(bpy.types.WindowManager, 'camera_plane_settings'):
        del bpy.types.WindowManager.camera_plane_settings
    if hasattr(bpy.types, 'Object') and hasattr(bpy.types.Object, 'camera_plane'):
        del bpy.types.Object.camera_plane

    _unregister_external_context_menu()

    from ..rna_safety import unregister_existing_class
    unregister_existing_class("CAMERA_PT_Camera_Plane")
    for c in reversed(classes):
        unregister_existing_class(c)


if __name__ == "__main__":
    register()
