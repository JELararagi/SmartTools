from ..translation import iface_text
import bpy

from ..translation import localize_inline
from .operators import CAMERA_OT_Camera_Mapping, CAMERA_OT_Camera_Plane_Update_Groups
from .properties import get_planes
from .utils.misc import natural_sort_key
from .utils.properties import get_lock_status
from ..help_operator import draw_help_button

# Icons of the group expander inside a plane row (a list row cannot hold a layout panel).
_GROUP_ROW_ICON = {True: 'DISCLOSURE_TRI_DOWN', False: 'DISCLOSURE_TRI_RIGHT'}


def _safe_active_object(context):
    try:
        return getattr(context, 'active_object', None)
    except Exception:
        return None


def _safe_plane_name(plane) -> str:
    try:
        return str(getattr(plane, 'name', '') or '')
    except ReferenceError:
        return ''
    except Exception:
        return ''


def _safe_plane_distance(plane) -> float:
    try:
        return float(getattr(plane.camera_plane, 'distance', 0.0) or 0.0)
    except ReferenceError:
        return 0.0
    except Exception:
        return 0.0


def _safe_select_get(obj) -> bool:
    try:
        return bool(obj.select_get())
    except ReferenceError:
        return False
    except Exception:
        return False


def _safe_prop(obj, name, default=None):
    try:
        return getattr(obj, name, default)
    except ReferenceError:
        return default
    except Exception:
        return default


def _safe_idprop_contains(obj, key) -> bool:
    try:
        return key in obj
    except ReferenceError:
        return False
    except Exception:
        return False


def _has_camera_plane_context(obj) -> bool:
    try:
        if obj is None:
            return False
        if getattr(obj, 'type', None) == "CAMERA":
            return True
        parent = getattr(obj, 'parent', None)
        return (parent is not None
                and getattr(parent, 'type', None) == "CAMERA"
                and "camera_plane" in obj
                and "distance" in obj["camera_plane"])
    except ReferenceError:
        return False
    except Exception:
        return False


class CAMERA_MT_Camera_Plane_Context_Menu(bpy.types.Menu):
    bl_label = "Options"

    def draw(self, context):
        layout = self.layout

        layout.operator("camera.group_selected_planes", icon="GROUP", text=iface_text("Group Selected"))

        layout.separator()
        layout.operator("camera.space_planes_evenly")
        layout.operator("camera.reverse_order")

        layout.separator()
        layout.operator("camera.apply_camera_plane", text=iface_text("Apply Selected"))

        layout.separator()
        layout.operator("camera.set_up_plane_layers", icon='RENDERLAYERS')


def _draw_image_row(layout, plane, show_scale=False, show_opacity=False, is_grouped=False):
    try:
        _ = plane.camera_plane
    except ReferenceError:
        return (False, False)
    except Exception:
        return (False, False)
    row = layout.row(align=True)
    split = row.split(align=True)
    row_name = split.row(align=True)
    try:
        lock = get_lock_status(plane)
    except Exception:
        lock = 'UNKNOWN'
    if not is_grouped:
        sub = row_name.row(align=True)
        # Warn that visibility state is out of sync
        sub.alert = _safe_prop(plane, 'hide_viewport', False) != _safe_prop(plane, 'hide_render', False)
        sub.prop(
            plane.camera_plane,
            "hide",
            icon_only=True,
            icon="RESTRICT_VIEW_ON" if _safe_prop(plane, 'hide_viewport', False) else "RESTRICT_VIEW_OFF",
        )
        row_name.prop(
            plane.camera_plane,
            "select",
            icon_only=True,
            icon="RESTRICT_SELECT_OFF" if _safe_select_get(plane) else "RESTRICT_SELECT_ON",
        )
        sub = row_name.row(align=True)
        # Warn that lock state is out of sync
        sub.alert = lock == 'MISMATCH'
        sub.prop(
            plane.camera_plane,
            "lock",
            icon_only=True,
            invert_checkbox=True,
            icon="LOCKED" if lock in {'LOCKED', 'MISMATCH'} else "UNLOCKED",
        )

        if _safe_idprop_contains(plane, "originals"):
            try:
                group_open = bool(plane.camera_plane.show_group)
            except Exception:
                group_open = False
            row_name.prop(
                plane.camera_plane,
                "show_group",
                icon_only=True,
                icon=_GROUP_ROW_ICON[group_open],
            )
        row_name.label(text=_safe_plane_name(plane), translate=False)
        # Warn that plane is grouped, but outside any group...
        if not _safe_idprop_contains(plane, "originals") and (".grouped" in _safe_plane_name(plane) or "grouped." in _safe_plane_name(plane)):
            row_warning = row_name.row(align=True)
            row_warning.alert = True
            row_warning.label(text=iface_text("Outside group?"), icon='ERROR')
    else:
        row_name.label(text=_safe_plane_name(plane), translate=False)

    row_info = split.row(align=True)

    if is_grouped:
        if show_scale or show_opacity:
            split_factor = 1.0 / 3.0 if show_scale and show_opacity else 0.5
            sub_split = row_info.split(factor=split_factor, align=True)
            sub_distance = sub_split.row(align=True)
            sub_props = sub_split.row(align=True)
        else:
            sub_distance = row_info.row(align=True)
        sub_distance.alignment = 'RIGHT'
        sub_distance.label(text="{:.1f} m".format(_safe_plane_distance(plane)), translate=False)
    else:
        sub_props = row_info.row(align=True)
        sub_props.prop(plane.camera_plane, "distance", emboss=True, icon_only=True)

    if show_scale:
        sub_props.prop(plane.camera_plane, "scale", emboss=True, icon_only=True)
    if show_opacity and getattr(plane, 'active_material', None) is not None:
        node_tree = getattr(plane.active_material, 'node_tree', None)
        nodes = getattr(node_tree, 'nodes', {}) if node_tree is not None else {}
        if "Opacity Multiplier" in nodes:
            try:
                sub_props.prop(
                    nodes["Opacity Multiplier"].inputs[1],
                    "default_value",
                    emboss=True,
                    icon_only=True,
                )
            except Exception:
                pass
        else:
            sub_props.operator(
                "camera.add_plane_opacity",
                text=iface_text("Add Opacity"),
            ).plane = _safe_plane_name(plane)

    try:
        plane_visibility = _safe_prop(plane, 'hide_viewport', False) != _safe_prop(plane, 'hide_render', False)
    except Exception:
        plane_visibility = False
    plane_lock = lock == 'MISMATCH'
    return (plane_lock, plane_visibility)


def draw_integrated_controls(layout, context):
    wm = getattr(context, 'window_manager', None)
    settings = getattr(wm, 'camera_plane_settings', None) if wm is not None else None
    if settings is None:
        return

    active = _safe_active_object(context)
    if not _has_camera_plane_context(active):
        return
    planes = get_planes(active)

    # Sort planes given selected sort type
    if getattr(settings, 'sort_type', 'DISTANCE') == 'ALPHABETICAL':
        planes.sort(key=lambda p: natural_sort_key(_safe_plane_name(p)))
    else:
        planes.sort(key=_safe_plane_distance)

    layout.operator("camera.import_camera_plane", icon='FILE_IMAGE')

    runtime_box = layout.box()
    runtime_box.label(text=iface_text("Manual Maintenance"), icon="FILE_REFRESH")
    runtime_box.operator("camera.run_maintenance", text=iface_text("Run Maintenance"), icon="FILE_REFRESH")

    if len(planes) > 0:
        layout.separator()

        box = layout.box()

        row = box.row()
        row.prop(settings, "show_selected")
        row.prop(settings, "filter", text="", icon="VIEWZOOM")
        row.prop(settings, "sort_type", expand=True, icon_only=True)
        row.menu(CAMERA_MT_Camera_Plane_Context_Menu.__name__, icon='DOWNARROW_HLT', text="")

        row = box.row()
        row.prop(settings, "show_scale")
        row.prop(settings, "show_opacity")

        col = box.column(align=True)
        col.use_property_split = True
        col.use_property_decorate = False

        # Column labels
        row_labels = col.row()
        split_labels = row_labels.split()
        sub = split_labels.row()
        sub = split_labels.row()
        if settings.show_scale or settings.show_opacity:
            split_factor = 1.0 / 3.0 if settings.show_scale and settings.show_opacity else 0.5
            sub_split = sub.split(factor=split_factor, align=True)
            sub = sub_split.row()
            sub.alignment = 'CENTER'
            sub.label(text=iface_text("Distance"))
            if settings.show_scale:
                sub = sub_split.row()
                sub.alignment = 'CENTER'
                sub.label(text=iface_text("Scale"))
            if settings.show_opacity:
                sub = sub_split.row()
                sub.alignment = 'CENTER'
                sub.label(text=iface_text("Opacity"))
        else:
            sub.alignment = 'CENTER'
            sub.label(text=iface_text("Distance"))

        visibility_out_of_sync = False
        lock_out_of_sync = False
        for plane in planes:
            # Filter based on selection
            if getattr(settings, 'show_selected', False) and not _safe_select_get(plane):
                continue
            # Filter based on name
            filter_text = str(getattr(settings, 'filter', '') or '').lower()
            if filter_text not in _safe_plane_name(plane).lower():
                continue
            if not _safe_idprop_contains(plane, "grouped"):
                plane_lock, plane_visibility = _draw_image_row(
                    col, plane, settings.show_scale, settings.show_opacity
                )
                visibility_out_of_sync = plane_visibility or visibility_out_of_sync
                lock_out_of_sync = plane_lock or lock_out_of_sync
            try:
                show_group = bool(plane.camera_plane.show_group)
            except Exception:
                show_group = False
            if not _safe_idprop_contains(plane, "originals") or not show_group:
                continue

            # Display planes inside a group
            plane_box = col.box()
            plane_col = plane_box.column(align=True)
            try:
                originals = list(plane["originals"][:])
            except Exception:
                originals = []

            # Sort planes given selected sort type
            if getattr(settings, 'sort_type', 'DISTANCE') == 'ALPHABETICAL':
                originals.sort(key=lambda p: natural_sort_key(_safe_plane_name(p)))
            else:
                originals.sort(key=_safe_plane_distance)

            if CAMERA_OT_Camera_Plane_Update_Groups.poll(context):
                update_row = plane_col.row()
                update_row.alert = True
                update_row.operator("camera.update_plane_groups", icon="FILE_REFRESH")

            for orig in originals:
                if str(getattr(settings, 'filter', '') or '').lower() in _safe_plane_name(orig).lower():
                    _draw_image_row(
                        plane_col,
                        orig,
                        settings.show_scale,
                        settings.show_opacity,
                        is_grouped=True,
                    )
            plane_col.operator("camera.ungroup_planes").group = _safe_plane_name(plane)

        if visibility_out_of_sync:
            layout.label(
                text=iface_text("Viewport and render visibility out of sync for some planes"), icon='ERROR'
            )
        if lock_out_of_sync:
            layout.label(text=iface_text("Transform locks out of sync for some planes"), icon='ERROR')


def draw_convert_to_camera_mapping(self, context):
    self.layout.separator()
    self.layout.operator(CAMERA_OT_Camera_Mapping.bl_idname, icon='CAMERA_DATA')
