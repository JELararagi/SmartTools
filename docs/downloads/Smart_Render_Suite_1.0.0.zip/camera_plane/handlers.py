# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit load maintenance for grouping and old Camera Plane metadata."""

import bpy
from bpy.app.handlers import persistent
from idprop.types import IDPropertyGroup


def _maintenance_enabled():
    window_manager = getattr(bpy.context, "window_manager", None)
    return bool(getattr(getattr(window_manager, "camera_plane_settings", None),
                        "auto_load_maintenance", False))


@persistent
def camera_plane_group_handler(_loaded_file, *, force=False):
    if (force or _maintenance_enabled()) and bpy.ops.camera.update_plane_groups.poll():
        bpy.ops.camera.update_plane_groups()


@persistent
def camera_plane_versioning_handler(_loaded_file, *, force=False):
    if not force and not _maintenance_enabled():
        return
    names = {"distance": "camera_plane_distance", "scale": "camera_plane_scale"}
    for obj in bpy.data.objects:
        parent = obj.parent
        if parent is None or parent.type != "CAMERA" or not all(key in obj for key in names.values()):
            continue
        existing = obj.get("camera_plane")
        if not isinstance(existing, IDPropertyGroup):
            obj["camera_plane"] = {name: obj[key] for name, key in names.items()}
            continue
        for name, key in names.items():
            if name not in existing:
                existing[name] = obj[key]
