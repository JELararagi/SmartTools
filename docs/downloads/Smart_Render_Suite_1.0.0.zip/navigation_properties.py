# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable

try:
    import bpy
except Exception:  # pragma: no cover - Blender provides bpy at runtime.
    bpy = None  # type: ignore[assignment]

# Compatibility shim only. Smart Render now uses ordinary Blender N-panel
# classes registered directly as VIEW_3D/UI panels.

_CATEGORY_OVERRIDES = {
    'smart_render_suite': 'Smart Render',
}

_REGISTRY = {
    'nav_entries': {},
    'panel_sources': {},
    'proxy_panels': {},
    'original_panel_polls': {},
    'launcher_callbacks': {},
    'launcher_draw_callbacks': {},
    'legacy_operators': {},
    'popup_operators': {},
    'preferred_owner': None,
    'active_owner': None,
    'shutdown': False,
    'runtime_teardown': False,
}

_STARTUP_SAFE_STUB = True


def _registry() -> dict:
    return _REGISTRY


def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip()


def _category_for(addon_key: str, label: object = '') -> str:
    addon_key = _normalize_owner(addon_key)
    if addon_key in _CATEGORY_OVERRIDES:
        return _CATEGORY_OVERRIDES[addon_key]
    text = str(label or addon_key or 'Smart Render').replace('_', ' ').strip()
    return text or 'Smart Render'


def _label_for(addon_key: str, label: object = '') -> str:
    return _category_for(addon_key, label)


def prepare_panel_classes(panel_classes: Iterable[type] | None, addon_key: str = '') -> tuple[type, ...]:
    del addon_key
    return tuple(cls for cls in tuple(panel_classes or ()) if isinstance(cls, type))


def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes=None, order: int = 0, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _REGISTRY.setdefault('nav_entries', {})[addon_key] = {
        'label': _label_for(addon_key, label),
        'icon': str(icon or ''),
        'operator_id': str(operator_id or ''),
        'button_operator_id': '',
        'order': int(order or 0),
        'category': _category_for(addon_key, label),
    }
    _REGISTRY.setdefault('panel_sources', {})[addon_key] = prepare_panel_classes(panel_classes, addon_key)
    _REGISTRY['preferred_owner'] = addon_key
    _REGISTRY['active_owner'] = addon_key
    _REGISTRY['shutdown'] = False
    _REGISTRY['runtime_teardown'] = False
    _tag_redraw_all_npanel_areas()
    return True


def refresh_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes=None, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes=None, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def uninstall(addon_key: str, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    for key in ('nav_entries', 'panel_sources', 'proxy_panels', 'original_panel_polls', 'launcher_callbacks', 'launcher_draw_callbacks'):
        try:
            _REGISTRY.get(key, {}).pop(addon_key, None)
        except Exception:
            pass
    if _REGISTRY.get('preferred_owner') == addon_key:
        _REGISTRY['preferred_owner'] = None
    if _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    _tag_redraw_all_npanel_areas()
    return True


def set_launcher_draw_callback(addon_key: str, callback) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    target = _REGISTRY.setdefault('launcher_draw_callbacks', {})
    if callable(callback):
        target[addon_key] = callback
    else:
        target.pop(addon_key, None)
    return True


def clear_launcher_draw_callback(addon_key: str) -> bool:
    return set_launcher_draw_callback(addon_key, None)


def is_active(context=None, addon_key: str = '') -> bool:
    del context, addon_key
    return True


def set_active_owner(context=None, addon_key: str | None = None) -> None:
    del context
    addon_key = _normalize_owner(addon_key)
    _REGISTRY['active_owner'] = addon_key or None
    if addon_key:
        _REGISTRY['preferred_owner'] = addon_key
    _tag_redraw_all_npanel_areas()


def clear_active_owner(addon_key: str = '') -> None:
    addon_key = _normalize_owner(addon_key)
    if not addon_key or _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    _tag_redraw_all_npanel_areas()


def toggle_active(context=None, addon_key: str = '') -> None:
    set_active_owner(context, addon_key)


def runtime_needs_refresh(addon_key: str = '') -> bool:
    del addon_key
    return False


def runtime_has_existing_host_candidates(addon_key: str = '') -> bool:
    del addon_key
    return False


def force_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    if preferred_owner:
        set_active_owner(None, preferred_owner)
    _tag_redraw_all_npanel_areas()
    return True


def refresh_ui_runtime(context=None, addon_key: str | None = None, activate_if_properties: bool = False, **_kwargs) -> bool:
    del activate_if_properties
    if addon_key:
        set_active_owner(context, addon_key)
    _tag_redraw_all_npanel_areas()
    return True


def sync_live_runtime_from_prefs(context=None) -> bool:
    del context
    _tag_redraw_all_npanel_areas()
    return True


def ensure_shared_nav_button_operators() -> bool:
    return True


def mark_suite_presence(addon_key: str, installed: bool = True) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    if installed:
        _REGISTRY.setdefault('nav_entries', {}).setdefault(addon_key, {'label': _category_for(addon_key), 'category': _category_for(addon_key), 'icon': '', 'operator_id': '', 'button_operator_id': '', 'order': 0})
    else:
        uninstall(addon_key)
    return True


def ensure_shared_window_menu_button(force: bool = False) -> bool:
    del force
    return False


def remove_shared_window_menu_button_if_unused(*_args, **_kwargs) -> None:
    return None


def schedule_shared_window_menu_button_refresh(*_args, **_kwargs) -> None:
    return None


def begin_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = True


def finish_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = False


def shutdown_runtime() -> None:
    _REGISTRY['shutdown'] = True
    _REGISTRY['nav_entries'].clear()
    _REGISTRY['panel_sources'].clear()
    _REGISTRY['proxy_panels'].clear()
    _tag_redraw_all_npanel_areas()


def is_shutting_down() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def runtime_is_shutdown() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def _set_runtime_teardown(value: bool = True) -> None:
    _REGISTRY['runtime_teardown'] = bool(value)
    _REGISTRY['shutdown'] = bool(value)


def is_smart_tools_context(context=None) -> bool:
    return _is_smart_tools_context(context)


def _is_smart_tools_context(context=None) -> bool:
    if bpy is None:
        return True
    context = context or getattr(bpy, 'context', None)
    area = getattr(context, 'area', None)
    if area is None:
        return True
    return str(getattr(area, 'type', '') or '') == 'VIEW_3D'


def _tag_redraw_all_npanel_areas() -> None:
    if bpy is None:
        return
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


def _tag_redraw_all_properties_areas() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_host_windows() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_window_menu_areas() -> None:
    _tag_redraw_all_npanel_areas()


def flush_redraws() -> None:
    _tag_redraw_all_npanel_areas()


def _verified_host_window_keys() -> tuple:
    return ()


def _ensure_host_watch_timer() -> bool:
    return False


def _install_window_menu_entry(*_args, **_kwargs) -> bool:
    return False


def _remove_window_menu_entry_if_unused(*_args, **_kwargs) -> None:
    return None


def _schedule_window_menu_refresh(*_args, **_kwargs) -> None:
    return None


def repair_live_hosts_and_menu(context=None, *, reopen_window: bool = False) -> bool:
    del context, reopen_window
    _tag_redraw_all_npanel_areas()
    return True


def _install_header_draw_wrapper(*_args, **_kwargs):
    return False


def _install_context_header_overlay(*_args, **_kwargs):
    return False


def _install_navigation_bar_draw_wrapper(*_args, **_kwargs):
    return False


def _install_render_context_draw_wrapper(*_args, **_kwargs):
    return False


def _install_foreign_panel_hider(*_args, **_kwargs):
    return False


def _ensure_runtime_hooks(*_args, **_kwargs) -> bool:
    return False


def _smart_tools_light_activate_runtime(*_args, **_kwargs) -> bool:
    return True


def open_smart_tools_window(*_args, **_kwargs) -> bool:
    return True


def open_or_reuse_smart_tools_window(*_args, **_kwargs) -> bool:
    return True


def invoke_props_dialog_preferred_window(*_args, **_kwargs) -> bool:
    return False


def invoke_props_dialog_outside_smart_tools(*_args, **_kwargs) -> bool:
    return False


def invoke_popup_outside_smart_tools(*_args, **_kwargs) -> bool:
    return False


def _ensure_host_window_popup_capacity(*_args, **_kwargs) -> bool:
    return False


def popup_menu_operator_id(addon_key: str = '') -> str:
    del addon_key
    return ''


def popup_operator_enum_operator_id(addon_key: str = '') -> str:
    del addon_key
    return ''


def popup_menu_pie_proxy_operator_id(addon_key: str = '') -> str:
    del addon_key
    return ''


def _ensure_popup_operators() -> bool:
    return False


def _ensure_legacy_open_operators(addon_key: str = '') -> bool:
    del addon_key
    return False


def _shared_nav_button_operator_class(addon_key: str = '', label: str = ''):
    del addon_key, label
    return None


def is_startup_safe_stub() -> bool:
    return True


def describe_startup_behavior() -> str:
    return 'standard_npanel_only'
