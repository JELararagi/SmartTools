# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright 2026 JELararagi
"""Read geographic coordinate pairs entered in Smart Render's Sun Position UI."""

import math
import re

_UNSIGNED = r"(?:[0-9]+(?:[.,][0-9]*)?|[.,][0-9]+)"
_DEGREES = rf"[+-]?{_UNSIGNED}"
_ANGLE = rf"{_DEGREES}(?:\s*°(?:\s*{_UNSIGNED}'(?!'))?(?:\s*{_UNSIGNED}\")?)?"
_COMPONENTS = re.compile(
    rf"(?P<degrees>{_DEGREES})(?:\s*°(?:\s*(?P<minutes>{_UNSIGNED})')?"
    rf"(?:\s*(?P<seconds>{_UNSIGNED})\")?)?"
)
_DIRECTIONS = {
    "N": ("latitude", 1),
    "S": ("latitude", -1),
    "E": ("longitude", 1),
    "W": ("longitude", -1),
}
_SEPARATOR = r"[;,\s]*"
_SEPARATED = re.compile(rf"(?P<first>{_ANGLE})[;,\s]+(?P<second>{_ANGLE})")
_DIRECTIONAL = (
    re.compile(
        rf"(?P<a>[NSEW])\s*(?P<first>{_ANGLE}){_SEPARATOR}"
        rf"(?P<b>[NSEW])\s*(?P<second>{_ANGLE})"
    ),
    re.compile(
        rf"(?P<first>{_ANGLE})\s*(?P<a>[NSEW]){_SEPARATOR}"
        rf"(?P<second>{_ANGLE})\s*(?P<b>[NSEW])"
    ),
)


def _number(text):
    return float(text.replace(",", ".")) if text is not None else 0.0


def _angle(text):
    parts = _COMPONENTS.fullmatch(text)
    degrees = _number(parts["degrees"])
    minutes = _number(parts["minutes"])
    seconds = _number(parts["seconds"])
    return math.copysign(abs(degrees) + minutes / 60 + seconds / 3600, degrees)


def parse_position(text):
    """Return signed (latitude, longitude) or None for an unrecognized pair."""
    source = text.strip().upper().replace("′", "'").replace("″", '"').replace("''", '"')
    pair = _SEPARATED.fullmatch(source)
    if pair:
        return _angle(pair["first"]), _angle(pair["second"])
    for shape in _DIRECTIONAL:
        pair = shape.fullmatch(source)
        if pair is None:
            continue
        first_axis, first_sign = _DIRECTIONS[pair["a"]]
        second_axis, second_sign = _DIRECTIONS[pair["b"]]
        if first_axis == second_axis:
            return None
        point = {
            first_axis: first_sign * _angle(pair["first"]),
            second_axis: second_sign * _angle(pair["second"]),
        }
        return point["latitude"], point["longitude"]
    return None
