# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Set Sun Position's current local date and fractional hour preset.

This file is executed by Blender's native Execute Preset path. It does not
register new classes or change the user's time-zone or daylight-saving option.
"""

from datetime import datetime

import bpy


current = datetime.today()
sun_props = bpy.context.scene.sun_pos_properties

# Year first: day-of-year setters interpret the ordinal within that year.
sun_props.year = current.year
sun_props.month = current.month
sun_props.day = current.day
# In day-of-year UI mode the RNA uses this separate field, so synchronize it
# with the calendar date without changing the selected display mode.
sun_props.day_of_year = current.timetuple().tm_yday
sun_props.time = current.hour + current.minute / 60.0 + current.second / 3600.0
