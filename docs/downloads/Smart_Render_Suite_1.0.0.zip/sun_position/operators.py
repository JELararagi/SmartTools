# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Create sun-path mesh objects from the public sun_calc geometry API.

The celestial computations belong to sun_calc and are not reimplemented here.
Parent package sun_position registers/unregisters these two operator classes.
"""

import bpy
from bpy.app.translations import pgettext_data
from bpy.props import BoolProperty, IntProperty
from bpy.types import Operator

from .sun_calc import calc_analemma, calc_surface


def _create_mesh_object(context, name, vertices, edges, faces, smooth=False):
    """Create one linked object; leave no partial data blocks on failure."""
    translated_name = pgettext_data(name)
    mesh = bpy.data.meshes.new(translated_name)
    obj = None
    try:
        mesh.from_pydata(vertices, edges, faces)
        mesh.update()
        if smooth:
            mesh.shade_smooth()
        obj = bpy.data.objects.new(translated_name, mesh)
        context.collection.objects.link(obj)
        return obj
    except Exception:
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(mesh, do_unlink=True)
        raise


def _error_text(english, japanese):
    """Choose a single message language without changing registered UI labels."""
    try:
        locale = str(bpy.app.translations.locale).lower().replace('-', '_')
    except (AttributeError, TypeError):
        locale = ''
    return japanese if locale.startswith('ja') else english


class SUNPOS_OT_Create_Analemmas_Object(Operator):
    bl_idname = 'world.create_analemma_object'
    bl_label = 'Create Analemma Object'
    bl_options = {'UNDO'}

    only_above_ground: BoolProperty(
        name='Only Above Ground',
        description='Discard the part of the analemmas that is below ground',
        default=True,
    )
    points: IntProperty(
        name='Points',
        description='Number of points for each analemma',
        default=365,
        min=36,
        max=365,
    )

    def execute(self, context):
        try:
            # Keep the existing astronomical calculations and their edge
            # topology, including ground clipping, unchanged.
            vertices, edges = calc_analemma(
                context.scene,
                points=self.points,
                only_above_ground=self.only_above_ground,
            )
            _create_mesh_object(context, 'Analemma', vertices, edges, [])
        except Exception as exc:
            self.report(
                {'ERROR'},
                _error_text(
                    f'Could not create analemma geometry: {exc}',
                    f'アナレンマの形状を作成できませんでした: {exc}',
                ),
            )
            return {'CANCELLED'}
        return {'FINISHED'}


class SUNPOS_OT_Create_Surface_Object(Operator):
    bl_idname = 'world.create_sun_path_surface'
    bl_label = 'Create Sun Path Surface'
    bl_options = {'UNDO'}

    only_above_ground: BoolProperty(
        name='Only Above Ground',
        description='Discard the part of the surface that is below ground',
        default=True,
    )

    def execute(self, context):
        try:
            # Request non-triangulated faces so the public sun-path surface
            # retains its original quadrilateral topology.
            vertices, faces = calc_surface(
                context.scene,
                only_above_ground=self.only_above_ground,
                do_triangulate=False,
            )
            _create_mesh_object(context, 'Sun Surface', vertices, [], faces, smooth=True)
        except Exception as exc:
            self.report(
                {'ERROR'},
                _error_text(
                    f'Could not create sun-path surface: {exc}',
                    f'太陽軌道面を作成できませんでした: {exc}',
                ),
            )
            return {'CANCELLED'}
        return {'FINISHED'}
