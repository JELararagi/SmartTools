import json
import os
from pathlib import Path

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from .compat import default_manifest_path, default_output_root
from .translation import PROPERTY_CONTEXT, enum_label, tooltip
from .elements_catalog import RENDER_ELEMENT_CATALOG, render_element_property_definition


_PERSISTENCE_SKIP_CLASS_NAMES = {'SRR_LogItem'}


def _schedule_persistent_state_save_from_update(instance, context) -> None:
    try:
        if type(instance).__name__ in _PERSISTENCE_SKIP_CLASS_NAMES:
            return
        from . import settings as _srs_settings
        if _srs_settings.is_applying_context():
            return
        # CollectionProperty row edits do not publish a dependable RNA msgbus
        # event.  Persist them in the same update call so Variant Name, queue
        # label, camera/layer selectors, and every other editable row field are
        # durable before Blender can switch scenes or exit.
        if type(instance).__name__ in {'SRR_QueueItem', 'SRR_VariantItem'}:
            ctx = context or getattr(bpy, 'context', None)
            _srs_settings.snapshot_context(
                ctx,
                force=_srs_settings.is_npanel_state_save_enabled(ctx),
            )
            return
        scheduler = getattr(_srs_settings, '_schedule_external_config_snapshot', None)
        if callable(scheduler):
            scheduler(context or getattr(bpy, 'context', None), force=False, delay=0.45)
    except Exception:
        pass


def _wrap_persistent_update(factory):
    def _factory(*args, **kwargs):
        kwargs.setdefault('translation_context', PROPERTY_CONTEXT)
        # Keep accessor-backed properties and explicit custom setters unchanged;
        # they already persist themselves or are virtual values.
        if 'get' in kwargs or 'set' in kwargs:
            return factory(*args, **kwargs)
        old_update = kwargs.get('update')

        def _update(instance, context):
            if callable(old_update):
                try:
                    old_update(instance, context)
                except Exception:
                    pass
            _schedule_persistent_state_save_from_update(instance, context)

        kwargs['update'] = _update
        return factory(*args, **kwargs)
    return _factory


BoolProperty = _wrap_persistent_update(BoolProperty)
EnumProperty = _wrap_persistent_update(EnumProperty)
FloatProperty = _wrap_persistent_update(FloatProperty)
IntProperty = _wrap_persistent_update(IntProperty)
StringProperty = _wrap_persistent_update(StringProperty)


def _default_n_panel_state_save_value() -> bool:
    try:
        config_root = bpy.utils.user_resource('CONFIG', create=True)
        path = Path(config_root) / 'Smart_Render_Suite' / 'Smart_Render_Suite.json'
        legacy_path = Path(config_root) / 'Smart_Render_Suite.json'
        source = path if path.exists() else legacy_path
        if not source.exists():
            return True
        data = json.loads(source.read_text(encoding='utf-8'))
        if not isinstance(data, dict):
            return True
        scene_group = data.get('scene_groups', {}).get('srr_settings', {})
        if isinstance(scene_group, dict) and 'n_panel_state_save' in scene_group:
            from . import settings as _srs_settings
            return _srs_settings._coerce_saved_bool(scene_group.get('n_panel_state_save'), True)
        if 'n_panel_state_save_enabled' in data:
            from . import settings as _srs_settings
            return _srs_settings._coerce_saved_bool(data.get('n_panel_state_save_enabled'), True)
    except Exception:
        pass
    return True

def _default_output_root_value() -> str:
    try:
        return default_output_root(create=True)
    except Exception:
        try:
            from .storage import user_default_root
            base = str(user_default_root('renders', create=True))
        except Exception:
            version = '5.1'
            try:
                app_version = getattr(getattr(bpy, 'app', None), 'version', None)
                if app_version and len(app_version) >= 2:
                    version = f"{int(app_version[0])}.{int(app_version[1])}"
            except Exception:
                pass
            if os.name == 'nt':
                roaming = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
                config_root = os.path.join(roaming, 'Blender Foundation', 'Blender', version, 'config')
            else:
                config_root = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'config')
            base = os.path.join(config_root, 'Smart_Render_Suite', 'renders')
        try:
            os.makedirs(base, exist_ok=True)
        except Exception:
            pass
        return base



_ENUM_LABELS_JA = {
    "Auto": "自動",
    "Japanese": "日本語",
    "English": "英語",
    "Legacy Auto": "互換用自動",
    "Keep Current": "現在を維持",
    "Hybrid": "ハイブリッド",
    "Draft": "下書き",
    "Preview": "プレビュー",
    "Final": "最終",
    "None": "変更なし",
    "Essentials": "基本",
    "Composite": "合成",
    "Lookdev": "ルックデブ",
    "Lighting": "ライティング",
    "Technical": "テクニカル",
    "Dataset": "データセット",
    "From Pass Bundle": "現在のパス構成から",
    "Beauty Only": 'ビューティーのみ',
    "Split EXR Files": "EXR 分割ファイル",
    "Multilayer EXR": "マルチレイヤー EXR",
    "Main Output Only": "メイン出力のみ",
    "Main + AOV Passes": "メイン + AOV パス",
    "AOV Passes Only": "AOV パスのみ",
    "Current Frame": "現在フレーム",
    "Scene Range": "シーン範囲",
    "Custom Range": "カスタム範囲",
    "Direct Output": "直接出力",
    "Compositor / File Output": "コンポジター / ファイル出力",
    "Active Only": "アクティブのみ",
    "All Layers": "全レイヤー",
    "Camera × Layer": "カメラ × レイヤー",
    "Variants and Takes": "バリアントとテイク / テイク",
    "Inherit": "継承",
    "On": "オン",
    "Off": "オフ",
    "Override": "上書き",
    "Clear": "クリア",
    "Replace": "置き換え",
    "Merge": "マージ",
    "Swap Proxy / Render": "Proxy / Render を入れ替え",
    "Proxy Only": "プロキシのみ",
    "Render Only": "Render のみ",
    "Generic Headless": "汎用ヘッドレス",
    "Generic Manifest": "汎用マニフェスト",
    "Pair": "ペア",
    "Variant": "バリアントとテイク",
}


def _item_label(label_en: str) -> str:
    label = str(label_en or "")
    return enum_label(_ENUM_LABELS_JA.get(label, label), label)




def _n_panel_state_save_update(self, context) -> None:
    try:
        from . import settings as _srs_settings
        # ``apply_context`` restores this master switch before some later
        # foldout properties (JSON keys are sorted on disk). Treating that
        # restore assignment as a user edit used to write the still-default
        # ``show_always_on_toggles`` value back into the same canonical payload,
        # so the following field could no longer restore its saved value.
        if _srs_settings.is_applying_context():
            return
        enabled = bool(getattr(self, 'n_panel_state_save', True))
        _srs_settings.set_npanel_state_save_enabled(enabled, context=context, save=True)
    except Exception:
        pass

def _ui_language_update(self, context) -> None:
    try:
        from . import translation as _srs_translation
        _srs_translation.refresh_loaded_class_attributes(settings=self)
        _srs_translation.tag_redraw_all()
    except Exception:
        pass


UI_LANGUAGE_ITEMS = [
    ("AUTO", _item_label("Auto"), tooltip("Blender の言語設定に従います。", "Follow Blender's language setting.")),
    ("JA", _item_label("Japanese"), tooltip("日本語優先で表示します。", "Display Japanese first.")),
    ("EN", _item_label("English"), tooltip("英語優先で表示します。", "Display English first.")),
    ("BILINGUAL", _item_label("Legacy Auto"), tooltip("旧版の両表示設定を読み込むための互換項目です。現在は Blender の言語設定に従って 1 言語だけ表示します。", "Compatibility entry for older bilingual saves. It now shows only one language by following Blender's language setting.")),
]
ENGINE_MODE_ITEMS = [
    ("KEEP", _item_label("Keep Current"), tooltip("現在のレンダーエンジンを維持します。", "Keep the current render engine.")),
    ("CYCLES", _item_label("Cycles"), tooltip("高品質な物理ベースレンダー向けです。", "For physically based final-quality rendering.")),
    ("EEVEE", _item_label("Eevee"), tooltip("高速なプレビューとリアルタイム寄りの描画に向きます。", "For fast previews and real-time oriented rendering.")),
    ("WORKBENCH", _item_label("Workbench"), tooltip("技術確認や簡易なレビュー向けです。", "For technical checks and lightweight review renders.")),
]
EXECUTION_DEVICE_ITEMS = [
    ("AUTO", _item_label("Auto"), tooltip('ローカル実行・ヘッドレス書き出し・ファームブリッジに対して、自動判定の実行デバイス方針を渡します。', "Pass an automatic execution-device preference to local planning, headless exports, and farm bridges.")),
    ("CPU", _item_label("CPU"), tooltip('CPU 前提の安全な実行方針です。GPU を使わないファームや、安定性優先の検証に向きます。', "Safe CPU-oriented execution policy. Useful for farms without GPUs or stability-first verification.")),
    ("GPU", _item_label("GPU"), tooltip('GPU 優先の実行方針です。GPU ファームや高速ルックデブ / プレビュー向けです。', "GPU-preferred execution policy for GPU farms and faster lookdev / preview work.")),
    ("HYBRID", _item_label("Hybrid"), tooltip("CPU / GPU 混在の環境を想定した実行方針です。farm 側で最適配分したいときに向きます。", "Execution Plan policy for mixed CPU/GPU environments when the farm should decide the best distribution.")),
]
QUALITY_ITEMS = [
    ("DRAFT", _item_label("Draft"), tooltip("とにかく素早く確認したいとき。", "Use when you want the fastest possible check render.")),
    ("PREVIEW", _item_label("Preview"), tooltip("速度と品質のバランス型です。", "Balanced preset between speed and quality.")),
    ("FINAL", _item_label("Final"), tooltip("納品・レビュー提出向けの高品質設定です。", "High-quality settings intended for review or final delivery.")),
]
PASS_BUNDLE_ITEMS = [
    ("NONE", _item_label("None"), tooltip("パス設定を変更しません。", "Do not change render pass settings.")),
    ("ESSENTIAL", _item_label("Essentials"), tooltip('深度、ノーマル、ベクトルなど基本パスを有効化します。', "Enable core passes such as Depth, Normal and Vector.")),
    ("COMPOSITE", _item_label("Composite"), tooltip("合成でよく使う実用パス群です。", "A practical pass bundle for compositing workflows.")),
    ("LOOKDEV", _item_label("Lookdev"), tooltip("材質・ライティング検証に役立つ広めのパス構成です。", "A broader pass set useful for material and lighting lookdev.")),
    ("LIGHTING", _item_label("Lighting"), tooltip("ライト検証向けにライティング関連パスを重視します。", "Focus on passes useful when evaluating lighting.")),
    ("CRYPTOMATTE", _item_label("Crypto / ID"), tooltip('Cryptomatte やインデックス系マスクを重視します。', "Focus on Cryptomatte and ID-style masking passes.")),
    ("TECHNICAL", _item_label("Technical"), tooltip("データ確認やテクニカルレビュー向けのパス構成です。", "Pass setup for data inspection and technical review.")),
    ("DATASET", _item_label("Dataset"), tooltip("合成・機械学習用データ出力を意識した構成です。", "Pass setup intended for compositing or dataset generation.")),
]
RENDER_ELEMENT_PRESET_ITEMS = [
    ("FROM_PASS_BUNDLE", _item_label("From Pass Bundle"), tooltip("現在のパスバンドルをそのままレンダーエレメント構成として使います。", "Use the current pass bundle as the render-elements setup.")),
    ("BEAUTY", _item_label("Beauty Only"), tooltip('ビューティーとアルファを中心にした最小構成です。', "Minimal render-elements setup centered on Beauty and Alpha.")),
    ("COMPOSITE", _item_label("Composite"), tooltip("Z深度 / ノーマル / ベロシティ / AO / 影 / Crypto など合成向けの要素を揃えます。", "Prepare compositing-oriented elements such as Z Depth, Normal, Velocity, AO, Shadow and Crypto.")),
    ("LOOKDEV", _item_label("Lookdev"), tooltip("マテリアルとライティング確認向けに幅広い要素を有効化します。", "Enable a broader set of elements for material and lighting lookdev.")),
    ("LIGHTING", _item_label("Lighting"), tooltip("Diffuse / Specular / 屈折 / Volume 系の照明確認向け要素を重視します。", "Focus on lighting-oriented elements such as diffuse, specular, refraction and volume.")),
    ("CRYPTO_ID", _item_label("Crypto / ID"), tooltip("Object / Material / Asset ID と深度系のマスク要素を重視します。", "Focus on object/material/asset ID and depth-style masking elements.")),
    ("TECHNICAL", _item_label("Technical"), tooltip("ワールド位置 / ノーマル / ベロシティ / UV / ID など技術確認向け要素を揃えます。", "Prepare technical elements such as world position, normal, velocity, UVs and IDs.")),
    ("DATASET", _item_label("Dataset"), tooltip("深度・法線・位置・ID などデータセット生成向け要素を重視します。", "Focus on depth, normal, position and ID elements for dataset generation.")),
]
RENDER_ELEMENT_OUTPUT_ITEMS = [
    ("FILES", _item_label("Split EXR Files"), tooltip("各レンダーエレメントを個別の EXR ファイルとして保存します。", "Save each render element as its own EXR file.")),
    ("MULTILAYER", _item_label("Multilayer EXR"), tooltip('レンダーエレメントをビューレイヤーごとに 1 つの OpenEXR マルチレイヤーにまとめます。', "Pack render elements into one OpenEXR Multilayer per view layer.")),
]
MOVIE_PRESET_ITEMS = [
    ("H264_MP4", _item_label("H.264 MP4"), tooltip("汎用共有向けの標準プリセットです。MP4/H.264 で軽く扱いやすいです。", "General-purpose sharing preset. MP4/H.264 is lightweight and widely supported.")),
    ("H264_HIGH_MP4", _item_label("H.264 High MP4"), tooltip("レビューや提出向けに H.264 の品質を高めた MP4 です。", "Higher-quality H.264 MP4 for review or delivery.")),
    ("PRORES_PROXY_MOV", _item_label("ProRes Proxy MOV"), tooltip("編集・レビュー向けの軽量 ProRes Proxy MOV です。", "Lightweight ProRes Proxy MOV for editorial and review workflows.")),
    ("PRORES_422_MOV", _item_label("ProRes 422 MOV"), tooltip("合成や編集の中間素材に向く高品質 ProRes 422 MOV です。", "High-quality ProRes 422 MOV suitable for compositing and editorial intermediates.")),
    ("VP9_WEBM", _item_label("VP9 WebM"), tooltip("Web 配布向けの VP9 / WebM プリセットです。", "VP9 / WebM preset for web delivery.")),
    ("LOSSLESS_MKV", _item_label("Lossless MKV"), tooltip("検証や保管向けの可逆 FFV1 / MKV プリセットです。", "Lossless FFV1 / MKV preset for archival or technical verification.")),
]
VERIFICATION_SCOPE_ITEMS = [
    ("PRIMARY_ONLY", _item_label("Main Output Only"), tooltip("メインの保存結果だけを検証します。直接保存中心の軽い確認に向きます。", "Verify only the main saved render result. Good for lighter direct-output checks.")),
    ("PRIMARY_AND_PASSES", _item_label("Main + AOV Passes"), tooltip('メイン出力とファイル出力ノード経由のパス出力を両方検証します。AOV やコンポジット用途で最も安全です。', "Verify both the main output and pass outputs driven by File Output nodes. This is the safest choice for AOV and compositing workflows.")),
    ("PASSES_ONLY", _item_label("AOV Passes Only"), tooltip('ファイル出力ノード経由のパス出力だけを検証します。メイン保存を使わず、AOV 群だけを重視する運用向けです。', "Verify only pass outputs from File Output nodes. Useful when your workflow focuses on AOV deliverables rather than the main saved image.")),
]
IMAGE_FORMAT_ITEMS = [
    ("PNG", _item_label("PNG"), tooltip("可逆圧縮で扱いやすい汎用形式です。", "A general-purpose lossless image format.")),
    ("OPEN_EXR", _item_label("OpenEXR"), tooltip("HDR 単層 EXR。高品質な静止画やパス保存に向きます。", "Single-layer HDR EXR suitable for high-quality outputs.")),
    ("OPEN_EXR_MULTILAYER", _item_label("OpenEXR Multilayer"), tooltip("複数パスを 1 ファイルにまとめたいときに向きます。", "Useful when you want multiple passes in one file.")),
    ("JPEG", _item_label("JPEG"), tooltip("軽量ですが不可逆圧縮です。", "Lightweight but lossy.")),
    ("TIFF", _item_label("TIFF"), tooltip("高品質な静止画保存に向きます。", "Good for high-quality still image storage.")),
    ("WEBP", _item_label("WebP"), tooltip("共有用プレビューに便利です。", "Convenient for preview sharing.")),
]
FRAME_MODE_ITEMS = [
    ("CURRENT", _item_label("Current Frame"), tooltip("現在フレームだけを処理します。", "Process only the current frame.")),
    ("SCENE", _item_label("Scene Range"), tooltip("シーンの開始から終了フレームまでを使います。", "Use the scene's start and end frame range.")),
    ("CUSTOM", _item_label("Custom Range"), tooltip("下で指定したフレーム範囲だけを使います。", "Use only the custom frame range below.")),
]
QUEUE_COMPOSITING_ITEMS = [
    ("AUTO", _item_label("Auto"), tooltip("シーンとコンポジタの状態から直接保存とコンポジット保存を自動判断します。", "Automatically choose between direct output and compositor-assisted output from the scene state.")),
    ("DIRECT", _item_label("Direct Output"), tooltip('メインのレンダーの出力パスを使う通常保存を優先し、コンポジット出力を強制しません。', "Prefer the normal main render filepath output and do not force compositor output.")),
    ("COMPOSITOR", _item_label("Compositor / File Output"), tooltip('シーンのコンポジット使用を有効化し、ファイル出力ノードやコンポジット経由の出力を優先します。', "Enable scene.render.use_compositing and prefer File Output node / compositor-driven outputs.")),
]
VIEW_LAYER_MODE_ITEMS = [
    ("ACTIVE", _item_label("Active Only"), tooltip("現在アクティブなビューレイヤーのみを対象にします。", "Use only the active view layer.")),
    ("ALL", _item_label("All Layers"), tooltip("すべてのビューレイヤーを対象にします。", "Use all view layers.")),
]
QUEUE_SOURCE_MODE_ITEMS = [
    ("PAIRS", _item_label("Camera × Layer"), tooltip("カメラとビューレイヤーの組み合わせからキューを生成します。", "Build queue items from camera and view-layer combinations.")),
    ("VARIANTS", _item_label("Variants and Takes"), tooltip("保存済みバリアントとテイクからキューを生成します。", "Build queue items from saved variants/takes.")),
]
TRI_STATE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip("シーン設定を引き継ぎます。", "Inherit the current scene setting.")),
    ("ON", _item_label("On"), tooltip("この項目を強制的に有効化します。", "Force this option on for the variant.")),
    ("OFF", _item_label("Off"), tooltip("この項目を強制的に無効化します。", "Force this option off for the variant.")),
]
VARIANT_OVERRIDE_MODE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip("現在のシーン状態をそのまま使います。", "Keep the current scene state as-is.")),
    ("OVERRIDE", _item_label("Override"), tooltip("このバリアントとテイクに保存された対象だけを適用します。", "Apply the override stored on this variant.")),
    ("CLEAR", _item_label("Clear"), tooltip("この項目を明示的に空にします。", "Explicitly clear this item for the variant.")),
]
COLLECTION_OVERRIDE_MODE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip('現在のビューレイヤーのコレクション状態をそのまま使います。', "Keep the current collection state of the active view layer.")),
    ("REPLACE", _item_label("Replace"), tooltip('コレクションの除外 / ホールドアウト / 間接のみを一度リセットしてから、このバリアントとテイクの指定を適用します。', "Reset collection exclude / holdout / indirect-only flags first, then apply this variant's rules.")),
    ("MERGE", _item_label("Merge"), tooltip('現在のコレクション状態に、このバリアントとテイクの指定だけを追加で重ねます。', "Layer this variant's collection rules on top of the current collection state without resetting first.")),
]
OBJECT_VISIBILITY_OVERRIDE_MODE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip('現在のオブジェクトのレンダーの可視設定をそのまま使います。', "Keep the current render-visibility state of scene objects.")),
    ("REPLACE", _item_label("Replace"), tooltip('一度すべてのオブジェクトをレンダー可視に戻してから、このバリアントとテイクの表示 / 非表示ルールを適用します。', "Reset all objects to render-visible first, then apply this variant's show / hide rules.")),
    ("MERGE", _item_label("Merge"), tooltip('現在のオブジェクト状態に、このバリアントとテイクの表示 / 非表示ルールだけを重ねます。', "Layer this variant's show / hide rules on top of the current object state.")),
]
COLOR_MANAGEMENT_MODE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip("現在のカラーマネジメント設定を使います。", "Use the current scene color-management settings.")),
    ("OVERRIDE", _item_label("Override"), tooltip('このバリアントとテイクだけビュー変換 / ルック / 露出 / ガンマを上書きします。', "Override View Transform / Look / Exposure / Gamma for this variant only.")),
]
VARIANT_ENGINE_ITEMS = [("SCENE", _item_label("Inherit"), tooltip("シーンのエンジン設定を使います。", "Use the scene's current engine choice."))] + ENGINE_MODE_ITEMS[1:]
VARIANT_QUALITY_ITEMS = [("SCENE", _item_label("Inherit"), tooltip("現在の品質プリセットを使います。", "Use the scene's current quality preset."))] + QUALITY_ITEMS
VARIANT_PASS_ITEMS = [("SCENE", _item_label("Inherit"), tooltip("現在のパスバンドルを使います。", "Use the scene's current pass bundle."))] + PASS_BUNDLE_ITEMS
VARIANT_IMAGE_FORMAT_ITEMS = [("SCENE", _item_label("Inherit"), tooltip("現在の保存形式を使います。", "Use the scene's current image format."))] + IMAGE_FORMAT_ITEMS
VARIANT_EXECUTION_DEVICE_ITEMS = [("SCENE", _item_label("Inherit"), tooltip("全体設定の実行デバイス方針を使います。", "Use the global execution-device policy."))] + EXECUTION_DEVICE_ITEMS
REPRESENTATION_MODE_ITEMS = [
    ("SCENE", _item_label("Inherit"), tooltip('現在のシーンのプロキシ / レンダー表現状態をそのまま使います。', "Keep the current scene proxy/render representation state.")),
    ("SWAP", _item_label("Swap Proxy / Render"), tooltip('プロキシコレクション群を隠し、レンダーコレクション群を表示する Scene Assembly 風の切り替えです。', "Scene Assembly style swap that hides proxy collections and shows render collections.")),
    ("PROXY_ONLY", _item_label("Proxy Only"), tooltip('軽量プロキシ側だけを表示して、重いレンダー側を隠します。レビューやレイアウト確認向けです。', "Show only the lightweight proxy side and hide the heavy render side. Useful for review or layout checks.")),
    ("RENDER_ONLY", _item_label("Render Only"), tooltip('高解像度レンダー側だけを表示して、プロキシ側を隠します。最終レンダー向けです。', "Show only the high-resolution render side and hide the proxy side. Useful for final rendering.")),
]
NETWORK_RENDER_TARGET_ITEMS = [
    ("GENERIC", _item_label("Generic Headless"), tooltip('Blender のバックグラウンドレンダーと共有の出力を前提にした共通ネットワークジョブです。', "Generic network job based on Blender background rendering and shared outputs.")),
    ("DEADLINE", _item_label("Deadline"), tooltip("AWS Thinkbox Deadline 向けのジョブ定義を使います。", "Use a job definition aligned with AWS Thinkbox Deadline.")),
    ("FLAMENCO", _item_label("Flamenco"), tooltip("Blender Studio Flamenco 向けのジョブ定義を使います。", "Use a job definition aligned with Blender Studio Flamenco.")),
    ("BACKBURNER", _item_label("Backburner"), tooltip("Autodesk Backburner 向けのネットワークジョブを使います。", "Use a network-job definition aligned with Autodesk Backburner.")),
    ("CROWDRENDER", _item_label("Crowdrender"), tooltip("Crowdrender の LAN / P2P 分散レンダー向け定義を使います。", "Use a definition aligned with Crowdrender LAN/P2P distributed rendering.")),
    ("TEAM_RENDER", _item_label("Team Render"), tooltip("Cinema 4D Team Render / Team Render Server 向け定義を使います。", "Use a definition aligned with Cinema 4D Team Render / Team Render Server.")),
    ("TRACTOR", _item_label("Pixar Tractor"), tooltip("Pixar Tractor 向けのタスクグラフを使います。", "Use a task-graph oriented definition for Pixar Tractor.")),
    ("QUBE", _item_label("PipelineFX Qube!"), tooltip("PipelineFX Qube! 向け定義を使います。", "Use a definition aligned with PipelineFX Qube!.")),
    ("ROYAL_RENDER", _item_label("Royal Render"), tooltip("Royal Render 向け定義を使います。", "Use a definition aligned with Royal Render.")),
    ("SMEDGE", _item_label("Smedge"), tooltip("Smedge 向け定義を使います。", "Use a definition aligned with Smedge.")),
    ("SHEEPIT", _item_label("SheepIt"), tooltip("SheepIt 向けの軽量 Blender ジョブを使います。", "Use a lightweight Blender-centric job definition for SheepIt.")),
    ("RENDER_NETWORK", _item_label("Render Network"), tooltip("Render Network 向けのクラウド送信定義を使います。", "Use a cloud-submission definition aligned with Render Network.")),
]
BRIDGE_TARGET_ITEMS = [
    ("GENERIC", _item_label("Generic Manifest"), tooltip("共通の上位抽象マニフェストを書き出します。", "Export the generic superset manifest.")),
    ("MAYA_RENDER_SETUP", _item_label("Maya Render Setup"), tooltip("Maya Render Setup / AOV 連携向け JSON を書き出します。", "Export a JSON mapping for Maya Render Setup and AOV workflows.")),
    ("MAX_STATE_SETS", _item_label("3ds Max State Sets"), tooltip("3ds Max の State Sets / Batch Render 向け JSON を書き出します。", "Export a JSON mapping for 3ds Max State Sets and Batch Render.")),
    ("BACKBURNER", _item_label("Autodesk Backburner"), tooltip("3ds Max / Maya 系の Backburner 向けジョブ JSON を書き出します。", "Export a job JSON aligned with Autodesk Backburner style submissions.")),
    ("C4D_TAKES", _item_label("Cinema 4D Takes"), tooltip("C4D Take System / Tokens 向け JSON を書き出します。", "Export a JSON mapping for Cinema 4D Takes and Tokens.")),
    ("TEAM_RENDER", _item_label("Cinema 4D Team Render"), tooltip("Cinema 4D Team Render / Team Render Server 向け JSON を書き出します。", "Export a JSON mapping for Cinema 4D Team Render and Team Render Server workflows.")),
    ("HOUDINI_SOLARIS", _item_label("Houdini Solaris / PDG"), tooltip("Houdini Takes / Solaris / PDG 向け JSON を書き出します。", "Export a JSON mapping for Houdini Takes, Solaris and PDG.")),
    ("USD_HYDRA", _item_label("USD / Hydra"), tooltip("USD RenderSettings / AOV / Hydra delegate 向け JSON を書き出します。", "Export a JSON mapping for USD RenderSettings, AOVs and Hydra delegates.")),
    ("UNREAL_MRQ", _item_label("Unreal Movie Render Queue"), tooltip('Unreal Engine の Movie Render Queue 向け JSON を書き出します。', "Export a JSON mapping for Unreal Engine's Movie Run Render Queue.")),
    ("UNITY_RECORDER", _item_label("Unity Recorder"), tooltip("Unity Recorder / AOV Recorder 向け JSON を書き出します。", "Export a JSON mapping for Unity Recorder and AOV Recorder.")),
    ("KATANA", _item_label("Foundry Katana"), tooltip('Katana のルックデブ / ライティング / レンダーの統括向け JSON を書き出します。', "Export a JSON mapping for Foundry Katana lookdev, lighting and render orchestration workflows.")),
    ("CLARISSE_IFX", _item_label("Clarisse iFX"), tooltip('Clarisse iFX のプログレッシブレンダリング / その場のコンポジット寄り JSON を書き出します。', "Export a JSON mapping aligned with Clarisse iFX progressive rendering and in-place comp workflows.")),
    ("GOLAEM", _item_label("Golaem"), tooltip('Golaem のレンダー設定の確認 / クラウドレンダー前診断向け JSON を書き出します。', "Export a JSON mapping for Golaem crowd-render validation and render-settings checks.")),
    ("CROWDRENDER", _item_label("Crowdrender"), tooltip("Crowdrender の分散 P2P / LAN レンダー向け JSON を書き出します。", "Export a JSON mapping aligned with Crowdrender distributed P2P/LAN rendering workflows.")),
    ("DEADLINE", _item_label("Deadline"), tooltip("Deadline へ渡しやすいジョブ定義 JSON を書き出します。", "Export a job-definition JSON that is easy to feed into Deadline.")),
    ("FLAMENCO", _item_label("Flamenco"), tooltip("Flamenco 向けジョブ定義 JSON を書き出します。", "Export a Flamenco-oriented job-definition JSON.")),
    ("ROYAL_RENDER", _item_label("Royal Render"), tooltip("Royal Render 向けの正規化ジョブ定義 JSON を書き出します。", "Export a normalized job-definition JSON for Royal Render.")),
    ("QUBE", _item_label("PipelineFX Qube!"), tooltip("Qube! 向けの正規化ジョブ定義 JSON を書き出します。", "Export a normalized job-definition JSON for PipelineFX Qube!.")),
    ("SMEDGE", _item_label("Smedge"), tooltip("Smedge 向けの正規化ジョブ定義 JSON を書き出します。", "Export a normalized job-definition JSON for Smedge.")),
    ("TRACTOR", _item_label("Pixar Tractor"), tooltip("Pixar Tractor 向けのタスクグラフ JSON を書き出します。", "Export a task-graph JSON for Pixar Tractor.")),
    ("GRIDMARKETS", _item_label("GridMarkets"), tooltip("GridMarkets / Houdini TOPs / LOPs 寄りのジョブ JSON を書き出します。", "Export a job JSON aligned with GridMarkets and Houdini TOPs/LOPs style workflows.")),
    ("DROP_AND_RENDER", _item_label("Drop & Render"), tooltip("Drop & Render の Houdini PDG / TOPs 向けジョブ JSON を書き出します。", "Export a job JSON aligned with Drop & Render Houdini PDG/TOPs workflows.")),
    ("PRISM_PIPELINE", _item_label("Prism Pipeline"), tooltip("Prism Pipeline へ渡しやすいメタデータ JSON を書き出します。", "Export pipeline metadata JSON that is easy to hand off to Prism Pipeline.")),
    ("REBUSFARM", _item_label("RebusFarm"), tooltip("RebusFarm 連携用の正規化ジョブ JSON を書き出します。", "Export a normalized job JSON for RebusFarm-style submission flows.")),
    ("SHEEPIT", _item_label("SheepIt"), tooltip("SheepIt 向けの Blender 中心ジョブ定義 JSON を書き出します。", "Export a Blender-centric job definition JSON for SheepIt workflows.")),
    ("FOX_RENDERFARM", _item_label("Fox Renderfarm"), tooltip("Fox Renderfarm 向けのジョブ定義 JSON を書き出します。", "Export a job definition JSON for Fox Renderfarm oriented workflows.")),
    ("GARAGEFARM", _item_label("GarageFarm"), tooltip("GarageFarm 向けのジョブ定義 JSON を書き出します。", "Export a job definition JSON for GarageFarm oriented workflows.")),
    ("IRENDER", _item_label("iRender"), tooltip("iRender 向けのジョブ定義 JSON を書き出します。", "Export a job definition JSON for iRender oriented workflows.")),
    ("RANCH_COMPUTING", _item_label("Ranch Computing"), tooltip("Ranch Computing 向けのジョブ定義 JSON を書き出します。", "Export a job definition JSON for Ranch Computing oriented workflows.")),
    ("RENDER_NETWORK", _item_label("Render Network"), tooltip("Render Network / nested scene submission 向け JSON を書き出します。", "Export a JSON mapping aligned with Render Network style nested-scene submissions.")),
]
QUEUE_ITEM_SOURCE_ITEMS = [
    ("PAIR", _item_label("Pair"), tooltip("カメラ×ビューレイヤーから生成されたジョブです。", "Queue item generated from a camera/view-layer pair.")),
    ("VARIANT", _item_label("Variant"), tooltip("保存済みバリアントとテイクから生成されたジョブです。", "Queue item generated from a saved variant.")),
]


class SRR_LogItem(PropertyGroup):
    level: StringProperty(
        description=tooltip(
            "INFO / WARNING / ERROR の重要度です。",
            "Severity of the log entry: INFO / WARNING / ERROR.",
        ),
    )
    timestamp: StringProperty(
        description=tooltip(
            "ログが記録された日時です。",
            "Timestamp recorded for this log entry.",
        ),
    )
    message: StringProperty(
        description=tooltip(
            "詳細メッセージです。監査結果やレンダー失敗の理由が入ります。",
            "Detailed log message containing audit notes or render failure reasons.",
        ),
    )


class SRR_QueueItem(PropertyGroup):
    enabled: BoolProperty(
        default=True,
        description=tooltip(
            "このジョブをレンダー対象に含めます。オフにするとキューには残りますが実行時にスキップされます。",
            "Include this queue item in rendering. Disabled rows remain in the queue but are skipped during execution.",
        ),
    )
    source_mode: EnumProperty(
        items=QUEUE_ITEM_SOURCE_ITEMS,
        default="PAIR",
        description=tooltip(
            "この行がカメラ×レイヤー由来か、バリアントとテイク由来かを表します。",
            "Shows whether this row came from a camera/layer pair or from a saved variant.",
        ),
    )
    camera_name: StringProperty(
        description=tooltip(
            '組み合わせ行で使うカメラ名です。バリアント行では解決結果の補助値としても使われます。',
            "Camera name used by PAIR rows. For VARIANT rows it can also store the resolved fallback value.",
        ),
    )
    view_layer_name: StringProperty(
        description=tooltip(
            '組み合わせ行で使うビューレイヤー名です。バリアント行では解決結果の補助値としても使われます。',
            "View layer name used by PAIR rows. For VARIANT rows it can also store the resolved fallback value.",
        ),
    )
    variant_name: StringProperty(
        description=tooltip(
            'バリアント行で参照するバリアントとテイク名です。',
            "Variant Name referenced by VARIANT rows.",
        ),
    )
    label: StringProperty(
        description=tooltip(
            "キュー一覧で見やすくするための表示名です。",
            "Display label shown in the queue list for easier identification.",
        ),
    )


class SRR_VariantItem(PropertyGroup):
    enabled: BoolProperty(
        name="Enabled",
        default=True,
        description=tooltip(
            "このバリアントとテイクをレンダーキューを生成の対象に含めます。",
            "Include this variant when building a queue from variants.",
        ),
    )
    name: StringProperty(
        name="Variant Name",
        default="Variant",
        description=tooltip(
            "このバリアントとテイクの名前です。出力の {variant} トークンやブリッジ出力でも使われます。",
            "Name of this variant. It is also used by the {variant} output token and bridge exports.",
        ),
    )
    description: StringProperty(
        name="Description",
        default="",
        description=tooltip(
            "用途メモです。どのショット・レビュー目的なのかを書いておくと管理しやすくなります。",
            "Optional note describing the purpose of this variant, such as a shot context or review goal.",
        ),
    )
    parent_variant_name: StringProperty(
        name="Parent Variant",
        default="",
        description=tooltip(
            '親バリアントとテイク名です。指定すると、空欄や継承の項目は親から継承します。C4D Take System や Houdini Takes のような階層的な状態管理に使えます。',
            "Optional parent variant. When set, empty fields and Inherit-style options are resolved from the parent, enabling hierarchical take-style workflows similar to Cinema 4D Takes and Houdini Takes.",
        ),
    )
    camera_name: StringProperty(
        name="Camera",
        default="",
        description=tooltip(
            "このバリアントとテイクで使うカメラ名です。空欄なら現在のシーンカメラを使います。",
            "Camera to use for this variant. Leave empty to use the current scene camera.",
        ),
    )
    view_layer_name: StringProperty(
        name="View Layer",
        default="",
        description=tooltip(
            "このバリアントとテイクで使うビューレイヤーです。空欄ならアクティブレイヤーを使います。",
            "View layer to use for this variant. Leave empty to use the active view layer.",
        ),
    )
    engine_mode: EnumProperty(
        name="Engine Override",
        items=VARIANT_ENGINE_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけレンダーエンジンを上書きします。",
            "Override the render engine for this variant only.",
        ),
    )
    quality_mode: EnumProperty(
        name="Quality Override",
        items=VARIANT_QUALITY_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけ品質プリセットを上書きします。",
            "Override the quality preset for this variant only.",
        ),
    )
    resolution_percentage_override: IntProperty(
        name="Resolution Override",
        default=0,
        min=0,
        max=1000,
        description=tooltip(
            "0 ならシーン設定を継承します。1 以上を入れるとこのバリアントとテイクだけ解像度倍率を上書きします。",
            "Use 0 to inherit the scene value. Any value above 0 overrides the resolution scale for this variant.",
        ),
    )
    resolution_x_override: IntProperty(
        name="Width Override",
        default=0,
        min=0,
        max=65536,
        description=tooltip(
            "0 ならシーン設定を継承します。1 以上を入れるとこのバリアントとテイクだけ出力幅を上書きします。片方だけ指定した場合は元の縦横比を保ったまま反対側を自動計算します。",
            "Use 0 to inherit the scene width. Any value above 0 overrides the output width for this variant. When only one side is set, the other side is computed automatically while preserving the original aspect ratio.",
        ),
    )
    resolution_y_override: IntProperty(
        name="Height Override",
        default=0,
        min=0,
        max=65536,
        description=tooltip(
            "0 ならシーン設定を継承します。1 以上を入れるとこのバリアントとテイクだけ出力高さを上書きします。片方だけ指定した場合は元の縦横比を保ったまま反対側を自動計算します。",
            "Use 0 to inherit the scene height. Any value above 0 overrides the output height for this variant. When only one side is set, the other side is computed automatically while preserving the original aspect ratio.",
        ),
    )
    sample_multiplier_override: FloatProperty(
        name="Sample Override",
        default=0.0,
        min=0.0,
        max=16.0,
        soft_min=0.0,
        soft_max=4.0,
        description=tooltip(
            "0.0 なら継承、0 より大きい値を入れるとサンプル倍率を上書きします。",
            "Use 0.0 to inherit. Any value above 0 overrides the sample multiplier for this variant.",
        ),
    )
    denoise_mode: EnumProperty(
        name="Denoise Override",
        items=TRI_STATE_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけデノイズのオン・オフを上書きします。",
            "Override denoising on or off for this variant only.",
        ),
    )
    adaptive_sampling_mode: EnumProperty(
        name="Adaptive Override",
        items=TRI_STATE_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけ適応サンプリングのオン・オフを上書きします。",
            "Override adaptive sampling on or off for this variant only.",
        ),
    )
    motion_blur_mode: EnumProperty(
        name="Motion Blur Override",
        items=TRI_STATE_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけモーションブラーのオン・オフを上書きします。",
            "Override motion blur on or off for this variant only.",
        ),
    )
    freestyle_mode: EnumProperty(
        name="Freestyle / Line Override",
        items=TRI_STATE_ITEMS,
        default="SCENE",
        description=tooltip(
            "Freestyle / Line Art 系のライン出力をこのバリアントとテイクだけ上書きします。",
            "Override Freestyle / line-style output for this variant only.",
        ),
    )
    pass_bundle: EnumProperty(
        name="Pass Bundle Override",
        items=VARIANT_PASS_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけパスバンドルを上書きします。",
            "Override the pass bundle for this variant only.",
        ),
    )
    image_format_override: EnumProperty(
        name="Format Override",
        items=VARIANT_IMAGE_FORMAT_ITEMS,
        default="SCENE",
        description=tooltip(
            "このバリアントとテイクだけ保存形式を上書きします。",
            "Override the image file format for this variant only.",
        ),
    )
    use_custom_frames: BoolProperty(
        name="Custom Frames",
        default=False,
        description=tooltip(
            "このバリアントとテイク専用のフレーム範囲を使います。オフなら全体設定を継承します。",
            "Use a custom frame range for this variant. Disable it to inherit the global frame setting.",
        ),
    )
    frame_start: IntProperty(
        name="Start Frame",
        default=1,
        description=tooltip(
            "バリアントとテイク専用フレーム範囲の開始です。",
            "Start Frame for the variant-specific frame range.",
        ),
    )
    frame_end: IntProperty(
        name="End Frame",
        default=250,
        description=tooltip(
            "バリアントとテイク専用フレーム範囲の終了です。",
            "End Frame for the variant-specific frame range.",
        ),
    )
    material_override_mode: EnumProperty(
        name="Material Override Mode",
        items=VARIANT_OVERRIDE_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'マテリアル上書きを継承するか、適用するか、明示的に解除するかを選びます。',
            "Choose whether the material override should be inherited, applied, or explicitly cleared.",
        ),
    )
    material_override_name: StringProperty(
        name="Material Override",
        default="",
        description=tooltip(
            'ビューレイヤーのマテリアル上書きを使ってクレイレンダーや技術確認をしたい時に使います。',
            "Use this when you want a clay render or technical check through the View Layer material override.",
        ),
    )
    world_override_mode: EnumProperty(
        name="World Override Mode",
        items=VARIANT_OVERRIDE_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'ワールドを継承するか、適用するか、明示的に解除するかを選びます。',
            "Choose whether the world should be inherited, overridden, or explicitly cleared.",
        ),
    )
    world_override_name: StringProperty(
        name="World Override",
        default="",
        description=tooltip(
            'このバリアントとテイクだけワールドを切り替えたいときに使います。HDRI バリエーション管理に便利です。',
            "Use this to switch the World only for this variant. Useful for HDRI variation management.",
        ),
    )
    collection_override_mode: EnumProperty(
        name="Collection Override Mode",
        items=COLLECTION_OVERRIDE_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'コレクションの表示状態を完全に置き換えるか、現在の状態へ重ねるかを選びます。',
            "Choose whether collection visibility state should fully replace the current state or merge with it.",
        ),
    )
    film_transparent_mode: EnumProperty(
        name="Film Transparent Override",
        items=TRI_STATE_ITEMS,
        default="SCENE",
        description=tooltip(
            'このバリアントとテイクだけフィルム透過のオン・オフを上書きします。',
            "Override Film Transparent on or off for this variant only.",
        ),
    )
    color_management_mode: EnumProperty(
        name="Color Management Mode",
        items=COLOR_MANAGEMENT_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'このバリアントとテイクだけビュー変換 / ルック / 露出 / ガンマを上書きします。',
            "Override View Transform / Look / Exposure / Gamma for this variant only.",
        ),
    )
    view_transform_override: StringProperty(
        name="View Transform",
        default="",
        description=tooltip(
            'カラーマネジメントを上書きにした時のビュー変換名です。空欄なら現在値を維持します。',
            "View Transform name used when Color Management is set to Override. Leave blank to keep the current value.",
        ),
    )
    look_override: StringProperty(
        name="Look",
        default="",
        description=tooltip(
            'カラーマネジメントを上書きにした時のルック名です。空欄なら現在値を維持します。',
            "Look name used when Color Management is set to Override. Leave blank to keep the current value.",
        ),
    )
    use_exposure_override: BoolProperty(
        name="Override Exposure",
        default=False,
        description=tooltip(
            'オンにすると下の露出値をこのバリアントとテイクだけ適用します。',
            "Enable to apply the Exposure value below only for this variant.",
        ),
    )
    exposure_override: FloatProperty(
        name="Exposure",
        default=0.0,
        min=-32.0,
        max=32.0,
        soft_min=-10.0,
        soft_max=10.0,
        description=tooltip(
            'カラーマネジメントを上書きにした時の露出値です。',
            "Exposure value used when Color Management is set to Override.",
        ),
    )
    use_gamma_override: BoolProperty(
        name="Override Gamma",
        default=False,
        description=tooltip(
            'オンにすると下のガンマ値をこのバリアントとテイクだけ適用します。',
            "Enable to apply the Gamma value below only for this variant.",
        ),
    )
    gamma_override: FloatProperty(
        name="Gamma",
        default=1.0,
        min=0.01,
        max=8.0,
        soft_min=0.25,
        soft_max=4.0,
        description=tooltip(
            'カラーマネジメントを上書きにした時のガンマ値です。',
            "Gamma value used when Color Management is set to Override.",
        ),
    )
    include_collections: StringProperty(
        name="Collections To Unhide",
        default="",
        description=tooltip(
            'このバリアントとテイクでレンダー対象に戻したいコレクションをカンマ区切りで指定します。そのままの名前のほか glob:Env_* や re:^BG_ のようなセレクターにも対応します。',
            "Comma-separated collections that should be made renderable for this variant. Supports exact names plus selectors such as glob:Env_* and re:^BG_.",
        ),
    )
    exclude_collections: StringProperty(
        name="Collections To Exclude",
        default="",
        description=tooltip(
            'このバリアントとテイクでレンダーから外したいコレクションをカンマ区切りで指定します。完全一致 / glob: / re: セレクターに対応します。',
            "Comma-separated collections to exclude from rendering. Supports exact, glob: and re: selectors.",
        ),
    )
    holdout_collections: StringProperty(
        name="Collections To Holdout",
        default="",
        description=tooltip(
            'ホールドアウトにしたいコレクションをカンマ区切りで指定します。完全一致 / glob: / re: セレクターに対応し、マスク用途向けです。',
            "Comma-separated collections to mark as holdout. Supports exact, glob: and re: selectors and is useful for masking workflows.",
        ),
    )
    indirect_only_collections: StringProperty(
        name="Collections Indirect Only",
        default="",
        description=tooltip(
            '間接のみにしたいコレクションをカンマ区切りで指定します。完全一致 / glob: / re: セレクターに対応します。',
            "Comma-separated collections to set as indirect-only. Supports exact, glob: and re: selectors.",
        ),
    )
    object_visibility_override_mode: EnumProperty(
        name="Object Visibility Mode",
        items=OBJECT_VISIBILITY_OVERRIDE_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'オブジェクト単位のレンダーの可視設定を継承するか、このバリアントとテイクの表示 / 非表示ルールで上書きするかを選びます。',
            "Choose whether object-level render visibility should be inherited or overridden by this variant's show / hide rules.",
        ),
    )
    show_objects: StringProperty(
        name="Objects To Show",
        default="",
        description=tooltip(
            'このバリアントとテイクでレンダー可視に戻したいオブジェクトをカンマ区切りで指定します。ライトやカメラもオブジェクトなので指定できます。そのままの名前のほか glob:Light_* や re:^BG_ のようなセレクターにも対応します。',
            "Comma-separated objects to force render-visible for this variant. Lights and cameras are objects too. Supports exact names plus selectors such as glob:Light_* and re:^BG_.",
        ),
    )
    hide_objects: StringProperty(
        name="Objects To Hide",
        default="",
        description=tooltip(
            'このバリアントとテイクでレンダーから外したいオブジェクトをカンマ区切りで指定します。ライトリグのオン/オフ 切り替えや、3ds Max State Sets / C4D Takes 的な見え方差分管理に向きます。完全一致 / glob: / re: セレクターに対応します。',
            "Comma-separated objects to exclude from rendering for this variant. Useful for light-rig toggles and look variations similar to 3ds Max State Sets or C4D Takes. Supports exact, glob: and re: selectors.",
        ),
    )
    representation_mode: EnumProperty(
        name="Representation Mode",
        items=REPRESENTATION_MODE_ITEMS,
        default="SCENE",
        description=tooltip(
            'Maya Scene Assembly 風にプロキシ / レンダー用コレクション群を切り替える上位抽象です。プロキシとレンダーを完全一致 / glob: / re: セレクターで指定します。',
            "Superset abstraction for Maya Scene Assembly style proxy/render collection switching. Define proxy and render collection groups with exact, glob: or re: selectors.",
        ),
    )
    proxy_collections: StringProperty(
        name="Proxy Collections",
        default="",
        description=tooltip(
            '軽量表示やレビュー用のプロキシコレクション群です。表現モードが有効なときに完全一致 / glob: / re: セレクターで解決されます。',
            "Proxy collection group used for lightweight display or review. Resolved with exact, glob: or re: selectors when representation mode is enabled.",
        ),
    )
    render_collections: StringProperty(
        name="Render Collections",
        default="",
        description=tooltip(
            '最終レンダー用の高解像度コレクション群です。表現モードが有効なときに完全一致 / glob: / re: セレクターで解決されます。',
            "High-resolution render collection group. Resolved with exact, glob: or re: selectors when representation mode is enabled.",
        ),
    )
    output_root_override: StringProperty(
        name="Output Root Override",
        subtype='DIR_PATH',
        default="",
        description=tooltip(
            "このバリアントとテイクだけ保存先の親フォルダーを上書きします。空欄なら全体設定を継承します。",
            "Override the output root only for this variant. Leave empty to inherit the global setting.",
        ),
    )
    output_dir_pattern_override: StringProperty(
        name="Directory Pattern Override",
        default="",
        description=tooltip(
            "このバリアントとテイクだけフォルダーパターンを上書きします。空欄なら継承です。",
            "Override the directory pattern only for this variant. Leave empty to inherit.",
        ),
    )
    output_file_pattern_override: StringProperty(
        name="File Pattern Override",
        default="",
        description=tooltip(
            "このバリアントとテイクだけファイル名パターンを上書きします。空欄なら継承です。",
            "Override the file naming pattern only for this variant. Leave empty to inherit.",
        ),
    )
    stamp_note_override: StringProperty(
        name="Stamp Note Override",
        default="",
        description=tooltip(
            "空欄なら全体のスタンプメモを使い、入力するとこのバリアントとテイクだけ別メモを表示します。",
            "Leave empty to use the global stamp note, or enter text to override it for this variant only.",
        ),
    )
    job_name_override: StringProperty(
        name="Job Name Override",
        default="",
        description=tooltip(
            '空欄なら全体のジョブ名を使います。入力するとこのバリアントとテイクだけ {job} / {shot} トークンとブリッジジョブ名の基準を差し替えます。',
            "Leave empty to use the global Job Name. When filled, this variant overrides the {job}/{shot} tokens and becomes the base job name used by bridge exports.",
        ),
    )
    job_tags_override: StringProperty(
        name="Job Tags Override",
        default="",
        description=tooltip(
            '空欄なら全体のジョブタグを使います。入力するとこのバリアントとテイクだけファーム / ブリッジ向けタグを差し替えます。カンマ区切りで複数指定できます。',
            "Leave empty to use the global Job Tags. When filled, this variant replaces the farm/bridge tags for that variant only. Multiple tags can be separated with commas.",
        ),
    )
    execution_device_mode_override: EnumProperty(
        name="Execution Plan Device Override",
        items=VARIANT_EXECUTION_DEVICE_ITEMS,
        default="SCENE",
        description=tooltip(
            'このバリアントとテイクだけ CPU / GPU / ハイブリッドの実行方針を上書きします。Deadline や Tractor など下流の実行計画にも反映されます。',
            "Override the CPU/GPU/Hybrid execution policy for this variant only. The hint is also propagated into downstream execution plans such as Deadline or Tractor exports.",
        ),
    )
    frame_chunk_size_override: IntProperty(
        name="Chunk Size Override",
        default=0,
        min=0,
        max=100000,
        description=tooltip(
            "0 なら全体設定を継承します。1 以上を入れると、このバリアントとテイクだけフレーム分割サイズを上書きします。",
            "Use 0 to inherit the global setting. Any value above 0 overrides the frame chunk size for this variant.",
        ),
    )
    concurrent_tasks_override: IntProperty(
        name="Concurrent Tasks Override",
        default=0,
        min=0,
        max=1024,
        description=tooltip(
            "0 なら全体設定を継承します。1 以上を入れると、このバリアントとテイクだけ同時実行タスク数ヒントを上書きします。",
            "Use 0 to inherit the global setting. Any value above 0 overrides the concurrent-task hint for this variant.",
        ),
    )
    farm_priority_override: IntProperty(
        name="Farm Priority Override",
        default=-1,
        min=-1,
        max=100000,
        description=tooltip(
            '-1 なら全体設定を継承します。0 以上を入れると、このバリアントとテイクだけファーム優先度を上書きします。',
            "Use -1 to inherit the global setting. Any value above or equal to 0 overrides the farm priority for this variant.",
        ),
    )
    memory_gb_hint_override: FloatProperty(
        name="Memory GB Override",
        default=-1.0,
        min=-1.0,
        max=65536.0,
        precision=2,
        description=tooltip(
            "-1 なら全体設定を継承します。0 以上を入れると、このバリアントとテイクだけタスク当たりのメモリ見積りを上書きします。",
            "Use -1 to inherit the global setting. Any value above or equal to 0 overrides the per-task memory estimate for this variant.",
        ),
    )
    temporal_subsamples_override: IntProperty(
        name="Temporal Subsamples Override",
        default=0,
        min=0,
        max=4096,
        description=tooltip(
            "0 なら全体設定を継承します。1 以上を入れると、このバリアントとテイクだけ時間方向サブサンプル数を上書きします。",
            "Use 0 to inherit the global setting. Any value above 0 overrides the temporal subsample count for this variant.",
        ),
    )
    spatial_subsamples_override: IntProperty(
        name="Spatial Subsamples Override",
        default=0,
        min=0,
        max=4096,
        description=tooltip(
            "0 なら全体設定を継承します。1 以上を入れると、このバリアントとテイクだけ空間サブサンプル数を上書きします。",
            "Use 0 to inherit the global setting. Any value above 0 overrides the spatial subsample count for this variant.",
        ),
    )
    accumulation_samples_override: IntProperty(
        name="Accumulation Samples Override",
        default=0,
        min=0,
        max=16384,
        description=tooltip(
            "0 なら全体設定を継承します。1 以上を入れると、このバリアントとテイクだけ蓄積サンプル数を上書きします。",
            "Use 0 to inherit the global setting. Any value above 0 overrides the accumulation sample count for this variant.",
        ),
    )


class SRR_Settings(PropertyGroup):
    ui_language: EnumProperty(
        name="UI Language",
        items=UI_LANGUAGE_ITEMS,
        default="AUTO",
        update=_ui_language_update,
        description=tooltip(
            "UI を Blender の言語設定・日本語・英語のどれで表示するかを決めます。旧版互換項目も 1 言語表示として扱います。",
            "Choose whether the UI should follow Blender's language, Japanese, or English. The legacy compatibility option also resolves to a single-language display.",
        ),
    )
    compact_mode: BoolProperty(
        name="Compact Mode",
        default=True,
        description=tooltip(
            "余白と補助文を減らしてコンパクト表示にします。",
            "Reduce spacing and helper text for a more compact layout.",
        ),
    )
    show_advanced: BoolProperty(
        name="Show Advanced",
        default=False,
        description=tooltip(
            '上級者向けの詳細設定、詳細キュー編集、ブリッジ、ログ、フルバリアントとテイク上書き項目を表示します。',
            "Show advanced controls, full queue editing, bridge tools, logs, and the complete variant override set.",
        ),
    )
    show_always_on_toggles: BoolProperty(
        name="Always-on Toggles",
        default=False,
        description=tooltip(
            "Nパネル最上部の常時機能切り替えグループを開閉します。既定では閉じた状態にして、起動時や通常表示時の余計な描画・検出処理を避けます。",
            "Open or close the Always-on Toggles group at the top of the N-panel. It is closed by default to avoid unnecessary drawing and detection work during startup and normal display.",
        ),
    )

    n_panel_state_save: BoolProperty(
        name="N-panel State Save",
        default=_default_n_panel_state_save_value(),
        update=_n_panel_state_save_update,
        description=tooltip(
            '有効時は、常時機能切り替え、各セクションの開閉、Nパネル内の設定変更を Blender の設定フォルダー/Smart_Render_Suite フォルダーにある Smart_Render_Suite.json へ変更イベントごとに保存します。無効化操作だけを最後に1回保存し、その後は再有効化まで書き込みません。',
            "When enabled, Always-on Toggles, section foldouts, and Smart Render N-panel settings are saved on change events to Smart_Render_Suite/Smart_Render_Suite.json in Blender's config folder. Turning it off is saved once; no later writes occur until it is enabled again.",
            usage_ja="頻繁に設定を変える場合や、シーン切り替え・再起動後もすぐ同じNパネル状態に戻したい場合は有効にします。",
            usage_en="Enable this when you frequently change settings or want the same N-panel state restored immediately after scene changes or restarts.",
            tip_ja="無効化操作を保存した後はJSONへ書き込みません。再有効化すると、その時点の設定全体を即時保存します。",
            tip_en="After the disable transition is saved, no JSON writes occur. Re-enabling immediately saves the complete current settings state.",
        ),
    )
    show_section_smart_render_overview: BoolProperty(
        name="Smart Render Section",
        default=False,
        description=tooltip(
            "Smart Render の概要、主要操作、保存先、品質、パス、キュー、診断状態をまとめたセクションを開閉します。",
            "Open or close the Smart Render overview section with primary actions, output root, quality, pass, queue, and audit status.",
        ),
    )
    show_section_integrated_tools: BoolProperty(
        name="Integrated Tools Section",
        default=False,
        description=tooltip(
            "同梱・統合されたレンダー補助ツールの一覧、検索、手動読み込み状態を表示するセクションを開閉します。",
            "Open or close the section that shows bundled integrated tools, search controls, and manual loading status.",
        ),
    )
    integrated_tool_section_state_json: StringProperty(
        name="Integrated Tool Section States",
        default="{}",
        description=tooltip(
            "その他ツールの中で、各同梱ツールのカスタムセクション開閉状態をJSONとして保存します。通常は操作する必要はありません。",
            "Stores the custom per-tool foldout states inside the Integrated Tools section as JSON. You normally do not need to edit this directly.",
        ),
        options={'HIDDEN'},
    )
    show_section_dashboard: BoolProperty(
        name="Dashboard Section",
        default=False,
        description=tooltip(
            "レンダー状態、出力、監査結果、リスク、欠落アセットなどの概要を確認するダッシュボードセクションを開閉します。",
            "Open or close the dashboard section for render status, output, audit results, risk, and missing asset summaries.",
        ),
    )
    show_section_render_profile: BoolProperty(
        name="Render Profile Section",
        default=False,
        description=tooltip(
            "レンダーエンジン、品質プリセット、サンプル、解像度、ノイズ低減、パスバンドル、画像形式の設定セクションを開閉します。",
            "Open or close the render profile section for engine, quality, samples, resolution, denoise, pass bundle, and image format settings.",
        ),
    )
    show_section_render_elements: BoolProperty(
        name="Render Elements Section",
        default=False,
        description=tooltip(
            "ビューティー、アルファ、Z深度、法線、ベロシティ、IDなどの Render Elements / AOV 構成を管理するセクションを開閉します。",
            "Open or close the Render Elements / AOV section for Beauty, alpha, Z depth, normals, velocity, IDs, and related outputs.",
        ),
    )
    show_section_network_render: BoolProperty(
        name="Network Render Section",
        default=False,
        description=tooltip(
            'ヘッドレス実行、レンダーファーム、外部実行向けのマニフェスト、JSON、スクリプト出力を準備するセクションを開閉します。',
            "Open or close the network render section for preparing manifests, JSON, and scripts for headless or farm execution.",
        ),
    )
    show_section_workflows: BoolProperty(
        name="Workflow Recipes Section",
        default=False,
        description=tooltip(
            "用途別レシピと安全なシーン自動整理を実行するワークフローセクションを開閉します。",
            "Open or close the workflow recipes section for task presets and safe automatic scene repair.",
        ),
    )
    show_section_execution: BoolProperty(
        name="Execution Plan Section",
        default=False,
        description=tooltip(
            "ローカル、ヘッドレス、ファーム実行で使うデバイス方針、フレーム分割、同時タスク、再試行などの実行計画セクションを開閉します。",
            "Open or close the execution plan section for device policy, chunking, concurrency, retries, and farm execution hints.",
        ),
    )
    show_section_variants: BoolProperty(
        name="Variants and Takes Section",
        default=False,
        description=tooltip(
            "カメラ、ビューレイヤー、フレーム、品質、出力などをバリアントとテイク単位で保存・適用するセクションを開閉します。",
            "Open or close the variants and takes section for saving and applying camera, View Layer, frame, quality, and output overrides.",
        ),
    )
    show_section_output: BoolProperty(
        name="Output Section",
        default=False,
        description=tooltip(
            "保存先、フォルダー名、ファイル名、上書き回避、検証、ムービー化、出力トークンを管理するセクションを開閉します。",
            "Open or close the output section for output root, folder and file naming, collision handling, verification, movie encoding, and tokens.",
        ),
    )
    show_section_batch: BoolProperty(
        name="Render Queue Section",
        default=False,
        description=tooltip(
            "カメラ、ビューレイヤー、バリアント、フレーム範囲からレンダーキューを作成・編集・実行するセクションを開閉します。",
            "Open or close the render queue section for creating, editing, and running jobs from cameras, View Layers, variants, and frame ranges.",
        ),
    )
    show_section_extra_tools: BoolProperty(
        name="Extra Tools Section",
        default=False,
        description=tooltip(
            "簡易表示中に使う診断、修復、AOVノード、レシピ、ブリッジ、ログへの入口セクションを開閉します。",
            "Open or close the simplified extra tools section for analysis, repair, AOV nodes, recipes, bridge export, and logs.",
        ),
    )
    show_section_bridge: BoolProperty(
        name="Bridge Section",
        default=False,
        description=tooltip(
            '外部DCC、USD、リアルタイムエンジン、レンダーファーム向けのブリッジマニフェストを作成するセクションを開閉します。',
            "Open or close the bridge section for creating adapter-friendly manifests for external DCCs, USD, realtime engines, and render farms.",
        ),
    )
    show_section_logs: BoolProperty(
        name="Logs Section",
        default=False,
        description=tooltip(
            "診断、準備、レンダー実行、出力検証で記録された情報、警告、エラーを確認するログセクションを開閉します。",
            "Open or close the logs section for information, warnings, and errors recorded by analysis, preparation, rendering, and verification.",
        ),
    )
    engine_mode: EnumProperty(
        name="Engine",
        items=ENGINE_MODE_ITEMS,
        default="KEEP",
        description=tooltip(
            'レンダー時に使うエンジン方針です。現在を維持なら現在のシーン設定をそのまま使います。',
            "Choose the render-engine policy. Keep Current preserves the scene's current engine.",
        ),
    )
    quality_mode: EnumProperty(
        name="Quality",
        items=QUALITY_ITEMS,
        default="PREVIEW",
        description=tooltip(
            '全体の品質プリセットです。下書き / プレビュー / 最終から目的に合わせて選びます。',
            "Global quality preset. Choose Draft, Preview or Final depending on the goal.",
        ),
    )
    sample_multiplier: FloatProperty(
        name="Sample Multiplier",
        default=1.0,
        min=0.1,
        max=16.0,
        soft_min=0.25,
        soft_max=4.0,
        description=tooltip(
            "品質プリセットのベースサンプル数に掛ける倍率です。1.0 が標準です。",
            "Multiplier applied to the base sample count of the selected quality preset. 1.0 is standard.",
        ),
    )
    resolution_percentage: IntProperty(
        name="Resolution %",
        default=100,
        min=1,
        max=1000,
        description=tooltip(
            "シーン解像度に対する出力倍率です。",
            "Output scale relative to the scene resolution.",
        ),
    )
    use_denoise: BoolProperty(
        name="Denoise",
        default=True,
        description=tooltip(
            "ノイズ低減を有効にします。Cycles で特に有効です。",
            "Enable denoising. Especially helpful with Cycles.",
        ),
    )
    use_adaptive_sampling: BoolProperty(
        name="Adaptive Sampling",
        default=True,
        description=tooltip(
            "必要な場所にだけ多くのサンプルを使うようにします。",
            "Spend more samples only where they are needed.",
        ),
    )
    use_motion_blur: BoolProperty(
        name="Motion Blur",
        default=False,
        description=tooltip(
            "動きの速い要素にモーションブラーを付けます。",
            "Add motion blur to fast-moving elements.",
        ),
    )
    use_freestyle: BoolProperty(
        name="Freestyle / Line Art",
        default=False,
        description=tooltip(
            "Freestyle やライン表現のレンダー出力を有効化します。NPR やテクニカル線画レビュー向けです。",
            "Enable Freestyle or line-style render output. Useful for NPR looks and technical line-art reviews.",
        ),
    )
    pass_bundle: EnumProperty(
        name="Pass Bundle",
        items=PASS_BUNDLE_ITEMS,
        default="ESSENTIAL",
        description=tooltip(
            "有効化するレンダーパスのまとまりです。用途ごとに必要な AOV をまとめて切り替えます。",
            "Bundle of render passes to enable. Switch groups of AOVs at once for different workflows.",
        ),
    )
    render_elements_enabled: BoolProperty(
        name="Render Elements",
        default=False,
        description=tooltip(
            '3ds Max の Render Elements に近い形で、ビューティー / Z深度 / ノーマル / ベロシティ / ID などをまとめて管理し、ファイル出力ノードも自動準備します。',
            "Manage Beauty, Z Depth, Normal, Velocity, ID and similar outputs in a 3ds Max Render Elements style, with File Output nodes prepared automatically.",
        ),
    )
    render_elements_preset: EnumProperty(
        name="Elements Quick Set",
        items=RENDER_ELEMENT_PRESET_ITEMS,
        default="FROM_PASS_BUNDLE",
        description=tooltip(
            "個別項目リストへ一括反映するためのクイックセットです。現在のパスバンドルや用途別セットを、個別エレメントのオン / オフに読み込めます。",
            "Quick set used to populate the individual element list. Load the current pass-bundle mapping or a task-oriented set into the per-element on/off list.",
        ),
    )
    render_elements_items_initialized: BoolProperty(
        name="Render Elements Item List Initialized",
        default=False,
        options={'HIDDEN'},
        description=tooltip(
            "旧プリセットから個別エレメント一覧へ初期移行済みかどうかを保持します。",
            "Tracks whether the legacy preset has already been migrated into the individual render-element list.",
        ),
    )
    render_elements_output_mode: EnumProperty(
        name="Elements Output",
        items=RENDER_ELEMENT_OUTPUT_ITEMS,
        default="FILES",
        description=tooltip(
            "レンダーエレメントを個別 EXR に分けるか、マルチレイヤー EXR にまとめるかを選びます。",
            "Choose whether render elements are written as split EXR files or packed into a Multilayer EXR.",
        ),
    )
    output_root: StringProperty(
        name="Output Root",
        subtype='DIR_PATH',
        default=_default_output_root_value(),
        description=tooltip(
            'レンダー結果の親フォルダーです。Blender 5.1では絶対パスまたはフォルダーピッカーで指定してください。空欄の場合は設定フォルダー/Smart_Render_Suite/renders を使用します。',
            "Parent folder for render outputs. In Blender 5.1, use an absolute path or the folder picker. When empty, config/Smart_Render_Suite/renders is used.",
        ),
    )
    output_dir_pattern: StringProperty(
        name="Directory Pattern",
        default="{blend}/{scene}/{camera}/{view_layer}/{quality}",
        description=tooltip(
            "保存フォルダーの自動生成パターンです。{render_layer}/{take}/{renderer}/{shot} の別名に加えて {parent_variant} と階層トークン {variant_path}/{take_path}、さらに {frame_start}/{frame_end}/{frame_count} と {resolution_x}/{resolution_y}/{fps}/{format}/{ext} も使えます。",
            "Automatic directory naming pattern. Along with alias tokens such as {render_layer}, {take}, {renderer}, and {shot}, you can also use {parent_variant}, hierarchical tokens such as {variant_path}/{take_path}, and {resolution_x}, {resolution_y}, {fps}, {format}, and {ext}.",
        ),
    )
    output_file_pattern: StringProperty(
        name="File Pattern",
        default="{scene}_{camera}_{view_layer}_{frame}",
        description=tooltip(
            'ファイル名の自動生成パターンです。拡張子は出力形式から自動追加されます。C4D風の {take}、MRQ/State Sets 向けの {shot}、親参照の {parent_variant}、階層化用の {variant_path}/{take_path} に加えて {frame_start}/{frame_end}/{frame_count} と {resolution_x}/{resolution_y}/{fps}/{format}/{ext} も使えます。必要ならビューティー/{scene}_{frame} のようにサブフォルダーも切れます。',
            "Automatic file naming pattern. The extension is added automatically from the image format. In addition to C4D-style {take}, shot-style {shot}, the parent token {parent_variant}, and hierarchical {variant_path}/{take_path}, you can also use {frame_start}, {frame_end}, {frame_count}, {resolution_x}, {resolution_y}, {fps}, {format}, and {ext}. Nested subfolders such as beauty/{scene}_{frame} are also supported when needed.",
        ),
    )
    image_format: EnumProperty(
        name="Image Format",
        items=IMAGE_FORMAT_ITEMS,
        default="PNG",
        description=tooltip(
            "基本の保存形式です。多パスや合成用途では EXR 系が推奨です。",
            "Base output image format. EXR variants are recommended for multi-pass and compositing workflows.",
        ),
    )
    overwrite_existing: BoolProperty(
        name="Overwrite Existing",
        default=True,
        description=tooltip(
            "同名ファイルがある場合に上書きします。オフなら自動で安全なサフィックスを付けます。",
            "Overwrite existing files. When disabled, the add-on automatically appends a safe suffix instead.",
        ),
    )
    skip_existing_frames: BoolProperty(
        name="Skip Existing Frames",
        default=False,
        description=tooltip(
            '既に同じ出力ファイルが存在するフレームは再レンダーせずスキップします。失敗再開や途中からの追いレンダーに向きます。オンのときは既存ファイルを上書きよりこちらが優先されます。',
            "Skip frames whose primary output file already exists instead of rendering them again. Useful for resume workflows and partial reruns. When enabled, this takes precedence over Overwrite Existing.",
        ),
    )
    use_placeholder: BoolProperty(
        name="Placeholder",
        default=False,
        description=tooltip(
            "レンダー中のプレースホルダーを使います。途中中断時の把握に役立ちます。",
            "Use placeholder files during rendering to help track interrupted jobs.",
        ),
    )
    auto_create_folders: BoolProperty(
        name="Auto Create Folders",
        default=True,
        description=tooltip(
            "必要な保存先フォルダーを自動作成します。",
            "Automatically create required output folders.",
        ),
    )
    auto_unique_tokens: BoolProperty(
        name="Auto Unique Tokens",
        default=True,
        description=tooltip(
            "必要に応じて {camera} や {frame} などを自動追加し、上書き事故を防ぎます。",
            "Automatically append tokens such as {camera} or {frame} when needed to avoid accidental overwrites.",
        ),
    )
    abort_on_collisions: BoolProperty(
        name="Abort On Collisions",
        default=True,
        description=tooltip(
            "事前監査で同じ保存先への衝突が見つかったらレンダーを中止します。",
            "Abort rendering if the preflight audit finds output path collisions.",
        ),
    )
    strict_missing_assets: BoolProperty(
        name="Strict Missing Assets",
        default=False,
        description=tooltip(
            "欠落外部ファイルを警告ではなくエラー扱いにします。",
            "Treat missing external files as errors instead of warnings.",
        ),
    )
    use_stamp: BoolProperty(
        name="Use Stamp",
        default=False,
        description=tooltip(
            "画像にシーン名やフレーム番号などのメタ情報を焼き込みます。",
            "Burn metadata such as scene name and frame number into the image.",
        ),
    )
    stamp_note: StringProperty(
        name="Stamp Note",
        default="Smart Render",
        description=tooltip(
            "スタンプへ追加表示する自由メモです。",
            "Extra note displayed in the render stamp.",
        ),
    )
    enable_movie_encode: BoolProperty(
        name="Encode Movie From Frames",
        default=False,
        description=tooltip(
            '2 フレーム以上のジョブに対して、連番画像から FFmpeg ムービー化プランをマニフェスト / ヘッドレススクリプトに含めます。ローカルレンダーキュー本体ではムービー化を強制せず、安全に後段処理として扱います。',
            "Include an FFmpeg movie-assembly plan for jobs with two or more frames in the manifest and exported headless scripts. The local render queue itself does not force encoding, keeping it as a safer downstream task.",
        ),
    )
    movie_preset: EnumProperty(
        name="Movie Preset",
        items=MOVIE_PRESET_ITEMS,
        default="H264_MP4",
        description=tooltip(
            "FFmpeg で使うムービー書き出しプリセットです。コーデックとコンテナの組み合わせを安全な組み合わせに固定します。",
            "Movie export preset used for FFmpeg. Each option pins a safe codec/container combination.",
        ),
    )
    movie_file_pattern: StringProperty(
        name="Movie File Pattern",
        default="{scene}_{variant}_{camera}_{view_layer}",
        description=tooltip(
            'ムービー出力名のパターンです。静止画と同じトークンを使えますが、通常は {frame} を含めません。代わりに {frame_start}/{frame_end}/{frame_count} や {variant_path}/{take_path} が便利です。必要ならレビュー/{scene}_{variant} のようにサブフォルダーも切れます。',
            "Pattern used for encoded movie names. It supports the same tokens as still outputs, but normally should not contain {frame}; {frame_start}, {frame_end}, {frame_count}, and {variant_path}/{take_path} are usually better choices for movie names. Nested subfolders such as review/{scene}_{variant} are also supported when needed.",
        ),
    )
    movie_overwrite_existing: BoolProperty(
        name="Overwrite Existing Movie",
        default=False,
        description=tooltip(
            "FFmpeg ムービー出力が既に存在する場合に上書きするかどうかです。",
            "Whether FFmpeg should overwrite an already existing movie output.",
        ),
    )
    ffmpeg_executable: StringProperty(
        name="FFmpeg Command",
        default="ffmpeg",
        description=tooltip(
            "FFmpeg の実行コマンドまたはフルパスです。通常は ffmpeg のままで構いません。必要なら ffmpeg.exe や絶対パスを指定できます。",
            "Command or full path used to invoke FFmpeg. The default 'ffmpeg' is fine on most systems; you can also point it to ffmpeg.exe or an absolute path.",
        ),
    )
    verify_outputs_after_render: BoolProperty(
        name="Verify Outputs After Render",
        default=True,
        description=tooltip(
            "各フレームのレンダー直後に、期待される出力ファイルの存在とサイズを検証します。失敗しても例外だけに頼らず、欠落や 0KB 近い壊れた出力を検出できます。",
            "After each rendered frame, verify that the expected output files exist and have a reasonable size. This catches missing or nearly empty broken outputs instead of relying only on exceptions.",
        ),
    )
    verification_scope: EnumProperty(
        name="Verification Scope",
        items=VERIFICATION_SCOPE_ITEMS,
        default="PRIMARY_AND_PASSES",
        description=tooltip(
            "どの種類の出力を検証対象にするかを選びます。メイン画像だけ、メイン+AOV、または AOV だけを選べます。",
            "Choose which outputs should be verified: only the main image, the main image plus AOVs, or AOVs only.",
        ),
    )
    min_output_size_kb: IntProperty(
        name="Minimum Output Size (KB)",
        default=1,
        min=0,
        max=1048576,
        description=tooltip(
            "出力ファイルがこのサイズ未満なら異常として扱います。0 にすると存在確認のみ行います。小さすぎる壊れた PNG / EXR を再試行前に弾くのに有効です。",
            "Treat files smaller than this threshold as invalid. Set it to 0 to check only for existence. This is useful for rejecting tiny broken PNG/EXR files before retrying.",
        ),
    )
    verification_retry_count: IntProperty(
        name="Verification Retry Count",
        default=1,
        min=0,
        max=20,
        description=tooltip(
            "出力検証が失敗したときに、同じ検証を追加で何回やり直すかです。ネットワークストレージやコンポジット書き込みの遅延で、実ファイルの反映が少し遅れる環境に有効です。",
            "How many extra times output verification should be retried after a failed check. This is useful on network storage or when compositor/file-output writes appear slightly later than the render call returns.",
        ),
    )
    verification_retry_delay: FloatProperty(
        name="Verification Retry Delay",
        default=0.35,
        min=0.0,
        max=60.0,
        precision=2,
        subtype='TIME',
        description=tooltip(
            "検証再試行の間に待つ秒数です。短い待機を入れることで、遅れて生成される AOV やムービー化前の連番ファイルの誤検知を減らします。",
            "Delay in seconds between verification retries. A small pause helps avoid false negatives when AOV files or sequence outputs land a little later than the main render call completes.",
        ),
    )
    cleanup_invalid_outputs: BoolProperty(
        name="Delete Invalid Outputs Before Retry",
        default=True,
        description=tooltip(
            '検証に失敗した壊れた出力ファイルを再試行前に削除します。0KB や不完全なファイルが残って、次の試行や再開を邪魔する事故を減らします。',
            "Delete invalid output files before retrying. This reduces cases where 0 KB or incomplete files interfere with the next attempt or a later resume pass.",
        ),
    )
    job_name: StringProperty(
        name="Job Name",
        default="main",
        description=tooltip(
            "{job} / {shot} トークン用の案件名・ショット名などです。必要なら Variant 側の Job Name Override で個別に差し替えできます。",
            "Custom job or shot name used by the {job}/{shot} tokens. You can override it per variant with Job Name Override when needed.",
        ),
    )
    frame_mode: EnumProperty(
        name="Frame Mode",
        items=FRAME_MODE_ITEMS,
        default="CURRENT",
        description=tooltip(
            "どのフレーム範囲をキューへ展開するかを決めます。",
            "Choose which frame range should be expanded into the queue.",
        ),
    )
    custom_frame_start: IntProperty(
        name="Custom Start",
        default=1,
        description=tooltip(
            'フレームモードがカスタムのときの開始フレームです。',
            "Start Frame used when Frame Mode is set to Custom.",
        ),
    )
    custom_frame_end: IntProperty(
        name="Custom End",
        default=250,
        description=tooltip(
            'フレームモードがカスタムのときの終了フレームです。',
            "End Frame used when Frame Mode is set to Custom.",
        ),
    )
    sequence_padding: IntProperty(
        name="Frame Padding",
        default=4,
        min=1,
        max=8,
        description=tooltip(
            "{frame} トークンのゼロ埋め桁数です。",
            "Zero-padding width used for the {frame} token.",
        ),
    )
    execution_device_mode: EnumProperty(
        name="Execution Plan Device",
        items=EXECUTION_DEVICE_ITEMS,
        default="AUTO",
        description=tooltip(
            'ローカル計画、ヘッドレススクリプト、ブリッジ書き出しに渡す実行デバイス方針です。Blender 本体設定を強制変更するのではなく、外部実行計画へ安全なヒントを渡します。',
            "Execution Plan-device policy passed to local planning, headless scripts, and bridge exports. It does not force Blender preferences directly; it provides safer downstream hints.",
        ),
    )
    farm_priority: IntProperty(
        name="Farm Priority",
        default=50,
        min=0,
        max=100,
        description=tooltip(
            'ファームマネージャー向けの優先度ヒントです。数値が高いほど重要ジョブとして扱いやすくなります。ローカルキューそのものには直接影響しません。',
            "Priority hint for farm managers. Higher numbers indicate more important jobs. It does not directly change local queue behavior.",
        ),
    )
    frame_chunk_size: IntProperty(
        name="Frame Chunk Size",
        default=1,
        min=1,
        max=100000,
        description=tooltip(
            'ヘッドレススクリプトとブリッジ書き出しで、何フレームずつ1ジョブにまとめるかを決めます。1なら1フレーム1タスク、8なら8フレーム単位です。大規模ファームや再試行運用では小さめが安全です。',
            "Choose how many frames should be grouped into one task for headless scripts and bridge exports. 1 means one frame per task; 8 means tasks of eight frames. Smaller chunks are usually safer for large farms and retry workflows.",
        ),
    )
    concurrent_tasks: IntProperty(
        name="Concurrent Tasks Hint",
        default=1,
        min=1,
        max=256,
        description=tooltip(
            '同時並列タスク数のヒントです。ブリッジ JSON やファーム書き出しで参照され、ローカルキューでは無理に並列実行しません。',
            "Hint for the desired number of concurrent tasks. Used by bridge JSON and farm exports; the local queue does not force unsafe parallel execution.",
        ),
    )
    memory_gb_hint: FloatProperty(
        name="Memory GB Hint",
        default=0.0,
        min=0.0,
        max=65536.0,
        precision=2,
        description=tooltip(
            '1タスクあたりに見込むメモリ量のヒントです。0なら未指定。重いショットをファームへ送る際の配分情報として使えます。',
            "Optional memory estimate per task in gigabytes. Leave at 0 for unspecified. Useful as a scheduling hint for heavy shots sent to a farm.",
        ),
    )
    job_tags: StringProperty(
        name="Job Tags",
        default="",
        description=tooltip(
            'カンマ区切りで自由なタグを付けます。例: lighting, urgent, gpu。ブリッジ書き出しやファームマネージャー側で分類・フィルタしやすくなります。',
            "Comma-separated custom tags such as lighting, urgent, or gpu. These help downstream bridge exports and farm managers categorize or filter jobs.",
        ),
    )
    temporal_subsamples: IntProperty(
        name="Temporal Subsamples",
        default=1,
        min=1,
        max=256,
        description=tooltip(
            "MRQ / Recorder 的な時間方向サブサンプリング数のヒントです。高いほどモーションブラー品質向上に使えますが、コストも増えます。",
            "Hint for MRQ/Recorder-style temporal subsampling. Higher values can improve motion-blur quality at a higher rendering cost.",
        ),
    )
    spatial_subsamples: IntProperty(
        name="Spatial Subsamples",
        default=1,
        min=1,
        max=256,
        description=tooltip(
            "MRQ 的な空間サブサンプリング数のヒントです。高いほどエイリアシングやノイズ低減に有利ですが、処理コストが増えます。",
            "Hint for MRQ-style spatial subsampling. Higher values can improve anti-aliasing and noise reduction at a higher processing cost.",
        ),
    )
    accumulation_samples: IntProperty(
        name="Accumulation Samples",
        default=1,
        min=1,
        max=4096,
        description=tooltip(
            'Unity Recorder やプログレッシブ蓄積に近い蓄積サンプル数のヒントです。複数サブフレームや蓄積型レンダーの外部実行計画へ渡します。',
            "Hint for Unity Recorder-style or progressive accumulation sample counts. Passed to downstream execution plans that support sub-frame or accumulation workflows.",
        ),
    )
    selected_cameras_only: BoolProperty(
        name="Selected Cameras Only",
        default=False,
        description=tooltip(
            "選択中のカメラだけをキュー化します。",
            "Queue only the selected cameras.",
        ),
    )
    renderable_cameras_only: BoolProperty(
        name="Renderable Cameras Only",
        default=True,
        description=tooltip(
            "「レンダーで無効」にしていないカメラだけを対象にします。",
            "Include only cameras that are not disabled for rendering.",
        ),
    )
    view_layer_mode: EnumProperty(
        name="View Layers",
        items=VIEW_LAYER_MODE_ITEMS,
        default="ACTIVE",
        description=tooltip(
            "アクティブなレイヤーだけを使うか、全レイヤーを対象にするかを選びます。",
            "Choose whether to use only the active view layer or every view layer.",
        ),
    )
    queue_source_mode: EnumProperty(
        name="Queue Source",
        items=QUEUE_SOURCE_MODE_ITEMS,
        default="PAIRS",
        description=tooltip(
            'キューをカメラ×レイヤーの組み合わせから作るか、保存済みバリアントから作るかを決めます。',
            "Choose whether the queue is built from camera/layer pairs or from saved variants.",
        ),
    )
    queue_compositing_mode: EnumProperty(
        name="Queue Compositing",
        items=QUEUE_COMPOSITING_ITEMS,
        default="AUTO",
        description=tooltip(
            'レンダーキューを実行時にコンポジット経由で出力するかを制御します。自動はシーン状態とファイル出力ノードの有無から判断します。',
            "Control whether queue rendering should route through the compositor. AUTO decides from the scene state and the presence of File Output nodes.",
        ),
    )
    retry_on_failure: BoolProperty(
        name="Retry On Failure",
        default=True,
        description=tooltip(
            "レンダー失敗時に同じフレームを自動で再試行します。瞬間的な I/O エラーや一時的不整合の吸収に役立ちます。",
            "Automatically retry the same frame when rendering fails. Useful for transient I/O errors and temporary state mismatches.",
        ),
    )
    retry_count: IntProperty(
        name="Retry Count",
        default=1,
        min=0,
        max=10,
        description=tooltip(
            "失敗フレームを再試行する最大回数です。1 なら初回失敗後に 1 回だけ再試行します。",
            "Maximum number of retries for a failed frame. A value of 1 retries once after the initial failure.",
        ),
    )
    halt_on_first_error: BoolProperty(
        name="Halt On First Error",
        default=False,
        description=tooltip(
            "最初の失敗でキュー全体を止めます。オフなら失敗を記録しつつ次のジョブへ進みます。",
            "Stop the entire queue on the first failure. When disabled, failures are logged and the queue continues to the next job.",
        ),
    )
    manifest_path: StringProperty(
        name="Manifest Path",
        subtype='FILE_PATH',
        default=default_manifest_path(),
        description=tooltip(
            '共通 JSON マニフェストの保存先です。同じ場所にヘッドレス実行用 .sh / .bat も書き出せます。',
            "Save path for the generic JSON manifest. Headless execution .sh / .bat scripts can also be exported next to it.",
        ),
    )
    network_render_enabled: BoolProperty(
        name="Network Render",
        default=False,
        description=tooltip(
            'ネットワークレンダラー向けのマニフェスト / ブリッジ JSON / ヘッドレススクリプトを 1 クリックでまとめて書き出しやすくします。',
            "Enable one-click export of a manifest, bridge JSON, and headless scripts for network renderers.",
        ),
    )
    network_render_target: EnumProperty(
        name="Network Target",
        items=NETWORK_RENDER_TARGET_ITEMS,
        default="GENERIC",
        description=tooltip(
            'ネットワークレンダラー向けの書き出し先を選びます。簡易UIではこの選択がブリッジターゲットより優先されます。',
            "Choose the export target for network rendering. In the simplified UI this selection takes priority over the broader Bridge Target.",
        ),
    )
    bridge_target: EnumProperty(
        name="Bridge Target",
        items=BRIDGE_TARGET_ITEMS,
        default="GENERIC",
        description=tooltip(
            "どの外部パイプライン向けの橋渡し JSON を書き出すかを選びます。",
            "Choose which external pipeline adapter JSON should be exported.",
        ),
    )
    preview_limit: IntProperty(
        name="Preview Limit",
        default=16,
        min=1,
        max=500,
        description=tooltip(
            "ログやプレビューへ表示する最大件数です。",
            "Maximum number of entries shown in preview and log output.",
        ),
    )
    analysis_detail_limit: IntProperty(
        name="Analysis Detail Limit",
        default=12,
        min=4,
        max=200,
        description=tooltip(
            "監査で詳細表示する問題件数の上限です。",
            "Maximum number of detailed issues shown by the audit.",
        ),
    )


# Individual 3ds Max-style Render Elements toggles.
for _render_element_item in RENDER_ELEMENT_CATALOG:
    _prop_options = render_element_property_definition(_render_element_item)
    SRR_Settings.__annotations__[_render_element_item["prop"]] = BoolProperty(
        name=_prop_options["name"],
        default=bool(_prop_options.get("default", False)),
        description=_prop_options["description"],
    )


def _integrated_tool_section_states_from_settings(settings_obj) -> dict:
    try:
        import json as _json
        raw = _json.loads(str(getattr(settings_obj, 'integrated_tool_section_state_json', '{}') or '{}'))
        if isinstance(raw, dict):
            return {str(k): bool(v) for k, v in raw.items()}
    except Exception:
        pass
    return {}


def _set_integrated_tool_section_state(settings_obj, alias: str, value: bool) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    try:
        import json as _json
        raw = _integrated_tool_section_states_from_settings(settings_obj)
        raw[alias] = bool(value)
        setattr(settings_obj, 'integrated_tool_section_state_json', _json.dumps(raw, ensure_ascii=False, sort_keys=True))
    except Exception:
        return
    try:
        from . import settings as _srs_settings
        if _srs_settings.is_applying_context():
            return
        ctx = getattr(bpy, 'context', None)
        _srs_settings.snapshot_context(ctx, force=_srs_settings.is_npanel_state_save_enabled(ctx))
    except Exception:
        pass


def _make_integrated_tool_section_getter(alias: str):
    alias = str(alias or '').strip()

    def _get(self):
        return bool(_integrated_tool_section_states_from_settings(self).get(alias, False))

    return _get


def _make_integrated_tool_section_setter(alias: str):
    alias = str(alias or '').strip()

    def _set(self, value):
        _set_integrated_tool_section_state(self, alias, bool(value))

    return _set


def _register_integrated_tool_native_section_props() -> None:
    try:
        from .tool_catalog import expanded_prop_name as _expanded_prop_name, display_name as _display_name, tool_aliases as _tool_aliases
    except Exception:
        return
    for _alias in tuple(_tool_aliases() or ()):
        _alias = str(_alias or '').strip()
        if not _alias:
            continue
        _prop_name = str(_expanded_prop_name(_alias) or '').strip()
        if not _prop_name or _prop_name in SRR_Settings.__annotations__:
            continue
        _label = _display_name(_alias, fallback=_alias.replace('_', ' ').title())
        SRR_Settings.__annotations__[_prop_name] = BoolProperty(
            name=_label,
            default=False,
            get=_make_integrated_tool_section_getter(_alias),
            set=_make_integrated_tool_section_setter(_alias),
            description=tooltip(
                f"その他ツール内の「{_label}」子セクションを Blender 標準の折りたたみグループとして開閉します。状態は設定フォルダー/Smart_Render_Suite/Smart_Render_Suite.json に保存されます。",
                f"Open or close the {_label} child section inside Other Tools using Blender's standard collapsible group. The state is stored in config/Smart_Render_Suite/Smart_Render_Suite.json.",
            ),
        )


_register_integrated_tool_native_section_props()


def _registered_property_group(cls):
    try:
        from .rna_safety import ensure_registered_class
        return ensure_registered_class(cls)
    except Exception:
        return cls



SCENE_PROPERTY_DEFINITIONS = {
    "srr_settings": lambda: PointerProperty(type=_registered_property_group(SRR_Settings)),
    "srr_queue": lambda: CollectionProperty(type=_registered_property_group(SRR_QueueItem)),
    "srr_queue_index": lambda: IntProperty(default=0),
    "srr_variants": lambda: CollectionProperty(type=_registered_property_group(SRR_VariantItem)),
    "srr_variant_index": lambda: IntProperty(default=0),
    "srr_logs": lambda: CollectionProperty(type=_registered_property_group(SRR_LogItem)),
    "srr_log_index": lambda: IntProperty(default=0),
    "srr_last_analysis_time": lambda: StringProperty(default=""),
    "srr_last_analysis_status": lambda: StringProperty(default="NOT_RUN"),
    "srr_last_collision_count": lambda: IntProperty(default=0),
    "srr_last_missing_asset_count": lambda: IntProperty(default=0),
    "srr_last_risk_score": lambda: IntProperty(default=0),
    "srr_last_render_summary": lambda: StringProperty(default=""),
}
