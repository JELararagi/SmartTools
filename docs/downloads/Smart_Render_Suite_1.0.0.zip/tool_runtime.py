# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Own the tool catalogue and interface together, without loading saved tools."""

from . import loader, ui_runtime


def register():
    loader.register_all()
    try:
        ui_runtime.register()
        loader.cancel_saved_loaded_tools_restore()
    except Exception:
        try:
            ui_runtime.unregister()
        finally:
            loader.unregister_all()
        raise


def unregister():
    try:
        ui_runtime.unregister()
    finally:
        loader.unregister_all()
