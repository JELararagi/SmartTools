# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Window-local options for constructing camera rig widgets."""

import bpy
from bpy.props import StringProperty
from bpy.types import PropertyGroup, WindowManager

from .. import rna_safety
from ..translation import localize_pair

_PROPERTY_NAME = "smart_render_camera_rigs_prefs"
_REGISTER_ERROR = ""
_REGISTERED_POINTER = False


class CAMERA_RIGS_RuntimePreferences(PropertyGroup):
    widget_prefix: StringProperty(
        name=localize_pair("ウィジェット接頭辞", "Widget Prefix"),
        description=localize_pair("生成するカメラウィジェットの名前の接頭辞",
                                  "Prefix for the names of generated camera widgets"),
        default="WGT-",
    )
    camera_widget_collection_name: StringProperty(
        name=localize_pair("コレクション名", "Collection Name"),
        description=localize_pair("生成したカメラウィジェットを保存するコレクション",
                                  "Collection for generated camera widgets"),
        default="Widgets",
    )


def get_runtime_preferences(context=None):
    window_manager = getattr(bpy.context if context is None else context, "window_manager", None)
    return getattr(window_manager, _PROPERTY_NAME, None)


def _draw_common(layout, settings):
    controls = layout.column(align=True)
    for property_name in ("widget_prefix", "camera_widget_collection_name"):
        controls.prop(settings, property_name)


def draw_runtime_settings(layout, context):
    settings = get_runtime_preferences(context)
    if settings is None:
        layout.label(text=localize_pair("カメラリグの設定を開けません", "Camera rig settings are unavailable"),
                     icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_pair("ウィジェット生成設定", "Widget generation settings"), icon="PREFERENCES")
    _draw_common(box, settings)


def register():
    global _REGISTERED_POINTER, _REGISTER_ERROR
    _REGISTER_ERROR = ""
    try:
        _REGISTERED_POINTER = bool(rna_safety.register_pointer_property(
            WindowManager, _PROPERTY_NAME, CAMERA_RIGS_RuntimePreferences))
    except (RuntimeError, TypeError, ValueError) as error:
        _REGISTERED_POINTER = False
        _REGISTER_ERROR = str(error)


def unregister():
    global _REGISTER_ERROR, _REGISTERED_POINTER
    if _REGISTERED_POINTER and hasattr(WindowManager, _PROPERTY_NAME):
        delattr(WindowManager, _PROPERTY_NAME)
    if _REGISTERED_POINTER:
        rna_safety.unregister_existing_class(CAMERA_RIGS_RuntimePreferences)
    _REGISTERED_POINTER = False
    _REGISTER_ERROR = ""
