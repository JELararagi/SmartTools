# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": 'Camera Rig Builder',
    "author": "JELararagi",
    "version": (1, 8, 2),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Build dolly, crane, and 2D camera rigs, then manage them from the Smart Render N-panel.",
    "category": "Camera",
}

from . import build_rigs
from . import operators
from . import ui_panels
from . import preferences as prefs
from . import runtime_preferences as runtime_prefs
from . import composition_guides_menu

# =========================================================================
# Registration:
# =========================================================================

def register():
    build_rigs.register()
    operators.register()
    ui_panels.register()
    prefs.register()
    runtime_prefs.register()
    composition_guides_menu.register()


def unregister():
    build_rigs.unregister()
    operators.unregister()
    ui_panels.unregister()
    runtime_prefs.unregister()
    prefs.unregister()
    composition_guides_menu.unregister()


if __name__ == "__main__":
    register()
