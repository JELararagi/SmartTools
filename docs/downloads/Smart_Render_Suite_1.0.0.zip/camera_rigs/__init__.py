# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Tie camera-rig operations, widgets, and panels to the tool lifecycle."""

from . import build_rigs, composition_guides_menu, operators, ui_panels
from . import preferences as prefs
from . import runtime_preferences as runtime_prefs

bl_info = dict(
    name="Camera Rig Builder",
    author="JELararagi",
    version=(1, 8, 2),
    blender=(5, 1, 0),
    location="3D View > Sidebar > Smart Render",
    description="Create and operate dolly, crane, and 2D camera rigs within Smart Render.",
    category="Camera",
)

_COMPONENTS = (build_rigs, operators, ui_panels, prefs, runtime_prefs, composition_guides_menu)


def register():
    active = []
    try:
        for component in _COMPONENTS:
            component.register()
            active.append(component)
    except Exception:
        for component in reversed(active):
            try:
                component.unregister()
            except (RuntimeError, ReferenceError):
                pass
        raise


def unregister():
    # Preserve the existing removal order for the shared camera classes.
    for component in (build_rigs, operators, ui_panels, runtime_prefs, prefs, composition_guides_menu):
        component.unregister()


if __name__ == "__main__":
    register()
