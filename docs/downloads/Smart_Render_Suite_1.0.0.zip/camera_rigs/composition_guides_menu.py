# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Show the rig camera's native Blender framing controls in a popover."""

from bpy.types import Panel

from ..rna_safety import safe_register_class, safe_unregister_class
from .operators import get_rig_and_cam, poll_base


_GUIDES = (
    "center",
    "center_diagonal",
    "golden",
    "golden_tria_a",
    "golden_tria_b",
    "harmony_tri_a",
    "harmony_tri_b",
    "thirds",
)


class ADD_CAMERA_RIGS_PT_composition_guides(Panel):
    bl_label = "Composition Guides"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_keep_popover_poll = True

    @classmethod
    def poll(cls, context):
        return poll_base(cls, context)

    def draw(self, context):
        active = getattr(context, "active_object", None)
        camera = get_rig_and_cam(active)[1]
        settings = getattr(camera, "data", None)
        if settings is not None:
            controls = self.layout
            controls.prop(settings, "show_safe_areas")
            controls.row().separator()
            for guide in _GUIDES:
                controls.prop(settings, f"show_composition_{guide}")


def register():
    safe_register_class(ADD_CAMERA_RIGS_PT_composition_guides)


def unregister():
    safe_unregister_class(ADD_CAMERA_RIGS_PT_composition_guides)
