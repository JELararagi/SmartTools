# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility entry points for callers of the former add-on preferences.

The integrated camera tools expose these options through the render panel.
"""

classes = ()


def register():
    """The camera tool does not own global add-on preferences."""


def unregister():
    """The camera tool has no global add-on preferences to remove."""
