# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

bl_info = {
    "name": 'External Pipeline Bridge',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Bridge manifest and export helper utilities integrated into Smart Render N-panel.",
    "category": "Render",
}

from .targets import build_bridge_export, supported_targets

__all__ = ["build_bridge_export", "supported_targets"]
