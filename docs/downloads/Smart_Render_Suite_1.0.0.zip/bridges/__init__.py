# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Expose render job payloads for separately installed pipeline tools."""

from .targets import build_bridge_export, supported_targets

__all__ = ("build_bridge_export", "supported_targets")

bl_info = dict(
    name="External Pipeline Bridge",
    description="Prepare render-job descriptions for external pipeline software.",
    author="JELararagi",
    category="Render",
    version=(1, 0, 0),
    blender=(5, 1, 0),
    location="3D View > Sidebar > Smart Render",
)
