# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import sys
from pathlib import Path

import bpy

_STALE_FILENAMES = (
    "smart_tools_window_bridge.py",
    "bootstrap_runtime.py",
    "smart_tools_bootstrap_common.py",
)

_STALE_MODULE_TAILS = {
    "smart_tools_window_bridge",
    "bootstrap_runtime",
    "smart_tools_bootstrap_common",
}

def _package_dir(file_path: str | None) -> Path | None:
    try:
        if not file_path:
            return None
        return Path(file_path).resolve().parent
    except Exception:
        return None

def preflight_cleanup(package_name: str = "", module_name: str = "", file_path: str = "") -> None:
    """Remove stale Smart_Tools_Window-era files/modules from in-place updates.

    Users sometimes replace add-on contents without deleting the previous folder first.
    This helper removes abandoned Smart_Tools_Window bridge/bootstrap files and their
    loaded modules so the Properties-based Smart Tools host becomes the only runtime.
    """
    del module_name

    # Extension repositories may be read-only.  Old package files are never
    # deleted in place; removing their loaded module aliases below is sufficient
    # for the current process, and a clean Extension reinstall owns code cleanup.
    del file_path

    package_name = str(package_name or '').strip()
    for tail in _STALE_MODULE_TAILS:
        sys.modules.pop(tail, None)
        if package_name:
            sys.modules.pop(f'{package_name}.{tail}', None)

def get_addon_preferences(context=None, package_name: str = "", module_name: str = "", file_path: str = ""):
    context = context or getattr(bpy, 'context', None)
    try:
        from .host_bridge import get_root_addon_preferences
    except Exception:
        get_root_addon_preferences = None

    candidates: list[str] = []
    for value in (
        str(package_name or '').strip(),
        str(module_name or '').strip(),
        str(_package_dir(file_path).name if _package_dir(file_path) is not None else '').strip(),
    ):
        if not value:
            continue
        if value not in candidates:
            candidates.append(value)
        if '.' in value:
            parent = value.rsplit('.', 1)[0].strip()
            if parent and parent not in candidates:
                candidates.append(parent)
            parts = [part for part in value.split('.') if part]
            if len(parts) >= 3 and parts[0] == 'bl_ext':
                root_name = '.'.join(parts[:3])
                root_id = parts[2]
                for candidate in (root_name, root_id):
                    if candidate and candidate not in candidates:
                        candidates.append(candidate)

    if callable(get_root_addon_preferences):
        for candidate in candidates:
            try:
                prefs = get_root_addon_preferences(candidate, context=context)
            except Exception:
                prefs = None
            if prefs is not None:
                return prefs

    prefs = getattr(getattr(context, 'preferences', None), 'addons', None)
    if prefs is None:
        return None
    for candidate in candidates:
        try:
            entry = prefs[candidate]
        except Exception:
            continue
        result = getattr(entry, 'preferences', None)
        if result is not None:
            return result
    return None
