# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": 'View Layer Manager',
    "author": "JELararagi",
    "version": (1, 2, 5),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Extended View Layer management tools integrated into the Smart Render N-panel workflow.",
    "category": "Render",
}

is_reloading = "bpy" in locals()

import bpy
from bpy.props import PointerProperty
from . import icons
from . import properties as props
from . import runtime_preferences as runtime_prefs
from . import op
from . import ui

if is_reloading:
    import importlib
    importlib.reload(icons)
    importlib.reload(props)
    importlib.reload(runtime_prefs)
    importlib.reload(op)
    importlib.reload(ui)


def _register_external_ui_hooks():
    _unregister_external_ui_hooks()
    ui.TOPBAR_HT_upper_bar.append(ui.draw_manager_topbar)


def _unregister_external_ui_hooks():
    try:
        ui.TOPBAR_HT_upper_bar.remove(ui.draw_manager_topbar)
    except ValueError:
        pass


UFRP_CLASSES = (
    props.UFRP_property_select,
    props.UFRP_property_passe,
    props.UFRP_properties,
    op.UFRP_OP_toggle,
    op.UFRP_OP_batch,
    op.UFRP_OP_OnlyUnmuted,
    op.UFRP_OP_OnlySelected,
    op.UFRP_OP_RenderLayerSwitch,
    op.UFRP_OP_ViewLayerAdd,
    op.UFRP_OP_ViewLayerRemove,
    op.UFRP_OP_ViewLayerSwitch,
    op.UFRP_OP_AllCopyProps,
    op.UFRP_OP_ReloadPasses,
    op.UFRP_OP_CopyLayer,
    op.UFRP_OP_PasteLayer,
    op.UFRP_OT_CopyToSelected,
    op.UFRP_OP_MoveLayer,
    op.UFRP_OP_SortLayers,
    ui.UFRP_PT_MANAGER_FILTER,
    ui.UFRP_PT_COPY_PASS_FILTER,
    ui.UFRP_MT_comp_menu,
    ui.UFRP_UL_layers,
    ui.UFRP_MT_manager_context_menu,
    ui.UFRP_PT_manager_topbar,
    ui.UFRP_PT_manager_properties,
)


def register():
    from ..rna_safety import ensure_registered_class, register_pointer_property
    icons.register()
    runtime_prefs.register()
    for cls in UFRP_CLASSES:
        ensure_registered_class(cls)
    _register_external_ui_hooks()
    register_pointer_property(bpy.types.Scene, "ufrp", props.UFRP_properties)

def unregister():
    if hasattr(bpy.types.Scene, "ufrp"):
        try:
            del bpy.types.Scene.ufrp
        except Exception:
            pass
    try:
        runtime_prefs.unregister()
    except Exception:
        pass
    _unregister_external_ui_hooks()
    from ..rna_safety import unregister_existing_class
    for cls in reversed(UFRP_CLASSES):
        unregister_existing_class(cls)
    icons.unregister()
