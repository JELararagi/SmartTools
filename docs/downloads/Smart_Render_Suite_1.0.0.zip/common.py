from .translation import iface_text
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import json
import os
import re
import sys
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

PACKAGE_ID = 'smart_render_suite'
ADDON_NAME = 'Smart_Render_Suite'
TOOL_LABEL_EN = 'Smart Render'
TOOL_LABEL_JA = 'Smart Render'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_PENDING_PREVIEW_REMOVALS = []
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Toggle Startup Control'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Settings'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated files are centralized below Blender CONFIG/Smart_Render_Suite.
    try:
        from .storage import user_data_dir
        return user_data_dir(create=create)
    except Exception:
        version = '5.1'
        try:
            app_version = getattr(getattr(bpy, 'app', None), 'version', None)
            if app_version and len(app_version) >= 2:
                version = f'{int(app_version[0])}.{int(app_version[1])}'
        except Exception:
            pass
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Render_Suite' / _STORAGE_DIRNAME
        else:
            root = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_Render_Suite' / _STORAGE_DIRNAME
        if create:
            try:
                root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        from . import settings as _settings
        path = _settings.settings_file_path()
        if path is not None:
            return Path(path)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            config_dir = user_resource('CONFIG', create=True)
            if config_dir:
                base = Path(config_dir) / 'Smart_Render_Suite'
                base.mkdir(parents=True, exist_ok=True)
                return base / 'Smart_Render_Suite.json'
    except Exception:
        pass
    return storage_path('settings', 'Smart_Render_Suite.json')


def _load_previews(*, force=False):
    # The shared help/header icons now use Blender standard icons.  Do not
    # create or remove preview collections here; stale preview icon ids can be
    # held by Blender UI buttons during panel redraws and may crash Blender's
    # C-side panel handler.
    return None


def icon_value(name, fallback=0):
    return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    _PREVIEW_COLLECTION = None


def _remove_preview_collection_later(pcoll):
    # Intentionally retained as a no-op for backward compatibility.
    return None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_RENDER_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_options = set()
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group. The help content is loaded only when this button is clicked.'

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            from . import help_content
            help_content.draw_help_popup(
                layout,
                context,
                topic,
                fallback_label=text(TOOL_LABEL_EN, TOOL_LABEL_JA, context),
                popup_width_px=680,
            )
            return
        except Exception as exc:
            box = layout.box()
            box.label(text=text('Help', 'ヘルプ', context), icon='HELP')
            _draw_wrapped(box, context, text(
                'The help popup could not be loaded: ',
                'ヘルプポップアップを読み込めませんでした: ',
                context,
            ) + str(exc))


class SMART_RENDER_OT_set_always_on(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Toggle Startup Control'
    bl_description = 'Set an always-on feature to enabled or disabled. Saving follows the N-panel State Save setting.'

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, text(f'Failed to toggle: {exc}', '切り替えに失敗しました。'))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, text(f'Failed to toggle: {exc}', '切り替えに失敗しました。'))
        try:
            from . import settings as _settings
            save_persistent_settings(context, force=_settings.is_npanel_state_save_enabled(context))
        except Exception:
            try:
                save_persistent_settings(context, force=False)
            except Exception:
                pass
        return {'FINISHED'}


class SMART_RENDER_OT_save_preferences(bpy.types.Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Settings'
    bl_description = 'Save current N-panel settings to Blender config/Smart_Render_Suite/Smart_Render_Suite.json and request Blender to save user preferences.'

    def execute(self, context):
        save_persistent_settings(context, force=True)
        try:
            from . import settings as _settings
            _settings.snapshot_context(context or getattr(bpy, 'context', None), force=True)
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, iface_text(text('Preferences saved.', 'プリファレンスを保存しました。', context)))
        return {'FINISHED'}



def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        from .rna_safety import safe_unregister_class
        safe_unregister_class(cls)
        return True
    except Exception:
        pass
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False


def _flatten_npanel_parent_before_register(cls):
    """Keep all SmartTools N-panel sections horizontally aligned.

    Blender indents Panel classes that use ``bl_parent_id``.  In a deep or
    lazily loaded SmartTools UI this compounds every time a child/grandchild
    section is exposed.  Flatten only sidebar (``bl_region_type == 'UI'``)
    panels before registration; non-sidebar panels keep their native parents.
    """
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            if str(getattr(cls, 'bl_region_type', '') or '') == 'UI':
                if str(getattr(cls, 'bl_parent_id', '') or ''):
                    cls.bl_parent_id = ''
    except Exception:
        pass
    return cls


def _register_class_wrapper(cls):
    _flatten_npanel_parent_before_register(cls)
    _materialize_annotations(cls)
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type) and existing is not cls:
            if _same_package_class(existing) or _old_generated_name(getattr(existing, '__name__', '')):
                _safe_unregister_class(existing)
    except Exception:
        pass
    try:
        return _ORIGINAL_REGISTER_CLASS(cls)
    except ValueError:
        # Already registered: this normally means Blender kept a class from a
        # failed previous load. Try one clean unregister/register cycle.
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
            if isinstance(existing, type):
                _safe_unregister_class(existing)
        except Exception:
            pass
        return _ORIGINAL_REGISTER_CLASS(cls)


def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    _ORIGINAL_REGISTER_CLASS = None


def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    _ORIGINAL_REGISTER_CLASS = None


def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _default_panel_poll(_cls, _context):
    return True


def _patch_panel_headers():
    for cls in _iter_relevant_panels():
        try:
            cls.bl_category = PANEL_CATEGORY
        except Exception:
            pass
        try:
            label = str(getattr(cls, 'bl_label', '') or '')
            clean = _clean_label(label)
            if clean and clean != label:
                cls.bl_label = clean
        except Exception:
            pass
        if _is_always_panel(cls):
            try:
                original_poll = getattr(cls, 'poll', None)
                cls.poll = classmethod(lambda _cls, context: False)
                _PATCHED_POLLS.append((cls, original_poll))
            except Exception:
                pass
            continue
        # Do not replace draw_header on classes that Blender has already
        # registered.  Blender 5.1 / Python 3.13 can crash in C-level panel
        # drawing when a registered RNA Panel's header callback is monkey
        # patched after registration, especially for mirrored Image Editor
        # panels.  Help buttons are provided only by classes that define their
        # own draw_header before registration.
        continue


def _unpatch_panel_headers():
    for cls, original in reversed(_PATCHED_PANELS):
        try:
            if original is None:
                if hasattr(cls, 'draw_header'):
                    delattr(cls, 'draw_header')
            else:
                cls.draw_header = original
            if hasattr(cls, '_smart_common_header_patched'):
                delattr(cls, '_smart_common_header_patched')
        except Exception:
            pass
    _PATCHED_PANELS.clear()
    for cls, original in reversed(_PATCHED_POLLS):
        try:
            if original is None:
                # Do not delete poll from a registered Panel while Blender may still
                # hold the RNA callback.  A default True poll matches the behavior
                # of a panel that originally had no explicit poll but keeps the
                # callback target present during live reload/unregister.
                cls.poll = classmethod(_default_panel_poll)
            else:
                cls.poll = original
        except Exception:
            pass
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _patch_addon_preferences():
    for cls in _iter_relevant_addon_preferences():
        if getattr(cls, '_smart_common_preferences_patched', False):
            continue
        original = getattr(cls, 'draw', None)

        def _draw_npanel_only(self, context):
            try:
                box = self.layout.box()
                box.label(text=text('Settings are managed in the N-panel.', '設定はNパネルで管理します。', context), icon='PREFERENCES')
                box.label(text=text('Open the 3D View Sidebar and use this tool tab.', '3Dビューのサイドバーを開き、このツールのタブを使用してください。', context))
            except Exception:
                pass

        try:
            cls.draw = _draw_npanel_only
            cls._smart_common_preferences_patched = True
            _PATCHED_PREFERENCES.append((cls, original))
        except Exception:
            pass


def _unpatch_addon_preferences():
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                if hasattr(cls, 'draw'):
                    delattr(cls, 'draw')
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    # Only global UI/runtime settings belong in user_default. Scene data is
    # stored by Blender in the .blend and must not be replayed on file load,
    # because scene property update callbacks can move objects.
    wm = getattr(ctx, 'window_manager', None)
    return [('window_manager', wm)] if wm is not None else []


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS
    # Smart Render now stores N-panel state in config/Smart_Render_Suite/Smart_Render_Suite.json via
    # settings.py.  The legacy common loader only accepts its old
    # {'window_manager': ...} payload so it cannot replay the full modern JSON
    # into unrelated RNA owners.
    path = settings_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict) and isinstance(raw.get('window_manager'), dict):
                _LOADED_SETTINGS = {'window_manager': raw.get('window_manager')}
                return _LOADED_SETTINGS
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import settings as _settings
        _settings.snapshot_context(ctx, force=bool(force) or _settings.is_npanel_state_save_enabled(ctx))
        try:
            path = _settings.settings_file_path()
            _AUTOSAVE_FINGERPRINT = str(path or '')
        except Exception:
            pass
        return
    except Exception:
        pass


def _autosave_timer():
    # Compatibility no-op. External N-panel persistence is now event-driven in
    # settings.py; a permanent autosave timer can interrupt 3D View navigation
    # by waking Blender's main thread during orbit/pan/zoom.
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def _remove_stale_common_handlers(collection):
    try:
        for handler in tuple(collection):
            try:
                name = str(getattr(handler, '__name__', '') or '')
                module = str(getattr(handler, '__module__', '') or '')
            except Exception:
                continue
            if name == '_load_post_handler' and module == __name__ and handler is not _load_post_handler:
                try:
                    collection.remove(handler)
                except Exception:
                    pass
    except Exception:
        pass


def _unregister_standalone_always_on_panel():
    # The Always-on controls are drawn inside SRR_PT_MAIN_PANEL. Older builds also
    # registered SMART_RENDER_PT_always_on as a separate top-level panel.  During
    # Blender shutdown, scanning Panel.__subclasses__() and reading RNA-backed
    # attributes can touch invalid RNA paths.  Use only exact bpy.types lookup so
    # this cleanup remains safe inside addon_utils.disable_all().
    targets = []
    identifiers = {'SMART_RENDER_PT_always_on'}
    for identifier in identifiers:
        try:
            found = getattr(bpy.types, identifier, None) if identifier.isidentifier() else None
        except Exception:
            found = None
        if isinstance(found, type) and found not in targets:
            targets.append(found)
    for cls in reversed(targets):
        try:
            from .rna_safety import unregister_existing_class
            unregister_existing_class(cls)
        except Exception:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass


_COMMON_OPERATOR_CLASSES = (SMART_RENDER_OT_open_help, SMART_RENDER_OT_set_always_on, SMART_RENDER_OT_save_preferences)


def _unregister_common_operator_class(cls):
    """Remove a common operator without Blender duplicate-registration noise."""
    if cls is None:
        return
    try:
        from .rna_safety import unregister_existing_class
        unregister_existing_class(cls)
        return
    except Exception:
        pass
    try:
        name = str(getattr(cls, '__name__', '') or '').strip()
        existing = getattr(bpy.types, name, None) if name and name.isidentifier() else None
    except Exception:
        existing = None
    try:
        bpy.utils.unregister_class(existing if isinstance(existing, type) else cls)
    except Exception:
        pass


def _register_common_operator_class(cls):
    _unregister_common_operator_class(cls)
    try:
        _materialize_annotations(cls)
        bpy.utils.register_class(cls)
    except ValueError:
        pass
    except Exception:
        return
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)


def register():
    _unregister_standalone_always_on_panel()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
    except Exception:
        pass
    for cls in _COMMON_OPERATOR_CLASSES:
        _register_common_operator_class(cls)
    load_settings_file()
    try:
        apply_persistent_settings(bpy.context)
    except Exception:
        pass
    # settings.py is the single load/save owner for external JSON. Remove any
    # stale common.py callback left by an older live-reload build, but do not
    # add a duplicate load_post resident.
    _remove_stale_common_handlers(bpy.app.handlers.load_post)
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    # Do not register a repeating autosave timer. settings.py uses RNA msgbus
    # change notifications and one-shot debounce saves instead.
    _patch_panel_headers()
    _patch_addon_preferences()


def unregister():
    # Final close-time persistence is handled by settings.uninstall(), after it
    # has a chance to replay the external JSON if Blender enabled the extension
    # before scene.srr_settings was available.  Saving here can serialize an
    # untouched startup scene and erase config/Smart_Render_Suite/Smart_Render_Suite.json.
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    for cls in reversed(tuple(_REGISTERED_CLASSES) or _COMMON_OPERATOR_CLASSES):
        _unregister_common_operator_class(cls)
    for cls in reversed(_COMMON_OPERATOR_CLASSES):
        _unregister_common_operator_class(cls)
    _REGISTERED_CLASSES.clear()
    _unregister_standalone_always_on_panel()
    try:
        if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    _remove_previews()
    _PENDING_PREVIEW_REMOVALS.clear()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()
