# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .tool_catalog import tool_aliases, tool_spec_defaults

SUITE_META = {
    'smart_render_suite': ('Smart Render', 'navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_ORIGINAL_MODULE_NAME_BY_ALIAS = {
    'frame_range_renderer': 'frame_range_renderer',
    'hdr_rotation': 'hdr_rotation',
    'k_tools_render_preset_manager': 'k_tools_render_preset_manager',
    'rendernames': 'rendernames',
}

_CACHE: list[dict[str, Any]] | None = None


TOOL_ALIAS_REMAP = {
    'add_on_add_camera_rigs_v1_8_2': 'camera_rigs',
    'add_on_dynamic_sky_v1_0_6': 'dynamic_sky',
    'add_on_frame_range_renderer_v1_0_0': 'frame_range_renderer',
    'add_on_freestyle_svg_exporter_v1_0_0': 'freestyle_svg_exporter',
    'add_on_hdr_rotation_v1_0_7': 'hdr_rotation',
    'add_on_k_tools_render_preset_manager_v1_3_0': 'k_tools_render_preset_manager',
    'add_on_lfs_camera_plane_v3_0_0': 'camera_plane',
    'add_on_overscan_v1_2_3': 'overscan',
    'add_on_pseudo_rendering_farm_v0_9_0': 'pseudo_rendering_farm',
    'add_on_profiler_v0_9_4': 'profiler',
    'add_on_rendernames_v1_2_0': 'rendernames',
    'add_on_sun_position_v4_4_0': 'sun_position',
    'add_on_tri_lighting_v0_2_1': 'tri_lighting',
    'add_on_use_for_rendering_plus_v1_2_5': 'use_for_rendering_plus',
}


def package_root() -> Path:
    return Path(__file__).resolve().parent


def report_path() -> Path:
    return package_root() / 'INTEGRATED_ADDONS_REPORT.md'


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'integrated_addon'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def _suite_name_to_key(_label: str) -> str:
    return 'smart_render_suite'


def _parse_report() -> dict[str, dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return {}

    specs: dict[str, dict[str, Any]] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            alias = TOOL_ALIAS_REMAP.get(sanitize_alias(match.group('outer')), sanitize_alias(match.group('outer')))
            current = {
                'alias': alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': _suite_name_to_key(match.group('suite').strip()),
                'suite_name': 'Smart Render',
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs[alias] = current
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r'"name"\s*:\s*"([^"]+)"', text)
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _iter_addon_dirs(expected_aliases: list[str] | tuple[str, ...] | None = None):
    root = package_root()
    aliases: list[str] = []
    if expected_aliases:
        for alias in expected_aliases:
            text = str(alias or '').strip()
            if text and text not in aliases:
                aliases.append(text)
    if not aliases:
        for alias in tool_aliases():
            if alias not in aliases:
                aliases.append(alias)
        for alias in TOOL_ALIAS_REMAP.values():
            if alias not in aliases:
                aliases.append(alias)

    try:
        discovered = sorted(
            child.name
            for child in root.iterdir()
            if child.is_dir()
            and not child.name.startswith('.')
            and child.name != '__pycache__'
            and (child / '__init__.py').exists()
        )
    except Exception:
        discovered = []

    for alias in discovered:
        if alias not in aliases:
            aliases.append(alias)

    for alias in aliases:
        path = root / alias
        if not path.is_dir():
            continue
        if path.name.startswith('.') or path.name == '__pycache__':
            continue
        if not (path / '__init__.py').exists():
            continue
        yield path


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    report_specs = _parse_report()
    ordered_aliases: list[str] = []
    for alias in tool_aliases():
        if alias not in ordered_aliases:
            ordered_aliases.append(alias)
    for alias in report_specs.keys():
        if alias not in ordered_aliases:
            ordered_aliases.append(alias)
    for alias in TOOL_ALIAS_REMAP.values():
        if alias not in ordered_aliases:
            ordered_aliases.append(alias)

    results: list[dict[str, Any]] = []
    for addon_dir in _iter_addon_dirs(ordered_aliases):
        alias = addon_dir.name
        spec = dict(report_specs.get(alias) or {
            'alias': alias,
            'outer_zip': alias + '.zip',
            'display_name': alias,
            'suite': 'smart_render_suite',
            'suite_name': 'Smart Render',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
        })
        init_path = addon_dir / '__init__.py'
        spec['addon_dir'] = str(addon_dir)
        spec['src_dir'] = str(addon_dir)
        spec['source_root'] = ''
        spec['original_module_name'] = _ORIGINAL_MODULE_NAME_BY_ALIAS.get(alias, '')
        spec['import_mode'] = 'root_package'
        spec['init_relpath'] = '__init__.py'
        spec['search_root'] = ''
        spec['vendor_dir'] = str(addon_dir)
        spec['suite_name'] = 'Smart Render'

        name, description = _read_bl_info_name_and_description(init_path)
        defaults = tool_spec_defaults(alias)

        display_name = str(defaults.get('display_name') or name or spec.get('display_name') or alias)
        if name and spec.get('display_name') in {'', None, alias}:
            display_name = name
        spec['display_name'] = display_name
        spec['description'] = str(defaults.get('description_en') or description or display_name)

        for key in ('summary_en', 'summary_ja', 'usage_en', 'usage_ja'):
            if defaults.get(key):
                spec[key] = defaults[key]

        if defaults.get('version'):
            spec['tool_version'] = tuple(defaults.get('version'))
        if defaults.get('blender'):
            spec['tool_blender'] = tuple(defaults.get('blender'))

        results.append(spec)

    _CACHE = list(results)
    return list(results)
