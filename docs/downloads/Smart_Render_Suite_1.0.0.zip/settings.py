# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

_CONFIG_DIR = 'settings'
_CONFIG_FOLDER = 'Smart_Render_Suite'
_CONFIG_FILE = 'Smart_Render_Suite.json'
_LEGACY_CONFIG_FILE = 'n_panel_persistent_settings.json'
_VERSION = 8

# The user-facing Smart Render N-panel is treated as a global workspace UI.
# All N-panel settings are stored in Blender's config/Smart_Render_Suite
# directory so they survive scene switching, file reloads, and Blender restarts.
_SCENE_GROUPS: tuple[str, ...] = (
    'srr_settings',
    'rendernames',
    'sun_pos_properties',
    'svg_export',
    'render_preset_settings',
    'ufrp',
    'overscan_settings',
)
_SCENE_COLLECTIONS: tuple[str, ...] = ('srr_queue', 'srr_variants')
_STRUCTURED_DEFAULTS_VERSION = 1
_STRUCTURED_DEFAULTS_KEY = 'structured_defaults_version'
_SCENE_VALUES: tuple[str, ...] = (
    'srr_queue_index',
    'srr_variant_index',
    # Lazily registered integrated-tool controls.  Missing RNA is deliberately
    # ignored until loader.refresh_change_subscriptions() runs after load.
    'pseudo_rendering_farm_instances',
    'frame_range_input',
)
_WM_GROUPS = (
    'camera_plane_settings',
    'profiler',
    'rendernames_global',
    'smart_render_k_tools_prefs',
    'smart_render_camera_rigs_prefs',
    'smart_render_sun_position_prefs',
    'smart_render_ufrp_prefs',
    'render_pipeline_settings',
)
_WM_VALUES = (
    'smart_render_suite_search_text',
    'smart_render_suite_show_integrated_tools',
)
_RUNTIME_VALUE_ALIASES = {
    'search_text': 'smart_render_suite_search_text',
    'show_integrated_tools': 'smart_render_suite_show_integrated_tools',
}

_ADDON_PREF_VALUES = (
    'search_text',
    'show_integrated_tools',
)  # Legacy import only; root UI now uses WindowManager runtime settings.

_SKIP_NAMES = {
    'rna_type',
    'bl_rna',
    'id_data',
    'name',
}
_SKIP_SUBSTRINGS = (
    'thumbnail',
    'icon',
    'error',
    'traceback',
    'status_text',
    'runtime_log',
    'progress',
    'is_running',
    'pointer',
)
_PERSISTENT_STATE_NAMES = {
    'n_panel_state_save',
    'integrated_tool_section_state_json',
    'show_section_logs',
    'halt_on_first_error',
    'preview_limit',
}
_PERSISTENT_STATE_PREFIXES = (
    'show_section_',
)
_PRIMITIVE_TYPES = (bool, int, float, str)

_DATA_CACHE: dict[str, Any] | None = None
_REGISTERED = False
_LOADING = False
_LAST_SIGNATURE = ''
_LAST_SAVE_TIME = 0.0
_APPLIED_SCENES: set[int] = set()
_APPLIED_WMS: set[int] = set()
_APPLIED_POINTER_CACHE_LIMIT = 64
_AUTOSAVE_TIMER = None
_STARTUP_APPLY_TIMER = None
_STARTUP_APPLY_ATTEMPTS = 0
_STARTUP_APPLY_MAX_ATTEMPTS = 40
_MSGBUS_OWNER = object()
_CHANGE_SAVE_TIMER = None
_CHANGE_SAVE_PENDING_FORCE = False
_LAST_CHANGE_TIME = 0.0
_CHANGE_SAVE_DEBOUNCE = 0.45
_LAST_SCENE_POINTER = 0
_SCENE_RESTORE_PENDING = False
_REGISTRATION_GUARD = False
_REGISTRATION_PAYLOAD: dict[str, Any] | None = None
_LOAD_ERROR = ''
_LAST_WRITE_ERROR = ''

_ON_DEMAND_REPLACED_ALWAYS_ON = {
    'camera_plane': {'auto_load_maintenance'},
    'rendernames': {'auto_refresh_preview'},
    'k_tools_render_preset_manager': {'auto_sync_on_startup'},
}




def _remember_applied_pointer(cache: set[int], pointer: int) -> None:
    """Keep scene/window-manager replay markers strictly bounded."""
    value = int(pointer or 0)
    if value <= 0:
        return
    if value not in cache and len(cache) >= _APPLIED_POINTER_CACHE_LIMIT:
        cache.clear()
    cache.add(value)


def _invalidate_preview_snapshot(scene=None) -> None:
    """Invalidate derived UI previews without performing a data scan."""
    try:
        from . import preview_cache
        target = scene if scene is not None else _context_scene(getattr(bpy, 'context', None))
        preview_cache.invalidate_scene(target)
    except Exception:
        pass

def is_applying_context() -> bool:
    """Return True while user_default runtime settings are being replayed.

    Other modules use this to avoid running scene-changing update callbacks
    during file load or extension registration.
    """
    # Registration of a lazy integrated tool is also a restore boundary.  Its
    # RNA defaults and legacy initialization callbacks must not be treated as
    # user edits before the frozen canonical payload has been replayed.
    return bool(_LOADING or _REGISTRATION_GUARD)




def _coerce_saved_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        token = value.strip().lower()
        if token in {'1', 'true', 'yes', 'on', 'enabled'}:
            return True
        if token in {'0', 'false', 'no', 'off', 'disabled', ''}:
            return False
    return bool(default)


def last_write_error() -> str:
    return str(_LAST_WRITE_ERROR or '')


def is_npanel_state_save_enabled(context=None, data: dict[str, Any] | None = None) -> bool:
    """Return whether normal N-panel edits should be written immediately."""
    try:
        scene = _context_scene(context)
        settings_obj = getattr(scene, 'srr_settings', None) if scene is not None else None
        if settings_obj is not None and hasattr(settings_obj, 'n_panel_state_save'):
            return _coerce_saved_bool(getattr(settings_obj, 'n_panel_state_save', True), True)
    except Exception:
        pass
    try:
        source = data if isinstance(data, dict) else _load_data()
        return _coerce_saved_bool(source.get('n_panel_state_save_enabled', True), True)
    except Exception:
        return True


def should_write_external_config_now(context=None) -> bool:
    return is_npanel_state_save_enabled(context)


def set_npanel_state_save_enabled(enabled: bool, *, context=None, save: bool = True) -> bool:
    """Persist the master N-panel state-save switch itself immediately."""
    global _LAST_SIGNATURE
    data = _load_data()
    enabled = bool(enabled)
    data['n_panel_state_save_enabled'] = enabled
    try:
        scene = _context_scene(context)
        settings_obj = getattr(scene, 'srr_settings', None) if scene is not None else None
        if settings_obj is not None and hasattr(settings_obj, 'n_panel_state_save'):
            target = enabled
            try:
                if bool(getattr(settings_obj, 'n_panel_state_save', True)) != target:
                    setattr(settings_obj, 'n_panel_state_save', target)
            except Exception:
                pass
            scene_groups = data.setdefault('scene_groups', {})
            if isinstance(scene_groups, dict):
                group = scene_groups.setdefault('srr_settings', {})
                if isinstance(group, dict):
                    group['n_panel_state_save'] = target
    except Exception:
        pass
    # Apply the change to the live subscription graph immediately.  OFF keeps
    # only the Scene-boundary listener; ON restores all real-time setting keys.
    if _REGISTERED and not is_applying_context():
        try:
            _register_change_subscriptions()
        except Exception:
            pass
    if save and not is_applying_context():
        _LAST_SIGNATURE = ''
        # OFF is allowed exactly one complete atomic snapshot: the transition
        # itself. Every later caller, including force=True legacy callers, is
        # rejected by snapshot_context/_write_data until the switch is ON.
        if snapshot_context(context, force=True, _allow_disabled_once=not enabled):
            return True
        return _write_data(data, allow_disabled_once=not enabled)
    return True

def settings_file_path() -> Path | None:
    """Return the external Smart Render config file in Blender's config dir.

    On Windows this resolves to:
    C:/Users/<User>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Render_Suite/Smart_Render_Suite.json
    """
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            config_dir = user_resource('CONFIG', create=True)
            if config_dir:
                base = Path(config_dir) / _CONFIG_FOLDER
                base.mkdir(parents=True, exist_ok=True)
                return base / _CONFIG_FILE
    except Exception:
        pass
    try:
        from .storage import config_root
        base = config_root(create=True) / _CONFIG_FOLDER
        base.mkdir(parents=True, exist_ok=True)
        return base / _CONFIG_FILE
    except Exception:
        version = '5.1'
        try:
            app_version = getattr(getattr(bpy, 'app', None), 'version', None)
            if app_version and len(app_version) >= 2:
                version = f'{int(app_version[0])}.{int(app_version[1])}'
        except Exception:
            pass
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            base = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / _CONFIG_FOLDER
        else:
            base = Path.home() / '.config' / 'blender' / version / 'config' / _CONFIG_FOLDER
        try:
            base.mkdir(parents=True, exist_ok=True)
            return base / _CONFIG_FILE
        except Exception:
            return None


def _settings_path() -> Path | None:
    return settings_file_path()


def _legacy_settings_paths() -> list[Path]:
    paths: list[Path] = []
    try:
        from .storage import user_default_root
        paths.append(user_default_root(_CONFIG_DIR, create=False) / _LEGACY_CONFIG_FILE)
    except Exception:
        pass
    try:
        from .compat import extension_user_root
        paths.append(Path(extension_user_root(create=False)) / _CONFIG_DIR / _LEGACY_CONFIG_FILE)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            config_dir = user_resource('CONFIG', create=False)
            if config_dir:
                config_root = Path(config_dir)
                paths.append(config_root / _CONFIG_FILE)
                paths.append(config_root / _CONFIG_FOLDER / _LEGACY_CONFIG_FILE)
                paths.append(config_root / _LEGACY_CONFIG_FILE)
                paths.append(config_root / 'SmartTools' / _LEGACY_CONFIG_FILE)
    except Exception:
        pass
    seen: set[str] = set()
    unique: list[Path] = []
    for path in paths:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        unique.append(path)
    return unique



def _scrub_on_demand_replaced_always_on(data: dict[str, Any]) -> None:
    """Remove legacy always-on state for tasks now handled on demand.

    Prevents older Smart_Render_Suite.json or .blend-serialized props from
    re-enabling file-load/timer work for maintenance/preview/sync features that
    now have manual or draw-time equivalents.
    """
    if not isinstance(data, dict):
        return
    store = data.get('always_on')
    if isinstance(store, dict):
        for alias, prop_names in _ON_DEMAND_REPLACED_ALWAYS_ON.items():
            nested = store.get(alias)
            if isinstance(nested, dict):
                for prop_name in prop_names:
                    nested.pop(prop_name, None)
                if not nested:
                    store.pop(alias, None)
            for prop_name in prop_names:
                store.pop(f'{alias}.{prop_name}', None)
    wm_groups = data.get('wm_groups')
    if isinstance(wm_groups, dict):
        cam = wm_groups.get('camera_plane_settings')
        if isinstance(cam, dict):
            cam['auto_load_maintenance'] = False
    scene_groups = data.get('scene_groups')
    if isinstance(scene_groups, dict):
        # These owners are stored in .blend data, not in the Smart Render root
        # scene group. The guard is kept here for forward compatibility with
        # older experimental snapshots that may have included them.
        for group_name, prop_name in (('rendernames', 'auto_refresh_preview'), ('render_preset_settings', 'auto_sync_on_startup')):
            group = scene_groups.get(group_name)
            if isinstance(group, dict):
                group[prop_name] = False


def _rewrite_legacy_package_paths(value: Any) -> tuple[Any, bool]:
    """Redirect saved package-local mutable paths into Smart Render CONFIG."""
    changed = False
    if isinstance(value, dict):
        result: dict[Any, Any] = {}
        for key, item in value.items():
            rewritten, item_changed = _rewrite_legacy_package_paths(item)
            result[key] = rewritten
            changed = changed or item_changed
        return result, changed
    if isinstance(value, list):
        result_list = []
        for item in value:
            rewritten, item_changed = _rewrite_legacy_package_paths(item)
            result_list.append(rewritten)
            changed = changed or item_changed
        return result_list, changed
    if not isinstance(value, str) or not value.strip():
        return value, False

    normalized = value.replace('\\', '/')
    lowered = normalized.casefold()
    marker = '/extensions/user_default/smart_render_suite'
    index = lowered.find(marker)
    if index < 0:
        return value, False
    suffix = normalized[index + len(marker):].lstrip('/')
    try:
        from .storage import suite_data_root
        target = suite_data_root(create=True)
    except Exception:
        return value, False
    rewritten = target.joinpath(*[part for part in suffix.split('/') if part]) if suffix else target
    return str(rewritten), str(rewritten) != value

def _load_data() -> dict[str, Any]:
    global _DATA_CACHE, _LOAD_ERROR
    if _DATA_CACHE is not None:
        return _DATA_CACHE
    data: dict[str, Any] = {'version': _VERSION}
    path = _settings_path()
    source = path if path is not None and path.exists() else None
    if source is None:
        for legacy in _legacy_settings_paths():
            try:
                if legacy.exists():
                    source = legacy
                    break
            except Exception:
                continue
    _LOAD_ERROR = ''
    if source is not None and source.exists():
        try:
            raw = json.loads(source.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                data.update(raw)
            else:
                _LOAD_ERROR = 'CONFIG_ROOT_NOT_OBJECT'
        except Exception:
            _LOAD_ERROR = 'CONFIG_JSON_INVALID'
            data = {'version': _VERSION}
    if int(data.get('version', 0) or 0) < _VERSION:
        data['version'] = _VERSION
    data.setdefault('scene_groups', {})
    data.setdefault('scene_collections', {})
    data.setdefault('scene_values', {})
    data.setdefault('wm_groups', {})
    data.setdefault('wm_values', {})
    data.setdefault('addon_preferences', {})
    data.setdefault('always_on', {})
    data.setdefault('loaded_tools', [])
    data.setdefault('n_panel_state_save_enabled', True)
    _scrub_on_demand_replaced_always_on(data)
    rewritten, storage_paths_changed = _rewrite_legacy_package_paths(data)
    if isinstance(rewritten, dict):
        data = rewritten
    _DATA_CACHE = data
    if storage_paths_changed:
        try:
            _write_data(data)
        except Exception:
            pass
    return _DATA_CACHE


def _scene_settings_has_non_default(values: Any) -> bool:
    if not isinstance(values, dict):
        return False
    sentinels = {
        'compact_mode': True,
        'show_advanced': False,
        'show_always_on_toggles': False,
        'n_panel_state_save': True,
        'show_section_smart_render_overview': False,
        'show_section_render_profile': False,
        'quality_mode': 'PREVIEW',
        'sample_multiplier': 1.0,
    }
    for key, default in sentinels.items():
        if key not in values:
            continue
        try:
            if values.get(key) != default:
                return True
        except Exception:
            pass
    try:
        output_root = str(values.get('output_root', '') or '')
        if output_root and 'smart_render_suite/renders' not in output_root.replace('\\', '/'):
            return True
    except Exception:
        pass
    return False


def _deep_merge_missing(base: dict[str, Any], saved: Any) -> dict[str, Any]:
    if not isinstance(saved, dict):
        return base
    for key, value in saved.items():
        if key not in base:
            base[key] = value
        elif isinstance(base.get(key), dict) and isinstance(value, dict):
            _deep_merge_missing(base[key], value)
    return base


def _contains_named_pointer_record(value: Any) -> bool:
    """Return whether a nested payload contains a resolvable Blender-ID pointer."""

    if isinstance(value, dict):
        if value.get('__pointer__') and str(value.get('name') or '').strip():
            return True
        return any(_contains_named_pointer_record(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return any(_contains_named_pointer_record(item) for item in value)
    return False


def _preserve_existing_scene_state_if_needed(path: Path, data: dict[str, Any]) -> None:
    """Avoid startup-time default snapshots from erasing the external config.

    Blender can fire update/timer paths while an extension is still enabling.
    If that happens before the saved scene settings have been replayed, the
    default scene can try to overwrite Smart_Render_Suite/Smart_Render_Suite.json.  When the file
    already contains non-default Smart Render settings and the new payload looks
    like an untouched default scene, keep the file-backed scene state and clear
    the applied-scene cache so the next apply pass restores it.
    """
    global _APPLIED_SCENES
    # Once the active scene has been replayed, this is an ordinary user-driven
    # write (including the state-save gate's deferred flush).  Preserving the
    # old file at that point would incorrectly undo intentional changes that
    # happen to move a group back to its defaults.
    try:
        scene = getattr(bpy.context, 'scene', None)
        if _REGISTERED and scene is not None and id(scene) in _APPLIED_SCENES:
            return
    except Exception:
        pass
    try:
        if not path.exists():
            return
        existing_raw = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(existing_raw, dict):
            return
    except Exception:
        return
    try:
        existing_settings = existing_raw.get('scene_groups', {}).get('srr_settings', {})
        current_settings = data.get('scene_groups', {}).get('srr_settings', {})
    except Exception:
        return
    existing_non_default = _scene_settings_has_non_default(existing_settings)
    current_non_default = _scene_settings_has_non_default(current_settings)
    try:
        existing_scene_groups = existing_raw.get('scene_groups', {})
        current_scene_groups = data.get('scene_groups', {})
    except Exception:
        existing_scene_groups = {}
        current_scene_groups = {}
    existing_named_pointer = _contains_named_pointer_record(existing_scene_groups)
    current_named_pointer = _contains_named_pointer_record(current_scene_groups)
    if (existing_non_default and not current_non_default) or (existing_named_pointer and not current_named_pointer):
        for key in ('scene_groups', 'scene_collections', 'scene_values'):
            value = existing_raw.get(key)
            if isinstance(value, dict):
                data[key] = value
        try:
            _APPLIED_SCENES.clear()
        except Exception:
            pass
    for key in ('always_on', 'feature_toggles'):
        existing_value = existing_raw.get(key)
        if isinstance(existing_value, dict):
            current_value = data.get(key)
            if not isinstance(current_value, dict):
                current_value = {}
                data[key] = current_value
            _deep_merge_missing(current_value, existing_value)


def _write_data(data: dict[str, Any], *, allow_disabled_once: bool = False) -> bool:
    global _LAST_WRITE_ERROR
    if _REGISTRATION_GUARD:
        _LAST_WRITE_ERROR = 'REGISTRATION_GUARD_ACTIVE'
        return False
    if _LOAD_ERROR:
        _LAST_WRITE_ERROR = _LOAD_ERROR
        return False
    if not allow_disabled_once:
        data_enabled = _coerce_saved_bool(data.get('n_panel_state_save_enabled', True), True)
        try:
            saved_group = data.get('scene_groups', {}).get('srr_settings', {})
            if isinstance(saved_group, dict) and 'n_panel_state_save' in saved_group:
                data_enabled = _coerce_saved_bool(saved_group.get('n_panel_state_save'), data_enabled)
        except Exception:
            pass
        live_enabled = is_npanel_state_save_enabled(getattr(bpy, 'context', None), data)
        if not data_enabled or not live_enabled:
            _LAST_WRITE_ERROR = 'N_PANEL_STATE_SAVE_DISABLED'
            return False
    path = _settings_path()
    if path is None:
        _LAST_WRITE_ERROR = 'CONFIG_PATH_UNAVAILABLE'
        return False
    temporary = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        _preserve_existing_scene_state_if_needed(path, data)
        _scrub_on_demand_replaced_always_on(data)
        data['version'] = _VERSION
        payload = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        try:
            if path.exists() and path.read_text(encoding='utf-8') == payload:
                _LAST_WRITE_ERROR = ''
                return True
        except Exception:
            pass
        temporary = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
        temporary.write_text(payload, encoding='utf-8')
        os.replace(str(temporary), str(path))
        _LAST_WRITE_ERROR = ''
        return True
    except Exception as exc:
        _LAST_WRITE_ERROR = f'{type(exc).__name__}: {exc}'
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except Exception:
                pass
        return False


def _always_on_store(data: dict[str, Any] | None = None) -> dict[str, Any]:
    if data is None:
        data = _load_data()
    store = data.get('always_on')
    if not isinstance(store, dict):
        store = {}
        data['always_on'] = store
    return store


def get_known_always_on(alias: str, prop_name: str, default: bool | None = False):
    """Return the saved state for a centralized always-on toggle.

    The store is independent from Scene/WindowManager runtime data so an
    unloaded tool can remain completely unloaded while its requested state is
    still remembered for the next startup.
    """
    alias = str(alias or '').strip()
    prop_name = str(prop_name or '').strip()
    if not alias or not prop_name:
        return default if default is None else bool(default)
    store = _always_on_store()
    try:
        nested = store.get(alias)
        if isinstance(nested, dict) and prop_name in nested:
            return _coerce_saved_bool(nested.get(prop_name), False)
        flat_key = f'{alias}.{prop_name}'
        if flat_key in store:
            return _coerce_saved_bool(store.get(flat_key), False)
    except Exception:
        pass
    return default if default is None else bool(default)


def set_known_always_on(alias: str, prop_name: str, enabled: bool, *, save: bool = True) -> bool:
    """Persist a centralized always-on toggle without loading its tool."""
    global _LAST_SIGNATURE
    alias = str(alias or '').strip()
    prop_name = str(prop_name or '').strip()
    if not alias or not prop_name:
        return False
    data = _load_data()
    store = _always_on_store(data)
    nested = store.get(alias)
    if not isinstance(nested, dict):
        nested = {}
        store[alias] = nested
    nested[prop_name] = bool(enabled)
    # Mirror the stable UI RNA identifier as a first-class JSON key.  The
    # central PropertyGroup is intentionally available even while the owning
    # lazy tool is unloaded, so its value must be independently auditable and
    # restorable without importing that tool.
    proxy_key = f'known__{alias}__{prop_name}'
    proxy_values = data.setdefault('persistent_toggle_state', {})
    if isinstance(proxy_values, dict):
        proxy_values[proxy_key] = bool(enabled)
    # Remove legacy flat key after migrating it into the nested structure.
    try:
        store.pop(f'{alias}.{prop_name}', None)
    except Exception:
        pass
    if save and is_npanel_state_save_enabled(getattr(bpy, 'context', None), data):
        _LAST_SIGNATURE = ''
        return bool(_write_data(data))
    return True


def enabled_known_aliases() -> set[str]:
    """Return aliases that have at least one saved always-on item enabled."""
    store = _always_on_store()
    aliases: set[str] = set()
    try:
        for key, value in store.items():
            if isinstance(value, dict):
                if any(_coerce_saved_bool(v, False) for v in value.values()):
                    aliases.add(str(key))
            elif isinstance(key, str) and '.' in key and _coerce_saved_bool(value, False):
                aliases.add(key.split('.', 1)[0])
    except Exception:
        pass
    return aliases


def _should_skip_name(name: str) -> bool:
    key = str(name or '').strip()
    low = key.lower()
    if key in _PERSISTENT_STATE_NAMES or any(key.startswith(prefix) for prefix in _PERSISTENT_STATE_PREFIXES):
        return False
    if not key or key in _SKIP_NAMES or key.startswith('_'):
        return True
    return any(token in low for token in _SKIP_SUBSTRINGS)


def _is_persistent_display_name(obj: Any, name: str) -> bool:
    """Identify a real user setting that intentionally uses RNA ``name``."""
    if str(name or '') != 'name' or obj is None:
        return False
    try:
        identifier = str(getattr(getattr(obj, 'bl_rna', None), 'identifier', '') or '')
    except Exception:
        identifier = ''
    return identifier == 'SRR_VariantItem' or type(obj).__name__ == 'SRR_VariantItem'


def _iter_rna_property_names(obj: Any) -> list[str]:
    names: list[str] = []
    try:
        rna_props = getattr(getattr(obj, 'bl_rna', None), 'properties', None)
        if rna_props is not None:
            for prop in rna_props:
                identifier = str(getattr(prop, 'identifier', '') or '')
                if identifier and (
                    not _should_skip_name(identifier)
                    or _is_persistent_display_name(obj, identifier)
                ):
                    names.append(identifier)
    except Exception:
        pass
    if not names:
        try:
            for identifier in dir(obj):
                if not _should_skip_name(identifier):
                    names.append(str(identifier))
        except Exception:
            pass
    # Preserve order and remove duplicates.
    seen: set[str] = set()
    out: list[str] = []
    for name in names:
        if name not in seen:
            seen.add(name)
            out.append(name)
    return out


def _serialize_value(value: Any, depth: int = 0) -> Any:
    if depth > 3:
        return None
    if value is None or isinstance(value, _PRIMITIVE_TYPES):
        return value
    # Pointer settings are portable references, never copies of artistic data.
    # Type plus exact datablock name prevents an unrelated same-label type from
    # being rebound after a scene/file change.
    try:
        if isinstance(value, bpy.types.ID):
            # Preserve Blender's canonical RNA identifier spelling (Object,
            # Collection, Material, ...). Restore remains case-insensitive.
            id_type = str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or type(value).__name__)
            return {'__pointer__': id_type, 'name': str(getattr(value, 'name', '') or '')}
    except Exception:
        pass
    # Nested PropertyGroups and CollectionProperties are configuration schema,
    # not artistic datablocks. Preserve their primitive fields recursively.
    try:
        if hasattr(value, 'bl_rna') and hasattr(value, 'add') and hasattr(value, 'clear'):
            return {'__collection__': [_serialize_group(item, depth + 1) for item in list(value)]}
        if hasattr(value, 'bl_rna'):
            nested = _serialize_group(value, depth + 1)
            if nested:
                return nested
    except Exception:
        pass
    # Vectors, colors, arrays and enum sets are stored as simple lists when safe.
    try:
        if isinstance(value, (list, tuple, set)):
            out = [_serialize_value(item, depth + 1) for item in value]
            return [item for item in out if item is not None]
    except Exception:
        pass
    try:
        if not isinstance(value, (str, bytes, dict)) and hasattr(value, '__iter__'):
            out = [_serialize_value(item, depth + 1) for item in list(value)]
            if out and all(item is not None for item in out):
                return out
    except Exception:
        pass
    return None


def _serialize_group(obj: Any, depth: int = 0) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if obj is None or depth > 3:
        return result
    for name in _iter_rna_property_names(obj):
        if obj.bl_rna.identifier == 'OverscanSettings' and name in {'original_frame', 'edited_camera'}:
            continue
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        if value is None:
            # Empty pointer controls are still part of the persistent schema.
            result[name] = None
            continue
        serialized = _serialize_value(value, depth + 1)
        if serialized is not None:
            result[name] = serialized
    return result


def _serialize_collection(collection: Any) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    try:
        iterator = list(collection)
    except Exception:
        return items
    for item in iterator:
        data = _serialize_group(item)
        if data:
            items.append(data)
    return items




def _rna_property_for(obj: Any, name: str):
    try:
        props = getattr(getattr(obj, 'bl_rna', None), 'properties', None)
        if props is None:
            return None
        getter = getattr(props, 'get', None)
        if callable(getter):
            return getter(str(name))
        for prop in props:
            if str(getattr(prop, 'identifier', '') or '') == str(name):
                return prop
    except Exception:
        return None
    return None


def _fallback_relative_root() -> Path:
    try:
        from .storage import user_default_root
        root = user_default_root('relative_paths', create=True)
    except Exception:
        try:
            from .compat import extension_user_root
            root = Path(extension_user_root(create=True)) / 'relative_paths'
        except Exception:
            version = '5.1'
            try:
                app_version = getattr(getattr(bpy, 'app', None), 'version', None)
                if app_version and len(app_version) >= 2:
                    version = f'{int(app_version[0])}.{int(app_version[1])}'
            except Exception:
                pass
            if os.name == 'nt':
                roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
                root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / _CONFIG_FOLDER / 'relative_paths'
            else:
                root = Path.home() / '.config' / 'blender' / version / 'config' / _CONFIG_FOLDER / 'relative_paths'
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return root


def _absolutize_blend_relative(value: str) -> str:
    raw = str(value or '').strip()
    if not raw.startswith('//'):
        return raw
    resolved = ''
    try:
        resolved = str(bpy.path.abspath(raw) or '').strip()
    except Exception:
        resolved = ''
    if resolved and not resolved.startswith('//'):
        return resolved
    relative = raw[2:].lstrip('/\\') or 'path'
    return str(_fallback_relative_root() / relative)


def _normalize_value_for_assignment(obj: Any, name: str, value: Any) -> Any:
    """Preserve the canonical user preference exactly during replay.

    Blender's ``//`` prefix is semantic data (blend-relative), not a request to
    resolve a path while restoring the add-on's external settings.  The narrow
    package-local migration remains in ``_rewrite_legacy_package_paths`` and is
    intentionally independent from ordinary assignment.
    """
    return value


def _resolve_pointer_record(value: Any):
    if not isinstance(value, dict) or not value.get('__pointer__'):
        return None, False
    id_type = str(value.get('__pointer__') or '').strip().upper()
    name = str(value.get('name') or '')
    if not name:
        return None, True
    collections = {
        'OBJECT': 'objects',
        'COLLECTION': 'collections',
        'MATERIAL': 'materials',
        'IMAGE': 'images',
        'TEXTURE': 'textures',
        'WORLD': 'worlds',
        'SCENE': 'scenes',
        'CAMERA': 'cameras',
        'LIGHT': 'lights',
        'NODETREE': 'node_groups',
    }
    container = getattr(getattr(bpy, 'data', None), collections.get(id_type, ''), None)
    try:
        return (container.get(name) if container is not None else None), True
    except Exception:
        return None, True


def _preserve_unresolved_pointer_records(current: Any, previous: Any) -> Any:
    """Keep portable ID references until their datablocks can be resolved.

    A factory-startup restore has no datablocks from the user's saved .blend,
    so a valid named pointer is temporarily represented by ``None`` in RNA.
    Mirroring that transient value back to JSON would permanently erase the
    portable reference before the matching .blend is opened.  Preserve only
    records whose named ID is currently unavailable.  If the ID still exists
    and the live pointer is ``None``, that is an explicit user Clear and the
    resulting JSON null remains authoritative.
    """
    if not isinstance(current, dict) or not isinstance(previous, dict):
        return current
    for name, old_value in previous.items():
        if isinstance(old_value, dict) and old_value.get('__pointer__'):
            if current.get(name) is None:
                resolved, is_pointer = _resolve_pointer_record(old_value)
                if is_pointer and resolved is None:
                    current[name] = old_value
            continue
        new_value = current.get(name)
        if isinstance(new_value, dict) and isinstance(old_value, dict):
            _preserve_unresolved_pointer_records(new_value, old_value)
    return current


def _preserve_unknown_group_values(current: Any, previous: Any, obj: Any) -> Any:
    """Keep forward-version keys which this build does not own."""
    if not isinstance(current, dict) or not isinstance(previous, dict):
        return current
    for name, old_value in previous.items():
        if name not in current:
            try:
                known_here = hasattr(obj, str(name))
            except Exception:
                known_here = False
            if not known_here:
                current[name] = old_value
            continue
        if isinstance(current.get(name), dict) and isinstance(old_value, dict):
            try:
                child = getattr(obj, str(name), None)
            except Exception:
                child = None
            _preserve_unknown_group_values(current[name], old_value, child)
    return current


def _assign_if_changed(obj: Any, name: str, current: Any, value: Any) -> None:
    # An RNA assignment fires the property's update callback even for an equal value,
    # so restoring untouched settings would run tool logic (overscan renamed the camera).
    normalized = _normalize_value_for_assignment(obj, name, value)
    try:
        same = current == normalized if isinstance(current, (bool, int, float, str)) else list(current) == list(normalized)
    except Exception:
        same = False
    if not same:
        setattr(obj, name, normalized)


def _apply_group(obj: Any, values: Any) -> None:
    if obj is None or not isinstance(values, dict):
        return
    for name, value in values.items():
        if _should_skip_name(str(name)) and not _is_persistent_display_name(obj, str(name)):
            continue
        try:
            current = getattr(obj, str(name))
        except Exception:
            current = None
        pointer, is_pointer = _resolve_pointer_record(value)
        if is_pointer:
            try:
                setattr(obj, str(name), pointer)
            except Exception:
                pass
        elif value is None or isinstance(value, _PRIMITIVE_TYPES):
            try:
                _assign_if_changed(obj, str(name), current, value)
            except Exception:
                pass
        elif isinstance(value, list):
            # Blender vector-like properties support sequence assignment, while
            # CollectionProperty values do not.  Attempt assignment only.
            try:
                _assign_if_changed(obj, str(name), current, value)
            except Exception:
                pass
        elif isinstance(value, dict) and current is not None:
            if isinstance(value.get('__collection__'), list):
                _apply_collection(current, value.get('__collection__'))
            else:
                _apply_group(current, value)


def _apply_collection(collection: Any, items: Any) -> None:
    if collection is None or not isinstance(items, list):
        return
    try:
        collection.clear()
    except Exception:
        return
    for values in items:
        if not isinstance(values, dict):
            continue
        try:
            item = collection.add()
        except Exception:
            break
        _apply_group(item, values)


def _serialize_named_values(obj: Any, names: tuple[str, ...]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if obj is None:
        return out
    for name in names:
        if not hasattr(obj, name):
            continue
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        serialized = _serialize_value(value)
        if serialized is not None:
            out[name] = serialized
    return out


def _apply_named_values(obj: Any, values: Any, names: tuple[str, ...]) -> None:
    if obj is None or not isinstance(values, dict):
        return
    for name in names:
        if name not in values or not hasattr(obj, name):
            continue
        try:
            current = getattr(obj, name)
            value = values.get(name)
            value = _normalize_value_for_assignment(obj, str(name), value)
            if current != value:
                setattr(obj, name, value)
        except Exception:
            pass


def _apply_wm_runtime_values(wm: Any, values: Any) -> None:
    if wm is None or not isinstance(values, dict):
        return
    for source_name, target_name in _RUNTIME_VALUE_ALIASES.items():
        if source_name in values:
            value = values.get(source_name)
        elif target_name in values:
            value = values.get(target_name)
        else:
            continue
        if not hasattr(wm, target_name):
            continue
        try:
            if target_name.endswith('show_integrated_tools'):
                value = bool(value)
            else:
                value = str(value or '')
            if getattr(wm, target_name) != value:
                setattr(wm, target_name, value)
        except Exception:
            pass


def _serialize_wm_runtime_values(wm: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if wm is None:
        return out
    for name in _WM_VALUES:
        if not hasattr(wm, name):
            continue
        try:
            value = getattr(wm, name)
        except Exception:
            continue
        serialized = _serialize_value(value)
        if serialized is not None:
            out[name] = serialized
    return out



def _context_scene(context=None):
    try:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
        if scene is not None:
            return scene
    except Exception:
        pass
    try:
        scenes = getattr(getattr(bpy, 'data', None), 'scenes', None)
        if scenes is not None and len(scenes) > 0:
            return scenes[0]
    except Exception:
        pass
    return None


def _context_wm(context=None):
    try:
        return getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
    except Exception:
        return None


def _scene_pointer(context=None) -> int:
    try:
        scene = _context_scene(context)
        return int(scene.as_pointer()) if scene is not None else 0
    except Exception:
        return 0


def _ensure_initial_structured_rows(context, data: dict[str, Any]) -> bool:
    """Create safe first-run rows for both editable render lists.

    Queue and Variant are first-class N-panel settings, but Blender exposes a
    CollectionProperty's row schema only after at least one row exists.  A
    clean install therefore starts with one useful Variant plus one disabled
    Queue draft.  The migration marker is written to the canonical JSON so an
    explicit user deletion remains authoritative on every later restart and
    scene change; defaults are never recreated after that first migration.
    """
    if not isinstance(data, dict):
        return False
    try:
        if int(data.get(_STRUCTURED_DEFAULTS_KEY, 0) or 0) >= _STRUCTURED_DEFAULTS_VERSION:
            return False
    except Exception:
        pass
    scene = _context_scene(context)
    if scene is None:
        return False
    scene_collections = data.get('scene_collections')
    if not isinstance(scene_collections, dict):
        scene_collections = {}
        data['scene_collections'] = scene_collections

    changed = False
    camera_name = ''
    view_layer_name = ''
    try:
        camera = getattr(scene, 'camera', None)
        camera_name = str(getattr(camera, 'name', '') or '')
    except Exception:
        camera_name = ''
    try:
        view_layer = getattr(context, 'view_layer', None) if context is not None else getattr(bpy.context, 'view_layer', None)
        view_layer_name = str(getattr(view_layer, 'name', '') or '')
    except Exception:
        view_layer_name = ''

    try:
        variants = getattr(scene, 'srr_variants', None)
        saved_variants = scene_collections.get('srr_variants')
        if variants is not None and not saved_variants and len(variants) == 0:
            variant = variants.add()
            variant.name = 'Default'
            from .translation import localize_pair
            variant.description = localize_pair('シーンの最初の状態', 'Initial scene state')
            variant.enabled = True
            variant.camera_name = camera_name
            variant.view_layer_name = view_layer_name
            changed = True
    except Exception:
        pass

    try:
        queue = getattr(scene, 'srr_queue', None)
        saved_queue = scene_collections.get('srr_queue')
        if queue is not None and not saved_queue and len(queue) == 0:
            item = queue.add()
            item.enabled = False
            item.source_mode = 'PAIR'
            item.camera_name = camera_name
            item.view_layer_name = view_layer_name
            item.variant_name = ''
            item.label = 'Current Scene (Disabled)'
            changed = True
    except Exception:
        pass

    data[_STRUCTURED_DEFAULTS_KEY] = _STRUCTURED_DEFAULTS_VERSION
    return changed


def apply_context(context=None, *, force: bool = False) -> None:
    global _LOADING, _LAST_SCENE_POINTER, _SCENE_RESTORE_PENDING
    if _LOADING:
        return
    data = _load_data()
    scene = _context_scene(context)
    wm = _context_wm(context)
    scene_id = id(scene) if scene is not None else 0
    wm_id = id(wm) if wm is not None else 0
    if not force and scene_id in _APPLIED_SCENES and wm_id in _APPLIED_WMS:
        return

    _LOADING = True
    try:
        if scene is not None:
            scene_applied = False
            scene_groups = data.get('scene_groups', {})
            if isinstance(scene_groups, dict):
                for name in _SCENE_GROUPS:
                    if hasattr(scene, name) and name in scene_groups:
                        target = getattr(scene, name, None)
                        stored = scene_groups.get(name)
                        if name == 'overscan_settings' and isinstance(stored, dict):
                            # Its recovery values belong to the saved shot. A global UI
                            # preference cannot identify which file or camera they describe.
                            stored = dict(stored)
                            for field in ('original_frame', 'edited_camera'):
                                stored.pop(field, None)
                            if getattr(target, 'original_frame', ''):
                                for field in ('mode', 'percentage', 'extra_pixels', 'specific_x_resolution'):
                                    stored.pop(field, None)
                        _apply_group(target, stored)
                        scene_applied = True
            # Explicit per-element choices are authoritative.  Older payloads
            # may contain those booleans while their hidden migration marker is
            # still false; leaving it false lets the legacy preset initializer
            # overwrite every restored re_* switch immediately afterwards.
            try:
                saved_render_settings = scene_groups.get('srr_settings', {}) if isinstance(scene_groups, dict) else {}
                settings_obj = getattr(scene, 'srr_settings', None)
                if (
                    settings_obj is not None
                    and isinstance(saved_render_settings, dict)
                    and any(str(key).startswith('re_') for key in saved_render_settings)
                    and (
                        saved_render_settings.get('render_elements_items_initialized', True)
                        or any(bool(value) for key, value in saved_render_settings.items() if str(key).startswith('re_'))
                    )
                    and hasattr(settings_obj, 'render_elements_items_initialized')
                ):
                    settings_obj.render_elements_items_initialized = True
                    scene_applied = True
            except Exception:
                pass
            try:
                settings_obj = getattr(scene, 'srr_settings', None)
                saved_group = scene_groups.get('srr_settings', {}) if isinstance(scene_groups, dict) else {}
                if settings_obj is not None and hasattr(settings_obj, 'n_panel_state_save'):
                    saved_value = saved_group.get('n_panel_state_save', data.get('n_panel_state_save_enabled', True))
                    setattr(settings_obj, 'n_panel_state_save', _coerce_saved_bool(saved_value, True))
                    scene_applied = True
            except Exception:
                pass
            scene_collections = data.get('scene_collections', {})
            if isinstance(scene_collections, dict):
                for name in _SCENE_COLLECTIONS:
                    if hasattr(scene, name) and name in scene_collections:
                        _apply_collection(getattr(scene, name, None), scene_collections.get(name))
                        scene_applied = True
            if _ensure_initial_structured_rows(context, data):
                scene_applied = True
            scene_values = data.get('scene_values', {})
            if isinstance(scene_values, dict) and scene_values:
                _apply_named_values(scene, scene_values, _SCENE_VALUES)
                scene_applied = True
            if scene_applied:
                _remember_applied_pointer(_APPLIED_SCENES, scene_id)
        if wm is not None:
            wm_groups = data.get('wm_groups', {})
            wm_applied = False
            wm_missing_saved_group = False
            if isinstance(wm_groups, dict):
                for name in _WM_GROUPS:
                    if name == 'smart_render_suite_runtime_prefs':
                        # Legacy nested runtime settings are imported below into
                        # direct WindowManager properties. Do not touch the old
                        # PointerProperty, because failed installs can leave it
                        # in an invalid RNA state.
                        continue
                    if hasattr(wm, name) and name in wm_groups:
                        saved_group = wm_groups.get(name)
                        _apply_group(getattr(wm, name, None), saved_group)
                        if name == 'profiler' and isinstance(saved_group, dict) and 'report_mode' in saved_group:
                            # Render Profiler stores this custom EnumProperty in
                            # a module-level backing value. Re-registering the
                            # lazy module resets that Python value, while the
                            # runtime-toggle proof may change it to VIEWPORT.
                            # Replay the canonical JSON value explicitly after
                            # the PropertyGroup exists. Runtime activation still
                            # consults the separate always-on toggle, so a saved
                            # VIEWPORT/RENDER preference remains fully dormant
                            # while report_enabled is false.
                            try:
                                from .profiler import properties as _profiler_properties
                                _profiler_properties.restore_report_mode(
                                    saved_group.get('report_mode'),
                                    sync_runtime=True,
                                )
                            except Exception:
                                pass
                        wm_applied = True
                    elif name in wm_groups:
                        # A lazily registered preference group is not available
                        # yet.  Do not mark this WindowManager fully applied;
                        # the loader's post-registration replay must still run.
                        wm_missing_saved_group = True
            wm_values = data.get('wm_values', {})
            if isinstance(wm_values, dict):
                _apply_wm_runtime_values(wm, wm_values)
                wm_applied = True
            if wm_applied and not wm_missing_saved_group:
                _remember_applied_pointer(_APPLIED_WMS, wm_id)
            else:
                _APPLIED_WMS.discard(wm_id)
        # Import older root AddonPreferences or legacy nested runtime values into
        # the direct WindowManager runtime settings once.
        try:
            wm_groups = data.get('wm_groups', {})
            legacy_values = data.get('addon_preferences', {})
            if wm is not None and isinstance(wm_groups, dict):
                nested = wm_groups.get('smart_render_suite_runtime_prefs')
                if isinstance(nested, dict):
                    _apply_wm_runtime_values(wm, nested)
            if wm is not None and isinstance(legacy_values, dict):
                _apply_wm_runtime_values(wm, legacy_values)
        except Exception:
            pass
        try:
            from . import controls
            disable_replaced = getattr(controls, 'disable_on_demand_replaced_runtimes', None)
            if callable(disable_replaced):
                disable_replaced(context, save=False)
            controls.enforce_known_controls(context, load_missing=False, suppress_transform_updates=True)
        except Exception:
            pass
    finally:
        _LOADING = False
    _LAST_SCENE_POINTER = _scene_pointer(context)
    _SCENE_RESTORE_PENDING = False




def _collect_loaded_tools() -> list[str]:
    aliases: list[str] = []
    try:
        from . import loader
        records = loader.get_records()
    except Exception:
        return aliases
    for record in records or []:
        try:
            if str(record.get('status') or '') != 'loaded':
                continue
            spec = record.get('spec') or {}
            alias = str(spec.get('alias') or '').strip()
            if alias and alias not in aliases:
                aliases.append(alias)
        except Exception:
            continue
    return aliases


def get_saved_loaded_tools() -> list[str]:
    """Return the last persisted integrated-tool aliases in stable order."""
    data = _load_data()
    raw = data.get('loaded_tools', [])
    aliases: list[str] = []
    if isinstance(raw, (list, tuple)):
        for item in raw:
            alias = str(item or '').strip()
            if alias and alias not in aliases:
                aliases.append(alias)
    return aliases


def _store_loaded_tools_snapshot(data: dict[str, Any]) -> None:
    current = _collect_loaded_tools()
    previous = data.get('loaded_tools', [])
    has_previous = isinstance(previous, (list, tuple)) and any(str(item or '').strip() for item in previous)
    if current or not has_previous:
        data['loaded_tools'] = current


def snapshot_context(context=None, *, force: bool = False, _allow_disabled_once: bool = False) -> bool:
    global _LAST_SIGNATURE, _LAST_SAVE_TIME, _SCENE_RESTORE_PENDING
    if _REGISTRATION_GUARD or _LOADING or not _REGISTERED:
        return False
    if not _allow_disabled_once and not is_npanel_state_save_enabled(context):
        return False
    pointer = _scene_pointer(context)
    if _LAST_SCENE_POINTER and pointer and pointer != _LAST_SCENE_POINTER:
        _SCENE_RESTORE_PENDING = True
        return False
    now = time.monotonic()

    data = _load_data()
    scene = _context_scene(context)
    wm = _context_wm(context)
    if scene is not None:
        previous_scene_groups = data.get('scene_groups', {}) if isinstance(data.get('scene_groups'), dict) else {}
        scene_groups: dict[str, Any] = {}
        for name in _SCENE_GROUPS:
            if hasattr(scene, name):
                values = _serialize_group(getattr(scene, name, None))
                _preserve_unresolved_pointer_records(
                    values,
                    previous_scene_groups.get(name, {}),
                )
                _preserve_unknown_group_values(
                    values,
                    previous_scene_groups.get(name, {}),
                    getattr(scene, name, None),
                )
                if values:
                    scene_groups[name] = values
        # Lazy integrated tools may not have registered their PropertyGroup on
        # the current scene yet.  Retain those file-backed groups until the tool
        # materializes and apply_context can replay them; a startup snapshot must
        # never erase a valid saved selector merely because its RNA is late.
        for name, values in previous_scene_groups.items():
            if name not in scene_groups and isinstance(values, dict):
                scene_groups[name] = values
        data['scene_groups'] = scene_groups

        scene_collections: dict[str, Any] = {}
        for name in _SCENE_COLLECTIONS:
            if hasattr(scene, name):
                items = _serialize_collection(getattr(scene, name, None))
                # Empty is an intentional, portable value.  Persist it
                # explicitly so removing the final row survives both restart
                # and scene changes instead of resurrecting stale rows.
                scene_collections[name] = items
        data['scene_collections'] = scene_collections
        data['scene_values'] = _serialize_named_values(scene, _SCENE_VALUES)
        try:
            settings_obj = getattr(scene, 'srr_settings', None)
            if settings_obj is not None and hasattr(settings_obj, 'n_panel_state_save'):
                data['n_panel_state_save_enabled'] = bool(getattr(settings_obj, 'n_panel_state_save', True))
        except Exception:
            pass
    if wm is not None:
        previous_wm_groups = data.get('wm_groups', {}) if isinstance(data.get('wm_groups'), dict) else {}
        wm_groups: dict[str, Any] = {}
        for name in _WM_GROUPS:
            if name == 'smart_render_suite_runtime_prefs':
                continue
            if hasattr(wm, name):
                values = _serialize_group(getattr(wm, name, None))
                _preserve_unresolved_pointer_records(
                    values,
                    previous_wm_groups.get(name, {}),
                )
                _preserve_unknown_group_values(
                    values,
                    previous_wm_groups.get(name, {}),
                    getattr(wm, name, None),
                )
                if values:
                    wm_groups[name] = values
        # Lazy WindowManager PropertyGroups (for example Render Names and the
        # Profiler) may not exist during core startup.  Retain their canonical
        # records exactly as Scene groups are retained above; otherwise the
        # first finite startup snapshot silently erases them from disk.
        for name, values in previous_wm_groups.items():
            if name not in wm_groups and isinstance(values, dict):
                wm_groups[name] = values
        data['wm_groups'] = wm_groups
        data['wm_values'] = _serialize_wm_runtime_values(wm)
    data['addon_preferences'] = {}
    _store_loaded_tools_snapshot(data)

    _scrub_on_demand_replaced_always_on(data)

    # Mirror currently loaded known always-on owner properties into the durable
    # central switch store.  Unloaded entries keep their saved value and remain
    # disabled without importing their tool.
    try:
        from . import controls
        for spec in controls.known_always_on_specs():
            alias = str(spec.get('alias') or '').strip()
            prop_name = str(spec.get('prop') or '').strip()
            if alias and prop_name:
                # The central proxy is authoritative. Lazy tool properties may
                # intentionally remain true after the proxy is switched OFF so
                # their UI choice is remembered, but that must never reactivate
                # handlers or overwrite the saved always-on state at shutdown.
                value = get_known_always_on(alias, prop_name, False)
                set_known_always_on(alias, prop_name, bool(value), save=False)
    except Exception:
        pass


    try:
        from . import feature_toggle
        export_feature_state = getattr(feature_toggle, 'export_state', None)
        load_feature_state = getattr(feature_toggle, '_load_state', None)
        state = export_feature_state() if callable(export_feature_state) else (load_feature_state() if callable(load_feature_state) else {})
        if isinstance(state, dict):
            data['feature_toggles'] = {str(alias): {str(key): bool(value) for key, value in dict(values).items()} for alias, values in state.items() if isinstance(values, dict)}
    except Exception:
        pass

    try:
        signature = json.dumps(data, ensure_ascii=False, sort_keys=True)
    except Exception:
        signature = str(time.time())
    if not force and signature == _LAST_SIGNATURE:
        _LAST_SAVE_TIME = now
        return True
    if not _write_data(data, allow_disabled_once=_allow_disabled_once):
        return False
    _LAST_SIGNATURE = signature
    _LAST_SAVE_TIME = now
    return True



def _schedule_external_config_snapshot(context=None, *, force: bool = False, delay: float = 0.45) -> None:
    """Schedule a one-shot external JSON save after an actual user change.

    Earlier builds used a permanent autosave timer.  That timer woke the main
    thread during viewport navigation even when the user was only orbiting,
    panning, or zooming the 3D View.  This function is event-driven: RNA
    msgbus/update callbacks call it only after a Smart Render setting changes.
    """
    del delay
    global _CHANGE_SAVE_TIMER, _CHANGE_SAVE_PENDING_FORCE, _LAST_CHANGE_TIME
    if _LOADING or not _REGISTERED:
        return
    if not is_npanel_state_save_enabled(context):
        return
    _cancel_change_save_timer()
    try:
        _LAST_CHANGE_TIME = time.monotonic()
    except Exception:
        _LAST_CHANGE_TIME = 0.0
    snapshot_context(context or getattr(bpy, 'context', None), force=bool(force))


def _cancel_preview_refresh() -> None:
    try:
        from . import preview_cache
        preview_cache.cancel_refresh()
    except Exception:
        pass


def _cancel_change_save_timer() -> None:
    global _CHANGE_SAVE_TIMER, _CHANGE_SAVE_PENDING_FORCE
    timer = _CHANGE_SAVE_TIMER
    _CHANGE_SAVE_TIMER = None
    _CHANGE_SAVE_PENDING_FORCE = False
    if not callable(timer):
        return
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if timers.is_registered(timer):
            timers.unregister(timer)
    except Exception:
        pass


def _on_persistent_rna_change(*_args) -> None:
    try:
        context = getattr(bpy, 'context', None)
        scene = _context_scene(context)
        _invalidate_preview_snapshot(scene)
        if scene is not None and id(scene) not in _APPLIED_SCENES:
            _on_active_scene_changed()
        _schedule_external_config_snapshot(context, force=False)
    except Exception:
        pass


def _on_active_scene_changed() -> None:
    """Restore the new active Scene through an event-only subscription."""
    context = getattr(bpy, 'context', None)
    scene = _context_scene(context)
    if scene is not None:
        _APPLIED_SCENES.discard(id(scene))
    apply_context(context, force=True)
    # Integrated Scene PropertyGroup instances may differ after the switch.
    _register_change_subscriptions()


def _valid_msgbus_property_names(rna_owner: Any) -> list[str]:
    names: list[str] = []
    try:
        props = getattr(getattr(rna_owner, 'bl_rna', None), 'properties', None)
        if props is not None:
            for prop in props:
                identifier = str(getattr(prop, 'identifier', '') or '')
                if identifier and not _should_skip_name(identifier):
                    names.append(identifier)
    except Exception:
        pass
    seen: set[str] = set()
    result: list[str] = []
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        result.append(name)
    return result


def _subscribe_msgbus_key(key) -> None:
    try:
        subscribe = getattr(getattr(bpy, 'msgbus', None), 'subscribe_rna', None)
        if callable(subscribe):
            subscribe(key=key, owner=_MSGBUS_OWNER, args=(), notify=_on_persistent_rna_change)
    except Exception:
        pass


def _runtime_setting_types(*roots: Any) -> tuple[type, ...]:
    """Discover loaded nested setting row types without PropertyRNA.fixed_type."""
    pending = [root for root in roots if root is not None]
    seen_objects: set[int] = set()
    seen_types: set[type] = set()
    while pending and len(seen_objects) < 512:
        obj = pending.pop()
        marker = id(obj)
        if marker in seen_objects:
            continue
        seen_objects.add(marker)
        try:
            if isinstance(obj, bpy.types.ID):
                continue
        except Exception:
            pass
        cls = type(obj)
        if hasattr(obj, 'bl_rna'):
            seen_types.add(cls)
        for prop_name in _iter_rna_property_names(obj):
            try:
                value = getattr(obj, prop_name)
            except Exception:
                continue
            if value is None or isinstance(value, _PRIMITIVE_TYPES):
                continue
            try:
                if isinstance(value, bpy.types.ID):
                    continue
            except Exception:
                pass
            if hasattr(value, 'bl_rna') and not hasattr(value, '__iter__'):
                pending.append(value)
                continue
            try:
                for item in list(value)[:128]:
                    if item is not None and hasattr(item, 'bl_rna'):
                        pending.append(item)
            except Exception:
                pass
    return tuple(sorted(seen_types, key=lambda item: item.__name__))


def _register_change_subscriptions() -> None:
    """Subscribe to Smart Render settings changes without using idle polling."""
    try:
        clear = getattr(getattr(bpy, 'msgbus', None), 'clear_by_owner', None)
        if callable(clear):
            clear(_MSGBUS_OWNER)
    except Exception:
        pass
    # Keep only the active-Scene notification while continuous N-panel saving
    # is disabled.  This preserves scene-switch restoration but removes the
    # hundreds of property callbacks that otherwise run during normal editing.
    if not is_npanel_state_save_enabled(getattr(bpy, 'context', None)):
        _subscribe_msgbus_key((bpy.types.Window, 'scene'))
        return
    try:
        from . import state as _state
        classes = (
            getattr(_state, 'SRR_Settings', None),
            getattr(_state, 'SRR_QueueItem', None),
            getattr(_state, 'SRR_VariantItem', None),
        )
        for cls in classes:
            if not isinstance(cls, type):
                continue
            for prop_name in _valid_msgbus_property_names(cls):
                _subscribe_msgbus_key((cls, prop_name))
    except Exception:
        pass
    # Scene collection/index values and direct WindowManager runtime values.
    for prop_name in tuple(_SCENE_VALUES) + tuple(_SCENE_COLLECTIONS):
        try:
            if hasattr(bpy.types.Scene, prop_name):
                _subscribe_msgbus_key((bpy.types.Scene, prop_name))
        except Exception:
            pass
    for prop_name in _WM_VALUES:
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                _subscribe_msgbus_key((bpy.types.WindowManager, prop_name))
        except Exception:
            pass
    _subscribe_msgbus_key((bpy.types.Window, 'scene'))
    # Integrated Scene property groups are loaded lazily. Subscribe to every
    # currently available settings class; loader.refresh_change_subscriptions()
    # repeats this after a new tool is loaded.
    try:
        scene = _context_scene(getattr(bpy, 'context', None))
        roots = [getattr(scene, group_name, None) for group_name in _SCENE_GROUPS] if scene is not None else []
        roots.extend(getattr(scene, name, None) for name in _SCENE_COLLECTIONS) if scene is not None else None
        for cls in _runtime_setting_types(*roots):
            for prop_name in _valid_msgbus_property_names(cls):
                _subscribe_msgbus_key((cls, prop_name))
    except Exception:
        pass
    # Already-loaded integrated tool preference groups are also event-driven.
    try:
        wm = _context_wm(getattr(bpy, 'context', None))
        roots = [getattr(wm, group_name, None) for group_name in _WM_GROUPS] if wm is not None else []
        for cls in _runtime_setting_types(*roots):
            for prop_name in _valid_msgbus_property_names(cls):
                _subscribe_msgbus_key((cls, prop_name))
    except Exception:
        pass


def refresh_change_subscriptions() -> None:
    if not _REGISTERED:
        return
    _register_change_subscriptions()


def _unregister_change_subscriptions() -> None:
    try:
        clear = getattr(getattr(bpy, 'msgbus', None), 'clear_by_owner', None)
        if callable(clear):
            clear(_MSGBUS_OWNER)
    except Exception:
        pass
    _cancel_change_save_timer()
    _cancel_preview_refresh()

def _autosave_context_timer():
    # Compatibility no-op.  Continuous idle polling was removed because it can
    # wake Blender's main thread during 3D View orbit/pan/zoom.  N-panel
    # persistence is now msgbus/update driven and uses one-shot debounce timers
    # only after real Smart Render setting changes.
    return None


def _register_autosave_timer() -> None:
    global _AUTOSAVE_TIMER
    _AUTOSAVE_TIMER = None
    _register_change_subscriptions()


def _unregister_autosave_timer() -> None:
    _unregister_change_subscriptions()


def _deferred_startup_apply_timer():
    global _STARTUP_APPLY_TIMER, _STARTUP_APPLY_ATTEMPTS
    if not _REGISTERED or bool(getattr(getattr(bpy, 'app', None), 'is_exiting', False)):
        _STARTUP_APPLY_TIMER = None
        return None
    _STARTUP_APPLY_ATTEMPTS += 1
    if _STARTUP_APPLY_ATTEMPTS > _STARTUP_APPLY_MAX_ATTEMPTS:
        _STARTUP_APPLY_TIMER = None
        return None
    ctx = getattr(bpy, 'context', None)
    try:
        scene = _context_scene(ctx)
        if scene is None or not hasattr(scene, 'srr_settings'):
            return 0.10 if _STARTUP_APPLY_ATTEMPTS < _STARTUP_APPLY_MAX_ATTEMPTS else None
        apply_context(ctx, force=True)
        # Only mirror back immediately when the user opted into continuous
        # N-panel persistence.  When disabled, the restored values stay in
        # memory and are written at explicit save/close boundaries.
        snapshot_context(ctx, force=is_npanel_state_save_enabled(ctx))
    except Exception:
        if _STARTUP_APPLY_ATTEMPTS < _STARTUP_APPLY_MAX_ATTEMPTS:
            return 0.25
    _STARTUP_APPLY_TIMER = None
    return None


def _register_startup_apply_timer() -> None:
    global _STARTUP_APPLY_TIMER, _STARTUP_APPLY_ATTEMPTS
    _unregister_startup_apply_timer()
    _STARTUP_APPLY_ATTEMPTS = 0
    _STARTUP_APPLY_TIMER = _deferred_startup_apply_timer
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        _STARTUP_APPLY_TIMER = None
        return
    try:
        timers.register(_STARTUP_APPLY_TIMER, first_interval=0.0, persistent=False)
    except TypeError:
        try:
            timers.register(_STARTUP_APPLY_TIMER, first_interval=0.0)
        except Exception:
            _STARTUP_APPLY_TIMER = None
    except Exception:
        _STARTUP_APPLY_TIMER = None


def _unregister_startup_apply_timer() -> None:
    global _STARTUP_APPLY_TIMER, _STARTUP_APPLY_ATTEMPTS
    timer = _STARTUP_APPLY_TIMER
    _STARTUP_APPLY_TIMER = None
    _STARTUP_APPLY_ATTEMPTS = 0
    if not callable(timer):
        return
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if timers.is_registered(timer):
            timers.unregister(timer)
    except Exception:
        pass



@persistent
def _undo_redo_post_handler(_dummy=None):
    try:
        ctx = getattr(bpy, 'context', None)
        apply_context(ctx)
        snapshot_context(ctx, force=is_npanel_state_save_enabled(ctx))
    except Exception:
        pass


@persistent
def _load_pre_handler(_dummy=None):
    global _LOADING, _SCENE_RESTORE_PENDING
    # ``load_pre`` is not a persistence boundary, but it is the start of a
    # critical restore boundary.  Smart Render's earlier load_post normalizer
    # may initialise newly loaded Scene RNA before this module's load_post
    # handler runs.  Keep all property update/msgbus save callbacks muted across
    # that interval so defaults from the incoming .blend cannot replace the
    # authoritative external JSON before it is replayed.
    _LOADING = True
    _SCENE_RESTORE_PENDING = True
    _cancel_change_save_timer()
    return None


@persistent
def _load_post_handler(_dummy=None):
    global _LOADING
    try:
        # Release the file-load guard installed in load_pre, then replay the
        # canonical payload while apply_context manages its own shorter guard.
        _LOADING = False
        _APPLIED_SCENES.clear()
        _APPLIED_WMS.clear()
        _invalidate_preview_snapshot()
        ctx = getattr(bpy, 'context', None)
        apply_context(ctx, force=True)
        snapshot_context(ctx, force=is_npanel_state_save_enabled(ctx))
        # Integrated tools from this and other suites may create WindowManager
        # or Scene RNA later in the same load_post pass.  Queue the existing
        # finite startup replay so those defaults cannot overwrite the canonical
        # Smart_Render_Suite.json values.
        _register_startup_apply_timer()
        _register_change_subscriptions()
    except Exception:
        _LOADING = False
        # Persistent settings must never break file loading.  Individual fields
        # are already best-effort restored and will be retried by the autosave
        # timer after Blender finishes context initialization.
        pass


@persistent
def _save_pre_handler(_dummy=None):
    try:
        ctx = getattr(bpy, 'context', None)
        # Blend-file save and preference-save paths are explicit save triggers.
        # When N-panel State Save is disabled, ordinary edits stay in memory, but
        # save/close boundaries must still persist pending N-panel settings.
        snapshot_context(ctx, force=True)
    except Exception:
        pass


def _remove_stale_registered_handlers(handlers) -> None:
    if handlers is None:
        return
    targets = (
        ('load_pre', '_load_pre_handler'),
        ('load_factory_startup_pre', '_load_pre_handler'),
        ('load_post', '_load_post_handler'),
        ('load_factory_startup_post', '_load_post_handler'),
        ('save_pre', '_save_pre_handler'),
        ('undo_post', '_undo_redo_post_handler'),
        ('redo_post', '_undo_redo_post_handler'),
    )
    for list_name, fn_name in targets:
        try:
            seq = getattr(handlers, list_name, None)
            if seq is None:
                continue
            for handler in tuple(seq):
                try:
                    name = str(getattr(handler, '__name__', '') or '')
                    module = str(getattr(handler, '__module__', '') or '')
                except Exception:
                    continue
                if name == fn_name and module == __name__:
                    current = (_load_pre_handler if fn_name == '_load_pre_handler' else (_load_post_handler if fn_name == '_load_post_handler' else (_save_pre_handler if fn_name == '_save_pre_handler' else _undo_redo_post_handler)))
                    if handler is not current:
                        try:
                            seq.remove(handler)
                        except Exception:
                            pass
        except Exception:
            pass


def install() -> None:
    global _REGISTERED
    if _REGISTERED:
        apply_context(getattr(bpy, 'context', None), force=True)
        _register_autosave_timer()
        return
    _load_data()
    apply_context(getattr(bpy, 'context', None), force=True)
    try:
        from . import controls
        disable_replaced = getattr(controls, 'disable_on_demand_replaced_runtimes', None)
        if callable(disable_replaced):
            disable_replaced(getattr(bpy, 'context', None), save=False)
    except Exception:
        pass
    _REGISTERED = True
    # Replay once more after the add-on is marked registered. During extension
    # enable Blender can expose WindowManager before the active Scene; this
    # second pass restores scene-backed N-panel state before the first snapshot.
    try:
        _APPLIED_SCENES.clear()
        _APPLIED_WMS.clear()
        apply_context(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    # Ensure config/Smart_Render_Suite/Smart_Render_Suite.json exists without
    # harvesting a still-default startup scene.  In Blender 5.1 the extension can
    # be enabled before the active Scene is fully exposed; forcing a snapshot in
    # that window erases saved N-panel state.  The deferred apply timer replays
    # the JSON as soon as scene.srr_settings is available.
    try:
        _write_data(_load_data())
    except Exception:
        pass
    _register_startup_apply_timer()
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    _remove_stale_registered_handlers(handlers)
    if handlers is not None:
        try:
            load_pre_handlers = getattr(handlers, 'load_pre', None)
            if load_pre_handlers is not None and _load_pre_handler not in load_pre_handlers:
                load_pre_handlers.append(_load_pre_handler)
        except Exception:
            pass
        try:
            factory_pre_handlers = getattr(handlers, 'load_factory_startup_pre', None)
            if factory_pre_handlers is not None and _load_pre_handler not in factory_pre_handlers:
                factory_pre_handlers.append(_load_pre_handler)
        except Exception:
            pass
        try:
            if _load_post_handler not in handlers.load_post:
                handlers.load_post.append(_load_post_handler)
        except Exception:
            pass
        try:
            factory_handlers = getattr(handlers, 'load_factory_startup_post', None)
            if factory_handlers is not None and _load_post_handler not in factory_handlers:
                factory_handlers.append(_load_post_handler)
        except Exception:
            pass
        # Event-driven updates already commit while saving is enabled. When it
        # is disabled, save_pre must not become a hidden write boundary. Remove
        # any handler retained by a live extension reload and do not add one.
        try:
            save_pre_handlers = getattr(handlers, 'save_pre', None)
            while save_pre_handlers is not None and _save_pre_handler in save_pre_handlers:
                save_pre_handlers.remove(_save_pre_handler)
        except Exception:
            pass
        # Settings are captured by property updates and load/save boundaries;
        # global undo/redo residents are unnecessary while runtimes are OFF.
        for _name in ('undo_post', 'redo_post'):
            try:
                _seq = getattr(handlers, _name, None)
                while _seq is not None and _undo_redo_post_handler in _seq:
                    _seq.remove(_undo_redo_post_handler)
            except Exception:
                pass
    _register_autosave_timer()


def begin_registration() -> None:
    """Freeze the canonical payload and block default-RNA snapshots."""
    global _DATA_CACHE, _REGISTRATION_GUARD, _REGISTRATION_PAYLOAD
    if _REGISTRATION_GUARD:
        return
    _DATA_CACHE = None
    data = _load_data()
    try:
        _REGISTRATION_PAYLOAD = json.loads(json.dumps(data, ensure_ascii=False))
    except Exception:
        _REGISTRATION_PAYLOAD = dict(data)
    _REGISTRATION_GUARD = True


def end_registration(context=None) -> None:
    """Replay the frozen payload after all eagerly registered RNA exists."""
    global _DATA_CACHE, _REGISTRATION_GUARD, _REGISTRATION_PAYLOAD
    if not _REGISTRATION_GUARD:
        return
    try:
        if isinstance(_REGISTRATION_PAYLOAD, dict):
            _DATA_CACHE = _REGISTRATION_PAYLOAD
        _APPLIED_SCENES.clear()
        _APPLIED_WMS.clear()
        apply_context(context or getattr(bpy, 'context', None), force=True)
    finally:
        _REGISTRATION_PAYLOAD = None
        _REGISTRATION_GUARD = False
    # All RNA owned by this registration boundary now exists and the guard has
    # been released, so complete the final replay synchronously.  Scheduling a
    # second one-shot here allowed nested lazy-tool registration to keep
    # replacing it during re-enable, leaving a timer in an otherwise all-OFF
    # suite.
    _post_register_restore_once()


def reload_and_apply_canonical_settings(context=None) -> None:
    """Reload the committed JSON and replay it after lazy RNA registration.

    A frozen in-memory registration payload protects the core registration
    boundary, but a bundled tool can run legacy initializers while creating its
    own Scene/WindowManager groups.  Re-reading the committed file after that
    boundary makes the external configuration authoritative and also resolves
    saved Blender-ID pointers only after their RNA owners exist.
    """
    global _DATA_CACHE
    if _REGISTRATION_GUARD:
        return
    _DATA_CACHE = None
    _APPLIED_SCENES.clear()
    _APPLIED_WMS.clear()
    _load_data()
    apply_context(context or getattr(bpy, 'context', None), force=True)
    _register_change_subscriptions()


def _post_register_restore_once():
    try:
        _APPLIED_SCENES.clear()
        _APPLIED_WMS.clear()
        apply_context(getattr(bpy, 'context', None), force=True)
        # Commit a first-run structured-row migration only after the guarded
        # registration replay has completed.  Subsequent calls are signature
        # stable and therefore perform no redundant disk write.
        snapshot_context(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    return None


def uninstall() -> None:
    global _REGISTERED
    try:
        ctx = getattr(bpy, 'context', None)
        scene = _context_scene(ctx)
        # If startup exited before the deferred replay ran, apply the external
        # JSON once before the final forced snapshot.  When the scene was already
        # applied, do not replay here, so pending edits with N-panel State Save
        # disabled are preserved and written at close time as requested.
        if scene is not None and id(scene) not in _APPLIED_SCENES:
            apply_context(ctx, force=True)
        snapshot_context(ctx, force=True)
    except Exception:
        pass
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    try:
        if bpy.app.timers.is_registered(_post_register_restore_once):
            bpy.app.timers.unregister(_post_register_restore_once)
    except Exception:
        pass
    _unregister_startup_apply_timer()
    _unregister_autosave_timer()
    try:
        from . import preview_cache
        preview_cache.clear_all()
    except Exception:
        pass
    if handlers is not None:
        for list_name, fn in (('load_pre', _load_pre_handler), ('load_factory_startup_pre', _load_pre_handler), ('load_post', _load_post_handler), ('load_factory_startup_post', _load_post_handler), ('save_pre', _save_pre_handler), ('undo_post', _undo_redo_post_handler), ('redo_post', _undo_redo_post_handler)):
            try:
                seq = getattr(handlers, list_name)
                if fn in seq:
                    seq.remove(fn)
            except Exception:
                pass
    _REGISTERED = False
