from .translation import iface_text
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import contextlib
import hashlib
import importlib
import io
import json
import sys
import textwrap
from typing import Any

import bpy

from . import runtime as _runtime, extra_ui, loader as loader, tool_registry as registry
from .tool_catalog import display_name as tool_display_name, display_name_ja as tool_display_name_ja, expanded_prop_name as tool_expanded_prop_name, search_text_blob
from .translation import localize_class_attributes, localize_inline, localize_pair, source_text

_REGISTERED_STATIC_CLASSES: list[type] = []
_REGISTERED_DYNAMIC_CLASSES: list[type] = []
_DYNAMIC_UI_REBUILD_TIMER = None
_DYNAMIC_UI_REBUILD_ACTIVE = False
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}
_SUITE_ROOT_PANEL_IDS: dict[str, str] = {}
_ADDON_PANEL_IDS: dict[str, str] = {}
_IMAGE_EDITOR_PANEL_IDS: dict[str, str] = {}
_NPANEL_AREA_TYPES = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}


def _is_supported_npanel_area(context) -> bool:
    area = getattr(context, 'area', None)
    if area is None:
        # During Blender 5.1 Sidebar rebuilds a partially populated context may be
        # passed to Panel.poll. Treat that context as unsupported so only the
        # concrete VIEW_3D root can appear and duplicate Smart Render roots cannot
        # leak from generated or mirrored panels.
        return False
    return str(getattr(area, 'type', '') or '') in _NPANEL_AREA_TYPES


def _panel_identifier(cls: type) -> str:
    return str(getattr(cls, 'bl_idname', '') or getattr(cls, '__name__', '') or '')


def _image_editor_header_noop(self, _context):
    # Dynamic Image Editor mirrors do not execute original header callbacks.
    # Original callbacks may resolve operators that were not registered yet or
    # may assume a VIEW_3D context; either case can crash Blender's panel header
    # renderer on 5.1/Python 3.13.
    return None


def _base_image_editor_panel_id(parent_id: str) -> str:
    parent_id = str(parent_id or '').strip()
    if parent_id == 'SRR_PT_MAIN_PANEL':
        return 'SRR_IMAGE_PT_MAIN_PANEL'
    if parent_id.startswith('SRR_PT_'):
        return 'SRR_IMAGE_PT_' + parent_id[len('SRR_PT_'):]
    return parent_id + '_IMAGE_EDITOR'


def _image_editor_dynamic_panel_clone(panel_cls: type):
    # Compatibility endpoint retained for callers from older loaded modules.
    # Fixed physical root classes live in ui.py.
    del panel_cls
    return None


def _safe_register_dynamic_panel_with_image_editor_clone(panel_cls: type) -> None:
    del panel_cls
    return None


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SMARTTOOLS_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()


def _txt(ja: str, en: str) -> str:
    return localize_pair(ja, en)


def _sync_persistent_ui_state(context) -> None:
    try:
        from . import settings as _settings
        _settings.apply_context(context)
    except Exception:
        pass


def _draw_lazy_help_button(layout, help_key: str, *, tool_label: str = '') -> None:
    try:
        from .help_operator import draw_help_button
        draw_help_button(layout, str(help_key or ''), tool_label=str(tool_label or ''))
    except Exception:
        pass


def _safe_register_static_class(cls: type) -> None:
    from .rna_safety import ensure_registered_class
    registered = ensure_registered_class(cls)
    _REGISTERED_STATIC_CLASSES.append(registered)


def _safe_register_dynamic_class(cls: type) -> None:
    from .rna_safety import ensure_registered_class
    registered = ensure_registered_class(cls)
    _REGISTERED_DYNAMIC_CLASSES.append(registered)


def _unregister_class_list(classes: list[type]) -> None:
    from .rna_safety import safe_unregister_class
    while classes:
        cls = classes.pop()
        try:
            safe_unregister_class(cls)
        except Exception:
            pass


def _cancel_dynamic_ui_rebuild() -> None:
    global _DYNAMIC_UI_REBUILD_TIMER, _DYNAMIC_UI_REBUILD_ACTIVE
    if callable(_DYNAMIC_UI_REBUILD_TIMER):
        try:
            if bpy.app.timers.is_registered(_DYNAMIC_UI_REBUILD_TIMER):
                bpy.app.timers.unregister(_DYNAMIC_UI_REBUILD_TIMER)
        except Exception:
            pass
    _DYNAMIC_UI_REBUILD_TIMER = None
    _DYNAMIC_UI_REBUILD_ACTIVE = False


def _safe_unregister_registered_classes() -> None:
    _cancel_dynamic_ui_rebuild()
    _unregister_class_list(_REGISTERED_DYNAMIC_CLASSES)
    _unregister_class_list(_REGISTERED_STATIC_CLASSES)
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _IMAGE_EDITOR_PANEL_IDS.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def _clear_dynamic_panel_state() -> None:
    _unregister_class_list(_REGISTERED_DYNAMIC_CLASSES)
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _IMAGE_EDITOR_PANEL_IDS.clear()


def _schedule_dynamic_ui_rebuild() -> None:
    # Records are read synchronously only at explicit load/toggle boundaries.
    _collect_records()


def _rebuild_dynamic_classes() -> None:
    _collect_records()
    # Integrated records are rendered inline by the canonical root body.


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'.{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return False
    try:
        nav = _import_nav_module(module_name)
        fn = getattr(nav, 'is_active', None)
        if callable(fn):
            return bool(fn(context, suite_key))
    except Exception:
        pass
    return False


def suite_panel_context(suite_key: str) -> str:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return 'render'
    try:
        nav = _import_nav_module(module_name)
        value = getattr(nav, '_SMART_TOOLS_CONTEXT', 'RENDER')
        return str(value or 'RENDER').lower()
    except Exception:
        return 'render'


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)

    should_refresh = False
    area = getattr(context, 'area', None) if context is not None else None
    if getattr(area, 'type', None) == 'PROPERTIES':
        should_refresh = True
    else:
        try:
            should_refresh = bool(_smart_tools_hosts_exist())
        except Exception:
            should_refresh = False

    if not should_refresh:
        return

    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass

def _smart_tools_hosts_exist() -> bool:
    for _suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            fn = getattr(nav, '_verified_host_window_keys', None)
            if callable(fn) and bool(fn()):
                return True
        except Exception:
            continue
    return False


def _root_preferences(context=None):
    try:
        from . import preferences as _preferences
        return _preferences.get_runtime_preferences(context)
    except Exception:
        return None


def _tool_list_visible(context=None) -> bool:
    prefs = _root_preferences(context)
    if prefs is None:
        return True
    try:
        return bool(getattr(prefs, 'show_integrated_tools', True))
    except Exception:
        return True


def _tool_search_text(context=None) -> str:
    prefs = _root_preferences(context)
    if prefs is None:
        return ''
    try:
        return str(getattr(prefs, 'search_text', '') or '').strip().lower()
    except Exception:
        return ''


def _record_matches_search(record: dict, context=None) -> bool:
    search_text = _tool_search_text(context)
    if not search_text:
        return True
    spec = dict((record or {}).get('spec') or {})
    alias = str(spec.get('alias') or (record or {}).get('alias') or '').strip()
    if alias and not spec.get('alias'):
        spec['alias'] = alias
    haystack = search_text_blob(spec)
    if alias and alias.lower() not in haystack:
        haystack = f"{haystack} {alias.lower()}".strip()
    return search_text in haystack


def _tool_active_state(alias: str, context=None, *, default: bool = True) -> bool:
    return True

def _root_original_panels(record: dict) -> list[type]:
    items: list[type] = []
    for panel_cls in record.get('panels', ()) or ():
        parent_id = str(getattr(panel_cls, 'bl_parent_id', '') or '').strip()
        if parent_id:
            continue
        if isinstance(panel_cls, type):
            items.append(panel_cls)
    return items


def _child_original_panels(record: dict) -> list[type]:
    items: list[type] = []
    for panel_cls in record.get('panels', ()) or ():
        parent_id = str(getattr(panel_cls, 'bl_parent_id', '') or '').strip()
        if not parent_id:
            continue
        if isinstance(panel_cls, type):
            items.append(panel_cls)
    return items


def _all_original_panels(record: dict) -> list[type]:
    items: list[type] = []
    for panel_cls in record.get('panels', ()) or ():
        if isinstance(panel_cls, type) and panel_cls not in items:
            items.append(panel_cls)
    return items


def _draw_runtime_settings_inline(layout, context, record: dict) -> bool:
    try:
        draw_fn = getattr(extra_ui, 'runtime_settings_draw_for_record', None)
        draw_fn = draw_fn(record) if callable(draw_fn) else None
    except Exception:
        draw_fn = None
    if not callable(draw_fn):
        return False
    try:
        box = layout.box()
        box.label(text=localize_inline('Settings / 設定'), icon='PREFERENCES')
        draw_fn(box, context)
        return True
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_txt('設定を表示できませんでした。', f'Runtime settings draw failed: {exc}'), icon='ERROR')
        return False


def _draw_root_panel_contents_inline(layout, context, record: dict, addon_title: str) -> bool:
    root_panels = _root_original_panels(record)
    if not root_panels:
        return False
    drawn = False
    normalized_title = str(addon_title or '').strip().lower()
    total = len(root_panels)
    for panel_cls in root_panels:
        draw_fn = getattr(panel_cls, 'draw', None)
        if not callable(draw_fn):
            continue
        label = str(getattr(panel_cls, 'bl_label', '') or getattr(panel_cls, '__name__', '') or '').strip()
        section = layout.box()
        if total > 1 or (label and label.lower() != normalized_title):
            section.label(text=label or localize_inline('Main Panel / メインパネル'), icon='OPTIONS')
        try:
            _call_draw(draw_fn, panel_cls, section, context)
            drawn = True
        except Exception as exc:
            section.alert = True
            section.label(text=_txt('パネルを表示できませんでした。', f'Root panel draw failed: {exc}'), icon='ERROR')
    return drawn


def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _status_text(record: dict) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _txt('読み込み済み', 'Loaded')
    if status == 'ready':
        return _txt('待機中', 'Ready')
    if status == 'unsupported_platform':
        return _txt('現在の OS・CPU では無効', 'Unsupported platform')
    if status == 'failed':
        return _txt('読み込み失敗', 'Load failed')
    if status == 'disabled':
        return _txt('上位互換または重複のため統合対象外', 'Superseded or deduplicated')
    return status or _txt('不明', 'Unknown')


def _addon_help_en(spec: dict) -> str:
    name = str(spec.get('display_name') or tool_display_name(spec.get('alias') or '', fallback='Integrated Tool')).strip()
    summary = str(spec.get('summary_en') or spec.get('description') or '').strip()
    usage = str(spec.get('usage_en') or '').strip()
    if summary and usage:
        return f'Function: {summary} How to use: {usage} Legacy side panels and legacy menu injections are removed or hidden so the entry point stays inside Smart Render N-panel.'
    if summary:
        return (
            f'Function: {summary}. How to use: open the migrated child panels or use the quick buttons below. '
            f'Legacy side panels and legacy menu injections are removed or hidden so the entry point stays inside Smart Render N-panel.'
        )
    return (
        f'Function: {name} has been migrated into Smart Render N-panel. How to use: open the migrated child panels or use the quick buttons below. '
        'Legacy side panels and legacy menu injections are removed or hidden.'
    )


def _addon_help_ja(spec: dict) -> str:
    name = str(spec.get('display_name') or tool_display_name(spec.get('alias') or '', fallback='Integrated Tool')).strip()
    summary = str(spec.get('summary_ja') or '').strip()
    usage = str(spec.get('usage_ja') or '').strip()
    if summary and usage:
        return f'機能: {summary} 使い方: {usage} 旧サイドバーや旧メニュー注入は削除または非表示化され、入口は Smart Render Nパネルに集約されています。'
    desc = str(spec.get('description') or '').strip()
    if summary or desc:
        return (
            f'機能: {summary or desc or name} 使い方: 下のクイックボタン、または子パネルを開いて必要な機能を使ってください。'
            '旧サイドバーや旧メニュー注入は削除または非表示化され、入口は Smart Render Nパネルに集約されています。'
        )
    return (
        f'機能: {name} の元機能を Smart Render Nパネル内へ統合しています。使い方: 下のクイックボタン、または子パネルを開いて'
        '必要な機能を使ってください。旧サイドバーや旧メニュー注入は削除または非表示化されています。'
    )


def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Integrated Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside Smart Render N-panel. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command inside Smart Render N-panel. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )


def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or '統合ツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: Smart Render Nパネル内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すと Smart Render Nパネル内の移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    shim_name = f'_SMARTTOOLS_INT_PANEL_SHIM_{ID_FACTORY.token(getattr(panel_cls, "__name__", ""), size=12)}'
    attrs = {}
    for name, value in getattr(panel_cls, '__dict__', {}).items():
        if name.startswith('__'):
            continue
        attrs[name] = value
    shim_cls = type(shim_name, (), attrs)
    shim = shim_cls()
    try:
        shim.layout = layout
    except Exception:
        pass
    for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options'):
        try:
            setattr(shim, name, getattr(panel_cls, name))
        except Exception:
            pass
    try:
        shim.is_popover = False
    except Exception:
        pass
    draw_fn(shim, context)


def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip()
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or menu_id, is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or '').strip() or op_id
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    display_label = localize_inline(label)
    display_desc = localize_inline(desc)
    operator_kwargs = {"text": display_label, "icon": icon}
    if target_kind == 'operator' and str(addon_alias or '') == 'render_pipeline':
        try:
            from . import render_pipeline as _smart_render_icons
            icon_id = max(0, int(_smart_render_icons.icon_value_for_operator(target_id, icon) or 0))
            if icon_id > 0:
                operator_kwargs = {"text": display_label, "icon_value": icon_id}
        except Exception:
            pass
    try:
        op = layout.operator(SMART_RENDER_SUITE_OT_integrated_invoke.bl_idname, **operator_kwargs)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = display_label
        op.target_desc = display_desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=display_label)


def _draw_tool_list(layout, record: dict, compact: bool = False) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=localize_inline('No direct operator or menu entry was found. / 直接呼び出せるオペレーターやメニューが見つかりませんでした。'),
        )
        return

    if menus:
        box = layout.box()
        box.label(text=localize_inline('Menus / メニュー'), icon='MENU_PANEL')
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        box = layout.box()
        box.label(text=localize_inline('Operators / オペレーター'), icon='TOOL_SETTINGS')
        flow = box.grid_flow(row_major=True, columns=1 if compact else 2, even_columns=True, even_rows=False, align=True)
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _ensure_record_loaded(alias: str, *, report=None) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    record = loader.get_record(alias)
    if record is None:
        return None
    status = str(record.get('status') or '')
    if status == 'loaded':
        return record
    record = loader.load_alias(alias, force=False)
    if record is None:
        return None
    if str(record.get('status') or '') != 'loaded' and report is not None:
        excerpt = _trace_excerpt(record.get('error', ''))
        report({'ERROR'}, _txt(f'読み込みに失敗しました: {alias}', excerpt or f'Failed to load: {alias}'))
    _collect_records()
    _schedule_dynamic_ui_rebuild()
    return record


class SMART_RENDER_SUITE_OT_load_integrated_tool(bpy.types.Operator):
    bl_idname = 'smart_render_suite.load_integrated_tool'
    bl_label = "Load Integrated Tool"
    bl_label = source_text('統合ツールを読み込む', 'Load Integrated Tool')
    bl_description = source_text(
        '選択した統合ツールを遅延読み込みし、Smart Render Nパネル内にその操作パネルを表示します。起動時は全ツールを一括読み込みせず、前回Nパネルで読み込んでいたツールだけを保存状態から復元できます。',
        'Lazy-load the selected Smart Render tool and show its controls inside the Smart Render N-panel. Startup does not batch-load every bundled tool; only tools saved as loaded in the N-panel can be restored.',
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    force_reload: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, _context):
        alias = str(self.addon_alias or '').strip()
        if not alias:
            self.report({'WARNING'}, _txt('読み込む統合ツールが指定されていません。', 'No Smart Render tool was specified.'))
            return {'CANCELLED'}
        record = loader.get_record(alias)
        if record is None:
            self.report({'ERROR'}, _txt(f'統合ツールが見つかりません: {alias}', f'Smart Render tool not found: {alias}'))
            return {'CANCELLED'}
        record = loader.load_alias(alias, force=bool(getattr(self, 'force_reload', False)))
        _collect_records()
        _schedule_dynamic_ui_rebuild()
        if record is None or str(record.get('status') or '') != 'loaded':
            excerpt = _trace_excerpt((record or {}).get('error', '') if isinstance(record, dict) else '')
            self.report({'ERROR'}, _txt('統合ツールの読み込みに失敗しました。', excerpt or 'Failed to load the Smart Render tool.'))
            return {'CANCELLED'}
        spec = dict(record.get('spec') or {})
        self.report({'INFO'}, _txt(f'{spec.get("display_name", alias)} を読み込みました。', f'Loaded {spec.get("display_name", alias)}.'))
        return {'FINISHED'}


class SMART_RENDER_SUITE_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'smart_render_suite.show_integrated_tool_info'
    bl_label = "Show Integrated Tool Info"
    bl_label = source_text('統合ツール情報を表示', 'Show Integrated Tool Info')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _txt('不明', 'Unknown')
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _txt(_addon_help_ja(spec), _addon_help_en(spec)),
            f"{_txt('状態', 'Status')}: {status}",
        ]
        if note:
            lines.append(f"{_txt('注記', 'Note')}: {note}")
        return ' '.join(str(line) for line in lines if line)

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _txt('不明', 'Unknown')
        self.report({'INFO'}, iface_text(f"{spec.get('display_name', alias)} - {status}"))
        return {'FINISHED'}


_REPORT_LEVELS = (
    ('Debug', 'DEBUG'),
    ('Info', 'INFO'),
    ('Operator', 'OPERATOR'),
    ('Property', 'PROPERTY'),
    ('Warning', 'WARNING'),
    ('Error', 'ERROR'),
    ('Invalid Input', 'ERROR_INVALID_INPUT'),
    ('Invalid Context', 'ERROR_INVALID_CONTEXT'),
    ('Out of Memory', 'ERROR_OUT_OF_MEMORY'),
)


_RELAYED_OUTPUT = set()


def _print_output_once(line: str) -> None:
    """Pass other output of a nested operator on to stdout, each distinct line once."""
    key = line[:120]
    if key in _RELAYED_OUTPUT or len(_RELAYED_OUTPUT) > 200:
        return
    _RELAYED_OUTPUT.add(key)
    sys.stdout.write(line + '\n')


def _relay_nested_reports(report, captured: str) -> None:
    """Show the reports of an operator that was called from Python.

    Blender writes them to stdout as "<type>: <message>" instead of the screen.
    Any other output goes on to stdout unchanged.
    """
    levels = {}
    for name, level in _REPORT_LEVELS:
        levels[name] = level
        levels[bpy.app.translations.pgettext_rpt(name)] = level
    for line in captured.splitlines():
        head, separator, message = line.partition(': ')
        level = levels.get(head) if separator else None
        if level is None:
            _print_output_once(line)
        elif level != 'DEBUG':
            report({level}, message)


class SMART_RENDER_SUITE_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'smart_render_suite.integrated_tool'
    bl_label = "Integrated Tool"
    bl_label = source_text('統合ツール', 'Integrated Tool')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _txt(
            _target_help_ja(kind, label, desc, is_pie=is_pie),
            _target_help_en(kind, label, desc, is_pie=is_pie),
        )

    def execute(self, _context):
        alias = str(self.addon_alias or '').strip()
        record = _ensure_record_loaded(alias, report=self.report) if alias else None
        if alias and (record is None or str(record.get('status') or '') != 'loaded'):
            return {'CANCELLED'}

        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id:
            self.report({'WARNING'}, _txt('呼び出す統合ツールが指定されていません。', 'No integrated tool target was specified.'))
            return {'CANCELLED'}
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _txt('メニューを開けませんでした。', f'Menu invoke failed: {target_id} ({exc})'))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _txt(f'オペレーターが見つかりません: {target_id}', f'Operator not found: {target_id}'))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            captured = io.StringIO()
            try:
                with contextlib.redirect_stdout(captured):
                    result = op_callable(*args)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
            finally:
                _relay_nested_reports(self.report, captured.getvalue())
        self.report({'ERROR'}, _txt(f'オペレーターの呼び出しに失敗しました: {target_id} ({last_error})', f'Operator invoke failed: {target_id} ({last_error})'))
        return {'CANCELLED'}


def _suite_records_for_draw() -> list[dict[str, Any]]:
    if not _SUITE_RECORDS:
        try:
            _collect_records()
        except Exception:
            pass
    records: list[dict[str, Any]] = []
    for suite_key in registry.SUITE_ORDER:
        records.extend(_SUITE_RECORDS.get(suite_key, []) or [])
    return records


def _settings_for_context(context):
    try:
        scene = getattr(context, 'scene', None)
        return getattr(scene, 'srr_settings', None) if scene is not None else None
    except Exception:
        return None


def _tool_section_states(settings) -> dict[str, bool]:
    if settings is None:
        return {}
    try:
        raw = json.loads(str(getattr(settings, 'integrated_tool_section_state_json', '{}') or '{}'))
        if isinstance(raw, dict):
            return {str(k): bool(v) for k, v in raw.items()}
    except Exception:
        pass
    return {}


def _tool_section_prop_name(alias: str) -> str:
    try:
        return str(tool_expanded_prop_name(str(alias or '').strip()) or '')
    except Exception:
        return f"integrated_tool_expanded__{str(alias or '').strip()}"


def _tool_section_is_open(settings, alias: str) -> bool:
    prop_name = _tool_section_prop_name(alias)
    try:
        if settings is not None and prop_name and hasattr(settings, prop_name):
            return bool(getattr(settings, prop_name))
    except Exception:
        pass
    return bool(_tool_section_states(settings).get(str(alias or ''), False))


def _status_icon(record: dict[str, Any]) -> str:
    status = str((record or {}).get('status') or '')
    if status == 'loaded':
        return 'CHECKMARK'
    if status == 'failed':
        return 'ERROR'
    if status == 'ready':
        return 'IMPORT'
    if status in {'disabled', 'unsupported_platform'}:
        return 'HIDE_ON'
    return 'TOOL_SETTINGS'


def _draw_integrated_help_button(layout, help_key: str, *, tool_label: str = '') -> None:
    try:
        from .help_operator import draw_help_button
        draw_help_button(layout, str(help_key or ''), tool_label=str(tool_label or ''))
    except Exception:
        try:
            row = layout.row(align=True)
            row.scale_x = 0.82
            row.scale_y = 1.0
            row.label(text='', icon='QUESTION')
        except Exception:
            pass


def _draw_integrated_record_body(layout, context, record: dict[str, Any]) -> None:
    spec = dict((record or {}).get('spec') or {})
    alias = str(spec.get('alias') or (record or {}).get('alias') or '').strip()
    status = str((record or {}).get('status') or '')
    row = layout.row(align=True)
    row.label(text=_status_text({'status': status}), icon=_status_icon(record))
    if status in {'ready', 'failed'} and alias:
        op = row.operator('smart_render_suite.load_integrated_tool', text=_txt('読み込む', 'Load'), icon='IMPORT')
        op.addon_alias = alias
        op.force_reload = bool(status == 'failed')

    if status == 'failed':
        excerpt = _trace_excerpt((record or {}).get('error', ''))
        if excerpt:
            warn = layout.box()
            warn.alert = True
            _wrap_lines(warn, f"{_txt('読み込みエラー', 'Load error')}: {excerpt}", width=70, icon='ERROR')
        return
    if status in {'unsupported_platform', 'disabled'}:
        layout.label(text=_txt('このツールは現在の環境では表示対象外です。', 'This tool is not available in the current environment.'))
        return
    if status != 'loaded':
        return

    quick = _quick_entries(record, limit=8)
    if quick:
        quick_box = layout.box()
        quick_box.label(text=_txt('クイックアクセス', 'Quick Access'), icon='TOOL_SETTINGS')
        col = quick_box.column(align=True)
        for kind, item_id, label, desc, is_pie in quick:
            _invoke_operator(
                col,
                addon_alias=alias,
                target_kind=kind,
                target_id=item_id,
                label=label,
                desc=desc,
                is_pie=is_pie,
            )
    else:
        layout.label(text=_txt('直接操作できる項目はありません。', 'No direct controls are exposed.'))

    for panel_cls in sorted(record.get('panels', ()), key=lambda cls: cls.__name__):
        if not getattr(panel_cls, '_srr_integrated_popover', False):
            continue
        if not panel_cls.poll(context):
            continue
        layout.popover(
            panel=getattr(panel_cls, 'bl_idname', panel_cls.__name__),
            text=localize_inline(panel_cls.bl_label),
        )

    try:
        for panel_index, panel_spec in enumerate(extra_ui.panel_specs_for_record(record), start=1):
            draw_fn = panel_spec.get('draw')
            if not callable(draw_fn):
                continue
            box = layout.box()
            box.label(text=str(localize_inline(panel_spec.get('label') or _txt('追加操作', 'Extra Controls'))), icon='TOOL_SETTINGS')
            try:
                draw_fn(box, context)
            except Exception as exc:
                box.label(text=_txt('追加の操作を表示できませんでした。', f'Extra draw failed: {exc}'), icon='ERROR')
    except Exception:
        pass


def _draw_integrated_record_section(layout, context, settings, record: dict[str, Any]) -> None:
    spec = dict((record or {}).get('spec') or {})
    alias = str(spec.get('alias') or (record or {}).get('alias') or '').strip()
    if not alias:
        return
    label = str(spec.get('display_name') or tool_display_name(alias) or alias)
    label = _txt(tool_display_name_ja(alias) or label, label)
    prop_name = _tool_section_prop_name(alias)
    header = body = None
    try:
        if settings is not None and prop_name and hasattr(settings, prop_name):
            try:
                header, body = layout.panel_prop(settings, prop_name)
            except Exception:
                header = body = None
        if header is None:
            safe_alias = ''.join(ch if ch.isalnum() else '_' for ch in alias).strip('_').lower() or 'tool'
            header, body = layout.panel(
                idname=f'smart_render_integrated_{safe_alias}',
                default_closed=True,
            )
        header.use_property_split = False
        header.use_property_decorate = False
        header.label(text=label, icon=_status_icon(record))
        header.separator(factor=0.35)
        _draw_integrated_help_button(header, f'integrated:{alias}', tool_label=label)
    except Exception:
        try:
            layout.label(text=label, icon=_status_icon(record))
        except Exception:
            pass
        return
    if body is None:
        return
    body = body.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    _draw_integrated_record_body(body, context, record)


def draw_embedded_tools_section(layout, context, *, draw_header: bool = True) -> None:
    """Draw the former Integrated Tools header inside SRR_PT_MAIN_PANEL.

    No separate Integrated Tools/Sougou Tools panel is registered.  The actual
    migrated tool panels are parented directly to SRR_PT_MAIN_PANEL; this section only
    provides the saved search/list controls and current load status.
    """
    records = _suite_records_for_draw()
    if not records:
        return

    visible_records = [item for item in records if _record_matches_search(item, context)]
    loaded = sum(1 for item in records if str(item.get('status') or '') == 'loaded')
    failed = sum(1 for item in records if str(item.get('status') or '') == 'failed')
    ready = sum(1 for item in records if str(item.get('status') or '') == 'ready')
    total = len(records)
    prefs = _root_preferences(context)

    if draw_header:
        info_box = layout.box()
        header = info_box.row(align=True)
        header.label(text='Smart Render', icon='RENDER_STILL')
        try:
            _draw_lazy_help_button(header, 'integrated_tools', tool_label='Smart Render')
        except Exception:
            pass
        child_layout = info_box
    else:
        # Keep child disclosure rows as direct siblings on the supplied body.
        # Status/search controls stay in a compact box above those rows.
        try:
            info_box = layout.box()
            info_box.use_property_split = False
            info_box.use_property_decorate = False
        except Exception:
            info_box = layout
        child_layout = layout

    if prefs is not None:
        try:
            from . import preferences as _preferences
            _preferences.draw_runtime_settings(info_box, context)
        except Exception:
            pass

    info_box.label(text=_txt(f'読み込み済み：{loaded}/{total} 件', f'Loaded: {loaded}/{total}'))
    if failed:
        info_box.label(text=_txt(f'{failed} 件で読み込みエラーがあります。', f'{failed} tools reported load errors.'), icon='ERROR')

    if not _tool_list_visible(context):
        info_box.label(text=_txt('その他ツールは非表示です。必要な時だけ表示してください。', 'The Other Tools list is hidden. Turn it back on only when you need to browse the tools.'), icon='HIDE_ON')
        return

    search_text = _tool_search_text(context)
    if search_text:
        info_box.label(text=_txt(f'検索一致: {len(visible_records)}/{total} 件', f'Matches: {len(visible_records)}/{total}'), icon='VIEWZOOM')
        if not visible_records:
            info_box.label(text=_txt('現在の検索条件に一致するツールはありません。', 'No Smart Render tools match the current search.'))

    settings = _settings_for_context(context)
    for record in visible_records:
        _draw_integrated_record_section(child_layout, context, settings, record)


def _addon_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    class_name, panel_id = ID_FACTORY.panel('INTADDON', suite_key, alias)
    parent_id = _SUITE_ROOT_PANEL_IDS[suite_key]
    panel_context = suite_panel_context(suite_key)

    @classmethod
    def poll(cls, context):
        # Smart Render uses one root N-panel only. Integrated tool entries are
        # drawn inside the root panel's section group, not as separate child
        # panels, so the native generated Panel stays hidden.
        del cls, context
        return False

    def draw(self, context):
        _sync_persistent_ui_state(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        raw_status = str(record.get('status') or '')
        enabled = True
        status = raw_status

        header = layout.row(align=True)
        if status in {'ready', 'failed'}:
            load_op = header.operator('smart_render_suite.load_integrated_tool', text=_txt('読み込む', 'Load'), icon='IMPORT')
            load_op.addon_alias = alias
            load_op.force_reload = bool(status == 'failed')
        header.label(text=_status_text({'status': status}))


        if status == 'failed':
            excerpt = _trace_excerpt(record.get('error', ''))
            if excerpt:
                warn = layout.box()
                warn.alert = True
                _wrap_lines(warn, f"{_txt('読み込みエラー', 'Load error')}: {excerpt}", width=70, icon='ERROR')

        if status == 'loaded':
            quick = _quick_entries(record, limit=6)
            if quick:
                quick_box = layout.box()
                quick_box.label(text=localize_inline('Quick Access / クイックアクセス'), icon='TOOL_SETTINGS')
                col = quick_box.column(align=True)
                for kind, item_id, label, desc, is_pie in quick:
                    _invoke_operator(
                        col,
                        addon_alias=alias,
                        target_kind=kind,
                        target_id=item_id,
                        label=label,
                        desc=desc,
                        is_pie=is_pie,
                    )
            if not quick:
                layout.label(text=_txt('直接操作できる項目はありません。', 'No direct controls are exposed.'))
        elif status == 'unsupported_platform':
            layout.label(text=localize_inline('This package is bundled, but it is disabled on the current platform. / 同梱済みですが現在の環境では無効です。'))
        elif status == 'disabled':
            layout.label(text=localize_inline('This package is intentionally disabled because a duplicate or superseded version was skipped. / 重複または上位互換により無効化されています。'))

    def draw_header(self, _context):
        _draw_lazy_help_button(self.layout, f'integrated:{alias}', tool_label=str(spec.get('display_name') or alias))

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': str(spec.get('display_name') or alias),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Render',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        'draw_header': draw_header,
        '_smart_suite_host_panel': True,
    }
    _ADDON_PANEL_IDS[alias] = panel_id
    return None


def _proxy_panel_class(record: dict, original_panel_cls: type, order_index: int):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTPROXY', suite_key, alias, getattr(original_panel_cls, '__name__', ''), order_index)
    panel_context = suite_panel_context(suite_key)
    original_label = localize_inline(str(getattr(original_panel_cls, 'bl_label', '') or getattr(original_panel_cls, '__name__', '') or panel_id))
    original_draw = getattr(original_panel_cls, 'draw', None)

    @classmethod
    def poll(cls, context):
        # Keep proxy panel bodies available for embedded/manual routing, but do
        # not display them as extra Smart Render N-panel children.
        del cls, context
        return False

    def draw(self, context):
        _sync_persistent_ui_state(context)
        layout = self.layout
        if not callable(original_draw):
            layout.label(text=localize_inline('Original panel has no draw function. / 元パネルに draw 関数がありません。'))
            return
        try:
            _call_draw(original_draw, original_panel_cls, layout, context)
        except Exception as exc:
            layout.label(text=_txt('パネルを表示できませんでした。', f'Proxy draw failed: {exc}'), icon='ERROR')

    def draw_header(self, _context):
        _draw_lazy_help_button(self.layout, f'integrated:{alias}', tool_label=original_label)

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': original_label,
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Render',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        'draw_header': draw_header,
        '_smart_suite_host_panel': True,
    }
    return None


def _extra_panel_class(record: dict, panel_spec: dict, order_index: int):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    panel_key = str(panel_spec.get('key') or getattr(panel_spec.get('draw'), '__name__', '') or order_index)
    class_name, panel_id = ID_FACTORY.panel('INTEXTRA', suite_key, alias, panel_key, order_index)
    panel_context = suite_panel_context(suite_key)
    panel_label = str(localize_inline(panel_spec.get('label') or 'Extra / 追加'))
    draw_fn = panel_spec.get('draw')

    @classmethod
    def poll(cls, context):
        # Keep generated integrated panels out of the native N-panel tree.
        del cls, context
        return False

    def draw(self, context):
        _sync_persistent_ui_state(context)
        layout = self.layout
        if not callable(draw_fn):
            layout.label(text=localize_inline('Extra controls are not available. / 追加操作は利用できません。'))
            return
        try:
            draw_fn(layout, context)
        except Exception as exc:
            layout.label(text=_txt('追加の操作を表示できませんでした。', f'Extra draw failed: {exc}'), icon='ERROR')

    def draw_header(self, _context):
        _draw_lazy_help_button(self.layout, f'integrated:{alias}', tool_label=panel_label)

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': panel_label,
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Render',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        'draw_header': draw_header,
        '_smart_suite_host_panel': True,
    }
    return None


def _tool_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTTOOLS', suite_key, alias)
    panel_context = suite_panel_context(suite_key)

    @classmethod
    def poll(cls, context):
        # Keep generated integrated tool lists inside the root section only.
        del cls, context
        return False

    def draw(self, _context):
        _sync_persistent_ui_state(_context)
        _draw_tool_list(self.layout, record, compact=True)

    def draw_header(self, _context):
        _draw_lazy_help_button(self.layout, f'integrated:{alias}', tool_label=_txt('ツール', 'Tools'))

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': localize_inline('Tools / ツール'),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart Render',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        'draw_header': draw_header,
        '_smart_suite_host_panel': True,
    }
    return None


def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)


def register() -> None:
    _safe_unregister_registered_classes()
    _collect_records()
    try:
        localize_class_attributes((SMART_RENDER_SUITE_OT_load_integrated_tool, SMART_RENDER_SUITE_OT_integrated_addon_info, SMART_RENDER_SUITE_OT_integrated_invoke))
    except Exception:
        pass
    _safe_register_static_class(SMART_RENDER_SUITE_OT_load_integrated_tool)
    _safe_register_static_class(SMART_RENDER_SUITE_OT_integrated_addon_info)
    _safe_register_static_class(SMART_RENDER_SUITE_OT_integrated_invoke)
    _collect_records()
    if _smart_tools_hosts_exist():
        try:
            refresh_all_suites(getattr(bpy, 'context', None))
        except Exception:
            pass


def unregister() -> None:
    _safe_unregister_registered_classes()
