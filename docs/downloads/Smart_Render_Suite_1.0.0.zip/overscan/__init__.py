# SPDX-License-Identifier: GPL-3.0-or-later
"""Enlarge a camera's rendered frame and restore the original settings across saves."""
import json
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from ..help_operator import draw_help_button
from ..translation import iface_text


def capture(scene, camera):
    data = camera.data
    return dict(width=scene.render.resolution_x, height=scene.render.resolution_y,
                object_name=camera.name, sensor_width=data.sensor_width,
                sensor_height=data.sensor_height, sensor_fit=data.sensor_fit,
                ortho_scale=data.ortho_scale, safe=data.show_safe_areas,
                action=list(scene.safe_areas.action), title=list(scene.safe_areas.title))


def restore(scene, settings):
    record = json.loads(settings.original_frame)
    camera = settings.edited_camera
    scene.render.resolution_x = record['width']
    scene.render.resolution_y = record['height']
    scene.safe_areas.action = record['action']
    scene.safe_areas.title = record['title']
    if camera and camera.type == 'CAMERA':
        data = camera.data
        for key in ('sensor_width','sensor_height','sensor_fit','ortho_scale'):
            setattr(data,key,record[key])
        data.show_safe_areas = record['safe']
        # Keep a deliberate name change made while working on the shot.
        if camera.name == record.get('applied_name'):
            camera.name = record['object_name']
    settings.edited_camera = None
    settings.original_frame = ''


def restore_legacy(scene, camera):
    if not camera or camera.type != 'CAMERA':
        return False
    data = camera.data
    fields = {'original_width','original_height','original_ortho_scale','original_sensor_width','original_sensor_fit'}
    if not data.get('overscan_applied') or not fields.issubset(data.keys()):
        return False
    if data['original_sensor_fit'] not in {'AUTO','HORIZONTAL','VERTICAL'}:
        return False
    scene.render.resolution_x = int(data['original_width'])
    scene.render.resolution_y = int(data['original_height'])
    data.ortho_scale = float(data['original_ortho_scale'])
    data.sensor_width = float(data['original_sensor_width'])
    data.sensor_fit = data['original_sensor_fit']
    for index, image in enumerate(data.background_images):
        key = f'bg_image_scale_{index}'
        if key in data:
            image.scale = float(data[key])
            del data[key]
    # This earlier format did not store the original name or guide settings.
    if camera.name.endswith('_o'):
        camera.name = camera.name[:-2]
    data.show_safe_areas = False
    scene.safe_areas.action = scene.safe_areas.title = (1,1)
    for key in fields | {'overscan_applied'}:
        del data[key]
    return True


def on_update(settings, context):
    scene = settings.id_data
    if not isinstance(scene,bpy.types.Scene):return
    camera = scene.camera
    if not camera or camera.type != 'CAMERA':return
    if settings.original_frame and settings.edited_camera != camera:
        restore(scene, settings)
    if not settings.original_frame:
        restore_legacy(scene,camera)
    base = json.loads(settings.original_frame) if settings.original_frame else capture(scene,camera)
    w,h=base['width'],base['height']
    if settings.mode == 'PIXELS':
        width,height=w+settings.extra_pixels,h+settings.extra_pixels
    elif settings.mode == 'SPECIFIC_X':
        width=max(w,settings.specific_x_resolution)
        height=round(h*width/w)
    else:
        factor=1+settings.percentage/100
        width,height=round(w*factor),round(h*factor)
    if (w,h)==(width,height):
        if settings.original_frame:restore(scene,settings)
        return
    limit=scene.render.bl_rna.properties['resolution_x'].hard_max
    if width>limit or height>limit:
        ratio=min(limit/width,limit/height)
        width,height=max(w,round(width*ratio)),max(h,round(height*ratio))
    data=camera.data
    vertical=base['sensor_fit']=='VERTICAL' or (base['sensor_fit']=='AUTO' and h*scene.render.pixel_aspect_y>w*scene.render.pixel_aspect_x)
    ratio=height/h if vertical else width/w
    if not settings.original_frame:
        settings.edited_camera=camera
        if not camera.name.endswith('_o'):camera.name=camera.name+'_o'
        base['applied_name']=camera.name
        settings.original_frame=json.dumps(base,ensure_ascii=False)
    scene.render.resolution_x=width
    scene.render.resolution_y=height
    if data.type=='ORTHO':
        data.ortho_scale=base['ortho_scale']*ratio
    else:
        # Blender's AUTO fit uses sensor_width for both aspect orientations.
        original_sensor=base['sensor_height'] if base['sensor_fit']=='VERTICAL' else base['sensor_width']
        data.sensor_fit='VERTICAL' if vertical else 'HORIZONTAL'
        if vertical:data.sensor_height=original_sensor*ratio
        else:data.sensor_width=original_sensor*ratio
    scene.safe_areas.action=(1-w/width,1-h/height)
    scene.safe_areas.title=(1,1)
    data.show_safe_areas=True


class OverscanSettings(bpy.types.PropertyGroup):
    mode: EnumProperty(name="Mode",items=(('PERCENTAGE',"Percentage",""),('PIXELS',"Extra Pixels",""),('SPECIFIC_X',"Specific X Resolution","")),default='PERCENTAGE',update=on_update)
    percentage: FloatProperty(name="Percentage",subtype='PERCENTAGE',default=0,min=0,max=100,update=on_update)
    extra_pixels: IntProperty(name="Extra Pixels",default=0,min=0,update=on_update)
    specific_x_resolution: IntProperty(name="Specific X Resolution",default=1920,min=1,update=on_update)
    overscan_panel: BoolProperty(name="Overscan",default=True)
    edited_camera: PointerProperty(type=bpy.types.Object,options={'HIDDEN'})
    original_frame: StringProperty(options={'HIDDEN'})


class RevertOverscan(bpy.types.Operator):
    bl_idname="render.revert_overscan"
    bl_label="Revert Overscan"
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        scene=context.scene
        if scene.overscan_settings.original_frame:restore(scene,scene.overscan_settings)
        elif not restore_legacy(scene,scene.camera):return {'CANCELLED'}
        return {'FINISHED'}


class OverscanPanel(bpy.types.Panel):
    bl_idname="RENDER_PT_OVERSCAN"
    bl_label="Overscan"
    bl_space_type='VIEW_3D'
    bl_region_type='HEADER'
    bl_context='output'
    _srr_integrated_popover=True

    def draw_header_preset(self,context):
        draw_help_button(self.layout,'integrated:overscan')

    def draw(self,context):
        st=context.scene.overscan_settings
        header=self.layout.row(align=True)
        header.prop(st,'overscan_panel',text=iface_text('Overscan'),icon='TRIA_DOWN' if st.overscan_panel else 'TRIA_RIGHT',emboss=False)
        draw_help_button(header,'integrated:overscan')
        if st.overscan_panel:
            self.layout.prop(st,'mode',text=iface_text('Mode'))
            key={'PERCENTAGE':'percentage','PIXELS':'extra_pixels','SPECIFIC_X':'specific_x_resolution'}[st.mode]
            self.layout.prop(st,key,text=iface_text(st.bl_rna.properties[key].name))
            self.layout.operator(RevertOverscan.bl_idname,text=iface_text('Revert Overscan'))


classes=(OverscanSettings,RevertOverscan,OverscanPanel)

def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Scene.overscan_settings=PointerProperty(type=OverscanSettings)

def unregister():
    del bpy.types.Scene.overscan_settings
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
