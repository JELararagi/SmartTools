# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import json
import re
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_PATCH_DEPTH = 0
_ORIGINALS: dict[str, Any] = {}
_ORIGINAL_DRAW_ADDS: dict[str, Any] = {}
_ORIGINAL_DRAW_REMOVES: dict[str, Any] = {}
_DUMMY_COUNTER = 0
_MAX_STATE_ALIASES = 128
_MAX_FEATURES_PER_ALIAS = 32
_MAX_ACTIONS_PER_FEATURE = 512
_MAX_TOKEN_LENGTH = 128

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. When N-panel State Save is enabled, the setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、元に戻す / やり直し、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. When N-panel State Save is enabled, the setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus',
        'label_ja': 'プロパティ変更の通知',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. When N-panel State Save is enabled, the setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する msgbus 購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. When N-panel State Save is enabled, the setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。Nパネル状態保存が有効な場合は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport Draw',
        'label_ja': 'ビューポート描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. When N-panel State Save is enabled, the setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。Nパネル状態保存が有効な場合は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)


def _clean_identifier(value: str, fallback: str = 'smart_tools') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Render'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_tools'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def toggle_operator_id() -> str:
    configure(suite_key='smart_render_suite', suite_label='Smart Render', category='Smart Render')
    return _OPERATOR_ID



def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return str(ja if _is_ja(None) else en)


def _settings_path() -> Path | None:
    configure(suite_key='smart_render_suite', suite_label='Smart Render', category='Smart Render')
    try:
        from . import settings as _settings
        getter = getattr(_settings, 'settings_file_path', None)
        if callable(getter):
            path = getter()
            if path is not None:
                return Path(path)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            config_dir = user_resource('CONFIG', create=True)
            if config_dir:
                base = Path(config_dir) / 'Smart_Render_Suite'
                base.mkdir(parents=True, exist_ok=True)
                return base / 'Smart_Render_Suite.json'
    except Exception:
        pass
    return None


def _legacy_settings_path() -> Path | None:
    configure()
    try:
        value = bpy.utils.user_resource('CONFIG', path='SmartTools', create=False)
        if value:
            legacy = Path(value) / f'{_SUITE_KEY}_persistent_feature_toggles.json'
            if legacy.exists():
                return legacy
    except Exception:
        pass
    try:
        from .storage import user_default_root
        legacy = user_default_root('settings', create=False) / f'{_SUITE_KEY}_persistent_feature_toggles.json'
        if legacy.exists():
            return legacy
    except Exception:
        pass
    try:
        from .compat import extension_user_root
        legacy = Path(extension_user_root(create=False)) / 'settings' / f'{_SUITE_KEY}_persistent_feature_toggles.json'
        if legacy.exists():
            return legacy
    except Exception:
        pass
    return None


def _bounded_token(value: Any) -> str:
    return str(value or '').strip()[:_MAX_TOKEN_LENGTH]


def _coerce_bool(value: Any) -> bool:
    if isinstance(value, str):
        token = value.strip().lower()
        if token in {'1', 'true', 'yes', 'on', 'enabled'}:
            return True
        if token in {'0', 'false', 'no', 'off', 'disabled', ''}:
            return False
    return bool(value)


def _extract_feature_toggle_state(raw: Any) -> dict[str, dict[str, bool]]:
    data: dict[str, dict[str, bool]] = {}
    if not isinstance(raw, dict):
        return data
    if isinstance(raw.get('feature_toggles'), dict):
        source = raw.get('feature_toggles')
    elif any(key in raw for key in ('version', 'scene_settings', 'scene_groups', 'scene_collections', 'scene_values', 'wm_groups', 'wm_values', 'always_on', 'loaded_tools')):
        return data
    else:
        source = raw
    if not isinstance(source, dict):
        return data
    for raw_alias, values in source.items():
        if len(data) >= _MAX_STATE_ALIASES:
            break
        alias = _bounded_token(raw_alias)
        if not alias or not isinstance(values, dict):
            continue
        cleaned: dict[str, bool] = {}
        for raw_key, value in values.items():
            if len(cleaned) >= _MAX_FEATURES_PER_ALIAS:
                break
            key = _bounded_token(raw_key)
            if key and isinstance(value, (bool, int, float, str)):
                cleaned[key] = _coerce_bool(value)
        if cleaned:
            data[alias] = cleaned
    return data


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    path = _settings_path()
    if path is not None and path.exists():
        try:
            data.update(_extract_feature_toggle_state(json.loads(path.read_text(encoding='utf-8'))))
        except Exception:
            data = {}
    if not data:
        legacy_path = _legacy_settings_path()
        if legacy_path is not None and legacy_path.exists():
            try:
                data.update(_extract_feature_toggle_state(json.loads(legacy_path.read_text(encoding='utf-8'))))
            except Exception:
                pass
    _STATE_CACHE = data
    return _STATE_CACHE


def export_state() -> dict[str, dict[str, bool]]:
    return {str(alias): {str(key): bool(value) for key, value in dict(values).items()} for alias, values in _load_state().items() if isinstance(values, dict)}


def _save_state() -> bool:
    try:
        from . import settings as _settings
        enabled_fn = getattr(_settings, 'is_npanel_state_save_enabled', None)
        if callable(enabled_fn) and not bool(enabled_fn(getattr(bpy, 'context', None))):
            return True
    except Exception:
        pass
    # All configuration writes go through settings._write_data so the master
    # save gate, malformed-file preservation, atomic replace and error status
    # cannot be bypassed by this secondary feature store.
    try:
        from . import settings as _settings
        load_data = getattr(_settings, '_load_data', None)
        write_data = getattr(_settings, '_write_data', None)
        if callable(load_data) and callable(write_data):
            payload = load_data()
            payload['feature_toggles'] = export_state()
            return bool(write_data(payload))
    except Exception:
        return False
    return False


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = _bounded_token(alias)
    feature_key = _bounded_token(feature_key)
    return _coerce_bool(_load_state().get(alias, {}).get(feature_key, False))


def _trim_oldest_mapping_entry(mapping: dict[str, Any]) -> None:
    if mapping:
        oldest = next(iter(mapping))
        mapping.pop(oldest, None)


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = _bounded_token(alias)
    feature_key = _bounded_token(feature_key)
    if not alias or not feature_key:
        return False
    state = _load_state()
    if alias not in state and len(state) >= _MAX_STATE_ALIASES:
        _trim_oldest_mapping_entry(state)
    alias_state = state.setdefault(alias, {})
    if feature_key not in alias_state and len(alias_state) >= _MAX_FEATURES_PER_ALIAS:
        _trim_oldest_mapping_entry(alias_state)
    desired = _coerce_bool(enabled)
    had_previous = feature_key in alias_state
    previous = alias_state.get(feature_key, False)
    alias_state[feature_key] = desired
    saved = _save_state()
    if not saved:
        if had_previous:
            alias_state[feature_key] = previous
        else:
            alias_state.pop(feature_key, None)
        if not alias_state:
            state.pop(alias, None)
        return False
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, desired)
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = _bounded_token(alias)
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()[:256]
    feature_key = _bounded_token(feature_key)
    info = _KIND_INFO.get(feature_key, {})
    if alias not in _FEATURES and len(_FEATURES) >= _MAX_STATE_ALIASES:
        oldest_alias = next(iter(_FEATURES))
        deactivate_alias(oldest_alias)
        _FEATURES.pop(oldest_alias, None)
    features = _FEATURES.setdefault(alias, {})
    if feature_key not in features and len(features) >= _MAX_FEATURES_PER_ALIAS:
        oldest_key = next(iter(features))
        old_feature = features.pop(oldest_key, None)
        if old_feature is not None:
            _set_feature_active(old_feature, False)
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _action_identity(action: dict[str, Any]) -> tuple[Any, ...]:
    kind = str(action.get('kind') or '')
    if kind == 'handlers':
        return kind, str(action.get('list_name') or ''), id(action.get('fn'))
    if kind == 'timers':
        return kind, id(action.get('fn'))
    if kind == 'msgbus':
        kwargs = action.get('kwargs') or {}
        args = tuple(action.get('args') or ())
        key = kwargs.get('key', args[0] if args else None)
        notify = kwargs.get('notify', args[3] if len(args) >= 4 else None)
        return kind, id(action.get('owner')), id(notify), repr(key)[:512]
    if kind == 'draw_handlers':
        args = tuple(action.get('args') or ())
        callback = args[0] if args else None
        draw_type = args[3] if len(args) >= 4 else (action.get('kwargs') or {}).get('draw_type')
        callback_args = args[1] if len(args) >= 2 else (action.get('kwargs') or {}).get('args')
        return kind, str(action.get('space_name') or ''), id(callback), id(callback_args), str(action.get('region_type') or ''), str(draw_type or '')
    if kind == 'keymaps':
        return kind, id(action.get('kmi')), str(action.get('km_name') or ''), str(action.get('idname') or '')
    return kind, id(action)


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    actions = feature.setdefault('actions', [])
    identity = _action_identity(action)
    if any(_action_identity(existing) == identity for existing in actions):
        return
    if len(actions) >= _MAX_ACTIONS_PER_FEATURE:
        removed = actions.pop(0)
        _remove_action(removed)
    actions.append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _snapshot_keymaps() -> set[int]:
    ids: set[int] = set()
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                ids.add(id(kmi))
    except Exception:
        pass
    return ids


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    props_out: dict[str, Any] = {}
    try:
        props = getattr(kmi, 'properties', None)
        bl_rna = getattr(props, 'bl_rna', None)
        for prop in getattr(bl_rna, 'properties', ()) or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type':
                continue
            try:
                value = getattr(props, ident)
            except Exception:
                continue
            if isinstance(value, (str, int, float, bool)):
                props_out[ident] = value
    except Exception:
        pass
    return props_out


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'km': km,
        'kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                if id(kmi) not in before:
                    actions.append(_describe_keymap_item(km, kmi))
    except Exception:
        pass
    return actions


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = _ORIGINAL_DRAW_REMOVES.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            if km is not None and kmi is not None:
                # Blender 5.1 can crash in rna_KeyMap_item_remove() when a
                # stale KeyMapItem is removed during application shutdown.
                # Disabling the item provides the same user-facing inactive
                # state without calling the unsafe native remove path.
                try:
                    kmi.active = False
                except Exception:
                    pass
            action['active_km'] = None
            action['active_kmi'] = None
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        km_name = str(action.get('km_name') or '')
        idname = str(action.get('idname') or '')
        if not km_name or not idname:
            return
        if idname == 'wm.tool_set_by_id':
            props = action.get('properties') or {}
            tool_name = str(props.get('name') or '').strip()
            if not tool_name:
                return
        try:
            km = kc.keymaps.get(km_name)
        except Exception:
            km = None
        if km is None:
            try:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'), modal=bool(action.get('modal', False)))
            except TypeError:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'))
        kwargs = {
            'type': str(action.get('type') or 'NONE'),
            'value': str(action.get('value') or 'PRESS'),
            'any': bool(action.get('any', False)),
            'shift': bool(action.get('shift', False)),
            'ctrl': bool(action.get('ctrl', False)),
            'alt': bool(action.get('alt', False)),
            'oskey': bool(action.get('oskey', False)),
            'key_modifier': str(action.get('key_modifier') or 'NONE'),
            'direction': str(action.get('direction') or 'ANY'),
            'repeat': bool(action.get('repeat', False)),
        }
        try:
            kmi = km.keymap_items.new(idname, **kwargs)
        except TypeError:
            kwargs.pop('repeat', None)
            try:
                kmi = km.keymap_items.new(idname, **kwargs)
            except TypeError:
                kwargs.pop('direction', None)
                kmi = km.keymap_items.new(idname, **kwargs)
        for prop_name, value in (action.get('properties') or {}).items():
            try:
                _safe_safe_set_kmi_property_v60(kmi, prop_name, value)
            except Exception:
                pass
        action['active_km'] = km
        action['active_kmi'] = kmi
        action['active'] = True
    except Exception:
        action['active'] = False


def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and fn not in seq:
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = _ORIGINALS.get('timer_register') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = _ORIGINALS.get('msgbus_subscribe') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = _ORIGINAL_DRAW_ADDS.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER = (_DUMMY_COUNTER + 1) % 1_000_000
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')


def _timer_register_proxy(function, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['timer_register'](function, *args, **kwargs)
    action = {'kind': 'timers', 'fn': function, 'args': tuple(args), 'kwargs': dict(kwargs), 'active': False}
    cap.record_action('timers', action)
    if cap.kind_enabled('timers'):
        result = _ORIGINALS['timer_register'](function, *args, **kwargs)
        action['active'] = True
        return result
    return None


def _msgbus_subscribe_proxy(*args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
    owner = kwargs.get('owner')
    if owner is None and len(args) >= 2:
        owner = args[1]
    action = {'kind': 'msgbus', 'args': tuple(args), 'kwargs': dict(kwargs), 'owner': owner, 'active': False}
    cap.record_action('msgbus', action)
    if cap.kind_enabled('msgbus'):
        result = _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
        action['active'] = True
        return result
    return None


def _make_draw_add_proxy(space_name: str, space_cls, original_add):
    def _proxy(*args, **kwargs):
        cap = _current_capture()
        if cap is None:
            return original_add(*args, **kwargs)
        region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
        action = {
            'kind': 'draw_handlers',
            'space_name': space_name,
            'space_cls': space_cls,
            'args': tuple(args),
            'kwargs': dict(kwargs),
            'region_type': region_type,
            'handle': None,
            'active': False,
        }
        cap.record_action('draw_handlers', action)
        if cap.kind_enabled('draw_handlers'):
            action['handle'] = original_add(*args, **kwargs)
            action['active'] = True
            return action['handle']
        return _next_dummy_handle()
    return _proxy


def _install_patches() -> None:
    # Startup-safe Blender 5.x mode: do not replace bpy.app.timers,
    # bpy.msgbus, or Space*.draw_handler_add. Replacing Blender runtime API
    # functions during add-on registration was a freeze/crash risk. The
    # explicit always-on controls in controls.py cover known
    # background features without monkey-patching bpy internals.
    return None


def _uninstall_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH = 0
    return None


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        _install_patches()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
                if not self.kind_enabled('handlers'):
                    _remove_action(action)
            for action in _collect_new_keymaps(self._before_keymaps):
                self.record_action('keymaps', action)
                if not self.kind_enabled('keymaps'):
                    _remove_action(action)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _uninstall_patches()
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    area.tag_redraw()
    except Exception:
        pass


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        tool_label = str(feature.get('tool_label') or alias or 'Integrated Tool')
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        action = _t(context, 'Click to switch this feature between enabled and disabled. The setting is saved immediately.', 'クリックすると、この機能の有効・無効を切り替えます。設定は即時保存されます。')
        enabled = is_feature_enabled(alias, feature_key)
        status = _t(context, f'Current state: {"Enabled" if enabled else "Disabled"}', f'現在の状態: {"有効" if enabled else "無効"}')
        return f'{tool_label}: {label}\n{desc}\n{action}\n{status}'
    return _t(context, 'Toggle an always-on Smart Render feature. The setting is saved immediately.', 'Smart Render の常時起動機能を切り替えます。設定は即時保存されます。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID

    class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_options = {'UNDO'}
        bl_idname = operator_id
        bl_label = _static_t('Toggle Feature', '機能を切り替え')
        bl_description = _static_t('Switch an always-on feature on or off and save the setting immediately.', '常時発動機能の有効・無効を切り替え、設定を即時保存します。')

        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting changed.', '機能設定を変更しました。'))
            return {'FINISHED'}

    SMARTTOOLS_OT_toggle_persistent_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_toggle_persistent_feature.__qualname__ = SMARTTOOLS_OT_toggle_persistent_feature.__name__
    SMARTTOOLS_OT_toggle_persistent_feature.__module__ = __name__
    try:
        existing = getattr(bpy.types, SMARTTOOLS_OT_toggle_persistent_feature.__name__, None)
        if isinstance(existing, type) and existing is not SMARTTOOLS_OT_toggle_persistent_feature:
            try:
                from .rna_safety import safe_unregister_class
                safe_unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    try:
        from .rna_safety import safe_register_class
        registered_cls = safe_register_class(SMARTTOOLS_OT_toggle_persistent_feature)
        _REGISTERED_CLASSES.append(registered_cls)
    except RuntimeError:
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_toggle_persistent_feature)
    except Exception:
        raise


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> None:
    try:
        from .rna_safety import safe_unregister_class
    except Exception:
        safe_unregister_class = None
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            if callable(safe_unregister_class):
                safe_unregister_class(cls)
            else:
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    global _STATE_CACHE
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()
    _CAPTURE_STACK.clear()
    _STATE_CACHE = None
    _uninstall_patches()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        props = getattr(kmi, 'properties', None)
        rna = getattr(props, 'bl_rna', None)
        prop_map = getattr(rna, 'properties', None)
        has_prop = False
        try:
            has_prop = str(prop_name) in set(prop_map.keys())
        except Exception:
            try:
                has_prop = prop_map.get(str(prop_name)) is not None
            except Exception:
                has_prop = hasattr(props, str(prop_name))
        if not has_prop:
            return False
        setattr(props, str(prop_name), value)
        return True
    except Exception:
        return False
