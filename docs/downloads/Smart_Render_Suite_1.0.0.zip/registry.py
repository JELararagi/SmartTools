# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Identify bundled tool folders without importing their modules."""

from copy import deepcopy
from pathlib import Path
import re

from .meta import ADDON_ID, ADDON_NAME
from .tool_folders import TOOL_SPECS


SUITE_META = {ADDON_ID: (ADDON_NAME, "navigation_properties")}
SUITE_ORDER = (ADDON_ID,)
_CACHE = None
_METADATA = {
    key: re.compile(r'"' + key + r'"\s*:\s*"([^"]+)"') for key in ("name", "description")
}


def package_root():
    return Path(__file__).resolve().parent


def tools_root():
    return package_root()


def clear_cache():
    global _CACHE
    _CACHE = None


def _read_bl_info_name_and_description(path):
    try:
        source = path.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return "", ""
    result = {}
    for key, parser in _METADATA.items():
        value = parser.search(source)
        result[key] = value.group(1).strip() if value else ""
    return result["name"], result["description"]


def _iter_addon_dirs():
    root = tools_root()
    for entry in TOOL_SPECS:
        alias = str(entry.get("dir") or "").strip()
        if not alias:
            continue
        folder = root / alias
        if folder.resolve().is_relative_to(root.resolve()) and (folder / "__init__.py").is_file():
            yield entry, folder


def build_specs(force=False):
    global _CACHE
    if _CACHE is None or force:
        specs = []
        for entry, folder in _iter_addon_dirs():
            alias = str(entry["dir"]).strip()
            name, description = _read_bl_info_name_and_description(folder / "__init__.py")
            title = name or str(entry.get("display_name") or alias)
            specs.append(dict(
                alias=alias, legacy_alias=str(entry.get("legacy_alias") or ""),
                outer_zip=str(entry.get("outer_zip") or f"{alias}.zip"),
                display_name=title, description=description or title, suite=ADDON_ID,
                suite_name=ADDON_NAME, load=True, note="", duplicate_of="", superseded_by="",
                spaces=list(entry.get("spaces") or ()), addon_dir=str(folder), src_dir=str(folder),
                source_root="", original_module_name=str(entry.get("original_module_name") or ""),
                import_mode="root_package", init_relpath="__init__.py", search_root="", vendor_dir=str(folder),
            ))
        _CACHE = specs
    return deepcopy(_CACHE)
