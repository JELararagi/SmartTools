# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from ..compat import abspath, default_output_root, extension_user_root, safe_name, set_image_file_format
from ..translation import action_tooltip, localize_pair, tooltip

bl_info = {
    "name": 'Render Pipeline Manager',
    "author": "JELararagi",
    "version": (1, 4, 0),
    "blender": (5, 1, 0),
    "location": "View3D or Image Editor > Sidebar > Smart Render > Integrated Tools",
    "description": "Precision-first render-pipeline cockpit with large custom icon UI and superset handoff manifests.",
    "category": "Render",
}

WM_SETTINGS_PROPERTY = "render_pipeline_settings"


def _t(ja: str, en: str) -> str:
    return localize_pair(ja, en)


def _safe_report(self, report_type: set[str], message_ja: str, message_en: str | None = None) -> None:
    try:
        self.report(report_type, _t(message_ja, message_en or message_ja))
    except Exception:
        pass


def _settings_update(_self, context) -> None:
    try:
        from .. import settings as persistent_settings
        persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
    except Exception:
        pass


def _enum(items: list[tuple[str, str, str, str, str]]) -> tuple[tuple[str, str, str], ...]:
    return tuple((identifier, _t(label_ja, label_en), tooltip(desc_ja, desc_en)) for identifier, label_ja, label_en, desc_ja, desc_en in items)



# Custom action icons.
# Original icon filenames are resolved to the deduplicated 32 px transparent PNG
# assets from the shared package-level icons directory.
_PREVIEW_COLLECTION = None
_PENDING_PREVIEW_REMOVALS = []
_ICON_PREVIEW_STORE_KEY = "JELARARAGI_SRS_RENDER_PIPELINE_PREVIEW_COLLECTIONS"
_IMAGE_EDITOR_PANEL_CLASSES: list[type] = []
_ICON_FILES: dict[str, str] = {
    "queue": "queue_build.png",
    "optimize": "precision_optimize.png",
    "precision": "precision_optimize.png",
    "autopilot": "autopilot_finalize.png",
    "pack": "submission_pack.png",
    "pipeline": "pipeline_flow.png",
}
_KNOWN_ICON_KEYS: tuple[str, ...] = tuple(_ICON_FILES.keys())
_OPERATOR_ICON_KEYS: dict[str, str] = {
    "render_pipeline.build_render_queue": "queue",
    "render_pipeline.optimize_precision_and_safety": "optimize",
    "render_pipeline.export_submission_pack": "pack",
    "render_pipeline.run_production_autopilot": "autopilot",
}
_BUILTIN_ICON_FALLBACKS: dict[str, str] = {
    "SEQ_STRIP_META": "queue",
    "MODIFIER": "optimize",
    "PLAY": "autopilot",
    "FILE_FOLDER": "pack",
}


def _preview_store() -> dict:
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if namespace is None:
            return {}
        store = namespace.setdefault(_ICON_PREVIEW_STORE_KEY, {})
        if isinstance(store, dict):
            return store
    except Exception:
        pass
    return {}


def _remove_preview_collection_later(pcoll) -> None:
    # Release custom preview collections during tool unregister. Owning panels
    # are hidden before this path, and best-effort removal prevents Blender
    # shutdown ResourceWarning output without touching UI state during draw.
    if pcoll is None:
        return None
    try:
        store = _preview_store()
        for key, value in tuple(store.items()):
            if value is pcoll:
                store.pop(key, None)
        retained = store.get('_retained')
        if isinstance(retained, list):
            while pcoll in retained:
                retained.remove(pcoll)
    except Exception:
        pass
    try:
        import bpy.utils.previews as previews
        previews.remove(pcoll)
    except Exception:
        pass
    return None



def _icon_directory() -> Path:
    return Path(__file__).resolve().parents[1] / 'icons'


def _load_icon_previews(*, force: bool = False):
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None and not force:
        return _PREVIEW_COLLECTION

    store = _preview_store()
    store_key = tuple(sorted(_ICON_FILES.items()))
    if not force:
        try:
            cached = store.get(store_key)
            if cached is not None:
                _PREVIEW_COLLECTION = cached
                return _PREVIEW_COLLECTION
        except Exception:
            pass

    try:
        import bpy.utils.previews as previews
        pcoll = previews.new()
    except Exception:
        _PREVIEW_COLLECTION = None
        return None

    folder = _icon_directory()
    loaded = False
    for key, filename in _ICON_FILES.items():
        path = folder / filename
        if not path.exists():
            continue
        try:
            pcoll.load(key, str(path), 'IMAGE')
            loaded = True
        except Exception:
            pass

    _PREVIEW_COLLECTION = pcoll
    try:
        if loaded:
            old = store.get(store_key)
            if old is not None and old is not pcoll:
                _remove_preview_collection_later(old)
            store[store_key] = pcoll
    except Exception:
        pass
    return _PREVIEW_COLLECTION


def _unload_icon_previews() -> None:
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        _remove_preview_collection_later(_PREVIEW_COLLECTION)
    _PREVIEW_COLLECTION = None


def _normalize_icon_key(value: str | None) -> str:
    text = str(value or '').strip()
    if not text:
        return ''
    text = text.replace('render_pipeline.', '')
    text = ''.join(ch.lower() if ch.isalnum() else '_' for ch in text)
    while '__' in text:
        text = text.replace('__', '_')
    return text.strip('_')


def _key_for_operator(idname: str | None, fallback_icon: str | None = None) -> str:
    op = str(idname or '').strip()
    if op in _OPERATOR_ICON_KEYS:
        return _OPERATOR_ICON_KEYS[op]
    normalized = _normalize_icon_key(op)
    if normalized in _KNOWN_ICON_KEYS:
        return normalized
    fallback = _BUILTIN_ICON_FALLBACKS.get(str(fallback_icon or '').strip())
    if fallback:
        return fallback
    normalized_fallback = _normalize_icon_key(fallback_icon)
    return normalized_fallback if normalized_fallback in _KNOWN_ICON_KEYS else ''


def _icon_value(key: str | None) -> int:
    normalized = _normalize_icon_key(key)
    if not normalized:
        return 0
    try:
        pcoll = _load_icon_previews()
        item = pcoll.get(normalized) if pcoll is not None else None
        return int(getattr(item, 'icon_id', 0) or 0)
    except Exception:
        return 0


def icon_value(key: str | None) -> int:
    return _icon_value(key)


def icon_value_for_operator(idname: str | None, fallback_icon: str | None = None) -> int:
    return _icon_value(_key_for_operator(idname, fallback_icon))


def _icon_button(layout, operator_id: str, icon_key: str, label_ja: str, label_en: str, *, fallback_icon: str = 'NONE', scale: float = 2.7, target: str | None = None):
    """Draw an icon-first operator button.

    The operator text is intentionally empty so the normal Blender button label
    consists only of the custom icon. Leaving emboss at its default lets the
    button body highlight on hover.
    """
    cell = layout.column(align=True)
    button_row = cell.row(align=True)
    button_row.alignment = 'CENTER'
    button_row.scale_y = scale
    kwargs = {"text": ""}
    icon_id = max(0, int(_icon_value(icon_key) or 0))
    if icon_id > 0:
        kwargs["icon_value"] = icon_id
    else:
        kwargs["icon"] = fallback_icon
    op = button_row.operator(operator_id, **kwargs)
    if target is not None:
        try:
            op.target = target
        except Exception:
            pass
    label_row = cell.row(align=True)
    label_row.alignment = 'CENTER'
    label_row.label(text=_t(label_ja, label_en))
    return op


def _draw_icon_row(layout, buttons: list[tuple[str, str, str, str, str]]) -> None:
    row = layout.row(align=True)
    for operator_id, icon_key, label_ja, label_en, fallback_icon in buttons:
        _icon_button(row, operator_id, icon_key, label_ja, label_en, fallback_icon=fallback_icon)


def _draw_pipeline_reference(layout) -> None:
    icon_id = max(0, int(_icon_value("pipeline") or 0))
    if icon_id <= 0:
        return
    box = layout.box()
    box.label(text=_t("視覚リファレンス", "Visual Reference"), icon='IMAGE_DATA')
    try:
        box.template_icon(icon_value=icon_id, scale=6.0)
    except Exception:
        pass
    box.label(text=_t("状態 → キュー → AOV → ファーム", "State → Queue → AOV → Farm"))


def _score_bar(score: int, width: int = 20) -> str:
    score = max(0, min(100, int(score)))
    filled = max(0, min(width, round(score / 100.0 * width)))
    return "█" * filled + "░" * (width - filled)


def _image_editor_header_noop(self, _context):
    return None


def _readiness_word(score: int, threshold: int, errors: int) -> str:
    if int(errors) > 0:
        return _t("停止", "Blocked")
    if int(score) >= max(95, int(threshold)):
        return _t("本番投入可", "Production Ready")
    if int(score) >= int(threshold):
        return _t("受け渡し可", "Handoff Ready")
    if int(score) >= 70:
        return _t("要確認", "Review Needed")
    return _t("未準備", "Not Ready")


def _image_editor_panel_clone(panel_cls: type, id_map: dict[str, str]):
    del panel_cls, id_map
    return None


PIPELINE_PRESET_ITEMS = _enum([
    ("SMART_DEFAULT", "統合標準", "Smart Default", "レンダー管理、命名、検証、ブリッジ出力を広く有効化する標準プリセットです。", "Balanced preset that enables render management, naming, validation, and bridge export."),
    ("LOOKDEV", "ルックデブ", "Lookdev", "HDRI、ライト、AOV、色管理、比較用バリアントとテイクを重視するルック開発向け設定です。", "Look-development preset focused on HDRI, lighting, AOVs, color management, and comparison variants."),
    ("FINAL_AOV", "最終AOV", "Final AOV", 'ビューティーだけでなく深度、ノーマル、ベクトル、IDなどの合成用エレメントを重視します。', "Final-output preset emphasizing compositing elements such as Depth, Normal, Vector, and IDs in addition to Beauty."),
    ("DATASET", "データセット生成", "Dataset", "機械学習・検証向けに、カメラ、フレーム、パス、メタデータを規則化して書き出します。", "Dataset preset that regularizes cameras, frames, passes, and metadata for ML or validation output."),
    ("FARM_HANDOFF", "ファーム受け渡し", "Farm Handoff", "Deadline、Flamenco、Tractor、Qubeなどへ渡しやすいジョブ分割とマニフェストを優先します。", "Farm handoff preset that prioritizes chunked jobs and manifests for Deadline, Flamenco, Tractor, Qube, and similar systems."),
    ("REALTIME_HANDOFF", "リアルタイム連携", "Realtime Handoff", "Unreal Movie Render QueueやUnity Recorderへ移しやすいサブサンプル、AOV、OCIO情報を出力します。", "Realtime handoff preset that exports subsampling, AOV, and OCIO data for Unreal Movie Render Queue or Unity Recorder."),
    ("USD_SUPERSET", "USD上位互換", "USD Superset", "Solaris、Hydra、Katana、Clarisse系の非破壊シーングラフ連携を意識した包括出力です。", "Superset preset for non-destructive scene-graph handoff to Solaris, Hydra, Katana, and Clarisse-style workflows."),
])

STATE_SYSTEM_ITEMS = _enum([
    ("BLENDER_SMART_VARIANTS", "Smart Renderバリアント", "Smart Render Variants", "Blender内ではSmart Renderのバリアントとテイクとキューを中心に状態を管理します。", "Use Smart Render variants and queues as the native Blender-side state system."),
    ("MAYA_RENDER_SETUP", "Maya Render Setup型", "Maya Render Setup", "MayaのRender Setupに近いコレクション、ルール、オーバーライドとしてマニフェスト化します。", "Export collection, rule, and override metadata shaped like Maya Render Setup."),
    ("MAX_STATE_SETS", "3ds Max State Sets型", "3ds Max State Sets", "3ds MaxのScene States、State Sets、Batch Renderに近いステート行として出力します。", "Export state rows shaped for 3ds Max Scene States, State Sets, and Batch Render."),
    ("C4D_TAKES", "Cinema 4D Takes型", "Cinema 4D Takes", "C4DのTake Systemとトークンを意識した階層テイクとして出力します。", "Export hierarchical takes and token naming data inspired by Cinema 4D Take System."),
    ("HOUDINI_TAKES_LOPS", "Houdini TakesとLOPs型", "Houdini Takes and LOPs", "Houdini Takes、Solaris、LOPs、PDGへ渡しやすい依存グラフを生成します。", "Export a dependency graph shaped for Houdini Takes, Solaris, LOPs, and PDG."),
])

BRIDGE_TARGET_ITEMS = _enum([
    ("GENERIC", "汎用マニフェスト", "Generic Manifest", "外部DCCやレンダーマネージャーが読み替えやすい共通JSONを書き出します。", "Write a generic JSON manifest that external DCCs and render managers can adapt."),
    ("MAYA_RENDER_SETUP", "Maya Render Setup", "Maya Render Setup", "MayaのRender Setup、AOV、Arnold系パイプラインへ渡すための構造を含めます。", "Include structures for Maya Render Setup, AOVs, and Arnold-style pipelines."),
    ("MAX_STATE_SETS", "3ds Max State Sets", "3ds Max State Sets", "State Sets、Batch Render、カメラ別パラメータ、トークン命名を含めます。", "Include State Sets, Batch Render, per-camera parameters, and token naming."),
    ("C4D_TAKES", "Cinema 4D Takes", "Cinema 4D Takes", "Take System、レンダーキューを実行、Team Render、トークンに合わせた情報を含めます。", "Include data for Take System, Run Render Queue, Team Render, and Tokens."),
    ("HOUDINI_SOLARIS", "Houdini SolarisとPDG", "Houdini Solaris and PDG", "Solaris、LOPs、Karma、TOPs、PDGワークアイテムに対応しやすい構造を含めます。", "Include structures for Solaris, LOPs, Karma, TOPs, and PDG work items."),
    ("USD_HYDRA", "USDとHydra", "USD and Hydra", "USD RenderSettings、AOV、Hydraデリゲート候補を含めます。", "Include USD RenderSettings, AOVs, and Hydra delegate hints."),
    ("KATANA", "Katana", "Katana", "Katanaのルックデブ、ライティング、Networked Interactive Rendering向け比較情報を含めます。", "Include comparison metadata for Katana lookdev, lighting, and networked interactive workflows."),
    ("CLARISSE_IFX", "Clarisse iFX", "Clarisse iFX", "Clarisse風の大規模アセンブリ、プログレッシブレンダー、インプレース合成情報を含めます。", "Include large-assembly, progressive-render, and in-place compositing metadata inspired by Clarisse iFX."),
    ("GOLAEM", "Golaem", "Golaem", "群衆キャッシュ、レンダー設定チェック、CrowdManager検証のための項目を含めます。", "Include crowd-cache, render-setting-check, and CrowdManager validation fields."),
    ("UNREAL_MRQ", "Unreal Movie Render Queue", "Unreal Movie Render Queue", "MRQの時間・空間サブサンプル、EXR、Stencil、OCIO連携を含めます。", "Include temporal and spatial subsampling, EXR, stencil, and OCIO metadata for MRQ."),
    ("UNITY_RECORDER", "Unity Recorder", "Unity Recorder", "Unity RecorderとHDRP AOV Recorderへ渡せる蓄積、AOV、連番出力情報を含めます。", "Include accumulation, AOV, and image-sequence metadata for Unity Recorder and HDRP AOV Recorder."),
    ("RENDERER_ECOSYSTEM", "レンダラーエコシステム", "Renderer Ecosystem", "RenderMan、LuxCoreRender、Radeon ProRender、POV-Ray、MoonRay、Hydraデリゲートなどの外部レンダラー前提情報を含めます。", "Include external renderer assumptions for RenderMan, LuxCoreRender, Radeon ProRender, POV-Ray, MoonRay, Hydra delegates, and similar systems."),
    ("AI_ASSET_PREP", "AIアセット準備連携", "AI Asset Prep Handoff", "Tripo AIなどの外部AIアセット準備、リトポ、テクスチャ、リギング、プレビュー工程へ渡せる状態情報を含めます。", "Include handoff metadata for external AI asset preparation, retopology, texture, rigging, and preview workflows such as Tripo AI-style tools."),
    ("PRISM_PIPELINE", "Prism Pipeline", "Prism Pipeline", "Prismなどの実行プラン Graph型パイプラインへ渡しやすいメタデータを含めます。", "Include metadata shaped for Prism-style execution-graph pipelines."),
])

FARM_TARGET_ITEMS = _enum([
    ("LOCAL_HEADLESS", "ローカルヘッドレス", "Local Headless", "Blenderをバックグラウンド起動するローカルバッチ実行用の定義です。", "Definition for local batch execution using background Blender."),
    ("FLAMENCO", "Flamenco", "Flamenco", "Blender Studio Flamencoへ渡しやすいジョブ、チャンク、依存関係を出力します。", "Export jobs, chunks, and dependencies shaped for Blender Studio Flamenco."),
    ("DEADLINE", "Deadline", "Deadline", "Deadline向けのジョブ、プラグイン情報、チャンク、優先度を出力します。", "Export job, plugin, chunk, and priority data for Deadline-style handoff."),
    ("TRACTOR", "Pixar Tractor", "Pixar Tractor", "Tractor向けのタスクグラフと依存関係を出力します。", "Export a task graph and dependencies for Tractor-style systems."),
    ("QUBE", "Qube", "Qube", "Qube向けのジョブ分割、CPU/GPUヒント、優先度を出力します。", "Export chunking, CPU/GPU hints, and priority data for Qube-style systems."),
    ("ROYAL_RENDER", "Royal Render", "Royal Render", "Royal Render向けの再試行、エラー処理、ライセンス配慮を含めます。", "Include retry, error-handling, and license-safety hints for Royal Render-style systems."),
    ("SMEDGE", "Smedge", "Smedge", "Smedge向けのキュー、優先度、フレーム範囲を出力します。", "Export queue, priority, and frame-range metadata for Smedge-style systems."),
    ("SHEEPIT", "SheepIt", "SheepIt", "SheepItのようなコミュニティファームへ渡すための軽量Blenderジョブ情報を含めます。", "Include lightweight Blender job metadata for SheepIt-style community farms."),
    ("CROWDRENDER", "Crowdrender", "Crowdrender", "CrowdrenderのLAN、P2P、同期レンダー向けの分割情報を含めます。", "Include chunk and synchronization data for Crowdrender-style LAN and P2P rendering."),
    ("TEAM_RENDER", "Team Render", "Team Render", "Cinema 4D Team Render風のLAN分散、ポート、クライアント前提情報を含めます。", "Include LAN distribution, port, and client assumptions for Team Render-style handoff."),
    ("GRIDMARKETS", "GridMarkets", "GridMarkets", "Houdini TOPs、PDG、予算停止、クラウド分散に近いメタデータを含めます。", "Include TOPs, PDG, budget-stop, and cloud-distribution metadata inspired by GridMarkets."),
    ("DROP_AND_RENDER", "Drop and Render", "Drop and Render", "Houdini PDGの失敗再開、依存関係維持、クラウド送信向け項目を含めます。", "Include failed-item resume, dependency preservation, and cloud-submission metadata for PDG handoff."),
    ("REBUSFARM", "RebusFarm", "RebusFarm", "RebusFarm風のプラグイン送信、連番、出力検証情報を含めます。", "Include plugin-submission, sequence, and output-validation metadata for RebusFarm-style handoff."),
    ("FOX_GARAGE_IRENDER", "商用クラウド総合", "Commercial Cloud Set", "Fox、Garage、iRenderなどへ手作業で渡しやすい汎用クラウド情報を含めます。", "Include generic cloud metadata for manual handoff to Fox, Garage, iRender, and similar services."),
])

VIEW_LAYER_STRATEGY_ITEMS = _enum([
    ("KEEP", "維持", "Keep", "既存のビューレイヤーを変更せず、診断とマニフェストだけに使います。", "Keep existing View Layers and use them only for diagnostics and manifest data."),
    ("CREATE_STANDARD", "標準ビューレイヤーを作成", "Create Standard View Layers", "ビューティー、マット、テクニカル、データセットの標準ビューレイヤーを必要な時だけ作成します。", "Create Beauty, Matte, Technical, and Dataset View Layers only when needed."),
    ("RENDERABLE_ONLY", "レンダー可能のみ", "Renderable Only", "レンダーに使えるカメラとビューレイヤーだけをキュー化する方針です。", "Queue only renderable cameras and View Layers."),
])

ACCURACY_MODE_ITEMS = _enum([
    ("FAST", "高速", "Fast", "軽量診断を優先し、大規模シーンでも待ち時間を抑えます。", "Prioritize lightweight diagnostics to keep large scenes responsive."),
    ("BALANCED", "標準精度", "Balanced", "品質、速度、ファーム受け渡しのバランスを取った推奨設定です。", "Balanced recommendations for quality, speed, and farm handoff."),
    ("STRICT", "厳密", "Strict", "欠落、上書き、AOV不足、ファーム失敗要因をより厳しく警告します。", "Warn more aggressively about missing data, overwrites, AOV gaps, and farm failure risks."),
    ("PRODUCTION", "本番", "Production", "夜間レンダー、クラウドファーム、外部DCC連携向けに最も安全寄りの判定を行います。", "Use the safest checks for overnight rendering, cloud farms, and external DCC handoff."),
])

# The document asks for broad compatibility across DCC render managers, take/state systems,
# farms, real-time render queues, and high-density lookdev tools.  The list below is the
# canonical Render Pipeline Manager coverage matrix used by the manifest and help popup.
COVERAGE_GROUPS: tuple[dict[str, Any], ...] = (
    {
        "id": "blender_native",
        "label_ja": "Blender標準レンダー基盤",
        "label_en": "Blender Native Render Base",
        "mode": "native",
        "features": ["View Layers", "Collections", "Render Passes", "AOV", "Freestyle", "Line Art", "OpenColorIO", "Cycles", "EEVEE", "Compositor File Output"],
        "adapter_ja": "ビューレイヤー、レンダーパス、出力ノード、色管理をBlender内で直接診断・設定します。",
        "adapter_en": "Diagnoses and configures View Layers, Render Passes, output nodes, and color management directly in Blender.",
    },
    {
        "id": "context_state_managers",
        "label_ja": "ステート・テイク・コンテキスト管理",
        "label_en": "State, Take, and Context Management",
        "mode": "native_plus_manifest",
        "features": ["Renderset context", "RenderStack node-style variants", "Maya Render Setup", "3ds Max Scene States", "3ds Max State Sets", "Cinema 4D Takes", "Houdini Takes"],
        "adapter_ja": "Smart Renderバリアントを上位抽象にし、外部DCC向けには状態・継承・オーバーライドをJSON化します。",
        "adapter_en": "Uses Smart Render variants as the superset abstraction and exports state, inheritance, and overrides as JSON for external DCCs.",
    },
    {
        "id": "batch_queue",
        "label_ja": "バッチレンダーとカメラキュー",
        "label_en": "Batch Render and Camera Queue",
        "mode": "native_plus_script",
        "features": ["Render+", "Batch Render Creator", "Batch Render Wizard", "Overnight Batch Render", "Batch Camera Render", "Domino Maya Rendering Tool", "brender", "headless Blender"],
        "adapter_ja": "カメラ、ビューレイヤー、バリアントとテイク、フレーム範囲からSmart Renderキューとヘッドレススクリプトを生成します。",
        "adapter_en": "Builds Smart Render queues and headless scripts from cameras, View Layers, variants, and frame ranges.",
    },
    {
        "id": "tokens_outputs",
        "label_ja": "トークン命名と出力衝突回避",
        "label_en": "Token Naming and Output Collision Safety",
        "mode": "native_plus_manifest",
        "features": ["Cinema 4D Tokens", "Render Naming", "project tokens", "camera tokens", "take tokens", "frame tokens", "date tokens", "collision-safe output"],
        "adapter_ja": "シーン、ショット、カメラ、テイク、フレーム、AOV、日付をトークン化し、上書き事故を避ける出力規則を生成します。",
        "adapter_en": "Tokenizes scene, shot, camera, take, frame, AOV, and date values to generate overwrite-safe output rules.",
    },
    {
        "id": "aov_compositing",
        "label_ja": "AOV・Render Elements・合成連携",
        "label_en": "AOV, Render Elements, and Compositing",
        "mode": "native_plus_manifest",
        "features": ["Render Passes", "3ds Max Render Elements", "MRQ render passes", "Unity HDRP AOV Recorder", "Multilayer EXR", "オブジェクトID", "World Depth", "Motion Vectors", "Cryptomatte"],
        "adapter_ja": "Blenderパスとコンポジターファイル出力を、Render ElementsやMRQ/RecorderのAOV概念へ写像します。",
        "adapter_en": "Maps Blender passes and compositor file outputs to Render Elements and MRQ/Recorder AOV concepts.",
    },
    {
        "id": "scene_assembly",
        "label_ja": "大規模シーンと表現切替",
        "label_en": "Large Scene Assembly and Representation Switching",
        "mode": "manifest_plus_validation",
        "features": ["Maya Scene Assembly", "proxy representation", "render representation", "USD references", "Clarisse high-density assembly", "Katana lookdev contexts", "Golaem crowd caches"],
        "adapter_ja": "プロキシ/renderコレクション、USD参照、群衆キャッシュ、巨大背景向けの検証情報をマニフェストへ含めます。",
        "adapter_en": "Includes proxy/render collection, USD reference, crowd-cache, and large-environment validation metadata in the manifest.",
    },
    {
        "id": "usd_pdg_pipeline",
        "label_ja": "USD・Solaris・PDG依存グラフ",
        "label_en": "USD, Solaris, and PDG Dependency Graph",
        "mode": "manifest",
        "features": ["USD RenderSettings", "Hydra", "Solaris LOPs", "Houdini TOPs", "PDG work items", "ImageMagick TOP", "FFmpeg TOP", "resume failed work items"],
        "adapter_ja": "キューをワークアイテム化し、キャッシュ、レンダー、検証、エンコードの依存関係をJSONへ出力します。",
        "adapter_en": "Turns the queue into work items and exports cache, render, validation, and encode dependencies as JSON.",
    },
    {
        "id": "network_farms",
        "label_ja": "ネットワーク・クラウドファーム連携",
        "label_en": "Network and Cloud Farm Handoff",
        "mode": "manifest_plus_script",
        "features": ["Flamenco", "SheepIt", "Crowdrender", "Deadline", "Royal Render", "Qube", "Smedge", "Tractor", "GridMarkets", "Drop and Render", "RebusFarm", "Fox Renderfarm", "GarageFarm", "iRender"],
        "adapter_ja": "実送信ではなく、各ファームが解釈しやすいジョブ、チャンク、優先度、再試行、コストヒントを生成します。",
        "adapter_en": "Generates job, chunk, priority, retry, and cost-hint data that render farms can adapt; it does not submit externally by itself.",
    },
    {
        "id": "realtime_offline",
        "label_ja": "リアルタイムエンジン高品質出力",
        "label_en": "Realtime Engine Offline-Quality Output",
        "mode": "manifest",
        "features": ["Unreal Movie Render Queue", "Temporal Sub-Sampling", "Spatial Sub-Sampling", "EXR", "Stencil Layers", "Unity Recorder", "Unity AOV Recorder", "Accumulation"],
        "adapter_ja": "MRQやUnity Recorderへ渡しやすいサブサンプル、蓄積、EXR、AOV、OCIO情報を出力します。",
        "adapter_en": "Exports subsampling, accumulation, EXR, AOV, and OCIO metadata for MRQ and Unity Recorder handoff.",
    },
    {
        "id": "renderer_ecosystem",
        "label_ja": "レンダラーエコシステム",
        "label_en": "Renderer Ecosystem",
        "mode": "manifest",
        "features": ["Cycles", "EEVEE", "Arnold", "RenderMan", "Redshift", "V-Ray", "Corona", "LuxCoreRender", "Radeon ProRender", "POV-Ray", "MoonRay", "Hydra delegates"],
        "adapter_ja": "Blender内で直接実行できない外部レンダラーも、ジョブ、AOV、デバイス、Hydra/USD連携ヒントとしてマニフェストへ記録します。",
        "adapter_en": "External renderers that cannot be executed directly in Blender are recorded as job, AOV, device, and Hydra/USD handoff hints in the manifest.",
    },
    {
        "id": "asset_pipeline_ai",
        "label_ja": "アセット準備とAI連携前提",
        "label_en": "Asset Preparation and AI Handoff Assumptions",
        "mode": "manifest_plus_validation",
        "features": ["synthetic data rendering", "dataset metadata", "AI asset-prep placeholders", "preview generation", "retopology handoff", "texture readiness", "rigging readiness"],
        "adapter_ja": "外部AI生成そのものは実行せず、データセット生成、プレビュー、テクスチャ、リトポ、リギング準備状態を後工程へ渡せる情報としてまとめます。",
        "adapter_en": "It does not run external AI generation, but records dataset, preview, texture, retopology, and rigging readiness as handoff metadata for downstream tools.",
    },
    {
        "id": "preflight_quality",
        "label_ja": "プリフライト・品質・失敗抑制",
        "label_en": "Preflight, Quality, and Failure Prevention",
        "mode": "native_plus_manifest",
        "features": ["Golaem Check Render Settings", "missing texture checks", "output path checks", "placeholder policy", "overwrite prevention", "retry policy", "multi-GPU hints", "budget hints", "AI asset-prep placeholders"],
        "adapter_ja": "レンダー前にカメラ、出力、欠落画像、上書き、フレーム範囲、GPU/メモリヒントを診断します。",
        "adapter_en": "Checks cameras, outputs, missing images, overwrite risk, frame ranges, and GPU/memory hints before rendering.",
    },
)


FARM_TARGET_PROFILES: dict[str, dict[str, Any]] = {
    "LOCAL_HEADLESS": {"chunk": 25, "retry": 0, "max_concurrency": 2, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": False},
    "FLAMENCO": {"chunk": 20, "retry": 1, "max_concurrency": 64, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": False},
    "DEADLINE": {"chunk": 10, "retry": 2, "max_concurrency": 512, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "TRACTOR": {"chunk": 10, "retry": 2, "max_concurrency": 512, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "QUBE": {"chunk": 10, "retry": 2, "max_concurrency": 256, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "ROYAL_RENDER": {"chunk": 10, "retry": 3, "max_concurrency": 256, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "SMEDGE": {"chunk": 15, "retry": 2, "max_concurrency": 128, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "SHEEPIT": {"chunk": 1, "retry": 1, "max_concurrency": 999, "requires_saved_blend": True, "supports_resume": False, "cost_sensitive": False},
    "CROWDRENDER": {"chunk": 5, "retry": 1, "max_concurrency": 32, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": False},
    "TEAM_RENDER": {"chunk": 10, "retry": 1, "max_concurrency": 64, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": False},
    "GRIDMARKETS": {"chunk": 5, "retry": 2, "max_concurrency": 1000, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "DROP_AND_RENDER": {"chunk": 5, "retry": 2, "max_concurrency": 1000, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "REBUSFARM": {"chunk": 10, "retry": 2, "max_concurrency": 1000, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
    "FOX_GARAGE_IRENDER": {"chunk": 5, "retry": 2, "max_concurrency": 2000, "requires_saved_blend": True, "supports_resume": True, "cost_sensitive": True},
}

BRIDGE_TARGET_PROFILES: dict[str, dict[str, Any]] = {
    "GENERIC": {"schema": "portable_json", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "MAYA_RENDER_SETUP": {"schema": "collections_overrides", "strict_paths": True, "supports_aov": True, "supports_takes": False},
    "MAX_STATE_SETS": {"schema": "state_rows", "strict_paths": True, "supports_aov": True, "supports_takes": False},
    "C4D_TAKES": {"schema": "hierarchical_takes_tokens", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "HOUDINI_SOLARIS": {"schema": "lop_pdg_work_items", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "USD_HYDRA": {"schema": "usd_render_settings", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "KATANA": {"schema": "lookdev_contexts", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "CLARISSE_IFX": {"schema": "assembly_layers", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "GOLAEM": {"schema": "crowd_cache_render_checks", "strict_paths": True, "supports_aov": True, "supports_takes": False},
    "UNREAL_MRQ": {"schema": "mrq_settings", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "UNITY_RECORDER": {"schema": "recorder_aov", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "RENDERER_ECOSYSTEM": {"schema": "renderer_handoff", "strict_paths": True, "supports_aov": True, "supports_takes": True},
    "AI_ASSET_PREP": {"schema": "asset_readiness", "strict_paths": True, "supports_aov": False, "supports_takes": False},
    "PRISM_PIPELINE": {"schema": "execution_graph", "strict_paths": True, "supports_aov": True, "supports_takes": True},
}


def _default_output_dir() -> str:
    try:
        root = Path(extension_user_root(create=True)) / "render_pipeline"
    except Exception:
        root = Path(default_output_root(create=True)) / "render_pipeline"
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return str(root)


def _resolve_output_dir(settings, *, create: bool = True) -> str:
    raw = str(getattr(settings, "output_dir", "") or "").strip()
    if raw:
        path = Path(abspath(raw)).expanduser()
    else:
        path = Path(_default_output_dir())
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return str(path)


def _safe_getattr(obj: Any, name: str, default: Any = None) -> Any:
    try:
        return getattr(obj, name, default)
    except Exception:
        return default


def _set_if_has(obj: Any, name: str, value: Any) -> bool:
    try:
        if obj is not None and hasattr(obj, name):
            setattr(obj, name, value)
            return True
    except Exception:
        return False
    return False


def _scene(context):
    return getattr(context, "scene", None) if context is not None else getattr(bpy.context, "scene", None)


def _wm(context):
    return getattr(context, "window_manager", None) if context is not None else getattr(bpy.context, "window_manager", None)


def get_settings(context=None):
    manager = _wm(context)
    if manager is None:
        return None
    return getattr(manager, WM_SETTINGS_PROPERTY, None)


def _frames(scene, settings) -> list[int]:
    start = int(_safe_getattr(scene, "frame_start", 1) or 1)
    end = int(_safe_getattr(scene, "frame_end", start) or start)
    if end < start:
        start, end = end, start
    if bool(getattr(settings, "limit_manifest_frames", True)) and (end - start) > 1000:
        # Keep manifests inspectable.  The full numeric range is still written as metadata.
        return [start, end]
    return list(range(start, end + 1))


def _frame_chunks(scene, settings) -> list[dict[str, int]]:
    start = int(_safe_getattr(scene, "frame_start", 1) or 1)
    end = int(_safe_getattr(scene, "frame_end", start) or start)
    if end < start:
        start, end = end, start
    size = max(1, int(getattr(settings, "frame_chunk_size", 10) or 10))
    chunks: list[dict[str, int]] = []
    cursor = start
    while cursor <= end:
        chunk_end = min(end, cursor + size - 1)
        chunks.append({"start": cursor, "end": chunk_end, "count": chunk_end - cursor + 1})
        cursor = chunk_end + 1
        if len(chunks) > 2000:
            break
    return chunks


def _camera_names(scene) -> list[str]:
    names: list[str] = []
    try:
        for obj in getattr(scene, "objects", []) or []:
            if str(getattr(obj, "type", "") or "") == "CAMERA":
                names.append(str(getattr(obj, "name", "Camera") or "Camera"))
    except Exception:
        pass
    if not names:
        try:
            for obj in getattr(bpy.data, "objects", []) or []:
                if str(getattr(obj, "type", "") or "") == "CAMERA":
                    names.append(str(getattr(obj, "name", "Camera") or "Camera"))
        except Exception:
            pass
    return sorted(dict.fromkeys(names))


def _view_layer_names(scene) -> list[str]:
    out: list[str] = []
    try:
        for layer in getattr(scene, "view_layers", []) or []:
            out.append(str(getattr(layer, "name", "ViewLayer") or "ViewLayer"))
    except Exception:
        pass
    return out or ["ViewLayer"]


def _variant_rows(scene) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    variants = getattr(scene, "srr_variants", None)
    if variants is None:
        return rows
    try:
        for item in variants:
            rows.append({
                "name": str(getattr(item, "name", "") or "Variant"),
                "enabled": bool(getattr(item, "enabled", True)),
                "parent": str(getattr(item, "parent_variant_name", "") or ""),
                "camera": str(getattr(item, "camera_name", "") or ""),
                "view_layer": str(getattr(item, "view_layer_name", "") or ""),
                "engine": str(getattr(item, "engine_mode", "SCENE") or "SCENE"),
                "quality": str(getattr(item, "quality_mode", "SCENE") or "SCENE"),
                "pass_bundle": str(getattr(item, "pass_bundle", "SCENE") or "SCENE"),
                "material_override": str(getattr(item, "material_override_name", "") or ""),
                "world_override": str(getattr(item, "world_override_name", "") or ""),
                "proxy_selectors": str(getattr(item, "proxy_collection_selectors", "") or ""),
                "render_selectors": str(getattr(item, "render_collection_selectors", "") or ""),
                "job_override": str(getattr(item, "job_name_override", "") or ""),
            })
    except Exception:
        pass
    return rows


def _queue_rows(scene, settings) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    queue = getattr(scene, "srr_queue", None)
    try:
        for item in queue or []:
            rows.append({"enabled": bool(getattr(item, "enabled", True)), "source_mode": str(getattr(item, "source_mode", "PAIR") or "PAIR"), "camera": str(getattr(item, "camera_name", "") or ""), "view_layer": str(getattr(item, "view_layer_name", "") or ""), "variant": str(getattr(item, "variant_name", "") or ""), "label": str(getattr(item, "label", "") or "")})
    except Exception:
        rows = []
    if rows:
        return _filter_renderable_rows(scene, rows, settings)
    return _generated_queue_rows(scene, settings)


def _generated_queue_rows(scene, settings) -> list[dict[str, Any]]:
    """Queue rows derived from the scene's variants, or else its cameras and View Layers."""
    rows: list[dict[str, Any]] = []
    cameras = _camera_names(scene)
    layers = _view_layer_names(scene)
    active_camera_name = str(getattr(getattr(scene, "camera", None), "name", "") or "")
    fallback_camera = active_camera_name or (cameras[0] if cameras else "")
    fallback_layer = layers[0] if layers else "ViewLayer"
    variants = _variant_rows(scene) if bool(getattr(settings, "enable_variant_take_graph", True)) else []
    for variant in variants:
        if not bool(variant.get("enabled", True)):
            continue
        cam = str(variant.get("camera") or fallback_camera)
        layer = str(variant.get("view_layer") or fallback_layer)
        label = safe_name(str(variant.get("job_override") or variant.get("name") or f"{cam}_{layer}"))
        rows.append({"enabled": True, "source_mode": "VARIANT", "camera": cam, "view_layer": layer, "variant": str(variant.get("name") or ""), "label": label})
    if rows:
        return _filter_renderable_rows(scene, rows, settings)
    for cam in cameras or [fallback_camera]:
        for layer in layers:
            rows.append({"enabled": True, "source_mode": "PAIR", "camera": cam, "view_layer": layer, "variant": "", "label": safe_name(f"{cam or 'SceneCamera'}_{layer}")})
    return _filter_renderable_rows(scene, rows, settings)


def _filter_renderable_rows(scene, rows: list[dict[str, Any]], settings) -> list[dict[str, Any]]:
    if str(getattr(settings, "view_layer_strategy", "KEEP") or "KEEP") != "RENDERABLE_ONLY":
        return rows
    cameras = set(_camera_names(scene))
    layers = set(_view_layer_names(scene))
    filtered: list[dict[str, Any]] = []
    for row in rows:
        cam = str(row.get("camera") or "")
        layer = str(row.get("view_layer") or "")
        if cam and cameras and cam not in cameras:
            continue
        if layer and layers and layer not in layers:
            continue
        filtered.append(row)
    return filtered or rows


def _pass_state(scene) -> dict[str, Any]:
    state: dict[str, Any] = {}
    for layer in getattr(scene, "view_layers", []) or []:
        layer_data: dict[str, bool] = {}
        for attr in ("use_pass_combined", "use_pass_z", "use_pass_mist", "use_pass_normal", "use_pass_vector", "use_pass_position", "use_pass_uv", "use_pass_object_index", "use_pass_material_index", "use_pass_diffuse_color", "use_pass_glossy_color", "use_pass_emit", "use_pass_environment", "use_pass_shadow", "use_pass_cryptomatte_object", "use_pass_cryptomatte_material", "use_pass_cryptomatte_asset"):
            if hasattr(layer, attr):
                try:
                    layer_data[attr] = bool(getattr(layer, attr))
                except Exception:
                    pass
        state[str(getattr(layer, "name", "ViewLayer") or "ViewLayer")] = layer_data
    return state


def _missing_image_paths(limit: int = 200) -> list[str]:
    missing: list[str] = []
    try:
        images = list(getattr(bpy.data, "images", []) or [])
    except Exception:
        images = []
    for image in images:
        try:
            filepath = str(getattr(image, "filepath", "") or "").strip()
            source = str(getattr(image, "source", "") or "")
            if not filepath or source in {"GENERATED", "VIEWER"}:
                continue
            resolved = bpy.path.abspath(filepath)
            if resolved and not os.path.exists(resolved):
                missing.append(resolved)
                if len(missing) >= limit:
                    break
        except Exception:
            continue
    return missing


def _scene_statistics(scene) -> dict[str, int]:
    counts = {"objects": 0, "meshes": 0, "cameras": 0, "lights": 0, "materials": 0, "collections": 0, "images": 0, "worlds": 0}
    try:
        objects = list(getattr(scene, "objects", []) or [])
        counts["objects"] = len(objects)
        counts["meshes"] = sum(1 for obj in objects if str(getattr(obj, "type", "") or "") == "MESH")
        counts["cameras"] = sum(1 for obj in objects if str(getattr(obj, "type", "") or "") == "CAMERA")
        counts["lights"] = sum(1 for obj in objects if str(getattr(obj, "type", "") or "") in {"LIGHT", "SUN"})
    except Exception:
        pass
    for key, data_name in (("materials", "materials"), ("collections", "collections"), ("images", "images"), ("worlds", "worlds")):
        try:
            counts[key] = len(list(getattr(bpy.data, data_name, []) or []))
        except Exception:
            pass
    return counts


def _frame_range(scene) -> tuple[int, int, int]:
    start = int(_safe_getattr(scene, "frame_start", 1) or 1)
    end = int(_safe_getattr(scene, "frame_end", start) or start)
    if end < start:
        start, end = end, start
    return start, end, max(1, end - start + 1)


def _scene_complexity(scene) -> dict[str, Any]:
    stats = _scene_statistics(scene)
    vertices = polygons = modifiers = hidden_render = 0
    linked_libraries: set[str] = set()
    try:
        objects = list(getattr(scene, "objects", []) or [])
    except Exception:
        objects = []
    for obj in objects:
        try:
            hidden_render += 1 if bool(getattr(obj, "hide_render", False)) else 0
        except Exception:
            pass
        try:
            modifiers += len(list(getattr(obj, "modifiers", []) or []))
        except Exception:
            pass
        data = _safe_getattr(obj, "data", None)
        if data is not None:
            try: vertices += len(getattr(data, "vertices", []) or [])
            except Exception: pass
            try: polygons += len(getattr(data, "polygons", []) or [])
            except Exception: pass
        try:
            lib = getattr(getattr(obj, "library", None), "filepath", "") or ""
            if lib: linked_libraries.add(str(lib))
        except Exception:
            pass
    score = min(35, polygons // 100000) + min(20, vertices // 500000) + min(20, modifiers // 50) + min(15, stats.get("images", 0) // 50) + min(10, len(linked_libraries))
    tier = "heavy" if score >= 55 else "medium" if score >= 25 else "small"
    return {"vertices": vertices, "polygons": polygons, "modifiers": modifiers, "hidden_render_objects": hidden_render, "linked_libraries": len(linked_libraries), "complexity_score": int(score), "complexity_tier": tier}


def _expected_aov_names(settings) -> list[str]:
    base = ["Beauty"]
    if bool(getattr(settings, "enable_aov_bundle", True)):
        base.extend(["Depth", "Normal", "Vector", "オブジェクトID", "マテリアルID"])
    preset = str(getattr(settings, "pipeline_preset", "SMART_DEFAULT") or "SMART_DEFAULT")
    bridge = str(getattr(settings, "bridge_target", "GENERIC") or "GENERIC")
    if preset in {"FINAL_AOV", "DATASET", "USD_SUPERSET", "REALTIME_HANDOFF"} or bridge in {"UNREAL_MRQ", "UNITY_RECORDER", "USD_HYDRA", "HOUDINI_SOLARIS"}:
        base.extend(["Cryptomatte Object", "Cryptomatte Material", "Mist", "UV", "Position"])
    if preset in {"FINAL_AOV", "LOOKDEV", "USD_SUPERSET"}:
        base.extend(["Diffuse Color", "Glossy Color", "Emission", "Environment", "Shadow"])
    out: list[str] = []
    for item in base:
        if item not in out: out.append(item)
    return out


_AOV_TO_ATTRS: dict[str, tuple[str, ...]] = {"Beauty": ("use_pass_combined",), "Depth": ("use_pass_z",), "Normal": ("use_pass_normal",), "Vector": ("use_pass_vector",), "オブジェクトID": ("use_pass_object_index",), "マテリアルID": ("use_pass_material_index",), "Cryptomatte Object": ("use_pass_cryptomatte_object",), "Cryptomatte Material": ("use_pass_cryptomatte_material",), "Mist": ("use_pass_mist",), "UV": ("use_pass_uv",), "Position": ("use_pass_position",), "Diffuse Color": ("use_pass_diffuse_color",), "Glossy Color": ("use_pass_glossy_color",), "Emission": ("use_pass_emit",), "Environment": ("use_pass_environment",), "Shadow": ("use_pass_shadow",)}


def _aov_coverage(scene, settings) -> dict[str, Any]:
    expected = _expected_aov_names(settings)
    expected_total = max(1, len(expected))
    layers: list[dict[str, Any]] = []
    enabled_total = 0
    try: layer_iter = list(getattr(scene, "view_layers", []) or [])
    except Exception: layer_iter = []
    if not layer_iter:
        return {"expected": expected, "coverage_percent": 0, "layers": [], "missing_by_layer": {"<none>": expected}}
    missing_by_layer: dict[str, list[str]] = {}
    for layer in layer_iter:
        layer_name = str(getattr(layer, "name", "ViewLayer") or "ViewLayer")
        enabled, missing = [], []
        for aov in expected:
            attrs = _AOV_TO_ATTRS.get(aov, ())
            ok = not attrs
            for attr in attrs:
                if hasattr(layer, attr):
                    try: ok = ok or bool(getattr(layer, attr))
                    except Exception: pass
            (enabled if ok else missing).append(aov)
        enabled_total += len(enabled)
        if missing: missing_by_layer[layer_name] = missing
        layers.append({"name": layer_name, "enabled": enabled, "missing": missing, "coverage_percent": round(100.0 * len(enabled) / expected_total, 2)})
    return {"expected": expected, "coverage_percent": round(100.0 * enabled_total / max(1, expected_total * len(layer_iter)), 2), "layers": layers, "missing_by_layer": missing_by_layer}


def _image_format_extension(scene) -> str:
    try:
        from ..compat import IMAGE_FORMAT_EXTENSIONS
        image_settings = getattr(getattr(scene, "render", None), "image_settings", None)
        fmt = str(getattr(image_settings, "file_format", "PNG") or "PNG")
        return str(IMAGE_FORMAT_EXTENSIONS.get(fmt, fmt.lower() or "png"))
    except Exception:
        return "png"


def _token_values(scene, settings, row: dict[str, Any] | None = None, *, frame: int | None = None, aov: str = "Beauty") -> dict[str, str]:
    row = row or {}
    scene_name = str(getattr(scene, "name", "Scene") or "Scene")
    blend_path = str(getattr(bpy.data, "filepath", "") or "")
    project = Path(blend_path).stem if blend_path else "untitled"
    camera = str(row.get("camera") or getattr(getattr(scene, "camera", None), "name", "Camera") or "Camera")
    view_layer = str(row.get("view_layer") or "ViewLayer")
    variant = str(row.get("variant") or row.get("label") or "default")
    frame_text = str(int(frame if frame is not None else int(_safe_getattr(scene, "frame_start", 1) or 1))).zfill(4)
    renderer = str(getattr(getattr(scene, "render", None), "engine", "") or "BLENDER")
    job = str(getattr(settings, "job_name", "") or scene_name)
    return {"project": project, "scene": scene_name, "shot": job, "job": job, "camera": camera or "Camera", "view_layer": view_layer or "ViewLayer", "variant": variant or "default", "take": variant or "default", "parent_variant": "", "frame": frame_text, "pass": str(aov or "Beauty"), "renderer": renderer, "date": datetime.now().strftime("%Y%m%d"), "time": datetime.now().strftime("%H%M%S")}


def _resolve_template(template: str, scene, settings, row: dict[str, Any] | None = None, *, frame: int | None = None, aov: str = "Beauty") -> str:
    text = str(template or "{scene}_{camera}_{view_layer}_{variant}_{frame}")
    for key, value in _token_values(scene, settings, row, frame=frame, aov=aov).items():
        text = text.replace("{" + key + "}", str(value))
    return safe_name(text)


def _output_prediction(scene, settings, *, limit: int = 500) -> dict[str, Any]:
    if scene is None:
        return {"samples": [], "duplicates": [], "warnings": [_t("シーンがありません。", "No active scene.")], "estimated_file_count": 0, "collision_count": 0, "max_path_length": 0}
    rows = [row for row in _queue_rows(scene, settings) if bool(row.get("enabled", True))]
    aovs = _expected_aov_names(settings) if bool(getattr(settings, "enable_aov_bundle", True)) else ["Beauty"]
    start, end, frame_count = _frame_range(scene)
    ext = _image_format_extension(scene)
    output_root = Path(_resolve_output_dir(settings, create=False))
    template = str(getattr(settings, "naming_template", "") or "{scene}_{camera}_{view_layer}_{variant}_{frame}")
    max_len_setting = max(40, int(getattr(settings, "max_output_path_length", 240) or 240))
    samples, duplicates, long_paths, invalid_names = [], [], [], []
    seen: dict[str, int] = {}
    frame_samples = [start] if start == end else [start, end]
    estimated_file_count = len(rows) * frame_count * max(1, len(aovs))
    max_path_len = 0
    for row in rows:
        for frame in frame_samples:
            for aov in aovs:
                filename = _resolve_template(template, scene, settings, row, frame=frame, aov=aov)
                if bool(getattr(settings, "enable_aov_bundle", True)) and aov != "Beauty" and "{pass}" not in template:
                    filename = safe_name(f"{filename}_{aov}")
                path = str(output_root / str(row.get("label") or "job") / f"{filename}.{ext}")
                norm = os.path.normcase(os.path.normpath(path))
                seen[norm] = seen.get(norm, 0) + 1
                if seen[norm] == 2 and len(duplicates) < 25: duplicates.append(path)
                max_path_len = max(max_path_len, len(path))
                if len(path) > max_len_setting and len(long_paths) < 25: long_paths.append(path)
                if any(ch in Path(filename).name for ch in '<>:"/\\|?*') and len(invalid_names) < 25: invalid_names.append(filename)
                if len(samples) < limit: samples.append({"camera": row.get("camera", ""), "view_layer": row.get("view_layer", ""), "variant": row.get("variant", ""), "frame": frame, "aov": aov, "path": path})
    warnings: list[str] = []
    if duplicates: warnings.append(_t(f"出力パス衝突候補が {len(duplicates)} 件あります。命名テンプレートへ {{camera}}、{{view_layer}}、{{variant}}、{{pass}} を含めてください。", f"Found {len(duplicates)} possible output path collision(s). Include {{camera}}, {{view_layer}}, {{variant}}, and {{pass}} in the naming template."))
    if long_paths: warnings.append(_t(f"長すぎる出力パス候補が {len(long_paths)} 件あります。", f"Found {len(long_paths)} output path candidate(s) that are too long."))
    if invalid_names: warnings.append(_t(f"ファイル名に使えない文字が残った候補が {len(invalid_names)} 件あります。", f"Found {len(invalid_names)} candidate filename(s) with invalid characters."))
    return {"estimated_file_count": estimated_file_count, "sample_count": len(samples), "samples": samples, "duplicates": duplicates, "long_paths": long_paths, "invalid_names": invalid_names, "warnings": warnings, "collision_count": max(0, sum(count - 1 for count in seen.values() if count > 1)), "max_path_length": max_path_len, "path_length_limit": max_len_setting}


def _adapter_profile(settings) -> dict[str, Any]:
    farm = str(getattr(settings, "farm_target", "LOCAL_HEADLESS") or "LOCAL_HEADLESS")
    bridge = str(getattr(settings, "bridge_target", "GENERIC") or "GENERIC")
    farm_profile = dict(FARM_TARGET_PROFILES.get(farm) or FARM_TARGET_PROFILES["LOCAL_HEADLESS"])
    bridge_profile = dict(BRIDGE_TARGET_PROFILES.get(bridge) or BRIDGE_TARGET_PROFILES["GENERIC"])
    return {"farm_target": farm, "farm_profile": farm_profile, "bridge_target": bridge, "bridge_profile": bridge_profile, "recommended_chunk_size": int(farm_profile.get("chunk", 10) or 10), "recommended_retry_count": int(farm_profile.get("retry", 1) or 1), "recommended_max_concurrency": int(farm_profile.get("max_concurrency", 1) or 1)}


def _adaptive_recommendations(scene, settings) -> dict[str, Any]:
    start, end, frame_count = _frame_range(scene)
    complexity = _scene_complexity(scene)
    profile = _adapter_profile(settings)
    current_chunk = max(1, int(getattr(settings, "frame_chunk_size", 10) or 10))
    recommended = int(profile.get("recommended_chunk_size", 10) or 10)
    mode = str(getattr(settings, "accuracy_mode", "BALANCED") or "BALANCED")
    if frame_count <= 1: recommended = 1
    elif complexity.get("complexity_tier") == "heavy": recommended = max(1, min(recommended, 5))
    elif mode in {"STRICT", "PRODUCTION"}: recommended = max(1, min(recommended, 10))
    elif mode == "FAST": recommended = min(max(recommended, 25), max(1, frame_count))
    recommended = max(1, min(recommended, max(1, frame_count)))
    recommended_concurrency = max(1, min(int(profile.get("recommended_max_concurrency", 1) or 1), int(getattr(settings, "concurrent_tasks", 1) or 1) if mode in {"STRICT", "PRODUCTION"} else 4))
    preset = str(getattr(settings, "pipeline_preset", "SMART_DEFAULT") or "SMART_DEFAULT")
    recommended_temporal = int(getattr(settings, "temporal_subsamples", 1) or 1)
    recommended_spatial = int(getattr(settings, "spatial_subsamples", 1) or 1)
    recommended_accum = int(getattr(settings, "accumulation_samples", 1) or 1)
    if preset in {"REALTIME_HANDOFF", "FINAL_AOV"}:
        recommended_temporal = max(recommended_temporal, 8 if mode in {"STRICT", "PRODUCTION"} else 4)
        recommended_spatial = max(recommended_spatial, 2)
        recommended_accum = max(recommended_accum, 16 if mode in {"STRICT", "PRODUCTION"} else 8)
    return {"frame_start": start, "frame_end": end, "frame_count": frame_count, "current_chunk_size": current_chunk, "recommended_chunk_size": recommended, "recommended_retry_count": max(int(getattr(settings, "retry_count", 1) or 1), int(profile.get("recommended_retry_count", 1) or 1)), "recommended_concurrent_tasks": recommended_concurrency, "recommended_temporal_subsamples": recommended_temporal, "recommended_spatial_subsamples": recommended_spatial, "recommended_accumulation_samples": recommended_accum, "complexity": complexity, "adapter_profile": profile}


def _quality_model(scene, settings) -> dict[str, Any]:
    warnings, errors = _diagnostics(scene, settings)
    aov = _aov_coverage(scene, settings)
    pred = _output_prediction(scene, settings, limit=50) if bool(getattr(settings, "enable_collision_prediction", True)) else {"collision_count": 0, "warnings": [], "estimated_file_count": 0}
    rec = _adaptive_recommendations(scene, settings)
    deep = _deep_preflight(scene, settings)
    storage = deep.get("metrics", {}).get("storage_estimate", {}) if isinstance(deep, dict) else {}
    score = 100 - min(65, len(errors) * 25) - min(38, len(warnings) * 4)
    if bool(getattr(settings, "enable_aov_gap_analysis", True)):
        score -= max(0, int((100.0 - float(aov.get("coverage_percent", 100.0))) * 0.25))
    score -= min(25, int(pred.get("collision_count", 0) or 0) * 5)
    if int(rec.get("current_chunk_size", 1) or 1) != int(rec.get("recommended_chunk_size", 1) or 1):
        score -= 5
    if bool(getattr(settings, "enable_storage_estimate", True)):
        estimated_mb = int(storage.get("estimated_mb", 0) or 0)
        if estimated_mb > 512000:
            score -= 10
        elif estimated_mb > 102400:
            score -= 4
    missing_external = deep.get("metrics", {}).get("missing_external_paths", []) if isinstance(deep, dict) else []
    if missing_external:
        score -= min(12, len(missing_external) * 2)
    score = max(0, min(100, int(score)))
    grade = "S" if score >= 95 else "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 50 else "D"
    recommendations: list[str] = []
    if errors:
        recommendations.append(_t("エラー項目を解消してからファーム投入してください。", "Resolve error items before farm submission."))
    if warnings:
        recommendations.append(_t("警告項目を確認し、未保存blend、欠落画像、出力先、AOV、容量を整理してください。", "Review warnings and clean up unsaved blend files, missing assets, output paths, AOVs, and storage risks."))
    if pred.get("collision_count", 0):
        recommendations.append(_t("命名テンプレートへ {camera}/{view_layer}/{variant}/{pass}/{frame} を含め、衝突を避けてください。", "Add {camera}/{view_layer}/{variant}/{pass}/{frame} to the naming template to avoid collisions."))
    if bool(getattr(settings, "enable_aov_gap_analysis", True)) and float(aov.get("coverage_percent", 100.0)) < 100:
        recommendations.append(_t("最終AOVやUSD/リアルタイム連携では、不足AOVを追加するかパイプラインプリセットを適用を実行してください。", "For Final AOV, USD, or realtime handoff, add missing AOVs or run Apply Pipeline Preset."))
    if int(rec.get("current_chunk_size", 1)) != int(rec.get("recommended_chunk_size", 1)):
        recommendations.append(_t(f"推奨チャンクサイズは {rec.get('recommended_chunk_size')} です。", f"Recommended chunk size is {rec.get('recommended_chunk_size')}."))
    if bool(getattr(settings, "enable_storage_estimate", True)) and int(storage.get("estimated_mb", 0) or 0) > 102400:
        recommendations.append(_t(f"概算容量は {storage.get('estimated_gb')} GB です。保存先とクラウド費用を確認してください。", f"Estimated storage is {storage.get('estimated_gb')} GB. Verify destination capacity and cloud cost."))
    if not recommendations:
        recommendations.append(_t("現在の設定はRender Pipeline Managerの上位互換ワークフローへ安全に渡せる状態です。", "The current setup is safe for Render Pipeline Manager superset handoff."))
    readiness = _readiness_word(score, int(getattr(settings, "quality_threshold", 85) or 85), len(errors))
    return {"score": score, "grade": grade, "readiness": readiness, "threshold": int(getattr(settings, "quality_threshold", 85) or 85), "passed": score >= int(getattr(settings, "quality_threshold", 85) or 85) and not errors, "warnings": warnings, "errors": errors, "recommendations": recommendations, "aov_coverage": aov, "output_prediction": pred, "adaptive_recommendations": rec, "deep_preflight": deep, "storage_estimate": storage}



def _write_csv(path: str, rows: list[dict[str, Any]]) -> None:
    target = Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    keys: list[str] = []
    for row in rows:
        for key in row.keys():
            if key not in keys: keys.append(str(key))
    if not keys: keys = ["empty"]
    with target.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore"); writer.writeheader()
        for row in rows: writer.writerow(row)


def _write_submission_pack(context, settings) -> dict[str, str]:
    out_dir = Path(_resolve_output_dir(settings, create=True)) / "submission_pack"; out_dir.mkdir(parents=True, exist_ok=True)
    manifest = _manifest(context, settings); quality = manifest.get("quality", {}) if isinstance(manifest, dict) else {}
    paths = {"manifest": str(out_dir / "render_pipeline_manifest.json"), "queue_csv": str(out_dir / "render_pipeline_queue_matrix.csv"), "adapter_profile": str(out_dir / "render_pipeline_adapter_profile.json"), "diagnostics": str(out_dir / "render_pipeline_diagnostics.txt"), "output_prediction": str(out_dir / "render_pipeline_output_prediction.json"), "aov_report": str(out_dir / "render_pipeline_aov_coverage.json")}
    _write_json(paths["manifest"], manifest)
    queue_rows = []
    for item in manifest.get("pdg_graph", {}).get("work_items", []) if isinstance(manifest, dict) else []:
        if isinstance(item, dict): queue_rows.append({"id": item.get("id", ""), "name": item.get("name", ""), "camera": item.get("camera", ""), "view_layer": item.get("view_layer", ""), "variant": item.get("variant", ""), "frame_start": item.get("frame_start", ""), "frame_end": item.get("frame_end", ""), "output_pattern": item.get("output_pattern", ""), "path_hash": item.get("path_hash", "")})
    _write_csv(paths["queue_csv"], queue_rows)
    _write_json(paths["adapter_profile"], manifest.get("adapter_profile", {})); _write_json(paths["output_prediction"], quality.get("output_prediction", {})); _write_json(paths["aov_report"], quality.get("aov_coverage", {}))
    Path(paths["diagnostics"]).write_text("\n".join(str(line) for line in _last_report_lines(_scene(context), settings)) + "\n", encoding="utf-8")
    return paths


def _token_schema(scene, settings) -> dict[str, str]:
    scene_name = str(getattr(scene, "name", "Scene") or "Scene")
    active_camera = getattr(scene, "camera", None)
    return {
        "{project}": "現在のblendファイル名、未保存の場合はuntitled。",
        "{scene}": scene_name,
        "{shot}": str(getattr(settings, "job_name", "") or scene_name),
        "{job}": str(getattr(settings, "job_name", "") or scene_name),
        "{camera}": str(getattr(active_camera, "name", "Camera") or "Camera"),
        "{view_layer}": "レンダー対象ビューレイヤー名。",
        "{variant}": "Smart Renderバリアントまたは外部DCCのTake/State名。",
        "{take}": "Cinema 4D TakesやHoudini Takesへ写像する階層テイク名。",
        "{parent_variant}": "親バリアントとテイクまたは親テイク名。",
        "{frame}": "ゼロ埋め済みフレーム番号。",
        "{pass}": "AOVまたはRender Element名。",
        "{renderer}": str(getattr(getattr(scene, "render", None), "engine", "") or ""),
        "{date}": datetime.now().strftime("%Y%m%d"),
        "{time}": datetime.now().strftime("%H%M%S"),
    }


def _coverage_entries(settings) -> list[dict[str, Any]]:
    active_flags = {
        "blender_native": True,
        "context_state_managers": bool(getattr(settings, "enable_variant_take_graph", True)),
        "batch_queue": bool(getattr(settings, "enable_batch_queue", True)),
        "tokens_outputs": bool(getattr(settings, "enable_token_naming", True)),
        "aov_compositing": bool(getattr(settings, "enable_aov_bundle", True)),
        "scene_assembly": bool(getattr(settings, "enable_scene_assembly", True)),
        "usd_pdg_pipeline": bool(getattr(settings, "enable_pdg_graph", True)),
        "network_farms": bool(getattr(settings, "enable_farm_handoff", True)),
        "realtime_offline": bool(getattr(settings, "enable_realtime_handoff", True)),
        "renderer_ecosystem": True,
        "asset_pipeline_ai": bool(getattr(settings, "enable_validation", True)) or bool(getattr(settings, "enable_scene_assembly", True)),
        "preflight_quality": bool(getattr(settings, "enable_validation", True)),
    }
    entries: list[dict[str, Any]] = []
    for group in COVERAGE_GROUPS:
        entries.append({
            "id": group["id"],
            "label": _t(str(group["label_ja"]), str(group["label_en"])),
            "mode": group["mode"],
            "enabled": bool(active_flags.get(str(group["id"]), True)),
            "features": list(group["features"]),
            "adapter_note": _t(str(group["adapter_ja"]), str(group["adapter_en"])),
        })
    return entries



def _dedupe_messages(items: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in items:
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        out.append(text)
    return out


def _missing_external_paths(limit: int = 200) -> list[dict[str, str]]:
    missing: list[dict[str, str]] = []
    data_specs = (
        ("libraries", "Library"),
        ("fonts", "Font"),
        ("movieclips", "Movie Clip"),
        ("sounds", "Sound"),
        ("volumes", "Volume"),
    )
    for collection_name, kind in data_specs:
        try:
            collection = list(getattr(bpy.data, collection_name, []) or [])
        except Exception:
            collection = []
        for datablock in collection:
            if len(missing) >= limit:
                return missing
            try:
                filepath = str(getattr(datablock, "filepath", "") or "").strip()
            except Exception:
                filepath = ""
            if not filepath:
                continue
            try:
                resolved = bpy.path.abspath(filepath)
            except Exception:
                resolved = filepath
            if resolved and not os.path.exists(resolved):
                missing.append({"kind": kind, "name": str(getattr(datablock, "name", "") or ""), "path": resolved})
    return missing


def _renderable_object_count(scene) -> int:
    count = 0
    try:
        objects = list(getattr(scene, "objects", []) or [])
    except Exception:
        objects = []
    for obj in objects:
        try:
            if str(getattr(obj, "type", "") or "") in {"MESH", "CURVE", "SURFACE", "META", "FONT", "VOLUME", "GPENCIL", "GREASEPENCIL"} and not bool(getattr(obj, "hide_render", False)):
                count += 1
        except Exception:
            continue
    return count


def _light_count(scene) -> int:
    try:
        return sum(1 for obj in getattr(scene, "objects", []) or [] if str(getattr(obj, "type", "") or "") in {"LIGHT", "SUN"})
    except Exception:
        return 0


def _active_camera_report(scene) -> dict[str, Any]:
    cam = getattr(scene, "camera", None)
    if cam is None:
        return {"name": "", "exists": False, "hide_render": False, "clip_valid": True}
    data = getattr(cam, "data", None)
    clip_start = float(getattr(data, "clip_start", 0.0) or 0.0) if data is not None else 0.0
    clip_end = float(getattr(data, "clip_end", 0.0) or 0.0) if data is not None else 0.0
    return {"name": str(getattr(cam, "name", "") or ""), "exists": True, "hide_render": bool(getattr(cam, "hide_render", False)), "clip_start": clip_start, "clip_end": clip_end, "clip_valid": not (clip_end and clip_start and clip_end <= clip_start)}


def _compositor_state(scene) -> dict[str, Any]:
    state = {"use_nodes": False, "file_output_nodes": 0, "viewer_nodes": 0, "composite_nodes": 0}
    try:
        state["use_nodes"] = bool(getattr(scene, "use_nodes", False))
        tree = getattr(scene, "node_tree", None)
        nodes = list(getattr(tree, "nodes", []) or []) if tree is not None else []
    except Exception:
        nodes = []
    for node in nodes:
        try:
            node_type = str(getattr(node, "type", "") or "")
            bl_idname = str(getattr(node, "bl_idname", "") or "")
            if node_type == "OUTPUT_FILE" or bl_idname == "CompositorNodeOutputFile":
                state["file_output_nodes"] += 1
            elif node_type == "VIEWER":
                state["viewer_nodes"] += 1
            elif node_type == "COMPOSITE":
                state["composite_nodes"] += 1
        except Exception:
            continue
    return state


def _color_management_state(scene) -> dict[str, Any]:
    view = getattr(scene, "view_settings", None)
    return {
        "view_transform": str(getattr(view, "view_transform", "") or "") if view is not None else "",
        "look": str(getattr(view, "look", "") or "") if view is not None else "",
        "exposure": float(getattr(view, "exposure", 0.0) or 0.0) if view is not None else 0.0,
        "gamma": float(getattr(view, "gamma", 1.0) or 1.0) if view is not None else 1.0,
        "sequencer_colorspace_settings": str(getattr(getattr(scene, "sequencer_colorspace_settings", None), "name", "") or ""),
    }


def _storage_estimate(scene, settings) -> dict[str, Any]:
    render = getattr(scene, "render", None)
    width = int(getattr(render, "resolution_x", 0) or 0) if render is not None else 0
    height = int(getattr(render, "resolution_y", 0) or 0) if render is not None else 0
    percentage = int(getattr(render, "resolution_percentage", 100) or 100) if render is not None else 100
    width = max(1, int(width * percentage / 100.0))
    height = max(1, int(height * percentage / 100.0))
    _start, _end, frame_count = _frame_range(scene)
    rows = [row for row in _queue_rows(scene, settings) if bool(row.get("enabled", True))]
    aov_count = max(1, len(_expected_aov_names(settings)) if bool(getattr(settings, "enable_aov_bundle", True)) else 1)
    image_settings = getattr(render, "image_settings", None) if render is not None else None
    fmt = str(getattr(image_settings, "file_format", "PNG") or "PNG") if image_settings is not None else "PNG"
    # Conservative production estimate: AOV-heavy EXR uses much more data than a flattened PNG.
    if fmt == "OPEN_EXR_MULTILAYER":
        bytes_per_pixel = 8 * max(1, aov_count)
        compression = 0.65
        file_multiplier = 1
    elif fmt == "OPEN_EXR":
        bytes_per_pixel = 8
        compression = 0.75
        file_multiplier = aov_count
    elif fmt in {"JPEG", "JPEG2000", "WEBP"}:
        bytes_per_pixel = 4
        compression = 0.12
        file_multiplier = 1
    elif fmt in {"PNG", "TIFF", "TARGA"}:
        bytes_per_pixel = 4
        compression = 0.45
        file_multiplier = aov_count if bool(getattr(settings, "enable_aov_bundle", True)) else 1
    else:
        bytes_per_pixel = 4
        compression = 0.55
        file_multiplier = aov_count
    estimated_files = max(1, len(rows)) * max(1, frame_count) * max(1, file_multiplier)
    estimated_bytes = int(width * height * bytes_per_pixel * compression * estimated_files)
    return {
        "resolution": [width, height],
        "frame_count": int(frame_count),
        "queue_rows": len(rows),
        "aov_count": int(aov_count),
        "file_format": fmt,
        "estimated_files": int(estimated_files),
        "estimated_mb": int(estimated_bytes / (1024 * 1024)),
        "estimated_gb": round(estimated_bytes / (1024 * 1024 * 1024), 2),
    }


def _deep_preflight(scene, settings) -> dict[str, Any]:
    warnings: list[str] = []
    errors: list[str] = []
    metrics: dict[str, Any] = {}
    if scene is None:
        return {"warnings": [_t("シーンがありません。", "No active scene.")], "errors": [_t("シーンがありません。", "No active scene.")], "metrics": metrics}
    mode = str(getattr(settings, "accuracy_mode", "BALANCED") or "BALANCED")
    render = getattr(scene, "render", None)
    resolution_x = int(getattr(render, "resolution_x", 0) or 0) if render is not None else 0
    resolution_y = int(getattr(render, "resolution_y", 0) or 0) if render is not None else 0
    resolution_percentage = int(getattr(render, "resolution_percentage", 100) or 100) if render is not None else 100
    if resolution_x <= 0 or resolution_y <= 0 or resolution_percentage <= 0:
        errors.append(_t("レンダー解像度が0以下です。出力画像を生成できません。", "Render resolution is zero or negative, so no output image can be generated."))
    if mode in {"STRICT", "PRODUCTION"} and (resolution_x * resolution_y * max(1, resolution_percentage) / 100) > (8192 * 8192):
        warnings.append(_t("非常に高い解像度です。AOVやEXRでは容量とメモリを確認してください。", "The resolution is very high. Verify storage and memory for AOV or EXR output."))
    cam = _active_camera_report(scene)
    metrics["active_camera"] = cam
    if cam.get("exists") and cam.get("hide_render"):
        errors.append(_t("アクティブカメラがレンダー非表示です。", "The active camera is hidden from render."))
    if cam.get("exists") and not cam.get("clip_valid"):
        warnings.append(_t("アクティブカメラのクリッピング範囲が不正です。", "The active camera clipping range is invalid."))
    renderable_count = _renderable_object_count(scene)
    metrics["renderable_objects"] = renderable_count
    if renderable_count <= 0:
        warnings.append(_t("レンダー可能なオブジェクトが見つかりません。空レンダーになる可能性があります。", "No renderable object was found. The render may be empty."))
    lights = _light_count(scene)
    metrics["lights"] = lights
    if mode in {"STRICT", "PRODUCTION"} and lights <= 0:
        warnings.append(_t("ライトが見つかりません。ワールドや発光マテリアルだけで照明する場合を除き、暗い出力になる可能性があります。", "No light was found. Unless using world lighting or emissive materials, output may be dark."))
    if bool(getattr(settings, "enable_deep_asset_scan", True)):
        external_missing = _missing_external_paths(limit=50)
        metrics["missing_external_paths"] = external_missing
        if external_missing:
            warnings.append(_t(f"画像以外の欠落外部参照が {len(external_missing)} 件あります。", f"Found {len(external_missing)} missing external reference(s) beyond images."))
    if bool(getattr(settings, "enable_compositor_checks", True)):
        compositor = _compositor_state(scene)
        metrics["compositor"] = compositor
        if bool(getattr(settings, "enable_aov_bundle", True)) and str(getattr(settings, "pipeline_preset", "")) in {"FINAL_AOV", "USD_SUPERSET", "REALTIME_HANDOFF"}:
            if compositor.get("use_nodes") and int(compositor.get("file_output_nodes", 0) or 0) <= 0:
                warnings.append(_t("コンポジターは有効ですがファイル出力ノードがありません。AOV別出力をコンポジター経由で管理する場合は追加してください。", "Compositor nodes are enabled but no File Output node exists. Add one if AOV outputs should be managed through the compositor."))
            if not compositor.get("use_nodes") and mode in {"STRICT", "PRODUCTION"}:
                warnings.append(_t("本番AOV運用ではコンポジターまたはマルチレイヤー EXRの出力経路を確認してください。", "For production AOV workflows, verify either compositor output or Multilayer EXR output routing."))
    if bool(getattr(settings, "enable_color_management_checks", True)):
        color = _color_management_state(scene)
        metrics["color_management"] = color
        if mode in {"STRICT", "PRODUCTION"} and not color.get("view_transform"):
            warnings.append(_t("色管理のビュー変換が取得できません。OCIO設定を確認してください。", "Color-management View Transform could not be read. Verify OCIO configuration."))
        if mode in {"STRICT", "PRODUCTION"} and abs(float(color.get("gamma", 1.0) or 1.0) - 1.0) > 0.001:
            warnings.append(_t("ガンマが1.0以外です。外部DCCや合成へ渡す前に意図した設定か確認してください。", "Gamma is not 1.0. Confirm that this is intentional before external DCC or compositing handoff."))
    if bool(getattr(settings, "enable_storage_estimate", True)):
        storage = _storage_estimate(scene, settings)
        metrics["storage_estimate"] = storage
        if int(storage.get("estimated_mb", 0) or 0) > 512000:
            warnings.append(_t(f"概算出力容量が {storage.get('estimated_gb')} GB です。出力先の空き容量とクラウド費用を確認してください。", f"Estimated output size is {storage.get('estimated_gb')} GB. Verify free space and cloud cost."))
        elif int(storage.get("estimated_mb", 0) or 0) > 102400 and mode in {"STRICT", "PRODUCTION"}:
            warnings.append(_t(f"概算出力容量が {storage.get('estimated_gb')} GB です。本番前に保存先容量を確認してください。", f"Estimated output size is {storage.get('estimated_gb')} GB. Verify destination storage before production."))
    return {"warnings": _dedupe_messages(warnings), "errors": _dedupe_messages(errors), "metrics": metrics}


def _diagnostics(scene, settings) -> tuple[list[str], list[str]]:
    warnings: list[str] = []
    errors: list[str] = []
    if scene is None:
        return [_t("シーンがありません。", "No active scene.")], [_t("シーンがありません。", "No active scene.")]
    mode = str(getattr(settings, "accuracy_mode", "BALANCED") or "BALANCED")
    cameras = _camera_names(scene)
    if not cameras:
        errors.append(_t("カメラがありません。レンダーキュー、MRQ、Batch カメラ系の出力に失敗します。", "No camera exists. Render queue, MRQ, and batch-camera style output will fail."))
    if getattr(scene, "camera", None) is None and cameras:
        warnings.append(_t("シーンのアクティブカメラが未設定です。キューには候補カメラを使います。", "The scene has no active camera. Candidate cameras will be used in the queue."))
    render = getattr(scene, "render", None)
    output_path = str(getattr(render, "filepath", "") or "").strip() if render is not None else ""
    if not output_path:
        warnings.append(_t("Blender標準の出力パスが空です。Render Pipeline Managerの既定出力先を使います。", "Blender's standard output path is empty. Render Pipeline Manager will use its default output directory."))
    missing = _missing_image_paths(limit=10)
    if missing:
        warnings.append(_t(f"欠落画像が {len(missing)} 件見つかりました。", f"Found {len(missing)} missing image path(s)."))
    frame_start = int(_safe_getattr(scene, "frame_start", 1) or 1)
    frame_end = int(_safe_getattr(scene, "frame_end", frame_start) or frame_start)
    if frame_end < frame_start:
        errors.append(_t("フレーム開始が終了より後になっています。", "Frame start is after frame end."))
    _start, _end, frame_count = _frame_range(scene)
    if frame_count > 5000 and int(getattr(settings, "frame_chunk_size", 10) or 10) > 250:
        warnings.append(_t("長いフレーム範囲に対してチャンクが大きすぎます。失敗時の再実行単位が重くなります。", "The chunk size is large for a long frame range. Failed re-runs will be expensive."))
    if bool(getattr(settings, "enable_farm_handoff", True)) and not str(getattr(bpy.data, "filepath", "") or ""):
        warnings.append(_t("blendファイルが未保存です。ファームやヘッドレススクリプトでは保存済みファイルが必要です。", "The blend file is unsaved. Farm and headless scripts need a saved blend file."))
    rows = _queue_rows(scene, settings)
    if bool(getattr(settings, "enable_batch_queue", True)) and not rows:
        errors.append(_t("レンダーキューを生成できるカメラ/View レイヤー/バリアントとテイクの組み合わせがありません。", "No camera/View Layer/variant combination can be queued."))
    layer_names = set(_view_layer_names(scene))
    camera_names = set(cameras)
    for row in rows[:200]:
        cam = str(row.get("camera") or "")
        layer = str(row.get("view_layer") or "")
        if cam and camera_names and cam not in camera_names:
            warnings.append(_t(f"キュー内のカメラ '{cam}' が現在のシーンに見つかりません。", f"Queued camera '{cam}' was not found in the current scene."))
        if layer and layer_names and layer not in layer_names:
            warnings.append(_t(f"キュー内のビューレイヤー '{layer}' が現在のシーンに見つかりません。", f"Queued View Layer '{layer}' was not found in the current scene."))
    if bool(getattr(settings, "enable_aov_gap_analysis", True)):
        coverage = _aov_coverage(scene, settings)
        if float(coverage.get("coverage_percent", 100.0)) < 75.0 and str(getattr(settings, "pipeline_preset", "")) in {"FINAL_AOV", "DATASET", "USD_SUPERSET", "REALTIME_HANDOFF"}:
            warnings.append(_t(f"AOV充足率が {coverage.get('coverage_percent')}% です。最終出力・連携用途では不足AOVを確認してください。", f"AOV coverage is {coverage.get('coverage_percent')}%. Review missing AOVs for final or handoff workflows."))
    if bool(getattr(settings, "enable_collision_prediction", True)):
        warnings.extend(str(item) for item in _output_prediction(scene, settings, limit=20).get("warnings", []) if item)
    if mode in {"STRICT", "PRODUCTION"}:
        if render is not None:
            image_settings = getattr(render, "image_settings", None)
            fmt = str(getattr(image_settings, "file_format", "") or "") if image_settings is not None else ""
            if bool(getattr(settings, "prefer_multilayer_exr", True)) and fmt not in {"OPEN_EXR", "OPEN_EXR_MULTILAYER"}:
                warnings.append(_t("厳密/本番モードではAOV受け渡し用にOPEN_EXRまたはOPEN_EXR_MULTILAYERを推奨します。", "Strict/Production mode recommends OPEN_EXR or OPEN_EXR_MULTILAYER for AOV handoff."))
        if bool(getattr(settings, "enable_farm_handoff", True)) and int(getattr(settings, "retry_count", 0) or 0) < 1:
            warnings.append(_t("厳密/本番モードではファーム失敗時の再試行回数を1以上にしてください。", "Strict/Production mode recommends retry_count >= 1 for farm failures."))
    deep = _deep_preflight(scene, settings)
    warnings.extend(deep.get("warnings", []) or [])
    errors.extend(deep.get("errors", []) or [])
    return _dedupe_messages(warnings), _dedupe_messages(errors)



def _work_items(scene, settings) -> list[dict[str, Any]]:
    rows = _queue_rows(scene, settings); chunks = _frame_chunks(scene, settings)
    aovs = _expected_aov_names(settings) if bool(getattr(settings, "enable_aov_bundle", True)) else ["Beauty"]
    template = str(getattr(settings, "naming_template", "") or "{scene}_{camera}_{view_layer}_{variant}_{frame}")
    ext = _image_format_extension(scene); output_root = Path(_resolve_output_dir(settings, create=False)); items: list[dict[str, Any]] = []
    for row_index, row in enumerate(rows, start=1):
        if not bool(row.get("enabled", True)): continue
        for chunk_index, chunk in enumerate(chunks, start=1):
            name = safe_name(f"{row.get('label') or row.get('camera') or 'job'}_{chunk['start']}_{chunk['end']}")
            first_name = _resolve_template(template, scene, settings, row, frame=int(chunk["start"]), aov=aovs[0] if aovs else "Beauty")
            if bool(getattr(settings, "enable_aov_bundle", True)) and "{pass}" not in template and len(aovs) > 1: first_name = safe_name(f"{first_name}_{{pass}}")
            output_pattern = str(output_root / str(row.get("label") or "job") / f"{first_name}.{ext}")
            path_hash = hashlib.sha1(output_pattern.encode("utf-8", errors="ignore")).hexdigest()[:16]
            items.append({"id": f"render_{row_index:03d}_{chunk_index:04d}", "name": name, "type": "render", "camera": row.get("camera", ""), "view_layer": row.get("view_layer", ""), "variant": row.get("variant", ""), "frame_start": chunk["start"], "frame_end": chunk["end"], "frame_count": chunk["count"], "aovs": aovs, "output_pattern": output_pattern, "path_hash": path_hash, "depends_on": ["preflight"], "then": ["verify_output"] + (["encode_movie"] if bool(getattr(settings, "enable_post_encode", False)) else []), "retry_count": int(getattr(settings, "retry_count", 1) or 1), "skip_existing": bool(getattr(settings, "skip_existing_outputs", True)), "use_placeholder": bool(getattr(settings, "use_placeholders", True))})
            if len(items) >= 5000: return items
    return items


def _manifest(context, settings) -> dict[str, Any]:
    scene = _scene(context); warnings, errors = _diagnostics(scene, settings)
    render = getattr(scene, "render", None); image_settings = getattr(render, "image_settings", None) if render is not None else None
    engine = str(getattr(render, "engine", "") or "") if render is not None else ""; filepath = str(getattr(bpy.data, "filepath", "") or "")
    rows = _queue_rows(scene, settings); work_items = _work_items(scene, settings); quality = _quality_model(scene, settings)
    deep_preflight = quality.get("deep_preflight", {}) if isinstance(quality, dict) else _deep_preflight(scene, settings)
    storage_estimate = quality.get("storage_estimate", {}) if isinstance(quality, dict) else _storage_estimate(scene, settings)
    adaptive = quality.get("adaptive_recommendations", {}) if isinstance(quality, dict) else {}; adapter_profile = _adapter_profile(settings); start_frame, end_frame, frame_count = _frame_range(scene)
    return {
        "schema": "render_pipeline_manifest_3.0", "generator": "Render Pipeline Manager", "copyright": "Copyright (C) 2026 JELararagi", "created_at": datetime.now().astimezone().isoformat(),
        "blender": {"version": tuple(getattr(getattr(bpy, "app", None), "version", (0, 0, 0))[:3]), "platform": platform.platform(), "python": sys.version.split()[0]},
        "source": {"blend_file": filepath or "<unsaved>", "scene": str(getattr(scene, "name", "Scene") or "Scene"), "renderer": engine, "frame_start": start_frame, "frame_end": end_frame, "frame_count": frame_count, "resolution_x": int(getattr(render, "resolution_x", 0) or 0) if render is not None else 0, "resolution_y": int(getattr(render, "resolution_y", 0) or 0) if render is not None else 0, "resolution_percentage": int(getattr(render, "resolution_percentage", 100) or 100) if render is not None else 100, "file_format": str(getattr(image_settings, "file_format", "") or "") if image_settings is not None else ""},
        "render_pipeline": {"pipeline_preset": str(getattr(settings, "pipeline_preset", "SMART_DEFAULT") or "SMART_DEFAULT"), "accuracy_mode": str(getattr(settings, "accuracy_mode", "BALANCED") or "BALANCED"), "state_system": str(getattr(settings, "state_system", "BLENDER_SMART_VARIANTS") or "BLENDER_SMART_VARIANTS"), "bridge_target": str(getattr(settings, "bridge_target", "GENERIC") or "GENERIC"), "farm_target": str(getattr(settings, "farm_target", "LOCAL_HEADLESS") or "LOCAL_HEADLESS"), "view_layer_strategy": str(getattr(settings, "view_layer_strategy", "KEEP") or "KEEP"), "frame_chunk_size": int(getattr(settings, "frame_chunk_size", 10) or 10), "concurrent_tasks": int(getattr(settings, "concurrent_tasks", 1) or 1), "retry_count": int(getattr(settings, "retry_count", 1) or 1), "temporal_subsamples": int(getattr(settings, "temporal_subsamples", 1) or 1), "spatial_subsamples": int(getattr(settings, "spatial_subsamples", 1) or 1), "accumulation_samples": int(getattr(settings, "accumulation_samples", 1) or 1), "quality_threshold": int(getattr(settings, "quality_threshold", 85) or 85)},
        "quality": quality, "deep_preflight": deep_preflight, "storage_estimate": storage_estimate, "adaptive_schedule": adaptive, "adapter_profile": adapter_profile, "coverage": _coverage_entries(settings), "scene_statistics": _scene_statistics(scene), "scene_complexity": _scene_complexity(scene), "cameras": _camera_names(scene), "view_layers": _view_layer_names(scene), "render_pass_state": _pass_state(scene), "aov_coverage": quality.get("aov_coverage", {}) if isinstance(quality, dict) else {}, "variants": _variant_rows(scene), "queue": rows, "tokens": _token_schema(scene, settings),
        "output": {"root": _resolve_output_dir(settings, create=True), "naming_template": str(getattr(settings, "naming_template", "") or "{scene}_{camera}_{view_layer}_{variant}_{frame}"), "movie_template": str(getattr(settings, "movie_template", "") or "{scene}_{variant}_{date}"), "overwrite_policy": "skip_existing" if bool(getattr(settings, "skip_existing_outputs", True)) else "allow_overwrite", "placeholder_policy": bool(getattr(settings, "use_placeholders", True)), "prediction": quality.get("output_prediction", {}) if isinstance(quality, dict) else {}},
        "aov_mapping": {"beauty": "Combined or Image", "depth": "Z or WorldDepth", "normal": "Normal", "velocity": "Vector or MotionVectors", "id": "Object Index, Material Index, Cryptomatte, Stencil Layer", "lighting": "Diffuse, Glossy, Emission, Environment, Shadow", "format_hint": "OPEN_EXR_MULTILAYER" if bool(getattr(settings, "prefer_multilayer_exr", True)) else "OPEN_EXR", "expected": _expected_aov_names(settings)},
        "external_adapters": {"state_systems": [item[0] for item in STATE_SYSTEM_ITEMS], "bridge_targets": [item[0] for item in BRIDGE_TARGET_ITEMS], "farm_targets": [item[0] for item in FARM_TARGET_ITEMS], "renderer_targets": ["CYCLES", "EEVEE", "ARNOLD", "RENDERMAN", "REDSHIFT", "VRAY", "CORONA", "LUXCORE", "RADEON_PRORENDER", "POVRAY", "MOONRAY", "USD_HYDRA"], "asset_prep_targets": ["SYNTHETIC_DATA", "AI_ASSET_PREP", "RETARGET_RETOPOLOGY", "TEXTURE_READINESS", "RIGGING_READINESS", "PREVIEW_GENERATION"]},
        "renderer_ecosystem": {"current_blender_engine": engine, "native_execution": ["CYCLES", "BLENDER_EEVEE_NEXT", "BLENDER_WORKBENCH"], "external_handoff_only": ["ARNOLD", "RENDERMAN", "REDSHIFT", "VRAY", "CORONA", "LUXCORE", "RADEON_PRORENDER", "POVRAY", "MOONRAY", "USD_HYDRA"], "note": _t("Render Pipeline Managerは外部レンダラー本体を同梱または実行しません。レンダー設定、AOV、デバイス、USD/Hydra連携のメタデータを出力します。", "Render Pipeline Manager does not bundle or execute external renderers. It exports render-setting, AOV, device, and USD/Hydra handoff metadata.")},
        "asset_preparation": {"synthetic_data_ready": str(getattr(settings, "pipeline_preset", "")) == "DATASET", "ai_generation_executed": False, "preview_generation_hint": True, "texture_readiness_check": bool(getattr(settings, "enable_validation", True)), "retopology_handoff_hint": bool(getattr(settings, "enable_scene_assembly", True)), "rigging_handoff_hint": bool(getattr(settings, "enable_scene_assembly", True)), "note": _t("外部AIアセット生成は実行せず、後工程が解釈できる準備状態とプレースホルダー情報だけを記録します。", "External AI asset generation is not executed; only readiness and placeholder metadata for downstream tools is recorded.")},
        "pdg_graph": {"enabled": bool(getattr(settings, "enable_pdg_graph", True)), "nodes": ["preflight", "cache_or_proxy_prepare", "render", "verify_output", "encode_movie", "publish_manifest"], "work_items": work_items},
        "farm_handoff": {"target": str(getattr(settings, "farm_target", "LOCAL_HEADLESS") or "LOCAL_HEADLESS"), "priority": int(getattr(settings, "farm_priority", 50) or 50), "chunk_count": len(_frame_chunks(scene, settings)), "work_item_count": len(work_items), "retry_count": int(getattr(settings, "retry_count", 1) or 1), "budget_guard": bool(getattr(settings, "include_cloud_cost_hints", True)), "cpu_gpu_hint": str(getattr(settings, "execution_device_hint", "AUTO") or "AUTO"), "profile": adapter_profile.get("farm_profile", {})},
        "realtime_handoff": {"unreal_mrq": {"temporal_subsamples": int(getattr(settings, "temporal_subsamples", 1) or 1), "spatial_subsamples": int(getattr(settings, "spatial_subsamples", 1) or 1), "accumulation_samples": int(getattr(settings, "accumulation_samples", 1) or 1), "write_exr": bool(getattr(settings, "prefer_multilayer_exr", True)), "include_motion_vectors": bool(getattr(settings, "enable_aov_bundle", True)), "include_object_ids": bool(getattr(settings, "enable_aov_bundle", True))}, "unity_recorder": {"accumulation_samples": int(getattr(settings, "accumulation_samples", 1) or 1), "image_sequence": True, "aov_recorder_hint": bool(getattr(settings, "enable_aov_bundle", True))}},
        "diagnostics": {"warnings": warnings, "errors": errors, "missing_images_sample": _missing_image_paths(limit=20), "missing_external_sample": deep_preflight.get("metrics", {}).get("missing_external_paths", [])[:20] if isinstance(deep_preflight, dict) else []},
    }


def _write_json(path: str, data: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def _last_report_lines(scene, settings) -> list[str]:
    warnings, errors = _diagnostics(scene, settings)
    coverage = _coverage_entries(settings)
    rows = _queue_rows(scene, settings)
    quality = _quality_model(scene, settings)
    aov = quality.get("aov_coverage", {}) if isinstance(quality, dict) else {}
    pred = quality.get("output_prediction", {}) if isinstance(quality, dict) else {}
    recs = list(quality.get("recommendations", []) or []) if isinstance(quality, dict) else []
    storage = quality.get("storage_estimate", {}) if isinstance(quality, dict) else {}
    readiness = str(quality.get("readiness", "") or _readiness_word(int(quality.get("score", 0) or 0), int(getattr(settings, "quality_threshold", 85) or 85), len(errors))) if isinstance(quality, dict) else ""
    return [
        _t("Render Pipeline Manager 診断", "Render Pipeline Manager Diagnostics"),
        f"Scene: {str(getattr(scene, 'name', 'Scene') or 'Scene')}",
        f"Quality: {quality.get('score', 0)}/100  Grade: {quality.get('grade', '-')}",
        f"Readiness: {readiness}",
        f"Score Bar: {_score_bar(int(quality.get('score', 0) or 0))}",
        f"Coverage: {sum(1 for item in coverage if item.get('enabled'))}/{len(coverage)}",
        f"AOV Coverage: {aov.get('coverage_percent', 0)}%",
        f"Estimated Files: {pred.get('estimated_file_count', 0)}",
        f"Estimated Storage: {storage.get('estimated_gb', 0)} GB",
        f"Path Collisions: {pred.get('collision_count', 0)}",
        f"Cameras: {len(_camera_names(scene))}",
        f"View Layers: {len(_view_layer_names(scene))}",
        f"Queue Rows: {len(rows)}",
        f"Warnings: {len(warnings)}",
        f"Errors: {len(errors)}",
        "",
        _t("推奨", "Recommendations"),
        *(recs[:10] or [_t("推奨事項はありません。", "No recommendations.")]),
        "",
        _t("警告", "Warnings"),
        *(warnings or [_t("警告はありません。", "No warnings.")]),
        "",
        _t("エラー", "Errors"),
        *(errors or [_t("エラーはありません。", "No errors.")]),
    ]


def _store_report(settings, lines: list[str], *, warnings: int = 0, errors: int = 0, coverage: int | None = None, quality: dict[str, Any] | None = None) -> None:
    try:
        settings.last_report = "\n".join(str(line) for line in lines); settings.last_warning_count = int(warnings); settings.last_error_count = int(errors)
        if coverage is not None: settings.last_coverage_count = int(coverage)
        if isinstance(quality, dict):
            settings.last_quality_score = int(quality.get("score", 0) or 0); settings.last_collision_count = int((quality.get("output_prediction", {}) or {}).get("collision_count", 0) or 0); settings.last_estimated_file_count = int((quality.get("output_prediction", {}) or {}).get("estimated_file_count", 0) or 0); settings.last_aov_coverage = int(float((quality.get("aov_coverage", {}) or {}).get("coverage_percent", 0) or 0))
            storage = quality.get("storage_estimate", {}) or {}; deep = quality.get("deep_preflight", {}) or {}
            settings.last_storage_estimate_mb = int(storage.get("estimated_mb", 0) or 0)
            settings.last_missing_asset_count = len(_missing_image_paths(limit=500)) + len((deep.get("metrics", {}) or {}).get("missing_external_paths", []) or [])
            settings.last_readiness_label = str(quality.get("readiness", "") or "")
        settings.last_run_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    except Exception: pass



class RENDER_PIPELINE_Settings(PropertyGroup):
    pipeline_preset: EnumProperty(
        name=_t("パイプラインプリセット", "Pipeline Preset"),
        items=PIPELINE_PRESET_ITEMS,
        default="SMART_DEFAULT",
        update=_settings_update,
        description=tooltip(
            "添付リストのどのワークフローを中心にするかを選びます。選択値はSmart Render本体の設定反映、マニフェスト出力、ヘッドレススクリプト生成の初期方針に使われます。",
            "Choose which workflow from the attached feature list should drive the setup. The value guides Smart Render core settings, manifest export, and headless script generation.",
        ),
    )
    state_system: EnumProperty(
        name=_t("ステート方式", "State System"),
        items=STATE_SYSTEM_ITEMS,
        default="BLENDER_SMART_VARIANTS",
        update=_settings_update,
        description=tooltip(
            "バリアントとテイク、テイク、ステートセット、Render Setup、LOPsなどの状態管理を、どの外部概念へ寄せて書き出すかを指定します。Blender内では非破壊なSmart Renderバリアントを中心に扱います。",
            "Select the external state-management concept used for export: variants, takes, state sets, Render Setup, or LOPs. Inside Blender the tool uses non-destructive Smart Render variants.",
        ),
    )
    bridge_target: EnumProperty(
        name=_t("ブリッジ先", "Bridge Target"),
        items=BRIDGE_TARGET_ITEMS,
        default="GENERIC",
        update=_settings_update,
        description=tooltip(
            "外部DCC、リアルタイムエンジン、USD、ルックデブツールへ渡すためのターゲット別マニフェスト形式を選びます。実送信ではなく、読み替えやすいJSONを生成します。",
            "Choose the target-specific manifest shape for external DCCs, realtime engines, USD, or lookdev tools. This generates adapter-friendly JSON rather than directly submitting jobs.",
        ),
    )
    farm_target: EnumProperty(
        name=_t("ファーム先", "Farm Target"),
        items=FARM_TARGET_ITEMS,
        default="LOCAL_HEADLESS",
        update=_settings_update,
        description=tooltip(
            "ローカルヘッドレス、LAN分散、クラウドレンダーファーム、PDG系サービスへ渡しやすいジョブ定義の出力先を選びます。",
            "Choose the job-definition style for local headless, LAN distribution, cloud render farms, or PDG-style services.",
        ),
    )
    view_layer_strategy: EnumProperty(
        name=_t("ビューレイヤー方針", "View Layer Strategy"),
        items=VIEW_LAYER_STRATEGY_ITEMS,
        default="KEEP",
        update=_settings_update,
        description=tooltip(
            "既存ビューレイヤーを維持するか、標準レイヤーを作成するか、レンダー可能な組み合わせだけをキュー化するかを指定します。",
            "Choose whether to keep existing View Layers, create standard layers, or queue only renderable combinations.",
        ),
    )
    accuracy_mode: EnumProperty(name=_t("精度モード", "Precision Mode"), items=ACCURACY_MODE_ITEMS, default="BALANCED", update=_settings_update, description=tooltip("診断、パス衝突予測、AOV不足検出、ファーム粒度推奨をどの厳しさで行うかを指定します。高速、標準精度、厳密、本番から選べます。", "Controls how strictly diagnostics, path-collision prediction, AOV-gap detection, and farm chunk recommendations are evaluated: Fast, Balanced, Strict, or Production."))
    enable_deep_asset_scan: BoolProperty(name=_t("深層アセット検査", "Deep Asset Scan"), default=True, update=_settings_update, description=tooltip("画像だけでなく、リンクライブラリ、フォント、動画、音声、ボリュームなどの外部参照も確認し、ファーム投入時に読み込み失敗しやすい欠落パスを検出します。", "Checks external references beyond images, including linked libraries, fonts, movies, sounds, and volumes, to catch missing paths that commonly fail on farms."))
    enable_compositor_checks: BoolProperty(name=_t("コンポジター検査", "Compositor Checks"), default=True, update=_settings_update, description=tooltip("AOVやEXR受け渡しを使う場合に、コンポジターのファイル出力ノード、ノードツリー利用状態、合成向け出力の準備度を確認します。", "When AOV or EXR handoff is enabled, checks compositor File Output nodes, node-tree use, and compositing-output readiness."))
    enable_color_management_checks: BoolProperty(name=_t("色管理検査", "Color Management Checks"), default=True, update=_settings_update, description=tooltip("OCIO、ビュー変換、ルック、露出、ガンマなどの色管理状態をマニフェストへ記録し、本番・外部DCC受け渡し前の確認項目に含めます。", "Records OCIO, View Transform, Look, exposure, and gamma state in the manifest and includes them in production/external-DCC preflight checks."))
    enable_storage_estimate: BoolProperty(name=_t("容量見積もり", "Storage Estimate"), default=True, update=_settings_update, description=tooltip("解像度、フレーム数、AOV数、出力形式、キュー件数から概算容量を計算し、夜間レンダーやクラウドファーム投入前の容量リスクを警告します。", "Estimates storage from resolution, frame count, AOV count, output format, and queue size, then warns about capacity risks before overnight or cloud rendering."))
    enable_collision_prediction: BoolProperty(name=_t("出力衝突予測", "Output Collision Prediction"), default=True, update=_settings_update, description=tooltip("命名テンプレート、カメラ、ビューレイヤー、バリアントとテイク、AOV、フレームから出力パス候補を事前計算し、上書き衝突、長すぎるパス、無効文字を検出します。", "Precomputes output path candidates from the naming template, cameras, View Layers, variants, AOVs, and frames to detect overwrite collisions, overly long paths, and invalid characters."))
    enable_aov_gap_analysis: BoolProperty(name=_t("AOV不足解析", "AOV Gap Analysis"), default=True, update=_settings_update, description=tooltip("選択したプリセットとブリッジ先に必要なAOVと、現在のビューレイヤーで有効なレンダーパスを比較し、不足しているパスを品質スコアへ反映します。", "Compares AOVs required by the selected preset and bridge target with the active Render Passes in each View Layer, then feeds missing passes into the quality score."))
    enable_adaptive_chunking: BoolProperty(name=_t("適応チャンク推奨", "Adaptive Chunking"), default=True, update=_settings_update, description=tooltip("フレーム数、シーン規模、選択ファーム、精度モードから、失敗時に再実行しやすいチャンクサイズと再試行回数を推奨します。", "Recommends chunk size and retry count from frame count, scene complexity, selected farm target, and accuracy mode so failed work can be rerun efficiently."))
    quality_threshold: IntProperty(name=_t("合格品質", "Quality Threshold"), default=85, min=0, max=100, update=_settings_update, description=tooltip("診断スコアがこの値以上なら、外部ファームやDCCへ渡す前提を満たす状態として扱います。厳密運用では90以上を推奨します。", "A diagnostic score at or above this value is treated as ready for farm or external-DCC handoff. 90 or higher is recommended for strict production use."))
    max_output_path_length: IntProperty(name=_t("最大パス長", "Max Path Length"), default=240, min=80, max=1024, update=_settings_update, description=tooltip("出力パス候補がこの文字数を超えた場合に警告します。Windowsやクラウドファームでのパス長問題を事前に避けるための安全値です。", "Warn when predicted output paths exceed this length. This helps avoid path-length problems on Windows or cloud farms."))
    enable_variant_take_graph: BoolProperty(
        name=_t("バリアントとテイクとテイクグラフ", "Variant and Take Graph"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Renderset、Maya Render Setup、3ds Max State Sets、Cinema 4D Takes、Houdini Takesに相当する状態管理情報を有効化します。",
            "Enable state-management metadata equivalent to Renderset, Maya Render Setup, 3ds Max State Sets, Cinema 4D Takes, and Houdini Takes.",
        ),
    )
    enable_batch_queue: BoolProperty(
        name=_t("レンダーキュー", "Render Queue"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "カメラ、ビューレイヤー、バリアントとテイク、フレーム範囲を組み合わせたバッチレンダーキュー情報を生成します。",
            "Generate batch-render queue data from cameras, View Layers, variants, and frame ranges.",
        ),
    )
    enable_token_naming: BoolProperty(
        name=_t("トークン命名", "Token Naming"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Cinema 4D トークン、レンダー命名、Batch Render系に近い、シーン・カメラ・テイク・フレーム・AOVの自動命名規則を有効化します。",
            "Enable automatic naming rules for scene, camera, take, frame, and AOV values, similar to Cinema 4D Tokens, Render Naming, and batch-render tools.",
        ),
    )
    enable_aov_bundle: BoolProperty(
        name=_t("AOVとRender Elements", "AOV and Render Elements"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "レンダーパス、Render Elements、MRQパス、Unity AOV Recorderに相当するマルチパス出力情報を扱います。",
            "Handle multipass output metadata equivalent to Render Passes, Render Elements, MRQ passes, and Unity AOV Recorder.",
        ),
    )
    enable_scene_assembly: BoolProperty(
        name=_t("シーンアセンブリ", "Scene Assembly"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Maya Scene Assembly、USD参照、プロキシ/レンダー表現切替、Clarisse/Katana風の大規模シーン管理情報を含めます。",
            "Include Maya Scene Assembly, USD reference, proxy/render representation switching, and Clarisse/Katana-style large-scene metadata.",
        ),
    )
    enable_pdg_graph: BoolProperty(
        name=_t("PDG依存グラフ", "PDG Dependency Graph"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Houdini TOPs/PDGのように、プリフライト、キャッシュ、レンダー、検証、エンコードの依存関係をワークアイテムとして出力します。",
            "Export preflight, cache, render, verification, and encoding dependencies as work items, similar to Houdini TOPs and PDG.",
        ),
    )
    enable_farm_handoff: BoolProperty(
        name=_t("ファーム受け渡し", "Farm Handoff"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Flamenco、Deadline、Tractor、Qube、Royal Render、Smedge、SheepIt、Crowdrender、Team Renderなどへ渡すためのジョブ情報を含めます。",
            "Include job metadata for Flamenco, Deadline, Tractor, Qube, Royal Render, Smedge, SheepIt, Crowdrender, Team Render, and similar systems.",
        ),
    )
    enable_realtime_handoff: BoolProperty(
        name=_t("リアルタイム連携", "Realtime Handoff"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "Unreal Movie Render QueueやUnity Recorderへ渡しやすい時間サブサンプル、空間サブサンプル、蓄積、AOV、EXR情報を含めます。",
            "Include temporal subsampling, spatial subsampling, accumulation, AOV, and EXR metadata for Unreal Movie Render Queue and Unity Recorder.",
        ),
    )
    enable_validation: BoolProperty(
        name=_t("プリフライト検証", "Preflight Validation"),
        default=True,
        update=_settings_update,
        description=tooltip(
            'Golaem Check Render 設定や夜間レンダー向けチェックに近い、カメラ、出力、欠落画像、フレーム範囲、上書きリスクの検証を行います。',
            "Run checks similar to Golaem Check Render Settings and overnight-render preflight: camera, output, missing images, frame range, and overwrite risk.",
        ),
    )
    enable_post_encode: BoolProperty(
        name=_t("FFmpeg後処理", "FFmpeg Post Encode"),
        default=False,
        update=_settings_update,
        description=tooltip(
            "Houdini TOPsやbrender系のように、連番画像レンダー後のFFmpegエンコード工程を依存グラフに含めます。",
            "Include an FFmpeg encoding step after image-sequence rendering, similar to Houdini TOPs or brender-style workflows.",
        ),
    )
    prefer_multilayer_exr: BoolProperty(
        name=_t("マルチレイヤー EXR優先", "Prefer Multilayer EXR"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "AOVやRender Elementsの外部受け渡しで、可能な場合はマルチレイヤー EXRを優先するヒントを出力します。",
            "Export a hint to prefer Multilayer EXR for AOV and Render Elements handoff when possible.",
        ),
    )
    include_cloud_cost_hints: BoolProperty(
        name=_t("クラウド費用ヒント", "Cloud Cost Hints"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "クラウドファーム向けにチャンク数、フレーム数、優先度、予算停止の参考情報をマニフェストへ含めます。",
            "Include reference data for cloud farms such as chunk counts, frame counts, priority, and budget-stop hints.",
        ),
    )
    skip_existing_outputs: BoolProperty(
        name=_t("既存出力をスキップ", "Skip Existing Outputs"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "夜間レンダーや再実行時の上書き事故を避けるため、既存ファイルをスキップする意図をマニフェストとスクリプトへ含めます。",
            "Include an intent to skip existing files in manifests and scripts to avoid accidental overwrites during overnight or retry rendering.",
        ),
    )
    use_placeholders: BoolProperty(
        name=_t("プレースホルダー", "Placeholders"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "ローカル並列レンダーやファーム向けに、同一フレームを複数プロセスが重複レンダーしないようプレースホルダー利用の意図を含めます。",
            "Include an intent to use placeholders so local parallel processes or farms do not render the same frame twice.",
        ),
    )
    limit_manifest_frames: BoolProperty(
        name=_t("フレーム一覧を圧縮", "Compact Frame List"),
        default=True,
        update=_settings_update,
        description=tooltip(
            "長いアニメーションでマニフェストが巨大化しないよう、個別フレーム列挙を開始・終了とチャンク情報に圧縮します。",
            "Compact long frame lists into start/end and chunk metadata so manifests do not become excessively large.",
        ),
    )
    output_dir: StringProperty(
        name=_t("出力フォルダー", "Output Folder"),
        subtype="DIR_PATH",
        default="",
        update=_settings_update,
        description=tooltip(
            "Render Pipeline Managerがマニフェスト、ヘッドレススクリプト、診断JSONを書き出す場所です。空欄の場合はBlender 5.1の設定フォルダー/Smart_Render_Suite/render_pipeline配下を使います。手動指定した場合のみ任意ディレクトリを使います。",
            "Folder where Render Pipeline Manager writes manifests, headless scripts, and diagnostic JSON. When blank, it uses Blender 5.1 config/Smart_Render_Suite/render_pipeline. A custom directory is used only when explicitly set here.",
        ),
    )
    manifest_name: StringProperty(
        name=_t("マニフェスト名", "Manifest Name"),
        default="render_pipeline_manifest.json",
        update=_settings_update,
        description=tooltip(
            "書き出すJSONマニフェストのファイル名です。拡張子がない場合はjsonを補います。",
            "File name for the exported JSON manifest. The json extension is added when omitted.",
        ),
    )
    script_name: StringProperty(
        name=_t("スクリプト名", "Script Name"),
        default="render_pipeline_headless",
        update=_settings_update,
        description=tooltip(
            "ヘッドレスレンダー用に生成する.bat または .shファイルのベース名です。OSに合わせて拡張子を付けます。",
            "Base name for the generated headless render bat or sh file. The extension is chosen for the current OS.",
        ),
    )
    job_name: StringProperty(
        name=_t("ジョブ名", "Job Name"),
        default="",
        update=_settings_update,
        description=tooltip(
            "{job}や{shot}トークン、外部ファームのジョブ名、テイク/ステート名のベースとして使う任意名です。空欄ならシーン名を使います。",
            "Optional name used as the base for {job}, {shot}, external farm job names, and take/state names. The scene name is used when blank.",
        ),
    )
    naming_template: StringProperty(
        name=_t("命名テンプレート", "Naming Template"),
        default="{scene}_{camera}_{view_layer}_{variant}_{frame}",
        update=_settings_update,
        description=tooltip(
            "出力ファイル名や外部DCCのトークン命名へ渡すテンプレートです。{scene}、{camera}、{view_layer}、{variant}、{take}、{frame}、{pass}などを使えます。",
            "Template passed to output file naming and external DCC token naming. Supports values such as {scene}, {camera}, {view_layer}, {variant}, {take}, {frame}, and {pass}.",
        ),
    )
    movie_template: StringProperty(
        name=_t("ムービー名テンプレート", "Movie Name Template"),
        default="{scene}_{variant}_{date}",
        update=_settings_update,
        description=tooltip(
            "連番画像を動画化する場合に使う名前テンプレートです。FFmpeg工程を有効にした時、依存グラフにも含めます。",
            "Name template used when encoding image sequences to a movie. When FFmpeg post encode is enabled, this is also included in the dependency graph.",
        ),
    )
    frame_chunk_size: IntProperty(
        name=_t("チャンクサイズ", "Chunk Size"),
        default=10,
        min=1,
        max=100000,
        update=_settings_update,
        description=tooltip(
            "ファーム、PDG、ヘッドレススクリプト向けに、フレームを何枚単位で分割するかを指定します。失敗時の再実行粒度にも影響します。",
            "Number of frames per chunk for farm, PDG, and headless-script handoff. This also controls the granularity of failed re-runs.",
        ),
    )
    concurrent_tasks: IntProperty(
        name=_t("並列タスク", "Concurrent Tasks"),
        default=1,
        min=1,
        max=256,
        update=_settings_update,
        description=tooltip(
            "ローカル並列やファーム送信時の同時実行数ヒントです。実際の実行数は外部マネージャー側で調整できます。",
            "Hint for local parallel or farm submission concurrency. The actual number can still be controlled by the external manager.",
        ),
    )
    retry_count: IntProperty(
        name=_t("再試行回数", "Retry Count"),
        default=1,
        min=0,
        max=100,
        update=_settings_update,
        description=tooltip(
            "失敗したワークアイテムやチャンクを何回再試行する想定かをマニフェストへ記録します。",
            "Records how many times failed work items or chunks should be retried in the manifest.",
        ),
    )
    farm_priority: IntProperty(
        name=_t("優先度", "Priority"),
        default=50,
        min=0,
        max=100,
        update=_settings_update,
        description=tooltip(
            "Deadline、Qube、Tractor、Smedgeなどへ渡すジョブ優先度のヒントです。",
            "Priority hint for Deadline, Qube, Tractor, Smedge, and similar systems.",
        ),
    )
    temporal_subsamples: IntProperty(
        name=_t("時間サブサンプル", "Temporal Subsamples"),
        default=1,
        min=1,
        max=1024,
        update=_settings_update,
        description=tooltip(
            "Unreal MRQやUnity Recorderの高品質モーションブラー・蓄積出力へ渡す時間方向サブサンプル数です。",
            "Temporal subsample count exported for high-quality motion blur and accumulation workflows in Unreal MRQ or Unity Recorder.",
        ),
    )
    spatial_subsamples: IntProperty(
        name=_t("空間サブサンプル", "Spatial Subsamples"),
        default=1,
        min=1,
        max=1024,
        update=_settings_update,
        description=tooltip(
            "Unreal MRQの空間サブサンプルやノイズ低減、アンチエイリアス品質へ渡すヒントです。",
            "Spatial subsample hint for Unreal MRQ-style anti-aliasing and noise reduction.",
        ),
    )
    accumulation_samples: IntProperty(
        name=_t("蓄積サンプル", "Accumulation Samples"),
        default=1,
        min=1,
        max=65536,
        update=_settings_update,
        description=tooltip(
            "Unity RecorderやMRQの蓄積レンダーに相当するサンプル数ヒントです。",
            "Sample-count hint equivalent to accumulation rendering in Unity Recorder or MRQ.",
        ),
    )
    execution_device_hint: EnumProperty(
        name=_t("実行デバイス", "Execution Plan Device"),
        items=_enum([
            ("AUTO", "自動", "Auto", "現在のBlender設定や外部ファーム側へ判断を任せます。", "Let current Blender settings or the external farm decide."),
            ("CPU", "CPU", "CPU", "CPUレンダー前提のジョブとして扱うヒントです。", "Hint that jobs should be treated as CPU-render jobs."),
            ("GPU", "GPU", "GPU", "GPUレンダー前提のジョブとして扱うヒントです。", "Hint that jobs should be treated as GPU-render jobs."),
            ("HYBRID", "ハイブリッド", "Hybrid", "CPU/GPU混在やファーム側の自動割当を想定します。", "Assume mixed CPU/GPU use or automatic allocation by the farm."),
        ]),
        default="AUTO",
        update=_settings_update,
        description=tooltip(
            "ローカル並列、Deadline、Qube、クラウドファームなどへ渡すCPU/GPU実行方針のヒントです。",
            "CPU/GPU execution hint for local parallel rendering, Deadline, Qube, and cloud farms.",
        ),
    )
    last_manifest_path: StringProperty(name="Last Manifest", default="", options={'HIDDEN'})
    last_script_path: StringProperty(name="Last Script", default="", options={'HIDDEN'})
    last_report: StringProperty(name="Last Report", default="", options={'HIDDEN'})
    last_run_at: StringProperty(name="Last Run", default="", options={'HIDDEN'})
    last_warning_count: IntProperty(name="Warnings", default=0, options={'HIDDEN'})
    last_error_count: IntProperty(name="Errors", default=0, options={'HIDDEN'})
    last_coverage_count: IntProperty(name="Coverage", default=0, options={'HIDDEN'})
    last_quality_score: IntProperty(name="Quality", default=0, options={'HIDDEN'})
    last_collision_count: IntProperty(name="Collisions", default=0, options={'HIDDEN'})
    last_estimated_file_count: IntProperty(name="Estimated Files", default=0, options={'HIDDEN'})
    last_aov_coverage: IntProperty(name="AOV Coverage", default=0, options={'HIDDEN'})
    last_submission_pack_dir: StringProperty(name="Submission Pack", default="", options={'HIDDEN'})
    last_storage_estimate_mb: IntProperty(name="Storage Estimate MB", default=0, options={'HIDDEN'})
    last_missing_asset_count: IntProperty(name="Missing Assets", default=0, options={'HIDDEN'})
    last_readiness_label: StringProperty(name="Readiness", default="", options={'HIDDEN'})


class RENDER_PIPELINE_OT_analyze(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.analyze"
    bl_label = "Diagnose"
    bl_description = action_tooltip(
        "添付リストにあるレンダー管理機能を基準に、現在のシーンがどの程度Render Pipeline Managerの上位互換ワークフローへ接続できるかを診断します。",
        "Analyze how the current scene can connect to Render Pipeline Manager's superset render-management workflow based on the attached feature list.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            _safe_report(self, {'ERROR'}, "Render Pipeline Manager設定またはシーンが見つかりません。", "Render Pipeline Manager settings or scene was not found.")
            return {'CANCELLED'}
        warnings, errors = _diagnostics(scene, settings)
        coverage = _coverage_entries(settings)
        quality = _quality_model(scene, settings)
        lines = _last_report_lines(scene, settings)
        _store_report(settings, lines, warnings=len(warnings), errors=len(errors), coverage=sum(1 for item in coverage if item.get("enabled")), quality=quality)
        try:
            text_name = "Render Pipeline Manager Diagnostics"
            text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
            text.clear()
            text.write(settings.last_report)
        except Exception:
            pass
        _safe_report(self, {'INFO'}, f"診断完了: 警告 {len(warnings)} 件、エラー {len(errors)} 件。", f"Analysis complete: {len(warnings)} warning(s), {len(errors)} error(s).")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_apply_preset(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.apply_pipeline_preset"
    bl_label = "Apply Pipeline Preset"
    bl_label = _t("パイプラインプリセットを適用", "Apply Pipeline Preset")
    bl_description = action_tooltip(
        "Render Pipeline Managerのパイプラインプリセットを、Smart Render本体のNパネル設定とBlenderレンダー設定へ安全寄りに反映します。レンダー実行は行いません。",
        "Apply the Render Pipeline Manager pipeline preset to Smart Render core N-panel settings and Blender render settings conservatively. This does not start rendering.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            return {'CANCELLED'}
        preset = str(settings.pipeline_preset or "SMART_DEFAULT")
        core = getattr(scene, "srr_settings", None)
        changes = 0
        if core is not None:
            for name, value in (
                ("show_advanced", True),
                ("render_elements_enabled", bool(settings.enable_aov_bundle)),
                ("network_render_enabled", bool(settings.enable_farm_handoff)),
                ("auto_unique_tokens", bool(settings.enable_token_naming)),
                ("auto_create_folders", True),
                ("skip_existing_frames", bool(settings.skip_existing_outputs)),
                ("use_placeholder", bool(settings.use_placeholders)),
                ("frame_chunk_size", int(settings.frame_chunk_size)),
                ("concurrent_tasks", int(settings.concurrent_tasks)),
                ("retry_count", int(settings.retry_count)),
                ("temporal_subsamples", int(settings.temporal_subsamples)),
                ("spatial_subsamples", int(settings.spatial_subsamples)),
                ("accumulation_samples", int(settings.accumulation_samples)),
                ("output_root", _resolve_output_dir(settings, create=True)),
            ):
                if _set_if_has(core, name, value):
                    changes += 1
            if preset in {"FINAL_AOV", "USD_SUPERSET", "REALTIME_HANDOFF"}:
                if _set_if_has(core, "pass_bundle", "COMPOSITE"):
                    changes += 1
                if _set_if_has(core, "render_elements_preset", "COMPOSITE"):
                    changes += 1
            elif preset == "DATASET":
                if _set_if_has(core, "pass_bundle", "DATASET"):
                    changes += 1
                if _set_if_has(core, "render_elements_preset", "DATASET"):
                    changes += 1
            elif preset == "LOOKDEV":
                if _set_if_has(core, "pass_bundle", "LOOKDEV"):
                    changes += 1
                if _set_if_has(core, "render_elements_preset", "LOOKDEV"):
                    changes += 1
            if _set_if_has(core, "bridge_target", str(settings.bridge_target)):
                changes += 1
            if _set_if_has(core, "network_render_target", str(settings.farm_target)):
                changes += 1
        render = getattr(scene, "render", None)
        if render is not None:
            if settings.prefer_multilayer_exr:
                image_settings = getattr(render, "image_settings", None)
                if set_image_file_format(image_settings, "OPEN_EXR_MULTILAYER"):
                    changes += 1
            if _set_if_has(render, "use_overwrite", not bool(settings.skip_existing_outputs)):
                changes += 1
            if _set_if_has(render, "use_placeholder", bool(settings.use_placeholders)):
                changes += 1
        if bool(settings.enable_aov_bundle):
            changes += _enable_common_passes(scene, preset=preset)
        if str(settings.view_layer_strategy) == "CREATE_STANDARD":
            changes += _create_standard_view_layers(scene)
        try:
            from .. import settings as persistent_settings
            persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
        except Exception:
            pass
        _safe_report(self, {'INFO'}, f"プリセットを反映しました: {changes} 件。", f"Applied preset: {changes} change(s).")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_build_queue(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.build_render_queue"
    bl_label = "Build Render Queue"
    bl_label = _t("レンダーキューを生成", "Build Render Queue")
    bl_description = action_tooltip(
        "カメラ、ビューレイヤー、Smart Renderバリアントをもとに、Batch Renderやレンダーキューを実行に近いキューを生成します。Smart Render本体のキューがある場合はそこへ反映します。",
        "Build a Batch Render or Run Render Queue style queue from cameras, View Layers, and Smart Render variants. If the Smart Render core queue exists, it is populated there.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            return {'CANCELLED'}
        queue = getattr(scene, "srr_queue", None)
        # Build from the scene: the current queue may be stale or only the disabled placeholder.
        rows = _generated_queue_rows(scene, settings)
        if queue is not None:
            try:
                queue.clear()
            except Exception:
                try:
                    while len(queue) > 0:
                        queue.remove(len(queue) - 1)
                except Exception:
                    queue = None
            if queue is not None:
                for row in rows:
                    try:
                        item = queue.add()
                        item.enabled = bool(row.get("enabled", True))
                        item.source_mode = str(row.get("source_mode", "PAIR") or "PAIR")
                        item.camera_name = str(row.get("camera", "") or "")
                        item.view_layer_name = str(row.get("view_layer", "") or "")
                        item.variant_name = str(row.get("variant", "") or "")
                        item.label = str(row.get("label", "") or safe_name(f"{item.camera_name}_{item.view_layer_name}_{item.variant_name}"))
                    except Exception:
                        continue
                try:
                    scene.srr_active_queue_index = 0
                except Exception:
                    pass
        try:
            from .. import settings as persistent_settings
            persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
        except Exception:
            pass
        _safe_report(self, {'INFO'}, f"キューを生成しました: {len(rows)} 件。", f"Built queue: {len(rows)} item(s).")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_create_standard_layers(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.create_standard_view_layers"
    bl_label = "Create Standard View Layers"
    bl_label = _t("標準ビューレイヤーを作成", "Create Standard View Layers")
    bl_description = action_tooltip(
        "ビューティー、マット、テクニカル、データセットの標準ビューレイヤーを、存在しない場合だけ作成します。既存レイヤーは削除しません。",
        "Create Beauty, Matte, Technical, and Dataset View Layers only when they do not already exist. Existing layers are not deleted.",
    )

    def execute(self, context):
        scene = _scene(context)
        if scene is None:
            return {'CANCELLED'}
        count = _create_standard_view_layers(scene)
        _safe_report(self, {'INFO'}, f"標準ビューレイヤーを確認しました: 新規 {count} 件。", f"Checked standard View Layers: {count} created.")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_export_manifest(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.export_manifest"
    bl_label = "Export Manifest"
    bl_label = _t("マニフェスト書出し", "Export Manifest")
    bl_description = action_tooltip(
        "添付リスト全体を横断する上位互換マニフェストをJSONで書き出します。既定では設定フォルダー/Smart_Render_Suite配下に保存されます。",
        "Export a superset JSON manifest that covers the attached feature list. By default it is saved under config/Smart_Render_Suite.",
    )

    def execute(self, context):
        settings = get_settings(context)
        if settings is None:
            return {'CANCELLED'}
        name = str(settings.manifest_name or "render_pipeline_manifest.json").strip() or "render_pipeline_manifest.json"
        if not name.lower().endswith(".json"):
            name += ".json"
        path = str(Path(_resolve_output_dir(settings, create=True)) / safe_name(name))
        try:
            data = _manifest(context, settings)
            _write_json(path, data)
            settings.last_manifest_path = path
            warnings = len(data.get("diagnostics", {}).get("warnings", []))
            errors = len(data.get("diagnostics", {}).get("errors", []))
            _store_report(settings, _last_report_lines(_scene(context), settings), warnings=warnings, errors=errors, coverage=sum(1 for item in data.get("coverage", []) if item.get("enabled")), quality=data.get("quality", {}))
        except Exception as exc:
            _safe_report(self, {'ERROR'}, "マニフェストの書き出しに失敗しました。", f"Failed to export manifest: {exc}")
            return {'CANCELLED'}
        _safe_report(self, {'INFO'}, f"マニフェストを書き出しました: {path}", f"Manifest exported: {path}")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_export_headless_script(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.export_headless_script"
    bl_label = "Export Headless Script"
    bl_label = _t("ヘッドレススクリプトを書き出し", "Export Headless Script")
    bl_description = action_tooltip(
        "現在のblendファイルをバックグラウンドレンダーするための簡易.bat または .shを生成します。外部ファームへ渡す前のローカル検証にも使えます。",
        "Generate a simple bat or sh file for background rendering the current blend file. This can also be used for local validation before handing off to a farm.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            return {'CANCELLED'}
        output_dir = Path(_resolve_output_dir(settings, create=True))
        base = safe_name(str(settings.script_name or "render_pipeline_headless"))
        is_windows = os.name == "nt"
        path = output_dir / f"{base}{'.bat' if is_windows else '.sh'}"
        blend_file = str(getattr(bpy.data, "filepath", "") or "")
        if not blend_file:
            blend_file = "<save_this_blend_file_first>"
        render_root = _resolve_output_dir(settings, create=True)
        frame_start = int(getattr(scene, 'frame_start', 1) or 1)
        frame_end = int(getattr(scene, 'frame_end', frame_start) or frame_start)
        if frame_end < frame_start:
            frame_start, frame_end = frame_end, frame_start
        frame_args = f"--render-frame {frame_start}" if frame_start == frame_end else f"--frame-start {frame_start} --frame-end {frame_end} --render-anim"
        engine = str(getattr(getattr(scene, "render", None), "engine", "") or "")
        output_template = safe_name(str(settings.naming_template or '{scene}_{frame}'))
        lines: list[str]
        if is_windows:
            lines = [
                "@echo off",
                "REM Generated by Render Pipeline Manager. Copyright (C) 2026 JELararagi.",
                "set BLENDER_EXE=blender",
                f"set BLEND_FILE={blend_file}",
                f"set OUTPUT_ROOT={render_root}",
                f"%BLENDER_EXE% -b \"%BLEND_FILE%\"" + (f" -E {engine}" if engine else "") + f" --render-output \"%OUTPUT_ROOT%\\{output_template}_####\" {frame_args}",
            ]
        else:
            lines = [
                "#!/usr/bin/env sh",
                "# Generated by Render Pipeline Manager. Copyright (C) 2026 JELararagi.",
                "BLENDER_EXE=${BLENDER_EXE:-blender}",
                f"BLEND_FILE='{blend_file}'",
                f"OUTPUT_ROOT='{render_root}'",
                f"$BLENDER_EXE -b \"$BLEND_FILE\"" + (f" -E {engine}" if engine else "") + f" --render-output \"$OUTPUT_ROOT/{output_template}_####\" {frame_args}",
            ]
        try:
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            if not is_windows:
                try:
                    path.chmod(path.stat().st_mode | 0o111)
                except Exception:
                    pass
            settings.last_script_path = str(path)
        except Exception as exc:
            _safe_report(self, {'ERROR'}, "スクリプトの生成に失敗しました。", f"Failed to export script: {exc}")
            return {'CANCELLED'}
        _safe_report(self, {'INFO'}, f"ヘッドレススクリプトを生成しました: {path}", f"Headless script exported: {path}")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_optimize_precision(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.optimize_precision_and_safety"
    bl_label = "Optimize Precision and Safety"
    bl_label = _t("精度と安全性を最適化", "Optimize Precision and Safety")
    bl_description = action_tooltip("現在のシーン、フレーム数、出力名、AOV、ファーム先を解析し、レンダー失敗と上書き衝突を避けるための安全寄り設定へ更新します。レンダー実行は行いません。", "Analyze the current scene, frame count, output names, AOVs, and farm target, then update settings toward safer render/farm handoff. This does not start rendering.")
    def execute(self, context):
        settings = get_settings(context); scene = _scene(context)
        if settings is None or scene is None: return {'CANCELLED'}
        changes = 0; quality = _quality_model(scene, settings); rec = quality.get("adaptive_recommendations", {}) if isinstance(quality, dict) else {}
        if bool(getattr(settings, "enable_adaptive_chunking", True)):
            for name, key in (("frame_chunk_size", "recommended_chunk_size"), ("retry_count", "recommended_retry_count"), ("concurrent_tasks", "recommended_concurrent_tasks"), ("temporal_subsamples", "recommended_temporal_subsamples"), ("spatial_subsamples", "recommended_spatial_subsamples"), ("accumulation_samples", "recommended_accumulation_samples")):
                if key in rec:
                    try:
                        value = int(rec.get(key) or getattr(settings, name))
                        if int(getattr(settings, name)) != value: setattr(settings, name, value); changes += 1
                    except Exception: pass
        if bool(getattr(settings, "enable_collision_prediction", True)):
            template = str(getattr(settings, "naming_template", "") or ""); required = ["{camera}", "{view_layer}", "{variant}", "{frame}"]
            if bool(getattr(settings, "enable_aov_bundle", True)): required.append("{pass}")
            missing_tokens = [token for token in required if token not in template]
            if missing_tokens:
                try: settings.naming_template = (template.strip() or "{scene}") + "_" + "_".join(missing_tokens); changes += 1
                except Exception: pass
        if bool(getattr(settings, "enable_aov_gap_analysis", True)): changes += _enable_common_passes(scene, preset=str(getattr(settings, "pipeline_preset", "SMART_DEFAULT") or "SMART_DEFAULT"))
        try: settings.skip_existing_outputs = True; settings.use_placeholders = True; settings.prefer_multilayer_exr = bool(getattr(settings, "enable_aov_bundle", True)); changes += 3
        except Exception: pass
        render = getattr(scene, "render", None)
        if render is not None:
            if _set_if_has(render, "use_overwrite", False): changes += 1
            if _set_if_has(render, "use_placeholder", True): changes += 1
            if bool(getattr(settings, "prefer_multilayer_exr", True)):
                image_settings = getattr(render, "image_settings", None)
                if set_image_file_format(image_settings, "OPEN_EXR_MULTILAYER"):
                    changes += 1
        quality = _quality_model(scene, settings); coverage = _coverage_entries(settings); warnings, errors = _diagnostics(scene, settings)
        _store_report(settings, _last_report_lines(scene, settings), warnings=len(warnings), errors=len(errors), coverage=sum(1 for item in coverage if item.get("enabled")), quality=quality)
        try:
            from .. import settings as persistent_settings; persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
        except Exception: pass
        _safe_report(self, {'INFO'}, f"精度と安全性を最適化を適用しました: {changes} 件。品質 {quality.get('score', 0)}/100。", f"Applied precision optimization: {changes} change(s). Quality {quality.get('score', 0)}/100.")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_export_submission_pack(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.export_submission_pack"
    bl_label = "Export Submission Pack"
    bl_label = _t("提出パックを書き出し", "Export Submission Pack")
    bl_description = action_tooltip("マニフェスト、キューCSV、アダプターレンダープロファイル、出力予測、AOV充足レポート、診断テキストをまとめて書き出します。外部DCC、ファーム、チーム共有用の実務パックです。", "Export a practical handoff pack containing a manifest, queue CSV, adapter profile, output prediction, AOV coverage report, and diagnostics text for external DCCs, farms, or team sharing.")
    def execute(self, context):
        settings = get_settings(context); scene = _scene(context)
        if settings is None or scene is None: return {'CANCELLED'}
        try:
            paths = _write_submission_pack(context, settings); settings.last_submission_pack_dir = str(Path(paths.get("manifest", "")).parent); settings.last_manifest_path = str(paths.get("manifest", ""))
            quality = _quality_model(scene, settings); warnings, errors = _diagnostics(scene, settings); coverage = _coverage_entries(settings)
            _store_report(settings, _last_report_lines(scene, settings), warnings=len(warnings), errors=len(errors), coverage=sum(1 for item in coverage if item.get("enabled")), quality=quality)
            try:
                from .. import settings as persistent_settings; persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
            except Exception: pass
        except Exception as exc:
            _safe_report(self, {'ERROR'}, "提出パックの書き出しに失敗しました。", f"Failed to export submission pack: {exc}"); return {'CANCELLED'}
        _safe_report(self, {'INFO'}, f"提出パックを書き出しました: {settings.last_submission_pack_dir}", f"Submission pack exported: {settings.last_submission_pack_dir}")
        return {'FINISHED'}



class RENDER_PIPELINE_OT_autopilot(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.run_production_autopilot"
    bl_label = "Run Production Autopilot"
    bl_label = _t("本番オートパイロットを実行", "Run Production Autopilot")
    bl_description = action_tooltip(
        "本番向けの一括処理です。精度モードを本番へ寄せ、主要検査を有効化し、AOVと安全設定を最適化し、キューと提出パックを生成します。レンダー実行や外部送信は行いません。",
        "One-click production preparation. It moves precision settings toward Production, enables major checks, optimizes AOV and safety settings, builds a queue, and exports a submission pack. It does not render or submit externally.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            return {'CANCELLED'}
        changes = 0
        desired_values = {
            "accuracy_mode": "PRODUCTION",
            "enable_collision_prediction": True,
            "enable_aov_gap_analysis": True,
            "enable_adaptive_chunking": True,
            "enable_deep_asset_scan": True,
            "enable_compositor_checks": True,
            "enable_color_management_checks": True,
            "enable_storage_estimate": True,
            "enable_validation": True,
            "enable_batch_queue": True,
            "enable_token_naming": True,
            "enable_aov_bundle": True,
            "enable_pdg_graph": True,
            "enable_farm_handoff": True,
            "skip_existing_outputs": True,
            "use_placeholders": True,
            "prefer_multilayer_exr": True,
            "quality_threshold": 90,
        }
        for name, value in desired_values.items():
            try:
                if getattr(settings, name) != value:
                    setattr(settings, name, value)
                    changes += 1
            except Exception:
                pass
        quality = _quality_model(scene, settings)
        rec = quality.get("adaptive_recommendations", {}) if isinstance(quality, dict) else {}
        for name, key in (("frame_chunk_size", "recommended_chunk_size"), ("retry_count", "recommended_retry_count"), ("concurrent_tasks", "recommended_concurrent_tasks"), ("temporal_subsamples", "recommended_temporal_subsamples"), ("spatial_subsamples", "recommended_spatial_subsamples"), ("accumulation_samples", "recommended_accumulation_samples")):
            if key not in rec:
                continue
            try:
                value = int(rec.get(key) or getattr(settings, name))
                if int(getattr(settings, name)) != value:
                    setattr(settings, name, value)
                    changes += 1
            except Exception:
                pass
        template = str(getattr(settings, "naming_template", "") or "").strip()
        required_tokens = ["{scene}", "{camera}", "{view_layer}", "{variant}", "{pass}", "{frame}"]
        missing_tokens = [token for token in required_tokens if token not in template]
        if missing_tokens:
            try:
                settings.naming_template = (template or "{scene}") + "_" + "_".join(missing_tokens)
                changes += 1
            except Exception:
                pass
        changes += _enable_common_passes(scene, preset=str(getattr(settings, "pipeline_preset", "SMART_DEFAULT") or "SMART_DEFAULT"))
        if str(getattr(settings, "view_layer_strategy", "KEEP") or "KEEP") == "CREATE_STANDARD":
            changes += _create_standard_view_layers(scene)
        rows = _queue_rows(scene, settings)
        try:
            queue = getattr(scene, "srr_queue", None)
            if queue is not None and hasattr(queue, "clear") and hasattr(queue, "add"):
                queue.clear()
                for row in rows:
                    item = queue.add()
                    try:
                        item.enabled = bool(row.get("enabled", True))
                        item.source_mode = str(row.get("source_mode", "PAIR") or "PAIR")
                        item.camera_name = str(row.get("camera", "") or "")
                        item.view_layer_name = str(row.get("view_layer", "") or "")
                        item.variant_name = str(row.get("variant", "") or "")
                        item.label = str(row.get("label", "") or safe_name(f"{item.camera_name}_{item.view_layer_name}_{item.variant_name}"))
                    except Exception:
                        continue
                changes += len(rows)
        except Exception:
            pass
        paths = {}
        try:
            paths = _write_submission_pack(context, settings)
            settings.last_submission_pack_dir = str(Path(paths.get("manifest", "")).parent)
            settings.last_manifest_path = str(paths.get("manifest", ""))
        except Exception:
            paths = {}
        quality = _quality_model(scene, settings)
        coverage = _coverage_entries(settings)
        warnings, errors = _diagnostics(scene, settings)
        _store_report(settings, _last_report_lines(scene, settings), warnings=len(warnings), errors=len(errors), coverage=sum(1 for item in coverage if item.get("enabled")), quality=quality)
        try:
            from .. import settings as persistent_settings
            persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
        except Exception:
            pass
        _safe_report(self, {'INFO'}, f"本番オートパイロットを実行を完了しました: {changes} 件更新、品質 {quality.get('score', 0)}/100。", f"Production autopilot finished: {changes} update(s), quality {quality.get('score', 0)}/100.")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_open_diagnostics_text(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.open_diagnostics_text"
    bl_label = "Open Diagnostics Text"
    bl_label = _t("診断テキストを開く", "Open Diagnostics Text")
    bl_description = action_tooltip(
        "最新の診断内容をBlenderのテキストエディター用テキストとして作成または更新します。長い警告や推奨を確認するための読みやすい表示です。",
        "Creates or updates a Blender Text Editor text block with the latest diagnostics so long warnings and recommendations are easy to inspect.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None or scene is None:
            return {'CANCELLED'}
        lines = _last_report_lines(scene, settings)
        try:
            text_name = "Render Pipeline Manager Diagnostics"
            txt = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
            txt.clear()
            txt.write("\n".join(str(line) for line in lines) + "\n")
            settings.last_report = "\n".join(str(line) for line in lines)
        except Exception as exc:
            _safe_report(self, {'ERROR'}, "診断テキストを作成できませんでした。", f"Could not create diagnostics text: {exc}")
            return {'CANCELLED'}
        _safe_report(self, {'INFO'}, "診断テキストを更新しました。", "Diagnostics text was updated.")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_copy_diagnostics(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.copy_diagnostics"
    bl_label = "Copy Diagnostics"
    bl_label = _t("診断をコピー", "Copy Diagnostics")
    bl_description = action_tooltip(
        "最新の診断内容をクリップボードへコピーします。チャット、チケット、チームレビューへ貼り付ける時に使います。",
        "Copies the latest diagnostics to the clipboard for chat, tickets, or team review.",
    )

    def execute(self, context):
        settings = get_settings(context)
        scene = _scene(context)
        if settings is None:
            return {'CANCELLED'}
        report = str(getattr(settings, "last_report", "") or "")
        if not report and scene is not None:
            report = "\n".join(str(line) for line in _last_report_lines(scene, settings))
        if not report:
            _safe_report(self, {'WARNING'}, "コピーできる診断結果がありません。", "No diagnostics are available to copy.")
            return {'CANCELLED'}
        try:
            context.window_manager.clipboard = report
        except Exception:
            pass
        _safe_report(self, {'INFO'}, "診断をコピーしました。", "Diagnostics copied.")
        return {'FINISHED'}



class RENDER_PIPELINE_OT_load_support_tools(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.load_support_tools"
    bl_label = "Load Support Tools"
    bl_label = _t("関連ツールを読み込む", "Load Support Tools")
    bl_description = action_tooltip(
        "Render Pipeline Managerの上位互換ワークフローでよく使う統合ツールだけを遅延読み込みします。全ツール一括読み込みは行いません。",
        "Lazy-load only the integrated tools commonly used by the Render Pipeline Manager superset workflow. This does not load every bundled tool.",
    )

    def execute(self, context):
        aliases = ["rendernames", "use_for_rendering_plus", "k_tools_render_preset_manager", "frame_range_renderer", "pseudo_rendering_farm", "freestyle_svg_exporter"]
        loaded = 0
        try:
            from .. import loader, settings as persistent_settings
            for alias in aliases:
                record = loader.load_alias(alias, force=False)
                if isinstance(record, dict) and str(record.get("status") or "") == "loaded":
                    loaded += 1
            persistent_settings.apply_context(context, force=True)
            persistent_settings.snapshot_context(context, force=persistent_settings.is_npanel_state_save_enabled(context))
        except Exception as exc:
            _safe_report(self, {'ERROR'}, "関連ツールの読み込みに失敗しました。", f"Failed to load support tools: {exc}")
            return {'CANCELLED'}
        _safe_report(self, {'INFO'}, f"関連ツールを読み込みました: {loaded} 件。", f"Loaded support tools: {loaded}.")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_copy_last_path(Operator):
    bl_options = {'UNDO'}
    bl_idname = "render_pipeline.copy_output_path"
    bl_label = "Copy Output Path"
    bl_label = _t("出力パスをコピー", "Copy Output Path")
    bl_description = action_tooltip(
        "最後に生成したマニフェストまたはヘッドレススクリプトのパスをクリップボードへコピーします。",
        "Copy the path of the last generated manifest or headless script to the clipboard.",
    )
    target: StringProperty(default="manifest", options={'SKIP_SAVE'})

    def execute(self, context):
        settings = get_settings(context)
        if settings is None:
            return {'CANCELLED'}
        path = settings.last_script_path if str(self.target) == "script" else settings.last_manifest_path
        if not path:
            _safe_report(self, {'WARNING'}, "コピーできるパスがまだありません。", "No path is available to copy yet.")
            return {'CANCELLED'}
        try:
            context.window_manager.clipboard = str(path)
        except Exception:
            pass
        _safe_report(self, {'INFO'}, f"コピーしました: {path}", f"Copied: {path}")
        return {'FINISHED'}


class RENDER_PIPELINE_OT_open_output_dir(Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "render_pipeline.open_output_folder"
    bl_label = "Open Output Folder"
    bl_label = _t("出力フォルダーを開く", "Open Output Folder")
    bl_description = action_tooltip(
        "Render Pipeline Managerの出力フォルダーをOSのファイルブラウザーで開きます。",
        "Open the Render Pipeline Manager output folder in the operating system file browser.",
    )

    def execute(self, context):
        settings = get_settings(context)
        if settings is None:
            return {'CANCELLED'}
        folder = _resolve_output_dir(settings, create=True)
        try:
            bpy.ops.wm.path_open(filepath=folder)
        except Exception:
            try:
                if os.name == "nt":
                    os.startfile(folder)  # type: ignore[attr-defined]
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", folder])
                else:
                    subprocess.Popen(["xdg-open", folder])
            except Exception as exc:
                _safe_report(self, {'ERROR'}, "フォルダーを開けませんでした。", f"Could not open folder: {exc}")
                return {'CANCELLED'}
        return {'FINISHED'}


def _enable_common_passes(scene, *, preset: str = "SMART_DEFAULT") -> int:
    changes = 0
    attrs = ["use_pass_z", "use_pass_normal", "use_pass_vector", "use_pass_object_index", "use_pass_material_index"]
    if preset in {"FINAL_AOV", "USD_SUPERSET", "REALTIME_HANDOFF", "DATASET"}:
        attrs.extend(["use_pass_uv", "use_pass_position", "use_pass_mist", "use_pass_diffuse_color", "use_pass_glossy_color", "use_pass_emit", "use_pass_environment", "use_pass_shadow", "use_pass_cryptomatte_object", "use_pass_cryptomatte_material", "use_pass_cryptomatte_asset"])
    for layer in getattr(scene, "view_layers", []) or []:
        for attr in attrs:
            if hasattr(layer, attr):
                try:
                    if not bool(getattr(layer, attr)):
                        setattr(layer, attr, True)
                        changes += 1
                except Exception:
                    pass
    return changes


def _create_standard_view_layers(scene) -> int:
    created = 0
    wanted = ("SRS_Beauty", "SRS_Matte", "SRS_Technical", "SRS_Dataset")
    existing = {str(getattr(layer, "name", "") or "") for layer in getattr(scene, "view_layers", []) or []}
    for name in wanted:
        if name in existing:
            continue
        try:
            scene.view_layers.new(name=name)
            created += 1
        except Exception:
            pass
    return created


def _report_lines(report) -> list:
    return str(report).splitlines()


def _draw_report(layout, settings) -> None:
    if not str(getattr(settings, "last_report", "") or "").strip():
        layout.label(text=_t("まだ診断結果はありません。", "No diagnostics have been run yet."))
        return
    box = layout.box()
    box.label(text=_t("最新結果", "Latest Result"), icon='TEXT')
    report_lines = _report_lines(settings.last_report)
    for line in report_lines[:18]:
        box.label(text=line[:180])
    if len(report_lines) > 18:
        box.label(text=_t("全文はテキストエディターで確認", "Full report: Text Editor"))



def _draw_score_card(layout, settings) -> None:
    score = int(getattr(settings, "last_quality_score", 0) or 0)
    threshold = int(getattr(settings, "quality_threshold", 85) or 85)
    errors = int(getattr(settings, "last_error_count", 0) or 0)
    warnings = int(getattr(settings, "last_warning_count", 0) or 0)
    collisions = int(getattr(settings, "last_collision_count", 0) or 0)
    aov = int(getattr(settings, "last_aov_coverage", 0) or 0)
    storage_mb = int(getattr(settings, "last_storage_estimate_mb", 0) or 0)
    readiness = str(getattr(settings, "last_readiness_label", "") or _readiness_word(score, threshold, errors))
    card = layout.box()
    header = card.row(align=True)
    header.label(text=_t(f"{readiness}  {score}/100", f"{readiness}  {score}/100"), icon='CHECKMARK' if score >= threshold and not errors else 'ERROR')
    header.label(text=_score_bar(score, 12))
    grid = card.grid_flow(columns=2, even_columns=True, even_rows=True, align=True)
    grid.label(text=_t(f"AOV {aov}%", f"AOV {aov}%"), icon='RENDER_RESULT')
    grid.label(text=_t(f"衝突 {collisions}", f"Collisions {collisions}"), icon='ERROR' if collisions else 'CHECKMARK')
    grid.label(text=_t(f"警告 {warnings}", f"Warnings {warnings}"), icon='ERROR' if warnings else 'CHECKMARK')
    grid.label(text=_t(f"容量 {round(storage_mb / 1024, 1)} GB", f"Storage {round(storage_mb / 1024, 1)} GB"), icon='FILE')
    if getattr(settings, "last_run_at", ""):
        card.label(text=str(settings.last_run_at), icon='TIME')


class RENDER_PIPELINE_PanelHelpMixin:
    """Adds a lightweight Help icon to each Render Pipeline Manager group header."""

    srs_help_key = ''

    def draw_header(self, _context):
        try:
            from ..help_operator import draw_help_button
            draw_help_button(
                self.layout,
                str(getattr(self, 'srs_help_key', '') or getattr(self, 'bl_idname', '') or 'integrated:render_pipeline'),
                tool_label=str(getattr(self, 'bl_label', '') or 'Render Pipeline Manager'),
            )
        except Exception:
            pass


class RENDER_PIPELINE_PT_RENDER_PIPELINE(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("Render Pipeline Manager", "Render Pipeline Manager")
    bl_idname = "RENDER_PIPELINE_PT_RENDER_PIPELINE"
    bl_label = "Render Pipeline"
    srs_help_key = "RENDER_PIPELINE_PT_RENDER_PIPELINE"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 24
    _srr_integrated_popover = True

    @classmethod
    def poll(cls, context):
        return get_settings(context) is not None

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        cockpit = layout.box()
        cockpit.label(text=_t("プロダクションコックピット", "Production Cockpit"), icon='RENDER_STILL')
        row = cockpit.row(align=True)
        _icon_button(row, "render_pipeline.run_production_autopilot", "autopilot", "本番化", "Autopilot", fallback_icon='PLAY', scale=3.0)
        _icon_button(row, "render_pipeline.analyze", "analyze", "診断", "Analyze", fallback_icon='VIEWZOOM', scale=3.0)
        _icon_button(row, "render_pipeline.optimize_precision_and_safety", "optimize", "最適化", "Optimize", fallback_icon='MODIFIER', scale=3.0)
        _icon_button(row, "render_pipeline.export_submission_pack", "pack", "提出", "Pack", fallback_icon='FILE_FOLDER', scale=3.0)
        row = cockpit.row(align=True)
        _icon_button(row, "render_pipeline.apply_pipeline_preset", "preset", "反映", "Preset", fallback_icon='CHECKMARK', scale=2.45)
        _icon_button(row, "render_pipeline.build_render_queue", "queue", "キュー", "Queue", fallback_icon='SEQ_STRIP_META', scale=2.45)
        _icon_button(row, "render_pipeline.export_manifest", "manifest", "JSON", "JSON", fallback_icon='FILE_TEXT', scale=2.45)
        _icon_button(row, "render_pipeline.load_support_tools", "support", "支援", "Tools", fallback_icon='TOOL_SETTINGS', scale=2.45)

        controls = layout.box()
        controls.label(text=_t("主要設定", "Primary Settings"), icon='PREFERENCES')
        controls.prop(settings, "pipeline_preset")
        controls.prop(settings, "accuracy_mode")
        controls.prop(settings, "job_name")

        _draw_score_card(layout, settings)


class RENDER_PIPELINE_PT_PRECISION_AND_SAFETY(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("精度と安全性", "Precision and Safety")
    bl_idname = "RENDER_PIPELINE_PT_PRECISION_AND_SAFETY"
    bl_label = "Precision and Safety"
    srs_help_key = "RENDER_PIPELINE_PT_PRECISION_AND_SAFETY"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "accuracy_mode")
        layout.prop(settings, "quality_threshold")
        layout.prop(settings, "enable_collision_prediction")
        layout.prop(settings, "enable_aov_gap_analysis")
        layout.prop(settings, "enable_adaptive_chunking")
        layout.prop(settings, "enable_deep_asset_scan")
        layout.prop(settings, "enable_compositor_checks")
        layout.prop(settings, "enable_color_management_checks")
        layout.prop(settings, "enable_storage_estimate")
        layout.prop(settings, "max_output_path_length")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.analyze", "analyze", "診断", "Analyze", fallback_icon='VIEWZOOM', scale=2.2)
        _icon_button(row, "render_pipeline.optimize_precision_and_safety", "precision", "精密化", "Precision", fallback_icon='MODIFIER', scale=2.2)
        _icon_button(row, "render_pipeline.run_production_autopilot", "autopilot", "本番化", "Autopilot", fallback_icon='PLAY', scale=2.2)
        _draw_score_card(layout, settings)


class RENDER_PIPELINE_PT_STATE_MANAGEMENT(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("ステート管理", "State Management")
    bl_idname = "RENDER_PIPELINE_PT_STATE_MANAGEMENT"
    bl_label = "State Management"
    srs_help_key = "RENDER_PIPELINE_PT_STATE_MANAGEMENT"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "state_system")
        layout.prop(settings, "enable_variant_take_graph")
        layout.prop(settings, "enable_scene_assembly")
        layout.prop(settings, "view_layer_strategy")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.create_standard_view_layers", "layers", "レイヤー", "Layers", fallback_icon='RENDERLAYERS', scale=2.3)
        _icon_button(row, "render_pipeline.apply_pipeline_preset", "preset", "反映", "Apply", fallback_icon='CHECKMARK', scale=2.3)


class RENDER_PIPELINE_PT_QUEUE_AND_NAMING(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("キューと命名", "Queue and Naming")
    bl_idname = "RENDER_PIPELINE_PT_QUEUE_AND_NAMING"
    bl_label = "Queue and Naming"
    srs_help_key = "RENDER_PIPELINE_PT_QUEUE_AND_NAMING"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "enable_batch_queue")
        layout.prop(settings, "enable_token_naming")
        layout.prop(settings, "naming_template")
        layout.prop(settings, "movie_template")
        layout.prop(settings, "frame_chunk_size")
        layout.prop(settings, "concurrent_tasks")
        layout.prop(settings, "retry_count")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.build_render_queue", "queue", "レンダーキューを生成", "Build Render Queue", fallback_icon='SEQ_STRIP_META', scale=2.3)
        _icon_button(row, "render_pipeline.export_headless_script", "script", "Headless", "Headless", fallback_icon='CONSOLE', scale=2.3)


class RENDER_PIPELINE_PT_AOV_AND_QUALITY(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("AOVと品質", "AOV and Quality")
    bl_idname = "RENDER_PIPELINE_PT_AOV_AND_QUALITY"
    bl_label = "AOV and Quality"
    srs_help_key = "RENDER_PIPELINE_PT_AOV_AND_QUALITY"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "enable_aov_bundle")
        layout.prop(settings, "enable_aov_gap_analysis")
        layout.prop(settings, "prefer_multilayer_exr")
        layout.prop(settings, "temporal_subsamples")
        layout.prop(settings, "spatial_subsamples")
        layout.prop(settings, "accumulation_samples")
        layout.prop(settings, "enable_realtime_handoff")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.apply_pipeline_preset", "preset", "AOV反映", "Apply AOV", fallback_icon='CHECKMARK', scale=2.3)
        _icon_button(row, "render_pipeline.analyze", "analyze", "検査", "Inspect", fallback_icon='VIEWZOOM', scale=2.3)


class RENDER_PIPELINE_PT_BRIDGE_AND_FARM(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("ブリッジとファーム", "Bridge and Farm")
    bl_idname = "RENDER_PIPELINE_PT_BRIDGE_AND_FARM"
    bl_label = "Bridge and Farm"
    srs_help_key = "RENDER_PIPELINE_PT_BRIDGE_AND_FARM"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "bridge_target")
        layout.prop(settings, "farm_target")
        layout.prop(settings, "enable_pdg_graph")
        layout.prop(settings, "enable_farm_handoff")
        layout.prop(settings, "include_cloud_cost_hints")
        layout.prop(settings, "farm_priority")
        layout.prop(settings, "execution_device_hint")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.export_manifest", "manifest", "JSON", "JSON", fallback_icon='FILE_TEXT', scale=2.4)
        _icon_button(row, "render_pipeline.export_submission_pack", "pack", "提出", "Pack", fallback_icon='FILE_FOLDER', scale=2.4)
        _icon_button(row, "render_pipeline.load_support_tools", "support", "支援", "Tools", fallback_icon='TOOL_SETTINGS', scale=2.4)


class RENDER_PIPELINE_PT_VALIDATION(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("検証", "Validation")
    bl_idname = "RENDER_PIPELINE_PT_VALIDATION"
    bl_label = "Validation"
    srs_help_key = "RENDER_PIPELINE_PT_VALIDATION"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "enable_validation")
        layout.prop(settings, "enable_deep_asset_scan")
        layout.prop(settings, "enable_compositor_checks")
        layout.prop(settings, "enable_color_management_checks")
        layout.prop(settings, "enable_storage_estimate")
        layout.prop(settings, "skip_existing_outputs")
        layout.prop(settings, "use_placeholders")
        layout.prop(settings, "limit_manifest_frames")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.analyze", "analyze", "再診断", "Recheck", fallback_icon='VIEWZOOM', scale=2.2)
        _icon_button(row, "render_pipeline.open_diagnostics_text", "report", "開く", "Open", fallback_icon='TEXT', scale=2.2)
        _icon_button(row, "render_pipeline.copy_diagnostics", "copy", "コピー", "Copy", fallback_icon='COPYDOWN', scale=2.2)
        _draw_report(layout, settings)


class RENDER_PIPELINE_PT_OUTPUT(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("出力", "Output")
    bl_idname = "RENDER_PIPELINE_PT_OUTPUT"
    bl_label = "Output"
    srs_help_key = "RENDER_PIPELINE_PT_OUTPUT"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        settings = get_settings(context)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.prop(settings, "output_dir")
        layout.prop(settings, "manifest_name")
        layout.prop(settings, "script_name")
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.export_manifest", "manifest", "JSON", "JSON", fallback_icon='FILE_TEXT', scale=2.2)
        _icon_button(row, "render_pipeline.export_headless_script", "script", "Script", "Script", fallback_icon='CONSOLE', scale=2.2)
        _icon_button(row, "render_pipeline.export_submission_pack", "pack", "Pack", "Pack", fallback_icon='FILE_FOLDER', scale=2.2)
        row = layout.row(align=True)
        _icon_button(row, "render_pipeline.copy_output_path", "copy_manifest", "JSONパス", "JSON Path", fallback_icon='COPYDOWN', scale=2.0, target="manifest")
        _icon_button(row, "render_pipeline.copy_output_path", "copy_script", "Script", "Script", fallback_icon='COPYDOWN', scale=2.0, target="script")
        _icon_button(row, "render_pipeline.open_output_folder", "folder", "開く", "Open", fallback_icon='FILE_FOLDER', scale=2.0)
        if settings.last_manifest_path:
            layout.label(text=str(settings.last_manifest_path)[:180], icon='FILE_TEXT', translate=False)
        if settings.last_script_path:
            layout.label(text=str(settings.last_script_path)[:180], icon='CONSOLE', translate=False)
        if settings.last_submission_pack_dir:
            layout.label(text=str(settings.last_submission_pack_dir)[:180], icon='FILE_FOLDER', translate=False)


class RENDER_PIPELINE_PT_UI_REFERENCE(RENDER_PIPELINE_PanelHelpMixin, Panel):
    bl_label = _t("UIリファレンス", "UI Reference")
    bl_idname = "RENDER_PIPELINE_PT_UI_REFERENCE"
    bl_label = "UI Reference"
    srs_help_key = "RENDER_PIPELINE_PT_UI_REFERENCE"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        _draw_pipeline_reference(layout)


CLASSES: tuple[type, ...] = (
    RENDER_PIPELINE_Settings,
    RENDER_PIPELINE_OT_analyze,
    RENDER_PIPELINE_OT_apply_preset,
    RENDER_PIPELINE_OT_build_queue,
    RENDER_PIPELINE_OT_create_standard_layers,
    RENDER_PIPELINE_OT_export_manifest,
    RENDER_PIPELINE_OT_export_headless_script,
    RENDER_PIPELINE_OT_optimize_precision,
    RENDER_PIPELINE_OT_export_submission_pack,
    RENDER_PIPELINE_OT_autopilot,
    RENDER_PIPELINE_OT_open_diagnostics_text,
    RENDER_PIPELINE_OT_copy_diagnostics,
    RENDER_PIPELINE_OT_load_support_tools,
    RENDER_PIPELINE_OT_copy_last_path,
    RENDER_PIPELINE_OT_open_output_dir,
    RENDER_PIPELINE_PT_RENDER_PIPELINE,
    RENDER_PIPELINE_PT_PRECISION_AND_SAFETY,
    RENDER_PIPELINE_PT_STATE_MANAGEMENT,
    RENDER_PIPELINE_PT_QUEUE_AND_NAMING,
    RENDER_PIPELINE_PT_AOV_AND_QUALITY,
    RENDER_PIPELINE_PT_BRIDGE_AND_FARM,
    RENDER_PIPELINE_PT_VALIDATION,
    RENDER_PIPELINE_PT_OUTPUT,
    RENDER_PIPELINE_PT_UI_REFERENCE,
)


def register() -> None:
    from ..rna_safety import register_pointer_property, ensure_registered_class, unregister_existing_class
    from ..translation import localize_class_attributes

    try:
        localize_class_attributes(CLASSES)
    except Exception:
        pass

    # Repair stale classes from interrupted reloads before PointerProperty registration.
    for cls in reversed(CLASSES):
        try:
            existing = getattr(bpy.types, getattr(cls, "__name__", ""), None)
            if existing is not None and existing is not cls:
                unregister_existing_class(existing)
        except Exception:
            pass

    _load_icon_previews()
    settings_cls = ensure_registered_class(RENDER_PIPELINE_Settings)
    for cls in CLASSES[1:]:
        ensure_registered_class(cls)

    # Image Editor N-panel mirroring is handled once by the Smart Render host
    # proxy system.  Remove stale direct clones from older builds so the tool
    # cannot appear twice or collide during registration after a hot reload.
    _IMAGE_EDITOR_PANEL_CLASSES.clear()
    for panel_cls in CLASSES:
        try:
            if not isinstance(panel_cls, type) or not issubclass(panel_cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        for identifier in (
            f"{getattr(panel_cls, '__name__', '')}_IMAGE_EDITOR",
            f"{getattr(panel_cls, 'bl_idname', '')}_IMAGE_EDITOR",
        ):
            if identifier.endswith('_IMAGE_EDITOR') and identifier != '_IMAGE_EDITOR':
                unregister_existing_class(identifier)

    register_pointer_property(bpy.types.WindowManager, WM_SETTINGS_PROPERTY, settings_cls)
    try:
        from .. import settings as persistent_settings
        persistent_settings.apply_context(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass


def unregister() -> None:
    from ..rna_safety import remove_rna_property, unregister_existing_class

    remove_rna_property(bpy.types.WindowManager, WM_SETTINGS_PROPERTY)
    while _IMAGE_EDITOR_PANEL_CLASSES:
        clone_cls = _IMAGE_EDITOR_PANEL_CLASSES.pop()
        unregister_existing_class(clone_cls)
    for cls in reversed(CLASSES):
        unregister_existing_class(cls)
    _unload_icon_previews()
