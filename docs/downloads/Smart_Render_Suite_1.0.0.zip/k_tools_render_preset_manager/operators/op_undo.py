# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Restore render settings saved immediately before the last preset load."""

import json

from bpy.types import Operator

from ...translation import iface_text
from ..utils import set_nested_attr

# An unavailable RNA enum is captured as an empty string. It is not an
# assignable color type or color-space name when the preset has changed modes.
_UNSET_RNA_ENUMS = {
    "display.shading.wireframe_color_type",
    "render.image_settings.linear_colorspace_settings.name",
}


class RENDER_PRESET_OT_undo(Operator):
    bl_idname = "render_preset.undo_preset_load"
    bl_label = "Undo Preset Load"
    bl_description = "Revert to the previous settings. This action cannot be undone"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = getattr(context, "scene", None)
        settings = getattr(scene, "render_preset_settings", None)
        return bool(getattr(settings, "undo_data", ""))

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = getattr(context, "scene", None)
        props = getattr(scene, "render_preset_settings", None)
        raw_history = getattr(props, "undo_data", "")
        if not raw_history:
            self.report({'WARNING'}, iface_text("No previous preset settings to restore."))
            return {'CANCELLED'}

        try:
            previous = json.loads(raw_history)
        except (TypeError, ValueError):
            self.report({'ERROR'}, iface_text("Saved render preset history is not valid JSON."))
            return {'CANCELLED'}

        # The loader stores a map: engine/category -> {property_path: value}.
        # Reject malformed snapshots before writing to Blender RNA.
        if not isinstance(previous, dict) or not previous or any(
            not isinstance(settings, dict) for settings in previous.values()
        ):
            self.report({'ERROR'}, iface_text("Saved render preset history has an invalid structure."))
            return {'CANCELLED'}

        changes = []
        for settings in previous.values():
            for path, value in settings.items():
                if not isinstance(path, str) or not path.strip():
                    self.report({'ERROR'}, iface_text("Saved render preset history contains an invalid property path."))
                    return {'CANCELLED'}
                changes.append((path, value))

        if not changes:
            self.report({'WARNING'}, iface_text("No previous preset settings to restore."))
            return {'CANCELLED'}

        restored = 0
        failures = []
        for path, value in changes:
            if value == "" and path in _UNSET_RNA_ENUMS:
                continue
            try:
                outcome = set_nested_attr(scene, path, value)
                if isinstance(outcome, (tuple, list)):
                    success = bool(outcome[0]) if outcome else False
                    reason = str(outcome[1]) if len(outcome) > 1 and outcome[1] else ""
                else:
                    success = bool(outcome)
                    reason = ""
                if success:
                    restored += 1
                else:
                    failures.append(f"{path}: {reason or 'not applied'}")
            except Exception as exc:
                failures.append(f"{path}: {exc}")

        if failures:
            # Keep the snapshot so the user can correct an unavailable property
            # and retry, rather than irreversibly losing a partial recovery.
            self.report({'WARNING'}, iface_text(
                f"Restored {restored} settings; {len(failures)} could not be restored. Undo history kept."
            ))
            return {'CANCELLED'}

        props.undo_data = ""
        props.loaded_preset_name = ""
        props.last_loaded_preset_path = ""
        self.report({'INFO'}, iface_text(f"Undo successful. Restored {restored} settings."))
        return {'FINISHED'}


classes = (RENDER_PRESET_OT_undo,)
