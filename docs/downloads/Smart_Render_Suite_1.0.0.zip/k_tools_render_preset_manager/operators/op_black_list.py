# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2026 JELararagi
"""Update the render preset property chooser from its public setting catalog.

Only the preferences collection is changed. User enable/disable decisions are
kept by setting path, including repeated entries in different categories.
"""

import bpy

from .. import utils
from ..properties.function_list import RENDER_SETTINGS


class RENDER_PRESET_OT_sync_blacklist(bpy.types.Operator):
    bl_idname = "render_preset.sync_property_list"
    bl_label = "Sync Property List"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        prefs = utils.get_addon_preferences(context)
        if prefs is None or not hasattr(prefs, "blacklist_items"):
            self.report({'ERROR'}, "Render preset preferences are unavailable")
            return {'CANCELLED'}

        collection = prefs.blacklist_items
        # Multiple previous entries for one path may disagree. An explicit
        # disabled choice must not silently become enabled during migration.
        choices = {}
        for item in collection:
            path = str(getattr(item, "path", "") or "").strip()
            if path:
                enabled = bool(getattr(item, "is_enabled", True))
                choices[path] = choices.get(path, True) and enabled

        # Keep one row per catalog entry: the same property can belong to
        # multiple UI categories. Deduplicating paths would hide those rows.
        rows = []
        for category, properties in RENDER_SETTINGS.items():
            for entry in properties:
                if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                    continue
                path, label = entry[0], entry[1]
                if not isinstance(path, str):
                    continue
                path = path.strip()
                if not path:
                    continue
                rows.append((path, str(label or path), str(category),
                             choices.get(path, True)))

        # Back up the original collection until the replacement is complete.
        previous = [
            (
                str(getattr(item, "path", "") or ""),
                str(getattr(item, "name", "") or ""),
                str(getattr(item, "category", "") or ""),
                bool(getattr(item, "is_enabled", True)),
            )
            for item in collection
        ]
        try:
            collection.clear()
            for path, label, category, enabled in rows:
                item = collection.add()
                item.path = path
                item.name = label
                item.category = category
                item.is_enabled = enabled
        except Exception as exc:
            # Do not leave partially refreshed preferences after a write error.
            try:
                collection.clear()
                for path, label, category, enabled in previous:
                    item = collection.add()
                    item.path = path
                    item.name = label
                    item.category = category
                    item.is_enabled = enabled
            except Exception:
                self.report({'ERROR'}, "Property list refresh failed; restoring the previous list also failed")
                return {'CANCELLED'}
            self.report({'ERROR'}, f"Property list refresh failed: {exc}")
            return {'CANCELLED'}

        return {'FINISHED'}


classes = (RENDER_PRESET_OT_sync_blacklist,)
