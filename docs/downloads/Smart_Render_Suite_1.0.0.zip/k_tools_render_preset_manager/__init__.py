

def _smarttools_console_output(*_args, **_kwargs):
    return None
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": 'Render Preset Manager',
    "author": "Robert Kezives, modified by JELararagi",
    "version": (1, 3, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Save, organize, sync, and restore render presets from the Smart Render N-panel integration.",
    "category": "Render",
}

import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
from .operators.op_user_presets import classes as ops_cls
from .operators.op_save import classes as save_ops
from .operators.op_undo import classes as undo_ops
from .operators.op_load import classes as load_cls
from .operators.op_delete import classes as delete_cls
from .operators.op_drag_n_drop import classes as drag_drop_cls
from .operators.op_black_list import classes as black_list_cls
from .ui import panels
from . import utils
from .operators import op_dev
from . import preferences
from . import runtime_preferences as runtime_prefs
from .properties import properties

def _auto_startup_sync_requested() -> bool:
    # Startup preset synchronization has been replaced by explicit Refresh
    # buttons in the Render Presets UI. This avoids registering a startup timer
    # from stale .blend/JSON values while preserving the same refresh operation
    # on demand.
    return False


def _run_startup_sync():
    """Refresh preset data once on startup, only if the user opted into it."""
    if not _auto_startup_sync_requested():
        return None
    try:
        if hasattr(bpy.ops.render_preset, 'sync_blacklist'):
            bpy.ops.render_preset.sync_property_list('EXEC_DEFAULT')
            bpy.ops.render_preset.refresh_user_presets()  # Refresh user's list only when explicitly requested.

    except Exception as e:
        _smarttools_console_output(f"Render Presets: Failed to auto-sync property list on startup: {e}")

    return None

classes = (
    *ops_cls,
    *save_ops,
    *undo_ops,    *load_cls,
    *drag_drop_cls,
    *delete_cls,
    *black_list_cls,
    )

def _register_external_render_injection():
    # Integrated mode: Smart Render re-exposes the UI through proxy
    # panels, so the original Render Properties injection stays disabled.
    return None


def _unregister_external_render_injection():
    return None


def register():
    for cls in classes:
        safe_register_class(cls)

    properties.register()    
    runtime_prefs.register()    
    preferences.register()    
    panels.register()    
    op_dev.register()    

    _register_external_render_injection()

    utils.ADDON_NAME = __package__

    # Preset synchronization is explicit. Remove any timer retained by an older
    # live-reload build and do not create a startup callback.
    try:
        if bpy.app.timers.is_registered(_run_startup_sync):
            bpy.app.timers.unregister(_run_startup_sync)
    except Exception:
        pass

def unregister():
    try:
        if bpy.app.timers.is_registered(_run_startup_sync):
            bpy.app.timers.unregister(_run_startup_sync)
    except Exception:
        pass
    for cls in reversed(classes):
        safe_unregister_class(cls)

    _unregister_external_render_injection()

    op_dev.unregister() 
    panels.unregister() 
    preferences.unregister() 
    runtime_prefs.unregister() 
    properties.unregister() 


if __name__ == "__main__":
    register()