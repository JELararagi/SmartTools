# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## Cross_Select
- Origin / 出どころ: extensions.blender.org: Cross_Select — https://vrm-addon-for-blender.info
- Copyright / 著作権者: RARA, CYX, Witty.Ming, Shuimeng
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - hdr_rotation/__init__.py
  - sun_position/draw.py

## cycles
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/cycles)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - profiler/ui.py
  - rendernames/__init__.py

## node_wrangler
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/node_wrangler)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - camera_plane/utils/image.py
  - profiler/__init__.py

## bl_operators
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_operators)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - sun_position/operators.py

## bl_ui
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_ui)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - camera_rigs/composition_guides_menu.py
  - camera_rigs/ui_panels.py
  - sun_position/ui_sun.py
  - use_for_rendering_plus/ui.py

## noise nodes (noise_nodes_20260920)
- Origin / 出どころ: noise nodes (public upstream source) — https://github.com/haseebahmed295/Noise-Nodes
- Copyright / 著作権者: haseebahmad295 <quicktiptech@gmail.com>
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - hdr_rotation/operators.py

## screencast (src)
- Origin / 出どころ: screencast (public upstream source) — https://github.com/nutti/Screencast-Keys
- Copyright / 著作権者: nutti, Paulo Gomes, Bart Crouch, John E. Herrenyo
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - sun_position/environment.py

## K-Tools Render Preset Manager (k_tools_render_preset_manager)
- Origin / 出どころ: https://github.com/r-kez/k_tools_render_preset_manager
- Copyright / 著作権者: Robert Kezives (r-kez)
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - k_tools_render_preset_manager/operators/op_undo.py
  - k_tools_render_preset_manager/preferences.py
