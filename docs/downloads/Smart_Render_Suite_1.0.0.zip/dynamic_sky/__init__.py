# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright 2026 JELararagi
"""Procedural world with independent horizon, directional sunlight and cloud controls."""
import bpy
from bpy.props import StringProperty
from ..help_operator import draw_help_button
from ..translation import localize_pair

# First three fields locate this implementation's editable shader input. The
# last three identify the public socket of worlds saved by earlier versions.
CONTROLS = (
    ('Lighting','Brightness','明るさ','Brightness','inputs',1,'Scene_Brightness','inputs',1),
    ('Lighting','Shadow saturation','影の彩度','Indirect color','inputs','Saturation','Shadow_color_saturation','inputs',1),
    ('Atmosphere','Sky color','空の色','Elevation colors','inputs',2,'Sky_and_Horizon_colors','inputs',1),
    ('Atmosphere','Horizon color','水平線の色','Elevation colors','inputs',1,'Sky_and_Horizon_colors','inputs',2),
    ('Atmosphere','Cloud color','雲の色','Cloud cover','inputs',2,'Cloud_color','inputs',1),
    ('Atmosphere','Cloud opacity','雲の不透明度','Cloud visibility','inputs',1,'Cloud_opacity','inputs',0),
    ('Atmosphere','Cloud density','雲の密度','Weather coverage','inputs',1,'Cloud_density','inputs',0),
    ('Sun','Sun color','太陽の色','Warm disk','inputs',2,'Sun_color','inputs',1),
    ('Sun','Sun strength','太陽の強さ','Disk intensity','inputs',1,'Sun_value','inputs',1),
    ('Sun','Edge hardness','太陽の輪郭','Disk falloff','inputs',0,'Soft_hard','inputs',0),
    ('Sun','Sun direction','太陽の方向','Solar direction','inputs',0,'Sky_normal','outputs',0),
)
GROUPS={'Lighting':('照明','Lighting'),'Atmosphere':('空と雲','Sky and clouds'),'Sun':('太陽','Sun')}

def build_world(world):
    world.use_nodes=True
    tree=world.node_tree
    tree.nodes.clear()
    def node(kind,name,x,y):
        n=tree.nodes.new(kind);n.name=name;n.label=name;n.location=(x,y)
        return n
    def wire(src,out,dst,entrance):
        tree.links.new(src.outputs[out],dst.inputs[entrance])
    def math(name,op,x,y,b=None):
        n=node('ShaderNodeMath',name,x,y);n.operation=op
        if b is not None:n.inputs[1].default_value=b
        return n
    def mix(name,x,y):
        return node('ShaderNodeMixRGB',name,x,y)
    angles=node('ShaderNodeTexCoord','Sky coordinates',0,480)
    normal=node('ShaderNodeVectorMath','Viewing direction',210,480);normal.operation='NORMALIZE'
    wire(angles,'Generated',normal,0)
    xyz=node('ShaderNodeSeparateXYZ','Altitude',430,730);wire(normal,'Vector',xyz,'Vector')
    elevation=math('Horizon blend','MULTIPLY',640,730,1.65);elevation.use_clamp=True;wire(xyz,'Z',elevation,0)
    base=mix('Elevation colors',870,730);wire(elevation,0,base,0)
    base.inputs[1].default_value=(.66,.74,.88,1);base.inputs[2].default_value=(.10,.28,.61,1)

    cloud=node('ShaderNodeTexNoise','Cloud layers',420,410);wire(normal,'Vector',cloud,'Vector')
    cloud.inputs['Scale'].default_value=4.2;cloud.inputs['Detail'].default_value=4.0
    cloud.inputs['Roughness'].default_value=.57
    cover=math('Weather coverage','ADD',640,400,.48);wire(cloud,'Fac',cover,0)
    mask=math('Cloud transition','MULTIPLY_ADD',865,400,5.2);mask.inputs[2].default_value=-4.8
    mask.use_clamp=True;wire(cover,0,mask,0)
    visible=math('Cloud visibility','MULTIPLY',1060,340,.75);visible.use_clamp=True;wire(mask,0,visible,0)
    sky=mix('Cloud cover',1280,670);wire(visible,0,sky,0);wire(base,0,sky,1);sky.inputs[2].default_value=(.92,.94,.97,1)

    sun=node('ShaderNodeVectorMath','Solar direction',210,40);sun.operation='NORMALIZE'
    sun.inputs[0].default_value=(.37,-.67,.64)
    dot=node('ShaderNodeVectorMath','Solar alignment',430,30);dot.operation='DOT_PRODUCT'
    wire(normal,0,dot,0);wire(sun,0,dot,1)
    front=math('Forward hemisphere','MAXIMUM',640,30,0);wire(dot,'Value',front,0)
    fall=math('Disk falloff','MULTIPLY_ADD',640,-190,850);fall.inputs[0].default_value=.55;fall.inputs[2].default_value=12
    disk=math('Sun disk','POWER',870,30);wire(front,0,disk,0);wire(fall,0,disk,1)
    strength=math('Disk intensity','MULTIPLY',1060,30,4.0);wire(disk,0,strength,0)
    warm=mix('Warm disk',1280,170);warm.blend_type='MULTIPLY';warm.inputs[0].default_value=1
    warm.inputs[2].default_value=(1,.77,.52,1);wire(strength,0,warm,1)
    total=node('ShaderNodeVectorMath','Sky radiance',1510,630);total.operation='ADD'
    wire(sky,0,total,0);wire(warm,0,total,1)

    indirect=node('ShaderNodeHueSaturation','Indirect color',1710,410);wire(total,'Vector',indirect,'Color')
    indirect.inputs['Saturation'].default_value=.85
    rays=node('ShaderNodeLightPath','Ray category',1690,110)
    lighting=mix('Sky and bounce light',1940,630);wire(rays,'Is Camera Ray',lighting,0)
    wire(indirect,'Color',lighting,1);wire(total,'Vector',lighting,2)
    bg=node('ShaderNodeBackground','Brightness',2160,630);wire(lighting,0,bg,'Color')
    output=node('ShaderNodeOutputWorld','World output',2370,630);wire(bg,0,output,'Surface')
    world['smart_render_sky_schema']=1

def editable_sockets(world):
    if not world or not world.node_tree:return {}
    current=world.get('smart_render_sky_schema')==1
    result={}
    for group,en,ja,n,side,i,old,oldside,oldi in CONTROLS:
        name,collection,index=(n,side,i) if current else (old,oldside,oldi)
        found=world.node_tree.nodes.get(name)
        if found is None:continue
        sockets=getattr(found,collection)
        sock=sockets.get(index) if isinstance(index,str) else sockets[index] if index<len(sockets) else None
        if sock is not None and hasattr(sock,'default_value'):result[en]=sock
    return result

def draw_world_controls(layout,context):
    scene=context.scene;world=scene.world
    if not world or not world.node_tree:
        layout.label(text=localize_pair('空を作成すると、ここで調整できます。','Create a sky to edit its controls here.'));return
    sockets=editable_sockets(world)
    if not sockets:
        layout.label(text=localize_pair('ワールドを選ぶか、新しい空を作成します。','Select a sky world or create one.'));return
    layout.label(text=world.name,icon='WORLD');group_now=None
    for group,en,ja,*_ in CONTROLS:
        if en not in sockets:continue
        if group!=group_now:group_now=group;layout.separator();layout.label(text=localize_pair(*GROUPS[group]))
        layout.prop(sockets[en],'default_value',text=localize_pair(ja,en))

class SMARTRENDER_OT_create_sky(bpy.types.Operator):
    bl_idname='sky.create_procedural_sky'
    bl_label='Create Procedural Sky'
    bl_description='Create a Cycles world with independently adjustable sky, clouds and sun'
    bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):return bool(context.scene and not context.scene.library)
    def execute(self,context):
        scene=context.scene;prior_world=scene.world;prior_engine=scene.render.engine;prior_name=scene.dynamic_sky_name
        world=bpy.data.worlds.new('Dynamic_1')
        try:
            build_world(world)
            scene.render.engine='CYCLES';scene.world=world;scene.dynamic_sky_name=world.name
        except Exception as err:
            scene.world=prior_world;scene.render.engine=prior_engine;scene.dynamic_sky_name=prior_name
            bpy.data.worlds.remove(world)
            self.report({'ERROR'},localize_pair('空を作成できませんでした。','Could not create the sky.')+' '+str(err))
            return {'CANCELLED'}
        return {'FINISHED'}

class SMARTRENDER_PT_dynamic_sky(bpy.types.Panel):
    bl_idname='DYNSKY_PT_DYNAMIC_SKY'
    bl_label='Dynamic Sky'
    bl_space_type='VIEW_3D';bl_region_type='HEADER';bl_context='objectmode'
    bl_options={'DEFAULT_CLOSED'};_srr_integrated_popover=True
    def draw_header_preset(self,context):draw_help_button(self.layout,'integrated:dynamic_sky')
    def draw(self,context):
        self.layout.operator(SMARTRENDER_OT_create_sky.bl_idname,text=localize_pair('空を作成','Create Sky'),icon='WORLD')
        draw_world_controls(self.layout,context)

def register():
    bpy.utils.register_class(SMARTRENDER_OT_create_sky);bpy.utils.register_class(SMARTRENDER_PT_dynamic_sky)
    bpy.types.Scene.dynamic_sky_name=StringProperty(name='Sky World',default='Dynamic')
def unregister():
    del bpy.types.Scene.dynamic_sky_name
    bpy.utils.unregister_class(SMARTRENDER_PT_dynamic_sky);bpy.utils.unregister_class(SMARTRENDER_OT_create_sky)
