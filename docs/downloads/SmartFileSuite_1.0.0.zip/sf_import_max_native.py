# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
import sys
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ImportHelper, axis_conversion, orientation_helper, poll_file_object_drop

@orientation_helper(axis_forward='Y', axis_up='Z')
class SF_OT_max_import(bpy.types.Operator, ImportHelper):
    """Import Autodesk MAX"""

    bl_idname = 'import_scene.sfs_max_import'
    bl_label = 'Import'
    bl_description = "Import Autodesk MAX (.max) files"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".max"
    filter_glob: StringProperty(default="*.max", options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH')

    scale_objects: FloatProperty(
        name="Scale",
        description="Scale factor for all objects",
        min=0.0,
        max=10000.0,
        soft_min=0.0,
        soft_max=10000.0,
        default=1.0,
    )
    use_image_search: BoolProperty(
        name="Image Search",
        description="Search subdirectories for any associated images (Warning, may be slow)",
        default=True,
    )
    object_filter: EnumProperty(
        name="Object Filter",
        options={'ENUM_FLAG'},
        items=(
            ('MATERIAL', "Material".rjust(12), "", 'MATERIAL_DATA', 0x1),
            ('UV', "UV Maps".rjust(11), "", 'UV_DATA', 0x2),
            ('PRIMITIVE', "Primitive".rjust(13), "", 'CUBE', 0x4),
            ('EMPTY', "Empty".rjust(11), "", 'EMPTY_AXIS', 0x8),
            ('ARMATURE', "Armature".rjust(11), "", 'ARMATURE_DATA', 0x10),
        ),
        description="Object types to import",
        default={'MATERIAL', 'UV', 'EMPTY', 'PRIMITIVE', 'ARMATURE'},
    )
    use_collection: BoolProperty(
        name="Collection",
        description="Create a new collection",
        default=False,
    )
    use_apply_matrix: BoolProperty(
        name="Apply Matrix",
        description="Use matrix to transform the objects",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        _sf_import_max_draw_include(layout, self)
        _sf_import_max_draw_transform(layout, self)

    def execute(self, context):
        _sf_import_max_cleanup_legacy_menu()
        keywords = _sf_import_max_build_keywords(self)
        keywords["global_matrix"] = axis_conversion(
            from_forward=self.axis_forward,
            from_up=self.axis_up,
        ).to_4x4()
        from .import_max import load as _sf_import_max_load
        return _sf_import_max_load(self, context, **keywords)

    def invoke(self, context, event):
        return self.invoke_popup(context)


class SF_IO_FH_max_3ds_max_file_handler(bpy.types.FileHandler):
    bl_idname = 'SF_IO_FH_max_3ds_max_file_handler'
    bl_label = '3ds Max File Handler'
    bl_import_operator = "import_scene.sfs_max_import"
    bl_file_extensions = ".max"

    @classmethod
    def poll_drop(cls, context):
        return poll_file_object_drop(context)


def _sf_import_max_collect_files(operator) -> list[str]:
    file_names: list[str] = []
    try:
        for item in getattr(operator, "files", ()):
            name = getattr(item, "name", None)
            if not name and isinstance(item, dict):
                name = item.get("name")
            if name:
                file_names.append(str(name))
    except Exception:
        pass

    return file_names


def _sf_import_max_build_keywords(operator) -> dict:
    return {
        "files": _sf_import_max_collect_files(operator),
        "directory": str(getattr(operator, "directory", "") or ""),
        "filepath": str(getattr(operator, "filepath", "") or ""),
        "scale_objects": float(getattr(operator, "scale_objects", 1.0) or 1.0),
        "use_collection": bool(getattr(operator, "use_collection", False)),
        "use_image_search": bool(getattr(operator, "use_image_search", True)),
        "object_filter": set(getattr(operator, "object_filter", set()) or set()),
        "use_apply_matrix": bool(getattr(operator, "use_apply_matrix", True)),
    }


def _sf_import_max_draw_include(layout, operator):
    header, body = layout.panel("SF_MAX_import_include", default_closed=False)
    header.label(text="Include")
    if body:
        row = body.row(align=True)
        row.prop(operator, "use_image_search")
        row.label(text="", icon='OUTLINER_OB_IMAGE' if operator.use_image_search else 'IMAGE_DATA')
        body.column().prop(operator, "object_filter")
        row = body.row(align=True)
        row.prop(operator, "use_collection")
        row.label(text="", icon='OUTLINER_COLLECTION' if operator.use_collection else 'GROUP')


def _sf_import_max_draw_transform(layout, operator):
    header, body = layout.panel("SF_MAX_import_transform", default_closed=False)
    header.label(text="Transform")
    if body:
        body.prop(operator, "scale_objects")
        row = body.row(align=True)
        row.prop(operator, "use_apply_matrix")
        row.label(text="", icon='VIEW_ORTHO' if operator.use_apply_matrix else 'MESH_GRID')
        body.prop(operator, "axis_forward")
        body.prop(operator, "axis_up")


def _sf_import_max_cleanup_legacy_menu() -> None:
    candidates = []
    package_name = str(__package__ or '').strip()
    if package_name:
        candidates.extend((f"{package_name}.import_max", f"{package_name}.import_max.__init__"))
    for module_name in candidates:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        menu_func = getattr(module, 'menu_func', None)
        if not callable(menu_func):
            continue
        try:
            bpy.types.TOPBAR_MT_file_import.remove(menu_func)
        except Exception:
            pass


try:
    classes = tuple(classes) + (
        SF_OT_max_import,
        SF_IO_FH_max_3ds_max_file_handler,
    )
except Exception:
    pass
