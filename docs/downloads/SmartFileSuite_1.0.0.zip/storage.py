# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_file_suite'
USER_DATA_DIRNAME = 'user_data'
CONFIG_DIRNAME = 'Smart_File_Suite'
LEGACY_PACKAGE_IDS = (PACKAGE_ID,)
LEGACY_MUTABLE_PATHS = (
    'user_data',
    'cache',
    'handoff',
    'runtime',
    'reports',
    'exports',
    'presets',
    'profiles',
    'autosave',
    'settings',
    'history',
    'bundles',
    'locks',
    'renders',
    'ikea_cache',
    'file_pipeline',
    'universal_multi_importer/autosave',
    'universal_multi_importer/logs',
    'universal_multi_importer/presets',
    'universal_multi_importer/color_presets',
    'decentraland_tools/temp',
    'decentraland_tools/exports',
    'decentraland_tools/imports',
    'decentraland_tools/avatars',
)


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_file_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _config_root(create: bool = False) -> Path:
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': bool(create)}),
                (('CONFIG',), {'create': bool(create)}),
                (('CONFIG',), {}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    value = ''
                if value:
                    path = Path(value)
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                    return path
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_root(*parts: object, create: bool = False) -> Path:
    """Canonical root for every automatic Smart File mutable artifact."""
    path = _config_root(create=create) / CONFIG_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_data_dir(*parts: object, create: bool = False) -> Path:
    return mutable_root(USER_DATA_DIRNAME, *parts, create=create)


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Return the installed Extension package as a read-only location.

    ``create`` remains accepted for compatibility but is deliberately ignored.
    """
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    """Legacy writable API redirected to CONFIG/Smart_File_Suite."""
    del package_id
    root = mutable_root(create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=False)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    return mutable_data_dir(*parts, create=create)


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    del package
    root = mutable_data_dir('runtime', create=create)
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    del package_id
    root = mutable_data_dir('storage', create=create)
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(text, encoding=encoding)
    tmp.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def _legacy_extension_roots(package: object | None = None) -> tuple[Path, ...]:
    """Return every plausible pre-CONFIG Smart File package root.

    Older builds wrote mutable files below the installed Extension directory.
    Blender's path API changed across 4.x/5.x and source-mode tests do not always
    resolve the same repository as the active CONFIG directory, so migration must
    inspect all supported legacy locations.  These paths are read-only migration
    sources; new data is always written through :func:`mutable_root`.
    """
    package_name = package_id(package or PACKAGE_ID)
    candidates: list[Path] = []

    installed = _installed_extension_root() if package_name == PACKAGE_ID else None
    if installed is not None:
        candidates.append(installed)

    for candidate in (
        _extension_path_user_root(package_name, False),
        _user_resource_root(package_name, False),
    ):
        if candidate is not None:
            candidates.append(candidate)

    # CONFIG and SCRIPTS based fallbacks cover Blender 4.x/5.x repository
    # layouts as well as portable/source-mode installs.
    try:
        config = _config_root(create=False)
        for folder_name in (package_name, 'smart_file_suite', 'Smart_File_Suite'):
            candidates.append(config.parent / 'extensions' / 'user_default' / folder_name)
            candidates.append(config / 'extensions' / 'user_default' / folder_name)
    except Exception:
        pass

    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                scripts = user_resource('SCRIPTS', create=False) or ''
            except TypeError:
                try:
                    scripts = user_resource('SCRIPTS') or ''
                except Exception:
                    scripts = ''
            except Exception:
                scripts = ''
            if scripts:
                scripts_root = Path(scripts)
                for folder_name in (package_name, 'smart_file_suite', 'Smart_File_Suite'):
                    candidates.append(scripts_root / 'extensions' / 'user_default' / folder_name)
                    candidates.append(scripts_root / 'extensions_user' / folder_name)

    # Some legacy archives placed a user_default folder beside the package.
    package_root = _package_root()
    for folder_name in (package_name, 'smart_file_suite', 'Smart_File_Suite'):
        candidates.append(package_root / 'user_default' / folder_name)
        candidates.append(package_root.parent / 'user_default' / folder_name)

    unique: list[Path] = []
    seen: set[str] = set()
    canonical = mutable_root(create=False)
    try:
        canonical_key = os.path.normcase(str(canonical.resolve()))
    except Exception:
        canonical_key = os.path.normcase(str(canonical))
    for candidate in candidates:
        try:
            normalized = os.path.normcase(str(candidate.resolve()))
        except Exception:
            normalized = os.path.normcase(str(candidate))
        if not normalized or normalized == canonical_key or normalized in seen:
            continue
        seen.add(normalized)
        unique.append(candidate)
    return tuple(unique)


def legacy_package_mutable_path(relative: object, package: object | None = None) -> Path:
    """Compatibility helper returning the primary legacy path.

    Migration itself uses every path from :func:`_legacy_extension_roots`.
    """
    clean = _clean_parts([relative])
    roots = _legacy_extension_roots(package or PACKAGE_ID)
    root = roots[0] if roots else extension_user_root(package or PACKAGE_ID, create=False)
    return root.joinpath(*clean)


def migrate_legacy_mutable_data() -> dict[str, int]:
    """Copy known old package-local mutable data to CONFIG, never deleting it.

    Existing destination files always win.  Source files remain untouched so a
    failed or interrupted migration cannot destroy recovery history.
    """
    result = {'roots': 0, 'sources': 0, 'copied': 0, 'skipped': 0}
    target_root = mutable_root(create=True)
    seen_sources: set[str] = set()
    seen_roots: set[str] = set()
    for legacy_id in LEGACY_PACKAGE_IDS:
        for package_root in _legacy_extension_roots(legacy_id):
            try:
                root_key = os.path.normcase(str(package_root.resolve()))
            except Exception:
                root_key = os.path.normcase(str(package_root))
            if root_key in seen_roots:
                continue
            seen_roots.add(root_key)
            result['roots'] += 1
            for relative_text in LEGACY_MUTABLE_PATHS:
                source_root = package_root.joinpath(*_clean_parts([relative_text]))
                try:
                    source_key = os.path.normcase(str(source_root.resolve()))
                except Exception:
                    source_key = os.path.normcase(str(source_root))
                if source_key in seen_sources:
                    continue
                seen_sources.add(source_key)
                try:
                    if not source_root.is_dir() or source_root.is_symlink():
                        continue
                except Exception:
                    continue
                result['sources'] += 1
                relative_root = Path(*_clean_parts([relative_text]))
                for source in source_root.rglob('*'):
                    try:
                        relative = source.relative_to(source_root)
                        if source.is_symlink() or not source.is_file():
                            continue
                        if '__pycache__' in relative.parts or source.suffix.lower() in {'.pyc', '.pyo'}:
                            result['skipped'] += 1
                            continue
                        target = target_root / relative_root / relative
                        if target.exists():
                            result['skipped'] += 1
                            continue
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, target)
                        result['copied'] += 1
                    except Exception:
                        result['skipped'] += 1
    return result


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        legacy_text = legacy.resolve().as_posix().lower()
        package_source = '/extensions/user_default/' in legacy_text
        if remove_legacy and not package_source:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
