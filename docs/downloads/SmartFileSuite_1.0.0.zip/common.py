# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

import json
import os
import re
import sys
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty
from .ui_language_runtime import error_text as _sf_error_text

PACKAGE_ID = 'smart_file_suite'
ADDON_NAME = 'Smart_File_Suite'
TOOL_LABEL_EN = 'Smart File'
TOOL_LABEL_JA = 'スマートファイル'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'
_CONFIG_DIR_NAME = 'Smart_File_Suite'
_CONFIG_FILE_NAME = 'Smart_File_Suite.json'

_PREVIEW_COLLECTION = None
_PREVIEW_COLLECTION_KEY = 'smart_file_suite.common.preview_collection'
_REGISTERED_CLASSES = []
_REGISTERED_CLASS_RECORDS = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_COMMON_OWNER_KEY = 'JELararagi.smart_file.common.lifecycle.v57540'
_COMMON_LEGACY_OWNER_KEYS = (
    'JELararagi.smart_file.common.lifecycle.v57539',
    'JELararagi.smart_file.common.lifecycle.v57536',
    'JELararagi.smart_file.common.lifecycle.v57535',
    'JELararagi.smart_file.common.lifecycle.v57534',
    'JELararagi.smart_file.common.lifecycle.v57533',
)
_COMMON_OWNER_TOKEN = object()
_COMMON_OWNER_GENERATION = __import__('uuid').uuid4().hex
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_APPLY_GUARD_KEY = 'smart_file_suite_settings_apply_suspended'
_RUNTIME_SETTING_EXCLUDE_NAMES = {
    # Scene-local object references must stay in the .blend. Replaying them from
    # global user_default settings can make thumbnail update callbacks move
    # cameras, empties, or lights back to old computed transforms on file load.
    'thumbnail_camera_name',
    'thumbnail_target_name',
}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時起動切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_EN,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    """Return the Smart File runtime storage root inside Blender CONFIG."""
    try:
        from .storage_paths import user_default_root
        root = Path(user_default_root(_STORAGE_DIRNAME, create=create))
    except Exception:
        try:
            root = Path(bpy.utils.user_resource('CONFIG', path='', create=create)) / 'Smart_File_Suite' / _STORAGE_DIRNAME
        except Exception:
            try:
                version = getattr(getattr(bpy, 'app', None), 'version', None)
                version_str = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
            except Exception:
                version_str = '5.1'
            if os.name == 'nt':
                roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
                base = Path(roaming) / 'Blender Foundation' / 'Blender' / version_str / 'config' / 'Smart_File_Suite'
            else:
                base = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version_str / 'config' / 'Smart_File_Suite'
            root = base / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _version_string() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def config_settings_path(create_parent=True):
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                root = Path(user_resource('CONFIG', path='', create=bool(create_parent)))
            except TypeError:
                root = Path(user_resource('CONFIG', create=bool(create_parent)))
            root = root / _CONFIG_DIR_NAME
            if create_parent:
                root.mkdir(parents=True, exist_ok=True)
            return root / _CONFIG_FILE_NAME
    except Exception:
        pass
    version = _version_string()
    if os.name == 'nt':
        root = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config' / _CONFIG_DIR_NAME
    else:
        root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config' / _CONFIG_DIR_NAME
    if create_parent:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root / _CONFIG_FILE_NAME

def settings_path():
    return config_settings_path(True)


def _sf_previews_module():
    try:
        import bpy.utils.previews as previews_mod
        return previews_mod
    except Exception:
        pass
    try:
        return getattr(getattr(bpy, 'utils', None), 'previews', None)
    except Exception:
        return None


def _icon_root_candidates():
    candidates = [package_root() / 'icons']
    try:
        func = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
        if callable(func):
            for package_id in (PACKAGE_ID, ADDON_NAME):
                try:
                    candidates.append(Path(func(package_id, path='icons', create=False)))
                except TypeError:
                    try:
                        candidates.append(Path(func(package_id, path='icons')))
                    except Exception:
                        pass
                except Exception:
                    pass
    except Exception:
        pass
    seen = set()
    unique = []
    for candidate in candidates:
        try:
            key = str(candidate.resolve())
        except Exception:
            key = str(candidate)
        if key not in seen:
            seen.add(key)
            unique.append(candidate)
    return unique


def _driver_namespace_preview_collection():
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if ns is None:
            return None
        return ns.get(_PREVIEW_COLLECTION_KEY)
    except Exception:
        return None


def _store_driver_namespace_preview_collection(pcoll) -> None:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if ns is not None and pcoll is not None:
            ns[_PREVIEW_COLLECTION_KEY] = pcoll
    except Exception:
        pass


def _preview_contains(pcoll, key: str) -> bool:
    try:
        return key in pcoll
    except Exception:
        try:
            return pcoll.get(key) is not None
        except Exception:
            return False


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        _store_driver_namespace_preview_collection(_PREVIEW_COLLECTION)
        try:
            from . import preview_cleanup as _sf_preview_cleanup
            _sf_preview_cleanup.register_atexit()
        except Exception:
            pass
        return _PREVIEW_COLLECTION
    pcoll = _driver_namespace_preview_collection()
    if pcoll is not None:
        _PREVIEW_COLLECTION = pcoll
        try:
            from . import preview_cleanup as _sf_preview_cleanup
            _sf_preview_cleanup.register_atexit()
        except Exception:
            pass
    previews_mod = _sf_previews_module()
    if previews_mod is None:
        return _PREVIEW_COLLECTION
    try:
        if _PREVIEW_COLLECTION is None:
            _PREVIEW_COLLECTION = previews_mod.new()
            _store_driver_namespace_preview_collection(_PREVIEW_COLLECTION)
            try:
                from . import preview_cleanup as _sf_preview_cleanup
                _sf_preview_cleanup.register_atexit()
            except Exception:
                pass
        icon_files = {
            'header': 'smart_file_header.png',
        }
        for icons_dir in _icon_root_candidates():
            for name, filename in icon_files.items():
                path = icons_dir / filename
                if path.exists():
                    try:
                        if not _preview_contains(_PREVIEW_COLLECTION, str(name)):
                            _PREVIEW_COLLECTION.load(str(name), str(path), 'IMAGE')
                    except Exception:
                        pass
    except Exception:
        pass
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    """Read an already prepared icon; Panel.draw never creates or loads files."""
    global _PREVIEW_COLLECTION
    pcoll = _PREVIEW_COLLECTION or _driver_namespace_preview_collection()
    if _PREVIEW_COLLECTION is None and pcoll is not None:
        _PREVIEW_COLLECTION = pcoll
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return int(fallback or 0)


def _remove_previews():
    global _PREVIEW_COLLECTION
    # The root lifecycle removes the exact preview collection after every Panel
    # and menu callback has been unregistered.  Drop this module reference now.
    _PREVIEW_COLLECTION = None

def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


class SMART_FILE_OT_system_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'smart_file_suite.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    bl_options = set()
    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from . import help as _help
        _help.draw_help_popup(self.layout, context, help_key=self.topic, popup_width=680)


class SMART_FILE_OT_system_always_on_toggle(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, _sf_error_text(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, _sf_error_text(exc))
        try:
            save_persistent_settings(context, force=False)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_FILE_OT_system_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save current N-panel settings to Blender config/Smart_File_Suite/Smart_File_Suite.json and request Blender to save user preferences.'

    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        saved = bool(save_persistent_settings(context, force=True, allow_disabled=True))
        if not saved:
            self.report({'ERROR'}, text(
                'Smart File settings could not be saved.',
                'Smart File 設定を保存できませんでした。',
                context,
            ))
            return {'CANCELLED'}
        try:
            result = bpy.ops.wm.save_userpref()
        except Exception as exc:
            self.report({'ERROR'}, _sf_error_text(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'} if result != {'CANCELLED'} else {'CANCELLED'}


class SMART_FILE_PT_system_file_suite_always_on_toggle(bpy.types.Panel):
    bl_idname = 'SMART_FILE_PT_system_file_suite_always_on_toggle'
    bl_label = 'Always-on Toggles'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 0
    _sfs_inline_top_section_replacement = True

    @classmethod
    def poll(cls, context):
        # Keep this historical public Panel ID registered for compatibility.
        # The usable body now lives in the first shared top-level root section.
        return False

    def draw_header(self, context):
        self.layout.label(text='', icon='TIME')

    def draw_header_preset(self, context):
        op = self.layout.operator('smart_file_suite.open_help', text='', icon='QUESTION')
        op.topic = 'always_on'

    def draw(self, context):
        package_name = str(__package__ or '').strip()
        module_name = f'{package_name}.reference_manager' if package_name else 'reference_manager'
        module = sys.modules.get(module_name)
        draw_body = getattr(module, '_sf_draw_always_on_switches_body', None) if module is not None else None
        if callable(draw_body):
            draw_body(self.layout, context)
        else:
            draw_always_on_panel(self.layout, context)
        return None


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _class_owned_rna(cls):
    try:
        rna = vars(cls).get('bl_rna') if isinstance(cls, type) else None
        return bool(rna is not None and str(getattr(rna, 'identifier', '') or '').strip())
    except Exception:
        return False


def _safe_unregister_class(cls):
    record = next((item for item in _REGISTERED_CLASS_RECORDS if item.get('class') is cls), None)
    if not isinstance(record, dict) or not bool(record.get('acquired')):
        return True
    if record.get('token') is not _COMMON_OWNER_TOKEN or record.get('generation') != _COMMON_OWNER_GENERATION:
        return False
    if not _class_owned_rna(cls):
        record['acquired'] = False
        return True
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        return False
    if _class_owned_rna(cls):
        return False
    record['acquired'] = False
    return True


def _flatten_npanel_parent_before_register(cls):
    # Parent metadata is part of the canonical public surface and is never
    # rewritten during registration.
    return cls


def _register_class_wrapper(cls):
    _materialize_annotations(cls)
    if _class_owned_rna(cls):
        if not any(item.get('class') is cls for item in _REGISTERED_CLASS_RECORDS):
            _REGISTERED_CLASS_RECORDS.append({
                'class': cls, 'acquired': False,
                'token': _COMMON_OWNER_TOKEN,
                'generation': _COMMON_OWNER_GENERATION,
            })
        return cls
    bpy.utils.register_class(cls)
    if not _class_owned_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'class-owned RNA validation failed: {getattr(cls, "__name__", cls)!s}')
    _REGISTERED_CLASS_RECORDS.append({
        'class': cls, 'acquired': True,
        'token': _COMMON_OWNER_TOKEN,
        'generation': _COMMON_OWNER_GENERATION,
    })
    return cls


def begin_register():
    # Retained for compatibility. Registration is explicit and never replaces
    # process-global bpy.utils.register_class.
    return True


def end_register():
    return True


def _common_namespace():
    try:
        value = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _common_cleanup_generation():
    ok = True
    for record in reversed(tuple(_REGISTERED_CLASS_RECORDS)):
        cls = record.get('class')
        if isinstance(cls, type) and not _safe_unregister_class(cls):
            ok = False
    _REGISTERED_CLASS_RECORDS.clear()
    _REGISTERED_CLASSES.clear()
    return ok


def _common_cleanup_external_owner(existing):
    cleanup = existing.get('cleanup') if isinstance(existing, dict) else None
    if not callable(cleanup):
        return False
    try:
        try:
            return bool(cleanup(existing.get('token'), existing.get('generation')))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def _common_install_owner():
    namespace = _common_namespace()
    if namespace is None:
        return False
    for legacy_key in _COMMON_LEGACY_OWNER_KEYS:
        legacy = namespace.get(legacy_key)
        if legacy is not None:
            if not _common_cleanup_external_owner(legacy):
                return False
            namespace.pop(legacy_key, None)
    existing = namespace.get(_COMMON_OWNER_KEY)
    if isinstance(existing, dict) and not (
        existing.get('token') is _COMMON_OWNER_TOKEN
        and existing.get('generation') == _COMMON_OWNER_GENERATION
    ):
        if not _common_cleanup_external_owner(existing):
            return False
        namespace.pop(_COMMON_OWNER_KEY, None)
    namespace[_COMMON_OWNER_KEY] = {
        'token': _COMMON_OWNER_TOKEN,
        'generation': _COMMON_OWNER_GENERATION,
        'classes': _REGISTERED_CLASS_RECORDS,
        'cleanup': _common_cleanup_generation,
    }
    return True


def _iter_relevant_panels():
    """Yield only exact classes already owned by this module generation."""
    for cls in tuple(_REGISTERED_CLASSES):
        try:
            if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
                yield cls
        except Exception:
            continue


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _is_smart_file_sidebar_panel(cls) -> bool:
    try:
        return (
            str(getattr(cls, 'bl_space_type', '') or '').upper() == 'VIEW_3D'
            and str(getattr(cls, 'bl_region_type', '') or '').upper() == 'UI'
            and str(getattr(cls, 'bl_category', '') or '') == PANEL_CATEGORY
        )
    except Exception:
        return False


def _sanitize_sidebar_header_callback(cls) -> None:
    # Retained for compatibility; canonical class metadata is never mutated.
    del cls
    return None


def _patch_panel_headers():
    # Canonical classes define their own UI; never mutate draw/poll callbacks.
    return None


def _unpatch_panel_headers():
    return None


def _iter_relevant_addon_preferences():
    """Yield only exact classes already owned by this module generation."""
    for cls in tuple(_REGISTERED_CLASSES):
        try:
            if isinstance(cls, type) and issubclass(cls, bpy.types.AddonPreferences):
                yield cls
        except Exception:
            continue


def _patch_addon_preferences():
    # Canonical classes define their own UI; never mutate draw/poll callbacks.
    return None


def _unpatch_addon_preferences():
    return None


def _set_apply_guard(enabled: bool) -> None:
    try:
        bpy.app.driver_namespace[_APPLY_GUARD_KEY] = bool(enabled)
    except Exception:
        pass


def _persistent_setting_excluded(name) -> bool:
    try:
        return str(name or '') in _RUNTIME_SETTING_EXCLUDE_NAMES
    except Exception:
        return False


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False) or _persistent_setting_excluded(identifier):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        if _persistent_setting_excluded(key):
            continue
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                try:
                    current = getattr(obj, key)
                    if _simple_rna_value(current) == _simple_rna_value(value):
                        continue
                except Exception:
                    pass
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    _set_apply_guard(True)
    try:
        for root_name, root in _iter_setting_roots(ctx):
            if root_name in data:
                _apply_group(root, data[root_name], 0)
    finally:
        _set_apply_guard(False)


def load_settings_file():
    global _LOADED_SETTINGS
    path = settings_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                data = raw.get('common_settings') if isinstance(raw.get('common_settings'), dict) else raw
                _LOADED_SETTINGS = data if isinstance(data, dict) else {}
                return _LOADED_SETTINGS
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}



def _npanel_state_save_enabled(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None)
        prefs = getattr(wm, 'sf_addon_settings', None) if wm is not None else None
        if prefs is not None and hasattr(prefs, 'enable_npanel_settings_keeper'):
            return bool(getattr(prefs, 'enable_npanel_settings_keeper'))
    except Exception:
        pass
    return False


def save_persistent_settings(context=None, force=False, allow_disabled=False):
    """Save N-panel settings through the central config keeper.

    The single persistent settings file is Blender's versioned config folder:
    Smart_File_Suite/Smart_File_Suite.json.  This wrapper keeps older calls working without
    overwriting the central schema used by settings.py.
    """
    global _AUTOSAVE_FINGERPRINT
    package = str(__package__ or '').strip()
    existing = sys.modules.get(f'{package}.settings') if package else None
    if existing is not None and bool(
        getattr(existing, '_STARTUP_RESTORE_PENDING', False)
        or getattr(existing, '_APPLYING', False)
    ):
        return False
    if not _npanel_state_save_enabled(context):
        return False
    try:
        from . import settings as _sf_persist
        if not force and hasattr(_sf_persist, 'schedule_save'):
            return bool(_sf_persist.schedule_save(
                context or getattr(bpy, 'context', None)
            ))
        save_now = getattr(_sf_persist, 'save_now', None)
        if not callable(save_now):
            return False
        result = bool(save_now(
            context or getattr(bpy, 'context', None),
            force=bool(force),
            allow_disabled=bool(allow_disabled),
        ))
        if result:
            try:
                _AUTOSAVE_FINGERPRINT = json.dumps(
                    collect_persistent_settings(context),
                    ensure_ascii=False,
                    sort_keys=True,
                    indent=2,
                )
            except Exception:
                pass
        return result
    except Exception:
        return False



def _autosave_timer():
    # Retained for legacy imports only. Settings persistence is event-driven and
    # this callback is never registered as a periodic timer.
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def _unregister_standalone_always_on_panel():
    # Legacy unowned classes are never removed by name.  A prior Smart File
    # generation must remove only records from its own exact owner ledger.
    return None


def register():
    if not _common_install_owner():
        return False
    # Registration and validation use the same path in foreground and
    # background Blender.  UI-only helpers are written to tolerate absent
    # windows, so no bpy.app.background branch is needed here.
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        for cls in (
            SMART_FILE_OT_system_always_on_toggle,
            SMART_FILE_OT_system_save_preferences,
            SMART_FILE_PT_system_file_suite_always_on_toggle,
        ):
            _register_class_wrapper(cls)
            if cls not in _REGISTERED_CLASSES:
                _REGISTERED_CLASSES.append(cls)
        # settings.py is the sole persistent settings lifecycle owner.  This
        # legacy module owns no handlers, timers, msgbus subscriptions, or draw
        # callback mutations.
        _load_previews()
        _patch_panel_headers()
        _patch_addon_preferences()
        return all(_class_owned_rna(cls) for cls in _REGISTERED_CLASSES)
    except Exception:
        _common_cleanup_generation()
        return False


def unregister():
    ok = _common_cleanup_generation()
    namespace = _common_namespace()
    if namespace is not None:
        owner = namespace.get(_COMMON_OWNER_KEY)
        if isinstance(owner, dict) and owner.get('token') is _COMMON_OWNER_TOKEN:
            namespace.pop(_COMMON_OWNER_KEY, None)
    _remove_previews()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    return ok
