# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

# Standard Smart File N-panel compatibility shim.
# This file keeps only runtime refresh and active-owner state used by the integrated tool UI.

_REGISTRY = {
    'active_owner': 'smart_file_suite',
    'preferred_owner': 'smart_file_suite',
    'shutdown': False,
    'runtime_teardown': False,
}


def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip() or 'smart_file_suite'


def _tag_redraw_all_view3d_areas() -> None:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


def is_active(context=None, addon_key: str = '') -> bool:
    del context, addon_key
    return True


def set_active_owner(context=None, addon_key: str | None = None) -> None:
    del context
    owner = _normalize_owner(addon_key)
    _REGISTRY['active_owner'] = owner
    _REGISTRY['preferred_owner'] = owner
    _tag_redraw_all_view3d_areas()


def clear_active_owner(addon_key: str = '') -> None:
    del addon_key
    _REGISTRY['active_owner'] = 'smart_file_suite'
    _REGISTRY['preferred_owner'] = 'smart_file_suite'
    _tag_redraw_all_view3d_areas()


def toggle_active(context=None, addon_key: str = '') -> None:
    set_active_owner(context, addon_key or 'smart_file_suite')


def force_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    if preferred_owner:
        set_active_owner(None, preferred_owner)
    else:
        _tag_redraw_all_view3d_areas()
    return True


def refresh_ui_runtime(context=None, addon_key: str | None = None, activate_if_properties: bool = False, **_kwargs) -> bool:
    del activate_if_properties
    if addon_key:
        set_active_owner(context, addon_key)
    else:
        _tag_redraw_all_view3d_areas()
    return True


def sync_live_runtime_from_prefs(context=None) -> bool:
    del context
    _tag_redraw_all_view3d_areas()
    return True


def begin_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = True


def finish_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = False


def shutdown_runtime() -> None:
    _REGISTRY['shutdown'] = True


def is_shutting_down() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def runtime_is_shutdown() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def _set_runtime_teardown(value: bool = True) -> None:
    _REGISTRY['runtime_teardown'] = bool(value)
    _REGISTRY['shutdown'] = bool(value)


def runtime_is_tearing_down() -> bool:
    return bool(_REGISTRY.get('runtime_teardown'))


def ensure_shared_nav_button_operators() -> bool:
    return True


def register(*_args, **_kwargs) -> bool:
    _tag_redraw_all_view3d_areas()
    return True


def unregister(*_args, **_kwargs) -> bool:
    _REGISTRY['shutdown'] = False
    _REGISTRY['runtime_teardown'] = False
    _tag_redraw_all_view3d_areas()
    return True
