# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

# Retired compatibility preferences module.
# Smart File settings are drawn and managed from the standard Smart File N-panel.


def register() -> None:
    return None


def unregister() -> None:
    return None
