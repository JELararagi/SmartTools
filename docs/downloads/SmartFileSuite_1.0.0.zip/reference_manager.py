# -----------------------------------------------------------------------------

#  Reference Manager (Phase 2+)

# -----------------------------------------------------------------------------



from .ui_language_runtime import ui_text as _ui_text

import datetime

import json

import os

import re

import time

import uuid as _sf_rm_uuid

import sys as _sf_rm_sys



import bpy

from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty

from bpy_extras.io_utils import ExportHelper, ImportHelper

from .ui_language_runtime import error_text as _sf_error_text



# Fixed, read-only Smart Tools Manager module lookup.  Panel poll never imports,

# scans, reads files, starts timers, or mutates runtime state.

_SF_MANAGER_PARENT_PACKAGE = str(__package__ or "").strip().rpartition(".")[0]

_SF_MANAGER_MODULE_NAMES = tuple(dict.fromkeys(tuple(

    name for name in (

        f"{_SF_MANAGER_PARENT_PACKAGE}.smart_tools_manager.manager" if _SF_MANAGER_PARENT_PACKAGE else "",

        f"{_SF_MANAGER_PARENT_PACKAGE}.smart_tools_manager" if _SF_MANAGER_PARENT_PACKAGE else "",

        "bl_ext.user_default.smart_tools_manager.manager",

        "bl_ext.user_default.smart_tools_manager",

        "smart_tools_manager.manager",

        "smart_tools_manager",

    ) if name

)))

_SF_MANAGER_RUNTIME_NAMESPACE_KEY = 'JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1'

_SF_MANAGER_RULE_CACHE = {

    'generation': '',

    'revision': -1,

    'active': False,

    'decisions': {},

}

_SF_MANAGER_WORKSPACE_ALIASES = {

    'LAYOUT': ('Layout', 'レイアウト'),

    'MODELING': ('Modeling', 'モデリング'),

    'SCULPTING': ('Sculpting', 'スカルプティング'),

    'UV_EDITING': ('UV Editing', 'UVエディティング', 'UV編集'),

    'TEXTURE_PAINT': ('Texture Paint', 'テクスチャペイント'),

    'SHADING': ('Shading', 'シェーディング'),

    'ANIMATION': ('Animation', 'アニメーション'),

    'RENDERING': ('Rendering', 'レンダリング'),

    'COMPOSITING': ('Compositing', 'コンポジティング'),

    'GEOMETRY_NODES': ('Geometry Nodes', 'Geometry Node', 'ジオメトリノード'),

    'SCRIPTING': ('Scripting', 'スクリプティング'),

    'ANIMATION_2D': ('2D Animation', '2Dアニメーション'),

    'FULL_CANVAS_2D': ('2D Full Canvas', '2Dフルキャンバス'),

    'MASKING': ('Masking', 'マスキング'),

    'MOTION_TRACKING': ('Motion Tracking', 'モーショントラッキング'),

    'VIDEO_EDITING': ('Video Editing', 'ビデオ編集'),

}





def _sf_manager_normalize_name(value) -> str:

    try:

        return ''.join(ch for ch in str(value or '').casefold() if ch.isalnum())

    except Exception:

        return ''





_SF_MANAGER_WORKSPACE_BY_NAME = {

    _sf_manager_normalize_name(alias): workspace_key

    for workspace_key, aliases in _SF_MANAGER_WORKSPACE_ALIASES.items()

    for alias in (workspace_key, *aliases)

    if _sf_manager_normalize_name(alias)

}



_RM_AUTO_SCHEDULED = False

_RM_TIMER_ACTIVE = False

_RM_LAST_AUTO_RESULT = {"updated": [], "missing": []}

_RM_OWNER_KEY = "JELararagi.smart_file.reference_manager.lifecycle.v57540"

_RM_LEGACY_OWNER_KEYS = (

    "JELararagi.smart_file.reference_manager.lifecycle.v57539",

    "JELararagi.smart_file.reference_manager.lifecycle.v57536",

    "JELararagi.smart_file.reference_manager.lifecycle.v57535",

    "JELararagi.smart_file.reference_manager.lifecycle.v57534",

    "JELararagi.smart_file.reference_manager.lifecycle.v57533",

)

_RM_OWNER_TOKEN = object()

_RM_OWNER_GENERATION = _sf_rm_uuid.uuid4().hex

_RM_HANDLER_RECORD = None

_RM_TIMER_RECORD = None

_RM_LAST_RUNTIME_ERROR = ""





def _rm_cache_get(prefs) -> dict:

    try:

        return json.loads(getattr(prefs, "ref_mtime_cache", "") or "{}") or {}

    except Exception:

        return {}





def _rm_cache_set(prefs, cache: dict) -> None:

    try:

        prefs.ref_mtime_cache = json.dumps(cache, ensure_ascii=False)

    except Exception:

        pass





def _rm_file_mtime_int(fp: str) -> int:

    fp = _norm_path(fp)

    try:

        return int(os.path.getmtime(fp))

    except Exception:

        return -1





def _rm_library_stats_for_fp(fp: str) -> dict:

    fp = _norm_path(fp)

    stats = {

        "OBJECTS": 0,

        "COLLECTIONS": 0,

        "MATERIALS": 0,

        "IMAGES": 0,

        "NODE_GROUPS": 0,

        "ACTIONS": 0,

        "WORLDS": 0,

    }

    try:

        for obj in bpy.data.objects:

            if getattr(getattr(obj, "library", None), "filepath", "") and _norm_path(obj.library.filepath) == fp:

                stats["OBJECTS"] += 1

        for c in bpy.data.collections:

            if getattr(getattr(c, "library", None), "filepath", "") and _norm_path(c.library.filepath) == fp:

                stats["COLLECTIONS"] += 1

        for m in bpy.data.materials:

            if getattr(getattr(m, "library", None), "filepath", "") and _norm_path(m.library.filepath) == fp:

                stats["MATERIALS"] += 1

        for img in bpy.data.images:

            if getattr(getattr(img, "library", None), "filepath", "") and _norm_path(img.library.filepath) == fp:

                stats["IMAGES"] += 1

        for ng in bpy.data.node_groups:

            if getattr(getattr(ng, "library", None), "filepath", "") and _norm_path(ng.library.filepath) == fp:

                stats["NODE_GROUPS"] += 1

        for ac in bpy.data.actions:

            if getattr(getattr(ac, "library", None), "filepath", "") and _norm_path(ac.library.filepath) == fp:

                stats["ACTIONS"] += 1

        for w in bpy.data.worlds:

            if getattr(getattr(w, "library", None), "filepath", "") and _norm_path(w.library.filepath) == fp:

                stats["WORLDS"] += 1

    except Exception:

        pass

    stats["TOTAL"] = sum(stats.values())

    return stats





_version_re = re.compile(r"^(?P<base>.*?)(?:[_\-\s]?v)(?P<ver>\d{1,4})$", re.IGNORECASE)





def _rm_parse_version(filepath: str):

    stem = os.path.splitext(os.path.basename(filepath))[0]

    m = _version_re.match(stem)

    if not m:

        return stem, None

    base = (m.group("base") or "").rstrip('_-')

    try:

        ver = int(m.group("ver"))

    except Exception:

        ver = None

    return base or stem, ver





def _rm_find_latest_in_dir(dirpath: str, base: str) -> tuple[str, int] | tuple[None, None]:

    try:

        best_fp = None

        best_ver = None

        for fn in os.listdir(dirpath):

            if not fn.lower().endswith(".blend"):

                continue

            fp = os.path.join(dirpath, fn)

            b, v = _rm_parse_version(fp)

            if b != base or v is None:

                continue

            if best_ver is None or v > best_ver:

                best_ver = v

                best_fp = fp

        return best_fp, best_ver

    except Exception:

        _RM_TIMER_ACTIVE = False

        return None, None





def _rm_find_latest_using_roots(context, base: str) -> tuple[str, int] | tuple[None, None]:

    # Use Asset Reader index if available; fallback to scanning roots shallowly.

    idx = _load_index()

    files = idx.get("files", {}) if isinstance(idx, dict) else {}

    best_fp = None

    best_ver = None

    try:

        for fp in files.keys():

            b, v = _rm_parse_version(fp)

            if b != base or v is None:

                continue

            if best_ver is None or v > best_ver:

                best_ver = v

                best_fp = fp

    except Exception:

        pass

    return best_fp, best_ver







def _rm_find_latest_from_catalog(context, lib_fp: str) -> tuple[str, int] | tuple[None, None]:

    """If lib_fp exists in any catalog entries, return that asset's latest path."""

    try:

        lib_fp_n = _norm_path(lib_fp)

        merged = _ar_get_merged_catalog(context, force=False)

        # If this library has an asset_id tag, prefer catalog latest by ID (robust against renames/moves).

        try:

            aid = _sf_get_library_asset_id(lib_fp_n)

        except Exception:

            aid = ""

        if aid:

            try:

                by_id = merged.get('latest_by_asset_id', {}) or {}

                ent, lver = by_id.get(aid, (None, 0))

                try:

                    lver = int(lver or 0)

                except Exception:

                    lver = 0

                if ent:

                    lp = _norm_path(ent.get('blend_abs', '') or '')

                    # treat as newer if different path, or if parsed version is lower

                    base, ver = _rm_parse_version(lib_fp_n)

                    if (lp and lp != lib_fp_n) or (ver is not None and lver and lver > (ver or 0)):

                        return lp, lver

            except Exception:

                pass

        mapping = merged.get('path_to_latest', {}) if isinstance(merged, dict) else {}

        info = mapping.get(lib_fp_n)

        if info and info.get('latest_path'):

            latest_path = _norm_path(info.get('latest_path') or '')

            latest_ver = int(info.get('latest_ver', 0) or 0)

            cur_ver = int(info.get('current_ver', 0) or 0)

            # treat as newer if version increased or file differs

            if (latest_ver and latest_ver > cur_ver) or (latest_path and latest_path != lib_fp_n):

                return latest_path, latest_ver

        # fallback: match by parsed base name if possible

        base, ver = _rm_parse_version(lib_fp_n)

        latest_by = merged.get('latest_by_asset', {}) if isinstance(merged, dict) else {}

        if base in latest_by:

            ent, lver = latest_by.get(base, (None, 0))

            try:

                lver = int(lver or 0)

            except Exception:

                lver = 0

            if ent:

                lp = _norm_path(ent.get('blend_abs', '') or '')

                if lp and (ver is None or lver > (ver or 0)) and lp != lib_fp_n:

                    return lp, lver

    except Exception:

        pass

    return None, None



def _rm_find_latest_for_library(context, lib_fp: str) -> tuple[str, int] | tuple[None, None]:

    prefs = _addon_prefs(context)

    if not prefs:

        return None, None

    lib_fp_n = _norm_path(lib_fp)

    base, ver = _rm_parse_version(lib_fp_n)



    strat = getattr(prefs, 'rm_candidate_priority', 'CATALOG_FIRST')



    def _is_newer(candidate_fp: str, candidate_ver: int | None) -> bool:

        cf = _norm_path(candidate_fp)

        if not cf or cf == lib_fp_n:

            return False

        if ver is None:

            return True

        try:

            cv = int(candidate_ver or 0)

        except Exception:

            cv = 0

        return cv > int(ver or 0)



    # Highest-version strategy: consider all candidates across sources (optionally filtering ROOTS)

    if strat == 'HIGHEST_VERSION':

        class _Dummy:

            pass

        d = _Dummy()

        d.filepath = lib_fp_n

        try:

            d.asset_id = _sf_get_library_asset_id(lib_fp_n) or ''

        except Exception:

            d.asset_id = ''

        cands = _rm_collect_relink_candidates(context, d)

        if getattr(prefs, 'rm_version_search_scope', 'ROOTS') != 'ROOTS':

            cands = [c for c in cands if c.get('source') != 'ROOTS']

        for c in cands:

            fp = _norm_path(c.get('filepath', '') or '')

            if not fp or not os.path.exists(fp):

                continue

            cv = int(c.get('version', 0) or 0)

            if _is_newer(fp, cv):

                return fp, cv

        return None, None



    # Order-based strategies

    def _try_catalog():

        cat_fp, cat_ver = _rm_find_latest_from_catalog(context, lib_fp_n)

        if cat_fp and _is_newer(cat_fp, cat_ver):

            return _norm_path(cat_fp), int(cat_ver or 0)

        return None, None



    def _try_dir():

        dirpath = os.path.dirname(lib_fp_n)

        cand_fp, cand_ver = _rm_find_latest_in_dir(dirpath, base)

        if cand_fp and cand_ver is not None and _is_newer(cand_fp, cand_ver):

            return _norm_path(cand_fp), int(cand_ver or 0)

        return None, None



    def _try_roots():

        if getattr(prefs, "rm_version_search_scope", "ROOTS") != 'ROOTS':

            return None, None

        cand_fp, cand_ver = _rm_find_latest_using_roots(context, base)

        if cand_fp and cand_ver is not None and _is_newer(cand_fp, cand_ver):

            return _norm_path(cand_fp), int(cand_ver or 0)

        return None, None



    if strat == 'DIR_FIRST':

        fp, vv = _try_dir()

        if fp:

            return fp, vv

        fp, vv = _try_catalog()

        if fp:

            return fp, vv

        return _try_roots()



    # Default: catalog first, then same folder, then roots

    fp, vv = _try_catalog()

    if fp:

        return fp, vv

    fp, vv = _try_dir()

    if fp:

        return fp, vv

    return _try_roots()





def _rm_collect_catalog_candidates_for_item(context, it) -> list[dict]:

    """Return candidate library filepaths for a RM item from merged catalogs."""

    cands = []

    try:

        merged = _ar_get_merged_catalog(context, force=False)

        assets = merged.get('assets', {}) or {}

        # group key is asset_id if available; else fall back to base name

        gk = (getattr(it, 'asset_id', '') or '').strip()

        if not gk:

            base, _ver = _rm_parse_version(getattr(it, 'filepath', '') or '')

            gk = base

        entries = assets.get(gk, []) or []

        for e in entries:

            fp = _norm_path(e.get('blend_abs', '') or '')

            if not fp:

                continue

            cands.append({

                'filepath': fp,

                'version': int(e.get('version', 0) or 0),

                'catalog_path': _norm_path(e.get('catalog_path', '') or ''),

                'root_rank': int(e.get('root_rank', 10**9) or 10**9),

                'published_at': e.get('published_at', '') or '',

                'source': 'CATALOG',

                'asset_id': (e.get('asset_id','') or '').strip(),

            })

    except Exception:

        cands = []

    return cands





def _rm_collect_version_candidates_for_item(context, it) -> list[dict]:

    """Collect candidates from same dir and roots by filename version pattern."""

    out = []

    fp = _norm_path(getattr(it, 'filepath', '') or '')

    if not fp:

        return out

    base, _ver = _rm_parse_version(fp)

    # same dir scan

    d = os.path.dirname(fp)

    try:

        for fn in os.listdir(d):

            if not fn.lower().endswith('.blend'):

                continue

            cand = _norm_path(os.path.join(d, fn))

            b, v = _rm_parse_version(cand)

            if b == base and v is not None:

                out.append({'filepath': cand, 'version': int(v or 0), 'source': 'SAME_DIR'})

    except Exception:

        pass

    # roots via index

    try:

        cand_fp, cand_ver = _rm_find_latest_using_roots(context, base)

        if cand_fp and cand_ver is not None:

            out.append({'filepath': _norm_path(cand_fp), 'version': int(cand_ver or 0), 'source': 'ROOTS'})

    except Exception:

        pass

    return out





def _rm_collect_relink_candidates(context, it) -> list[dict]:

    'Build a ranked unique candidate list for relinking.\n\n    This uses a weighted score (adjustable in Preferences) and optional Asset ID safety filters.'

    cur_fp = _norm_path(getattr(it, 'filepath', '') or '')

    cur_base, cur_ver = _rm_parse_version(cur_fp) if cur_fp else ('', None)

    seen = set([cur_fp]) if cur_fp else set()

    allc: list[dict] = []



    # catalog candidates (full list)

    for c in _rm_collect_catalog_candidates_for_item(context, it):

        fp = _norm_path(c.get('filepath', '') or '')

        if not fp or fp in seen:

            continue

        seen.add(fp)

        c['exists'] = bool(os.path.exists(fp))

        # ensure fields

        c.setdefault('asset_id', '')

        c.setdefault('root_rank', 10**9)

        allc.append(c)



    # version candidates (same dir + roots)

    for c in _rm_collect_version_candidates_for_item(context, it):

        fp = _norm_path(c.get('filepath', '') or '')

        if not fp or fp in seen:

            continue

        seen.add(fp)

        c['exists'] = bool(os.path.exists(fp))

        c.setdefault('asset_id', '')

        c.setdefault('root_rank', 10**9)

        allc.append(c)



    prefs = _addon_prefs(context)

    strat = getattr(prefs, 'rm_candidate_priority', 'CATALOG_FIRST') if prefs else 'CATALOG_FIRST'

    match_mode = getattr(prefs, 'rm_asset_id_match_mode', 'EXCLUDE_MISMATCH') if prefs else 'EXCLUDE_MISMATCH'

    no_id_mode = getattr(prefs, 'rm_no_id_mode', 'EMERGENCY_ONLY') if prefs else 'EMERGENCY_ONLY'



    w_exists = int(getattr(prefs, 'rm_score_w_exists', 1000) or 0) if prefs else 1000

    w_id = int(getattr(prefs, 'rm_score_w_asset_id', 500) or 0) if prefs else 500

    w_src = int(getattr(prefs, 'rm_score_w_source', 100) or 0) if prefs else 100

    w_ver = int(getattr(prefs, 'rm_score_w_version', 1) or 0) if prefs else 1

    w_root = int(getattr(prefs, 'rm_score_w_root', 5) or 0) if prefs else 5



    # current asset_id (prefer explicit field; fall back to reading)

    cur_aid = (getattr(it, 'asset_id', '') or '').strip()

    if not cur_aid and cur_fp and os.path.exists(cur_fp):

        try:

            cur_aid = (_sf_get_library_asset_id(cur_fp) or '').strip()

        except Exception:

            cur_aid = ''



    aid_cache: dict[str, str] = {}



    def _get_aid(fp: str) -> str:

        fp = _norm_path(fp)

        if not fp:

            return ''

        if fp in aid_cache:

            return aid_cache[fp]

        aid = ''

        try:

            if os.path.exists(fp):

                aid = (_sf_get_library_asset_id(fp) or '').strip()

        except Exception:

            aid = ''

        aid_cache[fp] = aid

        return aid



    def _src_bonus(src: str) -> int:

        src = src or ''

        if strat == 'DIR_FIRST':

            return {'SAME_DIR': 3, 'CATALOG': 2, 'ROOTS': 1}.get(src, 0)

        # default: catalog first

        return {'CATALOG': 3, 'SAME_DIR': 2, 'ROOTS': 1}.get(src, 0)



    filtered: list[dict] = []

    for c in allc:

        fp = _norm_path(c.get('filepath', '') or '')

        cand_aid = (c.get('asset_id', '') or '').strip()

        # Only read candidate asset_id if we may need it (filters or scoring)

        if (match_mode != 'OFF' or no_id_mode != 'ALLOW' or w_id) and not cand_aid:

            cand_aid = _get_aid(fp)

            c['asset_id'] = cand_aid



        # Asset ID filter

        if cur_aid:

            if match_mode == 'REQUIRE_MATCH':

                if cand_aid != cur_aid:

                    continue

            elif match_mode == 'EXCLUDE_MISMATCH':

                if cand_aid and cand_aid != cur_aid:

                    continue



            # No-ID candidate handling

            if not cand_aid:

                if no_id_mode == 'DISALLOW':

                    continue

                # EMERGENCY_ONLY is applied after collecting all candidates (need to know if we have ID'd candidates)



        filtered.append(c)



    if cur_aid and no_id_mode == 'EMERGENCY_ONLY':

        with_id = [c for c in filtered if (c.get('asset_id', '') or '').strip()]

        if with_id:

            filtered = with_id



    def _score_and_annotate(c: dict) -> float:

        fp = _norm_path(c.get('filepath', '') or '')

        exists = 1 if c.get('exists') else 0

        v = int(c.get('version', 0) or 0)

        src = c.get('source', '') or ''

        sb = _src_bonus(src)



        rr = int(c.get('root_rank', 10**9) or 10**9)

        rr_comp = 0

        if src == 'CATALOG':

            # smaller root_rank => higher score, clamp to [0..1000]

            rr_comp = max(0, min(1000, 1000 - rr))



        cand_aid = (c.get('asset_id', '') or '').strip()

        id_bonus = 0

        id_state = 'NA'

        if cur_aid:

            if cand_aid:

                if cand_aid == cur_aid:

                    id_bonus = 1

                    id_state = 'MATCH'

                else:

                    id_bonus = -1

                    id_state = 'MISMATCH'

            else:

                id_bonus = 0

                id_state = 'NO_ID'

        c['id_state'] = id_state



        score = (w_exists * exists) + (w_id * id_bonus) + (w_src * sb) + (w_ver * v) + (w_root * rr_comp)

        c['score'] = float(score)

        c['score_detail'] = f"exists={exists}*{w_exists} + id={id_bonus}*{w_id} + src={sb}*{w_src} + ver={v}*{w_ver} + root={rr_comp}*{w_root}"

        # annotate base/version

        b, vv = _rm_parse_version(fp)

        if c.get('version', 0) == 0 and vv is not None:

            c['version'] = int(vv)

            v = int(vv)

            # adjust score for version if needed

            c['score'] = float((w_exists * exists) + (w_id * id_bonus) + (w_src * sb) + (w_ver * v) + (w_root * rr_comp))

        c['base'] = b

        return float(c['score'])



    for c in filtered:

        _score_and_annotate(c)



    # sort by score descending, then exists, then version

    filtered.sort(key=lambda c: (float(c.get('score', 0.0) or 0.0), int(c.get('exists', False)), int(c.get('version', 0) or 0)), reverse=True)

    return filtered







def _rm_find_best_resolve_candidate(context, it) -> tuple[str, int] | tuple[None, None]:

    """Find best candidate for missing library resolution."""

    cands = _rm_collect_relink_candidates(context, it)

    for c in cands:

        fp = _norm_path(c.get('filepath', '') or '')

        if fp and os.path.exists(fp):

            return fp, int(c.get('version', 0) or 0)

    return None, None





def _rm_build_update_plan(context) -> int:

    """Populate WindowManager.sf_rm_plan_items with suggested actions."""

    wm = context.window_manager

    if not hasattr(wm, 'sf_rm_plan_items'):

        return 0

    wm.sf_rm_plan_items.clear()

    wm.sf_rm_plan_active_index = 0



    # Ensure list is current

    _rm_refresh_list(context)

    _rm_check_updates(context, silent=True)



    for it in wm.sf_rm_items:

        p = wm.sf_rm_plan_items.add()

        p.is_selected = False

        p.name = it.name

        p.filepath = _norm_path(it.filepath)

        p.asset_id = getattr(it, 'asset_id', '') or ''

        _base, _ver = _rm_parse_version(p.filepath)

        p.current_ver = int(_ver or 0)

        p.proposed_path = ''

        p.proposed_ver = 0

        p.reason = ''



        # Determine suggested action

        if it.status == 'MISSING':

            cand_fp, cand_ver = _rm_find_best_resolve_candidate(context, it)

            if cand_fp:

                p.action = 'RESOLVE'

                p.is_selected = True

                p.proposed_path = _norm_path(cand_fp)

                p.proposed_ver = int(cand_ver or 0)

                p.reason = _t('Missing')

            else:

                p.action = 'NONE'

                p.reason = _t('Missing') + '(' + _t('No candidates found') + ')'

        elif it.has_newer and it.latest_path:

            p.action = 'SWITCH'

            p.is_selected = True

            p.proposed_path = _norm_path(it.latest_path)

            p.proposed_ver = int(it.latest_ver or 0)

            p.reason = _t('Newer version found')

            if it.status == 'UPDATED':

                p.reason = _t('Newer version found') + '+' + _t('Updated')

        elif it.status == 'UPDATED':

            p.action = 'RELOAD'

            p.is_selected = True

            p.reason = _t('Updated')

        else:

            p.action = 'NONE'



    return len(wm.sf_rm_plan_items)





def _rm_build_relink_plan(context, only_active: bool = True, apply_all: bool = False) -> int:

    "Populate plan list with automatic relink/resolve suggestions.\n\n    Intended to replace manual 'Relink Selected...' with a confirm-only flow."

    wm = context.window_manager

    if not hasattr(wm, 'sf_rm_plan_items'):

        return 0

    wm.sf_rm_plan_items.clear()

    wm.sf_rm_plan_active_index = 0



    _rm_refresh_list(context)



    targets = []

    if apply_all:

        targets = list(wm.sf_rm_items)

    elif only_active and wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items):

        targets = [wm.sf_rm_items[wm.sf_rm_active_index]]

    else:

        targets = [it for it in wm.sf_rm_items if it.is_selected] or []



    for it in targets:

        p = wm.sf_rm_plan_items.add()

        p.is_selected = False

        p.name = it.name

        p.filepath = _norm_path(it.filepath)

        p.asset_id = getattr(it, 'asset_id', '') or ''

        _base, _ver = _rm_parse_version(p.filepath)

        p.current_ver = int(_ver or 0)

        p.proposed_path = ''

        p.proposed_ver = 0

        p.reason = ''



        # collect candidates and pick best existing

        cands = _rm_collect_relink_candidates(context, it)

        # honor version search scope (optionally avoid ROOTS suggestions)

        prefs = _addon_prefs(context)

        if prefs and getattr(prefs, 'rm_version_search_scope', 'ROOTS') != 'ROOTS':

            cands = [c for c in cands if c.get('source') != 'ROOTS']



        best = None

        for c in cands:

            fp = _norm_path(c.get('filepath', '') or '')

            if not fp or not os.path.exists(fp):

                continue

            if fp == _norm_path(it.filepath):

                continue

            best = c

            break



        if it.status == 'MISSING':

            if best:

                p.action = 'RESOLVE'

                p.is_selected = True

                p.proposed_path = _norm_path(best.get('filepath', '') or '')

                p.proposed_ver = int(best.get('version', 0) or 0)

                p.reason = _t('Missing') + f" [{best.get('source','')}]"

            else:

                p.action = 'NONE'

                p.reason = _t('Missing') + '(' + _t('No candidates found') + ')'

        else:

            if best:

                p.action = 'RELINK'

                p.is_selected = True

                p.proposed_path = _norm_path(best.get('filepath', '') or '')

                p.proposed_ver = int(best.get('version', 0) or 0)

                p.reason = f"AUTO [{best.get('source','')}]"

            else:

                p.action = 'NONE'

                p.reason = _t('No candidates found')



    return len(wm.sf_rm_plan_items)





def _rm_refresh_list(context):

    wm = context.window_manager

    wm.sf_rm_items.clear()



    libs = list(getattr(bpy.data, "libraries", []) or [])

    if not libs:

        return 0



    prefs = _addon_prefs(context)

    cache = _rm_cache_get(prefs) if prefs else {}



    for lib in libs:

        fp = _norm_path(getattr(lib, "filepath", "") or "")

        it = wm.sf_rm_items.add()

        it.is_selected = False

        it.filepath = fp

        it.name = os.path.basename(fp) if fp else "(unknown)"

        it.cached_mtime = int(cache.get(fp, -1)) if fp else -1



        mtime = _rm_file_mtime_int(fp) if fp else -1

        it.mtime = int(mtime)



        # status

        if not fp or mtime < 0 or (fp and not os.path.exists(fp)):

            it.status = "MISSING"

        elif it.cached_mtime > 0 and mtime > it.cached_mtime:

            it.status = "UPDATED"

        else:

            it.status = "OK"



        # stats

        st = _rm_library_stats_for_fp(fp) if fp else {"TOTAL": 0}

        it.total_ids = int(st.get("TOTAL", 0))

        it.count_objects = int(st.get("OBJECTS", 0))

        it.count_collections = int(st.get("COLLECTIONS", 0))

        it.count_materials = int(st.get("MATERIALS", 0))

        it.count_images = int(st.get("IMAGES", 0))

        it.count_node_groups = int(st.get("NODE_GROUPS", 0))

        it.count_actions = int(st.get("ACTIONS", 0))

        it.count_worlds = int(st.get("WORLDS", 0))



        # asset_id tag (used for ID-based relink)

        aid = ""

        try:

            aid = str(lib.get("sf_asset_id", "") or "")

        except Exception:

            aid = ""

        if not aid:

            # best-effort: infer from catalog by current path and store it on the Library datablock

            try:

                merged = _ar_get_merged_catalog(context, force=False)

                info = (merged.get("path_to_latest", {}) or {}).get(_norm_path(fp))

                if info and info.get("asset_id"):

                    aid = str(info.get("asset_id") or "")

                    try:

                        lib["sf_asset_id"] = aid

                    except Exception:

                        pass

            except Exception:

                pass

        it.asset_id = aid

        # latest version

        latest_fp, latest_ver = _rm_find_latest_for_library(context, fp) if fp else (None, None)

        if latest_fp:

            it.has_newer = True

            it.latest_path = _norm_path(latest_fp)

            it.latest_ver = int(latest_ver or 0)

        else:

            it.has_newer = False

            it.latest_path = ""

            it.latest_ver = 0



    return len(wm.sf_rm_items)





def _rm_check_updates(context, silent: bool = False):

    prefs = _addon_prefs(context)

    if not prefs:

        return [], []

    cache = _rm_cache_get(prefs)

    updated = []

    missing = []



    wm = context.window_manager

    for it in wm.sf_rm_items:

        fp = _norm_path(getattr(it, "filepath", "") or "")

        mtime = _rm_file_mtime_int(fp) if fp else -1

        it.mtime = int(mtime)



        if not fp or mtime < 0 or not os.path.exists(fp):

            it.status = "MISSING"

            missing.append(fp or "(unknown)")

            continue



        prev = int(cache.get(fp, -1))

        it.cached_mtime = prev

        if prev > 0 and mtime > prev:

            it.status = "UPDATED"

            updated.append(fp)

        else:

            it.status = "OK"



    _RM_LAST_AUTO_RESULT["updated"] = updated

    _RM_LAST_AUTO_RESULT["missing"] = missing



    if (not silent) and (updated or missing):

        msg = []

        if updated:

            msg.append(f"{_tr('Updated')}: {len(updated)}")

        if missing:

            msg.append(f"{_tr('Missing')}: {len(missing)}")

        try:

            _sf_call_menu_direct("SF_MT_reference_manager_reference_manager_notice", context=context)

        except Exception:

            pass

    return updated, missing





def _rm_mark_seen(context):

    prefs = _addon_prefs(context)

    if not prefs:

        return 0

    cache = _rm_cache_get(prefs)

    wm = context.window_manager

    cnt = 0

    for it in wm.sf_rm_items:

        fp = _norm_path(getattr(it, "filepath", "") or "")

        mtime = _rm_file_mtime_int(fp) if fp else -1

        if fp and mtime > 0:

            cache[fp] = int(mtime)

            it.cached_mtime = int(mtime)

            it.status = "OK"

            cnt += 1

    _rm_cache_set(prefs, cache)

    return cnt





def _rm_reload_library_by_fp(fp: str):

    fp = _norm_path(fp)

    lib = next((l for l in bpy.data.libraries if _norm_path(getattr(l, "filepath", "")) == fp), None)

    if not lib:

        return False

    try:

        if hasattr(lib, "reload"):

            lib.reload()

            return True

    except Exception:

        pass

    # fallback operator

    try:

        bpy.ops.wm.lib_reload(library=lib.name)

        return True

    except Exception:

        return False





def _rm_relink_library(old_fp: str, new_fp: str) -> bool:

    old_fp_n = _norm_path(old_fp)

    new_fp_n = _norm_path(new_fp)

    if not old_fp_n or not new_fp_n:

        return False

    lib = next((l for l in bpy.data.libraries if _norm_path(getattr(l, "filepath", "")) == old_fp_n), None)

    if not lib:

        return False

    try:

        lib.filepath = new_fp_n

        return True

    except Exception:

        return False





_SF_RM_UPGRADE_PLAN_TEXT = '.SFS_LibraryUpgrade__last_plan'





def _sf_rm_upgrade_plan_find_text():

    try:

        return bpy.data.texts.get(_SF_RM_UPGRADE_PLAN_TEXT)

    except Exception:

        return None





def _sf_rm_upgrade_plan_read_payload() -> dict:

    text_block = _sf_rm_upgrade_plan_find_text()

    if text_block is None:

        return {}

    try:

        raw = text_block.as_string()

    except Exception:

        raw = ''

    try:

        payload = json.loads(raw or '{}')

        return payload if isinstance(payload, dict) else {}

    except Exception:

        return {}





def _sf_rm_upgrade_plan_write_payload(payload: dict) -> str:

    text_block = _sf_rm_upgrade_plan_find_text()

    if text_block is None:

        text_block = bpy.data.texts.new(name=_SF_RM_UPGRADE_PLAN_TEXT)

    raw = json.dumps(dict(payload or {}), ensure_ascii=False, indent=2)

    try:

        text_block.clear()

    except Exception:

        pass

    text_block.write(raw)

    try:

        text_block.use_fake_user = True

    except Exception:

        pass

    try:

        text_block.use_module = False

    except Exception:

        pass

    return str(getattr(text_block, 'name', '') or _SF_RM_UPGRADE_PLAN_TEXT)





def _sf_rm_resolved_targets(context, *, only_active: bool = False, apply_all: bool = False) -> list:

    wm = context.window_manager

    if apply_all:

        return list(getattr(wm, 'sf_rm_items', []) or [])

    if only_active and getattr(wm, 'sf_rm_items', None) and 0 <= int(getattr(wm, 'sf_rm_active_index', -1)) < len(wm.sf_rm_items):

        return [wm.sf_rm_items[wm.sf_rm_active_index]]

    return [it for it in getattr(wm, 'sf_rm_items', []) or [] if bool(getattr(it, 'is_selected', False))]





def _sf_rm_upgrade_plan_entries_for_targets(targets: list) -> tuple[list[dict], list[dict]]:

    entries = []

    skipped = []

    for it in list(targets or []):

        current_path = _norm_path(str(getattr(it, 'filepath', '') or ''))

        latest_path = _norm_path(str(getattr(it, 'latest_path', '') or ''))

        if not current_path or not latest_path:

            skipped.append({'name': str(getattr(it, 'name', '') or ''), 'reason': _t('Missing path information in saved plan')})

            continue

        if current_path == latest_path:

            skipped.append({'name': str(getattr(it, 'name', '') or ''), 'reason': _t('Already latest')})

            continue

        if not bool(getattr(it, 'has_newer', False)):

            skipped.append({'name': str(getattr(it, 'name', '') or ''), 'reason': _t('No newer version found')})

            continue

        entries.append({

            'name': str(getattr(it, 'name', '') or os.path.basename(current_path) or '(unknown)'),

            'old_path': current_path,

            'new_path': latest_path,

            'current_ver': int(getattr(it, 'mtime', 0) or 0),

            'latest_ver': int(getattr(it, 'latest_ver', 0) or 0),

            'status': str(getattr(it, 'status', '') or ''),

        })

    return entries, skipped





def _sf_rm_upgrade_plan_execute(context, *, direction: str = 'FORWARD', open_report: bool = True) -> tuple[dict, str]:

    payload = _sf_rm_upgrade_plan_read_payload()

    entries = list(payload.get('entries') or [])

    if not entries:

        raise RuntimeError(_t('No saved upgrade plan was found'))



    direction = str(direction or 'FORWARD').upper()

    expected_key = 'old_path' if direction != 'RESTORE' else 'new_path'

    target_key = 'new_path' if direction != 'RESTORE' else 'old_path'

    source_blend = _norm_path(str(payload.get('source_blend', '') or ''))

    current_blend = _norm_path(str(bpy.data.filepath or ''))



    changed = 0

    drifted = 0

    failed = 0

    skipped = 0

    reload_targets = []

    report_lines = [

        f"Smart File | {_t('Saved Upgrade Plan')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        f"- {_t('Direction')}: {direction}",

        f"- {_t('Source Blend')}: {source_blend or _t('Unsaved')}",

        f"- {_t('Current Blend')}: {current_blend or _t('Unsaved')}",

        f"- {_t('Entries')}: {len(entries)}",

        '',

        'RESULTS',

    ]

    if source_blend and current_blend and source_blend != current_blend:

        report_lines.append(f"- [WARN] {_t('Plan was created from a different .blend file')}: {source_blend}")



    for entry in entries:

        expected_path = _norm_path(str(entry.get(expected_key, '') or ''))

        target_path = _norm_path(str(entry.get(target_key, '') or ''))

        label = str(entry.get('name', '') or os.path.basename(expected_path) or '(unknown)')

        if not expected_path or not target_path:

            skipped += 1

            report_lines.append(f"- [SKIP] {label} | {_t('Missing path information in saved plan')}")

            continue

        matches = [lib for lib in list(getattr(bpy.data, 'libraries', []) or []) if _norm_path(getattr(lib, 'filepath', '') or '') == expected_path]

        if not matches:

            drifted += 1

            report_lines.append(f"- [DRIFT] {label} | {expected_path}")

            continue

        entry_changed = 0

        for lib in matches:

            try:

                current_path = _norm_path(getattr(lib, 'filepath', '') or '')

            except Exception:

                current_path = ''

            if current_path != expected_path:

                drifted += 1

                report_lines.append(f"- [DRIFT] {label} | {current_path}")

                continue

            try:

                lib.filepath = target_path

                reload_targets.append(target_path)

                changed += 1

                entry_changed += 1

                report_lines.append(f"- [OK] {label} | {expected_path} -> {target_path}")

            except Exception as ex:

                failed += 1

                report_lines.append(f"- [FAIL] {label} | {ex}")

        if entry_changed <= 0:

            skipped += 1



    for reload_path in list(dict.fromkeys(reload_targets)):

        try:

            _rm_reload_library_by_fp(reload_path)

        except Exception:

            pass



    try:

        _rm_mark_seen(context)

    except Exception:

        pass

    try:

        _rm_refresh_list(context)

    except Exception:

        pass

    try:

        _rm_check_updates(context, silent=True)

    except Exception:

        pass



    text_name = _sf_report_export(

        context,

        _t('Apply Saved Upgrade Plan') if direction != 'RESTORE' else _t('Restore Saved Upgrade Plan'),

        report_lines,

        open_text=open_report,

        activity_title=_t('Applied saved upgrade plan') if direction != 'RESTORE' else _t('Restored saved upgrade plan'),

    )

    summary = {

        'changed': changed,

        'drifted': drifted,

        'failed': failed,

        'skipped': skipped,

        'entries': len(entries),

    }

    return summary, text_name





class SF_RM_LibraryItem(bpy.types.PropertyGroup):

    bl_description = 'Store one detected library item so the reference manager can inspect roots, broken links, and relink candidates'



    is_selected: BoolProperty(default=False)

    filepath: StringProperty(default="")

    name: StringProperty(default="")

    status: StringProperty(default="OK")  # OK / UPDATED / MISSING

    mtime: IntProperty(default=-1)

    cached_mtime: IntProperty(default=-1)



    asset_id: StringProperty(default="", options={'HIDDEN'})



    total_ids: IntProperty(default=0)

    count_objects: IntProperty(default=0)

    count_collections: IntProperty(default=0)

    count_materials: IntProperty(default=0)

    count_images: IntProperty(default=0)

    count_node_groups: IntProperty(default=0)

    count_actions: IntProperty(default=0)

    count_worlds: IntProperty(default=0)



    has_newer: BoolProperty(default=False)

    latest_path: StringProperty(default="")

    latest_ver: IntProperty(default=0)





class SF_RM_CandidateItem(bpy.types.PropertyGroup):

    bl_description = 'Store one possible relink candidate so you can compare paths and choose the safest repair target'



    filepath: StringProperty(default="")

    label: StringProperty(default="")

    source: StringProperty(default="")

    version: IntProperty(default=0)

    exists: BoolProperty(default=False)

    asset_id: StringProperty(default="", options={'HIDDEN'})

    score: FloatProperty(default=0.0)

    score_detail: StringProperty(default="", options={'HIDDEN'})





class SF_RM_PlanItem(bpy.types.PropertyGroup):

    bl_description = 'Store one planned relink or repair step so you can review what will change before applying fixes'



    is_selected: BoolProperty(default=False)

    name: StringProperty(default="")

    filepath: StringProperty(default="")

    asset_id: StringProperty(default="", options={'HIDDEN'})



    action: EnumProperty(

        name='Action',

        items=[

            ('NONE', "None", ""),

            ('RELOAD', "Reload", ""),

            ('SWITCH', "Switch to Latest", ""),

            ('RESOLVE', "Resolve Missing", ""),

            ('RELINK', "Relink", ""),

        ],

        default='NONE',

    )

    reason: StringProperty(default="")

    current_ver: IntProperty(default=0)

    proposed_path: StringProperty(default="")

    proposed_ver: IntProperty(default=0)





class SF_UL_rm_candidates(bpy.types.UIList):

    bl_description = 'Show scored relink candidates for the active library so you can compare score, version, and source before choosing a replacement path'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        row = layout.row(align=True)

        _cand_state_label, ic = _sf_state_meta('READY' if getattr(item, 'exists', False) else 'MISSING', fallback_icon='NONE')

        row.label(text=_sf_short_label_display(item.label or os.path.basename(item.filepath), 42), icon=ic, translate=False)

        sub = row.row(align=True)

        sub.scale_x = 0.9

        if hasattr(item, 'score'):

            try:

                sub.label(text=f"{_t('Score')}: {int(item.score)}")

            except Exception:

                pass

        if item.version:

            sub.label(text=f"{_t('Version')}: v{int(item.version):03d}")

        if item.source:

            sub.label(text=f"{_t('Source')}: {_sf_short_label_display(item.source, 18)}")





class SF_UL_rm_plan(bpy.types.UIList):

    bl_description = 'Show the current relink or repair plan row by row so you can enable only the changes you want to apply'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        row = layout.row(align=True)

        row.prop(item, "is_selected", text='')

        act = getattr(item, 'action', 'NONE')

        ic = 'DOT'

        if act == 'RELOAD':

            ic = 'FILE_REFRESH'

        elif act == 'SWITCH':

            ic = 'SORTTIME'

        elif act == 'RESOLVE':

            ic = 'FILE_FOLDER'

        elif act == 'RELINK':

            ic = 'FILEBROWSER'

        row.label(text=_sf_short_label_display(item.name, 40), icon=ic, translate=False)

        sub = row.row(align=True)

        sub.scale_x = 0.9

        if item.reason:

            sub.label(text=_sf_short_label_display(item.reason, 42))





class SF_UL_rm_libraries(bpy.types.UIList):

    bl_description = 'Show linked libraries found in the current file so you can inspect status, missing paths, newer versions, and relink readiness'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        row = layout.row(align=True)

        row.prop(item, "is_selected", text='')

        state_key = 'READY'

        if item.status == "MISSING":

            state_key = 'MISSING'

        elif item.status == "UPDATED" or item.has_newer:

            state_key = 'UPDATED'

        _lib_state_label, ic = _sf_state_meta(state_key, fallback_icon='NONE')

        row.label(text=_sf_short_label_display(item.name, 40), icon=ic, translate=False)

        # show small counts

        sub = row.row(align=True)

        sub.scale_x = 0.9

        sub.label(text=f"{_t('Linked IDs')}: {item.total_ids}")





class SF_MT_reference_manager_reference_manager_notice(bpy.types.Menu):

    bl_label = 'Reference Manager Notice'

    bl_idname = 'SF_MT_reference_manager_reference_manager_notice'

    bl_description = 'Review the latest automatic relink notice, missing libraries, and quick recovery actions from one compact menu'



    def draw(self, context):

        layout = self.layout

        upd = _RM_LAST_AUTO_RESULT.get("updated", []) or []

        mis = _RM_LAST_AUTO_RESULT.get("missing", []) or []

        if upd:

            layout.label(text=f"{_tr('Updated')}: {len(upd)}", icon='FILE_REFRESH')

            for fp in upd[:6]:

                layout.label(text=os.path.basename(fp), icon='FILE_BLEND', translate=False)

            if len(upd) > 6:

                layout.label(text='...', icon='DOT')

        if mis:

            layout.separator()

            layout.label(text=f"{_tr('Missing')}: {len(mis)}", icon='ERROR')

            for fp in mis[:6]:

                layout.label(text=os.path.basename(fp), icon='FILE_BLEND', translate=False)

            if len(mis) > 6:

                layout.label(text='...', icon='DOT')



        # Quick actions

        layout.separator()

        layout.operator("import_scene.sfs_reference_manager_review_update_plan", text=_t('Review Update Plan'), icon='FILE_TICK')

        layout.operator("import_scene.sfs_reference_manager_open", text=_t('Open'), icon='LINKED')

        row = layout.row(align=True)

        row.operator("import_scene.sfs_reference_manager_reload_all", text=_t('Reload All'), icon='FILE_REFRESH')

        op = row.operator("import_scene.sfs_reference_manager_switch_to_latest", text=_t('Switch to Latest'), icon='SORTTIME')

        _sf_safe_set_operator_property(op, 'apply_all', True)

        row_plan = layout.row(align=True)

        op3 = row_plan.operator("import_scene.sfs_rm_prepare_upgrade_plan", text=_t('Prepare Saved Upgrade Plan'), icon='FILE_TICK')

        op3.apply_all = True

        row_plan.operator("import_scene.sfs_reference_manager_apply_saved_upgrade_plan", text=_t('Apply Saved Upgrade Plan'), icon='CHECKMARK')

        row_plan.operator("import_scene.sfs_rm_restore_upgrade_plan", text=_t('Restore Saved Upgrade Plan'), icon='LOOP_BACK')

        row2 = layout.row(align=True)

        op2 = row2.operator("import_scene.sfs_library_roots_resolve_using_roots", text=_t('Resolve Using Roots'), icon='FILE_FOLDER')

        op2.apply_all = True

        row2.operator("import_scene.sfs_reference_manager_mark_seen", text=_t('Mark Seen'), icon='CHECKMARK')





class SF_OT_reference_manager_open(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_reference_manager_open'

    bl_label = 'Open'

    bl_description = 'Review linked library status, find missing or newer files, and safely reload, relink, or update references'

    bl_options = set()



    def invoke(self, context, _event):

        _rm_refresh_list(context)

        _rm_check_updates(context, silent=True)

        return context.window_manager.invoke_props_dialog(self, width=900)



    def draw(self, context):

        wm = context.window_manager

        prefs = _addon_prefs(context)

        layout = self.layout

        layout.use_property_split = True

        layout.use_property_decorate = False



        top = layout.row(align=True)

        _sf_operator_button(top, "import_scene.sfs_reference_manager_refresh", "Refresh", icon='FILE_REFRESH')

        _sf_operator_button(top, "import_scene.sfs_reference_manager_check_updates", "Check", icon='VIEWZOOM')

        _sf_operator_button(top, "import_scene.sfs_reference_manager_mark_seen", "Seen", icon='CHECKMARK')

        _sf_operator_button(top, "import_scene.sfs_reference_manager_reload_selected", "Reload Selected", icon='FILE_REFRESH')

        _sf_operator_button(top, "import_scene.sfs_reference_manager_reload_all", "Reload All", icon='FILE_REFRESH')



        split = layout.split(factor=0.52)

        left = split.column()

        right = split.column()



        if len(wm.sf_rm_items):

            left.template_list("SF_UL_rm_libraries", "", wm, "sf_rm_items", wm, "sf_rm_active_index", rows=10)

        else:

            box = left.box()

            box.label(text=_t('No linked libraries found'))



        if wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items):

            it = wm.sf_rm_items[wm.sf_rm_active_index]

            box = right.box()

            box.label(text=it.name, icon='LINKED', translate=False)

            box.label(text=os.path.basename(_norm_path(it.filepath or '')) or (it.filepath or ''), translate=False)

            box.label(text=f"{_t('Status')}: {it.status}")

            box.label(text=f"{_t('Linked IDs')}: {it.total_ids}")

            grid = box.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)

            grid.label(text=f"{_t('Objects')}: {it.count_objects}")

            grid.label(text=f"{_t('Collections')}: {it.count_collections}")

            grid.label(text=f"{_t('Materials')}: {it.count_materials}")

            grid.label(text=f"{_t('Images')}: {it.count_images}")

            grid.label(text=f"{_t('Node Groups')}: {it.count_node_groups}")

            grid.label(text=f"{_t('Actions')}: {it.count_actions}")

            actions = right.box()

            row = actions.row(align=True)

            op = _sf_operator_button(row, "import_scene.sfs_reference_manager_review_auto_relink", "Auto Relink", icon='VIEWZOOM')

            _sf_safe_set_operator_property(op, 'only_active', True)

            op = _sf_operator_button(row, "import_scene.sfs_reference_manager_review_suggested_relink", "Suggested", icon='VIEWZOOM')

            _sf_safe_set_operator_property(op, 'only_active', True)

            row = actions.row(align=True)

            op = _sf_operator_button(row, "import_scene.sfs_reference_manager_apply_selected_relink", "Apply Relink", icon='LINKED')

            _sf_safe_set_operator_property(op, 'only_active', True)

            op = _sf_operator_button(row, "import_scene.sfs_library_roots_resolve_using_roots", "Use Roots", icon='FILE_FOLDER')

            _sf_safe_set_operator_property(op, 'only_active', True)

            row = actions.row(align=True)

            row.operator("import_scene.sfs_external_assets_edit_selected_library", text=_t('Edit Selected Library'), icon='OUTLINER_OB_GROUP_INSTANCE')

            row.operator("import_scene.sfs_external_assets_audit", text=_t('Audit'), icon='CHECKMARK')

            row.operator("import_scene.sfs_reference_toolkit_open", text=_t('Open'), icon='ASSET_MANAGER')

            row.operator("import_scene.sfs_dependency_cockpit_open", text=_t('Open'), icon='NETWORK_DRIVE')

            row = actions.row(align=True)

            row.operator("import_scene.sfs_context_roots_open", text=_t('Open'), icon='FILE_PARENT')

            row.operator("import_scene.sfs_root_watch_open", text=_t('Open'), icon='FILE_REFRESH')

            if it.has_newer and it.latest_path:

                row = actions.row(align=True)

                op = row.operator("import_scene.sfs_reference_manager_switch_to_latest", text=_t('Switch to Latest'), icon='SORTTIME')

                _sf_safe_set_operator_property(op, 'only_active', True)

                op = row.operator("import_scene.sfs_rm_prepare_upgrade_plan", text=_t('Prepare Saved Upgrade Plan'), icon='FILE_TICK')

                _sf_safe_set_operator_property(op, 'only_active', True)

            saved = actions.row(align=True)

            saved.operator("import_scene.sfs_reference_manager_apply_saved_upgrade_plan", text=_t('Apply Saved Upgrade Plan'), icon='CHECKMARK')

            saved.operator("import_scene.sfs_rm_restore_upgrade_plan", text=_t('Restore Saved Upgrade Plan'), icon='LOOP_BACK')

        else:

            right.box().label(text=_t('No selection'))



    def execute(self, context):

        return {'FINISHED'}





class SF_OT_reference_manager_refresh(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_refresh'

    bl_label = 'Refresh'

    bl_description = 'Re-scan the current file for linked libraries and rebuild the Reference Manager list'



    bl_options = set()

    _sms_no_undo = True

    def execute(self, context):

        n = _rm_refresh_list(context)

        if n == 0:

            self.report({'INFO'}, _tr('No linked libraries found'))

        else:

            _rm_check_updates(context, silent=True)

        return {'FINISHED'}





class SF_OT_reference_manager_check_updates(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_check_updates'

    bl_label = 'Check Updates'

    bl_description = 'Check the listed linked libraries for missing files, newer versions, and relink candidates'



    bl_options = {'UNDO'}

    def execute(self, context):

        updated, missing = _rm_check_updates(context, silent=True)

        msg = []

        if updated:

            msg.append(f"{_tr('Updated')}: {len(updated)}")

        if missing:

            msg.append(f"{_tr('Missing')}: {len(missing)}")

        if msg:

            self.report({'WARNING'}, '/'.join(msg))

            prefs = _addon_prefs(context)

            if prefs and getattr(prefs, "rm_auto_popup_on_updates", False):

                try:

                    _sf_call_menu_direct("SF_MT_reference_manager_reference_manager_notice", context=context)

                except Exception:

                    pass

        else:

            self.report({'INFO'}, _tr('OK'))

        return {'FINISHED'}





class SF_OT_reference_manager_mark_seen(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_mark_seen'

    bl_label = 'Mark Seen'

    bl_description = 'Store the current linked-library timestamps so already reviewed updates stop showing as new'



    bl_options = {'UNDO'}

    def execute(self, context):

        cnt = _rm_mark_seen(context)

        self.report({'INFO'}, f"{_tr('Mark Seen')}: {cnt}")

        return {'FINISHED'}





class SF_OT_reference_manager_reload_selected(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_reload_selected'

    bl_label = 'Reload Selected'

    bl_description = 'Reload the active linked library from disk without changing its file path'



    bl_options = {'UNDO'}

    def execute(self, context):

        wm = context.window_manager

        done = 0

        for it in wm.sf_rm_items:

            if not it.is_selected:

                continue

            if _rm_reload_library_by_fp(it.filepath):

                done += 1

        _rm_mark_seen(context)

        _rm_refresh_list(context)

        self.report({'INFO'}, f"{_tr('Reload Selected')}: {done}")

        return {'FINISHED'}





class SF_OT_reference_manager_reload_all(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_reload_all'

    bl_label = 'Reload All'

    bl_description = 'Reload every linked library in the current file from disk'



    bl_options = {'UNDO'}

    def execute(self, context):

        done = 0

        # Reloading a library can free other empty libraries, so never keep an

        # RNA iterator open across lib.reload(): snapshot the paths first.

        for fp in [str(getattr(lib, "filepath", "") or "") for lib in bpy.data.libraries]:

            if _rm_reload_library_by_fp(fp):

                done += 1

        _rm_mark_seen(context)

        _rm_refresh_list(context)

        self.report({'INFO'}, f"{_tr('Reload All')}: {done}")

        return {'FINISHED'}





class SF_OT_reference_manager_apply_selected_relink(bpy.types.Operator, ImportHelper):

    bl_idname = 'import_scene.sfs_reference_manager_apply_selected_relink'

    bl_label = 'Apply Selected Relink'

    bl_description = 'Pick a specific replacement .blend file and apply that relink to the selected library reference'

    bl_options = {'UNDO'}



    filename_ext = ".blend"

    filter_glob: StringProperty(default="*.blend", options={'HIDDEN'})



    only_active: BoolProperty(default=False, options={'HIDDEN'})



    def execute(self, context):

        new_fp = _norm_path(self.filepath)

        if not new_fp:

            return {'CANCELLED'}



        wm = context.window_manager

        targets = []

        if self.only_active and wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items):

            targets = [wm.sf_rm_items[wm.sf_rm_active_index]]

        else:

            targets = [it for it in wm.sf_rm_items if it.is_selected] or ([])



        if not targets:

            self.report({'WARNING'}, _tr('No selection'))

            return {'CANCELLED'}



        for it in targets:

            if _rm_relink_library(it.filepath, new_fp):

                _rm_reload_library_by_fp(new_fp)

                it.filepath = new_fp

        _rm_mark_seen(context)

        _rm_refresh_list(context)

        self.report({'INFO'}, _tr('Apply Selected Relink...'))

        return {'FINISHED'}





class SF_OT_reference_manager_review_suggested_relink(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_review_suggested_relink'

    bl_label = 'Review Suggested Relink'

    bl_description = 'Inspect scored relink candidates for the current library and confirm the safest replacement path'

    bl_options = set()

    _sms_no_undo = True



    only_active: BoolProperty(default=True, options={'HIDDEN'})



    def invoke(self, context, _event):

        wm = context.window_manager

        wm.sf_rm_candidates.clear()

        wm.sf_rm_candidate_active_index = 0



        if not (wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items)):

            self.report({'WARNING'}, _tr('No selection'))

            return {'CANCELLED'}



        target = wm.sf_rm_items[wm.sf_rm_active_index]

        cands = _rm_collect_relink_candidates(context, target)

        if not cands:

            self.report({'WARNING'}, _tr('No candidates found'))

            return {'CANCELLED'}



        for c in cands[:200]:

            ci = wm.sf_rm_candidates.add()

            fp = _norm_path(c.get('filepath', '') or '')

            ci.filepath = fp

            ci.source = c.get('source', '') or ''

            ci.version = int(c.get('version', 0) or 0)

            ci.exists = bool(c.get('exists', False))

            ci.asset_id = (c.get('asset_id', '') or '').strip()

            try:

                ci.score = float(c.get('score', 0.0) or 0.0)

            except Exception:

                ci.score = 0.0

            ci.score_detail = (c.get('score_detail', '') or '')

            # label

            lab = os.path.basename(fp)

            if ci.version:

                lab = f"{lab} (v{ci.version:03d})"

            if ci.source:

                lab = f"{lab} [{ci.source}]"

            ci.label = lab



        return context.window_manager.invoke_props_dialog(self, width=860)



    def draw(self, context):

        wm = context.window_manager

        layout = self.layout

        _sf_draw_section_intro(layout.box(), 'Candidates', 'Compare relink options here and inspect score, source, and version before you trust a replacement.', 'VIEWZOOM')

        row = layout.row()

        if len(wm.sf_rm_candidates):

            _sf_draw_list_header(layout, [('Candidate / Score / Version / Source', 4.2)])

            row.template_list("SF_UL_rm_candidates", "", wm, "sf_rm_candidates", wm, "sf_rm_candidate_active_index", rows=10)

        else:

            _sf_draw_empty_state(layout, 'No relink candidates found', 'Try Refresh, Check Updates, or add trusted library roots before running candidate search again.', 'NONE')



        if wm.sf_rm_candidates and 0 <= wm.sf_rm_candidate_active_index < len(wm.sf_rm_candidates):

            c = wm.sf_rm_candidates[wm.sf_rm_candidate_active_index]

            box = layout.box()

            _sf_draw_section_intro(box, 'Selected Candidate', 'Use this summary to confirm score, version, and source before you relink to the highlighted file.', 'FILE_BLEND')

            box.label(text=_t('Replacement Summary'), icon='FILEBROWSER')

            box.label(text=os.path.basename(c.filepath), icon='FILE_BLEND', translate=False)

            _sf_draw_state_line(box, 'Candidate Status', 'READY' if getattr(c, 'exists', False) else 'MISSING', detail=os.path.basename(c.filepath or '') or '')

            _sf_draw_state_line(box, 'Candidate Source', 'READY' if getattr(c, 'source', '') else 'NOT SET', detail=getattr(c, 'source', ''))

            _sf_draw_state_line(box, 'Candidate Version', 'READY' if getattr(c, 'version', 0) else 'NOT SET', detail=(f"v{int(c.version):03d}" if getattr(c, 'version', 0) else ''))

            score_detail = str(int(c.score)) if hasattr(c, 'score') else ''

            _sf_draw_state_line(box, 'Candidate Score', 'REVIEW' if hasattr(c, 'score') else 'NOT SET', detail=score_detail)

            box.label(text=_t('File') + ':' + c.filepath)

            if getattr(c, 'score_detail', ''):

                box.label(text=_t('Score detail') + ':' + (c.score_detail[:220]))



    def execute(self, context):

        wm = context.window_manager

        if not (wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items)):

            return {'CANCELLED'}

        if not (wm.sf_rm_candidates and 0 <= wm.sf_rm_candidate_active_index < len(wm.sf_rm_candidates)):

            return {'CANCELLED'}



        target = wm.sf_rm_items[wm.sf_rm_active_index]

        cand = wm.sf_rm_candidates[wm.sf_rm_candidate_active_index]

        new_fp = _norm_path(cand.filepath)

        if not new_fp:

            return {'CANCELLED'}



        if _rm_relink_library(target.filepath, new_fp):

            _rm_reload_library_by_fp(new_fp)

            target.filepath = new_fp

            _rm_mark_seen(context)

            _rm_refresh_list(context)

            self.report({'INFO'}, _t('Apply Selected Relink...') + f": {os.path.basename(new_fp)}")

            return {'FINISHED'}



        self.report({'WARNING'}, _t('Relink failed'))

        return {'CANCELLED'}





class SF_OT_reference_manager_review_auto_relink(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_review_auto_relink'

    bl_label = 'Review Auto Relink'

    bl_description = 'Build a proposed relink plan automatically, then review the suggested changes before anything is applied'

    bl_options = set()

    _sms_no_undo = True



    only_active: BoolProperty(default=True, options={'HIDDEN'})

    apply_all: BoolProperty(default=False, options={'HIDDEN'})



    def invoke(self, context, _event):

        _rm_build_relink_plan(context, only_active=self.only_active, apply_all=self.apply_all)

        # Reuse the review dialog (confirm-only flow)

        return bpy.ops.import_scene.sfs_reference_manager_review_update_plan('INVOKE_DEFAULT', use_existing_plan=True)



    def execute(self, context):

        return {'FINISHED'}







def _rm_collect_review_candidates(context, plan_item) -> tuple[list[dict], dict]:

    try:

        class _Tmp:

            pass

        tmp = _Tmp()

        tmp.filepath = getattr(plan_item, 'filepath', '')

        tmp.asset_id = getattr(plan_item, 'asset_id', '')

        cands = _rm_collect_relink_candidates(context, tmp) or []

    except Exception:

        cands = []



    selected = {}

    pnorm = _norm_path(getattr(plan_item, 'proposed_path', '') or '')

    if pnorm:

        for cc in cands:

            if _norm_path(cc.get('filepath', '') or '') == pnorm:

                selected = cc

                break

    return cands, selected





class SF_OT_reference_manager_apply_preset(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_apply_preset'

    bl_label = 'Apply Preset'

    bl_description = 'Apply a predefined candidate-scoring profile to the Reference Manager safety weights'

    bl_options = {'UNDO', 'INTERNAL'}



    preset: EnumProperty(

        name='Scoring preset',

        items=[

            ('SAFE', "Safe", ""),

            ('AGGRESSIVE', "Aggressive", ""),

            ('LOCAL_FIRST', "Local-first", ""),

        ],

        default='SAFE',

    )



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}



        p = self.preset

        if p == 'SAFE':

            prefs.rm_candidate_priority = 'CATALOG_FIRST'

            prefs.rm_asset_id_match_mode = 'EXCLUDE_MISMATCH'

            prefs.rm_no_id_mode = 'EMERGENCY_ONLY'

            prefs.rm_score_w_exists = 2000

            prefs.rm_score_w_asset_id = 1200

            prefs.rm_score_w_source = 100

            prefs.rm_score_w_version = 1

            prefs.rm_score_w_root = 5

        elif p == 'AGGRESSIVE':

            prefs.rm_candidate_priority = 'HIGHEST_VERSION'

            prefs.rm_asset_id_match_mode = 'OFF'

            prefs.rm_no_id_mode = 'ALLOW'

            prefs.rm_score_w_exists = 1000

            prefs.rm_score_w_asset_id = 0

            prefs.rm_score_w_source = 50

            prefs.rm_score_w_version = 10

            prefs.rm_score_w_root = 2

        elif p == 'LOCAL_FIRST':

            prefs.rm_candidate_priority = 'DIR_FIRST'

            prefs.rm_asset_id_match_mode = 'EXCLUDE_MISMATCH'

            prefs.rm_no_id_mode = 'EMERGENCY_ONLY'

            prefs.rm_score_w_exists = 1200

            prefs.rm_score_w_asset_id = 800

            prefs.rm_score_w_source = 300

            prefs.rm_score_w_version = 2

            prefs.rm_score_w_root = 1



        prefs.rm_score_preset = p

        return {'FINISHED'}



class SF_OT_reference_manager_review_update_plan(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_review_update_plan'

    bl_label = 'Review Update Plan'

    bl_description = 'Review the planned reference updates, choose which rows are safe, and apply only the approved changes'

    bl_options = set()

    _sms_no_undo = True



    use_existing_plan: BoolProperty(default=False, options={'HIDDEN'})



    def invoke(self, context, _event):

        if not self.use_existing_plan:

            _rm_build_update_plan(context)

        return context.window_manager.invoke_props_dialog(self, width=1120)



    def draw(self, context):

        wm = context.window_manager

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Review Update Plan', 'Review the current plan, confirm the selected rows, then apply only the updates you trust.', 'FILE_TICK')



        # Summary (counts)

        totals = {'RELOAD': 0, 'SWITCH': 0, 'RESOLVE': 0, 'RELINK': 0, 'NONE': 0}

        sels = {'RELOAD': 0, 'SWITCH': 0, 'RESOLVE': 0, 'RELINK': 0, 'NONE': 0}

        unresolved = 0

        for p in wm.sf_rm_plan_items:

            act = getattr(p, 'action', 'NONE') or 'NONE'

            if act not in totals:

                act = 'NONE'

            totals[act] += 1

            if getattr(p, 'is_selected', False):

                sels[act] += 1

            if act in {'RESOLVE', 'SWITCH', 'RELINK'} and not (getattr(p, 'proposed_path', '') or ''):

                unresolved += 1

            if act == 'NONE' and (getattr(p, 'reason', '') or '').lower().find('missing') >= 0:

                unresolved += 1



        overview = _sf_draw_dialog_header(layout, 'Plan Overview', 'Review totals first, then inspect unresolved rows before applying the plan.', 'NONE')

        row = overview.row(align=True)

        row.label(text=f"{_t('Total')}: {len(wm.sf_rm_plan_items)}")

        row.label(text=f"{_t('Selected')}: {sum(sels.values())}")

        if unresolved:

            row.label(text=f"{_t('Unresolved')}: {unresolved}", icon='ERROR')



        grid = overview.grid_flow(columns=4, even_columns=True, even_rows=False, align=True)

        grid.label(text=f"{_t('Reload')} {sels['RELOAD']}/{totals['RELOAD']}", icon='FILE_REFRESH')

        grid.label(text=f"{_t('Switch to Latest')} {sels['SWITCH']}/{totals['SWITCH']}", icon='SORTTIME')

        grid.label(text=f"{_t('Resolve Missing')} {sels['RESOLVE']}/{totals['RESOLVE']}", icon='FILE_FOLDER')

        grid.label(text=f"{_t('Relink')} {sels['RELINK']}/{totals['RELINK']}", icon='FILEBROWSER')



        split = layout.split(factor=0.55)

        left = split.column()

        right = split.column()



        _sf_draw_section_intro(left.box(), 'Planned Changes', 'Review each row before you apply updates, relinks, or missing-file repairs.', 'FILE_TICK')

        if len(wm.sf_rm_plan_items):

            _sf_draw_list_header(left, [('Change / Reason', 4.0)])

            left.template_list("SF_UL_rm_plan", "", wm, "sf_rm_plan_items", wm, "sf_rm_plan_active_index", rows=12)

        else:

            _sf_draw_empty_state(left, 'No planned changes yet', 'Run Check Updates or Auto Relink first, then review the proposed plan here.', 'NONE')



        if wm.sf_rm_plan_items and 0 <= wm.sf_rm_plan_active_index < len(wm.sf_rm_plan_items):

            it = wm.sf_rm_plan_items[wm.sf_rm_plan_active_index]

            box = right.box()

            _sf_draw_section_intro(box, 'Selected Change', 'Confirm the reason and proposed replacement here before you apply this plan row.', 'FILE_TICK')

            box.label(text=_t('Change Summary'), icon='FILE_TICK')

            box.label(text=it.name, icon='FILE_BLEND', translate=False)

            box.label(text=_t('File') + ':' + (it.filepath or ""))

            if it.asset_id:

                box.label(text=_t('Asset ID') + ':' + it.asset_id)



            row = box.row(align=True)

            row.prop(it, "action", text=_t('Action'))

            row.prop(it, "is_selected", text=_t('Apply'))

            action_state = 'READY'

            action_map = {

                'NONE': _t('None'),

                'RELOAD': _t('Reload'),

                'SWITCH': _t('Switch to Latest'),

                'RESOLVE': _t('Resolve Missing'),

                'RELINK': _t('Relink'),

            }

            action_detail = action_map.get(getattr(it, 'action', 'NONE'), _t('Action'))

            if getattr(it, 'action', 'NONE') == 'NONE':

                action_state = 'REVIEW'

            elif getattr(it, 'action', 'NONE') in {'SWITCH', 'RESOLVE', 'RELINK'} and not (getattr(it, 'proposed_path', '') or ''):

                action_state = 'UNRESOLVED'

            _sf_draw_state_line(box, 'Plan Status', action_state, detail=action_detail)

            if it.reason:

                box.label(text=_t('Reason') + ':' + it.reason)



            if it.action in {'SWITCH', 'RESOLVE', 'RELINK'}:

                box.separator()

                box.label(text=_t('Proposed') + ":")



                cands, selected_cand = _rm_collect_review_candidates(context, it)

                rowd = box.row(align=True)

                rowd.prop(wm, "sf_rm_review_show_score_detail", text=_t('Score details'), emboss=False,

                          icon='TRIA_DOWN' if wm.sf_rm_review_show_score_detail else 'TRIA_RIGHT')



                proposed_norm = _norm_path(it.proposed_path or '')

                proposed_exists = bool(proposed_norm and os.path.exists(proposed_norm))

                _sf_draw_state_line(box, 'File Status', 'READY' if proposed_exists else 'MISSING', detail=os.path.basename(proposed_norm) or '')

                box.label(text=it.proposed_path or "")

                _sf_draw_state_line(box, 'Candidate Search', 'READY' if cands else 'NEEDS ROOTS', detail=f"{len(cands)} {_t('Candidates')}" if cands else _t('No relink candidates found'))



                sel_source = (selected_cand.get('source', '') or '').strip() if selected_cand else ''

                sel_version = int(selected_cand.get('version', 0) or 0) if selected_cand else int(getattr(it, 'proposed_ver', 0) or 0)

                sel_score = int(selected_cand.get('score', 0) or 0) if selected_cand else 0

                _sf_draw_state_line(box, 'Candidate Source', 'READY' if sel_source else 'NOT SET', detail=sel_source)

                _sf_draw_state_line(box, 'Candidate Version', 'READY' if sel_version else 'NOT SET', detail=(f"v{sel_version:03d}" if sel_version else ''))

                _sf_draw_state_line(box, 'Candidate Score', 'REVIEW' if cands else 'NOT SET', detail=(str(sel_score) if (selected_cand and sel_score) else ''))



                if wm.sf_rm_review_show_score_detail:

                    det = (selected_cand.get('score_detail', '') or '') if selected_cand else ''

                    if det:

                        box.label(text=det)

                if it.proposed_ver:

                    box.label(text=_t('Version') + f": v{int(it.proposed_ver):03d}")



                # Candidate comparison (Top 3)

                if cands:

                    box.separator()

                    box.label(text=_t('Top candidates') + ":")

                    for cc in cands[:3]:

                        fp = _norm_path(cc.get('filepath', '') or '')

                        if not fp:

                            continue

                        rowc = box.row(align=True)

                        icon = 'CHECKMARK' if (proposed_norm and fp == proposed_norm) else 'DOT'

                        rowc.label(text=os.path.basename(fp), icon=icon, translate=False)

                        try:

                            rowc.label(text=f"S:{int(cc.get('score', 0) or 0)}")

                        except Exception:

                            pass

                        vv = int(cc.get('version', 0) or 0)

                        if vv:

                            rowc.label(text=f"v{vv:03d}")

                        src = (cc.get('source', '') or '')

                        if src:

                            rowc.label(text=src)



                        if wm.sf_rm_review_show_score_detail:

                            det = (cc.get('score_detail', '') or '')

                            if det:

                                box.label(text=det)

            elif it.action == 'RELOAD':

                box.separator()

                _sf_draw_state_line(box, 'Plan Status', 'READY', detail=_t('Reload current library from disk'))

                box.label(text=_t('Proposed') + ':' + _t('Reload'))



        else:

            right.label(text=_t('No selection'))



        layout.separator()

        actions = _sf_draw_dialog_header(layout, 'Selection Actions', 'Refresh the plan first if source files changed, then choose which rows can apply.', 'CHECKMARK')

        _sf_draw_action_block(

            actions,

            primary_actions=[

                ("import_scene.sfs_reference_manager_refresh_2", "Rebuild Plan", 'FILE_REFRESH', {}),

            ],

            secondary_actions=[

                ("import_scene.sfs_reference_manager_review_select_all", "Select All", 'CHECKBOX_HLT', {'select': True}),

                ("import_scene.sfs_reference_manager_review_select_all", "Deselect All", 'CHECKBOX_DEHLT', {'select': False}),

            ],

        )



    def execute(self, context):

        wm = context.window_manager

        applied = 0

        for p in wm.sf_rm_plan_items:

            if not p.is_selected or p.action == 'NONE':

                continue

            old_fp = _norm_path(p.filepath)

            if p.action == 'RELOAD':

                if _rm_reload_library_by_fp(old_fp):

                    applied += 1

            elif p.action in {'SWITCH', 'RESOLVE', 'RELINK'}:

                new_fp = _norm_path(p.proposed_path)

                if new_fp and _rm_relink_library(old_fp, new_fp):

                    _rm_reload_library_by_fp(new_fp)

                    applied += 1

        _rm_mark_seen(context)

        _rm_refresh_list(context)

        self.report({'INFO'}, f"{_t('Apply Selected')}: {applied}")

        return {'FINISHED'}





class SF_OT_reference_manager_review_select_all(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_review_select_all'

    bl_label = 'Review Select All'

    bl_description = 'Enable or disable every row in the current review plan at once'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    select: BoolProperty(default=True)



    def execute(self, context):

        wm = context.window_manager

        for it in wm.sf_rm_plan_items:

            if it.action == 'NONE':

                it.is_selected = False

            else:

                it.is_selected = bool(self.select)

        return {'FINISHED'}





class SF_OT_reference_manager_refresh_2(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_refresh_2'

    bl_label = 'Refresh'

    bl_description = 'Rebuild the current review plan so it reflects the latest candidate analysis and selections'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        _rm_build_update_plan(context)

        return {'FINISHED'}





class SF_OT_library_roots_resolve_using_roots(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_resolve_using_roots'

    bl_label = 'Resolve Using Roots'

    bl_description = 'Search the configured Library Roots and named Context Roots for a replacement file that can fix the selected missing reference'

    bl_options = {'UNDO'}



    only_active: BoolProperty(default=False, options={'HIDDEN'})



    apply_all: BoolProperty(default=False, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}



        wm = context.window_manager

        targets = []

        if self.apply_all:

            targets = list(wm.sf_rm_items)

        elif self.only_active and wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items):

            targets = [wm.sf_rm_items[wm.sf_rm_active_index]]

        else:

            targets = [it for it in wm.sf_rm_items if it.is_selected] or []



        if not targets:

            self.report({'WARNING'}, _tr('No selection'))

            return {'CANCELLED'}



        idx = _load_index()

        files = idx.get("files", {}) if isinstance(idx, dict) else {}



        resolved = 0

        for it in targets:

            if it.status != "MISSING":

                continue



            # Prefer catalog latest by asset_id if available (more robust than filename search)

            if getattr(it, "asset_id", ""):

                try:

                    merged = _ar_get_merged_catalog(context, force=False)

                    by_id = (merged.get("latest_by_asset_id", {}) or {})

                    ent, _ver = by_id.get(str(it.asset_id), (None, 0))

                    cand_fp = _norm_path((ent.get("blend_abs", "") or "")) if ent else ""

                    if cand_fp and os.path.exists(cand_fp):

                        if _rm_relink_library(it.filepath, cand_fp):

                            _rm_reload_library_by_fp(cand_fp)

                            it.filepath = _norm_path(cand_fp)

                            resolved += 1

                            continue

                except Exception:

                    pass

            want = os.path.basename(it.filepath) if it.filepath else ""

            if not want:

                continue



            cand = None

            try:

                cand = _sf_ctx_find_best_library_replacement(context, str(it.filepath or ''), index_data=idx)

            except Exception:

                cand = None



            # fast path via index

            if not cand:

                for fp in files.keys():

                    if os.path.basename(fp) == want:

                        cand = fp

                        break



            # fallback: scan roots (limited)

            if not cand:

                roots = []

                for r in getattr(prefs, "library_roots", []) or []:

                    if getattr(r, "enabled", True):

                        rp = _norm_path(getattr(r, "path", ""))

                        if rp and os.path.isdir(rp):

                            roots.append(rp)

                for rp in roots:

                    found = None

                    for dirpath, dirnames, filenames in os.walk(rp):

                        dirnames[:] = [d for d in dirnames if not d.startswith(".")]

                        if want in filenames:

                            found = os.path.join(dirpath, want)

                            break

                    if found:

                        cand = found

                        break



            if cand and os.path.exists(cand):

                if _rm_relink_library(it.filepath, cand):

                    _rm_reload_library_by_fp(cand)

                    it.filepath = _norm_path(cand)

                    resolved += 1



        _rm_mark_seen(context)

        _rm_refresh_list(context)

        self.report({'INFO'}, f"{_tr('Resolve Using Roots')}: {resolved}")

        return {'FINISHED'}





class SF_OT_reference_manager_switch_to_latest(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_switch_to_latest'

    bl_label = 'Switch to Latest'

    bl_description = 'Replace the active linked library with the latest version found by the current search rules'

    bl_options = {'UNDO'}



    only_active: BoolProperty(default=False, options={'HIDDEN'})



    apply_all: BoolProperty(default=False, options={'HIDDEN'})



    def execute(self, context):

        wm = context.window_manager

        targets = []

        if self.apply_all:

            targets = list(wm.sf_rm_items)

        elif self.only_active and wm.sf_rm_items and 0 <= wm.sf_rm_active_index < len(wm.sf_rm_items):

            targets = [wm.sf_rm_items[wm.sf_rm_active_index]]

        else:

            targets = [it for it in wm.sf_rm_items if it.is_selected] or []



        if not targets:

            self.report({'WARNING'}, _tr('No selection'))

            return {'CANCELLED'}



        switched = 0

        for it in targets:

            if not it.has_newer or not it.latest_path:

                continue

            old_fp = it.filepath

            new_fp = it.latest_path

            if _rm_relink_library(old_fp, new_fp):

                _rm_reload_library_by_fp(new_fp)

                it.filepath = new_fp

                switched += 1



        if switched == 0:

            self.report({'INFO'}, _tr('No newer version found'))

        else:

            _rm_mark_seen(context)

            _rm_refresh_list(context)

            self.report({'INFO'}, f"{_tr('Switched to latest')}: {switched}")

        return {'FINISHED'}







class SF_OT_reference_manager_prepare_saved_upgrade_plan(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_rm_prepare_upgrade_plan'

    bl_label = 'Prepare Saved Upgrade Plan'

    bl_description = 'Snapshot the current latest-version replacements into a saved upgrade plan so you can preview them now, apply them later, and restore them safely if needed.'

    bl_options = {'UNDO'}



    only_active: BoolProperty(default=False, options={'HIDDEN'})

    apply_all: BoolProperty(default=False, options={'HIDDEN'})

    open_report: BoolProperty(name='Open Report', default=True, description="Open the generated saved upgrade report in Blender's text editor after writing the plan.")



    def execute(self, context):

        targets = _sf_rm_resolved_targets(context, only_active=bool(self.only_active), apply_all=bool(self.apply_all))

        if not targets:

            self.report({'WARNING'}, _tr('No selection'))

            return {'CANCELLED'}

        entries, skipped_rows = _sf_rm_upgrade_plan_entries_for_targets(targets)

        if not entries:

            self.report({'INFO'}, _t('No newer version found'))

            return {'CANCELLED'}



        payload = {

            'created_at': datetime.datetime.now().isoformat(timespec='seconds'),

            'source_blend': _norm_path(str(bpy.data.filepath or '')),

            'entries': entries,

        }

        text_block_name = _sf_rm_upgrade_plan_write_payload(payload)

        report_lines = [

            f"Smart File | {_t('Prepare Saved Upgrade Plan')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",

            '',

            f"- {_t('Saved Upgrade Plan')}: {text_block_name}",

            f"- {_t('Entries')}: {len(entries)}",

            f"- {_t('Skipped')}: {len(skipped_rows)}",

            '',

            'PLAN',

        ]

        for entry in entries:

            label = str(entry.get('name', '') or os.path.basename(str(entry.get('old_path', '') or '')) or '(unknown)')

            report_lines.append(f"- [READY] {label} | {entry.get('old_path','')} -> {entry.get('new_path','')}")

        if skipped_rows:

            report_lines.append('')

            report_lines.append('SKIPPED')

            for row in skipped_rows[:24]:

                report_lines.append(f"- [SKIP] {row.get('name','')} | {row.get('reason','')}")

            if len(skipped_rows) > 24:

                report_lines.append(f"- ... +{len(skipped_rows) - 24}")



        report_lines.append('')

        report_lines.append('NEXT')

        report_lines.append(f"- {_t('Use Apply Saved Upgrade Plan to switch the stored libraries without rebuilding the latest-version search')}")

        report_lines.append(f"- {_t('Use Restore Saved Upgrade Plan to roll back the latest stored library upgrade when the current file still matches the saved target paths')}")



        text_name = _sf_report_export(

            context,

            _t('Prepare Saved Upgrade Plan'),

            report_lines,

            open_text=bool(self.open_report),

            activity_title=_t('Prepared saved upgrade plan'),

        )

        self.report({'INFO'}, f"{_t('Saved Upgrade Plan')}: {len(entries)} | {text_name}")

        return {'FINISHED'}





class SF_OT_reference_manager_apply_saved_upgrade_plan(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_apply_saved_upgrade_plan'

    bl_label = 'Apply Saved Upgrade Plan'

    bl_description = 'Apply the last saved library upgrade plan so the same latest-version switches can run later without rebuilding the search list.'

    bl_options = {'UNDO'}



    open_report: BoolProperty(name='Open Report', default=True, description='Open the saved upgrade execution report after applying the stored plan.')



    def execute(self, context):

        try:

            summary, text_name = _sf_rm_upgrade_plan_execute(context, direction='FORWARD', open_report=bool(self.open_report))

        except RuntimeError as ex:

            self.report({'WARNING'}, _sf_error_text(ex))

            return {'CANCELLED'}

        level = {'WARNING'} if int(summary.get('failed', 0) or 0) or int(summary.get('drifted', 0) or 0) else {'INFO'}

        self.report(level, f"{_t('Updated')}: {summary.get('changed', 0)} | {_t('Drifted')}: {summary.get('drifted', 0)} | {_t('Failed')}: {summary.get('failed', 0)} | {text_name}")

        return {'FINISHED'}





class SF_OT_reference_manager_restore_saved_upgrade_plan(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_rm_restore_upgrade_plan'

    bl_label = 'Restore Saved Upgrade Plan'

    bl_description = 'Roll back the last saved library upgrade plan conservatively. Only libraries that still match the stored target paths are restored.'

    bl_options = {'UNDO'}



    open_report: BoolProperty(name='Open Report', default=True, description='Open the saved upgrade restore report after rolling back the stored plan.')



    def execute(self, context):

        try:

            summary, text_name = _sf_rm_upgrade_plan_execute(context, direction='RESTORE', open_report=bool(self.open_report))

        except RuntimeError as ex:

            self.report({'WARNING'}, _sf_error_text(ex))

            return {'CANCELLED'}

        level = {'WARNING'} if int(summary.get('failed', 0) or 0) or int(summary.get('drifted', 0) or 0) else {'INFO'}

        self.report(level, f"{_t('Updated')}: {summary.get('changed', 0)} | {_t('Drifted')}: {summary.get('drifted', 0)} | {_t('Failed')}: {summary.get('failed', 0)} | {text_name}")

        return {'FINISHED'}









def _rm_restore_selection_state(context, prev_selected, prev_active):

    try:

        current_selected = list(getattr(context, 'selected_objects', []) or [])

    except Exception:

        current_selected = []

    for obj in current_selected:

        try:

            obj.select_set(False)

        except Exception:

            pass

    for obj in list(prev_selected or []):

        try:

            obj.select_set(True)

        except Exception:

            pass

    try:

        context.view_layer.objects.active = prev_active

    except Exception:

        pass





def _rm_override_target_key(id_block):

    try:

        if id_block is None:

            return ('NONE', '')

        ap = getattr(id_block, 'as_pointer', None)

        if callable(ap):

            ptr = int(ap())

            if ptr:

                return ('PTR', ptr)

    except Exception:

        pass

    try:

        return (type(id_block).__name__, getattr(id_block, 'name_full', '') or getattr(id_block, 'name', ''))

    except Exception:

        return (type(id_block).__name__, repr(id_block))





def _rm_make_override_for_id(context, id_block) -> tuple[bool, str]:

    if id_block is None:

        return False, 'missing target'

    if getattr(id_block, 'override_library', None):

        return False, 'already override'

    if not getattr(id_block, 'library', None):

        return False, 'not linked'



    api_create = getattr(id_block, 'override_hierarchy_create', None)

    if callable(api_create):

        try:

            api_create(context.scene, context.view_layer)

            return True, ''

        except Exception as ex:

            last_error = str(ex)

    else:

        last_error = 'api unavailable'



    if not isinstance(id_block, bpy.types.Object):

        return False, last_error



    op = getattr(getattr(bpy.ops, 'object', None), 'make_override_library', None)

    if op is None:

        return False, last_error if last_error and last_error != 'api unavailable' else 'operator unavailable'



    prev_selected = list(getattr(context, 'selected_objects', []) or [])

    prev_active = getattr(context.view_layer.objects, 'active', None)

    try:

        for item in prev_selected:

            try:

                item.select_set(False)

            except Exception:

                pass

        try:

            id_block.select_set(True)

        except Exception:

            return False, 'selection failed'

        try:

            context.view_layer.objects.active = id_block

        except Exception:

            pass

        try:

            with context.temp_override(

                scene=context.scene,

                view_layer=context.view_layer,

                active_object=id_block,

                object=id_block,

                selected_objects=[id_block],

                selected_editable_objects=[id_block],

            ):

                if op.poll():

                    op()

                    return True, ''

        except Exception as ex:

            last_error = str(ex)

        else:

            last_error = 'poll failed'

        try:

            if op.poll():

                op()

                return True, ''

        except Exception as ex:

            last_error = str(ex)

        return False, last_error

    finally:

        _rm_restore_selection_state(context, prev_selected, prev_active)





def _rm_make_override_for_object(context, obj) -> tuple[bool, str]:

    return _rm_make_override_for_id(context, obj)





def _rm_collect_override_targets_from_selection(context):

    try:

        selected = list(context.selected_objects or [])

    except Exception:

        selected = []

    targets = []

    seen = set()

    for obj in selected:

        try:

            if not obj or not isinstance(obj, bpy.types.Object):

                continue

            if getattr(obj, 'override_library', None):

                continue

            if not getattr(obj, 'library', None):

                continue

            preferred = []

            for col in list(getattr(obj, 'users_collection', []) or []):

                try:

                    if not isinstance(col, bpy.types.Collection):

                        continue

                    if not getattr(col, 'library', None):

                        continue

                    if getattr(col, 'override_library', None):

                        continue

                    preferred.append(col)

                except Exception:

                    continue

            chosen = preferred[0] if preferred else obj

            key = _rm_override_target_key(chosen)

            if key in seen:

                continue

            seen.add(key)

            targets.append(chosen)

        except Exception:

            continue

    return targets









def _rm_collect_override_ids_from_selection(context):

    try:

        selected = list(context.selected_objects or [])

    except Exception:

        selected = []

    out = []

    seen = set()



    def _add(id_block):

        try:

            if not id_block or not getattr(id_block, 'override_library', None):

                return

            key = _rm_override_target_key(id_block)

            if key in seen:

                return

            seen.add(key)

            out.append(id_block)

        except Exception:

            return



    for obj in selected:

        try:

            _add(obj)

            _add(getattr(obj, 'data', None))

            anim = getattr(obj, 'animation_data', None)

            if anim:

                _add(getattr(anim, 'action', None))

            inst = getattr(obj, 'instance_collection', None)

            if inst:

                _add(inst)

            for slot in list(getattr(obj, 'material_slots', []) or []):

                _add(getattr(slot, 'material', None))

            for mod in list(getattr(obj, 'modifiers', []) or []):

                _add(getattr(mod, 'node_group', None))

            for coll in list(getattr(obj, 'users_collection', []) or []):

                _add(coll)

        except Exception:

            continue

    return out





def _rm_iter_override_ids_all():

    out = []

    seen = set()

    data = getattr(bpy, 'data', None)

    if data is None:

        return out

    for attr in dir(data):

        if attr.startswith('_'):

            continue

        try:

            coll = getattr(data, attr)

        except Exception:

            continue

        if coll is None or isinstance(coll, (str, bytes, int, float, bool, dict, set, tuple)):

            continue

        try:

            iterator = iter(coll)

        except TypeError:

            continue

        except Exception:

            continue

        for id_block in list(iterator or []):

            try:

                if not getattr(id_block, 'override_library', None):

                    continue

                key = _rm_override_target_key(id_block)

                if key in seen:

                    continue

                seen.add(key)

                out.append(id_block)

            except Exception:

                continue

    return out





def _rm_override_issue_severity(code: str) -> str:

    code = str(code or '').strip().lower()

    if code in {'missing_source_library', 'missing_reference_library', 'missing_override_reference'}:

        return 'BLOCKER'

    if code in {'missing_hierarchy_root', 'mixed_root_library'}:

        return 'WARN'

    return 'INFO'





_RM_OVERRIDE_ISSUE_LABELS = {

    'missing_source_library': 'Missing Source Library',

    'missing_reference_library': 'Missing Reference Library',

    'missing_override_reference': 'Missing Override Reference',

    'missing_hierarchy_root': 'Missing Hierarchy Root',

    'mixed_root_library': 'Mixed Root Library',

}





def _rm_override_issue_label(code: str) -> str:

    return _t(_RM_OVERRIDE_ISSUE_LABELS.get(str(code or '').strip().lower(), str(code or '').replace('_', '').title()))







def _rm_override_health_payload(context, *, scope: str = 'ALL') -> dict:

    scope = str(scope or 'ALL').upper()

    ids = _rm_collect_override_ids_from_selection(context) if scope == 'SELECTED' else _rm_iter_override_ids_all()

    rows = []

    blocker_count = 0

    warning_count = 0

    type_counts = {}

    library_counts = {}

    for id_block in ids:

        try:

            ov = getattr(id_block, 'override_library', None)

            if not ov:

                continue

            ref = getattr(ov, 'reference', None)

            root = getattr(ov, 'hierarchy_root', None)

            root_ref = getattr(getattr(root, 'override_library', None), 'reference', None) if root else None

            lib = getattr(ref, 'library', None) if ref else None

            root_lib = getattr(root_ref, 'library', None) if root_ref else None

            lib_path = _norm_path(getattr(lib, 'filepath', '') or '')

            root_lib_path = _norm_path(getattr(root_lib, 'filepath', '') or '')

            issues = []

            if ref is None:

                issues.append('missing_override_reference')

            elif lib is None:

                issues.append('missing_reference_library')

            elif lib_path and (not os.path.isfile(lib_path)):

                issues.append('missing_source_library')

            if root is None:

                issues.append('missing_hierarchy_root')

            elif root_lib_path and lib_path and root_lib_path != lib_path:

                issues.append('mixed_root_library')

            severities = [_rm_override_issue_severity(code) for code in issues]

            status = 'BLOCKER' if 'BLOCKER' in severities else ('WARN' if 'WARN' in severities else 'OK')

            if status == 'BLOCKER':

                blocker_count += 1

            elif status == 'WARN':

                warning_count += 1

            type_name = getattr(getattr(id_block, 'bl_rna', None), 'name', '') or type(id_block).__name__

            type_counts[type_name] = int(type_counts.get(type_name, 0) or 0) + 1

            lib_key = lib_path or _t('No linked library')

            library_counts[lib_key] = int(library_counts.get(lib_key, 0) or 0) + 1

            rows.append({

                'name': str(getattr(id_block, 'name_full', '') or getattr(id_block, 'name', '') or ''),

                'type': str(type_name),

                'root_name': str(getattr(root, 'name_full', '') or getattr(root, 'name', '') or ''),

                'library_path': lib_path,

                'root_library_path': root_lib_path,

                'issues': issues,

                'status': status,

            })

        except Exception:

            continue

    rows.sort(key=lambda row: ({'BLOCKER': 0, 'WARN': 1, 'OK': 2}.get(str(row.get('status', 'OK')), 3), str(row.get('type', '')), str(row.get('name', ''))))

    type_rows = [{'label': key, 'count': value} for key, value in sorted(type_counts.items(), key=lambda item: (-item[1], item[0]))]

    library_rows = [{'path': key, 'count': value} for key, value in sorted(library_counts.items(), key=lambda item: (-item[1], item[0]))]

    warnings = []

    if not rows:

        warnings.append(_t('No library overrides were found in the scanned scope'))

    if scope == 'SELECTED' and not list(getattr(context, 'selected_objects', []) or []):

        warnings.append(_t('Nothing was selected, so the selected-only override audit is empty'))

    return {

        'current_blend': _norm_path(bpy.data.filepath or ''),

        'scope': scope,

        'summary': {

            'total_overrides': len(rows),

            'blockers': blocker_count,

            'warnings': warning_count,

            'ok': max(0, len(rows) - blocker_count - warning_count),

        },

        'type_rows': type_rows,

        'library_rows': library_rows,

        'rows': rows,

        'warnings': warnings,

    }







def _rm_override_health_report_lines(title: str, payload: dict) -> list[str]:

    summary = dict((payload or {}).get('summary') or {})

    rows = list((payload or {}).get('rows') or [])

    type_rows = list((payload or {}).get('type_rows') or [])

    library_rows = list((payload or {}).get('library_rows') or [])

    lines = [

        f"Smart File | {title} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        f"- {_t('Current File')}: {_norm_path(str((payload or {}).get('current_blend', '') or '')) or _t('Unsaved current file')}",

        f"- {_t('Scope')}: {_t('Selected') if str((payload or {}).get('scope', 'ALL')).upper() == 'SELECTED' else _t('All')}",

        f"- {_t('Total Overrides')}: {int(summary.get('total_overrides', 0) or 0)}",

        f"- {_t('Blockers')}: {int(summary.get('blockers', 0) or 0)}",

        f"- {_t('Warnings')}: {int(summary.get('warnings', 0) or 0)}",

        f"- {_t('OK')}: {int(summary.get('ok', 0) or 0)}",

    ]

    warnings = list((payload or {}).get('warnings') or [])

    if warnings:

        lines.extend(['', 'WARNINGS'])

        for row in warnings:

            lines.append(f"- {row}")

    if type_rows:

        lines.extend(['', 'BY TYPE'])

        for row in type_rows[:24]:

            lines.append(f"- {row.get('label','')} | {int(row.get('count', 0) or 0)}")

    if library_rows:

        lines.extend(['', 'BY SOURCE LIBRARY'])

        for row in library_rows[:24]:

            lines.append(f"- {row.get('path','')} | {int(row.get('count', 0) or 0)}")

    if rows:

        lines.extend(['', 'OVERRIDE DETAILS'])

        for row in rows[:200]:

            issue_labels = ','.join(_rm_override_issue_label(code) for code in list(row.get('issues') or [])) or _t('Healthy')

            lines.append(f"- [{row.get('status','OK')}] {row.get('type','')} | {row.get('name','')} | {issue_labels}")

            if row.get('root_name'):

                lines.append(f"  - {_t('Hierarchy Root')}: {row.get('root_name','')}")

            if row.get('library_path'):

                lines.append(f"  - {_t('Source Library')}: {row.get('library_path','')}")

            if row.get('root_library_path') and row.get('root_library_path') != row.get('library_path'):

                lines.append(f"  - {_t('Root Library')}: {row.get('root_library_path','')}")

    else:

        lines.extend(['', f"- {_t('No library overrides were found in the scanned scope')}"])

    return lines



def _rm_collect_resync_targets_from_selection(context):

    try:

        selected = list(context.selected_objects or [])

    except Exception:

        selected = []

    groups = {}

    order = []

    for obj in selected:

        try:

            if not obj or not isinstance(obj, bpy.types.Object):

                continue

            ov = getattr(obj, 'override_library', None)

            if not ov:

                continue

            hierarchy_root = getattr(ov, 'hierarchy_root', None)

            key = _rm_override_target_key(hierarchy_root or obj)

            if key in groups:

                continue

            groups[key] = obj

            order.append(key)

        except Exception:

            continue

    return [groups[key] for key in order]





def _rm_resync_override_for_object(context, obj) -> tuple[bool, str]:

    # Blender 5.1 has no object-level resync operator; the RNA call is the public API.

    override = getattr(obj, 'override_library', None)

    if override is None:

        return False, 'not a library override'

    try:

        if override.resync(context.scene, view_layer=context.view_layer):

            return True, ''

        return False, 'resync returned false'

    except Exception as ex:

        return False, str(ex)





class SF_OT_override_manager_make_overrides_for_selected_linked(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_ovr_make_selected_linked'

    bl_label = 'Make Overrides for Selected Linked'

    bl_description = 'Create local Library Overrides for the currently selected linked objects when editing is needed'

    bl_options = {'UNDO'}



    def execute(self, context):

        made = 0

        failed = 0

        linked_targets = _rm_collect_override_targets_from_selection(context)

        if not linked_targets:

            self.report({'WARNING'}, _tr('No linked objects selected'))

            return {'CANCELLED'}

        for target in linked_targets:

            ok, _msg = _rm_make_override_for_id(context, target)

            if ok:

                made += 1

            else:

                failed += 1

        level = {'INFO'} if failed == 0 else {'WARNING'}

        self.report(level, f"{_tr('Overrides')}: {made} | {_tr('Failed')}: {failed}")

        return {'FINISHED'}





class SF_OT_override_manager_resync_overrides(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_resync_overrides'

    bl_label = 'Resync Overrides'

    bl_description = 'Resynchronize existing Library Overrides so they match their latest linked source state'

    bl_options = {'UNDO'}



    def execute(self, context):

        override_targets = _rm_collect_resync_targets_from_selection(context)

        if not override_targets:

            self.report({'WARNING'}, _tr('No override-capable objects selected'))

            return {'CANCELLED'}

        ok = 0

        failed = 0

        for obj in override_targets:

            success, _msg = _rm_resync_override_for_object(context, obj)

            if success:

                ok += 1

            else:

                failed += 1

        level = {'INFO'} if failed == 0 else {'WARNING'}

        self.report(level, f"{_tr('Resync attempted')}: {ok} | {_tr('Failed')}: {failed}")

        return {'FINISHED'}







class SF_OT_override_manager_audit(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_audit'

    bl_label = 'Audit'

    bl_description = 'Inspect Library Overrides for missing source libraries, missing hierarchy roots, and mixed source'

    bl_options = {'UNDO'}



    scope: EnumProperty(

        name='Scope',

        items=[

            ('ALL', 'All', 'Scan all Library Overrides in the current file.'),

            ('SELECTED', 'Selected', 'Only scan the selected objects and their directly related override data.'),

        ],

        default='ALL',

    )

    open_text: BoolProperty(name='Open report', default=True)



    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self, width=560)



    def draw(self, context):

        layout = self.layout

        layout.use_property_split = True

        layout.use_property_decorate = False

        layout.prop(self, 'scope')

        layout.prop(self, 'open_text')



    def execute(self, context):

        payload = _rm_override_health_payload(context, scope=self.scope)

        title = _t('Override Health Audit')

        text_name = _sf_report_export(

            context,

            title,

            _rm_override_health_report_lines(title, payload),

            open_text=self.open_text,

            activity_title=_t('Exported override health audit'),

        )

        summary = dict(payload.get('summary') or {})

        blockers = int(summary.get('blockers', 0) or 0)

        warnings = int(summary.get('warnings', 0) or 0)

        if blockers or warnings:

            self.report({'WARNING'}, f"{_t('Override audit exported')}: {text_name}")

        else:

            self.report({'INFO'}, f"{_t('Override audit exported')}: {text_name}")

        return {'FINISHED'}







def _rm_auto_runtime_enabled(prefs) -> bool:

    return bool(prefs and (getattr(prefs, 'rm_auto_check_on_load', False) or getattr(prefs, 'rm_auto_periodic', False)))





def _rm_namespace():

    try:

        value = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)

        return value if isinstance(value, dict) else None

    except Exception:

        return None





def _rm_ledger():

    namespace = _rm_namespace()

    value = namespace.get(_RM_OWNER_KEY) if namespace is not None else None

    return value if isinstance(value, dict) else None





def _rm_is_current_generation() -> bool:

    ledger = _rm_ledger()

    return bool(

        isinstance(ledger, dict)

        and ledger.get('token') is _RM_OWNER_TOKEN

        and ledger.get('generation') == _RM_OWNER_GENERATION

    )





def _rm_remove_exact_handler() -> bool:

    global _RM_HANDLER_RECORD

    record = _RM_HANDLER_RECORD

    ok = True

    if isinstance(record, dict):

        seq = record.get('handler_list')

        callback = record.get('callback')

        if (

            record.get('token') is not _RM_OWNER_TOKEN

            or record.get('generation') != _RM_OWNER_GENERATION

        ):

            return False

        try:

            while seq is not None and any(item is callback for item in tuple(seq)):

                seq.remove(callback)

            if seq is not None and any(item is callback for item in tuple(seq)):

                ok = False

        except Exception:

            ok = False

    _RM_HANDLER_RECORD = None

    ledger = _rm_ledger()

    if isinstance(ledger, dict):

        ledger['handler'] = None

    return ok





def _rm_cancel_exact_timer() -> bool:

    global _RM_TIMER_RECORD, _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE

    record = _RM_TIMER_RECORD

    ok = True

    if isinstance(record, dict):

        callback = record.get('callback')

        if (

            record.get('token') is not _RM_OWNER_TOKEN

            or record.get('generation') != _RM_OWNER_GENERATION

        ):

            return False

        timers = getattr(getattr(bpy, 'app', None), 'timers', None)

        checker = getattr(timers, 'is_registered', None) if timers is not None else None

        try:

            if timers is not None and callable(callback) and (not callable(checker) or checker(callback)):

                timers.unregister(callback)

        except Exception:

            try:

                if callable(checker) and checker(callback):

                    ok = False

            except Exception:

                ok = False

    _RM_TIMER_RECORD = None

    _RM_AUTO_SCHEDULED = False

    _RM_TIMER_ACTIVE = False

    ledger = _rm_ledger()

    if isinstance(ledger, dict):

        ledger['timer'] = None

    return ok





def _rm_cleanup_generation(token=None, generation=None) -> bool:

    if token is not None and token is not _RM_OWNER_TOKEN:

        return False

    if generation is not None and generation != _RM_OWNER_GENERATION:

        return False

    ok = _rm_cancel_exact_timer()

    if not _rm_remove_exact_handler():

        ok = False

    namespace = _rm_namespace()

    if namespace is not None:

        ledger = namespace.get(_RM_OWNER_KEY)

        if isinstance(ledger, dict) and ledger.get('token') is _RM_OWNER_TOKEN:

            namespace.pop(_RM_OWNER_KEY, None)

    return ok





def _rm_cleanup_previous(ledger) -> bool:

    if not isinstance(ledger, dict):

        return True

    cleanup = ledger.get('cleanup')

    if not callable(cleanup):

        return False

    try:

        try:

            return bool(cleanup(ledger.get('token'), ledger.get('generation')))

        except TypeError:

            return bool(cleanup())

    except Exception:

        return False





def _rm_install_owner() -> bool:

    global _RM_LAST_RUNTIME_ERROR

    namespace = _rm_namespace()

    if namespace is None:

        _RM_LAST_RUNTIME_ERROR = 'bpy.app.driver_namespace is unavailable'

        return False

    for key in _RM_LEGACY_OWNER_KEYS:

        previous = namespace.get(key)

        if previous is not None:

            if not _rm_cleanup_previous(previous):

                _RM_LAST_RUNTIME_ERROR = f'previous Reference Manager owner cleanup failed: {key}'

                return False

            namespace.pop(key, None)

    previous = namespace.get(_RM_OWNER_KEY)

    if isinstance(previous, dict) and not (

        previous.get('token') is _RM_OWNER_TOKEN

        and previous.get('generation') == _RM_OWNER_GENERATION

    ):

        if not _rm_cleanup_previous(previous):

            _RM_LAST_RUNTIME_ERROR = 'previous Reference Manager generation cleanup failed'

            return False

    namespace[_RM_OWNER_KEY] = {

        'token': _RM_OWNER_TOKEN,

        'generation': _RM_OWNER_GENERATION,

        'handler': _RM_HANDLER_RECORD,

        'timer': _RM_TIMER_RECORD,

        'cleanup': _rm_cleanup_generation,

    }

    _RM_LAST_RUNTIME_ERROR = ''

    return True





def _rm_auto_check_timer():

    """Perform one Reference Manager check and return the next requested delay."""

    global _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE

    _RM_AUTO_SCHEDULED = False

    # Old/reloaded callbacks and an OFF feature terminate before touching

    # context, linked libraries, files, or any scene-wide list.

    if not _rm_is_current_generation():

        _RM_TIMER_ACTIVE = False

        return None

    try:

        ctx = bpy.context

        prefs = _addon_prefs(ctx)

        if not _rm_auto_runtime_enabled(prefs):

            _RM_TIMER_ACTIVE = False

            return None

        _rm_refresh_list(ctx)

        updated, missing = _rm_check_updates(ctx, silent=True)

        if (updated or missing) and getattr(prefs, 'rm_auto_popup_on_updates', False):

            try:

                _sf_call_menu_direct('SF_MT_reference_manager_reference_manager_notice', context=ctx)

            except Exception:

                pass

        if getattr(prefs, 'rm_auto_periodic', False):

            try:

                interval_min = max(1, min(240, int(getattr(prefs, 'rm_auto_interval_min', 10) or 10)))

            except Exception:

                interval_min = 10

            return float(interval_min * 60.0)

        _RM_TIMER_ACTIVE = False

        return None

    except Exception:

        _RM_TIMER_ACTIVE = False

        return None





def _sf_rm_remove_load_post_handler():

    return _rm_remove_exact_handler()





def _sf_rm_add_load_post_handler():

    global _RM_HANDLER_RECORD, _RM_LAST_RUNTIME_ERROR

    if not _rm_install_owner():

        return False

    seq = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None), 'load_post', None)

    callback = _sf_rm_on_load_post

    if seq is None:

        _RM_LAST_RUNTIME_ERROR = 'bpy.app.handlers.load_post is unavailable'

        return False

    try:

        while any(item is callback for item in tuple(seq)):

            seq.remove(callback)

        seq.append(callback)

        if sum(1 for item in tuple(seq) if item is callback) != 1:

            raise RuntimeError('load_post exact-count validation failed')

        _RM_HANDLER_RECORD = {

            'handler_list': seq,

            'callback': callback,

            'token': _RM_OWNER_TOKEN,

            'generation': _RM_OWNER_GENERATION,

            'remover': _rm_remove_exact_handler,

        }

        ledger = _rm_ledger()

        if isinstance(ledger, dict):

            ledger['handler'] = _RM_HANDLER_RECORD

        _RM_LAST_RUNTIME_ERROR = ''

        return True

    except Exception as exc:

        _RM_LAST_RUNTIME_ERROR = f'{type(exc).__name__}: {exc}'

        _rm_remove_exact_handler()

        return False





def _sf_rm_sync_runtime_state(context=None, *, run_immediately: bool = False):

    global _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE

    prefs = _addon_prefs(context or bpy.context)

    enabled = _rm_auto_runtime_enabled(prefs)

    if not enabled:

        # Disabled means no handler, timer, or owner receipt.  Clean only exact

        # Smart File generations recorded in driver_namespace; never publish a

        # fresh owner merely to prove that an optional feature is OFF.

        namespace = _rm_namespace()

        if namespace is not None:

            for key in _RM_LEGACY_OWNER_KEYS:

                previous = namespace.get(key)

                if previous is not None:

                    if not _rm_cleanup_previous(previous):

                        return False

                    namespace.pop(key, None)

            previous = namespace.get(_RM_OWNER_KEY)

            if isinstance(previous, dict) and previous.get('token') is not _RM_OWNER_TOKEN:

                if not _rm_cleanup_previous(previous):

                    return False

                namespace.pop(_RM_OWNER_KEY, None)

        ok = _rm_cleanup_generation()

        _RM_AUTO_SCHEDULED = False

        _RM_TIMER_ACTIVE = False

        return bool(ok)

    if not _rm_install_owner():

        return False

    if not _sf_rm_add_load_post_handler():

        return False

    if not getattr(prefs, 'rm_auto_periodic', False) and not run_immediately:

        if not _rm_cancel_exact_timer():

            return False

    if run_immediately:

        return bool(_rm_schedule_auto_check())

    return True





def _rm_schedule_auto_check(delay: float = 1.5):

    global _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE, _RM_TIMER_RECORD, _RM_LAST_RUNTIME_ERROR

    if not _rm_install_owner():

        return False

    if isinstance(_RM_TIMER_RECORD, dict):

        callback = _RM_TIMER_RECORD.get('callback')

        checker = getattr(getattr(getattr(bpy, 'app', None), 'timers', None), 'is_registered', None)

        try:

            if callable(checker) and checker(callback):

                return True

        except Exception:

            pass

        _RM_TIMER_RECORD = None

    token = _RM_OWNER_TOKEN

    generation = _RM_OWNER_GENERATION



    def one_shot_callback():

        global _RM_TIMER_RECORD, _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE

        ledger = _rm_ledger()

        record = ledger.get('timer') if isinstance(ledger, dict) else None

        if not (

            _rm_is_current_generation()

            and isinstance(record, dict)

            and record.get('callback') is one_shot_callback

            and record.get('token') is token

            and record.get('generation') == generation

        ):

            return None

        _RM_TIMER_RECORD = None

        _RM_AUTO_SCHEDULED = False

        _RM_TIMER_ACTIVE = False

        if isinstance(ledger, dict):

            ledger['timer'] = None

        next_delay = _rm_auto_check_timer()

        if next_delay is not None and _rm_is_current_generation():

            _rm_schedule_auto_check(float(next_delay))

        return None



    one_shot_callback.__name__ = f'_sfs_reference_check_{generation}'

    timers = getattr(getattr(bpy, 'app', None), 'timers', None)

    if timers is None:

        _RM_LAST_RUNTIME_ERROR = 'bpy.app.timers is unavailable'

        return False

    try:

        timers.register(one_shot_callback, first_interval=max(1.0, float(delay)), persistent=False)

        checker = getattr(timers, 'is_registered', None)

        if callable(checker) and not checker(one_shot_callback):

            raise RuntimeError('Reference Manager timer identity was not retained')

        _RM_TIMER_RECORD = {

            'callback': one_shot_callback,

            'token': token,

            'generation': generation,

            'wake_delay': max(1.0, float(delay)),

            'one_shot': True,

            'remover': _rm_cancel_exact_timer,

        }

        _RM_AUTO_SCHEDULED = True

        _RM_TIMER_ACTIVE = True

        ledger = _rm_ledger()

        if isinstance(ledger, dict):

            ledger['timer'] = _RM_TIMER_RECORD

        _RM_LAST_RUNTIME_ERROR = ''

        return True

    except Exception as exc:

        _RM_TIMER_RECORD = None

        _RM_AUTO_SCHEDULED = False

        _RM_TIMER_ACTIVE = False

        _RM_LAST_RUNTIME_ERROR = f'{type(exc).__name__}: {exc}'

        ledger = _rm_ledger()

        if isinstance(ledger, dict):

            ledger['timer'] = None

        return False





@bpy.app.handlers.persistent

def _sf_rm_on_load_post(_dummy):

    if not _rm_is_current_generation():

        return

    try:

        prefs = _addon_prefs(bpy.context)

        if _rm_auto_runtime_enabled(prefs):

            _rm_schedule_auto_check()

    except Exception:

        return





def _sf_unique_catalog_asset_key(assets: dict, base_key: str) -> str:

    base_key = str(base_key or '').strip() or 'Asset'

    if base_key not in assets:

        return base_key

    n = 2

    while True:

        cand = f"{base_key}__{n}"

        if cand not in assets:

            return cand

        n += 1





def _sf_catalog_entry_identity(entry: dict, catalog_dir: str) -> tuple[str, int]:

    entry = entry or {}

    blend_rel = str(entry.get('blend') or '').strip()

    if blend_rel:

        blend_abs = _norm_path(os.path.join(catalog_dir, blend_rel))

    else:

        blend_abs = ''

    try:

        ver = int(entry.get('version', 0) or 0)

    except Exception:

        ver = 0

    return (blend_abs.lower(), ver)





def _sf_catalog_identity_token(identity) -> str:

    return json.dumps([str(identity[0]), int(identity[1])], ensure_ascii=False)





def _sf_catalog_identity_from_token(token) -> tuple[str, int]:

    if not token:

        return ('', 0)

    blend_abs, ver = json.loads(str(token))

    return (str(blend_abs), int(ver))





def _sf_build_catalog_draft_payload_for_root(prefs, root_path: str, catalog_filename: str, only_orphans: bool = True, category_mode: str = 'RELATIVE_FOLDER', infer_preview: bool = True, infer_meta: bool = True) -> tuple[dict, list[str], str]:

    default_category = getattr(prefs, 'pub_default_category', '') if prefs else ''

    referenced = _sf_collect_root_catalog_references(root_path, catalog_filename)

    all_blends = sorted({_norm_path(fp) for fp in _iter_blend_files_under(root_path)})

    selected = [fp for fp in all_blends if (fp not in referenced)] if only_orphans else list(all_blends)



    target_catalog_path = _norm_path(os.path.join(root_path, _safe_filename(catalog_filename) or 'catalog.json'))

    target_catalog_dir = os.path.dirname(target_catalog_path)

    payload = {'assets': {}, '_meta': {

        'root_path': root_path,

        'target_catalog_path': target_catalog_path,

        'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),

        'only_orphans': bool(only_orphans),

        'category_mode': category_mode,

    }}

    used_asset_keys = {}



    for blend_fp in selected:

        stem = os.path.splitext(os.path.basename(blend_fp))[0]

        asset_key_base = stem or 'Asset'

        n = used_asset_keys.get(asset_key_base.lower(), 0)

        used_asset_keys[asset_key_base.lower()] = n + 1

        asset_key = asset_key_base if n == 0 else f"{asset_key_base}__{n+1}"

        ver = _sf_guess_version_from_blend(blend_fp)

        category = _sf_guess_draft_category(root_path, blend_fp, category_mode, default_category)

        preview_abs = _sf_guess_preview_sidecar(blend_fp) if infer_preview else ''

        meta_abs = _sf_guess_meta_sidecar(blend_fp) if infer_meta else ''

        entry = {

            'version': ver,

            'blend': _sf_relpath_posix(blend_fp, target_catalog_dir),

            'preview': _sf_relpath_posix(preview_abs, target_catalog_dir) if preview_abs else '',

            'meta': _sf_relpath_posix(meta_abs, target_catalog_dir) if meta_abs else '',

            'published_at': '',

            'category': category or '',

            'tags': [],

            'draft_source': 'orphan_blend' if only_orphans else 'library_scan',

        }

        payload['assets'][asset_key] = {

            'asset_id': _sf_make_catalog_draft_asset_id(prefs, asset_key, root_path, blend_fp),

            'latest': ver,

            'entries': [entry],

        }



    return payload, selected, target_catalog_path





def _sf_merge_catalog_draft(context,

                            include_disabled: bool = False,

                            only_orphans: bool = True,

                            category_mode: str = 'RELATIVE_FOLDER',

                            infer_preview: bool = True,

                            infer_meta: bool = True,

                            apply_changes: bool = False,

                            create_backup: bool = True,

                            list_limit: int = 40,

                            merge_new_assets: bool = True,

                            merge_new_entries: bool = True,

                            fill_missing_metadata: bool = True,

                            allow_asset_key_rename: bool = True,

                            report_title: str = 'Merge Catalog Draft',

                            report_prefix: str = 'smart_file_suite_Catalog_Merge') -> dict:

    prefs = _addon_prefs(context)

    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'



    root_rows = []

    roots_src = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    for idx, r in enumerate(roots_src):

        path = _norm_path(getattr(r, 'path', '') or '')

        enabled = bool(getattr(r, 'enabled', True))

        exists = bool(path and os.path.isdir(path))

        if not path or not exists:

            continue

        if (not include_disabled) and (not enabled):

            continue

        root_rows.append({'index': idx, 'path': path, 'enabled': enabled, 'priority': int(getattr(r, 'priority', 0) or 0)})



    timestamp = datetime.datetime.now()

    stamp = timestamp.strftime('%Y%m%d_%H%M%S')

    total_root_drafts = 0

    total_inserted_assets = 0

    total_inserted_entries = 0

    total_skipped_duplicates = 0

    total_renamed_keys = 0

    total_files_written = 0

    total_metadata_fills = 0

    total_filtered_assets = 0

    total_filtered_entries = 0

    total_key_conflicts = 0

    preview_text_names = []

    report_lines = [

        f"{_t(report_title)} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        _ui_text(f"Apply changes: {bool(apply_changes)}", f'変更の適用：{"オン" if apply_changes else "オフ"}'),

        _ui_text(f"Create backup: {bool(create_backup)}", f'バックアップの作成：{"オン" if create_backup else "オフ"}'),

        _ui_text(f"Only orphans: {bool(only_orphans)}", f'参照されていない物のみ：{"オン" if only_orphans else "オフ"}'),

        _ui_text(f"Category mode: {category_mode}", f'カテゴリのモード：{category_mode}'),

        _ui_text(f"Infer preview: {bool(infer_preview)} | Infer meta: {bool(infer_meta)}", f'プレビューの推測：{"オン" if infer_preview else "オフ"}｜メタの推測：{"オン" if infer_meta else "オフ"}'),

        _ui_text(f"Merge new assets: {bool(merge_new_assets)} | Merge new entries: {bool(merge_new_entries)}", f'新しいアセットの結合：{"オン" if merge_new_assets else "オフ"}｜新しい項目の結合：{"オン" if merge_new_entries else "オフ"}'),

        _ui_text(f"Fill missing metadata: {bool(fill_missing_metadata)} | Allow asset key renames: {bool(allow_asset_key_rename)}", f'不足のメタデータの補完：{"オン" if fill_missing_metadata else "オフ"}｜アセットのキーの変更：{"オン" if allow_asset_key_rename else "オフ"}'),

        '',

    ]



    text_name_seen = set()

    for row in sorted(root_rows, key=lambda it: (-int(it['priority']), os.path.basename(it['path']).lower(), it['path'].lower())):

        root_path = row['path']

        payload, selected, target_catalog_path = _sf_build_catalog_draft_payload_for_root(

            prefs,

            root_path,

            catalog_filename,

            only_orphans=only_orphans,

            category_mode=category_mode,

            infer_preview=infer_preview,

            infer_meta=infer_meta,

        )

        if not payload.get('assets'):

            continue



        target_catalog_dir = os.path.dirname(target_catalog_path)

        existing_catalog = _ar_load_catalog(target_catalog_path) if os.path.exists(target_catalog_path) else {}

        if not isinstance(existing_catalog, dict):

            existing_catalog = {}

        merged_catalog = json.loads(json.dumps(existing_catalog, ensure_ascii=False)) if existing_catalog else {}

        assets = merged_catalog.get('assets')

        if not isinstance(assets, dict):

            assets = {}

            merged_catalog['assets'] = assets



        inserted_assets = 0

        inserted_entries = 0

        skipped_duplicates = 0

        renamed_keys = 0

        metadata_fills = 0

        filtered_assets = 0

        filtered_entries = 0

        key_conflicts = 0



        for draft_key, draft_data in (payload.get('assets') or {}).items():

            if not isinstance(draft_data, dict):

                continue

            draft_asset_id = str(draft_data.get('asset_id') or '').strip()

            draft_entries = [e for e in list(draft_data.get('entries', []) or []) if isinstance(e, dict)]

            target_key = None



            if draft_asset_id:

                for existing_key, existing_data in assets.items():

                    if not isinstance(existing_data, dict):

                        continue

                    if str(existing_data.get('asset_id') or '').strip() == draft_asset_id:

                        target_key = existing_key

                        break



            if target_key is None and draft_key in assets:

                existing_data = assets.get(draft_key)

                existing_aid = str(existing_data.get('asset_id') or '').strip() if isinstance(existing_data, dict) else ''

                if (not draft_asset_id) or (not existing_aid) or existing_aid == draft_asset_id:

                    target_key = draft_key



            if target_key is None:

                target_key = draft_key

                if target_key in assets:

                    if allow_asset_key_rename:

                        new_key = _sf_unique_catalog_asset_key(assets, target_key)

                        if new_key != target_key:

                            renamed_keys += 1

                        target_key = new_key

                    else:

                        key_conflicts += 1

                        filtered_assets += 1

                        filtered_entries += len(draft_entries)

                        continue



            asset_missing = (target_key not in assets) or (not isinstance(assets.get(target_key), dict))

            if asset_missing:

                if not merge_new_assets:

                    filtered_assets += 1

                    filtered_entries += len(draft_entries)

                    continue

                assets[target_key] = {

                    'asset_id': draft_asset_id,

                    'latest': int(draft_data.get('latest', 0) or 0),

                    'entries': [],

                }

                inserted_assets += 1



            target_asset = assets[target_key]

            if draft_asset_id and not str(target_asset.get('asset_id') or '').strip():

                target_asset['asset_id'] = draft_asset_id



            existing_entries = target_asset.get('entries')

            if not isinstance(existing_entries, list):

                existing_entries = []

                target_asset['entries'] = existing_entries



            existing_index = {}

            for e in existing_entries:

                if isinstance(e, dict):

                    existing_index[_sf_catalog_entry_identity(e, target_catalog_dir)] = e



            for draft_entry in draft_entries:

                key = _sf_catalog_entry_identity(draft_entry, target_catalog_dir)

                if key in existing_index:

                    cur = existing_index[key]

                    fill_count = 0

                    if fill_missing_metadata:

                        for field in ('preview', 'meta', 'category'):

                            if (not str(cur.get(field) or '').strip()) and str(draft_entry.get(field) or '').strip():

                                cur[field] = draft_entry.get(field)

                                fill_count += 1

                        cur_tags = cur.get('tags')

                        draft_tags = draft_entry.get('tags')

                        if (not isinstance(cur_tags, list) or not cur_tags) and isinstance(draft_tags, list) and draft_tags:

                            cur['tags'] = list(draft_tags)

                            fill_count += 1

                    skipped_duplicates += 1

                    metadata_fills += fill_count

                    continue

                if not merge_new_entries:

                    filtered_entries += 1

                    continue

                new_entry = dict(draft_entry)

                if not isinstance(new_entry.get('tags'), list):

                    new_entry['tags'] = []

                existing_entries.append(new_entry)

                existing_index[key] = new_entry

                inserted_entries += 1



            try:

                target_asset['entries'] = sorted(existing_entries, key=lambda e: (int(e.get('version', 0) or 0), str(e.get('blend') or '').lower()))

            except Exception:

                pass

            try:

                target_asset['latest'] = max([int(e.get('version', 0) or 0) for e in target_asset.get('entries', []) if isinstance(e, dict)] or [int(target_asset.get('latest', 0) or 0)])

            except Exception:

                pass



        if not inserted_assets and not inserted_entries and not renamed_keys and not metadata_fills:

            if not filtered_assets and not filtered_entries and not key_conflicts:

                continue



        total_root_drafts += 1

        total_inserted_assets += inserted_assets

        total_inserted_entries += inserted_entries

        total_skipped_duplicates += skipped_duplicates

        total_renamed_keys += renamed_keys

        total_metadata_fills += metadata_fills

        total_filtered_assets += filtered_assets

        total_filtered_entries += filtered_entries

        total_key_conflicts += key_conflicts



        root_slug = _sf_slugify(os.path.basename(root_path) or f"root_{row['index']}")

        preview_text_name = f"{report_prefix}_Preview_{root_slug}.json"

        if preview_text_name in text_name_seen:

            preview_text_name = f"{report_prefix}_Preview_{root_slug}_{row['index']}.json"

        text_name_seen.add(preview_text_name)

        _sf_write_report_text(preview_text_name, json.dumps(merged_catalog, ensure_ascii=False, indent=2) + '\n')

        preview_text_names.append(preview_text_name)



        backup_path = ''

        if apply_changes:

            try:

                if create_backup and os.path.exists(target_catalog_path):

                    backup_path = target_catalog_path + f".bak_{stamp}"

                    with open(target_catalog_path, 'r', encoding='utf-8') as f:

                        old_text = f.read()

                    with open(backup_path, 'w', encoding='utf-8') as f:

                        f.write(old_text)

                os.makedirs(os.path.dirname(target_catalog_path), exist_ok=True)

                with open(target_catalog_path, 'w', encoding='utf-8') as f:

                    json.dump(merged_catalog, f, ensure_ascii=False, indent=2)

                    f.write('\n')

                total_files_written += 1

            except Exception as ex:

                report_lines.append(f"ROOT | {root_path}")

                report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

                report_lines.append(f"- ERROR: {ex}")

                report_lines.append('')

                continue



        report_lines.append(f"ROOT | {root_path}")

        report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

        report_lines.append(_ui_text(f"- Preview text: {preview_text_name}", f'- プレビューのテキスト：{preview_text_name}'))

        report_lines.append(_ui_text(f"- Candidate blends: {len(selected)}", f'- 候補の blend：{len(selected)}'))

        report_lines.append(_ui_text(f"- Inserted assets: {inserted_assets}", f'- 追加したアセット：{inserted_assets}'))

        report_lines.append(_ui_text(f"- Inserted entries: {inserted_entries}", f'- 追加した項目：{inserted_entries}'))

        report_lines.append(_ui_text(f"- Skipped duplicates: {skipped_duplicates}", f'- 飛ばした重複：{skipped_duplicates}'))

        report_lines.append(_ui_text(f"- Metadata fills: {metadata_fills}", f'- メタデータの補完：{metadata_fills}'))

        report_lines.append(_ui_text(f"- Renamed asset keys: {renamed_keys}", f'- 名前を変えたアセットのキー：{renamed_keys}'))

        report_lines.append(_ui_text(f"- Filtered assets: {filtered_assets}", f'- 絞り込んだアセット：{filtered_assets}'))

        report_lines.append(_ui_text(f"- Filtered entries: {filtered_entries}", f'- 絞り込んだ項目：{filtered_entries}'))

        report_lines.append(_ui_text(f"- Key conflicts skipped: {key_conflicts}", f'- 飛ばしたキーの衝突：{key_conflicts}'))

        report_lines.append(_ui_text(f"- Wrote file: {bool(apply_changes)}", f'- ファイルへの書き込み：{"あり" if apply_changes else "なし"}'))

        if backup_path:

            report_lines.append(f"- Backup: {backup_path}")

        sample_paths = selected[:max(1, int(list_limit))]

        for fp in sample_paths:

            report_lines.append(f"  - {_sf_relpath_posix(fp, root_path)}")

        if len(selected) > int(list_limit):

            report_lines.append(_ui_text(f"  ... and {len(selected) - int(list_limit)} more", f'  …ほかに {len(selected) - int(list_limit)} 件'))

        report_lines.append('')



    report_lines.append(f"{_t('Generated root drafts')}: {total_root_drafts}")

    report_lines.append(f"{_t('Merged entries')}: {total_inserted_entries}")

    report_lines.append(f"{_t('Skipped duplicates')}: {total_skipped_duplicates}")

    report_lines.append(f"{_t('Metadata fills')}: {total_metadata_fills}")

    report_lines.append(f"{_t('Renamed asset keys')}: {total_renamed_keys}")

    report_lines.append(f"{_t('Filtered assets')}: {total_filtered_assets}")

    report_lines.append(f"{_t('Filtered entries')}: {total_filtered_entries}")

    report_lines.append(f"{_t('Key conflicts skipped')}: {total_key_conflicts}")

    report_lines.append(f"{_t('Catalog files written')}: {total_files_written}")

    if preview_text_names:

        report_lines.append(f"{_t('Preview Text')}: {','.join(preview_text_names)}")

    report_name = _sf_write_report_text(f'{report_prefix}_Report.txt', '\n'.join(report_lines) + '\n')



    summary_lines = [

        f"{_t(report_title)} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        f"{_t('Generated root drafts')}: {total_root_drafts}",

        f"{_t('Merged entries')}: {total_inserted_entries}",

        f"{_t('Skipped duplicates')}: {total_skipped_duplicates}",

        f"{_t('Metadata fills')}: {total_metadata_fills}",

        f"{_t('Renamed asset keys')}: {total_renamed_keys}",

        f"{_t('Filtered assets')}: {total_filtered_assets}",

        f"{_t('Filtered entries')}: {total_filtered_entries}",

        f"{_t('Key conflicts skipped')}: {total_key_conflicts}",

        f"{_t('Catalog files written')}: {total_files_written}",

        f"{_t('Report Text')}: {report_name}",

    ]

    if preview_text_names:

        summary_lines.append(f"{_t('Preview Text')}: {preview_text_names[0]}" + (f" (+{len(preview_text_names)-1})" if len(preview_text_names) > 1 else ''))

    if not total_inserted_assets and not total_inserted_entries and not total_renamed_keys and not total_metadata_fills:

        summary_lines.append(_t('No merge changes detected' if report_title == 'Merge Catalog Draft' else 'No selective merge changes detected'))



    return {

        'summary': '\n'.join(summary_lines),

        'report_name': report_name,

        'preview_text_names': preview_text_names,

        'root_count': total_root_drafts,

        'inserted_assets': total_inserted_assets,

        'inserted_entries': total_inserted_entries,

        'skipped_duplicates': total_skipped_duplicates,

        'metadata_fills': total_metadata_fills,

        'renamed_keys': total_renamed_keys,

        'filtered_assets': total_filtered_assets,

        'filtered_entries': total_filtered_entries,

        'key_conflicts': total_key_conflicts,

        'files_written': total_files_written,

    }









def _sf_cm_iter_items(prefs):

    if not prefs:

        return []

    return list(getattr(prefs, 'cm_review_items', []) or [])





def _sf_cm_find_owner_prefs(item):

    try:

        prefs = _addon_prefs(bpy.context)

        if prefs:

            for candidate in _sf_cm_iter_items(prefs):

                if candidate.as_pointer() == item.as_pointer():

                    return prefs

    except Exception:

        pass

    return None





def _sf_cm_direct_children(items, parent_key: str):

    pkey = str(parent_key or '')

    out = []

    for idx, candidate in enumerate(items):

        if str(getattr(candidate, 'parent_key', '') or '') == pkey:

            out.append((idx, candidate))

    return out





def _sf_cm_descendant_indices(items, parent_key: str):

    todo = [str(parent_key or '')]

    seen = set()

    out = []

    while todo:

        current = todo.pop(0)

        for idx, candidate in _sf_cm_direct_children(items, current):

            node_key = str(getattr(candidate, 'node_key', '') or '')

            if idx in seen:

                continue

            seen.add(idx)

            out.append(idx)

            if node_key:

                todo.append(node_key)

    return out





def _sf_cm_set_item_include(item, value: bool):

    try:

        item['include'] = bool(value)

    except Exception:

        try:

            item.include = bool(value)

        except Exception:

            pass





def _sf_cm_refresh_parent_states(prefs):

    items = _sf_cm_iter_items(prefs)

    if not items:

        if prefs:

            prefs.cm_review_summary = ''

        return



    direct_enabled_counts = {}

    selected_direct_counts = {}

    node_to_item = {}

    for idx, item in enumerate(items):

        node_key = str(getattr(item, 'node_key', '') or '')

        if node_key:

            node_to_item[node_key] = (idx, item)



    for idx, item in reversed(list(enumerate(items))):

        node_key = str(getattr(item, 'node_key', '') or '')

        children = _sf_cm_direct_children(items, node_key)

        if children:

            enabled_children = [child for _cidx, child in children if bool(getattr(child, 'enabled', True))]

            selected_children = [child for child in enabled_children if bool(getattr(child, 'include', False))]

            direct_enabled_counts[node_key] = len(enabled_children)

            selected_direct_counts[node_key] = len(selected_children)

            try:

                item.enabled = bool(enabled_children)

            except Exception:

                pass

            _sf_cm_set_item_include(item, bool(selected_children))

            try:

                item.entry_count = len(enabled_children)

            except Exception:

                pass

        else:

            direct_enabled_counts[node_key] = 0

            selected_direct_counts[node_key] = 1 if bool(getattr(item, 'enabled', True)) and bool(getattr(item, 'include', False)) else 0



    total_rows = len(items)

    enabled_rows = sum(1 for item in items if bool(getattr(item, 'enabled', True)))

    selected_rows = sum(1 for item in items if bool(getattr(item, 'enabled', True)) and bool(getattr(item, 'include', False)))

    enabled_assets = sum(1 for item in items if str(getattr(item, 'level', '') or '') == 'ASSET' and bool(getattr(item, 'enabled', True)))

    selected_assets = sum(1 for item in items if str(getattr(item, 'level', '') or '') == 'ASSET' and bool(getattr(item, 'enabled', True)) and bool(getattr(item, 'include', False)))

    enabled_entries = sum(1 for item in items if str(getattr(item, 'level', '') or '') == 'ENTRY' and bool(getattr(item, 'enabled', True)))

    selected_entries = sum(1 for item in items if str(getattr(item, 'level', '') or '') == 'ENTRY' and bool(getattr(item, 'enabled', True)) and bool(getattr(item, 'include', False)))

    root_count = sum(1 for item in items if str(getattr(item, 'level', '') or '') == 'ROOT')



    if prefs:

        prefs.cm_review_summary = '\n'.join([

            _t('Catalog Merge Selection Review'),

            f"{_t('Affected roots')}: {root_count}",

            f"{_t('Selection rows')}: {total_rows}",

            f"{_t('Enabled rows')}: {enabled_rows}",

            f"{_t('Selected rows')}: {selected_rows}",

            f"Assets: {selected_assets}/{enabled_assets}",

            f"Entries: {selected_entries}/{enabled_entries}",

        ])





def _sf_cm_apply_state_from_index(prefs, index: int, enable: bool):

    items = _sf_cm_iter_items(prefs)

    if index < 0 or index >= len(items):

        return False

    target = items[index]

    if not bool(getattr(target, 'enabled', True)):

        return False



    _sf_cm_set_item_include(target, bool(enable))

    node_key = str(getattr(target, 'node_key', '') or '')

    if node_key:

        for child_idx in _sf_cm_descendant_indices(items, node_key):

            child = items[child_idx]

            if bool(getattr(child, 'enabled', True)):

                _sf_cm_set_item_include(child, bool(enable))



    _sf_cm_refresh_parent_states(prefs)

    return True





def _sf_catalog_merge_selection_sync_from_item(item):

    prefs = _sf_cm_find_owner_prefs(item)

    if not prefs:

        return

    items = _sf_cm_iter_items(prefs)

    target_index = None

    target_ptr = item.as_pointer()

    for idx, candidate in enumerate(items):

        if candidate.as_pointer() == target_ptr:

            target_index = idx

            break

    if target_index is None:

        return

    _sf_cm_apply_state_from_index(prefs, target_index, bool(getattr(item, 'include', False)))



def _sf_clear_catalog_merge_selection(prefs):

    if not prefs:

        return

    try:

        prefs.cm_review_items.clear()

    except Exception:

        pass

    prefs.cm_review_active_index = 0

    prefs.cm_review_summary = ''





def _sf_collect_catalog_merge_selection(context,

                                        include_disabled: bool = False,

                                        only_orphans: bool = True,

                                        category_mode: str = 'RELATIVE_FOLDER',

                                        infer_preview: bool = True,

                                        infer_meta: bool = True,

                                        list_limit: int = 80) -> dict:

    prefs = _addon_prefs(context)

    if not prefs:

        return {'summary': _t('No items found'), 'report_name': ''}



    _sf_clear_catalog_merge_selection(prefs)

    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json')



    root_rows = []

    for idx, r in enumerate(list(getattr(prefs, 'library_roots', []) or [])):

        path = _norm_path(getattr(r, 'path', '') or '')

        enabled = bool(getattr(r, 'enabled', True))

        exists = bool(path and os.path.isdir(path))

        if not path or not exists:

            continue

        if (not include_disabled) and (not enabled):

            continue

        root_rows.append({'index': idx, 'path': path, 'enabled': enabled, 'priority': int(getattr(r, 'priority', 0) or 0)})



    timestamp = datetime.datetime.now()

    total_rows = 0

    total_enabled_rows = 0

    root_count = 0

    total_new_assets = 0

    total_new_entries = 0

    total_metadata_fills = 0

    total_renamed_keys = 0

    review_text_names = []

    report_lines = [

        f"{_t('Catalog Merge Selection Review')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        _ui_text(f"Only orphans: {bool(only_orphans)}", f'参照されていない物のみ：{"オン" if only_orphans else "オフ"}'),

        _ui_text(f"Category mode: {category_mode}", f'カテゴリのモード：{category_mode}'),

        _ui_text(f"Infer preview: {bool(infer_preview)} | Infer meta: {bool(infer_meta)}", f'プレビューの推測：{"オン" if infer_preview else "オフ"}｜メタの推測：{"オン" if infer_meta else "オフ"}'),

        'No on-disk changes are made',

        '',

    ]



    text_name_seen = set()

    for row in sorted(root_rows, key=lambda it: (-int(it['priority']), os.path.basename(it['path']).lower(), it['path'].lower())):

        root_path = row['path']

        payload, _selected, target_catalog_path = _sf_build_catalog_draft_payload_for_root(

            prefs,

            root_path,

            catalog_filename,

            only_orphans=only_orphans,

            category_mode=category_mode,

            infer_preview=infer_preview,

            infer_meta=infer_meta,

        )

        if not payload.get('assets'):

            continue



        target_catalog_dir = os.path.dirname(target_catalog_path)

        existing_catalog = _ar_load_catalog(target_catalog_path) if os.path.exists(target_catalog_path) else {}

        if not isinstance(existing_catalog, dict):

            existing_catalog = {}

        assets = existing_catalog.get('assets')

        if not isinstance(assets, dict):

            assets = {}



        root_count += 1

        root_new_assets = 0

        root_new_entries = 0

        root_metadata_fills = 0

        root_renamed_keys = 0

        root_node_key = f"ROOT|{root_path}"

        root_summary = prefs.cm_review_items.add()

        root_summary_index = len(prefs.cm_review_items) - 1

        root_summary.include = False

        root_summary.enabled = False

        root_summary.level = 'ROOT'

        root_summary.action = 'ROOT'

        root_summary.root_path = root_path

        root_summary.target_catalog_path = target_catalog_path

        root_summary.label = os.path.basename(root_path) or root_path

        root_summary.note = _sf_relpath_posix(target_catalog_path, root_path)

        root_summary.node_key = root_node_key

        root_summary.parent_key = ''

        root_summary.depth = 0

        total_rows += 1



        sample_changes = []

        for draft_key, draft_data in (payload.get('assets') or {}).items():

            if not isinstance(draft_data, dict):

                continue

            draft_asset_id = str(draft_data.get('asset_id') or '').strip()

            draft_entries = [e for e in list(draft_data.get('entries', []) or []) if isinstance(e, dict)]

            target_key = None

            matched_by_asset_id = False



            if draft_asset_id:

                for existing_key, existing_data in assets.items():

                    if not isinstance(existing_data, dict):

                        continue

                    if str(existing_data.get('asset_id') or '').strip() == draft_asset_id:

                        target_key = existing_key

                        matched_by_asset_id = True

                        break



            if target_key is None and draft_key in assets:

                existing_data = assets.get(draft_key)

                existing_aid = str(existing_data.get('asset_id') or '').strip() if isinstance(existing_data, dict) else ''

                if (not draft_asset_id) or (not existing_aid) or existing_aid == draft_asset_id:

                    target_key = draft_key



            renamed_to = ''

            if target_key is None:

                target_key = draft_key

                if target_key in assets:

                    renamed_to = _sf_unique_catalog_asset_key(assets, target_key)

                    if renamed_to != target_key:

                        target_key = renamed_to



            asset_node_key = f"ASSET|{root_path}|{draft_key}|{target_key}"

            existing_asset = assets.get(target_key) if isinstance(assets.get(target_key), dict) else None

            if existing_asset is None:

                action = 'RENAME_ASSET_KEY' if renamed_to else 'ADD_ASSET'

                note = f"{draft_key} -> {target_key}" if renamed_to else f"{len(draft_entries)} entries"

                asset_row = prefs.cm_review_items.add()

                asset_row.include = True

                asset_row.enabled = True

                asset_row.level = 'ASSET'

                asset_row.action = action

                asset_row.root_path = root_path

                asset_row.target_catalog_path = target_catalog_path

                asset_row.draft_key = draft_key

                asset_row.target_key = target_key

                asset_row.asset_id = draft_asset_id

                asset_row.entry_count = len(draft_entries)

                asset_row.label = f"{target_key}"

                asset_row.note = note

                asset_row.draft_category = str((draft_entries[0] or {}).get('category') or '') if draft_entries and isinstance(draft_entries[0], dict) else ''

                asset_row.node_key = asset_node_key

                asset_row.parent_key = root_node_key

                asset_row.depth = 1

                asset_row.ovr_has_key_rename = bool(renamed_to)

                asset_row.ovr_allow_key_rename = True

                total_rows += 1

                total_enabled_rows += 1

                root_new_assets += 1

                total_new_assets += 1

                if renamed_to:

                    root_renamed_keys += 1

                    total_renamed_keys += 1

                sample_changes.append(f"ASSET {action}: {draft_key} -> {target_key}")

            elif matched_by_asset_id and draft_key != target_key:

                asset_row = prefs.cm_review_items.add()

                asset_row.include = False

                asset_row.enabled = False

                asset_row.level = 'ASSET'

                asset_row.action = 'MERGE_INTO_EXISTING_ASSET_ID'

                asset_row.root_path = root_path

                asset_row.target_catalog_path = target_catalog_path

                asset_row.draft_key = draft_key

                asset_row.target_key = target_key

                asset_row.asset_id = draft_asset_id

                asset_row.entry_count = len(draft_entries)

                asset_row.label = f"{draft_key} -> {target_key}"

                asset_row.note = _t('Asset ID')

                asset_row.draft_category = str((draft_entries[0] or {}).get('category') or '') if draft_entries and isinstance(draft_entries[0], dict) else ''

                asset_row.node_key = asset_node_key

                asset_row.parent_key = root_node_key

                asset_row.depth = 1

                asset_row.ovr_has_key_rename = False

                asset_row.ovr_allow_key_rename = False

                total_rows += 1



            existing_entries = existing_asset.get('entries') if isinstance(existing_asset, dict) else []

            if not isinstance(existing_entries, list):

                existing_entries = []

            existing_index = {}

            for e in existing_entries:

                if isinstance(e, dict):

                    existing_index[_sf_catalog_entry_identity(e, target_catalog_dir)] = e



            for draft_entry in draft_entries:

                ident = _sf_catalog_entry_identity(draft_entry, target_catalog_dir)

                version = int(draft_entry.get('version', 0) or 0)

                blend_rel = str(draft_entry.get('blend') or '')

                if ident in existing_index:

                    cur = existing_index[ident]

                    fillable = []

                    for field in ('preview', 'meta', 'category'):

                        if (not str(cur.get(field) or '').strip()) and str(draft_entry.get(field) or '').strip():

                            fillable.append(field)

                    cur_tags = cur.get('tags')

                    draft_tags = draft_entry.get('tags')

                    if (not isinstance(cur_tags, list) or not cur_tags) and isinstance(draft_tags, list) and draft_tags:

                        fillable.append('tags')

                    ent_row = prefs.cm_review_items.add()

                    ent_row.include = bool(fillable)

                    ent_row.enabled = bool(fillable)

                    ent_row.level = 'ENTRY'

                    ent_row.action = 'FILL_METADATA' if fillable else 'SKIP_DUPLICATE'

                    ent_row.root_path = root_path

                    ent_row.target_catalog_path = target_catalog_path

                    ent_row.draft_key = draft_key

                    ent_row.target_key = target_key

                    ent_row.asset_id = draft_asset_id

                    ent_row.entry_identity = _sf_catalog_identity_token(ident)

                    ent_row.blend = blend_rel

                    ent_row.draft_category = str(draft_entry.get('category') or '')

                    ent_row.version = version

                    ent_row.label = f"v{version} | {blend_rel}"

                    ent_row.note = ','.join(fillable) if fillable else _t('Skipped duplicates')

                    ent_row.node_key = f"ENTRY|{root_path}|{target_key}|{ident}"

                    ent_row.parent_key = asset_node_key

                    ent_row.depth = 2

                    ent_row.ovr_has_preview = 'preview' in fillable

                    ent_row.ovr_has_meta = 'meta' in fillable

                    ent_row.ovr_has_category = 'category' in fillable

                    ent_row.ovr_has_tags = 'tags' in fillable

                    ent_row.ovr_use_preview = 'preview' in fillable

                    ent_row.ovr_use_meta = 'meta' in fillable

                    ent_row.ovr_use_category = 'category' in fillable

                    ent_row.ovr_use_tags = 'tags' in fillable

                    total_rows += 1

                    if fillable:

                        total_enabled_rows += 1

                        root_metadata_fills += 1

                        total_metadata_fills += 1

                        sample_changes.append(f"FILL v{version}: {blend_rel}")

                else:

                    ent_row = prefs.cm_review_items.add()

                    ent_row.include = True

                    ent_row.enabled = True

                    ent_row.level = 'ENTRY'

                    ent_row.action = 'ADD_ENTRY'

                    ent_row.root_path = root_path

                    ent_row.target_catalog_path = target_catalog_path

                    ent_row.draft_key = draft_key

                    ent_row.target_key = target_key

                    ent_row.asset_id = draft_asset_id

                    ent_row.entry_identity = _sf_catalog_identity_token(ident)

                    ent_row.blend = blend_rel

                    ent_row.draft_category = str(draft_entry.get('category') or '')

                    ent_row.version = version

                    ent_row.label = f"v{version} | {blend_rel}"

                    ent_row.note = target_key

                    ent_row.node_key = f"ENTRY|{root_path}|{target_key}|{ident}"

                    ent_row.parent_key = asset_node_key

                    ent_row.depth = 2

                    ent_row.ovr_has_preview = bool(str(draft_entry.get('preview') or '').strip())

                    ent_row.ovr_has_meta = bool(str(draft_entry.get('meta') or '').strip())

                    ent_row.ovr_has_category = bool(str(draft_entry.get('category') or '').strip())

                    ent_row.ovr_has_tags = isinstance(draft_entry.get('tags'), list) and bool(draft_entry.get('tags'))

                    ent_row.ovr_use_preview = bool(ent_row.ovr_has_preview)

                    ent_row.ovr_use_meta = bool(ent_row.ovr_has_meta)

                    ent_row.ovr_use_category = bool(ent_row.ovr_has_category)

                    ent_row.ovr_use_tags = bool(ent_row.ovr_has_tags)

                    total_rows += 1

                    total_enabled_rows += 1

                    root_new_entries += 1

                    total_new_entries += 1

                    sample_changes.append(f"ADD v{version}: {blend_rel}")



        root_summary = prefs.cm_review_items[root_summary_index]

        root_summary.note = _ui_text(f"assets {root_new_assets} | entries {root_new_entries} | fills {root_metadata_fills} | renames {root_renamed_keys}", f'アセット {root_new_assets}｜項目 {root_new_entries}｜補完 {root_metadata_fills}｜名前の変更 {root_renamed_keys}')



        root_slug = _sf_slugify(os.path.basename(root_path) or f"root_{row['index']}")

        review_text_name = f"smart_file_suite_Catalog_Selection_Review_{root_slug}.txt"

        if review_text_name in text_name_seen:

            review_text_name = f"smart_file_suite_Catalog_Selection_Review_{root_slug}_{row['index']}.txt"

        text_name_seen.add(review_text_name)

        _sf_write_report_text(review_text_name, '\n'.join(sample_changes[:max(1, int(list_limit))]) + ('\n' if sample_changes else ''))

        review_text_names.append(review_text_name)



        report_lines.append(f"ROOT | {root_path}")

        report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

        report_lines.append(_ui_text(f"- New assets: {root_new_assets}", f'- 新しいアセット：{root_new_assets}'))

        report_lines.append(_ui_text(f"- New entries: {root_new_entries}", f'- 新しい項目：{root_new_entries}'))

        report_lines.append(_ui_text(f"- Metadata fills: {root_metadata_fills}", f'- メタデータの補完：{root_metadata_fills}'))

        report_lines.append(_ui_text(f"- Renamed asset keys: {root_renamed_keys}", f'- 名前を変えたアセットのキー：{root_renamed_keys}'))

        for ln in sample_changes[:max(1, int(list_limit))]:

            report_lines.append(f"  - {ln}")

        if len(sample_changes) > int(list_limit):

            report_lines.append(_ui_text(f"  ... and {len(sample_changes) - int(list_limit)} more", f'  …ほかに {len(sample_changes) - int(list_limit)} 件'))

        report_lines.append('')



    report_lines.append(f"{_t('Affected roots')}: {root_count}")

    report_lines.append(f"{_t('Selection rows')}: {total_rows}")

    report_lines.append(f"{_t('Enabled rows')}: {total_enabled_rows}")

    report_lines.append(f"{_t('New assets')}: {total_new_assets}")

    report_lines.append(f"{_t('New entries')}: {total_new_entries}")

    report_lines.append(f"{_t('Metadata fills')}: {total_metadata_fills}")

    report_lines.append(f"{_t('Renamed asset keys')}: {total_renamed_keys}")

    if review_text_names:

        report_lines.append(f"{_t('Selection Review Text')}: {','.join(review_text_names)}")

    report_name = _sf_write_report_text('smart_file_suite_Catalog_Selection_Review_Report.txt', '\n'.join(report_lines) + '\n')



    _sf_cm_refresh_parent_states(prefs)

    items = _sf_cm_iter_items(prefs)

    enabled_rows = sum(1 for item in items if bool(getattr(item, 'enabled', True)))

    selected_rows = sum(1 for item in items if bool(getattr(item, 'enabled', True)) and bool(getattr(item, 'include', False)))

    summary = '\n'.join([

        f"{_t('Catalog Merge Selection Review')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        f"{_t('Affected roots')}: {root_count}",

        f"{_t('Selection rows')}: {total_rows}",

        f"{_t('Enabled rows')}: {enabled_rows}",

        f"{_t('Selected rows')}: {selected_rows}",

        f"{_t('New assets')}: {total_new_assets}",

        f"{_t('New entries')}: {total_new_entries}",

        f"{_t('Metadata fills')}: {total_metadata_fills}",

        f"{_t('Renamed asset keys')}: {total_renamed_keys}",

        f"{_t('Report Text')}: {report_name}",

    ])

    prefs.cm_review_summary = summary

    return {

        'summary': summary,

        'report_name': report_name,

        'root_count': root_count,

        'row_count': total_rows,

        'enabled_rows': enabled_rows,

        'selected_rows': selected_rows,

    }





def _sf_merge_catalog_draft_selected(context,

                                     selection_items,

                                     include_disabled: bool = False,

                                     only_orphans: bool = True,

                                     category_mode: str = 'RELATIVE_FOLDER',

                                     infer_preview: bool = True,

                                     infer_meta: bool = True,

                                     apply_changes: bool = False,

                                     create_backup: bool = True,

                                     list_limit: int = 40,

                                     report_title: str = 'Apply Merge Selection',

                                     report_prefix: str = 'smart_file_suite_Catalog_Merge_Selection') -> dict:

    prefs = _addon_prefs(context)

    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'



    selected_asset_actions = {}

    selected_add_entries = {}

    selected_fill_entries = {}

    selected_count = 0

    for it in list(selection_items or []):

        if not bool(getattr(it, 'enabled', True)) or not bool(getattr(it, 'include', False)):

            continue

        selected_count += 1

        rp = _norm_path(getattr(it, 'root_path', '') or '')

        action = str(getattr(it, 'action', '') or '')

        draft_key = str(getattr(it, 'draft_key', '') or '')

        target_key = str(getattr(it, 'target_key', '') or '')

        ident = _sf_catalog_identity_from_token(getattr(it, 'entry_identity', ''))

        entry_opts = {

            'preview': bool(getattr(it, 'ovr_use_preview', False)),

            'meta': bool(getattr(it, 'ovr_use_meta', False)),

            'category': bool(getattr(it, 'ovr_use_category', False)),

            'tags': bool(getattr(it, 'ovr_use_tags', False)),

        }

        asset_opts = {

            'allow_key_rename': bool(getattr(it, 'ovr_allow_key_rename', True)),

        }

        if action in {'ADD_ASSET', 'RENAME_ASSET_KEY'}:

            selected_asset_actions[(rp, action, draft_key, target_key)] = asset_opts

        elif action == 'ADD_ENTRY':

            selected_add_entries.setdefault((rp, target_key), {})[ident] = entry_opts

        elif action == 'FILL_METADATA':

            selected_fill_entries.setdefault((rp, target_key), {})[ident] = entry_opts



    if not selected_count:

        return {

            'summary': '\n'.join([_t('Apply Merge Selection'), _t('No selection items are enabled')]),

            'report_name': '',

            'selected_rows': 0,

            'inserted_entries': 0,

            'metadata_fills': 0,

            'files_written': 0,

        }



    root_rows = []

    roots_src = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    for idx, r in enumerate(roots_src):

        path = _norm_path(getattr(r, 'path', '') or '')

        enabled = bool(getattr(r, 'enabled', True))

        exists = bool(path and os.path.isdir(path))

        if not path or not exists:

            continue

        if (not include_disabled) and (not enabled):

            continue

        root_rows.append({'index': idx, 'path': path, 'enabled': enabled, 'priority': int(getattr(r, 'priority', 0) or 0)})



    timestamp = datetime.datetime.now()

    stamp = timestamp.strftime('%Y%m%d_%H%M%S')

    total_root_drafts = 0

    total_inserted_assets = 0

    total_inserted_entries = 0

    total_skipped_duplicates = 0

    total_renamed_keys = 0

    total_files_written = 0

    total_metadata_fills = 0

    total_filtered_assets = 0

    total_filtered_entries = 0

    total_key_conflicts = 0

    preview_text_names = []

    report_lines = [

        f"{_t(report_title)} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        _ui_text(f"Apply changes: {bool(apply_changes)}", f'変更の適用：{"オン" if apply_changes else "オフ"}'),

        _ui_text(f"Create backup: {bool(create_backup)}", f'バックアップの作成：{"オン" if create_backup else "オフ"}'),

        _ui_text(f"Only orphans: {bool(only_orphans)}", f'参照されていない物のみ：{"オン" if only_orphans else "オフ"}'),

        _ui_text(f"Category mode: {category_mode}", f'カテゴリのモード：{category_mode}'),

        _ui_text(f"Infer preview: {bool(infer_preview)} | Infer meta: {bool(infer_meta)}", f'プレビューの推測：{"オン" if infer_preview else "オフ"}｜メタの推測：{"オン" if infer_meta else "オフ"}'),

        f"{_t('Selected rows')}: {selected_count}",

        '',

    ]



    text_name_seen = set()

    for row in sorted(root_rows, key=lambda it: (-int(it['priority']), os.path.basename(it['path']).lower(), it['path'].lower())):

        root_path = row['path']

        payload, selected, target_catalog_path = _sf_build_catalog_draft_payload_for_root(

            prefs,

            root_path,

            catalog_filename,

            only_orphans=only_orphans,

            category_mode=category_mode,

            infer_preview=infer_preview,

            infer_meta=infer_meta,

        )

        if not payload.get('assets'):

            continue



        target_catalog_dir = os.path.dirname(target_catalog_path)

        existing_catalog = _ar_load_catalog(target_catalog_path) if os.path.exists(target_catalog_path) else {}

        if not isinstance(existing_catalog, dict):

            existing_catalog = {}

        merged_catalog = json.loads(json.dumps(existing_catalog, ensure_ascii=False)) if existing_catalog else {}

        assets = merged_catalog.get('assets')

        if not isinstance(assets, dict):

            assets = {}

            merged_catalog['assets'] = assets



        inserted_assets = 0

        inserted_entries = 0

        skipped_duplicates = 0

        renamed_keys = 0

        metadata_fills = 0

        filtered_assets = 0

        filtered_entries = 0

        key_conflicts = 0



        for draft_key, draft_data in (payload.get('assets') or {}).items():

            if not isinstance(draft_data, dict):

                continue

            draft_asset_id = str(draft_data.get('asset_id') or '').strip()

            draft_entries = [e for e in list(draft_data.get('entries', []) or []) if isinstance(e, dict)]

            target_key = None



            if draft_asset_id:

                for existing_key, existing_data in assets.items():

                    if not isinstance(existing_data, dict):

                        continue

                    if str(existing_data.get('asset_id') or '').strip() == draft_asset_id:

                        target_key = existing_key

                        break



            if target_key is None and draft_key in assets:

                existing_data = assets.get(draft_key)

                existing_aid = str(existing_data.get('asset_id') or '').strip() if isinstance(existing_data, dict) else ''

                if (not draft_asset_id) or (not existing_aid) or existing_aid == draft_asset_id:

                    target_key = draft_key



            rename_required = False

            if target_key is None:

                target_key = draft_key

                if target_key in assets:

                    new_key = _sf_unique_catalog_asset_key(assets, target_key)

                    if new_key != target_key:

                        rename_required = True

                        target_key = new_key



            asset_missing = (target_key not in assets) or (not isinstance(assets.get(target_key), dict))

            asset_action = 'RENAME_ASSET_KEY' if rename_required else 'ADD_ASSET'



            if asset_missing:

                asset_sel = selected_asset_actions.get((root_path, asset_action, draft_key, target_key))

                if not asset_sel:

                    filtered_assets += 1

                    filtered_entries += len(draft_entries)

                    continue

                if rename_required and not bool(asset_sel.get('allow_key_rename', True)):

                    key_conflicts += 1

                    filtered_assets += 1

                    filtered_entries += len(draft_entries)

                    continue

                allowed_asset_entries = selected_add_entries.get((root_path, target_key), {})

                if not allowed_asset_entries:

                    filtered_assets += 1

                    filtered_entries += len(draft_entries)

                    continue

                assets[target_key] = {

                    'asset_id': draft_asset_id,

                    'latest': int(draft_data.get('latest', 0) or 0),

                    'entries': [],

                }

                inserted_assets += 1

                if rename_required:

                    renamed_keys += 1

            elif rename_required:

                asset_sel = selected_asset_actions.get((root_path, 'RENAME_ASSET_KEY', draft_key, target_key))

                if (not asset_sel) or (not bool(asset_sel.get('allow_key_rename', True))):

                    key_conflicts += 1

                    filtered_assets += 1

                    filtered_entries += len(draft_entries)

                    continue



            target_asset = assets[target_key]

            if draft_asset_id and not str(target_asset.get('asset_id') or '').strip():

                target_asset['asset_id'] = draft_asset_id



            existing_entries = target_asset.get('entries')

            if not isinstance(existing_entries, list):

                existing_entries = []

                target_asset['entries'] = existing_entries



            existing_index = {}

            for e in existing_entries:

                if isinstance(e, dict):

                    existing_index[_sf_catalog_entry_identity(e, target_catalog_dir)] = e



            allowed_adds = selected_add_entries.get((root_path, target_key), {})

            allowed_fills = selected_fill_entries.get((root_path, target_key), {})



            for draft_entry in draft_entries:

                key = _sf_catalog_entry_identity(draft_entry, target_catalog_dir)

                if key in existing_index:

                    cur = existing_index[key]

                    fillable_fields = []

                    for field in ('preview', 'meta', 'category'):

                        if (not str(cur.get(field) or '').strip()) and str(draft_entry.get(field) or '').strip():

                            fillable_fields.append(field)

                    cur_tags = cur.get('tags')

                    draft_tags = draft_entry.get('tags')

                    if (not isinstance(cur_tags, list) or not cur_tags) and isinstance(draft_tags, list) and draft_tags:

                        fillable_fields.append('tags')

                    fill_opts = allowed_fills.get(key)

                    if fillable_fields and fill_opts:

                        applied_fields = 0

                        for field in ('preview', 'meta', 'category'):

                            if field in fillable_fields and bool(fill_opts.get(field, False)):

                                cur[field] = draft_entry.get(field)

                                applied_fields += 1

                        if 'tags' in fillable_fields and bool(fill_opts.get('tags', False)):

                            cur['tags'] = list(draft_tags)

                            applied_fields += 1

                        if applied_fields:

                            metadata_fills += applied_fields

                        else:

                            filtered_entries += 1

                        skipped_duplicates += 1

                    else:

                        if fillable_fields:

                            filtered_entries += 1

                        skipped_duplicates += 1

                    continue

                add_opts = allowed_adds.get(key)

                if not add_opts:

                    filtered_entries += 1

                    continue

                new_entry = dict(draft_entry)

                if not bool(add_opts.get('preview', False)):

                    new_entry['preview'] = ''

                if not bool(add_opts.get('meta', False)):

                    new_entry['meta'] = ''

                if not bool(add_opts.get('category', False)):

                    new_entry['category'] = ''

                if bool(add_opts.get('tags', False)):

                    if not isinstance(new_entry.get('tags'), list):

                        new_entry['tags'] = []

                else:

                    new_entry['tags'] = []

                existing_entries.append(new_entry)

                existing_index[key] = new_entry

                inserted_entries += 1



            try:

                target_asset['entries'] = sorted(existing_entries, key=lambda e: (int(e.get('version', 0) or 0), str(e.get('blend') or '').lower()))

            except Exception:

                pass

            try:

                target_asset['latest'] = max([int(e.get('version', 0) or 0) for e in target_asset.get('entries', []) if isinstance(e, dict)] or [int(target_asset.get('latest', 0) or 0)])

            except Exception:

                pass



        if not inserted_assets and not inserted_entries and not renamed_keys and not metadata_fills and not filtered_assets and not filtered_entries and not key_conflicts:

            continue



        total_root_drafts += 1

        total_inserted_assets += inserted_assets

        total_inserted_entries += inserted_entries

        total_skipped_duplicates += skipped_duplicates

        total_renamed_keys += renamed_keys

        total_metadata_fills += metadata_fills

        total_filtered_assets += filtered_assets

        total_filtered_entries += filtered_entries

        total_key_conflicts += key_conflicts



        root_slug = _sf_slugify(os.path.basename(root_path) or f"root_{row['index']}")

        preview_text_name = f"{report_prefix}_Preview_{root_slug}.json"

        if preview_text_name in text_name_seen:

            preview_text_name = f"{report_prefix}_Preview_{root_slug}_{row['index']}.json"

        text_name_seen.add(preview_text_name)

        _sf_write_report_text(preview_text_name, json.dumps(merged_catalog, ensure_ascii=False, indent=2) + '\n')

        preview_text_names.append(preview_text_name)



        backup_path = ''

        if apply_changes:

            try:

                if create_backup and os.path.exists(target_catalog_path):

                    backup_path = target_catalog_path + f".bak_{stamp}"

                    with open(target_catalog_path, 'r', encoding='utf-8') as f:

                        old_text = f.read()

                    with open(backup_path, 'w', encoding='utf-8') as f:

                        f.write(old_text)

                os.makedirs(os.path.dirname(target_catalog_path), exist_ok=True)

                with open(target_catalog_path, 'w', encoding='utf-8') as f:

                    json.dump(merged_catalog, f, ensure_ascii=False, indent=2)

                    f.write('\n')

                total_files_written += 1

            except Exception as ex:

                report_lines.append(f"ROOT | {root_path}")

                report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

                report_lines.append(f"- ERROR: {ex}")

                report_lines.append('')

                continue



        report_lines.append(f"ROOT | {root_path}")

        report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

        report_lines.append(_ui_text(f"- Preview text: {preview_text_name}", f'- プレビューのテキスト：{preview_text_name}'))

        report_lines.append(_ui_text(f"- Candidate blends: {len(selected)}", f'- 候補の blend：{len(selected)}'))

        report_lines.append(_ui_text(f"- Inserted assets: {inserted_assets}", f'- 追加したアセット：{inserted_assets}'))

        report_lines.append(_ui_text(f"- Inserted entries: {inserted_entries}", f'- 追加した項目：{inserted_entries}'))

        report_lines.append(_ui_text(f"- Skipped duplicates: {skipped_duplicates}", f'- 飛ばした重複：{skipped_duplicates}'))

        report_lines.append(_ui_text(f"- Metadata fills: {metadata_fills}", f'- メタデータの補完：{metadata_fills}'))

        report_lines.append(_ui_text(f"- Renamed asset keys: {renamed_keys}", f'- 名前を変えたアセットのキー：{renamed_keys}'))

        report_lines.append(_ui_text(f"- Filtered assets: {filtered_assets}", f'- 絞り込んだアセット：{filtered_assets}'))

        report_lines.append(_ui_text(f"- Filtered entries: {filtered_entries}", f'- 絞り込んだ項目：{filtered_entries}'))

        report_lines.append(_ui_text(f"- Key conflicts skipped: {key_conflicts}", f'- 飛ばしたキーの衝突：{key_conflicts}'))

        report_lines.append(_ui_text(f"- Wrote file: {bool(apply_changes)}", f'- ファイルへの書き込み：{"あり" if apply_changes else "なし"}'))

        if backup_path:

            report_lines.append(f"- Backup: {backup_path}")

        sample_paths = selected[:max(1, int(list_limit))]

        for fp in sample_paths:

            report_lines.append(f"  - {_sf_relpath_posix(fp, root_path)}")

        if len(selected) > int(list_limit):

            report_lines.append(_ui_text(f"  ... and {len(selected) - int(list_limit)} more", f'  …ほかに {len(selected) - int(list_limit)} 件'))

        report_lines.append('')



    report_lines.append(f"{_t('Generated root drafts')}: {total_root_drafts}")

    report_lines.append(f"{_t('Selected rows')}: {selected_count}")

    report_lines.append(f"{_t('Merged entries')}: {total_inserted_entries}")

    report_lines.append(f"{_t('Skipped duplicates')}: {total_skipped_duplicates}")

    report_lines.append(f"{_t('Metadata fills')}: {total_metadata_fills}")

    report_lines.append(f"{_t('Renamed asset keys')}: {total_renamed_keys}")

    report_lines.append(f"{_t('Filtered assets')}: {total_filtered_assets}")

    report_lines.append(f"{_t('Filtered entries')}: {total_filtered_entries}")

    report_lines.append(f"{_t('Key conflicts skipped')}: {total_key_conflicts}")

    report_lines.append(f"{_t('Catalog files written')}: {total_files_written}")

    if preview_text_names:

        report_lines.append(f"{_t('Preview Text')}: {','.join(preview_text_names)}")

    report_name = _sf_write_report_text(f'{report_prefix}_Report.txt', '\n'.join(report_lines) + '\n')



    summary_lines = [

        f"{_t(report_title)} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        f"{_t('Selected rows')}: {selected_count}",

        f"{_t('Generated root drafts')}: {total_root_drafts}",

        f"{_t('Merged entries')}: {total_inserted_entries}",

        f"{_t('Metadata fills')}: {total_metadata_fills}",

        f"{_t('Renamed asset keys')}: {total_renamed_keys}",

        f"{_t('Filtered entries')}: {total_filtered_entries}",

        f"{_t('Catalog files written')}: {total_files_written}",

        f"{_t('Report Text')}: {report_name}",

    ]

    if preview_text_names:

        summary_lines.append(f"{_t('Preview Text')}: {preview_text_names[0]}" + (f" (+{len(preview_text_names)-1})" if len(preview_text_names) > 1 else ''))



    return {

        'summary': '\n'.join(summary_lines),

        'report_name': report_name,

        'preview_text_names': preview_text_names,

        'selected_rows': selected_count,

        'inserted_entries': total_inserted_entries,

        'metadata_fills': total_metadata_fills,

        'files_written': total_files_written,

    }





def _sf_review_catalog_merge_diff(context,

                                  include_disabled: bool = False,

                                  only_orphans: bool = True,

                                  category_mode: str = 'RELATIVE_FOLDER',

                                  infer_preview: bool = True,

                                  infer_meta: bool = True,

                                  list_limit: int = 40) -> dict:

    prefs = _addon_prefs(context)

    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'



    root_rows = []

    roots_src = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    for idx, r in enumerate(roots_src):

        path = _norm_path(getattr(r, 'path', '') or '')

        enabled = bool(getattr(r, 'enabled', True))

        exists = bool(path and os.path.isdir(path))

        if not path or not exists:

            continue

        if (not include_disabled) and (not enabled):

            continue

        root_rows.append({'index': idx, 'path': path, 'enabled': enabled, 'priority': int(getattr(r, 'priority', 0) or 0)})



    timestamp = datetime.datetime.now()

    total_roots_affected = 0

    total_new_assets = 0

    total_new_entries = 0

    total_duplicate_entries = 0

    total_renamed_keys = 0

    total_metadata_fills = 0

    review_text_names = []

    report_lines = [

        f"{_t('Review Catalog Merge')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        _ui_text(f"Only orphans: {bool(only_orphans)}", f'参照されていない物のみ：{"オン" if only_orphans else "オフ"}'),

        _ui_text(f"Category mode: {category_mode}", f'カテゴリのモード：{category_mode}'),

        _ui_text(f"Infer preview: {bool(infer_preview)} | Infer meta: {bool(infer_meta)}", f'プレビューの推測：{"オン" if infer_preview else "オフ"}｜メタの推測：{"オン" if infer_meta else "オフ"}'),

        'No on-disk changes are made',

        '',

    ]



    text_name_seen = set()

    for row in sorted(root_rows, key=lambda it: (-int(it['priority']), os.path.basename(it['path']).lower(), it['path'].lower())):

        root_path = row['path']

        payload, _selected, target_catalog_path = _sf_build_catalog_draft_payload_for_root(

            prefs,

            root_path,

            catalog_filename,

            only_orphans=only_orphans,

            category_mode=category_mode,

            infer_preview=infer_preview,

            infer_meta=infer_meta,

        )

        if not payload.get('assets'):

            continue



        target_catalog_dir = os.path.dirname(target_catalog_path)

        existing_catalog = _ar_load_catalog(target_catalog_path) if os.path.exists(target_catalog_path) else {}

        if not isinstance(existing_catalog, dict):

            existing_catalog = {}

        assets = existing_catalog.get('assets')

        if not isinstance(assets, dict):

            assets = {}



        root_new_assets = 0

        root_new_entries = 0

        root_duplicate_entries = 0

        root_renamed_keys = 0

        root_metadata_fills = 0

        sample_changes = []



        for draft_key, draft_data in (payload.get('assets') or {}).items():

            if not isinstance(draft_data, dict):

                continue

            draft_asset_id = str(draft_data.get('asset_id') or '').strip()

            target_key = None

            matched_by_asset_id = False



            if draft_asset_id:

                for existing_key, existing_data in assets.items():

                    if not isinstance(existing_data, dict):

                        continue

                    if str(existing_data.get('asset_id') or '').strip() == draft_asset_id:

                        target_key = existing_key

                        matched_by_asset_id = True

                        break



            if target_key is None and draft_key in assets:

                existing_data = assets.get(draft_key)

                existing_aid = str(existing_data.get('asset_id') or '').strip() if isinstance(existing_data, dict) else ''

                if (not draft_asset_id) or (not existing_aid) or existing_aid == draft_asset_id:

                    target_key = draft_key



            renamed_to = ''

            if target_key is None:

                target_key = draft_key

                if target_key in assets:

                    renamed_to = _sf_unique_catalog_asset_key(assets, target_key)

                    if renamed_to != target_key:

                        root_renamed_keys += 1

                        target_key = renamed_to



            existing_asset = assets.get(target_key) if isinstance(assets.get(target_key), dict) else None

            if existing_asset is None:

                root_new_assets += 1

                draft_entries = [e for e in list(draft_data.get('entries', []) or []) if isinstance(e, dict)]

                root_new_entries += len(draft_entries)

                sample_changes.append({

                    'action': 'ADD_ASSET',

                    'draft_key': draft_key,

                    'target_key': target_key,

                    'asset_id': draft_asset_id,

                    'entry_count': len(draft_entries),

                    'renamed': bool(renamed_to),

                })

                continue



            existing_entries = existing_asset.get('entries')

            if not isinstance(existing_entries, list):

                existing_entries = []

            existing_index = {}

            for e in existing_entries:

                if isinstance(e, dict):

                    existing_index[_sf_catalog_entry_identity(e, target_catalog_dir)] = e



            if matched_by_asset_id and draft_key != target_key:

                sample_changes.append({

                    'action': 'MERGE_INTO_EXISTING_ASSET_ID',

                    'draft_key': draft_key,

                    'target_key': target_key,

                    'asset_id': draft_asset_id,

                    'entry_count': len(list(draft_data.get('entries', []) or [])),

                })

            elif renamed_to:

                sample_changes.append({

                    'action': 'RENAME_ASSET_KEY',

                    'draft_key': draft_key,

                    'target_key': target_key,

                    'asset_id': draft_asset_id,

                    'entry_count': len(list(draft_data.get('entries', []) or [])),

                })



            for draft_entry in list(draft_data.get('entries', []) or []):

                if not isinstance(draft_entry, dict):

                    continue

                ident = _sf_catalog_entry_identity(draft_entry, target_catalog_dir)

                if ident in existing_index:

                    cur = existing_index[ident]

                    fill_count = 0

                    for field in ('preview', 'meta', 'category'):

                        if (not str(cur.get(field) or '').strip()) and str(draft_entry.get(field) or '').strip():

                            fill_count += 1

                    cur_tags = cur.get('tags')

                    if (not isinstance(cur_tags, list) or not cur_tags) and isinstance(draft_entry.get('tags'), list) and draft_entry.get('tags'):

                        fill_count += 1

                    root_duplicate_entries += 1

                    root_metadata_fills += fill_count

                    sample_changes.append({

                        'action': 'SKIP_DUPLICATE' if fill_count == 0 else 'FILL_METADATA',

                        'target_key': target_key,

                        'blend': draft_entry.get('blend', ''),

                        'version': int(draft_entry.get('version', 0) or 0),

                        'fill_count': fill_count,

                    })

                else:

                    root_new_entries += 1

                    sample_changes.append({

                        'action': 'ADD_ENTRY',

                        'target_key': target_key,

                        'blend': draft_entry.get('blend', ''),

                        'version': int(draft_entry.get('version', 0) or 0),

                    })



        if not any([root_new_assets, root_new_entries, root_duplicate_entries, root_renamed_keys, root_metadata_fills]):

            continue



        total_roots_affected += 1

        total_new_assets += root_new_assets

        total_new_entries += root_new_entries

        total_duplicate_entries += root_duplicate_entries

        total_renamed_keys += root_renamed_keys

        total_metadata_fills += root_metadata_fills



        root_slug = _sf_slugify(os.path.basename(root_path) or f"root_{row['index']}")

        review_text_name = f"smart_file_suite_Catalog_Diff_Review_{root_slug}.json"

        if review_text_name in text_name_seen:

            review_text_name = f"smart_file_suite_Catalog_Diff_Review_{root_slug}_{row['index']}.json"

        text_name_seen.add(review_text_name)

        review_payload = {

            'root_path': root_path,

            'target_catalog_path': target_catalog_path,

            'summary': {

                'new_assets': root_new_assets,

                'new_entries': root_new_entries,

                'duplicate_entries': root_duplicate_entries,

                'renamed_asset_keys': root_renamed_keys,

                'metadata_fills': root_metadata_fills,

            },

            'sample_changes': list(sample_changes)[:max(1, int(list_limit))],

        }

        _sf_write_report_text(review_text_name, json.dumps(review_payload, ensure_ascii=False, indent=2) + '\n')

        review_text_names.append(review_text_name)



        report_lines.append(f"ROOT | {root_path}")

        report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))

        report_lines.append(f"- {_t('Review Text')}: {review_text_name}")

        report_lines.append(f"- {_t('New assets')}: {root_new_assets}")

        report_lines.append(f"- {_t('New entries')}: {root_new_entries}")

        report_lines.append(f"- {_t('Skipped duplicates')}: {root_duplicate_entries}")

        report_lines.append(f"- {_t('Renamed asset keys')}: {root_renamed_keys}")

        report_lines.append(f"- {_t('Metadata fills')}: {root_metadata_fills}")

        for item in list(sample_changes)[:max(1, int(list_limit))]:

            action = str(item.get('action', '') or '')

            label = str(item.get('target_key', '') or item.get('draft_key', '') or 'item')

            blend = str(item.get('blend', '') or '')

            ver = item.get('version', None)

            extra = ''

            if blend:

                extra = f" | {blend}"

            elif ver is not None:

                extra = f" | v{int(ver):03d}"

            report_lines.append(f"  - {action}: {label}{extra}")

        if len(sample_changes) > int(list_limit):

            report_lines.append(_ui_text(f"  ... and {len(sample_changes) - int(list_limit)} more", f'  …ほかに {len(sample_changes) - int(list_limit)} 件'))

        report_lines.append('')



    report_lines.append(f"{_t('Affected roots')}: {total_roots_affected}")

    report_lines.append(f"{_t('New assets')}: {total_new_assets}")

    report_lines.append(f"{_t('New entries')}: {total_new_entries}")

    report_lines.append(f"{_t('Skipped duplicates')}: {total_duplicate_entries}")

    report_lines.append(f"{_t('Renamed asset keys')}: {total_renamed_keys}")

    report_lines.append(f"{_t('Metadata fills')}: {total_metadata_fills}")

    if review_text_names:

        report_lines.append(f"{_t('Review Text')}: {','.join(review_text_names)}")

    report_name = _sf_write_report_text('smart_file_suite_Catalog_Diff_Review_Report.txt', '\n'.join(report_lines) + '\n')



    summary_lines = [

        f"{_t('Review Catalog Merge')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        f"{_t('Affected roots')}: {total_roots_affected}",

        f"{_t('New assets')}: {total_new_assets}",

        f"{_t('New entries')}: {total_new_entries}",

        f"{_t('Skipped duplicates')}: {total_duplicate_entries}",

        f"{_t('Renamed asset keys')}: {total_renamed_keys}",

        f"{_t('Metadata fills')}: {total_metadata_fills}",

        f"{_t('Report Text')}: {report_name}",

    ]

    if review_text_names:

        summary_lines.append(f"{_t('Review Text')}: {review_text_names[0]}" + (f" (+{len(review_text_names)-1})" if len(review_text_names) > 1 else ''))

    if not any([total_new_assets, total_new_entries, total_duplicate_entries, total_renamed_keys, total_metadata_fills]):

        summary_lines.append(_t('No merge differences detected'))



    return {

        'summary': '\n'.join(summary_lines),

        'report_name': report_name,

        'review_text_names': review_text_names,

        'root_count': total_roots_affected,

        'new_assets': total_new_assets,

        'new_entries': total_new_entries,

        'duplicate_entries': total_duplicate_entries,

        'renamed_keys': total_renamed_keys,

        'metadata_fills': total_metadata_fills,

    }





class SF_OT_catalog_merge_review_merge_preview(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_review_merge_preview'

    bl_label = 'Review Merge Preview'

    bl_description = 'Preview how catalog entries from multiple roots would merge before writing any changes to disk'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    include_disabled: BoolProperty(

        name='Include disabled roots',

        default=False,

        description='Scan disabled roots too when reviewing catalog merge changes',

    )

    only_orphans: BoolProperty(

        name='Only orphan blends',

        default=True,

        description='Generate review items only for blend files that are not referenced by any discovered catalog',

    )

    category_mode: EnumProperty(

        name='Category Mode',

        items=[

            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),

            ('ROOT', 'Root name', 'Use the library root folder name as the category'),

            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),

        ],

        default='RELATIVE_FOLDER',

    )

    infer_preview: BoolProperty(

        name='Infer preview sidecars',

        default=True,

        description='Detect common preview image sidecars next to the blend file and include them in the review payload',

    )

    infer_meta: BoolProperty(

        name='Infer metadata sidecars',

        default=True,

        description='Detect common JSON sidecars next to the blend file and include them in the review payload',

    )

    open_text: BoolProperty(

        name='Open report in Text Editor',

        default=False,

        description='Open the generated review report in a Text Editor when possible',

    )

    list_limit: IntProperty(

        name='List Limit',

        default=25,

        min=5,

        max=500,

        description='Maximum number of changes listed per root inside the review report',

    )

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=680)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Review Merge Preview', 'Review merge diff before writing catalog.json. No on-disk changes are made.', 'PRESET')

        options = _sf_draw_dialog_header(layout, 'Build Options', 'Choose what should be scanned before you build the review list or preview the merge.', 'OUTLINER')

        col = options.column(align=True)

        col.prop(self, 'include_disabled')

        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))

        col.prop(self, 'category_mode')

        col.prop(self, 'infer_preview')

        col.prop(self, 'infer_meta')

        col.prop(self, 'open_text')

        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        data = _sf_review_catalog_merge_diff(

            context,

            include_disabled=bool(self.include_disabled),

            only_orphans=bool(self.only_orphans),

            category_mode=self.category_mode,

            infer_preview=bool(self.infer_preview),

            infer_meta=bool(self.infer_meta),

            list_limit=int(self.list_limit),

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')



        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)



        new_assets = int(data.get('new_assets', 0) or 0)

        new_entries = int(data.get('new_entries', 0) or 0)

        metadata_fills = int(data.get('metadata_fills', 0) or 0)

        if new_assets or new_entries or metadata_fills:

            self.report({'INFO'}, f"{_t('Catalog merge review complete')}: {_t('New entries')} {new_entries}, {_t('New assets')} {new_assets}")

        else:

            self.report({'INFO'}, f"{_t('Catalog merge review complete')}: {_t('No merge differences detected')}")

        return {'FINISHED'}





class SF_OT_catalog_merge_build_merge_review(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_build_merge_review'

    bl_label = 'Build Merge Review'

    bl_description = 'Build a row-by-row merge review list so each proposed catalog change can be approved or skipped'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    include_disabled: BoolProperty(name='Include disabled roots', default=False)

    only_orphans: BoolProperty(name='Only orphan blends', default=True)

    category_mode: EnumProperty(

        name='Category Mode',

        items=[

            ('RELATIVE_FOLDER', 'Relative folder', ''),

            ('ROOT', 'Root name', ''),

            ('DEFAULT', 'Default category', ''),

        ],

        default='RELATIVE_FOLDER',

    )

    infer_preview: BoolProperty(name='Infer preview sidecars', default=True)

    infer_meta: BoolProperty(name='Infer metadata sidecars', default=True)

    open_text: BoolProperty(name='Open report in Text Editor', default=False)

    list_limit: IntProperty(name='List Limit', default=80, min=10, max=1000)

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        prefs = _addon_prefs(context)

        if prefs:

            self.include_disabled = bool(getattr(prefs, 'cm_review_include_disabled', False))

            self.only_orphans = bool(getattr(prefs, 'cm_review_only_orphans', True))

            self.category_mode = str(getattr(prefs, 'cm_review_category_mode', 'RELATIVE_FOLDER') or 'RELATIVE_FOLDER')

            self.infer_preview = bool(getattr(prefs, 'cm_review_infer_preview', True))

            self.infer_meta = bool(getattr(prefs, 'cm_review_infer_meta', True))

            self.open_text = bool(getattr(prefs, 'cm_review_open_text', False))

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=700)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Build Merge Review', 'Build a root / asset / entry review list that can be toggled before applying the merge. No on-disk changes are made.', 'OUTLINER')

        options = _sf_draw_dialog_header(layout, 'Build Options', 'Choose what should be scanned before you build the review list or preview the merge.', 'OUTLINER')

        col = options.column(align=True)

        col.prop(self, 'include_disabled')

        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))

        col.prop(self, 'category_mode')

        col.prop(self, 'infer_preview')

        col.prop(self, 'infer_meta')

        col.prop(self, 'open_text')

        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if prefs:

            prefs.cm_review_include_disabled = bool(self.include_disabled)

            prefs.cm_review_only_orphans = bool(self.only_orphans)

            prefs.cm_review_category_mode = self.category_mode

            prefs.cm_review_infer_preview = bool(self.infer_preview)

            prefs.cm_review_infer_meta = bool(self.infer_meta)

            prefs.cm_review_open_text = bool(self.open_text)

        data = _sf_collect_catalog_merge_selection(

            context,

            include_disabled=bool(self.include_disabled),

            only_orphans=bool(self.only_orphans),

            category_mode=self.category_mode,

            infer_preview=bool(self.infer_preview),

            infer_meta=bool(self.infer_meta),

            list_limit=int(self.list_limit),

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')

        auto_applied = 0

        if prefs and bool(getattr(prefs, 'cm_route_auto_apply_on_build', True)):

            auto_applied = _sf_cm_apply_routes(prefs, getattr(prefs, 'cm_review_items', []), enabled_only=True)

            if auto_applied:

                self.summary_text = (self.summary_text + '\n' if self.summary_text else "") + f"{_t('Auto-applied routes')}: {auto_applied}"

                prefs.cm_review_summary = self.summary_text

        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)

        msg = f"{_t('Review list built')}: {_t('Selection rows')} {int(data.get('row_count', 0) or 0)}"

        if auto_applied:

            msg += f" | {_t('Auto-applied routes')} {auto_applied}"

        self.report({'INFO'}, msg)

        return {'FINISHED'}





class SF_OT_catalog_merge_toggle_selection_item(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_toggle_selection_item'

    bl_label = 'Toggle Selection Item'

    bl_description = 'Turn one catalog-merge review row on or off without affecting the rest of the selection list'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1)

    enable: BoolProperty(default=True)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        if not _sf_cm_apply_state_from_index(prefs, int(self.index), bool(self.enable)):

            return {'CANCELLED'}

        return {'FINISHED'}





class SF_OT_catalog_merge_set_selection(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_set_selection'

    bl_label = 'Set Selection'

    bl_description = 'Turn all enabled catalog-merge review rows on or off in a single action'

    bl_options = {'UNDO', 'INTERNAL'}



    enable: BoolProperty(default=True)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        changed = 0

        for it in _sf_cm_iter_items(prefs):

            if bool(getattr(it, 'enabled', True)) and str(getattr(it, 'level', '') or '') == 'ENTRY':

                _sf_cm_set_item_include(it, bool(self.enable))

                changed += 1

        _sf_cm_refresh_parent_states(prefs)

        self.report({'INFO'}, f"{_t('Enabled rows')}: {changed}")

        return {'FINISHED'}





class SF_OT_catalog_merge_clear_merge_selection(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_clear_merge_selection'

    bl_label = 'Clear Merge Selection'

    bl_description = 'Remove the current merge-selection review data so a clean review can be built again'

    bl_options = {'UNDO', 'INTERNAL'}



    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)



    def execute(self, context):

        prefs = _addon_prefs(context)

        _sf_clear_catalog_merge_selection(prefs)

        self.report({'INFO'}, _t('Review list cleared'))

        return {'FINISHED'}





class SF_OT_catalog_merge_apply_selected_merge(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_apply_selected_merge'

    bl_label = 'Apply Selected Merge'

    bl_description = 'Apply the currently enabled merge-review rows and optionally write the result back to catalog.json'

    bl_options = {'UNDO', 'INTERNAL'}



    apply_changes: BoolProperty(name='Write to catalog.json', default=False)

    create_backup: BoolProperty(name='Create backup before write', default=True)

    open_text: BoolProperty(name='Open report in Text Editor', default=False)

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        prefs = _addon_prefs(context)

        if prefs:

            self.apply_changes = bool(getattr(prefs, 'cm_review_apply_changes', False))

            self.create_backup = bool(getattr(prefs, 'cm_review_create_backup', True))

            self.open_text = bool(getattr(prefs, 'cm_review_open_text', False))

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=700)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Apply Selected Merge', 'Apply the currently selected review items into catalog.json. Preview text is always generated, and on-disk writing is optional.', 'FILE_TICK')

        options = _sf_draw_dialog_header(layout, 'Write Options', 'Turn on disk writing only when the preview looks correct and you are ready to update catalog.json.', 'FILE_TICK')

        col = options.column(align=True)

        col.prop(self, 'apply_changes', text=_t('Write to catalog.json'))

        sub = col.column(align=True)

        sub.enabled = self.apply_changes

        sub.prop(self, 'create_backup', text=_t('Create backup before write'))

        col.prop(self, 'open_text')

        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        prefs.cm_review_apply_changes = bool(self.apply_changes)

        prefs.cm_review_create_backup = bool(self.create_backup)

        prefs.cm_review_open_text = bool(self.open_text)

        data = _sf_merge_catalog_draft_selected(

            context,

            getattr(prefs, 'cm_review_items', []),

            include_disabled=bool(getattr(prefs, 'cm_review_include_disabled', False)),

            only_orphans=bool(getattr(prefs, 'cm_review_only_orphans', True)),

            category_mode=str(getattr(prefs, 'cm_review_category_mode', 'RELATIVE_FOLDER') or 'RELATIVE_FOLDER'),

            infer_preview=bool(getattr(prefs, 'cm_review_infer_preview', True)),

            infer_meta=bool(getattr(prefs, 'cm_review_infer_meta', True)),

            apply_changes=bool(self.apply_changes),

            create_backup=bool(self.create_backup),

            report_title='Apply Merge Selection',

            report_prefix='smart_file_suite_Catalog_Merge_Selection',

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')

        prefs.cm_review_summary = self.summary_text

        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)

        if not int(data.get('selected_rows', 0) or 0):

            self.report({'INFO'}, _t('No selection items are enabled'))

        else:

            self.report({'INFO'}, f"{_t('Selection apply complete')}: {_t('Merged entries')} {int(data.get('inserted_entries', 0) or 0)}, {_t('Metadata fills')} {int(data.get('metadata_fills', 0) or 0)}")

        return {'FINISHED'}





class SF_OT_override_manager_set_preset_active(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_set_preset_active'

    bl_label = 'Set Preset Active'

    bl_description = 'Make one saved override preset the active preset for previewing, editing, or applying'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        presets = getattr(prefs, 'cm_override_presets', [])

        if self.index < 0 or self.index >= len(presets):

            return {'CANCELLED'}

        prefs.cm_preset_active_index = int(self.index)

        prefs.cm_preset_name = str(getattr(presets[self.index], 'name', '') or '')

        return {'FINISHED'}





class SF_OT_override_manager_save_preset(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_save_preset'

    bl_label = 'Save Preset'

    bl_description = 'Create a new override preset from the settings currently shown on the active review row'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        item = _sf_cm_get_active_item(prefs) if prefs else None

        if not prefs or not item:

            self.report({'WARNING'}, _t('No review row selected'))

            return {'CANCELLED'}

        name = str(getattr(prefs, 'cm_preset_name', '') or '').strip() or _sf_cm_preset_name_from_active_item(prefs)

        if _sf_cm_find_preset_index(prefs, name) >= 0:

            self.report({'WARNING'}, _t('Preset already exists'))

            return {'CANCELLED'}

        preset = prefs.cm_override_presets.add()

        preset.name = name

        _sf_cm_copy_item_to_preset(item, preset)

        prefs.cm_preset_active_index = len(prefs.cm_override_presets) - 1

        prefs.cm_preset_name = preset.name

        self.report({'INFO'}, f"{_t('Preset saved')}: {preset.name}")

        return {'FINISHED'}





class SF_OT_override_manager_update_preset(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_update_preset'

    bl_label = 'Update Preset'

    bl_description = 'Overwrite the active override preset with the settings from the current review row'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        item = _sf_cm_get_active_item(prefs) if prefs else None

        preset = _sf_cm_get_active_preset(prefs)

        if not prefs or not item or not preset:

            self.report({'WARNING'}, _t('No preset selected'))

            return {'CANCELLED'}

        _sf_cm_copy_item_to_preset(item, preset)

        if str(getattr(prefs, 'cm_preset_name', '') or '').strip():

            preset.name = str(getattr(prefs, 'cm_preset_name', '') or '').strip()

        prefs.cm_preset_name = preset.name

        self.report({'INFO'}, f"{_t('Preset updated')}: {preset.name}")

        return {'FINISHED'}





class SF_OT_override_manager_remove_preset(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_remove_preset'

    bl_label = 'Remove Preset'

    bl_description = 'Delete the active override preset from the saved preset list'

    bl_options = {'UNDO', 'INTERNAL'}



    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)



    def execute(self, context):

        prefs = _addon_prefs(context)

        preset = _sf_cm_get_active_preset(prefs)

        if not prefs or not preset:

            self.report({'WARNING'}, _t('No preset selected'))

            return {'CANCELLED'}

        idx = int(getattr(prefs, 'cm_preset_active_index', 0) or 0)

        name = str(getattr(preset, 'name', '') or '')

        prefs.cm_override_presets.remove(idx)

        prefs.cm_preset_active_index = max(0, min(idx, len(prefs.cm_override_presets) - 1)) if len(prefs.cm_override_presets) else 0

        prefs.cm_preset_name = str(getattr(_sf_cm_get_active_preset(prefs), 'name', '') or '')

        self.report({'INFO'}, f"{_t('Preset removed')}: {name}")

        return {'FINISHED'}





class SF_OT_override_manager_apply_preset(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_apply_preset'

    bl_label = 'Apply Preset'

    bl_description = 'Apply the active override preset to the current review row or to a broader selection, depending on scope'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        preset = _sf_cm_get_active_preset(prefs)

        if not prefs or not preset:

            self.report({'WARNING'}, _t('No preset selected'))

            return {'CANCELLED'}

        scope = str(getattr(prefs, 'cm_preset_apply_scope', 'MATCHING') or 'MATCHING')

        changed = _sf_cm_apply_preset(prefs, preset, scope=scope)

        self.report({'INFO'}, f"{_t('Preset applied')}: {changed}")

        return {'FINISHED'}





class SF_OT_override_manager_export_presets(bpy.types.Operator, ExportHelper):

    bl_idname = 'import_scene.sfs_override_manager_export_presets'

    bl_label = 'Export Presets'

    bl_description = 'Write the saved override preset library to disk so it can be backed up or shared'

    bl_options = {'UNDO', 'INTERNAL'}



    filename_ext = ".json"

    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_active_only: BoolProperty(name='Export active preset only', default=False)



    def invoke(self, context, _event):

        if not getattr(self, 'filepath', ''):

            self.filepath = _sf_user_default_file('smart_file_suite_Override_Presets.json', 'presets')

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        data_items = []

        if bool(self.export_active_only):

            preset = _sf_cm_get_active_preset(prefs)

            if preset:

                data_items.append(_sf_cm_preset_to_dict(preset))

        else:

            for preset in list(getattr(prefs, 'cm_override_presets', []) or []):

                data_items.append(_sf_cm_preset_to_dict(preset))

        payload = {

            'type': 'simple_append_override_presets',

            'version': 1,

            'exported_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),

            'count': len(data_items),

            'presets': data_items,

        }

        filepath = _norm_path(self.filepath or '')

        try:

            os.makedirs(os.path.dirname(filepath), exist_ok=True)

        except Exception:

            pass

        with open(filepath, 'w', encoding='utf-8') as f:

            json.dump(payload, f, ensure_ascii=False, indent=2)

        _sf_write_report_text('smart_file_suite_Override_Presets_Export.json', json.dumps(payload, ensure_ascii=False, indent=2) + '\n')

        self.report({'INFO'}, f"{_t('Export complete')}: {len(data_items)}")

        return {'FINISHED'}





class SF_OT_override_manager_import_presets(bpy.types.Operator, ImportHelper):

    bl_idname = 'import_scene.sfs_override_manager_import_presets'

    bl_label = 'Import Presets'

    bl_description = 'Load override presets from disk and merge or replace them according to the chosen import mode'

    bl_options = {'UNDO', 'INTERNAL'}



    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    import_mode: EnumProperty(

        name='Import mode',

        items=[

            ('UPSERT', 'Upsert', ''),

            ('APPEND', 'Append', ''),

            ('REPLACE', 'Replace all', ''),

        ],

        default='UPSERT',

    )



    def invoke(self, context, _event):

        prefs = _addon_prefs(context)

        if prefs:

            self.import_mode = str(getattr(prefs, 'cm_preset_import_mode', 'UPSERT') or 'UPSERT')

        if not getattr(self, 'filepath', ''):

            self.filepath = _sf_user_default_file('smart_file_suite_Override_Presets.json', 'presets')

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        filepath = _norm_path(self.filepath or '')

        if not filepath or not os.path.isfile(filepath):

            self.report({'WARNING'}, _t('File not found'))

            return {'CANCELLED'}

        with open(filepath, 'r', encoding='utf-8') as f:

            data = json.load(f)

        presets = data.get('presets') if isinstance(data, dict) else data

        if not isinstance(presets, list):

            self.report({'WARNING'}, _t('Invalid preset file'))

            return {'CANCELLED'}

        prefs.cm_preset_import_mode = self.import_mode

        if self.import_mode == 'REPLACE':

            prefs.cm_override_presets.clear()

        imported = 0

        last_index = -1

        for entry in presets:

            if not isinstance(entry, dict):

                continue

            name = str(entry.get('name') or '').strip() or 'Imported Preset'

            idx = _sf_cm_find_preset_index(prefs, name) if self.import_mode == 'UPSERT' else -1

            if idx >= 0:

                preset = prefs.cm_override_presets[idx]

            else:

                preset = prefs.cm_override_presets.add()

                idx = len(prefs.cm_override_presets) - 1

            _sf_cm_load_preset_from_dict(preset, entry)

            imported += 1

            last_index = idx

        if last_index >= 0:

            prefs.cm_preset_active_index = last_index

            prefs.cm_preset_name = str(getattr(prefs.cm_override_presets[last_index], 'name', '') or '')

        self.report({'INFO'}, f"{_t('Import complete')}: {imported}")

        return {'FINISHED'}





class SF_OT_override_manager_set_route_active(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_set_route_active'

    bl_label = 'Set Route Active'

    bl_description = 'Make one saved routing rule the active route for editing or applying'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        routes = getattr(prefs, 'cm_override_routes', [])

        if self.index < 0 or self.index >= len(routes):

            return {'CANCELLED'}

        prefs.cm_route_active_index = int(self.index)

        _sf_cm_copy_route_to_ui(prefs, routes[self.index])

        return {'FINISHED'}





class SF_OT_override_manager_save_route(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_save_route'

    bl_label = 'Save Route'

    bl_description = 'Create a new routing rule from the values currently entered in the route fields'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        name = str(getattr(prefs, 'cm_route_name', '') or '').strip() or 'Route'

        if _sf_cm_find_route_index(prefs, name) >= 0:

            self.report({'WARNING'}, _t('Route already exists'))

            return {'CANCELLED'}

        route = prefs.cm_override_routes.add()

        prefs.cm_route_name = name

        _sf_cm_copy_ui_to_route(prefs, route)

        prefs.cm_route_active_index = len(prefs.cm_override_routes) - 1

        _sf_cm_copy_route_to_ui(prefs, route)

        self.report({'INFO'}, f"{_t('Route saved')}: {route.name}")

        return {'FINISHED'}





class SF_OT_override_manager_update_route(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_update_route'

    bl_label = 'Update Route'

    bl_description = 'Overwrite the active routing rule with the values currently shown in the route fields'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        route = _sf_cm_get_active_route(prefs)

        if not prefs or not route:

            self.report({'WARNING'}, _t('No route selected'))

            return {'CANCELLED'}

        old_name = str(getattr(route, 'name', '') or '')

        new_name = str(getattr(prefs, 'cm_route_name', '') or '').strip() or old_name or 'Route'

        other_idx = _sf_cm_find_route_index(prefs, new_name)

        if other_idx >= 0 and other_idx != int(getattr(prefs, 'cm_route_active_index', 0) or 0):

            self.report({'WARNING'}, _t('Route already exists'))

            return {'CANCELLED'}

        prefs.cm_route_name = new_name

        _sf_cm_copy_ui_to_route(prefs, route)

        _sf_cm_copy_route_to_ui(prefs, route)

        self.report({'INFO'}, f"{_t('Route updated')}: {route.name}")

        return {'FINISHED'}





class SF_OT_override_manager_remove_route(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_remove_route'

    bl_label = 'Remove Route'

    bl_description = 'Delete the active routing rule from the saved route list'

    bl_options = {'UNDO', 'INTERNAL'}



    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)



    def execute(self, context):

        prefs = _addon_prefs(context)

        route = _sf_cm_get_active_route(prefs)

        if not prefs or not route:

            self.report({'WARNING'}, _t('No route selected'))

            return {'CANCELLED'}

        idx = int(getattr(prefs, 'cm_route_active_index', 0) or 0)

        name = str(getattr(route, 'name', '') or '')

        prefs.cm_override_routes.remove(idx)

        if len(prefs.cm_override_routes):

            prefs.cm_route_active_index = max(0, min(idx, len(prefs.cm_override_routes) - 1))

            _sf_cm_copy_route_to_ui(prefs, prefs.cm_override_routes[prefs.cm_route_active_index])

        else:

            prefs.cm_route_active_index = 0

            prefs.cm_route_name = ''

            prefs.cm_route_root_filter = ''

            prefs.cm_route_category_filter = ''

            prefs.cm_route_action_filter = 'ANY'

        self.report({'INFO'}, f"{_t('Route removed')}: {name}")

        return {'FINISHED'}





class SF_OT_override_manager_apply_routes(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_override_manager_apply_routes'

    bl_label = 'Apply Routes'

    bl_description = 'Apply the saved routing rules to matching review rows so the correct override preset is assigned automatically'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        if not list(getattr(prefs, 'cm_override_routes', []) or []):

            self.report({'WARNING'}, _t('No route selected'))

            return {'CANCELLED'}

        # Refresh active route from current UI fields if possible

        route = _sf_cm_get_active_route(prefs)

        if route:

            _sf_cm_copy_ui_to_route(prefs, route)

        changed = _sf_cm_apply_routes(prefs, getattr(prefs, 'cm_review_items', []), enabled_only=True)

        self.report({'INFO'}, f"{_t('Apply Routes')}: {changed}")

        return {'FINISHED'}





class SF_OT_catalog_merge_apply_filtered_merge(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_apply_filtered_merge'

    bl_label = 'Apply Filtered Merge'

    bl_description = 'Merge catalog draft data selectively so only approved assets, entries, and metadata changes are carried forward'

    bl_options = {'UNDO', 'INTERNAL'}



    include_disabled: BoolProperty(

        name='Include disabled roots',

        default=False,

        description='Scan disabled roots too when generating and selectively merging draft entries',

    )

    only_orphans: BoolProperty(

        name='Only orphan blends',

        default=True,

        description='Generate entries only for blend files that are not referenced by any discovered catalog',

    )

    category_mode: EnumProperty(

        name='Category Mode',

        items=[

            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),

            ('ROOT', 'Root name', 'Use the library root folder name as the category'),

            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),

        ],

        default='RELATIVE_FOLDER',

    )

    infer_preview: BoolProperty(

        name='Infer preview sidecars',

        default=True,

        description='Detect common preview image sidecars next to the blend file and include them in the merge payload',

    )

    infer_meta: BoolProperty(

        name='Infer metadata sidecars',

        default=True,

        description='Detect common JSON sidecars next to the blend file and include them in the merge payload',

    )

    merge_new_assets: BoolProperty(

        name='Merge new assets',

        default=True,

        description='Create brand-new asset blocks in catalog.json when they do not already exist',

    )

    merge_new_entries: BoolProperty(

        name='Merge new entries',

        default=True,

        description='Append new version entries into existing assets when they do not already exist',

    )

    fill_missing_metadata: BoolProperty(

        name='Fill missing metadata',

        default=True,

        description='Fill empty preview/meta/category/tags fields on duplicate entries when draft data has usable values',

    )

    allow_asset_key_rename: BoolProperty(

        name='Allow asset key renames',

        default=True,

        description='When a draft asset key collides with an unrelated existing key, create a safe renamed key instead of skipping it',

    )

    apply_changes: BoolProperty(

        name='Write to catalog.json',

        default=False,

        description='Write the selectively merged catalog result back to disk instead of only generating preview text',

    )

    create_backup: BoolProperty(

        name='Create backup before write',

        default=True,

        description='Write catalog.json.bak_<timestamp> before overwriting catalog.json',

    )

    open_text: BoolProperty(

        name='Open report in Text Editor',

        default=False,

        description='Open the generated merge report in a Text Editor when possible',

    )

    list_limit: IntProperty(

        name='List Limit',

        default=40,

        min=5,

        max=500,

        description='Maximum number of candidate blend paths listed per root inside the merge report',

    )

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=720)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Apply Filtered Merge', 'Selective merge generated catalog entries into catalog.json using action filters. Preview text is always generated, and on-disk writing is optional.', 'FILTER')

        build_box = _sf_draw_dialog_header(layout, 'Build Options', 'Choose what should be scanned before you build the review list or preview the merge.', 'OUTLINER')

        col = build_box.column(align=True)

        col.prop(self, 'include_disabled')

        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))

        col.prop(self, 'category_mode')

        col.prop(self, 'infer_preview')

        col.prop(self, 'infer_meta')



        sbox = _sf_draw_dialog_header(layout, 'Merge Rules', 'Choose which draft changes are allowed into the merged result before any file is written.', 'CHECKMARK')

        scol = sbox.column(align=True)

        scol.prop(self, 'merge_new_assets')

        scol.prop(self, 'merge_new_entries')

        scol.prop(self, 'fill_missing_metadata')

        scol.prop(self, 'allow_asset_key_rename')



        wbox = _sf_draw_dialog_header(layout, 'Write Options', 'Turn on disk writing only when the preview looks correct and you are ready to update catalog.json.', 'FILE_TICK')

        wcol = wbox.column(align=True)

        wcol.prop(self, 'apply_changes', text=_t('Write to catalog.json'))

        sub = wcol.column(align=True)

        sub.enabled = self.apply_changes

        sub.prop(self, 'create_backup', text=_t('Create backup before write'))

        wcol.prop(self, 'open_text')



        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        data = _sf_merge_catalog_draft(

            context,

            include_disabled=bool(self.include_disabled),

            only_orphans=bool(self.only_orphans),

            category_mode=self.category_mode,

            infer_preview=bool(self.infer_preview),

            infer_meta=bool(self.infer_meta),

            apply_changes=bool(self.apply_changes),

            create_backup=bool(self.create_backup),

            list_limit=int(self.list_limit),

            merge_new_assets=bool(self.merge_new_assets),

            merge_new_entries=bool(self.merge_new_entries),

            fill_missing_metadata=bool(self.fill_missing_metadata),

            allow_asset_key_rename=bool(self.allow_asset_key_rename),

            report_title='Selective Merge Catalog Draft',

            report_prefix='smart_file_suite_Catalog_Selective_Merge',

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')



        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)



        merged_entries = int(data.get('inserted_entries', 0) or 0)

        metadata_fills = int(data.get('metadata_fills', 0) or 0)

        filtered_entries = int(data.get('filtered_entries', 0) or 0)

        if merged_entries or metadata_fills:

            self.report({'INFO'}, f"{_t('Selective merge complete')}: {_t('Merged entries')} {merged_entries}, {_t('Metadata fills')} {metadata_fills}")

        else:

            self.report({'INFO'}, f"{_t('Selective merge complete')}: {_t('Filtered entries')} {filtered_entries}")

        return {'FINISHED'}





class SF_OT_catalog_merge_apply_full_merge(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_catalog_merge_apply_full_merge'

    bl_label = 'Apply Full Merge'

    bl_description = 'Merge catalog draft data using the current priority rules and produce a single consolidated result'

    bl_options = {'UNDO', 'INTERNAL'}



    include_disabled: BoolProperty(

        name='Include disabled roots',

        default=False,

        description='Scan disabled roots too when generating and merging draft entries',

    )

    only_orphans: BoolProperty(

        name='Only orphan blends',

        default=True,

        description='Generate entries only for blend files that are not referenced by any discovered catalog',

    )

    category_mode: EnumProperty(

        name='Category Mode',

        items=[

            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),

            ('ROOT', 'Root name', 'Use the library root folder name as the category'),

            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),

        ],

        default='RELATIVE_FOLDER',

    )

    infer_preview: BoolProperty(

        name='Infer preview sidecars',

        default=True,

        description='Detect common preview image sidecars next to the blend file and include them in the merge payload',

    )

    infer_meta: BoolProperty(

        name='Infer metadata sidecars',

        default=True,

        description='Detect common JSON sidecars next to the blend file and include them in the merge payload',

    )

    apply_changes: BoolProperty(

        name='Write to catalog.json',

        default=False,

        description='Write merged catalog data to disk. When disabled, only preview/report texts are generated',

    )

    create_backup: BoolProperty(

        name='Create backup before write',

        default=True,

        description='Create a timestamped backup next to the target catalog.json before overwriting it',

    )

    open_text: BoolProperty(

        name='Open report in Text Editor',

        default=False,

        description='Open the generated merge report in a Text Editor when possible',

    )

    list_limit: IntProperty(

        name='List Limit',

        default=25,

        min=5,

        max=500,

        description='Maximum number of paths listed per root inside the merge report',

    )

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=660)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Apply Full Merge', 'Merge generated catalog entries into catalog.json. Preview text is always generated, and on-disk writing is optional.', 'FILE_TICK')

        build_box = _sf_draw_dialog_header(layout, 'Build Options', 'Choose what should be scanned before you build the review list or preview the merge.', 'OUTLINER')

        col = build_box.column(align=True)

        col.prop(self, 'include_disabled')

        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))

        col.prop(self, 'category_mode')

        col.prop(self, 'infer_preview')

        col.prop(self, 'infer_meta')

        write_box = _sf_draw_dialog_header(layout, 'Write Options', 'Turn on disk writing only when the preview looks correct and you are ready to update catalog.json.', 'FILE_TICK')

        wcol = write_box.column(align=True)

        wcol.prop(self, 'apply_changes', text=_t('Write to catalog.json'))

        sub = wcol.column(align=True)

        sub.enabled = self.apply_changes

        sub.prop(self, 'create_backup', text=_t('Create backup before write'))

        wcol.prop(self, 'open_text')

        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        data = _sf_merge_catalog_draft(

            context,

            include_disabled=bool(self.include_disabled),

            only_orphans=bool(self.only_orphans),

            category_mode=self.category_mode,

            infer_preview=bool(self.infer_preview),

            infer_meta=bool(self.infer_meta),

            apply_changes=bool(self.apply_changes),

            create_backup=bool(self.create_backup),

            list_limit=int(self.list_limit),

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')



        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)



        files_written = int(data.get('files_written', 0) or 0)

        inserted_entries = int(data.get('inserted_entries', 0) or 0)

        if files_written:

            self.report({'INFO'}, f"{_t('Catalog merge complete')}: {_t('Catalog files written')} {files_written}")

        elif inserted_entries:

            self.report({'INFO'}, f"{_t('Catalog merge complete')}: {_t('Preview only (no disk write)')}")

        else:

            self.report({'INFO'}, f"{_t('Catalog merge complete')}: {_t('No merge changes detected')}")

        return {'FINISHED'}





def _sf_run_library_workflow(context,

                              include_disabled: bool = False,

                              run_diagnostics_before: bool = True,

                              run_repair: bool = True,

                              normalize_paths: bool = True,

                              remove_empty: bool = True,

                              merge_duplicates: bool = True,

                              disable_missing: bool = True,

                              sort_by_priority: bool = True,

                              rebuild_index: bool = True,

                              generate_draft: bool = True,

                              only_orphans: bool = True,

                              category_mode: str = 'RELATIVE_FOLDER',

                              infer_preview: bool = True,

                              infer_meta: bool = True,

                              merge_draft: bool = True,

                              apply_changes: bool = False,

                              create_backup: bool = True,

                              run_diagnostics_after: bool = True,

                              list_limit: int = 40) -> dict:

    timestamp = datetime.datetime.now()

    step_reports = []

    detail_lines = [

        f"{_t('Library Workflow')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        '',

        'OPTIONS',

        f"- include_disabled={bool(include_disabled)}",

        f"- run_diagnostics_before={bool(run_diagnostics_before)}",

        f"- run_repair={bool(run_repair)}",

        f"- generate_draft={bool(generate_draft)}",

        f"- merge_draft={bool(merge_draft)}",

        f"- run_diagnostics_after={bool(run_diagnostics_after)}",

        f"- apply_changes={bool(apply_changes)}",

        f"- only_orphans={bool(only_orphans)}",

        f"- category_mode={category_mode}",

        f"- infer_preview={bool(infer_preview)}",

        f"- infer_meta={bool(infer_meta)}",

        '',

    ]



    issue_before = None

    issue_after = None

    repair_data = {}

    draft_data = {}

    merge_data = {}



    if not any([run_diagnostics_before, run_repair, generate_draft, merge_draft, run_diagnostics_after]):

        report_name = _sf_write_report_text('smart_file_suite_Library_Workflow_Report.txt', '\n'.join(detail_lines + [_t('No workflow steps were enabled')]) + '\n')

        return {

            'summary': '\n'.join([_t('Library Workflow'), _t('No workflow steps were enabled'), f"{_t('Workflow Report')}: {report_name}"]),

            'report_name': report_name,

            'issue_before': 0,

            'issue_after': 0,

            'issue_delta': 0,

            'change_count': 0,

            'draft_entries': 0,

            'merged_entries': 0,

            'files_written': 0,

            'sub_reports': [],

        }



    if run_diagnostics_before:

        before = _sf_run_library_diagnostics(context, include_disabled=bool(include_disabled), list_limit=int(list_limit))

        issue_before = int(before.get('issue_count', 0) or 0)

        step_reports.append(before.get('report_name', ''))

        detail_lines.extend(['STEP 1 | DIAGNOSTICS BEFORE', before.get('summary', ''), ''])



    if run_repair:

        repair_data = _sf_repair_library_roots(

            context,

            normalize_paths=bool(normalize_paths),

            remove_empty=bool(remove_empty),

            merge_duplicates=bool(merge_duplicates),

            disable_missing=bool(disable_missing),

            sort_by_priority=bool(sort_by_priority),

            rebuild_index=bool(rebuild_index),

        )

        step_reports.append(repair_data.get('report_name', ''))

        detail_lines.extend(['STEP 2 | REPAIR', repair_data.get('summary', ''), ''])



    if generate_draft:

        draft_data = _sf_generate_catalog_draft(

            context,

            include_disabled=bool(include_disabled),

            only_orphans=bool(only_orphans),

            category_mode=category_mode,

            infer_preview=bool(infer_preview),

            infer_meta=bool(infer_meta),

            list_limit=int(list_limit),

        )

        step_reports.append(draft_data.get('report_name', ''))

        detail_lines.extend(['STEP 3 | DRAFT', draft_data.get('summary', ''), ''])



    if merge_draft:

        merge_data = _sf_merge_catalog_draft(

            context,

            include_disabled=bool(include_disabled),

            only_orphans=bool(only_orphans),

            category_mode=category_mode,

            infer_preview=bool(infer_preview),

            infer_meta=bool(infer_meta),

            apply_changes=bool(apply_changes),

            create_backup=bool(create_backup),

            list_limit=int(list_limit),

        )

        step_reports.append(merge_data.get('report_name', ''))

        preview_names = list(merge_data.get('preview_text_names', []) or [])

        for name in preview_names:

            step_reports.append(name)

        detail_lines.extend(['STEP 4 | MERGE', merge_data.get('summary', ''), ''])



    if run_diagnostics_after:

        after = _sf_run_library_diagnostics(context, include_disabled=bool(include_disabled), list_limit=int(list_limit))

        issue_after = int(after.get('issue_count', 0) or 0)

        step_reports.append(after.get('report_name', ''))

        detail_lines.extend(['STEP 5 | DIAGNOSTICS AFTER', after.get('summary', ''), ''])



    if issue_before is None:

        issue_before = issue_after if issue_after is not None else 0

    if issue_after is None:

        issue_after = issue_before if issue_before is not None else 0

    issue_delta = int(issue_after) - int(issue_before)



    sub_reports = [name for name in step_reports if name]

    detail_lines.extend([

        'SUMMARY',

        f"- {_t('Issues before')}: {int(issue_before)}",

        f"- {_t('Issues after')}: {int(issue_after)}",

        f"- {_t('Issue delta')}: {issue_delta:+d}",

        f"- {_t('Changes applied')}: {int(repair_data.get('change_count', 0) or 0)}",

        f"- {_t('Draft entries')}: {int(draft_data.get('entry_count', 0) or 0)}",

        f"- {_t('Merged entries')}: {int(merge_data.get('inserted_entries', 0) or 0)}",

        f"- {_t('Catalog files written')}: {int(merge_data.get('files_written', 0) or 0)}",

    ])

    if sub_reports:

        detail_lines.append('')

        detail_lines.append('SUB_REPORTS')

        for name in sub_reports:

            detail_lines.append(f"- {name}")



    report_name = _sf_write_report_text('smart_file_suite_Library_Workflow_Report.txt', '\n'.join(detail_lines) + '\n')



    summary_lines = [

        f"{_t('Library Workflow')} | {timestamp.strftime('%Y-%m-%d %H:%M:%S')}",

        f"{_t('Issues before')}: {int(issue_before)}",

        f"{_t('Issues after')}: {int(issue_after)}",

        f"{_t('Issue delta')}: {issue_delta:+d}",

        f"{_t('Changes applied')}: {int(repair_data.get('change_count', 0) or 0)}",

        f"{_t('Draft entries')}: {int(draft_data.get('entry_count', 0) or 0)}",

        f"{_t('Merged entries')}: {int(merge_data.get('inserted_entries', 0) or 0)}",

        f"{_t('Catalog files written')}: {int(merge_data.get('files_written', 0) or 0)}",

        f"{_t('Workflow Report')}: {report_name}",

    ]

    if sub_reports:

        summary_lines.append(f"{_t('Sub reports')}: {sub_reports[0]}" + (f" (+{len(sub_reports)-1})" if len(sub_reports) > 1 else ''))



    return {

        'summary': '\n'.join(summary_lines),

        'report_name': report_name,

        'issue_before': int(issue_before),

        'issue_after': int(issue_after),

        'issue_delta': int(issue_delta),

        'change_count': int(repair_data.get('change_count', 0) or 0),

        'draft_entries': int(draft_data.get('entry_count', 0) or 0),

        'merged_entries': int(merge_data.get('inserted_entries', 0) or 0),

        'files_written': int(merge_data.get('files_written', 0) or 0),

        'sub_reports': sub_reports,

    }





class SF_OT_reference_manager_run_library_workflow(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_run_library_workflow'

    bl_label = 'Run Library Workflow'

    bl_description = 'Run a guided maintenance workflow that chains diagnostics, indexing, catalog review, and optional fixes for shared libraries'

    bl_options = {'UNDO', 'INTERNAL'}



    include_disabled: BoolProperty(

        name='Include disabled roots',

        default=False,

        description='Scan disabled roots too when running the workflow',

    )

    run_diagnostics_before: BoolProperty(

        name='Run diagnostics before',

        default=True,

        description='Run diagnostics before repair / draft / merge',

    )

    run_repair: BoolProperty(

        name='Run repair',

        default=True,

        description='Run safe Library Roots repair before draft / merge',

    )

    run_diagnostics_after: BoolProperty(

        name='Run diagnostics after',

        default=True,

        description='Run diagnostics again after the workflow finishes',

    )

    generate_draft: BoolProperty(

        name='Run draft generation',

        default=True,

        description='Generate draft JSON/text for orphan or selected blend files',

    )

    merge_draft: BoolProperty(

        name='Run merge',

        default=True,

        description='Merge generated entries into catalog.json preview and optionally write to disk',

    )

    normalize_paths: BoolProperty(name='Normalize paths', default=True)

    remove_empty: BoolProperty(name='Remove empty roots', default=True)

    merge_duplicates: BoolProperty(name='Merge duplicate roots', default=True)

    disable_missing: BoolProperty(name='Disable missing roots', default=True)

    sort_by_priority: BoolProperty(name='Sort by priority', default=True)

    rebuild_index: BoolProperty(name='Rebuild index after repair', default=True)

    only_orphans: BoolProperty(name='Only orphan blends', default=True)

    category_mode: EnumProperty(

        name='Category Mode',

        items=[

            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),

            ('ROOT', 'Root name', 'Use the library root folder name as the category'),

            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),

        ],

        default='RELATIVE_FOLDER',

    )

    infer_preview: BoolProperty(name='Infer preview sidecars', default=True)

    infer_meta: BoolProperty(name='Infer metadata sidecars', default=True)

    apply_changes: BoolProperty(

        name='Write to catalog.json',

        default=False,

        description='Write merged catalog data to disk. Disabled means preview/report only',

    )

    create_backup: BoolProperty(name='Create backup before write', default=True)

    open_text: BoolProperty(name='Open report in Text Editor', default=False)

    list_limit: IntProperty(name='List Limit', default=25, min=5, max=500)

    summary_text: StringProperty(default='', options={'HIDDEN'})

    report_name: StringProperty(default='', options={'HIDDEN'})



    def invoke(self, context, _event):

        self.summary_text = ''

        self.report_name = ''

        return context.window_manager.invoke_props_dialog(self, width=700)



    def draw(self, context):

        layout = self.layout

        _sf_draw_dialog_header(layout, 'Run Library Workflow', 'Run the full workflow: diagnostics, root repair, draft generation, catalog merge, and re-check. Disk writing remains optional.', 'PLAY')



        sbox = _sf_draw_dialog_header(layout, 'Workflow Steps', 'Decide which stages to run, then use repair and write options below to control side effects.', 'CHECKMARK')

        col = sbox.column(align=True)

        col.prop(self, 'include_disabled')

        col.prop(self, 'run_diagnostics_before')

        col.prop(self, 'run_repair')

        col.prop(self, 'generate_draft')

        col.prop(self, 'merge_draft')

        col.prop(self, 'run_diagnostics_after')



        rbox = _sf_draw_dialog_header(layout, 'Repair Options', 'Adjust repair behavior here before the workflow changes roots, paths, or indexes.', 'PREFERENCES')

        col = rbox.column(align=True)

        col.enabled = self.run_repair

        col.prop(self, 'normalize_paths')

        col.prop(self, 'remove_empty')

        col.prop(self, 'merge_duplicates')

        col.prop(self, 'disable_missing')

        col.prop(self, 'sort_by_priority')

        col.prop(self, 'rebuild_index')



        dbox = _sf_draw_dialog_header(layout, 'Draft / Merge Options', 'Choose draft discovery and writeback rules here before the workflow reaches the catalog stage.', 'FILE_TICK')

        col = dbox.column(align=True)

        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))

        col.prop(self, 'category_mode')

        col.prop(self, 'infer_preview')

        col.prop(self, 'infer_meta')

        col.prop(self, 'apply_changes', text=_t('Write to catalog.json'))

        sub = col.column(align=True)

        sub.enabled = self.merge_draft and self.apply_changes

        sub.prop(self, 'create_backup', text=_t('Create backup before write'))

        col.prop(self, 'open_text')



        _sf_draw_dialog_summary(layout, self.summary_text)



    def execute(self, context):

        data = _sf_run_library_workflow(

            context,

            include_disabled=bool(self.include_disabled),

            run_diagnostics_before=bool(self.run_diagnostics_before),

            run_repair=bool(self.run_repair),

            normalize_paths=bool(self.normalize_paths),

            remove_empty=bool(self.remove_empty),

            merge_duplicates=bool(self.merge_duplicates),

            disable_missing=bool(self.disable_missing),

            sort_by_priority=bool(self.sort_by_priority),

            rebuild_index=bool(self.rebuild_index),

            generate_draft=bool(self.generate_draft),

            only_orphans=bool(self.only_orphans),

            category_mode=self.category_mode,

            infer_preview=bool(self.infer_preview),

            infer_meta=bool(self.infer_meta),

            merge_draft=bool(self.merge_draft),

            apply_changes=bool(self.apply_changes and self.merge_draft),

            create_backup=bool(self.create_backup),

            run_diagnostics_after=bool(self.run_diagnostics_after),

            list_limit=int(self.list_limit),

        )

        self.summary_text = data.get('summary', '')

        self.report_name = data.get('report_name', '')



        if self.open_text and self.report_name:

            _sf_open_text_in_any_editor(context, self.report_name)



        files_written = int(data.get('files_written', 0) or 0)

        issue_after = int(data.get('issue_after', 0) or 0)

        change_count = int(data.get('change_count', 0) or 0)

        if files_written:

            self.report({'INFO'}, f"{_t('Workflow complete')}: {_t('Catalog files written')} {files_written}")

        else:

            self.report({'INFO'}, f"{_t('Workflow complete')}: {_t('Issues after')} {issue_after} | {_t('Changes applied')} {change_count}")

        return {'FINISHED'}





# -----------------------------------------------------------------------------

#  Menu

# -----------------------------------------------------------------------------







class SF_MT_reference_manager_reference_manager_recent_sources(bpy.types.Menu):

    bl_label = 'Reference Manager Recent Sources'

    bl_idname = 'SF_MT_reference_manager_reference_manager_recent_sources'

    bl_description = 'Show recently used source .blend files so you can reopen a known source without browsing folders again'



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        entries = list(getattr(prefs, 'recent_paths', []) or []) if prefs else []

        if not entries:

            layout.label(text=_t('No recent sources yet'))

            return

        for idx, item in enumerate(entries[:10]):

            path = getattr(item, 'path', '') or ''

            label = os.path.basename(path) or path or f"{idx+1}"

            icon_id = _sf_saved_path_icon_id(path)

            op = layout.operator(SF_OT_source_browser_use.bl_idname, text=label, icon_value=icon_id, translate=False) if icon_id else layout.operator(SF_OT_source_browser_use.bl_idname, text=label, icon='FILE_BLEND', translate=False)

            _sf_safe_set_operator_property(op, 'kind', 'RECENT')

            _sf_safe_set_operator_property(op, 'index', idx)





class SF_MT_reference_manager_reference_manager_favorite_sources(bpy.types.Menu):

    bl_label = 'Reference Manager Favorite Sources'

    bl_idname = 'SF_MT_reference_manager_reference_manager_favorite_sources'

    bl_description = 'Show favorite source .blend files that you want to reuse often across importing, relinking, and publishing tasks'



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        entries = list(getattr(prefs, 'favorite_paths', []) or []) if prefs else []

        if not entries:

            layout.label(text=_t('No favorite sources yet'))

            return

        for idx, item in enumerate(entries[:10]):

            path = getattr(item, 'path', '') or ''

            label = os.path.basename(path) or path or f"{idx+1}"

            icon_id = _sf_saved_path_icon_id(path)

            op = layout.operator(SF_OT_source_browser_use.bl_idname, text=label, icon_value=icon_id, translate=False) if icon_id else layout.operator(SF_OT_source_browser_use.bl_idname, text=label, icon='FUND', translate=False)

            _sf_safe_set_operator_property(op, 'kind', 'FAVORITE')

            _sf_safe_set_operator_property(op, 'index', idx)





def _sf_is_within_root(path: str, root_path: str) -> bool:

    try:

        path = _norm_path(path or '')

        root_path = _norm_path(root_path or '')

        if not path or not root_path:

            return False

        return os.path.commonpath([path, root_path]) == root_path

    except Exception:

        return False





def _sf_find_library_root_for_path(prefs, path: str):

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    best = None

    best_len = -1

    for root in roots:

        if not bool(getattr(root, 'enabled', True)):

            continue

        root_path = _norm_path(getattr(root, 'path', '') or '')

        if not root_path or not os.path.isdir(root_path):

            continue

        if _sf_is_within_root(path, root_path) and len(root_path) > best_len:

            best = root

            best_len = len(root_path)

    return best





def _sf_find_nearby_catalog_for_path(path: str, root_path: str = '') -> str:

    try:

        if not path:

            return ''

        current = os.path.dirname(_norm_path(path))

        root_path = _norm_path(root_path or '')

        while current and os.path.isdir(current):

            candidate = os.path.join(current, 'catalog.json')

            if os.path.isfile(candidate):

                return _norm_path(candidate)

            parent = os.path.dirname(current)

            if not parent or parent == current:

                break

            if root_path and not _sf_is_within_root(parent, root_path):

                break

            current = parent

    except Exception:

        return ''

    return ''





def _sf_bool_status_label(value: bool) -> str:

    return _t('Yes') if bool(value) else _t('No')





def _sf_health_label(found: bool) -> str:

    return _t('Found') if bool(found) else _t('Missing')





def _sf_health_score_label(has_source: bool, source_info: dict, roots_ready: bool, index_ready: bool) -> tuple[int, str]:

    score = 0

    if has_source:

        score += 35

    if roots_ready:

        score += 15

    if index_ready:

        score += 15

    if bool(source_info.get('inside_root')):

        score += 10

    if bool(source_info.get('is_indexed')):

        score += 10

    if bool(source_info.get('preview_path')):

        score += 5

    if bool(source_info.get('meta_path')):

        score += 5

    if bool(source_info.get('catalog_path')):

        score += 5

    if score >= 85:

        label = _t('Excellent')

    elif score >= 65:

        label = _t('Good')

    elif score >= 40:

        label = _t('Partial')

    else:

        label = _t('Needs attention')

    return min(100, score), label





def _sf_get_source_insights(prefs, filepath: str, index_data: dict | None = None) -> dict:

    info = {

        'has_source': False,

        'root_name': '',

        'root_path': '',

        'inside_root': False,

        'preview_path': '',

        'meta_path': '',

        'catalog_path': '',

        'is_indexed': False,

        'source_mtime_label': '',

    }

    try:

        filepath = _norm_path(filepath or '')

        info['has_source'] = bool(filepath and os.path.isfile(filepath))

        if not info['has_source']:

            return info

        root = _sf_find_library_root_for_path(prefs, filepath)

        if root:

            info['inside_root'] = True

            info['root_name'] = getattr(root, 'label', '') or os.path.basename(_norm_path(getattr(root, 'path', '') or '')) or _t('Library Root')

            info['root_path'] = _norm_path(getattr(root, 'path', '') or '')

        preview_path = _sf_guess_preview_sidecar(filepath)

        meta_path = _sf_guess_meta_sidecar(filepath)

        info['preview_path'] = _norm_path(preview_path) if preview_path and os.path.isfile(preview_path) else ''

        info['meta_path'] = _norm_path(meta_path) if meta_path and os.path.isfile(meta_path) else ''

        info['catalog_path'] = _sf_find_nearby_catalog_for_path(filepath, info['root_path'])

        files_map = (index_data or {}).get('files', {}) if isinstance(index_data, dict) else {}

        norm_file = _norm_path(filepath)

        if isinstance(files_map, dict):

            info['is_indexed'] = norm_file in files_map or filepath in files_map

        try:

            stamp = os.path.getmtime(filepath)

            info['source_mtime_label'] = datetime.datetime.fromtimestamp(stamp).strftime('%Y-%m-%d %H:%M')

        except Exception:

            info['source_mtime_label'] = ''

    except Exception:

        pass

    return info





def _sf_publish_ready_state(source_info: dict) -> tuple[str, str]:

    info = dict(source_info or {})

    has_source = bool(info.get('has_source'))

    if not has_source:

        return 'NOT SET', ''

    preview_ready = bool(info.get('preview_path'))

    meta_ready = bool(info.get('meta_path'))

    catalog_ready = bool(info.get('catalog_path'))

    ready_count = sum((1 if preview_ready else 0, 1 if meta_ready else 0, 1 if catalog_ready else 0))

    if ready_count >= 3:

        return 'READY', _t('Preview + metadata + catalog are ready')

    if ready_count == 2:

        return 'REVIEW', _t('One publish sidecar is still missing')

    if ready_count == 1:

        return 'SETUP', _t('Only one publish sidecar is ready')

    return 'NOT READY', _t('Preview, metadata, and catalog are still missing')





def _sf_profile_fit_state(prefs, context, filepath: str, source_info: dict) -> tuple[str, str, int]:

    try:

        rows = _sf_profile_match_rows(prefs, context, filepath, source_info)

    except Exception:

        rows = []

    if not rows:

        return 'NOT SET', _t('No matching profile'), 0

    top = dict(rows[0] or {})

    profile = top.get('profile')

    score = int(top.get('score', 0) or 0)

    name = str(getattr(profile, 'name', '') or _t('Profile'))

    detail = f"{name} ({score}/100)"

    if score >= 75:

        return 'READY', detail, score

    if score >= 50:

        return 'REVIEW', detail, score

    return 'NOT FIT', detail, score





def _sf_root_coverage_rows(prefs, index_data: dict | None = None) -> list[dict]:

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    if index_data is None:

        try:

            index_data = _load_index()

        except Exception:

            index_data = {}

    files = (index_data or {}).get('files', {}) or {}

    rows: list[dict] = []

    for idx, root in enumerate(roots):

        root_path = _norm_path(getattr(root, 'path', '') or '')

        if not root_path:

            rows.append({

                'index': idx,

                'path': '',

                'name': _t('Not set'),

                'enabled': bool(getattr(root, 'enabled', True)),

                'priority': int(getattr(root, 'priority', 0) or 0),

                'indexed_count': 0,

                'exists': False,

            })

            continue

        prefix = root_path + os.sep

        count = 0

        for fp in files.keys():

            nfp = _norm_path(fp)

            if nfp == root_path or nfp.startswith(prefix):

                count += 1

        rows.append({

            'index': idx,

            'path': root_path,

            'name': os.path.basename(root_path) or root_path,

            'enabled': bool(getattr(root, 'enabled', True)),

            'priority': int(getattr(root, 'priority', 0) or 0),

            'indexed_count': count,

            'exists': os.path.isdir(root_path),

        })

    rows.sort(key=lambda it: (not it.get('enabled', True), -(it.get('priority', 0) or 0), (it.get('name') or '').lower()))

    return rows





def _sf_root_health_summary(prefs, index_data: dict | None = None) -> dict:

    rows = _sf_root_coverage_rows(prefs, index_data)

    summary = {

        'total': len(rows),

        'healthy': 0,

        'missing': 0,

        'disabled': 0,

        'empty': 0,

        'indexed_total': 0,

    }

    for row in rows:

        summary['indexed_total'] += int(row.get('indexed_count', 0) or 0)

        if not str(row.get('path') or '').strip():

            summary['empty'] += 1

        elif not bool(row.get('exists')):

            summary['missing'] += 1

        elif not bool(row.get('enabled', True)):

            summary['disabled'] += 1

        else:

            summary['healthy'] += 1

    return summary





def _sf_profile_intent_label(profile) -> str:

    mode = str(getattr(profile, 'mode', '') or '').upper()

    import_mode = str(getattr(profile, 'import_mode', '') or '').upper()

    if import_mode == 'APPEND' or mode == 'OBJECTS':

        return _t('Import')

    if import_mode == 'LINK_OVERRIDE':

        return _t('Publish Tool')

    return _t('Maintenance Tool')





def _sf_draw_root_status_badges(parent, prefs, index_data: dict | None = None, compact: bool = False):

    summary = _sf_root_health_summary(prefs, index_data)

    if not summary.get('total'):

        parent.label(text=_t('No library roots configured yet'))

        return

    grid = parent.grid_flow(columns=4 if not compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    badges = [

        (_t('Healthy Roots'), int(summary.get('healthy', 0)), 'CHECKMARK'),

        (_t('Missing Roots'), int(summary.get('missing', 0)), 'ERROR'),

        (_t('Disabled Roots'), int(summary.get('disabled', 0)), 'CANCEL'),

        (_t('Empty Roots'), int(summary.get('empty', 0)), 'BLANK1'),

    ]

    for title, value, icon in badges:

        box = grid.box()

        box.label(text=title, icon=icon)

        box.label(text=str(value), icon='BLANK1')





def _sf_source_readiness_items(filepath: str, source_info: dict, roots_ready: bool, index_ready: bool) -> list[dict]:

    has_source = bool(filepath and os.path.isfile(filepath))

    return [

        {

            'label': _t('Ready for import'),

            'ok': has_source,

            'detail': _t('Ready') if has_source else _t('Needs source'),

            'icon': 'IMPORT',

        },

        {

            'label': _t('Ready for maintenance'),

            'ok': bool(has_source and roots_ready and index_ready and source_info.get('inside_root') and source_info.get('is_indexed')),

            'detail': _t('Ready') if (has_source and roots_ready and index_ready and source_info.get('inside_root') and source_info.get('is_indexed')) else (_t('Needs roots') if not roots_ready or not source_info.get('inside_root') else (_t('Needs index') if not index_ready or not source_info.get('is_indexed') else _t('Needs source'))),

            'icon': 'TOOL_SETTINGS',

        },

        {

            'label': _t('Ready for publish'),

            'ok': bool(has_source and roots_ready and source_info.get('inside_root') and source_info.get('catalog_path') and source_info.get('preview_path') and source_info.get('meta_path')),

            'detail': _t('Ready') if (has_source and roots_ready and source_info.get('inside_root') and source_info.get('catalog_path') and source_info.get('preview_path') and source_info.get('meta_path')) else (_t('Missing sidecars') if has_source and (not source_info.get('preview_path') or not source_info.get('meta_path')) else (_t('Needs roots') if not roots_ready or not source_info.get('inside_root') else _t('Needs source'))),

            'icon': 'EXPORT',

        },

    ]





def _sf_draw_readiness_checklist(parent, context, compact: bool = False):

    prefs = _addon_prefs(context)

    wm = context.window_manager

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

    try:

        index = _load_index()

    except Exception:

        index = {}

    index_ready = bool(len((index or {}).get('files', {}) or {}))

    source_info = _sf_get_source_insights(prefs, filepath, index)

    grid = parent.grid_flow(columns=3 if not compact else 1, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in _sf_source_readiness_items(filepath, source_info, roots_ready, index_ready):

        box = grid.box()

        box.label(text=item.get('label', ''), icon=item.get('icon', 'CHECKMARK'))

        ok = bool(item.get('ok'))

        box.label(text=item.get('detail', ''), icon='CHECKMARK' if ok else 'ERROR')





def _sf_relationship_map_data(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool) -> dict:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    profile_pair = None

    try:

        ordered = _sf_profiles_for_goal(prefs, goal, context=context)

        profile_pair = ordered[0] if ordered else None

    except Exception:

        profile_pair = None

    enabled_roots = 0

    total_roots = 0

    try:

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        total_roots = len(roots)

        enabled_roots = sum(1 for root in roots if bool(getattr(root, 'enabled', True)))

    except Exception:

        pass

    coverage_label = _t('Needs source')

    if has_source:

        coverage_label = (source_info.get('root_name') or _t('Library Root')) if bool(source_info.get('inside_root')) else _t('Outside roots')

    if has_source and roots_ready:

        if bool(source_info.get('is_indexed')):

            index_label = _t('Ready')

        else:

            index_label = _t('Needs index')

    else:

        index_label = _t('Needs roots') if has_source else _t('Needs source')

    sidecar_bits = [

        f"P:{_sf_health_label(bool(source_info.get('preview_path')))}",

        f"M:{_sf_health_label(bool(source_info.get('meta_path')))}",

        f"C:{_sf_health_label(bool(source_info.get('catalog_path')))}",

    ] if has_source else [_t('Needs source')]

    profile_name = _t('No matching profile')

    profile_summary = ''

    profile_index = -1

    if profile_pair:

        profile_index, profile = profile_pair

        profile_name = getattr(profile, 'name', '') or _ui_text(f"Profile {profile_index+1}", f'プロファイル {profile_index + 1}')

        profile_summary = _sf_profile_summary(profile)

    return {

        'has_source': has_source,

        'source_label': os.path.basename(filepath) if has_source else _t('Not set'),

        'source_path': filepath,

        'coverage_label': coverage_label,

        'coverage_detail': f"{_t('Enabled Roots')}: {enabled_roots}/{max(total_roots, 0)}" if total_roots else _t('No library roots configured yet'),

        'index_label': index_label,

        'index_detail': _sf_bool_status_label(bool(source_info.get('is_indexed'))),

        'sidecars_label': '|'.join(sidecar_bits),

        'profile_label': profile_name,

        'profile_summary': profile_summary,

        'profile_index': profile_index,

        'goal': goal,

        'inside_root': bool(source_info.get('inside_root')),

        'roots_ready': bool(roots_ready),

        'index_ready': bool(index_ready),

    }





def _sf_draw_relationship_map(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, compact: bool = False):

    data = _sf_relationship_map_data(context, prefs, filepath, source_info, roots_ready, index_ready)

    box = parent.box()

    box.label(text=_t('Source Relationship'), icon='SHADERFX')

    grid = box.grid_flow(columns=2 if compact else 5, row_major=True, even_columns=True, even_rows=False, align=True)



    src = grid.box()

    src.label(text=_t('Source'), icon='FILE_BLEND')

    src.label(text=data.get('source_label', _t('Not set')), icon='CHECKMARK' if data.get('has_source') else 'ERROR')

    src.label(text=os.path.dirname(data.get('source_path', '')) if data.get('has_source') else _t('Needs source'), icon='FILE_FOLDER', translate=False)

    if data.get('has_source'):

        src.operator(SF_OT_source_browser_import.bl_idname, text=_t('Import'), icon='IMPORT')

    else:

        src.operator(SF_OT_source_browser_open_folder_2.bl_idname, text=_t('Open Folder'), icon='FILE_BLEND')



    cov = grid.box()

    cov.label(text=_t('Coverage'), icon='FILE_FOLDER')

    cov.label(text=data.get('coverage_label', ''), icon='CHECKMARK' if data.get('inside_root') else 'ERROR')

    cov.label(text=data.get('coverage_detail', ''))

    if data.get('has_source') and not data.get('inside_root'):

        op = cov.operator(SF_OT_library_roots_add_source_folder_as_root.bl_idname, text=_t('Add Source Folder as Root'), icon='FILE_FOLDER')

        _sf_safe_set_operator_property(op, 'mode', 'CURRENT_FOLDER')

    else:

        cov.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')



    idx = grid.box()

    idx.label(text=_t('Indexed Source'), icon='FILE_REFRESH')

    idx.label(text=data.get('index_label', ''), icon='CHECKMARK' if data.get('index_label') == _t('Ready') else 'ERROR')

    idx.label(text=data.get('index_detail', ''))

    idx.operator(SF_OT_asset_library_rebuild_index.bl_idname, text=_t('Rebuild Index'), icon='FILE_REFRESH')



    sc = grid.box()

    sc.label(text=_t('Sidecars'), icon='IMAGE_DATA')

    sc.label(text=data.get('sidecars_label', _t('Needs source')))

    op_row = sc.row(align=True)

    op_row.operator(SF_OT_asset_preview_batch_preview.bl_idname, text=_t('Batch Preview'), icon='RENDER_STILL')

    op_row.operator(SF_OT_asset_library_generate_catalog_draft.bl_idname, text=_t('Generate Catalog Draft'), icon='TEXT')



    prof = grid.box()

    prof.label(text=_t('Matching profile'), icon='PRESET')

    prof.label(text=data.get('profile_label', _t('No matching profile')), icon='PRESET' if data.get('profile_index', -1) >= 0 else 'ERROR')

    if data.get('profile_summary'):

        prof.label(text=data.get('profile_summary', ''), icon='BLANK1')

    if data.get('profile_index', -1) >= 0:

        row = prof.row(align=True)

        op = row.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=_t('Apply Profile'), icon='CHECKMARK')

        _sf_safe_set_operator_property(op, 'index', int(data.get('profile_index', -1)))

        op = row.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text=_t('Apply & Open'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'index', int(data.get('profile_index', -1)))

    else:

        prof.operator(SF_OT_workspace_profile_seed_default_profiles.bl_idname, text=_t('Seed Default Profiles'), icon='PRESET')

    return box





def _sf_profile_overview_counts(prefs, context=None) -> dict:

    profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

    visible = [profile for profile in profiles if _sf_profile_matches_filter(profile, prefs, context=context)]

    goal = _sf_current_session_goal(context or bpy.context)

    by_goal = {'EXPLORE': 0, 'IMPORT': 0, 'MAINTAIN': 0, 'PUBLISH': 0, 'RECOVER': 0}

    goal_matches = 0

    pinned = 0

    for profile in visible:

        if bool(getattr(profile, 'pinned', False)):

            pinned += 1

        if _sf_profile_matches_goal(profile, goal):

            goal_matches += 1

        tag = str(_sf_profile_tag_label(profile) or '').upper()

        if tag in by_goal:

            by_goal[tag] += 1

    return {

        'total': len(profiles),

        'visible': len(visible),

        'pinned': pinned,

        'goal_matches': goal_matches,

        'by_goal': by_goal,

    }





def _sf_draw_profile_overview(parent, prefs, context=None, compact: bool = False):

    counts = _sf_profile_overview_counts(prefs, context=context)

    box = parent.box()

    box.label(text=_t('Profile Summary'), icon='PRESET')

    grid = box.grid_flow(columns=2 if compact else 4, row_major=True, even_columns=True, even_rows=False, align=True)

    cards = [

        (_t('Total Profiles'), counts.get('total', 0), 'PRESET'),

        (_t('Visible Profiles'), counts.get('visible', 0), 'VIEWZOOM'),

        (_t('Pinned Profiles'), counts.get('pinned', 0), 'FUND'),

        (_t('Current Goal Match'), counts.get('goal_matches', 0), 'CHECKMARK'),

    ]

    for title, value, icon in cards:

        c = grid.box()

        c.label(text=title, icon=icon)

        c.label(text=str(value), icon='BLANK1')

    tags = box.row(align=True)

    for goal, icon in [('EXPLORE', 'VIEWZOOM'), ('IMPORT', 'IMPORT'), ('MAINTAIN', 'TOOL_SETTINGS'), ('PUBLISH', 'EXPORT'), ('RECOVER', 'CHECKMARK')]:

        tags.label(text=f"{_t(goal.title())}: {counts.get('by_goal', {}).get(goal, 0)}", icon=icon)

    return box





def _sf_draw_goal_decks(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False):

    box = parent.box()

    box.label(text=_t('Goal Decks'), icon='MENU_PANEL')

    current_goal = _sf_current_session_goal(context)

    grid = box.grid_flow(columns=2 if compact else 5, row_major=True, even_columns=True, even_rows=False, align=True)

    for goal, icon in [('EXPLORE', 'VIEWZOOM'), ('IMPORT', 'IMPORT'), ('MAINTAIN', 'TOOL_SETTINGS'), ('PUBLISH', 'EXPORT'), ('RECOVER', 'CHECKMARK')]:

        data = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal)

        card = grid.box()

        card.label(text=_t(goal.title()), icon=icon)

        if goal == current_goal:

            card.label(text=_t('Current Goal'), icon='CHECKMARK')

        card.label(text=data.get('status', ''), icon='CHECKMARK' if not data.get('blocker') else 'ERROR')

        if data.get('profile'):

            idx, profile = data.get('profile')

            card.label(text=getattr(profile, 'name', '') or _ui_text(f"Profile {idx+1}", f'プロファイル {idx + 1}'), icon='PRESET', translate=False)

        else:

            card.label(text=_t('No matching profile'))

        if data.get('blocker') and not compact:

            card.label(text=data.get('blocker', ''), icon='ERROR')

        row = card.row(align=True)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_set_goal, text=_t('Set goal'), icon='BOOKMARKS')

        _sf_safe_set_operator_property(op, 'goal', goal)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_open_goal, text=_t('Open deck'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'goal', goal)

    return box





def _sf_current_session_goal(context) -> str:

    try:

        value = str(getattr(context.window_manager, 'sf_session_goal', 'IMPORT') or 'IMPORT').upper()

    except Exception:

        value = 'IMPORT'

    return value if value in {'EXPLORE', 'IMPORT', 'MAINTAIN', 'PUBLISH', 'RECOVER'} else 'IMPORT'





def _sf_goal_icon(goal: str) -> str:

    return {

        'EXPLORE': 'VIEWZOOM',

        'IMPORT': 'IMPORT',

        'MAINTAIN': 'TOOL_SETTINGS',

        'PUBLISH': 'EXPORT',

        'RECOVER': 'CHECKMARK',

    }.get(str(goal or '').upper(), 'BOOKMARKS')





def _sf_profile_matches_goal(profile, goal: str) -> bool:

    goal = str(goal or '').upper()

    tag = str(_sf_profile_tag_label(profile) or '').upper()

    import_mode = str(getattr(profile, 'import_mode', '') or '').upper()

    mode = str(getattr(profile, 'mode', '') or '').upper()

    if goal == 'EXPLORE':

        return tag == 'EXPLORE' or mode in {'MATERIALS', 'NODE_GROUPS', 'ACTIONS', 'WORLDS'}

    if goal == 'IMPORT':

        return tag == 'IMPORT' or import_mode == 'APPEND' or mode == 'OBJECTS'

    if goal == 'MAINTAIN':

        return tag == 'MAINTAIN' or import_mode == 'LINK'

    if goal == 'PUBLISH':

        return tag == 'PUBLISH' or import_mode == 'LINK_OVERRIDE'

    if goal == 'RECOVER':

        return tag == 'RECOVER' or str(getattr(profile, 'notes', '') or '').lower().find('recover') != -1

    return False





def _sf_activity_entries(context) -> list[dict]:

    raw = ''

    try:

        raw = str(getattr(context.window_manager, 'sf_activity_log', '') or '')

    except Exception:

        raw = ''

    if not raw:

        return []

    try:

        data = json.loads(raw)

    except Exception:

        return []

    if not isinstance(data, list):

        return []

    entries = []

    for item in data:

        if isinstance(item, dict):

            entries.append({

                'time': str(item.get('time', '') or ''),

                'title': str(item.get('title', '') or ''),

                'detail': str(item.get('detail', '') or ''),

                'icon': str(item.get('icon', 'NONE') or 'NONE'),

            })

    return entries





def _sf_append_activity(context, title: str, detail: str = '', icon: str = 'NONE'):

    if context is None:

        return

    prefs = _addon_prefs(context)

    limit = int(getattr(prefs, 'activity_log_limit', 24) or 24) if prefs else 24

    limit = max(5, min(120, limit))

    try:

        stamp = datetime.datetime.now().strftime('%H:%M:%S')

    except Exception:

        stamp = ''

    entries = _sf_activity_entries(context)

    entries.insert(0, {

        'time': stamp,

        'title': str(title or '').strip(),

        'detail': str(detail or '').strip(),

        'icon': str(icon or 'NONE'),

    })

    entries = [it for it in entries if it.get('title')]

    try:

        context.window_manager.sf_activity_log = json.dumps(entries[:limit], ensure_ascii=False)

    except Exception:

        pass





def _sf_draw_activity_log(parent, context, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Recent Activity'), icon='TIME')

    entries = _sf_activity_entries(context)

    if not entries:

        box.label(text=_t('No activity recorded yet'))

    else:

        limit = 3 if compact else 7

        for item in entries[:limit]:

            row = box.row(align=True)

            row.label(text=f"[{item.get('time','')}] {item.get('title','')}", icon=item.get('icon', 'NONE'))

            detail = str(item.get('detail', '') or '').strip()

            if detail:

                box.label(text=detail, icon='BLANK1')

    _sf_draw_action_block(

        box,

        primary_actions=[

            (SF_OT_reference_manager_export_activity_log.bl_idname, 'Export Activity Log', 'EXPORT', {}),

        ],

        danger_actions=[

            (SF_OT_reference_manager_clear_activity_log.bl_idname, 'Clear Activity Log', 'TRASH', {}),

        ],

    )

    return box





def _sf_profile_matches_filter(profile, prefs, context=None) -> bool:

    if not profile:

        return False

    prefs = prefs or _addon_prefs(context or bpy.context)

    mode = str(getattr(prefs, 'workspace_profile_filter_mode', 'ALL') or 'ALL').upper() if prefs else 'ALL'

    text_filter = str(getattr(prefs, 'workspace_profile_filter_text', '') or '').strip().lower() if prefs else ''

    goal = _sf_current_session_goal(context or bpy.context)

    if mode == 'GOAL' and not _sf_profile_matches_goal(profile, goal):

        return False

    if mode == 'PINNED' and not bool(getattr(profile, 'pinned', False)):

        return False

    if mode == 'ACTIVE_TAG':

        tag = str(_sf_profile_tag_label(profile) or '').strip().upper()

        if tag != goal:

            return False

    if text_filter:

        haystack = '|'.join([

            str(getattr(profile, 'name', '') or ''),

            str(_sf_profile_tag_label(profile) or ''),

            str(getattr(profile, 'notes', '') or ''),

            str(getattr(profile, 'mode', '') or ''),

            str(getattr(profile, 'import_mode', '') or ''),

            str(getattr(profile, 'placement', '') or ''),

        ]).lower()

        if text_filter not in haystack:

            return False

    return True





def _sf_draw_profile_filter_bar(parent, prefs, context=None):

    box = parent.box()

    box.label(text=_t('Profile filters'), icon='VIEWZOOM')

    if not prefs:

        box.label(text=_t('No workspace profiles yet'))

        return box

    row = box.row(align=True)

    row.prop(prefs, 'workspace_profile_filter_text', text=_t('Profile Search'))

    row.prop(prefs, 'workspace_profile_filter_mode', text=_t('Profile Filter'))

    row.operator(SF_OT_workspace_profile_clear_filter.bl_idname, text=_t('Clear Filter'), icon='X')

    visible_count = len(_sf_profiles_for_goal(prefs, _sf_current_session_goal(context or bpy.context), context=context))

    total_count = len(list(getattr(prefs, 'workspace_profiles', []) or [])) if prefs else 0

    box.label(text=f"{_t('Visible Profiles')}: {visible_count}/{total_count}")

    return box





def _sf_root_attention_rows(prefs, context=None, source_info: dict | None = None) -> list[dict]:

    rows = []

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    enabled = [r for r in roots if bool(getattr(r, 'enabled', True))]

    disabled = [r for r in roots if not bool(getattr(r, 'enabled', True))]

    missing = [r for r in roots if str(getattr(r, 'path', '') or '').strip() and not os.path.isdir(_norm_path(getattr(r, 'path', '') or ''))]

    empty = [r for r in roots if not str(getattr(r, 'path', '') or '').strip()]

    seen = set()

    dup_count = 0

    for r in roots:

        path = _norm_path(getattr(r, 'path', '') or '')

        if not path:

            continue

        if path in seen:

            dup_count += 1

        seen.add(path)

    if source_info and not bool(source_info.get('inside_root')):

        rows.append({'title': _t('Current source is outside all enabled roots'), 'icon': 'ERROR'})

    if disabled and enabled:

        rows.append({'title': _t('Disabled roots are hiding part of the library coverage'), 'icon': 'CANCEL'})

    if missing:

        rows.append({'title': _t('Missing folders are still registered as library roots'), 'icon': 'ERROR'})

    if dup_count:

        rows.append({'title': _t('Duplicate root paths should be cleaned for predictable diagnostics'), 'icon': 'ERROR'})

    if empty:

        rows.append({'title': _t('Empty root rows should be removed to keep maintenance results cleaner'), 'icon': 'NONE'})

    return rows





def _sf_draw_root_attention_panel(parent, context, prefs, index=None, source_info: dict | None = None, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Root Attention'), icon='ERROR')

    rows = _sf_root_attention_rows(prefs, context=context, source_info=source_info or {})

    if not rows:

        box.label(text=_t('No blocker detected'), icon='CHECKMARK')

    else:

        for item in rows[:(2 if compact else 5)]:

            box.label(text=item.get('title', ''), icon=item.get('icon', 'NONE'))

    acts = box.row(align=True)

    acts.operator(SF_OT_workspace_command_fix_all.bl_idname, text=_t('Fix All'), icon='TOOL_SETTINGS')

    acts.operator(SF_OT_asset_library_repair_roots.bl_idname, text=_t('Repair Roots'), icon='PREFERENCES')

    acts.operator(SF_OT_library_roots_clean_roots.bl_idname, text=_t('Clean Roots'), icon='BRUSH_DATA')

    return box





def _sf_profile_note_text(profile) -> str:

    note = str(getattr(profile, 'notes', '') or '').strip()

    if note:

        return note

    tag = str(_sf_profile_tag_label(profile) or '').lower()

    defaults = {

        'import': _t('Ready to browse editable local copies from one source file'),

        'maintain': _t('Ready to inspect or maintain library content with safer external references'),

        'publish': _t('Ready to publish, version, and test linked asset packages'),

        'explore': _t('Browse catalog or index results before choosing a concrete import or publish step'),

        'recover': _t('Use this setup first when roots, index data, or source coverage need repair before normal work can continue'),

    }

    return defaults.get(tag, '')





def _sf_profiles_for_goal(prefs, goal: str, context=None):

    profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

    ranked = []

    for idx, profile in enumerate(profiles):

        if not _sf_profile_matches_filter(profile, prefs, context=context):

            continue

        ranked.append((

            0 if _sf_profile_matches_goal(profile, goal) else 1,

            0 if bool(getattr(profile, 'pinned', False)) else 1,

            str(_sf_profile_tag_label(profile) or '').lower(),

            str(getattr(profile, 'name', '') or '').lower(),

            idx,

            profile,

        ))

    ranked.sort(key=lambda item: item[:5])

    return [(idx, profile) for _a, _b, _c, _d, idx, profile in ranked]





def _sf_draw_profile_cards(parent, prefs, max_cards: int = 3, include_open: bool = True, compact: bool = False, context=None):

    ordered = _sf_profiles_for_goal(prefs, _sf_current_session_goal(context or bpy.context), context=context)

    if not ordered:

        parent.label(text=_t('No profiles match the current filter') if getattr(prefs, 'workspace_profile_filter_text', '') or str(getattr(prefs, 'workspace_profile_filter_mode', 'ALL') or 'ALL').upper() != 'ALL' else _t('No workspace profiles yet'))

        return

    grid = parent.grid_flow(columns=1 if compact else min(max_cards, 3), row_major=True, even_columns=True, even_rows=False, align=True)

    for idx, profile in ordered[:max_cards]:

        box = grid.box()

        header = box.row(align=True)

        header.label(text=getattr(profile, 'name', '') or _ui_text(f'Profile {idx+1}', f'プロファイル {idx + 1}'), icon='PRESET', translate=False)

        pin_icon = 'FUND' if bool(getattr(profile, 'pinned', False)) else 'SOLO_OFF'

        try:

            op = header.operator(SF_OT_workspace_profile_pin.bl_idname, text='', icon=pin_icon, emboss=True)

            _sf_safe_set_operator_property(op, 'index', idx)

        except Exception:

            pass

        box.label(text=_sf_profile_summary(profile), icon='BLANK1')

        note = _sf_profile_note_text(profile)

        if note:

            box.label(text=note)

        match_row = box.row(align=True)

        match_row.label(text=f"{_t('Tag')}: {_sf_profile_tag_label(profile)}", icon='BOOKMARKS')

        match_row.label(text=f"{_t('Goal Matches')}: {_sf_bool_status_label(_sf_profile_matches_goal(profile, _sf_current_session_goal(context or bpy.context)))}", icon='CHECKMARK' if _sf_profile_matches_goal(profile, _sf_current_session_goal(context or bpy.context)) else 'BLANK1')

        box.label(text=f"{_t('Recommended tool')}: {_sf_profile_intent_label(profile)}")

        row = box.row(align=True)

        op = row.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=_t('Apply Profile'), icon='CHECKMARK')

        _sf_safe_set_operator_property(op, 'index', idx)

        if include_open:

            op = row.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text=_t('Apply & Open'), icon='PLAY')

            _sf_safe_set_operator_property(op, 'index', idx)

        dup = box.row(align=True)

        op = dup.operator(SF_OT_workspace_profile_edit_profile.bl_idname, text=_t('Edit Profile'), icon='GREASEPENCIL')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = dup.operator(SF_OT_workspace_profile_duplicate_profile.bl_idname, text=_t('Duplicate Profile'), icon='DUPLICATE')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = dup.operator(SF_OT_workspace_profile_export_workspace_profiles.bl_idname, text=_t('Export Workspace Profiles'), icon='EXPORT')

        _sf_safe_set_operator_property(op, 'scope', 'ACTIVE')

        _sf_safe_set_operator_property(op, 'index', idx)





def _sf_find_workspace_profile(prefs, name: str):

    if not prefs or not name:

        return None, -1

    for idx, profile in enumerate(list(getattr(prefs, 'workspace_profiles', []) or [])):

        if str(getattr(profile, 'name', '') or '') == str(name):

            return profile, idx

    return None, -1



_SF_WORKSPACE_PROFILE_FIELDS = (

    'tag', 'notes', 'pinned', 'mode', 'import_mode', 'strict_loader', 'include_dependencies', 'bake_world', 'clear_parent',

    'clear_constraints', 'prefix', 'collision', 'apply_prefix_to_linked', 'put_in_collection',

    'collection_name_mode', 'collection_name', 'placement', 'offset', 'grid_spacing', 'grid_columns',

    'select_imported', 'frame_view',

)





def _sf_profile_to_dict(profile) -> dict:

    data = {'name': str(getattr(profile, 'name', '') or '')}

    for field in _SF_WORKSPACE_PROFILE_FIELDS:

        try:

            value = getattr(profile, field)

            if field in {'offset', 'grid_spacing'}:

                value = list(value[:3])

            data[field] = value

        except Exception:

            pass

    return data





def _sf_profile_from_dict(profile, data: dict):

    if not profile or not isinstance(data, dict):

        return

    for field in ('name',) + _SF_WORKSPACE_PROFILE_FIELDS:

        if field not in data:

            continue

        try:

            value = data[field]

            if field in {'offset', 'grid_spacing'}:

                value = tuple((value or [0.0, 0.0, 0.0])[:3])

            setattr(profile, field, value)

        except Exception:

            pass





def _sf_unique_workspace_profile_name(prefs, base_name: str) -> str:

    base_name = str(base_name or _t('Local Edit')).strip() or _t('Local Edit')

    names = {str(getattr(it, 'name', '') or '') for it in list(getattr(prefs, 'workspace_profiles', []) or [])}

    if base_name not in names:

        return base_name

    i = 2

    while True:

        candidate = f"{base_name} {i}"

        if candidate not in names:

            return candidate

        i += 1





def _sf_move_collection_item(collection, from_index: int, to_index: int) -> bool:

    try:

        if from_index == to_index:

            return False

        if from_index < 0 or to_index < 0 or from_index >= len(collection) or to_index >= len(collection):

            return False

        collection.move(from_index, to_index)

        return True

    except Exception:

        return False





def _sf_reorder_collection(collection, desired_old_indices: list[int]) -> bool:

    try:

        current = list(range(len(collection)))

        changed = False

        for target, old_idx in enumerate(desired_old_indices):

            current_pos = current.index(old_idx)

            if current_pos != target:

                collection.move(current_pos, target)

                value = current.pop(current_pos)

                current.insert(target, value)

                changed = True

        return changed

    except Exception:

        return False





def _sf_root_sort_key(item):

    idx, root = item

    path = _norm_path(getattr(root, 'path', '') or '')

    return (not bool(getattr(root, 'enabled', True)), -(int(getattr(root, 'priority', 0) or 0)), path.lower())





def _sf_sort_library_roots_in_place(prefs) -> bool:

    if not prefs:

        return False

    roots = list(enumerate(list(getattr(prefs, 'library_roots', []) or [])))

    desired = [idx for idx, _root in sorted(roots, key=_sf_root_sort_key)]

    return _sf_reorder_collection(prefs.library_roots, desired)





def _sf_capture_current_profile(profile, wm):

    if not profile or not wm:

        return

    if not str(getattr(profile, 'tag', '') or '').strip():

        goal = str(getattr(wm, 'sf_session_goal', '') or '').upper()

        tag_map = {'EXPLORE': 'Explore', 'IMPORT': 'Import', 'MAINTAIN': 'Maintain', 'PUBLISH': 'Publish', 'RECOVER': 'Recover'}

        profile.tag = tag_map.get(goal, _sf_profile_tag_label(profile) or 'Import')

    profile.mode = str(getattr(wm, 'sf_mode', 'OBJECTS') or 'OBJECTS')

    profile.import_mode = str(getattr(wm, 'sf_import_mode', 'APPEND') or 'APPEND')

    profile.strict_loader = bool(getattr(wm, 'sf_strict_loader', False))

    profile.include_dependencies = bool(getattr(wm, 'sf_include_dependencies', True))

    profile.bake_world = bool(getattr(wm, 'sf_bake_world', False))

    profile.clear_parent = bool(getattr(wm, 'sf_clear_parent', True))

    profile.clear_constraints = bool(getattr(wm, 'sf_clear_constraints', False))

    profile.prefix = str(getattr(wm, 'sf_prefix', '') or '')

    profile.collision = str(getattr(wm, 'sf_collision', 'DUPLICATE') or 'DUPLICATE')

    profile.apply_prefix_to_linked = bool(getattr(wm, 'sf_apply_prefix_to_linked', False))

    profile.put_in_collection = bool(getattr(wm, 'sf_put_in_collection', True))

    profile.collection_name_mode = str(getattr(wm, 'sf_collection_name_mode', 'FILE') or 'FILE')

    profile.collection_name = str(getattr(wm, 'sf_collection_name', '') or '')

    profile.placement = str(getattr(wm, 'sf_placement', 'ORIGINAL') or 'ORIGINAL')

    try:

        profile.offset = tuple(getattr(wm, 'sf_offset', (0.0, 0.0, 0.0))[:3])

        profile.grid_spacing = tuple(getattr(wm, 'sf_grid_spacing', (2.0, 2.0, 0.0))[:3])

    except Exception:

        pass

    profile.grid_columns = int(getattr(wm, 'sf_grid_columns', 5) or 5)

    profile.select_imported = bool(getattr(wm, 'sf_select_imported', True))

    profile.frame_view = bool(getattr(wm, 'sf_frame_view', False))

    if not str(getattr(profile, 'notes', '') or '').strip():

        profile.notes = _sf_profile_note_text(profile)





def _sf_apply_workspace_profile(profile, wm):

    if not profile or not wm:

        return

    try:

        wm.sf_mode = str(getattr(profile, 'mode', 'OBJECTS') or 'OBJECTS')

    except Exception:

        pass

    try:

        wm.sf_import_mode = str(getattr(profile, 'import_mode', 'APPEND') or 'APPEND')

    except Exception:

        pass

    wm.sf_strict_loader = bool(getattr(profile, 'strict_loader', False))

    wm.sf_include_dependencies = bool(getattr(profile, 'include_dependencies', True))

    wm.sf_bake_world = bool(getattr(profile, 'bake_world', False))

    wm.sf_clear_parent = bool(getattr(profile, 'clear_parent', True))

    wm.sf_clear_constraints = bool(getattr(profile, 'clear_constraints', False))

    wm.sf_prefix = str(getattr(profile, 'prefix', '') or '')

    try:

        wm.sf_collision = str(getattr(profile, 'collision', 'DUPLICATE') or 'DUPLICATE')

    except Exception:

        pass

    wm.sf_apply_prefix_to_linked = bool(getattr(profile, 'apply_prefix_to_linked', False))

    wm.sf_put_in_collection = bool(getattr(profile, 'put_in_collection', True))

    try:

        wm.sf_collection_name_mode = str(getattr(profile, 'collection_name_mode', 'FILE') or 'FILE')

    except Exception:

        pass

    wm.sf_collection_name = str(getattr(profile, 'collection_name', '') or '')

    try:

        wm.sf_placement = str(getattr(profile, 'placement', 'ORIGINAL') or 'ORIGINAL')

    except Exception:

        pass

    try:

        wm.sf_offset = tuple(getattr(profile, 'offset', (0.0, 0.0, 0.0))[:3])

        wm.sf_grid_spacing = tuple(getattr(profile, 'grid_spacing', (2.0, 2.0, 0.0))[:3])

    except Exception:

        pass

    wm.sf_grid_columns = int(getattr(profile, 'grid_columns', 5) or 5)

    wm.sf_select_imported = bool(getattr(profile, 'select_imported', True))

    wm.sf_frame_view = bool(getattr(profile, 'frame_view', False))





def _sf_add_library_root_path(prefs, path: str) -> tuple[str, bool]:

    path = _norm_path(path or '')

    if not prefs or not path or not os.path.isdir(path):

        return path, False

    for root in list(getattr(prefs, 'library_roots', []) or []):

        if _norm_path(getattr(root, 'path', '') or '') == path:

            root.enabled = True

            return path, False

    item = prefs.library_roots.add()

    item.path = path

    item.enabled = True

    try:

        item.priority = max([int(getattr(r, 'priority', 0) or 0) for r in prefs.library_roots[:-1]] + [0])

    except Exception:

        item.priority = 0

    return path, True





class SF_OT_workspace_profile_save_current_setup(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_save_current_setup'

    bl_label = 'Save Current Setup'

    bl_description = 'Capture the current Smart File browser settings as a reusable workspace profile'

    bl_options = {'UNDO', 'INTERNAL'}



    profile_name: StringProperty(name='Profile name', default="", options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        name = str(self.profile_name or getattr(prefs, 'workspace_profile_name', '') or '').strip()

        if not name:

            name = _t('Local Edit')

        profile, idx = _sf_find_workspace_profile(prefs, name)

        if profile is None:

            profile = prefs.workspace_profiles.add()

            profile.name = name

        _sf_capture_current_profile(profile, context.window_manager)

        profile.name = name

        prefs.workspace_profile_name = name

        self.report({'INFO'}, f"{_t('Profile saved')}: {name}")

        _sf_append_activity(context, _t('Captured current setup as a workspace profile'), name, 'ADD')

        return {'FINISHED'}





class SF_OT_workspace_profile_apply_profile(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_apply_profile'

    bl_label = 'Apply Profile'

    bl_description = 'Apply a saved workspace profile to the current Smart File browser settings'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = list(getattr(prefs, 'workspace_profiles', []) or [])

        if self.index < 0 or self.index >= len(profiles):

            return {'CANCELLED'}

        profile = profiles[self.index]

        _sf_apply_workspace_profile(profile, context.window_manager)

        try:

            _reload_items(context)

        except Exception:

            pass

        self.report({'INFO'}, f"{_t('Profile applied')}: {getattr(profile, 'name', '')}")

        _sf_append_activity(context, _t('Applied workspace profile'), getattr(profile, 'name', ''), 'CHECKMARK')

        return {'FINISHED'}





class SF_OT_workspace_profile_apply_and_open(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_apply_and_open'

    bl_label = 'Apply & Open'

    bl_description = 'Apply the selected workspace profile and immediately open the most relevant next tool for that setup'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = list(getattr(prefs, 'workspace_profiles', []) or [])

        if self.index < 0 or self.index >= len(profiles):

            return {'CANCELLED'}

        profile = profiles[self.index]

        _sf_apply_workspace_profile(profile, context.window_manager)

        try:

            _reload_items(context)

        except Exception:

            pass

        filepath = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        import_mode = str(getattr(profile, 'import_mode', '') or '').upper()

        mode = str(getattr(profile, 'mode', '') or '').upper()

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        opened = False

        if has_source and (import_mode == 'APPEND' or mode == 'OBJECTS'):

            try:

                bpy.ops.import_scene.sfs_source_browser_import('INVOKE_DEFAULT')

                opened = True

            except Exception:

                pass

        elif import_mode == 'LINK_OVERRIDE' and has_source:

            try:

                bpy.ops.import_scene.sfs_source_browser_import('INVOKE_DEFAULT')

                opened = True

            except Exception:

                pass

        elif roots_ready:

            try:

                bpy.ops.import_scene.sfs_reference_manager_open('INVOKE_DEFAULT')

                opened = True

            except Exception:

                pass

        if not opened:

            try:

                bpy.ops.import_scene.sfs_source_browser_open_folder_2('INVOKE_DEFAULT')

                opened = True

            except Exception:

                pass

        self.report({'INFO'}, f"{_t('Profile applied and tool opened')}: {getattr(profile, 'name', '')}")

        _sf_append_activity(context, _t('Applied workspace profile and opened the next tool'), getattr(profile, 'name', ''), 'PLAY')

        return {'FINISHED'}





class SF_OT_workspace_profile_remove_profile(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_remove_profile'

    bl_label = 'Remove Profile'

    bl_description = 'Remove a saved workspace profile from the Smart File N-panel settings'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})



    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        if self.index < 0 or self.index >= len(getattr(prefs, 'workspace_profiles', [])):

            return {'CANCELLED'}

        name = str(getattr(prefs.workspace_profiles[self.index], 'name', '') or '')

        prefs.workspace_profiles.remove(self.index)

        self.report({'INFO'}, f"{_t('Profile removed')}: {name}")

        _sf_append_activity(context, _t('Remove profile'), name, 'X')

        return {'FINISHED'}





class SF_OT_workspace_profile_seed_default_profiles(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_seed_default_profiles'

    bl_label = 'Seed Default Profiles'

    bl_description = 'Create curated starter profiles for local edit, linked review, and publish preparation workflows'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        seed = [

            (_t('Local Edit'), dict(tag='Import', notes=_t('Ready to browse editable local copies from one source file'), pinned=True, mode='OBJECTS', import_mode='APPEND', strict_loader=False, include_dependencies=True, bake_world=False, clear_parent=True, clear_constraints=False, collision='DUPLICATE', placement='ORIGINAL', put_in_collection=True, collection_name_mode='FILE', apply_prefix_to_linked=False, select_imported=True, frame_view=False)),

            (_t('Review Linked'), dict(tag='Maintain', notes=_t('Ready to inspect or maintain library content with safer external references'), pinned=True, mode='COLLECTIONS', import_mode='LINK', strict_loader=True, include_dependencies=False, bake_world=False, clear_parent=True, clear_constraints=False, collision='REUSE', placement='ORIGINAL', put_in_collection=True, collection_name_mode='FILE', apply_prefix_to_linked=False, select_imported=True, frame_view=False)),

            (_t('Publish Prep'), dict(tag='Publish', notes=_t('Ready to publish, version, and test linked asset packages'), pinned=True, mode='COLLECTIONS', import_mode='LINK_OVERRIDE', strict_loader=True, include_dependencies=False, bake_world=False, clear_parent=True, clear_constraints=False, collision='REUSE', placement='ORIGINAL', put_in_collection=True, collection_name_mode='FILE', apply_prefix_to_linked=False, select_imported=True, frame_view=False)),

            (_t('Explore Library'), dict(tag='Explore', notes=_t('Browse catalog or index results before choosing a concrete import or publish step'), pinned=False, mode='MATERIALS', import_mode='APPEND', strict_loader=False, include_dependencies=False, bake_world=False, clear_parent=True, clear_constraints=False, collision='DUPLICATE', placement='ORIGINAL', put_in_collection=False, collection_name_mode='FILE', apply_prefix_to_linked=False, select_imported=False, frame_view=False)),

            (_t('Recovery Audit'), dict(tag='Recover', notes=_t('Use this setup first when roots, index data, or source coverage need repair before normal work can continue'), pinned=True, mode='COLLECTIONS', import_mode='LINK', strict_loader=True, include_dependencies=False, bake_world=False, clear_parent=True, clear_constraints=False, collision='REUSE', placement='ORIGINAL', put_in_collection=False, collection_name_mode='FILE', apply_prefix_to_linked=False, select_imported=False, frame_view=False)),

        ]

        created = 0

        for name, values in seed:

            profile, idx = _sf_find_workspace_profile(prefs, name)

            if profile is None:

                profile = prefs.workspace_profiles.add()

                profile.name = name

                created += 1

            for key, value in values.items():

                try:

                    setattr(profile, key, value)

                except Exception:

                    pass

        self.report({'INFO'}, f"{_t('Default profiles created')}: {created}")

        return {'FINISHED'}





class SF_OT_workspace_profile_duplicate_profile(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_duplicate_profile'

    bl_label = 'Duplicate Profile'

    bl_description = 'Duplicate the selected workspace profile so it can be adjusted without overwriting the original'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = getattr(prefs, 'workspace_profiles', None)

        if profiles is None or self.index < 0 or self.index >= len(profiles):

            return {'CANCELLED'}

        source = profiles[self.index]

        new_profile = profiles.add()

        _sf_profile_from_dict(new_profile, _sf_profile_to_dict(source))

        new_profile.name = _sf_unique_workspace_profile_name(prefs, str(getattr(source, 'name', '') or _t('Local Edit')) + 'Copy')

        try:

            profiles.move(len(profiles) - 1, min(len(profiles) - 1, self.index + 1))

        except Exception:

            pass

        try:

            prefs.workspace_profile_active_index = min(len(profiles) - 1, self.index + 1)

        except Exception:

            pass

        self.report({'INFO'}, f"{_t('Profile duplicated')}: {new_profile.name}")

        return {'FINISHED'}





class SF_OT_workspace_profile_pin(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_pin'

    bl_label = 'Pin'

    bl_description = 'Pin or unpin the selected workspace profile so it stays emphasized in cards and quick access areas'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = getattr(prefs, 'workspace_profiles', None)

        if profiles is None or self.index < 0 or self.index >= len(profiles):

            return {'CANCELLED'}

        profile = profiles[self.index]

        profile.pinned = not bool(getattr(profile, 'pinned', False))

        self.report({'INFO'}, _t('Profile pinned') if profile.pinned else _t('Profile unpinned'))

        return {'FINISHED'}





class SF_OT_workspace_command_set_goal(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_set_goal'

    bl_label = 'Set Goal'

    bl_description = 'Set the current session goal so launchers, profile cards, and recommended actions can focus on the task you are doing right now'

    bl_options = {'UNDO', 'INTERNAL'}



    goal: EnumProperty(

        name='Goal',

        items=[

            ('EXPLORE', 'Explore', ''),

            ('IMPORT', 'Import', ''),

            ('MAINTAIN', 'Maintain', ''),

            ('PUBLISH', 'Publish', ''),

            ('RECOVER', 'Recover', ''),

        ],

        default='IMPORT',

        options={'HIDDEN'},

    )



    def execute(self, context):

        context.window_manager.sf_session_goal = self.goal

        self.report({'INFO'}, f"{_t('Set goal')}: {_t(self.goal.title())}")

        _sf_append_activity(context, _t('Updated session goal'), _t(self.goal.title()), 'BOOKMARKS')

        return {'FINISHED'}





class SF_OT_workspace_command_open_goal(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_open_goal'

    bl_label = 'Open Goal'

    bl_description = 'Switch the session goal and immediately open the most relevant workflow or maintenance tool for that task'

    bl_options = {'UNDO', 'INTERNAL'}



    goal: EnumProperty(

        name='Goal',

        items=[

            ('EXPLORE', 'Explore', ''),

            ('IMPORT', 'Import', ''),

            ('MAINTAIN', 'Maintain', ''),

            ('PUBLISH', 'Publish', ''),

            ('RECOVER', 'Recover', ''),

        ],

        default='IMPORT',

        options={'HIDDEN'},

    )



    def execute(self, context):

        context.window_manager.sf_session_goal = self.goal

        _sf_append_activity(context, _t('Applied session goal and opened the next tool'), _t(self.goal.title()), 'PLAY')

        if self.goal == 'EXPLORE':

            try:

                bpy.ops.import_scene.sfs_asset_reader_open('INVOKE_DEFAULT')

            except Exception:

                bpy.ops.import_scene.sfs_source_browser_open_folder_2('INVOKE_DEFAULT')

            return {'FINISHED'}

        if self.goal == 'IMPORT':

            bpy.ops.import_scene.sfs_reference_manager_apply_setup_and_open('INVOKE_DEFAULT', preset='IMPORT')

            return {'FINISHED'}

        if self.goal == 'MAINTAIN':

            bpy.ops.import_scene.sfs_reference_manager_apply_setup_and_open('INVOKE_DEFAULT', preset='MANAGE')

            return {'FINISHED'}

        if self.goal == 'PUBLISH':

            bpy.ops.import_scene.sfs_reference_manager_apply_setup_and_open('INVOKE_DEFAULT', preset='PUBLISH')

            return {'FINISHED'}

        try:

            bpy.ops.import_scene.sfs_reference_manager_source_check('INVOKE_DEFAULT')

        except Exception:

            pass

        return {'FINISHED'}









class SF_OT_workspace_command_run_goal_starter_pack(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_run_goal_starter_pack'

    bl_label = 'Run Goal Starter Pack'

    bl_description = 'Set the target goal, apply the closest profile or fallback preset, clear the most common blockers, and open the next relevant tool'

    bl_options = {'UNDO', 'INTERNAL'}



    popup_width: IntProperty(default=460, min=360, max=760, options={'HIDDEN'})

    skip_review: BoolProperty(default=False, options={'HIDDEN'})



    goal: EnumProperty(

        name='Goal',

        items=[

            ('EXPLORE', 'Explore', ''),

            ('IMPORT', 'Import', ''),

            ('MAINTAIN', 'Maintain', ''),

            ('PUBLISH', 'Publish', ''),

            ('RECOVER', 'Recover', ''),

        ],

        default='IMPORT',

        options={'HIDDEN'},

    )

    auto_fix: BoolProperty(default=True, options={'HIDDEN'})

    open_followup: BoolProperty(default=True, options={'HIDDEN'})



    def invoke(self, context, event):

        if self.skip_review:

            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self, width=self.popup_width)



    def draw(self, context):

        payload = _sf_quick_action_review_payload(context, 'RUN_GOAL_STARTER_PACK', self.goal)

        payload['icon'] = payload.get('icon', _sf_goal_icon(self.goal))

        _sf_draw_review_run_dialog(self.layout, payload)



    def execute(self, context):

        prefs = _addon_prefs(context)

        wm = context.window_manager

        goal = str(self.goal or 'IMPORT').upper()

        wm.sf_session_goal = goal

        steps = []

        best_pair = _sf_best_profile_for_goal(prefs, goal, context=context)

        if best_pair:

            idx, profile = best_pair

            try:

                _sf_apply_workspace_profile(profile, wm)

                try:

                    prefs.workspace_profile_active_index = idx

                    prefs.workspace_profile_name = getattr(profile, 'name', '') or ''

                except Exception:

                    pass

                steps.append(_t('Applied best profile'))

            except Exception:

                pass

        else:

            preset_map = {'IMPORT': 'IMPORT', 'MAINTAIN': 'MANAGE', 'PUBLISH': 'PUBLISH', 'RECOVER': 'MANAGE'}

            preset = preset_map.get(goal)

            if preset:

                try:

                    label = _sf_apply_workflow_preset(context, preset)

                    if label:

                        steps.append(_t('Applied fallback preset'))

                except Exception:

                    pass



        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)



        if self.auto_fix:

            if goal == 'RECOVER':

                if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_workspace_command_fix_all', None)):

                    steps.append(_t('Smart fix'))

            elif goal == 'MAINTAIN' and (has_source and (not source_info.get('inside_root') or not source_info.get('is_indexed') or not roots_ready or not index_ready)):

                if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_run_repair_pack', None), mode='COVERAGE_INDEX'):

                    steps.append(_t('Coverage + Index'))

            elif goal == 'PUBLISH' and has_source:

                needs_publish_prep = (not source_info.get('inside_root') or not source_info.get('is_indexed') or not source_info.get('preview_path') or not source_info.get('meta_path') or not source_info.get('catalog_path'))

                if needs_publish_prep and _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_run_repair_pack', None), mode='PUBLISH_PREP'):

                    steps.append(_t('Publish Prep'))



        opened = ''

        if self.open_followup:

            if goal == 'EXPLORE':

                opened = _t('Asset Reader...') if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_asset_reader_open', None), 'INVOKE_DEFAULT') else ''

                if not opened:

                    _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_source_browser_open_folder_2', None), 'INVOKE_DEFAULT')

                    opened = _t('Smart File...')

            elif goal == 'IMPORT':

                if has_source:

                    _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_source_browser_import', None), 'INVOKE_DEFAULT')

                    opened = _t('Browse')

                else:

                    _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_source_browser_open_folder_2', None), 'INVOKE_DEFAULT')

                    opened = _t('Smart File...')

            elif goal == 'MAINTAIN':

                if roots_ready:

                    _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_open', None), 'INVOKE_DEFAULT')

                    opened = _t('Reference Manager...')

                else:

                    _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_source_check', None), 'INVOKE_DEFAULT')

                    opened = _t('Source Check...')

            elif goal == 'PUBLISH':

                source_info = _sf_get_source_insights(prefs, filepath, None)

                if has_source and source_info.get('preview_path') and source_info.get('meta_path'):

                    _sf_run_operator_by_idname('export_scene.sfs_publisher_publish_asset', 'INVOKE_DEFAULT')

                    opened = _t('Publish Asset...')

                else:

                    _sf_run_operator_by_idname('export_scene.sfs_asset_preview_batch_preview', 'INVOKE_DEFAULT')

                    opened = _t('Asset Preview Batch...')

            else:

                _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_source_check', None), 'INVOKE_DEFAULT')

                opened = _t('Source Check...')

            if opened:

                steps.append(_t('Opened follow-up tool'))



        summary = ','.join([it for it in steps if it]) or _t('No starter-pack changes were needed')

        if opened:

            summary = f"{summary} → {opened}"

        self.report({'INFO'}, f"{_t('Goal starter pack finished')}: {_t(goal.title())} | {summary}")

        _sf_append_activity(context, _t('Ran goal starter pack'), f"{goal}: {summary}", _sf_goal_icon(goal))

        detail_lines = [f"{_t('Goal')}: {_t(goal.title())}"]

        detail_lines.extend([str(step) for step in steps if str(step).strip()])

        if opened:

            detail_lines.append(f"{_t('Opened follow-up tool')}: {opened}")

        if filepath:

            detail_lines.append(f"{_t('Source')}: {filepath}")

        follow_up = [

            _t('Open the suggested next tool and confirm that the blocker or goal step has cleared.'),

            (_t('Recommended follow-up') + ':' + opened) if opened else _t('Open Source Check...'),

        ]

        _sf_store_last_quick_action_result(context, _t('Run Goal Starter Pack'), summary, detail_lines, follow_up, _sf_goal_icon(goal))

        _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_view_action_result', None), 'INVOKE_DEFAULT')

        return {'FINISHED'}





class SF_OT_workspace_command_run_top_recommendation(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_run_top_recommendation'

    bl_label = 'Run Top Recommendation'

    bl_description = 'Follow the highest-priority recommended action for the current source, goal, and library state'

    bl_options = {'UNDO', 'INTERNAL'}



    popup_width: IntProperty(default=460, min=360, max=760, options={'HIDDEN'})

    skip_review: BoolProperty(default=False, options={'HIDDEN'})



    def invoke(self, context, event):

        if self.skip_review:

            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self, width=self.popup_width)



    def draw(self, context):

        payload = _sf_quick_action_review_payload(context, 'RUN_TOP_RECOMMENDATION', '')

        payload['icon'] = payload.get('icon', 'PLAY')

        _sf_draw_review_run_dialog(self.layout, payload)



    def execute(self, context):

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        health_score, _health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        if not actions:

            self.report({'INFO'}, _t('No blocker detected'))

            return {'CANCELLED'}

        action = actions[0]

        if not _sf_invoke_recommended_action(context, action):

            self.report({'WARNING'}, _t('Unable to execute the top recommendation'))

            return {'CANCELLED'}

        action_title = str(action.get('title', '') or '')

        action_detail = str(action.get('detail', '') or '')

        self.report({'INFO'}, f"{_t('Run Top Recommendation')}: {action_title}")

        _sf_append_activity(context, _t('Ran top recommendation'), action_title, action.get('icon', 'PLAY'))

        detail_lines = [f"{_t('Suggested action')}: {action_title}"]

        if action_detail:

            detail_lines.append(action_detail)

        detail_lines.append(f"{_t('Health Score')}: {health_score}/100 · {_health_label}")

        follow_up = [

            _t('Open the suggested next tool and confirm that the blocker or goal step has cleared.'),

            _t('Open Source Check...'),

        ]

        _sf_store_last_quick_action_result(context, _t('Run Top Recommendation'), action_title, detail_lines, follow_up, action.get('icon', 'PLAY'))

        _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_view_action_result', None), 'INVOKE_DEFAULT')

        return {'FINISHED'}





class SF_OT_workspace_command_fix_preview(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_fix_preview'

    bl_label = 'Fix Preview'

    bl_description = 'Preview what Smart Fix All would change before you run it'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=520, min=340, max=920, options={'HIDDEN'})



    def invoke(self, context, event):

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        can_run, reason, preview = _sf_can_run_smart_fix(context, _addon_prefs(context))

        payload = _sf_quick_action_review_payload(context, 'SMART_FIX_ALL', '')

        payload['title'] = _t('Smart Fix Preview...')

        payload['subtitle'] = _t('Preview the library-root cleanup and source-coverage fixes before applying them.')

        payload['can_run'] = bool(can_run)

        payload['reason'] = str(reason or '')

        lines = list((preview or {}).get('lines', []) or [])[:10]

        summary = str((preview or {}).get('summary', '') or '').strip()

        payload['summary'] = summary or payload.get('summary', '')

        payload['lines'] = lines or payload.get('lines', [])

        _sf_draw_review_run_dialog(layout, payload, max_lines=10)

        action_box = layout.box()

        _sf_draw_section_intro(action_box, 'Next Step', 'Run Smart Fix now or open the latest details in the Text Editor.', 'FORWARD')

        row = action_box.row(align=True)

        run_row = row.row(align=True)

        run_row.enabled = can_run

        op = run_row.operator(SF_OT_workspace_command_fix_all.bl_idname, text=_t('Fix All'), icon='TOOL_SETTINGS')

        _sf_safe_set_operator_property(op, 'skip_review', True)

        row.operator(SF_OT_workspace_command_fix_details.bl_idname, text=_t('Fix Details'), icon='TEXT')





class SF_OT_workspace_command_fix_all(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_fix_all'

    bl_label = 'Fix All'

    bl_description = 'Run a safe batch of root maintenance fixes and source-coverage fixes so the current workspace reaches a healthier state faster'

    bl_options = {'UNDO', 'INTERNAL'}



    popup_width: IntProperty(default=500, min=360, max=780, options={'HIDDEN'})

    skip_review: BoolProperty(default=False, options={'HIDDEN'})



    def invoke(self, context, event):

        if self.skip_review:

            return self.execute(context)

        return context.window_manager.invoke_props_dialog(self, width=self.popup_width)



    def draw(self, context):

        payload = _sf_quick_action_review_payload(context, 'SMART_FIX_ALL', '')

        payload['icon'] = payload.get('icon', 'TOOL_SETTINGS')

        _sf_draw_review_run_dialog(self.layout, payload, max_lines=8)



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        can_run, reason, _preview = _sf_can_run_smart_fix(context, prefs)

        if not can_run:

            self.report({'INFO'}, reason or _t('No actionable Smart Fix changes are available yet.'))

            return {'CANCELLED'}

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        added = 0

        reenabled = 0

        disabled_missing = 0

        removed_empty = 0

        removed_dup = 0



        roots = list(getattr(prefs, 'library_roots', []) or [])

        source_info = _sf_get_source_insights(prefs, filepath, None)

        if filepath and os.path.isfile(filepath) and (not roots or not bool(source_info.get('inside_root'))):

            folder = _norm_path(os.path.dirname(filepath))

            if folder and os.path.isdir(folder):

                _path, was_added = _sf_add_library_root_path(prefs, folder)

                if was_added:

                    added += 1

                else:

                    for root in list(getattr(prefs, 'library_roots', []) or []):

                        if _norm_path(getattr(root, 'path', '') or '') == folder and not bool(getattr(root, 'enabled', True)):

                            root.enabled = True

                            reenabled += 1



        existing = []

        seen = {}

        for root in list(getattr(prefs, 'library_roots', []) or []):

            item = {

                'path': _norm_path(getattr(root, 'path', '') or ''),

                'enabled': bool(getattr(root, 'enabled', True)),

                'priority': int(getattr(root, 'priority', 0) or 0),

            }

            if not item['path']:

                removed_empty += 1

                continue

            if item['enabled'] and not os.path.isdir(item['path']):

                item['enabled'] = False

                disabled_missing += 1

            kept = seen.get(item['path'])

            if kept is not None:

                # 同じ根が重なった時は、有効な方の状態を残す

                kept['enabled'] = kept['enabled'] or item['enabled']

                kept['priority'] = max(kept['priority'], item['priority'])

                removed_dup += 1

                continue

            seen[item['path']] = item

            existing.append(item)



        while len(prefs.library_roots):

            prefs.library_roots.remove(len(prefs.library_roots) - 1)

        for item in sorted(existing, key=lambda it: (not it['enabled'], -(it['priority'] or 0), (os.path.basename(it['path']) or it['path']).lower(), it['path'].lower())):

            root = prefs.library_roots.add()

            root.path = item['path']

            root.enabled = item['enabled']

            root.priority = item['priority']



        bits = []

        detail_lines = []

        if filepath:

            detail_lines.append(f"{_t('Source')}: {filepath}")

        if added:

            bits.append(f"root+{added}")

            detail_lines.append(f"{_t('Added roots')}: {added}")

        if reenabled:

            bits.append(_ui_text(f"reenabled {reenabled}", f'再び有効 {reenabled}'))

            detail_lines.append(f"{_t('Re-enabled roots')}: {reenabled}")

        if disabled_missing:

            bits.append(_ui_text(f"disabled missing {disabled_missing}", f'見つからず無効 {disabled_missing}'))

            detail_lines.append(f"{_t('Disabled missing roots')}: {disabled_missing}")

        if removed_empty:

            bits.append(_ui_text(f"removed empty {removed_empty}", f'空を削除 {removed_empty}'))

            detail_lines.append(f"{_t('Removed empty roots')}: {removed_empty}")

        if removed_dup:

            bits.append(_ui_text(f"removed duplicate {removed_dup}", f'重複を削除 {removed_dup}'))

            detail_lines.append(f"{_t('Removed duplicate roots')}: {removed_dup}")

        if not bits:

            summary = _t('No smart-fix changes were needed')

            details_payload = detail_lines or [summary]

            _sf_store_last_fix_report(context, summary, details_payload)

            _sf_store_last_quick_action_result(context, _t('Smart Fix All'), summary, details_payload, [_t('Open Source Check...'), _t('Open Smart Fix Details...')], 'TOOL_SETTINGS')

            self.report({'INFO'}, summary)

            _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_view_action_result', None), 'INVOKE_DEFAULT')

            return {'FINISHED'}

        summary = f"{_t('Smart fix summary')}: " + ','.join(bits)

        detail_lines.insert(0, summary)

        _sf_store_last_fix_report(context, summary, detail_lines)

        _sf_store_last_quick_action_result(context, _t('Smart Fix All'), summary, detail_lines, [_t('Open Source Check...'), _t('Open Smart Fix Details...')], 'TOOL_SETTINGS')

        self.report({'INFO'}, summary)

        _sf_append_activity(context, _t('Ran Smart Fix All'), summary, 'TOOL_SETTINGS')

        _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_view_action_result', None), 'INVOKE_DEFAULT')

        return {'FINISHED'}





class SF_OT_reference_manager_view_action_result(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_reference_manager_view_action_result'

    bl_label = 'View Action Result'

    bl_description = 'View the latest quick-action result and decide what to open next.'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=620, min=420, max=1100, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Action Result'), str(getattr(context.window_manager, 'sf_last_action_title', '') or _t('Last Quick Action')), 'CHECKMARK')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        payload = _sf_quick_action_result_payload(context)

        _sf_draw_execution_result_dialog(layout, payload, max_lines=10)

        _sf_draw_last_action_report_shortcuts(layout, context, compact=False)



        action_box = layout.box()

        _sf_draw_section_intro(action_box, 'Recommended Next Step', 'Open the next screen from here if you want to verify or continue immediately.', 'FORWARD')

        row = action_box.row(align=True)

        row.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

        row.operator(SF_OT_workspace_command_action_palette.bl_idname, text=_t('Action Palette'), icon='VIEWZOOM')

        last_title = str(getattr(context.window_manager, 'sf_last_action_title', '') or '')

        if last_title == _t('Smart Fix All') or last_title == 'Smart Fix All':

            action_box.operator(SF_OT_workspace_command_fix_details.bl_idname, text=_t('Fix Details'), icon='TEXT')





class SF_OT_workspace_command_fix_details(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_fix_details'

    bl_label = 'Fix Details'

    bl_description = 'Review the last Smart Fix summary and detailed maintenance changes captured during this session'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=620, min=420, max=1100, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Smart Fix Details'), _norm_path(getattr(context.window_manager, 'sf_filepath', '') or ''), 'TEXT')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

        lines = _sf_last_fix_report_lines(context)

        layout.label(text=_t('Latest Repair Snapshot'), icon='TOOL_SETTINGS')

        if summary:

            layout.label(text=summary, icon='CHECKMARK')

        else:

            layout.label(text=_t('No smart fix report yet'))

        body = layout.box()

        body.label(text=_t('Smart Fixes'), icon='TOOL_SETTINGS')

        if lines:

            for line in lines:

                body.label(text=line, icon='BLANK1')

        else:

            body.label(text=_t('No smart fix report yet'))

        layout.operator(SF_OT_workspace_command_fix_report.bl_idname, text=_t('Fix Report'), icon='EXPORT')





class SF_OT_workspace_command_fix_report(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_fix_report'

    bl_label = 'Fix Report'

    bl_description = 'Write the latest Smart Fix summary and details into a Blender text datablock for review or sharing'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

        lines = _sf_last_fix_report_lines(context)

        if not summary and not lines:

            self.report({'INFO'}, _t('No smart fix report yet'))

            return {'CANCELLED'}

        text_name = _sf_report_export(

            context,

            _t('Smart Fix Report'),

            _sf_build_smart_fix_report_lines(context),

            open_text=self.open_text,

            activity_title=_t('Exported smart fix report'),

        )

        self.report({'INFO'}, f"{_t('Smart fix report exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_workspace_profile_edit_profile(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_edit_profile'

    bl_label = 'Edit Profile'

    bl_description = 'Adjust profile identity and saved workflow settings without capturing a brand new setup'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})

    popup_width: IntProperty(default=620, min=420, max=1100, options={'HIDDEN'})



    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self, width=self.popup_width)



    def execute(self, context):

        self.report({'INFO'}, _t('Profile updated'))

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

        if self.index < 0 or self.index >= len(profiles):

            layout.label(text=_t('No workspace profiles yet'))

            return

        profile = profiles[self.index]

        ident = layout.box()

        ident.label(text=_t('Identity'), icon='PRESET')

        ident.prop(profile, 'name', text=_t('Profile name'))

        ident.prop(profile, 'tag', text=_t('Tag'))

        ident.prop(profile, 'notes', text=_t('Notes'))

        ident.prop(profile, 'pinned', text=_t('Pinned'))



        behavior = layout.box()

        behavior.label(text=_t('Behavior'), icon='TOOL_SETTINGS')

        row = behavior.row(align=True)

        row.prop(profile, 'mode', text=_t('Mode'))

        row.prop(profile, 'import_mode', text=_t('Import Mode'))

        row = behavior.row(align=True)

        row.prop(profile, 'strict_loader')

        row.prop(profile, 'include_dependencies')

        row = behavior.row(align=True)

        row.prop(profile, 'bake_world')

        row.prop(profile, 'clear_parent')

        row.prop(profile, 'clear_constraints')

        row = behavior.row(align=True)

        row.prop(profile, 'prefix')

        row.prop(profile, 'collision', text=_t('Collision'))

        behavior.prop(profile, 'apply_prefix_to_linked')

        behavior.prop(profile, 'put_in_collection')

        c_row = behavior.row(align=True)

        c_row.prop(profile, 'collection_name_mode', text=_t('Collection Name'))

        c_row.prop(profile, 'collection_name', text=_t('Custom'))



        place = layout.box()

        place.label(text=_t('Placement & Selection'), icon='ORIENTATION_GLOBAL')

        place.prop(profile, 'placement', text=_t('Placement'))

        if getattr(profile, 'placement', '') in {'CURSOR', 'ACTIVE', 'FLOOR', 'GRID'}:

            place.prop(profile, 'offset', text=_t('Offset'))

        if getattr(profile, 'placement', '') == 'GRID':

            grid = place.row(align=True)

            grid.prop(profile, 'grid_spacing', text=_t('Grid Spacing'))

            grid.prop(profile, 'grid_columns', text=_t('Columns'))

        srow = place.row(align=True)

        srow.prop(profile, 'select_imported')

        srow.prop(profile, 'frame_view')

        place.label(text=f"{_t('Recommended tool')}: {_sf_profile_intent_label(profile)}")





class SF_OT_workspace_profile_clear_filter(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_clear_filter'

    bl_label = 'Clear Filter'

    bl_description = 'Reset workspace profile search text and filter mode so every profile becomes visible again'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        prefs.workspace_profile_filter_text = ''

        prefs.workspace_profile_filter_mode = 'ALL'

        self.report({'INFO'}, _t('Profile filter cleared'))

        _sf_append_activity(context, _t('Profile filter cleared'), _t('Visible profiles after filter') + ':' + str(len(_sf_profiles_for_goal(prefs, _sf_current_session_goal(context), context=context))), 'VIEWZOOM')

        return {'FINISHED'}





class SF_OT_reference_manager_export_activity_log(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_export_activity_log'

    bl_label = 'Export Activity Log'

    bl_description = 'Write the Smart File session activity timeline to a Blender text datablock for troubleshooting or handoff notes'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(default=True, options={'HIDDEN'})



    def execute(self, context):

        entries = _sf_activity_entries(context)

        name = f"SF_Activity_Log_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"

        text_block = bpy.data.texts.new(name)

        text_block.write('Smart File Activity Log\n')

        text_block.write('=' * 40 + '\n')

        if entries:

            for item in entries:

                text_block.write(f"[{item.get('time','')}] {item.get('title','')}\n")

                if item.get('detail'):

                    text_block.write(f"  {item.get('detail')}\n")

        else:

            text_block.write(_t('No activity recorded yet') + '\n')

        if self.open_text:

            for area in getattr(context.screen, 'areas', []):

                if area.type == 'TEXT_EDITOR':

                    area.spaces.active.text = text_block

                    break

        self.report({'INFO'}, _t('Activity log exported'))

        _sf_append_activity(context, _t('Export Activity Log'), name, 'EXPORT')

        return {'FINISHED'}





class SF_OT_reference_manager_clear_activity_log(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_clear_activity_log'

    bl_label = 'Clear Activity Log'

    bl_description = 'Clear the Smart File activity timeline captured in this Blender session'

    bl_options = {'UNDO', 'INTERNAL'}



    def invoke(self, context, event):

        return context.window_manager.invoke_confirm(self, event)



    def execute(self, context):

        try:

            context.window_manager.sf_activity_log = '[]'

        except Exception:

            return {'CANCELLED'}

        self.report({'INFO'}, _t('Activity log cleared'))

        return {'FINISHED'}





class SF_OT_workspace_profile_move_profile(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_profile_move_profile'

    bl_label = 'Move Profile'

    bl_description = 'Move the selected workspace profile up or down to keep your preferred order in menus and launchers'

    bl_options = {'UNDO', 'INTERNAL'}



    index: IntProperty(default=-1, options={'HIDDEN'})

    direction: EnumProperty(

        name='Direction',

        items=[('UP', 'Move Up', ''), ('DOWN', 'Move Down', '')],

        default='UP',

        options={'HIDDEN'},

    )



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = getattr(prefs, 'workspace_profiles', None)

        if profiles is None or self.index < 0 or self.index >= len(profiles):

            return {'CANCELLED'}

        new_index = self.index - 1 if self.direction == 'UP' else self.index + 1

        new_index = max(0, min(len(profiles) - 1, new_index))

        if not _sf_move_collection_item(profiles, self.index, new_index):

            return {'CANCELLED'}

        try:

            prefs.workspace_profile_active_index = new_index

        except Exception:

            pass

        return {'FINISHED'}





class SF_OT_workspace_profile_export_workspace_profiles(bpy.types.Operator, ExportHelper):

    bl_idname = 'import_scene.sfs_workspace_profile_export_workspace_profiles'

    bl_label = 'Export Workspace Profiles'

    bl_description = 'Write saved workspace profiles to a JSON file so they can be backed up or shared across projects'

    bl_options = {'UNDO', 'INTERNAL'}



    filename_ext = ".json"

    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    scope: EnumProperty(

        name='Scope',

        items=[('ALL', 'All Profiles', ''), ('ACTIVE', 'Active Profile', ''), ('VISIBLE', 'Visible Profiles', ''), ('PINNED', 'Pinned Profiles', ''), ('GOAL', 'Goal Profiles', '')],

        default='ALL',

        options={'HIDDEN'},

    )

    index: IntProperty(default=-1, options={'HIDDEN'})



    def invoke(self, context, _event):

        if not getattr(self, 'filepath', ''):

            self.filepath = _sf_user_default_file('smart_file_suite_Workspace_Profiles.json', 'profiles')

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        profiles = list(getattr(prefs, 'workspace_profiles', []) or [])

        goal = _sf_current_session_goal(context)

        if self.scope == 'ACTIVE' and 0 <= self.index < len(profiles):

            payload_profiles = [_sf_profile_to_dict(profiles[self.index])]

        elif self.scope == 'VISIBLE':

            payload_profiles = [_sf_profile_to_dict(profile) for _idx, profile in _sf_profiles_for_goal(prefs, goal, context=context)]

        elif self.scope == 'PINNED':

            payload_profiles = [_sf_profile_to_dict(p) for p in profiles if bool(getattr(p, 'pinned', False))]

        elif self.scope == 'GOAL':

            payload_profiles = [_sf_profile_to_dict(p) for p in profiles if _sf_profile_matches_goal(p, goal)]

        else:

            payload_profiles = [_sf_profile_to_dict(p) for p in profiles]

        payload = {

            'schema': 'smart_file_suite_workspace_profiles_v1',

            'version': [5, 18, 2],

            'profiles': payload_profiles,

        }

        try:

            with open(self.filepath, 'w', encoding='utf-8') as fh:

                json.dump(payload, fh, ensure_ascii=False, indent=2)

        except Exception as ex:

            self.report({'ERROR'}, _sf_error_text(ex))

            return {'CANCELLED'}

        self.report({'INFO'}, f"{_t('Profiles exported')}: {len(payload_profiles)}")

        return {'FINISHED'}





class SF_OT_workspace_profile_import_workspace_profiles(bpy.types.Operator, ImportHelper):

    bl_idname = 'import_scene.sfs_workspace_profile_import_workspace_profiles'

    bl_label = 'Import Workspace Profiles'

    bl_description = 'Load workspace profiles from a JSON file and merge, append, or replace the current saved profiles'

    bl_options = {'UNDO', 'INTERNAL'}



    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    import_mode: EnumProperty(

        name='Import mode',

        items=[

            ('UPSERT', 'Merge / Update', 'Update matching names and add new ones'),

            ('APPEND', 'Append as New', 'Always append imported profiles as new entries'),

            ('REPLACE', 'Replace Existing', 'Clear current profiles before import'),

        ],

        default='UPSERT',

    )



    def invoke(self, context, _event):

        if not getattr(self, 'filepath', ''):

            self.filepath = _sf_user_default_file('smart_file_suite_Workspace_Profiles.json', 'profiles')

        context.window_manager.fileselect_add(self)

        return {'RUNNING_MODAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        try:

            with open(self.filepath, 'r', encoding='utf-8') as fh:

                raw = json.load(fh)

        except Exception as ex:

            self.report({'ERROR'}, _sf_error_text(ex))

            return {'CANCELLED'}

        if isinstance(raw, dict):

            entries = raw.get('profiles', [])

        elif isinstance(raw, list):

            entries = raw

        else:

            entries = []

        if not isinstance(entries, list) or not entries:

            self.report({'WARNING'}, _t('No workspace profiles yet'))

            return {'CANCELLED'}

        if self.import_mode == 'REPLACE':

            try:

                while prefs.workspace_profiles:

                    prefs.workspace_profiles.remove(len(prefs.workspace_profiles) - 1)

            except Exception:

                pass

        added = 0

        updated = 0

        for entry in entries:

            if not isinstance(entry, dict):

                continue

            name = str(entry.get('name', '') or _t('Local Edit')).strip() or _t('Local Edit')

            profile = None

            if self.import_mode == 'UPSERT':

                profile, _idx = _sf_find_workspace_profile(prefs, name)

            if profile is None:

                profile = prefs.workspace_profiles.add()

                if self.import_mode == 'APPEND':

                    name = _sf_unique_workspace_profile_name(prefs, name)

                profile.name = name

                added += 1

            else:

                updated += 1

            entry = dict(entry)

            entry['name'] = name

            _sf_profile_from_dict(profile, entry)

        self.report({'INFO'}, f"{_t('Profiles imported')}: +{added} / ~{updated}")

        return {'FINISHED'}





class SF_OT_library_roots_enable_all_roots(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_enable_all_roots'

    bl_label = 'Enable All Roots'

    bl_description = 'Enable every configured library root so diagnostics, indexing, preview, and publish tools can scan them again'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        changed = 0

        for root in list(getattr(prefs, 'library_roots', []) or []):

            if not bool(getattr(root, 'enabled', True)):

                root.enabled = True

                changed += 1

        self.report({'INFO'}, f"{_t('Roots enabled')}: {changed}")

        return {'FINISHED'}





class SF_OT_library_roots_disable_missing_roots(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_disable_missing_roots'

    bl_label = 'Disable Missing Roots'

    bl_description = 'Disable roots whose folder no longer exists so health checks focus on valid locations'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        changed = 0

        for root in list(getattr(prefs, 'library_roots', []) or []):

            path = _norm_path(getattr(root, 'path', '') or '')

            if path and not os.path.isdir(path) and bool(getattr(root, 'enabled', True)):

                root.enabled = False

                changed += 1

        self.report({'INFO'}, f"{_t('Missing roots disabled')}: {changed}")

        return {'FINISHED'}





class SF_OT_library_roots_sort_roots(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_sort_roots'

    bl_label = 'Sort Roots'

    bl_description = 'Sort library roots by enabled state, priority, and path so large libraries stay easier to review'

    bl_options = {'UNDO', 'INTERNAL'}



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        changed = _sf_sort_library_roots_in_place(prefs)

        self.report({'INFO'}, f"{_t('Roots sorted')}: {1 if changed else 0}")

        return {'FINISHED'}





class SF_OT_library_roots_quick_root_bootstrap(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_quick_root_bootstrap'

    bl_label = 'Quick Root Bootstrap'

    bl_description = 'Add current, recent, or favorite source folders as library roots to speed up initial setup'

    bl_options = {'UNDO', 'INTERNAL'}



    mode: EnumProperty(

        name='Bootstrap Source',

        items=[

            ('RECENT', 'Bootstrap from Recent', 'Add folders from recent source files'),

            ('FAVORITES', 'Bootstrap from Favorites', 'Add folders from favorite source files'),

            ('RECENT_AND_FAVORITES', 'Bootstrap from Recent + Favorites', 'Add folders from recent and favorite source files'),

        ],

        default='RECENT_AND_FAVORITES',

        options={'HIDDEN'},

    )

    use_parent_folder: BoolProperty(default=False, options={'HIDDEN'})

    limit: IntProperty(default=12, min=1, max=50, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        paths = []

        if self.mode in {'RECENT', 'RECENT_AND_FAVORITES'}:

            paths.extend([_norm_path(getattr(it, 'path', '') or '') for it in list(getattr(prefs, 'recent_paths', []) or [])[:self.limit]])

        if self.mode in {'FAVORITES', 'RECENT_AND_FAVORITES'}:

            paths.extend([_norm_path(getattr(it, 'path', '') or '') for it in list(getattr(prefs, 'favorite_paths', []) or [])[:self.limit]])

        added = 0

        existing = 0

        seen = set()

        for filepath in paths:

            if not filepath or filepath in seen or not os.path.isfile(filepath):

                continue

            seen.add(filepath)

            folder = _norm_path(os.path.dirname(filepath))

            if self.use_parent_folder:

                folder = _norm_path(os.path.dirname(folder))

            path, was_added = _sf_add_library_root_path(prefs, folder)

            if not path:

                continue

            if was_added:

                added += 1

            else:

                existing += 1

        if not (added or existing):

            self.report({'INFO'}, _t('No bootstrap root changes were needed'))

            return {'FINISHED'}

        self.report({'INFO'}, f"{_t('Roots bootstrapped')}: +{added} / ={existing}")

        return {'FINISHED'}









def _sf_collect_report_context(context) -> dict:

    prefs = _addon_prefs(context)

    wm = context.window_manager

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    try:

        index = _load_index()

    except Exception:

        index = {}

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

    index_ready = bool(len((index or {}).get('files', {}) or {}))

    source_info = _sf_get_source_insights(prefs, filepath, index)

    health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

    actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

    return {

        'prefs': prefs,

        'wm': wm,

        'filepath': filepath,

        'has_source': has_source,

        'index': index,

        'roots': roots,

        'roots_ready': roots_ready,

        'index_ready': index_ready,

        'source_info': source_info,

        'health_score': health_score,

        'health_label': health_label,

        'actions': actions,

        'goal': _sf_current_session_goal(context),

        'source_name': os.path.basename(filepath) if has_source else _t('Not set'),

        'source_stem': os.path.splitext(os.path.basename(filepath))[0] if has_source else _t('Not set'),

        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),

        'timestamp_slug': datetime.datetime.now().strftime('%Y%m%d_%H%M%S'),

    }







def _sf_safe_report_token(value: str, fallback: str = 'report') -> str:

    # 日本語の題やファイル名も残す（ASCII だけにすると別々の報告が同じ名前に潰れて上書きされる）

    token = re.sub(r'[^\w.-]+', '_', str(value or '').strip())

    token = token.strip('._-')

    return token or fallback





def _sf_report_text_block_name(report_title: str, data: dict) -> str:

    source_token = _sf_safe_report_token(data.get('source_stem', ''), 'no_source')

    goal_token = _sf_safe_report_token(str(data.get('goal', 'IMPORT')).upper(), 'goal')

    report_token = _sf_safe_report_token(report_title, 'report')

    return f"smart_file_suite_{report_token}__{source_token}__{goal_token}.txt"





def _sf_report_export(context, report_title: str, lines: list[str], *,

                      open_text: bool = True,

                      activity_title: str = '') -> str:

    data = _sf_collect_report_context(context)

    text_name = _sf_write_report_text(_sf_report_text_block_name(report_title, data), '\n'.join(lines) + '\n')

    if open_text:

        _sf_open_text_in_any_editor(context, text_name)

    if activity_title:

        _sf_append_activity(context, activity_title, text_name, 'TEXT')

    return text_name





def _sf_report_export_notes_lines(report_title: str, data: dict) -> list[str]:

    source_name = data.get('source_name') or _t('Not set')

    source_token = _sf_safe_report_token(data.get('source_stem', ''), 'no_source')

    goal_raw = str(data.get('goal', 'IMPORT') or 'IMPORT').upper()

    goal_label = _t(goal_raw.title())

    goal_token = _sf_safe_report_token(goal_raw, 'goal')

    text_name = _sf_report_text_block_name(report_title, data)

    return [

        f"- {_t('Report Name')}: {report_title}",

        f"- {_t('Generated Text Datablock')}: {text_name}",

        f"- {_t('Source Token')}: {source_token}",

        f"- {_t('Goal Token')}: {goal_token}",

        f"- {_t('Current Source Label')}: {source_name}",

        f"- {_t('Current Goal Label')}: {goal_label}",

        f"- {_t('Text datablock names include report, source, and goal so multiple exports stay side by side instead of overwriting one another.')}",

    ]





def _sf_report_lines_header(report_title: str, data: dict) -> list[str]:

    return [

        f"Smart File | {report_title} | {data.get('timestamp', '')}",

        '',

    ]





def _sf_report_recommended_report_choice(report_title: str, data: dict) -> tuple[str, str]:

    has_source = bool(data.get('has_source'))

    goal = str(data.get('goal', 'IMPORT') or 'IMPORT').upper()

    overall = _sf_report_overall_state_label(report_title, data)

    if report_title == _t('Workspace Report'):

        if overall in {_t('Needs source'), _t('Needs roots'), _t('Needs index')}:

            return (_t('Workspace Report'), _t('Stay here first because the everyday workspace summary is still the fastest place to verify setup before narrower reports.'))

        return (_t('Product Readiness Report'), _t('Open this next when you want a narrower source-focused read after the broad workspace summary.'))

    if report_title == _t('Smart Fix Report'):

        return (_t('Workspace Report'), _t('Open this next to confirm the broader workspace state after the recent fix result.'))

    if report_title == _t('Product Readiness Report'):

        if goal == 'PUBLISH':

            return (_t('Release Report'), _t('Open this next when publish timing or final go / no-go checks are the next decision.'))

        return (_t('Handoff Report'), _t('Open this next when the source now needs a transfer-ready summary for another person.'))

    if report_title == _t('Handoff Report'):

        return (_t('Release Report'), _t('Open this next when the handoff also needs a delivery or publish readiness decision.'))

    if report_title == _t('Release Report'):

        return (_t('Session Bundle'), _t('Open this next when you also want a larger archive snapshot after the release decision.'))

    if report_title == _t('Session Bundle'):

        if has_source:

            return (_t('Handoff Report'), _t('Open this next when you want a narrower decision document after the larger archive bundle.'))

        return (_t('Workspace Report'), _t('Open this next when you want to return from the large archive snapshot to the everyday summary.'))

    return (_t('Workspace Report'), _t('Open this next when you want the most general summary view.'))





def _sf_report_quick_read_lines(report_title: str, data: dict) -> list[str]:

    actions = list(data.get('actions', []) or [])

    top_action = actions[0] if actions else None

    next_report, next_reason = _sf_report_recommended_report_choice(report_title, data)

    return [

        f"- {_t('Overall State')}: {_sf_report_overall_state_label(report_title, data)}",

        f"- {_t('Strongest Missing Piece')}: {_sf_report_primary_gap_label(data)}",

        f"- {_t('Safest Next Move')}: {top_action.get('title') if top_action else _t('No blocker detected')}",

        f"- {_t('Best Follow-up Report')}: {next_report}",

        f"  {next_reason}",

        f"- {_t('Read this section first when you want the fastest summary of current state, blockers, and the next report to open.')}",

    ]





def _sf_report_primary_gap_label(data: dict) -> str:

    source_info = data.get('source_info') or {}

    has_source = bool(data.get('has_source'))

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    if not has_source:

        return _t('Source is not selected')

    if not roots_ready or not bool(source_info.get('inside_root')):

        return _t('Library root coverage is missing')

    if not index_ready or not bool(source_info.get('is_indexed')):

        return _t('Index coverage is missing')

    if not bool(source_info.get('preview_path')):

        return _t('Preview sidecar is missing')

    if not bool(source_info.get('meta_path')):

        return _t('Metadata sidecar is missing')

    if not bool(source_info.get('catalog_path')):

        return _t('Nearby catalog entry is missing')

    return _t('No major blocker detected')





def _sf_report_overall_state_label(report_title: str, data: dict) -> str:

    source_info = data.get('source_info') or {}

    has_source = bool(data.get('has_source'))

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    score = int(data.get('health_score', 0) or 0)

    publish_like = report_title in {_t('Product Readiness Report'), _t('Release Report')}

    if not has_source:

        return _t('Needs source')

    if not roots_ready or not bool(source_info.get('inside_root')):

        return _t('Needs roots')

    if not index_ready or not bool(source_info.get('is_indexed')):

        return _t('Needs index')

    if publish_like and not (bool(source_info.get('preview_path')) and bool(source_info.get('meta_path'))):

        return _t('Needs review')

    if score >= 85:

        return _t('Ready')

    if score >= 65:

        return _t('Needs review')

    return _t('Needs setup')





def _sf_report_decision_summary_lines(report_title: str, data: dict) -> list[str]:

    actions = list(data.get('actions', []) or [])

    top_action = actions[0] if actions else None

    return [

        f"- {_t('Overall State')}: {_sf_report_overall_state_label(report_title, data)}",

        f"- {_t('Blocking Items')}: {len(actions)}",

        f"- {_t('Strongest Missing Piece')}: {_sf_report_primary_gap_label(data)}",

        f"- {_t('Safest Next Move')}: {top_action.get('title') if top_action else _t('No blocker detected')}",

    ]





def _sf_report_immediate_blockers_lines(data: dict, limit: int = 3) -> list[str]:

    actions = list(data.get('actions', []) or [])

    if not actions:

        return [f"- {_t('No immediate blocker detected')}"]

    lines = []

    for action in actions[:max(1, int(limit or 3))]:

        title = str(action.get('title', '') or _t('No blocker detected')).strip()

        detail = str(action.get('detail', '') or '').strip()

        lines.append(f"- {title}" + (f": {detail}" if detail else ''))

    return lines





def _sf_report_overview_lines(report_title: str, data: dict) -> list[str]:

    source_info = data.get('source_info') or {}

    has_source = bool(data.get('has_source'))

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    coverage_status = _t('Ready') if (has_source and roots_ready and bool(source_info.get('inside_root'))) else (_t('Needs roots') if has_source else _t('Needs source'))

    index_status = _t('Indexed') if (has_source and index_ready and bool(source_info.get('is_indexed'))) else (_t('Needs index') if has_source else _t('Needs source'))

    top_action = (data.get('actions') or [None])[0]

    top_title = top_action.get('title') if top_action else _t('No blocker detected')

    return [

        f"- {_t('Current Goal')}: {_t(str(data.get('goal', 'IMPORT')).title())}",

        f"- {_t('Current Source')}: {data.get('source_name') or _t('Not set')}",

        f"- {_t('Health Score')}: {data.get('health_score', 0)}/100 · {data.get('health_label', '')}",

        f"- {_t('Source Coverage')}: {coverage_status}",

        f"- {_t('Index State')}: {index_status}",

        f"- {_t('Top Recommendation')}: {top_title}",

    ]





def _sf_report_lines_current_setup(context, data: dict) -> list[str]:

    wm = data.get('wm')

    filepath = data.get('filepath', '')

    has_source = bool(data.get('has_source'))

    roots = list(data.get('roots', []) or [])

    index = data.get('index') or {}

    source_info = data.get('source_info') or {}

    selected_count = sum(1 for it in getattr(wm, 'sf_items', []) if bool(getattr(it, 'is_selected', False))) if wm else 0

    listed_count = len(getattr(wm, 'sf_items', [])) if wm else 0

    return [

        f"- {_t('File')}: {filepath if has_source else _t('Not set')}",

        f"- {_t('Enabled Roots')}: {sum(1 for root in roots if bool(getattr(root, 'enabled', True)))}",

        f"- {_t('Indexed Files')}: {len((index or {}).get('files', {}) or {})}",

        f"- {_t('Mode')}: {str(getattr(wm, 'sf_mode', '') or '')}",

        f"- {_t('Import Mode')}: {str(getattr(wm, 'sf_import_mode', '') or '')}",

        f"- {_t('Placement')}: {str(getattr(wm, 'sf_placement', '') or '')}",

        f"- {_t('Collision')}: {str(getattr(wm, 'sf_collision', '') or '')}",

        f"- {_t('Selected')}: {selected_count}",

        f"- {_t('Listed')}: {listed_count}",

        f"- {_t('In Library Root')}: {source_info.get('root_name') if source_info.get('inside_root') else _t('No')}",

        f"- {_t('Indexed Source')}: {_sf_bool_status_label(bool(source_info.get('is_indexed')))}",

    ]





def _sf_report_section_heading(heading: str) -> str:

    heading = str(heading or '').strip()

    mapping = {

        'Workspace Pipeline': 'Workflow Path',

        'Goal Home Cards': 'Goal Guidance',

        'Profile Coverage Board': 'Profile Coverage',

        'Release Gate Summary': 'Release Gates',

        'Activity Timeline': 'Recent Activity',

        'Source Readiness Matrix': 'Source Readiness',

        'Source / Root / Profile Matrix': 'Setup Matrix',

        'Relationship Map': 'Source Relationship',

        'Profile Overview': 'Profile Summary',

        'Root Coverage Matrix': 'Root Coverage',

        'Consistency Check': 'Consistency Review',

        'Last Repair Snapshot': 'Latest Repair Snapshot',

    }

    return mapping.get(heading, heading)





def _sf_report_section_hint(heading: str) -> str:

    heading = _sf_report_section_heading(heading)

    mapping = {

        'Workflow Path': 'Read this path first to follow the safest order for the current workspace flow.',

        'Goal Guidance': 'Compare all goal lanes here before opening the next guided view.',

        'Profile Coverage': 'Use this section to confirm whether each goal already has a strong profile match.',

        'Release Gates': 'Check these gates before handoff or publish so the final decision stays visible.',

        'Recent Activity': 'Use the latest activity list to verify what changed most recently in this session.',

        'Source Readiness': 'Read source readiness first when you want the fastest picture of setup quality.',

        'Setup Matrix': 'Use this matrix for one compact view of source, roots, profile fit, and next action.',

        'Source Relationship': 'This view shows how the current source connects to coverage, indexing, sidecars, and profile fit.',

        'Profile Summary': 'Use this summary to confirm how many profiles are available, visible, and goal-ready.',

        'Root Coverage': 'Check root coverage when you need to confirm which library roots are actually ready to support the source.',

        'Consistency Review': 'Use consistency review to spot mismatched setup details before they become workflow problems.',

        'Latest Repair Snapshot': 'Read the latest repair snapshot to confirm what Smart Fix changed most recently.',

        'Smart Fix Preview': 'Use this preview when you want to inspect proposed repair changes before running Smart Fix.',

        'Goal Reading Lane': 'Use this ordered reading lane when you want the fastest path through report-specific sections for the current goal.',

        'UI Follow-up Lane': 'Use this lane when you are done reading and want the fastest UI path back into guided work.',

    }

    return mapping.get(heading, '')





def _sf_report_section_role(report_title: str, heading: str) -> str:

    normalized_heading = _sf_report_section_heading(heading)

    if normalized_heading not in set(_sf_report_specific_section_headings(report_title)):

        return ''

    mapping = {

        'Workflow Path': 'Primary check',

        'Goal Guidance': 'Compare here',

        'Profile Coverage': 'Compare here',

        'Release Gates': 'Share-ready proof',

        'Recent Activity': 'Reference detail',

        'Source Readiness': 'Primary check',

        'Setup Matrix': 'Compare here',

        'Source Relationship': 'Optional context',

        'Profile Summary': 'Reference detail',

        'Root Coverage': 'Compare here',

        'Consistency Review': 'Primary check',

        'Latest Repair Snapshot': 'Share-ready proof',

        'Execution Summary': 'Primary check',

        'Applied Changes': 'Share-ready proof',

        'Smart Fix Preview': 'Reference detail',

    }

    return mapping.get(normalized_heading, '')





def _sf_append_report_section(lines: list[str], heading: str, entries: list[str] | None = None, report_title: str | None = None, goal: str | None = None):

    normalized_heading = _sf_report_section_heading(heading)

    lines.extend(['', _t(normalized_heading)])

    hint = str(_sf_report_section_hint(normalized_heading) or '').strip()

    if hint:

        lines.append(_t(hint))

    if report_title:

        role = str(_sf_report_section_role(report_title, normalized_heading) or '').strip()

        if role:

            lines.append(f"- {_t('Section role')}: {_t(role)}")

        if normalized_heading in set(_sf_report_goal_focus_headings(report_title, goal)):

            rank = _sf_report_goal_focus_rank(report_title, normalized_heading, goal)

            if rank:

                lines.append(f"- {_t('Goal reading order')}: {rank[0]} / {rank[1]}")

            lines.append(f"- {_t('Goal focus')}: {_t('Best match for the current goal.')}")

    if entries:

        for entry in entries:

            text = str(entry or '').strip()

            if text:

                lines.append(text)

    else:

        lines.append(f"- {_t('No recommendation is available yet.')}")





def _sf_append_report_sections(lines: list[str], sections: list[tuple[str, list[str] | None]], report_title: str | None = None, goal: str | None = None):

    for heading, entries in sections:

        _sf_append_report_section(lines, heading, entries, report_title=report_title, goal=goal)





def _sf_report_role_priority(role: str) -> int:

    role = str(role or '').strip()

    mapping = {

        'Primary check': 0,

        'Compare here': 1,

        'Share-ready proof': 2,

        'Reference detail': 3,

        'Optional context': 4,

    }

    return mapping.get(role, 99)





def _sf_report_goal_focus_headings(report_title: str, goal: str | None) -> list[str]:

    goal = str(goal or 'IMPORT').upper().strip()

    mapping = {

        _t('Workspace Report'): {

            'EXPLORE': ['Workflow Path', 'Source Relationship', 'Profile Summary'],

            'IMPORT': ['Workflow Path', 'Root Coverage', 'Source Relationship'],

            'MAINTAIN': ['Consistency Review', 'Workflow Path', 'Smart Fix Preview'],

            'PUBLISH': ['Consistency Review', 'Release Gates', 'Workflow Path'],

            'RECOVER': ['Consistency Review', 'Smart Fix Preview', 'Recent Activity'],

        },

        _t('Smart Fix Report'): {

            'EXPLORE': ['Execution Summary', 'Applied Changes'],

            'IMPORT': ['Execution Summary', 'Applied Changes'],

            'MAINTAIN': ['Execution Summary', 'Applied Changes'],

            'PUBLISH': ['Execution Summary', 'Applied Changes'],

            'RECOVER': ['Execution Summary', 'Applied Changes'],

        },

        _t('Product Readiness Report'): {

            'EXPLORE': ['Goal Guidance', 'Source Readiness', 'Setup Matrix'],

            'IMPORT': ['Source Readiness', 'Setup Matrix', 'Goal Guidance'],

            'MAINTAIN': ['Source Readiness', 'Setup Matrix', 'Goal Guidance'],

            'PUBLISH': ['Source Readiness', 'Goal Guidance', 'Setup Matrix'],

            'RECOVER': ['Source Readiness', 'Setup Matrix', 'Goal Guidance'],

        },

        _t('Handoff Report'): {

            'EXPLORE': ['Goal Guidance', 'Profile Coverage', 'Recent Activity'],

            'IMPORT': ['Goal Guidance', 'Profile Coverage', 'Recent Activity'],

            'MAINTAIN': ['Profile Coverage', 'Latest Repair Snapshot', 'Recent Activity'],

            'PUBLISH': ['Profile Coverage', 'Latest Repair Snapshot', 'Goal Guidance'],

            'RECOVER': ['Latest Repair Snapshot', 'Profile Coverage', 'Recent Activity'],

        },

        _t('Release Report'): {

            'EXPLORE': ['Consistency Review', 'Release Gates'],

            'IMPORT': ['Consistency Review', 'Release Gates'],

            'MAINTAIN': ['Consistency Review', 'Release Gates'],

            'PUBLISH': ['Release Gates', 'Consistency Review'],

            'RECOVER': ['Consistency Review', 'Release Gates'],

        },

        _t('Session Bundle'): {

            'EXPLORE': ['Workflow Path', 'Goal Guidance', 'Profile Coverage'],

            'IMPORT': ['Workflow Path', 'Goal Guidance', 'Profile Coverage'],

            'MAINTAIN': ['Workflow Path', 'Latest Repair Snapshot', 'Profile Coverage'],

            'PUBLISH': ['Release Gates', 'Latest Repair Snapshot', 'Workflow Path'],

            'RECOVER': ['Latest Repair Snapshot', 'Recent Activity', 'Workflow Path'],

        },

    }

    report_map = mapping.get(report_title, {})

    ordered = report_map.get(goal, report_map.get('IMPORT', []))

    return [_sf_report_section_heading(h) for h in ordered]





def _sf_report_goal_focus_priority(report_title: str, heading: str, goal: str | None) -> int:

    normalized_heading = _sf_report_section_heading(heading)

    ordered = _sf_report_goal_focus_headings(report_title, goal)

    try:

        return ordered.index(normalized_heading)

    except ValueError:

        return 999





def _sf_report_goal_focus_rank(report_title: str, heading: str, goal: str | None) -> tuple[int, int] | None:

    normalized_heading = _sf_report_section_heading(heading)

    ordered = [h for h in _sf_report_goal_focus_headings(report_title, goal) if h]

    try:

        idx = ordered.index(normalized_heading)

    except ValueError:

        return None

    return (idx + 1, max(1, len(ordered)))





def _sf_report_ordered_specific_sections(report_title: str, sections: list[tuple[str, list[str] | None]], goal: str | None = None) -> list[tuple[str, list[str] | None]]:

    normalized = _sf_report_specific_section_headings(report_title)

    original_index = {heading: idx for idx, heading in enumerate(normalized)}



    def _key(item):

        heading, _entries = item

        normalized_heading = _sf_report_section_heading(heading)

        role = _sf_report_section_role(report_title, normalized_heading)

        goal_priority = _sf_report_goal_focus_priority(report_title, normalized_heading, goal)

        is_goal_focus = 0 if goal_priority != 999 else 1

        return (

            is_goal_focus,

            goal_priority,

            _sf_report_role_priority(role),

            original_index.get(normalized_heading, 999),

            normalized_heading,

        )



    return sorted(list(sections or []), key=_key)





def _sf_report_readiness_snapshot_lines(data: dict) -> list[str]:

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    has_source = bool(data.get('has_source'))

    coverage_status = _t('Ready') if (has_source and roots_ready and bool(source_info.get('inside_root'))) else (_t('Needs roots') if has_source else _t('Needs source'))

    index_status = _t('Indexed') if (has_source and index_ready and bool(source_info.get('is_indexed'))) else (_t('Needs index') if has_source else _t('Needs source'))

    preview_status = _t('Ready') if bool(source_info.get('preview_path')) else (_t('Missing') if has_source else _t('Not set'))

    metadata_status = _t('Ready') if bool(source_info.get('meta_path')) else (_t('Missing') if has_source else _t('Not set'))

    catalog_status = _t('Ready') if bool(source_info.get('catalog_path')) else (_t('Missing') if has_source else _t('Not set'))

    return [

        f"- {_t('Source Coverage')}: {coverage_status}" + (f" | {source_info.get('root_name', '')}" if bool(source_info.get('inside_root')) and source_info.get('root_name') else ''),

        f"- {_t('Index State')}: {index_status}",

        f"- {_t('Preview Sidecar')}: {preview_status}",

        f"- {_t('Metadata Sidecar')}: {metadata_status}",

        f"- {_t('Nearby Catalog')}: {catalog_status}",

    ]





def _sf_report_recommended_next_step_lines(data: dict) -> list[str]:

    actions = list(data.get('actions', []) or [])

    if actions:

        action = actions[0]

        return [

            f"- {action.get('title', _t('No blocker detected'))}",

            f"  {action.get('detail', '')}",

        ]

    return [f"- {_t('No recommendation is available yet.')}"]





def _sf_report_focus_lines(report_title: str, data: dict) -> list[str]:

    goal_label = _t(str(data.get('goal', 'IMPORT')).title())

    if report_title == _t('Workspace Report'):

        return [f"- {_t('Use this as the everyday summary for health, roots, profiles, and next actions.')}"]

    if report_title == _t('Smart Fix Report'):

        return [f"- {_t('Use this to confirm what Smart Fix changed before you continue with maintenance, publishing, or handoff work.')}"]

    if report_title == _t('Product Readiness Report'):

        return [f"- {_t('Use this to see whether the current source is ready for product-facing review and handoff.')}"]

    if report_title == _t('Handoff Report'):

        return [f"- {_t('Use this when you need a transfer-ready snapshot with blockers, profile coverage, activity, and repair history.')}"]

    if report_title == _t('Release Report'):

        return [f"- {_t('Use this to verify the final go / no-go release checks for the current source.')}"]

    if report_title == _t('Session Bundle'):

        return [f"- {_t('Use this when you want one larger archive-style snapshot that combines workspace health, handoff context, release checks, and recent repair history.')}"]

    return [f"- {_t('Use this report to review the current setup for the')} {goal_label}"]





def _sf_report_specific_section_headings(report_title: str) -> list[str]:

    mapping = {

        _t('Workspace Report'): [

            'Relationship Map',

            'Workspace Pipeline',

            'Profile Overview',

            'Release Gate Summary',

            'Root Coverage Matrix',

            'Consistency Check',

            'Smart Fix Preview',

            'Activity Timeline',

        ],

        _t('Smart Fix Report'): [

            'Execution Summary',

            'Applied Changes',

        ],

        _t('Product Readiness Report'): [

            'Source Readiness Matrix',

            'Goal Home Cards',

            'Source / Root / Profile Matrix',

        ],

        _t('Handoff Report'): [

            'Goal Home Cards',

            'Profile Coverage Board',

            'Activity Timeline',

            'Last Repair Snapshot',

        ],

        _t('Release Report'): [

            'Release Gate Summary',

            'Consistency Check',

        ],

        _t('Session Bundle'): [

            'Workspace Pipeline',

            'Goal Home Cards',

            'Profile Coverage Board',

            'Release Gate Summary',

            'Last Repair Snapshot',

            'Activity Timeline',

        ],

    }

    return [_sf_report_section_heading(h) for h in mapping.get(report_title, [])]





def _sf_report_goal_reading_lane_lines(report_title: str, data: dict) -> list[str]:

    goal = str(data.get('goal', 'IMPORT') or 'IMPORT').upper()

    focus_headings = [h for h in _sf_report_goal_focus_headings(report_title, goal) if h]

    if not focus_headings:

        return [f"- {_t('No recommendation is available yet.')}"]

    lines = [f"- {_t('Read this lane first for the current goal before moving to lower-priority reference sections.')}"]

    total = len(focus_headings)

    for idx, heading in enumerate(focus_headings, 1):

        role = str(_sf_report_section_role(report_title, heading) or '').strip()

        hint = str(_sf_report_section_hint(heading) or _t('Use this section for the report-specific details after the quick summary.')).strip()

        lines.append(f"- {idx}. {_t(heading)}")

        lines.append(f"  {_t('Goal reading order')}: {idx} / {total}")

        if role:

            lines.append(f"  {_t('Section role')}: {_t(role)}")

        lines.append(f"  {_t('Why now')}: {_t(hint)}")

    return lines





def _sf_report_section_map_lines(report_title: str, data: dict) -> list[str]:

    goal = str(data.get('goal', 'IMPORT') or 'IMPORT').upper()

    focus_headings = _sf_report_goal_focus_headings(report_title, goal)

    lines = [

        f"- {_t('Read first')}: {_t('Quick Read')}",

        f"  {_t('Fastest summary of current state, blockers, and the best follow-up report.')}",

        f"- {_t('Confirm next')}: {_t('Immediate Blockers')}",

        f"  {_t('Best place to see what is still stopping progress right now.')}",

    ]

    focus_label = '/'.join(_t(h) for h in focus_headings[:2] if h)

    if focus_label:

        lines.append(f"- {_t('Goal focus now')}: {focus_label}")

        lines.append(f"  {_t('Read these sections first for the current goal before the lower-priority reference sections.')}")

        lines.append(f"  {_t('Goal Reading Lane')}: {_t('Use this lane to read the best-matching report sections in order for the current goal.')}")

    seen = set()

    ordered_headings = [

        heading for heading, _entries in _sf_report_ordered_specific_sections(

            report_title,

            [(heading, None) for heading in _sf_report_specific_section_headings(report_title)],

            goal=goal,

        )

    ]

    focus_set = set(focus_headings)

    for heading in ordered_headings:

        if heading in seen:

            continue

        seen.add(heading)

        hint = str(_sf_report_section_hint(heading) or _t('Use this section for the report-specific details after the quick summary.')).strip()

        role = str(_sf_report_section_role(report_title, heading) or '').strip()

        lines.append(f"- {_t(heading)}")

        if role:

            lines.append(f"  {_t('Section role')}: {_t(role)}")

        if heading in focus_set:

            rank = _sf_report_goal_focus_rank(report_title, heading, goal)

            if rank:

                lines.append(f"  {_t('Goal reading order')}: {rank[0]} / {rank[1]}")

            lines.append(f"  {_t('Goal focus')}: {_t('Best match for the current goal.')}")

        lines.append(f"  {_t(hint)}")

    lines.append(f"- {_t('Finish with')}: {_t('Follow-up')} / {_t('UI Follow-up Lane')} / {_t('Export Notes')}")

    lines.append(f"  {_t('Use these last sections when you are ready to choose the next screen or share the exported text.')}")

    return lines





def _sf_report_next_tool_choice(report_title: str, data: dict) -> tuple[str, str]:

    if report_title == _t('Workspace Report'):

        return (_t('Source Check'), _t('Open this next when you want to verify the active source and then continue with the next guided action.'))

    if report_title == _t('Smart Fix Report'):

        return (_t('Smart Fix Details'), _t('Open this next when you want to inspect the last Smart Fix result in the UI before continuing.'))

    if report_title == _t('Product Readiness Report'):

        return (_t('Final Review'), _t('Open this next when you want a compact checkpoint after this source-focused readiness review.'))

    if report_title == _t('Handoff Report'):

        return (_t('Final Review'), _t('Open this next when you want a compact checkpoint before sharing or delivery.'))

    if report_title == _t('Release Report'):

        return (_t('Release Gate'), _t('Open this next when you want the visual gate board beside this release summary.'))

    if report_title == _t('Session Bundle'):

        return (_t('Final Review'), _t('Open this next when you want a narrower checkpoint after the larger archive snapshot.'))

    return (_t('Goal Home'), _t('Open this next when you want the next guided workspace step after reading this report.'))





def _sf_report_follow_up_lines(report_title: str, data: dict) -> list[str]:

    actions = list(data.get('actions', []) or [])

    next_report, next_report_reason = _sf_report_recommended_report_choice(report_title, data)

    next_tool, next_tool_reason = _sf_report_next_tool_choice(report_title, data)

    return [

        f"- {_t('Next action')}: {actions[0].get('title', _t('No blocker detected')) if actions else _t('No blocker detected')}",

        f"- {_t('Best Follow-up Report')}: {next_report}",

        f"  {next_report_reason}",

        f"- {_t('Next tool to open')}: {next_tool}",

        f"  {next_tool_reason}",

    ]





def _sf_report_after_reading_lines(report_title: str, data: dict) -> list[str]:

    next_report, next_report_reason = _sf_report_recommended_report_choice(report_title, data)

    next_tool, next_tool_reason = _sf_report_next_tool_choice(report_title, data)

    return [

        f"- {_t('Start here')}: {next_tool}",

        f"  {next_tool_reason}",

        f"- {_t('Then compare with')}: {next_report}",

        f"  {next_report_reason}",

        f"- {_t('Keep this report open if you want to compare the next UI check against this exported summary.')}",

    ]





def _sf_report_ui_follow_up_screens(report_title: str, data: dict) -> list[tuple[str, str]]:

    report_title = str(report_title or '')

    mapping = {

        _t('Workspace Report'): [

            (_t('Source Check'), _t('Open this first when you want to verify the current source before continuing.')),

            (_t('Goal Home'), _t('Open this next when you want the guided next step for the current goal.')),

            (_t('Action Palette'), _t('Open this when you want one compact list of commands after the report review.')),

        ],

        _t('Smart Fix Report'): [

            (_t('Smart Fix Details'), _t('Open this first when you want the full repair breakdown in the UI.')),

            (_t('Source Check'), _t('Open this next when you want to confirm the source state after the fix.')),

            (_t('Final Review'), _t('Open this after the fix when you want a compact checkpoint before moving on.')),

        ],

        _t('Product Readiness Report'): [

            (_t('Final Review'), _t('Open this first when you want a compact readiness checkpoint after the source-focused report.')),

            (_t('Source Check'), _t('Open this next when you want to verify sidecars, roots, and index coverage in the UI.')),

            (_t('Goal Home'), _t('Open this after the readiness check when you want the next guided move for the current goal.')),

        ],

        _t('Handoff Report'): [

            (_t('Final Review'), _t('Open this first when you want a compact pre-share checkpoint.')),

            (_t('Release Gate'), _t('Open this next when delivery or publish readiness also needs a visible gate decision.')),

            (_t('Goal Home'), _t('Open this after the handoff review when you want the next guided workspace step.')),

        ],

        _t('Release Report'): [

            (_t('Release Gate'), _t('Open this first when you want the visual gate board beside the release summary.')),

            (_t('Final Review'), _t('Open this next when you want a compact checkpoint after the release call.')),

            (_t('Goal Home'), _t('Open this after the release review when the workspace needs the next guided action.')),

        ],

        _t('Session Bundle'): [

            (_t('Final Review'), _t('Open this first when you want a narrower checkpoint after the broad bundle snapshot.')),

            (_t('Source Check'), _t('Open this next when you want to validate the active source against the bundle summary.')),

            (_t('Goal Home'), _t('Open this after the bundle review when you want the next guided workspace action.')),

        ],

    }

    return list(mapping.get(report_title, [

        (_t('Goal Home'), _t('Open this first when you want the next guided workspace step after reading the report.')),

        (_t('Source Check'), _t('Open this next when you want to verify the active source in the UI.')),

        (_t('Action Palette'), _t('Open this when you want one compact list of commands after the report review.')),

    ]))





def _sf_report_ui_follow_up_lane_lines(report_title: str, data: dict) -> list[str]:

    screens = _sf_report_ui_follow_up_screens(report_title, data)

    if not screens:

        return [f"- {_t('No recommendation is available yet.')}"]

    total = len(screens)

    lines = [f"- {_t('Use this lane when you are done reading and want the fastest UI path back into guided work.')}"]

    for idx, (screen_title, reason) in enumerate(screens, 1):

        lines.append(f"- {idx}. {screen_title}")

        lines.append(f"  {_t('UI follow-up order')}: {idx} / {total}")

        lines.append(f"  {_t('Why open this')}: {reason}")

    return lines





def _sf_report_action_summary_lines(data: dict, limit: int = 6) -> list[str]:

    actions = list(data.get('actions', []) or [])

    if actions:

        lines = []

        for action in actions[:max(1, int(limit or 1))]:

            title = str(action.get('title', _t('No blocker detected')) or _t('No blocker detected')).strip()

            detail = str(action.get('detail', '') or '').strip()

            lines.append(f"- {title}" + (f": {detail}" if detail else ''))

        return lines

    return [f"- {_t('No recommendation is available yet.')}"]





def _sf_report_intro_sections(report_title: str, context, data: dict) -> list[tuple[str, list[str] | None]]:

    return [

        ('Quick Read', _sf_report_quick_read_lines(report_title, data)),

        ('Section Map', _sf_report_section_map_lines(report_title, data)),

        ('Goal Reading Lane', _sf_report_goal_reading_lane_lines(report_title, data)),

        ('Overview', _sf_report_overview_lines(report_title, data)),

        ('Decision Summary', _sf_report_decision_summary_lines(report_title, data)),

        ('Why This Report', _sf_report_focus_lines(report_title, data)),

        ('Current Setup', _sf_report_lines_current_setup(context, data)),

        ('Readiness Snapshot', _sf_report_readiness_snapshot_lines(data)),

        ('Immediate Blockers', _sf_report_immediate_blockers_lines(data)),

        ('Action Summary', _sf_report_action_summary_lines(data)),

    ]





def _sf_report_closing_sections(report_title: str, data: dict) -> list[tuple[str, list[str] | None]]:

    return [

        ('Follow-up', _sf_report_follow_up_lines(report_title, data)),

        ('UI Follow-up Lane', _sf_report_ui_follow_up_lane_lines(report_title, data)),

        ('Next Review', _sf_report_after_reading_lines(report_title, data)),

        ('Export Notes', _sf_report_export_notes_lines(report_title, data)),

    ]





def _sf_append_report_core_sections(lines: list[str], report_title: str, context, data: dict):

    _sf_append_report_sections(lines, _sf_report_intro_sections(report_title, context, data), report_title=report_title, goal=data.get('goal'))





def _sf_append_report_specific_sections(lines: list[str], report_title: str, sections: list[tuple[str, list[str] | None]], data: dict | None = None):

    goal = (data or {}).get('goal') if isinstance(data, dict) else None

    _sf_append_report_sections(

        lines,

        _sf_report_ordered_specific_sections(report_title, sections, goal=goal),

        report_title=report_title,

        goal=goal,

    )





def _sf_append_report_closing_sections(lines: list[str], report_title: str, data: dict):

    _sf_append_report_sections(lines, _sf_report_closing_sections(report_title, data), report_title=report_title, goal=data.get('goal'))





def _sf_build_smart_fix_report_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

    detail_lines = _sf_last_fix_report_lines(context)

    lines = _sf_report_lines_header(_t('Smart Fix Report'), data)

    _sf_append_report_core_sections(lines, _t('Smart Fix Report'), context, data)

    _sf_append_report_specific_sections(lines, _t('Smart Fix Report'), [

        ('Execution Summary', [f"- {summary or _t('No smart fix report yet')}"]),

        ('Applied Changes', [f"- {line}" for line in detail_lines] if detail_lines else [f"- {_t('No smart fix report yet')}"]),

    ], data=data)

    _sf_append_report_closing_sections(lines, _t('Smart Fix Report'), data)

    return lines





def _sf_build_session_bundle_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    prefs = data.get('prefs')

    filepath = data.get('filepath', '')

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    health_score = int(data.get('health_score', 0) or 0)

    actions = list(data.get('actions', []) or [])

    lines = _sf_report_lines_header(_t('Session Bundle'), data)

    _sf_append_report_core_sections(lines, _t('Session Bundle'), context, data)

    release_rows = _sf_release_gate_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

    release_score, release_passed, release_label = _sf_release_gate_summary(release_rows)

    summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

    detail_lines = _sf_last_fix_report_lines(context)

    _sf_append_report_specific_sections(lines, _t('Session Bundle'), [

        ('Workspace Pipeline', [

            f"- {row.get('title','')}: {row.get('detail','')}"

            for row in _sf_workspace_pipeline_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

        ]),

        ('Goal Home Cards', [

            f"- {_t(str(row.get('goal','IMPORT')).title())}: {row.get('status','')} | {_t('Heavy blocker')}: {row.get('blocker','')} | {_t('Suggested profile')}: {row.get('profile','')}"

            for row in _sf_goal_home_card_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

        ]),

        ('Profile Coverage Board', [

            f"- {_t(str(row.get('goal','IMPORT')).title())}: {_t('Goal support')}={row.get('count',0)} | A={row.get('append',0)} L={row.get('link',0)} O={row.get('override',0)} | {_t('Pinned lead')}: {row.get('lead','')}"

            for row in _sf_profile_coverage_rows(prefs, context=context)

        ]),

        ('Release Gate Summary', [

            f"- {_t('Gate score')}: {release_score}/100",

            f"- {_t('Passed gates')}: {release_passed}/{len(release_rows)}",

            f"- {_t('Gate summary')}: {release_label}",

        ] + [f"  - {row.get('title','')}: {row.get('detail','')}" for row in release_rows]),

        ('Last Repair Snapshot', [f"- {summary or _t('No smart fix report yet')}"] + [f"  - {line}" for line in detail_lines[:10]]),

        ('Activity Timeline', [

            f"- [{entry.get('time','')}] {entry.get('title','')}" + (f": {entry.get('detail','')}" if entry.get('detail') else '')

            for entry in _sf_activity_entries(context)[:12]

        ]),

    ], data=data)

    _sf_append_report_closing_sections(lines, _t('Session Bundle'), data)

    return lines





def _sf_profile_coverage_rows(prefs, context=None) -> list[dict]:

    profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

    rows = []

    for goal in ('EXPLORE', 'IMPORT', 'MAINTAIN', 'PUBLISH', 'RECOVER'):

        matched = []

        for profile in profiles:

            try:

                if not _sf_profile_matches_filter(profile, prefs, context=context):

                    continue

            except Exception:

                pass

            if _sf_profile_matches_goal(profile, goal):

                matched.append(profile)

        rows.append({

            'goal': goal,

            'count': len(matched),

            'append': sum(1 for profile in matched if str(getattr(profile, 'import_mode', '') or '').upper() == 'APPEND'),

            'link': sum(1 for profile in matched if str(getattr(profile, 'import_mode', '') or '').upper() == 'LINK'),

            'override': sum(1 for profile in matched if str(getattr(profile, 'import_mode', '') or '').upper() in {'LINK_OVERRIDE', 'OVERRIDE'}),

            'lead': getattr(matched[0], 'name', '') if matched else _t('No matching profile'),

        })

    return rows





def _sf_draw_profile_coverage_board(parent, prefs, context=None, compact: bool = False):

    box = parent.box()

    _sf_draw_section_intro(box, 'Profile Coverage Board', 'Compare how many profiles support each goal and which profile leads each lane.', 'PRESET')

    rows = _sf_profile_coverage_rows(prefs, context=context)

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows[:(3 if compact else 5)]:

        card = grid.box()

        card.label(text=_t(str(item.get('goal', 'IMPORT')).title()), icon=_sf_goal_icon(item.get('goal', 'IMPORT')))

        _sf_draw_state_line(card, 'Goal support', 'Ready' if int(item.get('count', 0) or 0) > 0 else 'Needs setup', fallback_icon='PRESET', detail=str(item.get('count', 0)))

        card.label(text=f"A={item.get('append',0)}  L={item.get('link',0)}  O={item.get('override',0)}", icon='BLANK1')

        card.label(text=f"{_t('Pinned lead')}: {item.get('lead', _t('No matching profile'))}", icon='BLANK1')

    return box





def _sf_goal_home_card_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict]) -> list[dict]:

    rows = []

    for goal_name in ('EXPLORE', 'IMPORT', 'MAINTAIN', 'PUBLISH', 'RECOVER'):

        gdata = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal_name)

        profile_pair = gdata.get('profile')

        profile_label = _t('No matching profile')

        if profile_pair:

            _idx, profile = profile_pair

            profile_label = getattr(profile, 'name', '') or profile_label

        rows.append({

            'goal': goal_name,

            'status': gdata.get('status', ''),

            'blocker': gdata.get('blocker') or _t('No blocker detected'),

            'profile': profile_label,

            'summary': gdata.get('summary', ''),

        })

    return rows





def _sf_draw_goal_home_cards(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False):

    box = parent.box()

    _sf_draw_section_intro(box, 'Goal Home Cards', 'Compare all workflow goals in one place before choosing the next lane to open.', 'BOOKMARKS')

    rows = _sf_goal_home_card_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows[:(3 if compact else 5)]:

        card = grid.box()

        card.label(text=_t(str(item.get('goal', 'IMPORT')).title()), icon=_sf_goal_icon(item.get('goal', 'IMPORT')))

        _sf_draw_state_line(card, 'Status', 'Ready' if str(item.get('status', '')).lower().startswith('ready') else 'Needs setup', fallback_icon='NONE', detail=str(item.get('status', '') or ''))

        card.label(text=f"{_t('Heavy blocker')}: {item.get('blocker', '')}", icon='BLANK1')

        card.label(text=f"{_t('Suggested profile')}: {item.get('profile', '')}", icon='BLANK1')

    return box





def _sf_source_root_profile_matrix_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict]) -> list[dict]:

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    profile_pair = _sf_best_profile_for_goal(prefs, goal, context=context)

    top_action = actions[0] if actions else None

    return [

        {

            'title': _t('Current Source'),

            'status': os.path.basename(filepath) if has_source else _t('Not set'),

            'detail': _sf_short_path_display(filepath, 72) if has_source else _t('Choose a source .blend file'),

            'icon': 'FILE_BLEND',

        },

        {

            'title': _t('Coverage'),

            'status': source_info.get('root_name') if source_info.get('inside_root') else (_t('Needs roots') if roots_ready else _t('Needs more setup')),

            'detail': _t('Inside library root') if source_info.get('inside_root') else _t('Outside library root'),

            'icon': 'FILE_FOLDER',

        },

        {

            'title': _t('Index'),

            'status': _t('Indexed') if bool(source_info.get('is_indexed')) else _t('Needs index'),

            'detail': _t('Indexed and trackable') if bool(source_info.get('is_indexed')) else _t('Needs index'),

            'icon': 'FILE_REFRESH',

        },

        {

            'title': _t('Matching profile'),

            'status': getattr(profile_pair[1], 'name', '') if profile_pair else _t('No matching profile'),

            'detail': _sf_profile_summary(profile_pair[1]) if profile_pair else _t('No matching profile'),

            'icon': 'PRESET',

        },

        {

            'title': _t('Top Recommendation'),

            'status': top_action.get('title', _t('No blocker detected')) if top_action else _t('No blocker detected'),

            'detail': top_action.get('detail', '') if top_action else '',

            'icon': top_action.get('icon', 'FORWARD') if top_action else 'CHECKMARK',

        },

    ]





def _sf_draw_source_root_profile_matrix(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict], compact: bool = False):

    box = parent.box()

    _sf_draw_section_intro(box, 'Source / Root / Profile Matrix', 'Read the current source, coverage, index, profile fit, and next recommendation in one short matrix.', 'SEQ_STRIP_META')

    rows = _sf_source_root_profile_matrix_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

    for item in rows[:(3 if compact else 5)]:

        row = box.row(align=True)

        row.label(text=item.get('title', ''), icon=item.get('icon', 'NONE'))

        row.label(text=item.get('status', ''), icon='BLANK1')

    return box





def _sf_release_gate_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict]) -> list[dict]:

    has_source = bool(filepath and os.path.isfile(filepath))

    profile_pair = _sf_best_profile_for_goal(prefs, _sf_current_session_goal(context), context=context)

    publish_ready = bool(source_info.get('preview_path')) and bool(source_info.get('meta_path')) and bool(source_info.get('catalog_path'))

    top_action = actions[0] if actions else None

    rows = [

        {'title': _t('Source'), 'passed': has_source, 'detail': os.path.basename(filepath) if has_source else _t('Choose a source .blend file'), 'icon': 'FILE_BLEND'},

        {'title': _t('Coverage'), 'passed': bool(has_source and roots_ready and source_info.get('inside_root')), 'detail': source_info.get('root_name') if source_info.get('inside_root') else (_t('Needs roots') if roots_ready else _t('Library roots are not configured')), 'icon': 'FILE_FOLDER'},

        {'title': _t('Index'), 'passed': bool(has_source and index_ready and source_info.get('is_indexed')), 'detail': _t('Indexed and trackable') if source_info.get('is_indexed') else _t('Needs index'), 'icon': 'FILE_REFRESH'},

        {'title': _t('Publish Data'), 'passed': bool(has_source and publish_ready), 'detail': _t('Preview, metadata, and catalog context ready') if publish_ready else _t('Missing sidecars'), 'icon': 'EXPORT'},

        {'title': _t('Matching profile'), 'passed': bool(profile_pair), 'detail': getattr(profile_pair[1], 'name', '') if profile_pair else _t('No matching profile'), 'icon': 'PRESET'},

        {'title': _t('Top Recommendation'), 'passed': bool(top_action), 'detail': top_action.get('title', _t('No blocker detected')) if top_action else _t('No blocker detected'), 'icon': top_action.get('icon', 'FORWARD') if top_action else 'CHECKMARK'},

        {'title': _t('Health Score'), 'passed': int(health_score or 0) >= 65, 'detail': f"{int(health_score or 0)}/100", 'icon': 'NONE'},

    ]

    for item in rows:

        item['state'] = _t('Ready') if item.get('passed') else _t('Needs more setup')

    return rows





def _sf_release_gate_summary(rows: list[dict]) -> tuple[int, int, str]:

    total = len(rows or [])

    if total <= 0:

        return 0, 0, _t('Needs more setup')

    passed = sum(1 for row in rows if bool(row.get('passed')))

    score = int(round((passed / max(total, 1)) * 100))

    label = _t('Ready now') if passed == total else (_t('Needs more setup') if passed >= max(1, total // 2) else _t('Needs attention'))

    return score, passed, label





def _sf_draw_release_gate_board(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False):

    box = parent.box()

    _sf_draw_section_intro(box, 'Release Gate Summary', 'Check the release gates in one place before publishing or handing off the current source.', 'CHECKMARK')

    rows = _sf_release_gate_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

    score, passed, label = _sf_release_gate_summary(rows)

    box.label(text=f"{_t('Gate score')}: {score}/100", icon='CHECKMARK' if score >= 70 else 'ERROR')

    box.label(text=f"{_t('Passed gates')}: {passed}/{len(rows)} · {label}", icon='BLANK1')

    for item in rows[:(4 if compact else 7)]:

        _sf_draw_state_line(box, item.get('title', ''), 'Ready' if item.get('passed') else 'Needs setup', fallback_icon=item.get('icon', 'NONE'), detail=item.get('detail', ''))

    return box





def _sf_build_product_readiness_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    prefs = data.get('prefs')

    filepath = data.get('filepath', '')

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    health_score = int(data.get('health_score', 0) or 0)

    actions = list(data.get('actions', []) or [])

    lines = _sf_report_lines_header(_t('Product Readiness Report'), data)

    _sf_append_report_core_sections(lines, _t('Product Readiness Report'), context, data)

    _sf_append_report_specific_sections(lines, _t('Product Readiness Report'), [

        ('Source Readiness Matrix', [

            f"- {row.get('title','')}: {int(row.get('score',0) or 0)}/100 | {row.get('detail','')}"

            for row in _sf_source_matrix_rows(context, prefs, filepath, source_info, roots_ready, index_ready)

        ]),

        ('Goal Home Cards', [

            f"- {_t(str(row.get('goal','IMPORT')).title())}: {row.get('status','')} | {_t('Heavy blocker')}: {row.get('blocker','')} | {_t('Suggested profile')}: {row.get('profile','')}"

            for row in _sf_goal_home_card_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

        ]),

        ('Source / Root / Profile Matrix', [

            f"- {row.get('title','')}: {row.get('status','')}" + (f" | {row.get('detail','')}" if row.get('detail') else '')

            for row in _sf_source_root_profile_matrix_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

        ]),

    ], data=data)

    _sf_append_report_closing_sections(lines, _t('Product Readiness Report'), data)

    return lines





def _sf_build_release_readiness_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    prefs = data.get('prefs')

    filepath = data.get('filepath', '')

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    health_score = int(data.get('health_score', 0) or 0)

    actions = list(data.get('actions', []) or [])

    lines = _sf_report_lines_header(_t('Release Report'), data)

    _sf_append_report_core_sections(lines, _t('Release Report'), context, data)

    release_rows = _sf_release_gate_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

    release_score, release_passed, release_label = _sf_release_gate_summary(release_rows)

    _sf_append_report_specific_sections(lines, _t('Release Report'), [

        ('Release Gate Summary', [

            f"- {_t('Gate score')}: {release_score}/100",

            f"- {_t('Passed gates')}: {release_passed}/{len(release_rows)}",

            f"- {_t('Gate summary')}: {release_label}",

        ] + [f"  - {row.get('title','')}: {row.get('detail','')}" for row in release_rows]),

        ('Consistency Check', [

            f"- {row.get('title','')}: {row.get('detail','')}" for row in _sf_consistency_rows(context, prefs, filepath, source_info, roots_ready, index_ready)

        ]),

    ], data=data)

    _sf_append_report_closing_sections(lines, _t('Release Report'), data)

    return lines





def _sf_build_final_handoff_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    prefs = data.get('prefs')

    filepath = data.get('filepath', '')

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    health_score = int(data.get('health_score', 0) or 0)

    actions = list(data.get('actions', []) or [])

    lines = _sf_report_lines_header(_t('Handoff Report'), data)

    _sf_append_report_core_sections(lines, _t('Handoff Report'), context, data)

    summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

    detail_lines = _sf_last_fix_report_lines(context)

    handoff_sections = [

        ('Goal Home Cards', [

            f"- {_t(str(row.get('goal','IMPORT')).title())}: {row.get('status','')} | {_t('Heavy blocker')}: {row.get('blocker','')} | {_t('Suggested profile')}: {row.get('profile','')}"

            for row in _sf_goal_home_card_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

        ]),

        ('Profile Coverage Board', [

            f"- {_t(str(row.get('goal','IMPORT')).title())}: {_t('Goal support')}={row.get('count',0)} | A={row.get('append',0)} L={row.get('link',0)} O={row.get('override',0)} | {_t('Pinned lead')}: {row.get('lead','')}"

            for row in _sf_profile_coverage_rows(prefs, context=context)

        ]),

        ('Activity Timeline', [

            f"- [{entry.get('time','')}] {entry.get('title','')}" + (f": {entry.get('detail','')}" if entry.get('detail') else '')

            for entry in _sf_activity_entries(context)[:10]

        ]),

    ]

    if summary or detail_lines:

        handoff_sections.append(('Last Repair Snapshot', [f"- {summary or _t('No repair snapshot yet')}"] + [f"  - {line}" for line in detail_lines[:10]]))

    _sf_append_report_specific_sections(lines, _t('Handoff Report'), handoff_sections, data=data)

    _sf_append_report_closing_sections(lines, _t('Handoff Report'), data)

    return lines



def _sf_build_workspace_report_lines(context) -> list[str]:

    data = _sf_collect_report_context(context)

    prefs = data.get('prefs')

    filepath = data.get('filepath', '')

    source_info = data.get('source_info') or {}

    roots_ready = bool(data.get('roots_ready'))

    index_ready = bool(data.get('index_ready'))

    health_score = int(data.get('health_score', 0) or 0)

    actions = list(data.get('actions', []) or [])

    index = data.get('index') or {}

    relation = _sf_relationship_map_data(context, prefs, filepath, source_info, roots_ready, index_ready)

    profile_counts = _sf_profile_overview_counts(prefs, context=context)

    lines = _sf_report_lines_header(_t('Workspace Report'), data)

    _sf_append_report_core_sections(lines, _t('Workspace Report'), context, data)

    release_rows = _sf_release_gate_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions)

    release_score, release_passed, release_label = _sf_release_gate_summary(release_rows)

    preview_data = _sf_build_smart_fix_preview(context, prefs)

    _sf_append_report_specific_sections(lines, _t('Workspace Report'), [

        ('Relationship Map', [

            f"- {_t('Source')}: {relation.get('source_label', _t('Not set'))}",

            f"- {_t('Coverage')}: {relation.get('coverage_label', '')}",

            f"- {_t('Indexed Source')}: {relation.get('index_label', '')}",

            f"- {_t('Sidecars')}: {relation.get('sidecars_label', '')}",

            f"- {_t('Matching profile')}: {relation.get('profile_label', _t('No matching profile'))}",

        ]),

        ('Workspace Pipeline', [

            f"- {row.get('title','')}: {row.get('detail','')}"

            for row in _sf_workspace_pipeline_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

        ]),

        ('Profile Overview', [

            f"- {_t('Total Profiles')}: {profile_counts.get('total', 0)}",

            f"- {_t('Visible Profiles')}: {profile_counts.get('visible', 0)}",

            f"- {_t('Pinned Profiles')}: {profile_counts.get('pinned', 0)}",

            f"- {_t('Goal Matches')}: {profile_counts.get('goal_matches', 0)}",

        ]),

        ('Release Gate Summary', [

            f"- {_t('Gate score')}: {release_score}/100",

            f"- {_t('Passed gates')}: {release_passed}/{len(release_rows)}",

            f"- {_t('Gate summary')}: {release_label}",

        ] + [f"  - {row.get('title','')}: {row.get('detail','')}" for row in release_rows]),

        ('Root Coverage Matrix', [

            f"- {row.get('name')}: {row.get('status')} | {_t('Indexed Count')} {row.get('indexed_count', 0)} | {_t('Current Source')}: " + (_t('Inside root') if row.get('inside_source') else _t('Outside root'))

            for row in _sf_root_coverage_matrix_rows(prefs, index, filepath)[:12]

        ]),

        ('Consistency Check', [

            f"- {row.get('title','')}: {row.get('detail','')}" for row in _sf_consistency_rows(context, prefs, filepath, source_info, roots_ready, index_ready)

        ]),

        ('Smart Fix Preview', [f"- {preview_data.get('summary','')}"] + [f"  - {line}" for line in preview_data.get('lines', [])[:8]]),

        ('Activity Timeline', [

            f"- [{entry.get('time','')}] {entry.get('title','')}" + (f": {entry.get('detail','')}" if entry.get('detail') else '')

            for entry in _sf_activity_entries(context)[:8]

        ]),

    ], data=data)

    _sf_append_report_closing_sections(lines, _t('Workspace Report'), data)

    return lines





class SF_OT_reference_manager_workspace_report(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_workspace_report'

    bl_label = 'Workspace Report'

    bl_description = 'Write a text report with current source health, setup snapshot, root coverage, and recommended actions'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        lines = _sf_build_workspace_report_lines(context)

        text_name = _sf_report_export(

            context,

            _t('Workspace Report'),

            lines,

            open_text=self.open_text,

            activity_title=_t('Exported workspace report'),

        )

        self.report({'INFO'}, f"{_t('Workspace report exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_workspace_command_session_bundle(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_session_bundle'

    bl_label = 'Session Bundle'

    bl_description = 'Write a larger handoff bundle with workspace health, goal roadmaps, visible profiles, activity, and recent repair details'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open bundle after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        lines = _sf_build_session_bundle_lines(context)

        text_name = _sf_report_export(

            context,

            _t('Session Bundle'),

            lines,

            open_text=self.open_text,

            activity_title=_t('Exported session bundle'),

        )

        self.report({'INFO'}, f"{_t('Session bundle exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_workspace_command_goal_roadmap(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_goal_roadmap'

    bl_label = 'Goal Roadmap'

    bl_description = 'Open a focused goal board that shows blockers, recommended actions, matching profiles, and quick fixes for one workflow goal'

    bl_options = {'INTERNAL'}



    goal: EnumProperty(

        name='Goal',

        items=[('EXPLORE', 'Explore', ''), ('IMPORT', 'Import', ''), ('MAINTAIN', 'Maintain', ''), ('PUBLISH', 'Publish', ''), ('RECOVER', 'Recover', '')],

        default='IMPORT',

        options={'HIDDEN'},

    )

    popup_width: IntProperty(default=560, min=360, max=960, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened goal board'), str(self.goal or ''), _sf_goal_icon(self.goal))

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        gdata = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=self.goal)



        hero = layout.box()

        hero.label(text=f"{_t('Focused goal board')}: {_t(str(self.goal).title())}", icon=_sf_goal_icon(self.goal))

        hero.label(text=f"{_t('Focus Status')}: {gdata.get('status', '')}", icon='CHECKMARK' if not gdata.get('blocker') else 'ERROR')

        hero.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        row = hero.row(align=True)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_set_goal, text=_t('Set goal'), icon='BOOKMARKS')

        _sf_safe_set_operator_property(op, 'goal', self.goal)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_open_goal, text=_t('Apply & Open'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'goal', self.goal)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_save_goal_snapshot, text=_t('Save Goal Snapshot'), icon='ADD')

        _sf_safe_set_operator_property(op, 'goal', self.goal)



        _sf_draw_session_cockpit(layout, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True)



        blocker = layout.box()

        blocker.label(text=_t('Main blocker'), icon='ERROR' if gdata.get('blocker') else 'CHECKMARK')

        blocker.label(text=gdata.get('blocker') or _t('No blocker detected'), icon='ERROR' if gdata.get('blocker') else 'CHECKMARK')

        blocker.label(text=gdata.get('summary', ''), icon='BLANK1')



        prof_box = layout.box()

        prof_box.label(text=_t('Suggested Profiles'), icon='PRESET')

        matched = _sf_profiles_for_goal(prefs, self.goal, context=context)

        if matched:

            for idx, profile in matched[:3]:

                card = prof_box.box()

                card.label(text=getattr(profile, 'name', '') or _ui_text(f'Profile {idx+1}', f'プロファイル {idx + 1}'), icon='PRESET', translate=False)

                card.label(text=_sf_profile_summary(profile), icon='BLANK1')

                note = _sf_profile_note_text(profile)

                if note:

                    card.label(text=note)

                row = card.row(align=True)

                op = row.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=_t('Apply Profile'), icon='CHECKMARK')

                _sf_safe_set_operator_property(op, 'index', idx)

                op = row.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text=_t('Apply & Open'), icon='PLAY')

                _sf_safe_set_operator_property(op, 'index', idx)

                op = row.operator(SF_OT_workspace_profile_edit_profile.bl_idname, text=_t('Edit Profile'), icon='GREASEPENCIL')

                _sf_safe_set_operator_property(op, 'index', idx)

        else:

            prof_box.label(text=_t('No matching profile'))

            prof_box.operator(SF_OT_workspace_profile_seed_default_profiles.bl_idname, text=_t('Seed Default Profiles'), icon='PRESET')



        _sf_draw_goal_playbook_panel(layout, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True, goal_override=self.goal)

        _sf_draw_goal_roadmap_panel(layout, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True, goal_override=self.goal)

        _sf_draw_source_matrix_panel(layout, context, prefs, filepath, source_info, roots_ready, index_ready, compact=True)

        _sf_draw_workspace_pipeline(layout, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=True)

        _sf_draw_blocker_stack(layout, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=True)

        _sf_draw_profile_tag_matrix(layout, prefs, context=context, compact=True)

        _sf_draw_profile_signal_board(layout, prefs, context, compact=True)

        _sf_draw_goal_scoreboard(layout, context, prefs, filepath, source_info, roots_ready, index_ready, compact=True)

        _sf_draw_profile_match_board(layout, prefs, context, filepath, source_info, compact=True)

        _sf_draw_consistency_panel(layout, context, prefs, filepath, source_info, roots_ready, index_ready, compact=True)

        _sf_draw_action_queue_panel(layout, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, compact=True)



        ready = layout.box()

        ready.label(text=_t('Readiness Checklist'), icon='CHECKMARK')

        _sf_draw_readiness_checklist(ready, context, compact=True)



        rel = layout.box()

        rel.label(text=_t('Source Relationship'), icon='SHADERFX')

        _sf_draw_relationship_map(rel, context, prefs, filepath, source_info, roots_ready, index_ready, compact=True)



        att = layout.box()

        att.label(text=_t('Root Attention'), icon='FILE_FOLDER')

        _sf_draw_root_attention_panel(att, context, prefs, index, source_info, compact=True)



        act_box = layout.box()

        act_box.label(text=_t('Primary actions'), icon='FORWARD')

        if gdata.get('actions'):

            for action in gdata.get('actions', [])[:2]:

                _sf_draw_recommended_action(act_box, action)

        else:

            act_box.label(text=_t('No blocker detected'), icon='CHECKMARK')

        if str(self.goal or '').upper() == 'RECOVER':

            act_box.operator(SF_OT_workspace_command_fix_all.bl_idname, text=_t('Fix All'), icon='TOOL_SETTINGS')

        _sf_draw_repair_pack_panel(layout, context, prefs, filepath, source_info, compact=True)





class SF_OT_workspace_command_save_goal_snapshot(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_save_goal_snapshot'

    bl_label = 'Save Goal Snapshot'

    bl_description = 'Save the current browser setup as a goal-focused workspace profile snapshot so you can quickly return to this state later'

    bl_options = {'UNDO', 'INTERNAL'}



    goal: EnumProperty(

        name='Goal',

        items=[('EXPLORE', 'Explore', ''), ('IMPORT', 'Import', ''), ('MAINTAIN', 'Maintain', ''), ('PUBLISH', 'Publish', ''), ('RECOVER', 'Recover', '')],

        default='IMPORT',

        options={'HIDDEN'},

    )

    pin_profile: BoolProperty(name='Pin profile', default=True, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        wm = context.window_manager

        if not prefs:

            return {'CANCELLED'}

        goal = str(self.goal or _sf_current_session_goal(context) or 'IMPORT').upper()

        fp = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        source_name = os.path.splitext(os.path.basename(fp))[0] if fp else ''

        base = _t(goal.title()) + 'Snapshot'

        if source_name:

            base = f"{base} · {source_name}"

        profile = prefs.workspace_profiles.add()

        profile.name = _sf_unique_workspace_profile_name(prefs, base)

        _sf_capture_current_profile(profile, wm)

        profile.tag = goal.title()

        if self.pin_profile:

            profile.pinned = True

        if not str(getattr(profile, 'notes', '') or '').strip():

            profile.notes = _t('Save the current setup as a goal-focused snapshot profile so you can return to this working state quickly.')

        try:

            prefs.workspace_profile_active_index = len(prefs.workspace_profiles) - 1

            prefs.workspace_profile_name = profile.name

        except Exception:

            pass

        self.report({'INFO'}, f"{_t('Goal snapshot saved')}: {profile.name}")

        _sf_append_activity(context, _t('Saved goal snapshot'), profile.name, _sf_goal_icon(goal))

        return {'FINISHED'}





class SF_OT_library_roots_add_source_folder_as_root(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_add_source_folder_as_root'

    bl_label = 'Add Source Folder as Root'

    bl_description = 'Add the folder of the current source .blend file as a library root so diagnostics, indexing, and publish tools can include it immediately'

    bl_options = {'UNDO', 'INTERNAL'}



    mode: EnumProperty(

        name='Root Source',

        items=[

            ('CURRENT_FOLDER', "Current source folder", "Use the folder that directly contains the current source .blend file"),

            ('PARENT_FOLDER', "Parent of source folder", "Use the parent folder of the current source .blend file folder"),

        ],

        default='CURRENT_FOLDER',

        options={'HIDDEN'},

    )



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        filepath = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '')

        if not filepath or not os.path.isfile(filepath):

            self.report({'WARNING'}, _t('File not found'))

            return {'CANCELLED'}

        folder = _norm_path(os.path.dirname(filepath))

        if self.mode == 'PARENT_FOLDER':

            parent = _norm_path(os.path.dirname(folder))

            if parent:

                folder = parent

        if not folder or not os.path.isdir(folder):

            self.report({'WARNING'}, _t('Invalid file'))

            return {'CANCELLED'}

        path, added = _sf_add_library_root_path(prefs, folder)

        if not path:

            self.report({'WARNING'}, _t('Invalid file'))

            return {'CANCELLED'}

        if added:

            self.report({'INFO'}, f"{_t('Library root added')}: {folder}")

            _sf_append_activity(context, _t('Added library root from current source'), folder, 'FILE_FOLDER')

        else:

            self.report({'INFO'}, f"{_t('Library root already exists')}: {folder}")

        return {'FINISHED'}





class SF_OT_library_roots_clean_roots(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_library_roots_clean_roots'

    bl_label = 'Clean Roots'

    bl_description = 'Remove empty, missing, and duplicate library roots to keep diagnostics and publish searches cleaner'

    bl_options = {'UNDO', 'INTERNAL'}



    remove_missing: BoolProperty(default=True, options={'HIDDEN'})

    deduplicate: BoolProperty(default=True, options={'HIDDEN'})

    sort_by_priority: BoolProperty(default=True, options={'HIDDEN'})



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        existing = []

        for root in list(getattr(prefs, 'library_roots', []) or []):

            existing.append({

                'path': _norm_path(getattr(root, 'path', '') or ''),

                'enabled': bool(getattr(root, 'enabled', True)),

                'priority': int(getattr(root, 'priority', 0) or 0),

            })

        cleaned = []

        seen = {}

        removed_empty = 0

        removed_missing = 0

        removed_dup = 0

        for item in existing:

            path = item['path']

            if not path:

                removed_empty += 1

                continue

            if self.remove_missing and not os.path.isdir(path):

                removed_missing += 1

                continue

            if self.deduplicate and path in seen:

                # 同じ根が重なった時は、有効な方の状態を残す

                seen[path]['enabled'] = seen[path]['enabled'] or item['enabled']

                seen[path]['priority'] = max(seen[path]['priority'], item['priority'])

                removed_dup += 1

                continue

            seen[path] = item

            cleaned.append(item)

        if self.sort_by_priority:

            cleaned.sort(key=lambda it: (not it['enabled'], -(it['priority'] or 0), (os.path.basename(it['path']) or it['path']).lower(), it['path'].lower()))

        while len(prefs.library_roots):

            prefs.library_roots.remove(len(prefs.library_roots) - 1)

        for item in cleaned:

            root = prefs.library_roots.add()

            root.path = item['path']

            root.enabled = item['enabled']

            root.priority = item['priority']

        if not (removed_empty or removed_missing or removed_dup):

            self.report({'INFO'}, _t('No library-root cleanup changes were needed'))

            return {'FINISHED'}

        bits = []

        if removed_empty:

            bits.append(_ui_text(f"empty {removed_empty}", f'空 {removed_empty}'))

        if removed_missing:

            bits.append(_ui_text(f"missing {removed_missing}", f'見つからない {removed_missing}'))

        if removed_dup:

            bits.append(_ui_text(f"duplicate {removed_dup}", f'重複 {removed_dup}'))

        self.report({'INFO'}, f"{_t('Cleaned')}: " + ','.join(bits))

        _sf_append_activity(context, _t('Cleaned library roots'), ','.join(bits), 'BRUSH_DATA')

        return {'FINISHED'}





def _sf_build_recommended_actions(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int = 0) -> list[dict]:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    actions: list[dict] = []



    def add(title, detail, operator, icon='CHECKMARK', button=None, preset=None, goal_value=''):

        operator_id = str(operator or '').strip()

        actions.append({

            'title': title,

            'detail': detail,

            'operator': operator_id,

            'icon': icon,

            'button': _sf_review_run_button_text() if _sf_action_requires_review(operator_id) else (button or title),

            'preset': preset or '',

            'goal': goal_value or '',

        })



    if not has_source:

        add(_t('Choose a source file'),

            _t('Select a valid source .blend file first so the browser and health tools know what to inspect.'),

            SF_OT_source_browser_open_folder_2.bl_idname,

            'FILEBROWSER',

            _t('Scene Select'))

        add(_t('Open workflow lane'),

            _t('Apply the import-oriented lane and jump directly into the browser when you are ready to pick datablocks.'),

            SF_OT_reference_manager_apply_setup_and_open.bl_idname,

            'IMPORT',

            _t('Apply Setup & Open'),

            'IMPORT')

        return actions[:3]



    add(_t('Check current source'),

        _t('Open the focused source check and jump straight into the next best action for this file'),

        SF_OT_reference_manager_source_check.bl_idname,

        'CHECKMARK',

        _t('Source Check...'))



    if not roots_ready:

        add(_t('Configure library roots'),

            _t('Library roots are not configured yet, so diagnostics, relink, and publish workflows cannot reach their full range.'),

            SF_OT_asset_library_repair_roots.bl_idname,

            'PREFERENCES',

            _t('Repair Library Roots...'))

        add(_t('Add source folder as root'),

            _t('Set up library roots or add the current source folder as a root to unlock broader diagnostics and publish workflows.'),

            SF_OT_library_roots_add_source_folder_as_root.bl_idname,

            'FILE_FOLDER',

            _t('Add Source Folder as Root'),

            'CURRENT_FOLDER')



    if has_source and roots_ready and not bool(source_info.get('inside_root')):

        add(_t('Bring source into root coverage'),

            _t('Set up library roots or add the current source folder as a root to unlock broader diagnostics and publish workflows.'),

            SF_OT_library_roots_add_source_folder_as_root.bl_idname,

            'FILE_FOLDER',

            _t('Add Source Folder as Root'),

            'CURRENT_FOLDER')



    if roots_ready and (not index_ready or not bool(source_info.get('is_indexed'))):

        add(_t('Build or refresh index'),

            _t('Source needs indexing before library-wide review tools can track it reliably.'),

            SF_OT_asset_library_rebuild_index.bl_idname,

            'FILE_REFRESH',

            _t('Rebuild Library Index'))



    if has_source:

        add(_t('Open import browser'),

            _t('Browse datablocks in the current source and import only what you need with the active workflow settings.'),

            SF_OT_source_browser_import.bl_idname,

            'FILE_REFRESH',

            _t('Import'))



    if roots_ready and index_ready:

        add(_t('Review references'),

            _t('Inspect linked libraries, stale references, and relink candidates once roots and index data are ready.'),

            SF_OT_reference_manager_open.bl_idname,

            'LINKED',

            _t('Reference Manager...'))



    if has_source and (not source_info.get('preview_path') or not source_info.get('meta_path')):

        add(_t('Generate previews'),

            _t('Preview and metadata sidecars are still missing, so visual browsing and publish review can be improved.'),

            SF_OT_asset_preview_batch_preview.bl_idname,

            'RENDER_STILL',

            _t('Asset Preview Batch...'))



    if has_source and roots_ready and not source_info.get('catalog_path'):

        add(_t('Generate catalog draft'),

            _t('Create a draft catalog.json path before large publish or merge operations so categories stay organized.'),

            SF_OT_asset_library_generate_catalog_draft.bl_idname,

            'TEXT',

            _t('Generate Catalog Draft...'))



    if has_source and roots_ready:

        add(_t('Publish current asset'),

            _t('Version and publish the current asset once source, roots, and sidecars are in a healthy state.'),

            SF_OT_publisher_publish_asset.bl_idname,

            'EXPORT',

            _t('Publish Asset...'))



    if has_source and health_score >= 85:

        add(_t('Open workflow lane'),

            _t('Source file is ready for guided workflows'),

            SF_OT_reference_manager_apply_setup_and_open.bl_idname,

            'PLAY',

            _t('Apply Setup & Open'),

            'MANAGE')



    deduped = []

    seen = set()

    for action in actions:

        key = (action.get('operator'), action.get('preset'), action.get('button'))

        if key in seen:

            continue

        seen.add(key)

        deduped.append(action)

    goal = _sf_current_session_goal(context)

    goal_priority = {

        'EXPLORE': {SF_OT_asset_reader_open.bl_idname: 0, SF_OT_source_browser_import.bl_idname: 1, SF_OT_reference_manager_source_check.bl_idname: 2},

        'IMPORT': {SF_OT_source_browser_import.bl_idname: 0, SF_OT_reference_manager_apply_setup_and_open.bl_idname: 1, SF_OT_source_browser_open_folder_2.bl_idname: 2},

        'MAINTAIN': {SF_OT_reference_manager_open.bl_idname: 0, SF_OT_asset_library_rebuild_index.bl_idname: 1, SF_OT_asset_library_diagnostics.bl_idname: 2},

        'PUBLISH': {SF_OT_publisher_publish_asset.bl_idname: 0, SF_OT_asset_preview_batch_preview.bl_idname: 1, SF_OT_asset_library_generate_catalog_draft.bl_idname: 2},

        'RECOVER': {SF_OT_workspace_command_fix_all.bl_idname: 0, SF_OT_reference_manager_source_check.bl_idname: 1, SF_OT_asset_library_diagnostics.bl_idname: 2},

    }

    prio = goal_priority.get(goal, {})

    deduped.sort(key=lambda action: (prio.get(action.get('operator'), 50), 0 if str(action.get('preset', '') or '').upper() == goal else 1, action.get('title', '')))

    if goal == 'RECOVER':

        deduped.insert(0, {

            'title': _t('Smart Fix All'),

            'detail': _t('Run a safe batch of root maintenance fixes and source-coverage fixes so the current workspace reaches a healthier state faster'),

            'operator': SF_OT_workspace_command_fix_all.bl_idname,

            'icon': 'TOOL_SETTINGS',

            'button': _t('Smart Fix All'),

            'preset': '',

        })

        seen2 = set()

        filtered = []

        for a in deduped:

            k = (a.get('operator'), a.get('preset'), a.get('button'))

            if k in seen2:

                continue

            seen2.add(k)

            filtered.append(a)

        deduped = filtered

    return deduped[:6]







def _sf_invoke_recommended_action(context, action: dict) -> bool:

    if not context or not action:

        return False

    operator_id = str(action.get('operator', '') or '').strip()

    if not operator_id or '.' not in operator_id:

        return False

    module_name, op_name = operator_id.split('.', 1)

    op_module = getattr(bpy.ops, module_name, None)

    op_callable = getattr(op_module, op_name, None) if op_module else None

    if op_callable is None:

        return False

    kwargs = {}

    preset = str(action.get('preset', '') or '').strip()

    if preset:

        if operator_id == SF_OT_reference_manager_apply_setup_and_open.bl_idname:

            kwargs['preset'] = preset

        elif operator_id == SF_OT_library_roots_add_source_folder_as_root.bl_idname:

            kwargs['mode'] = preset

    for payload in ((('INVOKE_DEFAULT',), kwargs), (tuple(), kwargs), (('INVOKE_DEFAULT',), {}), (tuple(), {})):

        args, kw = payload

        try:

            op_callable(*args, **kw)

            return True

        except TypeError:

            continue

        except Exception:

            continue

    return False





def _sf_build_smart_fix_preview(context, prefs=None) -> dict:

    prefs = prefs or _addon_prefs(context)

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    source_folder = _norm_path(os.path.dirname(filepath)) if filepath else ''

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    source_info = _sf_get_source_insights(prefs, filepath, None)

    lines = []

    added = 0

    reenabled = 0

    disabled_missing = 0

    removed_empty = 0

    removed_dup = 0

    reorder_needed = 0



    if filepath and os.path.isfile(filepath) and source_folder:

        existing_root = None

        for root in roots:

            if _norm_path(getattr(root, 'path', '') or '') == source_folder:

                existing_root = root

                break

        if existing_root is None and not bool(source_info.get('inside_root')):

            lines.append(_t('Would add current source folder as a new library root'))

            added += 1

        elif existing_root is not None and not bool(getattr(existing_root, 'enabled', True)):

            lines.append(_t('Would re-enable the current source folder root'))

            reenabled += 1



    seen = set()

    normalized = []

    for root in roots:

        path = _norm_path(getattr(root, 'path', '') or '')

        enabled = bool(getattr(root, 'enabled', True))

        priority = int(getattr(root, 'priority', 0) or 0)

        if not path:

            removed_empty += 1

            continue

        if path in seen:

            removed_dup += 1

            continue

        seen.add(path)

        if enabled and not os.path.isdir(path):

            disabled_missing += 1

        normalized.append((path, priority))

    if removed_empty:

        lines.append(f"{_t('Would remove empty root entries')}: {removed_empty}")

    if removed_dup:

        lines.append(f"{_t('Would remove duplicate root entries')}: {removed_dup}")

    if disabled_missing:

        lines.append(f"{_t('Would disable missing enabled roots')}: {disabled_missing}")

    sorted_norm = sorted(normalized, key=lambda item: (-int(item[1]), str(item[0]).lower()))

    if normalized and normalized != sorted_norm:

        reorder_needed = 1

        lines.append(_t('Would normalize root order'))



    total_changes = added + reenabled + disabled_missing + removed_empty + removed_dup + reorder_needed

    summary = _t('No preview changes predicted') if total_changes == 0 else f"{_t('Preview Summary')}: {total_changes}"

    return {

        'summary': summary,

        'lines': lines,

        'counts': {

            'add_root': added,

            'reenable_root': reenabled,

            'disable_missing': disabled_missing,

            'remove_empty': removed_empty,

            'remove_duplicate': removed_dup,

            'reorder': reorder_needed,

            'total': total_changes,

        }

    }





def _sf_can_run_smart_fix(context, prefs=None):

    prefs = prefs or _addon_prefs(context)

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    has_source = bool(filepath and os.path.isfile(filepath))

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    has_roots = bool(roots)

    preview = _sf_build_smart_fix_preview(context, prefs)

    total = int(((preview or {}).get('counts') or {}).get('total', 0) or 0)

    if not has_source and not has_roots:

        return False, _t('Select a source or add a library root first so Smart Fix has something meaningful to repair.'), preview

    if total <= 0:

        return False, _t('No actionable Smart Fix changes are available yet.'), preview

    return True, '', preview





def _sf_repair_pack_block_reason(context, prefs, mode: str):

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    has_source = bool(filepath and os.path.isfile(filepath))

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    has_roots = bool(roots)

    mode = str(mode or '').upper()

    if mode != 'ROOTS_ONLY' and not has_source:

        return _t('Select a source first. This repair pack depends on the current source.')

    if mode == 'ROOTS_ONLY' and not has_roots and not has_source:

        return _t('Add a library root or select a source first so this repair pack has something to clean.')

    return ''





def _sf_consistency_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool) -> list[dict]:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    wm = context.window_manager if context else None

    mode = str(getattr(wm, 'sf_mode', '') or '').upper() if wm else ''

    import_mode = str(getattr(wm, 'sf_import_mode', '') or '').upper() if wm else ''

    rows = []



    def add(title, ok, detail):

        rows.append({

            'title': title,

            'ok': bool(ok),

            'detail': detail,

        })



    expected_import = {

        'IMPORT': 'APPEND',

        'MAINTAIN': 'LINK',

        'PUBLISH': 'LINK_OVERRIDE',

        'RECOVER': 'LINK',

    }.get(goal, '')

    if goal == 'EXPLORE':

        ok = mode in {'MATERIALS', 'NODE_GROUPS', 'ACTIONS', 'WORLDS'} or import_mode == 'APPEND'

        detail = _t('Aligned') if ok else _t('Needs adjustment')

    else:

        ok = (import_mode == expected_import) if expected_import else True

        detail = f"{_t('Aligned')} ({expected_import})" if ok and expected_import else (_t('Aligned') if ok else f"{_t('Needs adjustment')} ({expected_import})")

    add(_t('Goal vs Import Mode'), ok, detail)



    coverage_ok = True if goal in {'EXPLORE', 'IMPORT'} else bool(has_source and roots_ready and source_info.get('inside_root'))

    coverage_detail = _t('Aligned') if coverage_ok else (_t('Needs source') if not has_source else _t('Needs roots'))

    add(_t('Goal vs Source Coverage'), coverage_ok, coverage_detail)



    index_ok = True if goal not in {'MAINTAIN', 'RECOVER'} else bool(has_source and roots_ready and index_ready and source_info.get('is_indexed'))

    index_detail = _t('Aligned') if index_ok else (_t('Needs index') if has_source else _t('Needs source'))

    add(_t('Goal vs Index State'), index_ok, index_detail)



    sidecars_ok = True if goal != 'PUBLISH' else bool(has_source and source_info.get('preview_path') and source_info.get('meta_path') and source_info.get('catalog_path'))

    sidecars_detail = _t('Aligned') if sidecars_ok else (_t('Missing sidecars') if has_source else _t('Needs source'))

    add(_t('Goal vs Publish Sidecars'), sidecars_ok, sidecars_detail)



    profiles = _sf_profiles_for_goal(prefs, goal, context=context)

    profile_ok = bool(profiles)

    add(_t('Goal vs Profile Matches'), profile_ok, _t('Aligned') if profile_ok else _t('No matching profile'))

    return rows





def _sf_draw_consistency_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Consistency Review'), icon='CHECKMARK')

    rows = _sf_consistency_rows(context, prefs, filepath, source_info, roots_ready, index_ready)

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows:

        card = grid.box()

        ok = bool(item.get('ok'))

        card.label(text=item.get('title', ''), icon='CHECKMARK' if ok else 'ERROR')

        card.label(text=item.get('detail', ''), icon='ERROR' if not ok else 'BLANK1')

    row = box.row(align=True)

    row.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    row.operator(SF_OT_workspace_command_fix_preview.bl_idname, text=_t('Fix Preview'), icon='TOOL_SETTINGS')

    box.label(text=_t('Review before running'), icon='ERROR')

    return box





def _sf_draw_action_queue_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, compact: bool = False):

    actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

    box = parent.box()

    box.label(text=_t('Action Queue'), icon='FORWARD')

    row = box.row(align=True)

    row.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    row.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

    box.label(text=_t('Review before running'), icon='ERROR')

    if not actions:

        box.label(text=_t('No blocker detected'), icon='CHECKMARK')

        return box

    for action in actions[:(2 if compact else 4)]:

        _sf_draw_recommended_action(box, action)

    return box











def _sf_action_requires_review(operator_id: str) -> bool:

    operator_id = str(operator_id or '').strip()

    return operator_id in {

        SF_OT_workspace_command_run_goal_starter_pack.bl_idname,

        SF_OT_workspace_command_run_top_recommendation.bl_idname,

        SF_OT_workspace_command_fix_all.bl_idname,

    }







def _sf_review_run_button_text() -> str:

    return _t('Review & Run...')







def _sf_quick_action_review_payload(context, action_key: str, goal_value: str = '') -> dict:

    prefs = _addon_prefs(context)

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    has_source = bool(filepath and os.path.isfile(filepath))

    try:

        index = _load_index()

    except Exception:

        index = {}

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    enabled_roots = [root for root in roots if bool(getattr(root, 'enabled', True))]

    roots_ready = bool(enabled_roots)

    indexed_entries = len((index or {}).get('files', {}) or {})

    index_ready = bool(indexed_entries)

    source_info = _sf_get_source_insights(prefs, filepath, index)

    health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

    action_key = str(action_key or '').strip().upper()

    goal = str(goal_value or _sf_current_session_goal(context) or 'IMPORT').upper()

    source_name = os.path.basename(filepath) if filepath else _t('Not set')

    roots_detail = f"{_t('Enabled roots')}: {len(enabled_roots)}" if roots_ready else _t('No enabled roots')

    index_detail = f"{_t('Indexed entries')}: {indexed_entries}" if index_ready else _t('Indexed entries') + ': 0'



    def state_item(label, state, detail='', icon='NONE'):

        return {'label': _t(label), 'state': state, 'detail': detail, 'icon': icon}



    def predicted_follow_up(goal_key: str) -> str:

        goal_key = str(goal_key or '').upper()

        if goal_key == 'EXPLORE':

            return _t('Asset Reader...')

        if goal_key == 'IMPORT':

            return _t('Browse') if has_source else _t('Smart File...')

        if goal_key == 'MAINTAIN':

            return _t('Reference Manager...') if roots_ready else _t('Source Check...')

        if goal_key == 'PUBLISH':

            if has_source and source_info.get('preview_path') and source_info.get('meta_path'):

                return _t('Publish Asset...')

            return _t('Asset Preview Batch...')

        return _t('Source Check...')



    if action_key == 'RUN_TOP_RECOMMENDATION':

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        action = actions[0] if actions else None

        action_title = str((action or {}).get('title', '') or _t('Not set'))

        action_detail = str((action or {}).get('detail', '') or '')

        return {

            'title': _t('Run Top Recommendation'),

            'subtitle': _t('Review the current top recommendation before it runs a tool or change.'),

            'summary': _t('Highest-priority suggestion for the current goal and source state.'),

            'icon': 'PLAY',

            'can_run': bool(action),

            'reason': '' if action else _t('No top recommendation is available right now.'),

            'states': [

                state_item('Current Goal', 'READY', _t(goal.title()), _sf_goal_icon(goal)),

                state_item('Current Source', 'READY' if has_source else 'NEEDS SOURCE', source_name, 'FILE_BLEND'),

                state_item('Library Roots', 'READY' if roots_ready else 'NEEDS ROOTS', roots_detail, 'FILE_FOLDER'),

                state_item('Index State', 'INDEXED' if index_ready else 'NEEDS INDEX', index_detail, 'FILE_REFRESH'),

                state_item('Top Action', 'READY' if action else 'NOT SET', action_title, 'PLAY'),

            ],

            'lines': [

                f"{_t('Suggested action')}: {action_title}",

                action_detail,

                f"{_t('Health Score')}: {health_score}/100 · {health_label}",

            ],

            'follow_up': [

                _t('Open the suggested next tool and confirm that the blocker or goal step has cleared.'),

            ],

        }



    if action_key == 'SMART_FIX_ALL':

        can_run, reason, preview = _sf_can_run_smart_fix(context, prefs)

        lines = list((preview or {}).get('lines', []) or [])[:6]

        summary = str((preview or {}).get('summary', '') or '').strip()

        return {

            'title': _t('Smart Fix All'),

            'subtitle': _t('Review the current Smart Fix plan before it changes roots, coverage, or disabled entries.'),

            'summary': summary or _t('Safe maintenance batch for roots, index coverage, and disabled entries.'),

            'icon': 'TOOL_SETTINGS',

            'can_run': bool(can_run),

            'reason': str(reason or ''),

            'states': [

                state_item('Current Source', 'READY' if has_source else 'NEEDS SOURCE', source_name, 'FILE_BLEND'),

                state_item('Library Roots', 'READY' if roots_ready else 'NEEDS ROOTS', roots_detail, 'FILE_FOLDER'),

                state_item('Index State', 'INDEXED' if index_ready else 'NEEDS INDEX', index_detail, 'FILE_REFRESH'),

                state_item('Change Scope', 'REVIEW' if lines else 'READY', summary or _t('Nothing selected'), 'TOOL_SETTINGS'),

                state_item('Safety Check', 'READY' if can_run else 'NEEDS SETUP', str(reason or _t('This action can still run, but the snapshot above shows what may need follow-up.')), 'CHECKMARK'),

            ],

            'lines': [line for line in ([summary] + lines + [f"{_t('Health Score')}: {health_score}/100 · {health_label}"]) if str(line or '').strip()],

            'follow_up': [

                _t('Recommended follow-up') + ':' + _t('Open Source Check or Smart Fix Report after the run if you want to verify the cleanup result.'),

            ],

        }



    profiles = _sf_profiles_for_goal(prefs, goal, context=context)

    profile_ok = bool(profiles)

    next_tool = predicted_follow_up(goal)

    return {

        'title': _t('Run Goal Starter Pack'),

        'subtitle': _t('Review the current goal starter pack before it applies setup changes and opens follow-up tools.'),

        'summary': _t('Goal-oriented setup pass for the current source and workflow state.'),

        'icon': _sf_goal_icon(goal),

        'can_run': True,

        'reason': '',

        'states': [

            state_item('Current Goal', 'READY', _t(goal.title()), _sf_goal_icon(goal)),

            state_item('Current Source', 'READY' if has_source else 'NEEDS SOURCE', source_name, 'FILE_BLEND'),

            state_item('Profile Match', 'READY' if profile_ok else 'REVIEW', (_t('Matches') + f": {len(profiles)}") if profile_ok else _t('Fallback preset'), 'PRESET'),

            state_item('Library Roots', 'READY' if roots_ready else 'NEEDS ROOTS', roots_detail, 'FILE_FOLDER'),

            state_item('Predicted Follow-up', 'REVIEW', next_tool, 'FORWARD'),

        ],

        'lines': [

            f"{_t('Goal')}: {_t(goal.title())}",

            _t('Common fixes') + ':' + _t('Enabled when the goal needs root, index, or publish-prep recovery.'),

            _t('Next tool') + ':' + next_tool,

        ],

        'follow_up': [

            _t('Open the suggested next tool and confirm that the blocker or goal step has cleared.'),

        ],

    }







def _sf_action_palette_items(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int) -> list[dict]:

    goal = _sf_current_session_goal(context)

    items = []

    def add(title, detail, operator, icon='CHECKMARK', button=None, preset='', goal_value='', keywords=''):

        operator_id = str(operator or '')

        review = _sf_action_requires_review(operator_id)

        items.append({

            'title': title,

            'detail': detail,

            'operator': operator_id,

            'icon': icon,

            'button': _sf_review_run_button_text() if review else (button or title),

            'preset': preset or '',

            'goal': goal_value or '',

            'keywords': keywords or '',

            'review': review,

        })



    for action in _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score):

        operator_id = str((action or {}).get('operator', '') or '')

        items.append(dict(

            action,

            button=_sf_review_run_button_text() if _sf_action_requires_review(operator_id) else (action or {}).get('button', ''),

            review=_sf_action_requires_review(operator_id),

            keywords=f"recommended {goal.lower()} current source",

        ))



    add(_t('Action Palette...'), _t('Search the suite command list and launch the next tool without leaving the current workspace.'), SF_OT_workspace_command_action_palette.bl_idname, 'VIEWZOOM', _t('Action Palette...'), '', '', 'palette quick action search launcher')

    add(_t('Root Coverage Matrix...'), _t('Inspect each library root, its indexed coverage, current-source relationship, and maintenance state in one place.'), SF_OT_library_roots_root_coverage_matrix.bl_idname, 'FILE_FOLDER', _t('Root Coverage Matrix...'), '', '', 'roots coverage matrix diagnostics')

    add(_t('Goal Roadmap'), _t('Review the milestone checklist for the active goal and see which requirement is still blocking progress.'), SF_OT_workspace_command_goal_roadmap.bl_idname, _sf_goal_icon(goal), _t('Goal Roadmap...'), '', goal, 'goal roadmap milestones blocker')

    add(_t('Launcher...'), _t('Open the suite home screen with start-page cards, recent sources, favorites, and guided tools.'), SF_OT_workspace_command_launcher.bl_idname, 'MENU_PANEL', _t('Launcher...'), '', '', 'home dashboard launcher')

    add(_t('Source Check...'), _t('Validate the active source against root, index, preview, metadata, and catalog readiness.'), SF_OT_reference_manager_source_check.bl_idname, 'CHECKMARK', _t('Source Check...'), '', '', 'source check validate health')

    add(_t('Smart File...'), _t('Open the main import browser and inspect datablocks inside the current source .blend file.'), SF_OT_source_browser_open_folder_2.bl_idname, 'ASSET_MANAGER', _t('Smart File...'), '', '', 'browser import append link')

    add(_t('Asset Reader...'), _t('Browse indexed library content, analyze files, and inspect catalog-aware assets.'), SF_OT_asset_reader_open.bl_idname, 'ASSET_MANAGER', _t('Asset Reader...'), '', '', 'asset reader catalog browse library')

    add(_t('Reference Manager...'), _t('Inspect linked libraries, missing paths, relink candidates, and override maintenance tasks.'), SF_OT_reference_manager_open.bl_idname, 'LINKED', _t('Reference Manager...'), '', '', 'reference relink overrides maintain')

    add(_t('Publish Asset...'), _t('Prepare versioned output, preview renders, metadata sidecars, and catalog-aware publish steps.'), SF_OT_publisher_publish_asset.bl_idname, 'EXPORT', _t('Publish Asset...'), '', '', 'publish version metadata preview catalog')

    add(_t('Asset Preview Batch...'), _t('Generate or refresh preview images and metadata sidecars for source files in bulk.'), SF_OT_asset_preview_batch_preview.bl_idname, 'RENDER_STILL', _t('Asset Preview Batch...'), '', '', 'preview batch thumbnails sidecars')

    add(_t('Library Diagnostics...'), _t('Audit library roots and index coverage before maintenance, relinking, or publishing.'), SF_OT_asset_library_diagnostics.bl_idname, 'CHECKMARK', _t('Library Diagnostics...'), '', '', 'diagnostics roots index')

    add(_t('Repair Library Roots...'), _t('Repair, add, remove, or reorder library roots that drive diagnostics and publishing.'), SF_OT_asset_library_repair_roots.bl_idname, 'PREFERENCES', _t('Repair Library Roots...'), '', '', 'repair roots')

    add(_t('Generate Catalog Draft...'), _t('Create a draft catalog.json context for the current library structure.'), SF_OT_asset_library_generate_catalog_draft.bl_idname, 'TEXT', _t('Generate Catalog Draft...'), '', '', 'catalog draft')

    add(_t('Run Goal Starter Pack'), _t('Set the goal, apply the closest profile or preset, run common fixes when needed, and open the next tool.'), SF_OT_workspace_command_run_goal_starter_pack.bl_idname, _sf_goal_icon(goal), _t('Run Goal Starter Pack'), '', goal, 'starter pack goal workflow')

    add(_t('Run Top Recommendation'), _t('Execute the highest-priority action suggested for the current goal and source state.'), SF_OT_workspace_command_run_top_recommendation.bl_idname, 'PLAY', _t('Run Top Recommendation'), '', '', 'recommendation next action')

    add(_t('Smart Fix All'), _t('Run a safe batch of root maintenance fixes and source-coverage fixes so the current workspace reaches a healthier state faster'), SF_OT_workspace_command_fix_all.bl_idname, 'TOOL_SETTINGS', _t('Smart Fix All'), '', '', 'smart fix repair roots')

    add(_t('Smart Fix Preview...'), _t('Preview what Smart Fix would add, disable, remove, or reorder before changing the workspace.'), SF_OT_workspace_command_fix_preview.bl_idname, 'TOOL_SETTINGS', _t('Smart Fix Preview...'), '', '', 'repair preview smart fix')

    add(_t('Workspace Report'), _t('Write a text summary of workspace health, roots, profiles, and recommended actions.'), SF_OT_reference_manager_workspace_report.bl_idname, 'TEXT', _t('Workspace Report'), '', '', 'report export text handoff')

    add(_t('Session Bundle'), _t('Export a larger handoff bundle that combines workspace health, goal roadmaps, profile visibility, activity, and recent repair details in one text block.'), SF_OT_workspace_command_session_bundle.bl_idname, 'FILE_TEXT', _t('Session Bundle'), '', '', 'bundle export text handoff')



    for lane_name in ('LINK', 'APPEND', 'IMPORT', 'EXPORT', 'PREVIEW', 'HISTORY', 'OTHER'):

        for section in _sf_lane_tool_sections(context, lane_name):

            for item in list(section.get('items') or []):

                operator_id = str(item.get('operator', '') or '')

                if not operator_id:

                    continue

                props = dict(item.get('props') or {})

                goal_value = str(props.get('goal', '') or '')

                add(

                    str(item.get('label', '') or operator_id),

                    str(item.get('detail', '') or ''),

                    operator_id,

                    str(item.get('icon', 'CHECKMARK') or 'CHECKMARK'),

                    str(item.get('label', '') or operator_id),

                    '',

                    goal_value,

                    f"{lane_name.lower()} original tools {item.get('keywords', '')}",

                )



    seen = set()

    deduped = []

    for item in items:

        key = (item.get('title'), item.get('operator'), item.get('preset'), item.get('goal'))

        if key in seen:

            continue

        seen.add(key)

        deduped.append(item)

    return deduped







def _sf_draw_action_palette_entry(parent, entry: dict):

    box = parent.box()

    review = bool(entry.get('review'))

    try:

        box.alert = review

    except Exception:

        pass

    box.label(text=entry.get('title', ''), icon=entry.get('icon', 'CHECKMARK'))

    if review:

        box.label(text=_t('Review before running'), icon='ERROR')

    operator_id = str(entry.get('operator', '') or '')

    if not operator_id:

        return box

    op = box.operator(operator_id, text=entry.get('button', entry.get('title', 'Open')), icon=entry.get('icon', 'CHECKMARK'))

    preset = str(entry.get('preset', '') or '')

    goal_value = str(entry.get('goal', '') or '')

    if preset:

        if not _sf_safe_set_operator_property(op, 'preset', preset):

            _sf_safe_set_operator_property(op, 'mode', preset)

    if goal_value:

        _sf_safe_set_operator_property(op, 'goal', goal_value)

    if review:

        _sf_safe_set_operator_property(op, 'skip_review', False)

    return box







def _sf_root_coverage_matrix_rows(prefs, index_data: dict | None = None, filepath: str = '') -> list[dict]:

    filepath = _norm_path(filepath or '')

    rows = _sf_root_coverage_rows(prefs, index_data)

    for row in rows:

        root_path = _norm_path(row.get('path') or '')

        inside = False

        direct = False

        if filepath and root_path:

            prefix = root_path + os.sep

            inside = filepath == root_path or filepath.startswith(prefix)

            direct = _norm_path(os.path.dirname(filepath)) == root_path

        status = _t('Ready') if row.get('enabled') and row.get('exists') and row.get('indexed_count', 0) > 0 else (_t('Needs setup') if row.get('enabled') and row.get('exists') else _t('Needs attention'))

        if row.get('enabled') and row.get('exists') and row.get('indexed_count', 0) == 0:

            status = _t('Needs index')

        if not row.get('enabled'):

            status = _t('Disabled')

        if not row.get('path'):

            status = _t('Not set')

        if row.get('path') and not row.get('exists'):

            status = _t('Missing')

        row['inside_source'] = inside

        row['source_direct'] = direct

        row['status'] = status

    return rows







def _sf_draw_root_coverage_matrix(parent, prefs, filepath: str, index_data: dict | None = None, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Root Coverage'), icon='FILE_FOLDER')

    rows = _sf_root_coverage_matrix_rows(prefs, index_data, filepath)

    if not rows:

        box.label(text=_t('No library roots configured yet'))

        return box

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    limit = 4 if compact else 8

    for row_data in rows[:limit]:

        card = grid.box()

        title_icon = 'FILE_FOLDER' if row_data.get('path') else 'ERROR'

        card.label(text=row_data.get('name') or _t('Not set'), icon=title_icon, translate=False)

        _sf_draw_state_line(card, 'Status', row_data.get('status', ''), fallback_icon='NONE')

        count_state = 'Ready' if int(row_data.get('indexed_count', 0) or 0) > 0 else ('Needs index' if row_data.get('enabled') and row_data.get('exists') else row_data.get('status', ''))

        _sf_draw_state_line(card, 'Indexed Count', count_state, fallback_icon='FILE', detail=str(row_data.get('indexed_count', 0)))

        _sf_draw_state_line(card, 'Current Source', 'Ready' if row_data.get('inside_source') else 'Not ready', fallback_icon='FILE_BLEND', detail=_t('Inside root') if row_data.get('inside_source') else _t('Outside root'))

        if row_data.get('source_direct'):

            card.label(text=_t('Source folder matches this root directly'), icon='CHECKMARK')

        if row_data.get('path'):

            card.label(text=row_data.get('path'), icon='FILE_FOLDER', translate=False)

    row = box.row(align=True)

    row.operator(SF_OT_library_roots_enable_all_roots.bl_idname, text=_t('Enable All Roots'), icon='CHECKMARK')

    row.operator(SF_OT_library_roots_disable_missing_roots.bl_idname, text=_t('Disable Missing Roots'), icon='CANCEL')

    row.operator(SF_OT_library_roots_sort_roots.bl_idname, text=_t('Sort Roots'), icon='SORTALPHA')

    return box







def _sf_goal_roadmap_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], goal_override: str | None = None) -> list[dict]:

    goal = str(goal_override or _sf_current_session_goal(context) or 'IMPORT').upper()

    has_source = bool(filepath and os.path.isfile(filepath))

    best_pair = _sf_best_profile_for_goal(prefs, goal, context=context)

    rows = []

    rows.append({'title': _t('Source selected'), 'done': has_source, 'detail': os.path.basename(filepath) if has_source else _t('Choose a source .blend file')})

    if goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'}:

        inside_root = bool(source_info.get('inside_root'))

        rows.append({'title': _t('Inside managed root'), 'done': inside_root, 'detail': source_info.get('root_name') or (_t('Needs roots') if roots_ready else _t('Library roots are not configured'))})

        indexed = bool(index_ready and source_info.get('is_indexed'))

        rows.append({'title': _t('Indexed and trackable'), 'done': indexed, 'detail': _t('Aligned') if indexed else _t('Needs index')})

    if goal == 'PUBLISH':

        sidecars = bool(source_info.get('preview_path')) and bool(source_info.get('meta_path')) and bool(source_info.get('catalog_path'))

        rows.append({'title': _t('Publish sidecars ready'), 'done': sidecars, 'detail': _t('Aligned') if sidecars else _t('Missing sidecars')})

    rows.append({'title': _t('Matching profile ready'), 'done': bool(best_pair), 'detail': (getattr(best_pair[1], 'name', '') if best_pair else _t('No matching profile'))})

    recommended_ready = bool(actions)

    rows.append({'title': _t('Recommended action ready'), 'done': recommended_ready, 'detail': actions[0].get('title', _t('No blocker detected')) if recommended_ready else _t('No blocker detected')})

    return rows







def _sf_draw_goal_roadmap_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False, goal_override: str | None = None):

    goal = str(goal_override or _sf_current_session_goal(context) or 'IMPORT').upper()

    rows = _sf_goal_roadmap_rows(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal)

    done_count = sum(1 for row in rows if bool(row.get('done')))

    box = parent.box()

    box.label(text=_t('Goal Roadmap'), icon=_sf_goal_icon(goal))

    box.label(text=f"{_t('Roadmap Progress')}: {done_count}/{len(rows)}", icon='CHECKMARK' if done_count == len(rows) else 'ERROR')

    limit = 4 if compact else 6

    for row_data in rows[:limit]:

        row = box.row(align=True)

        row.label(text=row_data.get('title', ''), icon='CHECKMARK' if row_data.get('done') else 'ERROR')

        row.label(text=row_data.get('detail', ''), icon='ERROR' if not row_data.get('done') else 'BLANK1')

    action_row = box.row(align=True)

    op = _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_goal_roadmap, text=_t('Goal Roadmap...'), icon='MENU_PANEL')

    _sf_safe_set_operator_property(op, 'goal', goal)

    op = _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_run_goal_starter_pack, text=_sf_review_run_button_text(), icon='PLAY')

    _sf_safe_set_operator_property(op, 'goal', goal)

    box.label(text=_t('Review before running'), icon='ERROR')

    return box





def _sf_draw_recommended_action(parent, action: dict):

    box = parent.box()

    box.label(text=action.get('title', ''), icon=action.get('icon', 'CHECKMARK'))

    operator_id = str(action.get('operator', '') or '').strip()

    review_required = _sf_action_requires_review(operator_id)

    button_text = action.get('button', action.get('title', 'Open'))

    if review_required:

        button_text = _sf_review_run_button_text()

    op = box.operator(action.get('operator', SF_OT_workspace_command_launcher.bl_idname), text=button_text, icon=action.get('icon', 'CHECKMARK'))

    preset = action.get('preset', '')

    if preset:

        if not _sf_safe_set_operator_property(op, 'preset', preset):

            _sf_safe_set_operator_property(op, 'mode', preset)

    goal_value = action.get('goal', '')

    if goal_value:

        _sf_safe_set_operator_property(op, 'goal', goal_value)

    if review_required:

        box.label(text=_t('Review before running'), icon='ERROR')

    return box





def _sf_goal_focus_data(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], goal_override: str | None = None) -> dict:

    goal = str(goal_override or _sf_current_session_goal(context) or "IMPORT").upper()

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    summaries = {

        'EXPLORE': _t('Browse assets, categories, and source choices before importing or publishing.'),

        'IMPORT': _t('Prepare a safe local or linked import flow and open the browser quickly.'),

        'MAINTAIN': _t('Keep roots, indexes, and references healthy across the library.'),

        'PUBLISH': _t('Prepare sidecars, versions, and final publish checks.'),

        'RECOVER': _t('Fix broken roots, missing index data, and coverage gaps first.'),

    }

    blocker = ''

    if not has_source:

        blocker = _t('Select a source file first')

    elif goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and not roots_ready:

        blocker = _t('Library roots are not configured')

    elif goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and not bool(source_info.get('inside_root')):

        blocker = _t('Current source is outside enabled roots')

    elif goal in {'MAINTAIN', 'RECOVER'} and (not index_ready or not bool(source_info.get('is_indexed'))):

        blocker = _t('Index data is not ready')

    elif goal == 'PUBLISH' and (not bool(source_info.get('preview_path')) or not bool(source_info.get('meta_path')) or not bool(source_info.get('catalog_path'))):

        blocker = _t('Preview, metadata, or catalog sidecars are still missing')

    ordered = _sf_profiles_for_goal(prefs, goal, context=context)

    profile = ordered[0] if ordered else None

    if blocker:

        status = _t('Attention needed')

    elif health_score >= 85:

        status = _t('Ready to continue')

    else:

        status = _t('Usable with minor follow-up')

    return {

        'goal': goal,

        'summary': summaries.get(goal, ''),

        'status': status,

        'blocker': blocker,

        'profile': profile,

        'actions': list(actions or [])[:2],

    }





def _sf_draw_goal_focus_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False, goal_override: str | None = None):

    data = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal_override)

    box = parent.box()

    box.label(text=_t('Goal Focus'), icon='BOOKMARKS')

    status_row = box.row(align=True)

    status_row.label(text=f"{_t('Focus Status')}: {data.get('status', '')}", icon='CHECKMARK' if not data.get('blocker') else 'ERROR')

    blocker_box = box.box()

    blocker_box.label(text=_t('Main blocker'), icon='ERROR' if data.get('blocker') else 'CHECKMARK')

    blocker_box.label(text=data.get('blocker') or _t('No blocker detected'), icon='ERROR' if data.get('blocker') else 'CHECKMARK')

    profile_pair = data.get('profile')

    if profile_pair:

        idx, profile = profile_pair

        prof = box.box()

        prof.label(text=_t('Suggested profile'), icon='PRESET')

        prof.label(text=getattr(profile, 'name', '') or _ui_text(f'Profile {idx+1}', f'プロファイル {idx + 1}'), icon='PRESET', translate=False)

        prof.label(text=_sf_profile_summary(profile), icon='BLANK1')

        note = _sf_profile_note_text(profile)

        if note:

            prof.label(text=note)

        prow = prof.row(align=True)

        op = prow.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=_t('Apply Profile'), icon='CHECKMARK')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = prow.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text=_t('Apply & Open'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = prow.operator(SF_OT_workspace_profile_edit_profile.bl_idname, text=_t('Edit Profile'), icon='GREASEPENCIL')

        _sf_safe_set_operator_property(op, 'index', idx)

    action_box = box.box()

    action_box.label(text=_t('Primary actions'), icon='FORWARD')

    if data.get('actions'):

        for action in data.get('actions', [])[:(1 if compact else 2)]:

            _sf_draw_recommended_action(action_box, action)

    else:

        action_box.label(text=_t('No blocker detected'), icon='CHECKMARK')

    return box







def _sf_goal_score_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool) -> list[dict]:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    rows = []

    for goal in ('EXPLORE', 'IMPORT', 'MAINTAIN', 'PUBLISH', 'RECOVER'):

        goal_profiles = _sf_profiles_for_goal(prefs, goal, context=context)

        gdata = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, 100, [], goal_override=goal)

        score = 0

        if has_source:

            score += 30

        if goal in {'EXPLORE', 'IMPORT'} or roots_ready:

            score += 15

        if goal in {'EXPLORE', 'IMPORT'} or bool(source_info.get('inside_root')):

            score += 15

        if goal not in {'MAINTAIN', 'RECOVER'} or (index_ready and bool(source_info.get('is_indexed'))):

            score += 15

        if goal != 'PUBLISH' or (bool(source_info.get('preview_path')) and bool(source_info.get('meta_path')) and bool(source_info.get('catalog_path'))):

            score += 15

        if goal_profiles:

            score += 10

        if not gdata.get('blocker'):

            score += 10

        score = max(0, min(100, score))

        rows.append({

            'goal': goal,

            'score': score,

            'blocker': str(gdata.get('blocker') or ''),

            'status': str(gdata.get('status') or ''),

            'profiles': len(goal_profiles),

            'top_profile': goal_profiles[0] if goal_profiles else None,

        })

    return rows





def _sf_draw_goal_scoreboard(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Goal Scoreboard'), icon='MENU_PANEL')

    rows = _sf_goal_score_rows(context, prefs, filepath, source_info, roots_ready, index_ready)

    grid = box.grid_flow(columns=1 if compact else 5, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows:

        goal = item.get('goal', 'IMPORT')

        card = grid.box()

        score = int(item.get('score', 0) or 0)

        blocker = str(item.get('blocker', '') or '')

        card.label(text=_t(str(goal).title()), icon=_sf_goal_icon(goal))

        card.label(text=f"{_t('Score')}: {score}/100", icon='CHECKMARK' if score >= 80 else ('NONE' if score >= 55 else 'ERROR'))

        card.label(text=f"{_t('Profiles')}: {int(item.get('profiles', 0) or 0)}", icon='PRESET')

        card.label(text=f"{_t('Blockers')}: {0 if not blocker else 1}", icon='ERROR' if blocker else 'CHECKMARK')

        card.label(text=(blocker or item.get('status', ''))[:120], icon='ERROR' if blocker else 'BLANK1')

        top = item.get('top_profile')

        if top:

            idx, profile = top

            card.label(text=_ui_text(f"{_t('Top Profile')}: {getattr(profile, 'name', '') or f'Profile {idx+1}'}", f'プロファイル {idx + 1}'), icon='BOOKMARKS')

        row = card.row(align=True)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_set_goal, text=_t('Set goal'), icon='BOOKMARKS')

        _sf_safe_set_operator_property(op, 'goal', goal)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_open_goal, text=_t('Apply & Open'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'goal', goal)

        sub = card.row(align=True)

        op = _sf_draw_operator_if_registered(sub, SF_OT_workspace_command_goal_roadmap, text=_t('Goal Roadmap...'), icon='MENU_PANEL')

        _sf_safe_set_operator_property(op, 'goal', goal)

        op = _sf_draw_operator_if_registered(sub, SF_OT_workspace_command_save_goal_snapshot, text=_t('Save Snapshot'), icon='ADD')

        _sf_safe_set_operator_property(op, 'goal', goal)

    return box





def _sf_profile_match_rows(prefs, context, filepath: str, source_info: dict) -> list[dict]:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    rows = []

    if not prefs:

        return rows

    profiles = list(getattr(prefs, 'workspace_profiles', []) or [])

    for idx, profile in enumerate(profiles):

        if not _sf_profile_matches_filter(profile, prefs, context=context):

            continue

        score = 0

        reasons = []

        import_mode = str(getattr(profile, 'import_mode', '') or '').upper()

        mode = str(getattr(profile, 'mode', '') or '').upper()

        if _sf_profile_matches_goal(profile, goal):

            score += 45

            reasons.append(_t('Goal aligned'))

        else:

            reasons.append(_t('Goal mismatch'))

        if has_source:

            if bool(source_info.get('inside_root')) and import_mode in {'LINK', 'LINK_OVERRIDE'}:

                score += 16

                reasons.append(_t('Inside enabled root'))

            elif not bool(source_info.get('inside_root')) and import_mode == 'APPEND':

                score += 10

                reasons.append(_t('Good for external source'))

            if bool(source_info.get('is_indexed')) and import_mode in {'LINK', 'LINK_OVERRIDE'}:

                score += 10

                reasons.append(_t('Indexed source ready'))

            if import_mode == 'LINK_OVERRIDE' and bool(source_info.get('preview_path')) and bool(source_info.get('meta_path')) and bool(source_info.get('catalog_path')):

                score += 14

                reasons.append(_t('Publish sidecars ready'))

            if mode == 'OBJECTS' and import_mode == 'APPEND':

                score += 8

                reasons.append(_t('Fast local import'))

            elif mode == 'COLLECTIONS' and import_mode in {'LINK', 'LINK_OVERRIDE'}:

                score += 8

                reasons.append(_t('Library friendly collection workflow'))

        if bool(getattr(profile, 'pinned', False)):

            score += 4

        if str(getattr(profile, 'notes', '') or '').strip():

            score += 3

        score = max(0, min(100, score))

        rows.append({

            'index': idx,

            'profile': profile,

            'score': score,

            'reasons': reasons[:3],

            'goal_match': _sf_profile_matches_goal(profile, goal),

        })

    rows.sort(key=lambda item: (-int(item.get('score', 0) or 0), 0 if bool(getattr(item.get('profile'), 'pinned', False)) else 1, str(getattr(item.get('profile'), 'name', '') or '').lower()))

    return rows





def _sf_draw_profile_match_board(parent, prefs, context, filepath: str, source_info: dict, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Profile Match Board'), icon='PRESET')

    rows = _sf_profile_match_rows(prefs, context, filepath, source_info)

    if not rows:

        box.label(text=_t('No matching profile'))

        return box

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows[:(3 if compact else 4)]:

        idx = int(item.get('index', -1) or -1)

        profile = item.get('profile')

        if profile is None:

            continue

        card = grid.box()

        score = int(item.get('score', 0) or 0)

        head = card.row(align=True)

        head.label(text=getattr(profile, 'name', '') or _ui_text(f'Profile {idx+1}', f'プロファイル {idx + 1}'), icon='PRESET', translate=False)

        op = head.operator(SF_OT_workspace_profile_pin.bl_idname, text='', icon='FUND' if bool(getattr(profile, 'pinned', False)) else 'SOLO_OFF', emboss=True)

        _sf_safe_set_operator_property(op, 'index', idx)

        card.label(text=f"{_t('Score')}: {score}/100", icon='CHECKMARK' if score >= 75 else ('NONE' if score >= 50 else 'ERROR'))

        card.label(text=_sf_profile_summary(profile), icon='BLANK1')

        for reason in item.get('reasons', [])[:(2 if compact else 3)]:

            card.label(text=reason)

        row = card.row(align=True)

        op = row.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=_t('Apply Profile'), icon='CHECKMARK')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = row.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text=_t('Apply & Open'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'index', idx)

        op = row.operator(SF_OT_workspace_profile_edit_profile.bl_idname, text=_t('Edit Profile'), icon='GREASEPENCIL')

        _sf_safe_set_operator_property(op, 'index', idx)

    return box









def _sf_best_profile_for_goal(prefs, goal: str, context=None):

    try:

        ordered = _sf_profiles_for_goal(prefs, goal, context=context)

        return ordered[0] if ordered else None

    except Exception:

        return None





def _sf_goal_playbook_data(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], goal_override: str | None = None) -> dict:

    goal = str(goal_override or _sf_current_session_goal(context) or 'IMPORT').upper()

    has_source = bool(filepath and os.path.isfile(filepath))

    best_pair = _sf_best_profile_for_goal(prefs, goal, context=context)

    best_profile = best_pair[1] if best_pair else None

    playbooks = {

        'EXPLORE': {

            'icon': 'VIEWZOOM',

            'summary': _t('Choose source and browse contents'),

            'ideal': [_t('Source selected'), _t('Matching profile ready')],

            'steps': [

                _t('Choose a source .blend file'),

                _t('Open the Asset Reader or browser to inspect datablocks'),

                _t('Save a reusable explore-oriented profile if this source will be revisited'),

            ],

        },

        'IMPORT': {

            'icon': 'IMPORT',

            'summary': _t('Apply a local-edit friendly setup and open the browser'),

            'ideal': [_t('Source selected'), _t('Matching profile ready')],

            'steps': [

                _t('Choose a source .blend file'),

                _t('Apply an import-oriented profile or preset'),

                _t('Open the main browser and select datablocks to append or link'),

            ],

        },

        'MAINTAIN': {

            'icon': 'TOOL_SETTINGS',

            'summary': _t('Bring the source under root and index coverage, then open maintenance tools'),

            'ideal': [_t('Source selected'), _t('Inside managed root'), _t('Indexed and trackable'), _t('Matching profile ready')],

            'steps': [

                _t('Make sure the current source is inside an enabled library root'),

                _t('Rebuild the library index if the source is still not tracked'),

                _t('Open maintenance and relink tools for a focused review'),

            ],

        },

        'PUBLISH': {

            'icon': 'EXPORT',

            'summary': _t('Make sure publish sidecars and catalog context are ready before opening publish tools'),

            'ideal': [_t('Source selected'), _t('Inside managed root'), _t('Indexed and trackable'), _t('Preview, metadata, and catalog context ready'), _t('Matching profile ready')],

            'steps': [

                _t('Keep the source inside a managed root so catalogs and publishing stay predictable'),

                _t('Generate preview and metadata sidecars if they are missing'),

                _t('Open preview or publish tools only after catalog context is visible'),

            ],

        },

        'RECOVER': {

            'icon': 'CHECKMARK',

            'summary': _t('Repair common blockers first, then reopen focused diagnostics'),

            'ideal': [_t('Source selected'), _t('Inside managed root'), _t('Indexed and trackable')],

            'steps': [

                _t('Preview the repair scope before changing many roots'),

                _t('Run Smart Fix or a repair pack to clear the most common blockers'),

                _t('Reopen Source Check to verify the remaining issues'),

            ],

        },

    }

    data = dict(playbooks.get(goal, playbooks['IMPORT']))

    dynamic_steps = []

    if not has_source:

        dynamic_steps.append(_t('Choose a source .blend file'))

    if goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and has_source and not bool(source_info.get('inside_root')):

        dynamic_steps.append(_t('Make sure the current source is inside an enabled library root'))

    if goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and (not index_ready or (has_source and not bool(source_info.get('is_indexed')))):

        dynamic_steps.append(_t('Rebuild the library index if the source is still not tracked'))

    if goal == 'PUBLISH' and has_source and (not source_info.get('preview_path') or not source_info.get('meta_path') or not source_info.get('catalog_path')):

        dynamic_steps.append(_t('Generate preview and metadata sidecars if they are missing'))

    if best_profile:

        data['profile_label'] = getattr(best_profile, 'name', '') or _t('Matching profile ready')

    else:

        data['profile_label'] = _t('No matching profile')

    data['steps'] = (dynamic_steps + list(data.get('steps', [])))[:4]

    data['ideal'] = list(dict.fromkeys(data.get('ideal', [])))[:5]

    data['goal'] = goal

    data['best_pair'] = best_pair

    data['actions'] = actions[:2] if actions else []

    blocker = _sf_goal_focus_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal).get('blocker')

    data['blocker'] = blocker

    data['ready_now'] = not bool(blocker)

    return data





def _sf_draw_goal_playbook_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False, goal_override: str | None = None):

    pdata = _sf_goal_playbook_data(context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, goal_override=goal_override)

    box = parent.box()

    box.label(text=_t('Goal Playbook'), icon=pdata.get('icon', 'BOOKMARKS'))

    title = box.row(align=True)

    title.label(text=f"{_t(str(pdata.get('goal','IMPORT')).title())} · {_t('Starter Summary')}", icon=pdata.get('icon', 'BOOKMARKS'))

    ready_icon = _sf_state_meta('Ready now' if pdata.get('ready_now') else 'Needs more setup')[1]

    title.label(text=_t('Ready now') if pdata.get('ready_now') else _t('Needs more setup'), icon=ready_icon)

    box.label(text=pdata.get('summary', ''))

    if pdata.get('blocker'):

        box.label(text=f"{_t('Main blocker')}: {pdata.get('blocker')}", icon='ERROR')

    if pdata.get('profile_label'):

        box.label(text=f"{_t('Suggested profile')}: {pdata.get('profile_label')}", icon='PRESET')

    action_row = box.row(align=True)

    op = _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_run_goal_starter_pack, text=_sf_review_run_button_text(), icon='PLAY')

    _sf_safe_set_operator_property(op, 'goal', pdata.get('goal', 'IMPORT'))

    op = _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_goal_roadmap, text=_t('Goal Roadmap...'), icon='MENU_PANEL')

    _sf_safe_set_operator_property(op, 'goal', pdata.get('goal', 'IMPORT'))

    op = _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_save_goal_snapshot, text=_t('Save Snapshot'), icon='ADD')

    _sf_safe_set_operator_property(op, 'goal', pdata.get('goal', 'IMPORT'))

    box.label(text=_t('Review before running'), icon='ERROR')

    split = box.split(factor=0.5)

    ideal = split.box()

    ideal.label(text=_t('Ideal State'), icon='CHECKMARK')

    for line in pdata.get('ideal', [])[:(3 if compact else 5)]:

        ideal.label(text=line, icon='BLANK1')

    steps = split.box()

    steps.label(text=_t('First Steps'), icon='FORWARD')

    for line in pdata.get('steps', [])[:(3 if compact else 4)]:

        steps.label(text=line, icon='BLANK1')

    if pdata.get('actions'):

        act = box.box()

        act.label(text=_t('Starter Pack'), icon='PLAY')

        for action in pdata.get('actions', [])[:(1 if compact else 2)]:

            _sf_draw_recommended_action(act, action)

    return box





def _sf_source_matrix_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool) -> list[dict]:

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    matching = _sf_profiles_for_goal(prefs, goal, context=context) if prefs else []

    preview = bool(source_info.get('preview_path'))

    meta = bool(source_info.get('meta_path'))

    catalog = bool(source_info.get('catalog_path'))

    publish_parts = int(preview) + int(meta) + int(catalog)

    coverage_score = 100 if (roots_ready and source_info.get('inside_root')) else (55 if roots_ready else (25 if has_source else 0))

    index_score = 100 if (index_ready and source_info.get('is_indexed')) else (45 if index_ready else 0)

    publish_score = int((publish_parts / 3.0) * 100) if has_source else 0

    consistency_score = 100

    if goal == 'IMPORT' and not has_source:

        consistency_score = 0

    elif goal in {'MAINTAIN', 'RECOVER'} and (not source_info.get('inside_root') or not source_info.get('is_indexed')):

        consistency_score = 35 if has_source else 0

    elif goal == 'PUBLISH' and (publish_parts < 3 or not source_info.get('inside_root') or not source_info.get('is_indexed')):

        consistency_score = 30 if has_source else 0

    rows = [

        {'title': _t('Source'), 'score': 100 if has_source else 0, 'detail': os.path.basename(filepath) if has_source else _t('Needs source'), 'icon': 'FILE_BLEND'},

        {'title': _t('Coverage'), 'score': coverage_score, 'detail': (source_info.get('root_name') or _t('Inside managed root')) if source_info.get('inside_root') else (_t('Needs roots') if roots_ready else _t('Needs more setup')), 'icon': 'FILE_FOLDER'},

        {'title': _t('Index'), 'score': index_score, 'detail': _t('Indexed and trackable') if source_info.get('is_indexed') else (_t('Needs index') if index_ready or has_source else _t('Needs source')), 'icon': 'FILE_REFRESH'},

        {'title': _t('Publish Data'), 'score': publish_score, 'detail': f"{publish_parts}/3", 'icon': 'EXPORT'},

        {'title': _t('Profile Fit'), 'score': min(100, len(matching) * 25), 'detail': f"{len(matching)} {_t('Profiles')}", 'icon': 'PRESET'},

        {'title': _t('Consistency'), 'score': consistency_score, 'detail': _t('Ready now') if consistency_score >= 80 else _t('Needs more setup'), 'icon': 'CHECKMARK'},

    ]

    return rows





def _sf_draw_source_matrix_panel(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Source Readiness'), icon='SEQ_STRIP_META')

    grid = box.grid_flow(columns=2 if compact else 3, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in _sf_source_matrix_rows(context, prefs, filepath, source_info, roots_ready, index_ready):

        card = grid.box()

        score = int(item.get('score', 0) or 0)

        card.label(text=item.get('title', ''), icon=item.get('icon', 'NONE'))

        state_name = 'Ready' if score >= 75 else ('Needs setup' if score >= 40 else 'Needs attention')

        _sf_draw_state_line(card, 'Score', state_name, fallback_icon='NONE', detail=f"{score}/100")

        card.label(text=item.get('detail', ''), icon='BLANK1')

    return box









def _sf_workspace_pipeline_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict]) -> list[dict]:

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = _sf_current_session_goal(context)

    profile_pair = _sf_best_profile_for_goal(prefs, goal, context=context)

    top_action = actions[0] if actions else None

    sidecars_ready = bool(source_info.get('preview_path')) and bool(source_info.get('meta_path')) and bool(source_info.get('catalog_path'))

    rows = [

        {

            'title': _t('Source'),

            'done': has_source,

            'detail': os.path.basename(filepath) if has_source else _t('Choose a source .blend file'),

            'icon': 'FILE_BLEND',

        },

        {

            'title': _t('Coverage'),

            'done': bool(roots_ready and source_info.get('inside_root')) if has_source else False,

            'detail': (source_info.get('root_name') or _t('Inside managed root')) if source_info.get('inside_root') else (_t('Needs roots') if roots_ready else _t('Library roots are not configured')),

            'icon': 'FILE_FOLDER',

        },

        {

            'title': _t('Index'),

            'done': bool(index_ready and source_info.get('is_indexed')) if has_source else False,

            'detail': _t('Indexed and trackable') if source_info.get('is_indexed') else (_t('Needs index') if has_source else _t('Needs source')),

            'icon': 'FILE_REFRESH',

        },

        {

            'title': _t('Publish Data'),

            'done': sidecars_ready if has_source else False,

            'detail': _t('Preview, metadata, and catalog context ready') if sidecars_ready else (_t('Missing sidecars') if has_source else _t('Needs source')),

            'icon': 'EXPORT',

        },

        {

            'title': _t('Matching profile'),

            'done': bool(profile_pair),

            'detail': (getattr(profile_pair[1], 'name', '') or _t('Matching profile ready')) if profile_pair else _t('No matching profile'),

            'icon': 'PRESET',

        },

        {

            'title': _t('Top Recommendation'),

            'done': bool(top_action),

            'detail': top_action.get('title', _t('No blocker detected')) if top_action else _t('No blocker detected'),

            'icon': top_action.get('icon', 'FORWARD') if top_action else 'CHECKMARK',

        },

    ]

    return rows





def _sf_draw_workspace_pipeline(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict], compact: bool = False):

    box = parent.box()

    box.label(text=_t('Workflow Path'), icon='SORTTIME')

    rows = _sf_workspace_pipeline_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

    for item in rows[:(4 if compact else 6)]:

        row = box.row(align=True)

        row.label(text=item.get('title', ''), icon=item.get('icon', 'NONE'))

        row.label(text=item.get('detail', ''), icon='CHECKMARK' if item.get('done') else 'ERROR')

    acts = box.row(align=True)

    acts.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    acts.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

    box.label(text=_t('Review before running'), icon='ERROR')

    return box





def _sf_profile_tag_matrix_rows(prefs, context=None) -> list[dict]:

    profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

    rows = []

    for goal in ('EXPLORE', 'IMPORT', 'MAINTAIN', 'PUBLISH', 'RECOVER'):

        visible = []

        for idx, profile in enumerate(profiles):

            if not _sf_profile_matches_filter(profile, prefs, context=context):

                continue

            if _sf_profile_matches_goal(profile, goal):

                visible.append(profile)

        pinned = sum(1 for profile in visible if bool(getattr(profile, 'pinned', False)))

        rows.append({

            'goal': goal,

            'label': _t(goal.title()),

            'count': len(visible),

            'pinned': pinned,

            'top': getattr(visible[0], 'name', '') if visible else _t('No matching profile'),

        })

    return rows





def _sf_draw_profile_tag_matrix(parent, prefs, context=None, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Profile Tag Matrix'), icon='PRESET')

    rows = _sf_profile_tag_matrix_rows(prefs, context=context)

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    for item in rows[:(3 if compact else 5)]:

        card = grid.box()

        card.label(text=item.get('label', ''), icon=_sf_goal_icon(item.get('goal', 'IMPORT')))

        card.label(text=f"{_t('Visible Profiles')}: {item.get('count', 0)}")

        card.label(text=f"{_t('Pinned Profiles')}: {item.get('pinned', 0)}", icon='FUND')

        card.label(text=item.get('top', ''), icon='BLANK1', translate=False)

    return box





def _sf_blocker_stack_rows(context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict]) -> list[dict]:

    rows = []

    filepath = _norm_path(filepath or '')

    has_source = bool(filepath and os.path.isfile(filepath))

    goal = str(_sf_current_session_goal(context) or 'IMPORT').upper()

    if not has_source:

        rows.append({'title': _t('Select a source file first'), 'detail': _t('Choose a source .blend file'), 'severity': 100, 'icon': 'ERROR'})

    if goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and not roots_ready:

        rows.append({'title': _t('Library roots are not configured'), 'detail': _t('Add at least one enabled root before maintenance or publish work'), 'severity': 95, 'icon': 'FILE_FOLDER'})

    if has_source and roots_ready and goal in {'MAINTAIN', 'PUBLISH', 'RECOVER'} and not bool(source_info.get('inside_root')):

        rows.append({'title': _t('Current source is outside enabled roots'), 'detail': _t('Add the source folder as a root or switch to a managed source'), 'severity': 88, 'icon': 'ERROR'})

    if has_source and goal in {'MAINTAIN', 'RECOVER', 'PUBLISH'} and (not index_ready or not bool(source_info.get('is_indexed'))):

        rows.append({'title': _t('Index data is not ready'), 'detail': _t('Rebuild the library index so coverage and review tools can track this source'), 'severity': 82, 'icon': 'FILE_REFRESH'})

    if has_source and goal == 'PUBLISH' and (not bool(source_info.get('preview_path')) or not bool(source_info.get('meta_path')) or not bool(source_info.get('catalog_path'))):

        rows.append({'title': _t('Publish sidecars are incomplete'), 'detail': _t('Preview, metadata, or nearby catalog context is still missing'), 'severity': 78, 'icon': 'EXPORT'})

    best = _sf_best_profile_for_goal(prefs, goal, context=context)

    if not best:

        rows.append({'title': _t('No matching profile'), 'detail': _t('Seed or capture a workspace profile that matches the current goal'), 'severity': 60, 'icon': 'PRESET'})

    if actions:

        top = actions[0]

        rows.append({'title': top.get('title', _t('Top Recommendation')), 'detail': top.get('detail', ''), 'severity': 50, 'icon': top.get('icon', 'FORWARD')})

    if not rows:

        rows.append({'title': _t('No strong blockers detected'), 'detail': _t('The current source, roots, index, and profile pool look usable'), 'severity': 0, 'icon': 'CHECKMARK'})

    rows.sort(key=lambda item: int(item.get('severity', 0) or 0), reverse=True)

    return rows





def _sf_draw_blocker_stack(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, actions: list[dict], compact: bool = False):

    rows = _sf_blocker_stack_rows(context, prefs, filepath, source_info, roots_ready, index_ready, actions)

    box = parent.box()

    box.label(text=_t('Current Blockers'), icon='ERROR')

    for item in rows[:(4 if compact else 6)]:

        row = box.row(align=True)

        row.label(text=item.get('title', ''), icon=item.get('icon', 'ERROR'))

        row.label(text=item.get('detail', ''), icon='BLANK1')

    acts = box.row(align=True)

    acts.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    acts.operator(SF_OT_workspace_command_fix_preview.bl_idname, text=_t('Fix Preview'), icon='TOOL_SETTINGS')

    box.label(text=_t('Review before running'), icon='ERROR')

    return box





def _sf_profile_signal_board_data(prefs, context) -> dict:

    profiles = list(getattr(prefs, 'workspace_profiles', []) or []) if prefs else []

    visible_pairs = _sf_profiles_for_goal(prefs, _sf_current_session_goal(context), context=context) if prefs else []

    visible = [pair[1] for pair in visible_pairs]

    wm = getattr(context, 'window_manager', None)

    current_mode = str(getattr(wm, 'sf_mode', 'OBJECTS') or 'OBJECTS').upper()

    exact_mode = 0

    tags = {}

    for profile in visible:

        if str(getattr(profile, 'mode', '') or '').upper() == current_mode:

            exact_mode += 1

        tag = str(getattr(profile, 'tag', '') or '').strip()

        if tag:

            tags[tag] = tags.get(tag, 0) + 1

    top_tags = ','.join([name for name, _count in sorted(tags.items(), key=lambda kv: (-kv[1], kv[0].lower()))[:3]]) if tags else _t('Not set')

    return {

        'total': len(profiles),

        'visible': len(visible),

        'pinned': sum(1 for profile in visible if bool(getattr(profile, 'pinned', False))),

        'goal_matches': len(visible),

        'exact_mode': exact_mode,

        'top_tags': top_tags,

        'top_profile': getattr(visible[0], 'name', '') if visible else _t('No matching profile'),

    }





def _sf_draw_profile_signal_board(parent, prefs, context, compact: bool = False):

    data = _sf_profile_signal_board_data(prefs, context)

    box = parent.box()

    box.label(text=_t('Profile Signal Board'), icon='PRESET')

    grid = box.grid_flow(columns=2 if compact else 3, row_major=True, even_columns=True, even_rows=False, align=True)

    cards = [

        (_t('Visible Profiles'), data.get('visible', 0), 'NONE'),

        (_t('Pinned Profiles'), data.get('pinned', 0), 'FUND'),

        (_t('Goal Matches'), data.get('goal_matches', 0), 'BOOKMARKS'),

        (_t('Exact Mode Matches'), data.get('exact_mode', 0), 'CHECKMARK'),

    ]

    for label, value, icon in cards:

        card = grid.box()

        card.label(text=label, icon=icon)

        card.label(text=str(value), icon='BLANK1')

    box.label(text=f"{_t('Top Tags')}: {data.get('top_tags', _t('Not set'))}", icon='BOOKMARKS')

    box.label(text=f"{_t('Suggested profile')}: {data.get('top_profile', _t('No matching profile'))}", icon='PRESET')

    return box





def _sf_draw_session_cockpit(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, actions: list[dict], compact: bool = False):

    box = parent.box()

    box.label(text=_t('Session Cockpit...'), icon='MENU_PANEL')

    row = box.row(align=True)

    row.operator(SF_OT_workspace_command_session_cockpit.bl_idname, text=_t('Session Cockpit'), icon='MENU_PANEL')

    op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_goal_home, text=_t('Goal Home...'), icon='WINDOW')

    _sf_safe_set_operator_property(op, 'goal', _sf_current_session_goal(context))

    row.operator(SF_OT_workspace_command_action_palette.bl_idname, text=_t('Action Palette'), icon='VIEWZOOM')

    _sf_draw_blocker_stack(box, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=True)

    _sf_draw_profile_signal_board(box, prefs, context, compact=True)

    return box





def _sf_run_simple_operator(op_callable, *args, **kwargs) -> bool:

    if op_callable is None:

        return False

    attempts = [

        (args, kwargs),

        (( 'EXEC_DEFAULT',), kwargs) if not args else None,

        ((), kwargs),

        (( 'EXEC_DEFAULT',), {}) if not args else None,

        ((), {}),

    ]

    for attempt in attempts:

        if attempt is None:

            continue

        a, kw = attempt

        try:

            op_callable(*a, **kw)

            return True

        except TypeError:

            continue

        except Exception:

            continue

    return False





def _sf_get_operator_callable(op_idname: str):

    try:

        category, name = str(op_idname or '').split('.', 1)

    except ValueError:

        return None

    try:

        category_mod = getattr(bpy.ops, category, None)

        return getattr(category_mod, name, None) if category_mod else None

    except Exception:

        return None





def _sf_run_operator_by_idname(op_idname: str, *args, **kwargs) -> bool:

    return _sf_run_simple_operator(_sf_get_operator_callable(op_idname), *args, **kwargs)





def _sf_call_menu_direct(menu_name: str, context=None) -> bool:

    menu_name = str(menu_name or '').strip()

    if not menu_name:

        return False

    call_menu = getattr(getattr(bpy.ops, 'wm', None), 'call_menu', None)

    if call_menu is None:

        return False

    return _sf_run_simple_operator(call_menu, name=menu_name)





def _sf_enable_standard_npanel_popups(class_iterable=None):

    return None







class SF_OT_reference_manager_run_repair_pack(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_run_repair_pack'

    bl_label = 'Run Repair Pack'

    bl_description = 'Run a bundled maintenance pack that combines root fixes, source coverage fixes, and the next most relevant tool for the chosen situation'

    bl_options = {'UNDO', 'INTERNAL'}



    mode: EnumProperty(

        name='Repair Pack',

        items=[

            ('ROOTS_ONLY', 'Roots Only', 'Enable, clean, and sort library roots without changing the current source selection'),

            ('COVERAGE_INDEX', 'Coverage + Index', 'Bring the current source under root coverage, then rebuild the library index'),

            ('RECOVER_REVIEW', 'Recover + Review', 'Run Smart Fix All and open the current source check for a follow-up review'),

            ('PUBLISH_PREP', 'Publish Prep', 'Repair coverage, rebuild the index, then continue into preview or publish follow-up tools'),

        ],

        default='COVERAGE_INDEX',

        options={'HIDDEN'},

    )



    def execute(self, context):

        prefs = _addon_prefs(context)

        if not prefs:

            return {'CANCELLED'}

        reason = _sf_repair_pack_block_reason(context, prefs, self.mode)

        if reason:

            self.report({'INFO'}, reason)

            return {'CANCELLED'}

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        steps = []

        if self.mode in {'COVERAGE_INDEX', 'PUBLISH_PREP'} and has_source:

            source_info = _sf_get_source_insights(prefs, filepath, None)

            if not bool(source_info.get('inside_root')):

                if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_library_roots_add_source_folder_as_root', None), mode='CURRENT_FOLDER'):

                    steps.append(_t('Added source root'))

        if self.mode == 'RECOVER_REVIEW':

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_workspace_command_fix_all', None)):

                steps.append(_t('Smart fix'))

        else:

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_library_roots_enable_all_roots', None)):

                steps.append(_t('Enabled roots'))

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_library_roots_disable_missing_roots', None)):

                steps.append(_t('Disabled missing roots'))

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_library_roots_clean_roots', None), remove_missing=False, deduplicate=True, sort_by_priority=True):

                steps.append(_t('Cleaned roots'))

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_library_roots_sort_roots', None)):

                steps.append(_t('Sorted roots'))

        if self.mode in {'COVERAGE_INDEX', 'PUBLISH_PREP'}:

            if _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_asset_library_rebuild_index', None)):

                steps.append(_t('Rebuilt index'))

        followup = ''

        if self.mode == 'RECOVER_REVIEW':

            _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_source_check', None), 'INVOKE_DEFAULT')

            followup = _t('Source Check...')

        elif self.mode == 'PUBLISH_PREP':

            source_info = _sf_get_source_insights(prefs, filepath, None)

            if has_source and (not source_info.get('preview_path') or not source_info.get('meta_path')):

                _sf_run_operator_by_idname('export_scene.sfs_asset_preview_batch_preview', 'INVOKE_DEFAULT')

                followup = _t('Asset Preview Batch...')

            else:

                _sf_run_operator_by_idname('export_scene.sfs_publisher_publish_asset', 'INVOKE_DEFAULT')

                followup = _t('Publish Asset...')

        elif self.mode == 'COVERAGE_INDEX':

            _sf_run_simple_operator(getattr(bpy.ops.import_scene, 'sfs_reference_manager_open', None), 'INVOKE_DEFAULT')

            followup = _t('Reference Manager...')

        summary = ','.join([s for s in steps if s]) or _t('No repair-pack changes were needed')

        if followup:

            summary = f"{summary} → {followup}"

        self.report({'INFO'}, f"{_t('Repair pack finished')}: {summary}")

        _sf_append_activity(context, _t('Ran repair pack'), f"{self.mode}: {summary}", 'TOOL_SETTINGS')

        return {'FINISHED'}





def _sf_draw_repair_pack_panel(parent, context, prefs, filepath: str, source_info: dict, compact: bool = False):

    box = parent.box()

    _sf_draw_section_intro(box, 'Repair Packs', 'Run bundled maintenance packs for roots, coverage, recovery, or publish preparation when you want fewer manual steps.', 'TOOL_SETTINGS')

    grid = box.grid_flow(columns=1 if compact else 2, row_major=True, even_columns=True, even_rows=False, align=True)

    packs = [

        ('ROOTS_ONLY', _t('Roots Only'), _t('Enable, clean, and sort roots without changing the current source.'), 'FILE_FOLDER'),

        ('COVERAGE_INDEX', _t('Coverage + Index'), _t('Bring the current source under root coverage, then rebuild index data.'), 'FILE_REFRESH'),

        ('RECOVER_REVIEW', _t('Recover + Review'), _t('Run Smart Fix All and reopen the focused source check for follow-up.'), 'CHECKMARK'),

        ('PUBLISH_PREP', _t('Publish Prep'), _t('Repair coverage, refresh index data, then continue into preview or publish follow-up.'), 'EXPORT'),

    ]

    for mode, title, detail, icon in packs:

        card = grid.box()

        card.label(text=title, icon=icon)

        reason = _sf_repair_pack_block_reason(context, prefs, mode)

        run_row = card.row(align=True)

        run_row.enabled = not bool(reason)

        op = run_row.operator(SF_OT_reference_manager_run_repair_pack.bl_idname, text=_t('Run Repair Pack'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'mode', mode)

        if reason:

            card.label(text=reason)

    return box





def _sf_store_last_quick_action_result(context, title: str, summary: str, details: list[str] | None = None, follow_up: list[str] | None = None, icon: str = 'CHECKMARK'):

    wm = context.window_manager

    try:

        wm.sf_last_action_title = str(title or '')

        wm.sf_last_action_summary = str(summary or '')

        wm.sf_last_action_details = '\n'.join([str(it) for it in (details or []) if str(it).strip()])

        wm.sf_last_action_followup = '\n'.join([str(it) for it in (follow_up or []) if str(it).strip()])

        wm.sf_last_action_icon = str(icon or 'CHECKMARK')

    except Exception:

        pass





def _sf_last_quick_action_lines(context, attr_name: str) -> list[str]:

    raw = ''

    try:

        raw = str(getattr(context.window_manager, attr_name, '') or '')

    except Exception:

        raw = ''

    return [line for line in raw.splitlines() if line.strip()]





def _sf_quick_action_result_payload(context) -> dict:

    wm = context.window_manager if context else None

    prefs = _addon_prefs(context)

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    has_source = bool(filepath and os.path.isfile(filepath))

    try:

        index = _load_index()

    except Exception:

        index = {}

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    enabled_roots = [root for root in roots if bool(getattr(root, 'enabled', True))]

    roots_ready = bool(enabled_roots)

    indexed_entries = len((index or {}).get('files', {}) or {})

    index_ready = bool(indexed_entries)

    source_info = _sf_get_source_insights(prefs, filepath, index)

    health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

    title = str(getattr(wm, 'sf_last_action_title', '') or '').strip()

    summary = str(getattr(wm, 'sf_last_action_summary', '') or '').strip()

    icon = str(getattr(wm, 'sf_last_action_icon', '') or 'CHECKMARK')

    details = _sf_last_quick_action_lines(context, 'sf_last_action_details')

    follow_up = _sf_last_quick_action_lines(context, 'sf_last_action_followup')

    source_name = os.path.basename(filepath) if filepath else _t('Not set')



    def state_item(label, state, detail='', icon='NONE'):

        return {'label': _t(label), 'state': state, 'detail': detail, 'icon': icon}



    states = [

        state_item('Current Goal', 'READY', _t(_sf_current_session_goal(context).title()), _sf_goal_icon(_sf_current_session_goal(context))),

        state_item('Current Source', 'READY' if has_source else 'NEEDS SOURCE', source_name, 'FILE_BLEND'),

        state_item('Library Roots', 'READY' if roots_ready else 'NEEDS ROOTS', f"{_t('Enabled roots')}: {len(enabled_roots)}" if roots_ready else _t('No enabled roots'), 'FILE_FOLDER'),

        state_item('Index State', 'INDEXED' if index_ready else 'NEEDS INDEX', f"{_t('Indexed entries')}: {indexed_entries}" if index_ready else _t('Indexed entries') + ': 0', 'FILE_REFRESH'),

        state_item('Source Status', 'READY' if int(health_score) >= 65 else 'REVIEW', f"{int(health_score)}/100 · {health_label}", 'CHECKMARK' if int(health_score) >= 65 else 'ERROR'),

    ]

    return {

        'title': title or _t('Last Quick Action'),

        'subtitle': _t('View the latest quick-action result and decide what to open next.'),

        'summary': summary or _t('No quick action result yet'),

        'status': _t('Action result'),

        'icon': icon or 'CHECKMARK',

        'states': states,

        'lines': details,

        'follow_up': follow_up,

    }









def _sf_has_last_quick_action_result(context) -> bool:

    try:

        wm = context.window_manager if context else None

        return bool(str(getattr(wm, 'sf_last_action_title', '') or '').strip() or str(getattr(wm, 'sf_last_action_summary', '') or '').strip())

    except Exception:

        return False





def _sf_last_action_report_actions(context) -> tuple[list[tuple], list[tuple]]:

    goal = str(_sf_current_session_goal(context) or 'IMPORT').upper()

    last_title = str(getattr(context.window_manager, 'sf_last_action_title', '') or '').strip() if context and getattr(context, 'window_manager', None) else ''

    last_title_l = last_title.lower()

    source_path = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '') if context and getattr(context, 'window_manager', None) else ''

    has_source = bool(source_path and os.path.isfile(source_path))



    primary: list[tuple] = []

    secondary: list[tuple] = []

    seen: set[str] = set()



    def add(slot: list[tuple], operator_idname: str, label: str, icon: str = 'TEXT', props: dict | None = None):

        key = f"{operator_idname}|{label}"

        if key in seen:

            return

        seen.add(key)

        payload = {'open_text': True}

        if props:

            payload.update(dict(props))

        slot.append((operator_idname, label, icon, payload, False))



    add(primary, SF_OT_reference_manager_workspace_report.bl_idname, 'Workspace Report', 'TEXT')



    if 'smart fix all' in last_title_l or 'smart fix' in last_title_l:

        add(primary, SF_OT_workspace_command_fix_report.bl_idname, 'Smart Fix Report', 'TEXT')



    if has_source:

        add(secondary, SF_OT_reference_manager_product_readiness_report.bl_idname, 'Product Readiness Report', 'TEXT')

        if goal == 'PUBLISH':

            add(secondary, SF_OT_workspace_command_release_report.bl_idname, 'Release Report', 'TEXT')

        elif goal in {'IMPORT', 'MAINTAIN', 'RECOVER'}:

            add(secondary, SF_OT_workspace_command_handoff_report.bl_idname, 'Handoff Report', 'TEXT')



    return primary, secondary





def _sf_last_action_report_reason(label: str, context) -> str:

    goal = str(_sf_current_session_goal(context) or 'IMPORT').upper()

    last_title = str(getattr(context.window_manager, 'sf_last_action_title', '') or '').strip() if context and getattr(context, 'window_manager', None) else ''

    last_title_l = last_title.lower()

    label = str(label or '').strip()

    if label == 'Workspace Report':

        if 'smart fix all' in last_title_l or 'smart fix' in last_title_l:

            return _t('Use this to confirm the updated health, roots, and next actions after the latest fix.')

        if goal == 'PUBLISH':

            return _t('Use this as the everyday summary before moving to release checks.')

        return _t('Use this as the everyday summary to confirm health, roots, profiles, and next actions.')

    if label == 'Smart Fix Report':

        return _t('Use this to review the exact repairs, skips, and follow-up checks from Smart Fix.')

    if label == 'Product Readiness Report':

        return _t('Use this to see whether the current source is ready for product-facing review and handoff.')

    if label == 'Handoff Report':

        return _t('Use this when handing the current source to another person or the next pipeline step.')

    if label == 'Release Report':

        return _t('Use this to verify the final go / no-go release checks for the current source.')

    return _t('Use this report to capture the current state before moving to the next step.')





def _sf_last_action_report_priority(label: str, context) -> tuple[int, str]:

    goal = str(_sf_current_session_goal(context) or 'IMPORT').upper()

    last_title = str(getattr(context.window_manager, 'sf_last_action_title', '') or '').strip() if context and getattr(context, 'window_manager', None) else ''

    last_title_l = last_title.lower()

    source_path = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '') if context and getattr(context, 'window_manager', None) else ''

    has_source = bool(source_path and os.path.isfile(source_path))

    if label == 'Smart Fix Report' and ('smart fix all' in last_title_l or 'smart fix' in last_title_l):

        return 100, _t('Recommended first')

    if label == 'Release Report' and goal == 'PUBLISH' and has_source:

        return 100, _t('Recommended first')

    if label == 'Handoff Report' and goal in {'IMPORT', 'MAINTAIN', 'RECOVER'} and has_source:

        return 100, _t('Recommended first')

    if label == 'Workspace Report':

        if not has_source:

            return 100, _t('Recommended first')

        return 85, _t('Good next step')

    if label == 'Product Readiness Report' and has_source:

        return 90 if goal == 'PUBLISH' else 80, _t('Good next step')

    if label in {'Release Report', 'Handoff Report', 'Smart Fix Report'}:

        return 70, _t('Useful follow-up')

    return 60, _t('Useful follow-up')





def _sf_rank_last_action_reports(context, compact: bool = False) -> list[dict]:

    primary, secondary = _sf_last_action_report_actions(context)

    actions = list(primary) + list(secondary)

    ranked: list[dict] = []

    seen: set[str] = set()

    for index, action in enumerate(actions):

        if not action:

            continue

        label = str(action[1] or '').strip()

        if not label or label in seen:

            continue

        seen.add(label)

        score, band = _sf_last_action_report_priority(label, context)

        ranked.append({

            'action': action,

            'label': label,

            'reason': _sf_last_action_report_reason(label, context),

            'score': int(score),

            'band': band,

            'order': index,

        })

    ranked.sort(key=lambda item: (-int(item.get('score', 0)), int(item.get('order', 0)), str(item.get('label', '')).lower()))

    if compact:

        return ranked[:3]

    return ranked[:5]





def _sf_last_action_report_reason_lines(context, compact: bool = False) -> list[tuple[str, str, str]]:

    ranked = _sf_rank_last_action_reports(context, compact=compact)

    return [(str(item.get('band', '') or ''), str(item.get('label', '') or ''), str(item.get('reason', '') or '')) for item in ranked]





def _sf_draw_last_action_report_shortcuts(parent, context, compact: bool = False):

    ranked = _sf_rank_last_action_reports(context, compact=compact)

    if not ranked:

        return None

    box = parent.box()

    _sf_draw_section_intro(

        box,

        'Report Shortcuts',

        'Export the most relevant report for the latest result so you can share, review, or hand off the current state without rebuilding context.',

        'TEXT',

    )



    recommended = [tuple(r.get('action')) for r in ranked[:1] if r.get('action')]

    follow_up = [tuple(r.get('action')) for r in ranked[1:(3 if compact else 5)] if r.get('action')]



    if ranked:

        top = ranked[0]

        top_box = box.box()

        _sf_draw_section_intro(

            top_box,

            'Recommended Report',

            'Start with this report first when you want the clearest follow-up from the latest result.',

            'SOLO_ON',

        )

        top_box.label(text=f"{_t(str(top.get('label', '') or ''))} — {_t(str(top.get('band', '') or 'Recommended first'))}"[:240], icon='CHECKMARK')

        _sf_draw_action_block(top_box, primary_actions=recommended)



    if follow_up:

        more_box = box.box()

        _sf_draw_section_intro(

            more_box,

            'More Reports',

            'Use these when you need extra detail, sharing output, or a different review angle after the first report.',

            'TEXT',

        )

        _sf_draw_action_block(more_box, primary_actions=follow_up[:2], secondary_actions=follow_up[2:])



    reason_lines = _sf_last_action_report_reason_lines(context, compact=compact)

    if reason_lines:

        why_box = box.box()

        _sf_draw_section_intro(

            why_box,

            'Why These Reports',

            'Use the short reason under each report so you can choose the best export without guessing.',

            'NONE',

        )

        for band, label, reason in reason_lines:

            prefix = f"{_t(band)} — {_t(label)}" if band else _t(label)

            why_box.label(text=f"{prefix}: {reason}"[:240], icon='BLANK1')

    return box





def _sf_draw_last_quick_action_card(parent, context, compact: bool = False, title: str = 'Latest Result', subtitle: str = 'Keep the latest quick action visible here so you can continue from the same place after closing the popup.'):

    box = parent.box()

    if not _sf_has_last_quick_action_result(context):

        _sf_draw_empty_state(box, title, 'Nothing has been run yet. Use Review & Run on a recommended action to capture the latest result here.', 'NONE')

        return box



    payload = _sf_quick_action_result_payload(context)

    icon = str(payload.get('icon', 'CHECKMARK') or 'CHECKMARK')

    _sf_draw_section_intro(box, title, subtitle, icon)



    summary = str(payload.get('summary', '') or '').strip()

    if summary:

        box.label(text=summary[:240], icon='CHECKMARK')



    state_box = box.box()

    _sf_draw_section_intro(state_box, 'Result Snapshot', 'Review the current readiness after the last quick action finished.', 'NONE')

    for item in list(payload.get('states', []) or [])[:(3 if compact else 5)]:

        _sf_draw_state_line(

            state_box,

            str(item.get('label', 'Status') or 'Status'),

            str(item.get('state', '') or ''),

            fallback_icon=str(item.get('icon', 'NONE') or 'NONE'),

            detail=str(item.get('detail', '') or ''),

        )



    follow_up = [str(line) for line in list(payload.get('follow_up', []) or []) if str(line or '').strip()]

    if follow_up:

        next_box = box.box()

        _sf_draw_section_intro(next_box, 'Next Step', 'Use the first follow-up as the default next move after the latest quick action.', 'FORWARD')

        for line in follow_up[:(1 if compact else 2)]:

            next_box.label(text=line[:240], icon='BLANK1')



    _sf_draw_last_action_report_shortcuts(box, context, compact=compact)



    action_block = box.column(align=True)

    primary = [

        (SF_OT_reference_manager_view_action_result.bl_idname, 'Open Result...', 'CHECKMARK', {}, False),

        (SF_OT_reference_manager_source_check.bl_idname, 'Open Source Check...', 'CHECKMARK', {}, False),

    ]

    secondary = [

        (SF_OT_workspace_command_action_palette.bl_idname, 'Open Action Palette...', 'VIEWZOOM', {}, False),

    ]

    last_title = str(getattr(context.window_manager, 'sf_last_action_title', '') or '')

    if last_title == _t('Smart Fix All') or last_title == 'Smart Fix All':

        secondary.append((SF_OT_workspace_command_fix_details.bl_idname, 'Open Smart Fix Details...', 'TEXT', {}, False))

    _sf_draw_action_block(action_block, primary_actions=primary, secondary_actions=secondary)

    return box





def _sf_store_last_fix_report(context, summary: str, details: list[str]):

    wm = context.window_manager

    try:

        wm.sf_last_fix_summary = str(summary or '')

        wm.sf_last_fix_details = '\n'.join([str(it) for it in (details or []) if str(it).strip()])

    except Exception:

        pass





def _sf_last_fix_report_lines(context) -> list[str]:

    raw = ''

    try:

        raw = str(getattr(context.window_manager, 'sf_last_fix_details', '') or '')

    except Exception:

        raw = ''

    return [line for line in raw.splitlines() if line.strip()]





def _sf_draw_last_fix_snapshot(parent, context, compact: bool = False):

    box = parent.box()

    box.label(text=_t('Latest Repair Snapshot'), icon='TOOL_SETTINGS')

    summary = ''

    try:

        summary = str(getattr(context.window_manager, 'sf_last_fix_summary', '') or '').strip()

    except Exception:

        summary = ''

    if not summary:

        box.label(text=_t('No smart fix report yet'))

        return box

    box.label(text=summary, icon='CHECKMARK')

    details = _sf_last_fix_report_lines(context)

    for line in details[:(2 if compact else 5)]:

        box.label(text=line, icon='BLANK1')

    row = box.row(align=True)

    row.operator(SF_OT_workspace_command_fix_details.bl_idname, text=_t('Fix Details'), icon='TEXT')

    row.operator(SF_OT_workspace_command_fix_report.bl_idname, text=_t('Fix Report'), icon='EXPORT')

    return box





def _sf_workflow_preset_label(preset: str) -> str:

    preset = str(preset or '').upper()

    if preset == 'IMPORT':

        return _t('Objects + Append')

    if preset == 'MANAGE':

        return _t('Collections + Link')

    if preset == 'PUBLISH':

        return _t('Collections + Link Override')

    return ""





def _sf_apply_workflow_preset(context, preset: str) -> str:

    wm = context.window_manager

    preset = str(preset or '').upper()

    if preset == 'IMPORT':

        wm.sf_mode = 'OBJECTS'

        wm.sf_import_mode = 'APPEND'

        wm.sf_strict_loader = False

        wm.sf_include_dependencies = True

        wm.sf_bake_world = False

        wm.sf_clear_parent = True

        wm.sf_clear_constraints = False

        wm.sf_collision = 'DUPLICATE'

        wm.sf_apply_prefix_to_linked = False

        wm.sf_put_in_collection = True

        wm.sf_collection_name_mode = 'FILE'

        wm.sf_placement = 'ORIGINAL'

        wm.sf_select_imported = True

        wm.sf_frame_view = False

    elif preset == 'MANAGE':

        wm.sf_mode = 'COLLECTIONS'

        wm.sf_import_mode = 'LINK'

        wm.sf_strict_loader = True

        wm.sf_include_dependencies = True

        wm.sf_bake_world = False

        wm.sf_clear_parent = False

        wm.sf_clear_constraints = False

        wm.sf_collision = 'REUSE'

        wm.sf_apply_prefix_to_linked = False

        wm.sf_put_in_collection = False

        wm.sf_collection_name_mode = 'FILE'

        wm.sf_placement = 'ORIGINAL'

        wm.sf_select_imported = False

        wm.sf_frame_view = False

    elif preset == 'PUBLISH':

        wm.sf_mode = 'COLLECTIONS'

        wm.sf_import_mode = 'LINK_OVERRIDE'

        wm.sf_strict_loader = True

        wm.sf_include_dependencies = True

        wm.sf_bake_world = False

        wm.sf_clear_parent = False

        wm.sf_clear_constraints = False

        wm.sf_collision = 'REUSE'

        wm.sf_apply_prefix_to_linked = False

        wm.sf_put_in_collection = False

        wm.sf_collection_name_mode = 'FILE'

        wm.sf_placement = 'ORIGINAL'

        wm.sf_select_imported = True

        wm.sf_frame_view = False

    else:

        return ""



    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

    if filepath and os.path.isfile(filepath):

        try:

            _reload_items(context)

        except Exception:

            pass

    return _sf_workflow_preset_label(preset)





class SF_OT_reference_manager_apply_recommended_setup(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_apply_recommended_setup'

    bl_label = 'Apply Recommended Setup'

    bl_description = 'Apply the recommended browser settings for this workflow lane so mode, import behavior, and post actions start from a safer default'

    bl_options = {'UNDO', 'INTERNAL'}



    preset: EnumProperty(

        name='Workflow Preset',

        items=[

            ('IMPORT', "Import from Source", "Objects + Append for local editable imports from a chosen .blend source"),

            ('MANAGE', "Maintain Library", "Collections + Link for safer maintenance and reference-friendly browsing"),

            ('PUBLISH', "Publish & Version", "Collections + Link Override for publish-oriented validation and version review"),

        ],

        default='IMPORT',

    )



    def execute(self, context):

        label = _sf_apply_workflow_preset(context, self.preset)

        if not label:

            self.report({'WARNING'}, _t('Invalid file'))

            return {'CANCELLED'}

        self.report({'INFO'}, f"{_t('Preset applied')}: {label}")

        return {'FINISHED'}





class SF_OT_reference_manager_apply_setup_and_open(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_apply_setup_and_open'

    bl_label = 'Apply Setup & Open'

    bl_description = 'Apply the recommended setup for this workflow lane and immediately open the most relevant next tool'

    bl_options = {'UNDO', 'INTERNAL'}



    preset: EnumProperty(

        name='Workflow Preset',

        items=[

            ('IMPORT', "Import from Source", "Objects + Append for local editable imports from a chosen .blend source"),

            ('MANAGE', "Maintain Library", "Collections + Link for safer maintenance and reference-friendly browsing"),

            ('PUBLISH', "Publish & Version", "Collections + Link Override for publish-oriented validation and version review"),

        ],

        default='IMPORT',

    )



    def execute(self, context):

        label = _sf_apply_workflow_preset(context, self.preset)

        if not label:

            self.report({'WARNING'}, _t('Invalid file'))

            return {'CANCELLED'}

        filepath = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        prefs = _addon_prefs(context)

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        if self.preset == 'IMPORT':

            if has_source:

                bpy.ops.import_scene.sfs_source_browser_import('INVOKE_DEFAULT')

            else:

                bpy.ops.import_scene.sfs_source_browser_open_folder_2('INVOKE_DEFAULT')

        elif self.preset == 'MANAGE':

            if roots_ready:

                bpy.ops.import_scene.sfs_reference_manager_open('INVOKE_DEFAULT')

            else:

                bpy.ops.import_scene.sfs_asset_library_diagnostics('INVOKE_DEFAULT')

        else:

            bpy.ops.export_scene.sfs_publisher_publish_asset('INVOKE_DEFAULT')

        return {'FINISHED'}





class SF_OT_reference_manager_source_check(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_reference_manager_source_check'

    bl_label = 'Source Check'

    bl_description = 'Open a small current-source check with only the most important status and fix buttons'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=420, min=340, max=620, options={'HIDDEN'})

    show_advanced: BoolProperty(

        name='Show advanced tools',

        default=False,

        description='Reveal deeper repair and analysis tools after the compact source-health summary.',

    )



    def invoke(self, context, event):

        _sf_refresh_compact_launcher_context(context)

        _sf_append_activity(context, _t('Opened Source Check'), _norm_path(getattr(context.window_manager, 'sf_filepath', '') or ''), 'CHECKMARK')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        try:

            index = _load_index()

        except Exception:

            index = {}

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        can_fix, fix_reason, _preview = _sf_can_run_smart_fix(context, prefs)



        managed_state = 'READY' if bool(source_info.get('inside_root')) else ('SETUP' if roots_ready else 'NOT SET')

        managed_detail = str(source_info.get('root_name') or '') if bool(source_info.get('inside_root')) else (_t('Source is still outside enabled roots') if has_source and roots_ready else '')

        indexed_state = 'INDEXED' if bool(source_info.get('is_indexed')) else ('NEEDS INDEX' if has_source else 'NOT SET')

        publish_state, publish_detail = _sf_publish_ready_state(source_info)

        profile_state, profile_detail, _profile_score = _sf_profile_fit_state(prefs, context, filepath, source_info)



        head = layout.box()

        head.label(text=_t('Source Check...'), icon='CHECKMARK')

        head.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        if has_source:

            head.label(text=_sf_short_label_display(os.path.basename(filepath), 30), icon='FILE_BLEND', translate=False)

            head.label(text=_sf_short_path_display(filepath, 48), icon='FILE_FOLDER', translate=False)

        else:

            head.label(text=_t('No source selected'))



        status = layout.box()

        _sf_draw_section_intro(

            status,

            'Current Source Summary',

            'Read these five lines first. They condense source readiness into managed/indexed/publish/profile states so beginners can decide the next move without opening heavier boards.',

            'CHECKMARK',

        )

        _sf_draw_state_line(status, 'Source', 'READY' if has_source else 'NOT SET', detail=os.path.basename(filepath) if has_source else '')

        _sf_draw_state_line(status, 'Managed', managed_state, fallback_icon='FILE_FOLDER', detail=managed_detail)

        _sf_draw_state_line(status, 'Indexed', indexed_state, fallback_icon='FILE_REFRESH')

        _sf_draw_state_line(status, 'Publish Ready', publish_state, fallback_icon='EXPORT', detail=publish_detail)

        _sf_draw_state_line(status, 'Fit Profile', profile_state, fallback_icon='PRESET', detail=profile_detail)



        row = layout.row(align=True)

        row.operator(SF_OT_source_browser_open_folder_2.bl_idname, text=_t('Open Folder'), icon='FILE_BLEND')

        row.prop(self, 'show_advanced', text=_t('Advanced'))



        row = layout.row(align=True)

        row.operator(SF_OT_reference_manager_open.bl_idname, text=_t('Open'), icon='LINKED')

        preview_row = row.row(align=True)

        preview_row.operator(SF_OT_workspace_command_fix_preview.bl_idname, text=_t('Fix Preview'), icon='TOOL_SETTINGS')

        run_fix = row.row(align=True)

        run_fix.enabled = can_fix

        run_fix.operator(SF_OT_workspace_command_fix_all.bl_idname, text=_t('Fix All'), icon='TOOL_SETTINGS')



        if actions:

            next_box = layout.box()

            next_box.label(text=_t('Next'), icon='FORWARD')

            _sf_draw_recommended_action(next_box, actions[0])



        if self.show_advanced:

            detail = layout.box()

            _sf_draw_section_intro(

                detail,

                'Advanced Details',

                'Open these when you need the deeper root, sidecar, dependency, representation, or bundle tools after confirming the compact source summary above.',

                'TOOL_SETTINGS',

            )

            if has_source:

                _sf_draw_state_line(detail, 'Preview', 'READY' if bool(source_info.get('preview_path')) else 'MISSING', fallback_icon='IMAGE_DATA')

                _sf_draw_state_line(detail, 'Metadata', 'READY' if bool(source_info.get('meta_path')) else 'MISSING', fallback_icon='TEXT')

                _sf_draw_state_line(detail, 'Catalog', 'READY' if bool(source_info.get('catalog_path')) else 'MISSING', fallback_icon='FILE')

            else:

                detail.label(text=_t('Select a .blend file first.'))

            extra = detail.row(align=True)

            extra.operator('import_scene.sfs_external_assets_audit', text=_t('Audit'), icon='CHECKMARK')

            extra.operator('import_scene.sfs_reference_toolkit_open', text=_t('Open'), icon='ASSET_MANAGER')

            extra.operator('import_scene.sfs_dependency_cockpit_open', text=_t('Open'), icon='NETWORK_DRIVE')

            extra.operator('import_scene.sfs_context_roots_open', text=_t('Open'), icon='FILE_PARENT')

            extra2 = detail.row(align=True)

            extra2.operator('import_scene.sfs_root_watch_open', text=_t('Open'), icon='FILE_REFRESH')

            extra2.operator('import_scene.sfs_representation_open', text=_t('Open'), icon='MOD_WIREFRAME')

            extra2.operator('import_scene.sfs_assembly_guard_open', text=_t('Open'), icon='RESTRICT_SELECT_OFF')

            extra2.operator('import_scene.sfs_external_assets_bundle_project', text=_t('Bundle Project'), icon='EXPORT')



        if fix_reason and not can_fix:

            layout.label(text=_sf_short_label_display(fix_reason, 46))





class SF_OT_reference_manager_product_readiness_report(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_reference_manager_product_readiness_report'

    bl_label = 'Product Readiness Report'

    bl_description = 'Export a compact product-readiness handoff report with blockers, goal cards, source-root-profile relations, and the current top recommendation.'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        lines = _sf_build_product_readiness_lines(context)

        text_name = _sf_report_export(

            context,

            _t('Product Readiness Report'),

            lines,

            open_text=self.open_text,

            activity_title=_t('Exported product readiness report'),

        )

        self.report({'INFO'}, f"{_t('Product readiness report exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_workspace_command_goal_home(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_goal_home'

    bl_label = 'Goal Home'

    bl_description = 'Open a compact goal home with only the current goal, top actions, and matching profiles'

    bl_options = {'INTERNAL'}



    goal: EnumProperty(

        name='Goal',

        items=[('EXPLORE', 'Explore', ''), ('IMPORT', 'Import', ''), ('MAINTAIN', 'Maintain', ''), ('PUBLISH', 'Publish', ''), ('RECOVER', 'Recover', '')],

        default='IMPORT',

        options={'HIDDEN'},

    )

    popup_width: IntProperty(default=420, min=340, max=620, options={'HIDDEN'})

    show_advanced: BoolProperty(

        name='Show advanced tools',

        default=False,

        description='Reveal deeper repair and analysis tools after the compact source-health summary.',

    )



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened goal home'), str(self.goal or ''), _sf_goal_icon(self.goal))

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        has_source = bool(filepath and os.path.isfile(filepath))

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        matched = _sf_profiles_for_goal(prefs, self.goal, context=context) if prefs else []



        head = layout.box()

        head.label(text=_t('Goal Home...'), icon=_sf_goal_icon(self.goal))

        head.label(text=f"{_t('Goal')}: {_t(str(self.goal).title())}", icon='BOOKMARKS')

        head.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')



        row = layout.row(align=True)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_set_goal, text=_t('Set Goal'), icon='BOOKMARKS')

        _sf_safe_set_operator_property(op, 'goal', self.goal)

        op = _sf_draw_operator_if_registered(row, SF_OT_workspace_command_open_goal, text=_t('Apply'), icon='PLAY')

        _sf_safe_set_operator_property(op, 'goal', self.goal)

        row.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')



        if actions:

            next_box = layout.box()

            next_box.label(text=_t('Next'), icon='FORWARD')

            _sf_draw_recommended_action(next_box, actions[0])



        if matched:

            pbox = layout.box()

            pbox.label(text=_t('Profiles'), icon='PRESET')

            for idx, profile in matched[:2]:

                row = pbox.row(align=True)

                label = _sf_short_label_display(getattr(profile, 'name', '') or _ui_text(f'Profile {idx+1}', f'プロファイル {idx + 1}'), 28)

                op = row.operator(SF_OT_workspace_profile_apply_profile.bl_idname, text=label, icon='PRESET')

                _sf_safe_set_operator_property(op, 'index', idx)

                op = row.operator(SF_OT_workspace_profile_apply_and_open.bl_idname, text='', icon='PLAY', emboss=True)

                _sf_safe_set_operator_property(op, 'index', idx)



        tools = layout.row(align=True)

        open_row = tools.row(align=True)

        open_row.operator(SF_OT_source_browser_import.bl_idname, text=_t('Import'), icon='IMPORT')

        tools.operator(SF_OT_reference_manager_open.bl_idname, text=_t('Open'), icon='LINKED')

        tools.operator(SF_OT_publisher_publish_asset.bl_idname, text=_t('Publish Asset'), icon='EXPORT')





class SF_OT_workspace_command_session_cockpit(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_session_cockpit'

    bl_label = 'Session Cockpit'

    bl_description = 'Open a compact session summary with only current status and the next useful tools'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=420, min=340, max=620, options={'HIDDEN'})

    show_advanced: BoolProperty(

        name='Show advanced tools',

        default=False,

        description='Reveal deeper repair and analysis tools after the compact source-health summary.',

    )



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Session Cockpit'), _sf_current_session_goal(context), 'MENU_PANEL')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        has_source = bool(filepath and os.path.isfile(filepath))

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        current_goal = _sf_current_session_goal(context)



        head = layout.box()

        head.label(text=_t('Session Cockpit...'), icon='MENU_PANEL')

        head.label(text=f"{_t('Current Goal')}: {_t(str(current_goal).title())}", icon='BOOKMARKS')

        head.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        if has_source:

            head.label(text=_sf_short_label_display(os.path.basename(filepath), 30), icon='FILE_BLEND', translate=False)

        else:

            head.label(text=_t('No source selected'))



        status = layout.column(align=True)

        if has_source:

            _sf_draw_state_line(status, 'Root', 'OK' if source_info.get('inside_root') else 'Setup', fallback_icon='FILE_FOLDER', detail=(source_info.get('root_name') or ''))

            _sf_draw_state_line(status, 'Index', 'OK' if bool(source_info.get('is_indexed')) else 'Missing', fallback_icon='FILE_REFRESH')

            _sf_draw_state_line(status, 'Preview', 'OK' if bool(source_info.get('preview_path')) else 'Missing', fallback_icon='IMAGE_DATA')



        if actions:

            next_box = layout.box()

            next_box.label(text=_t('Next'), icon='FORWARD')

            _sf_draw_recommended_action(next_box, actions[0])



        row = layout.row(align=True)

        row.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

        row.operator(SF_OT_reference_manager_open.bl_idname, text=_t('Open'), icon='LINKED')

        row.operator(SF_OT_publisher_publish_asset.bl_idname, text=_t('Publish Asset'), icon='EXPORT')



        bottom = layout.row(align=True)

        open_row = bottom.row(align=True)

        open_row.operator(SF_OT_source_browser_import.bl_idname, text=_t('Import'), icon='IMPORT')

        bottom.operator('uhm.sfs_history_create_restore_point_now', text=_t('Create Restore Point Now'), icon='RECOVER_LAST')





class SF_OT_workspace_command_action_palette(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_action_palette'

    bl_label = 'Action Palette'

    bl_description = 'Open a searchable command palette for Smart File tools, recommendations, and goal-oriented actions'

    bl_options = {'INTERNAL'}



    filter_text: StringProperty(name='Filter', default="", options={'TEXTEDIT_UPDATE'})

    popup_width: IntProperty(default=640, min=420, max=1100, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Action Palette'), _sf_current_session_goal(context), 'VIEWZOOM')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        has_source = bool(filepath and os.path.isfile(filepath))

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)



        hero = layout.box()

        hero.label(text=_t('Action Palette...'), icon='VIEWZOOM')

        hero.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        hero.prop(self, 'filter_text', text=_t('Search'))



        entries = _sf_action_palette_items(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        filt = str(self.filter_text or '').strip().lower()

        if filt:

            filtered = []

            for entry in entries:

                hay = '|'.join([

                    str(entry.get('title', '') or ''),

                    str(entry.get('detail', '') or ''),

                    str(entry.get('keywords', '') or ''),

                    str(entry.get('button', '') or ''),

                ]).lower()

                if filt in hay:

                    filtered.append(entry)

            entries = filtered

        layout.label(text=f"{_t('Visible Commands')}: {len(entries)}")

        if not entries:

            layout.label(text=_t('No matching command found'))

            return

        for entry in entries[:12]:

            _sf_draw_action_palette_entry(layout, entry)





class SF_OT_library_roots_root_coverage_matrix(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_library_roots_root_coverage_matrix'

    bl_label = 'Root Coverage Matrix'

    bl_description = 'Open a detailed matrix that compares every library root with current-source coverage, indexed counts, and maintenance state'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=720, min=420, max=1200, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Root Coverage Matrix'), _norm_path(getattr(context.window_manager, 'sf_filepath', '') or ''), 'FILE_FOLDER')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        filepath = _norm_path(getattr(context.window_manager, 'sf_filepath', '') or '')

        try:

            index = _load_index()

        except Exception:

            index = {}

        _sf_draw_root_coverage_matrix(layout, prefs, filepath, index, compact=False)





class SF_OT_workspace_command_release_report(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_release_report'

    bl_label = 'Release Report'

    bl_description = 'Export a release-readiness report that summarizes concrete gates for source setup, root coverage, indexing, sidecars, profile fit, and the next action.'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        lines = _sf_build_release_readiness_lines(context)

        text_name = _sf_report_export(

            context,

            _t('Release Report'),

            lines,

            open_text=self.open_text,

            activity_title=_t('Exported release readiness report'),

        )

        self.report({'INFO'}, f"{_t('Release readiness report exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_workspace_command_release_gate(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_release_gate'

    bl_label = 'Release Gate'

    bl_description = 'Open a board that evaluates release readiness as concrete gates for the current source, goal, roots, index state, sidecars, profiles, and next actions'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=760, min=420, max=1200, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Release Gate'), _sf_current_session_goal(context), 'CHECKMARK')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        has_source = bool(filepath and os.path.isfile(filepath))

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)



        hero = layout.box()

        hero.label(text=_t('Release Gate...'), icon='CHECKMARK')

        hero.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        row = hero.row(align=True)

        row.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

        row.operator(SF_OT_workspace_command_release_report.bl_idname, text=_t('Release Report'), icon='TEXT').open_text = True

        hero.label(text=_t('Review before running'), icon='ERROR')

        _sf_draw_last_quick_action_card(layout, context, compact=False)



        split = layout.split(factor=0.5)

        left = split.column(align=True)

        right = split.column(align=True)

        _sf_draw_release_gate_board(left, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=False)

        _sf_draw_blocker_stack(left, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=False)

        _sf_draw_goal_roadmap_panel(left, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=False)

        _sf_draw_source_root_profile_matrix(right, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=False)

        _sf_draw_profile_coverage_board(right, prefs, context=context, compact=False)

        _sf_draw_action_queue_panel(right, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, compact=False)





class SF_OT_workspace_command_handoff_report(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_handoff_report'

    bl_label = 'Handoff Report'

    bl_description = 'Export a consolidated final handoff pack with readiness, blockers, profile coverage, and the top recommendation for the current source and goal.'

    bl_options = {'UNDO', 'INTERNAL'}



    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})



    def execute(self, context):

        lines = _sf_build_final_handoff_lines(context)

        text_name = _sf_report_export(

            context,

            _t('Handoff Report'),

            lines,

            open_text=self.open_text,

            activity_title=_t('Exported final handoff pack'),

        )

        self.report({'INFO'}, f"{_t('Final handoff pack exported')}: {text_name}")

        return {'FINISHED'}





class SF_OT_reference_manager_final_review(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_reference_manager_final_review'

    bl_label = 'Final Review'

    bl_description = 'Open a final-review board that consolidates product readiness, blocker priority, profile coverage, and the top next action for handoff or release checks'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=760, min=420, max=1200, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_append_activity(context, _t('Opened Final Review'), _sf_current_session_goal(context), 'TEXT')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        layout = self.layout

        prefs = _addon_prefs(context)

        wm = context.window_manager

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')

        try:

            index = _load_index()

        except Exception:

            index = {}

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

        index_ready = bool(len((index or {}).get('files', {}) or {}))

        source_info = _sf_get_source_insights(prefs, filepath, index)

        has_source = bool(filepath and os.path.isfile(filepath))

        health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

        compact = bool(prefs and str(getattr(prefs, 'ui_home_density', 'COMFORT')) == 'COMPACT')



        hero = layout.box()

        hero.label(text=_t('Final Review...'), icon='TEXT')

        hero.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

        hero.label(text=f"{_t('Session Goal')}: {_t(str(_sf_current_session_goal(context)).title())}", icon='BOOKMARKS')

        row = hero.row(align=True)

        row.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

        row.operator(SF_OT_workspace_command_handoff_report.bl_idname, text=_t('Handoff Report'), icon='TEXT').open_text = True

        hero.label(text=_t('Review before running'), icon='ERROR')

        _sf_draw_last_quick_action_card(layout, context, compact=compact)



        split = layout.split(factor=0.5)

        left = split.column(align=True)

        right = split.column(align=True)

        _sf_draw_goal_home_cards(left, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=compact)

        _sf_draw_blocker_stack(left, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=compact)

        _sf_draw_source_root_profile_matrix(left, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=compact)

        _sf_draw_profile_coverage_board(right, prefs, context=context, compact=compact)

        _sf_draw_release_gate_board(right, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=compact)

        _sf_draw_profile_signal_board(right, prefs, context, compact=compact)

        _sf_draw_action_queue_panel(right, context, prefs, filepath, source_info, roots_ready, index_ready, health_score, compact=compact)





def _sf_draw_launcher_saved_source_button(parent, path: str, *, kind: str, index: int, fallback_icon: str = 'FILE_BLEND'):

    path = _norm_path(path or '')

    label = os.path.basename(path) or path or _t('Source')

    icon_id = _sf_saved_path_icon_id(path)

    if icon_id:

        op = parent.operator('import_scene.sfs_source_browser_use', text=_sf_short_label_display(label, 22), icon_value=icon_id)

    else:

        op = parent.operator('import_scene.sfs_source_browser_use', text=_sf_short_label_display(label, 22), icon=fallback_icon)

    _sf_safe_set_operator_property(op, 'kind', kind)

    _sf_safe_set_operator_property(op, 'index', index)

    return op





def _sf_draw_launcher_quick_sources(parent, context, prefs):

    entries_recent = list(getattr(prefs, 'recent_paths', []) or [])[:2] if prefs else []

    entries_fav = list(getattr(prefs, 'favorite_paths', []) or [])[:2] if prefs else []

    box = parent.box()

    _sf_draw_section_intro(

        box,

        'Quick Sources',

        'Reopen a recent or pinned source without browsing folders again. Use this when the current task returns to the same files repeatedly.',

        'FILE_BLEND',

    )

    if not entries_recent and not entries_fav:

        box.label(text=_t('No recent or favorite sources yet'))

    if entries_fav:

        fav_box = box.box()

        _sf_draw_section_intro(

            fav_box,

            'Favorites',

            'Pin trusted sources here so beginners and veterans can jump back to the same asset roots without searching.',

            'FUND',

        )

        for idx, item in enumerate(entries_fav):

            path = getattr(item, 'path', '') or ''

            row = fav_box.row(align=True)

            _sf_draw_launcher_saved_source_button(row, path, kind='FAVORITE', index=idx, fallback_icon='FUND')

            info = fav_box.row(align=True)

            info.enabled = False

            info.label(text=_sf_short_path_display(path, 56), icon='BLANK1', translate=False)

    if entries_recent:

        recent_box = box.box()

        _sf_draw_section_intro(

            recent_box,

            'Recent',

            'Use the last opened sources when you want to continue a nearby task or compare against a previous source quickly.',

            'FILE_REFRESH',

        )

        for idx, item in enumerate(entries_recent):

            path = getattr(item, 'path', '') or ''

            row = recent_box.row(align=True)

            _sf_draw_launcher_saved_source_button(row, path, kind='RECENT', index=idx, fallback_icon='FILE_BLEND')

            info = recent_box.row(align=True)

            info.enabled = False

            info.label(text=_sf_short_path_display(path, 56), icon='BLANK1', translate=False)

    footer = box.row(align=True)

    footer.menu(SF_MT_reference_manager_reference_manager_recent_sources.bl_idname, text=_t('Reference Manager Recent Sources'), icon='FILE_BLEND')

    footer.menu(SF_MT_reference_manager_reference_manager_favorite_sources.bl_idname, text=_t('Reference Manager Favorite Sources'), icon='FUND')

    pin = footer.row(align=True)

    pin.enabled = bool(_norm_path(getattr(context.window_manager, 'sf_filepath', '') or ''))

    pin.operator('import_scene.sfs_source_add_current_favorite', text=_t('Add Favorite'), icon='BOOKMARKS')

    return box





def _sf_draw_launcher_lane(parent, title: str, subtitle: str, icon: str, primary_actions=None, secondary_actions=None):

    box = parent.box()

    _sf_draw_section_intro(box, title, subtitle, icon)

    _sf_draw_action_block(box, primary_actions=primary_actions, secondary_actions=secondary_actions)

    return box





def _sf_draw_launcher_snapshot_card(parent, context, prefs, filepath: str, source_info: dict, roots_ready: bool, index_ready: bool, health_score: int, health_label: str, actions: list[dict], can_fix: bool, fix_reason: str, include_hero: bool = False):

    goal = _sf_current_session_goal(context)

    has_source = bool(filepath and os.path.isfile(filepath))

    title = 'Smart File' if include_hero else 'Launcher Snapshot'

    subtitle = 'Start here to confirm the active source, managed/indexed/publish/profile status, and safest next move before opening deeper tools.'

    box = parent.box()

    _sf_draw_section_intro(box, title, subtitle, 'MENU_PANEL')

    box.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

    box.label(text=f"{_t('Session Goal')}: {_t(str(goal).title())}", icon=_sf_goal_icon(goal))

    if has_source:

        box.label(text=_sf_short_label_display(os.path.basename(filepath), 34), icon='FILE_BLEND', translate=False)

        box.label(text=_sf_short_path_display(filepath, 74), icon='FILE_FOLDER', translate=False)

    else:

        box.label(text=_t('No source selected'))



    managed_state = 'READY' if source_info.get('inside_root') else ('NEEDS SETUP' if roots_ready else 'NOT SET')

    managed_detail = str(source_info.get('root_name') or '') if bool(source_info.get('inside_root')) else (_t('Source is still outside enabled roots') if has_source and roots_ready else '')

    index_state = 'INDEXED' if bool(source_info.get('is_indexed')) else ('NEEDS INDEX' if has_source else 'NOT SET')

    publish_state, publish_detail = _sf_publish_ready_state(source_info)

    profile_state, profile_detail, _profile_score = _sf_profile_fit_state(prefs, context, filepath, source_info)



    state = box.box()

    _sf_draw_section_intro(

        state,

        'Source Health',

        'Read these lines first. They condense the current source into source/managed/indexed/publish/profile states so you can decide the next action quickly.',

        'CHECKMARK',

    )

    _sf_draw_state_line(state, 'Source', 'READY' if has_source else 'NOT SET', detail=os.path.basename(filepath) if has_source else '')

    _sf_draw_state_line(state, 'Managed', managed_state, detail=managed_detail)

    _sf_draw_state_line(state, 'Indexed', index_state, fallback_icon='FILE_REFRESH')

    _sf_draw_state_line(state, 'Publish Ready', publish_state, fallback_icon='EXPORT', detail=publish_detail)

    _sf_draw_state_line(state, 'Fit Profile', profile_state, fallback_icon='PRESET', detail=profile_detail)



    nav = box.row(align=True)

    nav.operator(SF_OT_source_browser_open_folder_2.bl_idname, text=_t('Open Folder'), icon='FILE_BLEND')

    nav.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

    op = _sf_draw_operator_if_registered(nav, SF_OT_workspace_command_goal_home, text=_t('Goal Home...'), icon=_sf_goal_icon(goal))

    _sf_safe_set_operator_property(op, 'goal', goal)

    nav.operator(SF_OT_workspace_command_action_palette.bl_idname, text=_t('Action Palette'), icon='VIEWZOOM')



    if actions:

        rec = box.box()

        _sf_draw_section_intro(

            rec,

            'Best Next Move',

            'Use this when you want Smart File to choose the most relevant lane from source health, root coverage, index state, publish readiness, and the current goal.',

            'FORWARD',

        )

        _sf_draw_recommended_action(rec, actions[0])



    quick = box.row(align=True)

    quick.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    quick.operator(SF_OT_workspace_command_fix_preview.bl_idname, text=_t('Fix Preview'), icon='TOOL_SETTINGS')

    run_fix = quick.row(align=True)

    run_fix.enabled = can_fix

    run_fix.operator(SF_OT_workspace_command_fix_all.bl_idname, text=_t('Fix All'), icon='TOOL_SETTINGS')

    quick.operator(SF_OT_history_open.bl_idname, text=_t('Open'), icon='RECOVER_LAST')



    if fix_reason and not can_fix:

        hint = box.row(align=True)

        hint.enabled = False

        hint.label(text=_sf_short_label_display(fix_reason, 72))

    return box







_SF_COMPACT_LAUNCHER_CONTEXT_CACHE = {'key': None, 'fast_key': None, 'time': 0.0, 'data': None}

_SF_COMPACT_LAUNCHER_CONTEXT_TTL = 2.5





def _sf_cache_file_signature(path: str) -> tuple[int, int]:

    try:

        if not path:

            return -1, -1

        st = os.stat(path)

        return int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))), int(st.st_size)

    except Exception:

        return -1, -1





def _sf_library_roots_signature(prefs) -> tuple:

    rows = []

    try:

        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    except Exception:

        roots = []

    for root in roots:

        try:

            rows.append((

                _norm_path(getattr(root, 'path', '') or ''),

                str(getattr(root, 'label', '') or ''),

                bool(getattr(root, 'enabled', True)),

                int(getattr(root, 'priority', 0) or 0),

            ))

        except Exception:

            pass

    return tuple(rows)





def _sf_compact_launcher_fast_key(context, prefs, filepath: str) -> tuple:

    try:

        wm = getattr(context, 'window_manager', None)

        goal = str(getattr(wm, 'sf_session_goal', '') or '') if wm else ''

    except Exception:

        goal = ''

    return (_norm_path(filepath or ''), goal, id(prefs) if prefs is not None else 0)





def _sf_compact_launcher_cache_key(context, prefs, filepath: str) -> tuple:

    try:

        index_path_fn = globals().get('_index_json_path')

        index_path = str(index_path_fn() if callable(index_path_fn) else '')

    except Exception:

        index_path = ''

    try:

        wm = getattr(context, 'window_manager', None)

        goal = str(getattr(wm, 'sf_session_goal', '') or '')

    except Exception:

        goal = ''

    return (

        _norm_path(filepath or ''),

        _sf_cache_file_signature(filepath),

        index_path,

        _sf_cache_file_signature(index_path),

        _sf_library_roots_signature(prefs),

        goal,

    )





def _sf_clone_compact_launcher_context(data: dict) -> dict:

    out = dict(data or {})

    if isinstance(out.get('source_info'), dict):

        out['source_info'] = dict(out.get('source_info') or {})

    if isinstance(out.get('actions'), list):

        out['actions'] = [dict(item) if isinstance(item, dict) else item for item in out.get('actions') or []]

    return out





def _sf_compact_launcher_context_cache_clear() -> None:

    try:

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['key'] = None

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['fast_key'] = None

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['time'] = 0.0

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['data'] = None

    except Exception:

        pass



def _sf_refresh_compact_launcher_context(context) -> dict:

    """Explicitly refresh the disk-backed launcher diagnostics cache."""

    prefs = _addon_prefs(context)

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    fast_key = _sf_compact_launcher_fast_key(context, prefs, filepath)

    now = time.monotonic()



    cache_key = _sf_compact_launcher_cache_key(context, prefs, filepath)

    has_source = bool(filepath and os.path.isfile(filepath))

    try:

        index = _load_index()

    except Exception:

        index = {}

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

    index_ready = bool(len((index or {}).get('files', {}) or {}))

    source_info = _sf_get_source_insights(prefs, filepath, index)

    health_score, health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

    actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)

    data = {

        'prefs': prefs,

        'filepath': filepath,

        'has_source': has_source,

        'index': index,

        'roots_ready': roots_ready,

        'index_ready': index_ready,

        'source_info': source_info,

        'health_score': health_score,

        'health_label': health_label,

        'actions': actions,

    }

    try:

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['key'] = cache_key

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['fast_key'] = fast_key

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['time'] = now

        _SF_COMPACT_LAUNCHER_CONTEXT_CACHE['data'] = _sf_clone_compact_launcher_context(data)

    except Exception:

        pass

    return _sf_clone_compact_launcher_context(data)





def _sf_compact_launcher_context(context) -> dict:

    """Return only prepared launcher data; N-panel drawing performs no I/O."""

    prefs = _addon_prefs(context)

    wm = context.window_manager if context else None

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

    fast_key = _sf_compact_launcher_fast_key(context, prefs, filepath)

    try:

        if (

            _SF_COMPACT_LAUNCHER_CONTEXT_CACHE.get('fast_key') == fast_key

            and isinstance(_SF_COMPACT_LAUNCHER_CONTEXT_CACHE.get('data'), dict)

        ):

            return _sf_clone_compact_launcher_context(

                _SF_COMPACT_LAUNCHER_CONTEXT_CACHE.get('data') or {}

            )

    except Exception:

        pass

    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []

    roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)

    return {

        'prefs': prefs,

        'filepath': filepath,

        # Existence, index, source insight, health, and recommendations are

        # intentionally unknown until the user presses Refresh Status.

        'has_source': False,

        'index': {},

        'roots_ready': roots_ready,

        'index_ready': False,

        'source_info': {},

        'health_score': 0,

        'health_label': _t('Needs refresh / 更新が必要'),

        'actions': [],

    }



def _sf_compact_lane_payload(context, lane: str, ctx_data: dict | None = None) -> dict:

    ctx_data = dict(ctx_data or _sf_compact_launcher_context(context))

    filepath = _norm_path(ctx_data.get('filepath', '') or '')

    has_source = bool(ctx_data.get('has_source'))

    roots_ready = bool(ctx_data.get('roots_ready'))

    source_info = dict(ctx_data.get('source_info') or {})



    category = str(lane or 'OTHER').upper()

    info = _sf_function_category_info(category)

    items = list(_sf_function_category_items(context, category))

    first_item = items[0] if items else {}

    count = len(items)



    payload = {

        'lane': category,

        'title': str(info.get('title', _t('Category')) or _t('Category')),

        'status': str(info.get('subtitle', '') or _t('Ready')),

        'detail': str(info.get('subtitle', '') or ''),

        'button': str(info.get('button', _t('Open Category')) or _t('Open Category')),

        'operator': str(first_item.get('operator', SF_OT_workspace_command_action_palette.bl_idname) or SF_OT_workspace_command_action_palette.bl_idname),

        'kwargs': dict(first_item.get('props') or {}),

        'goal': _sf_lane_goal(category),

        'icon': str(info.get('icon', 'MENU_PANEL') or 'MENU_PANEL'),

    }



    if category == 'APPEND':

        if not has_source:

            payload.update({

                'status': _t('No source selected / ソースが選択されていません'),

                'detail': _t('Choose a .blend source first, then use append-style ingest tools from this category. / 先に .blend ソースを選択し、その後このカテゴリからアペンド系の取り込みを使ってください。'),

                'operator': SF_OT_source_browser_open_folder_2.bl_idname,

                'kwargs': {},

            })

        else:

            source_name = os.path.basename(filepath) if filepath else _t('Current Source')

            payload.update({

                'status': _t(f'Current source: {source_name} / 現在のソース: {source_name}'),

            })

    elif category == 'LINK':

        if has_source:

            root_label = str(source_info.get('root_name') or '')

            if root_label:

                payload['status'] = _t(f'Linked workflow ready in {root_label} / {root_label} でリンク作業を開始できます')

        else:

            payload['status'] = str(info.get('subtitle', '') or _t('Ready'))

    elif category == 'EXPORT':

        publish_ready = bool(

            has_source

            and roots_ready

            and bool(source_info.get('inside_root'))

            and bool(source_info.get('preview_path'))

            and bool(source_info.get('meta_path'))

            and bool(source_info.get('catalog_path'))

        )

        if publish_ready:

            payload['status'] = _t('Publish-ready source / 公開準備が整っています')

    elif category == 'HISTORY':

        payload['status'] = str(info.get('subtitle', '') or _t('Ready'))



    return payload





def _sf_draw_compact_lane_card(parent, payload: dict):

    lane = str(payload.get('lane', '') or '')

    title = str(payload.get('title', '') or '')

    icon = str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL')

    box, body, expanded = _sf_draw_child_section_header(

        parent,

        getattr(bpy, 'context', None),

        section_key=f'sfs_home_category_{_sf_slug_key(lane or title)}',

        title=title,

        icon=icon,

        help_key='category',

        lane=lane,

        section=title,

        default_open=False,

    )

    if not expanded or body is None:

        return box

    status = _sf_short_label_display(str(payload.get('status', '') or ''), 60)

    if status:

        row = body.row(align=True)

        row.enabled = False

        row.label(text=status)

    op = _sf_draw_operator_if_registered(body, SF_OT_workspace_command_open_category_hub, text=str(payload.get('button', _t('Open'))), icon=icon)

    _sf_safe_set_operator_property(op, 'lane', str(payload.get('lane', 'LINK') or 'LINK'))

    return box







def _sf_draw_compact_quick_sources(layout, context, prefs):

    box, body, expanded = _sf_draw_group_section_header(

        layout,

        context,

        section_key='sfs_section_quick_sources',

        title=_t('Quick Sources'),

        icon='FILE_BLEND',

        help_key='quick_sources',

        section=_t('Quick Sources'),

        default_open=False,

    )

    if not expanded or body is None:

        return box

    row = body.column(align=True)

    row.menu(SF_MT_reference_manager_reference_manager_recent_sources.bl_idname, text=_t('Recent Sources'), icon='FILE_REFRESH')

    row.menu(SF_MT_reference_manager_reference_manager_favorite_sources.bl_idname, text=_t('Favorite Sources'), icon='FUND')

    pin = row.row(align=True)

    pin.enabled = bool(_norm_path(getattr(context.window_manager, 'sf_filepath', '') or ''))

    pin.operator('import_scene.sfs_source_add_current_favorite', text=_t('Add Favorite'), icon='BOOKMARKS')

    return box







def _sf_lane_goal(lane: str) -> str:

    return {

        'LINK': 'MAINTAIN',

        'APPEND': 'IMPORT',

        'IMPORT': 'IMPORT',

        'EXPORT': 'PUBLISH',

        'PREVIEW': 'PUBLISH',

        'HISTORY': 'RECOVER',

        'OTHER': 'MAINTAIN',

    }.get(str(lane or 'APPEND').upper(), 'IMPORT')





_SF_NPANEL_PAGE_ITEMS = [

    ('HOME', 'Home', 'Open the Smart File overview and functional category launcher inside the Smart File N-panel.', 'ASSET_MANAGER', 0),

    ('LINK', 'Link', 'Browse linked-reference, relink, override, and linked-return tools.', 'LINKED', 1),

    ('APPEND', 'Append', 'Open local editable ingest tools that start from the current source browser.', 'APPEND_BLEND', 2),

    ('IMPORT', 'Import', 'Open container, queue, and project-side import or load helpers.', 'IMPORT', 3),

    ('EXPORT', 'Export', 'Open publish, bundle, manifest, and other output-focused tools.', 'EXPORT', 4),

    ('PREVIEW', 'Preview', 'Open checks, audits, review boards, previews, and representation inspection tools.', 'IMAGE_DATA', 5),

    ('HISTORY', 'History & Restore', 'Open history, autosave, restore, rollback, and safety-recovery tools.', 'RECOVER_LAST', 6),

    ('OTHER', 'Other', 'Open cross-search, guidance, monitoring, and uncategorized support tools.', 'MENU_PANEL', 7),

]





def _sf_is_view3d_sidebar_context(context) -> bool:

    try:

        area = getattr(context, 'area', None)

        return area is None or str(getattr(area, 'type', '') or '') == 'VIEW_3D'

    except Exception:

        return False





def _sf_set_workspace_page(context, page: str) -> bool:

    wm = getattr(context, 'window_manager', None)

    if wm is None:

        return False

    page = str(page or 'HOME').upper()

    valid = {item[0] for item in _SF_NPANEL_PAGE_ITEMS}

    if page not in valid:

        page = 'HOME'

    try:

        wm.sf_workspace_page = page

        if page != 'HOME':

            goal = _sf_lane_goal(page)

            if goal:

                wm.sf_session_goal = goal

        return True

    except Exception:

        return False





def _sf_update_workspace_page(self, context):

    page = str(getattr(self, 'sf_workspace_page', 'HOME') or 'HOME').upper()

    if page == 'HOME':

        return

    try:

        goal = _sf_lane_goal(page)

        if goal:

            self.sf_session_goal = goal

    except Exception:

        pass







def _sf_lane_tool_entry(label: str, operator: str, icon: str = 'CHECKMARK', detail: str = '', props: dict | None = None, enabled: bool = True, keywords: str = '') -> dict:

    return {

        'label': label,

        'operator': operator,

        'icon': icon,

        'detail': detail,

        'props': dict(props or {}),

        'enabled': bool(enabled),

        'keywords': keywords or '',

    }









_SF_INTEGRATED_TOOL_SECTION_LIMIT = 1000





def _sf_integrated_import_module(module_name: str):

    try:

        import importlib as _sf_importlib

        package = str(__package__ or '').strip()

        if not package:

            return None

        return _sf_importlib.import_module(f'{package}.{module_name}')

    except Exception:

        return None





def _sf_integrated_tool_records(context=None) -> list[dict]:

    """Read the immutable startup catalog without importing from Panel.draw."""

    del context

    package = str(__package__ or '').strip()

    module_name = f'{package}.loader' if package else 'loader'

    loader = _sf_rm_sys.modules.get(module_name)

    get_records = getattr(loader, 'get_records', None) if loader is not None else None

    if not callable(get_records):

        return []

    try:

        return [record for record in tuple(get_records() or ()) if isinstance(record, dict)]

    except Exception:

        return []







def _sf_integrated_static_entries(record: dict, key: str) -> list[dict]:

    try:

        static_ui = (record.get('spec') or {}).get('static_ui') or {}

        entries = static_ui.get(str(key or '')) or []

        return [dict(item) for item in entries if isinstance(item, dict)]

    except Exception:

        return []



def _sf_integrated_record_alias(record: dict) -> str:

    try:

        return str((record.get('spec') or {}).get('alias') or '').strip()

    except Exception:

        return ''





def _sf_integrated_record_name(record: dict) -> str:

    spec = record.get('spec') or {}

    return str(spec.get('display_name') or spec.get('alias') or _t('Integrated Tool / 統合ツール')).strip()





def _sf_integrated_short_name(alias: str, name: str) -> str:

    alias = str(alias or '').strip().lower()

    explicit = {

        'autodesk_3ds': '3DS',

        'bulk_asset_tools': 'Assets / アセット',

        'decentraland_tools': 'DCL',

        'dxf_export': 'DXF',

        'dxf_import': 'DXF',

        'ikea': 'IKEA',

        'import_max': 'MAX',

        'object_reporter': 'Reporter / レポーター',

        'stl_legacy': 'STL',

        'texture_manager': 'Texture / テクスチャ',

        'universal_multi_importer': 'UMI',

        'vat': 'VAT',

    }

    if alias in explicit:

        return _t(explicit[alias])

    clean = str(name or alias or 'Tool')

    for word in ('Format', 'Tools', 'Tool', 'Browser', 'Editor', 'Toolset'):

        clean = clean.replace(word, '')

    clean = ' '.join(clean.split()).strip()

    return clean or str(name or alias or 'Tool')





def _sf_integrated_button_label(alias: str, addon_name: str, label: str) -> str:

    label = str(label or '').strip() or _t('Open')

    prefix = _sf_integrated_short_name(alias, addon_name)

    lowered = label.lower()

    if prefix and prefix.lower() not in lowered:

        generic = {

            'import', 'export', 'refresh', 'select', 'remove', 'add', 'clear', 'open', 'settings',

            'rename', 'copy', 'move', 'delete', 'pack', 'unpack', 'validate', 'preview', 'process',

            'apply', 'load', 'save', 'edit', 'duplicate', 'show all', 'collect', 'relink',

        }

        if label.lower() in generic or len(label) <= 18:

            return f'{prefix}: {_t(label)}'

    return label





def _sf_integrated_haystack(*values) -> str:

    return ' '.join(str(value or '') for value in values).lower()





def _sf_integrated_alias_default_category(alias: str, addon_name: str = '') -> str:

    alias = str(alias or '').lower()

    if alias in {'autodesk_3ds', 'dxf_import', 'ikea', 'import_max', 'universal_multi_importer'}:

        return 'IMPORT'

    if alias in {'dxf_export', 'stl_legacy', 'vat'}:

        return 'EXPORT'

    if alias in {'texture_manager'}:

        return 'LINK'

    if alias in {'object_reporter'}:

        return 'PREVIEW'

    if alias in {'bulk_asset_tools', 'decentraland_tools'}:

        return 'OTHER'

    return 'OTHER'





def _sf_integrated_operator_category(alias: str, addon_name: str, op_id: str, label: str, desc: str) -> str:

    text = _sf_integrated_haystack(alias, addon_name, op_id, label, desc)

    # Specific file-format import/export operators should stay in the user-facing

    # import/export lanes even when the add-on description contains both words.

    if any(token in text for token in ('export', 'save stl', 'quick export', 'glb', 'gltf', 'csv', 'bundle', 'composite', 'vertex animation', 'process anim')):

        if 'import' not in str(op_id).lower() or 'export' in text:

            return 'EXPORT'

    if any(token in text for token in ('restore', 'autosave', 'backup', 'history', 'snapshot', 'rollback')):

        return 'HISTORY'

    if any(token in text for token in ('relink', 'link ', 'linked', 'reference', 'library', 'texture path', 'make relative', 'make absolute', 'pack', 'unpack', 'collect', 'gather', 'missing')):

        if 'append' not in text and 'import' not in str(op_id).lower():

            return 'LINK'

    if 'append' in text:

        return 'APPEND'

    if any(token in text for token in ('import', 'load ', 'browse', 'drop in', 'add prop', 'avatar shapes', 'rig', 'ikea')):

        return 'IMPORT'

    if any(token in text for token in ('preview', 'thumbnail', 'render thumbnail', 'validate', 'validator', 'audit', 'check', 'report', 'summary', 'table', 'limitations', 'guide', 'documentation', 'open log')):

        return 'PREVIEW'

    if any(token in text for token in ('settings', 'preset', 'rename', 'tag', 'material', 'cleanup', 'remove', 'resize', 'compress', 'simplify', 'collider', 'theme', 'select', 'filter', 'field', 'property', 'condition')):

        return 'OTHER'

    return _sf_integrated_alias_default_category(alias, addon_name)





def _sf_integrated_category_icon(category: str, text: str = '') -> str:

    category = str(category or '').upper()

    lowered = str(text or '').lower()

    if category == 'LINK':

        return 'LINKED'

    if category == 'APPEND':

        return 'APPEND_BLEND'

    if category == 'IMPORT':

        return 'IMPORT'

    if category == 'EXPORT':

        return 'EXPORT'

    if category == 'PREVIEW':

        if 'thumbnail' in lowered or 'preview' in lowered or 'render' in lowered:

            return 'IMAGE_DATA'

        return 'VIEWZOOM'

    if category == 'HISTORY':

        return 'RECOVER_LAST'

    return 'TOOL_SETTINGS'





def _sf_integrated_skip_operator_id(op_id: str) -> bool:

    op_id = str(op_id or '').strip()

    if not op_id or '.' not in op_id:

        return True

    lowered = op_id.lower()

    # File handlers and UILists are registered classes, not useful command buttons.

    if lowered.startswith(('io_fh_', 'import_scene_fh_', 'umi_ul_', 'uhm_ul_')):

        return True

    return False





def _sf_integrated_operator_items(context, category: str) -> list[dict]:

    category = str(category or 'OTHER').upper()

    items: list[dict] = []

    seen: set[tuple[str, str]] = set()

    for record in _sf_integrated_tool_records(context):

        alias = _sf_integrated_record_alias(record)

        addon_name = _sf_integrated_record_name(record)

        runtime_entries = []

        if str(record.get('status') or '') == 'loaded':

            for cls in list(record.get('operators') or []):

                runtime_entries.append({

                    'idname': str(getattr(cls, 'bl_idname', '') or '').strip(),

                    'label': str(getattr(cls, 'bl_label', '') or '').strip(),

                    'description': str(getattr(cls, 'bl_description', '') or '').strip(),

                })

        entries = runtime_entries + _sf_integrated_static_entries(record, 'operators')

        for entry in entries:

            op_id = str(entry.get('idname') or '').strip()

            if _sf_integrated_skip_operator_id(op_id) or (alias, op_id) in seen:

                continue

            label = str(entry.get('label') or op_id).strip()

            desc = str(entry.get('description') or '').strip()

            op_category = _sf_integrated_operator_category(alias, addon_name, op_id, label, desc)

            if op_category != category:

                continue

            seen.add((alias, op_id))

            display_label = _sf_integrated_button_label(alias, addon_name, label)

            detail = desc or str((record.get('spec') or {}).get('description') or addon_name)

            keywords = _sf_integrated_haystack(alias, addon_name, op_id, label, desc)

            entry = _sf_lane_tool_entry(

                _t(display_label),

                'smart_file_suite.sfs_integrated_tools_open',

                _sf_integrated_category_icon(category, display_label + ' ' + detail),

                _t(detail),

                props={

                    'addon_alias': alias,

                    'target_kind': 'operator',

                    'target_id': op_id,

                    'target_label': _t(label),

                    'target_desc': _t(detail),

                    'is_pie_menu': False,

                },

                keywords=keywords,

            )

            entry['help_key'] = 'integrated_addon'

            entry['addon_alias'] = alias

            entry['operator_id'] = op_id

            entry['help_title'] = _sf_integrated_short_name(alias, addon_name)

            items.append(entry)

    items.sort(key=lambda item: (str(item.get('label') or '').lower(), str((item.get('props') or {}).get('target_id') or '').lower()))

    return items[:_SF_INTEGRATED_TOOL_SECTION_LIMIT]





def _sf_integrated_menu_items(context, category: str) -> list[dict]:

    category = str(category or 'OTHER').upper()

    items: list[dict] = []

    seen: set[tuple[str, str]] = set()

    for record in _sf_integrated_tool_records(context):

        alias = _sf_integrated_record_alias(record)

        addon_name = _sf_integrated_record_name(record)

        runtime_entries = []

        if str(record.get('status') or '') == 'loaded':

            for cls in list(record.get('menus') or []):

                runtime_entries.append({

                    'idname': str(getattr(cls, 'bl_idname', '') or '').strip(),

                    'label': str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').strip(),

                    'description': '',

                    'class_name': str(getattr(cls, '__name__', '') or ''),

                })

        entries = runtime_entries + _sf_integrated_static_entries(record, 'menus')

        for entry in entries:

            menu_id = str(entry.get('idname') or '').strip()

            if not menu_id or (alias, menu_id) in seen:

                continue

            label = str(entry.get('label') or menu_id).strip()

            text_blob = f'{menu_id} {label} {entry.get("class_name", "")}'

            menu_category = _sf_integrated_operator_category(alias, addon_name, menu_id, label, '')

            if menu_category != category:

                continue

            seen.add((alias, menu_id))

            display_label = _sf_integrated_button_label(alias, addon_name, label)

            is_pie = 'PIE' in text_blob.upper()

            detail = _t('Open this migrated menu from the Smart File category. The original tool is loaded only when this menu is opened. / Smart File のカテゴリ内からこの移植済みメニューを開きます。元ツールはこのメニューを開く時だけ読み込まれます。')

            entry = _sf_lane_tool_entry(

                _t(display_label),

                'smart_file_suite.sfs_integrated_tools_open',

                'PRESET' if is_pie else 'DOWNARROW_HLT',

                detail,

                props={

                    'addon_alias': alias,

                    'target_kind': 'menu',

                    'target_id': menu_id,

                    'target_label': label,

                    'target_desc': detail,

                    'is_pie_menu': bool(is_pie),

                },

                keywords=_sf_integrated_haystack(alias, addon_name, menu_id, label, 'menu preset popup'),

            )

            entry['help_key'] = 'integrated_addon'

            entry['addon_alias'] = alias

            entry['operator_id'] = menu_id

            entry['help_title'] = _sf_integrated_short_name(alias, addon_name)

            items.append(entry)

    items.sort(key=lambda item: (str(item.get('label') or '').lower(), str((item.get('props') or {}).get('target_id') or '').lower()))

    return items





def _sf_integrated_record_categories(record: dict) -> set[str]:

    categories: set[str] = set()

    alias = _sf_integrated_record_alias(record)

    addon_name = _sf_integrated_record_name(record)

    operator_entries = []

    if str(record.get('status') or '') == 'loaded':

        for cls in list(record.get('operators') or []):

            operator_entries.append({

                'idname': str(getattr(cls, 'bl_idname', '') or '').strip(),

                'label': str(getattr(cls, 'bl_label', '') or '').strip(),

                'description': str(getattr(cls, 'bl_description', '') or '').strip(),

            })

    operator_entries += _sf_integrated_static_entries(record, 'operators')

    for entry in operator_entries:

        op_id = str(entry.get('idname') or '').strip()

        if _sf_integrated_skip_operator_id(op_id):

            continue

        categories.add(_sf_integrated_operator_category(alias, addon_name, op_id, str(entry.get('label') or op_id), str(entry.get('description') or '')))

    menu_entries = []

    if str(record.get('status') or '') == 'loaded':

        for cls in list(record.get('menus') or []):

            menu_entries.append({

                'idname': str(getattr(cls, 'bl_idname', '') or '').strip(),

                'label': str(getattr(cls, 'bl_label', '') or '').strip(),

            })

    menu_entries += _sf_integrated_static_entries(record, 'menus')

    for entry in menu_entries:

        menu_id = str(entry.get('idname') or '').strip()

        if not menu_id:

            continue

        categories.add(_sf_integrated_operator_category(alias, addon_name, menu_id, str(entry.get('label') or menu_id), ''))

    if not categories:

        categories.add(_sf_integrated_alias_default_category(alias, addon_name))

    return categories





def _sf_integrated_advanced_items(context, category: str) -> list[dict]:

    category = str(category or 'OTHER').upper()

    items: list[dict] = []

    for record in _sf_integrated_tool_records(context):

        alias = _sf_integrated_record_alias(record)

        if not alias:

            continue

        status = str(record.get('status') or '')

        addon_name = _sf_integrated_record_name(record)

        has_embedded_ui = bool(record.get('proxy_panels') or record.get('deferred_panels') or record.get('preferences'))

        include = has_embedded_ui or status in {'failed', 'ready', 'unsupported_platform'}

        if not include:

            continue

        categories = _sf_integrated_record_categories(record)

        if category not in categories and not (status == 'failed' and category == 'OTHER'):

            continue

        short = _sf_integrated_short_name(alias, addon_name)

        label = f'{short}: ' + _t('Advanced Controls / 詳細コントロール')

        detail = str((record.get('spec') or {}).get('description') or addon_name)

        if status == 'failed':

            detail = _t('Open load details and migrated controls for troubleshooting. / 読み込み詳細と移植済みコントロールを開き、問題確認に使います。')

        entry = _sf_lane_tool_entry(

            label,

            'smart_file_suite.sfs_integrated_tools_open_controls',

            'MENU_PANEL' if status != 'failed' else 'ERROR',

            _t(detail),

            props={'addon_alias': alias, 'category': category},

            keywords=_sf_integrated_haystack(alias, addon_name, detail, category, 'advanced controls panels settings'),

        )

        entry['help_key'] = 'integrated_addon'

        entry['addon_alias'] = alias

        entry['help_title'] = short

        items.append(entry)

    items.sort(key=lambda item: str(item.get('label') or '').lower())

    return items





def _sf_integrated_lane_sections(context, category: str) -> list[dict]:

    category = str(category or 'OTHER').upper()

    section_meta = {

        'LINK': (_t('Integrated Link Tools / 統合リンクツール'), _t('Bundled relink, reference, library, and external path tools from the migrated subfolders. / 移植済みサブフォルダから、再リンク、参照、ライブラリ、外部パス関連の機能をまとめています。'), 'LINKED'),

        'APPEND': (_t('Integrated Append Tools / 統合アペンドツール'), _t('Bundled append and local editable ingest tools from the migrated subfolders. / 移植済みサブフォルダから、アペンドとローカル編集向け取り込み機能をまとめています。'), 'APPEND_BLEND'),

        'IMPORT': (_t('Integrated Import Tools / 統合インポートツール'), _t('Bundled format importers and project-side load helpers from the migrated subfolders. / 移植済みサブフォルダから、各形式インポーターと読込補助機能をまとめています。'), 'IMPORT'),

        'EXPORT': (_t('Integrated Export Tools / 統合エクスポートツール'), _t('Bundled format exporters, package writers, and output helpers from the migrated subfolders. / 移植済みサブフォルダから、各形式エクスポーター、パッケージ出力、書き出し補助をまとめています。'), 'EXPORT'),

        'PREVIEW': (_t('Integrated Preview Tools / 統合プレビューツール'), _t('Bundled validation, thumbnail, report, and inspection tools from the migrated subfolders. / 移植済みサブフォルダから、検証、サムネイル、レポート、点検機能をまとめています。'), 'VIEWZOOM'),

        'HISTORY': (_t('Integrated History / Restore Tools / 統合履歴/復元ツール'), _t('Bundled restore, backup, and rollback-related tools from the migrated subfolders. / 移植済みサブフォルダから、復元、バックアップ、ロールバック関連機能をまとめています。'), 'RECOVER_LAST'),

        'OTHER': (_t('Integrated Other Tools / 統合その他ツール'), _t('Bundled setup, cleanup, metadata, material, and support tools from the migrated subfolders. / 移植済みサブフォルダから、設定、整理、メタデータ、マテリアル、補助機能をまとめています。'), 'TOOL_SETTINGS'),

    }

    title, subtitle, icon = section_meta.get(category, section_meta['OTHER'])

    sections: list[dict] = []

    operator_items = _sf_integrated_operator_items(context, category)

    menu_items = _sf_integrated_menu_items(context, category)

    direct_items = list(operator_items or []) + list(menu_items or [])

    if direct_items:

        sections.append({'title': title, 'subtitle': subtitle, 'icon': icon, 'help_key': 'integrated_section', 'lane': category, 'section': title, 'items': direct_items})

    advanced_items = _sf_integrated_advanced_items(context, category)

    if advanced_items:

        sections.append({

            'title': _t('Advanced Controls / 統合詳細コントロール'),

            'subtitle': _t('Open migrated panels and settings only when a compact category button does not expose enough detail. / カテゴリ内の簡易ボタンだけでは足りない場合に、移植済みパネルと設定を開きます。'),

            'icon': 'MENU_PANEL',

            'help_key': 'integrated_advanced',

            'lane': category,

            'section': _t('Advanced Controls / 統合詳細コントロール'),

            'items': advanced_items,

        })

    return sections





def _sf_function_category_info(category: str) -> dict:

    category = str(category or 'OTHER').upper()

    info_map = {

        'LINK': {

            'title': _t('Link'),

            'subtitle': _t('Keep linked-reference checks, relink work, override checks, and linked return paths together. / リンク参照の確認、再接続、オーバーライド点検、リンク編集の戻り動線をここに集約します。'),

            'icon': 'LINKED',

            'button': _t('Open Link Tools / リンク機能を開く'),

        },

        'APPEND': {

            'title': _t('Append'),

            'subtitle': _t('Use this category for editable local ingest from a chosen source .blend. / 選択したソース .blend から編集可能なローカルデータを取り込む入口です。'),

            'icon': 'APPEND_BLEND',

            'button': _t('Open Append Tools / アペンド機能を開く'),

        },

        'IMPORT': {

            'title': _t('Import'),

            'subtitle': _t('Open container, queue, state, and project-side load helpers that are not the main append browser. / メインのアペンドブラウザー以外のコンテナ、キュー、状態、プロジェクト側の読込補助を開きます。'),

            'icon': 'IMPORT',

            'button': _t('Open Import Tools / インポート機能を開く'),

        },

        'EXPORT': {

            'title': _t('Export'),

            'subtitle': _t('Keep publish, package, bundle, and manifest output tools in one place. / 公開、パッケージ化、バンドル、マニフェスト出力をこのカテゴリにまとめます。'),

            'icon': 'EXPORT',

            'button': _t('Open Export Tools / エキスポート機能を開く'),

        },

        'PREVIEW': {

            'title': _t('Preview'),

            'subtitle': _t('Inspect checks, audits, sidecars, review boards, and display representations before committing changes. / 変更を確定する前に、確認、監査、サイドカー、レビューボード、表示表現を点検します。'),

            'icon': 'IMAGE_DATA',

            'button': _t('Open Preview Tools / プレビュー機能を開く'),

        },

        'HISTORY': {

            'title': _t('History & Restore'),

            'subtitle': _t('Use snapshots, autosaves, saved plans, and rollback helpers from one safety-focused category. / スナップショット、オートセーブ、保存済み計画、ロールバック補助を安全重視の1カテゴリにまとめます。'),

            'icon': 'RECOVER_LAST',

            'button': _t('Open History / Restore Tools / 履歴/復元機能を開く'),

        },

        'OTHER': {

            'title': _t('Other'),

            'subtitle': _t('Open guidance, search, monitoring, migrated settings, and uncategorized support tools here. / 案内、検索、監視、移設した設定、そのほかの補助機能をここにまとめます。'),

            'icon': 'MENU_PANEL',

            'button': _t('Open Other Tools / その他の機能を開く'),

        },

    }

    return dict(info_map.get(category, info_map['OTHER']))







def _sf_smart_fix_available_from_cached_state(context, prefs=None) -> bool:

    """Return draw-safe Smart Fix availability without filesystem or scene scans.



    The executing operator performs the authoritative preflight.  Panel draw only

    reads already-resident RNA strings/collections so a redraw never touches disk.

    """

    try:

        wm = getattr(context, 'window_manager', None)

        source = str(getattr(wm, 'sf_filepath', '') or getattr(bpy.data, 'filepath', '') or '').strip()

    except Exception:

        source = ''

    try:

        roots = getattr(prefs, 'library_roots', ()) if prefs is not None else ()

        has_root = any(bool(getattr(item, 'enabled', True)) for item in tuple(roots or ()))

    except Exception:

        has_root = False

    return bool(source or has_root)





def _sf_function_category_items(context, category: str) -> list[dict]:

    category = str(category or 'OTHER').upper()

    prefs = _addon_prefs(context)

    can_fix = _sf_smart_fix_available_from_cached_state(context, prefs) if category == 'HISTORY' else True



    items_map = {

        'LINK': [

            _sf_lane_tool_entry(_t('Linked Overview'), 'import_scene.sfs_pipeline_linked_overview', 'LINKED', _t('Inspect linked relationships before you relink, publish, or hand off.'), keywords='linked overview references'),

            _sf_lane_tool_entry(_t('Relink'), 'import_scene.sfs_reference_manager_open', 'LINKED', _t('Inspect linked libraries, missing paths, relink candidates, and override issues.'), keywords='reference manager relink'),

            _sf_lane_tool_entry(_t('Toolkit'), 'import_scene.sfs_reference_toolkit_open', 'ASSET_MANAGER', _t('Open the focused reference toolkit for repair workflows.'), keywords='reference toolkit repair'),

            _sf_lane_tool_entry(_t('Dependencies'), 'import_scene.sfs_dependency_cockpit_open', 'NETWORK_DRIVE', _t('Inspect dependency coverage before packaging, relinking, or publishing.'), keywords='dependency cockpit'),

            _sf_lane_tool_entry(_t('Override Audit...'), 'import_scene.sfs_override_manager_audit', 'CHECKMARK', _t('Review library override health before applying larger fixes.'), keywords='override audit'),

            _sf_lane_tool_entry(_t('Prepare Saved Upgrade'), 'import_scene.sfs_rm_prepare_upgrade_plan', 'FILE_TICK', _t('Prepare an upgrade plan for saved library references.'), keywords='prepare saved upgrade plan'),

            _sf_lane_tool_entry(_t('Apply Saved Upgrade'), 'import_scene.sfs_reference_manager_apply_saved_upgrade_plan', 'CHECKMARK', _t('Apply the prepared saved upgrade plan.'), keywords='apply saved upgrade'),

            _sf_lane_tool_entry(_t('Restore Saved Upgrade'), 'import_scene.sfs_rm_restore_upgrade_plan', 'LOOP_BACK', _t('Restore the previous saved-upgrade state.'), keywords='restore saved upgrade'),

        ],

        'APPEND': [

            _sf_lane_tool_entry(_t('Smart File...'), SF_OT_source_browser_open_folder_2.bl_idname, 'ASSET_MANAGER', _t('Choose a source and open the main browser for the current .blend workflow.'), keywords='source browser select file import'),

            _sf_lane_tool_entry(_t('Import'), SF_OT_source_browser_import.bl_idname, 'IMPORT', _t('Open the import browser for the current source file.'), keywords='import current browser append link'),

            _sf_lane_tool_entry(_t('Library'), 'import_scene.sfs_asset_reader_open', 'ASSET_MANAGER', _t('Browse indexed library content and inspect catalog-aware assets.'), keywords='asset reader library catalog'),

        ],

        'IMPORT': [

            _sf_lane_tool_entry(_t('Container Deck'), 'import_scene.sfs_container_deck_open', 'PACKAGE', _t('Browse the current container deck and related revisions.'), keywords='container deck'),

            _sf_lane_tool_entry(_t('Load Container'), 'import_scene.sfs_pipeline_load_container', 'IMPORT', _t('Load a specific container into the current scene.'), keywords='load container'),

            _sf_lane_tool_entry(_t('Load Latest Container'), 'import_scene.sfs_container_deck_load_latest', 'FILE_REFRESH', _t('Load the newest related container revision.'), keywords='load latest container revision'),

            _sf_lane_tool_entry(_t('Import MAX (.max)'), 'import_scene.sfs_max_import', 'IMPORT', _t('Open the Autodesk MAX importer. Choose one or more .max files, then set scale, image search, collection creation, and transform options in the import dialog before running the import. / Autodesk MAX インポーターを開きます。1つ以上の .max ファイルを選択し、実行前にインポートダイアログでスケール、画像検索、コレクション作成、変換設定を調整してください。'), keywords='import max max file 3ds max scene material uv armature'),

            _sf_lane_tool_entry(_t('Context Roots'), 'import_scene.sfs_context_roots_open', 'FILE_PARENT', _t('Manage context roots, environment paths, and project root behavior.'), keywords='context roots'),

            _sf_lane_tool_entry(_t('Shot Queue'), 'import_scene.sfs_shot_queue_open', 'RENDER_STILL', _t('Build or review the current shot-render queue.'), keywords='shot queue toolkit'),

        ],

        'EXPORT': [

            _sf_lane_tool_entry(_t('Container'), 'export_scene.sfs_pipeline_publish_container', 'EXPORT', _t('Publish the current work as a versioned container.'), keywords='publish container'),

            _sf_lane_tool_entry(_t('Publish'), 'export_scene.sfs_publisher_publish_asset', 'EXPORT', _t('Publish the current asset with preview, metadata, and catalog support.'), keywords='asset publisher publish'),

            _sf_lane_tool_entry(_t('Bundle'), 'import_scene.sfs_external_assets_bundle_project', 'EXPORT', _t('Create a portable external-asset bundle for the current workspace.'), keywords='bundle external assets'),

            _sf_lane_tool_entry(_t('Shot Manifest'), 'export_scene.sfs_pipeline_shot_manifest', 'FILE_TEXT', _t('Export a manifest for shot-state handoff or review.'), keywords='shot manifest export'),

        ],

        'PREVIEW': [

            _sf_lane_tool_entry(_t('Source Check...'), SF_OT_reference_manager_source_check.bl_idname, 'CHECKMARK', _t('Validate root, index, preview, metadata, and catalog readiness for the active source.'), keywords='validate source check health'),

            _sf_lane_tool_entry(_t('Audit'), 'import_scene.sfs_external_assets_audit', 'CHECKMARK', _t('Audit external assets and their readiness for safer relink and bundle work.'), keywords='external audit'),

            _sf_lane_tool_entry(_t('Verify Bundle...'), 'import_scene.sfs_external_assets_verify_bundle', 'CHECKMARK', _t('Verify an external-asset bundle before handoff.'), keywords='verify bundle'),

            _sf_lane_tool_entry(_t('Conflict Audit...'), 'import_scene.sfs_external_assets_conflict_audit', 'SORTALPHA', _t('Check for file conflicts before applying a bundle or plan.'), keywords='conflict audit'),

            _sf_lane_tool_entry(_t('Smart Fix Preview...'), SF_OT_workspace_command_fix_preview.bl_idname, 'TOOL_SETTINGS', _t('Preview smart-fix changes before anything is modified.'), keywords='smart fix preview'),

            _sf_lane_tool_entry(_t('Env Audit...'), 'import_scene.sfs_context_roots_environment_audit', 'VIEWZOOM', _t('Audit environment-root path sources and overrides.'), keywords='environment audit'),

            _sf_lane_tool_entry(_t('Handoff Audit...'), 'import_scene.sfs_project_guard_handoff_audit', 'TEXT', _t('Audit handoff readiness for the current scene and workspace.'), keywords='handoff audit'),

            _sf_lane_tool_entry(_t('Representations'), 'import_scene.sfs_representation_open', 'MOD_WIREFRAME', _t('Switch lightweight or alternate scene representations.'), keywords='representation toolkit'),

            _sf_lane_tool_entry(_t('Switch Container Representation'), 'import_scene.sfs_container_deck_switch_representation', 'ASSET_MANAGER', _t('Swap the active container representation when alternates exist.'), keywords='container representation switch'),

            _sf_lane_tool_entry(_t('Release Gate...'), 'import_scene.sfs_workspace_command_release_gate', 'CHECKMARK', _t('Review release gates before final publish or handoff.'), keywords='release gate publish'),

            _sf_lane_tool_entry(_t('Final Review...'), 'import_scene.sfs_reference_manager_final_review', 'TEXT', _t('Open the final review board for a last readiness check.'), keywords='final review board'),

            _sf_lane_tool_entry(_t('Thumbs'), 'export_scene.sfs_asset_preview_batch_preview', 'RENDER_STILL', _t('Generate preview thumbnails and sidecars in bulk.'), keywords='batch previews thumbs'),

        ],

        'HISTORY': [

            _sf_lane_tool_entry(_t('History'), SF_OT_history_open.bl_idname, 'RECOVER_LAST', _t('Open snapshots, restore points, and recent recovery context.'), keywords='history restore recovery'),

            _sf_lane_tool_entry(_t('Create Restore Point'), 'uhm.sfs_history_create_restore_point_now', 'PRESET', _t('Create a manual restore point for the current .blend before risky work.'), keywords='history restore point snapshot backup'),

            _sf_lane_tool_entry(_t('Create Autosave'), 'uhm.sfs_history_create_autosave_now', 'FILE_TICK', _t('Create an immediate autosave before risky changes.'), keywords='autosave backup'),

            _sf_lane_tool_entry(_t('Restore Selected'), 'uhm.sfs_history_restore_selected_row', 'RECOVER_LAST', _t('Restore the selected history entry from the integrated history list.'), keywords='history restore selected'),

            _sf_lane_tool_entry(_t('Delete Selected History'), 'uhm.sfs_history_delete_selected_row', 'TRASH', _t('Delete the selected history entry from the integrated history list.'), keywords='history delete selected'),

            _sf_lane_tool_entry(_t('Clear History'), 'uhm.sfs_history_clear_all', 'X', _t('Clear stored history entries for the current history view.'), keywords='history clear'),

            _sf_lane_tool_entry(_t('Open History Folder'), 'uhm.sfs_history_open_storage_folder', 'FILE_FOLDER', _t('Open the folder that stores restore points and autosaves.'), keywords='history folder storage autosave restore'),

            _sf_lane_tool_entry(_t('Export History'), 'uhm.sfs_history_export_log', 'EXPORT', _t('Export the current history list for review or support notes.'), keywords='history export report'),

            _sf_lane_tool_entry(_t('Apply Saved Plan'), 'import_scene.sfs_root_repath_apply_saved_plan', 'CHECKMARK', _t('Apply a previously saved relink plan.'), keywords='apply saved repath plan'),

            _sf_lane_tool_entry(_t('Restore Saved Plan'), 'import_scene.sfs_root_repath_restore_saved_plan', 'LOOP_BACK', _t('Restore the paths captured in the last saved relink plan.'), keywords='restore saved repath plan'),

            _sf_lane_tool_entry(_t('Run Fix'), 'import_scene.sfs_workspace_command_fix_all', 'TOOL_SETTINGS', _t('Run the bundled safe repair pack for common root and coverage blockers.'), enabled=can_fix, keywords='run fix smart fix all'),

            _sf_lane_tool_entry(_t('Project Guard'), 'import_scene.sfs_project_guard_open', 'LOCKVIEW_ON', _t('Open the project guard for locks, snapshots, and shared-edit safety.'), keywords='project guard'),

            _sf_lane_tool_entry(_t('Assembly Guard'), 'import_scene.sfs_assembly_guard_open', 'RESTRICT_SELECT_OFF', _t('Check assembly-level safety before larger merges or publishes.'), keywords='assembly guard'),

            _sf_lane_tool_entry(_t('Shot States'), 'import_scene.sfs_shot_state_open', 'CAMERA_DATA', _t('Capture, restore, or compare shot-state presets.'), keywords='shot state toolkit'),

        ],

        'OTHER': [

            _sf_lane_tool_entry(_t('Goal Home...'), SF_OT_workspace_command_goal_home.bl_idname, _sf_goal_icon(_sf_lane_goal(category)), _t('Open the guided goal hub for the current functional category.'), props={'goal': _sf_lane_goal(category)}, keywords='goal home guidance'),

            _sf_lane_tool_entry(_t('Action Palette...'), SF_OT_workspace_command_action_palette.bl_idname, 'VIEWZOOM', _t('Search across the full Smart File command list.'), keywords='action palette search'),

            _sf_lane_tool_entry(_t('Session Cockpit...'), SF_OT_workspace_command_session_cockpit.bl_idname, 'MENU_PANEL', _t('Review session guidance, profiles, health, and recommendations in one screen.'), keywords='session cockpit dashboard'),

            _sf_lane_tool_entry(_t('Watch Roots'), 'import_scene.sfs_root_watch_open', 'FILE_REFRESH', _t('Inspect or maintain watched project roots.'), keywords='root watch toolkit'),

        ],

    }

    items = list(items_map.get(category, items_map['OTHER']))

    if category == 'LINK':

        try:

            roundtrip_ticket = _sf_link_edit_current_ticket_cached(context)

        except Exception:

            roundtrip_ticket = {}

        if roundtrip_ticket and _sf_link_edit_ticket_matches_current(roundtrip_ticket, bpy.data.filepath or ''):

            items.append(_sf_lane_tool_entry(_t('Return to Parent Scene'), 'import_scene.sfs_external_assets_return_to_parent_scene', 'LOOP_BACK', _t('Jump back to the parent scene after editing a linked child file.'), keywords='return parent linked edit'))

    return items









_SF_LANE_TOOL_SECTIONS_CACHE = {}

_SF_LANE_TOOL_SECTIONS_CACHE_MAX = 16

_SF_LANE_TOOL_CATEGORIES = ('LINK', 'APPEND', 'IMPORT', 'EXPORT', 'PREVIEW', 'HISTORY', 'OTHER')





def _sf_clone_lane_tool_sections(sections: list[dict]) -> list[dict]:

    cloned = []

    for section in list(sections or []):

        if not isinstance(section, dict):

            continue

        section_copy = dict(section)

        section_copy['items'] = [dict(item) if isinstance(item, dict) else item for item in list(section.get('items') or [])]

        cloned.append(section_copy)

    return cloned





def _sf_lane_tool_sections_cache_key(context, category: str) -> tuple:

    try:

        wm = getattr(context, 'window_manager', None)

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm else ''

        goal = str(getattr(wm, 'sf_session_goal', '') or '') if wm else ''

    except Exception:

        filepath = ''

        goal = ''

    return (str(category or 'OTHER').upper(), filepath, goal, str(getattr(bpy.app.translations, 'locale', '') or ''))



def _sf_build_lane_tool_sections(context, category: str) -> list[dict]:

    """Build the full tool catalog without mutating draw-time state.



    This constructor only reads already-resident RNA and the immutable startup

    catalog.  Callers may prime the bounded cache outside Panel.draw; draw-time

    cache misses return a transient value without writing global state.

    """

    category = str(category or 'OTHER').upper()

    if category not in _SF_LANE_TOOL_CATEGORIES:

        category = 'OTHER'

    info = _sf_function_category_info(category)

    sections = [{

        'title': str(info.get('title', _t('Category')) or _t('Category')),

        'subtitle': str(info.get('subtitle', '') or ''),

        'icon': str(info.get('icon', 'MENU_PANEL') or 'MENU_PANEL'),

        'help_key': 'category',

        'lane': category,

        'items': _sf_function_category_items(context, category),

    }]

    if category != 'HISTORY':

        try:

            sections.extend(_sfsmart_lane_sections(context, category))

        except Exception:

            pass

    try:

        sections.extend(_sf_integrated_lane_sections(context, category))

    except Exception:

        pass

    return _sf_clone_lane_tool_sections(sections)





def _sf_prime_lane_tool_sections_cache(context) -> int:

    """Prime the bounded immutable UI catalog outside every draw boundary."""

    built = {}

    for category in _SF_LANE_TOOL_CATEGORIES:

        cache_key = _sf_lane_tool_sections_cache_key(context, category)

        built[cache_key] = _sf_build_lane_tool_sections(context, category)

    # Replace atomically after every category has been built.  The fixed set is

    # intentionally smaller than the hard upper bound and contains no RNA refs.

    if len(built) > _SF_LANE_TOOL_SECTIONS_CACHE_MAX:

        built = dict(list(built.items())[:_SF_LANE_TOOL_SECTIONS_CACHE_MAX])

    _SF_LANE_TOOL_SECTIONS_CACHE.clear()

    _SF_LANE_TOOL_SECTIONS_CACHE.update(built)

    return len(built)





def _sf_clear_lane_tool_sections_cache() -> None:

    _SF_LANE_TOOL_SECTIONS_CACHE.clear()





def _sf_lane_tool_sections(context, lane: str) -> list[dict]:

    """Read the immutable catalog; never mutate state from Panel.draw."""

    category = str(lane or 'OTHER').upper()

    if category not in _SF_LANE_TOOL_CATEGORIES:

        category = 'OTHER'

    cache_key = _sf_lane_tool_sections_cache_key(context, category)

    cached = _SF_LANE_TOOL_SECTIONS_CACHE.get(cache_key)

    if cached is not None:

        return _sf_clone_lane_tool_sections(cached)

    # Context-dependent keys can change after registration.  Build a transient

    # full body so first draw is never header-only, but do not populate a cache

    # or perform any runtime registration from the draw call.

    return _sf_build_lane_tool_sections(context, category)



def _sf_draw_lane_tool_button(parent, item: dict):

    row = parent.row(align=True)

    row.enabled = bool(item.get('enabled', True))

    label = str(item.get('label', '') or _t('Open'))

    icon = str(item.get('icon', 'CHECKMARK') or 'CHECKMARK')

    icon_value = 0

    icon_key = str(item.get('icon_value_key', '') or '').strip()

    if icon_key:

        try:

            icon_func = globals().get('_sfsmart_icon_id')

            if callable(icon_func):

                icon_value = int(icon_func(icon_key, 0) or 0)

        except Exception:

            icon_value = 0

    operator_id = str(item.get('operator', '') or '').strip()

    has_help = bool(str(item.get('help_key', '') or '').strip() or str(item.get('addon_alias', '') or '').strip())

    button_area = row

    help_area = None

    if has_help:

        split = row.split(factor=0.82, align=True)

        button_area = split.row(align=True)

        help_area = split.row(align=True)

        help_area.alignment = 'RIGHT'

    if not operator_id:

        button_area.enabled = False

        button_area.label(text=label, icon='ERROR')

    elif not _sf_operator_idname_registered(operator_id):

        # Do not call UILayout.operator for unknown operators.  Blender logs an

        # error every time unknown operators are drawn, and repeated draw errors

        # can hide the other Smart File categories after interrupted extension

        # reloads.  Keep the button position visible but disabled instead.

        button_area.enabled = False

        button_area.label(text=label, icon_value=icon_value) if icon_value else button_area.label(text=label, icon=icon)

    else:

        try:

            try:

                scale = 1.0

                wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)

                if bool(item.get('frameless_icon', False)) and wm is not None:

                    scale = max(1.0, min(2.2, int(getattr(wm, 'sf_smart_icon_scale', 160) or 160) / 120.0))

                button_area.scale_y = scale

            except Exception:

                pass

            if icon_value:

                try:

                    op = button_area.operator(operator_id, text=label, icon_value=icon_value, emboss=not bool(item.get('frameless_icon', False)))

                except TypeError:

                    op = button_area.operator(operator_id, text=label, icon_value=icon_value)

            else:

                op = button_area.operator(operator_id, text=label, icon=icon)

            for key, value in dict(item.get('props') or {}).items():

                _sf_safe_set_operator_property(op, key, value)

        except Exception:

            button_area.enabled = False

            button_area.label(text=label, icon='ERROR')

    if help_area is not None:

        _sf_draw_help_button(

            help_area,

            help_key=str(item.get('help_key', '') or 'tool'),

            addon_alias=str(item.get('addon_alias', '') or ''),

            operator_id=operator_id,

            title=str(item.get('help_title', '') or label),

            text='',

            icon='QUESTION',

        )

    return row







def _sf_draw_lane_tool_items(parent, section: dict, *, button_columns: int = 2):

    grid = parent.grid_flow(columns=max(1, int(button_columns or 1)), row_major=True, even_columns=True, even_rows=False, align=True)

    for item in list(section.get('items') or []):

        _sf_draw_lane_tool_button(grid.column(align=True), item)

    return grid





def _sf_tool_route_key(item: dict) -> tuple:

    try:

        operator_id = str(item.get('operator', '') or '').strip()

        props = tuple(sorted((str(k), str(v)) for k, v in dict(item.get('props') or {}).items()))

        return operator_id, props

    except Exception:

        return ('', ())





def _sf_is_repeated_utility_route(item: dict) -> bool:

    operator_id = str(item.get('operator', '') or '').strip()

    repeated = {

        SF_OT_reference_manager_source_check.bl_idname,

        SF_OT_workspace_command_action_palette.bl_idname,

        SF_OT_workspace_command_goal_home.bl_idname,

        SF_OT_history_open.bl_idname,

    }

    return operator_id in repeated





def _sf_simplify_lane_sections(sections: list[dict], *, lane: str = '') -> list[dict]:

    """Return category sections with duplicate popup/search routes removed.



    The top-level section rows are unchanged; this only reduces repeated buttons

    inside category bodies and category popups.  One global Source Check and one

    Search button are kept in Current Source, while History controls remain in

    the History section body.

    """

    del lane

    simplified = []

    seen_routes: set[tuple] = set()

    for section in list(sections or []):

        if not isinstance(section, dict):

            continue

        section_copy = dict(section)

        items = []

        for item in list(section.get('items') or []):

            if not isinstance(item, dict):

                continue

            if _sf_is_repeated_utility_route(item):

                continue

            key = _sf_tool_route_key(item)

            if key in seen_routes:

                continue

            seen_routes.add(key)

            items.append(dict(item))

        section_copy['items'] = items

        if items or str(section_copy.get('subtitle', '') or '').strip():

            simplified.append(section_copy)

    return simplified





def _sf_draw_lane_tool_section(parent, section: dict, *, button_columns: int = 2, default_open: bool = False):

    title = str(section.get('title', '') or _t('Section'))

    lane = str(section.get('lane', '') or '')

    icon_value = 0

    icon_key = str(section.get('icon_value_key', '') or '').strip()

    icon = str(section.get('icon', 'MENU_PANEL') or 'MENU_PANEL')

    if icon_key:

        try:

            icon_func = globals().get('_sfsmart_icon_id')

            if callable(icon_func):

                icon_value = int(icon_func(icon_key, 0) or 0)

        except Exception:

            icon_value = 0

    # Blender's normal UILayout operator does not allow icon_value on the small

    # section icon button, so custom preview icons are represented by the closest

    # stable Blender icon in the header while the action buttons keep their

    # detailed custom icons.

    box, body, expanded = _sf_draw_child_section_header(

        parent,

        getattr(bpy, 'context', None),

        section_key=f'sfs_lane_section_{_sf_slug_key(lane)}_{_sf_slug_key(title)}',

        title=title,

        icon=icon,

        help_key=str(section.get('help_key', '') or 'section'),

        lane=lane,

        section=str(section.get('section', '') or title),

        default_open=bool(default_open),

    )

    if expanded and body is not None:

        _sf_draw_lane_tool_items(body, section, button_columns=button_columns)

    return box







def _sf_draw_lane_tool_hub_ui(layout, context, lane: str, *, embedded: bool = False, suppress_hero: bool = False):

    payload = _sf_compact_lane_payload(context, lane)

    region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)

    if region_width <= 0:

        region_width = 720 if not embedded else 360

    use_two_columns = (region_width >= (760 if not embedded else 620)) and not embedded and not suppress_hero

    button_columns = 1 if embedded and region_width < 560 else 2



    # Keep category bodies focused.  The N-panel already has one current-source

    # command row, so embedded category sections do not repeat Search, History,

    # Goal Home, or Launcher routes.

    if not suppress_hero and not embedded:

        hero = layout.box()

        hero.label(text=str(payload.get('title', '') or _t('Category')), icon=str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL'))

        status = _sf_short_label_display(str(payload.get('status', '') or payload.get('detail', '') or ''), 110)

        if status:

            row = hero.row(align=True)

            row.enabled = False

            row.label(text=status)

        action_row = hero.row(align=True)

        op_idname = str(payload.get('operator', '') or '').strip()

        if op_idname:

            _sf_draw_operator_id_if_registered(

                action_row,

                op_idname,

                text=_t('Recommended'),

                icon=str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL'),

                props=dict(payload.get('kwargs') or {}),

            )

        _sf_draw_operator_if_registered(action_row, SF_OT_workspace_command_action_palette, text=_t('Search...'), icon='VIEWZOOM')



    sections = _sf_simplify_lane_sections(list(_sf_lane_tool_sections(context, lane) or []), lane=str(lane or ''))



    # The outer top-level section already displays the category name.  Draw the

    # first same-named section directly so opening a category does not create a

    # second title row with the same meaning.

    if suppress_hero and sections:

        first = sections[0]

        if _sf_slug_key(first.get('title', '')) == _sf_slug_key(payload.get('title', '')):

            _sf_draw_lane_tool_items(layout, first, button_columns=button_columns)

            sections = sections[1:]



    if use_two_columns:

        split = layout.split(factor=0.5)

        left = split.column(align=True)

        right = split.column(align=True)

        columns = (left, right)

        for idx, section in enumerate(sections):

            _sf_draw_lane_tool_section(columns[idx % 2], section, button_columns=button_columns, default_open=(idx == 0))

    else:

        column = layout.column(align=True)

        for idx, section in enumerate(sections):

            _sf_draw_lane_tool_section(column, section, button_columns=button_columns, default_open=(not embedded and idx == 0))







class SF_OT_workspace_command_category_tools(bpy.types.Operator):

    bl_label = 'Category Tools'

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_workspace_command_category_tools'

    bl_label = 'Category Tools'

    bl_description = 'Open a compact category hub that keeps the regrouped Smart File tools available inside the selected functional category.'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=760, min=460, max=1240, options={'HIDDEN'})



    lane: EnumProperty(

        name='Category',

        items=[

            ('LINK', 'Link', ''),

            ('APPEND', 'Append', ''),

            ('IMPORT', 'Import', ''),

            ('EXPORT', 'Export', ''),

            ('PREVIEW', 'Preview', ''),

            ('HISTORY', 'History & Restore', ''),

            ('OTHER', 'Other', ''),

        ],

        default='LINK',

        options={'HIDDEN'},

    )



    def invoke(self, context, event):

        payload = _sf_compact_lane_payload(context, self.lane)

        _sf_append_activity(context, _t('Opened category hub / カテゴリハブを開きました'), f"{self.lane} | {payload.get('title', '')}", str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL'))

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        _sf_draw_lane_tool_hub_ui(self.layout, context, self.lane, embedded=False)







class SF_OT_workspace_command_open_category_hub(bpy.types.Operator):

    bl_label = 'Open category hub'

    bl_idname = 'import_scene.sfs_workspace_command_open_category_hub'

    bl_label = 'Open category hub'

    bl_description = 'Open the regrouped Smart File category hub and keep the same top-level tools reachable inside that category.'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    lane: EnumProperty(

        name='Category',

        items=[

            ('LINK', 'Link', ''),

            ('APPEND', 'Append', ''),

            ('IMPORT', 'Import', ''),

            ('EXPORT', 'Export', ''),

            ('PREVIEW', 'Preview', ''),

            ('HISTORY', 'History & Restore', ''),

            ('OTHER', 'Other', ''),

        ],

        default='LINK',

        options={'HIDDEN'},

    )



    def execute(self, context):

        payload = _sf_compact_lane_payload(context, self.lane)

        goal = str(payload.get('goal', '') or _sf_lane_goal(self.lane)).strip()

        if goal:

            try:

                context.window_manager.sf_session_goal = goal

            except Exception:

                pass

        if _sf_is_view3d_sidebar_context(context) and _sf_set_workspace_page(context, self.lane):

            _sf_append_activity(context, _t('Opened category view / カテゴリ表示を開きました'), f"{self.lane} | {payload.get('title', '')}", str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL'))

            return {'FINISHED'}

        opened = _sf_run_operator_by_idname(SF_OT_workspace_command_category_tools.bl_idname, 'INVOKE_DEFAULT', lane=self.lane)

        if opened:

            return {'FINISHED'}

        op_idname = str(payload.get('operator', '') or '').strip()

        kwargs = dict(payload.get('kwargs') or {})

        if op_idname:

            opened = _sf_run_operator_by_idname(op_idname, 'INVOKE_DEFAULT', **kwargs)

            if not opened:

                opened = _sf_run_operator_by_idname(op_idname, **kwargs)

        if not opened:

            self.report({'WARNING'}, _t('Could not open the selected category / 選択したカテゴリを開けませんでした'))

            return {'CANCELLED'}

        _sf_append_activity(context, _t('Opened category view / カテゴリ表示を開きました'), f"{self.lane} | {payload.get('title', '')}", str(payload.get('icon', 'MENU_PANEL') or 'MENU_PANEL'))

        return {'FINISHED'}







class SF_OT_workspace_command_show_page(bpy.types.Operator):

    bl_label = 'Show Page'

    bl_idname = 'import_scene.sfs_workspace_command_show_page'

    bl_label = 'Show Page'

    bl_description = 'Switch the standard Smart File N-panel to the selected functional page without opening a popup or changing Blender UI settings.'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    page: EnumProperty(

        name='Page',

        items=[

            ('HOME', 'Home', 'Show the Smart File overview.'),

            ('LINK', 'Link', 'Show linked-reference, relink, and library path tools.'),

            ('APPEND', 'Append', 'Show append and local editable ingest tools.'),

            ('IMPORT', 'Import', 'Show importer and project-side load tools.'),

            ('EXPORT', 'Export', 'Show publish, package, bundle, and output tools.'),

            ('PREVIEW', 'Preview', 'Show checks, audits, thumbnails, and review tools.'),

            ('HISTORY', 'History & Restore', 'Show restore, autosave, rollback, and safety tools.'),

            ('OTHER', 'Other', 'Show setup, support, search, monitoring, and uncategorized tools.'),

        ],

        default='HOME',

        options={'HIDDEN'},

    )



    @classmethod

    def description(cls, context, properties):

        page = str(getattr(properties, 'page', 'HOME') or 'HOME').upper()

        info = _sf_function_category_info(page) if page != 'HOME' else {

            'title': _t('Home'),

            'subtitle': _t('Show all Smart File categories and the current source status. / すべてのSmart Fileカテゴリと現在のソース状態を表示します。'),

        }

        title = str(info.get('title', '') or '')

        detail = str(info.get('subtitle', '') or '')

        return _t(f'Function: switch the Smart File N-panel to {title}. How to use: click this tab to display that category in the same N-panel without opening an extra window. {detail} / 機能: Smart File Nパネルを「{title}」へ切り替えます。使い方: このタブをクリックすると、別ウィンドウを開かずに同じNパネル内で該当カテゴリを表示します。{detail}')



    def execute(self, context):

        page = str(self.page or 'HOME').upper()

        if not _sf_set_workspace_page(context, page):

            try:

                self.report({'WARNING'}, _t('The selected Smart File page could not be shown. / 選択したSmart Fileページを表示できませんでした。'))

            except Exception:

                pass

            return {'CANCELLED'}

        try:

            settings = _sf_integrated_import_module('settings')

            if settings is not None and hasattr(settings, 'schedule_save'):

                settings.schedule_save(context)

        except Exception:

            pass

        try:

            _sf_tag_redraw_view3d(context)

        except Exception:

            pass

        return {'FINISHED'}







_SF_NPANEL_PROP_RECOVERY_MESSAGE = ''





def _sf_workspace_props_ready_now(context=None) -> bool:

    try:

        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)

    except Exception:

        wm = None

    try:

        wm_type = getattr(bpy.types, 'WindowManager', None)

    except Exception:

        wm_type = None

    try:

        return bool(

            (wm is not None and hasattr(wm, 'sf_workspace_page'))

            or (wm_type is not None and hasattr(wm_type, 'sf_workspace_page'))

        )

    except Exception:

        return False





def _sf_repair_workspace_props(context=None) -> bool:

    """Rebuild only the lightweight N-panel properties used for drawing.



    This recovery path is invoked by the explicit Rebuild operator or normal

    add-on lifecycle code.  It must not recreate heavy CollectionProperty

    definitions during panel drawing, because stale

    PropertyGroup RNA from interrupted extension reloads can make Blender emit

    repeated missing-bl_rna errors and leave only a partial category UI.  Full

    runtime properties are registered during normal add-on registration; draw

    recovery only restores the page selector and source/status fields needed to

    keep every Smart File category visible.

    """

    global _SF_NPANEL_PROP_RECOVERY_MESSAGE

    try:

        _sf_register_minimal_workspace_props()

        try:

            _sf_seed_dynamic_enum_defaults()

        except Exception:

            pass

        try:

            settings = _sf_integrated_import_module('settings')

            if settings is not None and hasattr(settings, 'apply_all'):

                settings.apply_all(context or getattr(bpy, 'context', None))

        except Exception:

            pass

        _SF_NPANEL_PROP_RECOVERY_MESSAGE = ''

        try:

            _sf_tag_redraw_view3d(context or getattr(bpy, 'context', None))

        except Exception:

            pass

        return _sf_workspace_props_ready_now(context)

    except Exception as exc:

        _SF_NPANEL_PROP_RECOVERY_MESSAGE = str(exc)

        return False





def _sf_runtime_workspace_props_ready(context) -> bool:

    # Panel drawing is strictly read-only.  Missing RNA is repaired by the

    # explicit Rebuild button below or during normal registration.

    return _sf_workspace_props_ready_now(context)





def _sf_rna_class_ready_for_layout(cls) -> bool:

    try:

        return bool(isinstance(cls, type) and getattr(cls, 'bl_rna', None) is not None)

    except Exception:

        return False







def _sf_operator_idname_registered(op_idname: str) -> bool:

    op_idname = str(op_idname or '').strip()

    if not op_idname or '.' not in op_idname:

        return False

    prefix, suffix = op_idname.split('.', 1)

    prefix = prefix.strip()

    suffix = suffix.strip()

    if not prefix or not suffix:

        return False

    rna_id = f"{prefix.upper()}_OT_{suffix}"

    try:

        cls = getattr(bpy.types, rna_id, None)

        if isinstance(cls, type) and getattr(cls, 'bl_rna', None) is not None:

            return True

    except Exception:

        pass

    try:

        group = getattr(bpy.ops, prefix, None)

        if group is None:

            return False

        op = getattr(group, suffix, None)

        if op is None:

            return False

        get_rna = getattr(op, 'get_rna_type', None)

        if callable(get_rna):

            return get_rna() is not None

        return True

    except Exception:

        return False



def _sf_draw_operator_id_if_registered(layout, op_idname: str, *, text='', icon='NONE', depress: bool = False, props: dict | None = None, enabled: bool = True):

    op_idname = str(op_idname or '').strip()

    if op_idname and _sf_operator_idname_registered(op_idname):

        try:

            op = layout.operator(op_idname, text=text, icon=icon, depress=bool(depress))

            for key, value in dict(props or {}).items():

                _sf_safe_set_operator_property(op, key, value)

            return op

        except TypeError:

            # Older/fallback layouts may not accept depress. Retry without it.

            try:

                op = layout.operator(op_idname, text=text, icon=icon)

                for key, value in dict(props or {}).items():

                    _sf_safe_set_operator_property(op, key, value)

                return op

            except Exception:

                pass

        except Exception:

            pass

    try:

        row = layout.row(align=True)

        row.enabled = bool(enabled) and False

        row.label(text=text or op_idname or _t('Unavailable / 利用不可'), icon=icon if icon else 'ERROR')

    except Exception:

        pass

    return None









def _sf_operator_id_registered(op_idname: str) -> bool:

    return _sf_operator_idname_registered(op_idname)





def _sf_safe_set_operator_property(op, prop_name: str, value) -> bool:

    try:

        if op is None:

            return False

        setattr(op, str(prop_name or ''), value)

        return True

    except Exception:

        return False



def _sf_draw_operator_if_registered(layout, operator_cls, *, text='', icon='NONE', depress: bool = False):

    try:

        op_idname = str(getattr(operator_cls, 'bl_idname', '') or operator_cls or '').strip()

    except Exception:

        op_idname = ''

    try:

        if op_idname and _sf_operator_id_registered(op_idname):

            try:

                return layout.operator(op_idname, text=text, icon=icon, depress=bool(depress))

            except TypeError:

                return layout.operator(op_idname, text=text, icon=icon)

    except Exception:

        pass

    try:

        row = layout.row(align=True)

        row.enabled = False

        row.label(text=text or getattr(operator_cls, 'bl_label', '') or _t('Unavailable / 利用不可'), icon=icon)

    except Exception:

        pass

    return None







_SFS_GROUP_UI_STATE_KEY = 'smart_file_suite_group_ui_state_v1'





def _sf_group_state_read() -> dict:

    """Read the group UI state without creating draw-time storage."""

    try:

        state = bpy.app.driver_namespace.get(_SFS_GROUP_UI_STATE_KEY)

        return state if isinstance(state, dict) else {}

    except Exception:

        return {}





def _sf_group_state_store() -> dict:

    """Create state only from explicit Operator/property update callbacks."""

    try:

        ns = bpy.app.driver_namespace

        state = ns.get(_SFS_GROUP_UI_STATE_KEY)

        if not isinstance(state, dict):

            state = {}

            ns[_SFS_GROUP_UI_STATE_KEY] = state

        return state

    except Exception:

        return {}





def _sf_group_section_state_get(section_key: str, default: bool = False) -> bool:

    section_key = str(section_key or '').strip()

    if not section_key:

        return bool(default)

    try:

        return bool(_sf_group_state_read().get(section_key, bool(default)))

    except Exception:

        return bool(default)





def _sf_group_section_state_set(section_key: str, value: bool) -> None:

    section_key = str(section_key or '').strip()

    if not section_key:

        return

    try:

        _sf_group_state_store()[section_key] = bool(value)

        try:

            from . import settings as _sf_persist

            if hasattr(_sf_persist, 'schedule_save'):

                _sf_persist.schedule_save(getattr(bpy, 'context', None))

        except Exception:

            pass

    except Exception:

        pass





def _sf_tag_redraw_view3d(context=None) -> None:

    try:

        wm = getattr(context or bpy.context, 'window_manager', None)

        if wm is not None:

            for window in getattr(wm, 'windows', []) or []:

                screen = getattr(window, 'screen', None)

                for area in getattr(screen, 'areas', []) or []:

                    if str(getattr(area, 'type', '') or '') == 'VIEW_3D':

                        area.tag_redraw()

    except Exception:

        pass





class SF_OT_system_toggle_ui_section(bpy.types.Operator):

    bl_label = 'Toggle Section'

    bl_idname = 'smart_file_suite.ui_section_toggle'

    bl_description = 'Open or close this Smart File UI section.'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    section_key: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    display_title: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})



    @classmethod

    def description(cls, context, properties):

        title = str(getattr(properties, 'display_title', '') or '').strip()

        if title:

            return _t(f'Open or close the {title} section. / 「{title}」セクションを開閉します。')

        return _t('Open or close this Smart File UI section. / このSmart File UIセクションを開閉します。')



    def execute(self, context):

        key = str(self.section_key or '').strip()

        if not key:

            return {'CANCELLED'}

        _sf_group_section_state_set(key, not _sf_group_section_state_get(key, False))

        _sf_tag_redraw_view3d(context)

        return {'FINISHED'}





def _sf_slug_key(value: object) -> str:

    text = re.sub(r'[^0-9A-Za-z_]+', '_', str(value or '').strip()).strip('_').lower()

    return text or 'section'





def _sf_safe_icon(icon: object, fallback: str = 'TOOL_SETTINGS') -> str:

    """Return a non-empty Blender icon identifier with a stable fallback."""

    value = str(icon or '').strip()

    return value if value and value != 'NONE' else str(fallback or 'TOOL_SETTINGS')





def _sf_draw_group_section_header(parent, context, *, section_key: str, title: str, icon: str = 'MENU_PANEL', help_key: str = 'section', lane: str = '', section: str = '', addon_alias: str = '', operator_id: str = '', default_open: bool = False):

    """Draw the shared top-level foldout and return (box, body, expanded).



    Layout order matches the other Smart suites: disclosure button, one flat

    icon-bearing title button, and the compact help button.  Opened bodies do

    not repeat the same section title.

    """

    del context

    section_key = str(section_key or '').strip() or f'sfs_section_{_sf_slug_key(title)}'

    title = str(title or '').strip() or _t('Section')

    expanded = _sf_group_section_state_get(section_key, default_open)

    box = parent.box()

    try:

        box.use_property_split = False

        box.use_property_decorate = False

    except Exception:

        pass

    row = box.row(align=True)

    try:

        row.use_property_split = False

        row.use_property_decorate = False

    except Exception:

        pass



    def _toggle_button(area, *, text='', draw_icon='NONE', emboss=True, fallback_icon='TOOL_SETTINGS'):

        op = None

        resolved_icon = _sf_safe_icon(draw_icon, fallback_icon)

        try:

            op = area.operator(

                SF_OT_system_toggle_ui_section.bl_idname,

                text=text,

                icon=resolved_icon,

                emboss=emboss,

                depress=bool(expanded),

            )

        except TypeError:

            try:

                op = area.operator(

                    SF_OT_system_toggle_ui_section.bl_idname,

                    text=text,

                    icon=_sf_safe_icon(fallback_icon, 'TOOL_SETTINGS'),

                    emboss=emboss,

                )

            except Exception:

                op = None

        except Exception:

            try:

                op = area.operator(

                    SF_OT_system_toggle_ui_section.bl_idname,

                    text=text,

                    icon=_sf_safe_icon(fallback_icon, 'TOOL_SETTINGS'),

                    emboss=emboss,

                )

            except Exception:

                op = None

        if op is not None:

            _sf_safe_set_operator_property(op, 'section_key', section_key)

            _sf_safe_set_operator_property(op, 'display_title', title)

            return True

        return False



    triangle = 'TRIA_DOWN' if expanded else 'TRIA_RIGHT'

    if not _toggle_button(row, text='', draw_icon=triangle, emboss=True, fallback_icon=triangle):

        row.label(text='', icon=triangle)



    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.

    title_icon = _sf_safe_icon(icon, 'TOOL_SETTINGS')

    if not _toggle_button(row, text=title, draw_icon=title_icon, emboss=False, fallback_icon='TOOL_SETTINGS'):

        try:

            row.label(text=title, icon=title_icon)

        except Exception:

            try:

                row.label(text=title, icon='TOOL_SETTINGS')

            except Exception:

                row.label(text=title)



    try:

        row.separator(factor=0.35)

    except Exception:

        pass

    help_row = row.row(align=True)

    help_row.scale_x = 0.82

    _sf_draw_help_button(

        help_row,

        help_key=str(help_key or 'section'),

        lane=str(lane or ''),

        section=str(section or title),

        addon_alias=str(addon_alias or ''),

        operator_id=str(operator_id or ''),

        title=title,

        text='',

        icon='QUESTION',

    )

    if not expanded:

        return box, None, False



    # Keep the body inside the same box.  Every top-level section is drawn in an

    # independent sibling slot, so expanding one section cannot indent the next.

    body = box.column(align=True)

    try:

        body.use_property_split = False

        body.use_property_decorate = False

    except Exception:

        pass

    return box, body, True





def _sf_draw_child_section_header(parent, context, *, section_key: str, title: str, icon: str = 'MENU_PANEL', help_key: str = 'section', lane: str = '', section: str = '', addon_alias: str = '', operator_id: str = '', default_open: bool = False):

    """Use native panel storage only in panels, and explicit state in popups."""

    section_key = str(section_key or '').strip() or f'sfs_child_{_sf_slug_key(title)}'

    section_key = f'sfs_child_{_sf_slug_key(section_key)}'

    title = str(title or '').strip() or _t('Section')



    # Popup blocks have no Panel runtime for UILayout.panel's persistent state.

    # Calling it there can crash in Blender's native panel_prop implementation.

    if getattr(context, 'region_popup', None) is not None:

        return _sf_draw_group_section_header(

            parent, context, section_key=section_key, title=title, icon=icon,

            help_key=help_key, lane=lane, section=section, addon_alias=addon_alias,

            operator_id=operator_id, default_open=default_open,

        )



    panel_fn = getattr(parent, 'panel', None)

    if callable(panel_fn):

        try:

            try:

                header, panel = panel_fn(section_key, default_closed=not bool(default_open))

            except TypeError:

                header, panel = panel_fn(section_key)

            if header is not None:

                try:

                    header.label(text=title, icon=str(icon or 'MENU_PANEL'))

                except TypeError:

                    header.label(text=title)

                help_area = header.row(align=True)

                try:

                    help_area.alignment = 'RIGHT'

                    help_area.scale_x = 0.82

                    help_area.scale_y = 1.0

                except Exception:

                    pass

                _sf_draw_help_button(

                    help_area,

                    help_key=str(help_key or 'section'),

                    lane=str(lane or ''),

                    section=str(section or title),

                    addon_alias=str(addon_alias or ''),

                    operator_id=str(operator_id or ''),

                    title=title,

                    text='',

                    icon='QUESTION',

                )

            if panel is None:

                return header, None, False

            body = panel.column(align=True)

            try:

                body.use_property_split = False

                body.use_property_decorate = False

            except Exception:

                pass

            return header, body, True

        except Exception:

            pass



    # Blender 5.1 provides UILayout.panel.  If an unexpected host omits it,

    # keep the controls usable without reintroducing a custom disclosure row.

    box = parent.box()

    row = box.row(align=True)

    try:

        row.label(text=title, icon=str(icon or 'MENU_PANEL'))

    except TypeError:

        row.label(text=title)

    help_area = row.row(align=True)

    try:

        help_area.alignment = 'RIGHT'

        help_area.scale_x = 0.82

        help_area.scale_y = 1.0

    except Exception:

        pass

    _sf_draw_help_button(

        help_area,

        help_key=str(help_key or 'section'),

        lane=str(lane or ''),

        section=str(section or title),

        addon_alias=str(addon_alias or ''),

        operator_id=str(operator_id or ''),

        title=title,

        text='',

        icon='QUESTION',

    )

    body = box.column(align=True)

    try:

        body.use_property_split = False

        body.use_property_decorate = False

    except Exception:

        pass

    return box, body, True



def _sf_draw_help_button(layout, *, help_key: str = '', lane: str = '', section: str = '', addon_alias: str = '', operator_id: str = '', title: str = '', text: str | None = None, icon: str = 'QUESTION'):

    """Draw a compact icon-only help button using Blender's standard QUESTION icon."""

    try:

        layout.scale_x = 0.82

        layout.scale_y = 1.0

    except Exception:

        pass

    op_cls = globals().get('SF_OT_system_open_help')

    op_idname = str(getattr(op_cls, 'bl_idname', '') or '').strip()

    op = None

    try:

        if op_idname and _sf_operator_idname_registered(op_idname):

            op = layout.operator(op_idname, text='', icon='QUESTION', emboss=True)

        else:

            row = layout.row(align=True)

            row.enabled = False

            row.label(text='', icon='QUESTION')

    except Exception:

        try:

            row = layout.row(align=True)

            row.enabled = False

            row.label(text='', icon='QUESTION')

        except Exception:

            pass

        return None

    _sf_safe_set_operator_property(op, 'help_key', str(help_key or ''))

    _sf_safe_set_operator_property(op, 'lane', str(lane or ''))

    _sf_safe_set_operator_property(op, 'section', str(section or ''))

    _sf_safe_set_operator_property(op, 'addon_alias', str(addon_alias or ''))

    _sf_safe_set_operator_property(op, 'operator_id', str(operator_id or ''))

    _sf_safe_set_operator_property(op, 'display_title', str(title or ''))

    return op



def _sf_draw_workspace_props_missing_recovery_ui(layout, context):

    layout.use_property_split = False

    layout.use_property_decorate = False

    box = layout.box()

    box.alert = True

    box.label(text=_t('Smart File UI settings are unavailable / Smart File UI設定を利用できません'))

    box.label(text=_t('Use Rebuild N-panel UI to repair the missing settings. / 「NパネルUIを再構築」で不足設定を修復してください。'), icon='BLANK1')

    row = box.row(align=True)

    _sf_draw_operator_if_registered(row, SF_OT_system_rebuild_n_panel_ui, text=_t('Rebuild N-panel UI'), icon='FILE_REFRESH')

    _sf_draw_operator_if_registered(row, SF_OT_workspace_command_launcher, text=_t('Open Launcher / ランチャーを開く'), icon='ASSET_MANAGER')

    err = str(_SF_NPANEL_PROP_RECOVERY_MESSAGE or '').strip()

    if err:

        err_box = box.box()

        err_box.label(text=_t('Last recovery message / 最後の復旧メッセージ'), icon='CONSOLE')

        err_box.label(text=_sf_short_label_display(err, 96), icon='BLANK1')



    lanes = layout.box()

    lanes.label(text=_t('Available Smart File categories / 使用できるSmart Fileカテゴリ'), icon='MENU_PANEL')

    for lane, label, icon in (

        ('LINK', _t('Link'), 'LINKED'),

        ('APPEND', _t('Append'), 'APPEND_BLEND'),

        ('IMPORT', _t('Import'), 'IMPORT'),

        ('EXPORT', _t('Export'), 'EXPORT'),

        ('PREVIEW', _t('Preview'), 'IMAGE_DATA'),

        ('HISTORY', _t('History & Restore'), 'RECOVER_LAST'),

        ('OTHER', _t('Other'), 'MENU_PANEL'),

    ):

        lane_row = lanes.row(align=True)

        op = _sf_draw_operator_if_registered(lane_row, SF_OT_workspace_command_open_category_hub, text=label, icon=icon)

        if op is not None:

            try:

                _sf_safe_set_operator_property(op, 'lane', lane)

            except Exception:

                pass







def _sf_draw_launcher_dashboard_ui(layout, context, *, include_hero: bool = False):

    if not _sf_runtime_workspace_props_ready(context):

        _sf_draw_workspace_props_missing_recovery_ui(layout, context)

        return

    ctx_data = _sf_compact_launcher_context(context)

    prefs = ctx_data.get('prefs')

    filepath = _norm_path(ctx_data.get('filepath', '') or '')

    has_source = bool(ctx_data.get('has_source'))

    source_info = dict(ctx_data.get('source_info') or {})

    health_score = int(ctx_data.get('health_score', 0) or 0)

    health_label = str(ctx_data.get('health_label', '') or '')

    actions = list(ctx_data.get('actions') or [])



    try:

        roundtrip_ticket = _sf_link_edit_current_ticket_cached(context)

    except Exception:

        roundtrip_ticket = {}

    if roundtrip_ticket and _sf_link_edit_ticket_matches_current(roundtrip_ticket, bpy.data.filepath or ''):

        rt_box = layout.box()

        rt_box.label(text='Linked Edit Return', icon='LOOP_BACK')

        rt_box.label(text=_sf_short_label_display(os.path.basename(str(roundtrip_ticket.get('parent_blend', '') or '')) or _t('Parent Scene'), 40), icon='FILE_BLEND', translate=False)

        row = rt_box.row(align=True)

        _sf_draw_operator_id_if_registered(row, 'import_scene.sfs_external_assets_return_to_parent_scene', text=_t('Return to Parent Scene'), icon='LOOP_BACK')

        _sf_draw_operator_id_if_registered(row, 'import_scene.sfs_external_assets_audit', text=_t('Audit'), icon='CHECKMARK')



    hero = layout.box()

    hero_header = hero.row(align=True)

    hero_header.label(text='Smart File', icon='ASSET_MANAGER')

    help_row = hero_header.row(align=True)

    help_row.alignment = 'RIGHT'

    help_row.scale_x = 0.82

    help_row.scale_y = 1.0

    _sf_draw_help_button(help_row, help_key='home', title='Smart File', text='', icon='QUESTION')

    hero.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

    if has_source:

        hero.label(text=_sf_short_label_display(os.path.basename(filepath), 36), icon='FILE_BLEND', translate=False)

        row = hero.row(align=True)

        row.enabled = False

        row.label(text=_sf_short_path_display(filepath, 76), icon='FILE_FOLDER', translate=False)

    else:

        hero.label(text=_t('No source selected'))

    if actions:

        lead = actions[0]

        hero.label(text=_sf_short_label_display(f"{_t('Next')}: {lead.get('title', '')}", 72), icon=str(lead.get('icon', 'FORWARD') or 'FORWARD'))



    hero_actions = hero.row(align=True)

    hero_actions.operator('import_scene.sfs_refresh_compact_launcher_context', text=_t('Refresh Status / 状態更新'), icon='FILE_REFRESH')

    hero_actions.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    hero_actions.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

    hero_tools = hero.row(align=True)

    hero_tools.operator(SF_OT_workspace_command_action_palette.bl_idname, text=_t('Action Palette'), icon='VIEWZOOM')

    hero_tools.operator(SF_OT_history_open.bl_idname, text=_t('Open'), icon='RECOVER_LAST')



    _sf_draw_compact_quick_sources(layout, context, prefs)



    region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)

    grid_columns = 2 if include_hero or region_width >= 620 else 1

    grid = layout.grid_flow(columns=grid_columns, row_major=True, even_columns=True, even_rows=False, align=True)

    for lane in ('LINK', 'APPEND', 'IMPORT', 'EXPORT', 'PREVIEW', 'HISTORY', 'OTHER'):

        try:

            _sf_draw_compact_lane_card(grid, _sf_compact_lane_payload(context, lane, ctx_data))

        except Exception as exc:

            fallback = grid.column(align=True).box()

            info = _sf_function_category_info(lane)

            fallback.alert = True

            fallback.label(text=str(info.get('title', lane) or lane), icon=str(info.get('icon', 'ERROR') or 'ERROR'))

            fallback.label(text=_sf_short_label_display(_sf_error_text(exc), 72), icon='ERROR')



    if include_hero or _sf_has_last_quick_action_result(context):

        _sf_draw_last_quick_action_card(

            layout,

            context,

            compact=True,

            title='Latest Result',

            subtitle='Keep the newest guided outcome visible here so you can continue from the same place after closing the launcher.',

        )











def _sf_always_on_target_owner(context, target: str):

    target = str(target or '').strip().upper()

    if target == 'PREFS':

        return _addon_prefs(context)

    scene = getattr(context, 'scene', None)

    if target == 'SCENE_TEXMGR':

        return getattr(scene, 'texmgr_settings', None) if scene is not None else None

    if target == 'SCENE_REPORTER':

        return getattr(scene, 'reporter_settings', None) if scene is not None else None

    return None





def _sf_property_description(owner, prop_name: str) -> str:

    try:

        rna = getattr(owner, 'bl_rna', None)

        prop = getattr(getattr(rna, 'properties', None), 'get', lambda _name: None)(str(prop_name or ''))

        if prop is not None:

            return str(getattr(prop, 'description', '') or '')

    except Exception:

        pass

    return ''





class SF_OT_system_rebuild_n_panel_ui(bpy.types.Operator):

    bl_label = 'Rebuild N-panel UI'

    bl_idname = 'import_scene.sfs_system_rebuild_n_panel_ui'

    bl_label = 'Rebuild N-panel UI'

    bl_description = 'Rebuild the Smart File N-panel runtime properties when the tab is visible but its UI settings were not ready after an interrupted reload.'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    @classmethod

    def description(cls, context, properties):

        return _t('Function: restores the lightweight WindowManager settings required by the Smart File N-panel without changing theme, transparency, or workspace tools. How to use: click this only when the Smart File tab is visible but the UI is blank or still initializing. / 機能: テーマ、透明度、ワークスペースツールを変更せず、Smart File Nパネルに必要な軽量WindowManager設定を復元します。使い方: Smart Fileタブは見えるのにUIが空白、または初期化中の時だけクリックします。')



    def execute(self, context):

        if _sf_repair_workspace_props(context):

            try:

                self.report({'INFO'}, _t('Smart File N-panel UI was rebuilt.'))

            except Exception:

                pass

            return {'FINISHED'}

        try:

            self.report({'WARNING'}, _t('Smart File N-panel UI could not be rebuilt.'))

        except Exception:

            pass

        return {'CANCELLED'}





class SF_OT_refresh_compact_launcher_context(bpy.types.Operator):

    bl_label = 'Refresh Status'

    bl_idname = 'import_scene.sfs_refresh_compact_launcher_context'

    bl_description = 'Refresh source existence, index, health, and recommendation data shown in the Smart File N-panel.'

    bl_options = {'INTERNAL'}



    def execute(self, context):

        try:

            _sf_refresh_compact_launcher_context(context)

            _sf_tag_redraw_view3d(context)

            return {'FINISHED'}

        except Exception as exc:

            self.report({'ERROR'}, _sf_error_text(exc))

            return {'CANCELLED'}





class SF_OT_system_toggle_always_on_setting(bpy.types.Operator):

    bl_label = 'Toggle Always-on Setting'

    bl_idname = 'import_scene.sfs_system_toggle_always_on_setting'

    bl_label = 'Toggle Always-on Setting'

    bl_description = 'Switch this always-on feature on or off.'

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    target: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    prop_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    display_label: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    load_alias: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    tooltip_text: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})



    @classmethod

    def description(cls, context, properties):

        tooltip = str(getattr(properties, 'tooltip_text', '') or '').strip()

        if tooltip:

            return _t(tooltip)

        label = str(getattr(properties, 'display_label', '') or '').strip() or _t('Always-on Setting')

        target = str(getattr(properties, 'target', '') or '')

        prop_name = str(getattr(properties, 'prop_name', '') or '')

        owner = _sf_always_on_target_owner(context, target)

        desc = _sf_property_description(owner, prop_name) if owner is not None else ''

        tail = _t('Click to switch this item between enabled and disabled.')

        return f'{label}: {desc} {tail}' if desc else f'{label}: {tail}'



    def execute(self, context):

        owner = _sf_always_on_target_owner(context, self.target)

        # An unloaded tool's row reads "Disabled", so that press always means ON,

        # even when loading restores a saved ON value first.

        turn_on_after_load = owner is None

        if owner is None and str(self.load_alias or '').strip():

            loader = _sf_integrated_import_module('loader')

            load_fn = getattr(loader, 'load_alias', None) if loader is not None else None

            if callable(load_fn):

                try:

                    load_fn(str(self.load_alias or '').strip())

                except Exception:

                    pass

            try:

                settings = _sf_integrated_import_module('settings')

                if settings is not None and hasattr(settings, 'apply_all'):

                    settings.apply_all(context)

            except Exception:

                pass

            owner = _sf_always_on_target_owner(context, self.target)

        prop_name = str(self.prop_name or '').strip()

        if owner is None or not prop_name or not hasattr(owner, prop_name):

            self.report({'WARNING'}, _t('The selected always-on setting is unavailable.'))

            return {'CANCELLED'}

        try:

            setattr(owner, prop_name, True if turn_on_after_load else not bool(getattr(owner, prop_name)))

        except Exception as exc:

            self.report({'WARNING'}, f"{_t('The setting could not be changed.')}: {exc}")

            return {'CANCELLED'}

        try:

            settings = _sf_integrated_import_module('settings')

            if settings is not None and prop_name != 'enable_npanel_settings_keeper':

                # The keeper property's own update callback performs its one

                # mandatory boundary save. Every other switch joins the shared

                # quiet-period batch instead of writing synchronously here.

                schedule = getattr(settings, 'schedule_save', None)

                if callable(schedule):

                    schedule(context)

        except Exception:

            pass

        _sf_tag_redraw_view3d(context)

        return {'FINISHED'}





def _sf_toggle_icon(value: bool) -> str:

    return 'CHECKBOX_HLT' if bool(value) else 'CHECKBOX_DEHLT'





def _sf_tag_redraw_view3d(context=None) -> None:

    try:

        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)

        for window in getattr(wm, 'windows', ()) or ():

            screen = getattr(window, 'screen', None)

            for area in getattr(screen, 'areas', ()) or ():

                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':

                    area.tag_redraw()

    except Exception:

        pass





def _sf_always_on_state_text(value) -> str:

    # 常時の行の状態の文字。訳が付く言語（日本語など）は今までどおり Enabled／Disabled の訳、

    # 訳が付かない時（英語）は右の欄に収まる On／Off にする。

    msgid = 'Enabled' if value else 'Disabled'

    text = _t(msgid)

    if text == msgid:

        return 'On' if value else 'Off'

    return text





def _sf_draw_toggle_prop(parent, owner, prop_name: str, label: str, *, target: str = 'PREFS', load_alias: str = '', tooltip: str = '', icon_true: str = 'CHECKBOX_HLT', icon_false: str = 'CHECKBOX_DEHLT') -> bool:

    available = owner is not None and hasattr(owner, prop_name)

    try:

        value = bool(getattr(owner, prop_name)) if available else False

    except Exception:

        value = False

    row = parent.row(align=True)

    row.scale_y = 0.95

    split = row.split(factor=0.72, align=True)

    left = split.row(align=True)

    left.alignment = 'LEFT'

    left.label(text=_t(label))

    right = split.row(align=True)

    right.alignment = 'RIGHT'

    right.use_property_split = False

    right.use_property_decorate = False



    # Always prefer Blender's native BoolProperty button.  The active/blue theme

    # overlay is then owned by RNA state instead of an operator's transient

    # depress flag, so enabled rows remain blue after redraws and file changes.

    if available:

        try:

            right.row(align=True).prop(

                owner,

                prop_name,

                text=_sf_always_on_state_text(value),

                toggle=True,

                icon=icon_true if value else icon_false,

                emboss=True,

            )

            return True

        except Exception:

            pass



    # Fallback only for lazy scene tools before their PropertyGroup is registered.

    try:

        op = _sf_draw_operator_if_registered(

            right.row(align=True),

            SF_OT_system_toggle_always_on_setting,

            text=_sf_always_on_state_text(value),

            icon=icon_true if value else icon_false,

            depress=bool(value),

        )

        _sf_safe_set_operator_property(op, 'target', str(target or 'PREFS'))

        _sf_safe_set_operator_property(op, 'prop_name', str(prop_name or ''))

        _sf_safe_set_operator_property(op, 'display_label', _t(label))

        _sf_safe_set_operator_property(op, 'load_alias', str(load_alias or ''))

        _sf_safe_set_operator_property(op, 'tooltip_text', _t(tooltip or ''))

        if not available and not load_alias:

            right.enabled = False

    except Exception:

        right.enabled = False

        right.label(text=_sf_always_on_state_text(False), icon='CHECKBOX_DEHLT')

    return available or bool(load_alias)





def _sf_draw_always_on_switches_body(layout, context):

    """Draw the native Always-on Toggles child Panel body without custom foldout state."""

    wm = getattr(context, 'window_manager', None)

    prefs = _addon_prefs(context)

    scene = getattr(context, 'scene', None)

    col = layout.column(align=True)

    col.use_property_split = False

    col.use_property_decorate = False

    drew = False

    if prefs is not None:

        rows = (

            ('enable_npanel_settings_keeper', 'N-panel State Save', 'When enabled, every persistent Smart File N-panel setting is saved after its change event and restored after restart or scene change. Turning it off records OFF once, removes the persistence handlers and subscriptions, and blocks every later settings writer until it is enabled again.'),

            ('enable_compatibility_guards', 'Compatibility Guards', 'Keeps Smart File compatibility guards available for known Smart toolset startup, missing-operator, handler, and RNA-drawing issues. It now patches once and on future imports instead of using a polling timer; disable only while debugging those external add-ons.'),

            ('enable_automatic_proxy_cleanup', 'Automatic Proxy Cleanup', 'Checks broken Smart File proxy metadata from explicit load/save callbacks and a periodic maintenance timer. Enable only while maintaining proxy-heavy files; disabling removes all owned callbacks and the timer.'),

            ('enable_restore_snapshots', 'Optional Timed Restore Points', 'Allows optional timed restore-point creation. Manual Restore Point remains the primary rollback workflow; enable this only when timed helper checkpoints are needed.'),

            ('enable_autosave', 'Rolling Autosave', 'Creates rolling autosave backups in the integrated history system. Enable it when periodic backup files are needed; disable it to stop autosave work completely.'),

            ('rm_auto_check_on_load', 'Reference Load Check', 'Checks linked libraries when a Blender file is loaded. Enable it when missing or outdated references should be checked automatically on load.'),

            ('rm_auto_periodic', 'Reference Periodic Check', 'Checks linked references periodically while Blender remains open. Enable it only when continuous reference monitoring is needed.'),

        )

        for index, (prop_name, label, tooltip) in enumerate(rows):

            drew = _sf_draw_toggle_prop(col, prefs, prop_name, label, tooltip=tooltip) or drew

            if index == 0:

                try:

                    col.separator(factor=0.5)

                except Exception:

                    col.separator()



    tex_settings = getattr(scene, 'texmgr_settings', None) if scene is not None else None

    drew = _sf_draw_toggle_prop(

        col,

        tex_settings,

        'auto_refresh_on_file_load',

        'Texture File-load Refresh',

        target='SCENE_TEXMGR',

        load_alias='texture_manager',

        tooltip='Refreshes Texture Manager data when a Blender file is loaded. Enable it when texture paths should be checked automatically after file load; disabled keeps Texture Manager inactive until opened.',

    ) or drew

    reporter_settings = getattr(scene, 'reporter_settings', None) if scene is not None else None

    drew = _sf_draw_toggle_prop(

        col,

        reporter_settings,

        'labels_enabled',

        'Viewport Labels',

        target='SCENE_REPORTER',

        load_alias='object_reporter',

        tooltip='Draws Object Reporter labels in the 3D View overlay. Enable it only when live viewport labels are needed; disabled removes the draw handler and keeps it inactive.',

    ) or drew



    try:

        package_name = str(__package__ or '').strip()

        module_name = f'{package_name}.feature_toggle' if package_name else 'feature_toggle'

        _sf_feature_toggle = _sf_rm_sys.modules.get(module_name)

        draw_all = getattr(_sf_feature_toggle, 'draw_all_toggles', None) if _sf_feature_toggle is not None else None

        if callable(draw_all):

            drew = bool(draw_all(col, context, compact=True, show_empty=False)) or drew

    except Exception:

        pass



    if not drew:

        row = col.row(align=True)

        row.enabled = False

        row.label(text=_t('No always-on feature is currently available.'))

    return drew





def _sf_draw_always_on_section(layout, context):

    """Draw Always-on Toggles as the first standard top-level section."""

    box, body, expanded = _sf_draw_group_section_header(

        layout,

        context,

        section_key='sfs_section_always_on_toggles',

        title=_t('Always-on Toggles'),

        icon='TIME',

        help_key='always_on',

        section=_t('Always-on Toggles'),

        default_open=False,

    )

    if expanded and body is not None:

        _sf_draw_always_on_switches_body(body, context)

    return box





def _sf_draw_workspace_page_selector(layout, context, current_page: str):

    """Draw every Smart File category explicitly.



    The previous enum-tab fallback could degrade into a single visible enum value

    after Blender extension hot reloads, which made the N-panel look as if only

    the current page, often Other, existed.  These are plain operator buttons, so

    every category is visible regardless of enum drawing state.

    """

    current_page = str(current_page or 'HOME').upper()

    box = layout.box()

    region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)

    compact = bool(region_width and region_width < 620)

    # Four columns keeps all eight categories visible as two stable rows in the N-panel.

    # This avoids Blender drawing only the active enum value, such as Other, in narrow

    # or partially recovered Sidebar layouts.

    grid = box.grid_flow(columns=4, row_major=True, even_columns=True, even_rows=False, align=True)

    for page, label, _description, icon, _order in _SF_NPANEL_PAGE_ITEMS:

        label_text = '' if compact else _t(label)

        col = grid.column(align=True)

        if _sf_operator_idname_registered(getattr(globals().get('SF_OT_workspace_command_show_page'), 'bl_idname', '')):

            try:

                op = col.operator(SF_OT_workspace_command_show_page.bl_idname, text=label_text, icon=icon, depress=(str(page).upper() == current_page))

            except TypeError:

                op = col.operator(SF_OT_workspace_command_show_page.bl_idname, text=label_text, icon=icon)

            _sf_safe_set_operator_property(op, 'page', str(page))

        else:

            row = col.row(align=True)

            row.enabled = False

            row.label(text=label_text or _t(label), icon=icon)

    return box







def _sf_draw_current_source_section(layout, context):

    ctx_data = _sf_compact_launcher_context(context)

    filepath = _norm_path(ctx_data.get('filepath', '') or '')

    has_source = bool(ctx_data.get('has_source'))

    health_score = int(ctx_data.get('health_score', 0) or 0)

    health_label = str(ctx_data.get('health_label', '') or '')

    actions = list(ctx_data.get('actions') or [])

    box, body, expanded = _sf_draw_group_section_header(

        layout,

        context,

        section_key='sfs_section_current_source',

        title=_t('Current Source'),

        icon='FILE_BLEND',

        help_key='home',

        section=_t('Current Source'),

        default_open=True,

    )

    if not expanded or body is None:

        return box

    body.label(text=f"{_t('Health Score')}: {health_score}/100 · {health_label}", icon='CHECKMARK' if health_score >= 65 else 'NONE')

    if has_source:

        body.label(text=_sf_short_label_display(os.path.basename(filepath), 64), icon='FILE_BLEND', translate=False)

        row = body.row(align=True)

        row.enabled = False

        row.label(text=_sf_short_path_display(filepath, 92), icon='FILE_FOLDER', translate=False)

    else:

        body.label(text=_t('No source selected'))

    if actions:

        lead = actions[0]

        body.label(text=_sf_short_label_display(f"{_t('Next')}: {lead.get('title', '')}", 92), icon=str(lead.get('icon', 'FORWARD') or 'FORWARD'))

    primary = body.grid_flow(row_major=True, columns=2, even_columns=True, align=True)

    primary.operator('import_scene.sfs_refresh_compact_launcher_context', text=_t('Refresh Status / 状態更新'), icon='FILE_REFRESH')

    primary.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

    _sf_draw_operator_if_registered(primary, SF_OT_reference_manager_source_check, text=_t('Source Check...'), icon='CHECKMARK')

    _sf_draw_operator_if_registered(primary, SF_OT_workspace_command_action_palette, text=_t('Search...'), icon='VIEWZOOM')

    return box







# -----------------------------------------------------------------------------

# Undo load diagnostic (explicit operator work only; Panel.draw reads cache)

# -----------------------------------------------------------------------------



_SF_UNDO_DIAGNOSTIC_CACHE_LIMIT = 8

_SF_UNDO_DIAGNOSTIC_CACHE = {}

_SF_UNDO_DIAGNOSTIC_ID_COLLECTIONS = (

    'objects', 'meshes', 'curves', 'metaballs', 'materials', 'textures',

    'images', 'node_groups', 'actions', 'armatures', 'cameras', 'lights',

    'lattices', 'worlds', 'collections', 'grease_pencils', 'movieclips',

    'masks', 'sounds', 'fonts', 'texts', 'volumes', 'pointclouds',

    'hair_curves',

)





def _sf_undo_diagnostic_context_key(context) -> tuple[int, int]:

    wm = getattr(context, 'window_manager', None) if context is not None else None

    scene = getattr(context, 'scene', None) if context is not None else None



    def _pointer(value) -> int:

        if value is None:

            return 0

        try:

            return int(value.as_pointer())

        except Exception:

            return int(id(value))



    # A file/scene load gets a new Scene identity, so stale results from the

    # previous file are not shown even though Blender retains one WindowManager.

    return (_pointer(wm), _pointer(scene))





def _sf_undo_diagnostic_snapshot(context) -> dict:

    """Return a detached primitive snapshot; never scan Blender data from draw."""

    key = _sf_undo_diagnostic_context_key(context)

    value = _SF_UNDO_DIAGNOSTIC_CACHE.get(key)

    return dict(value) if isinstance(value, dict) else {}





def _sf_undo_diagnostic_store(context, **updates) -> dict:

    key = _sf_undo_diagnostic_context_key(context)

    previous = dict(_SF_UNDO_DIAGNOSTIC_CACHE.pop(key, {}) or {})

    previous.update(updates)

    # Keep the bounded cache primitive-only and cap diagnostic text even when a

    # Blender exception contains an unexpectedly long path or report payload.

    previous['error'] = str(previous.get('error', '') or '')[:512]

    top_objects = []

    for item in tuple(previous.get('top_objects') or ())[:5]:

        try:

            name, vertex_count = item

            top_objects.append((str(name)[:128], max(0, int(vertex_count))))

        except Exception:

            continue

    if 'top_objects' in previous:

        previous['top_objects'] = tuple(top_objects)

    # The cache stores primitives/tuples only; no RNA reference survives an event.

    _SF_UNDO_DIAGNOSTIC_CACHE[key] = previous

    while len(_SF_UNDO_DIAGNOSTIC_CACHE) > _SF_UNDO_DIAGNOSTIC_CACHE_LIMIT:

        oldest_key = next(iter(_SF_UNDO_DIAGNOSTIC_CACHE))

        _SF_UNDO_DIAGNOSTIC_CACHE.pop(oldest_key, None)

    return dict(previous)





def _sf_undo_diagnostic_clear_cache() -> None:

    _SF_UNDO_DIAGNOSTIC_CACHE.clear()





def _sf_undo_diagnostic_collection_length(name: str) -> int:

    try:

        return int(len(getattr(bpy.data, name)))

    except Exception:

        return 0





def _sf_undo_diagnostic_packed_image_bytes() -> int:

    total = 0

    try:

        images = getattr(bpy.data, 'images', ()) or ()

    except Exception:

        images = ()

    for image in images:

        try:

            packed_files = tuple(getattr(image, 'packed_files', ()) or ())

        except Exception:

            packed_files = ()

        if packed_files:

            for packed in packed_files:

                try:

                    total += max(0, int(getattr(packed, 'size', 0) or 0))

                except Exception:

                    pass

            continue

        try:

            packed = getattr(image, 'packed_file', None)

            if packed is not None:

                total += max(0, int(getattr(packed, 'size', 0) or 0))

        except Exception:

            pass

    return int(total)





def _sf_undo_diagnostic_orphan_count() -> int:

    total = 0

    for collection_name in _SF_UNDO_DIAGNOSTIC_ID_COLLECTIONS:

        try:

            values = getattr(bpy.data, collection_name, ())

        except Exception:

            continue

        try:

            iterator = iter(values)

        except Exception:

            continue

        for datablock in iterator:

            try:

                if int(getattr(datablock, 'users', 0) or 0) == 0:

                    total += 1

            except Exception:

                pass

    return int(total)





def _sf_undo_diagnostic_total_datablocks() -> int:

    return int(sum(_sf_undo_diagnostic_collection_length(name) for name in _SF_UNDO_DIAGNOSTIC_ID_COLLECTIONS))





def _sf_undo_diagnostic_collect_factors() -> dict:

    """Collect bounded snapshot-weight factors only from explicit operators."""

    counts = {

        'objects': _sf_undo_diagnostic_collection_length('objects'),

        'meshes': _sf_undo_diagnostic_collection_length('meshes'),

        'images': _sf_undo_diagnostic_collection_length('images'),

        'materials': _sf_undo_diagnostic_collection_length('materials'),

        'actions': _sf_undo_diagnostic_collection_length('actions'),

        'node_groups': _sf_undo_diagnostic_collection_length('node_groups'),

    }

    top_objects = []

    try:

        objects = getattr(bpy.data, 'objects', ()) or ()

    except Exception:

        objects = ()

    for obj in objects:

        try:

            if str(getattr(obj, 'type', '') or '') != 'MESH':

                continue

            mesh = getattr(obj, 'data', None)

            vertex_count = int(len(getattr(mesh, 'vertices', ()) or ())) if mesh is not None else 0

            item = (vertex_count, str(getattr(obj, 'name_full', '') or getattr(obj, 'name', '') or 'Object'))

            top_objects.append(item)

            top_objects.sort(key=lambda value: (-int(value[0]), str(value[1]).casefold()))

            if len(top_objects) > 5:

                del top_objects[5:]

        except Exception:

            continue

    packed_bytes = _sf_undo_diagnostic_packed_image_bytes()

    return {

        'counts': counts,

        'packed_image_bytes': int(packed_bytes),

        'packed_image_mb': float(packed_bytes) / (1024.0 * 1024.0),

        'top_objects': tuple((str(name), int(count)) for count, name in top_objects),

        'orphan_count': _sf_undo_diagnostic_orphan_count(),

        'total_datablocks': _sf_undo_diagnostic_total_datablocks(),

        'captured_at': float(time.time()),

    }





def _sf_undo_diagnostic_operator_finished(result) -> bool:

    try:

        return 'FINISHED' in set(result or ())

    except Exception:

        return False





def _sf_undo_diagnostic_view3d_override(context) -> dict:

    """Return a transient VIEW_3D operator override; never retain RNA values."""

    wm = getattr(context, 'window_manager', None)

    current_window = getattr(context, 'window', None)

    windows = []

    if current_window is not None:

        windows.append(current_window)

    try:

        for window in (getattr(wm, 'windows', ()) or ()):

            if window is not None and all(window is not item for item in windows):

                windows.append(window)

    except Exception:

        pass



    for window in windows:

        try:

            screen = getattr(window, 'screen', None)

            for area in (getattr(screen, 'areas', ()) or ()):

                if str(getattr(area, 'type', '') or '') != 'VIEW_3D':

                    continue

                for region in (getattr(area, 'regions', ()) or ()):

                    if str(getattr(region, 'type', '') or '') != 'WINDOW':

                        continue

                    override = {

                        'window': window,

                        'screen': screen,

                        'area': area,

                        'region': region,

                    }

                    # Global undo replaces Scene/ViewLayer data. Resolve them
                    # through the live window instead of pinning old RNA in the
                    # override while undo restores and evaluates the new Main.
                    return override

        except Exception:

            continue

    return {}





def _sf_undo_diagnostic_call(context, operator, **kwargs):

    """Invoke an undo operator in VIEW_3D when available.



    Text, Node, and other editors can own editor-local undo stacks. The Smart

    File panel is available in all physical editors, so the explicit diagnostic

    resolves a transient VIEW_3D override to measure Blender's scene Global Undo

    rather than an unrelated editor stack.

    """

    override = _sf_undo_diagnostic_view3d_override(context)

    temp_override = getattr(context, 'temp_override', None)

    if override and callable(temp_override):

        with temp_override(**override):

            return operator(**kwargs)

    return operator(**kwargs)





def _sf_undo_diagnostic_restore_selection(context, active_name: str, selected_names: tuple[str, ...]) -> None:

    try:

        selected = set(selected_names)

        for obj in (getattr(bpy.data, 'objects', ()) or ()):

            try:

                obj.select_set(str(getattr(obj, 'name', '') or '') in selected)

            except Exception:

                pass

        active = getattr(bpy.data, 'objects', None)

        active = active.get(active_name) if active is not None and active_name else None

        view_layer = getattr(context, 'view_layer', None)

        if active is not None and view_layer is not None:

            view_layer.objects.active = active

    except Exception:

        pass





def _sf_draw_undo_load_diagnostic(parent, context) -> None:

    """Draw cached diagnostic output only; all Blender-data scans are operators."""

    snapshot = _sf_undo_diagnostic_snapshot(context)

    active = getattr(context, 'active_object', None)

    object_mode = str(getattr(context, 'mode', '') or '') == 'OBJECT'



    controls = parent.row(align=True)

    measure = controls.row(align=True)

    measure.enabled = bool(active is not None and object_mode)

    measure.operator(

        'import_scene.sfs_system_measure_undo_speed',

        text=_t('Measure Undo Speed / Undo速度を計測'),

        icon='TIME',

    )

    controls.operator(

        'import_scene.sfs_system_purge_orphan_data',

        text=_t('Purge Orphan Data / 孤立データを整理'),

        icon='TRASH',

    )

    if active is None or not object_mode:

        parent.label(

            text=_t('Select a local object and switch to Object Mode before measuring. / ローカルオブジェクトを選択し、オブジェクトモードで計測してください。'),

        )



    error_text = str(snapshot.get('error', '') or '')

    if error_text:

        error_box = parent.box()

        error_box.alert = True

        error_box.label(text=_t('Undo diagnostic failed / Undo診断に失敗しました'), icon='ERROR')

        error_box.label(text=_sf_short_label_display(error_text, 120), icon='BLANK1')



    # B58_15_UNDO_HELP_ONLY_20261024: 操作説明は既存の？ヘルプへ集約。

    if snapshot.get('measured'):

        timing = parent.box()

        timing.label(text=_t('Undo Timing Averages / Undo時間の平均'), icon='TIME')

        grid = timing.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)

        grid.label(text=_t('Push / プッシュ'))

        grid.label(text=f"{float(snapshot.get('push_average', 0.0) or 0.0):.4f} s")

        grid.label(text=_t('Undo / 元に戻す'))

        grid.label(text=f"{float(snapshot.get('undo_average', 0.0) or 0.0):.4f} s")

        grid.label(text=_t('Redo / やり直す'))

        grid.label(text=f"{float(snapshot.get('redo_average', 0.0) or 0.0):.4f} s")

        grid.label(text=_t('Probe Cycles / 計測回数'))

        grid.label(text=str(int(snapshot.get('cycles', 0) or 0)))



        factors = parent.box()

        factors.label(text=_t('Snapshot Weight Factors / スナップショット重量要因'), icon='MEMORY')

        counts = dict(snapshot.get('counts') or {})

        count_grid = factors.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)

        for key, label in (

            ('objects', _t('Objects / オブジェクト')),

            ('meshes', _t('Meshes / メッシュ')),

            ('images', _t('Images / 画像')),

            ('materials', _t('Materials / マテリアル')),

            ('actions', _t('Actions / アクション')),

            ('node_groups', _t('Node Groups / ノードグループ')),

        ):

            count_grid.label(text=label)

            count_grid.label(text=str(int(counts.get(key, 0) or 0)))

        count_grid.label(text=_t('Packed Image Size / パック画像サイズ'))

        count_grid.label(text=f"{float(snapshot.get('packed_image_mb', 0.0) or 0.0):.2f} MB")

        count_grid.label(text=_t('Orphan Data / 孤立データ'))

        count_grid.label(text=str(int(snapshot.get('orphan_count', 0) or 0)))



        top_objects = tuple(snapshot.get('top_objects') or ())

        top_box = factors.box()

        top_box.label(text=_t('Top 5 Objects by Vertex Count / 頂点数上位5オブジェクト'), icon='MESH_DATA')

        if top_objects:

            for index, item in enumerate(top_objects[:5], 1):

                try:

                    name, vertex_count = item

                except Exception:

                    continue

                top_box.label(text=f"{index}. {_sf_short_label_display(str(name), 72)} — {int(vertex_count):,}")

        else:

            top_box.label(text=_t('No mesh objects / メッシュオブジェクトなし'))



    if snapshot.get('purge_completed'):

        purge_box = parent.box()

        purge_box.label(text=_t('Last Orphan Purge / 直前の孤立データ整理'), icon='TRASH')

        purge_grid = purge_box.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)

        purge_grid.label(text=_t('Data-blocks Before / 整理前データブロック'))

        purge_grid.label(text=str(int(snapshot.get('purge_before_total', 0) or 0)))

        purge_grid.label(text=_t('Data-blocks After / 整理後データブロック'))

        purge_grid.label(text=str(int(snapshot.get('purge_after_total', 0) or 0)))

        purge_grid.label(text=_t('Removed / 削除数'))

        purge_grid.label(text=str(int(snapshot.get('purge_removed', 0) or 0)))



def _sf_history_extra_tool_sections(context) -> list[dict]:

    prefs = _addon_prefs(context)

    can_fix = _sf_smart_fix_available_from_cached_state(context, prefs)

    return [

        {

            'title': _t('Saved Plans'),

            'subtitle': _t('Apply or restore saved recovery plans without leaving the History & Restore section.'),

            'icon': 'FILE_TICK',

            'help_key': 'category',

            'lane': 'HISTORY',

            'section': _t('Saved Plans'),

            'items': [

                _sf_lane_tool_entry(_t('Apply Saved Plan'), 'import_scene.sfs_root_repath_apply_saved_plan', 'CHECKMARK', _t('Apply a previously saved relink plan.'), keywords='apply saved repath plan'),

                _sf_lane_tool_entry(_t('Restore Saved Plan'), 'import_scene.sfs_root_repath_restore_saved_plan', 'LOOP_BACK', _t('Restore the paths captured in the last saved relink plan.'), keywords='restore saved repath plan'),

                _sf_lane_tool_entry(_t('Run Fix'), 'import_scene.sfs_workspace_command_fix_all', 'TOOL_SETTINGS', _t('Run the bundled safe repair pack for common root and coverage blockers.'), enabled=can_fix, keywords='run fix smart fix all'),

            ],

        },

        {

            'title': _t('Project Safety'),

            'subtitle': _t('Open project-level guards and shot-state tools that support rollback and review workflows.'),

            'icon': 'LOCKVIEW_ON',

            'help_key': 'category',

            'lane': 'HISTORY',

            'section': _t('Project Safety'),

            'items': [

                _sf_lane_tool_entry(_t('Project Guard'), 'import_scene.sfs_project_guard_open', 'LOCKVIEW_ON', _t('Open the project guard for locks, snapshots, and shared-edit safety.'), keywords='project guard'),

                _sf_lane_tool_entry(_t('Assembly Guard'), 'import_scene.sfs_assembly_guard_open', 'RESTRICT_SELECT_OFF', _t('Check assembly-level safety before larger merges or publishes.'), keywords='assembly guard'),

                _sf_lane_tool_entry(_t('Shot States'), 'import_scene.sfs_shot_state_open', 'CAMERA_DATA', _t('Capture, restore, or compare shot-state presets.'), keywords='shot state toolkit'),

            ],

        },

    ]





def _sf_draw_history_category_sections(parent, context) -> None:

    # History controls are drawn directly as child sections of History & Restore.

    # The former wrapper section named History Controls and the non-functional

    # File Pipeline history subsection are intentionally not drawn here.

    try:

        draw_history_popup_ui(parent, context)

    except Exception as exc:

        fail = parent.box()

        fail.alert = True

        fail.label(text=_t('History controls could not be drawn'), icon='ERROR')

        fail.label(text=_sf_short_label_display(_sf_error_text(exc), 120), icon='BLANK1')

    for section in _sf_history_extra_tool_sections(context):

        _sf_draw_lane_tool_section(parent, section, button_columns=2, default_open=False)





def _sf_draw_grouped_category_section(layout, context, page: str):

    info = _sf_function_category_info(page)

    title = str(info.get('title', page) or page)

    icon = str(info.get('icon', 'MENU_PANEL') or 'MENU_PANEL')

    box, body, expanded = _sf_draw_group_section_header(

        layout,

        context,

        section_key=f'sfs_top_category_{_sf_slug_key(page)}',

        title=title,

        icon=icon,

        help_key='category',

        lane=str(page or ''),

        section=title,

        default_open=False,

    )

    if not expanded or body is None:

        return box

    if str(page).upper() == 'HISTORY':

        _sf_draw_history_category_sections(body, context)

    else:

        _sf_draw_lane_tool_hub_ui(body, context, page, embedded=True, suppress_hero=True)

    if str(page).upper() == 'OTHER':

        diagnostic_box, diagnostic_body, diagnostic_expanded = _sf_draw_child_section_header(

            body,

            context,

            section_key='sfs_other_undo_load_diagnostic',

            title=_t('Undo Load Diagnostic / Undo負荷診断'),

            icon='TIME',

            help_key='undo_load_diagnostic',

            lane='OTHER',

            section=_t('Undo Load Diagnostic / Undo負荷診断'),

            default_open=False,

        )

        if diagnostic_expanded and diagnostic_body is not None:

            _sf_draw_undo_load_diagnostic(diagnostic_body, context)



        settings_box, settings_body, settings_expanded = _sf_draw_child_section_header(

            body,

            context,

            section_key='sfs_other_settings',

            title=_t('Settings'),

            icon='PREFERENCES',

            help_key='settings',

            lane='OTHER',

            section=_t('Settings'),

            default_open=False,

        )

        if settings_expanded and settings_body is not None:

            try:

                _sf_draw_addon_preferences_inside_smart_file_panel(settings_body, context)

            except Exception:

                fail = settings_body.box()

                fail.alert = True

                fail.label(text=_t('Settings could not be drawn in the Smart File N-panel. / Smart File Nパネル内で設定を描画できませんでした。'), icon='ERROR')

    return box





def _sf_draw_smart_file_workspace_ui(layout, context):

    if not _sf_runtime_workspace_props_ready(context):

        _sf_draw_workspace_props_missing_recovery_ui(layout, context)

        return

    layout.use_property_split = False

    layout.use_property_decorate = False



    def _top_slot():

        slot = layout.column(align=True)

        try:

            slot.use_property_split = False

            slot.use_property_decorate = False

        except Exception:

            pass

        return slot



    # Each top-level Smart File section is drawn into an independent sibling

    # layout slot.  This prevents nested body indentation from visually carrying

    # over to the following top-level headers when a section such as Link is open.

    # Keep the canonical section as the first direct boxed structure.  Extra

    # wrapper columns made it look nested to manager/proxy layouts even though

    # it was visually near the top.

    _sf_draw_always_on_section(_top_slot(), context)

    _sf_draw_current_source_section(_top_slot(), context)

    _sf_draw_compact_quick_sources(_top_slot(), context, _addon_prefs(context))



    for page in ('LINK', 'APPEND', 'IMPORT', 'EXPORT', 'PREVIEW', 'HISTORY', 'OTHER'):

        try:

            _sf_draw_grouped_category_section(_top_slot(), context, page)

        except Exception as exc:

            fallback = layout.box()

            fallback.alert = True

            fallback.label(text=str(page), icon='ERROR')

            fallback.label(text=_sf_short_label_display(_sf_error_text(exc), 120), icon='BLANK1')







def _sf_draw_panel_crash_guard(layout, context, draw_fn, *, label: str = 'Smart File'):

    try:

        return draw_fn(layout, context)

    except Exception as exc:

        try:

            fail = layout.box()

            fail.alert = True

            fail.label(text=_t('Smart File UI recovered from a drawing error'), icon='ERROR')

            fail.label(text=_sf_short_label_display(_sf_error_text(exc), 96), icon='BLANK1')

        except Exception:

            pass

        return None



class SF_OT_system_open_help(bpy.types.Operator):

    _sms_no_undo = True

    bl_label = 'Open Help'

    bl_idname = 'import_scene.sfs_system_open_help'

    bl_label = 'Open Help'

    bl_description = 'Open detailed help for this Smart File tool group.'

    bl_options = {'INTERNAL'}



    help_key: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    lane: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    section: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    addon_alias: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    operator_id: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    display_title: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    popup_width: IntProperty(default=820, min=520, max=1280, options={'HIDDEN', 'SKIP_SAVE'})



    @classmethod

    def description(cls, context, properties):

        title = str(getattr(properties, 'display_title', '') or '').strip()

        if title:

            return _t(f'Open help for {title}.')

        return _t('Open detailed help for this Smart File tool group.')



    def _help_module(self):

        import importlib as _importlib

        package = str(__package__ or '').strip()

        if not package:

            raise ImportError('Smart File package namespace is unavailable')

        module_name = f'{package}.help'

        return _importlib.import_module(module_name)



    def invoke(self, context, event):

        return context.window_manager.invoke_popup(self, width=int(self.popup_width or 820))



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        try:

            mod = self._help_module()

            draw_fn = getattr(mod, 'draw_help_popup', None)

            if callable(draw_fn):

                draw_fn(

                    self.layout,

                    context,

                    help_key=str(self.help_key or ''),

                    lane=str(self.lane or ''),

                    section=str(self.section or ''),

                    addon_alias=str(self.addon_alias or ''),

                    operator_id=str(self.operator_id or ''),

                    title=str(self.display_title or ''),

                    popup_width=int(self.popup_width or 820),

                )

                return

        except Exception as exc:

            box = self.layout.box()

            box.alert = True

            box.label(text=_t('Help could not be loaded / ヘルプを読み込めませんでした'), icon='ERROR')

            box.label(text=_sf_short_label_display(_sf_error_text(exc), 120), icon='BLANK1')

            return

        self.layout.label(text=_t('Help module is unavailable / ヘルプモジュールを利用できません'), icon='ERROR')





_SF_HISTORY_LEGACY_MIGRATION_COMPLETE = False





def _sf_migrate_legacy_history_on_explicit_open() -> bool:

    """Run the legacy history directory migration only on explicit History use.



    Cold add-on enable must not traverse directories.  This keeps the legacy

    compatibility operation available without placing it on import/register or

    Panel.draw paths.  A failed migration remains retryable on the next explicit

    History invocation and never escapes as a console traceback.

    """

    global _SF_HISTORY_LEGACY_MIGRATION_COMPLETE

    if _SF_HISTORY_LEGACY_MIGRATION_COMPLETE:

        return True

    try:

        import importlib as _importlib

        package = str(__package__ or '').strip()

        if not package:

            return False

        module = _importlib.import_module(f"{package}.history_storage")

        migrate_fn = getattr(module, 'migrate_legacy', None)

        if not callable(migrate_fn):

            return False

        migrate_fn()

        _SF_HISTORY_LEGACY_MIGRATION_COMPLETE = True

        return True

    except Exception:

        return False







class SF_OT_system_measure_undo_speed(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_system_measure_undo_speed'

    bl_label = 'Measure Undo Speed'

    bl_description = 'Measure Blender undo push, undo, and redo timing with three or four balanced temporary object-property probes, then collect scene weight factors without scanning from Panel.draw.'

    bl_options = {'INTERNAL'}



    cycles: IntProperty(default=3, min=3, max=4, options={'HIDDEN', 'SKIP_SAVE'})



    @classmethod

    def poll(cls, context):

        return bool(

            getattr(context, 'active_object', None) is not None

            and str(getattr(context, 'mode', '') or '') == 'OBJECT'

        )



    def execute(self, context):

        wm = getattr(context, 'window_manager', None)

        window = getattr(context, 'window', None)

        obj = getattr(context, 'active_object', None)

        if obj is None or str(getattr(context, 'mode', '') or '') != 'OBJECT':

            self.report({'ERROR'}, _t('Select a local object and switch to Object Mode before measuring. / ローカルオブジェクトを選択し、オブジェクトモードで計測してください。'))

            return {'CANCELLED'}

        if getattr(obj, 'library', None) is not None and getattr(obj, 'override_library', None) is None:

            self.report({'ERROR'}, _t('The active linked object is read-only. Select a local object or library override. / アクティブなリンクオブジェクトは読み取り専用です。ローカルオブジェクトまたはライブラリオーバーライドを選択してください。'))

            return {'CANCELLED'}

        try:

            if bool(getattr(wm, 'is_interface_locked', False)):

                raise RuntimeError(_t('Blender is currently locking the interface. Finish the active job and try again. / Blenderが現在インターフェースをロックしています。実行中の処理を完了してから再試行してください。'))

            preferences = getattr(context, 'preferences', None)

            edit_preferences = getattr(preferences, 'edit', None)

            if not bool(getattr(edit_preferences, 'use_global_undo', True)):

                raise RuntimeError(_t('Enable Global Undo in Blender Preferences before measuring undo speed. / Undo速度を計測する前に、BlenderプリファレンスでGlobal Undoを有効にしてください。'))

            if not _sf_undo_diagnostic_view3d_override(context):

                raise RuntimeError(_t('Open a 3D View in any Blender window before measuring undo speed. / Undo速度を計測する前に、いずれかのBlenderウィンドウで3Dビューを開いてください。'))

            screen = getattr(context, 'screen', None)

            if bool(getattr(screen, 'is_animation_playing', False)):

                raise RuntimeError(_t('Stop animation playback before measuring undo speed. / Undo速度を計測する前にアニメーション再生を停止してください。'))

            is_job_running = getattr(getattr(bpy, 'app', None), 'is_job_running', None)

            if callable(is_job_running) and bool(is_job_running('RENDER')):

                raise RuntimeError(_t('Wait for rendering to finish before measuring undo speed. / Undo速度を計測する前にレンダリング完了を待ってください。'))

        except RuntimeError as exc:

            self.report({'ERROR'}, _sf_error_text(exc))

            return {'CANCELLED'}

        except Exception:

            pass



        active_name = str(getattr(obj, 'name', '') or '')

        selected_names = tuple(str(getattr(item, 'name', '') or '') for item in tuple(getattr(context, 'selected_objects', ()) or ()))

        probe_key = f'_sfs_undo_probe_{_sf_rm_uuid.uuid4().hex}'

        cycles = max(3, min(4, int(self.cycles or 3)))

        push_times = []

        undo_times = []

        redo_times = []

        error_text = ''

        progress_started = False

        cursor_changed = False

        redo_branch_sealed = False



        try:

            if wm is not None:

                wm.progress_begin(0, cycles * 4 + 1)

                progress_started = True

            if window is not None:

                window.cursor_set('WAIT')

                cursor_changed = True



            baseline_result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo_push, message='Smart File Undo Diagnostic Baseline')

            if not _sf_undo_diagnostic_operator_finished(baseline_result):

                raise RuntimeError('undo_push baseline returned without FINISHED')



            for index in range(cycles):

                current = getattr(bpy.data, 'objects', None)

                current = current.get(active_name) if current is not None else None

                if current is None:

                    raise RuntimeError('The active object disappeared during undo measurement')

                current[probe_key] = float(index + 1) * 1.0e-12



                started = time.perf_counter()

                result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo_push, message=f'Smart File Undo Diagnostic Probe {index + 1}')

                push_times.append(max(0.0, time.perf_counter() - started))

                if not _sf_undo_diagnostic_operator_finished(result):

                    raise RuntimeError('undo_push returned without FINISHED')

                if wm is not None:

                    wm.progress_update(index * 4 + 1)



                started = time.perf_counter()

                result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo)

                undo_times.append(max(0.0, time.perf_counter() - started))

                if not _sf_undo_diagnostic_operator_finished(result):

                    raise RuntimeError('undo returned without FINISHED')

                current = getattr(bpy.data, 'objects', None)

                current = current.get(active_name) if current is not None else None

                if current is None or probe_key in current:

                    raise RuntimeError('measured undo did not restore the pre-probe object state')

                if wm is not None:

                    wm.progress_update(index * 4 + 2)



                started = time.perf_counter()

                result = _sf_undo_diagnostic_call(context, bpy.ops.ed.redo)

                redo_times.append(max(0.0, time.perf_counter() - started))

                if not _sf_undo_diagnostic_operator_finished(result):

                    raise RuntimeError('redo returned without FINISHED')

                current = getattr(bpy.data, 'objects', None)

                current = current.get(active_name) if current is not None else None

                if current is None or probe_key not in current:

                    raise RuntimeError('measured redo did not restore the probe state')

                if wm is not None:

                    wm.progress_update(index * 4 + 3)



                # Compensating undo restores the exact pre-probe state.  It is not

                # included in the reported Undo average, so each measured metric

                # still has exactly ``cycles`` samples.

                result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo)

                if not _sf_undo_diagnostic_operator_finished(result):

                    raise RuntimeError('compensating undo returned without FINISHED')

                current = getattr(bpy.data, 'objects', None)

                current = current.get(active_name) if current is not None else None

                if current is not None and probe_key in current:

                    raise RuntimeError('temporary undo probe survived compensating undo')

                if wm is not None:

                    wm.progress_update(index * 4 + 4)



            # The final compensating undo leaves Blender's redo branch pointing

            # at the temporary probe. Push the restored baseline once to close

            # that branch, so a later user Redo cannot resurrect diagnostic data.

            seal_result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo_push, message='Smart File Undo Diagnostic Restored')

            if not _sf_undo_diagnostic_operator_finished(seal_result):

                raise RuntimeError('restored baseline undo_push returned without FINISHED')

            redo_branch_sealed = True

            if wm is not None:

                wm.progress_update(cycles * 4 + 1)



            factors = _sf_undo_diagnostic_collect_factors()

            _sf_undo_diagnostic_store(

                context,

                measured=True,

                cycles=cycles,

                push_average=sum(push_times) / len(push_times),

                undo_average=sum(undo_times) / len(undo_times),

                redo_average=sum(redo_times) / len(redo_times),

                error='',

                **factors,

            )

            self.report({'INFO'}, _t('Undo speed measurement completed. / Undo速度の計測が完了しました。'))

            return {'FINISHED'}

        except Exception as exc:

            error_text = f'{type(exc).__name__}: {exc}'

            try:

                factors = _sf_undo_diagnostic_collect_factors()

            except Exception:

                factors = {}

            _sf_undo_diagnostic_store(context, measured=False, error=error_text, **factors)

            self.report({'ERROR'}, _t('Undo speed measurement failed. The temporary change was restored. / Undo速度の計測に失敗しました。一時変更は復元しました。'))

            return {'CANCELLED'}

        finally:

            # Never leave the unique probe property behind, including a partial

            # undo/redo failure. Reacquire by name because undo can invalidate RNA

            # object references held before the operation.

            try:

                current = getattr(bpy.data, 'objects', None)

                current = current.get(active_name) if current is not None else None

                if current is not None and probe_key in current:

                    try:

                        result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo)

                    except Exception:

                        result = None

                    current = getattr(bpy.data, 'objects', None)

                    current = current.get(active_name) if current is not None else None

                    if current is not None and probe_key in current:

                        del current[probe_key]

                # On a failure path, clear any redo branch that may still point

                # at the probe after compensating cleanup. This is best-effort

                # because the original failure must still be reported unchanged.

                if not redo_branch_sealed:

                    try:

                        seal_result = _sf_undo_diagnostic_call(context, bpy.ops.ed.undo_push, message='Smart File Undo Diagnostic Restored')

                        redo_branch_sealed = _sf_undo_diagnostic_operator_finished(seal_result)

                    except Exception:

                        pass

            except Exception:

                pass

            _sf_undo_diagnostic_restore_selection(context, active_name, selected_names)

            if progress_started and wm is not None:

                try:

                    wm.progress_end()

                except Exception:

                    pass

            if cursor_changed and window is not None:

                try:

                    window.cursor_set('DEFAULT')

                except Exception:

                    pass





class SF_OT_system_purge_orphan_data(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_system_purge_orphan_data'

    bl_label = 'Purge Orphan Data'

    bl_description = 'Recursively purge unused Blender data only after confirmation, then refresh the cached Undo Load Diagnostic factors.'

    bl_options = {'UNDO'}



    def invoke(self, context, event):

        return context.window_manager.invoke_props_dialog(self, width=500)



    def draw(self, context):

        box = self.layout.box()

        box.alert = True

        box.label(text=_t('Confirm Orphan Data Purge / 孤立データ整理の確認'), icon='ERROR')

        box.label(text=_t('Unused data blocks will be removed recursively. This can permanently delete data that is not linked to the current scene. / 未使用データブロックを再帰的に削除します。現在のシーンへリンクされていないデータが完全に削除される場合があります。'), icon='BLANK1')

        box.label(text=_t('Save the project first when you may need those unused data blocks later. / 後で未使用データが必要になる可能性がある場合は、先にプロジェクトを保存してください。'))



    def execute(self, context):

        wm = getattr(context, 'window_manager', None)

        window = getattr(context, 'window', None)

        progress_started = False

        cursor_changed = False

        try:

            before = _sf_undo_diagnostic_collect_factors()

            before_total = int(before.get('total_datablocks', 0) or 0)

            if wm is not None:

                wm.progress_begin(0, 1)

                progress_started = True

            if window is not None:

                window.cursor_set('WAIT')

                cursor_changed = True

            bpy.data.orphans_purge(do_recursive=True)

            after = _sf_undo_diagnostic_collect_factors()

            after_total = int(after.get('total_datablocks', 0) or 0)

            removed = max(0, before_total - after_total)

            _sf_undo_diagnostic_store(

                context,

                purge_completed=True,

                purge_before_total=before_total,

                purge_after_total=after_total,

                purge_removed=removed,

                error='',

                **after,

            )

            if wm is not None:

                wm.progress_update(1)

            self.report({'INFO'}, _t(f'Orphan data purge completed: {removed} data-blocks removed. / 孤立データの整理が完了しました: {removed}個のデータブロックを削除しました。'))

            return {'FINISHED'}

        except Exception as exc:

            _sf_undo_diagnostic_store(context, error=f'{type(exc).__name__}: {exc}')

            self.report({'ERROR'}, _t('Orphan data purge failed. / 孤立データの整理に失敗しました。'))

            return {'CANCELLED'}

        finally:

            if progress_started and wm is not None:

                try:

                    wm.progress_end()

                except Exception:

                    pass

            if cursor_changed and window is not None:

                try:

                    window.cursor_set('DEFAULT')

                except Exception:

                    pass



class SF_OT_history_open(bpy.types.Operator):

    _sms_no_undo = True

    bl_idname = 'import_scene.sfs_history_open'

    bl_label = 'Open'

    bl_description = 'Open the integrated history popup and the same History / Restore controls used by the regrouped Smart File category view.'

    bl_options = {'INTERNAL'}



    popup_width: IntProperty(default=560, min=420, max=760, options={'HIDDEN'})



    def invoke(self, context, event):

        _sf_migrate_legacy_history_on_explicit_open()

        _sf_append_activity(context, _t('Opened History Popup'), '', 'RECOVER_LAST')

        return context.window_manager.invoke_popup(self, width=self.popup_width)



    def execute(self, context):

        return {'FINISHED'}



    def draw(self, context):

        draw_history_popup_ui(self.layout, context)





class SF_OT_workspace_command_launcher(bpy.types.Operator):

    bl_idname = 'import_scene.sfs_workspace_command_launcher'

    bl_label = 'Launcher'

    bl_description = 'Open the Smart File home workspace from the Smart File N-panel, or use the popup fallback when launching it from another area. The home opens the seven functional categories requested for Smart File workflows.'

    # Opening the launcher only changes transient WindowManager UI state.  An

    # UNDO flag snapshots the whole scene before showing this popup, which is

    # disproportionately expensive for production files and provides no useful

    # undo step.

    bl_options = {'INTERNAL'}

    _sms_no_undo = True



    popup_width: IntProperty(default=560, min=420, max=760, options={'HIDDEN'})



    def invoke(self, context, event):

        prefs = _addon_prefs(context)

        width = int(getattr(prefs, 'ui_launcher_popup_width', self.popup_width) if prefs else self.popup_width)

        width = max(420, min(720, width))

        _sf_set_workspace_page(context, 'HOME')

        _sf_refresh_compact_launcher_context(context)

        _sf_append_activity(context, _t('Opened Launcher'), str(width), 'ASSET_MANAGER')

        return context.window_manager.invoke_popup(self, width=width)



    def execute(self, context):

        _sf_set_workspace_page(context, 'HOME')

        _sf_refresh_compact_launcher_context(context)

        return {'FINISHED'}



    def draw(self, context):

        _sf_draw_launcher_dashboard_ui(self.layout, context, include_hero=True)





class SF_PT_workspace_command_workspace_launcher(bpy.types.Panel):

    bl_label = 'Workspace Launcher'

    bl_idname = 'SF_PT_workspace_command_workspace_launcher'

    bl_description = 'Legacy compatibility shell kept unregistered and hidden. Use the Smart File N-panel for source selection, categories, help, and saved settings.'

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = 'Smart File'

    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'

    bl_options = set()

    bl_ui_units_x = 24



    @classmethod

    def poll(cls, context):

        return False



    def draw(self, context):

        _sf_draw_panel_crash_guard(self.layout, context, lambda layout, ctx: _sf_draw_launcher_dashboard_ui(layout, ctx, include_hero=False), label='Legacy Launcher Panel')





def _sf_manager_placement_result(value) -> bool:

    """Normalize the Manager's read-only placement result.



    Absent/disabled/NOT_READY is fail-open.  READY is authoritative.  Current

    Managers return a bool; structured forms are accepted for reload-boundary

    compatibility without importing or inspecting any other module.

    """

    if isinstance(value, bool):

        return value

    if value is None:

        return True

    if isinstance(value, dict):

        phase = str(value.get("phase") or value.get("state") or value.get("status") or "").strip().upper()

        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:

            return True

        if phase == "READY":

            return bool(value.get("allowed", value.get("value", True)))

        if "allowed" in value:

            return bool(value.get("allowed"))

        return True

    if isinstance(value, (tuple, list)) and len(value) >= 2:

        phase = str(value[0] or "").strip().upper()

        if phase in {"NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:

            return True

        if phase == "READY":

            return bool(value[1])

    if isinstance(value, str):

        phase = value.strip().upper()

        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:

            return True

        if phase in {"ALLOW", "ALLOWED", "ON", "TRUE"}:

            return True

        if phase in {"DENY", "DENIED", "OFF", "FALSE"}:

            return False

    return bool(value)





def _sf_manager_module_explicitly_unready(module) -> bool:

    """Read only explicit Manager lifecycle fields; absence is not an error."""

    if module is None:

        return True

    values = vars(module)

    for name in ("__addon_enabled__", "_manager_registered"):

        if name in values and not bool(values.get(name)):

            return True

    for name in (

        "PLACEMENT_API_STATE", "placement_api_state", "_placement_api_state",

        "PLACEMENT_PHASE", "placement_phase", "_placement_phase",

    ):

        if name not in values:

            continue

        phase = str(values.get(name) or "").strip().upper()

        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE", "ERROR"}:

            return True

    return False





def _sf_manager_runtime_record():

    try:

        record = bpy.app.driver_namespace.get(_SF_MANAGER_RUNTIME_NAMESPACE_KEY)

    except Exception:

        return None

    if not isinstance(record, dict):

        return None

    if record.get('package_id') != 'smart_tools_manager' or record.get('status') != 'ACTIVE':

        return None

    generation = record.get('generation')

    revision = record.get('revision')

    if not isinstance(generation, str) or not generation:

        return None

    if type(revision) is not int or revision < 0:

        return None

    if not isinstance(record.get('public_api'), dict):

        return None

    return record





def _sf_manager_workspace_key(context) -> str:

    for source in (

        getattr(context, 'workspace', None),

        getattr(getattr(context, 'window', None), 'workspace', None),

    ):

        try:

            normalized = _sf_manager_normalize_name(getattr(source, 'name', ''))

        except Exception:

            normalized = ''

        key = _SF_MANAGER_WORKSPACE_BY_NAME.get(normalized)

        if key:

            return key

    return ''





def _sf_refresh_manager_rule_cache(record) -> bool:

    generation = str(record.get('generation') or '')

    revision = int(record.get('revision') or 0)

    decisions = {}

    ready = False

    snapshot_fn = record.get('public_api', {}).get('get_rule_matrix_snapshot')

    if callable(snapshot_fn):

        try:

            snapshot = snapshot_fn()

        except Exception:

            snapshot = None

        status = str(getattr(snapshot, 'status', '') or '').upper()

        ready = bool(

            isinstance(snapshot, dict)

            and status == 'READY'

            and bool(getattr(snapshot, 'authoritative', True))

        )

        if ready:

            for workspace_key in _SF_MANAGER_WORKSPACE_ALIASES:

                try:

                    editor_rules = snapshot.get(workspace_key, {}).get('VIEW_3D', {})

                    value = editor_rules.get('SMART_FILE')

                except Exception:

                    value = None

                if isinstance(value, bool):

                    decisions[workspace_key] = value

    _SF_MANAGER_RULE_CACHE.update({

        'generation': generation,

        'revision': revision,

        'active': bool(ready),

        'decisions': decisions,

    })

    return True





def _sf_manager_panel_rule_allows(context, editor_key: str) -> bool:

    """Use one revision cache; ordinary Panel.poll performs no Manager call."""

    exact_editor_key = str(editor_key or "").strip().upper()

    if exact_editor_key != 'VIEW_3D':

        return True

    record = _sf_manager_runtime_record()

    if record is None:

        _SF_MANAGER_RULE_CACHE.update({

            'generation': '', 'revision': -1, 'active': False, 'decisions': {},

        })

        return True

    generation = str(record.get('generation') or '')

    revision = int(record.get('revision') or 0)

    if (

        _SF_MANAGER_RULE_CACHE.get('generation') != generation

        or _SF_MANAGER_RULE_CACHE.get('revision') != revision

    ):

        _sf_refresh_manager_rule_cache(record)

    if not _SF_MANAGER_RULE_CACHE.get('active'):

        return True

    workspace_key = _sf_manager_workspace_key(context)

    value = _SF_MANAGER_RULE_CACHE.get('decisions', {}).get(workspace_key)

    return value if isinstance(value, bool) else True





class SF_PT_reference_manager_reference_manager_workspace(bpy.types.Panel):

    _sfs_standard_npanel_anchor = True

    _smart_tools_manager_native_npanel_root = True

    _smart_tools_manager_tool_key = "SMART_FILE"

    _smart_tools_manager_disable_proxy = True

    _smart_tools_manager_no_cross_editor_proxy = True

    _smart_tools_manager_no_active_object_required = True

    _smart_tools_manager_cross_editor_safe = True

    bl_label = 'Smart File'

    bl_idname = 'SF_PT_reference_manager_reference_manager_workspace'

    bl_description = 'Show the Smart File home and the seven requested functional categories as a standard 3D View Sidebar N-panel.'

    bl_space_type = 'VIEW_3D'

    bl_region_type = 'UI'

    bl_category = 'Smart File'

    bl_order = 0



    @classmethod

    def poll(cls, context):

        area = getattr(context, 'area', None)

        in_view = area is None or str(getattr(area, 'type', '') or '') == 'VIEW_3D'

        return bool(in_view and _sf_manager_panel_rule_allows(context, "VIEW_3D"))



    def draw_header_preset(self, context):

        op = self.layout.operator('smart_file_suite.open_help', text='', icon='QUESTION')

        op.topic = 'home'



    def draw(self, context):

        _sf_draw_panel_crash_guard(self.layout, context, _sf_draw_smart_file_workspace_ui, label='Smart File N-panel')

        return None





class SF_MT_reference_manager_reference_manager(bpy.types.Menu):

    bl_label = 'Reference Manager'

    bl_idname = 'SF_MT_reference_manager_reference_manager'

    bl_description = 'Open the compact Smart File category menu from the Smart File N-panel when you want the launcher and regrouped Link, Append, Import, Export, Preview, History and Restore, and Other categories with full tool access inside each category.'



    def draw(self, context):

        layout = self.layout



        layout.operator(SF_OT_workspace_command_run_top_recommendation.bl_idname, text=_sf_review_run_button_text(), icon='PLAY')

        layout.operator(SF_OT_reference_manager_source_check.bl_idname, text=_t('Source Check'), icon='CHECKMARK')

        layout.operator(SF_OT_workspace_command_action_palette.bl_idname, text=_t('Search...'), icon='VIEWZOOM')

        layout.separator()



        for lane, label, icon in (

            ('LINK', _t('Link'), 'LINKED'),

            ('APPEND', _t('Append'), 'APPEND_BLEND'),

            ('IMPORT', _t('Import'), 'IMPORT'),

            ('EXPORT', _t('Export'), 'EXPORT'),

            ('PREVIEW', _t('Preview'), 'IMAGE_DATA'),

            ('HISTORY', _t('History & Restore'), 'RECOVER_LAST'),

            ('OTHER', _t('Other'), 'MENU_PANEL'),

        ):

            op = _sf_draw_operator_if_registered(layout, SF_OT_workspace_command_open_category_hub, text=label, icon=icon)

            _sf_safe_set_operator_property(op, 'lane', lane)



        try:

            roundtrip_ticket = _sf_link_edit_current_ticket_cached(context)

        except Exception:

            roundtrip_ticket = {}

        if roundtrip_ticket and _sf_link_edit_ticket_matches_current(roundtrip_ticket, bpy.data.filepath or ''):

            layout.separator()

            layout.operator('import_scene.sfs_external_assets_return_to_parent_scene', text=_t('Return to Parent Scene'), icon='LOOP_BACK')





def menu_func_append(self, context):

    prefs = _addon_prefs(context)

    if prefs and not bool(getattr(prefs, "ui_show_file_menu", False)):

        return

    icon_id = _sf_brand_icon_id(context)

    if icon_id:

        self.layout.menu(SF_MT_reference_manager_reference_manager.bl_idname, text=_t('Reference Manager'), icon_value=icon_id)

    else:

        self.layout.menu(SF_MT_reference_manager_reference_manager.bl_idname, text=_t('Reference Manager'), icon='ASSET_MANAGER')





def view3d_header_menu_func(self, context):

    prefs = _addon_prefs(context)

    if prefs and not bool(getattr(prefs, "ui_show_view3d_header_menu", True)):

        return



    row = self.layout.row(align=True)

    row.operator_context = 'INVOKE_DEFAULT'

    icon_id = _sf_brand_icon_id(context)

    if icon_id:

        row.operator(SF_OT_workspace_command_launcher.bl_idname, text='', icon_value=icon_id, emboss=True)

    else:

        row.operator(SF_OT_workspace_command_launcher.bl_idname, text='', icon='ASSET_MANAGER', emboss=True)

