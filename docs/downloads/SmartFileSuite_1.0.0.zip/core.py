# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

'Smart File (Upgraded, split package)\n\nBrowse datablocks inside a .blend file, select items from a list UI, and import them\nwith production-friendly options:\n\n- Objects / Collections / Materials / Node Groups / Actions / Worlds\n- Append / Link / Link + Library Override\n- Best-effort dependency handling for Objects\n- Naming / collision strategy\n- Organization into a new collection\n- Placement rules (cursor / active / floor / grid) + offsets\n- Post actions (select imported, frame in view)\n- Japanese UI + tooltips via Blender translations'

from .ui_language_runtime import ui_text as _ui_text
import os
import json
import time
import datetime
import re
import uuid
import textwrap
import sys
import bpy

from bpy.props import (
    StringProperty,
    BoolProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    PointerProperty,
)
from bpy_extras.io_utils import ImportHelper, ExportHelper


# -----------------------------------------------------------------------------
#  License / Rights
# -----------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact:
#  Video Tutorials:
#
#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - 禁止事項: 許可なき再配布、改変、転売を固く禁じます。
# -----------------------------------------------------------------------------


bl_info = {
    "name": "Smart File",
    "author": "JELararagi",
    "version": (5, 75, 88),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart File",
    "description": "Browse, import, inspect, relink, watch roots, manage named context roots, preview or apply handoff manifests, publish, run goal starter packs, read goal playbooks, compare source readiness matrices, visualize source-to-root relationships, compare goal scoreboards, inspect profile match boards, run bundled repair packs, run top recommendations, preview repairs, open focused goal roadmaps, export session bundles or profile packs, compare goal decks, track activity, filter workspace profiles, apply smart fixes, and maintain library roots for .blend assets from a modern properties-first workflow.",
    "category": "Import-Export",
}


_SF_BRAND_ICON_NAME = "smart_file_suite_header"
_SF_BRAND_PREVIEW_COLLECTION_KEY = "smart_file_suite.brand_preview_collection"
_SF_BRAND_ICON_ID = 0
_SF_BRAND_PREVIEW_COLLECTION = None



def _sf_header_icon_variant_value(context: bpy.types.Context | None = None) -> str:
    try:
        prefs = _addon_prefs(context or bpy.context)
        value = str(getattr(prefs, "ui_header_icon_variant", "AUTO") or "AUTO").upper() if prefs else "AUTO"
    except Exception:
        value = "AUTO"
    return value if value in {"AUTO", "COLOR", "LIGHT", "DARK", "MONO"} else "AUTO"


def _sf_brand_icon_candidates(context: bpy.types.Context | None = None) -> list[str]:
    icon_dir = os.path.join(os.path.dirname(__file__), 'icons')
    return [os.path.join(icon_dir, 'smart_file_header.png')]


def _sf_brand_icon_path(context: bpy.types.Context | None = None) -> str:
    for candidate in _sf_brand_icon_candidates(context):
        if os.path.isfile(candidate):
            return candidate
    return os.path.join(os.path.dirname(__file__), "icons", "smart_file_header.png")


def _sf_brand_preview_collection():
    """Return a persistent preview collection for the Smart File header icon.

    Never return icon IDs from a temporary preview collection. Blender can keep
    UI buttons alive across redraw and mode-transition events, so removing the
    collection immediately after reading ``icon_id`` can leave the C-side UI with
    a stale icon pointer.
    """
    global _SF_BRAND_PREVIEW_COLLECTION
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if ns is None:
            return None
        pcoll = _SF_BRAND_PREVIEW_COLLECTION
        if pcoll is None:
            pcoll = ns.get(_SF_BRAND_PREVIEW_COLLECTION_KEY)
        if pcoll is not None:
            _SF_BRAND_PREVIEW_COLLECTION = pcoll
            ns[_SF_BRAND_PREVIEW_COLLECTION_KEY] = pcoll
            try:
                from . import preview_cleanup as _sf_preview_cleanup
                _sf_preview_cleanup.register_atexit()
            except Exception:
                pass
            return pcoll
        import bpy.utils.previews as previews_mod
        pcoll = previews_mod.new()
        _SF_BRAND_PREVIEW_COLLECTION = pcoll
        ns[_SF_BRAND_PREVIEW_COLLECTION_KEY] = pcoll
        try:
            from . import preview_cleanup as _sf_preview_cleanup
            _sf_preview_cleanup.register_atexit()
        except Exception:
            pass
        return pcoll
    except Exception:
        return None




def _sf_prime_brand_icon(context: bpy.types.Context | None = None) -> int:
    """Load the single header icon outside Panel.draw and cache its integer ID."""
    global _SF_BRAND_ICON_ID
    path = _sf_brand_icon_path(context)
    if not path or not os.path.isfile(path):
        _SF_BRAND_ICON_ID = 0
        return 0
    try:
        pcoll = _sf_brand_preview_collection()
        if pcoll is None:
            _SF_BRAND_ICON_ID = 0
            return 0
        key = f"{_SF_BRAND_ICON_NAME}:{os.path.abspath(path)}"
        if key not in pcoll:
            pcoll.load(key, path, 'IMAGE')
        _SF_BRAND_ICON_ID = int(getattr(pcoll[key], 'icon_id', 0) or 0)
    except Exception:
        _SF_BRAND_ICON_ID = 0
    return int(_SF_BRAND_ICON_ID or 0)


def _sf_brand_icon_id(context: bpy.types.Context | None = None) -> int:
    """Return the icon prepared during registration; never touch disk in draw."""
    del context
    return int(_SF_BRAND_ICON_ID or 0)

def _sf_saved_path_icon_id(path: str) -> int:
    try:
        preview = _sf_guess_preview_sidecar(path)
        if preview:
            return _get_thumb_icon_id(preview)
    except Exception:
        pass
    return 0


def _sf_short_path_display(path: str, max_len: int = 54) -> str:
    path = _norm_path(path or '')
    if not path:
        return ''
    if len(path) <= max_len:
        return path
    base = os.path.basename(path) or path
    head_budget = max(8, max_len - len(base) - 4)
    if len(base) >= max_len - 3:
        return '…' + base[-(max_len - 1):]
    return path[:head_budget].rstrip('/\\') + '…/' + base


def _sf_short_label_display(text: str, max_len: int = 28) -> str:
    text = str(text or '').strip()
    if not text:
        return ''
    if len(text) <= max_len:
        return text
    return text[: max(4, max_len - 1)].rstrip() + '…'


def _sf_ui_density_is_compact(prefs) -> bool:
    try:
        return str(getattr(prefs, 'ui_home_density', 'COMFORT') or 'COMFORT').upper() == 'COMPACT'
    except Exception:
        return False


def _sf_draw_section_intro(box, title: str, subtitle: str = '', icon: str = 'NONE'):
    box.label(text=_t(title), icon=icon)
    return box


def _sf_draw_dialog_header(parent, title: str, subtitle: str = '', icon: str = 'NONE'):
    box = parent.box()
    _sf_draw_section_intro(box, title, subtitle, icon)
    return box


def _sf_draw_dialog_summary(parent, summary_text: str = '', title: str = 'Latest Summary', subtitle: str = 'Review the generated summary here before you close the dialog or open the report in the Text Editor.', icon: str = 'TEXT'):
    box = parent.box()
    _sf_draw_section_intro(box, title, subtitle, icon)
    if summary_text:
        for line in str(summary_text or '').splitlines():
            if not line.strip():
                box.separator()
            else:
                box.label(text=line[:240])
    else:
        _sf_draw_empty_state(box, 'No summary yet', 'Run the current step first to generate a preview summary in this area.', 'NONE')
    return box


def _sf_draw_hint(box, text: str, icon: str = 'NONE'):
    if text:
        box.label(text=_t(text), icon=icon)
    return box


def _sf_draw_empty_state(parent, title: str, body: str = '', icon: str = 'NONE'):
    box = parent.box()
    box.label(text=_t(title), icon=icon)
    return box


def _sf_draw_list_header(parent, columns, icon: str = 'BLANK1'):
    row = parent.row(align=True)
    row.scale_y = 0.85
    for idx, column in enumerate(columns):
        if isinstance(column, (tuple, list)):
            label = column[0] if len(column) > 0 else ''
            scale = float(column[1]) if len(column) > 1 else 1.0
            align = str(column[2]) if len(column) > 2 and column[2] else 'LEFT'
        else:
            label = str(column or '')
            scale = 1.0
            align = 'LEFT'
        cell = row.row(align=True)
        cell.scale_x = max(0.1, scale)
        try:
            cell.alignment = align
        except Exception:
            pass
        cell.label(text=_t(label), icon=(icon if idx == 0 else 'BLANK1'))
    return row





def _sf_operator_button(parent, operator_idname: str, text: str, icon: str = 'NONE', danger: bool = False, depress: bool = False, emboss: bool = True):
    slot = parent.row(align=True)
    slot.alert = bool(danger)
    return slot.operator(operator_idname, text=_t(text), icon=icon, depress=depress, emboss=emboss)


def _sf_draw_action_row(parent, actions):
    row = parent.row(align=True)
    for action in (actions or []):
        if not action:
            row.separator()
            continue
        operator_idname, text, icon, props, danger = (list(action) + [{}, False])[:5]
        op = _sf_operator_button(row, operator_idname, text, icon=icon or 'NONE', danger=bool(danger))
        for key, value in dict(props or {}).items():
            try:
                setattr(op, key, value)
            except Exception:
                pass
    return row


def _sf_draw_action_block(parent, primary_actions=None, secondary_actions=None, danger_actions=None, danger_title: str = 'Risky Actions', danger_hint: str = 'Keep remove, clear, or delete actions separate so they are harder to click by accident.'):
    block = parent.column(align=True)
    if primary_actions:
        _sf_draw_action_row(block, primary_actions)
    if secondary_actions:
        _sf_draw_action_row(block, secondary_actions)
    if danger_actions:
        danger_box = block.box()
        try:
            danger_box.alert = True
        except Exception:
            pass
        danger_box.label(text=_t(danger_title), icon='ERROR')
        _sf_draw_action_row(danger_box, [tuple(list(action[:4]) + [True]) for action in danger_actions])
    return block


def _sf_state_meta(state: str | None, fallback_icon: str = 'NONE') -> tuple[str, str]:
    raw = str(state or '').strip()
    key = raw.upper()
    mapping = {
        'READY': ('Ready', 'CHECKMARK'),
        'READY NOW': ('Ready now', 'CHECKMARK'),
        'HEALTHY': ('Ready', 'CHECKMARK'),
        'ALIGNED': ('Ready', 'CHECKMARK'),
        'FOUND': ('Ready', 'CHECKMARK'),
        'OK': ('Ready', 'CHECKMARK'),
        'INDEXED': ('Indexed', 'FILE_REFRESH'),
        'PUBLISHED': ('Published', 'EXPORT'),
        'UPDATED': ('Updated', 'FILE_REFRESH'),
        'REVIEW': ('Needs review', 'NONE'),
        'REVIEW NEEDED': ('Needs review', 'NONE'),
        'UNRESOLVED': ('Needs attention', 'ERROR'),
        'MISSING': ('Missing', 'ERROR'),
        'NOT READY': ('Not ready', 'ERROR'),
        'NOT SET': ('Not set', 'NONE'),
        'DISABLED': ('Disabled', 'CANCEL'),
        'NEEDS SETUP': ('Needs setup', 'ERROR'),
        'NEEDS MORE SETUP': ('Needs more setup', 'ERROR'),
        'NEEDS ADJUSTMENT': ('Needs adjustment', 'ERROR'),
        'NEEDS ATTENTION': ('Needs attention', 'ERROR'),
        'ATTENTION NEEDED': ('Attention needed', 'ERROR'),
        'NEEDS INDEX': ('Needs index', 'FILE_REFRESH'),
        'NEEDS SOURCE': ('Needs source', 'ERROR'),
        'NEEDS ROOTS': ('Needs roots', 'ERROR'),
        'MISSING SIDECARS': ('Missing sidecars', 'ERROR'),
        'YES': ('Yes', 'CHECKMARK'),
        'NO': ('No', 'NONE'),
    }
    label, icon = mapping.get(key, (raw or 'Status', fallback_icon))
    return _t(label), icon


def _sf_draw_state_line(parent, label: str, state: str | None, fallback_icon: str = 'NONE', detail: str = ''):
    state_label, icon = _sf_state_meta(state, fallback_icon=fallback_icon)
    row = parent.row(align=True)
    row.label(text=f"{_t(label)}: {state_label}", icon=icon)
    if detail:
        row.label(text=str(detail), icon='BLANK1')
    return row


def _sf_draw_review_run_dialog(parent, payload: dict, max_lines: int = 6, max_states: int = 6):
    payload = dict(payload or {})
    _sf_draw_dialog_header(parent, payload.get('title', 'Review & Run...'), payload.get('subtitle', ''), payload.get('icon', 'NONE'))

    summary_text = str(payload.get('summary', '') or '').strip()
    reason_text = str(payload.get('reason', '') or '').strip()
    can_run = bool(payload.get('can_run', True))

    if summary_text or reason_text:
        overview = parent.box()
        _sf_draw_section_intro(overview, 'Execution Summary', 'Read the short summary first so you know what this action is about to do.', 'NONE')
        if summary_text:
            overview.label(text=summary_text[:240], icon='BLANK1')
        if reason_text:
            _sf_draw_hint(overview, reason_text, 'NONE' if can_run else 'ERROR')

    states = list(payload.get('states', []) or [])
    if states:
        ready_box = parent.box()
        _sf_draw_section_intro(ready_box, 'Readiness Snapshot', 'Check the goal, source, roots, and index state before continuing.', 'CHECKMARK')
        for item in states[:max_states]:
            label = str(item.get('label', 'Status') or 'Status')
            state = str(item.get('state', '') or '')
            detail = str(item.get('detail', '') or '')
            fallback_icon = str(item.get('icon', 'NONE') or 'NONE')
            _sf_draw_state_line(ready_box, label, state, fallback_icon=fallback_icon, detail=detail)

    lines = [str(line) for line in list(payload.get('lines', []) or []) if str(line or '').strip()]
    if lines:
        plan_box = parent.box()
        _sf_draw_section_intro(plan_box, 'Planned Changes', 'Review the main changes, follow-up tools, and side effects before running this action.', 'TEXT')
        for line in lines[:max_lines]:
            plan_box.label(text=line[:240], icon='BLANK1')

    follow_up = [str(line) for line in list(payload.get('follow_up', []) or []) if str(line or '').strip()]
    if follow_up:
        follow_box = parent.box()
        _sf_draw_section_intro(follow_box, 'After You Run It', 'Use these follow-up notes to verify the result after the action completes.', 'FORWARD')
        for line in follow_up[:max_lines]:
            follow_box.label(text=line[:240], icon='BLANK1')

    footnote = str(payload.get('footnote', '') or '').strip()
    if footnote:
        _sf_draw_hint(parent.box(), footnote, 'NONE')


def _sf_draw_execution_result_dialog(parent, payload: dict, max_lines: int = 8, max_states: int = 6):
    payload = dict(payload or {})
    _sf_draw_dialog_header(parent, payload.get('title', 'Last Quick Action'), payload.get('subtitle', ''), payload.get('icon', 'CHECKMARK'))

    summary_text = str(payload.get('summary', '') or '').strip()
    status_text = str(payload.get('status', '') or '').strip()
    if summary_text or status_text:
        overview = parent.box()
        _sf_draw_section_intro(overview, 'Execution Result', 'Review the short result summary first so you know what just changed.', 'CHECKMARK')
        if summary_text:
            overview.label(text=summary_text[:240], icon='BLANK1')
        if status_text:
            _sf_draw_hint(overview, status_text, 'CHECKMARK')

    states = list(payload.get('states', []) or [])
    if states:
        ready_box = parent.box()
        _sf_draw_section_intro(ready_box, 'Current Readiness', 'Confirm the goal, source, roots, and index state after the action completed.', 'NONE')
        for item in states[:max_states]:
            label = str(item.get('label', 'Status') or 'Status')
            state = str(item.get('state', '') or '')
            detail = str(item.get('detail', '') or '')
            fallback_icon = str(item.get('icon', 'NONE') or 'NONE')
            _sf_draw_state_line(ready_box, label, state, fallback_icon=fallback_icon, detail=detail)

    lines = [str(line) for line in list(payload.get('lines', []) or []) if str(line or '').strip()]
    if lines:
        plan_box = parent.box()
        _sf_draw_section_intro(plan_box, 'What Changed', 'Review the main changes that finished during the action.', 'TEXT')
        for line in lines[:max_lines]:
            plan_box.label(text=line[:240], icon='BLANK1')

    follow_up = [str(line) for line in list(payload.get('follow_up', []) or []) if str(line or '').strip()]
    if follow_up:
        follow_box = parent.box()
        _sf_draw_section_intro(follow_box, 'Recommended Next Step', 'Use the follow-up notes to decide which screen to open next.', 'FORWARD')
        for line in follow_up[:max_lines]:
            follow_box.label(text=line[:240], icon='BLANK1')

    footnote = str(payload.get('footnote', '') or '').strip()
    if footnote:
        _sf_draw_hint(parent.box(), footnote, 'NONE')


def _sf_draw_source_snapshot(parent, filepath: str, source_info: dict | None, health_score: int = 0, health_label: str = '', compact: bool = False):
    box = parent.box()
    _sf_draw_section_intro(box, 'Current Source Snapshot', 'See the active source, root coverage, indexing, and sidecar readiness before using deeper tools.', 'FILE_BLEND')
    filepath = _norm_path(filepath or '')
    info = dict(source_info or {})
    if not filepath:
        _sf_draw_empty_state(
            box,
            'No source selected yet',
            'Choose a .blend source so Smart File can inspect readiness, suggest the next step, and unlock source-aware tools.',
            'NONE',
        )
        return box

    box.label(text=os.path.basename(filepath) or filepath, icon='FILE_BLEND', translate=False)
    folder_label = _sf_short_path_display(os.path.dirname(filepath), 66 if not compact else 48)
    if folder_label:
        box.label(text=folder_label, icon='FILE_FOLDER', translate=False)

    score_row = box.row(align=True)
    score_row.label(text=f"{_t('Health Score')}: {int(health_score)}/100", icon='CHECKMARK' if int(health_score) >= 65 else 'ERROR')
    if health_label:
        score_row.label(text=str(health_label), icon='BLANK1')

    grid = box.grid_flow(columns=2 if not compact else 1, row_major=True, even_columns=True, even_rows=False, align=True)
    _sf_draw_state_line(grid, 'Root Coverage', 'Ready' if bool(info.get('inside_root')) else 'Needs roots', fallback_icon='FILE_FOLDER', detail=_t('Inside library root') if bool(info.get('inside_root')) else _t('Outside library root'))
    _sf_draw_state_line(grid, 'Indexed', 'Indexed' if bool(info.get('is_indexed')) else 'Not ready', fallback_icon='FILE_REFRESH')
    _sf_draw_state_line(grid, 'Preview Sidecar', 'Ready' if bool(info.get('preview_path')) else 'Missing', fallback_icon='IMAGE_DATA')
    _sf_draw_state_line(grid, 'Metadata Sidecar', 'Ready' if bool(info.get('meta_path')) else 'Missing', fallback_icon='TEXT')
    _sf_draw_state_line(grid, 'Catalog', 'Ready' if bool(info.get('catalog_path')) else 'Missing', fallback_icon='FILE_TICK')
    modified = str(info.get('source_mtime_label') or '').strip() or _t('Unknown')
    grid.label(text=f"{_t('Last Modified')}: {modified}", icon='TIME')

    if bool(info.get('inside_root')) and str(info.get('root_name') or '').strip():
        box.label(text=f"{_t('Root')}: {str(info.get('root_name') or '').strip()}", icon='FILE_FOLDER')
    return box


def _sf_goal_primary_screens(goal: str) -> list[str]:
    goal = str(goal or '').upper()
    mapping = {
        'EXPLORE': ['Launcher...', 'Goal Home...', 'Source Check...'],
        'IMPORT': ['Goal Home...', 'Run Top Recommendation', 'Workspace Profiles'],
        'MAINTAIN': ['Source Check...', 'Repair Packs', 'Goal Home...'],
        'PUBLISH': ['Goal Home...', 'Final Review...', 'Release Gate...'],
        'RECOVER': ['Source Check...', 'Smart Fix Preview...', 'Smart Fix All', 'Repair Packs'],
    }
    return list(mapping.get(goal, ['Launcher...', 'Goal Home...', 'Source Check...']))


def _sf_draw_recommended_lane(parent, goal: str, compact: bool = False, has_source: bool = False):
    box = parent.box()
    _sf_draw_section_intro(box, 'Recommended Path', 'Keep the beginner path fixed so most daily work can be completed from the main four screens.', 'TRACKING')
    primary = _sf_goal_primary_screens(goal)
    focus = box.box()
    focus.label(text=f"{_t('Goal')}: {_t(str(goal or '').title())}", icon='BOOKMARKS')
    for idx, label in enumerate(primary[:(3 if compact else len(primary))], 1):
        focus.label(text=f"{idx}. {_t(label)}", icon='FORWARD' if idx == 1 else 'BLANK1')
    if not has_source:
        pass
    return box


def _sf_draw_report_hub(parent, context, has_source: bool, compact: bool = False):
    box = parent.box()
    _sf_draw_section_intro(box, 'Reports', 'Use the lighter report for daily checks, then step up to handoff, release, or full bundles only when needed.', 'TEXT')

    daily = box.box()
    daily.label(text=_t('Daily Report'), icon='TEXT')
    if not compact:
        pass
    daily.operator(SF_OT_reference_manager_workspace_report.bl_idname, text=_t('Workspace Report'), icon='TEXT').open_text = True

    final = box.box()
    final.label(text=_t('Handoff & Final'), icon='FILE_TICK')
    if not compact:
        pass
    buttons = final.column(align=True) if compact else final.row(align=True)
    if has_source:
        buttons.operator(SF_OT_reference_manager_product_readiness_report.bl_idname, text=_t('Product Readiness Report'), icon='TEXT').open_text = True
        buttons.operator(SF_OT_workspace_command_handoff_report.bl_idname, text=_t('Handoff Report'), icon='TEXT').open_text = True
        buttons.operator(SF_OT_workspace_command_release_report.bl_idname, text=_t('Release Report'), icon='TEXT').open_text = True
    else:
        buttons.enabled = False
        buttons.operator(SF_OT_reference_manager_product_readiness_report.bl_idname, text=_t('Product Readiness Report'), icon='TEXT').open_text = True
        buttons.operator(SF_OT_workspace_command_handoff_report.bl_idname, text=_t('Handoff Report'), icon='TEXT').open_text = True
        buttons.operator(SF_OT_workspace_command_release_report.bl_idname, text=_t('Release Report'), icon='TEXT').open_text = True
        final.label(text=_t('Select a source to unlock product, handoff, and release reports.'))

    full = box.box()
    full.label(text=_t('Full Bundle'), icon='FILE_TEXT')
    if not compact:
        pass
    full.operator(SF_OT_workspace_command_session_bundle.bl_idname, text=_t('Session Bundle'), icon='FILE_TEXT').open_text = True
    return box


# -----------------------------------------------------------------------------
#  Translations
# -----------------------------------------------------------------------------

try:
    from .translation_catalog import TRANSLATION_DICT as translation_dict
except Exception:
    translation_dict = {"ja_JP": {}}


def _sf_locale_is_japanese() -> bool:
    "Return True only when Blender itself is actively drawing the UI in Japanese.\n\n    Smart File should follow Blender's own language settings and translation\n    toggles instead of forcing a local add-on language mode. In particular, if the\n    user disables interface translation in Blender preferences, the add-on should\n    stay in English even when the preferred language is set to Japanese."
    try:
        prefs = getattr(bpy.context, "preferences", None)
        view = getattr(prefs, "view", None) if prefs else None
        if view is not None and hasattr(view, "use_translate_interface"):
            if not bool(getattr(view, "use_translate_interface", False)):
                return False
        language = str(getattr(view, "language", "") or "")
        if language and language != 'DEFAULT':
            return language.startswith('ja')
        return str(getattr(bpy.app.translations, 'locale', '') or '').startswith('ja')
    except Exception:
        return False


def _sf_loaded_ui_language_callable(name: str):
    """Resolve an already-loaded language helper without importing from draw."""
    try:
        module = sys.modules.get(f"{__package__}.ui_language_runtime")
        candidate = getattr(module, name, None) if module is not None else None
        return candidate if callable(candidate) else None
    except Exception:
        return None


def _sf_split_bilingual_message(msgid: str):
    try:
        shared_split = _sf_loaded_ui_language_callable('split_bilingual')
        pair = shared_split(msgid) if shared_split is not None else None
        if pair:
            return pair
    except Exception:
        pass
    if not isinstance(msgid, str):
        return None
    text = msgid.strip()
    if not text:
        return None
    for sep in (' / ', ' ｜ ', ' | ', '：', ' : '):
        cursor = 0
        candidates = []
        while True:
            idx = text.find(sep, cursor)
            if idx < 0:
                break
            left = text[:idx].strip()
            right = text[idx + len(sep):].strip()
            left_ja = bool(re.search(r'[ぁ-んァ-ン一-龯]', left))
            right_ja = bool(re.search(r'[ぁ-んァ-ン一-龯]', right))
            if left and right and right_ja and not left_ja:
                if not (re.search(r'[A-Za-z]', right) and (len(left) < 8 or len(left.split()) < 2)):
                    candidates.append((len(re.findall(r'[A-Za-z]', right)), -idx, left, right))
            elif left and right and left_ja and not right_ja:
                if not (re.search(r'[A-Za-z]', left) and (len(right) < 8 or len(right.split()) < 2)):
                    candidates.append((len(re.findall(r'[A-Za-z]', left)), -idx, right, left))
            cursor = idx + len(sep)
        if candidates:
            candidates.sort()
            return candidates[0][2], candidates[0][3]
    if '/' in text:
        left, right = text.rsplit('/', 1)
        left = left.strip()
        right = right.strip()
        if left and right and re.search(r'[ぁ-んァ-ン一-龯]', right) and not re.search(r'[ぁ-んァ-ン一-龯]', left):
            return left, right
        if left and right and re.search(r'[ぁ-んァ-ン一-龯]', left) and not re.search(r'[ぁ-んァ-ン一-龯]', right):
            return right, left
    return None


def _sf_strip_bilingual_source(msgid: str) -> str:
    pair = _sf_split_bilingual_message(msgid)
    return pair[0] if pair else msgid


def _sf_locale_clean_message(msgid: str) -> str:
    pair = _sf_split_bilingual_message(msgid)
    if not pair:
        return msgid
    # Always hand Blender the English source msgid and let Blender's translation
    # system decide whether the current UI should remain English or be translated.
    # This keeps the add-on in sync with Blender's global language preferences.
    return pair[0]


def _sf_register_auto_bilingual_translations():
    """Merge the build-time source translation cache on every Blender path."""
    ja = translation_dict.setdefault("ja_JP", {})
    try:
        from .auto_bilingual_generated import AUTO_BILINGUAL_TRANSLATIONS
    except Exception:
        AUTO_BILINGUAL_TRANSLATIONS = ()
    for original, english, japanese in AUTO_BILINGUAL_TRANSLATIONS:
        ja.setdefault(("*", original), japanese)
        ja.setdefault(("*", english), japanese)


_sf_register_auto_bilingual_translations()


def _sf_translate_without_import(kind: str, msgid: str) -> str:
    cleaned = _sf_locale_clean_message(msgid)
    loaded = _sf_loaded_ui_language_callable(kind)
    if loaded is not None:
        try:
            return loaded(msgid)
        except Exception:
            pass
    try:
        translations = bpy.app.translations
        if kind == 'iface':
            translated = translations.pgettext_iface(cleaned)
        elif kind == 'tip':
            translated = translations.pgettext_tip(cleaned)
        else:
            translated = translations.pgettext(cleaned)
    except Exception:
        translated = cleaned
    return translated or cleaned


def _t(msgid: str) -> str:
    return _sf_translate_without_import('iface', msgid)


def _tt(msgid: str) -> str:
    return _sf_translate_without_import('tip', msgid)


def _tr(msgid: str) -> str:
    return _sf_translate_without_import('data', msgid)


def _addon_prefs(context: bpy.types.Context | None):
    """Return the persistent N-panel settings PropertyGroup.

    User-facing Smart File settings are stored on WindowManager.sf_addon_settings
    and are persisted in Blender config/Smart_File_Suite/Smart_File_Suite.json. Blender Add-on
    Preferences properties are intentionally not used for this UI.
    """
    context = context or getattr(bpy, "context", None)
    try:
        wm = getattr(context, "window_manager", None)
        settings = getattr(wm, "sf_addon_settings", None) if wm is not None else None
        if settings is not None:
            return settings
    except Exception:
        pass
    return None


def _sf_draw_complete_preferences(layout, context) -> None:
    """Draw the legacy complete settings surface only on explicit request."""
    prefs = _addon_prefs(context)
    if prefs is None:
        layout.label(text=_t('N-panel settings are not available yet.'), icon='ERROR')
        return
    pref_cls = type(prefs)
    draw_fn = getattr(pref_cls, '_smart_file_panel_draw', None)
    if not callable(draw_fn):
        draw_fn = getattr(pref_cls, 'draw', None)
    if not callable(draw_fn):
        layout.label(text=_t('N-panel settings draw function is unavailable.'), icon='ERROR')
        return
    sentinel = object()
    previous_layout = getattr(pref_cls, 'layout', sentinel)
    previous_flag = getattr(pref_cls, '_smart_file_panel_preferences_draw', sentinel)
    try:
        setattr(pref_cls, 'layout', layout)
        setattr(pref_cls, '_smart_file_panel_preferences_draw', True)
        draw_fn(prefs, context)
    finally:
        try:
            if previous_layout is sentinel:
                delattr(pref_cls, 'layout')
            else:
                setattr(pref_cls, 'layout', previous_layout)
        except Exception:
            pass
        try:
            if previous_flag is sentinel:
                delattr(pref_cls, '_smart_file_panel_preferences_draw')
            else:
                setattr(pref_cls, '_smart_file_panel_preferences_draw', previous_flag)
        except Exception:
            pass


def _sf_draw_addon_preferences_inside_smart_file_panel(layout, context) -> None:
    """Draw a bounded settings summary; full settings live in an explicit dialog."""
    prefs = _addon_prefs(context)
    box = layout.box()
    box.label(text=_t('Settings'), icon='PREFERENCES')
    if prefs is None:
        box.label(text=_t('N-panel settings are not available yet.'), icon='ERROR')
        return

    # These are the common settings users need while working. Keeping this
    # surface bounded prevents hundreds of controls and index diagnostics from
    # being rebuilt on every Sidebar redraw.
    for prop_name in (
        'ui_launcher_popup_width',
        'ui_home_density',
        'max_recent',
        'activity_log_limit',
    ):
        if hasattr(prefs, prop_name):
            try:
                box.prop(prefs, prop_name)
            except Exception:
                pass
    row = box.row(align=True)
    try:
        row.operator(
            'wm.sfs_system_open_detailed_settings',
            text=_t('Detailed Settings...'),
            icon='PREFERENCES',
        )
    except Exception:
        pass
    try:
        row.operator(
            'wm.sfs_system_save_preferences',
            text=_t('Save Preferences'),
            icon='FILE_TICK',
        )
    except Exception:
        pass


def _norm_path(p: str) -> str:
    raw = str(p or '')
    if not raw.strip():
        return ''
    expanded = os.path.expanduser(os.path.expandvars(raw))
    try:
        return os.path.normpath(bpy.path.abspath(expanded))
    except Exception:
        try:
            return os.path.normpath(expanded)
        except Exception:
            return os.path.normpath(raw)

_SF_ENUM_STRING_CACHE: dict[str, str] = {}


def _sf_stable_enum_items(items):
    'Return EnumProperty items with globally-referenced strings.\n\n    Blender keeps raw references to dynamic enum strings. Keeping the string\n    objects alive at module scope avoids fragile behavior during redraw and\n    reload cycles.'
    stable = []
    for item in items or []:
        if not isinstance(item, (list, tuple)):
            continue
        normalized = []
        for value in item:
            if isinstance(value, str):
                cached = _SF_ENUM_STRING_CACHE.get(value)
                if cached is None:
                    _SF_ENUM_STRING_CACHE[value] = value
                    cached = value
                normalized.append(cached)
            else:
                normalized.append(value)
        stable.append(tuple(normalized))
    return stable



def _sf_blender_version_string() -> str:
    """Return Blender's major.minor CONFIG version folder."""
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def _sf_extension_package_name() -> str:
    package_name = str(globals().get('__package__') or __package__ or __name__ or '').strip()
    return package_name or 'smart_file_suite'


def _sf_user_default_dir(*parts: str, create: bool = True) -> str:
    try:
        from .storage_paths import user_default_dir
        return _norm_path(user_default_dir(*parts, create=create))
    except Exception:
        pass
    cleaned = [str(part or '').strip().strip('/\\') for part in parts if str(part or '').strip()]
    try:
        base = bpy.utils.user_resource('CONFIG', create=False) or ''
    except Exception:
        base = ''
    if not base:
        if os.name == 'nt':
            root = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
            base = os.path.join(root, 'Blender Foundation', 'Blender', _sf_blender_version_string(), 'config')
        else:
            base = os.path.join(os.environ.get('XDG_CONFIG_HOME', os.path.join(os.path.expanduser('~'), '.config')), 'blender', _sf_blender_version_string(), 'config')
    path = _norm_path(os.path.join(base, 'Smart_File_Suite', *cleaned))
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def _sf_user_default_file(filename: str, *parts: str, create_parent: bool = True) -> str:
    safe_name = os.path.basename(str(filename or '').strip()) or 'untitled'
    directory = _sf_user_default_dir(*parts, create=create_parent)
    path = _norm_path(os.path.join(directory, safe_name))
    if create_parent:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
        except Exception:
            pass
    return path


def _sf_project_or_user_default_dir(subdir: str = 'handoff') -> str:
    # Automatic Smart File handoff/support files stay inside the suite CONFIG
    # root. User-selected export/import paths are handled by
    # their own file browser operators and are not redirected here.
    return _sf_user_default_dir(subdir, create=True)


def _data_from_attr_for_mode(mode: str) -> str:
    return {
        'OBJECTS': 'objects',
        'COLLECTIONS': 'collections',
        'MATERIALS': 'materials',
        'NODE_GROUPS': 'node_groups',
        'ACTIONS': 'actions',
        'WORLDS': 'worlds',
    }[mode]


def _wm_dir_for_mode(mode: str) -> str:
    return {
        'OBJECTS': 'Object',
        'COLLECTIONS': 'Collection',
        'MATERIALS': 'Material',
        'NODE_GROUPS': 'NodeTree',
        'ACTIONS': 'Action',
        'WORLDS': 'World',
    }[mode]


def _reload_items(context) -> int:
    'Refresh WindowManager.sf_items from the current source file and mode.\n\n    This helper is used by the main browser, quick-list reopen actions, and\n    Reference Manager shortcuts. It silently clears stale rows when the file is\n    missing or unreadable so UI callbacks do not hard-fail.'
    wm = getattr(context, 'window_manager', None)
    if wm is None or not hasattr(wm, 'sf_items'):
        return 0

    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')
    mode = str(getattr(wm, 'sf_mode', 'OBJECTS') or 'OBJECTS')

    prev_selected = {str(getattr(it, 'name', '') or ''): bool(getattr(it, 'is_selected', False)) for it in getattr(wm, 'sf_items', []) or []}
    prev_active_name = ''
    try:
        active_index = int(getattr(wm, 'sf_active_index', 0) or 0)
        items = getattr(wm, 'sf_items', [])
        if 0 <= active_index < len(items):
            prev_active_name = str(getattr(items[active_index], 'name', '') or '')
    except Exception:
        prev_active_name = ''

    def _clear():
        try:
            wm.sf_items.clear()
        except Exception:
            pass
        try:
            wm.sf_active_index = 0
        except Exception:
            pass
        return 0

    if not filepath or not os.path.isfile(filepath):
        return _clear()

    try:
        attr = _data_from_attr_for_mode(mode)
    except Exception:
        try:
            wm.sf_mode = 'OBJECTS'
        except Exception:
            pass
        attr = 'objects'

    try:
        with bpy.data.libraries.load(filepath, link=False) as (data_from, _data_to):
            names = list(getattr(data_from, attr, []) or [])
    except Exception:
        return _clear()

    names = sorted({str(n) for n in names if str(n or '').strip()}, key=lambda s: s.lower())

    try:
        wm.sf_items.clear()
        active_index = 0
        for i, name in enumerate(names):
            item = wm.sf_items.add()
            item.name = name
            item.is_selected = prev_selected.get(name, False)
            if prev_active_name and name == prev_active_name:
                active_index = i
        wm.sf_active_index = active_index if names else 0
    except Exception:
        return 0

    return len(names)


def _mode_icon(mode: str) -> str:
    return {
        'OBJECTS': 'OBJECT_DATA',
        'COLLECTIONS': 'OUTLINER_COLLECTION',
        'MATERIALS': 'MATERIAL',
        'NODE_GROUPS': 'NODETREE',
        'ACTIONS': 'ACTION',
        'WORLDS': 'WORLD',
    }[mode]



def _find_layer_collection(layer_col: bpy.types.LayerCollection, target: bpy.types.Collection):
    if layer_col.collection == target:
        return layer_col
    for child in layer_col.children:
        found = _find_layer_collection(child, target)
        if found:
            return found
    return None


def _snapshot_ptrs_for_mode(mode: str) -> set[int]:
    attr = _data_from_attr_for_mode(mode)
    col = getattr(bpy.data, attr, None)
    if col is None:
        return set()
    out: set[int] = set()
    for idb in col:
        try:
            out.add(int(idb.as_pointer()))
        except Exception:
            out.add(id(idb))
    return out


def _get_new_ids_for_mode(mode: str, before_ptrs: set[int]) -> list:
    attr = _data_from_attr_for_mode(mode)
    col = getattr(bpy.data, attr, None)
    if col is None:
        return []
    new_ids = []
    for idb in col:
        try:
            ptr = int(idb.as_pointer())
        except Exception:
            ptr = id(idb)
        if ptr not in before_ptrs:
            new_ids.append(idb)
    return new_ids


def _strict_load_with_wm_append(context: bpy.types.Context, filepath: str, mode: str, names: list[str], do_link: bool):
    "Strict loader: use Blender's built-in wm.append with explicit paths.\n    This generally loads dependencies more faithfully than bpy.data.libraries.load, at the cost of speed."
    # Ensure active collection is the destination so wm.append links correctly.
    try:
        dest_col = context.collection
        layer_col = _find_layer_collection(context.view_layer.layer_collection, dest_col)
        if layer_col:
            context.view_layer.active_layer_collection = layer_col
    except Exception:
        pass

    dir_name = _wm_dir_for_mode(mode)
    directory = filepath + os.sep + dir_name + os.sep
    before = _snapshot_ptrs_for_mode(mode)

    for n in names:
        fp = directory + n
        kwargs = dict(
            filepath=fp,
            directory=directory,
            filename=n,
            link=do_link,
            autoselect=False,
        )
        # Version-robust: Blender has used different naming (active_collection vs active_layer).
        try:
            props = bpy.ops.wm.append.get_rna_type().properties
            if "active_collection" in props:
                kwargs["active_collection"] = True
            elif "active_layer" in props:
                kwargs["active_layer"] = True
        except Exception:
            kwargs["active_collection"] = True

        bpy.ops.wm.append(**kwargs)

    return _get_new_ids_for_mode(mode, before)

def _is_linked_id(idblock) -> bool:
    try:
        return bool(getattr(idblock, "library", None))
    except Exception:
        return False


def _sf_get_library_by_fp(fp: str):
    fp_n = _norm_path(fp)
    try:
        for lib in list(getattr(bpy.data, "libraries", []) or []):
            if _norm_path(getattr(lib, "filepath", "") or "") == fp_n:
                return lib
    except Exception:
        pass
    return None


def _sf_get_library_asset_id(fp: str) -> str:
    lib = _sf_get_library_by_fp(fp)
    if not lib:
        return ""
    # Prefer the new Smart File key, but keep backward compatibility with
    # older Smart Asset libraries that still store sa_asset_id.
    for key in ("sf_asset_id", "sa_asset_id"):
        try:
            value = str(lib.get(key, "") or "")
            if value:
                return value
        except Exception:
            try:
                value = str(lib[key])
                if value:
                    return value
            except Exception:
                pass
    return ""


def _sf_set_library_asset_id(fp: str, asset_id: str):
    if not asset_id:
        return
    lib = _sf_get_library_by_fp(fp)
    if not lib:
        return
    try:
        lib["sf_asset_id"] = str(asset_id)
    except Exception:
        pass
    try:
        lib["sa_asset_id"] = str(asset_id)
    except Exception:
        pass


def _add_recent(context: bpy.types.Context, filepath: str):
    prefs = _addon_prefs(context)
    if not prefs:
        return
    fp = _norm_path(filepath)
    if not fp:
        return

    # Remove duplicates
    for i in range(len(prefs.recent_paths) - 1, -1, -1):
        if _norm_path(prefs.recent_paths[i].path) == fp:
            prefs.recent_paths.remove(i)
    it = prefs.recent_paths.add()
    it.path = fp
    prefs.recent_paths.move(len(prefs.recent_paths) - 1, 0)
    while len(prefs.recent_paths) > prefs.max_recent:
        prefs.recent_paths.remove(len(prefs.recent_paths) - 1)


def _ensure_collection(context: bpy.types.Context, name: str) -> bpy.types.Collection:
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        context.collection.children.link(col)
    else:
        # Ensure visibility under current collection.
        # Blender collection children are ID collections, so name-string membership
        # checks can fail or silently skip linking depending on the runtime context.
        try:
            child_exists = False
            getter = getattr(context.collection.children, 'get', None)
            if callable(getter):
                try:
                    child_exists = getter(col.name) is not None
                except Exception:
                    child_exists = False
            if not child_exists:
                try:
                    child_exists = any(getattr(item, 'name', '') == col.name for item in context.collection.children)
                except Exception:
                    child_exists = False
            if not child_exists:
                context.collection.children.link(col)
        except Exception:
            pass
    return col


def _group_bounds_world(objs: list[bpy.types.Object]):
    import math
    from mathutils import Vector

    if not objs:
        z = Vector((0.0, 0.0, 0.0))
        return z, z

    mn = Vector((math.inf, math.inf, math.inf))
    mx = Vector((-math.inf, -math.inf, -math.inf))
    for o in objs:
        try:
            bb = [Vector(corner) for corner in o.bound_box]
            for v in bb:
                w = o.matrix_world @ v
                mn.x, mn.y, mn.z = min(mn.x, w.x), min(mn.y, w.y), min(mn.z, w.z)
                mx.x, mx.y, mx.z = max(mx.x, w.x), max(mx.y, w.y), max(mx.z, w.z)
        except Exception:
            w = o.matrix_world.translation
            mn.x, mn.y, mn.z = min(mn.x, w.x), min(mn.y, w.y), min(mn.z, w.z)
            mx.x, mx.y, mx.z = max(mx.x, w.x), max(mx.y, w.y), max(mx.z, w.z)
    return mn, mx


def _offset_objects(objs: list[bpy.types.Object], delta):
    if not objs:
        return
    for o in objs:
        o.location = o.location + delta


def _apply_placement(context: bpy.types.Context, objs: list[bpy.types.Object], placement: str,
                     offset_vec, grid_spacing, columns: int):
    from mathutils import Vector

    if not objs:
        return
    explicit_offset = Vector(offset_vec)

    if placement == 'ORIGINAL':
        _offset_objects(objs, explicit_offset)
        return

    mn, mx = _group_bounds_world(objs)
    center = (mn + mx) * 0.5

    if placement == 'CURSOR':
        target = context.scene.cursor.location
        delta = (target - center) + explicit_offset
        _offset_objects(objs, delta)
        return

    if placement == 'ACTIVE':
        ao = context.view_layer.objects.active
        if ao is None:
            _offset_objects(objs, explicit_offset)
            return
        target = ao.matrix_world.translation
        delta = (target - center) + explicit_offset
        _offset_objects(objs, delta)
        return

    if placement == 'FLOOR':
        delta = Vector((0.0, 0.0, -mn.z)) + explicit_offset
        _offset_objects(objs, delta)
        return

    if placement == 'GRID':
        sp = Vector(grid_spacing)
        cols = max(1, int(columns))
        base = context.scene.cursor.location
        for i, o in enumerate(objs):
            r = i // cols
            c = i % cols
            o.location = base + Vector((sp.x * c, sp.y * r, 0.0)) + explicit_offset
        return


def _try_frame_view(context: bpy.types.Context):
    # Try framing selected objects in any VIEW_3D area.
    try:
        win = context.window
        scr = win.screen
    except Exception:
        return

    for area in scr.areas:
        if area.type != 'VIEW_3D':
            continue
        for region in area.regions:
            if region.type != 'WINDOW':
                continue
            override = {
                "window": win,
                "screen": scr,
                "area": area,
                "region": region,
                "scene": context.scene,
                "view_layer": context.view_layer,
            }
            try:
                with context.temp_override(**override):
                    bpy.ops.view3d.view_selected()
            except Exception:
                pass
            return


def _clear_parent_keep_world(obj: bpy.types.Object):
    # Keep world transform while clearing parent
    mw = obj.matrix_world.copy()
    obj.parent = None
    obj.matrix_world = mw


def _clear_constraints_keep_world(obj: bpy.types.Object):
    mw = obj.matrix_world.copy()
    try:
        obj.constraints.clear()
    except Exception:
        # Some constraints collections may not support clear()
        for c in list(getattr(obj, "constraints", [])):
            try:
                obj.constraints.remove(c)
            except Exception:
                pass
    obj.matrix_world = mw


def _compute_related_object_names(objs: list[bpy.types.Object]) -> set[str]:
    """Best-effort discovery of related object names from already-loaded objects."""
    related: set[str] = set()

    def add_parent_chain(o: bpy.types.Object):
        p = o.parent
        while p is not None:
            related.add(p.name)
            p = p.parent

    def add_constraint_targets(o: bpy.types.Object):
        for c in getattr(o, "constraints", []):
            t = getattr(c, "target", None)
            if isinstance(t, bpy.types.Object):
                related.add(t.name)

    def add_modifier_targets(o: bpy.types.Object):
        for m in getattr(o, "modifiers", []):
            for attr in (
                "object",
                "target",
                "mirror_object",
                "offset_object",
                "start_cap",
                "end_cap",
                "curve",
                "lattice",
            ):
                if hasattr(m, attr):
                    v = getattr(m, attr)
                    if isinstance(v, bpy.types.Object):
                        related.add(v.name)

    def add_driver_ids(o: bpy.types.Object):
        ad = getattr(o, "animation_data", None)
        if not ad:
            return
        for fc in getattr(ad, "drivers", []) or []:
            drv = getattr(fc, "driver", None)
            if not drv:
                continue
            for var in drv.variables:
                for targ in var.targets:
                    idb = getattr(targ, "id", None)
                    if isinstance(idb, bpy.types.Object):
                        related.add(idb.name)

    for o in objs:
        add_parent_chain(o)
        add_constraint_targets(o)
        add_modifier_targets(o)
        add_driver_ids(o)

    return related


# -----------------------------------------------------------------------------
#  Properties
# -----------------------------------------------------------------------------


class SF_PathItem(bpy.types.PropertyGroup):
    bl_description = 'Store a recent or favorite source file path so Smart File can reopen familiar .blend sources quickly and safely'

    path: StringProperty(name='File', subtype='FILE_PATH')


class SF_Item(bpy.types.PropertyGroup):
    bl_description = 'Represent one datablock discovered inside a source .blend file so you can inspect it and decide whether to import it'

    name: StringProperty(
        name='Items',
        description='Name of the datablock found in the selected source .blend file.',
    )
    is_selected: BoolProperty(
        name='Select',
        default=False,
        description='Turn this on to include this datablock in the next import operation.',
    )




# -----------------------------------------------------------------------------
#  Asset Reader (Phase 1): Preferences data
# -----------------------------------------------------------------------------

class SF_LibraryRoot(bpy.types.PropertyGroup):
    bl_description = 'Describe one library root folder used for indexing, catalog merging, relink checks, and source browsing'

    path: StringProperty(name='Root', subtype='DIR_PATH')
    enabled: BoolProperty(name='Enabled', default=True)
    priority: IntProperty(name='Priority', default=0, description='Higher priority roots win when merging catalogs (larger number = higher priority)')


class SF_ContextRoot(bpy.types.PropertyGroup):
    bl_description = 'Describe one named context root used by suffix-aware relink, root migration, drift watch, and handoff manifests'

    alias: StringProperty(name='Alias', default="", description='Short stable name used in exported context manifests and root maps.')
    path: StringProperty(name='Root', subtype='DIR_PATH', default="", description='Base folder used as a named project root for relink, watch, and handoff.')
    env_var: StringProperty(name='Environment Variable', default="", description='Optional environment-variable name such as SHOW_ROOT or ASSET_ROOT. When filled, the stored path may be relative to that variable, and the resolved folder is expanded at runtime.')
    kind: EnumProperty(
        name='Kind',
        items=[
            ('ANY', 'Any', 'Use this root for every supported external file kind.'),
            ('LIBRARY', 'Libraries', 'Prefer this root when resolving linked .blend libraries.'),
            ('IMAGE', 'Images', 'Prefer this root when resolving textures and other image files.'),
            ('CACHEFILE', 'Caches', 'Prefer this root when resolving Alembic, USD, and other cache-style files.'),
            ('VOLUME', 'Volumes', 'Prefer this root when resolving VDB and other volume files.'),
            ('MOVIECLIP', 'Movie Clips', 'Prefer this root when resolving tracked movie clips and video sequences.'),
            ('SOUND', 'Sounds', 'Prefer this root when resolving external audio files.'),
            ('VECTORFONT', 'Fonts', 'Prefer this root when resolving external vector font files.'),
            ('TEXT', 'Texts', 'Prefer this root when resolving external text datablocks.'),
            ('UNKNOWN', 'Other', 'Use this root for unsupported or uncategorized file references.'),
        ],
        default='ANY',
        description='Optional external-file category this root should specialize in.',
    )
    enabled: BoolProperty(name='Enabled', default=True, description='Allow this Context Root to participate in suffix-aware recovery, drift watch, and manifest export.')
    priority: IntProperty(name='Priority', default=0, description='Higher values win when multiple roots can resolve the same suffix.')
    notes: StringProperty(name='Notes', default="", description='Optional helper note for the team or for future handoff.')

def _sf_cm_on_item_include_update(self, _context):
    try:
        _sf_catalog_merge_selection_sync_from_item(self)
    except Exception:
        pass


class SF_CM_ReviewItem(bpy.types.PropertyGroup):
    bl_description = 'Store one catalog review row so you can inspect merge actions, overrides, and publish choices before writing files'

    include: BoolProperty(name='Include', default=True, update=_sf_cm_on_item_include_update)
    enabled: BoolProperty(name='Enabled', default=True, options={'HIDDEN'})
    level: EnumProperty(
        name='Level',
        items=[
            ('ROOT', "Root", ""),
            ('ASSET', "Asset", ""),
            ('ENTRY', "Entry", ""),
        ],
        default='ENTRY',
    )
    action: StringProperty(name='Action', default="")
    label: StringProperty(name='Label', default="")
    note: StringProperty(name='Note', default="")
    root_path: StringProperty(name='Root Path', subtype='DIR_PATH', default="")
    target_catalog_path: StringProperty(name='Target Catalog', subtype='FILE_PATH', default="")
    draft_key: StringProperty(name='Draft Key', default="")
    target_key: StringProperty(name='Target Key', default="")
    asset_id: StringProperty(name='Asset ID', default="")
    entry_identity: StringProperty(name='Entry Identity', default="")
    blend: StringProperty(name='Blend', default="")
    draft_category: StringProperty(name='Draft Category', default="")
    version: IntProperty(name='Version', default=0)
    entry_count: IntProperty(name='Entry Count', default=0)
    node_key: StringProperty(name='Node Key', default="", options={'HIDDEN'})
    parent_key: StringProperty(name='Parent Key', default="", options={'HIDDEN'})
    depth: IntProperty(name='Depth', default=0, options={'HIDDEN'})

    ovr_has_preview: BoolProperty(name='Has Preview Option', default=False, options={'HIDDEN'})
    ovr_has_meta: BoolProperty(name='Has Meta Option', default=False, options={'HIDDEN'})
    ovr_has_category: BoolProperty(name='Has Category Option', default=False, options={'HIDDEN'})
    ovr_has_tags: BoolProperty(name='Has Tags Option', default=False, options={'HIDDEN'})
    ovr_has_key_rename: BoolProperty(name='Has Key Rename Option', default=False, options={'HIDDEN'})

    ovr_use_preview: BoolProperty(name='Use preview', default=False)
    ovr_use_meta: BoolProperty(name='Use meta', default=False)
    ovr_use_category: BoolProperty(name='Use category', default=False)
    ovr_use_tags: BoolProperty(name='Use tags', default=False)
    ovr_allow_key_rename: BoolProperty(name='Allow key rename', default=True)


class SF_CM_OverridePreset(bpy.types.PropertyGroup):
    bl_description = 'Save one reusable override preset so repeated catalog review decisions stay consistent across similar assets'

    name: StringProperty(name='Name', default="")
    action_filter: EnumProperty(
        name='Action Filter',
        items=[
            ('ANY', 'Any', ''),
            ('ADD_ASSET', 'Add Asset', ''),
            ('ADD_ENTRY', 'Add Entry', ''),
            ('FILL_METADATA', 'Fill Metadata', ''),
            ('RENAME_ASSET_KEY', 'Rename Asset Key', ''),
        ],
        default='ANY',
    )
    use_preview: BoolProperty(name='Use preview', default=True)
    use_meta: BoolProperty(name='Use meta', default=True)
    use_category: BoolProperty(name='Use category', default=True)
    use_tags: BoolProperty(name='Use tags', default=True)
    allow_key_rename: BoolProperty(name='Allow key rename', default=True)


class SF_CM_OverrideRoute(bpy.types.PropertyGroup):
    bl_description = 'Describe one override route that maps review actions, filters, and optional preset choices to a specific workflow path'

    name: StringProperty(name='Name', default="")
    enabled: BoolProperty(name='Enabled', default=True)
    preset_name: StringProperty(name='Preset name', default="")
    action_filter: EnumProperty(
        name='Action Filter',
        items=[
            ('ANY', 'Any', ''),
            ('ADD_ASSET', 'Add Asset', ''),
            ('ADD_ENTRY', 'Add Entry', ''),
            ('FILL_METADATA', 'Fill Metadata', ''),
            ('RENAME_ASSET_KEY', 'Rename Asset Key', ''),
        ],
        default='ANY',
    )
    root_filter: StringProperty(name='Root filter', default="")
    category_filter: StringProperty(name='Category filter', default="")


class SF_WorkspaceProfile(bpy.types.PropertyGroup):
    bl_description = 'Save one reusable Smart File workspace profile so beginners can reopen a proven setup without rebuilding every option'

    name: StringProperty(name='Profile Name', default="", description='Readable name used for a reusable Smart File workspace setup')
    tag: StringProperty(name='Tag', default="", description='Short category such as Import, Maintain, Publish, Explore, or Recover used to group this profile')
    notes: StringProperty(name='Notes', default="", description='Optional helper note shown on profile cards and reports so newer users know when to use this setup')
    pinned: BoolProperty(name='Pinned', default=False, description='Keep this profile emphasized near the top of cards and quick access lists')
    mode: StringProperty(default='OBJECTS')
    import_mode: StringProperty(default='APPEND')
    strict_loader: BoolProperty(default=False)
    include_dependencies: BoolProperty(default=True)
    bake_world: BoolProperty(default=False)
    clear_parent: BoolProperty(default=True)
    clear_constraints: BoolProperty(default=False)
    prefix: StringProperty(default="")
    collision: StringProperty(default='DUPLICATE')
    apply_prefix_to_linked: BoolProperty(default=False)
    put_in_collection: BoolProperty(default=True)
    collection_name_mode: StringProperty(default='FILE')
    collection_name: StringProperty(default="")
    placement: StringProperty(default='ORIGINAL')
    offset: FloatVectorProperty(size=3, default=(0.0, 0.0, 0.0), subtype='TRANSLATION')
    grid_spacing: FloatVectorProperty(size=3, default=(2.0, 2.0, 0.0), subtype='TRANSLATION')
    grid_columns: IntProperty(default=5, min=1, max=100)
    select_imported: BoolProperty(default=True)
    frame_view: BoolProperty(default=False)


def _sf_profile_tag_label(profile) -> str:
    if not profile:
        return ""
    explicit = str(getattr(profile, 'tag', '') or '').strip()
    if explicit:
        return explicit
    import_mode = str(getattr(profile, 'import_mode', '') or '').upper()
    mode = str(getattr(profile, 'mode', '') or '').upper()
    if import_mode == 'LINK_OVERRIDE':
        return 'Publish'
    if import_mode == 'LINK':
        return 'Maintain'
    if mode in {'MATERIALS', 'NODE_GROUPS', 'ACTIONS', 'WORLDS'}:
        return 'Explore'
    return 'Import'


def _sf_profile_summary(profile) -> str:
    if not profile:
        return ""
    mode = str(getattr(profile, 'mode', '') or '')
    import_mode = str(getattr(profile, 'import_mode', '') or '')
    placement = str(getattr(profile, 'placement', '') or '')
    tag = _sf_profile_tag_label(profile)
    return f"{tag} · {mode} · {import_mode} · {placement}" if tag else f"{mode} · {import_mode} · {placement}"




def _sf_tag_redraw_view3d(context=None) -> None:
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _sf_settings_restore_barrier_active() -> bool:
    """Check the restore barrier without importing or materializing settings RNA."""
    package = str(__package__ or __name__ or '').strip()
    module = sys.modules.get(f'{package}.settings') if package else None
    return bool(
        module is not None
        and (
            getattr(module, '_STARTUP_RESTORE_PENDING', False)
            or getattr(module, '_APPLYING', False)
        )
    )


def _sf_save_persistent_settings(context=None, *, force: bool = False, allow_disabled: bool = False) -> bool:
    if _sf_settings_restore_barrier_active():
        return False
    try:
        package = str(__package__ or __name__ or '').strip()
        _sf_persist = sys.modules.get(f'{package}.settings') if package else None
        if _sf_persist is None:
            import importlib
            _sf_persist = importlib.import_module(f'{package}.settings')
        if not force and hasattr(_sf_persist, 'schedule_save'):
            return bool(_sf_persist.schedule_save(context or getattr(bpy, 'context', None)))
        elif hasattr(_sf_persist, 'save_now'):
            return bool(_sf_persist.save_now(
                context or getattr(bpy, 'context', None),
                force=bool(force),
                allow_disabled=bool(allow_disabled),
            ))
    except Exception:
        return False
    return False


def _sf_always_on_pref_update(self, context):
    if _sf_settings_restore_barrier_active():
        return
    _sf_save_persistent_settings(context, force=False)
    _sf_tag_redraw_view3d(context)


_SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = False
_SF_HISTORY_RUNTIME_SYNC_DELAY = 0.12
_SF_HISTORY_RUNTIME_SYNC_DEADLINE = 0.0


def _sf_history_runtime_sync_now(context=None) -> None:
    reason = ''
    try:
        from .history_auto_save.core import runtime as _sf_hist_runtime
        ok = bool(_sf_hist_runtime.sync_listener_runtime(
            context=context or getattr(bpy, 'context', None),
            reason='preference update',
            preserve_state=True,
        ))
        if not ok:
            status = _sf_hist_runtime.get_runtime_status(context or getattr(bpy, 'context', None))
            reason = str(
                status.get('last_runtime_error')
                or status.get('last_save_error')
                or 'History preference synchronization returned False'
            )
    except Exception as exc:
        reason = f"{type(exc).__name__}: {exc}"
    if reason:
        try:
            repair = globals().get('_sf_history_request_repair')
            if callable(repair):
                repair(reason)
        except Exception:
            pass


def _sf_history_runtime_sync_timer():
    global _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE, _SF_HISTORY_RUNTIME_SYNC_DEADLINE
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if bool(getattr(wm, 'is_interface_locked', False)):
        return 0.2
    remaining = float(_SF_HISTORY_RUNTIME_SYNC_DEADLINE or 0.0) - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = False
    _SF_HISTORY_RUNTIME_SYNC_DEADLINE = 0.0
    _sf_history_runtime_sync_now(getattr(bpy, 'context', None))
    return None


def _sf_cancel_history_runtime_sync() -> None:
    global _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE, _SF_HISTORY_RUNTIME_SYNC_DEADLINE
    _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = False
    _SF_HISTORY_RUNTIME_SYNC_DEADLINE = 0.0
    try:
        if bpy.app.timers.is_registered(_sf_history_runtime_sync_timer):
            bpy.app.timers.unregister(_sf_history_runtime_sync_timer)
    except Exception:
        pass


def _sf_schedule_history_runtime_sync(context=None) -> None:
    global _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE, _SF_HISTORY_RUNTIME_SYNC_DEADLINE
    del context
    _SF_HISTORY_RUNTIME_SYNC_DEADLINE = time.monotonic() + _SF_HISTORY_RUNTIME_SYNC_DELAY
    try:
        if bpy.app.timers.is_registered(_sf_history_runtime_sync_timer):
            _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = True
            return
        bpy.app.timers.register(
            _sf_history_runtime_sync_timer,
            first_interval=_SF_HISTORY_RUNTIME_SYNC_DELAY,
            persistent=False,
        )
    except Exception:
        _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = False
        _SF_HISTORY_RUNTIME_SYNC_DEADLINE = 0.0
        _sf_history_runtime_sync_now(getattr(bpy, 'context', None))
        return
    _SF_HISTORY_RUNTIME_SYNC_TIMER_ACTIVE = True


def _sf_history_listener_pref_update(self, context):
    # settings.apply_all may assign several restored fields in one transaction.
    # Suppress per-property runtime churn while startup restoration is pending;
    # the root startup finalizer performs exactly one verified sync afterwards.
    restore_in_progress = _sf_settings_restore_barrier_active()
    if not restore_in_progress:
        try:
            _sf_schedule_history_runtime_sync(context)
        except Exception:
            pass
    _sf_always_on_pref_update(self, context)


def _sf_autosave_enabled_pref_update(self, context):
    """Persist only an explicit user autosave choice, then sync the runtime.

    Startup/main-settings replay is guarded by the settings service and must not
    turn an unproven legacy ``False`` into a permanent opt-out marker.
    """
    if _sf_settings_restore_barrier_active():
        return
    try:
        package = str(__package__ or __name__ or '').strip()
        _sf_settings = sys.modules.get(f'{package}.settings') if package else None
        restoring = _sf_settings_restore_barrier_active()
        handle_choice = getattr(_sf_settings, 'handle_autosave_property_update', None)
        persist_choice = getattr(_sf_settings, 'persist_autosave_user_choice', None)
        if not restoring and callable(handle_choice):
            handle_choice(self, context)
        elif not restoring and callable(persist_choice):
            persist_choice(
                context,
                bool(getattr(self, 'enable_autosave', False)),
                source='user_ui',
            )
    except Exception:
        pass
    _sf_history_listener_pref_update(self, context)


def _sf_reference_auto_pref_update(self, context):
    if _sf_settings_restore_barrier_active():
        return
    try:
        sync_fn = globals().get('_sf_rm_sync_runtime_state')
        if callable(sync_fn):
            sync_fn(context=context, run_immediately=True)
    except Exception:
        pass
    _sf_always_on_pref_update(self, context)


def _sf_bool_pref(context, name: str, default: bool = False) -> bool:
    try:
        prefs = _addon_prefs(context or getattr(bpy, 'context', None))
        if prefs is not None and hasattr(prefs, name):
            return bool(getattr(prefs, name))
    except Exception:
        pass
    return bool(default)


def _sf_sync_settings_keeper_runtime(context=None) -> bool:
    """Synchronize the single canonical N-panel settings owner exactly once."""
    if globals().get('_SF_SYNCING_SETTINGS_KEEPER'):
        return False
    globals()['_SF_SYNCING_SETTINGS_KEEPER'] = True
    error = ''
    try:
        try:
            from . import settings as _sf_persist
        except Exception as exc:
            _sf_persist = None
            error = f"settings import failed: {type(exc).__name__}: {exc}"
        if _sf_persist is None:
            globals()['_SF_SETTINGS_RUNTIME_ERROR'] = error or 'settings service unavailable'
            return False
        try:
            register_fn = getattr(_sf_persist, 'register', None)
            if not callable(register_fn) or not register_fn(
                context or getattr(bpy, 'context', None), apply_saved=False
            ):
                status_fn = getattr(_sf_persist, 'get_registration_status', None)
                status = status_fn(context) if callable(status_fn) else {}
                error = str(status.get('last_error') or 'canonical settings registration returned False')
                globals()['_SF_SETTINGS_RUNTIME_ERROR'] = error
                return False
            status_fn = getattr(_sf_persist, 'get_registration_status', None)
            status = status_fn(context) if callable(status_fn) else {}
            if not bool(status.get('registered')):
                error = str(status.get('last_error') or 'canonical settings owner is not exact')
                globals()['_SF_SETTINGS_RUNTIME_ERROR'] = error
                return False
            globals()['_SF_SETTINGS_RUNTIME_ERROR'] = ''
            return True
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            globals()['_SF_SETTINGS_RUNTIME_ERROR'] = error
            return False
    finally:
        globals()['_SF_SYNCING_SETTINGS_KEEPER'] = False

def _sf_sync_compatibility_guard_runtime(context=None) -> None:
    """Synchronize the optional guard without importing it while disabled."""
    enabled = _sf_bool_pref(context, 'enable_compatibility_guards', False)
    package = str(__package__ or '').strip()
    module_name = f"{package}.compatibility_guards" if package else 'compatibility_guards'
    _sf_compat = sys.modules.get(module_name)
    if enabled and _sf_compat is None:
        try:
            from . import compatibility_guards as _sf_compat
        except Exception:
            _sf_compat = None
    if _sf_compat is None:
        return
    try:
        callback = getattr(_sf_compat, 'register' if enabled else 'unregister', None)
        if callable(callback):
            callback()
    except Exception:
        pass


def _sf_sync_builtin_always_on_runtime(context=None) -> None:
    """Synchronize optional enabled runtimes exactly once after core startup.

    Canonical settings and History autosave are already owned by the mandatory
    register transaction.  Re-running their global status/synchronization graph
    here added duplicate cold-start work and could re-arm the same autosave
    deadline twice.  Only independently enabled optional services are handled.
    """
    context = context or getattr(bpy, 'context', None)
    _sf_sync_compatibility_guard_runtime(context)

    try:
        prefs = _addon_prefs(context)
    except Exception:
        prefs = None

    try:
        reference_enabled = bool(_rm_auto_runtime_enabled(prefs))
    except Exception:
        reference_enabled = False
    sync_reference = globals().get('_sf_rm_sync_runtime_state')
    if callable(sync_reference):
        try:
            sync_reference(context=context, run_immediately=False)
        except Exception:
            pass

    proxy_enabled = bool(
        prefs is not None
        and getattr(prefs, 'enable_automatic_proxy_cleanup', False)
    )
    package = str(__package__ or '').strip()
    proxy_name = f"{package}.scene_proxy_cleanup" if package else 'scene_proxy_cleanup'
    proxy_module = sys.modules.get(proxy_name)
    if proxy_enabled and proxy_module is None:
        try:
            from . import scene_proxy_cleanup as proxy_module
        except Exception:
            proxy_module = None
    if proxy_module is not None:
        try:
            sync = getattr(proxy_module, 'sync', None)
            if callable(sync):
                sync(proxy_enabled, context)
        except Exception:
            pass


def _sf_compatibility_guard_pref_update(self, context):
    if _sf_settings_restore_barrier_active():
        return
    _sf_sync_compatibility_guard_runtime(context)
    _sf_always_on_pref_update(self, context)


def _sf_proxy_cleanup_pref_update(self, context):
    if _sf_settings_restore_barrier_active():
        return
    try:
        from . import scene_proxy_cleanup as _sf_proxy_cleanup
        _sf_proxy_cleanup.sync(bool(getattr(self, 'enable_automatic_proxy_cleanup', False)), context)
    except Exception:
        pass
    _sf_always_on_pref_update(self, context)


def _sf_settings_keeper_pref_update(self, context):
    if _sf_settings_restore_barrier_active():
        return
    package = str(__package__ or __name__ or '').strip()
    _sf_persist = sys.modules.get(f'{package}.settings') if package else None
    enabled = bool(getattr(self, 'enable_npanel_settings_keeper', True))
    if not enabled:
        commit = getattr(_sf_persist, 'commit_keeper_transition', None)
        if callable(commit):
            commit(self, context)
        _sf_sync_settings_keeper_runtime(context)
    else:
        _sf_sync_settings_keeper_runtime(context)
        _sf_save_persistent_settings(context, force=True, allow_disabled=False)
    _sf_tag_redraw_view3d(context)


class SF_OT_system_save_preferences(bpy.types.Operator):
    bl_idname = 'wm.sfs_system_save_preferences'
    bl_label = 'Save Preferences'
    bl_description = "Save Blender preferences after writing all Smart File N-panel settings to Blender config/Smart_File_Suite/Smart_File_Suite.json"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        if not _sf_save_persistent_settings(context, force=True, allow_disabled=True):
            self.report({'ERROR'}, _t('Smart File settings could not be written.'))
            return {'CANCELLED'}
        try:
            result = bpy.ops.wm.save_userpref()
        except Exception as exc:
            self.report({'ERROR'}, _t(f"Could not save Blender preferences: {exc}"))
            return {'CANCELLED'}
        try:
            self.report({'INFO'}, _t('Preferences saved'))
        except Exception:
            pass
        return {'FINISHED'} if result != {'CANCELLED'} else {'CANCELLED'}


class SF_OT_system_open_detailed_settings(bpy.types.Operator):
    bl_idname = 'wm.sfs_system_open_detailed_settings'
    bl_label = 'Detailed Settings'
    bl_description = 'Open the complete Smart File settings only when they are needed'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def invoke(self, context, event):
        del event
        return context.window_manager.invoke_props_dialog(self, width=900)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        _sf_draw_complete_preferences(self.layout, context)


class SFS_PG_system_file_suite_preferences(bpy.types.PropertyGroup):
    bl_label = 'File Suite Preferences'
    bl_idname = __name__
    bl_description = 'Configure launcher behavior, library roots, workspace profiles, history protection, and other Smart File defaults used across the add-on'

    recent_paths: CollectionProperty(type=SF_PathItem)
    favorite_paths: CollectionProperty(type=SF_PathItem)
    max_recent: IntProperty(
        name='Max Recent',
        default=10,
        min=1,
        max=50,
        description='Maximum number of recently used source .blend files to keep in the quick access history shown by the N-panel launcher and detailed browser',
    )
    ui_show_view3d_header_menu: BoolProperty(
        name='Legacy 3D View Header Toggle',
        default=False,
        description='Legacy compatibility value. Smart File does not add a 3D View header button; use the Smart File N-panel for access.',
    )
    ui_show_file_menu: BoolProperty(
        name='Legacy File Menu Toggle',
        default=False,
        description='Legacy compatibility value. Smart File does not add a File menu entry; use the Smart File N-panel for access.',
    )
    ui_header_icon_variant: EnumProperty(
        name='Header Icon Style',
        items=[
            ('AUTO', "Auto (Brand Color)", "Use the default Smart File brand icon"),
            ('COLOR', "Brand Color", "Always use the full-color Smart File icon"),
            ('LIGHT', "Light Theme", "Use a lighter icon variant that reads well on darker headers"),
            ('DARK', "Dark Theme", "Use a darker icon variant that reads well on brighter headers"),
            ('MONO', "Monochrome", "Use a monochrome icon variant for a minimal UI"),
        ],
        default='AUTO',
        description='Choose the icon style used by the Smart File N-panel header and launcher. The artwork is packed tightly so it remains clear in Blender UI slots.',
    )

    ui_launcher_popup_width: IntProperty(
        name='Launcher Width',
        default=420,
        min=320,
        max=720,
        description='Choose how wide the Smart File start-page popup opens. Smaller values keep the popup easier to fit on screen; larger values give a little more room to quick tools.',
    )
    ui_home_density: EnumProperty(
        name='Home density',
        items=[
            ('COMFORT', "Comfort", "Use more spacing and descriptive text in home-style popups"),
            ('COMPACT', "Compact", "Fit more cards and summaries into each Smart File home view"),
        ],
        default='COMFORT',
        description='Control whether launcher, cockpit, and goal-home popups prioritize readability or information density',
    )

    workspace_profiles: CollectionProperty(type=SF_WorkspaceProfile)
    workspace_profile_name: StringProperty(
        name='Profile name',
        default="",
        description='Name used when saving the current Smart File browser settings as a reusable workspace profile so beginners can recognize when to apply it again',
    )
    workspace_profile_active_index: IntProperty(
        name='Active Profile',
        default=0,
        min=0,
        description='Internal active workspace profile row used by management actions',
    )

    workspace_profile_filter_text: StringProperty(
        name='Profile Search',
        default="",
        description='Filter workspace profile cards and lists by name, tag, notes, mode, or import mode',
    )
    workspace_profile_filter_mode: EnumProperty(
        name='Profile Filter',
        items=[
            ('ALL', "All", "Show every workspace profile"),
            ('GOAL', "Goal Matches", "Show only profiles that match the current session goal"),
            ('PINNED', "Pinned", "Show only pinned profiles"),
            ('ACTIVE_TAG', "Current Goal Tag", "Show only profiles whose tag matches the current session goal"),
        ],
        default='ALL',
        description='Choose which profiles stay visible in cards and quick lists',
    )
    activity_log_limit: IntProperty(
        name='Activity Log Limit',
        default=24,
        min=5,
        max=120,
        description='Maximum number of recent Smart File actions kept in this Blender session timeline for troubleshooting, review, and handoff notes',
    )

    enable_npanel_settings_keeper: BoolProperty(
        name='N-panel State Save',
        default=True,
        update=_sf_settings_keeper_pref_update,
        description='When enabled, Smart File saves every persistent N-panel setting after its change event and restores it across Blender launches and scene changes. Turning this off records OFF once, removes the owned persistence handlers and subscriptions, and blocks every later settings writer until it is enabled again. Other explicitly enabled runtimes keep their own independent lifecycle.',
    )
    enable_compatibility_guards: BoolProperty(
        name='Compatibility Guards',
        default=False,
        update=_sf_compatibility_guard_pref_update,
        description='Keeps the Smart File compatibility guards active so known external Smart toolset registration, missing-operator, handler, and RNA-drawing problems are patched before they create console errors or crashes. Leave enabled for mixed Smart toolset installations; disable only when debugging those external add-ons directly.',
    )
    enable_automatic_proxy_cleanup: BoolProperty(
        name='Automatic Proxy Cleanup',
        default=False,
        update=_sf_proxy_cleanup_pref_update,
        description='Continuously checks for broken Smart File proxy metadata using load/save handlers and a periodic timer. Enable only while maintaining proxy-heavy files; disabling removes every owned handler and timer. Manual cleanup remains available.',
    )

    enable_history_listener: BoolProperty(
        name='Legacy History Background Runtime',
        default=False,
        update=_sf_history_listener_pref_update,
        options={'HIDDEN'},
        description='Legacy compatibility value. Smart File now starts history background work only when Rolling Autosave or Optional Timed Restore Points require automatic timed work.',
    )
    enable_restore_snapshots: BoolProperty(
        name='Enable Optional Timed Restore Points',
        default=False,
        update=_sf_history_listener_pref_update,
        description='Optional helper that creates restore points at a fixed minute interval. Leave this off when Restore Point should remain a deliberate manual checkpoint tool. Manual Restore Point creation remains available even when this timed helper is disabled.',
    )
    history_restore_point_manual_primary_migrated: BoolProperty(
        name='Restore Point Manual Primary Migration Done',
        default=False,
        options={'HIDDEN'},
        update=_sf_always_on_pref_update,
        description='Internal migration flag used once to switch older saved settings from automatic timed restore points to the new manual-restore-point-primary workflow. This is hidden and normally does not need manual editing.',
    )

    restore_snapshot_interval_minutes: IntProperty(
        name='Timed Restore Point Interval (Minutes)',
        min=1,
        max=999,
        default=15,
        update=_sf_history_listener_pref_update,
        description='Time between optional timed restore points, measured in minutes. This setting is only used when Enable Optional Timed Restore Points is on, and it creates a file only after a new change has happened since the previous restore point.',
    )
    restore_snapshot_max_files: IntProperty(
        name='Timed Restore Point Max Files',
        min=1,
        max=999,
        default=50,
        update=_sf_always_on_pref_update,
        description='Maximum number of optional timed restore-point files kept for the current project. Manual restore points also use this same retention limit so important rollback files do not grow without control.',
    )
    enable_autosave: BoolProperty(
        name='Enable Rolling Autosave',
        default=False,
        update=_sf_autosave_enabled_pref_update,
        description="Creates extra timed autosave copies in a separate autosave folder. These are additional safety backups independent from Blender's built-in autosave. Disable this to stop rolling autosave; history background work stops automatically when no timed history feature remains active.",
    )
    autosave_interval_minutes: IntProperty(
        name='Autosave Interval (Minutes)',
        min=1,
        max=999,
        default=5,
        update=_sf_history_listener_pref_update,
        description='Time between automatic autosave files, measured in minutes. Example: 5 means one autosave about every 5 minutes after a new change happens.',
    )
    autosave_max_files: IntProperty(
        name='Autosave Max Files',
        min=1,
        max=999,
        default=50,
        update=_sf_always_on_pref_update,
        description='Maximum number of autosave files kept for the current project. When the limit is exceeded, the oldest autosave files are deleted first.',
    )
    autosave_retention_scope: EnumProperty(
        name='Autosave Retention Scope',
        items=[
            ('SCENE', 'Same Scene Name', 'Apply Autosave Max Files only to autosaves that share the current scene or blend-file name.'),
            ('GLOBAL', 'All Scenes', 'Apply Autosave Max Files to all Smart File autosaves in the selected history storage root.'),
        ],
        default='SCENE',
        update=_sf_always_on_pref_update,
        description='Choose whether Autosave Max Files limits only autosaves for the current scene name or the total autosave files across all scene names in the history storage folder.',
    )
    autosave_skip_unchanged: BoolProperty(
        name='Skip Unchanged Autosaves',
        default=True,
        update=_sf_history_listener_pref_update,
        description='When enabled, Rolling Autosave does not write another .blend copy if no operation or scene update has happened since the previous autosave. Keep this on to avoid saving the same data repeatedly while the file is idle. Turn it off only when you intentionally want interval-based copies even during idle time.',
    )
    history_directory: StringProperty(
        name='History Storage Folder',
        subtype='DIR_PATH',
        default="",
        update=_sf_always_on_pref_update,
        description="Root folder where Smart File stores restore points, autosaves, safety backups, and exported JSON logs. Leave it empty to use the Smart File CONFIG storage folder.",
    )
    compress_snapshots: BoolProperty(
        name='Compress Snapshot Files',
        default=False,
        update=_sf_always_on_pref_update,
        description="Uses Blender's compressed save option when writing restore points and autosaves. This usually reduces disk space, but saving can take slightly longer.",
    )
    double_click_restore: BoolProperty(
        name='Restore On Double Click',
        default=False,
        update=_sf_always_on_pref_update,
        description='Reserved for a future input workflow. The current stable workflow is: select a row first, then press Restore Selected to open the confirmation popup.',
    )
    create_safety_snapshot_before_restore: BoolProperty(
        name='Create Safety Snapshot Before Restore',
        default=True,
        update=_sf_always_on_pref_update,
        description='Before opening an older restore point, Smart File first saves the current state as a safety backup. This is strongly recommended because it gives you a way back if you restore the wrong point.',
    )
    timer_interval_seconds: IntProperty(
        name='Background Poll Interval (Seconds)',
        min=1,
        max=10,
        default=1,
        update=_sf_history_listener_pref_update,
        description='How often Smart File checks for new changes while Rolling Autosave or Optional Timed Restore Points are active. Smaller numbers feel more responsive, while larger numbers reduce background overhead.',
    )

    # Asset Reader (Phase 1)
    library_roots: CollectionProperty(type=SF_LibraryRoot)
    context_roots: CollectionProperty(type=SF_ContextRoot)
    new_library_root_path: StringProperty(name='New Library Root', subtype='DIR_PATH', default="", description='Folder that contains your source .blend asset libraries. Add one or more roots so the reader, diagnostics, relink, publish, and repair tools know where to search by default')

    cm_review_items: CollectionProperty(type=SF_CM_ReviewItem)
    cm_review_active_index: IntProperty(default=0)
    cm_review_include_disabled: BoolProperty(
        name='Include disabled roots',
        default=False,
        description='Scan disabled roots too when building the merge selection review',
    )
    cm_review_only_orphans: BoolProperty(
        name='Only orphan blends',
        default=True,
        description='Generate review items only for blend files that are not referenced by any discovered catalog',
    )
    cm_review_category_mode: EnumProperty(
        name='Category Mode',
        items=[
            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),
            ('ROOT', 'Root name', 'Use the library root folder name as the category'),
            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),
        ],
        default='RELATIVE_FOLDER',
    )
    cm_review_infer_preview: BoolProperty(
        name='Infer preview sidecars',
        default=True,
        description='Detect common preview image sidecars next to the blend file and include them in the selection review',
    )
    cm_review_infer_meta: BoolProperty(
        name='Infer metadata sidecars',
        default=True,
        description='Detect common JSON sidecars next to the blend file and include them in the selection review',
    )
    cm_review_apply_changes: BoolProperty(
        name='Write to catalog.json',
        default=False,
        description='Write the selected merge result back to disk instead of only generating preview text',
    )
    cm_review_create_backup: BoolProperty(
        name='Create backup before write',
        default=True,
        description='Write catalog.json.bak_<timestamp> before overwriting catalog.json',
    )
    cm_review_open_text: BoolProperty(
        name='Open report in Text Editor',
        default=False,
        description='Open the generated selection report in a Text Editor when possible',
    )
    cm_review_summary: StringProperty(default="", options={'HIDDEN'})

    cm_override_presets: CollectionProperty(type=SF_CM_OverridePreset)
    cm_preset_active_index: IntProperty(default=0)
    cm_preset_name: StringProperty(
        name='Preset name',
        default="",
        description='Name used when saving an override preset from the active review row',
    )
    cm_preset_apply_scope: EnumProperty(
        name='Preset scope',
        items=[
            ('ACTIVE', 'Active row', 'Apply only to the selected review row'),
            ('ENABLED', 'Enabled rows', 'Apply to all enabled review rows'),
            ('MATCHING', 'Matching action', 'Apply to enabled rows that match the preset action filter'),
        ],
        default='MATCHING',
    )
    cm_preset_import_mode: EnumProperty(
        name='Import mode',
        items=[
            ('UPSERT', 'Upsert', 'Update presets with the same name and add new ones'),
            ('APPEND', 'Append', 'Always append imported presets'),
            ('REPLACE', 'Replace all', 'Clear existing presets before import'),
        ],
        default='UPSERT',
    )

    cm_override_routes: CollectionProperty(type=SF_CM_OverrideRoute)
    cm_route_active_index: IntProperty(default=0)
    cm_route_name: StringProperty(name='Route name', default="", description='Readable name for this routing rule preset')
    cm_route_action_filter: EnumProperty(
        name='Action Filter',
        items=[
            ('ANY', 'Any', 'Match any action'),
            ('ADD_ASSET', 'Add Asset', 'Match add-asset rows'),
            ('ADD_ENTRY', 'Add Entry', 'Match add-entry rows'),
            ('FILL_METADATA', 'Fill Metadata', 'Match metadata fill rows'),
            ('RENAME_ASSET_KEY', 'Rename Asset Key', 'Match asset-key rename rows'),
        ],
        default='ANY',
    )
    cm_route_root_filter: StringProperty(name='Root filter', default="", description='Only match review rows whose library root path contains this text')
    cm_route_category_filter: StringProperty(name='Category filter', default="", description='Only match review rows whose detected category contains this text')
    cm_route_auto_apply_on_build: BoolProperty(
        name='Auto apply routing after build',
        default=True,
        description='Automatically apply preset routing rules after building the merge selection review',
    )

    thumb_dir: StringProperty(
        name='Thumbnails Folder',
        subtype='DIR_PATH',
        default="",
        description='If empty, thumbnails are stored in the add-on cache folder',
    )
    thumb_resolution: IntProperty(
        name='Thumbnail Size',
        default=256,
        min=64,
        max=1024,
        description='Thumbnail render resolution in pixels',
    )

    # Publisher (Phase 3)
    pub_default_subdir: StringProperty(
        name='Default Publish Subfolder',
        default="Published",
        description='Subfolder under the selected root where assets will be written by default',
    )
    pub_version_padding: IntProperty(
        name='Version Padding',
        default=3,
        min=1,
        max=6,
        description='Digits used for version numbering (e.g. v001)',
    )
    pub_preview_default: EnumProperty(
        name='Default Preview Mode',
        items=[
            ('NONE', "None", ""),
            ('EEVEE', "Fast Render (Eevee)", ""),
        ],
        default='EEVEE',
        description='Default preview generation mode for publishing',
    )
    pub_open_folder: BoolProperty(
        name='Open folder after publish',
        default=False,
        description='Open the output folder in the OS file browser after publishing',
    )

    pub_ext_files_mode: EnumProperty(
        name='External Files',
        items=[
            ('NONE', "None", ""),
            ('COPY', "Copy external files", ""),
            ('COPY_PACK_SCRIPT', "Copy + Pack script", ""),
        ],
        default='COPY',
        description='Handle external files (images) by copying them into the publish folder and remapping paths.Pack script writes a helper script to pack files later in Blender.',
    )
    pub_ext_files_subdir: StringProperty(
        name='External Files Subfolder',
        default="textures",
        description='Subfolder name used to store copied external files',
    )
    pub_catalog_filename: StringProperty(
        name='Catalog File Name',
        default="catalog.json",
        description='Catalog file created/updated in the publish folder (JSON)',
    )
    pub_update_catalog: BoolProperty(
        name='Update catalog',
        default=True,
        description='Update catalog.json on publish',
    )
    pub_default_category: StringProperty(
        name='Default Category',
        default="",
        description='Default category used for catalog entries',
    )

    # Asset ID scheme (Phase 3.6)
    pub_asset_id_scheme: EnumProperty(
        name='Asset ID Scheme',
        items=[
            ('UUID4', "UUID v4", "Generate a random UUID (recommended)"),
            ('UUID5', "UUID v5 (stable)", "Generate a stable UUID from prefix+asset name"),
            ('PREFIX_UUID4', "Prefix + UUID v4", "Prefix the random UUID with your project key"),
            ('PREFIX_UUID5', "Prefix + UUID v5", "Prefix the stable UUID with your project key"),
        ],
        default='UUID4',
        description='How to generate asset_id for new assets (existing assets keep their id)',
    )

    pub_asset_id_prefix: StringProperty(
        name='Asset ID Prefix',
        default="",
        description='Optional project key/prefix used by some Asset ID schemes (e.g. PRJ001)',
    )


    apply_prefix_to_linked: BoolProperty(
        name='Apply prefix to linked items',
        default=False,
        description='When enabled, the namespace prefix is also applied to linked library items (not recommended).',
    )


    # Reference Manager (Phase 2)
    ref_mtime_cache: StringProperty(
        name='Reference mtime cache',
        default="{}",
        description='Internal cache for linked library file modification times (JSON)',
        options={'HIDDEN'},
    )


    rm_auto_check_on_load: BoolProperty(
        name='Auto check on file load',
        default=False,
        update=_sf_reference_auto_pref_update,
        description='Automatically check linked library files for updates after opening a .blend. Enable this only when you want Smart File to check missing or outdated linked references on file load.',
    )
    rm_auto_popup_on_updates: BoolProperty(
        name='Popup on updates',
        default=False,
        update=_sf_always_on_pref_update,
        description='Show a popup when updated or missing linked libraries are detected. Enable this when visible notices are needed; disable it for silent checks.',
    )
    rm_version_search_scope: EnumProperty(
        name='Version search scope',
        items=[
            ('SAME_DIR', "Same folder", ""),
            ('ROOTS', "Library Roots", ""),
        ],
        default='ROOTS',
        description="Where to search for newer versions when using 'Switch to Latest'",
    )

    rm_candidate_priority: EnumProperty(
        name='Candidate priority',
        items=[
            ('CATALOG_FIRST', "Catalog first", "Prefer catalog (asset_id) candidates when available"),
            ('DIR_FIRST', "Same folder first", "Prefer candidates in the same folder (safer for local work)"),
            ('HIGHEST_VERSION', "Highest version", "Pick the highest version across all sources"),
        ],
        default='CATALOG_FIRST',
        description='Ranking rule used for relink candidate selection (Resolve Missing / Auto Relink / some Latest detection)',
    )


    rm_asset_id_match_mode: EnumProperty(
        name='Asset ID match mode',
        items=[
            ('EXCLUDE_MISMATCH', "Exclude mismatch", "Exclude candidates whose asset_id differs when both sides have asset_id"),
            ('REQUIRE_MATCH', "Require match", "If current library has asset_id, only candidates with the same asset_id are allowed"),
            ('OFF', "Off", "Do not use asset_id for candidate filtering"),
        ],
        default='EXCLUDE_MISMATCH',
        description='Safety filter for relink candidate selection based on asset_id',
    )

    rm_no_id_mode: EnumProperty(
        name='No-ID candidates',
        items=[
            ('ALLOW', "Allow", "Allow candidates without asset_id"),
            ('DISALLOW', "Disallow", "Exclude candidates without asset_id when current has asset_id"),
            ('EMERGENCY_ONLY', "Emergency only", "Use no-id candidates only if no asset_id-matching candidates are available"),
        ],
        default='EMERGENCY_ONLY',
        description='How to treat candidates that do not have an asset_id',
    )

    rm_auto_apply_without_review: BoolProperty(
        name='Auto apply without review',
        default=False,
        description='When enabled, Auto Relink applies changes immediately without opening the Review dialog',
    )


    rm_score_preset: EnumProperty(
        name='Scoring preset',
        items=[
            ('CUSTOM', "Custom", "Do not change weights automatically"),
            ('SAFE', "Safe", "Conservative scoring for safer relinks"),
            ('AGGRESSIVE', "Aggressive", "Prefer latest versions even across sources"),
            ('LOCAL_FIRST', "Local-first", "Prefer same-folder candidates for local work"),
        ],
        default='CUSTOM',
        description='Quick preset for candidate scoring weights and strategy',
    )

    rm_score_w_exists: IntProperty(
        name='Weight: Exists',
        default=1000,
        min=0, max=5000,
        description='Scoring weight for whether the candidate file exists',
    )
    rm_score_w_asset_id: IntProperty(
        name='Weight: Asset ID match',
        default=500,
        min=0, max=5000,
        description='Scoring weight for Asset ID match (only affects candidates that have asset_id)',
    )
    rm_score_w_source: IntProperty(
        name='Weight: Source',
        default=100,
        min=0, max=5000,
        description='Scoring weight for candidate source (Catalog / Same folder / Roots)',
    )
    rm_score_w_version: IntProperty(
        name='Weight: Version',
        default=1,
        min=0, max=100,
        description='Scoring weight per version step',
    )
    rm_score_w_root: IntProperty(
        name='Weight: Root priority',
        default=5,
        min=0, max=5000,
        description='Scoring weight for catalog root priority (higher-priority roots score higher)',
    )

    rm_auto_periodic: BoolProperty(
        name='Periodic update check',
        default=False,
        update=_sf_reference_auto_pref_update,
        description='Continuously check linked libraries for updates at a fixed interval. Enable this only when continuous background monitoring is needed, because it performs periodic work while Blender is open.',
    )
    rm_auto_interval_min: IntProperty(
        name='Check interval (min)',
        default=10,
        min=1,
        max=240,
        description='Interval in minutes for periodic update checks',
    )

    cat_merge_priority_mode: EnumProperty(
        name='Catalog merge priority',
        items=[
            ('ROOT_PRIORITY', "Root priority", "Prefer assets from higher-priority library roots when merging catalogs"),
            ('HIGHEST_VERSION', "Highest version", "Always pick the highest version across all roots regardless of root priority"),
        ],
        default='ROOT_PRIORITY',
        description='Choose whether merged catalog decisions should favor trusted root priority or always chase the newest version across every root',
    )



    cat_conflict_overrides_json: StringProperty(
        name='Catalog conflict overrides',
        default="{}",
        description='Internal per-asset preferred source catalog mapping (JSON)',
        options={'HIDDEN'},
    )

    debug_translation: BoolProperty(
        name='Debug: Translation Check',
        default=False,
        description='Internal developer helper for translation diagnostics',
        options={'HIDDEN'},
    )

    def draw(self, context):
        drawn_inside_smart_file_panel = bool(getattr(type(self), '_smart_file_panel_preferences_draw', False))
        layout = self.layout
        wm = context.window_manager
        if not drawn_inside_smart_file_panel:
            layout.use_property_split = False
            layout.use_property_decorate = False
            info = layout.box()
            info.label(text=_t('Smart File settings are available in the Smart File N-panel.'))
            return
        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')
        roots = list(getattr(self, 'library_roots', []) or [])
        roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)
        try:
            index = _load_index()
        except Exception:
            index = {}
        index_ready = bool(len((index or {}).get('files', {}) or {}))
        source_info = _sf_get_source_insights(self, filepath, index)
        has_source = bool(filepath and os.path.isfile(filepath))
        health_score, _health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)

        if not drawn_inside_smart_file_panel:
            category_box = layout.box()
            category_box.label(text=_t('Functional Categories'), icon='ASSET_MANAGER')
            try:
                _sf_draw_smart_file_workspace_ui(category_box, context)
            except Exception:
                category_box.label(text=_t('Category launcher is unavailable until the workspace runtime finishes loading.'))

        access_box = layout.box()
        access_box.label(text=_t('Access & Menus'), icon='MENU_PANEL')
        # N-panel-only UI policy: legacy top-menu toggles are intentionally not drawn.
        access_box.prop(self, "ui_launcher_popup_width")
        access_box.prop(self, "ui_home_density")
        if not drawn_inside_smart_file_panel:
            pass

        goal_box = layout.box()
        _sf_draw_section_intro(goal_box, "Session Goal", "Use the current goal to narrow the home screen toward exploration, import, maintenance, publish, or recovery tasks.", 'BOOKMARKS')
        try:
            goal_box.prop(context.window_manager, "sf_session_goal", text=_t('Current Goal'))
        except Exception:
            pass
        _sf_draw_recommended_lane(goal_box, _sf_current_session_goal(context), compact=True, has_source=has_source)

        snapshot_box = layout.box()
        _sf_draw_source_snapshot(snapshot_box, filepath, source_info, health_score, _health_label, compact=True)

        try:
            actions = _sf_build_recommended_actions(context, self, filepath, source_info, roots_ready, index_ready, health_score)
            _sf_draw_goal_focus_panel(layout, context, self, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True)
            _sf_draw_goal_playbook_panel(layout, context, self, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True)
            _sf_draw_source_matrix_panel(layout, context, self, filepath, source_info, roots_ready, index_ready, compact=True)
            _sf_draw_goal_scoreboard(layout, context, self, filepath, source_info, roots_ready, index_ready, compact=True)
            _sf_draw_consistency_panel(layout, context, self, filepath, source_info, roots_ready, index_ready, compact=True)
            _sf_draw_action_queue_panel(layout, context, self, filepath, source_info, roots_ready, index_ready, health_score, compact=True)
            _sf_draw_relationship_map(layout, context, self, filepath, source_info, roots_ready, index_ready, compact=True)
            _sf_draw_goal_decks(layout, context, self, filepath, source_info, roots_ready, index_ready, health_score, actions, compact=True)
            _sf_draw_profile_match_board(layout, self, context, filepath, source_info, compact=True)
            _sf_draw_last_fix_snapshot(layout, context, compact=True)
            _sf_draw_repair_pack_panel(layout, context, self, filepath, source_info, compact=True)
        except Exception:
            pass

        prof_box = layout.box()
        prof_box.label(text=_t('Workspace Profiles'), icon='PRESET')
        row = prof_box.row(align=True)
        row.prop(self, "workspace_profile_name", text=_t('Profile name'))
        row.operator("import_scene.sfs_workspace_profile_save_current_setup", text=_t('Save Current Setup'), icon='ADD')
        row.operator("import_scene.sfs_workspace_profile_seed_default_profiles", text=_t('Seed Default Profiles'), icon='PRESET')

        tool_row = prof_box.row(align=True)
        tool_row.label(text=_t('Profile Tools'), icon='TOOL_SETTINGS')
        tool_row.operator("import_scene.sfs_workspace_profile_export_workspace_profiles", text=_t('Export Workspace Profiles'), icon='EXPORT').scope = 'ALL'
        tool_row.operator("import_scene.sfs_workspace_profile_import_workspace_profiles", text=_t('Import Workspace Profiles'), icon='IMPORT')
        pack_row = prof_box.row(align=True)
        pack_row.operator("import_scene.sfs_workspace_profile_export_workspace_profiles", text=_t('Export Workspace Profiles'), icon='EXPORT').scope = 'VISIBLE'
        pack_row.operator("import_scene.sfs_workspace_profile_export_workspace_profiles", text=_t('Export Workspace Profiles'), icon='EXPORT').scope = 'PINNED'
        pack_row.operator("import_scene.sfs_workspace_profile_export_workspace_profiles", text=_t('Export Workspace Profiles'), icon='EXPORT').scope = 'GOAL'
        try:
            _sf_draw_profile_filter_bar(prof_box, self, context)
            _sf_draw_profile_overview(prof_box, self, context=context, compact=True)
        except Exception:
            pass

        if self.workspace_profiles:
            _sf_draw_profile_cards(prof_box, self, max_cards=3, include_open=True, compact=False)
            prof_box.separator()
            for idx, profile in _sf_profiles_for_goal(self, _sf_current_session_goal(context), context=context)[:10]:
                r = prof_box.row(align=True)
                r.label(text=getattr(profile, 'name', '') or _ui_text(f"Profile {idx+1}", f'プロファイル {idx + 1}'), icon='PRESET', translate=False)
                r.label(text=_sf_profile_summary(profile), icon='BLANK1')
                op = r.operator("import_scene.sfs_workspace_profile_apply_profile", text=_t('Apply Profile'), icon='CHECKMARK')
                op.index = idx
                op = r.operator("import_scene.sfs_workspace_profile_apply_and_open", text=_t('Apply & Open'), icon='PLAY')
                op.index = idx
                op = r.operator("import_scene.sfs_workspace_profile_edit_profile", text='', icon='GREASEPENCIL', emboss=True)
                op.index = idx
                op = r.operator("import_scene.sfs_workspace_profile_duplicate_profile", text='', icon='DUPLICATE', emboss=True)
                op.index = idx
                op = r.operator("import_scene.sfs_workspace_profile_move_profile", text='', icon='TRIA_UP', emboss=True)
                op.index = idx
                op.direction = 'UP'
                op = r.operator("import_scene.sfs_workspace_profile_move_profile", text='', icon='TRIA_DOWN', emboss=True)
                op.index = idx
                op.direction = 'DOWN'
                op = r.operator("import_scene.sfs_workspace_profile_remove_profile", text='', icon='X', emboss=True)
                op.index = idx
        else:
            prof_box.label(text=_t('No workspace profiles yet'))

        readiness_box = layout.box()
        _sf_draw_section_intro(readiness_box, "Readiness Checklist", "See the minimum requirements for import, maintenance, preview, and publish workflows at a glance.", 'CHECKMARK')
        _sf_draw_readiness_checklist(readiness_box, context, compact=True)

        root_status = layout.box()
        _sf_draw_section_intro(root_status, "Root Status Badges", "Summarize how many roots are healthy, missing, disabled, or still empty so maintenance priorities are clearer.", 'FILE_FOLDER')
        _sf_draw_root_status_badges(root_status, self, compact=True)

        root_box = layout.box()
        _sf_draw_section_intro(root_box, "Root Maintenance", "Keep library roots enabled, ordered, and clean so diagnostics and publishing stay predictable.", 'TOOL_SETTINGS')
        rrow = root_box.row(align=True)
        rrow.operator("import_scene.sfs_library_roots_enable_all_roots", text=_t('Enable All Roots'), icon='CHECKMARK')
        rrow.operator("import_scene.sfs_library_roots_disable_missing_roots", text=_t('Disable Missing Roots'), icon='CANCEL')
        rrow.operator("import_scene.sfs_library_roots_sort_roots", text=_t('Sort Roots'), icon='SORTALPHA')
        root_box.operator("import_scene.sfs_library_roots_clean_roots", text=_t('Clean Roots'), icon='BRUSH_DATA')
        try:
            _sf_draw_root_attention_panel(layout, context, self, index, source_info, compact=True)
        except Exception:
            pass

        workflow_defaults_box = layout.box()
        _sf_draw_section_intro(workflow_defaults_box, "Everyday Defaults", "Tune the basic history, logging, and naming behavior that most users notice first.", 'SETTINGS')
        workflow_defaults_box.prop(self, "max_recent")
        workflow_defaults_box.prop(self, "activity_log_limit")
        workflow_defaults_box.prop(self, "apply_prefix_to_linked")

        history_box = layout.box()
        _sf_draw_section_intro(history_box, "History & Restore", "Manual Restore Point is the primary rollback workflow; Autosave remains the rolling safety net.", 'RECOVER_LAST')

        startup = history_box.box()
        startup.label(text=_t('Startup / Monitoring'), icon='TIME')

        split = history_box.split(factor=0.5)
        left_box = split.box()
        left_box.label(text=_t('Optional Timed Restore Points'), icon='PRESET')
        left_box.prop(self, "enable_restore_snapshots", text=_t('Enable Optional Timed Restore'))
        left = left_box.column(align=True)
        left.enabled = self.enable_restore_snapshots
        left.prop(self, "restore_snapshot_interval_minutes")
        left.prop(self, "restore_snapshot_max_files")

        right_box = split.box()
        right_box.label(text=_t('Autosaves'), icon='FILE_TICK')
        right_box.prop(self, "enable_autosave", text=_t('Enable Rolling Autosave'))
        right = right_box.column(align=True)
        right.enabled = self.enable_autosave
        right.prop(self, "autosave_interval_minutes")
        right.prop(self, "autosave_max_files")
        right.prop(self, "autosave_skip_unchanged")

        behavior = history_box.box()
        behavior.label(text=_t('Storage & Behavior'), icon='PREFERENCES')
        behavior.prop(self, "history_directory")
        behavior.prop(self, "compress_snapshots")
        behavior.prop(self, "create_safety_snapshot_before_restore")
        behavior.prop(self, "timer_interval_seconds")

        diagnostics_box = layout.box()
        _sf_draw_section_intro(diagnostics_box, "Diagnostics", "Use these checks when you are investigating behavior or preparing a support report.", 'CONSOLE')

        try:
            _sf_draw_activity_log(diagnostics_box, context, compact=True)
        except Exception:
            pass

        rm_box = layout.box()
        _sf_draw_section_intro(rm_box, "Reference Manager", "These settings control how safely the add-on finds, scores, and applies relink candidates.", 'LINKED')
        rm_box.prop(self, "rm_version_search_scope")
        rm_box.prop(self, "rm_candidate_priority")
        rm_box.prop(self, "rm_asset_id_match_mode")
        rm_box.prop(self, "rm_no_id_mode")
        rm_box.prop(self, "rm_auto_apply_without_review")
        wbox = rm_box.box()
        wbox.label(text=_t('Candidate scoring weights'), icon='SORTSIZE')

        prow = wbox.row(align=True)
        prow.prop(self, "rm_score_preset", text=_t('Preset'))
        apply_row = prow.row(align=True)
        apply_row.enabled = self.rm_score_preset != 'CUSTOM'
        op = apply_row.operator("import_scene.sfs_reference_manager_apply_preset", text=_t('Apply Preset'), icon='CHECKMARK')
        op.preset = self.rm_score_preset if self.rm_score_preset != 'CUSTOM' else 'SAFE'

        brow = wbox.row(align=True)
        op = brow.operator("import_scene.sfs_reference_manager_apply_preset", text=_t('Apply Preset'))
        op.preset = 'SAFE'
        op = brow.operator("import_scene.sfs_reference_manager_apply_preset", text=_t('Apply Preset'))
        op.preset = 'LOCAL_FIRST'
        op = brow.operator("import_scene.sfs_reference_manager_apply_preset", text=_t('Apply Preset'))
        op.preset = 'AGGRESSIVE'

        gridw = wbox.grid_flow(columns=2, even_columns=True, even_rows=False, align=True)
        gridw.prop(self, "rm_score_w_exists")
        gridw.prop(self, "rm_score_w_asset_id")
        gridw.prop(self, "rm_score_w_source")
        gridw.prop(self, "rm_score_w_version")
        gridw.prop(self, "rm_score_w_root")
        sub = rm_box.row(align=True)
        sub.enabled = self.rm_auto_periodic
        sub.prop(self, "rm_auto_interval_min")

        ar_box = layout.box()
        _sf_draw_section_intro(ar_box, "Asset Reader", "Library roots define where diagnostics, indexing, catalog generation, and publish tools search by default.", 'ASSET_MANAGER')
        ar_box.prop(self, "cat_merge_priority_mode")

        recent_box = layout.box()
        _sf_draw_section_intro(recent_box, "Recent Files", "Keep a short history of recently used source files so you can reopen work without browsing folders again.", 'RECOVER_LAST')
        recent_box.label(text=f"{_t('Saved entries')}: {len(getattr(self, 'recent_paths', []) or [])}/{int(getattr(self, 'max_recent', 10) or 10)}")
        if not self.recent_paths:
            recent_box.label(text=_t('No recent source files yet'))
        for idx, it in enumerate(self.recent_paths):
            item_box = recent_box.box()
            info = item_box.row(align=True)
            path = _norm_path(getattr(it, 'path', '') or '')
            info.label(text=os.path.basename(path) or path or _t('Not set'), icon='FILE_BLEND', translate=False)
            if path:
                info.label(text=_sf_short_path_display(os.path.dirname(path), 46), icon='FILE_FOLDER', translate=False)
            _sf_draw_action_block(
                item_box,
                primary_actions=[
                    ("import_scene.sfs_source_browser_use", "Use", 'IMPORT', {'kind': 'RECENT', 'index': idx}),
                ],
                danger_actions=[
                    ("import_scene.sfs_source_browser_remove", "Remove", 'TRASH', {'kind': 'RECENT', 'index': idx}),
                ],
            )

        fav_box = layout.box()
        _sf_draw_section_intro(fav_box, "Favorites", "Pin stable source files here so the N-panel launcher can reopen them with one click.", 'FUND')
        fav_box.label(text=f"{_t('Saved entries')}: {len(getattr(self, 'favorite_paths', []) or [])}")
        if not self.favorite_paths:
            fav_box.label(text=_t('No favorite source files yet'))
        for idx, it in enumerate(self.favorite_paths):
            item_box = fav_box.box()
            info = item_box.row(align=True)
            path = _norm_path(getattr(it, 'path', '') or '')
            info.label(text=os.path.basename(path) or path or _t('Not set'), icon='FILE_BLEND', translate=False)
            if path:
                info.label(text=_sf_short_path_display(os.path.dirname(path), 46), icon='FILE_FOLDER', translate=False)
            _sf_draw_action_block(
                item_box,
                primary_actions=[
                    ("import_scene.sfs_source_browser_use", "Use", 'IMPORT', {'kind': 'FAVORITE', 'index': idx}),
                ],
                danger_actions=[
                    ("import_scene.sfs_source_browser_remove", "Remove", 'TRASH', {'kind': 'FAVORITE', 'index': idx}),
                ],
            )



        box = layout.box()
        _sf_draw_section_intro(box, "Library Roots", "Add, order, and maintain library roots so every scan, repair, publish, and relink tool works from the same trusted search area.", 'FILE_FOLDER')
        box.label(text=f"{_t('Configured roots')}: {len(getattr(self, 'library_roots', []) or [])}")
        row = box.row(align=True)
        row.prop(self, "new_library_root_path", text='')
        row.operator("import_scene.sfs_asset_library_add_root", text=_t('Add Root'), icon='ADD')

        if not self.library_roots:
            box.label(text=_t('No library roots configured yet'))
        for i, r in enumerate(self.library_roots):
            root_box = box.box()
            rr = root_box.row(align=True)
            rr.prop(r, "enabled", text='')
            rr.label(text=_sf_short_path_display(_norm_path(r.path), 68), icon='FILE_FOLDER', translate=False)
            rr.prop(r, "priority", text=_t('Priority'))
            _sf_draw_action_block(
                root_box,
                danger_actions=[
                    ("import_scene.sfs_asset_library_remove_root", "Remove", 'TRASH', {'index': i}),
                ],
            )

        row = box.row(align=True)
        row.operator("import_scene.sfs_asset_library_rebuild_index", text=_t('Rebuild Index'), icon='FILE_REFRESH').full_rebuild = False
        row.operator("import_scene.sfs_asset_library_rebuild_index", text=_t('Rebuild Index'), icon='FILE_REFRESH').full_rebuild = True
        row = box.row(align=True)
        row.operator("import_scene.sfs_asset_library_diagnostics", text=_t('Diagnostics'), icon='CHECKMARK')
        row.operator("import_scene.sfs_asset_library_repair_roots", text=_t('Repair Roots'), icon='PREFERENCES')
        row = box.row(align=True)
        row.operator("import_scene.sfs_context_roots_open", text=_t('Open'), icon='FILE_PARENT')
        row.operator("import_scene.sfs_root_watch_open", text=_t('Open'), icon='FILE_REFRESH')
        row = box.row(align=True)
        row.operator("import_scene.sfs_asset_library_generate_catalog_draft", text=_t('Generate Catalog Draft'), icon='TEXT')
        row.operator("import_scene.sfs_catalog_merge_review_merge_preview", text=_t('Review Merge Preview'), icon='VIEWZOOM')
        _sf_draw_action_block(
            box,
            primary_actions=[
                ("import_scene.sfs_catalog_merge_apply_filtered_merge", "Apply Filtered Merge...", 'FILTER', {}),
            ],
            danger_actions=[
                ("import_scene.sfs_catalog_merge_apply_full_merge", "Apply Full Merge...", 'FILE_TICK', {}),
            ],
        )
        row = box.row(align=True)
        row.operator("import_scene.sfs_reference_manager_run_library_workflow", text=_t('Run Library Workflow'), icon='PLAY')

        sbox = layout.box()
        _sf_draw_section_intro(sbox, "Catalog Merge Selection Review", "Review each merge row before applying shared catalog decisions across roots, previews, metadata, and tags.", 'OUTLINER')
        scol = sbox.column(align=True)
        scol.label(text=_t('Review settings'))
        scol.prop(self, "cm_review_include_disabled")
        scol.prop(self, "cm_review_only_orphans", text=_t('Only orphan blends'))
        scol.prop(self, "cm_review_category_mode")
        scol.prop(self, "cm_review_infer_preview")
        scol.prop(self, "cm_review_infer_meta")
        _sf_draw_action_block(
            sbox,
            primary_actions=[
                ("import_scene.sfs_catalog_merge_build_merge_review", "Build Merge Review...", 'OUTLINER', {}),
                ("import_scene.sfs_catalog_merge_apply_selected_merge", "Apply Selected Merge...", 'FILE_TICK', {}),
            ],
            secondary_actions=[
                ("import_scene.sfs_catalog_merge_set_selection", "All ON", 'CHECKBOX_HLT', {'enable': True}),
                ("import_scene.sfs_catalog_merge_set_selection", "All OFF", 'CHECKBOX_DEHLT', {'enable': False}),
            ],
            danger_actions=[
                ("import_scene.sfs_catalog_merge_clear_merge_selection", "Clear Merge Selection", 'TRASH', {}),
            ],
        )

        split = sbox.split(factor=0.58)
        left = split.column(align=True)
        right = split.column(align=True)
        left.template_list("SF_UL_cm_review_items", "", self, "cm_review_items", self, "cm_review_active_index", rows=10)
        db = right.box()
        db.label(text=_t('Detail Preview'), icon='TEXT')
        active_item = _sf_cm_get_active_item(self)
        for line in _sf_cm_get_active_item_detail_lines(self):
            if not line.strip():
                db.separator()
            else:
                db.label(text=line[:240])

        if active_item:
            obox = db.box()
            obox.label(text=_t('Individual Overrides'), icon='SETTINGS')
            obox.label(text=_t('Only affects the selected review row'))
            any_override = False
            if bool(getattr(active_item, 'ovr_has_key_rename', False)):
                obox.prop(active_item, 'ovr_allow_key_rename')
                any_override = True
            if bool(getattr(active_item, 'ovr_has_preview', False)):
                obox.prop(active_item, 'ovr_use_preview')
                any_override = True
            if bool(getattr(active_item, 'ovr_has_meta', False)):
                obox.prop(active_item, 'ovr_use_meta')
                any_override = True
            if bool(getattr(active_item, 'ovr_has_category', False)):
                obox.prop(active_item, 'ovr_use_category')
                any_override = True
            if bool(getattr(active_item, 'ovr_has_tags', False)):
                obox.prop(active_item, 'ovr_use_tags')
                any_override = True
            if not any_override:
                obox.label(text=_t('No per-item overrides for this row'))

        if self.cm_review_summary:
            sb = sbox.box()
            sb.label(text=_t('Current selection summary'))
            for line in (self.cm_review_summary or '').splitlines():
                if not line.strip():
                    sb.separator()
                else:
                    sb.label(text=line[:240])

        pbox = layout.box()
        _sf_draw_section_intro(pbox, "Override Presets", "Store reusable merge override recipes so repeated catalog-review work stays consistent across many rows.", 'PRESET')
        row = pbox.row(align=True)
        row.prop(self, "cm_preset_name", text='')
        _sf_operator_button(row, "import_scene.sfs_override_manager_save_preset", "Save", icon='ADD')
        _sf_operator_button(row, "import_scene.sfs_override_manager_update_preset", "Update", icon='FILE_REFRESH')
        row = pbox.row(align=True)
        row.prop(self, "cm_preset_apply_scope", text=_t('Scope'))
        _sf_draw_action_block(
            pbox,
            primary_actions=[
                ("import_scene.sfs_override_manager_apply_preset", "Apply", 'CHECKMARK', {}),
            ],
            danger_actions=[
                ("import_scene.sfs_override_manager_remove_preset", "Remove", 'TRASH', {}),
            ],
        )
        if self.cm_override_presets:
            for idx, preset in enumerate(self.cm_override_presets):
                rr = pbox.row(align=True)
                icon = 'RADIOBUT_ON' if idx == int(getattr(self, 'cm_preset_active_index', 0) or 0) else 'RADIOBUT_OFF'
                op = rr.operator("import_scene.sfs_override_manager_set_preset_active", text='', icon=icon, emboss=True)
                op.index = idx
                rr.label(text=f"{preset.name} [{preset.action_filter}]")
                rr.label(text=f"p:{'Y' if preset.use_preview else '-'} m:{'Y' if preset.use_meta else '-'} c:{'Y' if preset.use_category else '-'} t:{'Y' if preset.use_tags else '-'} r:{'Y' if preset.allow_key_rename else '-'}")
            ap = self.cm_override_presets[min(max(int(getattr(self, 'cm_preset_active_index', 0) or 0), 0), len(self.cm_override_presets)-1)]
            ib = pbox.box()
            ib.label(text=_t('Active preset'))
            ib.label(text=f"{ap.name} | {ap.action_filter}")
            ib.label(text=f"{_t('Preview')}: {_t('Yes') if bool(ap.use_preview) else _t('No')} | {_t('Meta')}: {_t('Yes') if bool(ap.use_meta) else _t('No')} | {_t('Category')}: {_t('Yes') if bool(ap.use_category) else _t('No')} | {_t('Tags')}: {_t('Yes') if bool(ap.use_tags) else _t('No')} | {_t('Rename')}: {_t('Yes') if bool(ap.allow_key_rename) else _t('No')}")
        brow = pbox.row(align=True)
        brow.prop(self, "cm_preset_import_mode", text=_t('Import mode'))
        _sf_operator_button(brow, "import_scene.sfs_override_manager_import_presets", "Import Presets", icon='IMPORT')
        _sf_operator_button(brow, "import_scene.sfs_override_manager_export_presets", "Export Presets", icon='EXPORT')

        rbox = layout.box()
        _sf_draw_section_intro(rbox, "Preset Routing", "Automatically route saved override presets to review rows by action, root path, and category filters.", 'SORTBYEXT')
        rbox.prop(self, "cm_route_auto_apply_on_build")
        row = rbox.row(align=True)
        row.prop(self, "cm_route_name", text='')
        _sf_operator_button(row, "import_scene.sfs_override_manager_save_route", "Save Route", icon='ADD')
        _sf_operator_button(row, "import_scene.sfs_override_manager_update_route", "Update Route", icon='FILE_REFRESH')
        row = rbox.row(align=True)
        row.prop(self, "cm_route_action_filter", text=_t('Action'))
        row.prop(self, "cm_route_root_filter", text=_t('Root contains'))
        row.prop(self, "cm_route_category_filter", text=_t('Category contains'))
        _sf_draw_action_block(
            rbox,
            primary_actions=[
                ("import_scene.sfs_override_manager_apply_routes", "Apply Routes", 'CHECKMARK', {}),
            ],
            danger_actions=[
                ("import_scene.sfs_override_manager_remove_route", "Remove Route", 'TRASH', {}),
            ],
        )
        active_preset = _sf_cm_get_active_preset(self)
        if active_preset:
            rbox.label(text=f"{_t('Preset name')}: {getattr(active_preset, 'name', '')}")
        if self.cm_override_routes:
            for idx, route in enumerate(self.cm_override_routes):
                rr = rbox.row(align=True)
                icon = 'RADIOBUT_ON' if idx == int(getattr(self, 'cm_route_active_index', 0) or 0) else 'RADIOBUT_OFF'
                op = rr.operator("import_scene.sfs_override_manager_set_route_active", text='', icon=icon, emboss=True)
                op.index = idx
                rr.prop(route, 'enabled', text='')
                rr.label(text=f"{route.name} -> {route.preset_name or '-'} [{route.action_filter}]")
                if getattr(route, 'root_filter', ''):
                    rr.label(text=f"{_t('Root')}: {route.root_filter}")
                if getattr(route, 'category_filter', ''):
                    rr.label(text=f"{_t('Category')}: {route.category_filter}")

        box = layout.box()
        box.label(text=_t('Thumbnails'), icon='RENDER_STILL')
        box.prop(self, "thumb_dir")
        box.prop(self, "thumb_resolution")


        pbox = layout.box()
        pbox.label(text=_t('Publish Settings'), icon='EXPORT')
        pbox.prop(self, "pub_default_subdir")
        pbox.prop(self, "pub_version_padding")
        pbox.prop(self, "pub_preview_default")
        pbox.prop(self, "pub_open_folder")
        pbox.separator()
        pbox.prop(self, "pub_ext_files_mode")
        pbox.prop(self, "pub_ext_files_subdir")
        pbox.prop(self, "pub_catalog_filename")
        pbox.prop(self, "pub_update_catalog")
        pbox.prop(self, "pub_default_category")

        pbox.separator()
        pbox.label(text=_t('Asset ID'), icon='KEY_HLT')
        pbox.prop(self, "pub_asset_id_scheme")
        pbox.prop(self, "pub_asset_id_prefix")


_SF_ADDON_PREFERENCES_SMART_FILE_PANEL_DRAW = getattr(SFS_PG_system_file_suite_preferences, 'draw', None)
if callable(_SF_ADDON_PREFERENCES_SMART_FILE_PANEL_DRAW):
    SFS_PG_system_file_suite_preferences._smart_file_panel_draw = _SF_ADDON_PREFERENCES_SMART_FILE_PANEL_DRAW
# SFS_PG_system_file_suite_preferences is a PropertyGroup-backed N-panel settings store; keep draw available only through Smart File's panel dispatcher.




























































































































































































































































































































































































































































































































































































































































































# -----------------------------------------------------------------------------
#  UI text polish: detailed bilingual tooltips for major visible operators
# -----------------------------------------------------------------------------
def _sf_apply_ui_text_polish():
    def _set_desc(cls_name: str, desc: str):
        cls = globals().get(cls_name)
        if cls is not None:
            try:
                cls.bl_description = _sf_strip_bilingual_source(desc)
            except Exception:
                pass

    descriptions = {
        "SF_OT_source_browser_scene_select": 'Use the path written in the Source field as the active source scene, scan it again, and refresh the listed datablocks without leaving the dialog.',
        "SF_OT_source_browser_use": 'Load the selected saved source path back into Smart File and reopen the source browser.',
        "SF_OT_source_browser_remove": 'Remove the chosen entry from the Recent list or the Favorites list without deleting the actual file.',
        "SF_OT_source_browser_add_current_file_to_favorites": 'Add the currently selected source .blend file to Favorites so it can be reopened quickly later.',
        "SF_OT_source_browser_toggle_favorite": "Turn the current source file's favorite state on or off.",
        "SF_OT_source_browser_copy_path": 'Copy either the current source file path or its folder path to the clipboard.',
        "SF_OT_source_browser_cleanup_saved_paths": 'Remove missing, duplicate, or invalid entries from the Recent list, Favorites list, or both.',
        "SF_OT_source_browser_import": 'Rescan the currently chosen source file and reopen the import browser with the latest datablock list. Use this after changing the source path, mode, or search setup and you want a fresh browser state.',
        "SF_OT_source_browser_open_folder": 'Open the operating-system folder that contains the currently selected source .blend file. Use this when you want to inspect nearby textures, caches, versions, or related files outside Blender.',
        "SF_OT_source_browser_clear_saved_paths": 'Clear all entries from Recent or Favorites in one step without touching files on disk.',
        "SF_OT_source_browser_select_all": 'Select all listed datablocks, clear the selection, or invert the current selection state.',
        "SF_OT_source_browser_open_folder_2": 'Open a file browser so you can browse to another source .blend file, set it as the current source, and refresh the import list for that file.',
        "SF_OT_source_browser_import_2": 'Browse the datablocks inside the chosen .blend file, choose only what you need, and import them with dependency, naming, organization, and placement options.',
        "SF_OT_asset_reader_open": 'Inspect indexed library files, compare catalog and raw index views, then import only the results you checked.',
        "SF_OT_asset_library_diagnostics": 'Scan configured library roots for missing folders, unsupported content, catalog issues, and indexing mismatches.',
        "SF_OT_asset_library_repair_roots": 'Review safe cleanup and normalization suggestions for configured library roots before indexing or publishing.',
        "SF_OT_asset_library_generate_catalog_draft": 'Build a draft catalog proposal from the current library roots without overwriting published files immediately.',
        "SF_OT_asset_library_rebuild_index": 'Rescan all enabled library roots and rebuild the cache used by Asset Reader and Reference Manager.',
        "SF_OT_reference_manager_open": 'Audit linked libraries, review update or relink candidates, and apply only the changes you trust.',
        "SF_OT_reference_manager_refresh": "Rebuild the Reference Manager list from the current file's linked libraries.",
        "SF_OT_reference_manager_check_updates": 'Check linked libraries for missing files, newer versions, and relink candidates using the current scoring rules.',
        "SF_OT_reference_manager_reload_selected": 'Reload only the active linked library from disk without changing its stored path.',
        "SF_OT_reference_manager_reload_all": 'Reload every linked library in the current file from disk.',
        "SF_OT_reference_manager_apply_selected_relink": 'Choose one replacement path for the active linked library and apply that relink explicitly.',
        "SF_OT_reference_manager_review_suggested_relink": 'Review scored relink candidates for the active library before applying the safest replacement.',
        "SF_OT_reference_manager_review_auto_relink": 'Build a proposed relink plan automatically, then let you review every row before anything is changed.',
        "SF_OT_reference_manager_review_update_plan": 'Apply only the enabled rows from the current Reference Manager review plan.',
        "SF_OT_library_roots_resolve_using_roots": 'Search configured library roots for a replacement file that can fix the active missing reference.',
        "SF_OT_reference_manager_switch_to_latest": 'Replace the active linked library with the newest valid version found by the current search rules.',
        "SF_OT_catalog_merge_review_merge_preview": 'Preview how catalog entries from multiple roots will merge before any file is written.',
        "SF_OT_catalog_merge_build_merge_review": 'Create a row-by-row review list for catalog merge decisions so each proposed change can be approved or skipped.',
        "SF_OT_catalog_merge_apply_selected_merge": 'Apply the currently enabled catalog-merge rows and optionally write the result back to catalog.json.',
        "SF_OT_catalog_merge_apply_filtered_merge": 'Merge only approved catalog draft rows so reviewed assets and metadata changes are carried forward.',
        "SF_OT_catalog_merge_apply_full_merge": 'Run a full catalog merge using the current priority rules and generate a single consolidated result.',
        "SF_OT_reference_manager_run_library_workflow": 'Run a guided maintenance workflow that chains diagnostics, indexing, catalog review, and optional fixes.',
        "SF_OT_asset_preview_batch_preview": 'Create or refresh preview images for many published assets at once, with optional catalog updates.',
        "SF_OT_publisher_publish_asset": 'Publish selected scene content as a versioned asset package with preview, metadata, changelog, and catalog options.',
        "SF_OT_root_repath_apply_saved_plan": 'Apply the last saved root-repath plan again so you can preview first, review the report, and then execute the exact same migration safely.',
        "SF_OT_root_repath_restore_saved_plan": 'Restore the previous paths recorded in the last saved root-repath plan. Only records that still match the saved migrated paths are changed back, so drifted edits stay protected.',
        "SF_OT_workspace_command_launcher": 'Open the compact launcher dashboard for goal-based navigation, quick reports, and the most common Smart File actions.',
        "SF_OT_history_open": 'Open the integrated history popup and the fully migrated Smart File history controls inside the Recover workflow.',
        "SF_OT_workspace_command_goal_home": 'Open the goal-oriented home popup so the current task focus, recommendations, and next actions stay easy to follow.',
        "SF_OT_reference_manager_source_check": 'Inspect the current source path, root coverage, publish readiness, and common setup problems before you continue.',
        "SF_OT_workspace_command_session_cockpit": 'Open a session summary popup with quick status, recent actions, and the most useful follow-up tools.',
        "SF_OT_workspace_command_action_palette": 'Open a searchable action-style palette for common Smart File tools and guided next steps.',
        "SF_OT_workspace_command_release_gate": 'Review release-readiness checkpoints before final asset handoff or shared-library publication.',
        "SF_OT_reference_manager_final_review": 'Open a final review board that summarizes source health, publish readiness, and recommended wrap-up actions.',
        "SF_OT_library_roots_root_coverage_matrix": 'Open a matrix view that shows how well the current source and libraries are covered by configured roots.',
        "SF_OT_workspace_profile_save_current_setup": 'Save the current Smart File setup as a reusable workspace profile.',
        "SF_OT_workspace_profile_apply_profile": 'Apply the selected workspace profile to restore a known-safe setup quickly.',
        "SF_OT_workspace_profile_apply_and_open": 'Apply the selected workspace profile and immediately open its recommended tool.',
        "SF_OT_workspace_profile_duplicate_profile": 'Duplicate the active workspace profile so you can build a variant without losing the original.',
        "SF_OT_workspace_profile_import_workspace_profiles": 'Import workspace profiles from JSON and merge, append, or replace them according to the selected mode.',
        "SF_OT_workspace_profile_export_workspace_profiles": 'Export workspace profiles to JSON for backup, transfer, or team sharing.',
    }
    for name, desc in descriptions.items():
        _set_desc(name, desc)
