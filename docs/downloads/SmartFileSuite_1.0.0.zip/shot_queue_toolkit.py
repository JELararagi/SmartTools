# -----------------------------------------------------------------------------
#  Shot Queue Toolkit / Marker Capture / Batch Camera Queue
# -----------------------------------------------------------------------------

import json
import os
import time


_SF_SHOT_QUEUE_SCOPE_ITEMS = [
    ('ENABLED', 'Enabled', 'Run only the shots whose Enabled toggle is on.'),
    ('ALL', 'All', 'Run every stored shot regardless of the Enabled toggle.'),
]

_SF_SHOT_RUN_MODE_ITEMS = [
    ('APPLY', 'Apply Only', 'Apply each shot without rendering so you can verify cameras, ranges, and visibility quickly.'),
    ('STILL', 'Render Still', 'Render one still image for each stored shot.'),
    ('ANIMATION', 'Render Animation', 'Render the stored frame range for each shot as animation.'),
]

_SF_SHOT_CAPTURE_MODE_ITEMS = [
    ('FULL', 'Full State', 'Store full scene, render, object, and collection state. Use this when each shot needs its own visibility setup.'),
    ('SCENE_ONLY', 'Scene + Render Only', 'Store the camera, frame range, render settings, and markers only. Use this for lighter shot entries.'),
]

_SF_SHOT_DEPENDENCY_POLICY_ITEMS = [
    ('OFF', 'Off', 'Do not run the external-dependency scan before the queue. Use this only when you already validated the file elsewhere and want maximum speed.'),
    ('WARN', 'Warn Only', 'Scan the current file and continue even when issues are found, but record the warnings in the queue report.'),
    ('BLOCK', 'Block on Issues', 'Abort the queue before rendering when missing dependencies, missing shots, or duplicate outputs are detected.'),
]


def _sf_sq_now_text():
    try:
        return _sf_guard_now_text()
    except Exception:
        return time.strftime('%Y-%m-%d %H:%M:%S')


def _sf_sq_items(context):
    wm = getattr(context, 'window_manager', None)
    return list(getattr(wm, 'sf_shot_slots', []) or []) if wm is not None else []


def _sf_sq_active_index(context):
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return 0
    try:
        return int(getattr(wm, 'sf_shot_active_index', 0) or 0)
    except Exception:
        return 0


def _sf_sq_active_item(context):
    items = _sf_sq_items(context)
    if not items:
        return None
    idx = _sf_sq_active_index(context)
    idx = max(0, min(idx, len(items) - 1))
    return items[idx]


def _sf_sq_safe_name(text, fallback='Shot'):
    value = str(text or '').strip()
    return value or fallback


def _sf_sq_unique_name(items, wanted, fallback='Shot'):
    base = _sf_sq_safe_name(wanted, fallback)
    used = {str(getattr(it, 'name', '') or '').strip() for it in items if it is not None}
    if base not in used:
        return base
    idx = 2
    while True:
        trial = f'{base} {idx}'
        if trial not in used:
            return trial
        idx += 1


def _sf_sq_view_layer_name(context):
    try:
        return str(getattr(getattr(context, 'view_layer', None), 'name', '') or '')
    except Exception:
        return ''


def _sf_sq_default_name(context):
    scene = getattr(context, 'scene', None)
    camera = getattr(scene, 'camera', None) if scene is not None else None
    frame_current = 1
    try:
        frame_current = int(getattr(scene, 'frame_current', 1) or 1)
    except Exception:
        frame_current = 1
    cam_name = str(getattr(camera, 'name', '') or '').strip()
    if cam_name:
        return f'{cam_name} F{frame_current:04d}'
    scene_name = str(getattr(scene, 'name', '') or '').strip() if scene is not None else ''
    if scene_name:
        return f'{scene_name} F{frame_current:04d}'
    return f'Shot F{frame_current:04d}'


def _sf_sq_tokens(context, shot=None, *, scene_override=None):
    scene = scene_override if scene_override is not None else getattr(context, 'scene', None)
    render = getattr(scene, 'render', None) if scene is not None else None
    filepath = _norm_path(bpy.data.filepath or '')
    blend_dir = os.path.dirname(filepath) if filepath else _sf_user_default_dir('renders')
    blend_name = os.path.splitext(os.path.basename(filepath))[0] if filepath else 'unsaved'
    shot_name = str(getattr(shot, 'name', '') or '') if shot is not None else ''
    camera_name = str(getattr(shot, 'camera_name', '') or '') if shot is not None else ''
    if not camera_name and scene is not None:
        camera_name = str(getattr(getattr(scene, 'camera', None), 'name', '') or '')
    if not shot_name:
        shot_name = _sf_sq_default_name(context)
    scene_name = str(getattr(shot, 'scene_name', getattr(scene, 'name', '') if scene is not None else '') or '')
    view_layer = str(getattr(shot, 'view_layer_name', _sf_sq_view_layer_name(context)) or '')
    frame_start = int(getattr(shot, 'frame_start', getattr(scene, 'frame_start', 1)) or 1) if shot is not None else int(getattr(scene, 'frame_start', 1) or 1)
    frame_end = int(getattr(shot, 'frame_end', getattr(scene, 'frame_end', 250)) or 250) if shot is not None else int(getattr(scene, 'frame_end', 250) or 250)
    frame_current = int(getattr(shot, 'frame_current', getattr(scene, 'frame_current', 1)) or 1) if shot is not None else int(getattr(scene, 'frame_current', 1) or 1)
    engine = str(getattr(render, 'engine', '') or '') if render is not None else ''
    return {
        'blend_dir': blend_dir.replace('\\', '/'),
        'blend': _safe_filename(blend_name) or 'unsaved',
        'scene': _safe_filename(scene_name) or 'Scene',
        'shot': _safe_filename(shot_name) or 'Shot',
        'camera': _safe_filename(camera_name) or 'Camera',
        'view_layer': _safe_filename(view_layer) or 'ViewLayer',
        'frame_start': str(frame_start),
        'frame_end': str(frame_end),
        'frame_current': str(frame_current),
        'engine': _safe_filename(engine) or 'Engine',
    }


def _sf_sq_expand_tokens(context, template, shot=None, *, scene_override=None):
    value = str(template or '').strip() or '{blend_dir}/renders/{shot}/{shot}'
    for key, token_value in _sf_sq_tokens(context, shot, scene_override=scene_override).items():
        value = value.replace('{' + key + '}', str(token_value))
    return value.replace('\\', '/')


def _sf_sq_default_output_path(context, shot=None, *, scene_override=None):
    scene = scene_override if scene_override is not None else getattr(context, 'scene', None)
    render = getattr(scene, 'render', None) if scene is not None else None
    current = str(getattr(render, 'filepath', '') or '').strip() if render is not None else ''
    if current:
        if any(token in current for token in ('{shot}', '{camera}', '{scene}', '{blend}', '{blend_dir}', '{view_layer}')):
            return _sf_sq_expand_tokens(context, current, shot, scene_override=scene_override)
        if current.endswith('/') or current.endswith('\\'):
            return _sf_sq_expand_tokens(context, current.rstrip('/\\') + '/{shot}/{shot}', shot, scene_override=scene_override)
        return _sf_sq_expand_tokens(context, current + '_{shot}', shot, scene_override=scene_override)
    return _sf_sq_expand_tokens(context, '{blend_dir}/renders/{shot}/{shot}', shot, scene_override=scene_override)


def _sf_sq_capture_payload(context, capture_mode='FULL'):
    capture_mode = str(capture_mode or 'FULL').upper()
    include_objects = capture_mode == 'FULL'
    include_collections = capture_mode == 'FULL'
    payload = dict(_sf_guard_capture_scene_state(context, include_objects=include_objects, include_collections=include_collections) or {})
    if payload:
        payload['kind'] = 'shot_queue_state'
        payload['shot_capture_mode'] = capture_mode
        payload['view_layer'] = _sf_sq_view_layer_name(context)
    return payload


def _sf_sq_item_payload(item):
    raw = str(getattr(item, 'payload_json', '') or '')
    if not raw.strip():
        return {}
    try:
        payload = json.loads(raw)
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _sf_sq_fill_item_from_payload(item, payload, context, output_path='', name=''):
    scene_info = dict((payload or {}).get('scene') or {})
    render_info = dict((payload or {}).get('render') or {})
    scene = getattr(context, 'scene', None)
    render = getattr(scene, 'render', None) if scene is not None else None
    item.name = _sf_sq_safe_name(name or scene_info.get('camera') or scene_info.get('name') or _sf_sq_default_name(context), 'Shot')
    item.scene_name = str(scene_info.get('name', getattr(scene, 'name', '')) or '')
    item.camera_name = str(scene_info.get('camera', getattr(getattr(scene, 'camera', None), 'name', '') or '') or '')
    item.view_layer_name = str((payload or {}).get('view_layer', _sf_sq_view_layer_name(context)) or '')
    item.frame_start = int(scene_info.get('frame_start', getattr(scene, 'frame_start', 1)) or 1)
    item.frame_end = int(scene_info.get('frame_end', getattr(scene, 'frame_end', 250)) or 250)
    item.frame_current = int(scene_info.get('frame_current', getattr(scene, 'frame_current', 1)) or 1)
    item.resolution_x = int(render_info.get('resolution_x', getattr(render, 'resolution_x', 0)) or 0)
    item.resolution_y = int(render_info.get('resolution_y', getattr(render, 'resolution_y', 0)) or 0)
    item.resolution_percentage = int(render_info.get('resolution_percentage', getattr(render, 'resolution_percentage', 100)) or 100)
    item.file_format = str(render_info.get('file_format', getattr(getattr(render, 'image_settings', None), 'file_format', '') or '') or '')
    item.output_path = str(output_path or render_info.get('output_path', '') or _sf_sq_default_output_path(context, item))
    item.capture_mode = str((payload or {}).get('shot_capture_mode', 'FULL') or 'FULL')
    try:
        item.payload_json = json.dumps(payload or {}, ensure_ascii=False)
    except Exception:
        item.payload_json = ''


def _sf_sq_store_to_item(context, item, capture_mode='FULL', name='', notes=None):
    payload = _sf_sq_capture_payload(context, capture_mode=capture_mode)
    _sf_sq_fill_item_from_payload(item, payload, context, output_path=_sf_sq_default_output_path(context, item), name=name)
    if notes is not None:
        item.notes = str(notes or '')
    item.updated_at = _sf_sq_now_text()
    item.enabled = True
    wm = getattr(context, 'window_manager', None)
    if wm is not None:
        try:
            wm.sf_project_guard_scene_state_json = json.dumps(payload, ensure_ascii=False)
        except Exception:
            pass
    return payload


def _sf_sq_apply_view_layer(context, view_layer_name):
    name = str(view_layer_name or '').strip()
    if not name:
        return False
    scene = getattr(context, 'scene', None)
    window = getattr(context, 'window', None)
    if scene is None or window is None:
        return False
    try:
        view_layer = scene.view_layers.get(name)
    except Exception:
        view_layer = None
    if view_layer is None:
        return False
    try:
        window.view_layer = view_layer
        return True
    except Exception:
        return False


def _sf_sq_switch_to_scene(context, scene_name):
    name = str(scene_name or '').strip()
    if not name:
        return getattr(context, 'scene', None), False, False
    target_scene = bpy.data.scenes.get(name)
    if target_scene is None:
        return getattr(context, 'scene', None), False, True
    window = getattr(context, 'window', None)
    switched = False
    if window is not None:
        try:
            if window.scene is not target_scene:
                window.scene = target_scene
                switched = True
        except Exception:
            pass
    return getattr(context, 'scene', None) or target_scene, switched, False


def _sf_sq_apply_item(context, item):
    scene = getattr(context, 'scene', None)
    if scene is None or item is None:
        return {'restored': 0, 'missing': 0, 'failed': 1, 'view_layer': False, 'scene_switched': False, 'aborted': True, 'reason': 'missing context'}

    payload = _sf_sq_item_payload(item)
    requested_scene_name = _sf_sq_requested_scene_name(item)

    resolved_scene, switched, missing_scene = _sf_sq_switch_to_scene(context, requested_scene_name)
    if resolved_scene is None:
        return {'restored': 0, 'missing': 1 if missing_scene else 0, 'failed': 1, 'view_layer': False, 'scene_switched': switched, 'aborted': True, 'reason': 'scene unavailable'}
    if missing_scene:
        return {'restored': 0, 'missing': 1, 'failed': 1, 'view_layer': False, 'scene_switched': switched, 'aborted': True, 'reason': 'scene missing'}

    if payload:
        shot_payload = dict(payload)
        shot_payload['kind'] = 'scene_state_snapshot'
        result = _sf_guard_restore_scene_state_from_payload(context, shot_payload, apply_markers=True, replace_markers=False)
        result['scene_switched'] = bool(result.get('scene_switched')) or switched
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            try:
                wm.sf_project_guard_scene_state_json = json.dumps(shot_payload, ensure_ascii=False)
            except Exception:
                pass
    else:
        result = {'restored': 0, 'missing': 0, 'failed': 0, 'scene_switched': switched, 'aborted': False, 'reason': ''}

    scene = getattr(context, 'scene', None) or resolved_scene
    if missing_scene:
        result['missing'] = int(result.get('missing', 0) or 0) + 1
    render = getattr(scene, 'render', None)
    try:
        cam_name = str(getattr(item, 'camera_name', '') or '')
        if cam_name:
            cam = bpy.data.objects.get(cam_name)
            if cam is not None:
                scene.camera = cam
            else:
                result['missing'] = int(result.get('missing', 0) or 0) + 1
        scene.frame_start = int(getattr(item, 'frame_start', getattr(scene, 'frame_start', 1)) or 1)
        scene.frame_end = int(getattr(item, 'frame_end', getattr(scene, 'frame_end', 250)) or 250)
        frame_current = int(getattr(item, 'frame_current', getattr(scene, 'frame_current', 1)) or 1)
        try:
            scene.frame_set(frame_current)
        except Exception:
            scene.frame_current = frame_current
        if render is not None:
            render.resolution_x = int(getattr(item, 'resolution_x', getattr(render, 'resolution_x', 0)) or 0)
            render.resolution_y = int(getattr(item, 'resolution_y', getattr(render, 'resolution_y', 0)) or 0)
            render.resolution_percentage = int(getattr(item, 'resolution_percentage', getattr(render, 'resolution_percentage', 100)) or 100)
            if str(getattr(item, 'output_path', '') or '').strip():
                render.filepath = _sf_sq_expand_tokens(context, str(getattr(item, 'output_path', '') or ''), item)
            image_settings = getattr(render, 'image_settings', None)
            if image_settings is not None and str(getattr(item, 'file_format', '') or '').strip():
                image_settings.file_format = str(getattr(item, 'file_format', '') or '')
    except Exception:
        result['failed'] = int(result.get('failed', 0) or 0) + 1
    result['view_layer'] = _sf_sq_apply_view_layer(context, str(getattr(item, 'view_layer_name', '') or ''))
    result['aborted'] = False
    result['reason'] = str(result.get('reason', '') or '')
    return result


def _sf_sq_markers_sorted(scene):
    markers = list(getattr(scene, 'timeline_markers', []) or [])
    markers.sort(key=lambda m: (int(getattr(m, 'frame', 0) or 0), str(getattr(m, 'name', '') or '')))
    return markers


def _sf_sq_marker_payload(context, marker, next_frame=None, capture_mode='SCENE_ONLY'):
    payload = _sf_sq_capture_payload(context, capture_mode=capture_mode)
    payload['kind'] = 'shot_queue_state'
    scene_info = dict(payload.get('scene') or {})
    scene_info['camera'] = str(getattr(getattr(marker, 'camera', None), 'name', '') or scene_info.get('camera', ''))
    frame_start = int(getattr(marker, 'frame', 1) or 1)
    frame_end = max(frame_start, int(next_frame) - 1) if next_frame is not None else int(getattr(context.scene, 'frame_end', frame_start) or frame_start)
    scene_info['frame_start'] = frame_start
    scene_info['frame_end'] = frame_end
    scene_info['frame_current'] = frame_start
    payload['scene'] = scene_info
    return payload


def _sf_sq_scene_view_layer_name(scene, fallback: str = '') -> str:
    try:
        view_layers = getattr(scene, 'view_layers', None)
        if view_layers:
            active = getattr(view_layers, 'active', None)
            if active is not None:
                return str(getattr(active, 'name', '') or fallback or '')
            first = view_layers[0] if len(view_layers) else None
            return str(getattr(first, 'name', '') or fallback or '')
    except Exception:
        pass
    return str(fallback or '')



def _sf_sq_camera_objects_in_scene(scene, *, include_hidden: bool = True):
    out = []
    try:
        objects = list(getattr(scene, 'objects', []) or [])
    except Exception:
        objects = []
    for ob in objects:
        try:
            if str(getattr(ob, 'type', '') or '') != 'CAMERA':
                continue
        except Exception:
            continue
        if not include_hidden:
            try:
                if bool(getattr(ob, 'hide_render', False)) and bool(getattr(ob, 'hide_viewport', False)):
                    continue
            except Exception:
                pass
        out.append(ob)
    out.sort(key=lambda ob: str(getattr(ob, 'name', '') or ''))
    return out



def _sf_sq_payload_for_scene_camera(context, scene, camera_obj, capture_mode='SCENE_ONLY'):
    capture_mode = str(capture_mode or 'SCENE_ONLY').upper()
    include_objects = capture_mode == 'FULL'
    include_collections = capture_mode == 'FULL'
    payload = {
        'tool': 'Smart File',
        'kind': 'shot_queue_state',
        'version': _sf_pipe_version_text(),
        'created_at': _sf_sq_now_text(),
        'timestamp_unix': int(time.time()),
        'file': _norm_path(bpy.data.filepath or ''),
        'scene': {
            'name': str(getattr(scene, 'name', '') or ''),
            'camera': str(getattr(camera_obj, 'name', '') or ''),
            'world': str(getattr(getattr(scene, 'world', None), 'name', '') or ''),
            'frame_start': int(getattr(scene, 'frame_start', 1) or 1),
            'frame_end': int(getattr(scene, 'frame_end', 250) or 250),
            'frame_current': int(getattr(scene, 'frame_current', 1) or 1),
            'use_preview_range': bool(getattr(scene, 'use_preview_range', False)),
            'frame_preview_start': int(getattr(scene, 'frame_preview_start', getattr(scene, 'frame_start', 1)) or getattr(scene, 'frame_start', 1) or 1),
            'frame_preview_end': int(getattr(scene, 'frame_preview_end', getattr(scene, 'frame_end', 250)) or getattr(scene, 'frame_end', 250) or 250),
        },
        'render': dict(_sf_guard_render_settings_snapshot(scene) or {}),
        'markers': [
            {
                'name': str(getattr(marker, 'name', '') or ''),
                'frame': int(getattr(marker, 'frame', 0) or 0),
                'camera': str(getattr(getattr(marker, 'camera', None), 'name', '') or ''),
            }
            for marker in getattr(scene, 'timeline_markers', []) or []
        ],
        'object_states': [],
        'collection_states': [],
        'shot_capture_mode': capture_mode,
        'view_layer': _sf_sq_scene_view_layer_name(scene, fallback=_sf_sq_view_layer_name(context)),
    }
    if include_objects:
        for ob in getattr(scene, 'objects', []) or []:
            entry = {'name': str(getattr(ob, 'name', '') or '')}
            if not entry['name']:
                continue
            for attr in ('hide_viewport', 'hide_render', 'display_type'):
                try:
                    entry[attr] = getattr(ob, attr)
                except Exception:
                    pass
            payload['object_states'].append(entry)
    if include_collections:
        for coll in getattr(bpy.data, 'collections', []) or []:
            entry = {'name': str(getattr(coll, 'name', '') or '')}
            if not entry['name']:
                continue
            for attr in ('hide_viewport', 'hide_render'):
                try:
                    entry[attr] = getattr(coll, attr)
                except Exception:
                    pass
            payload['collection_states'].append(entry)
    return payload



def _sf_sq_selected_items(context, queue_scope='ENABLED'):
    items = _sf_sq_items(context)
    scope = str(queue_scope or 'ENABLED').upper()
    if scope == 'ALL':
        return items
    return [item for item in items if bool(getattr(item, 'enabled', False))]


def _sf_sq_requested_scene_name(item):
    payload = _sf_sq_item_payload(item)
    requested = ''
    if payload:
        requested = str(dict(payload.get('scene') or {}).get('name', '') or '').strip()
    if not requested:
        requested = str(getattr(item, 'scene_name', '') or '').strip()
    return requested


def _sf_sq_capture_scene_restore_payload(context, scene_name, *, include_collections=False):
    name = str(scene_name or '').strip()
    scene = getattr(context, 'scene', None)
    if scene is None:
        return {}
    if not name or name == str(getattr(scene, 'name', '') or ''):
        payload = _sf_guard_capture_scene_state(context, include_objects=True, include_collections=include_collections)
        if payload:
            payload['window_view_layer'] = _sf_sq_view_layer_name(context)
        return payload

    target_scene = bpy.data.scenes.get(name)
    if target_scene is None:
        return {}

    window = getattr(context, 'window', None)
    prev_scene = getattr(context, 'scene', None)
    prev_scene_name = str(getattr(prev_scene, 'name', '') or '') if prev_scene is not None else ''
    prev_view_layer_name = str(getattr(getattr(context, 'view_layer', None), 'name', '') or '')
    payload = {}
    if window is None:
        return payload
    try:
        window.scene = target_scene
        payload = _sf_guard_capture_scene_state(context, include_objects=True, include_collections=include_collections)
        if payload:
            payload['window_view_layer'] = _sf_sq_view_layer_name(context)
    except Exception:
        payload = {}
    finally:
        try:
            if prev_scene_name:
                restore_scene = bpy.data.scenes.get(prev_scene_name)
                if restore_scene is not None:
                    window.scene = restore_scene
                    if prev_view_layer_name:
                        try:
                            restore_view_layer = restore_scene.view_layers.get(prev_view_layer_name)
                        except Exception:
                            restore_view_layer = None
                        if restore_view_layer is not None:
                            try:
                                window.view_layer = restore_view_layer
                            except Exception:
                                pass
        except Exception:
            pass
    return payload


def _sf_sq_restore_scene_payloads(context, payloads, original_scene_name=''):
    restored = 0
    failed = 0
    original_name = str(original_scene_name or '').strip()
    names = [name for name in list(payloads.keys()) if str(name or '').strip() and str(name or '').strip() != original_name]
    if original_name and original_name in payloads:
        names.append(original_name)
    for name in names:
        payload = dict(payloads.get(name) or {})
        if not payload:
            continue
        try:
            _sf_guard_restore_scene_state_from_payload(context, payload)
            view_layer_name = str(payload.get('window_view_layer', '') or '').strip()
            if view_layer_name:
                _sf_sq_apply_view_layer(context, view_layer_name)
            restored += 1
        except Exception:
            failed += 1
    return {'restored_scenes': restored, 'failed_scenes': failed}


def _sf_sq_output_path_for_item(context, item, *, scene_override=None):
    template = str(getattr(item, 'output_path', '') or '').strip()
    if template:
        return _sf_sq_expand_tokens(context, template, item, scene_override=scene_override)
    return _sf_sq_default_output_path(context, item, scene_override=scene_override)


def _sf_sq_summary(context):
    items = _sf_sq_items(context)
    enabled = [item for item in items if bool(getattr(item, 'enabled', False))]
    missing_camera = 0
    missing_scene = 0
    with_payload = 0
    ready_output = 0
    duplicate_output = 0
    seen_outputs = {}
    for item in items:
        requested_scene = _sf_sq_requested_scene_name(item)
        target_scene = bpy.data.scenes.get(requested_scene) if requested_scene else getattr(context, 'scene', None)
        if requested_scene and target_scene is None:
            missing_scene += 1
        cam_name = str(getattr(item, 'camera_name', '') or '')
        if cam_name and bpy.data.objects.get(cam_name) is None:
            missing_camera += 1
        if str(getattr(item, 'payload_json', '') or '').strip():
            with_payload += 1
        try:
            output_path = _sf_sq_output_path_for_item(context, item, scene_override=target_scene)
        except Exception:
            output_path = ''
        if output_path:
            ready_output += 1
            key = _norm_path(output_path).lower()
            seen_outputs[key] = seen_outputs.get(key, 0) + 1
    duplicate_output = sum(1 for count in seen_outputs.values() if count > 1)
    return {
        'total': len(items),
        'enabled': len(enabled),
        'missing_camera': missing_camera,
        'missing_scene': missing_scene,
        'with_payload': with_payload,
        'ready_output': ready_output,
        'duplicate_output': duplicate_output,
    }


def _sf_sq_preflight_payload(context, *, queue_scope='ENABLED', include_dependencies: bool = True):
    items = list(_sf_sq_selected_items(context, queue_scope) or [])
    missing_scenes = []
    missing_cameras = []
    output_groups = {}
    rows = []
    for item in items:
        shot_name = str(getattr(item, 'name', '') or _t('Shot'))
        requested_scene = _sf_sq_requested_scene_name(item)
        target_scene = bpy.data.scenes.get(requested_scene) if requested_scene else getattr(context, 'scene', None)
        if requested_scene and target_scene is None:
            missing_scenes.append({'shot': shot_name, 'scene': requested_scene})
            rows.append(f"- [SCENE] {shot_name} | {requested_scene}")
        cam_name = str(getattr(item, 'camera_name', '') or '')
        if cam_name and bpy.data.objects.get(cam_name) is None:
            missing_cameras.append({'shot': shot_name, 'camera': cam_name})
            rows.append(f"- [CAMERA] {shot_name} | {cam_name}")
        try:
            output_path = _sf_sq_output_path_for_item(context, item, scene_override=target_scene)
        except Exception:
            output_path = ''
        if output_path:
            key = _norm_path(output_path).lower()
            output_groups.setdefault(key, []).append({'shot': shot_name, 'path': _norm_path(output_path)})
    duplicate_outputs = [group for group in output_groups.values() if len(group) > 1]

    dependency_summary = {}
    if include_dependencies:
        try:
            dep_records = _sf_ext_collect_current_file_records(include_libraries=True, include_texts=False, include_missing=True)
            dependency_summary = dict(_sf_ext_summary(dep_records) or {})
        except Exception:
            dependency_summary = {}
    blocking_issue_count = len(missing_scenes) + len(missing_cameras) + len(duplicate_outputs)
    if include_dependencies:
        blocking_issue_count += int(dependency_summary.get('missing_records', 0) or 0)
    return {
        'queue_scope': str(queue_scope or 'ENABLED').upper(),
        'items': items,
        'selected_count': len(items),
        'missing_scenes': missing_scenes,
        'missing_cameras': missing_cameras,
        'duplicate_outputs': duplicate_outputs,
        'dependency_summary': dependency_summary,
        'blocking_issue_count': int(blocking_issue_count or 0),
        'issue_preview': rows[:12],
    }


def _sf_sq_preflight_report_lines(context, title: str, payload: dict) -> list[str]:
    payload = dict(payload or {})
    dep = dict(payload.get('dependency_summary') or {})
    lines = [
        f'Smart File | {title} | {_sf_sq_now_text()}',
        '',
        f"- {_t('Scope')}: {payload.get('queue_scope', 'ENABLED')}",
        f"- {_t('Shots')}: {int(payload.get('selected_count', 0) or 0)}",
        f"- {_t('Missing Scenes')}: {len(payload.get('missing_scenes') or [])}",
        f"- {_t('Missing Cameras')}: {len(payload.get('missing_cameras') or [])}",
        f"- {_t('Duplicate Outputs')}: {len(payload.get('duplicate_outputs') or [])}",
    ]
    if dep:
        lines.extend([
            f"- {_t('Missing Dependencies')}: {int(dep.get('missing_records', 0) or 0)}",
            f"- {_t('Absolute Dependencies')}: {int(dep.get('absolute_records', 0) or 0)}",
            f"- {_t('Environment Variables')}: {int(dep.get('env_records', 0) or 0)}",
        ])
    if payload.get('missing_scenes'):
        lines.extend(['', 'MISSING SCENES'])
        for row in list(payload.get('missing_scenes') or []):
            lines.append(f"- {row.get('shot','')} | {row.get('scene','')}")
    if payload.get('missing_cameras'):
        lines.extend(['', 'MISSING CAMERAS'])
        for row in list(payload.get('missing_cameras') or []):
            lines.append(f"- {row.get('shot','')} | {row.get('camera','')}")
    duplicate_outputs = list(payload.get('duplicate_outputs') or [])
    if duplicate_outputs:
        lines.extend(['', 'DUPLICATE OUTPUTS'])
        for group in duplicate_outputs[:12]:
            if not group:
                continue
            lines.append(f"- {group[0].get('path','')}")
            for row in group:
                lines.append(f"  - {row.get('shot','')}")
    return lines


def _sf_sq_report_lines(context, title, rows, run_mode='APPLY', queue_scope='ENABLED', preflight=None):
    summary = _sf_sq_summary(context)
    lines = [
        f'Smart File | {title} | {_sf_sq_now_text()}',
        '',
        f"- {_t('Mode')}: {run_mode}",
        f"- {_t('Scope')}: {queue_scope}",
        f"- {_t('Shots')}: {summary.get('total', 0)}",
        f"- {_t('Enabled')}: {summary.get('enabled', 0)}",
    ]
    if preflight is not None:
        dep = dict((preflight or {}).get('dependency_summary') or {})
        lines.extend([
            '',
            'Preflight',
            '-' * 48,
            f"- {_t('Missing Scenes')}: {len((preflight or {}).get('missing_scenes') or [])}",
            f"- {_t('Missing Cameras')}: {len((preflight or {}).get('missing_cameras') or [])}",
            f"- {_t('Duplicate Outputs')}: {len((preflight or {}).get('duplicate_outputs') or [])}",
            f"- {_t('Issues found')}: {int((preflight or {}).get('blocking_issue_count', 0) or 0)}",
        ])
        if dep:
            lines.extend([
                f"- {_t('Missing Dependencies')}: {int(dep.get('missing_records', 0) or 0)}",
                f"- {_t('Absolute Dependencies')}: {int(dep.get('absolute_records', 0) or 0)}",
                f"- {_t('Environment Variables')}: {int(dep.get('env_records', 0) or 0)}",
            ])
        preview_rows = list((preflight or {}).get('issue_preview') or [])
        if preview_rows:
            lines.append(f"- {_t('Preview')}:")
            for preview in preview_rows[:8]:
                lines.append(f"  {preview}")
    lines.extend([
        '',
        'Results',
        '-' * 48,
    ])
    for row in rows:
        lines.append(f"* {row.get('shot', '')} | {row.get('status', '')} | {row.get('detail', '')}")
    if not rows:
        lines.append(f"* {_t('No shots were processed')}")
    return lines

def _sf_sq_ensure_output_parent(path):
    target = str(path or '').strip()
    if not target:
        return
    folder = target if target.endswith('/') or target.endswith('\\') else os.path.dirname(target)
    folder = _norm_path(folder or '')
    if folder:
        os.makedirs(folder, exist_ok=True)


class SF_ShotSlotItem(bpy.types.PropertyGroup):
    bl_description = 'Store one queued shot recipe, including camera, frame range, output path, and saved state payload, so batch runs stay readable and editable.'

    enabled: BoolProperty(
        name='Enabled',
        default=True,
        description='Include this shot in queue runs when the queue scope is set to Enabled only. Disable it temporarily when you want to keep the shot stored but skip it in the next batch.',
    )
    name: StringProperty(
        name='Shot Name',
        default='Shot',
        description='Friendly shot label shown in the list, reports, and output tokens. Use a short production-facing name such as SH010 or Lobby_CloseUp.',
    )
    notes: StringProperty(
        name='Notes',
        default='',
        description='Optional reminder for artists, such as what changed in this shot or what to check before rendering.',
    )
    scene_name: StringProperty(name='Scene', default='')
    camera_name: StringProperty(name='Camera', default='')
    view_layer_name: StringProperty(name='View Layer', default='')
    frame_start: IntProperty(name='Start', default=1)
    frame_end: IntProperty(name='End', default=250)
    frame_current: IntProperty(name='Current', default=1)
    resolution_x: IntProperty(name='Width', default=1920)
    resolution_y: IntProperty(name='Height', default=1080)
    resolution_percentage: IntProperty(name='Scale', default=100, min=1, max=1000)
    output_path: StringProperty(
        name='Output Path',
        subtype='FILE_PATH',
        default='',
        description='Per-shot output path. You can use tokens like {shot}, {camera}, {scene}, {blend}, {blend_dir}, and {view_layer}.',
    )
    file_format: StringProperty(name='Format', default='PNG')
    capture_mode: EnumProperty(
        name='Capture Mode',
        items=_SF_SHOT_CAPTURE_MODE_ITEMS,
        default='FULL',
        description='Choose whether this shot stores full object and collection visibility state, or only scene and render state. Full mode is safer for shot-specific visibility changes, while Scene Only keeps entries lighter.',
    )
    payload_json: StringProperty(name='Payload JSON', default='', options={'HIDDEN'})
    updated_at: StringProperty(name='Updated At', default='', options={'HIDDEN'})


class SF_UL_shot_queue_shot_queue_slot_list(bpy.types.UIList):
    bl_label = 'Shot Queue Slot List'
    bl_idname = 'SF_UL_shot_queue_shot_queue_slot_list'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        shot = item
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(shot, 'enabled', text='')
            icon_name = 'CAMERA_DATA'
            cam_name = str(getattr(shot, 'camera_name', '') or '')
            scene_name = _sf_sq_requested_scene_name(shot)
            if scene_name and bpy.data.scenes.get(scene_name) is None:
                icon_name = 'ERROR'
            elif cam_name and bpy.data.objects.get(cam_name) is None:
                icon_name = 'ERROR'
            row.label(text=str(getattr(shot, 'name', '') or _t('Shot')), icon=icon_name, translate=False)
            sub = row.row(align=True)
            sub.enabled = False
            sub.label(text=cam_name or _t('No Camera'), translate=False)
            sub.label(text=f"{int(getattr(shot, 'frame_start', 1) or 1)}-{int(getattr(shot, 'frame_end', 1) or 1)}")
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text='', icon='CAMERA_DATA')

class SF_OT_shot_queue_store_current(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_store_current'
    bl_label = 'Store Current'
    bl_description = 'Capture the current camera, frame range, render settings, and optionally visibility state into a reusable shot entry. Use this before review tweaks, per-camera variants, or batch rendering so the setup can be recalled safely later.'
    bl_options = {'UNDO'}

    append_new: BoolProperty(name='Append New', default=False, description='Always add a new shot item instead of updating the active one.')
    capture_mode: EnumProperty(name='Capture Mode', items=_SF_SHOT_CAPTURE_MODE_ITEMS, default='FULL')
    custom_name: StringProperty(name='Shot Name', default='', description='Optional shot name. Leave blank to build a name from the active camera and frame.')

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, _t('No WindowManager'))
            return {'CANCELLED'}
        items = wm.sf_shot_slots
        target = None
        if not self.append_new:
            target = _sf_sq_active_item(context)
        if target is None:
            target = items.add()
            wm.sf_shot_active_index = len(items) - 1
        wanted = self.custom_name.strip() or getattr(target, 'name', '') or _sf_sq_default_name(context)
        _sf_sq_store_to_item(context, target, capture_mode=self.capture_mode, name=wanted)
        existing = [it for it in items if it != target]
        target.name = _sf_sq_unique_name(existing, target.name, 'Shot')
        try:
            _sf_append_activity(context, _t('Stored current shot'), target.name, 'CAMERA_DATA')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Stored')}: {target.name}")
        return {'FINISHED'}


class SF_OT_shot_queue_capture_from_camera_markers(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_capture_from_camera_markers'
    bl_label = 'Capture From Camera Markers'
    bl_description = 'Create or append shot entries from timeline markers that have cameras assigned. This gives Blender a compact shot-manager workflow similar to camera-based batch tools in larger DCC applications.'
    bl_options = {'UNDO'}

    clear_existing: BoolProperty(name='Replace existing', default=False, description='Clear the current shot list before building shots from markers.')
    capture_mode: EnumProperty(name='Capture Mode', items=_SF_SHOT_CAPTURE_MODE_ITEMS, default='SCENE_ONLY')

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        wm = getattr(context, 'window_manager', None)
        if scene is None or wm is None:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        markers = [m for m in _sf_sq_markers_sorted(scene) if getattr(m, 'camera', None) is not None]
        if not markers:
            self.report({'WARNING'}, _t('No camera markers were found'))
            return {'CANCELLED'}
        if self.clear_existing:
            wm.sf_shot_slots.clear()
            wm.sf_shot_active_index = 0
        created = 0
        for idx, marker in enumerate(markers):
            next_frame = getattr(markers[idx + 1], 'frame', None) if idx + 1 < len(markers) else None
            payload = _sf_sq_marker_payload(context, marker, next_frame, capture_mode=self.capture_mode)
            item = wm.sf_shot_slots.add()
            name = str(getattr(marker, 'name', '') or '') or f"{getattr(getattr(marker, 'camera', None), 'name', 'Camera')} F{int(getattr(marker, 'frame', 1) or 1):04d}"
            _sf_sq_fill_item_from_payload(item, payload, context, output_path='', name=name)
            item.output_path = _sf_sq_default_output_path(context, item)
            item.updated_at = _sf_sq_now_text()
            item.enabled = True
            created += 1
        wm.sf_shot_active_index = max(0, len(wm.sf_shot_slots) - created)
        try:
            _sf_append_activity(context, _t('Created shots from markers'), str(created), 'CAMERA_DATA')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Created')}: {created}")
        return {'FINISHED'}


class SF_OT_shot_queue_capture_from_cameras(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_capture_from_cameras'
    bl_label = 'Capture From Cameras'
    bl_description = 'Create or append shot entries from camera objects in the current scene or across all scenes. This adds a Blender-native batch-camera workflow similar to Shot Manager, Save Cams, and multi-camera render utilities from other DCC tools.'
    bl_options = {'UNDO'}

    clear_existing: BoolProperty(name='Replace existing', default=False, description='Clear the current shot list before building shots from cameras.')
    capture_mode: EnumProperty(name='Capture Mode', items=_SF_SHOT_CAPTURE_MODE_ITEMS, default='SCENE_ONLY')
    scene_scope: EnumProperty(
        name='Scene Scope',
        items=[
            ('CURRENT_SCENE', 'Current Scene', 'Read camera objects only from the current scene.'),
            ('ALL_SCENES', 'All Scenes', 'Read camera objects from every scene in the file and queue them together.'),
        ],
        default='CURRENT_SCENE',
    )
    include_hidden: BoolProperty(name='Include hidden cameras', default=True, description='When enabled, cameras hidden for viewport and render are still converted into queue entries. Disable this to build a cleaner review queue from active cameras only.')

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        scene = getattr(context, 'scene', None)
        if wm is None or scene is None:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        scenes = [scene] if str(self.scene_scope or 'CURRENT_SCENE').upper() == 'CURRENT_SCENE' else list(getattr(bpy.data, 'scenes', []) or [])
        if self.clear_existing:
            wm.sf_shot_slots.clear()
            wm.sf_shot_active_index = 0
        created = 0
        for target_scene in scenes:
            cameras = _sf_sq_camera_objects_in_scene(target_scene, include_hidden=bool(self.include_hidden))
            for camera_obj in cameras:
                payload = _sf_sq_payload_for_scene_camera(context, target_scene, camera_obj, capture_mode=self.capture_mode)
                item = wm.sf_shot_slots.add()
                scene_name = str(getattr(target_scene, 'name', '') or '').strip()
                camera_name = str(getattr(camera_obj, 'name', '') or '').strip()
                if len(scenes) > 1 and scene_name:
                    name = f"{scene_name} | {camera_name or 'Camera'}"
                else:
                    name = camera_name or f"{scene_name or 'Scene'} Camera"
                _sf_sq_fill_item_from_payload(item, payload, context, output_path='', name=name)
                item.output_path = str(dict(payload.get('render') or {}).get('output_path', '') or _sf_sq_default_output_path(context, item))
                item.updated_at = _sf_sq_now_text()
                item.enabled = True
                created += 1
        if created == 0:
            self.report({'INFO'}, _t('No camera objects were found for the chosen scope'))
            return {'FINISHED'}
        wm.sf_shot_active_index = max(0, len(wm.sf_shot_slots) - created)
        try:
            _sf_append_activity(context, _t('Created shots from cameras'), str(created), 'CAMERA_DATA')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Created')}: {created}")
        return {'FINISHED'}



class SF_OT_shot_queue_apply_active(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_apply_active'
    bl_label = 'Apply Active'
    bl_description = 'Apply the selected shot safely. If the shot stores a different scene name, the operator switches to that scene first; if the stored scene is missing, it stops instead of overwriting the wrong scene.'
    bl_options = {'UNDO'}

    def execute(self, context):
        item = _sf_sq_active_item(context)
        if item is None:
            self.report({'WARNING'}, _t('No active shot'))
            return {'CANCELLED'}
        result = _sf_sq_apply_item(context, item)
        if bool(result.get('aborted')):
            detail = str(result.get('reason', '') or _t('Failed'))
            self.report({'ERROR'}, f"{_t('Failed')}: {item.name} | {detail}")
            return {'CANCELLED'}
        try:
            _sf_append_activity(context, _t('Applied shot'), item.name, 'CAMERA_DATA')
        except Exception:
            pass
        self.report({'WARNING'} if (int(result.get('missing', 0) or 0) or int(result.get('failed', 0) or 0)) else {'INFO'}, f"{_t('Applied')}: {item.name}")
        return {'FINISHED'}


class SF_OT_shot_queue_remove_active(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_remove_active'
    bl_label = 'Remove Active'
    bl_description = 'Remove the currently selected shot from the list. This only removes the saved entry; it does not delete any cameras, scenes, or rendered files.'
    bl_options = {'UNDO'}

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return {'CANCELLED'}
        idx = _sf_sq_active_index(context)
        items = wm.sf_shot_slots
        if idx < 0 or idx >= len(items):
            self.report({'WARNING'}, _t('No active shot'))
            return {'CANCELLED'}
        name = str(getattr(items[idx], 'name', '') or '')
        items.remove(idx)
        wm.sf_shot_active_index = min(max(0, idx - 1), max(0, len(items) - 1))
        try:
            _sf_append_activity(context, _t('Removed shot'), name, 'TRASH')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Removed')}: {name}")
        return {'FINISHED'}


class SF_OT_shot_queue_move_active(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_move_active'
    bl_label = 'Move Active'
    bl_description = 'Move the active shot up or down in the queue order. Queue execution follows this order, so use it to control review and render sequence.'
    bl_options = {'UNDO'}

    direction: EnumProperty(name='Direction', items=[('UP', 'Up', ''), ('DOWN', 'Down', '')], default='UP')

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return {'CANCELLED'}
        idx = _sf_sq_active_index(context)
        items = wm.sf_shot_slots
        if idx < 0 or idx >= len(items):
            self.report({'WARNING'}, _t('No active shot'))
            return {'CANCELLED'}
        other = idx - 1 if self.direction == 'UP' else idx + 1
        if other < 0 or other >= len(items):
            return {'CANCELLED'}
        items.move(idx, other)
        wm.sf_shot_active_index = other
        return {'FINISHED'}


class SF_OT_shot_queue_export_queue(bpy.types.Operator, ExportHelper):
    bl_idname = 'export_scene.sfs_shot_queue_export_queue'
    bl_label = 'Export Queue'
    bl_description = 'Write the current shot list into a JSON queue file so another scene or teammate can restore the same shot order, camera assignments, ranges, and per-shot output settings.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.sf_shot_queue.json'
    filter_glob: StringProperty(default='*.sf_shot_queue.json;*.json', options={'HIDDEN'})
    open_folder: BoolProperty(name='Open folder', default=False, description='Open the destination folder after export.')

    def invoke(self, context, event):
        scene = getattr(context, 'scene', None)
        seed = _sf_pipe_safe_name(getattr(scene, 'name', '') or os.path.splitext(os.path.basename(bpy.data.filepath or 'shot_queue'))[0], 'shot_queue')
        if not self.filepath:
            start_dir = _sf_ref_rel_base_dir() or _sf_user_default_dir('handoff')
            self.filepath = os.path.join(start_dir, f'{seed}.sf_shot_queue.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('Output path is required'))
            return {'CANCELLED'}
        if not filepath.lower().endswith('.sf_shot_queue.json'):
            filepath += '.sf_shot_queue.json'
        items = list(_sf_sq_items(context) or [])
        data = {
            'tool': 'Smart File',
            'kind': 'shot_queue',
            'version': _sf_pipe_version_text(),
            'created_at': _sf_sq_now_text(),
            'file': _norm_path(bpy.data.filepath or ''),
            'active_index': _sf_sq_active_index(context),
            'shots': [],
        }
        for item in items:
            data['shots'].append({
                'enabled': bool(getattr(item, 'enabled', False)),
                'name': str(getattr(item, 'name', '') or ''),
                'notes': str(getattr(item, 'notes', '') or ''),
                'scene_name': str(getattr(item, 'scene_name', '') or ''),
                'camera_name': str(getattr(item, 'camera_name', '') or ''),
                'view_layer_name': str(getattr(item, 'view_layer_name', '') or ''),
                'frame_start': int(getattr(item, 'frame_start', 1) or 1),
                'frame_end': int(getattr(item, 'frame_end', 250) or 250),
                'frame_current': int(getattr(item, 'frame_current', 1) or 1),
                'resolution_x': int(getattr(item, 'resolution_x', 0) or 0),
                'resolution_y': int(getattr(item, 'resolution_y', 0) or 0),
                'resolution_percentage': int(getattr(item, 'resolution_percentage', 100) or 100),
                'output_path': str(getattr(item, 'output_path', '') or ''),
                'file_format': str(getattr(item, 'file_format', '') or ''),
                'capture_mode': str(getattr(item, 'capture_mode', 'FULL') or 'FULL'),
                'payload': _sf_sq_item_payload(item),
                'updated_at': str(getattr(item, 'updated_at', '') or ''),
            })
        _sf_pipe_json_write(filepath, data)
        if self.open_folder:
            try:
                bpy.ops.wm.path_open(filepath=os.path.dirname(filepath) or filepath)
            except Exception:
                pass
        try:
            _sf_append_activity(context, _t('Exported shot queue'), os.path.basename(filepath), 'EXPORT')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Shot Queue')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_shot_queue_import_queue(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.sfs_shot_queue_import_queue'
    bl_label = 'Import Queue'
    bl_description = 'Read a previously exported Smart File shot queue and rebuild the shot list in the current session. This is useful for handoff, template scenes, and render review setups.'
    bl_options = {'UNDO'}

    filter_glob: StringProperty(default='*.sf_shot_queue.json;*.json', options={'HIDDEN'})
    clear_existing: BoolProperty(name='Replace existing', default=False, description='Clear the current shot list before importing the file.')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath or not os.path.isfile(filepath):
            self.report({'ERROR'}, _t('Shot-queue file was not found'))
            return {'CANCELLED'}
        data = _sf_pipe_json_read(filepath)
        kind = str(data.get('kind', '') or '')
        if kind != 'shot_queue':
            self.report({'ERROR'}, _t('This file is not a Smart File shot queue'))
            return {'CANCELLED'}
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return {'CANCELLED'}
        if self.clear_existing:
            wm.sf_shot_slots.clear()
            wm.sf_shot_active_index = 0
        created = 0
        for row in list(data.get('shots', []) or []):
            item = wm.sf_shot_slots.add()
            item.enabled = bool(row.get('enabled', False))
            item.name = str(row.get('name', '') or _sf_sq_default_name(context))
            item.notes = str(row.get('notes', '') or '')
            item.scene_name = str(row.get('scene_name', '') or '')
            item.camera_name = str(row.get('camera_name', '') or '')
            item.view_layer_name = str(row.get('view_layer_name', '') or '')
            item.frame_start = int(row.get('frame_start', 1) or 1)
            item.frame_end = int(row.get('frame_end', 250) or 250)
            item.frame_current = int(row.get('frame_current', 1) or 1)
            item.resolution_x = int(row.get('resolution_x', 0) or 0)
            item.resolution_y = int(row.get('resolution_y', 0) or 0)
            item.resolution_percentage = int(row.get('resolution_percentage', 100) or 100)
            item.output_path = str(row.get('output_path', '') or '')
            item.file_format = str(row.get('file_format', '') or '')
            item.capture_mode = str(row.get('capture_mode', 'FULL') or 'FULL')
            item.updated_at = str(row.get('updated_at', '') or '')
            try:
                item.payload_json = json.dumps(dict(row.get('payload') or {}), ensure_ascii=False)
            except Exception:
                item.payload_json = ''
            created += 1
        try:
            wm.sf_shot_active_index = max(0, min(int(data.get('active_index', 0) or 0), max(0, len(wm.sf_shot_slots) - 1)))
        except Exception:
            wm.sf_shot_active_index = 0
        try:
            _sf_append_activity(context, _t('Imported shot queue'), os.path.basename(filepath), 'IMPORT')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Imported')}: {created}")
        return {'FINISHED'}


class SF_OT_shot_queue_preflight(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_preflight'
    bl_label = 'Preflight'
    bl_description = 'Scan the selected queue scope for missing scenes, missing cameras, duplicate outputs, and optional external dependency problems before running the batch. Use this as the safe review step before still or animation renders.'
    bl_options = set()
    _sms_no_undo = True

    queue_scope: EnumProperty(name='Scope', items=_SF_SHOT_QUEUE_SCOPE_ITEMS, default='ENABLED')
    dependency_policy: EnumProperty(name='Dependency Policy', items=_SF_SHOT_DEPENDENCY_POLICY_ITEMS, default='WARN')
    open_report: BoolProperty(name='Open report', default=True, description='Open the generated preflight report inside Blender so you can jump straight into fixes.')

    def execute(self, context):
        include_dependencies = str(self.dependency_policy or 'WARN').upper() != 'OFF'
        payload = _sf_sq_preflight_payload(context, queue_scope=self.queue_scope, include_dependencies=include_dependencies)
        title = _t('Shot Queue Preflight')
        text_name = _sf_report_export(
            context,
            title,
            _sf_sq_preflight_report_lines(context, title, payload),
            open_text=bool(self.open_report),
            activity_title=_t('Ran shot queue preflight'),
        )
        issue_count = int(payload.get('blocking_issue_count', 0) or 0)
        self.report({'WARNING'} if issue_count else {'INFO'}, f"{_t('Issues found')}: {issue_count} | {_t('Report')}: {text_name}")
        return {'FINISHED'}


class SF_OT_shot_queue_run_queue(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_run_queue'
    bl_label = 'Run Queue'
    bl_description = 'Run the stored shots as an apply-only pass, a still-image batch, or an animation batch. The operator now performs a preflight scan for missing scenes, missing cameras, duplicate outputs, and optional external dependency issues before rendering, then restores every touched scene afterward.'
    bl_options = set()
    _sms_no_undo = True

    queue_scope: EnumProperty(name='Scope', items=_SF_SHOT_QUEUE_SCOPE_ITEMS, default='ENABLED')
    run_mode: EnumProperty(name='Run Mode', items=_SF_SHOT_RUN_MODE_ITEMS, default='APPLY')
    dependency_policy: EnumProperty(name='Dependency Policy', items=_SF_SHOT_DEPENDENCY_POLICY_ITEMS, default='WARN')
    abort_on_duplicate_output: BoolProperty(
        name='Abort on duplicate outputs',
        default=True,
        description='Treat duplicate resolved output paths as blocking problems. Keep this on for real rendering so two shots do not overwrite the same files by accident.',
    )
    restore_after: BoolProperty(name='Restore original state', default=True, description='Restore the scene to its original state after the queue finishes.')
    open_report: BoolProperty(name='Open report', default=True, description='Open a text report inside Blender after the queue run.')

    def execute(self, context):
        dependency_policy = str(self.dependency_policy or 'WARN').upper()
        include_dependencies = dependency_policy != 'OFF'
        preflight = _sf_sq_preflight_payload(context, queue_scope=self.queue_scope, include_dependencies=include_dependencies)
        items = list(preflight.get('items') or [])
        if not items:
            self.report({'WARNING'}, _t('No shots matched the current queue scope'))
            return {'CANCELLED'}

        blocking_issue_count = len(preflight.get('missing_scenes') or []) + len(preflight.get('missing_cameras') or [])
        if bool(self.abort_on_duplicate_output):
            blocking_issue_count += len(preflight.get('duplicate_outputs') or [])
        if dependency_policy == 'BLOCK':
            blocking_issue_count += int(dict(preflight.get('dependency_summary') or {}).get('missing_records', 0) or 0)
        preflight['blocking_issue_count'] = int(blocking_issue_count or 0)

        if dependency_policy == 'BLOCK' and int(blocking_issue_count or 0) > 0:
            title = _t('Shot Queue Preflight')
            text_name = _sf_report_export(
                context,
                title,
                _sf_sq_preflight_report_lines(context, title, preflight),
                open_text=bool(self.open_report),
                activity_title=_t('Blocked shot queue'),
            )
            self.report({'ERROR'}, f"{_t('Queue blocked by preflight')}: {int(blocking_issue_count or 0)} | {_t('Report')}: {text_name}")
            return {'CANCELLED'}

        original_scene_name = str(getattr(getattr(context, 'scene', None), 'name', '') or '')
        restore_payloads = {}
        if original_scene_name:
            payload = _sf_sq_capture_scene_restore_payload(context, original_scene_name, include_collections=True)
            if payload:
                restore_payloads[original_scene_name] = payload
        for item in items:
            scene_name = _sf_sq_requested_scene_name(item)
            if not scene_name or scene_name in restore_payloads:
                continue
            payload = _sf_sq_capture_scene_restore_payload(context, scene_name, include_collections=False)
            if payload:
                restore_payloads[scene_name] = payload

        rows = []
        processed = 0
        for item in items:
            name = str(getattr(item, 'name', '') or _t('Shot'))
            try:
                result = _sf_sq_apply_item(context, item)
                if bool(result.get('aborted')):
                    status = _t('Skipped')
                    detail = str(result.get('reason', '') or _t('Failed'))
                    rows.append({'shot': name, 'status': status, 'detail': detail})
                    continue
                active_scene = getattr(context, 'scene', None)
                active_render = getattr(active_scene, 'render', None) if active_scene is not None else None
                output_path = str(getattr(item, 'output_path', '') or '')
                if output_path:
                    output_path = _sf_sq_expand_tokens(context, output_path, item)
                else:
                    output_path = _sf_sq_default_output_path(context, item)
                if active_render is not None:
                    active_render.filepath = output_path
                try:
                    _sf_sq_ensure_output_parent(output_path)
                except Exception:
                    pass
                if self.run_mode == 'STILL':
                    if active_scene is not None:
                        try:
                            active_scene.frame_set(int(getattr(item, 'frame_current', getattr(item, 'frame_start', 1)) or 1))
                        except Exception:
                            pass
                    bpy.ops.render.render(write_still=True)
                    status = _t('Rendered still')
                    detail = os.path.basename(output_path or '')
                elif self.run_mode == 'ANIMATION':
                    if active_scene is not None:
                        active_scene.frame_start = int(getattr(item, 'frame_start', getattr(active_scene, 'frame_start', 1)) or 1)
                        active_scene.frame_end = int(getattr(item, 'frame_end', getattr(active_scene, 'frame_end', 250)) or 250)
                        try:
                            active_scene.frame_set(int(getattr(item, 'frame_start', getattr(active_scene, 'frame_start', 1)) or 1))
                        except Exception:
                            pass
                    bpy.ops.render.render(animation=True)
                    status = _t('Rendered animation')
                    detail = f"{int(getattr(item, 'frame_start', 1) or 1)}-{int(getattr(item, 'frame_end', 1) or 1)}"
                else:
                    status = _t('Applied')
                    detail = f"{int(result.get('restored', 0) or 0)} / {int(result.get('missing', 0) or 0)} / {int(result.get('failed', 0) or 0)}"
                rows.append({'shot': name, 'status': status, 'detail': detail})
                processed += 1
            except Exception as ex:
                rows.append({'shot': name, 'status': _t('Failed'), 'detail': str(ex)})

        if self.restore_after and restore_payloads:
            try:
                _sf_sq_restore_scene_payloads(context, restore_payloads, original_scene_name=original_scene_name)
            except Exception:
                pass

        text_name = _sf_report_export(
            context,
            _t('Shot Queue Report'),
            _sf_sq_report_lines(context, _t('Shot Queue Report'), rows, run_mode=self.run_mode, queue_scope=self.queue_scope, preflight=preflight),
            open_text=bool(self.open_report),
            activity_title=_t('Ran shot queue'),
        )
        if int(blocking_issue_count or 0) > 0 and dependency_policy == 'WARN':
            self.report({'WARNING'}, f"{_t('Processed')}: {processed} | {_t('Issues found')}: {int(blocking_issue_count or 0)} | {_t('Report')}: {text_name}")
        else:
            self.report({'WARNING'} if processed < len(items) else {'INFO'}, f"{_t('Processed')}: {processed} | {_t('Report')}: {text_name}")
        return {'FINISHED'}

class SF_OT_shot_queue_open(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_queue_open'
    bl_label = 'Open'
    bl_description = 'Open a compact shot board for saving scene states per shot, capturing camera markers, exporting'
    # The dialog itself is UI-only.  Its child commands own file/scene changes
    # and their explicit Undo or external-I/O semantics.
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def invoke(self, context, event):
        del event
        try:
            _sf_append_activity(context, _t('Opened Shot Queue Toolkit'), '', 'CAMERA_DATA')
        except Exception:
            pass
        try:
            return context.window_manager.invoke_props_dialog(self, width=860)
        except Exception:
            return {'CANCELLED'}

    def execute(self, context):
        del context
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        wm = getattr(context, 'window_manager', None)
        summary = _sf_sq_summary(context)
        shot = _sf_sq_active_item(context)
        layout.use_property_split = False
        layout.use_property_decorate = False

        _sf_draw_dialog_header(
            layout,
            'Shot Queue Toolkit',
            'Save, recall, exchange, preflight, and batch-run per-shot camera and render state without duplicating whole scenes or collections.',
            'CAMERA_DATA',
        )

        summary_box = layout.box()
        _sf_draw_section_intro(
            summary_box,
            'Queue Summary',
            'Use this snapshot first. It shows how many shots are stored, how many are enabled for the next run, and whether any saved scene, camera, or output targets need attention before batch rendering.',
            'NONE',
        )
        _sf_draw_state_line(summary_box, 'Shots', 'READY' if int(summary.get('total', 0) or 0) else 'NOT SET', detail=str(int(summary.get('total', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Enabled', 'READY' if int(summary.get('enabled', 0) or 0) else 'NOT SET', detail=str(int(summary.get('enabled', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Stored Payloads', 'READY' if int(summary.get('with_payload', 0) or 0) else 'NOT SET', detail=str(int(summary.get('with_payload', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Output Paths', 'READY' if int(summary.get('ready_output', 0) or 0) else 'NOT SET', detail=str(int(summary.get('ready_output', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Missing Scenes', 'READY' if int(summary.get('missing_scene', 0) or 0) == 0 else 'ATTENTION NEEDED', detail=str(int(summary.get('missing_scene', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Missing Cameras', 'READY' if int(summary.get('missing_camera', 0) or 0) == 0 else 'ATTENTION NEEDED', detail=str(int(summary.get('missing_camera', 0) or 0)))
        _sf_draw_state_line(summary_box, 'Duplicate Outputs', 'READY' if int(summary.get('duplicate_output', 0) or 0) == 0 else 'ATTENTION NEEDED', detail=str(int(summary.get('duplicate_output', 0) or 0)))

        split = layout.split(factor=0.48)
        left = split.column(align=True)
        right = split.column(align=True)

        list_box = left.box()
        _sf_draw_section_intro(
            list_box,
            'Stored Shots',
            'The queue runs in this order. Enable or disable rows to control which shots participate in the next batch.',
            'LINENUMBERS_ON',
        )
        row = list_box.row()
        row.template_list('SF_UL_shot_queue_shot_queue_slot_list', '', wm, 'sf_shot_slots', wm, 'sf_shot_active_index', rows=7)

        ops = row.column(align=True)
        add_new = ops.operator('import_scene.sfs_shot_queue_store_current', text='', icon='ADD', emboss=True)
        add_new.append_new = True
        add_new.capture_mode = 'FULL'
        ops.operator('import_scene.sfs_shot_queue_apply_active', text='', icon='PLAY', emboss=True)
        ops.operator('import_scene.sfs_shot_queue_remove_active', text='', icon='REMOVE', emboss=True)
        up = ops.operator('import_scene.sfs_shot_queue_move_active', text='', icon='TRIA_UP', emboss=True)
        up.direction = 'UP'
        down = ops.operator('import_scene.sfs_shot_queue_move_active', text='', icon='TRIA_DOWN', emboss=True)
        down.direction = 'DOWN'

        tool_row = list_box.row(align=True)
        save_active = tool_row.operator('import_scene.sfs_shot_queue_store_current', text='Store Current', icon='FILE_TICK')
        save_active.append_new = False
        save_active.capture_mode = 'FULL'
        capture_markers = tool_row.operator('import_scene.sfs_shot_queue_capture_from_camera_markers', text='Capture From Camera Markers', icon='MARKER')
        capture_markers.clear_existing = False
        capture_cameras = tool_row.operator('import_scene.sfs_shot_queue_capture_from_cameras', text='Capture From Cameras', icon='CAMERA_DATA')
        capture_cameras.clear_existing = False

        queue_box = left.box()
        _sf_draw_section_intro(
            queue_box,
            'Queue Actions',
            'Run a preflight check first when you want to catch missing scenes, missing cameras, duplicate outputs, and dependency problems before the batch starts. Rendering modes restore the original state afterward.',
            'RENDER_STILL',
        )
        row = queue_box.row(align=True)
        preflight = row.operator('import_scene.sfs_shot_queue_preflight', text='Preflight', icon='CHECKMARK')
        preflight.queue_scope = 'ENABLED'
        preflight.dependency_policy = 'WARN'
        dry = row.operator('import_scene.sfs_shot_queue_run_queue', text='Run Queue', icon='PLAY')
        dry.run_mode = 'APPLY'
        dry.queue_scope = 'ENABLED'
        dry.dependency_policy = 'WARN'
        dry.abort_on_duplicate_output = False
        still = row.operator('import_scene.sfs_shot_queue_run_queue', text='Run Queue', icon='RENDER_STILL')
        still.run_mode = 'STILL'
        still.queue_scope = 'ENABLED'
        still.dependency_policy = 'BLOCK'
        still.abort_on_duplicate_output = True
        anim = row.operator('import_scene.sfs_shot_queue_run_queue', text='Run Queue', icon='RENDER_ANIMATION')
        anim.run_mode = 'ANIMATION'
        anim.queue_scope = 'ENABLED'
        anim.dependency_policy = 'BLOCK'
        anim.abort_on_duplicate_output = True

        row = queue_box.row(align=True)
        row.operator('export_scene.sfs_shot_queue_export_queue', text='Export Queue', icon='EXPORT')
        row.operator('import_scene.sfs_shot_queue_import_queue', text='Import Queue', icon='IMPORT')
        row.operator('export_scene.sfs_pipeline_shot_manifest', text='Shot Manifest', icon='FILE_TEXT')

        detail_box = right.box()
        _sf_draw_section_intro(
            detail_box,
            'Active Shot',
            'Edit the selected shot here. Tokens like {shot}, {camera}, {scene}, {blend}, {blend_dir}, and {view_layer} can be used in the output path.',
            'PROPERTIES',
        )
        if shot is None:
            detail_box.label(text=_t('No active shot'))
        else:
            col = detail_box.column(align=True)
            col.prop(shot, 'enabled')
            col.prop(shot, 'name')
            col.prop(shot, 'notes')
            col.prop(shot, 'capture_mode')
            col.separator()
            col.prop(shot, 'scene_name')
            col.prop(shot, 'camera_name')
            col.prop(shot, 'view_layer_name')
            frame_row = col.row(align=True)
            frame_row.prop(shot, 'frame_start')
            frame_row.prop(shot, 'frame_end')
            frame_row.prop(shot, 'frame_current')
            res_row = col.row(align=True)
            res_row.prop(shot, 'resolution_x')
            res_row.prop(shot, 'resolution_y')
            res_row.prop(shot, 'resolution_percentage')
            col.prop(shot, 'file_format')
            col.prop(shot, 'output_path')
            state = col.box()
            requested_scene = _sf_sq_requested_scene_name(shot)
            scene_ok = (not requested_scene) or (bpy.data.scenes.get(requested_scene) is not None)
            _sf_draw_state_line(state, 'Payload', 'READY' if str(getattr(shot, 'payload_json', '') or '').strip() else 'NOT SET', detail=str(getattr(shot, 'updated_at', '') or ''))
            _sf_draw_state_line(state, 'Scene Exists', 'READY' if scene_ok else 'ATTENTION NEEDED', detail=requested_scene or _t('Current'))
            _sf_draw_state_line(state, 'Camera Exists', 'READY' if (not str(getattr(shot, 'camera_name', '') or '') or bpy.data.objects.get(str(getattr(shot, 'camera_name', '') or '')) is not None) else 'ATTENTION NEEDED', detail=str(getattr(shot, 'camera_name', '') or _t('No Camera')))
            resolved = _sf_sq_expand_tokens(context, str(getattr(shot, 'output_path', '') or ''), shot) if str(getattr(shot, 'output_path', '') or '').strip() else ''
            _sf_draw_state_line(state, 'Resolved Output', 'READY' if resolved else 'NOT SET', detail=_sf_short_path_display(resolved, 54) if resolved else '')

        support = right.box()
        _sf_draw_section_intro(
            support,
            'Related Tools',
            'Use these when a shot also needs reference relink, lightweight display, dependency review, or recovery snapshots beyond the per-shot queue itself.',
            'TOOL_SETTINGS',
        )
        _sf_draw_action_block(
            support,
            primary_actions=[
                ('import_scene.sfs_project_guard_open', 'Project Guard', 'LOCKVIEW_ON', {}),
                ('import_scene.sfs_reference_manager_open', 'Relink', 'LINKED', {}),
                ('import_scene.sfs_dependency_cockpit_open', 'Dependencies', 'NONE', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_assembly_guard_open', 'Assembly Guard', 'RESTRICT_SELECT_OFF', {}),
                ('import_scene.sfs_shot_state_open', 'Shot States', 'CAMERA_DATA', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
                ('export_scene.sfs_publisher_publish_asset', 'Publish', 'EXPORT', {}),
            ],
        )
