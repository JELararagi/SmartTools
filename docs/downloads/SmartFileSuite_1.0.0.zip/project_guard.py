
# -----------------------------------------------------------------------------
#  Project Guard / Scene State / Cooperative Lock Toolkit
# -----------------------------------------------------------------------------

import getpass
import hashlib
import json
import os
import shutil
import socket


_SF_GUARD_LOCK_SCOPE_ITEMS = [
    ('CURRENT_FILE', 'Current File', 'Target only the current .blend file. Use this when you want a simple check-out style marker for the main scene you are editing right now.'),
    ('LINKED_LIBRARIES', 'Linked Libraries', 'Target every linked external .blend library referenced by the current scene. Use this before a larger relink or publish session so other artists can see which references are in active use.'),
    ('CURRENT_AND_LINKED', 'Current + Linked', 'Target both the current .blend file and all linked external libraries together. This gives a broader project-level lock pass similar to a lightweight check-in'),
]


def _sf_guard_now_text() -> str:
    try:
        return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return ''


def _sf_guard_owner_text() -> str:
    parts = []
    try:
        user = str(getpass.getuser() or '').strip()
    except Exception:
        user = ''
    try:
        host = str(socket.gethostname() or '').strip()
    except Exception:
        host = ''
    if user:
        parts.append(user)
    if host:
        parts.append(host)
    return '@'.join(parts) if parts else 'unknown'


def _sf_guard_lock_hash(target_path: str) -> str:
    norm = _norm_path(target_path or '')
    if not norm:
        return 'unknown'
    try:
        return hashlib.sha1(norm.encode('utf-8', 'ignore')).hexdigest()[:12]
    except Exception:
        return 'unknown'


def _sf_guard_lock_dir_for_target(target_path: str) -> str:
    norm = _norm_path(target_path or '')
    folder = ''
    try:
        if norm and os.path.isdir(norm):
            folder = norm
        else:
            folder = os.path.dirname(norm)
    except Exception:
        folder = ''
    folder = _norm_path(folder or '')
    if not folder:
        try:
            folder = _sf_user_default_dir('locks')
        except Exception:
            folder = ''
    if not folder:
        return ''
    return os.path.join(folder, '.smart_file_suite', 'locks')


def _sf_guard_lock_path_for_target(target_path: str) -> str:
    norm = _norm_path(target_path or '')
    if not norm:
        return ''
    base = os.path.basename(norm.rstrip('/\\')) or 'target'
    token = _sf_guard_lock_hash(norm)
    safe = _safe_filename(os.path.splitext(base)[0] or base) or 'target'
    lock_dir = _sf_guard_lock_dir_for_target(norm)
    if not lock_dir:
        return ''
    return os.path.join(lock_dir, f'{safe}__{token}.sfslock.json')


def _sf_guard_read_json(filepath: str) -> dict:
    path = _norm_path(filepath or '')
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _sf_guard_write_json(filepath: str, data: dict):
    path = _norm_path(filepath or '')
    if not path:
        raise ValueError('missing filepath')
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    shutil.move(tmp, path)


def _sf_guard_current_file_path() -> str:
    try:
        return _norm_path(bpy.data.filepath or '')
    except Exception:
        return ''


def _sf_guard_linked_library_paths() -> list[str]:
    out = []
    seen = set()
    for lib in getattr(bpy.data, 'libraries', []) or []:
        raw = ''
        try:
            raw = str(getattr(lib, 'filepath', '') or '')
        except Exception:
            raw = ''
        try:
            path = _norm_path(bpy.path.abspath(raw, library=getattr(lib, 'parent', None)) or raw)
        except Exception:
            path = _norm_path(raw)
        if not path or path in seen:
            continue
        seen.add(path)
        out.append(path)
    return out


def _sf_guard_targets(scope: str = 'CURRENT_FILE') -> list[str]:
    scope = str(scope or 'CURRENT_FILE').upper()
    out = []
    seen = set()

    def add(path: str):
        norm = _norm_path(path or '')
        if not norm or norm in seen:
            return
        seen.add(norm)
        out.append(norm)

    if scope in {'CURRENT_FILE', 'CURRENT_AND_LINKED'}:
        add(_sf_guard_current_file_path())
    if scope in {'LINKED_LIBRARIES', 'CURRENT_AND_LINKED'}:
        for path in _sf_guard_linked_library_paths():
            add(path)
    return out


def _sf_guard_build_lock_payload(target_path: str, *, note: str = '') -> dict:
    return {
        'tool': 'Smart File',
        'kind': 'cooperative_reference_lock',
        'version': _sf_pipe_version_text(),
        'created_at': _sf_guard_now_text(),
        'updated_at': _sf_guard_now_text(),
        'timestamp_unix': int(time.time()),
        'target_path': _norm_path(target_path or ''),
        'owner_blend': _sf_guard_current_file_path(),
        'owner': _sf_guard_owner_text(),
        'pid': int(os.getpid()),
        'note': str(note or '').strip(),
    }


def _sf_guard_is_stale_lock(data: dict) -> bool:
    payload = dict(data or {})
    ts = 0
    try:
        ts = int(payload.get('timestamp_unix', 0) or 0)
    except Exception:
        ts = 0
    age = max(0, int(time.time()) - ts) if ts else 0
    owner_blend = _norm_path(payload.get('owner_blend', '') or '')
    if age and age > 7 * 24 * 3600:
        return True
    if owner_blend and (not os.path.exists(owner_blend)) and age > 12 * 3600:
        return True
    return False


def _sf_guard_lock_status_for_target(target_path: str) -> dict:
    target = _norm_path(target_path or '')
    lock_path = _sf_guard_lock_path_for_target(target)
    payload = _sf_guard_read_json(lock_path)
    exists = bool(lock_path and os.path.isfile(lock_path))
    owner_blend = _norm_path(payload.get('owner_blend', '') or '') if payload else ''
    same_owner = bool(owner_blend and owner_blend == _sf_guard_current_file_path())
    stale = _sf_guard_is_stale_lock(payload) if payload else False
    return {
        'target_path': target,
        'lock_path': lock_path,
        'locked': exists,
        'same_owner': same_owner,
        'stale': stale,
        'owner': str(payload.get('owner', '') or ''),
        'owner_blend': owner_blend,
        'updated_at': str(payload.get('updated_at', '') or ''),
        'note': str(payload.get('note', '') or ''),
    }


def _sf_guard_acquire_lock(target_path: str, *, note: str = '', force: bool = False) -> dict:
    target = _norm_path(target_path or '')
    lock_path = _sf_guard_lock_path_for_target(target)
    if not target or not lock_path:
        return {'ok': False, 'reason': 'invalid_target', 'target_path': target, 'lock_path': lock_path}
    existing = _sf_guard_read_json(lock_path)
    exists = bool(lock_path and os.path.isfile(lock_path))
    same_owner = bool(existing and _norm_path(existing.get('owner_blend', '') or '') == _sf_guard_current_file_path())
    stale = _sf_guard_is_stale_lock(existing) if existing else False
    if exists and (not same_owner) and (not stale) and (not force):
        return {
            'ok': False,
            'reason': 'conflict',
            'target_path': target,
            'lock_path': lock_path,
            'owner': str(existing.get('owner', '') or ''),
            'owner_blend': _norm_path(existing.get('owner_blend', '') or ''),
            'updated_at': str(existing.get('updated_at', '') or ''),
        }
    payload = _sf_guard_build_lock_payload(target, note=note)
    if existing and same_owner:
        payload['created_at'] = str(existing.get('created_at', '') or payload['created_at'])
    _sf_guard_write_json(lock_path, payload)
    return {
        'ok': True,
        'reason': 'refreshed' if same_owner else ('reclaimed_stale' if stale else 'created'),
        'target_path': target,
        'lock_path': lock_path,
    }


def _sf_guard_release_lock(target_path: str, *, force: bool = False) -> dict:
    target = _norm_path(target_path or '')
    lock_path = _sf_guard_lock_path_for_target(target)
    if not target or not lock_path:
        return {'ok': False, 'reason': 'invalid_target', 'target_path': target, 'lock_path': lock_path}
    existing = _sf_guard_read_json(lock_path)
    if not os.path.isfile(lock_path):
        return {'ok': False, 'reason': 'missing', 'target_path': target, 'lock_path': lock_path}
    same_owner = bool(existing and _norm_path(existing.get('owner_blend', '') or '') == _sf_guard_current_file_path())
    stale = _sf_guard_is_stale_lock(existing) if existing else False
    if (not same_owner) and (not force) and (not stale):
        return {
            'ok': False,
            'reason': 'conflict',
            'target_path': target,
            'lock_path': lock_path,
            'owner': str(existing.get('owner', '') or ''),
            'owner_blend': _norm_path(existing.get('owner_blend', '') or ''),
            'updated_at': str(existing.get('updated_at', '') or ''),
        }
    try:
        os.remove(lock_path)
    except Exception as ex:
        return {'ok': False, 'reason': str(ex), 'target_path': target, 'lock_path': lock_path}
    return {'ok': True, 'reason': 'released', 'target_path': target, 'lock_path': lock_path}


def _sf_guard_cleanup_stale_locks(scope: str = 'CURRENT_AND_LINKED') -> dict:
    targets = _sf_guard_targets(scope)
    removed = []
    skipped = []
    failed = []
    for path in targets:
        status = _sf_guard_lock_status_for_target(path)
        if not status.get('locked'):
            skipped.append({'target_path': path, 'reason': 'missing'})
            continue
        if not status.get('stale'):
            skipped.append({'target_path': path, 'reason': 'active'})
            continue
        lock_path = _norm_path(status.get('lock_path', '') or '')
        if not lock_path or not os.path.isfile(lock_path):
            skipped.append({'target_path': path, 'reason': 'missing'})
            continue
        try:
            os.remove(lock_path)
            removed.append({'target_path': path, 'lock_path': lock_path})
        except Exception as ex:
            failed.append({'target_path': path, 'lock_path': lock_path, 'reason': str(ex)})
    return {
        'targets': targets,
        'removed': removed,
        'skipped': skipped,
        'failed': failed,
    }


def _sf_guard_refresh_locks(scope: str = 'CURRENT_AND_LINKED', *, note: str = '', create_missing: bool = True) -> dict:
    targets = _sf_guard_targets(scope)
    refreshed = []
    created = []
    conflicts = []
    skipped = []
    failed = []
    for path in targets:
        status = _sf_guard_lock_status_for_target(path)
        if status.get('locked') and (not status.get('same_owner')) and (not status.get('stale')):
            conflicts.append({'target_path': path, 'owner': status.get('owner', ''), 'owner_blend': status.get('owner_blend', ''), 'updated_at': status.get('updated_at', '')})
            continue
        if (not status.get('locked')) and (not create_missing):
            skipped.append({'target_path': path, 'reason': 'missing'})
            continue
        result = _sf_guard_acquire_lock(path, note=note, force=False)
        if not result.get('ok'):
            reason = str(result.get('reason', '') or '')
            if reason == 'conflict':
                conflicts.append(result)
            else:
                failed.append(result)
            continue
        reason = str(result.get('reason', '') or '')
        row = {'target_path': path, 'lock_path': result.get('lock_path', ''), 'reason': reason}
        if reason == 'refreshed':
            refreshed.append(row)
        elif reason == 'created':
            created.append(row)
        elif reason == 'reclaimed_stale':
            created.append(row)
        else:
            refreshed.append(row)
    return {
        'targets': targets,
        'refreshed': refreshed,
        'created': created,
        'conflicts': conflicts,
        'skipped': skipped,
        'failed': failed,
    }



def _sf_guard_render_settings_snapshot(scene) -> dict:
    render = getattr(scene, 'render', None)
    fps_val = 0.0
    try:
        fps = float(getattr(render, 'fps', 0) or 0)
        fps_base = float(getattr(render, 'fps_base', 1.0) or 1.0)
        fps_val = round(fps / fps_base, 4) if fps_base else fps
    except Exception:
        fps_val = 0.0
    return {
        'engine': str(getattr(render, 'engine', '') or ''),
        'resolution_x': int(getattr(render, 'resolution_x', 0) or 0),
        'resolution_y': int(getattr(render, 'resolution_y', 0) or 0),
        'resolution_percentage': int(getattr(render, 'resolution_percentage', 100) or 100),
        'fps': fps_val,
        'fps_raw': int(getattr(render, 'fps', 0) or 0),
        'fps_base': float(getattr(render, 'fps_base', 1.0) or 1.0),
        'output_path': str(getattr(render, 'filepath', '') or ''),
        'file_format': str(getattr(getattr(render, 'image_settings', None), 'file_format', '') or ''),
    }


def _sf_guard_capture_scene_state(context, *, include_objects: bool = True, include_collections: bool = True) -> dict:
    scene = getattr(context, 'scene', None)
    if scene is None:
        return {}
    payload = {
        'tool': 'Smart File',
        'kind': 'scene_state_snapshot',
        'version': _sf_pipe_version_text(),
        'created_at': _sf_guard_now_text(),
        'timestamp_unix': int(time.time()),
        'file': _sf_guard_current_file_path(),
        'scene': {
            'name': str(getattr(scene, 'name', '') or ''),
            'camera': str(getattr(getattr(scene, 'camera', None), 'name', '') or ''),
            'world': str(getattr(getattr(scene, 'world', None), 'name', '') or ''),
            'frame_start': int(getattr(scene, 'frame_start', 1) or 1),
            'frame_end': int(getattr(scene, 'frame_end', 250) or 250),
            'frame_current': int(getattr(scene, 'frame_current', 1) or 1),
            'use_preview_range': bool(getattr(scene, 'use_preview_range', False)),
            'frame_preview_start': int(getattr(scene, 'frame_preview_start', getattr(scene, 'frame_start', 1)) or getattr(scene, 'frame_start', 1) or 1),
            'frame_preview_end': int(getattr(scene, 'frame_preview_end', getattr(scene, 'frame_end', 250)) or getattr(scene, 'frame_end', 250) or 250),
        },
        'render': _sf_guard_render_settings_snapshot(scene),
        'markers': [
            {
                'name': str(getattr(marker, 'name', '') or ''),
                'frame': int(getattr(marker, 'frame', 0) or 0),
                'camera': str(getattr(getattr(marker, 'camera', None), 'name', '') or ''),
            }
            for marker in getattr(scene, 'timeline_markers', []) or []
        ],
        'object_states': [],
        'collection_states': [],
    }
    if include_objects:
        for ob in getattr(scene, 'objects', []) or []:
            entry = {'name': str(getattr(ob, 'name', '') or '')}
            if not entry['name']:
                continue
            for attr in ('hide_viewport', 'hide_render', 'display_type'):
                try:
                    entry[attr] = getattr(ob, attr)
                except Exception:
                    pass
            payload['object_states'].append(entry)
    if include_collections:
        for coll in getattr(bpy.data, 'collections', []) or []:
            entry = {'name': str(getattr(coll, 'name', '') or '')}
            if not entry['name']:
                continue
            for attr in ('hide_viewport', 'hide_render'):
                try:
                    entry[attr] = getattr(coll, attr)
                except Exception:
                    pass
            payload['collection_states'].append(entry)
    return payload


def _sf_guard_store_scene_state(context, *, include_objects: bool = True, include_collections: bool = True) -> dict:
    payload = _sf_guard_capture_scene_state(context, include_objects=include_objects, include_collections=include_collections)
    wm = getattr(context, 'window_manager', None)
    if wm is not None:
        try:
            wm.sf_project_guard_scene_state_json = json.dumps(payload, ensure_ascii=False)
        except Exception:
            pass
    return payload


def _sf_guard_restore_scene_state_from_payload(context, payload: dict, *, apply_markers: bool = True, replace_markers: bool = False) -> dict:
    scene = getattr(context, 'scene', None)
    if scene is None:
        return {'restored': 0, 'missing': 0, 'failed': 1, 'objects': 0, 'collections': 0, 'scene_switched': False}
    data = dict(payload or {})
    scene_info = dict(data.get('scene') or {})
    render_info = dict(data.get('render') or {})
    restored = 0
    missing = 0
    failed = 0
    scene_switched = False

    def apply_attr(obj, attr, value):
        nonlocal restored, failed
        try:
            setattr(obj, attr, value)
            restored += 1
        except Exception:
            failed += 1

    requested_scene_name = str(scene_info.get('name', '') or '').strip()
    if requested_scene_name:
        target_scene = bpy.data.scenes.get(requested_scene_name)
        if target_scene is None:
            missing += 1
        else:
            window = getattr(context, 'window', None)
            if window is not None:
                try:
                    if window.scene is not target_scene:
                        window.scene = target_scene
                        scene_switched = True
                except Exception:
                    failed += 1
            scene = getattr(context, 'scene', None) or target_scene

    if scene_info:
        try:
            cam_name = str(scene_info.get('camera', '') or '')
            if cam_name:
                cam = bpy.data.objects.get(cam_name)
                if cam is not None:
                    apply_attr(scene, 'camera', cam)
                else:
                    missing += 1
        except Exception:
            failed += 1
        try:
            world_name = str(scene_info.get('world', '') or '')
            if world_name:
                world = bpy.data.worlds.get(world_name)
                if world is not None:
                    apply_attr(scene, 'world', world)
                else:
                    missing += 1
        except Exception:
            failed += 1
        for attr in ('frame_start', 'frame_end', 'frame_current', 'frame_preview_start', 'frame_preview_end'):
            if attr in scene_info:
                apply_attr(scene, attr, int(scene_info.get(attr, getattr(scene, attr, 0)) or 0))
        if 'use_preview_range' in scene_info:
            apply_attr(scene, 'use_preview_range', bool(scene_info.get('use_preview_range')))

    render = getattr(scene, 'render', None)
    if render is not None and render_info:
        mapping = {
            'engine': ('engine', str),
            'resolution_x': ('resolution_x', int),
            'resolution_y': ('resolution_y', int),
            'resolution_percentage': ('resolution_percentage', int),
            'output_path': ('filepath', str),
        }
        for key, (attr, caster) in mapping.items():
            if key in render_info:
                try:
                    apply_attr(render, attr, caster(render_info.get(key)))
                except Exception:
                    failed += 1
        try:
            image_settings = getattr(render, 'image_settings', None)
            if image_settings is not None and 'file_format' in render_info:
                apply_attr(image_settings, 'file_format', str(render_info.get('file_format') or ''))
        except Exception:
            failed += 1
        try:
            if 'fps_raw' in render_info or 'fps' in render_info:
                raw_fps = int(render_info.get('fps_raw', 0) or 0)
                fps_base = float(render_info.get('fps_base', 1.0) or 1.0)
                if raw_fps > 0:
                    apply_attr(render, 'fps', raw_fps)
                    apply_attr(render, 'fps_base', fps_base if fps_base > 0 else 1.0)
                else:
                    fps_value = float(render_info.get('fps', 0.0) or 0.0)
                    if fps_value > 0:
                        rounded = max(1, int(round(fps_value)))
                        apply_attr(render, 'fps', rounded)
                        base = rounded / fps_value if fps_value else 1.0
                        apply_attr(render, 'fps_base', base if base > 0 else 1.0)
        except Exception:
            failed += 1

    obj_restored = 0
    coll_restored = 0
    for entry in list(data.get('object_states', []) or []):
        name = str(entry.get('name', '') or '')
        if not name:
            continue
        ob = bpy.data.objects.get(name)
        if ob is None:
            missing += 1
            continue
        for attr in ('display_type', 'hide_viewport', 'hide_render'):
            if attr not in entry:
                continue
            try:
                setattr(ob, attr, entry.get(attr))
                if attr == 'hide_viewport':
                    try:
                        ob.hide_set(bool(entry.get(attr)))
                    except Exception:
                        pass
                restored += 1
            except Exception:
                failed += 1
        obj_restored += 1

    for entry in list(data.get('collection_states', []) or []):
        name = str(entry.get('name', '') or '')
        if not name:
            continue
        coll = bpy.data.collections.get(name)
        if coll is None:
            missing += 1
            continue
        for attr in ('hide_viewport', 'hide_render'):
            if attr not in entry:
                continue
            try:
                setattr(coll, attr, bool(entry.get(attr)))
                restored += 1
            except Exception:
                failed += 1
        coll_restored += 1

    markers_added = 0
    markers_updated = 0
    if apply_markers:
        marker_entries = list(data.get('markers', []) or [])
        if replace_markers:
            try:
                for marker in list(getattr(scene, 'timeline_markers', []) or []):
                    scene.timeline_markers.remove(marker)
            except Exception:
                failed += 1
        try:
            existing_by_name = {str(getattr(marker, 'name', '') or ''): marker for marker in getattr(scene, 'timeline_markers', []) or []}
        except Exception:
            existing_by_name = {}
        for entry in marker_entries:
            name = str(entry.get('name', '') or '')
            if not name:
                continue
            marker = existing_by_name.get(name)
            if marker is None:
                try:
                    marker = scene.timeline_markers.new(name=name, frame=int(entry.get('frame', 0) or 0))
                    markers_added += 1
                    restored += 1
                    existing_by_name[name] = marker
                except Exception:
                    failed += 1
                    continue
            else:
                try:
                    marker.frame = int(entry.get('frame', getattr(marker, 'frame', 0)) or getattr(marker, 'frame', 0) or 0)
                    markers_updated += 1
                    restored += 1
                except Exception:
                    failed += 1
            cam_name = str(entry.get('camera', '') or '')
            if cam_name:
                cam = bpy.data.objects.get(cam_name)
                if cam is None:
                    missing += 1
                else:
                    try:
                        marker.camera = cam
                        restored += 1
                    except Exception:
                        failed += 1

    return {
        'restored': restored,
        'missing': missing,
        'failed': failed,
        'objects': obj_restored,
        'collections': coll_restored,
        'markers_added': markers_added,
        'markers_updated': markers_updated,
        'scene_switched': scene_switched,
    }


def _sf_guard_restore_scene_state(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    raw = str(getattr(wm, 'sf_project_guard_scene_state_json', '') or '') if wm is not None else ''
    if not raw.strip():
        return {'restored': 0, 'missing': 0, 'failed': 0, 'objects': 0, 'collections': 0}
    try:
        payload = json.loads(raw)
    except Exception:
        return {'restored': 0, 'missing': 0, 'failed': 1, 'objects': 0, 'collections': 0}
    return _sf_guard_restore_scene_state_from_payload(context, payload)


def _sf_guard_snapshot_count(context) -> int:
    wm = getattr(context, 'window_manager', None)
    raw = str(getattr(wm, 'sf_project_guard_scene_state_json', '') or '') if wm is not None else ''
    if not raw.strip():
        return 0
    try:
        payload = json.loads(raw)
    except Exception:
        return 0
    return len(list(payload.get('object_states', []) or [])) + len(list(payload.get('collection_states', []) or [])) + len(list(payload.get('markers', []) or []))


def _sf_guard_health_payload(context) -> dict:
    current_file = _sf_guard_current_file_path()
    records = _sf_ext_collect_current_file_records(include_libraries=True, include_texts=False, include_missing=True)
    ext_summary = _sf_ext_summary(records)
    linked = _sf_pipe_linked_payload(context)
    lock_targets = _sf_guard_targets('CURRENT_AND_LINKED')
    lock_rows = [_sf_guard_lock_status_for_target(path) for path in lock_targets]
    conflicts = [row for row in lock_rows if row.get('locked') and (not row.get('same_owner')) and (not row.get('stale'))]
    stale = [row for row in lock_rows if row.get('stale')]
    scene = getattr(context, 'scene', None)
    marker_count = len(getattr(scene, 'timeline_markers', []) or []) if scene is not None else 0
    camera_count = len([ob for ob in getattr(bpy.data, 'objects', []) or [] if str(getattr(ob, 'type', '') or '') == 'CAMERA'])
    ready_relative = bool(current_file and int(ext_summary.get('missing_records', 0) or 0) == 0 and int(ext_summary.get('absolute_records', 0) or 0) == 0)
    return {
        'current_file': current_file,
        'current_file_saved': bool(current_file),
        'linked': linked,
        'external': ext_summary,
        'lock_rows': lock_rows,
        'lock_conflicts': conflicts,
        'stale_locks': stale,
        'lock_count': len([row for row in lock_rows if row.get('locked')]),
        'snapshot_entries': _sf_guard_snapshot_count(context),
        'camera_count': int(camera_count or 0),
        'marker_count': int(marker_count or 0),
        'relative_ready': ready_relative,
    }


def _sf_guard_report_lines(context, *, title: str = 'Project Guard Report') -> list[str]:
    payload = _sf_guard_health_payload(context)
    external = dict(payload.get('external') or {})
    linked = dict(payload.get('linked') or {})
    lines = [
        f"Smart File | {title} | {_sf_guard_now_text()}",
        '',
        f"- {_t('Current File')}: {payload.get('current_file') or _t('Unsaved current file')}",
        f"- {_t('Linked Libraries')}: {len(linked.get('libraries') or [])}",
        f"- {_t('Linked Scene Objects')}: {int(linked.get('linked_object_count', 0) or 0)}",
        f"- {_t('Override Scene Objects')}: {int(linked.get('override_object_count', 0) or 0)}",
        f"- {_t('Missing')}: {int(external.get('missing_records', 0) or 0)}",
        f"- {_t('Absolute')}: {int(external.get('absolute_records', 0) or 0)}",
        f"- {_t('Environment Variables')}: {int(external.get('env_records', 0) or 0)}",
        f"- {_t('Sequences')}: {int(external.get('sequence_records', 0) or 0)}",
        f"- {_t('Active Locks')}: {int(payload.get('lock_count', 0) or 0)}",
        f"- {_t('Lock Conflicts')}: {len(payload.get('lock_conflicts') or [])}",
        f"- {_t('Stale Locks')}: {len(payload.get('stale_locks') or [])}",
        f"- {_t('Scene Snapshot Entries')}: {int(payload.get('snapshot_entries', 0) or 0)}",
        f"- {_t('Cameras')}: {int(payload.get('camera_count', 0) or 0)}",
        f"- {_t('Markers')}: {int(payload.get('marker_count', 0) or 0)}",
        f"- {_t('Relative Ready')}: {'YES' if payload.get('relative_ready') else 'NO'}",
        '',
        'LOCK DETAILS',
    ]
    for row in list(payload.get('lock_rows') or [])[:24]:
        state = 'FREE'
        if row.get('locked'):
            state = 'STALE' if row.get('stale') else ('OWNED BY THIS FILE' if row.get('same_owner') else 'CONFLICT')
        lines.append(f"- [{state}] {row.get('target_path','')} | owner={row.get('owner','')} | updated={row.get('updated_at','')}")
    lines.extend(['', 'MISSING EXTERNAL REFERENCES'])
    miss_rows = [rec for rec in _sf_ext_collect_current_file_records(include_libraries=True, include_texts=False, include_missing=True) if (not rec.get('exists')) and (not rec.get('packed'))]
    if miss_rows:
        for rec in miss_rows[:40]:
            lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
    else:
        lines.append(f"- {_t('No missing external references were detected in the current scan.')}")
    return lines


def _sf_guard_handoff_payload(context, *, search_dir: str = '', include_current_file_dir: bool = True, include_library_roots: bool = True, include_context_roots: bool = True) -> dict:
    guard = _sf_guard_health_payload(context)
    external = dict(guard.get('external') or {})
    conflict = _sf_ext_conflict_payload(
        context,
        search_dir=search_dir,
        include_current_file_dir=include_current_file_dir,
        include_library_roots=include_library_roots,
        include_context_roots=include_context_roots,
        include_libraries=True,
        include_texts=False,
        only_missing=True,
    )
    env_payload = _sf_ctx_env_audit_payload(context)
    override_payload = _rm_override_health_payload(context, scope='ALL')
    env_summary = dict(env_payload.get('summary') or {})
    override_summary = dict(override_payload.get('summary') or {})
    blockers = []
    warnings = []
    if not guard.get('current_file_saved'):
        blockers.append(_t('Save the current .blend file before handoff, bundle, or path normalization work.'))
    if int(external.get('missing_records', 0) or 0) > 0:
        blockers.append(_t('Resolve missing external references before handoff.'))
    if len(guard.get('lock_conflicts') or []) > 0:
        blockers.append(_t('Review cooperative lock conflicts before handoff or publish work.'))
    if int(env_summary.get('missing_env', 0) or 0) > 0:
        blockers.append(_t('Define the missing environment variables used by Context Roots.'))
    if int(env_summary.get('missing_path', 0) or 0) > 0:
        blockers.append(_t('Fix missing folders behind environment-backed Context Roots.'))
    if int(override_summary.get('blockers', 0) or 0) > 0:
        blockers.append(_t('Repair broken Library Overrides before updating or handing off the scene.'))
    if len(conflict.get('ambiguous_targets') or []) > 0:
        warnings.append(_t('At least one missing reference has multiple relink candidates.'))
    if len(conflict.get('current_conflicts') or []) > 0:
        warnings.append(_t('The current file contains duplicate basenames that resolve to different paths.'))
    if len(conflict.get('root_library_conflicts') or []) > 0:
        warnings.append(_t('Configured roots contain duplicate .blend names that can make load or relink choices ambiguous.'))
    if int(external.get('absolute_records', 0) or 0) > 0:
        warnings.append(_t('Normalize absolute external paths before packaging or handoff when portability matters.'))
    if len(guard.get('stale_locks') or []) > 0:
        warnings.append(_t('Cleanup stale cooperative locks so the next artist sees a clean reservation state.'))
    if int(env_summary.get('direct', 0) or 0) > 0:
        warnings.append(_t('Some Context Roots still use direct paths instead of environment variables.'))
    if int(override_summary.get('warnings', 0) or 0) > 0:
        warnings.append(_t('Review override warnings before switching linked libraries or pushing a handoff.'))
    if int(guard.get('snapshot_entries', 0) or 0) <= 0:
        warnings.append(_t('Store a scene snapshot so temporary handoff edits are easier to roll back.'))

    score = 100
    score -= min(50, int(external.get('missing_records', 0) or 0) * 10)
    score -= min(15, int(external.get('absolute_records', 0) or 0) * 2)
    score -= min(20, len(guard.get('lock_conflicts') or []) * 5)
    score -= min(15, len(guard.get('stale_locks') or []) * 3)
    score -= min(15, int(env_summary.get('missing_env', 0) or 0) * 5)
    score -= min(15, int(env_summary.get('missing_path', 0) or 0) * 5)
    score -= min(15, len(conflict.get('ambiguous_targets') or []) * 3)
    score -= min(15, int(override_summary.get('blockers', 0) or 0) * 5)
    score = max(0, min(100, int(score)))

    gates = {
        'saved': bool(guard.get('current_file_saved')),
        'missing': int(external.get('missing_records', 0) or 0) == 0,
        'absolute': int(external.get('absolute_records', 0) or 0) == 0,
        'locks': len(guard.get('lock_conflicts') or []) == 0,
        'env': int(env_summary.get('missing_env', 0) or 0) == 0 and int(env_summary.get('missing_path', 0) or 0) == 0,
        'override': int(override_summary.get('blockers', 0) or 0) == 0,
        'snapshot': int(guard.get('snapshot_entries', 0) or 0) > 0,
        'conflicts': len(conflict.get('ambiguous_targets') or []) == 0 and len(conflict.get('current_conflicts') or []) == 0,
    }
    ready = all(bool(v) for k, v in gates.items() if k not in {'absolute', 'snapshot', 'conflicts'})
    return {
        'current_file': guard.get('current_file') or '',
        'guard': guard,
        'external': external,
        'conflict': conflict,
        'env': env_payload,
        'override': override_payload,
        'blockers': blockers,
        'warnings': warnings,
        'gates': gates,
        'score': score,
        'ready': ready,
    }



def _sf_guard_handoff_report_lines(context, *, title: str = 'Project Handoff Audit', payload: dict | None = None) -> list[str]:
    payload = payload or _sf_guard_handoff_payload(context)
    guard = dict(payload.get('guard') or {})
    external = dict(payload.get('external') or {})
    conflict = dict(payload.get('conflict') or {})
    env_summary = dict((payload.get('env') or {}).get('summary') or {})
    override_summary = dict((payload.get('override') or {}).get('summary') or {})
    gates = dict(payload.get('gates') or {})
    def gate_text(flag: bool) -> str:
        return 'PASS' if flag else 'CHECK'
    lines = [
        f"Smart File | {title} | {_sf_guard_now_text()}",
        '',
        f"- {_t('Current File')}: {payload.get('current_file') or _t('Unsaved current file')}",
        f"- {_t('Handoff Readiness Score')}: {int(payload.get('score', 0) or 0)}/100",
        f"- {_t('Ready for Handoff')}: {'YES' if payload.get('ready') else 'NO'}",
        f"- {_t('Blockers')}: {len(payload.get('blockers') or [])}",
        f"- {_t('Warnings')}: {len(payload.get('warnings') or [])}",
        '',
        'GATES',
        f"- {_t('Saved File')}: {gate_text(bool(gates.get('saved')))}",
        f"- {_t('Missing References')}: {gate_text(bool(gates.get('missing')))}",
        f"- {_t('Absolute Paths')}: {gate_text(bool(gates.get('absolute')))}",
        f"- {_t('Lock Conflicts')}: {gate_text(bool(gates.get('locks')))}",
        f"- {_t('Context Root Environment')}: {gate_text(bool(gates.get('env')))}",
        f"- {_t('Library Overrides')}: {gate_text(bool(gates.get('override')))}",
        f"- {_t('Scene Snapshot')}: {gate_text(bool(gates.get('snapshot')))}",
        f"- {_t('Conflict Audit')}: {gate_text(bool(gates.get('conflicts')))}",
        '',
        'SUMMARY',
        f"- {_t('Linked Libraries')}: {len((guard.get('linked') or {}).get('libraries') or [])}",
        f"- {_t('Missing')}: {int(external.get('missing_records', 0) or 0)}",
        f"- {_t('Absolute')}: {int(external.get('absolute_records', 0) or 0)}",
        f"- {_t('Environment Variables')}: {int(external.get('env_records', 0) or 0)}",
        f"- {_t('Ambiguous Relink Targets')}: {len(conflict.get('ambiguous_targets') or [])}",
        f"- {_t('Current Basename Conflicts')}: {len(conflict.get('current_conflicts') or [])}",
        f"- {_t('Root Library Name Conflicts')}: {len(conflict.get('root_library_conflicts') or [])}",
        f"- {_t('Missing environment variable')}: {int(env_summary.get('missing_env', 0) or 0)}",
        f"- {_t('Missing path')}: {int(env_summary.get('missing_path', 0) or 0)}",
        f"- {_t('Direct path')}: {int(env_summary.get('direct', 0) or 0)}",
        f"- {_t('Override blockers')}: {int(override_summary.get('blockers', 0) or 0)}",
        f"- {_t('Override warnings')}: {int(override_summary.get('warnings', 0) or 0)}",
        f"- {_t('Active Locks')}: {int(guard.get('lock_count', 0) or 0)}",
        f"- {_t('Lock Conflicts')}: {len(guard.get('lock_conflicts') or [])}",
        f"- {_t('Stale Locks')}: {len(guard.get('stale_locks') or [])}",
        f"- {_t('Scene Snapshot Entries')}: {int(guard.get('snapshot_entries', 0) or 0)}",
    ]
    blockers = list(payload.get('blockers') or [])
    warnings = list(payload.get('warnings') or [])
    if blockers:
        lines.extend(['', 'BLOCKERS'])
        for row in blockers:
            lines.append(f"- {row}")
    if warnings:
        lines.extend(['', 'WARNINGS'])
        for row in warnings:
            lines.append(f"- {row}")
    ambiguous = list(conflict.get('ambiguous_targets') or [])
    if ambiguous:
        lines.extend(['', 'AMBIGUOUS RELINK TARGETS'])
        for row in ambiguous[:24]:
            lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | candidates={int(row.get('candidate_count', 0) or 0)}")
            if row.get('recommended'):
                lines.append(f"  - recommended={row.get('recommended','')}")
    current_conflicts = list(conflict.get('current_conflicts') or [])
    if current_conflicts:
        lines.extend(['', 'CURRENT BASENAME CONFLICTS'])
        for row in current_conflicts[:16]:
            lines.append(f"- {row.get('basename','')} | {int(row.get('count', 0) or 0)}")
            for sub in list(row.get('rows') or [])[:6]:
                lines.append(f"  - [{sub.get('kind','')}] {sub.get('name','')} | {sub.get('path','')}")
    env_rows = list((payload.get('env') or {}).get('rows') or [])
    if env_rows:
        lines.extend(['', 'CONTEXT ROOT ENV'])
        for row in env_rows[:16]:
            lines.append(f"- [{row.get('status','DIRECT')}] {row.get('alias','')} | {row.get('resolved_path','')}")
    override_rows = list((payload.get('override') or {}).get('rows') or [])
    if override_rows:
        lines.extend(['', 'OVERRIDE HEALTH'])
        for row in override_rows[:20]:
            lines.append(f"- [{row.get('status','OK')}] {row.get('name','')} | {row.get('type','')} | {row.get('detail','')}")
    lock_rows = list(guard.get('lock_rows') or [])
    if lock_rows:
        lines.extend(['', 'LOCK DETAILS'])
        for row in lock_rows[:20]:
            state = 'FREE'
            if row.get('locked'):
                state = 'STALE' if row.get('stale') else ('OWNED BY THIS FILE' if row.get('same_owner') else 'CONFLICT')
            lines.append(f"- [{state}] {row.get('target_path','')} | owner={row.get('owner','')} | updated={row.get('updated_at','')}")
    return lines


class SF_OT_project_guard_store_scene_state(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_store_scene_state'
    bl_label = 'Store Scene State'
    bl_description = 'Capture the current camera, frame range, render output, and visibility state of scene objects and collections so you can switch shot setups safely and restore them later. This behaves like a compact shot-state memory for both beginners and advanced pipeline work.'
    bl_options = {'UNDO'}

    include_objects: BoolProperty(name='Include objects', default=True, options={'HIDDEN'}, description='Store object visibility and display-type state too.')
    include_collections: BoolProperty(name='Include collections', default=True, options={'HIDDEN'}, description='Store collection visibility state too.')

    def execute(self, context):
        payload = _sf_guard_store_scene_state(context, include_objects=bool(self.include_objects), include_collections=bool(self.include_collections))
        entry_count = len(list(payload.get('object_states', []) or [])) + len(list(payload.get('collection_states', []) or []))
        try:
            _sf_append_activity(context, _t('Stored scene state snapshot'), str(entry_count), 'FILE_TICK')
        except Exception:
            pass
        if not payload:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Stored')}: {entry_count}")
        return {'FINISHED'}


class SF_OT_project_guard_restore_scene_state(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_restore_scene_state'
    bl_label = 'Restore Scene State'
    bl_description = 'Restore the most recently stored or imported scene-state snapshot, including camera, frame range, render settings, and saved visibility states. Use this when temporary troubleshooting or layout changes should not overwrite the intended shot setup.'
    bl_options = {'UNDO'}

    def execute(self, context):
        result = _sf_guard_restore_scene_state(context)
        restored = int(result.get('restored', 0) or 0)
        missing = int(result.get('missing', 0) or 0)
        failed = int(result.get('failed', 0) or 0)
        markers_added = int(result.get('markers_added', 0) or 0)
        markers_updated = int(result.get('markers_updated', 0) or 0)
        try:
            _sf_append_activity(context, _t('Restored scene state snapshot'), str(restored), 'RECOVER_LAST')
        except Exception:
            pass
        if restored == 0 and missing == 0 and failed == 0:
            self.report({'WARNING'}, _t('No stored scene-state snapshot was found'))
            return {'CANCELLED'}
        self.report({'WARNING'} if (missing or failed) else {'INFO'}, f"{_t('Restored')}: {restored} | {_t('Missing')}: {missing} | {_t('Failed')}: {failed}")
        return {'FINISHED'}


class SF_OT_project_guard_export_scene_state(bpy.types.Operator, ExportHelper):
    bl_idname = 'export_scene.sfs_project_guard_export_scene_state'
    bl_label = 'Export Scene State'
    bl_description = 'Write the current shot-style scene state into a JSON file so another scene, task, or teammate can restore the same camera, render, and visibility setup later. This gives Blender a lightweight handoff format similar to shot-state tools in larger DCC pipelines.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.sf_scene_state.json'
    filter_glob: StringProperty(default='*.sf_scene_state.json;*.json', options={'HIDDEN'})
    include_objects: BoolProperty(name='Include objects', default=True, description='Include object visibility and display state in the exported file.')
    include_collections: BoolProperty(name='Include collections', default=True, description='Include collection visibility state in the exported file.')
    open_folder: BoolProperty(name='Open folder', default=False, description='Open the destination folder after export.')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('No export path'))
            return {'CANCELLED'}
        payload = _sf_guard_capture_scene_state(context, include_objects=bool(self.include_objects), include_collections=bool(self.include_collections))
        if not payload:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        _sf_guard_write_json(filepath, payload)
        try:
            _sf_append_activity(context, _t('Exported scene state snapshot'), os.path.basename(filepath), 'EXPORT')
        except Exception:
            pass
        if self.open_folder:
            try:
                bpy.ops.wm.path_open(filepath=os.path.dirname(filepath) or filepath)
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Scene state')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_project_guard_import_scene_state(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.sfs_project_guard_import_scene_state'
    bl_label = 'Import Scene State'
    bl_description = 'Read a previously exported scene-state JSON file, store it in the current session, and optionally apply it immediately. This is useful for restoring per-shot camera and visibility setups after handoff or troubleshooting.'
    bl_options = {'UNDO'}

    filter_glob: StringProperty(default='*.sf_scene_state.json;*.json', options={'HIDDEN'})
    apply_immediately: BoolProperty(name='Apply immediately', default=True, description='Apply the imported scene state right after reading the file.')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath or not os.path.isfile(filepath):
            self.report({'ERROR'}, _t('Scene-state file was not found'))
            return {'CANCELLED'}
        payload = _sf_guard_read_json(filepath)
        if str(payload.get('kind', '') or '') != 'scene_state_snapshot':
            self.report({'ERROR'}, _t('This file is not a Smart File scene-state snapshot'))
            return {'CANCELLED'}
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            try:
                wm.sf_project_guard_scene_state_json = json.dumps(payload, ensure_ascii=False)
            except Exception:
                pass
        restored = 0
        missing = 0
        failed = 0
        markers_added = 0
        markers_updated = 0
        if self.apply_immediately:
            result = _sf_guard_restore_scene_state_from_payload(context, payload)
            restored = int(result.get('restored', 0) or 0)
            missing = int(result.get('missing', 0) or 0)
            failed = int(result.get('failed', 0) or 0)
            markers_added = int(result.get('markers_added', 0) or 0)
            markers_updated = int(result.get('markers_updated', 0) or 0)
        try:
            _sf_append_activity(context, _t('Imported scene state snapshot'), os.path.basename(filepath), 'IMPORT')
        except Exception:
            pass
        if self.apply_immediately:
            self.report({'WARNING'} if (missing or failed) else {'INFO'}, f"{_t('Restored')}: {restored} | {_t('Missing')}: {missing} | {_t('Failed')}: {failed} | {_t('Markers')}: +{markers_added}/~{markers_updated}")
        else:
            self.report({'INFO'}, _t('Scene-state snapshot stored in the current session'))
        return {'FINISHED'}


class SF_OT_project_guard_create_cooperative_lock(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_create_cooperative_lock'
    bl_label = 'Create Cooperative Lock'
    bl_description = 'Create a lightweight cooperative lock file for the current .blend file, linked libraries, or both. This does not force Blender to block editing, but it gives teams a clear check-out style signal that the scene or reference is already being worked on.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_GUARD_LOCK_SCOPE_ITEMS, default='CURRENT_AND_LINKED')
    force: BoolProperty(name='Force', default=False, description='Allow stale or conflicting locks to be replaced after you verify the previous owner is no longer working on them.')
    note: StringProperty(name='Note', default='', description='Optional short note written into each lock file so teammates know why the lock exists.')

    def execute(self, context):
        targets = _sf_guard_targets(self.scope)
        if not targets:
            self.report({'WARNING'}, _t('No valid lock targets were found'))
            return {'CANCELLED'}
        ok = 0
        conflicts = []
        reclaimed = 0
        for path in targets:
            result = _sf_guard_acquire_lock(path, note=self.note, force=bool(self.force))
            if result.get('ok'):
                ok += 1
                if str(result.get('reason', '') or '') == 'reclaimed_stale':
                    reclaimed += 1
            else:
                conflicts.append(result)
        try:
            _sf_append_activity(context, _t('Created cooperative locks'), f"{ok}/{len(targets)}", 'LOCKED')
        except Exception:
            pass
        if ok == 0:
            detail = conflicts[0].get('owner', '') if conflicts else ''
            self.report({'ERROR'}, f"{_t('Lock conflict')}: {detail}")
            return {'CANCELLED'}
        level = {'WARNING'} if conflicts else {'INFO'}
        msg = f"{_t('Created')}: {ok}"
        if reclaimed:
            msg += f" | {_t('Reclaimed stale')}: {reclaimed}"
        if conflicts:
            msg += f" | {_t('Conflicts')}: {len(conflicts)}"
        self.report(level, msg)
        return {'FINISHED'}


class SF_OT_project_guard_refresh_cooperative_locks(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_refresh_cooperative_locks'
    bl_label = 'Refresh Cooperative Locks'
    bl_description = "Refresh lock timestamps for the current file, linked libraries, or both. This safely renews locks already owned by the current blend and creates missing ones if needed, while leaving another artist's active lock untouched."
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_GUARD_LOCK_SCOPE_ITEMS, default='CURRENT_AND_LINKED')
    note: StringProperty(name='Note', default='', description='Optional short note written while refreshing locks so teammates can see what task is still in progress.')
    create_missing: BoolProperty(name='Create missing locks', default=True, description='If a target no longer has a lock file, create a fresh one while refreshing the rest. Disable this if you only want to touch locks that already exist.')

    def execute(self, context):
        result = _sf_guard_refresh_locks(self.scope, note=self.note, create_missing=bool(self.create_missing))
        refreshed = list(result.get('refreshed') or [])
        created = list(result.get('created') or [])
        conflicts = list(result.get('conflicts') or [])
        failed = list(result.get('failed') or [])
        try:
            _sf_append_activity(context, _t('Refreshed cooperative locks'), f"{len(refreshed) + len(created)}", 'FILE_REFRESH')
        except Exception:
            pass
        if (not refreshed) and (not created) and conflicts:
            detail = conflicts[0].get('owner', '') if conflicts else ''
            self.report({'ERROR'}, f"{_t('Lock conflict')}: {detail}")
            return {'CANCELLED'}
        level = {'WARNING'} if conflicts or failed else {'INFO'}
        msg = f"{_t('Refreshed')}: {len(refreshed)} | {_t('Created')}: {len(created)}"
        if conflicts:
            msg += f" | {_t('Conflicts')}: {len(conflicts)}"
        if failed:
            msg += f" | {_t('Failed')}: {len(failed)}"
        self.report(level, msg)
        return {'FINISHED'}



class SF_OT_project_guard_release_cooperative_lock(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_release_cooperative_lock'
    bl_label = 'Release Cooperative Lock'
    bl_description = 'Release cooperative lock files created by Smart File for the current .blend file, linked libraries, or both. Use this after relink, publish, or handoff work so other artists know the file is no longer actively reserved.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_GUARD_LOCK_SCOPE_ITEMS, default='CURRENT_AND_LINKED')
    force: BoolProperty(name='Force', default=False, description='Allow locks owned by other files to be removed too. Use only after confirming the previous owner finished or the lock is stale.')

    def execute(self, context):
        targets = _sf_guard_targets(self.scope)
        if not targets:
            self.report({'WARNING'}, _t('No valid lock targets were found'))
            return {'CANCELLED'}
        ok = 0
        conflicts = []
        for path in targets:
            result = _sf_guard_release_lock(path, force=bool(self.force))
            if result.get('ok'):
                ok += 1
            elif str(result.get('reason', '') or '') != 'missing':
                conflicts.append(result)
        try:
            _sf_append_activity(context, _t('Released cooperative locks'), f"{ok}/{len(targets)}", 'UNLOCKED')
        except Exception:
            pass
        if ok == 0 and conflicts:
            detail = conflicts[0].get('owner', '') if conflicts else ''
            self.report({'ERROR'}, f"{_t('Lock conflict')}: {detail}")
            return {'CANCELLED'}
        level = {'WARNING'} if conflicts else {'INFO'}
        msg = f"{_t('Released')}: {ok}"
        if conflicts:
            msg += f" | {_t('Conflicts')}: {len(conflicts)}"
        self.report(level, msg)
        return {'FINISHED'}


class SF_OT_project_guard_cleanup_stale_locks(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_cleanup_stale_locks'
    bl_label = 'Cleanup Stale Locks'
    bl_description = 'Remove only stale cooperative lock files for the current file, linked libraries, or both. This is safer than force-unlock because active locks owned by someone else are kept intact.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_GUARD_LOCK_SCOPE_ITEMS, default='CURRENT_AND_LINKED')

    def execute(self, context):
        result = _sf_guard_cleanup_stale_locks(self.scope)
        removed = list(result.get('removed') or [])
        failed = list(result.get('failed') or [])
        skipped = list(result.get('skipped') or [])
        try:
            _sf_append_activity(context, _t('Cleaned stale cooperative locks'), f"{len(removed)}", 'TRASH')
        except Exception:
            pass
        if failed:
            self.report({'WARNING'}, f"{_t('Removed')}: {len(removed)} | {_t('Failed')}: {len(failed)}")
            return {'FINISHED'}
        if removed:
            self.report({'INFO'}, f"{_t('Removed')}: {len(removed)} | {_t('Kept active')}: {len([row for row in skipped if str(row.get('reason', '')) == 'active'])}")
            return {'FINISHED'}
        self.report({'INFO'}, _t('No stale locks were found'))
        return {'FINISHED'}


class SF_OT_project_guard_export_report(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_export_report'
    bl_label = 'Export Report'
    bl_description = 'Write a compact report that summarizes missing externals, absolute paths, linked-library counts, scene snapshot readiness, and cooperative lock status. This gives beginners a readable handoff note and gives advanced users a quick troubleshooting snapshot.'
    bl_options = {'UNDO'}

    open_text: BoolProperty(name='Open report', default=True, options={'HIDDEN'})

    def execute(self, context):
        lines = _sf_guard_report_lines(context)
        text_name = _sf_report_export(
            context,
            _t('Project Guard Report'),
            lines,
            open_text=bool(self.open_text),
            activity_title=_t('Exported Project Guard report'),
        )
        self.report({'INFO'}, text_name)
        return {'FINISHED'}



class SF_OT_project_guard_handoff_audit(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_project_guard_handoff_audit'
    bl_label = 'Handoff Audit'
    bl_description = 'Write one integrated handoff audit that combines external-reference health, relink ambiguity, Context Root environment checks, Library Override health, and cooperative lock status before you package, publish, or hand off the current scene.'
    bl_options = {'UNDO'}

    search_dir: StringProperty(name='Extra search folder', subtype='DIR_PATH', default='')
    include_current_file_dir: BoolProperty(name='Include current file folder', default=True)
    include_library_roots: BoolProperty(name='Include library roots', default=True)
    include_context_roots: BoolProperty(name='Include Context Roots', default=True)
    open_text: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'search_dir')
        layout.prop(self, 'include_current_file_dir')
        layout.prop(self, 'include_library_roots')
        layout.prop(self, 'include_context_roots')
        layout.prop(self, 'open_text')

    def execute(self, context):
        payload = _sf_guard_handoff_payload(
            context,
            search_dir=self.search_dir,
            include_current_file_dir=bool(self.include_current_file_dir),
            include_library_roots=bool(self.include_library_roots),
            include_context_roots=bool(self.include_context_roots),
        )
        title = _t('Project Handoff Audit')
        text_name = _sf_report_export(
            context,
            title,
            _sf_guard_handoff_report_lines(context, title=title, payload=payload),
            open_text=bool(self.open_text),
            activity_title=_t('Exported handoff audit'),
        )
        if payload.get('blockers'):
            self.report({'WARNING'}, f"{_t('Handoff audit exported')}: {text_name}")
        else:
            self.report({'INFO'}, f"{_t('Handoff audit exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_project_guard_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_project_guard_open'
    bl_label = 'Open'
    bl_description = 'Open a compact visual board for external-reference health, shot-style scene-state snapshots, and cooperative check-out locks. This board brings together the practical overlap between Project Manager, Shot Manager, Save Cams, Missing Assets tools, and lightweight reference-lock workflows in one Blender-first UI.'
    bl_options = set()

    popup_width: IntProperty(default=660, min=460, max=920, options={'HIDDEN'})

    def invoke(self, context, event):
        try:
            _sf_append_activity(context, _t('Opened Project Guard'), '', 'LOCKVIEW_ON')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        payload = _sf_guard_health_payload(context)
        external = dict(payload.get('external') or {})
        conflicts = list(payload.get('lock_conflicts') or [])
        stale = list(payload.get('stale_locks') or [])
        _sf_draw_dialog_header(
            layout,
            'Project Guard',
            'Review missing references, scene-state snapshots, and cooperative locks before relink, publish, or handoff work.',
            'LOCKVIEW_ON',
        )

        summary = layout.box()
        _sf_draw_section_intro(
            summary,
            'Health Summary',
            'Use this snapshot first. It shows whether the current file is saved, whether external references are portable, and whether another file already marked the same targets as busy.',
            'NONE',
        )
        _sf_draw_state_line(summary, 'Current File Saved', 'READY' if payload.get('current_file_saved') else 'NOT SET', detail=(payload.get('current_file') or _t('Unsaved current file')))
        _sf_draw_state_line(summary, 'Missing External References', 'READY' if int(external.get('missing_records', 0) or 0) == 0 else 'ATTENTION NEEDED', detail=str(int(external.get('missing_records', 0) or 0)))
        _sf_draw_state_line(summary, 'Absolute External Paths', 'READY' if int(external.get('absolute_records', 0) or 0) == 0 else 'ATTENTION NEEDED', detail=str(int(external.get('absolute_records', 0) or 0)))
        _sf_draw_state_line(summary, 'Linked Libraries', 'READY' if len((payload.get('linked') or {}).get('libraries') or []) else 'NOT SET', detail=str(len((payload.get('linked') or {}).get('libraries') or [])))
        _sf_draw_state_line(summary, 'Cooperative Lock Conflicts', 'READY' if not conflicts else 'ATTENTION NEEDED', detail=str(len(conflicts)))
        _sf_draw_state_line(summary, 'Stale Locks', 'READY' if not stale else 'NEEDS ATTENTION', detail=str(len(stale)))
        _sf_draw_state_line(summary, 'Scene Snapshot Entries', 'READY' if int(payload.get('snapshot_entries', 0) or 0) else 'NOT SET', detail=str(int(payload.get('snapshot_entries', 0) or 0)))
        _sf_draw_state_line(summary, 'Relative Ready', 'READY' if payload.get('relative_ready') else 'NOT READY', detail=_t('No missing and no absolute external paths are preferred before packaging or handoff.') if not payload.get('relative_ready') else '')

        state_box = layout.box()
        _sf_draw_section_intro(
            state_box,
            'Scene State & Shot Handoff',
            'Store or export a recoverable scene-state snapshot before temporary layout, troubleshooting, or review changes. This is especially useful when multiple camera shots share the same linked asset assembly.',
            'CAMERA_DATA',
        )
        _sf_draw_action_block(
            state_box,
            primary_actions=[
                ('import_scene.sfs_project_guard_store_scene_state', 'Store Scene State', 'FILE_TICK', {}),
                ('import_scene.sfs_project_guard_restore_scene_state', 'Restore Scene State', 'RECOVER_LAST', {}),
                ('export_scene.sfs_project_guard_export_scene_state', 'Export Scene State', 'EXPORT', {}),
                ('import_scene.sfs_project_guard_import_scene_state', 'Import Scene State', 'IMPORT', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_shot_state_open', 'Shot States', 'CAMERA_DATA', {}),
                ('import_scene.sfs_shot_queue_open', 'Shot Queue', 'RENDER_STILL', {}),
                ('import_scene.sfs_assembly_guard_open', 'Assembly Guard', 'RESTRICT_SELECT_OFF', {}),
                ('export_scene.sfs_pipeline_shot_manifest', 'Shot Manifest', 'FILE_TEXT', {}),
                ('import_scene.sfs_representation_store_snapshot', 'Store Representation', 'MOD_WIREFRAME', {}),
                ('import_scene.sfs_representation_restore_snapshot', 'Restore Representation', 'RECOVER_LAST', {}),
            ],
        )

        lock_box = layout.box()
        _sf_draw_section_intro(
            lock_box,
            'Cooperative Locks',
            'These locks do not hard-block Blender. They create small sidecar files so teammates can see that the current file or linked references are already being handled in another task.',
            'LOCKED',
        )
        _sf_draw_action_block(
            lock_box,
            primary_actions=[
                ('import_scene.sfs_project_guard_create_cooperative_lock', 'Lock Current', 'LOCKED', {'scope': 'CURRENT_FILE'}),
                ('import_scene.sfs_project_guard_create_cooperative_lock', 'Lock Linked', 'LOCKED', {'scope': 'LINKED_LIBRARIES'}),
                ('import_scene.sfs_project_guard_create_cooperative_lock', 'Lock All', 'LOCKED', {'scope': 'CURRENT_AND_LINKED'}),
                ('import_scene.sfs_project_guard_refresh_cooperative_locks', 'Refresh Mine', 'FILE_REFRESH', {'scope': 'CURRENT_AND_LINKED'}),
            ],
            secondary_actions=[
                ('import_scene.sfs_project_guard_release_cooperative_lock', 'Unlock Current', 'UNLOCKED', {'scope': 'CURRENT_FILE'}),
                ('import_scene.sfs_project_guard_release_cooperative_lock', 'Unlock Linked', 'UNLOCKED', {'scope': 'LINKED_LIBRARIES'}),
                ('import_scene.sfs_project_guard_release_cooperative_lock', 'Unlock All', 'UNLOCKED', {'scope': 'CURRENT_AND_LINKED'}),
                ('import_scene.sfs_project_guard_cleanup_stale_locks', 'Cleanup Stale', 'TRASH', {'scope': 'CURRENT_AND_LINKED'}),
            ],
        )
        if conflicts:
            notice = lock_box.box()
            _sf_draw_section_intro(
                notice,
                'Active Conflicts',
                'These lock files appear to belong to another owner. Review them before forcing a lock or unlock action.',
                'ERROR',
            )
            for row in conflicts[:4]:
                notice.label(text=(row.get('target_path') or '')[:140], icon='BLANK1')
                owner = row.get('owner') or row.get('owner_blend') or _t('Unknown owner')
                notice.label(text=str(owner)[:140], icon='BLANK1')
                note = str(row.get('note', '') or '').strip()
                if note:
                    notice.label(text=_sf_short_label_display(note, 120))
        if stale:
            stale_box = lock_box.box()
            _sf_draw_section_intro(
                stale_box,
                'Stale Locks',
                'These lock files look abandoned because the owning file disappeared or the timestamp is too old. Cleanup Stale removes only these rows and keeps active locks intact.',
                'TRASH',
            )
            for row in stale[:4]:
                stale_box.label(text=(row.get('target_path') or '')[:140], icon='BLANK1')
                owner = row.get('owner') or row.get('owner_blend') or _t('Unknown owner')
                stale_box.label(text=str(owner)[:140], icon='BLANK1')
                note = str(row.get('note', '') or '').strip()
                if note:
                    stale_box.label(text=_sf_short_label_display(note, 120))

        tools = layout.box()
        _sf_draw_section_intro(
            tools,
            'Diagnostics & Recovery',
            'Jump to the most relevant repair and overview tools from here when the summary shows missing paths, heavy linked scenes, or unsafe handoff conditions.',
            'TOOL_SETTINGS',
        )
        _sf_draw_action_block(
            tools,
            primary_actions=[
                ('import_scene.sfs_project_guard_export_report', 'Export Guard Report', 'TEXT', {}),
                ('import_scene.sfs_project_guard_handoff_audit', 'Handoff Audit...', 'TEXT', {}),
                ('import_scene.sfs_external_assets_audit', 'Audit', 'CHECKMARK', {}),
                ('import_scene.sfs_dependency_cockpit_open', 'Dependency Cockpit', 'FILE_TICK', {}),
                ('import_scene.sfs_context_roots_open', 'Context Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_root_watch_open', 'Watch Roots', 'FILE_REFRESH', {}),
                ('import_scene.sfs_reference_manager_open', 'Relink', 'LINKED', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_pipeline_linked_overview', 'Linked Overview', 'LINKED', {}),
                ('import_scene.sfs_representation_open', 'Representations', 'MOD_WIREFRAME', {}),
                ('import_scene.sfs_assembly_guard_open', 'Assembly Guard', 'RESTRICT_SELECT_OFF', {}),
                ('import_scene.sfs_workspace_command_fix_all', 'Run Fix', 'TOOL_SETTINGS', {}),
            ],
        )

        tip = layout.box()
        _sf_draw_section_intro(
            tip,
            'Recommended Flow',
            'Store a scene-state snapshot first, review missing or absolute references, then create cooperative locks before larger relink or publish passes. After handoff, export the guard report and release the locks so the next person sees a clean state.',
            'LIGHT',
        )
