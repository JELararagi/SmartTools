# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

_LOADER = None
_UI_RUNTIME = None
_LAST_RUNTIME_ERROR = ''


def _runtime_modules():
    global _LOADER, _UI_RUNTIME
    if _LOADER is None:
        from . import loader as _loaded_loader
        _LOADER = _loaded_loader
    if _UI_RUNTIME is None:
        from . import ui_runtime as _loaded_ui_runtime
        _UI_RUNTIME = _loaded_ui_runtime
    return _LOADER, _UI_RUNTIME


def register() -> bool:
    """Register the metadata-only integrated runtime as one transaction.

    Errors are retained as diagnostics and reported to the package root through
    ``False``.  No exception crosses the Blender add-on register boundary.
    """
    import time
    global _SFS_RUNTIME_PROFILE, _LAST_RUNTIME_ERROR
    profile = {}
    _LAST_RUNTIME_ERROR = ''
    total_started = time.perf_counter()
    import_started = time.perf_counter()
    loader = None
    ui_runtime = None
    loader_ready = False
    ui_ready = False
    try:
        loader, ui_runtime = _runtime_modules()
        profile['module_import'] = time.perf_counter() - import_started
        loader_started = time.perf_counter()
        records = loader.register_all()
        profile['loader_register'] = time.perf_counter() - loader_started
        loader_ready = isinstance(records, list)
        if not loader_ready:
            raise RuntimeError("integrated loader registration did not return its record set")
        ui_started = time.perf_counter()
        ui_ready = bool(ui_runtime.register())
        profile['ui_register'] = time.perf_counter() - ui_started
        if not ui_ready:
            raise RuntimeError(
                getattr(ui_runtime, "_LAST_RUNTIME_ERROR", "")
                or "integrated UI runtime exact registration failed"
            )
        profile['total'] = time.perf_counter() - total_started
        _SFS_RUNTIME_PROFILE = dict(profile)
        import sys
        root = sys.modules.get(str(__package__ or ''))
        if root is not None:
            setattr(root, '_SFS_RUNTIME_PROFILE', dict(profile))
            # The N-panel catalog was primed before the integrated records existed.
            prime_lane_cache = getattr(root, '_sf_prime_lane_tool_sections_cache', None)
            if callable(prime_lane_cache):
                try:
                    import bpy
                    prime_lane_cache(getattr(bpy, 'context', None))
                except Exception:
                    # Non-fatal: the draw path can still build the same catalog.
                    pass
        return True
    except Exception as exc:
        _LAST_RUNTIME_ERROR = f'{type(exc).__name__}: {exc}'
        profile['total'] = time.perf_counter() - total_started
        _SFS_RUNTIME_PROFILE = dict(profile)
        if ui_ready and ui_runtime is not None:
            try:
                ui_runtime.unregister()
            except Exception:
                pass
        if loader_ready and loader is not None:
            try:
                loader.unregister_all()
            except Exception:
                pass
        return False


def unregister() -> bool:
    """Reverse only resources owned by this integrated runtime generation."""
    ok = True
    # Save optional Scene RNA before the loader removes it. The later core
    # teardown otherwise serializes an empty owner and loses enabled labels.
    try:
        import bpy
        from . import settings
        if settings._keeper_enabled(bpy.context):
            if not settings.save_now(bpy.context, force=True, allow_disabled=True):
                ok = False
    except Exception:
        ok = False
    ui_runtime = _UI_RUNTIME
    loader = _LOADER
    if ui_runtime is not None:
        try:
            if ui_runtime.unregister() is False:
                ok = False
        except Exception:
            ok = False
    if loader is not None:
        try:
            loader.unregister_all()
        except Exception:
            ok = False
    return ok
