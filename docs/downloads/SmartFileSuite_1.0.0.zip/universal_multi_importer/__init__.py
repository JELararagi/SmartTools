# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations
import bpy

bl_info = {
    "name": "Universal Multi Importer",
    "author": "JELararagi",
    "description": "Batch Import many file formats at once, Batch process them",
    "blender": (5, 1, 0),
    "version": (2, 4, 0),
    "location": "File > Import > Universal Multi Importer (File / Folder) | Object > Command Batcher",
    "warning": "",
    "doc_url": "https://github.com/Tilapiatsu/blender-Universal_Multi_Importer",
    "tracker_url": ("https://github.com/Tilapiatsu/blender-Universal_Multi_Importer/issues/new"),
    "support": "COMMUNITY",
    "category": "Import-Export",
}



def _umi_class_has_bl_rna(cls):
    """Return True only for classes Blender has fully registered.

    Blender 5.1/Python 3.13 may expose an inherited placeholder ``bl_rna`` on
    unregistered PropertyGroup subclasses.  PointerProperty rejects that state
    with a missing-bl_rna error, so the class also has to be present in
    ``bpy.types`` under its RNA class name.
    """
    if not isinstance(cls, type):
        return False
    try:
        bl_rna = getattr(cls, "bl_rna", None)
        identifier = str(getattr(bl_rna, "identifier", "") or "").strip()
    except Exception:
        return False
    if not identifier or identifier in {"PropertyGroup", "Operator", "Panel", "Menu", "AddonPreferences"}:
        return False
    # Blender 5.1 may keep a dynamically loaded PropertyGroup out of
    # ``bpy.types`` even though its RNA registration is complete.  The
    # ``is_registered`` flag is authoritative in that case and the class is
    # valid for PointerProperty (verified for extension-loaded classes).
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
        return getattr(bpy.types, identifier, None) is cls
    except Exception:
        return False


def _umi_ensure_class_ready(cls):
    if _umi_class_has_bl_rna(cls):
        return True
    if not isinstance(cls, type):
        return False
    try:
        bpy.utils.register_class(cls)
    except Exception:
        try:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
        except Exception:
            return False
    return _umi_class_has_bl_rna(cls)


def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def register():
    from . import import_module

    import_module.register()
    from . import preferences
    from . import operators
    from .preferences.preferences import PreferencesProxy

    preferences.register()
    if _umi_ensure_class_ready(PreferencesProxy):
        bpy.types.WindowManager.umi_preferences_proxy = bpy.props.PointerProperty(type=PreferencesProxy)
    _apply_suite_settings_after_pointer_registration(getattr(bpy, 'context', None))
    operators.register()


def unregister():
    from . import import_module
    from . import preferences
    from . import operators

    operators.unregister()
    if hasattr(bpy.types.WindowManager, 'umi_preferences_proxy'):
        del bpy.types.WindowManager.umi_preferences_proxy
    preferences.unregister()
    import_module.unregister()


if __name__ == "__main__":
    register()
