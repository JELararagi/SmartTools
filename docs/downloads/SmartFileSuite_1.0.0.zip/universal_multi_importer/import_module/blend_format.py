from ...ui_language_runtime import ui_text as _ui_text
import bpy
from os import path
from ..unique_name.unique_name import UniqueName
from ..logger import LOG
from ..bversion import BVERSION


class IMPORT_SCENE_OT_universal_multi_importer_import_blend(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_universal_multi_importer_import_blend'
    bl_label = 'Import Blend'
    bl_options = {'UNDO', 'INTERNAL'}
    bl_description = "Append or Link Blend file"

    import_module: bpy.props.EnumProperty(
        name="Import Module", default="APPEND", items=[("APPEND", "Append", ""), ("LINK", "Link", "")]
    )

    import_actions: bpy.props.BoolProperty(name="Actions", default=False)
    import_armatures: bpy.props.BoolProperty(name="Armatures", default=False)
    import_brushes: bpy.props.BoolProperty(name="Brushes", default=False)
    import_cameras: bpy.props.BoolProperty(name="Cameras", default=False)
    import_cache_files: bpy.props.BoolProperty(name="Cache files", default=False)
    import_curves: bpy.props.BoolProperty(name="Curves", default=False)
    import_hair_curves: bpy.props.BoolProperty(name="Hair Curves", default=False)
    import_fonts: bpy.props.BoolProperty(name="Fonts", default=False)
    import_grease_pencils: bpy.props.BoolProperty(name="Grease Penil", default=False)
    import_collections: bpy.props.BoolProperty(name="Collections", default=False)
    import_images: bpy.props.BoolProperty(name="Images", default=False)
    import_lights: bpy.props.BoolProperty(name="Lights", default=False)
    import_linestyles: bpy.props.BoolProperty(name="Line Styes", default=False)
    import_lattices: bpy.props.BoolProperty(name="Lattices", default=False)
    import_masks: bpy.props.BoolProperty(name="Masks", default=False)
    import_materials: bpy.props.BoolProperty(name="Materials", default=False)
    import_metaballs: bpy.props.BoolProperty(name="Metaballs", default=False)
    import_meshes: bpy.props.BoolProperty(name="Meshes", default=False)
    import_movieclips: bpy.props.BoolProperty(name="Movie Clips", default=False)
    import_node_groups: bpy.props.BoolProperty(name="Node Groups", default=False)
    import_objects: bpy.props.BoolProperty(name="Objects", default=True)
    import_paint_curves: bpy.props.BoolProperty(name="Paint Cures", default=False)
    import_palettes: bpy.props.BoolProperty(name="Palettes", default=False)
    import_particles: bpy.props.BoolProperty(name="Particles", default=False)
    import_pointclouds: bpy.props.BoolProperty(name="Point Clouds", default=False)
    import_lightprobes: bpy.props.BoolProperty(name="Light Probes", default=False)
    import_scenes: bpy.props.BoolProperty(name="Scenes", default=False)
    # import_shape_keys : bpy.props.BoolProperty(name="Shape Keys", default=False)
    import_sounds: bpy.props.BoolProperty(name="Sounds", default=False)
    import_speakers: bpy.props.BoolProperty(name="Speakers", default=False)
    import_texts: bpy.props.BoolProperty(name="Texts", default=False)
    import_textures: bpy.props.BoolProperty(name="Textures", default=False)
    import_volumes: bpy.props.BoolProperty(name="Volumes", default=False)
    import_worlds: bpy.props.BoolProperty(name="Worlds", default=False)
    import_workspaces: bpy.props.BoolProperty(name="Workspaces", default=False)

    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH", options={"HIDDEN"})

    import_to_collection_source = ["objects", "collections"]
    import_to_collection_rnatype_name = ["Object", "Collection"]
    force_append_mode = ["collections", "workspaces", "volumes", "scenes", "lightprobes", "particles", "pointclouds"]
    excluded_datatypes = [
        "batch_remove",
        "bl_rna",
        "filepath",
        "is_dirty",
        "is_saved",
        "libraries",
        "orphans_purge",
        "rna_type",
        "screens",
        "temp_data",
        "use_autopack",
        "user_map",
        "version",
        "window_managers",
        "shape_keys",
    ]
    dependency_datatype = [
        "ACTION",
        "ARMATURE",
        "BRUSH",
        "CACHEFILE",
        "CAMERA",
        "COLLECTION",
        "CURVE",
        "CURVES",
        "FONT",
        "GEOMETRY",
        "GREASEPENCIL",
        "GREASEPENCIL_V3",
        "IMAGE",
        "KEY",
        "LATTICE",
        "LIBRARY",
        "LIGHT",
        "LIGHT_PROBE",
        "LINESTYLE",
        "MASK",
        "MATERIAL",
        "MESH",
        "META",
        "MOVIECLIP",
        "NODETREE",
        "NODEOBJECT",
        "PAINTCURVE",
        "PALETTE",
        "PARTICLE",
        "POINTCLOUD",
        "SCENE",
        "SCREEN",
        "SOUND",
        "SPEAKER",
        "TEXT",
        "TEXTURE",
        "VOLUME",
        "WINDOWMANAGER",
        "WORKSPACE",
        "WORLD",
    ]

    @property
    def is_append(self):
        return self.import_module == "APPEND"

    @property
    def is_link(self):
        return self.import_module == "LINK"

    @property
    def filename(self):
        return path.basename(self.filepath)

    @property
    def import_datas(self):
        if self._import_datas is None:
            self._import_datas = [
                m.replace("import_", "")
                for m in self.__annotations__.keys()
                if m.startswith("import_") and m != "import_module" and getattr(self, m)
            ]

        return self._import_datas

    @property
    def local_names(self):
        if self._local_names is None:
            local_names = {}

            for datatype in dir(bpy.data):
                if (
                    datatype in self.excluded_datatypes or datatype.startswith("__")
                ) or datatype not in self.import_datas:
                    continue

                data = getattr(bpy.data, datatype)

                local_names[datatype] = [d.name for d in data]

            self._local_names = local_names

        return self._local_names

    @property
    def operation(self):
        return "Appending" if self.is_append else "Linking"

    @property
    def library(self):
        if self._library is None:
            lib_name = self.filename
            if lib_name in bpy.data.libraries:
                self._library = bpy.data.libraries[lib_name]

        return self._library

    def register_local_unique_names(self):
        for source in self.import_datas:
            local_datas = getattr(bpy.data, source)

            for e in local_datas:
                self.unique_name.register_element_correspondance(e)

    def get_import_command(self):
        return bpy.ops.wm.append if self.is_append else bpy.ops.wm.link

    def get_data_dependencies(self, src, object_to_import, dependencies, data):
        # Capture Dependencies
        for p in dir(src):
            if p.startswith("__"):
                continue

            # print(src.name, p)
            if p in ["layers_uv_select_src", "layers_vcol_select_src"]:
                continue

            attr = getattr(src, p, None)

            if attr is None:
                continue

            try:
                attr.rna_type
                attr_type = attr.id_type
            except AttributeError:
                continue

            if attr_type in self.dependency_datatype:
                if attr in object_to_import:
                    continue

                if attr_type == "OBJECT":
                    if attr in object_to_import:
                        continue
                    LOG.info(f'Blend format : Link Object Depencency "{attr.name}"')
                    object_to_import.append(attr)
                elif attr_type in ["NODETREE", "GEOMETRY"]:
                    if attr in data:
                        continue
                    LOG.info(f'Blend format : Link Node Depencency "{attr.name}"')
                    data.append(attr.name)
                else:
                    if attr in dependencies:
                        continue
                    LOG.info(f'Blend format : Link Depencency "{attr.name}"')
                    dependencies.append(attr)

    def append_data(self, source, data_list):
        source_string = source.replace("_", " ")
        # Import Loop
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            data_source = getattr(data_from, source)
            for name in data_source:
                if name not in data_list:
                    continue

                target = getattr(data_to, source)
                LOG.info(f"Blend format : Appending {source_string} : {name}")
                target.append(name)

    def get_node_dependencies(self, data, dep=[], local_data=[]):
        for n in data.nodes:
            node_tree = getattr(n, "node_tree", None)
            if node_tree is None:
                continue

            if node_tree in local_data:
                # n.node_tree = bpy.data.node_groups[node_tree.name]
                continue

            if node_tree.library is None:
                continue

            if node_tree in dep:
                continue

            dep.append(node_tree)

            new_dep = self.get_node_dependencies(node_tree, dep=[], local_data=local_data)

            for nd in new_dep:
                if nd in dep:
                    continue

                dep.append(nd)

        return dep

    def get_font_dependencies(self, data):
        if data.font.library is None:
            return False
        LOG.info(f'Blend format : Appending "{data.font.name}"')
        data.font.make_local()
        return True

    def make_local(self, to_append, dependencies, data):
        local_data = []
        if len(to_append["Object"]):
            override = {}
            override["selected_objects"] = to_append["Object"]
            # TODO : need to find an alternative to bpy.context.temp_override for blender 3.1 and bellow
            if BVERSION >= 3.2:
                with bpy.context.temp_override(**override):
                    bpy.ops.object.make_local(type="SELECT_OBDATA_MATERIAL")

                    for o in bpy.context.selected_objects:
                        if o.data is None:
                            continue

                        # Make Fonts Local
                        if o.data.rna_type.name == "Text Curve":
                            if not self.get_font_dependencies(o.data):
                                continue

                with bpy.context.temp_override(**override):
                    bpy.ops.object.make_local(type="SELECT_OBDATA_MATERIAL")
            else:
                bpy.ops.object.make_local(override, type="SELECT_OBDATA_MATERIAL")

                for o in bpy.context.selected_objects:
                    if o.data is None:
                        continue

                    # Make Fonts Local
                    if o.data.rna_type.name == "Text Curve":
                        if not self.get_font_dependencies(o.data):
                            continue

                bpy.ops.object.make_local(override, type="SELECT_OBDATA_MATERIAL")

        for d in dependencies:
            if d in local_data:
                continue
            d.make_local()
            local_data.append(d)

        for d in data:
            if d in local_data:
                continue
            d.make_local()

            local_data.append(d)
            LOG.info(f'Blend format : Appending "{d.name}"')

            # Make Fonts Local
            if d.rna_type.name == "Text Curve":
                if not self.get_font_dependencies(d):
                    continue

            if d.id_type in ["NODETREE"]:
                dep = self.get_node_dependencies(d, dep=[], local_data=local_data)
                while len(dep):
                    for dd in dep:
                        if dd in local_data:
                            continue

                        if dd.library is None:
                            continue

                        local_dd = dd.make_local()
                        local_data.append(dd)

                    dep = self.get_node_dependencies(d, dep=[], local_data=local_data)

    def prevent_name_collision(self, source):
        need_rename = {}
        # TODO : Fix for Blender 3.3.21 : file save with newer version
        with bpy.data.libraries.load(self.filepath, link=self.is_link) as (data_from, data_to):
            data_source = getattr(data_from, source)
            data_target = getattr(bpy.data, source)
            data_target = [d.name for d in data_target]
            for name in data_source:
                if name in data_target:
                    need_rename[name] = None

        for name in need_rename.keys():
            new_name = self.unique_name.get_unique_name(name)
            element = getattr(bpy.data, source)[name]
            need_rename[name] = element
            try:
                element.name = new_name
            except AttributeError as e:
                need_rename[name] = None
                print(e)

        return need_rename

    def revert_name_collision(self, source: str, duplicate_data_names: dict, import_data_names: list):
        data = getattr(bpy.data, source)

        for name in duplicate_data_names.keys():
            if duplicate_data_names[name] is None:
                continue
            new_name = self.unique_name.get_next_valid_name(name)
            data[name].name = new_name

            if name in import_data_names:
                i = import_data_names.index(name)
                import_data_names[i] = new_name
            duplicate_data_names[name].name = name

    def import_command(self, source):
        # The loader returns the exact imported IDs after leaving its context.
        # Never rename/search existing IDs by name: a same-name linked object
        # can otherwise be mistaken for the appended copy and made local.
        source_string = source.replace("_", " ")
        with bpy.data.libraries.load(self.filepath, link=self.is_link) as (data_from, data_to):
            names = list(getattr(data_from, source))
            setattr(data_to, source, names)
        imported = [item for item in getattr(data_to, source) if item is not None]
        if not imported:
            message = _ui_text(f"No {source_string} found in {self.filename}. Skipping ...", f'{self.filename} に {source_string} がありません。飛ばします…')
            LOG.warning("Blend format : " + message)
            LOG.store_warning(message)
            return
        for item in imported:
            LOG.info(f"Blend format : {self.operation} {source_string} : {item.name}")
            if source == "objects":
                if not any(existing == item for existing in self.current_collection.objects):
                    self.current_collection.objects.link(item)
            elif source == "collections":
                if not any(existing == item for existing in self.current_collection.children):
                    self.current_collection.children.link(item)
        if source == "objects":
            self.imported_objects = imported
        # link=False already appends local IDs and their dependencies. A second
        # object.make_local operation is both unnecessary and invalid in Edit
        # mode, and could localize pre-existing library users.
        self._library = None

    def import_data(self):
        if self.import_actions:
            self.import_command("actions")
        if self.import_armatures:
            self.import_command("armatures")
        if self.import_brushes:
            self.import_command("brushes")
        if self.import_cameras:
            self.import_command("cameras")
        if self.import_cache_files:
            self.import_command("cache_files")
        if self.import_curves:
            self.import_command("curves")
        if self.import_hair_curves:
            self.import_command("hair_curves")
        if self.import_fonts:
            self.import_command("fonts")
        if self.import_grease_pencils:
            self.import_command("grease_pencils")
            # self.import_command('grease_pencils_v3')
        if self.import_collections:
            self.import_command("collections")
        if self.import_images:
            self.import_command("images")
        if self.import_lights:
            self.import_command("lights")
        if self.import_linestyles:
            self.import_command("linestyles")
        if self.import_lattices:
            self.import_command("lattices")
        if self.import_masks:
            self.import_command("masks")
        if self.import_materials:
            self.import_command("materials")
        if self.import_metaballs:
            self.import_command("metaballs")
        if self.import_meshes:
            self.import_command("meshes")
        if self.import_movieclips:
            self.import_command("movieclips")
        if self.import_node_groups:
            self.import_command("node_groups")
        if self.import_objects:
            self.import_command("objects")
        if self.import_paint_curves:
            self.import_command("paint_curves")
        if self.import_particles:
            self.import_command("particles")
        if self.import_palettes:
            self.import_command("palettes")
        if self.import_pointclouds:
            self.import_command("pointclouds")
        if self.import_lightprobes:
            self.import_command("lightprobes")
        if self.import_scenes:
            self.import_command("scenes")
        # if self.import_shape_keys:
        #     self.import_command('shape_keys')
        if self.import_sounds:
            self.import_command("sounds")
        if self.import_speakers:
            self.import_command("speakers")
        if self.import_texts:
            self.import_command("texts")
        if self.import_textures:
            self.import_command("textures")
        if self.import_volumes:
            self.import_command("volumes")
        if self.import_worlds:
            self.import_command("worlds")
        if self.import_workspaces:
            self.import_command("workspaces")

        for o in self.imported_objects:
            o.select_set(True)

        self.importing = False

    def modal(self, context, event):
        bpy.ops.wm.redraw_timer(type="DRAW", iterations=1)
        if not self.import_started:
            self.import_started = True
            self.importing = True
            self.import_data()

        if not self.import_finished and not self.importing:
            if self.import_module == "APPEND" and self.library is not None and not self._library_was_present:
                bpy.ops.data.sfs_universal_multi_importer_remove_library(library_name=self.library.name)

            self.import_finished = True

            context.window_manager.event_timer_remove(self._timer)

            return {"FINISHED"}

        return {"RUNNING_MODAL"}

    def execute(self, context):
        self.current_collection = context.collection
        self.unique_name = UniqueName()
        self._import_datas = None
        self._local_names = None
        self._library = None
        self._library_was_present = self.filename in bpy.data.libraries
        self.import_started = False
        self.importing = False
        self.import_finished = False
        self.register_local_unique_names()
        self.imported_objects = []

        self.import_data()
        # 追加前からリンクされていたライブラリは、ユーザーのものなので消さない
        if self.import_module == "APPEND" and self.library is not None and not self._library_was_present:
            bpy.ops.data.sfs_universal_multi_importer_remove_library(library_name=self.library.name)

        return {"FINISHED"}

        # wm = context.window_manager
        # self._timer = wm.event_timer_add(0.01, window=context.window)
        # wm.modal_handler_add(self)
        # return {'RUNNING_MODAL'}


class SFS_OT_universal_multi_importer_remove_library(bpy.types.Operator):
    bl_idname = 'data.sfs_universal_multi_importer_remove_library'
    bl_label = 'Remove Library'
    bl_options = {'UNDO', 'INTERNAL'}
    bl_description = "Remove a library by name"

    library_name: bpy.props.StringProperty(name="Library Name", default="")

    def execute(self, context):
        bpy.data.libraries.remove(bpy.data.libraries[self.library_name])
        return {"FINISHED"}


classes = (IMPORT_SCENE_OT_universal_multi_importer_import_blend, SFS_OT_universal_multi_importer_remove_library)


def register():

    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)


if __name__ == "__main__":
    register()
