import bpy
import os
import math
from ...umi_const import (
    get_umi_settings,
    get_batcher_list_name,
    get_batcher_index_name,
    OPERTAOR_LIST,
    get_operator_boolean,
    DATATYPE_PREFIX,
    DATATYPE_PROPERTIES,
    DATATYPE_LIST,
    DATATYPE_PROPERTIES_DICT,
)
from ...operators.ui.const_operators import COMMAND_BATCHER_PRESET_FOLDER
from ...operators.command_batcher_const import COMMAND_BATCHER_ITEM_COUNT, COMMAND_BATCHER_VARIABLE
from ...bversion import BVERSION


datatype_col_count = math.ceil(len(DATATYPE_LIST) / 4)
batcher_item_col_count = math.ceil(COMMAND_BATCHER_ITEM_COUNT / 7)


def get_datatypes(self, context, edit_text):
    def get_enabled_datatypes():
        enabled = []
        for i, d in enumerate(DATATYPE_PROPERTIES):
            if getattr(self, d["property"]):
                enabled.append(d["name"])

        return enabled

    enabled = get_enabled_datatypes()
    return [d for d in DATATYPE_PROPERTIES_DICT.keys() if d not in enabled]


def update_add_datatype(self, context):
    if self.adding_datatype:
        self.adding_datatype = False
        return

    self.adding_datatype = True
    setattr(self, DATATYPE_PROPERTIES_DICT[self.add_datatype], True)
    self.add_datatype = ""
    self.adding_datatype = False


def operators(self, context, edit_text):
    return OPERTAOR_LIST


def draw_applies_to(self, layout):
    def get_enabled_datatypes_count():
        count = 0
        for i, d in enumerate(DATATYPE_PROPERTIES):
            if getattr(self, d["property"]):
                count += 1
        return count

    layout.use_property_split = True
    layout.use_property_decorate = False

    # Operator dialogs have no Panel runtime; UILayout.panel can crash.
    panel = layout.box()
    header = panel.row(align=True)
    header.label(text="Applies to :", icon="OPTIONS")

    if panel:
        # row = panel.row()
        # row.prop(self, 'add_datatype')
        row = panel.split(factor=0, align=True)
        row.alignment = "EXPAND"
        col = row.column(align=True)
        col.alignment = "LEFT"
        for i, d in enumerate(DATATYPE_PROPERTIES):
            if i % datatype_col_count == 0:
                col = row.column(align=True)
                col.alignment = "LEFT"

            # if not getattr(self, d['property']):
            #     continue

            # if d['property'] == "modifier_types" and not getattr(self, 'applies_to_modifiers') :
            #     continue

            if d["property"] == "applies_to_modifiers" and getattr(self, "applies_to_modifiers"):
                row1 = col.row(align=True)
                row1.alignment = "RIGHT"
                row1.label(text=d["name"])
                row1.label(text="", icon=d["icon"])
                row1.prop(self, f"{d['property']}", text="")
                continue

            if d["property"] == "modifier_type" and not getattr(self, "applies_to_modifiers"):
                continue

            elif d["property"] == "modifier_type":
                row1 = col.row(align=True)
                row1.alignment = "RIGHT"
                row1.label(text=d["name"] + " :")
                row1 = col.row(align=True)
                row1.alignment = "RIGHT"
                row1.prop(self, f"{d['property']}", text="")
                continue

            row1 = col.row(align=True)
            row1.alignment = "RIGHT"
            row1.label(text=d["name"])
            row1.label(text="", icon=d["icon"])
            row1.prop(self, f"{d['property']}", text="")

        col3 = row.column(align=True)
        col3.alignment = "RIGHT"
        col3.label(text="")


def read_applies_to(self, current_operator):
    for d in DATATYPE_PROPERTIES:
        exec(
            f"self.{d['property']} = current_operator.{d['property']}",
            {"self": self, "current_operator": current_operator},
        )


def set_applies_to(self, current_operator):
    for d in DATATYPE_PROPERTIES:
        exec(
            f"current_operator.{d['property']} = self.{d['property']}",
            {"self": self, "current_operator": current_operator},
        )


def set_applies_to_from_duplicate(self, current_operator, reference_operator):
    for d in DATATYPE_PROPERTIES:
        exec(
            f"current_operator.{d['property']} = reference_operator.{d['property']}",
            {"self": self, "current_operator": current_operator, "reference_operator": reference_operator},
        )


def draw_add_edit_operator(self, layout):
    col = layout.column()
    col.label(text="Command:")
    col.prop(self, "operator", text="")
    col.separator()

    col.use_property_split = True
    col.use_property_decorate = False

    # Operator dialogs have no Panel runtime; UILayout.panel can crash.
    panel = col.box()
    header = panel.row(align=True)
    header.label(text="Inject Variable :", icon="SORTALPHA")

    if panel:
        row = panel.row()
        row.alignment = "EXPAND"
        for i, c in enumerate(COMMAND_BATCHER_VARIABLE.values()):
            if i % batcher_item_col_count == 0:
                sub_col = row.column(align=True)

            sub_col.prop(self, f"{c['property']}", text="")

    draw_applies_to(self, col)


if not os.path.exists(COMMAND_BATCHER_PRESET_FOLDER):
    print(f"SFS_OT_universal_multi_importer_import_all : Creating Preset Folder : {COMMAND_BATCHER_PRESET_FOLDER}")
    os.makedirs(COMMAND_BATCHER_PRESET_FOLDER, exist_ok=True)


def get_operator(target_name, target_id_name):
    umi_settings = get_umi_settings()
    target = eval(f"umi_settings.{target_name}")
    idx = eval(f"umi_settings.{target_id_name}")
    operators = target

    active = operators[idx] if len(operators) else None

    return idx, operators, active


class SFS_OT_universal_multi_importer_move_operator(bpy.types.Operator):
    bl_idname = 'scene.sfs_universal_multi_importer_move_operator'
    bl_label = 'Move Operator'
    bl_options = {'UNDO'}
    bl_description = "Move Operator up or down.\nThis controls the position in the Menu."

    direction: bpy.props.EnumProperty(items=[("UP", "Up", ""), ("DOWN", "Down", "")])

    @classmethod
    def poll(cls, context):
        umi_settings = get_umi_settings()
        return eval(f"umi_settings.{get_batcher_list_name()}")

    def execute(self, context):
        umi_settings = get_umi_settings()

        idx, operator, _ = get_operator(get_batcher_list_name(), get_batcher_index_name())

        nextidx = 0

        if self.direction == "UP":
            nextidx = max(idx - 1, 0)
        elif self.direction == "DOWN":
            nextidx = min(idx + 1, len(operator) - 1)

        operator.move(idx, nextidx)
        exec(f"umi_settings.{get_batcher_index_name()} = nextidx")

        return {"FINISHED"}


class SFS_OT_universal_multi_importer_clear_all_operators(bpy.types.Operator):
    bl_idname = 'scene.sfs_universal_multi_importer_clear_all_operators'
    bl_label = 'Clear All Operators'
    bl_options = {'UNDO'}
    bl_description = "Clear All Operators."

    @classmethod
    def poll(cls, context):
        umi_settings = get_umi_settings()
        return eval(f"umi_settings.{get_batcher_list_name()}")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)

    def execute(self, context):
        self.umi_settings = get_umi_settings()
        target = eval(f"self.umi_settings.{get_batcher_list_name()}")
        target.clear()

        return {"FINISHED"}


class SFS_OT_universal_multi_importer_remove_selected_operator(bpy.types.Operator):
    bl_idname = 'scene.sfs_universal_multi_importer_remove_selected_operator'
    bl_label = 'Remove Selected Operator'
    bl_options = {'UNDO'}
    bl_description = "Remove selected Operator."

    id: bpy.props.IntProperty(name="Operator ID", default=0)

    @classmethod
    def poll(cls, context):
        umi_settings = get_umi_settings()
        return eval(f"umi_settings.{get_batcher_list_name()}")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)

    def execute(self, context):
        umi_settings = get_umi_settings()

        self.umi_settings = get_umi_settings()
        target = eval(f"self.umi_settings.{get_batcher_list_name()}")

        target.remove(self.id)

        umi_settings.umi_operator_idx = min(self.id, len(target) - 1)

        return {"FINISHED"}


class SFS_OT_universal_multi_importer_duplicate_selected_operator(bpy.types.Operator):
    bl_idname = 'scene.sfs_umi_duplicate_operator'
    bl_label = 'Duplicate Selected Operator'
    bl_options = {'UNDO'}
    bl_description = "Duplicate selected Operator."

    id: bpy.props.IntProperty(name="Operator ID", default=0)

    @classmethod
    def poll(cls, context):
        umi_settings = get_umi_settings()
        return eval(f"umi_settings.{get_batcher_list_name()}")

    def execute(self, context):
        self.umi_settings = get_umi_settings()
        target = eval(f"self.umi_settings.{get_batcher_list_name()}")
        o = target.add()
        o.enabled = target[self.id].enabled
        o.operator = target[self.id].operator
        set_applies_to_from_duplicate(self, o, target[self.id])
        target.move(len(target) - 1, self.id + 1)

        return {"FINISHED"}


class SFS_OT_universal_multi_importer_edit_operator(bpy.types.Operator):
    bl_idname = 'scene.sfs_universal_multi_importer_edit_operator'
    bl_label = 'Edit Operator'
    bl_options = {'UNDO'}
    bl_description = "Edit current operator"

    id: bpy.props.IntProperty(name="Operator ID", default=0)
    operator: bpy.props.StringProperty(name="Operator Command", default="", search=operators)

    def draw(self, context):
        draw_add_edit_operator(self, self.layout)

    def invoke(self, context, event):
        self.umi_settings = get_umi_settings()

        target = eval(f"self.umi_settings.{get_batcher_list_name()}")

        if not 0 <= self.id < len(target):
            self.report({'WARNING'}, "The operator row no longer exists")
            return {'CANCELLED'}
        current_operator = target[self.id]

        self.operator = current_operator.operator

        read_applies_to(self, current_operator)

        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=int(self.umi_settings.umi_window_width * 0.8))

    def execute(self, context):
        self.umi_settings = get_umi_settings()
        target = eval(f"self.umi_settings.{get_batcher_list_name()}")
        if not 0 <= self.id < len(target):
            self.report({'WARNING'}, "The operator row no longer exists")
            return {'CANCELLED'}
        o = target[self.id]
        o.operator = self.operator
        o.modifier_type = self.modifier_type
        set_applies_to(self, o)
        return {"FINISHED"}


class SFS_OT_universal_multi_importer_add_operator(bpy.types.Operator):
    bl_idname = 'scene.sfs_universal_multi_importer_add_operator'
    bl_label = 'Add Operator'
    bl_options = {'UNDO'}
    bl_description = "Add a new operator"

    operator: bpy.props.StringProperty(name="Operator Command", default="", search=operators)

    def draw(self, context):
        draw_add_edit_operator(self, self.layout)

    def invoke(self, context, event):
        self.umi_settings = get_umi_settings()
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=int(self.umi_settings.umi_window_width * 0.8))

    def execute(self, context):
        self.umi_settings = get_umi_settings()
        target = eval(f"self.umi_settings.{get_batcher_list_name()}")
        o = target.add()
        o.operator = self.operator
        o.modifier_type = self.modifier_type
        set_applies_to(self, o)
        return {"FINISHED"}


classes = (
    SFS_OT_universal_multi_importer_move_operator,
    SFS_OT_universal_multi_importer_clear_all_operators,
    SFS_OT_universal_multi_importer_remove_selected_operator,
    SFS_OT_universal_multi_importer_duplicate_selected_operator,
)

datatype_classes = (
    SFS_OT_universal_multi_importer_edit_operator,
    SFS_OT_universal_multi_importer_add_operator,
)


def register():
    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)
    for cls in datatype_classes:
        annotations = getattr(cls, "__annotations__", None)
        if annotations is None:
            annotations = {}
            cls.__annotations__ = annotations
        annotations["add_datatype"] = bpy.props.StringProperty(
            name="Add Datatype", search=get_datatypes, update=update_add_datatype
        )
        annotations["adding_datatype"] = bpy.props.BoolProperty(name="Adding Datatype", default=False)

    from ... import class_property_injection

    class_property_injection.register(datatype_classes, DATATYPE_PROPERTIES + tuple(COMMAND_BATCHER_VARIABLE.values()))
    for cls in datatype_classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class

    for cls in reversed(datatype_classes):
        unregister_class(cls)

    from ... import class_property_injection

    class_property_injection.unregister(
        datatype_classes, DATATYPE_PROPERTIES + tuple(COMMAND_BATCHER_VARIABLE.values())
    )

    for cls in reversed(classes):
        unregister_class(cls)


if __name__ == "__main__":
    register()
