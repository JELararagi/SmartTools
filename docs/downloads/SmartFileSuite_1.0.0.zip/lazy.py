# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

# Legacy lazy Smart File launcher retired.
# Smart File now registers its 3D View Sidebar N-panel directly from __init__.py.


def register() -> None:
    return None


def unregister() -> None:
    return None


def ensure_runtime_initialized(*_args, **_kwargs) -> bool:
    return False
