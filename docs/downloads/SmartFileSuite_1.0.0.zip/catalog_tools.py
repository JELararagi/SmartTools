from .ui_language_runtime import error_text as _sf_error_text
# -----------------------------------------------------------------------------
#  Catalog merge helpers (Phase 3.3)
# -----------------------------------------------------------------------------

_CATALOG_MERGE_MEM = {"key": None, "merged": None}

def _ar_find_catalog_files(root_dir: str, filename: str, max_depth: int = 4, limit: int = 200) -> list[str]:
    root_dir = _norm_path(root_dir)
    if not root_dir or not os.path.isdir(root_dir):
        return []
    out = []
    try:
        base_depth = root_dir.rstrip(os.sep).count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root_dir):
            # depth limit
            cur_depth = dirpath.rstrip(os.sep).count(os.sep) - base_depth
            if cur_depth >= max_depth:
                dirnames[:] = []
            if filename in filenames:
                out.append(_norm_path(os.path.join(dirpath, filename)))
                if len(out) >= limit:
                    break
    except Exception:
        return out
    return out



def _ar_collect_catalog_files(context) -> list[tuple[str,int]]:
    'Collect catalog.json files under enabled roots.\n\n    Returns list of (catalog_path, root_rank) where smaller rank means higher priority.\n    Rank is derived from root.priority (higher priority => smaller rank) and root list order.'
    prefs = _addon_prefs(context)
    wm = context.window_manager
    filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'

    roots = []
    if prefs:
        for idx, r in enumerate(getattr(prefs, 'library_roots', []) or []):
            if getattr(r, 'enabled', True):
                p = _norm_path(getattr(r, 'path', '') or '')
                if p and os.path.isdir(p):
                    pr = int(getattr(r, 'priority', 0) or 0)
                    # higher priority should win -> smaller rank
                    rank = (-pr, idx)
                    roots.append((p, rank))

    out = []
    seen = set()
    # preserve order by roots and discovery order
    for rt, rank in roots:
        for fp in _ar_find_catalog_files(rt, filename, max_depth=5, limit=300):
            fp = _norm_path(fp)
            if fp and fp not in seen:
                out.append((fp, rank[0]*1000 + rank[1]))
                seen.add(fp)

    # explicit file (lowest priority)
    explicit = _norm_path(getattr(wm, 'sf_ar_catalog_file', '') or '')
    if explicit and os.path.exists(explicit) and explicit not in seen:
        out.append((explicit, 10**9))
    return out




def _ar_get_merged_catalog(context, force: bool = False) -> dict:
    'Return merged catalog data across roots.\n\n    Merges multiple catalog.json files and computes:\n    - assets: {group_key: [entry, ...]} where group_key is asset_id if available else asset name\n    - latest_by_asset: {group_key: (entry, version)}\n    - path_to_latest: {blend_abs: {asset_key, asset_id, current_ver, latest_ver, latest_path}}\n    - key_to_display: {group_key: display_name}'
    global _CATALOG_MERGE_MEM
    files = _ar_collect_catalog_files(context)  # [(path, rank), ...]
    key = []
    for fp, rk in files:
        try:
            key.append((fp, int(os.stat(fp).st_mtime), int(rk)))
        except Exception:
            key.append((fp, 0, int(rk)))
    key = tuple(key)
    if (not force) and _CATALOG_MERGE_MEM.get('key') == key and _CATALOG_MERGE_MEM.get('merged'):
        return _CATALOG_MERGE_MEM['merged']

    prefs = _addon_prefs(context)
    priority_mode = getattr(prefs, 'cat_merge_priority_mode', 'ROOT_PRIORITY') if prefs else 'ROOT_PRIORITY'

    overrides = {}
    try:
        overrides = json.loads(getattr(prefs, 'cat_conflict_overrides_json', '{}') or '{}') if prefs else {}
    except Exception:
        overrides = {}
    if not isinstance(overrides, dict):
        overrides = {}

    merged_assets: dict[str, list] = {}
    key_to_display: dict[str, str] = {}
    path_to_latest: dict[str, dict] = {}

    # ingest
    for cat_fp, root_rank in files:
        cat = _ar_load_catalog(cat_fp)
        assets = (cat.get('assets') or {}) if isinstance(cat, dict) else {}
        base_dir = os.path.dirname(_norm_path(cat_fp))
        for asset_key, data in (assets or {}).items():
            if not isinstance(data, dict):
                continue
            asset_id = (data.get('asset_id') or '').strip()
            group_key = asset_id or str(asset_key)
            if group_key not in merged_assets:
                merged_assets[group_key] = []
            if group_key not in key_to_display:
                key_to_display[group_key] = str(asset_key)

            try:
                entries = list((data or {}).get('entries', []) or [])
            except Exception:
                entries = []
            for e in entries:
                try:
                    ver = int(e.get('version', 0) or 0)
                except Exception:
                    ver = 0
                blend_rel = e.get('blend', '') or ''
                prev_rel = e.get('preview', '') or ''
                ent = dict(e)
                ent['catalog_path'] = _norm_path(cat_fp)
                ent['root_rank'] = int(root_rank)
                ent['asset'] = str(asset_key)
                ent['asset_id'] = asset_id
                ent['blend_abs'] = _norm_path(os.path.join(base_dir, blend_rel)) if blend_rel else ''
                ent['preview_abs'] = _norm_path(os.path.join(base_dir, prev_rel)) if prev_rel else ''
                ent['version'] = ver
                merged_assets[group_key].append(ent)

    # choose latest per group
    latest_by_asset: dict[str, tuple] = {}
    for group_key, entries in merged_assets.items():
        if not entries:
            continue


        # Apply per-asset override: if user chose a preferred catalog source for this asset,
        # restrict selection to entries from that catalog.
        prefer_cat = ""
        try:
            prefer_cat = _norm_path((overrides or {}).get(group_key, "") or "")
        except Exception:
            prefer_cat = ""
        if prefer_cat:
            try:
                filtered = [e for e in entries if _norm_path(e.get("catalog_path", "") or "") == prefer_cat]
                if filtered:
                    entries = filtered
            except Exception:
                pass

        def _score(ent):
            v = int(ent.get('version', 0) or 0)
            rk = int(ent.get('root_rank', 10**9) or 10**9)
            # smaller rk = higher priority
            if priority_mode == 'HIGHEST_VERSION':
                return (v, ent.get('published_at',''))
            # ROOT_PRIORITY: rank first, then version
            return (-rk, v, ent.get('published_at',''))

        try:
            # Pick by score (max)
            latest_ent = max(entries, key=_score)
        except Exception:
            latest_ent = entries[-1]
        latest_ver = int(latest_ent.get('version', 0) or 0)
        latest_by_asset[group_key] = (latest_ent, latest_ver)

        latest_path = latest_ent.get('blend_abs', '') or ''
        for e in entries:
            p = e.get('blend_abs', '') or ''
            if not p:
                continue
            path_to_latest[_norm_path(p)] = {
                "asset": e.get("asset", key_to_display.get(group_key, group_key)),
                "asset_id": e.get("asset_id", "") or "",
                "group_key": group_key,
                "current_ver": int(e.get('version', 0) or 0),
                "latest_ver": int(latest_ver or 0),
                "latest_path": _norm_path(latest_path),
            }


    # Convenience mapping: asset_id -> (latest_entry, latest_ver)
    latest_by_asset_id = {}
    try:
        for _gk, (_ent, _ver) in (latest_by_asset or {}).items():
            if not _ent:
                continue
            _aid = str((_ent.get('asset_id') or '')).strip()
            if _aid:
                latest_by_asset_id[_aid] = (_ent, int(_ver or 0))
    except Exception:
        latest_by_asset_id = {}

    merged = {
        "files": [fp for fp, _rk in files],
        "assets": merged_assets,
        "latest_by_asset": latest_by_asset,
        "latest_by_asset_id": latest_by_asset_id,
        "path_to_latest": path_to_latest,
        "key_to_display": key_to_display,
        "priority_mode": priority_mode,
    }
    _CATALOG_MERGE_MEM = {"key": key, "merged": merged}
    return merged




def _ar_guess_asset_from_filename(blend_fp: str) -> str:
    stem = os.path.splitext(os.path.basename(blend_fp))[0]
    m = re.match(r"^(.*)_v\d+$", stem, re.IGNORECASE)
    return (m.group(1) if m else stem).strip()


def _ar_join_catalog_relative(catalog_path: str, rel: str) -> str:
    if not rel:
        return ''
    base = os.path.dirname(_norm_path(catalog_path))
    return _norm_path(os.path.join(base, rel))


def _ar_refresh_catalog_assets(context):
    wm = context.window_manager
    wm.sf_ar_cat_assets.clear()
    wm.sf_ar_cat_versions.clear()
    wm.sf_ar_cat_raw_json = ''

    use_merge = bool(getattr(wm, 'sf_ar_cat_merge_roots', False))

    # categories list
    cats = set()

    if use_merge:
        merged = _ar_get_merged_catalog(context, force=True)
        prefs = _addon_prefs(context)
        overrides = {}
        try:
            overrides = json.loads(getattr(prefs, 'cat_conflict_overrides_json', '{}') or '{}') if prefs else {}
        except Exception:
            overrides = {}
        if not isinstance(overrides, dict):
            overrides = {}
        assets_map = merged.get('assets', {}) or {}
        latest_by = merged.get('latest_by_asset', {}) or {}

        for asset_key, entries in assets_map.items():
            latest_ent, latest_ver = latest_by.get(asset_key, (None, 0))
            if not latest_ent:
                continue

            category = latest_ent.get('category', '') or ''
            tags = latest_ent.get('tags', []) or []
            if isinstance(tags, str):
                tags = [tags]
            if category:
                cats.add(category)

            # Build entries payload (absolute paths)
            entries_payload = []
            try:
                for e in entries:
                    v = int(e.get('version', 0) or 0)
                    vs = e.get('version_str', '') or f"v{v:03d}"
                    entries_payload.append({
                        "version": v,
                        "version_str": vs,
                        "blend_abs": e.get('blend_abs', '') or '',
                        "preview_abs": e.get('preview_abs', '') or '',
                        "published_at": e.get('published_at', '') or '',
                        "category": e.get('category', '') or '',
                        "tags": e.get('tags', []) or [],
                        "catalog_path": e.get('catalog_path', '') or '',
                    })
            except Exception:
                entries_payload = []

            it = wm.sf_ar_cat_assets.add()
            it.asset = (merged.get("key_to_display", {}) or {}).get(asset_key, latest_ent.get("asset", asset_key) if latest_ent else asset_key)
            it.group_key = str(asset_key)
            it.asset_id = (latest_ent.get("asset_id","") if latest_ent else "")
            it.category = category
            it.tags = ','.join([t for t in tags if t]) if isinstance(tags, list) else (tags or '')
            it.latest_version = int(latest_ver or 0)
            it.catalog_path = latest_ent.get('catalog_path', '') or ''
            it.latest_blend = _norm_path(latest_ent.get('blend_abs', '') or '')
            it.latest_preview = _norm_path(latest_ent.get('preview_abs', '') or '')
            # conflict candidates across sources
            try:
                cand = sorted({ _norm_path((e.get('catalog_path','') or '')) for e in entries_payload if (e.get('catalog_path','') or '') })
            except Exception:
                cand = []
            it.conflict = bool(len(cand) > 1)
            try:
                it.candidates_json = json.dumps(cand, ensure_ascii=False)
            except Exception:
                it.candidates_json = '[]'
            it.preferred_catalog = _norm_path((overrides or {}).get(str(asset_key), '') or '')
            try:
                it.entries_json = json.dumps(entries_payload, ensure_ascii=False)
            except Exception:
                it.entries_json = '[]'

        wm.sf_ar_cat_categories_json = json.dumps(sorted(cats), ensure_ascii=False)
        _ar_apply_catalog_filters(context)
        return

    # Single catalog file mode
    cat_path = _norm_path(getattr(wm, 'sf_ar_catalog_file', '') or '')
    cat = _ar_load_catalog(cat_path)
    assets = (cat.get('assets') or {}) if isinstance(cat, dict) else {}

    for asset_key, data in assets.items():
        try:
            latest = int((data or {}).get('latest', 0) or 0)
            entries = list((data or {}).get('entries', []) or [])
        except Exception:
            latest = 0
            entries = []

        # Pick latest entry (by version)
        latest_entry = None
        for e in entries:
            try:
                if int(e.get('version', 0) or 0) == latest:
                    latest_entry = e
            except Exception:
                pass
        if latest_entry is None and entries:
            latest_entry = entries[-1]
            try:
                latest = int(latest_entry.get('version', 0) or 0)
            except Exception:
                latest = 0

        category = ''
        tags = []
        blend_rel = ''
        prev_rel = ''
        if latest_entry:
            category = latest_entry.get('category', '') or ''
            tags = latest_entry.get('tags', []) or []
            blend_rel = latest_entry.get('blend', '') or ''
            prev_rel = latest_entry.get('preview', '') or ''

        if category:
            cats.add(category)

        it = wm.sf_ar_cat_assets.add()
        it.asset = asset_key
        it.category = category
        it.tags = ','.join([t for t in tags if t]) if isinstance(tags, list) else (tags or '')
        it.latest_version = int(latest or 0)
        it.catalog_path = cat_path
        it.latest_blend = _ar_join_catalog_relative(cat_path, blend_rel)
        it.latest_preview = _ar_join_catalog_relative(cat_path, prev_rel)
        try:
            it.entries_json = json.dumps(entries, ensure_ascii=False)
        except Exception:
            it.entries_json = '[]'

    wm.sf_ar_cat_categories_json = json.dumps(sorted(cats), ensure_ascii=False)
    _ar_apply_catalog_filters(context)


def _ar_parse_tag_tokens(text: str) -> list[str]:
    text = (text or '').strip()
    if not text:
        return []
    # allow comma or space separated tokens
    parts = re.split(r"[\s,]+", text)
    out = []
    for p in parts:
        p = (p or '').strip()
        if not p:
            continue
        out.append(p)
    return out


def _ar_apply_catalog_filters(context):
    wm = context.window_manager
    # Keep a copy and re-filter in-place: easiest is to rebuild from loaded catalog again.
    # For simplicity, we store the unfiltered list in JSON (sf_ar_cat_raw_json).
    raw_json = getattr(wm, 'sf_ar_cat_raw_json', '') or ''
    if not raw_json:
        # create raw snapshot
        raw = []
        for it in wm.sf_ar_cat_assets:
            raw.append({
                'asset': it.asset,
                'group_key': it.group_key,
                'asset_id': it.asset_id,
                'conflict': it.conflict,
                'candidates_json': it.candidates_json,
                'preferred_catalog': it.preferred_catalog,
                'category': it.category,
                'tags': it.tags,
                'latest_version': it.latest_version,
                'latest_blend': it.latest_blend,
                'latest_preview': it.latest_preview,
                'catalog_path': it.catalog_path,
                'entries_json': it.entries_json,
            })
        try:
            wm.sf_ar_cat_raw_json = json.dumps(raw, ensure_ascii=False)
        except Exception:
            wm.sf_ar_cat_raw_json = ''
        raw_json = wm.sf_ar_cat_raw_json

    try:
        raw = json.loads(raw_json)
    except Exception:
        raw = []

    cat_filter = _ar_category_value_from_enum(wm, getattr(wm, 'sf_ar_cat_category', 'ALL') or 'ALL')
    tag_tokens = _ar_parse_tag_tokens(getattr(wm, 'sf_ar_cat_tag_filter', '') or '')
    tag_tokens_lower = [t.lower() for t in tag_tokens]
    search = (getattr(wm, 'sf_ar_search', '') or '').strip().lower()  # reuse search box

    wm.sf_ar_cat_assets.clear()
    for r in raw:
        if cat_filter != 'ALL' and (r.get('category') or '') != cat_filter:
            continue
        if tag_tokens_lower:
            tags_str = (r.get('tags') or '')
            tags_lower = tags_str.lower()
            # normalize to set
            tags_set = {t.strip().lower() for t in tags_str.split(',') if t.strip()}
            ok = True
            for tok in tag_tokens_lower:
                if tok in tags_set:
                    continue
                # allow partial match fallback
                if tok and tok not in tags_lower:
                    ok = False
                    break
            if not ok:
                continue
        if search:
            if search not in (r.get('asset') or '').lower() and search not in (r.get('category') or '').lower() and search not in (r.get('tags') or '').lower():
                continue
        it = wm.sf_ar_cat_assets.add()
        it.asset = r.get('asset', '')
        it.group_key = r.get('group_key', '')
        it.asset_id = r.get('asset_id', '')
        it.conflict = r.get('conflict', False)
        it.candidates_json = r.get('candidates_json', '[]')
        it.preferred_catalog = r.get('preferred_catalog', '')
        it.category = r.get('category', '')
        it.tags = r.get('tags', '')
        it.latest_version = int(r.get('latest_version', 0) or 0)
        it.latest_blend = r.get('latest_blend', '')
        it.latest_preview = r.get('latest_preview', '')
        it.catalog_path = r.get('catalog_path', '')
        it.entries_json = r.get('entries_json', '[]')

    # Tag cloud (for quick filter buttons)
    counts = {}
    try:
        for it in wm.sf_ar_cat_assets:
            for t in (it.tags or '').split(','):
                t = (t or '').strip()
                if not t:
                    continue
                counts[t] = counts.get(t, 0) + 1
    except Exception:
        counts = {}
    cloud = [{"tag": k, "count": v} for k, v in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0].lower()))]
    try:
        wm.sf_ar_cat_tag_cloud_json = json.dumps(cloud, ensure_ascii=False)
    except Exception:
        wm.sf_ar_cat_tag_cloud_json = '[]'
    _prime_thumb_previews(
        getattr(item, 'latest_preview', '')
        for item in tuple(wm.sf_ar_cat_assets)
        if getattr(item, 'latest_preview', '')
    )


def _ar_build_versions_for_active(context):
    wm = context.window_manager
    wm.sf_ar_cat_versions.clear()
    if not (0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets)):
        return
    a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
    cat_path = _norm_path(a.catalog_path)
    try:
        entries = json.loads(a.entries_json or '[]')
    except Exception:
        entries = []
    # sort desc by version
    try:
        entries = sorted(entries, key=lambda e: int(e.get('version', 0) or 0), reverse=True)
    except Exception:
        pass

    for e in entries[:200]:
        it = wm.sf_ar_cat_versions.add()
        try:
            it.version = int(e.get('version', 0) or 0)
        except Exception:
            it.version = 0
        it.version_str = e.get('version_str', '') or f"v{it.version:03d}"
        blend_abs = e.get('blend_abs', '') or ''
        prev_abs = e.get('preview_abs', '') or ''
        if blend_abs:
            it.blend = _norm_path(blend_abs)
        else:
            it.blend = _ar_join_catalog_relative(cat_path, e.get('blend', '') or '')
        if prev_abs:
            it.preview = _norm_path(prev_abs)
        else:
            it.preview = _ar_join_catalog_relative(cat_path, e.get('preview', '') or '')
        it.published_at = e.get('published_at', '') or ''
    _prime_thumb_previews(
        getattr(item, 'preview', '')
        for item in tuple(wm.sf_ar_cat_versions)
        if getattr(item, 'preview', '')
    )


def _ar_draw_catalog_ui(op, context, layout):
    wm = context.window_manager
    prefs = _addon_prefs(context)

    # Catalog controls
    top = layout.row(align=True)
    top.prop(wm, 'sf_ar_cat_merge_roots', text=_t('Merge Roots'))
    catrow = top.row(align=True)
    catrow.enabled = not getattr(wm, 'sf_ar_cat_merge_roots', False)
    catrow.prop(wm, 'sf_ar_catalog_file', text=_t('Catalog File'))
    top.operator('import_scene.sfs_asset_reader_auto_detect_catalog', text=_t('Auto Detect Catalog'), icon='VIEWZOOM')
    top.operator('import_scene.sfs_asset_reader_reload_catalog', text=_t('Reload Catalog'), icon='FILE_REFRESH')

    # Batch previews for the catalog folder
    cat_dir = ''
    try:
        if getattr(wm, 'sf_ar_catalog_file', '') and not getattr(wm, 'sf_ar_cat_merge_roots', False):
            cat_dir = os.path.dirname(_norm_path(getattr(wm, 'sf_ar_catalog_file', '') or ''))
        else:
            # Prefer first enabled library root
            if prefs:
                for r in getattr(prefs, 'library_roots', []) or []:
                    if getattr(r, 'enabled', True):
                        p = _norm_path(getattr(r, 'path', '') or '')
                        if p and os.path.isdir(p):
                            cat_dir = p
                            break
            if not cat_dir:
                cat_dir = os.path.dirname(_norm_path(getattr(wm, 'sf_ar_catalog_file', '') or ''))
    except Exception:
        cat_dir = os.path.dirname(_norm_path(getattr(wm, 'sf_ar_catalog_file', '') or ''))

    bp = top.operator('export_scene.sfs_asset_preview_batch_preview', text=_t('Batch Preview'), icon='RENDER_STILL')
    try:
        bp.target_dir = cat_dir
        bp.catalog_filename = os.path.basename(getattr(prefs, 'pub_catalog_filename', 'catalog.json')) if prefs else 'catalog.json'
    except Exception:
        pass

    filt = layout.row(align=True)
    filt.prop(wm, 'sf_ar_cat_category', text=_t('Category'))
    filt.prop(wm, 'sf_ar_cat_tag_filter', text=_t('Tags'))
    filt.prop(wm, 'sf_ar_search', text=_t('Search'))
    filt.operator('import_scene.sfs_asset_reader_apply_catalog_filters', text=_t('Apply Catalog Filters'), icon='FILE_REFRESH')

    # Quick tag buttons
    try:
        cloud = json.loads(getattr(wm, 'sf_ar_cat_tag_cloud_json', '[]') or '[]')
    except Exception:
        cloud = []
    if cloud:
        tag_box = layout.box()
        tag_box.label(text=_t('Tag Quick Filter'), icon='TAG')
        flow = tag_box.grid_flow(columns=6, even_columns=True, even_rows=False, align=True)
        # active tags
        active_tokens = _ar_parse_tag_tokens(getattr(wm, 'sf_ar_cat_tag_filter', '') or '')
        active_lower = {t.lower() for t in active_tokens}
        for item in cloud[:24]:
            try:
                tg = str(item.get('tag', '') or '').strip()
                cnt = int(item.get('count', 0) or 0)
            except Exception:
                tg, cnt = '', 0
            if not tg:
                continue
            btn_text = f"{tg} ({cnt})" if cnt else tg
            flow.operator('import_scene.sfs_asset_reader_toggle_tag', text=btn_text, icon='TAG', depress=(tg.lower() in active_lower)).tag = tg
        _sf_draw_action_block(
            tag_box,
            danger_actions=[
                ('import_scene.sfs_asset_reader_clear_tags', 'Clear Tags', 'TRASH', {}),
            ],
        )

    split = layout.split(factor=0.62)
    left = split.column()
    right = split.column()

    _sf_draw_section_intro(left.box(), 'Catalog Assets', 'Choose an asset group first, then inspect details and versions on the right.', 'ASSET_MANAGER')
    if len(wm.sf_ar_cat_assets):
        left.template_list('SF_UL_asset_library_asset_library_catalog_asset_list', '', wm, 'sf_ar_cat_assets', wm, 'sf_ar_cat_active_index', rows=16)
    else:
        _sf_draw_empty_state(left, 'No catalog assets found', 'Reload the catalog, enable Merge Roots, or adjust category and tag filters to show published assets.', 'NONE')

    row = left.row(align=True)
    row.operator('import_scene.sfs_asset_reader_import_latest', text=_t('Import Latest'), icon='IMPORT')
    row.operator('import_scene.sfs_asset_reader_open_folder', text=_t('Open Folder'), icon='FOLDER_REDIRECT')

    # Details / versions
    box = right.box()
    _sf_draw_section_intro(box, 'Details', 'Review the selected asset before you import the latest version or open its source folder.', 'NONE')
    if not (0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets)):
        if len(wm.sf_ar_cat_assets) == 0:
            _sf_draw_empty_state(box, 'No catalog assets found', 'Reload the catalog, enable Merge Roots, or adjust category and tag filters to show published assets.', 'NONE')
        else:
            _sf_draw_empty_state(box, 'No asset selected', 'Choose one asset from the list on the left to see metadata, versions, and import actions.', 'NONE')
    else:
        a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
        box.label(text=_t('Asset Summary'), icon='ASSET_MANAGER')
        box.label(text=f"{_t('Name')}: {a.asset}")
        if a.category:
            box.label(text=f"{_t('Category')}: {a.category}")
        if a.tags:
            box.label(text=f"{_t('Tags')}: {a.tags}")
        box.label(text=f"{_t('Latest')}: v{a.latest_version:03d}" if a.latest_version else _t('Latest'))
        if a.latest_blend:
            box.prop(a, 'latest_blend', text=_t('File'))
        # Conflict resolution (multiple sources for same asset)
        if getattr(a, "conflict", False):
            cbox = right.box()
            cbox.label(text=_t('Conflict'), icon='ERROR')
            if getattr(a, "preferred_catalog", ""):
                cbox.label(text=_t('Preferred Source') + ':' + os.path.basename(_norm_path(a.preferred_catalog)))
            cbox.prop(wm, "sf_ar_cat_pref_source", text=_t('Preferred Source'))
            _sf_draw_action_block(
                cbox,
                primary_actions=[
                    ("import_scene.sfs_asset_reader_set_preferred_source", "Set Preferred Source", 'CHECKMARK', {}),
                ],
                danger_actions=[
                    ("import_scene.sfs_asset_reader_clear_preferred_source", "Clear Preferred Source", 'TRASH', {}),
                ],
            )

    vbox = right.box()
    _sf_draw_section_intro(vbox, 'Versions', 'Use this list when you need something older than the latest published version.', 'FILE_TICK')
    vrow = vbox.row(align=True)
    vrow.operator('import_scene.sfs_asset_reader_build_versions', text=_t('Build Versions'), icon='FILE_REFRESH')
    vrow.operator('import_scene.sfs_asset_reader_import_version', text=_t('Import Version'), icon='IMPORT')
    if len(wm.sf_ar_cat_versions):
        vbox.template_list('SF_UL_asset_library_asset_library_catalog_version_list', '', wm, 'sf_ar_cat_versions', wm, 'sf_ar_cat_ver_active_index', rows=6)
    else:
        _sf_draw_empty_state(vbox, 'No versions loaded yet', 'Build the version list after selecting an asset to compare published revisions here.', 'NONE')

    # Import options
    opt = right.box()
    opt.label(text=_t('Import Options'), icon='APPEND_BLEND')
    opt.prop(wm, 'sf_import_mode')
    opt.prop(wm, 'sf_strict_loader')
    opt.prop(wm, 'sf_put_in_collection')
    if wm.sf_put_in_collection:
        opt.prop(wm, 'sf_collection_name_mode')
        if wm.sf_collection_name_mode == 'CUSTOM':
            opt.prop(wm, 'sf_collection_name')
    opt.prop(wm, 'sf_prefix')
    opt.prop(wm, 'sf_collision')
    opt.label(text=_t('Placement'), icon='PIVOT_CURSOR')
    opt.prop(wm, 'sf_placement')
    opt.prop(wm, 'sf_offset')
    sub = opt.column(align=True)
    sub.enabled = (wm.sf_placement == 'GRID')
    sub.prop(wm, 'sf_grid_spacing')
    sub.prop(wm, 'sf_grid_columns')

    after = right.box()
    after.label(text=_t('After Import'), icon='RESTRICT_SELECT_OFF')
    after.prop(wm, 'sf_select_imported')
    after.prop(wm, 'sf_frame_view')


# ----------------------------
#  Operators: Asset Reader
# ----------------------------

class SF_OT_asset_reader_open(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_open'
    bl_label = 'Open'
    bl_description = 'Inspect indexed .blend libraries, review risks and dependencies, and import checked assets with Smart File options'
    bl_options = {'UNDO'}

    def invoke(self, context, _event):
        # initial refresh
        _ar_refresh_items(context)
        # auto-load catalog if set
        try:
            wm = context.window_manager
            if getattr(wm, 'sf_ar_view_mode', 'INDEX') == 'CATALOG' and (getattr(wm, 'sf_ar_catalog_file', '') or getattr(wm, 'sf_ar_cat_merge_roots', False)):
                bpy.ops.import_scene.sfs_asset_reader_reload_catalog('EXEC_DEFAULT')
        except Exception:
            pass
        wm = context.window_manager
        if not getattr(wm, "sf_ar_dep_summary", ""):
            wm.sf_ar_dep_summary = ""
        if not getattr(wm, "sf_ar_dep_tree", ""):
            wm.sf_ar_dep_tree = ""
        return context.window_manager.invoke_props_dialog(self, width=920)

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        row = layout.row(align=True)
        row.prop(wm, 'sf_ar_view_mode', expand=True)
        if getattr(wm, 'sf_ar_view_mode', 'INDEX') == 'CATALOG':
            _ar_draw_catalog_ui(self, context, layout)
            return

        tools = layout.row(align=True)
        tools.operator("import_scene.sfs_asset_library_rebuild_index", text=_t('Rebuild Index'), icon='FILE_REFRESH')
        tools.operator("import_scene.sfs_asset_reader_refresh", text=_t('Refresh'), icon='FILE_REFRESH')
        tools.operator("import_scene.sfs_asset_reader_analyze_file", text=_t('Analyze File'), icon='VIEWZOOM')
        tools.operator("import_scene.sfs_asset_reader_analyze_selection", text=_t('Analyze Selection'), icon='CONSTRAINT')
        tools.operator("import_scene.sfs_asset_reader_generate_thumbnails", text=_t('Generate Thumbnails'), icon='RENDER_STILL')

        filt = layout.row(align=True)
        filt.prop(wm, 'sf_ar_root_filter', text='Roots')
        filt.prop(wm, 'sf_ar_type_filter', text='Type')
        filt.prop(wm, 'sf_ar_search', text='Search')
        filt.prop(wm, 'sf_ar_sort', text='Sort')

        split = layout.split(factor=0.6)
        left = split.column()
        right = split.column()

        left.template_list("SF_UL_asset_library_asset_library_item_list", "", wm, "sf_ar_items", wm, "sf_ar_active_index", rows=12)
        row = left.row(align=True)
        row.operator("import_scene.sfs_asset_reader_select_all", text=_t('Select All'), icon='CHECKBOX_HLT').mode = 'ALL'
        row.operator("import_scene.sfs_asset_reader_select_all", text=_t('Select All'), icon='CHECKBOX_DEHLT').mode = 'NONE'
        row.operator("import_scene.sfs_asset_reader_select_all", text=_t('Select All'), icon='ARROW_LEFTRIGHT').mode = 'INVERT'
        row.operator("import_scene.sfs_asset_reader_import_checked", text=_t('Import Checked'), icon='IMPORT')

        active = None
        if 0 <= wm.sf_ar_active_index < len(wm.sf_ar_items):
            active = wm.sf_ar_items[wm.sf_ar_active_index]

        info = right.box()
        info.label(text=_t('Details'))
        if not active:
            info.label(text=_t('No items selected'))
        else:
            info.label(text=active.name, icon='FILE_BLEND', translate=False)
            info.label(text=f"{_t('Type')}: {active.data_type}")
            info.label(text=f"{_t('File')}: {os.path.basename(active.file_path)}")
            risk = info.column(align=True)
            risk.label(text=f"{_t('Missing Textures')}: {active.missing_textures}")
            risk.label(text=f"{_t('Absolute Paths')}: {active.abs_texture_paths}")
            if active.is_newer:
                risk.label(text=_t('Newer Blender Version'), icon='ERROR')

        dep = right.box()
        dep.label(text=_t('Dependency Summary'), icon='CONSTRAINT')
        summ = (wm.sf_ar_dep_summary or '').strip()
        if summ:
            lines = summ.splitlines()
            for line in lines[:10]:
                dep.label(text=line[:180])
            if len(lines) > 10:
                dep.label(text=f"... {len(lines) - 10} {_t('more')}", icon='DOT')
        else:
            dep.label(text=_t('Run Analyze File or Analyze Checked'))

    def execute(self, context):
        # no-op; import is done via button
        return {'FINISHED'}


class SF_OT_asset_reader_refresh(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_refresh'
    bl_label = 'Refresh'
    bl_description = 'Refresh the Asset Reader list using the current filters and library index'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        _ar_refresh_items(context)
        return {'FINISHED'}


class SF_OT_asset_reader_select_all(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_select_all'
    bl_label = 'Select All'
    bl_description = 'Select, deselect, or invert the checked state for all Asset Reader results'
    bl_options = {'UNDO', 'INTERNAL'}

    mode: EnumProperty(items=[('ALL', "All", ""), ('NONE', "None", ""), ('INVERT', "Invert", "")], default='ALL')

    def execute(self, context):
        wm = context.window_manager
        if self.mode == 'ALL':
            for it in wm.sf_ar_items:
                it.checked = True
        elif self.mode == 'NONE':
            for it in wm.sf_ar_items:
                it.checked = False
        else:
            for it in wm.sf_ar_items:
                it.checked = not it.checked
        return {'FINISHED'}


class SF_OT_asset_reader_analyze_file(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_analyze_file'
    bl_label = 'Analyze File'
    bl_description = 'Read dependency and risk information for the active Asset Reader result'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        wm = context.window_manager
        if not (0 <= wm.sf_ar_active_index < len(wm.sf_ar_items)):
            self.report({'WARNING'}, _tr('No items selected'))
            return {'CANCELLED'}
        it = wm.sf_ar_items[wm.sf_ar_active_index]
        fp = _norm_path(it.file_path)
        if not fp or not os.path.exists(fp):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}

        idx = _load_index()
        rec = idx.setdefault("files", {}).get(fp)
        if not rec:
            rec = {
                "mtime": int(os.stat(fp).st_mtime) if os.path.exists(fp) else 0,
                "size": int(os.stat(fp).st_size) if os.path.exists(fp) else 0,
                "blend_version": int(_read_blend_version_int(fp)),
                "is_newer": False,
                "lists": _scan_blend_lists(fp),
                "analysis": {},
                "thumbs": {},
            }
            idx["files"][fp] = rec

        # Load all images (linked) to inspect paths
        snapshot = _capture_data_snapshot()
        missing = 0
        abs_paths = 0
        try:
            with bpy.data.libraries.load(fp, link=True) as (df, dt):
                dt.images = list(getattr(df, "images", []) or [])
            # inspect
            for img in dt.images:
                if img is None:
                    continue
                p = getattr(img, "filepath", "") or ""
                if not p:
                    continue
                if os.path.isabs(bpy.path.abspath(p)):
                    abs_paths += 1
                # existence check (resolve relative to blend file)
                abs_p = bpy.path.abspath(p, library=img.library) if getattr(img, "library", None) else bpy.path.abspath(p)
                if abs_p and not os.path.exists(abs_p):
                    missing += 1
        except Exception:
            pass
        finally:
            _cleanup_new_data(snapshot)

        rec.setdefault("analysis", {})
        rec["analysis"]["missing_textures"] = int(missing)
        rec["analysis"]["abs_texture_paths"] = int(abs_paths)
        rec["analysis"]["last_analyzed"] = time.time()
        idx["files"][fp] = rec
        _save_index(idx)

        # refresh list to display counts
        _ar_refresh_items(context)
        self.report({'INFO'}, _tr('Analyze complete'))
        return {'FINISHED'}


class SF_OT_asset_reader_analyze_selection(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_analyze_selection'
    bl_label = 'Analyze Selection'
    bl_description = 'Analyze dependency and risk information for all checked Asset Reader results'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        wm = context.window_manager

        # pick checked items; if none, use active
        targets = [it for it in wm.sf_ar_items if it.checked]
        if not targets:
            if not (0 <= wm.sf_ar_active_index < len(wm.sf_ar_items)):
                self.report({'WARNING'}, _tr('No items selected'))
                return {'CANCELLED'}
            targets = [wm.sf_ar_items[wm.sf_ar_active_index]]

        merged = {}
        tree_lines = []
        for it in targets[:50]:  # safety cap
            deps, tree = _analyze_deps_for_item(it.file_path, it.data_type, it.name)
            # merge sets
            for k, s in deps.items():
                merged.setdefault(k, set()).update(s)
            if tree:
                tree_lines.append(f"== {it.data_type}:{it.name} ({os.path.basename(it.file_path)}) ==")
                tree_lines.extend(tree)
                tree_lines.append("")

        wm.sf_ar_dep_summary = _summarize_deps_against_current(merged)
        wm.sf_ar_dep_tree = '\n'.join(tree_lines).strip()
        self.report({'INFO'}, _tr('Analyze complete'))
        return {'FINISHED'}


class SF_OT_asset_reader_show_dependency_tree(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_asset_reader_show_dependency_tree'
    bl_label = 'Show Dependency Tree'
    bl_description = "Open the full dependency tree report for the current analysis in Blender's Text Editor"
    bl_options = {'INTERNAL'}

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=760)

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        txt = (wm.sf_ar_dep_tree or "").strip()
        if not txt:
            layout.label(text=_t('Not analyzed'))
            return
        lines = txt.splitlines()
        max_lines = 40
        for ln in lines[:max_lines]:
            layout.label(text=ln[:160])
        if len(lines) > max_lines:
            layout.label(text='...')

    def execute(self, context):
        return {'FINISHED'}


class SF_OT_asset_reader_copy_tree(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_copy_tree'
    bl_label = 'Copy Tree'
    bl_description = 'Copy the current dependency tree text to the clipboard'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        txt = (wm.sf_ar_dep_tree or "").strip()
        if txt:
            context.window_manager.clipboard = txt
            self.report({'INFO'}, _tr('Copied'))
            return {'FINISHED'}
        self.report({'WARNING'}, _tr('Not analyzed'))
        return {'CANCELLED'}


class SF_OT_asset_reader_generate_thumbnails(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_generate_thumbnails'
    bl_label = 'Generate Thumbnails'
    bl_description = 'Generate preview thumbnails for the visible Asset Reader results'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        prefs = _addon_prefs(context)

        targets = [it for it in wm.sf_ar_items if it.checked and it.data_type in {'OBJECTS', 'COLLECTIONS'}]
        if not targets:
            self.report({'WARNING'}, _tr('No items selected'))
            return {'CANCELLED'}

        out_dir = _thumbs_dir(prefs)
        res = int(getattr(prefs, "thumb_resolution", 256) or 256)
        res = max(64, min(1024, res))

        idx = _load_index()
        files = idx.setdefault("files", {})

        # Create a temporary scene for rendering
        orig_scene = context.scene
        temp_scene = bpy.data.scenes.new("SF_Thumb_Scene")
        temp_scene.render.image_settings.file_format = 'PNG'
        temp_scene.render.resolution_x = res
        temp_scene.render.resolution_y = res
        temp_scene.render.resolution_percentage = 100

        # Camera / light
        cam_data = bpy.data.cameras.new("SF_Thumb_Cam")
        cam_obj = bpy.data.objects.new("SF_Thumb_Cam", cam_data)
        temp_scene.collection.objects.link(cam_obj)
        temp_scene.camera = cam_obj

        light_data = bpy.data.lights.new("SF_Thumb_Light", type='AREA')
        light_obj = bpy.data.objects.new("SF_Thumb_Light", light_data)
        temp_scene.collection.objects.link(light_obj)

        def _frame_camera_to_objects(objects):
            # compute bounds
            import mathutils
            min_v = mathutils.Vector((1e9, 1e9, 1e9))
            max_v = mathutils.Vector((-1e9, -1e9, -1e9))
            any_bb = False
            for ob in objects:
                if ob.type in {'CAMERA', 'LIGHT'}:
                    continue
                try:
                    for v in ob.bound_box:
                        vv = ob.matrix_world @ mathutils.Vector(v)
                        min_v.x = min(min_v.x, vv.x)
                        min_v.y = min(min_v.y, vv.y)
                        min_v.z = min(min_v.z, vv.z)
                        max_v.x = max(max_v.x, vv.x)
                        max_v.y = max(max_v.y, vv.y)
                        max_v.z = max(max_v.z, vv.z)
                        any_bb = True
                except Exception:
                    pass
            if not any_bb:
                return
            center = (min_v + max_v) * 0.5
            size = (max_v - min_v).length
            dist = max(0.5, size * 1.2)

            cam_obj.location = center + mathutils.Vector((dist, -dist, dist))
            cam_obj.rotation_euler = (math.radians(60), 0.0, math.radians(45))

            light_obj.location = center + mathutils.Vector((dist, -dist, dist * 1.2))
            light_data.energy = 200.0

        import math
        import mathutils

        done = 0
        failures = []

        # render each target
        for it in targets[:50]:
            fp = _norm_path(it.file_path)
            if not fp or not os.path.exists(fp):
                failures.append(f"[{it.data_type}] {it.name} | {_t('Missing source file')}: {fp or '-'}")
                continue

            snap = _capture_data_snapshot()

            loaded_objects = []
            loaded_collections = []

            try:
                with bpy.data.libraries.load(fp, link=False) as (df, dt):
                    if it.data_type == 'OBJECTS' and it.name in getattr(df, "objects", []):
                        dt.objects = [it.name]
                    elif it.data_type == 'COLLECTIONS' and it.name in getattr(df, "collections", []):
                        dt.collections = [it.name]
                    else:
                        continue

                if it.data_type == 'OBJECTS':
                    ob = dt.objects[0]
                    if ob:
                        temp_scene.collection.objects.link(ob)
                        loaded_objects = [ob]
                else:
                    col = dt.collections[0]
                    if col:
                        temp_scene.collection.children.link(col)
                        loaded_collections = [col]
                        loaded_objects = list(col.all_objects)

                _frame_camera_to_objects(loaded_objects)

                # output path
                base = _safe_key(os.path.splitext(os.path.basename(fp))[0])
                out_name = f"{base}__{it.data_type}__{_safe_key(it.name)}.png"
                out_path = os.path.join(out_dir, out_name)

                temp_scene.render.filepath = out_path
                with context.temp_override(scene=temp_scene):
                    bpy.ops.render.render(write_still=True)

                # store into index
                rec = files.get(fp, {})
                thumbs = rec.get("thumbs", {}) or {}
                thumbs[f"{it.data_type}:{it.name}"] = out_path
                rec["thumbs"] = thumbs
                files[fp] = rec
                it.thumb_path = out_path
                done += 1

            except Exception as e:
                failures.append(f"[{it.data_type}] {it.name} | {os.path.basename(fp)} | {type(e).__name__}: {e}")
            finally:
                # unlink loaded things from temp scene to avoid leaks
                try:
                    for ob in loaded_objects:
                        try:
                            linked = temp_scene.collection.objects.get(ob.name)
                        except Exception:
                            linked = None
                        if linked is ob:
                            temp_scene.collection.objects.unlink(ob)
                except Exception:
                    pass
                try:
                    for col in loaded_collections:
                        try:
                            linked = temp_scene.collection.children.get(col.name)
                        except Exception:
                            linked = None
                        if linked is col:
                            temp_scene.collection.children.unlink(col)
                except Exception:
                    pass
                _cleanup_new_data(snap)

        # cleanup temp scene
        try:
            bpy.data.objects.remove(cam_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.objects.remove(light_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.cameras.remove(cam_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.lights.remove(light_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.scenes.remove(temp_scene, do_unlink=True)
        except Exception:
            pass

        _save_index(idx)
        _ar_refresh_items(context)

        if failures:
            lines = [
                f"Smart File | {_t('Thumbnail Generation Report')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                '',
                f"- {_t('Generated')}: {done}",
                f"- {_t('Failures')}: {len(failures)}",
                '',
                *failures,
            ]
            _sf_report_export(
                context,
                _t('Thumbnail Generation Report'),
                lines,
                open_text=False,
                activity_title=_t('Generated thumbnails with warnings'),
            )
            self.report({'WARNING'}, f"{_tr('Thumbnails generated')}: {done} | {_t('Failures')}: {len(failures)}")
            return {'FINISHED'}

        self.report({'INFO'}, f"{_tr('Thumbnails generated')}: {done}")
        return {'FINISHED'}




class SF_OT_asset_reader_auto_detect_catalog(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_auto_detect_catalog'
    bl_label = 'Auto Detect Catalog'
    bl_description = 'Search the configured library roots and fill the catalog source field with the most likely catalog.json file'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        prefs = _addon_prefs(context)
        wm = context.window_manager
        filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'

        # Gather catalogs across enabled roots (recursive, depth-limited)
        roots = []
        if prefs:
            for r in getattr(prefs, 'library_roots', []) or []:
                if getattr(r, 'enabled', True):
                    p = _norm_path(getattr(r, 'path', '') or '')
                    if p and os.path.isdir(p):
                        roots.append(p)

        cand = []
        for rt in roots:
            cand.extend(_ar_find_catalog_files(rt, filename, max_depth=5, limit=300))
        cand = sorted(set([_norm_path(c) for c in cand if c]))

        if not cand:
            self.report({'WARNING'}, _tr('Catalog not found'))
            return {'CANCELLED'}

        # Store a representative catalog file path (used in single-file mode, and as a hint in merged mode)
        wm.sf_ar_catalog_file = _norm_path(cand[0])

        # reload
        try:
            bpy.ops.import_scene.sfs_asset_reader_reload_catalog('EXEC_DEFAULT')
        except Exception:
            pass
        self.report({'INFO'}, _tr('Catalog loaded'))
        return {'FINISHED'}



class SF_OT_asset_reader_reload_catalog(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_reload_catalog'
    bl_label = 'Reload Catalog'
    bl_description = 'Reload the active catalog.json file and rebuild the catalog-based asset list'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        wm = context.window_manager
        wm.sf_ar_cat_raw_json = ''
        _ar_refresh_catalog_assets(context)
        self.report({'INFO'}, _tr('Catalog loaded'))
        return {'FINISHED'}


class SF_OT_asset_reader_apply_catalog_filters(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_apply_catalog_filters'
    bl_label = 'Apply Catalog Filters'
    bl_description = 'Refresh the catalog asset view after changing search, category, source, or tag filters'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        _ar_apply_catalog_filters(context)
        return {'FINISHED'}



class SF_OT_asset_reader_toggle_tag(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_toggle_tag'
    bl_label = 'Toggle Tag'
    bl_description = 'Enable or disable one tag filter chip in the catalog view'
    bl_options = {'UNDO', 'INTERNAL'}

    tag: StringProperty(name='Tag', default="", options={'HIDDEN'})

    def execute(self, context):
        wm = context.window_manager
        tg = (self.tag or "").strip()
        if not tg:
            return {'CANCELLED'}
        tokens = _ar_parse_tag_tokens(getattr(wm, 'sf_ar_cat_tag_filter', '') or '')
        lower = [t.lower() for t in tokens]
        if tg.lower() in lower:
            tokens = [t for t in tokens if t.lower() != tg.lower()]
        else:
            tokens.append(tg)
        wm.sf_ar_cat_tag_filter = ','.join(tokens)
        _ar_apply_catalog_filters(context)
        return {'FINISHED'}


class SF_OT_asset_reader_clear_tags(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_clear_tags'
    bl_label = 'Clear Tags'
    bl_description = 'Clear all active tag filters in the catalog view'
    bl_options = {'UNDO', 'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        wm = context.window_manager
        wm.sf_ar_cat_tag_filter = ""
        _ar_apply_catalog_filters(context)
        return {'FINISHED'}

class SF_OT_asset_reader_set_preferred_source(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_set_preferred_source'
    bl_label = 'Set Preferred Source'
    bl_description = 'Remember which source entry should be preferred for the active catalog asset when multiple versions exist'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        wm = context.window_manager
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        if not (0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets)):
            return {'CANCELLED'}
        a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
        group_key = (a.group_key or a.asset_id or a.asset or '').strip() or str(wm.sf_ar_cat_active_index)

        sel = getattr(wm, 'sf_ar_cat_pref_source', 'AUTO') or 'AUTO'
        try:
            cand = json.loads(getattr(a, 'candidates_json', '[]') or '[]')
        except Exception:
            cand = []

        try:
            overrides = json.loads(getattr(prefs, 'cat_conflict_overrides_json', '{}') or '{}')
        except Exception:
            overrides = {}
        if not isinstance(overrides, dict):
            overrides = {}

        if sel == 'AUTO':
            overrides.pop(str(group_key), None)
        else:
            try:
                i = int(sel[1:])
                if 0 <= i < len(cand):
                    overrides[str(group_key)] = _norm_path(str(cand[i]))
            except Exception:
                pass

        prefs.cat_conflict_overrides_json = json.dumps(overrides, ensure_ascii=False)
        _ar_refresh_catalog_assets(context)
        self.report({'INFO'}, _tr('Catalog loaded'))
        return {'FINISHED'}


class SF_OT_asset_reader_clear_preferred_source(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_clear_preferred_source'
    bl_label = 'Clear Preferred Source'
    bl_description = 'Remove the saved preferred-source override for the active catalog asset'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        wm = context.window_manager
        try:
            wm.sf_ar_cat_pref_source = 'AUTO'
        except Exception:
            pass
        return bpy.ops.import_scene.sfs_asset_reader_set_preferred_source('EXEC_DEFAULT')


class SF_OT_asset_reader_build_versions(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_build_versions'
    bl_label = 'Build Versions'
    bl_description = 'Build the version list for the active catalog asset so older or newer publishes can be compared'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        _ar_build_versions_for_active(context)
        return {'FINISHED'}


def _ar_best_guess_import_from_blend(context, blend_fp: str, asset_name: str = '') -> tuple[str, list[str]]:
    """Return (mode, names) best guess from a published blend."""
    blend_fp = _norm_path(blend_fp)
    if not blend_fp or not os.path.exists(blend_fp):
        return '', []
    # Prefer collection with same name
    try:
        lists = _scan_blend_lists(blend_fp)
    except Exception:
        lists = {}
    cols = list((lists or {}).get('COLLECTIONS', []) or [])
    objs = list((lists or {}).get('OBJECTS', []) or [])
    if asset_name and asset_name in cols:
        return 'COLLECTIONS', [asset_name]
    if len(cols) == 1:
        return 'COLLECTIONS', [cols[0]]
    if len(objs) == 1:
        return 'OBJECTS', [objs[0]]
    # fallback: collections first
    if cols:
        return 'COLLECTIONS', [cols[0]]
    if objs:
        return 'OBJECTS', [objs[0]]
    return '', []


class SF_OT_asset_reader_import_latest(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_import_latest'
    bl_label = 'Import Latest'
    bl_description = 'Import the latest published version of the active catalog asset with the current Smart File options'
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        wm = context.window_manager
        if not (0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets)):
            self.report({'WARNING'}, _tr('No selection'))
            return {'CANCELLED'}
        a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
        blend_fp = _norm_path(a.latest_blend)
        if not blend_fp or not os.path.exists(blend_fp):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}

        mode, names = _ar_best_guess_import_from_blend(context, blend_fp, asset_name=a.asset)
        if not mode or not names:
            self.report({'WARNING'}, _tr('No items found'))
            return {'CANCELLED'}

        prev_fp = wm.sf_filepath
        prev_mode = wm.sf_mode
        prev_aid = getattr(wm, "sf_current_asset_id", "")
        try:
            # tag linked libraries with this asset_id (when importing via Catalog)
            try:
                wm.sf_current_asset_id = getattr(a, "asset_id", "") or ""
            except Exception:
                wm.sf_current_asset_id = ""

            wm.sf_filepath = blend_fp
            wm.sf_mode = mode
            wm.sf_items.clear()
            for n in names:
                si = wm.sf_items.add()
                si.name = n
                si.is_selected = True
            bpy.ops.import_scene.sfs_source_browser_import_2('EXEC_DEFAULT')
        except Exception as e:
            self.report({'ERROR'}, _sf_error_text(e))
            return {'CANCELLED'}
        finally:
            wm.sf_filepath = prev_fp
            wm.sf_mode = prev_mode
            try:
                wm.sf_current_asset_id = prev_aid
            except Exception:
                pass

        return {'FINISHED'}


class SF_OT_asset_reader_import_version(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_import_version'
    bl_label = 'Import Version'
    bl_description = 'Import the specifically selected version of the active catalog asset'
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        wm = context.window_manager
        if not (0 <= wm.sf_ar_cat_ver_active_index < len(wm.sf_ar_cat_versions)):
            self.report({'WARNING'}, _tr('No selection'))
            return {'CANCELLED'}
        v = wm.sf_ar_cat_versions[wm.sf_ar_cat_ver_active_index]
        blend_fp = _norm_path(v.blend)
        if not blend_fp or not os.path.exists(blend_fp):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}
        asset_name = ''
        if 0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets):
            asset_name = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index].asset

        mode, names = _ar_best_guess_import_from_blend(context, blend_fp, asset_name=asset_name)
        if not mode or not names:
            self.report({'WARNING'}, _tr('No items found'))
            return {'CANCELLED'}

        prev_fp = wm.sf_filepath
        prev_mode = wm.sf_mode
        prev_aid = getattr(wm, "sf_current_asset_id", "")
        try:
            # tag linked libraries with this asset_id (when importing via Catalog)
            try:
                if 0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets):
                    wm.sf_current_asset_id = getattr(wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index], "asset_id", "") or ""
                else:
                    wm.sf_current_asset_id = ""
            except Exception:
                wm.sf_current_asset_id = ""

            wm.sf_filepath = blend_fp
            wm.sf_mode = mode
            wm.sf_items.clear()
            for n in names:
                si = wm.sf_items.add()
                si.name = n
                si.is_selected = True
            bpy.ops.import_scene.sfs_source_browser_import_2('EXEC_DEFAULT')
        except Exception as e:
            self.report({'ERROR'}, _sf_error_text(e))
            return {'CANCELLED'}
        finally:
            wm.sf_filepath = prev_fp
            wm.sf_mode = prev_mode
            try:
                wm.sf_current_asset_id = prev_aid
            except Exception:
                pass

        return {'FINISHED'}


class SF_OT_asset_reader_open_folder(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_open_folder'
    bl_label = 'Open Folder'
    bl_description = 'Open the folder that contains the active catalog asset or version in the operating system file browser'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        if not (0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets)):
            self.report({'WARNING'}, _tr('No selection'))
            return {'CANCELLED'}
        a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
        fp = _norm_path(a.latest_blend)
        if not fp:
            return {'CANCELLED'}
        try:
            bpy.ops.wm.path_open(filepath=os.path.dirname(fp))
        except Exception:
            pass
        return {'FINISHED'}
class SF_OT_asset_reader_import_checked(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_import_checked'
    bl_label = 'Import Checked'
    bl_description = 'Import all checked Asset Reader results using the current Smart File options'
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        wm = context.window_manager
        filepath_groups = {}
        for it in wm.sf_ar_items:
            if it.checked:
                filepath_groups.setdefault(it.file_path, {}).setdefault(it.data_type, []).append(it.name)

        if not filepath_groups:
            self.report({'WARNING'}, _tr('No items selected'))
            return {'CANCELLED'}

        # Reuse the same import options used by Smart File dialog
        # Import each file/type group
        for fp, type_map in filepath_groups.items():
            for dt, names in type_map.items():
                # Temporarily drive the existing execute logic by setting SA properties
                # (keeps behavior consistent)
                prev_fp = wm.sf_filepath
                prev_mode = wm.sf_mode
                prev_sel = [x.is_selected for x in wm.sf_items]
                try:
                    wm.sf_filepath = fp
                    wm.sf_mode = dt
                    # fill sf_items with names
                    wm.sf_items.clear()
                    for n in names:
                        si = wm.sf_items.add()
                        si.name = n
                        si.is_selected = True
                    # call the existing import operator in EXEC mode (no UI)
                    bpy.ops.import_scene.sfs_source_browser_import_2('EXEC_DEFAULT')
                except Exception:
                    pass
                finally:
                    # restore
                    try:
                        wm.sf_filepath = prev_fp
                        wm.sf_mode = prev_mode
                    except Exception:
                        pass
                    # restore sf_items selection state is not critical

        return {'FINISHED'}
class SF_OT_asset_reader_translation_check(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_reader_translation_check'
    bl_label = 'Translation Check'
    bl_description = 'List untranslated UI strings in the system console so localization gaps can be fixed'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs or not prefs.debug_translation:
            return {'CANCELLED'}

        # Minimal check: print keys that return the same string in ja_JP.
        keys = [k[1] for k in translation_dict.get("ja_JP", {}).keys() if k[0] == "*"]
        missing = []
        for k in sorted(set(keys)):
            if bpy.app.translations.pgettext_iface(k) == k and bpy.app.translations.pgettext(k) == k:
                missing.append(k)
        print("[Smart File] Translation check - possibly missing translations:")
        for m in missing:
            print('-', m)
        return {'FINISHED'}
