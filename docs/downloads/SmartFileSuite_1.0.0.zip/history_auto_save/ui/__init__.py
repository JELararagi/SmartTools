# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi. All Rights Reserved.
#
# Terms of Use:
# - All rights, including copyright and intellectual property rights, belong to JELararagi.
# - Redistribution, resale, modification, reverse engineering, or sharing without explicit permission is prohibited.
# ------------------------------------------------------------------------------

# Package marker for Blender addon UI modules.
