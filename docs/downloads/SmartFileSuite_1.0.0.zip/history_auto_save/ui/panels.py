# ------------------------------------------------------------------------------
# Integrated into Smart File
# ------------------------------------------------------------------------------

from ...ui_language_runtime import ui_text as _ui_text
import os

import bpy
from bpy.types import Panel

from ..core.context_utils import addon_prefs, project_root, scene_settings
from ..core import crash_recovery
from ..core.runtime import history_counts, runtime_status
from ..translation import iface as _iface, mode_label as _mode_label

ENTRY_ICONS = {
    "Restore Point": 'PRESET',
    "Autosave": 'FILE_TICK',
}


def safe_label(layout, text, icon=None):
    try:
        if icon:
            layout.label(text=text, icon=icon)
        else:
            layout.label(text=text)
    except TypeError:
        layout.label(text=text)


def _crash_recovery_status_text(value) -> str:
    text = str(value or "Ready")
    suffix = " recovery candidates found."
    if text.endswith(suffix):
        count = text[:-len(suffix)]
        if count.isdigit():
            return _iface("{} recovery candidates found.").format(count)
    prefix = "Crash recovery result could not be loaded: "
    if text.startswith(prefix):
        detail = text[len(prefix):]
        return f"{_iface('Crash recovery result could not be loaded:')} {detail}"
    return _iface(text)


def _crash_recovery_candidate_label(item) -> str:
    label = str(getattr(item, "label", "") or "")
    if label:
        return _iface(label)
    return _iface("Candidate")




def _operator_exists(bl_idname: str) -> bool:
    try:
        prefix, suffix = str(bl_idname or '').split('.', 1)
    except ValueError:
        return False
    rna_id = f"{prefix.upper()}_OT_{suffix}"
    try:
        if isinstance(getattr(bpy.types, rna_id, None), type):
            return True
    except Exception:
        pass
    try:
        group = getattr(bpy.ops, prefix, None)
        op = getattr(group, suffix, None) if group is not None else None
        return op is not None
    except Exception:
        return False

def _safe_operator(layout, bl_idname: str, *, text: str = "", icon: str = 'NONE', **kwargs):
    if not _operator_exists(bl_idname):
        try:
            layout.label(text=text or bl_idname, icon='ERROR')
        except Exception:
            pass
        return None
    try:
        return layout.operator(bl_idname, text=text, icon=icon, **kwargs)
    except TypeError:
        try:
            return layout.operator(bl_idname, text=text, icon=icon)
        except Exception:
            return None
    except Exception:
        return None

def _safe_set_operator_property(op, name: str, value) -> bool:
    try:
        if op is None:
            return False
        setattr(op, str(name or ''), value)
        return True
    except Exception:
        return False


def _draw_sf_help_button(layout, *, section: str, title: str):
    try:
        layout.scale_x = 0.82
        layout.scale_y = 1.0
    except Exception:
        pass
    op_idname = 'import_scene.sfs_system_open_help'
    if not _operator_exists(op_idname):
        try:
            row = layout.row(align=True)
            row.enabled = False
            row.label(text='', icon='QUESTION')
        except Exception:
            pass
        return None
    try:
        op = layout.operator(op_idname, text='', icon='QUESTION', emboss=True)
    except TypeError:
        op = layout.operator(op_idname, text='', icon='QUESTION', emboss=True)
    except Exception:
        return None
    _safe_set_operator_property(op, 'help_key', 'history_section')
    _safe_set_operator_property(op, 'lane', 'HISTORY')
    _safe_set_operator_property(op, 'section', str(section or ''))
    _safe_set_operator_property(op, 'display_title', str(title or ''))
    return op


_SFS_GROUP_UI_STATE_KEY = 'smart_file_suite_group_ui_state_v1'


def _section_state_get(section_key: str, default: bool = False) -> bool:
    """Read section state without creating or mutating draw-time storage."""
    try:
        ns = bpy.app.driver_namespace
        state = ns.get(_SFS_GROUP_UI_STATE_KEY)
        return bool(state.get(str(section_key or ''), bool(default))) if isinstance(state, dict) else bool(default)
    except Exception:
        return bool(default)


def _safe_set_op_props(op, **kwargs):
    try:
        for key, value in kwargs.items():
            try:
                setattr(op, key, value)
            except Exception:
                pass
    except Exception:
        pass


def _draw_history_group_section(layout, context, text: str, icon: str, *, help_section: str, default_open: bool = False):
    section_key = 'sfs_history_child_' + ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(help_section or text)).strip('_')
    try:
        panel_fn = getattr(layout, 'panel', None)
        if callable(panel_fn):

            try:
                header, panel = panel_fn(section_key, default_closed=not bool(default_open))
            except TypeError:
                header, panel = panel_fn(section_key)
            if header is not None:
                try:
                    header.label(text=text, icon=icon)
                except TypeError:
                    header.label(text=text)
                help_row = header.row(align=True)
                try:
                    help_row.alignment = 'RIGHT'
                    help_row.scale_x = 0.82
                    help_row.scale_y = 1.0
                except Exception:
                    pass
                _draw_sf_help_button(help_row, section=help_section, title=text)
            if panel is None:
                return header, None, False
            body = panel.column(align=True)
            return header, body, True
    except Exception:
        pass
    expanded = _section_state_get(section_key, default_open)
    box = layout.box()
    row = box.row(align=True)
    row.label(text=text, icon=icon)
    help_row = row.row(align=True)
    try:
        help_row.alignment = 'RIGHT'
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        pass
    _draw_sf_help_button(help_row, section=help_section, title=text)
    if not expanded:
        return box, None, False
    body = box.column(align=True)
    return box, body, True


def _draw_section_header(layout, text: str, icon: str, *, help_section: str):
    row = layout.row(align=True)
    row.label(text=text, icon=icon)
    help_row = row.row(align=True)
    help_row.alignment = 'RIGHT'
    help_row.scale_x = 0.82
    help_row.scale_y = 1.0
    _draw_sf_help_button(help_row, section=help_section, title=text)
    return row



def _compact_path_label(path: str, limit: int = 96) -> str:
    path = str(path or '').strip()
    if not path:
        return '-'
    path = os.path.normpath(path)
    if len(path) <= limit:
        return path
    drive, tail = os.path.splitdrive(path)
    parts = [part for part in path.replace('\\', '/').split('/') if part]
    if len(parts) <= 2:
        return '...' + path[-max(8, limit - 3):]
    end = os.path.join(*parts[-2:])
    prefix = f'{drive}{os.sep}' if drive else ''
    label = f'{prefix}...{os.sep}{end}'
    return label if len(label) <= limit else '...' + label[-max(8, limit - 3):]


def _matches_filter(item, text: str) -> bool:
    if not text:
        return True
    haystack = " ".join([
        item.label or "",
        item.detail or "",
        item.timestamp or "",
        item.active_object or "",
        item.entry_type or "",
        item.mode or "",
        item.scene_name or "",
    ]).lower()
    return text.lower() in haystack


def _visible_indices(st):
    indices = list(range(len(st.entries) - 1, -1, -1))
    text = (st.filter_text or "").strip()
    result = []
    for idx in indices:
        item = st.entries[idx]
        if not _matches_filter(item, text):
            continue
        if item.entry_type not in {"Restore Point", "Autosave"}:
            continue
        if getattr(st, "show_only_restorable", True) and not (item.restorable or item.nearest_restore_index >= 0):
            continue
        result.append(idx)
    return result



class _UHM_PanelBase:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart File'


def draw_history_summary(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False

    prefs = addon_prefs(context)
    st = scene_settings(context)
    if st is None:
        safe_label(layout, _iface("Ready"), 'NONE')
        return

    total_rows, restore_rows, autosave_rows = history_counts(context)
    listener_enabled = bool((getattr(prefs, 'enable_autosave', False) or getattr(prefs, 'enable_restore_snapshots', False))) if prefs is not None else False

    hero = layout.box()
    hero.label(text=_iface("Checkpoint"))
    hero.prop(st, "checkpoint_name", text="", placeholder=_iface("Manual Restore Point"))
    main_action = hero.row(align=True)
    main_action.scale_y = 1.15
    _safe_operator(main_action, "uhm.sfs_history_create_restore_point_now", text=_iface("Create Manual Restore Point"), icon='ADD')

    safe_label(hero, runtime_status(context), 'RADIOBUT_ON' if listener_enabled else 'RADIOBUT_OFF')
    try:
        _safe_operator(hero, "uhm.sfs_history_refresh_runtime", text=_iface("Refresh"), icon='FILE_REFRESH')
    except Exception:
        pass

    if prefs is None:
        safe_label(hero, _iface("Preferences unavailable"), 'ERROR')

    counts = hero.column(align=True)
    for count_label, count_icon, count_value in (
        ("Visible", 'LINENUMBERS_ON', total_rows),
        ("Restore", 'PRESET', restore_rows),
        ("Autosave", 'FILE_TICK', autosave_rows),
    ):
        count_row = counts.split(factor=0.7, align=True)
        count_row.label(text=_iface(count_label), icon=count_icon)
        count_row.label(text=str(count_value))

def draw_history_list_section(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    st = scene_settings(context)
    if st is None:
        return

    tools = layout.box()
    search = tools.row(align=True)
    search.prop(st, "filter_text", text="", icon='VIEWZOOM')
    search.prop(st, "show_only_restorable", text=_iface("Restorable Only"), toggle=True)
    search.prop(st, "show_details", text=_iface("Details"), toggle=True)

    visible = _visible_indices(st)

    list_box = tools.box()
    list_box.scale_y = 0.95
    if visible:
        for row_number, idx in enumerate(visible[:14], start=1):
            item = st.entries[idx]
            restore_ready = bool(getattr(item, "restorable", False) or getattr(item, "nearest_restore_index", -1) >= 0)
            is_active = idx == getattr(st, "active_index", -1)
            item_icon = ENTRY_ICONS.get(getattr(item, "entry_type", ""), 'TIME')
            stamp = f" [{item.timestamp[-8:]}]" if getattr(item, "timestamp", "") else ""
            label = (getattr(item, "label", "") or _iface("(unnamed)")) + stamp
            row = list_box.row(align=True)
            row.alert = bool(is_active)
            select_op = _safe_operator(row, "uhm.sfs_history_row_click", text=label, icon=item_icon, depress=is_active)
            if select_op is not None:
                select_op.index = idx
            row.label(text="", icon='CHECKMARK' if restore_ready else 'REMOVE')
        if len(visible) > 14:
            list_box.label(text=_iface("More rows are available. Use Search or Restorable Only to narrow the list."), icon='SORTSIZE')
    else:
        list_box.label(text=_iface("No restore points or autosaves match the current filter."))

    buttons = tools.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
    buttons.operator_context = 'INVOKE_DEFAULT'
    _safe_operator(buttons, "uhm.sfs_history_restore_selected_row", text=_iface("Restore Selected"), icon='RECOVER_LAST')
    _safe_operator(buttons, "uhm.sfs_history_delete_selected_row", text=_iface("Delete"), icon='TRASH')
    _safe_operator(buttons, "uhm.sfs_history_export_log", text=_iface("Export Log"), icon='FILE')
    _safe_operator(buttons, "uhm.sfs_history_clear_all", text=_iface("Clear"), icon='X')

    if not visible:
        footer = tools.row(align=True)
        footer.scale_y = 0.9
        footer.label(text=_iface("No restore points or autosaves yet."))


def draw_history_quick_actions(layout, context):
    st = scene_settings(context)
    if st is None:
        return

    box = layout.box()
    box.label(text=_iface("Manual Restore Point"), icon='PRESET')
    box.label(text=_iface("Checkpoint"))
    box.prop(st, "checkpoint_name", text="", placeholder=_iface("Manual Restore Point"))

    primary = box.row(align=True)
    primary.scale_y = 1.18
    _safe_operator(primary, "uhm.sfs_history_create_restore_point_now", text=_iface("Create Manual Restore Point"), icon='ADD')

    utility = box.box()
    utility.label(text=_iface("Autosave Utility"), icon='FILE_TICK')
    utility.label(text=_iface("Autosave normally runs in the background. Use this only when you want an extra rolling backup immediately."), icon='BLANK1')
    row = utility.row(align=True)
    _safe_operator(row, "uhm.sfs_history_create_autosave_now", text=_iface("Create Autosave Now"), icon='FILE_TICK')

    row = box.row(align=True)
    _safe_operator(row, "uhm.sfs_history_open_storage_folder", text=_iface("Open Project Storage Folder"), icon='FILEBROWSER')


def draw_history_selected_row(layout, context):
    st = scene_settings(context)
    if st is None or st.active_index < 0 or st.active_index >= len(st.entries):
        safe_label(layout, _iface("No history yet"), 'NONE')
        return

    item = st.entries[st.active_index]
    details = layout.box()
    safe_label(details, item.label or _iface("(unnamed)"), ENTRY_ICONS.get(item.entry_type, 'PRESET'))
    grid = details.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
    grid.label(text=_iface("Time"))
    grid.label(text=item.timestamp or "-")
    grid.label(text=_iface("Type"))
    grid.label(text=item.entry_type or "-")
    grid.label(text=_iface("Object"))
    grid.label(text=item.active_object or "-", translate=False)
    grid.label(text=_iface("Mode"))
    grid.label(text=_mode_label(item.mode))
    grid.label(text=_iface("Frame"))
    grid.label(text=str(item.frame))
    grid.label(text=_iface("Scene"))
    grid.label(text=item.scene_name or "-", translate=False)
    grid.label(text=_iface("Restore Target"))
    grid.label(text=_iface("Direct snapshot") if item.restorable else _iface("Nearest earlier restore point"))
    if item.detail:
        details.separator()
        details.label(text=_iface("Details"), icon='TEXT')
        details.label(text=item.detail)
    if getattr(st, "show_details", False) and item.file_path:
        details.separator()
        details.label(text=_iface("Attached File"), icon='FILE_BLEND')
        details.label(text=item.file_path, translate=False)


def draw_history_automatic(layout, context):
    prefs = addon_prefs(context)
    if prefs is None:
        safe_label(layout, _iface("Preferences unavailable"), 'NONE')
        return

    left_box = layout.box()
    left_box.label(text=_iface("Optional Timed Restore Points"), icon='PRESET')
    left_box.prop(prefs, "enable_restore_snapshots", text=_iface("Enable Optional Timed Restore"))
    left = left_box.column(align=True)
    left.enabled = prefs.enable_restore_snapshots
    left.prop(prefs, "restore_snapshot_interval_minutes", text=_iface("Interval"))
    left.prop(prefs, "restore_snapshot_max_files", text=_iface("Max Files"))

    right_box = layout.box()
    right_box.label(text=_iface("Autosaves"), icon='FILE_TICK')
    right_box.prop(prefs, "enable_autosave", text=_iface("Enable Rolling Autosave"))
    right = right_box.column(align=True)
    right.enabled = prefs.enable_autosave
    right.prop(prefs, "autosave_interval_minutes", text=_iface("Interval"))
    right.prop(prefs, "autosave_max_files", text=_iface("Max Files"))
    right.label(text=_iface("Max Files Scope"))
    right.prop(prefs, "autosave_retention_scope", text="")
    right.prop(prefs, "autosave_skip_unchanged", text=_iface("Skip Unchanged Autosaves"))
    autosave_now = right.row(align=True)
    autosave_now.enabled = bool(getattr(prefs, "enable_autosave", False))
    _safe_operator(autosave_now, "uhm.sfs_history_create_autosave_now", text=_iface("Create Autosave Now"), icon='FILE_TICK')

def draw_history_behavior(layout, context):
    prefs = addon_prefs(context)
    if prefs is None:
        safe_label(layout, _iface("Preferences unavailable"), 'NONE')
        return

    box = layout.box()
    box.label(text=_iface("Storage Folder"), icon='FILEBROWSER')
    box.label(text=_iface("Manual Storage Folder"))
    box.prop(prefs, "history_directory", text="")
    row = box.column(align=True)
    _safe_operator(row, "uhm.sfs_history_register_storage_folder", text=_iface("Register History Folder"), icon='FILE_TICK')
    _safe_operator(row, "uhm.sfs_history_open_storage_folder", text=_iface("Open Project Storage Folder"), icon='FILEBROWSER')
    _safe_operator(row, "uhm.sfs_history_use_default_storage_folder", text=_iface("Use Default Folder"), icon='LOOP_BACK')
    box.separator()
    safe_label(box, _iface("Current Project Storage"), 'FILE_FOLDER')
    box.label(text=_compact_path_label(project_root(context, create=False)))

    options = layout.box()
    options.label(text=_iface("Restore Safety"), icon='RECOVER_LAST')
    options.prop(prefs, "create_safety_snapshot_before_restore")
    options.prop(prefs, "compress_snapshots")
    options.prop(prefs, "timer_interval_seconds")
    try:
        _safe_operator(options, 'wm.sfs_system_save_preferences', text=_iface('Save Preferences'), icon='FILE_TICK')
    except Exception:
        pass

def draw_history_crash_recovery(layout, context):
    st = scene_settings(context)
    if st is None:
        safe_label(layout, _iface("Scene settings unavailable"), 'ERROR')
        return

    status = layout.box()
    status.label(text=_iface("Crash Recovery"), icon='RECOVER_LAST')
    row = status.row(align=True)
    row.label(text=_iface("Status"))
    row.label(text=_crash_recovery_status_text(getattr(st, "crash_recovery_status", "")))
    status.prop(st, "crash_recovery_progress", text=_iface("Progress"))
    if getattr(st, "crash_recovery_last_error", ""):
        error_box = status.box()
        error_box.alert = True
        error_box.label(text=_iface("Last Error"), icon='ERROR')
        error_box.label(text=st.crash_recovery_last_error)

    scan = layout.box()
    scan.label(text=_iface("External Crash Targets"), icon='VIEWZOOM')
    row = scan.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
    _safe_operator(row, "uhm.sfs_history_crash_recovery_quick_scan", text=_iface("Refresh Targets"), icon='FILE_REFRESH')
    _safe_operator(row, "uhm.sfs_history_crash_recovery_disk_points", text=_iface("Saved Recovery Points"), icon='RECOVER_LAST')
    _safe_operator(row, "uhm.sfs_history_crash_recovery_cancel", text=_iface("Cancel"), icon='CANCEL')
    _safe_operator(row, "uhm.sfs_history_crash_recovery_clear", text=_iface("Clear"), icon='X')

    candidates = layout.box()
    candidates.label(text=_iface("Recovery Candidates"), icon='FILE_BLEND')
    if len(st.crash_recovery_candidates):
        for idx in range(min(12, len(st.crash_recovery_candidates))):
            item = st.crash_recovery_candidates[idx]
            row = candidates.row(align=True)
            row.alert = bool(idx == st.crash_recovery_active_index)
            icon = 'CHECKMARK' if item.recommended else ('ERROR' if item.suspect_small or not item.valid_blend_header else 'FILE_BLEND')
            label = _crash_recovery_candidate_label(item)
            suffix = "  ★" if item.recommended else ""
            row.label(text=f"{idx}: {label}: {os.path.basename(item.path)}{suffix}", icon=icon)
            row.label(text=item.mtime_text)
        candidates.prop(st, "crash_recovery_active_index", text=_iface("Selected Candidate Index"))
        selected = st.crash_recovery_candidates[st.crash_recovery_active_index] if 0 <= st.crash_recovery_active_index < len(st.crash_recovery_candidates) else None
        if selected is not None:
            details = candidates.box()
            details.label(text=selected.path, icon='FILE_BLEND', translate=False)
            signal = str(getattr(selected, "crash_signal", "") or "")
            if signal:
                details.label(text=f"{_iface('Crash Signal')}: {signal}", icon='ERROR')
            details.label(text=f"{selected.scene_name} | {selected.mtime_text} | {selected.size} {_iface('Bytes')}")
    else:
        candidates.label(text=_iface("No crash-recovery scan has been run yet."))

    recover = layout.box()
    recover.label(text=_iface("Recover and Open"), icon='RECOVER_LAST')
    recover.label(text=_iface("Output Folder"))
    recover.prop(st, "crash_recovery_destination_dir", text="")
    _safe_operator(recover, "uhm.sfs_history_crash_recovery_copy_selected", text=_iface("Recover Latest State"), icon='RECOVER_LAST')
    _safe_operator(recover, "uhm.sfs_history_crash_recovery_analyze_selected", text=_iface("Find Memory Recovery Points"), icon='VIEWZOOM')
    points = crash_recovery.recovery_points()
    if points:
        points_box = recover.box()
        points_box.label(text=_iface("Memory Recovery Points"), icon='RECOVER_LAST')
        for idx, point in enumerate(points[:24]):
            row = points_box.row(align=True)
            label = str(point.get("label") or point.get("name") or _ui_text(f"Recovery point {idx}", f'復旧点 {idx}'))
            row.label(text=f"{idx}: {label}")
            op = _safe_operator(row, "uhm.sfs_history_crash_recovery_point", text=_iface("Recover This Point"), icon='FILE_TICK')
            if op is not None:
                op.step_index = idx
    if getattr(st, "crash_recovery_last_destination", ""):
        recover.label(text=st.crash_recovery_last_destination, icon='FILE_TICK')


def draw_history_popup_ui(layout, context):
    summary_box, summary_body, summary_expanded = _draw_history_group_section(layout, context, _iface("History Summary"), 'RECOVER_LAST', help_section='HISTORY_SUMMARY', default_open=True)
    if summary_expanded and summary_body is not None:
        draw_history_summary(summary_body, context)

    _box, body, expanded = _draw_history_group_section(layout, context, _iface("History Browser"), 'LINENUMBERS_ON', help_section='HISTORY_BROWSER')
    if expanded and body is not None:
        draw_history_list_section(body, context)

    _box, body, expanded = _draw_history_group_section(layout, context, _iface("Selected Snapshot"), 'PRESET', help_section='HISTORY_SELECTED_SNAPSHOT')
    if expanded and body is not None:
        draw_history_selected_row(body, context)

    _box, body, expanded = _draw_history_group_section(layout, context, _iface("Automatic Protection"), 'FILE_TICK', help_section='HISTORY_AUTOMATIC_PROTECTION')
    if expanded and body is not None:
        draw_history_automatic(body, context)

    _box, body, expanded = _draw_history_group_section(layout, context, _iface("Storage & Behavior"), 'PREFERENCES', help_section='HISTORY_STORAGE_BEHAVIOR')
    if expanded and body is not None:
        draw_history_behavior(body, context)

    _box, body, expanded = _draw_history_group_section(layout, context, _iface("Crash Recovery"), 'RECOVER_LAST', help_section='HISTORY_CRASH_RECOVERY')
    if expanded and body is not None:
        draw_history_crash_recovery(body, context)




# History & Restore is drawn only by ``draw_history_popup_ui`` inside the
# canonical Smart File "History & Restore" top-level section.  Registering the
# former Panel wrappers duplicated the same controls beneath the Suite root and
# exposed "History Snapshot Protection" as an extra top-level section.
CLASSES = ()
