from __future__ import annotations

import bisect
import collections
import hashlib
import json
import mmap
import os
import re
import struct
import sys
import time
from pathlib import Path
from typing import Any, Iterable

ENGINE_VERSION = "smartfile-deep-recovery/1"
SCHEMA_ANALYZE = "smartfile_deep_recovery/analyze/1"
SCHEMA_EXTRACT = "smartfile_deep_recovery/extract/1"
SCHEMA_RESCUE = "smartfile_deep_recovery/rescue/1"

BLEND_HDR = b"BLENDER17-01v0501"
BHEAD = 32
PTR = 8
SHARED_TAG = 0x8000
MASK48 = (1 << 48) - 1
MAX_CHUNK_BYTES = 1 << 24
DEFAULT_MIN_STEP_BYTES = 1 << 20

ATTR_ELEM = {
    0: 1,
    1: 1,
    2: 4,
    3: 4,
    4: 8,
    5: 4,
    6: 8,
    7: 12,
    8: 64,
    9: 4,
    10: 16,
    11: 16,
    12: 256,
}
CD_MDEFORMVERT = 2


def _now_text() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def progress(stage: str, pct: int, msg: str = "") -> None:
    sys.stdout.write("@@PROGRESS %s %d %s\n" % (stage, int(pct), str(msg or "")))
    sys.stdout.flush()


class Dump:
    """Read-only virtual-address view of a full-memory Windows minidump."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = str(path)
        self.f = open(self.path, "rb")
        self.mm = mmap.mmap(self.f.fileno(), 0, access=mmap.ACCESS_READ)
        mm = self.mm
        if mm[:4] != b"MDMP":
            raise ValueError("not a full-memory minidump")
        nstreams, dirrva = struct.unpack_from("<II", mm, 8)
        raw: list[list[int]] = []
        for i in range(nstreams):
            st, _dsize, rva = struct.unpack_from("<III", mm, dirrva + i * 12)
            if st == 9:
                nranges, baserva = struct.unpack_from("<QQ", mm, rva)
                off, p = baserva, rva + 16
                for _ in range(nranges):
                    start, size = struct.unpack_from("<QQ", mm, p)
                    p += 16
                    raw.append([start, size, off])
                    off += size
        if not raw:
            raise ValueError("dump has no full-memory stream")
        raw.sort()
        merged: list[list[int]] = []
        for r in raw:
            if merged and merged[-1][0] + merged[-1][1] == r[0] and merged[-1][2] + merged[-1][1] == r[2]:
                merged[-1][1] += r[1]
            else:
                merged.append(list(r))
        self.ranges = merged
        self.starts = [r[0] for r in merged]
        self.total = sum(r[1] for r in merged)

    def read(self, va: int, n: int) -> bytes | None:
        if n <= 0 or n > (1 << 31):
            return None
        i = bisect.bisect_right(self.starts, va) - 1
        if i < 0:
            return None
        start, size, base = self.ranges[i]
        if not (start <= va and va + n <= start + size):
            return None
        off = base + (va - start)
        return self.mm[off:off + n]

    def u64(self, va: int) -> int | None:
        data = self.read(va, 8)
        return None if data is None else struct.unpack("<Q", data)[0]

    def off_to_va(self, off: int) -> int | None:
        for start, size, base in self.ranges:
            if base <= off < base + size:
                return start + (off - base)
        return None

    def find_all(self, needle: bytes, limit: int = 100000) -> list[int]:
        out: list[int] = []
        pos = 0
        mm = self.mm
        while len(out) < limit:
            found = mm.find(needle, pos)
            if found < 0:
                break
            out.append(found)
            pos = found + 1
        return out

    def find_all_multi(self, needles: Iterable[bytes], limit_each: int = 100000) -> dict[bytes, list[int]]:
        return {needle: self.find_all(needle, limit_each) for needle in needles}

    def close(self) -> None:
        try:
            self.mm.close()
        finally:
            self.f.close()


class MemFile:
    """Deterministic read-only virtual-address memory fixture."""

    def __init__(self, data: bytes | bytearray, *, base: int = 0x10000000):
        self.data = bytes(data)
        self.base = int(base)
        self.ranges = [(self.base, len(self.data), 0)]
        self.starts = [self.base]
        self.total = len(self.data)

    def read(self, va: int, n: int) -> bytes | None:
        off = int(va) - self.base
        if n <= 0 or off < 0 or off + n > len(self.data):
            return None
        return self.data[off:off + n]

    def u64(self, va: int) -> int | None:
        data = self.read(va, 8)
        return None if data is None else struct.unpack("<Q", data)[0]

    def off_to_va(self, off: int) -> int | None:
        return self.base + int(off) if 0 <= int(off) < len(self.data) else None

    def find_all(self, needle: bytes, limit: int = 100000) -> list[int]:
        out: list[int] = []
        pos = 0
        while len(out) < limit:
            found = self.data.find(needle, pos)
            if found < 0:
                break
            out.append(found)
            pos = found + 1
        return out

    def find_all_multi(self, needles: Iterable[bytes], limit_each: int = 100000) -> dict[bytes, list[int]]:
        return {needle: self.find_all(needle, limit_each) for needle in needles}

    def close(self) -> None:
        return None


class LiveProcess:
    """Explicit read-only virtual-address view of another process."""

    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_VM_READ = 0x0010
    MEM_COMMIT = 0x1000
    MEM_PRIVATE = 0x20000
    PAGE_GUARD = 0x100
    PAGE_NOACCESS = 0x01
    READABLE = (0x02 | 0x04 | 0x20 | 0x40 | 0x80)

    def __init__(self, pid: int, *, exclude_pid: int | None = None, chunk: int = 8 << 20):
        if exclude_pid is None:
            exclude_pid = os.getpid()
        pid = int(pid)
        if pid == int(exclude_pid):
            raise ValueError("live recovery requires an explicit other Blender process; current process is excluded")
        import ctypes
        from ctypes import wintypes
        self.pid = pid
        self.ctypes = ctypes
        self.chunk = int(chunk)
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.k32 = k32
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.h = k32.OpenProcess(self.PROCESS_QUERY_INFORMATION | self.PROCESS_VM_READ, False, pid)
        if not self.h:
            err = ctypes.get_last_error()
            raise PermissionError("USER_ACTION_REQUIRED: OpenProcess(%d) failed with Win32 error %d; run with sufficient permission or provide a dump" % (pid, err))

        class MBI(ctypes.Structure):
            _fields_ = [
                ("BaseAddress", ctypes.c_void_p),
                ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wintypes.DWORD),
                ("__align", wintypes.DWORD),
                ("RegionSize", ctypes.c_size_t),
                ("State", wintypes.DWORD),
                ("Protect", wintypes.DWORD),
                ("Type", wintypes.DWORD),
                ("__align2", wintypes.DWORD),
            ]

        self._MBI = MBI
        k32.VirtualQueryEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MBI), ctypes.c_size_t]
        k32.VirtualQueryEx.restype = ctypes.c_size_t
        k32.ReadProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        k32.ReadProcessMemory.restype = wintypes.BOOL
        ranges: list[list[int]] = []
        addr = 0
        mbi = MBI()
        while addr < (1 << 47):
            got = k32.VirtualQueryEx(self.h, ctypes.c_void_p(addr), ctypes.byref(mbi), ctypes.sizeof(mbi))
            if not got:
                break
            base = int(mbi.BaseAddress or 0)
            size = int(mbi.RegionSize or 0)
            if size <= 0:
                break
            prot = int(mbi.Protect)
            if int(mbi.State) == self.MEM_COMMIT and (prot & self.READABLE) and int(mbi.Type) == self.MEM_PRIVATE and not (prot & self.PAGE_GUARD) and not (prot & self.PAGE_NOACCESS):
                ranges.append([base, size])
            addr = base + size
        ranges.sort()
        merged: list[list[int]] = []
        for r in ranges:
            if merged and merged[-1][0] + merged[-1][1] == r[0]:
                merged[-1][1] += r[1]
            else:
                merged.append(list(r))
        self.ranges = [(b, s, 0) for b, s in merged]
        self.starts = [b for b, _s, _o in self.ranges]
        self.total = sum(s for _b, s, _o in self.ranges)

    def read(self, va: int, n: int) -> bytes | None:
        if n <= 0 or n > (1 << 31):
            return None
        ctypes = self.ctypes
        buf = ctypes.create_string_buffer(n)
        got = ctypes.c_size_t(0)
        ok = self.k32.ReadProcessMemory(self.h, ctypes.c_void_p(int(va)), buf, n, ctypes.byref(got))
        if not ok or got.value != n:
            return None
        return buf.raw

    def u64(self, va: int) -> int | None:
        data = self.read(va, 8)
        return None if data is None else struct.unpack("<Q", data)[0]

    def off_to_va(self, off: int) -> int | None:
        return int(off)

    def find_all(self, needle: bytes, limit: int = 100000) -> list[int]:
        out: list[int] = []
        overlap = max(0, len(needle) - 1)
        for base, size, _o in self.ranges:
            pos = 0
            while pos < size and len(out) < limit:
                want = min(self.chunk, size - pos)
                data = self.read(base + pos, want)
                if data is None:
                    pos += want
                    continue
                cursor = 0
                while len(out) < limit:
                    found = data.find(needle, cursor)
                    if found < 0:
                        break
                    out.append(base + pos + found)
                    cursor = found + 1
                if want < self.chunk:
                    break
                pos += want - overlap
        return out

    def find_all_multi(self, needles: Iterable[bytes], limit_each: int = 100000) -> dict[bytes, list[int]]:
        needles = list(needles)
        out: dict[bytes, list[int]] = {n: [] for n in needles}
        if not needles:
            return out
        overlap = max(len(n) for n in needles) - 1
        for base, size, _o in self.ranges:
            pos = 0
            while pos < size:
                want = min(self.chunk, size - pos)
                data = self.read(base + pos, want)
                if data is None:
                    pos += want
                    continue
                for needle in needles:
                    acc = out[needle]
                    if len(acc) >= limit_each:
                        continue
                    cursor = 0
                    while len(acc) < limit_each:
                        found = data.find(needle, cursor)
                        if found < 0:
                            break
                        acc.append(base + pos + found)
                        cursor = found + 1
                if want < self.chunk:
                    break
                pos += want - overlap
        return out

    def close(self) -> None:
        try:
            self.k32.CloseHandle(self.h)
        except Exception:
            pass


def open_source(spec: str, *, current_pid: int | None = None):
    text = str(spec or "")
    if text.lower().startswith("pid:"):
        pid = int(text.split(":", 1)[1])
        return LiveProcess(pid, exclude_pid=os.getpid() if current_pid is None else int(current_pid))
    path = Path(text)
    with path.open("rb") as handle:
        head = handle.read(4)
    if head == b"MDMP":
        return Dump(text)
    return MemFile(path.read_bytes())


class SDNA:
    def __init__(self, buf: bytes):
        if buf[:4] != b"SDNA":
            raise ValueError("bad SDNA block")
        p = 4
        if buf[p:p + 4] != b"NAME":
            raise ValueError("bad SDNA NAME section")
        p += 4
        n = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.names: list[str] = []
        for _ in range(n):
            end = buf.index(b"\0", p)
            self.names.append(buf[p:end].decode("ascii", "replace"))
            p = end + 1
        p = (p + 3) & ~3
        if buf[p:p + 4] != b"TYPE":
            raise ValueError("bad SDNA TYPE section")
        p += 4
        n = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.types: list[str] = []
        for _ in range(n):
            end = buf.index(b"\0", p)
            self.types.append(buf[p:end].decode("ascii", "replace"))
            p = end + 1
        p = (p + 3) & ~3
        if buf[p:p + 4] != b"TLEN":
            raise ValueError("bad SDNA TLEN section")
        p += 4
        self.tlens = list(struct.unpack_from("<%dH" % len(self.types), buf, p))
        p += 2 * len(self.types)
        p = (p + 3) & ~3
        if buf[p:p + 4] != b"STRC":
            raise ValueError("bad SDNA STRC section")
        p += 4
        nstr = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.structs: list[tuple[int, list[tuple[int, int]]]] = []
        for _ in range(nstr):
            tidx, nf = struct.unpack_from("<HH", buf, p)
            p += 4
            fields: list[tuple[int, int]] = []
            for _ in range(nf):
                ft, fn = struct.unpack_from("<HH", buf, p)
                p += 4
                fields.append((ft, fn))
            self.structs.append((tidx, fields))
        self.by_name = {self.types[tidx]: si for si, (tidx, _fields) in enumerate(self.structs)}
        self._cache: dict[str, dict[str, tuple[int, int, str]]] = {}

    def _fsize(self, field_type: int, field_name: str) -> int:
        size = PTR if field_name.startswith("*") else self.tlens[field_type]
        for item in re.findall(r"\[(\d+)\]", field_name):
            size *= int(item)
        return size

    def layout(self, struct_name: str) -> dict[str, tuple[int, int, str]]:
        if struct_name in self._cache:
            return self._cache[struct_name]
        si = self.by_name[struct_name]
        off = 0
        layout: dict[str, tuple[int, int, str]] = {}
        for field_type, field_name_index in self.structs[si][1]:
            name = self.names[field_name_index]
            key = name.lstrip("*").split("[")[0]
            size = self._fsize(field_type, name)
            if key not in layout:
                layout[key] = (off, size, self.types[field_type])
            off += size
        self._cache[struct_name] = layout
        return layout

    def struct_size(self, struct_name: str) -> int:
        return self.tlens[self.structs[self.by_name[struct_name]][0]]

    def name_of(self, struct_index: int) -> str:
        if 0 <= struct_index < len(self.structs):
            return self.types[self.structs[struct_index][0]]
        return "?"


def parse_blocks(data: bytes) -> list[tuple[bytes, int, int, int, int, int, int]]:
    p = len(BLEND_HDR)
    out: list[tuple[bytes, int, int, int, int, int, int]] = []
    total = len(data)
    while p + BHEAD <= total:
        code = data[p:p + 4]
        sdna_index = struct.unpack_from("<I", data, p + 4)[0]
        old = struct.unpack_from("<Q", data, p + 8)[0]
        block_len = struct.unpack_from("<Q", data, p + 16)[0]
        nr = struct.unpack_from("<I", data, p + 24)[0]
        flags = struct.unpack_from("<I", data, p + 28)[0]
        out.append((code, old, block_len, sdna_index, nr, flags, p + BHEAD))
        if code == b"ENDB" or block_len > (1 << 32):
            break
        p += BHEAD + int(block_len)
    return out


def _plausible_ptr(value: int | None) -> bool:
    return bool(value and 0x10000 < int(value) < 0x7FFFFFFFFFFF and (int(value) & 7) == 0)


def find_undo_chains(source, *, max_steps: int = 200, min_step_bytes: int = DEFAULT_MIN_STEP_BYTES) -> list[dict[str, Any]]:
    progress("scan", 5, "scanning blend streams")
    heads = source.find_all(BLEND_HDR)
    header_vas: list[int] = []
    for head in heads:
        va = source.off_to_va(head)
        if va is not None:
            header_vas.append(int(va))
    needles = [struct.pack("<Q", va) for va in header_vas]
    hits = source.find_all_multi(needles)
    candidate_chunk_heads: list[int] = []
    for needle in needles:
        for hit in hits.get(needle, ()):
            hva = source.off_to_va(hit)
            if hva is not None:
                candidate_chunk_heads.append(int(hva) - 16)
    seen: dict[str, dict[str, Any]] = {}
    for i, base in enumerate(candidate_chunk_heads):
        if len(seen) >= max_steps:
            break
        if i % 64 == 0:
            progress("scan", 5 + int(35.0 * i / max(1, len(candidate_chunk_heads))), "analyzing undo chains")
        next_ptr = source.u64(base)
        prev_ptr = source.u64(base + 8)
        size = source.u64(base + 24)
        if size is None or not (0 < int(size) <= MAX_CHUNK_BYTES):
            continue
        if not (_plausible_ptr(next_ptr) or int(next_ptr or 0) == 0):
            continue
        if prev_ptr:
            continue
        digest = hashlib.blake2b(digest_size=16)
        plan: list[tuple[int, int]] = []
        buffers: list[int] = []
        total = 0
        chunks = 0
        cur = int(base)
        guard: set[int] = set()
        ok = True
        while cur and cur not in guard:
            guard.add(cur)
            buf = source.u64(cur + 16)
            chunk_size = source.u64(cur + 24)
            nx = source.u64(cur)
            if buf is None or chunk_size is None or not (0 < int(chunk_size) <= MAX_CHUNK_BYTES):
                ok = False
                break
            data = source.read(int(buf), int(chunk_size))
            if data is None:
                ok = False
                break
            digest.update(data)
            plan.append((int(buf), int(chunk_size)))
            buffers.append(int(buf))
            total += int(chunk_size)
            chunks += 1
            if not nx:
                break
            cur = int(nx)
        if not ok or total < int(min_step_bytes):
            continue
        key = digest.hexdigest()
        if key not in seen:
            seen[key] = {"plan": plan, "chunks": chunks, "bytes": total, "head": int(base), "bufs": set(buffers), "digest": key}
    steps = sorted(seen.values(), key=lambda step: int(step["head"]))
    owners: collections.Counter[int] = collections.Counter()
    for step in steps:
        for buf in step["bufs"]:
            owners[int(buf)] += 1
    for index, step in enumerate(steps):
        step["index"] = index
        step["unique_bufs"] = sum(1 for buf in step["bufs"] if owners[int(buf)] == 1)
        del step["bufs"]
    return steps


def materialize_step(step: dict[str, Any], source) -> bytes:
    out = bytearray()
    for ptr, size in step.get("plan", ()):
        chunk = source.read(int(ptr), int(size))
        if chunk is None:
            raise RuntimeError("step chunk is no longer readable")
        out.extend(chunk)
    data = bytes(out)
    if not data.startswith(BLEND_HDR):
        raise ValueError("materialized step does not start with the expected Blender header")
    return data


def _tagged_shared_ptr(value: int) -> bool:
    return (int(value) >> 48) == SHARED_TAG and (1 << 32) < (int(value) & MASK48) < 0x7FFFFFFFFFFF


def inline_shared(blob: bytes, source, stats: collections.Counter | None = None) -> tuple[bytes, collections.Counter]:
    """Bounded implicit-sharing resolver.

    The resolver parses DNA and known DATA scopes before deciding whether to add
    materialized DATA blocks. Unsupported layouts fail open by returning the
    original blob with a skip statistic; they do not fall back to a first-header
    copy.
    """
    stats = stats if stats is not None else collections.Counter()
    try:
        blocks = parse_blocks(blob)
        dna = next(block for block in blocks if block[0] == b"DNA1")
        sdna = SDNA(blob[dna[6]:dna[6] + dna[2]])
    except Exception:
        stats["skip_no_parseable_sdna"] += 1
        return blob, stats
    inserts: dict[int, list[tuple[int, bytes]]] = collections.defaultdict(list)

    def add(after_block, old_val: int, payload: bytes) -> None:
        if payload:
            inserts[int(after_block[6] + after_block[2])].append((int(old_val), payload))

    def fetch(ptr: int, nbytes: int) -> bytes | None:
        if nbytes <= 0 or nbytes > MAX_CHUNK_BYTES:
            return None
        return source.read(int(ptr) & MASK48, int(nbytes))

    try:
        mesh_layout = sdna.layout("Mesh")
        attr_layout = sdna.layout("Attribute")
        attr_storage_layout = sdna.layout("AttributeStorage")
        attr_array_layout = sdna.layout("AttributeArray")
        custom_data_layer_layout = sdna.layout("CustomDataLayer")
        packed_layout = sdna.layout("PackedFile")
        attr_size = sdna.struct_size("Attribute")
        custom_data_layer_size = sdna.struct_size("CustomDataLayer")
    except Exception:
        stats["skip_unknown_51_layout"] += 1
        return blob, stats

    u64 = lambda off: struct.unpack_from("<Q", blob, off)[0]
    i64 = lambda off: struct.unpack_from("<q", blob, off)[0]
    i32 = lambda off: struct.unpack_from("<i", blob, off)[0]
    i16 = lambda off: struct.unpack_from("<h", blob, off)[0]
    i8 = lambda off: struct.unpack_from("<b", blob, off)[0]

    idx = 0
    while idx < len(blocks):
        block = blocks[idx]
        code = block[0].rstrip(b"\x00")
        if not (len(code) == 2 and code.isalpha()):
            idx += 1
            continue
        scope: list[tuple[bytes, int, int, int, int, int, int]] = []
        j = idx + 1
        while j < len(blocks) and blocks[j][0] == b"DATA":
            scope.append(blocks[j])
            j += 1
        by_old: dict[int, list[tuple[bytes, int, int, int, int, int, int]]] = collections.defaultdict(list)
        for data_block in scope:
            by_old[int(data_block[1])].append(data_block)

        def scoped_block(ptr: int, want: int | None = None):
            for data_block in by_old.get(int(ptr), ()):
                if want is None or int(data_block[2]) == int(want):
                    return data_block
            return None

        def do_attr_table(table_block, count: int) -> None:
            for attr_index in range(max(0, int(count))):
                off = int(table_block[6]) + attr_index * attr_size
                dtype = i16(off + attr_layout["data_type"][0])
                storage_type = i8(off + attr_layout["storage_type"][0])
                storage_block = scoped_block(u64(off + attr_layout["data"][0]), 32 if storage_type == 0 else 16)
                if storage_block is None:
                    continue
                array_ptr = u64(int(storage_block[6]))
                if not _tagged_shared_ptr(array_ptr):
                    continue
                n_items = i64(int(storage_block[6]) + attr_array_layout["size"][0]) if storage_type == 0 else 1
                elem = ATTR_ELEM.get(int(dtype))
                if elem is None:
                    stats["skip_unknown_attribute_type"] += 1
                    continue
                raw = fetch(array_ptr, int(n_items) * int(elem))
                if raw is None:
                    stats["missing_attribute_array"] += 1
                    continue
                add(storage_block, array_ptr, raw)
                stats["attribute_arrays"] += 1

        total_vertices = 0
        if code == b"ME":
            data_off = int(block[6])
            total_vertices = i32(data_off + mesh_layout["totvert"][0])
            storage_off = mesh_layout["attribute_storage"][0]
            attr_count = i32(data_off + storage_off + attr_storage_layout["dna_attributes_num"][0])
            attr_table = scoped_block(u64(data_off + storage_off + attr_storage_layout["dna_attributes"][0]), attr_count * attr_size)
            if attr_table is not None:
                do_attr_table(attr_table, attr_count)
            poly_offset = u64(data_off + mesh_layout["poly_offset_indices"][0])
            total_poly = i32(data_off + mesh_layout["totpoly"][0])
            if _tagged_shared_ptr(poly_offset) and total_poly:
                raw = fetch(poly_offset, (total_poly + 1) * 4)
                if raw is not None:
                    add(block, poly_offset, raw)
                    stats["face_offset_arrays"] += 1
        else:
            for data_block in scope:
                if sdna.name_of(data_block[3]) == "Attribute" and attr_size and int(data_block[2]) % attr_size == 0:
                    do_attr_table(data_block, int(data_block[2]) // attr_size)
        for data_block in scope:
            struct_name = sdna.name_of(data_block[3])
            if struct_name == "CustomDataLayer":
                for layer_index in range(int(data_block[2]) // custom_data_layer_size):
                    off = int(data_block[6]) + layer_index * custom_data_layer_size
                    layer_type = i32(off + custom_data_layer_layout["type"][0])
                    ptr = u64(off + custom_data_layer_layout["data"][0])
                    if not _tagged_shared_ptr(ptr):
                        continue
                    if int(layer_type) == CD_MDEFORMVERT and total_vertices:
                        raw = fetch(ptr, total_vertices * 16)
                        if raw is not None:
                            add(data_block, ptr, raw)
                            stats["vertex_weight_layers"] += 1
                    else:
                        stats["skip_custom_data_layer"] += 1
            elif struct_name == "PackedFile":
                size = i32(int(data_block[6]) + packed_layout["size"][0])
                ptr = u64(int(data_block[6]) + packed_layout["data"][0])
                if _tagged_shared_ptr(ptr):
                    raw = fetch(ptr, size)
                    if raw is not None:
                        add(data_block, ptr, raw)
                        stats["packed_files"] += 1
        idx = j

    if not inserts:
        stats["no_inline_insertions"] += 1
        return blob, stats
    out = bytearray()
    pos = 0
    for cut in sorted(inserts.keys()):
        out.extend(blob[pos:cut])
        for old_val, payload in inserts[cut]:
            out.extend(struct.pack("<4sIQQII", b"DATA", 0, old_val, len(payload), 1, 0))
            out.extend(payload)
        pos = cut
    out.extend(blob[pos:])
    return bytes(out), stats


def summarize_step(blob: bytes) -> dict[str, Any]:
    info: dict[str, Any] = {"objects": 0, "meshes": 0, "materials": 0, "images": 0, "actions": 0, "collections": 0, "totvert": 0, "totpoly": 0, "blend_path": ""}
    try:
        blocks = parse_blocks(blob)
        dna = next(block for block in blocks if block[0] == b"DNA1")
        sdna = SDNA(blob[dna[6]:dna[6] + dna[2]])
    except Exception:
        return info
    counts: collections.Counter[str] = collections.Counter()
    try:
        mesh_layout = sdna.layout("Mesh")
    except Exception:
        mesh_layout = {}
    for block in blocks:
        code = block[0].rstrip(b"\x00")
        if len(code) == 2 and code.isalpha():
            counts[code.decode("ascii", "replace")] += 1
            if code == b"ME" and mesh_layout:
                try:
                    info["totvert"] += struct.unpack_from("<i", blob, block[6] + mesh_layout["totvert"][0])[0]
                    info["totpoly"] += struct.unpack_from("<i", blob, block[6] + mesh_layout["totpoly"][0])[0]
                except Exception:
                    pass
    info.update(objects=counts.get("OB", 0), meshes=counts.get("ME", 0), materials=counts.get("MA", 0), images=counts.get("IM", 0), actions=counts.get("AC", 0), collections=counts.get("GR", 0))
    try:
        fg_layout = sdna.layout("FileGlobal")
        key = "filename" if "filename" in fg_layout else "filepath"
        off, size, _typ = fg_layout[key]
        for block in blocks:
            if sdna.name_of(block[3]) == "FileGlobal":
                raw = blob[block[6] + off:block[6] + off + size]
                info["blend_path"] = raw.split(b"\x00")[0].decode("utf-8", "replace")
                break
    except Exception:
        pass
    return info


def rank_steps(steps: list[dict[str, Any]], expectations: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    expectations = expectations or {}
    expected_active = str(expectations.get("active", "") or "")
    expected_actcol = expectations.get("actcol")
    scored: list[tuple[tuple[int, int, int, int], dict[str, Any]]] = []
    for step in steps:
        info = step.get("info") if isinstance(step.get("info"), dict) else {}
        score = 0
        if expected_active and str(info.get("active", "")) == expected_active:
            score += 1000
        if expected_actcol is not None and int(info.get("actcol", -999)) == int(expected_actcol):
            score += 500
        score += int(step.get("unique_bufs", 0)) * 10
        score += min(int(step.get("bytes", 0)) // (1 << 20), 200)
        scored.append(((score, int(step.get("head", 0)), int(step.get("index", 0)), int(step.get("chunks", 0))), step))
    scored.sort(key=lambda item: item[0], reverse=True)
    for rank, (_score, step) in enumerate(scored):
        step["rank"] = rank
    return [step for _score, step in scored]


def analyze_source(spec: str, *, max_summary_steps: int = 32, min_step_bytes: int = DEFAULT_MIN_STEP_BYTES) -> dict[str, Any]:
    src = open_source(spec)
    try:
        steps = find_undo_chains(src, min_step_bytes=min_step_bytes)
        for step in steps[:max_summary_steps]:
            try:
                step["info"] = summarize_step(materialize_step(step, src))
            except Exception as exc:
                step["info"] = {"summary_error": f"{type(exc).__name__}: {exc}"}
        ranked = rank_steps(steps)
        return {
            "schema": SCHEMA_ANALYZE,
            "engine": ENGINE_VERSION,
            "generated": _now_text(),
            "source": spec,
            "steps": [_public_step(step) for step in ranked],
        }
    finally:
        try:
            src.close()
        except Exception:
            pass


def _public_step(step: dict[str, Any]) -> dict[str, Any]:
    return {
        "index": int(step.get("index", -1)),
        "rank": int(step.get("rank", 999999)),
        "chunks": int(step.get("chunks", 0)),
        "bytes": int(step.get("bytes", 0)),
        "unique_bufs": int(step.get("unique_bufs", 0)),
        "digest": str(step.get("digest", "")),
        "info": step.get("info", {}),
    }


def _atomic_write(path: Path, data: bytes) -> None:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"destination already exists: {path}")
    part = path.with_name(path.name + ".part")
    if part.exists():
        part.unlink()
    with part.open("wb") as handle:
        handle.write(data)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except Exception:
            pass
    os.replace(str(part), str(path))


def extract_step(spec: str, step_index: int, destination: str | os.PathLike[str], *, min_step_bytes: int = DEFAULT_MIN_STEP_BYTES) -> dict[str, Any]:
    src = open_source(spec)
    try:
        steps = find_undo_chains(src, min_step_bytes=min_step_bytes)
        matches = [step for step in steps if int(step.get("index", -1)) == int(step_index)]
        if not matches:
            raise IndexError("recovery step index not found")
        step = matches[0]
        raw = materialize_step(step, src)
        repaired, inline_stats = inline_shared(raw, src)
        out = Path(destination).resolve()
        _atomic_write(out, repaired)
        return {
            "schema": SCHEMA_EXTRACT,
            "engine": ENGINE_VERSION,
            "generated": _now_text(),
            "status": "PASS",
            "source": spec,
            "selected_step": _public_step(step),
            "destination": str(out),
            "destination_size": out.stat().st_size,
            "destination_sha256": _sha256_file(out),
            "inline_stats": dict(inline_stats),
        }
    finally:
        try:
            src.close()
        except Exception:
            pass


def rescue_best(spec: str, destination: str | os.PathLike[str], *, min_step_bytes: int = DEFAULT_MIN_STEP_BYTES) -> dict[str, Any]:
    src = open_source(spec)
    try:
        steps = find_undo_chains(src, min_step_bytes=min_step_bytes)
        if not steps:
            raise RuntimeError("no recovery steps found")
        for step in steps:
            try:
                step["info"] = summarize_step(materialize_step(step, src))
            except Exception as exc:
                step["info"] = {"summary_error": f"{type(exc).__name__}: {exc}"}
        ranked = rank_steps(steps)
        best = ranked[0]
        raw = materialize_step(best, src)
        repaired, inline_stats = inline_shared(raw, src)
        out = Path(destination).resolve()
        _atomic_write(out, repaired)
        return {
            "schema": SCHEMA_RESCUE,
            "engine": ENGINE_VERSION,
            "generated": _now_text(),
            "status": "PASS",
            "source": spec,
            "selected_step": _public_step(best),
            "steps": [_public_step(step) for step in ranked],
            "destination": str(out),
            "destination_size": out.stat().st_size,
            "destination_sha256": _sha256_file(out),
            "inline_stats": dict(inline_stats),
        }
    finally:
        try:
            src.close()
        except Exception:
            pass


def write_json(path: str | os.PathLike[str], payload: dict[str, Any]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main(argv: list[str]) -> int:
    try:
        if len(argv) >= 4 and argv[1] == "analyze":
            write_json(argv[3], analyze_source(argv[2]))
            return 0
        if len(argv) >= 5 and argv[1] == "extract":
            write_json(argv[4] + ".json", extract_step(argv[2], int(argv[3]), argv[4]))
            return 0
        if len(argv) >= 4 and argv[1] == "rescue":
            payload = rescue_best(argv[2], argv[3])
            if len(argv) >= 5:
                write_json(argv[4], payload)
            return 0
        raise SystemExit("usage: crash_recovery_engine.py analyze <dump|pid:N> <out.json> | extract <dump|pid:N> <step-index> <out.blend> | rescue <dump|pid:N> <out.blend> [out.json]")
    except Exception as exc:
        if len(argv) >= 3:
            sys.stderr.write(f"{type(exc).__name__}: {exc}\n")
        return 3


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
