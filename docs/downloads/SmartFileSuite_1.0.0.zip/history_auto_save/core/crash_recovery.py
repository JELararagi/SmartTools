from __future__ import annotations

if __package__:
    from ...ui_language_runtime import ui_text as _ui_text
else:
    # ワーカーとして単独で起動された時はパッケージが無いので、文は英語のまま書く
    def _ui_text(en, ja):
        return en
import hashlib
import ctypes
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Iterable

try:
    from bpy.app.handlers import persistent  # type: ignore
except Exception:
    def persistent(func):
        return func


SCHEMA_SCAN = "smart_file_crash_recovery/scan/1"
SCHEMA_COPY = "smart_file_crash_recovery/copy/1"
SCHEMA_DEEP = "smart_file_crash_recovery/deep/1"
SCHEMA_ORIGINAL_CHAIN = "smart_file_crash_recovery/original_chain/1"
STATE_KEY = "smart_file_crash_recovery_state_v1"
TIMER_KEY = "smart_file_crash_recovery_timer_v1"
HANDLERS_KEY = "smart_file_crash_recovery_handlers_v1"
BLENDER_HEADER = b"BLENDER"
ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"
EXTERNAL_CRASH_KIND = "external_crash_process"
_CRASH_TITLE_RE = re.compile(r"(not responding|応答なし|crash|クラッシュ|fatal|exception|access violation|application error|アプリケーション エラー)", re.I)
LEASE_SCHEMA = "smart_file_crash_recovery/lease/1"
LEASE_TTL_SECONDS = 15 * 60
_OWNED_HANDLER_NAMES = frozenset({
    "_save_pre_reset_runtime",
    "_load_post_reset_runtime",
})
_THIS_CODE_FILENAME = os.path.normcase(str(Path(__file__).resolve()))
_THIS_CODE_BASENAME = Path(_THIS_CODE_FILENAME).name


def _now_text() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def _safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._ -]+", "_", str(value or "Recovered")).strip(" ._")
    return text or "Recovered"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def _read_head(path: Path, want: int = 1 << 18) -> bytes:
    try:
        with path.open("rb") as handle:
            # zstd の .blend は圧縮後の先頭 want バイトでは展開できないので、多めに読む
            raw = handle.read(max(want, 1 << 18))
    except Exception:
        return b""
    if raw[:4] != ZSTD_MAGIC:
        return raw[:want]
    try:
        import io
        import zstandard

        out: list[bytes] = []
        got = 0
        with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw)) as reader:
            while got < want:
                chunk = reader.read(min(65536, want - got))
                if not chunk:
                    break
                out.append(chunk)
                got += len(chunk)
        return b"".join(out)
    except Exception:
        return b""


def is_readable_blend_header(path: str | os.PathLike[str]) -> bool:
    try:
        p = Path(path)
        return p.is_file() and p.stat().st_size > 12 and _read_head(p, 16).startswith(BLENDER_HEADER)
    except Exception:
        return False


_PATH_RE = re.compile(rb"[A-Za-z]:[\\/][^\x00\r\n]{0,700}?\.blend\b")
_HISTORY_RE = re.compile(r"[\\/]Smart_File_Suite[\\/]history[\\/](?P<project>[^\\/]+)[\\/]", re.I)
_AUTOSAVE_RE = re.compile(r"^(?P<stem>.+?)_Autosave_\d+$", re.I)
_RESTORE_RE = re.compile(r"^(?P<stem>.+?)__restore_points__.*$", re.I)
_BLENDER_AUTOSAVE_RE = re.compile(r"^(?P<stem>.+?)_\d+_autosave$", re.I)
_RECOVERED_RE = re.compile(r"^(?P<stem>.+?)_recovered(?:[_.].*)?$", re.I)


def blend_self_path(path: str | os.PathLike[str]) -> str:
    head = _read_head(Path(path))
    if not head.startswith(BLENDER_HEADER):
        return ""
    pos = 12
    size = len(head)
    while pos + 24 <= size:
        code = head[pos:pos + 4]
        try:
            block_len = int.from_bytes(head[pos + 16:pos + 24], "little", signed=False)
        except Exception:
            break
        data_pos = pos + 24
        if code == b"GLOB":
            match = _PATH_RE.search(head[data_pos:data_pos + min(block_len, 8192)])
            return match.group(0).decode("utf-8", "replace") if match else ""
        if code == b"ENDB" or block_len > (1 << 32):
            break
        pos = data_pos + block_len
    return ""


def scene_key_for(path: Path) -> tuple[str, bool]:
    name = path.name
    stem = path.stem
    low_name = name.lower()
    norm = str(path).replace("/", "\\")
    match = _HISTORY_RE.search(norm)
    if match:
        return match.group("project"), False
    if low_name.endswith((".blend1", ".blend2")):
        return Path(name).stem, False
    if low_name == "quit.blend" or low_name.endswith(".crash.blend"):
        return "", True
    for rx in (_AUTOSAVE_RE, _RESTORE_RE, _BLENDER_AUTOSAVE_RE, _RECOVERED_RE):
        found = rx.match(stem)
        if found:
            return found.group("stem"), False
    return stem, False


def candidate_kind(path: Path, home_dir: Path | None, scene_stem: str) -> tuple[str, str]:
    low = str(path).lower().replace("\\", "/")
    stem = path.stem
    if _RECOVERED_RE.match(stem):
        return "recovered", "Recovered file"
    if low.endswith(".blend1"):
        return "backup", "Previous save (.blend1)"
    if low.endswith(".blend2"):
        return "backup", "Earlier save (.blend2)"
    if "restore_points" in low:
        return "restore", "Restore point"
    if "autosaves" in low:
        return "autosave", "Smart File autosave"
    if path.name.lower().endswith("_autosave.blend"):
        return "autosave", "Blender autosave"
    if path.name.lower() == "quit.blend":
        return "quit", "Quit recovery file"
    if low.endswith(".crash.blend"):
        return "crash", "Crash-written blend"
    if home_dir is not None and path.parent.resolve() == home_dir.resolve() and stem.lower() == scene_stem.lower():
        return "self", "Saved file"
    return "other", "Related blend"


def _collect_window_rows() -> list[dict[str, Any]]:
    if os.name != "nt":
        return []
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.WinDLL("user32", use_last_error=True)
        rows: list[dict[str, Any]] = []
        enum_proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        is_hung = getattr(user32, "IsHungAppWindow", None)

        def callback(hwnd, _lparam):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True
                pid = wintypes.DWORD(0)
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                length = int(user32.GetWindowTextLengthW(hwnd) or 0)
                title = ""
                if length > 0:
                    buf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buf, length + 1)
                    title = buf.value
                class_buf = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, class_buf, 256)
                rows.append({
                    "pid": int(pid.value),
                    "title": title,
                    "class_name": class_buf.value,
                    "hung": bool(is_hung(hwnd)) if callable(is_hung) else False,
                })
            except Exception:
                pass
            return True

        user32.EnumWindows(enum_proc_type(callback), 0)
        return rows
    except Exception:
        return []


def _collect_blender_process_rows() -> list[dict[str, Any]]:
    if os.name != "nt":
        return []
    ps = (
        "$ErrorActionPreference='SilentlyContinue'; "
        "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; "
        "Get-CimInstance Win32_Process -Filter \"name='blender.exe'\" | "
        "ForEach-Object { $p = Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue; "
        "[pscustomobject]@{pid=[int]$_.ProcessId; executable_path=[string]$_.ExecutablePath; "
        "command_line=[string]$_.CommandLine; responding=if($p){[bool]$p.Responding}else{$false}; "
        "main_window_title=if($p){[string]$p.MainWindowTitle}else{''}} } | ConvertTo-Json -Compress"
    )
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            encoding="utf-8",
            errors="replace",
            timeout=5.0,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
        )
        data = json.loads(proc.stdout or "[]")
        if isinstance(data, dict):
            data = [data]
        return [row for row in data if isinstance(row, dict)]
    except Exception:
        return []


def _process_row_pid(row: dict[str, Any]) -> int:
    for key in ("pid", "ProcessId", "process_id"):
        try:
            value = int(row.get(key, 0) or 0)
            if value > 0:
                return value
        except Exception:
            pass
    return 0


def _is_helper_or_background_blender(row: dict[str, Any]) -> bool:
    command = str(row.get("command_line", row.get("CommandLine", "")) or "").lower()
    path = str(row.get("executable_path", row.get("ExecutablePath", "")) or "").lower()
    if "blender_driver.py" in command or "mcp\\blender" in command or "mcp/blender" in command:
        return True
    if " --background" in command or " -b" in command or command.strip().endswith(" -b"):
        return True
    if path and not path.endswith("blender.exe"):
        return True
    return False


def _crash_signal_for(pid: int, row: dict[str, Any], window_rows: Iterable[dict[str, Any]]) -> str:
    if bool(row.get("crash_signal", False)):
        return str(row.get("crash_signal_text", "fixture crash signal"))
    for win in window_rows:
        try:
            if int(win.get("pid", 0) or 0) != int(pid):
                continue
            class_name = str(win.get("class_name", win.get("class", "")) or "")
            if class_name != "#32770":
                continue
            win_title = str(win.get("title", "") or "")
            if win_title and _CRASH_TITLE_RE.search(win_title):
                return f"visible crash dialog: {win_title}"
        except Exception:
            pass
    return ""


def discover_external_crash_processes(
    *,
    current_pid: int | None = None,
    process_rows: Iterable[dict[str, Any]] | None = None,
    window_rows: Iterable[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    current = os.getpid() if current_pid is None else int(current_pid)
    rows = list(process_rows) if process_rows is not None else _collect_blender_process_rows()
    windows = list(window_rows) if window_rows is not None else _collect_window_rows()
    out: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        pid = _process_row_pid(row)
        if pid <= 0 or pid == current:
            continue
        if _is_helper_or_background_blender(row):
            continue
        signal = _crash_signal_for(pid, row, windows)
        if not signal:
            continue
        out.append({
            "pid": pid,
            "path": f"pid:{pid}",
            "label": "External crashed Blender",
            "kind": EXTERNAL_CRASH_KIND,
            "crash_signal": signal,
            "command_line": str(row.get("command_line", row.get("CommandLine", "")) or ""),
            "executable_path": str(row.get("executable_path", row.get("ExecutablePath", "")) or ""),
            "valid_blend_header": False,
            "recommended": True,
            "suspect_small": False,
            "size": 0,
            "mtime": time.time(),
            "mtime_text": time.strftime("%Y/%m/%d %H:%M:%S", time.localtime()),
        })
    return sorted(out, key=lambda item: int(item.get("pid", 0)))


def _config_roots() -> list[Path]:
    roots: list[Path] = []
    for env_name in ("BLENDER_USER_CONFIG", "APPDATA"):
        value = os.environ.get(env_name)
        if not value:
            continue
        root = Path(value)
        if env_name == "APPDATA":
            root = root / "Blender Foundation" / "Blender" / "5.1" / "config"
        roots.append(root)
    return roots


def _add_file(path: Path, seen: set[str], out: list[Path]) -> None:
    try:
        resolved = path.resolve()
        key = os.path.normcase(str(resolved))
        if key in seen or not resolved.is_file():
            return
        if not resolved.name.lower().endswith((".blend", ".blend1", ".blend2")):
            return
        seen.add(key)
        out.append(resolved)
    except Exception:
        return


def iter_candidate_files(roots: Iterable[str], *, include_ambient: bool = True) -> list[Path]:
    seen: set[str] = set()
    out: list[Path] = []
    scene_dirs: set[Path] = set()
    for raw in roots or ():
        if not raw:
            continue
        p = Path(raw)
        if p.is_dir():
            scene_dirs.add(p.resolve())
        elif p.is_file():
            _add_file(p, seen, out)
            scene_dirs.add(p.parent.resolve())
    if include_ambient:
        for config in _config_roots():
            recent = config / "recent-files.txt"
            try:
                for line in recent.read_text(encoding="utf-8", errors="replace").splitlines():
                    path = Path(line.strip())
                    if str(path).lower().endswith(".blend"):
                        _add_file(path, seen, out)
                        scene_dirs.add(path.parent.resolve())
            except Exception:
                pass
            history = config / "Smart_File_Suite" / "history"
            try:
                for p in history.rglob("*.blend"):
                    _add_file(p, seen, out)
            except Exception:
                pass
    for d in list(scene_dirs):
        try:
            for p in d.iterdir():
                if p.name.lower().endswith((".blend", ".blend1", ".blend2")):
                    _add_file(p, seen, out)
        except Exception:
            pass
    if include_ambient:
        for env_name in ("TEMP", "TMP"):
            temp = os.environ.get(env_name)
            if not temp:
                continue
            try:
                for p in Path(temp).iterdir():
                    low = p.name.lower()
                    if low.endswith(".blend") and (low.endswith("_autosave.blend") or low == "quit.blend" or low.endswith(".crash.blend")):
                        _add_file(p, seen, out)
            except Exception:
                pass
    return sorted(out, key=lambda item: str(item).lower())


def scan_to_payload(roots: Iterable[str], *, include_ambient: bool = True, include_external_crashes: bool = True) -> dict[str, Any]:
    files = iter_candidate_files(roots, include_ambient=include_ambient)
    scenes: dict[str, dict[str, Any]] = {}
    home_dirs: dict[str, Path] = {}
    for path in files:
        try:
            st = path.stat()
        except Exception:
            continue
        stem, needs_head = scene_key_for(path)
        self_path = blend_self_path(path) if needs_head else ""
        if self_path:
            stem = Path(self_path).stem
        if not stem:
            stem = path.stem
        key = stem.lower()
        scene = scenes.setdefault(key, {"scene_name": stem + ".blend", "scene_path": "", "home_dir": "", "candidates": []})
        if path.suffix.lower() == ".blend" and path.stem.lower() == key:
            scene["scene_path"] = str(path)
            home_dirs[key] = path.parent
        elif self_path and not scene["scene_path"]:
            scene["scene_path"] = self_path
        scene["candidates"].append({
            "path": str(path),
            "mtime": st.st_mtime,
            "mtime_text": time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(st.st_mtime)),
            "size": st.st_size,
            "self_path": self_path,
            "valid_blend_header": is_readable_blend_header(path),
        })
    out: list[dict[str, Any]] = []
    for key, scene in scenes.items():
        if not scene["scene_path"] and scene["candidates"]:
            scene["scene_path"] = scene["candidates"][0]["path"]
        home_dir = home_dirs.get(key) or (Path(scene["scene_path"]).parent if scene["scene_path"] else None)
        scene["home_dir"] = str(home_dir) if home_dir else ""
        stem = Path(scene["scene_name"]).stem
        for candidate in scene["candidates"]:
            kind, label = candidate_kind(Path(candidate["path"]), home_dir, stem)
            candidate["kind"] = kind
            candidate["label"] = label
        biggest = max((int(c.get("size", 0) or 0) for c in scene["candidates"] if c.get("valid_blend_header")), default=0)
        for candidate in scene["candidates"]:
            size = int(candidate.get("size", 0) or 0)
            candidate["suspect_small"] = bool(biggest and size < biggest * 0.6)
        priority = {"autosave": 0, "restore": 0, "quit": 1, "crash": 1, "self": 2, "backup": 2, "recovered": 8, "other": 9}
        ranked = sorted(scene["candidates"], key=lambda c: (
            1 if c.get("suspect_small") else 0,
            1 if not c.get("valid_blend_header") else 0,
            priority.get(str(c.get("kind")), 9),
            -float(c.get("mtime", 0) or 0),
        ))
        best_path = ranked[0]["path"] if ranked else ""
        for candidate in scene["candidates"]:
            candidate["recommended"] = candidate["path"] == best_path
        scene["candidates"].sort(key=lambda c: float(c.get("mtime", 0) or 0), reverse=True)
        scene["candidate_count"] = len(scene["candidates"])
        scene["recommended_path"] = best_path
        scene["newest_mtime"] = float(scene["candidates"][0].get("mtime", 0) or 0) if scene["candidates"] else 0.0
        out.append(scene)
    out.sort(key=lambda item: float(item.get("newest_mtime", 0) or 0), reverse=True)
    external = discover_external_crash_processes() if include_external_crashes else []
    if external:
        out.insert(0, {
            "scene_name": "External crashed Blender",
            "scene_path": "",
            "home_dir": "",
            "candidates": external,
            "candidate_count": len(external),
            "recommended_path": external[0]["path"],
            "newest_mtime": max(float(item.get("mtime", 0) or 0) for item in external),
        })
    return {
        "schema": SCHEMA_SCAN,
        "generated": _now_text(),
        "include_ambient_roots": bool(include_ambient),
        "include_external_crashes": bool(include_external_crashes),
        "scanned_files": len(files),
        "external_crash_processes": len(external),
        "scenes": out,
    }


def command_scan(out_json: str, roots: list[str], *, include_ambient: bool = True, include_external_crashes: bool = True) -> int:
    payload = scan_to_payload(roots, include_ambient=include_ambient, include_external_crashes=include_external_crashes)
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0


def _atomic_copy_blend(source: Path, destination: Path) -> dict[str, Any]:
    source = source.resolve()
    destination = destination.resolve()
    before = source.stat()
    if destination.exists():
        raise FileExistsError(_ui_text(f"Destination already exists: {destination}", f'保存先がすでにあります：{destination}'))
    if not is_readable_blend_header(source):
        raise ValueError(_ui_text(f"Source is not a readable .blend header: {source}", f'読める .blend ではありません：{source}'))
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_name(destination.name + ".part")
    if part.exists():
        part.unlink()
    with source.open("rb") as src, part.open("wb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
        dst.flush()
        try:
            os.fsync(dst.fileno())
        except Exception:
            pass
    os.replace(str(part), str(destination))
    after = source.stat()
    if before.st_size != after.st_size or int(before.st_mtime_ns) != int(after.st_mtime_ns):
        raise RuntimeError("Source metadata changed during recovery copy; destination was written but source integrity is not proven")
    return {
        "source": str(source),
        "destination": str(destination),
        "source_size": before.st_size,
        "destination_size": destination.stat().st_size,
        "source_sha256": _sha256(source),
        "destination_sha256": _sha256(destination),
        "source_mtime_ns_before": int(before.st_mtime_ns),
        "source_mtime_ns_after": int(after.st_mtime_ns),
        "destination_valid_blend_header": is_readable_blend_header(destination),
    }


def command_copy(source: str, destination: str, out_json: str) -> int:
    payload = {"schema": SCHEMA_COPY, "generated": _now_text(), "status": "FAIL", "error": ""}
    try:
        result = _atomic_copy_blend(Path(source), Path(destination))
        payload.update(result)
        payload["byte_identical"] = result["source_sha256"] == result["destination_sha256"]
        payload["status"] = "PASS" if payload["byte_identical"] and result["destination_valid_blend_header"] else "FAIL"
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def command_deep(source: str, destination: str, out_json: str) -> int:
    payload = {"schema": SCHEMA_DEEP, "generated": _now_text(), "status": "FAIL", "error": "", "live_process_boundary": "NOT_CLAIMED"}
    try:
        engine = _engine_module()
        result = engine.rescue_best(source, destination)
        payload.update(result)
        payload["schema"] = SCHEMA_DEEP
        payload["status"] = "PASS" if Path(destination).is_file() and result.get("status") == "PASS" else "FAIL"
        payload["live_process_boundary"] = "EXPLICIT_SOURCE_ONLY"
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def _open_recovered_mainfile(context, path: str) -> dict[str, Any]:
    payload: dict[str, Any] = {"requested_path": path, "status": "NOT_RUN", "filepath_after": ""}
    if not path:
        payload["status"] = "NO_PATH"
        return payload
    if not Path(path).is_file():
        payload["status"] = "MISSING_PATH"
        return payload
    try:
        bpy = _bpy()
        if bool(getattr(getattr(bpy, "app", None), "background", False)):
            result = bpy.ops.wm.open_mainfile('EXEC_DEFAULT', filepath=str(path), load_ui=False)
        else:
            window = getattr(context, "window", None)
            if window is None:
                raise RuntimeError("an active Blender window is required for unsaved-changes confirmation")
            with bpy.context.temp_override(window=window):
                result = bpy.ops.wm.open_mainfile('INVOKE_DEFAULT', filepath=str(path), load_ui=False)
        result_set = set(result) if isinstance(result, set) else set()
        filepath_after = str(getattr(getattr(bpy, "data", None), "filepath", "") or "")
        payload.update({"operator_result": sorted(result) if isinstance(result, set) else str(result), "filepath_after": filepath_after})
        if "RUNNING_MODAL" in result_set:
            payload["status"] = "PENDING_CONFIRMATION"
            return payload
        payload["status"] = "PASS" if "FINISHED" in result_set and os.path.normcase(os.path.abspath(filepath_after)) == os.path.normcase(os.path.abspath(path)) else "FAIL"
        if payload["status"] != "PASS":
            payload["error"] = f"open_mainfile filepath mismatch: expected={path} actual={filepath_after}"
    except Exception as exc:
        payload["status"] = "FAIL"
        payload["error"] = f"{type(exc).__name__}: {exc}"
    return payload


def command_deep_analyze(source: str, out_json: str) -> int:
    payload = {"schema": "smart_file_crash_recovery/deep_analyze/1", "generated": _now_text(), "status": "FAIL", "error": ""}
    try:
        engine = _engine_module()
        payload.update(engine.analyze_source(source))
        payload["schema"] = "smart_file_crash_recovery/deep_analyze/1"
        payload["status"] = "PASS" if payload.get("steps") else "FAIL"
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def command_deep_extract(source: str, step_index: int, destination: str, out_json: str) -> int:
    payload = {"schema": "smart_file_crash_recovery/deep_extract/1", "generated": _now_text(), "status": "FAIL", "error": ""}
    try:
        engine = _engine_module()
        payload.update(engine.extract_step(source, int(step_index), destination))
        payload["schema"] = "smart_file_crash_recovery/deep_extract/1"
        payload["status"] = "PASS" if Path(destination).is_file() and payload.get("status") == "PASS" else "FAIL"
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def _write_full_memory_dump(pid: int, destination: Path) -> dict[str, Any]:
    """Create one read-only, owned full minidump of an explicit other PID."""
    if os.name != "nt":
        raise RuntimeError("full process dumps are supported only on Windows")
    if int(pid) <= 0 or int(pid) == os.getpid():
        raise ValueError("an explicit other process PID is required")
    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(f"dump destination already exists: {destination}")
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    dbghelp = ctypes.WinDLL("dbghelp", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32)
    kernel32.OpenProcess.restype = ctypes.c_void_p
    kernel32.CloseHandle.argtypes = (ctypes.c_void_p,)
    kernel32.CloseHandle.restype = ctypes.c_int
    dbghelp.MiniDumpWriteDump.argtypes = (ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32,
                                          ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    dbghelp.MiniDumpWriteDump.restype = ctypes.c_int
    handle = kernel32.OpenProcess(0x0450, False, int(pid))  # QUERY_INFORMATION | VM_READ | DUP_HANDLE
    if not handle:
        raise PermissionError(f"OpenProcess failed for PID {pid}: {ctypes.get_last_error()}")
    class _PMCEX(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                    ("PrivateUsage", ctypes.c_size_t)]
    psapi.GetProcessMemoryInfo.argtypes = (ctypes.c_void_p, ctypes.POINTER(_PMCEX), ctypes.c_uint32)
    psapi.GetProcessMemoryInfo.restype = ctypes.c_int
    counters = _PMCEX(); counters.cb = ctypes.sizeof(counters)
    private_usage = 0
    if psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
        private_usage = int(counters.PrivateUsage)
    try:
        free_bytes = int(shutil.disk_usage(destination.parent).free)
    except Exception:
        kernel32.CloseHandle(handle)
        raise
    required_bytes = private_usage + (512 << 20)
    if private_usage and free_bytes < required_bytes:
        kernel32.CloseHandle(handle)
        raise OSError(f"insufficient dump storage: required={required_bytes} free={free_bytes}")
    fd = -1; part = destination.with_name(destination.name + ".part")
    try:
        fd = os.open(str(part), os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
        import msvcrt
        file_handle = msvcrt.get_osfhandle(fd)
        flags = 0x00000002 | 0x00000004 | 0x00000800 | 0x00001000 | 0x00020000
        ok = dbghelp.MiniDumpWriteDump(handle, int(pid), file_handle, flags, None, None, None)
        if not ok:
            raise OSError(f"MiniDumpWriteDump failed: {ctypes.get_last_error()}")
        os.close(fd); fd = -1
        os.replace(part, destination)
    except Exception:
        part.unlink(missing_ok=True)
        raise
    finally:
        if fd >= 0:
            os.close(fd)
        kernel32.CloseHandle(handle)
    if not destination.is_file() or destination.stat().st_size <= 0:
        destination.unlink(missing_ok=True)
        raise RuntimeError("full memory dump is empty")
    return {"path": str(destination), "size": destination.stat().st_size, "sha256": _sha256(destination),
            "private_usage": private_usage, "required_free_bytes": required_bytes, "free_bytes_before": free_bytes,
            "dump_flags": "FullMemory|HandleData|FullMemoryInfo|ThreadInfo|IgnoreInaccessibleMemory"}


def _finalize_raw_blend(raw_path: Path, destination: Path) -> dict[str, Any]:
    """Load engine output in Blender, compressed-save, then create-only promote."""
    raw_path = raw_path.resolve(); destination = destination.resolve()
    if destination.exists():
        raise FileExistsError(f"destination already exists: {destination}")
    if not raw_path.is_file() or raw_path.stat().st_size <= 0:
        raise RuntimeError("raw reconstruction is missing or empty")
    bpy = _bpy()
    opened = bpy.ops.wm.open_mainfile('EXEC_DEFAULT', filepath=str(raw_path), load_ui=False)
    if 'FINISHED' not in set(opened):
        raise RuntimeError(f"Blender rejected reconstructed raw file: {opened}")
    if os.path.normcase(os.path.abspath(str(bpy.data.filepath))) != os.path.normcase(os.path.abspath(str(raw_path))):
        raise RuntimeError("Blender opened a different path than the reconstructed raw file")
    counts = {name: len(getattr(bpy.data, name, ())) for name in
              ("objects", "meshes", "materials", "images", "actions", "collections")}
    attribute_mismatches = 0
    for mesh in bpy.data.meshes:
        domains = {"POINT": len(mesh.vertices), "EDGE": len(mesh.edges),
                   "FACE": len(mesh.polygons), "CORNER": len(mesh.loops)}
        for uv in mesh.uv_layers:
            if len(uv.uv) != len(mesh.loops):
                attribute_mismatches += 1
        for attribute in mesh.attributes:
            expected = domains.get(attribute.domain)
            if expected is not None and len(attribute.data) != expected:
                attribute_mismatches += 1
    packed = [image for image in bpy.data.images if image.packed_file]
    integrity = {"counts": counts, "attribute_mismatches": attribute_mismatches,
                 "packed_images": len(packed),
                 "nonempty_packed_images": sum(1 for image in packed if image.packed_file.size > 0),
                 "total_vertices": sum(len(mesh.vertices) for mesh in bpy.data.meshes),
                 "total_polygons": sum(len(mesh.polygons) for mesh in bpy.data.meshes),
                 "edit_mode_objects": [obj.name for obj in bpy.data.objects if obj.mode != "OBJECT"]}
    stage = destination.with_name(f".sfstage-{uuid.uuid4().hex}.blend")
    try:
        saved = bpy.ops.wm.save_as_mainfile('EXEC_DEFAULT', filepath=str(stage), compress=True, copy=True)
        if 'FINISHED' not in set(saved) or not stage.is_file() or stage.stat().st_size <= 0:
            raise RuntimeError(f"Blender finalization failed: {saved}")
        if destination.exists():
            raise FileExistsError(f"destination appeared during finalization: {destination}")
        os.link(stage, destination)
    finally:
        stage.unlink(missing_ok=True)
    return {"destination": str(destination), "destination_size": destination.stat().st_size,
            "destination_sha256": _sha256(destination), "blender_opened_raw": True,
            "blender_compressed_save": True, "create_only_promotion": True,
            "integrity": integrity}


def _new_owned_session() -> Path:
    session = local_work_root() / f"session-{_stamp()}-{uuid.uuid4().hex}"
    session.mkdir(parents=True, exist_ok=False)
    (session / ".smart-file-owned-session.json").write_text(
        json.dumps({"schema": "smart_file_crash_recovery/session/1", "worker_pid": os.getpid()}) + "\n",
        encoding="utf-8")
    return session


def _remove_owned_session(session: str | Path) -> bool:
    path = Path(session).resolve(); root = local_work_root().resolve()
    marker = path / ".smart-file-owned-session.json"
    if path.parent != root or not path.name.startswith("session-") or not marker.is_file():
        return False
    shutil.rmtree(path)
    return True


def _remove_sessions_for_worker(worker_pid: int) -> int:
    if int(worker_pid or 0) <= 0:
        return 0
    root = local_work_root().resolve(); removed = 0
    for path in root.glob("session-*"):
        marker = path / ".smart-file-owned-session.json"
        try:
            record = json.loads(marker.read_text(encoding="utf-8"))
            if record.get("schema") == "smart_file_crash_recovery/session/1" and int(record.get("worker_pid", 0)) == int(worker_pid):
                removed += int(_remove_owned_session(path))
        except Exception:
            continue
    return removed


def _record_session_removal(payload: dict[str, Any], session: str | Path) -> None:
    try:
        payload["owned_session_removed"] = _remove_owned_session(session)
    except Exception as exc:
        payload["owned_session_removed"] = False
        payload["cleanup_error"] = f"{type(exc).__name__}: {exc}"
        payload["status"] = "FAIL"


def _owned_chain_paths(destination: Path) -> tuple[Path, Path, Path, Path]:
    del destination
    session = _new_owned_session()
    return session, session / "process.full.dmp", session / "recovered_raw.blend", session / "steps.json"


def command_dump_analyze(pid: int, out_json: str) -> int:
    payload = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "analyze", "status": "FAIL", "error": ""}
    session = None
    try:
        session, dump, _raw, steps = _owned_chain_paths(Path(out_json))
        payload["dump"] = _write_full_memory_dump(pid, dump)
        result = _engine_module().analyze_dump(str(dump), str(steps))
        payload.update({"engine": result, "steps": result.get("steps", []), "dump_path": str(dump), "session_path": str(session),
                        "status": "PASS" if result.get("steps") else "FAIL"})
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
        if session is not None:
            _record_session_removal(payload, session)
    if session is not None and payload.get("status") != "PASS" and "owned_session_removed" not in payload:
        _record_session_removal(payload, session)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def command_dump_rescue(pid: int, destination: str, out_json: str) -> int:
    payload = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "latest", "status": "FAIL", "error": ""}
    session = None
    try:
        final = Path(destination).resolve()
        session, dump, raw, steps = _owned_chain_paths(final)
        payload["dump"] = _write_full_memory_dump(pid, dump)
        engine = _engine_module().rescue_raw(str(dump), str(raw), str(steps))
        finalized = _finalize_raw_blend(raw, final)
        payload.update({"engine": engine, "steps": engine.get("steps", []), "dump_path": str(dump),
                        "raw_path": str(raw), **finalized,
                        "status": "FAIL_UNRESOLVED_REFERENCES" if engine.get("warning") else "PASS",
                        "engine_warning_unresolved_references": bool(engine.get("warning"))})
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if session is not None:
            _record_session_removal(payload, session)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def command_dump_extract(dump_path: str, step_index: int, destination: str, out_json: str) -> int:
    payload = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "point", "status": "FAIL", "error": ""}
    session = None
    try:
        final = Path(destination).resolve()
        session = _new_owned_session()
        raw = session / "recovered_raw.blend"
        engine = _engine_module().extract_raw(dump_path, int(step_index), str(raw))
        finalized = _finalize_raw_blend(raw, final)
        payload.update({"engine": engine, "selected_step_index": int(step_index), "dump_path": str(dump_path),
                        "raw_path": str(raw), **finalized,
                        "status": "FAIL_UNRESOLVED_REFERENCES" if engine.get("warning") else "PASS",
                        "engine_warning_unresolved_references": bool(engine.get("warning"))})
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if session is not None:
            _record_session_removal(payload, session)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def command_fixture_rescue(dump_path: str, destination: str, out_json: str) -> int:
    """Deterministic acceptance entrypoint for a synthetic owned MDMP only."""
    payload = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "synthetic_fixture", "status": "FAIL", "error": ""}
    session = None
    try:
        final = Path(destination).resolve()
        session = _new_owned_session()
        raw = session / "recovered_raw.blend"; steps = session / "steps.json"
        engine = _engine_module().rescue_raw(dump_path, str(raw), str(steps))
        finalized = _finalize_raw_blend(raw, final)
        payload.update({"engine": engine, "steps": engine.get("steps", []), "dump_path": str(Path(dump_path).resolve()),
                        "raw_path": str(raw), **finalized,
                        "status": "FAIL_UNRESOLVED_REFERENCES" if engine.get("warning") else "PASS",
                        "engine_warning_unresolved_references": bool(engine.get("warning"))})
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if session is not None:
            _record_session_removal(payload, session)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def _engine_module():
    name = "smart_file_crash_recovery_engine_runtime"
    path = Path(__file__).with_name("crash_recovery_original_adapter.py")
    mod = sys.modules.get(name)
    if mod is not None:
        return mod
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Smart File deep recovery engine could not be loaded")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def local_work_root() -> Path:
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    root = Path(base) / "SmartTools" / "SmartFile" / "CrashRecovery"
    root.mkdir(parents=True, exist_ok=True)
    return root


def cleanup_abandoned_scratch(*, max_age_seconds: int = 6 * 60 * 60) -> dict[str, Any]:
    state: dict[str, Any] = {}
    try:
        bpy = _bpy()
        raw_state = bpy.app.driver_namespace.get(STATE_KEY)
        if isinstance(raw_state, dict):
            state = raw_state
    except Exception:
        state = {}
    proc = state.get("process") if isinstance(state, dict) else None
    try:
        if proc is not None and proc.poll() is None:
            return {"status": "SKIP_ACTIVE_WORKER", "removed": 0, "bytes": 0}
    except Exception:
        return {"status": "SKIP_UNKNOWN_WORKER", "removed": 0, "bytes": 0}
    root = local_work_root().resolve()
    now = time.time()
    removed = 0
    bytes_removed = 0
    active_parts = _active_lease_part_paths(root, now)
    for path in root.rglob("*.part"):
        try:
            resolved = path.resolve()
            if root not in resolved.parents:
                continue
            if os.path.normcase(str(resolved)) in active_parts:
                continue
            if now - resolved.stat().st_mtime < int(max_age_seconds):
                continue
            size = resolved.stat().st_size
            resolved.unlink()
            removed += 1
            bytes_removed += int(size)
        except Exception:
            pass
    return {"status": "PASS", "removed": removed, "bytes": bytes_removed, "root": str(root)}


def _worker_token() -> str:
    return hashlib.sha256(f"{os.getpid()}:{time.time_ns()}:{id(object())}".encode("ascii")).hexdigest().upper()


def _lease_path_for(report: Path) -> Path:
    return report.with_suffix(report.suffix + ".lease.json")


def _write_worker_lease(path: Path, *, token: str, part_path: str = "", worker_pid: int = 0) -> None:
    payload = {
        "schema": LEASE_SCHEMA,
        "owner": "SmartFile",
        "pid": int(worker_pid or os.getpid()),
        "controller_pid": os.getpid(),
        "token": token,
        "updated": time.time(),
        "part_path": part_path,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def _refresh_worker_lease(state: dict[str, Any]) -> bool:
    lease_text = str(state.get("lease", "") or "")
    token = str(state.get("token", "") or "")
    if not lease_text or not token:
        return False
    part_path = str(state.get("part_path", "") or "")
    worker_pid = int(state.get("worker_pid", 0) or 0)
    controller_pid = int(state.get("controller_pid", 0) or 0)
    if worker_pid <= 0:
        proc = state.get("process")
        worker_pid = int(getattr(proc, "pid", 0) or 0)
    if controller_pid <= 0:
        controller_pid = os.getpid()
    payload = {
        "schema": LEASE_SCHEMA,
        "owner": "SmartFile",
        "pid": worker_pid,
        "controller_pid": controller_pid,
        "token": token,
        "updated": time.time(),
        "part_path": part_path,
    }
    path = Path(lease_text)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)
    return True


def _clear_worker_lease(state: dict[str, Any]) -> bool:
    lease_text = str(state.get("lease", "") or "")
    if not lease_text:
        return False
    path = Path(lease_text)
    try:
        if path.exists():
            path.unlink()
        return True
    except Exception:
        return False


def _active_lease_part_paths(root: Path, now: float | None = None) -> set[str]:
    clock = time.time() if now is None else float(now)
    active: set[str] = set()
    for lease in root.rglob("*.lease.json"):
        try:
            data = json.loads(lease.read_text(encoding="utf-8"))
            if data.get("schema") != LEASE_SCHEMA:
                continue
            if str(data.get("owner", "") or "") != "SmartFile":
                continue
            if int(data.get("pid", 0) or 0) <= 0 or int(data.get("controller_pid", 0) or 0) <= 0:
                continue
            if not str(data.get("token", "") or ""):
                continue
            updated = float(data.get("updated", 0) or 0)
            if clock - updated > LEASE_TTL_SECONDS:
                continue
            part = str(data.get("part_path", "") or "")
            if not part:
                continue
            resolved = Path(part).resolve()
            if root not in resolved.parents:
                continue
            active.add(os.path.normcase(str(resolved)))
        except Exception:
            pass
    return active


def default_recovery_path(source_path: str, destination_dir: str = "") -> str:
    source = Path(source_path)
    directory = Path(destination_dir) if destination_dir else local_work_root() / "Recovered"
    stem = _safe_name(source.stem)
    return str(directory / f"{stem}_Recovered_{_stamp()}.blend")


def _bpy():
    import bpy  # type: ignore
    return bpy


def _state() -> dict[str, Any]:
    bpy = _bpy()
    ns = bpy.app.driver_namespace
    state = ns.get(STATE_KEY)
    if not isinstance(state, dict):
        state = {"process": None, "owner": "SmartFile", "mode": "", "report": "", "started": 0.0, "stdout": "", "stderr": ""}
        ns[STATE_KEY] = state
    return state


def _scene_settings(context=None):
    from .context_utils import scene_settings
    return scene_settings(context)


def _iter_scene_settings() -> list[Any]:
    try:
        bpy = _bpy()
        scenes = getattr(getattr(bpy, "data", None), "scenes", None)
        if scenes is None:
            return []
        out: list[Any] = []
        for scene in scenes:
            settings = getattr(scene, "uhm_settings", None)
            if settings is not None:
                out.append(settings)
        return out
    except Exception:
        return []


def _reset_scene_runtime_state(st) -> bool:
    if st is None:
        return False
    try:
        candidates = getattr(st, "crash_recovery_candidates", None)
        if hasattr(candidates, "clear"):
            candidates.clear()
        st.crash_recovery_active_index = -1
        st.crash_recovery_scan_root = ""
        st.crash_recovery_destination_dir = ""
        st.crash_recovery_destination = ""
        st.crash_recovery_deep_source = ""
        st.crash_recovery_live_pid = 0
        st.crash_recovery_step_index = -1
        st.crash_recovery_status = "Ready"
        st.crash_recovery_progress = 0
        st.crash_recovery_last_report = ""
        st.crash_recovery_last_error = ""
        st.crash_recovery_last_destination = ""
        return True
    except Exception:
        return False


def _reset_all_scene_runtime_state() -> bool:
    ok = True
    for settings in _iter_scene_settings():
        if not _reset_scene_runtime_state(settings):
            ok = False
    return ok


def _handler_records() -> list[dict[str, Any]]:
    bpy = _bpy()
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    if not isinstance(namespace, dict):
        raise RuntimeError("bpy.app.driver_namespace is unavailable")
    records = namespace.get(HANDLERS_KEY)
    if not isinstance(records, list):
        records = []
        namespace[HANDLERS_KEY] = records
    return records


def _remove_exact_handler(collection, callback) -> bool:
    removed = False
    try:
        while any(item is callback for item in tuple(collection or ())):
            collection.remove(callback)
            removed = True
    except Exception:
        return False
    return removed or not any(item is callback for item in tuple(collection or ()))


def _owned_handler_match(callback, expected_name: str) -> bool:
    if not callable(callback):
        return False
    if str(getattr(callback, "__name__", "") or "") != str(expected_name or ""):
        return False
    module_name = str(getattr(callback, "__module__", "") or "")
    if module_name not in {__name__, ""} and not module_name.endswith(".crash_recovery"):
        return False
    code = getattr(callback, "__code__", None)
    filename = str(getattr(code, "co_filename", "") or "")
    if not filename:
        return False
    try:
        normalized = os.path.normcase(str(Path(filename).resolve()))
    except Exception:
        normalized = os.path.normcase(filename)
    return Path(normalized).name == _THIS_CODE_BASENAME


def _remove_owned_handler_fallback(collection, expected_name: str) -> bool:
    removed = False
    try:
        for callback in tuple(collection or ()):
            if _owned_handler_match(callback, expected_name):
                collection.remove(callback)
                removed = True
    except Exception:
        return False
    return removed or not any(
        _owned_handler_match(callback, expected_name)
        for callback in tuple(collection or ())
    )


def _remove_stale_owned_handlers(handlers) -> bool:
    ok = True
    save_pre = getattr(handlers, "save_pre", None)
    load_post = getattr(handlers, "load_post", None)
    if save_pre is not None:
        ok = _remove_owned_handler_fallback(save_pre, "_save_pre_reset_runtime") and ok
    if load_post is not None:
        ok = _remove_owned_handler_fallback(load_post, "_load_post_reset_runtime") and ok
    return ok


def _append_exact_handler(collection, callback, role: str) -> bool:
    records = _handler_records()
    if any(item is callback for item in tuple(collection or ())):
        if not any(record.get("callback") is callback for record in records):
            records.append({"collection": collection, "callback": callback, "role": role})
        return True
    collection.append(callback)
    if not any(item is callback for item in tuple(collection or ())):
        return False
    records.append({"collection": collection, "callback": callback, "role": role})
    return True


@persistent
def _save_pre_reset_runtime(_dummy=None):
    try:
        _reset_all_scene_runtime_state()
    except Exception:
        return


@persistent
def _load_post_reset_runtime(_dummy=None):
    try:
        _reset_all_scene_runtime_state()
    except Exception:
        return


def register_owned_resources(context=None) -> bool:
    del context
    try:
        bpy = _bpy()
        handlers = getattr(getattr(bpy, "app", None), "handlers", None)
        if handlers is None:
            raise RuntimeError("bpy.app.handlers is unavailable")
        if not _remove_stale_owned_handlers(handlers):
            raise RuntimeError("crash recovery stale handler cleanup failed")
        if not _append_exact_handler(getattr(handlers, "save_pre", None), _save_pre_reset_runtime, "save_pre"):
            raise RuntimeError("crash recovery save_pre handler registration failed")
        if not _append_exact_handler(getattr(handlers, "load_post", None), _load_post_reset_runtime, "load_post"):
            raise RuntimeError("crash recovery load_post handler registration failed")
        return True
    except Exception:
        return False


def _python_or_blender_command(*, require_blender: bool = False) -> list[str]:
    try:
        bpy = _bpy()
        py = getattr(getattr(bpy, "app", None), "binary_path_python", "") or ""
        blender = getattr(getattr(bpy, "app", None), "binary_path", "") or ""
    except Exception:
        py = ""; blender = ""
    if require_blender:
        exe = blender or (sys.executable if sys.executable.lower().endswith("blender.exe") else "")
        if not exe or not Path(exe).is_file():
            raise RuntimeError("Blender executable is required for recovery finalization")
        return [exe, "--background", "--factory-startup", "--disable-autoexec", "-noaudio", "--python", __file__, "--"]
    if py and Path(py).is_file():
        return [py, __file__]
    exe = sys.executable
    if exe.lower().endswith("blender.exe"):
        return [exe, "--background", "--factory-startup", "--disable-autoexec", "-noaudio", "--python", __file__, "--"]
    return [exe, __file__]


def _register_poll_timer() -> None:
    bpy = _bpy()
    ns = bpy.app.driver_namespace
    timer = ns.get(TIMER_KEY)
    try:
        if timer is not None and bpy.app.timers.is_registered(timer):
            return
    except Exception:
        pass
    ns[TIMER_KEY] = _poll_timer
    bpy.app.timers.register(_poll_timer, first_interval=0.25, persistent=True)


def _load_report(path: str) -> dict[str, Any]:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}


def _fill_candidates(context, report: dict[str, Any]) -> None:
    st = _scene_settings(context)
    if st is None:
        return
    try:
        st.crash_recovery_candidates.clear()
        scenes = report.get("scenes") if isinstance(report, dict) else []
        for scene in scenes if isinstance(scenes, list) else []:
            scene_name = str(scene.get("scene_name", ""))
            for candidate in scene.get("candidates", []) or []:
                item = st.crash_recovery_candidates.add()
                item.scene_name = scene_name
                item.path = str(candidate.get("path", ""))
                item.label = str(candidate.get("label", ""))
                item.kind = str(candidate.get("kind", ""))
                if hasattr(item, "source_pid"):
                    item.source_pid = int(candidate.get("pid", 0) or 0)
                if hasattr(item, "crash_signal"):
                    item.crash_signal = str(candidate.get("crash_signal", ""))
                item.mtime_text = str(candidate.get("mtime_text", ""))
                item.size = int(candidate.get("size", 0) or 0)
                item.recommended = bool(candidate.get("recommended", False))
                item.suspect_small = bool(candidate.get("suspect_small", False))
                item.valid_blend_header = bool(candidate.get("valid_blend_header", False))
        st.crash_recovery_active_index = 0 if len(st.crash_recovery_candidates) else -1
        st.crash_recovery_status = _ui_text(f"{len(st.crash_recovery_candidates)} recovery candidates found.", f'復旧の候補が {len(st.crash_recovery_candidates)} 件見つかりました。')
        st.crash_recovery_progress = 100
    except Exception as exc:
        st.crash_recovery_status = _ui_text(f"Crash recovery result could not be loaded: {type(exc).__name__}: {exc}", f'復旧の結果を読み込めませんでした：{type(exc).__name__}: {exc}')


def _cleanup_worker_runtime(state: dict[str, Any]) -> None:
    value = str(state.pop("runtime_root", "") or "")
    if not value:
        return
    path = Path(value).resolve(); root = local_work_root().resolve()
    if path.parent == root and path.name.startswith("runtime-"):
        shutil.rmtree(path, ignore_errors=True)


def _finish_state(context=None) -> None:
    state = _state()
    report = _load_report(str(state.get("report", "")))
    if str(report.get("schema", "")) == SCHEMA_ORIGINAL_CHAIN and str(report.get("operation", "")) == "analyze":
        old_session = str(state.get("recovery_session_path", "") or "")
        if old_session and old_session != str(report.get("session_path", "")):
            _remove_owned_session(old_session)
        state["recovery_points"] = list(report.get("steps") or [])
        state["recovery_dump_path"] = str(report.get("dump_path", ""))
        state["recovery_session_path"] = str(report.get("session_path", ""))
    _cleanup_worker_runtime(state)
    should_open = bool(state.get("open_after_success")) and str(report.get("status", "FAIL")) == "PASS" and bool(report.get("destination"))
    if should_open:
        state["process"] = None
        state["mode"] = ""
        state["open_after_success"] = False
        open_payload = _open_recovered_mainfile(context, str(report.get("destination", "")))
        report["open_mainfile"] = open_payload
        if str(open_payload.get("status", "FAIL")) == "PENDING_CONFIRMATION":
            report["status"] = "OPEN_PENDING_CONFIRMATION"
            state["pending_open_path"] = str(report.get("destination", ""))
            state["pending_open_report"] = str(state.get("report", ""))
            state["pending_open_started"] = time.time()
        elif str(open_payload.get("status", "FAIL")) != "PASS":
            report["status"] = "FAIL"
            report["error"] = str(open_payload.get("error", "Recovered file could not be opened in the current Blender process."))
        try:
            Path(str(state.get("report", ""))).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        except Exception:
            pass
        return
    st = _scene_settings(context)
    if st is not None:
        st.crash_recovery_last_report = str(state.get("report", ""))
        st.crash_recovery_last_error = str(report.get("error", ""))
        if str(report.get("schema", "")) == SCHEMA_SCAN:
            _fill_candidates(context, report)
        else:
            status = str(report.get("status", "FAIL"))
            st.crash_recovery_status = "Crash recovery completed." if status == "PASS" else "Crash recovery failed."
            st.crash_recovery_progress = 100 if status == "PASS" else 0
            if report.get("destination"):
                st.crash_recovery_last_destination = str(report.get("destination", ""))
    state["process"] = None
    state["mode"] = ""
    state["open_after_success"] = False


def _poll_pending_open(state: dict[str, Any]) -> float | None:
    path = str(state.get("pending_open_path", "") or "")
    if not path:
        return None
    report_path = str(state.get("pending_open_report", "") or "")
    try:
        bpy = _bpy(); actual = str(getattr(getattr(bpy, "data", None), "filepath", "") or "")
        matched = os.path.normcase(os.path.abspath(actual)) == os.path.normcase(os.path.abspath(path))
        elapsed = time.time() - float(state.get("pending_open_started", time.time()))
        if not matched and elapsed < 120.0:
            return 0.5
        report = _load_report(report_path)
        if matched:
            report["status"] = "PASS"
            report["open_mainfile"] = {"status": "PASS", "requested_path": path, "filepath_after": actual,
                                       "confirmation": "BLENDER_BUILTIN_CONFIRMED"}
        else:
            report["status"] = "FAIL"
            report["error"] = "Recovered-file open was not confirmed within the bounded confirmation window."
            report["open_mainfile"] = {"status": "CANCELLED_OR_TIMEOUT", "requested_path": path, "filepath_after": actual}
        Path(report_path).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    finally:
        state.pop("pending_open_path", None); state.pop("pending_open_report", None); state.pop("pending_open_started", None)
    return None


def _poll_timer():
    try:
        state = _state()
        proc = state.get("process")
        if proc is None:
            return _poll_pending_open(state)
        code = proc.poll()
        if code is None:
            try:
                _refresh_worker_lease(state)
            except Exception:
                pass
            return 0.5
        state["returncode"] = int(code)
        try:
            _clear_worker_lease(state)
        except Exception:
            pass
        _finish_state(getattr(_bpy(), "context", None))
        return 0.5 if state.get("pending_open_path") else None
    except Exception:
        return None


def _start_worker(context, mode: str, args: list[str], report_name: str, *, open_after_success: bool = False) -> tuple[bool, str]:
    state = _state()
    proc = state.get("process")
    if proc is not None and proc.poll() is None:
        return False, "Crash recovery worker is already running."
    work = local_work_root()
    report = work / report_name
    stdout = work / (report.stem + ".stdout.log")
    stderr = work / (report.stem + ".stderr.log")
    token = _worker_token()
    destination = ""
    if mode in {"copy", "deep", "deep_extract", "dump_rescue", "dump_extract"} and len(args) >= 3:
        destination = str(args[-1])
    lease = _lease_path_for(report)
    part_path = (destination + ".part") if destination else ""
    require_blender = mode in {"dump_rescue", "dump_extract"}
    command = _python_or_blender_command(require_blender=require_blender) + args + [str(report)]
    child_env = os.environ.copy()
    runtime_root = work / f"runtime-{token}"
    if require_blender:
        for name in ("config", "scripts", "datafiles", "temp"):
            (runtime_root / name).mkdir(parents=True, exist_ok=True)
        child_env.update({"BLENDER_USER_CONFIG": str(runtime_root / "config"),
                          "BLENDER_USER_SCRIPTS": str(runtime_root / "scripts"),
                          "BLENDER_USER_DATAFILES": str(runtime_root / "datafiles"),
                          "TMP": str(runtime_root / "temp"), "TEMP": str(runtime_root / "temp")})
    with stdout.open("w", encoding="utf-8") as out, stderr.open("w", encoding="utf-8") as err:
        proc = subprocess.Popen(command, stdout=out, stderr=err, cwd=str(work), env=child_env)
    state.update({"process": proc, "mode": mode, "report": str(report), "stdout": str(stdout), "stderr": str(stderr), "started": time.time(), "command": command, "open_after_success": bool(open_after_success), "lease": str(lease), "token": token, "worker_pid": int(getattr(proc, "pid", 0) or 0), "controller_pid": os.getpid(), "part_path": part_path, "runtime_root": str(runtime_root) if require_blender else ""})
    _refresh_worker_lease(state)
    st = _scene_settings(context)
    if st is not None:
        st.crash_recovery_status = "Crash recovery worker started."
        st.crash_recovery_progress = 1
        st.crash_recovery_last_report = str(report)
        st.crash_recovery_last_error = ""
    _register_poll_timer()
    return True, str(report)


def start_scan(context=None) -> tuple[bool, str]:
    clear_recovery_points()
    return _start_worker(context, "scan", ["scan", "--roots-only"], f"scan_{_stamp()}.json")


def start_recovery_points_scan(context=None) -> tuple[bool, str]:
    """Original quick-recovery tab: disk autosaves/backups, no process targets."""
    clear_recovery_points()
    return _start_worker(context, "points_scan", ["scan", "--no-external-crashes"], f"points_scan_{_stamp()}.json")


def _selected_candidate_path(context=None) -> str:
    st = _scene_settings(context)
    if st is None or st.crash_recovery_active_index < 0 or st.crash_recovery_active_index >= len(st.crash_recovery_candidates):
        return ""
    return st.crash_recovery_candidates[st.crash_recovery_active_index].path


def start_copy_selected(context=None) -> tuple[bool, str]:
    st = _scene_settings(context)
    source = _selected_candidate_path(context)
    if not source:
        return False, "No crash recovery candidate is selected."
    destination = ""
    try:
        destination = str(st.crash_recovery_destination or "")
    except Exception:
        pass
    if not destination:
        destination = default_recovery_path(source, getattr(st, "crash_recovery_destination_dir", "") if st is not None else "")
    if str(source).lower().startswith("pid:"):
        pid = int(str(source).split(":", 1)[1])
        return _start_worker(context, "dump_rescue", ["dump_rescue", str(pid), destination], f"dump_rescue_{_stamp()}.json", open_after_success=True)
    return _start_worker(context, "copy", ["copy", source, destination], f"copy_{_stamp()}.json", open_after_success=True)


def start_analyze_selected(context=None) -> tuple[bool, str]:
    source = _selected_candidate_path(context)
    if not str(source).lower().startswith("pid:"):
        return False, "Select an external crashed Blender process first."
    pid = int(str(source).split(":", 1)[1])
    return _start_worker(context, "dump_analyze", ["dump_analyze", str(pid)], f"dump_analyze_{_stamp()}.json")


def recovery_points() -> list[dict[str, Any]]:
    values = _state().get("recovery_points", [])
    return [dict(item) for item in values if isinstance(item, dict)] if isinstance(values, list) else []


def clear_recovery_points() -> None:
    state = _state()
    _remove_owned_session(str(state.get("recovery_session_path", "") or ""))
    state.pop("recovery_session_path", None); state.pop("recovery_dump_path", None); state.pop("recovery_points", None)


def start_recovery_point(context, step_index: int) -> tuple[bool, str]:
    state = _state()
    dump_path = str(state.get("recovery_dump_path", ""))
    points = recovery_points()
    if not dump_path or not Path(dump_path).is_file():
        return False, "Analyze the selected crashed Blender process first."
    if int(step_index) < 0 or int(step_index) >= len(points):
        return False, "Recovery point index is out of range."
    st = _scene_settings(context)
    destination = default_recovery_path(f"RecoveryPoint_{int(step_index):03d}.blend", getattr(st, "crash_recovery_destination_dir", "") if st else "")
    return _start_worker(context, "dump_extract", ["dump_extract", dump_path, str(int(step_index)), destination], f"dump_extract_{_stamp()}.json", open_after_success=True)


def start_deep_fixture(context=None) -> tuple[bool, str]:
    st = _scene_settings(context)
    if st is None:
        return False, "Scene settings unavailable"
    live_pid = int(getattr(st, "crash_recovery_live_pid", 0) or 0)
    deep_source = str(getattr(st, "crash_recovery_deep_source", "") or "")
    if live_pid > 0:
        if live_pid == os.getpid():
            return False, "Current Blender process cannot be selected for live recovery."
        source = f"pid:{live_pid}"
        destination_seed = f"LiveProcess_{live_pid}.blend"
    elif deep_source:
        source = deep_source
        destination_seed = deep_source
    else:
        return False, "Select a recovery fixture/dump or enter an explicit other Blender PID first."
    destination = st.crash_recovery_destination or default_recovery_path(destination_seed, st.crash_recovery_destination_dir)
    step_index = int(getattr(st, "crash_recovery_step_index", -1) or -1)
    if step_index >= 0:
        return _start_worker(context, "deep_extract", ["deep_extract", source, str(step_index), destination], f"deep_extract_{_stamp()}.json")
    return _start_worker(context, "deep", ["deep", source, destination], f"deep_{_stamp()}.json")


def cancel_worker() -> bool:
    state = _state()
    proc = state.get("process")
    if proc is None or proc.poll() is not None:
        worker_pid = int(state.get("worker_pid", 0) or 0)
        state["process"] = None
        _clear_worker_lease(state)
        _cleanup_worker_runtime(state)
        _remove_sessions_for_worker(worker_pid)
        return False
    worker_pid = int(state.get("worker_pid", 0) or 0)
    try:
        proc.terminate()
        try:
            proc.wait(timeout=3.0)
        except Exception:
            proc.kill()
        return True
    finally:
        state["process"] = None
        _clear_worker_lease(state)
        _cleanup_worker_runtime(state)
        _remove_sessions_for_worker(worker_pid)


def cleanup_owned_resources() -> None:
    cancel_worker()
    try:
        state = _state()
        _remove_owned_session(str(state.get("recovery_session_path", "") or ""))
        state.pop("recovery_session_path", None); state.pop("recovery_dump_path", None); state.pop("recovery_points", None)
    except Exception:
        pass
    try:
        bpy = _bpy()
        _reset_all_scene_runtime_state()
        handlers = getattr(getattr(bpy, "app", None), "handlers", None)
        try:
            records = list(_handler_records())
        except Exception:
            records = []
        for record in reversed(records):
            _remove_exact_handler(record.get("collection"), record.get("callback"))
        if handlers is not None:
            _remove_stale_owned_handlers(handlers)
        ns = bpy.app.driver_namespace
        timer = ns.get(TIMER_KEY)
        if timer is not None and bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
        ns.pop(TIMER_KEY, None)
        ns.pop(STATE_KEY, None)
        ns.pop(HANDLERS_KEY, None)
    except Exception:
        pass
    try:
        cleanup_abandoned_scratch()
    except Exception:
        pass


def main(argv: list[str]) -> int:
    args = list(argv)
    if "--" in args:
        args = args[args.index("--") + 1:]
    elif args and args[0] == "--":
        args = args[1:]
    if not args:
        return 2
    command = args[0]
    try:
        if command == "scan" and len(args) >= 2:
            roots = args[1:-1]
            include_ambient = True
            include_external_crashes = True
            if "--roots-only" in roots:
                include_ambient = False
                roots = [item for item in roots if item != "--roots-only"]
            if "--no-external-crashes" in roots:
                include_external_crashes = False
                roots = [item for item in roots if item != "--no-external-crashes"]
            return command_scan(args[-1], roots, include_ambient=include_ambient, include_external_crashes=include_external_crashes)
        if command == "copy" and len(args) == 4:
            return command_copy(args[1], args[2], args[3])
        if command == "deep_analyze" and len(args) == 3:
            return command_deep_analyze(args[1], args[2])
        if command == "deep_extract" and len(args) == 5:
            return command_deep_extract(args[1], int(args[2]), args[3], args[4])
        if command == "deep" and len(args) == 4:
            return command_deep(args[1], args[2], args[3])
        if command == "dump_analyze" and len(args) == 3:
            return command_dump_analyze(int(args[1]), args[2])
        if command == "dump_rescue" and len(args) == 4:
            return command_dump_rescue(int(args[1]), args[2], args[3])
        if command == "dump_extract" and len(args) == 5:
            return command_dump_extract(args[1], int(args[2]), args[3], args[4])
        if command == "fixture_rescue" and len(args) == 4:
            return command_fixture_rescue(args[1], args[2], args[3])
    except Exception as exc:
        if args:
            try:
                out = Path(args[-1])
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(json.dumps({"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            except Exception:
                pass
        return 9
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
