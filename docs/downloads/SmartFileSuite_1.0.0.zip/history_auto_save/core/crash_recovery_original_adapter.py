"""Safe Smart File host for the verbatim Crash Rescue 2.3.0 engine.

All reconstruction is performed by its original cmd_analyze/cmd_extract/
cmd_rescue entry points.  This adapter only provides private same-directory
staging, structured result reporting and non-overwrite final promotion.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import uuid

ENGINE_VERSION = "2.3.0-command-host"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()



def _valid_small_memfile(engine, blob: bytes) -> bool:
    """Recognize a complete small undo stream by structure, never size alone."""
    import struct
    if not blob.startswith(engine.BLEND_HDR):
        return False
    offset = len(engine.BLEND_HDR)
    dna_data = None
    scene_index = None
    has_global = False
    ended = False
    while offset + engine.BHEAD <= len(blob):
        code = blob[offset:offset + 4]
        sdna_index = struct.unpack_from('<I', blob, offset + 4)[0]
        size = struct.unpack_from('<Q', blob, offset + 16)[0]
        end = offset + engine.BHEAD + size
        if end > len(blob):
            return False
        if code == b'ENDB':
            ended = size == 0 and end == len(blob)
            break
        if code == b'DNA1':
            if dna_data is not None:
                return False
            dna_data = blob[offset + engine.BHEAD:end]
        elif code == b'SC\0\0':
            scene_index = sdna_index
        elif code == b'GLOB':
            has_global = True
        offset = end
    if not ended or dna_data is None or scene_index is None or not has_global:
        return False
    try:
        dna = engine.SDNA(dna_data)
        return (dna.name_of(scene_index) == 'Scene'
                and all(name in dna.by_name for name in ('ID', 'Scene', 'FileGlobal')))
    except (ValueError, IndexError, KeyError, UnicodeError, AssertionError, struct.error):
        return False


def _linked_undo_order(engine, source, steps):
    """Recognize the x64 5.1 Global Undo list; ambiguous/foreign layouts abstain.

    BLO_undofile.hh and BKE_undo_system.hh define MemFileUndoData and
    UndoStep; memfile_undo.cc owns the data pointer at offset104. Validate
    both levels of ownership and reciprocal links, not allocation addresses.
    """
    import struct
    if len(steps) < 2:
        return {}
    owners = {}
    hits = source.find_all_multi([struct.pack('<Q', step['head']) for step in steps])
    for index, step in enumerate(steps):
        last, current = 0, step['head']
        for _ in step['plan']:
            last, current = current, source.u64(current)
        if current != 0:
            return {}
        for hit in hits.get(struct.pack('<Q', step['head']), ()):
            address = source.off_to_va(hit)
            if address is None:
                continue
            data = address - 1024
            path = source.read(data, 1024)
            # Accounting includes implicit shared arrays, not just stream bytes.
            size = source.u64(address + 16)
            if (engine._plausible_ptr(data) and path is not None and b'\0' in path
                    and source.u64(address + 8) == last
                    and size is not None and size == source.u64(address + 32)):
                owners[data] = index
    if not owners:
        return {}
    pointers = source.find_all_multi([struct.pack('<Q', data) for data in owners])
    nodes = {}
    for data, index in owners.items():
        for hit in pointers.get(struct.pack('<Q', data), ()):
            address = source.off_to_va(hit)
            if address is None:
                continue
            node = address - 104
            kind = source.u64(node + 80)
            kind_name = source.u64(kind + 16) if kind else None
            flags = source.read(node + 96, 4)
            name = source.read(node + 16, 64)
            if (engine._plausible_ptr(node) and kind_name
                    and source.read(kind_name, 12) == b'Global Undo\0'
                    and source.u64(kind + 80) == 112
                    and flags is not None and len(flags) == 4
                    and all(flag in (0, 1) for flag in flags)
                    and name is not None and name[0] and b'\0' in name
                    and source.u64(node + 88) == source.u64(data + 1056)):
                nodes[node] = (index, source.u64(node), source.u64(node + 8), kind)
    roots = [node for node, value in nodes.items() if value[2] == 0]
    if len(roots) != 1:
        return {}
    current, previous, order, seen = roots[0], 0, {}, set()
    kind = nodes[current][3]
    while current:
        if current not in nodes or current in seen:
            return {}
        index, following, back, current_kind = nodes[current]
        if back != previous or current_kind != kind or index in order:
            return {}
        seen.add(current); order[index] = len(order)
        previous, current = current, following
    return order if len(order) == len(steps) and len(seen) == len(nodes) else {}


def _install_small_chain_support(engine) -> None:
    """Keep the bundled engine byte-for-byte; extend candidate recognition only.

    Original reconstruction/inlining/extraction remain its own commands.
    Geometry arrays may be implicitly shared outside the undo stream, so a valid
    16k-vertex scene can have a 533kB chain below the original 1MiB heuristic.
    Reuse the original scan's pointer hits instead of scanning the dump twice.
    """
    import collections
    import struct
    if getattr(engine, '_smart_file_small_chain_support', False):
        return
    original_find = engine.find_undo_chains
    original_rank = engine.rank_steps

    class ScanCache:
        def __init__(self, source):
            self.source = source
            self.headers = []
            self.hits = {}

        def __getattr__(self, name):
            return getattr(self.source, name)

        def find_all(self, needle, *args, **kwargs):
            found = self.source.find_all(needle, *args, **kwargs)
            if needle == engine.BLEND_HDR:
                self.headers = found
            return found

        def find_all_multi(self, needles, *args, **kwargs):
            self.hits = self.source.find_all_multi(needles, *args, **kwargs)
            return self.hits

    def find_with_small_streams(source, max_steps=200):
        cached = ScanCache(source)
        steps = original_find(cached, max_steps=max_steps)
        small = {}
        for offset in cached.headers:
            address = source.off_to_va(offset)
            if address is None:
                continue
            for hit in cached.hits.get(struct.pack('<Q', address), ()):
                hit_address = source.off_to_va(hit)
                if hit_address is None:
                    continue
                head = hit_address - 16
                current, previous, total = head, 0, 0
                visited, plan, pieces = set(), [], []
                while current and current not in visited and len(visited) < 8192:
                    if not engine._plausible_ptr(current) or source.u64(current + 8) != previous:
                        break
                    visited.add(current)
                    buf, size, following = source.u64(current + 16), source.u64(current + 24), source.u64(current)
                    if size is None or not 0 < size < (1 << 20) or total + size >= (1 << 20):
                        break
                    data = source.read(buf, size) if buf is not None else None
                    if data is None or len(data) != size:
                        break
                    plan.append((buf, size)); pieces.append(data); total += size
                    if following == 0:
                        blob = b''.join(pieces)
                        if _valid_small_memfile(engine, blob):
                            key = hashlib.blake2b(blob, digest_size=16).hexdigest()
                            small.setdefault(key, {'plan': plan, 'chunks': len(plan), 'bytes': total, 'head': head})
                        break
                    previous, current = current, following
        combined = sorted(steps + list(small.values()), key=lambda step: step['head'])[:max_steps]
        owners = collections.Counter(buf for step in combined for buf in {buf for buf, _ in step['plan']})
        chronological = _linked_undo_order(engine, source, combined)
        for index, step in enumerate(combined):
            step['linked_undo_position'] = chronological.get(index)
            step['unique_bufs'] = sum(owners[buf] == 1 for buf in {buf for buf, _ in step['plan']})
        if small:
            engine.log('  SmartFile structurally validated small undo steps: %d' % len(small))
        return combined

    def rank_with_verified_terminal(steps, expectations=None):
        order = original_rank(steps, expectations)
        positions = [step.get('linked_undo_position') for step in steps]
        basis = 'ORIGINAL_RANKING'
        if (len(steps) > 1 and all(isinstance(pos, int) for pos in positions)
                and sorted(positions) == list(range(len(steps)))):
            terminal = positions.index(len(steps) - 1)
            # Preserve independent crash-log agreement when it identifies a state.
            if steps[terminal]['log_agree'] >= max(step['log_agree'] for step in steps):
                order = sorted(order, key=lambda index: positions[index], reverse=True)
                basis = 'VALIDATED_GLOBAL_UNDO_LINKED_LIST'
                for rank, index in enumerate(order):
                    steps[index]['rank'] = rank
        for step in steps:
            step['info']['linked_undo_position'] = step.get('linked_undo_position')
            step['info']['ranking_basis'] = basis
        return order

    engine.rank_steps = rank_with_verified_terminal
    engine.find_undo_chains = find_with_small_streams
    engine._smart_file_small_chain_support = True


def _engine():
    name = "smart_file_original_crash_rescue_2_3_0"
    mod = sys.modules.get(name)
    if mod is not None:
        _install_small_chain_support(mod)
        return mod
    path = Path(__file__).with_name("crash_recovery_original_2_3_0.py")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("original Crash Rescue engine unavailable")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    _install_small_chain_support(mod)
    return mod


def _stage(destination: str | os.PathLike[str]) -> tuple[Path, Path, Path]:
    final = Path(destination).resolve()
    final.parent.mkdir(parents=True, exist_ok=True)
    if final.exists():
        raise FileExistsError(f"destination already exists: {final}")
    token = uuid.uuid4().hex
    return final, final.with_name(f".sfstage-{token}.blend"), final.with_name(f".sfstage-{token}.json")


def _promote(stage: Path, final: Path) -> Path:
    if not stage.is_file() or stage.stat().st_size <= 0:
        raise RuntimeError("original engine did not create a nonempty staged blend")
    # link() is create-only, therefore a destination created after the precheck
    # cannot be overwritten; both paths are deliberately in the final parent.
    try:
        os.link(stage, final)
    except FileExistsError:
        raise FileExistsError(f"destination appeared during recovery: {final}")
    except OSError as exc:
        raise RuntimeError(f"atomic non-overwrite promotion failed: {exc}")
    stage.unlink(missing_ok=True)
    return final


def _read_report(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def analyze_source(source: str, **_unused) -> dict:
    engine = _engine()
    report = Path(tempfile.gettempdir()) / f"sf-analyze-{uuid.uuid4().hex}.json"
    try:
        code = int(engine.cmd_analyze(str(source), str(report)))
        payload = _read_report(report)
        return {"schema": "smart_file/original_2_3_0/analyze/1", "engine": ENGINE_VERSION,
                "generated": _now(), "source": str(source), "return_code": code,
                "status": "PASS" if code == 0 and payload.get("steps") else "FAIL",
                "steps": list(payload.get("steps") or []), "original_report": payload}
    finally:
        report.unlink(missing_ok=True)


def analyze_dump(source: str, report_path: str | os.PathLike[str]) -> dict:
    """Run the verbatim 2.3.0 analyzer and retain its exact report."""
    engine = _engine()
    report = Path(report_path).resolve()
    report.parent.mkdir(parents=True, exist_ok=True)
    code = int(engine.cmd_analyze(str(source), str(report)))
    payload = _read_report(report)
    return {"return_code": code, "steps": list(payload.get("steps") or []),
            "original_report": payload, "report": str(report)}


def extract_raw(source: str, step_index: int, raw_output: str | os.PathLike[str]) -> dict:
    """Materialize one engine step to an owned raw file; no final promotion."""
    engine = _engine()
    raw = Path(raw_output).resolve()
    raw.parent.mkdir(parents=True, exist_ok=True)
    if raw.exists():
        raise FileExistsError(f"raw output already exists: {raw}")
    code = int(engine.cmd_extract(str(source), int(step_index), str(raw)))
    if code not in {0, 5} or not raw.is_file() or raw.stat().st_size <= 0:
        raise RuntimeError(f"original cmd_extract returned {code} without usable output")
    return {"return_code": code, "raw": str(raw), "raw_size": raw.stat().st_size,
            "raw_sha256": _sha(raw), "warning": code == 5}


def rescue_raw(source: str, raw_output: str | os.PathLike[str], report_path: str | os.PathLike[str]) -> dict:
    """Run the original one-button rescue into an owned raw file.

    Return code 5 means unresolved references.  It is retained as a warning and
    may proceed to Blender finalization, but is never itself a successful final
    result.
    """
    engine = _engine()
    raw = Path(raw_output).resolve()
    report = Path(report_path).resolve()
    raw.parent.mkdir(parents=True, exist_ok=True)
    if raw.exists():
        raise FileExistsError(f"raw output already exists: {raw}")
    code = int(engine.cmd_rescue(str(source), str(raw), str(report)))
    payload = _read_report(report)
    if code not in {0, 5} or not raw.is_file() or raw.stat().st_size <= 0:
        raise RuntimeError(f"original cmd_rescue returned {code} without usable output")
    return {"return_code": code, "raw": str(raw), "raw_size": raw.stat().st_size,
            "raw_sha256": _sha(raw), "warning": code == 5,
            "steps": list(payload.get("steps") or []), "original_report": payload}


def extract_step(source: str, step_index: int, destination: str | os.PathLike[str], **_unused) -> dict:
    engine = _engine(); final, stage, _report = _stage(destination)
    try:
        code = int(engine.cmd_extract(str(source), int(step_index), str(stage)))
        if code != 0:
            raise RuntimeError(f"original cmd_extract returned {code}")
        output = _promote(stage, final)
        return {"schema": "smart_file/original_2_3_0/extract/1", "engine": ENGINE_VERSION,
                "generated": _now(), "status": "PASS", "source": str(source),
                "selected_step_index": int(step_index), "destination": str(output),
                "destination_size": output.stat().st_size, "destination_sha256": _sha(output),
                "return_code": code}
    finally:
        stage.unlink(missing_ok=True)


def rescue_best(source: str, destination: str | os.PathLike[str], **_unused) -> dict:
    engine = _engine(); final, stage, report = _stage(destination)
    try:
        code = int(engine.cmd_rescue(str(source), str(stage), str(report)))
        payload = _read_report(report)
        if code != 0:
            raise RuntimeError(f"original cmd_rescue returned {code}; unresolved references are not accepted")
        output = _promote(stage, final)
        return {"schema": "smart_file/original_2_3_0/rescue/1", "engine": ENGINE_VERSION,
                "generated": _now(), "status": "PASS", "source": str(source),
                "destination": str(output), "destination_size": output.stat().st_size,
                "destination_sha256": _sha(output), "return_code": code,
                "original_report": payload, "steps": list(payload.get("steps") or [])}
    finally:
        stage.unlink(missing_ok=True)
        report.unlink(missing_ok=True)
