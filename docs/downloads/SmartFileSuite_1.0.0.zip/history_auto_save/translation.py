# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi. All Rights Reserved.
#
# Terms of Use:
# - All rights, including copyright and intellectual property rights, belong to JELararagi.
# - Redistribution, resale, modification, reverse engineering, or sharing without explicit permission is prohibited.
# ------------------------------------------------------------------------------

import re

import bpy

# Translation declarations are identical in foreground and background Blender.
# Importing these tables does not require a UI context.
try:
    from ..ui_language_runtime import iface as _suite_iface, tip as _suite_tip, data as _suite_data, split_bilingual as _suite_split_bilingual
except Exception:  # pragma: no cover
    _suite_iface = _suite_tip = _suite_data = _suite_split_bilingual = None
from .translation_data import BASE_PAIRS, EXTRA_UI_TRANSLATIONS
from ..language_extra import has_leftover_english

_I18N_KEY = __name__


def _t(src, dst):
    return (("*", src), dst)


def _has_ascii(text: str) -> bool:
    return bool(re.search(r"[A-Za-z]", text or ""))


def _has_japanese(text: str) -> bool:
    return bool(re.search(r"[ぁ-んァ-ン一-龯]", text or ""))


def _split_bilingual(msgid: str):
    if callable(_suite_split_bilingual):
        try:
            pair = _suite_split_bilingual(msgid)
            if pair:
                return pair
        except Exception:
            pass
    if not isinstance(msgid, str):
        return None
    msgid = msgid.strip()
    if not msgid:
        return None
    candidates = []
    for sep in (' / ', ' ｜ ', ' | ', '：', ' : '):
        cursor = 0
        while True:
            idx = msgid.find(sep, cursor)
            if idx < 0:
                break
            left = msgid[:idx].strip()
            right = msgid[idx + len(sep):].strip()
            if left and right and _has_japanese(right) and not _has_japanese(left):
                candidates.append((len(re.findall(r'[A-Za-z]', right)), -idx, left, right))
            elif left and right and _has_japanese(left) and not _has_japanese(right):
                candidates.append((len(re.findall(r'[A-Za-z]', left)), -idx, right, left))
            cursor = idx + len(sep)
    if candidates:
        candidates.sort()
        return candidates[0][2], candidates[0][3]
    return None


def _clean_msgid(msgid: str) -> str:
    if not isinstance(msgid, str):
        return msgid
    pair = _split_bilingual(msgid)
    if pair:
        return pair[0]
    return msgid.strip()


TRANSLATIONS = {"ja_JP": dict(_t(src, dst) for src, dst in BASE_PAIRS)}
TRANSLATIONS.setdefault("ja_JP", {}).update(EXTRA_UI_TRANSLATIONS)
TRANSLATIONS["ja_JP"] = {key: value for key, value in TRANSLATIONS["ja_JP"].items() if not has_leftover_english(value)}


_MODE_LABELS = {
    'OBJECT': "Object Mode",
    'EDIT_MESH': "Mesh Edit Mode",
    'EDIT_CURVE': "Curve Edit Mode",
    'EDIT_CURVES': "Hair Curves Edit Mode",
    'EDIT_SURFACE': "Surface Edit Mode",
    'EDIT_TEXT': "Text Edit Mode",
    'EDIT_ARMATURE': "Armature Edit Mode",
    'EDIT_METABALL': "Metaball Edit Mode",
    'EDIT_LATTICE': "Lattice Edit Mode",
    'EDIT_GREASE_PENCIL': "Grease Pencil Edit Mode",
    'EDIT_GPENCIL': "Grease Pencil Edit Mode",
    'EDIT_POINTCLOUD': "Point Cloud Edit Mode",
    'POSE': "Pose Mode",
    'SCULPT': "Sculpt Mode",
    'SCULPT_CURVES': "Hair Curves Sculpt Mode",
    'SCULPT_GREASE_PENCIL': "Grease Pencil Sculpt Mode",
    'SCULPT_GPENCIL': "Grease Pencil Sculpt Mode",
    'PAINT_WEIGHT': "Weight Paint Mode",
    'PAINT_VERTEX': "Vertex Paint Mode",
    'PAINT_TEXTURE': "Texture Paint Mode",
    'PAINT_GREASE_PENCIL': "Grease Pencil Draw Mode",
    'PAINT_GPENCIL': "Grease Pencil Draw Mode",
    'WEIGHT_GREASE_PENCIL': "Grease Pencil Weight Paint Mode",
    'WEIGHT_GPENCIL': "Grease Pencil Weight Paint Mode",
    'VERTEX_GREASE_PENCIL': "Grease Pencil Vertex Paint Mode",
    'VERTEX_GPENCIL': "Grease Pencil Vertex Paint Mode",
    'PARTICLE': "Particle Edit Mode",
}


def mode_label(mode: str) -> str:
    """Display name of a saved context.mode value."""
    name = _MODE_LABELS.get(mode or "")
    return iface(name) if name else "-"


def iface(msgid: str) -> str:
    if callable(_suite_iface):
        try:
            return _suite_iface(msgid)
        except Exception:
            pass
    msgid = _clean_msgid(msgid)
    try:
        translated = bpy.app.translations.pgettext_iface(msgid)
    except Exception:
        translated = msgid
    return translated or msgid


def tip(msgid: str) -> str:
    if callable(_suite_tip):
        try:
            return _suite_tip(msgid)
        except Exception:
            pass
    msgid = _clean_msgid(msgid)
    try:
        translated = bpy.app.translations.pgettext_tip(msgid)
    except Exception:
        translated = msgid
    return translated or msgid


def data(msgid: str) -> str:
    if callable(_suite_data):
        try:
            return _suite_data(msgid)
        except Exception:
            pass
    msgid = _clean_msgid(msgid)
    try:
        translated = bpy.app.translations.pgettext(msgid)
    except Exception:
        translated = msgid
    return translated or msgid


def register():
    try:
        bpy.app.translations.unregister(_I18N_KEY)
    except Exception:
        pass
    bpy.app.translations.register(_I18N_KEY, TRANSLATIONS)


def unregister():
    try:
        bpy.app.translations.unregister(_I18N_KEY)
    except Exception:
        pass
