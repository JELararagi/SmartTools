# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

#  【利用規約】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - 禁止事項: 許可なき再配布、改変、転売を固く禁じます。

bl_info = {
    "name": "History Snapshot Protection",
    "author": "JELararagi",
    "version": (5, 75, 88),
    "blender": (5, 1, 0),
    "location": "Smart File > Recover",
    "description": "Modern history logging, manual restore points, optional timed restore helpers, confirm-before-restore, selection-first restore, snapshot-only list, and rolling autosave for Blender 5.x",
    "category": "System",
}

SMART_FILE_SUITE_VERSION = (5, 75, 88)

from . import translation as i18n, properties as props
from .operators import history_operators as history_ops
from .ui import panels
from .core import runtime

# Standalone History Panel wrappers are intentionally excluded. The canonical
# Smart File History & Restore section calls panels.draw_history_popup_ui.
CLASSES = tuple(props.CLASSES) + tuple(history_ops.CLASSES)


def _uhm_class_has_bl_rna(cls) -> bool:
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _uhm_lookup_registered_class(cls):
    """Compatibility helper using exact class identity only."""
    return cls if _uhm_class_has_bl_rna(cls) else None


def _uhm_safe_register_class(cls):
    """Registration is owned by history_integration; never register here."""
    del cls
    return False


def _uhm_registered_pg_type(cls):
    if _uhm_class_has_bl_rna(cls):
        return cls
    raise RuntimeError(f"History PropertyGroup RNA is not ready: {getattr(cls, '__name__', cls)!r}")


def _apply_suite_settings_after_pointer_registration(context=None) -> bool:
    try:
        from .. import settings as _sfs_settings
        apply_all = getattr(_sfs_settings, "apply_all", None)
        if callable(apply_all):
            apply_all(context)
        return True
    except Exception:
        return False


def register() -> bool:
    """Compatibility facade; never acquire or synchronize lifecycle resources.

    ``history_integration.py`` is executed into the Smart File root bootstrap
    namespace. Importing that file again as a child module would create a second
    owner token and generation. The facade therefore consults the already-loaded
    root owner only and performs no register/sync operation of its own.
    """
    try:
        import sys

        root_name = (__package__ or "").rpartition(".")[0]
        root_module = sys.modules.get(root_name)
        status_fn = getattr(root_module, "_sf_history_status", None)
        if not callable(status_fn):
            return False
        return bool(status_fn().get("registered"))
    except Exception:
        return False


def unregister() -> bool:
    """Compatibility facade; lifecycle teardown is owned by core only."""
    return True


__all__ = ["CLASSES", "register", "unregister", "runtime", "props", "history_ops", "panels"]


