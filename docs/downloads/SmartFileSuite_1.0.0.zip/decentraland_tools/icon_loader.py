# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
"""Custom icon loading for Decentraland Tools.

PNG icons are loaded from the packaged flat ``icons`` folder with
``bpy.utils.previews``.  The loader is intentionally lazy-retry capable because
some Blender startup paths expose previews only after add-on registration has
started.
"""

from __future__ import annotations

import os
from pathlib import Path

import bpy

_previews_mod = None
preview_collections = {}
_loaded_icon_dir = ''
_DRIVER_NAMESPACE_KEY = 'smart_file_suite.decentraland.preview_collection'



def _get_previews():
    global _previews_mod
    if _previews_mod is not None:
        return _previews_mod
    try:
        import bpy.utils.previews as _mod
        _previews_mod = _mod
        return _mod
    except Exception:
        pass
    try:
        _mod = getattr(getattr(bpy, 'utils', None), 'previews', None)
        if _mod is not None:
            _previews_mod = _mod
            return _mod
    except Exception:
        pass
    return None


def _icon_dir_candidates():
    package_root = Path(__file__).resolve().parents[1]
    candidates = [package_root / 'icons']
    try:
        func = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
        if callable(func):
            for package_id in ('smart_file_suite', 'Smart_File_Suite'):
                try:
                    candidates.append(Path(func(package_id, path='icons', create=False)))
                except TypeError:
                    try:
                        candidates.append(Path(func(package_id, path='icons')))
                    except Exception:
                        pass
                except Exception:
                    pass
    except Exception:
        pass
    unique = []
    seen = set()
    for candidate in candidates:
        try:
            key = str(candidate.resolve())
        except Exception:
            key = str(candidate)
        if key not in seen:
            seen.add(key)
            unique.append(Path(key))
    return unique


ICONS = {
    'ORIGIN_TL': 'dcl_origin_tl.png',
    'ORIGIN_TR': 'dcl_origin_tr.png',
    'ORIGIN_CENTER': 'dcl_origin_center.png',
    'ORIGIN_BL': 'dcl_origin_bl.png',
    'ORIGIN_BR': 'dcl_origin_br.png',
    'CUBE_SPARK': 'dcl_lod_generate.png',
}

def _resolve_icon_dir() -> Path:
    filenames = set(ICONS.values())
    for folder in _icon_dir_candidates():
        try:
            if folder.is_dir() and any((folder / filename).is_file() for filename in filenames):
                return folder
        except Exception:
            pass
    return _icon_dir_candidates()[0]


def _driver_namespace_collection():
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if ns is None:
            return None
        return ns.get(_DRIVER_NAMESPACE_KEY)
    except Exception:
        return None


def _store_driver_namespace_collection(pcoll) -> None:
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if ns is not None:
            ns[_DRIVER_NAMESPACE_KEY] = pcoll
    except Exception:
        pass


def _ensure_cleanup_registered() -> None:
    try:
        from .. import preview_cleanup
        preview_cleanup.register_atexit()
    except Exception:
        pass


def _load_missing_icons(icons, icon_dir: Path) -> None:
    for name, filename in ICONS.items():
        filepath = icon_dir / filename
        if not filepath.exists():
            continue
        try:
            if name in icons:
                continue
        except Exception:
            pass
        try:
            icons.load(name, str(filepath), 'IMAGE')
        except Exception:
            pass


def register(force: bool = False):
    """Load custom icons into a persistent preview collection."""
    global _loaded_icon_dir
    del force
    icon_dir = _resolve_icon_dir()
    pcoll = preview_collections.get('dcl') or _driver_namespace_collection()
    if pcoll is not None:
        preview_collections['dcl'] = pcoll
        _store_driver_namespace_collection(pcoll)
        _ensure_cleanup_registered()
        _load_missing_icons(pcoll, icon_dir)
        _loaded_icon_dir = str(icon_dir)
        return True

    previews = _get_previews()
    if previews is None:
        return False
    try:
        icons = previews.new()
    except Exception:
        return False
    _load_missing_icons(icons, icon_dir)
    preview_collections['dcl'] = icons
    _store_driver_namespace_collection(icons)
    _ensure_cleanup_registered()
    _loaded_icon_dir = str(icon_dir)
    return True


def unregister():
    """Detach module references without freeing icon IDs still used by pending UI events."""
    pcoll = _driver_namespace_collection()
    preview_collections.clear()
    if pcoll is not None:
        preview_collections['dcl'] = pcoll


def get_icon(name):
    """Return the icon_id for a custom icon, or 0 when Blender's standard fallback should be used."""
    key = str(name or '').strip()
    if not key or key not in ICONS:
        return 0
    pcoll = preview_collections.get("dcl")
    try:
        if pcoll is None or key not in pcoll:
            register(force=pcoll is not None)
            pcoll = preview_collections.get("dcl")
        if pcoll and key in pcoll:
            return int(getattr(pcoll[key], 'icon_id', 0) or 0)
    except Exception:
        return 0
    return 0
