# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Object Reporter",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Reporter",
    "description": "Metadata presets, select by properties, viewport labels, summary table, CSV export",
    "category": "Object",
}

import bpy
from bpy.props import PointerProperty

from .core import (
    REPORTER_FilterCondition,
    REPORTER_Preset,
    REPORTER_PropertyDefinition,
    REPORTER_SceneSettings,
    REPORTER_SharedField,
)
from .filter import (
    REPORTER_OT_object_reporter_add_condition,
    REPORTER_OT_object_reporter_clear_all,
    REPORTER_OT_object_reporter_add_to_selection,
    REPORTER_OT_object_reporter_isolate,
    REPORTER_OT_object_reporter_select,
    REPORTER_OT_object_reporter_pick_property,
    REPORTER_OT_object_reporter_pick_value,
    REPORTER_OT_object_reporter_remove,
    REPORTER_OT_object_reporter_show_all,
    REPORTER_PT_object_reporter_object_reporter_select,
)
from .panels import (
    REPORTER_PT_object_reporter_object_reporter_fields,
    REPORTER_PT_object_reporter_object_reporter,
    REPORTER_PT_object_reporter_object_reporter_output,
)
from .reporter import (
    REPORTER_OT_object_reporter_add_field,
    REPORTER_OT_object_reporter_clear,
    REPORTER_OT_object_reporter_export_csv,
    REPORTER_OT_object_reporter_pick_field,
    REPORTER_OT_object_reporter_refresh,
    REPORTER_OT_object_reporter_remove_2,
    REPORTER_OT_object_reporter_select_2,
    REPORTER_PT_object_reporter_object_reporter_csv_export,
    REPORTER_PT_object_reporter_object_reporter_grouping,
    REPORTER_PT_object_reporter_object_reporter_summary,
    REPORTER_PT_object_reporter_object_reporter_viewport_labels,
    REPORTER_UL_SharedFields,
    cleanup_stale_label_generation,
    finalize_runtime_generation,
    prepare_runtime_generation,
    sync_label_runtime_with_scene,
    unregister_handler,
)
from .tagger import (
    REPORTER_OT_object_reporter_add_as_filter,
    REPORTER_OT_object_reporter_add_preset,
    REPORTER_OT_object_reporter_add_field_2,
    REPORTER_OT_object_reporter_add_to_fields,
    REPORTER_OT_object_reporter_apply,
    REPORTER_OT_object_reporter_apply_and_overwrite,
    REPORTER_OT_object_reporter_pick_value_2,
    REPORTER_OT_object_reporter_pick_value_3,
    REPORTER_OT_object_reporter_remove_property,
    REPORTER_OT_object_reporter_remove_preset,
    REPORTER_OT_object_reporter_remove_field,
    REPORTER_OT_object_reporter_set_property,
    REPORTER_PT_object_reporter_object_reporter_presets,
    REPORTER_PT_object_reporter_object_reporter_tag_selected,
    REPORTER_UL_PresetProperties,
    REPORTER_UL_Presets,
)


_REGISTERED_CLASSES = []
_POINTER_DESCRIPTOR = None
_POINTER_ACQUIRED = False
_LAST_REGISTER_ERROR = ""


def _class_ready(cls) -> bool:
    try:
        rna = vars(cls).get("bl_rna") if isinstance(cls, type) else None
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _sidebar_panel_deferred(cls) -> bool:
    # Smart File's loader keeps VIEW_3D sidebar panels unregistered on purpose
    # and draws them inside its own N-panel, so they never own RNA here.
    try:
        return bool(
            isinstance(cls, type)
            and issubclass(cls, bpy.types.Panel)
            and str(getattr(cls, "bl_space_type", "") or "").upper() == "VIEW_3D"
            and str(getattr(cls, "bl_region_type", "") or "").upper() == "UI"
        )
    except Exception:
        return False


def _pointer_matches(descriptor, expected_type) -> bool:
    if descriptor is None:
        return False
    try:
        fixed = getattr(descriptor, "fixed_type", None)
        expected_rna = vars(expected_type).get("bl_rna")
        if fixed is expected_type or fixed is expected_rna:
            return True
        keywords = getattr(descriptor, "keywords", None)
        return bool(isinstance(keywords, dict) and keywords.get("type") is expected_type)
    except Exception:
        return False

# Registration order: PropertyGroups -> Operators -> UILists -> Panels
classes = (
    # PropertyGroups
    REPORTER_PropertyDefinition,
    REPORTER_Preset,
    REPORTER_FilterCondition,
    REPORTER_SharedField,
    REPORTER_SceneSettings,
    # Operators — tagger
    REPORTER_OT_object_reporter_set_property,
    REPORTER_OT_object_reporter_pick_value_2,
    REPORTER_OT_object_reporter_remove_property,
    REPORTER_OT_object_reporter_add_preset,
    REPORTER_OT_object_reporter_remove_preset,
    REPORTER_OT_object_reporter_add_field_2,
    REPORTER_OT_object_reporter_remove_field,
    REPORTER_OT_object_reporter_apply,
    REPORTER_OT_object_reporter_apply_and_overwrite,
    REPORTER_OT_object_reporter_add_as_filter,
    REPORTER_OT_object_reporter_add_to_fields,
    REPORTER_OT_object_reporter_pick_value_3,
    # Operators — filter
    REPORTER_OT_object_reporter_add_condition,
    REPORTER_OT_object_reporter_remove,
    REPORTER_OT_object_reporter_clear_all,
    REPORTER_OT_object_reporter_select,
    REPORTER_OT_object_reporter_add_to_selection,
    REPORTER_OT_object_reporter_isolate,
    REPORTER_OT_object_reporter_show_all,
    REPORTER_OT_object_reporter_pick_property,
    REPORTER_OT_object_reporter_pick_value,
    # Operators — reporter
    REPORTER_OT_object_reporter_add_field,
    REPORTER_OT_object_reporter_remove_2,
    REPORTER_OT_object_reporter_pick_field,
    REPORTER_OT_object_reporter_clear,
    REPORTER_OT_object_reporter_refresh,
    REPORTER_OT_object_reporter_select_2,
    REPORTER_OT_object_reporter_export_csv,
    # UILists
    REPORTER_UL_Presets,
    REPORTER_UL_PresetProperties,
    REPORTER_UL_SharedFields,
    # Panels (parent first, then children)
    REPORTER_PT_object_reporter_object_reporter,
    REPORTER_PT_object_reporter_object_reporter_fields,
    REPORTER_PT_object_reporter_object_reporter_presets,
    REPORTER_PT_object_reporter_object_reporter_tag_selected,
    REPORTER_PT_object_reporter_object_reporter_select,
    REPORTER_PT_object_reporter_object_reporter_output,
    REPORTER_PT_object_reporter_object_reporter_viewport_labels,
    REPORTER_PT_object_reporter_object_reporter_grouping,
    REPORTER_PT_object_reporter_object_reporter_summary,
    REPORTER_PT_object_reporter_object_reporter_csv_export,
)



def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def sync_runtime_after_settings() -> None:
    sync_label_runtime_with_scene()


def register():
    global _REGISTERED_CLASSES, _POINTER_DESCRIPTOR, _POINTER_ACQUIRED, _LAST_REGISTER_ERROR
    _LAST_REGISTER_ERROR = ""
    if not prepare_runtime_generation():
        _LAST_REGISTER_ERROR = "Object Reporter stale runtime cleanup failed"
        return False
    registered = []
    pointer_acquired = False
    try:
        for cls in classes:
            if not _class_ready(cls):
                bpy.utils.register_class(cls)
            if not _class_ready(cls) and not _sidebar_panel_deferred(cls):
                raise RuntimeError(f"class-owned RNA validation failed: {cls.__name__}")
            registered.append(cls)
        existing = getattr(bpy.types.Scene, "reporter_settings", None) if hasattr(bpy.types.Scene, "reporter_settings") else None
        if existing is None:
            bpy.types.Scene.reporter_settings = PointerProperty(type=REPORTER_SceneSettings)
            existing = getattr(bpy.types.Scene, "reporter_settings", None)
            pointer_acquired = True
        if not _pointer_matches(existing, REPORTER_SceneSettings):
            raise RuntimeError("Scene.reporter_settings has a foreign PointerProperty type")
        _REGISTERED_CLASSES = list(registered)
        _POINTER_DESCRIPTOR = existing
        _POINTER_ACQUIRED = pointer_acquired
        _apply_suite_settings_after_pointer_registration(getattr(bpy, "context", None))
        return True
    except Exception as exc:
        _LAST_REGISTER_ERROR = f"{type(exc).__name__}: {exc}"[:1024]
        try:
            unregister_handler()
        except Exception:
            pass
        if pointer_acquired and hasattr(bpy.types.Scene, "reporter_settings"):
            try:
                if getattr(bpy.types.Scene, "reporter_settings") is existing:
                    del bpy.types.Scene.reporter_settings
            except Exception:
                pass
        for cls in reversed(registered):
            try:
                if _class_ready(cls):
                    bpy.utils.unregister_class(cls)
            except Exception:
                pass
        _REGISTERED_CLASSES = []
        _POINTER_DESCRIPTOR = None
        _POINTER_ACQUIRED = False
        finalize_runtime_generation()
        return False


def unregister():
    global _REGISTERED_CLASSES, _POINTER_DESCRIPTOR, _POINTER_ACQUIRED, _LAST_REGISTER_ERROR
    ok = bool(unregister_handler())
    if _POINTER_ACQUIRED and _POINTER_DESCRIPTOR is not None:
        try:
            current = getattr(bpy.types.Scene, "reporter_settings", None) if hasattr(bpy.types.Scene, "reporter_settings") else None
            if current is _POINTER_DESCRIPTOR:
                del bpy.types.Scene.reporter_settings
            elif current is not None:
                ok = False
        except Exception:
            ok = False
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try:
            if _class_ready(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            ok = False
    _REGISTERED_CLASSES = []
    _POINTER_DESCRIPTOR = None
    _POINTER_ACQUIRED = False
    if not finalize_runtime_generation():
        ok = False
    if ok:
        _LAST_REGISTER_ERROR = ""
    return bool(ok)
