# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
"""Custom icon loader for File Pipeline.

The PNG files are bundled in the flat ``icons`` directory.  This module resolves
that directory from the installed extension package first, then falls back to
legacy paths.  Preview collections are created lazily and can also be forced at
registration time so Blender redraws the N-panel with custom icons immediately.
"""
from __future__ import annotations

import os as _os
from pathlib import Path as _Path

import bpy

_PREVIEWS = None
_PREVIEW_COLLECTION = None
_LOADED_ICON_DIR = ''
_LOADED_SIGNATURE: tuple[tuple[str, int, int], ...] = ()
_DRIVER_NAMESPACE_KEY = 'smart_file_suite.file_pipeline_icons.preview_collection'


_ICON_FILES = {
    'hub': 'sfsmart_hub.png',
    'preflight': 'sfsmart_preflight.png',
    'resolve': 'sfsmart_resolve.png',
    'handoff': 'sfsmart_handoff.png',
    'inventory': 'sfsmart_inventory.png',
    'collect': 'sfsmart_collect.png',
    'verify': 'sfsmart_verify.png',
    'repath_preview': 'sfsmart_repath_preview.png',
    'repath_apply': 'sfsmart_repath_apply.png',
    'relative': 'sfsmart_relative.png',
    'reload': 'sfsmart_reload.png',
    'localize': 'sfsmart_localize.png',
    'override': 'sfsmart_override.png',
    'proxy': 'sfsmart_proxy.png',
    'restore_display': 'sfsmart_restore_display.png',
    'delta_capture': 'sfsmart_delta_capture.png',
    'delta_compare': 'sfsmart_delta_compare.png',
    'delta_restore': 'sfsmart_delta_restore.png',
    'shot': 'sfsmart_shot.png',
    'camera_queue': 'sfsmart_camera_queue.png',
    'catalog': 'sfsmart_catalog.png',
    'duplicate_audit': 'sfsmart_duplicate_audit.png',
    'usd': 'sfsmart_usd.png',
    'version_plan': 'sfsmart_version_plan.png',
    'apply_version': 'sfsmart_apply_version.png',
    'cache': 'sfsmart_cache.png',
    'texture_swap': 'sfsmart_texture_swap.png',
    'naming': 'sfsmart_naming.png',
    'material_rules': 'sfsmart_material_rules.png',
    'checkout': 'sfsmart_checkout.png',
    'checkin': 'sfsmart_checkin.png',
    'engine': 'sfsmart_engine.png',
    'export_hierarchy': 'sfsmart_export_hierarchy.png',
    'quality_audit': 'sfsmart_quality_audit.png',
    'dependency_graph': 'sfsmart_dependency_graph.png',
    'publish_container': 'sfsmart_publish_container.png',
    'super_manifest': 'sfsmart_super_manifest.png',
    'edit_library': 'sfsmart_edit_library.png',
    'report': 'sfsmart_report.png',
    'settings': 'sfsmart_settings.png',
    'reference_board': 'sfsmart_reference_board_icon.png',
}


def _get_previews():
    global _PREVIEWS
    if _PREVIEWS is not None:
        return _PREVIEWS
    try:
        import bpy.utils.previews as previews_mod
        _PREVIEWS = previews_mod
        return previews_mod
    except Exception:
        pass
    try:
        previews_mod = getattr(getattr(bpy, 'utils', None), 'previews', None)
        if previews_mod is not None:
            _PREVIEWS = previews_mod
            return previews_mod
    except Exception:
        pass
    return None


def _package_dir() -> _Path:
    return _Path(__file__).resolve().parent


def _extension_path(package_id: str, subpath: str) -> _Path | None:
    try:
        func = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
        if not callable(func):
            return None
        try:
            value = func(package_id, path=subpath, create=False)
        except TypeError:
            value = func(package_id, path=subpath)
        return _Path(value).resolve() if value else None
    except Exception:
        return None


def _root_package_id() -> str:
    try:
        root = str(__package__ or '').split('.', 1)[0].strip()
        if root:
            return root
    except Exception:
        pass
    return 'smart_file_suite'


def _icon_dir_candidates() -> tuple[_Path, ...]:
    base = _package_dir()
    candidates: list[_Path] = [
        base / 'icons',
    ]
    for package_id in ('smart_file_suite', 'Smart_File_Suite', _root_package_id()):
        ext = _extension_path(package_id, 'icons')
        if ext is not None:
            candidates.append(ext)
    unique: list[_Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key not in seen:
            seen.add(key)
            unique.append(candidate)
    return tuple(unique)


def _has_icon_files(folder: _Path) -> bool:
    try:
        return folder.is_dir() and any((folder / name).is_file() for name in set(_ICON_FILES.values()))
    except Exception:
        return False


def _resolve_icon_dir() -> _Path:
    for candidate in _icon_dir_candidates():
        if _has_icon_files(candidate):
            return candidate
    return _icon_dir_candidates()[0]


def _icon_signature(icon_dir: _Path) -> tuple[tuple[str, int, int], ...]:
    signature = []
    for key, filename in sorted(_ICON_FILES.items()):
        path = icon_dir / filename
        try:
            st = path.stat()
            signature.append((key, int(st.st_mtime_ns), int(st.st_size)))
        except Exception:
            signature.append((key, 0, 0))
    return tuple(signature)


def _preview_contains(pcoll, key: str) -> bool:
    try:
        return key in pcoll
    except Exception:
        try:
            return pcoll.get(key) is not None
        except Exception:
            return False


def _preview_item(pcoll, key: str):
    try:
        return pcoll[key]
    except Exception:
        try:
            return pcoll.get(key)
        except Exception:
            return None


def _expected_loaded_keys(icon_dir: _Path) -> set[str]:
    keys = set()
    for key, filename in _ICON_FILES.items():
        try:
            if (icon_dir / filename).is_file():
                keys.add(key)
        except Exception:
            pass
    return keys


def _collection_has_expected_keys(pcoll, icon_dir: _Path) -> bool:
    for key in _expected_loaded_keys(icon_dir):
        if not _preview_contains(pcoll, key):
            return False
    return True


def _driver_namespace_collection():
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if ns is None:
            return None
        return ns.get(_DRIVER_NAMESPACE_KEY)
    except Exception:
        return None


def _store_driver_namespace_collection(pcoll) -> None:
    try:
        ns = getattr(bpy.app, 'driver_namespace', None)
        if ns is not None:
            ns[_DRIVER_NAMESPACE_KEY] = pcoll
    except Exception:
        pass


def _load_missing_icons_into_collection(pcoll, icon_dir: _Path) -> bool:
    changed = False
    for key, filename in _ICON_FILES.items():
        path = icon_dir / filename
        if not path.is_file():
            continue
        if _preview_contains(pcoll, key):
            continue
        try:
            pcoll.load(key, str(path), 'IMAGE')
            changed = True
        except Exception:
            pass
    return changed


def load_icons(force: bool = False):
    """Create or return the persistent File Pipeline preview collection.

    The collection is intentionally stable while Blender is running. UI widgets
    can keep C-side references to custom icon IDs across panel redraws and mode
    transitions; removing and recreating the preview collection inside draw-time
    lookup paths can leave those widgets with stale pointers.
    """
    global _PREVIEW_COLLECTION, _LOADED_ICON_DIR, _LOADED_SIGNATURE
    icon_dir = _resolve_icon_dir()
    signature = _icon_signature(icon_dir)

    pcoll = _PREVIEW_COLLECTION or _driver_namespace_collection()
    if pcoll is not None:
        _PREVIEW_COLLECTION = pcoll
        _store_driver_namespace_collection(pcoll)
        _load_missing_icons_into_collection(pcoll, icon_dir)
        _LOADED_ICON_DIR = str(icon_dir)
        _LOADED_SIGNATURE = signature
        try:
            from . import preview_cleanup as _sf_preview_cleanup
            _sf_preview_cleanup.register_atexit()
        except Exception:
            pass
        return pcoll

    previews = _get_previews()
    if previews is None:
        return None

    try:
        pcoll = previews.new()
    except Exception:
        return None

    _load_missing_icons_into_collection(pcoll, icon_dir)
    _PREVIEW_COLLECTION = pcoll
    _LOADED_ICON_DIR = str(icon_dir)
    _LOADED_SIGNATURE = signature
    _store_driver_namespace_collection(pcoll)
    try:
        from . import preview_cleanup as _sf_preview_cleanup
        _sf_preview_cleanup.register_atexit()
    except Exception:
        pass
    return _PREVIEW_COLLECTION


def icon_path(name: str = '') -> str:
    key = str(name or '').strip()
    filename = _ICON_FILES.get(key, '')
    icon_dir = _resolve_icon_dir()
    return str(icon_dir / filename) if filename else str(icon_dir)



def icon_id(name: str, fallback: int = 0) -> int:
    """Read an icon prepared at registration; never load files from UI draw."""
    key = str(name or '').strip()
    if not key:
        return int(fallback or 0)
    pcoll = _PREVIEW_COLLECTION or _driver_namespace_collection()
    if pcoll is None:
        return int(fallback or 0)
    try:
        if not _preview_contains(pcoll, key):
            return int(fallback or 0)
        icon = _preview_item(pcoll, key)
        return int(getattr(icon, 'icon_id', 0) or fallback or 0)
    except Exception:
        return int(fallback or 0)

def missing_icon_files() -> list[str]:
    icon_dir = _resolve_icon_dir()
    missing = []
    for key, filename in sorted(_ICON_FILES.items()):
        try:
            if not (icon_dir / filename).is_file():
                missing.append(f'{key}:{filename}')
        except Exception:
            missing.append(f'{key}:{filename}')
    return missing



def unload_icons() -> None:
    global _PREVIEW_COLLECTION, _LOADED_ICON_DIR, _LOADED_SIGNATURE
    _PREVIEW_COLLECTION = None
    _LOADED_ICON_DIR = ''
    _LOADED_SIGNATURE = ()

