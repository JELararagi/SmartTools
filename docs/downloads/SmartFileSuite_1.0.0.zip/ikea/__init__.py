# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import logging
import os
import pathlib
import typing as t

import bpy
import bpy.utils.previews  # type: ignore

from ..storage_paths import user_default_dir

from .ikea_lib import IkeaApiWrapper, IkeaException
from ..ui_language_runtime import ui_text as _ui_text
from ..ui_language_runtime import error_text as _sf_error_text

bl_info = {
    'name': 'IKEA Browser',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'Smart File > Integrated Tools > IKEA Browser',
    'description': 'Browse IKEA products, preview thumbnails, and import supported models into the current scene',
    'category': 'Import-Export',
}

log = logging.getLogger(__name__)
_thumbs = None
_THUMBS_KEY = 'smart_file_suite.ikea.thumbnail_preview_collection'
ikea = IkeaApiWrapper('ie', 'en')
search_results = []
_last_itemNo = None
_last_pip = None


def _ensure_previews():
    global _thumbs
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if _thumbs is None and ns is not None:
            _thumbs = ns.get(_THUMBS_KEY)
        if _thumbs is None:
            _thumbs = bpy.utils.previews.new()
            if ns is not None:
                ns[_THUMBS_KEY] = _thumbs
        if _thumbs is not None:
            try:
                from .. import preview_cleanup
                preview_cleanup.register_atexit()
            except Exception:
                pass
        return _thumbs
    except Exception:
        return None


def _clear_previews() -> None:
    global _thumbs
    # Keep thumbnail preview collections alive for the session. They may still be
    # referenced by queued UI events after an integrated panel is unregistered.
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        _thumbs = ns.get(_THUMBS_KEY) if ns is not None else _thumbs
    except Exception:
        pass


def _cache_dir() -> pathlib.Path:
    try:
        return pathlib.Path(user_default_dir('ikea_cache', create=True))
    except Exception:
        return (pathlib.Path(os.environ.get('APPDATA', str(pathlib.Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / '5.1' / 'config' / 'Smart_File_Suite' / 'ikea_cache') if os.name == 'nt' else (pathlib.Path(os.environ.get('XDG_CONFIG_HOME', str(pathlib.Path.home() / '.config'))) / 'blender' / '5.1' / 'config' / 'Smart_File_Suite' / 'ikea_cache')


def _wm_proxy(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is not None:
        proxy = getattr(wm, 'ikea_settings_proxy', None)
        if proxy is not None:
            return proxy
    return None


class _IkeaPrefsFallback:
    country = 'ie'
    language = 'en'
    debug = False


_FALLBACK = _IkeaPrefsFallback()


def get_ikea_preferences(context=None):
    ctx = context or getattr(bpy, 'context', None)
    proxy = _wm_proxy(context=ctx)
    if proxy is not None:
        return proxy
    return _FALLBACK

def get_integrated_preferences_proxy(context=None, pref_cls=None, record=None):
    return get_ikea_preferences(context=context)


def _init(self=None, context=None):
    global ikea
    prefs = get_ikea_preferences(context=context)
    addon_dir = _cache_dir()
    try:
        addon_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    ikea = IkeaApiWrapper(str(getattr(prefs, 'country', 'ie') or 'ie'), str(getattr(prefs, 'language', 'en') or 'en'))
    ikea.cache_dir = addon_dir

    logging.basicConfig(
        level=logging.DEBUG if bool(getattr(prefs, 'debug', False)) else logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s %(message)s',
    )
    log.info('Initialized IKEA Browser')


def _get_thumbnail_icon(itemNo: str, url: str) -> int:
    thumbs = _ensure_previews()
    if thumbs is None:
        return 0
    if itemNo not in thumbs:
        if not bpy.app.online_access:
            raise IkeaException("Can't load thumbnail without internet access")
        filename = ikea.get_thumbnail(itemNo, url)
        ip = thumbs.load(itemNo, filename, 'IMAGE')
        if ip.image_size[0] == 0 or ip.image_size[1] == 0:
            log.warning('Thumbnail %s is empty', itemNo)
    return thumbs[itemNo].icon_id


def _cached_thumbnail_icon(itemNo: str) -> int:
    """Read a prepared preview without allocating or downloading in draw."""
    try:
        thumbs = _thumbs
        if thumbs is None:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            thumbs = ns.get(_THUMBS_KEY) if ns is not None else None
        if thumbs is not None and itemNo in thumbs:
            return int(thumbs[itemNo].icon_id)
    except Exception:
        pass
    return 0


class IkeaBrowserPreferencesProxy(bpy.types.PropertyGroup):
    country: bpy.props.StringProperty(
        name='Country',
        description='Two-letter IKEA market code used for product search and model lookup. Example: ie, us, jp. Change this if you want results from a different regional catalog.',
        default='ie',
        update=_init,
    )
    language: bpy.props.StringProperty(
        name='Language',
        description='Two-letter language code used when requesting IKEA product names and details. Example: en, ja, de. Use a language supported by the selected IKEA region.',
        default='en',
        update=_init,
    )
    debug: bpy.props.BoolProperty(
        name='Debug Logging',
        description='Write more detailed log output to help diagnose network, cache, or import issues while browsing IKEA products.',
        default=False,
        update=_init,
    )


class SFS_PG_ikea_ikea_browser_preferences(bpy.types.PropertyGroup):
    bl_label = 'IKEA Browser Preferences'
    bl_idname = __package__

    country: bpy.props.StringProperty(name='Country', default='ie', update=_init)  # type: ignore
    language: bpy.props.StringProperty(name='Language', default='en', update=_init)  # type: ignore
    debug: bpy.props.BoolProperty(name='Debug Logging', default=False, update=_init)  # type: ignore

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'country')
        layout.prop(self, 'language')
        layout.prop(self, 'debug')


class SFS_OT_ikea_import_product(bpy.types.Operator):
    bl_idname = 'ikea.sfs_ikea_import_product'
    bl_label = 'Import Product'

    itemName: bpy.props.StringProperty()  # type: ignore
    itemNo: bpy.props.StringProperty()  # type: ignore

    bl_options = {'UNDO'}
    def execute(self, context) -> t.Set[str]:
        if not bpy.app.online_access:
            self.report({'ERROR'}, 'IKEA Browser requires online access')
            return {'CANCELLED'}

        try:
            try:
                bpy.ops.import_scene.gltf(filepath=ikea.get_model(self.itemNo))
            except AttributeError:
                self.report({'ERROR'}, 'Blender is missing the glTF import add-on. Enable it in Preferences first.')
                return {'CANCELLED'}
            except RuntimeError as e:
                if 'libextern_draco' in str(e):
                    self.report({'ERROR'}, 'libextern_draco error. Update Blender to a newer release and try again.\n\n' + str(e))
                    return {'CANCELLED'}
                raise

            for obj in bpy.context.selected_objects:
                assert isinstance(obj, bpy.types.Object)
                obj['ikeaItemNo'] = self.itemNo
                obj['ikeaItemName'] = self.itemName
                obj.name = self.itemName + '_' + ikea.format_item_no(obj['ikeaItemNo'])
                if not obj.parent:
                    obj.location = bpy.context.scene.cursor.location
        except IkeaException as e:
            self.report({'ERROR'}, _sf_error_text(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class SFS_OT_ikea_search_products(bpy.types.Operator):
    bl_idname = 'ikea.sfs_ikea_search_products'
    bl_label = 'Search Products'
    bl_description = 'Search IKEA and prepare product thumbnails'

    def execute(self, context) -> t.Set[str]:
        global search_results
        if not bpy.app.online_access:
            self.report({'ERROR'}, 'IKEA Browser requires online access')
            return {'CANCELLED'}
        query = str(getattr(context.window_manager, 'ikea_search', '') or '').strip()
        if not query:
            search_results = []
            return {'FINISHED'}
        try:
            search_results = list(ikea.search(query) or [])
            for result in search_results:
                try:
                    _get_thumbnail_icon(str(result.get('itemNo') or ''), str(result.get('mainImageUrl') or ''))
                except Exception as exc:
                    log.warning('Could not prepare IKEA thumbnail: %s', exc)
        except IkeaException as exc:
            search_results = []
            self.report({'ERROR'}, _sf_error_text(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class SFS_OT_ikea_refresh_product(bpy.types.Operator):
    bl_idname = 'ikea.sfs_ikea_refresh_product'
    bl_label = 'Refresh Product Details'
    bl_description = 'Download the selected IKEA product details and thumbnail'

    itemNo: bpy.props.StringProperty()  # type: ignore

    def execute(self, context) -> t.Set[str]:
        global _last_pip, _last_itemNo
        if not bpy.app.online_access:
            self.report({'ERROR'}, 'IKEA Browser requires online access')
            return {'CANCELLED'}
        item_no = str(self.itemNo or '').strip()
        if not item_no:
            return {'CANCELLED'}
        try:
            pip = ikea.get_pip(item_no)
            _last_itemNo = item_no
            _last_pip = pip
            if pip:
                _get_thumbnail_icon(item_no, str(pip.get('mainImage', {}).get('url') or ''))
        except IkeaException as exc:
            self.report({'ERROR'}, _sf_error_text(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class SFS_PT_ikea_ikea_browser(bpy.types.Panel):
    bl_label = 'IKEA Browser'
    bl_idname = 'SFS_PT_ikea_ikea_browser'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart File'
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_options = set()

    def draw(self, context) -> None:
        if not bpy.app.online_access:
            self.layout.label(text='Blender is set to offline mode')
            self.layout.label(text='To use IKEA Browser, enable online access:')
            self.layout.operator('screen.userpref_show', text='Open Preferences').section = 'SYSTEM'
            return

        layout = self.layout
        prefs = get_ikea_preferences(context)
        layout.label(text=_ui_text(f"Region: {str(getattr(prefs, 'country', 'ie')).upper()} - Language: {str(getattr(prefs, 'language', 'en')).upper()}", f"地域：{str(getattr(prefs, 'country', 'ie')).upper()}／言語：{str(getattr(prefs, 'language', 'en')).upper()}"))
        search_row = layout.row(align=True)
        search_row.prop(context.window_manager, 'ikea_search', text='', icon='VIEWZOOM')
        search_row.operator(SFS_OT_ikea_search_products.bl_idname, text='Search', icon='VIEWZOOM')

        if not search_results and context.window_manager.ikea_search:
            layout.label(text='Press Search to update results')
            return

        grid = layout.grid_flow(even_columns=True)
        for result in search_results:
            log.debug('Displaying product: %s', result)
            box = grid.box()
            box.label(text=result['mainImageAlt'])
            icon = _cached_thumbnail_icon(result['itemNo'])
            if icon:
                box.template_icon(icon_value=icon, scale=10)
            else:
                box.label(text='Thumbnail not loaded', icon='IMAGE_DATA')
            btn = box.operator(SFS_OT_ikea_import_product.bl_idname, text='Import Product')
            btn.itemNo = result['itemNo']
            btn.itemName = result['name']


class SFS_PT_ikea_ikea_product(bpy.types.Panel):
    bl_label = 'IKEA Product'
    bl_idname = 'SFS_PT_ikea_ikea_product'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart File'
    bl_parent_id = 'SFS_PT_ikea_ikea_browser'
    bl_options = set()

    @classmethod
    def poll(self, context):
        return context.object and context.object.get('ikeaItemNo')

    def draw(self, context) -> None:
        global _last_pip, _last_itemNo

        layout = self.layout
        obj = getattr(context, 'object', None)
        itemNo = obj.get('ikeaItemNo') if obj is not None else None
        if not itemNo:
            layout.label(text='No IKEA product metadata on the active object')
            return

        row = layout.row()
        row.label(text='Item No')
        row.label(text=ikea.format_item_no(itemNo))

        if not bpy.app.online_access:
            layout.label(text='Enable online access to see more details')
            return

        pip = _last_pip if itemNo == _last_itemNo else None
        refresh = layout.operator(SFS_OT_ikea_refresh_product.bl_idname, text='Refresh Product', icon='FILE_REFRESH')
        refresh.itemNo = str(itemNo)

        if pip:
            icon = _cached_thumbnail_icon(itemNo)
            if icon:
                layout.template_icon(icon_value=icon, scale=10)

            grid = layout.grid_flow(row_major=True, even_rows=False, columns=2)
            grid.label(text='Name')
            grid.label(text=pip['name'], translate=False)
            grid.label(text='Price')
            grid.label(text=pip['price'])
            grid.label(text='Style')
            grid.label(text=pip['styleGroup'])
            grid.label(text='Type')
            grid.label(text=pip['typeName'])

            layout.operator('wm.url_open', text='Open Website').url = pip['pipUrl']
        else:
            layout.label(text='Product info missing')


def _update_search(self, context) -> None:
    global search_results
    # Text editing is not an implicit network action.  Search is performed only
    # by the explicit operator so N-panel redraw and typing remain idle.
    search_results = []


classes = (
    IkeaBrowserPreferencesProxy,
    SFS_PT_ikea_ikea_browser,
    SFS_PT_ikea_ikea_product,
    SFS_OT_ikea_import_product,
    SFS_OT_ikea_search_products,
    SFS_OT_ikea_refresh_product,
)



def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def register() -> None:
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.ikea_search = bpy.props.StringProperty(
        name='Search',
        default='',
        update=_update_search,
        options={'SKIP_SAVE'},
    )
    bpy.types.WindowManager.ikea_settings_proxy = bpy.props.PointerProperty(type=IkeaBrowserPreferencesProxy)
    _apply_suite_settings_after_pointer_registration(getattr(bpy, 'context', None))
    _init(None, None)


def unregister() -> None:
    global search_results, _last_itemNo, _last_pip
    if hasattr(bpy.types.WindowManager, 'ikea_settings_proxy'):
        del bpy.types.WindowManager.ikea_settings_proxy
    if hasattr(bpy.types.WindowManager, 'ikea_search'):
        del bpy.types.WindowManager.ikea_search
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    search_results = []
    _last_itemNo = None
    _last_pip = None
    _clear_previews()


if __name__ == '__main__':
    register()
