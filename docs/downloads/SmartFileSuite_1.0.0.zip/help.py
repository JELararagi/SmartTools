# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Lazy Smart File help popup body.

This module is intentionally not named ``sf_*.py`` and is never imported by the
normal Smart File startup/bootstrap path.  The N-panel registers only a tiny
operator; the detailed help body below is imported only when the user clicks a
Help button.
"""

from __future__ import annotations

import ast
import importlib
import os
import re
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy
except Exception:  # pragma: no cover - Blender supplies bpy at runtime.
    bpy = None

_JA_RE = re.compile(r"[ぁ-んァ-ン一-龯々ー]")
_SPACE_RE = re.compile(r"\s+")
_PROP_FACTORIES = {
    "StringProperty",
    "BoolProperty",
    "BoolVectorProperty",
    "IntProperty",
    "IntVectorProperty",
    "FloatProperty",
    "FloatVectorProperty",
    "EnumProperty",
    "PointerProperty",
    "CollectionProperty",
}
_OPERATOR_BASE_PROP_IDS = {"has_reports", "layout", "macros", "options", "properties", "is_registered"}
_SKIP_PROP_IDS = {
    "rna_type",
    "bl_idname",
    "bl_label",
    "bl_description",
    "name",
    "description",
    "popup_width",
    "help_key",
    "display_title",
    "addon_alias",
    "operator_id",
    "section",
    "lane",
}

_CATEGORY_META = {
    "HOME": (
        "Smart File Home",
        "Smart File ホーム",
        "Central launcher for selecting a source file, opening frequently used Smart File categories, and jumping to recent or favorite sources.",
        "ソースファイルの選択、Smart File の主要カテゴリ、最近使ったソースやお気に入りソースへの移動をまとめた中央ランチャーです。",
        "Open the Smart File tab, choose a source when needed, then select the category that matches the current task. Use the Help buttons beside each group when you need detailed guidance.",
        "Smart File タブを開き、必要に応じてソースを選択してから、現在の作業に合うカテゴリを選びます。詳しい説明が必要な場合は各グループ横のヘルプを開いてください。",
    ),
    "LINK": (
        "Link",
        "リンク",
        "Tools for linked libraries, relinking, dependency checks, library update checks, and returning from linked-edit workflows.",
        "リンクライブラリ、再リンク、依存関係確認、ライブラリ更新確認、リンク編集からの復帰を扱う機能群です。",
        "Use this category before changing linked-library paths, when dependencies are missing, or when linked data must be refreshed from disk.",
        "リンクライブラリのパス変更、依存関係の不足確認、リンクデータの再読込が必要なときに使用します。",
    ),
    "APPEND": (
        "Append",
        "アペンド",
        "Tools for bringing editable local data from a selected .blend source into the current scene.",
        "選択した .blend ソースから編集可能なローカルデータを現在のシーンへ取り込む機能群です。",
        "Select a source .blend first, check the content, then append the required objects, collections, materials, or related data.",
        "先にソース .blend を選択し、内容を確認してから、必要なオブジェクト、コレクション、マテリアルなどをアペンドします。",
    ),
    "IMPORT": (
        "Import",
        "インポート",
        "Tools for importing or loading external formats, containers, state data, queues, and migrated importer add-ons.",
        "外部形式、コンテナ、状態データ、キュー、移植済みインポーターを読み込むための機能群です。",
        "Open the matching importer or loading helper, review its options in the operator dialog, and run it only after the source and context are correct.",
        "目的のインポーターまたは読込補助を開き、オペレーターダイアログ内の設定を確認してから、ソースとコンテキストが正しい状態で実行します。",
    ),
    "EXPORT": (
        "Export",
        "エキスポート",
        "Tools for publishing, package creation, bundle output, manifest export, and migrated exporter add-ons.",
        "公開、パッケージ作成、バンドル出力、マニフェスト書き出し、移植済みエクスポーターを扱う機能群です。",
        "Check the output path and readiness information, run audits or previews when available, then execute the required export or publish command.",
        "出力先と準備状態を確認し、可能な場合は監査やプレビューを行ってから、必要な書き出しまたは公開コマンドを実行します。",
    ),
    "PREVIEW": (
        "Preview",
        "プレビュー",
        "Tools for validation, audits, thumbnails, representations, release checks, and review boards before final changes.",
        "最終変更前の検証、監査、サムネイル、表現切り替え、リリース確認、レビューボードを扱う機能群です。",
        "Use this category before committing changes, packaging data, or handing off a scene. Review warnings first, then run the corrective action only when appropriate.",
        "変更確定、パッケージ化、シーン受け渡しの前に使用します。警告を確認してから、必要な場合だけ修正操作を実行します。",
    ),
    "HISTORY": (
        "History & Restore",
        "履歴/復元",
        "Safety tools for manual restore points, rolling autosave, selected restore, saved plans, rollback, and recovery helpers.",
        "手動復元ポイント、世代管理自動保存、選択復元、保存済み計画、ロールバック、復旧補助を扱う安全系機能群です。",
        "Create a restore point before risky work, use autosave when continuous backup is needed, and restore only after confirming the selected history item.",
        "危険な作業前に復元ポイントを作成し、継続バックアップが必要な場合は自動保存を使い、復元時は選択した履歴項目を確認してから実行します。",
    ),
    "OTHER": (
        "Other",
        "その他",
        "Supporting tools for search, guidance, monitoring, migrated settings, metadata, maintenance, and uncategorized utilities.",
        "検索、案内、監視、移植済み設定、メタデータ、メンテナンス、未分類ユーティリティを扱う補助機能群です。",
        "Use this category when the task does not clearly belong to link, append, import, export, preview, or history workflows.",
        "リンク、アペンド、インポート、エキスポート、プレビュー、履歴のいずれにも明確に当てはまらない作業で使用します。",
    ),
}

_ALWAYS_ON_SETTINGS = [
    ("enable_npanel_settings_keeper", "N-panel State Save", "Nパネル状態保存", "When enabled, every persistent Smart File N-panel setting is saved after its change event and restored after restart or scene change. Turning it off records OFF once, removes the persistence resources, and blocks every later settings writer until it is enabled again.", '有効時はSmart Fileの永続Nパネル設定を変更イベント後に保存し、再起動やシーン変更後に復元します。OFFへの変更だけを最後に1回保存し、その後は再びONにするまで全設定の書き込みを停止します。'),
    ("enable_compatibility_guards", "Compatibility Guards", "互換ガード", "Keeps guards active for known external Smart toolset startup, missing-operator, handler, and RNA-drawing issues.", '外部Smart ツールで確認済みの起動、未登録オペレーター、ハンドラー、RNA描画問題へのガードを有効にします。'),
    ("enable_automatic_proxy_cleanup", "Automatic Proxy Cleanup", "自動プロキシ清掃", "Checks and removes broken Smart File proxy metadata from owned callbacks and a maintenance timer. Disable it to remove those callbacks and the timer completely.", "Smart Fileが所有するコールバックと保守タイマーで破損したプロキシ情報を確認・清掃します。無効時はコールバックとタイマーを完全に解除します。"),
    ("enable_restore_snapshots", "Optional Timed Restore Points", "任意の定期復元ポイント", "Allows optional timed restore-point creation. Manual Restore Point remains the primary rollback workflow.", "任意の定期復元ポイント作成を許可します。手動復元ポイントを主な戻り先作成ワークフローとして使います。"),
    ("enable_autosave", "Rolling Autosave", "世代管理自動保存", "Creates rolling autosave backups in the integrated history system.", "統合履歴システムで世代管理自動保存バックアップを作成します。"),
    ("autosave_skip_unchanged", "Skip Unchanged Autosaves", "未変更の自動保存をスキップ", "Skips writing a new autosave when no operation or scene update happened since the previous autosave.", "前回の自動保存以降に操作やシーン更新がない場合、新しい自動保存を書き込まないようにします。"),
    ("rm_auto_check_on_load", "Reference Load Check", "参照読込時チェック", "Checks linked libraries when a Blender file is loaded.", "Blenderファイル読込時にリンクライブラリを確認します。"),
    ("rm_auto_periodic", "Reference Periodic Check", "参照定期チェック", "Checks linked references periodically while Blender remains open.", "Blender起動中にリンク参照を定期確認します。"),
    ("rm_auto_popup_on_updates", "Reference Update Popup", "参照更新ポップアップ", "Shows visible notices when Reference Manager detects missing, changed, or newer linked libraries.", "Reference Managerが欠落、変更、新しいリンクライブラリを検出したときに通知します。"),
    ("auto_refresh_on_file_load", "Texture File-load Refresh", "テクスチャ読込時更新", "Refreshes Texture Manager data after a Blender file is loaded.", "Blenderファイル読込後にTexture Managerの情報を更新します。"),
    ("labels_enabled", "Viewport Labels", "ビューポートラベル", "Draws Object Reporter labels in the 3D View overlay. With the default filters, only selected objects that have a custom property get a label; change this with Selected Only and Tagged Only in Object Reporter.", "3Dビュー上にObject Reporterのラベルを描画します。既定の絞り込みでは、選択中でカスタムプロパティを持つオブジェクトにだけラベルが出ます。変えるにはオブジェクトレポーターの「選択中のみ」「タグ付きのみ」を切り替えます。"),
]

_SETTING_CACHE: dict[str, list[dict[str, str]]] = {}
_ALIAS_CACHE: dict[str, dict[str, Any]] = {}
_OPERATOR_PROP_CACHE: dict[str, list[dict[str, str]]] = {}


def _is_ja(context=None) -> bool:
    try:
        if bpy is None:
            return False
        ctx = context or getattr(bpy, "context", None)
        view = getattr(getattr(ctx, "preferences", None), "view", None) if ctx is not None else getattr(getattr(bpy, "context", None), "preferences", None).view
        if view is not None and not bool(getattr(view, "use_translate_interface", True)):
            return False
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "")
        if not locale and view is not None:
            locale = str(getattr(view, "language", "") or "")
        return locale.lower().startswith("ja")
    except Exception:
        return False


def _split_bilingual(text: str, context=None) -> str:
    value = str(text or "")
    if " / " not in value or not _JA_RE.search(value):
        return value
    left, right = value.split(" / ", 1)
    if _is_ja(context):
        return right.strip() if _JA_RE.search(right) else value.strip()
    return left.strip()


def _collapse(text: object) -> str:
    return _SPACE_RE.sub(" ", str(text or "").replace("\n", " ")).strip()


def _ui(text: object, context=None) -> str:
    value = _collapse(text)
    if not value:
        return ""
    value = _split_bilingual(value, context=context)
    try:
        from .ui_language_runtime import iface as _iface
        translated = _iface(value)
        if translated:
            value = str(translated)
    except Exception:
        pass
    value = _split_bilingual(value, context=context)
    if _is_ja(context) and value and not _JA_RE.search(value):
        # Use the existing term translator when available.  Proper names such as
        # Smart File can remain in Latin script; ordinary UI phrases are
        # converted so the help popup does not show bilingual text.
        try:
            from .ui_language_runtime import _ENGLISH_WORD_RE, _term_to_japanese
            guessed = _term_to_japanese(value)
            if guessed and not _ENGLISH_WORD_RE.search(str(guessed)):
                value = str(guessed)
        except Exception:
            pass
    elif not _is_ja(context) and _JA_RE.search(value) and " / " in value:
        value = _split_bilingual(value, context=context)
    return _collapse(value)


def _t(en: str, ja: str, context=None) -> str:
    return _ui(ja if _is_ja(context) else en, context=context)


_HELP_POPUP_WIDTH_PX = 820


def _ui_scale(context=None) -> float:
    try:
        prefs = getattr(context, "preferences", None) if context is not None else getattr(getattr(bpy, "context", None), "preferences", None)
        scale = float(getattr(getattr(prefs, "view", None), "ui_scale", 1.0) or 1.0)
        return max(0.5, min(4.0, scale))
    except Exception:
        return 1.0


def _font_size(context=None) -> int:
    # Blender's default UI label size is close to 11 pt.  The exact font can be
    # user-configured, so blf is used for measurement whenever Blender provides it.
    return max(8, int(round(11.0 * _ui_scale(context))))


def _measure_text_px(text: object, *, context=None) -> float:
    value = str(text or "")
    if not value:
        return 0.0
    try:
        import blf  # type: ignore

        font_id = 0
        size = _font_size(context)
        try:
            blf.size(font_id, size)
        except TypeError:
            blf.size(font_id, size, 72)
        width, _height = blf.dimensions(font_id, value)
        return float(width or 0.0)
    except Exception:
        # Fallback for static checks outside Blender.  It is still pixel-width
        # based, not a fixed character-count wrap.
        font_size = float(_font_size(context))
        total = 0.0
        for ch in value:
            code = ord(ch)
            if ch.isspace():
                total += font_size * 0.34
            elif 0x1100 <= code <= 0x11FF or 0x2E80 <= code <= 0xA4CF or 0xAC00 <= code <= 0xD7AF or 0xF900 <= code <= 0xFAFF or 0xFE10 <= code <= 0xFE6F or 0xFF00 <= code <= 0xFFEF:
                total += font_size * 1.02
            elif ch in "ilI.,:;!|[](){}'`":
                total += font_size * 0.38
            elif ch in "mwMW@#%&":
                total += font_size * 0.88
            else:
                total += font_size * 0.58
        return total


def _active_help_popup_width(context=None, popup_width: int | None = None) -> int:
    width = int(popup_width or _HELP_POPUP_WIDTH_PX or 820)
    if width <= 0:
        try:
            width = int(getattr(getattr(context, "region", None), "width", 0) or 820)
        except Exception:
            width = 820
    return max(240, width)


def _available_text_width_px(*, context=None, popup_width: int | None = None, icon: str = "BLANK1") -> float:
    width = float(_active_help_popup_width(context, popup_width))
    scale = _ui_scale(context)
    # Account for the popup margins, box padding, label padding, and optional
    # icon slot.  The remaining value is the drawable text span inside the popup.
    base_padding = 62.0 * scale
    icon_padding = 24.0 * scale if str(icon or "BLANK1") != "BLANK1" else 6.0 * scale
    return max(160.0, width - base_padding - icon_padding)


def _split_token_to_fit(token: str, max_px: float, *, context=None) -> list[str]:
    chunks: list[str] = []
    current = ""
    for ch in str(token or ""):
        candidate = current + ch
        if current and _measure_text_px(candidate, context=context) > max_px:
            chunks.append(current)
            current = ch
        else:
            current = candidate
    if current:
        chunks.append(current)
    return chunks


def _wrap_text_to_popup_width(text: str, max_px: float, *, context=None) -> list[str]:
    value = _collapse(text)
    if not value:
        return []
    if _measure_text_px(value, context=context) <= max_px:
        return [value]

    tokens = re.findall(r"\s+|\S+", value)
    lines: list[str] = []
    current = ""
    for token in tokens:
        token = " " if token.isspace() else token
        if token == " " and not current:
            continue
        candidate = current + token
        if _measure_text_px(candidate.rstrip(), context=context) <= max_px:
            current = candidate
            continue
        if current.strip():
            lines.append(current.rstrip())
            current = ""
        if token == " ":
            continue
        token = token.lstrip()
        if _measure_text_px(token, context=context) <= max_px:
            current = token
            continue
        parts = _split_token_to_fit(token, max_px, context=context)
        if parts:
            lines.extend(parts[:-1])
            current = parts[-1]
    if current.strip():
        lines.append(current.rstrip())
    return lines or [value]


def _draw_wrapped(layout, text: object, *, context=None, icon: str = "BLANK1", popup_width: int | None = None) -> None:
    value = _ui(text, context=context)
    if not value:
        return
    max_px = _available_text_width_px(context=context, popup_width=popup_width, icon=icon)
    first = True
    for line in _wrap_text_to_popup_width(value, max_px, context=context):
        layout.label(text=line, icon=icon if first else "BLANK1")
        first = False


def _draw_block(layout, heading_en: str, heading_ja: str, lines: Iterable[object], *, context=None, icon: str = 'NONE'):
    box = layout.box()
    box.label(text=_t(heading_en, heading_ja, context=context), icon=icon)
    drew = False
    for line in lines:
        text = _ui(line, context=context)
        if not text:
            continue
        _draw_wrapped(box, text, context=context, icon="DOT")
        drew = True
    if not drew:
        _draw_wrapped(box, _t("No additional information is available.", "追加情報はありません。", context=context), context=context)
    return box


def _prop_display(prop: dict[str, str], context=None) -> str:
    name = _ui(prop.get("name") or "", context=context)
    desc = _ui(prop.get("description") or "", context=context)
    default = str(prop.get("default") or "").strip()
    if _is_ja(context):
        default = {"True": "オン", "False": "オフ"}.get(default, default)
        base = f"{name}: {desc}"
        return f"{base}（既定値：{default}）" if default else base
    default = {"True": "On", "False": "Off"}.get(default, default)
    base = f"{name}: {desc}"
    return f"{base} (default: {default})" if default else base


def _draw_settings(layout, settings: Iterable[dict[str, str]], *, context=None):
    box = layout.box()
    box.label(text=_t("3. Settings", "3. 設定項目", context=context), icon="PREFERENCES")
    # A row without a name or description explains nothing; those are internal values.
    settings_list = [
        item for item in settings
        if isinstance(item, dict) and str(item.get("name") or "").strip() and str(item.get("description") or "").strip()
    ]
    if not settings_list:
        _draw_wrapped(box, _t("This group has no separate configurable settings exposed by the current registered UI or static bundled code.", "現在登録されているUIまたは同梱コード上、このグループ専用の個別設定項目はありません。", context=context), context=context)
        return box
    for prop in settings_list:
        _draw_wrapped(box, _prop_display(prop, context=context), context=context, icon="DOT")
    return box


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _package_module():
    package = str(__package__ or "").strip()
    if not package:
        return None
    return importlib.import_module(package)


def _registry_specs() -> list[dict[str, Any]]:
    try:
        package = str(__package__ or "").strip()
        if not package:
            return []
        reg = importlib.import_module(f"{package}.registry")
        build = getattr(reg, "build_specs", None)
        if callable(build):
            return list(build(False) or [])
    except Exception:
        pass
    return []


def _spec_by_alias(alias: str) -> dict[str, Any]:
    alias = str(alias or "").strip()
    if not alias:
        return {}
    if alias in _ALIAS_CACHE:
        return dict(_ALIAS_CACHE[alias])
    for spec in _registry_specs():
        if str(spec.get("alias") or "").strip() == alias:
            _ALIAS_CACHE[alias] = dict(spec)
            return dict(spec)
    return {}


def _literal(node: ast.AST) -> Any:
    try:
        return ast.literal_eval(node)
    except Exception:
        return None


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Call):
        return _call_name(node.func)
    return ""


def _extract_prop_call(value: ast.AST) -> dict[str, str] | None:
    if not isinstance(value, ast.Call):
        return None
    func_name = _call_name(value.func)
    if func_name not in _PROP_FACTORIES:
        return None
    kwargs: dict[str, Any] = {}
    for kw in getattr(value, "keywords", ()) or ():
        if kw.arg:
            kwargs[kw.arg] = _literal(kw.value)
    # Support property definitions that put name and description in positional slots.
    args = list(getattr(value, "args", ()) or ())
    if "name" not in kwargs and args:
        kwargs["name"] = _literal(args[0])
    if "description" not in kwargs and len(args) > 1:
        kwargs["description"] = _literal(args[1])
    default = kwargs.get("default", "")
    if isinstance(default, (list, tuple, dict, set)):
        default = repr(default)
    return {
        "factory": func_name,
        "name": str(kwargs.get("name") or "").strip(),
        "description": str(kwargs.get("description") or "").strip(),
        "default": str(default or "").strip(),
    }


def _class_attrs(node: ast.ClassDef) -> dict[str, str]:
    attrs: dict[str, str] = {}
    for stmt in getattr(node, "body", ()) or ():
        targets = []
        value = None
        if isinstance(stmt, ast.Assign):
            targets = list(stmt.targets or [])
            value = stmt.value
        elif isinstance(stmt, ast.AnnAssign):
            targets = [stmt.target]
            value = stmt.value
        if value is None:
            continue
        for target in targets:
            if isinstance(target, ast.Name) and target.id.startswith("bl_"):
                lit = _literal(value)
                if isinstance(lit, (str, int, float, bool)):
                    attrs[target.id] = str(lit)
    return attrs


def _class_property_entries(node: ast.ClassDef, source: str, *, class_label: str = "") -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    for stmt in getattr(node, "body", ()) or ():
        targets = []
        value = None
        if isinstance(stmt, ast.Assign):
            targets = list(stmt.targets or [])
            value = stmt.value
        elif isinstance(stmt, ast.AnnAssign):
            targets = [stmt.target]
            value = stmt.value if stmt.value is not None else stmt.annotation
        if value is None:
            continue
        prop = _extract_prop_call(value)
        if not prop:
            continue
        for target in targets:
            if not isinstance(target, ast.Name):
                continue
            ident = str(target.id or "").strip()
            if not ident or ident in _SKIP_PROP_IDS or ident.startswith(("_", "bl_")):
                continue
            entry = dict(prop)
            entry["identifier"] = ident
            entry["name"] = entry.get("name") or ident.replace("_", " ").title()
            entry["source"] = f"{class_label or node.name} / {source}"
            entries.append(entry)
    return entries


def _scan_static_properties(paths: Iterable[Path], *, restrict_operator_ids: set[str] | None = None) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    root = _package_root()
    for path in sorted(paths, key=lambda p: p.as_posix().lower()):
        if not path.exists() or "__pycache__" in path.parts:
            continue
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except Exception:
            continue
        try:
            rel = path.relative_to(root).as_posix()
        except Exception:
            rel = path.name
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            attrs = _class_attrs(node)
            class_label = str(attrs.get("bl_label") or node.name).strip()
            bl_idname = str(attrs.get("bl_idname") or "").strip()
            if restrict_operator_ids is not None and bl_idname and bl_idname not in restrict_operator_ids:
                continue
            if restrict_operator_ids is not None and not bl_idname:
                # When looking for operator properties, skip unrelated property groups.
                continue
            for entry in _class_property_entries(node, rel, class_label=class_label):
                key = (entry.get("source", ""), entry.get("identifier", ""), entry.get("description", ""))
                if key in seen:
                    continue
                seen.add(key)
                entries.append(entry)
    return entries


def _operator_rna_class(operator_id: str):
    if bpy is None:
        return None
    op = str(operator_id or "").strip()
    if not op:
        return None
    candidates = [op]
    if "." in op:
        prefix, suffix = op.split(".", 1)
        candidates.append(f"{prefix.upper()}_OT_{suffix}")
    for ident in candidates:
        try:
            found = getattr(bpy.types, ident, None)
            if isinstance(found, type):
                return found
        except Exception:
            pass
    return None

def _rna_properties_for_type(cls, *, source: str = "") -> list[dict[str, str]]:
    if not isinstance(cls, type):
        return []
    try:
        props = getattr(getattr(cls, "bl_rna", None), "properties", None)
    except Exception:
        props = None
    if props is None:
        return []
    entries: list[dict[str, str]] = []
    try:
        iterable = list(props)
    except Exception:
        try:
            iterable = list(props.values())
        except Exception:
            iterable = []
    for prop in iterable:
        try:
            ident = str(getattr(prop, "identifier", "") or "").strip()
        except Exception:
            ident = ""
        if not ident or ident in _SKIP_PROP_IDS or ident.startswith(("_", "bl_")) or ident in _OPERATOR_BASE_PROP_IDS:
            continue
        try:
            if bool(getattr(prop, "is_hidden", False)):
                continue
        except Exception:
            pass
        name = str(getattr(prop, "name", "") or ident.replace("_", " ").title())
        desc = str(getattr(prop, "description", "") or "")
        default = ""
        try:
            default_value = getattr(prop, "default", None)
            if default_value not in (None, ""):
                default = str(default_value)
        except Exception:
            default = ""
        entries.append({"identifier": ident, "name": name, "description": desc, "default": default, "source": source or getattr(cls, "__name__", "")})
    return entries


def _settings_for_operator_ids(operator_ids: Iterable[str]) -> list[dict[str, str]]:
    ids = {str(op or "").strip() for op in operator_ids if str(op or "").strip()}
    cache_key = "operators:" + "|".join(sorted(ids))
    if cache_key in _SETTING_CACHE:
        return list(_SETTING_CACHE[cache_key])
    entries: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    missing: set[str] = set()
    for op_id in sorted(ids):
        cls = _operator_rna_class(op_id)
        if cls is None:
            missing.add(op_id)
            continue
        label = getattr(cls, "bl_label", "") or op_id
        for prop in _rna_properties_for_type(cls, source=str(label)):
            key = (prop.get("source", ""), prop.get("identifier", ""))
            if key not in seen:
                seen.add(key)
                entries.append(prop)
    if missing:
        py_files = list(_package_root().glob("sf_*.py"))
        for prop in _scan_static_properties(py_files, restrict_operator_ids=missing):
            key = (prop.get("source", ""), prop.get("identifier", ""))
            if key not in seen:
                seen.add(key)
                entries.append(prop)
    _SETTING_CACHE[cache_key] = list(entries)
    return entries


def _prefs_settings(context=None) -> list[dict[str, str]]:
    try:
        pkg = _package_module()
        pref_fn = getattr(pkg, "_addon_prefs", None)
        prefs = pref_fn(context) if callable(pref_fn) else None
        if prefs is not None:
            return _rna_properties_for_type(type(prefs), source=_t("Smart File N-panel Settings", "Smart File Nパネル設定", context=context))
    except Exception:
        pass
    return []

def _settings_from_owner_type(owner_type, identifiers: Iterable[str], *, source: str = "") -> list[dict[str, str]]:
    ids = {str(item or '').strip() for item in identifiers if str(item or '').strip()}
    if not ids or not isinstance(owner_type, type):
        return []
    result: list[dict[str, str]] = []
    for entry in _rna_properties_for_type(owner_type, source=source):
        if str(entry.get("identifier") or '').strip() in ids:
            result.append(entry)
    return result


def _window_manager_settings(context, identifiers: Iterable[str], *, source: str = "") -> list[dict[str, str]]:
    owner = getattr(getattr(bpy, 'types', None), 'WindowManager', None) if bpy is not None else None
    return _settings_from_owner_type(owner, identifiers, source=source or _t("File Pipeline Settings", "ファイル パイプライン 設定", context=context))


def _history_pref_settings(context, identifiers: Iterable[str], *, source: str = "") -> list[dict[str, str]]:
    try:
        package = str(__package__ or "").strip()
        if not package:
            raise ImportError("Smart File package namespace is unavailable")
        mod = importlib.import_module(f"{package}.history_auto_save.properties")
        owner = getattr(mod, 'SFS_PG_history_history_preferences', None)
    except Exception:
        owner = None
    return _settings_from_owner_type(owner, identifiers, source=source or _t("History & Restore Settings", "履歴/復元設定", context=context))


def _history_scene_settings(context, identifiers: Iterable[str], *, source: str = "") -> list[dict[str, str]]:
    try:
        package = str(__package__ or "").strip()
        if not package:
            raise ImportError("Smart File package namespace is unavailable")
        mod = importlib.import_module(f"{package}.history_auto_save.properties")
        owner = getattr(mod, 'UHM_SceneSettings', None)
    except Exception:
        owner = None
    return _settings_from_owner_type(owner, identifiers, source=source or _t("History Browser State", "履歴ブラウザー状態", context=context))


def _merge_settings(*groups: Iterable[dict[str, str]]) -> list[dict[str, str]]:
    merged: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for group in groups:
        for entry in list(group or []):
            if not isinstance(entry, dict):
                continue
            key = (str(entry.get('source') or ''), str(entry.get('identifier') or ''), str(entry.get('name') or ''))
            if key in seen:
                continue
            seen.add(key)
            merged.append(entry)
    return merged



def _static_settings_for_alias(alias: str) -> list[dict[str, str]]:
    alias = str(alias or "").strip()
    if not alias:
        return []
    cache_key = f"alias:{alias}"
    if cache_key in _SETTING_CACHE:
        return list(_SETTING_CACHE[cache_key])
    spec = _spec_by_alias(alias)
    package_dir = Path(str(spec.get("package_dir") or _package_root() / alias))
    try:
        py_files = [p for p in package_dir.rglob("*.py") if "__pycache__" not in p.parts]
    except Exception:
        py_files = []
    entries = _scan_static_properties(py_files)
    _SETTING_CACHE[cache_key] = list(entries)
    return list(entries)


def _operator_items_from_sections(sections: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for section in sections or []:
        for item in list(section.get("items") or []):
            if isinstance(item, dict):
                items.append(item)
    return items


def _lane_sections(context, lane: str) -> list[dict[str, Any]]:
    try:
        fn = getattr(_package_module(), "_sf_lane_tool_sections", None)
        if callable(fn):
            return list(fn(context, lane) or [])
    except Exception:
        pass
    return []


def _category_help(context, lane: str) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    lane = str(lane or "OTHER").upper()
    meta = _CATEGORY_META.get(lane, _CATEGORY_META["OTHER"])
    title = _t(meta[0], meta[1], context=context)
    sections = _lane_sections(context, lane)
    items = _operator_items_from_sections(sections)
    tool_lines = []
    for item in items:
        label = _ui(item.get("label") or item.get("operator") or "", context=context)
        desc = _ui(item.get("description") or "", context=context)
        if label and desc:
            tool_lines.append(f"{label}: {desc}")
        elif label:
            tool_lines.append(label)
    overview = [meta[2] if not _is_ja(context) else meta[3]]
    if tool_lines:
        overview.append(_t("Included functions:", "含まれる機能:", context=context))
        overview.extend(tool_lines)
    usage = [meta[4] if not _is_ja(context) else meta[5]]
    usage.append(_t("Run commands from the N-panel buttons. Commands that require more options open Blender operator dialogs. N-panel settings are saved to the Blender config/Smart_File_Suite/Smart_File_Suite.json and restored on startup and file changes.", "Nパネルのボタンからコマンドを実行します。追加オプションが必要なコマンドは Blender 標準のオペレーターダイアログを開きます。Nパネル設定は Blender config/Smart_File_Suite/Smart_File_Suite.json へ保存され、起動時やファイル切り替え時に復元されます。", context=context))
    operator_ids = [str(item.get("operator") or "") for item in items]
    settings = _settings_for_operator_ids(operator_ids)
    if lane in {"OTHER", "HOME"}:
        settings.extend(_prefs_settings(context))
    return title, overview, usage, settings


def _always_on_help(context) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    title = _t("Always-on Toggles", "常時機能切り替え", context=context)
    overview = [
        _t(
            "This group collects every handler, timer, watcher, file-load hook, and viewport overlay that can keep running without direct button execution.",
            "このグループは、直接ボタンを押していない間も動き続けるハンドラー、タイマー、監視、ファイル読込フック、ビューポートオーバーレイをまとめています。",
            context=context,
        )
    ]
    usage = [
        _t(
            "Enable only the features that must run continuously. Disabled items must remain fully inactive until their tool is opened or the toggle is enabled again.",
            "常時動かす必要がある機能だけを有効にしてください。無効の項目は、ツールを開くか再度有効化するまで完全に非アクティブのままにします。",
            context=context,
        ),
        _t("While N-panel State Save is on, bundled tools whose switch was saved as enabled are loaded after startup and after opening a file. Other bundled tools stay unloaded.", "「Nパネル状態保存」が有効なら、有効で保存された同梱の機能は、起動とファイルを開いた後に読み込まれて動き始めます。それ以外の同梱の機能は読み込まれません。", context=context),
    ]
    settings = []
    for ident, en, ja, desc_en, desc_ja in _ALWAYS_ON_SETTINGS:
        settings.append({"identifier": ident, "name": _t(en, ja, context=context), "description": _t(desc_en, desc_ja, context=context), "source": title})
    return title, overview, usage, settings


def _quick_sources_help(context) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    title = _t("Quick Sources", "クイックソース", context=context)
    overview = [_t("Quick access to recent source files, favorite source files, and the current pinned source used by append and asset reading workflows.", "アペンドやアセット読込ワークフローで使う最近のソース、お気に入りソース、現在の固定ソースへ素早くアクセスします。", context=context)]
    usage = [_t("Use Recent or Favorites to switch source files quickly. Use Pin Current after selecting a useful source so it remains available across sessions.", '「最近」 または 「お気に入り」 でソースファイルを素早く切り替えます。便利なソースを選択した後は 「現在のソースをピン留め」 で固定し、次回以降も使えるようにします。', context=context)]
    settings = [
        {"identifier": "sf_filepath", "name": _t("Source File", "ソースファイル", context=context), "description": _t("Current source .blend path used by the Smart File browser and append/import helpers.", "Smart File ブラウザーとアペンド/インポート補助で使う現在のソース .blend パスです。", context=context), "source": title},
        {"identifier": "recent_sources", "name": _t("Recent Sources", "最近のソース", context=context), "description": _t("Saved list of recently used source files.", "最近使用したソースファイルの保存リストです。", context=context), "source": title},
        {"identifier": "favorite_sources", "name": _t("Favorite Sources", "お気に入りソース", context=context), "description": _t("Saved list of pinned source files.", "固定したソースファイルの保存リストです。", context=context), "source": title},
    ]
    return title, overview, usage, settings




def _undo_load_diagnostic_help(context) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    title = _t('Undo Load Diagnostic', 'Undo負荷診断', context=context)
    overview = [
        _t(
            'Blender core owns Global Undo, so a Python add-on cannot directly make the undo engine itself faster. This diagnostic measures push, undo, and redo time and records scene factors that commonly increase snapshot and dependency-graph rebuild cost.',
            'Global UndoはBlender本体が管理しているため、PythonアドオンからUndo本体を直接高速化することはできません。この診断はプッシュ・元に戻す・やり直しの時間を計測し、スナップショット作成や依存グラフ再評価を重くしやすいシーン要因を記録します。',
            context=context,
        ),
        _t(
            'The data-block counts, packed-image size, top mesh vertex counts, and orphan count are scanned only when you press Measure Undo Speed or confirm Purge Orphan Data. Panel redraw never performs those scans.',
            'データブロック数、パック画像サイズ、頂点数上位メッシュ、孤立データ数は、「Undo速度を計測」を押した時または「孤立データを整理」を確定した時だけ走査します。パネルの再描画では走査しません。',
            context=context,
        ),
    ]
    usage = [
        _t(
            'Run Measure Undo Speed to collect timings and snapshot weight factors.',
            '「Undo速度を計測」を実行すると、時間とスナップショット重量要因を集計します。',
            context=context,
        ),
        _t(
            'Keep at least one 3D View open while measuring. Smart File uses that context so the test reaches Blender Global Undo instead of an editor-local undo stack.',
            '計測中は少なくとも1つの3Dビューを開いてください。Smart Fileはそのコンテキストを使い、各エディター固有のUndoではなくBlenderのGlobal Undoを計測します。',
            context=context,
        ),
        _t(
            'For lighter editing, work in Edit Mode when the task fits, split or link very heavy assets into separate files, and use Solid viewport shading while making dense edits.',
            '編集負荷を下げるには、作業内容に適する場合は編集モードを中心に使い、非常に重いアセットは別ファイルへ分割またはリンクし、高密度な編集中はビューポートをソリッド表示にします。',
            context=context,
        ),
        _t(
            'Blender Preferences > Undo Steps changes how many states are retained in memory; it does not make each individual undo operation faster.',
            'Blenderプリファレンスの「元に戻す回数」は、メモリへ保持する状態数を変更する設定であり、1回ごとのUndo処理速度を速くする設定ではありません。',
            context=context,
        ),
        _t(
            'Purge Orphan Data is destructive. Review the confirmation dialog and save the project first when unused data may still be needed.',
            '「孤立データを整理」は破壊的処理です。未使用データが後で必要になる可能性がある場合は、確認ダイアログを確認し、先にプロジェクトを保存してください。',
            context=context,
        ),
    ]
    return title, overview, usage, []

def _integrated_alias_help(context, alias: str) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    spec = _spec_by_alias(alias)
    display = _ui(spec.get("display_name") or alias.replace("_", " ").title(), context=context)
    desc = _ui(spec.get("description") or spec.get("note") or "", context=context)
    static_ui = dict(spec.get("static_ui") or {})
    functions: list[str] = []
    for kind, label_en, label_ja in (
        ("operators", "Operators", "オペレーター"),
        ("menus", "Menus", "メニュー"),
        ("panels", "Panels", "パネル"),
        ("file_handlers", "File Handlers", "ファイルハンドラー"),
    ):
        entries = list(static_ui.get(kind) or [])
        if not entries:
            continue
        functions.append(_t(label_en, label_ja, context=context))
        for entry in entries:
            label = _ui(entry.get("label") or entry.get("idname") or "", context=context)
            edesc = _ui(entry.get("description") or "", context=context)
            if label and edesc:
                functions.append(f"{label}: {edesc}")
            elif label:
                functions.append(label)
    overview = [desc or _t("This bundled add-on is integrated into Smart File and remains unloaded until one of its controls is used.", "この同梱アドオンは Smart File に統合されており、いずれかのコントロールを使うまで読み込まれません。", context=context)]
    if functions:
        overview.append(_t("Available functions:", "利用できる機能:", context=context))
        overview.extend(functions)
    usage = [
        _t("Use the matching category button in the Smart File N-panel. Direct commands run immediately or open Blender's native operator dialog. Advanced controls open migrated panels and settings only when required.", "Smart File Nパネル内の該当カテゴリボタンから使用します。直接コマンドは即時実行または Blender 標準のオペレーターダイアログを開きます。詳細コントロールは必要なときだけ移植済みパネルと設定を開きます。", context=context),
        _t("The tool stays unloaded until one of its controls is used, unless its saved always-on switch is enabled.", "このツールは、いずれかの操作を使うまで読み込まれません。常時起動の切り替えが有効で保存されている時だけ、起動時とファイルを開いた時に読み込まれます。", context=context),
        _t("Dialog-only controls open in Blender's native dialog when the matching operator runs.", "ダイアログ専用の設定は、対応するオペレーターを実行すると開く Blender 標準のダイアログに出ます。", context=context),
    ]
    if alias == "object_reporter":
        usage.extend((
            _t("The fields you turn on are used by the viewport labels, the summary table, and CSV export. Decimal places are set in the Fields panel.", "オンにしたフィールドは、ビューポートラベル・集計表・CSV 書き出しで使います。小数の桁数はフィールドのパネルで決めます。", context=context),
            _t("Geometry fields update after relevant scene or selection changes.", "ジオメトリのフィールドは、シーンや選択が変わると更新されます。", context=context),
            _t("Grouping applies to the summary table and CSV export. With the sum button on, rows add up; with it off, the shared value or (multiple) is shown.", "グループ化は集計表と CSV 書き出しに効きます。Σ を押した列は合計し、押していない列は共通の値か (multiple) を出します。", context=context),
            _t("In the tag list: the down arrow picks a value, the filter icon adds a condition, and the lines icon adds to the fields.", "タグの一覧の右のアイコンは、▼ が値の選択、じょうごが条件への追加、横線がフィールドへの追加です。", context=context),
        ))
        usage.append(_t("In Summary, press Refresh to load or update the table. In Tag Selected, switch to Any when the selected objects have no shared properties.", "集計表を読み込み・更新するには「更新」を押します。「選択にタグ付け」で共通のプロパティがない場合は「Any」に切り替えます。", context=context))
    elif alias == "ikea":
        usage.append(_t("Press Search to update the browser results.", "検索結果を更新するには「検索」を押します。", context=context))
    elif alias == "texture_manager":
        usage.append(_t("If the editor asks you to restart Blender, restart it to finish loading. Press Refresh to scan textures.", "読み込みのために再起動を求められたら Blender を再起動します。「更新」でテクスチャをスキャンします。", context=context))
    settings = _static_settings_for_alias(alias)
    return display, overview, usage, settings


def _integrated_section_help(context, lane: str, section: str) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    lane = str(lane or "OTHER").upper()
    title = _ui(section or _t("Integrated Tools", "統合ツール", context=context), context=context)
    specs = _registry_specs()
    overview = [_t("This group shows tools detected from bundled add-on folders and classified into the current Smart File category without loading the full tool code at startup.", "このグループは、同梱アドオンフォルダから検出したツールを、起動時に全コードを読み込まず現在の Smart File カテゴリへ分類して表示します。", context=context)]
    usage = [_t("Click a tool button to lazy-load and run only that target. Use each bundled add-on's Help button for its complete function and setting list.", "ツールボタンを押すと、その対象だけを遅延読み込みして実行します。各同梱アドオンの完全な機能一覧と設定一覧は、そのアドオンのヘルプを開いて確認します。", context=context)]
    lines = []
    for spec in specs:
        name = _ui(spec.get("display_name") or spec.get("alias") or "", context=context)
        desc = _ui(spec.get("description") or spec.get("note") or "", context=context)
        if name:
            lines.append(f"{name}: {desc}" if desc else name)
    if lines:
        overview.append(_t("Bundled tool groups:", "同梱ツールグループ:", context=context))
        overview.extend(lines)
    # Section settings are aggregated at the add-on level to avoid startup cost.
    settings = []
    for spec in specs:
        alias = str(spec.get("alias") or "").strip()
        if alias:
            settings.extend(_static_settings_for_alias(alias))
    return title, overview, usage, settings



def _file_pipeline_help(context) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    title = _t("File Pipeline", "File Pipeline", context=context)
    overview = [
        _t(
            "File Pipeline is the upper-compatible cross-DCC file-management command center inside Smart File. It consolidates preflight scoring, prioritized repair recommendations, linked-library inventory, scored Link Manager style repath, smart missing-reference resolution with path-token/stem/sequence/version/size-aware candidate scoring, verified BlendPack/FilePathFinder style asset collection with UDIM and image-sequence expansion, Project Manager style missing-asset checks, scene assembly representations, Softimage/Maya style delta snapshots, parsed USD layer manifests, Katana/Clarisse inspired lazy assembly notes, shot and camera queues, cache reports, version upgrade plans, dependency graphs, publish/load container manifests, engine prefab manifests, material rule manifests, duplicate audits, project quality audits, portable handoff packs, and check-in/check-out lock records.",
            "ファイル パイプライン は Smart File 内に組み込んだ上位互換のDCC横断ファイル管理コマンドセンターです。事前診断スコア、優先修復提案、リンクライブラリ一覧、スコア付き再パス指定、パストークン、ステム、シーケンス、バージョン、サイズを考慮した欠落参照のスマート解決、UDIM と画像シーケンス展開に対応した検証付きアセット収集、欠落アセット確認、シーンアセンブリ表現、差分スナップショット、解析付き USD レイヤーマニフェスト、遅延アセンブリ用メモ、ショット/カメラキュー、キャッシュレポート、バージョン更新計画、依存関係グラフ、公開・読み込み コンテナマニフェスト、エンジン用プレハブマニフェスト、マテリアルルールマニフェスト、重複監査、プロジェクト品質監査、ポータブル受け渡しパック、チェックイン/チェックアウトロックをまとめます。",
            context=context,
        ),
        _t(
            "Generated files are stored in Smart File CONFIG storage unless Output Folder is manually set in the N-panel. The add-on preference property UI is not used.",
            '生成ファイルは、Nパネルで 出力フォルダー を手動指定した場合を除き、Smart File の CONFIG 保存領域へ保存します。アドオンプリファレンスのプロパティUIは使用しません。',
            context=context,
        ),
    ]
    usage = [
        _t(
            "Open Smart File > any category > File Pipeline. Start with Pipeline Preflight, review the Quality Score and Recommended Actions, then choose a Workflow board. Set Project Root, Search Root, Output Folder, Scope, Proxy Mode, Action Deck, Icon Scale, Frameless Icons, confidence threshold, replacement prefixes, texture extensions, and safety switches. Run Preview Repath or Smart Resolve Missing before applying path changes. Enable Apply Changes only when you are ready to write paths, open linked libraries, or change object states.",
            'Smart File の任意カテゴリから ファイル パイプライン を開きます。まず パイプライン事前診断 を実行し、品質スコアと推奨アクションを確認してからワークフローボードを選びます。プロジェクトルート、検索ルート、出力フォルダー、範囲、プロキシのモード、アクションデッキ、アイコンの大きさ、枠無しアイコン、信頼度しきい値、置換元/置換先パス、テクスチャ拡張子、安全スイッチを設定します。パス変更前は 再パス指定をプレビュー または 見つからない参照の解決 を先に実行し、パスの書き戻し、リンクライブラリを開く操作、オブジェクト状態の変更準備ができた場合のみ 変更を適用 を有効にします。',
            context=context,
        ),
        _t(
            "Use the Icon Deck when you want large frameless custom icons for faster visual operation. Use Portable Handoff Pack for final delivery, Pipeline Preflight for the fastest go/no-go decision, Smart Resolve Missing for scored repair, Verify Package after Collect Package, Reference Inventory and Project Quality Audit for audits, Preview Repath before Apply Repath for controlled path repair, Dependency Graph for TD review, Material Rule Manifest for lookdev handoff, Publish Container Manifest for Prism/AYON style handoff, Proxy Display for heavy assemblies, Capture Delta before risky local edits, Shot Manifest for camera handoff, USD Layer Manifest for USD-oriented pipelines, and Engine Prefab Manifest for Unreal/Unity style downstream planning.",
            '大きな枠無しカスタムアイコンで素早く操作したい場合は アイコンデッキ を使います。最終納品には ポータブル引き渡しパック、最短の可否判断には パイプライン事前診断、スコア付き修復には 見つからない参照の解決、パッケージを収集 後の確認には パッケージを検証、監査には 参照インベントリ と プロジェクト品質を監査、安全なパス修復には 再パス指定を適用 の前に 再パス指定をプレビュー、TD確認には 依存のグラフ、ルックデブ受け渡しには マテリアルルールマニフェスト、Prism/AYON 型の受け渡しには 公開コンテナマニフェスト、重いアセンブリには プロキシ表示、危険なローカル編集前には 差分を保存、カメラ受け渡しには ショットマニフェスト、USD 系パイプラインには USDレイヤーマニフェスト、Unreal/Unity 系の下流設計には エンジン用プレハブマニフェスト を使います。',
            context=context,
        ),
    ]
    settings = [
        {"name": _t("Project Root", 'プロジェクトルート', context=context), "description": _t("Manual project root used by catalog, version, and search actions.", "カタログ、バージョン、検索系アクションで使う手動プロジェクトルートです。", context=context)},
        {"name": _t("Search Root", '検索ルート', context=context), "description": _t("Manual search root used to find missing or newer files.", "欠落ファイルや新しいバージョンを探す手動検索ルートです。", context=context)},
        {"name": _t("Output Folder", '出力フォルダー', context=context), "description": _t("Manual output folder. Empty stores generated files in Smart File CONFIG storage.", "手動出力フォルダーです。空欄時は生成ファイルを Smart File の CONFIG 保存領域へ保存します。", context=context)},
        {"name": _t("Apply Changes", '変更を適用', context=context), "description": _t("Safety switch for actions that change file paths. While it is off, no paths are written and Edit Linked Library does not open the file. Collect Package still copies the files.", "ファイルのパスを変える機能の安全スイッチです。切っている間は、パスを書き換えず、「リンクライブラリを編集」もファイルを開きません。「パッケージを収集」はファイルを写すところまで行います。", context=context)},
        {"name": _t("Use Relative Paths", "Use Relative Paths", context=context), "description": _t("Stores written paths as Blender-relative paths when the current file is saved.", "現在のファイルが保存済みの場合、書き戻すパスを Blender 相対パスで保存します。", context=context)},
        {"name": _t("Workflow", "Workflow", context=context), "description": _t("Changes the recommended File Pipeline board without disabling the full toolset.", "推奨されるファイル パイプライン ボードを切り替えます。全ツールは無効化されません。", context=context)},
        {"name": _t("Confidence Threshold", "信頼度しきい値", context=context), "description": _t("Minimum score required before Smart Resolve Missing can apply a candidate when Apply Changes is enabled.", '変更を適用有効時に見つからない参照の解決が候補を適用するための最低スコアです。', context=context)},
        {"name": _t("Action Deck", 'アクションデッキ', context=context), "description": _t("Switches between Guided, Icon Deck, and Dense layouts. Icon Deck prioritizes the generated frameless icons and larger hit targets.", 'ガイド付き、アイコンデッキ、高密度 のレイアウトを切り替えます。アイコンデッキ は生成済みの枠無しアイコンと大きい操作対象を優先します。', context=context)},
        {"name": _t("Icon Scale", 'アイコンの大きさ', context=context), "description": _t("Controls the height of File Pipeline icon buttons. The generated PNGs use transparent backgrounds and oversized symbols so they remain readable.", "ファイル パイプライン のアイコンボタン高さを調整します。生成PNGは透明背景で図形を大きく描いているため視認性を保ちやすくなります。", context=context)},
        {"name": _t("Frameless Icons", '枠無しアイコン', context=context), "description": _t("Draws supported File Pipeline icon buttons without button embossing, leaving the generated symbol as the visual focus.", "対応するファイル パイプライン アイコンボタンをエンボスなしで描画し、生成した図形を見た目の中心にします。", context=context)},
        {"name": _t("Hash Files", "Hash Files", context=context), "description": _t("Computes SHA-1 hashes for higher precision audits. Keep disabled for faster checks on huge caches.", "高精度監査用にSHA-1ハッシュを計算します。巨大キャッシュを高速に確認したい場合は無効のままにします。", context=context)},
    ]
    return title, overview, usage, settings

def _file_pipeline_action_help(context, action: str, title: str = "") -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    key = str(action or '').strip().upper()
    label = title or key.replace('_', ' ').title()
    desc = ''
    try:
        package = str(__package__ or "").strip()
        if not package:
            raise ImportError("Smart File package namespace is unavailable")
        mod = importlib.import_module(f"{package}.file_pipeline")
        desc_map = getattr(mod, '_SFSMART_ACTION_DESC_MAP', {}) or {}
        label_map = getattr(mod, '_SFSMART_ACTION_LABEL_MAP', {}) or {}
        label = str(label_map.get(key) or label)
        desc = str(desc_map.get(key) or '')
    except Exception:
        pass
    display = _ui(label, context=context)
    overview = [
        _ui(desc, context=context) or _t('This File Pipeline action runs one focused production task.', 'この ファイル パイプライン アクションは、1つの明確な制作タスクを実行します。', context=context),
    ]
    usage = [
        _t('Review the relevant section settings first, then run this action from the File Pipeline area. Destructive actions should be used only after checking Apply Changes and the target paths.', '関連するセクション設定を先に確認してから、ファイル パイプライン エリアからこのアクションを実行します。破壊的な操作は、変更を適用 と対象パスを確認してからのみ使います。', context=context),
    ]
    settings_map = {
        'PIPELINE_PREFLIGHT': ['sf_smart_workflow', 'sf_smart_confidence_threshold', 'sf_smart_hash_files', 'sf_smart_analyze_sequences'],
        'SMART_RESOLVE_MISSING': ['sf_smart_search_root', 'sf_smart_confidence_threshold', 'sf_smart_apply_changes', 'sf_smart_make_relative', 'sf_smart_include_libraries', 'sf_smart_max_scan_files'],
        'PORTABLE_HANDOFF_PACK': ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_bundle_dir', 'sf_smart_zip_bundle', 'sf_smart_make_relative', 'sf_smart_hash_files'],
        'SCAN_REFERENCES': ['sf_smart_include_libraries', 'sf_smart_hash_files', 'sf_smart_analyze_sequences'],
        'COLLECT_ASSETS': ['sf_smart_bundle_dir', 'sf_smart_zip_bundle', 'sf_smart_apply_changes', 'sf_smart_make_relative', 'sf_smart_include_libraries'],
        'VERIFY_PACKAGE': ['sf_smart_bundle_dir', 'sf_smart_hash_files'],
        'REPATH_PREVIEW': ['sf_smart_repath_from', 'sf_smart_repath_to', 'sf_smart_search_root', 'sf_smart_include_libraries', 'sf_smart_max_scan_files'],
        'REPATH_APPLY': ['sf_smart_apply_changes', 'sf_smart_make_relative', 'sf_smart_repath_from', 'sf_smart_repath_to'],
        'RELATIVE_PATHS': ['sf_smart_make_relative', 'sf_smart_apply_changes'],
        'RELOAD_LIBRARIES': ['sf_smart_include_libraries'],
        'MAKE_LOCAL': ['sf_smart_scope'],
        'OVERRIDE_SELECTED': ['sf_smart_scope'],
        'DISABLE_LINKED': ['sf_smart_scope', 'sf_smart_proxy_mode'],
        'RESTORE_LINKED_VISIBILITY': [],
        'CAPTURE_DELTA': ['sf_smart_delta_file'],
        'COMPARE_DELTA': ['sf_smart_delta_file'],
        'RESTORE_DELTA': ['sf_smart_delta_file'],
        'SHOT_MANIFEST': ['sf_smart_bundle_dir'],
        'CAMERA_QUEUE': ['sf_smart_bundle_dir'],
        'CATALOG_INDEX': ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_max_scan_files', 'sf_smart_catalog_file'],
        'CATALOG_DUPLICATE_AUDIT': ['sf_smart_catalog_file', 'sf_smart_hash_files'],
        'USD_MANIFEST': ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_max_scan_files'],
        'VERSION_PLAN': ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_max_scan_files'],
        'APPLY_VERSION_PLAN': ['sf_smart_apply_changes', 'sf_smart_make_relative'],
        'CACHE_SCAN': ['sf_smart_search_root', 'sf_smart_analyze_sequences'],
        'TEXTURE_EXTENSION_SWAP': ['sf_smart_extension_from', 'sf_smart_extension_to', 'sf_smart_apply_changes', 'sf_smart_make_relative'],
        'NAMING_REPORT': ['sf_smart_project_root', 'sf_smart_search_root'],
        'MATERIAL_RULES': ['sf_smart_bundle_dir', 'sf_smart_material_rule_file'],
        'CHECKOUT': ['sf_smart_checkout_user'],
        'CHECKIN': ['sf_smart_checkout_user'],
        'ENGINE_MANIFEST': ['sf_smart_bundle_dir'],
        'EXPORT_HIERARCHY_AS_LIBRARY': ['sf_smart_bundle_dir', 'sf_smart_scope'],
        'PROJECT_QUALITY_AUDIT': ['sf_smart_confidence_threshold', 'sf_smart_hash_files', 'sf_smart_analyze_sequences'],
        'DEPENDENCY_GRAPH': ['sf_smart_hash_files', 'sf_smart_bundle_dir'],
        'PUBLISH_CONTAINER': ['sf_smart_bundle_dir', 'sf_smart_project_root'],
        'PIPELINE_SUPER_MANIFEST': ['sf_smart_bundle_dir', 'sf_smart_project_root', 'sf_smart_search_root'],
        'EDIT_LINKED_LIBRARY': ['sf_smart_apply_changes'],
    }
    settings = _window_manager_settings(context, settings_map.get(key, []), source=display)
    return display, overview, usage, settings


def _file_pipeline_section_help(context, section: str) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    key = str(section or '').strip().upper()
    title_map = {
        'SFSMART_COMMAND_CENTER': ('Command Center', 'Command Center'),
        'SFSMART_RECOMMENDED_ACTIONS': ('Recommended Actions', '推奨アクション'),
        'SFSMART_SETTINGS': ('File Pipeline Settings', 'ファイル パイプライン 設定'),
        'SFSMART_VISUAL_OPERATION': ('Visual Operation', '表示と操作'),
        'SFSMART_ROOTS_OUTPUT': ('Roots and Output', 'ルートと出力'),
        'SFSMART_BEHAVIOR_SAFETY': ('Behavior and Safety', '動作と安全設定'),
        'SFSMART_ADVANCED_PRECISION': ('Advanced Precision', '詳細精度設定'),
        'SFSMART_ICON_DECK': ('Icon Action Deck', 'アイコンアクションデッキ'),
        'SFSMART_AUDIT_REPAIR': ('Audit and Repair', '監査と修復'),
        'SFSMART_PACKAGE_PUBLISH': ('Package and Publish', 'パッケージと公開'),
        'SFSMART_ASSEMBLY_OVERRIDES': ('Assembly and Overrides', 'アセンブリとオーバーライド'),
        'SFSMART_SHOT_CACHE_USD_LOOKDEV': ('Shot, Cache, USD, and Lookdev', 'ショット・キャッシュ・USD・ルックデブ'),
        'SFSMART_CATALOG_MAINTENANCE': ('Catalog and Maintenance', 'カタログと保守'),
    }
    en, ja = title_map.get(key, ('File Pipeline', 'ファイル パイプライン'))
    title = _t(en, ja, context=context)
    overview_map = {
        'SFSMART_COMMAND_CENTER': [
            _t('This board summarizes the current scene health, latest preflight score, high-risk counts, and readiness for handoff in one place.', 'このボードでは、現在のシーン健全性、直近の事前診断スコア、高リスク件数、受け渡し準備状態を1か所で確認できます。', context=context),
            _t('Use it as the first stop before repair, packaging, publish, or downstream export work.', '修復、パッケージ化、公開、下流書き出しの前に最初に確認する場所として使います。', context=context),
        ],
        'SFSMART_RECOMMENDED_ACTIONS': [
            _t('This group exposes the fastest safe entry points for the most common File Pipeline workflows.', 'このグループでは、ファイル パイプライン の代表的な作業へ最短で安全に入れるボタンをまとめています。', context=context),
        ],
        'SFSMART_SETTINGS': [
            _t('This group contains the persistent N-panel settings that control File Pipeline behavior, safety, path targets, and UI style.', 'このグループには、ファイル パイプライン の動作、安全性、パス先、UIスタイルを制御する恒久的なNパネル設定をまとめています。', context=context),
        ],
        'SFSMART_VISUAL_OPERATION': [
            _t('These settings change how File Pipeline is presented in the N-panel without changing the underlying data.', 'これらの設定は、内部データを変えずに ファイル パイプライン のNパネル表示と操作感だけを切り替えます。', context=context),
        ],
        'SFSMART_ROOTS_OUTPUT': [
            _t('These path settings decide where File Pipeline searches for assets and where it writes generated packages and reports.', 'これらのパス設定は、ファイル パイプライン がアセットを探す場所と、生成パッケージやレポートを書き出す場所を決めます。', context=context),
        ],
        'SFSMART_BEHAVIOR_SAFETY': [
            _t('These switches decide what is collected, how paths are written back, and whether file or object changes are allowed.', 'これらのスイッチは、収集対象、パスの書き戻し方法、ファイルやオブジェクトの変更可否を決めます。', context=context),
        ],
        'SFSMART_ADVANCED_PRECISION': [
            _t('These settings increase analysis precision for large productions, but can add scan time.', 'これらの設定は大規模制作での解析精度を高めますが、走査時間が増えることがあります。', context=context),
        ],
        'SFSMART_ICON_DECK': [
            _t('This board places the main File Pipeline actions into a dense visual deck that prioritizes custom icons and large hit targets.', 'このボードでは、主要な ファイル パイプライン アクションを、独自アイコンと大きな操作領域を優先した視覚デッキとして並べます。', context=context),
        ],
        'SFSMART_AUDIT_REPAIR': [
            _t('This tool group focuses on scene inspection, missing-reference search, scored repair planning, and safe path correction.', 'このツールグループは、シーン検査、欠落参照探索、スコア付き修復計画、安全なパス修正に集中しています。', context=context),
        ],
        'SFSMART_PACKAGE_PUBLISH': [
            _t('This group prepares portable deliveries by collecting files, verifying the result, and writing handoff manifests.', 'このグループは、ファイル収集、検証、受け渡しマニフェスト出力により、可搬性のある納品物を準備します。', context=context),
        ],
        'SFSMART_ASSEMBLY_OVERRIDES': [
            _t('This group handles proxy display, overrides, link materialization, and delta capture for heavy linked assemblies.', 'このグループは、重いリンクアセンブリ向けのプロキシ表示、オーバーライド、リンク実体化、差分保存を扱います。', context=context),
        ],
        'SFSMART_SHOT_CACHE_USD_LOOKDEV': [
            _t('This group covers shot-state export, camera queues, cache inspection, USD layer manifests, and material rule handoff.', 'このグループは、ショット状態出力、カメラキュー、キャッシュ検査、USD レイヤーマニフェスト、マテリアルルール受け渡しを扱います。', context=context),
        ],
        'SFSMART_CATALOG_MAINTENANCE': [
            _t('This group builds catalogs, checks duplicates, audits naming and quality, manages lock records, and prepares maintenance reports.', 'このグループは、カタログ生成、重複確認、命名/品質監査、ロック管理、保守レポート作成を扱います。', context=context),
        ],
    }
    usage_map = {
        'SFSMART_COMMAND_CENTER': [
            _t('Run Pipeline Preflight first, then review the score, counts, and recommended next steps before choosing another board.', '最初に パイプライン事前診断 を実行し、その後でスコア、件数、推奨手順を確認してから別のボードへ進みます。', context=context),
        ],
        'SFSMART_RECOMMENDED_ACTIONS': [
            _t('Use these buttons when you want the standard safe order: inspect, repair, package, then verify or export.', '検査、修復、パッケージ化、検証または書き出し、という標準的で安全な順序で進めたい場合に使います。', context=context),
        ],
        'SFSMART_SETTINGS': [
            _t('Adjust these once per project or scene context. The values are saved with Smart File N-panel persistence and can also be kept by the Save Preferences flow.', 'これらはプロジェクトやシーンごとに調整します。値は Smart File のNパネル永続化で保存され、［プリファレンスを保存］の流れでも維持できます。', context=context),
        ],
        'SFSMART_VISUAL_OPERATION': [
            _t('Use Guided for structured work, Icon Deck for icon-first operation, and Dense when you need maximum action density.', '整理された操作には ガイド付き、アイコン優先操作には アイコンデッキ、情報量重視には 高密度 を使います。', context=context),
        ],
        'SFSMART_ROOTS_OUTPUT': [
            _t('Set Project Root and Search Root before running search-heavy tools. Leave Output Folder empty when you want generated files to stay inside Smart File CONFIG storage.', '検索系ツールを使う前に プロジェクトルート と 検索ルート を設定します。生成ファイルを Smart File の CONFIG 保存領域へ保存したい場合は 出力フォルダー を空欄にします。', context=context),
        ],
        'SFSMART_BEHAVIOR_SAFETY': [
            _t('Keep Apply Changes off while reviewing plans. Turn it on only when you are ready to write paths.', '案を確かめている間は「変更を適用」を切っておき、パスを実際に書き換える時だけ入れます。', context=context),
        ],
        'SFSMART_ADVANCED_PRECISION': [
            _t('Use these only when simpler checks are not enough. Hashing, sequence analysis, and large scan limits help precision but cost more time.', '簡易確認で足りない場合だけ使います。ハッシュ、シーケンス解析、大きな走査上限は精度向上に役立ちますが、その分時間がかかります。', context=context),
        ],
        'SFSMART_ICON_DECK': [
            _t('Use this when you want the cleanest large-icon workflow. The Help buttons beside action rows still explain each action in detail.', '大きなアイコン中心で最も直感的に操作したいときに使います。各アクション横のヘルプから詳細も確認できます。', context=context),
        ],
        'SFSMART_AUDIT_REPAIR': [
            _t('Run inventory and preflight first, then preview repath or Smart Resolve Missing. Apply repair only after reviewing the scored candidates.', '最初に 参照インベントリ と 事前点検 を行い、その後で 再パス指定をプレビュー または 見つからない参照の解決 を実行します。修復適用は、スコア付き候補を確認してから行います。', context=context),
        ],
        'SFSMART_PACKAGE_PUBLISH': [
            _t('Collect first, verify second, and write manifests last so the handoff data reflects the final packaged result.', '先に収集し、次に検証し、最後にマニフェストを書き出すことで、受け渡し情報を最終パッケージ状態に合わせます。', context=context),
        ],
        'SFSMART_ASSEMBLY_OVERRIDES': [
            _t('Capture Delta before making risky local edits. Use proxy display for heavy scenes and restore display after review when needed.', '危険なローカル編集の前に 差分を保存 を実行します。重いシーンでは プロキシ表示 を使い、必要に応じて 確認の後に 表示を復元 で戻します。', context=context),
        ],
        'SFSMART_SHOT_CACHE_USD_LOOKDEV': [
            _t('Use these tools after the scene structure is stable enough for review, render queue preparation, cache handoff, or USD/lookdev exchange.', 'レビュー、レンダーキュー準備、キャッシュ受け渡し、USD/ルックデブ交換ができる程度にシーン構造が固まった後で使います。', context=context),
        ],
        'SFSMART_CATALOG_MAINTENANCE': [
            _t('Use these when maintaining a long-lived project library or cleaning a large source tree before delivery.', '長期運用ライブラリの保守や、大きなソースツリーを納品前に整理するときに使います。', context=context),
        ],
    }
    settings = {
        'SFSMART_COMMAND_CENTER': _window_manager_settings(context, ['sf_smart_workflow', 'sf_smart_confidence_threshold', 'sf_smart_apply_changes'], source=title),
        'SFSMART_RECOMMENDED_ACTIONS': _window_manager_settings(context, ['sf_smart_workflow', 'sf_smart_apply_changes', 'sf_smart_confidence_threshold'], source=title),
        'SFSMART_SETTINGS': _window_manager_settings(context, ['sf_smart_workflow', 'sf_smart_ui_density', 'sf_smart_show_advanced', 'sf_smart_action_deck_style', 'sf_smart_icon_scale', 'sf_smart_frameless_icons', 'sf_smart_show_button_hints', 'sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_bundle_dir', 'sf_smart_scope', 'sf_smart_proxy_mode', 'sf_smart_include_libraries', 'sf_smart_make_relative', 'sf_smart_apply_changes', 'sf_smart_zip_bundle', 'sf_smart_confidence_threshold', 'sf_smart_max_scan_files', 'sf_smart_hash_files', 'sf_smart_analyze_sequences', 'sf_smart_repath_from', 'sf_smart_repath_to', 'sf_smart_extension_from', 'sf_smart_extension_to', 'sf_smart_delta_file', 'sf_smart_catalog_file', 'sf_smart_checkout_user'], source=title),
        'SFSMART_VISUAL_OPERATION': _window_manager_settings(context, ['sf_smart_action_deck_style', 'sf_smart_icon_scale', 'sf_smart_frameless_icons', 'sf_smart_show_button_hints', 'sf_smart_ui_density', 'sf_smart_show_advanced'], source=title),
        'SFSMART_ROOTS_OUTPUT': _window_manager_settings(context, ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_bundle_dir'], source=title),
        'SFSMART_BEHAVIOR_SAFETY': _window_manager_settings(context, ['sf_smart_scope', 'sf_smart_proxy_mode', 'sf_smart_include_libraries', 'sf_smart_make_relative', 'sf_smart_apply_changes', 'sf_smart_zip_bundle'], source=title),
        'SFSMART_ADVANCED_PRECISION': _window_manager_settings(context, ['sf_smart_confidence_threshold', 'sf_smart_max_scan_files', 'sf_smart_hash_files', 'sf_smart_analyze_sequences', 'sf_smart_repath_from', 'sf_smart_repath_to', 'sf_smart_extension_from', 'sf_smart_extension_to', 'sf_smart_delta_file', 'sf_smart_catalog_file', 'sf_smart_checkout_user'], source=title),
        'SFSMART_ICON_DECK': _window_manager_settings(context, ['sf_smart_action_deck_style', 'sf_smart_icon_scale', 'sf_smart_frameless_icons', 'sf_smart_show_button_hints'], source=title),
        'SFSMART_AUDIT_REPAIR': _window_manager_settings(context, ['sf_smart_search_root', 'sf_smart_project_root', 'sf_smart_confidence_threshold', 'sf_smart_max_scan_files', 'sf_smart_apply_changes', 'sf_smart_make_relative', 'sf_smart_include_libraries', 'sf_smart_repath_from', 'sf_smart_repath_to'], source=title),
        'SFSMART_PACKAGE_PUBLISH': _window_manager_settings(context, ['sf_smart_bundle_dir', 'sf_smart_zip_bundle', 'sf_smart_make_relative', 'sf_smart_include_libraries', 'sf_smart_project_root'], source=title),
        'SFSMART_ASSEMBLY_OVERRIDES': _window_manager_settings(context, ['sf_smart_scope', 'sf_smart_proxy_mode', 'sf_smart_apply_changes', 'sf_smart_delta_file'], source=title),
        'SFSMART_SHOT_CACHE_USD_LOOKDEV': _window_manager_settings(context, ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_hash_files', 'sf_smart_analyze_sequences', 'sf_smart_bundle_dir'], source=title),
        'SFSMART_CATALOG_MAINTENANCE': _window_manager_settings(context, ['sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_max_scan_files', 'sf_smart_hash_files', 'sf_smart_analyze_sequences', 'sf_smart_extension_from', 'sf_smart_extension_to', 'sf_smart_catalog_file', 'sf_smart_checkout_user'], source=title),
    }.get(key, [])
    return title, overview_map.get(key, [_t('This section belongs to File Pipeline.', 'このセクションは ファイル パイプライン に含まれます。', context=context)]), usage_map.get(key, [_t('Use the section header buttons or action rows inside File Pipeline.', 'ファイル パイプライン 内のセクションヘッダーまたはアクション行から使います。', context=context)]), settings


def _history_section_help(context, section: str) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    key = str(section or '').strip().upper()
    title_map = {
        'HISTORY_BROWSER': ('History Browser', '履歴ブラウザー'),
        'HISTORY_QUICK_ACTIONS': ('Quick Actions', 'クイックアクション'),
        'HISTORY_SELECTED_SNAPSHOT': ('Selected Snapshot', '選択中スナップショット'),
        'HISTORY_AUTOMATIC_PROTECTION': ('Automatic Protection', '自動保護'),
        'HISTORY_STORAGE_BEHAVIOR': ('Storage & Behavior', '保存先と動作'),
        'HISTORY_TIPS': ('Tips', 'ヒント'),
    }
    en, ja = title_map.get(key, ('History & Restore', '履歴/復元'))
    title = _t(en, ja, context=context)
    overview_map = {
        'HISTORY_BROWSER': [_t('This section lists restore points and autosaves in a focused browser so you can locate a safe rollback target quickly.', 'このセクションでは、復元ポイントと自動保存を見やすいブラウザーにまとめ、戻り先を素早く探せるようにしています。', context=context)],
        'HISTORY_QUICK_ACTIONS': [_t('This section focuses on deliberate manual restore points before risky work. Autosave creation remains available as a secondary utility.', 'このセクションでは、危険な作業前に意図的な手動復元ポイントを作成することを主役にしています。自動保存の即時作成は補助操作として残しています。', context=context)],
        'HISTORY_SELECTED_SNAPSHOT': [_t('This section shows the currently selected row in detail before you restore or delete it.', 'このセクションでは、復元や削除の前に、選択中の履歴行の詳細を確認できます。', context=context)],
        'HISTORY_AUTOMATIC_PROTECTION': [_t('This section controls optional timed restore points and rolling autosaves. Autosave can skip idle intervals when no operation or scene update happened.', 'このセクションでは、任意の定期復元ポイントとローリング自動保存を制御します。自動保存は、操作やシーン更新がない待機時間をスキップできます。', context=context)],
        'HISTORY_STORAGE_BEHAVIOR': [_t('This section controls where history files are written and how safety behavior works during restore.', 'このセクションでは、履歴ファイルの保存先と、復元時の安全動作を制御します。', context=context)],
        'HISTORY_TIPS': [_t('This section provides short guidance for safe recovery workflows.', 'このセクションでは、安全な復旧ワークフロー向けの短い案内を表示します。', context=context)],
    }
    usage_map = {
        'HISTORY_BROWSER': [_t('Select a row first, review the time and details, then restore only when the target is correct.', '先に行を選択し、時刻と詳細を確認してから、対象が正しいと判断できた場合のみ復元します。', context=context)],
        'HISTORY_QUICK_ACTIONS': [_t('Name the checkpoint clearly, then create a Manual Restore Point before destructive edits, imports, exports, or large cleanup work.', 'チェックポイント名を分かりやすく付け、破壊的な編集、読み込み、書き出し、大規模な整理の前に手動復元ポイントを作成します。', context=context), _t('If the name is left empty, the restore point is named Manual Restore Point in the current language.', '名前が空のときは、「手動復元ポイント」という名前で作ります。', context=context)],
        'HISTORY_SELECTED_SNAPSHOT': [_t('Use this area to inspect the active object, scene, mode, frame, and attached file before restore.', '復元前に、アクティブオブジェクト、シーン、モード、フレーム、関連ファイルを確認するために使います。', context=context)],
        'HISTORY_AUTOMATIC_PROTECTION': [_t('Enable Rolling Autosave or Optional Timed Restore Points only when continuous protection is required.', '継続的な保護が必要な場合だけ、世代管理自動保存または任意の定期復元ポイントを有効にします。', context=context)],
        'HISTORY_STORAGE_BEHAVIOR': [_t('Leave the storage folder empty to keep generated files under Smart File CONFIG storage. Set a manual folder only when a project requires a separate storage root.', '生成ファイルを Smart File の CONFIG 保存領域へ置きたい場合は保存フォルダーを空欄にします。別保存先が必要なプロジェクトだけ手動フォルダーを設定します。', context=context)],
        'HISTORY_TIPS': [_t('Use the tips as a quick reminder, not as the main control surface. The actual settings remain in the sections above.', 'ヒントは簡易リマインダーとして使い、主設定は上の各セクションで調整します。', context=context)],
    }
    settings = {
        'HISTORY_BROWSER': _history_scene_settings(context, ['filter_text', 'show_only_restorable', 'show_details'], source=title),
        'HISTORY_QUICK_ACTIONS': _history_scene_settings(context, ['checkpoint_name'], source=title),
        'HISTORY_SELECTED_SNAPSHOT': _history_scene_settings(context, ['show_details'], source=title),
        'HISTORY_AUTOMATIC_PROTECTION': _merge_settings(_history_pref_settings(context, ['enable_restore_snapshots', 'restore_snapshot_interval_minutes', 'restore_snapshot_max_files', 'enable_autosave', 'autosave_interval_minutes', 'autosave_max_files', 'autosave_skip_unchanged', 'autosave_retention_scope'], source=title)),
        'HISTORY_STORAGE_BEHAVIOR': _history_pref_settings(context, ['history_directory', 'compress_snapshots', 'double_click_restore', 'create_safety_snapshot_before_restore', 'timer_interval_seconds'], source=title),
        'HISTORY_TIPS': [],
    }.get(key, [])
    return title, overview_map.get(key, [_t('This section belongs to History & Restore.', 'このセクションは履歴/復元に含まれます。', context=context)]), usage_map.get(key, [_t('Use the controls in the History & Restore area.', '履歴/復元エリア内のコントロールを使います。', context=context)]), settings


def _operator_help(context, operator_id: str, title: str = "") -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    cls = _operator_rna_class(operator_id)
    label = title or _t("Command", "コマンド", context=context)
    desc = ""
    if cls is not None:
        label = title or str(getattr(cls, "bl_label", "") or label)
        desc = str(getattr(cls, "bl_description", "") or "")
    label = _ui(label, context=context)
    overview = [desc or _t("This command is part of the selected Smart File tool group.", "このコマンドは選択中の Smart File ツールグループに含まれます。", context=context)]
    usage = [_t("Click the command button from the N-panel. If Blender opens an operator dialog, review the settings below before confirming.", "Nパネルからコマンドボタンを押します。Blender がオペレーターダイアログを開いた場合は、確定前に下記の設定項目を確認してください。", context=context)]
    settings = _settings_for_operator_ids([operator_id])
    return label, overview, usage, settings


def _home_help(context) -> tuple[str, list[str], list[str], list[dict[str, str]]]:
    meta = _CATEGORY_META["HOME"]
    title = _t(meta[0], meta[1], context=context)
    overview = [meta[2] if not _is_ja(context) else meta[3]]
    overview.append(_t("Visible groups include the always-on toggle group, page selector, quick source controls, seven functional Smart File categories, and the N-panel settings area.", "表示グループには、常時機能切り替え、ページ選択、クイックソース、7つの Smart File 機能カテゴリ、Nパネル設定エリアが含まれます。", context=context))
    usage = [meta[4] if not _is_ja(context) else meta[5]]
    usage.append(_t("The N-panel itself stays compact. Use Help popups for detailed explanations, and use Save Preferences in the N-panel when you want Blender to write preferences after Smart File has saved its N-panel settings.", "Nパネル本体はコンパクトに保ちます。詳細説明はヘルプポップアップで確認し、Smart File がNパネル設定を保存したうえで Blender プリファレンスも書き出したい場合は、Nパネル内の［プリファレンスを保存］を使用してください。", context=context))
    settings = _prefs_settings(context)
    settings.extend(_quick_sources_help(context)[3])
    return title, overview, usage, settings


def _resolve_topic(context, help_key: str, lane: str, section: str, addon_alias: str, operator_id: str, title: str):
    key = str(help_key or "").strip().lower()
    lane = str(lane or "").strip().upper()
    alias = str(addon_alias or "").strip()
    op_id = str(operator_id or "").strip()
    if key == "always_on":
        return _always_on_help(context)
    if key == "recovery":
        title = _t("Smart File Recovery", "Smart File の復旧", context=context)
        overview = [_t("Smart File could not load its full interface or runtime.", "Smart File の完全な UI またはランタイムを読み込めませんでした。", context=context)]
        usage = [_t("Use Load Smart File UI to repair the sidebar, or Retry Runtime Load after a startup failure. If recovery fails, check the last registration error shown in the panel.", "サイドバーを修復するには［Smart File UIを読み込む］を使います。起動に失敗した場合は［ランタイム読み込みを再試行］を使います。復旧できない場合は、パネルに表示される最後の登録エラーを確認してください。", context=context)]
        return title, overview, usage, []
    if key == "stl_import":
        title = _t("Legacy STL Import", "旧形式 STL インポート", context=context)
        overview = [_t("Load an STL mesh and adjust its scale, axes, and facet normals.", "STL メッシュを読み込み、スケール、軸、ファセット法線を設定します。", context=context)]
        usage = [_t("Select the STL file, review the settings, and confirm the import.", "STL ファイルを選び、設定を確認してインポートを実行します。", context=context)]
        return title, overview, usage, _settings_for_operator_ids(["import_mesh.sfs_stl_import"])
    if key == "stl_export":
        title = _t("Legacy STL Export", "旧形式 STL エクスポート", context=context)
        overview = [_t("Write meshes to STL with the chosen object selection, transform, and modifier settings.", "出力対象、トランスフォーム、モディファイアの設定に従ってメッシュを STL に書き出します。", context=context)]
        usage = [_t("Choose the output path, review the settings, and confirm the export.", "出力先を選び、設定を確認してエクスポートを実行します。", context=context)]
        return title, overview, usage, _settings_for_operator_ids(["export_mesh.sfs_stl_export"])
    if key == "undo_load_diagnostic":
        return _undo_load_diagnostic_help(context)
    if key == "history_section":
        return _history_section_help(context, section or title)
    if key == "file_pipeline_action":
        return _file_pipeline_action_help(context, section or operator_id or title, title)
    if key == "file_pipeline_section":
        return _file_pipeline_section_help(context, section or title)
    if key == "quick_sources":
        return _quick_sources_help(context)
    if key == "home" or lane == "HOME":
        return _home_help(context)
    if key == "integrated_addon" or alias:
        return _integrated_alias_help(context, alias)
    if key in {"integrated_section", "integrated_advanced"}:
        return _integrated_section_help(context, lane or "OTHER", section or title)
    if op_id in {"import_scene.sfs_file_pipeline_open", "import_scene.sfs_file_pipeline_run_action", "import_scene.sfs_file_pipeline_open_report", "import_scene.sfs_file_pipeline_open_icon_reference"} or key == "file_pipeline":
        return _file_pipeline_help(context)
    if key == "tool" or op_id:
        return _operator_help(context, op_id, title)
    if key == "category" or lane:
        return _category_help(context, lane or "OTHER")
    return _home_help(context)


def draw_help_popup(layout, context, *, help_key: str = "", lane: str = "", section: str = "", addon_alias: str = "", operator_id: str = "", title: str = "", popup_width: int | None = None) -> None:
    """Draw the detailed help popup. Imported only from the Help operator."""
    global _HELP_POPUP_WIDTH_PX
    _HELP_POPUP_WIDTH_PX = _active_help_popup_width(context, popup_width)
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    topic_title, overview, usage, settings = _resolve_topic(context, help_key, lane, section, addon_alias, operator_id, title)

    header = layout.box()
    header.label(text=_ui(topic_title, context=context), icon="QUESTION")

    _draw_block(layout, "Overview", "1. 機能概要", overview, context=context)
    _draw_block(layout, "2. Usage", "2. 使用方法", usage, context=context, icon="HELP")
    _draw_settings(layout, settings, context=context)


__all__ = ["draw_help_popup"]
