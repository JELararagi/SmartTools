# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy


def _wm_proxy(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is not None:
        proxy = getattr(wm, 'bulk_asset_tools_preferences_proxy', None)
        if proxy is not None:
            return proxy
    return None


class _BulkAssetToolsPrefsFallback:
    max_threads = 10
    background = True
    factory_default = True


_FALLBACK = _BulkAssetToolsPrefsFallback()


def get_bulk_asset_tools_prefs(context=None):
    ctx = context or getattr(bpy, 'context', None)
    proxy = _wm_proxy(context=ctx)
    if proxy is not None:
        return proxy
    return _FALLBACK

def get_integrated_preferences_proxy(context=None, pref_cls=None, record=None):
    return get_bulk_asset_tools_prefs(context=context)


class BulkAssetToolsPreferencesProxy(bpy.types.PropertyGroup):
    max_threads: bpy.props.IntProperty(
        name='Max Threads',
        description='Maximum number of child Blender processes started at the same time when applying asset metadata in bulk. Increase only if your machine has enough CPU and memory headroom.',
        default=10,
        min=1,
    )
    background: bpy.props.BoolProperty(
        name='Run Background Processes',
        description='Run each child Blender process without opening a full Blender window. This is usually faster and is recommended for unattended batch metadata updates.',
        default=True,
    )
    factory_default: bpy.props.BoolProperty(
        name='Use Factory Startup',
        description='Launch child Blender processes with factory startup so third-party add-ons and local startup files do not interfere with batch asset processing.',
        default=True,
    )


class SFS_PG_bulk_assets_bulk_assets_preferences(bpy.types.PropertyGroup):
    bl_label = 'Bulk Assets Preferences'
    bl_idname = __package__

    max_threads: bpy.props.IntProperty(
        name='Max Threads',
        description='Maximum number of child Blender processes started at the same time when applying asset metadata in bulk. Use a lower value on machines with limited CPU or memory.',
        default=10,
        min=1,
    )
    background: bpy.props.BoolProperty(
        name='Run Background Processes',
        description='Run child Blender processes in background mode so batch jobs do not open additional Blender windows. Recommended for normal use.',
        default=True,
    )
    factory_default: bpy.props.BoolProperty(
        name='Use Factory Startup',
        description='Start child Blender processes with factory startup. This prevents unrelated user add-ons and startup files from affecting the batch command result.',
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.label(text='Bulk Asset Tools')
        layout.prop(self, 'max_threads')
        layout.prop(self, 'background')
        layout.prop(self, 'factory_default')
