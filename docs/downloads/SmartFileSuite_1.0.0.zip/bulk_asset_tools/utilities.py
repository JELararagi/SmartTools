import bpy
import os
from .settings import get_bulk_asset_tools_prefs

# UI Functions


def header_menu_func(self, context):
    self.layout.operator_context = 'INVOKE_DEFAULT'
    self.layout.separator()



def tag_callback(self, context):
    tags = {}
    for f in bpy.context.selected_assets:
        for tag in f.metadata.tags:
            tags[tag.name] = True
    output = []
    i = 0
    for tag in tags.keys():
        output.append((tag, tag, "", i))
        i += 1
    return output


def item_callback(self, context):
    output = [("", "Catalog", "", 0),
              ("00000000-0000-0000-0000-000000000000", "Unassigned", "", 0)]

    if context.space_data.params.asset_library_reference == "ALL":
        return [("", "Select a catalog other than 'All'", "", 0)]

    directory = get_catalog_directory(context)
    catalog_path = os.path.join(directory, "blender_assets.cats.txt") if directory else ""
    # Unsaved local files and libraries without a catalog only offer Unassigned.
    if not catalog_path or not os.path.isfile(catalog_path):
        return output
    with open(catalog_path, encoding="utf-8") as catalog_file:
        cats = catalog_file.readlines()

    i = 1
    for line in cats:
        if line[0:1] == "#":
            continue
        if line.strip() == "":
            continue
        if line[0:7] == "VERSION":
            continue
        data = line.split(":")
        output.append((data[0], data[1], "", i))
        i += 1
    return output


# Utility Functions

def get_catalog_directory(context):
    params = context.space_data.params
    reference = params.asset_library_reference
    # Native Asset Browser does not keep params.directory for Current File.
    if reference == "LOCAL":
        return os.path.dirname(bpy.data.filepath) if bpy.data.filepath else ""
    library = context.preferences.filepaths.asset_libraries.get(reference)
    if library is not None:
        return bpy.path.abspath(library.path)
    # Keep Blender-provided directories for other concrete library references.
    return os.fsdecode(params.directory)


def get_file_path(relative_path, directory):
    p = relative_path.split(".blend\\")
    p[0] = p[0]+".blend"
    return os.path.join(directory, p[0])


def id_type_to_type_name(id_type):
    type_out = id_type.lower()+"s"
    if id_type == "NODETREE":
        type_out = "node_groups"
    return type_out


def run_command(path, commands):
    import subprocess
    commandlist = "".join(commands)
    try:
        expr = "import bpy; "+commandlist + \
            " bpy.ops.wm.save_mainfile(); bpy.ops.wm.quit_blender();"
        list = [bpy.app.binary_path]
        prefs = get_bulk_asset_tools_prefs()
        if prefs.background == True:
            list.append("-b")
        list.append(path)
        list.append("--python-expr")
        list.append(expr)
        subprocess.run(list)
    except:
        print("Error on the new Blender instance")
