# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Exact Suite/generation/session ownership for temporary Blender data.

Names, prefixes, Collection names and historical ``sss_generated`` flags are
never ownership evidence.  Cleanup requires a live in-memory ledger record and
all three persisted token fields to match byte-for-byte.
"""
from __future__ import annotations
from dataclasses import dataclass
import uuid
from typing import Any, Callable
from . import _sss_lifecycle as _lifecycle

_KEYS = ("_sss_owner_uuid", "_sss_generation_uuid", "_sss_session_uuid")
_REGISTRY: dict[int, tuple[Any, "OwnershipToken", str, Callable[[Any], None] | None]] = {}
_LOAD_PRE_HANDLE = None

@dataclass(frozen=True, slots=True)
class OwnershipToken:
    owner_uuid: str
    generation_uuid: str
    session_uuid: str


def new_token(session_uuid: str | None = None) -> OwnershipToken:
    return OwnershipToken(_lifecycle.OWNER_UUID, _lifecycle.active_generation(), str(session_uuid or uuid.uuid4()))


def stamp(data: Any, token: OwnershipToken) -> bool:
    if not (token.owner_uuid and token.generation_uuid and token.session_uuid):
        return False
    try:
        data[_KEYS[0]] = token.owner_uuid
        data[_KEYS[1]] = token.generation_uuid
        data[_KEYS[2]] = token.session_uuid
        return True
    except Exception:
        return False


def matches(data: Any, token: OwnershipToken) -> bool:
    try:
        return all(str(data.get(k, "") or "") == value for k, value in zip(_KEYS, (token.owner_uuid, token.generation_uuid, token.session_uuid)))
    except Exception:
        return False


def clear_if_owned(data: Any, token: OwnershipToken) -> bool:
    if not matches(data, token):
        return False
    try:
        for key in _KEYS:
            data.pop(key, None)
        return True
    except Exception:
        return False


def _release_load_pre_handler() -> None:
    global _LOAD_PRE_HANDLE
    handle = _LOAD_PRE_HANDLE
    if handle is None:
        return
    try:
        import bpy
        _lifecycle.remove_handler(bpy.app.handlers.load_pre, handle)
    except Exception:
        pass
    _LOAD_PRE_HANDLE = None


def _release_data_leases() -> None:
    """Release exact data-ledger records so no old RNA reference survives load."""
    journal = _lifecycle.current_journal()
    if journal is None:
        return
    while True:
        try:
            released = journal.release_matching(lambda record: record.kind == "data_ledger")
        except Exception:
            break
        if not released:
            break

def _on_load_pre(*_args, **_kwargs) -> None:
    # Data-block identities become invalid across file replacement. Release
    # exact finite leases only; never scan the incoming scene/database.
    _release_data_leases()
    _REGISTRY.clear()
    _release_load_pre_handler()


def _ensure_load_pre_handler() -> None:
    global _LOAD_PRE_HANDLE
    if _LOAD_PRE_HANDLE is not None or not _REGISTRY:
        return
    try:
        import bpy
        _LOAD_PRE_HANDLE = _lifecycle.append_handler(bpy.app.handlers.load_pre, _on_load_pre)
    except Exception:
        _LOAD_PRE_HANDLE = None


def track(data: Any, token: OwnershipToken, *, kind: str = "data", remover: Callable[[Any], None] | None = None) -> bool:
    """Track an exact ID object in the current generation's in-memory ledger."""
    current_generation = _lifecycle.active_generation()
    if (
        data is None
        or token.owner_uuid != _lifecycle.OWNER_UUID
        or not current_generation
        or token.generation_uuid != current_generation
        or not matches(data, token)
    ):
        return False
    ident = id(data)
    existing = _REGISTRY.get(ident)
    if existing is not None:
        if existing[0] is not data:
            return False
        if existing[1] == token and existing[2] == str(kind or "data"):
            return True
        # The same ID was stamped again under a new kind (a session part that
        # becomes the session): the persisted stamp is already the new token,
        # so the old record can never match again. Replace it.
    record = (data, token, str(kind or "data"), remover)
    _REGISTRY[ident] = record
    _ensure_load_pre_handler()
    # Release the strong RNA reference on rollback/unregister/load teardown.  The
    # lifecycle lease deliberately does not delete user-visible generated data.
    try:
        generation = _lifecycle.active_generation()
        if generation and generation == token.generation_uuid:
            value = (ident, data, token)
            def release_ledger(entry):
                entry_ident, entry_data, entry_token = entry
                current = _REGISTRY.get(entry_ident)
                if current is not None and current[0] is entry_data and current[1] == entry_token:
                    _REGISTRY.pop(entry_ident, None)
                    if not _REGISTRY:
                        _release_load_pre_handler()
            _lifecycle.acquire_resource(
                "data_ledger", value, release_ledger, callback=data,
                metadata={"data_identity": ident, "kind": str(kind or "data"),
                          "owner_uuid": token.owner_uuid, "session_uuid": token.session_uuid},
            )
    except Exception:
        # Tracking remains valid for the current explicit operation even when a
        # headless test does not expose a lifecycle journal.
        pass
    return True



def token_for(data: Any, *, kind: str | None = None) -> OwnershipToken | None:
    record = _REGISTRY.get(id(data))
    if record is None or record[0] is not data:
        return None
    _data, token, record_kind, _remover = record
    if kind is not None and record_kind != str(kind):
        return None
    if token.owner_uuid != _lifecycle.OWNER_UUID or token.generation_uuid != _lifecycle.active_generation():
        return None
    return token if matches(data, token) else None


def is_tracked(data: Any, *, kind: str | None = None) -> bool:
    return token_for(data, kind=kind) is not None


def stamp_and_track(data: Any, *, kind: str = "data", token: OwnershipToken | None = None,
                    remover: Callable[[Any], None] | None = None) -> OwnershipToken | None:
    owned = token or new_token()
    if not stamp(data, owned):
        return None
    return owned if track(data, owned, kind=kind, remover=remover) else None

def untrack(data: Any, token: OwnershipToken | None = None) -> bool:
    record = _REGISTRY.get(id(data))
    if record is None or record[0] is not data:
        return False
    if token is not None and record[1] != token:
        return False
    _REGISTRY.pop(id(data), None)
    if not _REGISTRY:
        _release_load_pre_handler()
    return True


def registry_checkpoint() -> frozenset[int]:
    return frozenset(_REGISTRY)


def tracked_records(*, kind: str | None = None) -> tuple[tuple[Any, OwnershipToken, str, Callable[[Any], None] | None], ...]:
    result = []
    stale = []
    current_generation = _lifecycle.active_generation()
    for ident, record in tuple(_REGISTRY.items()):
        data, token, record_kind, remover = record
        if (
            id(data) != ident
            or token.owner_uuid != _lifecycle.OWNER_UUID
            or not current_generation
            or token.generation_uuid != current_generation
            or not matches(data, token)
        ):
            stale.append(ident)
            continue
        if kind is None or record_kind == kind:
            result.append(record)
    for ident in stale:
        _REGISTRY.pop(ident, None)
    return tuple(result)


def cleanup_since(checkpoint: frozenset[int] | set[int] | tuple[int, ...]) -> int:
    """Remove exact current-generation records created after *checkpoint*."""
    keep = set(checkpoint or ())
    removed = 0
    for data, token, _record_kind, remover in reversed(tracked_records()):
        ident = id(data)
        if ident in keep or not matches(data, token):
            continue
        try:
            if callable(remover):
                remover(data)
                removed += 1
            untrack(data, token)
        except Exception:
            continue
    return removed

def cleanup_tracked(*, kind: str | None = None) -> int:
    removed = 0
    for data, token, record_kind, remover in reversed(tracked_records(kind=kind)):
        if not matches(data, token):
            continue
        try:
            if callable(remover):
                remover(data)
                removed += 1
            untrack(data, token)
        except Exception:
            continue
    return removed


def clear_registry() -> None:
    _release_data_leases()
    _REGISTRY.clear()
    _release_load_pre_handler()


def snapshot() -> tuple[dict[str, Any], ...]:
    return tuple({"identity": id(data), "kind": kind, "owner_uuid": token.owner_uuid,
                  "generation_uuid": token.generation_uuid, "session_uuid": token.session_uuid,
                  "matches": matches(data, token)}
                 for data, token, kind, _remover in tracked_records())
