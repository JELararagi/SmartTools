# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bounded UI-facing diagnostic state; never prints to the process console.

Registration failures are captured as tagged, one-shot degraded-state entries.
This keeps Blender's add-on enable transaction alive in restricted startup
contexts while avoiding repeated console warnings or tracebacks.
"""
from __future__ import annotations
from collections import deque
from typing import Any

_MAX_ERRORS = 32
_ERRORS: deque[dict[str, str]] = deque(maxlen=_MAX_ERRORS)
_MAX_TAGS = 128
_ONCE_TAGS: set[str] = set()
_ONCE_ORDER: deque[str] = deque()


def _entry(scope: str, error: BaseException | str, severity: str = "ERROR") -> dict[str, str]:
    return {
        "scope": str(scope or "runtime")[:160],
        "message": str(error or "unknown error")[:1024],
        "severity": str(severity or "ERROR").upper()[:16],
    }


def record(scope: str, error: BaseException | str) -> None:
    _ERRORS.append(_entry(scope, error, "ERROR"))


def warn_once(tag: str, error: BaseException | str) -> bool:
    """Record one bounded degraded-registration warning for *tag*.

    Nothing is printed and no Python warning is emitted.  The return value is
    true only for the first record, allowing callers to update UI state once.
    """
    normalized = str(tag or "registration").strip()[:160] or "registration"
    if normalized in _ONCE_TAGS:
        return False
    while len(_ONCE_ORDER) >= _MAX_TAGS:
        expired = _ONCE_ORDER.popleft()
        _ONCE_TAGS.discard(expired)
    _ONCE_TAGS.add(normalized)
    _ONCE_ORDER.append(normalized)
    _ERRORS.append(_entry(f"DEGRADED:{normalized}", error, "WARNING"))
    return True


def clear() -> None:
    _ERRORS.clear()
    _ONCE_TAGS.clear()
    _ONCE_ORDER.clear()


def snapshot() -> tuple[dict[str, str], ...]:
    return tuple(dict(item) for item in _ERRORS)


def warning_tags() -> tuple[str, ...]:
    return tuple(sorted(_ONCE_TAGS))
