# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Bounded diagnostics read by the Sculpt Suite interface."""
from collections import OrderedDict, deque

_MAX_ERRORS = 32
_MAX_TAGS = 128
_ERRORS = deque(maxlen=_MAX_ERRORS)
_WARNING_TAGS = OrderedDict()


def _entry(scope, error, severity="ERROR"):
    fields = (("scope", scope, "runtime", 160), ("message", error, "unknown error", 1024))
    row = {field: str(value or fallback)[:limit] for field, value, fallback, limit in fields}
    row["severity"] = str(severity or "ERROR").upper()[:16]
    return row


def record(scope, error):
    _ERRORS.append(_entry(scope, error))


def warn_once(tag, error):
    tag = str(tag or "").strip()[:160] or "registration"
    if tag in _WARNING_TAGS:
        return False
    if len(_WARNING_TAGS) == _MAX_TAGS:
        _WARNING_TAGS.popitem(last=False)
    _WARNING_TAGS[tag] = None
    _ERRORS.append(_entry("DEGRADED:" + tag, error, "WARNING"))
    return True


def clear():
    _ERRORS.clear()
    _WARNING_TAGS.clear()


def snapshot():
    return tuple(row.copy() for row in _ERRORS)


def warning_tags():
    return tuple(sorted(_WARNING_TAGS))
