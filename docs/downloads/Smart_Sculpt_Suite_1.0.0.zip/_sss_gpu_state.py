# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Immutable draw packets and exact GPU-state preservation.

All shader lookup, GPU batch construction, texture lookup, geometry conversion
and RNA reads are performed by the packet builders outside Blender draw
callbacks.  A production draw callback only retrieves an already completed
packet and calls :meth:`ImmutableDrawPacket.replay`.
"""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Sequence
from . import _sss_lifecycle as _lifecycle

try:
    import gpu as _gpu
except Exception:
    _gpu = None
try:
    import blf as _blf
except Exception:
    _blf = None
try:
    from gpu_extras.batch import batch_for_shader as _batch_for_shader
except Exception:
    _batch_for_shader = None
try:
    from gpu_extras.presets import draw_texture_2d as _draw_texture_2d
except Exception:
    _draw_texture_2d = None

_GET_SET = (
    ("blend_get", "blend_set"),
    ("depth_test_get", "depth_test_set"),
    ("face_culling_get", "face_culling_set"),
    ("front_facing_get", "front_facing_set"),
    ("line_width_get", "line_width_set"),
    ("point_size_get", "point_size_set"),
    ("program_point_size_get", "program_point_size_set"),
    ("scissor_test_get", "scissor_test_set"),
    ("scissor_get", "scissor_set"),
    ("viewport_get", "viewport_set"),
    ("depth_mask_get", "depth_mask_set"),
    ("color_mask_get", "color_mask_set"),
    ("depth_range_get", "depth_range_set"),
    ("line_smooth_get", "line_smooth_set"),
    ("polygon_offset_get", "polygon_offset_set"),
)

def _state_pairs(state: Any) -> tuple[tuple[str, str], ...]:
    """Return every zero-argument GPU getter with a matching setter.

    The explicit sequence preserves a stable restore order across Blender GPU
    backends.  Additional backend state added by Blender is included when it
    follows the public ``*_get``/``*_set`` convention.
    """
    pairs = list(_GET_SET)
    seen = set(pairs)
    try:
        names = tuple(sorted(str(name) for name in dir(state)))
    except Exception:
        names = ()
    for getter_name in names:
        if not getter_name.endswith("_get"):
            continue
        setter_name = f"{getter_name[:-4]}_set"
        pair = (getter_name, setter_name)
        if pair in seen:
            continue
        if callable(getattr(state, getter_name, None)) and callable(getattr(state, setter_name, None)):
            seen.add(pair)
            pairs.append(pair)
    return tuple(pairs)

def capture(state: Any) -> tuple[tuple[Callable[..., Any], Any], ...]:
    values: list[tuple[Callable[..., Any], Any]] = []
    for getter_name, setter_name in _state_pairs(state):
        getter = getattr(state, getter_name, None)
        setter = getattr(state, setter_name, None)
        if not (callable(getter) and callable(setter)):
            continue
        try:
            value = getter()
            if isinstance(value, list):
                value = tuple(value)
            values.append((setter, value))
        except Exception:
            continue
    return tuple(values)

def restore(values: Iterable[tuple[Callable[..., Any], Any]]) -> None:
    for setter, value in reversed(tuple(values)):
        try:
            if isinstance(value, (tuple, list)):
                setter(*tuple(value))
            else:
                setter(value)
        except Exception:
            # A state field unsupported by the running GPU backend must not
            # prevent restoration of the remaining fields.
            continue

@contextmanager
def preserved_gpu_state(state: Any | None = None):
    if state is None:
        state = getattr(_gpu, 'state', None) if _gpu is not None else None
    saved = capture(state) if state is not None else ()
    try:
        yield
    finally:
        restore(saved)

@dataclass(frozen=True, slots=True)
class DrawCommand:
    callable: Callable[..., Any]
    args: tuple[Any, ...] = ()
    kwargs_items: tuple[tuple[str, Any], ...] = ()

    def replay(self) -> None:
        self.callable(*self.args, **dict(self.kwargs_items))

@dataclass(frozen=True, slots=True)
class ImmutableDrawPacket:
    generation_uuid: str
    commands: tuple[DrawCommand, ...]
    expected_viewport: tuple[int, int, int, int] | None = None

    def _viewport_matches(self, state: Any) -> bool:
        expected = self.expected_viewport
        if expected is None:
            return True
        getter = getattr(state, "viewport_get", None)
        if not callable(getter):
            return True
        try:
            current = tuple(int(round(float(v))) for v in getter())
            expected_i = tuple(int(round(float(v))) for v in expected)
            return current == expected_i
        except Exception:
            return True

    def replay(self) -> None:
        if self.generation_uuid and not _lifecycle.generation_is_current(self.generation_uuid):
            return
        state = getattr(_gpu, 'state', None) if _gpu is not None else None
        if state is not None and not self._viewport_matches(state):
            return
        with preserved_gpu_state(state):
            for command in self.commands:
                try:
                    command.replay()
                except Exception:
                    # Draw callbacks are intentionally silent; the exact GPU
                    # state is still restored by the surrounding context.
                    continue

EMPTY_PACKET = ImmutableDrawPacket("", ())

def replay_state_packet(state: Any) -> None:
    """Production draw callback body: data-only immutable packet replay."""
    if not isinstance(state, dict) or not bool(state.get("alive", False)):
        return
    packet = state.get("packet")
    if isinstance(packet, ImmutableDrawPacket):
        packet.replay()
        return
    packets = state.get("packets", ())
    if isinstance(packets, (tuple, list)):
        for candidate in tuple(packets):
            if isinstance(candidate, ImmutableDrawPacket):
                candidate.replay()


def _set_state_value(name: str, value: Any) -> None:
    state = getattr(_gpu, 'state', None) if _gpu is not None else None
    setter = getattr(state, name, None)
    if not callable(setter):
        return
    if isinstance(value, (tuple, list)):
        setter(*tuple(value))
    else:
        setter(value)


def _draw_uniform_batch(shader: Any, batch: Any, color: tuple[float, float, float, float],
                        blend: str | None, depth_test: str | None,
                        line_width: float | None, point_size: float | None) -> None:
    if blend is not None:
        _set_state_value("blend_set", blend)
    if depth_test is not None:
        _set_state_value("depth_test_set", depth_test)
    if line_width is not None:
        _set_state_value("line_width_set", float(line_width))
    if point_size is not None:
        _set_state_value("point_size_set", float(point_size))
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_text(font_id: int, text: str, x: float, y: float, size: int,
               color: tuple[float, float, float, float]) -> None:
    if _blf is None:
        return
    try:
        _blf.size(int(font_id), int(size))
    except TypeError:
        _blf.size(int(font_id), int(size), 72)
    if hasattr(_blf, "color"):
        _blf.color(int(font_id), *tuple(float(v) for v in color))
    _blf.position(int(font_id), float(x), float(y), 0.0)
    _blf.draw(int(font_id), str(text))


def _draw_texture(texture: Any, x: float, y: float, width: float, height: float) -> None:
    if _draw_texture_2d is not None:
        _draw_texture_2d(texture, (float(x), float(y)), float(width), float(height))


def build_packet(*,
                 primitives: Sequence[Mapping[str, Any]] = (),
                 texts: Sequence[Mapping[str, Any]] = (),
                 textures: Sequence[Mapping[str, Any]] = (),
                 expected_viewport: tuple[int, int, int, int] | None = None,
                 generation_uuid: str | None = None) -> ImmutableDrawPacket:
    """Build a finished immutable packet outside a draw callback.

    Primitive dictionaries accept ``mode``, ``coords``, ``color`` and optional
    ``indices``, ``blend``, ``depth_test``, ``line_width`` and ``point_size``.
    Text/texture dictionaries contain only immutable values and already-created
    GPU textures.
    """
    generation = str(generation_uuid if generation_uuid is not None else _lifecycle.active_generation())
    commands: list[DrawCommand] = []
    if primitives:
        try:
            if _gpu is None or _batch_for_shader is None:
                raise RuntimeError("GPU module unavailable")
            shader = _gpu.shader.from_builtin("UNIFORM_COLOR")
            for spec in tuple(primitives):
                coords = tuple(tuple(float(v) for v in point) for point in tuple(spec.get("coords", ())))
                if not coords:
                    continue
                mode = str(spec.get("mode", "LINES"))
                if mode == "LINE_LOOP" and spec.get("indices") is None and len(coords) >= 3:
                    # Vulkan has no line-loop primitive; close the outline explicitly.
                    mode = "LINE_STRIP"
                    coords = coords + (coords[0],)
                content: dict[str, Any] = {"pos": coords}
                indices = spec.get("indices")
                batch = _batch_for_shader(shader, mode, content, indices=indices) if indices is not None else _batch_for_shader(shader, mode, content)
                color_raw = tuple(spec.get("color", (1.0, 1.0, 1.0, 1.0)))
                color = tuple(float(v) for v in (color_raw + (1.0, 1.0, 1.0, 1.0))[:4])
                args = (
                    shader, batch, color,
                    spec.get("blend", "ALPHA"),
                    spec.get("depth_test"),
                    spec.get("line_width"),
                    spec.get("point_size"),
                )
                commands.append(DrawCommand(_draw_uniform_batch, args))
        except Exception:
            # Headless import/audit environments intentionally produce a packet
            # without GPU commands while preserving all data-side behavior.
            pass
    for spec in tuple(texts):
        try:
            text = str(spec.get("text", ""))
            if not text:
                continue
            color_raw = tuple(spec.get("color", (1.0, 1.0, 1.0, 1.0)))
            color = tuple(float(v) for v in (color_raw + (1.0, 1.0, 1.0, 1.0))[:4])
            args = (int(spec.get("font_id", 0)), text, float(spec.get("x", 0.0)),
                    float(spec.get("y", 0.0)), int(spec.get("size", 12)), color)
            commands.append(DrawCommand(_draw_text, args))
        except Exception:
            continue
    for spec in tuple(textures):
        texture = spec.get("texture")
        if texture is None:
            continue
        args = (texture, float(spec.get("x", 0.0)), float(spec.get("y", 0.0)),
                float(spec.get("width", 1.0)), float(spec.get("height", 1.0)))
        commands.append(DrawCommand(_draw_texture, args))
    viewport = tuple(int(round(float(v))) for v in expected_viewport) if expected_viewport is not None else None
    return ImmutableDrawPacket(generation, tuple(commands), viewport)
