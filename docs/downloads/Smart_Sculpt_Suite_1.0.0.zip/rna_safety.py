# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""RNA registration through the Sculpt Suite lifecycle owner."""
from bpy.types import PropertyGroup

from . import _sss_lifecycle as _lifecycle


def is_blender_exit_unregister_in_progress():
    return False


def is_property_group_class(cls):
    return isinstance(cls, type) and issubclass(cls, PropertyGroup)


def class_name(cls):
    return str(getattr(cls, "__name__", None) or "")


def existing_registered_class(cls):
    if isinstance(cls, type) and _lifecycle.class_registration_identity(cls)[0]:
        return cls
    return None


def class_is_registered(cls):
    return existing_registered_class(cls) is cls


def bind_module_class_reference(original, replacement):
    return original


def resolve_property_group_class(cls):
    return cls


registered_property_group_type = resolve_property_group_class


def rebind_deferred_property_group_types(cls):
    return None


def register_class(cls):
    return _lifecycle.register_class(cls)


def unregister_class(cls):
    return _lifecycle.unregister_class(cls)


def unregister_classes(classes):
    for cls in reversed(tuple(classes or ())):
        unregister_class(cls)


def register_property(owner, name, definition):
    return _lifecycle.set_rna_property(owner, name, definition)


def unregister_property(owner, name):
    return _lifecycle.remove_rna_property(owner, name)


set_rna_property = register_property
remove_rna_property = unregister_property
