# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

import importlib
import json
import sys
import math
from datetime import datetime
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Sequence

import bmesh
import bpy

from .. import _sss_ownership as _ownership

SNAPSHOT_COLLECTION_NAME = "SSS_Snapshots"
PROXY_COLLECTION_NAME = "SSS_ProxySessions"
HELPER_COLLECTION_NAME = "SSS_Helpers"
RECOVERY_COLLECTION_NAME = "SSS_Recovery"

ESSENTIAL_SCULPT_BRUSH_FILE = "essentials_brushes-mesh_sculpt.blend"
SCULPT_TOOL_ESSENTIAL_BRUSHES = {
    "DRAW": "Draw",
    "CLAY": "Clay",
    "CLAY_STRIPS": "Clay Strips",
    "SMOOTH": "Smooth",
    "GRAB": "Grab",
    "INFLATE": "Inflate/Deflate",
    "SCRAPE": "Scrape/Fill",
    "DRAW_SHARP": "Draw Sharp",
    "SNAKE_HOOK": "Snake Hook",
    "CLOTH": "Drag Cloth",
    "POSE": "Pose",
    "CREASE": "Crease Sharp",
}
# -----------------------------------------------------------------------------
# Blender UI icon compatibility helpers
# -----------------------------------------------------------------------------

_ICON_ENUM_CACHE: set[str] | None = None
_ICON_ALIASES = {
    # Blender 5.1 removed/renamed this old transform icon ID.  HAND is the
    # closest built-in icon for sculpt grab-style controls and exists in 5.1.
    "TRANSFORM_MOVE": "HAND",
}


def initialize_ui_icon_cache() -> None:
    """Build Blender's icon enum snapshot once during registration, never draw."""
    global _ICON_ENUM_CACHE
    identifiers: set[str] = set()
    try:
        layout_rna = getattr(getattr(bpy, "types", None), "UILayout", None)
        functions = getattr(getattr(layout_rna, "bl_rna", None), "functions", None)
        operator_fn = functions["operator"] if functions is not None else None
        parameters = getattr(operator_fn, "parameters", None)
        icon_param = parameters["icon"] if parameters is not None else None
        enum_items = getattr(icon_param, "enum_items", ()) or ()
        for item in enum_items:
            identifier = str(getattr(item, "identifier", "") or "").strip()
            if identifier:
                identifiers.add(identifier)
    except Exception:
        identifiers = set()
    _ICON_ENUM_CACHE = identifiers


def clear_ui_icon_cache() -> None:
    global _ICON_ENUM_CACHE
    _ICON_ENUM_CACHE = None


def _ui_icon_enum_identifiers() -> set[str]:
    # Hot draw paths are read-only.  Registration owns cache creation.
    return _ICON_ENUM_CACHE if _ICON_ENUM_CACHE is not None else set()


def safe_icon(icon: str | None, fallback: str = "NONE") -> str:
    """Return an icon ID that is valid for the running Blender UI enum.

    Blender changes some icon identifiers between releases.  Passing an unknown
    identifier to UILayout.operator()/label() raises during panel draw and can
    destabilize the 3D View N-panel.  This helper keeps icon use defensive while
    leaving valid theme/UI behavior untouched.
    """
    value = str(icon or "").strip()
    fallback_value = str(fallback or "NONE").strip() or "NONE"
    if not value:
        value = fallback_value
    value = _ICON_ALIASES.get(value, value)
    fallback_value = _ICON_ALIASES.get(fallback_value, fallback_value)
    identifiers = _ui_icon_enum_identifiers()
    if identifiers:
        if value in identifiers:
            return value
        if fallback_value in identifiers:
            return fallback_value
        if "NONE" in identifiers:
            return "NONE"
    return value if value else fallback_value




# -----------------------------------------------------------------------------
# Context / selection / mode helpers
# -----------------------------------------------------------------------------


def addon_id_candidates() -> list[str]:
    candidates: list[str] = []
    package_name = str(__package__ or "").strip()
    root_package = package_name.rsplit('.core', 1)[0] if '.core' in package_name else ''
    leaf_name = package_name.split(".")[-1] if package_name else ""
    module_name = Path(__file__).resolve().parent.name
    for candidate in (root_package, package_name, leaf_name, module_name, "core"):
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    return candidates



def addon_module():
    """Return the already-loaded package root without import or module scanning."""
    package_name = str(__package__ or "").strip()
    root_package = package_name.rsplit(".core", 1)[0] if ".core" in package_name else package_name
    return sys.modules.get(root_package) if root_package else None



def addon_version_tuple() -> tuple[int, ...]:
    module = addon_module()
    bl_info = getattr(module, "bl_info", None) if module is not None else None
    if bl_info is None and module is not None and module.__name__.startswith("bl_ext."):
        # Blender removes extension bl_info on enable and loads manifest metadata on demand.
        from addon_utils import module_bl_info

        bl_info = module_bl_info(module)
    version = getattr(bl_info, 'get', lambda _k, _d=None: _d)("version", ()) if bl_info is not None else ()
    if isinstance(version, tuple) and all(isinstance(value, int) for value in version):
        return version
    return ()



def addon_version_string() -> str:
    version = addon_version_tuple()
    return ".".join(str(value) for value in version) if version else "unknown"


def addon_prefs(context: bpy.types.Context | None = None):
    ctx = context or bpy.context

    package_name = str(__package__ or '').strip()
    root_package = package_name.rsplit('.core', 1)[0] if '.core' in package_name else ''
    if not root_package:
        return None
    prefs_module = sys.modules.get(f'{root_package}.preferences')
    if prefs_module is None:
        return None
    try:
        root_prefs = getattr(prefs_module, 'root_preferences', lambda context=None: None)(ctx)
    except Exception:
        root_prefs = None
    if root_prefs is None:
        return None
    try:
        if hasattr(root_prefs, 'core_prefs'):
            return getattr(root_prefs, 'core_prefs')
    except Exception:
        pass
    return root_prefs



def settings_from_context(context: bpy.types.Context):
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    return getattr(scene, "core", None) if scene is not None else None



def _rna_pointer_is_valid(value: Any) -> bool:
    """Return True when a Blender RNA object can still be safely queried."""
    if value is None:
        return False
    try:
        pointer = int(value.as_pointer())
    except Exception:
        return True
    return pointer != 0


def _mesh_data_is_valid(obj: Any) -> bool:
    try:
        if obj is None or not _rna_pointer_is_valid(obj):
            return False
        if getattr(obj, 'type', None) != 'MESH':
            return False
        mesh = getattr(obj, 'data', None)
        return mesh is not None and _rna_pointer_is_valid(mesh)
    except Exception:
        return False


def active_mesh_object(context: bpy.types.Context) -> bpy.types.Object | None:
    """Return the active mesh object without assuming all context members exist.

    Blender can redraw N-panels while object/mode state is changing.  Chained
    context lookups such as ``context.view_layer.objects.active`` are therefore
    kept behind small try blocks so a transient empty or invalid context cannot
    escape from panel drawing code.
    """
    if context is None:
        return None

    candidates = []
    for getter in (
        lambda: getattr(context, 'sculpt_object', None),
        lambda: getattr(getattr(getattr(context, 'view_layer', None), 'objects', None), 'active', None),
        lambda: getattr(context, 'object', None),
        lambda: getattr(context, 'active_object', None),
    ):
        try:
            obj = getter()
        except Exception:
            obj = None
        if obj is not None and obj not in candidates:
            candidates.append(obj)

    for obj in candidates:
        if _mesh_data_is_valid(obj):
            return obj
    return None



def selected_mesh_objects(context: bpy.types.Context, editable_only: bool = False) -> list[bpy.types.Object]:
    result = []
    for obj in getattr(context, "selected_objects", []):
        if not obj or obj.type != 'MESH':
            continue
        if editable_only and (obj.library or obj.data.library):
            continue
        result.append(obj)
    return result



def related_armature(obj: bpy.types.Object | None):
    if obj is None:
        return None
    for modifier in getattr(obj, "modifiers", []):
        if modifier.type == 'ARMATURE' and modifier.object and modifier.object.type == 'ARMATURE':
            return modifier.object
    return None



def set_attr_if_exists(target: Any, name: str, value: Any) -> bool:
    if target is None or not hasattr(target, name):
        return False
    try:
        setattr(target, name, value)
        return True
    except Exception:
        return False



def safe_report(operator: bpy.types.Operator, level: str, message: str) -> None:
    try:
        operator.report({level}, message)
    except Exception:
        pass



def deselect_all_safe(context: bpy.types.Context | None = None) -> None:
    ctx = context or bpy.context
    view_layer = getattr(ctx, 'view_layer', None)
    deselected = False
    if view_layer is not None:
        try:
            for item in list(getattr(view_layer, 'objects', [])):
                try:
                    item.select_set(False)
                    deselected = True
                except Exception:
                    continue
        except Exception:
            deselected = False
    if deselected:
        return
    try:
        safe_operator_call(bpy.ops.object.select_all, [{'action': 'DESELECT'}])
    except Exception:
        pass



def make_active(context: bpy.types.Context, obj: bpy.types.Object | None, *, keep_existing_selection: bool = False) -> bool:
    if obj is None:
        return False
    if not keep_existing_selection:
        deselect_all_safe(context)
    try:
        obj.hide_set(False)
    except Exception:
        pass
    try:
        obj.hide_viewport = False
    except Exception:
        pass
    try:
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return True
    except Exception:
        return False



def select_only(context: bpy.types.Context, objects: Iterable[bpy.types.Object], active: bpy.types.Object | None = None) -> None:
    deselect_all_safe(context)
    active_obj = active
    for obj in objects:
        try:
            obj.hide_set(False)
        except Exception:
            pass
        try:
            obj.hide_viewport = False
        except Exception:
            pass
        try:
            obj.select_set(True)
        except Exception:
            pass
        if active_obj is None:
            active_obj = obj
    if active_obj is not None:
        try:
            context.view_layer.objects.active = active_obj
        except Exception:
            pass



def ensure_mode(context: bpy.types.Context, mode: str, obj: bpy.types.Object | None = None) -> bool:
    obj = obj or active_mesh_object(context)
    if obj is None:
        return False
    try:
        try:
            obj.hide_set(False)
        except Exception:
            pass
        try:
            obj.hide_viewport = False
        except Exception:
            pass
        deselect_all_safe(context)
        if context.view_layer.objects.active != obj:
            context.view_layer.objects.active = obj
        obj.select_set(True)
        if getattr(obj, "mode", None) == mode:
            return True
        safe_operator_call(bpy.ops.object.mode_set, [{'mode': mode, 'toggle': False}, {'mode': mode}])
        if getattr(obj, "mode", None) == mode:
            return True
        deselect_all_safe(context)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        safe_operator_call(bpy.ops.object.mode_set, [{'mode': mode, 'toggle': False}, {'mode': mode}])
        return getattr(obj, "mode", None) == mode
    except Exception:
        return False



def ensure_object_mode(context: bpy.types.Context, obj: bpy.types.Object | None = None) -> bool:
    return ensure_mode(context, 'OBJECT', obj)



def ensure_sculpt_mode(context: bpy.types.Context, obj: bpy.types.Object | None = None) -> bool:
    return ensure_mode(context, 'SCULPT', obj)



def ensure_edit_mode(context: bpy.types.Context, obj: bpy.types.Object | None = None) -> bool:
    return ensure_mode(context, 'EDIT', obj)

def strict_edit_mode_sculpt_settings(context=None):
    """Return embedded Edit Mode Sculpt settings when they are registered on the scene."""
    ctx = context or getattr(bpy, 'context', None)
    try:
        scene = getattr(ctx, 'scene', None) if ctx is not None else getattr(bpy.context, 'scene', None)
        return getattr(scene, 'strict_edit_mode_sculpt_settings', None) if scene is not None else None
    except Exception:
        return None


def strict_edit_mode_sculpt_active(context=None) -> bool:
    """True when Smart Sculpt should route sculpt-like commands to Edit Mode Sculpt."""
    ctx = context or getattr(bpy, 'context', None)
    try:
        mode = str(getattr(ctx, 'mode', '') or '')
    except Exception:
        mode = ''
    if mode != 'EDIT_MESH':
        return False
    settings = strict_edit_mode_sculpt_settings(ctx)
    try:
        return bool(settings is not None and getattr(settings, 'enabled', False))
    except Exception:
        return False


def run_strict_edit_mode_operator(context, operator_tail: str, **properties) -> set[str]:
    """Run an embedded strict_edit_sculpt operator while preserving Mesh Edit Mode."""
    ctx = context or getattr(bpy, 'context', None)
    operator_tail = str(operator_tail or '').strip()
    if not operator_tail:
        return {'CANCELLED'}
    obj = active_mesh_object(ctx) if ctx is not None else None
    original_mode = getattr(obj, 'mode', '') if obj is not None else ''
    if obj is not None and original_mode != 'EDIT':
        ensure_edit_mode(ctx, obj)
    try:
        namespace = getattr(bpy.ops, 'strict_edit_sculpt', None)
        op = getattr(namespace, operator_tail, None) if namespace is not None else None
        if op is None:
            return {'CANCELLED'}
        result = op(**{str(k): v for k, v in properties.items() if str(k or '').strip()})
        return result if isinstance(result, set) else {'FINISHED'}
    except Exception:
        return {'CANCELLED'}
    finally:
        if obj is not None and original_mode == 'EDIT':
            ensure_edit_mode(ctx, obj)


def restore_mode_after_smart_operation(context, obj: bpy.types.Object | None, original_mode: str | None, *, auto_enter_sculpt: bool = False) -> bool:
    """Restore the mode expected by Smart Sculpt after object-mode helper operations.

    Mesh Edit Mode takes priority so the embedded Edit Mode Sculpt workflow stays
    the main path even when older Smart Sculpt settings request automatic Sculpt
    Mode entry.
    """
    if obj is None:
        return False
    mode = str(original_mode or '').upper()
    try:
        if mode in {'EDIT', 'EDIT_MESH'}:
            return ensure_edit_mode(context, obj)
        if mode == 'SCULPT' or bool(auto_enter_sculpt):
            return ensure_sculpt_mode(context, obj)
        return ensure_object_mode(context, obj)
    except Exception:
        return False


def set_strict_edit_mode_brush(context, tool: str) -> bool:
    settings = strict_edit_mode_sculpt_settings(context)
    if settings is None:
        return False
    tool = str(tool or '').strip().upper()
    aliases = {
        'CLAY_STRIPS': 'CLAY_STRIPS',
        'DRAW_SHARP': 'DRAW_SHARP',
        'CLOTH': 'CLOTH',
        'POSE': 'POSE',
        'SMOOTH': 'SMOOTH',
        'SCRAPE': 'SCRAPE',
        'CREASE': 'CREASE',
        'GRAB': 'GRAB',
        'DRAW': 'DRAW',
        'CLAY': 'CLAY',
        'INFLATE': 'INFLATE',
        'DEFLATE': 'DEFLATE',
        'PINCH': 'PINCH',
    }
    mapped = aliases.get(tool, tool)
    try:
        setattr(settings, 'brush_tool', mapped)
        return True
    except Exception:
        return False


def capture_selection_state(context: bpy.types.Context) -> dict[str, Any]:
    active = getattr(getattr(context, 'view_layer', None), 'objects', None)
    active_obj = active.active if active is not None else None
    return {
        'active_name': getattr(active_obj, 'name', ''),
        'selected_names': [obj.name for obj in getattr(context, 'selected_objects', []) if obj is not None],
        'mode': getattr(active_obj, 'mode', 'OBJECT') if active_obj is not None else 'OBJECT',
    }



def restore_selection_state(context: bpy.types.Context, state: dict[str, Any] | None) -> bool:
    if not isinstance(state, dict):
        return False
    selected_names = [str(name) for name in state.get('selected_names', []) if isinstance(name, str)]
    active_name = str(state.get('active_name', '') or '')
    desired_mode = str(state.get('mode', 'OBJECT') or 'OBJECT')
    selected_objects = [bpy.data.objects.get(name) for name in selected_names]
    selected_objects = [obj for obj in selected_objects if obj is not None]
    active_obj = bpy.data.objects.get(active_name) if active_name else None

    if selected_objects:
        select_only(context, selected_objects, active=active_obj if active_obj in selected_objects else selected_objects[0])
    elif active_obj is not None:
        make_active(context, active_obj, keep_existing_selection=False)
    else:
        deselect_all_safe(context)
        return True

    if active_obj is not None and active_obj.name in bpy.data.objects and desired_mode and desired_mode != 'OBJECT':
        try:
            ensure_mode(context, desired_mode, active_obj)
        except Exception:
            pass
    return True


@contextmanager
def preserved_selection_and_mode(context: bpy.types.Context, obj: bpy.types.Object | None = None, target_mode: str | None = None):
    selection_state = capture_selection_state(context)
    prev_active = context.view_layer.objects.active
    prev_selected = list(getattr(context, "selected_objects", []))

    touched_objects: dict[str, bpy.types.Object] = {}
    visibility_state: dict[str, dict[str, Any]] = {}

    def _remember_visibility(item: bpy.types.Object | None) -> None:
        if item is None or item.name in touched_objects:
            return
        touched_objects[item.name] = item
        visibility_state[item.name] = capture_object_visibility_state(item)

    _remember_visibility(prev_active)
    for item in prev_selected:
        _remember_visibility(item)
    _remember_visibility(obj)

    if obj is not None:
        make_active(context, obj, keep_existing_selection=False)
        if target_mode is not None:
            ensure_mode(context, target_mode, obj)
    try:
        yield
    finally:
        try:
            restore_selection_state(context, selection_state)
            for name, state in visibility_state.items():
                restore_object_visibility_state(bpy.data.objects.get(name), state)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Operator helpers / brush selection
# -----------------------------------------------------------------------------


def operator_from_path(op_path: str):
    current = bpy.ops
    for part in op_path.split('.'):
        current = getattr(current, part, None)
        if current is None:
            return None
    return current



def operator_exists(op_path: str) -> bool:
    return operator_from_path(op_path) is not None



def operator_result_succeeded(result: Any) -> bool:
    if result is None:
        return True
    try:
        values = {str(item) for item in result}
    except Exception:
        return bool(result)
    if not values:
        return False
    if 'CANCELLED' in values and not ({'FINISHED', 'RUNNING_MODAL'} & values):
        return False
    return True



def operator_result_error(operator_name: str, kwargs: dict[str, Any] | None, result: Any) -> RuntimeError:
    kwargs = kwargs or {}
    details = ", ".join(f"{key}={value!r}" for key, value in sorted(kwargs.items()))
    suffix = f" with ({details})" if details else ""
    return RuntimeError(f"Operator {operator_name}{suffix} returned {result!r}")



def _context_is_view3d_window(context: bpy.types.Context | None = None) -> bool:
    ctx = context or bpy.context
    area = getattr(ctx, 'area', None)
    region = getattr(ctx, 'region', None)
    return (
        area is not None
        and getattr(area, 'type', None) == 'VIEW_3D'
        and region is not None
        and getattr(region, 'type', None) == 'WINDOW'
    )


def _context_area_region_keys(context: bpy.types.Context | None = None) -> tuple[int | None, int | None]:
    ctx = context or bpy.context
    area = getattr(ctx, 'area', None)
    region = getattr(ctx, 'region', None)
    try:
        area_key = int(area.as_pointer()) if area is not None else None
    except Exception:
        area_key = None
    try:
        region_key = int(region.as_pointer()) if region is not None else None
    except Exception:
        region_key = None
    return area_key, region_key


def iter_view3d_overrides(context: bpy.types.Context | None = None):
    ctx = context or bpy.context
    wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
    if wm is None:
        return
    windows: list[Any] = []
    current_window = getattr(ctx, 'window', None)
    if current_window is not None:
        windows.append(current_window)
    same_scene_windows = []
    fallback_windows = []
    current_scene = getattr(ctx, 'scene', None)
    for window in getattr(wm, 'windows', []):
        if window is None or window in windows:
            continue
        if getattr(window, 'scene', None) == current_scene:
            same_scene_windows.append(window)
        else:
            fallback_windows.append(window)
    windows.extend(same_scene_windows)
    windows.extend(fallback_windows)

    current_area_key, current_region_key = _context_area_region_keys(ctx)
    seen = set()
    for window in windows:
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', []):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            regions = [region for region in getattr(area, 'regions', []) if getattr(region, 'type', None) == 'WINDOW']
            if not regions:
                continue
            region = regions[-1]
            try:
                area_key = int(area.as_pointer())
            except Exception:
                area_key = None
            try:
                region_key = int(region.as_pointer())
            except Exception:
                region_key = None
            if area_key == current_area_key and region_key == current_region_key:
                continue
            dedupe_key = (id(window), area_key, region_key)
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is None or getattr(space, 'type', None) != 'VIEW_3D':
                for candidate_space in getattr(area, 'spaces', []):
                    if getattr(candidate_space, 'type', None) == 'VIEW_3D':
                        space = candidate_space
                        break

            override = {
                'window': window,
                'screen': screen,
                'area': area,
                'region': region,
            }
            if space is not None and getattr(space, 'type', None) == 'VIEW_3D':
                override['space_data'] = space
                region_data = getattr(space, 'region_3d', None)
                if region_data is not None:
                    override['region_data'] = region_data
            yield override


def find_view3d_context(context: bpy.types.Context | None = None) -> tuple[dict[str, Any] | None, Any | None]:
    ctx = context or bpy.context
    if _context_is_view3d_window(ctx):
        override = {
            'window': getattr(ctx, 'window', None),
            'screen': getattr(ctx, 'screen', None),
            'area': getattr(ctx, 'area', None),
            'region': getattr(ctx, 'region', None),
        }
        space = getattr(ctx, 'space_data', None)
        if space is not None and getattr(space, 'type', None) == 'VIEW_3D':
            override['space_data'] = space
            region_data = getattr(ctx, 'region_data', None)
            if region_data is not None:
                override['region_data'] = region_data
            return override, space
    for override in iter_view3d_overrides(ctx) or ():
        return override, override.get('space_data')
    return None, None


def tag_redraw_area(area) -> None:
    if area is None:
        return
    try:
        area.tag_redraw()
        return
    except Exception:
        pass
    for region in getattr(area, 'regions', []):
        try:
            region.tag_redraw()
        except Exception:
            pass


def _call_operator_with_view3d_fallback(operator, kwargs: dict[str, Any], operator_name: str, *, try_view3d_fallback: bool):
    last_exc: Exception | None = None
    try:
        result = operator(**kwargs)
        if operator_result_succeeded(result):
            return result
        last_exc = operator_result_error(str(operator_name), kwargs, result)
    except Exception as exc:
        last_exc = exc

    if not try_view3d_fallback:
        if last_exc is not None:
            raise last_exc
        raise RuntimeError(f"Operator call failed without available context: {operator_name}")

    for override in iter_view3d_overrides() or ():
        try:
            with bpy.context.temp_override(**override):
                result = operator(**kwargs)
            if operator_result_succeeded(result):
                area = override.get('area')
                tag_redraw_area(area)
                return result
            last_exc = operator_result_error(str(operator_name), kwargs, result)
        except Exception as exc:
            last_exc = exc

    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"Operator call failed without available context: {operator_name}")


def call_operator_by_paths(op_paths: Sequence[str], kwargs_variants: Sequence[dict[str, Any]] | None = None):
    last_exc: Exception | None = None
    variants = list(kwargs_variants or [{}])
    try_view3d_fallback = not _context_is_view3d_window()
    for op_path in op_paths:
        operator = operator_from_path(op_path)
        if operator is None:
            continue
        for kwargs in variants:
            try:
                return _call_operator_with_view3d_fallback(operator, kwargs, op_path, try_view3d_fallback=try_view3d_fallback)
            except Exception as exc:
                last_exc = exc
    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"No operator available from paths: {', '.join(op_paths)}")



def safe_operator_call(operator, variants: Iterable[dict[str, Any]] | None = None):
    variants = list(variants or [{}])
    last_exc: Exception | None = None
    idname_py = getattr(operator, 'idname_py', None)
    operator_name = (idname_py() if callable(idname_py) else None) or getattr(operator, '__qualname__', None) or getattr(operator, '__name__', None) or str(operator)
    try_view3d_fallback = not _context_is_view3d_window()
    for kwargs in variants:
        try:
            return _call_operator_with_view3d_fallback(operator, kwargs, operator_name, try_view3d_fallback=try_view3d_fallback)
        except Exception as exc:
            last_exc = exc
    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"Operator call failed without available variants: {operator_name}")



def get_sculpt_settings(context: bpy.types.Context):
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    tool_settings = getattr(scene, "tool_settings", None) if scene is not None else None
    return getattr(tool_settings, "sculpt", None)



def get_active_brush(context: bpy.types.Context):
    sculpt = get_sculpt_settings(context)
    if sculpt is None:
        return None
    try:
        return getattr(sculpt, "brush", None)
    except Exception:
        return None



def sculpt_tool_id_of_brush(brush) -> str:
    if brush is None:
        return ""
    try:
        brush_type = str(getattr(brush, "sculpt_brush_type", "") or "").upper()
    except Exception:
        return ""
    # Scrape was merged into the Plane brush type; the quick tools keep the name SCRAPE.
    return "SCRAPE" if brush_type == "PLANE" else brush_type



def active_sculpt_tool_id(context: bpy.types.Context) -> str:
    return sculpt_tool_id_of_brush(get_active_brush(context))



def active_brush_name(context: bpy.types.Context) -> str:
    brush = get_active_brush(context)
    if brush is None:
        return ""
    try:
        return str(getattr(brush, "name", "") or "")
    except Exception:
        return ""



def brush_from_name(name: str | None):
    safe_name = str(name or "").strip()
    if not safe_name:
        return None
    try:
        return bpy.data.brushes.get(safe_name)
    except Exception:
        return None



def _activate_brush_asset(asset_library_type: str, relative_asset_identifier: str) -> bool:
    try:
        safe_operator_call(
            bpy.ops.brush.asset_activate,
            [{'asset_library_type': asset_library_type, 'relative_asset_identifier': relative_asset_identifier}],
        )
        return True
    except Exception:
        return False



def activate_sculpt_brush_by_name(context: bpy.types.Context, brush_name: str | None) -> bool:
    brush = brush_from_name(brush_name)
    if brush is None or get_sculpt_settings(context) is None:
        return False
    if get_active_brush(context) == brush:
        return True
    library = getattr(brush, "library", None)
    if library is None:
        _activate_brush_asset('LOCAL', f"Brush/{brush.name}")
    elif getattr(library, "name", "") == ESSENTIAL_SCULPT_BRUSH_FILE:
        _activate_brush_asset('ESSENTIALS', f"brushes/{ESSENTIAL_SCULPT_BRUSH_FILE}/Brush/{brush.name}")
    if get_active_brush(context) == brush:
        return True
    sculpt_tool = sculpt_tool_id_of_brush(brush)
    return bool(sculpt_tool) and select_sculpt_tool(context, sculpt_tool)



def brush_matches_sculpt_tool(context: bpy.types.Context, sculpt_tool: str) -> bool:
    current = active_sculpt_tool_id(context)
    return bool(current) and current == str(sculpt_tool or '').upper()



def tool_pipe_slot_attr(slot: int) -> str:
    slot_index = max(1, min(int(slot), 3))
    return f"tool_pipe_slot_{slot_index}"



def tool_pipe_slot_tool_attr(slot: int) -> str:
    slot_index = max(1, min(int(slot), 3))
    return f"tool_pipe_slot_{slot_index}_tool"



def tool_pipe_slot_name(settings, slot: int) -> str:
    if settings is None:
        return ""
    return str(getattr(settings, tool_pipe_slot_attr(slot), "") or "")



def tool_pipe_slot_tool(settings, slot: int) -> str:
    if settings is None:
        return ""
    return str(getattr(settings, tool_pipe_slot_tool_attr(slot), "") or "").upper()



def tool_pipe_slot_label(settings, slot: int) -> str:
    name = tool_pipe_slot_name(settings, slot)
    if name:
        return name
    tool = tool_pipe_slot_tool(settings, slot)
    if tool:
        return tool.replace('_', ' ').title()
    return ui_text('Slot {0}', 'スロット {0}').format(max(1, min(int(slot), 3)))



def clear_tool_pipe_slot(settings, slot: int) -> bool:
    if settings is None:
        return False
    attrs = [tool_pipe_slot_attr(slot), tool_pipe_slot_tool_attr(slot)]
    had_value = False
    try:
        for attr in attrs:
            if not hasattr(settings, attr):
                continue
            if str(getattr(settings, attr, "") or ""):
                had_value = True
            setattr(settings, attr, "")
        return had_value
    except Exception:
        return False


def store_tool_pipe_slot(settings, slot: int, brush_name: str | None, sculpt_tool: str | None) -> bool:
    if settings is None:
        return False
    try:
        setattr(settings, tool_pipe_slot_attr(slot), str(brush_name or ""))
        setattr(settings, tool_pipe_slot_tool_attr(slot), str(sculpt_tool or "").upper())
        return True
    except Exception:
        return False



def mesh_has_meaningful_topology(obj: bpy.types.Object | None, *, min_vertices: int = 3, min_faces: int = 1) -> bool:
    verts, _edges, faces = topology_signature(obj)
    return verts >= min_vertices and faces >= min_faces



def restore_recovery_if_invalid_topology(
    context: bpy.types.Context,
    obj: bpy.types.Object | None,
    *,
    min_vertices: int = 3,
    min_faces: int = 1,
) -> tuple[bool, str, tuple[int, int, int]]:
    counts = topology_signature(obj)
    if mesh_has_meaningful_topology(obj, min_vertices=min_vertices, min_faces=min_faces):
        return False, "", counts
    restored, reason = restore_recovery_backup_into_object(context, obj)
    return restored, reason, counts



def select_sculpt_tool(context: bpy.types.Context, sculpt_tool: str) -> bool:
    sculpt_tool = str(sculpt_tool or '').strip().upper()
    if not sculpt_tool:
        return False
    brush_name = SCULPT_TOOL_ESSENTIAL_BRUSHES.get(sculpt_tool)
    if brush_name:
        _activate_brush_asset('ESSENTIALS', f"brushes/{ESSENTIAL_SCULPT_BRUSH_FILE}/Brush/{brush_name}")
    return brush_matches_sculpt_tool(context, sculpt_tool)


# -----------------------------------------------------------------------------
# Data / collection helpers
# -----------------------------------------------------------------------------


def unique_name(base: str) -> str:
    existing = set(bpy.data.objects.keys()) | set(bpy.data.meshes.keys()) | set(bpy.data.collections.keys()) | set(bpy.data.textures.keys())
    if base not in existing:
        return base
    index = 1
    while f"{base}.{index:03d}" in existing:
        index += 1
    return f"{base}.{index:03d}"


FILENAME_SANITIZE_PATTERN = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_filename_component(name: str | None, fallback: str = "smart_sculpt") -> str:
    raw = str(name or fallback).strip()
    raw = FILENAME_SANITIZE_PATTERN.sub("_", raw)
    raw = raw.replace("\n", "_").replace("\r", "_").replace("\t", " ")
    raw = re.sub(r"\s+", " ", raw).strip(" ._")
    return raw or fallback


def collection_in_hierarchy(root: bpy.types.Collection | None, target: bpy.types.Collection | None, _visited: set[str] | None = None) -> bool:
    if root is None or target is None:
        return False
    if root == target:
        return True
    visited = _visited or set()
    if root.name in visited:
        return False
    visited.add(root.name)
    for child in getattr(root, 'children', []):
        if collection_in_hierarchy(child, target, visited):
            return True
    return False



def _native_remove_owned_id(data) -> None:
    """Remove one exact Blender ID; callers must verify ledger ownership first."""
    if data is None:
        return
    if isinstance(data, bpy.types.Object):
        bpy.data.objects.remove(data, do_unlink=True)
    elif isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
    elif isinstance(data, bpy.types.Curve):
        bpy.data.curves.remove(data)
    elif isinstance(data, bpy.types.Lattice):
        bpy.data.lattices.remove(data)
    elif isinstance(data, bpy.types.Armature):
        bpy.data.armatures.remove(data)
    elif isinstance(data, bpy.types.Texture):
        bpy.data.textures.remove(data)
    elif isinstance(data, bpy.types.Material):
        bpy.data.materials.remove(data)
    elif isinstance(data, bpy.types.Collection):
        bpy.data.collections.remove(data)


def _ownership_kind(id_data, kind: str) -> str:
    if isinstance(id_data, bpy.types.Object):
        prefix = 'object'
    elif isinstance(id_data, bpy.types.Collection):
        prefix = 'collection'
    elif isinstance(id_data, bpy.types.Texture):
        prefix = 'texture'
    elif isinstance(id_data, bpy.types.Material):
        prefix = 'material'
    else:
        prefix = 'data'
    return f"{prefix}:{str(kind or 'generated')}"


def mark_generated(id_data, kind: str):
    """Stamp and journal exact Suite ownership; legacy flags are metadata only."""
    if id_data is None:
        return None
    token = _ownership.new_token()
    record_kind = _ownership_kind(id_data, kind)
    if not _ownership.stamp(id_data, token):
        return None
    try:
        id_data['sss_generated'] = True
        id_data['sss_generated_kind'] = str(kind or 'generated')
    except Exception:
        pass
    if not _ownership.track(id_data, token, kind=record_kind, remover=_native_remove_owned_id):
        return None
    # Object data created/copied for this object receives the same exact token.
    if isinstance(id_data, bpy.types.Object):
        data = getattr(id_data, 'data', None)
        if data is not None and getattr(data, 'users', 0) <= 1 and _ownership.stamp(data, token):
            _ownership.track(data, token, kind=f"data:{str(kind or 'generated')}", remover=_native_remove_owned_id)
    return token


def generated_is_owned(id_data, kind: str | None = None) -> bool:
    token = _ownership.token_for(id_data)
    if token is None:
        return False
    if kind is None:
        return True
    expected = _ownership_kind(id_data, kind)
    return _ownership.token_for(id_data, kind=expected) is not None


def ensure_collection(name: str, *, hidden: bool = True, scene: bpy.types.Scene | None = None) -> bpy.types.Collection:
    try:
        target_scene = scene or getattr(bpy.context, 'scene', None)
    except Exception:
        target_scene = scene
    record_kind = f"collection:{str(name)}"
    collection = None
    for candidate, _token, kind, _remover in _ownership.tracked_records(kind=record_kind):
        if isinstance(candidate, bpy.types.Collection):
            collection = candidate
            break
    if collection is None:
        # A same-named foreign/user Collection is never adopted or modified.
        collection = bpy.data.collections.new(unique_name(str(name)))
        mark_generated(collection, str(name))
    if target_scene is not None and not collection_in_hierarchy(target_scene.collection, collection):
        try:
            target_scene.collection.children.link(collection)
        except Exception:
            pass
    try:
        collection.hide_render = True
        if hidden:
            collection.hide_viewport = True
    except Exception:
        pass
    return collection


def snapshot_collection(scene: bpy.types.Scene | None = None) -> bpy.types.Collection:
    return ensure_collection(SNAPSHOT_COLLECTION_NAME, hidden=True, scene=scene)


def proxy_collection(scene: bpy.types.Scene | None = None) -> bpy.types.Collection:
    return ensure_collection(PROXY_COLLECTION_NAME, hidden=False, scene=scene)


def helper_collection(scene: bpy.types.Scene | None = None) -> bpy.types.Collection:
    return ensure_collection(HELPER_COLLECTION_NAME, hidden=False, scene=scene)


def recovery_collection(scene: bpy.types.Scene | None = None) -> bpy.types.Collection:
    return ensure_collection(RECOVERY_COLLECTION_NAME, hidden=True, scene=scene)


def remove_orphan_data(data_block, *, require_owned: bool = False) -> None:
    if data_block is None:
        return
    if require_owned and not _ownership.is_tracked(data_block):
        return
    try:
        if getattr(data_block, 'users', 1) != 0:
            return
    except Exception:
        return
    try:
        _native_remove_owned_id(data_block)
        _ownership.untrack(data_block)
    except Exception:
        pass


def safe_delete_object(obj: bpy.types.Object | None, *, require_owned: bool = False) -> bool:
    if obj is None:
        return False
    try:
        if obj.name not in bpy.data.objects:
            return False
    except Exception:
        return False
    object_token = _ownership.token_for(obj) if require_owned else None
    if require_owned and object_token is None:
        return False
    data = getattr(obj, 'data', None)
    data_owned = _ownership.is_tracked(data) if data is not None else False
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return False
    if object_token is not None:
        _ownership.untrack(obj, object_token)
    remove_orphan_data(data, require_owned=require_owned and data_owned)
    return True

def _root_locale_module():
    """Return the fixed already-loaded translation module; never import from draw."""
    package = str(__package__ or '').strip()
    root = package.rsplit('.core', 1)[0] if '.core' in package else package.split('.', 1)[0]
    return sys.modules.get(f'{root}.translation') if root else None


def locale_is_japanese() -> bool:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return bool(mod.locale_is_japanese())
        except Exception:
            pass
    try:
        prefs = getattr(bpy.context, "preferences", None)
        view = getattr(prefs, "view", None) if prefs else None
        if view is not None:
            if not getattr(view, "use_translate_interface", True):
                return False
            language = str(getattr(view, "language", "DEFAULT") or "DEFAULT")
            language_upper = language.upper()
            if language_upper.startswith("JA") or language_upper in {"JAPANESE", "JA_JP"}:
                return True
            if language_upper not in {"DEFAULT", "DEFAULT_LANGUAGE"}:
                return False
        locale = getattr(bpy.app.translations, "locale", "") or ""
        return str(locale).lower().startswith("ja")
    except Exception:
        return False


def preferred_ui_language() -> str:
    return 'JAPANESE' if locale_is_japanese() else 'ENGLISH'


def ui_text(english: str, japanese: str) -> str:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.ui_text(english, japanese)
        except Exception:
            pass
    return japanese if locale_is_japanese() else english


_JAPANESE_TEXT_RE = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")


def contains_japanese_text(text: str | None) -> bool:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return bool(mod.contains_japanese_text(text))
        except Exception:
            pass
    return bool(_JAPANESE_TEXT_RE.search(str(text or "")))


def _first_japanese_index(text: str | None) -> int:
    match = _JAPANESE_TEXT_RE.search(str(text or ""))
    return match.start() if match else -1


def split_bilingual_text(text: str | None) -> tuple[str, str]:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.split_bilingual_text(text)
        except Exception:
            pass
    raw = str(text or "").strip()
    if not raw:
        return "", ""
    spaced = None
    for match in re.finditer(r"\s+/\s+", raw):
        if not contains_japanese_text(raw[:match.start()]) and contains_japanese_text(raw[match.end():]):
            spaced = match
    if spaced is not None:
        return raw[:spaced.start()].strip(), raw[spaced.end():].strip()
    best_fallback: tuple[str, str, int] | None = None
    for match in re.finditer(r"\s*/\s*", raw):
        english = raw[:match.start()].strip()
        japanese = raw[match.end():].strip()
        if not english or not japanese:
            continue
        if contains_japanese_text(english) or not contains_japanese_text(japanese):
            continue
        first_japanese = _first_japanese_index(japanese)
        if first_japanese < 0:
            continue
        if best_fallback is None:
            best_fallback = (english, japanese, first_japanese)
        if first_japanese <= 72:
            return english, japanese
    if best_fallback is not None:
        return best_fallback[0], best_fallback[1]
    if contains_japanese_text(raw):
        return "", raw
    return raw, ""


def canonicalize_text(text: str | None) -> str:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.canonicalize_text(text)
        except Exception:
            pass
    english, japanese = split_bilingual_text(text)
    if english and japanese:
        return english
    return str(text or "").strip()


def localize_bilingual_text(text: str | None, *, fallback_japanese: str | None = None) -> str:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.localize_bilingual_text(text, fallback_japanese=fallback_japanese)
        except Exception:
            pass
    english, japanese = split_bilingual_text(text)
    if not english and not japanese:
        return ""
    if not japanese:
        japanese = str(fallback_japanese or english)
    if not english:
        english = str(text or japanese)
    return ui_text(english, japanese)


def localize_bilingual_format(
    text: str | None,
    /,
    *args,
    fallback_japanese: str | None = None,
    **kwargs,
) -> str:
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.localize_bilingual_format(text, *args, fallback_japanese=fallback_japanese, **kwargs)
        except Exception:
            pass
    template = localize_bilingual_text(text, fallback_japanese=fallback_japanese)
    if not template:
        return ""
    try:
        return template.format(*args, **kwargs)
    except Exception:
        return template


def exception_ui_text(exc) -> str:
    """Return an exception as a short sentence in the active UI language."""
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.exception_ui_text(exc)
        except Exception:
            pass
    return str(exc or '')


_LAYOUT_TEXT_KWARGS = {"text", "heading", "placeholder"}
_POSITIONAL_TEXT_INDEXES = {
    "label": (0,),
    "operator": (1,),
    "menu": (1,),
    "popover": (1,),
    "prop": (2,),
    "prop_enum": (2,),
    "prop_menu_enum": (2,),
    "operator_menu_enum": (2,),
    "operator_enum": (2,),
}


def translate_registered_text(text: str | None) -> str:
    """Return one UI string in the active Blender interface language."""
    mod = _root_locale_module()
    if mod is not None:
        try:
            return mod.translate_registered_text(text)
        except Exception:
            pass
    value = localize_bilingual_text(text)
    if not value:
        return ""
    try:
        translated = bpy.app.translations.pgettext_iface(value)
        if translated:
            return str(translated)
    except Exception:
        pass
    return value


def _localize_layout_arg(value):
    if isinstance(value, str):
        return translate_registered_text(value)
    return value


class _LocalizedUILayout:
    """Proxy UILayout that localizes only text arguments and delegates everything else."""

    __slots__ = ("_layout",)

    def __init__(self, layout):
        object.__setattr__(self, "_layout", layout)

    def __getattr__(self, name):
        attr = getattr(object.__getattribute__(self, "_layout"), name)
        if not callable(attr):
            return attr

        def _wrapped(*args, **kwargs):
            if args:
                indexes = _POSITIONAL_TEXT_INDEXES.get(str(name), ())
                if indexes:
                    args = list(args)
                    for index in indexes:
                        if index < len(args):
                            args[index] = _localize_layout_arg(args[index])
                    args = tuple(args)
            if kwargs:
                kwargs = dict(kwargs)
                for key in _LAYOUT_TEXT_KWARGS:
                    if key in kwargs:
                        kwargs[key] = _localize_layout_arg(kwargs[key])
            result = attr(*args, **kwargs)
            return localized_layout(result)

        return _wrapped

    def __setattr__(self, name, value):
        setattr(object.__getattribute__(self, "_layout"), name, value)

    def __bool__(self):
        return bool(object.__getattribute__(self, "_layout"))


def _is_blender_ui_layout(value) -> bool:
    try:
        return isinstance(value, bpy.types.UILayout)
    except Exception:
        return value.__class__.__name__ == 'UILayout'


def localized_layout(layout):
    """Return Blender's native UILayout object unchanged.

    Older builds used a Python UILayout proxy to split bilingual strings at draw
    time.  On Blender 5.1, any proxy or injected layout object inside Panel.draw
    can contribute to hard crashes in the 3D View Sidebar.  The add-on now keeps
    the layout path native and relies on explicit ui_text() calls plus registered
    RNA translations.
    """
    try:
        if isinstance(layout, _LocalizedUILayout) or layout.__class__.__name__ == '_LocalizedUILayout':
            try:
                return object.__getattribute__(layout, "_layout")
            except Exception:
                return getattr(layout, "_layout", layout)
    except Exception:
        pass
    return layout


def normalize_class_texts(classes) -> None:
    mod = _root_locale_module()
    if mod is not None:
        try:
            mod.normalize_class_texts(classes)
        except Exception:
            pass


def register_runtime_translations() -> None:
    mod = _root_locale_module()
    if mod is not None:
        try:
            mod.register_translations()
        except Exception:
            pass


def _register_runtime_pair(english: str, japanese: str) -> None:
    mod = _root_locale_module()
    if mod is not None:
        try:
            mod.register_pair(english, japanese)
        except Exception:
            pass


def _registered_japanese(english: str) -> str:
    mod = _root_locale_module()
    if mod is None:
        return ""
    try:
        return str(mod.japanese_for_english(english) or "")
    except Exception:
        return ""


def beginner_property_description(
    text: str | None,
    *,
    how_to_en: str | None = None,
    how_to_ja: str | None = None,
) -> str:
    english, japanese = split_bilingual_text(text)
    if not english and not japanese:
        return ""
    if not english:
        english = canonicalize_text(text)
    if not japanese:
        japanese = english
    how_to_en = str(
        how_to_en
        or "Adjust this setting before running the related button so the tool behaves the way you expect."
    )
    how_to_ja = str(
        how_to_ja
        or "関連する実行ボタンを押す前にこの設定を調整すると、狙った結果に合わせやすくなります。"
    )
    english_text = f"{english}\nHow to use: {how_to_en}"
    japanese_text = f"{japanese}\n使い方: {how_to_ja}"
    _register_runtime_pair(english_text, japanese_text)
    return english_text


def beginner_enum_description(
    text: str | None,
    *,
    how_to_en: str | None = None,
    how_to_ja: str | None = None,
) -> str:
    english, japanese = split_bilingual_text(text)
    if not english and not japanese:
        return ""
    if not english:
        english = canonicalize_text(text)
    if not japanese:
        japanese = english
    how_to_en = str(
        how_to_en
        or "Select this choice in the list above, then run the matching action button in the same section."
    )
    how_to_ja = str(
        how_to_ja
        or "上の一覧やドロップダウンでこの項目を選び、同じセクション内の対応ボタンで実行します。"
    )
    english_text = f"{english}\nHow to use: {how_to_en}"
    japanese_text = f"{japanese}\n使い方: {how_to_ja}"
    _register_runtime_pair(english_text, japanese_text)
    return english_text


def _operator_tooltip_hint(bl_idname: str) -> tuple[str, str, str, str]:
    normalized = str(bl_idname or "").lower()

    if "export" in normalized:
        return (
            "Select the mesh or selection set you want to hand off, confirm the target format and folder, then click once to write the exchange file.",
            "受け渡したいメッシュまたは選択セットを決め、形式と保存先フォルダを確認してから 1 回クリックで受け渡しファイルを書き出します。",
            "This writes an external file for round-trip work. It does not replace the original object in the scene.",
            "これは往復作業用の外部ファイルを書き出す処理で、シーン内の元オブジェクトを置き換えるものではありません。",
        )
    if "import" in normalized:
        return (
            "Make sure the exchange folder contains the file you want, then click to bring the newest matching handoff back into the current scene.",
            "受け渡しフォルダに目的のファイルがあることを確認してからクリックすると、条件に合う最新ファイルを現在のシーンへ読み込みます。",
            "Imported helper objects that do not contain usable mesh data are cleaned up automatically whenever possible.",
            "使用できるメッシュを含まない読み込み補助オブジェクトは、可能な範囲で自動整理されます。",
        )
    if any(token in normalized for token in ("analyze", "report")):
        return (
            "Select the mesh you want to inspect, run the tool, then review the findings shown in the panel or generated report.",
            "調べたいメッシュを選択して実行し、パネルや生成レポートに出る検出結果を確認します。",
            "Analysis tools are meant to inspect data first. Use the repair buttons only after checking the findings.",
            "解析系ツールはまず状態確認を行うためのものです。修正ボタンは内容を確認してから使うと安全です。",
        )
    if any(token in normalized for token in ("snapshot", "recovery", "layer", "session", "proxy")):
        return (
            "Pick the mesh that owns the stored data, then use this button to save, restore, compare, or clear that non-destructive state.",
            "保存先または管理対象のメッシュを選び、このボタンで非破壊データの保存・復元・比較・整理を行います。",
            "These tools manage backup-style data and helper objects. Restoring or deleting entries can change what temporary data stays in the file.",
            "これらはバックアップ風データや補助オブジェクトを管理します。復元や削除を行うと、ファイル内に保持される一時データが変わる場合があります。",
        )
    if any(token in normalized for token in ("remesh", "quadriflow", "boolean", "extract", "slice", "fix", "cleanup", "delete", "clear", "close")):
        return (
            "Select the target mesh, check the options in this section, then run the action once and inspect the result immediately.",
            "対象メッシュを選び、このセクションの設定を確認してから 1 回実行し、結果をすぐに確認します。",
            "This action can change topology, remove helper data, or overwrite a previous state. Use Undo if the result is not what you expected.",
            "この操作はトポロジ変更、一時データ削除、既存状態の上書きを伴う場合があります。意図と違う結果になったら 元に戻す（Ctrl+Z）で戻してください。",
        )
    if any(token in normalized for token in ("prepare", "configure", "set_", "add_", "create", "cycle_", "store_", "use_", "toggle_")):
        return (
            "Set the target object or current selection first, then click once to build the helper, switch the tool, or apply the setup.",
            "先に対象オブジェクトや現在の選択を整え、その後 1 回クリックして補助要素の作成、ツール切替、設定適用を行います。",
            "Most setup tools are safe to test repeatedly, but they may add helper objects, modifiers, or new collections to the scene.",
            "多くのセットアップ系ツールは試しやすいですが、補助オブジェクトやモディファイア、新規コレクションを追加することがあります。",
        )
    return (
        "Select the mesh or objects this tool should affect, review the nearby options, then click once to run it.",
        "このツールの対象になるメッシュやオブジェクトを選択し、近くの設定を確認してから 1 回クリックで実行します。",
        "If the result is not what you wanted, use Undo and adjust the settings before trying again.",
        "狙った結果にならない場合は、元に戻す（Ctrl+Z）で戻して設定を調整してから再実行してください。",
    )


def _format_operator_tooltip(
    english: str,
    japanese: str,
    how_to_en: str,
    how_to_ja: str,
    note_en: str,
    note_ja: str,
) -> str:
    english = canonicalize_text(english)
    japanese = str(japanese or english).strip()
    lines_en = []
    lines_ja = []
    if english:
        lines_en.append(f"Purpose: {english}")
    if japanese:
        lines_ja.append(f"機能: {japanese}")
    if how_to_en:
        lines_en.append(f"How to use: {how_to_en}")
    if how_to_ja:
        lines_ja.append(f"使い方: {how_to_ja}")
    if note_en:
        lines_en.append(f"Good to know: {note_en}")
    if note_ja:
        lines_ja.append(f"補足: {note_ja}")
    english_text = "\n".join(lines_en)
    japanese_text = "\n".join(lines_ja)
    _register_runtime_pair(english_text, japanese_text)
    return english_text


def enhance_operator_descriptions(classes: Sequence[type]) -> None:
    for cls in classes:
        if not isinstance(cls, type):
            continue
        bl_idname = str(getattr(cls, "bl_idname", "") or "")
        if not bl_idname.startswith("smart_sculpt."):
            continue
        original = getattr(cls, "__sss_original_bl_description", None)
        if original is None:
            original = str(getattr(cls, "bl_description", "") or "")
            setattr(cls, "__sss_original_bl_description", original)

        if not original:
            original = str(getattr(cls, "bl_label", "") or "")
        english, japanese = split_bilingual_text(original)
        if not english:
            english = str(getattr(cls, "bl_label", "") or original or "")
        if not japanese:
            japanese = _registered_japanese(english) or english

        how_to_en, how_to_ja, note_en, note_ja = _operator_tooltip_hint(bl_idname)
        cls.bl_description = _format_operator_tooltip(
            english,
            japanese,
            how_to_en,
            how_to_ja,
            note_en,
            note_ja,
        )


def serialize_json_data(data: Any) -> str:
    try:
        return json.dumps(data, ensure_ascii=False)
    except Exception:
        return ""



def deserialize_json_data(raw: str | None, default: Any):
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default



def capture_object_visibility_state(obj: bpy.types.Object) -> dict[str, Any]:
    state = {
        "hide_get": False,
        "hide_viewport": False,
        "hide_render": False,
    }
    if obj is None:
        return state
    try:
        state["hide_get"] = bool(obj.hide_get())
    except Exception:
        pass
    try:
        state["hide_viewport"] = bool(obj.hide_viewport)
    except Exception:
        pass
    try:
        state["hide_render"] = bool(obj.hide_render)
    except Exception:
        pass
    return state



def capture_visibility_map(objects: Iterable[bpy.types.Object]) -> str:
    data = {}
    for obj in objects:
        if obj is None:
            continue
        data[obj.name] = capture_object_visibility_state(obj)
    return serialize_json_data(data)



def deserialize_visibility_map(raw: str | None) -> dict[str, dict[str, Any]]:
    data = deserialize_json_data(raw, {})
    return data if isinstance(data, dict) else {}



def restore_object_visibility_state(obj: bpy.types.Object, state: dict[str, Any] | None) -> bool:
    if obj is None or not isinstance(state, dict):
        return False
    restored = False
    if "hide_viewport" in state:
        try:
            obj.hide_viewport = bool(state["hide_viewport"])
            restored = True
        except Exception:
            pass
    if "hide_render" in state:
        try:
            obj.hide_render = bool(state["hide_render"])
            restored = True
        except Exception:
            pass
    if "hide_get" in state:
        try:
            obj.hide_set(bool(state["hide_get"]))
            restored = True
        except Exception:
            pass
    return restored


VIEW3D_SHADING_STATE_ATTRS = (
    "type",
    "light",
    "color_type",
    "single_color",
    "show_cavity",
    "show_shadows",
    "show_object_outline",
    "show_specular_highlight",
    "cavity_type",
)
VIEW3D_OVERLAY_STATE_ATTRS = (
    "show_overlays",
    "show_wireframes",
    "show_sculpt_face_sets",
    "show_face_sets",
    "show_sculpt_mask",
)



def _capture_struct_state(target: Any, names: Sequence[str]) -> dict[str, Any]:
    state: dict[str, Any] = {}
    if target is None:
        return state
    for name in names:
        if not hasattr(target, name):
            continue
        try:
            value = getattr(target, name)
            if name == "single_color":
                value = tuple(value)
            elif isinstance(value, (list, tuple)):
                value = tuple(value)
            state[name] = value
        except Exception:
            continue
    return state



def capture_view3d_state(space) -> dict[str, Any]:
    if space is None or getattr(space, "type", None) != 'VIEW_3D':
        return {}
    return {
        "shading": _capture_struct_state(getattr(space, "shading", None), VIEW3D_SHADING_STATE_ATTRS),
        "overlay": _capture_struct_state(getattr(space, "overlay", None), VIEW3D_OVERLAY_STATE_ATTRS),
    }



def restore_view3d_state(space, state: dict[str, Any] | None) -> bool:
    if space is None or getattr(space, "type", None) != 'VIEW_3D' or not isinstance(state, dict):
        return False
    shading = getattr(space, "shading", None)
    overlay = getattr(space, "overlay", None)
    restored = False

    shading_state = state.get("shading", {}) if isinstance(state.get("shading", {}), dict) else {}
    overlay_state = state.get("overlay", {}) if isinstance(state.get("overlay", {}), dict) else {}

    for name in ("type", "light", "color_type", "cavity_type"):
        if name in shading_state and set_attr_if_exists(shading, name, shading_state[name]):
            restored = True
    if "single_color" in shading_state and hasattr(shading, "single_color"):
        try:
            shading.single_color = tuple(shading_state["single_color"])
            restored = True
        except Exception:
            pass
    for name in VIEW3D_SHADING_STATE_ATTRS:
        if name in {"type", "light", "color_type", "single_color", "cavity_type"}:
            continue
        if name in shading_state and set_attr_if_exists(shading, name, shading_state[name]):
            restored = True
    for name in VIEW3D_OVERLAY_STATE_ATTRS:
        if name in overlay_state and set_attr_if_exists(overlay, name, overlay_state[name]):
            restored = True
    return restored



def view3d_state_storage(scene: bpy.types.Scene, key: str = "_sss_view3d_state_store") -> dict[str, Any]:
    raw = scene.get(key, "") if scene is not None else ""
    data = deserialize_json_data(raw, {})
    return data if isinstance(data, dict) else {}



def store_view3d_state(scene: bpy.types.Scene, space, state: dict[str, Any], key: str = "_sss_view3d_state_store") -> None:
    if scene is None or space is None:
        return
    store = view3d_state_storage(scene, key)
    store[str(space.as_pointer())] = state
    scene[key] = serialize_json_data(store)



def pop_view3d_state(scene: bpy.types.Scene, space, key: str = "_sss_view3d_state_store") -> dict[str, Any] | None:
    if scene is None or space is None:
        return None
    store = view3d_state_storage(scene, key)
    state = store.pop(str(space.as_pointer()), None)
    scene[key] = serialize_json_data(store)
    return state



_OBJECT_TRANSFORM_IDENTIFIERS = {
    "location",
    "rotation_euler",
    "rotation_quaternion",
    "rotation_axis_angle",
    "rotation_mode",
    "scale",
    "dimensions",
    "matrix_world",
    "matrix_local",
    "matrix_basis",
    "matrix_parent_inverse",
}


def capture_object_transform_state(obj: bpy.types.Object | None) -> dict[str, Any]:
    """Capture only transform fields that must never be changed by UI/save/load helpers."""
    if obj is None:
        return {}
    state: dict[str, Any] = {}
    for name in (
        "matrix_world",
        "matrix_basis",
        "matrix_parent_inverse",
        "location",
        "rotation_mode",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "scale",
    ):
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        try:
            state[name] = value.copy()
        except Exception:
            try:
                state[name] = tuple(value)
            except Exception:
                state[name] = value
    return state


def _transform_values_equal(current, stored) -> bool:
    try:
        current_cmp = tuple(current) if hasattr(current, '__iter__') and not isinstance(current, str) else current
        stored_cmp = tuple(stored) if hasattr(stored, '__iter__') and not isinstance(stored, str) else stored
        return current_cmp == stored_cmp
    except Exception:
        return False


def restore_object_transform_state(obj: bpy.types.Object | None, state: dict[str, Any]) -> bool:
    """Restore a previously captured transform without touching mesh data or custom properties."""
    if obj is None or not state:
        return False
    changed = False
    for name in (
        "rotation_mode",
        "matrix_parent_inverse",
        "matrix_basis",
        "matrix_world",
        "location",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "scale",
    ):
        if name not in state:
            continue
        value = state[name]
        try:
            current = getattr(obj, name)
        except Exception:
            continue
        if _transform_values_equal(current, value):
            continue
        try:
            setattr(obj, name, value)
            changed = True
        except Exception:
            continue
    return changed


def capture_scene_object_transforms(scene: bpy.types.Scene | None = None) -> dict[str, dict[str, Any]]:
    """Capture all current object transforms by name for save/load synchronization guards."""
    try:
        objects = list((scene.objects if scene is not None else bpy.data.objects) or [])
    except Exception:
        objects = list(getattr(bpy.data, 'objects', []) or [])
    out: dict[str, dict[str, Any]] = {}
    for obj in objects:
        try:
            name = str(getattr(obj, 'name', '') or '')
        except Exception:
            name = ''
        if not name:
            continue
        state = capture_object_transform_state(obj)
        if state:
            out[name] = state
    return out


def restore_scene_object_transforms(state_by_name: dict[str, dict[str, Any]], scene: bpy.types.Scene | None = None) -> int:
    if not state_by_name:
        return 0
    try:
        objects = {obj.name: obj for obj in ((scene.objects if scene is not None else bpy.data.objects) or [])}
    except Exception:
        objects = {obj.name: obj for obj in (getattr(bpy.data, 'objects', []) or [])}
    restored = 0
    for name, state in state_by_name.items():
        obj = objects.get(name) or bpy.data.objects.get(name)
        if obj is None:
            continue
        if restore_object_transform_state(obj, state):
            restored += 1
    return restored


def copy_writable_rna_properties(source, target, *, skip_identifiers: set[str] | None = None) -> None:
    skip = {"rna_type", "name", "type", "bl_rna"}
    if skip_identifiers:
        skip.update(skip_identifiers)
    props = getattr(getattr(source, "bl_rna", None), "properties", [])
    for prop in props:
        identifier = getattr(prop, "identifier", "")
        if not identifier or identifier in skip or getattr(prop, "is_readonly", False):
            continue
        if getattr(prop, "is_hidden", False):
            continue
        try:
            value = getattr(source, identifier)
        except Exception:
            continue
        try:
            if getattr(prop, "is_array", False):
                value = tuple(value)
            setattr(target, identifier, value)
        except Exception:
            continue


def restore_modifiers_from_object(target_obj: bpy.types.Object, source_obj: bpy.types.Object) -> None:
    try:
        for mod in reversed(list(target_obj.modifiers)):
            target_obj.modifiers.remove(mod)
    except Exception:
        pass

    for source_mod in source_obj.modifiers:
        try:
            new_mod = target_obj.modifiers.new(name=source_mod.name, type=source_mod.type)
        except Exception:
            continue
        copy_writable_rna_properties(source_mod, new_mod)
        # Retry a few pointer-like targets after basic properties have been copied.
        for attr in (
            "object", "target", "origin", "mirror_object", "offset_object",
            "texture", "start_cap", "end_cap", "vertex_group", "uv_layer", "node_group",
        ):
            if hasattr(source_mod, attr) and hasattr(new_mod, attr):
                try:
                    setattr(new_mod, attr, getattr(source_mod, attr))
                except Exception:
                    pass


def restore_vertex_groups_from_object(target_obj: bpy.types.Object, source_obj: bpy.types.Object) -> None:
    if target_obj is None or source_obj is None:
        return
    target_groups = getattr(target_obj, "vertex_groups", None)
    source_groups = getattr(source_obj, "vertex_groups", None)
    if target_groups is None or source_groups is None:
        return
    try:
        for group in reversed(list(target_groups)):
            target_groups.remove(group)
    except Exception:
        pass
    created_groups = []
    for source_group in source_groups:
        try:
            new_group = target_groups.new(name=source_group.name)
        except Exception:
            continue
        try:
            new_group.lock_weight = bool(getattr(source_group, "lock_weight", False))
        except Exception:
            pass
        created_groups.append(new_group)
    source_mesh = getattr(source_obj, "data", None)
    target_mesh = getattr(target_obj, "data", None)
    if source_mesh is None or target_mesh is None:
        return
    max_vertices = min(len(getattr(source_mesh, "vertices", [])), len(getattr(target_mesh, "vertices", [])))
    if max_vertices <= 0 or not created_groups:
        return
    for vertex_index in range(max_vertices):
        try:
            source_vertex = source_mesh.vertices[vertex_index]
        except Exception:
            continue
        for assignment in getattr(source_vertex, "groups", []):
            group_index = int(getattr(assignment, "group", -1))
            if group_index < 0 or group_index >= len(created_groups):
                continue
            try:
                created_groups[group_index].add([vertex_index], float(getattr(assignment, "weight", 0.0)), 'REPLACE')
            except Exception:
                continue

def restore_object_display_settings(target_obj: bpy.types.Object, source_obj: bpy.types.Object) -> None:
    preserved_transform = capture_object_transform_state(target_obj)
    copy_writable_rna_properties(
        source_obj,
        target_obj,
        skip_identifiers={
            "data",
            "parent",
            "children",
            "users_collection",
            "users_scene",
            "users",
            "instance_collection",
            "hide_viewport",
            "hide_render",
            "hide_select",
            "show_name",
            "show_axis",
            *_OBJECT_TRANSFORM_IDENTIFIERS,
        },
    )
    restore_object_transform_state(target_obj, preserved_transform)

def write_text_block(name: str, body: str):
    text_block = bpy.data.texts.get(name)
    if text_block is None:
        text_block = bpy.data.texts.new(name)
    else:
        text_block.clear()
    text_block.write(body)
    return text_block



def duplicate_object_data(obj: bpy.types.Object, collection: bpy.types.Collection, name: str | None = None, kind: str | None = None) -> bpy.types.Object:
    duplicate = obj.copy()
    if getattr(obj, "data", None) is not None:
        duplicate.data = obj.data.copy()
    duplicate.animation_data_clear()
    duplicate.name = unique_name(name or f"{obj.name}_copy")
    collection.objects.link(duplicate)
    if kind:
        mark_generated(duplicate, kind)
    return duplicate



def evaluated_mesh_copy(context: bpy.types.Context, obj: bpy.types.Object, collection: bpy.types.Collection, name: str | None = None, kind: str | None = None) -> bpy.types.Object:
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = bpy.data.meshes.new_from_object(eval_obj, preserve_all_data_layers=True, depsgraph=depsgraph)
    new_obj = bpy.data.objects.new(unique_name(name or f"{obj.name}_eval"), mesh)
    new_obj.matrix_world = obj.matrix_world.copy()
    collection.objects.link(new_obj)
    if kind:
        mark_generated(new_obj, kind)
    return new_obj



def ensure_single_user_mesh(obj: bpy.types.Object) -> None:
    if obj and obj.type == 'MESH' and obj.data and obj.data.users > 1:
        obj.data = obj.data.copy()



def duplicate_for_safety(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    suffix: str,
    *,
    protect_shape_keys: bool = True,
    protect_multires: bool = False,
    protect_shared: bool = True,
) -> tuple[bpy.types.Object, bool]:
    prefs = addon_prefs(context)
    if prefs and not getattr(prefs, "auto_duplicate_destructive", True):
        ensure_single_user_mesh(obj)
        return obj, False

    has_shape_keys = bool(getattr(obj.data, "shape_keys", None) and len(obj.data.shape_keys.key_blocks) > 1)
    has_multires = bool(find_multires_modifier(obj))
    is_shared = bool(obj.data.users > 1)
    need_duplicate = (protect_shape_keys and has_shape_keys) or (protect_multires and has_multires) or (protect_shared and is_shared)
    if not need_duplicate:
        ensure_single_user_mesh(obj)
        return obj, False

    collection = context.collection or context.scene.collection
    duplicate = duplicate_object_data(obj, collection, name=f"{obj.name}_{suffix}", kind='derived')
    make_active(context, duplicate)
    return duplicate, True


# -----------------------------------------------------------------------------
# Diagnostics / mesh analysis
# -----------------------------------------------------------------------------


def clear_diagnostics(settings) -> None:
    if settings is not None:
        settings.diagnostics.clear()



def add_diagnostic(settings, severity: str, title: str, detail: str = "") -> None:
    if settings is None:
        return
    item = settings.diagnostics.add()
    item.severity = severity
    item.title = title
    item.detail = detail



def topology_signature(obj: bpy.types.Object | None) -> tuple[int, int, int]:
    try:
        if obj is None or not _mesh_data_is_valid(obj):
            return (0, 0, 0)
        mesh = getattr(obj, 'data', None)
        if mesh is None or not _rna_pointer_is_valid(mesh):
            return (0, 0, 0)
        return (
            len(getattr(mesh, 'vertices', ()) or ()),
            len(getattr(mesh, 'edges', ()) or ()),
            len(getattr(mesh, 'polygons', ()) or ()),
        )
    except Exception:
        return (0, 0, 0)



def validate_mesh_copy(obj: bpy.types.Object) -> bool:
    mesh_copy = obj.data.copy()
    try:
        changed = mesh_copy.validate(verbose=False, clean_customdata=False)
        return bool(changed)
    finally:
        remove_orphan_data(mesh_copy)



def mesh_data_layer_info(mesh) -> dict[str, Any]:
    uv_layers = getattr(mesh, "uv_layers", None)
    color_attributes = getattr(mesh, "color_attributes", None)
    attributes = getattr(mesh, "attributes", None)

    try:
        uv_count = len(uv_layers) if uv_layers is not None else 0
    except Exception:
        uv_count = 0
    try:
        color_count = len(color_attributes) if color_attributes is not None else 0
    except Exception:
        color_count = 0

    attribute_names: list[str] = []
    if attributes is not None:
        try:
            attribute_names = [str(attr.name) for attr in attributes]
        except Exception:
            attribute_names = []

    has_face_sets = any("face_set" in name.lower() for name in attribute_names)
    return {
        "uv_count": uv_count,
        "color_count": color_count,
        "attribute_names": attribute_names,
        "has_face_sets": has_face_sets,
    }



def analyze_bmesh_issues(obj: bpy.types.Object, max_polys: int = 1_500_000) -> dict[str, int | None]:
    mesh = obj.data
    if len(mesh.polygons) > max_polys:
        return {
            "loose_verts": None,
            "loose_edges": None,
            "loose_faces": None,
            "non_manifold_edges": None,
            "ngons": None,
            "zero_length_edges": None,
            "zero_area_faces": None,
        }

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        loose_verts = sum(1 for v in bm.verts if len(v.link_edges) == 0)
        loose_edges = sum(1 for e in bm.edges if len(e.link_faces) == 0)
        loose_faces = sum(1 for f in bm.faces if all(len(e.link_faces) <= 1 for e in f.edges))
        non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
        ngons = sum(1 for f in bm.faces if len(f.verts) > 4)
        zero_length_edges = sum(1 for e in bm.edges if (e.verts[0].co - e.verts[1].co).length <= 1e-9)
        zero_area_faces = sum(1 for f in bm.faces if f.calc_area() <= 1e-12)
        return {
            "loose_verts": loose_verts,
            "loose_edges": loose_edges,
            "loose_faces": loose_faces,
            "non_manifold_edges": non_manifold,
            "ngons": ngons,
            "zero_length_edges": zero_length_edges,
            "zero_area_faces": zero_area_faces,
        }
    finally:
        bm.free()



def nearly_one(value: float, tolerance: float = 1e-4) -> bool:
    return math.isclose(value, 1.0, rel_tol=tolerance, abs_tol=tolerance)



def has_non_uniform_scale(obj: bpy.types.Object) -> bool:
    x, y, z = obj.scale
    return not (math.isclose(x, y, rel_tol=1e-4, abs_tol=1e-4) and math.isclose(y, z, rel_tol=1e-4, abs_tol=1e-4))



def has_unapplied_scale(obj: bpy.types.Object) -> bool:
    return not all(nearly_one(v) for v in obj.scale)



def has_negative_scale(obj: bpy.types.Object) -> bool:
    try:
        return any(float(value) < 0.0 for value in obj.scale)
    except Exception:
        return False



def find_modifier(obj: bpy.types.Object, mod_type: str):
    return next((mod for mod in obj.modifiers if mod.type == mod_type), None)



def find_multires_modifier(obj: bpy.types.Object):
    return find_modifier(obj, 'MULTIRES')


# -----------------------------------------------------------------------------
# Snapshot / proxy helpers
# -----------------------------------------------------------------------------


def active_object_snapshots(obj: bpy.types.Object):
    return getattr(obj, "smart_sculpt_snapshots", None)



def serialize_name_list(objects: Iterable[bpy.types.Object]) -> str:
    return json.dumps([obj.name for obj in objects])



def deserialize_name_list(raw: str | None) -> list[str]:
    if not raw:
        return []
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return [str(x) for x in data]
    except Exception:
        pass
    return []



def sweep_broken_snapshot_items() -> int:
    removed = 0
    for obj in bpy.data.objects:
        snapshots = getattr(obj, "smart_sculpt_snapshots", None)
        if snapshots is None:
            continue
        for idx in reversed(range(len(snapshots))):
            item = snapshots[idx]
            if bpy.data.objects.get(item.object_name) is None:
                snapshots.remove(idx)
                removed += 1
        try:
            obj.smart_sculpt_snapshot_index = max(0, min(obj.smart_sculpt_snapshot_index, len(snapshots) - 1))
        except Exception:
            pass
    return removed


def clear_snapshot_preview_reference(owner_obj: bpy.types.Object | None, preview_name: str | None = None) -> bool:
    if owner_obj is None:
        return False
    current = str(owner_obj.get("sss_snapshot_preview", "") or "")
    if not current:
        return False
    if preview_name and current != preview_name:
        return False
    try:
        del owner_obj["sss_snapshot_preview"]
        return True
    except Exception:
        return False


def sweep_broken_snapshot_previews() -> int:
    removed = 0
    for obj in bpy.data.objects:
        preview_name = str(obj.get("sss_snapshot_preview", "") or "")
        if not preview_name:
            continue
        preview_obj = bpy.data.objects.get(preview_name)
        if preview_obj is None or not generated_is_owned(preview_obj, 'snapshot_preview'):
            if clear_snapshot_preview_reference(obj):
                removed += 1
    return removed


def session_source_names(obj: bpy.types.Object | None) -> list[str]:
    if obj is None:
        return []
    return deserialize_name_list(obj.get("sss_proxy_sources"))


def session_source_objects(obj: bpy.types.Object | None) -> list[bpy.types.Object]:
    result: list[bpy.types.Object] = []
    for name in session_source_names(obj):
        source = bpy.data.objects.get(name)
        if source is not None:
            result.append(source)
    return result


def restore_session_sources_from_object(obj: bpy.types.Object | None) -> tuple[list[str], int, int]:
    if obj is None:
        return [], 0, 0
    names = session_source_names(obj)
    visibility_map = deserialize_visibility_map(obj.get("sss_source_visibility"))
    restored = 0
    missing = 0
    for name in names:
        source = bpy.data.objects.get(name)
        if source is None:
            missing += 1
            continue
        state = visibility_map.get(name)
        if state:
            if restore_object_visibility_state(source, state):
                restored += 1
            continue
        did_restore = False
        try:
            source.hide_set(False)
            did_restore = True
        except Exception:
            pass
        try:
            source.hide_viewport = False
            did_restore = True
        except Exception:
            pass
        if did_restore:
            restored += 1
    return names, restored, missing




def mesh_uv_layer_count(obj: bpy.types.Object | None) -> int:
    mesh = getattr(obj, "data", None)
    uv_layers = getattr(mesh, "uv_layers", None)
    try:
        return len(uv_layers) if uv_layers is not None else 0
    except Exception:
        return 0


def new_objects_from_names(before_names: Iterable[str]) -> list[bpy.types.Object]:
    before = {str(name) for name in before_names}
    result: list[bpy.types.Object] = []
    for name in bpy.data.objects.keys():
        if name in before:
            continue
        obj = bpy.data.objects.get(name)
        if obj is not None:
            result.append(obj)
    result.sort(key=lambda item: item.name)
    return result


def new_mesh_objects_from_names(before_names: Iterable[str]) -> list[bpy.types.Object]:
    return [obj for obj in new_objects_from_names(before_names) if getattr(obj, "type", None) == 'MESH']


def filter_meaningful_mesh_objects(
    objects: Iterable[bpy.types.Object],
    *,
    min_vertices: int = 3,
    min_faces: int = 1,
) -> tuple[list[bpy.types.Object], list[bpy.types.Object]]:
    valid: list[bpy.types.Object] = []
    invalid: list[bpy.types.Object] = []
    for obj in objects:
        if obj is None or getattr(obj, "type", None) != 'MESH' or obj.name not in bpy.data.objects:
            continue
        if mesh_has_meaningful_topology(obj, min_vertices=min_vertices, min_faces=min_faces):
            valid.append(obj)
        else:
            invalid.append(obj)
    valid.sort(key=lambda item: item.name)
    invalid.sort(key=lambda item: item.name)
    return valid, invalid


def delete_objects_if_possible(objects: Iterable[bpy.types.Object]) -> int:
    removed = 0
    for obj in objects:
        if obj is None or obj.name not in bpy.data.objects:
            continue
        if safe_delete_object(obj):
            removed += 1
    return removed


def select_objects_if_any(context: bpy.types.Context, objects: Sequence[bpy.types.Object]) -> int:
    valid = [obj for obj in objects if obj is not None and obj.name in bpy.data.objects]
    if not valid:
        return 0
    select_only(context, valid, active=valid[0])
    return len(valid)


def recovery_backup_name(obj: bpy.types.Object | None) -> str:
    if obj is None:
        return ""
    try:
        return str(obj.get("sss_recovery_backup", "") or "")
    except Exception:
        return ""


def recovery_backup_reason(obj: bpy.types.Object | None) -> str:
    if obj is None:
        return ""
    try:
        return str(obj.get("sss_recovery_reason", "") or "")
    except Exception:
        return ""


def recovery_backup_saved_at(obj: bpy.types.Object | None) -> str:
    if obj is None:
        return ""
    try:
        return str(obj.get("sss_recovery_saved_at", "") or "")
    except Exception:
        return ""


def recovery_backup_object(obj: bpy.types.Object | None):
    name = recovery_backup_name(obj)
    return bpy.data.objects.get(name) if name else None


def clear_recovery_backup_reference(owner_obj: bpy.types.Object | None, backup_name: str | None = None) -> bool:
    if owner_obj is None:
        return False
    current = recovery_backup_name(owner_obj)
    if not current:
        return False
    if backup_name and current != backup_name:
        return False
    cleared = False
    for key in ("sss_recovery_backup", "sss_recovery_reason", "sss_recovery_saved_at"):
        try:
            if key in owner_obj:
                del owner_obj[key]
                cleared = True
        except Exception:
            pass
    return cleared


def delete_recovery_backup_object(owner_obj: bpy.types.Object | None) -> bool:
    backup = recovery_backup_object(owner_obj)
    if backup is None:
        clear_recovery_backup_reference(owner_obj)
        return False
    backup_name = backup.name
    removed = safe_delete_object(backup)
    if removed:
        clear_recovery_backup_reference(owner_obj, backup_name)
    return removed


def sweep_broken_recovery_backups() -> int:
    removed = 0
    for obj in bpy.data.objects:
        backup_name = recovery_backup_name(obj)
        if not backup_name:
            continue
        backup_obj = bpy.data.objects.get(backup_name)
        if backup_obj is None or not generated_is_owned(backup_obj, 'recovery'):
            if clear_recovery_backup_reference(obj):
                removed += 1
    return removed


def make_recovery_backup(
    context: bpy.types.Context,
    obj: bpy.types.Object | None,
    reason: str,
    *,
    force: bool = False,
):
    if obj is None or getattr(obj, "type", None) != 'MESH':
        return None
    settings = settings_from_context(context)
    if not force and settings is not None and not getattr(settings, "enable_recovery_backups", True):
        return None

    previous_name = recovery_backup_name(obj)
    previous_backup = bpy.data.objects.get(previous_name) if previous_name else None
    collection = recovery_collection(context.scene)
    backup = duplicate_object_data(obj, collection, name=f"{obj.name}_recovery", kind='recovery')
    # A recovery mesh has its own identity even when copied from a staged mesh.
    backup.data.name = backup.name
    try:
        backup.hide_set(True)
    except Exception:
        pass
    try:
        backup.hide_viewport = True
    except Exception:
        pass
    try:
        backup.hide_render = True
    except Exception:
        pass
    try:
        backup["sss_recovery_source"] = obj.name
        backup["sss_recovery_reason"] = str(reason)
    except Exception:
        pass
    try:
        obj["sss_recovery_backup"] = backup.name
        obj["sss_recovery_reason"] = str(reason)
        obj["sss_recovery_saved_at"] = datetime.now().isoformat(timespec="seconds")
    except Exception:
        pass
    if previous_backup is not None and previous_backup != backup:
        safe_delete_object(previous_backup)
    return backup


def restore_recovery_backup_into_object(context: bpy.types.Context, obj: bpy.types.Object | None) -> tuple[bool, str]:
    if obj is None or getattr(obj, "type", None) != 'MESH':
        return False, ""
    backup = recovery_backup_object(obj)
    if backup is None or getattr(backup, "type", None) != 'MESH':
        clear_recovery_backup_reference(obj)
        return False, ""

    original_mode = getattr(obj, 'mode', 'OBJECT')
    original_visibility = capture_object_visibility_state(obj)
    reason = recovery_backup_reason(obj) or str(backup.get("sss_recovery_reason", "") or "")
    ensure_object_mode(context, obj)
    old_mesh = getattr(obj, "data", None)
    try:
        obj.data = backup.data.copy()
        if old_mesh is not None:
            remove_orphan_data(old_mesh)
        restore_vertex_groups_from_object(obj, backup)
        restore_modifiers_from_object(obj, backup)
        restore_object_display_settings(obj, backup)
    except Exception:
        return False, reason
    finally:
        restore_object_visibility_state(obj, original_visibility)
        if original_mode == 'SCULPT':
            ensure_sculpt_mode(context, obj)
        elif original_mode == 'EDIT':
            ensure_edit_mode(context, obj)
        else:
            ensure_object_mode(context, obj)
    return True, reason


# -----------------------------------------------------------------------------
# Exchange / cleanup helpers
# -----------------------------------------------------------------------------


# extension_user_root is assigned to the user_default-aware resolver below.
def default_exchange_directory() -> Path:
    directory = extension_user_root(create=True) / "exchange"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _is_default_exchange_path(raw: str | None) -> bool:
    text = str(raw or "").strip().replace('\\', '/')
    if not text:
        return True
    normalized = text.rstrip('/')
    return normalized.casefold() in {"//smartsculptexchange", "smartsculpexchange"}


EXTENSIONS = {
    'OBJ': '.obj',
    'USD': '.usd',
    'FBX': '.fbx',
    'ABC': '.abc',
    'PLY': '.ply',
}



def exchange_directory(context: bpy.types.Context) -> Path:
    settings = settings_from_context(context)
    prefs = addon_prefs(context)
    raw = ""
    if settings and getattr(settings, 'exchange_dir', ''):
        raw = settings.exchange_dir
    elif prefs and getattr(prefs, 'default_exchange_dir', ''):
        raw = prefs.default_exchange_dir

    raw_text = str(raw or "").strip()
    if not raw_text or _is_default_exchange_path(raw_text):
        return default_exchange_directory()

    try:
        directory = Path(bpy.path.abspath(raw_text)).expanduser()
        directory.mkdir(parents=True, exist_ok=True)
        return directory
    except Exception:
        # Invalid manual paths fall back to the add-on controlled user_default
        # exchange directory so no startup-generated data escapes user_default.
        return default_exchange_directory()



def export_path(context: bpy.types.Context, extension: str) -> Path:
    obj = active_mesh_object(context) or context.view_layer.objects.active
    stem = sanitize_filename_component(obj.name if obj else "smart_sculpt")
    return exchange_directory(context) / f"{stem}{extension}"



def newest_file_with_suffix(directory: Path, suffix: str) -> Path | None:
    files = [path for path in directory.glob(f"*{suffix}") if path.is_file()]
    if not files:
        return None
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0]



def newest_matching_file_with_suffix(directory: Path, suffix: str, preferred_stem: str | None = None) -> Path | None:
    files = [path for path in directory.glob(f"*{suffix}") if path.is_file()]
    if not files:
        return None
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    if preferred_stem:
        safe_stem = sanitize_filename_component(preferred_stem)
        preferred = [path for path in files if path.stem == safe_stem or path.stem.startswith(f"{safe_stem}_")]
        if preferred:
            return preferred[0]
    return files[0]



def cleanup_generated_data(include_snapshots: bool = False) -> dict[str, int]:
    """Delete only exact current-generation ledger entries.

    Names, ``SSS_`` prefixes, shared Collection names, and historical flags are
    intentionally ignored.  This function runs only from an explicit operator.
    """
    removed_objects = removed_textures = removed_collections = 0
    restored_sources = cleared_preview_refs = cleared_recovery_refs = 0
    records = tuple(_ownership.tracked_records())

    for obj, _token, kind, _remover in records:
        if not kind.startswith('object:') or not isinstance(obj, bpy.types.Object):
            continue
        generated_kind = kind.split(':', 1)[1]
        if generated_kind == 'snapshot' and not include_snapshots:
            continue
        if generated_kind in {'proxy', 'session'}:
            _names, restored, _missing = restore_session_sources_from_object(obj)
            restored_sources += restored
        if generated_kind == 'snapshot_preview':
            for owner, _owner_token, owner_kind, _owner_remover in tuple(_ownership.tracked_records()):
                if owner_kind.startswith('object:') and isinstance(owner, bpy.types.Object):
                    if clear_snapshot_preview_reference(owner, obj.name):
                        cleared_preview_refs += 1
        if generated_kind == 'recovery':
            for owner, _owner_token, owner_kind, _owner_remover in tuple(_ownership.tracked_records()):
                if owner_kind.startswith('object:') and isinstance(owner, bpy.types.Object):
                    if clear_recovery_backup_reference(owner, obj.name):
                        cleared_recovery_refs += 1
        if safe_delete_object(obj, require_owned=True):
            removed_objects += 1

    for data, token, kind, _remover in tuple(_ownership.tracked_records()):
        if kind.startswith('texture:') and isinstance(data, bpy.types.Texture):
            try:
                if data.users == 0 and _ownership.matches(data, token):
                    bpy.data.textures.remove(data)
                    _ownership.untrack(data, token)
                    removed_textures += 1
            except Exception:
                pass

    for collection, token, kind, _remover in tuple(_ownership.tracked_records()):
        if not kind.startswith('collection:') or not isinstance(collection, bpy.types.Collection):
            continue
        if kind == f'collection:{SNAPSHOT_COLLECTION_NAME}' and not include_snapshots:
            continue
        try:
            empty = not collection.objects and not collection.children
        except Exception:
            empty = False
        if empty and _ownership.matches(collection, token):
            try:
                bpy.data.collections.remove(collection)
                _ownership.untrack(collection, token)
                removed_collections += 1
            except Exception:
                pass
    return {
        'objects': removed_objects,
        'textures': removed_textures,
        'collections': removed_collections,
        'restored_sources': restored_sources,
        'cleared_preview_refs': cleared_preview_refs,
        'cleared_recovery_refs': cleared_recovery_refs,
    }


# --- Smart Tools unified user_default path patch (2026-03-27) ---
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    default = str(default or "").strip()
    try:
        current = Path(__file__).resolve().parent
        while True:
            manifest = current / "blender_manifest.toml"
            if manifest.is_file():
                for raw_line in manifest.read_text(encoding="utf-8").splitlines():
                    line = raw_line.strip()
                    if not line.startswith("id"):
                        continue
                    _, _, value = line.partition("=")
                    value = str(value or "").strip().strip('"').strip("'")
                    if value:
                        return value
                break
            if current.parent == current:
                break
            current = current.parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        head = default.split(".", 1)[0].strip()
        if head:
            default = head
    return default

def _smart_tools_sculpt_extension_candidates() -> tuple[str, ...]:
    values = []
    try:
        values.extend(list(addon_id_candidates()))
    except Exception:
        pass
    values.append('core')
    out = []
    for value in values:
        value = _smart_tools_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or ('core',)

def _smart_tools_extension_user_root(create: bool = False) -> Path:
    for package_id in _smart_tools_sculpt_extension_candidates():
        path = _smart_tools_version_user_default_root(package_id, create=create)
        if path:
            return path
    return _smart_tools_version_user_default_root('core', create=create)

extension_user_root = _smart_tools_extension_user_root

# --- Smart Tools user_default migration patch (2026-03-27) ---
def _smart_tools_manifest_dir() -> Path:
    try:
        current = Path(__file__).resolve().parent
        while True:
            if (current / "blender_manifest.toml").is_file():
                return current
            if current.parent == current:
                break
            current = current.parent
    except Exception:
        pass
    return Path(__file__).resolve().parent

def _smart_tools_has_visible_entries(path: Path) -> bool:
    try:
        return any(item.name not in {".DS_Store", "Thumbs.db"} for item in path.iterdir())
    except Exception:
        return False

def _smart_tools_merge_tree(src: Path, dst: Path) -> None:
    import shutil
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in {".DS_Store", "Thumbs.db"}:
            continue
        target = dst / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        elif item.is_file() and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)

def _smart_tools_user_version_root() -> Path | None:
    """Return Blender's user version root without creating external folders."""
    utils_mod = getattr(bpy, "utils", None)
    if utils_mod is not None:
        resource_path = getattr(utils_mod, "resource_path", None)
        if callable(resource_path):
            try:
                value = resource_path("USER")
                if value:
                    return Path(str(value)).expanduser()
            except Exception:
                pass
    try:
        major, minor = getattr(bpy.app, "version", (5, 1, 0))[:2]
        version_name = f"{int(major)}.{int(minor)}"
    except Exception:
        version_name = "5.1"
    try:
        import os
        if sys.platform.startswith("win"):
            appdata = os.environ.get("APPDATA")
            if appdata:
                return Path(appdata) / "Blender Foundation" / "Blender" / version_name
        if sys.platform == "darwin":
            return Path.home() / "Library" / "Application Support" / "Blender" / version_name
    except Exception:
        pass
    return Path.home() / ".config" / "blender" / version_name


def _smart_tools_normalized_path_text(path: Path) -> str:
    try:
        resolved = Path(path).expanduser().resolve(strict=False)
    except Exception:
        resolved = Path(path).expanduser()
    return str(resolved).replace('\\', '/').rstrip('/').casefold()


def _smart_tools_is_inside_user_default(path: Path) -> bool:
    user_version_root = _smart_tools_user_version_root()
    if user_version_root is None:
        return False
    repo = Path(user_version_root) / 'extensions' / 'user_default'
    path_text = _smart_tools_normalized_path_text(Path(path))
    repo_text = _smart_tools_normalized_path_text(repo)
    return path_text == repo_text or path_text.startswith(repo_text + '/')


def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> Path:
    package_id = _smart_tools_manifest_extension_id(package_id)
    try:
        root_package = str(__package__ or '').rsplit('.core', 1)[0]
        if root_package:
            storage_mod = importlib.import_module(f'{root_package}.storage')
            resolver = getattr(storage_mod, 'mutable_settings_root', None)
            if callable(resolver):
                return Path(resolver(package_id or getattr(storage_mod, 'PACKAGE_ID', 'smart_sculpt_suite'), create=create))
    except Exception:
        pass
    target_path: Path | None = None
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            value = user_resource('CONFIG', create=create) or ''
            if value:
                target_path = Path(str(value)).expanduser() / 'Smart_Sculpt_Suite' / 'sidecars'
    except Exception:
        target_path = None
    if target_path is None:
        user_version_root = _smart_tools_user_version_root()
        if user_version_root is not None:
            target_path = user_version_root / 'config' / 'Smart_Sculpt_Suite' / 'sidecars'
        else:
            target_path = Path.home() / '.config' / 'blender' / '5.1' / 'config' / 'Smart_Sculpt_Suite' / 'sidecars'
    if create:
        target_path.mkdir(parents=True, exist_ok=True)
    return target_path
