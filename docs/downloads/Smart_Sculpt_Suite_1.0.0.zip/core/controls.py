# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import json
import sys
from pathlib import Path
from typing import Any

import bpy

from . import utils
from .. import _sss_json_store as _json_store

_SETTINGS_DIRNAME = 'settings'
_CONFIG_DIRNAME = 'Smart_Sculpt_Suite'
_CONFIG_FILENAME = 'Smart_Sculpt_Suite.json'
_ROOT_KNOWN_CONTROLS_ATTR = 'known_controls_json'
_APPLYING_CONTROL_UPDATE = False
_SESSION_STATE: dict[str, Any] = {}
_STATE_LOADED = False


def _t(english: str, japanese: str) -> str:
    return utils.ui_text(english, japanese)


def _tooltip(english: str, japanese: str) -> str:
    return utils.ui_text(english, japanese)


def _compact_npanel_layout(layout):
    """Use a narrow-sidebar layout that does not push controls outside the N-panel."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _help_button_row(layout):
    try:
        layout.separator(factor=0.35)
    except TypeError:
        try:
            layout.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    return row


def _draw_help_button(layout, topic_id: str) -> bool:
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        help_op = _help_button_row(layout).operator('smart_sculpt.open_help_popup', text='', icon='QUESTION')
        help_op.topic_id = topic_id
        return True
    except Exception:
        return False


def _path() -> Path | None:
    try:
        from .. import storage as _smart_storage
        return _smart_storage.workspace_settings_path(create=True)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            value = user_resource('CONFIG', create=True) or ''
            if value:
                path = Path(str(value)).expanduser()
                path.mkdir(parents=True, exist_ok=True)
                return path / _CONFIG_DIRNAME / _CONFIG_FILENAME
    except Exception:
        pass
    return None


def _controls_store_validator(payload: dict[str, Any]) -> bool:
    return isinstance(payload, dict) and str(payload.get('addon_id', 'smart_sculpt_suite') or 'smart_sculpt_suite') == 'smart_sculpt_suite'

def _read_shared_store() -> dict[str, Any]:
    file_path = _path()
    if file_path is None:
        return {}
    try:
        document = _json_store.read_with_backup(
            file_path, validator=_controls_store_validator, allow_legacy=True, repair=True
        )
        return _json_store.payload_only(document) if isinstance(document, dict) else {}
    except Exception:
        return {}


def _write_shared_store(data: dict[str, Any]) -> bool:
    value = dict(data) if isinstance(data, dict) else {}
    value.setdefault('version', 1)
    value.setdefault('addon_id', 'smart_sculpt_suite')
    value.setdefault('storage_folder', _CONFIG_DIRNAME)
    value.setdefault('storage_file', _CONFIG_FILENAME)
    try:
        from .. import storage as _smart_storage
        _smart_storage.write_workspace_settings(value)
        return True
    except Exception:
        pass
    file_path = _path()
    if file_path is None:
        return False
    try:
        _json_store.atomic_write(file_path, value, validator=_controls_store_validator)
        verified = _json_store.read_with_backup(
            file_path, validator=_controls_store_validator, allow_legacy=False, repair=False
        )
        return isinstance(verified, dict) and _json_store.payload_only(verified) == value
    except Exception:
        return False


def _legacy_state_paths() -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        from .. import storage as _smart_storage
        paths.append(Path(_smart_storage.extension_user_root(create=False)) / _SETTINGS_DIRNAME / 'core_always_on_controls.json')
    except Exception:
        pass
    return tuple(paths)


def _read_state() -> dict[str, Any]:
    """Load persistence once outside draw; empty state is cached explicitly."""
    global _SESSION_STATE, _STATE_LOADED
    if _STATE_LOADED:
        return dict(_SESSION_STATE)
    _STATE_LOADED = True
    shared_data = _read_shared_store()
    file_data = _coerce_state(shared_data)
    if not file_data:
        # Preserve historical scene.core fallbacks in the same memory snapshot
        # so hot UI reads never reopen the JSON file.
        scene_values = shared_data.get('scene_settings') if isinstance(shared_data, dict) else None
        if isinstance(scene_values, dict):
            known = {}
            for spec in _KNOWN_CONTROLS:
                if str(spec.get('owner_key') or '') != 'scene.core':
                    continue
                prop = str(spec.get('prop') or '')
                if prop in scene_values:
                    known[_state_key('scene.core', prop)] = bool(scene_values[prop])
            if known:
                file_data = {'version': 1, 'known_controls': known}
    if file_data:
        _SESSION_STATE = dict(file_data)
        _mirror_state_to_preferences(file_data)
        return dict(_SESSION_STATE)
    for legacy_path in _legacy_state_paths():
        if legacy_path.exists():
            try:
                document = _json_store.read_with_backup(legacy_path, allow_legacy=True, repair=False)
                file_data = _coerce_state(_json_store.payload_only(document) if isinstance(document, dict) else {})
            except Exception:
                file_data = {}
            if file_data:
                _SESSION_STATE = dict(file_data)
                _write_state(file_data)
                return dict(_SESSION_STATE)
    pref_data = _read_state_from_preferences()
    if pref_data:
        _SESSION_STATE = dict(pref_data)
        _write_state(pref_data)
        return dict(_SESSION_STATE)
    _SESSION_STATE = {}
    return {}


def _write_state(data: dict[str, Any]) -> None:
    global _SESSION_STATE, _STATE_LOADED
    _STATE_LOADED = True
    data = _coerce_state(data)
    _SESSION_STATE = dict(data) if data else {}
    _mirror_state_to_preferences(data)
    if not data:
        return
    shared_data = _read_shared_store()
    shared_data['known_controls'] = dict(data.get('known_controls') or {})
    shared_data['version'] = 1
    shared_data['addon_id'] = 'smart_sculpt_suite'
    shared_data['storage_file'] = _CONFIG_FILENAME
    _write_shared_store(shared_data)


def _set_session_state(data: dict[str, Any]) -> None:
    global _SESSION_STATE, _STATE_LOADED
    _STATE_LOADED = True
    data = _coerce_state(data)
    _SESSION_STATE = dict(data) if data else {}
    _mirror_state_to_preferences(data)


def _npanel_state_save_enabled(context=None) -> bool:
    try:
        from . import settings as persistent_settings
        scene = getattr(context, 'scene', None) if context is not None else getattr(getattr(bpy, 'context', None), 'scene', None)
        checker = getattr(persistent_settings, 'immediate_save_enabled', None)
        if callable(checker):
            return bool(checker(scene))
    except Exception:
        pass
    try:
        settings = getattr(getattr(context, 'scene', None), 'core', None) if context is not None else getattr(getattr(getattr(bpy, 'context', None), 'scene', None), 'core', None)
        if settings is not None and hasattr(settings, 'always_on_npanel_autosave_restore'):
            return bool(getattr(settings, 'always_on_npanel_autosave_restore'))
    except Exception:
        pass
    return True


def _state_key(owner_key: str, prop_name: str) -> str:
    return f'{str(owner_key or "").strip()}::{str(prop_name or "").strip()}'


def _stored_known_value(owner_key: str, prop_name: str, default: bool = False) -> bool:
    # Hot UI reads are strictly cache-only.  Registration/load/operator
    # boundaries explicitly prime _SESSION_STATE through _read_state().
    key = _state_key(owner_key, prop_name)
    values = _SESSION_STATE.get('known_controls') if _STATE_LOADED else None
    if isinstance(values, dict) and key in values:
        return bool(values.get(key, default))
    return bool(default)


def _store_known_value(owner_key: str, prop_name: str, enabled: bool, *, context=None, force: bool = False) -> None:
    data = _read_state()
    values = data.setdefault('known_controls', {})
    if isinstance(values, dict):
        values[_state_key(owner_key, prop_name)] = bool(enabled)
    data['version'] = 1
    if bool(force) or _npanel_state_save_enabled(context):
        _write_state(data)
    else:
        _set_session_state(data)


_KNOWN_CONTROLS: tuple[dict[str, Any], ...] = (
    {
        'alias': 'core',
        'owner_key': 'scene.core',
        'prop': 'always_on_npanel_autosave_restore',
        'label_en': 'N-panel State Save',
        'label_ja': 'Nパネル状態保存',
        'icon': 'FILE_TICK',
        'default': True,
        'description_en': 'Controls Smart Sculpt N-panel state saving. When enabled, every N-panel setting change, including always-on switches, is saved immediately to Smart_Sculpt_Suite/Smart_Sculpt_Suite.json in the Blender config folder and restored on startup or scene changes. When disabled, settings are saved only when the current scene is closed or when Save Preferences is run.',
        'description_ja': 'スマートスカルプトのNパネル状態保存を制御します。有効時は、常時機能切り替えを含む全Nパネル設定の変更を Blender の設定フォルダー内の Smart_Sculpt_Suite/Smart_Sculpt_Suite.json へ即時保存し、起動時やシーン切り替え時に復元します。無効時は、現在のシーンを閉じる時またはプリファレンス保存時だけ保存します。',
    },
    {
        'alias': 'navigation',
        'owner_key': 'scene.core',
        'prop': 'always_on_navigation_border_overlay',
        'label_en': 'Navigation Border Overlay',
        'label_ja': '境界オーバーレイ',
        'icon': 'OVERLAY',
        'default': False,
        'description_en': 'Enables the only unavoidable live viewport feature: the navigation border overlay draw handler. Keep it disabled unless a persistent border guide is required.',
        'description_ja': '常時表示に描画ハンドラーが必要な唯一の項目です。ナビゲーション境界ガイドを常時表示したい場合だけ有効にします。',
    },
)

# Navigation mode preferences are read only while an operator is running; they
# are ordinary settings, not resident services. Keep only the actual border
# draw handler and add the two Edit Mask runtimes that own a timer/draw handler.
_KNOWN_CONTROLS = tuple(
    spec for spec in _KNOWN_CONTROLS
    if str(spec.get('prop') or '') in {
        'always_on_npanel_autosave_restore',
        'always_on_navigation_border_overlay',
    }
) + (
    {
        'alias': 'edit_mode_sculpt',
        'owner_key': 'scene.edit_mode_sculpt',
        'prop': 'use_mask_for_mesh_editing',
        'label_en': 'Edit Mask Lock',
        'label_ja': '編集マスクロック',
        'icon': 'MOD_MASK',
        'default': False,
        'description_en': 'Keeps the masked-vertex lock timer active while Edit Mask is in use. OFF removes the timer immediately.',
        'description_ja': '編集マスク使用中にマスク頂点ロックタイマーを維持します。無効にするとタイマーを直ちに解除します。',
    },
    {
        'alias': 'edit_mode_sculpt',
        'owner_key': 'scene.edit_mode_sculpt',
        'prop': 'mask_overlay_enabled',
        'label_en': 'Locked Vertex Overlay',
        'label_ja': 'ロック頂点オーバーレイ',
        'icon': 'OVERLAY',
        'default': False,
        'description_en': 'Keeps a View3D draw handler active to show locked vertices. OFF removes the handler immediately.',
        'description_ja': 'ロック頂点を表示する3Dビュー描画ハンドラーを維持します。無効にするとハンドラーを直ちに解除します。',
    },
)

_CONTROL_PROP_TO_SPEC: dict[str, dict[str, Any]] = {str(spec.get('prop') or ''): spec for spec in _KNOWN_CONTROLS}


def _spec_for(alias: str, owner_key: str, prop_name: str) -> dict[str, Any] | None:
    for spec in _KNOWN_CONTROLS:
        if str(spec.get('alias') or '') == alias and str(spec.get('owner_key') or '') == owner_key and str(spec.get('prop') or '') == prop_name:
            return spec
    return None


def _preferences_module():
    """Return the already-loaded package preferences module without importing."""
    package = str(__package__ or '').strip()
    prefix = package.rsplit('.core', 1)[0] if '.core' in package else package.rsplit('.', 1)[0]
    return sys.modules.get(f'{prefix}.preferences') if prefix else None


def _root_preferences(context=None):
    prefs_module = _preferences_module()
    if prefs_module is None:
        return None
    try:
        getter = getattr(prefs_module, 'root_preferences', None)
        return getter(context) if callable(getter) else None
    except Exception:
        return None


def _coerce_state(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    values = data.get('known_controls')
    if not isinstance(values, dict) or not values:
        return {}
    out: dict[str, Any] = {'known_controls': {str(k): bool(v) for k, v in values.items() if str(k or '').strip()}}
    if not out['known_controls']:
        return {}
    try:
        out['version'] = int(data.get('version', 1) or 1)
    except Exception:
        out['version'] = 1
    return out


def _read_state_from_preferences(context=None) -> dict[str, Any]:
    root = _root_preferences(context)
    if root is None:
        return {}
    try:
        raw = str(getattr(root, _ROOT_KNOWN_CONTROLS_ATTR, '') or '').strip()
    except Exception:
        raw = ''
    if not raw:
        return {}
    try:
        return _coerce_state(json.loads(raw))
    except Exception:
        return {}


def _mirror_state_to_preferences(data: dict[str, Any], context=None) -> None:
    root = _root_preferences(context)
    if root is None or not hasattr(root, _ROOT_KNOWN_CONTROLS_ATTR):
        return
    try:
        setattr(root, _ROOT_KNOWN_CONTROLS_ATTR, json.dumps(_coerce_state(data), ensure_ascii=False, sort_keys=True))
    except Exception:
        pass


def _resolve_owner(context, owner_key: str):
    owner_key = str(owner_key or '').strip()
    if owner_key == 'scene.core':
        try:
            return getattr(getattr(context, 'scene', None), 'core', None)
        except Exception:
            return None
    if owner_key == 'scene.edit_mode_sculpt':
        try:
            return getattr(getattr(context, 'scene', None), 'strict_edit_mode_sculpt_settings', None)
        except Exception:
            return None
    if owner_key == 'wm.sculptnav':
        try:
            wm = getattr(context, 'window_manager', None)
            return getattr(wm, 'sculptnav', None) or getattr(wm, 'sculptnav_props', None)
        except Exception:
            return None
    if owner_key.startswith('prefs.'):
        alias = owner_key.split('.', 1)[1]
        prefs_module = _preferences_module()
        if prefs_module is not None:
            try:
                finder = getattr(prefs_module, 'find_tool_settings', None)
                if callable(finder):
                    return finder(alias, context=context)
            except Exception:
                return None
    return None


def _load_alias(alias: str) -> bool:
    alias = str(alias or '').strip()
    if not alias or alias == 'core':
        return True
    try:
        from . import loader, ui_runtime
        record = loader.load_alias(alias)
        try:
            refresh = getattr(ui_runtime, '_collect_records', None)
            if callable(refresh):
                refresh()
        except Exception:
            pass
        return bool(record and str(record.get('status') or '') == 'loaded')
    except Exception:
        return False


def _current_known_value(context, spec: dict[str, Any]) -> bool:
    owner_key = str(spec.get('owner_key') or '')
    prop_name = str(spec.get('prop') or '')
    owner = _resolve_owner(context, owner_key)
    if owner is not None and hasattr(owner, prop_name):
        try:
            return bool(getattr(owner, prop_name))
        except Exception:
            pass
    return _stored_known_value(owner_key, prop_name, bool(spec.get('default', False)))


def _set_feature_toggle(alias: str, feature_key: str, enabled: bool) -> None:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return
    try:
        from .. import feature_toggle
        setter = getattr(feature_toggle, 'set_feature_enabled', None)
        if callable(setter):
            setter(alias, feature_key, bool(enabled))
    except Exception:
        pass


def _deactivate_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    if not alias or alias == 'core':
        return
    try:
        from .. import feature_toggle
        deactivate = getattr(feature_toggle, 'deactivate_alias', None)
        if callable(deactivate):
            deactivate(alias)
    except Exception:
        pass


def _set_navigation_pref(context, pref_name: str, enabled: bool) -> None:
    owner = _resolve_owner(context, 'prefs.navigation')
    if owner is None and enabled:
        _load_alias('navigation')
        owner = _resolve_owner(context, 'prefs.navigation')
    if owner is not None and hasattr(owner, pref_name):
        try:
            setattr(owner, pref_name, bool(enabled))
        except Exception:
            pass


def _set_navigation_wm_enabled(context, enabled: bool) -> None:
    owner = _resolve_owner(context, 'wm.sculptnav')
    if owner is None and enabled:
        _load_alias('navigation')
        owner = _resolve_owner(context, 'wm.sculptnav')
    if owner is not None and hasattr(owner, 'enabled'):
        try:
            setattr(owner, 'enabled', bool(enabled))
        except Exception:
            pass


def _set_navigation_overlay_runtime(enabled: bool) -> None:
    """Start or stop the only persistent navigation draw handler on demand."""
    try:
        from ..navigation.ui import overlays as _nav_overlays
        if bool(enabled):
            register = getattr(_nav_overlays, 'register', None)
            if callable(register):
                register()
        else:
            unregister = getattr(_nav_overlays, 'unregister', None)
            if callable(unregister):
                unregister()
    except Exception:
        pass


_NAVIGATION_PREFERENCE_MAP = {
    'navigation_enabled': ('wm', 'enabled'),
    'navigation_canvas_enabled': ('prefs', 'canvas_navigation_enabled'),
    'navigation_rmb_enabled': ('prefs', 'canvas_rmb_enabled'),
    'navigation_double_click_focus_enabled': ('prefs', 'double_click_focus_enabled'),
}


def apply_navigation_preference_settings(settings, context=None, *, request_save: bool = True) -> None:
    """Mirror ordinary Navigation UI settings into their native owners.

    These four values are read only when a navigation operator is invoked. They
    deliberately do not appear in the Always-on group and never install a
    handler, timer, keymap, or draw callback.
    """
    context = context or getattr(bpy, 'context', None)
    if settings is None or context is None:
        return
    values: dict[str, bool] = {}
    for prop_name in _NAVIGATION_PREFERENCE_MAP:
        if not hasattr(settings, prop_name):
            continue
        try:
            values[prop_name] = bool(getattr(settings, prop_name))
        except Exception:
            continue
    if not values:
        return

    # Loading is needed only when an enabled preference must be applied. A
    # completely disabled set stays class- and background-free at startup.
    native_owner_ready = (
        _resolve_owner(context, 'wm.sculptnav') is not None
        or _resolve_owner(context, 'prefs.navigation') is not None
    )
    if any(values.values()) and not native_owner_ready:
        _load_alias('navigation')
    for prop_name, enabled in values.items():
        owner_kind, target_name = _NAVIGATION_PREFERENCE_MAP[prop_name]
        if owner_kind == 'wm':
            _set_navigation_wm_enabled(context, enabled)
        else:
            _set_navigation_pref(context, target_name, enabled)

    if request_save:
        try:
            from . import settings as persistent_settings
            save = getattr(persistent_settings, 'request_immediate_save', None)
            if callable(save):
                save(getattr(context, 'scene', None), context=context)
        except Exception:
            pass


def _apply_special_control(context, spec: dict[str, Any], enabled: bool) -> None:
    prop_name = str(spec.get('prop') or '')
    alias = str(spec.get('alias') or '')
    enabled = bool(enabled)
    if prop_name == 'always_on_npanel_autosave_restore':
        try:
            from . import settings as persistent_settings
            setter = getattr(persistent_settings, 'set_auto_sync_enabled', None)
            if callable(setter):
                setter(enabled, apply_now=False)
        except Exception:
            pass
        return

    if alias != 'navigation':
        return

    if prop_name == 'always_on_navigation_border_overlay':
        _set_navigation_pref(context, 'show_border_overlay', enabled)
        _set_navigation_overlay_runtime(enabled)
        return


def _assign_owner_value(context, spec: dict[str, Any], enabled: bool) -> None:
    global _APPLYING_CONTROL_UPDATE
    owner_key = str(spec.get('owner_key') or '')
    prop_name = str(spec.get('prop') or '')
    owner = _resolve_owner(context, owner_key)
    if owner is None:
        return
    if not hasattr(owner, prop_name):
        return
    previous = _APPLYING_CONTROL_UPDATE
    _APPLYING_CONTROL_UPDATE = True
    try:
        try:
            if bool(getattr(owner, prop_name)) != bool(enabled):
                setattr(owner, prop_name, bool(enabled))
        except Exception:
            try:
                setattr(owner, prop_name, bool(enabled))
            except Exception:
                pass
    finally:
        _APPLYING_CONTROL_UPDATE = previous


def _set_known_value(context, spec: dict[str, Any], enabled: bool) -> bool:
    owner_key = str(spec.get('owner_key') or '')
    prop_name = str(spec.get('prop') or '')
    alias = str(spec.get('alias') or '')
    if bool(enabled) and alias and alias != 'core':
        _load_alias(alias)
    _assign_owner_value(context, spec, bool(enabled))
    _store_known_value(owner_key, prop_name, bool(enabled), context=context, force=(prop_name == 'always_on_npanel_autosave_restore'))
    _apply_special_control(context, spec, bool(enabled))
    try:
        if owner_key.startswith('scene.'):
            from . import settings as persistent_settings
            request_save = getattr(persistent_settings, 'request_immediate_save', None)
            if callable(request_save):
                request_save(getattr(context, 'scene', None), context, force=(prop_name == 'always_on_npanel_autosave_restore'))
            elif (prop_name == 'always_on_npanel_autosave_restore') or _npanel_state_save_enabled(context):
                persistent_settings.save_scene_settings(getattr(context, 'scene', None))
    except Exception:
        pass
    return True


def apply_setting_property_update(settings, context=None) -> None:
    """Synchronize direct BoolProperty toggles drawn in the always-on group."""
    if _APPLYING_CONTROL_UPDATE:
        return
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return
    try:
        from . import settings as persistent_settings
        applying_scene_restore = bool(getattr(persistent_settings, 'is_applying', lambda: False)())
    except Exception:
        applying_scene_restore = False
    if applying_scene_restore:
        return

    changed: list[tuple[dict[str, Any], bool]] = []
    for spec in _KNOWN_CONTROLS:
        prop_name = str(spec.get('prop') or '')
        owner_key = str(spec.get('owner_key') or '')
        if owner_key != 'scene.core' or not prop_name or not hasattr(settings, prop_name):
            continue
        try:
            current = bool(getattr(settings, prop_name))
        except Exception:
            continue
        stored = _stored_known_value(owner_key, prop_name, bool(spec.get('default', False)))
        if bool(current) != bool(stored):
            changed.append((spec, current))

    for spec, enabled in changed:
        owner_key = str(spec.get('owner_key') or '')
        prop_name = str(spec.get('prop') or '')
        _store_known_value(owner_key, prop_name, enabled, context=context, force=(prop_name == 'always_on_npanel_autosave_restore'))
        _apply_special_control(context, spec, enabled)


def save_known_controls_from_context(context=None, *, persist: bool = True) -> None:
    """Copy current always-on BoolProperty values into the shared JSON state."""
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return
    data = _read_state()
    values = data.setdefault('known_controls', {})
    if not isinstance(values, dict):
        values = {}
        data['known_controls'] = values
    for spec in _KNOWN_CONTROLS:
        owner_key = str(spec.get('owner_key') or '')
        prop_name = str(spec.get('prop') or '')
        if not owner_key or not prop_name:
            continue
        owner = _resolve_owner(context, owner_key)
        if owner is None or not hasattr(owner, prop_name):
            continue
        try:
            values[_state_key(owner_key, prop_name)] = bool(getattr(owner, prop_name))
        except Exception:
            continue
    data['version'] = 1
    if persist:
        _write_state(data)
    else:
        _set_session_state(data)


def apply_saved_always_on_states(context=None, *, auto_load_enabled: bool = False, apply_runtime: bool = True) -> None:
    # Explicit non-draw persistence boundary.  Prime the bounded data snapshot
    # once before any cache-only value lookup.
    _read_state()
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return
    for spec in _KNOWN_CONTROLS:
        owner_key = str(spec.get('owner_key') or '')
        prop_name = str(spec.get('prop') or '')
        alias = str(spec.get('alias') or '')
        saved = _stored_known_value(owner_key, prop_name, bool(spec.get('default', False)))
        if saved and auto_load_enabled and alias and alias != 'core':
            _load_alias(alias)
        _assign_owner_value(context, spec, bool(saved))
        if apply_runtime:
            _apply_special_control(context, spec, bool(saved))


class SSS_OT_toggle_known_persistent_control(bpy.types.Operator):
    bl_idname = 'smart_sculpt.toggle_known_persistent_control'
    bl_label = 'Toggle Always-on Control'
    bl_description = 'Enable or disable an always-on Smart Sculpt function. Saving follows N-panel State Save.'
    bl_options = {'UNDO'}

    alias: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    owner_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    prop_name: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        spec = _spec_for(str(getattr(properties, 'alias', '') or ''), str(getattr(properties, 'owner_key', '') or ''), str(getattr(properties, 'prop_name', '') or ''))
        if spec:
            return _tooltip(
                str(spec.get('description_en') or '') + ' Click to switch this item between On and Off. If N-panel State Save is enabled, the change is written immediately; otherwise it is written when the current scene closes or Save Preferences is run.',
                str(spec.get('description_ja') or '') + ' クリックすると有効 / 無効を切り替えます。Nパネル状態保存が有効な場合は即時保存し、無効な場合は現在のシーンを閉じる時またはプリファレンス保存時に保存します。',
            )
        return _tooltip(
            'Enable or disable this always-on function. Saving follows N-panel State Save: immediate when enabled, or scene-close/Save Preferences timing when disabled.',
            'この常時起動機能の有効 / 無効を切り替えます。保存タイミングはNパネル状態保存に従い、有効時は即時、無効時はシーン終了時またはプリファレンス保存時です。',
        )

    def execute(self, context):
        spec = _spec_for(str(self.alias or ''), str(self.owner_key or ''), str(self.prop_name or ''))
        if spec is None:
            self.report({'WARNING'}, _t('The selected always-on item was not found.', '選択した常時起動項目が見つかりませんでした。'))
            return {'CANCELLED'}
        current = _current_known_value(context, spec)
        enabled = not current
        _set_known_value(context, spec, enabled)
        try:
            for area in getattr(getattr(context, 'screen', None), 'areas', ()):
                area.tag_redraw()
        except Exception:
            pass
        self.report({'INFO'}, _t('Always-on setting updated.', '常時起動設定を更新しました。'))
        return {'FINISHED'}


classes = (SSS_OT_toggle_known_persistent_control,)


def _runtime_operator_id() -> str:
    try:
        from .. import feature_toggle
        getter = getattr(feature_toggle, 'toggle_operator_id', None)
        if callable(getter):
            op_id = str(getter() or '').strip()
            if op_id:
                return op_id
        configure = getattr(feature_toggle, 'configure', None)
        if callable(configure):
            configure()
        return str(getattr(feature_toggle, '_OPERATOR_ID', '') or '').strip()
    except Exception:
        return ''


def _runtime_feature_entries() -> list[dict[str, Any]]:
    try:
        from .. import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        if not callable(entries_fn):
            return []
        entries = list(entries_fn() or [])
        entries.sort(key=lambda item: (str(item.get('tool_label') or item.get('alias') or '').lower(), str(item.get('key') or '').lower()))
        return entries
    except Exception:
        return []


def _operator_button(layout, operator_id: str, *, text: str, icon: str, depress: bool):
    """Compatibility fallback for legacy runtime toggles that cannot expose a BoolProperty."""
    kwargs = {'text': text, 'icon': utils.safe_icon(icon), 'depress': bool(depress)}
    try:
        return layout.operator(operator_id, **kwargs)
    except TypeError:
        kwargs.pop('depress', None)
        try:
            return layout.operator(operator_id, **kwargs)
        except TypeError:
            kwargs.pop('icon', None)
            return layout.operator(operator_id, **kwargs)


def _draw_switch_row(layout, *, label: str, icon: str, enabled: bool, data=None, prop_name: str = '', operator_id: str = '', props: dict[str, Any] | None = None) -> bool:
    """Draw one Smart Rig-style always-on row.

    The visible UI is intentionally limited to the tool/function name on the
    left and one checkbox-style Enabled/Disabled button on the right.  Detailed
    usage text remains in the BoolProperty/operator tooltip.
    """
    layout = _compact_npanel_layout(layout)
    row = _compact_npanel_layout(layout.row(align=True))
    try:
        row.scale_y = 0.95
    except Exception:
        pass
    split = row.split(factor=0.72, align=True)
    left = _compact_npanel_layout(split.row(align=True))
    left.label(text=str(label or ''))

    right = _compact_npanel_layout(split.row(align=True))
    try:
        right.alignment = 'RIGHT'
    except Exception:
        pass
    button_text = _t('On', '有効') if enabled else _t('Off', '無効')
    icon_id = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    if data is not None and prop_name and hasattr(data, prop_name):
        try:
            right.row(align=True).prop(data, prop_name, text=button_text, icon=utils.safe_icon(icon_id), toggle=True)
            return True
        except TypeError:
            try:
                right.row(align=True).prop(data, prop_name, text=button_text, toggle=True)
                return True
            except Exception:
                pass
        except Exception:
            pass
    if operator_id:
        try:
            op = _operator_button(right.row(align=True), operator_id, text=button_text, icon=icon_id, depress=bool(enabled))
            for key, value in (props or {}).items():
                try:
                    setattr(op, key, value)
                except Exception:
                    pass
            return True
        except Exception:
            pass
    right.enabled = False
    right.label(text=button_text, icon=utils.safe_icon(icon_id))
    return False


def _draw_known_controls(layout, context) -> int:
    # Panel draw must remain read-only in Blender 5.1.  Saved values are applied
    # during register/load/scene-switch handlers, not while the UI is drawing.
    count = 0
    for spec in _KNOWN_CONTROLS:
        owner_key = str(spec.get('owner_key') or '')
        prop_name = str(spec.get('prop') or '')
        owner = _resolve_owner(context, owner_key)
        if owner is None or not prop_name or not hasattr(owner, prop_name):
            continue
        enabled = _current_known_value(context, spec)
        label = _t(str(spec.get('label_en') or ''), str(spec.get('label_ja') or ''))
        if not label:
            continue
        _draw_switch_row(
            layout,
            label=label,
            icon=str(spec.get('icon') or 'PLUGIN'),
            enabled=enabled,
            data=owner,
            prop_name=prop_name,
            operator_id=SSS_OT_toggle_known_persistent_control.bl_idname,
            props={
                'alias': str(spec.get('alias') or ''),
                'owner_key': owner_key,
                'prop_name': prop_name,
            },
        )
        count += 1
        if prop_name == 'always_on_npanel_autosave_restore':
            try:
                layout.separator(factor=0.5)
            except Exception:
                pass
    return count


def _draw_runtime_features(layout, context) -> int:
    # Captured runtime features are intentionally not drawn as operator-backed
    # buttons here.  The stable Smart Rig-style UI uses saved BoolProperties so
    # Blender owns the active blue overlay.  Runtime effects that need startup
    # control are exposed through _KNOWN_CONTROLS above.
    return 0


def draw_persistent_controls(layout, context, settings=None) -> int:
    """Draw the centralized always-on switch group at the top of the N-panel."""
    layout = _compact_npanel_layout(layout)
    box = layout.box()
    _compact_npanel_layout(box)
    # The header is the shared Smart Sculpt top-level section header
    # (ui._draw_section_header: triangle, borderless icon+title, 0.35 gap,
    # compact help) so it lines up with every other top-level section.  Section
    # key 'always_on' reads and toggles the same show_always_on_toggles state.
    # The sibling ui module is taken from sys.modules (no import while drawing);
    # the hand-drawn header below is only the fallback.
    is_open = None
    try:
        ui_module = sys.modules.get(f'{__package__}.ui') if __package__ else None
        draw_section_header = getattr(ui_module, '_draw_section_header', None)
        if callable(draw_section_header):
            is_open = bool(draw_section_header(box, context, settings, 'always_on', 'Always-on Toggles', '常時機能切り替え', 'TIME', 'always_on', default=False))
    except Exception:
        is_open = None
    if is_open is None:
        is_open = bool(getattr(settings, 'show_always_on_toggles', False)) if settings is not None else False
        header = box.row(align=True)
        _compact_npanel_layout(header)
        header.label(text=_t('Always-on Toggles', '常時機能切り替え'), icon=utils.safe_icon('TIME'))
        header.separator(factor=0.35)
        _draw_help_button(header, 'always_on')
    if not is_open:
        return 0

    col = box.column(align=True)
    _compact_npanel_layout(col)
    total = _draw_known_controls(col, context) + _draw_runtime_features(col, context)
    if total == 0:
        box.label(text=_t('No always-on entries are currently detected.', '現在検出された常時起動項目はありません。'))
    return total


def clear_session_cache() -> None:
    """Release bounded data-only persistence snapshots on disable/reload."""
    global _SESSION_STATE, _STATE_LOADED
    _SESSION_STATE.clear()
    _STATE_LOADED = False
