# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

from . import utils, utils as _smart_utils
from .. import storage as _smart_storage
from datetime import datetime
import json
from pathlib import Path

import bpy
from bpy.types import Operator



EXTENSIONS = utils.EXTENSIONS

def _export_attempts(fmt: str, filepath: str):
    return {
        'OBJ': [
            ('wm.obj_export', {'filepath': filepath, 'export_selected_objects': True}),
            ('wm.obj_export', {'filepath': filepath}),
            ('export_scene.obj', {'filepath': filepath, 'use_selection': True}),
            ('export_scene.obj', {'filepath': filepath}),
        ],
        'USD': [
            ('wm.usd_export', {'filepath': filepath, 'selected_objects_only': True}),
            ('wm.usd_export', {'filepath': filepath}),
        ],
        'FBX': [
            ('export_scene.fbx', {'filepath': filepath, 'use_selection': True}),
            ('export_scene.fbx', {'filepath': filepath}),
        ],
        'ABC': [
            ('wm.alembic_export', {'filepath': filepath, 'selected': True}),
            ('wm.alembic_export', {'filepath': filepath}),
        ],
        'PLY': [
            ('wm.ply_export', {'filepath': filepath, 'export_selected_objects': True}),
            ('wm.ply_export', {'filepath': filepath}),
            ('export_mesh.ply', {'filepath': filepath, 'use_selection': True}),
            ('export_mesh.ply', {'filepath': filepath}),
        ],
    }[fmt]



def _import_attempts(fmt: str, filepath: str):
    return {
        'OBJ': [
            ('wm.obj_import', {'filepath': filepath}),
            ('import_scene.obj', {'filepath': filepath}),
        ],
        'USD': [
            ('wm.usd_import', {'filepath': filepath}),
        ],
        'FBX': [
            ('import_scene.fbx', {'filepath': filepath}),
        ],
        'ABC': [
            ('wm.alembic_import', {'filepath': filepath}),
        ],
        'PLY': [
            ('wm.ply_import', {'filepath': filepath}),
            ('import_mesh.ply', {'filepath': filepath}),
        ],
    }[fmt]



def _exchange_scope(context) -> str:
    settings = utils.settings_from_context(context)
    return getattr(settings, "exchange_scope", 'ACTIVE') if settings else 'ACTIVE'



def _export_objects(context):
    scope = _exchange_scope(context)
    active = utils.active_mesh_object(context) or context.view_layer.objects.active
    if active is not None and getattr(active, 'type', None) != 'MESH':
        active = None

    if scope == 'SELECTED':
        meshes = utils.selected_mesh_objects(context)
        if active is not None:
            if active in meshes:
                meshes = [active] + [obj for obj in meshes if obj != active]
            else:
                meshes.insert(0, active)
        if meshes:
            return meshes, active or meshes[0], scope

    if active is not None:
        return [active], active, 'ACTIVE'
    return [], None, scope



def _export_stem(active_obj, export_objects, scope: str) -> str:
    base = utils.sanitize_filename_component(active_obj.name if active_obj else 'smart_sculpt')
    if scope != 'SELECTED' or len(export_objects) <= 1:
        return base
    return f"{base}_set_{len(export_objects)}"



def _build_export_path(context, fmt: str, export_objects, scope: str):
    settings = utils.settings_from_context(context)
    ext = EXTENSIONS[fmt]
    stem = _export_stem(export_objects[0] if export_objects else None, export_objects, scope)
    directory = utils.exchange_directory(context)
    if not (settings and getattr(settings, "exchange_timestamped_export", True)):
        return directory / f"{stem}{ext}"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return directory / f"{stem}_{timestamp}{ext}"


def _file_signature(filepath: Path) -> tuple[bool, int, int]:
    try:
        stat = filepath.stat()
        mtime_ns = int(getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1_000_000_000)))
        return True, int(stat.st_size), mtime_ns
    except Exception:
        return False, 0, 0



def _remove_zero_byte_file(filepath: Path) -> None:
    try:
        if filepath.is_file() and filepath.stat().st_size <= 0:
            filepath.unlink(missing_ok=True)
    except Exception:
        pass



def _export_file_is_valid(filepath: Path, before_signature: tuple[bool, int, int]) -> bool:
    exists, size, mtime_ns = _file_signature(filepath)
    if not exists or size <= 0:
        return False
    if not before_signature[0]:
        return True
    return (exists, size, mtime_ns) != before_signature



def _topology_payload_for_object(obj):
    counts = utils.topology_signature(obj)
    return {
        "name": str(obj.name),
        "safe_name": utils.sanitize_filename_component(obj.name),
        "vertices": counts[0],
        "edges": counts[1],
        "faces": counts[2],
    }



def _write_export_manifest(context, export_objects, fmt: str, filepath: Path, scope: str):
    if not export_objects or filepath is None:
        return None
    try:
        objects_payload = [_topology_payload_for_object(obj) for obj in export_objects if obj is not None and getattr(obj, 'type', None) == 'MESH']
        if not objects_payload:
            return None
        payload = {
            "addon": "Smart Sculpt",
            "version": utils.addon_version_string(),
            "blender_version": getattr(bpy.app, "version_string", ""),
            "source_blend_file": getattr(bpy.data, "filepath", "") or "",
            "scope": str(scope),
            "format": str(fmt),
            "filepath": str(filepath),
            "exported_at": datetime.now().isoformat(timespec="seconds"),
            "active_object_name": str(export_objects[0].name),
            "safe_active_object_name": utils.sanitize_filename_component(export_objects[0].name),
            "object_count": len(objects_payload),
            "object_names": [item["name"] for item in objects_payload],
            "safe_object_names": [item["safe_name"] for item in objects_payload],
            "totals": {
                "vertices": sum(int(item["vertices"]) for item in objects_payload),
                "edges": sum(int(item["edges"]) for item in objects_payload),
                "faces": sum(int(item["faces"]) for item in objects_payload),
            },
            "objects": objects_payload,
        }
        manifest_path = filepath.with_suffix(filepath.suffix + ".json")
        _smart_storage.atomic_write_json(manifest_path, payload, indent=2, ensure_ascii=False, sort_keys=True)
        return manifest_path
    except Exception:
        return None



def _load_manifest_for_exchange_file(filepath: Path):
    manifest_path = filepath.with_suffix(filepath.suffix + ".json")
    if not manifest_path.is_file():
        return None
    try:
        data = json.loads(manifest_path.read_text(encoding='utf-8'))
    except Exception:
        return None
    return data if isinstance(data, dict) else None



def _preferred_safe_names(context) -> list[str]:
    names: list[str] = []
    active = utils.active_mesh_object(context) or context.view_layer.objects.active
    if active is not None and getattr(active, 'type', None) == 'MESH':
        names.append(utils.sanitize_filename_component(active.name))
    for obj in utils.selected_mesh_objects(context):
        safe_name = utils.sanitize_filename_component(obj.name)
        if safe_name not in names:
            names.append(safe_name)
    return names



def _candidate_score(filepath: Path, preferred_safe_names: list[str]) -> tuple[int, float]:
    try:
        mtime = float(filepath.stat().st_mtime)
    except Exception:
        mtime = 0.0
    if not preferred_safe_names:
        return (0, mtime)

    score = 0
    stem = filepath.stem
    for safe_name in preferred_safe_names:
        if stem == safe_name or stem.startswith(f"{safe_name}_"):
            score = max(score, 40)

    manifest = _load_manifest_for_exchange_file(filepath)
    if isinstance(manifest, dict):
        manifest_names = []
        for key in ('active_object_name', 'safe_active_object_name'):
            value = manifest.get(key)
            if isinstance(value, str) and value:
                manifest_names.append(value)
        for key in ('object_names', 'safe_object_names'):
            values = manifest.get(key)
            if isinstance(values, list):
                for value in values:
                    if isinstance(value, str) and value:
                        manifest_names.append(value)
        safe_manifest_names = {utils.sanitize_filename_component(value) for value in manifest_names}
        overlap = len(set(preferred_safe_names) & safe_manifest_names)
        if overlap:
            score = max(score, 100 + overlap)
            if str(manifest.get('scope', '')) == 'SELECTED' and len(preferred_safe_names) > 1:
                score += 10
    return (score, mtime)



def _latest_exchange_file(directory: Path, suffix: str, preferred_safe_names: list[str]) -> Path | None:
    files = [path for path in directory.glob(f"*{suffix}") if path.is_file()]
    if not files:
        return None
    files.sort(key=lambda path: _candidate_score(path, preferred_safe_names), reverse=True)
    return files[0]



def _select_imported_objects(context, new_object_names: set[str]) -> int:
    imported = [bpy.data.objects.get(name) for name in sorted(new_object_names)]
    imported = [obj for obj in imported if obj is not None and obj.type == 'MESH']
    if not imported:
        return 0
    utils.select_only(context, imported, active=imported[0])
    return len(imported)


def _restore_previous_context(context, selection_state) -> None:
    try:
        utils.restore_selection_state(context, selection_state)
    except Exception:
        pass


class SSS_OT_export_exchange(Operator):
    bl_idname = "smart_sculpt.export_exchange"
    bl_label = "Export Exchange File"
    bl_description = _smart_utils.localize_bilingual_text((
        "Export the active mesh or the selected mesh set to the configured exchange folder using manifest-aware round-trip helpers. "
        "This is a safer Blender-native approximation of one-click handoff workflows such as GoZ, and it can optionally append a timestamp to avoid overwriting older iterations. "
        "/ アクティブメッシュ、または選択中メッシュセットを、マニフェスト付きの安全な受け渡しとして設定フォルダへ書き出します。"
        "GoZ のようなワンクリック往復フローを Blender ネイティブで安全側に近似し、必要に応じてタイムスタンプで古い反復ファイルの上書きを防ぎます。"
    ))
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        export_objects, active_obj, _scope = _export_objects(context)
        return bool(export_objects) and active_obj is not None

    def execute(self, context):
        settings = utils.settings_from_context(context)
        fmt = settings.exchange_format if settings else 'OBJ'
        export_objects, active_obj, scope = _export_objects(context)
        if not export_objects or active_obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No exportable mesh objects found. / 書き出し可能なメッシュオブジェクトが見つかりません。"))
            return {'CANCELLED'}
        try:
            path = _build_export_path(context, fmt, export_objects, scope)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not prepare export path: {v0} / 書き出しパスを準備できませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        success = False
        last_error = None
        before_signature = _file_signature(path)
        with utils.preserved_selection_and_mode(context, active_obj, 'OBJECT'):
            utils.select_only(context, export_objects, active=active_obj)
            for op_path, kwargs in _export_attempts(fmt, str(path)):
                try:
                    utils.call_operator_by_paths((op_path,), [kwargs])
                    if _export_file_is_valid(path, before_signature):
                        success = True
                        break
                    _remove_zero_byte_file(path)
                    last_error = RuntimeError(f"Exporter {op_path} finished without writing a usable file")
                except Exception as exc:
                    _remove_zero_byte_file(path)
                    last_error = exc
        if not success:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Export failed for format {v0}: {v1} / {v2} 書き出しに失敗しました: {v3}', v0=fmt, v1=last_error, v2=fmt, v3=last_error))
            return {'CANCELLED'}

        manifest_path = _write_export_manifest(context, export_objects, fmt, path, scope)
        object_count = len(export_objects)
        if manifest_path is not None:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Exported {v0} object(s) to {v1} (+ {v2}) / {v3} 個を書き出し、{v4} と {v5} を保存しました。', v0=object_count, v1=path.name, v2=manifest_path.name, v3=object_count, v4=path.name, v5=manifest_path.name))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Exported {v0} object(s) to {v1} / {v2} 個を {v3} へ書き出しました。', v0=object_count, v1=path.name, v2=object_count, v3=path.name))
        return {'FINISHED'}


class SSS_OT_import_latest_exchange(Operator):
    bl_idname = "smart_sculpt.import_latest_exchange"
    bl_label = "Import Latest Exchange File"
    bl_description = _smart_utils.localize_bilingual_text((
        "Import the newest matching exchange file from the configured folder, preferring sidecar manifests that match the active object or current selection when possible. "
        "This keeps repeated round-trips more predictable than a simple newest-file import. "
        "/ 設定フォルダから、可能ならアクティブオブジェクトや現在の選択に一致するサイドカーマニフェストを優先して、最適な最新受け渡しファイルを読み込みます。"
        "単純な『一番新しいだけ』の読み込みより、反復的な往復作業を安定させます。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        fmt = settings.exchange_format if settings else 'OBJ'
        ext = EXTENSIONS[fmt]
        try:
            directory = utils.exchange_directory(context)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not access exchange folder: {v0} / 受け渡しフォルダへアクセスできませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        preferred_safe_names = _preferred_safe_names(context)
        latest = _latest_exchange_file(directory, ext, preferred_safe_names)
        if latest is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('No {v0} files found in {v1} / {v2} に {v3} ファイルがありません。', v0=ext, v1=directory, v2=directory, v3=ext))
            return {'CANCELLED'}

        selection_state = utils.capture_selection_state(context)
        prev_active = context.view_layer.objects.active
        if prev_active is not None and getattr(prev_active, 'type', None) == 'MESH':
            try:
                utils.ensure_object_mode(context, prev_active)
            except Exception:
                pass

        before_names = set(bpy.data.objects.keys())
        success = False
        last_error = None
        for op_path, kwargs in _import_attempts(fmt, str(latest)):
            try:
                utils.call_operator_by_paths((op_path,), [kwargs])
                success = True
                break
            except Exception as exc:
                last_error = exc
        if not success:
            _restore_previous_context(context, selection_state)
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Import failed for format {v0}: {v1} / {v2} 読み込みに失敗しました: {v3}', v0=fmt, v1=last_error, v2=fmt, v3=last_error))
            return {'CANCELLED'}

        imported_objects = utils.new_objects_from_names(before_names)
        mesh_objects = [obj for obj in imported_objects if getattr(obj, 'type', None) == 'MESH']
        valid_meshes, invalid_meshes = utils.filter_meaningful_mesh_objects(mesh_objects)
        dropped = utils.delete_objects_if_possible(invalid_meshes)
        imported_count = _select_imported_objects(context, {obj.name for obj in valid_meshes}) if valid_meshes else 0
        manifest = _load_manifest_for_exchange_file(latest)
        try:
            expected_count = int(manifest.get('object_count') or 0) if isinstance(manifest, dict) else 0
        except Exception:
            expected_count = 0
        if imported_count > 0:
            drop_note = _smart_utils.localize_bilingual_format(' Dropped {v0} invalid imported mesh object(s). / 不正な読み込みメッシュ {v1} 個を削除しました。', v0=dropped, v1=dropped) if dropped else ""
            manifest_note = _smart_utils.localize_bilingual_format(' Manifest expected {v0}. / マニフェスト想定 {v1} 個。', v0=expected_count, v1=expected_count) if expected_count > 0 and imported_count != expected_count else ""
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Imported {v0} ({v1} new mesh object(s)).{v2}{v3} / {v4} を読み込み、新規メッシュ {v5} 個を選択しました。', v0=latest.name, v1=imported_count, v2=drop_note, v3=manifest_note, v4=latest.name, v5=imported_count))
            return {'FINISHED'}

        removed_on_failure = utils.delete_objects_if_possible(imported_objects)
        _restore_previous_context(context, selection_state)
        if mesh_objects:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Import finished but did not produce a usable mesh object from {v0}; removed {v1} imported object(s). / {v2} の読み込みは完了しましたが、使用可能なメッシュオブジェクトは生成されなかったため、読み込みオブジェクト {v3} 個を削除しました。', v0=latest.name, v1=removed_on_failure, v2=latest.name, v3=removed_on_failure))
            return {'CANCELLED'}
        self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Import finished but did not add any mesh objects from {v0}; removed {v1} imported object(s). / {v2} を読み込みましたが、メッシュオブジェクトは追加されなかったため、読み込みオブジェクト {v3} 個を削除しました。', v0=latest.name, v1=removed_on_failure, v2=latest.name, v3=removed_on_failure))
        return {'CANCELLED'}


class SSS_OT_cleanup_generated_data(Operator):
    bl_idname = "smart_sculpt.cleanup_generated_data"
    bl_label = "Cleanup Generated Data"
    bl_description = _smart_utils.localize_bilingual_text((
        "Remove generated helpers, temporary cutters, proxy objects, snapshot previews, scattered helpers, unused procedural textures, and optionally hidden snapshots. "
        "/ 生成済みヘルパー、一時カッター、プロキシオブジェクト、スナップショット比較プレビュー、散布ヘルパー、未使用のプロシージャルテクスチャ、必要に応じて隠しスナップショットも整理して削除します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        include_snapshots = settings.cleanup_include_snapshots if settings else False
        result = utils.cleanup_generated_data(include_snapshots=include_snapshots)
        self.report(
            {'INFO'},
            _smart_utils.localize_bilingual_format(
                "Cleanup complete: {objects} object(s), {textures} texture(s), {collections} collection(s), "
                "restored sources {restored_sources}, cleared preview refs {cleared_preview_refs}, "
                "and cleared recovery refs {cleared_recovery_refs}. "
                "/ 整理完了: オブジェクト {objects} 個、テクスチャ {textures} 個、コレクション {collections} 個、"
                "復元した元オブジェクト {restored_sources} 件、解除したプレビュー参照 {cleared_preview_refs} 件、"
                "解除した回復バックアップ参照 {cleared_recovery_refs} 件。",
                objects=result['objects'],
                textures=result['textures'],
                collections=result['collections'],
                restored_sources=result['restored_sources'],
                cleared_preview_refs=result['cleared_preview_refs'],
                cleared_recovery_refs=result['cleared_recovery_refs'],
            ),
        )
        return {'FINISHED'}


classes = (
    SSS_OT_export_exchange,
    SSS_OT_import_latest_exchange,
    SSS_OT_cleanup_generated_data,
)
