# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Iterable

from .. import _sss_lifecycle as _lifecycle

_ICON_COLLECTION_NAME = "smart_sculpt_suite_large_icons"
_PREVIEW_COLLECTIONS: dict[str, object] = {}
_LOADED_ICON_KEYS: set[str] = set()
_REGISTERED_ONCE = False
_PREVIEWS_MODULE = None
_ICON_NAMES_CACHE: tuple[str, ...] | None = None
_ICON_PATH_MAP_CACHE: dict[str, Path] | None = None

# Custom icons are limited to composite Smart Sculpt functions for which Blender's
# built-in icon set does not provide a single clear functional match.  Actions
# with a clear standard Blender icon return icon_value 0 and use the fallback
# built-in icon instead.
SMART_ACTION_ICON_KEYS = {
    'APEX_AUTOPILOT_PASS': 'smart_apex_autopilot_pass',
    'SUPREME_STUDIO_PIPELINE': 'smart_supreme_studio_pipeline',
    'PRECISION_FRONTIER_PASS': 'smart_precision_frontier_pass',
    'ADAPTIVE_MASTER_PASS': 'smart_adaptive_master_pass',
    'MESH_DOCTOR_PRO': 'smart_mesh_doctor_pro',
    'SURFACE_DETAIL_SYNTH': 'smart_surface_detail_synth',
    'SCULPT_LAYER_STACK_PRO': 'smart_sculpt_layer_stack_pro',
    'SYMMETRY_POSE_GUARD': 'smart_symmetry_pose_guard',
    'SCULPT_TRANSFER_PROFILE': 'smart_sculpt_transfer_profile',
    'BSPHERE_ARMATURE_BLOCKOUT': 'smart_bsphere_armature_blockout',
    'MULTI_OBJECT_HARMONIZER': 'smart_multi_object_harmonizer',
    'SPEED_BLOCKOUT': 'smart_speed_blockout',
    'QUICK_POLYGROUP_PLUS': 'smart_quick_polygroup_plus',
    'ANCHOR_BEND_PRO': 'smart_anchor_bend_pro',
    'VOXEL_HYBRID_SURFACE': 'smart_voxel_hybrid_surface',
    'WRAP_RETOPO_UV': 'smart_wrap_retopo_uv',
    'MUSCLE_LAYER_DRIVER': 'smart_muscle_layer_driver',
    'CURVE_SWEEP_RAIL_CUT': 'smart_curve_sweep_rail_cut',
    'PROCEDURAL_MICRODETAIL_BRUSH': 'smart_procedural_microdetail_brush',
    'ENVIRONMENT_GROWTH': 'smart_environment_growth',
    'INTEROP_ROUNDTRIP': 'smart_interop_roundtrip',
    'MESH_CLEANER_PRO': 'smart_mesh_cleaner_pro',
    'FULL_SAFE_SETUP': 'smart_full_safe_setup',
}

SMART_ACTION_FALLBACK_ICONS = {
    'APEX_AUTOPILOT_PASS': 'VIEWZOOM',
    'SUPREME_STUDIO_PIPELINE': 'SEQ_STRIP_META',
    'PRECISION_FRONTIER_PASS': 'VIEWZOOM',
    'ADAPTIVE_MASTER_PASS': 'TOOL_SETTINGS',
    'MESH_DOCTOR_PRO': 'CHECKMARK',
    'SURFACE_DETAIL_SYNTH': 'TEXTURE',
    'SCULPT_LAYER_STACK_PRO': 'SHAPEKEY_DATA',
    'SYMMETRY_POSE_GUARD': 'MOD_MIRROR',
    'SCULPT_TRANSFER_PROFILE': 'IMPORT',
    'BSPHERE_ARMATURE_BLOCKOUT': 'ARMATURE_DATA',
    'MULTI_OBJECT_HARMONIZER': 'GROUP',
    'SPEED_BLOCKOUT': 'SCULPTMODE_HLT',
    'QUICK_POLYGROUP_PLUS': 'MESH_GRID',
    'ANCHOR_BEND_PRO': 'EMPTY_DATA',
    'VOXEL_HYBRID_SURFACE': 'MOD_REMESH',
    'HARD_SURFACE_CUTKIT': 'MOD_BOOLEAN',
    'WRAP_RETOPO_UV': 'GROUP_UVS',
    'VELLUM_CLOTH_DRAPE': 'MOD_CLOTH',
    'MUSCLE_LAYER_DRIVER': 'DRIVER',
    'CURVE_SWEEP_RAIL_CUT': 'CURVE_DATA',
    'PROCEDURAL_MICRODETAIL_BRUSH': 'BRUSH_DATA',
    'ENVIRONMENT_GROWTH': 'PARTICLES',
    'PHOTO_REFERENCE_HANDOFF': 'IMAGE_DATA',
    'INTEROP_ROUNDTRIP': 'FILE_REFRESH',
    'MESH_CLEANER_PRO': 'BRUSH_DATA',
    'FULL_SAFE_SETUP': 'FILE_TICK',
}

# Backward-compatible aliases for old Smart Sculpt icon keys.  The files are not
# bundled anymore; these aliases only prevent stale runtime requests from falling
# through to missing previews after add-on reloads.
ICON_RENAME_ALIASES = {'smart_default': 'smart_default'}


def _previews_module():
    """Return Blender's preview module and retry if it was unavailable earlier."""
    global _PREVIEWS_MODULE
    if _PREVIEWS_MODULE is not None:
        return _PREVIEWS_MODULE
    try:
        module = importlib.import_module('bpy.utils.previews')
    except Exception:
        module = None
    if module is None:
        try:
            from bpy.utils import previews as module  # type: ignore
        except Exception:
            module = None
    if module is None:
        try:
            import bpy  # type: ignore
            module = getattr(getattr(bpy, 'utils', None), 'previews', None)
        except Exception:
            module = None
    _PREVIEWS_MODULE = module
    return module


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def icons_dir() -> Path:
    return package_root() / 'icons'


def _candidate_icon_dirs() -> tuple[Path, ...]:
    root = package_root()
    return (root / 'icons',)


def reference_dir() -> Path:
    return package_root() / 'assets' / 'reference'


def reference_image_path() -> str:
    return str(reference_dir() / 'smart_sculpt_reference.png')


def _normalized_key(value: str | None) -> str:
    text = str(value or '').strip().replace('\\', '/').split('/')[-1]
    if text.lower().endswith('.png'):
        text = text[:-4]
    return ''.join(ch.lower() if ch.isalnum() else '_' for ch in text).strip('_')


def _canonical_key(value: str | None) -> str:
    key = _normalized_key(value)
    return ICON_RENAME_ALIASES.get(key, key)


def iter_icon_names() -> Iterable[str]:
    global _ICON_NAMES_CACHE
    if _ICON_NAMES_CACHE is not None:
        return _ICON_NAMES_CACHE
    names = {_canonical_key(value) for value in SMART_ACTION_ICON_KEYS.values()}
    names.add(_canonical_key('smart_default'))
    try:
        for folder in _candidate_icon_dirs():
            for path in folder.glob('*.png'):
                names.add(_canonical_key(path.stem))
    except Exception:
        pass
    _ICON_NAMES_CACHE = tuple(sorted(name for name in names if name))
    return _ICON_NAMES_CACHE


def _icon_path_map() -> dict[str, Path]:
    global _ICON_PATH_MAP_CACHE
    if _ICON_PATH_MAP_CACHE is not None:
        return _ICON_PATH_MAP_CACHE
    mapping: dict[str, Path] = {}
    for folder in _candidate_icon_dirs():
        try:
            if not folder.exists():
                continue
            for path in sorted(folder.glob('*.png')):
                key = _canonical_key(path.stem)
                if key and key not in mapping:
                    mapping[key] = path
        except Exception:
            continue
    _ICON_PATH_MAP_CACHE = mapping
    return _ICON_PATH_MAP_CACHE


def _preview_collection():
    return _PREVIEW_COLLECTIONS.get(_ICON_COLLECTION_NAME)


def _collection_has_key(pcoll, key: str) -> bool:
    if pcoll is None or not key:
        return False
    try:
        return pcoll.get(key) is not None
    except Exception:
        pass
    try:
        return key in pcoll
    except Exception:
        return False


def _collection_get(pcoll, key: str):
    if pcoll is None or not key:
        return None
    try:
        return pcoll.get(key)
    except Exception:
        pass
    try:
        return pcoll[key]
    except Exception:
        return None


def register(*, force: bool = False) -> None:
    """Register bundled custom PNG icons with Blender previews.

    The directory is scanned at runtime so Blender Extension namespace imports
    and user_default installs resolve the same icon files.
    """
    global _REGISTERED_ONCE
    previews = _previews_module()
    if previews is None:
        return
    if force:
        unregister()
    pcoll = _preview_collection()
    if pcoll is not None and _LOADED_ICON_KEYS and not force:
        expected = set(iter_icon_names())
        if expected.issubset(_LOADED_ICON_KEYS):
            return
    if pcoll is None:
        try:
            pcoll = previews.new()
        except Exception:
            return

        def _remove_preview_collection(value):
            preview_module, collection = value
            preview_module.remove(collection)

        resource = (previews, pcoll)
        try:
            _lifecycle.acquire_resource(
                'preview_collection',
                resource,
                _remove_preview_collection,
                native_remover=previews.remove,
                metadata={'collection_name': _ICON_COLLECTION_NAME, 'collection_identity': id(pcoll)},
            )
        except Exception:
            try:
                previews.remove(pcoll)
            except Exception:
                pass
            raise
        _PREVIEW_COLLECTIONS[_ICON_COLLECTION_NAME] = pcoll

    mapping = _icon_path_map()
    loaded: set[str] = set()
    for name in iter_icon_names():
        path = mapping.get(name)
        if path is None or not path.exists():
            continue
        if _collection_has_key(pcoll, name):
            loaded.add(name)
            continue
        try:
            pcoll.load(name, str(path), 'IMAGE')
            loaded.add(name)
        except Exception:
            continue
    _LOADED_ICON_KEYS.clear()
    _LOADED_ICON_KEYS.update(loaded)
    _REGISTERED_ONCE = True


def unregister() -> None:
    global _REGISTERED_ONCE, _PREVIEWS_MODULE, _ICON_NAMES_CACHE, _ICON_PATH_MAP_CACHE
    previews = _previews_module()
    for pcoll in list(_PREVIEW_COLLECTIONS.values()):
        resource = (previews, pcoll)
        released = False
        try:
            journal = _lifecycle.current_journal()
            if journal is not None:
                released = bool(journal.release_matching(
                    lambda record: record.kind == 'preview_collection'
                    and isinstance(record.value, tuple)
                    and len(record.value) == 2
                    and record.value[1] is pcoll
                ))
        except Exception:
            released = False
        if not released and previews is not None:
            try:
                previews.remove(pcoll)
            except Exception:
                pass
    _PREVIEW_COLLECTIONS.clear()
    _LOADED_ICON_KEYS.clear()
    _REGISTERED_ONCE = False
    _PREVIEWS_MODULE = None
    _ICON_NAMES_CACHE = None
    _ICON_PATH_MAP_CACHE = None


def ensure_registered(requested: str | None = None, *, force: bool = False) -> None:
    """Ensure previews are registered outside volatile panel redraw paths.

    Preview image loading is intentionally conservative.  The normal add-on
    register() call loads all bundled PNG icons once.  During UI drawing, callers
    should prefer already-loaded preview IDs and fall back to built-in icons if
    the collection is unavailable instead of forcing a reload from inside a panel
    handler.
    """
    key = _canonical_key(requested)
    pcoll = _preview_collection()
    if force:
        register(force=True)
        return
    if pcoll is None:
        if not _REGISTERED_ONCE:
            register(force=False)
        return
    if key and _collection_has_key(pcoll, key):
        return
    if not _LOADED_ICON_KEYS and not _REGISTERED_ONCE:
        register(force=False)


def icon_value(name: str | None, *, fallback: str = 'smart_default', register_if_needed: bool = False) -> int:
    key = _canonical_key(name)
    fallback_key = _canonical_key(fallback) or _canonical_key('smart_default')
    if register_if_needed:
        ensure_registered(key or fallback_key)
    pcoll = _preview_collection()
    if pcoll is None:
        return 0
    for candidate in (key, fallback_key, _canonical_key('smart_default')):
        if not candidate:
            continue
        preview = _collection_get(pcoll, candidate)
        if preview is not None:
            try:
                value = int(getattr(preview, 'icon_id', 0) or 0)
            except Exception:
                value = 0
            if value > 0:
                return value
    return 0


def action_icon_key(action: str | None) -> str:
    return SMART_ACTION_ICON_KEYS.get(str(action or '').strip().upper(), '')


def action_icon_value(action: str | None, *, register_if_needed: bool = False) -> int:
    key = action_icon_key(action)
    if not key:
        return 0
    return icon_value(key, register_if_needed=register_if_needed)


def action_fallback_icon(action: str | None) -> str:
    return str(SMART_ACTION_FALLBACK_ICONS.get(str(action or '').strip().upper(), 'IMAGE_DATA') or 'IMAGE_DATA')


def loaded_icon_keys() -> tuple[str, ...]:
    ensure_registered(force=not bool(_LOADED_ICON_KEYS))
    return tuple(sorted(_LOADED_ICON_KEYS))


classes = ()
