from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any
import bpy
from .. import _sss_lifecycle as _lifecycle, _sss_json_store as _json_store
try:
    from bpy.app.handlers import persistent
except Exception:

    def persistent(func):
        return func
_SETTINGS_DIRNAME = 'settings'
_CONFIG_DIRNAME = 'Smart_Sculpt_Suite'
_CONFIG_FILENAME = 'Smart_Sculpt_Suite.json'
_LEGACY_CONFIG_FILENAMES = ('Smart_' + 'workspace_Suite.json',)
_KNOWN_ALWAYS_ON_PROPS = ('always_on_npanel_autosave_restore', 'always_on_navigation_border_overlay')
_NAVIGATION_SETTING_NAME_MIGRATION = {'always_on_sculpt_navigation': 'navigation_enabled', 'always_on_canvas_navigation': 'navigation_canvas_enabled', 'always_on_rmb_navigation': 'navigation_rmb_enabled', 'always_on_double_click_focus': 'navigation_double_click_focus_enabled'}
_PREFERENCES_SETTINGS_ATTR = 'smart_sculpt_npanel_settings'
_APPLYING = False
_LAST_SNAPSHOT: dict[str, Any] | None = None
_LAST_PREFS_SNAPSHOT: dict[str, Any] | None = None
_REGISTERED = False
_AUTO_SYNC_ENABLED = False
_LAST_ACTIVE_SCENE_ID: int | None = None
_MSGBUS_OWNER = None
_MSGBUS_REGISTERED = False
_DYNAMIC_SETTINGS_MSGBUS_OWNERS = []
_AUTO_SYNC_HANDLER_HANDLES: dict[str, Any] = {}
_REGISTRATION_GUARD = False
_REGISTRATION_STORE: dict[str, Any] | None = None

def _is_package_local_path(path: Path | None) -> bool:
    """Return whether *path* is inside the installed Extension package."""
    if path is None:
        return False
    try:
        package_root = Path(__file__).resolve().parents[1]
        Path(path).expanduser().resolve(strict=False).relative_to(package_root)
        return True
    except Exception:
        return False

def _settings_directory() -> Path | None:
    """Return the Smart Sculpt settings directory under Blender config."""
    try:
        from .. import storage as _smart_storage
        getter = getattr(_smart_storage, 'workspace_settings_dir', None)
        if callable(getter):
            return getter(create=True)
        path = _smart_storage.config_dir(create=True) / _CONFIG_DIRNAME
        path.mkdir(parents=True, exist_ok=True)
        return path
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            value = user_resource('CONFIG', create=True) or ''
            if value:
                path = Path(str(value)).expanduser() / _CONFIG_DIRNAME
                path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    return None

def _settings_path() -> Path | None:
    try:
        from .. import storage as _smart_storage
        return _smart_storage.workspace_settings_path(create=True)
    except Exception:
        pass
    directory = _settings_directory()
    if directory is None:
        return None
    return directory / _CONFIG_FILENAME

def is_applying() -> bool:
    return bool(_APPLYING)

def is_auto_sync_enabled() -> bool:
    return bool(_AUTO_SYNC_ENABLED)

def immediate_save_enabled(scene=None) -> bool:
    if _APPLYING:
        return False
    try:
        settings = _settings_from_scene(scene)
        if settings is not None and hasattr(settings, 'always_on_npanel_autosave_restore'):
            return bool(getattr(settings, 'always_on_npanel_autosave_restore'))
    except Exception:
        pass
    return bool(_AUTO_SYNC_ENABLED)

def _sync_auto_sync_flag_from_scene(scene=None) -> None:
    """Mirror the stored N-panel State Save property into the runtime flag."""
    global _AUTO_SYNC_ENABLED
    try:
        settings = _settings_from_scene(scene)
        if settings is not None and hasattr(settings, 'always_on_npanel_autosave_restore'):
            _AUTO_SYNC_ENABLED = bool(getattr(settings, 'always_on_npanel_autosave_restore'))
    except Exception:
        pass

def request_immediate_save(scene=None, context=None, *, force: bool=False) -> None:
    if _APPLYING or _REGISTRATION_GUARD:
        return
    if not force and (not immediate_save_enabled(scene)):
        return
    try:
        save_scene_settings(scene, force=force)
    except Exception:
        pass

def _navigation_wm_settings(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        return getattr(wm, 'sculptnav', None) if wm is not None else None
    except Exception:
        return None

def snapshot_navigation_settings(scene=None, context=None) -> dict[str, Any]:
    """Serialize SculptNavigation settings without copying Blender data.

    Ignored collections are portable references only: JSON receives stable
    datablock names and restore resolves those names inside the current file.
    """
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    out: dict[str, Any] = {}
    wm_values = _snapshot_rna_group(_navigation_wm_settings(context))
    wm_values.pop('enabled', None)
    if wm_values:
        out['window_manager'] = wm_values
    names: list[str] = []
    try:
        for item in getattr(scene, 'sculptnav_ignored_collections', ()) or ():
            collection = getattr(item, 'collection', None)
            name = str(getattr(collection, 'name', '') or '').strip()
            if name and name not in names:
                names.append(name)
    except Exception:
        pass
    if names:
        out['ignored_collection_names'] = names
    try:
        if scene is not None and hasattr(scene, 'sculptnav_ignored_collections_index'):
            out['ignored_collection_index'] = int(getattr(scene, 'sculptnav_ignored_collections_index', 0) or 0)
    except Exception:
        pass
    return out

def apply_navigation_settings(scene=None, context=None) -> None:
    """Restore loaded SculptNavigation RNA from the canonical JSON store."""
    global _APPLYING
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    stored = _read_store().get('navigation_settings')
    if not isinstance(stored, dict):
        return
    previous = _APPLYING
    _APPLYING = True
    try:
        wm_values = stored.get('window_manager')
        if isinstance(wm_values, dict):
            canonical_wm_values = dict(wm_values)
            canonical_wm_values.pop('enabled', None)
            _copy_snapshot_to_group(canonical_wm_values, _navigation_wm_settings(context))
        collection = getattr(scene, 'sculptnav_ignored_collections', None) if scene is not None else None
        names = stored.get('ignored_collection_names')
        if collection is not None and isinstance(names, list):
            try:
                collection.clear()
            except Exception:
                collection = None
            if collection is not None:
                for raw_name in names:
                    name = str(raw_name or '').strip()
                    if not name:
                        continue
                    try:
                        target = bpy.data.collections.get(name)
                    except Exception:
                        target = None
                    if target is None:
                        continue
                    try:
                        item = collection.add()
                        item.collection = target
                    except Exception:
                        continue
        if scene is not None and hasattr(scene, 'sculptnav_ignored_collections_index'):
            try:
                maximum = max(0, len(getattr(scene, 'sculptnav_ignored_collections', ())) - 1)
                index = min(maximum, max(0, int(stored.get('ignored_collection_index', 0) or 0)))
                scene.sculptnav_ignored_collections_index = index
            except Exception:
                pass
    finally:
        _APPLYING = previous

def _dynamic_setting_change_notify(*_args) -> None:
    if _APPLYING or not _AUTO_SYNC_ENABLED:
        return
    request_immediate_save(getattr(getattr(bpy, 'context', None), 'scene', None), context=getattr(bpy, 'context', None), force=False)

def clear_dynamic_change_subscriptions() -> None:
    for owner in tuple(_DYNAMIC_SETTINGS_MSGBUS_OWNERS):
        _lifecycle.clear_msgbus(owner)
    _DYNAMIC_SETTINGS_MSGBUS_OWNERS.clear()

def refresh_dynamic_change_subscriptions(context=None) -> None:
    clear_dynamic_change_subscriptions()
    if not _AUTO_SYNC_ENABLED:
        return
    groups = (_navigation_wm_settings(context), dict(_iter_preference_groups(context) or ()).get('navigation'))
    seen = set()
    for group in groups:
        cls = type(group) if group is not None else None
        if not isinstance(cls, type):
            continue
        for name in _iter_storable_property_names(group):
            key = (cls, str(name))
            if key in seen:
                continue
            seen.add(key)
            try:
                owner = _lifecycle.subscribe_msgbus(key=key, notify=_dynamic_setting_change_notify)
                _DYNAMIC_SETTINGS_MSGBUS_OWNERS.append(owner)
            except Exception:
                pass

def _handler_container(name: str):
    try:
        return getattr(bpy.app.handlers, name)
    except Exception:
        return None

def _capture_scene_transform_guard(scene=None) -> dict[str, Any]:
    """Compatibility no-op for settings-only persistence operations.

    Applying Smart Sculpt N-panel, preference, and navigation settings does not
    modify object transforms.  A scene-wide transform snapshot here made every
    file load, save, undo, and scene switch proportional to object count.
    """
    del scene
    return {}

def _restore_scene_transform_guard(state: dict[str, Any], scene=None) -> None:
    if not state:
        return
    try:
        from . import utils as _smart_utils
        _smart_utils.restore_scene_object_transforms(state, scene)
    except Exception:
        pass

def _apply_saved_always_on_controls(context=None, *, apply_runtime: bool=False) -> None:
    try:
        from . import controls as _persistent_controls
        _persistent_controls.apply_saved_always_on_states(context or getattr(bpy, 'context', None), auto_load_enabled=True, apply_runtime=bool(apply_runtime))
    except Exception:
        pass

def _flush_feature_toggle_state(*, force=False):
    del force
    try:
        from .. import feature_toggle as _feature_toggle
        _feature_toggle.flush_state()
    except Exception:
        pass

def _register_scene_switch_msgbus(*, strict: bool=False) -> None:
    global _MSGBUS_REGISTERED, _MSGBUS_OWNER
    if _MSGBUS_OWNER is not None:
        _lifecycle.clear_msgbus(_MSGBUS_OWNER)
        _MSGBUS_OWNER = None
    try:
        _MSGBUS_OWNER = _lifecycle.subscribe_msgbus(key=(bpy.types.Window, 'scene'), notify=_scene_switch_msgbus)
        _MSGBUS_REGISTERED = True
    except Exception:
        _MSGBUS_REGISTERED = False
        _MSGBUS_OWNER = None
        if strict:
            raise

def _unregister_scene_switch_msgbus() -> None:
    global _MSGBUS_REGISTERED, _MSGBUS_OWNER
    if _MSGBUS_OWNER is not None:
        _lifecycle.clear_msgbus(_MSGBUS_OWNER)
    _MSGBUS_OWNER = None
    _MSGBUS_REGISTERED = False

def _register_auto_sync_handlers(*, strict: bool=False) -> None:
    """Acquire event-driven persistence resources only while the feature is ON."""
    del strict  # Registration degrades internally and never escapes add-on enable.
    if not _AUTO_SYNC_ENABLED:
        _unregister_auto_sync_handlers()
        return
    acquired_names=[]
    try:
        _register_scene_switch_msgbus(strict=False)
        for name, callback in (('load_pre', _load_pre), ('load_post', _load_post), ('save_pre', _save_pre)):
            collection = _handler_container(name)
            if collection is None:
                continue
            existing = _AUTO_SYNC_HANDLER_HANDLES.get(name)
            try:
                if existing is not None and existing in collection:
                    continue
            except Exception:
                pass
            if existing is not None:
                _lifecycle.remove_handler(collection, existing)
                _AUTO_SYNC_HANDLER_HANDLES.pop(name, None)
            wrapped=_lifecycle.append_handler(collection, callback)
            _AUTO_SYNC_HANDLER_HANDLES[name]=wrapped
            acquired_names.append(name)
    except Exception as exc:
        for name in reversed(acquired_names):
            collection=_handler_container(name)
            wrapped=_AUTO_SYNC_HANDLER_HANDLES.pop(name,None)
            if collection is not None and wrapped is not None:
                try: _lifecycle.remove_handler(collection,wrapped)
                except Exception: pass
        _unregister_scene_switch_msgbus()
        try:
            from .. import _sss_runtime_errors as _runtime_errors
            _runtime_errors.warn_once('settings-auto-sync-resources', exc)
        except Exception:
            pass


def _unregister_auto_sync_handlers() -> None:
    _unregister_scene_switch_msgbus()
    clear_dynamic_change_subscriptions()
    for name, callback in (('load_pre', _load_pre), ('load_post', _load_post), ('save_pre', _save_pre)):
        collection = _handler_container(name)
        wrapped = _AUTO_SYNC_HANDLER_HANDLES.pop(name, None)
        if collection is None:
            continue
        try:
            _lifecycle.remove_handler(collection, wrapped if wrapped is not None else callback)
        except Exception:
            pass


def _sync_auto_sync_resources(context=None) -> None:
    if _AUTO_SYNC_ENABLED:
        _register_auto_sync_handlers()
        refresh_dynamic_change_subscriptions(context)
    else:
        _unregister_auto_sync_handlers()


def set_auto_sync_enabled(enabled: bool, *, apply_now: bool=True) -> None:
    """Set N-panel State Save and immediately acquire/release its resources."""
    global _AUTO_SYNC_ENABLED
    enabled = bool(enabled)
    changed = enabled != _AUTO_SYNC_ENABLED
    _AUTO_SYNC_ENABLED = enabled
    _sync_auto_sync_resources(getattr(bpy, 'context', None))
    if apply_now and changed and (not _APPLYING):
        scene = getattr(bpy.context, 'scene', None)
        transform_guard = _capture_scene_transform_guard(scene)
        try:
            # The user-triggered transition is an explicit save boundary.
            request_immediate_save(scene, getattr(bpy, 'context', None), force=True)
        except Exception:
            pass
        finally:
            _restore_scene_transform_guard(transform_guard, scene)


def _legacy_settings_paths() -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        directory = _settings_directory()
        if directory is not None:
            for filename in _LEGACY_CONFIG_FILENAMES:
                paths.append(directory / filename)
    except Exception:
        pass
    try:
        from .. import storage as _smart_storage
        legacy_paths = getattr(_smart_storage, 'legacy_workspace_settings_paths', None)
        if callable(legacy_paths):
            paths.extend(list(legacy_paths(create=False)))
    except Exception:
        pass
    try:
        from .. import storage as _smart_storage
        root = Path(_smart_storage.extension_user_root(create=False))
        paths.append(root / _SETTINGS_DIRNAME / 'core_npanel_settings.json')
        paths.append(root / 'user_data' / 'settings' / 'n_panel_settings.json')
    except Exception:
        pass
    seen: set[str] = set()
    unique: list[Path] = []
    for path in paths:
        try:
            key = str(Path(path).expanduser().resolve(strict=False))
        except Exception:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        unique.append(Path(path))
    return tuple(unique)

def _read_json_file(path):
    if path is None:
        return {}
    document = _json_store.read_with_backup(path, allow_legacy=True, repair=False)
    return _json_store.payload_only(document) if isinstance(document, dict) else {}

def _migrate_navigation_setting_names(data: dict[str, Any]) -> bool:
    """Move legacy misclassified Always-on names to ordinary Navigation keys."""
    if not isinstance(data, dict):
        return False
    changed = False

    def migrate_values(values) -> None:
        nonlocal changed
        if not isinstance(values, dict):
            return
        for old_name, new_name in _NAVIGATION_SETTING_NAME_MIGRATION.items():
            if old_name not in values:
                continue
            if new_name not in values:
                values[new_name] = values[old_name]
            values.pop(old_name, None)
            changed = True
    migrate_values(data.get('scene_settings'))
    preference_settings = data.get('preference_settings')
    if isinstance(preference_settings, dict):
        for group_values in preference_settings.values():
            migrate_values(group_values)
    known = data.get('known_controls')
    if isinstance(known, dict):
        for old_name in _NAVIGATION_SETTING_NAME_MIGRATION:
            composite = f'scene.core::{old_name}'
            if composite in known:
                known.pop(composite, None)
                changed = True
    if changed:
        data['version'] = max(2, int(data.get('version', 0) or 0))
    return changed

def _read_store():
    if isinstance(_REGISTRATION_STORE, dict):
        data = dict(_REGISTRATION_STORE)
        _migrate_navigation_setting_names(data)
        return data
    data = _read_json_file(_settings_path())
    if data:
        _migrate_navigation_setting_names(data)
        return data
    for legacy_path in _legacy_settings_paths():
        data = _read_json_file(legacy_path)
        if data:
            _migrate_navigation_setting_names(data)
            data.setdefault('version', 1)
            data.setdefault('addon_id', 'smart_sculpt_suite')
            data['storage_folder'] = _CONFIG_DIRNAME
            data['storage_file'] = _CONFIG_FILENAME
            return data
    return {}

def _write_store(data):
    if _REGISTRATION_GUARD:
        return
    payload = dict(data) if isinstance(data, dict) else {}
    try:
        from .. import storage as _smart_storage
        _smart_storage.carry_feature_toggles(payload)
    except Exception:
        pass
    payload.setdefault('version', 1)
    payload.setdefault('addon_id', 'smart_sculpt_suite')
    payload['storage_folder'] = _CONFIG_DIRNAME
    payload['storage_file'] = _CONFIG_FILENAME
    path = _settings_path()
    if path is None:
        return
    _json_store.atomic_write(path, payload, validator=lambda value: isinstance(value, dict) and str(value.get('addon_id', 'smart_sculpt_suite')) == 'smart_sculpt_suite')

def _sync_known_controls_from_snapshot(data: dict[str, Any], snapshot: dict[str, Any] | None) -> None:
    if not isinstance(data, dict) or not isinstance(snapshot, dict):
        return
    values = data.setdefault('known_controls', {})
    if not isinstance(values, dict):
        values = {}
        data['known_controls'] = values
    for prop_name in _KNOWN_ALWAYS_ON_PROPS:
        if prop_name in snapshot:
            try:
                values[f'scene.core::{prop_name}'] = bool(snapshot[prop_name])
            except Exception:
                continue

def _settings_from_scene(scene=None):
    scene = scene or getattr(bpy.context, 'scene', None)
    if scene is None:
        return None
    try:
        return getattr(scene, 'core', None)
    except Exception:
        return None

def _edit_mode_settings_from_scene(scene=None):
    scene = scene or getattr(bpy.context, 'scene', None)
    if scene is None:
        return None
    try:
        return getattr(scene, 'strict_edit_mode_sculpt_settings', None)
    except Exception:
        return None

def _preferences_owner(context=None):
    context = context or getattr(bpy, 'context', None)
    return getattr(context, 'preferences', None)

def _preferences_scene_settings(context=None):
    preferences = _preferences_owner(context)
    if preferences is None:
        return None
    try:
        return getattr(preferences, _PREFERENCES_SETTINGS_ATTR, None)
    except Exception:
        return None

def _copy_snapshot_to_group(snapshot: dict[str, Any], group) -> None:
    global _APPLYING
    if group is None or not isinstance(snapshot, dict):
        return
    names = set(_iter_storable_property_names(group))
    previous = _APPLYING
    _APPLYING = True
    try:
        for name, value in snapshot.items():
            if name not in names:
                continue
            try:
                setattr(group, name, value)
            except Exception:
                continue
    finally:
        _APPLYING = previous

def _mirror_scene_snapshot_to_preferences(snapshot: dict[str, Any], context=None) -> None:
    target = _preferences_scene_settings(context)
    if target is None:
        return
    _copy_snapshot_to_group(snapshot, target)

def _snapshot_preferences_scene_settings(context=None) -> dict[str, Any]:
    return _snapshot_rna_group(_preferences_scene_settings(context))

def _preferences_module():
    try:
        import importlib
        package = str(__package__ or '').strip()
        prefix = package.rsplit('.core', 1)[0] if '.core' in package else package.rsplit('.', 1)[0]
        return importlib.import_module(f'{prefix}.preferences')
    except Exception:
        return None

def _root_preferences(context=None):
    mod = _preferences_module()
    if mod is None:
        return None
    try:
        getter = getattr(mod, 'root_preferences', None)
        return getter(context) if callable(getter) else None
    except Exception:
        return None

def _iter_preference_groups(context=None):
    mod = _preferences_module()
    if mod is None:
        return
    root = _root_preferences(context)
    if root is not None:
        yield ('root', root)
    try:
        order = tuple(getattr(mod, 'TOOL_ORDER', ()) or ())
    except Exception:
        order = ()
    finder = getattr(mod, 'find_tool_settings', None)
    for alias in order:
        if not callable(finder):
            continue
        try:
            group = finder(str(alias), context=context)
        except Exception:
            group = None
        if group is not None:
            yield (str(alias), group)

def _is_simple_rna_property(prop) -> bool:
    try:
        if bool(getattr(prop, 'is_readonly', False)) or bool(getattr(prop, 'is_hidden', False)):
            return False
    except Exception:
        pass
    try:
        identifier = str(getattr(prop, 'identifier', '') or '')
    except Exception:
        return False
    if not identifier or identifier == 'rna_type' or identifier == 'diagnostics':
        return False
    try:
        ptype = str(getattr(prop, 'type', '') or '')
    except Exception:
        ptype = ''
    return ptype in {'BOOLEAN', 'INT', 'FLOAT', 'ENUM', 'STRING'}

def _iter_storable_property_names(settings) -> tuple[str, ...]:
    if settings is None:
        return ()
    try:
        props = getattr(getattr(settings, 'bl_rna', None), 'properties', ())
    except Exception:
        props = ()
    names: list[str] = []
    for prop in props:
        if not _is_simple_rna_property(prop):
            continue
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if identifier and hasattr(settings, identifier):
            names.append(identifier)
    return tuple(names)

def _iter_storable_id_property_names(settings) -> tuple[str, ...]:
    if settings is None:
        return ()
    names: list[str] = []
    try:
        keys = list(settings.keys()) if hasattr(settings, 'keys') else []
    except Exception:
        keys = []
    for key in keys:
        key_text = str(key or '').strip()
        if not key_text:
            continue
        if key_text.startswith('ui_section_') or key_text.startswith('smart_sculpt_ui_'):
            names.append(key_text)
    return tuple(sorted(set(names)))

def _json_safe_value(value: Any) -> Any:
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        sequence = list(value)
        if len(sequence) <= 64 and all((isinstance(item, (bool, int, float, str)) or item is None for item in sequence)):
            return sequence
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return None

def snapshot_scene_settings(scene=None) -> dict[str, Any]:
    settings = _settings_from_scene(scene)
    if settings is None:
        return {}
    out: dict[str, Any] = {}
    for name in _iter_storable_property_names(settings):
        try:
            out[name] = _json_safe_value(getattr(settings, name))
        except Exception:
            continue
    for name in _iter_storable_id_property_names(settings):
        try:
            out[name] = _json_safe_value(settings[name])
        except Exception:
            continue
    return out

def snapshot_edit_mode_settings(scene=None) -> dict[str, Any]:
    """Serialize only Edit Mode Sculpt tool options, never mesh/mask content."""
    return _snapshot_rna_group(_edit_mode_settings_from_scene(scene))

def _snapshot_rna_group(data) -> dict[str, Any]:
    if data is None:
        return {}
    out: dict[str, Any] = {}
    for name in _iter_storable_property_names(data):
        try:
            out[name] = _json_safe_value(getattr(data, name))
        except Exception:
            continue
    return out

def snapshot_preferences(context=None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, group in _iter_preference_groups(context) or ():
        snap = _snapshot_rna_group(group)
        if snap:
            out[key] = snap
    return out

def save_preferences(context=None, *, force: bool=False, scene=None) -> None:
    """Save preferences and the N-panel state for the intended scene.

    ``Window.scene`` notifications run after Blender has already switched the
    active context to the destination scene.  Callers that are flushing the
    scene being left must therefore pass that previous scene explicitly;
    otherwise the new scene's default RNA values overwrite the canonical JSON
    immediately before restore.
    """
    global _LAST_PREFS_SNAPSHOT, _LAST_SNAPSHOT
    if _REGISTRATION_GUARD:
        return
    if scene is None:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
    snap = snapshot_preferences(context)
    scene_snap = snapshot_scene_settings(scene) if scene is not None else {}
    edit_snap = snapshot_edit_mode_settings(scene) if scene is not None else {}
    if not snap and (not scene_snap):
        if force:
            _flush_feature_toggle_state(force=True)
        return
    if not force and (not immediate_save_enabled(scene)):
        if snap:
            _LAST_PREFS_SNAPSHOT = json.loads(json.dumps(snap, ensure_ascii=False))
        if scene_snap:
            _mirror_scene_snapshot_to_preferences(scene_snap, context)
            _LAST_SNAPSHOT = dict(scene_snap)
        try:
            from . import controls as _persistent_controls
            sync_controls = getattr(_persistent_controls, 'save_known_controls_from_context', None)
            if callable(sync_controls):
                sync_controls(getattr(bpy, 'context', None), persist=False)
        except Exception:
            pass
        return
    data = _read_store()
    if snap:
        data['preference_settings'] = snap
    if scene_snap:
        _mirror_scene_snapshot_to_preferences(scene_snap, context)
        data['scene_settings'] = scene_snap
        _sync_known_controls_from_snapshot(data, scene_snap)
        _LAST_SNAPSHOT = dict(scene_snap)
    if edit_snap:
        data['edit_mode_settings'] = edit_snap
    navigation_snap = snapshot_navigation_settings(scene, context)
    if navigation_snap:
        data['navigation_settings'] = navigation_snap
    data['version'] = 1
    _write_store(data)
    try:
        current_scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        if scene is None or current_scene is scene:
            from . import controls as _persistent_controls
            sync_controls = getattr(_persistent_controls, 'save_known_controls_from_context', None)
            if callable(sync_controls):
                sync_controls(getattr(bpy, 'context', None), persist=True)
    except Exception:
        pass
    _flush_feature_toggle_state(force=bool(force) or immediate_save_enabled(scene))
    _LAST_PREFS_SNAPSHOT = json.loads(json.dumps(snap, ensure_ascii=False)) if snap else snapshot_preferences(context)

def apply_preferences(context=None) -> None:
    global _APPLYING, _LAST_PREFS_SNAPSHOT
    data = _read_store()
    stored = data.get('preference_settings')
    if not isinstance(stored, dict) or not stored:
        _LAST_PREFS_SNAPSHOT = snapshot_preferences(context)
        return
    groups = dict(_iter_preference_groups(context) or ())
    previous = _APPLYING
    _APPLYING = True
    try:
        for key, values in stored.items():
            if not isinstance(values, dict):
                continue
            group = groups.get(str(key))
            if group is None:
                continue
            names = set(_iter_storable_property_names(group))
            for name, value in values.items():
                if name not in names:
                    continue
                try:
                    setattr(group, name, value)
                except Exception:
                    continue
    finally:
        _APPLYING = previous
    _LAST_PREFS_SNAPSHOT = snapshot_preferences(context)

def save_scene_settings(scene=None, *, force: bool=False) -> None:
    global _LAST_SNAPSHOT
    if _REGISTRATION_GUARD:
        return
    snap = snapshot_scene_settings(scene)
    if not snap:
        if force:
            _flush_feature_toggle_state(force=True)
        return
    _mirror_scene_snapshot_to_preferences(snap)
    _LAST_SNAPSHOT = dict(snap)
    if not force and (not immediate_save_enabled(scene)):
        try:
            from . import controls as _persistent_controls
            sync_controls = getattr(_persistent_controls, 'save_known_controls_from_context', None)
            if callable(sync_controls):
                sync_controls(getattr(bpy, 'context', None), persist=False)
        except Exception:
            pass
        return
    data = _read_store()
    data['scene_settings'] = snap
    edit_snap = snapshot_edit_mode_settings(scene)
    if edit_snap:
        data['edit_mode_settings'] = edit_snap
    navigation_snap = snapshot_navigation_settings(scene, getattr(bpy, 'context', None))
    if navigation_snap:
        data['navigation_settings'] = navigation_snap
    _sync_known_controls_from_snapshot(data, snap)
    data['version'] = 1
    _write_store(data)
    try:
        current_scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        if scene is None or current_scene is scene:
            from . import controls as _persistent_controls
            sync_controls = getattr(_persistent_controls, 'save_known_controls_from_context', None)
            if callable(sync_controls):
                sync_controls(getattr(bpy, 'context', None), persist=True)
    except Exception:
        pass
    _flush_feature_toggle_state(force=bool(force) or immediate_save_enabled(scene))

def apply_scene_settings(scene=None) -> None:
    global _APPLYING, _LAST_SNAPSHOT
    scene = scene or getattr(bpy.context, 'scene', None)
    settings = _settings_from_scene(scene)
    if settings is None:
        return
    data = _read_store()
    stored = data.get('scene_settings')
    if not isinstance(stored, dict) or not stored:
        stored = _snapshot_preferences_scene_settings()
    if not isinstance(stored, dict) or not stored:
        _LAST_SNAPSHOT = snapshot_scene_settings(scene)
        _mirror_scene_snapshot_to_preferences(_LAST_SNAPSHOT)
        _sync_auto_sync_flag_from_scene(scene)
        edit_settings = _edit_mode_settings_from_scene(scene)
        edit_stored = data.get('edit_mode_settings')
        if edit_settings is not None and isinstance(edit_stored, dict):
            _copy_snapshot_to_group(edit_stored, edit_settings)
        apply_navigation_settings(scene, getattr(bpy, 'context', None))
        try:
            from . import controls as _persistent_controls
            sync_navigation = getattr(_persistent_controls, 'apply_navigation_preference_settings', None)
            if callable(sync_navigation):
                sync_navigation(settings, getattr(bpy, 'context', None), request_save=False)
        except Exception:
            pass
        return
    names = set(_iter_storable_property_names(settings))
    id_names = {str(name) for name in stored.keys() if str(name).startswith(('ui_section_', 'smart_sculpt_ui_'))}
    _APPLYING = True
    try:
        for name, value in stored.items():
            if name in names:
                try:
                    setattr(settings, name, value)
                except Exception:
                    continue
            elif name in id_names:
                try:
                    settings[name] = bool(value) if isinstance(value, bool) else value
                except Exception:
                    continue
    finally:
        _APPLYING = False
    _LAST_SNAPSHOT = snapshot_scene_settings(scene)
    _mirror_scene_snapshot_to_preferences(_LAST_SNAPSHOT)
    _sync_auto_sync_flag_from_scene(scene)
    edit_settings = _edit_mode_settings_from_scene(scene)
    edit_stored = data.get('edit_mode_settings')
    if edit_settings is not None and isinstance(edit_stored, dict):
        _copy_snapshot_to_group(edit_stored, edit_settings)
    apply_navigation_settings(scene, getattr(bpy, 'context', None))
    try:
        from . import controls as _persistent_controls
        sync_navigation = getattr(_persistent_controls, 'apply_navigation_preference_settings', None)
        if callable(sync_navigation):
            sync_navigation(settings, getattr(bpy, 'context', None), request_save=False)
    except Exception:
        pass

def sync_scene_settings_from_panel_draw(context=None) -> None:
    """Compatibility no-op: draw never mutates state, caches, RNA, or files."""
    del context
    return None

@persistent
def _load_pre(_dummy=None, *args, **kwargs) -> None:
    if not _AUTO_SYNC_ENABLED or _APPLYING:
        return
    scene = getattr(bpy.context, 'scene', None)
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        save_scene_settings(scene, force=True)
        save_preferences(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)

@persistent
def _load_post(_dummy=None, *args, **kwargs) -> None:
    del _dummy, args, kwargs
    if not _AUTO_SYNC_ENABLED or _APPLYING:
        return
    scene = getattr(bpy.context, 'scene', None)
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        _register_scene_switch_msgbus()
        apply_scene_settings(scene)
        _sync_auto_sync_flag_from_scene(scene)
        _sync_auto_sync_resources(getattr(bpy, 'context', None))
        apply_preferences(getattr(bpy, 'context', None))
        _apply_saved_always_on_controls(getattr(bpy, 'context', None), apply_runtime=True)
    except Exception:
        pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)

@persistent
def _save_pre(_dummy=None, *args, **kwargs) -> None:
    if not _AUTO_SYNC_ENABLED or _APPLYING:
        return
    scene = getattr(bpy.context, 'scene', None)
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        save_scene_settings(scene)
        save_preferences(getattr(bpy, 'context', None))
    except Exception:
        pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)

def _handle_active_scene_change() -> None:
    global _LAST_ACTIVE_SCENE_ID
    if not _AUTO_SYNC_ENABLED or _APPLYING:
        return
    try:
        scene = getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    current_id = id(scene) if scene is not None else None
    if current_id is None or current_id == _LAST_ACTIVE_SCENE_ID:
        return
    _LAST_ACTIVE_SCENE_ID = current_id
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        apply_scene_settings(scene)
        _sync_auto_sync_flag_from_scene(scene)
        _sync_auto_sync_resources(getattr(bpy, 'context', None))
        apply_preferences(getattr(bpy, 'context', None))
        _apply_saved_always_on_controls(getattr(bpy, 'context', None), apply_runtime=True)
    except Exception:
        pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)

@persistent
def _undo_redo_post(_dummy=None, *args, **kwargs) -> None:
    """Mirror Smart Sculpt N-panel state after Blender undo/redo.

    Scene RNA properties participate in Blender's undo stack, while the
    external Smart_Sculpt_Suite.json file is separate.  This handler updates
    the external state and reapplies runtime-only always-on switches after
    undo/redo without touching mesh data or object transforms.
    """
    global _LAST_SNAPSHOT
    if _APPLYING:
        return
    scene = getattr(bpy.context, 'scene', None)
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        _sync_auto_sync_flag_from_scene(scene)
        snap = snapshot_scene_settings(scene)
        if snap:
            _LAST_SNAPSHOT = dict(snap)
            _mirror_scene_snapshot_to_preferences(snap, getattr(bpy, 'context', None))
        if immediate_save_enabled(scene):
            save_scene_settings(scene, force=True)
            save_preferences(getattr(bpy, 'context', None), force=True)
        _apply_saved_always_on_controls(getattr(bpy, 'context', None), apply_runtime=True)
    except Exception:
        pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)

def _scene_switch_msgbus(*_args, **_kwargs) -> None:
    if _APPLYING or not _AUTO_SYNC_ENABLED:
        return
    _handle_active_scene_change()

@persistent
def _scene_switch_post(_dummy=None, *args, **kwargs) -> None:
    """Apply external N-panel settings when Blender's active scene changes."""
    if _APPLYING or not _AUTO_SYNC_ENABLED:
        return
    _handle_active_scene_change()

def _scene_switch_timer():
    return None

def _register_scene_switch_timer() -> None:
    return None

def _unregister_scene_switch_timer() -> None:
    return None

def register() -> None:
    global _REGISTERED, _LAST_ACTIVE_SCENE_ID
    if _REGISTERED:
        return
    scene = getattr(bpy.context, 'scene', None)
    _LAST_ACTIVE_SCENE_ID = id(scene) if scene is not None else None
    transform_guard = _capture_scene_transform_guard(scene)
    try:
        apply_scene_settings(scene)
        _sync_auto_sync_flag_from_scene(scene)
        apply_preferences(getattr(bpy, 'context', None))
        _apply_saved_always_on_controls(getattr(bpy, 'context', None), apply_runtime=True)
    except Exception as exc:
        try:
            from .. import _sss_runtime_errors as _runtime_errors
            _runtime_errors.warn_once('settings-register-restore', exc)
        except Exception:
            pass
    finally:
        _restore_scene_transform_guard(transform_guard, scene)
    _sync_auto_sync_resources(getattr(bpy, 'context', None))
    _REGISTERED = True
    return None


def begin_registration(context=None) -> None:
    """Freeze canonical state before Blender registers default RNA values."""
    global _REGISTRATION_GUARD, _REGISTRATION_STORE
    if _REGISTRATION_GUARD:
        return
    _REGISTRATION_STORE = _read_store()
    _REGISTRATION_GUARD = True

def end_registration(context=None) -> None:
    """Restore the frozen state once after all RNA is registered.

    The complete registration call is synchronous.  Applying the canonical
    settings here avoids a zero-delay timer, prevents a second round of update
    callbacks, and leaves no startup callback behind when all always-on
    features are disabled.
    """
    global _REGISTRATION_GUARD, _REGISTRATION_STORE
    if not _REGISTRATION_GUARD:
        return
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    try:
        apply_scene_settings(scene)
        apply_preferences(ctx)
        apply_navigation_settings(scene, ctx)
        _sync_auto_sync_flag_from_scene(scene)
        _apply_saved_always_on_controls(ctx, apply_runtime=True)
        _sync_auto_sync_resources(ctx)
    finally:
        _REGISTRATION_GUARD = False
        _REGISTRATION_STORE = None

def rollback_registration() -> None:
    global _REGISTERED, _LAST_ACTIVE_SCENE_ID
    _REGISTERED = False
    _unregister_auto_sync_handlers()
    clear_dynamic_change_subscriptions()
    _unregister_scene_switch_timer()
    _AUTO_SYNC_HANDLER_HANDLES.clear()
    _LAST_ACTIVE_SCENE_ID=None

def unregister() -> None:
    # A live replacement retires this exact old generation before the new
    # package has an active journal.  Persistence here could import the new
    # package while old RNA/resources are still rolling back.  Normal user
    # disable retains the existing explicit final-save behavior.
    if _REGISTERED and (not _lifecycle.live_replacement_rollback_active()):
        try:
            save_scene_settings(getattr(bpy.context, 'scene', None), force=True)
            save_preferences(getattr(bpy, 'context', None), force=True)
        except Exception:
            pass
    rollback_registration()
