# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Explicit transactional migration for exactly owned legacy RNA data.

Registration, load and save handlers never call this module.  It does not open,
scan, rewrite or replace a .blend file and it never unregisters Panels or edits
Workspace owner collections.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Iterable
from .._sss_ownership import OwnershipToken, matches, stamp
@dataclass(frozen=True,slots=True)
class MigrationResult:
    inspected:int=0; migrated:int=0; skipped:int=0

def migrate_owned_rna(datablocks: Iterable[Any], source: OwnershipToken, target: OwnershipToken,
                      migration: Callable[[Any],None]|None=None) -> MigrationResult:
    required=(source.owner_uuid,source.generation_uuid,source.session_uuid,target.owner_uuid,target.generation_uuid,target.session_uuid)
    if not all(required): raise ValueError("complete source and target ownership tokens are required")
    changed=[]; inspected=migrated=skipped=0
    try:
        for datablock in tuple(datablocks or ()):
            inspected+=1
            if not matches(datablock,source): skipped+=1; continue
            previous={k:datablock.get(k) for k in ("_sss_owner_uuid","_sss_generation_uuid","_sss_session_uuid")}
            changed.append((datablock,previous))
            if callable(migration): migration(datablock)
            if not stamp(datablock,target): raise RuntimeError("ownership token update failed")
            migrated+=1
    except Exception:
        for datablock,previous in reversed(changed):
            for key,value in previous.items():
                try:
                    if value is None: datablock.pop(key,None)
                    else: datablock[key]=value
                except Exception: pass
        raise
    return MigrationResult(inspected,migrated,skipped)

def cleanup_legacy_proxy_data(*_args,**_kwargs): return {"inspected":0,"migrated":0,"skipped":0,"raw_blend_io":False}
def register(): return None
def unregister(): return None
