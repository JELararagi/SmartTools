# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Explicit migration for datablocks carrying the full ownership token."""
from dataclasses import dataclass

from .._sss_ownership import OwnershipToken, _KEYS, matches, stamp


@dataclass(frozen=True, slots=True)
class MigrationResult:
    inspected: int = 0
    migrated: int = 0
    skipped: int = 0


def migrate_owned_rna(datablocks, source: OwnershipToken, target: OwnershipToken, migration=None):
    if any(not (token.owner_uuid and token.generation_uuid and token.session_uuid)
           for token in (source, target)):
        raise ValueError("complete source and target ownership tokens are required")
    items = tuple(datablocks or ())
    backups = []
    try:
        for datablock in items:
            if not matches(datablock, source):
                continue
            backups.append((datablock, tuple(datablock.get(key) for key in _KEYS)))
            if callable(migration):
                migration(datablock)
            if not stamp(datablock, target):
                raise RuntimeError("ownership token update failed")
    except Exception:
        for datablock, original in reversed(backups):
            for key, value in zip(_KEYS, original, strict=True):
                try:
                    if value is None:
                        datablock.pop(key, None)
                    else:
                        datablock[key] = value
                except Exception:
                    continue
        raise
    return MigrationResult(len(items), len(backups), len(items) - len(backups))


def cleanup_legacy_proxy_data(*args, **kwargs):
    return {"inspected": 0, "migrated": 0, "skipped": 0, "raw_blend_io": False}


def register():
    return None


unregister = register
