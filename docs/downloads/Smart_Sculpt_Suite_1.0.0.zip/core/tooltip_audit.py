# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility no-op: production never wraps bpy.props or registered RNA classes."""
def begin_runtime_audit(): return None
def finish_runtime_audit(): return None
def clear_runtime_audit(): return None
def abort_runtime_audit(): return None
