# SPDX-License-Identifier: GPL-3.0-or-later
"""Legacy entry points for tooltips now owned directly by registered RNA."""


def begin_runtime_audit():
    """The compatibility hook leaves Blender's RNA API untouched."""


finish_runtime_audit = begin_runtime_audit
clear_runtime_audit = begin_runtime_audit
abort_runtime_audit = begin_runtime_audit
