# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SUITE_META = {
    'core': ('Smart Sculpt', 'core.navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def integrated_root() -> Path:
    return Path(__file__).resolve().parent


def report_path() -> Path:
    return package_root() / 'INTEGRATED_ADDONS_REPORT.md'


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'integrated_addon'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def _suite_name_to_key(label: str) -> str:
    normalized = str(label or '').strip().lower()
    for suite_key, (suite_name, _nav) in SUITE_META.items():
        if normalized == suite_name.lower() or normalized == suite_key.lower() or normalized == suite_key.replace('_', ' ').lower():
            return suite_key
    return 'core'


def _parse_report() -> dict[str, dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return {}

    specs: dict[str, dict[str, Any]] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            alias = sanitize_alias(match.group('outer'))
            current = {
                'alias': alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': _suite_name_to_key(match.group('suite').strip()),
                'suite_name': match.group('suite').strip(),
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs[alias] = current
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r'"name"\s*:\s*"([^"]+)"', text)
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _iter_candidate_aliases(report_specs: dict[str, dict[str, Any]]):
    seen: set[str] = set()
    for alias in sorted(report_specs, key=str.lower):
        seen.add(alias)
        yield alias
    for child in sorted(package_root().iterdir(), key=lambda item: item.name.lower()):
        if child.name in {'core', '__pycache__'}:
            continue
        if not child.is_dir():
            continue
        if (child / '__init__.py').exists() and child.name not in seen:
            yield child.name


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    report_specs = _parse_report()
    results: list[dict[str, Any]] = []

    for alias in _iter_candidate_aliases(report_specs):
        module_dir = package_root() / alias
        init_path = module_dir / '__init__.py'
        if not module_dir.is_dir() or not init_path.exists():
            continue
        spec = dict(report_specs.get(alias) or {
            'alias': alias,
            'outer_zip': alias + '.zip',
            'display_name': alias,
            'suite': 'core',
            'suite_name': SUITE_META['core'][0],
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
        })
        spec['module_dir'] = str(module_dir)
        spec['init_path'] = str(init_path)
        spec['package_name'] = alias
        spec['suite_name'] = spec.get('suite_name') or SUITE_META.get(spec['suite'], ('Unknown', ''))[0]
        name, description = _read_bl_info_name_and_description(init_path)
        if name and not spec.get('display_name'):
            spec['display_name'] = name
        spec['description'] = description or str(spec.get('display_name') or alias)
        results.append(spec)

    _CACHE = list(results)
    return list(results)
