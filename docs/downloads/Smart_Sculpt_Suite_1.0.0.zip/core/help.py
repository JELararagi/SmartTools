# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from bpy.props import IntProperty, StringProperty
from bpy.types import Operator

from . import help_content, utils
from ..popup_text import PopupText, draw_popup_text, popup_page_property, popup_text_property, store_popup_text


_HELP_POPUP_WIDTH = 760


class SSS_OT_open_help_popup(Operator):
    bl_idname = 'smart_sculpt.open_help_popup'
    bl_label = 'Help'
    bl_description = 'Open detailed help for this Smart Sculpt tool group.'
    bl_options = {'INTERNAL'}

    topic_id: StringProperty(default='', options={'SKIP_SAVE'})
    page: popup_page_property()
    page_text: popup_text_property()
    page_size: IntProperty(default=16, options={'HIDDEN', 'SKIP_SAVE'})
    page_count: IntProperty(default=1, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, _properties):
        return utils.ui_text(
            'Open a detailed help popup for this Smart Sculpt tool group.',
            'このスマートスカルプトツールグループの詳細ヘルプを開きます。',
        )

    def invoke(self, context, _event):
        try:
            text = PopupText()
            help_content.draw_help_popup(text, context, self.topic_id, popup_width=_HELP_POPUP_WIDTH)
            store_popup_text(self, context, text)
            return context.window_manager.invoke_popup(self, width=_HELP_POPUP_WIDTH)
        except Exception:
            return {'CANCELLED'}

    def draw(self, context):
        layout = utils.localized_layout(self.layout)
        try:
            draw_popup_text(self, layout, utils.ui_text('Page', 'ページ'))
        except Exception as exc:
            layout.label(
                text=f"{utils.ui_text('Help draw failed', 'ヘルプ表示に失敗しました')}: {utils.exception_ui_text(exc)}",
                icon=utils.safe_icon('ERROR'),
            )

    def execute(self, context):
        # Popup ownership belongs to invoke().  execute() must finish the
        # existing popup instead of opening a second one.
        return {'FINISHED'}


classes = (
    SSS_OT_open_help_popup,
)
