# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


from . import utils, utils as _smart_utils
from .. import _sss_transactions as _transactions
import bpy
import numpy as np
from bpy.props import EnumProperty
from bpy.types import Operator



def _strict_edit_extract_selected_geometry(context, obj, *, label: str, thickness: float = 0.0, add_solidify: bool = False):
    """Create a safe edit-mode extraction from the currently selected faces."""
    if obj is None:
        return 0, []
    original_mode = getattr(obj, 'mode', 'OBJECT')
    if not utils.ensure_edit_mode(context, obj):
        return 0, []
    selected_faces = 0
    try:
        import bmesh  # Blender module
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        selected_faces = sum(1 for face in bm.faces if getattr(face, 'select', False))
    except Exception:
        selected_faces = 0
    if selected_faces <= 0:
        strict_settings = utils.strict_edit_mode_sculpt_settings(context)
        if bool(getattr(strict_settings, 'affect_visible_when_none', False)):
            try:
                utils.safe_operator_call(bpy.ops.mesh.select_all, [{'action': 'SELECT'}])
                import bmesh  # Blender module
                bm = bmesh.from_edit_mesh(obj.data)
                bm.faces.ensure_lookup_table()
                selected_faces = sum(1 for face in bm.faces if getattr(face, 'select', False))
            except Exception:
                selected_faces = 0
    if selected_faces <= 0:
        return 0, []

    before_names = set(bpy.data.objects.keys())
    try:
        utils.safe_operator_call(bpy.ops.mesh.duplicate)
        utils.safe_operator_call(bpy.ops.mesh.separate, [{'type': 'SELECTED'}])
    except Exception:
        try:
            utils.restore_mode_after_smart_operation(context, obj, original_mode)
        except Exception:
            pass
        return 0, []

    created = utils.new_mesh_objects_from_names(before_names)
    valid_created, invalid_created = utils.filter_meaningful_mesh_objects(created)
    try:
        utils.delete_objects_if_possible(invalid_created)
    except Exception:
        pass
    for new_obj in valid_created:
        try:
            new_obj.name = utils.unique_name(f"{obj.name}_{label}")
            utils.mark_generated(new_obj, label.lower())
            if add_solidify and thickness > 0.0:
                solid = new_obj.modifiers.new(name=utils.unique_name("SSS_EditExtractSolidify"), type='SOLIDIFY')
                solid.thickness = thickness
                utils.set_attr_if_exists(solid, 'use_even_offset', True)
        except Exception:
            pass
    try:
        utils.make_active(context, obj, keep_existing_selection=False)
        utils.restore_mode_after_smart_operation(context, obj, original_mode)
    except Exception:
        pass
    return len(valid_created), valid_created


class SSS_OT_configure_dyntopo(Operator):
    bl_idname = "smart_sculpt.configure_dyntopo"
    bl_label = "Configure Dyntopo"
    bl_description = _smart_utils.localize_bilingual_text((
        "Enable Dynamic Topology if needed and apply a safe detail preset using Blender 5 style sculpt settings. "
        "/ 必要であればダイナミックトポロジーを有効化し、Blender 5 系のスカルプト設定に沿って安全な細分プリセットを適用します。"
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute(stage_mesh=False)
    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        sculpt = utils.get_sculpt_settings(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Need an active sculpt mesh. / アクティブなスカルプト用メッシュが必要です。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            strict_settings = utils.strict_edit_mode_sculpt_settings(context)
            if strict_settings is not None:
                try:
                    strict_settings.brush_tool = 'SIMPLIFY'
                    strict_settings.brush_strength = 0.35
                    strict_settings.strength = 0.35
                except Exception:
                    pass
            self.report({'INFO'}, _smart_utils.localize_bilingual_text('Edit Mode Sculpt topology brush prepared. / 編集モード専用スカルプトのトポロジーブラシを準備しました。'))
            return {'FINISHED'}
        if sculpt is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Need an active sculpt mesh. / アクティブなスカルプト用メッシュが必要です。"))
            return {'CANCELLED'}
        if utils.find_multires_modifier(obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Disable/remove Multires before enabling Dyntopo. / ダイナミックトポロジーを使う前にマルチレゾを無効化または削除してください。"))
            return {'CANCELLED'}

        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        if not getattr(obj, "use_dynamic_topology_sculpting", False):
            try:
                utils.safe_operator_call(bpy.ops.sculpt.dynamic_topology_toggle)
            except Exception as exc:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not enable Dyntopo: {v0} / ダイナミックトポロジーを有効化できませんでした: {v1}', v0=exc, v1=exc))
                return {'CANCELLED'}

        detail_mode = settings.dyntopo_mode if settings else 'CONSTANT'
        detail_value = settings.dyntopo_detail if settings else 18.0

        utils.set_attr_if_exists(sculpt, 'detail_type_method', detail_mode)
        utils.set_attr_if_exists(sculpt, 'detail_refine_method', 'SUBDIVIDE_COLLAPSE')
        if detail_mode == 'CONSTANT':
            utils.set_attr_if_exists(sculpt, 'constant_detail_resolution', detail_value)
        else:
            utils.set_attr_if_exists(sculpt, 'detail_size', detail_value)
            utils.set_attr_if_exists(sculpt, 'detail_percent', detail_value)

        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Dyntopo configured: {v0} / ダイナミックトポロジー設定完了: {v1}', v0=detail_mode, v1=detail_mode))
        return {'FINISHED'}


class SSS_OT_detail_flood_fill(Operator):
    bl_idname = "smart_sculpt.detail_flood_fill"
    bl_label = "Detail Flood Fill"
    bl_description = _smart_utils.localize_bilingual_text((
        'Apply Dyntopo detail flood fill to even out tessellation density across the current sculpt. / 現在のスカルプト全体にダイナミックトポロジーのディテールフラッドフィルを適用し、細分化密度を均一化します。'
    ))
    bl_options = {'UNDO'}

    # A staged mesh copy would drop the live Dyntopo session this operator needs.
    @_transactions.transactional_execute(stage_mesh=False)
    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            result = utils.run_strict_edit_mode_operator(context, 'topology_operation', operation='SUBDIVIDE')
            if 'CANCELLED' in result:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text('Edit Mode detail fill substitute failed. / 編集モードのディテール補助処理に失敗しました。'))
                return {'CANCELLED'}
            return {'FINISHED'}
        started_in_sculpt = obj.mode == 'SCULPT'
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        # Leaving Sculpt Mode ends a Dyntopo session on meshes with attributes such as UVs, so
        # a run started outside Sculpt Mode cannot find one to reuse.
        if not started_in_sculpt and not getattr(obj, "use_dynamic_topology_sculpting", False):
            try:
                utils.safe_operator_call(bpy.ops.sculpt.dynamic_topology_toggle)
            except Exception:
                pass
        if not getattr(obj, "use_dynamic_topology_sculpting", False):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Enable Dyntopo first. / 先にダイナミックトポロジーを有効化してください。"))
            return {'CANCELLED'}
        utils.make_recovery_backup(context, obj, 'detail_flood_fill')
        # Blender polls sculpt.detail_flood_fill only under Constant or Manual detail, and the
        # default is Relative: use the panel's Detail for this run, then give the mode back.
        sculpt = context.tool_settings.sculpt
        previous_method = sculpt.detail_type_method
        previous_resolution = sculpt.constant_detail_resolution
        if previous_method not in {'CONSTANT', 'MANUAL'}:
            settings = utils.settings_from_context(context)
            sculpt.detail_type_method = 'CONSTANT'
            if settings is not None:
                sculpt.constant_detail_resolution = float(settings.dyntopo_detail)
        try:
            utils.safe_operator_call(bpy.ops.sculpt.detail_flood_fill)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Detail flood fill failed: {v0} / ディテール均一化に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            if previous_method not in {'CONSTANT', 'MANUAL'}:
                sculpt.constant_detail_resolution = previous_resolution
                sculpt.detail_type_method = previous_method
        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Detail flood fill produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / ディテール均一化結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'detail_flood_fill', v3=counts[0], v4=counts[2], v5=reason or 'detail_flood_fill'))
            return {'CANCELLED'}
        return {'FINISHED'}


class SSS_OT_voxel_remesh(Operator):
    bl_idname = "smart_sculpt.voxel_remesh"
    bl_label = "Voxel Remesh"
    bl_description = _smart_utils.localize_bilingual_text((
        'Run a robust voxel remesh. If the source object carries risky state such as shared mesh data, shape keys, or Multires, the operator will duplicate first to protect the original whenever preferences allow. / 共有メッシュ、シェイプキー、マルチレゾなど危険な状態では、設定が許す限り元を保護するため先に複製してからボクセルリメッシュを実行します。'
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute
    def execute(self, context):
        settings = utils.settings_from_context(context)
        source = utils.active_mesh_object(context)
        if source is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        original_mode = getattr(source, 'mode', 'OBJECT')
        utils.ensure_object_mode(context, source)
        obj, duplicated = utils.duplicate_for_safety(context, source, 'voxel', protect_shape_keys=True, protect_multires=True, protect_shared=True)
        utils.make_active(context, obj, keep_existing_selection=False)
        utils.make_recovery_backup(context, obj, 'voxel_remesh')
        if duplicated:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for voxel remesh. / 安全のため複製を作成してからボクセルリメッシュを行います。"))

        transform_guard = utils.capture_object_transform_state(obj)

        utils.ensure_single_user_mesh(obj)
        mesh = obj.data
        voxel_size = settings.voxel_size if settings else 0.03
        voxel_adaptivity = settings.voxel_adaptivity if settings else 0.0
        utils.set_attr_if_exists(mesh, 'remesh_voxel_size', voxel_size)
        utils.set_attr_if_exists(mesh, 'remesh_voxel_adaptivity', voxel_adaptivity)
        utils.set_attr_if_exists(mesh, 'use_remesh_preserve_volume', True)
        utils.set_attr_if_exists(mesh, 'use_remesh_preserve_sculpt_face_sets', True)
        utils.set_attr_if_exists(mesh, 'use_remesh_preserve_vertex_colors', True)
        utils.set_attr_if_exists(mesh, 'use_remesh_fix_poles', True)

        try:
            utils.safe_operator_call(bpy.ops.object.voxel_remesh)
        except Exception as exc:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Voxel remesh failed: {v0} / ボクセルリメッシュに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            utils.restore_object_transform_state(obj, transform_guard)

        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Voxel remesh produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / ボクセルリメッシュ結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'voxel_remesh', v3=counts[0], v4=counts[2], v5=reason or 'voxel_remesh'))
            return {'CANCELLED'}
        if not utils.mesh_has_meaningful_topology(obj):
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Voxel remesh produced invalid topology ({v0} verts / {v1} faces). / ボクセルリメッシュ結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
            return {'CANCELLED'}

        utils.restore_mode_after_smart_operation(context, obj, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Voxel remesh complete. / ボクセルリメッシュ完了。"))
        return {'FINISHED'}


class SSS_OT_quadriflow_remesh(Operator):
    bl_idname = "smart_sculpt.quadriflow_remesh"
    bl_label = "QuadriFlow Remesh"
    bl_description = _smart_utils.localize_bilingual_text((
        'Create a quad-friendly remesh with Blender\'s built-in Quadriflow. If Quadriflow fails, the operator falls back to voxel remesh instead of hard-stopping. / Blender 内蔵クアッドリメッシュで四角面主体のリメッシュを作成します。失敗時は処理停止せず、フォールバックとしてボクセルリメッシュへ切り替えます。'
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute
    def execute(self, context):
        settings = utils.settings_from_context(context)
        source = utils.active_mesh_object(context)
        if source is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        original_mode = getattr(source, 'mode', 'OBJECT')
        utils.ensure_object_mode(context, source)
        obj, duplicated = utils.duplicate_for_safety(context, source, 'quad', protect_shape_keys=True, protect_multires=True, protect_shared=True)
        utils.make_active(context, obj, keep_existing_selection=False)
        utils.make_recovery_backup(context, obj, 'quadriflow_remesh')
        if duplicated:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for quad remesh. / 安全のため複製を作成してからクアッドリメッシュを行います。"))

        transform_guard = utils.capture_object_transform_state(obj)

        target_faces = settings.quad_target_faces if settings else 5000
        success = False
        try:
            utils.safe_operator_call(
                bpy.ops.object.quadriflow_remesh,
                [
                    {
                        'target_faces': target_faces,
                        'use_mesh_symmetry': True,
                        'use_preserve_sharp': True,
                        'use_preserve_boundary': True,
                        'preserve_attributes': True,
                        'smooth_normals': True,
                    },
                    {
                        'target_faces': target_faces,
                        'use_mesh_symmetry': True,
                    },
                    {
                        'target_faces': target_faces,
                    },
                ],
            )
            success = True
        except Exception:
            success = False
        finally:
            utils.restore_object_transform_state(obj, transform_guard)

        if not success:
            mesh = obj.data
            utils.set_attr_if_exists(mesh, 'remesh_voxel_size', settings.voxel_size if settings else 0.03)
            utils.set_attr_if_exists(mesh, 'remesh_voxel_adaptivity', settings.voxel_adaptivity if settings else 0.0)
            try:
                utils.safe_operator_call(bpy.ops.object.voxel_remesh)
                utils.restore_object_transform_state(obj, transform_guard)
                restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
                if restored:
                    self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Quadriflow fallback produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / クアッドリメッシュフォールバック結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'quadriflow_remesh', v3=counts[0], v4=counts[2], v5=reason or 'quadriflow_remesh'))
                    return {'CANCELLED'}
                if not utils.mesh_has_meaningful_topology(obj):
                    self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Quadriflow fallback produced invalid topology ({v0} verts / {v1} faces). / クアッドリメッシュフォールバック結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
                    return {'CANCELLED'}
                utils.restore_mode_after_smart_operation(context, obj, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Quadriflow failed, voxel remesh was used instead. / クアッドリメッシュが失敗したため、代わりにボクセルリメッシュを実行しました。"))
                return {'FINISHED'}
            except Exception as exc:
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Both quad remesh and voxel fallback failed: {v0} / クアッドリメッシュとボクセルフォールバックの両方が失敗しました: {v1}', v0=exc, v1=exc))
                return {'CANCELLED'}

        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Quad remesh produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / クアッドリメッシュ結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'quadriflow_remesh', v3=counts[0], v4=counts[2], v5=reason or 'quadriflow_remesh'))
            return {'CANCELLED'}
        if not utils.mesh_has_meaningful_topology(obj):
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Quad remesh produced invalid topology ({v0} verts / {v1} faces). / クアッドリメッシュ結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
            return {'CANCELLED'}

        utils.restore_mode_after_smart_operation(context, obj, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Quad remesh complete. / クアッドリメッシュ完了。"))
        return {'FINISHED'}


def _extract_arguments(settings) -> dict:
    return {
        'mask_threshold': 0.5,
        'add_boundary_loop': getattr(settings, 'mask_extract_add_boundary_loop', True) if settings else True,
        'smooth_iterations': getattr(settings, 'mask_extract_smooth_iterations', 4) if settings else 4,
        'apply_shrinkwrap': getattr(settings, 'mask_extract_apply_shrinkwrap', True) if settings else True,
    }


def _apply_extract_thickness(objects, thickness: float) -> None:
    for extracted in objects:
        for modifier in extracted.modifiers:
            if modifier.type == 'SOLIDIFY':
                modifier.thickness = thickness


def _largest_visible_face_set_vertices(mesh):
    """Return a per-vertex bool array for the largest visible face set, or None without face sets."""
    face_sets = mesh.attributes.get('.sculpt_face_set')
    face_count = len(mesh.polygons)
    if face_sets is None or face_sets.domain != 'FACE' or face_count == 0:
        return None
    ids = np.empty(face_count, dtype=np.int32)
    face_sets.data.foreach_get('value', ids)
    visible = np.ones(face_count, dtype=bool)
    hidden = mesh.attributes.get('.hide_poly')
    if hidden is not None and len(hidden.data) == face_count:
        hidden.data.foreach_get('value', visible)
        visible = ~visible
    if not np.any(visible):
        return None
    values, counts = np.unique(ids[visible], return_counts=True)
    target = values[int(np.argmax(counts))]
    in_target = visible & (ids == target)
    loop_totals = np.empty(face_count, dtype=np.int32)
    mesh.polygons.foreach_get('loop_total', loop_totals)
    loop_vertices = np.empty(len(mesh.loops), dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', loop_vertices)
    vertices = np.zeros(len(mesh.vertices), dtype=bool)
    vertices[loop_vertices[np.repeat(in_target, loop_totals)]] = True
    return vertices


class _TemporaryExtractMask:
    """Hold a face set as the sculpt mask while extracting, then put the user's mask back."""

    def __init__(self, mesh, vertices):
        self.mesh = mesh
        self.existed = mesh.attributes.get('.sculpt_mask') is not None
        self.saved = None
        count = len(mesh.vertices)
        if self.existed:
            self.saved = np.empty(count, dtype=np.float32)
            mesh.attributes['.sculpt_mask'].data.foreach_get('value', self.saved)
        else:
            mesh.attributes.new('.sculpt_mask', 'FLOAT', 'POINT')
        mesh.attributes['.sculpt_mask'].data.foreach_set('value', vertices.astype(np.float32))
        mesh.update()

    def restore(self):
        mask = self.mesh.attributes.get('.sculpt_mask')
        if self.existed:
            if mask is not None:
                mask.data.foreach_set('value', self.saved)
        elif mask is not None:
            self.mesh.attributes.remove(mask)
        self.mesh.update()


class SSS_OT_face_set_extract(Operator):
    bl_idname = "smart_sculpt.face_set_extract"
    bl_label = "Face Set Extract"
    bl_description = _smart_utils.localize_bilingual_text((
        "Extract the largest visible face set into a new mesh. To extract a different face set, hide the others first. This uses the shared extract thickness, smoothing, boundary-loop, and shrinkwrap options so face-set extraction stays consistent with mask extraction. "
        "/ 表示中で一番大きいフェイスセットを新しいメッシュとして抽出します。別のフェイスセットを抽出する時は、ほかを先に隠します。厚み・スムーズ・境界ループ・シュリンクラップはマスク抽出と共有され、抽出系の操作感を揃えます。"
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute
    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            thickness = settings.extract_thickness if settings else 0.02
            created_count, _created = _strict_edit_extract_selected_geometry(context, obj, label='EditFaceSetExtract', thickness=thickness, add_solidify=True)
            if created_count <= 0:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select faces in Mesh Edit Mode before extracting. / 抽出前にメッシュ編集モードで面を選択してください。"))
                return {'CANCELLED'}
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode face extraction created {v0} object(s). / 編集モードフェイスセット抽出で新規オブジェクトを {v1} 個作成しました。', v0=created_count, v1=created_count))
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        thickness = settings.extract_thickness if settings else 0.02

        utils.ensure_object_mode(context, obj)
        vertices = _largest_visible_face_set_vertices(obj.data)
        if vertices is None:
            utils.ensure_sculpt_mode(context, obj)
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No visible face set to extract. Create face sets first. / 抽出できる表示中のフェイスセットがありません。先にフェイスセットを作成してください。"))
            return {'CANCELLED'}
        utils.make_recovery_backup(context, obj, 'face_set_extract')
        before_names = set(bpy.data.objects.keys())
        temporary_mask = _TemporaryExtractMask(obj.data, vertices)
        try:
            utils.ensure_sculpt_mode(context, obj)
            utils.safe_operator_call(bpy.ops.sculpt.paint_mask_extract, [_extract_arguments(settings)])
        except Exception:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_text("Face-set extract failed. / フェイスセット抽出に失敗しました。"))
            return {'CANCELLED'}
        finally:
            utils.make_active(context, obj, keep_existing_selection=False)
            utils.ensure_object_mode(context, obj)
            temporary_mask.restore()
            utils.ensure_sculpt_mode(context, obj)

        created = utils.new_mesh_objects_from_names(before_names)
        valid_created, invalid_created = utils.filter_meaningful_mesh_objects(created)
        dropped = utils.delete_objects_if_possible(invalid_created)
        _apply_extract_thickness(valid_created, thickness)
        created_count = utils.select_objects_if_any(context, valid_created)
        if created_count <= 0:
            restored, reason = utils.restore_recovery_backup_into_object(context, obj)
            if restored:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Face-set extract finished without a usable new mesh, so the source was restored from recovery backup ({v0}). / 使える新規メッシュが作成されなかったため、元オブジェクトを回復バックアップから復元しました（{v1}）。', v0=reason or 'face_set_extract', v1=reason or 'face_set_extract'))
            else:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Face-set extract finished but did not create a usable new mesh object. / フェイスセット抽出は完了しましたが、使用可能な新しいメッシュオブジェクトは作成されませんでした。"))
            return {'CANCELLED'}
        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Face-set extract source became invalid and was rolled back ({v0} verts / {v1} faces, reason={v2}). / フェイスセット抽出後に元オブジェクトが不正になったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'face_set_extract', v3=counts[0], v4=counts[2], v5=reason or 'face_set_extract'))
            return {'CANCELLED'}
        drop_note = _smart_utils.localize_bilingual_format(' Dropped {v0} invalid extract object(s). / 不正な抽出オブジェクト {v1} 個を削除しました。', v0=dropped, v1=dropped) if dropped else ""
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Face set extracted ({v0} new object(s)).{v1} / フェイスセットを抽出し、新規オブジェクト {v2} 個を作成しました。', v0=created_count, v1=drop_note, v2=created_count))
        return {'FINISHED'}


def _mesh_has_usable_mask(obj, threshold=0.5):
    """True when Blender's mask extract/slice has masked geometry to work on.

    Dyntopo and Multires keep the mask outside ``.sculpt_mask``, so those are left
    for Blender itself to judge.
    """
    if getattr(obj, 'use_dynamic_topology_sculpting', False) or utils.find_multires_modifier(obj):
        return True
    attribute = obj.data.attributes.get('.sculpt_mask')
    if attribute is None:
        return False
    values = np.empty(len(attribute.data), dtype=np.float32)
    attribute.data.foreach_get('value', values)
    return bool((values >= threshold).any())


class SSS_OT_mask_extract(Operator):
    bl_idname = "smart_sculpt.mask_extract"
    bl_label = "Mask Extract"
    bl_description = _smart_utils.localize_bilingual_text((
        "Extract the current sculpt mask into a new shell object using safe Blender 5 compatible argument fallbacks. This is useful for armor plates, cloth panels, scales, shell pieces, and Speedsculpt-style extract workflows. "
        "/ Blender 5 互換の引数フォールバックを使って、現在のスカルプトマスクを新しいシェルオブジェクトとして抽出します。アーマー板、布パネル、鱗、外殻パーツ、Speedsculpt 風の抽出ワークフローに便利です。"
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute
    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            thickness = settings.extract_thickness if settings else 0.02
            created_count, _created = _strict_edit_extract_selected_geometry(context, obj, label='EditMaskExtract', thickness=thickness, add_solidify=True)
            if created_count <= 0:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select faces in Mesh Edit Mode before extracting. / 抽出前にメッシュ編集モードで面を選択してください。"))
                return {'CANCELLED'}
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode extract created {v0} object(s). / 編集モード抽出で新規オブジェクトを {v1} 個作成しました。', v0=created_count, v1=created_count))
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}

        if not _mesh_has_usable_mask(obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Paint a mask first: no part of this mesh is masked. / 先にマスクを塗ってください。このメッシュにはマスクされた部分がありません。"))
            return {'CANCELLED'}
        thickness = settings.extract_thickness if settings else 0.02

        utils.make_recovery_backup(context, obj, 'mask_extract')
        before_names = set(bpy.data.objects.keys())
        try:
            utils.safe_operator_call(bpy.ops.sculpt.paint_mask_extract, [_extract_arguments(settings)])
        except Exception as exc:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Mask extract failed: {v0} / マスク抽出に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        created = utils.new_mesh_objects_from_names(before_names)
        valid_created, invalid_created = utils.filter_meaningful_mesh_objects(created)
        dropped = utils.delete_objects_if_possible(invalid_created)
        _apply_extract_thickness(valid_created, thickness)
        created_count = utils.select_objects_if_any(context, valid_created)
        if created_count <= 0:
            restored, reason = utils.restore_recovery_backup_into_object(context, obj)
            if restored:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mask extract finished without a usable new mesh, so the source was restored from recovery backup ({v0}). / 使える新規メッシュが作成されなかったため、元オブジェクトを回復バックアップから復元しました（{v1}）。', v0=reason or 'mask_extract', v1=reason or 'mask_extract'))
            else:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Mask extract finished but did not create a usable new mesh object. / マスク抽出は完了しましたが、使用可能な新しいメッシュオブジェクトは作成されませんでした。"))
            return {'CANCELLED'}
        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mask extract source became invalid and was rolled back ({v0} verts / {v1} faces, reason={v2}). / マスク抽出後に元オブジェクトが不正になったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'mask_extract', v3=counts[0], v4=counts[2], v5=reason or 'mask_extract'))
            return {'CANCELLED'}
        drop_note = _smart_utils.localize_bilingual_format(' Dropped {v0} invalid extract object(s). / 不正な抽出オブジェクト {v1} 個を削除しました。', v0=dropped, v1=dropped) if dropped else ""
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Mask extracted ({v0} new object(s)).{v1} / マスクを抽出し、新規オブジェクト {v2} 個を作成しました。', v0=created_count, v1=drop_note, v2=created_count))
        return {'FINISHED'}


class SSS_OT_mask_slice(Operator):
    bl_idname = "smart_sculpt.mask_slice"
    bl_label = "Mask Slice"
    bl_description = _smart_utils.localize_bilingual_text((
        "Slice the current sculpt mask into a new object using safe Blender 5 compatible fallbacks. This is useful for quickly separating panels, shell pieces, armor plates, or production-ready split parts without first creating manual selections. "
        "/ Blender 5 互換のフォールバックで、現在のスカルプトマスクを新しいオブジェクトへ切り出します。手動選択を作る前に、パネル、外殻パーツ、アーマー板、制作向けの分割パーツを素早く分けたいときに便利です。"
    ))
    bl_options = {'UNDO'}

    @_transactions.transactional_execute
    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            created_count, _created = _strict_edit_extract_selected_geometry(context, obj, label='EditMaskSlice', thickness=0.0, add_solidify=False)
            if created_count <= 0:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select faces in Mesh Edit Mode before slicing. / スライス前にメッシュ編集モードで面を選択してください。"))
                return {'CANCELLED'}
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode slice created {v0} object(s). / 編集モードスライスで新規オブジェクトを {v1} 個作成しました。', v0=created_count, v1=created_count))
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}

        if not _mesh_has_usable_mask(obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Paint a mask first: no part of this mesh is masked. / 先にマスクを塗ってください。このメッシュにはマスクされた部分がありません。"))
            return {'CANCELLED'}
        fill_holes = getattr(settings, 'mask_slice_fill_holes', False) if settings else False
        utils.make_recovery_backup(context, obj, 'mask_slice')
        variants = [
            {'fill_holes': fill_holes, 'new_object': True},
            {'fill_holes': fill_holes},
            {'new_object': True},
            {},
        ]

        before_names = set(bpy.data.objects.keys())
        try:
            utils.safe_operator_call(bpy.ops.sculpt.paint_mask_slice, variants)
        except Exception as exc:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Mask slice failed: {v0} / マスクスライスに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        created = utils.new_mesh_objects_from_names(before_names)
        valid_created, invalid_created = utils.filter_meaningful_mesh_objects(created)
        dropped = utils.delete_objects_if_possible(invalid_created)
        created_count = utils.select_objects_if_any(context, valid_created)
        if created_count <= 0:
            restored, reason = utils.restore_recovery_backup_into_object(context, obj)
            if restored:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mask slice finished without a usable new mesh, so the source was restored from recovery backup ({v0}). / 使える新規メッシュが作成されなかったため、元オブジェクトを回復バックアップから復元しました（{v1}）。', v0=reason or 'mask_slice', v1=reason or 'mask_slice'))
            else:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Mask slice finished but did not create a usable new mesh object. / マスクスライスは完了しましたが、使用可能な新しいメッシュオブジェクトは作成されませんでした。"))
            return {'CANCELLED'}
        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mask slice source became invalid and was rolled back ({v0} verts / {v1} faces, reason={v2}). / マスクスライス後に元オブジェクトが不正になったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'mask_slice', v3=counts[0], v4=counts[2], v5=reason or 'mask_slice'))
            return {'CANCELLED'}
        drop_note = _smart_utils.localize_bilingual_format(' Dropped {v0} invalid sliced object(s). / 不正な切り出しオブジェクト {v1} 個を削除しました。', v0=dropped, v1=dropped) if dropped else ""
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Mask sliced into {v0} new object(s).{v1} / マスクを切り出し、新規オブジェクト {v2} 個を作成しました。', v0=created_count, v1=drop_note, v2=created_count))
        return {'FINISHED'}


class SSS_OT_multires_action(Operator):
    bl_idname = "smart_sculpt.multires_action"
    bl_label = "Multires Action"
    bl_description = _smart_utils.localize_bilingual_text((
        'Add or manage a Multires modifier while guarding against common conflicts such as Dyntopo. / ダイナミックトポロジーなどのよくある競合を避けながら、マルチレゾモディファイアを追加または管理します。'
    ))
    bl_options = {'UNDO'}

    action: EnumProperty(
        name="Action",
        description=_smart_utils.localize_bilingual_text("Multires operation to run on the active object / アクティブオブジェクトへ実行するマルチレゾ操作です"),
        items=[
            ('ADD', "Add", _smart_utils.localize_bilingual_text("Add a Multires modifier / マルチレゾを追加")),
            ('SUBDIVIDE', "Subdivide", _smart_utils.localize_bilingual_text("Add one subdivision level / 1段階細分化")),
            ('LEVEL_UP', "Level +", _smart_utils.localize_bilingual_text("Increase displayed sculpt level / 表示スカルプレベルを上げる")),
            ('LEVEL_DOWN', "Level -", _smart_utils.localize_bilingual_text("Decrease displayed sculpt level / 表示スカルプレベルを下げる")),
            ('APPLY_BASE', "Apply Base", _smart_utils.localize_bilingual_text("Apply the base level / ベースレベルへ適用")),
        ],
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        source = utils.active_mesh_object(context)
        original_mode = getattr(source, 'mode', 'OBJECT') if source is not None else 'OBJECT'
        if source is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if getattr(source, 'use_dynamic_topology_sculpting', False):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Disable Dyntopo before using Multires. / マルチレゾを使う前にダイナミックトポロジーを無効化してください。"))
            return {'CANCELLED'}

        utils.ensure_object_mode(context, source)
        obj, duplicated = utils.duplicate_for_safety(context, source, 'multires', protect_shape_keys=True, protect_multires=False, protect_shared=True)
        utils.make_recovery_backup(context, obj, f'multires_{self.action.lower()}')
        if duplicated:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for Multires. / 安全のため複製を作成してからマルチレゾを処理します。"))

        utils.ensure_single_user_mesh(obj)
        mod = utils.find_multires_modifier(obj)
        if mod is None and self.action in {'ADD', 'SUBDIVIDE'}:
            mod = obj.modifiers.new(name="SSS_Multires", type='MULTIRES')

        if mod is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No Multires modifier found. / マルチレゾモディファイアが見つかりません。"))
            return {'CANCELLED'}

        try:
            if self.action == 'ADD':
                for _ in range(max(1, settings.multires_levels if settings else 1)):
                    utils.safe_operator_call(
                        bpy.ops.object.multires_subdivide,
                        [{'modifier': mod.name, 'mode': 'CATMULL_CLARK'}],
                    )
                target_level = getattr(mod, 'total_levels', 0)
                utils.set_attr_if_exists(mod, 'sculpt_levels', target_level)
                utils.set_attr_if_exists(mod, 'levels', target_level)
            elif self.action == 'SUBDIVIDE':
                utils.safe_operator_call(
                    bpy.ops.object.multires_subdivide,
                    [{'modifier': mod.name, 'mode': 'CATMULL_CLARK'}],
                )
                target_level = getattr(mod, 'total_levels', getattr(mod, 'levels', 0))
                utils.set_attr_if_exists(mod, 'sculpt_levels', target_level)
                utils.set_attr_if_exists(mod, 'levels', target_level)
            elif self.action == 'LEVEL_UP':
                new_level = min(getattr(mod, 'sculpt_levels', getattr(mod, 'levels', 0)) + 1, getattr(mod, 'total_levels', 0))
                utils.set_attr_if_exists(mod, 'sculpt_levels', new_level)
                utils.set_attr_if_exists(mod, 'levels', new_level)
            elif self.action == 'LEVEL_DOWN':
                new_level = max(getattr(mod, 'sculpt_levels', getattr(mod, 'levels', 0)) - 1, 0)
                utils.set_attr_if_exists(mod, 'sculpt_levels', new_level)
                utils.set_attr_if_exists(mod, 'levels', new_level)
            elif self.action == 'APPLY_BASE':
                utils.safe_operator_call(
                    bpy.ops.object.multires_base_apply,
                    [{'modifier': mod.name}],
                )
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Multires action failed: {v0} / マルチレゾ操作に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Multires action produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / マルチレゾ操作結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'multires_' + self.action.lower(), v3=counts[0], v4=counts[2], v5=reason or 'multires_' + self.action.lower()))
            return {'CANCELLED'}
        utils.restore_mode_after_smart_operation(context, obj, original_mode)
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Multires action complete: {v0} / マルチレゾ操作完了: {v1}', v0=self.action, v1=self.action))
        return {'FINISHED'}


classes = (
    SSS_OT_configure_dyntopo,
    SSS_OT_detail_flood_fill,
    SSS_OT_voxel_remesh,
    SSS_OT_quadriflow_remesh,
    SSS_OT_face_set_extract,
    SSS_OT_mask_extract,
    SSS_OT_mask_slice,
    SSS_OT_multires_action,
)
