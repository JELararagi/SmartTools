# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


from . import utils, utils as _smart_utils
import math
import random

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator
from mathutils import Quaternion, Vector




IDENTITY_QUATERNION = Quaternion((1.0, 0.0, 0.0, 0.0))


def _triangle_area(a: Vector, b: Vector, c: Vector) -> float:
    return ((b - a).cross(c - a)).length * 0.5


def _random_point_in_triangle(a: Vector, b: Vector, c: Vector, rng: random.Random) -> Vector:
    r1 = math.sqrt(rng.random())
    r2 = rng.random()
    return ((1.0 - r1) * a) + (r1 * (1.0 - r2) * b) + (r1 * r2 * c)


def _sample_face_point_world(obj: bpy.types.Object, poly, mesh, rng: random.Random):
    verts = [obj.matrix_world @ mesh.vertices[index].co for index in poly.vertices]
    if len(verts) < 3:
        return None, None

    tris = []
    weights = []
    root = verts[0]
    for index in range(1, len(verts) - 1):
        tri = (root, verts[index], verts[index + 1])
        area = _triangle_area(*tri)
        if area > 1e-12:
            tris.append(tri)
            weights.append(area)

    if not tris:
        normal = Vector((0.0, 0.0, 1.0))
        try:
            normal = (obj.matrix_world.to_3x3() @ poly.normal).normalized()
        except Exception:
            pass
        return verts[0], normal

    tri = rng.choices(tris, weights=weights, k=1)[0]
    point = _random_point_in_triangle(*tri, rng)
    try:
        normal = (obj.matrix_world.to_3x3() @ poly.normal).normalized()
    except Exception:
        normal = Vector((0.0, 0.0, 1.0))
    return point, normal


def _temporary_eval_mesh(context: bpy.types.Context, obj: bpy.types.Object):
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = obj.data
    cleanup = None
    try:
        mesh = eval_obj.to_mesh()
        cleanup = eval_obj.to_mesh_clear
    except Exception:
        mesh = obj.data
        cleanup = None
    return mesh, cleanup


def _align_quaternion_from_normal(normal: Vector) -> Quaternion:
    try:
        if normal.length_squared < 1e-12:
            return IDENTITY_QUATERNION.copy()
        return Vector((0.0, 0.0, 1.0)).rotation_difference(normal.normalized())
    except Exception:
        return IDENTITY_QUATERNION.copy()


def _scatter_mesh_copy_from_source(context: bpy.types.Context, source: bpy.types.Object):
    name = utils.unique_name(f"SSS_ScatterMesh_{utils.sanitize_filename_component(source.name)}")
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None

    if depsgraph is not None:
        try:
            eval_obj = source.evaluated_get(depsgraph)
            temp_mesh = eval_obj.to_mesh()
            try:
                mesh_data = temp_mesh.copy()
                mesh_data.name = name
                return mesh_data
            finally:
                try:
                    eval_obj.to_mesh_clear()
                except Exception:
                    pass
        except Exception:
            pass

    try:
        mesh_data = source.data.copy()
        mesh_data.name = name
        return mesh_data
    except Exception:
        return None



def _scatter_instance_object(mesh_data, source: bpy.types.Object, collection: bpy.types.Collection):
    inst = bpy.data.objects.new(utils.unique_name(f"SSS_Scatter_{utils.sanitize_filename_component(source.name)}"), mesh_data)
    collection.objects.link(inst)
    try:
        inst.animation_data_clear()
    except Exception:
        pass
    try:
        inst.parent = None
    except Exception:
        pass
    try:
        for constraint in list(inst.constraints):
            inst.constraints.remove(constraint)
    except Exception:
        pass
    try:
        inst.hide_set(False)
    except Exception:
        pass
    try:
        inst.hide_viewport = False
        inst.hide_render = False
        inst.hide_select = False
    except Exception:
        pass
    utils.mark_generated(inst, 'scatter')
    return inst


class SSS_OT_add_primitive(Operator):
    bl_idname = "smart_sculpt.add_primitive"
    bl_label = "Add Primitive"
    bl_description = _smart_utils.localize_bilingual_text((
        "Add a sculpt-friendly primitive and optionally boolean it into the active mesh for rapid blockout or hard-surface ideation. "
        "/ スカルプト向けプリミティブを追加し、必要ならアクティブメッシュへブーリアン適用して、ブロックアウトやハードサーフェス案出しを高速化します。"
    ))
    bl_options = {'UNDO'}

    primitive: EnumProperty(
        name="Primitive",
        description=_smart_utils.localize_bilingual_text("Primitive type used for quick blockout or boolean ideation / クイックブロックアウトやブーリアン案出しに使うプリミティブ形状です"),
        items=[
            ('SPHERE', "Sphere", _smart_utils.localize_bilingual_text("UV Sphere / UV球")),
            ('CUBE', "Cube", _smart_utils.localize_bilingual_text("Cube / 立方体")),
            ('CYLINDER', "Cylinder", _smart_utils.localize_bilingual_text("Cylinder / 円柱")),
            ('CONE', "Cone", _smart_utils.localize_bilingual_text("Cone / 円錐")),
            ('TORUS', "Torus", _smart_utils.localize_bilingual_text("Torus / トーラス")),
        ],
    )
    boolean_mode: EnumProperty(
        name="Boolean",
        description=_smart_utils.localize_bilingual_text("How the created primitive should interact with the active target mesh / 作成したプリミティブをアクティブターゲットメッシュへどう作用させるかを選びます"),
        items=[
            ('NONE', "None", _smart_utils.localize_bilingual_text("Leave as a separate object / 別オブジェクトとして残す")),
            ('UNION', "Union", _smart_utils.localize_bilingual_text("Fuse into the active object / アクティブオブジェクトへ結合")),
            ('DIFFERENCE', "Difference", _smart_utils.localize_bilingual_text("Subtract from the active object / アクティブオブジェクトから差し引く")),
            ('INTERSECT', "Intersect", _smart_utils.localize_bilingual_text("Keep overlap only / 重なり部分のみ保持")),
        ],
        default='NONE',
    )
    radius: FloatProperty(
        name="Radius",
        description=_smart_utils.localize_bilingual_text("Base radius used when creating the primitive / プリミティブ作成時に使う基本半径です"),
        default=0.2,
        min=0.001,
        soft_max=10.0,
    )
    apply_boolean: BoolProperty(name="Apply", default=True, description=_smart_utils.localize_bilingual_text("Apply the boolean modifier immediately / ブーリアンを即適用"))

    def execute(self, context):
        settings = utils.settings_from_context(context)
        prefs = utils.addon_prefs(context)
        source_obj = utils.active_mesh_object(context)
        original_mode = getattr(source_obj, 'mode', 'OBJECT') if source_obj is not None else 'OBJECT'
        target = source_obj if self.boolean_mode != 'NONE' else None
        if target is not None:
            utils.ensure_object_mode(context, target)
            target, duplicated = utils.duplicate_for_safety(context, target, 'boolean', protect_shape_keys=True, protect_multires=True, protect_shared=True)
            utils.make_recovery_backup(context, target, f'primitive_boolean_{self.boolean_mode.lower()}')
            if duplicated:
                self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for boolean target. / ブーリアン対象を保護するため安全な複製を作成しました。"))
        location = context.scene.cursor.location.copy()

        try:
            if self.primitive == 'SPHERE':
                utils.safe_operator_call(
                    bpy.ops.mesh.primitive_uv_sphere_add,
                    [{'radius': self.radius, 'location': location}],
                )
            elif self.primitive == 'CUBE':
                utils.safe_operator_call(
                    bpy.ops.mesh.primitive_cube_add,
                    [{'size': self.radius * 2.0, 'location': location}],
                )
            elif self.primitive == 'CYLINDER':
                utils.safe_operator_call(
                    bpy.ops.mesh.primitive_cylinder_add,
                    [{'radius': self.radius, 'depth': self.radius * 2.0, 'location': location}],
                )
            elif self.primitive == 'CONE':
                utils.safe_operator_call(
                    bpy.ops.mesh.primitive_cone_add,
                    [{'radius1': self.radius, 'depth': self.radius * 2.0, 'location': location}],
                )
            elif self.primitive == 'TORUS':
                utils.safe_operator_call(
                    bpy.ops.mesh.primitive_torus_add,
                    [
                        {'major_radius': self.radius, 'minor_radius': self.radius * 0.35, 'location': location},
                        {'location': location},
                    ],
                )
        except Exception as exc:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Primitive creation failed: {v0} / プリミティブ作成に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        cutter = context.view_layer.objects.active
        if cutter is None:
            return {'CANCELLED'}
        utils.mark_generated(cutter, 'cutter')

        if target is not None:
            utils.make_active(context, target)
            try:
                mod = target.modifiers.new(name=utils.unique_name(f"SSS_{self.boolean_mode}"), type='BOOLEAN')
                mod.object = cutter
                mod.operation = self.boolean_mode
                utils.set_attr_if_exists(mod, 'solver', 'EXACT')
                if self.apply_boolean:
                    utils.safe_operator_call(
                        bpy.ops.object.modifier_apply,
                        [{'modifier': mod.name}],
                    )
                    if prefs and prefs.remove_cutters_after_boolean:
                        utils.safe_delete_object(cutter)
            except Exception as exc:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Boolean failed: {v0} / ブーリアンに失敗しました: {v1}', v0=exc, v1=exc))
                return {'CANCELLED'}
            if self.apply_boolean:
                restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, target)
                if restored:
                    self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Primitive boolean produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / プリミティブブーリアン結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or self.boolean_mode.lower(), v3=counts[0], v4=counts[2], v5=reason or self.boolean_mode.lower()))
                    return {'CANCELLED'}
                if not utils.mesh_has_meaningful_topology(target):
                    self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Primitive boolean produced invalid topology ({v0} verts / {v1} faces). / プリミティブブーリアン結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
                    return {'CANCELLED'}
            utils.restore_mode_after_smart_operation(context, target, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Primitive created and boolean applied. / プリミティブを作成し、ブーリアンを適用しました。"))
            return {'FINISHED'}

        utils.restore_mode_after_smart_operation(context, cutter, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Primitive created. / プリミティブを作成しました。"))
        return {'FINISHED'}


class SSS_OT_boolean_from_selection(Operator):
    bl_idname = "smart_sculpt.boolean_from_selection"
    bl_label = "Boolean From Selection"
    bl_description = _smart_utils.localize_bilingual_text((
        "Use the active object as the target and all other selected mesh objects as cutters. "
        "/ アクティブオブジェクトをターゲット、他の選択メッシュをカッターとして使用します。"
    ))
    bl_options = {'UNDO'}

    operation: EnumProperty(
        name="Operation",
        description=_smart_utils.localize_bilingual_text("Boolean mode used when applying the selected cutters to the active target / 選択中カッターをアクティブターゲットへ適用するブーリアン方式です"),
        items=[
            ('UNION', "Union", _smart_utils.localize_bilingual_text("Fuse cutters into target / カッターをターゲットへ結合")),
            ('DIFFERENCE', "Difference", _smart_utils.localize_bilingual_text("Subtract cutters from target / カッターをターゲットから減算")),
            ('INTERSECT', "Intersect", _smart_utils.localize_bilingual_text("Keep overlap only / 重なり部分のみ保持")),
        ],
        default='UNION',
    )
    apply_boolean: BoolProperty(
        name="Apply",
        description=_smart_utils.localize_bilingual_text("Apply each boolean modifier immediately instead of leaving it live / 各ブーリアンモディファイアを残さず、すぐ適用して確定します"),
        default=True,
    )
    voxel_cleanup: BoolProperty(
        name="Voxel Cleanup",
        description=_smart_utils.localize_bilingual_text("Optionally run a voxel remesh cleanup after the batch boolean / 一括ブーリアン後に任意でボクセルリメッシュ整理を実行します"),
        default=False,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        prefs = utils.addon_prefs(context)
        source = utils.active_mesh_object(context)
        original_mode = getattr(source, 'mode', 'OBJECT') if source is not None else 'OBJECT'
        cutters = [obj for obj in utils.selected_mesh_objects(context) if obj != source]
        if source is None or not cutters:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select an active target and at least one cutter. / アクティブなターゲットと1つ以上のカッターを選択してください。"))
            return {'CANCELLED'}

        utils.ensure_object_mode(context, source)
        target, duplicated = utils.duplicate_for_safety(context, source, 'boolean_batch', protect_shape_keys=True, protect_multires=True, protect_shared=True)
        utils.make_recovery_backup(context, target, f'boolean_batch_{self.operation.lower()}')
        if duplicated:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for boolean target. / ブーリアン対象を保護するため安全な複製を作成しました。"))
        utils.make_active(context, target)
        success_count = 0
        failed_cutters: list[str] = []
        for cutter in cutters:
            try:
                mod = target.modifiers.new(name=utils.unique_name(f"SSS_{self.operation}"), type='BOOLEAN')
                mod.object = cutter
                mod.operation = self.operation
                utils.set_attr_if_exists(mod, 'solver', 'EXACT')
                if self.apply_boolean:
                    utils.safe_operator_call(
                        bpy.ops.object.modifier_apply,
                        [{'modifier': mod.name}],
                    )
                    if prefs and prefs.remove_cutters_after_boolean:
                        utils.safe_delete_object(cutter)
                success_count += 1
            except Exception as exc:
                failed_cutters.append(cutter.name)
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Boolean failed on {v0}: {v1} / {v2} へのブーリアンに失敗しました: {v3}', v0=cutter.name, v1=exc, v2=cutter.name, v3=exc))

        if success_count <= 0:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("All boolean cutters failed. / すべてのブーリアンカッター処理に失敗しました。"))
            return {'CANCELLED'}

        if (self.voxel_cleanup or (settings and settings.boolean_cleanup_voxel)) and settings:
            utils.set_attr_if_exists(target.data, 'remesh_voxel_size', settings.voxel_size)
            utils.set_attr_if_exists(target.data, 'remesh_voxel_adaptivity', settings.voxel_adaptivity)
            try:
                utils.safe_operator_call(bpy.ops.object.voxel_remesh)
            except Exception:
                pass

        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, target)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Boolean batch produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / ブーリアン一括結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or self.operation.lower(), v3=counts[0], v4=counts[2], v5=reason or self.operation.lower()))
            return {'CANCELLED'}
        if not utils.mesh_has_meaningful_topology(target):
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Boolean batch produced invalid topology ({v0} verts / {v1} faces). / ブーリアン一括結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
            return {'CANCELLED'}

        utils.restore_mode_after_smart_operation(context, target, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
        if failed_cutters:
            self.report(
                {'WARNING'},
                _smart_utils.localize_bilingual_format('Boolean batch completed with partial failures ({v0}/{v1} succeeded). / ブーリアン一括処理は部分成功です（{v2} 個中 {v3} 個成功）。', v0=success_count, v1=len(cutters), v2=len(cutters), v3=success_count),
            )
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Boolean batch complete ({v0}/{v1}). / ブーリアン一括処理が完了しました（{v2} 個中 {v3} 個成功）。', v0=success_count, v1=len(cutters), v2=len(cutters), v3=success_count))
        return {'FINISHED'}




class SSS_OT_add_rail_cutter(Operator):
    bl_idname = "smart_sculpt.add_rail_cutter"
    bl_label = "Add Rail Cutter"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create a long panel-line or slice-style cutter inspired by ziRail, ziCut, Box Cutter, and hard-surface sculpt helper workflows. "
        "It can stay as a guide object or immediately boolean into the active target. "
        "/ ziRail、ziCut、Box Cutter、ハードサーフェス系スカルプト補助ワークフローに着想を得た、長いパネルライン／スライス用カッターを作成します。"
        "ガイドとして残すことも、すぐアクティブターゲットへブーリアンすることもできます。"
    ))
    bl_options = {'UNDO'}

    axis: EnumProperty(
        name="Axis",
        description=_smart_utils.localize_bilingual_text("Primary axis used by the rail cutter / レールカッターを主に伸ばす軸です"),
        items=[
            ('X', "X", _smart_utils.localize_bilingual_text("Create a cutter elongated on the X axis / X 軸方向に長いカッター")),
            ('Y', "Y", _smart_utils.localize_bilingual_text("Create a cutter elongated on the Y axis / Y 軸方向に長いカッター")),
            ('Z', "Z", _smart_utils.localize_bilingual_text("Create a cutter elongated on the Z axis / Z 軸方向に長いカッター")),
        ],
        default='Y',
    )
    length: FloatProperty(
        name="Length",
        description=_smart_utils.localize_bilingual_text("Overall length of the rail cutter / レールカッター全体の長さです"),
        default=1.2,
        min=0.01,
        soft_max=100.0,
    )
    width: FloatProperty(
        name="Width",
        description=_smart_utils.localize_bilingual_text("Thin side of the rail cutter used for panel-line style cuts / パネルライン風カットに使う細い幅です"),
        default=0.03,
        min=0.001,
        soft_max=10.0,
    )
    depth: FloatProperty(
        name="Depth",
        description=_smart_utils.localize_bilingual_text("Depth of the rail cutter as it pushes through the target / ターゲットへ食い込むレールカッターの深さです"),
        default=0.15,
        min=0.001,
        soft_max=20.0,
    )
    apply_to_target: BoolProperty(
        name="Boolean Difference",
        default=True,
        description=_smart_utils.localize_bilingual_text("Immediately add this cutter as a Difference boolean on the active mesh / 作成したカッターをアクティブメッシュへ差分ブーリアンとして即追加します"),
    )
    apply_boolean: BoolProperty(
        name="Apply Boolean",
        default=True,
        description=_smart_utils.localize_bilingual_text("Apply the boolean modifier right away for destructive slicing / ブーリアンモディファイアを即適用して確定スライスします"),
    )
    remove_cutter: BoolProperty(
        name="Delete Cutter After Apply",
        default=False,
        description=_smart_utils.localize_bilingual_text("Delete the cutter object after the boolean has been applied / ブーリアン適用後にカッターを削除します"),
    )
    add_bevel: BoolProperty(
        name="Bevel Cutter",
        default=True,
        description=_smart_utils.localize_bilingual_text("Add a light bevel to the cutter so panel cuts are easier to read / カッターへ軽いベベルを加え、パネルカットを視認しやすくします"),
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        prefs = utils.addon_prefs(context)
        source_obj = utils.active_mesh_object(context)
        original_mode = getattr(source_obj, 'mode', 'OBJECT') if source_obj is not None else 'OBJECT'
        target = source_obj if self.apply_to_target else None
        if target is not None:
            utils.ensure_object_mode(context, target)
            target, duplicated = utils.duplicate_for_safety(
                context,
                target,
                'rail_cutter',
                protect_shape_keys=True,
                protect_multires=True,
                protect_shared=True,
            )
            utils.make_recovery_backup(context, target, 'rail_cutter_difference')
            if duplicated:
                self.report({'INFO'}, _smart_utils.localize_bilingual_text("Created a safe duplicate for rail cutter target. / レールカッター対象を保護するため安全な複製を作成しました。"))

        location = context.scene.cursor.location.copy()
        try:
            utils.safe_operator_call(
                bpy.ops.mesh.primitive_cube_add,
                [{'size': 2.0, 'location': location}],
            )
        except Exception as exc:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Rail cutter creation failed: {v0} / レールカッターの作成に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        cutter = context.view_layer.objects.active
        if cutter is None:
            return {'CANCELLED'}
        cutter.name = utils.unique_name("SSS_RailCutter")
        utils.mark_generated(cutter, 'cutter')

        try:
            if target is not None:
                cutter.rotation_euler = target.matrix_world.to_euler()
        except Exception:
            pass

        if self.axis == 'X':
            cutter.scale = (self.length * 0.5, self.width * 0.5, self.depth * 0.5)
        elif self.axis == 'Y':
            cutter.scale = (self.width * 0.5, self.length * 0.5, self.depth * 0.5)
        else:
            cutter.scale = (self.width * 0.5, self.depth * 0.5, self.length * 0.5)

        if self.add_bevel:
            try:
                bevel = cutter.modifiers.new(name=utils.unique_name("SSS_CutterBevel"), type='BEVEL')
                bevel.width = max(self.width * 0.35, 0.0005)
                bevel.segments = 2
                utils.set_attr_if_exists(bevel, 'limit_method', 'NONE')
                utils.set_attr_if_exists(bevel, 'miter_outer', 'PATCH')
            except Exception:
                pass

        if target is None:
            utils.restore_mode_after_smart_operation(context, cutter, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Rail cutter created. / レールカッターを作成しました。"))
            return {'FINISHED'}

        utils.make_active(context, target)
        try:
            mod = target.modifiers.new(name=utils.unique_name("SSS_RailDifference"), type='BOOLEAN')
            mod.object = cutter
            mod.operation = 'DIFFERENCE'
            utils.set_attr_if_exists(mod, 'solver', 'EXACT')
            if self.apply_boolean:
                utils.safe_operator_call(
                    bpy.ops.object.modifier_apply,
                    [{'modifier': mod.name}],
                )
                if self.remove_cutter or (prefs and prefs.remove_cutters_after_boolean):
                    utils.safe_delete_object(cutter)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Rail cutter boolean failed: {v0} / レールカッターのブーリアンに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        if self.apply_boolean:
            restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, target)
            if restored:
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Rail cutter boolean produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / レールカッターブーリアン結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'rail_cutter_difference', v3=counts[0], v4=counts[2], v5=reason or 'rail_cutter_difference'))
                return {'CANCELLED'}
            if not utils.mesh_has_meaningful_topology(target):
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Rail cutter boolean produced invalid topology ({v0} verts / {v1} faces). / レールカッターブーリアン結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
                return {'CANCELLED'}
        utils.restore_mode_after_smart_operation(context, target, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Rail cutter created and linked to target. / レールカッターを作成し、ターゲットへ適用しました。"))
        return {'FINISHED'}


class SSS_OT_add_sphere_chain(Operator):
    bl_idname = "smart_sculpt.add_sphere_chain"
    bl_label = "Add Sphere Chain"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create a skin-modifier based sphere chain similar to fast base-mesh sphere systems such as BSpheres or ZSphere-style workflows. "
        "/ BSpheres や ZSphere 系の高速ベースメッシュ作成に近い、スキンモディファイアベースのスフィアチェーンを作成します。"
    ))
    bl_options = {'UNDO'}

    count: IntProperty(
        name="Count",
        description=_smart_utils.localize_bilingual_text("How many spheres/segments are used in the chain / チェーンに使う球体・セグメント数です"),
        default=5,
        min=2,
        max=64,
    )
    radius: FloatProperty(
        name="Radius",
        description=_smart_utils.localize_bilingual_text("Starting radius of the first sphere in the chain / チェーン先頭の球体半径です"),
        default=0.12,
        min=0.001,
        soft_max=10.0,
    )
    spacing: FloatProperty(
        name="Spacing",
        description=_smart_utils.localize_bilingual_text("Distance between generated sphere-chain control points / 生成するスフィアチェーン制御点同士の間隔です"),
        default=0.18,
        min=0.001,
        soft_max=10.0,
    )
    taper: FloatProperty(
        name="Taper",
        description=_smart_utils.localize_bilingual_text("How much the chain radius narrows from start to end / チェーンの半径を先端へ向かってどれだけ細くするかです"),
        default=0.25,
        min=0.0,
        max=1.0,
    )
    convert_to_mesh: BoolProperty(
        name="Convert To Mesh",
        description=_smart_utils.localize_bilingual_text("Convert the generated sphere chain to mesh immediately / 生成したスフィアチェーンをすぐメッシュへ変換します"),
        default=True,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        source_obj = utils.active_mesh_object(context)
        original_mode = getattr(source_obj, 'mode', 'OBJECT') if source_obj is not None else 'OBJECT'
        utils.ensure_object_mode(context, source_obj)
        collection = context.collection or context.scene.collection
        mesh = bpy.data.meshes.new(utils.unique_name("SSS_SphereChain"))
        obj = bpy.data.objects.new(mesh.name, mesh)
        collection.objects.link(obj)
        utils.make_active(context, obj)
        utils.mark_generated(obj, 'sphere_chain')

        verts = [(0.0, (i - (self.count - 1) * 0.5) * self.spacing, 0.0) for i in range(self.count)]
        edges = [(i, i + 1) for i in range(self.count - 1)]
        mesh.from_pydata(verts, edges, [])
        mesh.update()

        skin = obj.modifiers.new(name="SSS_Skin", type='SKIN')
        subsurf = obj.modifiers.new(name="SSS_Subsurf", type='SUBSURF')
        subsurf.levels = 1
        subsurf.render_levels = 1

        try:
            skin_data = obj.data.skin_vertices[0].data
            for i in range(len(skin_data)):
                factor = 1.0 - (self.taper * (i / max(self.count - 1, 1)))
                radius = max(self.radius * factor, 0.001)
                skin_data[i].radius = (radius, radius)
        except Exception:
            pass

        if self.convert_to_mesh:
            try:
                utils.safe_operator_call(
                    bpy.ops.object.modifier_apply,
                    [{'modifier': skin.name}],
                )
            except Exception:
                pass
            try:
                utils.safe_operator_call(
                    bpy.ops.object.modifier_apply,
                    [{'modifier': subsurf.name}],
                )
            except Exception:
                pass
            utils.restore_mode_after_smart_operation(context, obj, original_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Sphere chain created. / スフィアチェーンを作成しました。"))
        return {'FINISHED'}


class SSS_OT_add_curve_tube(Operator):
    bl_idname = "smart_sculpt.add_curve_tube"
    bl_label = "Add Curve Tube"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create a curve-based tube that works like a quick ZSphere/curve-sweep style base form and optionally convert it to mesh. "
        "/ ZSphere やカーブスイープ風の高速ベース形状として使えるカーブチューブを作成し、必要ならメッシュへ変換します。"
    ))
    bl_options = {'UNDO'}

    radius: FloatProperty(
        name="Radius",
        description=_smart_utils.localize_bilingual_text("Radius used by the generated tube profile / 生成されるチューブ断面の半径です"),
        default=0.08,
        min=0.001,
        soft_max=10.0,
    )
    length: FloatProperty(
        name="Length",
        description=_smart_utils.localize_bilingual_text("Overall length of the curve tube / カーブチューブ全体の長さです"),
        default=0.6,
        min=0.001,
        soft_max=100.0,
    )
    convert_to_mesh: BoolProperty(
        name="Convert To Mesh",
        description=_smart_utils.localize_bilingual_text("Convert the generated curve tube to mesh immediately / 生成したカーブチューブをすぐメッシュへ変換します"),
        default=True,
    )

    def execute(self, context):
        source = utils.active_mesh_object(context)
        source_mode = source.mode if source is not None else 'OBJECT'
        settings = utils.settings_from_context(context)
        view_layer = context.view_layer
        previous_active = view_layer.objects.active
        previous_selection = tuple(context.selected_objects)
        tube_data = None
        tube = None

        try:
            if context.mode != 'OBJECT':
                utils.ensure_object_mode(context, source)
                if context.mode != 'OBJECT':
                    raise RuntimeError("Object Mode is unavailable")

            tube_data = bpy.data.curves.new("BezierCurve", 'CURVE')
            tube_data.dimensions = '3D'
            tube_data.fill_mode = 'FULL'
            tube_data.resolution_u = 12
            tube_data.bevel_depth = self.radius
            tube_data.bevel_resolution = 4

            centerline = tube_data.splines.new('BEZIER')
            centerline.resolution_u = tube_data.resolution_u
            centerline.bezier_points.add(1)
            half_length = self.length / 2.0
            for point, longitudinal in zip(centerline.bezier_points, (-half_length, half_length)):
                point.co = (0.0, longitudinal, 0.0)
                point.handle_left_type = 'AUTO'
                point.handle_right_type = 'AUTO'
                point.select_control_point = True
                point.select_left_handle = True
                point.select_right_handle = True

            tube = bpy.data.objects.new("BezierCurve", tube_data)
            context.collection.objects.link(tube)
            tube.location = context.scene.cursor.location
            space = context.space_data
            if isinstance(space, bpy.types.SpaceView3D) and space.local_view is not None:
                tube.local_view_set(space, True)
            for selected in previous_selection:
                selected.select_set(False, view_layer=view_layer)
            tube.select_set(True, view_layer=view_layer)
            view_layer.objects.active = tube

            if self.convert_to_mesh:
                converted = utils.safe_operator_call(bpy.ops.object.convert, [{'target': 'MESH'}])
                if 'FINISHED' not in converted or tube.type != 'MESH':
                    raise RuntimeError("The tube could not be converted to mesh")
                if tube_data.users == 0:
                    bpy.data.curves.remove(tube_data)
                    tube_data = None

            utils.mark_generated(tube, 'curve_tube')
        except Exception as exc:
            generated_mesh = tube.data if tube is not None and tube.type == 'MESH' else None
            if tube is not None:
                bpy.data.objects.remove(tube, do_unlink=True)
            if generated_mesh is not None and generated_mesh.users == 0:
                bpy.data.meshes.remove(generated_mesh)
            if tube_data is not None and tube_data.users == 0:
                bpy.data.curves.remove(tube_data)
            for selected in previous_selection:
                selected.select_set(True, view_layer=view_layer)
            view_layer.objects.active = previous_active
            if source is not None and source_mode != 'OBJECT':
                utils.restore_mode_after_smart_operation(context, source, source_mode)
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format(
                'Curve creation failed: {v0} / カーブ作成に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        if self.convert_to_mesh:
            utils.restore_mode_after_smart_operation(
                context, tube, source_mode, auto_enter_sculpt=bool(settings and settings.auto_enter_sculpt))
        self.report({'INFO'}, _smart_utils.localize_bilingual_text(
            "Curve tube created. / カーブチューブを作成しました。"))
        return {'FINISHED'}


class SSS_OT_create_anchor_bend_setup(Operator):
    bl_idname = "smart_sculpt.create_anchor_bend_setup"
    bl_label = "Create Anchor Bend Setup"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create a non-destructive bend setup using a Simple Deform modifier and an Empty origin object. "
        "This approximates anchor/bend style posing workflows without requiring a full rig. "
        "/ シンプル変形とエンプティ原点を使った非破壊ベンドセットアップを作成します。フルリグなしでアンカー／ベンド系のポーズ調整を近似します。"
    ))
    bl_options = {'UNDO'}

    axis: EnumProperty(
        name="Axis",
        description=_smart_utils.localize_bilingual_text("Axis around which the anchor-bend setup deforms the mesh / アンカーベンドでメッシュを曲げる軸です"),
        items=[('X', "X", _smart_utils.localize_bilingual_text("Bend around X / X 軸")), ('Y', "Y", _smart_utils.localize_bilingual_text("Bend around Y / Y 軸")), ('Z', "Z", _smart_utils.localize_bilingual_text("Bend around Z / Z 軸"))],
        default='Z',
    )
    angle: FloatProperty(
        name="Angle",
        description=_smart_utils.localize_bilingual_text("Initial bend angle of the generated setup / 生成されるベンドセットアップの初期角度です"),
        subtype='ANGLE',
        default=0.0,
    )

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        original_mode = getattr(obj, 'mode', 'OBJECT') if obj is not None else 'OBJECT'
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        utils.ensure_object_mode(context, obj)
        collection = context.collection or context.scene.collection
        empty = bpy.data.objects.new(utils.unique_name(f"{obj.name}_bend_origin"), None)
        empty.empty_display_type = 'SPHERE'
        empty.empty_display_size = max(obj.dimensions.length * 0.05, 0.05)
        empty.matrix_world = obj.matrix_world.copy()
        collection.objects.link(empty)
        utils.mark_generated(empty, 'bend_origin')

        mod = obj.modifiers.new(name=utils.unique_name("SSS_AnchorBend"), type='SIMPLE_DEFORM')
        mod.deform_method = 'BEND'
        mod.deform_axis = self.axis
        mod.angle = self.angle
        mod.origin = empty

        utils.restore_mode_after_smart_operation(context, obj, original_mode)
        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Anchor bend setup created. / アンカーベンドセットアップを作成しました。"))
        return {'FINISHED'}




class SSS_OT_add_detail_scatter(Operator):
    bl_idname = "smart_sculpt.add_detail_scatter"
    bl_label = "Add Detail Scatter"
    bl_description = _smart_utils.localize_bilingual_text((
        "Scatter selected helper meshes onto the active mesh surface. "
        "This approximates Forest Pack, ZENV, procedural placement, scale distribution, bolt scattering, rock breakup, and other modern surface-detail workflows. "
        "/ 選択中のヘルパーメッシュをアクティブメッシュ表面へ散布配置します。"
        "Forest Pack、ZENV、プロシージャル配置、鱗配置、ボルト散布、岩のばらしなど、現代的な表面ディテール配置ワークフローを Blender ネイティブで近似します。"
    ))
    bl_options = {'UNDO'}

    count: IntProperty(
        name="Count",
        description=_smart_utils.localize_bilingual_text("How many helper meshes to place on the active target surface / アクティブターゲット表面へ配置するヘルパーメッシュ数"),
        default=24,
        min=1,
        max=5000,
    )
    min_scale: FloatProperty(
        name="Min Scale",
        description=_smart_utils.localize_bilingual_text("Smallest random scale multiplier used during scattering / 散布時に使うランダム縮尺の最小値"),
        default=0.8,
        min=0.01,
        soft_max=10.0,
    )
    max_scale: FloatProperty(
        name="Max Scale",
        description=_smart_utils.localize_bilingual_text("Largest random scale multiplier used during scattering / 散布時に使うランダム縮尺の最大値"),
        default=1.2,
        min=0.01,
        soft_max=10.0,
    )
    align_to_normal: BoolProperty(
        name="Align To Normal",
        description=_smart_utils.localize_bilingual_text("Rotate scattered helpers to follow the surface normal / 散布ヘルパーを表面法線へ合わせて回転"),
        default=True,
    )
    normal_offset: FloatProperty(
        name="Offset",
        description=_smart_utils.localize_bilingual_text("Offset helpers along the target normal to avoid z-fighting or embed them slightly / ターゲット法線方向へオフセットし、Zファイティング回避や軽い埋め込みを行います"),
        default=0.0,
        precision=4,
        soft_max=1.0,
    )
    seed: IntProperty(
        name="Seed",
        description=_smart_utils.localize_bilingual_text("Random seed for repeatable scattering / 再現可能な散布配置のための乱数シード"),
        default=0,
        min=0,
        max=1_000_000,
    )
    avoid_overlap: BoolProperty(
        name="Avoid Overlap",
        description=_smart_utils.localize_bilingual_text("Reject placements that fall too close together so scattered helpers stay more readable and less interpenetrated / 近すぎる配置を拒否し、散布ヘルパー同士の見分けやすさと食い込み抑制を優先します"),
        default=False,
    )
    min_gap: FloatProperty(
        name="Gap",
        description=_smart_utils.localize_bilingual_text("Extra spacing added when overlap avoidance is enabled / 重なり回避が有効なときに追加する間隔"),
        default=0.0,
        min=0.0,
        soft_max=10.0,
        precision=4,
    )
    tilt_degrees: FloatProperty(
        name="Random Tilt",
        description=_smart_utils.localize_bilingual_text("Maximum random tilt angle in degrees applied after normal alignment to break up repetition / 法線合わせ後に加える最大ランダム傾き角度。繰り返し感を崩します"),
        default=0.0,
        min=0.0,
        max=180.0,
    )

    def execute(self, context):
        target = utils.active_mesh_object(context)
        original_mode = getattr(target, 'mode', 'OBJECT') if target is not None else 'OBJECT'
        sources = [obj for obj in utils.selected_mesh_objects(context) if obj != target]
        if target is None or not sources:
            self.report(
                {'WARNING'},
                _smart_utils.localize_bilingual_text("Select an active target mesh and one or more source detail meshes. / アクティブなターゲットメッシュと、1つ以上のソースディテールメッシュを選択してください。"),
            )
            return {'CANCELLED'}

        utils.ensure_object_mode(context, target)
        mesh, cleanup = _temporary_eval_mesh(context, target)
        rng = random.Random(self.seed)
        collection = utils.helper_collection(context.scene)
        created = 0
        placed_spheres = []
        mesh_cache: dict[str, bpy.types.Mesh] = {}

        def _candidate_radius(obj, scale_mul):
            try:
                dims = getattr(obj, 'dimensions', None)
                if dims is not None:
                    return max(float(dims[0]), float(dims[1]), float(dims[2]), 0.001) * 0.5 * scale_mul
            except Exception:
                pass
            return max(self.min_gap, 0.001) + scale_mul * 0.1

        try:
            polygons = [poly for poly in getattr(mesh, 'polygons', []) if len(poly.vertices) >= 3]
            if not polygons:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Target has no valid polygons for scattering. / 散布に使える有効ポリゴンがターゲットにありません。"))
                return {'CANCELLED'}
            poly_weights = [max(getattr(poly, 'area', 0.0), 1e-12) for poly in polygons]
            scale_low = min(self.min_scale, self.max_scale)
            scale_high = max(self.min_scale, self.max_scale)
            attempts_per_instance = 24 if self.avoid_overlap else 1

            for _ in range(self.count):
                chosen = None
                for _attempt in range(attempts_per_instance):
                    source = rng.choice(sources)
                    poly = rng.choices(polygons, weights=poly_weights, k=1)[0]
                    point, normal = _sample_face_point_world(target, poly, mesh, rng)
                    if point is None:
                        continue
                    scale_mul = rng.uniform(scale_low, scale_high)
                    radius = _candidate_radius(source, scale_mul)
                    location = point + ((normal.normalized() if normal and normal.length_squared > 1e-12 else Vector((0.0, 0.0, 1.0))) * self.normal_offset)
                    if self.avoid_overlap:
                        blocked = False
                        for existing_loc, existing_radius in placed_spheres:
                            if (location - existing_loc).length < (radius + existing_radius + max(self.min_gap, 0.0)):
                                blocked = True
                                break
                        if blocked:
                            continue
                    chosen = (source, normal, scale_mul, location, radius)
                    break

                if chosen is None:
                    continue

                source, normal, scale_mul, location, radius = chosen
                mesh_key = source.name_full if hasattr(source, 'name_full') else source.name
                mesh_data = mesh_cache.get(mesh_key)
                if mesh_data is None:
                    mesh_data = _scatter_mesh_copy_from_source(context, source)
                    if mesh_data is None:
                        continue
                    mesh_cache[mesh_key] = mesh_data
                inst = _scatter_instance_object(mesh_data, source, collection)

                base_quat = source.matrix_world.to_quaternion()
                if self.align_to_normal:
                    safe_normal = normal.normalized() if normal and normal.length_squared > 1e-12 else Vector((0.0, 0.0, 1.0))
                    spin_q = Quaternion(safe_normal, rng.uniform(0.0, math.tau))
                    final_q = spin_q @ _align_quaternion_from_normal(safe_normal) @ base_quat
                    if self.tilt_degrees > 0.0:
                        trial_axis = safe_normal.cross(Vector((1.0, 0.0, 0.0)))
                        if trial_axis.length_squared <= 1e-12:
                            trial_axis = safe_normal.cross(Vector((0.0, 1.0, 0.0)))
                        if trial_axis.length_squared > 1e-12:
                            tilt_axis = trial_axis.normalized()
                            tilt_axis.rotate(Quaternion(safe_normal, rng.uniform(0.0, math.tau)))
                            tilt_angle = math.radians(rng.uniform(-self.tilt_degrees, self.tilt_degrees))
                            final_q = Quaternion(tilt_axis, tilt_angle) @ final_q
                    inst.rotation_mode = 'QUATERNION'
                    inst.rotation_quaternion = final_q
                else:
                    inst.rotation_mode = 'QUATERNION'
                    inst.rotation_quaternion = base_quat

                source_scale = tuple(float(value) if abs(float(value)) > 1e-8 else 1.0 for value in source.scale)
                inst.scale = tuple(value * scale_mul for value in source_scale)
                inst.location = location
                placed_spheres.append((location.copy(), radius))
                created += 1
        finally:
            if cleanup is not None:
                try:
                    cleanup()
                except Exception:
                    pass
            for mesh_data in list(mesh_cache.values()):
                try:
                    if mesh_data.users <= 0:
                        bpy.data.meshes.remove(mesh_data)
                except Exception:
                    pass

        if created == 0:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No scatter instances were created. / 散布インスタンスを作成できませんでした。"))
            return {'CANCELLED'}

        if created < self.count:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Created {v0}/{v1} scatter instance(s). / 散布インスタンスを {v2} 個中 {v3} 個作成しました。', v0=created, v1=self.count, v2=self.count, v3=created))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Created {v0} scatter instance(s). / {v1} 個の散布インスタンスを作成しました。', v0=created, v1=created))
        utils.restore_mode_after_smart_operation(context, target, original_mode)
        return {'FINISHED'}



class SSS_OT_add_procedural_stack(Operator):
    bl_idname = "smart_sculpt.add_procedural_stack"
    bl_label = "Add Procedural Stack"
    bl_description = _smart_utils.localize_bilingual_text((
        "Add a non-destructive procedural detail stack inspired by node-room and geometry-node workflows, but implemented with Blender-safe modifier stacks for maximum compatibility. "
        "/ ノードルームやジオメトリノード系の非破壊ディテールワークフローに着想を得た、Blender 5 で安定しやすいモディファイアスタックを追加します。"
    ))
    bl_options = {'UNDO'}

    preset: EnumProperty(
        name="Preset",
        description=_smart_utils.localize_bilingual_text("Procedural stack recipe to add on top of the active sculpt object / アクティブスカルプトオブジェクトへ追加するプロシージャルスタックのレシピです"),
        items=[
            ('SURFACE_NOISE', "Surface Noise", _smart_utils.localize_bilingual_text("Soft breakup for organic surfaces / 有機表面の軽い荒れ")),
            ('MICRO_BREAKUP', "Micro Breakup", _smart_utils.localize_bilingual_text("Layered high-frequency breakup / 高周波ディテールの積層")),
            ('SHELL', "Shell", _smart_utils.localize_bilingual_text("Solid shell thickness / シェル厚み付与")),
            ('WRINKLE', "Wrinkle", _smart_utils.localize_bilingual_text("Wrinkle-oriented displacement / しわ向けディスプレイス")),
            ('SCAFFOLDER', "Scaffolder", _smart_utils.localize_bilingual_text("Cage-like helper stack inspired by procedural scaffolding / プロシージャルスキャフォールダー風のケージ補助スタック")),
            ('DLA_GROWTH', "DLA Growth", _smart_utils.localize_bilingual_text("Clustered aggregate breakup inspired by diffusion-limited aggregation / 拡散律速凝集に着想を得た集合体風の荒れ")),
            ('HYBRID_SURFACE', "Hybrid Surface", _smart_utils.localize_bilingual_text("Blend smooth base forms with restrained hard-surface style breakup / 滑らかな下地と控えめなハードサーフェス風の荒れを両立")),
        ],
    )

    def _new_texture(self, name: str, texture_type: str):
        tex = bpy.data.textures.new(name=utils.unique_name(name), type=texture_type)
        utils.mark_generated(tex, 'texture')
        return tex

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        original_mode = getattr(obj, 'mode', 'OBJECT') if obj is not None else 'OBJECT'
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        utils.ensure_object_mode(context, obj)
        utils.ensure_single_user_mesh(obj)

        strength = settings.procedural_strength if settings else 0.05
        scale = settings.procedural_scale if settings else 1.0

        try:
            if self.preset == 'SURFACE_NOISE':
                tex = self._new_texture("SSS_SurfaceNoise", 'CLOUDS')
                tex.noise_scale = scale
                mod = obj.modifiers.new(name=utils.unique_name("SSS_SurfaceNoise"), type='DISPLACE')
                mod.texture = tex
                mod.strength = strength
                mod.mid_level = 0.0
                utils.set_attr_if_exists(mod, 'direction', 'NORMAL')
            elif self.preset == 'MICRO_BREAKUP':
                for idx, (noise_scale, mul) in enumerate(((scale, 1.0), (scale * 0.25, 0.35)), start=1):
                    tex = self._new_texture(f"SSS_Micro_{idx}", 'CLOUDS')
                    tex.noise_scale = max(noise_scale, 0.0001)
                    mod = obj.modifiers.new(name=utils.unique_name(f"SSS_Micro_{idx}"), type='DISPLACE')
                    mod.texture = tex
                    mod.strength = strength * mul
                    mod.mid_level = 0.0
                    utils.set_attr_if_exists(mod, 'direction', 'NORMAL')
                smooth = obj.modifiers.new(name=utils.unique_name("SSS_Smooth"), type='SMOOTH')
                smooth.factor = 0.15
                smooth.iterations = 2
            elif self.preset == 'SHELL':
                solidify = obj.modifiers.new(name=utils.unique_name("SSS_Shell"), type='SOLIDIFY')
                solidify.thickness = max(strength, 0.001)
                utils.set_attr_if_exists(solidify, 'use_even_offset', True)
                subsurf = obj.modifiers.new(name=utils.unique_name("SSS_Subsurf"), type='SUBSURF')
                subsurf.levels = 1
                subsurf.render_levels = 1
            elif self.preset == 'WRINKLE':
                tex = self._new_texture("SSS_Wrinkle", 'DISTORTED_NOISE')
                tex.noise_scale = max(scale * 0.5, 0.0001)
                mod = obj.modifiers.new(name=utils.unique_name("SSS_Wrinkle"), type='DISPLACE')
                mod.texture = tex
                mod.strength = strength * 0.6
                mod.mid_level = 0.0
                utils.set_attr_if_exists(mod, 'direction', 'NORMAL')
                smooth = obj.modifiers.new(name=utils.unique_name("SSS_WrinkleSmooth"), type='SMOOTH')
                smooth.factor = 0.08
                smooth.iterations = 1
            elif self.preset == 'SCAFFOLDER':
                remesh = obj.modifiers.new(name=utils.unique_name("SSS_ScaffoldRemesh"), type='REMESH')
                if not utils.set_attr_if_exists(remesh, 'mode', 'BLOCKS'):
                    utils.set_attr_if_exists(remesh, 'mode', 'SHARP')
                utils.set_attr_if_exists(remesh, 'octree_depth', max(4, min(7, int(round(5 + scale * 0.5)))))
                utils.set_attr_if_exists(remesh, 'scale', 0.9)
                utils.set_attr_if_exists(remesh, 'use_remove_disconnected', False)

                wire = obj.modifiers.new(name=utils.unique_name("SSS_ScaffoldWire"), type='WIREFRAME')
                wire.thickness = max(strength * 0.2, 0.001)
                utils.set_attr_if_exists(wire, 'use_even_offset', True)
                utils.set_attr_if_exists(wire, 'use_relative_offset', False)
                utils.set_attr_if_exists(wire, 'use_replace', False)
                utils.set_attr_if_exists(wire, 'offset', 0.0)

                smooth = obj.modifiers.new(name=utils.unique_name("SSS_ScaffoldSmooth"), type='SMOOTH')
                smooth.factor = 0.08
                smooth.iterations = 1
            elif self.preset == 'DLA_GROWTH':
                remesh = obj.modifiers.new(name=utils.unique_name("SSS_DLA_Remesh"), type='REMESH')
                if not utils.set_attr_if_exists(remesh, 'mode', 'SHARP'):
                    utils.set_attr_if_exists(remesh, 'mode', 'BLOCKS')
                utils.set_attr_if_exists(remesh, 'octree_depth', max(4, min(8, int(round(5 + scale)))))
                utils.set_attr_if_exists(remesh, 'scale', 0.92)
                utils.set_attr_if_exists(remesh, 'use_remove_disconnected', False)

                tex = self._new_texture("SSS_DLA_Primary", 'DISTORTED_NOISE')
                tex.noise_scale = max(scale * 0.35, 0.0001)
                mod = obj.modifiers.new(name=utils.unique_name("SSS_DLA_Displace"), type='DISPLACE')
                mod.texture = tex
                mod.strength = strength * 0.55
                mod.mid_level = 0.0
                utils.set_attr_if_exists(mod, 'direction', 'NORMAL')

                tex2 = self._new_texture("SSS_DLA_Secondary", 'CLOUDS')
                tex2.noise_scale = max(scale * 0.12, 0.0001)
                mod2 = obj.modifiers.new(name=utils.unique_name("SSS_DLA_Micro"), type='DISPLACE')
                mod2.texture = tex2
                mod2.strength = strength * 0.18
                mod2.mid_level = 0.0
                utils.set_attr_if_exists(mod2, 'direction', 'NORMAL')

                smooth = obj.modifiers.new(name=utils.unique_name("SSS_DLA_Smooth"), type='SMOOTH')
                smooth.factor = 0.05
                smooth.iterations = 1
            elif self.preset == 'HYBRID_SURFACE':
                subsurf = obj.modifiers.new(name=utils.unique_name("SSS_HybridSubsurf"), type='SUBSURF')
                subsurf.levels = 1
                subsurf.render_levels = 1
                tex = self._new_texture("SSS_HybridSurface", 'DISTORTED_NOISE')
                tex.noise_scale = max(scale * 0.75, 0.0001)
                mod = obj.modifiers.new(name=utils.unique_name("SSS_HybridDisplace"), type='DISPLACE')
                mod.texture = tex
                mod.strength = strength * 0.35
                mod.mid_level = 0.0
                utils.set_attr_if_exists(mod, 'direction', 'NORMAL')
                smooth = obj.modifiers.new(name=utils.unique_name("SSS_HybridSmooth"), type='SMOOTH')
                smooth.factor = 0.12
                smooth.iterations = 2
                bevel = obj.modifiers.new(name=utils.unique_name("SSS_HybridBevel"), type='BEVEL')
                bevel.width = max(strength * 0.05, 0.0002)
                bevel.segments = 2
                utils.set_attr_if_exists(bevel, 'limit_method', 'ANGLE')
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Procedural stack failed: {v0} / プロシージャルスタックに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        utils.restore_mode_after_smart_operation(context, obj, original_mode)
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Procedural stack added: {v0} / プロシージャルスタック追加: {v1}', v0=self.preset, v1=self.preset))
        return {'FINISHED'}


class SSS_OT_create_retopo_setup(Operator):
    bl_idname = "smart_sculpt.create_retopo_setup"
    bl_label = "Create Retopo Setup"
    bl_description = _smart_utils.localize_bilingual_text((
        'Create a retopo helper object from evaluated mesh data with optional Quadriflow, shrinkwrap, mirror, and face snapping. / 評価後メッシュから、任意のクアッドリメッシュ、シュリンクラップ、ミラー、面スナップ設定込みのリトポ補助オブジェクトを作成します。'
    ))
    bl_options = {'UNDO'}

    use_quadriflow: BoolProperty(
        name="Use Quadriflow",
        description=_smart_utils.localize_bilingual_text("Run Quadriflow on the helper mesh before adding retopo modifiers / リトポ補助メッシュ作成前にクアッドリメッシュを実行します"),
        default=True,
    )
    enter_edit_mode: BoolProperty(
        name="Enter Edit Mode",
        description=_smart_utils.localize_bilingual_text("Enter Edit Mode on the new retopo helper when setup finishes / セットアップ完了後、新しいリトポ補助へ編集モードで入ります"),
        default=True,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        source = utils.active_mesh_object(context)
        if source is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        utils.ensure_object_mode(context, source)
        collection = context.collection or context.scene.collection
        retopo = utils.evaluated_mesh_copy(context, source, collection, name=f"{source.name}_retopo", kind='retopo')
        utils.make_active(context, retopo)
        utils.ensure_single_user_mesh(retopo)
        try:
            for mod in reversed(list(retopo.modifiers)):
                retopo.modifiers.remove(mod)
        except Exception:
            pass

        if self.use_quadriflow:
            try:
                utils.safe_operator_call(
                    bpy.ops.object.quadriflow_remesh,
                    [
                        {
                            'target_faces': settings.quad_target_faces if settings else 5000,
                            'use_mesh_symmetry': True,
                            'use_preserve_sharp': True,
                            'use_preserve_boundary': True,
                        },
                        {'target_faces': settings.quad_target_faces if settings else 5000},
                    ],
                )
            except Exception:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Quadriflow in retopo setup failed, continuing with duplicate mesh. / リトポセットアップ内のクアッドリメッシュは失敗しましたが、複製メッシュで続行します。"))

        shrinkwrap = retopo.modifiers.new(name="SSS_Shrinkwrap", type='SHRINKWRAP')
        shrinkwrap.target = source
        utils.set_attr_if_exists(shrinkwrap, 'wrap_method', 'NEAREST_SURFACEPOINT')
        utils.set_attr_if_exists(shrinkwrap, 'offset', settings.retopo_offset if settings else 0.003)

        if settings and settings.retopo_use_mirror:
            mirror = retopo.modifiers.new(name="SSS_Mirror", type='MIRROR')
            try:
                mirror.use_axis[0] = True
            except Exception:
                pass

        utils.set_attr_if_exists(retopo, 'show_in_front', True)
        utils.set_attr_if_exists(retopo, 'display_type', 'WIRE')

        ts = context.scene.tool_settings
        utils.set_attr_if_exists(ts, 'use_snap', True)
        try:
            ts.snap_elements = {'FACE'}
        except Exception:
            pass
        utils.set_attr_if_exists(ts, 'use_snap_project', True)
        utils.set_attr_if_exists(ts, 'use_snap_backface_culling', False)

        if self.enter_edit_mode:
            utils.ensure_edit_mode(context, retopo)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Retopo setup created. / リトポセットアップを作成しました。"))
        return {'FINISHED'}


class SSS_OT_auto_uv_project(Operator):
    bl_idname = "smart_sculpt.auto_uv_project"
    bl_label = "Auto UV Project"
    bl_description = _smart_utils.localize_bilingual_text((
        'Run Smart UV Project on the active mesh, which is useful after extraction, retopo helpers, or simple hard-surface sculpt parts. When supported by the running Blender build, it also tries to normalize island scale and pack islands so the result is easier to bake or texture immediately. / 抽出後メッシュ、リトポ補助オブジェクト、単純なハードサーフェス部品に便利なスマートUV投影を実行します。利用中の Blender が対応していれば、島の縮尺合わせとパックも試み、ベイクやテクスチャ作業へそのまま進みやすくします。'
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        original_mode = getattr(obj, 'mode', 'OBJECT')
        utils.make_recovery_backup(context, obj, 'auto_uv_project')
        uv_count_before = utils.mesh_uv_layer_count(obj)
        if not utils.ensure_edit_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Edit mode. / 編集モードへ入れませんでした。"))
            return {'CANCELLED'}
        try:
            margin = settings.unwrap_margin if settings else 0.02
            utils.safe_operator_call(
                bpy.ops.mesh.select_all,
                [{'action': 'SELECT'}],
            )
            utils.safe_operator_call(
                bpy.ops.uv.smart_project,
                [{'island_margin': margin}],
            )
            try:
                utils.safe_operator_call(
                    bpy.ops.uv.select_all,
                    [{'action': 'SELECT'}],
                )
            except Exception:
                pass
            try:
                utils.safe_operator_call(bpy.ops.uv.average_islands_scale)
            except Exception:
                pass
            try:
                utils.safe_operator_call(
                    bpy.ops.uv.pack_islands,
                    [
                        {'margin': margin},
                        {},
                    ],
                )
            except Exception:
                pass
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Auto UV failed: {v0} / 自動UVに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            if original_mode == 'SCULPT':
                utils.ensure_sculpt_mode(context, obj)
            elif original_mode == 'EDIT':
                utils.ensure_edit_mode(context, obj)
            else:
                utils.ensure_object_mode(context, obj)

        uv_count_after = utils.mesh_uv_layer_count(obj)
        if uv_count_after <= 0:
            restored, reason = utils.restore_recovery_backup_into_object(context, obj)
            if restored:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Auto UV finished without a UV layer, so the mesh was restored from recovery backup ({v0}). / UVレイヤーが作成されなかったため、メッシュを回復バックアップから復元しました（{v1}）。', v0=reason or 'auto_uv_project', v1=reason or 'auto_uv_project'))
            else:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Auto UV finished but no UV layer was created. / 自動UVは完了しましたが、UVレイヤーは作成されませんでした。"))
            return {'CANCELLED'}
        if uv_count_after > uv_count_before:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Auto UV complete ({v0} new UV layer(s)). / 自動UV展開が完了し、新規UVレイヤーを {v1} 個作成しました。', v0=uv_count_after - uv_count_before, v1=uv_count_after - uv_count_before))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Auto UV complete. / 自動UV展開が完了しました。"))
        return {'FINISHED'}


classes = (
    SSS_OT_add_primitive,
    SSS_OT_boolean_from_selection,
    SSS_OT_add_rail_cutter,
    SSS_OT_add_sphere_chain,
    SSS_OT_add_curve_tube,
    SSS_OT_create_anchor_bend_setup,
    SSS_OT_add_detail_scatter,
    SSS_OT_add_procedural_stack,
    SSS_OT_create_retopo_setup,
    SSS_OT_auto_uv_project,
)
