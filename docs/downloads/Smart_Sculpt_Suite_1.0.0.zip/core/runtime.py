# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from . import loader, ui_runtime


def register() -> None:
    loader.register_all()
    ui_runtime.register()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
