# SPDX-License-Identifier: GPL-3.0-or-later
"""Order the tool loader before the UI and reverse that order on teardown."""

from . import loader, ui_runtime


def register():
    loader.register_all()
    ui_runtime.register()


def unregister():
    try:
        ui_runtime.unregister()
    finally:
        loader.unregister_all()
