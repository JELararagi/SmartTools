# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import math
from typing import Iterable

import bpy
from mathutils import Vector

from . import utils as _smart_utils


def _t(en: str, ja: str) -> str:
    try:
        return _smart_utils.ui_text(en, ja)
    except Exception:
        return str(en or ja or '')


def _active_mesh(context):
    obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
    try:
        if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None) is not None:
            return obj
    except Exception:
        return None
    return None


def _safe_collection(context):
    try:
        col = getattr(context, 'collection', None)
        if col is not None:
            return col
    except Exception:
        pass
    try:
        return bpy.context.scene.collection
    except Exception:
        return None


def _bounds(obj):
    if obj is None:
        return Vector((0.0, 0.0, 0.0)), 1.0, Vector((1.0, 1.0, 1.0))
    try:
        pts = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        if not pts:
            raise ValueError
        mn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
        mx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
        size = mx - mn
        radius = max(float(size.x), float(size.y), float(size.z), 0.001)
        return (mn + mx) * 0.5, radius, size
    except Exception:
        return Vector((0.0, 0.0, 0.0)), 1.0, Vector((1.0, 1.0, 1.0))


def _link_object(context, obj):
    col = _safe_collection(context)
    if col is None:
        return False
    try:
        col.objects.link(obj)
        return True
    except Exception:
        try:
            bpy.context.scene.collection.objects.link(obj)
            return True
        except Exception:
            return False


def _unique_name(base: str) -> str:
    base = str(base or 'SSS_Object').strip() or 'SSS_Object'
    if base not in bpy.data.objects and base not in bpy.data.meshes and base not in bpy.data.curves:
        return base
    idx = 1
    while f'{base}.{idx:03d}' in bpy.data.objects or f'{base}.{idx:03d}' in bpy.data.meshes or f'{base}.{idx:03d}' in bpy.data.curves:
        idx += 1
    return f'{base}.{idx:03d}'


def _ensure_material(obj, name: str, color: tuple[float, float, float, float]):
    try:
        mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
        mat.diffuse_color = color
        mats = obj.data.materials
        for idx, existing in enumerate(mats):
            if existing == mat or getattr(existing, 'name', '') == name:
                return idx
        mats.append(mat)
        return len(mats) - 1
    except Exception:
        return 0


def _make_polygroup_integration(context, group_count: int = 6, *, seam_borders: bool = True, sharp_borders: bool = True) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    mesh = obj.data
    group_count = max(2, min(64, int(group_count or 6)))
    try:
        mesh.update(calc_edges=True)
    except Exception:
        pass
    colors = ((0.80,0.34,0.25,1),(0.25,0.50,0.85,1),(0.36,0.72,0.42,1),(0.88,0.68,0.22,1),(0.55,0.38,0.82,1),(0.28,0.72,0.72,1),(0.78,0.42,0.67,1),(0.60,0.60,0.60,1))
    mat_indices = [_ensure_material(obj, f'SSS_Polygroup_{i + 1:02d}', colors[i % len(colors)]) for i in range(group_count)]
    groups = []
    try:
        for i in range(group_count):
            groups.append(obj.vertex_groups.get(f'SSS_Polygroup_{i + 1:02d}') or obj.vertex_groups.new(name=f'SSS_Polygroup_{i + 1:02d}'))
    except Exception:
        groups = []
    poly_values: list[int] = []
    for poly in mesh.polygons:
        try:
            n = poly.normal
            axis = 0 if abs(n.x) >= abs(n.y) and abs(n.x) >= abs(n.z) else (1 if abs(n.y) >= abs(n.z) else 2)
            value = int((poly.index + axis) % group_count)
        except Exception:
            value = int(poly.index % group_count)
        poly_values.append(value)
        try:
            poly.material_index = mat_indices[value]
        except Exception:
            pass
        if groups:
            try:
                groups[value].add(list(poly.vertices), 1.0, 'ADD')
            except Exception:
                pass
    try:
        attr = mesh.attributes.get('SSS_Polygroup_ID') or mesh.attributes.new('SSS_Polygroup_ID', 'INT', 'FACE')
        for idx, item in enumerate(attr.data):
            item.value = int(poly_values[idx] + 1) if idx < len(poly_values) else 0
    except Exception:
        pass
    try:
        edge_key_to_index = {tuple(sorted(edge.vertices)): edge.index for edge in mesh.edges}
        edge_groups: dict[int, set[int]] = {}
        for poly, value in zip(mesh.polygons, poly_values):
            verts = list(poly.vertices)
            for a, b in zip(verts, verts[1:] + verts[:1]):
                edge_index = edge_key_to_index.get(tuple(sorted((a, b))))
                if edge_index is not None:
                    edge_groups.setdefault(edge_index, set()).add(value)
        for edge in mesh.edges:
            border = len(edge_groups.get(edge.index, set())) > 1
            if border and seam_borders:
                edge.use_seam = True
            if border and sharp_borders:
                try:
                    edge.use_edge_sharp = True
                except Exception:
                    pass
    except Exception:
        pass
    try:
        sharp_attr = mesh.attributes.get('sharp_edge') or mesh.attributes.new('sharp_edge', 'BOOLEAN', 'EDGE')
        for edge in mesh.edges:
            try:
                sharp_attr.data[edge.index].value = bool(getattr(edge, 'use_edge_sharp', False) or getattr(edge, 'use_seam', False))
            except Exception:
                pass
    except Exception:
        pass
    try:
        mesh.update()
    except Exception:
        pass
    obj['sss_polygroup_integrated'] = True
    obj['sss_polygroup_count'] = group_count
    return {'object': obj.name, 'groups': group_count, 'faces': len(mesh.polygons)}


def _make_curve_object(context, name: str, points: Iterable[Vector], *, bevel_depth: float = 0.01):
    curve = bpy.data.curves.new(_unique_name(name), 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 8
    try:
        curve.bevel_depth = max(0.0001, float(bevel_depth))
        curve.bevel_resolution = 2
    except Exception:
        pass
    pts = list(points)
    spline = curve.splines.new('POLY')
    spline.points.add(max(0, len(pts) - 1))
    for point, co in zip(spline.points, pts):
        point.co = (float(co.x), float(co.y), float(co.z), 1.0)
    obj = bpy.data.objects.new(curve.name, curve)
    _link_object(context, obj)
    return obj


def _make_flow_guides(context, count: int = 5) -> dict:
    target = _active_mesh(context)
    center, radius, size = _bounds(target)
    count = max(2, min(12, int(count or 5)))
    created = []
    for i in range(count):
        z = center.z + ((i + 1) / (count + 1) - 0.5) * max(size.z, radius) * 0.85
        pts = []
        for step in range(37):
            angle = math.tau * step / 36
            pts.append(Vector((center.x + math.cos(angle) * radius * 0.45, center.y + math.sin(angle) * radius * 0.38, z)))
        created.append(_make_curve_object(context, f'SSS_Flow_Guide_{i + 1:02d}', pts, bevel_depth=radius * 0.006))
    if target is not None:
        target['sss_flow_guides'] = [obj.name for obj in created]
    return {'guides': len(created), 'target': getattr(target, 'name', '')}


def _make_guided_remesh_stack(context, voxel_size: float | None = None) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    _center, radius, _size = _bounds(obj)
    created = []
    try:
        mod = obj.modifiers.new('SSS_Guided_Voxel_Remesh', 'REMESH')
        try: mod.mode = 'VOXEL'
        except Exception: pass
        try: mod.voxel_size = float(voxel_size or max(radius * 0.035, 0.001))
        except Exception: pass
        created.append(mod.name)
    except Exception:
        pass
    try:
        mod = obj.modifiers.new('SSS_Guided_Weighted_Normals', 'WEIGHTED_NORMAL')
        created.append(mod.name)
    except Exception:
        pass
    obj['sss_guided_remesh_stack'] = created
    return {'object': obj.name, 'modifiers': created}


def _make_hd_microtile(context, levels: int = 2, strength: float = 0.035) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    levels = max(1, min(5, int(levels or 2)))
    strength = max(0.0, min(2.0, float(strength or 0.035)))
    created = []
    try:
        if obj.data.shape_keys is None:
            obj.shape_key_add(name='Basis', from_mix=False)
        key = obj.shape_key_add(name=f'SSS_HD_Microtile_Layer_{len(obj.data.shape_keys.key_blocks):02d}', from_mix=False)
        key.value = 0.0
        key.slider_min = -1.0
        key.slider_max = 1.0
        created.append(key.name)
    except Exception:
        pass
    try:
        mod = obj.modifiers.new('SSS_HD_Subdivision_Stage', 'SUBSURF')
        mod.levels = min(levels, 3)
        mod.render_levels = min(levels, 3)
        created.append(mod.name)
    except Exception:
        pass
    try:
        texture = bpy.data.textures.new(_unique_name('SSS_HD_Micro_Noise'), 'VORONOI')
        texture.noise_scale = 0.65
        mod = obj.modifiers.new('SSS_HD_Micro_Displace', 'DISPLACE')
        mod.strength = strength
        mod.texture = texture
        created.append(mod.name)
    except Exception:
        try:
            mod = obj.modifiers.new('SSS_HD_Micro_Displace', 'DISPLACE')
            mod.strength = strength
            created.append(mod.name)
        except Exception:
            pass
    obj['sss_hd_microtile'] = True
    obj['sss_hd_microtile_levels'] = levels
    return {'object': obj.name, 'created': created}


def _cube_mesh(size: float):
    s = float(size) * 0.5
    verts = [(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
    faces = [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]
    return verts, faces


def _cylinder_mesh(radius: float, depth: float, segments: int = 16, cone: bool = False):
    segments = max(6, min(48, int(segments)))
    verts = []
    for z, r in ((-depth * 0.5, radius), (depth * 0.5, 0.0 if cone else radius)):
        for i in range(segments):
            a = math.tau * i / segments
            verts.append((math.cos(a) * r, math.sin(a) * r, z))
    verts.append((0, 0, -depth * 0.5)); verts.append((0, 0, depth * 0.5))
    bc = len(verts) - 2; tc = len(verts) - 1
    faces = []
    for i in range(segments):
        j = (i + 1) % segments
        faces.append((i, j, segments + i) if cone else (i, j, segments + j, segments + i))
        faces.append((bc, j, i))
        if not cone:
            faces.append((tc, segments + i, segments + j))
    return verts, faces


def _add_mesh_object(context, name: str, verts, faces, loc: Vector):
    mesh = bpy.data.meshes.new(_unique_name(name + '_Mesh'))
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_unique_name(name), mesh)
    obj.location = loc
    _link_object(context, obj)
    return obj


def _make_imm_parts(context, part_type: str, count: int, spacing: float) -> dict:
    target = _active_mesh(context)
    center, radius, size = _bounds(target)
    count = max(1, min(64, int(count or 6)))
    spacing = max(0.01, min(10.0, float(spacing or 0.15)))
    part_type = str(part_type or 'BOLT').upper()
    base_size = max(radius * 0.08, 0.025)
    created = []
    total_width = (count - 1) * spacing * radius * 0.25
    for i in range(count):
        loc = Vector((center.x - total_width * 0.5 + i * spacing * radius * 0.25, center.y, center.z + max(size.z, radius) * 0.55))
        if part_type in {'SPIKE', 'HORN'}:
            verts, faces = _cylinder_mesh(base_size, base_size * 2.2, 16, cone=True)
        elif part_type in {'CHAIN', 'RING'}:
            verts, faces = _cylinder_mesh(base_size, base_size * 0.35, 20, cone=False)
        elif part_type in {'PLATE', 'SCALE_PLATE'}:
            verts, faces = _cube_mesh(base_size * 1.8)
        else:
            verts, faces = _cylinder_mesh(base_size, base_size * 0.9, 12, cone=False)
        obj = _add_mesh_object(context, f'SSS_IMM_{part_type}_{i + 1:02d}', verts, faces, loc)
        if target is not None:
            obj['sss_imm_target'] = target.name
        obj['sss_imm_part_type'] = part_type
        created.append(obj.name)
    if target is not None:
        target['sss_imm_parts'] = created
    return {'target': getattr(target, 'name', ''), 'created': created}


def _make_vdm_stamp(context, stamp_type: str, strength: float) -> dict:
    target = _active_mesh(context)
    center, radius, size = _bounds(target)
    stamp_type = str(stamp_type or 'WRINKLE_RIDGE').upper()
    strength = max(0.005, min(2.0, float(strength or 0.04)))
    grid = 8; span = radius * 0.35
    verts = []
    for y in range(grid + 1):
        yy = (y / grid - 0.5) * span
        for x in range(grid + 1):
            xx = (x / grid - 0.5) * span
            r = math.sqrt((xx / max(span, 0.001)) ** 2 + (yy / max(span, 0.001)) ** 2)
            if stamp_type == 'PORE_FIELD':
                zz = (math.sin(x * 12.9898 + y * 78.233) * 0.5 + 0.5) * strength * radius * 0.18
            elif stamp_type == 'EAR_FOLD':
                zz = math.exp(-((xx * 3.0) ** 2 + (yy * 1.5) ** 2) / max(span * span, 0.001)) * strength * radius
            elif stamp_type == 'ROCK_CHIP':
                zz = (1.0 - min(1.0, r * 2.2)) * strength * radius * (1 if (x + y) % 2 else -0.45)
            elif stamp_type == 'CLOTH_FOLD':
                zz = math.sin((xx / max(span, 0.001)) * math.pi * 4.0) * strength * radius * 0.35
            else:
                zz = math.exp(-abs(yy) * 7.0 / max(span, 0.001)) * strength * radius * 0.7
            verts.append((xx, yy, zz))
    faces = []
    for y in range(grid):
        for x in range(grid):
            a = y * (grid + 1) + x
            faces.append((a, a + 1, a + grid + 2, a + grid + 1))
    obj = _add_mesh_object(context, f'SSS_VDM_{stamp_type}', verts, faces, Vector((center.x, center.y, center.z + max(size.z, radius) * 0.62)))
    if target is not None:
        obj['sss_vdm_target'] = target.name
    obj['sss_vdm_stamp_type'] = stamp_type
    return {'created': obj.name, 'type': stamp_type}


def _make_zmodeler_action(context, action: str) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    action = str(action or 'PANEL_LOOP').upper()
    created = []
    if action in {'PANEL_LOOP', 'PANEL_EXTRUDE'}:
        try:
            mod = obj.modifiers.new('SSS_ZModeler_Panel_Solidify', 'SOLIDIFY'); mod.thickness = 0.035; mod.offset = 1.0; created.append(mod.name)
        except Exception: pass
        try:
            mod = obj.modifiers.new('SSS_ZModeler_Panel_Bevel', 'BEVEL'); mod.width = 0.015; mod.segments = 2; created.append(mod.name)
        except Exception: pass
    if action in {'BORDER_BEVEL', 'PANEL_LOOP'}:
        try:
            mod = obj.modifiers.new('SSS_ZModeler_Border_Bevel', 'BEVEL'); mod.width = 0.02; mod.segments = 3; created.append(mod.name)
        except Exception: pass
    if action == 'CREASE_BORDER':
        for edge in obj.data.edges:
            try: edge.use_seam = True
            except Exception: pass
            try: edge.use_edge_sharp = True
            except Exception: pass
        try: obj.data.update()
        except Exception: pass
        created.append('SSS_Crease_Border_Marks')
    if action == 'BRIDGE_GUIDES':
        center, radius, size = _bounds(obj)
        for i, yoff in enumerate((-0.25, 0.0, 0.25), 1):
            curve_obj = _make_curve_object(context, f'SSS_ZModeler_Bridge_Guide_{i}', [Vector((center.x - radius * 0.4, center.y + radius * yoff, center.z + size.z * 0.55)), Vector((center.x + radius * 0.4, center.y + radius * yoff, center.z + size.z * 0.55))], bevel_depth=radius * 0.007)
            created.append(curve_obj.name)
    try:
        mod = obj.modifiers.new('SSS_ZModeler_Weighted_Normals', 'WEIGHTED_NORMAL'); created.append(mod.name)
    except Exception: pass
    obj['sss_zmodeler_last_action'] = action
    return {'object': obj.name, 'action': action, 'created': created}


def _make_sculpt_layer_action(context, action: str) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    action = str(action or 'CREATE').upper()
    if action == 'CREATE':
        if obj.data.shape_keys is None:
            obj.shape_key_add(name='Basis', from_mix=False)
        key = obj.shape_key_add(name=f'SSS_3D_Layer_{len(obj.data.shape_keys.key_blocks):02d}', from_mix=False)
        key.slider_min = -1.0; key.slider_max = 1.0; key.value = 1.0
        obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1
        return {'object': obj.name, 'layer': key.name, 'action': action}
    key = getattr(obj, 'active_shape_key', None)
    if key is None or getattr(obj, 'active_shape_key_index', 0) <= 0:
        raise RuntimeError(_t('Select a sculpt layer shape key first.', '先にスカルプレイヤー用シェイプキーを選択してください。'))
    if action == 'INVERT':
        try:
            basis = obj.data.shape_keys.key_blocks[0]
            for i, point in enumerate(key.data):
                point.co = basis.data[i].co - (point.co - basis.data[i].co)
            key.value = -float(key.value or 1.0)
        except Exception:
            key.value = -float(key.value or 1.0)
    elif action == 'BAKE':
        try:
            basis = obj.data.shape_keys.key_blocks[0]; value = float(key.value or 1.0)
            for i, vert in enumerate(obj.data.vertices):
                vert.co = basis.data[i].co + (key.data[i].co - basis.data[i].co) * value
            obj.data.update()
        except Exception: pass
    elif action == 'DELETE':
        try: obj.shape_key_remove(key)
        except Exception: pass
    return {'object': obj.name, 'action': action}


def _find_shape_key(obj, name: str):
    try:
        return obj.data.shape_keys.key_blocks.get(name) if obj.data.shape_keys else None
    except Exception:
        return None


def _make_morph_target_action(context, action: str) -> dict:
    obj = _active_mesh(context)
    if obj is None:
        raise RuntimeError(_t('Select a mesh object first.', '先にメッシュオブジェクトを選択してください。'))
    action = str(action or 'CAPTURE').upper(); key_name = 'SSS_Morph_Target'
    if action == 'CAPTURE':
        if obj.data.shape_keys is None:
            obj.shape_key_add(name='Basis', from_mix=False)
        old = _find_shape_key(obj, key_name)
        if old is not None:
            try: obj.shape_key_remove(old)
            except Exception: pass
        key = obj.shape_key_add(name=key_name, from_mix=False); key.value = 0.0
        obj['sss_morph_target_key'] = key_name
        return {'object': obj.name, 'action': action, 'key': key.name}
    key = _find_shape_key(obj, key_name)
    if key is None:
        raise RuntimeError(_t('Capture a Morph Target first.', '先にモーフターゲットを記録してください。'))
    if action == 'RESTORE':
        for i, vert in enumerate(obj.data.vertices):
            try: vert.co = key.data[i].co
            except Exception: pass
        obj.data.update()
    elif action == 'BLEND':
        blend = obj.shape_key_add(name=f'SSS_Morph_Blend_{len(obj.data.shape_keys.key_blocks):02d}', from_mix=False)
        for i, point in enumerate(blend.data):
            try: point.co = key.data[i].co
            except Exception: pass
        blend.value = 0.5; obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1
    elif action == 'CLEAR':
        try: obj.shape_key_remove(key)
        except Exception: pass
        try: obj.pop('sss_morph_target_key', None)
        except Exception: pass
    return {'object': obj.name, 'action': action}


def _make_report(context) -> str:
    obj = _active_mesh(context)
    name = 'SSS_ZBrush_Gap_Coverage_Report'
    text = bpy.data.texts.get(name) or bpy.data.texts.new(name)
    text.clear()
    def yes_no(value):
        return _t('Yes', 'あり') if value else _t('No', 'なし')
    lines = [
        _t('Smart Sculpt - ZBrush Gap Coverage Report', 'スマートスカルプト - ZBrush 相当機能のカバレッジレポート'),
        '================================================', '', f"{_t('Target', '対象')}: {getattr(obj, 'name', None) or _t('None', 'なし')}", '',
        _t('Implemented Blender-side coverage:', 'Blender 側で用意している機能:'),
        _t('- HD Geometry gap: HD Microtile stack using Multires/Subdivision + micro Displace + sculpt layer marker.', '- HD ジオメトリ相当: マルチレゾ/サブディビジョン、微細ディスプレイス、スカルプトレイヤーの目印を組み合わせた HD マイクロタイルスタック。'),
        _t('- ZRemesher gap: Flow guide curves, Polygroup attributes, seam/sharp border sync, Guided Remesh stack.', '- ZRemesher 相当: フローガイドカーブ、ポリグループ属性、シーム/シャープ境界の同期、ガイド付きリメッシュスタック。'),
        _t('- IMM gap: Insert Multi Mesh helper parts generated from the N-panel and placed near the sculpt target.', '- IMM 相当: N パネルから作成してスカルプト対象の近くに置く、挿入メッシュの補助パーツ。'),
        _t('- VDM gap: Vector-displacement-style stamp mesh generation for folds, ridges, pores, chips, and cloth forms.', '- VDM 相当: 折り目、尾根、毛穴、欠け、布の形を作るベクトルディスプレイス風のスタンプメッシュ。'),
        _t('- Polygroups gap: Face attribute, materials, vertex groups, seams, and sharp borders synchronized as one trigger system.', '- ポリグループ相当: フェース属性、マテリアル、頂点グループ、シーム、シャープ境界を 1 つの区分として同期。'),
        _t('- ZModeler gap: Panel loop, panel extrude, border bevel, crease border, and bridge guide helpers.', '- ZModeler 相当: パネルループ、パネル押し出し、境界ベベル、境界クリース、ブリッジガイドの補助。'),
        _t('- 3D Layers gap: Shape-key sculpt layers with invert, bake, and delete actions.', '- 3D レイヤー相当: シェイプキーのスカルプトレイヤー（反転、ベイク、削除）。'),
        _t('- Morph Target gap: Capture, restore, blend layer creation, and clear actions.', '- モーフターゲット相当: 記録、復元、ブレンドレイヤーの作成、消去。'), '',
    ]
    if obj is not None:
        lines.extend([f"{_t('Polygroup integrated', 'ポリグループの統合')}: {yes_no(obj.get('sss_polygroup_integrated', False))}", f"{_t('Polygroup count', 'ポリグループ数')}: {int(obj.get('sss_polygroup_count', 0) or 0)}", f"{_t('HD microtile', 'HD マイクロタイル')}: {yes_no(obj.get('sss_hd_microtile', False))}", f"{_t('Flow guides', 'フローガイド')}: {len(obj.get('sss_flow_guides', []) or [])}", f"{_t('IMM parts', 'IMM パーツ')}: {len(obj.get('sss_imm_parts', []) or [])}", f"{_t('Guided remesh modifiers', 'ガイド付きリメッシュのモディファイア')}: {len(obj.get('sss_guided_remesh_stack', []) or [])}"])
    text.write('\n'.join(lines) + '\n')
    return name


class SSS_OT_polygroup_integrate(bpy.types.Operator):
    bl_idname = 'smart_sculpt.polygroup_integrate'; bl_label = 'Create Deep Polygroups'
    bl_description = _smart_utils.localize_bilingual_text('Create ZBrush-like deep Polygroups by syncing face attributes, materials, vertex groups, seams, and sharp borders so retopo, UV, masking, and panel tools can use the same grouping trigger. / フェース属性、マテリアル、頂点グループ、シーム、シャープ境界を同期し、リトポ、UV、マスク、パネル処理の共通トリガーとして使えるZBrush風の深層ポリグループを作成します。')
    bl_options = {'UNDO'}
    group_count: bpy.props.IntProperty(name='Group Count', default=6, min=2, max=64)
    def execute(self, context):
        try:
            settings = getattr(getattr(context, 'scene', None), 'core', None); count = int(getattr(settings, 'zbrush_gap_polygroup_count', self.group_count) or self.group_count)
            info = _make_polygroup_integration(context, count); self.report({'INFO'}, _t(f"Created {info['groups']} Polygroups.", f"{info['groups']} 個のポリグループを作成しました。")); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_flow_remesh_guide_setup(bpy.types.Operator):
    bl_idname = 'smart_sculpt.flow_remesh_guide_setup'; bl_label = 'Create Flow Remesh Guides'
    bl_description = _smart_utils.localize_bilingual_text('Create ZRemesher-style flow guide curves and a safe guided remesh modifier stack for the active sculpt mesh. / アクティブスカルプトメッシュにZRemesher風のエッジフローガイドカーブと安全なガイド付きリメッシュ補助スタックを作成します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            info = _make_flow_guides(context, getattr(getattr(context.scene, 'core', None), 'zbrush_gap_flow_guide_count', 5)); _make_guided_remesh_stack(context); self.report({'INFO'}, _t(f"Created {info['guides']} flow guides.", f"{info['guides']} 本のフローガイドを作成しました。")); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_hd_microtile_setup(bpy.types.Operator):
    bl_idname = 'smart_sculpt.hd_microtile_setup'; bl_label = 'Create HD Microtile Stack'
    bl_description = _smart_utils.localize_bilingual_text('Create a Blender-safe HD detail stack that approximates ZBrush HD Geometry with Multires/Subdivision, micro Displace, and a non-destructive sculpt layer marker. / マルチレゾ/サブディビジョン、微細ディスプレイス、非破壊スカルプレイヤーマーカーでZBrush HD GeometryをBlender安全寄りに近似するHDディテールスタックを作成します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            settings = getattr(getattr(context, 'scene', None), 'core', None); _make_hd_microtile(context, int(getattr(settings, 'zbrush_gap_hd_levels', 2) or 2), float(getattr(settings, 'zbrush_gap_detail_strength', 0.035) or 0.035)); self.report({'INFO'}, _t('HD Microtile stack created.', 'HDマイクロタイルスタックを作成しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_insert_multi_mesh_part(bpy.types.Operator):
    bl_idname = 'smart_sculpt.insert_multi_mesh_part'; bl_label = 'Insert Multi Mesh Asset'
    bl_description = _smart_utils.localize_bilingual_text('Generate IMM-style insert mesh helper parts near the active sculpt target. / アクティブスカルプト対象の近くへIMM風の挿入メッシュ補助パーツを生成します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None); info = _make_imm_parts(context, getattr(s, 'zbrush_gap_imm_part', 'BOLT'), int(getattr(s, 'zbrush_gap_imm_count', 6) or 6), float(getattr(s, 'zbrush_gap_imm_spacing', 0.6) or 0.6)); self.report({'INFO'}, _t(f"Created {len(info['created'])} IMM parts.", f"{len(info['created'])} 個のIMMパーツを作成しました。")); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_vdm_stamp(bpy.types.Operator):
    bl_idname = 'smart_sculpt.vdm_stamp'; bl_label = 'Create VDM Stamp'
    bl_description = _smart_utils.localize_bilingual_text('Create a vector-displacement-style stamp mesh for folds, ridges, pores, rock chips, or cloth wrinkles as reusable sculpt detail geometry. / 折り目、リッジ、毛穴、岩欠け、布しわ用のVDM風スタンプメッシュを、再利用できるスカルプトディテール形状として作成します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None); _make_vdm_stamp(context, getattr(s, 'zbrush_gap_vdm_stamp', 'WRINKLE_RIDGE'), float(getattr(s, 'zbrush_gap_detail_strength', 0.035) or 0.035)); self.report({'INFO'}, _t('VDM stamp created.', 'VDMスタンプを作成しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_zmodeler_sculpt_action(bpy.types.Operator):
    bl_idname = 'smart_sculpt.zmodeler_sculpt_action'; bl_label = 'Run ZModeler Sculpt Action'
    bl_description = _smart_utils.localize_bilingual_text('Run a ZModeler-style hard-surface sculpt helper such as panel loop, panel extrude, border bevel, crease border, or bridge guides. / パネルループ、パネル押し出し、境界ベベル、境界クリース、ブリッジガイドなどのZモデラー風ハードサーフェス補助を実行します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None); _make_zmodeler_action(context, getattr(s, 'zbrush_gap_zmodeler_action', 'PANEL_LOOP')); self.report({'INFO'}, _t('ZModeler helper created.', 'Zモデラー補助を作成しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_sculpt_layer_pro_action(bpy.types.Operator):
    bl_idname = 'smart_sculpt.sculpt_layer_pro_action'; bl_label = 'Run Sculpt Layer Pro Action'
    bl_description = _smart_utils.localize_bilingual_text('Create, invert, bake, or delete a ZBrush-like 3D sculpt layer using Blender shape keys. / Blenderのシェイプキーを使い、ZBrush風3Dスカルプレイヤーの作成、反転、ベイク、削除を行います。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None); _make_sculpt_layer_action(context, getattr(s, 'zbrush_gap_layer_action', 'CREATE')); self.report({'INFO'}, _t('Sculpt layer action finished.', 'スカルプレイヤー操作が完了しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_morph_target_action(bpy.types.Operator):
    bl_idname = 'smart_sculpt.morph_target_action'; bl_label = 'Run Morph Target Action'
    bl_description = _smart_utils.localize_bilingual_text('Capture, restore, blend, or clear a Morph Target using managed shape keys for safe non-destructive sculpt correction. / 管理シェイプキーを使い、モーフターゲットの記録、復元、ブレンド、消去を行い、安全な非破壊スカルプト修正に使います。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None); _make_morph_target_action(context, getattr(s, 'zbrush_gap_morph_action', 'CAPTURE')); self.report({'INFO'}, _t('Morph Target action finished.', 'モーフターゲット操作が完了しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_zbrush_gap_report(bpy.types.Operator):
    bl_idname = 'smart_sculpt.zbrush_gap_report'; bl_label = 'Create ZBrush Gap Report'
    bl_description = _smart_utils.localize_bilingual_text('Write a coverage report describing which ZBrush-class sculpt workflow helpers are present on the current scene and active target. / 現在のシーンとアクティブ対象に対して、ZBrush級スカルプトワークフロー補助の構築状態をカバレッジレポートとして書き出します。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            name = _make_report(context); self.report({'INFO'}, _t(f'Report written: {name}', f'レポートを書き出しました: {name}')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

class SSS_OT_zbrush_gap_pipeline(bpy.types.Operator):
    bl_idname = 'smart_sculpt.zbrush_gap_pipeline'; bl_label = 'Run ZBrush-Class Sculpt Pipeline'
    bl_description = _smart_utils.localize_bilingual_text('Run the integrated Smart Sculpt Suite pipeline covering HD detail, Polygroups, Flow Remesh guides, IMM, VDM, ZModeler helpers, Morph Target, Sculpt Layer, and a coverage report. / HDディテール、ポリグループ、フローリメッシュガイド、IMM、VDM、Zモデラー補助、モーフターゲット、スカルプトレイヤー、カバレッジレポートをまとめて実行する統合スマートスカルプトスイートパイプラインです。')
    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            s = getattr(getattr(context, 'scene', None), 'core', None)
            _make_polygroup_integration(context, int(getattr(s, 'zbrush_gap_polygroup_count', 6) or 6)); _make_flow_guides(context, int(getattr(s, 'zbrush_gap_flow_guide_count', 5) or 5)); _make_guided_remesh_stack(context); _make_hd_microtile(context, int(getattr(s, 'zbrush_gap_hd_levels', 2) or 2), float(getattr(s, 'zbrush_gap_detail_strength', 0.035) or 0.035)); _make_imm_parts(context, getattr(s, 'zbrush_gap_imm_part', 'BOLT'), int(getattr(s, 'zbrush_gap_imm_count', 6) or 6), float(getattr(s, 'zbrush_gap_imm_spacing', 0.6) or 0.6)); _make_vdm_stamp(context, getattr(s, 'zbrush_gap_vdm_stamp', 'WRINKLE_RIDGE'), float(getattr(s, 'zbrush_gap_detail_strength', 0.035) or 0.035)); _make_zmodeler_action(context, getattr(s, 'zbrush_gap_zmodeler_action', 'PANEL_LOOP')); _make_morph_target_action(context, 'CAPTURE'); _make_sculpt_layer_action(context, 'CREATE'); _make_report(context)
            self.report({'INFO'}, _t('ZBrush-class sculpt pipeline finished.', 'ZBrush級スカルプトパイプラインが完了しました。')); return {'FINISHED'}
        except Exception as exc: self.report({'ERROR'}, _smart_utils.exception_ui_text(exc)); return {'CANCELLED'}

classes = (SSS_OT_polygroup_integrate, SSS_OT_flow_remesh_guide_setup, SSS_OT_hd_microtile_setup, SSS_OT_insert_multi_mesh_part, SSS_OT_vdm_stamp, SSS_OT_zmodeler_sculpt_action, SSS_OT_sculpt_layer_pro_action, SSS_OT_morph_target_action, SSS_OT_zbrush_gap_report, SSS_OT_zbrush_gap_pipeline)
