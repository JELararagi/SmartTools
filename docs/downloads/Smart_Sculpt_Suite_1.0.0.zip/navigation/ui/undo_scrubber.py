# SPDX-License-Identifier: GPL-3.0-or-later
"""Keep the legacy hit-test import available without a scrubber surface."""


def is_over_scrubber_bar(*_args, **_kwargs):
    return False
