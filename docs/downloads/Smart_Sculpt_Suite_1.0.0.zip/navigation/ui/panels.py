# SPDX-License-Identifier: GPL-3.0-or-later
"""List collections skipped by canvas hit tests."""

from contextlib import suppress

import bpy

from ... import rna_safety
from ...core import utils


class SCULPTNAV_UL_ignored_collections(bpy.types.UIList):
    bl_idname = "SCULPTNAV_UL_ignored_collections"

    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        glyph = "OUTLINER_COLLECTION"
        if item.collection is None:
            caption = utils.ui_text("(Select Collection)", "(コレクションを選択)")
            layout.label(text=caption, icon=glyph)
            return
        layout.prop(item, "collection", text="", icon=glyph)


classes = (SCULPTNAV_UL_ignored_collections,)


def register():
    with suppress(Exception):
        utils.normalize_class_texts(classes)
        utils.register_runtime_translations()
    rna_safety.register_class(SCULPTNAV_UL_ignored_collections)


def unregister():
    with suppress(Exception):
        rna_safety.unregister_class(SCULPTNAV_UL_ignored_collections)
