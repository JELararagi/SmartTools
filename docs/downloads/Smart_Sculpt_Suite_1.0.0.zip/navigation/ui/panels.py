# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""
Shared UI list for SculptNavigation ignored collections.
The original N-panel host is migrated into Smart Sculpt.
"""

from ...core import utils as _smart_utils
import bpy
from ... import rna_safety as _rna_safety


class SCULPTNAV_UL_ignored_collections(bpy.types.UIList):
    """UIList for displaying ignored collections."""
    bl_idname = "SCULPTNAV_UL_ignored_collections"

    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if item.collection:
            layout.prop(item, "collection", text="", icon='OUTLINER_COLLECTION')
        else:
            layout.label(text=_smart_utils.ui_text("(Select Collection)", "(コレクションを選択)"), icon='OUTLINER_COLLECTION')


classes = (
    SCULPTNAV_UL_ignored_collections,
)



def _safe_register_class(cls):
    return _rna_safety.register_class(cls)


def _safe_unregister_class(cls):
    try:
        return _rna_safety.unregister_class(cls)
    except Exception:
        return False

def register():
    try:
        _smart_utils.normalize_class_texts(classes)
        _smart_utils.register_runtime_translations()
    except Exception:
        pass
    for cls in classes:
        _safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
