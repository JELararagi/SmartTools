# SPDX-License-Identifier: GPL-3.0-or-later
"""Navigation lists and viewport overlays for Smart Sculpt."""
