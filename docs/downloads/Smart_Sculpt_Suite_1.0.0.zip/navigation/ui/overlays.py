# SPDX-License-Identifier: GPL-3.0-or-later
"""Build the Sculpt Navigation edge-zone indicator outside Blender's draw callback."""

import bpy

from ... import _sss_gpu_state as gpu_packets
from ... import _sss_lifecycle as lifecycle
from ..properties import get_addon_preferences, get_wm_props

_COLOR = (0.3, 0.6, 1.0, 0.6)
_REGION = "WINDOW"
_draw_handler = None
_draw_state = {"alive": False, "packet": gpu_packets.EMPTY_PACKET}


def _read_rectangle(region):
    if region is None:
        return None
    return tuple(int(getattr(region, coordinate)) for coordinate in ("x", "y", "width", "height"))


def _border(prefs, viewport):
    _, _, width, height = viewport
    dx = min(width // 2, max(0, int(prefs.border_width or 75)))
    dy = min(height // 2, max(0, int(prefs.border_height or 75)))
    if width <= dx * 2 or height <= dy * 2:
        return ()
    left, right = dx, width - dx
    bottom, top = dy, height - dy
    return (dict(mode="LINE_LOOP", blend="ALPHA",
                 coords=((left, bottom), (right, bottom), (right, top), (left, top)),
                 color=tuple(float(value) for value in getattr(prefs, "border_color", _COLOR)[:4]),
                 line_width=max(1.0, float(getattr(prefs, "border_line_width", 1.0) or 1.0))),)


def refresh(context=None):
    global _draw_state
    context = bpy.context if context is None else context
    active, viewport, border = False, None, ()
    try:
        prefs = get_addon_preferences(context)
        runtime = get_wm_props(context)
        active = bool(runtime.enabled and prefs.show_border_overlay)
        viewport = _read_rectangle(context.region)
        if active and viewport is not None:
            border = _border(prefs, viewport)
    except (AttributeError, KeyError, TypeError, ValueError, ReferenceError, RuntimeError):
        active, viewport, border = False, None, ()
    _draw_state = dict(alive=active, packet=gpu_packets.build_packet(primitives=border, expected_viewport=viewport))


def draw_border_overlay():
    gpu_packets.replay_state_packet(_draw_state)


def register():
    global _draw_handler
    refresh()
    if _draw_state["alive"] and _draw_handler is None:
        _draw_handler, _wrapper = lifecycle.add_draw_handler(
            bpy.types.SpaceView3D, draw_border_overlay, (), _REGION, "POST_PIXEL")


def unregister():
    global _draw_handler, _draw_state
    if _draw_handler is not None:
        lifecycle.remove_draw_handler(bpy.types.SpaceView3D, _draw_handler, _REGION)
        _draw_handler = None
    _draw_state = {"alive": False, "packet": gpu_packets.EMPTY_PACKET}
