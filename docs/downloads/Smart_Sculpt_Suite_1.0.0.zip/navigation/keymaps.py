# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""
Keymap policy for SculptNavigation.

Automatic keymap registration is intentionally disabled. This integrated tool
keeps Blender standard keymaps untouched, so any shortcut setup remains a
manual decision inside Blender Preferences > Keymap.
"""

import bpy  # Kept for API compatibility with callers that expect this module.

# Preserved for compatibility with existing imports.
addon_keymaps = []

# Default registration references, exposed only as static information.
MANUAL_KEYMAP_SPECS = (
    ('Sculpt', 'sculptnav.canvas_navigation', 'LEFTMOUSE', 'PRESS', False, False, False),
    ('Sculpt', 'sculptnav.canvas_pan', 'LEFTMOUSE', 'PRESS', True, False, False),
    ('Sculpt', 'sculptnav.canvas_rmb_navigation', 'RIGHTMOUSE', 'PRESS', False, False, False),
    ('Sculpt', 'sculptnav.canvas_rmb_zoom', 'RIGHTMOUSE', 'PRESS', True, False, False),
    ('Sculpt', 'sculptnav.roll', 'LEFTMOUSE', 'PRESS', True, False, True),
)


def register():
    """Do not touch Blender keymaps automatically."""
    addon_keymaps.clear()



def unregister():
    """Do not touch Blender keymaps automatically."""
    addon_keymaps.clear()
