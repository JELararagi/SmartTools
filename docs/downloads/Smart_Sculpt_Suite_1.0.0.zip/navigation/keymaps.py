# SPDX-License-Identifier: GPL-3.0-or-later
"""Publish shortcut suggestions without editing Blender's key configuration."""

import bpy


addon_keymaps = []
_GESTURES = (
    ("canvas_navigation", "LEFTMOUSE", False, False),
    ("canvas_pan", "LEFTMOUSE", True, False),
    ("canvas_rmb_navigation", "RIGHTMOUSE", False, False),
    ("canvas_rmb_zoom", "RIGHTMOUSE", True, False),
    ("roll", "LEFTMOUSE", True, True),
)
MANUAL_KEYMAP_SPECS = tuple(
    ("Sculpt", f"sculptnav.{action}", button, "PRESS", shift, False, alt)
    for action, button, shift, alt in _GESTURES
)


def register():
    addon_keymaps.clear()


unregister = register
