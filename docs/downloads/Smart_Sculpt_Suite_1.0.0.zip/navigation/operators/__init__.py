# SPDX-License-Identifier: GPL-3.0-or-later
"""Operator implementations for canvas and brush gestures."""
