# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""
Brush adjustment operator for SculptNavigation.
Allows adjusting brush size (horizontal) and strength (vertical) by dragging.
"""

import bpy
from ... import rna_safety as _rna_safety
from ... import _sss_lifecycle as _lifecycle
from ... import _sss_gpu_state as _gpu_state
from ... import _sss_runtime_errors as _runtime_errors

from ...core import utils as _smart_utils
from bpy.props import IntProperty
import math

from ..properties import get_addon_preferences


def _tr(text: str) -> str:
    try:
        return str(bpy.app.translations.pgettext_iface(text) or text)
    except Exception:
        return text
from ..core.hit_testing import get_active_brush


def _safe_cursor_set(context, cursor):
    try:
        window = getattr(context, 'window', None)
        if window is not None:
            window.cursor_set(cursor)
    except Exception:
        pass


def _safe_cursor_warp(context, x, y):
    try:
        window = getattr(context, 'window', None)
        if window is not None:
            window.cursor_warp(int(x), int(y))
    except Exception:
        pass


def _safe_tag_redraw(context):
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


def _safe_modal_handler_add(context, operator):
    try:
        wm = getattr(context, 'window_manager', None)
        if wm is not None:
            wm.modal_handler_add(operator)
            return True
    except Exception:
        pass
    return False


def sample_brush_curve(brush, distance_normalized):
    """
    Sample the brush's actual falloff curve at a given distance.

    Args:
        brush: Blender brush object
        distance_normalized: 0.0 to 1.0 (center to edge)

    Returns:
        float: 0.0 to 1.0 intensity value, or None if sampling failed
    """
    if not brush:
        return None

    # Blender 5.0 renamed brush.curve to brush.curve_distance_falloff
    curve = None
    if hasattr(brush, 'curve_distance_falloff'):
        curve = brush.curve_distance_falloff
    elif hasattr(brush, 'curve'):
        curve = brush.curve

    if not curve:
        return None

    try:
        if hasattr(curve, 'curves') and len(curve.curves) > 0:
            # The brush curve maps distance (0-1) to intensity (0-1)
            return curve.evaluate(curve.curves[0], distance_normalized)
    except Exception:
        pass

    return None


def get_brush_falloff_preset(brush):
    """
    Get the brush's falloff preset name.

    Args:
        brush: Blender brush object

    Returns:
        str: Preset name like 'SMOOTH', 'SHARP', etc., or None if not found
    """
    if not brush:
        return None

    # Blender 5.0 renamed brush.curve_preset to brush.curve_distance_falloff_preset
    preset = None
    if hasattr(brush, 'curve_distance_falloff_preset'):
        preset = brush.curve_distance_falloff_preset
    elif hasattr(brush, 'curve_preset'):
        preset = brush.curve_preset

    if preset:
        # Handle enum objects
        if hasattr(preset, 'identifier'):
            return preset.identifier
        elif isinstance(preset, str):
            return preset
        else:
            return str(preset)

    return None


def get_falloff_value(distance_normalized, preset, brush=None):
    """
    Calculate falloff intensity at a normalized distance (0=center, 1=edge).

    Args:
        distance_normalized: 0.0 to 1.0 (center to edge)
        preset: Brush curve_preset string
        brush: Brush object (needed for CUSTOM curves or direct sampling)

    Returns:
        float: 0.0 to 1.0 intensity value (1.0 at center, 0.0 at edge)
    """
    d = min(1.0, max(0.0, distance_normalized))  # Clamp to 0-1
    inv_d = 1.0 - d  # Inverse distance (1 at center, 0 at edge)

    # Try to detect and use the brush's actual preset if 'FROM_BRUSH'
    if preset == 'FROM_BRUSH' and brush:
        # First try to get the preset name from the brush
        detected_preset = get_brush_falloff_preset(brush)
        if detected_preset and detected_preset != 'CUSTOM':
            # Recursively call with the detected preset
            return get_falloff_value(d, detected_preset, brush)
        # If custom or can't detect preset, sample the curve directly
        sampled = sample_brush_curve(brush, d)
        if sampled is not None:
            return sampled

    if preset == 'CONSTANT':
        return 1.0
    elif preset == 'LIN':  # Linear
        return inv_d
    elif preset == 'SHARP':
        # Sharp falloff: (1-d)^2 - drops quickly near edge
        return inv_d * inv_d
    elif preset == 'ROOT':
        # Root falloff: sqrt(1-d) - slow initial drop, faster near edge
        return math.sqrt(inv_d)
    elif preset == 'SPHERE':
        # Spherical/hemisphere: sqrt(1-d^2)
        return math.sqrt(max(0.0, 1.0 - d * d))
    elif preset == 'POW4':
        # Sharper falloff: (1-d)^4
        return inv_d ** 4
    elif preset == 'INVSQUARE':
        # Inverse square: (1-sqrt(d))^2
        return (1.0 - math.sqrt(d)) ** 2
    elif preset == 'SMOOTH':
        # Smooth hermite/smoothstep: 3t^2 - 2t^3 where t = (1-d)
        return inv_d * inv_d * (3.0 - 2.0 * inv_d)
    elif preset == 'SMOOTHER':
        # Even smoother: 6t^5 - 15t^4 + 10t^3
        return inv_d * inv_d * inv_d * (inv_d * (inv_d * 6.0 - 15.0) + 10.0)
    elif preset == 'CUSTOM' and brush and hasattr(brush, 'curve'):
        # Sample the custom curve
        sampled = sample_brush_curve(brush, d)
        if sampled is not None:
            return sampled
        return inv_d  # Fallback to linear
    else:
        # Default fallback to linear
        return inv_d


def _adjust_viewport(region):
    try:
        return (int(region.x), int(region.y), int(region.width), int(region.height))
    except Exception:
        return None


def _draw_brush_adjust_packet(state):
    """Draw callback: immutable packet replay only."""
    _gpu_state.replay_state_packet(state)


def _make_brush_adjust_packet(cx, cy, current_size, initial_size, current_strength, prefs, brush, region, hint_text=None):
    primitives = []
    texts = []
    segments = 64
    ring_scale = float(getattr(prefs, 'brush_ring_scale', 1.0) or 1.0)
    radius = max(1.0, float(current_size) * ring_scale)
    initial_radius = max(1.0, float(initial_size) * ring_scale)
    ring_color = tuple(float(v) for v in tuple(getattr(prefs, 'brush_ring_color', (1.0, 1.0, 1.0, 0.85)))[:4])
    strength_color = tuple(float(v) for v in tuple(getattr(prefs, 'brush_strength_color', (0.3, 0.6, 1.0, 0.35)))[:4])
    ring = tuple((float(cx) + radius * math.cos(math.tau * i / segments),
                  float(cy) + radius * math.sin(math.tau * i / segments)) for i in range(segments))
    primitives.append({'mode': 'LINE_LOOP', 'coords': ring, 'color': ring_color, 'line_width': 2.0})
    preset = str(getattr(prefs, 'brush_falloff_curve', 'FROM_BRUSH'))
    curve = []
    mirror = []
    for i in range(49):
        xoff = (i / 48.0 * 2.0 - 1.0) * radius
        value = get_falloff_value(abs(xoff) / radius, preset, brush)
        yoff = float(value) * radius * 0.6
        curve.append((float(cx) + xoff, float(cy) + yoff))
        mirror.append((float(cx) + xoff, float(cy) - yoff))
    primitives.append({'mode': 'LINE_STRIP', 'coords': tuple(curve), 'color': (1.0, 1.0, 1.0, 0.8), 'line_width': 2.0})
    primitives.append({'mode': 'LINE_STRIP', 'coords': tuple(mirror), 'color': (1.0, 1.0, 1.0, 0.4), 'line_width': 1.5})
    arc_count = max(0, min(segments, int(segments * float(current_strength))))
    if arc_count > 2:
        arc = [(float(cx), float(cy))]
        for i in range(arc_count + 1):
            angle = -math.pi / 2.0 - (i / segments) * math.pi
            arc.append((float(cx) + radius * 0.7 * math.cos(angle), float(cy) + radius * 0.7 * math.sin(angle)))
        primitives.append({'mode': 'TRI_FAN', 'coords': tuple(arc), 'color': strength_color})
    if int(initial_size) != int(current_size):
        dashed = []
        for i in range(0, segments, 2):
            for j in (i, i + 1):
                angle = j / segments * math.tau
                dashed.append((float(cx) + initial_radius * math.cos(angle), float(cy) + initial_radius * math.sin(angle)))
        primitives.append({'mode': 'LINES', 'coords': tuple(dashed), 'color': (0.5, 0.5, 0.5, 0.4), 'line_width': 1.0})
    label = f"{_tr('Size')}: {int(current_size)}   {_tr('Strength')}: {float(current_strength):.3f}"
    texts.append({'text': label, 'x': float(cx) + radius + 12.0, 'y': float(cy) + 10.0,
                  'size': 13, 'color': (1.0, 1.0, 1.0, 1.0)})
    if hint_text:
        texts.append({'text': str(hint_text), 'x': float(cx) - radius, 'y': float(cy) - radius - 20.0,
                      'size': 11, 'color': (0.7, 0.7, 0.7, 0.8)})
    return _gpu_state.build_packet(primitives=tuple(primitives), texts=tuple(texts),
                                   expected_viewport=_adjust_viewport(region))


class SCULPTNAV_OT_brush_adjust(bpy.types.Operator):
    """Adjust brush size (horizontal) and strength (vertical) by dragging"""

    bl_idname = "sculptnav.brush_adjust"
    bl_label = "SculptNavigation Brush Adjust"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    # Initial mouse position (passed from navigation operator)
    initial_x: IntProperty(options={'HIDDEN', 'SKIP_SAVE'})
    initial_y: IntProperty(options={'HIDDEN', 'SKIP_SAVE'})

    # Internal state
    _brush = None
    _initial_size = 0
    _initial_strength = 0.0
    _draw_handler = None
    _prefs = None
    _ups = None  # Unified paint settings (Blender 5.0: per-mode)
    _use_unified_size = False
    _use_unified_strength = False
    # Accumulated deltas for cursor tracking
    _accumulated_delta_x = 0.0
    _accumulated_delta_y = 0.0
    _last_mouse_x = 0
    _last_mouse_y = 0
    _is_tablet = False  # Track if using tablet input

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D' and
            context.mode in ('SCULPT', 'PAINT_VERTEX', 'PAINT_WEIGHT', 'PAINT_TEXTURE') and
            get_active_brush(context) is not None
        )

    def _get_unified_paint_settings(self, context):
        """Get unified paint settings for current mode with Blender 5.1-safe guards."""
        try:
            ts = getattr(context, 'tool_settings', None)
            mode = str(getattr(context, 'mode', '') or '')
        except Exception:
            return None
        if ts is None:
            return None
        try:
            if mode == 'SCULPT':
                sculpt = getattr(ts, 'sculpt', None)
                return getattr(sculpt, 'unified_paint_settings', None) if sculpt is not None else None
            if mode == 'PAINT_VERTEX':
                vp = getattr(ts, 'vertex_paint', None)
                return getattr(vp, 'unified_paint_settings', None) if vp is not None else None
            if mode == 'PAINT_WEIGHT':
                wp = getattr(ts, 'weight_paint', None)
                return getattr(wp, 'unified_paint_settings', None) if wp is not None else None
            if mode == 'PAINT_TEXTURE':
                ip = getattr(ts, 'image_paint', None)
                return getattr(ip, 'unified_paint_settings', None) if ip is not None else None
        except Exception:
            return None
        return None

    def invoke(self, context, event):
        if not self.poll(context):
            return {'PASS_THROUGH'}

        self._prefs = get_addon_preferences(context)
        self._brush = get_active_brush(context)

        if not self._brush:
            self.report({'WARNING'}, _tr("No active brush found"))
            return {'CANCELLED'}

        # Get unified paint settings for Blender 5.0 (now per-mode)
        self._ups = self._get_unified_paint_settings(context)

        # Determine if using unified size/strength
        self._use_unified_size = self._ups.use_unified_size if self._ups else False
        self._use_unified_strength = self._ups.use_unified_strength if self._ups else False

        # Store initial values (from unified settings if enabled, else from brush)
        if self._use_unified_size and self._ups:
            self._initial_size = self._ups.size
        else:
            self._initial_size = self._brush.size

        if self._use_unified_strength and self._ups:
            self._initial_strength = self._ups.strength
        else:
            self._initial_strength = self._brush.strength

        # Store unprojected_radius for sculpt brushes
        if hasattr(self._brush, 'unprojected_radius'):
            self._initial_unprojected_radius = self._brush.unprojected_radius

        # Use passed initial position or current event position
        if self.initial_x != 0 or self.initial_y != 0:
            self._initial_mouse = (self.initial_x, self.initial_y)
        else:
            self._initial_mouse = (event.mouse_region_x, event.mouse_region_y)

        # Detect tablet input - tablets use absolute positioning, so cursor warp doesn't work
        self._is_tablet = getattr(event, 'is_tablet', False)

        # Initialize cursor tracking
        self._accumulated_delta_x = 0.0
        self._accumulated_delta_y = 0.0
        self._last_mouse_x = event.mouse_x
        self._last_mouse_y = event.mouse_y

        # Add draw handler for visual feedback.  If Blender rejects handler
        # creation during a mode switch, continue without the overlay.
        self._draw_state = {'alive': True, 'packet': _gpu_state.EMPTY_PACKET}
        self._sync_draw_packet(context)
        try:
            self._draw_handler, self._draw_callback_guard = _lifecycle.add_draw_handler(
                bpy.types.SpaceView3D, _draw_brush_adjust_packet, (self._draw_state,), 'WINDOW', 'POST_PIXEL')
        except Exception as exc:
            _runtime_errors.record('brush_adjust_draw_handler', exc)
            self._draw_handler = None

        # Change cursor to indicate adjustment mode
        _safe_cursor_set(context, 'SCROLL_XY')

        _safe_modal_handler_add(context, self)
        _safe_tag_redraw(context)

        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            # Update tablet detection (in case it changes mid-drag)
            if getattr(event, 'is_tablet', False):
                self._is_tablet = True

            # Calculate delta from last position
            delta_x = event.mouse_x - self._last_mouse_x
            delta_y = event.mouse_y - self._last_mouse_y
            self._accumulated_delta_x += delta_x
            self._accumulated_delta_y += delta_y

            if self._is_tablet:
                # Tablet: Don't warp cursor (absolute positioning)
                # Just track the movement normally
                self._last_mouse_x = event.mouse_x
                self._last_mouse_y = event.mouse_y
            else:
                # Mouse: Warp cursor back to initial position (keeps brush cursor fixed)
                region = getattr(context, 'region', None)
                region_x = int(getattr(region, 'x', 0) or 0)
                region_y = int(getattr(region, 'y', 0) or 0)
                warp_x = self._initial_mouse[0] + region_x
                warp_y = self._initial_mouse[1] + region_y
                _safe_cursor_warp(context, warp_x, warp_y)
                # Update last mouse to warped position for next frame
                self._last_mouse_x = warp_x
                self._last_mouse_y = warp_y

            changed = self._update_brush(context)
            if changed:
                self._sync_draw_packet(context)
                if context.area:
                    _safe_tag_redraw(context)
            return {'RUNNING_MODAL'}

        if event.type == 'RIGHTMOUSE' and event.value == 'RELEASE':
            self._cleanup(context)
            return {'FINISHED'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._cleanup(context)
            return {'FINISHED'}

        if event.type == 'ESC':
            # Restore original values
            if self._brush:
                if self._use_unified_size and self._ups:
                    self._ups.size = self._initial_size
                else:
                    self._brush.size = self._initial_size

                if self._use_unified_strength and self._ups:
                    self._ups.strength = self._initial_strength
                else:
                    self._brush.strength = self._initial_strength
            self._cleanup(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _update_brush(self, context):
        """Update brush properties based on accumulated mouse movement."""
        if not self._brush:
            return False

        changed = False

        # Use accumulated deltas (cursor is locked, so we track virtually)
        delta_x = self._accumulated_delta_x
        delta_y = self._accumulated_delta_y

        # Apply invert preferences
        if self._prefs.brush_invert_size:
            delta_x = -delta_x
        if self._prefs.brush_invert_strength:
            delta_y = -delta_y

        # Horizontal movement -> brush size
        size_delta = delta_x / self._prefs.brush_size_sensitivity
        new_size = self._initial_size + size_delta
        # Clamp to valid range (Blender's max is 1000)
        new_size = max(1, min(1000, int(new_size)))

        # Apply size to unified settings or brush directly
        if self._use_unified_size and self._ups:
            if int(getattr(self._ups, 'size', new_size)) != int(new_size):
                self._ups.size = new_size
                changed = True
        else:
            if int(getattr(self._brush, 'size', new_size)) != int(new_size):
                self._brush.size = new_size
                changed = True

        # Also set unprojected_radius for sculpt brushes (3D size)
        if hasattr(self._brush, 'unprojected_radius') and self._initial_size > 0 and hasattr(self, '_initial_unprojected_radius'):
            scale = new_size / self._initial_size
            target_radius = self._initial_unprojected_radius * scale
            current_radius = float(getattr(self._brush, 'unprojected_radius', target_radius))
            if abs(current_radius - float(target_radius)) > 1e-6:
                self._brush.unprojected_radius = target_radius
                changed = True

        # Vertical movement -> brush strength
        strength_delta = delta_y / self._prefs.brush_strength_sensitivity
        new_strength = self._initial_strength + strength_delta
        # Clamp to valid range
        new_strength = max(0.0, min(1.0, new_strength))

        # Apply strength to unified settings or brush directly
        if self._use_unified_strength and self._ups:
            current_strength = float(getattr(self._ups, 'strength', new_strength))
            if abs(current_strength - float(new_strength)) > 1e-6:
                self._ups.strength = new_strength
                changed = True
        else:
            current_strength = float(getattr(self._brush, 'strength', new_strength))
            if abs(current_strength - float(new_strength)) > 1e-6:
                self._brush.strength = new_strength
                changed = True
        return changed

    def _draw_callback(self, context):
        """Compatibility method; production handler does not bind Operator RNA."""
        _gpu_state.replay_state_packet(getattr(self, '_draw_state', None))

    def _sync_draw_packet(self, context):
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict):
            return
        if not self._brush:
            state['packet'] = _gpu_state.EMPTY_PACKET
            return
        current_size = self._ups.size if self._use_unified_size and self._ups else self._brush.size
        current_strength = self._ups.strength if self._use_unified_strength and self._ups else self._brush.strength
        cx, cy = self._initial_mouse
        state['packet'] = _make_brush_adjust_packet(cx, cy, current_size, self._initial_size,
                                                    current_strength, self._prefs, self._brush,
                                                    getattr(context, 'region', None))

    def _cleanup(self, context):
        """Release the exact current-generation draw handler and state."""
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
            state['packet'] = _gpu_state.EMPTY_PACKET
        if getattr(self, '_draw_handler', None) is not None:
            _lifecycle.remove_draw_handler(bpy.types.SpaceView3D, self._draw_handler, 'WINDOW')
            self._draw_handler = None
        self._draw_state = None
        _safe_cursor_set(context, 'DEFAULT')
        self._brush = None
        self._prefs = None
        self._ups = None
        self._use_unified_size = False
        self._use_unified_strength = False
        self._is_tablet = False
        if getattr(context, 'area', None):
            _safe_tag_redraw(context)


classes = (
    SCULPTNAV_OT_brush_adjust,
)



def _safe_register_class(cls):
    return _rna_safety.register_class(cls)


def _safe_unregister_class(cls):
    try:
        return _rna_safety.unregister_class(cls)
    except Exception:
        return False

def register():
    try:
        _smart_utils.normalize_class_texts(classes)
        _smart_utils.register_runtime_translations()
    except Exception:
        pass
    for cls in classes:
        _safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
