# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""
Canvas Navigation for SculptNavigation - 3D Coat-style navigation.

LMB on empty canvas space triggers orbit navigation (like MMB).
LMB on mesh passes through to normal sculpt/paint behavior.
Shift+LMB = Pan navigation.
Double-click on empty space frames the selected object(s).

This creates a seamless pen tablet workflow without needing MMB.
"""

import bpy
from ... import rna_safety as _rna_safety
from ... import _sss_lifecycle as _lifecycle
from ... import _sss_gpu_state as _gpu_state
from ... import _sss_runtime_errors as _runtime_errors

from ...core import utils as _smart_utils
import blf
import time
from bpy_extras import view3d_utils
from mathutils import Vector, Quaternion
from math import radians

from ..properties import get_addon_preferences, get_wm_props
from ..core.hit_testing import hit_test_context, is_navigation_enabled, get_active_brush, check_border_zone
from .brush_adjust import _make_brush_adjust_packet




# Double-click tracking
_last_click_time = 0
_last_click_pos = (0, 0)

# Mode mapping: context.mode -> mode_set argument
MODE_MAP = {
    'SCULPT': 'SCULPT',
    'PAINT_VERTEX': 'VERTEX_PAINT',
    'PAINT_WEIGHT': 'WEIGHT_PAINT',
    'PAINT_TEXTURE': 'TEXTURE_PAINT',
    'EDIT_MESH': 'EDIT',
    'EDIT_CURVE': 'EDIT',
    'EDIT_SURFACE': 'EDIT',
    'EDIT_ARMATURE': 'EDIT',
    'POSE': 'POSE',
}


def _rna_pointer_is_valid(value):
    if value is None:
        return False
    try:
        _ = value.name
    except ReferenceError:
        return False
    except Exception:
        pass
    try:
        _ = value.as_pointer()
    except ReferenceError:
        return False
    except Exception:
        return False
    return True


def _safe_getattr(obj, name, default=None):
    try:
        return getattr(obj, name, default)
    except ReferenceError:
        return default
    except Exception:
        return default


def _safe_active_object(context):
    obj = _safe_getattr(context, 'active_object', None)
    if _rna_pointer_is_valid(obj):
        return obj
    obj = _safe_getattr(context, 'object', None)
    if _rna_pointer_is_valid(obj):
        return obj
    try:
        obj = context.view_layer.objects.active
    except Exception:
        obj = None
    return obj if _rna_pointer_is_valid(obj) else None


def _safe_selected_objects(context):
    try:
        return [obj for obj in context.selected_objects if _rna_pointer_is_valid(obj)]
    except Exception:
        return []


def _safe_context_mode(context):
    return str(_safe_getattr(context, 'mode', '') or '')


def _view3d_region_ready(context):
    return bool(_safe_getattr(context, 'area', None) and _safe_getattr(context.area, 'type', None) == 'VIEW_3D' and _safe_getattr(context, 'region', None) and _safe_getattr(context, 'region_data', None))


def _safe_view_selected_or_all(use_all=False):
    try:
        if use_all:
            result = bpy.ops.view3d.view_all('INVOKE_DEFAULT')
        else:
            result = bpy.ops.view3d.view_selected('INVOKE_DEFAULT')
        return result in ({'FINISHED'}, {'RUNNING_MODAL'})
    except Exception:
        try:
            bpy.ops.view3d.view_all('INVOKE_DEFAULT')
            return True
        except Exception:
            return False


def _safe_cursor_set(context, cursor):
    try:
        window = _safe_getattr(context, 'window', None)
        if window is not None:
            window.cursor_set(cursor)
    except Exception:
        pass


def _safe_cursor_warp(context, x, y):
    try:
        window = _safe_getattr(context, 'window', None)
        if window is not None:
            window.cursor_warp(int(x), int(y))
    except Exception:
        pass


def _safe_tag_redraw(context):
    try:
        area = _safe_getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


def _safe_modal_handler_add(context, operator):
    try:
        wm = _safe_getattr(context, 'window_manager', None)
        if wm is not None:
            wm.modal_handler_add(operator)
            return True
    except Exception:
        pass
    return False


def _safe_event_timer_add(context, time_step):
    wm = _safe_getattr(context, 'window_manager', None)
    if wm is None:
        return None
    try:
        return _lifecycle.add_event_timer(
            wm, float(time_step), window=_safe_getattr(context, 'window', None)
        )
    except Exception as exc:
        _runtime_errors.record('canvas_event_timer_add', exc)
        return None


def _safe_event_timer_remove(context, timer):
    if timer is None:
        return False
    wm = _safe_getattr(context, 'window_manager', None)
    if wm is None:
        return False
    try:
        return bool(_lifecycle.remove_event_timer(wm, timer))
    except Exception as exc:
        _runtime_errors.record('canvas_event_timer_remove', exc)
        return False


def get_surface_point(context, event):
    """Return a safe world-space surface point under the cursor, or None."""
    if not _view3d_region_ready(context):
        return None
    try:
        region = context.region
        rv3d = context.region_data
        coord = (int(getattr(event, 'mouse_region_x', 0)), int(getattr(event, 'mouse_region_y', 0)))
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        if view_vector is None or ray_origin is None:
            return None
        depsgraph = context.evaluated_depsgraph_get()
        hit, location, _normal, _index, _obj, _matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)
        return location if hit else None
    except Exception:
        return None




def _is_in_border_zone_fast(context, event, prefs) -> bool:
    try:
        return bool(check_border_zone(
            context,
            event,
            border_width=getattr(prefs, 'border_width', 75),
            border_height=getattr(prefs, 'border_height', 75),
        ).get('in_zone'))
    except Exception:
        return False

def get_orbit_origin(context, event, origin_mode):
    """Return a crash-safe orbit pivot, or None for Blender default."""
    origin_mode = str(origin_mode or 'BLENDER')
    if origin_mode == 'BLENDER':
        return None
    if origin_mode == 'SURFACE':
        surface_point = get_surface_point(context, event)
        if surface_point is not None:
            return surface_point
        obj = _safe_active_object(context)
        try:
            return obj.location.copy() if obj is not None else None
        except Exception:
            return None
    if origin_mode == 'ACTIVE':
        obj = _safe_active_object(context)
        try:
            return obj.location.copy() if obj is not None else None
        except Exception:
            return None
    if origin_mode == 'SELECTION':
        selected = _safe_selected_objects(context)
        if selected:
            center = Vector((0, 0, 0))
            count = 0
            for obj in selected:
                try:
                    center += obj.location
                    count += 1
                except Exception:
                    continue
            if count:
                return center / count
        obj = _safe_active_object(context)
        try:
            return obj.location.copy() if obj is not None else None
        except Exception:
            return None
    if origin_mode == 'CURSOR':
        try:
            return context.scene.cursor.location.copy()
        except Exception:
            return None
    return None


def set_view_pivot(context, location):
    """Set the 3D View pivot when a valid RegionView3D is available."""
    if location is None:
        return
    try:
        rv3d = context.region_data
        if rv3d is not None:
            rv3d.view_location = location
    except Exception:
        return


def _draw_canvas_packet(state):
    """GPU callback: replay one completed immutable packet only."""
    _gpu_state.replay_state_packet(state)


def _draw_focus_hud_packet(state):
    """GPU callback: replay one completed immutable packet only."""
    _gpu_state.replay_state_packet(state)


def _region_viewport(region):
    try:
        return (int(region.x), int(region.y), int(region.width), int(region.height))
    except Exception:
        return None


def _rect_vertices(x, y, width, height):
    x = float(x); y = float(y); width = float(width); height = float(height)
    return ((x, y), (x + width, y), (x + width, y + height), (x, y + height))


def _rect_outline_vertices(x, y, width, height):
    vertices = _rect_vertices(x, y, width, height)
    return (*vertices, vertices[0])


def _measure_text(text, size):
    """Measure text outside draw; deterministic fallback supports headless audit."""
    try:
        blf.size(0, int(size))
        width, height = blf.dimensions(0, str(text))
        return float(width), float(height)
    except Exception:
        return float(len(str(text)) * max(6, int(size) * 0.55)), float(size)


def _build_focus_hud_packet(context, prefs):
    """Build all HUD geometry/text and hit boxes outside the draw callback."""
    region = _safe_getattr(context, 'region', None)
    if region is None:
        return _gpu_state.EMPTY_PACKET, ()
    padding_x, padding_y = 12.0, 10.0
    row_height, check_size, check_margin = 24.0, 14.0, 8.0
    title_font_size, label_font_size, row_spacing = 12, 11, 4.0
    labels = (
        _smart_utils.translate_registered_text('Mirror'),
        _smart_utils.translate_registered_text('Array'),
        _smart_utils.translate_registered_text('Solidify'),
    )
    max_label_w = max((_measure_text(label, label_font_size)[0] for label in labels), default=70.0)
    title_text = _smart_utils.translate_registered_text('Ignore Modifiers')
    title_w = _measure_text(title_text, title_font_size)[0]
    panel_inner_w = max(check_size + check_margin + max_label_w, title_w)
    total_width = max(160.0, padding_x * 2.0 + panel_inner_w)
    title_area = 22.0
    total_height = padding_y * 2.0 + title_area + (row_height + row_spacing) * 3.0
    margin = 16.0
    position = str(getattr(prefs, 'focus_hud_position', 'BOTTOM_RIGHT') or 'BOTTOM_RIGHT')
    region_width = float(getattr(region, 'width', 0.0) or 0.0)
    region_height = float(getattr(region, 'height', 0.0) or 0.0)
    if position == 'BOTTOM_LEFT':
        x, y = margin, margin
    elif position == 'TOP_LEFT':
        x, y = margin, region_height - total_height - margin
    elif position == 'TOP_RIGHT':
        x, y = region_width - total_width - margin, region_height - total_height - margin
    else:
        x, y = region_width - total_width - margin, margin
    x += float(getattr(prefs, 'focus_hud_offset_x', 0.0) or 0.0)
    y += float(getattr(prefs, 'focus_hud_offset_y', 0.0) or 0.0)

    bg_color = (0.188, 0.188, 0.188, 0.95)
    header_color = (0.22, 0.22, 0.22, 1.0)
    border_color = (0.098, 0.098, 0.098, 1.0)
    title_color = (0.85, 0.85, 0.85, 1.0)
    label_color = (0.78, 0.78, 0.78, 1.0)
    check_on_color = (0.33, 0.55, 0.82, 1.0)
    check_off_color = (0.28, 0.28, 0.28, 1.0)
    check_border_color = (0.45, 0.45, 0.45, 1.0)
    check_mark_color = (1.0, 1.0, 1.0, 1.0)

    primitives = []
    texts = []
    primitives.append({'mode': 'TRI_FAN', 'coords': _rect_vertices(x, y, total_width, total_height), 'color': bg_color})
    header_h = title_area + padding_y
    header_y = y + total_height - header_h
    primitives.append({'mode': 'TRI_FAN', 'coords': _rect_vertices(x, header_y, total_width, header_h), 'color': header_color})
    primitives.append({'mode': 'LINE_STRIP', 'coords': _rect_outline_vertices(x, y, total_width, total_height), 'color': border_color, 'line_width': 1.0})
    primitives.append({'mode': 'TRI_FAN', 'coords': _rect_vertices(x, header_y, total_width, 1.0), 'color': border_color})
    texts.append({'text': title_text, 'x': x + padding_x,
                  'y': header_y + (header_h - title_font_size) / 2.0,
                  'size': title_font_size, 'color': title_color})

    buttons = []
    button_data = (
        ('focus_ignore_mirror', labels[0]),
        ('focus_ignore_array', labels[1]),
        ('focus_ignore_solidify', labels[2]),
    )
    row_start_y = header_y - padding_y - row_height
    for index, (prop_name, label) in enumerate(button_data):
        row_y = row_start_y - index * (row_height + row_spacing)
        enabled = bool(getattr(prefs, prop_name, False))
        buttons.append({'x': x, 'y': row_y, 'w': total_width, 'h': row_height, 'prop': prop_name})
        check_x = x + padding_x
        check_y = row_y + (row_height - check_size) / 2.0
        primitives.append({'mode': 'TRI_FAN', 'coords': _rect_vertices(check_x, check_y, check_size, check_size),
                           'color': check_on_color if enabled else check_off_color})
        primitives.append({'mode': 'LINE_STRIP', 'coords': _rect_outline_vertices(check_x, check_y, check_size, check_size),
                           'color': check_border_color, 'line_width': 1.0})
        if enabled:
            mark = ((check_x + 3.0, check_y + check_size * 0.45),
                    (check_x + check_size * 0.4, check_y + 3.0),
                    (check_x + check_size - 3.0, check_y + check_size - 4.0))
            primitives.append({'mode': 'LINE_STRIP', 'coords': mark, 'color': check_mark_color, 'line_width': 2.0})
        label_height = _measure_text(label, label_font_size)[1]
        texts.append({'text': label, 'x': check_x + check_size + check_margin,
                      'y': row_y + (row_height - label_height) / 2.0,
                      'size': label_font_size, 'color': label_color})
    packet = _gpu_state.build_packet(
        primitives=tuple(primitives), texts=tuple(texts),
        expected_viewport=_region_viewport(region),
    )
    return packet, tuple(buttons)


class SCULPTNAV_OT_canvas_navigation(bpy.types.Operator):
    """
    3D Coat-style canvas navigation.

    LMB on empty space = Orbit (calls Blender's native view3d.rotate)
    LMB on mesh = Pass through to normal tool behavior
    Shift+LMB = Pan (view3d.move)
    """

    bl_idname = "sculptnav.canvas_navigation"
    bl_label = "Canvas Navigation"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D'
        )

    def invoke(self, context, event):
        global _last_click_time, _last_click_pos

        # Check if SculptNavigation is enabled (session toggle)
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)

        # Check if clicking on undo scrubber - let it handle the click
        if getattr(prefs, 'undo_scrubber_enabled', False):
            from ..ui.undo_scrubber import is_over_scrubber_bar
            if is_over_scrubber_bar(context, event):
                return {'PASS_THROUGH'}

        # Check if canvas navigation is enabled globally
        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}

        # Check if navigation is enabled for current mode
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        # Border-zone navigation is decided from region coordinates only.
        # This avoids a scene ray-cast on the most latency-sensitive edge-drag
        # path while preserving the same visible behavior: border clicks navigate.
        if _is_in_border_zone_fast(context, event, prefs):
            if getattr(prefs, 'double_click_focus_enabled', True):
                allow_double_click = True
                if getattr(prefs, 'double_click_outside_border_only', False):
                    allow_double_click = True
                if allow_double_click and self._is_double_click(event, prefs):
                    return self._focus_selected(context, prefs)
            _last_click_time = time.time()
            _last_click_pos = (event.mouse_region_x, event.mouse_region_y)
            if event.shift:
                return self._invoke_pan(context, event) if getattr(prefs, 'lmb_pan_enabled', True) else {'PASS_THROUGH'}
            return self._invoke_orbit(context, event) if getattr(prefs, 'lmb_orbit_enabled', True) else {'PASS_THROUGH'}

        # Perform hit test (pass prefs for pass-through object filtering).
        hit_result = hit_test_context(
            context,
            event,
            border_width=prefs.border_width,
            border_height=prefs.border_height,
            prefs=prefs
        )

        should_navigate = (hit_result.in_border_zone or hit_result.hit_type == 'EMPTY')

        if not should_navigate:
            # Check for double-click on object to select and focus
            if getattr(prefs, 'double_click_focus_enabled', True):
                if getattr(prefs, 'double_click_select_and_focus', True):
                    if hit_result.hit_type == 'MESH' and hit_result.hit_object:
                        if self._is_double_click(event, prefs):
                            return self._select_and_focus(context, hit_result.hit_object, prefs)

            # Hit mesh, gizmo, or UI - let normal behavior happen
            return {'PASS_THROUGH'}

        # Check for double-click to focus (on empty space/border)
        if getattr(prefs, 'double_click_focus_enabled', True):
            # Check if double-click should only work inside border zone
            allow_double_click = True
            if getattr(prefs, 'double_click_outside_border_only', False):
                # Only allow if IN border zone
                allow_double_click = hit_result.in_border_zone

            if allow_double_click and self._is_double_click(event, prefs):
                return self._focus_selected(context, prefs)

        # Update click tracking for next potential double-click
        _last_click_time = time.time()
        _last_click_pos = (event.mouse_region_x, event.mouse_region_y)

        # Determine which navigation to invoke based on modifiers
        if event.shift:
            # Shift+LMB = Pan (like Shift+MMB)
            if getattr(prefs, 'lmb_pan_enabled', True):
                return self._invoke_pan(context, event)
            else:
                return {'PASS_THROUGH'}
        else:
            # LMB = Orbit (like MMB)
            if getattr(prefs, 'lmb_orbit_enabled', True):
                return self._invoke_orbit(context, event)
            else:
                return {'PASS_THROUGH'}

    def _is_double_click(self, event, prefs):
        """Check if the current click is a double-click."""
        global _last_click_time, _last_click_pos

        current_time = time.time()
        threshold_sec = getattr(prefs, 'double_click_threshold', 300) / 1000.0

        # Check time threshold
        if current_time - _last_click_time > threshold_sec:
            return False

        # Check position (clicks should be close together)
        dx = abs(event.mouse_region_x - _last_click_pos[0])
        dy = abs(event.mouse_region_y - _last_click_pos[1])
        if dx > 10 or dy > 10:
            return False

        # Reset tracking after detecting double-click
        _last_click_time = 0
        _last_click_pos = (0, 0)

        return True

    def _get_modifiers_to_ignore(self, obj, prefs):
        """Get list of modifiers to temporarily disable for focus."""
        ignore_mirror = getattr(prefs, 'focus_ignore_mirror', True)
        ignore_array = getattr(prefs, 'focus_ignore_array', True)
        ignore_solidify = getattr(prefs, 'focus_ignore_solidify', False)

        modifiers = []
        if obj and hasattr(obj, 'modifiers'):
            for mod in obj.modifiers:
                if not mod.show_viewport:
                    continue

                # Check standard modifier types
                if mod.type == 'MIRROR' and ignore_mirror:
                    modifiers.append(mod)
                elif mod.type == 'ARRAY' and ignore_array:
                    modifiers.append(mod)
                elif mod.type == 'SOLIDIFY' and ignore_solidify:
                    modifiers.append(mod)
                # Check for Geometry Nodes-based modifiers (Blender 5.0+)
                elif mod.type == 'NODES' and hasattr(mod, 'node_group') and mod.node_group:
                    node_group_name = mod.node_group.name.lower()
                    # New GN-based Array modifier
                    if ignore_array and 'array' in node_group_name:
                        modifiers.append(mod)
                    # New GN-based Mirror modifier (if exists)
                    elif ignore_mirror and 'mirror' in node_group_name:
                        modifiers.append(mod)

        return modifiers

    def _focus_selected(self, context, prefs):
        """Focus selected objects without changing Object/Edit/Sculpt mode."""
        disabled_modifiers = []
        obj = _safe_active_object(context)
        try:
            if obj is None:
                _safe_view_selected_or_all(use_all=True)
                return {'FINISHED'}
            # Modifier visibility changes are restricted to Object mode; changing
            # modifiers while Sculpt/Edit mode is redrawing can destabilize Blender
            # 5.1 native panel handlers.
            if _safe_context_mode(context) == 'OBJECT':
                disabled_modifiers = self._get_modifiers_to_ignore(obj, prefs)
                for mod in disabled_modifiers:
                    try:
                        mod.show_viewport = False
                    except Exception:
                        pass
                if disabled_modifiers:
                    try:
                        context.view_layer.update()
                    except Exception:
                        pass
            _safe_view_selected_or_all(use_all=False)
        finally:
            for mod in disabled_modifiers:
                try:
                    mod.show_viewport = True
                except Exception:
                    pass
        if getattr(prefs, 'focus_show_hud', True):
            try:
                bpy.ops.sculptnav.focus_hud('INVOKE_DEFAULT')
            except Exception:
                pass
        return {'FINISHED'}

    def _select_and_focus(self, context, obj, prefs):
        """Select and focus an object only in Object mode.

        Selecting another object during Sculpt/Edit mode was one of the unsafe
        event patterns that could feed invalid UI state to Blender 5.1, so this
        path now passes through unless Object mode is active.
        """
        if not _rna_pointer_is_valid(obj):
            return {'CANCELLED'}
        if _safe_context_mode(context) != 'OBJECT':
            return {'PASS_THROUGH'}
        disabled_modifiers = []
        try:
            try:
                _smart_utils.select_only(context, [obj], active=obj)
            except Exception:
                try:
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
                except Exception:
                    return {'CANCELLED'}
            disabled_modifiers = self._get_modifiers_to_ignore(obj, prefs)
            for mod in disabled_modifiers:
                try:
                    mod.show_viewport = False
                except Exception:
                    pass
            if disabled_modifiers:
                try:
                    context.view_layer.update()
                except Exception:
                    pass
            _safe_view_selected_or_all(use_all=False)
        finally:
            for mod in disabled_modifiers:
                try:
                    mod.show_viewport = True
                except Exception:
                    pass
        if getattr(prefs, 'focus_show_hud', True):
            try:
                bpy.ops.sculptnav.focus_hud('INVOKE_DEFAULT')
            except Exception:
                pass
        return {'FINISHED'}

    def _invoke_orbit(self, context, event):
        """Invoke Blender's native orbit operator."""
        try:
            prefs = get_addon_preferences(context)
            origin_mode = getattr(prefs, 'orbit_origin', 'BLENDER')

            # Set custom orbit origin if not using Blender default
            if origin_mode != 'BLENDER':
                origin = get_orbit_origin(context, event, origin_mode)
                set_view_pivot(context, origin)

            # Use Blender's native orbit operator
            result = bpy.ops.view3d.rotate('INVOKE_DEFAULT')
            if result == {'RUNNING_MODAL'}:
                return {'RUNNING_MODAL'}
            return {'FINISHED'}
        except Exception:
            return {'PASS_THROUGH'}

    def _invoke_pan(self, context, event):
        """Invoke Blender's native pan operator."""
        try:
            result = bpy.ops.view3d.move('INVOKE_DEFAULT')
            if result == {'RUNNING_MODAL'}:
                return {'RUNNING_MODAL'}
            return {'FINISHED'}
        except Exception:
            return {'PASS_THROUGH'}

class SCULPTNAV_OT_canvas_pan(bpy.types.Operator):
    """
    Canvas pan navigation (for explicit Shift+LMB binding).

    Shift+LMB on empty space = Pan (like Shift+MMB)
    Shift+LMB on mesh = Pass through
    """

    bl_idname = "sculptnav.canvas_pan"
    bl_label = "Canvas Pan"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D'
        )

    def invoke(self, context, event):
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)
        if getattr(prefs, 'undo_scrubber_enabled', False):
            from ..ui.undo_scrubber import is_over_scrubber_bar
            if is_over_scrubber_bar(context, event):
                return {'PASS_THROUGH'}
        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        if _is_in_border_zone_fast(context, event, prefs):
            try:
                result = bpy.ops.view3d.move('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}

        hit_result = hit_test_context(context, event, border_width=prefs.border_width, border_height=prefs.border_height, prefs=prefs)
        if hit_result.in_border_zone or hit_result.hit_type == 'EMPTY':
            try:
                result = bpy.ops.view3d.move('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}
        return {'PASS_THROUGH'}


class SCULPTNAV_OT_canvas_zoom(bpy.types.Operator):
    """
    Canvas zoom navigation (for explicit Ctrl+LMB binding).
    """

    bl_idname = "sculptnav.canvas_zoom"
    bl_label = "Canvas Zoom"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D'
        )

    def invoke(self, context, event):
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)
        if getattr(prefs, 'undo_scrubber_enabled', False):
            from ..ui.undo_scrubber import is_over_scrubber_bar
            if is_over_scrubber_bar(context, event):
                return {'PASS_THROUGH'}
        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        if _is_in_border_zone_fast(context, event, prefs):
            try:
                result = bpy.ops.view3d.zoom('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}

        hit_result = hit_test_context(context, event, border_width=prefs.border_width, border_height=prefs.border_height, prefs=prefs)
        if hit_result.in_border_zone or hit_result.hit_type == 'EMPTY':
            try:
                result = bpy.ops.view3d.zoom('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}
        return {'PASS_THROUGH'}


class SCULPTNAV_OT_canvas_rmb_navigation(bpy.types.Operator):
    """
    3D Coat-style RMB canvas navigation with configurable gesture axes.

    Each axis (horizontal/vertical) can be independently configured for
    empty space and on-mesh contexts. Both axes apply simultaneously.
    RMB click = Context menu.

    Modifier keys:
    - Shift + RMB drag = Zoom (view3d.zoom)
    """

    bl_idname = "sculptnav.canvas_rmb_navigation"
    bl_label = "Canvas RMB Navigation"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    # State tracking
    _start_x: int = 0
    _start_y: int = 0
    _last_x: int = 0
    _last_y: int = 0
    _is_dragging: bool = False
    _drag_threshold: int = 4
    _use_shift: bool = False
    _hit_mesh: bool = False
    _is_tablet: bool = False
    _prefs = None

    # Per-axis action assignments (read from prefs on drag start)
    _h_action: str = 'NONE'
    _v_action: str = 'NONE'

    # Brush state (used when any axis is BRUSH_SIZE or BRUSH_STRENGTH)
    _brush = None
    _initial_size: int = 0
    _initial_strength: float = 0.0
    _initial_unprojected_radius: float = 0.0
    _ups = None
    _use_unified_size: bool = False
    _use_unified_strength: bool = False
    _accumulated_delta_x: float = 0.0
    _accumulated_delta_y: float = 0.0
    _draw_handler = None
    _start_region_x: int = 0
    _start_region_y: int = 0

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D'
        )

    def invoke(self, context, event):
        # Check if SculptNavigation is enabled (session toggle)
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)
        self._prefs = prefs

        # Check if clicking on undo scrubber
        if getattr(prefs, 'undo_scrubber_enabled', False):
            from ..ui.undo_scrubber import is_over_scrubber_bar
            if is_over_scrubber_bar(context, event):
                return {'PASS_THROUGH'}

        # Check if canvas navigation is enabled globally
        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}

        # Check if RMB navigation is enabled
        if not getattr(prefs, 'canvas_rmb_enabled', True):
            return {'PASS_THROUGH'}

        # Check if navigation is enabled for current mode
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        # Border-zone RMB navigation does not need a ray-cast.
        in_border = _is_in_border_zone_fast(context, event, prefs)
        if in_border:
            self._hit_mesh = False
        else:
            hit_result = hit_test_context(
                context,
                event,
                border_width=prefs.border_width,
                border_height=prefs.border_height,
                prefs=prefs
            )
            self._hit_mesh = (hit_result.hit_type == 'MESH')
            if hit_result.hit_type in ('GIZMO', 'UI'):
                return {'PASS_THROUGH'}

        # Detect tablet input
        self._is_tablet = getattr(event, 'is_tablet', False)

        # Store initial state
        self._start_x = event.mouse_x
        self._start_y = event.mouse_y
        self._last_x = event.mouse_x
        self._last_y = event.mouse_y
        self._start_region_x = event.mouse_region_x
        self._start_region_y = event.mouse_region_y
        self._is_dragging = False
        self._h_action = 'NONE'
        self._v_action = 'NONE'
        self._use_shift = event.shift
        self._accumulated_delta_x = 0.0
        self._accumulated_delta_y = 0.0
        self._brush = None
        self._draw_handler = None
        self._draw_state = {'alive': False, 'packet': _gpu_state.EMPTY_PACKET}

        # Use tablet-specific drag threshold if tablet detected
        if self._is_tablet:
            self._drag_threshold = getattr(prefs, 'tablet_drag_threshold', 8)
        else:
            self._drag_threshold = prefs.drag_threshold

        # Border zone always navigates (override mesh hit)
        if in_border:
            self._hit_mesh = False

        # Enter modal to detect drag vs click
        _safe_modal_handler_add(context, self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # Update tablet detection
        if getattr(event, 'is_tablet', False):
            self._is_tablet = True

        if event.type == 'MOUSEMOVE':
            dx = event.mouse_x - self._start_x
            dy = event.mouse_y - self._start_y

            if not self._is_dragging:
                # Check if we've exceeded drag threshold
                if abs(dx) > self._drag_threshold or abs(dy) > self._drag_threshold:
                    self._is_dragging = True

                    # Handle Shift modifier override (zoom)
                    if self._use_shift:
                        if getattr(self._prefs, 'rmb_zoom_enabled', True):
                            try:
                                bpy.ops.view3d.zoom('INVOKE_DEFAULT')
                            except:
                                pass
                            self._cleanup(context)
                            return {'FINISHED'}
                        else:
                            self._cleanup(context)
                            return {'PASS_THROUGH'}

                    # Read axis assignments and direction lock from prefs
                    if self._hit_mesh:
                        self._h_action = self._prefs.rmb_mesh_horizontal
                        self._v_action = self._prefs.rmb_mesh_vertical
                        direction_lock = getattr(self._prefs, 'rmb_mesh_direction_lock', False)
                    else:
                        self._h_action = self._prefs.rmb_empty_horizontal
                        self._v_action = self._prefs.rmb_empty_vertical
                        direction_lock = getattr(self._prefs, 'rmb_empty_direction_lock', True)

                    # Direction lock: keep only the dominant axis
                    if direction_lock:
                        if abs(dx) > abs(dy):
                            self._v_action = 'NONE'
                        else:
                            self._h_action = 'NONE'

                    # If both NONE, nothing to do
                    if self._h_action == 'NONE' and self._v_action == 'NONE':
                        self._cleanup(context)
                        return {'PASS_THROUGH'}

                    # Init brush state if any axis is a brush action
                    has_brush_action = (
                        self._h_action in ('BRUSH_SIZE', 'BRUSH_STRENGTH') or
                        self._v_action in ('BRUSH_SIZE', 'BRUSH_STRENGTH')
                    )
                    if has_brush_action:
                        if not self._init_brush(context):
                            # Brush init failed — clear brush actions, keep nav actions
                            if self._h_action in ('BRUSH_SIZE', 'BRUSH_STRENGTH'):
                                self._h_action = 'NONE'
                            if self._v_action in ('BRUSH_SIZE', 'BRUSH_STRENGTH'):
                                self._v_action = 'NONE'

                    # The draw callback receives only an immutable packet state.
                    # All RNA reads and GPU batch construction happen here, outside draw.
                    if self._brush and self._prefs.brush_show_visual_ring:
                        self._draw_state = {'alive': True, 'packet': _gpu_state.EMPTY_PACKET}
                        self._rebuild_draw_packet(context)
                        try:
                            self._draw_handler, _wrapped = _lifecycle.add_draw_handler(
                                bpy.types.SpaceView3D, _draw_canvas_packet,
                                (self._draw_state,), 'WINDOW', 'POST_PIXEL'
                            )
                        except Exception as exc:
                            self._draw_state['alive'] = False
                            self._draw_handler = None
                            _runtime_errors.record('canvas_brush_draw_handler', exc)
                        _safe_cursor_set(context, 'SCROLL_XY')

                    # Reset tracking for delta computation
                    self._last_x = event.mouse_x
                    self._last_y = event.mouse_y

                return {'RUNNING_MODAL'}

            # Already dragging — compute per-frame deltas
            frame_dx = event.mouse_x - self._last_x
            frame_dy = event.mouse_y - self._last_y
            self._accumulated_delta_x += frame_dx
            self._accumulated_delta_y += frame_dy

            # Apply pan (both axes simultaneously, like default MMB pan)
            if self._h_action == 'PAN' or self._v_action == 'PAN':
                self._apply_pan_delta(context, frame_dx, frame_dy)

            # Apply other navigation actions (per-axis delta)
            if self._h_action != 'PAN':
                self._apply_action(context, self._h_action, frame_dx, 'HORIZONTAL')
            if self._v_action != 'PAN':
                self._apply_action(context, self._v_action, frame_dy, 'VERTICAL')

            # Update brush values (accumulated delta, once per frame)
            if self._brush and self._update_brush(context):
                self._rebuild_draw_packet(context)

            # Cursor warping for brush actions (keeps ring centered on cursor)
            if self._brush:
                if self._is_tablet:
                    self._last_x = event.mouse_x
                    self._last_y = event.mouse_y
                else:
                    region = getattr(context, 'region', None)
                    region_x = int(getattr(region, 'x', 0) or 0)
                    region_y = int(getattr(region, 'y', 0) or 0)
                    warp_x = self._start_region_x + region_x
                    warp_y = self._start_region_y + region_y
                    _safe_cursor_warp(context, warp_x, warp_y)
                    self._last_x = warp_x
                    self._last_y = warp_y
            else:
                self._last_x = event.mouse_x
                self._last_y = event.mouse_y

            _safe_tag_redraw(context)
            return {'RUNNING_MODAL'}

        elif event.type == 'RIGHTMOUSE' and event.value == 'RELEASE':
            if not self._is_dragging:
                # Was a click, not a drag — invoke context menu
                try:
                    bpy.ops.wm.call_menu(name="VIEW3D_MT_object_context_menu")
                except:
                    pass
            self._cleanup(context)
            return {'FINISHED'}

        elif event.type == 'ESC':
            # Restore brush values on cancel
            self._restore_brush()
            self._cleanup(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _apply_action(self, context, action, delta, axis):
        """Dispatch a navigation action for one axis."""
        if action == 'ROLL':
            self._apply_roll_delta(context, delta)
        elif action == 'DOLLY':
            self._apply_dolly_delta(context, delta)
        elif action == 'ZOOM':
            self._apply_zoom_delta(context, delta)
        # PAN handled separately (uses both axes)
        # BRUSH_SIZE and BRUSH_STRENGTH handled by _update_brush

    def _apply_roll_delta(self, context, delta):
        """Apply roll rotation from a mouse delta."""
        rv3d = context.region_data
        if not rv3d:
            return

        if getattr(self._prefs, 'roll_invert', False):
            delta = -delta

        sensitivity = getattr(self._prefs, 'roll_sensitivity', 0.3)
        roll_axis_mode = getattr(self._prefs, 'roll_axis', 'VIEW')

        if roll_axis_mode == 'VIEW':
            roll_axis = Vector((0, 0, 1))
        elif roll_axis_mode == 'WORLD_X':
            roll_axis = rv3d.view_rotation @ Vector((1, 0, 0))
        elif roll_axis_mode == 'WORLD_Y':
            roll_axis = rv3d.view_rotation @ Vector((0, 1, 0))
        elif roll_axis_mode == 'WORLD_Z':
            roll_axis = rv3d.view_rotation @ Vector((0, 0, 1))
        else:
            roll_axis = Vector((0, 0, 1))

        rv3d.view_rotation = Quaternion(roll_axis, radians(delta * sensitivity)) @ rv3d.view_rotation

    def _apply_dolly_delta(self, context, delta):
        """Apply dolly zoom from a mouse delta."""
        rv3d = context.region_data
        if not rv3d:
            return

        sensitivity = getattr(self._prefs, 'dolly_sensitivity', 1.0)
        if getattr(self._prefs, 'dolly_invert', False):
            delta = -delta

        factor = 1.0 - (delta * sensitivity * 0.01)
        factor = max(0.9, min(1.1, factor))
        rv3d.view_distance *= factor

    def _apply_pan_delta(self, context, dx, dy):
        """Apply viewport pan from mouse deltas (both axes, like default MMB pan)."""
        rv3d = context.region_data
        if not rv3d:
            return

        vm = rv3d.view_matrix
        right = Vector((vm[0][0], vm[0][1], vm[0][2]))
        up = Vector((vm[1][0], vm[1][1], vm[1][2]))

        if getattr(self._prefs, 'pan_invert_x', False):
            dx = -dx
        if getattr(self._prefs, 'pan_invert_y', False):
            dy = -dy

        sensitivity = getattr(self._prefs, 'pan_sensitivity', 1.0) * 0.002 * rv3d.view_distance
        rv3d.view_location -= (right * dx + up * dy) * sensitivity

    def _apply_zoom_delta(self, context, delta):
        """Apply zoom from a mouse delta (positive = zoom in)."""
        rv3d = context.region_data
        if not rv3d:
            return

        sensitivity = getattr(self._prefs, 'zoom_sensitivity', 1.0)
        if getattr(self._prefs, 'zoom_invert', False):
            delta = -delta

        factor = 1.0 - (delta * sensitivity * 0.01)
        factor = max(0.9, min(1.1, factor))
        rv3d.view_distance *= factor

    def _init_brush(self, context):
        """Initialize brush state for size/strength adjustment. Returns True on success."""
        brush = get_active_brush(context)
        if not brush:
            return False

        self._brush = brush

        # Get unified paint settings (Blender 5.0+: per-mode) with
        # Blender 5.1-safe context guards.
        try:
            ts = getattr(context, 'tool_settings', None)
            mode = str(getattr(context, 'mode', '') or '')
        except Exception:
            ts = None
            mode = ''
        ups = None
        try:
            if ts is not None and mode == 'SCULPT':
                sculpt = getattr(ts, 'sculpt', None)
                ups = getattr(sculpt, 'unified_paint_settings', None) if sculpt is not None else None
            elif ts is not None and mode == 'PAINT_VERTEX':
                vp = getattr(ts, 'vertex_paint', None)
                ups = getattr(vp, 'unified_paint_settings', None) if vp is not None else None
            elif ts is not None and mode == 'PAINT_WEIGHT':
                wp = getattr(ts, 'weight_paint', None)
                ups = getattr(wp, 'unified_paint_settings', None) if wp is not None else None
            elif ts is not None and mode == 'PAINT_TEXTURE':
                ip = getattr(ts, 'image_paint', None)
                ups = getattr(ip, 'unified_paint_settings', None) if ip is not None else None
        except Exception:
            ups = None

        self._ups = ups
        self._use_unified_size = ups.use_unified_size if ups else False
        self._use_unified_strength = ups.use_unified_strength if ups else False

        # Store initial values
        if self._use_unified_size and ups:
            self._initial_size = ups.size
        else:
            self._initial_size = brush.size

        if self._use_unified_strength and ups:
            self._initial_strength = ups.strength
        else:
            self._initial_strength = brush.strength

        if hasattr(brush, 'unprojected_radius'):
            self._initial_unprojected_radius = brush.unprojected_radius

        return True

    def _update_brush(self, context):
        """Update brush size/strength from accumulated deltas."""
        if not self._brush:
            return False

        changed = False
        has_size = self._h_action == 'BRUSH_SIZE' or self._v_action == 'BRUSH_SIZE'
        has_strength = self._h_action == 'BRUSH_STRENGTH' or self._v_action == 'BRUSH_STRENGTH'

        if has_size:
            # Use delta from whichever axis has BRUSH_SIZE
            if self._h_action == 'BRUSH_SIZE':
                size_delta = self._accumulated_delta_x
            else:
                size_delta = self._accumulated_delta_y

            if self._prefs.brush_invert_size:
                size_delta = -size_delta

            new_size = max(1, min(1000, int(
                self._initial_size + size_delta / self._prefs.brush_size_sensitivity
            )))

            if self._use_unified_size and self._ups:
                if int(getattr(self._ups, 'size', new_size)) != int(new_size):
                    self._ups.size = new_size
                    changed = True
            else:
                if int(getattr(self._brush, 'size', new_size)) != int(new_size):
                    self._brush.size = new_size
                    changed = True

            # Update unprojected_radius for sculpt brushes
            if hasattr(self._brush, 'unprojected_radius') and self._initial_size > 0:
                target_radius = self._initial_unprojected_radius * (new_size / self._initial_size)
                current_radius = float(getattr(self._brush, 'unprojected_radius', target_radius))
                if abs(current_radius - float(target_radius)) > 1e-6:
                    self._brush.unprojected_radius = target_radius
                    changed = True

        if has_strength:
            # Use delta from whichever axis has BRUSH_STRENGTH
            if self._h_action == 'BRUSH_STRENGTH':
                strength_delta = self._accumulated_delta_x
            else:
                strength_delta = self._accumulated_delta_y

            if self._prefs.brush_invert_strength:
                strength_delta = -strength_delta

            new_strength = max(0.0, min(1.0,
                self._initial_strength + strength_delta / self._prefs.brush_strength_sensitivity
            ))

            if self._use_unified_strength and self._ups:
                current_strength = float(getattr(self._ups, 'strength', new_strength))
                if abs(current_strength - float(new_strength)) > 1e-6:
                    self._ups.strength = new_strength
                    changed = True
            else:
                current_strength = float(getattr(self._brush, 'strength', new_strength))
                if abs(current_strength - float(new_strength)) > 1e-6:
                    self._brush.strength = new_strength
                    changed = True
        return changed

    def _restore_brush(self):
        """Restore brush to initial values (for ESC cancel)."""
        if not self._brush:
            return

        if self._use_unified_size and self._ups:
            self._ups.size = self._initial_size
        else:
            self._brush.size = self._initial_size

        if self._use_unified_strength and self._ups:
            self._ups.strength = self._initial_strength
        else:
            self._brush.strength = self._initial_strength

    def _rebuild_draw_packet(self, context):
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict) or not state.get('alive') or not self._brush:
            return
        try:
            current_size = (self._ups.size if self._use_unified_size and self._ups else self._brush.size)
            current_strength = (self._ups.strength if self._use_unified_strength and self._ups else self._brush.strength)
            h_names = {'BRUSH_SIZE': _smart_utils.translate_registered_text('Size'),
                       'BRUSH_STRENGTH': _smart_utils.translate_registered_text('Strength')}
            v_names = h_names
            parts = []
            h_label = h_names.get(self._h_action, '')
            v_label = v_names.get(self._v_action, '')
            if h_label:
                parts.append(f"\u2190 {h_label} \u2192")
            if v_label:
                parts.append(f"\u2193 {v_label} \u2191")
            hint = "     ".join(parts) if parts else None
            state['packet'] = _make_brush_adjust_packet(
                self._start_region_x, self._start_region_y, current_size,
                self._initial_size, current_strength, self._prefs, self._brush,
                _safe_getattr(context, 'region', None), hint_text=hint,
            )
        except Exception as exc:
            state['packet'] = _gpu_state.EMPTY_PACKET
            _runtime_errors.record('canvas_brush_packet', exc)

    def _draw_callback(self, _context=None):
        """Compatibility callback; immutable packet replay only."""
        _gpu_state.replay_state_packet(getattr(self, '_draw_state', None))

    def _cleanup(self, context):
        """Idempotently release only this generation's exact resources."""
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
            state['packet'] = _gpu_state.EMPTY_PACKET
        if self._draw_handler is not None:
            try:
                _lifecycle.remove_draw_handler(bpy.types.SpaceView3D, self._draw_handler, 'WINDOW')
            except Exception as exc:
                _runtime_errors.record('canvas_brush_draw_remove', exc)
            self._draw_handler = None
        if self._brush:
            _safe_cursor_set(context, 'DEFAULT')
        self._brush = None
        self._ups = None
        self._prefs = None
        self._h_action = 'NONE'
        self._v_action = 'NONE'
        self._draw_state = {'alive': False, 'packet': _gpu_state.EMPTY_PACKET}
        if _safe_getattr(context, 'area', None):
            _safe_tag_redraw(context)


class SCULPTNAV_OT_canvas_rmb_zoom(bpy.types.Operator):
    """Canvas RMB zoom (for explicit Shift+RMB binding)."""

    bl_idname = "sculptnav.canvas_rmb_zoom"
    bl_label = "Canvas RMB Zoom"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        return (
            context.area and
            context.area.type == 'VIEW_3D'
        )

    def invoke(self, context, event):
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)
        if getattr(prefs, 'undo_scrubber_enabled', False):
            from ..ui.undo_scrubber import is_over_scrubber_bar
            if is_over_scrubber_bar(context, event):
                return {'PASS_THROUGH'}
        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}
        if not getattr(prefs, 'canvas_rmb_enabled', True):
            return {'PASS_THROUGH'}
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        if _is_in_border_zone_fast(context, event, prefs):
            try:
                result = bpy.ops.view3d.zoom('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}

        hit_result = hit_test_context(context, event, border_width=prefs.border_width, border_height=prefs.border_height, prefs=prefs)
        if hit_result.in_border_zone or hit_result.hit_type == 'EMPTY':
            try:
                result = bpy.ops.view3d.zoom('INVOKE_DEFAULT')
                if result == {'RUNNING_MODAL'}:
                    return {'RUNNING_MODAL'}
                return {'FINISHED'}
            except Exception:
                return {'PASS_THROUGH'}
        return {'PASS_THROUGH'}


class SCULPTNAV_OT_roll(bpy.types.Operator):
    """Dedicated roll operator for view rotation."""

    bl_idname = "sculptnav.roll"
    bl_label = "Canvas Roll"
    bl_options = {'BLOCKING'}
    _sms_no_undo = True

    # Modal state
    _last_x: int = 0
    _invoke_key: str = ""

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'VIEW_3D'

    def invoke(self, context, event):
        # Check if SculptNavigation is enabled
        wm_props = get_wm_props(context)
        if not wm_props.enabled:
            return {'PASS_THROUGH'}

        prefs = get_addon_preferences(context)

        if not getattr(prefs, 'canvas_navigation_enabled', True):
            return {'PASS_THROUGH'}
        if not is_navigation_enabled(context, prefs):
            return {'PASS_THROUGH'}

        # Store initial state
        self._last_x = event.mouse_x
        self._invoke_key = event.type
        self._prefs = prefs

        _safe_modal_handler_add(context, self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            rv3d = context.region_data
            if rv3d:
                # Calculate delta
                delta_x = event.mouse_x - self._last_x
                self._last_x = event.mouse_x

                # Apply invert setting
                if getattr(self._prefs, 'roll_invert', False):
                    delta_x = -delta_x

                # Get sensitivity
                sensitivity = getattr(self._prefs, 'roll_sensitivity', 0.3)

                # Determine roll axis based on preference
                roll_axis_mode = getattr(self._prefs, 'roll_axis', 'WORLD_Z')

                if roll_axis_mode == 'VIEW':
                    roll_axis = Vector((0, 0, 1))
                elif roll_axis_mode == 'WORLD_X':
                    roll_axis = rv3d.view_rotation @ Vector((1, 0, 0))
                elif roll_axis_mode == 'WORLD_Y':
                    roll_axis = rv3d.view_rotation @ Vector((0, 1, 0))
                elif roll_axis_mode == 'WORLD_Z':
                    roll_axis = rv3d.view_rotation @ Vector((0, 0, 1))
                else:
                    roll_axis = Vector((0, 0, 1))

                # Apply rotation
                rv3d.view_rotation = Quaternion(roll_axis, radians(delta_x * sensitivity)) @ rv3d.view_rotation

            _safe_tag_redraw(context)
            return {'RUNNING_MODAL'}

        # Exit on key release
        if event.type == self._invoke_key and event.value == 'RELEASE':
            return {'FINISHED'}

        if event.type == 'ESC':
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}


class SCULPTNAV_OT_focus_hud(bpy.types.Operator):
    """Focus HUD - Quick access to focus modifier settings"""

    _sms_no_undo = True
    bl_idname = "sculptnav.focus_hud"
    bl_label = "Focus - Ignore Modifiers"
    # The HUD only exposes preference controls. It does not own a sculpt data
    # change and must not insert an empty global undo step when opened/closed.
    bl_options = {'INTERNAL'}

    # For fixed position HUD
    _draw_handler = None
    _timer = None
    _buttons = ()  # Immutable hit rectangles built outside draw.
    _draw_state = None

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        prefs = get_addon_preferences(context)
        position = getattr(prefs, 'focus_hud_position', 'CURSOR')

        if position != 'CURSOR':
            # Use custom GPU drawing at selected corner
            return self._invoke_fixed_hud(context, event)
        else:
            # Use Blender's native popup for cursor position when available.
            try:
                wm = _safe_getattr(context, 'window_manager', None)
                if wm is not None:
                    return wm.invoke_popup(self, width=220)
            except Exception:
                pass
            return {'FINISHED'}

    def _invoke_fixed_hud(self, context, event):
        """Show a fixed HUD backed by a completed immutable draw packet."""
        del event
        self._draw_state = {'alive': True, 'packet': _gpu_state.EMPTY_PACKET}
        self._rebuild_hud_packet(context)
        try:
            self._draw_handler, _wrapped = _lifecycle.add_draw_handler(
                bpy.types.SpaceView3D, _draw_focus_hud_packet,
                (self._draw_state,), 'WINDOW', 'POST_PIXEL'
            )
        except Exception as exc:
            self._draw_state['alive'] = False
            self._draw_handler = None
            _runtime_errors.record('focus_hud_draw_handler', exc)
            return {'CANCELLED'}
        self._timer = _safe_event_timer_add(context, 3.0)
        if not _safe_modal_handler_add(context, self):
            self._cleanup(context)
            return {'CANCELLED'}
        _safe_tag_redraw(context)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):

        # Auto-dismiss on timer
        if event.type == 'TIMER':
            self._cleanup(context)
            return {'FINISHED'}

        # Dismiss on click outside or escape
        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'PRESS':
            # Check if click is on a button
            region = context.region
            mx, my = event.mouse_region_x, event.mouse_region_y
            prefs = get_addon_preferences(context)

            for btn in self._buttons:
                if btn['x'] <= mx <= btn['x'] + btn['w'] and btn['y'] <= my <= btn['y'] + btn['h']:
                    # Toggle the property
                    prop_name = btn['prop']
                    setattr(prefs, prop_name, not getattr(prefs, prop_name))
                    self._rebuild_hud_packet(context)
                    _safe_tag_redraw(context)
                    return {'RUNNING_MODAL'}

            # Click outside - dismiss
            self._cleanup(context)
            return {'FINISHED'}

        if event.type == 'ESC':
            self._cleanup(context)
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def _cleanup(self, context):
        """Idempotently remove this HUD's exact draw and event-timer leases."""
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
            state['packet'] = _gpu_state.EMPTY_PACKET
        if self._draw_handler is not None:
            try:
                _lifecycle.remove_draw_handler(bpy.types.SpaceView3D, self._draw_handler, 'WINDOW')
            except Exception as exc:
                _runtime_errors.record('focus_hud_draw_remove', exc)
            self._draw_handler = None
        if self._timer is not None:
            _safe_event_timer_remove(context, self._timer)
            self._timer = None
        self._buttons = ()
        self._draw_state = {'alive': False, 'packet': _gpu_state.EMPTY_PACKET}
        _safe_tag_redraw(context)

    def _rebuild_hud_packet(self, context):
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict) or not state.get('alive'):
            return
        try:
            prefs = get_addon_preferences(context)
            packet, buttons = _build_focus_hud_packet(context, prefs)
            state['packet'] = packet
            self._buttons = buttons
        except Exception as exc:
            state['packet'] = _gpu_state.EMPTY_PACKET
            self._buttons = ()
            _runtime_errors.record('focus_hud_packet', exc)

    def _draw_hud(self, _context=None):
        """Compatibility callback; immutable packet replay only."""
        _gpu_state.replay_state_packet(getattr(self, '_draw_state', None))

    def draw(self, context):
        """Draw using Blender's native UI elements (for cursor position popup)."""
        layout = _smart_utils.localized_layout(self.layout)
        prefs = get_addon_preferences(context)

        # Title
        layout.label(text="Ignore Modifiers")
        layout.separator()

        # Horizontal toggles
        row = layout.row(align=True)
        row.prop(prefs, "focus_ignore_mirror", text="Mirror", toggle=True)
        row.prop(prefs, "focus_ignore_array", text="Array", toggle=True)
        row.prop(prefs, "focus_ignore_solidify", text="Solidify", toggle=True)


classes = (
    SCULPTNAV_OT_canvas_navigation,
    SCULPTNAV_OT_canvas_pan,
    SCULPTNAV_OT_canvas_zoom,
    SCULPTNAV_OT_canvas_rmb_navigation,
    SCULPTNAV_OT_canvas_rmb_zoom,
    SCULPTNAV_OT_roll,
    SCULPTNAV_OT_focus_hud,
)



def _safe_register_class(cls):
    return _rna_safety.register_class(cls)


def _safe_unregister_class(cls):
    try:
        return _rna_safety.unregister_class(cls)
    except Exception:
        return False

def register():
    try:
        _smart_utils.normalize_class_texts(classes)
        _smart_utils.register_runtime_translations()
    except Exception:
        pass
    for cls in classes:
        _safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
