# SPDX-License-Identifier: GPL-3.0-or-later
"""Switch off-mesh navigation on or off for the current window manager."""

from contextlib import suppress

import bpy

from ... import rna_safety
from ...core import utils
from ..properties import get_wm_props


class SCULPTNAV_OT_toggle(bpy.types.Operator):
    """Toggle SculptNavigation on/off"""

    bl_idname = "sculptnav.toggle"
    bl_label = "Toggle SculptNavigation"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    def execute(self, context):
        settings = get_wm_props(context)
        enabled = not settings.enabled
        settings.enabled = enabled
        message = "SculptNavigation enabled" if enabled else "SculptNavigation disabled"
        with suppress(Exception):
            message = bpy.app.translations.pgettext_iface(message) or message
        self.report({"INFO"}, message)
        return {"FINISHED"}


classes = (SCULPTNAV_OT_toggle,)


def register():
    with suppress(Exception):
        utils.normalize_class_texts(classes)
        utils.register_runtime_translations()
    rna_safety.register_class(SCULPTNAV_OT_toggle)


def unregister():
    with suppress(Exception):
        rna_safety.unregister_class(SCULPTNAV_OT_toggle)
