# SPDX-License-Identifier: GPL-3.0-or-later
"""Viewport and sculpt brush logic used by the navigation operators."""
