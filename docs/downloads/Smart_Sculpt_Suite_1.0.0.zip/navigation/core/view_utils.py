# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""
View manipulation utilities for SculptNav.
Handles orbit and dolly operations with proper matrix math.
"""

import bpy
from mathutils import Vector, Quaternion


def _rna_pointer_is_valid(value):
    if value is None:
        return False
    try:
        _ = value.name
    except ReferenceError:
        return False
    except Exception:
        pass
    try:
        _ = value.as_pointer()
    except ReferenceError:
        return False
    except Exception:
        return False
    return True


def _safe_active_object(context):
    try:
        obj = context.active_object
    except Exception:
        obj = None
    return obj if _rna_pointer_is_valid(obj) else None


def get_orbit_pivot(context, mode='ACTIVE'):
    """Return a crash-safe world-space orbit pivot, or None for Blender default."""
    mode = str(mode or 'ACTIVE')
    if mode == 'BLENDER':
        return None
    if mode in {'SURFACE', 'ACTIVE'}:
        obj = _safe_active_object(context)
        try:
            return obj.matrix_world.translation.copy() if obj is not None else None
        except Exception:
            return None
    if mode == 'CURSOR':
        try:
            return context.scene.cursor.location.copy()
        except Exception:
            return None
    if mode == 'SELECTION':
        try:
            selected = [obj for obj in context.selected_objects if _rna_pointer_is_valid(obj)]
        except Exception:
            selected = []
        if selected:
            center = Vector((0, 0, 0))
            count = 0
            for obj in selected:
                try:
                    center += obj.matrix_world.translation
                    count += 1
                except Exception:
                    continue
            if count:
                return center / count
        obj = _safe_active_object(context)
        try:
            return obj.matrix_world.translation.copy() if obj is not None else None
        except Exception:
            return None
    return None


def orbit_view(context, delta_x, delta_y, sensitivity=1.0, invert_x=False, invert_y=False, pivot=None):
    """
    Orbit the view around a pivot point.

    Args:
        context: Blender context
        delta_x: Horizontal mouse movement in pixels
        delta_y: Vertical mouse movement in pixels
        sensitivity: Multiplier for rotation speed
        invert_x: Invert horizontal direction
        invert_y: Invert vertical direction
        pivot: Optional pivot point (Vector). If None, orbits around view_location.
    """
    rv3d = context.region_data
    if not rv3d:
        return

    # Base orbit speed (radians per pixel)
    orbit_speed = 0.005 * sensitivity

    # Apply inversion
    if invert_x:
        delta_x = -delta_x
    if invert_y:
        delta_y = -delta_y

    # Calculate rotation angles
    angle_x = delta_x * orbit_speed
    angle_y = delta_y * orbit_speed

    # Get current view state
    current_rot = rv3d.view_rotation.copy()
    current_loc = rv3d.view_location.copy()

    # Create rotation quaternions
    # Horizontal rotation around global Z axis
    rot_z = Quaternion((0, 0, 1), -angle_x)

    # Vertical rotation around view's local X axis
    view_x = current_rot @ Vector((1, 0, 0))
    rot_x = Quaternion(view_x, angle_y)

    # Combine rotations
    combined_rot = rot_z @ rot_x

    if pivot is not None:
        # Orbit around specific pivot point
        # Calculate offset from pivot to current view location
        offset = current_loc - pivot

        # Rotate the offset vector
        new_offset = combined_rot @ offset

        # Apply new view state
        rv3d.view_rotation = combined_rot @ current_rot
        rv3d.view_location = pivot + new_offset
    else:
        # Simple rotation around current view location
        rv3d.view_rotation = combined_rot @ current_rot


def dolly_view(context, delta, sensitivity=1.0, invert=False):
    """
    Dolly the view (move forward/backward).

    Args:
        context: Blender context
        delta: Mouse movement in pixels (positive = zoom in)
        sensitivity: Multiplier for zoom speed
        invert: Invert zoom direction
    """
    rv3d = context.region_data
    if not rv3d:
        return

    # Apply inversion
    if invert:
        delta = -delta

    # Dolly speed factor (proportional to current distance)
    dolly_speed = 0.01 * sensitivity

    # Calculate new distance
    distance_delta = delta * dolly_speed * rv3d.view_distance
    new_distance = rv3d.view_distance - distance_delta

    # Clamp to reasonable range
    new_distance = max(0.001, min(10000.0, new_distance))

    rv3d.view_distance = new_distance


def smooth_orbit_view(context, delta_x, delta_y, sensitivity=1.0, invert_x=False, invert_y=False,
                      pivot=None, smoothing=0.5):
    """
    Orbit view with smoothing for more fluid motion.

    Args:
        context: Blender context
        delta_x: Target horizontal delta
        delta_y: Target vertical delta
        sensitivity: Movement sensitivity
        invert_x: Invert horizontal
        invert_y: Invert vertical
        pivot: Orbit pivot point
        smoothing: Smoothing factor (0=no smoothing, 1=max smoothing)
    """
    # For now, just use regular orbit
    # Smoothing would require persistent state between calls
    orbit_view(context, delta_x, delta_y, sensitivity, invert_x, invert_y, pivot)


def get_view_direction(context):
    """
    Get the current view direction vector.

    Args:
        context: Blender context

    Returns:
        Vector: Normalized view direction (what the camera is looking at)
    """
    rv3d = context.region_data
    if not rv3d:
        return Vector((0, 0, -1))

    # View direction is -Z in view space
    view_rotation = rv3d.view_rotation
    return view_rotation @ Vector((0, 0, -1))


def get_view_up(context):
    """
    Get the current view up vector.

    Args:
        context: Blender context

    Returns:
        Vector: Normalized up direction in view
    """
    rv3d = context.region_data
    if not rv3d:
        return Vector((0, 1, 0))

    view_rotation = rv3d.view_rotation
    return view_rotation @ Vector((0, 1, 0))


def get_view_right(context):
    """
    Get the current view right vector.

    Args:
        context: Blender context

    Returns:
        Vector: Normalized right direction in view
    """
    rv3d = context.region_data
    if not rv3d:
        return Vector((1, 0, 0))

    view_rotation = rv3d.view_rotation
    return view_rotation @ Vector((1, 0, 0))


class ViewState:
    """
    Stores view state for later restoration.
    Useful for canceling operations.
    """

    __slots__ = ('view_rotation', 'view_location', 'view_distance', 'view_perspective')

    def __init__(self, context):
        rv3d = context.region_data
        if rv3d:
            self.view_rotation = rv3d.view_rotation.copy()
            self.view_location = rv3d.view_location.copy()
            self.view_distance = rv3d.view_distance
            self.view_perspective = rv3d.view_perspective
        else:
            self.view_rotation = Quaternion()
            self.view_location = Vector()
            self.view_distance = 10.0
            self.view_perspective = 'PERSP'

    def restore(self, context):
        """Restore the saved view state."""
        rv3d = context.region_data
        if rv3d:
            rv3d.view_rotation = self.view_rotation
            rv3d.view_location = self.view_location
            rv3d.view_distance = self.view_distance
            # Note: view_perspective is read-only in some cases
