# SPDX-License-Identifier: GPL-3.0-or-later
"""Register the sculpt navigation interfaces in dependency order."""

from contextlib import suppress

from . import keymaps, properties, translation
from .operators import brush_adjust, canvas_navigation, navigation
from .ui import overlays, panels


_REGISTERED = False
_COMPLETED_MODULES = []


def _registration_modules():
    return translation, properties, panels, navigation, brush_adjust, canvas_navigation, keymaps


def _release(installed):
    for component in reversed(installed):
        with suppress(Exception):
            component.unregister()


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    try:
        for component in _registration_modules():
            component.register()
            _COMPLETED_MODULES.append(component)
    except Exception:
        _release(_COMPLETED_MODULES)
        _COMPLETED_MODULES.clear()
        raise
    _REGISTERED = True


def rollback_registration():
    global _REGISTERED
    # A contained startup failure may leave a partially initialized component.
    _release(tuple(_COMPLETED_MODULES) or _registration_modules())
    with suppress(Exception):
        overlays.unregister()
    _COMPLETED_MODULES.clear()
    _REGISTERED = False


unregister = rollback_registration


if __name__ == "__main__":
    register()
