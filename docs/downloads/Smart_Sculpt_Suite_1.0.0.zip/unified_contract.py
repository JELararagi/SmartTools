# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Settings and file ownership boundaries for Smart Sculpt."""

CONTRACT_VERSION = 1
EXTENSION_ID = "smart_sculpt_suite"
CONFIG_FOLDER = "Smart_Sculpt_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"

_CORE = "scene.core"
_MASK_SETTINGS = "scene.strict_edit_mode_sculpt_settings"
_NAVIGATION = "window_manager.sculptnav"
_IGNORED_COLLECTIONS = "scene.sculptnav_ignored_collections"

STATE_SAVE_PATH = f"{_CORE}.always_on_npanel_autosave_restore"
SECTION_OPEN_PATH = f"{_CORE}.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    f"{_CORE}.always_on_navigation_border_overlay",
    f"{_MASK_SETTINGS}.use_mask_for_mesh_editing",
    f"{_MASK_SETTINGS}.mask_overlay_enabled",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (_CORE, _MASK_SETTINGS)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    _NAVIGATION, _IGNORED_COLLECTIONS, f"{_IGNORED_COLLECTIONS}_index",
)
EXCLUDED_TRANSIENT_PATHS = (
    f"{_CORE}.name",
    *(f"{_CORE}.tool_pipe_slot_{number}_tool" for number in range(1, 4)),
    f"{_MASK_SETTINGS}.name",
    f"{_MASK_SETTINGS}.brush_settings_json",
    f"{_MASK_SETTINGS}.brush_settings_active_key",
    f"{_NAVIGATION}.name",
    f"{_NAVIGATION}.enabled",
    *PERSISTED_DYNAMIC_RNA_PATTERNS[1:],
)
ROOT_PANEL_IDS = ("SSS_PT_main",)
