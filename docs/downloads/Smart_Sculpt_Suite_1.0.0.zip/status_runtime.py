# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Track a finite set of status messages without timers or global patches."""
from contextlib import contextmanager
import time
from uuid import uuid4

_MAX_ENTRIES = 32
_ENTRIES = {}


def _put(token, owner, text, kind, expires=None):
    _ENTRIES.pop(token, None)
    _ENTRIES[token] = dict(token=token, owner=str(owner), text=str(text), kind=kind, expires=expires)
    if len(_ENTRIES) > _MAX_ENTRIES:
        del _ENTRIES[next(iter(_ENTRIES))]
    return token


def _expires_after(duration):
    return time.monotonic() + max(0.0, float(duration))


def _prune():
    now = time.monotonic()
    for token, entry in list(_ENTRIES.items()):
        if entry["expires"] is not None and entry["expires"] <= now:
            del _ENTRIES[token]


def set_transient(owner, text, duration=2.5, *, context=None):
    return _put(f"transient:{uuid4()}", owner, text, "transient", _expires_after(duration))


def set_service(owner, text, *, context=None):
    return _put(f"service:{owner}", owner, text, "service")


def begin_task(owner, text, *, context=None):
    return _put(f"task:{uuid4()}", owner, text, "task")


def update_task(token, text, *, context=None):
    entry = _ENTRIES.get(token)
    if entry is None:
        return False
    entry["text"] = str(text)
    return True


def finish_task(token, final_text=None, duration=1.5, *, context=None):
    if token not in _ENTRIES:
        return False
    if final_text is None:
        del _ENTRIES[token]
    else:
        _ENTRIES[token].update(text=str(final_text), expires=_expires_after(duration))
    return True


def clear(owner_or_token, *, context=None):
    value = str(owner_or_token)
    for token, entry in list(_ENTRIES.items()):
        if value in (token, entry["owner"]):
            del _ENTRIES[token]


def clear_prefix(prefix, *, context=None):
    prefix = str(prefix)
    for token, entry in list(_ENTRIES.items()):
        if token.startswith(prefix) or entry["owner"].startswith(prefix):
            del _ENTRIES[token]


def clear_all(*, context=None):
    _ENTRIES.clear()


def snapshot():
    _prune()
    return tuple(entry.copy() for entry in _ENTRIES.values())


@contextmanager
def task_scope(owner, text, *, context=None, success_text=None, failure_text=None):
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception:
        finish_task(token, failure_text, context=context)
        raise
    else:
        finish_task(token, success_text, context=context)


def instrument_operator_class(cls, *args, **kwargs):
    return cls


def _no_handlers(*args, **kwargs):
    return 0


instrument_loaded_package_operators = _no_handlers
instrument_loaded_package_handlers = _no_handlers
restore_package_handlers = _no_handlers
prune_orphan_persistent_handler_markers = _no_handlers


@contextmanager
def capture_registration_callbacks(*args, **kwargs):
    yield


capture_runtime_resources = capture_registration_callbacks
