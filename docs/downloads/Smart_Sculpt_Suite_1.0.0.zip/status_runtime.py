# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bounded status service with no global API interception or background polling."""
from __future__ import annotations
from contextlib import contextmanager
from collections import OrderedDict
import time, uuid
from typing import Any
_MAX_ENTRIES=32
_ENTRIES: OrderedDict[str,dict[str,Any]]=OrderedDict()
def _put(token,owner,text,kind,expires=None):
    _ENTRIES[token]={"token":token,"owner":str(owner),"text":str(text),"kind":str(kind),"expires":expires}
    _ENTRIES.move_to_end(token)
    while len(_ENTRIES)>_MAX_ENTRIES: _ENTRIES.popitem(last=False)
    return token
def _prune():
    now=time.monotonic()
    for key,value in tuple(_ENTRIES.items()):
        exp=value.get("expires")
        if exp is not None and exp<=now: _ENTRIES.pop(key,None)
def set_transient(owner,text,duration=2.5,*,context=None):
    del context; token=f"transient:{uuid.uuid4()}"; return _put(token,owner,text,"transient",time.monotonic()+max(0.0,float(duration)))
def set_service(owner,text,*,context=None):
    del context; token=f"service:{owner}"; return _put(token,owner,text,"service")
def begin_task(owner,text,*,context=None):
    del context; token=f"task:{uuid.uuid4()}"; return _put(token,owner,text,"task")
def update_task(token,text,*,context=None):
    del context
    if token not in _ENTRIES: return False
    _ENTRIES[token]["text"]=str(text); return True
def finish_task(token,final_text=None,duration=1.5,*,context=None):
    del context
    if token not in _ENTRIES: return False
    if final_text is None: _ENTRIES.pop(token,None)
    else:
        _ENTRIES[token]["text"]=str(final_text); _ENTRIES[token]["expires"]=time.monotonic()+max(0.0,float(duration))
    return True
def clear(owner_or_token,*,context=None):
    del context
    key=str(owner_or_token)
    _ENTRIES.pop(key,None)
    for token,value in tuple(_ENTRIES.items()):
        if value.get("owner")==key: _ENTRIES.pop(token,None)
def clear_prefix(prefix,*,context=None):
    del context; prefix=str(prefix)
    for token,value in tuple(_ENTRIES.items()):
        if token.startswith(prefix) or str(value.get("owner","")).startswith(prefix): _ENTRIES.pop(token,None)
def clear_all(*,context=None): del context; _ENTRIES.clear()
def snapshot(): _prune(); return tuple(dict(value) for value in _ENTRIES.values())
@contextmanager
def task_scope(owner,text,*,context=None,success_text=None,failure_text=None):
    token=begin_task(owner,text,context=context)
    try:
        yield token
    except Exception:
        finish_task(token,failure_text,context=context); raise
    else: finish_task(token,success_text,context=context)
def instrument_operator_class(cls,*_args,**_kwargs): return cls
def instrument_loaded_package_operators(*_args,**_kwargs): return 0
def instrument_loaded_package_handlers(*_args,**_kwargs): return 0
def restore_package_handlers(*_args,**_kwargs): return 0
def prune_orphan_persistent_handler_markers(*_args,**_kwargs): return 0
@contextmanager
def capture_registration_callbacks(*_args,**_kwargs): yield
@contextmanager
def capture_runtime_resources(*_args,**_kwargs): yield
