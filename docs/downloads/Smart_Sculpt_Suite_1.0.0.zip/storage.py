# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable
import tempfile

from . import _sss_json_store as _json_store

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_sculpt_suite'
USER_DATA_DIRNAME = 'user_data'
WORKSPACE_SETTINGS_DIRNAME = 'Smart_Sculpt_Suite'
WORKSPACE_SETTINGS_FILENAME = 'Smart_Sculpt_Suite.json'
MUTABLE_SIDECAR_DIRNAME = 'sidecars'
LEGACY_WORKSPACE_SETTINGS_FILENAMES = (
    'Smart_' + 'workspace_Suite.json',
    WORKSPACE_SETTINGS_FILENAME,
)
_LAST_WORKSPACE_SETTINGS_TEXT: str | None = None


def config_dir(create: bool = True) -> Path:
    """Return Blender's versioned config directory.

    On Windows this resolves to:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/<version>/config
    """
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', create=create) or ''
            except TypeError:
                try:
                    value = user_resource('CONFIG', '', create=create) or ''
                except Exception:
                    value = ''
            except Exception:
                value = ''
            if value:
                path = Path(str(value)).expanduser()
                try:
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
                return path
    root = _user_version_root() or (Path.home() / '.config' / 'blender' / _blender_version())
    path = Path(root) / 'config'
    try:
        if create:
            path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def workspace_settings_dir(create: bool = True) -> Path:
    """Return the Smart Sculpt settings folder under Blender's config directory.

    On Windows this resolves to:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/<version>/config/Smart_Sculpt_Suite
    """
    path = config_dir(create=create) / WORKSPACE_SETTINGS_DIRNAME
    try:
        if create:
            path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def workspace_settings_path(create: bool = True) -> Path:
    """Return the external Smart Sculpt N-panel settings JSON path."""
    return workspace_settings_dir(create=create) / WORKSPACE_SETTINGS_FILENAME


def legacy_workspace_settings_paths(create: bool = False) -> tuple[Path, ...]:
    """Return legacy external settings paths used before the settings folder was introduced."""
    base = config_dir(create=create)
    paths: list[Path] = []
    for name in LEGACY_WORKSPACE_SETTINGS_FILENAMES:
        paths.append(base / name)
    paths.append(base / WORKSPACE_SETTINGS_DIRNAME / ('Smart_' + 'workspace_Suite.json'))
    seen: set[str] = set()
    unique: list[Path] = []
    for path in paths:
        key = str(path)
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return tuple(unique)


def _workspace_settings_validator(payload: dict[str, Any]) -> bool:
    return isinstance(payload, dict) and str(payload.get('addon_id', PACKAGE_ID) or PACKAGE_ID) == PACKAGE_ID


def read_workspace_settings() -> dict[str, Any]:
    path = workspace_settings_path(create=False)
    document = _json_store.read_with_backup(
        path, validator=_workspace_settings_validator, allow_legacy=True, repair=True
    )
    if isinstance(document, dict):
        return _json_store.payload_only(document)
    for legacy_path in legacy_workspace_settings_paths(create=False):
        if legacy_path == path or not legacy_path.exists():
            continue
        document = _json_store.read_with_backup(
            legacy_path, validator=_workspace_settings_validator, allow_legacy=True, repair=False
        )
        if not isinstance(document, dict):
            continue
        data = _json_store.payload_only(document)
        data.setdefault('version', 1)
        data.setdefault('addon_id', PACKAGE_ID)
        data['storage_folder'] = WORKSPACE_SETTINGS_DIRNAME
        data['storage_file'] = WORKSPACE_SETTINGS_FILENAME
        write_workspace_settings(data)
        # A legacy file is removed only after the new target passed readback.
        verified = _json_store.read_with_backup(
            path, validator=_workspace_settings_validator, allow_legacy=False, repair=False
        )
        if isinstance(verified, dict):
            try:
                legacy_path.unlink()
            except OSError:
                pass
        return data
    return {}


def write_workspace_settings(data: dict[str, Any]) -> None:
    global _LAST_WORKSPACE_SETTINGS_TEXT
    value = dict(data) if isinstance(data, dict) else {}
    value.setdefault('version', 1)
    value.setdefault('addon_id', PACKAGE_ID)
    value['storage_folder'] = WORKSPACE_SETTINGS_DIRNAME
    value['storage_file'] = WORKSPACE_SETTINGS_FILENAME
    payload_text = json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))
    if _LAST_WORKSPACE_SETTINGS_TEXT == payload_text:
        return
    path = workspace_settings_path(create=True)
    existing = _json_store.read_with_backup(
        path, validator=_workspace_settings_validator, allow_legacy=True, repair=True
    )
    if isinstance(existing, dict) and _json_store.payload_only(existing) == value:
        _LAST_WORKSPACE_SETTINGS_TEXT = payload_text
        return
    _json_store.atomic_write(path, value, validator=_workspace_settings_validator)
    verified = _json_store.read_with_backup(
        path, validator=_workspace_settings_validator, allow_legacy=False, repair=False
    )
    if not isinstance(verified, dict) or _json_store.payload_only(verified) != value:
        raise OSError('Smart Sculpt settings readback mismatch')
    _LAST_WORKSPACE_SETTINGS_TEXT = payload_text

def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _normalized_path_text(path: Path) -> str:
    try:
        resolved = Path(path).expanduser().resolve(strict=False)
    except Exception:
        resolved = Path(path).expanduser()
    return str(resolved).replace('\\', '/').rstrip('/').casefold()


def _is_same_or_child(path: Path, root: Path) -> bool:
    path_text = _normalized_path_text(path)
    root_text = _normalized_path_text(root)
    return path_text == root_text or path_text.startswith(root_text + '/')


def _versioned_user_default_repository() -> Path | None:
    user_root = _user_version_root()
    if user_root is None:
        return None
    return Path(user_root) / 'extensions' / 'user_default'


def _is_user_default_package_path(path: Path) -> bool:
    """Return True when *path* is a package directory below Blender's versioned user_default repository."""
    try:
        repo = _versioned_user_default_repository()
        return repo is not None and _is_same_or_child(Path(path).parent, repo) and Path(path).parent.name.casefold() == 'user_default'
    except Exception:
        return False


def _installed_extension_root(package_id: str = PACKAGE_ID) -> Path | None:
    current = _package_root()
    try:
        # Blender may preserve the ZIP folder name.  Accept Smart_Sculpt_Suite,
        # smart_sculpt_suite, or any case variant as long as the package itself
        # is already installed below extensions/user_default.
        if _is_user_default_package_path(current):
            return current
    except Exception:
        pass
    return None


def _is_inside_user_default(path: Path) -> bool:
    repo = _versioned_user_default_repository()
    if repo is None:
        return False
    return _is_same_or_child(Path(path), repo)


def _user_version_root() -> Path | None:
    """Return Blender's versioned user root, e.g. .../Blender/5.1."""
    if bpy is not None:
        resource_path = getattr(getattr(bpy, 'utils', None), 'resource_path', None)
        if callable(resource_path):
            try:
                value = resource_path('USER')
                if value:
                    return Path(str(value)).expanduser()
            except Exception:
                pass
    version = _blender_version()
    try:
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            return Path(roaming) / 'Blender Foundation' / 'Blender' / version
        if sys.platform == 'darwin':
            return Path.home() / 'Library' / 'Application Support' / 'Blender' / version
    except Exception:
        pass
    return Path.home() / '.config' / 'blender' / version


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            if not _is_inside_user_default(path):
                continue
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_sculpt_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            if not _is_inside_user_default(path):
                continue
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if _is_inside_user_default(path):
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    user_root = _user_version_root() or (Path.home() / '.config' / 'blender' / _blender_version())
    path = Path(user_root) / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Return the installed Extension root for read-only legacy discovery."""
    pkg = package_id(package)
    installed = _installed_extension_root(pkg) if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed

    # This resolver is intentionally read-only. Mutable data uses
    # ``mutable_settings_root`` below.
    return _platform_user_default_package_root(pkg, False)


def mutable_settings_root(package: object | None = None, *, create: bool = True) -> Path:
    """Return the CONFIG-owned root for every automatically written sidecar."""
    pkg = package_id(package)
    root = workspace_settings_dir(create=create) / MUTABLE_SIDECAR_DIRNAME
    if pkg != PACKAGE_ID:
        root = root / _clean_part(pkg)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = mutable_settings_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = mutable_settings_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=False)
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_bytes().decode('utf-8', 'strict'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = str(text).encode(encoding, 'strict')
    fd, temp_name = tempfile.mkstemp(prefix=f'.{target.name}.', suffix='.tmp', dir=str(target.parent))
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, 'wb', closefd=True) as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if temp.read_bytes() != raw:
            raise OSError('temporary text readback mismatch')
        os.replace(temp, target)
        try:
            directory_fd = os.open(str(target.parent), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except Exception:
            pass
        if target.read_bytes() != raw:
            raise OSError('atomic text readback mismatch')
    finally:
        try:
            temp.unlink()
        except OSError:
            pass


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    raw = json.dumps(
        data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys,
        allow_nan=False, default=str,
    ) + '\n'
    atomic_write_text(path, raw, encoding='utf-8')
    parsed = json.loads(Path(path).read_bytes().decode('utf-8', 'strict'))
    if parsed != json.loads(raw):
        raise OSError('atomic JSON readback mismatch')

def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy a legacy file while retaining package-local sources."""
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        package_local = False
        try:
            legacy.resolve(strict=False).relative_to(_package_root().resolve(strict=False))
            package_local = True
        except Exception:
            package_local = False
        if remove_legacy and not package_local:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
