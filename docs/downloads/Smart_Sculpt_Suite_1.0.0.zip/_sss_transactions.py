# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Transactional mesh and context isolation for Smart Sculpt operations.

Destructive operations run against a copied staging mesh.  The original mesh,
mode, active object, selection, edit selection/history, cursor, Sculpt settings,
Dyntopo state, and Suite-owned recovery references are captured before any
mutation.  Only a ``FINISHED`` result commits the staged mesh.  ``CANCELLED``,
exceptions, modal loss, and reload use the same idempotent rollback path.
"""
from __future__ import annotations

from contextlib import AbstractContextManager
import functools
import uuid
from typing import Any, Callable

from . import _sss_ownership as _ownership
from . import _sss_runtime_errors as _errors

# Pointers of staging meshes owned by a transaction that is still open.  A nested
# transaction on such a mesh must not stage again: committing would remove the
# mesh the enclosing transaction still has to commit.
_LIVE_STAGING_POINTERS: set[int] = set()


def _mesh_pointer(mesh: Any) -> int:
    try:
        return int(mesh.as_pointer())
    except Exception:
        return 0


def _mode_set(context: Any, mode: str | None) -> bool:
    if not mode:
        return True
    try:
        active = context.view_layer.objects.active
        if active is None or str(getattr(active, "mode", "")) == str(mode):
            return True
        import bpy
        result = bpy.ops.object.mode_set(mode=str(mode))
        return "FINISHED" in set(result or ())
    except Exception:
        return False


def _remove_mesh(mesh: Any) -> None:
    if mesh is None:
        return
    try:
        import bpy
        if int(getattr(mesh, "users", 0) or 0) == 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass


def _capture_scene_cursor(context: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    try:
        cursor = context.scene.cursor
        for name in ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "rotation_mode"):
            if hasattr(cursor, name):
                value = getattr(cursor, name)
                result[name] = value.copy() if hasattr(value, "copy") else value
    except Exception:
        pass
    return result


def _restore_scene_cursor(context: Any, snapshot: dict[str, Any]) -> None:
    try:
        cursor = context.scene.cursor
        for name, value in snapshot.items():
            try:
                setattr(cursor, name, value.copy() if hasattr(value, "copy") else value)
            except Exception:
                pass
    except Exception:
        pass


def _capture_edit_selection(obj: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"verts": (), "edges": (), "faces": (), "active_face": -1, "history": ()}
    if obj is None or str(getattr(obj, "mode", "")) != "EDIT":
        return result
    try:
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        result["verts"] = tuple(v.index for v in bm.verts if bool(v.select))
        result["edges"] = tuple(e.index for e in bm.edges if bool(e.select))
        result["faces"] = tuple(f.index for f in bm.faces if bool(f.select))
        result["active_face"] = int(getattr(getattr(bm.faces, "active", None), "index", -1))
        history = []
        for elem in tuple(getattr(bm, "select_history", ()) or ()):
            kind = "VERT" if elem in bm.verts else "EDGE" if elem in bm.edges else "FACE" if elem in bm.faces else ""
            if kind:
                history.append((kind, int(elem.index)))
        result["history"] = tuple(history)
    except Exception:
        pass
    return result


def _restore_edit_selection(obj: Any, snapshot: dict[str, Any]) -> None:
    if obj is None or str(getattr(obj, "mode", "")) != "EDIT":
        return
    try:
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        verts = set(snapshot.get("verts", ())); edges = set(snapshot.get("edges", ())); faces = set(snapshot.get("faces", ()))
        for vert in bm.verts:
            vert.select = vert.index in verts
        for edge in bm.edges:
            edge.select = edge.index in edges
        for face in bm.faces:
            face.select = face.index in faces
        active_face = int(snapshot.get("active_face", -1))
        bm.faces.active = bm.faces[active_face] if 0 <= active_face < len(bm.faces) else None
        try:
            bm.select_history.clear()
        except Exception:
            pass
        for kind, index in snapshot.get("history", ()):
            seq = bm.verts if kind == "VERT" else bm.edges if kind == "EDGE" else bm.faces
            if 0 <= int(index) < len(seq):
                try:
                    bm.select_history.add(seq[int(index)])
                except Exception:
                    pass
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass


def _capture_idprops(data: Any) -> dict[str, Any]:
    """Capture every ID property at an explicit operation boundary.

    Rollback never classifies ownership from a name or prefix.  The complete
    pre-operation map is restored, so user-authored ``SSS_``/``sss_`` keys are
    preserved exactly and additions made by a cancelled operation disappear.
    """
    result: dict[str, Any] = {}
    if data is None:
        return result
    try:
        for key in tuple(data.keys()):
            text = str(key or "")
            value = data.get(key)
            result[text] = value.copy() if hasattr(value, "copy") else value
    except Exception:
        pass
    return result


def _restore_idprops(data: Any, snapshot: dict[str, Any]) -> None:
    if data is None:
        return
    try:
        current = tuple(str(key or "") for key in tuple(data.keys()))
    except Exception:
        current = ()
    for key in current:
        if key not in snapshot:
            try:
                data.pop(key, None)
            except Exception:
                pass
    for key, value in snapshot.items():
        try:
            data[key] = value.copy() if hasattr(value, "copy") else value
        except Exception:
            pass


def _capture_sculpt_state(context: Any, active: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    try:
        result["dynamic_topology"] = bool(getattr(active, "use_dynamic_topology_sculpting", False))
    except Exception:
        pass
    try:
        sculpt = context.tool_settings.sculpt
    except Exception:
        sculpt = None
    if sculpt is not None:
        values: dict[str, Any] = {}
        for name in (
            "detail_type_method", "detail_refine_method", "constant_detail_resolution",
            "detail_size", "detail_percent", "symmetrize_direction", "use_symmetry_x",
            "use_symmetry_y", "use_symmetry_z", "lock_x", "lock_y", "lock_z",
        ):
            try:
                value = getattr(sculpt, name)
                values[name] = value.copy() if hasattr(value, "copy") else value
            except Exception:
                pass
        result["sculpt_values"] = values
    return result


def _restore_sculpt_state(context: Any, active: Any, snapshot: dict[str, Any]) -> None:
    desired_dyntopo = snapshot.get("dynamic_topology", None)
    if desired_dyntopo is not None and active is not None:
        try:
            current = bool(getattr(active, "use_dynamic_topology_sculpting", False))
        except Exception:
            current = bool(desired_dyntopo)
        if current != bool(desired_dyntopo):
            previous_mode = str(getattr(active, "mode", "") or "")
            try:
                import bpy
                if _mode_set(context, "SCULPT"):
                    result = bpy.ops.sculpt.dynamic_topology_toggle()
                    if "FINISHED" not in set(result or ()):
                        raise RuntimeError("Dyntopo rollback toggle was cancelled")
            except Exception:
                try:
                    setattr(active, "use_dynamic_topology_sculpting", bool(desired_dyntopo))
                except Exception:
                    pass
            finally:
                _mode_set(context, previous_mode)
    try:
        sculpt = context.tool_settings.sculpt
    except Exception:
        sculpt = None
    if sculpt is not None:
        for name, value in dict(snapshot.get("sculpt_values", {}) or {}).items():
            try:
                setattr(sculpt, name, value.copy() if hasattr(value, "copy") else value)
            except Exception:
                pass


def _capture_brush_state(context: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    try:
        sculpt = context.tool_settings.sculpt
    except Exception:
        sculpt = None
    brush = getattr(sculpt, "brush", None) if sculpt is not None else None
    result["sculpt"] = sculpt
    result["brush"] = brush
    brush_values: dict[str, Any] = {}
    if brush is not None:
        for name in (
            "size", "strength", "weight", "direction", "curve_preset", "use_pressure_size",
            "use_pressure_strength", "use_locked_size", "spacing", "hardness", "auto_smooth_factor",
            "normal_radius_factor", "plane_offset", "color", "secondary_color",
            "cursor_color_add", "cursor_color_subtract", "texture", "mask_texture",
        ):
            try:
                value = getattr(brush, name)
                brush_values[name] = value.copy() if hasattr(value, "copy") else value
            except Exception:
                pass
    result["brush_values"] = brush_values
    try:
        unified = context.tool_settings.unified_paint_settings
    except Exception:
        unified = None
    result["unified"] = unified
    unified_values: dict[str, Any] = {}
    if unified is not None:
        for name in (
            "use_unified_size", "use_unified_strength", "use_unified_weight", "use_unified_color",
            "size", "unprojected_radius", "strength", "weight", "color", "secondary_color",
        ):
            try:
                value = getattr(unified, name)
                unified_values[name] = value.copy() if hasattr(value, "copy") else value
            except Exception:
                pass
    result["unified_values"] = unified_values
    return result


def _restore_brush_state(snapshot: dict[str, Any]) -> None:
    sculpt = snapshot.get("sculpt")
    brush = snapshot.get("brush")
    if sculpt is not None and brush is not None:
        try:
            sculpt.brush = brush
        except Exception:
            pass
    if brush is not None:
        for name, value in dict(snapshot.get("brush_values", {}) or {}).items():
            try:
                setattr(brush, name, value.copy() if hasattr(value, "copy") else value)
            except Exception:
                pass
    unified = snapshot.get("unified")
    if unified is not None:
        for name, value in dict(snapshot.get("unified_values", {}) or {}).items():
            try:
                setattr(unified, name, value.copy() if hasattr(value, "copy") else value)
            except Exception:
                pass


class SculptStateTransaction(AbstractContextManager):
    """Isolate active-mesh edits and restore the complete captured context."""

    def __init__(self, context: Any, *, label: str = "Sculpt operation", stage_mesh: bool = True):
        self.context = context
        self.label = str(label)
        self.stage_mesh = bool(stage_mesh)
        self.transaction_uuid = str(uuid.uuid4())
        self.committed = False
        self.rolled_back = False
        self.closed = False
        self._original = None
        self._staging = None
        self._active = None
        self._linked_users: tuple[Any, ...] = ()
        self._token = None
        self._snapshot: dict[str, Any] = {}
        self._ownership_checkpoint: frozenset[int] = frozenset()

    def __enter__(self):
        try:
            context = self.context
            active = getattr(getattr(getattr(context, "view_layer", None), "objects", None), "active", None)
            selected = tuple(getattr(context, "selected_objects", ()) or ())
            mode = str(getattr(active, "mode", "") or "") if active is not None else ""
            self._active = active
            self._original = getattr(active, "data", None) if active is not None else None
            self._ownership_checkpoint = _ownership.registry_checkpoint()
            mesh_select_mode = None
            try:
                mesh_select_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
            except Exception:
                pass
            self._snapshot = {
                "active": active,
                "selected": selected,
                "mode": mode,
                "active_material_index": int(getattr(active, "active_material_index", 0) or 0) if active else 0,
                "mesh_select_mode": mesh_select_mode,
                "edit_selection": _capture_edit_selection(active),
                "cursor": _capture_scene_cursor(context),
                "object_idprops": _capture_idprops(active),
                "mesh_idprops": _capture_idprops(self._original),
                "sculpt_state": _capture_sculpt_state(context, active),
            }
            if not self.stage_mesh or self._original is None or not hasattr(self._original, "copy"):
                return self
            if _mesh_pointer(self._original) in _LIVE_STAGING_POINTERS:
                # The enclosing transaction already isolates this mesh and decides
                # whether it is committed.
                return self
            try:
                import bpy
                self._linked_users = tuple(obj for obj in tuple(bpy.data.objects) if getattr(obj, "data", None) is self._original)
            except Exception:
                self._linked_users = (active,) if active is not None else ()
            if not _mode_set(context, "OBJECT"):
                raise RuntimeError("could not enter Object mode for staging")
            self._staging = self._original.copy()
            _LIVE_STAGING_POINTERS.add(_mesh_pointer(self._staging))
            try:
                self._staging.name = f"{getattr(self._original, 'name', 'Mesh')}.__SSS_STAGE__"
            except Exception:
                pass
            self._token = _ownership.new_token(self.transaction_uuid)
            if not _ownership.stamp(self._staging, self._token):
                raise RuntimeError("staging mesh ownership stamp failed")
            if not _ownership.track(self._staging, self._token, kind="staging_mesh", remover=_remove_mesh):
                raise RuntimeError("staging mesh ownership ledger failed")
            active.data = self._staging
            if getattr(active, "data", None) is not self._staging:
                raise RuntimeError("staging mesh assignment failed")
            if mode and not _mode_set(context, mode):
                raise RuntimeError(f"could not restore operation mode {mode}")
            _restore_edit_selection(active, self._snapshot["edit_selection"])
            return self
        except Exception:
            self.rollback()
            raise

    def _restore_context(self) -> None:
        context = self.context
        active = self._snapshot.get("active")
        try:
            current_selected = tuple(getattr(context, "selected_objects", ()) or ())
            for obj in current_selected:
                try:
                    obj.select_set(False)
                except Exception:
                    pass
            for obj in self._snapshot.get("selected", ()):
                try:
                    obj.select_set(True)
                except Exception:
                    pass
            context.view_layer.objects.active = active
            if active is not None:
                active.active_material_index = int(self._snapshot.get("active_material_index", 0))
        except Exception:
            pass
        mode = self._snapshot.get("mode")
        _mode_set(context, mode)
        try:
            values = self._snapshot.get("mesh_select_mode")
            if values is not None:
                context.tool_settings.mesh_select_mode = tuple(values)
        except Exception:
            pass
        _restore_edit_selection(active, self._snapshot.get("edit_selection", {}))
        _restore_scene_cursor(context, self._snapshot.get("cursor", {}))

    def _restore_mutable_state(self) -> None:
        active = self._snapshot.get("active")
        _restore_idprops(active, self._snapshot.get("object_idprops", {}))
        _restore_idprops(self._original, self._snapshot.get("mesh_idprops", {}))
        _restore_sculpt_state(self.context, active, self._snapshot.get("sculpt_state", {}))

    def commit(self) -> None:
        if self.rolled_back:
            raise RuntimeError("cannot commit a rolled-back sculpt transaction")
        self.committed = True

    def finish(self):
        """Commit and close exactly once for modal operators."""
        if self.rolled_back:
            return {"CANCELLED"}
        if self.closed:
            return {"FINISHED"} if self.committed else {"CANCELLED"}
        self.commit()
        self._finalize_commit()
        return {"FINISHED"}

    def cancel(self):
        """Idempotent public cancellation for modal operators."""
        if self.closed and self.committed:
            return {"FINISHED"}
        self.rollback()
        return {"CANCELLED"}

    def _finalize_commit(self) -> None:
        if self.closed:
            return
        active = self._active
        mode = self._snapshot.get("mode")
        assigned: list[Any] = []
        original_name = ""
        if self._staging is not None and self._original is not None:
            original_name = str(getattr(self._original, "name", "") or "")
        try:
            if self._staging is not None:
                if not _mode_set(self.context, "OBJECT"):
                    raise RuntimeError("could not enter Object mode for atomic mesh commit")
                for obj in self._linked_users:
                    try:
                        current = getattr(obj, "data", None)
                    except Exception:
                        continue
                    if current is self._original or obj is active:
                        obj.data = self._staging
                        if getattr(obj, "data", None) is not self._staging:
                            raise RuntimeError("linked-user mesh swap failed")
                        assigned.append(obj)
                if active is not None and getattr(active, "data", None) is not self._staging:
                    active.data = self._staging
                    if getattr(active, "data", None) is not self._staging:
                        raise RuntimeError("active mesh swap failed")
                    assigned.append(active)
                if self._token is not None:
                    if not _ownership.matches(self._staging, self._token):
                        raise RuntimeError("staging mesh ownership changed before commit")
                    _ownership.untrack(self._staging, self._token)
                    if not _ownership.clear_if_owned(self._staging, self._token):
                        raise RuntimeError("staging mesh ownership clear failed")
                _remove_mesh(self._original)
                try:
                    if original_name:
                        self._staging.name = original_name
                except Exception:
                    pass
            self.closed = True
            _LIVE_STAGING_POINTERS.discard(_mesh_pointer(self._staging))
            _mode_set(self.context, mode)
            self._restore_context()
            self._original = None
            self._staging = None
        except Exception:
            for obj in reversed(assigned):
                try:
                    obj.data = self._original
                except Exception:
                    pass
            if active is not None and self._original is not None:
                try:
                    active.data = self._original
                except Exception:
                    pass
            self.closed = False
            self.rollback()
            raise

    def rollback(self) -> None:
        if self.rolled_back or (self.closed and self.committed):
            return
        self.rolled_back = True
        active = self._active
        mode = self._snapshot.get("mode")
        _mode_set(self.context, "OBJECT")
        if self._staging is not None and self._original is not None:
            for obj in self._linked_users:
                try:
                    if getattr(obj, "data", None) is self._staging:
                        obj.data = self._original
                except Exception:
                    pass
        if active is not None and self._original is not None:
            try:
                active.data = self._original
            except Exception:
                pass
        if self._token is not None and self._staging is not None:
            try:
                _ownership.untrack(self._staging, self._token)
                _ownership.clear_if_owned(self._staging, self._token)
            except Exception:
                pass
        _LIVE_STAGING_POINTERS.discard(_mesh_pointer(self._staging))
        _remove_mesh(self._staging)
        self._staging = None
        try:
            _ownership.cleanup_since(self._ownership_checkpoint)
        except Exception:
            pass
        _mode_set(self.context, mode)
        self._restore_mutable_state()
        self._restore_context()
        self.closed = True

    def __exit__(self, exc_type, exc, tb):
        if exc_type is not None or not self.committed:
            self.rollback()
        else:
            self._finalize_commit()
        return False


class DirectBrushSession(SculptStateTransaction):
    _SETTING_NAMES = (
        "brush_tool", "brush_radius", "brush_strength", "brush_amount", "brush_direction",
        "brush_spacing", "brush_falloff", "brush_hardness", "brush_normal_radius",
        "brush_auto_smooth", "brush_accumulate", "brush_plane_offset", "brush_front_faces_only",
        "brush_stabilize_stroke", "brush_stabilize_radius", "brush_input_samples",
        "brush_use_pressure_size", "brush_use_pressure_strength", "brush_strength_hotkeys",
        "brush_strength_step", "pose_axis", "pose_angle",
    )

    def __init__(self, context: Any, *, settings: Any = None):
        super().__init__(context, label="Direct Brush", stage_mesh=True)
        self.settings = settings
        self.cancelled = False
        self.finished = False
        self._settings: dict[str, Any] = {}
        self._brush_snapshot: dict[str, Any] = {}
        self._cleanups: list[Callable[[], None]] = []

    def __enter__(self):
        super().__enter__()
        self._brush_snapshot = _capture_brush_state(self.context)
        if self.settings is not None:
            for name in self._SETTING_NAMES:
                if hasattr(self.settings, name):
                    try:
                        value = getattr(self.settings, name)
                        self._settings[name] = value.copy() if hasattr(value, "copy") else value
                    except Exception:
                        pass
        return self

    def add_cleanup(self, callback: Callable[[], None]) -> None:
        if callable(callback):
            self._cleanups.append(callback)

    def _cleanup(self) -> None:
        for callback in reversed(self._cleanups):
            try:
                callback()
            except Exception:
                pass
        self._cleanups.clear()

    def _restore_direct_state(self) -> None:
        if self.settings is not None:
            for name, value in self._settings.items():
                try:
                    setattr(self.settings, name, value.copy() if hasattr(value, "copy") else value)
                except Exception:
                    pass
        _restore_brush_state(self._brush_snapshot)

    def rollback(self) -> None:
        """Rollback mesh, brush, settings and captured native cleanups exactly once.

        ``AbstractContextManager.__exit__`` reaches this method on an exception,
        so exceptional and reload-driven exits cannot bypass Direct Brush state
        restoration merely because the modal operator did not call ``cancel``.
        """
        if self.rolled_back or (self.closed and self.committed):
            return
        self.cancelled = True
        self._cleanup()
        self._restore_direct_state()
        super().rollback()

    def cancel(self):
        if self.finished:
            return {"FINISHED"}
        if not self.cancelled:
            self.cancelled = True
        self.rollback()
        return {"CANCELLED"}

    def finish(self):
        if self.cancelled:
            return {"CANCELLED"}
        if not self.finished:
            self.finished = True
            self.committed = True
            self._cleanup()
            try:
                self._finalize_commit()
            except Exception:
                self.finished = False
                self.cancelled = True
                raise
        return {"FINISHED"}


def transactional_execute(function: Callable[..., Any] | None = None, *, stage_mesh: bool = True):
    """Decorate an ``Operator.execute`` method with exact rollback semantics."""
    def decorate(target: Callable[..., Any]):
        @functools.wraps(target)
        def wrapped(self, context, *args, **kwargs):
            transaction = SculptStateTransaction(
                context,
                label=getattr(self, "bl_label", target.__name__),
                stage_mesh=stage_mesh,
            )
            try:
                with transaction:
                    result = target(self, context, *args, **kwargs)
                    values = set(result or ()) if isinstance(result, (set, frozenset, list, tuple)) else {str(result)}
                    if "FINISHED" in values:
                        transaction.commit()
                    return result
            except Exception as exc:
                _errors.record(f"operator:{getattr(self, 'bl_idname', target.__name__)}", exc)
                return {"CANCELLED"}
        wrapped._sss_transactional_execute = True
        wrapped._sss_transaction_stage_mesh = bool(stage_mesh)
        return wrapped
    if function is None:
        return decorate
    return decorate(function)
