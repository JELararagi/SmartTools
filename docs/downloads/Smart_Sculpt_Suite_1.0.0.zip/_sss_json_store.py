# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Strict UTF-8, revisioned, crash-safe JSON persistence.

Every write uses a unique temporary file in the destination directory, flushes
and fsyncs it, atomically replaces the destination, fsyncs the directory, then
reads the file back and validates schema, revision, checksum, and caller schema.
A last-known-good ``.bak`` is replaced through the same unique-temp discipline.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Callable

SCHEMA = "smart_sculpt_suite.settings.v1"
_VALUE_KEY = "_sss_wrapped_value"
PayloadValidator = Callable[[dict[str, Any]], bool]


def _canonical(payload: Any) -> bytes:
    return json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8", "strict")


def _checksum(payload: Any) -> str:
    return hashlib.sha256(_canonical(payload)).hexdigest()


def make_document(payload: dict[str, Any], revision: int) -> dict[str, Any]:
    body = dict(payload or {})
    return {
        "_sss_schema": SCHEMA,
        "revision": max(1, int(revision)),
        "checksum": _checksum(body),
        "payload": body,
    }


def validate_document(value: Any, validator: PayloadValidator | None = None) -> bool:
    if not isinstance(value, dict) or value.get("_sss_schema") != SCHEMA:
        return False
    if not isinstance(value.get("revision"), int) or value["revision"] < 1:
        return False
    payload = value.get("payload")
    if not isinstance(payload, dict) or str(value.get("checksum", "")) != _checksum(payload):
        return False
    if callable(validator):
        try:
            return bool(validator(payload))
        except Exception:
            return False
    return True


def payload_only(document: dict[str, Any] | None) -> dict[str, Any]:
    return dict(document.get("payload", {})) if isinstance(document, dict) else {}


def _read(path: Path, validator: PayloadValidator | None = None, allow_legacy: bool = False):
    try:
        raw = path.read_bytes()
        value = json.loads(raw.decode("utf-8", "strict"))
    except Exception:
        return None
    if validate_document(value, validator):
        return value
    if allow_legacy and isinstance(value, dict):
        try:
            accepted = not callable(validator) or bool(validator(value))
        except Exception:
            accepted = False
        if accepted:
            return make_document(value, 1)
    return None


def _fsync_dir(path: Path) -> None:
    try:
        fd = os.open(str(path), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except Exception:
        # Directory fsync is unavailable on some Windows/Python combinations.
        pass


def _unique_temp(parent: Path, name: str, suffix: str = ".tmp") -> tuple[int, Path]:
    fd, filename = tempfile.mkstemp(prefix=f".{name}.", suffix=suffix, dir=str(parent))
    return fd, Path(filename)


def _write_and_fsync(fd: int, path: Path, raw: bytes) -> None:
    with os.fdopen(fd, "wb", closefd=True) as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if path.read_bytes() != raw:
        raise OSError("temporary JSON readback mismatch")


def _atomic_replace_bytes(target: Path, raw: bytes) -> None:
    """Write bytes through a unique sibling temporary and replace atomically."""
    fd, temp = _unique_temp(target.parent, target.name)
    try:
        _write_and_fsync(fd, temp, raw)
        os.replace(temp, target)
        _fsync_dir(target.parent)
        if target.read_bytes() != raw:
            raise OSError("atomic byte readback mismatch")
    finally:
        try:
            temp.unlink()
        except OSError:
            pass


def atomic_write(
    path: str | Path,
    payload: dict[str, Any],
    validator: PayloadValidator | None = None,
) -> dict[str, Any]:
    """Persist one validated document and retain a verified last-known-good backup.

    The destination is never written in place.  If post-replace validation
    fails, the previous verified destination (or verified backup) is restored
    through another unique temporary before the exception is propagated.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    backup = target.with_suffix(target.suffix + ".bak")
    current = _read(target, validator, True)
    backup_doc = _read(backup, validator, True)
    revision = max(
        [int(doc.get("revision", 0)) for doc in (current, backup_doc) if isinstance(doc, dict)] or [0]
    ) + 1
    document = make_document(dict(payload or {}), revision)
    if callable(validator) and not bool(validator(document["payload"])):
        raise ValueError("JSON payload schema rejected")
    raw = json.dumps(
        document,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        indent=2,
    ).encode("utf-8", "strict") + b"\n"

    previous_raw: bytes | None = None
    if current is not None and target.exists():
        candidate = target.read_bytes()
        if _read(target, validator, True) is not None:
            previous_raw = candidate
    elif backup_doc is not None and backup.exists():
        candidate = backup.read_bytes()
        if _read(backup, validator, True) is not None:
            previous_raw = candidate

    # Preserve the current verified target as .bak before publishing the new
    # revision.  A corrupt target is never copied over a healthy backup.
    if current is not None and target.exists():
        current_raw = target.read_bytes()
        backup_temp_fd, backup_temp = _unique_temp(target.parent, backup.name)
        try:
            _write_and_fsync(backup_temp_fd, backup_temp, current_raw)
            if _read(backup_temp, validator, True) is None:
                raise OSError("backup JSON validation failed")
            os.replace(backup_temp, backup)
            _fsync_dir(target.parent)
            if _read(backup, validator, True) is None:
                raise OSError("backup JSON readback validation failed")
        finally:
            try:
                backup_temp.unlink()
            except OSError:
                pass

    temp_fd, temp = _unique_temp(target.parent, target.name)
    replaced = False
    try:
        _write_and_fsync(temp_fd, temp, raw)
        if _read(temp, validator, False) is None:
            raise OSError("temporary JSON schema validation failed")
        os.replace(temp, target)
        replaced = True
        _fsync_dir(target.parent)
        verified = _read(target, validator, False)
        if not validate_document(verified, validator):
            raise OSError("atomic JSON readback validation failed")
        if int(verified.get("revision", 0)) != revision:
            raise OSError("atomic JSON revision mismatch")
        if target.read_bytes() != raw:
            raise OSError("atomic JSON byte readback mismatch")
        # The first successful revision also receives a verified backup.  On
        # later revisions the backup intentionally remains the previous
        # last-known-good document written above.
        if backup_doc is None and current is None:
            _atomic_replace_bytes(backup, raw)
            if _read(backup, validator, False) is None:
                raise OSError("initial backup JSON readback validation failed")
        return verified
    except Exception:
        if replaced:
            if previous_raw is not None:
                try:
                    _atomic_replace_bytes(target, previous_raw)
                    if _read(target, validator, True) is None:
                        raise OSError("restored JSON failed validation")
                except Exception as restore_exc:
                    raise OSError("atomic JSON failed and previous verified data could not be restored") from restore_exc
            else:
                # No verified predecessor existed.  Never leave an unverified
                # first revision behind after a post-replace failure.
                try:
                    target.unlink()
                    _fsync_dir(target.parent)
                except FileNotFoundError:
                    pass
                except Exception as cleanup_exc:
                    raise OSError("atomic JSON failed and invalid first revision could not be removed") from cleanup_exc
        raise
    finally:
        try:
            temp.unlink()
        except OSError:
            pass


def read_with_backup(
    path: str | Path,
    validator: PayloadValidator | None = None,
    allow_legacy: bool = False,
    repair: bool = True,
):
    target = Path(path)
    backup = target.with_suffix(target.suffix + ".bak")
    candidates = []
    for candidate in (target, backup):
        document = _read(candidate, validator, allow_legacy)
        if isinstance(document, dict):
            candidates.append((int(document.get("revision", 0)), candidate, document))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    _revision, source, document = candidates[0]
    if repair and source != target:
        try:
            return atomic_write(target, payload_only(document), validator)
        except Exception:
            # The verified backup remains authoritative even when the target is
            # temporarily read-only.
            return document
    return document


def atomic_write_value(path: str | Path, value: Any) -> dict[str, Any]:
    """Persist an arbitrary JSON value inside the same validated envelope."""
    return atomic_write(path, {_VALUE_KEY: value}, lambda payload: _VALUE_KEY in payload)


def read_value_with_backup(path: str | Path, default: Any = None, *, allow_legacy: bool = True) -> Any:
    target = Path(path)
    document = read_with_backup(target, lambda payload: _VALUE_KEY in payload, False)
    if isinstance(document, dict):
        return payload_only(document).get(_VALUE_KEY, default)
    if allow_legacy:
        try:
            value = json.loads(target.read_bytes().decode("utf-8", "strict"))
            atomic_write_value(target, value)
            return value
        except Exception:
            pass
    return default
