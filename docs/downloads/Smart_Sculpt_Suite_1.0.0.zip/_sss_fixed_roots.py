# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Eleven fixed Suite-owned roots covering seventeen logical Blender editors."""
from __future__ import annotations
from typing import Final
import bpy
from . import _sss_lifecycle as _lifecycle
from . import _sss_panel_rules as _rules
from . import _sss_runtime_errors as _runtime_errors
from .core.ui import SSS_PT_main as _BodyPanel

LOGICAL_EDITORS: Final[tuple[str, ...]] = (
    "VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR", "SHADER_EDITOR", "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR", "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR", "DOPE_SHEET", "GRAPH_EDITOR", "DRIVERS",
    "NLA_EDITOR", "TEXT_EDITOR", "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET",
)

def logical_editor(context, physical: str) -> str:
    space = getattr(context, "space_data", None)
    area = getattr(context, "area", None)
    area_type = str(getattr(area, "type", physical) or physical)
    ui_type = str(getattr(area, "ui_type", "") or "")
    if physical == "IMAGE_EDITOR":
        return "UV_EDITOR" if ui_type == "UV" or str(getattr(space, "mode", "")) == "UV" else "IMAGE_EDITOR"
    if physical == "NODE_EDITOR":
        tree = str(getattr(space, "tree_type", "") or getattr(space, "ui_type", "") or ui_type)
        if tree in {"CompositorNodeTree", "COMPOSITING"}: return "COMPOSITOR"
        if tree in {"GeometryNodeTree", "GeometryNodeEditor", "GEOMETRY"}: return "GEOMETRY_NODE_EDITOR"
        if tree in {"TextureNodeTree", "TextureNodeEditor", "TEXTURE"}: return "TEXTURE_NODE_EDITOR"
        return "SHADER_EDITOR"
    if physical == "SEQUENCE_EDITOR": return "VIDEO_SEQUENCER"
    if physical == "CLIP_EDITOR": return "MOVIE_CLIP_EDITOR"
    if physical == "DOPESHEET_EDITOR": return "DOPE_SHEET"
    if physical == "GRAPH_EDITOR":
        return "DRIVERS" if str(getattr(space, "mode", "")) == "DRIVERS" else "GRAPH_EDITOR"
    if physical == "NLA_EDITOR": return "NLA_EDITOR"
    if physical == "TEXT_EDITOR": return "TEXT_EDITOR"
    if physical == "FILE_BROWSER":
        browse = str(getattr(space, "browse_mode", "") or "")
        return "ASSET_BROWSER" if browse == "ASSETS" or ui_type == "ASSETS" else "FILE_BROWSER"
    if physical == "SPREADSHEET": return "SPREADSHEET"
    return area_type if area_type in LOGICAL_EDITORS else "VIEW_3D"

def _physical_area_matches(context, physical: str) -> bool:
    area = getattr(context, "area", None)
    if area is None:
        return False
    try:
        return str(getattr(area, "type", "") or "") == str(physical or "")
    except Exception:
        return False

def _poll(context, physical: str) -> bool:
    if not _physical_area_matches(context, physical):
        return False
    return _rules.placement_allowed(context, logical_editor(context, physical))

class _BodyMixin:
    _op = _BodyPanel._op
    _draw_diagnostics_summary = _BodyPanel._draw_diagnostics_summary
    _popup_op = _BodyPanel._popup_op
    _help_button = _BodyPanel._help_button
    _box_header = _BodyPanel._box_header
    _section_box = _BodyPanel._section_box
    _section_box_or_empty = _BodyPanel._section_box_or_empty
    _section = _BodyPanel._section
    _button_grid = _BodyPanel._button_grid
    _draw_label_stack = _BodyPanel._draw_label_stack
    _draw_always_on_toggles = _BodyPanel._draw_always_on_toggles
    _draw_full_access = _BodyPanel._draw_full_access
    _draw_active_target_summary = _BodyPanel._draw_active_target_summary
    _smart_action_run_kwargs = _BodyPanel._smart_action_run_kwargs
    _draw_smart_action_group = _BodyPanel._draw_smart_action_group
    _draw_edit_mode_sculpt = _BodyPanel._draw_edit_mode_sculpt
    _draw_top_viewport = _BodyPanel._draw_top_viewport
    _draw_top_efficiency = _BodyPanel._draw_top_efficiency
    _draw_top_brush = _BodyPanel._draw_top_brush
    _draw_top_remesh_retopo = _BodyPanel._draw_top_remesh_retopo
    _draw_top_generate_deform = _BodyPanel._draw_top_generate_deform
    _draw_top_analysis_repair = _BodyPanel._draw_top_analysis_repair
    _draw_top_save_io = _BodyPanel._draw_top_save_io
    _draw_compact_sculpt = _BodyPanel._draw_compact_sculpt
    _smart_action_label = _BodyPanel._smart_action_label
    _draw_smart_metrics = _BodyPanel._draw_smart_metrics
    _draw_smart_feature_badges = _BodyPanel._draw_smart_feature_badges
    _draw_smart_selected_action_card = _BodyPanel._draw_smart_selected_action_card
    _draw_smart_icon_board = _BodyPanel._draw_smart_icon_board
    _draw_compact_smart = _BodyPanel._draw_compact_smart
    _draw_compact_surface = _BodyPanel._draw_compact_surface
    _draw_compact_build = _BodyPanel._draw_compact_build
    _draw_compact_settings = _BodyPanel._draw_compact_settings
    _draw_compact_safe = _BodyPanel._draw_compact_safe
    _draw_impl = _BodyPanel._draw_impl
    def draw(self, context):
        # Full-body delegate.  Blender Panel.draw must return None even if an
        # internal helper later changes to return a status value.
        _BodyPanel.draw(self, context)
        return None
    draw_dashboard = _BodyPanel.draw_dashboard
    draw_topology = _BodyPanel.draw_topology
    draw_nondestructive = _BodyPanel.draw_nondestructive
    draw_procedural = _BodyPanel.draw_procedural
    draw_retopo = _BodyPanel.draw_retopo

def _bind_canonical_body_methods() -> tuple[str, ...]:
    """Bind every canonical body helper before any fixed root is registered.

    The fixed roots intentionally keep their own Panel RNA classes, so helper
    methods added to ``SSS_PT_main`` must be copied onto this non-RNA mixin.
    Synchronizing the complete callable inventory prevents omissions in newly
    split prepare/populate and always-on drawing helpers while preserving the
    fixed-root ``draw()`` None-return boundary.
    """
    bound: list[str] = []
    for name, descriptor in vars(_BodyPanel).items():
        if name in {"poll", "draw"} or not callable(descriptor):
            continue
        setattr(_BodyMixin, name, descriptor)
        bound.append(name)
    return tuple(bound)

_BODY_BOUND_METHODS: Final[tuple[str, ...]] = _bind_canonical_body_methods()

class _RootBase(_BodyMixin):
    def draw_header_preset(self, context):
        self._help_button(self.layout, 'tab_all')

    bl_label = "Smart Sculpt"
    bl_category = "Smart Sculpt"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}
    # Immutable Manager-facing metadata.  These values exist before RNA
    # registration and are never changed on a live Panel class.
    _smart_tools_manager_tool_key = _rules.TOOL_KEY
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_owner = _rules.TOOL_KEY
    _smart_sculpt_owner_uuid = _lifecycle.OWNER_UUID
    _smart_sculpt_fixed_root = True

class SSS_PT_FIXED_VIEW3D(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_view3d"; bl_space_type="VIEW_3D"
    @classmethod
    def poll(cls, context): return _poll(context,"VIEW_3D")
class SSS_PT_FIXED_IMAGE(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_image"; bl_space_type="IMAGE_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"IMAGE_EDITOR")
class SSS_PT_FIXED_NODE(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_node"; bl_space_type="NODE_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"NODE_EDITOR")
class SSS_PT_FIXED_VSE(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_vse"; bl_space_type="SEQUENCE_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"SEQUENCE_EDITOR")
class SSS_PT_FIXED_CLIP(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_clip"; bl_space_type="CLIP_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"CLIP_EDITOR")
class SSS_PT_FIXED_DOPESHEET(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_dopesheet"; bl_space_type="DOPESHEET_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"DOPESHEET_EDITOR")
class SSS_PT_FIXED_GRAPH(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_graph"; bl_space_type="GRAPH_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"GRAPH_EDITOR")
class SSS_PT_FIXED_NLA(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_nla"; bl_space_type="NLA_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"NLA_EDITOR")
class SSS_PT_FIXED_TEXT(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_text"; bl_space_type="TEXT_EDITOR"
    @classmethod
    def poll(cls, context): return _poll(context,"TEXT_EDITOR")
class SSS_PT_FIXED_FILE(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_file"; bl_space_type="FILE_BROWSER"
    _smart_tools_manager_editor_keys = ("FILE_BROWSER",)

    @classmethod
    def poll(cls, context):
        return logical_editor(context, "FILE_BROWSER") == "FILE_BROWSER" and _poll(context, "FILE_BROWSER")


class SSS_PT_FIXED_ASSET(_RootBase, bpy.types.Panel):
    bl_idname = "SSS_PT_fixed_asset"
    bl_space_type = "FILE_BROWSER"
    bl_region_type = "TOOL_PROPS"
    _smart_tools_manager_editor_keys = ("ASSET_BROWSER",)

    @classmethod
    def poll(cls, context):
        return logical_editor(context, "FILE_BROWSER") == "ASSET_BROWSER" and _poll(context, "FILE_BROWSER")

class SSS_PT_FIXED_SPREADSHEET(_RootBase, bpy.types.Panel):
    bl_idname="SSS_PT_fixed_spreadsheet"; bl_space_type="SPREADSHEET"
    @classmethod
    def poll(cls, context): return _poll(context,"SPREADSHEET")
CLASSES=(SSS_PT_FIXED_VIEW3D,SSS_PT_FIXED_IMAGE,SSS_PT_FIXED_NODE,SSS_PT_FIXED_VSE,SSS_PT_FIXED_CLIP,
         SSS_PT_FIXED_DOPESHEET,SSS_PT_FIXED_GRAPH,SSS_PT_FIXED_NLA,SSS_PT_FIXED_TEXT,SSS_PT_FIXED_FILE,SSS_PT_FIXED_ASSET,SSS_PT_FIXED_SPREADSHEET)

# Concrete metadata mirrors the base class so external static/native-root
# matrix tools that inspect class dictionaries instead of inherited attributes
# still find the authoritative roots.  This runs at module import before
# Blender RNA registration and never mutates registered Panel classes.
for _cls in CLASSES:
    _cls.bl_region_type = _cls.bl_region_type
    _cls.bl_category = "Smart Sculpt"
    _cls._smart_tools_manager_tool_key = _rules.TOOL_KEY
    _cls._smart_tools_manager_native_npanel_root = True

_REGISTERED=False
_REGISTERED_CLASSES:list[type]=[]

def register() -> None:
    """Register all fixed roots independently; never abort package enable."""
    global _REGISTERED
    if _REGISTERED:
        return None
    try:
        _rules.bind_public_manager_api()
    except Exception as exc:
        _runtime_errors.warn_once('fixed-roots-manager-bind', exc)
    registered_now=[]
    for cls in CLASSES:
        try:
            if _lifecycle.register_class(cls):
                registered_now.append(cls)
        except Exception as exc:
            _runtime_errors.warn_once(f'fixed-root:{getattr(cls, "__name__", "unknown")}', exc)
    _REGISTERED_CLASSES[:] = registered_now
    _REGISTERED=True
    return None

def rollback_registration() -> None:
    global _REGISTERED
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try: _lifecycle.unregister_class(cls)
        except Exception: pass
    _REGISTERED_CLASSES.clear()
    _rules.unbind()
    _REGISTERED=False

def unregister() -> None:
    rollback_registration()
