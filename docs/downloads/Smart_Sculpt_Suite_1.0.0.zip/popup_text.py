# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Collect layout rows and render a screen-sized page."""
import json

from bpy.props import IntProperty, StringProperty


class PopupText:
    def __init__(self, width=None):
        self.rows = []
        self.width = width

    def box(self):
        return self

    def row(self, *, align=False):
        return self

    column = row

    def label(self, *, text, icon="NONE"):
        if self.width is None:
            self.rows.append((text, icon))
        else:
            from .core.help_content import _pixel_wrap_lines, _ui_scale

            lines = _pixel_wrap_lines(text, max_pixels=_ui_scale() * (self.width - 85))
            self.rows.extend((line, icon if index == 0 else "NONE")
                             for index, line in enumerate(lines))

    def separator(self, *, factor=1.0):
        self.rows.append(("", None))


def _rows_per_page(context):
    physical_height = context.window.height / context.preferences.system.ui_scale
    max_rows = int(int(physical_height - 140) / 24)
    return min(16, max(max_rows, 4))


def _get_page(operator):
    return min(operator.get("page_number", 1), operator.page_count)


def _set_page(operator, page):
    operator["page_number"] = min(max(page, 1), operator.page_count)


def store_popup_text(operator, context, text):
    operator.page_text = json.dumps(text.rows, ensure_ascii=False)
    page_size = _rows_per_page(context)
    operator.page_size = page_size
    operator.page_count = max(1, (len(text.rows) + page_size - 1) // page_size)
    operator.page = 1


def draw_popup_text(operator, layout, page_label):
    count = operator.page_count
    if count > 1:
        layout.row(align=True).prop(operator, "page", text=f"{page_label} (1–{count})")
    size = operator.page_size
    start = size * (operator.page - 1)
    rows = json.loads(operator.page_text or "[]")
    for text, icon in rows[start:start + size]:
        if icon is None:
            layout.separator(factor=0.25)
        else:
            layout.label(text=text, icon=icon)


def popup_page_property():
    return IntProperty(min=1, options={"SKIP_SAVE"}, get=_get_page, set=_set_page)


def popup_text_property():
    return StringProperty(options={"HIDDEN", "SKIP_SAVE"})
