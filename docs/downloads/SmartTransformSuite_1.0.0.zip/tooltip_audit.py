# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

# ============================================================================
# Tooltip audit runtime helper
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package
# ============================================================================

from __future__ import annotations

import inspect
import re
import sys
from typing import Any

import bpy

_PROP_FACTORY_NAMES = (
    "BoolProperty",
    "BoolVectorProperty",
    "CollectionProperty",
    "EnumProperty",
    "FloatProperty",
    "FloatVectorProperty",
    "IntProperty",
    "IntVectorProperty",
    "PointerProperty",
    "StringProperty",
)

_TRANSLATION_CONTEXTS = ("*", "Operator", "Property", "Tooltip", "UI", "Panel", "Menu", "Addon")

_JA_RE = re.compile(r"[ぁ-んァ-ヶ一-龯]")
_ASCII_RE = re.compile(r"[A-Za-z]")
_SPACE_RE = re.compile(r"\s+")

_EXCLUDED_MODULE_SUFFIXES = (
    ".tooltip_audit",
)

_ORIGINAL_REGISTER_CLASS = None
_ACTIVE = False
_FINISHED = False
_OWNER = (__package__ or "addon") + ".tooltip_audit"
_PENDING_TRANSLATIONS: dict[str, dict[tuple[str, str], str]] = {"ja_JP": {}}
_ORIGINAL_CLASS_I18N_TEXTS: dict[tuple[str, str, str], Any] = {}
_ORIGINAL_PROPERTY_DATA: dict[tuple[str, str, str], dict[str, Any]] = {}
_ORIGINAL_BPY_FACTORIES: dict[str, Any] = {}
_WRAPPED_FACTORIES: dict[str, Any] = {}
_WRAPPED_FACTORY_OBJECTS: set[Any] = set()
_WRAPPED_MODULE_ALIASES: dict[tuple[str, str], Any] = {}
_PACKAGE_MODULE_CACHE: tuple[tuple[str, Any], ...] = ()
_PACKAGE_MODULE_CACHE_NAMES: tuple[str, ...] = ()
_PACKAGE_CLASS_CACHE: tuple[tuple[str, str, Any], ...] = ()
_PACKAGE_CLASS_CACHE_MODULE_NAMES: tuple[str, ...] = ()


def _contains_japanese(text: object) -> bool:
    return isinstance(text, str) and bool(_JA_RE.search(text))


def _contains_ascii(text: object) -> bool:
    return isinstance(text, str) and bool(_ASCII_RE.search(text))



def _split_bilingual_pair(text: object) -> tuple[str, str] | None:
    if not isinstance(text, str) or " / " not in text:
        return None
    raw = str(text)
    left, right = raw.split(" / ", 1)
    left = left.strip()
    right = right.strip()
    if not left or not right:
        return None
    left_has_ja = _contains_japanese(left)
    right_has_ja = _contains_japanese(right)
    if left_has_ja == right_has_ja:
        return None
    # Return (English, Japanese).  Only true language-pair strings are split;
    # same-language separators such as "X / Y" or "Undo / Redo" are preserved.
    return (right, left) if left_has_ja else (left, right)


def _canonical_visible_text(text: object) -> object:
    """Return the English source of RNA-visible text and register its Japanese.

    Text baked into RNA cannot follow a language change made during the session,
    so RNA keeps the English source and Blender translates it when drawing.
    """
    if not isinstance(text, str) or not text:
        return text
    from . import translation as _sts_translation
    pair = _split_bilingual_pair(text)
    if pair:
        en, ja = pair
        _register_translation(en, ja)
        return en
    if _contains_japanese(text):
        en = _sts_translation.english_source(text)
        if en:
            _register_translation(en, text)
            return en
        return text
    ja = _sts_translation.japanese_source(text)
    if ja:
        _register_translation(text, ja)
    return text


def _clean_text(text: object) -> str:
    if text is None:
        return ""
    return _SPACE_RE.sub(" ", str(text).strip())


def _is_valid_blender_update_callback(callback: object) -> bool:
    if callback is None:
        return True
    if not callable(callback):
        return False
    try:
        signature = inspect.signature(callback)
        positional = [
            p for p in signature.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        required = [p for p in positional if p.default is p.empty]
        has_varargs = any(p.kind == p.VAR_POSITIONAL for p in signature.parameters.values())
        if has_varargs:
            return len(required) <= 2
        return len(positional) >= 2 and len(required) <= 2
    except Exception:
        pass
    try:
        code = getattr(callback, '__code__', None)
        if code is not None:
            argc = int(getattr(code, 'co_argcount', 0)) + int(getattr(code, 'co_posonlyargcount', 0))
            return argc == 2
    except Exception:
        pass
    return True


def _sanitize_property_factory_kwargs(kwargs: dict) -> dict:
    if 'update' in kwargs and not _is_valid_blender_update_callback(kwargs.get('update')):
        kwargs = dict(kwargs)
        kwargs.pop('update', None)
    return kwargs


def _package_name() -> str:
    return __package__ or "addon"


def _package_module_names() -> tuple[str, ...]:
    package = _package_name()
    prefix = package + "."
    names: list[str] = []
    for module_name, module in list(sys.modules.items()):
        if module is None:
            continue
        if module_name != package and not module_name.startswith(prefix):
            continue
        if any(module_name.endswith(suffix) for suffix in _EXCLUDED_MODULE_SUFFIXES):
            continue
        names.append(module_name)
    return tuple(names)


def _package_modules() -> tuple[tuple[str, Any], ...]:
    global _PACKAGE_MODULE_CACHE, _PACKAGE_MODULE_CACHE_NAMES
    global _PACKAGE_CLASS_CACHE, _PACKAGE_CLASS_CACHE_MODULE_NAMES
    names = _package_module_names()
    if names != _PACKAGE_MODULE_CACHE_NAMES:
        modules: list[tuple[str, Any]] = []
        for module_name in names:
            module = sys.modules.get(module_name)
            if module is not None:
                modules.append((module_name, module))
        _PACKAGE_MODULE_CACHE_NAMES = names
        _PACKAGE_MODULE_CACHE = tuple(modules)
        _PACKAGE_CLASS_CACHE = ()
        _PACKAGE_CLASS_CACHE_MODULE_NAMES = ()
    return _PACKAGE_MODULE_CACHE


def _iter_package_modules():
    yield from _package_modules()


def _iter_package_classes():
    global _PACKAGE_CLASS_CACHE, _PACKAGE_CLASS_CACHE_MODULE_NAMES
    modules = _package_modules()
    module_names = tuple(module_name for module_name, _module in modules)
    if module_names != _PACKAGE_CLASS_CACHE_MODULE_NAMES or not _PACKAGE_CLASS_CACHE:
        seen: set[tuple[str, str]] = set()
        package = _package_name()
        classes: list[tuple[str, str, Any]] = []
        for module_name, module in modules:
            for class_name, cls in inspect.getmembers(module, inspect.isclass):
                owner = str(getattr(cls, "__module__", "") or "")
                if not owner.startswith(package):
                    continue
                key = (module_name, class_name)
                if key in seen:
                    continue
                seen.add(key)
                classes.append((module_name, class_name, cls))
        _PACKAGE_CLASS_CACHE_MODULE_NAMES = module_names
        _PACKAGE_CLASS_CACHE = tuple(classes)
    yield from _PACKAGE_CLASS_CACHE


def _property_keywords(prop_def):
    keywords = getattr(prop_def, "keywords", None)
    if isinstance(keywords, dict):
        fn = getattr(getattr(prop_def, "function", None), "__name__", "")
        return keywords, str(fn or "")
    if isinstance(prop_def, tuple) and len(prop_def) == 2 and isinstance(prop_def[1], dict):
        return prop_def[1], str(prop_def[0] or "")
    return None, ""


def _register_translation(msgid: object, ja_text: object) -> None:
    msgid = str(msgid or "").strip()
    ja_text = str(ja_text or "").strip()
    if not msgid or not ja_text:
        return
    if _contains_japanese(msgid) and not _contains_ascii(msgid):
        return
    # A one-word msgid is shared with all of Blender; leave it to Blender's catalog.
    if " " not in msgid:
        return
    table = _PENDING_TRANSLATIONS.setdefault("ja_JP", {})
    for ctx in _TRANSLATION_CONTEXTS:
        table.setdefault((ctx, msgid), ja_text)


def _patch_static_enum_items(keywords: dict) -> bool:
    items = keywords.get("items")
    if not isinstance(items, (list, tuple)):
        return False
    changed = False
    new_items = []
    for item in items:
        if item is None or not isinstance(item, (list, tuple)) or len(item) < 2:
            new_items.append(item)
            continue
        rebuilt = list(item)
        rebuilt[1] = _canonical_visible_text(item[1])
        if len(item) >= 3:
            rebuilt[2] = _canonical_visible_text(item[2])
        if tuple(rebuilt) != tuple(item):
            item = tuple(rebuilt)
            changed = True
        new_items.append(item)
    if changed:
        keywords["items"] = tuple(new_items) if isinstance(items, tuple) else list(new_items)
    return changed


def _patch_annotation_properties() -> None:
    for module_name, class_name, cls in _iter_package_classes():
        annotations = getattr(cls, "__annotations__", {}) or {}
        for prop_name, prop_def in annotations.items():
            keywords, prop_type = _property_keywords(prop_def)
            prop_type = str(prop_type or "").split(".")[-1]
            if not isinstance(keywords, dict) or prop_type not in _PROP_FACTORY_NAMES:
                continue
            key = (module_name, class_name, str(prop_name))
            if key not in _ORIGINAL_PROPERTY_DATA:
                _ORIGINAL_PROPERTY_DATA[key] = {
                    "name_present": "name" in keywords,
                    "name": keywords.get("name"),
                    "description_present": "description" in keywords,
                    "description": keywords.get("description"),
                    "items_present": "items" in keywords,
                    "items": keywords.get("items"),
                }
            for field in ("name", "description"):
                if field in keywords:
                    keywords[field] = _canonical_visible_text(keywords.get(field))
            try:
                _patch_static_enum_items(keywords)
            except Exception:
                pass


def _patch_one_class_i18n_texts(module_name: str, class_name: str, cls) -> None:
    for attr in ("bl_label", "bl_description", "bl_category"):
        try:
            value = getattr(cls, attr, None)
        except Exception:
            continue
        localized = _canonical_visible_text(value)
        if localized == value:
            continue
        key = (module_name, class_name, attr)
        if key not in _ORIGINAL_CLASS_I18N_TEXTS:
            _ORIGINAL_CLASS_I18N_TEXTS[key] = value
        try:
            setattr(cls, attr, localized)
        except Exception:
            pass


def _patch_class_i18n_texts() -> None:
    for module_name, class_name, cls in _iter_package_classes():
        _patch_one_class_i18n_texts(module_name, class_name, cls)


def _install_register_class_wrapper() -> None:
    global _ORIGINAL_REGISTER_CLASS
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    original = bpy.utils.register_class
    package = _package_name()

    def _wrapper(cls):
        module_name = str(getattr(cls, "__module__", "") or "")
        if module_name.startswith(package):
            _patch_one_class_i18n_texts(module_name, cls.__name__, cls)
        return original(cls)

    _ORIGINAL_REGISTER_CLASS = original
    bpy.utils.register_class = _wrapper


def _restore_register_class_wrapper() -> None:
    global _ORIGINAL_REGISTER_CLASS
    if _ORIGINAL_REGISTER_CLASS is not None:
        bpy.utils.register_class = _ORIGINAL_REGISTER_CLASS
        _ORIGINAL_REGISTER_CLASS = None


def _make_factory_wrapper(factory_name: str, original):
    def _wrapper(*args, **kwargs):
        kwargs = _sanitize_property_factory_kwargs(dict(kwargs))
        for field in ("name", "description"):
            if field in kwargs:
                kwargs[field] = _canonical_visible_text(kwargs.get(field))
        if factory_name == "EnumProperty":
            try:
                _patch_static_enum_items(kwargs)
            except Exception:
                pass
        return original(*args, **kwargs)

    _wrapper.__name__ = getattr(original, "__name__", factory_name)
    _wrapper.__qualname__ = getattr(original, "__qualname__", factory_name)
    return _wrapper


def _install_property_factory_wrappers() -> None:
    if _ORIGINAL_BPY_FACTORIES:
        return
    for factory_name in _PROP_FACTORY_NAMES:
        original = getattr(bpy.props, factory_name, None)
        if not callable(original):
            continue
        _ORIGINAL_BPY_FACTORIES[factory_name] = original
        wrapper = _make_factory_wrapper(factory_name, original)
        _WRAPPED_FACTORIES[factory_name] = wrapper
        _WRAPPED_FACTORY_OBJECTS.add(wrapper)
        try:
            setattr(bpy.props, factory_name, wrapper)
        except Exception:
            pass
    for module_name, module in _iter_package_modules():
        for factory_name, wrapper in _WRAPPED_FACTORIES.items():
            if not hasattr(module, factory_name):
                continue
            current = getattr(module, factory_name)
            if current is wrapper:
                continue
            _WRAPPED_MODULE_ALIASES[(module_name, factory_name)] = current
            try:
                setattr(module, factory_name, wrapper)
            except Exception:
                pass


def _restore_property_factory_wrappers() -> None:
    for factory_name, original in list(_ORIGINAL_BPY_FACTORIES.items()):
        try:
            setattr(bpy.props, factory_name, original)
        except Exception:
            pass
    for module_name, module in _iter_package_modules():
        for factory_name in _PROP_FACTORY_NAMES:
            current = getattr(module, factory_name, None)
            if current in _WRAPPED_FACTORY_OBJECTS:
                replacement = _ORIGINAL_BPY_FACTORIES.get(factory_name) or getattr(bpy.props, factory_name, None)
                if replacement is not None:
                    try:
                        setattr(module, factory_name, replacement)
                    except Exception:
                        pass
    for (module_name, factory_name), original in list(_WRAPPED_MODULE_ALIASES.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        try:
            setattr(module, factory_name, original)
        except Exception:
            pass
    _ORIGINAL_BPY_FACTORIES.clear()
    _WRAPPED_FACTORIES.clear()
    _WRAPPED_FACTORY_OBJECTS.clear()
    _WRAPPED_MODULE_ALIASES.clear()


def _restore_annotation_properties() -> None:
    for (module_name, class_name, prop_name), original in list(_ORIGINAL_PROPERTY_DATA.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        cls = getattr(module, class_name, None)
        if cls is None:
            continue
        annotations = getattr(cls, "__annotations__", {}) or {}
        prop_def = annotations.get(prop_name)
        keywords, _prop_type = _property_keywords(prop_def)
        if not isinstance(keywords, dict):
            continue
        if original.get("name_present", False):
            keywords["name"] = original.get("name")
        else:
            keywords.pop("name", None)
        if original.get("description_present", False):
            keywords["description"] = original.get("description")
        else:
            keywords.pop("description", None)
        if original.get("items_present", False):
            keywords["items"] = original.get("items")
        else:
            keywords.pop("items", None)
    _ORIGINAL_PROPERTY_DATA.clear()


def _restore_class_i18n_texts() -> None:
    for (module_name, class_name, attr), original in list(_ORIGINAL_CLASS_I18N_TEXTS.items()):
        module = sys.modules.get(module_name)
        if module is None:
            continue
        cls = getattr(module, class_name, None)
        if cls is None:
            continue
        try:
            setattr(cls, attr, original)
        except Exception:
            pass
    _ORIGINAL_CLASS_I18N_TEXTS.clear()


def _register_pending_translations() -> None:
    table = _PENDING_TRANSLATIONS.get("ja_JP", {})
    if not table:
        return
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_OWNER, _PENDING_TRANSLATIONS)
    except Exception:
        pass


def _unregister_pending_translations() -> None:
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass


def _clear_pending_translations() -> None:
    _PENDING_TRANSLATIONS.clear()
    _PENDING_TRANSLATIONS["ja_JP"] = {}


def begin_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    if _ACTIVE:
        return
    _ACTIVE = True
    _FINISHED = False
    _clear_pending_translations()
    _install_property_factory_wrappers()
    _install_register_class_wrapper()
    _patch_annotation_properties()
    _patch_class_i18n_texts()


def finish_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    if not _ACTIVE and _FINISHED:
        return
    try:
        # Do not mutate already-registered Panel / Operator classes here.  Blender
        # 5.x keeps native references to registered UI classes; changing class
        # metadata after registration can leave stale UI callbacks during N-panel
        # redraws.  Property factories are still wrapped while modules register,
        # and the collected translation table is registered here.
        _register_pending_translations()
    finally:
        _restore_property_factory_wrappers()
        _restore_register_class_wrapper()
        _ACTIVE = False
        _FINISHED = True


def clear_runtime_audit() -> None:
    global _ACTIVE, _FINISHED
    global _PACKAGE_MODULE_CACHE, _PACKAGE_MODULE_CACHE_NAMES
    global _PACKAGE_CLASS_CACHE, _PACKAGE_CLASS_CACHE_MODULE_NAMES
    _unregister_pending_translations()
    _restore_property_factory_wrappers()
    _restore_register_class_wrapper()
    _restore_annotation_properties()
    _restore_class_i18n_texts()
    _clear_pending_translations()
    _PACKAGE_MODULE_CACHE = ()
    _PACKAGE_MODULE_CACHE_NAMES = ()
    _PACKAGE_CLASS_CACHE = ()
    _PACKAGE_CLASS_CACHE_MODULE_NAMES = ()
    _ACTIVE = False
    _FINISHED = False


def abort_runtime_audit() -> None:
    clear_runtime_audit()
