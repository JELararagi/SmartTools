# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import numbers
import os
import time
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

from . import runtime as _runtime

_SETTINGS_FOLDER_NAME = 'Smart_Transform_Suite'
_PRIMARY_STORE_FILE_NAME = 'Smart_Transform_Suite.json'
_LEGACY_STORE_FILE_NAMES = (
    'smart_transform_suite_npanel_settings.json',
    'core_suite_npanel_settings.json',
)
_AUTOSAVE_INTERVAL = 3.0
_TIMER_RUNNING = False
_SAVE_PENDING = False
_DIRTY_SINCE_SAVE = False
_USERPREF_MTIME_NS: int | None = None
_LAST_SNAPSHOT: dict[str, Any] | None = None
_RESTORING = False
_LAST_SCENE_ID: int | None = None
_STARTUP_RESTORE_PENDING = False
_FILE_LOAD_RESTORE_PENDING = False
_USER_SCENE_EDIT_DURING_STARTUP_RESTORE = False
_PREF_MIRROR_PROP = 'npanel_settings_json'
_FEATURE_TOGGLE_MIRROR_PROP = 'persistent_feature_toggles_json'
_RUNTIME_SYNC_TIMER_RUNNING = False
_RUNTIME_SYNC_TIMER = None
_RUNTIME_SYNC_GENERATION = 0
_RUNTIME_SYNC_ADMITTED = False
_MODULE_IMPORT_TIME_NS = time.time_ns()
_POLICY_TOGGLE_WRITE_DEPTH = 0
_CHANGE_MSGBUS_OWNER = object()
_CHANGE_SUBSCRIPTIONS_INSTALLED = False
_LAST_WRITE_ERROR: dict[str, Any] | None = None

_PERSISTED_PROPERTY_FACTORIES = frozenset({
    'BoolProperty', 'BoolVectorProperty', 'EnumProperty', 'FloatProperty',
    'FloatVectorProperty', 'IntProperty', 'IntVectorProperty', 'StringProperty',
})

_FEATURE_TOGGLE_COLLECTION_PROP = 'smart_transform_suite_persistent_feature_switches'
_FEATURE_TOGGLE_ITEM_PROPS = ('enabled',)

_SCENE_SCALAR_PROPS = (
    'select_guard_enabled',
    'ssg_other_objects_occlude',
    'ssg_multi_edit_mutual_occlude',
    'ssg_enable_click_filter',
    'ssg_quality_preset',
    'ssg_view_scope',
    'ssg_auto_bypass_xray',
    'ssg_select_through_xray_off',
    'ssg_auto_bypass_wireframe',
    'ssg_ignore_backface_occluders',
    'ssg_hold_bypass_key',
    'ssg_hold_enable_key',
    'ssg_hold_enable_key_event',
    'ssg_show_status_feedback',
    'ssg_partial_visible_ratio_min',
    'ssg_max_steps',
    'ssg_vertex_screen_samples',
    'ssg_vertex_sample_radius_px',
    'ssg_edge_sample_count',
    'ssg_face_sample_limit',
    'ssg_object_sample_limit',
    'ssg_target_depth_margin',
    'ssg_cache_seconds',
    'ssg_idle_signature_skip',
    'ssg_eps',
)
_SCENE_COLLECTION_REF_PROPS = (
    'ssg_occluder_exclude_collection',
)
# ``None`` means: persist every writable scalar/array property in the suite-owned
# PointerProperty group.  _strip_live_transform_values() is still applied, so
# live object/edit-mesh value setters (loc/rot/scale/dim/bevel/etc.) are never
# restored over data saved in a .blend file.
_SCENE_POINTER_PROP_STORES = {
    'core_props': None,
}
# Cursor lock state is owned by each Scene and persisted by Blender in the
# .blend.  Mirroring it into the global N-panel JSON would replay one scene's
# enabled flag and anchor into another scene during a deferred scene switch.
_WINDOW_MANAGER_POINTER_PROP_STORES = {
    'quick_align_settings': None,
}

# The Always-on Toggles section is critical user state and must be kept outside
# .blend data.  Store a compact explicit block in config/Smart_Transform_Suite/Smart_Transform_Suite.json
# in addition to the recursive preferences snapshot so delayed UI operators and
# nested PropertyGroups cannot be missed.
_ALWAYS_ON_TOGGLE_PROP_PATHS = (
    'show_always_on_switches',
    'npanel_state_save_enabled',
    'enable_smart_gizmo_live_runtime',
    'smart_gizmo_live_runtime_restore_ack_v13',
    'gizmo_toggle_state',
    'enable_smart_gizmo_style',
    'prefer_csdt_keymap_priority',
    'enable_cursor_lock_feature',
    'enable_precision_length_drag',
    'precision_length_drag_step_cm',
    'precision_numeric_drag_step_rotation',
    'precision_numeric_drag_step_length',
    'precision_numeric_drag_step_mass',
    'precision_numeric_drag_step_time',
    'precision_numeric_drag_step_temperature',
    'precision_numeric_drag_units_migrated_v61',
    'precision_number_drag_step_length',
    'precision_number_drag_step_area',
    'precision_number_drag_step_volume',
    'precision_number_drag_step_angle',
    'precision_number_drag_step_scale',
    'precision_number_drag_step_factor',
    'precision_number_drag_step_percentage',
    'precision_number_drag_step_time',
    'precision_number_drag_step_time_absolute',
    'precision_number_drag_step_velocity',
    'precision_number_drag_step_acceleration',
    'precision_number_drag_step_mass',
    'precision_number_drag_step_power',
    'precision_number_drag_step_temperature',
    'precision_number_drag_step_color_temperature',
    'precision_number_drag_step_wavelength',
    'precision_number_drag_step_frequency',
    'precision_number_drag_step_camera',
    'precision_number_drag_step_color',
    'precision_number_drag_step_number',
    'enable_mesh_island_transform',
    'select_guard.pref_scene_runtime_enabled',
    'select_guard.apply_defaults_on_file_load',
    'select_guard.pref_hold_enable_key',
    'select_guard.pref_hold_enable_key_event',
)


_LIVE_TRANSFORM_PROP_NAMES = frozenset({
    'loc_x', 'loc_y', 'loc_z',
    'rot_x', 'rot_y', 'rot_z',
    'scale_x', 'scale_y', 'scale_z',
    'dim_x', 'dim_y', 'dim_z',
    'v_bevel', 'v_crease',
    'e_bevel', 'e_crease',
})


def _strip_live_transform_values(data: Any) -> Any:
    if isinstance(data, dict):
        return {
            key: _strip_live_transform_values(value)
            for key, value in data.items()
            if str(key) not in _LIVE_TRANSFORM_PROP_NAMES
        }
    if isinstance(data, list):
        return [_strip_live_transform_values(item) for item in data]
    return data

_SKIP_PREF_PROPS = {
    'rna_type',
    _PREF_MIRROR_PROP,
    _FEATURE_TOGGLE_MIRROR_PROP,
    # UI-only proxy; precision_numeric_drag_step_time persists physical seconds.
    'precision_numeric_drag_step_time_display',
}

_LEGACY_MODULE_ENABLE_FLAGS = {
    'enable_core_panel',
    'enable_quick_align',
    'enable_quick_multi_edit',
    'enable_select_guard',
}

_SKIP_POINTER_TYPES = {
    'WindowManager', 'Scene', 'Screen', 'Object', 'Collection', 'Material', 'Mesh',
}

_NPANEL_DIRECT_PROP_PREFIXES = (
    'smart_', 'sts_', 'csdt_', 'select_guard_', 'ssg_', 'quick_', 'qme_',
    'cursor_lock_', 'custom_select_', 'precision_', 'mesh_island_', 'normal_align_',
    'overlay_', 'gizmo_', 'axis_', 'bg_',
)

# Runtime-only payloads used by preview/modal tools. They are not user-facing
# N-panel settings and must not be replayed into another scene from JSON.
_NPANEL_RUNTIME_PROP_NAMES = frozenset({
    'name',
    'target_name', 'source_names_json', 'selected_names_json', 'initial_states_json',
    'hit_location_json', 'hit_normal_json', 'view_up_json', 'view_right_json',
    'is_updating', 'last_preview_time', 'pending_update', 'timer_active',
})


def _persisted_preference_property_update(_owner, context) -> None:
    """Publish a native RNA change to the existing deferred settings writer."""
    request_save('persisted_preference_property_update', context=context)


def _persisted_scene_property_update(_owner, context) -> None:
    """Publish a scene/WM setting change without touching live transform values."""
    mark_user_scene_edit_during_startup_restore(context)
    request_save('persisted_scene_property_update', context=context)


def materialize_persisted_property_updates(classes, *, owner_scope: str = 'preferences'):
    """Add an update callback to persisted, update-less deferred RNA properties.

    Blender does not emit a msgbus change for custom properties which have no
    update callback.  The settings watcher therefore cannot observe ordinary UI
    or operator assignments to those properties.  Materialize the callback once,
    before class registration, while preserving every existing keyword and
    leaving update/get/set properties, hidden runtime payloads, and live
    transform accessors untouched.
    """
    callback = (
        _persisted_scene_property_update
        if str(owner_scope) in {'scene', 'window_manager'}
        else _persisted_preference_property_update
    )
    report = {'materialized': [], 'existing_callback_or_accessor': [], 'excluded': []}
    for cls in tuple(classes or ()):
        annotations = vars(cls).get('__annotations__', {})
        if not isinstance(annotations, dict):
            continue
        for name, deferred in tuple(annotations.items()):
            function = getattr(deferred, 'function', None)
            keywords = getattr(deferred, 'keywords', None)
            factory_name = str(getattr(function, '__name__', '') or '')
            label = f'{getattr(cls, "__name__", type(cls).__name__)}.{name}'
            if factory_name not in _PERSISTED_PROPERTY_FACTORIES or not isinstance(keywords, dict):
                report['excluded'].append(label)
                continue
            options = set(keywords.get('options', set()) or set())
            if (
                name in _SKIP_PREF_PROPS
                or name in _LEGACY_MODULE_ENABLE_FLAGS
                or name in _LIVE_TRANSFORM_PROP_NAMES
                or name in _NPANEL_RUNTIME_PROP_NAMES
                or str(name).startswith('bl_')
                or 'HIDDEN' in options
            ):
                report['excluded'].append(label)
                continue
            if any(key in keywords for key in ('update', 'get', 'set')):
                report['existing_callback_or_accessor'].append(label)
                continue
            materialized_keywords = dict(keywords)
            materialized_keywords['update'] = callback
            annotations[name] = function(**materialized_keywords)
            report['materialized'].append(label)
    return report


def _addon_root_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    return 'core_suite'


def is_restoring() -> bool:
    return bool(_RESTORING)


def _startup_restore_pending_has_store(context=None) -> bool:
    del context
    # Block snapshots while either the initial startup restore or a subsequent
    # .blend file-load restore is pending.  Preferences are stored in a hidden
    # WindowManager PropertyGroup; Blender recreates that group with defaults
    # when a file is opened, so saving before load_post restoration would replace
    # the external JSON with those temporary defaults.
    return bool(_STARTUP_RESTORE_PENDING or _FILE_LOAD_RESTORE_PENDING)


def mark_user_scene_edit_during_startup_restore(context=None) -> None:
    """Record an explicit scene/N-panel edit made before deferred JSON restore.

    On Windows/Blender 5.1 the add-on can be installed in one process, which
    creates a default JSON, then opened in the next process where the user may
    toggle a setting before the deferred startup restore timer fires.  This mark
    prevents that stale startup restore from replaying default false values over
    the user's new scene-side edits.
    """
    del context
    global _USER_SCENE_EDIT_DURING_STARTUP_RESTORE
    try:
        if _STARTUP_RESTORE_PENDING:
            _USER_SCENE_EDIT_DURING_STARTUP_RESTORE = True
    except Exception:
        pass


def _preexisting_store_file_available() -> bool:
    """Return True only for a settings file that predates this module import."""
    try:
        candidates = _settings_path_candidates()
    except Exception:
        candidates = []
    for path in candidates:
        try:
            if not path.exists():
                continue
            data = _parse_store_text(path.read_text(encoding='utf-8'))
            if not isinstance(data, dict) or not data:
                continue
            mtime = _path_mtime_ns(path)
            if mtime is None or mtime < _MODULE_IMPORT_TIME_NS:
                return True
        except Exception:
            pass
    return False


def is_npanel_state_save_enabled(context=None) -> bool:
    """Return whether every N-panel change should be written immediately.

    The switch lives on the runtime preferences object.  Missing preferences are
    treated as enabled so first installs keep the previous persistent behavior.
    """
    try:
        prefs = _resolve_preferences(context or getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    if prefs is None:
        return True
    try:
        return bool(getattr(prefs, 'npanel_state_save_enabled', True))
    except Exception:
        return True


def _write_allowed(context=None) -> bool:
    """Return True only for normal enabled saves or the one policy-toggle write."""
    return bool(_POLICY_TOGGLE_WRITE_DEPTH > 0 or is_npanel_state_save_enabled(context))


def mark_dirty() -> None:
    global _DIRTY_SINCE_SAVE
    _DIRTY_SINCE_SAVE = True


def _record_write_error(stage: str, path, error) -> None:
    """Expose the last persistence failure without mutating last-good state."""
    global _LAST_WRITE_ERROR
    _LAST_WRITE_ERROR = {
        'stage': str(stage or 'write'),
        'path': str(path or ''),
        'error': f'{type(error).__name__}: {error}' if isinstance(error, BaseException) else str(error or ''),
        'time_ns': time.time_ns(),
    }


def _clear_write_error() -> None:
    global _LAST_WRITE_ERROR
    _LAST_WRITE_ERROR = None


def last_write_error() -> dict[str, Any] | None:
    """Return a detached, user-observable description of the last write error."""
    return dict(_LAST_WRITE_ERROR) if isinstance(_LAST_WRITE_ERROR, dict) else None


def _config_root_dir(*, create: bool = True) -> Path | None:
    # Blender's user config directory.  On Windows Blender 5.1 this resolves to:
    # C:\Users\<User>\AppData\Roaming\Blender Foundation\Blender\5.1\config
    try:
        base_text = bpy.utils.user_resource('CONFIG', path='', create=bool(create))
        base = Path(str(base_text))
        if create:
            base.mkdir(parents=True, exist_ok=True)
        return base
    except Exception:
        return None


def _settings_dir() -> Path | None:
    # Store every suite-wide N-panel setting in a dedicated folder under
    # Blender's config directory:
    #   ...\config\Smart_Transform_Suite\Smart_Transform_Suite.json
    root = _config_root_dir(create=True)
    if root is not None:
        try:
            base = root / _SETTINGS_FOLDER_NAME
            base.mkdir(parents=True, exist_ok=True)
            return base
        except Exception:
            pass
    try:
        base = _runtime.extension_user_default_storage_dir(__file__, folder_name='_user_data', create=True)
        base = Path(str(base)) / _SETTINGS_FOLDER_NAME
        base.mkdir(parents=True, exist_ok=True)
        return base
    except Exception:
        return None


def _legacy_extension_settings_dir() -> Path | None:
    try:
        base = _runtime.extension_user_default_storage_dir(__file__, folder_name='_user_data', create=False)
        return base if base is not None else None
    except Exception:
        return None


def _settings_path() -> Path | None:
    base = _settings_dir()
    if base is None:
        return None
    return base / _PRIMARY_STORE_FILE_NAME


def _settings_path_candidates() -> list[Path]:
    paths: list[Path] = []
    base = _settings_dir()
    if base is not None:
        # Current canonical store.
        paths.append(base / _PRIMARY_STORE_FILE_NAME)
        # Legacy files inside the new folder, if a previous development build wrote them.
        for name in _LEGACY_STORE_FILE_NAMES:
            cleaned = str(name or '').strip()
            if cleaned:
                path = base / cleaned
                if path not in paths:
                    paths.append(path)
    config_root = _config_root_dir(create=True)
    if config_root is not None:
        # Previous builds wrote JSON directly into .../config.  Keep reading and
        # migrate those files into .../config/Smart_Transform_Suite/.
        for name in (_PRIMARY_STORE_FILE_NAME, *_LEGACY_STORE_FILE_NAMES):
            cleaned = str(name or '').strip()
            if cleaned:
                path = config_root / cleaned
                if path not in paths:
                    paths.append(path)
    legacy_base = _legacy_extension_settings_dir()
    if legacy_base is not None:
        for name in (_PRIMARY_STORE_FILE_NAME, 'smart_transform_suite_npanel_settings.json', 'core_suite_npanel_settings.json'):
            path = legacy_base / name
            if path not in paths:
                paths.append(path)
            nested = legacy_base / _SETTINGS_FOLDER_NAME / name
            if nested not in paths:
                paths.append(nested)
    return paths


def _legacy_config_root_store_paths() -> list[Path]:
    paths: list[Path] = []
    config_root = _config_root_dir(create=True)
    if config_root is None:
        return paths
    primary = _settings_path()
    for name in (_PRIMARY_STORE_FILE_NAME, *_LEGACY_STORE_FILE_NAMES):
        cleaned = str(name or '').strip()
        if not cleaned:
            continue
        path = config_root / cleaned
        if path == primary:
            continue
        if path not in paths:
            paths.append(path)
    return paths


def _path_mtime_ns(path: Path | None) -> int | None:
    try:
        if path is not None and path.exists():
            return int(path.stat().st_mtime_ns)
    except Exception:
        pass
    return None


def _should_prefer_legacy_root_store(primary: Path | None) -> bool:
    """Use the old root-level store during first-run migration when needed.

    Some Blender 5.x registration callbacks can create a default canonical file
    before load_into_preferences() has a chance to read an older
    .../config/Smart_Transform_Suite/Smart_Transform_Suite.json.  If that canonical file was created
    during this module import, treat it as a bootstrap snapshot and let the
    existing root-level store migrate into the new dedicated folder instead.
    """
    try:
        if primary is None or not primary.exists():
            return True
        mtime = _path_mtime_ns(primary)
        if mtime is not None and mtime >= _MODULE_IMPORT_TIME_NS:
            return True
    except Exception:
        pass
    return False


def _atomic_write_text(path: Path, text: str) -> None:
    """Replace one settings file atomically in its existing directory."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    try:
        with temp.open('w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except Exception:
            pass


def _migrate_legacy_store_file(source: Path, data: dict[str, Any], context=None) -> bool:
    primary = _settings_path()
    if primary is None or source == primary or not isinstance(data, dict):
        return False
    if not _write_allowed(context):
        return False
    try:
        data = _strip_live_transform_values(data)
        json_text = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        _atomic_write_text(primary, json_text)
    except Exception as exc:
        _record_write_error('migrate_primary_commit', primary, exc)
        return False
    _clear_write_error()
    _write_preferences_mirror(json_text, context)
    removed = False
    try:
        if source.exists() and source != primary:
            source.unlink()
            removed = True
    except Exception:
        removed = False
    return removed or not source.exists()


def _resolve_preferences(context=None):
    try:
        return _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        return None


def _rna_properties(owner) -> dict[str, Any]:
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        if props is None:
            return {}
        return {str(getattr(prop, 'identifier', '') or ''): prop for prop in props if str(getattr(prop, 'identifier', '') or '')}
    except Exception:
        return {}


def _is_readonly(prop) -> bool:
    try:
        return bool(getattr(prop, 'is_readonly', False))
    except Exception:
        return False


def _prop_type(prop) -> str:
    try:
        return str(getattr(prop, 'type', '') or '')
    except Exception:
        return ''


def _fixed_type_name(prop) -> str:
    try:
        fixed = getattr(prop, 'fixed_type', None)
        return str(getattr(fixed, '__name__', '') or getattr(fixed, 'identifier', '') or '')
    except Exception:
        return ''


_INVALID_JSON_SCALAR = object()


def _json_scalar_value(value: Any):
    if value is None:
        return None
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, str):
        return str(value)
    if isinstance(value, numbers.Integral):
        return int(value)
    if isinstance(value, numbers.Real):
        return float(value)
    return _INVALID_JSON_SCALAR


def _scalar_or_array(value: Any):
    scalar = _json_scalar_value(value)
    if scalar is not _INVALID_JSON_SCALAR:
        return scalar
    try:
        iterator = iter(value)
    except Exception:
        return None
    try:
        out = []
        for item in iterator:
            scalar_item = _json_scalar_value(item)
            if scalar_item is _INVALID_JSON_SCALAR:
                return None
            out.append(scalar_item)
        return out
    except Exception:
        return None


def _resolve_setting_path(root, path: str):
    owner = root
    parts = [part.strip() for part in str(path or '').split('.') if part.strip()]
    if not parts:
        return None, ''
    for part in parts[:-1]:
        try:
            owner = getattr(owner, part)
        except Exception:
            return None, ''
        if owner is None:
            return None, ''
    return owner, parts[-1]



_ALWAYS_ON_GROUP_DEPENDENCIES = {
    'enable_smart_gizmo_live_runtime': (
        'gizmo_toggle_state',
        'enable_smart_gizmo_style',
    ),
}


def _normalize_always_on_toggle_values(values: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(values, dict):
        return {}
    out = dict(values)
    for master, deps in _ALWAYS_ON_GROUP_DEPENDENCIES.items():
        try:
            enabled = bool(out.get(master, False))
        except Exception:
            enabled = False
        if not enabled:
            continue
        for dep in deps:
            if dep in _ALWAYS_ON_TOGGLE_PROP_PATHS:
                out[dep] = True
    return out



def _sanitize_smart_gizmo_live_runtime_restore(pref_data, always_on_values) -> None:
    """Disable unsafe legacy live-runtime restore values.

    Builds before this migration could persist enable_smart_gizmo_live_runtime=True
    as a side effect of Smart Gizmo style/overlay restoration. Replaying that old
    value on install starts a window-wide modal watcher before the user explicitly
    activates the feature, which can interfere with Blender menus and ordinary UI.
    A true live runtime value is restored only after this build has recorded the
    hidden acknowledgement flag.
    """
    try:
        ack = False
        if isinstance(pref_data, dict):
            ack = ack or bool(pref_data.get('smart_gizmo_live_runtime_restore_ack_v13', False))
        if isinstance(always_on_values, dict):
            ack = ack or bool(always_on_values.get('smart_gizmo_live_runtime_restore_ack_v13', False))
        if ack:
            return
        if isinstance(pref_data, dict):
            pref_data['enable_smart_gizmo_live_runtime'] = False
            pref_data['smart_gizmo_live_runtime_restore_ack_v13'] = True
        if isinstance(always_on_values, dict):
            always_on_values['enable_smart_gizmo_live_runtime'] = False
            always_on_values['smart_gizmo_live_runtime_restore_ack_v13'] = True
    except Exception:
        pass


def _coerce_loaded_always_on_dependencies(prefs) -> None:
    if prefs is None:
        return
    for master, deps in _ALWAYS_ON_GROUP_DEPENDENCIES.items():
        owner, prop_name = _resolve_setting_path(prefs, master)
        try:
            enabled = bool(getattr(owner, prop_name)) if owner is not None and prop_name else False
        except Exception:
            enabled = False
        if not enabled:
            continue
        for dep in deps:
            dep_owner, dep_name = _resolve_setting_path(prefs, dep)
            try:
                if dep_owner is not None and dep_name and hasattr(dep_owner, dep_name):
                    if not bool(getattr(dep_owner, dep_name, False)):
                        setattr(dep_owner, dep_name, True)
            except Exception:
                pass


def _stored_scene_scalar_has(prop_name: str, context=None) -> bool:
    try:
        data = _strip_live_transform_values(_read_store(context))
    except Exception:
        data = {}
    if not isinstance(data, dict):
        return False
    scene_values = data.get('scene')
    if not isinstance(scene_values, dict):
        return False
    if any(key in scene_values for key in ('props', 'pointers', 'collection_refs')):
        props = scene_values.get('props')
        return isinstance(props, dict) and str(prop_name) in props
    return str(prop_name) in scene_values


def _apply_select_guard_runtime_pref_to_scene(context=None, prefs=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    # When Smart_Transform_Suite.json already stores the scene's visible
    # Select Guard toggle, that explicit N-panel state must win on Blender
    # restart and scene switches. The older runtime preference remains a default
    # only for stores that do not yet contain a scene-level toggle.
    if _stored_scene_scalar_has('select_guard_enabled', ctx):
        return
    prefs = prefs or _resolve_preferences(ctx)
    ssg = getattr(prefs, 'select_guard', None) if prefs is not None else None
    try:
        enabled = bool(getattr(ssg, 'pref_scene_runtime_enabled', False)) if ssg is not None else False
    except Exception:
        enabled = False
    try:
        scene = getattr(ctx, 'scene', None) if ctx is not None else getattr(bpy.context, 'scene', None)
        if scene is not None and hasattr(scene, 'select_guard_enabled'):
            # Treat the always-on preference as a default/enabler only. Do not
            # force the visible N-panel toggle OFF after the user has just turned
            # it ON but before Smart_Transform_Suite.json has finished writing.
            if enabled and not bool(getattr(scene, 'select_guard_enabled', False)):
                setattr(scene, 'select_guard_enabled', True)
    except Exception:
        pass


def _sync_loaded_runtimes(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    prefs = _resolve_preferences(ctx)
    try:
        _coerce_loaded_always_on_dependencies(prefs)
    except Exception:
        pass
    try:
        from . import integration as _integration
        if hasattr(_integration, 'apply_from_prefs'):
            _integration.apply_from_prefs(ctx)
    except Exception:
        pass
    try:
        from .core import csdt_gizmo as _csdt_gizmo
        if hasattr(_csdt_gizmo, 'sync_runtime_from_prefs'):
            _csdt_gizmo.sync_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        from .core import csdt_operators as _csdt_ops
        if hasattr(_csdt_ops, 'sync_runtime_from_prefs'):
            _csdt_ops.sync_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        _apply_select_guard_runtime_pref_to_scene(ctx, prefs)
        from . import select_guard as _select_guard
        if hasattr(_select_guard, 'sync_runtime_from_prefs'):
            _select_guard.sync_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        from . import precision_length_drag as _precision_length_drag
        if hasattr(_precision_length_drag, 'sync_runtime_from_prefs'):
            _precision_length_drag.sync_runtime_from_prefs(ctx)
    except Exception:
        pass


def _schedule_runtime_sync(context=None, delay: float = 0.05) -> None:
    global _RUNTIME_SYNC_TIMER_RUNNING, _RUNTIME_SYNC_TIMER
    if not _RUNTIME_SYNC_ADMITTED or _RUNTIME_SYNC_TIMER_RUNNING:
        return
    generation = _RUNTIME_SYNC_GENERATION
    _RUNTIME_SYNC_TIMER_RUNNING = True

    def _tick():
        global _RUNTIME_SYNC_TIMER_RUNNING, _RUNTIME_SYNC_TIMER
        if _RUNTIME_SYNC_TIMER is not _tick:
            return None
        _RUNTIME_SYNC_TIMER = None
        _RUNTIME_SYNC_TIMER_RUNNING = False
        if not _RUNTIME_SYNC_ADMITTED or generation != _RUNTIME_SYNC_GENERATION:
            return None
        try:
            _sync_loaded_runtimes(getattr(bpy, 'context', None))
        except Exception:
            pass
        return None

    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            _RUNTIME_SYNC_TIMER = _tick
            timers.register(_tick, first_interval=max(0.0, float(delay)))
            return
    except Exception:
        _RUNTIME_SYNC_TIMER = None
        _RUNTIME_SYNC_TIMER_RUNNING = False
    _RUNTIME_SYNC_TIMER = _tick
    _RUNTIME_SYNC_TIMER_RUNNING = True
    _tick()


def _flush_pending_ui_changes(context=None) -> bool:
    """Apply deferred Always-on Toggle UI operators before JSON snapshots."""
    if _RESTORING:
        return False
    flushed = False
    try:
        from . import preferences as _preferences
        fn = getattr(_preferences, 'flush_pending_always_on_changes', None)
        if callable(fn):
            flushed = bool(fn(context))
    except Exception:
        pass
    return flushed


def _always_on_toggles_snapshot(context=None) -> dict[str, Any]:
    prefs = _resolve_preferences(context)
    if prefs is None:
        return {}
    # A snapshot reads; only the returned values are normalised below.
    data: dict[str, Any] = {}
    for path in _ALWAYS_ON_TOGGLE_PROP_PATHS:
        owner, prop_name = _resolve_setting_path(prefs, path)
        if owner is None or not prop_name:
            continue
        try:
            if not hasattr(owner, prop_name):
                continue
            serial = _scalar_or_array(getattr(owner, prop_name))
            if serial is not None:
                data[path] = serial
        except Exception:
            pass
    return _normalize_always_on_toggle_values(data)


def _apply_always_on_toggles(values: Any, context=None, prefs=None) -> None:
    if not isinstance(values, dict):
        return
    prefs = prefs or _resolve_preferences(context)
    if prefs is None:
        return
    allowed = set(_ALWAYS_ON_TOGGLE_PROP_PATHS)
    normalized_values = _normalize_always_on_toggle_values(values)
    ordered_paths = list(_ALWAYS_ON_TOGGLE_PROP_PATHS)
    for path in normalized_values.keys():
        path = str(path or '').strip()
        if path not in ordered_paths:
            ordered_paths.append(path)
    for path in ordered_paths:
        path = str(path or '').strip()
        if path not in allowed or path not in normalized_values:
            continue
        value = normalized_values.get(path)
        owner, prop_name = _resolve_setting_path(prefs, path)
        if owner is None or not prop_name:
            continue
        try:
            if hasattr(owner, prop_name):
                setattr(owner, prop_name, value)
        except Exception:
            pass
    try:
        _coerce_loaded_always_on_dependencies(prefs)
    except Exception:
        pass


def save_always_on_now(context=None, *, force: bool = False) -> bool:
    """Persist the Always-on Toggles block according to the N-panel policy.

    When N-panel State Save is ON, Always-on Toggles are written to
    Smart_Transform_Suite.json immediately after the UI event, matching the
    user's requested persistent-runtime behavior.  When it is OFF, the change is
    still applied in the current session, marked dirty, and persisted by the
    current session only.  The policy toggle itself is persisted exactly once by
    persist_save_policy_change(); force/direct/shutdown paths cannot bypass OFF.
    """
    if _RESTORING:
        return False
    ctx = context or getattr(bpy, 'context', None)
    if not _write_allowed(ctx):
        mark_dirty()
        return False
    try:
        _flush_pending_ui_changes(ctx)
    except Exception:
        pass
    try:
        data = _read_store(ctx)
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    try:
        data = _strip_live_transform_values(data)
    except Exception:
        pass
    try:
        data['schema'] = max(int(data.get('schema', 5) or 5), 5)
    except Exception:
        data['schema'] = 5
    # Saving must not change the session: the snapshot below already normalises what is
    # stored, and forcing the dependencies here undid the Smart Gizmo overlay toggle.
    try:
        data['always_on_toggles'] = _always_on_toggles_snapshot(ctx)
    except Exception:
        data['always_on_toggles'] = {}
    try:
        data['feature_toggles'] = _feature_toggles_snapshot(ctx)
    except Exception:
        pass
    try:
        global _LAST_SNAPSHOT, _DIRTY_SINCE_SAVE
        if _write_store(data, ctx):
            _LAST_SNAPSHOT = data
            _DIRTY_SINCE_SAVE = False
            return True
        _DIRTY_SINCE_SAVE = True
    except Exception:
        mark_dirty()
    return False


def _snapshot_owner(owner, *, depth: int = 0) -> dict[str, Any]:
    if owner is None or depth > 4:
        return {}
    data: dict[str, Any] = {}
    for ident, prop in _rna_properties(owner).items():
        if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_'):
            continue
        ptype = _prop_type(prop)
        try:
            value = getattr(owner, ident)
        except Exception:
            continue
        if ptype == 'POINTER':
            # Pointer properties on PropertyGroup owners are usually read-only
            # as containers, but their child properties are mutable settings.
            fixed_name = _fixed_type_name(prop)
            if fixed_name in _SKIP_POINTER_TYPES:
                continue
            child = _snapshot_owner(value, depth=depth + 1)
            if child:
                data[ident] = child
            continue
        if _is_readonly(prop):
            continue
        if ptype == 'COLLECTION':
            continue
        serial = _scalar_or_array(value)
        if serial is not None:
            data[ident] = serial
    return data


def _prop_is_hidden(prop) -> bool:
    try:
        return 'HIDDEN' in set(getattr(prop, 'options', set()) or set())
    except Exception:
        return False


def _snapshot_npanel_settings_owner(owner, *, depth: int = 0) -> dict[str, Any]:
    """Snapshot visible N-panel settings from a suite PropertyGroup.

    This is intentionally broader than the old hard-coded whitelist, but it does
    not persist hidden runtime data such as temporary target names or preview JSON
    payloads.  Live transform setter fields are also skipped so opening a file or
    changing scenes cannot overwrite object/edit-mesh data saved in the .blend.
    """
    if owner is None or depth > 4:
        return {}
    data: dict[str, Any] = {}
    for ident, prop in _rna_properties(owner).items():
        if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_') or ident in _LIVE_TRANSFORM_PROP_NAMES or ident in _NPANEL_RUNTIME_PROP_NAMES:
            continue
        if _prop_is_hidden(prop):
            continue
        ptype = _prop_type(prop)
        try:
            value = getattr(owner, ident)
        except Exception:
            continue
        if ptype == 'POINTER':
            fixed_name = _fixed_type_name(prop)
            if fixed_name in _SKIP_POINTER_TYPES:
                continue
            child = _snapshot_npanel_settings_owner(value, depth=depth + 1)
            if child:
                data[ident] = child
            continue
        if _is_readonly(prop) or ptype == 'COLLECTION':
            continue
        serial = _scalar_or_array(value)
        if serial is not None:
            data[ident] = serial
    return _strip_live_transform_values(data)


def _apply_npanel_settings_owner(owner, data: dict[str, Any], *, depth: int = 0) -> None:
    if owner is None or not isinstance(data, dict) or depth > 4:
        return
    props = _rna_properties(owner)
    for ident, value in data.items():
        if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_') or ident in _LIVE_TRANSFORM_PROP_NAMES or ident in _NPANEL_RUNTIME_PROP_NAMES:
            continue
        prop = props.get(str(ident))
        if prop is None or _prop_is_hidden(prop):
            continue
        ptype = _prop_type(prop)
        if ptype == 'POINTER' and isinstance(value, dict):
            try:
                _apply_npanel_settings_owner(getattr(owner, ident), value, depth=depth + 1)
            except Exception:
                pass
            continue
        if _is_readonly(prop) or ptype == 'COLLECTION':
            continue
        try:
            if isinstance(value, list):
                current = getattr(owner, ident)
                try:
                    for idx, item in enumerate(value):
                        current[idx] = item
                except Exception:
                    setattr(owner, ident, value)
            elif isinstance(value, (str, int, float, bool)) or value is None:
                setattr(owner, ident, value)
        except Exception:
            pass



def _snapshot_named_scalar_props(owner, prop_names: tuple[str, ...]) -> dict[str, Any]:
    if owner is None:
        return {}
    data: dict[str, Any] = {}
    for prop_name in prop_names:
        try:
            if not hasattr(owner, prop_name):
                continue
            serial = _scalar_or_array(getattr(owner, prop_name))
            if serial is not None:
                data[prop_name] = serial
        except Exception:
            pass
    return data


def _snapshot_custom_or_named_props(owner, prop_names: tuple[str, ...]) -> dict[str, Any]:
    if owner is None:
        return {}
    data: dict[str, Any] = {}
    for prop_name in prop_names:
        value = None
        found = False
        # Prefer the live RNA attribute over the raw IDProperty entry. Blender may
        # expose BoolProperty values in ID storage as 0/1 integers and vector
        # values as IDPropertyArray objects; the RNA attribute preserves the
        # intended boolean/vector semantics for JSON persistence.
        try:
            if hasattr(owner, prop_name):
                value = getattr(owner, prop_name)
                found = True
        except Exception:
            found = False
        if not found:
            try:
                if hasattr(owner, 'get'):
                    raw = owner.get(prop_name, None)
                    if raw is not None:
                        value = raw
                        found = True
            except Exception:
                pass
        if not found:
            continue
        serial = _scalar_or_array(value)
        if serial is not None:
            data[prop_name] = serial
    return data


def _snapshot_collection_refs(owner, prop_names: tuple[str, ...]) -> dict[str, str]:
    if owner is None:
        return {}
    data: dict[str, str] = {}
    for prop_name in prop_names:
        try:
            target = getattr(owner, prop_name, None)
            # Store an explicit empty string as well.  Otherwise clearing a
            # previously saved collection would leave the old JSON reference in
            # effect when another .blend is opened.
            data[prop_name] = str(getattr(target, 'name', '') or '') if target is not None else ''
        except Exception:
            pass
    return data


def _scene_snapshot(context=None) -> dict[str, Any]:
    scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return {}
    data: dict[str, Any] = {}
    scalars = _snapshot_named_scalar_props(scene, _SCENE_SCALAR_PROPS)
    if scalars:
        data['props'] = scalars
    refs = _snapshot_collection_refs(scene, _SCENE_COLLECTION_REF_PROPS)
    if refs:
        data['collection_refs'] = refs
    pointer_data: dict[str, Any] = {}
    for owner_name, prop_names in _SCENE_POINTER_PROP_STORES.items():
        try:
            owner = getattr(scene, owner_name, None)
        except Exception:
            owner = None
        if prop_names is None:
            values = _snapshot_npanel_settings_owner(owner)
        else:
            values = _snapshot_custom_or_named_props(owner, prop_names)
        values = _strip_live_transform_values(values)
        if values:
            pointer_data[owner_name] = values
    if pointer_data:
        data['pointers'] = pointer_data
    return data


def _window_manager_snapshot(context=None) -> dict[str, Any]:
    wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return {}
    pointer_data: dict[str, Any] = {}
    for owner_name, prop_names in _WINDOW_MANAGER_POINTER_PROP_STORES.items():
        try:
            owner = getattr(wm, owner_name, None)
        except Exception:
            owner = None
        if prop_names is None:
            values = _snapshot_npanel_settings_owner(owner)
        else:
            values = _snapshot_named_scalar_props(owner, prop_names)
        values = _strip_live_transform_values(values)
        if values:
            pointer_data[owner_name] = values
    data: dict[str, Any] = {}
    if pointer_data:
        data['pointers'] = pointer_data
    return data


def _owner_is_suite_property_group(owner) -> bool:
    if owner is None:
        return False
    try:
        module_name = str(getattr(type(owner), '__module__', '') or '')
        root = _addon_root_id()
        return bool(
            module_name.startswith(root)
            or '.smart_transform_suite' in module_name
            or module_name.endswith('smart_transform_suite.preferences')
            or module_name.endswith('smart_transform_suite.core')
            or module_name.endswith('smart_transform_suite.select_guard')
            or module_name.endswith('smart_transform_suite.quick_align')
            or module_name.endswith('smart_transform_suite.quick_multi_edit')
        )
    except Exception:
        return False


def _n_panel_direct_prop_name_relevant(prop_name: str) -> bool:
    lower = str(prop_name or '').lower()
    if not lower or lower in {'rna_type'} or lower in _LIVE_TRANSFORM_PROP_NAMES:
        return False
    return lower.startswith(_NPANEL_DIRECT_PROP_PREFIXES)


def _snapshot_npanel_generic_owner(owner, *, depth: int = 0) -> dict[str, Any]:
    """Snapshot additional suite-owned N-panel RNA values on Scene/WindowManager.

    The explicit snapshot lists above cover known stable settings.  This generic
    pass catches newly added N-panel controls without restoring live transform
    value fields that would overwrite data saved in the .blend file.
    """
    if owner is None or depth > 3:
        return {}
    out: dict[str, Any] = {}
    for ident, prop in _rna_properties(owner).items():
        try:
            if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_') or ident in _LIVE_TRANSFORM_PROP_NAMES:
                continue
            if _is_readonly(prop) and _prop_type(prop) != 'POINTER':
                continue
            ptype = _prop_type(prop)
            if ptype == 'COLLECTION':
                continue
            if ptype == 'POINTER':
                fixed_name = _fixed_type_name(prop)
                if fixed_name in _SKIP_POINTER_TYPES:
                    continue
                try:
                    child = getattr(owner, ident, None)
                except Exception:
                    child = None
                if child is None:
                    continue
                if not (_owner_is_suite_property_group(child) or _n_panel_direct_prop_name_relevant(ident)):
                    continue
                child_data = _snapshot_owner(child, depth=depth + 1)
                if child_data:
                    out[ident] = child_data
                continue
            if not _n_panel_direct_prop_name_relevant(ident):
                continue
            try:
                serial = _scalar_or_array(getattr(owner, ident))
            except Exception:
                serial = None
            if serial is not None:
                out[ident] = serial
        except Exception:
            continue
    return _strip_live_transform_values(out)


def _apply_npanel_generic_owner(owner, data: Any, *, depth: int = 0) -> None:
    if owner is None or not isinstance(data, dict) or depth > 3:
        return
    props = _rna_properties(owner)
    for ident, value in data.items():
        try:
            if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_') or ident in _LIVE_TRANSFORM_PROP_NAMES:
                continue
            prop = props.get(str(ident))
            if prop is None:
                continue
            ptype = _prop_type(prop)
            if ptype == 'COLLECTION':
                continue
            if ptype == 'POINTER' and isinstance(value, dict):
                try:
                    child = getattr(owner, ident, None)
                except Exception:
                    child = None
                if child is not None and (_owner_is_suite_property_group(child) or _n_panel_direct_prop_name_relevant(ident)):
                    _apply_owner(child, value, depth=depth + 1)
                continue
            if _is_readonly(prop):
                continue
            if not _n_panel_direct_prop_name_relevant(ident):
                continue
            if isinstance(value, list):
                current = getattr(owner, ident)
                try:
                    for idx, item in enumerate(value):
                        current[idx] = item
                except Exception:
                    setattr(owner, ident, value)
            elif isinstance(value, (str, int, float, bool)) or value is None:
                setattr(owner, ident, value)
        except Exception:
            pass

def _feature_toggles_snapshot(context=None) -> dict[str, Any]:
    try:
        from . import feature_toggle as _feature_toggle
        exporter = getattr(_feature_toggle, 'export_persistent_state', None)
        if callable(exporter):
            data = exporter(context)
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    try:
        prefs = _resolve_preferences(context)
        raw = getattr(prefs, _FEATURE_TOGGLE_MIRROR_PROP, '') if prefs is not None else ''
        parsed = json.loads(str(raw or '{}'))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _apply_feature_toggles(values: Any, context=None) -> None:
    if not isinstance(values, dict):
        return
    try:
        from . import feature_toggle as _feature_toggle
        importer = getattr(_feature_toggle, 'import_persistent_state', None)
        if callable(importer):
            importer(values, context=context, apply_runtime=True)
            return
    except Exception:
        pass
    try:
        prefs = _resolve_preferences(context)
        if prefs is not None and hasattr(prefs, _FEATURE_TOGGLE_MIRROR_PROP):
            setattr(prefs, _FEATURE_TOGGLE_MIRROR_PROP, json.dumps(values, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception:
        pass


def snapshot(context=None) -> dict[str, Any]:
    prefs = _resolve_preferences(context)
    return {
        'schema': 5,
        'addon_preferences': _snapshot_owner(prefs),
        'always_on_toggles': _always_on_toggles_snapshot(context),
        'scene': _scene_snapshot(context),
        'window_manager': _window_manager_snapshot(context),
        'feature_toggles': _feature_toggles_snapshot(context),
    }

def _parse_store_text(text: str | None) -> dict[str, Any]:
    if not text:
        return {}
    try:
        raw = json.loads(str(text))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _read_preferences_mirror(context=None) -> dict[str, Any]:
    prefs = _resolve_preferences(context)
    if prefs is None:
        return {}
    try:
        return _parse_store_text(getattr(prefs, _PREF_MIRROR_PROP, ''))
    except Exception:
        return {}


def _write_preferences_mirror(json_text: str, context=None) -> bool:
    prefs = _resolve_preferences(context)
    if prefs is None or not hasattr(prefs, _PREF_MIRROR_PROP):
        return False
    try:
        if getattr(prefs, _PREF_MIRROR_PROP, '') != json_text:
            setattr(prefs, _PREF_MIRROR_PROP, json_text)
        return True
    except Exception as exc:
        _record_write_error('preferences_mirror', _PREF_MIRROR_PROP, exc)
        return False




def _sanitize_loaded_store(data: dict[str, Any]) -> dict[str, Any]:
    """Remove unsafe development-time generic RNA snapshots before use.

    fixed37 wrote broad Scene/WindowManager ``generic`` blocks so that every new
    N-panel property would be captured automatically.  In real user configs those
    blocks can contain volatile/runtime RNA and make install/startup appear to
    freeze while Blender rebuilds the UI.  Current builds persist only explicit
    suite-owned PropertyGroups and ignore/remove the generic blocks on load.
    """
    if not isinstance(data, dict):
        return {}
    try:
        scene = data.get('scene')
        if isinstance(scene, dict) and 'generic' in scene:
            scene = dict(scene)
            scene.pop('generic', None)
            data = dict(data)
            data['scene'] = scene
    except Exception:
        pass
    try:
        wm = data.get('window_manager')
        if isinstance(wm, dict) and 'generic' in wm:
            wm = dict(wm)
            wm.pop('generic', None)
            data = dict(data)
            data['window_manager'] = wm
    except Exception:
        pass
    try:
        prefs = data.get('addon_preferences')
        if isinstance(prefs, dict) and 'interaction_profile' in prefs:
            prefs = dict(prefs)
            prefs.pop('interaction_profile', None)
            data = dict(data)
            data['addon_preferences'] = prefs
    except Exception:
        pass
    return data



def _rewrite_sanitized_store_file(path: Path | None, data: dict[str, Any], context=None) -> bool:
    """Write a sanitized store directly without recursively calling _read_store."""
    if path is None or not isinstance(data, dict) or not _write_allowed(context):
        return False
    try:
        clean = _strip_live_transform_values(_sanitize_loaded_store(data))
        json_text = json.dumps(clean, ensure_ascii=False, indent=2, sort_keys=True)
        _atomic_write_text(path, json_text)
    except Exception as exc:
        _record_write_error('sanitize_primary_commit', path, exc)
        return False
    _clear_write_error()
    # A sanitized legacy source is not the canonical transaction.  Mirroring it
    # before migration would expose new state even if the subsequent primary
    # commit failed.
    if path == _settings_path():
        _write_preferences_mirror(json_text, context)
    return True

def _read_store(context=None) -> dict[str, Any]:
    primary = _settings_path()
    if _should_prefer_legacy_root_store(primary):
        for path in _legacy_config_root_store_paths():
            if path.exists():
                try:
                    raw_data = _parse_store_text(path.read_text(encoding='utf-8'))
                    data = _sanitize_loaded_store(raw_data)
                    if data:
                        if data != raw_data:
                            _rewrite_sanitized_store_file(path, data, context)
                        migrated = _migrate_legacy_store_file(path, data, context)
                        if migrated and path.exists():
                            try:
                                path.unlink()
                            except Exception:
                                pass
                        return data
                except Exception:
                    pass
    for path in _settings_path_candidates():
        if path.exists():
            try:
                raw_data = _parse_store_text(path.read_text(encoding='utf-8'))
                data = _sanitize_loaded_store(raw_data)
                if data:
                    if data != raw_data:
                        _rewrite_sanitized_store_file(path, data, context)
                    _migrate_legacy_store_file(path, data, context)
                    return data
            except Exception:
                pass
    raw_data = _read_preferences_mirror(context)
    data = _sanitize_loaded_store(raw_data)
    if data != raw_data:
        try:
            _write_preferences_mirror(json.dumps(_strip_live_transform_values(data), ensure_ascii=False, indent=2, sort_keys=True), context)
        except Exception:
            pass
    return data


def _write_store(data: dict[str, Any], context=None) -> bool:
    if not _write_allowed(context):
        return False
    try:
        data = _sanitize_loaded_store(data)
        data = _strip_live_transform_values(data)
        json_text = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception as exc:
        _record_write_error('serialize', _settings_path(), exc)
        return False
    primary = _settings_path()
    if primary is None:
        _record_write_error('resolve_primary', '', 'settings path unavailable')
        return False
    try:
        _atomic_write_text(primary, json_text)
    except Exception as exc:
        _record_write_error('primary_commit', primary, exc)
        return False
    _clear_write_error()
    # The canonical file is the transaction boundary. Secondary cleanup and
    # the mirror never run after a denied or failed primary commit.
    for legacy_path in _settings_path_candidates()[1:]:
        try:
            if legacy_path.exists():
                legacy_path.unlink()
        except Exception:
            pass
    _write_preferences_mirror(json_text, context)
    return True


def _apply_owner(owner, data: dict[str, Any], *, depth: int = 0) -> None:
    if owner is None or not isinstance(data, dict) or depth > 4:
        return
    props = _rna_properties(owner)
    for ident, value in data.items():
        if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_'):
            continue
        prop = props.get(str(ident))
        if prop is None:
            continue
        ptype = _prop_type(prop)
        if ptype == 'POINTER' and isinstance(value, dict):
            try:
                _apply_owner(getattr(owner, ident), value, depth=depth + 1)
            except Exception:
                pass
            continue
        if _is_readonly(prop):
            continue
        if ptype == 'COLLECTION':
            continue
        try:
            if isinstance(value, list):
                current = getattr(owner, ident)
                try:
                    for idx, item in enumerate(value):
                        current[idx] = item
                except Exception:
                    setattr(owner, ident, value)
            elif isinstance(value, (str, int, float, bool)) or value is None:
                setattr(owner, ident, value)
        except Exception:
            pass



def _apply_named_scalar_props(owner, values: dict[str, Any], prop_names: tuple[str, ...]) -> None:
    if owner is None or not isinstance(values, dict):
        return
    allowed = set(prop_names)
    for prop_name, value in values.items():
        if prop_name in _LIVE_TRANSFORM_PROP_NAMES:
            continue
        if prop_name not in allowed:
            continue
        try:
            if hasattr(owner, prop_name):
                setattr(owner, prop_name, value)
        except Exception:
            pass


def _apply_custom_or_named_props(owner, values: dict[str, Any], prop_names: tuple[str, ...]) -> None:
    if owner is None or not isinstance(values, dict):
        return
    allowed = set(prop_names)
    for prop_name, value in values.items():
        if prop_name in _LIVE_TRANSFORM_PROP_NAMES:
            continue
        if prop_name not in allowed:
            continue
        applied = False
        try:
            if hasattr(owner, prop_name):
                setattr(owner, prop_name, value)
                applied = True
        except Exception:
            applied = False
        if not applied:
            try:
                owner[prop_name] = value
            except Exception:
                pass


def _apply_collection_refs(owner, values: dict[str, str], prop_names: tuple[str, ...]) -> None:
    if owner is None or not isinstance(values, dict):
        return
    allowed = set(prop_names)
    for prop_name, collection_name in values.items():
        if prop_name not in allowed:
            continue
        name = str(collection_name or '').strip()
        try:
            if not hasattr(owner, prop_name):
                continue
            if not name:
                setattr(owner, prop_name, None)
                continue
            collections = getattr(getattr(bpy, 'data', None), 'collections', None)
            target = collections.get(name) if collections is not None else None
            # If the stored collection does not exist in the newly opened file,
            # clear the pointer instead of retaining an unrelated .blend value.
            setattr(owner, prop_name, target if target is not None else None)
        except Exception:
            pass


def _restore_cursor_lock_if_needed(context=None) -> None:
    try:
        from . import cursor_lock as _cursor_lock
    except Exception:
        return
    try:
        _cursor_lock.restore_context_scene(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def apply_saved_scene_values(context=None) -> None:
    """Apply persisted Scene and WindowManager N-panel state after registration/file load."""
    data = _strip_live_transform_values(_read_store(context))
    if not isinstance(data, dict):
        return
    ctx = context or getattr(bpy, 'context', None)
    pref_values = data.get('addon_preferences')
    scene_values = data.get('scene')
    wm_values = data.get('window_manager')
    always_on_values = data.get('always_on_toggles')
    feature_values = data.get('feature_toggles')
    _sanitize_smart_gizmo_live_runtime_restore(pref_values if isinstance(pref_values, dict) else None, always_on_values)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    prefs = _resolve_preferences(ctx)
    global _RESTORING, _LAST_SCENE_ID, _LAST_SNAPSHOT, _STARTUP_RESTORE_PENDING, _FILE_LOAD_RESTORE_PENDING, _USER_SCENE_EDIT_DURING_STARTUP_RESTORE
    old = _RESTORING
    _RESTORING = True
    try:
        # The editable N-panel preferences live on WindowManager rather than in
        # AddonPreferences.  A .blend load can recreate that PropertyGroup with
        # defaults, so restore the complete preferences tree on every load, not
        # only during add-on registration.  This includes all Smart Gizmo, Smart
        # G-R-S, foldout, sensitivity, color, and integrated-tool settings.
        skip_pref_restore = False
        try:
            skip_pref_restore = bool(
                _STARTUP_RESTORE_PENDING
                and not _FILE_LOAD_RESTORE_PENDING
                and _USER_SCENE_EDIT_DURING_STARTUP_RESTORE
            )
        except Exception:
            skip_pref_restore = False
        if not skip_pref_restore and prefs is not None and isinstance(pref_values, dict):
            _apply_owner(prefs, _strip_live_transform_values(pref_values))
            _force_legacy_module_enable_flags(prefs)

        if scene is not None and isinstance(scene_values, dict):
            # Schema 1 stored scene values directly; schema 2 stores typed groups.
            if any(key in scene_values for key in ('props', 'pointers', 'collection_refs')):
                scalar_values = scene_values.get('props') if isinstance(scene_values.get('props'), dict) else {}
                pointer_values = scene_values.get('pointers') if isinstance(scene_values.get('pointers'), dict) else {}
                collection_values = scene_values.get('collection_refs') if isinstance(scene_values.get('collection_refs'), dict) else {}
            else:
                scalar_values = scene_values
                pointer_values = {}
                collection_values = {}
            skip_scene_restore = False
            try:
                skip_scene_restore = bool(_STARTUP_RESTORE_PENDING and _USER_SCENE_EDIT_DURING_STARTUP_RESTORE)
            except Exception:
                skip_scene_restore = False
            if not skip_scene_restore:
                _apply_named_scalar_props(scene, scalar_values, _SCENE_SCALAR_PROPS)
                _apply_collection_refs(scene, collection_values, _SCENE_COLLECTION_REF_PROPS)
                if isinstance(pointer_values, dict):
                    for owner_name, prop_names in _SCENE_POINTER_PROP_STORES.items():
                        values = pointer_values.get(owner_name)
                        if isinstance(values, dict):
                            try:
                                owner = getattr(scene, owner_name, None)
                            except Exception:
                                owner = None
                            if prop_names is None:
                                _apply_npanel_settings_owner(owner, _strip_live_transform_values(values))
                            else:
                                _apply_custom_or_named_props(owner, values, prop_names)
            try:
                _LAST_SCENE_ID = id(scene)
            except Exception:
                _LAST_SCENE_ID = None

        if wm is not None and isinstance(wm_values, dict):
            pointer_values = wm_values.get('pointers') if isinstance(wm_values.get('pointers'), dict) else {}
            for owner_name, prop_names in _WINDOW_MANAGER_POINTER_PROP_STORES.items():
                values = pointer_values.get(owner_name)
                if isinstance(values, dict):
                    try:
                        owner = getattr(wm, owner_name, None)
                    except Exception:
                        owner = None
                    if prop_names is None:
                        _apply_npanel_settings_owner(owner, _strip_live_transform_values(values))
                    else:
                        _apply_named_scalar_props(owner, values, prop_names)
        _apply_always_on_toggles(always_on_values, ctx)
        _apply_feature_toggles(feature_values, ctx)
    finally:
        _RESTORING = old
        _STARTUP_RESTORE_PENDING = False
        _FILE_LOAD_RESTORE_PENDING = False
        _USER_SCENE_EDIT_DURING_STARTUP_RESTORE = False
    try:
        _restore_cursor_lock_if_needed(ctx)
    except Exception:
        pass
    try:
        prefs_now = _resolve_preferences(ctx)
        _coerce_loaded_always_on_dependencies(prefs_now)
        _apply_select_guard_runtime_pref_to_scene(ctx, prefs_now)
    except Exception:
        pass
    try:
        _LAST_SNAPSHOT = snapshot(ctx)
    except Exception:
        _LAST_SNAPSHOT = None
    try:
        _schedule_runtime_sync(ctx, delay=0.05)
    except Exception:
        pass

def _force_legacy_module_enable_flags(prefs) -> None:
    if prefs is None:
        return
    for ident in _LEGACY_MODULE_ENABLE_FLAGS:
        try:
            if hasattr(prefs, ident):
                setattr(prefs, ident, True)
        except Exception:
            pass


def load_into_preferences(prefs=None, context=None) -> bool:
    data = _strip_live_transform_values(_read_store(context))
    pref_data = data.get('addon_preferences') if isinstance(data, dict) else None
    always_on_values = data.get('always_on_toggles') if isinstance(data, dict) else None
    _sanitize_smart_gizmo_live_runtime_restore(pref_data, always_on_values)
    if not isinstance(pref_data, dict) and not isinstance(always_on_values, dict):
        return False
    prefs = prefs or _resolve_preferences(context)
    if prefs is None:
        return False
    global _RESTORING, _LAST_SNAPSHOT
    old = _RESTORING
    _RESTORING = True
    try:
        if isinstance(pref_data, dict):
            _apply_owner(prefs, pref_data)
        if isinstance(always_on_values, dict):
            # Dedicated always-on block is authoritative and scene-independent.
            # Apply after the generic preferences snapshot so older mirrored
            # values cannot overwrite the current external JSON state.
            _apply_always_on_toggles(always_on_values, context, prefs=prefs)
        _coerce_loaded_always_on_dependencies(prefs)
        _force_legacy_module_enable_flags(prefs)
    finally:
        _RESTORING = old
    # Scene and WindowManager values are restored by a deferred load/start hook.
    # Do not apply them here while registration is still building panels and RNA.
    # Do not force-write here: integrated N-panel modules may not be registered yet.
    # The register sequence applies scene/window-manager values after integration,
    # then start() writes a complete snapshot and mirrors it into saved preferences.
    _LAST_SNAPSHOT = None
    try:
        _schedule_runtime_sync(context, delay=0.10)
    except Exception:
        pass
    return True



def _restore_scene_if_context_changed(context=None) -> bool:
    """Reapply persisted scene N-panel values before saving a newly switched scene.

    Newly created/switched scenes have default RNA values.  Their update
    callbacks can queue an autosave before the periodic scene-change restore
    tick runs; without this guard, the default values overwrite
    Smart_Transform_Suite.json.  Restoring first keeps scene switches
    authoritative to the saved N-panel state.
    """
    global _LAST_SCENE_ID
    if _RESTORING:
        return False
    ctx = context or getattr(bpy, 'context', None)
    try:
        scene = getattr(ctx, 'scene', None)
        scene_id = id(scene) if scene is not None else None
    except Exception:
        scene = None
        scene_id = None
    if scene_id is None:
        return False
    if _LAST_SCENE_ID is None:
        _LAST_SCENE_ID = scene_id
        return False
    if scene_id == _LAST_SCENE_ID:
        return False
    try:
        data = _read_store(ctx)
    except Exception:
        data = {}
    try:
        if not isinstance(data, dict) or not isinstance(data.get('scene'), dict):
            _LAST_SCENE_ID = scene_id
            return False
        apply_saved_scene_values(ctx)
        _LAST_SCENE_ID = scene_id
        return True
    except Exception:
        try:
            _LAST_SCENE_ID = scene_id
        except Exception:
            pass
        return False


def save_now(context=None, *, force: bool = False, bypass_policy: bool = False) -> bool:
    global _LAST_SNAPSHOT, _DIRTY_SINCE_SAVE
    if _RESTORING:
        return False
    if _startup_restore_pending_has_store(context):
        _DIRTY_SINCE_SAVE = True
        return False
    try:
        if _restore_scene_if_context_changed(context):
            force = True
    except Exception:
        pass
    if _flush_pending_ui_changes(context):
        force = True
    # ``bypass_policy`` remains accepted for old callers, but it intentionally
    # cannot bypass Save OFF.  Only persist_save_policy_change() owns the one
    # scoped write that records the policy toggle itself.
    del bypass_policy
    if not _write_allowed(context):
        _DIRTY_SINCE_SAVE = True
        return False
    data = snapshot(context)
    if force or data != _LAST_SNAPSHOT or _DIRTY_SINCE_SAVE:
        if not _write_store(data, context):
            _DIRTY_SINCE_SAVE = True
            return False
        _LAST_SNAPSHOT = data
        _DIRTY_SINCE_SAVE = False
    return True


def persist_save_policy_change(context=None) -> None:
    """Persist Save ON/OFF exactly once, then restore the normal write policy."""
    global _POLICY_TOGGLE_WRITE_DEPTH
    if _RESTORING:
        return
    _POLICY_TOGGLE_WRITE_DEPTH += 1
    try:
        save_now(context, force=True)
    finally:
        _POLICY_TOGGLE_WRITE_DEPTH = max(0, _POLICY_TOGGLE_WRITE_DEPTH - 1)



def _deferred_request_save_tick():
    """Run queued preference persistence outside the active UI event handler."""
    global _SAVE_PENDING
    if _startup_restore_pending_has_store(getattr(bpy, 'context', None)):
        _SAVE_PENDING = True
        try:
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None:
                timers.register(_deferred_request_save_tick, first_interval=0.05)
                return None
        except Exception:
            pass
        return None
    _SAVE_PENDING = False
    if not _TIMER_RUNNING:
        return None
    try:
        save_now(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    return None


def request_save(reason: str = 'settings_update', context=None) -> None:
    """Queue N-panel settings persistence for the next safe timer tick.

    Saving used to snapshot Add-on Preferences, Scene, and WindowManager RNA
    synchronously from property update callbacks.  Blender 5.x can enter those
    callbacks while a Sidebar panel event is still being handled; touching large
    RNA trees at that point can leave the native panel handler with stale state.
    Queue the snapshot instead so it runs after the current UI event has exited.
    """
    del reason
    if _RESTORING:
        return
    global _SAVE_PENDING, _DIRTY_SINCE_SAVE
    if not is_npanel_state_save_enabled(context):
        _DIRTY_SINCE_SAVE = True
        return
    if _SAVE_PENDING:
        return
    _SAVE_PENDING = True
    try:
        _initialize_userpref_mtime()
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_deferred_request_save_tick, first_interval=0.01)
            return
    except Exception:
        pass
    # Non-UI fallback, mainly for headless tests where bpy.app.timers may be
    # unavailable.  In Blender UI sessions the timer path above is used.
    try:
        _deferred_request_save_tick()
    except Exception:
        pass



@persistent
def _save_settings_on_save_pre(_dummy=None):
    """Persist during .blend save only while continuous N-panel saving is enabled."""
    try:
        ctx = getattr(bpy, 'context', None)
        if is_npanel_state_save_enabled(ctx):
            save_now(ctx, force=True)
    except Exception:
        pass


@persistent
def _save_settings_on_load_pre(_dummy=None):
    """Persist pending settings and protect them during the next .blend load."""
    global _FILE_LOAD_RESTORE_PENDING, _USER_SCENE_EDIT_DURING_STARTUP_RESTORE
    try:
        save_now(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    # From this point until deferred load_post restoration, the newly loaded
    # WindowManager/Scene values are provisional defaults and must never be
    # written back over Smart_Transform_Suite.json.
    _FILE_LOAD_RESTORE_PENDING = True
    _USER_SCENE_EDIT_DURING_STARTUP_RESTORE = False


@persistent
def _save_settings_on_exit_pre(_dummy=None):
    """Persist pending settings before Blender exits."""
    try:
        save_now(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass


def _userpref_path() -> Path | None:
    base = _config_root_dir(create=False)
    if base is None:
        return None
    return base / 'userpref.blend'


def _initialize_userpref_mtime() -> None:
    global _USERPREF_MTIME_NS
    try:
        path = _userpref_path()
        if path is not None and path.exists():
            _USERPREF_MTIME_NS = int(path.stat().st_mtime_ns)
    except Exception:
        _USERPREF_MTIME_NS = None


def _userpref_save_watch_once() -> None:
    """Check the userpref timestamp once without owning a periodic timer."""
    global _USERPREF_MTIME_NS
    try:
        path = _userpref_path()
        if path is not None and path.exists():
            mtime = int(path.stat().st_mtime_ns)
            if _USERPREF_MTIME_NS is None:
                _USERPREF_MTIME_NS = mtime
                if _DIRTY_SINCE_SAVE:
                    save_now(getattr(bpy, 'context', None), force=True)
            elif mtime != _USERPREF_MTIME_NS:
                _USERPREF_MTIME_NS = mtime
                save_now(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass


def _userpref_save_watch_tick():
    """Compatibility terminator for the separate 1 Hz watcher in older builds."""
    if _TIMER_RUNNING:
        _userpref_save_watch_once()
    return None


def _deferred_load_post_apply_tick():
    try:
        ctx = getattr(bpy, 'context', None)
        if _startup_restore_pending_has_store(ctx):
            apply_saved_scene_values(ctx)
        sync_change_subscriptions_for_policy(ctx)
    except Exception:
        pass
    return None


@persistent
def _apply_saved_settings_on_load_post(_dummy=None):
    """Restore every persisted N-panel value after file-load UI settles.

    Blender 5.1 recreates the hidden WindowManager preferences group while
    opening a .blend, so Smart Gizmo and other N-panel settings must be restored
    together with Scene/WindowManager settings after every load.
    """
    global _FILE_LOAD_RESTORE_PENDING
    _FILE_LOAD_RESTORE_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_deferred_load_post_apply_tick, first_interval=0.20)
            return
    except Exception:
        pass
    try:
        _deferred_load_post_apply_tick()
    except Exception:
        pass


def _autosave_tick():
    """Compatibility terminator: 1.8.250 uses change events, never polling."""
    return None


def _on_owned_setting_changed() -> None:
    request_save('rna_change_event', context=getattr(bpy, 'context', None))


def _iter_suite_setting_owners(owner, *, depth: int = 0):
    """Yield suite-owned PropertyGroups reached through persisted pointers."""
    if owner is None or depth > 4:
        return
    yield owner
    for ident, prop in _rna_properties(owner).items():
        if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_'):
            continue
        if _prop_type(prop) != 'POINTER' or _fixed_type_name(prop) in _SKIP_POINTER_TYPES:
            continue
        try:
            child = getattr(owner, ident, None)
        except Exception:
            child = None
        if child is not None and _owner_is_suite_property_group(child):
            yield from _iter_suite_setting_owners(child, depth=depth + 1)


def _iter_change_subscription_targets(context=None):
    """Yield only exact RNA fields represented by the persistent snapshot."""
    ctx = context or getattr(bpy, 'context', None)
    seen: set[tuple[int, str]] = set()

    def emit(owner, ident):
        ident = str(ident or '')
        marker = (id(owner), ident)
        if owner is None or not ident or marker in seen:
            return None
        prop = _rna_properties(owner).get(ident)
        if prop is None or _is_readonly(prop):
            return None
        seen.add(marker)
        return owner, ident

    prefs = _resolve_preferences(ctx)
    for owner in _iter_suite_setting_owners(prefs):
        for ident, prop in _rna_properties(owner).items():
            if ident in _SKIP_PREF_PROPS or ident in _LEGACY_MODULE_ENABLE_FLAGS or ident.startswith('bl_'):
                continue
            if ident in _LIVE_TRANSFORM_PROP_NAMES or ident in _NPANEL_RUNTIME_PROP_NAMES:
                continue
            if _prop_type(prop) in {'POINTER', 'COLLECTION'}:
                continue
            target = emit(owner, ident)
            if target is not None:
                yield target

    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    for ident in (*_SCENE_SCALAR_PROPS, *_SCENE_COLLECTION_REF_PROPS):
        target = emit(scene, ident)
        if target is not None:
            yield target
    for pointer_name, prop_names in _SCENE_POINTER_PROP_STORES.items():
        child = getattr(scene, pointer_name, None) if scene is not None else None
        for owner in _iter_suite_setting_owners(child):
            for ident, prop in _rna_properties(owner).items():
                if prop_names is not None and ident not in prop_names:
                    continue
                if ident in _SKIP_PREF_PROPS or ident in _LIVE_TRANSFORM_PROP_NAMES or ident in _NPANEL_RUNTIME_PROP_NAMES:
                    continue
                if _prop_type(prop) in {'POINTER', 'COLLECTION'} or _prop_is_hidden(prop):
                    continue
                target = emit(owner, ident)
                if target is not None:
                    yield target

    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    for pointer_name, prop_names in _WINDOW_MANAGER_POINTER_PROP_STORES.items():
        child = getattr(wm, pointer_name, None) if wm is not None else None
        for owner in _iter_suite_setting_owners(child):
            for ident, prop in _rna_properties(owner).items():
                if prop_names is not None and ident not in prop_names:
                    continue
                if ident in _SKIP_PREF_PROPS or ident in _LIVE_TRANSFORM_PROP_NAMES or ident in _NPANEL_RUNTIME_PROP_NAMES:
                    continue
                if _prop_type(prop) in {'POINTER', 'COLLECTION'} or _prop_is_hidden(prop):
                    continue
                target = emit(owner, ident)
                if target is not None:
                    yield target

    # This suite-owned WindowManager collection is exported into the
    # feature_toggles block. Subscribe to its exact member field, never to
    # unrelated WindowManager RNA.
    collection = getattr(wm, _FEATURE_TOGGLE_COLLECTION_PROP, None) if wm is not None else None
    if collection is not None:
        target = emit(wm, _FEATURE_TOGGLE_COLLECTION_PROP)
        if target is not None:
            yield target
        for item in collection:
            for ident in _FEATURE_TOGGLE_ITEM_PROPS:
                target = emit(item, ident)
                if target is not None:
                    yield target


def _rna_msgbus_key(owner, ident: str):
    """Build Blender's supported instance-specific RNA property key."""
    try:
        return owner.path_resolve(str(ident), False)
    except Exception:
        return (type(owner), str(ident))


def _install_change_subscriptions(context=None) -> None:
    """Subscribe once to concrete suite-owned settings; no periodic scanner."""
    global _CHANGE_SUBSCRIPTIONS_INSTALLED
    _remove_change_subscriptions()
    if not is_npanel_state_save_enabled(context):
        return
    msgbus = getattr(bpy, 'msgbus', None)
    if msgbus is None:
        return
    subscribed = 0
    for owner, ident in _iter_change_subscription_targets(context):
        try:
            msgbus.subscribe_rna(
                key=_rna_msgbus_key(owner, ident),
                owner=_CHANGE_MSGBUS_OWNER,
                args=(),
                notify=_on_owned_setting_changed,
            )
            subscribed += 1
        except Exception:
            pass
    _CHANGE_SUBSCRIPTIONS_INSTALLED = bool(subscribed)


def _remove_change_subscriptions() -> None:
    global _CHANGE_SUBSCRIPTIONS_INSTALLED
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None:
            msgbus.clear_by_owner(_CHANGE_MSGBUS_OWNER)
    except Exception:
        pass
    _CHANGE_SUBSCRIPTIONS_INSTALLED = False


def sync_change_subscriptions_for_policy(context=None) -> None:
    if is_npanel_state_save_enabled(context):
        _install_change_subscriptions(context)
    else:
        _remove_change_subscriptions()


def start(context=None) -> None:
    """Start persistent N-panel settings support.

    The JSON store is kept in Blender's user config directory as
    Smart_Transform_Suite/Smart_Transform_Suite.json, mirrored into hidden runtime strings, and refreshed by finite RNA change events
    so properties without explicit update callbacks are still retained.
    """
    global _TIMER_RUNNING, _LAST_SNAPSHOT, _LAST_SCENE_ID, _STARTUP_RESTORE_PENDING, _FILE_LOAD_RESTORE_PENDING, _USER_SCENE_EDIT_DURING_STARTUP_RESTORE
    global _RUNTIME_SYNC_TIMER_RUNNING, _RUNTIME_SYNC_TIMER, _RUNTIME_SYNC_GENERATION, _RUNTIME_SYNC_ADMITTED
    pending_runtime_sync = _RUNTIME_SYNC_TIMER
    _RUNTIME_SYNC_GENERATION += 1
    _RUNTIME_SYNC_ADMITTED = True
    _RUNTIME_SYNC_TIMER = None
    _RUNTIME_SYNC_TIMER_RUNNING = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if pending_runtime_sync is not None and timers is not None and hasattr(timers, 'is_registered'):
            if timers.is_registered(pending_runtime_sync):
                timers.unregister(pending_runtime_sync)
    except Exception:
        pass
    _TIMER_RUNNING = True
    try:
        _LAST_SNAPSHOT = snapshot(context)
    except Exception:
        _LAST_SNAPSHOT = None
    try:
        scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
        _LAST_SCENE_ID = id(scene) if scene is not None else None
    except Exception:
        _LAST_SCENE_ID = None
    try:
        preexisting_store_file = _preexisting_store_file_available()
    except Exception:
        preexisting_store_file = False
    try:
        existing_store = _read_store(context or getattr(bpy, 'context', None))
    except Exception:
        existing_store = {}
    # Do not write a startup snapshot over an existing Smart_Transform_Suite.json
    # before the deferred scene restore has applied.  A file created by property
    # update callbacks during the current registration pass is not considered
    # preexisting, so fresh installs can still save immediately.
    _STARTUP_RESTORE_PENDING = bool(preexisting_store_file and isinstance(existing_store, dict) and existing_store)
    _FILE_LOAD_RESTORE_PENDING = False
    _USER_SCENE_EDIT_DURING_STARTUP_RESTORE = False
    if not isinstance(existing_store, dict) or not existing_store:
        try:
            request_save('settings_start', context=context or getattr(bpy, 'context', None))
        except Exception:
            pass
    try:
        _schedule_runtime_sync(context or getattr(bpy, 'context', None), delay=0.15)
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_pre = getattr(handlers, 'load_pre', None) if handlers is not None else None
        if load_pre is not None and _save_settings_on_load_pre not in load_pre:
            load_pre.append(_save_settings_on_load_pre)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        if load_post is not None and _apply_saved_settings_on_load_post not in load_post:
            load_post.append(_apply_saved_settings_on_load_post)
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if save_pre is not None and _save_settings_on_save_pre not in save_pre:
            save_pre.append(_save_settings_on_save_pre)
        exit_pre = getattr(handlers, 'exit_pre', None) if handlers is not None else None
        if exit_pre is not None and _save_settings_on_exit_pre not in exit_pre:
            exit_pre.append(_save_settings_on_exit_pre)
    except Exception:
        pass
    try:
        _initialize_userpref_mtime()
    except Exception:
        pass
    sync_change_subscriptions_for_policy(context or getattr(bpy, 'context', None))


def stop(context=None) -> None:
    global _TIMER_RUNNING, _SAVE_PENDING, _STARTUP_RESTORE_PENDING, _FILE_LOAD_RESTORE_PENDING
    global _RUNTIME_SYNC_TIMER_RUNNING, _RUNTIME_SYNC_TIMER, _RUNTIME_SYNC_GENERATION, _RUNTIME_SYNC_ADMITTED
    pending_runtime_sync = _RUNTIME_SYNC_TIMER
    _RUNTIME_SYNC_ADMITTED = False
    _RUNTIME_SYNC_GENERATION += 1
    _RUNTIME_SYNC_TIMER = None
    _RUNTIME_SYNC_TIMER_RUNNING = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if pending_runtime_sync is not None and timers is not None and hasattr(timers, 'is_registered'):
            if timers.is_registered(pending_runtime_sync):
                timers.unregister(pending_runtime_sync)
    except Exception:
        pass
    try:
        save_now(context or getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    _TIMER_RUNNING = False
    _SAVE_PENDING = False
    _STARTUP_RESTORE_PENDING = False
    _FILE_LOAD_RESTORE_PENDING = False
    _remove_change_subscriptions()
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered'):
            if timers.is_registered(_deferred_request_save_tick):
                try:
                    timers.unregister(_deferred_request_save_tick)
                except Exception:
                    pass
            if timers.is_registered(_autosave_tick):
                timers.unregister(_autosave_tick)
            if timers.is_registered(_userpref_save_watch_tick):
                timers.unregister(_userpref_save_watch_tick)
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_pre = getattr(handlers, 'load_pre', None) if handlers is not None else None
        if load_pre is not None and _save_settings_on_load_pre in load_pre:
            load_pre.remove(_save_settings_on_load_pre)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        if load_post is not None and _apply_saved_settings_on_load_post in load_post:
            load_post.remove(_apply_saved_settings_on_load_post)
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if save_pre is not None and _save_settings_on_save_pre in save_pre:
            save_pre.remove(_save_settings_on_save_pre)
        exit_pre = getattr(handlers, 'exit_pre', None) if handlers is not None else None
        if exit_pre is not None and _save_settings_on_exit_pre in exit_pre:
            exit_pre.remove(_save_settings_on_exit_pre)
    except Exception:
        pass
