# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from . import core_runtime as _core_runtime


def extension_id(module_file: str | None = None) -> str:
    return _core_runtime.extension_id(module_file)


def addon_root_candidates(package_name: str | None = None, module_name: str | None = None, fallback_leaf: str = 'core_suite', module_file: str | None = None) -> tuple[str, ...]:
    candidates = list(_core_runtime.addon_candidate_keys(package_name, module_name, module_file))
    if fallback_leaf and fallback_leaf not in candidates:
        candidates.append(fallback_leaf)
    return tuple(candidates)


def addon_root_module_name(package_name: str | None = None, module_name: str | None = None, fallback_leaf: str = 'core_suite', module_file: str | None = None) -> str:
    candidates = addon_root_candidates(package_name, module_name, fallback_leaf, module_file)

    if fallback_leaf:
        for key in candidates:
            text = str(key or '').strip()
            if not text.startswith('bl_ext.'):
                continue
            parts = [part for part in text.split('.') if part]
            if fallback_leaf in parts:
                idx = parts.index(fallback_leaf)
                if idx >= 2:
                    return '.'.join(parts[: idx + 1])

        for key in candidates:
            text = str(key or '').strip()
            if text == fallback_leaf or text.endswith('.' + fallback_leaf):
                return text

    return candidates[0] if candidates else fallback_leaf


def resolve_addon_preferences(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None, fallback_leaf: str = 'core_suite'):
    return _core_runtime.get_addon_preferences(context, package_name, module_name, module_file)


def get_addon_preferences(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None):
    return _core_runtime.get_addon_preferences(context, package_name, module_name, module_file)


def resolve_addon_module_key(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None):
    return _core_runtime.resolve_addon_module_key(context, package_name, module_name, module_file)


def preflight_cleanup(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None, *, force: bool = False):
    return _core_runtime.preflight_cleanup(package_name, module_name, module_file, force=force)


def extension_user_default_root(module_file: str | None = None, *, create: bool = True):
    return _core_runtime.extension_user_default_root(module_file, create=create)


def extension_user_default_storage_dir(module_file: str | None = None, *, folder_name: str = '_user_data', create: bool = True):
    return _core_runtime.extension_user_default_storage_dir(module_file, folder_name=folder_name, create=create)
