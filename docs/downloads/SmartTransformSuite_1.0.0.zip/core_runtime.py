# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from .keymap_safety import safe_remove_keymap as _sts_safe_remove_keymap
from . import operator_safety as _op_safety

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender-only runtime
    bpy = None

_PREFERRED_EXTENSION_ID = "smart_transform_suite"
_CLEANED_PACKAGE_ROOTS: set[str] = set()
_PREFLIGHT_CORE_DONE_KEYS: set[str] = set()
_PREFLIGHT_KEYMAP_DONE_KEYS: set[str] = set()
_LEGACY_MODULE_LEAVES = (
    "navigation_properties",
    "smart_tools_bootstrap_common",
    "smart_tools_preferences",
    "console_clean_runtime",
    "npanel_" + "op" + "acity_runtime",
    "integrated_core_panel",
    "integrated_quick_align",
    "integrated_quick_multi_edit",
    "integrated_select_guard",
    "integrated_uv_tools",
    "uv_tools",
    "integrated_mesh_vertex_tools",
    "integrated_uv_tools_parts",
    "csdt_gizmo",
    "csdt_globals",
    "csdt_ops",
    "csdt_utils",
    "cycle_custom_select",
    "smart_grs_main",
    "grs_pcl",
    "settings_runtime",
)
_LEGACY_DIR_NAMES = (
    "bundled",
    "_integrated_addons",
    "vendors",
    "integrated_uv_tools_parts",
    "uv_tools",
    "__pycache__",
)
_LEGACY_FILE_NAMES: tuple[str, ...] = (
    "navigation_properties.py",
    "smart_tools_bootstrap_common.py",
    "smart_tools_preferences.py",
    "console_clean_runtime.py",
    "npanel_" + "op" + "acity_runtime.py",
    "integrated_core_panel.py",
    "integrated_quick_align.py",
    "integrated_quick_multi_edit.py",
    "integrated_select_guard.py",
    "integrated_uv_tools.py",
    "integrated_mesh_vertex_tools.py",
    "csdt_gizmo.py",
    "csdt_globals.py",
    "csdt_operators.py",
    "csdt_utils.py",
    "cycle_custom_select.py",
    "grs_main.py",
    "grs_pcl.py",
    "settings_runtime.py",
)
_LEGACY_FILE_GLOBS: tuple[str, ...] = (
    '**/__pycache__',
    '**/*.pyc',
    '**/*.pyo',
)

_LEGACY_PACKAGE_ALIASES = (
    "smart_transform_suite",
    "Smart_Transform_Suite",
    "bl_ext.user_default.smart_transform_suite",
    "bl_ext.user_default.Smart_Transform_Suite",
    "bl_ext.user_default.core_suite",
)



def _unique_append(items: list[str], value: str | None) -> None:
    text = str(value or "").strip().strip('.')
    if text and text not in items:
        items.append(text)


def package_root_from_file(module_file: str | None) -> Path:
    if not module_file:
        return Path.cwd()
    current = Path(module_file).resolve()
    if current.is_file() or current.suffix:
        current = current.parent
    while True:
        if (current / 'blender_manifest.toml').is_file():
            return current
        if current.parent == current:
            return current
        current = current.parent





def _blender_version_text() -> str:
    """Return Blender's major.minor version for versioned user data paths."""
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _platform_user_default_root(*, create: bool = True) -> Path:
    """Return the platform fallback for Blender's extensions/user_default root."""
    version = _blender_version_text()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default'
    elif sys.platform == 'darwin':
        root = Path.home() / 'Library' / 'Application Support' / 'Blender' / version / 'extensions' / 'user_default'
    else:
        root = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default'
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def _path_inside_user_default(path: Path) -> Path | None:
    try:
        resolved = path.resolve()
    except Exception:
        resolved = path
    parts = tuple(resolved.parts)
    lowered = [str(part).lower() for part in parts]
    for idx in range(0, max(0, len(parts) - 1)):
        if lowered[idx] == 'extensions' and lowered[idx + 1] == 'user_default':
            try:
                return Path(*parts[: idx + 2])
            except Exception:
                return None
    return None


def extension_user_default_root(module_file: str | None = None, *, create: bool = True) -> Path:
    """Return the active Blender extension repository root named ``user_default``.

    The preferred result is Blender's standard per-user extension repository,
    e.g. ``.../Blender/5.1/extensions/user_default``.  A package already loaded
    from that repository wins because it is the safest location for extension
    local support data in Blender 5.x.
    """
    raw_root = _path_inside_user_default(Path(module_file)) if module_file else None
    if raw_root is not None:
        if create:
            try:
                raw_root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return raw_root

    package_root = package_root_from_file(module_file)
    root = _path_inside_user_default(package_root)
    if root is not None:
        if create:
            try:
                root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return root

    if bpy is not None:
        try:
            root_text = bpy.utils.user_resource('EXTENSIONS', path='user_default', create=bool(create))
            if root_text:
                root = Path(root_text)
                if create:
                    root.mkdir(parents=True, exist_ok=True)
                return root
        except Exception:
            pass
        try:
            scripts_root_text = bpy.utils.user_resource('SCRIPTS', create=False)
            if scripts_root_text:
                root = Path(scripts_root_text).parent / 'extensions' / 'user_default'
                if create:
                    root.mkdir(parents=True, exist_ok=True)
                return root
        except Exception:
            pass

    # Last resort: never write generated add-on data beside an arbitrary
    # unpacked package.  Keep it in Blender's versioned user_default repository.
    return _platform_user_default_root(create=create)


def extension_user_default_storage_dir(module_file: str | None = None, *, folder_name: str = '_user_data', create: bool = True) -> Path:
    """Return an extension-owned support-data folder under ``extensions/user_default``."""
    package_root = package_root_from_file(module_file)
    root = extension_user_default_root(module_file, create=create)
    inside_root = _path_inside_user_default(package_root)
    if inside_root is not None:
        try:
            storage_base = package_root if package_root.is_relative_to(root) else root / _manifest_extension_id(module_file)
        except Exception:
            storage_base = package_root if str(package_root).startswith(str(root)) else root / _manifest_extension_id(module_file)
    else:
        storage_base = root / _manifest_extension_id(module_file)
    folder = str(folder_name or '_user_data').strip() or '_user_data'
    path = storage_base / folder
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path

def _manifest_extension_id(module_file: str | None = None, default: str = _PREFERRED_EXTENSION_ID) -> str:
    root = package_root_from_file(module_file)
    manifest = root / 'blender_manifest.toml'
    try:
        for raw_line in manifest.read_text(encoding='utf-8').splitlines():
            line = raw_line.strip()
            if not line.startswith('id'):
                continue
            _, _, value = line.partition('=')
            value = str(value or '').strip().strip('"').strip("'")
            if value:
                return value
    except Exception:
        pass
    return str(default or _PREFERRED_EXTENSION_ID).strip() or _PREFERRED_EXTENSION_ID


def extension_id(module_file: str | None = None) -> str:
    """Return the manifest extension id used for user_default support data."""
    return _manifest_extension_id(module_file)


def addon_candidate_keys(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None) -> tuple[str, ...]:
    items: list[str] = []
    _unique_append(items, _manifest_extension_id(module_file))

    for legacy_alias in _LEGACY_PACKAGE_ALIASES:
        _unique_append(items, legacy_alias)

    for raw_value in (package_name, module_name):
        text = str(raw_value or '').strip().strip('.')
        if not text:
            continue
        _unique_append(items, text)
        parts = [part for part in text.split('.') if part]
        for length in range(len(parts) - 1, 0, -1):
            _unique_append(items, '.'.join(parts[:length]))
        if parts:
            _unique_append(items, parts[-1])
        if len(parts) >= 2:
            _unique_append(items, parts[-2])
    return tuple(items)


def _addon_keys(addons) -> list[str]:
    keys: list[str] = []
    try:
        keys.extend(list(addons.keys()))
    except Exception:
        pass
    if keys:
        return keys
    try:
        for item in addons:
            module_name = str(getattr(item, 'module', '') or '').strip()
            if module_name and module_name not in keys:
                keys.append(module_name)
    except Exception:
        pass
    return keys


def resolve_addon_module_key(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None) -> str | None:
    if bpy is None:
        return None
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context
    addons = getattr(getattr(ctx, 'preferences', None), 'addons', None) if ctx is not None else None
    if addons is None:
        return None

    candidates = addon_candidate_keys(package_name, module_name, module_file)
    for key in candidates:
        try:
            addons[key]
            return key
        except Exception:
            pass

    existing_keys = _addon_keys(addons)
    if not existing_keys:
        return None

    lowered_candidates = []
    for key in candidates:
        text = str(key or '').strip()
        if not text:
            continue
        lowered_candidates.append((text.lower(), text.rsplit('.', 1)[-1].lower()))

    seen: set[str] = set()
    for actual_key in existing_keys:
        text = str(actual_key or '').strip()
        if not text or text in seen:
            continue
        seen.add(text)
        lookup = text.lower()
        leaf = text.rsplit('.', 1)[-1].lower()
        for full_name, leaf_name in lowered_candidates:
            if (
                lookup == full_name
                or lookup.endswith('.' + full_name)
                or leaf == leaf_name
                or lookup.endswith('.' + leaf_name)
            ):
                return text
    return None


def get_addon_preferences(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None):
    if bpy is None:
        return None
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context

    # Smart Transform keeps all editable settings in the N-panel.  To avoid
    # Blender Preferences showing an empty "Preferences" block, current
    # builds store the add-on's runtime settings in a hidden WindowManager
    # PropertyGroup instead of an AddonPreferences subclass.
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is None:
            wm = getattr(bpy.context, 'window_manager', None)
        prefs = getattr(wm, 'smart_transform_suite_runtime_preferences', None) if wm is not None else None
        if prefs is not None:
            return prefs
    except Exception:
        pass

    key = resolve_addon_module_key(ctx, package_name, module_name, module_file)
    if not key:
        return None
    try:
        return ctx.preferences.addons[key].preferences
    except Exception:
        return None


def _remove_path(path: Path) -> bool:
    try:
        if path.is_symlink() or path.is_file():
            path.unlink(missing_ok=True)
            return True
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=False)
            return True
    except FileNotFoundError:
        return False
    except Exception:
        try:
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
                return True
        except Exception:
            pass
    return False




def _neutralize_module_watchdog_before_module_pop(module) -> bool:
    """Return True when it is safe to remove a legacy module from sys.modules.

    Old Smart Transform builds registered _csdt_constraint_watchdog as a
    bpy.app.timer.  If a module is removed while that exact callable is still
    registered, Blender keeps a timer callback that can no longer be found by
    later cleanup code and may crash inside RNA path resolution.
    """
    try:
        fn = getattr(module, '_csdt_constraint_watchdog', None)
    except Exception:
        fn = None
    if not callable(fn):
        return True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    except Exception:
        timers = None
    if timers is None:
        return False
    try:
        if timers.is_registered(fn):
            timers.unregister(fn)
    except Exception:
        # Keep the module reachable so the exact function object can be retried
        # by the next guard tick instead of stranding a dangerous timer.
        return False
    try:
        def _safe_noop_watchdog():
            return None
        setattr(module, '_csdt_constraint_watchdog', _safe_noop_watchdog)
    except Exception:
        pass
    return True

def unregister_legacy_loaded_modules(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None) -> list[str]:
    addon_id = _manifest_extension_id(module_file)
    candidates = addon_candidate_keys(package_name, module_name, module_file)
    current_keys = {str(v or '').strip() for v in (package_name, module_name, addon_id) if str(v or '').strip()}
    removed: list[str] = []

    def _matches_current(name: str) -> bool:
        if not name:
            return False
        if name in current_keys:
            return True
        return any(candidate and (name == candidate or name.endswith('.' + candidate)) for candidate in candidates)

    for key, module in list(sys.modules.items()):
        text = str(key or '').strip()
        if not text:
            continue
        parts = text.split('.')
        if len(parts) >= 3 and parts[0] == 'bl_ext' and parts[2] != addon_id and parts[2] not in _LEGACY_PACKAGE_ALIASES and '.'.join(parts[:3]) not in _LEGACY_PACKAGE_ALIASES:
            # Another extension may reuse a legacy leaf name; its modules are not ours.
            continue

        related_to_current = (
            addon_id in text
            or any(candidate and candidate in text for candidate in candidates if '.' in candidate)
            or text in _LEGACY_MODULE_LEAVES
            or any(text.startswith(leaf + '.') for leaf in _LEGACY_MODULE_LEAVES)
            or text in _LEGACY_PACKAGE_ALIASES
        )
        if not related_to_current:
            continue
        if _matches_current(text):
            continue

        is_legacy = (
            text in _LEGACY_PACKAGE_ALIASES
            or any(
                text == leaf
                or text.endswith('.' + leaf)
                or f'.{leaf}.' in text
                or text.startswith(leaf + '.')
                for leaf in _LEGACY_MODULE_LEAVES
            )
            or '.bundled.' in text
            or '._integrated_addons.' in text
        )
        if not is_legacy:
            continue

        cleanup_fn = getattr(module, 'unregister', None)
        cleanup_called = False
        if callable(cleanup_fn):
            try:
                cleanup_fn()
                cleanup_called = True
            except TypeError:
                pass
            except Exception:
                cleanup_called = True
        if not cleanup_called:
            cleanup_fn = getattr(module, 'uninstall', None)
            if callable(cleanup_fn):
                legacy_owners = (
                    addon_id,
                    'core_suite',
                    'smart_transform_suite',
                    'Smart_Transform_Suite',
                    'bl_ext.user_default.smart_transform_suite',
                    'bl_ext.user_default.Smart_Transform_Suite',
                    'bl_ext.user_default.core_suite',
                    *candidates,
                )
                try:
                    cleanup_fn()
                    cleanup_called = True
                except TypeError:
                    for owner in legacy_owners:
                        if not owner:
                            continue
                        try:
                            cleanup_fn(owner)
                            cleanup_called = True
                        except TypeError:
                            try:
                                cleanup_fn(addon_key=owner)
                                cleanup_called = True
                            except Exception:
                                pass
                        except Exception:
                            pass
                except Exception:
                    cleanup_called = True
        if not _neutralize_module_watchdog_before_module_pop(module):
            # Do not remove modules that still own a registered legacy timer.
            # Leaving the module reachable is safer than stranding a callback.
            continue
        sys.modules.pop(key, None)
        removed.append(text)

    return removed





def _keymap_item_count(km) -> int:
    """Crash-safe no-op count; do not touch KeyMap.keymap_items."""
    del km
    return 0


def _new_keymap_item_from_source(dst_km, src_kmi):
    """Crash-safe no-op; do not create keymap items from source keymaps."""
    del dst_km, src_kmi
    return None

def _copy_kmi_properties(src_kmi, dst_kmi) -> None:
    # Crash-safe Blender 5.1 policy: do not inspect KeyMapItem.properties from
    # existing source keymaps.  Stale OperatorProperties RNA can raise a native
    # access violation outside Python exception handling.  The key combination
    # itself is still copied by _new_keymap_item_from_source; custom operator
    # properties are intentionally skipped.
    del src_kmi, dst_kmi
    return None


def _preflight_session_key(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None) -> str:
    root = package_root_from_file(module_file)
    candidates = addon_candidate_keys(package_name, module_name, module_file)
    suffix = '|'.join(candidates) if candidates else (_manifest_extension_id(module_file) or _PREFERRED_EXTENSION_ID)
    return f"{root.resolve()}::{suffix}"


def _keymap_cleanup_ready() -> bool:
    """Crash-safe no-op; do not inspect keyconfigs."""
    return False


def _ensure_user_interface_keymap_from_defaults(keyconfigs) -> list[str]:
    """Reserved compatibility hook for older builds that created empty UI keymaps.

    Current builds do not recreate Blender's User Interface keymap. Leaving this
    as a defined no-op preserves internal calls while avoiding unreachable code.
    """
    del keyconfigs
    return []



def cleanup_empty_user_interface_keymaps() -> list[str]:
    """Crash-safe no-op; do not traverse or mutate keyconfigs."""
    return []

def cleanup_legacy_files(module_file: str | None = None) -> list[str]:
    root = package_root_from_file(module_file)
    root_key = str(root)
    if root_key in _CLEANED_PACKAGE_ROOTS:
        return []

    removed: list[str] = []

    for name in _LEGACY_FILE_NAMES:
        path = root / name
        if not path.exists():
            continue
        if _remove_path(path):
            removed.append(path.relative_to(root).as_posix())

    for pattern in _LEGACY_FILE_GLOBS:
        try:
            matches = tuple(root.glob(pattern))
        except Exception:
            matches = ()
        for path in matches:
            if path.exists() and _remove_path(path):
                removed.append(path.relative_to(root).as_posix())

    for name in _LEGACY_DIR_NAMES:
        path = root / name
        if path.exists() and _remove_path(path):
            removed.append(path.relative_to(root).as_posix())

    _CLEANED_PACKAGE_ROOTS.add(root_key)
    return removed


def preflight_cleanup(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None, force: bool = False) -> dict[str, list[str]]:
    session_key = _preflight_session_key(package_name, module_name, module_file)

    modules: list[str] = []
    files: list[str] = []
    keymaps: list[str] = []

    if force or session_key not in _PREFLIGHT_CORE_DONE_KEYS:
        modules = unregister_legacy_loaded_modules(package_name, module_name, module_file)
        files = cleanup_legacy_files(module_file)
        if not force:
            _PREFLIGHT_CORE_DONE_KEYS.add(session_key)

    if force or session_key not in _PREFLIGHT_KEYMAP_DONE_KEYS:
        keymaps = cleanup_empty_user_interface_keymaps()
        if force or _keymap_cleanup_ready():
            _PREFLIGHT_KEYMAP_DONE_KEYS.add(session_key)

    return {
        'modules': modules,
        'files': files,
        'keymaps': keymaps,
    }
