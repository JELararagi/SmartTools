# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
import math
import importlib as _safe_help_importlib
import sys as _sts_sys

from bpy.props import (
    BoolProperty,
    IntProperty,
    FloatProperty,
    EnumProperty,
    StringProperty,
    PointerProperty,
)

# 翻訳関数のインポート
from .translation import T, TI, TB, english_source
from . import runtime as _runtime
from . import settings as _settings
from . import ui_icons as _ui_icons
from . import operator_safety as _op_safety
# -----------------------------------------------------------------------------


def _addon_root_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    return _runtime.addon_root_module_name(__package__, __name__, module_file=__file__)





_RUNTIME_PREFS_ATTR = 'smart_transform_suite_runtime_preferences'
_LEGACY_ADDON_PREFERENCES_CLASSES = (
    'CSDT_Preferences',
    'SmartTransformPreferences',
    'QUICK_ALIGN_PT_preferences',
    'QuickMultiEditPreferences',
    'SSG_AddonPreferences',
)


def runtime_preferences_from_window_manager(context=None):
    try:
        if not hasattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR):
            return None
    except Exception:
        return None
    try:
        ctx = context or bpy.context
    except Exception:
        ctx = context
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        try:
            wm = getattr(bpy.context, 'window_manager', None)
        except Exception:
            wm = None
    if wm is None:
        return None
    try:
        return getattr(wm, _RUNTIME_PREFS_ATTR, None)
    except Exception:
        return None


def _unregister_legacy_addon_preferences_classes() -> None:
    for class_name in _LEGACY_ADDON_PREFERENCES_CLASSES:
        try:
            cls = getattr(bpy.types, class_name, None)
            if isinstance(cls, type) and issubclass(cls, bpy.types.AddonPreferences):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass


def _register_runtime_preferences_property() -> None:
    if hasattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR):
        return
    kwargs = dict(
        type=CSDT_Preferences,
        name=_ui('Smart Transform Runtime Preferences', 'Smart Transformランタイム設定'),
        description=_ui(
            'Hidden runtime storage used by the Smart Transform N-panel. It replaces the visible Add-on Preferences section so the Preferences block does not appear in Blender Preferences.',
            'Smart Transform のNパネルが使用する非表示ランタイム保存領域です。表示されるアドオンプリファレンス欄を置き換え、Blenderプリファレンス側に「プリファレンス」ブロックを表示しません。',
        ),
    )
    try:
        setattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR, PointerProperty(**kwargs, options={'HIDDEN'}))
    except TypeError:
        try:
            setattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR, PointerProperty(**kwargs))
        except Exception:
            pass
    except Exception:
        pass


def _unregister_runtime_preferences_property() -> None:
    try:
        if hasattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR):
            delattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR)
    except Exception:
        pass

def _ui(en: str, ja: str) -> str:
    return TI(en, ja)


_UNIT_NAME_JA = {
    'NONE': 'なし',
    'ADAPTIVE': '自動',
    'DEGREES': '度',
    'RADIANS': 'ラジアン',
    'METERS': 'メートル',
    'CENTIMETERS': 'センチメートル',
    'MILLIMETERS': 'ミリメートル',
    'MICROMETERS': 'マイクロメートル',
    'KILOMETERS': 'キロメートル',
    'MILES': 'マイル',
    'FEET': 'フィート',
    'INCHES': 'インチ',
    'THOU': 'サウ',
    'TONNES': 'トン',
    'KILOGRAMS': 'キログラム',
    'GRAMS': 'グラム',
    'MILLIGRAMS': 'ミリグラム',
    'POUNDS': 'ポンド',
    'OUNCES': 'オンス',
    'STONES': 'ストーン',
    'SECONDS': '秒',
    'MILLISECONDS': 'ミリ秒',
    'MICROSECONDS': 'マイクロ秒',
    'MINUTES': '分',
    'HOURS': '時間',
    'DAYS': '日',
    'FRAMES': 'フレーム',
    'KELVIN': 'ケルビン',
    'CELSIUS': '摂氏',
    'FAHRENHEIT': '華氏',
}


_PRECISION_TIME_SECONDS_PER_UNIT = {
    'MICROSECONDS': 1.0e-6,
    'MILLISECONDS': 1.0e-3,
    'SECONDS': 1.0,
    'MINUTES': 60.0,
    'HOURS': 3600.0,
    'DAYS': 86400.0,
    # Blender's ADAPTIVE time display has no fixed scalar for an editable step.
    # Interpret the editable value as seconds and state that in the unit label.
    'ADAPTIVE': 1.0,
}


def _precision_drag_time_unit_identifier(context=None) -> str:
    try:
        ctx = context or getattr(bpy, 'context', None)
        return str(ctx.scene.unit_settings.time_unit or 'SECONDS').upper()
    except Exception:
        return 'SECONDS'


def _precision_drag_time_seconds_per_unit(context=None) -> float:
    return float(_PRECISION_TIME_SECONDS_PER_UNIT.get(_precision_drag_time_unit_identifier(context), 1.0))


def _precision_drag_time_display_get(self) -> float:
    try:
        seconds = float(getattr(self, 'precision_numeric_drag_step_time', 1.0))
    except Exception:
        seconds = 1.0
    factor = _precision_drag_time_seconds_per_unit(getattr(bpy, 'context', None))
    if not math.isfinite(seconds) or seconds <= 0.0:
        seconds = 1.0
    if not math.isfinite(factor) or factor <= 0.0:
        factor = 1.0
    return max(seconds / factor, 1.0e-9)


def _precision_drag_time_display_set(self, value) -> None:
    try:
        shown_value = float(value)
    except Exception:
        shown_value = 1.0
    if not math.isfinite(shown_value) or shown_value <= 0.0:
        shown_value = 1.0e-9
    factor = _precision_drag_time_seconds_per_unit(getattr(bpy, 'context', None))
    if not math.isfinite(factor) or factor <= 0.0:
        factor = 1.0
    try:
        self.precision_numeric_drag_step_time = max(shown_value * factor, 1.0e-9)
    except Exception:
        pass


def _precision_drag_scene_unit_name(context, category: str) -> str:
    try:
        units = context.scene.unit_settings
    except Exception:
        return _ui('Blender default', 'Blenderデフォルト')
    attr_by_category = {
        'rotation': 'system_rotation',
        'length': 'length_unit',
        'mass': 'mass_unit',
        'time': 'time_unit',
        'temperature': 'temperature_unit',
    }
    try:
        identifier = str(getattr(units, attr_by_category[category], '') or '')
    except Exception:
        identifier = ''
    if category == 'length':
        try:
            if str(getattr(units, 'system', 'NONE') or 'NONE') == 'NONE':
                identifier = 'NONE'
        except Exception:
            pass
    if not identifier:
        return _ui('Blender default', 'Blenderデフォルト')
    if category == 'time' and identifier == 'ADAPTIVE':
        return _ui('Adaptive (Seconds)', '自動（秒）')
    en = identifier.replace('_', ' ').title()
    ja = _UNIT_NAME_JA.get(identifier, en)
    return _ui(en, ja)


def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}


def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False


def _operator_button_target(layout, *, icon_only: bool = False):
    if layout is None:
        return None
    if not icon_only:
        return layout
    try:
        row = layout.row(align=True)
        row.scale_x = 1.18
        row.scale_y = 1.28
        return row
    except Exception:
        return layout


# -----------------------------------------------------------------------------
# Persistent N-panel settings save
# -----------------------------------------------------------------------------

_LAST_AUTOSAVE_SNAPSHOT = None


def _request_prefs_save(reason: str = 'preferences_update') -> None:
    del reason
    try:
        if _settings.is_restoring():
            return
    except Exception:
        pass
    try:
        _settings.request_save('preferences_update')
    except Exception:
        pass

def _request_userpref_autosave(context=None) -> None:
    try:
        if _settings.is_restoring():
            return
    except Exception:
        pass
    try:
        _settings.request_save('preferences_update', context=context)
    except Exception:
        pass

def _sync_custom_select_mode_update(self, context) -> None:
    _request_prefs_save('custom_select_mode')
    try:
        if _settings.is_restoring():
            return
    except Exception:
        pass
    mode_to_tool = {
        'TWEAK': 'builtin.select',
        'BOX': 'builtin.select_box',
        'CIRCLE': 'builtin.select_circle',
        'LASSO': 'builtin.select_lasso',
    }
    try:
        mode = str(getattr(self, 'custom_select_mode', 'BOX') or 'BOX').strip().upper()
    except Exception:
        mode = 'BOX'
    tool_id = mode_to_tool.get(mode, 'builtin.select_box')
    try:
        setattr(self, 'last_select_tool', tool_id)
    except Exception:
        pass

    def _sync_toolbar():
        try:
            from .core import cycle_custom_select as _cycle_custom_select
            ctx = context or bpy.context
            try:
                active_tool_id = _cycle_custom_select._safe_active_view3d_tool_id(ctx)
            except Exception:
                active_tool_id = ''
            _cycle_custom_select._sync_select_toolbar_group_mode(ctx, tool_id, active_tool_id=active_tool_id)
        except Exception:
            pass

    _defer_ui_task(_sync_toolbar, delay=0.02)


# Blender 5.1 can execute property update callbacks while a native Sidebar panel
# event is still being handled.  Runtime sync, modal/draw-handler changes,
# keymap repair and viewport redraw are therefore deferred to a timer tick.
def _defer_ui_task(callback, *args, delay: float = 0.05, **kwargs) -> None:
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            def _run():
                try:
                    callback(*args, **kwargs)
                except Exception:
                    pass
                return None
            timers.register(_run, first_interval=max(0.0, float(delay)))
            return
    except Exception:
        pass
    try:
        callback(*args, **kwargs)
    except Exception:
        pass

def _is_restoring_settings() -> bool:
    try:
        return bool(_settings.is_restoring())
    except Exception:
        return False


def _save_always_on_change_now(context=None) -> None:
    try:
        if _settings.is_restoring():
            return
    except Exception:
        pass
    try:
        _settings.save_always_on_now(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _update_mesh_island_transform_always_on(self, context) -> None:
    del self
    _request_prefs_save('enable_mesh_island_transform')
    _save_always_on_change_now(context)


def _update_show_always_on_switches(self, context) -> None:
    del self
    _request_prefs_save('show_always_on_switches')
    _save_always_on_change_now(context)

def _snapshot_simple_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        if hasattr(value, '__len__') and not isinstance(value, (bytes, bytearray, str)):
            return tuple(_snapshot_simple_value(v) for v in value)
    except Exception:
        pass
    return None


def _snapshot_rna_group(group, depth=0):
    if group is None or depth > 3:
        return None
    out = []
    try:
        props = getattr(getattr(group, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            ident = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if not ident or ident in {'rna_type', 'npanel_settings_json', 'persistent_feature_toggles_json'}:
            continue
        try:
            ptype = str(getattr(prop, 'type', '') or '')
        except Exception:
            ptype = ''
        try:
            value = getattr(group, ident)
        except Exception:
            continue
        if ptype == 'POINTER':
            sub = _snapshot_rna_group(value, depth + 1)
            if sub is not None:
                out.append((ident, sub))
            continue
        if ptype in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
            out.append((ident, _snapshot_simple_value(value)))
    return tuple(out)




def _update_npanel_state_save_enabled(self, context) -> None:
    """Persist the N-panel state-save policy immediately.

    This setting controls whether ordinary N-panel changes are written to
    Smart_Transform_Suite.json continuously or only at explicit safe save
    milestones.  The policy switch itself is always written immediately so the
    next Blender launch restores the requested save behavior.
    """
    try:
        if _settings.is_restoring():
            return
    except Exception:
        pass
    try:
        _settings.persist_save_policy_change(context or getattr(bpy, 'context', None))
        _settings.sync_change_subscriptions_for_policy(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def _autosave_on_ui_draw(prefs, context=None) -> None:
    del prefs, context
    # Do not traverse preferences during a panel draw pass.  Property updates
    # already queue a deferred save through _settings.request_save(); walking
    # RNA here can run while Blender's native panel handler is still processing
    # the current event and has been observed to cause hard crashes in 5.x.
    return


def _ensure_stp_scale_link_migration(panel):
    if panel is None:
        return None
    try:
        already_migrated = bool(getattr(panel, 'scale_link_axes_migrated', False))
    except Exception:
        already_migrated = True
    if already_migrated:
        return panel
    try:
        legacy_enabled = bool(getattr(panel, 'scale_link_xyz', False))
    except Exception:
        legacy_enabled = False
    try:
        panel.scale_link_x = legacy_enabled
        panel.scale_link_y = legacy_enabled
        panel.scale_link_z = legacy_enabled
        panel.scale_link_axes_migrated = True
    except Exception:
        pass
    return panel



_QME_NAMED_KEYS = (
    ('SPACE', 'Space Key', 'スペースキー'), ('TAB', 'Tab Key', 'タブキー'), ('RET', 'Enter Key', 'エンターキー'),
    ('ESC', 'Escape Key', 'エスケープキー'), ('BACK_SPACE', 'Backspace Key', 'バックスペースキー'),
    ('DEL', 'Del Key', 'デリートキー'), ('INSERT', 'Ins Key', 'インサートキー'),
    ('HOME', 'Home Key', 'ホームキー'), ('END', 'End Key', 'エンドキー'),
    ('PAGE_UP', 'Page Up Key', 'ページアップキー'), ('PAGE_DOWN', 'Page Down Key', 'ページダウンキー'),
    ('LEFT_ARROW', 'Left Arrow Key', '左矢印キー'), ('RIGHT_ARROW', 'Right Arrow Key', '右矢印キー'),
    ('UP_ARROW', 'Up Arrow Key', '上矢印キー'), ('DOWN_ARROW', 'Down Arrow Key', '下矢印キー'),
    ('ACCENT_GRAVE', 'Accent Grave Key', 'アクセントグレーブキー'), ('MINUS', 'Minus Key', 'マイナスキー'),
    ('EQUAL', 'Equal Key', 'イコールキー'), ('LEFT_BRACKET', 'Left Bracket Key', '左角かっこキー'),
    ('RIGHT_BRACKET', 'Right Bracket Key', '右角かっこキー'), ('SEMI_COLON', 'Semicolon Key', 'セミコロンキー'),
    ('COMMA', 'Comma Key', 'カンマキー'), ('PERIOD', 'Period Key', 'ピリオドキー'), ('QUOTE', 'Quote Key', 'クォートキー'),
    ('SLASH', 'Slash Key', 'スラッシュキー'), ('BACK_SLASH', 'Backslash Key', 'バックスラッシュキー'),
)
_QME_NUMPAD_KEYS = (
    ('NUMPAD_0', 'Numpad 0', 'テンキー 0'), ('NUMPAD_1', 'Numpad 1', 'テンキー 1'), ('NUMPAD_2', 'Numpad 2', 'テンキー 2'),
    ('NUMPAD_3', 'Numpad 3', 'テンキー 3'), ('NUMPAD_4', 'Numpad 4', 'テンキー 4'), ('NUMPAD_5', 'Numpad 5', 'テンキー 5'),
    ('NUMPAD_6', 'Numpad 6', 'テンキー 6'), ('NUMPAD_7', 'Numpad 7', 'テンキー 7'), ('NUMPAD_8', 'Numpad 8', 'テンキー 8'),
    ('NUMPAD_9', 'Numpad 9', 'テンキー 9'), ('NUMPAD_PLUS', 'Numpad +', 'テンキー +'), ('NUMPAD_MINUS', 'Numpad -', 'テンキー -'),
    ('NUMPAD_ASTERIX', 'Numpad *', 'テンキー *'), ('NUMPAD_SLASH', 'Numpad /', 'テンキー /'), ('NUMPAD_PERIOD', 'Numpad .', 'テンキー .'),
    ('NUMPAD_ENTER', 'Numpad Enter', 'テンキーのエンター'),
)


def _qme_key_type_items(_self=None, _context=None):
    items = [
        ('NONE', _ui('Disabled', '無効'), _ui('Do not register this shortcut.', 'このショートカットを登録しません。')),
        ('20515', _ui('Legacy Compatibility', '旧互換値'), _ui('Temporary compatibility alias for legacy invalid shortcut data.', '古い不正ショートカット値を受け止める一時互換項目です。')),
        ('RIGHTMOUSE', _ui('Right Mouse', '右クリック'), _ui('Use right mouse click for this shortcut.', 'このショートカットに右クリックを使います。')),
        ('LEFTMOUSE', _ui('Left Mouse', '左クリック'), _ui('Use left mouse click for this shortcut.', 'このショートカットに左クリックを使います。')),
        ('MIDDLEMOUSE', _ui('Middle Mouse', '中クリック'), _ui('Use middle mouse click for this shortcut.', 'このショートカットに中クリックを使います。')),
        ('BUTTON4MOUSE', _ui('Mouse Button 4', 'マウスボタン4'), _ui('Use mouse button 4 for this shortcut.', 'このショートカットにマウスボタン4を使います。')),
        ('BUTTON5MOUSE', _ui('Mouse Button 5', 'マウスボタン5'), _ui('Use mouse button 5 for this shortcut.', 'このショートカットにマウスボタン5を使います。')),
        ('WHEELUPMOUSE', _ui('Wheel Up', 'ホイール上'), _ui('Use mouse wheel up for this shortcut.', 'このショートカットにホイール上を使います。')),
        ('WHEELDOWNMOUSE', _ui('Wheel Down', 'ホイール下'), _ui('Use mouse wheel down for this shortcut.', 'このショートカットにホイール下を使います。')),
        ('WHEELINMOUSE', _ui('Wheel In', 'ホイール押し込み'), _ui('Use wheel-in for this shortcut.', 'このショートカットにホイール押し込みを使います。')),
        ('WHEELOUTMOUSE', _ui('Wheel Out', 'ホイール引き出し'), _ui('Use wheel-out for this shortcut.', 'このショートカットにホイール引き出しを使います。')),
        ('MOUSEMOVE', _ui('Mouse Move', 'マウス移動'), _ui('Use mouse movement for this shortcut.', 'このショートカットにマウス移動を使います。')),
        ('TRACKPADPAN', _ui('Trackpad Pan', 'トラックパッドパン'), _ui('Use trackpad pan for this shortcut.', 'このショートカットにトラックパッドパンを使います。')),
        ('TRACKPADZOOM', _ui('Trackpad Zoom', 'トラックパッドズーム'), _ui('Use trackpad zoom for this shortcut.', 'このショートカットにトラックパッドズームを使います。')),
    ]

    for ident in [
        'A','B','C','D','E','F','G','H','I','J','K','L','M',
        'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    ]:
        items.append((ident, ident, _ui(f'Use {ident} for this shortcut.', f'このショートカットに {ident} キーを使います。')))

    for ident, label in [
        ('ZERO', '0'), ('ONE', '1'), ('TWO', '2'), ('THREE', '3'), ('FOUR', '4'),
        ('FIVE', '5'), ('SIX', '6'), ('SEVEN', '7'), ('EIGHT', '8'), ('NINE', '9'),
    ]:
        items.append((ident, label, _ui(f'Use {label} for this shortcut.', f'このショートカットに {label} キーを使います。')))

    # Blender's own catalogue already answers "Esc", "Del", "Insert", "End" and
    # others, and it wins over add-on tables, so these names use their own text.
    for ident, label_en, label_ja in _QME_NAMED_KEYS:
        items.append((ident, _ui(label_en, label_ja), _ui(f'Use {label_en} for this shortcut.', f'このショートカットに{label_ja}を使います。')))

    for i in range(1, 25):
        ident = f'F{i}'
        items.append((ident, ident, _ui(f'Use {ident} for this shortcut.', f'このショートカットに {ident} キーを使います。')))

    for ident, label_en, label_ja in _QME_NUMPAD_KEYS:
        items.append((ident, _ui(label_en, label_ja), _ui(f'Use {label_en} for this shortcut.', f'このショートカットに{label_ja}を使います。')))

    return items



def _qme_key_value_items(_self=None, _context=None):
    return [
        ('PRESS', _ui('Press', '押下'), _ui('Trigger when the key or button is pressed.', 'キーまたはボタンを押した時に実行します。')),
        ('CLICK', _ui('Click', 'クリック'), _ui('Trigger on click.', 'クリック時に実行します。')),
        ('DOUBLE_CLICK', _ui('Double Click', 'ダブルクリック'), _ui('Trigger on double click.', 'ダブルクリック時に実行します。')),
        ('CLICK_DRAG', _ui('Click Drag', 'クリックドラッグ'), _ui('Trigger when the input starts a drag.', 'ドラッグ開始時に実行します。')),
        ('RELEASE', _ui('Release', '離す'), _ui('Trigger when the key or button is released.', 'キーまたはボタンを離した時に実行します。')),
        ('ANY', _ui('Any', '任意'), _ui('Accept any event value for this input.', 'この入力の値を任意扱いにします。')),
    ]

QME_KEY_TYPE_ITEMS = _qme_key_type_items()
QME_KEY_VALUE_ITEMS = _qme_key_value_items()


_COPY_TEXT_OPERATOR_ID = 'core_suite.copy_text'


class _SafeMissingOperator:
    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        return None


_SAFE_MISSING_OPERATOR = _SafeMissingOperator()


def _operator_properties_contain(op, prop_name: str) -> bool:
    return _op_safety.operator_proxy_has_property(op, prop_name)


def _safe_set_operator_property(op, prop_name: str, value, *, strict: bool = True, operator_id: object | None = None) -> bool:
    if op is None or op is _SAFE_MISSING_OPERATOR:
        return False
    return _op_safety.safe_set_operator_property(op, prop_name, value, operator_id=operator_id, strict=strict)


def _operator_exists(operator_id: object) -> bool:
    return _op_safety.operator_exists(operator_id)


def _safe_layout_operator(layout, operator_id: object, *, text: str = '', icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, depress: bool = False, **props):
    idname = str(operator_id or '').strip()
    clean_props = dict(props)
    clean_props.pop('custom_icon', None)
    icon_only = not str(text or '').strip()
    draw_layout = _operator_button_target(layout, icon_only=icon_only)
    if draw_layout is None:
        return _SAFE_MISSING_OPERATOR
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=idname, text=str(text or ''), custom_icon=custom_icon, props=clean_props)

    def _draw_operator_button(target_id: str, target_text: str):
        try:
            return draw_layout.operator(target_id, text=target_text, emboss=bool(emboss), depress=bool(depress), **icon_args)
        except TypeError:
            try:
                return draw_layout.operator(target_id, text=target_text, icon=icon, emboss=bool(emboss), depress=bool(depress))
            except TypeError:
                return draw_layout.operator(target_id, text=target_text, icon=icon)

    if not _operator_exists(idname):
        # Keep inactive tools lazy: the N-panel can show a button, but the
        # owning module is imported only when the user actually presses it.
        try:
            from . import lazy_operators as _lazy_operators
            lazy_id = 'core_suite.lazy_execute_operator'
            if _operator_exists(lazy_id):
                op = _draw_operator_button(lazy_id, text or idname or _ui('Run', '実行'))
                _safe_set_operator_property(op, 'target_operator', idname, strict=True, operator_id=lazy_id)
                _safe_set_operator_property(op, 'module_key', _lazy_operators.module_key_for_operator(idname), strict=True, operator_id=lazy_id)
                for prop_name, prop_value in clean_props.items():
                    if prop_name in {'mode', 'action', 'category', 'profile'}:
                        _safe_set_operator_property(op, prop_name, str(prop_value), strict=True, operator_id=lazy_id)
                return op
        except Exception:
            pass
        try:
            label = text or _ui('Unavailable', '利用不可')
            _draw_icon_label(draw_layout, label, icon='ERROR')
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR
    try:
        op = _draw_operator_button(idname, str(text or ''))
        for prop_name, prop_value in clean_props.items():
            _safe_set_operator_property(op, prop_name, prop_value, strict=True, operator_id=idname)
        return op
    except Exception:
        try:
            label = text or _ui('Unavailable', '利用不可')
            _draw_icon_label(draw_layout, label, icon='ERROR')
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR



def _qme_default_mouse_button_label(qme, context=None):
    button = str(getattr(qme, 'default_mouse_button', 'RIGHTMOUSE') or 'RIGHTMOUSE')
    if button == 'AUTO':
        try:
            select_mouse = str(getattr(getattr(getattr(context, 'preferences', None), 'inputs', None), 'select_mouse', 'RIGHT') or 'RIGHT')
            button = 'LEFTMOUSE' if select_mouse == 'LEFT' else 'RIGHTMOUSE'
        except Exception:
            button = 'RIGHTMOUSE'
    return 'LMB' if button == 'LEFTMOUSE' else 'RMB'



def _draw_copy_text_row(layout, label: str, value: str, *, icon: str = 'COPYDOWN'):
    col = layout.column(align=True)
    row = col.split(factor=0.72, align=True)
    _draw_icon_label(row, str(label), icon=icon)
    try:
        op = row.operator(_COPY_TEXT_OPERATOR_ID, text=_ui('Copy', 'コピー'))
        _safe_set_operator_property(op, 'text', str(value or ''), strict=True, operator_id=_COPY_TEXT_OPERATOR_ID)
        _safe_set_operator_property(op, 'report_label', str(value or ''), strict=True, operator_id=_COPY_TEXT_OPERATOR_ID)
    except Exception:
        pass


def _draw_keymap_location_label(layout, value: str):
    """Draw a non-copyable recommended keymap location label."""
    value = str(value or '').strip()
    if not value:
        return
    col = layout.column(align=True)
    _draw_icon_label(col, _ui('Recommended Keymap Location', '推奨キーマップ登録場所'), icon='KEY_HLT')
    # Wide (Japanese) characters take about twice the width of Latin ones.
    def _width(text):
        return sum(2 if ord(char) > 0x2E7F else 1 for char in text)
    lines = []
    for part in value.split(' > '):
        if lines and _width(lines[-1] + ' > ' + part + ' >') <= 36:
            lines[-1] += ' > ' + part
        else:
            lines.append(part)
    for index, line in enumerate(lines):
        col.label(text=line + (' >' if index < len(lines) - 1 else ''), translate=False)


def _draw_manual_keymap_registration_box(
    layout,
    *,
    title: str | None = None,
    locations=(),
    entries=(),
    topic_key: str = '',
):
    """Draw manual keymap registration guidance at a section bottom.

    The add-on must not create Preferences > Keymap items automatically.
    Recommended locations are displayed as plain text directly above each
    copyable Operator ID / modal action ID.  Location rows intentionally do not
    include a copy button.
    """
    if layout is None:
        return None
    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        header = box.row(align=True)
    except Exception:
        header = box
    _draw_icon_label(
        header,
        _ui('Keymap Registration', 'キーマップ登録'),
        icon='KEY_HLT',
    )
    if topic_key:
        _draw_help_button(header, str(topic_key), icon='QUESTION')

    location_values = []
    for _label, value in tuple(locations or ()):
        value = str(value or '').strip()
        if value:
            location_values.append(value)
    default_location = location_values[0] if len(location_values) == 1 else ''

    def _entry_parts(entry):
        if isinstance(entry, dict):
            return (
                str(entry.get('label') or _ui('Registration ID', '登録ID')),
                str(entry.get('value') or ''),
                str(entry.get('location') or default_location or ''),
            )
        try:
            items = tuple(entry)
        except Exception:
            return (_ui('Registration ID', '登録ID'), str(entry or ''), default_location)
        label = str(items[0] if len(items) > 0 else _ui('Registration ID', '登録ID'))
        value = str(items[1] if len(items) > 1 else '')
        location = str(items[2] if len(items) > 2 else default_location)
        return label, value, location

    for entry in tuple(entries or ()):
        label, value, location = _entry_parts(entry)
        if not str(value or '').strip():
            continue
        _draw_keymap_location_label(box, location)
        _draw_copy_text_row(box, str(label or _ui('Registration ID', '登録ID')), str(value))
    return box



def _qme_item_label(items, ident: str) -> str:
    for item in items:
        if item[0] == ident:
            name = str(item[1])
            return bpy.app.translations.pgettext_iface(english_source(name) or name)
    return ident


def _qme_binding_summary(qme, prefix: str) -> str:
    key_type = str(getattr(qme, f'custom_{prefix}_type', 'NONE') or 'NONE')
    if key_type == 'NONE':
        return _ui('Disabled', '無効')
    value = str(getattr(qme, f'custom_{prefix}_value', 'PRESS') or 'PRESS')
    parts = []
    if bool(getattr(qme, f'custom_{prefix}_shift', False)):
        parts.append('Shift')
    if bool(getattr(qme, f'custom_{prefix}_ctrl', False)):
        parts.append('Ctrl')
    if bool(getattr(qme, f'custom_{prefix}_alt', False)):
        parts.append('Alt')
    parts.append(_qme_item_label(QME_KEY_TYPE_ITEMS, key_type))
    if value not in {'PRESS', 'ANY'}:
        parts.append(_qme_item_label(QME_KEY_VALUE_ITEMS, value))
    return ' + '.join(parts)



def _draw_qme_binding_editor(layout, qme, prefix: str, title: str, operator_id: str):
    box = layout.box()
    _draw_icon_label(box, title, icon='KEYINGSET')
    row = box.row(align=True)
    row.prop(qme, f'custom_{prefix}_type', text=_ui('Key', 'キー'))
    row.prop(qme, f'custom_{prefix}_value', text=_ui('Event', '動作'))
    mods = box.row(align=True)
    mods.prop(qme, f'custom_{prefix}_shift', toggle=True, text='Shift')
    mods.prop(qme, f'custom_{prefix}_ctrl', toggle=True, text='Ctrl')
    mods.prop(qme, f'custom_{prefix}_alt', toggle=True, text='Alt')
    _draw_icon_label(box, f"{_ui('Current', '現在')}: {_qme_binding_summary(qme, prefix)}")
    _draw_copy_text_row(box, _ui('Operator ID', 'オペレーターID'), operator_id)

# -----------------------------------------------------------------------------
# Smart Transform - Other Tools Preferences (PropertyGroups)
# -----------------------------------------------------------------------------

_SUITE_TOGGLE_APPLY_PENDING = False


def _apply_suite_toggles_deferred():
    _request_prefs_save('suite_toggle_apply')
    global _SUITE_TOGGLE_APPLY_PENDING
    _SUITE_TOGGLE_APPLY_PENDING = False
    try:
        from . import integration
        integration.apply_from_prefs(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _update_suite_toggle(self, context):
    _request_userpref_autosave(context)
    if _is_restoring_settings():
        return
    # Generic dispatcher for enable toggles.  Do not register/unregister Panel
    # classes synchronously from a UI property update, because this can invalidate
    # the active VIEW_3D sidebar panel while Blender is still processing its UI
    # event/layout pass.  Defer the actual apply step to the next timer tick.
    del self, context
    global _SUITE_TOGGLE_APPLY_PENDING
    if _SUITE_TOGGLE_APPLY_PENDING:
        return
    _SUITE_TOGGLE_APPLY_PENDING = True
    try:
        bpy.app.timers.register(_apply_suite_toggles_deferred, first_interval=0.01)
    except Exception:
        _apply_suite_toggles_deferred()


def _update_cursor_lock_feature(self, context):
    _request_userpref_autosave(context)
    if _is_restoring_settings():
        return
    def _sync():
        try:
            from . import cursor_lock as _cursor_lock
            if hasattr(_cursor_lock, 'sync_feature_from_prefs'):
                _cursor_lock.sync_feature_from_prefs(getattr(bpy, 'context', None), save=False)
        except Exception:
            pass
    _defer_ui_task(_sync)



def _update_precision_length_drag(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    del self

    def _sync():
        ctx = getattr(bpy, 'context', None)
        try:
            from . import integration
            integration.apply_from_prefs(ctx)
        except Exception:
            pass
        try:
            from . import precision_length_drag as _precision_length_drag
            if hasattr(_precision_length_drag, 'sync_runtime_from_prefs'):
                _precision_length_drag.sync_runtime_from_prefs(ctx)
        except Exception:
            pass

    _defer_ui_task(_sync)


def _update_precision_length_drag_step(self, context):
    # The operator reads this value when a drag starts; only persistence is
    # required here.  Keep the update lightweight so typing in the spinner does
    # not re-register keymaps or redraw the whole Suite.
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)

def _loaded_module(rel_name: str):
    try:
        full_name = f"{__package__}.{rel_name}"
        return _sts_sys.modules.get(full_name)
    except Exception:
        return None


def _update_qme_keymap_pref(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    _update_suite_toggle(self, context)
    try:
        qme = _loaded_module("quick_multi_edit")
        if qme is not None and callable(getattr(qme, "update_keymap_preference", None)):
            qme.update_keymap_preference(self, context)
    except Exception:
        pass



def _update_smart_gizmo_live_runtime(self, context):
    if not _is_restoring_settings():
        try:
            if hasattr(self, 'smart_gizmo_live_runtime_restore_ack_v13'):
                self.smart_gizmo_live_runtime_restore_ack_v13 = True
        except Exception:
            pass
        try:
            if bool(getattr(self, 'enable_smart_gizmo_live_runtime', False)):
                if hasattr(self, 'gizmo_toggle_state'):
                    self.gizmo_toggle_state = True
                if hasattr(self, 'enable_smart_gizmo_style'):
                    self.enable_smart_gizmo_style = True
        except Exception:
            pass
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    def _sync():
        try:
            from .core import csdt_gizmo, csdt_operators as csdt_ops
            ctx = getattr(bpy, 'context', None)
            if hasattr(csdt_gizmo, "sync_runtime_from_prefs"):
                csdt_gizmo.sync_runtime_from_prefs(ctx)
            if hasattr(csdt_ops, "sync_runtime_from_prefs"):
                csdt_ops.sync_runtime_from_prefs(ctx)
        except Exception:
            pass
    _defer_ui_task(_sync, delay=0.05)


class STS_QuickAlignPrefs(bpy.types.PropertyGroup):
    operator_id: bpy.props.StringProperty(
        name="Operator ID for Keymap",
        default="object.quick_align_tool",
        description="Operator ID for manual shortcut registration. Copy this into Preferences > Keymap if you want your own Quick Align hotkey."
    )
    warp_cursor_after_pick: bpy.props.BoolProperty(
        name="Warp Cursor on Open",
        default=True,
        description="When Start Quick Align opens the dialog, move the cursor aside first so the dialog is less likely to cover that spot. It can still be covered with a small offset or near the window edge."
    )
    warp_offset_px: bpy.props.IntProperty(
        name="Warp Offset (px)",
        default=200,
        min=0,
        soft_max=2000,
        description="How far the cursor moves aside when the Quick Align dialog opens."
    )
    preview_throttle_ms: bpy.props.IntProperty(
        name="Preview Throttle (ms)",
        default=80,
        min=0,
        soft_max=500,
        description="Delay between preview updates in the Align dialog. Increase it for very heavy scenes to keep the preview responsive."
    )
    saved_settings_json: bpy.props.StringProperty(
        name=T('Saved Quick Align Settings JSON'),
        description=T('Hidden compatibility mirror for serialized Quick Align N-panel settings. It is maintained automatically and is not edited manually.'),
        default="",
        options={'HIDDEN'},
    )

class STS_SmartTransformPanelPrefs(bpy.types.PropertyGroup):
    use_scene_orientation: bpy.props.BoolProperty(
        name="Use Scene Transform Orientation",
        description="Always follow the scene's current transform orientation in the Transform popup. Turn this off if you want the popup to keep its own orientation setting.",
        default=True,
    )

    delta_display_mode: bpy.props.EnumProperty(
        name="Delta Display",
        description="Choose how delta fields behave after you enter a value. Knob keeps the last value visible; Auto-Zero returns the field to its neutral starting value after each change.",
        items=[
            ('KNOB', "Knob", "Show last entered value (nudge-style)"),
            ('AUTOZERO', "Auto-Zero", "Always show neutral value and apply input immediately"),
        ],
        default='KNOB',
    )

    delta_scale_style: bpy.props.EnumProperty(
        name="Δ Scale Style",
        description="Choose whether delta scale is entered as a multiplier or as an additive percentage-style offset.",
        items=[
            ('FACTOR', "Factor", "Use multiplicative factor (1.1 = +10%)"),
            ('ADD', "Add Value", "Use additive value (0.1 = +10%, -0.1 = -10%)"),
        ],
        default='FACTOR',
    )

    scale_link_xyz: bpy.props.BoolProperty(
        name=_ui('Legacy Link XYZ Scale', '旧リンクXYZスケール'),
        description=_ui('Legacy compatibility flag used only to migrate the old all-axis scale link setting.', '旧バージョンの全軸スケールリンク設定を移行するためだけに使う互換フラグです。'),
        default=False,
        options={'HIDDEN'},
    )

    scale_link_axes_migrated: bpy.props.BoolProperty(
        name=_ui('Scale Link Axes Migrated', 'スケールリンク軸移行済み'),
        description=_ui('Internal compatibility flag for Smart Transform scale-link axis migration.', 'Smart Transform のスケールリンク軸移行に使う内部互換フラグです。'),
        default=False,
        options={'HIDDEN'},
    )

    scale_link_x: bpy.props.BoolProperty(
        name=_ui('X', 'X'),
        description=_ui(
            'Include X in the Smart Transform scale link group. When X and any other checked scale axes are enabled together, editing one checked axis applies the same value to the whole checked group.',
            'Smart Transform のスケールリンク対象に X を含めます。X と他のチェック済み軸を同時にONにすると、チェックが入っている軸のどれか1つを編集したときに、その値がチェック済みグループ全体へ同じ値で適用されます。',
        ),
        default=False,
    )

    scale_link_y: bpy.props.BoolProperty(
        name=_ui('Y', 'Y'),
        description=_ui(
            'Include Y in the Smart Transform scale link group. When Y and any other checked scale axes are enabled together, editing one checked axis applies the same value to the whole checked group.',
            'Smart Transform のスケールリンク対象に Y を含めます。Y と他のチェック済み軸を同時にONにすると、チェックが入っている軸のどれか1つを編集したときに、その値がチェック済みグループ全体へ同じ値で適用されます。',
        ),
        default=False,
    )

    scale_link_z: bpy.props.BoolProperty(
        name=_ui('Z', 'Z'),
        description=_ui(
            'Include Z in the Smart Transform scale link group. When Z and any other checked scale axes are enabled together, editing one checked axis applies the same value to the whole checked group.',
            'Smart Transform のスケールリンク対象に Z を含めます。Z と他のチェック済み軸を同時にONにすると、チェックが入っている軸のどれか1つを編集したときに、その値がチェック済みグループ全体へ同じ値で適用されます。',
        ),
        default=False,
    )

    pose_each_rotation_mode: bpy.props.EnumProperty(
        name="Pose Rotation (Each)",
        description="Choose how rotation works when multiple pose bones are edited individually. Channel Box edits the rotation channels directly; Oriented Pivot rotates around each bone using the chosen orientation.",
        items=[
            ('CHANNEL', "Channel Box", "Edit bone rotation values (Maya-like, no translation)"),
            ('ORIENT', "Oriented Pivot", "Rotate around bone head using the chosen orientation"),
        ],
        default='CHANNEL',
    )

    keymap_id: bpy.props.StringProperty(
        name="Keymap ID (Copy this)",
        description="Operator ID used when you register a custom shortcut for the Transform popup in Blender's Keymap preferences.",
        default="wm.core",
    )

class STS_QuickMultiEditPrefs(bpy.types.PropertyGroup):
    enable_keymaps: BoolProperty(
        name=_ui('Quick Multi-Edit Hotkeys', 'クイック複数編集ホットキー'),
        description=_ui('Enable the Quick Multi-Edit mouse shortcuts. Turn this off to keep all Quick Multi-Edit background keymap items disabled while keeping the N-panel UI and manual buttons available.', 'クイック複数編集 のマウスショートカットを有効化します。OFF にすると、NパネルUIと手動ボタンは残したまま、クイック複数編集 の常時キーマップ項目を登録しません。'),
        default=False,
        update=_update_qme_keymap_pref,
    )

    use_custom_keymap: BoolProperty(
        name=_ui('Use Custom Keymap', 'カスタムキーマップを使う'),
        description=_ui('When this is ON, Quick Multi-Edit uses the custom Add / Remove / Toggle / Switch-to-clicked-only bindings defined below. The add-on does not create these keymaps automatically; copy the IDs shown at the bottom of this section and register shortcuts manually in Preferences > Keymap.', 'これをONにすると、下で指定した加算・減算・切替・単独切り替えのカスタム割り当てを使います。このアドオンはこれらのキーマップを自動作成しません。セクション最下部のIDをコピーし、プリファレンス > キーマップで手動登録してください。'),
        default=False,
        update=_update_qme_keymap_pref,
    )

    default_mouse_button: EnumProperty(
        name=_ui('Mouse Button (Manual Reference)', '手動登録用マウスボタン'),
        description=_ui("Choose the mouse button reference used when you manually register Quick Multi-Edit shortcuts. Auto follows Blender's current selection style.", "クイック複数編集 のショートカットを手動登録するときのマウスボタン参照を選びます。「自動」は Blender の選択方式に合わせます。"),
        items=[
            ('AUTO', _ui('Auto (match selection style)', '自動'), _ui("Use Blender's current left-click / right-click select preference.", 'Blender の左クリック選択・右クリック選択設定に合わせます。')),
            ('RIGHTMOUSE', _ui('Right Mouse Button', '右クリック'), _ui('Use right click as the manual Quick Multi-Edit shortcut reference.', 'クイック複数編集 の手動登録用参照として右クリックを使います。')),
            ('LEFTMOUSE', _ui('Left Mouse Button', '左クリック'), _ui('Use left click as the manual Quick Multi-Edit shortcut reference.', 'クイック複数編集 の手動登録用参照として左クリックを使います。')),
        ],
        default='RIGHTMOUSE',
        update=_update_qme_keymap_pref,
    )

    custom_add_type: EnumProperty(
        name=_ui('Add Key', '加算キー'),
        description=_ui('Primary key or mouse input used for the Add shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、加算ショートカットで使う主入力です。'),
        items=QME_KEY_TYPE_ITEMS,
        default='RIGHTMOUSE',
        update=_update_qme_keymap_pref,
    )
    custom_add_value: EnumProperty(
        name=_ui('Add Event', '加算イベント'),
        description=_ui('Event type used for the Add shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、加算ショートカットで使うイベント種別です。'),
        items=QME_KEY_VALUE_ITEMS,
        default='PRESS',
        update=_update_qme_keymap_pref,
    )
    custom_add_shift: BoolProperty(name="Shift", description=_ui('Require Shift for the Add shortcut.', '加算ショートカットに Shift を必要にします。'), default=True, update=_update_qme_keymap_pref)
    custom_add_ctrl: BoolProperty(name="Ctrl", description=_ui('Require Ctrl for the Add shortcut.', '加算ショートカットに Ctrl を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_add_alt: BoolProperty(name="Alt", description=_ui('Require Alt for the Add shortcut.', '加算ショートカットに Alt を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_add_oskey: BoolProperty(name=_ui('OSKey', 'OSキー'), description=_ui('Require the OS key for the Add shortcut.', '加算ショートカットに OS キーを必要にします。'), default=False, update=_update_qme_keymap_pref)

    custom_remove_type: EnumProperty(
        name=_ui('Remove Key', '減算キー'),
        description=_ui('Primary key or mouse input used for the Remove shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、減算ショートカットで使う主入力です。'),
        items=QME_KEY_TYPE_ITEMS,
        default='RIGHTMOUSE',
        update=_update_qme_keymap_pref,
    )
    custom_remove_value: EnumProperty(
        name=_ui('Remove Event', '減算イベント'),
        description=_ui('Event type used for the Remove shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、減算ショートカットで使うイベント種別です。'),
        items=QME_KEY_VALUE_ITEMS,
        default='PRESS',
        update=_update_qme_keymap_pref,
    )
    custom_remove_shift: BoolProperty(name="Shift", description=_ui('Require Shift for the Remove shortcut.', '減算ショートカットに Shift を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_remove_ctrl: BoolProperty(name="Ctrl", description=_ui('Require Ctrl for the Remove shortcut.', '減算ショートカットに Ctrl を必要にします。'), default=True, update=_update_qme_keymap_pref)
    custom_remove_alt: BoolProperty(name="Alt", description=_ui('Require Alt for the Remove shortcut.', '減算ショートカットに Alt を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_remove_oskey: BoolProperty(name=_ui('OSKey', 'OSキー'), description=_ui('Require the OS key for the Remove shortcut.', '減算ショートカットに OS キーを必要にします。'), default=False, update=_update_qme_keymap_pref)

    custom_toggle_type: EnumProperty(
        name=_ui('Toggle Key', '切り替えキー'),
        description=_ui('Primary key or mouse input used for the Toggle shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、切り替えショートカットで使う主入力です。'),
        items=QME_KEY_TYPE_ITEMS,
        default='RIGHTMOUSE',
        update=_update_qme_keymap_pref,
    )
    custom_toggle_value: EnumProperty(
        name=_ui('Toggle Event', '切り替えイベント'),
        description=_ui('Event type used for the Toggle shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、切り替えショートカットで使うイベント種別です。'),
        items=QME_KEY_VALUE_ITEMS,
        default='PRESS',
        update=_update_qme_keymap_pref,
    )
    custom_toggle_shift: BoolProperty(name="Shift", description=_ui('Require Shift for the Toggle shortcut.', '切り替えショートカットに Shift を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_toggle_ctrl: BoolProperty(name="Ctrl", description=_ui('Require Ctrl for the Toggle shortcut.', '切り替えショートカットに Ctrl を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_toggle_alt: BoolProperty(name="Alt", description=_ui('Require Alt for the Toggle shortcut.', '切り替えショートカットに Alt を必要にします。'), default=True, update=_update_qme_keymap_pref)
    custom_toggle_oskey: BoolProperty(name=_ui('OSKey', 'OSキー'), description=_ui('Require the OS key for the Toggle shortcut.', '切り替えショートカットに OS キーを必要にします。'), default=False, update=_update_qme_keymap_pref)

    custom_isolate_type: EnumProperty(
        name=_ui('Switch Key', '単独切り替えキー'),
        description=_ui('Optional custom shortcut that clears the current multi-edit set and switches Edit Mode to only the clicked object. Set this to Disabled when you do not need it.', '現在のマルチ編集セットを解除して、クリックしたオブジェクトだけを選択・編集状態に切り替える任意ショートカットです。不要なら 無効 にしてください。'),
        items=QME_KEY_TYPE_ITEMS,
        default='NONE',
        update=_update_qme_keymap_pref,
    )
    custom_isolate_value: EnumProperty(
        name=_ui('Switch Event', '単独切り替えイベント'),
        description=_ui('Event type used for the Switch shortcut when Use Custom Keymap is ON.', 'カスタムキーマップON時に、単独切り替えショートカットで使うイベント種別です。'),
        items=QME_KEY_VALUE_ITEMS,
        default='PRESS',
        update=_update_qme_keymap_pref,
    )
    custom_isolate_shift: BoolProperty(name="Shift", description=_ui('Require Shift for the Switch shortcut.', '単独切り替えショートカットに Shift を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_isolate_ctrl: BoolProperty(name="Ctrl", description=_ui('Require Ctrl for the Switch shortcut.', '単独切り替えショートカットに Ctrl を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_isolate_alt: BoolProperty(name="Alt", description=_ui('Require Alt for the Switch shortcut.', '単独切り替えショートカットに Alt を必要にします。'), default=False, update=_update_qme_keymap_pref)
    custom_isolate_oskey: BoolProperty(name=_ui('OSKey', 'OSキー'), description=_ui('Require the OS key for the Switch shortcut.', '単独切り替えショートカットに OS キーを必要にします。'), default=False, update=_update_qme_keymap_pref)

    active_behavior: EnumProperty(
        name=_ui('Active Behavior', 'アクティブ挙動'),
        description=_ui('Choose what happens to the active object when you click another object.', '別オブジェクトをクリックしたとき、アクティブオブジェクトをどう扱うかを選びます。'),
        items=[
            ('MOVE', _ui('Move Active to Clicked', 'クリック先をアクティブにする'), _ui('Make the clicked object the active one inside the multi-edit set.', 'マルチ編集セット内で、クリックしたオブジェクトをアクティブにします。')),
            ('KEEP', _ui('Keep Current Active', '現在のアクティブを維持'), _ui('Keep the current active object even after changing the multi-edit set.', 'マルチ編集セットを変更しても現在のアクティブを維持します。')),
        ],
        default='MOVE',
    )

    shift_action: EnumProperty(
        name=_ui('Legacy Shift Action', '旧Shift動作'),
        description=_ui('Legacy compatibility property kept only for older saved settings.', '旧保存設定との互換用に残しているレガシープロパティです。'),
        items=[
            ('ADD', "Add", _ui('Legacy compatibility value.', '互換用値です。')),
            ('TOGGLE', "Toggle", _ui('Legacy compatibility value.', '互換用値です。')),
        ],
        default='ADD',
        options={'HIDDEN'},
    )

    # Filters
    restrict_same_type: BoolProperty(
        name=_ui('Restrict to same object type as active', 'アクティブと同種のみ'),
        description=_ui('Only allow objects of the same type as the active object to join the multi-edit set. Useful when you want to avoid mixing meshes, curves, and other object types.', 'アクティブオブジェクトと同じ種類のオブジェクトだけをマルチ編集セットへ追加できます。メッシュとカーブなどを混在させたくない時に便利です。'),
        default=True,
    )
    respect_visibility_select_lock: BoolProperty(
        name=_ui('Respect visibility/selection locks', '非表示・選択不可を尊重'),
        description=_ui('Ignore hidden or selection-locked objects when Quick Multi-Edit builds or edits the set.', 'クイック複数編集 でセットを構築・編集するとき、非表示や選択不可のオブジェクトを無視します。'),
        default=True,
    )
    filter_same_collection: BoolProperty(
        name=_ui('Only same collection', '同じコレクションのみ'),
        description=_ui('Only allow objects that share a collection with the clicked object.', 'クリックしたオブジェクトと同じコレクションを共有しているオブジェクトだけを許可します。'),
        default=False,
    )
    filter_name_prefix: BoolProperty(
        name=_ui('Only same name prefix', '同じ名前接頭辞のみ'),
        description=_ui('Only allow objects whose names begin with the same prefix as the clicked object.', 'クリックしたオブジェクトと同じ接頭辞で始まる名前のオブジェクトだけを許可します。'),
        default=False,
    )
    custom_name_prefix: StringProperty(
        name=_ui('Custom name prefix', 'カスタム接頭辞'),
        description=_ui("Optional manual prefix filter. Leave empty to use the clicked object's prefix automatically when the prefix filter is enabled.", '任意の手動接頭辞フィルターです。空欄なら、接頭辞フィルター有効時にクリックしたオブジェクトの接頭辞を自動使用します。'),
        default="",
    )

    # Picking
    enable_cycle_pick: BoolProperty(
        name=_ui('Enable cycle pick', '背面候補の巡回選択'),
        description=_ui('When several objects overlap under the cursor, allow repeated clicks to cycle through the available targets instead of always choosing only the front-most one.', 'カーソル下で複数オブジェクトが重なるとき、連続クリックで候補を巡回できるようにします。'),
        default=True,
    )
    cycle_timeout: FloatProperty(
        name=_ui('Cycle timeout (sec)', '巡回タイムアウト'),
        description=_ui('How long repeated clicks are treated as one cycling sequence. Increase this if you want more time to step through overlapping objects.', '連続クリックをひとつの巡回操作として扱う秒数です。候補をゆっくり切り替えたい時は値を上げてください。'),
        default=0.5,
        min=0.05,
        max=2.0,
    )
    cycle_pixel_threshold: IntProperty(
        name=_ui('Cycle pixel threshold', '巡回ピクセル閾値'),
        description=_ui('How far the cursor may move before cycle picking resets.', '巡回選択がリセットされるまでに許容するカーソル移動量です。'),
        default=6,
        min=0,
        max=50,
    )
    max_cycle_hits: IntProperty(
        name=_ui('Max cycle hits', '巡回候補上限'),
        description=_ui('Maximum number of overlapping hit candidates collected for cycle pick.', '巡回選択で収集する重なり候補の最大数です。'),
        default=8,
        min=2,
        max=32,
    )

    # Speed
    fast_path_no_mode_toggle: BoolProperty(
        name=_ui('Fast path without mode toggle', 'モード切替なし高速処理'),
        default=True,
        description=_ui('Try to apply selection changes without leaving Edit Mode when possible.', '可能な場合は 編集モード を抜けずに選択変更を適用します。'),
    )

    # Feedback
    show_status_report: BoolProperty(
        name=_ui('Show status report', 'ステータス表示'),
        default=True,
        description=_ui("Show short messages in Blender's status/report area after Quick Multi-Edit actions.", 'クイック複数編集 実行後に Blender のステータス/レポート欄へ短いメッセージを表示します。'),
    )
    show_hud: BoolProperty(
        name=_ui('Show HUD message in viewport', 'ビューポートHUD表示'),
        description=_ui('Show a small message in the viewport after Quick Multi-Edit changes the set, so you can confirm what happened immediately.', 'クイック複数編集 でセットを変更した後、ビューポートに小さなメッセージを表示します。'),
        default=False,
    )
    hud_duration: FloatProperty(
        name=_ui('HUD duration (sec)', 'HUD表示時間'),
        description=_ui('How long the viewport HUD message stays visible after a Quick Multi-Edit action.', 'クイック複数編集 実行後に HUD メッセージを表示する時間です。'),
        default=1.2,
        min=0.1,
        max=10.0,
    )

    # History
    history_depth: IntProperty(
        name=_ui('History depth', '履歴保持数'),
        description=_ui('How many previous multi-edit sets are remembered so you can restore an earlier state.', '以前のマルチ編集セットを復元できるように保持する履歴数です。'),
        default=10,
        min=0,
        max=200,
    )

    # Custom keymap helper IDs
    copy_id_add: StringProperty(name=_ui('Add Operator ID', '加算オペレーターID'), description=_ui('Copy this Operator ID to register the Add shortcut manually.', '加算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_add", options={'SKIP_SAVE'})
    copy_id_remove: StringProperty(name=_ui('Remove Operator ID', '減算オペレーターID'), description=_ui('Copy this Operator ID to register the Remove shortcut manually.', '減算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_remove", options={'SKIP_SAVE'})
    copy_id_toggle: StringProperty(name=_ui('Toggle Operator ID', '切り替えオペレーターID'), description=_ui('Copy this Operator ID to register the Toggle shortcut manually.', '切り替えショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_toggle", options={'SKIP_SAVE'})
    copy_id_isolate: StringProperty(name=_ui('Switch Operator ID', '単独切り替えオペレーターID'), description=_ui('Copy this Operator ID to register the Switch shortcut manually.', '単独切り替えショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_isolate", options={'SKIP_SAVE'})
    copy_id_box_add: StringProperty(name=_ui('Box Add Operator ID', '箱で加算オペレーターID'), description=_ui('Copy this Operator ID to register the box-add shortcut manually.', '箱で加算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_box_add", options={'SKIP_SAVE'})
    copy_id_box_remove: StringProperty(name=_ui('Box Remove Operator ID', '箱で減算オペレーターID'), description=_ui('Copy this Operator ID to register the box-remove shortcut manually.', '箱で減算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_box_remove", options={'SKIP_SAVE'})
    copy_id_box_toggle: StringProperty(name=_ui('Box Toggle Operator ID', '箱で切替オペレーターID'), description=_ui('Copy this Operator ID to register the box-toggle shortcut manually.', '箱で切替のショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_box_toggle", options={'SKIP_SAVE'})
    copy_id_lasso_add: StringProperty(name=_ui('Lasso Add Operator ID', '縄で加算オペレーターID'), description=_ui('Copy this Operator ID to register the lasso-add shortcut manually.', '縄で加算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_lasso_add", options={'SKIP_SAVE'})
    copy_id_lasso_remove: StringProperty(name=_ui('Lasso Remove Operator ID', '縄で減算オペレーターID'), description=_ui('Copy this Operator ID to register the lasso-remove shortcut manually.', '縄で減算ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_lasso_remove", options={'SKIP_SAVE'})
    copy_id_lasso_toggle: StringProperty(name=_ui('Lasso Toggle Operator ID', '縄で切替オペレーターID'), description=_ui('Copy this Operator ID to register the lasso-toggle shortcut manually.', '縄で切替のショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_lasso_toggle", options={'SKIP_SAVE'})
    copy_id_restore: StringProperty(name=_ui('Restore Operator ID', '復元オペレーターID'), description=_ui('Copy this Operator ID to register the restore shortcut manually.', '復元ショートカットを手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_restore_previous", options={'SKIP_SAVE'})
    copy_id_active_collection: StringProperty(name=_ui('Active Collection Operator ID', 'アクティブコレクションオペレーターID'), description=_ui('Copy this Operator ID to register the active-collection tool manually.', 'アクティブコレクション操作を手動登録するための オペレーターID をコピーします。'), default="view3d.quick_multi_edit_from_active_collection", options={'SKIP_SAVE'})

    # Placeholder for future compatibility (not exposed)
    action_isolate_only_clicked: BoolProperty(
        name=_ui('Isolate Only Clicked', 'クリック対象のみ単独化'),
        description=_ui('Hidden compatibility flag retained for older Quick Multi-Edit settings. It is not exposed in the N-panel.', '古い クイック複数編集 設定との互換用に保持する非表示フラグです。Nパネルには表示しません。'),
        default=False,
        options={'HIDDEN'},
    )

def _sync_ssg_load_post_handler(context=None):
    try:
        select_guard = _loaded_module("select_guard")
        if select_guard is None:
            return
        sync = getattr(select_guard, "_sync_load_post_handler", None)
        if callable(sync):
            sync(context or getattr(bpy, "context", None))
    except Exception:
        pass


_SSG_SCENE_RUNTIME_APPLY_PENDING = False


def _suite_prefs(context=None):
    try:
        from . import runtime as _runtime
        return _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        return None


def _apply_ssg_scene_runtime_pref_deferred():
    global _SSG_SCENE_RUNTIME_APPLY_PENDING
    _SSG_SCENE_RUNTIME_APPLY_PENDING = False
    try:
        context = getattr(bpy, 'context', None)
        prefs = _suite_prefs(context)
        ssg = getattr(prefs, 'select_guard', None) if prefs is not None else None
        enabled = bool(getattr(ssg, 'pref_scene_runtime_enabled', False)) if ssg is not None else False
        try:
            from . import integration as _integration
            if hasattr(_integration, 'apply_from_prefs'):
                _integration.apply_from_prefs(context)
        except Exception:
            pass
        scene = getattr(context, 'scene', None) if context is not None else None
        if scene is not None and hasattr(scene, 'select_guard_enabled'):
            try:
                setattr(scene, 'select_guard_enabled', enabled)
            except Exception:
                pass
        _sync_ssg_load_post_handler(context)
        if enabled:
            try:
                sg = _loaded_module('select_guard')
                runner = getattr(sg, '_load_post_sync_deferred_tick', None) if sg is not None else None
                if callable(runner):
                    _defer_ui_task(runner, delay=0.05)
            except Exception:
                pass
    except Exception:
        pass
    return None


def _request_ssg_scene_runtime_pref_apply():
    global _SSG_SCENE_RUNTIME_APPLY_PENDING
    if _SSG_SCENE_RUNTIME_APPLY_PENDING:
        return
    _SSG_SCENE_RUNTIME_APPLY_PENDING = True
    try:
        bpy.app.timers.register(_apply_ssg_scene_runtime_pref_deferred, first_interval=0.05)
    except Exception:
        _apply_ssg_scene_runtime_pref_deferred()


def _update_ssg_apply_defaults_pref(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    _update_suite_toggle(self, context)
    _defer_ui_task(lambda: _sync_ssg_load_post_handler(getattr(bpy, 'context', None)), delay=0.05)


def _update_ssg_scene_runtime_pref(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    _update_suite_toggle(self, context)
    # Defer syncing Scene.select_guard_enabled and modal startup so a preference
    # checkbox cannot mutate runtime handlers during a UI panel event.
    del self, context
    _request_ssg_scene_runtime_pref_apply()

def _update_ssg_setting_pref(self, context):
    _request_userpref_autosave(context)
    if _is_restoring_settings():
        return
    # These are Smart Select Guard N-panel/popup settings stored in
    # Smart_Transform_Suite.json.  Keep the save asynchronous so Blender 5.1 does
    # not redraw Sidebar panels while their native handler is still active.
    del self
    _defer_ui_task(lambda: _sync_ssg_load_post_handler(getattr(bpy, 'context', None)), delay=0.05)



_SSG_HOLD_ENABLE_KEY_ITEMS = (
    ('NONE', _ui('Always', '常時'), _ui('Do not require a hold key. Smart Select Guard works whenever its main toggle is ON.', '指定キーを要求しません。スマート選択ガード の主スイッチがONの間は常に機能します。')),
    ('Q', _ui('Q Key', 'Qキー'), _ui('Use Q as the non-modifier key that enables Smart Select Guard only while it is held.', 'Qキーを押している間だけ スマート選択ガード を有効にします。')),
    ('W', _ui('W Key', 'Wキー'), _ui('Use W as the non-modifier key that enables Smart Select Guard only while it is held.', 'Wキーを押している間だけ スマート選択ガード を有効にします。')),
    ('E', _ui('E Key', 'Eキー'), _ui('Use E as the non-modifier key that enables Smart Select Guard only while it is held.', 'Eキーを押している間だけ スマート選択ガード を有効にします。')),
    ('D', _ui('D Key', 'Dキー'), _ui('Use D as the non-modifier key that enables Smart Select Guard only while it is held.', 'Dキーを押している間だけ スマート選択ガード を有効にします。')),
    ('F', _ui('F Key', 'Fキー'), _ui('Use F as the non-modifier key that enables Smart Select Guard only while it is held.', 'Fキーを押している間だけ スマート選択ガード を有効にします。')),
    ('V', _ui('V Key', 'Vキー'), _ui('Use V as the non-modifier key that enables Smart Select Guard only while it is held.', 'Vキーを押している間だけ スマート選択ガード を有効にします。')),
    ('X', _ui('X Key', 'Xキー'), _ui('Use X as the non-modifier key that enables Smart Select Guard only while it is held.', 'Xキーを押している間だけ スマート選択ガード を有効にします。')),
    ('Z', _ui('Z Key', 'Zキー'), _ui('Use Z as the non-modifier key that enables Smart Select Guard only while it is held.', 'Zキーを押している間だけ スマート選択ガード を有効にします。')),
    ('TAB', _ui('Tab Key', 'Tabキー'), _ui('Use Tab as the non-modifier key that enables Smart Select Guard only while it is held.', 'Tabキーを押している間だけ スマート選択ガード を有効にします。')),
    ('SPACE', _ui('Space Key', 'スペースキー'), _ui('Use Space as the non-modifier key that enables Smart Select Guard only while it is held.', 'スペースキーを押している間だけ スマート選択ガード を有効にします。')),
    ('ACCENT_GRAVE', _ui('Accent Key', 'アクセントキー'), _ui('Use the accent/grave key as the non-modifier key that enables Smart Select Guard only while it is held.', 'アクセント/グレーブキーを押している間だけ スマート選択ガード を有効にします。')),
)


class STS_SmartSelectGuardPrefs(bpy.types.PropertyGroup):
    toggle_operator_id: bpy.props.StringProperty(
        name="Shortcut Toggle Operator ID",
        description="Copy this ID and assign a shortcut in Preferences > Keymap.",
        default="view3d.select_guard_toggle",
        options={'SKIP_SAVE'},
    )

    apply_defaults_on_file_load: bpy.props.BoolProperty(
        name=_ui('Use Preferences as Defaults on File Load', 'ファイル読込時に設定を既定値として適用'),
        description=_ui('If enabled, apply the preference defaults to a scene once after loading a file. Turn this on only when Smart Select Guard should initialize scenes automatically.', '有効にすると、ファイル読込時にスマート選択ガードの既定設定をシーンへ一度適用します。シーン初期化を自動化したい場合だけONにしてください。'),
        default=False,
        update=_update_ssg_apply_defaults_pref,
    )

    pref_scene_runtime_enabled: bpy.props.BoolProperty(
        name=_ui('Smart Select Guard Scene Runtime', 'スマート選択ガードシーン常時監視'),
        description=_ui('Enable the Smart Select Guard modal watcher for the current scene and keep this preference as the default for future scene setup. Leave this off for lighter idle performance.', '現在のシーンでスマート選択ガードのモーダル監視を有効にし、この設定を今後のシーン用の既定値として保存します。待機時の負荷を下げる場合はOFFにしてください。'),
        default=False,
        update=_update_ssg_scene_runtime_pref,
    )

    # defaults
    pref_quality_preset: bpy.props.EnumProperty(
        name="Quality Preset",
        description="Choose the balance between speed and precision for occlusion checks. Fast is lighter; Precise performs more sampling.",
        items=[
            ('FAST', "Fast", "Use fewer checks for better speed in heavy scenes."),
            ('BALANCED', "Balanced", "Use a practical balance between speed and reliability."),
            ('PRECISE', "Precise", "Use more checks for stricter occlusion filtering."),
            ('CUSTOM', "Custom", "Use the detailed manual values below instead of a preset."),
        ],
        default='BALANCED',
        update=_update_ssg_setting_pref,
    )

    pref_view_scope: bpy.props.EnumProperty(
        name="View Scope",
        description="Choose whether Smart Select Guard works only in the current 3D View or across all 3D Views.",
        items=[
            ('ACTIVE', "Active View Only", "Only the current 3D View uses Smart Select Guard."),
            ('ALL', "All 3D Views", "Apply Smart Select Guard to every open 3D View."),
        ],
        default='ACTIVE',
        update=_update_ssg_setting_pref,
    )

    pref_other_objects_occlude: bpy.props.BoolProperty(
        name="Enable Other Objects Occlusion",
        description="When enabled, other objects in the scene can block selection of the current object or mesh elements. Turn this off if you only want self-occlusion rules.",
        default=False,
        update=_update_ssg_setting_pref,
    )

    pref_multi_edit_mutual_occlude: bpy.props.BoolProperty(
        name="Enable Mutual Occlusion for Multi-Edit",
        description="When editing multiple selected objects, allow them to block each other during visibility checks. Turn this off if you want each edited object judged more independently.",
        default=True,
        update=_update_ssg_setting_pref,
    )

    pref_click_filter: bpy.props.BoolProperty(
        name="Enable Click Select Filtering",
        description="Apply Smart Select Guard even to normal single clicks. Turn this off if you only want it to affect drag-based selection tools.",
        default=True,
        update=_update_ssg_setting_pref,
    )

    pref_auto_bypass_xray: bpy.props.BoolProperty(
        name="Auto Bypass in X-Ray",
        description="Temporarily relax Smart Select Guard when X-Ray is active so X-Ray can still be used as an intentional select-through workflow.",
        default=True,
        update=_update_ssg_setting_pref,
    )

    pref_select_through_xray_off: bpy.props.BoolProperty(
        name=_ui('Select Through when X-Ray Off', '透過表示OFF時も背面選択'),
        description=_ui(
            'When the viewport X-Ray display is off, temporarily enable X-Ray from the moment a selection drag starts (circle select: from the press) so back-side and occluded mesh elements can be selected. When the button is released and the selection is confirmed, the original X-Ray state is restored even if nothing was selected. A plain click (except with circle select) does not start it.',
            'ビューの透過表示がOFFの時、選択ドラッグを始めた時点（サークル選択は押した時点）から一時的に透過表示をONにして、背面や遮蔽されたメッシュ要素も選択できるようにします。ボタンを離して選択が確定した時点で、無選択の場合も含め元の透過表示状態へ戻します。クリックだけの選択（サークル選択を除く）では切り替えません。',
        ),
        default=False,
        update=_update_ssg_setting_pref,
    )

    pref_auto_bypass_wireframe: bpy.props.BoolProperty(
        name="Auto Bypass in Wireframe",
        description="Temporarily relax Smart Select Guard when Wireframe is active so wireframe inspection stays practical.",
        default=True,
        update=_update_ssg_setting_pref,
    )

    pref_ignore_backface: bpy.props.BoolProperty(
        name="Ignore Backfacing Occluders",
        description="Ignore polygons facing away from the view when judging occlusion. This can make back-side shells less likely to block selection.",
        default=False,
        update=_update_ssg_setting_pref,
    )

    pref_hold_bypass_key: bpy.props.EnumProperty(
        name="Hold-to-Bypass Key",
        description="Deprecated hidden compatibility setting. Modifier-key bypass is disabled because it conflicts with Blender standard Shift/Ctrl/Alt selection behavior.",
        items=[
            ('NONE', "None", "Do not use a hold-to-bypass modifier key."),
            ('SHIFT', "Shift", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
            ('CTRL', "Ctrl", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
            ('ALT', "Alt", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
        ],
        default='NONE',
        update=_update_ssg_setting_pref,
    )

    pref_hold_enable_key: bpy.props.EnumProperty(
        name=_ui('Enable-While-Held Key', '有効キー'),
        description=_ui('Legacy hidden compatibility setting. Use the Smart Select Guard shortcut button instead of this pull-down.', '互換用の非表示設定です。プルダウンではなくスマート選択ガードのショートカット割り当てボタンを使用してください。'),
        items=_SSG_HOLD_ENABLE_KEY_ITEMS,
        default='NONE',
        update=_update_ssg_setting_pref,
    )

    pref_hold_enable_key_event: bpy.props.StringProperty(
        name=_ui('Enable-While-Held Shortcut Event', '有効キーイベント'),
        description=_ui('Stored event identifier for the Smart Select Guard enable-while-held shortcut. Right-click the shortcut button and assign any key to change it.', 'スマート選択ガードの押している間だけ有効ショートカット用イベント識別子です。ショートカットボタンを右クリックし、任意のキーを割り当てて変更します。'),
        default='',
        options={'HIDDEN'},
        update=_update_ssg_setting_pref,
    )

    pref_show_status_feedback: bpy.props.BoolProperty(
        name="Show Status Feedback",
        description="Show short status messages when Smart Select Guard blocks or bypasses a selection.",
        default=True,
        update=_update_ssg_setting_pref,
    )

    pref_partial_visible_ratio_min: bpy.props.FloatProperty(
        name="Partial Visibility Threshold",
        description="If > 0, require this visible ratio for edges/faces to be treated as visible (0 = any visible sample counts).",
        min=0.0,
        max=1.0,
        default=0.0,
        subtype='FACTOR',
        update=_update_ssg_setting_pref,
    )

    pref_cache_seconds: bpy.props.FloatProperty(
        name="Cache Seconds",
        description="Keep recent occlusion results for this many seconds to reduce repeated recalculation. Lower values update more often, while higher values can feel faster.",
        min=0.0,
        max=1.0,
        default=0.15,
        precision=3,
        update=_update_ssg_setting_pref,
    )

    pref_idle_signature_skip: bpy.props.IntProperty(
        name="Idle Signature Skip",
        description="How many idle checks are skipped before Smart Select Guard refreshes its internal state again. Higher values reduce overhead.",
        min=1,
        max=12,
        default=4,
        update=_update_ssg_setting_pref,
    )

    pref_target_depth_margin: bpy.props.FloatProperty(
        name="Target Depth Margin",
        description="Extra depth margin used when comparing the clicked target against possible occluders. Increase it slightly if near-surface picks feel too strict.",
        min=0.0,
        max=0.02,
        default=0.0030,
        precision=5,
        update=_update_ssg_setting_pref,
    )




class STS_MeshVertexToolsPrefs(bpy.types.PropertyGroup):
    # Basic helpers for mesh component workflows (panel + optional keymaps)
    operator_id_panel: StringProperty(
        name="Operator ID (Panel)",
        description="Copy this ID if you want to assign a shortcut to open the Vertex Tools panel category quickly.",
        default="view3d.sts_vertex_tools_dummy",
        options={'SKIP_SAVE'},
    )
    show_panel: BoolProperty(
        name="Show Vertex Tools Panel",
        description="Show the Vertex Tools panel in the 3D View sidebar (Edit Mesh).",
        default=True,
    )

# =========================================================
# Proxy Callback Functions
# 循環参照を防ぐため、関数内でモジュールを遅延インポートします
# =========================================================
def _update_csdt_behavior_pref(self, context):
    """Persist and synchronize Smart Transform click behavior settings."""
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    def _sync():
        try:
            from .core import csdt_operators as csdt_ops
            ctx = getattr(bpy, 'context', None)
            if hasattr(csdt_ops, 'sync_runtime_from_prefs'):
                csdt_ops.sync_runtime_from_prefs(ctx)
            if hasattr(csdt_ops, 'ensure_csdt_keymap_repair_runtime'):
                csdt_ops.ensure_csdt_keymap_repair_runtime(ctx)
        except Exception:
            pass
    try:
        _sync()
    except Exception:
        pass
    _defer_ui_task(_sync, delay=0.03)


def _update_smart_gizmo_settings(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    def _sync():
        try:
            from .core import csdt_gizmo
            csdt_gizmo._update_smart_gizmo_settings(self, getattr(bpy, 'context', None))
        except Exception:
            pass
    _defer_ui_task(_sync, delay=0.05)

def _update_gizmo_pick_factor(self, context):
    _request_userpref_autosave(context)
    if _is_restoring_settings():
        return
    def _sync():
        try:
            from .core import csdt_gizmo
            if hasattr(csdt_gizmo, "_update_gizmo_pick_factor"):
                csdt_gizmo._update_gizmo_pick_factor(self, getattr(bpy, 'context', None))
        except Exception:
            pass
    _defer_ui_task(_sync, delay=0.05)



def _update_csdt_keymap_priority(self, context):
    _request_userpref_autosave(context)
    _save_always_on_change_now(context)
    if _is_restoring_settings():
        return
    enabled = bool(getattr(self, 'prefer_csdt_keymap_priority', False))
    def _sync():
        try:
            from .core import csdt_operators as csdt_ops
            ctx = getattr(bpy, 'context', None)
            csdt_ops.apply_csdt_keymap_priority(ctx, enabled)
            if hasattr(csdt_ops, 'ensure_csdt_keymap_repair_runtime'):
                csdt_ops.ensure_csdt_keymap_repair_runtime(ctx)
        except Exception:
            pass
    _defer_ui_task(_sync, delay=0.05)


def _update_overlay_aa_mode(self, context):
    """Redraw viewports when AA mode changes."""
    _request_userpref_autosave(context)
    if _is_restoring_settings():
        return
    def _redraw():
        try:
            from .core import csdt_utils
            csdt_utils._tag_view3d_redraw()
        except Exception:
            pass
    _defer_ui_task(_redraw, delay=0.05)


# =========================================================
# Preferences & Operators
# =========================================================
class VIEW3D_OT_csdt_reset_settings(bpy.types.Operator):
    bl_idname = "view3d.csdt_reset_settings"
    bl_label = "Reset Settings"
    bl_description = "Restore the settings in this section to their default values"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    category: bpy.props.StringProperty(
        name=T('Settings Category'),
        description=T('Internal settings category to reset. This is set by the N-panel reset button and is not edited manually.'),
        default='',
        options={'HIDDEN'},
    )

    def execute(self, context):
        prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
        if not prefs:
            return {'CANCELLED'}
        target = prefs
        props = []
        if self.category == 'TARGET_TOOLS':
            props = ['enable_move', 'enable_rotate', 'enable_scale', 'enable_transform']
        elif self.category == 'SELECTION':
            props = ['use_immediate_select', 'smart_gizmo_click_select_priority', 'keep_multi_selection', 'update_active_element', 'enable_click_through', 'enable_back_element_click_select', 'crossing_select_edges', 'crossing_select_faces']
        elif self.category == 'TRANSFORM':
            props = ['enable_drag_transform', 'enable_axis_memory', 'smart_gizmo_use_circular_rotation', 'smart_gizmo_use_distance_scale', 'tool_disallow_negative_scale']
        elif self.category == 'BACKGROUND':
            props = ['enable_bg_deselect', 'enable_bg_drag_select']
        elif self.category == 'SENSITIVITY':
            props = ['drag_threshold', 'vert_hit_radius', 'edge_hit_radius', 'g_normal', 'g_shift', 'r_normal', 'r_shift', 's_normal', 's_shift']
        elif self.category == 'SMART_GIZMO':
            props = [
                'enable_smart_gizmo_live_runtime', 'enable_smart_gizmo_style', 'smart_gizmo_screen_scale', 
                'smart_axis_scale', 'smart_plane_scale', 'smart_center_scale', 
                'gizmo_pick_range_px', 'color_x', 'color_y', 'color_z', 
                'color_free', 'color_highlight'
            ]
        elif self.category == 'GRS_SENSITIVITY':
            props = ['g_normal', 'g_shift', 'r_normal', 'r_shift', 's_normal', 's_shift']
        elif self.category == 'GRS_PROPORTIONAL':
            props = ['show_orange_circle', 'enable_prop_cursor_lock', 'circle_color', 'circle_line_width']
        elif self.category == 'GRS_AXIS':
            props = [
                'enable_middle_mouse_plane', 'draw_axis_lines_in_front', 
                'axis_line_width', 'axis_line_width_active', 
                'axis_color_x', 'axis_color_y', 'axis_color_z', 
                'axis_color_dark_x', 'axis_color_dark_y', 'axis_color_dark_z'
            ]
        
        if target is None:
            return {'CANCELLED'}

        for p in props:
            target.property_unset(p)
            
        try:
            from .core import csdt_utils
            csdt_utils._tag_view3d_redraw()
        except Exception:
            pass
        
        return {'FINISHED'}


class CSDT_Preferences(bpy.types.PropertyGroup):
    bl_idname = _addon_root_id()

    npanel_settings_json: bpy.props.StringProperty(
        name=_ui('Persistent N-panel Settings JSON', 'Nパネル常時保存JSON'),
        description=_ui(
            'Internal saved-preferences mirror for all Smart Transform N-panel settings. This is not a user-facing control; the editable UI is consolidated in the N-panel.',
            'Smart Transform のNパネル設定を内部保持するためのミラーです。ユーザーが操作する項目ではありません。編集UIはNパネルに集約されています。',
        ),
        default='',
        options={'HIDDEN'},
    )
    persistent_feature_toggles_json: bpy.props.StringProperty(
        name=_ui('Persistent Runtime Feature Toggles JSON', '常時発動機能切替保存JSON'),
        description=_ui(
            'Internal saved-preferences mirror for always-on runtime feature switches. This is not a user-facing control; use the N-panel switches.',
            '常時発動機能スイッチを内部保持するためのミラーです。ユーザーが操作する項目ではありません。Nパネルのスイッチを使用します。',
        ),
        default='',
        options={'HIDDEN'},
    )

    npanel_state_save_enabled: bpy.props.BoolProperty(
        name=_ui('N-panel State Save', 'Nパネル状態保存'),
        description=_ui(
            'When enabled, every Smart Transform N-panel setting change is written atomically to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json after the current UI event and restored after restart. Turning this OFF writes that OFF state exactly once; no later force, direct, file-load, or shutdown path writes settings until it is enabled again.',
            '有効の場合、Smart Transform Nパネルで行った全設定変更を現在のUIイベント終了後に Blender設定フォルダーの Smart_Transform_Suite/Smart_Transform_Suite.json へアトミック保存し、再起動後に復元します。OFFへ切り替えた時はそのOFF状態を一度だけ保存し、その後は再びONにするまで、強制・直接・ファイル読込・終了処理からも設定を書き込みません。',
        ),
        default=True,
        update=_update_npanel_state_save_enabled,
    )



    enable_mesh_island_transform: bpy.props.BoolProperty(
        name=_ui('Island Transform', 'アイランド変形'),
        description=_ui(
            'Always-on switch for Mesh Island Transform. The value is stored in Smart_Transform_Suite.json and is independent of the current .blend scene. When enabled, Smart Transform G / R / S and the 3D Smart Gizmo can transform connected selected mesh islands as units.',
            'メッシュ用アイランド変形の常時起動スイッチです。値は現在の.blendシーンに依存せず Smart_Transform_Suite.json に保存されます。有効時、Smart Transform の G / R / S と3Dスマートギズモは、接続された選択メッシュアイランドを単位として変形できます。',
        ),
        default=False,
        update=_update_mesh_island_transform_always_on,
    )
    mesh_island_transform_individual_pivot_only: bpy.props.BoolProperty(
        name=_ui('Use Only With Individual Origins Pivot', '「それぞれの基点」の時だけ使用'),
        description=_ui(
            'When enabled, Island Transform becomes active only in Edit Mesh mode while Blender Transform Pivot Point is Individual Origins. Median, Cursor, Active, and Bounding Box pivot modes use normal Smart Transform behavior. Turn this off to use Island Transform in every pivot mode while its always-on switch is enabled.',
            '有効の場合、アイランド変形はメッシュ編集中かつBlenderのトランスフォームピボットポイントが「それぞれの基点」の時だけ有効になります。中央値、3Dカーソル、アクティブ、バウンディングボックスの各ピボットでは通常のSmart Transform挙動を使います。常時起動スイッチが有効な間、全ピボットでアイランド単位変形を使う場合はOFFにしてください。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('mesh_island_transform_individual_pivot_only'),
    )
    mesh_island_transform_toggle_operator_id: bpy.props.StringProperty(
        name=_ui('Island Transform Toggle Operator ID', 'アイランド変形切り替えID'),
        description=_ui('Operator ID for manual keymap registration of the Island Transform ON/OFF toggle.', 'アイランド変形のON/OFF切り替えを手動キーマップ登録するためのオペレーターIDです。'),
        default='mesh.smart_island_transform_toggle',
        options={'SKIP_SAVE'},
    )
    mesh_island_transform_move_operator_id: bpy.props.StringProperty(
        name=_ui('Island Move Operator ID', 'アイランド移動ID'),
        description=_ui('Operator ID for optional G-key island move registration in the Mesh keymap.', 'メッシュキーマップで任意のGキー形式アイランド移動を登録するためのオペレーターIDです。'),
        default='mesh.smart_island_move',
        options={'SKIP_SAVE'},
    )
    mesh_island_transform_rotate_operator_id: bpy.props.StringProperty(
        name=_ui('Island Rotate Operator ID', 'アイランド回転ID'),
        description=_ui('Operator ID for optional R-key island rotate registration in the Mesh keymap.', 'メッシュキーマップで任意のRキー形式アイランド回転を登録するためのオペレーターIDです。'),
        default='mesh.smart_island_rotate',
        options={'SKIP_SAVE'},
    )
    mesh_island_transform_scale_operator_id: bpy.props.StringProperty(
        name=_ui('Island Scale Operator ID', 'アイランドスケールID'),
        description=_ui('Operator ID for optional S-key island scale registration in the Mesh keymap.', 'メッシュキーマップで任意のSキー形式アイランドスケールを登録するためのオペレーターIDです。'),
        default='mesh.smart_island_scale',
        options={'SKIP_SAVE'},
    )

    # ---------------------------------------------------------
    enable_smart_gizmo_live_runtime: bpy.props.BoolProperty(
        name=_ui('3D Smart Gizmo Live Runtime', '3Dスマートギズモ・ライブランタイム'),
        description=_ui(
            'Keep the 3D Smart Gizmo draw handler and live viewport watchers running continuously after startup.\n\nDefault: OFF to keep Blender startup and idle use light. Turn this ON only when you want the custom 3D Smart Gizmo overlay and live hover response to stay ready without launching a tool first.',
            '3Dスマートギズモの描画ハンドラとビューポート監視を起動後も常時動かします。\n\n初期値はOFFです。Blenderの起動時と待機時を軽く保ちます。ツールを起動しなくても独自の3Dスマートギズモ表示とライブホバー反応を常時待機させたい場合だけONにしてください。',
        ),
        default=False,
        update=_update_smart_gizmo_live_runtime,
    )

    smart_gizmo_live_runtime_restore_ack_v13: bpy.props.BoolProperty(
        name=_ui('Smart Gizmo Live Runtime Restore Acknowledged', 'スマートギズモ常時ランタイム復元確認済み'),
        description=_ui(
            'Hidden migration flag used to distinguish an intentionally enabled live runtime from older saved values that could start a window-wide modal watcher immediately after installation.',
            'インストール直後にウィンドウ全体のモーダル監視を起動してしまう旧保存値と、意図的に有効化された常時ランタイムを区別するための非表示移行フラグです。',
        ),
        default=False,
        options={'HIDDEN'},
    )

    runtime_load_defaults_seeded_v28: bpy.props.BoolProperty(
        name=_ui('Runtime Defaults Seeded', 'ランタイム既定値シード済み'),
        description=_ui('Hidden migration flag used to avoid applying startup default values more than once after upgrading this add-on.', 'このアドオン更新後に起動時既定値を複数回適用しないための非表示移行フラグです。'),
        default=False,
        options={'HIDDEN'},
    )

    # ---------------------------------------------------------
    # Toolset: Other Tools Enable Toggles
    # ---------------------------------------------------------
    enable_core_panel: bpy.props.BoolProperty(
        name=_ui('Enable Smart Transform Panel', 'Smart Transformパネルを有効化'),
        default=True,
        description=_ui(
            'Enable the Smart Transform numeric and delta input panel in the standard 3D View Sidebar N-panel, plus its popup. This module is independent from the 3D Smart Gizmo / Smart GRS.',
            '3Dビューの標準Nパネルで Smart Transform の数値入力と差分入力パネル、およびポップアップを有効にします。このモジュールは3Dスマートギズモ / Smart G-R-Sとは独立しています。',
        ),
        update=_update_suite_toggle,
    )
    enable_quick_align: bpy.props.BoolProperty(
        name=_ui('Enable Quick Align', 'クイック整列を有効化'),
        default=True,
        description=_ui(
            'Enable Quick Align tools. Provides fast alignment and target picking helpers. Disable this when you do not use alignment workflows or want to keep this module unloaded.',
            'クイック整列 ツールを有効化します。高速な整列とターゲットピック補助を使えるようにします。整列ワークフローを使わない場合や、このモジュールを読み込まず軽くしたい場合は無効にしてください。',
        ),
        update=_update_suite_toggle,
    )
    enable_quick_multi_edit: bpy.props.BoolProperty(
        name=_ui('Enable Quick Multi-Edit', 'クイック複数編集を有効化'),
        default=True,
        description=_ui(
            'Enable the Quick Multi-Edit selection module. It adds fast multi-object selection helpers such as click add/remove/toggle, box selection, lasso selection, and cycle picking. Disable this when you want the module to stay unloaded.',
            'クイック複数編集 選択モジュールを有効化します。クリック追加・除外・切り替え、ボックス選択、投げ縄選択、巡回選択などの高速な複数編集補助を追加します。このモジュールを読み込まず軽くしたい場合は無効にしてください。',
        ),
        update=_update_suite_toggle,
    )
    enable_select_guard: bpy.props.BoolProperty(
        name=_ui('Enable Smart Select Guard', 'スマート選択ガードを有効化'),
        default=True,
        description=_ui(
            'Enable the Smart Select Guard module. It adds selection occlusion and bypass helpers to reduce accidental picking behind visible objects. Disable this when you want the module to stay unloaded.',
            'スマート選択ガード モジュールを有効化します。表示中オブジェクトの背後を誤選択しにくくする遮蔽判定とバイパス補助を追加します。このモジュールを読み込まず軽くしたい場合は無効にしてください。',
        ),
        update=_update_suite_toggle,
    )
    enable_cursor_lock_feature: bpy.props.BoolProperty(
        name=_ui('Enable 3D Cursor Lock Feature', '3Dカーソルロック機能を有効化'),
        default=False,
        description=_ui(
            'Enable or disable the 3D Cursor Lock feature itself inside Smart Transform. When this is ON, the original icon toggle is shown in the 3D View header and that header button is used to lock or unlock the 3D Cursor. Turning this OFF hides the header button and also clears any active 3D Cursor lock state so the cursor moves normally again.',
            'Smart Transform 内の 3Dカーソルロック機能自体を有効または無効にします。ON の間は、元ツールと同じアイコン切替が 3Dビューヘッダーに表示され、そのヘッダーボタンで3Dカーソルのロック / アンロックを切り替えます。OFF にするとヘッダーボタンを非表示にし、現在有効な3Dカーソルロック状態も解除して、再び通常どおり動かせるようにします。',
        ),
        update=_update_cursor_lock_feature,
    )

    enable_precision_length_drag: bpy.props.BoolProperty(
        name=_ui('Enable Precision Numeric Drag', '精密数値ドラッグを有効化'),
        default=False,
        description=_ui(
            "Enable the manually registered Shift-left precision drag for editable Blender Rotation, Length, Mass, Time, and Temperature float spinners. Register wm.smart_transform_precision_numeric_drag in Preferences > Keymap > Screen > Screen Editing as Shift + Left Mouse / Press. The five steps use the active scene's Blender Unit Settings. Incompatible fields and viewport/tool gestures are immediately passed through unchanged. Release the left mouse button to confirm, or press Esc / right click to restore the starting value.",
            'Blenderの「回転」「長さ」「質量」「時間」「温度」に属する編集可能な小数数値スピナーで、手動登録したShift+左精密ドラッグを有効化します。wm.smart_transform_precision_numeric_drag を、プリファレンス > キーマップ > スクリーン > スクリーン編集 に Shift + 左マウス / 押下 として登録してください。5種類の刻みは現在のシーンのBlender単位設定を使用します。対象外の数値欄や3Dビュー・各ツールの操作は変更せず直ちにBlenderへ返します。左ボタンを離すと確定し、Escまたは右クリックで開始値へ戻します。',
        ),
        update=_update_precision_length_drag,
    )

    # Legacy value kept for old saved preferences. It is no longer shown in the UI.
    precision_length_drag_step_cm: bpy.props.FloatProperty(
        name=_ui('Legacy Numeric Drag Step', '旧精密数値ドラッグ刻み'),
        default=0.01,
        min=0.000001,
        precision=4,
        step=1,
        options={'HIDDEN'},
        description=_ui(
            'Compatibility value from older builds. Precision Numeric Drag now uses unit-specific step settings below.',
            '旧バージョンとの互換用値です。現在の精密数値ドラッグは下記の単位別刻み設定を使用します。',
        ),
        update=_update_precision_length_drag_step,
    )

    # Precision Numeric Drag mirrors Blender's five Scene Unit Settings.
    # Rotation/length/mass/time use Blender RNA units directly. Temperature is a
    # plain delta with an adjacent current-unit label because Blender TEMPERATURE
    # RNA values are absolute and would apply Celsius offsets to a step value.
    precision_numeric_drag_step_rotation: bpy.props.FloatProperty(
        name=_ui('Rotation', '回転'),
        default=math.radians(1.0),
        min=1.0e-9,
        soft_max=math.radians(90.0),
        precision=6,
        step=1,
        unit='ROTATION',
        subtype='ANGLE',
        description=_ui(
            'Precision step for editable rotation and angle fields. The displayed unit follows Scene Properties > Units > Rotation, while Blender stores and applies the value in its native rotation unit.',
            '編集可能な回転・角度欄に適用する精密刻みです。表示単位は「シーンプロパティ > 単位 > 回転」に従い、Blender内部の回転単位へ自動変換して適用します。',
        ),
        update=_update_precision_length_drag_step,
    )
    precision_numeric_drag_step_length: bpy.props.FloatProperty(
        name=_ui('Length', '長さ'),
        default=0.01,
        min=1.0e-9,
        soft_max=1000.0,
        precision=6,
        step=1,
        unit='LENGTH',
        subtype='DISTANCE',
        description=_ui(
            'Precision step for editable length, distance, translation, and XYZ length fields. The displayed unit follows the active scene unit system, scale, and Length setting.',
            '編集可能な長さ・距離・移動・XYZ長さ欄に適用する精密刻みです。表示単位は現在のシーンの単位系、単位倍率、および「長さ」設定に従います。',
        ),
        update=_update_precision_length_drag_step,
    )
    precision_numeric_drag_step_mass: bpy.props.FloatProperty(
        name=_ui('Mass', '質量'),
        default=0.01,
        min=1.0e-9,
        soft_max=1000.0,
        precision=6,
        step=1,
        unit='MASS',
        subtype='NONE',
        description=_ui(
            'Precision step for editable mass fields. The displayed unit follows Scene Properties > Units > Mass.',
            '編集可能な質量欄に適用する精密刻みです。表示単位は「シーンプロパティ > 単位 > 質量」に従います。',
        ),
        update=_update_precision_length_drag_step,
    )
    # Physical time step stored in seconds. Blender 5.1 does not apply
    # Scene.unit_settings.time_unit to arbitrary TIME FloatProperty widgets, so
    # the N-panel draws the display proxy below instead. Keeping seconds here
    # preserves existing fixed60/fixed63 preferences and JSON values exactly.
    precision_numeric_drag_step_time: bpy.props.FloatProperty(
        name=_ui('Time Step (Internal Seconds)', '時間刻み（内部秒）'),
        default=1.0,
        min=1.0e-9,
        soft_max=86400000.0,
        precision=9,
        step=1,
        options={'HIDDEN'},
        description=_ui(
            'Internal physical time step in seconds. The visible Time setting converts this value to and from the active Scene time unit.',
            '物理的な時間刻みを秒で保持する内部値です。表示される「時間」設定が、現在のシーン時間単位との間で相互変換します。',
        ),
        update=_update_precision_length_drag_step,
    )
    precision_numeric_drag_step_time_display: bpy.props.FloatProperty(
        name=_ui('Time', '時間'),
        min=1.0e-9,
        soft_max=1000000.0,
        precision=6,
        step=1,
        get=_precision_drag_time_display_get,
        set=_precision_drag_time_display_set,
        description=_ui(
            'Precision step for editable time and absolute-time fields, entered in the active Scene Properties > Units > Time unit. The value is converted to physical seconds internally, so changing the Scene time unit updates the displayed step without changing its duration.',
            '編集可能な時間・絶対時間欄に適用する精密刻みです。「シーンプロパティ > 単位 > 時間」で現在選択中の単位で入力します。内部では物理秒へ変換するため、シーンの時間単位を切り替えると、継続時間を維持したまま表示値が変換されます。',
        ),
    )
    precision_numeric_drag_step_temperature: bpy.props.FloatProperty(
        name=_ui('Temperature', '温度'),
        default=1.0,
        min=1.0e-9,
        soft_max=1000.0,
        precision=6,
        step=1,
        description=_ui(
            'Temperature difference applied per drag step. The value is interpreted in Scene Properties > Units > Temperature. It is intentionally stored as a difference instead of an absolute TEMPERATURE RNA value, preventing Celsius offsets from turning a small step into a large Kelvin jump.',
            'ドラッグ1刻みごとに適用する温度差です。値は「シーンプロパティ > 単位 > 温度」で選択中の単位として解釈します。絶対温度の温度プロパティの値ではなく温度差として保持するため、摂氏のオフセットによって小さな刻みが大きなケルビン差へ変換されることを防ぎます。',
        ),
        update=_update_precision_length_drag_step,
    )
    precision_numeric_drag_units_migrated_v61: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'},
    )

    precision_number_drag_step_length: bpy.props.FloatProperty(
        name=_ui('Length Step', '長さ刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to length, distance, translation, and XYZ length float spinners. The value is read when Shift-left dragging starts.', '長さ・距離・移動・XYZ長さの小数スピナーに適用する刻みです。この値はShift+左ドラッグ開始時に読み込まれます。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_area: bpy.props.FloatProperty(
        name=_ui('Area Step', '面積刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to area unit float spinners.', '面積単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_volume: bpy.props.FloatProperty(
        name=_ui('Volume Step', '体積刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to volume unit float spinners.', '体積単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_angle: bpy.props.FloatProperty(
        name=_ui('Angle Drag Step', '角度刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to angle float spinners, in visible degrees. Internally the value is converted to radians when the target property is edited.', '角度の小数スピナーに適用する刻みです。表示上の度数として指定し、対象プロパティへ適用する際に内部でラジアンへ変換します。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_scale: bpy.props.FloatProperty(
        name=_ui('Scale Step', 'スケール刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to scale-like float spinners, including properties whose identifier or label contains scale.', 'スケール系の小数スピナーに適用する刻みです。識別子または表示名に scale が含まれるプロパティも対象になります。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_factor: bpy.props.FloatProperty(
        name=_ui('Factor Step', '係数刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to factor subtype float spinners.', '係数サブタイプの小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_percentage: bpy.props.FloatProperty(
        name=_ui('Percentage Step', 'パーセント刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to percentage float spinners.', 'パーセント系の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_time: bpy.props.FloatProperty(
        name=_ui('Time Step', '時間刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to time unit float spinners.', '時間単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_time_absolute: bpy.props.FloatProperty(
        name=_ui('Absolute Time Step', '絶対時間刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to absolute time unit float spinners.', '絶対時間単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_velocity: bpy.props.FloatProperty(
        name=_ui('Velocity Step', '速度刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to velocity unit float spinners.', '速度単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_acceleration: bpy.props.FloatProperty(
        name=_ui('Acceleration Step', '加速度刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to acceleration unit float spinners.', '加速度単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_mass: bpy.props.FloatProperty(
        name=_ui('Mass Step', '質量刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to mass unit float spinners.', '質量単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_power: bpy.props.FloatProperty(
        name=_ui('Power Step', '出力刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to power unit float spinners.', '出力単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_temperature: bpy.props.FloatProperty(
        name=_ui('Temperature Step', '温度刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to temperature unit float spinners.', '温度単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_color_temperature: bpy.props.FloatProperty(
        name=_ui('Color Temperature Step', '色温度刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to color temperature unit float spinners.', '色温度単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_wavelength: bpy.props.FloatProperty(
        name=_ui('Wavelength Step', '波長刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to wavelength unit float spinners.', '波長単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_frequency: bpy.props.FloatProperty(
        name=_ui('Frequency Step', '周波数刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to frequency unit float spinners.', '周波数単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_camera: bpy.props.FloatProperty(
        name=_ui('Camera Step', 'カメラ刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to camera unit float spinners.', 'カメラ単位の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_color: bpy.props.FloatProperty(
        name=_ui('Color Step', '色刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to color component float spinners.', '色成分の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )
    precision_number_drag_step_number: bpy.props.FloatProperty(
        name=_ui('Number Step', '通常数値刻み'), default=0.01, min=0.000001, precision=4, step=1,
        description=_ui('Step applied to normal float spinners that do not have a dedicated unit.', '専用単位を持たない通常の小数スピナーに適用する刻みです。'),
        update=_update_precision_length_drag_step,
    )


    enable_mesh_vertex_tools: bpy.props.BoolProperty(
        name=_ui('Enable Mesh / Vertex Tools', 'メッシュ / 頂点ツールを有効化'),
        default=False,
        description=_ui(
            'Compatibility placeholder for older saved preferences. This build does not expose a separate Mesh / Vertex Tools module from this switch.',
            '旧バージョンの保存済み設定との互換用項目です。このビルドでは、このスイッチから独立したメッシュ / 頂点ツールモジュールは表示しません。',
        ),
        update=_update_suite_toggle,
    )

    affect_only_all_object_types: bpy.props.BoolProperty(
        name=_ui('Apply Affect Only to All Object Types', '影響の限定を全オブジェクトへ適用'),
        description=_ui(
            'When enabled, Smart Gizmo and Smart G-R-S honor 3D View Options > Transform > Affect Only > Origins, Locations, and Parents for every selected Object Mode object type, including Empty, Camera, Light, Armature, Curve, Text, Lattice, Metaball, Speaker, Volume, Point Cloud, Grease Pencil, and future object types. When disabled, these Affect Only options are honored only when every selected object is a Mesh; non-mesh-only and mixed selections use normal Smart transform behavior. The setting does not change Blender standard gizmos or standard G/R/S.',
            '有効にすると、スマートギズモ と Smart G-R-S は、3Dビューの「オプション > トランスフォーム > 影響の限定」にある「原点」「位置」「親」を、エンプティ、カメラ、ライト、アーマチュア、カーブ、テキスト、ラティス、メタボール、スピーカー、ボリューム、ポイントクラウド、グリースペンシル、将来追加される種類を含む、オブジェクトモードで選択中の全オブジェクト種別へ反映します。無効にすると、選択中の全オブジェクトがメッシュの場合だけ影響の限定を反映し、非メッシュのみ、またはメッシュと非メッシュの混在選択では通常のSmart変形として動作します。Blender標準ギズモと標準G/R/Sの挙動は変更しません。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('affect_only_all_object_types'),
    )

    normal_align_use_pivot: bpy.props.BoolProperty(
        name=_ui('Align Object Pivot', 'オブジェクトピボットを合わせる'),
        description=_ui(
            'Move the active mesh object origin to the average position of the selected visible Edit Mesh vertices and rotate the object local Z axis to their averaged vertex normal. The mesh data is counter-transformed so the visible world-space mesh shape and vertex positions do not move. Use this when the object pivot itself must follow a modeled surface direction.',
            'アクティブなメッシュオブジェクトの原点を、編集モードで選択中かつ表示中の頂点の平均位置へ移動し、オブジェクトのローカルZ軸を平均頂点法線へ向けます。メッシュデータを逆変換するため、見た目のワールド空間メッシュ形状と頂点位置は移動しません。オブジェクトのピボット自体をモデリング面の方向へ合わせたい場合に使用します。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('normal_align_use_pivot'),
    )
    normal_align_use_orientation: bpy.props.BoolProperty(
        name=_ui('Create Custom Orientation', 'カスタム座標系を作成'),
        description=_ui(
            'Create or overwrite the custom transform orientation named VertexNormal from the average position and averaged normal of the selected visible Edit Mesh vertices, then make it the active transform orientation. When Align Object Pivot is disabled, the object pivot remains unchanged.',
            '編集モードで選択中かつ表示中の頂点の平均位置と平均法線から、カスタムトランスフォーム座標系「VertexNormal」を作成または上書きし、現在の変形座標系として有効化します。「オブジェクトピボットを合わせる」が無効の場合、オブジェクトのピボットは変更しません。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('normal_align_use_orientation'),
    )

    # Foldouts
    show_suite_integrations: bpy.props.BoolProperty(
        name=_ui('Show Other Tool Toggles', 'その他ツール切り替えを表示'),
        description=_ui('Open or close the N-panel group that controls which Smart Transform modules are enabled. The open/closed state is saved and restored with the rest of the N-panel settings.', 'Smart Transform モジュールの有効 / 無効を管理するNパネルグループを開閉します。開閉状態は他のNパネル設定と同じく保存・復元されます。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_suite_integrations'),
    )
    show_always_on_switches: bpy.props.BoolProperty(
        name=_ui('Show Resident Features', '常時機能切り替えを表示'),
        description=_ui(
            'Open or close the consolidated Resident Features group at the top of the Smart Transform N-panel. The initial state after installation is closed.',
            'Smart Transform のNパネル最上部にある「常時機能切り替え」グループを開閉します。インストール直後の初期状態は閉じた状態です。',
        ),
        default=False,
        update=_update_show_always_on_switches,
    )
    show_core_panel_settings: bpy.props.BoolProperty(
        name=_ui('Show Smart Transform Panel Settings', 'Smart Transformパネル設定を表示'),
        description=_ui('Open or close the Smart Transform numeric panel settings group in the N-panel.', 'Nパネル内の Smart Transform 数値パネル設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_core_panel_settings'),
    )
    show_cursor_lock_settings: bpy.props.BoolProperty(
        name=_ui('Show 3D Cursor Lock Settings', '3Dカーソルロック設定を表示'),
        description=_ui('Open or close the 3D Cursor Lock settings group in the N-panel.', 'Nパネル内の3Dカーソルロック設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_cursor_lock_settings'),
    )
    show_precision_length_drag_settings: bpy.props.BoolProperty(
        name=_ui('Show Precision Numeric Drag Settings', '精密数値ドラッグ設定を表示'),
        description=_ui(
            'Open or close the Precision Numeric Drag settings group in Other Tools. This group controls the Shift-left float-spinner drag feature, unit-specific steps, usage, and operator ID.',
            'その他ツール内の精密数値ドラッグ設定グループを開閉します。このグループでは小数スピナーのShift+左ドラッグ機能の有効 / 無効、単位別刻み、使い方、オペレーターIDを確認できます。',
        ),
        default=False,
        update=lambda self, context: _request_prefs_save('show_precision_length_drag_settings'),
    )
    show_cycle_custom_select_settings: bpy.props.BoolProperty(
        name=_ui('Show Custom Selection Cycle Settings', 'カスタム選択切り替え設定を表示'),
        description=_ui(
            'Open or close the Custom Selection Cycle settings group inside Other Tools. This group controls which selection modes are included when the cycle command is used while keeping the active Move / Rotate / Scale / Transform tool selected.',
            'その他ツール内のカスタム選択切り替え設定グループを開閉します。移動 / 回転 / スケール / トランスフォームツールを選択したまま、切り替えコマンドに含める選択モードを設定します。',
        ),
        default=False,
        update=lambda self, context: _request_prefs_save('show_cycle_custom_select_settings'),
    )
    show_quick_align_settings: bpy.props.BoolProperty(
        name=_ui('Show Quick Align Settings', 'クイック整列設定を表示'),
        description=_ui('Open or close the Quick Align settings group in the N-panel.', 'Nパネル内の クイック整列 設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_quick_align_settings'),
    )
    show_quick_multi_edit_settings: bpy.props.BoolProperty(
        name=_ui('Show Quick Multi-Edit Settings', 'クイック複数編集設定を表示'),
        description=_ui('Open or close the Quick Multi-Edit settings group in the N-panel.', 'Nパネル内の クイック複数編集 設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_quick_multi_edit_settings'),
    )
    show_mesh_island_transform_settings: bpy.props.BoolProperty(
        name=_ui('Show Island Transform Settings', 'アイランド変形設定を表示'),
        description=_ui('Open or close the mesh Island Transform settings group in the Other Tools section.', 'その他ツール内のメッシュ用アイランド変形設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_mesh_island_transform_settings'),
    )
    show_normal_aligner_settings: bpy.props.BoolProperty(
        name=_ui('Show Vertex Normal Aligner Settings', '頂点法線アライナー設定を表示'),
        description=_ui(
            'Open or close the Vertex Normal Aligner group in Other Tools. The group controls whether the object pivot, the VertexNormal custom transform orientation, or both are aligned to the average normal of selected Edit Mesh vertices.',
            'その他ツール内の頂点法線アライナー設定グループを開閉します。編集モードで選択した頂点の平均法線へ、オブジェクトピボット、カスタム座標系「VertexNormal」、またはその両方を合わせる設定を行います。',
        ),
        default=False,
        update=lambda self, context: _request_prefs_save('show_normal_aligner_settings'),
    )
    show_select_guard_settings: bpy.props.BoolProperty(
        name=_ui('Show Smart Select Guard Settings', 'スマート選択ガード設定を表示'),
        description=_ui('Open or close the Smart Select Guard settings group in the N-panel.', 'Nパネル内の スマート選択ガード 設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_select_guard_settings'),
    )
    show_mesh_vertex_tools_settings: bpy.props.BoolProperty(
        name=_ui('Show Mesh / Vertex Tools Settings', 'メッシュ / 頂点ツール設定を表示'),
        description=_ui('Open or close the compatibility Mesh / Vertex Tools settings group in the N-panel.', 'Nパネル内の互換用メッシュ / 頂点ツール設定グループを開閉します。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_mesh_vertex_tools_settings'),
    )

    show_section_smart_transform_info: bpy.props.BoolProperty(
        name=_ui('Show Transform Section', 'トランスフォームセクションを表示'),
        description=_ui('Open or close the Transform section in the N-panel.', 'Nパネル内のトランスフォームセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_smart_transform_info'),
    )
    show_section_controls: bpy.props.BoolProperty(
        name=_ui('Show Controls Section', 'コントロールセクションを表示'),
        description=_ui('Open or close the Smart Transform controls section in the N-panel.', 'Nパネル内のSmart Transformコントロールセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_controls'),
    )
    show_section_target_tools: bpy.props.BoolProperty(
        name=_ui('Show Target Tools Section', '対象ツールセクションを表示'),
        description=_ui('Open or close the Target Tools section in the N-panel.', 'Nパネル内の対象ツールセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_target_tools'),
    )
    show_section_selection_behavior: bpy.props.BoolProperty(
        name=_ui('Show Selection Behavior Section', '選択挙動セクションを表示'),
        description=_ui('Open or close the Selection Behavior section in the N-panel.', 'Nパネル内の選択挙動セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_selection_behavior'),
    )
    show_section_transform_behavior: bpy.props.BoolProperty(
        name=_ui('Show Transform Behavior Section', '変形挙動セクションを表示'),
        description=_ui('Open or close the Transform Behavior section in the N-panel.', 'Nパネル内の変形挙動セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_transform_behavior'),
    )
    show_section_background_interaction: bpy.props.BoolProperty(
        name=_ui('Show Background Interaction Section', '背景操作セクションを表示'),
        description=_ui('Open or close the Background Interaction section in the N-panel.', 'Nパネル内の背景操作セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_background_interaction'),
    )
    show_section_sensitivity: bpy.props.BoolProperty(
        name=_ui('Show Sensitivity Section', '感度セクションを表示'),
        description=_ui('Open or close the Sensitivity Settings section in the N-panel.', 'Nパネル内の感度設定セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_sensitivity'),
    )
    show_grs_child_snapping_proportional: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Snapping / Proportional', 'Smart G-R-S スナップ / プロポーショナルを表示'),
        description=_ui('Open or close the Smart G-R-S Snapping / Proportional child group.', 'Smart G-R-S のスナップ / プロポーショナル子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_snapping_proportional'),
    )
    show_grs_child_drag_sensitivity: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Drag Sensitivity', 'Smart G-R-S ドラッグ感度を表示'),
        description=_ui('Open or close the Smart G-R-S Drag Sensitivity child group.', 'Smart G-R-S のドラッグ感度子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_drag_sensitivity'),
    )
    show_grs_child_scale_behavior: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Scale Behavior', 'Smart G-R-S スケール挙動を表示'),
        description=_ui('Open or close the Smart G-R-S Scale Behavior child group.', 'Smart G-R-S のスケール挙動子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_scale_behavior'),
    )
    show_grs_child_axis_constraint_line: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Axis Constraint Line', 'Smart G-R-S 軸制約ラインを表示'),
        description=_ui('Open or close the Smart G-R-S Axis Constraint Line child group.', 'Smart G-R-S の軸制約ライン子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_axis_constraint_line'),
    )
    show_grs_child_proportional_cursor: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Proportional Cursor', 'Smart G-R-S プロポーション半径調整を表示'),
        description=_ui('Open or close the Smart G-R-S proportional cursor child group.', 'Smart G-R-S のプロポーション半径調整子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_proportional_cursor'),
    )
    show_grs_child_proportional_adjust: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Proportional Adjust', 'Smart G-R-S プロポーション調整を表示'),
        description=_ui('Open or close the Smart G-R-S Proportional Adjust child group.', 'Smart G-R-S のプロポーション調整子グループを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_grs_child_proportional_adjust'),
    )
    show_section_smart_gizmo: bpy.props.BoolProperty(
        name=_ui('Show 3D Smart Gizmo Section', '3Dスマートギズモセクションを表示'),
        description=_ui('Open or close the 3D Smart Gizmo section in the N-panel.', 'Nパネル内の3Dスマートギズモセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_smart_gizmo'),
    )
    show_section_additional_entry_points: bpy.props.BoolProperty(
        name=_ui('Legacy Hidden Operator IDs Section', '旧非表示オペレーターIDセクション'),
        description=_ui('Compatibility-only hidden foldout retained for older saved settings. The old separate operator ID section is no longer drawn in the N-panel.', '古い保存設定との互換用に残した非表示の折り畳み状態です。旧オペレーターID専用セクションはNパネルには描画しません。'),
        default=False,
        update=lambda self, context: _request_prefs_save('show_section_additional_entry_points'),
    )
    show_section_smart_grs: bpy.props.BoolProperty(
        name=_ui('Show Smart G-R-S Section', 'Smart G-R-Sセクションを表示'),
        description=_ui('Open or close the Smart G-R-S Transform section in the N-panel.', 'Nパネル内のSmart G-R-S変形セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_smart_grs'),
    )
    show_section_proportional: bpy.props.BoolProperty(
        name=_ui('Show Proportional Editing Section', 'プロポーショナル編集セクションを表示'),
        description=_ui('Open or close the Proportional Editing section in the N-panel.', 'Nパネル内のプロポーショナル編集セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_proportional'),
    )
    show_section_hud_numeric: bpy.props.BoolProperty(
        name=_ui('Show HUD / Numeric Input Section', 'HUD / 数値入力セクションを表示'),
        description=_ui('Open or close the HUD / Numeric Input section in the N-panel.', 'Nパネル内のHUD / 数値入力セクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_hud_numeric'),
    )
    show_section_overlay_aa: bpy.props.BoolProperty(
        name=_ui('Show Overlay Anti-Aliasing Section', 'オーバーレイAAセクションを表示'),
        description=_ui('Open or close the Overlay Anti-Aliasing section in the N-panel.', 'Nパネル内のオーバーレイのアンチエイリアスセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_overlay_aa'),
    )
    show_section_integrated_tools: bpy.props.BoolProperty(
        name=_ui('Show Other Tools Section', 'その他ツールセクションを表示'),
        description=_ui('Open or close the Other Tools section in the N-panel.', 'Nパネル内のその他ツールセクションを開閉します。'),
        default=True,
        update=lambda self, context: _request_prefs_save('show_section_integrated_tools'),
    )

    # Integrated tool settings (stored under addon prefs mirror; editable UI stays in the N-panel)
    core_panel: bpy.props.PointerProperty(
        type=STS_SmartTransformPanelPrefs,
        name=_ui('Smart Transform Panel Mirror', 'Smart Transformパネルミラー'),
        description=_ui('Hidden compatibility mirror for Smart Transform N-panel settings. Editing is performed only from the N-panel.', 'Smart Transform Nパネル設定の互換用ミラーです。編集はNパネルからのみ行います。'),
    )
    quick_align: bpy.props.PointerProperty(
        type=STS_QuickAlignPrefs,
        name=_ui('Quick Align Mirror', 'クイック整列ミラー'),
        description=_ui('Hidden compatibility mirror for Quick Align N-panel settings. Editing is performed only from the N-panel.', 'クイック整列 Nパネル設定の互換用ミラーです。編集はNパネルからのみ行います。'),
    )
    quick_multi_edit: bpy.props.PointerProperty(
        type=STS_QuickMultiEditPrefs,
        name=_ui('Quick Multi-Edit Mirror', 'クイック複数編集ミラー'),
        description=_ui('Hidden compatibility mirror for Quick Multi-Edit N-panel settings. Editing is performed only from the N-panel.', 'クイック複数編集 Nパネル設定の互換用ミラーです。編集はNパネルからのみ行います。'),
    )
    select_guard: bpy.props.PointerProperty(
        type=STS_SmartSelectGuardPrefs,
        name=_ui('Smart Select Guard Mirror', 'スマート選択ガードミラー'),
        description=_ui('Hidden compatibility mirror for Smart Select Guard N-panel settings. Editing is performed only from the N-panel.', 'スマート選択ガード Nパネル設定の互換用ミラーです。編集はNパネルからのみ行います。'),
    )
    mesh_vertex_tools: bpy.props.PointerProperty(
        type=STS_MeshVertexToolsPrefs,
        name=_ui('Mesh Vertex Tools Mirror', 'メッシュ頂点ツールミラー'),
        description=_ui('Hidden compatibility mirror for Mesh Vertex Tools N-panel settings. Editing is performed only from the N-panel.', 'メッシュ頂点ツール Nパネル設定の互換用ミラーです。編集はNパネルからのみ行います。'),
    )

    # ---------------------------------------------------------
    # STF (Smart Transform Tools) Settings
    # ---------------------------------------------------------
    enable_move: bpy.props.BoolProperty(
        name="Enable for Move Tool", default=True,
        description="Enable Smart Transform behaviors for the Move Tool.",
        update=_update_csdt_behavior_pref,
    )
    enable_rotate: bpy.props.BoolProperty(
        name="Enable for Rotate Tool", default=True,
        description="Enable Smart Transform behaviors for the Rotate Tool.",
        update=_update_csdt_behavior_pref,
    )
    enable_scale: bpy.props.BoolProperty(
        name="Enable for Scale Tool", default=True,
        description="Enable Smart Transform behaviors for the Scale Tool.",
        update=_update_csdt_behavior_pref,
    )
    enable_transform: bpy.props.BoolProperty(
        name="Enable for Transform Tool", default=True,
        description="Enable Smart Transform behaviors for the Transform Tool.",
        update=_update_csdt_behavior_pref,
    )

    use_immediate_select: bpy.props.BoolProperty(
        name="Immediate Select (On Press)", default=True,
        description="Select object/element immediately on mouse press. If OFF, select on release.",
        update=_update_csdt_behavior_pref,
    )
    smart_gizmo_click_select_priority: bpy.props.BoolProperty(
        name="Element Click Priority over Smart Gizmo",
        default=True,
        description=(
            "When a click overlaps a Smart Gizmo handle and a selectable object or edit element, release "
            "selects it using standard Smart Transform modifiers (Shift add, Ctrl subtract, Shift+Ctrl toggle). "
            "Alt/OS-key variants remain Blender-native. Moving beyond the drag threshold keeps the original "
            "selection and starts the hovered gizmo handle instead. Disable this to keep the legacy gizmo-first behavior"
        ),
        update=_update_csdt_behavior_pref,
    )
    keep_multi_selection: bpy.props.BoolProperty(
        name="Keep Multi-Selection on Drag", default=True,
        description="When dragging one of multiple selected items, move the entire selection group.",
        update=_update_csdt_behavior_pref,
    )
    update_active_element: bpy.props.BoolProperty(
        name="Update Active Element", default=True,
        description="When clicking an already selected item, make it the active element (white highlight).",
        update=_update_csdt_behavior_pref,
    )
    enable_click_through: bpy.props.BoolProperty(
        name="Click Through Unselectable", default=True,
        description="Allow selecting objects behind unselectable (Hide Select) objects in Object Mode.",
        update=_update_csdt_behavior_pref,
    )
    enable_back_element_click_select: bpy.props.BoolProperty(
        name=_ui('Backside Element Click Select', '背面エレメントクリック選択'),
        default=False,
        description=_ui(
            'Allow repeated click selection of editable mesh elements that overlap behind the front element at the same screen position. When enabled, Smart Transform builds a click candidate list from the configured hit range and cycles through overlapping vertices, edges, or face-center dots on repeated clicks, without changing box/lasso/circle selection behavior.',
            '同じ画面位置で前面要素の背後に重なっているメッシュ編集要素を、クリックで選び分けられるようにします。有効時は「感度・判定範囲の設定」に従って頂点・辺・面中央ドットの候補リストを作成し、同じ位置を繰り返しクリックしたときに重なった候補を順番に選択します。ボックス・投げ縄・サークル選択の挙動は変更しません。',
        ),
        update=_update_csdt_behavior_pref,
    )

    crossing_select_edges: bpy.props.BoolProperty(
        name=_ui('Crossing Selection: Edges', '交差選択: 辺'),
        default=False,
        description=_ui(
            'In Edit Mesh, extend box, lasso, and circle selection so edges are selected when any part of the projected edge intersects or lies inside the selection region. OFF keeps Blender standard edge selection.',
            'メッシュ編集で、ボックス・投げ縄・サークル選択時に投影された辺の一部が選択範囲と交差または内部にある場合も選択します。OFFではBlender標準の辺選択を維持します。',
        ),
        update=_update_csdt_behavior_pref,
    )
    crossing_select_faces: bpy.props.BoolProperty(
        name=_ui('Crossing Selection: Faces', '交差選択: 面'),
        default=False,
        description=_ui(
            'In Edit Mesh, extend box, lasso, and circle selection so faces are selected when any part of the projected polygon intersects or contains the selection region. OFF keeps Blender standard face-center selection.',
            'メッシュ編集で、ボックス・投げ縄・サークル選択時に投影された面ポリゴンの一部が選択範囲と交差または包含する場合も選択します。OFFではBlender標準の面中心点選択を維持します。',
        ),
        update=_update_csdt_behavior_pref,
    )

    enable_drag_transform: bpy.props.BoolProperty(
        name="Drag to Transform", default=True,
        description="Start transform operation immediately when dragging. If OFF, only selection is performed.",
        update=_update_csdt_behavior_pref,
    )
    enable_axis_memory: bpy.props.BoolProperty(
        name="Smart Axis Memory", default=True,
        description="Remember the last used axis constraint (X, Y, Z) and apply it to the next operation.",
        update=lambda self, context: _request_prefs_save('enable_axis_memory'),
    )

    smart_gizmo_use_circular_rotation: bpy.props.BoolProperty(
        name=_ui('Gizmo Circular Rotation', 'ギズモ円周回転'),
        description=_ui(
            'Choose how Smart G-R-S rotation, the 3D Smart Gizmo Rotate tool, and Transform-tool rotate handles convert mouse movement into angle changes. ON uses Blender-default-like circular control: drag clockwise or counterclockwise around the transform center to rotate, with screen-stable direction correction so X/Y/Z rings do not invert when viewed from the back side. OFF uses screen-coordinate control where plus/minus movement on the display changes the angle. Default: ON.',
            'Smart G-R-S回転、3Dスマートギズモの回転ツール、トランスフォームツール内の回転ハンドルで、マウス移動を角度へ変換する方法を切り替えます。ONではBlender標準ギズモに近く、変形中心の周囲を時計回り/反時計回りにドラッグして回転します。X/Y/Zリングを裏側から見た場合でも画面上のカーソル移動方向を基準に補正し、回転方向が反転しないようにします。OFFでは、ディスプレイ上の±方向の移動量で角度を変更します。初期値はONです。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('smart_gizmo_use_circular_rotation'),
    )

    smart_gizmo_use_distance_scale: bpy.props.BoolProperty(
        name=_ui('Gizmo Distance Scale', 'ギズモ距離スケール'),
        description=_ui(
            'Choose how Smart G-R-S scale, the 3D Smart Gizmo Scale tool, and Transform-tool scale handles convert mouse movement into scale changes. ON keeps the current distance-based scale method: moving farther from the transform center or along the active scale handle direction enlarges, and moving closer shrinks. OFF uses display-coordinate scale: dragging the cursor to the right or upward enlarges, and dragging it to the left or downward shrinks, while the selected axis or plane constraint still decides which scale axes are affected. Default: ON.',
            'Smart G-R-Sスケール、3Dスマートギズモのスケールツール、トランスフォームツール内のスケールハンドルで、マウス移動をスケール量へ変換する方法を切り替えます。ONでは現在の距離ベース方式を維持し、変形中心から遠ざける、または有効なスケールハンドル方向へ動かすと拡大し、近づけると縮小します。OFFではディスプレイ座標方式になり、カーソルを画面上の右または上へドラッグすると拡大し、左または下へドラッグすると縮小します。軸・平面拘束はそのまま有効で、どの軸をスケールするかだけを決定します。初期値はONです。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('smart_gizmo_use_distance_scale'),
    )

    tool_disallow_negative_scale: bpy.props.BoolProperty(
        name=_ui('Disallow Negative Scale for Scale Tools', 'スケールツールのマイナススケールを禁止'),
        description=_ui(
            'ON: Scale tool and Transform-tool scale handles use the Smart G-R-S positive-scale algorithm and clamp scale to a small positive value instead of allowing mirror/negative scale. OFF: use Blender native resize behavior that can pass through negative scale.',
            'ONの場合、スケールツールとトランスフォームツールのスケールハンドルでSmart G-R-Sと同じ正方向スケールアルゴリズムを使用し、ミラー化するマイナススケールを許可せず、最小の正値で止めます。OFFの場合はマイナススケールを許可するBlender標準の拡大縮小挙動を使用します。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('tool_disallow_negative_scale'),
    )
      
    gizmo_pick_range_px: bpy.props.IntProperty(
        name="Gizmo Pick Range", default=7, min=1, max=50, subtype='PIXEL', update=_update_gizmo_pick_factor,
        description="Hit detection range for the 3D Smart Gizmo (pixels)."
    )
      
    enable_smart_gizmo_style: bpy.props.BoolProperty(
        name=_ui('3D Smart Gizmo Custom Style', '3Dスマートギズモ独自表示'), default=True, update=_update_smart_gizmo_settings,
        description=_ui('Use the Smart Transform custom drawing and hit detection for the 3D Smart Gizmo while its live runtime and overlay are enabled. OFF keeps the live runtime available but stops the add-on custom handle style.', '3Dスマートギズモの常時ランタイムと表示が有効な間、Smart Transform独自の描画とクリック判定を使用します。OFFではランタイムは利用可能なまま、アドオン独自ハンドル表示を停止します。')
    )

    enable_smart_gizmo_rotate: bpy.props.BoolProperty(
        name="Enable 3D Smart Gizmo: Rotate", default=True, update=_update_smart_gizmo_settings,
        description="Enable the 3D Smart Gizmo overlay for the Rotate tool in the 3D View."
    )
    enable_smart_gizmo_scale: bpy.props.BoolProperty(
        name="Enable 3D Smart Gizmo: Scale", default=True, update=_update_smart_gizmo_settings,
        description="Enable the 3D Smart Gizmo overlay for the Scale tool in the 3D View."
    )
    enable_smart_gizmo_transform: bpy.props.BoolProperty(
        name="Enable 3D Smart Gizmo: Transform", default=True, update=_update_smart_gizmo_settings,
        description="Enable the 3D Smart Gizmo overlay for the combined Transform tool in the 3D View."
    )

    smart_gizmo_transform_show_move: bpy.props.BoolProperty(
        name="Move", default=True, update=_update_smart_gizmo_settings,
        description="Transform tool only: show the Move component of the 3D Smart Gizmo.\nTurn this OFF if you want a cleaner Transform gizmo (Move / Rotate / Scale can be shown independently)."
    )
    smart_gizmo_transform_show_rotate: bpy.props.BoolProperty(
        name="Rotate", default=True, update=_update_smart_gizmo_settings,
        description="Transform tool only: show the Rotate component of the 3D Smart Gizmo.\nTurn this OFF to reduce clutter when using a combined Transform gizmo."
    )
    smart_gizmo_transform_show_scale: bpy.props.BoolProperty(
        name="Scale", default=True, update=_update_smart_gizmo_settings,
        description="Transform tool only: show the Scale component of the 3D Smart Gizmo.\nTurn this OFF if Scale handles overlap your workflow (you can still use the Scale tool separately)."
    )
    
    gizmo_toggle_state: bpy.props.BoolProperty(
        name=_ui('3D Smart Gizmo Overlay Active', '3Dスマートギズモ表示を有効化'),
        default=True,
        description=_ui(
            'Turn the 3D Smart Gizmo overlay itself on or off. Keep this ON when you want the custom Move / Rotate / Scale handles to appear in the 3D View while the live runtime is enabled.',
            '3Dスマートギズモの表示そのものを有効 / 無効にします。常時ランタイムが有効な状態で、3Dビューに独自の移動・回転・スケールハンドルを表示したい場合はONにしてください。',
        ),
        update=_update_smart_gizmo_settings,
    )
      
    smart_gizmo_screen_scale: bpy.props.FloatProperty(
        name="3D Smart Gizmo Screen Scale", default=1.0, min=0.2, max=3.0, update=_update_smart_gizmo_settings,
        description="Overall screen size scale of the 3D Smart Gizmo."
    )
    smart_axis_scale: bpy.props.FloatProperty(
        name="XYZ Axis", default=1.0, min=0.2, max=3.0, update=_update_smart_gizmo_settings,
        description="Size scale of the X/Y/Z arrow axes."
    )
    smart_plane_scale: bpy.props.FloatProperty(
        name="Plane Axis", default=1.0, min=0.2, max=3.0, update=_update_smart_gizmo_settings,
        description="Size scale of the plane constraint handles (squares)."
    )
    smart_center_scale: bpy.props.FloatProperty(
        name="Free Axis", default=1.0, min=0.2, max=3.0, update=_update_smart_gizmo_settings,
        description="Size scale of the center free-move handle (circle)."
    )

    color_x: bpy.props.FloatVectorProperty(
        name="X Axis Color", default=(0.9098, 0.2118, 0.3059), min=0.0, max=1.0, subtype='COLOR', size=3, update=_update_smart_gizmo_settings,
        description="Color of the X axis line and arrow."
    )
    color_y: bpy.props.FloatVectorProperty(
        name="Y Axis Color", default=(0.5216, 0.8000, 0.0235), min=0.0, max=1.0, subtype='COLOR', size=3, update=_update_smart_gizmo_settings,
        description="Color of the Y axis line and arrow."
    )
    color_z: bpy.props.FloatVectorProperty(
        name="Z Axis Color", default=(0.1882, 0.5059, 0.9255), min=0.0, max=1.0, subtype='COLOR', size=3, update=_update_smart_gizmo_settings,
        description="Color of the Z axis line and arrow."
    )
    color_free: bpy.props.FloatVectorProperty(
        name="Free Axis Color", default=(1.0, 1.0, 1.0), min=0.0, max=1.0, subtype='COLOR', size=3, update=_update_smart_gizmo_settings,
        description="Color of the center free-move handle."
    )
    color_highlight: bpy.props.FloatVectorProperty(
        name="Highlight Color", default=(1.0, 0.9, 0.1), min=0.0, max=1.0, subtype='COLOR', size=3, update=_update_smart_gizmo_settings,
        description="Color used when hovering or selecting a gizmo handle."
    )

    enable_bg_deselect: bpy.props.BoolProperty(
        name="Background Click Deselect", default=True,
        description="Deselect all items when clicking on empty space.",
        update=_update_csdt_behavior_pref,
    )
    enable_bg_drag_select: bpy.props.BoolProperty(
        name="Background Drag Select", default=True,
        description="When you press empty 3D View space and drag, show the box-selection frame from the original click position immediately and apply Box Select on release. Click without dragging still clears the selection when Background Click Deselect is enabled.",
        update=_update_csdt_behavior_pref,
    )

    drag_threshold: bpy.props.IntProperty(
        name="Drag Threshold (px)", default=3, min=1, max=50, subtype='PIXEL',
        description="Mouse distance required to recognize a drag operation (pixels).",
        update=_update_csdt_behavior_pref,
    )
    vert_hit_radius: bpy.props.IntProperty(
        name="Vertex Hit Radius (px)", default=20, min=1, max=100, subtype='PIXEL',
        description="Hit detection radius for selecting vertices (pixels).",
        update=_update_csdt_behavior_pref,
    )
    edge_hit_radius: bpy.props.IntProperty(
        name="Edge Hit Radius (px)", default=20, min=1, max=100, subtype='PIXEL',
        description="Hit detection radius for selecting edges (pixels).",
        update=_update_csdt_behavior_pref,
    )
      
    shortcut_id_display: bpy.props.StringProperty(
        name="Shortcut ID", default="view3d.csdt_toggle_smart_gizmo",
        description="Keymap ID used for toggling the 3D Smart Gizmo."
    )

    cycle_custom_select_id_display: bpy.props.StringProperty(
        name=_ui('Custom Select Shortcut Registration ID', 'カスタム選択ショートカット登録ID'),
        default="view3d.cycle_custom_select",
        description=_ui(
            'Operator ID used to register a shortcut for Custom Selection Cycle in Blender Preferences > Keymap. Copy this ID when assigning a custom key.',
            'Blenderのプリファレンス > キーマップでカスタム選択切り替えのショートカットを登録するためのオペレーターIDです。任意のキーを割り当てる時にこのIDをコピーします。',
        ),
    )

    last_select_tool: bpy.props.StringProperty(
        name=T("Last Select Tool"),
        description=T("Internal name of the last Blender selection tool restored by Smart Transform when custom selection tools are toggled off."),
        default="builtin.select_box",
        options={'HIDDEN'},
    )

    custom_select_mode: bpy.props.EnumProperty(
        name=_ui('Current Custom Selection Mode', '現在のカスタム選択モード'),
        description=_ui(
            'Selection mode used by Custom Selection Cycle while a supported transform tool stays active. The matching Blender toolbar Select sub-mode is synchronized, and the cycle command moves to the next enabled mode.',
            '対応する変形ツールをアクティブにしたまま、カスタム選択切り替えが使用する選択モードです。Blenderツールバー側の選択ツールモードも同期し、切り替えコマンドで次の有効モードへ進みます。',
        ),
        items=[
            ('TWEAK', _ui('Long Press', '長押し'), _ui('Use the normal select/tweak style. Click selection and drag-transform behavior remain close to the active transform tool, and background drag selection is not forced by this mode.', '通常の選択 / 微調整スタイルを使います。クリック選択とドラッグ変形はアクティブな変形ツールに近い挙動を維持し、このモードでは背景ドラッグ選択を強制しません。')),
            ('BOX', _ui('Box Select', 'ボックス選択'), _ui('Use box selection for background drag selection while the active Move / Rotate / Scale / Transform tool remains selected.', '移動 / 回転 / スケール / トランスフォームツールを選択したまま、背景ドラッグ選択にボックス選択を使います。')),
            ('CIRCLE', _ui('Circle Select', 'サークル選択'), _ui('Use Blender Circle Select as the custom selection mode without permanently switching away from the active transform tool.', 'アクティブな変形ツールから恒久的に切り替えず、カスタム選択モードとしてBlenderのサークル選択を使います。')),
            ('LASSO', _ui('Lasso Select', '投げ縄選択'), _ui('Use Blender Lasso Select as the custom selection mode without permanently switching away from the active transform tool.', 'アクティブな変形ツールから恒久的に切り替えず、カスタム選択モードとしてBlenderの投げ縄選択を使います。')),
        ],
        default='BOX',
        update=_sync_custom_select_mode_update,
    )

    custom_select_enable_tweak: bpy.props.BoolProperty(
        name=_ui('Long Press', '長押し'),
        description=_ui(
            'Include the Long Press / Select-Tweak mode in the Custom Selection Cycle. When this is OFF, the cycle skips this mode; for example Box Select cycles to Circle Select, then Lasso Select, then back to Box Select.',
            'カスタム選択切り替えの巡回対象に、長押し / 選択微調整モードを含めます。OFFの場合はこのモードを飛ばし、例えばボックス選択→サークル選択→投げ縄選択→ボックス選択のように巡回します。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('custom_select_enable_tweak'),
    )
    custom_select_enable_box: bpy.props.BoolProperty(
        name=_ui('Box Select', 'ボックス選択'),
        description=_ui(
            'Include Box Select in the Custom Selection Cycle. This mode uses the add-on fixed-origin box preview for background drag selection while the active transform tool remains selected.',
            'カスタム選択切り替えの巡回対象にボックス選択を含めます。このモードでは、アクティブな変形ツールを維持したまま、背景ドラッグ選択にアドオン側の始点固定ボックスプレビューを使います。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('custom_select_enable_box'),
    )
    custom_select_enable_circle: bpy.props.BoolProperty(
        name=_ui('Circle Select', 'サークル選択'),
        description=_ui(
            'Include Circle Select in the Custom Selection Cycle. When this mode is active, a background selection drag can invoke Blender Circle Select while the active transform tool setting is preserved.',
            'カスタム選択切り替えの巡回対象にサークル選択を含めます。このモードが有効な時は、アクティブな変形ツール設定を維持したまま、背景選択ドラッグでBlenderのサークル選択を呼び出せます。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('custom_select_enable_circle'),
    )
    custom_select_enable_lasso: bpy.props.BoolProperty(
        name=_ui('Lasso Select', '投げ縄選択'),
        description=_ui(
            'Include Lasso Select in the Custom Selection Cycle. When this mode is active, a background selection drag can invoke Blender Lasso Select while the active transform tool setting is preserved.',
            'カスタム選択切り替えの巡回対象に投げ縄選択を含めます。このモードが有効な時は、アクティブな変形ツール設定を維持したまま、背景選択ドラッグでBlenderの投げ縄選択を呼び出せます。',
        ),
        default=True,
        update=lambda self, context: _request_prefs_save('custom_select_enable_lasso'),
    )

    prefer_cycle_operator: bpy.props.BoolProperty(
        name="Prefer Blender Cycle (simulate loop)",
        default=True,
        description="Prefer Blender's built-in tool cycling. Fall back to manual cycling if it does not work.",
    )

    # ---------------------------------------------------------
    # Smart G-R-S Transform Settings
    # ---------------------------------------------------------

    # ---------------------------------------------------------
    # Keymap Conflicts / Priority
    # ---------------------------------------------------------
    grs_move_operator_id_display: bpy.props.StringProperty(
        name=_ui('Move Operator ID', '移動オペレーターID'),
        description=_ui('Copy this Operator ID to register Smart G-R-S Move manually in Blender Preferences > Keymap.', 'Smart G-R-S 移動を Blender のプリファレンス > キーマップへ手動登録するための オペレーターID をコピーします。'),
        default="transform.smart_grs_move",
    )
    grs_rotate_operator_id_display: bpy.props.StringProperty(
        name=_ui('Rotate Operator ID', '回転オペレーターID'),
        description=_ui('Copy this Operator ID to register Smart G-R-S Rotate manually in Blender Preferences > Keymap.', 'Smart G-R-S 回転を Blender のプリファレンス > キーマップへ手動登録するための オペレーターID をコピーします。'),
        default="transform.smart_grs_rotate",
    )
    grs_scale_operator_id_display: bpy.props.StringProperty(
        name=_ui('Scale Operator ID', '拡大縮小オペレーターID'),
        description=_ui('Copy this Operator ID to register Smart G-R-S Scale manually in Blender Preferences > Keymap.', 'Smart G-R-S 拡大縮小を Blender のプリファレンス > キーマップへ手動登録するための オペレーターID をコピーします。'),
        default="transform.smart_grs_scale",
    )
    prop_adjust_modal_map_display: bpy.props.StringProperty(
        name=_ui('Transform Modal Map', 'トランスフォームモーダルマップ'),
        description=_ui('Copy the Transform Modal Map name shown here when you manually register proportional-size controls.', 'プロポーショナルサイズ操作を手動登録するときに使う トランスフォームモーダルマップ 名をコピーします。'),
        default="Transform Modal Map",
    )
    prop_adjust_action_display: bpy.props.StringProperty(
        name=_ui('Proportional Size', 'プロポーショナルサイズ'),
        description=_ui('Copy this modal map action name for continuous proportional-size adjustment.', '連続的なプロポーショナルサイズ調整に使うモーダルマップのアクション名をコピーします。'),
        default="PROPORTIONAL_SIZE",
    )
    prop_adjust_up_display: bpy.props.StringProperty(
        name=_ui('Proportional Size Up', 'プロポーショナルサイズ増加'),
        description=_ui('Copy this modal map action name for stepped proportional-size increase.', '段階的にプロポーショナルサイズを大きくするためのモーダルマップのアクション名をコピーします。'),
        default="PROPORTIONAL_SIZE_UP",
    )
    prop_adjust_down_display: bpy.props.StringProperty(
        name=_ui('Proportional Size Down', 'プロポーショナルサイズ減少'),
        description=_ui('Copy this modal map action name for stepped proportional-size decrease.', '段階的にプロポーショナルサイズを小さくするためのモーダルマップのアクション名をコピーします。'),
        default="PROPORTIONAL_SIZE_DOWN",
    )

    prefer_csdt_keymap_priority: bpy.props.BoolProperty(
        name=_ui('Prefer Tool Click (Priority)', 'ツールクリックを優先（高優先度）'),
        description=_ui(
            'Use the Smart Transform 3D tool click handler without disabling Blender or third-party selection keymaps. Modifier-clicks such as Shift / Ctrl / Alt stay native so edit-mode vertex deselection and loop selection keep working.',
            'Blender標準や他アドオンの選択キーマップを無効化せずに、Smart Transform の3Dツールクリック処理を使用します。Shift / Ctrl / Alt などの修飾クリックは標準処理へ返すため、編集モードの頂点選択解除やループ選択を維持します。',
        ),
        default=False,
        update=_update_csdt_keymap_priority,
    )
    show_csdt_keymap_conflicts: bpy.props.BoolProperty(
        name="Show Tool Click Conflicts",
        description="Show other keymap items in tool keymaps that may be overridden by Smart Transform click handling.",
        default=False,
    )

    hud_enabled: bpy.props.BoolProperty(
        name="HUD",
        description="Show a small HUD during Smart G/R/S transforms (values, constraints, snaps, numeric input, help).",
        default=True,
    )
    hud_anchor_mode: bpy.props.EnumProperty(
        name="HUD Anchor",
        description="Fix the HUD to the viewport/editor or place it near the gizmo/pivot.",
        items=[
            ('VIEW', 'Fixed to View', 'Keep the HUD at a fixed screen position in the editor/view.'),
            ('GIZMO', 'Fixed to Gizmo', 'Place the HUD near the active gizmo / transform pivot.'),
        ],
        default='GIZMO',
    )
    hud_offset_x: bpy.props.IntProperty(
        name="HUD Offset X (px)",
        description="Horizontal offset of the HUD in pixels. In Fixed to View mode this is the distance from the left edge. In Fixed to Gizmo mode this is the offset from the gizmo anchor.",
        default=18, min=-2000, max=2000,
    )
    hud_offset_y: bpy.props.IntProperty(
        name="HUD Offset Y (px)",
        description="Vertical offset of the HUD in pixels. In Fixed to View mode this is the distance from the top edge. In Fixed to Gizmo mode this is the offset from the gizmo anchor.",
        default=24, min=-2000, max=2000,
    )
    hud_font_size: bpy.props.IntProperty(
        name="HUD Font Size",
        description="Font size for the transform HUD / numeric input overlay.",
        default=11, min=8, max=48,
    )
    hud_text_color: bpy.props.FloatVectorProperty(
        name="HUD Text Color",
        description="Display color of the HUD / numeric input text.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
    )
    hud_show_help_by_default: bpy.props.BoolProperty(
        name="HUD: Show Help by Default",
        description="Start Smart G/R/S with help text visible (toggle with H).",
        default=False,
    )

    snap_move_grid_step: bpy.props.FloatProperty(
        name="Snap: Move Grid Step",
        description="Grid snapping step for Move mode when holding X (Maya-style grid snap).",
        default=0.1, min=0.000001,
    )
    snap_rotate_step_deg: bpy.props.FloatProperty(
        name="Snap: Rotate Step (deg)",
        description="Angle snap step (degrees) for Rotate mode when holding X.",
        default=5.0, min=0.01,
    )
    snap_scale_step: bpy.props.FloatProperty(
        name="Snap: Scale Step",
        description="Percent snap step for Scale mode when holding X. Example: 0.1 = 10 percent steps.",
        default=0.1, min=0.000001,
    )

    object_prop_basis: bpy.props.EnumProperty(
        name="Object Proportional Basis",
        description="Distance basis for proportional editing in Object Mode.",
        items=[
            ('ORIGIN', 'Origin', 'Use object origins for distance.'),
            ('BBOX', 'Bounding Box Center', 'Use bounding box center for distance.'),
            ('BBOX_CLOSEST', 'Bounding Box Closest', 'Use closest point on bounding box to selected pivot(s).'),
        ],
        default='ORIGIN',
    )

    prop_falloff_profile: bpy.props.EnumProperty(
        name="Proportional Falloff Profile",
        description="Additional falloff shaping (keeps Blender falloff types but adjusts curve to match other DCCs).",
        items=[
            ('BLENDER', 'Blender', 'No extra shaping.'),
            ('MAYA', 'Maya', 'Slightly softer tail / more influence near center.'),
            ('MAX', '3ds Max', 'Tighter falloff (more localized).'),
        ],
        default='BLENDER',
    )

    g_normal: bpy.props.FloatProperty(name="Move Sensitivity (G) - Normal", description="Mouse sensitivity multiplier for Move (G).\n1.0 is baseline. Larger = faster, smaller = slower.", default=1.0, min=0.0)
    g_shift: bpy.props.FloatProperty(name="Move Sensitivity (G) - With Shift", description="Sensitivity multiplier while holding Shift during Move (G).\nUse as a custom precision mode.", default=0.1, min=0.0)
    r_normal: bpy.props.FloatProperty(name="Rotate Sensitivity (R) - Normal", description="Mouse sensitivity multiplier for Rotate (R).\n1.0 is baseline. Larger = faster, smaller = slower.", default=1.0, min=0.0)
    r_shift: bpy.props.FloatProperty(name="Rotate Sensitivity (R) - With Shift", description="Sensitivity multiplier while holding Shift during Rotate (R).\nUse as a custom precision mode.", default=0.1, min=0.0)
    s_normal: bpy.props.FloatProperty(name="Scale Sensitivity (S) - Normal", description="Mouse sensitivity multiplier for Scale (S).\n1.0 is baseline. Larger = faster, smaller = slower.", default=1.0, min=0.0)
    s_shift: bpy.props.FloatProperty(name="Scale Sensitivity (S) - With Shift", description="Sensitivity multiplier while holding Shift during Scale (S).\nUse as a custom precision mode.", default=0.1, min=0.0)

    disallow_negative_scale: bpy.props.BoolProperty(
        name="Scale Mode (S): Disallow Negative Scale",
        description="ON: Disallows negative scale values (no mirroring). Scaling is 3ds Max-like (horizontal mouse delta, clamped at a minimum positive value).\nOFF: Allows negative scale (mirroring) with a Blender-like continuous sign change.",
        default=True
    )

    show_orange_circle: bpy.props.BoolProperty(
        name="Proportional Editing: Show Influence Circle",
        description="Show or hide the on-screen circle that indicates the proportional editing influence radius.\nThis is a visual overlay only (it does not change the proportional settings).",
        default=True
    )
    circle_color: bpy.props.FloatVectorProperty(
        name="Proportional Editing: Circle Color",
        description="Set the display color of the proportional influence circle overlay.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.2388, 0.2388, 0.2388, 1.0)
    )
    circle_line_width: bpy.props.IntProperty(
        name="Proportional Editing: Circle Line Width (px)",
        description="Set the line width of the proportional influence circle overlay in pixels.",
        subtype='PIXEL', min=1, max=100, default=2
    )

    enable_prop_cursor_lock: bpy.props.BoolProperty(
        name="Proportional Editing: Cursor Lock for Influence Adjust",
        description="When adjusting the proportional influence radius during this add-on transform (G/R/S), keep the visible cursor fixed (no warp / no jitter) and use internal relative mouse delta only.\nThis works with ALL keymap bindings assigned to:\n- Transform Modal Map > Proportional Size (Adjust)\n- Transform Modal Map > Proportional Size Up (Increase)\n- Transform Modal Map > Proportional Size Down (Decrease)\nNote: Cursor Lock is used for the 'Adjust' action (continuous adjust). Up/Down actions apply stepped changes.",
        default=True
    )
    
    enable_middle_mouse_plane: bpy.props.BoolProperty(
        name="Middle Mouse Drag: Allow Plane Constraints (XY/XZ/YZ)",
        description="Allow selecting plane constraints (XY/XZ/YZ) by dragging between axes while holding the middle mouse button.",
        default=True
    )
    
    draw_axis_lines_in_front: bpy.props.BoolProperty(
        name="Draw Lines in Front (X-Ray)",
        description="Draw the constraint guide lines in front of objects.",
        default=True
    )

    axis_line_width: bpy.props.IntProperty(
        name="Axis Constraint Line Thickness (px)",
        description="Set the thickness of the constraint guide line for X/Y/Z axes in pixels.\nThis affects the lines drawn when you constrain with X/Y/Z (or plane constraints with Shift+X/Y/Z).",
        subtype='PIXEL', min=1, max=20, default=2
    )
    
    axis_line_width_active: bpy.props.IntProperty(
        name="Axis Constraint Line Thickness (Active, px)",
        description="Set the thickness of the active constraint guide line while holding middle mouse.",
        subtype='PIXEL', min=1, max=20, default=4
    )
    
    axis_color_x: bpy.props.FloatVectorProperty(
        name="Axis Line Color: X",
        description="Set the display color of the X-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.886, 0.475, 0.592, 1.0)
    )
    axis_color_y: bpy.props.FloatVectorProperty(
        name="Axis Line Color: Y",
        description="Set the display color of the Y-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.639, 0.812, 0.427, 1.0)
    )
    axis_color_z: bpy.props.FloatVectorProperty(
        name="Axis Line Color: Z",
        description="Set the display color of the Z-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.443, 0.647, 0.882, 1.0)
    )

    axis_color_dark_x: bpy.props.FloatVectorProperty(
        name="Axis Line Color (Dark): X",
        description="Set the display color of the inactive X-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.569, 0.188, 0.243, 1.0)
    )
    axis_color_dark_y: bpy.props.FloatVectorProperty(
        name="Axis Line Color (Dark): Y",
        description="Set the display color of the inactive Y-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.349, 0.502, 0.102, 1.0)
    )
    axis_color_dark_z: bpy.props.FloatVectorProperty(
        name="Axis Line Color (Dark): Z",
        description="Set the display color of the inactive Z-axis constraint guide line.",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.169, 0.357, 0.569, 1.0)
    )


    # ---------------------------------------------------------
    # Overlay Anti-Aliasing (applies to all AA-enabled overlay drawings)
    # ---------------------------------------------------------
    overlay_aa_mode: bpy.props.EnumProperty(
        name="Overlay Anti-Aliasing",
        description=T(
            "Switch anti-aliasing mode for all overlay drawings in this add-on (3D Smart Gizmo lines, axis constraint lines, proportional influence circle, etc.).\n"
            "Smooth (2-pass): best visual quality (draws lines twice).\n"
            "Standard AA: uses Blender's built-in GPU anti-aliasing when available (single draw).\n"
            "Off: disables add-on AA passes."
        ),
        items=[
            ('AA_2PASS', "Smooth", "Best quality: draws an extra soft outer line under the main line (2 passes)."),
            ('AA_MSAA',  "Standard AA",     "Single pass: uses Blender's built-in GPU anti-aliasing when available. (No extra AA pass)"),
            ('AA_OFF',   "No AA",           "No additional AA: draw lines as-is. (Fastest / sharpest)"),
        ],
        default='AA_2PASS',
        update=_update_overlay_aa_mode,
    )

    def draw(self, context):
        # User-facing settings are consolidated in the 3D View N-panel.
        # Keep Blender's Add-on Preferences property area completely empty.
        del context
        return None


def draw_addon_preferences_redirect_ui(layout, context=None):
    return




def _safe_prop(layout, owner, prop_name: str, *, text: str = '', toggle: bool = False, icon: str = 'NONE') -> bool:
    if layout is None or owner is None:
        return False
    try:
        if not hasattr(owner, str(prop_name)):
            return False
        layout.prop(owner, str(prop_name), text=str(text or ''), toggle=bool(toggle), icon=icon)
        return True
    except Exception:
        return False




_HELP_OPERATOR_ID = 'core_suite.show_tool_help'


def _draw_help_button(layout, topic_key: str, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Modeling style minimum-width standard QUESTION help button."""
    if layout is None or not str(topic_key or '').strip():
        return None
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        try:
            op = row.operator(_HELP_OPERATOR_ID, text='', icon='QUESTION', emboss=True)
        except TypeError:
            op = row.operator(_HELP_OPERATOR_ID, text='', icon='QUESTION')
        _safe_set_operator_property(op, 'topic_key', str(topic_key or ''), strict=True, operator_id=_HELP_OPERATOR_ID)
        return op
    except Exception:
        return None






def _draw_help_button_inline(layout, topic_key: str):
    """Draw a minimum-width standard QUESTION help button without adding spacers."""
    if layout is None or not str(topic_key or '').strip():
        return None
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator(_HELP_OPERATOR_ID, text='', icon='QUESTION', emboss=True)
    except TypeError:
        try:
            op = row.operator(_HELP_OPERATOR_ID, text='', icon='QUESTION')
        except Exception:
            return None
    _safe_set_operator_property(op, 'topic_key', str(topic_key or ''), strict=True, operator_id=_HELP_OPERATOR_ID)
    return op



def _draw_section_help_button(row, topic_key: str):
    if row is None or not str(topic_key or '').strip():
        return None
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    return _draw_help_button_inline(row, topic_key)




_SAFE_OPEN_WHEN_ACTIVE_OBJECT_UNSELECTED = {
    'show_section_smart_transform_info',
}


def _ui_mode_requires_lightweight_sections() -> bool:
    """Return True while Blender is in a fragile mode/redraw state.

    Blender 5.1's panel handler is especially sensitive while a visible N-panel
    redraws a deep custom UI during mode switches.  The section headers remain
    visible, but heavy section bodies are held closed outside stable selected
    Object mode.  This avoids ui_handler_panel access violations and long UI
    stalls while still keeping all top-level controls discoverable.
    """
    try:
        ctx = getattr(bpy, 'context', None)
        mode = str(getattr(ctx, 'mode', '') or '').upper()
        obj = getattr(ctx, 'object', None) or getattr(ctx, 'active_object', None)
        if obj is None:
            return False
        obj_mode = str(getattr(obj, 'mode', '') or '').upper()
        if mode and mode != 'OBJECT':
            return True
        if obj_mode and obj_mode != 'OBJECT':
            return True
        try:
            if not bool(obj.select_get()):
                return True
        except Exception:
            return False
    except Exception:
        return False
    return False


def _force_section_body_closed_for_ui_safety(prop_name: str) -> bool:
    # Do not hide or force-close any N-panel section based on selection or mode.
    # Object-dependent controls guard their application path instead, so the UI
    # remains visible and editable even while Blender is in Edit/Sculpt mode or
    # no object is selected.
    del prop_name
    return False


class _NullUILayout:
    """No-op layout used when a native child panel is collapsed."""
    enabled = False
    active = False
    alignment = 'LEFT'
    use_property_split = False
    use_property_decorate = False
    scale_x = 1.0
    scale_y = 1.0

    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        def _noop(*_args, **_kwargs):
            return self
        return _noop

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def label(self, *args, **kwargs):
        return None

    def prop(self, *args, **kwargs):
        return None

    def operator(self, *args, **kwargs):
        return _SAFE_MISSING_OPERATOR

    def separator(self, *args, **kwargs):
        return None


_NULL_LAYOUT = _NullUILayout()


def _finish_section_body_layout(body):
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    return body


def _draw_child_panel_group(layout, panel_id: str, label: str, *, icon: str = 'NONE', topic_key: str = '', default_open: bool = True, state_owner=None, state_prop: str = ''):
    """Draw a child group exclusively through Blender's native panel API."""
    if layout is None:
        return None

    panel_id = str(panel_id or '').strip() or 'sts_child_section'
    icon_name = str(icon or 'NONE') or 'NONE'
    state_prop = str(state_prop or '').strip()
    try:
        opened = bool(getattr(state_owner, state_prop, bool(default_open))) if state_owner is not None and state_prop and hasattr(state_owner, state_prop) else bool(default_open)
    except Exception:
        opened = bool(default_open)

    header = None
    body = None
    panel_created = False
    panel_prop_fn = getattr(layout, 'panel_prop', None)
    if callable(panel_prop_fn) and state_owner is not None and state_prop and hasattr(state_owner, state_prop):
        try:
            header, body = panel_prop_fn(state_owner, state_prop)
            panel_created = True
        except Exception:
            header = None
            body = None
    if not panel_created:
        panel_fn = getattr(layout, 'panel', None)
        if not callable(panel_fn):
            return None
        try:
            header, body = panel_fn(panel_id, default_closed=not bool(opened))
        except Exception:
            return None

    if header is not None:
        try:
            header.use_property_split = False
            header.use_property_decorate = False
        except Exception:
            pass
        _draw_icon_label(header, str(label or ''), icon=icon_name)
        _draw_section_help_button(header, topic_key)

    if body is None:
        return None
    return _finish_section_body_layout(body)


def _draw_child_prop_group(layout, panel_id: str, label: str, *, icon: str = 'NONE', topic_key: str = '', default_open: bool = True, state_owner=None, state_prop: str = ''):
    return _draw_child_panel_group(
        layout,
        panel_id,
        label,
        icon=icon,
        topic_key=topic_key,
        default_open=default_open,
        state_owner=state_owner,
        state_prop=state_prop,
    )


def _draw_npanel_section(layout, prefs, prop_name: str, label: str, *, icon: str = 'NONE', topic_key: str = '', default_open: bool = True, use_native_header: bool = False):
    """Draw a top-level N-panel section.

    Top-level Smart Transform sections intentionally use the explicit legacy
    header order: triangle, icon, section title, and help button.  Child groups
    can opt in to Blender's native panel header with use_native_header=True.
    """
    if layout is None:
        return None
    try:
        opened = bool(getattr(prefs, str(prop_name), bool(default_open))) if prefs is not None else bool(default_open)
    except Exception:
        opened = bool(default_open)
    try:
        if opened and _force_section_body_closed_for_ui_safety(str(prop_name)):
            opened = False
    except Exception:
        pass

    icon_name = str(icon or 'NONE') or 'NONE'
    if bool(use_native_header):
        try:
            panel_prop_fn = getattr(layout, 'panel_prop', None)
            if callable(panel_prop_fn) and prefs is not None and hasattr(prefs, str(prop_name)):
                header, body = panel_prop_fn(prefs, str(prop_name))
                if header is not None:
                    try:
                        header.use_property_split = False
                        header.use_property_decorate = False
                    except Exception:
                        pass
                    _draw_icon_label(header, str(label or ''), icon=icon_name)
                    _draw_section_help_button(header, topic_key)
                if body is None:
                    return None
                return _finish_section_body_layout(body)
        except Exception:
            pass

    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        header = box.row(align=True)
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        header = box

    op_id = 'core_suite.toggle_npanel_foldout'
    try:
        op = header.operator(op_id, text='', icon='TRIA_DOWN' if opened else 'TRIA_RIGHT', emboss=True, depress=opened)
        _safe_set_operator_property(op, 'prop_name', str(prop_name), strict=True, operator_id=op_id)
    except Exception:
        try:
            header.label(text='', icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
        except Exception:
            pass
    try:
        op = header.operator(op_id, text=str(label or ''), icon=icon_name, emboss=False, depress=opened)
        _safe_set_operator_property(op, 'prop_name', str(prop_name), strict=True, operator_id=op_id)
    except Exception:
        try:
            header.label(text=str(label or ''), icon=icon_name)
        except TypeError:
            try:
                header.label(text=str(label or ''))
            except Exception:
                pass
    _draw_section_help_button(header, topic_key)

    if not opened:
        return None
    try:
        return _finish_section_body_layout(box.column(align=True))
    except Exception:
        return box


def draw_npanel_section(layout, prefs, prop_name: str, label: str, *, icon: str = 'NONE', topic_key: str = '', default_open: bool = True):
    return _draw_npanel_section(layout, prefs, prop_name, label, icon=icon, topic_key=topic_key, default_open=default_open, use_native_header=False)


def _draw_integrated_tool_section(layout, prefs, prop_name: str, label: str, *, icon: str = 'NONE', topic_key: str = ''):
    try:
        default_open = bool(getattr(prefs, str(prop_name), False)) if prefs is not None and hasattr(prefs, str(prop_name)) else False
    except Exception:
        default_open = False
    return _draw_child_prop_group(
        layout,
        f'sts_integrated_{str(prop_name)}',
        label,
        icon=icon,
        topic_key=topic_key,
        default_open=default_open,
        state_owner=prefs,
        state_prop=str(prop_name),
    )


def _draw_integrated_tool_row(layout, prefs, prop_name: str, label: str, *, icon: str = 'NONE', topic_key: str = ''):
    """Draw one Other Tools row using a flat Smart Selector style row.

    Do not use split(), separator_spacer(), or nested right-aligned subrows here.
    Those constructs caused persistent stair-step indentation in Blender 5.1 UI
    panels after repeated redraws.  A flat row keeps every item anchored to the
    same parent column and prevents following boxes from inheriting offsets.
    """
    if layout is None or prefs is None:
        return None
    try:
        row = layout.row(align=True)
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        row = layout
    try:
        row.label(text=str(label or ''), icon=str(icon or 'NONE') or 'NONE')
    except TypeError:
        try:
            row.label(text=str(label or ''))
        except Exception:
            pass
    except Exception:
        pass
    try:
        row.prop(prefs, str(prop_name), toggle=True, text=T('Settings'))
    except TypeError:
        try:
            row.prop(prefs, str(prop_name), text=T('Settings'))
        except Exception:
            pass
    except Exception:
        pass
    _draw_help_button_inline(row, topic_key)
    return row


class STS_OT_show_tool_help(bpy.types.Operator):
    # Keep the id literal so static tooling can see this operator is
    # self-registered; _HELP_OPERATOR_ID stays the canonical constant for
    # every call site.
    bl_idname = 'core_suite.show_tool_help'
    bl_label = _ui('Help', 'ヘルプ')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = _ui(
        'Show a detailed help popup for this Smart Transform tool.',
        'このSmart トランスフォームツールの詳細ヘルプをポップアップ表示します。',
    )

    topic_key: StringProperty(
        name=_ui('Help Topic', 'ヘルプ項目'),
        description=_ui('Internal key that selects which detailed Smart Transform help topic is shown in the popup.', '詳細ヘルプポップアップに表示する Smart Transform ヘルプ項目を選択する内部キーです。'),
        default='',
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        try:
            key = str(getattr(properties, 'topic_key', '') or '')
            if key:
                return _ui(
                    'Open this tool help. The popup contains the overview, usage, and all setting explanations.',
                    'このツールのヘルプを開きます。ポップアップ内に機能概要、使用方法、全設定項目の解説を表示します。',
                )
        except Exception:
            pass
        return cls.bl_description

    def execute(self, context):
        topic = str(getattr(self, 'topic_key', '') or '').strip()
        try:
            module = _safe_help_importlib.import_module(f'{__package__}.help')
            show_help = getattr(module, 'show_help_popup', None)
            if callable(show_help):
                show_help(context, topic)
                return {'FINISHED'}
        except Exception:
            self.report({'WARNING'}, _ui('Help could not be opened.', 'ヘルプを開けませんでした。'))
            return {'CANCELLED'}
        self.report({'WARNING'}, _ui('Help is unavailable.', 'ヘルプを利用できません。'))
        return {'CANCELLED'}

def _runtime_alias_label(alias: str) -> str:
    text = str(alias or '').strip()
    labels = {
        'copy_text': _ui('Copy Text', 'テキストコピー'),
        'preferences': _ui('Preferences UI', 'プリファレンスUI'),
        'smart_grs_main': _ui('Smart G-R-S', 'Smart G-R-S'),
        'csdt_gizmo': _ui('3D Smart Gizmo', '3Dスマートギズモ'),
        'csdt_ops': _ui('3D Smart Transform Click', '3Dスマート変形クリック'),
        'cycle_custom_select': _ui('Cycle Custom Select', 'カスタム選択切り替え'),
        'core_panel': _ui('Smart Transform Panel', 'Smart Transformパネル'),
        'quick_align': _ui('Quick Align', 'クイック整列'),
        'quick_multi_edit': _ui('Quick Multi-Edit', 'クイック複数編集'),
        'select_guard': _ui('Smart Select Guard', 'スマート選択ガード'),
        'precision_length_drag': _ui('Precision Numeric Drag', '精密数値ドラッグ'),
    }
    if text in labels:
        return labels[text]
    return ' '.join(part.capitalize() for part in text.replace('_', ' ').split()) or _ui('Runtime Feature', '常時機能')


def _always_on_switches_body_layout(layout, prefs):
    """Return the body layout for the Smart Modeling style always-on foldout."""
    if layout is None or prefs is None:
        return None
    return _draw_npanel_section(
        layout,
        prefs,
        'show_always_on_switches',
        _ui('Always-on Toggles', '常時機能切り替え'),
        icon='TIME',
        topic_key='always_on_toggles',
        default_open=False,
    )

def _switch_state_label(enabled: bool) -> str:
    return _ui('On', '有効') if bool(enabled) else _ui('Off', '無効')


_TOGGLE_SENTINEL = object()
_ALWAYS_ON_PROP_CHANGE_QUEUE: list[tuple[str, str, object]] = []
_ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING = False
_ALWAYS_ON_REDRAW_PENDING = False


def _always_on_setting_path(owner_path: str, prop_name: str) -> str:
    owner_path = str(owner_path or '').strip().strip('.')
    prop_name = str(prop_name or '').strip()
    return f'{owner_path}.{prop_name}' if owner_path else prop_name


def _is_external_always_on_setting(owner_path: str, prop_name: str) -> bool:
    path = _always_on_setting_path(owner_path, prop_name)
    try:
        allowed = set(getattr(_settings, '_ALWAYS_ON_TOGGLE_PROP_PATHS', ()) or ())
    except Exception:
        allowed = set()
    if allowed:
        return path in allowed
    return not path.startswith('show_')



def _coerce_aggregated_always_on_dependencies(prefs) -> bool:
    changed = False
    if prefs is None:
        return False
    try:
        if bool(getattr(prefs, 'enable_smart_gizmo_live_runtime', False)):
            for dep_name in ('gizmo_toggle_state', 'enable_smart_gizmo_style'):
                if hasattr(prefs, dep_name) and not bool(getattr(prefs, dep_name, False)):
                    setattr(prefs, dep_name, True)
                    changed = True
    except Exception:
        pass
    return changed


def _queue_always_on_prop_change(owner_path: str, prop_name: str, value=_TOGGLE_SENTINEL) -> None:
    owner_path = str(owner_path or '').strip()
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return
    global _ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING
    _ALWAYS_ON_PROP_CHANGE_QUEUE.append((owner_path, prop_name, value))
    try:
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            _apply_deferred_always_on_prop_changes()
            return
    except Exception:
        pass
    if _ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING:
        return
    _ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_apply_deferred_always_on_prop_changes, first_interval=0.01)
            return
    except Exception:
        pass
    _apply_deferred_always_on_prop_changes()


def _apply_deferred_always_on_prop_changes():
    global _ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING
    pending = list(_ALWAYS_ON_PROP_CHANGE_QUEUE)
    _ALWAYS_ON_PROP_CHANGE_QUEUE.clear()
    _ALWAYS_ON_PROP_CHANGE_TIMER_RUNNING = False
    if not pending:
        return None
    try:
        prefs = _runtime.get_addon_preferences(getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        prefs = None
    changed = False
    changed_external_always_on = False
    changed_other_deferred = False
    for owner_path, prop_name, value in pending:
        owner = _resolve_always_on_owner(prefs, owner_path)
        if owner is None or not prop_name:
            continue
        try:
            if not hasattr(owner, prop_name):
                continue
            if value is _TOGGLE_SENTINEL:
                value_to_set = not bool(getattr(owner, prop_name))
            else:
                value_to_set = value
            setattr(owner, prop_name, value_to_set)
            changed = True
            try:
                if _coerce_aggregated_always_on_dependencies(prefs):
                    changed_external_always_on = True
            except Exception:
                pass
            if _is_external_always_on_setting(owner_path, prop_name):
                changed_external_always_on = True
            else:
                changed_other_deferred = True
        except Exception:
            pass
    if changed:
        if changed_external_always_on:
            try:
                # Always-on switches are global runtime preferences.  Persist them
                # immediately to config/Smart_Transform_Suite/Smart_Transform_Suite.json so they are not
                # lost on scene changes and do not depend on .blend Scene data.
                _settings.save_always_on_now(getattr(bpy, 'context', None))
            except Exception:
                try:
                    _settings.save_now(getattr(bpy, 'context', None), force=True)
                except Exception:
                    pass
        if changed_other_deferred:
            try:
                _request_prefs_save('deferred_npanel_state_change')
            except Exception:
                pass
        try:
            _queue_always_on_redraw(getattr(bpy, 'context', None))
        except Exception:
            pass
    return None


def flush_pending_always_on_changes(context=None) -> bool:
    """Apply queued Always-on Toggle changes before persistent snapshots."""
    del context
    had_queue = bool(_ALWAYS_ON_PROP_CHANGE_QUEUE)
    try:
        _apply_deferred_always_on_prop_changes()
    except Exception:
        pass
    return had_queue


def _tag_always_on_redraw(context=None) -> None:
    """Refresh N-panel button depression after an always-on switch changes."""
    try:
        if context is not None and getattr(context, 'area', None) is not None:
            context.area.tag_redraw()
    except Exception:
        pass
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                try:
                    if getattr(area, 'type', None) in {'VIEW_3D'}:
                        area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


def _tag_always_on_redraw_delayed():
    global _ALWAYS_ON_REDRAW_PENDING
    _ALWAYS_ON_REDRAW_PENDING = False
    _tag_always_on_redraw(getattr(bpy, 'context', None))
    return None


def _queue_always_on_redraw(context=None) -> None:
    del context
    global _ALWAYS_ON_REDRAW_PENDING
    if _ALWAYS_ON_REDRAW_PENDING:
        return
    _ALWAYS_ON_REDRAW_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_tag_always_on_redraw_delayed, first_interval=0.03)
            return
    except Exception:
        pass
    _tag_always_on_redraw_delayed()


def _resolve_always_on_owner(prefs, owner_path: str):
    owner_path = str(owner_path or '').strip()
    if prefs is None:
        return None
    if not owner_path or owner_path in {'prefs', 'root'}:
        return prefs
    owner = prefs
    for part in owner_path.split('.'):
        part = part.strip()
        if not part:
            continue
        try:
            owner = getattr(owner, part)
        except Exception:
            return None
        if owner is None:
            return None
    return owner


def _rna_prop_description(owner, prop_name: str) -> str:
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', {})
        prop = props.get(prop_name) if hasattr(props, 'get') else None
        desc = str(getattr(prop, 'description', '') or '').strip() if prop is not None else ''
        if desc:
            return desc
    except Exception:
        pass
    return _ui(
        'Enable or disable this always-on Smart Transform feature. This state is written to the external Smart_Transform_Suite.json config file immediately and is restored independently of scene data.',
        'このSmart Transform常時起動機能の有効 / 無効を切り替えます。この状態は外部設定ファイル Smart_Transform_Suite.json に即時保存され、シーンデータに依存せず復元されます。',
    )


class STS_OT_toggle_npanel_foldout(bpy.types.Operator):
    bl_idname = 'core_suite.toggle_npanel_foldout'
    bl_label = _ui('Toggle Settings Foldout', '設定折り畳みを切り替え')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = _ui(
        'Open or close this Smart Transform N-panel settings group. The state is saved after the current UI event finishes to avoid unsafe panel redraw timing.',
        'Smart Transform Nパネルの設定グループを開閉します。パネル再描画中の不安定なタイミングを避けるため、状態保存は現在のUIイベント終了後に行います。',
    )

    prop_name: StringProperty(
        name=_ui('Foldout Property', '折り畳みプロパティ'),
        description=_ui('Internal foldout state property to toggle safely.', '安全に切り替える内部折り畳み状態プロパティです。'),
        default='',
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        try:
            prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
        except Exception:
            prefs = None
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if prefs is None or not prop_name.startswith('show_'):
            return {'CANCELLED'}
        try:
            if not hasattr(prefs, prop_name):
                return {'CANCELLED'}
            _queue_always_on_prop_change('', prop_name)
            _queue_always_on_redraw(context)
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}


class STS_OT_toggle_always_on_property(bpy.types.Operator):
    bl_idname = 'core_suite.toggle_always_on_property'
    bl_label = _ui('Toggle Always-on Setting', '常時起動設定を切り替え')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = _ui(
        'Enable or disable an always-on Smart Transform setting. The state is written to Smart_Transform_Suite.json immediately and restored independently of the open scene.',
        'Smart Transform の常時起動設定を有効または無効にします。この状態は Smart_Transform_Suite.json へ即時保存され、開いているシーンに依存せず復元されます。',
    )

    owner_path: StringProperty(
        name=_ui('Owner Path', '所有者パス'),
        description=_ui('Internal path to the settings owner that contains the always-on property being toggled.', '切り替える常時起動プロパティを持つ設定所有者への内部パスです。'),
        default='',
        options={'SKIP_SAVE'},
    )
    prop_name: StringProperty(
        name=_ui('Property Name', 'プロパティ名'),
        description=_ui('Internal property name of the always-on setting to toggle and save immediately.', '切り替えて即時保存する常時起動設定の内部プロパティ名です。'),
        default='',
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        try:
            prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
            owner = _resolve_always_on_owner(prefs, getattr(properties, 'owner_path', ''))
            prop_name = str(getattr(properties, 'prop_name', '') or '')
            if owner is not None and prop_name:
                return _rna_prop_description(owner, prop_name)
        except Exception:
            pass
        return cls.bl_description

    def execute(self, context):
        try:
            prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
        except Exception:
            prefs = None
        owner = _resolve_always_on_owner(prefs, getattr(self, 'owner_path', ''))
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if owner is None or not prop_name:
            self.report({'WARNING'}, _ui('The selected setting is unavailable.', '選択した設定を取得できません。'))
            return {'CANCELLED'}
        try:
            if not hasattr(owner, prop_name):
                raise AttributeError(prop_name)
            _queue_always_on_prop_change(getattr(self, 'owner_path', ''), prop_name)
            _queue_always_on_redraw(context)
            return {'FINISHED'}
        except Exception:
            self.report({'WARNING'}, _ui('The selected setting could not be changed.', '選択した設定を変更できませんでした。'))
            return {'CANCELLED'}


def _owner_path_from_object(prefs, owner) -> str:
    if owner is prefs:
        return ''
    for name in ('quick_multi_edit', 'select_guard', 'core_panel', 'quick_align', 'mesh_vertex_tools'):
        try:
            if getattr(prefs, name, None) is owner:
                return name
        except Exception:
            pass
    return ''


def _draw_state_operator_button(right, operator_id: str, *, text: str, enabled: bool, icon: str | None = None):
    try:
        right.operator_context = 'EXEC_DEFAULT'
    except Exception:
        pass
    icon_name = icon or ('CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT')
    custom_name = 'enabled' if enabled else 'disabled'
    icon_args = _ui_icon_kwargs(icon=icon_name, operator_id=operator_id, text=text, custom_icon=custom_name)
    try:
        return right.operator(operator_id, text=str(text), emboss=True, depress=bool(enabled), **icon_args)
    except TypeError:
        return right.operator(operator_id, text=str(text), icon=icon_name, emboss=True, depress=bool(enabled))


def _draw_switch_prop_row(layout, owner, prop_name: str, label: str, *, icon: str = 'NONE', prefs=None, owner_path: str | None = None) -> bool:
    if layout is None:
        return False
    prop_name = str(prop_name or '').strip()
    if owner is None or not prop_name:
        return False
    try:
        if not hasattr(owner, prop_name):
            return False
        enabled = bool(getattr(owner, prop_name))
    except Exception:
        return False
    try:
        row = layout.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=str(label))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.use_property_split = False
        right.use_property_decorate = False
        op = _draw_state_operator_button(right.row(align=True), 'core_suite.toggle_always_on_property', text=_switch_state_label(enabled), enabled=enabled)
        _safe_set_operator_property(op, 'owner_path', str(owner_path if owner_path is not None else _owner_path_from_object(prefs, owner)), strict=True, operator_id='core_suite.toggle_always_on_property')
        _safe_set_operator_property(op, 'prop_name', prop_name, strict=True, operator_id='core_suite.toggle_always_on_property')
        return True
    except Exception:
        return False


def _draw_switch_operator_row(layout, operator_id: str, alias: str, feature_key: str, label: str, enabled: bool, *, icon: str = 'NONE') -> bool:
    if layout is None or not operator_id or not alias or not feature_key:
        return False
    try:
        try:
            from . import feature_toggle as _runtime_toggles
            enabled = bool(_runtime_toggles.is_feature_enabled(alias, feature_key))
        except Exception:
            enabled = bool(enabled)
        row = layout.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=str(label))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        op = _draw_state_operator_button(right.row(align=True), operator_id, text=_switch_state_label(enabled), enabled=enabled)
        _safe_set_operator_property(op, 'alias', str(alias), strict=True, operator_id=operator_id)
        _safe_set_operator_property(op, 'feature_key', str(feature_key), strict=True, operator_id=operator_id)
        return True
    except Exception:
        return False




def draw_always_on_toggles_ui(layout, prefs, context=None):
    """Draw every real resident/continuous control in the first N-panel group."""
    if prefs is None or layout is None:
        return
    body = _always_on_switches_body_layout(layout, prefs)
    if body is None:
        return

    ssg = getattr(prefs, 'select_guard', None)

    rows = body.column(align=True)
    try:
        rows.use_property_split = False
        rows.use_property_decorate = False
    except Exception:
        pass
    _draw_switch_prop_row(rows, prefs, 'npanel_state_save_enabled', _ui('N-panel State Save', 'Nパネル状態保存'), prefs=prefs, owner_path='')
    try:
        rows.separator(factor=0.5)
    except Exception:
        pass
    _draw_switch_prop_row(rows, prefs, 'enable_smart_gizmo_live_runtime', _ui('3D Smart Gizmo Runtime', '3Dスマートギズモ常駐'), prefs=prefs, owner_path='')
    _draw_switch_prop_row(rows, prefs, 'prefer_csdt_keymap_priority', _ui('3D Tool Click Priority', '3Dツールクリック優先'), prefs=prefs, owner_path='')
    _draw_switch_prop_row(rows, prefs, 'enable_cursor_lock_feature', _ui('3D Cursor Lock Runtime', '3Dカーソルロック常駐'), prefs=prefs, owner_path='')
    _draw_switch_prop_row(rows, prefs, 'enable_precision_length_drag', _ui('Precision Numeric Drag', '精密数値ドラッグ'), prefs=prefs, owner_path='')
    _draw_switch_prop_row(rows, prefs, 'enable_mesh_island_transform', _ui('Mesh Island Transform', 'アイランド変形'), prefs=prefs, owner_path='')
    _draw_switch_prop_row(rows, ssg, 'pref_scene_runtime_enabled', _ui('Select Guard Runtime', '選択ガード常駐'), prefs=prefs, owner_path='select_guard')
    _draw_switch_prop_row(rows, ssg, 'apply_defaults_on_file_load', _ui('Select Guard File Defaults', '選択ガード読込時既定'), prefs=prefs, owner_path='select_guard')

def draw_core_panel_settings(layout, prefs, *, show_enable_toggle: bool = False):
    if prefs is None or layout is None:
        return

    row = layout.row(align=True)
    _draw_icon_label(row, T("Transform"), icon='CON_TRANSLIKE')
    row.prop(prefs, "show_core_panel_settings", toggle=True, text=T("Settings"))
    _draw_help_button(row, 'core_panel', icon='QUESTION')

    if prefs.show_core_panel_settings:
        stp = _ensure_stp_scale_link_migration(prefs.core_panel)
        box_stp = layout.box()
        box_stp.prop(stp, "use_scene_orientation", text=_ui('Use Scene Transform Orientation', 'シーンの変形方向を使う'))
        box_stp.prop(stp, "delta_display_mode", text=_ui('Δ Display', 'Δ表示'))
        box_stp.prop(stp, "delta_scale_style", text=_ui('Δ Scale', 'Δ拡縮'))
        link_box = box_stp.box()
        row_link_head = link_box.row(align=True)
        row_link_head.label(text=_ui('Scale Link Axes', 'スケールリンク軸'))
        _draw_help_button(row_link_head, 'core_scale_link_axes', icon='QUESTION')
        row_link = link_box.row(align=True)
        row_link.prop(stp, "scale_link_x", toggle=True)
        row_link.prop(stp, "scale_link_y", toggle=True)
        row_link.prop(stp, "scale_link_z", toggle=True)
        box_stp.prop(stp, "pose_each_rotation_mode", text=_ui('Pose', 'ポーズ'))
        _draw_manual_keymap_registration_box(
            box_stp,
            title=_ui('Transform Popup Keymap Registration', 'Transformポップアップ キーマップ登録'),
            topic_key='core_panel',
            locations=(
                (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
            ),
            entries=(
                (_ui('Popup Operator ID', 'ポップアップ登録ID'), str(getattr(stp, 'keymap_id', 'wm.core') or 'wm.core')),
            ),
        )


def draw_suite_preferences_ui(prefs, layout, context=None, *, show_integrated_core_panel: bool = True, show_always_on_toggles: bool = True):
    if prefs is None or layout is None:
        return
    if context is None:
        context = getattr(bpy, "context", None)

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    def _section(prop_name: str, label: str, icon: str, topic_key: str, *, default_open: bool = True):
        return _draw_npanel_section(layout, prefs, prop_name, label, icon=icon, topic_key=topic_key, default_open=default_open)

    if show_always_on_toggles:
        draw_always_on_toggles_ui(layout, prefs, context)

    # --- Target Tools ---
    body = _section('show_section_target_tools', T("Target Tools"), 'TOOL_SETTINGS', 'target_tools')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='TARGET_TOOLS')
        col = body.column(align=True)
        col.prop(prefs, "enable_move", text=T("Enable for Move Tool"))
        col.prop(prefs, "enable_rotate", text=T("Enable for Rotate Tool"))
        col.prop(prefs, "enable_scale", text=T("Enable for Scale Tool"))
        col.prop(prefs, "enable_transform", text=T("Enable for Transform Tool"))

    # --- Selection Behavior ---
    body = _section('show_section_selection_behavior', T("Selection Behavior"), 'RESTRICT_SELECT_OFF', 'selection_behavior')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='SELECTION')
        body.prop(prefs, "use_immediate_select", text=T("Immediate Select (On Press)"))
        body.prop(prefs, "smart_gizmo_click_select_priority", text=_ui('Element Click over Gizmo', 'ギズモ上でも要素を選択'))
        body.prop(prefs, "keep_multi_selection", text=T("Keep Multi-Selection on Drag"))
        body.prop(prefs, "update_active_element", text=T("Update Active Element"))
        body.prop(prefs, "enable_click_through", text=T("Click Through Unselectable"))
        body.prop(prefs, "enable_back_element_click_select", text=_ui('Backside Element Click Select', '背面エレメントクリック選択'))
        body.prop(prefs, "crossing_select_edges", text=_ui('Crossing Selection: Edges', '交差選択: 辺'))
        body.prop(prefs, "crossing_select_faces", text=_ui('Crossing Selection: Faces', '交差選択: 面'))
        _draw_manual_keymap_registration_box(
            body,
            title=_ui('3D Selection Keymap Registration', '3D選択キーマップ登録'),
            topic_key='selection_operator_ids',
            locations=(
                (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
            ),
            entries=(
                (_ui('3D Click Handler ID', '3Dクリック処理ID'), 'view3d.sts_csdt_force'),
                (_ui('Exact Select ID', '3D単独精密選択ID'), 'view3d.csdt_single_select_no_drag'),
            ),
        )

    # --- Transform Behavior ---
    body = _section('show_section_transform_behavior', T("Transform Behavior"), 'ORIENTATION_GIMBAL', 'transform_behavior')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='TRANSFORM')
        body.prop(prefs, "enable_drag_transform", text=T("Drag to Transform"))
        body.prop(prefs, "enable_axis_memory", text=T("Smart Axis Memory"))
        body.prop(prefs, "smart_gizmo_use_circular_rotation", text=_ui('Gizmo Circular Rotation', 'ギズモ円周回転'))
        body.prop(prefs, "smart_gizmo_use_distance_scale", text=_ui('Gizmo Distance Scale', 'ギズモ距離スケール'))
        body.prop(prefs, "tool_disallow_negative_scale", text=_ui('Disallow Negative Scale', 'マイナススケール禁止'))

    # --- Background Interaction ---
    body = _section('show_section_background_interaction', T("Background Interaction"), 'SCENE_DATA', 'background_interaction')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='BACKGROUND')
        body.prop(prefs, "enable_bg_deselect", text=T("Background Click Deselect"))
        body.prop(prefs, "enable_bg_drag_select", text=T("Background Drag Select"))

    # --- Sensitivity Settings ---
    body = _section('show_section_sensitivity', T("Sensitivity Settings"), 'DRIVER_DISTANCE', 'sensitivity_settings')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='SENSITIVITY')
        body.prop(prefs, "drag_threshold", text=T("Drag Threshold (px)"))
        body.prop(prefs, "vert_hit_radius", text=T("Vertex Hit Radius (px)"))
        body.prop(prefs, "edge_hit_radius", text=T("Edge Hit Radius (px)"))
        try:
            from .core import grs_main as smart_grs_main
            try:
                smart_grs_main.draw_sensitivity_preferences(prefs, body)
            except TypeError:
                smart_grs_main._draw_grs_sensitivity_section(body, prefs)
        except Exception:
            pass

    # --- 3D Smart Gizmo Settings ---
    body = _section('show_section_smart_gizmo', T("3D Smart Gizmo Settings"), 'GIZMO', 'smart_gizmo_3d')
    if body is not None:
        row_reset = body.row(align=True)
        _safe_layout_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='SMART_GIZMO')
        sub = body.column(align=True)
        sub.enabled = True
        sub.prop(prefs, "enable_smart_gizmo_rotate", text=T("Enable 3D Smart Gizmo: Rotate"))
        sub.prop(prefs, "enable_smart_gizmo_scale", text=T("Enable 3D Smart Gizmo: Scale"))
        sub.prop(prefs, "enable_smart_gizmo_transform", text=T("Enable 3D Smart Gizmo: Transform"))
        row_comp = sub.row(align=True)
        row_comp.enabled = True
        row_comp.prop(prefs, "smart_gizmo_transform_show_move", toggle=True, text=T("Move"))
        row_comp.prop(prefs, "smart_gizmo_transform_show_rotate", toggle=True, text=T("Rotate"))
        row_comp.prop(prefs, "smart_gizmo_transform_show_scale", toggle=True, text=T("Scale"))
        sub.prop(prefs, "smart_gizmo_screen_scale", text=_ui('Screen Scale', '表示スケール'))
        sub.prop(prefs, "smart_axis_scale", text=T("XYZ Axis"))
        sub.prop(prefs, "smart_plane_scale", text=T("Plane Axis"))
        sub.prop(prefs, "smart_center_scale", text=T("Free Axis"))
        sub.prop(prefs, "gizmo_pick_range_px", text=T("Gizmo Pick Range (px)"))
        box_color = sub.box()
        row_color_head = box_color.row(align=True)
        _draw_icon_label(row_color_head, T("3D Smart Gizmo Colors"), icon='COLOR')
        _draw_help_button(row_color_head, 'smart_gizmo_colors', icon='QUESTION')
        row_c = box_color.row(align=True)
        row_c.prop(prefs, "color_x", text=T("X"))
        row_c.prop(prefs, "color_y", text=T("Y"))
        row_c.prop(prefs, "color_z", text=T("Z"))
        col_c2 = box_color.column(align=True)
        col_c2.prop(prefs, "color_free", text=T("Free Axis Color"))
        col_c2.prop(prefs, "color_highlight", text=T("Highlight Color"))
        _draw_manual_keymap_registration_box(
            sub,
            title=_ui('3D Smart Gizmo Keymap Registration', '3Dスマートギズモ キーマップ登録'),
            topic_key='smart_gizmo_3d',
            locations=(
                (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
            ),
            entries=(
                (_ui('Toggle Operator ID', '切り替え登録ID'), str(getattr(prefs, 'shortcut_id_display', 'view3d.csdt_toggle_smart_gizmo') or 'view3d.csdt_toggle_smart_gizmo')),
            ),
        )

    # --- Smart G-R-S Transform ---
    body = _section('show_section_smart_grs', TI('Smart G-R-S Transform', 'Smart G-R-S変形'), 'CON_TRANSLIKE', 'smart_grs')
    if body is not None:
        try:
            from .core import grs_main as smart_grs_main
            try:
                smart_grs_main.draw_preferences(prefs, body, show_header=False)
            except TypeError:
                smart_grs_main.draw_preferences(prefs, body)
        except Exception:
            pass
        _draw_manual_keymap_registration_box(
            body,
            title=_ui('Smart G-R-S Keymap Registration', 'Smart G-R-S キーマップ登録'),
            topic_key='smart_grs',
            locations=(
                (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
            ),
            entries=(
                (_ui('Move G Operator ID', '移動G登録ID'), str(getattr(prefs, 'grs_move_operator_id_display', 'transform.smart_grs_move') or 'transform.smart_grs_move')),
                (_ui('Rotate R Operator ID', '回転R登録ID'), str(getattr(prefs, 'grs_rotate_operator_id_display', 'transform.smart_grs_rotate') or 'transform.smart_grs_rotate')),
                (_ui('Scale S Operator ID', 'スケールS登録ID'), str(getattr(prefs, 'grs_scale_operator_id_display', 'transform.smart_grs_scale') or 'transform.smart_grs_scale')),
            ),
        )
    # --- Proportional Editing ---
    body = _section('show_section_proportional', TI('Proportional Editing', 'プロポーショナル編集'), 'DRIVER_DISTANCE', 'grs_proportional_editing')
    if body is not None:
        try:
            from .core import grs_main as smart_grs_main
            try:
                smart_grs_main.draw_proportional_editing_preferences(prefs, body, show_header=False)
            except TypeError:
                smart_grs_main.draw_proportional_editing_preferences(prefs, body)
        except Exception:
            pass
        _draw_manual_keymap_registration_box(
            body,
            title=_ui('Proportional Editing Keymap Registration', 'プロポーショナル編集キーマップ登録'),
            topic_key='grs_proportional_editing',
            locations=(
                (_ui('3D View Cursor Tool Location', '3Dビュー カーソル調整登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                (_ui('Modal Actions Location', 'モーダル操作登録場所'), _ui('Preferences > Keymap > Transform Modal Map', 'プリファレンス > キーマップ > トランスフォームモーダルマップ')),
            ),
            entries=(
                (_ui('Cursor Tool ID', 'カーソル調整登録ID'), 'view3d.proportional_size_cursor', _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                (_ui('Adjust Modal Action ID', '連続調整モーダルID'), str(getattr(prefs, 'prop_adjust_action_display', 'PROPORTIONAL_SIZE') or 'PROPORTIONAL_SIZE'), _ui('Preferences > Keymap > Transform Modal Map', 'プリファレンス > キーマップ > トランスフォームモーダルマップ')),
                (_ui('Step Up ID', '拡大モーダルID'), str(getattr(prefs, 'prop_adjust_up_display', 'PROPORTIONAL_SIZE_UP') or 'PROPORTIONAL_SIZE_UP'), _ui('Preferences > Keymap > Transform Modal Map', 'プリファレンス > キーマップ > トランスフォームモーダルマップ')),
                (_ui('Step Down ID', '縮小モーダルID'), str(getattr(prefs, 'prop_adjust_down_display', 'PROPORTIONAL_SIZE_DOWN') or 'PROPORTIONAL_SIZE_DOWN'), _ui('Preferences > Keymap > Transform Modal Map', 'プリファレンス > キーマップ > トランスフォームモーダルマップ')),
            ),
        )

    # --- HUD / Numeric Input ---
    body = _section('show_section_hud_numeric', TI('HUD / Numeric Input', 'HUD / 数値入力'), 'FONT_DATA', 'hud_numeric_input')
    if body is not None:
        try:
            from .core import grs_main as smart_grs_main
            try:
                smart_grs_main.draw_hud_numeric_input_preferences(prefs, body, show_header=False)
            except TypeError:
                smart_grs_main.draw_hud_numeric_input_preferences(prefs, body)
        except Exception:
            pass

    # --- Overlay Anti-Aliasing ---
    body = _section('show_section_overlay_aa', _ui('Overlay Anti-Aliasing', '線のアンチエイリアス'), 'MOD_SMOOTH', 'overlay_anti_aliasing')
    if body is not None:
        row_aa = body.row(align=True)
        row_aa.prop(prefs, "overlay_aa_mode", expand=True)

    # --- Other Tools ---
    body = _section('show_section_integrated_tools', _ui('Other Tools', 'その他ツール'), 'PLUGIN', 'integrated_tools')
    if body is not None:
        col_suite = body
        try:
            col_suite.use_property_split = False
            col_suite.use_property_decorate = False
        except Exception:
            pass

        affect_only_box = col_suite.box()
        affect_only_box.prop(
            prefs,
            'affect_only_all_object_types',
            text=_ui('Apply Affect Only to All Object Types', '影響の限定を全オブジェクトへ適用'),
            icon='OBJECT_ORIGIN',
        )

        if show_integrated_core_panel:
            core_body = _draw_integrated_tool_section(col_suite, prefs, 'show_core_panel_settings', T("Transform"), icon='CON_TRANSLIKE', topic_key='core_panel')
            if core_body is not None:
                stp = _ensure_stp_scale_link_migration(prefs.core_panel)
                core_body.prop(stp, "use_scene_orientation", text=_ui('Use Scene Transform Orientation', 'シーンの変形方向を使う'))
                core_body.prop(stp, "delta_display_mode", text=_ui('Δ Display', 'Δ表示'))
                core_body.prop(stp, "delta_scale_style", text=_ui('Δ Scale', 'Δ拡縮'))
                link_box = core_body.box()
                row_link_head = link_box.row(align=True)
                row_link_head.label(text=_ui('Scale Link Axes', 'スケールリンク軸'))
                _draw_help_button(row_link_head, 'core_scale_link_axes', icon='QUESTION')
                row_link = link_box.row(align=True)
                row_link.prop(stp, "scale_link_x", toggle=True)
                row_link.prop(stp, "scale_link_y", toggle=True)
                row_link.prop(stp, "scale_link_z", toggle=True)
                core_body.prop(stp, "pose_each_rotation_mode", text=_ui('Pose', 'ポーズ'))
                _draw_manual_keymap_registration_box(
                    core_body,
                    title=_ui('Transform Popup Keymap Registration', 'Transformポップアップ キーマップ登録'),
                    topic_key='core_panel',
                    locations=(
                        (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    ),
                    entries=(
                        (_ui('Popup Operator ID', 'ポップアップ登録ID'), str(getattr(stp, 'keymap_id', 'wm.core') or 'wm.core')),
                    ),
                )

        cursor_body = _draw_integrated_tool_section(col_suite, prefs, 'show_cursor_lock_settings', _ui('3D Cursor Lock', '3Dカーソルロック'), icon='PIVOT_CURSOR', topic_key='cursor_lock')
        if cursor_body is not None:
            _draw_switch_prop_row(cursor_body, prefs, 'enable_cursor_lock_feature', _ui('3D Cursor Lock Runtime', '3Dカーソルロック常駐'), prefs=prefs, owner_path='')

        pld_body = _draw_integrated_tool_section(col_suite, prefs, 'show_precision_length_drag_settings', _ui('Precision Numeric Drag', '精密数値ドラッグ'), icon='DRIVER_DISTANCE', topic_key='precision_length_drag')
        if pld_body is not None:
            steps_box = pld_body.box()
            _draw_icon_label(steps_box, _ui('Blender Unit Steps', 'Blender単位別刻み'), icon='DRIVER_DISTANCE')
            for category, prop_name, label_en, label_ja in (
                ('rotation', 'precision_numeric_drag_step_rotation', 'Rotation', '回転'),
                ('length', 'precision_numeric_drag_step_length', 'Length', '長さ'),
                ('mass', 'precision_numeric_drag_step_mass', 'Mass', '質量'),
                ('time', 'precision_numeric_drag_step_time_display', 'Time', '時間'),
                ('temperature', 'precision_numeric_drag_step_temperature', 'Temp', '温度'),
            ):
                row_step = steps_box.split(factor=0.62, align=True)
                try:
                    row_step.prop(prefs, prop_name, text=_ui(label_en, label_ja))
                except Exception:
                    continue
                try:
                    row_step.label(text=_precision_drag_scene_unit_name(context, category))
                except Exception:
                    pass
            _draw_manual_keymap_registration_box(
                pld_body,
                title=_ui('Precision Numeric Drag Keymap Registration', '精密数値ドラッグ キーマップ登録'),
                topic_key='precision_length_drag',
                locations=(
                    (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > Screen > Screen Editing', 'プリファレンス > キーマップ > スクリーン > スクリーン編集')),
                ),
                entries=(
                    (_ui('Operator ID', '登録ID'), 'wm.smart_transform_precision_numeric_drag'),
                ),
            )

        ccs_body = _draw_integrated_tool_section(col_suite, prefs, 'show_cycle_custom_select_settings', T('Cycle Custom Select'), icon='RESTRICT_SELECT_OFF', topic_key='cycle_custom_select')
        if ccs_body is not None:
            row_ccs_run = ccs_body.row(align=True)
            _safe_layout_operator(row_ccs_run, "view3d.cycle_custom_select", text=_ui('Run Cycle Custom Select', 'カスタム選択切り替えを実行'), icon='RESTRICT_SELECT_OFF', custom_icon='cycle')
            mode_box = ccs_body.box()
            row_mode_head = mode_box.row(align=True)
            _draw_icon_label(row_mode_head, _ui('Selection Modes', '選択モード'), icon='TOOL_SETTINGS', custom_icon='settings')
            mode_box.prop(prefs, "custom_select_mode", text=_ui('Current', '現在'))
            row_modes = mode_box.row(align=True)
            row_modes.prop(prefs, "custom_select_enable_tweak", toggle=True)
            row_modes.prop(prefs, "custom_select_enable_box", toggle=True)
            row_modes = mode_box.row(align=True)
            row_modes.prop(prefs, "custom_select_enable_circle", toggle=True)
            row_modes.prop(prefs, "custom_select_enable_lasso", toggle=True)
            _draw_manual_keymap_registration_box(
                ccs_body,
                title=_ui('Cycle Custom Select Keymap Registration', 'カスタム選択切り替え キーマップ登録'),
                topic_key='cycle_custom_select',
                locations=(
                    (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                ),
                entries=(
                    (_ui('Operator ID', '登録ID'), str(getattr(prefs, 'cycle_custom_select_id_display', 'view3d.cycle_custom_select') or 'view3d.cycle_custom_select')),
                ),
            )

        qa_body = _draw_integrated_tool_section(col_suite, prefs, 'show_quick_align_settings', T('Quick Align'), icon='EMPTY_ARROWS', topic_key='quick_align')
        if qa_body is not None:
            qa = prefs.quick_align
            row_ops = qa_body.column(align=True)
            try:
                row_ops.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            _safe_layout_operator(row_ops, "object.quick_align_tool", text=_ui('Start Quick Align', 'クイック整列を開始'), icon='EMPTY_ARROWS')
            _safe_layout_operator(row_ops, "object.quick_align_popup", text=_ui('Open Align Dialog', '整列ダイアログを開く'), icon='WINDOW')
            qa_body.prop(qa, "warp_cursor_after_pick", text=_ui('Warp Cursor on Open', '窓を開く時にカーソルをずらす'))
            subr = qa_body.row(align=True)
            subr.enabled = True
            subr.prop(qa, "warp_offset_px", text=_ui('Warp Offset (px)', 'ワープオフセット (px)'))
            qa_body.prop(qa, "preview_throttle_ms", text=_ui('Preview Throttle (ms)', 'プレビュー更新間隔 (ms)'))
            _draw_manual_keymap_registration_box(
                qa_body,
                title=_ui('Quick Align Keymap Registration', 'クイック整列 キーマップ登録'),
                topic_key='quick_align_ids',
                locations=(
                    (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View > Object Mode', 'プリファレンス > キーマップ > 3Dビュー > オブジェクトモード')),
                ),
                entries=(
                    (_ui('Start Tool ID', '開始ツールID'), str(getattr(qa, 'operator_id', 'object.quick_align_tool') or 'object.quick_align_tool')),
                    (_ui('Dialog Popup ID', 'ダイアログID'), 'object.quick_align_popup'),
                    (_ui('Dialog Swap ID', 'ダイアログ入替ID'), 'object.quick_align_swap_refs'),
                    (_ui('Dialog Reset ID', 'ダイアログリセットID'), 'object.quick_align_reset_dialog'),
                ),
            )

        qme_body = _draw_integrated_tool_section(col_suite, prefs, 'show_quick_multi_edit_settings', T('Quick Multi-Edit'), icon='EDITMODE_HLT', topic_key='quick_multi_edit')
        if qme_body is not None:
            qme = prefs.quick_multi_edit
            if not qme.use_custom_keymap:
                guide = qme_body.box()
                row_guide_head = guide.row(align=True)
                _draw_icon_label(row_guide_head, _ui('Default Click Shortcuts', '既定クリックショートカット'), icon='MOUSE_RMB')
                _draw_help_button(row_guide_head, 'qme_click_shortcuts', icon='QUESTION')
                guide.prop(qme, "default_mouse_button", text=_ui('Mouse', 'マウス'))
            else:
                guide = qme_body.box()
                row_guide_head = guide.row(align=True)
                _draw_icon_label(row_guide_head, _ui('Custom Keymap', 'カスタムキーマップ'), icon='KEYINGSET')
                _draw_help_button(row_guide_head, 'qme_click_shortcuts', icon='QUESTION')
                _draw_qme_binding_editor(guide, qme, 'add', _ui('Add', '加算'), qme.copy_id_add)
                _draw_qme_binding_editor(guide, qme, 'remove', _ui('Remove', '減算'), qme.copy_id_remove)
                _draw_qme_binding_editor(guide, qme, 'toggle', _ui('Toggle', '切り替え'), qme.copy_id_toggle)
                _draw_qme_binding_editor(guide, qme, 'isolate', _ui('Switch to Clicked Only (Optional)', 'クリック対象へ単独切り替え（任意）'), qme.copy_id_isolate)
            ops_box = qme_body.box()
            row_ops_head = ops_box.row(align=True)
            _draw_icon_label(row_ops_head, _ui('Operations', '操作'), icon='TOOL_SETTINGS')
            _draw_help_button(row_ops_head, 'qme_operations', icon='QUESTION')
            row_click_ops = ops_box.row(align=True)
            try:
                row_click_ops.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            _safe_layout_operator(row_click_ops, qme.copy_id_add, text=_ui('Add', '加算'))
            _safe_layout_operator(row_click_ops, qme.copy_id_remove, text=_ui('Remove', '減算'))
            row_click_ops = ops_box.row(align=True)
            try:
                row_click_ops.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            _safe_layout_operator(row_click_ops, qme.copy_id_toggle, text=_ui('Toggle', '切替'))
            _safe_layout_operator(row_click_ops, qme.copy_id_isolate, text=_ui('Solo', '単独'))
            row_ops = ops_box.row(align=True)
            _safe_layout_operator(row_ops, qme.copy_id_restore, text=_ui('Restore Previous', '前回復元'), icon='LOOP_BACK')
            row_batch_box = ops_box.row(align=True)
            try:
                row_batch_box.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            _safe_layout_operator(row_batch_box, qme.copy_id_box_add, text=_ui('Box+', '箱で加算'))
            _safe_layout_operator(row_batch_box, qme.copy_id_box_remove, text=_ui('Box-', '箱で減算'))
            _safe_layout_operator(row_batch_box, qme.copy_id_box_toggle, text=_ui('Box ±', '箱で切替'))
            row_batch_lasso = ops_box.row(align=True)
            try:
                row_batch_lasso.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            _safe_layout_operator(row_batch_lasso, qme.copy_id_lasso_add, text=_ui('Lasso+', '縄で加算'))
            _safe_layout_operator(row_batch_lasso, qme.copy_id_lasso_remove, text=_ui('Lasso-', '縄で減算'))
            _safe_layout_operator(row_batch_lasso, qme.copy_id_lasso_toggle, text=_ui('Lasso ±', '縄で切替'))
            row_coll_a = ops_box.column(align=True)
            _safe_layout_operator(row_coll_a, "view3d.quick_multi_edit_collection_set", text=_ui('Set from Active Collection', 'アクティブコレクション設定'), icon='OUTLINER_COLLECTION')
            _safe_layout_operator(row_coll_a, "view3d.quick_multi_edit_collection_add", text=_ui('Add Collection', 'コレクション加算'), icon='ADD')
            row_coll_b = row_coll_a
            _safe_layout_operator(row_coll_b, "view3d.quick_multi_edit_collection_remove", text=_ui('Remove Collection', 'コレクション減算'), icon='REMOVE')
            _safe_layout_operator(row_coll_b, "view3d.quick_multi_edit_collection_toggle", text=_ui('Toggle Collection', 'コレクション切替'), icon='FILE_REFRESH')
            qme_body.separator()
            qme_body.label(text=_ui('Active Behavior', 'アクティブ挙動'))
            qme_body.prop(qme, "active_behavior", text='')
            qme_body.prop(qme, "restrict_same_type", text=_ui('Restrict to same object type as active', 'アクティブと同種のみ'))
            qme_body.prop(qme, "respect_visibility_select_lock", text=_ui('Respect visibility/selection locks', '非表示・選択不可を尊重'))
            qme_body.prop(qme, "filter_same_collection", text=_ui('Only same collection', '同じコレクションのみ'))
            qme_body.prop(qme, "filter_name_prefix", text=_ui('Only same name prefix', '同じ名前接頭辞のみ'))
            if qme.filter_name_prefix:
                qme_body.prop(qme, "custom_name_prefix", text=_ui('Custom name prefix', 'カスタム接頭辞'))
            qme_body.prop(qme, "enable_cycle_pick", text=_ui('Enable cycle pick', '背面候補の巡回選択'))
            sub2 = qme_body.column(align=True)
            sub2.enabled = True
            sub2.prop(qme, "cycle_timeout", text=_ui('Cycle timeout (sec)', '巡回タイムアウト'))
            sub2.prop(qme, "cycle_pixel_threshold", text=_ui('Cycle pixel threshold', '巡回ピクセル閾値'))
            sub2.prop(qme, "max_cycle_hits", text=_ui('Max cycle hits', '巡回候補上限'))
            qme_body.prop(qme, "fast_path_no_mode_toggle", text=_ui('Fast path without mode toggle', 'モード切替なし高速処理'))
            qme_body.prop(qme, "show_status_report", text=_ui('Show status report', 'ステータス表示'))
            qme_body.prop(qme, "show_hud", text=_ui('Show HUD message in viewport', 'ビューポートHUD表示'))
            sub_hud = qme_body.column(align=True)
            sub_hud.enabled = True
            sub_hud.prop(qme, "hud_duration", text=_ui('HUD duration (sec)', 'HUD表示時間'))
            qme_body.prop(qme, "history_depth", text=_ui('History depth', '履歴保持数'))
            _draw_manual_keymap_registration_box(
                qme_body,
                title=_ui('Quick Multi-Edit Keymap Registration', 'クイック複数編集 キーマップ登録'),
                topic_key='qme_manual_ids',
                locations=(
                    (_ui('3D View Location', '3Dビュー登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Outliner Location', 'アウトライナー登録場所'), _ui('Preferences > Keymap > Outliner', 'プリファレンス > キーマップ > アウトライナー')),
                ),
                entries=(
                    (_ui('Add ID', '加算ID'), str(getattr(qme, 'copy_id_add', 'view3d.quick_multi_edit_add') or 'view3d.quick_multi_edit_add'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Remove ID', '減算ID'), str(getattr(qme, 'copy_id_remove', 'view3d.quick_multi_edit_remove') or 'view3d.quick_multi_edit_remove'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Toggle ID', '切り替えID'), str(getattr(qme, 'copy_id_toggle', 'view3d.quick_multi_edit_toggle') or 'view3d.quick_multi_edit_toggle'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Switch ID', '単独切り替えID'), str(getattr(qme, 'copy_id_isolate', 'view3d.quick_multi_edit_isolate') or 'view3d.quick_multi_edit_isolate'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Box Add ID', '箱で加算ID'), str(getattr(qme, 'copy_id_box_add', 'view3d.quick_multi_edit_box_add') or 'view3d.quick_multi_edit_box_add'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Box Remove ID', '箱で減算ID'), str(getattr(qme, 'copy_id_box_remove', 'view3d.quick_multi_edit_box_remove') or 'view3d.quick_multi_edit_box_remove'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Box Toggle ID', '箱で切替ID'), str(getattr(qme, 'copy_id_box_toggle', 'view3d.quick_multi_edit_box_toggle') or 'view3d.quick_multi_edit_box_toggle'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Lasso Add ID', '縄で加算ID'), str(getattr(qme, 'copy_id_lasso_add', 'view3d.quick_multi_edit_lasso_add') or 'view3d.quick_multi_edit_lasso_add'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Lasso Remove ID', '縄で減算ID'), str(getattr(qme, 'copy_id_lasso_remove', 'view3d.quick_multi_edit_lasso_remove') or 'view3d.quick_multi_edit_lasso_remove'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Lasso Toggle ID', '縄で切替ID'), str(getattr(qme, 'copy_id_lasso_toggle', 'view3d.quick_multi_edit_lasso_toggle') or 'view3d.quick_multi_edit_lasso_toggle'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Restore ID', '復元ID'), str(getattr(qme, 'copy_id_restore', 'view3d.quick_multi_edit_restore_previous') or 'view3d.quick_multi_edit_restore_previous'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Active Collection ID', 'アクティブコレクションID'), str(getattr(qme, 'copy_id_active_collection', 'view3d.quick_multi_edit_from_active_collection') or 'view3d.quick_multi_edit_from_active_collection'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                    (_ui('Outliner Collection ID', 'アウトライナーコレクションID'), 'outliner.quick_multi_edit_from_collection', _ui('Preferences > Keymap > Outliner', 'プリファレンス > キーマップ > アウトライナー')),
                ),
            )

        island_body = _draw_integrated_tool_section(col_suite, prefs, 'show_mesh_island_transform_settings', _ui('Island Transform', 'アイランド変形'), icon='EDITMODE_HLT', topic_key='mesh_island_transform')
        if island_body is not None:
            island_body.prop(prefs, 'mesh_island_transform_individual_pivot_only', text=_ui('Only with Individual Origins', '個別の原点の時だけ使う'))
            _draw_manual_keymap_registration_box(
                island_body,
                title=_ui('Island Transform Keymap Registration', 'アイランド変形 キーマップ登録'),
                topic_key='mesh_island_transform',
                locations=(
                    (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View > Mesh', 'プリファレンス > キーマップ > 3Dビュー > メッシュ')),
                ),
                entries=(
                    (_ui('Move G Operator ID', '移動G登録ID'), str(getattr(prefs, 'mesh_island_transform_move_operator_id', 'mesh.smart_island_move') or 'mesh.smart_island_move')),
                    (_ui('Rotate R Operator ID', '回転R登録ID'), str(getattr(prefs, 'mesh_island_transform_rotate_operator_id', 'mesh.smart_island_rotate') or 'mesh.smart_island_rotate')),
                    (_ui('Scale S Operator ID', 'スケールS登録ID'), str(getattr(prefs, 'mesh_island_transform_scale_operator_id', 'mesh.smart_island_scale') or 'mesh.smart_island_scale')),
                    (_ui('Toggle Operator ID', '切り替え登録ID'), str(getattr(prefs, 'mesh_island_transform_toggle_operator_id', 'mesh.smart_island_transform_toggle') or 'mesh.smart_island_transform_toggle')),
                ),
            )

        normal_body = _draw_integrated_tool_section(
            col_suite,
            prefs,
            'show_normal_aligner_settings',
            _ui('Vertex Normal Aligner', '頂点法線アライナー'),
            icon='ORIENTATION_NORMAL',
            topic_key='normal_aligner',
        )
        if normal_body is not None:
            normal_body.prop(
                prefs,
                'normal_align_use_pivot',
                text=_ui('Align Object Pivot', 'オブジェクトピボットを合わせる'),
                icon='OBJECT_ORIGIN',
            )
            normal_body.prop(
                prefs,
                'normal_align_use_orientation',
                text=_ui('Create Custom Orientation', 'カスタム座標系を作成'),
                icon='ORIENTATION_NORMAL',
            )
            run_row = normal_body.row(align=True)
            active_obj = getattr(context, 'active_object', None) if context is not None else None
            run_row.enabled = bool(
                active_obj is not None
                and getattr(active_obj, 'type', None) == 'MESH'
                and getattr(active_obj, 'mode', None) == 'EDIT'
            )
            _safe_layout_operator(
                run_row,
                'mesh.smart_align_to_vertex_normal',
                text=_ui('Align to Selected Vertex Normal', '選択頂点法線に合わせる'),
                icon='CHECKMARK',
            )
            if not run_row.enabled:
                _draw_icon_label(
                    normal_body,
                    _ui(
                        'Select vertices, edges, or faces.',
                        '頂点・辺・面を選んでください。',
                    ),
                    icon='ERROR',
                )
            _draw_manual_keymap_registration_box(
                normal_body,
                title=_ui('Vertex Normal Aligner Keymap Registration', '頂点法線アライナー キーマップ登録'),
                topic_key='normal_aligner',
                entries=(
                    (
                        _ui('Align Operator ID', '法線整列登録ID'),
                        'mesh.smart_align_to_vertex_normal',
                        _ui('Preferences > Keymap > 3D View > Mesh', 'プリファレンス > キーマップ > 3Dビュー > メッシュ'),
                    ),
                ),
            )

        ssg_body = _draw_integrated_tool_section(col_suite, prefs, 'show_select_guard_settings', T('Smart Select Guard'), icon='RESTRICT_SELECT_OFF', topic_key='select_guard')
        if ssg_body is not None:
            ssg = prefs.select_guard
            scene_for_ssg = getattr(context, 'scene', None)
            row_ops = ssg_body.row(align=True)
            _safe_layout_operator(row_ops, "view3d.ssg_toggle_occluder_ignore_selected", text=_ui('Ignore Selected Occluders', '選択遮蔽物を無視'), icon='HIDE_OFF')

            live_owner = scene_for_ssg if scene_for_ssg is not None and hasattr(scene_for_ssg, 'select_guard_enabled') else ssg
            ssg_body.label(text=_ui('Basic Settings', '基本設定'), icon='RESTRICT_SELECT_OFF')
            if scene_for_ssg is not None and hasattr(scene_for_ssg, 'select_guard_enabled'):
                ssg_body.prop(scene_for_ssg, 'select_guard_enabled', text=_ui('Smart Select Guard', 'スマート選択ガード'))

            if scene_for_ssg is not None and hasattr(scene_for_ssg, 'ssg_select_through_xray_off'):
                ssg_body.prop(scene_for_ssg, 'ssg_select_through_xray_off', text=_ui('Select Through when X-Ray Off', '透過表示OFF時も背面選択'))
            else:
                ssg_body.prop(ssg, 'pref_select_through_xray_off', text=_ui('Select Through when X-Ray Off', '透過表示OFF時も背面選択'))

            # Enable-while-held key is assigned like a normal Blender shortcut:
            # right-click the operator button and choose "Assign Shortcut".  The
            # old pull-down is intentionally not shown to avoid Shift/Ctrl/Alt
            # modifier conflicts and to allow any key supported by Blender.
            hold_box = ssg_body.box()
            hold_box.label(text=_ui('Enable-While-Held Shortcut', '有効キー'), icon='KEY_HLT')
            hold_row = hold_box.row(align=True)
            _safe_layout_operator(hold_row, 'view3d.ssg_hold_enable_key', text=_ui('Assign Key', 'キー割当'), icon='KEY_HLT')
            _safe_layout_operator(hold_row, 'view3d.ssg_clear_hold_enable_key_shortcut', text=_ui('Clear', '解除'), icon='X')
            try:
                sg_mod = _loaded_module('select_guard')
                label_func = getattr(sg_mod, '_ssg_hold_enable_display_label', None) if sg_mod is not None else None
                hold_label = label_func(scene_for_ssg, context) if callable(label_func) else _ui('None - always active', '常時有効')
            except Exception:
                hold_label = _ui('None - always active', '常時有効')
            hold_info = hold_box.row(align=True)
            hold_info.enabled = False
            hold_info.label(text=_ui('Key: ', 'キー: ') + str(hold_label))

            ssg_body.separator()
            ssg_body.label(text=_ui('Selection Behavior', '選択動作'), icon='SELECT_SET')
            if scene_for_ssg is not None and hasattr(scene_for_ssg, 'ssg_enable_click_filter'):
                ssg_body.prop(scene_for_ssg, 'ssg_enable_click_filter', text=_ui('Enable Click Select Filtering', 'クリック選択フィルター'))
                if hasattr(scene_for_ssg, 'ssg_other_objects_occlude'):
                    ssg_body.prop(scene_for_ssg, 'ssg_other_objects_occlude', text=_ui('Enable Other Objects Occlusion', '他オブジェクトの遮蔽を有効'))
                if hasattr(scene_for_ssg, 'ssg_multi_edit_mutual_occlude'):
                    ssg_body.prop(scene_for_ssg, 'ssg_multi_edit_mutual_occlude', text=_ui('Enable Mutual Occlusion for Multi-Edit', '複数編集の相互遮蔽を有効'))
                ssg_body.prop(scene_for_ssg, 'ssg_show_status_feedback', text=_ui('Show Status Feedback', 'ステータス表示'))
            else:
                ssg_body.prop(ssg, 'pref_click_filter', text=_ui('Enable Click Select Filtering', 'クリック選択フィルター'))
                if hasattr(ssg, 'pref_other_objects_occlude'):
                    ssg_body.prop(ssg, 'pref_other_objects_occlude', text=_ui('Enable Other Objects Occlusion', '他オブジェクトの遮蔽を有効'))
                if hasattr(ssg, 'pref_multi_edit_mutual_occlude'):
                    ssg_body.prop(ssg, 'pref_multi_edit_mutual_occlude', text=_ui('Enable Mutual Occlusion for Multi-Edit', '複数編集の相互遮蔽を有効'))
                ssg_body.prop(ssg, 'pref_show_status_feedback', text=_ui('Show Status Feedback', 'ステータス表示'))

            if scene_for_ssg is not None and hasattr(scene_for_ssg, 'ssg_occluder_exclude_collection'):
                ssg_body.separator()
                ssg_body.prop(scene_for_ssg, 'ssg_occluder_exclude_collection', text=_ui('Exclude', '除外'))

            _draw_manual_keymap_registration_box(
                ssg_body,
                title=_ui('Smart Select Guard Keymap Registration', 'スマート選択ガード キーマップ登録'),
                topic_key='select_guard',
                locations=(
                    (_ui('Recommended Keymap Location', '推奨キーマップ登録場所'), _ui('Preferences > Keymap > 3D View', 'プリファレンス > キーマップ > 3Dビュー')),
                ),
                entries=(
                    (_ui('Hold Enable Operator ID', 'ホールド有効化登録ID'), 'view3d.ssg_hold_enable_key'),
                    (_ui('Toggle ID', '常時切り替え登録ID'), 'view3d.select_guard_toggle'),
                    (_ui('Ignore Selected ID', '選択遮蔽物無視登録ID'), 'view3d.ssg_toggle_occluder_ignore_selected'),
                ),
            )



    try:
        _autosave_on_ui_draw(prefs, context)
    except Exception:
        pass

def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_register_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
        except Exception:
            pass
    try:
        bpy.utils.register_class(cls)
    except ValueError:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)
_COMPAT_WM_FOLDOUT_PROPS = ('sos_always_on_toggles_open',)
_COMPAT_WM_FOLDOUT_PROPS_OWNED: set[str] = set()


def _compat_wm_always_on_get(_self):
    try:
        prefs = _runtime.get_addon_preferences(getattr(bpy, 'context', None), __package__, __name__, __file__)
        return bool(getattr(prefs, 'show_always_on_switches', False)) if prefs is not None else False
    except Exception:
        return False


def _compat_wm_always_on_set(_self, value):
    try:
        _queue_always_on_prop_change('', 'show_always_on_switches', bool(value))
        _queue_always_on_redraw(getattr(bpy, 'context', None))
    except Exception:
        pass


def _register_compat_wm_foldout_props() -> None:
    for prop_name in _COMPAT_WM_FOLDOUT_PROPS:
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                try:
                    delattr(bpy.types.WindowManager, prop_name)
                except Exception:
                    pass
            setattr(
                bpy.types.WindowManager,
                prop_name,
                BoolProperty(
                    name=_ui('Resident Features Open', '常時機能切り替えを開く'),
                    description=_ui(
                        'Compatibility foldout state for older Smart Transform UI layouts. It mirrors the current Resident Features foldout and saves only after the current UI event finishes.',
                        '旧Smart Transform UIレイアウト用の互換折り畳み状態です。現在の常時機能切り替えの開閉状態を反映し、保存は現在のUIイベント終了後に行います。',
                    ),
                    get=_compat_wm_always_on_get,
                    set=_compat_wm_always_on_set,
                    options={'SKIP_SAVE'},
                ),
            )
            _COMPAT_WM_FOLDOUT_PROPS_OWNED.add(prop_name)
        except Exception:
            pass


def _unregister_compat_wm_foldout_props() -> None:
    for prop_name in tuple(_COMPAT_WM_FOLDOUT_PROPS_OWNED):
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                delattr(bpy.types.WindowManager, prop_name)
        except Exception:
            pass
        _COMPAT_WM_FOLDOUT_PROPS_OWNED.discard(prop_name)


_PREFERENCES_MODULE_REGISTERED = False


classes = (
    STS_OT_show_tool_help,
    STS_OT_toggle_npanel_foldout,
    STS_OT_toggle_always_on_property,
    STS_QuickAlignPrefs,
    STS_SmartTransformPanelPrefs,
    STS_QuickMultiEditPrefs,
    STS_SmartSelectGuardPrefs,
    STS_MeshVertexToolsPrefs,
    VIEW3D_OT_csdt_reset_settings,
    CSDT_Preferences,
)


def _sanitize_qme_legacy_event_enums():
    valid_types = {item[0] for item in QME_KEY_TYPE_ITEMS}
    valid_values = {item[0] for item in QME_KEY_VALUE_ITEMS}
    # Blender 5.1 can hard-crash when AddonPreferences lookup is attempted
    # while this extension intentionally has no visible Add-on Preferences
    # block.  Use the hidden WindowManager runtime preferences instead.
    try:
        prefs = runtime_preferences_from_window_manager(getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    qme = getattr(prefs, 'quick_multi_edit', None) if prefs is not None else None
    if qme is None:
        return
    for prop_name in ('custom_add_type', 'custom_remove_type', 'custom_toggle_type', 'custom_isolate_type'):
        try:
            value = str(getattr(qme, prop_name, 'NONE') or 'NONE')
            if value not in valid_types:
                setattr(qme, prop_name, 'NONE')
        except Exception:
            pass
    for prop_name in ('custom_add_value', 'custom_remove_value', 'custom_toggle_value', 'custom_isolate_value'):
        try:
            value = str(getattr(qme, prop_name, 'PRESS') or 'PRESS')
            if value not in valid_values:
                setattr(qme, prop_name, 'PRESS')
        except Exception:
            pass


def _schedule_qme_legacy_event_enum_sanitize():
    def _run():
        try:
            _sanitize_qme_legacy_event_enums()
        except Exception:
            pass
        return None
    try:
        bpy.app.timers.register(_run, first_interval=0.2)
    except Exception:
        pass


def register():
    global _PREFERENCES_MODULE_REGISTERED
    if _PREFERENCES_MODULE_REGISTERED:
        return
    try:
        existing_cls = getattr(bpy.types, 'CSDT_Preferences', None)
        if isinstance(existing_cls, type) and hasattr(bpy.types.WindowManager, _RUNTIME_PREFS_ATTR):
            _PREFERENCES_MODULE_REGISTERED = True
            _schedule_qme_legacy_event_enum_sanitize()
            return
    except Exception:
        pass
    registered = []
    try:
        _unregister_legacy_addon_preferences_classes()
        _settings.materialize_persisted_property_updates(
            (
                STS_QuickAlignPrefs,
                STS_SmartTransformPanelPrefs,
                STS_QuickMultiEditPrefs,
                STS_SmartSelectGuardPrefs,
                STS_MeshVertexToolsPrefs,
                CSDT_Preferences,
            ),
            owner_scope='preferences',
        )
        for cls in classes:
            _safe_register_class(cls)
            registered.append(cls)
        _register_runtime_preferences_property()
        _register_compat_wm_foldout_props()
        # Do not touch the newly registered WindowManager PointerProperty
        # synchronously.  Blender 5.1 can hard-crash in extension workflows
        # when a freshly registered pointer is read during the same register
        # stack.  Sanitize after the current event instead.
        _schedule_qme_legacy_event_enum_sanitize()
    except Exception:
        _unregister_compat_wm_foldout_props()
        _unregister_runtime_preferences_property()
        for cls in reversed(registered):
            _safe_unregister_class(cls)
        _PREFERENCES_MODULE_REGISTERED = False
        raise
    _PREFERENCES_MODULE_REGISTERED = True

def unregister():
    global _PREFERENCES_MODULE_REGISTERED
    _unregister_compat_wm_foldout_props()
    _unregister_runtime_preferences_property()
    for cls in reversed(classes):
        _safe_unregister_class(cls)
    _unregister_legacy_addon_preferences_classes()
    _PREFERENCES_MODULE_REGISTERED = False
