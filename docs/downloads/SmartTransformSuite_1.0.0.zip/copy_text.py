# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from bpy.props import StringProperty

from .translation import TI


COPY_TEXT_OPERATOR_ID = 'core_suite.copy_text'


class STS_OT_copy_text(bpy.types.Operator):
    bl_idname = COPY_TEXT_OPERATOR_ID
    bl_label = TI('Copy Text', 'テキストをコピー')
    bl_description = TI(
        'Copy the displayed registration text to the clipboard so it can be pasted into Blender Preferences > Keymap.',
        '表示中の登録文字列をクリップボードへコピーし、プリファレンス > キーマップ に貼り付けられるようにします。',
    )
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    text: StringProperty(name='Text', description='Text copied to the system clipboard when this operator is executed.', options={'SKIP_SAVE'})
    report_label: StringProperty(name='Report Label', description='Optional label shown in Blender reports after the text has been copied.', options={'SKIP_SAVE'})

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, TI('Clipboard is not available.', 'クリップボードを利用できません。'))
            return {'CANCELLED'}
        try:
            wm.clipboard = str(self.text or '')
        except Exception:
            self.report({'ERROR'}, TI('Copy failed.', 'コピーに失敗しました。'))
            return {'CANCELLED'}
        label = str(self.report_label or self.text or '').strip()
        self.report({'INFO'}, TI(f'Copied: {label}', f'コピーしました: {label}'))
        return {'FINISHED'}


classes = (
    STS_OT_copy_text,
)


def _safe_unregister_class(cls) -> None:
    target = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass



def _safe_register_class(cls) -> None:
    try:
        from . import operator_safety as _op_safety
        for _name in ('normalize_operator_class_for_registration', 'normalize_operator_methods_for_registration', 'restore_operator_class_method_signatures'):
            _fn = getattr(_op_safety, _name, None)
            if callable(_fn):
                _fn(cls)
    except Exception:
        pass
    target = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
        except Exception:
            pass
    try:
        bpy.utils.register_class(cls)
    except ValueError:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)



def register() -> None:
    registered = []
    try:
        for cls in classes:
            _safe_register_class(cls)
            registered.append(cls)
    except Exception:
        for cls in reversed(registered):
            _safe_unregister_class(cls)
        raise



def unregister() -> None:
    for cls in reversed(classes):
        _safe_unregister_class(cls)
