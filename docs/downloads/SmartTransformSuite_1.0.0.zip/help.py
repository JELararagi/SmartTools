# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Lazy-loaded help popups for Smart Transform.

This module is intentionally not imported during add-on registration or normal
N-panel drawing.  The lightweight N-panel help button imports this file only
when the user clicks Help.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
import unicodedata
from typing import Iterable

import bpy
from . import ui_icons as _ui_icons

try:
    import blf
except Exception:
    blf = None


_REGISTERED = False


def _label_kwargs(icon: str = 'NONE', custom_icon: str = '') -> dict[str, object]:
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> None:
    try:
        layout.label(text=str(text or ''), **_label_kwargs(icon, custom_icon))
    except TypeError:
        layout.label(text=str(text or ''), icon=icon or 'NONE')


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else getattr(bpy.context, 'preferences', None)
        view = getattr(prefs, 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        lang = str(getattr(view, 'language', '') or '').lower()
        return lang.startswith('ja')
    except Exception:
        return False


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


@dataclass(frozen=True)
class HelpTopic:
    title_en: str
    title_ja: str
    icon: str
    overview_en: tuple[str, ...]
    overview_ja: tuple[str, ...]
    usage_en: tuple[str, ...]
    usage_ja: tuple[str, ...]
    settings: tuple[tuple[str, str, str, str], ...]


def S(en_label: str, ja_label: str, en_desc: str, ja_desc: str) -> tuple[str, str, str, str]:
    return (en_label, ja_label, en_desc, ja_desc)


TOPICS: dict[str, HelpTopic] = {
    'modern_ui': HelpTopic(
        'Modern UI / Icon System', 'モダンUI / アイコンシステム', 'PLUGIN',
        (
            'Smart Transform uses a Smart Rig-tone transparent custom icon pack for the N-panel command hub and shared operator buttons.',
            "Icon-only buttons are drawn as normal Blender buttons with the label reduced to the custom icon, so the entire button highlights on hover.",
        ),
        (
            'Smart Transform は、Smart Rigと同じトーンの透明背景独自アイコンパックをNパネルのコマンドハブと共通オペレーターボタンに使用します。',
            'アイコンのみのボタンは通常のBlenderボタンとして描画し、ラベルを独自アイコンだけにすることで、ホバー時にボタン全体がハイライトします。',
        ),
        (
            'Use the icon buttons exactly like normal Blender buttons. Hover each item to read the detailed tooltip.',
            'Settings remain in the 3D View Sidebar N-panel; Add-on Preferences only redirects you back to the panel.',
        ),
        (
            '通常のBlenderボタンと同じようにアイコンボタンを使用します。各項目にマウスを重ねると詳細ツールチップを確認できます。',
            '設定は3DビューのサイドバーNパネルに維持され、アドオンプリファレンスはNパネルへの案内だけを表示します。',
        ),
        (
            S('Custom icon pack', '独自アイコンパック', 'Transparent PNG icons shipped inside the extension package; no icon files are generated at startup.', '拡張パッケージ内に同梱した透明PNGアイコンです。起動時にアイコンファイルは生成しません。'),
            S('Icon-only hover buttons', 'アイコン専用ハイライトボタン', "Icon-only operator buttons keep Blender's normal button emboss so the full button area highlights on hover.", 'アイコンのみのオペレーターボタンもBlender標準のボタン枠を維持し、ホバー時にボタン全体がハイライトします。'),
            S('N-panel command hub', 'Nパネルコマンドハブ', 'The top N-panel block confirms the current UI system and provides this help entry.', 'Nパネル上部のブロックで現在のUI方式を確認し、このヘルプを開けます。'),
            S('Persistent restoration', '永続復元', 'N-panel settings and always-on toggles are saved to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and restored after startup, file load, and scene changes.', 'Nパネル設定と常時起動切替はBlender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、起動時、ファイル読込時、シーン切り替え時に復元されます。'),
        ),
    ),
    'always_on_toggles': HelpTopic(
        'Resident Features', '常時機能切り替え', 'TIME',
        (
            'This group centralizes all always-on runtime switches and live display states that can keep handlers, timers, draw handlers, message-bus subscriptions, or keymaps ready without pressing a tool button.',
            'Disabled entries stay fully inactive wherever possible, keeping startup and idle operation lighter.',
        ),
        (
            'このグループは、ボタンを押していない時もハンドラー、タイマー、描画ハンドラー、メッセージバス監視、キーマップを待機させる常時起動系スイッチとライブ表示状態を集約します。',
            '無効の項目は可能な限り完全に停止し、起動時と待機時の負荷を抑えます。',
        ),
        (
            'Enable only the items that must react automatically while you work.',
            'Leave rarely used live overlays, background watchers, and replacement hotkeys disabled until needed.',
            'The state is saved in Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and restored after Blender restarts, file loads, or scene changes.',
        ),
        (
            '作業中に自動反応が必要な項目だけ有効にしてください。',
            '使用頻度の低いライブ表示、背景監視、置換ホットキーは必要になるまで無効のままにしてください。',
            '状態はBlender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存されます。Blender再起動後、別ファイル読込後、シーン切り替え後も復元されます。',
        ),
        (
            S('3D Smart Gizmo Runtime', '3Dスマートギズモ常駐', 'Keeps the 3D Smart Gizmo runtime ready without starting a transform first.', '変形開始前から3Dスマートギズモのランタイムを待機させます。'),
            S('3D Smart Gizmo Overlay', '3Dスマートギズモ表示', 'Shows or hides the 3D Smart Gizmo overlay state.', '3Dスマートギズモの表示状態を切り替えます。'),
            S('3D Smart Gizmo Custom Style', '3Dスマートギズモ独自表示', 'Uses the add-on drawing style for gizmo handles.', 'ギズモハンドルにアドオン独自の描画スタイルを使用します。'),
            S('3D Tool Click Priority', '3Dツールクリック優先', 'Uses the add-on 3D click handler non-destructively. Startup and file-load repair keeps Blender native deselect, add/remove, and loop-select click routes active.', 'アドオンの3Dクリック処理を非破壊で使用します。起動時とファイル読込時の復旧処理により、Blender標準の選択解除、加算・減算、ループ選択のクリック経路を有効に保ちます。'),
            S('Quick Multi-Edit Hotkeys', 'クイック複数編集ホットキー', 'Enables Quick Multi-Edit mouse or custom shortcut bindings.', 'クイック複数編集のマウスまたはカスタムショートカットを有効化します。'),
            S('Select Guard Runtime', '選択ガード常駐', 'Keeps Smart Select Guard scene/runtime monitoring active.', 'スマート選択ガードのシーン監視とランタイム監視を維持します。'),
            S('Select Guard File Defaults', '選択ガード読込時既定', 'Applies saved Smart Select Guard defaults when a file is loaded.', 'ファイル読込時に保存済みのスマート選択ガード既定値を適用します。'),
        ),
    ),
    'core_click': HelpTopic(
        '3D Smart Transform Click', '3Dスマート変形クリック', 'MOUSE_LMB',
        ('Controls the add-on click, selection, drag-transform, and hit-detection behavior for 3D View transform tools. The click priority path is repaired at startup and file load so native 3D View deselection remains available while enabled.',),
        ('3Dビューの変形ツールで使うクリック、選択、ドラッグ変形、ヒット判定の挙動を制御します。クリック優先経路は起動時とファイル読込時に復旧されるため、有効中でも標準の3Dビュー選択解除を維持します。',),
        ('Enable the target tools you want, tune selection behavior, then adjust hit radii only if clicking vertices or edges feels too strict or too loose. Modifier-clicks are passed through to Blender selection behavior. Use the click-selection Operator IDs only when you intentionally register a manual shortcut.',),
        ('使いたい対象ツールを有効化し、選択挙動を調整します。頂点や辺のクリック判定が厳しすぎる、または緩すぎる場合だけ判定半径を調整してください。修飾キー付きクリックはBlender標準の選択挙動へ返します。',),
        (
            S('Enable for Move Tool', '移動ツールで有効', 'Allows the Smart Transform click workflow while the Move tool is active.', '移動ツールが有効な時にSmart Transformクリック処理を使います。'),
            S('Enable for Rotate Tool', '回転ツールで有効', 'Allows the workflow while the Rotate tool is active.', '回転ツールが有効な時にこの処理を使います。'),
            S('Enable for Scale Tool', 'スケールツールで有効', 'Allows the workflow while the Scale tool is active.', 'スケールツールが有効な時にこの処理を使います。'),
            S('Enable for Transform Tool', 'トランスフォームツールで有効', 'Allows the workflow while Blender combined Transform tool is active.', 'Blenderの統合トランスフォームツールが有効な時にこの処理を使います。'),
            S('Immediate Select', '即時選択', 'Selects the clicked component on mouse press for faster click-drag workflows.', 'マウス押下時点でクリック対象を選択し、クリック後すぐドラッグしやすくします。'),
            S('Keep Multi-Selection on Drag', 'ドラッグ時に複数選択を維持', 'Keeps the existing multi-selection when dragging one selected element.', '選択済み要素をドラッグする時に既存の複数選択を維持します。'),
            S('Update Active Element', 'アクティブ要素を更新', 'Makes the clicked item the active element when selection changes.', '選択変更時にクリック対象をアクティブ要素にします。'),
            S('Click Through Unselectable', '選択不可をクリック透過', 'Lets clicks pass through objects or elements that cannot be selected.', '選択不可のオブジェクトや要素をクリック対象から除外します。'),
            S('Drag to Transform', 'ドラッグで変形', 'Starts transform from a valid drag rather than requiring a separate G, R, or S command.', 'G、R、Sを別途押さず、有効なドラッグから変形を開始します。'),
            S('Smart Axis Memory', 'スマート軸メモリ', 'Remembers and reuses recent axis or plane intent where supported.', '対応する操作で直近の軸または平面の意図を記憶して再利用します。'),
            S('Background Click Deselect', '背景クリックで選択解除', 'Clears selection when clicking empty 3D View space. In Edit Mesh mode, the add-on also uses a direct bmesh fallback when operator context is unstable.', '3Dビューの空白部分をクリックした時に選択を解除します。メッシュ編集では、オペレーターコンテキストが不安定な場合も直接処理で解除を補助します。'),
            S('Background Drag Select', '背景ドラッグ選択', 'Starts area selection when dragging from empty 3D View space.', '3Dビューの空白部分からドラッグした時に範囲選択を開始します。'),
            S('Drag Threshold', 'ドラッグしきい値', 'Pixel distance required before a press becomes a drag.', '押下をドラッグとして扱うまでのピクセル距離です。'),
            S('Vertex Hit Radius', '頂点判定半径', 'Pixel radius used when detecting vertices under the cursor.', 'カーソル下の頂点を検出するピクセル半径です。'),
            S('Edge Hit Radius', '辺判定半径', 'Pixel radius used when detecting edges under the cursor.', 'カーソル下の辺を検出するピクセル半径です。'),
            S('Reset', 'リセット', 'Restores the section defaults for the corresponding setting group.', '対応する設定グループを既定値へ戻します。'),
        ),
    ),
    'smart_gizmo_3d': HelpTopic(
        '3D Smart Gizmo', '3Dスマートギズモ', 'GIZMO',
        ('Draws and hit-tests the add-on transform handles in the 3D View.',),
        ('3Dビュー上にアドオン独自の変形ハンドルを描画し、クリック判定を行います。',),
        ('Enable the handle types needed for your current tool. Increase pick range or handle scale if handles are hard to select. Register the toggle operator only if you want a shortcut for it; the add-on does not add this keymap automatically.',),
        ('現在のツールで必要なハンドル種別を有効にします。ハンドルを選びにくい場合は判定範囲や表示スケールを上げてください。表示を切り替えるショートカットが必要な場合だけオペレーターを登録します。このアドオンはこのキーマップを自動追加しません。',),
        (
            S('Enable 3D Smart Gizmo Rotate', '3Dスマートギズモ回転', 'Shows rotate handles for the Rotate tool.', '回転ツール用の回転ハンドルを表示します。'),
            S('Enable 3D Smart Gizmo Scale', '3Dスマートギズモスケール', 'Shows scale handles for the Scale tool.', 'スケールツール用のスケールハンドルを表示します。'),
            S('Enable 3D Smart Gizmo Transform', '3DスマートギズモTransform', 'Shows combined handles for the Transform tool.', 'トランスフォームツール用の統合ハンドルを表示します。'),
            S('Transform Move', 'Transformの移動', 'Shows the move component inside the combined Transform gizmo.', '統合トランスフォームギズモ内に移動成分を表示します。'),
            S('Transform Rotate', 'Transformの回転', 'Shows the rotate component inside the combined Transform gizmo.', '統合トランスフォームギズモ内に回転成分を表示します。'),
            S('Transform Scale', 'Transformのスケール', 'Shows the scale component inside the combined Transform gizmo.', '統合トランスフォームギズモ内にスケール成分を表示します。'),
            S('3D Smart Gizmo Screen Scale', '表示スケール', 'Overall screen-space size of the gizmo.', 'ギズモ全体の画面上の大きさです。'),
            S('XYZ Axis', 'XYZ軸', 'Scale of axis handles.', '軸ハンドルの大きさです。'),
            S('Plane Axis', '平面軸', 'Scale of plane handles.', '平面ハンドルの大きさです。'),
            S('Free Axis', '自由軸', 'Scale of center or free-transform handle.', '中央または自由変形ハンドルの大きさです。'),
            S('Gizmo Pick Range', 'ギズモ判定範囲', 'Pixel range used to detect gizmo handles.', 'ギズモハンドルを検出するピクセル範囲です。'),
            S('X Color', 'X色', 'Display color for X-axis handles.', 'X軸ハンドルの表示色です。'),
            S('Y Color', 'Y色', 'Display color for Y-axis handles.', 'Y軸ハンドルの表示色です。'),
            S('Z Color', 'Z色', 'Display color for Z-axis handles.', 'Z軸ハンドルの表示色です。'),
            S('Free Axis Color', '自由軸色', 'Display color for the free-transform handle.', '自由変形ハンドルの表示色です。'),
            S('Highlight Color', 'ハイライト色', 'Display color used when a handle is hovered or active.', 'ハンドルのホバー時または操作中に使う表示色です。'),
            S('Shortcut ID', 'ショートカットID', 'Operator ID used when manually assigning a shortcut.', '手動でショートカットを割り当てる時に使うオペレーターIDです。'),
        ),
    ),
    'cycle_custom_select': HelpTopic(
        'Cycle Custom Select', 'カスタム選択切り替え', 'RESTRICT_SELECT_OFF',
        (
            'Cycles the add-on custom selection mode inside Other Tools instead of forcing Move, Rotate, Scale, or Transform to leave the active toolbar state.',
            'Disabled modes are skipped, so the cycle order always uses only the enabled Long Press, Box Select, Circle Select, and Lasso Select entries.',
        ),
        (
            'その他ツール内のアドオン側カスタム選択モードを巡回し、移動、回転、スケール、Transform のアクティブなツールバー状態を強制的に解除しません。',
            '無効にしたモードは飛ばすため、長押し、ボックス選択、サークル選択、投げ縄選択のうち有効な項目だけで巡回します。',
        ),
        (
            'Press Run to execute the cycle once, or copy the registration ID and assign any shortcut in Blender Preferences.',
            'When a supported transform tool is active, the next enabled custom selection mode is saved and used for background selection behavior while the transform tool remains active.',
        ),
        (
            '実行ボタンで1回切り替えるか、登録IDをコピーしてBlenderのプリファレンスで任意のショートカットを割り当てます。',
            '対応する変形ツールがアクティブな場合は、次の有効なカスタム選択モードを保存し、変形ツールを維持したまま背景選択動作に使用します。',
        ),
        (
            S('Run Cycle Custom Select', 'カスタム選択切り替えを実行', 'Runs the cycle command immediately.', '切り替えコマンドを即時実行します。'),
            S('Current Custom Selection Mode', '現在のカスタム選択モード', 'Shows or directly sets the selection mode used while the transform tool remains active.', '変形ツールを維持したまま使用する選択モードを表示または直接指定します。'),
            S('Long Press', '長押し', 'Includes the normal Select/Tweak style in the cycle. Disable it to skip directly from Box Select to Circle Select and Lasso Select.', '通常の選択 / 微調整スタイルを巡回に含めます。無効にすると、ボックス選択からサークル選択、投げ縄選択へ直接進みます。'),
            S('Box Select', 'ボックス選択', 'Includes Box Select in the cycle and uses the add-on fixed-origin background box selection preview.', 'ボックス選択を巡回に含め、背景ドラッグ時にアドオン側の始点固定ボックス選択プレビューを使用します。'),
            S('Circle Select', 'サークル選択', 'Includes Blender Circle Select in the cycle while preserving the active transform tool setting.', 'アクティブな変形ツール設定を維持したまま、Blenderのサークル選択を巡回に含めます。'),
            S('Lasso Select', '投げ縄選択', 'Includes Blender Lasso Select in the cycle while preserving the active transform tool setting.', 'アクティブな変形ツール設定を維持したまま、Blenderの投げ縄選択を巡回に含めます。'),
            S('Custom Select Shortcut Registration ID', 'カスタム選択ショートカット登録ID', 'Operator ID used for manual keymap registration.', '手動キーマップ登録に使うオペレーターIDです。'),
        ),
    ),
    'core_panel': HelpTopic(
        'Smart Transform Panel', 'Smart Transformパネル', 'CON_TRANSLIKE',
        ('Provides numeric and delta transform controls through the standard N-panel and popup workflow. Settings are edited and saved from the N-panel; the Add-on Preferences UI does not expose editable property controls.',),
        ('通常Nパネルとポップアップで数値入力と差分変形を行うための機能です。設定の編集と保存はNパネルで行い、アドオンプリファレンスUIには編集用プロパティを表示しません。',),
        ('Set orientation and delta behavior in the N-panel, then assign the Keymap ID if you want to open the popup from a shortcut. N-panel values are saved to config/Smart_Transform_Suite/Smart_Transform_Suite.json and restored across startup, file changes, and scene changes.',
         'The panel always shows the Object Mode layout. In Edit Mode the fields act on the selected elements. In other modes some fields have no effect.',
         'The X button beside a field returns it to its neutral value: scale to 1, location and rotation to 0. For dimensions it returns to the length at scale 1 (Object Mode only). Affect Only settings such as Origins apply as they do when you type in the dimension field. An object with no length on that axis (such as an Empty) does not change.',),
        ('Nパネルで方向と差分入力の挙動を設定し、ショートカットでポップアップを開きたい場合はキーマップIDを登録してください。Nパネル値はconfig/Smart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、起動時、ファイル切り替え後、シーン切り替え後も復元されます。',
         'パネルはいつもオブジェクトモードの並びで表示します。編集モードでは選んだ要素に効きます。そのほかのモードでは効かない欄があります。',
         '欄の右の「×」は値を元に戻します。スケールは 1、位置と回転は 0 です。寸法はスケール 1 の時の長さに戻します（オブジェクトモードだけ）。「原点のみ」などの影響範囲の設定は、寸法の欄へ入力した時と同じように効きます。長さが 0 の物（エンプティなど）は変わりません。',),
        (
            S('Paste: Location / Rotation / Scale', 'ペースト：位置／回転／スケール', 'Sets what the Paste button applies; components that are off stay unchanged. The Paste button is disabled when all three are off.', '「ペースト」ボタンで貼る物を選びます。オフの物は変わりません。3 つともオフの時はボタンを押せません。'),
            S('Use Scene Transform Orientation', 'シーンの変形方向を使う', 'Follows Blender scene transform orientation instead of keeping a separate popup orientation.', 'ポップアップ専用方向ではなく、Blenderシーンの変形方向に追従します。'),
            S('Δ Display', 'Δ表示', 'Chooses whether delta fields keep the last value or return to neutral after use.', '差分欄が最後の値を保持するか、使用後に中立値へ戻るかを選びます。'),
            S('Δ Scale', 'Δ拡縮', 'Chooses multiplicative factor input or additive percentage-style input for scale deltas.', 'スケール差分を倍率入力にするか、加算パーセント風入力にするかを選びます。'),
            S('Scale Link X', 'スケールリンクX', 'Includes X in the linked scale-axis group.', 'リンク対象のスケール軸にXを含めます。'),
            S('Scale Link Y', 'スケールリンクY', 'Includes Y in the linked scale-axis group.', 'リンク対象のスケール軸にYを含めます。'),
            S('Scale Link Z', 'スケールリンクZ', 'Includes Z in the linked scale-axis group.', 'リンク対象のスケール軸にZを含めます。'),
            S('Pose Each Rotation Mode', 'ポーズ', 'Chooses channel editing or oriented-pivot rotation for individual pose-bone rotation.', 'ポーズボーン個別回転で、チャンネル編集か方向ピボット回転かを選びます。'),
            S('Keymap ID', 'キーマップID', 'Operator ID for manual shortcut registration of the Transform popup.', 'トランスフォームポップアップを手動ショートカット登録するためのオペレーターIDです。'),
        ),
    ),
    'cursor_lock': HelpTopic(
        '3D Cursor Lock', '3Dカーソルロック', 'PIVOT_CURSOR',
        ('Enables the integrated 3D Cursor Lock feature from Smart Transform. When the feature is enabled, the original icon toggle appears in the 3D View header and that header button is used to lock or unlock the 3D Cursor for the current scene.',),
        ('Smart Transform から統合された3Dカーソルロック機能を有効化します。機能が有効な間は、元ツールと同じアイコン切替が3Dビューヘッダーに表示され、そのヘッダーボタンで現在のシーンの3Dカーソルをロック / アンロックします。',),
        ('Turn the feature ON from Other Tools when you want the header icon toggle to be available. Then move the 3D Cursor to the position you want to keep and click the header icon to lock it. Turning the feature OFF hides the header toggle and clears any active lock state so the 3D Cursor moves normally again.',),
        ('ヘッダーのアイコン切替を使いたい時は、まずその他ツール内でこの機能自体をONにしてください。その後、固定したい位置へ3Dカーソルを移動し、ヘッダーアイコンを押してロックします。機能自体をOFFにするとヘッダー切替は非表示になり、現在有効なロック状態も解除されて、3Dカーソルを再び通常どおり動かせます。',),
        (
            S('3D Cursor Lock', '3Dカーソルロック', 'Enables or disables the 3D Cursor Lock feature itself. When enabled, the header icon toggle becomes available.', '3Dカーソルロック機能自体を有効または無効にします。有効な間はヘッダーのアイコン切替を使えるようになります。'),
            S('Header Icon Toggle', 'ヘッダーアイコン切替', 'Appears in the 3D View header while the feature is enabled. Click it to lock or unlock the current scene 3D Cursor.', '機能が有効な間だけ3Dビューヘッダーに表示されます。押すと現在のシーンの3Dカーソルをロック / アンロックします。'),
            S('Settings', '設定', 'Opens or closes the 3D Cursor Lock section inside Other Tools.', 'その他ツール内の3Dカーソルロック設定セクションを開閉します。'),
        ),
    ),
    'precision_length_drag': HelpTopic(
        'Precision Numeric Drag', '精密数値ドラッグ', 'DRIVER_DISTANCE',
        (
            'Adds an optional Shift-left precision drag workflow for editable Blender Rotation, Length, Mass, Time, and Temperature spinners.',
            'Each step setting is a Blender unit-aware value and follows the active scene Unit Settings. Time and temperature are converted as physical differences.',
            'Unsupported float fields, integer fields, panel backgrounds, and editor viewports immediately keep Blender standard Shift-left behavior.',
        ),
        (
            'Blender の編集可能な「回転」「長さ」「質量」「時間」「温度」スピナーに、Shift+左ドラッグの精密操作を追加します。',
            '各刻みはBlenderの単位対応値で、現在のシーンの単位設定に従って表示・入力されます。時間と温度は物理的な差分へ変換して適用します。',
            '対象外の小数欄、整数欄、パネル背景、各エディターのビュー領域では、Blender標準のShift+左操作をそのまま維持します。',
        ),
        (
            'Enable Precision Numeric Drag in Resident Features and manually register its operator in Screen > Screen Editing as Shift + Left Mouse / Press.',
            'Place the pointer over a supported numeric spinner and drag horizontally. Two horizontal pixels apply one configured step.',
            'Release the left mouse button to confirm. Press Esc or right click while dragging to restore the starting value.',
        ),
        (
            '常時機能切り替えで精密数値ドラッグを有効にし、スクリーン > スクリーン編集へShift + 左マウス / 押下としてオペレーターを手動登録します。',
            '対象の数値スピナー上で左右にドラッグします。横方向2ピクセルごとに設定刻みを1回適用します。',
            '左ボタンを離すと確定します。ドラッグ中にEscまたは右クリックを押すと開始値へ戻します。',
        ),
        (
            S('Enable Precision Numeric Drag', '精密数値ドラッグを有効化', 'Controls the manually registered Screen > Screen Editing Shift + Left Mouse / Press operator. Poll checks the exact RNA button and supported unit before invocation, and invoke validates it again. Viewports, panel backgrounds, unsupported fields, and other Shift-left gestures therefore never start this modal operator.', 'スクリーン > スクリーン編集 に手動登録した Shift + 左マウス / 押下 オペレーターを制御します。起動の前後で、対象の数値欄と単位を確かめます。3Dビュー、パネル背景、対象外の欄、そのほかのShift+左操作では本モーダルオペレーター自体が起動しません。'),
            S('Supported units', '対応単位', 'Only Rotation, Length, Mass, Time, and Temperature FLOAT properties use custom steps. Unit-less factors, percentages, scale fields, derived units, colors, and integer fields keep Blender standard dragging.', 'カスタム刻みを使うのは「回転」「長さ」「質量」「時間」「温度」の小数のプロパティだけです。単位なし係数、パーセント、スケール、派生単位、色、整数欄はBlender標準ドラッグのままです。'),
            S('Scene Unit Steps', 'シーン単位別刻み', 'The five values display and accept the unit selected in Scene Properties > Units. Time is stored as physical seconds and converted to the selected microseconds/milliseconds/seconds/minutes/hours/days display; temperature is handled as a difference so Celsius offsets never corrupt the step.', '5つの値は「シーンプロパティ > 単位」で選択中の単位を表示・入力に使用します。時間は物理秒で保持して、選択中のマイクロ秒／ミリ秒／秒／分／時間／日へ変換します。温度は差分として扱うため、摂氏オフセットで刻みが壊れません。'),
            S('Operator ID', 'オペレーターID', 'wm.smart_transform_precision_numeric_drag is the manual keymap operator ID.', '手動キーマップ登録には wm.smart_transform_precision_numeric_drag を使用します。'),
        ),
    ),
    'quick_align': HelpTopic(
        'Quick Align', 'クイック整列', 'EMPTY_ARROWS',
        ('Aligns objects quickly by selecting reference and target points or objects.',),
        ('基準点や対象オブジェクトを指定して、オブジェクトを素早く整列します。',),
        ('Start the tool, pick the required references, then use the dialog to swap, reset, or preview alignment. Dialog settings edited from the N-panel are saved and restored across startup and file changes.',),
        ('ツールを開始し、必要な基準を指定します。ダイアログで入れ替え、リセット、プレビューを行います。Nパネルで編集するダイアログ設定は保存され、起動時やファイル切り替え後も復元されます。',),
        (
            S('Start Quick Align', 'クイック整列を開始', 'Starts the interactive Quick Align workflow.', '対話式のクイック整列ワークフローを開始します。'),
            S('Open Align Dialog', '整列ダイアログを開く', 'Opens the Quick Align dialog directly.', 'クイック整列ダイアログを直接開きます。'),
            S('Use Farthest Pair', '最遠ペア基準', 'Needs at least three objects including the target, with Align To set to Object.', 'ターゲットを含む 3 つ以上の物が要ります。整列先が「オブジェクト」の時だけ使えます。'),
            S('Start Tool ID', '開始ツールID', 'Operator ID for the interactive Quick Align tool.', '対話式クイック整列ツールのオペレーターIDです。'),
            S('Dialog Popup ID', 'ダイアログID', 'Operator ID for opening the dialog.', 'ダイアログを開くためのオペレーターIDです。'),
            S('Dialog Swap ID', 'ダイアログ入替ID', 'Operator ID for swapping alignment references in the dialog.', 'ダイアログ内の整列基準を入れ替えるためのIDです。'),
            S('Dialog Reset ID', 'ダイアログリセットID', 'Operator ID for resetting the dialog state.', 'ダイアログ状態をリセットするためのIDです。'),
            S('Warp Cursor on Open', '窓を開く時にカーソルをずらす', 'When Start Quick Align opens the dialog, moves the cursor aside first so the dialog is less likely to cover that spot. It can still be covered with a small offset or near the window edge. Continuous mode does not move the cursor again.', '「クイック整列を開始」で窓を開く時に、先にカーソルを横へずらし、今の場所が窓で隠れにくくします。ずらす量が小さい時や画面の端では隠れることがあります。連続モードの続きの窓では動かしません。'),
            S('Warp Offset', 'ワープオフセット', 'How far the cursor moves aside, in pixels.', 'カーソルを横へずらす距離（ピクセル）です。'),
            S('Preview Throttle', 'プレビュー更新間隔', 'Delay between preview updates.', 'プレビュー更新の間隔です。'),
        ),
    ),
    'quick_multi_edit': HelpTopic(
        'Quick Multi-Edit', 'クイック複数編集', 'EDITMODE_HLT',
        ('Adds and removes objects from the current edit set quickly, including click, box, lasso, cycle-pick, and collection-based operations.',),
        ('クリック、ボックス、投げ縄、背面候補巡回、コレクション操作で、現在の編集対象にオブジェクトを素早く追加・削除します。',),
        ('Use default click shortcuts or define custom bindings. Manual operation buttons remain available even when background hotkeys are disabled.',),
        ('既定クリックショートカットを使うか、カスタム割り当てを設定します。バックグラウンドホットキーを無効にしても、手動操作ボタンは使えます。',),
        (
            S('Quick Multi-Edit Hotkeys', 'クイック複数編集ホットキー', 'Enables background shortcuts for Quick Multi-Edit.', 'クイック複数編集のバックグラウンドショートカットを有効にします。'),
            S('Use Custom Keymap', 'カスタムキーマップを使う', 'Uses custom Add, Remove, Toggle, and Switch bindings instead of defaults.', '既定割り当ての代わりに、加算、減算、切り替え、単独切り替えのカスタム割り当てを使います。'),
            S('Default Mouse Button', '既定マウスボタン', 'Chooses the mouse button used by default click shortcuts.', '既定クリックショートカットで使うマウスボタンを選びます。'),
            S('Add Binding', '加算割り当て', 'Shortcut event used to add the clicked object to multi-edit.', 'クリック対象を複数編集へ加算するショートカットイベントです。'),
            S('Remove Binding', '減算割り当て', 'Shortcut event used to remove the clicked object from multi-edit.', 'クリック対象を複数編集から減算するショートカットイベントです。'),
            S('Toggle Binding', '切り替え割り当て', 'Shortcut event used to toggle the clicked object membership.', 'クリック対象の複数編集参加状態を切り替えるショートカットイベントです。'),
            S('Switch Binding', '単独切り替え割り当て', 'Shortcut event used to switch editing to only the clicked object.', 'クリック対象だけを編集対象にするショートカットイベントです。'),
            S('Manual Registration IDs', '手動登録用ID', 'Operator IDs for Add, Remove, Toggle, Switch, box, lasso, restore, and collection actions.', '加算、減算、切り替え、単独切り替え、ボックス、投げ縄、復元、コレクション操作用のオペレーターIDです。'),
            S('Operations', '操作', 'Runs the corresponding Quick Multi-Edit operation from the N-panel.', 'Nパネルから対応するクイック複数編集操作を実行します。'),
            S('Active Behavior', 'アクティブ挙動', 'Controls how the active object is chosen after multi-edit changes.', '複数編集変更後のアクティブオブジェクトの決め方を制御します。'),
            S('Restrict to same object type as active', 'アクティブと同種のみ', 'Allows only objects of the same type as the active object.', 'アクティブオブジェクトと同じ種類のオブジェクトだけを許可します。'),
            S('Respect visibility and selection locks', '非表示と選択不可を尊重', 'Avoids hidden objects and objects locked from selection.', '非表示オブジェクトや選択不可オブジェクトを対象から除外します。'),
            S('Only same collection', '同じコレクションのみ', 'Limits candidates to objects sharing a collection with the clicked object.', 'クリック対象と同じコレクションを共有するオブジェクトに限定します。'),
            S('Only same name prefix', '同じ名前接頭辞のみ', 'Limits candidates to objects with a matching name prefix.', '名前接頭辞が一致するオブジェクトに限定します。'),
            S('Custom name prefix', 'カスタム接頭辞', 'Name prefix used when same-prefix filtering is enabled.', '同じ接頭辞フィルターが有効な時に使う名前接頭辞です。'),
            S('Enable cycle pick', '背面候補の巡回選択', 'Cycles through multiple objects under the cursor across repeated clicks.', '繰り返しクリックでカーソル下の複数候補を巡回します。'),
            S('Cycle timeout', '巡回タイムアウト', 'Time window for repeated clicks to count as one cycle sequence.', '繰り返しクリックを同じ巡回操作として扱う時間です。'),
            S('Cycle pixel threshold', '巡回ピクセルしきい値', 'Cursor movement tolerance during cycle-pick.', '巡回選択中に許容するカーソル移動量です。'),
            S('Max cycle hits', '巡回候補上限', 'Maximum number of candidates considered for cycle-pick.', '巡回選択で扱う候補数の上限です。'),
            S('Fast path without mode toggle', 'モード切替なし高速処理', 'Uses a faster path where edit-mode switching is not required.', '編集モード切り替えが不要な場合に高速経路を使います。'),
            S('Show status report', 'ステータス表示', 'Shows operation results in Blender status reports.', '操作結果をBlenderのステータス報告に表示します。'),
            S('Show HUD message in viewport', 'ビューポートHUD表示', 'Shows a short HUD message after operations.', '操作後に短いHUDメッセージを表示します。'),
            S('HUD duration', 'HUD表示時間', 'Duration for Quick Multi-Edit HUD messages.', 'クイック複数編集のHUDメッセージ表示時間です。'),
            S('History depth', '履歴保持数', 'Number of previous edit sets kept for restore.', '復元用に保持する過去の編集セット数です。'),
        ),
    ),
    'select_guard': HelpTopic(
        'Smart Select Guard', 'スマート選択ガード', 'RESTRICT_SELECT_OFF',
        ('Filters selection by visibility and occlusion so accidental picks behind other geometry are reduced.',),
        ('可視性と遮蔽を基準に選択をフィルターし、他の形状の奥にある対象を誤選択しにくくします。',),
        ('Use the simple Smart Select Guard controls to enable the guard, allow select-through while X-Ray is off, choose an optional non-modifier enable key, and set basic feedback/exclusion options. Scene-level N-panel values are saved and restored; collection references are restored by name when the collection exists. Right-click the key row to assign a key; with no key, the guard follows its switch in Resident Features. Register the hold operator only when you want the guard active while a key is held.',),
        ('スマート選択ガード のシンプルな設定で、有効化、透過表示OFF時の背面選択、任意の非装飾キーによる押下中有効化、基本フィードバック、除外設定を調整します。シーン側のNパネル値は保存・復元され、コレクション参照は同名コレクションがある場合に復元されます。キーの行を右クリックするとキーを割り当てられます。割り当てが無い時は「常時機能切り替え」の状態に従います。キーを押している間だけ有効にしたい場合のみ、ホールド用オペレーターを登録します。',),
        (
            S('Apply Defaults', '既定値を適用', 'Writes add-on default Smart Select Guard values to the scene/runtime state.', 'スマート選択ガードのアドオン既定値をシーンまたはランタイム状態へ書き込みます。'),
            S('Ignore Selected Occluders', '選択遮蔽物を無視', 'Temporarily ignores selected objects as occluders.', '選択中オブジェクトを遮蔽物として一時的に無視します。'),
            S('Toggle Operator ID', '切替オペレーターID', 'Operator ID for manual Smart Select Guard toggle registration.', 'スマート選択ガード切り替えを手動登録するためのオペレーターIDです。'),
            S('Select Through when X-Ray Off', '透過表示OFF時も背面選択', 'Temporarily enables X-Ray during selection click/drag and restores the original X-Ray state after confirmation.', '選択クリック/ドラッグ中だけ一時的に透過表示をONにし、確定後に元の透過状態へ戻します。'),
            S('Enable-While-Held Key', '押している間だけ有効', 'Optional non-modifier key that makes Smart Select Guard work only while the key is held.', '任意の非装飾キーを押している間だけスマート選択ガードを有効にします。'),
            S('Enable Click Select Filtering', 'クリック選択フィルター', 'Applies filtering to normal click selection.', '通常のクリック選択にもフィルターを適用します。'),
                        S('Show Status Feedback', 'ステータスフィードバックを表示', 'Shows short feedback when selection is blocked or bypassed.', '選択がブロックまたはバイパスされた時に短いフィードバックを表示します。'),
            S('Partial Visibility Threshold', '部分可視しきい値', 'Required visible ratio for partially visible elements.', '部分的に見えている要素を可視扱いするために必要な比率です。'),
            S('Cache Seconds', 'キャッシュ秒数', 'Time to reuse recent occlusion results.', '直近の遮蔽判定結果を再利用する時間です。'),
            S('Idle Signature Skip', 'アイドル署名スキップ', 'Number of idle checks skipped before refreshing internal state.', '内部状態を更新する前にスキップするアイドルチェック数です。'),
            S('Target Depth Margin', '対象深度マージン', 'Depth tolerance when comparing target and occluder depth.', '対象と遮蔽物の深度比較に使う許容値です。'),
        ),
    ),
    'smart_grs': HelpTopic(
        'Smart G-R-S Transform', 'Smart G-R-S変形', 'CON_TRANSLIKE',
        ('Replaces or supplements G, R, and S with a modal transform workflow that includes HUD, numeric input, snapping, axis constraints, and optional proportional helpers.',),
        ('G、R、Sを、HUD、数値入力、スナップ、軸拘束、任意のプロポーショナル補助付きのモーダル変形に置き換えまたは補助します。',),
        ('Assign the Move, Rotate, and Scale Operator IDs manually in Blender Preferences > Keymap when you want Smart G-R-S to replace standard G/R/S. If you do not assign them, Blender standard G/R/S remains unchanged. In object mode and mesh edit mode, Smart G-R-S shows Blender-style status-bar shortcut hints and supports left-click confirm, right-click cancel, X/Y/Z axis constraints, Shift+X/Y/Z plane constraints, B snap-base setting, Ctrl snap invert, Shift+Tab snap toggle, A snap-point add, Alt+A snap-point remove, R rotate, S resize, middle-click automatic axis constraint, Shift+middle-click automatic plane constraint, Shift precision mode, and Alt navigation. In non-mesh edit or pose contexts, Smart G-R-S delegates to Blender native transform to keep the complete standard modal behavior and status bar.',),
        ('標準のG/R/SをSmart G-R-Sへ置き換えたい場合は、Blenderのプリファレンス > キーマップで移動・回転・スケールのオペレーターIDを手動登録します。登録しない場合、Blender標準のG/R/Sはそのままです。オブジェクトモードとメッシュ編集モードでは、Blender風のステータスバーショートカット表示を行い、左クリック確定、右クリックキャンセル、X/Y/Z軸拘束、Shift+X/Y/Z平面拘束、Bスナップベース設定、Ctrlスナップ反転、Shift+Tabスナップ切り替え、Aスナップポイント追加、Alt+Aスナップポイント削除、R回転、Sリサイズ、中クリック自動軸拘束、Shift+中クリック自動平面拘束、Shift高精度モード、Altナビゲートに対応します。非メッシュ編集やポーズの文脈では、完全な標準モーダル挙動とステータスバーを維持するためBlender標準Transformへ委譲します。',),
        (
            S('Move Operator ID', '移動オペレーターID', 'Operator ID for Smart Move.', 'スマート移動用のオペレーターIDです。'),
            S('Rotate Operator ID', '回転オペレーターID', 'Operator ID for Smart Rotate.', 'スマート回転用のオペレーターIDです。'),
            S('Scale Operator ID', 'スケールオペレーターID', 'Operator ID for Smart Scale.', 'スマート拡大縮小用のオペレーターIDです。'),
            S('HUD', 'HUD', 'Shows transform values, constraints, snapping state, and numeric input feedback.', '変形値、拘束、スナップ状態、数値入力フィードバックを表示します。'),
            S('Snapping', 'スナップ', 'Enables configured snap steps during Smart G-R-S operations.', 'Smart G-R-S操作中に設定済みスナップ刻みを使います。'),
            S('Move Grid Step', '移動グリッド刻み', 'Step size used for move snapping.', '移動スナップに使う刻み幅です。'),
            S('Rotate Step', '回転刻み', 'Angle step used for rotate snapping.', '回転スナップに使う角度刻みです。'),
            S('Scale Step', 'スケール刻み', 'Scale increment used for scale snapping.', 'スケールスナップに使う増分です。'),
            S('Sensitivity', '感度', 'Normal and shifted sensitivity values for move, rotate, and scale.', '移動、回転、スケールの通常時とShift時の感度です。'),
            S('Disallow Negative Scale', '負スケール禁止', 'Prevents scale operations from crossing into negative scale values.', 'スケール操作が負の値へ入ることを防ぎます。'),
            S('Middle Mouse Auto Constraints', '中ボタン自動拘束', 'Middle mouse drag chooses an automatic axis constraint; Shift plus middle mouse chooses an automatic plane constraint.', '中ボタンドラッグは自動軸拘束を選択し、Shiftを押しながら中ボタンを使うと自動平面拘束を選択します。'),
            S('Draw Lines in Front', 'ラインを前面表示', 'Draws axis constraint lines in front of scene geometry.', '軸拘束ラインをシーン形状の前面に描画します。'),
            S('Axis Line Width', '軸ライン幅', 'Line width for inactive and active axis constraint lines.', '非アクティブおよびアクティブ軸拘束ラインの幅です。'),
            S('Axis Colors', '軸色', 'Display colors for X, Y, Z and darkened inactive variants.', 'X、Y、Zおよび暗色の非アクティブ表示色です。'),
        ),
    ),
    'proportional_editing': HelpTopic(
        'Proportional Editing', 'プロポーショナル編集', 'DRIVER_DISTANCE',
        ('Adds proportional radius adjustment and visual influence-circle support around Smart G-R-S and Edit Mesh workflows.',),
        ('Smart G-R-Sとメッシュ編集で、プロポーショナル半径調整と影響円表示を補助します。',),
        ('Run the cursor-radius tool in Edit Mesh, or use the Transform Modal Map IDs when manually registering proportional-size controls.',),
        ('メッシュ編集でカーソル半径調整ツールを実行するか、プロポーショナルサイズ操作を手動登録する時にトランスフォームモーダルマップ IDを使います。',),
        (
            S('Run', '実行', 'Starts the proportional-size cursor adjustment tool.', 'プロポーショナルサイズのカーソル調整ツールを開始します。'),
            S('Influence Circle', '影響円', 'Shows the proportional influence circle.', 'プロポーショナル影響円を表示します。'),
            S('Line Width', '線幅', 'Display width of the influence circle.', '影響円の表示線幅です。'),
            S('Circle Color', '円の色', 'Display color of the influence circle.', '影響円の表示色です。'),
            S('Keymap Area', 'キーマップ領域', 'Keymap area where the operator or modal map entry belongs.', 'オペレーターまたはモーダルマップ項目が属するキーマップ領域です。'),
            S('Operator ID', '登録ID', 'Operator ID for manual shortcut assignment.', '手動ショートカット割り当て用のオペレーターIDです。'),
            S('Cursor Lock', 'カーソルロック', 'Locks cursor behavior during proportional adjustment where supported.', '対応するプロポーショナル調整中のカーソル挙動をロックします。'),
            S('Adjust', '連続調整', 'Transform Modal Map entry for continuous radius adjustment.', '半径を連続調整するトランスフォームモーダルマップ項目です。'),
            S('Step Up', '拡大', 'Transform Modal Map entry for increasing proportional size.', 'プロポーショナルサイズを大きくするトランスフォームモーダルマップ項目です。'),
            S('Step Down', '縮小', 'Transform Modal Map entry for decreasing proportional size.', 'プロポーショナルサイズを小さくするトランスフォームモーダルマップ項目です。'),
        ),
    ),
    'hud_numeric_input': HelpTopic(
        'HUD and Numeric Input', 'HUDと数値入力', 'FONT_DATA',
        ('Controls the on-screen transform HUD and numeric input feedback used by Smart G-R-S.',),
        ('Smart G-R-Sで使う画面上の変形HUDと数値入力フィードバックを制御します。',),
        ('Enable HUD for visual feedback, choose the anchor mode, then tune offset, font size, and text color for readability.',),
        ('HUDを有効にして視覚フィードバックを表示し、固定位置、オフセット、フォントサイズ、文字色を見やすく調整します。',),
        (
            S('HUD', 'HUD', 'Enables or disables the transform HUD.', '変形HUDを有効または無効にします。'),
            S('Show Help', 'ヘルプ表示', 'Starts Smart G-R-S with help text visible in the HUD.', 'Smart G-R-S開始時にHUD内のヘルプ文を表示します。'),
            S('HUD Anchor', 'HUD固定位置', 'Chooses fixed-to-view or near-gizmo placement.', 'ビュー固定またはギズモ付近配置を選びます。'),
            S('Offset X', 'オフセットX', 'Horizontal HUD offset in pixels.', 'HUDの横方向オフセットです。'),
            S('Offset Y', 'オフセットY', 'Vertical HUD offset in pixels.', 'HUDの縦方向オフセットです。'),
            S('Font Size', 'フォントサイズ', 'Font size used by the HUD text.', 'HUDテキストのフォントサイズです。'),
            S('Text Color', '文字色', 'Display color for HUD text.', 'HUDテキストの表示色です。'),
        ),
    ),
    'overlay_anti_aliasing': HelpTopic(
        'Overlay Anti-Aliasing', 'オーバーレイアンチエイリアス', 'MOD_SMOOTH',
        ('Chooses how add-on overlay lines are smoothed.',),
        ('アドオンのオーバーレイ線をどの方式で滑らかに描画するかを選びます。',),
        ('Use Smooth for quality, Standard AA for a lighter single pass, or No AA for the fastest and sharpest raw lines.',),
        ('品質重視ならスムーズ、軽い単一パスなら標準AA、最速でシャープな線が必要ならAAなしを選びます。',),
        (
            S('Smooth', 'スムーズ', 'Draws an additional soft pass under the main overlay line.', 'メインのオーバーレイ線の下に柔らかい追加パスを描画します。'),
            S('Standard AA', '標準AA', 'Uses Blender or GPU line smoothing where available.', '利用可能なBlenderまたはGPUのライン平滑化を使います。'),
            S('No AA', 'AAなし', 'Draws lines without additional smoothing for maximum speed.', '追加の平滑化なしで線を描画し、速度を優先します。'),
        ),
    ),
    'integrated_tools': HelpTopic(
        'Other Tools', 'その他ツール', 'PLUGIN',
        ('Contains the optional and auxiliary tool groups bundled into Smart Transform. All editable suite settings are consolidated in the N-panel, and Add-on Preferences property controls are intentionally not used.',),
        ('Smart Transformに同梱されたその他ツール群をまとめた領域です。編集可能なツールセット設定はすべてNパネルに集約し、アドオンプリファレンスのプロパティ操作は使用しません。',),
        ('Open only the tool group you are editing. Heavy tool code is loaded lazily where possible, while always-on behavior, saved-state control, and preference-save mirroring remain centralized in the N-panel.',),
        ('編集したいツールグループだけ開いてください。可能な箇所では重いツールコードを遅延読み込みし、常時起動処理、保存状態、プリファレンス保存への複製はNパネルに集約しています。',),
        (
            S('Apply Affect Only to All Object Types', '影響の限定を全オブジェクトへ適用', 'Controls whether Smart Gizmo / Smart G-R-S apply Origins, Locations, and Parents to Empty and every other non-mesh object type. Disable it to limit this behavior to all-mesh selections.', 'スマートギズモ / Smart G-R-S の「原点」「位置」「親」を、エンプティなど全ての非メッシュオブジェクト種別にも反映するかを切り替えます。無効にすると、選択中の全オブジェクトがメッシュの場合だけ使用します。'),
            S('Transform', 'トランスフォーム', 'Numeric and delta transform panel settings.', '数値入力と差分変形パネルの設定です。'),
            S('3D Cursor Lock', '3Dカーソルロック', 'Locks the 3D Cursor to the saved position from the Smart Transform N-panel.', 'Smart Transform のNパネルから3Dカーソルを保存位置に固定します。'),
            S('Cycle Custom Select', 'カスタム選択切り替え', 'Cycles custom selection modes while preserving active transform tools.', 'アクティブな変形ツールを維持したままカスタム選択モードを巡回します。'),
            S('Quick Align', 'クイック整列', 'Fast object alignment tools.', '高速なオブジェクト整列ツールです。'),
            S('Quick Multi-Edit', 'クイック複数編集', 'Multi-object edit-set selection tools.', '複数オブジェクト編集対象の選択補助ツールです。'),
            S('Smart Select Guard', 'スマート選択ガード', 'Occlusion-aware selection guard tools.', '遮蔽を考慮する選択ガードツールです。'),
            S('Island Transform', 'アイランド変形', 'Transforms connected selected edit-mesh islands with dedicated G/R/S operators.', '専用G/R/Sオペレーターで、接続された選択メッシュ編集アイランドを変形します。'),
            S('Affect Only for All Object Types', '影響の限定を全オブジェクトへ適用', 'Lets Smart Gizmo and Smart G-R-S honor Origins, Locations, and Parents for Empty and every other Object Mode object type. Turn it off to limit this Smart behavior to all-mesh selections.', 'スマートギズモ と Smart G-R-S の「原点」「位置」「親」を、エンプティなど全てのオブジェクトモードの種別へ反映します。無効にすると、選択中の全オブジェクトがメッシュの場合だけこのSmart挙動を使用します。'),
            S('Vertex Normal Aligner', '頂点法線アライナー', 'Aligns the active mesh object pivot and/or the VertexNormal custom transform orientation to the average normal of selected Edit Mesh vertices.', 'アクティブなメッシュオブジェクトのピボット、カスタム座標系「VertexNormal」、またはその両方を、編集モードで選択した頂点の平均法線へ合わせます。'),
        ),
    ),
}



# Detailed group help topics.  This block intentionally lives in the lazy-loaded
# help module so normal registration and N-panel drawing do not import it.
TOPICS.update({
    'target_tools': HelpTopic(
        'Target Tools', '対象ツール', 'TOOL_SETTINGS',
        ('Chooses which active Blender transform tools are allowed to use Smart Transform click handling.',),
        ('どのBlender変形ツールでSmart Transformのクリック処理を使うかを選択します。',),
        ('Enable only the tools where Smart Transform should participate in click selection, drag start, and Smart Gizmo behavior. Disable a tool to keep that tool closer to Blender default interaction.',),
        ('本アドオンのクリック選択、ドラッグ開始、スマートギズモ挙動を使うツールだけ有効にします。無効のツールはBlender標準操作に近い状態を保ちます。',),
        (
            S('Enable for Move Tool', '移動ツールで有効', 'Allows Smart Transform click and drag handling while the active tool is Move.', 'アクティブツールが移動の時に本アドオンのクリック・ドラッグ処理を使います。'),
            S('Enable for Rotate Tool', '回転ツールで有効', 'Allows Smart Transform click and drag handling while the active tool is Rotate.', 'アクティブツールが回転の時に本アドオンのクリック・ドラッグ処理を使います。'),
            S('Enable for Scale Tool', 'スケールツールで有効', 'Allows Smart Transform click and drag handling while the active tool is Scale.', 'アクティブツールがスケールの時に本アドオンのクリック・ドラッグ処理を使います。'),
            S('Enable for Transform Tool', 'トランスフォームツールで有効', 'Allows Smart Transform click and drag handling while Blender combined Transform tool is active.', 'Blenderの統合トランスフォームツールが有効な時に本アドオンのクリック・ドラッグ処理を使います。'),
            S('Reset', 'リセット', 'Restores target-tool switches to their defaults.', '対象ツールの有効化スイッチを既定値へ戻します。'),
        ),
    ),
    'selection_behavior': HelpTopic(
        'Selection Behavior', '選択の挙動', 'RESTRICT_SELECT_OFF',
        ('Controls how Smart Transform changes selection at mouse press and drag start in the 3D View.',),
        ('3Dビューでマウス押下時やドラッグ開始時に本アドオンが選択をどう扱うかを制御します。',),
        ('Tune these settings when you want faster click-drag editing or when selection changes feel too aggressive.',),
        ('素早いクリックドラッグ編集をしたい場合や、選択変更が強すぎる場合に調整します。',),
        (
            S('Immediate Select (On Press)', '即時選択（押下時）', 'Selects the clicked component as soon as the mouse is pressed.', 'マウスを押した時点でクリック対象コンポーネントを選択します。'),
            S('Keep Multi-Selection on Drag', 'ドラッグ時に複数選択を維持', 'Keeps an existing multi-selection when dragging one already selected element.', '選択済み要素をドラッグする時に既存の複数選択を維持します。'),
            S('Update Active Element', 'アクティブ要素を更新', 'Makes the clicked object or component the active item when selection changes.', '選択が変わる時にクリック対象をアクティブ項目にします。'),
            S('Click Through Unselectable', '選択不可をクリック透過', 'Skips objects or elements Blender marks as unselectable.', 'Blender上で選択不可になっているオブジェクトや要素をクリック対象から除外します。'),
            S('Reset', 'リセット', 'Restores selection-behavior defaults.', '選択挙動の設定を既定値へ戻します。'),
        ),
    ),
    'transform_behavior': HelpTopic(
        'Transform Behavior', '変形の挙動', 'ORIENTATION_GIMBAL',
        ('Controls direct drag-to-transform and axis-memory behavior.',),
        ('直接ドラッグ変形と軸メモリの挙動を制御します。',),
        ('Enable drag-to-transform for faster direct manipulation. Enable axis memory when repeatedly moving or scaling along the same axis or plane.',),
        ('より直接操作に近い感触にしたい場合はドラッグ変形を有効にします。同じ軸や平面で繰り返し編集する場合は軸メモリを有効にします。',),
        (
            S('Drag to Transform', 'ドラッグで変形', 'Starts Move, Rotate, or Scale from a qualified drag without pressing G, R, or S first.', 'G、R、Sを先に押さず、条件を満たすドラッグから移動・回転・スケールを開始します。'),
            S('Smart Axis Memory', 'スマート軸メモリ', 'Remembers recent axis or plane intent and reuses it where supported.', '直近の軸または平面の意図を記憶し、対応する場面で再利用します。'),
            S('Reset', 'リセット', 'Restores transform-behavior defaults.', '変形挙動の設定を既定値へ戻します。'),
        ),
    ),
    'background_interaction': HelpTopic(
        'Background Interaction', '背景操作', 'SCENE_DATA',
        ('Defines what happens when the cursor starts on empty 3D View space instead of a selectable target.',),
        ('カーソルが選択対象ではなく3Dビューの空白部分から始まった場合の動作を定義します。',),
        ('Use background deselect for standard click-to-clear behavior. Use background drag select when empty-space drags should show a box-selection frame from the original press point immediately and apply the box on release.',),
        ('空白クリックで選択解除したい場合は背景クリック解除を使います。空白ドラッグでクリック位置からすぐにボックス選択枠を表示し、離した時に矩形選択を適用したい場合は背景ドラッグ選択を使います。',),
        (
            S('Background Click Deselect', '背景クリックで選択解除', 'Clears selection when clicking empty 3D View space.', '3Dビュー空白をクリックした時に選択を解除します。'),
            S('Background Drag Select', '背景ドラッグ選択', 'Shows a box-selection frame immediately from the original empty-space press and applies Box Select on release.', '空白部分の押下位置からすぐにボックス選択枠を表示し、マウスを離した時にボックス選択を適用します。'),
            S('Reset', 'リセット', 'Restores background-interaction defaults.', '背景操作設定を既定値へ戻します。'),
        ),
    ),
    'sensitivity_settings': HelpTopic(
        'Sensitivity Settings', '感度・判定範囲', 'DRIVER_DISTANCE',
        ('Controls drag threshold and screen-space hit ranges for vertex and edge picking.',),
        ('ドラッグ開始しきい値と、頂点・辺ピックに使う画面上の判定範囲を制御します。',),
        ('Increase hit radii when small elements are hard to click. Lower them when nearby elements are selected by mistake.',),
        ('小さい要素をクリックしにくい場合は判定半径を上げます。近くの要素を誤選択する場合は下げます。',),
        (
            S('Drag Threshold (px)', 'ドラッグしきい値（px）', 'Pixel distance required before a press becomes a drag.', '押下がドラッグ扱いになるまでに必要なピクセル距離です。'),
            S('Vertex Hit Radius (px)', '頂点ヒット半径（px）', 'Screen-space radius for detecting vertices under the cursor.', 'カーソル下の頂点を検出する画面上の半径です。'),
            S('Edge Hit Radius (px)', '辺ヒット半径（px）', 'Screen-space radius for detecting edges under the cursor.', 'カーソル下の辺を検出する画面上の半径です。'),
            S('Reset', 'リセット', 'Restores sensitivity defaults.', '感度と判定範囲を既定値へ戻します。'),
        ),
    ),
    'core_scale_link_axes': HelpTopic(
        'Scale Link Axes', 'スケールリンク軸', 'LINKED',
        ('Defines which scale-axis fields are edited together in the Smart Transform panel.',),
        ('Smart Transformパネルのスケール軸入力を、どの軸同士で連動させるかを指定します。',),
        ('Enable the axes that should share one value. Editing any enabled axis applies the same value to the enabled group while leaving disabled axes independent.',),
        ('同じ値で連動させたい軸を有効にします。有効な軸のどれか1つを編集すると、有効な軸グループへ同じ値が適用され、無効な軸は独立します。',),
        (S('X', 'X', 'Includes the X scale field in the linked scale group.', 'Xスケール欄を連動グループに含めます。'), S('Y', 'Y', 'Includes the Y scale field in the linked scale group.', 'Yスケール欄を連動グループに含めます。'), S('Z', 'Z', 'Includes the Z scale field in the linked scale group.', 'Zスケール欄を連動グループに含めます。')),
    ),
    'smart_gizmo_colors': HelpTopic(
        '3D Smart Gizmo Colors', '3Dスマートギズモ色', 'COLOR',
        ('Controls the display colors used by the custom 3D Smart Gizmo axes, center handle, and hover highlight.',),
        ('独自3Dスマートギズモの軸、中心ハンドル、ホバー強調に使う表示色を制御します。',),
        ('Adjust these colors when the gizmo is hard to read against the current viewport theme, material colors, or overlay style.',),
        ('現在のビューポートテーマ、マテリアル色、オーバーレイ表示でギズモが見えにくい場合に調整します。',),
        (S('X', 'X', 'Color used for the X-axis handle and guide.', 'X軸ハンドルとガイドに使う色です。'), S('Y', 'Y', 'Color used for the Y-axis handle and guide.', 'Y軸ハンドルとガイドに使う色です。'), S('Z', 'Z', 'Color used for the Z-axis handle and guide.', 'Z軸ハンドルとガイドに使う色です。'), S('Free Axis Color', '自由軸色', 'Color used for the center/free transform handle.', '中心または自由変形ハンドルに使う色です。'), S('Highlight Color', 'ハイライト色', 'Color used when the cursor is over a selectable gizmo handle.', 'カーソルが選択可能なギズモハンドル上にある時の強調色です。')),
    ),
    'normal_aligner': HelpTopic(
        'Vertex Normal Aligner', '頂点法線アライナー', 'ORIENTATION_NORMAL',
        (
            'Uses the average position and average vertex normal of selected visible Edit Mesh vertices to align the active mesh object pivot, create the VertexNormal custom transform orientation, or perform both operations.',
            'When the pivot is aligned, the mesh data is counter-transformed so the visible world-space mesh shape stays in place.',
        ),
        (
            '編集モードで選択中かつ表示中の頂点について、平均位置と平均頂点法線を使用し、アクティブなメッシュオブジェクトのピボット、カスタム座標系「VertexNormal」、またはその両方を合わせます。',
            'ピボットを合わせる場合はメッシュデータを逆変換するため、見た目のワールド空間メッシュ形状は元の位置を維持します。',
        ),
        (
            'Select a mesh object, enter Edit Mode, and select one or more vertices, edges, or faces. Enable the required operations, then run Align to Selected Vertex Normal.',
            'For a shortcut, register mesh.smart_align_to_vertex_normal manually in Preferences > Keymap > 3D View > Mesh. The add-on does not create the keymap automatically.',
        ),
        (
            'メッシュオブジェクトを選択して編集モードに入り、頂点・辺・面を1つ以上選択します。必要な処理を有効にしてから「選択頂点法線に合わせる」を実行します。',
            'ショートカットで実行する場合は、プリファレンス > キーマップ > 3Dビュー > メッシュ に mesh.smart_align_to_vertex_normal を手動登録します。アドオンからキーマップを自動作成しません。',
        ),
        (
            S('Align Object Pivot', 'オブジェクトピボットを合わせる', 'Moves the object origin to the selected-vertex average position and rotates local Z to the average normal while preserving the visible mesh shape.', 'オブジェクト原点を選択頂点の平均位置へ移動し、ローカルZ軸を平均法線へ回転します。見た目のメッシュ形状は維持します。'),
            S('Create Custom Orientation', 'カスタム座標系を作成', 'Creates or overwrites the VertexNormal custom transform orientation and makes it active. The object pivot is not changed when pivot alignment is disabled.', 'カスタムトランスフォーム座標系「VertexNormal」を作成または上書きし、アクティブにします。ピボット整列が無効な場合、オブジェクトピボットは変更しません。'),
            S('Align to Selected Vertex Normal', '選択頂点法線に合わせる', 'Runs the enabled pivot/orientation operations and returns to Edit Mode with the original object selection restored.', '有効なピボット・座標系処理を実行し、元のオブジェクト選択を復元して編集モードへ戻ります。'),
            S('Operator ID', '登録ID', 'Manual keymap registration ID: mesh.smart_align_to_vertex_normal.', '手動キーマップ登録IDは mesh.smart_align_to_vertex_normal です。'),
        ),
    ),
    'mesh_island_transform': HelpTopic(
        'Island Transform', 'アイランド変形', 'EDITMODE_HLT',
        ('Transforms connected selected edit-mesh component islands as units. The integrated implementation is based on the supplied Smart Island Transform script, but stores its ON/OFF state in Smart Transform settings instead of Scene data.',),
        ('接続された選択メッシュ編集コンポーネントのアイランドを単位として変形します。添付の Smart アイランド変形 スクリプトを基礎に統合し、ON/OFF状態はシーンデータではなくSmart Transform設定に保存します。',),
        ('Assign Move to G, Rotate to R, and Scale to S in the 3D View > Mesh keymap if you want the standard G/R/S keys to use Island Transform. Assign the toggle ID to an unused shortcut for quick switching. The operators pass through to Blender native transforms when Island Transform is OFF. Turn the feature on or off in Resident Features.',),
        ('標準のG/R/Sキーでアイランド変形を使う場合は、3Dビュー > メッシュ キーマップで移動をG、回転をR、スケールをSへ登録してください。素早く切り替えたい場合は、切り替えIDを未使用ショートカットへ登録します。アイランド変形がOFFの場合、各オペレーターはBlender標準トランスフォームへ渡します。機能のON・OFFは「常時機能切り替え」で行います。',),
        (
            S('Enable Island Transform', 'アイランド変形を有効化', 'Enables the mesh island G/R/S operators and Smart Gizmo island routing.', 'メッシュアイランド用G/R/Sオペレーターとスマートギズモのアイランド処理を有効化します。'),
            S('Move G Operator ID', '移動G登録ID', 'Operator ID recommended for the Mesh G key.', 'メッシュキーマップのGキーへ推奨するオペレーターIDです。'),
            S('Rotate R Operator ID', '回転R登録ID', 'Operator ID recommended for the Mesh R key.', 'メッシュキーマップのRキーへ推奨するオペレーターIDです。'),
            S('Scale S Operator ID', 'スケールS登録ID', 'Operator ID recommended for the Mesh S key.', 'メッシュキーマップのSキーへ推奨するオペレーターIDです。'),
            S('Toggle Operator ID', '切り替え登録ID', 'Operator ID used for manual ON/OFF keymap registration.', 'ON/OFF切り替え用の手動キーマップ登録IDです。'),
            S('Transform Pivot / Orientation / Snap', 'ピボット / 座標系 / スナップ', 'Uses the current Blender transform pivot, transform orientation, and basic snap state during the custom island modal.', 'カスタムアイランドモーダル中に現在のBlenderトランスフォームピボット、トランスフォーム座標系、基本スナップ状態を使用します。'),
        ),
    ),
    'qme_click_shortcuts': HelpTopic(
        'Quick Multi-Edit Click Shortcuts', 'クイック複数編集クリックショートカット', 'MOUSE_RMB',
        ('Configures default or custom click bindings for multi-edit object set operations.',),
        ('複数編集オブジェクトセット操作の既定またはカスタムクリック割り当てを設定します。',),
        ('Use default shortcuts for a compact setup, or custom bindings when another add-on or personal keymap already uses the same click combinations.',),
        ('簡易設定では既定ショートカットを使い、他アドオンや個人キーマップと競合する場合はカスタム割り当てを使います。',),
        (S('Mouse Button', 'マウスボタン', 'Mouse button used by default Quick Multi-Edit shortcuts.', '既定クイック複数編集ショートカットで使うマウスボタンです。'), S('Add / Remove / Toggle / Switch Bindings', '加算・減算・切替・単独切替割り当て', 'Custom binding slots for each multi-edit action.', '各複数編集アクション用のカスタム割り当て欄です。')),
    ),
    'qme_manual_ids': HelpTopic(
        'Quick Multi-Edit Manual Registration IDs', 'クイック複数編集手動登録ID', 'COPYDOWN',
        ('Lists operator IDs used when assigning Quick Multi-Edit shortcuts manually.',),
        ('クイック複数編集のショートカットを手動割り当てする時に使うオペレーターID一覧です。',),
        ('Copy the required ID, then paste it into Blender Preferences > Keymap when creating a manual shortcut. Register only the actions you need. 3D View operators are for viewport selection, and Outliner operators are for collection context actions.',),
        ('必要なIDをコピーし、Blenderのプリファレンス > キーマップで手動ショートカット作成時に貼り付けます。必要な操作だけ登録してください。3Dビュー系はビューポート選択用、アウトライナー系はコレクションのコンテキスト操作用です。',),
        (S('Add ID', '加算ID', 'Adds clicked objects.', 'クリック対象を追加するIDです。'), S('Remove ID', '減算ID', 'Removes clicked objects.', 'クリック対象を削除するIDです。'), S('Toggle ID', '切替ID', 'Toggles clicked objects.', 'クリック対象を切り替えるIDです。'), S('Switch ID', '単独切替ID', 'Switches to clicked object only.', 'クリック対象だけに切り替えるIDです。'), S('Box / Lasso IDs', 'ボックス / 投げ縄ID', 'Batch edit-set IDs for box and lasso gestures.', 'ボックスと投げ縄ジェスチャー用の一括編集IDです。'), S('Restore ID', '復元ID', 'Restores the previous multi-edit state.', '前回の複数編集状態を復元するIDです。'), S('Active Collection ID', 'アクティブコレクションID', 'Builds or edits the set from the active collection.', 'アクティブコレクションからセットを作成または編集するIDです。')),
    ),
    'qme_operations': HelpTopic(
        'Quick Multi-Edit Operations', 'クイック複数編集操作', 'TOOL_SETTINGS',
        ('Provides manual buttons for Quick Multi-Edit click, box, lasso, restore, and active-collection actions.',),
        ('クイック複数編集のクリック、ボックス、投げ縄、復元、アクティブコレクション操作を手動実行するボタンです。',),
        ('Press Add, Remove, Toggle, or Solo, then click an object in the 3D View. Press a Box or Lasso button, then drag in the 3D View to enclose objects. Esc or right-click cancels, also during a drag. While waiting, the sidebar and toolbar strips over the 3D View cannot be picked, even where they look transparent. Objects that share the same mesh cannot be edited together: objects already in the set stay, and the others are left out.',),
        ('加算・減算・切替・単独は、押した後に 3D ビューで物をクリックします。箱と縄のボタンは、押した後に 3D ビューをドラッグして物を囲みます。Esc か右クリックで取り消します。ドラッグの途中でも取り消せます。待っている間は、3D ビューに重なるサイドバーとツールバーの帯の上は、透けて見える所でも選べません。同じメッシュを共有する物は一緒に編集できないので、今の組に入っている物を残し、足す側の物を外します。',),
        (S('Add / Remove / Toggle / Solo', '加算・減算・切替・単独', 'Press the button, then click an object in the 3D View to add it, remove it, toggle it, or switch to it alone.', '押した後に 3D ビューでクリックした物を、足す・外す・入れ替える・その物だけにします。'), S('Restore Previous', '前回復元', 'Restores the previous multi-edit set where available.', '利用可能な場合に前回の複数編集セットを復元します。'), S('Box Add / Remove / Toggle', '箱で加算・減算・切替', 'Press the button, then drag a box in the 3D View. Objects with a bounding-box corner inside it are affected.', '押した後に 3D ビューをドラッグして四角で囲みます。外接箱の角が枠に入った物が対象です。'), S('Lasso Add / Remove / Toggle', '縄で加算・減算・切替', 'Press the button, then draw a lasso in the 3D View. Objects with a bounding-box corner inside it are affected.', '押した後に 3D ビューをドラッグして投げ縄で囲みます。外接箱の角が縄に入った物が対象です。'), S('Set / Add / Remove / Toggle Collection', 'コレクション設定・加算・減算・切替', 'Applies collection members to the current multi-edit set.', 'コレクション内のオブジェクトを現在の複数編集セットへ反映します。')),
    ),
    'quick_align_ids': HelpTopic(
        'Quick Align Operator IDs', 'クイック整列オペレーターID', 'KEY_HLT',
        ('Lists operator IDs used by Quick Align commands and popup actions.',),
        ('クイック整列のコマンドとポップアップ操作で使うオペレーターID一覧です。',),
        ('Copy these IDs for custom shortcuts, scripts, pie menus, or external launcher tools.',),
        ('独自ショートカット、スクリプト、パイメニュー、外部ランチャーから呼び出す時にコピーします。',),
        (S('Start Tool ID', '開始ツールID', 'Starts the interactive Quick Align picking workflow.', '対話式クイック整列ピック操作を開始するIDです。'), S('Dialog Popup ID', 'ダイアログID', 'Opens the Quick Align dialog directly.', 'クイック整列ダイアログを直接開くIDです。'), S('Dialog Swap ID', 'ダイアログ入替ID', 'Swaps reference and target sides inside the dialog workflow.', 'ダイアログ操作内で参照側と対象側を入れ替えるIDです。'), S('Dialog Reset ID', 'ダイアログリセットID', 'Clears dialog selection state and returns it to its initial state.', 'ダイアログ内の選択状態を消去し、初期状態へ戻すIDです。')),
    ),
    'smart_select_guard_settings': HelpTopic(
        'Smart Select Guard Settings', 'スマート選択ガード設定', 'RESTRICT_SELECT_OFF',
        ('Configures the occlusion-aware selection filter used by Smart Select Guard.',),
        ('スマート選択ガードが使う遮蔽判定付き選択フィルターを設定します。',),
        ('Use the simple settings to keep normal operation clear: enable the guard, choose select-through behavior, optionally require a specified key, and set basic feedback/exclusion options.',),
        ('通常操作をわかりやすく保つため、有効化、背面選択、指定キーによる押下中有効化、基本フィードバック、除外設定だけを調整します。',),
        (S('Apply Defaults', '既定値を適用', 'Copies saved default guard settings to the current scene.', '保存済みの既定ガード設定を現在のシーンへ反映します。'), S('Ignore Selected Occluders', '選択遮蔽物を無視', 'Temporarily treats selected occluding objects as non-blocking where supported.', '対応箇所で、選択済み遮蔽物を一時的に遮蔽しないものとして扱います。'), S('Toggle Operator ID', '切替オペレーターID', 'Operator ID for assigning a manual toggle shortcut.', '手動の切替ショートカットを割り当てるためのオペレーターIDです。'), S('Select Through when X-Ray Off', '透過表示OFF時も背面選択', 'Temporarily enables X-Ray during selection click/drag and restores the original X-Ray state after confirmation.', '選択クリック/ドラッグ中だけ一時的に透過表示をONにし、確定後に元の透過状態へ戻します。'), S('Enable-While-Held Key', '押している間だけ有効', 'Optional non-modifier key that makes Smart Select Guard work only while the key is held.', '任意の非装飾キーを押している間だけスマート選択ガードを有効にします。'), S('Enable Click Select Filtering', 'クリック選択フィルター', 'Filters click selection so occluded targets are less likely to be selected.', 'クリック選択時に遮蔽対象が選ばれにくいようにフィルターします。'), S('Show Status Feedback', 'ステータスフィードバックを表示', 'Shows feedback when guard behavior affects selection.', 'ガード挙動が選択に影響した時にフィードバックを表示します。'), S('Partial Visibility Threshold', '部分可視しきい値', 'Minimum visible ratio for accepting a partially occluded target.', '部分遮蔽された対象を許可する最小可視比率です。'), S('Cache Seconds', 'キャッシュ秒数', 'Duration for reusing guard calculations.', 'ガード計算を再利用する秒数です。'), S('Idle Signature Skip', 'アイドル署名スキップ', 'Skips repeated checks when scene and view signature are unchanged.', 'シーンとビューの署名が変わらない時に重複チェックを省略します。'), S('Target Depth Margin', '対象深度マージン', 'Depth tolerance for comparing target and occluder positions.', '対象と遮蔽物の深度比較に使う許容幅です。')),
    ),
    'grs_snapping_proportional': HelpTopic(
        'Smart G-R-S Snapping / Proportional', 'Smart G-R-Sスナップ / プロポーショナル', 'SNAP_ON',
        ('Controls snap increments and object-mode proportional distance behavior for Smart G-R-S.',),
        ('Smart G-R-Sのスナップ刻みと、オブジェクトモードのプロポーショナル距離挙動を制御します。',),
        ('Set snap increments to match scene scale, then choose the proportional basis and falloff profile for your editing style.',),
        ('シーンスケールに合うスナップ刻みを設定し、編集スタイルに合うプロポーショナル距離基準と減衰プロファイルを選びます。',),
        (S('Move Grid Step', '移動グリッド刻み', 'Grid distance used for move snapping.', '移動スナップで使うグリッド距離です。'), S('Rotate Step', '回転刻み', 'Angle step in degrees used for rotate snapping.', '回転スナップで使う角度刻みです。'), S('Scale Step', 'スケール刻み', 'Scale increment used for scale snapping.', 'スケールスナップで使う増分です。'), S('Object Proportional Basis', 'オブジェクトプロポ距離基準', 'Chooses origin, bounding-box center, or closest bounding-box point for object-mode proportional distance.', 'オブジェクトモードのプロポ距離に原点、バウンディングボックス中心、最近点のどれを使うかを選びます。'), S('Proportional Falloff Profile', 'プロポ減衰プロファイル', 'Adds Blender, Maya, or 3ds Max style falloff shaping.', 'Blender、Maya、3ds Max風の減衰補正を追加します。')),
    ),
    'grs_sensitivity': HelpTopic(
        'Smart G-R-S Drag Sensitivity', 'Smart G-R-Sドラッグ感度', 'DRIVER_DISTANCE',
        ('Controls mouse sensitivity multipliers for Smart G-R-S move, rotate, and scale.',),
        ('Smart G-R-Sの移動、回転、スケールのマウス感度倍率を制御します。',),
        ('Use normal values for standard dragging and Shift values for precision mode. Larger values are faster; smaller values are slower.',),
        ('通常値は標準ドラッグ、Shift値は精密操作用です。大きい値ほど速く、小さい値ほど遅くなります。',),
        (S('Move (G) Sensitivity - Normal', '移動（G）感度 - 通常', 'Mouse sensitivity multiplier for normal Smart Move.', '通常時のスマート移動マウス感度倍率です。'), S('Move (G) Sensitivity - Shift', '移動（G）感度 - Shift', 'Mouse sensitivity multiplier while holding Shift during Smart Move.', 'スマート移動中にShiftを押している時の感度倍率です。'), S('Rotate (R) Sensitivity - Normal', '回転（R）感度 - 通常', 'Mouse sensitivity multiplier for normal Smart Rotate.', '通常時のスマート回転マウス感度倍率です。'), S('Rotate (R) Sensitivity - Shift', '回転（R）感度 - Shift', 'Mouse sensitivity multiplier while holding Shift during Smart Rotate.', 'スマート回転中にShiftを押している時の感度倍率です。'), S('Scale (S) Sensitivity - Normal', 'スケール（S）感度 - 通常', 'Mouse sensitivity multiplier for normal Smart Scale.', '通常時のスマート拡大縮小マウス感度倍率です。'), S('Scale (S) Sensitivity - Shift', 'スケール（S）感度 - Shift', 'Mouse sensitivity multiplier while holding Shift during Smart Scale.', 'スマート拡大縮小中にShiftを押している時の感度倍率です。'), S('Reset', 'リセット', 'Restores Smart G-R-S sensitivity defaults.', 'Smart G-R-Sの感度設定を既定値へ戻します。')),
    ),
    'grs_scale_behavior': HelpTopic(
        'Smart G-R-S Scale Behavior', 'Smart G-R-Sスケール挙動', 'TRANSFORM_SCALE',
        ('Controls whether Smart Scale is allowed to cross into negative scale values.',),
        ('スマート拡大縮小が負のスケール値へ入ることを許可するかを制御します。',),
        ('Keep this enabled for DCC-style positive-only scaling. Disable it only when intentionally needing mirror-like negative scale behavior.',),
        ('DCC風の正スケールのみで扱いたい場合は有効にします。ミラーに近い負スケール挙動が必要な場合だけ無効にします。',),
        (S('Disallow Negative Scale', '負スケール禁止', 'Prevents scale from crossing zero into negative values.', 'スケールが0を越えて負の値へ入ることを防ぎます。'),),
    ),
    'grs_axis_constraint_line': HelpTopic(
        'Smart G-R-S Axis Constraint Line', 'Smart G-R-S軸拘束ライン', 'AXIS_SIDE',
        ('Controls plane-constraint selection and visual guide lines during Smart G-R-S axis constraints.',),
        ('Smart G-R-Sの軸拘束中に使う平面拘束選択と視覚ガイドラインを制御します。',),
        ('Enable middle-mouse plane constraints to pick XY, XZ, or YZ by dragging between axes. Tune widths and colors for your viewport theme.',),
        ('中ボタンドラッグでXY、XZ、YZを選びたい場合は平面拘束を有効にします。ビューポートテーマに合わせて線幅と色を調整します。',),
        (S('Middle Mouse Drag: Allow Plane Constraints', '中ボタンドラッグ：平面拘束を許可', 'Allows middle mouse drag between axes to choose plane constraints.', '中ボタンドラッグで軸間を選び、平面拘束を指定できるようにします。'), S('Draw Lines in Front (X-Ray)', '線を前面表示（透過）', 'Draws constraint guide lines in front of objects.', '拘束ガイドラインをオブジェクトより前面に描画します。'), S('Thickness', '太さ', 'Line width for inactive guide lines.', '非アクティブなガイドラインの太さです。'), S('Active Thickness', 'アクティブ太さ', 'Line width for the active guide line.', 'アクティブなガイドラインの太さです。'), S('X / Y / Z Colors', 'X / Y / Z色', 'Display colors for each axis guide line.', '各軸ガイドラインの表示色です。'), S('Dark Colors', '暗色', 'Display colors for inactive or secondary guide lines.', '非アクティブまたは補助軸ガイドラインの表示色です。'), S('Reset', 'リセット', 'Restores axis-line defaults.', '軸ライン設定を既定値へ戻します。')),
    ),
})

_HELP_POPUP_WIDTH_PX = 920
_MIN_HELP_TEXT_WIDTH_PX = 160


def _ui_scale(context) -> float:
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else getattr(bpy.context, 'preferences', None)
        system = getattr(prefs, 'system', None)
        view = getattr(prefs, 'view', None)
        scale = getattr(system, 'ui_scale', None)
        if scale is None:
            scale = getattr(view, 'ui_scale', 1.0)
        return max(0.5, min(4.0, float(scale or 1.0)))
    except Exception:
        return 1.0


def _font_size_px(context) -> int:
    # Blender UI labels are drawn around 11-12 px at scale 1.0. Matching that
    # size lets the help popup wrap at the popup edge instead of at a fixed
    # character count.
    return max(9, int(round(12.0 * _ui_scale(context))))


def _set_blf_ui_size(context) -> None:
    if blf is None:
        return
    size = _font_size_px(context)
    try:
        blf.size(0, size)
    except TypeError:
        try:
            blf.size(0, size, 72)
        except Exception:
            pass
    except Exception:
        pass


def _char_units(ch: str) -> int:
    try:
        if ch == '\t':
            return 4
        return 2 if unicodedata.east_asian_width(ch) in {'F', 'W'} else 1
    except Exception:
        return 1


def _text_units(text: str) -> int:
    return sum(_char_units(ch) for ch in str(text or ''))


def _measure_text_px(context, text: str) -> float:
    text = str(text or '')
    if not text:
        return 0.0
    if blf is not None:
        try:
            _set_blf_ui_size(context)
            width, _height = blf.dimensions(0, text)
            return float(width)
        except Exception:
            pass
    # Fallback used only if Blender's font measurement API is unavailable.
    # It still scales from popup pixels instead of fixed help-line lengths.
    unit_px = 6.0 * _ui_scale(context)
    return float(_text_units(text) * unit_px)


def _popup_width_px(context) -> int:
    """Return the active help popup width in pixels when Blender exposes it.

    ``invoke_props_dialog(width=...)`` receives a pixel width, but during some
    fallback popup paths Blender may report the source editor region instead of
    the popup region. In that case use this add-on's requested popup width so
    wrapping still follows the help popup instead of the 3D View/N-panel size.
    """
    try:
        region = getattr(context, 'region', None)
        width = int(getattr(region, 'width', 0) or 0)
    except Exception:
        width = 0
    requested = _HELP_POPUP_WIDTH_PX
    if int(requested * 0.78) <= width <= requested + 120:
        return width
    return requested


def _content_width_px(context, *, nested: bool = False, label: bool = False,
                      icon: bool = False, popup_width: int | None = None) -> int:
    """Estimate the text area inside the current help popup.

    The previous help renderer used fixed character caps, which forced line
    breaks even when the popup was wider. This function starts from the popup
    pixel width and subtracts only UI chrome: dialog margins, box padding,
    nested setting boxes, and optional label icons.
    """
    scale = _ui_scale(context)
    inset = 78.0 * scale
    if nested:
        inset += 54.0 * scale
    if label:
        inset += 8.0 * scale
    if icon:
        inset += 28.0 * scale
    width = _popup_width_px(context) if popup_width is None else popup_width
    return max(_MIN_HELP_TEXT_WIDTH_PX, int(width - inset))


def _tokenize_for_pixel_wrap(text: str) -> list[str]:
    """Return breakable tokens while preserving normal word spacing.

    English and other space-separated languages wrap at word boundaries first.
    Japanese strings often have no spaces, so a single long token is split only
    after it actually exceeds the available popup width.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip())
    if not text:
        return []
    return re.findall(r'\S+\s*', text) or [text]


def _wrap_unbroken_token(context, token: str, max_px: int) -> list[str]:
    token = str(token or '')
    if not token:
        return []
    if _measure_text_px(context, token.rstrip()) <= max_px:
        return [token.rstrip()]
    lines: list[str] = []
    cur = ''
    for ch in token:
        if ch.isspace() and not cur:
            continue
        candidate = cur + ch
        if cur and _measure_text_px(context, candidate.rstrip()) > max_px:
            line = cur.rstrip()
            if line:
                lines.append(line)
            cur = ch.lstrip()
        else:
            cur = candidate
    if cur.strip():
        lines.append(cur.rstrip())
    return lines or [token.rstrip()]


def _wrap_pixel_line(context, text: str, max_px: int) -> list[str]:
    raw_line = re.sub(r'\s+', ' ', str(text or '').strip())
    if not raw_line:
        return []
    if _measure_text_px(context, raw_line) <= max_px:
        return [raw_line]

    lines: list[str] = []
    cur = ''
    for token in _tokenize_for_pixel_wrap(raw_line):
        token = token or ''
        if not cur:
            token = token.lstrip()
            if _measure_text_px(context, token.rstrip()) <= max_px:
                cur = token
                continue
            split = _wrap_unbroken_token(context, token.rstrip(), max_px)
            if split:
                lines.extend(split[:-1])
                cur = split[-1]
                if token.endswith(' '):
                    cur += ' '
            else:
                cur = ''
            continue

        candidate = cur + token
        if _measure_text_px(context, candidate.rstrip()) <= max_px:
            cur = candidate
            continue

        line = cur.rstrip()
        if line:
            lines.append(line)
        token = token.lstrip()
        if _measure_text_px(context, token.rstrip()) <= max_px:
            cur = token
            continue

        split = _wrap_unbroken_token(context, token.rstrip(), max_px)
        if split:
            lines.extend(split[:-1])
            cur = split[-1]
            if token.endswith(' '):
                cur += ' '
        else:
            cur = ''

    if cur.strip():
        lines.append(cur.rstrip())
    return lines or [raw_line]


def _wrap_text(text: str, *, context=None, max_pixels: int | None = None) -> list[str]:
    text = str(text or '').strip()
    if not text:
        return []
    max_px = max(_MIN_HELP_TEXT_WIDTH_PX, int(max_pixels or _content_width_px(context)))
    lines: list[str] = []
    for raw_line in text.splitlines() or [text]:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        lines.extend(_wrap_pixel_line(context, raw_line, max_px))
    return lines or [text]

def _draw_wrapped(
    layout,
    context,
    text: str,
    *,
    icon: str = 'BLANK1',
    nested: bool = False,
    label: bool = False,
    popup_width: int | None = None,
) -> None:
    width_px = _content_width_px(
        context, nested=nested, label=label, icon=(icon != 'BLANK1'), popup_width=popup_width,
    )
    for i, line in enumerate(_wrap_text(text, context=context, max_pixels=width_px)):
        _label(layout, line, icon=icon if i == 0 else 'BLANK1')


def _draw_section(layout, context, heading_en: str, heading_ja: str,
                  paragraphs: Iterable[str], icon: str, *, popup_width: int | None) -> None:
    box = layout.box()
    _draw_wrapped(box, context, _t(context, heading_en, heading_ja), icon=icon, label=True, popup_width=popup_width)
    col = box.column(align=True)
    for paragraph in paragraphs:
        _draw_wrapped(col, context, paragraph, popup_width=popup_width)


def _draw_settings(layout, context, settings: Iterable[tuple[str, str, str, str]],
                   *, popup_width: int | None) -> None:
    box = layout.box()
    _draw_wrapped(box, context, _t(context, '3. Settings', '3. 設定項目'), icon='PREFERENCES', label=True, popup_width=popup_width)
    col = box.column(align=True)
    ja = _is_ja(context)
    for en_label, ja_label, en_desc, ja_desc in settings:
        item = col.box()
        _draw_wrapped(item, context, ja_label if ja else en_label, icon='DOT', nested=True, label=True, popup_width=popup_width)
        _draw_wrapped(item, context, ja_desc if ja else en_desc, nested=True, popup_width=popup_width)


TOPIC_ALIASES: dict[str, str] = {
    '': 'integrated_tools',
    'overview': 'integrated_tools',
    'VIEW3D_PT_core_suite': 'core_panel',
    'view3d_pt_core_suite': 'core_panel',
    'SMART_TRANSFORM_PT_always_on': 'always_on_toggles',
    'smart_transform_pt_always_on': 'always_on_toggles',
    'VIEW3D_PT_select_guard_popover': 'smart_select_guard_settings',
    'view3d_pt_select_guard_popover': 'smart_select_guard_settings',
    'VIEW3D_OT_sts_toggle_cursor_lock': 'cursor_lock',
    'view3d_ot_sts_toggle_cursor_lock': 'cursor_lock',
    'selection_operator_ids': 'core_click',
    'WM_OT_smart_transform_precision_numeric_drag': 'precision_length_drag',
    'wm_ot_smart_transform_precision_numeric_drag': 'precision_length_drag',
    'wm.smart_transform_precision_numeric_drag': 'precision_length_drag',
    'QuickAlignSettings': 'quick_align',
    'quickalignsettings': 'quick_align',
    'QuickMultiEditPreferences': 'quick_multi_edit',
    'quickmultieditpreferences': 'quick_multi_edit',
    'SSG_AddonPreferences': 'smart_select_guard_settings',
    'ssg_addonpreferences': 'smart_select_guard_settings',
}


def resolve_topic_key(topic_key: str | None) -> str:
    key = str(topic_key or '').strip()
    resolved = TOPIC_ALIASES.get(key) or TOPIC_ALIASES.get(key.lower()) or key
    return resolved if resolved in TOPICS else 'integrated_tools'


def _draw_topic(layout, context, topic_key: str, *, popup_width: int | None = None) -> None:
    topic_key = resolve_topic_key(topic_key)
    topic = TOPICS[topic_key]
    _draw_section(
        layout,
        context,
        '1. Feature Overview',
        '1. 機能概要',
        topic.overview_ja if _is_ja(context) else topic.overview_en,
        'INFO',
        popup_width=popup_width,
    )
    _draw_section(
        layout,
        context,
        '2. Usage',
        '2. 使用方法',
        topic.usage_ja if _is_ja(context) else topic.usage_en,
        'PLAY',
        popup_width=popup_width,
    )
    _draw_settings(layout, context, topic.settings, popup_width=popup_width)


class STS_OT_help_popup_dialog(bpy.types.Operator):
    bl_idname = 'core_suite.help_popup_dialog'
    bl_label = 'Smart Transform Help'
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = 'Display lazy-loaded Smart Transform help.'

    topic_key: bpy.props.StringProperty(
        name='Help Topic',
        description='Internal help topic key used to choose the popup content for the clicked Smart Transform N-panel help button.',
        default='',
        options={'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        del event
        self._confirming_help_dialog = True
        try:
            result = context.window_manager.invoke_props_dialog(self, width=_HELP_POPUP_WIDTH_PX, title=_t(context, 'Smart Transform Help', 'Smart Transform ヘルプ'))
        except Exception:
            self._confirming_help_dialog = False
            return self.execute(context)
        self._confirming_help_dialog = result == {'RUNNING_MODAL'}
        return result

    def draw(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        _draw_topic(layout, context, str(getattr(self, 'topic_key', '') or ''))

    def execute(self, context):
        if getattr(self, '_confirming_help_dialog', False):
            return {'FINISHED'}

        # Explicit EXEC and failed dialog invocation still display the help.
        topic_key = resolve_topic_key(str(getattr(self, 'topic_key', '') or ''))
        topic = TOPICS[topic_key]

        if bool(getattr(bpy.app, 'background', False)) or getattr(context, 'window', None) is None or getattr(context, 'window_manager', None) is None:
            try:
                self.report({'INFO'}, _t(context, topic.title_en, topic.title_ja))
            except Exception:
                pass
            return {'FINISHED'}

        def _popup_draw(self_popup, popup_context):
            _draw_topic(self_popup.layout, popup_context, topic_key)

        try:
            context.window_manager.popup_menu(
                _popup_draw,
                title=_t(context, topic.title_en, topic.title_ja),
                icon=topic.icon,
            )
        except Exception:
            pass
        return {'FINISHED'}


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    try:
        existing = getattr(bpy.types, 'STS_OT_help_popup_dialog', None)
        if isinstance(existing, type) and existing is not STS_OT_help_popup_dialog:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    try:
        bpy.utils.register_class(STS_OT_help_popup_dialog)
        _REGISTERED = True
    except RuntimeError:
        _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    try:
        bpy.utils.unregister_class(STS_OT_help_popup_dialog)
    except Exception:
        pass
    _REGISTERED = False


def show_help_popup(context, topic_key: str) -> None:
    key = resolve_topic_key(topic_key)
    topic = TOPICS[key]
    try:
        # Re-register on demand so the dialog title follows the current Blender language.
        if _REGISTERED:
            unregister()
        STS_OT_help_popup_dialog.bl_label = _t(context, topic.title_en, topic.title_ja)
        STS_OT_help_popup_dialog.bl_description = _t(
            context,
            'Display detailed help for this Smart Transform tool.',
            'このSmart トランスフォームツールの詳細ヘルプを表示します。',
        )
    except Exception:
        pass
    register()
    try:
        bpy.ops.core_suite.help_popup_dialog('INVOKE_DEFAULT', topic_key=key)
    except Exception:
        def _popup_draw(self_popup, popup_context):
            _draw_topic(self_popup.layout, popup_context, key)
        context.window_manager.popup_menu(
            _popup_draw,
            title=_t(context, topic.title_en, topic.title_ja),
            icon=topic.icon,
        )
