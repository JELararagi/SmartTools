# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Custom UI icon registry for Smart Transform.

The shipped PNG icons are transparent, borderless, and drawn to the full image
bounds so Blender's normal UI icon slot shows the glyph as large as possible.
No files are generated at runtime; all assets live inside the installed
extension package.
"""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

_PREVIEWS = None
_ICON_COLLECTION = None
_REGISTERED = False

_ICON_DIR = Path(__file__).resolve().parent / 'icon' / 'resources'
_ICON_RENAME_ALIASES: dict[str, str] = {'qme_collection_remove': 'collection_remove'}


def _icon_stem(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip()
    if not text:
        return ''
    return Path(text).stem


def _load_icon_rename_aliases() -> dict[str, str]:
    return dict(_ICON_RENAME_ALIASES)


def resolved_icon_name(name: str | None) -> str:
    key = _icon_stem(name)
    if not key:
        return ''
    if (_ICON_DIR / f'{key}.png').exists():
        return key
    mapped = _load_icon_rename_aliases().get(key, '')
    if mapped and (_ICON_DIR / f'{mapped}.png').exists():
        return mapped
    return key


# Logical icon names used by this add-on.  Standard Blender icons are used
# for every function where a matching built-in glyph exists.  Custom PNGs are
# reserved for compound selection operations that Blender does not provide as a
# single standard icon.
OPERATOR_ICONS: dict[str, str] = {
    'core.copy': 'copy',
    'core.paste': 'paste',
    'core.apply_rs': 'apply',
    'core.apply_all': 'apply_all',
    'core.snap': 'snap',
    'core.snap_to_cursor_button': 'to_cursor',
    'core.cursor_to_selection_button': 'cursor_to_selection',
    'core.snap_to_active_button': 'to_active',
    'core.snap_to_floor_button': 'to_floor',
    'core.reset_value': 'reset',
    'core_suite.show_tool_help': 'help',
    'core_suite.copy_text': 'copy_id',
    'core_suite.toggle_always_on_property': 'enabled',
    'core_suite.toggle_runtime_feature': 'enabled',
    'view3d.smart_grs_move': 'move',
    'view3d.smart_grs_rotate': 'rotate',
    'view3d.smart_grs_scale': 'scale',
    'transform.smart_grs_move': 'move',
    'transform.smart_grs_rotate': 'rotate',
    'transform.smart_grs_scale': 'scale',
    'transform.smart_grs_transform': 'smart_transform',
    'view3d.csdt_reset_settings': 'reset',
    'view3d.proportional_size_cursor': 'cursor',
    'view3d.cycle_custom_select': 'cycle',
    'mesh.smart_island_move': 'move',
    'mesh.smart_island_rotate': 'rotate',
    'mesh.smart_island_scale': 'scale',
    'mesh.smart_island_transform_toggle': 'mesh_island',
    'mesh.sts_island_transform_toggle': 'mesh_island',
    'object.quick_align_tool': 'quick_align',
    'object.quick_align_popup': 'popup',
    'object.quick_align_swap_refs': 'swap',
    'object.quick_align_reset_dialog': 'reset',
    'view3d.quick_multi_edit_add': 'add',
    'view3d.quick_multi_edit_remove': 'remove',
    'view3d.quick_multi_edit_toggle': 'toggle',
    'view3d.quick_multi_edit_isolate': 'switch',
    'view3d.quick_multi_edit_restore_previous': 'restore',
    'view3d.quick_multi_edit_box_add': 'box_add',
    'view3d.quick_multi_edit_box_remove': 'box_remove',
    'view3d.quick_multi_edit_box_toggle': 'box_toggle',
    'view3d.quick_multi_edit_lasso_add': 'lasso_add',
    'view3d.quick_multi_edit_lasso_remove': 'lasso_remove',
    'view3d.quick_multi_edit_lasso_toggle': 'lasso_toggle',
    'view3d.quick_multi_edit_from_active_collection': 'collection_set',
    'view3d.quick_multi_edit_collection_set': 'collection_set',
    'view3d.quick_multi_edit_collection_add': 'collection_add',
    'view3d.quick_multi_edit_collection_remove': 'collection_remove',
    'view3d.quick_multi_edit_collection_toggle': 'collection_toggle',
    'outliner.quick_multi_edit_from_collection': 'collection_set',
    'outliner.quick_multi_edit_collection_set': 'collection_set',
    'outliner.quick_multi_edit_collection_add': 'collection_add',
    'outliner.quick_multi_edit_collection_remove': 'collection_remove',
    'view3d.ssg_apply_prefs_to_scene': 'apply',
    'view3d.ssg_toggle_occluder_ignore_selected': 'shield_bypass',
    'view3d.select_guard_toggle': 'select_guard',
}

BUILTIN_ICON_BY_CUSTOM_NAME: dict[str, str] = {
    'help': 'QUESTION',
    'settings': 'PREFERENCES',
    'profile': 'PRESET',
    'suite': 'PLUGIN',
    'smart_transform': 'CON_TRANSLIKE',
    'quick_align': 'EMPTY_ARROWS',
    'quick_multi_edit': 'EDITMODE_HLT',
    'select_guard': 'RESTRICT_SELECT_OFF',
    'uv': 'GROUP_UVS',
    'mesh_island': 'MESH_DATA',
    'gizmo': 'GIZMO',
    'click': 'MOUSE_RMB',
    'keymap': 'KEY_HLT',
    'always_on': 'TIME',
    'anti_alias': 'MOD_SMOOTH',
    'color': 'COLOR',
    'cursor': 'CURSOR',
    'proportional': 'DRIVER_DISTANCE',
    'info': 'INFO',
    'copy': 'COPYDOWN',
    'copy_id': 'COPYDOWN',
    'paste': 'PASTEDOWN',
    'apply': 'CHECKMARK',
    'apply_all': 'FILE_TICK',
    'snap': 'SNAP_ON',
    'to_cursor': 'PIVOT_CURSOR',
    'cursor_to_selection': 'PIVOT_ACTIVE',
    'to_active': 'PIVOT_INDIVIDUAL',
    'to_floor': 'TRIA_DOWN',
    'reset': 'X',
    'move': 'TRANSFORM_MOVE',
    'rotate': 'TRANSFORM_ROTATE',
    'scale': 'TRANSFORM_SCALE',
    'refresh': 'FILE_REFRESH',
    'restore': 'LOOP_BACK',
    'add': 'ADD',
    'remove': 'REMOVE',
    'toggle': 'FILE_REFRESH',
    'switch': 'VIEWZOOM',
    'collection': 'OUTLINER_COLLECTION',
    'popup': 'WINDOW',
    'run': 'PLAY',
    'swap': 'ARROW_LEFTRIGHT',
    'enabled': 'CHECKBOX_HLT',
}

TEXT_HINT_ICONS: dict[str, str] = {
    'move': 'move',
    '移動': 'move',
    'rotate': 'rotate',
    '回転': 'rotate',
    'scale': 'scale',
    'スケール': 'scale',
    '拡大縮小': 'scale',
    'add': 'add',
    '加算': 'add',
    'remove': 'remove',
    '減算': 'remove',
    'toggle': 'toggle',
    '切り替え': 'toggle',
    'switch': 'switch',
    '単独': 'switch',
    'restore': 'restore',
    '復元': 'restore',
    'box add': 'box_add',
    '箱で加算': 'box_add',
    'box remove': 'box_remove',
    '箱で減算': 'box_remove',
    'box toggle': 'box_toggle',
    '箱で切替': 'box_toggle',
    'lasso add': 'lasso_add',
    '縄で加算': 'lasso_add',
    'lasso remove': 'lasso_remove',
    '縄で減算': 'lasso_remove',
    'lasso toggle': 'lasso_toggle',
    '縄で切替': 'lasso_toggle',
    'collection': 'collection',
    'コレクション': 'collection',
}


def _preferred_builtin_icon(name: str | None) -> str:
    key = _icon_stem(name)
    if not key:
        return ''
    return str(BUILTIN_ICON_BY_CUSTOM_NAME.get(key, '') or '').strip()


def _logical_icon_for_builtin(icon: str | None) -> str:
    # Retained only for legacy calls that pass custom icon aliases explicitly.
    # Normal built-in icon arguments are returned unchanged by icon_kwargs() and
    # label_kwargs() so Blender's native icon is used directly.
    aliases = {
        'QUESTION': 'help',
        'HELP': 'help',
        'PREFERENCES': 'settings',
        'TOOL_SETTINGS': 'settings',
        'PRESET': 'profile',
        'PLUGIN': 'suite',
        'CON_TRANSLIKE': 'smart_transform',
        'EMPTY_ARROWS': 'quick_align',
        'EDITMODE_HLT': 'quick_multi_edit',
        'RESTRICT_SELECT_OFF': 'select_guard',
        'GROUP_UVS': 'uv',
        'GIZMO': 'gizmo',
        'MOUSE_LMB': 'click',
        'MOUSE_RMB': 'click',
        'KEY_HLT': 'keymap',
        'KEYINGSET': 'keymap',
        'TIME': 'always_on',
        'MOD_SMOOTH': 'anti_alias',
        'COLOR': 'color',
        'CURSOR': 'cursor',
        'DRIVER_DISTANCE': 'proportional',
        'INFO': 'info',
        'COPYDOWN': 'copy',
        'PASTEDOWN': 'paste',
        'CHECKMARK': 'apply',
        'FILE_TICK': 'apply_all',
        'SNAP_ON': 'snap',
        'PIVOT_CURSOR': 'to_cursor',
        'PIVOT_ACTIVE': 'cursor_to_selection',
        'PIVOT_INDIVIDUAL': 'to_active',
        'TRIA_DOWN': 'to_floor',
        'X': 'reset',
        'ORIENTATION_GIMBAL': 'smart_transform',
        'TRANSFORM_MOVE': 'move',
        'TRANSFORM_ROTATE': 'rotate',
        'TRANSFORM_SCALE': 'scale',
        'FILE_REFRESH': 'refresh',
        'LOOP_BACK': 'restore',
        'ADD': 'add',
        'REMOVE': 'remove',
        'VIEWZOOM': 'switch',
        'OUTLINER_COLLECTION': 'collection',
        'WINDOW': 'popup',
        'PLAY': 'run',
    }
    return aliases.get(str(icon or '').strip(), '')

def register() -> None:
    global _PREVIEWS, _ICON_COLLECTION, _REGISTERED
    if _REGISTERED:
        return
    try:
        import bpy.utils.previews as previews  # type: ignore
    except Exception:
        _REGISTERED = True
        return
    _PREVIEWS = previews
    try:
        pcoll = previews.new()
    except Exception:
        _REGISTERED = True
        return
    _ICON_COLLECTION = pcoll
    try:
        if _ICON_DIR.exists():
            loaded_paths: dict[str, Path] = {}
            for path in sorted(_ICON_DIR.glob('*.png')):
                name = path.stem
                loaded_paths[name] = path
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
            # Load legacy icon names as aliases that point to the deduplicated
            # representative PNGs.  This keeps every old code reference mapped
            # to the new icon pack without copying duplicate image files.
            for legacy_name, renamed_name in sorted(_load_icon_rename_aliases().items()):
                path = loaded_paths.get(renamed_name)
                if path is None:
                    continue
                try:
                    if legacy_name != renamed_name:
                        pcoll.load(legacy_name, str(path), 'IMAGE')
                except Exception:
                    pass
    finally:
        _REGISTERED = True


def unregister() -> None:
    global _PREVIEWS, _ICON_COLLECTION, _REGISTERED
    pcoll = _ICON_COLLECTION
    previews = _PREVIEWS
    if previews is not None and pcoll is not None:
        try:
            previews.remove(pcoll)
        except Exception:
            pass
    _ICON_COLLECTION = None
    _PREVIEWS = None
    _REGISTERED = False


def _loaded_icon_value(name: str) -> int:
    pcoll = _ICON_COLLECTION
    if pcoll is None:
        return 0
    try:
        icon = pcoll.get(str(name or '').strip())
        return int(getattr(icon, 'icon_id', 0) or 0) if icon is not None else 0
    except Exception:
        return 0


def icon_value(name: str | None, fallback: int = 0) -> int:
    key = _icon_stem(name)
    if not key:
        return int(fallback or 0)
    value = _loaded_icon_value(key)
    if value:
        return value
    resolved = resolved_icon_name(key)
    if resolved and resolved != key:
        value = _loaded_icon_value(resolved)
        if value:
            return value
    return int(fallback or 0)


def custom_icon_name(*, icon: str | None = None, operator_id: str | None = None, text: str | None = None, custom_icon: str | None = None, props: Mapping[str, object] | None = None) -> str:
    explicit = str(custom_icon or '').strip()
    if explicit:
        return explicit

    op_id = str(operator_id or '').strip()
    if op_id in OPERATOR_ICONS:
        name = OPERATOR_ICONS[op_id]
        if op_id == 'core.snap' and props:
            mode = str(props.get('mode', '') or '').strip().upper()
            if mode == 'TO_CURSOR':
                return 'to_cursor'
            if mode == 'CURSOR_TO_SEL':
                return 'cursor_to_selection'
            if mode == 'TO_ACTIVE':
                return 'to_active'
            if mode == 'TO_FLOOR':
                return 'to_floor'
        if op_id == 'view3d.quick_multi_edit_from_active_collection' and props:
            action = str(props.get('action', '') or '').strip().upper()
            if action == 'ADD':
                return 'collection_add'
            if action == 'REMOVE':
                return 'collection_remove'
            if action == 'TOGGLE':
                return 'collection_toggle'
        return name

    text_l = str(text or '').strip().lower()
    if text_l:
        for hint, name in TEXT_HINT_ICONS.items():
            if hint.lower() in text_l:
                return name
    return ''

def icon_kwargs(*, icon: str | None = None, operator_id: str | None = None, text: str | None = None, custom_icon: str | None = None, props: Mapping[str, object] | None = None) -> dict[str, object]:
    name = custom_icon_name(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props)
    builtin = _preferred_builtin_icon(name)
    if builtin:
        return {'icon': builtin}
    value = icon_value(name) if name else 0
    if value:
        return {'icon_value': value}
    icon_key = str(icon or 'NONE').strip() or 'NONE'
    return {'icon': icon_key}


def label_kwargs(icon: str | None = None, custom_icon: str | None = None) -> dict[str, object]:
    name = str(custom_icon or '').strip()
    if name:
        builtin = _preferred_builtin_icon(name)
        if builtin:
            return {'icon': builtin}
        value = icon_value(name)
        if value:
            return {'icon_value': value}
    return {'icon': str(icon or 'NONE').strip() or 'NONE'}
