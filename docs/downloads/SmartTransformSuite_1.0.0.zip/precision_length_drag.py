﻿# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Precision Numeric Drag integration for Smart Transform Suite.

After the operator ID is manually registered in Blender's ``Screen Editing``
keymap as ``Shift + Left Mouse / Press``, Shift-left drag over an editable
Rotation, Length, Mass, Time, or Temperature spinner to adjust it by the
configured Scene-unit-aware step. Time is stored as physical seconds while the
N-panel proxy converts to the active Scene time unit. The global keymap poll
accepts only supported RNA numeric buttons and invoke validates the target again,
so viewport selection and every other Shift-left gesture remain under Blender's
normal input handling.
"""

from __future__ import annotations

import math

import bpy
import blf

try:
    import gpu
    from gpu_extras.batch import batch_for_shader
except Exception:  # GPU drawing is optional; the drag operation still works.
    gpu = None
    batch_for_shader = None

from .translation import TI
from .manager_runtime_bridge import workspace_runtime_allowed as _workspace_runtime_allowed


bl_info = {
    "name": "Precision Numeric Drag",
    "author": "Smart Transform Suite",
    "version": (1, 5, 0),
    "blender": (5, 1, 0),
    "location": "Preferences > Keymap > Screen > Screen Editing > Shift Left Mouse Press",
    "description": "Shift-left-drag Rotation, Length, Mass, Time, and Temperature fields using Scene-unit-aware steps while passing every other Shift-left gesture through unchanged.",
    "category": "Interface",
}

ADDON_KEYMAPS: list[tuple[object, object]] = []
PRECISION_DRAG_OPERATOR_ID = "wm.smart_transform_precision_numeric_drag"
DEFAULT_NUMERIC_STEP = 0.01
PIXELS_PER_STEP = 2.0  # One configured numeric step for every two pixels of horizontal drag
_REGISTERED = False
_KEYMAP_ACTIVE = False

_STEP_PROP_BY_CATEGORY = {
    "rotation": "precision_numeric_drag_step_rotation",
    "length": "precision_numeric_drag_step_length",
    "mass": "precision_numeric_drag_step_mass",
    "time": "precision_numeric_drag_step_time",
    "temperature": "precision_numeric_drag_step_temperature",
}

_DEFAULT_STEP_BY_CATEGORY = {
    "rotation": math.radians(1.0),
    "length": 0.01,
    "mass": 0.01,
    "time": 1.0,
    "temperature": 1.0,
}

_CATEGORY_LABEL = {
    "rotation": ("Rotation", "回転"),
    "length": ("Length", "長さ"),
    "mass": ("Mass", "質量"),
    "time": ("Time", "時間"),
    "temperature": ("Temperature", "温度"),
}


# Backward-compatible constants for older callers that imported them directly.
CM_STEP = DEFAULT_NUMERIC_STEP
METER_PER_CM_STEP = 0.0001


def _t(en: str, ja: str) -> str:
    return TI(en, ja)


def _prefs(context=None):
    try:
        from . import runtime as _runtime
        return _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        return None


def _feature_enabled(context=None) -> bool:
    prefs = _prefs(context)
    try:
        return bool(getattr(prefs, 'enable_precision_length_drag', False))
    except Exception:
        return False


def _positive_step(value, fallback=DEFAULT_NUMERIC_STEP) -> float:
    try:
        result = float(value)
    except Exception:
        result = float(fallback)
    if not math.isfinite(result) or result <= 0.0:
        result = float(fallback)
    return max(result, 1.0e-9)


def _migrate_precision_unit_steps(prefs) -> None:
    """Migrate non-default legacy steps once without changing new defaults.

    fixed60 stored rotation in visible degrees and all other categories as raw
    unit-less values.  The new five settings are proper Blender unit-aware RNA
    properties.  Copy an old value only when it differs from the old default;
    this preserves customized installs while new installs keep the clearer new
    defaults (notably a one-degree rotation step).
    """
    if prefs is None:
        return
    try:
        if bool(getattr(prefs, "precision_numeric_drag_units_migrated_v61", False)):
            return
    except Exception:
        return
    legacy_pairs = (
        ("precision_number_drag_step_length", "precision_numeric_drag_step_length", False),
        ("precision_number_drag_step_mass", "precision_numeric_drag_step_mass", False),
        ("precision_number_drag_step_time", "precision_numeric_drag_step_time", False),
        ("precision_number_drag_step_temperature", "precision_numeric_drag_step_temperature", False),
        ("precision_number_drag_step_angle", "precision_numeric_drag_step_rotation", True),
    )
    for old_name, new_name, degrees_to_radians in legacy_pairs:
        try:
            old_value = float(getattr(prefs, old_name))
        except Exception:
            continue
        if not math.isfinite(old_value):
            continue
        # Every fixed60 legacy step defaulted to 0.01.  Preserve only an actual
        # customization; otherwise retain the new unit-aware default.
        if abs(old_value - 0.01) <= 1.0e-6:
            continue
        if degrees_to_radians:
            old_value = math.radians(old_value)
        try:
            setattr(prefs, new_name, max(old_value, 1.0e-9))
        except Exception:
            pass
    try:
        prefs.precision_numeric_drag_units_migrated_v61 = True
    except Exception:
        pass


def _temperature_step_to_internal(value: float, context=None) -> float:
    """Convert a displayed temperature *difference* to Blender's Kelvin delta.

    Blender's TEMPERATURE RNA unit represents an absolute temperature, so using
    it for a step field would display a 1 K step as roughly -272 °C.  The setting
    is therefore stored as a plain difference in the scene-selected unit and
    converted here.  Kelvin and Celsius differences have the same magnitude;
    Fahrenheit is included for forward compatibility even though Blender 5.1
    exposes Adaptive/Kelvin/Celsius.
    """
    try:
        ctx = context or getattr(bpy, 'context', None)
        unit = str(ctx.scene.unit_settings.temperature_unit or 'KELVIN').upper()
    except Exception:
        unit = 'KELVIN'
    if unit == 'FAHRENHEIT':
        return float(value) * (5.0 / 9.0)
    return float(value)


def _step_for_category(category: str, context=None) -> float:
    prefs = _prefs(context)
    _migrate_precision_unit_steps(prefs)
    prop_name = _STEP_PROP_BY_CATEGORY.get(category)
    if not prop_name:
        return 0.0
    fallback = float(_DEFAULT_STEP_BY_CATEGORY.get(category, DEFAULT_NUMERIC_STEP))
    value = None
    if prefs is not None:
        try:
            value = getattr(prefs, prop_name)
        except Exception:
            value = None
    value = _positive_step(value, fallback)
    if category == 'temperature':
        value = _temperature_step_to_internal(value, context)
        fallback = _temperature_step_to_internal(fallback, context)
    # Rotation, length, and mass settings use Blender RNA units directly. Time is
    # already stored as physical seconds by the N-panel display proxy. Temperature
    # is a unit-labelled delta converted above to avoid absolute-temperature
    # offsets.
    return _positive_step(value, fallback)


def _category_display_label(category: str) -> str:
    en, ja = _CATEGORY_LABEL.get(category, ("Numeric", "数値"))
    return _t(en, ja)


def _split_data_path_last_token(data_path: str) -> tuple[str, str]:
    """Split an RNA data path at the last dot outside brackets and strings."""
    depth = 0
    in_string = False
    quote = ""
    escape = False
    last_dot = -1

    for index, char in enumerate(data_path):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                in_string = False
            continue
        if char in {"'", '"'}:
            in_string = True
            quote = char
            continue
        if char == "[":
            depth += 1
            continue
        if char == "]":
            depth = max(0, depth - 1)
            continue
        if char == "." and depth == 0:
            last_dot = index
    if last_dot < 0:
        return "", data_path
    return data_path[:last_dot], data_path[last_dot + 1:]


def _collection_get(collection, identifier: str):
    try:
        return collection.get(identifier)
    except Exception:
        pass
    try:
        return collection[identifier]
    except Exception:
        return None


def _space_class_for_area(area):
    if area is None:
        return None
    name_by_type = {
        "VIEW_3D": "SpaceView3D",
        "PROPERTIES": "SpaceProperties",
        "NODE_EDITOR": "SpaceNodeEditor",
                "SEQUENCE_EDITOR": "SpaceSequenceEditor",
        "CLIP_EDITOR": "SpaceClipEditor",
        "DOPESHEET_EDITOR": "SpaceDopeSheetEditor",
        "GRAPH_EDITOR": "SpaceGraphEditor",
        "NLA_EDITOR": "SpaceNLA",
        "TEXT_EDITOR": "SpaceTextEditor",
        "CONSOLE": "SpaceConsole",
        "INFO": "SpaceInfo",
        "OUTLINER": "SpaceOutliner",
        "FILE_BROWSER": "SpaceFileBrowser",
        "PREFERENCES": "SpacePreferences",
        "SPREADSHEET": "SpaceSpreadsheet",
    }
    class_name = name_by_type.get(area.type)
    return getattr(bpy.types, class_name, None) if class_name else None


def _safe_tag_redraw(area):
    try:
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


def _hard_bounds(rna_property) -> tuple[float | None, float | None]:
    hard_min = getattr(rna_property, "hard_min", None)
    hard_max = getattr(rna_property, "hard_max", None)
    try:
        hard_min = float(hard_min)
    except Exception:
        hard_min = None
    try:
        hard_max = float(hard_max)
    except Exception:
        hard_max = None
    if hard_min is not None and not math.isfinite(hard_min):
        hard_min = None
    if hard_max is not None and not math.isfinite(hard_max):
        hard_max = None
    return hard_min, hard_max


def _clamp_value(value: float, hard_min: float | None, hard_max: float | None) -> float:
    if hard_min is not None and value < hard_min:
        value = hard_min
    if hard_max is not None and value > hard_max:
        value = hard_max
    return value


def _float_category_for_property(rna_property, property_id: str = "") -> str | None:
    del property_id
    if getattr(rna_property, "type", "") != "FLOAT":
        return None
    # Blender's RNA unit category is the sole authority.  Subtypes such as
    # QUATERNION and AXISANGLE are unit-less numeric component arrays; applying
    # an angular step to those values would be incorrect.  True angle/Euler,
    # translation/distance, and dimension fields already expose ROTATION or
    # LENGTH as their RNA unit.
    unit = str(getattr(rna_property, "unit", "NONE") or "NONE").upper()
    if unit == "ROTATION":
        return "rotation"
    if unit == "LENGTH":
        return "length"
    if unit == "MASS":
        return "mass"
    if unit in {"TIME", "TIME_ABSOLUTE"}:
        return "time"
    if unit == "TEMPERATURE":
        return "temperature"
    # Only the five categories present in Scene Properties > Units use custom
    # steps. Unit-less factor/scale/quaternion fields, derived units, colors, and
    # integer fields retain Blender's standard drag behavior.
    return None


class _NumericTarget:
    __slots__ = (
        "datablock",
        "owner",
        "data_path",
        "property_id",
        "property_index",
        "rna_property",
        "is_array",
        "start_value",
        "label",
        "hard_min",
        "hard_max",
        "category",
        "step_value",
    )

    def __init__(
        self,
        datablock,
        owner,
        data_path: str,
        property_id: str,
        property_index: int,
        rna_property,
        is_array: bool,
        start_value: float,
        label: str,
        hard_min: float | None,
        hard_max: float | None,
        category: str,
        step_value: float,
    ):
        self.datablock = datablock
        self.owner = owner
        self.data_path = data_path
        self.property_id = property_id
        self.property_index = property_index
        self.rna_property = rna_property
        self.is_array = is_array
        self.start_value = start_value
        self.label = label
        self.hard_min = hard_min
        self.hard_max = hard_max
        self.category = category
        self.step_value = step_value


# Backward-compatible alias for older imports.
_LengthTarget = _NumericTarget


def _build_target(datablock, owner, data_path: str, property_id: str, property_index: int, rna_property, context=None) -> _NumericTarget | None:
    category = _float_category_for_property(rna_property, property_id)
    if category is None:
        return None
    try:
        if owner.is_property_readonly(property_id):
            return None
    except Exception:
        pass
    array_length = int(getattr(rna_property, "array_length", 0) or 0)
    is_array = array_length > 0
    try:
        raw_value = getattr(owner, property_id)
    except Exception:
        return None
    if is_array:
        if property_index < 0 or property_index >= array_length:
            return None
        try:
            start_value = float(raw_value[property_index])
        except Exception:
            return None
    else:
        property_index = -1
        try:
            start_value = float(raw_value)
        except Exception:
            return None
    if not math.isfinite(start_value):
        return None
    hard_min, hard_max = _hard_bounds(rna_property)
    base_label = getattr(rna_property, "name", property_id) or property_id
    try:
        base_label = bpy.app.translations.pgettext_iface(base_label)
    except Exception:
        pass
    if is_array and property_index >= 0:
        suffixes = ("X", "Y", "Z", "W")
        suffix = suffixes[property_index] if property_index < len(suffixes) else str(property_index)
        label = f"{base_label} {suffix}"
    else:
        label = str(base_label)
    return _NumericTarget(
        datablock=datablock,
        owner=owner,
        data_path=str(data_path or property_id),
        property_id=property_id,
        property_index=property_index,
        rna_property=rna_property,
        is_array=is_array,
        start_value=start_value,
        label=label,
        hard_min=hard_min,
        hard_max=hard_max,
        category=category,
        step_value=_step_for_category(category, context),
    )


def _coerce_property_index(raw_index) -> int:
    try:
        if raw_index is None:
            return -1
        index = int(raw_index)
    except Exception:
        return -1
    return index if index >= 0 else -1


def _rna_property_from_owner(owner, property_id: str):
    if owner is None or not property_id:
        return None
    try:
        properties = getattr(getattr(owner, "bl_rna", None), "properties", None)
    except Exception:
        properties = None
    if properties is None:
        return None
    return _collection_get(properties, property_id)


def _parse_property_token(token: str, fallback_property_id: str = "") -> tuple[str, int]:
    token = str(token or "").strip()
    fallback_property_id = str(fallback_property_id or "").strip()
    if not token:
        return fallback_property_id, -1
    if token.endswith("]") and "[" in token:
        base, index_text = token.rsplit("[", 1)
        base = base.strip()
        index_text = index_text[:-1].strip()
        if base.isidentifier():
            return base, _coerce_property_index(index_text)
    if token.isidentifier():
        return token, -1
    return fallback_property_id, -1


def _property_index_from_context_attrs(context) -> int:
    for attr_name in (
        "button_prop_array_index",
        "button_property_index",
        "button_array_index",
        "property_index",
        "button_index",
        "index",
    ):
        try:
            index = _coerce_property_index(getattr(context, attr_name))
        except Exception:
            continue
        if index >= 0:
            return index
    return -1


def _target_from_context_property(context, fallback_owner=None, fallback_rna_property=None) -> _NumericTarget | None:
    """Resolve Blender's active UI property tuple when available.

    Some Blender 5.1 numeric spinners expose the hovered field through
    ``context.property`` instead of, or in addition to,
    ``button_pointer``/``button_prop``.  The tuple can also contain the exact
    vector component index selected by the spinner, so use it before falling
    back to the generic button context.
    """
    try:
        payload = getattr(context, "property", None)
    except Exception:
        payload = None
    if not isinstance(payload, tuple) or len(payload) < 2:
        return None

    try:
        owner = payload[0]
        raw_property = payload[1]
    except Exception:
        return None
    property_index = -1
    if len(payload) >= 3:
        property_index = _coerce_property_index(payload[2])

    if owner is None:
        owner = fallback_owner
    if owner is None:
        return None

    fallback_property_id = str(getattr(fallback_rna_property, "identifier", "") or "")
    rna_property = None
    property_id = ""
    data_path = ""

    if hasattr(raw_property, "identifier"):
        rna_property = raw_property
        property_id = str(getattr(raw_property, "identifier", "") or "")
        data_path = property_id
    else:
        data_path = str(raw_property or "").strip()
        owner_path, token = _split_data_path_last_token(data_path)
        property_id, parsed_index = _parse_property_token(token, fallback_property_id)
        if property_index < 0 and parsed_index >= 0:
            property_index = parsed_index
        if owner_path:
            try:
                owner = owner.path_resolve(owner_path)
            except Exception:
                pass

    if not property_id:
        return None
    if fallback_rna_property is not None and property_id == fallback_property_id:
        rna_property = fallback_rna_property
    if rna_property is None:
        rna_property = _rna_property_from_owner(owner, property_id)
    if rna_property is None:
        return None
    if property_index < 0:
        property_index = _property_index_from_context_attrs(context)
    try:
        owner_data_path = owner.path_from_id(property_id)
    except Exception:
        owner_data_path = data_path or property_id
    return _build_target(getattr(owner, "id_data", owner), owner, str(owner_data_path or property_id), property_id, property_index, rna_property, context)


def _target_from_button_context(context) -> _NumericTarget | None:
    """Resolve an editable floating-point field under Blender's active UI button context."""
    try:
        owner = getattr(context, "button_pointer", None)
    except Exception:
        owner = None
    try:
        rna_property = getattr(context, "button_prop", None)
    except Exception:
        rna_property = None

    target = _target_from_context_property(context, owner, rna_property)
    if target is not None:
        return target
    return _target_from_button_pointer_context(context)


def _target_from_button_pointer_context(context) -> _NumericTarget | None:
    try:
        owner = getattr(context, "button_pointer", None)
    except Exception:
        owner = None
    try:
        rna_property = getattr(context, "button_prop", None)
    except Exception:
        rna_property = None
    if owner is None or rna_property is None:
        return None
    property_id = str(getattr(rna_property, "identifier", "") or "")
    if not property_id and isinstance(rna_property, str):
        property_id = rna_property
        rna_property = _rna_property_from_owner(owner, property_id)
    if not property_id:
        return None
    if rna_property is None or not hasattr(rna_property, "type"):
        rna_property = _rna_property_from_owner(owner, property_id)
    if rna_property is None:
        return None
    property_index = _property_index_from_context_attrs(context)
    if property_index < 0:
        path_target = _target_from_context_property(context, owner, rna_property)
        if path_target is not None:
            return path_target
    try:
        data_path = owner.path_from_id(property_id)
    except Exception:
        data_path = property_id
    return _build_target(getattr(owner, "id_data", owner), owner, str(data_path or property_id), property_id, property_index, rna_property, context)


def _set_target_value(target: _NumericTarget, value: float) -> bool:
    try:
        if target.is_array:
            current = getattr(target.owner, target.property_id)
            try:
                current[target.property_index] = value
            except Exception:
                replacement = list(current)
                replacement[target.property_index] = value
                setattr(target.owner, target.property_id, replacement)
        else:
            setattr(target.owner, target.property_id, value)
        try:
            id_data = getattr(target.owner, 'id_data', None)
            if id_data is not None and hasattr(id_data, 'update_tag'):
                id_data.update_tag()
        except Exception:
            pass
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
    except Exception:
        return False
    return True


def _format_numeric_value(target: _NumericTarget, value: float) -> str:
    if target.category == "rotation":
        try:
            scene = getattr(bpy.context, "scene", None)
            if scene is not None and str(getattr(scene.unit_settings, "system_rotation", "DEGREES")) == "RADIANS":
                return f"{value:.6g} rad"
        except Exception:
            pass
        return f"{math.degrees(value):.4f}°"
    return f"{value:.6g}"


def _draw_popup(operator):
    if not operator._target:
        return
    if not _workspace_runtime_allowed(getattr(bpy, "context", None)):
        return
    font_id = 0
    try:
        ui_scale = float(bpy.context.preferences.system.ui_scale)
    except Exception:
        ui_scale = 1.0
    font_size = max(11, int(round(12 * ui_scale)))
    padding_x = int(round(9 * ui_scale))
    padding_y = int(round(7 * ui_scale))
    line_gap = int(round(4 * ui_scale))
    current = operator._current_value
    delta = current - operator._target.start_value
    lines = (
        f"{operator._target.label}: {_format_numeric_value(operator._target, current)}",
        f"Δ {_format_numeric_value(operator._target, delta)}",
        f"{_category_display_label(operator._target.category)} step: {_format_numeric_value(operator._target, operator._target.step_value)}",
    )
    try:
        blf.size(font_id, font_size)
    except TypeError:
        blf.size(font_id, font_size, 72)
    except Exception:
        pass
    dimensions = []
    for line in lines:
        try:
            dimensions.append(blf.dimensions(font_id, line))
        except Exception:
            dimensions.append((len(line) * font_size * 0.55, font_size))
    text_width = max((width for width, _height in dimensions), default=120.0)
    line_height = max((height for _width, height in dimensions), default=float(font_size))
    box_width = text_width + padding_x * 2
    box_height = line_height * len(lines) + line_gap * (len(lines) - 1) + padding_y * 2
    x = max(6, operator._draw_mouse_region_x + int(round(14 * ui_scale)))
    y = max(6, operator._draw_mouse_region_y + int(round(18 * ui_scale)))
    if gpu is not None and batch_for_shader is not None:
        try:
            shader = gpu.shader.from_builtin("UNIFORM_COLOR")
            coords = ((x, y), (x + box_width, y), (x + box_width, y + box_height), (x, y + box_height))
            batch = batch_for_shader(shader, "TRIS", {"pos": coords}, indices=((0, 1, 2), (0, 2, 3)))
            gpu.state.blend_set("ALPHA")
            shader.bind()
            shader.uniform_float("color", (0.08, 0.08, 0.08, 0.86))
            batch.draw(shader)
            gpu.state.blend_set("NONE")
        except Exception:
            try:
                gpu.state.blend_set("NONE")
            except Exception:
                pass
    try:
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
    except Exception:
        pass
    text_y = y + box_height - padding_y - line_height
    for line in lines:
        try:
            blf.position(font_id, x + padding_x, text_y, 0)
            blf.draw(font_id, line)
        except Exception:
            pass
        text_y -= line_height + line_gap



def _event_matches_shift_left_precision_drag(event) -> bool:
    """Return True only for the manually registered Shift-left press chord.

    The operator starts on the initial press and handles the subsequent drag
    modally.  Tweak/click-drag events are deliberately rejected because those
    are also used by viewport selection tools and other editors.
    """
    try:
        return (
            str(getattr(event, "type", "") or "") == "LEFTMOUSE"
            and str(getattr(event, "value", "") or "") == "PRESS"
            and bool(getattr(event, "shift", False))
            and not bool(getattr(event, "ctrl", False))
            and not bool(getattr(event, "alt", False))
            and not bool(getattr(event, "oskey", False))
        )
    except Exception:
        return False


def _live_numeric_target_from_context(context) -> _NumericTarget | None:
    """Resolve the exact supported FLOAT property under the current UI event.

    Blender 5.1 normally exposes ``context.property`` while a Screen Editing
    keymap item is polled over an RNA button, and always exposes it again during
    invoke. The older button_pointer/button_prop pair is retained as a fallback.
    """
    if context is None:
        return None
    try:
        payload = getattr(context, "property", None)
    except Exception:
        payload = None
    try:
        button_prop = getattr(context, "button_prop", None)
    except Exception:
        button_prop = None
    if not (isinstance(payload, tuple) and len(payload) >= 2) and button_prop is None:
        return None
    return _target_from_button_context(context)


def _context_has_explicit_property_payload(context) -> bool:
    if context is None:
        return False
    try:
        payload = getattr(context, 'property', None)
        if isinstance(payload, tuple) and len(payload) >= 2:
            return True
    except Exception:
        pass
    try:
        return getattr(context, 'button_prop', None) is not None
    except Exception:
        return False


def _set_keymap_item_modifiers(keymap_item, *, shift=False, ctrl=False, alt=False, oskey=False) -> None:
    for attr, value in (
        ("shift", shift),
        ("ctrl", ctrl),
        ("alt", alt),
        ("oskey", oskey),
    ):
        try:
            setattr(keymap_item, attr, bool(value))
        except Exception:
            pass


class _PrecisionNumericDragOperatorBase:
    bl_label = TI("Precision Numeric Drag", "精密数値ドラッグ")
    bl_description = TI(
        "Manually register this operator in Preferences > Keymap > Screen > Screen Editing as Shift + Left Mouse / Press. Rotation, Length, Mass, Time, and Temperature spinners use their configured Scene-unit-aware step. Unsupported fields and every non-numeric Shift-left gesture are rejected before this modal operator starts. Left-button release confirms; Esc or right click restores the starting value.",
        "このオペレーターを、プリファレンス > キーマップ > スクリーン > スクリーン編集 に Shift + 左マウス / 押下 として手動登録します。「回転」「長さ」「質量」「時間」「温度」の数値スピナーでは、現在のシーン単位に対応した設定刻みを使用します。対象外の数値欄と数値欄以外のShift+左操作では、本モーダルオペレーターを起動しません。左ボタンを離すと確定し、Escまたは右クリックで開始値へ戻します。",
    )
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    _target: _NumericTarget | None = None
    _area = None
    _region_type = "WINDOW"
    _space_class = None
    _draw_handler = None
    _start_mouse_x = 0
    _region_origin_x = 0
    _region_origin_y = 0
    _draw_mouse_region_x = 0
    _draw_mouse_region_y = 0
    _current_value = 0.0

    @classmethod
    def poll(cls, context):
        # Screen Editing is global. Blender 5.1 attaches context.property (or the
        # legacy button_prop payload) while keymap poll is evaluating a real RNA
        # property button in N-panels, Properties, node controls, headers and
        # popovers. Require that exact payload and resolve the supported FLOAT unit
        # before invocation. Viewports, canvas backgrounds, ordinary buttons,
        # integer fields and unsupported/unit-less floats therefore never start
        # this operator and retain their original Shift-left event path unchanged.
        if not _feature_enabled(context):
            return False
        if not _context_has_explicit_property_payload(context):
            return False
        if not _workspace_runtime_allowed(context):
            return False
        try:
            return _live_numeric_target_from_context(context) is not None
        except Exception:
            return False

    @classmethod
    def description(cls, context, properties):
        del properties
        if not _feature_enabled(context):
            return _t(
                "Precision Numeric Drag is currently disabled in Smart Transform > Other Tools. Enable it after manually registering this operator in Screen > Screen Editing as Shift + Left Mouse / Press.",
                "精密数値ドラッグは Smart Transform > その他ツール で現在無効です。スクリーン > スクリーン編集 に Shift + 左マウス / 押下 として本オペレーターを手動登録した後、この機能を有効化してください。",
            )
        return cls.bl_description

    def _update_draw_position(self, event):
        try:
            self._draw_mouse_region_x = int(event.mouse_x) - int(self._region_origin_x)
            self._draw_mouse_region_y = int(event.mouse_y) - int(self._region_origin_y)
        except Exception:
            self._draw_mouse_region_x = int(getattr(event, "mouse_region_x", 0))
            self._draw_mouse_region_y = int(getattr(event, "mouse_region_y", 0))

    def _install_draw_handler(self, context):
        self._area = context.area
        region = context.region
        self._region_type = getattr(region, "type", "WINDOW") if region is not None else "WINDOW"
        self._region_origin_x = int(getattr(region, "x", 0) or 0)
        self._region_origin_y = int(getattr(region, "y", 0) or 0)
        self._space_class = _space_class_for_area(context.area)
        if self._space_class is None:
            return
        try:
            self._draw_handler = self._space_class.draw_handler_add(_draw_popup, (self,), self._region_type, "POST_PIXEL")
        except Exception:
            self._draw_handler = None
            self._space_class = None

    def _remove_draw_handler(self):
        if self._draw_handler is not None and self._space_class is not None:
            try:
                self._space_class.draw_handler_remove(self._draw_handler, self._region_type)
            except Exception:
                pass
        self._draw_handler = None
        self._space_class = None

    def _finish_cleanup(self):
        self._remove_draw_handler()
        _safe_tag_redraw(self._area)
        self._target = None
        self._area = None

    def execute(self, context):
        # Direct console/operator-history execution has no active UI button/event.
        # Pass-through is not accepted from execute(), so cancel without touching data.
        del context
        return {"CANCELLED"}

    def invoke(self, context, event):
        if not _feature_enabled(context) or not _event_matches_shift_left_precision_drag(event):
            return {"CANCELLED", "PASS_THROUGH"}
        if not _workspace_runtime_allowed(context):
            return {"CANCELLED", "PASS_THROUGH"}
        target = _live_numeric_target_from_context(context)
        if target is None:
            # Defensive revalidation for a UI rebuild between poll and invoke.
            # The original event remains available to Blender's button handler.
            return {"CANCELLED", "PASS_THROUGH"}
        self._target = target
        self._current_value = target.start_value
        self._start_mouse_x = int(getattr(event, "mouse_x", 0))
        self._install_draw_handler(context)
        self._update_draw_position(event)
        _safe_tag_redraw(context.area)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if self._target is None:
            self._finish_cleanup()
            return {"CANCELLED"}
        if not _workspace_runtime_allowed(context):
            _set_target_value(self._target, self._target.start_value)
            self._current_value = self._target.start_value
            self._finish_cleanup()
            return {"CANCELLED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            self._update_draw_position(event)
            distance_px = float(int(getattr(event, "mouse_x", self._start_mouse_x)) - self._start_mouse_x)
            steps = int(round(distance_px / PIXELS_PER_STEP))
            new_value = self._target.start_value + steps * self._target.step_value
            new_value = _clamp_value(new_value, self._target.hard_min, self._target.hard_max)
            if _set_target_value(self._target, new_value):
                self._current_value = new_value
            else:
                _set_target_value(self._target, self._target.start_value)
                self.report({"WARNING"}, _t("The selected numeric field could not be edited.", "選択した数値欄を編集できませんでした。"))
                self._finish_cleanup()
                return {"CANCELLED"}
            _safe_tag_redraw(self._area)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            self._finish_cleanup()
            return {"FINISHED"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            _set_target_value(self._target, self._target.start_value)
            self._current_value = self._target.start_value
            self._finish_cleanup()
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


class WM_OT_smart_transform_precision_numeric_drag(_PrecisionNumericDragOperatorBase, bpy.types.Operator):
    bl_idname = PRECISION_DRAG_OPERATOR_ID

    @classmethod
    def poll(cls, context):
        return _PrecisionNumericDragOperatorBase.poll.__func__(cls, context)

    @classmethod
    def description(cls, context, properties):
        return _PrecisionNumericDragOperatorBase.description.__func__(cls, context, properties)

    def execute(self, context):
        return _PrecisionNumericDragOperatorBase.execute(self, context)

    def invoke(self, context, event):
        return _PrecisionNumericDragOperatorBase.invoke(self, context, event)

    def modal(self, context, event):
        return _PrecisionNumericDragOperatorBase.modal(self, context, event)


classes = (
    WM_OT_smart_transform_precision_numeric_drag,
)


def _precision_drag_operator_idnames() -> set[str]:
    return {PRECISION_DRAG_OPERATOR_ID}


def _keymap_item_is_ours(kmi) -> bool:
    try:
        return str(getattr(kmi, 'idname', '') or '') in _precision_drag_operator_idnames()
    except Exception:
        return False


def _keymap_item_is_active_operator(kmi) -> bool:
    try:
        return str(getattr(kmi, 'idname', '') or '') == PRECISION_DRAG_OPERATOR_ID
    except Exception:
        return False


def _key_config_is_user(key_config) -> bool:
    try:
        wm = bpy.context.window_manager
        if key_config is getattr(wm.keyconfigs, 'user', None):
            return True
    except Exception:
        pass
    try:
        return str(getattr(key_config, 'name', '') or '').strip().lower().endswith('user')
    except Exception:
        return False


def _track_keymap_item(keymap, keymap_item) -> None:
    for km, kmi in list(ADDON_KEYMAPS):
        if km is keymap and kmi is keymap_item:
            return
    ADDON_KEYMAPS.append((keymap, keymap_item))


def _keymap_item_is_live(keymap, keymap_item) -> bool:
    try:
        return keymap_item in list(getattr(keymap, 'keymap_items', []) or []) and bool(getattr(keymap_item, 'active', False))
    except Exception:
        return False


def _keymap_item_signature(keymap, keymap_item):
    try:
        return (
            str(getattr(keymap, "name", "") or ""),
            str(getattr(keymap, "space_type", "") or "EMPTY"),
            str(getattr(keymap, "region_type", "") or "WINDOW"),
            str(getattr(keymap_item, "type", "") or ""),
            str(getattr(keymap_item, "value", "") or ""),
            bool(getattr(keymap_item, "shift", False)),
            bool(getattr(keymap_item, "ctrl", False)),
            bool(getattr(keymap_item, "alt", False)),
            bool(getattr(keymap_item, "oskey", False)),
        )
    except Exception:
        return None


def _has_stale_precision_drag_keymap_items(required: set[tuple]) -> bool:
    try:
        wm = bpy.context.window_manager
        keyconfigs = tuple(kc for kc in (wm.keyconfigs.addon, wm.keyconfigs.user) if kc is not None)
    except Exception:
        keyconfigs = ()
    for key_config in keyconfigs:
        try:
            keymaps = list(getattr(key_config, "keymaps", []) or [])
        except Exception:
            keymaps = []
        for keymap in keymaps:
            try:
                items = list(getattr(keymap, "keymap_items", []) or [])
            except Exception:
                items = []
            for keymap_item in items:
                if not _keymap_item_is_ours(keymap_item):
                    continue
                try:
                    if not bool(getattr(keymap_item, "active", False)):
                        continue
                except Exception:
                    pass
                signature = _keymap_item_signature(keymap, keymap_item)
                if _key_config_is_user(key_config):
                    if _keymap_item_is_active_operator(keymap_item) and signature in required:
                        continue
                    return True
                if not _keymap_item_is_active_operator(keymap_item) or signature not in required:
                    return True
    return False


def _tracked_keymaps_are_live() -> bool:
    required = set(_keymap_specs())
    if not required or len(ADDON_KEYMAPS) < len(required):
        return False
    if _has_stale_precision_drag_keymap_items(required):
        return False
    live = set()
    for keymap, keymap_item in list(ADDON_KEYMAPS):
        if not _keymap_item_is_live(keymap, keymap_item):
            return False
        if not _keymap_item_is_active_operator(keymap_item):
            return False
        signature = _keymap_item_signature(keymap, keymap_item)
        if signature is None:
            return False
        live.add(signature)
    return required.issubset(live)


def _new_keymap_item_compatible(keymap, event_type="LEFTMOUSE", event_value="CLICK_DRAG", *, shift=True, ctrl=False, alt=False, oskey=False):
    """No-op: Precision Numeric Drag no longer creates keymap items automatically."""
    del keymap, event_type, event_value, shift, ctrl, alt, oskey
    return None

def _keymap_item_matches_event(keymap_item, event_type: str, event_value: str, *, shift=False, ctrl=False, alt=False, oskey=False) -> bool:
    try:
        return (
            str(getattr(keymap_item, "type", "") or "") == event_type
            and str(getattr(keymap_item, "value", "") or "") == event_value
            and bool(getattr(keymap_item, "shift", False)) == bool(shift)
            and bool(getattr(keymap_item, "ctrl", False)) == bool(ctrl)
            and bool(getattr(keymap_item, "alt", False)) == bool(alt)
            and bool(getattr(keymap_item, "oskey", False)) == bool(oskey)
        )
    except Exception:
        return False


def _keymap_specs():
    # Manual shortcut reference only. Smart Transform Suite never creates or
    # repairs Blender keymap entries automatically.
    #
    # Blender 5.1 exposes ordinary RNA spinner payloads during Screen Editing
    # keymap poll. Unsupported fields and editor viewports are rejected before
    # invoke; invoke revalidates uncommon UI controls before entering modal state. The supported registration is:
    #   Screen > Screen Editing : Shift + Left Mouse / Press
    return (
        ("Screen Editing", "EMPTY", "WINDOW", "LEFTMOUSE", "PRESS", True, False, False, False),
    )

def _keymap_spec_from_item(keymap, keymap_item):
    try:
        return (
            str(getattr(keymap, "name", "") or ""),
            str(getattr(keymap, "space_type", "") or "EMPTY"),
            str(getattr(keymap, "region_type", "") or "WINDOW"),
            str(getattr(keymap_item, "type", "") or ""),
            str(getattr(keymap_item, "value", "") or ""),
            bool(getattr(keymap_item, "shift", False)),
            bool(getattr(keymap_item, "ctrl", False)),
            bool(getattr(keymap_item, "alt", False)),
            bool(getattr(keymap_item, "oskey", False)),
        )
    except Exception:
        return None


def _remove_obsolete_keymaps_for_our_operator() -> bool:
    """No-op: do not remove or deactivate Blender keymaps automatically."""
    return False

def _remove_stale_saved_keymaps_for_our_operator():
    """No-op: saved keymaps are user-managed only."""
    return

def _user_priority_keymaps_are_live() -> bool:
    """No-op: automatic user-keyconfig inspection/repair is disabled."""
    return False

def _register_user_priority_keymaps() -> bool:
    """No-op: automatic user-keyconfig injection is disabled."""
    return False

def _deactivate_user_priority_keymaps() -> None:
    """No-op: do not alter user keymap items automatically."""
    return

def _register_keymaps():
    """No-op: keymap registration is manual-only."""
    global _KEYMAP_ACTIVE
    _KEYMAP_ACTIVE = False
    try:
        ADDON_KEYMAPS.clear()
    except Exception:
        pass
    return

def _unregister_keymaps():
    """Clear local keymap references only; do not mutate Blender keymaps."""
    global _KEYMAP_ACTIVE
    try:
        ADDON_KEYMAPS.clear()
    except Exception:
        pass
    _KEYMAP_ACTIVE = False
    return

_KEYMAP_GUARD_ACTIVE = False


def _keymap_guard_timer():
    """No-op timer body; automatic keymap repair is disabled."""
    global _KEYMAP_GUARD_ACTIVE
    _KEYMAP_GUARD_ACTIVE = False
    return None

def _ensure_keymap_guard():
    """No-op: do not start keymap repair timers."""
    global _KEYMAP_GUARD_ACTIVE
    _KEYMAP_GUARD_ACTIVE = False
    return

def _remove_all_precision_drag_keymaps() -> None:
    """No-op: never remove/deactivate keymaps automatically."""
    return

def sync_runtime_from_prefs(context=None):
    """Register only operators/classes; keymaps are manual-only."""
    try:
        _migrate_precision_unit_steps(_prefs(context))
    except Exception:
        pass
    try:
        ADDON_KEYMAPS.clear()
    except Exception:
        pass
    return

def ensure_registered(enable=True):
    if enable:
        register()
    else:
        unregister()


def register():
    global _REGISTERED
    if not _REGISTERED:
        for cls in classes:
            try:
                from . import operator_safety as _operator_safety
                if hasattr(_operator_safety, 'normalize_operator_class_for_registration'):
                    _operator_safety.normalize_operator_class_for_registration(cls)
            except Exception:
                pass
            try:
                bpy.utils.register_class(cls)
            except ValueError:
                pass
        _REGISTERED = True
    # Exception guards are installed once by the main package register after all
    # Operator classes have been registered. Installing them here can leave a
    # guarded class with an invalid registration signature during reload.
    sync_runtime_from_prefs(getattr(bpy, 'context', None))


def unregister():
    global _REGISTERED
    _unregister_keymaps()
    _deactivate_user_priority_keymaps()
    if _REGISTERED:
        for cls in reversed(classes):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        _REGISTERED = False


if __name__ == "__main__":
    register()
