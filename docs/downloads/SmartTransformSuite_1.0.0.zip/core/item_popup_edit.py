"""Popup-only native Item median and collection rules (Blender ec6e62d40fa9)."""


def bounded_values(values, desired, total=None):
    values = tuple(float(v) for v in values)
    if not values:
        return ()
    total = len(values) if total is None else total
    old = sum(values) / len(values)
    desired = min(1.0, max(0.0, float(desired)))
    if desired == old:
        return values
    if total == 1 or desired in (0.0, 1.0):
        return tuple(desired for _ in values)
    old = min(1.0, max(0.0, old))
    if desired <= old:
        scale = desired / old
        return tuple(min(1.0, max(0.0, v * scale)) for v in values)
    scale = (1.0 - desired) / (1.0 - old)
    return tuple(min(1.0, max(0.0, 1.0 - (1.0 - v) * scale)) for v in values)


def additive_values(values, desired, total=None):
    values = tuple(float(v) for v in values)
    if not values:
        return ()
    total = len(values) if total is None else total
    delta = float(desired) - sum(values) / len(values)
    return tuple(float(desired) if total == 1 else v + delta for v in values)


def skin_values(values, desired, total=None):
    values = tuple(float(v) for v in values)
    if not values:
        return ()
    total = len(values) if total is None else total
    old = sum(values) / len(values)
    if total == 1 or old == 0.0:
        return tuple(float(desired) for _ in values)
    return tuple(v * float(desired) / old for v in values)


def bone_collection_visible(bone, armature):
    collections = tuple(bone.collections)
    if not collections:
        return not armature.collections.is_solo_active
    return any(collection.is_visible_effectively for collection in collections)


def legacy_translate(data, delta):
    """Native Item center/handle selection and NURB_HANDLE_TEST_EACH.

    Snapshot before any RNA update; bulk writes avoid sequential center/handle
    deltas reading already-recalculated handles. The final RNA co update calls
    BKE_nurb_handles_calc (rna_Curve_update_points).
    """
    for spline in data.splines:
        if spline.type != 'BEZIER':
            coordinates=[]
            for point in spline.points:
                co=list(point.co)
                if point.select:
                    co[:3]=[co[i]+delta[i] for i in range(3)]
                if data.dimensions == '2D':
                    co[2]=0.0
                coordinates.extend(co)
            if coordinates:
                spline.points.foreach_set('co',coordinates)
            continue
        points=list(spline.bezier_points)
        coordinates={name:[] for name in ('co','handle_left','handle_right')}
        transitions=[]
        for point in points:
            flags=(point.select_left_handle,point.select_control_point,point.select_right_handle)
            for name,selected in zip(('handle_left','co','handle_right'),flags):
                co=list(getattr(point,name))
                if flags[1] or selected:
                    co=[co[i]+delta[i] for i in range(3)]
                if data.dimensions == '2D':
                    co[2]=0.0
                coordinates[name].extend(co)
            left,right=point.handle_left_type,point.handle_right_type
            if any(flags) and not all(flags):
                if left in {'AUTO','AUTO_CLAMPED'}:
                    left='ALIGNED'
                if right in {'AUTO','AUTO_CLAMPED'}:
                    right='ALIGNED'
                if left == 'VECTOR' and bool(flags[0]) != bool(flags[1]):
                    left='FREE'
                if right == 'VECTOR' and bool(flags[2]) != bool(flags[1]):
                    right='FREE'
            transitions.append((left,right))
        for point,(left,right) in zip(points,transitions):
            if point.handle_left_type != left:
                point.handle_left_type=left
            if point.handle_right_type != right:
                point.handle_right_type=right
        for name in ('co','handle_left','handle_right'):
            if points:
                spline.bezier_points.foreach_set(name,coordinates[name])
        if points:
            # Explicit public update; never a type/selection round-trip.
            points[0].co=points[0].co.copy()
    data.update_tag()


def legacy_project_2d(data):
    if data.dimensions != '2D':
        return
    for spline in data.splines:
        points=spline.bezier_points if spline.type=='BEZIER' else spline.points
        names=('co','handle_left','handle_right') if spline.type=='BEZIER' else ('co',)
        for name in names:
            values=[list(getattr(point,name)) for point in points]
            if any(co[2] != 0.0 for co in values):
                for co in values:co[2]=0.0
                points.foreach_set(name,[v for co in values for v in co])
