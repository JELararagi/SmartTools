# SPDX-FileCopyrightText: 2023 Blender Authors
# SPDX-License-Identifier: GPL-2.0-or-later
"""Popup-local port of Blender ec6e62d40fa9 curve_bezier.cc handle rules.

Pure tuple math is deliberately separate from public attribute access so exact
source vectors can run without importing Blender. No state or registration.
"""
from math import sqrt

FREE, AUTO, VECTOR, ALIGN = range(4)


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def mul(a, scale):
    return tuple(x * scale for x in a)


def length(a):
    return sqrt(sum(x * x for x in a))


def aligned(position, other, handle):
    direction = sub(other, position)
    size = length(direction)
    return sub(position, mul(direction, length(sub(handle, position)) / size)) if size else tuple(position)


def calculate_point_handles(type_left, type_right, position, previous, following, left, right):
    left, right = tuple(left), tuple(right)
    if AUTO in (type_left, type_right):
        prev_diff, next_diff = sub(position, previous), sub(following, position)
        prev_len, next_len = length(prev_diff) or 1.0, length(next_diff) or 1.0
        direction = add(mul(next_diff, 1.0 / next_len), mul(prev_diff, 1.0 / prev_len))
        size = length(direction) * 2.5614
        if size:
            if type_left == AUTO:
                left = add(position, mul(direction, -min(prev_len, next_len * 5.0) / size))
            if type_right == AUTO:
                right = add(position, mul(direction, min(next_len, prev_len * 5.0) / size))
    if type_left == VECTOR:
        left = add(position, mul(sub(previous, position), 1.0 / 3.0))
    if type_right == VECTOR:
        right = add(position, mul(sub(following, position), 1.0 / 3.0))
    if type_left == ALIGN and type_right != ALIGN:
        left = aligned(position, right, left)
    elif type_left != ALIGN and type_right == ALIGN:
        right = aligned(position, left, right)
    return left, right


def set_handle_position(position, kind, other_kind, new_handle, handle, other):
    if kind in (AUTO, VECTOR):
        return tuple(handle), tuple(other)
    handle = tuple(new_handle)
    if other_kind == ALIGN:
        other = aligned(position, handle, other)
    return handle, tuple(other)


def calculate_auto_handles(cyclic, types_left, types_right, positions, left, right):
    left, right = list(map(tuple, left)), list(map(tuple, right))
    size = len(positions)
    if size <= 1:
        return left, right
    for i, position in enumerate(positions):
        previous = positions[i - 1] if i or cyclic else sub(mul(position, 2), positions[1])
        following = positions[(i + 1) % size] if i + 1 < size or cyclic else sub(mul(position, 2), positions[-2])
        left[i], right[i] = calculate_point_handles(types_left[i], types_right[i], position,
                                                    previous, following, left[i], right[i])
    return left, right


def geometries(context):
    """Native active-object drawing scope, including editable selected GP frames."""
    obj = context.active_object
    if obj.type == 'CURVES':
        return (obj.data,)
    if obj.type != 'GREASEPENCIL':
        return ()
    multi = context.scene.tool_settings.use_grease_pencil_multi_frame_editing
    result = []
    for layer in obj.data.layers:
        owner = layer
        editable = True
        while owner is not None:
            if owner.hide or owner.lock:
                editable = False
                break
            owner = owner.parent_group
        if not editable:
            continue
        frames = [f for f in layer.frames if multi and f.select]
        current = layer.current_frame()
        if current is not None:
            frames.append(current)
        for frame in frames:
            drawing = frame.drawing
            if drawing is not None and drawing.type == 'DRAWING' and drawing not in result:
                result.append(drawing)
    return tuple(result)


def offsets(geometry):
    data = geometry.curve_offset_data if hasattr(geometry, 'curve_offset_data') else geometry.curve_offsets
    return [int(item.value) for item in data]


def read_attr(geometry, name, count, default, field='value'):
    attr = geometry.attributes.get(name)
    if attr is None:
        return [default for _ in range(count)]
    return [tuple(getattr(v, field)) if field == 'vector' else getattr(v, field) for v in attr.data]


def selected(geometry, name, bounds):
    size = bounds[-1] if bounds else 0
    attr = geometry.attributes.get(name)
    if attr is None:
        return [True] * size
    values = [bool(v.value) for v in attr.data]
    if attr.domain == 'CURVE':
        return [values[c] for c in range(len(bounds) - 1) for _ in range(bounds[c], bounds[c+1])]
    if attr.domain != 'POINT' or len(values) != size:
        raise ValueError('Unsupported curve selection attribute domain')
    return values


def coordinate_entries(context):
    entries = []
    for geometry in geometries(context):
        bounds = offsets(geometry)
        if not bounds:
            continue
        types = read_attr(geometry, 'curve_type', len(bounds)-1, 0)
        center = selected(geometry, '.selection', bounds)
        position = geometry.attributes.get('position')
        if position:
            entries.extend((v, 'vector') for i,v in enumerate(position.data) if center[i])
        for side in ('left','right'):
            attr = geometry.attributes.get('handle_' + side)
            if attr is None:
                continue
            selection = selected(geometry, '.selection_handle_' + side, bounds)
            for c in range(len(types)):
                if types[c] == 2:
                    entries.extend((attr.data[i], 'vector') for i in range(bounds[c],bounds[c+1]) if selection[i])
    return tuple(entries)


def scalar_entries(context, field, create=False):
    if field not in {'radius','tilt','nurbs_w'}:
        return ()
    name, default = {'radius':('radius',.01),'tilt':('tilt',0.0),'nurbs_w':('nurbs_weight',1.0)}[field]
    entries=[]
    for geometry in geometries(context):
        bounds=offsets(geometry)
        if not bounds:
            continue
        select=selected(geometry,'.selection',bounds)
        types=read_attr(geometry,'curve_type',len(bounds)-1,0)
        indices=[i for c in range(len(types)) for i in range(bounds[c],bounds[c+1])
                 if select[i] and (field != 'nurbs_w' or types[c] == 3)]
        attr=geometry.attributes.get(name)
        if indices and attr is None and create:
            attr=geometry.attributes.new(name=name,type='FLOAT',domain='POINT')
            for value in attr.data:
                value.value=default
        entries.extend((attr.data[i] if attr else None, default) for i in indices)
    return tuple(entries)


def update_geometry(context, recalculate=False):
    for geometry in geometries(context):
        if recalculate:
            bounds=offsets(geometry)
            types=read_attr(geometry,'curve_type',max(0,len(bounds)-1),0)
            left_attr=geometry.attributes.get('handle_left')
            right_attr=geometry.attributes.get('handle_right')
            if left_attr is not None and right_attr is not None:
                count=bounds[-1]
                positions=read_attr(geometry,'position',count,(0,0,0),'vector')
                left=read_attr(geometry,'handle_left',count,(0,0,0),'vector')
                right=read_attr(geometry,'handle_right',count,(0,0,0),'vector')
                tl=read_attr(geometry,'handle_type_left',count,0)
                tr=read_attr(geometry,'handle_type_right',count,0)
                cyclic=read_attr(geometry,'cyclic',len(types),False)
                for c,kind in enumerate(types):
                    if kind != 2:
                        continue
                    a,b=bounds[c:c+2]
                    new_left,new_right=calculate_auto_handles(cyclic[c],tl[a:b],tr[a:b],positions[a:b],left[a:b],right[a:b])
                    for i in range(a,b):
                        if new_left[i-a] != left[i]:
                            left_attr.data[i].vector=new_left[i-a]
                        if new_right[i-a] != right[i]:
                            right_attr.data[i].vector=new_right[i-a]
        if hasattr(geometry,'tag_positions_changed'):
            geometry.tag_positions_changed()
    context.active_object.data.update_tag()
