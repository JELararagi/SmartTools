"""Popup-only native-equivalent Item fields for Smart Transform.

This module owns no registration. Object/bone fields bind public RNA directly;
edit-selection proxies are computed RNA on the active geometry ID and write
selected data through public RNA/BMesh only.
Native Undo and visible-field equivalence require independent GUI acceptance.
"""

import bpy
import bmesh
from mathutils import Vector
from ..translation import TI
from .item_popup_edit import bounded_values, additive_values, skin_values, bone_collection_visible
from .item_popup_edit import legacy_translate, legacy_project_2d
from . import item_popup_curves as _curves


def _label(layout, text, *, icon='NONE'):
    layout.label(text=bpy.app.translations.pgettext(text), icon=icon)


def _prop(layout, owner, name, *, text=None, expand=False, active=True):
    """Draw one public RNA property; missing required fields fail visibly."""
    if owner is None:
        return False
    # Operator custom fields live on its public OperatorProperties RNA.
    # Do not probe owner.<field> here: that would invoke its getter during draw.
    is_operator = isinstance(owner, bpy.types.Operator)
    rna_owner = owner.properties if is_operator else owner
    rna = getattr(rna_owner, 'bl_rna', None)
    prop = rna.properties.get(name) if rna is not None else None
    if prop is None:
        if is_operator:
            raise AttributeError(f'Missing popup RNA property {type(owner).__name__}.{name}')
        return False
    # A column keeps the native W/X/Y/Z labels readable for four components.
    row = (layout.column(align=True) if name in {'rotation_quaternion', 'rotation_axis_angle'}
           else layout.row())
    row.active = bool(active)
    kwargs = {}
    if text is not None:
        kwargs['text'] = text
    if expand:
        kwargs['expand'] = True
    row.prop(owner, name, **kwargs)
    return True


def _lock_row(layout, owner, name, *, text='Lock', active=True):
    if owner is None or not hasattr(owner, name):
        return False
    row = layout.row(align=True)
    row.active = bool(active)
    row.prop(owner, name, text=text, expand=True)
    return True


def _draw_rotation(layout, owner, *, label='Rotation', active=True):
    if owner is None:
        return
    _label(layout, label)
    mode = str(getattr(owner, 'rotation_mode', 'XYZ') or 'XYZ')
    if mode == 'QUATERNION':
        _prop(layout, owner, 'rotation_quaternion', text=TI('Rotation', '回転'))
    elif mode == 'AXIS_ANGLE':
        _prop(layout, owner, 'rotation_axis_angle', text=TI('Rotation', '回転'))
    else:
        _prop(layout, owner, 'rotation_euler', text=TI('Rotation', '回転'))
    if mode in {'QUATERNION', 'AXIS_ANGLE'}:
        _prop(layout, owner, 'lock_rotations_4d', text=TI('4L', '4L'), active=active)
        if bool(getattr(owner, 'lock_rotations_4d', False)):
            _prop(layout, owner, 'lock_rotation_w', text=TI('Lock W', 'Wをロック'), active=active)
    _lock_row(layout, owner, 'lock_rotation', text=TI('Lock', 'ロック'), active=active)
    _prop(layout, owner, 'rotation_mode', text='')


def _draw_scale(layout, owner, *, active=True):
    _prop(layout, owner, 'scale', text=TI('Scale', 'スケール'), active=active)
    _lock_row(layout, owner, 'lock_scale', text=TI('Lock', 'ロック'), active=active)


def _draw_object(layout, obj):
    _prop(layout, obj, 'location', text=TI('Location', '位置'))
    _lock_row(layout, obj, 'lock_location', text=TI('Lock', 'ロック'))
    _draw_rotation(layout, obj)
    _draw_scale(layout, obj)
    # Blender's Object panel exposes dimensions only where the RNA property is
    # present; do not synthesize it for unsupported data types.
    if getattr(obj, 'type', None) in {
        'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'ARMATURE',
        'LATTICE', 'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL',
    }:
        _prop(layout, obj, 'dimensions', text=TI('Dimensions', '寸法'))


def _draw_pose_bone(layout, obj, pb):
    bone = getattr(pb, 'bone', None)
    if bone is None or not _bone_visible(bone, obj.data):
        _label(layout, TI('No Bone Active', 'アクティブなボーンがありません'))
        return
    connected = bool(getattr(bone, 'use_connect', False) and getattr(bone, 'parent', None) is not None)
    _prop(layout, pb, 'location', text=TI('Location', '位置'), active=not connected)
    _lock_row(layout, pb, 'lock_location', text=TI('Lock', 'ロック'), active=not connected)
    _draw_rotation(layout, pb, label='Rotation')
    _draw_scale(layout, pb)


def _draw_edit_bone(layout, obj, eb):
    parent = getattr(eb, 'parent', None)
    connected = bool(getattr(eb, 'use_connect', False))
    _prop(layout, eb, 'head')
    if connected and parent is not None and hasattr(parent, 'tail_radius'):
        _prop(layout, parent, 'tail_radius', text=TI('Radius (Parent)', '半径（親）'))
    else:
        _prop(layout, eb, 'head_radius', text=TI('Radius', '半径'))
    _prop(layout, eb, 'tail')
    _prop(layout, eb, 'tail_radius', text=TI('Radius', '半径'))
    _prop(layout, eb, 'roll')
    _prop(layout, eb, 'length')
    _prop(layout, eb, 'envelope_distance', text=TI('Envelope', 'エンベロープ'))


def _bone_visible(bone, armature):
    return bone_collection_visible(bone, armature)


def _draw_metaball(layout, obj):
    element = getattr(getattr(obj, 'data', None), 'elements', None)
    active = getattr(element, 'active', None) if element is not None else None
    if active is None:
        _label(layout, TI('Nothing selected', '何も選択されていません'))
        return
    for name in ('co', 'radius', 'stiffness', 'type'):
        _prop(layout, active, name)
    kind = str(getattr(active, 'type', 'BALL'))
    size_names = {'CUBE': ('size_x', 'size_y', 'size_z'),
                  'CAPSULE': ('size_x',), 'PLANE': ('size_x', 'size_y'),
                  'ELLIPSOID': ('size_x', 'size_y', 'size_z')}.get(kind, ())
    for name in size_names:
        _prop(layout, active, name)


def _selected_edit_points(context):
    """Return selected local-space coordinate owners without selecting data."""
    obj = getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'mode', None) != 'EDIT':
        return (), None
    if obj.type == 'MESH':
        bm = bmesh.from_edit_mesh(obj.data)
        return tuple((vert, 'co') for vert in bm.verts if vert.select), bm
    if obj.type in {'CURVE', 'SURFACE'}:
        points = []
        for spline in obj.data.splines:
            if spline.type == 'BEZIER':
                for point in spline.bezier_points:
                    if point.select_control_point:
                        points.append((point, 'co'))
                    else:
                        if point.select_left_handle:
                            points.append((point, 'handle_left'))
                        if point.select_right_handle:
                            points.append((point, 'handle_right'))
            else:
                points.extend((point, 'co') for point in spline.points if point.select)
        return tuple(points), None
    if obj.type == 'LATTICE':
        return tuple((point, 'co_deform') for point in obj.data.points if point.select), None
    if obj.type in {'CURVES','GREASEPENCIL'}:
        return _curves.coordinate_entries(context), None
    return (), None


def _point_location(item):
    owner, attr = item
    return Vector(getattr(owner, attr)[:3])


def get_edit_median_location(global_space=False):
    points, _bm = _selected_edit_points(bpy.context)
    if not points:
        return (0.0, 0.0, 0.0)
    result = sum((_point_location(point) for point in points), Vector((0, 0, 0))) / len(points)
    if global_space:
        result = bpy.context.active_object.matrix_world @ result
    return tuple(result)


def set_edit_median_location(value, global_space=False):
    context = bpy.context
    obj = getattr(context, 'active_object', None)
    points, bm = _selected_edit_points(context)
    if not points or obj is None:
        return
    target = Vector(value)
    if global_space:
        target = obj.matrix_world.inverted_safe() @ target
    delta = target - Vector(get_edit_median_location())
    if not any(abs(v) > 1.0e-10 for v in delta):
        return
    if obj.type in {'CURVE','SURFACE'}:
        legacy_translate(obj.data,delta)
        return
    for point, attr in points:
        current = getattr(point, attr).copy()
        if len(current) == 4:
            setattr(point, attr, (*tuple(Vector(current[:3]) + delta), current[3]))
        else:
            setattr(point, attr, current + delta)
        if attr == 'co' and hasattr(point, 'handle_left') and hasattr(point, 'handle_right'):
            point.handle_left = point.handle_left + delta
            point.handle_right = point.handle_right + delta
    if bm is not None:
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    elif obj.type in {'CURVES','GREASEPENCIL'}:
        # Item writes selected positions/handles raw, then recomputes AUTO/VECTOR.
        # set_handle_position is intentionally not substituted here: that API
        # aligns the opposite handle while Item's median code does not.
        _curves.update_geometry(context,recalculate=True)
    else:
        obj.data.update_tag()


def _scalar_owners(field, *, create=False):
    context = bpy.context
    obj = getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'mode', None) != 'EDIT':
        return (), None, None
    if obj.type == 'MESH' and field in {'bevel_vertex', 'crease_vertex', 'bevel_edge', 'crease_edge'}:
        bm = bmesh.from_edit_mesh(obj.data)
        domain = bm.verts if field.endswith('vertex') else bm.edges
        layers = bm.verts.layers.float if field.endswith('vertex') else bm.edges.layers.float
        layer_name = {'bevel_vertex': 'bevel_weight_vert', 'crease_vertex': 'crease_vert',
                      'bevel_edge': 'bevel_weight_edge', 'crease_edge': 'crease_edge'}[field]
        layer = layers.get(layer_name)
        if layer is None and create:
            layer = layers.new(layer_name)
        if layer is None:
            return (), bm, None
        return tuple(item for item in domain if item.select), bm, layer
    points, _ = _selected_edit_points(context)
    centers = tuple(point for point, attr in points if attr in {'co', 'co_deform'})
    if field in {'radius', 'tilt', 'weight_softbody'}:
        return tuple(point for point in centers if hasattr(point, field)), None, field
    if field == 'nurbs_w':
        return tuple(point for point in centers if hasattr(point, 'co') and len(point.co) == 4), None, 'nurbs_w'
    return (), None, None


def get_edit_median_scalar(field):
    obj=bpy.context.active_object
    if obj is not None and obj.type in {'CURVES','GREASEPENCIL'}:
        entries=_curves.scalar_entries(bpy.context,field)
        return sum(float(v.value if v is not None else default) for v,default in entries)/len(entries) if entries else 0.0
    owners, _bm, key = _scalar_owners(field)
    if not owners or key is None:
        return 0.0
    if key == 'nurbs_w':
        return sum(float(point.co[3]) for point in owners) / len(owners)
    return sum(float(point[key] if not isinstance(key, str) else getattr(point, key)) for point in owners) / len(owners)


def set_edit_median_scalar(field, value):
    obj = getattr(bpy.context, 'active_object', None)
    if obj is not None and obj.type in {'CURVES','GREASEPENCIL'}:
        before=_curves.scalar_entries(bpy.context,field)
        if not before:
            return
        values=[v.value if v is not None else default for v,default in before]
        if float(value) == sum(values)/len(values):
            return
        entries=_curves.scalar_entries(bpy.context,field,create=True)
        updates=additive_values(values,float(value),len(_selected_edit_points(bpy.context)[0]))
        for (owner,_),updated in zip(entries,updates):
            owner.value=max(.01,min(100.0,updated)) if field=='nurbs_w' else updated
        _curves.update_geometry(bpy.context)
        return
    owners, bm, key = _scalar_owners(field, create=True)
    if not owners or key is None or obj is None:
        return
    old = get_edit_median_scalar(field)
    desired = float(value)
    if abs(desired - old) <= 1.0e-10:
        return
    values = tuple(float(point.co[3] if key == 'nurbs_w' else
                         (getattr(point, key) if isinstance(key, str) else point[key]))
                   for point in owners)
    # Native Item passes total selected coordinate count, not scalar-owner count.
    total = len(_selected_edit_points(bpy.context)[0])
    if field in {'bevel_vertex', 'crease_vertex', 'bevel_edge', 'crease_edge', 'weight_softbody'}:
        updates = bounded_values(values, desired, total)
    else:
        updates = additive_values(values, desired, total)
    for point, updated in zip(owners, updates):
        if key == 'nurbs_w':
            co = point.co.copy()
            co[3] = updated
            point.co = co
        elif isinstance(key, str):
            setattr(point, key, updated)
        else:
            point[key] = updated
    if bm is not None:
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    else:
        if obj.type in {'CURVE','SURFACE'}:
            legacy_project_2d(obj.data)
        obj.data.update_tag()


def get_skin_radius(axis):
    obj=bpy.context.active_object
    if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
        return 0.0
    bm=bmesh.from_edit_mesh(obj.data)
    layer=bm.verts.layers.skin.active
    values=[v[layer].radius[axis] for v in bm.verts if v.select] if layer else []
    return sum(values)/len(values) if values else 0.0


def set_skin_radius(axis,value):
    obj=bpy.context.active_object
    if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
        return
    bm=bmesh.from_edit_mesh(obj.data)
    layer=bm.verts.layers.skin.active
    if layer is None:
        return
    vertices=[v for v in bm.verts if v.select]
    values=[v[layer].radius[axis] for v in vertices]
    for vertex,new in zip(vertices,skin_values(values,value)):
        radius=list(vertex[layer].radius)
        radius[axis]=new
        vertex[layer].radius=radius
    bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)


def _draw_edit_selection(layout, context, popup):
    points, _bm = _selected_edit_points(context)
    mesh_edges = bool(_bm is not None and any(edge.select for edge in _bm.edges))
    if not points and not mesh_edges:
        _label(layout, TI('Nothing selected', '何も選択されていません'))
        return
    if points:
        _label(layout, TI('Median', '中点') if len(points) > 1 else TI('Vertex', '頂点'))
        _prop(layout, popup, 'sts_popup_edit_median_location', text=TI('Location', '位置'))
        _prop(layout, popup, 'sts_popup_edit_global_space', text=TI('Global', 'グローバル'))
    if len(points) == 1 and context.active_object.type in {'CURVE', 'SURFACE', 'LATTICE'}:
        point, attr = points[0]
        if attr in {'co', 'co_deform'}:
            for name in ('weight_softbody', 'radius', 'tilt'):
                _prop(layout, point, name)
            if hasattr(point, 'weight'):
                _prop(layout, point, 'weight', text=TI('W', 'W'))
    elif context.active_object.type in {'CURVE', 'SURFACE', 'LATTICE','CURVES','GREASEPENCIL'}:
        for prop, label in (('edit_mean_weight', TI('Mean Weight', '平均ウェイト')),
                            ('edit_mean_radius', TI('Mean Radius', '平均半径')),
                            ('edit_mean_tilt', TI('Mean Tilt', '平均傾斜')),
                            ('edit_mean_nurbs_w', TI('W', 'W'))):
            field = {'edit_mean_weight': 'weight_softbody', 'edit_mean_radius': 'radius',
                     'edit_mean_tilt': 'tilt', 'edit_mean_nurbs_w': 'nurbs_w'}[prop]
            if (_curves.scalar_entries(context,field) if context.active_object.type in {'CURVES','GREASEPENCIL'} else _scalar_owners(field)[0]):
                _prop(layout, popup, 'sts_popup_' + prop, text=label)
    if context.active_object.type == 'MESH':
        bm = bmesh.from_edit_mesh(context.active_object.data)
        edges = tuple(edge for edge in bm.edges if edge.select)
        if points:
            multiple = len(points) > 1
            _label(layout, TI('Vertices Data', '頂点データ') if multiple
                   else TI('Vertex Data', '頂点データ'))
            _prop(layout, popup, 'sts_popup_edit_bevel_vertex',
                  text=(TI('Mean Bevel Weight', '平均ベベルウェイト') if multiple
                        else TI('Bevel Weight', 'ベベルウェイト')))
            _prop(layout, popup, 'sts_popup_edit_crease_vertex',
                  text=(TI('Mean Vertex Crease', '平均頂点クリース') if multiple
                        else TI('Vertex Crease', '頂点クリース')))
            if bm.verts.layers.skin.active is not None:
                _prop(layout, popup, 'sts_popup_edit_skin_x',
                      text=(TI('Mean Radius X', '平均半径X') if multiple
                            else TI('Radius X', '半径X')))
                _prop(layout, popup, 'sts_popup_edit_skin_y',
                      text=(TI('Mean Radius Y', '平均半径Y') if multiple
                            else TI('Radius Y', '半径Y')))
        if edges:
            multiple = len(edges) > 1
            _label(layout, TI('Edges Data', '辺データ') if multiple
                   else TI('Edge Data', '辺データ'))
            _prop(layout, popup, 'sts_popup_edit_bevel_edge',
                  text=(TI('Mean Bevel Weight', '平均ベベルウェイト') if multiple
                        else TI('Bevel Weight', 'ベベルウェイト')))
            _prop(layout, popup, 'sts_popup_edit_crease_edge',
                  text=(TI('Mean Crease', '平均クリース') if multiple
                        else TI('Crease', 'クリース')))


def draw_item_popup(layout, context, popup=None):
    """Draw the supported native Item contexts without selecting fallback data."""
    obj = getattr(context, 'active_object', None)
    if obj is None:
        _label(layout, TI('No active transform target.', 'アクティブな変形対象がありません。'))
        return
    mode = str(getattr(obj, 'mode', '') or '')
    if getattr(obj, 'type', None) == 'ARMATURE' and mode == 'EDIT':
        edit_bones = getattr(obj.data, 'edit_bones', None)
        eb = getattr(edit_bones, 'active', None) if edit_bones is not None else None
        # Native v3d_editarmature_buts tests collection visibility only.
        if eb is None or not bone_collection_visible(eb, obj.data):
            _label(layout, TI('Nothing selected', '何も選択されていません'))
        else:
            _draw_edit_bone(layout, obj, eb)
        return
    if getattr(obj, 'type', None) == 'META' and mode == 'EDIT':
        _draw_metaball(layout, obj)
        return
    if mode == 'EDIT' and getattr(obj, 'type', None) in {'MESH', 'CURVE', 'SURFACE', 'LATTICE','CURVES','GREASEPENCIL'}:
        _draw_edit_selection(layout, context, obj.data)
        return
    if getattr(obj, 'type', None) == 'ARMATURE' and mode == 'POSE':
        active = obj.data.bones.active
        pb = obj.pose.bones.get(active.name) if active else None
        if pb is None:
            _label(layout, TI('No Bone Active', 'アクティブなボーンがありません'))
        else:
            _draw_pose_bone(layout, obj, pb)
        return
    if mode != 'EDIT' and mode != 'POSE':
        _draw_object(layout, obj)
        return
    _label(layout, TI('Nothing selected', '何も選択されていません'))
