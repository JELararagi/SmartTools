# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Supplemental UI translations for static source labels."""

EXTRA_TRANSLATIONS = {
    ('*', 'Apply one of the preset interaction profiles to the add-on preferences'): 'プリセットの操作設定をアドオンの設定へ適用します。',
    ('*', 'Display lazy-loaded Smart Transform help.'): 'Smart Transform のヘルプを表示します。',
    ('*', 'Percent snap step for Scale mode when holding X. Example: 0.1 = 10% steps.'): 'スケール中に X を押している間のパーセント刻みです。例：0.1 = 10% 刻み。',
    ('*', 'Reset the current field to its neutral value. Scale returns to 1.0, while location, rotation, and delta offsets return to 0.0'): '現在の入力欄を中立値へ戻します。スケールは 1.0、位置・回転・Δオフセットは 0.0 に戻ります。',
    ('*', 'Smart Transform Help'): 'Smart Transform のヘルプ',
    ('*', "Start the add-on's Smart Move, Rotate, or Scale workflow with HUD, snapping helpers, axis memory, and numeric input"): 'HUD・スナップ補助・軸の記憶・数値入力の付いたスマート移動・回転・拡大縮小を開始します。',
}
