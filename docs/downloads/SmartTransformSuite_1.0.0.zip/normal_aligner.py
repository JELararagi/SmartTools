# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Selected-vertex normal alignment tools integrated into Smart Transform Suite.

The operator keeps the source add-on's two independent operations:

* move/rotate the active mesh object's origin to the average selected vertex
  position/normal while preserving the visible world-space mesh shape;
* create or overwrite a custom transform orientation named ``VertexNormal``.

No standalone panel and no automatic keymap entries are created.  The Smart
Transform N-panel owns the settings and exposes the manual keymap ID.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterable

import bpy
import bmesh
from mathutils import Matrix, Vector

from . import runtime as _runtime
from .translation import TI


_ORIENTATION_NAME = "VertexNormal"
_TEMP_OBJECT_PREFIX = "__STS_VertexNormal_Temp__"
_EPSILON = 1.0e-12
_REGISTERED = False


def _prefs(context=None):
    try:
        return _runtime.get_addon_preferences(
            context or getattr(bpy, "context", None),
            __package__,
            __name__,
            __file__,
        )
    except Exception:
        return None


def _view3d_area_and_window_region(context):
    """Return a VIEW_3D area and WINDOW region suitable for Blender operators."""
    area = getattr(context, "area", None)
    if area is None or getattr(area, "type", None) != "VIEW_3D":
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None) if window is not None else None
        for candidate in tuple(getattr(screen, "areas", ()) or ()):
            if getattr(candidate, "type", None) == "VIEW_3D":
                area = candidate
                break
    if area is None or getattr(area, "type", None) != "VIEW_3D":
        return None, None

    region = getattr(context, "region", None)
    if region is None or getattr(region, "type", None) != "WINDOW" or region not in tuple(getattr(area, "regions", ()) or ()):
        region = None
        for candidate in tuple(getattr(area, "regions", ()) or ()):
            if getattr(candidate, "type", None) == "WINDOW":
                region = candidate
                break
    return area, region


@contextmanager
def _view3d_operator_override(context):
    """Use the 3D View WINDOW region even when invoked from its N-panel UI."""
    area, region = _view3d_area_and_window_region(context)
    temp_override = getattr(context, "temp_override", None)
    if area is None or region is None or not callable(temp_override):
        yield
        return

    kwargs = {"area": area, "region": region}
    for name in ("window", "screen", "scene", "view_layer"):
        value = getattr(context, name, None)
        if value is not None:
            kwargs[name] = value

    manager = temp_override(**kwargs)
    entered = False
    try:
        manager.__enter__()
        entered = True
        yield
    except BaseException as exc:
        if entered:
            suppress = bool(manager.__exit__(type(exc), exc, exc.__traceback__))
            entered = False
            if suppress:
                return
        raise
    finally:
        if entered:
            manager.__exit__(None, None, None)


def _selected_object_names(view_layer) -> tuple[str, ...]:
    names: list[str] = []
    for obj in tuple(getattr(view_layer, "objects", ()) or ()):
        try:
            if obj.select_get():
                names.append(str(obj.name))
        except Exception:
            continue
    return tuple(names)


def _deselect_view_layer_objects(view_layer) -> None:
    for obj in tuple(getattr(view_layer, "objects", ()) or ()):
        try:
            if obj.select_get():
                obj.select_set(False)
        except Exception:
            pass


def _restore_object_selection(view_layer, selected_names: Iterable[str], active_name: str) -> None:
    _deselect_view_layer_objects(view_layer)
    for name in tuple(selected_names or ()):
        try:
            obj = view_layer.objects.get(str(name))
        except Exception:
            obj = None
        if obj is not None:
            try:
                obj.select_set(True)
            except Exception:
                pass
    try:
        active = view_layer.objects.get(str(active_name)) if active_name else None
    except Exception:
        active = None
    if active is not None:
        try:
            active.select_set(True)
        except Exception:
            pass
        try:
            view_layer.objects.active = active
        except Exception:
            pass


def _set_only_active_object(view_layer, obj) -> None:
    _deselect_view_layer_objects(view_layer)
    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        view_layer.objects.active = obj
    except Exception:
        pass


def _mode_set(context, mode: str) -> bool:
    try:
        with _view3d_operator_override(context):
            result = bpy.ops.object.mode_set(mode=mode)
        return "FINISHED" in set(result or ())
    except Exception:
        return False


def _create_orientation(context, *, name: str) -> bool:
    try:
        with _view3d_operator_override(context):
            result = bpy.ops.transform.create_orientation(name=name, use=True, overwrite=True)
        return "FINISHED" in set(result or ())
    except Exception:
        return False


def _transform_mesh_preserving_shape_keys(mesh, matrix: Matrix) -> None:
    """Transform base mesh and shape keys when Blender exposes that option."""
    try:
        mesh.transform(matrix, shape_keys=True)
    except TypeError:
        mesh.transform(matrix)
    mesh.update()


def _selected_average_local_position_and_normal(obj) -> tuple[Vector, Vector, int]:
    bm = bmesh.from_edit_mesh(obj.data)
    try:
        bm.normal_update()
    except Exception:
        pass
    selected = [vert for vert in bm.verts if bool(getattr(vert, "select", False)) and not bool(getattr(vert, "hide", False))]
    if not selected:
        return Vector((0.0, 0.0, 0.0)), Vector((0.0, 0.0, 0.0)), 0

    position = Vector((0.0, 0.0, 0.0))
    normal = Vector((0.0, 0.0, 0.0))
    for vert in selected:
        position += vert.co
        normal += vert.normal
    count = len(selected)
    position /= float(count)
    return position, normal, count


def _world_normal_from_local(matrix_world: Matrix, local_normal: Vector) -> Vector:
    try:
        normal_matrix = matrix_world.to_3x3().inverted_safe().transposed()
        world_normal = normal_matrix @ local_normal
    except Exception:
        world_normal = matrix_world.to_3x3() @ local_normal
    if world_normal.length_squared > _EPSILON:
        world_normal.normalize()
    return world_normal


def _new_object_matrix(position: Vector, normal: Vector, old_matrix: Matrix) -> Matrix:
    rotation = normal.to_track_quat("Z", "Y").to_matrix().to_4x4()
    try:
        decomposed_scale = old_matrix.to_scale()
        scale = Vector((abs(float(decomposed_scale.x)), abs(float(decomposed_scale.y)), abs(float(decomposed_scale.z))))
        if float(old_matrix.to_3x3().determinant()) < 0.0:
            scale.x = -scale.x
    except Exception:
        scale = Vector((1.0, 1.0, 1.0))
    scale_matrix = Matrix.Diagonal((float(scale.x), float(scale.y), float(scale.z), 1.0))
    return Matrix.Translation(position) @ rotation @ scale_matrix


def _activate_custom_orientation(scene, name: str) -> bool:
    try:
        slots = getattr(scene, "transform_orientation_slots", None)
        if slots and len(slots) > 0:
            slots[0].type = str(name)
            return True
    except Exception:
        pass
    return False


class MESH_OT_smart_align_to_vertex_normal(bpy.types.Operator):
    """Align the object pivot and/or custom orientation to selected vertex normals."""

    bl_idname = "mesh.smart_align_to_vertex_normal"
    bl_label = TI("Align to Selected Vertex Normal", "選択頂点法線に合わせる")
    bl_description = TI(
        "Use the average position and average normal of the selected, visible Edit Mesh vertices. Depending on the N-panel settings, move and rotate the active object's pivot while preserving the visible mesh shape, create or overwrite the VertexNormal custom transform orientation, or perform both operations. The operator returns to Edit Mode and restores the original object selection.",
        "メッシュ編集で選択中かつ表示中の頂点について、平均位置と平均法線を使用します。Nパネル設定に応じて、見た目のメッシュ形状を維持したままアクティブオブジェクトのピボットを移動・回転し、カスタムトランスフォーム座標系「VertexNormal」を作成または上書きするか、その両方を実行します。処理後は編集モードへ戻り、元のオブジェクト選択を復元します。",
    )
    bl_options = {'UNDO'}
    bl_undo_group = "Smart Transform Suite"

    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None)
        obj = getattr(context, "active_object", None)
        ok = bool(
            area is not None
            and getattr(area, "type", None) == "VIEW_3D"
            and obj is not None
            and getattr(obj, "type", None) == "MESH"
            and getattr(obj, "mode", None) == "EDIT"
            and getattr(getattr(obj, "data", None), "is_editmode", False)
        )
        if not ok:
            try:
                cls.poll_message_set(
                    TI(
                        "Open a 3D View, select a mesh object, enter Edit Mode, and select one or more vertices, edges, or faces.",
                        "3Dビューでメッシュオブジェクトを選択して編集モードに入り、頂点・辺・面を1つ以上選択してください。",
                    )
                )
            except Exception:
                pass
        return ok

    def execute(self, context):
        prefs = _prefs(context)
        use_pivot = bool(getattr(prefs, "normal_align_use_pivot", True)) if prefs is not None else True
        use_orientation = bool(getattr(prefs, "normal_align_use_orientation", True)) if prefs is not None else True

        if not use_pivot and not use_orientation:
            self.report(
                {"WARNING"},
                TI(
                    "Enable Align Object Pivot, Create Custom Orientation, or both in the Normal Aligner settings.",
                    "法線アライナー設定で「オブジェクトピボットを合わせる」「カスタム座標系を作成」のどちらか一方、または両方を有効にしてください。",
                ),
            )
            return {"CANCELLED"}

        obj = getattr(context, "active_object", None)
        if obj is None or getattr(obj, "type", None) != "MESH" or getattr(obj, "mode", None) != "EDIT":
            self.report(
                {"ERROR"},
                TI(
                    "Select a mesh object and run this tool in Edit Mode.",
                    "メッシュオブジェクトを選択し、編集モードでこのツールを実行してください。",
                ),
            )
            return {"CANCELLED"}

        try:
            local_position, local_normal, selected_count = _selected_average_local_position_and_normal(obj)
        except Exception:
            self.report(
                {"ERROR"},
                TI(
                    "The selected vertex data could not be read.",
                    "選択頂点データを取得できませんでした。",
                ),
            )
            return {"CANCELLED"}

        if selected_count <= 0:
            self.report(
                {"ERROR"},
                TI(
                    "Select one or more visible mesh vertices, edges, or faces.",
                    "表示中のメッシュ頂点・辺・面を1つ以上選択してください。",
                ),
            )
            return {"CANCELLED"}

        if local_normal.length_squared <= _EPSILON:
            self.report(
                {"ERROR"},
                TI(
                    "The averaged selected vertex normal has zero length. Select vertices whose normals do not cancel each other.",
                    "選択頂点の平均法線がゼロ長になっています。法線同士が打ち消し合わない頂点を選択してください。",
                ),
            )
            return {"CANCELLED"}
        local_normal.normalize()

        matrix_world_old = obj.matrix_world.copy()
        world_position = matrix_world_old @ local_position
        world_normal = _world_normal_from_local(matrix_world_old, local_normal)
        if world_normal.length_squared <= _EPSILON:
            self.report(
                {"ERROR"},
                TI(
                    "The selected normal could not be converted to world space.",
                    "選択法線をワールド空間へ変換できませんでした。",
                ),
            )
            return {"CANCELLED"}

        view_layer = getattr(context, "view_layer", None)
        if view_layer is None:
            self.report({"ERROR"}, TI("The current View Layer is unavailable.", "現在のビューレイヤーを取得できません。"))
            return {"CANCELLED"}

        try:
            active_before = getattr(view_layer.objects, "active", None) or obj
            original_active_name = str(getattr(active_before, "name", "") or getattr(obj, "name", ""))
        except Exception:
            original_active_name = str(getattr(obj, "name", "") or "")
        original_selected_names = _selected_object_names(view_layer)
        temp_object = None
        success = False
        error_message = ""
        pivot_applied = False
        pivot_data_transform = None
        original_mesh_data = obj.data
        isolated_mesh_data = None

        try:
            if not _mode_set(context, "OBJECT"):
                raise RuntimeError(TI("Could not leave Edit Mode.", "編集モードを終了できませんでした。"))

            if use_pivot:
                if int(getattr(obj.data, "users", 1) or 1) > 1:
                    isolated_mesh_data = obj.data.copy()
                    obj.data = isolated_mesh_data
                new_matrix = _new_object_matrix(world_position, world_normal, matrix_world_old)
                try:
                    data_transform = new_matrix.inverted_safe() @ matrix_world_old
                except Exception:
                    data_transform = new_matrix.inverted() @ matrix_world_old
                _transform_mesh_preserving_shape_keys(obj.data, data_transform)
                obj.matrix_world = new_matrix
                pivot_data_transform = data_transform.copy()
                pivot_applied = True
                try:
                    context.view_layer.update()
                except Exception:
                    pass

            if use_orientation:
                if use_pivot:
                    _set_only_active_object(view_layer, obj)
                else:
                    temp_object = bpy.data.objects.new(_TEMP_OBJECT_PREFIX, None)
                    collection = getattr(context, "collection", None)
                    if collection is None:
                        collection = getattr(getattr(context, "scene", None), "collection", None)
                    if collection is None:
                        raise RuntimeError(TI("No writable collection is available for the temporary orientation helper.", "一時座標系ヘルパーをリンクできるコレクションがありません。"))
                    collection.objects.link(temp_object)
                    temp_object.matrix_world = Matrix.Translation(world_position) @ world_normal.to_track_quat("Z", "Y").to_matrix().to_4x4()
                    _set_only_active_object(view_layer, temp_object)

                if not _create_orientation(context, name=_ORIENTATION_NAME):
                    raise RuntimeError(
                        TI(
                            "Blender could not create the VertexNormal custom transform orientation.",
                            "Blenderでカスタムトランスフォーム座標系「VertexNormal」を作成できませんでした。",
                        )
                    )
                if not _activate_custom_orientation(getattr(context, "scene", None), _ORIENTATION_NAME):
                    raise RuntimeError(
                        TI(
                            "The VertexNormal orientation was created, but it could not be made active.",
                            "「VertexNormal」座標系は作成されましたが、アクティブに切り替えられませんでした。",
                        )
                    )

            success = True
        except Exception as exc:
            error_message = str(exc)
        finally:
            if temp_object is not None:
                try:
                    bpy.data.objects.remove(temp_object, do_unlink=True)
                except Exception:
                    pass
            if not success and isolated_mesh_data is not None:
                try:
                    obj.data = original_mesh_data
                    bpy.data.meshes.remove(isolated_mesh_data)
                    isolated_mesh_data = None
                    obj.matrix_world = matrix_world_old
                    pivot_applied = False
                except Exception:
                    pass
            elif not success and pivot_applied and pivot_data_transform is not None:
                try:
                    rollback = pivot_data_transform.inverted_safe()
                    _transform_mesh_preserving_shape_keys(obj.data, rollback)
                    obj.matrix_world = matrix_world_old
                    pivot_applied = False
                except Exception:
                    pass
            _restore_object_selection(view_layer, original_selected_names, original_active_name)
            try:
                if getattr(obj, "name", "") in view_layer.objects:
                    obj.select_set(True)
                    view_layer.objects.active = obj
            except Exception:
                pass
            if getattr(obj, "name", "") in bpy.data.objects:
                if not _mode_set(context, "EDIT") and success:
                    success = False
                    error_message = TI(
                        "The alignment finished, but Blender could not return the object to Edit Mode.",
                        "整列処理は完了しましたが、Blenderでオブジェクトを編集モードへ戻せませんでした。",
                    )
            try:
                for area in tuple(getattr(getattr(context, "screen", None), "areas", ()) or ()):
                    if getattr(area, "type", None) in {"VIEW_3D", "PROPERTIES", "OUTLINER"}:
                        area.tag_redraw()
            except Exception:
                pass

        if not success:
            self.report(
                {"ERROR"},
                error_message
                or TI(
                    "The selected-normal alignment operation failed.",
                    "選択法線への整列処理に失敗しました。",
                ),
            )
            return {"CANCELLED"}

        if use_pivot and use_orientation:
            message = TI(
                f"Aligned the pivot and VertexNormal orientation using {selected_count} selected vertices.",
                f"選択頂点{selected_count}個の平均法線に、ピボットと「VertexNormal」座標系を合わせました。",
            )
        elif use_pivot:
            message = TI(
                f"Aligned the pivot using {selected_count} selected vertices.",
                f"選択頂点{selected_count}個の平均法線にピボットを合わせました。",
            )
        else:
            message = TI(
                f"Created the VertexNormal orientation using {selected_count} selected vertices.",
                f"選択頂点{selected_count}個の平均法線から「VertexNormal」座標系を作成しました。",
            )
        self.report({"INFO"}, message)
        return {"FINISHED"}


_CLASSES = (MESH_OT_smart_align_to_vertex_normal,)


def register():
    global _REGISTERED
    if _REGISTERED:
        return
    registered: list[type] = []
    try:
        for cls in _CLASSES:
            existing = getattr(bpy.types, cls.__name__, None)
            if isinstance(existing, type):
                try:
                    bpy.utils.unregister_class(existing)
                except Exception:
                    pass
            bpy.utils.register_class(cls)
            registered.append(cls)
    except Exception:
        for cls in reversed(registered):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        raise
    _REGISTERED = True


def unregister():
    global _REGISTERED
    for cls in reversed(_CLASSES):
        existing = getattr(bpy.types, cls.__name__, None)
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    _REGISTERED = False
