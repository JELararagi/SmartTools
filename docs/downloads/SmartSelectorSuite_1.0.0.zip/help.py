# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Click-loaded help popups for Smart Selector.

This module is deliberately not imported during add-on registration or normal
N-panel drawing.  The lightweight operator in ui imports it only after a
Help button is invoked.
"""

from __future__ import annotations

import ast
import re
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Iterable, Sequence

import bpy

try:
    from .translation import t as _suite_translate
except Exception:  # pragma: no cover - fallback outside Blender
    def _suite_translate(text: object, ja: object | None = None, context=None) -> str:
        return str(ja if ja is not None and _is_ja() else text or '')


try:
    import blf as _blf
except Exception:  # pragma: no cover - Blender-only module outside Blender
    _blf = None

_SPACE_RE = re.compile(r"\s+")

# The help popup itself is opened at this width from ui.py. Text wrapping is not
# based on a fixed number of characters; it is calculated from the available
# popup width and the measured UI text width. Labels that fit on one line are
# kept on one line, and wrapping is applied only when the rendered text would
# exceed the popup body.
_HELP_DIALOG_WIDTH = 820
_HELP_TEXT_WIDTH_PX = 704
_HELP_HORIZONTAL_PADDING_PX = 116
_HELP_ICON_RESERVED_PX = 28
_HELP_FONT_ID = 0


def _lang_code() -> str:
    try:
        lang = str(getattr(bpy.context.preferences.view, 'language', '') or '').strip()
        if lang and lang.upper() != 'DEFAULT':
            return lang
    except Exception:
        pass
    try:
        return str(getattr(bpy.app.translations, 'locale', '') or '').strip()
    except Exception:
        return ''


def _is_ja() -> bool:
    return _lang_code().lower().startswith('ja')


def _t(en: str, ja: str) -> str:
    return str(ja if _is_ja() else en)


def _clean(text: object) -> str:
    return _SPACE_RE.sub(' ', str(text or '').strip())


def _ui_scale(context=None) -> float:
    try:
        prefs = getattr(context, 'preferences', None) or getattr(bpy.context, 'preferences', None)
        value = float(getattr(getattr(prefs, 'system', None), 'ui_scale', 1.0) or 1.0)
    except Exception:
        value = 1.0
    return max(0.75, min(value, 2.5))


def _char_columns(ch: str) -> int:
    """Return a fallback visual-column width for one character."""
    if not ch:
        return 0
    if ch == '\t':
        return 4
    if unicodedata.combining(ch):
        return 0
    east = unicodedata.east_asian_width(ch)
    if east in {'F', 'W'}:
        return 2
    if east == 'A' and _is_ja():
        return 2
    return 1


def _is_breakable_ui_char(ch: str) -> bool:
    """Return True for CJK-style characters that can wrap without spaces."""
    if not ch or ch.isspace() or unicodedata.combining(ch):
        return False
    east = unicodedata.east_asian_width(ch)
    return east in {'F', 'W'} or (east == 'A' and _is_ja())


def _wrap_units(text: str) -> list[str]:
    """Split text into English words/spaces and CJK per-character units."""
    units: list[str] = []
    buf = ''
    for ch in str(text or ''):
        if ch.isspace():
            if buf:
                units.append(buf)
                buf = ''
            if units and units[-1] != ' ':
                units.append(' ')
            continue
        if _is_breakable_ui_char(ch):
            if buf:
                units.append(buf)
                buf = ''
            units.append(ch)
            continue
        buf += ch
    if buf:
        units.append(buf)
    while units and units[0] == ' ':
        units.pop(0)
    while units and units[-1] == ' ':
        units.pop()
    return units


def _prepare_blf(context=None) -> bool:
    """Prepare Blender's UI font measurement when the blf module is available."""
    if _blf is None:
        return False
    try:
        size = max(10, int(round(11 * _ui_scale(context))))
        try:
            _blf.size(_HELP_FONT_ID, size)
        except TypeError:
            # Blender versions before the two-argument API require dpi.
            _blf.size(_HELP_FONT_ID, size, 72)
        return True
    except Exception:
        return False


def _text_pixels(text: str, context=None) -> float:
    """Return rendered text width in pixels, using blf when possible."""
    text = str(text or '')
    if not text:
        return 0.0
    if _prepare_blf(context):
        try:
            return float(_blf.dimensions(_HELP_FONT_ID, text)[0])
        except Exception:
            pass

    # Fallback for static analysis or non-Blender execution. This path is less
    # exact than blf, but still tracks UI scale and East Asian full-width glyphs.
    unit_px = 7.25 * _ui_scale(context)
    return float(sum(_char_columns(ch) * unit_px for ch in text))


def _estimate_text_width_px(context=None, dialog_width: int | None = None) -> int:
    """Estimate the popup body width available to a single help label."""
    width_px = int(dialog_width or 0)
    if width_px <= 0:
        try:
            region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
        except Exception:
            region_width = 0
        if region_width > 0:
            width_px = region_width
    if width_px <= 0:
        width_px = _HELP_DIALOG_WIDTH

    padding_px = int(round(_HELP_HORIZONTAL_PADDING_PX * _ui_scale(context)))
    return max(180, width_px - padding_px)


def _split_long_token_pixels(token: str, max_px: float, context=None) -> list[str]:
    max_px = max(120.0, float(max_px))
    parts: list[str] = []
    buf = ''
    for ch in str(token or ''):
        candidate = buf + ch
        if buf and _text_pixels(candidate, context) > max_px:
            parts.append(buf.rstrip())
            buf = ch
        else:
            buf = candidate
    if buf:
        parts.append(buf.rstrip())
    return parts or ['']


def _wrap_pixels(text: str, max_px: float, context=None) -> list[str]:
    """Wrap text only when its rendered width exceeds the available pixels."""
    text = _clean(text)
    if not text:
        return []
    max_px = max(180.0, float(max_px))
    if _text_pixels(text, context) <= max_px:
        return [text]

    lines: list[str] = []
    current = ''
    units = _wrap_units(text) or [text]
    for unit in units:
        if not unit:
            continue
        if unit == ' ' and not current:
            continue

        candidate = current + unit
        candidate_for_measure = candidate.rstrip()
        if candidate_for_measure and _text_pixels(candidate_for_measure, context) <= max_px:
            current = candidate
            continue

        if unit == ' ':
            if current:
                lines.append(current.rstrip())
                current = ''
            continue

        if current:
            lines.append(current.rstrip())
            current = ''

        unit = unit.lstrip()
        if not unit:
            continue
        if _text_pixels(unit, context) <= max_px:
            current = unit
            continue

        parts = _split_long_token_pixels(unit, max_px, context)
        if parts:
            lines.extend(part for part in parts[:-1] if part)
            current = parts[-1]

    if current:
        lines.append(current.rstrip())
    return lines or [text]


def _wrap(layout, text: str, *, icon: str = 'NONE', width: int | None = None, context=None) -> None:
    text = _clean(text)
    if not text:
        return

    max_px = float(width or _HELP_TEXT_WIDTH_PX)
    first_px = max(180.0, max_px - (_HELP_ICON_RESERVED_PX * _ui_scale(context) if icon and icon != 'NONE' else 0.0))
    lines = _wrap_pixels(text, first_px, context)

    # Continuation lines do not include the icon column, so rewrap the tail with
    # the full popup body width. This prevents unnecessary fixed-width wrapping
    # while still keeping the first icon line inside the same popup width.
    if len(lines) > 1 and first_px != max_px:
        tail = ''.join(lines[1:]) if _is_ja() else ' '.join(lines[1:])
        lines = [lines[0], *_wrap_pixels(tail, max_px, context)]

    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)

def _draw_lines(layout, lines: Iterable[str], *, icon: str = 'NONE', width: int | None = None) -> None:
    for index, line in enumerate(lines):
        _wrap(layout, line, icon=icon if index == 0 else 'NONE', width=width)


def _draw_heading(layout, title: str, icon: str = 'NONE'):
    box = layout.box()
    _wrap(box, title, icon=icon)
    return box


def _draw_named_items(layout, items: Sequence[tuple[str, str]], *, icon: str = 'DOT', width: int | None = None) -> None:
    for name, desc in items:
        text = f'{name}: {desc}' if desc else name
        _wrap(layout, text, icon=icon, width=width)


@dataclass(frozen=True)
class _DetectedSetting:
    topic: str
    module: str
    owner: str
    identifier: str
    property_type: str
    name: str
    description: str
    default: str
    extra: str


@dataclass(frozen=True)
class _DetectedFunction:
    topic: str
    module: str
    class_name: str
    bl_idname: str
    label: str
    description: str


_TOPIC_SOURCE_MAP: dict[str, tuple[str, ...]] = {
    'smart_selector': ('ui.py', 'preferences.py', 'always_on.py', 'registry.py', 'settings.py'),
    'selection_sets': ('selection_sets.py', 'ui.py'),
    'project': ('ui.py', 'preferences.py', 'settings.py', 'utils.py'),
    'selector_data': ('ui.py', 'server.py', 'html.py', 'settings.py'),
    'settings': ('ui.py', 'preferences.py', 'settings.py', 'registry.py'),
    'settings_performance': ('ui.py', 'preferences.py', 'settings.py'),
    'settings_project_list': ('ui.py', 'preferences.py', 'settings.py', 'utils.py'),
    'bridge_actions': ('ui.py', 'server.py', 'preferences.py'),
    'bridge_undo_redo': ('ui.py',),
    'bridge_selection': ('ui.py', 'server.py'),
    'bridge_shapekey': ('ui.py', 'server.py'),
    'bridge_custom_prop': ('ui.py', 'server.py'),
    'bridge_script': ('ui.py', 'server.py', 'preferences.py'),
    'collection_manager': ('collection_manager',),
    'gp_select': ('gp_select',),
    'gp_select_renaming_pass': ('gp_select',),
    'gp_select_rigging': ('gp_select',),
}


_TOPIC_FUNCTION_FILTERS: dict[str, tuple[str, ...]] = {
    'selection_sets': ('selection_set_',),
    'project': ('project_', 'open_project', 'set_active_project'),
    'selector_data': ('selector', 'favorite'),
    'settings': ('settings', 'preference'),
    'settings_performance': ('state', 'interval', 'backup', 'exec', 'sync'),
    'settings_project_list': ('project', 'archive', 'root_dir', 'folder'),
    'bridge_actions': ('undo', 'redo', 'selection', 'shapekey', 'custom_prop', 'script'),
    'bridge_undo_redo': ('undo', 'redo'),
    'bridge_selection': ('selection', 'select'),
    'bridge_shapekey': ('shape', 'shapekey', 'key'),
    'bridge_custom_prop': ('custom_prop', 'custom', 'property', 'rna'),
    'bridge_script': ('script',),
    'gp_select_renaming_pass': ('rename', 'pass', 'find', 'replace', 'strip', 'prefix', 'suffix', 'clean'),
    'gp_select_rigging': ('rig', 'time', 'offset', 'sensitivity', 'driver', 'setup'),
}


_TOPIC_SETTING_FILTERS: dict[str, tuple[str, ...]] = {
    'selection_sets': ('selection_set', 'member', 'active_object'),
    'project': ('project', 'root_dir', 'archive', 'name'),
    'selector_data': ('selector', 'favorite', 'backup', 'payload', 'browser', 'grid', 'snap', 'style', 'action'),
    'settings': ('root_dir', 'interval', 'backup', 'exec', 'archive', 'section', 'show_'),
    'settings_performance': ('state', 'interval', 'backup', 'exec'),
    'settings_project_list': ('root_dir', 'archive', 'project'),
    'bridge_actions': ('payload', 'script', 'shape', 'custom', 'selection'),
    'bridge_selection': ('selection_payload', 'selection', 'target'),
    'bridge_shapekey': ('shapekey_payload', 'shape', 'key'),
    'bridge_custom_prop': ('custom_prop_payload', 'custom', 'prop', 'path'),
    'bridge_script': ('exec_script_payload', 'script', 'enable_exec_script'),
    'gp_select_renaming_pass': ('name', 'rename', 'find', 'replace', 'pass', 'affix', 'text'),
    'gp_select_rigging': ('sensitivity', 'rig', 'time', 'offset', 'driver'),
}


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _topic_paths(topic_id: str) -> tuple[Path, ...]:
    root = _package_root()
    rels = _TOPIC_SOURCE_MAP.get(str(topic_id or '').strip(), ())
    paths: list[Path] = []
    for rel in rels:
        p = root / rel
        if p.is_dir():
            paths.extend(sorted(q for q in p.rglob('*.py') if q.name != 'help.py' and '__pycache__' not in q.parts))
        elif p.is_file():
            paths.append(p)
    # Preserve order and remove duplicates.
    seen: set[str] = set()
    unique: list[Path] = []
    for p in paths:
        key = str(p.resolve())
        if key in seen:
            continue
        seen.add(key)
        unique.append(p)
    return tuple(unique)


def _module_label(path: Path) -> str:
    try:
        return path.relative_to(_package_root()).as_posix()
    except Exception:
        return path.name


def _call_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = _call_name(node.value)
        return f'{parent}.{node.attr}' if parent else node.attr
    return ''


def _literal(node: ast.AST | None) -> str:
    if node is None:
        return ''
    try:
        value = ast.literal_eval(node)
    except Exception:
        try:
            return ast.unparse(node)
        except Exception:
            return ''
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return 'True' if value else 'False'
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, (tuple, list)):
        items = [str(v) for v in list(value)[:12]]
        suffix = '...' if len(value) > 12 else ''
        return ', '.join(items) + suffix
    if isinstance(value, dict):
        return ', '.join(str(k) for k in list(value.keys())[:12])
    return str(value)


def _keyword(call: ast.Call, name: str) -> str:
    for kw in getattr(call, 'keywords', []) or []:
        if kw.arg == name:
            return _literal(kw.value)
    return ''


def _target_name(node: ast.AST | None) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _target_name(node.value)
        return f'{base}.{node.attr}' if base else node.attr
    if isinstance(node, ast.Subscript):
        return _target_name(node.value)
    return ''


def _class_base_names(node: ast.ClassDef) -> tuple[str, ...]:
    names: list[str] = []
    for base in getattr(node, 'bases', []) or []:
        names.append(_call_name(base))
    return tuple(names)


def _is_property_call(node: ast.AST | None) -> bool:
    return isinstance(node, ast.Call) and _call_name(node.func).endswith('Property')


def _property_from_assignment(node: ast.AST) -> tuple[str, ast.Call] | None:
    if isinstance(node, ast.AnnAssign):
        target = _target_name(node.target)
        if _is_property_call(node.value):
            return target, node.value  # type: ignore[return-value]
        if _is_property_call(node.annotation):
            return target, node.annotation  # type: ignore[return-value]
    if isinstance(node, ast.Assign):
        targets = list(getattr(node, 'targets', []) or [])
        target = _target_name(targets[0]) if targets else ''
        if _is_property_call(node.value):
            return target, node.value  # type: ignore[return-value]
    return None


def _class_assignment_string(node: ast.AST, attr_name: str) -> str:
    for child in getattr(node, 'body', []) or []:
        if isinstance(child, (ast.Assign, ast.AnnAssign)):
            targets = getattr(child, 'targets', None)
            if targets:
                names = [_target_name(t) for t in targets]
            else:
                names = [_target_name(getattr(child, 'target', None))]
            if attr_name in names:
                return _literal(getattr(child, 'value', None))
    return ''


def _matches_topic_filter(topic_id: str, *texts: str, kind: str = 'function') -> bool:
    topic_id = str(topic_id or '').strip()
    if topic_id in {'smart_selector', 'collection_manager', 'gp_select'}:
        return True
    filters = (_TOPIC_FUNCTION_FILTERS if kind == 'function' else _TOPIC_SETTING_FILTERS).get(topic_id)
    if not filters:
        return True
    hay = ' '.join(str(t or '').lower() for t in texts).replace('smart_selector_suite', '').replace('smart selector suite', '').replace('smart selector', '')
    return any(token in hay for token in filters)


def _localized_source_text(text: str, context=None) -> str:
    value = _clean(text)
    if not value:
        return ''
    try:
        translated = _suite_translate(value, context=context)
        if translated:
            return _clean(translated)
    except Exception:
        pass
    try:
        if _is_ja():
            translated = bpy.app.translations.pgettext_iface(value)
            if translated and translated != value:
                return _clean(translated)
            translated = bpy.app.translations.pgettext_tip(value)
            if translated and translated != value:
                return _clean(translated)
    except Exception:
        pass
    return value


def _setting_allowed_for_topic(topic_id: str, owner: str, identifier: str, name: str, desc: str) -> bool:
    topic = str(topic_id or '').strip()
    owner_l = str(owner or '').lower()
    ident_l = str(identifier or '').lower()
    name_l = str(name or '').lower()
    desc_l = str(desc or '').lower()
    if owner_l == 'sssuite_ot_show_help' or ident_l in {'topic_id'}:
        return topic == 'smart_selector'
    if topic == 'settings':
        return owner_l == 'sssuite_npanelsettings'
    if topic == 'settings_performance':
        return owner_l == 'sssuite_npanelsettings' and ident_l in {'state_update_interval', 'max_backup_generations', 'enable_exec_script'}
    if topic == 'settings_project_list':
        return owner_l == 'sssuite_npanelsettings' and ident_l in {'root_dir', 'show_archived_projects'}
    if topic == 'selector_data':
        return ('selector' in owner_l or 'favorite' in owner_l or 'selector' in ident_l or 'favorite' in ident_l)
    if topic == 'project':
        return (
            'project' in owner_l or 'project' in ident_l or 'project' in name_l
            or ident_l in {'root_dir', 'show_archived_projects'}
        )
    if topic == 'bridge_actions':
        return (
            owner_l == 'sssuite_bridgepayloadproperties'
            or any(token in owner_l or token in ident_l for token in ('script', 'shapekey', 'custom_prop', 'selection', 'undo', 'redo'))
            or ident_l in {'enable_exec_script'}
        )
    if topic == 'bridge_selection':
        return owner_l == 'sssuite_bridgepayloadproperties' and ('selection' in ident_l or 'selection' in name_l)
    if topic == 'bridge_shapekey':
        return owner_l == 'sssuite_bridgepayloadproperties' and ('shape' in ident_l or 'shape' in name_l)
    if topic == 'bridge_custom_prop':
        return owner_l == 'sssuite_bridgepayloadproperties' and ('custom' in ident_l or 'property' in name_l or 'rna' in desc_l)
    if topic == 'bridge_script':
        return (
            (owner_l == 'sssuite_bridgepayloadproperties' and 'script' in ident_l)
            or ident_l == 'enable_exec_script'
        )
    return True


def _japanese_char_count(text: str) -> int:
    return sum(1 for ch in str(text or '') if '\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff')


def _ascii_letter_count(text: str) -> int:
    return sum(1 for ch in str(text or '') if ('A' <= ch <= 'Z') or ('a' <= ch <= 'z'))


def _needs_generic_ja(text: str) -> bool:
    if not _is_ja():
        return False
    value = str(text or '')
    if not value.strip():
        return True
    if 'Function:' in value or 'How to use:' in value:
        return True
    ja = _japanese_char_count(value)
    ascii_letters = _ascii_letter_count(value)
    if ja <= 0:
        return True
    return ascii_letters > max(24, ja * 0.55)


def _is_user_setting(call: ast.Call) -> bool:
    """A property the user sees has its own name; the rest (operator arguments, stored state) stays out of the help."""
    if not _keyword(call, 'name'):
        return False
    for kw in getattr(call, 'keywords', []) or []:
        if kw.arg == 'options' and any(isinstance(n, ast.Constant) and n.value in {'HIDDEN', 'SKIP_SAVE'} for n in ast.walk(kw.value)):
            return False
    return True


def _property_type_label(prop_type: str) -> str:
    key = str(prop_type or '').strip()
    if not _is_ja():
        return {
            'StringProperty': 'text',
            'BoolProperty': 'on/off',
            'IntProperty': 'whole number',
            'FloatProperty': 'number',
            'EnumProperty': 'choice',
            'CollectionProperty': 'list',
            'PointerProperty': 'reference',
            'FloatVectorProperty': 'numbers',
            'IntVectorProperty': 'whole numbers',
            'BoolVectorProperty': 'on/off values',
        }.get(key, '')
    mapping = {
        'StringProperty': '文字列',
        'BoolProperty': '真偽値',
        'IntProperty': '整数',
        'FloatProperty': '小数',
        'EnumProperty': '選択肢',
        'CollectionProperty': 'コレクション',
        'PointerProperty': '参照',
        'FloatVectorProperty': '小数ベクトル',
        'IntVectorProperty': '整数ベクトル',
        'BoolVectorProperty': '真偽値ベクトル',
    }
    return mapping.get(key, '')


@lru_cache(maxsize=64)
def _detected_settings(topic_id: str) -> tuple[_DetectedSetting, ...]:
    topic = str(topic_id or '').strip() or 'smart_selector'
    records: list[_DetectedSetting] = []
    for path in _topic_paths(topic):
        try:
            tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'))
        except Exception:
            continue
        module = _module_label(path)
        for class_node in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
            owner = class_node.name
            for body_node in getattr(class_node, 'body', []) or []:
                item = _property_from_assignment(body_node)
                if item is None:
                    continue
                identifier, call = item
                if not identifier or not _is_user_setting(call):
                    continue
                prop_type = _call_name(call.func).rsplit('.', 1)[-1]
                name = _keyword(call, 'name')
                desc = _keyword(call, 'description')
                default = _keyword(call, 'default')
                extras = []
                for key in ('min', 'max'):
                    value = _keyword(call, key)
                    if value:
                        extras.append(f'{key}={value}')
                if not _matches_topic_filter(topic, identifier, name, desc, owner, kind='setting'):
                    continue
                if not _setting_allowed_for_topic(topic, owner, identifier, name, desc):
                    continue
                records.append(_DetectedSetting(topic, module, owner, identifier, prop_type, name, desc, default, ', '.join(extras)))
        # Module-level Property definitions are also possible.
        for body_node in getattr(tree, 'body', []) or []:
            item = _property_from_assignment(body_node)
            if item is None:
                continue
            identifier, call = item
            if not identifier or not _is_user_setting(call):
                continue
            prop_type = _call_name(call.func).rsplit('.', 1)[-1]
            name = _keyword(call, 'name')
            desc = _keyword(call, 'description')
            default = _keyword(call, 'default')
            if not _matches_topic_filter(topic, identifier, name, desc, kind='setting'):
                continue
            if not _setting_allowed_for_topic(topic, 'module', identifier, name, desc):
                continue
            records.append(_DetectedSetting(topic, module, 'module', identifier, prop_type, name, desc, default, ''))
    # De-duplicate by visible name and identifier while preserving order.
    out: list[_DetectedSetting] = []
    seen: set[tuple[str, str, str]] = set()
    for rec in records:
        key = (rec.identifier, rec.name, rec.owner)
        if key in seen:
            continue
        seen.add(key)
        out.append(rec)
    return tuple(out)


@lru_cache(maxsize=64)
def _detected_functions(topic_id: str) -> tuple[_DetectedFunction, ...]:
    topic = str(topic_id or '').strip() or 'smart_selector'
    records: list[_DetectedFunction] = []
    for path in _topic_paths(topic):
        try:
            tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'))
        except Exception:
            continue
        module = _module_label(path)
        for node in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
            base_names = _class_base_names(node)
            if not any(name.endswith('Operator') or '.Operator' in name for name in base_names):
                continue
            bl_idname = _class_assignment_string(node, 'bl_idname')
            label = _class_assignment_string(node, 'bl_label')
            desc = _class_assignment_string(node, 'bl_description')
            if not label:
                continue
            if str(bl_idname).endswith(('.show_help', '.toggle_ui_section', '.cm_send_report')):
                continue
            if bl_idname and ('.' not in bl_idname and not bl_idname.startswith('SMART_')):
                continue
            if not _matches_topic_filter(topic, node.name, bl_idname, label, desc, kind='function'):
                continue
            records.append(_DetectedFunction(topic, module, node.name, bl_idname, label, desc))
    out: list[_DetectedFunction] = []
    seen: set[tuple[str, str]] = set()
    for rec in records:
        key = (rec.bl_idname, rec.label)
        if key in seen:
            continue
        seen.add(key)
        out.append(rec)
    return tuple(out)


def _manual_name_index(items: Sequence[tuple[str, str]]) -> dict[str, int]:
    """1.10.53 (review fix 1): lower-case name of each hand-written item -> its position (first one wins)."""
    index: dict[str, int] = {}
    for position, (name, _desc) in enumerate(items):
        index.setdefault(_clean(name).lower(), position)
    return index


def _merge_detected_into_manual(items: list[tuple[str, str]], position: int, detected_desc: str) -> None:
    """1.10.53 (review fix 1): a detected item whose name is the name of a hand-written item is not dropped.

    Its description is written after the hand-written description of that item (unless it is already there),
    so the text the detected item showed before (modifier keys, the real behaviour of the operator, its id) stays.
    """
    detected_desc = _clean(detected_desc)
    if not detected_desc:
        return
    name, desc = items[position]
    desc = _clean(desc)
    if detected_desc in desc:
        return
    sep = '' if desc.endswith(('。', '）', '」')) else ' '   # no space after a Japanese full stop
    items[position] = (name, f'{desc}{sep}{detected_desc}' if desc else detected_desc)


def _setting_items_for_topic(topic_id: str, manual_items: Sequence[tuple[str, str]]) -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = list(manual_items or [])
    manual_index = _manual_name_index(items)
    seen_names = {_clean(name).lower() for name, _desc in items}
    for rec in _detected_settings(topic_id):
        name = _localized_source_text(rec.name)
        desc = _localized_source_text(rec.description)
        meta_bits: list[str] = []
        if rec.property_type:
            meta_bits.append(_t('Type', '種類') + f': {_property_type_label(rec.property_type)}')
        if rec.default:
            default_text = {'True': _t('on', 'オン'), 'False': _t('off', 'オフ')}.get(rec.default, rec.default)
            meta_bits.append(_t('Default', '既定値') + f': {default_text}')
        if rec.extra:
            meta_bits.append(rec.extra.replace('min=', _t('min ', '最小 ')).replace('max=', _t('max ', '最大 ')))
        if not desc or _needs_generic_ja(desc):
            desc = ''
        if meta_bits:
            desc = f'{desc} ({"; ".join(meta_bits)})'.strip()
        key = name.lower()
        if not name:
            continue
        if key in manual_index:
            _merge_detected_into_manual(items, manual_index[key], desc)
            continue
        if key in seen_names:
            continue
        seen_names.add(key)
        items.append((name, desc))
    return items


def _function_items_for_topic(topic_id: str, manual_items: Sequence[tuple[str, str]]) -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = list(manual_items or [])
    manual_index = _manual_name_index(items)
    seen_names = {_clean(name).lower() for name, _desc in items}
    for rec in _detected_functions(topic_id):
        name = _localized_source_text(rec.label)
        desc = _localized_source_text(rec.description)
        if not desc or _needs_generic_ja(desc) or desc.startswith('Function: runs the '):
            desc = ''
        key = name.lower()
        if not name:
            continue
        if key in manual_index:
            _merge_detected_into_manual(items, manual_index[key], desc)
            continue
        if key in seen_names:
            continue
        seen_names.add(key)
        items.append((name, desc))
    return items

def _common_topics() -> dict[str, dict[str, object]]:
    return {
        'smart_selector': {
            'title': _t('Smart Selector Help', 'スマートセレクター ヘルプ'),
            'overview': [
                _t(
                    'Smart Selector is a single 3D View Sidebar panel that launches browser-based selector files, project management, integrated tools, persistent settings, and bridge actions. The main buttons use borderless high-coverage custom icons so each action can be identified quickly in a compact N-panel.',
                    'スマートセレクターは、ブラウザーベースのセレクターファイル、プロジェクト管理、統合ツール、永続設定、ブリッジ操作を1つの3Dビューサイドバーパネルから扱うためのアドオンです。主要ボタンには枠無しで図形面積を大きく取った独自アイコンを使い、狭いNパネルでも各操作を素早く判別できるようにしています。',
                ),
            ],
            'usage': [
                _t(
                    'Use the groups inside the Smart Selector panel from top to bottom: enable required always-on items, choose a project, create or open selector data, then use the integrated tools only when needed.',
                    'スマートセレクターのパネル内のグループを上から順に使います。必要な常時起動項目を有効化し、プロジェクトを選び、セレクターデータを作成または起動し、必要な時だけ統合ツールを読み込みます。',
                ),
            ],
            'settings': [
                (_t('Always-on Toggles', '常時起動切り替え'), _t('Controls background handlers, timers, hotkeys, header widgets, and lazy-load availability.', 'バックグラウンドハンドラー、タイマー、ホットキー、ヘッダーウィジェット、遅延読み込みの利用可否を制御します。')),
                (_t('Selection Sets', '選択セット'), _t('Creates scene-local named object selections that can be recalled, combined, updated, renamed, and deleted.', 'シーン内のオブジェクト選択を名前付きで保存し、呼び出し、追加・除外・切り替え、更新、名前変更、削除を行います。')),
                (_t('Project', 'プロジェクト'), _t('Chooses the selector data folder used by the browser UI.', 'ブラウザーUIで使うセレクターデータ用フォルダーを選びます。')),
                (_t('Selector Data List', 'セレクターデータ一覧'), _t('Shows selector JSON files in the active project and opens them in play or edit mode.', '現在のプロジェクト内のセレクターJSONを表示し、再生または編集モードで開きます。')),
                (_t('Settings', '設定'), _t('Stores save locations, safety options, synchronization interval, backup generation count, and project list behavior.', '保存先、安全設定、同期間隔、バックアップ世代数、プロジェクト一覧の挙動を保存します。')),
                (_t('Bridge Actions', 'ブリッジ操作'), _t('Runs internal bridge operations from JSON payloads for testing or manual control.', 'テストや手動操作のため、JSONペイロードから内部ブリッジ処理を実行します。')),
            ],
        },
        'selection_sets': {
            'title': _t('Selection Sets Help', '選択セット ヘルプ'),
            'overview': [
                _t(
                    'Selection Sets provide a 3ds Max-style named object-selection workflow inside Blender. Each set stores direct object references in the current .blend, so object renames do not break membership.',
                    '選択セットは、3ds Maxの名前付き選択セットに相当するオブジェクト選択ワークフローをBlender内に提供します。各セットは現在の.blendにオブジェクト参照を直接保存するため、オブジェクト名を変更してもメンバーは維持されます。',
                ),
                _t(
                    'Selection-set data belongs to the scene and is saved with the .blend. The section open/closed state and the next new-set name follow N-panel State Save in Smart_Selector_Suite.json.',
                    '選択セットのデータはシーンに属し、.blendと一緒に保存されます。セクションの開閉状態と次に作成するセット名は、「Nパネル状態保存」に従ってSmart_Selector_Suite.jsonへ保存されます。',
                ),
            ],
            'usage': [
                _t('Select one or more objects, enter a set name, and click Create. Choose a row in the list before using the controls below it.', '1つ以上のオブジェクトを選択し、セット名を入力して「作成」を押します。下部の操作を使う前に一覧から対象行を選んでください。'),
                _t('Select replaces the current object selection. Add, Subtract, and Toggle combine the named set with the current selection without changing set membership.', '「選択」は現在のオブジェクト選択を置き換えます。「追加」「除外」「切り替え」はセット内容を変更せず、現在の選択と組み合わせます。'),
                _t('Update replaces the set contents with the current selection. The adjacent icon buttons add members, remove members, rename the set, or delete the set.', '「更新」は現在の選択でセット内容を置き換えます。隣のアイコンボタンでは、メンバー追加、メンバー除外、名前変更、セット削除を行います。'),
            ],
            'functions': [
                (_t('Create', '作成'), _t('Creates a new uniquely named set from the current object selection.', '現在のオブジェクト選択から重複しない名前の新規セットを作成します。')),
                (_t('Select / Add / Subtract / Toggle', '選択 / 追加 / 除外 / 切り替え'), _t('Recalls the active set with replace, additive, subtractive, or toggle selection behavior.', '置換、追加、除外、切り替えのいずれかでアクティブセットを呼び出します。')),
                (_t('Update', '更新'), _t('Replaces every member of the active set with the current object selection.', 'アクティブセットの全メンバーを現在のオブジェクト選択へ置き換えます。')),
                (_t('Add Objects to Selection Set', '選択セットへオブジェクトを追加'), _t('The + icon. Adds selected objects without removing existing members.', '＋のアイコンです。既存メンバーを残したまま、選択中のオブジェクトを追加します。')),
                (_t('Remove Objects from Selection Set', '選択セットからオブジェクトを除外'), _t('The - icon. Removes selected objects from the set without deleting the objects from the scene.', '－のアイコンです。選択中のオブジェクトをセットから除外します。シーン内のオブジェクト自体は削除しません。')),
                (_t('Rename Selection Set / Delete Selection Set', '選択セット名を変更 / 選択セットを削除'), _t('The pencil and trash icons. Renames the active set or deletes only the set definition.', '鉛筆とごみ箱のアイコンです。アクティブセット名を変更するか、セット定義だけを削除します。')),
            ],
            'settings': [
                (_t('New Selection Set Name', '新規選択セット名'), _t('Name used for the next set. This UI value follows the N-panel State Save policy.', '次に作成するセットへ使う名前です。このUI値は「Nパネル状態保存」の方針に従います。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Scene-local storage', 'シーン内保存'), _t('Set names, memberships, and remembered active objects are stored in the .blend scene as intentional functional data.', 'セット名、メンバー、記憶したアクティブオブジェクトは、意図した機能データとして.blendのシーン内へ保存されます。')),
            ],
        },
        'project': {
            'title': _t('Project Help', 'プロジェクト ヘルプ'),
            'overview': [
                _t('Projects are folders that separate selector JSON files and images by job, character, scene, or shot.', 'プロジェクトは、セレクターJSONと画像を案件、キャラクター、シーン、カットごとに分けるためのフォルダーです。'),
                _t('The active project is saved according to N-panel State Save and is restored after Blender restarts or after opening another scene.', 'アクティブプロジェクトは「Nパネル状態保存」に従って保存され、Blender再起動後や別シーンを開いた後も復元されます。'),
            ],
            'usage': [
                _t('Click the project name to open the project list, choose the folder you want to use, and then create or open selector files from the Selector Data List group.', 'プロジェクト名をクリックして一覧を開き、使うフォルダーを選んでから、「セレクターデータ一覧」グループでセレクターを作成または起動します。'),
                _t('Use the folder button to open the current project on disk, and use create, rename, duplicate, or archive buttons for project maintenance.', 'フォルダーボタンで現在のプロジェクトをディスク上で開き、作成、リネーム、複製、アーカイブの各ボタンでプロジェクトを管理します。'),
            ],
            'functions': [
                (_t('Project list', 'プロジェクト一覧'), _t('Switches the active project folder.', 'アクティブなプロジェクトフォルダーを切り替えます。')),
                (_t('Open Project Folder', 'プロジェクトフォルダを開く'), _t('Opens the active project directory in the operating system file browser.', 'OSのファイルブラウザーで現在のプロジェクトフォルダーを開きます。')),
                (_t('Create Project', 'プロジェクト作成'), _t('Creates a new folder and switches to it.', '新しいフォルダーを作成し、そのプロジェクトへ切り替えます。')),
                (_t('Rename Project', 'プロジェクト名変更'), _t('Renames the current project folder while keeping its selector files and images inside.', '現在のプロジェクトフォルダー名を変更し、中のセレクターと画像は保持します。')),
                (_t('Duplicate Project', 'プロジェクト複製'), _t('Copies all selector files and images into a new project folder.', '全セレクターファイルと画像を新しいプロジェクトフォルダーへコピーします。')),
                (_t('Archive Project', 'プロジェクトをアーカイブ'), _t('Moves the project into the archive folder and switches back to the default project.', 'プロジェクトをアーカイブフォルダーへ移動し、標準プロジェクトへ戻します。')),
            ],
            'settings': [
                (_t('Project Name', 'プロジェクト名'), _t('The name entered when creating a project. Use letters, numbers, and underscores to avoid path problems.', 'プロジェクト作成時に入力する名前です。パス問題を避けるため、英数字とアンダースコア中心の名前を推奨します。')),
                (_t('New Name', '新しい名前'), _t('The destination name used when renaming or duplicating a project.', 'プロジェクトのリネームまたは複製時に使う変更先の名前です。')),
                (_t('Show Archived Projects', 'アーカイブ済みプロジェクトを表示'), _t('Shows project folders inside the archive directory in the project list.', 'アーカイブディレクトリ内のプロジェクトも一覧に表示します。')),
                (_t('Data Save Root Directory', 'データ保存ルートディレクトリ'), _t('The root directory where all project folders are stored. Blank uses CONFIG/Smart_Selector_Suite.', '全プロジェクトフォルダーを保存するルートディレクトリです。空欄の場合は CONFIG/Smart_Selector_Suite を使います。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Active Project', 'アクティブプロジェクト'), _t('The currently selected project folder name. It is stored in the add-on persistent settings, not only in the current scene.', '現在選択中のプロジェクトフォルダー名です。現在のシーンだけでなく、アドオンの永続設定へ保存されます。')),
            ],
        },
        'selector_data': {
            'title': _t('Selector Data List Help', 'セレクターデータ一覧 ヘルプ'),
            'overview': [
                _t('The Selector Data List shows every selector JSON file in the active project and opens the browser-based selector UI.', 'セレクターデータ一覧は、現在のプロジェクト内にある全セレクターJSONを表示し、ブラウザー型のセレクターUIを起動します。'),
                _t('Selector files can contain buttons, sliders, images, object targets, collection targets, Shape Key controls, custom-property controls, and optional Python script actions.', 'セレクターファイルには、ボタン、スライダー、画像、オブジェクト対象、コレクション対象、シェイプキー操作、カスタムプロパティ操作、任意のPythonスクリプト操作を含められます。'),
            ],
            'usage': [
                _t('Click Create New Selector to open an empty selector in edit mode. After editing in the browser, save it as a JSON file.', '「新規セレクター作成」をクリックすると、空のセレクターを編集モードで開きます。ブラウザー上で編集した後、JSONファイルとして保存します。'),
                _t('Click the button with the name of an existing selector (play) to use it. Click the pencil icon (edit) to modify that selector in the browser editor.', '既存セレクターの名前のボタン（再生）で使用し、鉛筆のアイコン（編集）でブラウザーエディターから内容を変更します。'),
            ],
            'functions': [
                (_t('Create New Selector', '新規セレクター作成'), _t('Opens a new empty selector in browser edit mode.', '空のセレクターをブラウザー編集モードで開きます。')),
                (_t('Open Selector', 'セレクターを開く'), _t('The button with the selector name (play mode): Launches an existing selector for normal use. The pencil icon beside it (edit mode): Launches an existing selector for editing layout, buttons, sliders, images, and actions.', 'セレクター名のボタン（再生モード）：既存セレクターを通常使用用に起動します。隣の鉛筆のアイコン（編集モード）：既存セレクターを編集用に起動し、レイアウト、ボタン、スライダー、画像、アクションを変更します。')),
                (_t('Toggle Favorite', 'お気に入り切替'), _t('The star icon. Marks or unmarks a selector as a favorite inside the current project.', '星のアイコンです。現在のプロジェクト内でセレクターをお気に入り登録または解除します。')),
                (_t('Favorites Only', 'お気に入りのみ'), _t('Filters the list so only favorite selectors are shown.', '一覧をフィルターし、お気に入りセレクターだけを表示します。')),
            ],
            'settings': [
                (_t('Favorites Only', 'お気に入りのみ'), _t('A persistent N-panel filter. It is saved according to N-panel State Save and restored after restart or scene change.', 'Nパネルの永続フィルターです。「Nパネル状態保存」に従って保存され、再起動後やシーン変更後も復元されます。')),
                (_t('Backup Generations', 'バックアップ世代数'), _t('Controls how many previous JSON/image versions are kept when selector data is saved.', 'セレクターデータ保存時に、過去のJSON/画像を何世代残すかを制御します。')),
                (_t('Browser server', 'ブラウザーサーバー'), _t('The always-on permission that allows selector browser windows to start. If disabled, new selector windows are blocked.', 'セレクターブラウザーウィンドウの起動を許可する常時起動項目です。無効の場合、新しいセレクターウィンドウは起動しません。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Browser edit mode', 'ブラウザー編集モード'), _t('Edits selector layout, button positions, labels, images, colors, fonts, grid display, and snap behavior.', 'セレクターのレイアウト、ボタン位置、ラベル、画像、カラー、フォント、グリッド表示、スナップ挙動を編集します。')),
                (_t('Browser play mode', 'ブラウザー再生モード'), _t('Runs selector buttons and sliders for object selection, collection control, Shape Key values, custom properties, scripts, timeline actions, and camera actions.', 'セレクターボタンとスライダーを使い、オブジェクト選択、コレクション制御、シェイプキー値、カスタムプロパティ、スクリプト、タイムライン操作、カメラ操作を実行します。')),
                (_t('Object and collection capture', 'オブジェクトとコレクション取得'), _t('Captures selected Blender objects or collection names and stores them as selector targets.', 'Blenderで選択したオブジェクトやコレクション名を取得し、セレクターの対象として保存します。')),
                (_t('Bone capture', 'ボーン取得'), _t('Captures selected pose bones and stores them as selector targets.', '選択中のポーズボーンを取得し、セレクター対象として保存します。')),
                (_t('Shape Key and custom property controls', 'シェイプキーとカスタムプロパティ制御'), _t('Creates controls that send numeric values from the browser back to Blender.', 'ブラウザーからBlenderへ数値を送信するコントロールを作成します。')),
                (_t('Save, Save As, Load, and backups', '保存、別名保存、読み込み、バックアップ'), _t('Stores selector JSON and image data in the active project. Backup generations are controlled from Settings.', 'セレクターJSONと画像データを現在のプロジェクトへ保存します。バックアップ世代数は設定で制御します。')),
                (_t('Favorite selectors', 'お気に入りセレクター'), _t('Per-project favorite state for selector JSON files. It is stored in the add-on settings.', 'セレクターJSONごとのプロジェクト別お気に入り状態です。アドオン設定に保存されます。')),
                (_t('Browser data watchers', 'ブラウザーデータ監視'), _t('Always-on watcher that keeps object and collection data dirty flags updated for browser refresh.', 'ブラウザー更新用にオブジェクトとコレクションの更新フラグを維持する常時起動監視です。')),
                (_t('Browser state-sync timer', 'ブラウザー状態同期タイマー'), _t('Always-on timer that sends selection, active object, collection, object, and Shape Key state to the browser.', '選択状態、アクティブオブジェクト、コレクション、オブジェクト、シェイプキー状態をブラウザーへ送る常時起動タイマーです。')),
                (_t('Browser task-queue timer', 'ブラウザータスクキュータイマー'), _t('Always-on timer that executes queued browser requests on Blender’s main thread.', 'ブラウザーから送られた処理キューをBlenderのメインスレッドで実行する常時起動タイマーです。')),
                (_t('Grid and snap options', 'グリッドとスナップ設定'), _t('Browser editor options for alignment while placing buttons, sliders, and image elements.', 'ボタン、スライダー、画像要素を配置するときの位置合わせ用ブラウザー編集設定です。')),
                (_t('Style options', 'スタイル設定'), _t('Browser editor options for text, font, size, color, opacity, border, radius, and image appearance.', 'テキスト、フォント、サイズ、色、不透明度、枠線、角丸、画像表示を調整するブラウザー編集設定です。')),
                (_t('Action target options', 'アクション対象設定'), _t('Browser editor options that define whether a selector controls objects, collections, bones, Shape Keys, custom properties, scripts, timeline, or camera actions.', 'セレクターがオブジェクト、コレクション、ボーン、シェイプキー、カスタムプロパティ、スクリプト、タイムライン、カメラ操作のどれを制御するかを定義するブラウザー編集設定です。')),
            ],
        },
        'settings': {
            'title': _t('Settings Help', '設定 ヘルプ'),
            'overview': [
                _t('Settings store the data path, synchronization behavior, backup behavior, safety permissions, and project-list behavior used by Smart Selector.', '設定では、スマートセレクターが使うデータ保存先、同期挙動、バックアップ挙動、安全権限、プロジェクト一覧の挙動を保存します。'),
            ],
            'usage': [
                _t('Change values directly in the Settings group. With N-panel State Save enabled, values are saved immediately to Smart_Selector_Suite/Smart_Selector_Suite.json; with it disabled, they are flushed on scene close or Save Preferences.', '「設定」グループ内で値を直接変更します。「Nパネル状態保存」が有効な場合は Smart_Selector_Suite/Smart_Selector_Suite.json へ即時保存され、無効な場合はシーンを閉じる時またはプリファレンス保存時に反映されます。'),
                _t('For heavy scenes, increase State Sync Interval (s). For shared selector files, disable Allow Execute Script unless scripts are required.', '重いシーンでは「状態同期間隔（秒）」を大きくしてください。共有セレクターファイルを使う場合、スクリプトが必要な時以外は「スクリプト実行を許可」を無効にしてください。'),
            ],
            'settings': [
                (_t('Data Save Root Directory', 'データ保存ルートディレクトリ'), _t('Root folder for project folders. Blank uses CONFIG/Smart_Selector_Suite. Changing it does not move existing projects automatically.', 'プロジェクトフォルダーのルート保存先です。空欄では CONFIG/Smart_Selector_Suite を使います。変更しても既存プロジェクトは自動移動しません。')),
                (_t('State Sync Interval (s)', '状態同期間隔（秒）'), _t('How often Blender state is synchronized to the browser bridge. Larger values reduce update frequency and can help heavy scenes.', 'Blenderの状態をブラウザーブリッジへ同期する間隔です。値を大きくすると更新頻度が下がり、重いシーンで負荷を抑えやすくなります。')),
                (_t('Backup Generations', 'バックアップ世代数'), _t('Number of backup generations kept beside saved JSON and image files. Set 0 to disable backups.', '保存したJSONと画像の横に残すバックアップ世代数です。0でバックアップを無効化します。')),
                (_t('Allow Execute Script', 'スクリプト実行を許可'), _t('Allows selector buttons to run custom Python scripts. Disable this when using untrusted or shared selector data.', 'セレクターボタンからカスタムPythonスクリプトを実行できるようにします。信頼できないデータや共有データを使う場合は無効にしてください。')),
                (_t('Show Archived Projects', 'アーカイブ済みプロジェクトを表示'), _t('Shows archived project folders in the project list.', 'アーカイブ済みプロジェクトフォルダーをプロジェクト一覧へ表示します。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Collection Manager availability', 'コレクションマネージャーの利用可否'), _t('Controlled from Always-on Toggles. Disable it to keep the Collection Manager module unloaded until re-enabled.', '「常時起動切り替え」で制御します。無効にすると、再度有効化するまでコレクションマネージャーモジュールを未読み込み状態に保ちます。')),
                (_t('GP Select availability', 'GP セレクトの利用可否'), _t('Controlled from Always-on Toggles. Disable it to keep the GP Select module unloaded until re-enabled.', '「常時起動切り替え」で制御します。無効にすると、再度有効化するまで GP セレクトモジュールを未読み込み状態に保ちます。')),
            ],
        },
        'bridge_actions': {
            'title': _t('Bridge Actions Help', 'ブリッジ操作 ヘルプ'),
            'overview': [
                _t('Bridge Actions expose the same internal actions that the browser selector can send to Blender. They are mainly for testing, recovery, and manual execution from the N-panel.', 'ブリッジ操作は、ブラウザーセレクターからBlenderへ送られる内部処理をNパネルから直接実行するためのものです。主にテスト、復旧、手動実行に使います。'),
            ],
            'usage': [
                _t('Edit the JSON payload field for the action you want to test, then click the action button below that field.', 'テストしたい処理のJSONペイロード欄を編集し、その欄の下にある実行ボタンをクリックします。'),
                _t('These values are saved according to N-panel State Save. Invalid object names, paths, JSON syntax, or disabled script execution can cancel the action.', 'これらの値は「Nパネル状態保存」に従って保存されます。無効なオブジェクト名、パス、JSON構文、またはスクリプト実行無効化により、処理がキャンセルされる場合があります。'),
            ],
            'functions': [
                (_t('Undo', '元に戻す'), _t('Runs Blender undo from the bridge UI.', 'ブリッジUIからBlenderの元に戻す操作を実行します。')),
                (_t('Redo', 'やり直し'), _t('Runs Blender redo from the bridge UI.', 'ブリッジUIからBlenderのやり直し操作を実行します。')),
                (_t('Apply Selection', '選択を適用'), _t('Applies object, collection, bone, or component selection data from a JSON payload.', 'JSONペイロードのオブジェクト、コレクション、ボーン、コンポーネント選択情報を適用します。')),
                (_t('Set Shape Key', 'シェイプキーを設定'), _t('Sets a Shape Key value on a target object.', '対象オブジェクトのシェイプキー値を設定します。')),
                (_t('Set Custom Property', 'カスタムプロパティを設定'), _t('Sets a numeric custom property or data-path value on a target object.', '対象オブジェクトの数値カスタムプロパティまたはデータパス値を設定します。')),
                (_t('Execute Script', 'スクリプトを実行'), _t('Executes a Python script payload when script execution is allowed in Settings.', '設定でスクリプト実行が許可されている場合に、Pythonスクリプトペイロードを実行します。')),
            ],
            'settings': [
                (_t('Selection Payload', '選択ペイロード'), _t('JSON field used by Apply Selection. Example target keys include target_type, objects, collections, bones, and action options.', '選択を適用で使うJSON欄です。target_type、objects、collections、bones、action などのキーを指定できます。')),
                (_t('Shape Key Payload', 'シェイプキーペイロード'), _t('JSON field used by Set Shape Key. It contains object name, Shape Key name, and target value.', 'シェイプキー設定で使うJSON欄です。オブジェクト名、シェイプキー名、設定値を含めます。')),
                (_t('Custom Property Payload', 'カスタムプロパティペイロード'), _t('JSON field used by Set Custom Property. It contains object name, data path, and target numeric value.', 'カスタムプロパティ設定で使うJSON欄です。オブジェクト名、データパス、設定する数値を含めます。')),
                (_t('Script Payload', 'スクリプトペイロード'), _t('JSON field used by Execute Script. It contains a script string. It runs only when Allow Execute Script is enabled.', 'スクリプト実行で使うJSON欄です。script文字列を含めます。「スクリプト実行を許可」が有効な場合だけ実行されます。')),
            ],
        },
        'collection_manager': {
            'title': _t('Collection Manager Help', 'コレクションマネージャーヘルプ'),
            'overview': [
                _t('Collection Manager manages scene collections, object membership, collection restriction flags, local and global visibility states, filtering, and QCD slot workflows.', 'コレクションマネージャーは、シーン内コレクション、オブジェクト所属、コレクション制限フラグ、ローカル/グローバル表示状態、フィルター、QCDスロット運用を管理します。'),
                _t('The module is lazy-loaded. If it has not been used yet, only the lightweight button remains visible in Smart Selector.', 'このモジュールは遅延読み込みです。まだ使っていない場合、スマートセレクターには軽量なボタンだけが表示されます。'),
            ],
            'usage': [
                _t('Click Open Collection Manager to load the module if needed and open the collection popup.', '「コレクションマネージャーを開く」をクリックすると、必要な場合だけモジュールを読み込み、コレクション管理ポップアップを開きます。'),
                _t('Enable QCD, menus, hotkeys, or cleanup handlers from Always-on Toggles only when those background features are needed.', 'QCD、メニュー、ホットキー、クリーンアップハンドラーは、必要な場合だけ「常時起動切り替え」で有効化してください。'),
            ],
            'functions': [
                (_t('Open Collection Manager', 'コレクションマネージャーを開く'), _t('Loads the tool and opens the main collection management popup.', 'ツールを読み込み、メインのコレクション管理ポップアップを開きます。')),
                (_t('Set Active Collection', 'アクティブコレクションを設定'), _t('Sets the active collection target.', '操作対象のアクティブコレクションを設定します。')),
                (_t('Expand All Items / Expand Sublevel Items', '全項目を展開 / サブ階層を展開'), _t('Expands or collapses collection rows.', 'コレクション行を展開または折りたたみます。')),
                (_t('Select All Objects in the Collection', 'コレクション内の全オブジェクトを選択'), _t('Selects objects inside the chosen collection, including cumulative selection workflows.', '指定コレクション内のオブジェクトを選択し、累積選択ワークフローにも対応します。')),
                (_t('Send Objects to Collection', 'オブジェクトをコレクションへ送る'), _t('Moves or links selected objects into the target collection according to the operator mode.', '選択オブジェクトを、オペレーターのモードに応じて対象コレクションへ移動またはリンクします。')),
                (_t('Restriction toggles', '制限トグル'), _t('Controls Exclude, Disable Selection, Hide in Viewport, Disable in Viewports, Disable in Renders, Holdout, and Indirect Only.', '除外、選択不可、ビューポート非表示、ビューポート無効、レンダー無効、ホールドアウト、間接のみ を制御します。')),
                (_t('Add Collection / Remove Collection', 'コレクションを追加 / コレクションを削除'), _t('Creates new collections or removes existing collections, including empty collection cleanup.', '新規コレクションを作成、または既存コレクションや空コレクションを削除します。')),
                (_t('Apply Phantom Mode', 'ファントムモードを適用'), _t('The check-mark icon beside the Phantom Mode button. Phantom Mode lets you try collection states temporarily; this button keeps the result: it ends Phantom Mode and keeps the collection states changed during it, and the state saved when Phantom Mode was turned on is not restored (to cancel instead, turn Phantom Mode off with its button: that restores the saved state).', 'ファントムモードのボタンの横のチェックマークのアイコンです。ファントムモードでは、コレクションの状態を一時的に試せます。このボタンはその結果を残します。ファントムモードを終え、その間に変えたコレクションの状態をそのまま残し、ファントムモードを有効化した時に保存した状態には戻しません（取り消したい時は、ファントムモードのボタンで無効化します。保存した状態に戻ります）。')),
            ],
            'settings': [
                (_t('[EC] Exclude from View Layer', '[EC] ビューレイヤーから除外'), _t('Shows the Exclude column and controls whether a collection is excluded from the active View Layer.', '除外の列を表示し、コレクションを現在のビューレイヤーから除外するかを制御します。')),
                (_t('[SS] Disable Selection', '[SS] 選択を無効化'), _t('Shows the selection restriction column and controls whether objects in a collection can be selected.', '選択制限列を表示し、コレクション内オブジェクトを選択できるかを制御します。')),
                (_t('[VV] Hide in Viewport', '[VV] ビューポートで非表示'), _t('Shows the local viewport visibility column.', 'ローカルビューポート表示列を表示します。')),
                (_t('[DV] Disable in Viewports', '[DV] ビューポートで無効化'), _t('Shows the global viewport disable column.', 'グローバルなビューポート無効列を表示します。')),
                (_t('[RR] Disable in Renders', '[RR] レンダーで無効化'), _t('Shows the render disable column.', 'レンダー無効列を表示します。')),
                (_t('[HH] Holdout', '[HH] ホールドアウト'), _t('Shows the Holdout column for view-layer collection rendering.', 'ビューレイヤーのコレクションレンダリング用ホールドアウト列を表示します。')),
                (_t('[IO] Indirect Only', '[IO] 間接のみ'), _t('Shows the Indirect Only column for view-layer collection rendering.', 'ビューレイヤーのコレクションレンダリング用 間接のみ 列を表示します。')),
                (_t('Align Local Options', 'ローカルオプションを整列'), _t('Places local option controls in a right-side column for a more aligned layout.', 'ローカルオプションを右側列にそろえて表示します。')),
                (_t('Filter By Name', '名前でフィルター'), _t('Filters visible collections by text.', '表示するコレクションを文字列で絞り込みます。')),
                (_t('Invert', '反転'), _t('Inverts the active collection filter result.', '現在のコレクションフィルター結果を反転します。')),
                (_t('Filter By Selected', '選択でフィルター'), _t('Shows only collections that contain selected objects.', '選択オブジェクトを含むコレクションだけを表示します。')),
                (_t('Filter By QCD', 'QCDでフィルター'), _t('Shows only collections assigned to QCD slots.', 'QCDスロットに割り当てられているコレクションだけを表示します。')),
                (_t('Disable Objects override', 'オブジェクト無効化の置き換え'), _t('Always-on setting that adds Disable Selected, Disable Unselected, and Restore Disabled Objects behavior.', '「選択物を無効化」「非選択物を無効化」「無効化した物を戻す」を追加する常時起動設定です。')),
                (_t('QCD system', 'QCD システム'), _t('Always-on setting that enables QCD operators, handlers, hotkeys, and optional header widget support.', 'QCDオペレーター、ハンドラー、ホットキー、任意のヘッダーウィジェット対応を有効化する常時起動設定です。')),
                (_t('QCD hotkeys (non-edit)', 'QCD ホットキー（編集以外）'), _t('Enables number-key QCD shortcuts outside Edit Mode.', '編集モード以外で数値キーQCDショートカットを有効化します。')),
                (_t('QCD edit-mode hotkeys', 'QCD 編集モード用ホットキー'), _t('Enables number-key QCD shortcuts while editing geometry.', 'ジオメトリ編集中に数値キーQCDショートカットを有効化します。')),
                (_t('QCD 3D View header widget', 'QCD ヘッダーウィジェット'), _t('Draws QCD slot buttons in the 3D View header.', '3DビューのヘッダーにQCDスロットボタンを表示します。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Disable Objects workflow', 'オブジェクト無効化ワークフロー'), _t('Disables selected or unselected objects and restores disabled objects when the override is enabled.', '置き換え機能が有効な場合、選択/非選択オブジェクトを無効化し、無効化したオブジェクトを復元します。')),
                (_t('QCD actions', 'QCD 操作'), _t('Creates, renumbers, views, isolates, moves to, and selects objects from QCD slots.', 'QCDスロットの作成、番号整理、表示、隔離、移動、オブジェクト選択を行います。')),
            ],
        },
        'gp_select': {
            'title': _t('GP Select Help', 'GP セレクト ヘルプ'),
            'overview': [
                _t('GP Select provides Grease Pencil mode switching, stroke-layer selection, layer ordering, visibility, opacity, mask, material, weight, pass-index, and rigging helper workflows.', 'GP セレクトは、Grease Pencil のモード切り替え、ストロークレイヤー選択、レイヤー順序、表示、透明度、マスク、マテリアル、ウェイト、パスインデックス、リギング補助を扱います。'),
                _t('The module is lazy-loaded. Until GP Select is loaded, only the lightweight load button is shown.', 'このモジュールは遅延読み込みです。GP セレクトを読み込むまで、軽量な読み込みボタンだけが表示されます。'),
            ],
            'usage': [
                _t('Click Load GP Select UI when you need Grease Pencil tools. After loading, use the GP Select, Renaming and Pass Index, and Rigging Tools subgroups inside the single Smart Selector panel.', 'Grease Pencil ツールが必要な時に「GP セレクトUIを読み込む」をクリックします。読み込み後は、単一のスマートセレクターのパネル内にある GP セレクト、リネームとパスインデックス、リギングツールの各グループを使います。'),
                _t('Most commands require selected Grease Pencil strokes, layers, objects, or a compatible mode. If nothing changes, check the current object type, mode, and selection.', '多くのコマンドは、選択中のGrease Pencilストローク、レイヤー、オブジェクト、または対応モードを必要とします。変化がない場合は、現在のオブジェクト種別、モード、選択状態を確認してください。'),
            ],
            'functions': [
                (_t('Modes', 'モード'), _t('Switches to Draw, Lasso, Pull, Pinch, Strength, and Thickness tools.', '描画、投げ縄、引っ張り、つまむ、強さ、厚み ツールへ切り替えます。')),
                (_t('Weight Selected', '選択へウェイト'), _t('Prepares selected Grease Pencil strokes for Weight Paint workflows.', '選択中のGrease Pencilストロークをウェイトペイントワークフロー用に準備します。')),
                (_t('Assign Weight', 'ウェイト割り当て'), _t('Assigns weight to selected strokes according to the active workflow.', 'アクティブなワークフローに従い、選択ストロークへウェイトを割り当てます。')),
                (_t('Sync Layer Name / Make layers From Groups', 'レイヤー名を同期 / グループからレイヤーを作成'), _t('Synchronizes layer names with vertex groups and creates layers from groups when needed.', '必要に応じてレイヤー名と頂点グループを同期し、グループからレイヤーを作成します。')),
                (_t('Selection & Reordering', '選択と並べ替え'), _t('Switches to layers, isolates strokes, locks selected layers, sends layers to top or bottom, and moves groups above or below selections.', 'レイヤーへ切り替え、ストロークを隔離し、選択レイヤーをロックし、レイヤーを最上部/最下部へ送ったり、選択の上下へグループ移動します。')),
                (_t('Select By', '条件で選択'), _t('Selects similar layers by prefix, infix, or suffix.', '接頭辞、中間文字列、接尾辞で類似レイヤーを選択します。')),
                (_t('Visibility & Opacity', '表示と不透明度'), _t('Applies opacity values, restores opacity, hides selected layers, and unlocks all.', '不透明度値の適用、復元、選択レイヤー非表示、全ロック解除を行います。')),
                (_t('Layer Tools', 'レイヤーツール'), _t('Duplicates and hides originals, deletes selected layers, groups selected stroke layers, converts vertex groups to layers, and removes empty layers.', '複製して元を非表示、選択レイヤー削除、選択ストロークレイヤーのグループ化、頂点グループからレイヤー作成、空レイヤー削除を行います。')),
                (_t('Mask:', 'マスク:'), _t('Applies active-layer masks to selected strokes, masks selected strokes to the active layer, unmasks, inverts masks, and toggles all masks.', 'アクティブレイヤーマスクの選択ストロークへの適用、選択ストロークのアクティブレイヤーへのマスク、マスク解除、マスク反転、全マスク切り替えを行います。')),
            ],
            'settings': [
                (_t('Text', 'テキスト'), _t('Affix text used when adding prefixes or suffixes to layer names.', 'レイヤー名へ接頭辞または接尾辞を追加するときに使う文字列です。')),
                (_t('New Name', '新しい名前'), _t('Replacement name used by full-name rename operations.', 'フルネームリネーム操作で使う置き換え名です。')),
                (_t('Find', '検索'), _t('Text to search for in selected layer names.', '選択レイヤー名の中から検索する文字列です。')),
                (_t('Replace', '置換'), _t('Text used to replace the Find value.', '検索文字列を置き換えるための文字列です。')),
                (_t('Opacity', '不透明度'), _t('Target opacity value applied to selected stroke layers.', '選択ストロークレイヤーへ適用する不透明度の目標値です。')),
                (_t('Pass', 'パス'), _t('Layer or material Pass Index value applied by the pass-index tools.', 'パスインデックスツールでレイヤーまたはマテリアルへ適用する値です。')),
                (_t('Sensitivity', '感度'), _t('Controller sensitivity used by the Time Offset Driver Generator.', '時間オフセットのドライバーを作る時に使うコントローラーの感度です。')),
                (_t('GP weight cleanup handlers', 'GP ウェイトの後片付け'), _t('Always-on setting that permits temporary cleanup handlers used by Weight Selected workflows.', '「選択へウェイト」ワークフローで使う一時クリーンアップハンドラーを許可する常時起動設定です。')),
            ],
        },
        'gp_select_renaming_pass': {
            'title': _t('Renaming and Pass Index Help', 'リネームとパスインデックスヘルプ'),
            'overview': [
                _t('This GP Select subgroup edits Grease Pencil layer names and Pass Index values without leaving the Smart Selector panel.', 'この GP セレクト内グループでは、スマートセレクターのパネルから離れずに Grease Pencil レイヤー名とパスインデックス値を編集します。'),
            ],
            'usage': [
                _t('Select strokes or layers first, enter the required text or Pass Index value, then press the corresponding action button.', '先にストロークまたはレイヤーを選択し、必要な文字列またはパスインデックス値を入力してから、対応する実行ボタンを押します。'),
            ],
            'functions': [
                (_t('Apply Layer Pass Index?', 'レイヤーパスインデックスを適用しますか？'), _t('The layer icon. Applies the Pass value to selected Grease Pencil layers.', 'レイヤーのアイコンです。選択Grease Pencilレイヤーへパスの値を適用します。')),
                (_t('Set Material Pass Index?', 'マテリアルパスインデックスを設定しますか？'), _t('The material icon. Applies the Pass value to the relevant materials.', 'マテリアルのアイコンです。関連マテリアルへパスの値を適用します。')),
                (_t('Reset Indexes?', 'インデックスをリセットしますか？'), _t('The loop-back icon. Resets configured Pass Index values.', '戻る矢印のアイコンです。設定済みのパスインデックス値をリセットします。')),
                (_t('Prefix / Suffix', '接頭辞 / 接尾辞'), _t('Adds the Affixes text before or after selected layer names.', '「付ける文字」の欄の文字列を選択レイヤー名の前または後ろへ追加します。')),
                (_t('Rename', 'リネーム'), _t('Replaces selected layer names with the Rename value.', '選択レイヤー名をリネーム欄の値へ置き換えます。')),
                (_t('Replace', '置換'), _t('Finds text in selected layer names and replaces it with the Replace value.', '選択レイヤー名内の文字列を検索し、置換の欄の値へ置換します。')),
                (_t('Strip', '除去'), _t('Cleans digits or punctuation from selected layer names according to the operator logic.', 'オペレーターの処理に従い、選択レイヤー名から数字や句読点を整理します。')),
            ],
            'settings': [
                (_t('Pass', 'パス'), _t('Numeric Pass Index value to apply.', '適用する数値のパスインデックスです。')),
                (_t('Affixes', '付ける文字'), _t('Text used for prefix and suffix operations.', '接頭辞と接尾辞の操作で使う文字列です。')),
                (_t('Rename', 'リネーム'), _t('Full replacement name for selected layers (the field beside the Rename button).', '選択レイヤー名を丸ごと置き換える名前です（「リネーム」のボタンの横の欄）。')),
                (_t('Find', '検索'), _t('Search text for find-and-replace.', '検索と置換で探す文字列です。')),
                (_t('Replace', '置換'), _t('Replacement text for find-and-replace.', '検索文字列を置き換える文字列です。')),
            ],
        },
        'gp_select_rigging': {
            'title': _t('Rigging Tools Help', 'リギングツール ヘルプ'),
            'overview': [
                _t('Rigging Tools creates and manages time-offset driver setups for Grease Pencil layer animation workflows.', 'リギングツールは、Grease Pencil レイヤーアニメーション向けの時間オフセットのドライバーを作成・管理します。'),
            ],
            'usage': [
                _t('Select the relevant Grease Pencil layers, bones, or setup targets, set Sensitivity if needed, then run the creation or maintenance command.', '対象となるGrease Pencilレイヤー、ボーン、セットアップ対象を選択し、必要に応じて感度を設定してから作成または管理コマンドを実行します。'),
            ],
            'functions': [
                (_t('Create Layer Time Control', 'レイヤーの時間オフセット制御を作成'), _t('Creates a layer-based time-offset controller setup.', 'レイヤーベースの時間オフセットコントローラーセットアップを作成します。')),
                (_t('Create Pass Index Time Control', 'インデックスパスの時間オフセット制御を作成'), _t('Creates a time-offset setup based on indexed Pass values.', 'インデックス化したパスの値に基づく時間オフセットのセットアップを作成します。')),
                (_t('Remove Setup', 'セットアップを削除'), _t('Removes the generated setup from the selected target.', '選択対象から生成済みセットアップを削除します。')),
                (_t('Apply Sensitivity', '感度を適用'), _t('Applies the Sensitivity value to existing drivers.', '既存ドライバーへ感度値を適用します。')),
                (_t('Toggle Time Visibility', '時間表示を切替'), _t('Toggles visibility behavior used by the generated time setup.', '生成された時間セットアップで使う表示挙動を切り替えます。')),
            ],
            'settings': [
                (_t('Sensitivity', '感度'), _t('Controls the strength of the time-offset driver response.', '時間オフセットドライバー反応の強さを制御します。')),
            ],
        },
    }


def _extra_topics() -> dict[str, dict[str, object]]:
    return {
        'settings_performance': {
            'title': _t('Performance / Safety Help', 'パフォーマンスと安全性 ヘルプ'),
            'overview': [
                _t('This subgroup stores update speed, backup retention, and script-execution safety settings used by Smart Selector and the browser bridge.', 'このグループでは、スマートセレクターとブラウザーブリッジで使う更新速度、バックアップ保持、安全なスクリプト実行設定を管理します。'),
            ],
            'usage': [
                _t('Increase the sync interval for heavier scenes, lower it when you need faster browser feedback, keep backups enabled when editing production selectors, and allow script execution only for trusted selector files.', '重いシーンでは同期間隔を大きくし、ブラウザー反映を速くしたい場合は小さくします。制作中のセレクターではバックアップ保持を有効にし、スクリプト実行は信頼できるセレクターファイルに対してのみ許可してください。'),
            ],
            'settings': [
                (_t('State Sync Interval (s)', '状態同期間隔（秒）'), _t('Changes how often Smart Selector sends live state updates to the browser bridge.', 'スマートセレクターがブラウザーブリッジへライブ状態更新を送る頻度を変更します。')),
                (_t('Backup Generations', 'バックアップ世代数'), _t('Controls how many previous JSON and image backups are kept when selector data is saved.', 'セレクターデータ保存時に保持する JSON と画像の過去バックアップ数を制御します。')),
                (_t('Allow Execute Script', 'スクリプト実行を許可'), _t('Allows selector files to run custom Python scripts. Disable this when using untrusted data.', 'セレクターファイルからカスタム Python スクリプトを実行できるようにします。信頼できないデータを使う場合は無効にしてください。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Performance tuning', 'パフォーマンス調整'), _t('Adjusts how frequently Blender state is synchronized to the browser and how much backup history is preserved.', 'Blender 状態をブラウザーへ同期する頻度と、保持するバックアップ履歴量を調整します。')),
                (_t('Script safety control', 'スクリプト安全制御'), _t('Controls whether selector buttons are allowed to execute custom Python code.', 'セレクターボタンからカスタム Python コードを実行できるかを制御します。')),
            ],
        },
        'settings_project_list': {
            'title': _t('Project List Help', 'プロジェクト一覧 ヘルプ'),
            'overview': [
                _t('This subgroup manages where project folders are stored and whether archived projects appear in the project picker.', 'このグループでは、プロジェクトフォルダーの保存場所と、アーカイブ済みプロジェクトを一覧へ表示するかどうかを管理します。'),
            ],
            'usage': [
                _t('Leave the root directory blank to use CONFIG/Smart_Selector_Suite, or enter a manual directory when you want to store selector projects elsewhere. Enable archived-project visibility only when you need to reopen older jobs.', 'ルートディレクトリを空欄にすると、CONFIG/Smart_Selector_Suite を使います。別の場所へ保存したい場合だけ手動ディレクトリを指定してください。古い案件を再度開く必要がある場合だけ、アーカイブ済みプロジェクト表示を有効にします。'),
            ],
            'functions': [
                (_t('Show Archived Projects', 'アーカイブ済みプロジェクトを表示'), _t('Controls whether archived project folders appear in the project picker.', 'アーカイブ済みプロジェクトフォルダーをプロジェクト選択一覧へ表示するかどうかを制御します。')),
            ],
            'settings': [
                (_t('Data Save Root Directory', 'データ保存ルートディレクトリ'), _t('Manual root directory for project folders. Blank uses CONFIG/Smart_Selector_Suite.', 'プロジェクトフォルダー用の手動ルートディレクトリです。空欄の場合は CONFIG/Smart_Selector_Suite を使います。')),
                (_t('Show Archived Projects', 'アーカイブ済みプロジェクトを表示'), _t('Shows archived project folders inside the project picker list.', 'アーカイブ済みプロジェクトフォルダーをプロジェクト一覧の中へ表示します。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('Project storage location', 'プロジェクト保存先'), _t('Determines where Smart Selector creates and searches project folders.', 'スマートセレクターがプロジェクトフォルダーを作成・検索する場所を決定します。')),
            ],
        },
        'bridge_undo_redo': {
            'title': _t('Undo / Redo Help', '元に戻す・やり直し ヘルプ'),
            'overview': [
                _t('This bridge subgroup runs Blender history commands directly from the Smart Selector panel.', 'このブリッジグループでは、スマートセレクターのパネルから直接 Blender の履歴コマンドを実行します。'),
            ],
            'usage': [
                _t('Use Undo to step backward through recent changes and Redo to restore the last undone step. These buttons act immediately and do not require a JSON payload.', '「元に戻す」で最近の変更を一段階戻し、「やり直し」で直前に戻した変更を復元します。これらのボタンは即時実行され、JSON ペイロードを必要としません。'),
            ],
            'functions': [
                (_t('Undo', '元に戻す'), _t('Runs Blender undo from the Smart Selector panel.', 'スマートセレクターのパネルから Blender の元に戻す操作を実行します。')),
                (_t('Redo', 'やり直し'), _t('Runs Blender redo from the Smart Selector panel.', 'スマートセレクターのパネルから Blender のやり直し操作を実行します。')),
            ],
            # 1.10.52 (review fix 3): not a button or setting of the panel; shown under "What it does".
            'concepts': [
                (_t('No dedicated setting', '専用設定なし'), _t('This subgroup executes Blender history commands directly and does not store its own persistent value.', 'このグループは Blender の履歴コマンドを直接実行するため、専用の永続設定値は持ちません。')),
            ],
        },
        'bridge_selection': {
            'title': _t('Apply Selection Payload Help', '選択ペイロード適用 ヘルプ'),
            'overview': [
                _t('This bridge subgroup applies object, collection, bone, or component-selection data from a JSON payload.', 'このブリッジグループでは、JSON ペイロードからオブジェクト、コレクション、ボーン、またはコンポーネント選択データを適用します。'),
            ],
            'usage': [
                _t('Edit the Selection Payload JSON, then click Apply Selection. Typical keys include target_type, objects, collections, bones, shift, and ctrl.', '選択ペイロードの JSON を編集してから、「選択を適用」をクリックします。代表的なキーには target_type、objects、collections、bones、shift、ctrl があります。'),
            ],
            'functions': [
                (_t('Apply Selection', '選択を適用'), _t('Applies the current selection JSON payload to Blender.', '現在の選択 JSON ペイロードを Blender へ適用します。')),
            ],
            'settings': [
                (_t('Selection Payload', '選択ペイロード'), _t('JSON field used to describe what should be selected and how that selection should be applied.', '何を選択するか、どのように選択を適用するかを記述する JSON 入力欄です。')),
            ],
        },
        'bridge_shapekey': {
            'title': _t('Shape Key Payload Help', 'シェイプキーペイロード ヘルプ'),
            'overview': [
                _t('This bridge subgroup sends a numeric Shape Key value from the panel to Blender.', 'このブリッジグループでは、数値のシェイプキー値をパネルから Blender へ送信します。'),
            ],
            'usage': [
                _t('Fill the JSON payload with the target object name, Shape Key name, and desired value, then click Set Shape Key.', '対象オブジェクト名、シェイプキー名、設定したい値を JSON に入力してから、「シェイプキーを設定」をクリックします。'),
            ],
            'functions': [
                (_t('Set Shape Key', 'シェイプキーを設定'), _t('Writes the payload value into the target Shape Key.', 'ペイロード内の値を対象シェイプキーへ書き込みます。')),
            ],
            'settings': [
                (_t('Shape Key Payload', 'シェイプキーペイロード'), _t('JSON field that contains the target object, Shape Key identifier, and numeric value.', '対象オブジェクト、シェイプキー識別子、数値を含む JSON 入力欄です。')),
            ],
        },
        'bridge_custom_prop': {
            'title': _t('Custom Property Payload Help', 'カスタムプロパティペイロード ヘルプ'),
            'overview': [
                _t('This bridge subgroup writes a numeric custom-property or data-path value to a target object.', 'このブリッジグループでは、数値カスタムプロパティまたはデータパス値を対象オブジェクトへ書き込みます。'),
            ],
            'usage': [
                _t('Enter the object name, target property path, and numeric value in JSON form, then click Set Custom Property.', 'オブジェクト名、対象プロパティパス、数値を JSON 形式で入力してから、「カスタムプロパティを設定」をクリックします。'),
            ],
            'functions': [
                (_t('Set Custom Property', 'カスタムプロパティを設定'), _t('Applies the payload value to the target numeric custom property or data path.', 'ペイロードの値を対象の数値カスタムプロパティまたはデータパスへ適用します。')),
            ],
            'settings': [
                (_t('Custom Property Payload', 'カスタムプロパティペイロード'), _t('JSON field that contains the target object name, property path, and numeric value.', '対象オブジェクト名、プロパティパス、数値を含む JSON 入力欄です。')),
            ],
        },
        'bridge_script': {
            'title': _t('Script Payload Help', 'スクリプトペイロード ヘルプ'),
            'overview': [
                _t('This bridge subgroup executes a Python script payload on Blender\'s main thread when script execution is allowed.', 'このブリッジグループでは、スクリプト実行が許可されている場合に Python スクリプトペイロードを Blender のメインスレッドで実行します。'),
            ],
            'usage': [
                _t('Enter the script string in JSON form and click Execute Script. Disable Allow Execute Script in Settings when you do not need this feature or when selector data is not trusted.', 'JSON 形式で script 文字列を入力し、「スクリプトを実行」をクリックします。この機能が不要な場合やセレクターデータを信頼できない場合は、設定内の「スクリプト実行を許可」を無効にしてください。'),
            ],
            'functions': [
                (_t('Execute Script', 'スクリプトを実行'), _t('Runs the current script payload when script execution is enabled.', 'スクリプト実行が有効な場合に、現在のスクリプトペイロードを実行します。')),
            ],
            'settings': [
                (_t('Script Payload', 'スクリプトペイロード'), _t('JSON field that contains the script string to execute.', '実行する script 文字列を含む JSON 入力欄です。')),
                (_t('Allow Execute Script', 'スクリプト実行を許可'), _t('Master safety switch that permits or blocks script payload execution.', 'スクリプトペイロード実行を許可または遮断するための安全スイッチです。')),
            ],
        },
    }


def _always_on_extra_lines(key: str) -> list[str]:
    try:
        from . import help_more as _more
        return [str(x) for x in (_more.always_on_extra(_t).get(key) or []) if x]
    except Exception:
        return []


def _always_on_settings_items() -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = []
    try:
        from . import always_on
        for info in always_on.feature_definitions():
            label = str(info.get('label_ja') if _is_ja() else info.get('label_en') or info.get('key') or '')
            desc = str(info.get('description_ja') if _is_ja() else info.get('description_en') or '')
            desc = desc.replace('機能: ', '').replace('使い方: ', '') if _is_ja() else desc.replace('Function: ', '').replace('How to use: ', '')
            items.append((label, desc))
    except Exception:
        items = [
            (_t('Collection Manager', 'コレクションマネージャー'), _t('Controls whether the Collection Manager tool can be loaded.', 'コレクションマネージャーを読み込めるかを制御します。')),
            (_t('GP Select', 'GP セレクト'), _t('Controls whether GP Select can be loaded.', 'GP セレクトを読み込めるかを制御します。')),
            (_t('Browser server', 'ブラウザーサーバー'), _t('Controls whether selector browser windows can start the local server.', 'セレクターブラウザーウィンドウがローカルサーバーを起動できるかを制御します。')),
        ]
    return items


def _always_on_sections() -> list[dict[str, object]]:
    """1.10.52: the always_on_toggles help as data (the same six parts, drawn and exported from one place)."""
    sections: list[dict[str, object]] = [
        {'kind': 'title', 'heading': _t('Always-on Toggles Help', '常時起動切り替え ヘルプ'), 'icon': 'HELP', 'lines': []},
        {'kind': 'lines', 'heading': _t('1. What it does', '1. 何をする機能か'), 'icon': 'QUESTION', 'lines': [
            _t('Always-on Toggles centralize N-panel state saving and only the features that genuinely need background registration, such as optional handlers, hotkeys, menus, and header widgets.', '常時起動切り替えは、Nパネル状態保存と、任意ハンドラー、ホットキー、メニュー、ヘッダーウィジェットなど、バックグラウンド登録が本当に必要な機能だけを集約します。'),
            _t('Browser synchronization watchers and timers are no longer user-facing always-on items; they are registered only while the browser bridge server is running and are removed when it stops.', 'ブラウザー同期用の監視とタイマーは、表示項目としての常時起動ではなく、ブラウザーブリッジサーバー稼働中だけ自動登録され、停止時に解除されます。'),
        ]},
    ]
    prep = _always_on_extra_lines('prep')
    if prep:
        sections.append({'kind': 'items', 'heading': _t('2. Before you start', '2. 使う前の準備'), 'icon': 'CHECKBOX_HLT', 'item_icon': 'DOT', 'lines': prep})
    sections.append({'kind': 'lines', 'heading': _t('3. Steps', '3. 操作の手順'), 'icon': 'PLAY', 'lines': _numbered([
        _t('Open the group, then use the checkbox on the right side of each row. Blue means enabled; disabled means the feature should not run in the background.', 'グループを開き、各行右側のチェックボックスを使います。青い状態は有効、無効状態はその機能をバックグラウンドで動作させないことを意味します。'),
        _t('Tool-module toggles control whether Collection Manager and GP Select can be loaded. Background toggles control optional handlers, menus, hotkeys, and header widgets.', 'ツールモジュールの切り替えはコレクションマネージャーと GP セレクト を読み込めるかを制御します。バックグラウンド項目は、任意ハンドラー、メニュー、ホットキー、ヘッダーウィジェットを制御します。'),
        _t('When N-panel State Save is enabled, changes are written immediately to Smart_Selector_Suite/Smart_Selector_Suite.json. When it is disabled, changes are kept in memory and flushed when the current scene is closed or Save Preferences is executed.', '「Nパネル状態保存」が有効な場合、変更は Smart_Selector_Suite/Smart_Selector_Suite.json へ即時保存されます。無効な場合、変更はメモリ上に保持され、現在のシーンを閉じる時または「プリファレンスを保存」実行時に保存されます。'),
    ])})
    sections.append({'kind': 'items', 'heading': _t('4. Settings and recommended values', '4. 各設定の意味とおすすめの値'), 'icon': 'TOOL_SETTINGS', 'item_icon': 'CHECKBOX_HLT',
                     'lines': [f'{name}: {desc}' if desc else name for name, desc in _always_on_settings_items()]})
    check = _always_on_extra_lines('check')
    if check:
        sections.append({'kind': 'items', 'heading': _t('5. How to check the result', '5. 結果の確かめ方'), 'icon': 'CHECKMARK', 'item_icon': 'DOT', 'lines': check})
    notes = _always_on_extra_lines('notes')
    if notes:
        sections.append({'kind': 'items', 'heading': _t('6. Undo, cautions and limits', '6. 元に戻す方法・注意・限界'), 'icon': 'ERROR', 'item_icon': 'DOT', 'lines': notes})
    return sections


def _merged_catalog() -> dict[str, dict[str, object]]:
    """All help topics.  1.10.51: + help_more (prep / numbered steps / check / notes, new topics) + help_ark (顔 ARKit).

    1.10.52: when help_more replaces the old 'usage' with numbered steps, the old usage text is kept as
    'usage_notes' (drawn under the steps) so nothing of the older help is lost.
    """
    catalog = _common_topics()
    catalog.update(_extra_topics())
    try:
        from . import help_more as _more
        catalog.update(_more.topics(_t))
        for key, extra in _more.supplements(_t).items():
            data = dict(catalog.get(key) or {})
            old_usage = [str(x) for x in (data.get('usage') or []) if x]
            for field, value in extra.items():
                data[field] = value
            if 'usage' in extra and old_usage and 'usage_notes' not in extra:
                data['usage_notes'] = old_usage
            catalog[key] = data
    except Exception:
        pass
    try:
        from . import help_ark as _ark
        catalog.update(_ark.topics(_t))
    except Exception:
        pass
    return catalog


_STEP_RE = re.compile(r'^\s*\d+[.)．、]\s*')


def _numbered(lines: Sequence[str]) -> list[str]:
    """Steps are always shown numbered 1, 2, 3 ... (an existing number at the start is replaced)."""
    out = []
    for index, line in enumerate(lines, start=1):
        text = _STEP_RE.sub('', str(line or ''))
        out.append(f'{index}. {text}')
    return out


def help_topic_ids() -> tuple[str, ...]:
    """Every help key the popup can draw (used by the help draw test and the help export)."""
    return tuple(sorted(set(_merged_catalog().keys()) | {'always_on_toggles'}))


def topic_sections(topic_id: str) -> list[dict[str, object]]:
    """1.10.52: the whole help of one key, in drawing order, as data.

    Each entry: {'kind': 'title'|'lines'|'items', 'heading': str, 'icon': str, 'lines': [str], 'item_icon': str,
    'extra': [str]}.  The popup draws exactly this, and the help export (the manual) writes exactly this, so the
    manual and the add-on cannot drift apart.
    """
    topic = prepare_topic(topic_id)
    if topic == 'always_on_toggles':
        return _always_on_sections()
    catalog = _merged_catalog()
    data = catalog.get(topic) or catalog['smart_selector']
    title = str(data.get('title') or _t('Smart Selector Help', 'スマートセレクター ヘルプ'))
    sections: list[dict[str, object]] = [{'kind': 'title', 'heading': title, 'icon': 'HELP', 'lines': []}]

    # 1.10.51: the six parts of the SmartTools common help spec, always in this order (empty parts are skipped).
    index = 1

    def _add(kind: str, en: str, ja: str, icon: str, lines: list[str], item_icon: str = 'DOT', extra: list[str] | None = None) -> None:
        nonlocal index
        sections.append({'kind': kind, 'heading': _t(f'{index}. {en}', f'{index}. {ja}'), 'icon': icon, 'item_icon': item_icon,
                         'lines': [str(x) for x in lines if x], 'extra': [str(x) for x in (extra or []) if x]})
        index += 1

    overview = list(data.get('overview') or [])
    # 1.10.52: parts of the feature that are not a button or setting of the panel (named items, shown here).
    overview += [f'{n}: {d}' if d else n for n, d in (data.get('concepts') or [])]
    if overview:
        _add('lines', 'What it does', '何をする機能か', 'QUESTION', overview)
    prep = list(data.get('prep') or [])
    if prep:
        _add('items', 'Before you start', '使う前の準備', 'CHECKBOX_HLT', prep)
    usage = list(data.get('usage') or [])
    usage_notes = list(data.get('usage_notes') or [])
    if usage or usage_notes:
        _add('lines', 'Steps', '操作の手順', 'PLAY', _numbered(usage), extra=usage_notes)
    functions = _function_items_for_topic(topic, list(data.get('functions') or []))
    if functions:
        _add('items', 'Buttons', '各ボタンの意味', 'TOOL_SETTINGS', [f'{n}: {d}' if d else n for n, d in functions])
    settings = _setting_items_for_topic(topic, list(data.get('settings') or []))
    if settings:
        _add('items', 'Settings and recommended values', '各設定の意味とおすすめの値', 'PREFERENCES', [f'{n}: {d}' if d else n for n, d in settings])
    check = list(data.get('check') or [])
    if check:
        _add('items', 'How to check the result', '結果の確かめ方', 'CHECKMARK', check)
    notes = list(data.get('notes') or [])
    if notes:
        _add('items', 'Undo, cautions and limits', '元に戻す方法・注意・限界', 'ERROR', notes)
    return sections


def topic_texts(topic_id: str) -> list[str]:
    """The full text of one topic, in drawing order (the help draw test checks that every piece is drawn)."""
    texts: list[str] = []
    for section in topic_sections(topic_id):
        texts.append(str(section.get('heading') or ''))
        texts.extend(str(x) for x in (section.get('lines') or []))
        texts.extend(str(x) for x in (section.get('extra') or []))
    return [t for t in texts if t]


def _draw_sections(layout, sections: Sequence[dict[str, object]]) -> None:
    for section in sections:
        kind = str(section.get('kind') or '')
        heading = str(section.get('heading') or '')
        icon = str(section.get('icon') or 'NONE')
        lines = list(section.get('lines') or [])
        if kind == 'title':
            _wrap(layout, heading, icon=icon)
            continue
        box = _draw_heading(layout, heading, icon)
        if kind == 'items':
            _draw_named_items(box, [(line, '') for line in lines], icon=str(section.get('item_icon') or 'DOT'))
        else:
            _draw_lines(box, lines)
        extra = list(section.get('extra') or [])
        if extra:
            _draw_named_items(box, [(line, '') for line in extra], icon='DOT')


def _draw_topic(layout, topic_id: str) -> None:
    _draw_sections(layout, topic_sections(topic_id))


def prepare_topic(topic_id: str) -> str:
    return str(topic_id or 'smart_selector').strip() or 'smart_selector'


def draw_help(layout, topic_id: str, context=None, dialog_width: int | None = None) -> None:
    global _HELP_DIALOG_WIDTH, _HELP_TEXT_WIDTH_PX
    if dialog_width:
        _HELP_DIALOG_WIDTH = int(dialog_width)
    _HELP_TEXT_WIDTH_PX = _estimate_text_width_px(context, _HELP_DIALOG_WIDTH)
    _draw_topic(layout, prepare_topic(topic_id))


def export_markdown(lang_title: str = '', version: str = '') -> str:
    """1.10.52: the whole help of every key as one Markdown text, in the current UI language.

    Written mechanically from topic_sections(), i.e. from the same data the ? popups draw.
    """
    out: list[str] = []
    head = lang_title or _t('Smart Selector help, full text', 'スマートセレクター ヘルプ全文')
    out.append(f'# {head}' + (f' ({version})' if version else ''))
    out.append('')
    out.append(_t('This file is written mechanically from the ? help popups of the add-on. Every line below is drawn in the add-on in the same words.',
                  'この文書は、アドオンの ？ のヘルプから機械的に書き出した物です。下の文は、アドオンの中で同じ文のまま出ます。'))
    out.append('')
    for key in help_topic_ids():
        out.append(f'<!-- key: {key} -->')
        for section in topic_sections(key):
            kind = str(section.get('kind') or '')
            heading = str(section.get('heading') or '')
            if kind == 'title':
                out.append(f'## {heading}')
                out.append('')
                continue
            out.append(f'### {heading}')
            out.append('')
            for line in section.get('lines') or []:
                out.append(f'- {line}' if kind == 'items' else str(line))
                if kind != 'items':
                    out.append('')
            if kind == 'items' and section.get('lines'):
                out.append('')
            for line in section.get('extra') or []:
                out.append(f'- {line}')
            if section.get('extra'):
                out.append('')
    return '\n'.join(out).rstrip('\n') + '\n'
