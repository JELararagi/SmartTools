# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy
import functools

from bpy.types import (
    Operator,
)

from bpy.props import (
    BoolProperty,
    StringProperty,
    IntProperty
)

# For VARS
from . import internals
from . import qcd_undo

# For FUNCTIONS
from .internals import (
    update_property_group,
    generate_state,
    get_modifiers,
    get_move_selection,
    get_move_active,
    update_qcd_header,
)

from .operator_utils import (
    mode_converter,
    apply_to_children,
    select_collection_objects,
    set_exclude_state,
    isolate_sel_objs_collections,
    disable_sel_objs_collections,
)

def _qcd_atomic(method):
    """Give one QCD user action exactly one undoable Scene-token change."""
    def _finish(context, before, result):
        result_set = set(result or ())
        if 'FINISHED' not in result_set:
            return result
        if not qcd_undo.commit(context, before):
            return {'CANCELLED'}
        return result

    if method.__name__ == 'invoke':
        @functools.wraps(method)
        def invoke_wrapper(self, context, event):
            before = qcd_undo.begin(context)
            return _finish(context, before, method(self, context, event))
        return invoke_wrapper

    @functools.wraps(method)
    def execute_wrapper(self, context):
        before = qcd_undo.begin(context)
        return _finish(context, before, method(self, context))
    return execute_wrapper


try:
    from ..translation_data import report_runtime_message as _sssuite_report
except Exception:
    def _sssuite_report(operator, report_types, message):
        try:
            operator.report(report_types, str(message or ''))
        except Exception:
            pass


class LockedObjects():
    def __init__(self):
        self.objs = []
        self.mode = ""

def get_locked_objs(context):
    # get objects not in object mode
    locked = LockedObjects()
    if context.mode == 'OBJECT':
        return locked

    if context.view_layer.objects.active:
        active = context.view_layer.objects.active
        locked.mode = mode_converter[context.mode]

        for obj in context.view_layer.objects:
            if obj.mode != 'OBJECT':
                if obj.mode not in ['POSE', 'WEIGHT_PAINT'] or obj == active:
                    if obj.mode == active.mode:
                        locked.objs.append(obj)

    return locked


class QCDAllBase():
    meta_op = False
    meta_report = None

    context = None
    view_layer = ""
    history = None
    orig_active_collection = None
    orig_active_object = None
    locked = None

    @classmethod
    def init(cls, context):
        # 履歴の失効はヘッダーの描画でしか見ていなかった。描画を挟まずに押すと
        # コレクションの増減前の履歴を当てて IndexError になる。使う直前にも確かめる。
        # 失効時は check_state が QCDAllBase.clear() を呼ぶので、下の代入より先に行う。
        # Public operations can run before the header refreshes its cached tree.
        # Rebuild RNA references first, without assigning new QCD slots.
        internals.update_collection_tree(context, auto_numerate=False)
        internals.check_state(context, qcd=True)

        cls.context = context
        cls.orig_active_collection = context.view_layer.active_layer_collection
        cls.view_layer = context.view_layer.name
        cls.orig_active_object = context.view_layer.objects.active

        if not cls.view_layer in internals.qcd_history:
            internals.qcd_history[cls.view_layer] = []

        cls.history = internals.qcd_history[cls.view_layer]

        cls.locked = get_locked_objs(context)

    @classmethod
    def apply_history(cls):
        for x, item in enumerate(internals.layer_collections.values()):
            item["ptr"].exclude = cls.history[x]

        # clear rto history
        del internals.qcd_history[cls.view_layer]

        internals.qcd_collection_state.clear()
        cls.history = None

    @classmethod
    def finalize(cls):
        # restore active collection
        cls.context.view_layer.active_layer_collection = cls.orig_active_collection

        # restore active object if possible
        if cls.orig_active_object:
            if cls.orig_active_object.name in cls.context.view_layer.objects:
                cls.context.view_layer.objects.active = cls.orig_active_object

        # restore locked objects back to their original mode
        # needed because of exclude child updates
        if cls.context.view_layer.objects.active:
            if cls.locked.objs:
                bpy.ops.object.mode_set(mode=cls.locked.mode)

    @classmethod
    def clear(cls):
        cls.context = None
        cls.view_layer = ""
        cls.history = None
        cls.orig_active_collection = None
        cls.orig_active_object = None
        cls.locked = None


def _enable_all_qcd_slots_impl(operator, context):
    """Toggle all QCD slots as one Blender undo transaction.

    Both the header meta button and the direct operator call this implementation
    without nesting another UNDO operator.  The transient QCD history remains a
    runtime convenience, while all Blender collection changes are owned by the
    caller's single transaction.
    """
    qab = QCDAllBase

    if not dict(internals.qcd_slots):
        if qab.meta_op:
            qab.meta_report = "No QCD slots."
        else:
            _sssuite_report(operator, {"INFO"}, "No QCD slots.")
        return {'CANCELLED'}

    qab.init(context)
    try:
        if not qab.history:
            keep_history = False

            for laycol in internals.layer_collections.values():
                is_qcd_slot = internals.qcd_slots.contains(name=laycol["name"])
                qab.history.append(laycol["ptr"].exclude)

                if is_qcd_slot and laycol["ptr"].exclude:
                    keep_history = True
                    set_exclude_state(laycol["ptr"], False)

            if not keep_history:
                internals.qcd_history.pop(qab.view_layer, None)
                if qab.meta_op:
                    qab.meta_report = "All QCD slots are already enabled."
                else:
                    _sssuite_report(operator, {"INFO"}, "All QCD slots are already enabled.")
                return {'CANCELLED'}

            internals.qcd_collection_state.clear()
            internals.qcd_collection_state.update(internals.generate_state(qcd=True))
        else:
            qab.apply_history()

        qab.finalize()
        return {'FINISHED'}
    finally:
        qab.clear()


class EnableAllQCDSlotsMeta(Operator):
    '''QCD All Meta Operator'''
    bl_label = "Quick View Toggles"
    # The normal click directly owns the QCD collection changes.  Alt only
    # discards transient history and returns CANCELLED so no empty Blender undo
    # step is produced.
    bl_options = {'UNDO'}
    bl_idname = "view3d.enable_all_qcd_slots_meta"

    @classmethod
    def description(cls, context, properties):
        hotkey_string = (
            "  * LMB - Enable all slots/Restore.\n"
            "  * Alt+LMB - Discard History.\n"
            "  * LMB+Hold - Menu"
            )

        return hotkey_string

    @_qcd_atomic
    def invoke(self, context, event):
        qab = QCDAllBase
        modifiers = get_modifiers(event)

        if modifiers == {"alt"}:
            view_layer_name = str(getattr(context.view_layer, "name", "") or "")
            if view_layer_name not in internals.qcd_history:
                return {'CANCELLED'}
            internals.qcd_history.pop(view_layer_name, None)
            internals.qcd_collection_state.clear()
            qab.clear()
            update_qcd_header()
            return {'FINISHED'}

        qab.meta_op = True
        try:
            result = _enable_all_qcd_slots_impl(self, context)
            if qab.meta_report:
                _sssuite_report(self, {"INFO"}, qab.meta_report)
                qab.meta_report = None
            return result
        finally:
            qab.meta_op = False
            qab.clear()


class EnableAllQCDSlots(Operator):
    '''Toggles between the current state and all enabled'''
    bl_label = "Enable All QCD Slots"
    bl_description = 'Function: Toggles between the current state and all enabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.enable_all_qcd_slots"
    bl_options = {'UNDO'}

    @_qcd_atomic
    def execute(self, context):
        return _enable_all_qcd_slots_impl(self, context)


class EnableAllQCDSlotsIsolated(Operator):
    '''Toggles between the current state and all enabled (non-QCD collections disabled)'''
    bl_label = "Enable All QCD Slots Isolated"
    bl_description = 'Function: Toggles between the current state and all enabled (non-QCD collections disabled). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.enable_all_qcd_slots_isolated"
    bl_options = {'UNDO'}

    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase

        # validate qcd slots
        if not dict(internals.qcd_slots):
            _sssuite_report(self,{"INFO"}, "No QCD slots.")

            return {'CANCELLED'}

        qab.init(context)

        if qab.locked.objs and not internals.qcd_slots.object_in_slots(qab.orig_active_object):
            # clear rto history
            del internals.qcd_history[qab.view_layer]
            qab.clear()

            _sssuite_report(self,{"WARNING"}, "Cannot execute.  The active object would be lost.")

            return {'CANCELLED'}

        if not qab.history:
            keep_history = False

            for laycol in internals.layer_collections.values():
                is_qcd_slot = internals.qcd_slots.contains(name=laycol["name"])

                qab.history.append(laycol["ptr"].exclude)

                if is_qcd_slot and laycol["ptr"].exclude:
                    keep_history = True
                    set_exclude_state(laycol["ptr"], False)

                if not is_qcd_slot and not laycol["ptr"].exclude:
                    keep_history = True
                    set_exclude_state(laycol["ptr"], True)


            if not keep_history:
                # clear rto history
                del internals.qcd_history[qab.view_layer]
                qab.clear()

                _sssuite_report(self,{"INFO"}, "All QCD slots are already enabled and isolated.")
                return {'CANCELLED'}

            internals.qcd_collection_state.clear()
            internals.qcd_collection_state.update(internals.generate_state(qcd=True))

        else:
            qab.apply_history()

        qab.finalize()

        return {'FINISHED'}

class IsolateSelectedObjectsCollections(Operator):
    '''Isolate collections (via EC) that contain the selected objects'''
    bl_label = "Isolate Selected Objects Collections"
    bl_options = {'UNDO'}
    bl_description = 'Function: Isolate collections (via EC) that contain the selected objects. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.isolate_selected_objects_collections"

    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase
        qab.init(context)

        use_active = bool(context.mode != 'OBJECT')

        # isolate
        error = isolate_sel_objs_collections(qab.view_layer, "exclude", "QCD", use_active=use_active)

        if error:
            qab.clear()
            _sssuite_report(self,{"WARNING"}, error)
            return {'CANCELLED'}

        qab.finalize()

        internals.qcd_collection_state.clear()
        internals.qcd_collection_state.update(internals.generate_state(qcd=True))

        return {'FINISHED'}


class DisableSelectedObjectsCollections(Operator):
    '''Disable all collections that contain the selected objects'''
    bl_label = "Disable Selected Objects Collections"
    bl_options = {'UNDO'}
    bl_description = 'Function: Disable all collections that contain the selected objects. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.disable_selected_objects_collections"

    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase
        qab.init(context)

        if qab.locked.objs:
            # clear rto history
            del internals.qcd_history[qab.view_layer]
            qab.clear()

            _sssuite_report(self,{"WARNING"}, "Can only be executed in Object Mode")
            return {'CANCELLED'}

        # disable
        error = disable_sel_objs_collections(qab.view_layer, "exclude", "QCD")

        if error:
            qab.clear()
            _sssuite_report(self,{"WARNING"}, error)
            return {'CANCELLED'}

        qab.finalize()

        internals.qcd_collection_state.clear()
        internals.qcd_collection_state.update(internals.generate_state(qcd=True))

        return {'FINISHED'}


class DisableAllNonQCDSlots(Operator):
    '''Toggles between the current state and all non-QCD collections disabled'''
    bl_label = "Disable All Non QCD Slots"
    bl_description = 'Function: Toggles between the current state and all non-QCD collections disabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.disable_all_non_qcd_slots"
    bl_options = {'UNDO'}


    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase

        # validate qcd slots
        if not dict(internals.qcd_slots):
            _sssuite_report(self,{"INFO"}, "No QCD slots.")

            return {'CANCELLED'}

        qab.init(context)

        if qab.locked.objs and not internals.qcd_slots.object_in_slots(qab.orig_active_object):
            # clear rto history
            del internals.qcd_history[qab.view_layer]
            qab.clear()

            _sssuite_report(self,{"WARNING"}, "Cannot execute.  The active object would be lost.")

            return {'CANCELLED'}

        if not qab.history:
            keep_history = False

            for laycol in internals.layer_collections.values():
                is_qcd_slot = internals.qcd_slots.contains(name=laycol["name"])

                qab.history.append(laycol["ptr"].exclude)

                if not is_qcd_slot and not laycol["ptr"].exclude:
                    keep_history = True
                    set_exclude_state(laycol["ptr"], True)

            if not keep_history:
                # clear rto history
                del internals.qcd_history[qab.view_layer]
                qab.clear()

                _sssuite_report(self,{"INFO"}, "All non QCD slots are already disabled.")
                return {'CANCELLED'}

            internals.qcd_collection_state.clear()
            internals.qcd_collection_state.update(internals.generate_state(qcd=True))

        else:
            qab.apply_history()

        qab.finalize()

        return {'FINISHED'}


class DisableAllCollections(Operator):
    '''Toggles between the current state and all collections disabled'''
    bl_label = "Disable All collections"
    bl_description = 'Function: Toggles between the current state and all collections disabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.disable_all_collections"
    bl_options = {'UNDO'}


    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase

        qab.init(context)

        if qab.locked.objs:
            # clear rto history
            del internals.qcd_history[qab.view_layer]
            qab.clear()

            _sssuite_report(self,{"WARNING"}, "Cannot execute.  The active object would be lost.")

            return {'CANCELLED'}

        if not qab.history:
            for laycol in internals.layer_collections.values():

                qab.history.append(laycol["ptr"].exclude)

            if all(qab.history): # no collections are enabled
                # clear rto history
                del internals.qcd_history[qab.view_layer]
                qab.clear()

                _sssuite_report(self,{"INFO"}, "All collections are already disabled.")
                return {'CANCELLED'}

            for laycol in internals.layer_collections.values():
                laycol["ptr"].exclude = True

            internals.qcd_collection_state.clear()
            internals.qcd_collection_state.update(internals.generate_state(qcd=True))

        else:
            qab.apply_history()

        qab.finalize()

        return {'FINISHED'}


class SelectAllQCDObjects(Operator):
    '''Select all objects in QCD slots'''
    bl_label = "Select All QCD Objects"
    bl_description = 'Function: Select all objects in QCD slots. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.select_all_qcd_objects"
    bl_options = {'UNDO'}


    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase

        if context.mode != 'OBJECT':
            _sssuite_report(self,{"WARNING"}, "Can only be executed in Object Mode")
            return {'CANCELLED'}

        if not context.selectable_objects:
            if qab.meta_op:
                qab.meta_report = "No objects present to select."

            else:
                _sssuite_report(self,{"INFO"}, "No objects present to select.")

            return {'CANCELLED'}

        orig_selected_objects = context.selected_objects

        # Keep QCD selection inside this top-level UNDO operator. Direct RNA
        # deselection avoids a nested Object Select All undo transaction.
        for obj in tuple(getattr(context, 'selected_objects', ()) or ()):
            try:
                obj.select_set(False)
            except Exception:
                pass

        for slot, collection_name in internals.qcd_slots:
            select_collection_objects(
                is_master_collection=False,
                collection_name=collection_name,
                replace=False,
                nested=False,
                selection_state=True
                )

        if context.selected_objects == orig_selected_objects:
            for slot, collection_name in internals.qcd_slots:
                select_collection_objects(
                    is_master_collection=False,
                    collection_name=collection_name,
                    replace=False,
                    nested=False,
                    selection_state=False
                    )


        return {'FINISHED'}


class DiscardQCDHistory(Operator):
    '''Discard QCD History'''
    bl_label = "Discard History"
    # The hidden Scene token makes transient history a real one-click undo state.
    bl_options = {'UNDO'}
    bl_description = 'Function: Discard QCD History. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.discard_qcd_history"

    @_qcd_atomic
    def execute(self, context):
        qab = QCDAllBase
        view_layer = context.view_layer.name

        if view_layer not in internals.qcd_history:
            return {'CANCELLED'}

        del internals.qcd_history[view_layer]
        qab.clear()

        # Update header UI without creating an empty Blender undo step.
        update_qcd_header()
        return {'FINISHED'}


def move_to_qcd_slot_impl(context, slot, toggle=False):
    """Apply one QCD move and report whether Blender data changed.

    The modal QCD widget calls this implementation directly so one key press can
    create exactly one explicit undo boundary.  The public operator below uses
    the same function and lets Blender own the normal operator undo transaction.
    """
    selected_objects = tuple(get_move_selection() or ())
    active_object = get_move_active()
    slot = str(slot or "")
    slot_name = internals.qcd_slots.get_name(slot)
    if not slot_name or not selected_objects:
        return False

    entry = internals.layer_collections.get(slot_name)
    qcd_laycol = entry.get("ptr") if isinstance(entry, dict) else None
    if qcd_laycol is None:
        return False

    target_objects = qcd_laycol.collection.objects
    changed = False

    if toggle:
        if active_object is None:
            active_object = selected_objects[0]
        active_in_target = active_object.name in target_objects
        if not active_in_target:
            for obj in selected_objects:
                if obj.name not in target_objects:
                    target_objects.link(obj)
                    changed = True
        else:
            for obj in selected_objects:
                if obj.name not in target_objects:
                    continue
                # Never leave an object without a collection.
                if len(obj.users_collection) <= 1:
                    continue
                target_objects.unlink(obj)
                changed = True
    else:
        for obj in selected_objects:
            if obj.name not in target_objects:
                target_objects.link(obj)
                changed = True

            # users_collection changes while unlinking, therefore iterate over a
            # stable copy.  Non-QCD collections are intentionally removed too,
            # preserving the original "move to slot" behaviour.
            for collection in tuple(obj.users_collection):
                if collection == qcd_laycol.collection:
                    continue
                collection.objects.unlink(obj)
                changed = True

    if not changed:
        return False

    internals.move_triggered = True
    if not context.active_object and active_object is not None:
        try:
            context.view_layer.objects.active = active_object
        except RuntimeError:
            pass

    update_qcd_header()
    return True


def view_qcd_slot_impl(context, slot, toggle=False):
    """Apply one QCD visibility action without nesting another UNDO operator."""
    slot_name = internals.qcd_slots.get_name(str(slot or ""))
    if not slot_name:
        return False
    entry = internals.layer_collections.get(slot_name)
    qcd_laycol = entry.get("ptr") if isinstance(entry, dict) else None
    if qcd_laycol is None:
        return False

    orig_active_object = context.view_layer.objects.active
    locked = get_locked_objs(context)

    if toggle:
        if not qcd_laycol.exclude:
            if not set(locked.objs).isdisjoint(qcd_laycol.collection.objects):
                return False
        set_exclude_state(qcd_laycol, not qcd_laycol.exclude)
    else:
        for laycol in internals.layer_collections.values():
            if laycol["name"] != qcd_laycol.name:
                if set(locked.objs).isdisjoint(laycol["ptr"].collection.objects):
                    laycol["ptr"].exclude = True
                else:
                    laycol["ptr"].exclude = False
        qcd_laycol.exclude = False

        def exclude_all_children(layer_collection):
            if set(locked.objs).isdisjoint(layer_collection.collection.objects):
                layer_collection.exclude = True
            else:
                layer_collection.exclude = False

        apply_to_children(qcd_laycol, exclude_all_children)

    if orig_active_object:
        try:
            if orig_active_object.name in context.view_layer.objects:
                context.view_layer.objects.active = orig_active_object
        except RuntimeError:
            pass

    if context.view_layer.objects.active and locked.objs:
        try:
            bpy.ops.object.mode_set(mode=locked.mode)
        except Exception:
            pass

    try:
        context.view_layer.active_layer_collection = qcd_laycol
    except Exception:
        pass

    update_qcd_header()
    view_layer_name = context.view_layer.name
    internals.rto_history["exclude"].pop(view_layer_name, None)
    internals.rto_history["exclude_all"].pop(view_layer_name, None)
    return True


class MoveToQCDSlot(Operator):
    '''Move object(s) to QCD slot'''
    bl_label = "Move To QCD Slot"
    bl_description = 'Function: Move object(s) to QCD slot. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.move_to_qcd_slot"
    bl_options = {'UNDO'}

    slot: StringProperty(description='Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    toggle: BoolProperty(description='Function: supplies the Toggle parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @_qcd_atomic
    def execute(self, context):
        return {'FINISHED'} if move_to_qcd_slot_impl(context, self.slot, self.toggle) else {'CANCELLED'}


class ViewMoveQCDSlot(Operator):
    bl_label = ""
    bl_idname = "view3d.view_move_qcd_slot"
    # This is the top-level click owner; helper functions avoid nested undo operators.
    bl_options = {'UNDO'}

    slot: StringProperty(description='Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        slot_name = internals.qcd_slots.get_name(properties.slot)
        slot_string = f"QCD Slot {properties.slot}: \"{slot_name}\"\n"
        selection_hotkeys = ""

        if context.mode == 'OBJECT':
            selection_hotkeys = (
                ".\n"
                "  * Alt+LMB - Select objects in slot.\n"
                "  * Alt+Shift+LMB - Toggle objects' selection for slot"
                )

        hotkey_string = (
            "  * LMB - Isolate slot.\n"
            "  * Shift+LMB - Toggle slot.\n"
            "  * Ctrl+LMB - Move objects to slot.\n"
            "  * Ctrl+Shift+LMB - Toggle objects' slot"
            + selection_hotkeys
            )

        return f"{slot_string}{hotkey_string}"

    @_qcd_atomic
    def invoke(self, context, event):
        modifiers = get_modifiers(event)

        if modifiers == {"shift"}:
            changed = view_qcd_slot_impl(context, self.slot, toggle=True)
        elif modifiers == {"ctrl"}:
            changed = move_to_qcd_slot_impl(context, self.slot, toggle=False)
        elif modifiers == {"ctrl", "shift"}:
            changed = move_to_qcd_slot_impl(context, self.slot, toggle=True)
        elif modifiers == {"alt"}:
            before = {obj.name for obj in tuple(getattr(context, "selected_objects", ()) or ())}
            select_collection_objects(
                is_master_collection=False,
                collection_name=internals.qcd_slots.get_name(self.slot),
                replace=True,
                nested=False,
            )
            after = {obj.name for obj in tuple(getattr(context, "selected_objects", ()) or ())}
            changed = before != after
        elif modifiers == {"alt", "shift"}:
            before = {obj.name for obj in tuple(getattr(context, "selected_objects", ()) or ())}
            select_collection_objects(
                is_master_collection=False,
                collection_name=internals.qcd_slots.get_name(self.slot),
                replace=False,
                nested=False,
            )
            after = {obj.name for obj in tuple(getattr(context, "selected_objects", ()) or ())}
            changed = before != after
        else:
            changed = view_qcd_slot_impl(context, self.slot, toggle=False)

        return {'FINISHED'} if changed else {'CANCELLED'}


class ViewQCDSlot(Operator):
    '''View objects in QCD slot'''
    bl_label = "View QCD Slot"
    bl_description = 'Function: View objects in QCD slot. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.view_qcd_slot"
    bl_options = {'UNDO'}

    slot: StringProperty(description='Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    toggle: BoolProperty(description='Function: supplies the Toggle parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @_qcd_atomic
    def execute(self, context):
        return {'FINISHED'} if view_qcd_slot_impl(context, self.slot, self.toggle) else {'CANCELLED'}


class UnassignedQCDSlot(Operator):
    bl_label = ""
    bl_idname = "view3d.unassigned_qcd_slot"
    bl_options = {'UNDO'}

    slot: StringProperty(description='Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        slot_string = f"Unassigned QCD Slot {properties.slot}:\n"

        hotkey_string = (
            "  * LMB - Create slot.\n"
            "  * Shift+LMB - Create and isolate slot.\n"
            "  * Ctrl+LMB - Create and move objects to slot.\n"
            "  * Ctrl+Shift+LMB - Create and add objects to slot"
            )

        return f"{slot_string}{hotkey_string}"

    @_qcd_atomic
    def invoke(self, context, event):
        modifiers = get_modifiers(event)

        new_collection = bpy.data.collections.new(f"Collection {self.slot}")
        context.scene.collection.children.link(new_collection)
        internals.qcd_slots.add_slot(f"{self.slot}", new_collection.name)

        # Refresh the Collection Manager list without auto-filling unrelated
        # collections into the remaining QCD slots.  This user action creates
        # exactly the requested slot and must remain one atomic Undo state.
        update_property_group(context, auto_numerate=False)

        if modifiers == {"shift"}:
            view_qcd_slot_impl(context, self.slot, toggle=False)
        elif modifiers == {"ctrl"}:
            move_to_qcd_slot_impl(context, self.slot, toggle=False)
        elif modifiers == {"ctrl", "shift"}:
            move_to_qcd_slot_impl(context, self.slot, toggle=True)

        return {'FINISHED'}


class CreateAllQCDSlots(Operator):
    bl_label = "Create All QCD Slots"
    bl_description = 'Function: creates any missing QCD slot collections until all 20 QCD slots exist. How to use: run this when the scene needs a complete QCD slot set; existing slot assignments are kept and only missing slots are created.'
    bl_idname = "view3d.create_all_qcd_slots"
    bl_options = {'UNDO'}

    @_qcd_atomic
    def execute(self, context):
        created = 0
        for slot_number in range(1, 21):
            if not internals.qcd_slots.get_name(f"{slot_number}"):
                new_collection = bpy.data.collections.new(f"Collection {slot_number}")
                context.scene.collection.children.link(new_collection)
                internals.qcd_slots.add_slot(f"{slot_number}", new_collection.name)
                created += 1

        if not created:
            return {'CANCELLED'}

        # update tree view property
        update_property_group(context)
        return {'FINISHED'}


class RenumerateQCDSlots(Operator):
    bl_label = "Renumber QCD Slots"
    bl_description = 'Function: renumbers QCD slot assignments. How to use: click to renumber from slot 1 in breadth-first order; Ctrl uses linear order, Alt resets assignments, and Shift constrains the operation to the current branch.'
    bl_idname = "view3d.renumerate_qcd_slots"
    bl_options = {'UNDO'}

    @_qcd_atomic
    def invoke(self, context, event):
        modifiers = get_modifiers(event)

        beginning = False
        depth_first = False
        constrain = False

        if 'alt' in modifiers:
            beginning=True

        if 'ctrl' in modifiers:
            depth_first=True

        if 'shift' in modifiers:
            constrain=True

        before_slots = dict(internals.qcd_slots)
        before_overrides = set(internals.qcd_slots.overrides)

        internals.qcd_slots.renumerate(
            beginning=beginning,
            depth_first=depth_first,
            constrain=constrain,
        )

        if (before_slots == dict(internals.qcd_slots)
                and before_overrides == set(internals.qcd_slots.overrides)):
            return {'CANCELLED'}

        update_property_group(context)
        return {'FINISHED'}
