# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from . import loader as loader, ui_runtime as ui_runtime

_REGISTERED = False
_RESTORE_LOADED_ALIASES: tuple[str, ...] = ()


def is_registered() -> bool:
    return bool(_REGISTERED)


def register() -> None:
    global _REGISTERED, _RESTORE_LOADED_ALIASES
    if _REGISTERED:
        return
    loader.register_all()
    try:
        ui_runtime.mark_record_cache_dirty()
    except Exception:
        pass
    for alias in _RESTORE_LOADED_ALIASES:
        try:
            loader.ensure_record_loaded(alias)
        except Exception:
            pass
    _RESTORE_LOADED_ALIASES = ()
    ui_runtime.register()
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED, _RESTORE_LOADED_ALIASES
    if not _REGISTERED:
        return
    loaded_aliases: list[str] = []
    for record in loader.get_records():
        try:
            if str(record.get('status') or '') == 'loaded':
                alias = str((record.get('spec') or {}).get('alias') or '').strip()
                if alias:
                    loaded_aliases.append(alias)
        except Exception:
            pass
    _RESTORE_LOADED_ALIASES = tuple(loaded_aliases)
    ui_runtime.unregister()
    loader.unregister_all()
    try:
        ui_runtime.mark_record_cache_dirty()
    except Exception:
        pass
    _REGISTERED = False


def rebuild_if_registered(context=None) -> None:
    global _REGISTERED
    if not _REGISTERED:
        return
    loaded_aliases = []
    for record in loader.get_records():
        try:
            if str(record.get('status') or '') == 'loaded':
                alias = str((record.get('spec') or {}).get('alias') or '').strip()
                if alias:
                    loaded_aliases.append(alias)
        except Exception:
            pass

    ui_runtime.unregister()
    loader.unregister_all()
    try:
        ui_runtime.mark_record_cache_dirty()
    except Exception:
        pass
    loader.register_all()
    try:
        ui_runtime.mark_record_cache_dirty()
    except Exception:
        pass
    for alias in loaded_aliases:
        try:
            loader.ensure_record_loaded(alias)
        except Exception:
            pass
    ui_runtime.register()
    try:
        ui_runtime.mark_record_cache_dirty()
    except Exception:
        pass
    try:
        ui_runtime.refresh_all_suites(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    _REGISTERED = True
