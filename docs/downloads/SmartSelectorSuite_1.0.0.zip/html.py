# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Redistribution, modification, resale, or relicensing is prohibited without
# explicit permission from the rights holder.
# ------------------------------------------------------------------------------
# html.py

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en" translate="no" class="notranslate">
<head>
    <meta charset="UTF-8">
    <meta name="google" content="notranslate">
    <meta http-equiv="Content-Language" content="en,ja">
    <title>Smart Selector</title>
    <script>
        (function(){
            const p = new URLSearchParams(window.location.search);
            const lang = ((p.get('lang') || 'ja').toLowerCase().startsWith('ja')) ? 'ja' : 'en';
            document.documentElement.lang = lang === 'ja' ? 'ja' : 'en';
            document.title = `Smart Selector [${lang === 'ja' ? '未保存' : 'Unsaved'}]`;
        })();
    </script>
    <style>
        /* === Modern UI Colors & Variables === */
        :root {
            --panel-width: 380px;
            --bg-color: #1e1e1e; --panel-bg: #252526; --toolbar-bg: #333333; --text-color: #d4d4d4;
            --btn-bg: #3e3e42; --btn-hover: #505050; --border-color: #454545; --input-bg: #1e1e1e;
            --accent-color: #6f8f5f; --accent-hover: #7da66a;
            --hover-color: #f1c40f; --select-color: #e74c3c;
            --hover-overlay-color: rgba(241, 196, 15, 0.25); --select-overlay-color: rgba(231, 76, 60, 0.25);
            --hover-filter: drop-shadow(0 0 2px var(--hover-color)) drop-shadow(0 0 4px var(--hover-color));
            --select-filter: drop-shadow(0 0 3px var(--select-color)) drop-shadow(0 0 6px var(--select-color));
            --tab-bar-bg: #2d2d2d; --tab-bg: #1e1e1e; --tab-color: #aaa; --tab-active-bg: #0e639c; --tab-active-color: #ffffff;
            --canvas-bg: #111111; --workspace-bg: #2b2b2b;
        }

        * { box-sizing: border-box; }
        body { background-color: var(--canvas-bg); color: var(--text-color); font-family: 'Segoe UI', Tahoma, sans-serif; margin: 0; overflow: hidden; user-select: none; }

        /* Toolbar */
        #toolbar { position: absolute; top: 0; left: 0; width: 100%; height: 44px; background: var(--toolbar-bg); padding: 0 16px; display: flex; align-items: center; gap: 10px; z-index: 1000; border-bottom: 1px solid var(--border-color); box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        button, select, input[type="text"], input[type="number"] { background: var(--btn-bg); color: var(--text-color); border: 1px solid var(--border-color); padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 12px; outline: none; transition: background 0.1s;}
        button:hover, select:hover { background: var(--btn-hover); }
        input:focus, select:focus { border-color: var(--accent-color); }

        /* Tabs */
        #tab-bar { position: absolute; top: 44px; left: 0; right: var(--panel-width); height: 32px; background: var(--tab-bar-bg); display: flex; align-items: flex-end; border-bottom: 1px solid var(--border-color); z-index: 900; overflow-x: auto; scrollbar-width: none; transition: right 0.1s; padding-left: 12px;}
        #tab-bar::-webkit-scrollbar { display: none; }
        .play-mode-tab { top: 0 !important; right: 0 !important; }
        .tab { background: var(--tab-bg); color: var(--tab-color); border: 1px solid var(--border-color); border-bottom: none; padding: 6px 14px; margin-right: 4px; border-radius: 6px 6px 0 0; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 12px; white-space: nowrap; transition: background 0.2s;}
        .tab.active { background: var(--tab-active-bg); color: var(--tab-active-color); border-color: var(--tab-active-bg); font-weight: bold; }
        .tab-close { font-weight: bold; cursor: pointer; opacity: 0.5; padding: 0 4px;} .tab-close:hover { opacity: 1; color: #ff4d4d; }
        #add-tab-btn { background: transparent; border: none; font-size: 18px; color: var(--text-color); cursor: pointer; padding: 0 8px; margin-bottom: 2px;}

        /* Canvas */
        #canvas-viewport { position: absolute; top: 76px; left: 0; right: var(--panel-width); bottom: 0; background-color: var(--canvas-bg); overflow: auto; transition: right 0.1s; }
        .play-mode-canvas { top: 32px !important; right: 0 !important; }
        .play-mode-canvas-notab { top: 0px !important; right: 0 !important; }

        #scroll-content { position: relative; min-width: 100%; min-height: 100%; overflow: hidden;}
        #workspace { position: absolute; top: 0; left: 0; transform-origin: 0 0; background-color: var(--workspace-bg); box-shadow: 0 0 15px rgba(0,0,0,0.5);}

        #grid-layer { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; display: none; z-index: 0; }
        body:not(.edit-mode) #grid-layer { display: none !important; }

        #bg-layer { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; border: 1px solid transparent; }

        /* Properties Panel (Right Side) */
        #properties { position: absolute; top: 44px; right: 0; left: auto; width: var(--panel-width); height: calc(100vh - 44px); background: var(--panel-bg); border-left: 1px solid var(--border-color); padding: 14px; overflow-y: auto; overflow-x: hidden; display: block; z-index: 1000; font-size: 12px; transition: width 0.1s;}
        .properties-fullscreen { display: none !important; }

        /* Resizer */
        #panel-resizer { position: absolute; top: 0; left: 0; width: 6px; height: 100%; cursor: ew-resize; z-index: 1010; transition: background 0.2s; }
        #panel-resizer:hover, .resizing-panel #panel-resizer { background: var(--accent-color); }

        .prop-section { margin-bottom: 16px; border: 1px solid var(--border-color); border-radius: 6px; overflow: hidden; background: var(--bg-color); }
        .prop-section summary { background: var(--toolbar-bg); padding: 10px 12px; font-size: 13px; font-weight: bold; cursor: pointer; outline: none; }
        .prop-section summary:hover { background: var(--btn-hover); }
        .prop-section-content { padding: 12px; display: flex; flex-direction: column; gap: 8px; }

        /* Layout Fixes */
        .prop-row { display: flex; align-items: center; gap: 6px; width: 100%; flex-wrap: nowrap; }
        .prop-row.wrap-safe { align-items: flex-start; flex-wrap: wrap; }
        .prop-row.wrap-safe .prop-label { flex: 0 0 85px; }
        .prop-row.wrap-safe .prop-controls { flex: 1 1 220px; flex-wrap: wrap; row-gap: 6px; }
        .prop-label { flex: 0 0 85px; font-size: 11px; opacity: 0.9; text-align: left; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;}
        .prop-controls { display: flex; flex: 1 1 auto; gap: 4px; align-items: center; min-width: 0; flex-wrap: nowrap;}
        .prop-controls input[type="number"], .prop-controls input[type="text"], .prop-controls select { flex: 1 1 0; min-width: 20px; height: 24px; box-sizing: border-box; }
        .prop-controls input[type="color"] { width: 32px; height: 24px; padding: 0; cursor: pointer; flex-shrink: 0; border: 1px solid var(--border-color); border-radius: 4px; }

        .checkbox-label { display: flex; align-items: center; gap: 4px; font-size: 11px; cursor: pointer; white-space: nowrap; flex-shrink: 0;}
        .checkbox-label input[type="checkbox"] { margin: 0; cursor: pointer; accent-color: var(--accent-color); flex-shrink: 0;}
        .btn-flex { flex: 1 1 0; min-width: 0; padding: 6px 4px; text-align: center; }
        /* Borderless, high-coverage custom vector toolbar icons */
        :root {
            --sss-ico-add: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M13%202h6v11h11v6H19v11h-6V19H2v-6h11z'/%3E%3C/svg%3E");
            --sss-ico-slider: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M5%207h22v4H5zM5%2021h22v4H5z'/%3E%3Ccircle%20fill='black'%20cx='12'%20cy='9'%20r='6'/%3E%3Ccircle%20fill='black'%20cx='22'%20cy='23'%20r='6'/%3E%3C/svg%3E");
            --sss-ico-save: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%203h20l4%204v22H4z'/%3E%3Cpath%20fill='white'%20d='M8%205h13v8H8zM9%2019h14v8H9z'/%3E%3Cpath%20fill='black'%20d='M18%206h3v6h-3z'/%3E%3C/svg%3E");
            --sss-ico-saveas: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%203h19l5%205v21H4z'/%3E%3Cpath%20fill='white'%20d='M8%205h12v7H8zM9%2020h8v6H9z'/%3E%3Cpath%20fill='black'%20d='M19%2024l8-8%203%203-8%208-4%201z'/%3E%3C/svg%3E");
            --sss-ico-pin: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M12%202h13l-4%208%205%205-7%203-5%2012-2-10-10-2%2012-5%203-7z'/%3E%3C/svg%3E");
            --sss-ico-undo: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M14%206v6h6c5%200%208%203%208%207s-3%207-8%207H9v-5h11c2%200%203-1%203-2s-1-2-3-2h-6v6L4%2014z'/%3E%3C/svg%3E");
            --sss-ico-redo: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M18%206v6h-6c-5%200-8%203-8%207s3%207%208%207h11v-5H12c-2%200-3-1-3-2s1-2%203-2h6v6l10-9z'/%3E%3C/svg%3E");
            --sss-ico-copy: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M9%203h16v20H9zM5%209h4v17h13v4H5z'/%3E%3C/svg%3E");
            --sss-ico-cut: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M7%204a5%205%200%20110%2010A5%205%200%20017%204zm18%200a5%205%200%20110%2010%205%205%200%20010-10zM8%2019l16%2010%202-3L10%2016zm16-3L8%2026l2%203%2016-10z'/%3E%3C/svg%3E");
            --sss-ico-paste: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M11%203h10l2%204h5v22H4V7h5z'/%3E%3Cpath%20fill='white'%20d='M9%2011h14v3H9zm0%206h14v3H9zm0%206h10v3H9z'/%3E%3C/svg%3E");
            --sss-ico-align-left: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%204h4v24H4zM10%206h18v5H10zm0%208h13v5H10zm0%208h18v5H10z'/%3E%3C/svg%3E");
            --sss-ico-align-center: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M14%203h4v26h-4zM7%206h18v5H7zm3%208h12v5H10zm-3%208h18v5H7z'/%3E%3C/svg%3E");
            --sss-ico-align-right: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M24%204h4v24h-4zM4%206h18v5H4zm5%208h13v5H9zM4%2022h18v5H4z'/%3E%3C/svg%3E");
            --sss-ico-align-top: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%204h24v4H4zm2%206h5v18H6zm8%200h5v12h-5zm8%200h5v18h-5z'/%3E%3C/svg%3E");
            --sss-ico-align-middle: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M3%2014h26v4H3zM6%205h5v22H6zm8%208h5v6h-5zm8-8h5v22h-5z'/%3E%3C/svg%3E");
            --sss-ico-align-bottom: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%2024h24v4H4zM6%204h5v18H6zm8%206h5v12h-5zm8-6h5v18h-5z'/%3E%3C/svg%3E");
            --sss-ico-dist-h: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M3%205h4v22H3zm22%200h4v22h-4zM10%2014h12v4H10zM10%2010l-6%206%206%206zm12%200l6%206-6%206z'/%3E%3C/svg%3E");
            --sss-ico-dist-v: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M5%203h22v4H5zm0%2022h22v4H5zM14%2010h4v12h-4zM10%2010l6-6%206%206zm0%2012l6%206%206-6z'/%3E%3C/svg%3E");
            --sss-ico-action: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M18%202l2%205%205-1%202%205-4%203%204%203-2%205-5-1-2%205h-6l-2-5-5%201-2-5%204-3-4-3%202-5%205%201%202-5z'/%3E%3Ccircle%20fill='white'%20cx='15'%20cy='16'%20r='5'/%3E%3C/svg%3E");
            --sss-ico-lock: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M8%2013h16v16H8zM12%2013V9a4%204%200%20118%200v4h-4V9a2%202%200%2010-4%200v4z'/%3E%3C/svg%3E");
            --sss-ico-trash: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M8%209h16l-1%2020H9zM6%205h20v4H6zm6-3h8v3h-8z'/%3E%3Cpath%20fill='white'%20d='M12%2013h3v12h-3zm5%200h3v12h-3z'/%3E%3C/svg%3E");
            --sss-ico-capture: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M4%209h6l3-4h6l3%204h6v18H4z'/%3E%3Ccircle%20fill='white'%20cx='16'%20cy='18'%20r='7'/%3E%3Ccircle%20fill='black'%20cx='16'%20cy='18'%20r='4'/%3E%3C/svg%3E");
            --sss-ico-apply: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M12%2023L3%2014l4-4%205%205L25%203l4%204z'/%3E%3C/svg%3E");
            --sss-ico-cancel: url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2032%2032'%3E%3Cpath%20fill='black'%20d='M7%203l9%209%209-9%204%204-9%209%209%209-4%204-9-9-9%209-4-4%209-9-9-9z'/%3E%3C/svg%3E");
        }
        button[data-ui-icon] { display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
        button[data-ui-icon]::before { content: ''; display: inline-block; width: 1.2em; height: 1.2em; flex: 0 0 1.2em; background: currentColor; -webkit-mask: var(--sss-current-icon) center / contain no-repeat; mask: var(--sss-current-icon) center / contain no-repeat; }
        button.icon-only { min-width: 30px; padding: 3px; aspect-ratio: 1 / 1; }
        button.icon-only::before { width: 22px; height: 22px; flex-basis: 22px; }
        button.toolbar-icon-btn::before, button.add-icon-btn::before, button.ctx-btn::before { width: 18px; height: 18px; flex-basis: 18px; }
        button[data-ui-icon="add"] { --sss-current-icon: var(--sss-ico-add); }
        button[data-ui-icon="slider"] { --sss-current-icon: var(--sss-ico-slider); }
        button[data-ui-icon="save"] { --sss-current-icon: var(--sss-ico-save); }
        button[data-ui-icon="saveas"] { --sss-current-icon: var(--sss-ico-saveas); }
        button[data-ui-icon="pin"] { --sss-current-icon: var(--sss-ico-pin); }
        button[data-ui-icon="undo"] { --sss-current-icon: var(--sss-ico-undo); }
        button[data-ui-icon="redo"] { --sss-current-icon: var(--sss-ico-redo); }
        button[data-ui-icon="copy"] { --sss-current-icon: var(--sss-ico-copy); }
        button[data-ui-icon="cut"] { --sss-current-icon: var(--sss-ico-cut); }
        button[data-ui-icon="paste"] { --sss-current-icon: var(--sss-ico-paste); }
        button[data-ui-icon="align-left"] { --sss-current-icon: var(--sss-ico-align-left); }
        button[data-ui-icon="align-center"] { --sss-current-icon: var(--sss-ico-align-center); }
        button[data-ui-icon="align-right"] { --sss-current-icon: var(--sss-ico-align-right); }
        button[data-ui-icon="align-top"] { --sss-current-icon: var(--sss-ico-align-top); }
        button[data-ui-icon="align-middle"] { --sss-current-icon: var(--sss-ico-align-middle); }
        button[data-ui-icon="align-bottom"] { --sss-current-icon: var(--sss-ico-align-bottom); }
        button[data-ui-icon="dist-h"] { --sss-current-icon: var(--sss-ico-dist-h); }
        button[data-ui-icon="dist-v"] { --sss-current-icon: var(--sss-ico-dist-v); }
        button[data-ui-icon="action"] { --sss-current-icon: var(--sss-ico-action); }
        button[data-ui-icon="lock"] { --sss-current-icon: var(--sss-ico-lock); }
        button[data-ui-icon="trash"] { --sss-current-icon: var(--sss-ico-trash); }
        button[data-ui-icon="capture"] { --sss-current-icon: var(--sss-ico-capture); }
        button[data-ui-icon="apply"] { --sss-current-icon: var(--sss-ico-apply); }
        button[data-ui-icon="cancel"] { --sss-current-icon: var(--sss-ico-cancel); }

        /* Cleaned Up File Input */
        .clear-img-btn { background: transparent; border: none; color: #e74c3c; cursor: pointer; font-size: 16px; padding: 0 4px; }

        .snap-guide-v, .snap-guide-h { position: absolute; background-color: #f39c12; z-index: 1500; display: none; pointer-events: none; }
        .snap-guide-v { width: 1px; height: 10000px; top: -5000px; }
        .snap-guide-h { height: 1px; width: 10000px; left: -5000px; }

        /* === Elements === */
        .selector-btn {
            position: absolute; display: flex; align-items: center; justify-content: center;
            cursor: pointer; z-index: 10; transition: filter 0.2s;
            filter: drop-shadow(0 2px 3px rgba(0,0,0,0.4));
        }
        .selector-btn:hover { filter: var(--hover-filter, none); z-index: 15; }
        .selector-btn.selected { filter: var(--select-filter, none); z-index: 20; }
        body:not(.edit-mode) .selector-btn[data-action-type="display"] { pointer-events: none !important; }

        .resize-handle { position: absolute; right: -5px; bottom: -5px; width: 12px; height: 12px; background: var(--accent-color); cursor: se-resize; z-index: 30; display: none; border-radius: 50%; border: 2px solid #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.5);}
        .edit-mode .selected > .resize-handle { display: block; }
        .edit-mode .locked-elem > .resize-handle { display: none !important; }

        .btn-inner { width: 100%; height: 100%; display: flex; position: absolute; top:0; left:0; overflow: visible; background-image: var(--bg-img-url); background-size: 100% 100%; background-position: center; background-repeat: no-repeat;}

        .btn-inner::after { content: ''; position: absolute; inset: 0; pointer-events: none; transition: background-color 0.2s; z-index: 1; border-radius: inherit; -webkit-mask-image: var(--bg-img-url); mask-image: var(--bg-img-url); -webkit-mask-size: 100% 100%; mask-size: 100% 100%; }
        .selector-btn:hover .btn-inner::after { background-color: var(--hover-overlay-color); }
        .selector-btn.selected .btn-inner::after { background-color: var(--select-overlay-color); }

        .btn-text { position: relative; z-index: 2; pointer-events: none; width: 100%; padding: 4px; line-height: 1.2; word-break: break-word; color: var(--font-color);}

        /* Sliders */
        .slider-container { padding: 4px 8px; justify-content: space-evenly; align-items: center; display: flex; flex-direction: column; }
        .slider-label { pointer-events: none; position:relative; z-index: 2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex-shrink:0; text-align:center; color: var(--font-color);}
        .slider-controls { display:flex; align-items:center; justify-content:center; gap:6px; flex: 0 0 auto; position:relative; z-index: 3; pointer-events: auto; }

        input[type=range].slider-input-range { -webkit-appearance: none; background: transparent; padding: 0; border: none; }
        input[type=range].slider-input-range::-webkit-slider-runnable-track { width: 100%; height: 6px; background: var(--track-color, #2980b9); border-radius: 3px; border: 1px solid rgba(0,0,0,0.2); }
        input[type=range].slider-input-range::-webkit-slider-thumb { -webkit-appearance: none; height: 14px; width: 14px; border-radius: 50%; background: var(--thumb-color, #ffffff); margin-top: -4px; cursor: pointer; border: 1px solid rgba(0,0,0,0.4); box-shadow: 0 1px 3px rgba(0,0,0,0.3); }

        .slider-input-num { padding:2px; background: var(--spin-bg, var(--input-bg)); color: var(--spin-font, var(--text-color)); border:1px solid var(--border-color); border-radius:3px; text-align:center; font-size:11px; font-weight:bold;}
        body.edit-mode .slider-controls { pointer-events: none; }

        .shape-circle { border-radius: 50%; } .shape-circle::after { border-radius: 50%; }
        .shape-square { border-radius: inherit; } .shape-square::after { border-radius: inherit; }
        .shape-triangle { clip-path: polygon(50% 0%, 0% 100%, 100% 100%); border-radius: 0 !important; }
        .shape-star { clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%); border-radius: 0 !important; }
        .shape-text { background-color: transparent !important; border: none !important; box-shadow: none !important; }
        .shape-text::after { display: none; }

        .locked-elem { outline: 2px dashed #f39c12 !important; outline-offset: 3px; }
        #selection-box { position: absolute; border: 1px dashed var(--accent-color); background-color: rgba(0, 122, 204, 0.2); display: none; z-index: 1500; pointer-events: none; }
        body:not(.edit-mode) .selector-btn.state-unknown { opacity: 0.5; outline: 2px dashed #9a9a9a; outline-offset: 2px; }
        #toast-msg { position: fixed; left: 50%; bottom: 16px; transform: translateX(-50%); max-width: 90vw; background: rgba(192,57,43,0.95); color: #fff; padding: 6px 12px; border-radius: 6px; font-size: 12px; z-index: 3500; display: none; pointer-events: none; white-space: pre-line; word-break: break-word; box-shadow: 0 2px 8px rgba(0,0,0,0.4); }

        /* Modals & Tooltips */
        #context-menu { position: absolute; background: var(--panel-bg); border: 1px solid var(--border-color); padding: 8px; border-radius: 6px; display: none; z-index: 2000; box-shadow: 0 4px 15px rgba(0,0,0,0.5); width: 160px;}
        #context-menu h4 { margin: 0 0 8px 0; font-size: 13px; text-align:center; color: var(--text-color); opacity: 0.8;}
        .ctx-btn { width: 100%; text-align: left; padding: 8px; margin-bottom: 2px; background: transparent; border: none; color: var(--text-color); font-size: 12px; border-radius: 4px; cursor: pointer; transition: background 0.1s;}
        .ctx-btn:hover { background: var(--accent-color); color:#fff; }
        .ctx-divider { border-top: 1px solid var(--border-color); margin: 4px 0; }

        .align-btn { width: 32px; height: 26px; padding: 0; font-size: 14px; display:flex; align-items:center; justify-content:center; }
        .add-icon-btn { flex: 1; height: 30px; font-size: 13px; display:flex; align-items:center; justify-content:center; transition: filter 0.2s; border-radius: 4px; border:none; box-shadow: 0 2px 4px rgba(0,0,0,0.2); font-weight:bold;}
        .add-icon-btn:hover { filter: brightness(1.2); }

        .modal-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.7); display: none; align-items: center; justify-content: center; z-index: 3000; backdrop-filter: blur(3px);}
        .modal-content { background: var(--panel-bg); border: 1px solid var(--border-color); border-radius: 8px; padding: 24px; width: 450px; max-width: 90vw; max-height: 90vh; overflow-y: auto; box-shadow: 0 15px 40px rgba(0,0,0,0.6); }
        .modal-content h3 { margin-top: 0; margin-bottom: 16px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px; color: var(--accent-color); }
        textarea { width: 100%; background: var(--input-bg); color: var(--text-color); border: 1px solid var(--border-color); font-family: 'Consolas', monospace; font-size: 12px; padding: 8px; box-sizing: border-box; resize: vertical; border-radius: 4px;}
        #elem-tooltip { min-height: 72px; white-space: pre-wrap; }

        /* v1.10.45: the per-element .custom-tooltip is only a data holder now and is never painted.
           Each .selector-btn is its own stacking context (position:absolute + inline z-index + rotate transform)
           inside the transformed #workspace, so a tip nested in a button was painted under any sibling button
           with a higher (or equal, later) z-index. The visible tip is #floating-tooltip: a direct child of
           <body>, position:fixed, top-most z-index, positioned from getBoundingClientRect() every frame. */
        .custom-tooltip { display: none !important; }
        #floating-tooltip { position: fixed; left: 0; top: 0; background: var(--tooltip-bg, rgba(255,255,255,0.96)); color: var(--tooltip-color, #000); padding: 8px 12px; border-radius: 6px; font-size: 11px; line-height: 1.45; pointer-events: none; z-index: 2147483000; white-space: pre-line; word-break: break-word; min-width: 180px; max-width: 420px; display: none; box-shadow: 0 2px 8px rgba(0,0,0,0.25); border: 1px solid rgba(0,0,0,0.12); box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; text-align: left; }
        #floating-tooltip::after { content: ''; position: absolute; bottom: 100%; left: var(--tip-arrow-x, 50%); margin-left: -5px; border-width: 5px; border-style: solid; border-color: transparent transparent var(--tooltip-bg, rgba(255,255,255,0.96)) transparent; }
        #floating-tooltip.tip-above::after { bottom: auto; top: 100%; border-color: var(--tooltip-bg, rgba(255,255,255,0.96)) transparent transparent transparent; }
    </style>
</head>
<body class="edit-mode">

    <div id="toolbar">
        <select id="mode-select" onchange="toggleMode()" style="width:auto;" data-i18n-title="tt_mode">
            <option value="edit" data-i18n="mode_edit">✎ 編集モード</option>
            <option value="play" data-i18n="mode_play">▶ セレクトモード</option>
        </select>
        <button onclick="toggleTopmost()" id="topmost-btn" class="icon-btn toolbar-icon-btn" data-ui-icon="pin" style="background:#b7845a; color:#fff;" data-i18n="pin_off" data-i18n-title="tt_pin">Blenderに追従: OFF</button>

        <div style="margin-left:auto; display:flex; align-items:center; gap:10px;">
            <span id="current-file-label" style="font-size:13px; color:#f39c12; font-weight:bold;"></span>
            <span style="font-size:12px; opacity:0.8;" id="status" data-i18n="status_ready">準備完了</span>
            <button onclick="saveFile()" class="icon-btn toolbar-icon-btn" data-ui-icon="save" style="background:#5d8a66; color:#fff; border:none; padding:4px 12px; font-weight:bold; height:26px;" data-i18n="btn_save" data-i18n-title="tt_save">上書き保存</button>
            <button onclick="saveAsFile()" class="icon-btn toolbar-icon-btn" data-ui-icon="saveas" style="background:#5d8a66; color:#fff; border:none; padding:4px 12px; font-weight:bold; height:26px;" data-i18n="btn_save_as" data-i18n-title="tt_save_as">別名保存</button>
        </div>
    </div>

    <div id="tab-bar">
        <div id="tabs-container" style="display:flex; height:100%;"></div>
        <button id="add-tab-btn" class="icon-only" data-ui-icon="add" onclick="addPage()" data-i18n-title="tt_add_tab" aria-label="Add Tab"></button>
    </div>

    <div id="canvas-viewport">
        <div id="scroll-content">
            <div id="workspace">
                <div id="grid-layer"></div>
                <div id="bg-layer" class="selector-btn" style="z-index:1; border:none; box-shadow:none;"><div class="resize-handle" onmousedown="onResizeMouseDown(event, document.getElementById('bg-layer'))"></div></div>
                <div id="selection-box"></div>
                <div id="snap-v" class="snap-guide-v"></div>
                <div id="snap-h" class="snap-guide-h"></div>
            </div>
        </div>
    </div>

    <div id="properties">
        <div id="panel-resizer" data-i18n-title="tt_panel_resize"></div>

        <details class="prop-section" open data-i18n-title="tt_panel_bg">
            <summary data-i18n="bg_settings">キャンバス設定</summary>
            <div class="prop-section-content">
                <div class="prop-row" data-i18n-title="tt_canvas_size">
                    <div class="prop-label" data-i18n="lbl_canvas_size">サイズ(W/H):</div>
                    <div class="prop-controls">
                        <input type="number" id="canvas-w" value="500" oninput="updateCanvasSize()">
                        <input type="number" id="canvas-h" value="500" oninput="updateCanvasSize()">
                    </div>
                </div>
                <div class="prop-row" data-i18n-title="tt_canvas_bg_color">
                    <div class="prop-label" data-i18n="lbl_color">背景色:</div>
                    <div class="prop-controls"><input type="color" id="bg-color" value="#2b2b2b" onchange="updateBg()"></div>
                </div>
                <div class="prop-row" style="margin-bottom:8px;">
                    <div class="prop-label" data-i18n="lbl_panzoom">機能制限:</div>
                    <div class="prop-controls">
                        <label class="checkbox-label" data-i18n-title="tt_panzoom"><input type="checkbox" id="panzoom-toggle" checked onchange="togglePanZoom()"><span data-i18n="lbl_enable">パン＆ズーム許可</span></label>
                    </div>
                </div>
                <div class="prop-row" style="margin-bottom:8px;" data-i18n-title="tt_empty_click_deselect">
                    <div class="prop-label" data-i18n="lbl_empty_click">空クリック:</div>
                    <div class="prop-controls">
                        <label class="checkbox-label" data-i18n-title="tt_empty_click_deselect"><input type="checkbox" id="empty-click-deselect-toggle" checked onchange="toggleEmptyClickDeselect()"><span data-i18n="lbl_empty_click_deselect">Blenderの選択を解除</span></label>
                    </div>
                </div>

                <hr style="border:0; border-top:1px solid var(--border-color); margin:4px 0 8px 0;">
                <div style="font-size:11px; font-weight:bold; opacity:0.8; margin-bottom:4px;" data-i18n="lbl_tab_colors" data-i18n-title="tt_tab_colors">タブカラー設定 (固定)</div>
                <div class="prop-row" data-i18n-title="tt_tab_colors">
                    <div class="prop-label" data-i18n="lbl_tab_bar_bg">バー背景:</div>
                    <div class="prop-controls"><input type="color" id="tab-bar-bg" value="#2d2d2d" onchange="updateTabColors()"></div>
                </div>
                <div class="prop-row" data-i18n-title="tt_tab_colors">
                    <div class="prop-label" data-i18n="lbl_tab_bg">タブ背景:</div>
                    <div class="prop-controls">
                        <input type="color" id="tab-bg" value="#1e1e1e" onchange="updateTabColors()">
                        <span data-i18n="lbl_active">アクティブ</span><input type="color" id="tab-act-bg" value="#0e639c" onchange="updateTabColors()">
                    </div>
                </div>
                <div class="prop-row" data-i18n-title="tt_tab_colors">
                    <div class="prop-label" data-i18n="lbl_tab_font_color">文字色:</div>
                    <div class="prop-controls">
                        <input type="color" id="tab-font-color" value="#aaaaaa" onchange="updateTabColors()">
                        <span data-i18n="lbl_active">アクティブ</span><input type="color" id="tab-act-font-color" value="#ffffff" onchange="updateTabColors()">
                    </div>
                </div>
            </div>
        </details>

        <details class="prop-section" data-i18n-title="tt_panel_layout">
            <summary data-i18n="layout_settings">追加・レイアウト・整列</summary>
            <div class="prop-section-content">
                <div style="display:flex; gap:6px;">
                    <button onclick="addElem('button', null, true)" class="add-icon-btn icon-btn" data-ui-icon="add" style="background:#6d8f74; color:#fff;" data-i18n="add_btn" data-i18n-title="add_btn_tip">要素</button>
                    <button onclick="addElem('slider', null, true)" class="add-icon-btn icon-btn" data-ui-icon="slider" style="background:#b58b63; color:#fff;" data-i18n="add_slider" data-i18n-title="add_slider_tip">スライダー</button>
                </div>
                <div style="display:flex; gap:4px;">
                    <button class="btn-flex icon-only" data-ui-icon="undo" onclick="undo()" data-i18n-title="tt_undo" aria-label="Undo"></button>
                    <button class="btn-flex icon-only" data-ui-icon="redo" onclick="redo()" data-i18n-title="tt_redo" aria-label="Redo"></button>
                    <button class="btn-flex icon-only" data-ui-icon="copy" onclick="copyElems()" data-i18n-title="tt_copy" aria-label="Copy"></button>
                    <button class="btn-flex icon-only" data-ui-icon="cut" onclick="cutElems()" data-i18n-title="tt_cut" aria-label="Cut"></button>
                    <button class="btn-flex icon-only" data-ui-icon="paste" onclick="pasteElems()" data-i18n-title="tt_paste" aria-label="Paste"></button>
                </div>

                <div class="prop-row" style="margin-top:4px;">
                    <div class="prop-controls" style="justify-content: space-between;">
                        <label class="checkbox-label" data-i18n-title="tt_snap"><input type="checkbox" id="snap-toggle" checked><span data-i18n="lbl_snap_elem">スナップ</span></label>
                        <label class="checkbox-label" data-i18n-title="tt_grid"><input type="checkbox" id="grid-toggle" onchange="updateGrid()"><span data-i18n="lbl_snap_grid">グリッド</span></label>
                        <div class="prop-controls" style="flex:0 0 50px;" data-i18n-title="tt_grid_size"><input type="number" id="grid-size" value="20" onchange="updateGrid()"></div>
                    </div>
                </div>

                <div style="display:flex; flex-direction:column; gap:4px; margin-top:4px;">
                    <div style="display:flex; gap:4px;">
                        <button class="btn-flex icon-only" data-ui-icon="align-left" onclick="alignElems('left')" data-i18n-title="tt_align_l" aria-label="Align Left"></button>
                        <button class="btn-flex icon-only" data-ui-icon="align-center" onclick="alignElems('center')" data-i18n-title="tt_align_c" aria-label="Align Center"></button>
                        <button class="btn-flex icon-only" data-ui-icon="align-right" onclick="alignElems('right')" data-i18n-title="tt_align_r" aria-label="Align Right"></button>
                        <button class="btn-flex icon-btn" data-ui-icon="dist-h" onclick="distributeElems('h')" style="flex:2;" data-i18n-title="tt_dist_h"><span data-i18n="lbl_distribute_h">横分散</span></button>
                    </div>
                    <div style="display:flex; gap:4px;">
                        <button class="btn-flex icon-only" data-ui-icon="align-top" onclick="alignElems('top')" data-i18n-title="tt_align_t" aria-label="Align Top"></button>
                        <button class="btn-flex icon-only" data-ui-icon="align-middle" onclick="alignElems('middle')" data-i18n-title="tt_align_m" aria-label="Align Middle"></button>
                        <button class="btn-flex icon-only" data-ui-icon="align-bottom" onclick="alignElems('bottom')" data-i18n-title="tt_align_b" aria-label="Align Bottom"></button>
                        <button class="btn-flex icon-btn" data-ui-icon="dist-v" onclick="distributeElems('v')" style="flex:2;" data-i18n-title="tt_dist_v"><span data-i18n="lbl_distribute_v">縦分散</span></button>
                    </div>
                </div>
            </div>
        </details>

        <details class="prop-section" id="elem-section" open data-i18n-title="tt_panel_elem">
            <summary><span data-i18n="elem_settings">要素設定</span> <span id="multi-select-warn" style="color:var(--select-color); display:none; font-size:10px; margin-left:10px;" data-i18n="msg_multi_sel">(複数選択中)</span></summary>
            <div class="prop-section-content">
                <div id="no-btn-selected" style="font-size:11px; color:var(--tab-color); text-align:center; padding:10px;" data-i18n="msg_no_sel">※要素をクリックして選択</div>

                <div id="common-settings" style="display:none;">
                    <div class="prop-row" data-i18n-title="tt_prop_name">
                        <div class="prop-label" data-i18n="lbl_name">ID名:</div>
                        <div class="prop-controls"><input type="text" id="elem-name" onchange="updateElem()"></div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_size">
                        <div class="prop-label" data-i18n="lbl_size">サイズ(W/H):</div>
                        <div class="prop-controls">
                            <input type="number" id="elem-width" value="40" oninput="updateElemSize('w')">
                            <input type="number" id="elem-height" value="40" oninput="updateElemSize('h')">
                            <label class="checkbox-label" data-i18n-title="tt_lock_aspect"><input type="checkbox" id="elem-lock" checked onchange="updateElemSize('lock')">🔒</label>
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_pos">
                        <div class="prop-label" data-i18n="lbl_pos">位置(X/Y/Z):</div>
                        <div class="prop-controls">
                            <input type="number" id="elem-x" value="0" oninput="updateElemPos()">
                            <input type="number" id="elem-y" value="0" oninput="updateElemPos()">
                            <input type="number" id="elem-z" value="10" oninput="updateElemPos()">
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_rot">
                        <div class="prop-label" data-i18n="lbl_rotate">回転(度):</div>
                        <div class="prop-controls">
                            <input type="number" id="elem-rotate" value="0" oninput="updateElem()">
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_tooltip">
                        <div class="prop-label" data-i18n="lbl_tooltip">Tip解説:</div>
                        <div class="prop-controls"><textarea id="elem-tooltip" oninput="updateElem()"></textarea></div>
                    </div>
                    <div class="prop-row wrap-safe" data-i18n-title="tt_tooltip_colors">
                        <div class="prop-label" data-i18n="lbl_tooltip_colors">Tip色:</div>
                        <div class="prop-controls">
                            <span data-i18n="lbl_bg_short">背景</span><input type="color" id="elem-tooltip-bg" value="#ffffff" onchange="updateElem()">
                            <span data-i18n="lbl_text_short">文字</span><input type="color" id="elem-tooltip-color" value="#000000" onchange="updateElem()">
                        </div>
                    </div>
                </div>

                <div id="btn-settings" style="display:none; margin-top:8px; border-top:1px solid var(--border-color); padding-top:12px;">
                    <div class="prop-row" data-i18n-title="tt_prop_shape">
                        <div class="prop-label" data-i18n="lbl_shape">形状:</div>
                        <div class="prop-controls">
                            <select id="btn-shape" onchange="updateElem()">
                                <option value="square" data-i18n="opt_square">□ 四角</option>
                                <option value="circle" data-i18n="opt_circle">〇 円</option>
                                <option value="triangle" data-i18n="opt_tri">△ 三角</option>
                                <option value="star" data-i18n="opt_star">☆ 星型</option>
                                <option value="text" data-i18n="opt_text">Ｔ テキストのみ</option>
                            </select>
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_bg">
                        <div class="prop-label" data-i18n="lbl_color">背景色(色/透):</div>
                        <div class="prop-controls">
                            <input type="color" id="btn-color" value="#3498db" onchange="updateElem()">
                            <input type="number" id="btn-color-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_border">
                        <div class="prop-label" data-i18n="lbl_border">枠線(色/透/幅):</div>
                        <div class="prop-controls">
                            <input type="color" id="btn-border-c" value="#2980b9" onchange="updateElem()">
                            <input type="number" id="btn-border-a" value="100" min="0" max="100" onchange="updateElem()">%
                            <input type="number" id="btn-border-w" value="2" onchange="updateElem()">px
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_bstyle">
                        <div class="prop-label" data-i18n="lbl_border_style">枠線種:</div>
                        <div class="prop-controls">
                            <select id="btn-border-s" onchange="updateElem()">
                                <option value="solid" data-i18n="opt_line_solid">実線</option><option value="dashed" data-i18n="opt_line_dash">破線</option><option value="dotted" data-i18n="opt_line_dot">点線</option>
                            </select>
                        </div>
                    </div>
                    <div class="prop-row" id="radius-row" data-i18n-title="tt_prop_radius">
                        <div class="prop-label" data-i18n="lbl_radius">角丸(px):</div>
                        <div class="prop-controls"><input type="number" id="btn-radius" value="6" onchange="updateElem()"></div>
                    </div>

                    <div style="margin-top:12px; font-size:11px; font-weight:bold; opacity:0.8;" data-i18n="lbl_multi_img" data-i18n-title="tt_prop_img">背景画像設定 (透過PNG対応)</div>

                    <div class="prop-row" data-i18n-title="tt_prop_img">
                        <div class="prop-label" data-i18n="lbl_img_norm">通常:</div>
                        <div class="prop-controls" style="flex: 1; overflow: hidden;">
                            <input type="file" id="btn-img" accept="image/png, image/jpeg" onchange="uploadImage(this, 'elem', 'normal')" style="width:100%; font-size:11px; cursor:pointer;">
                        </div>
                        <button class="clear-img-btn" id="btn-img-clear" onclick="clearSingleImage('normal')" data-i18n-title="tt_clear_image" style="display:none;">×</button>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_img">
                        <label class="checkbox-label prop-label"><input type="checkbox" id="use-img-hover" onchange="updateElem()"><span data-i18n="lbl_img_hov">Hover:</span></label>
                        <div class="prop-controls" style="flex: 1; overflow: hidden;">
                            <input type="file" id="btn-img-h" accept="image/png, image/jpeg" onchange="uploadImage(this, 'elem', 'hover')" style="width:100%; font-size:11px; cursor:pointer;">
                        </div>
                        <button class="clear-img-btn" id="btn-img-h-clear" onclick="clearSingleImage('hover')" data-i18n-title="tt_clear_image" style="display:none;">×</button>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_img">
                        <label class="checkbox-label prop-label"><input type="checkbox" id="use-img-select" onchange="updateElem()"><span data-i18n="lbl_img_sel">Select:</span></label>
                        <div class="prop-controls" style="flex: 1; overflow: hidden;">
                            <input type="file" id="btn-img-s" accept="image/png, image/jpeg" onchange="uploadImage(this, 'elem', 'select')" style="width:100%; font-size:11px; cursor:pointer;">
                        </div>
                        <button class="clear-img-btn" id="btn-img-s-clear" onclick="clearSingleImage('select')" data-i18n-title="tt_clear_image" style="display:none;">×</button>
                    </div>
                </div>

                <div id="slider-settings" style="display:none; margin-top:8px; border-top:1px solid var(--border-color); padding-top:12px;">
                    <div class="prop-row" data-i18n-title="tt_slider_mode">
                        <div class="prop-label" data-i18n="lbl_mode">表示モード:</div>
                        <div class="prop-controls">
                            <select id="slider-mode" onchange="updateElem()">
                                <option value="both" data-i18n="opt_both">両方</option>
                                <option value="slider" data-i18n="opt_slider">スライダのみ</option>
                                <option value="spinner" data-i18n="opt_spinner">数値のみ</option>
                            </select>
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_slider_widths">
                        <div class="prop-label" data-i18n="lbl_sld_widths">幅(バー/数値):</div>
                        <div class="prop-controls">
                            <input type="number" id="slider-track-w" value="120" onchange="updateElem()">px
                            <input type="number" id="slider-spin-w" value="50" onchange="updateElem()">px
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_slider_minmax">
                        <div class="prop-label" data-i18n="val_min_max">最小 / 最大:</div>
                        <div class="prop-controls">
                            <input type="number" id="slider-min" value="0" step="0.1" onchange="updateElem()">
                            <input type="number" id="slider-max" value="1" step="0.1" onchange="updateElem()">
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_bg">
                        <div class="prop-label" data-i18n="lbl_color">背景色(色/透):</div>
                        <div class="prop-controls">
                            <input type="color" id="slider-color" value="#3498db" onchange="updateElem()">
                            <input type="number" id="slider-color-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_slider_colors">
                        <div class="prop-label" data-i18n="lbl_sld_track">バー色/透:</div>
                        <div class="prop-controls">
                            <input type="color" id="slider-track-color" value="#2980b9" onchange="updateElem()">
                            <input type="number" id="slider-track-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_slider_colors">
                        <div class="prop-label" data-i18n="lbl_sld_thumb">ツマミ色/透:</div>
                        <div class="prop-controls">
                            <input type="color" id="slider-thumb-color" value="#ffffff" onchange="updateElem()">
                            <input type="number" id="slider-thumb-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_slider_colors">
                        <div class="prop-label" data-i18n="lbl_sld_spin">数値背景/透:</div>
                        <div class="prop-controls">
                            <input type="color" id="slider-spin-bg" value="#1e1e1e" onchange="updateElem()">
                            <input type="number" id="slider-spin-bg-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_font_color">
                        <div class="prop-label" data-i18n="lbl_spin_font">数値文字/透:</div>
                        <div class="prop-controls">
                            <input type="color" id="slider-spin-font-c" value="#ffffff" onchange="updateElem()">
                            <input type="number" id="slider-spin-font-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                </div>

                <div id="text-settings" style="display:none; margin-top:8px; border-top:1px solid var(--border-color); padding-top:12px;">
                    <div class="prop-row" data-i18n-title="tt_prop_text">
                        <div class="prop-label" data-i18n="lbl_text">文字:</div>
                        <div class="prop-controls"><input type="text" id="elem-text" oninput="updateElem()"></div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_font_color">
                        <div class="prop-label" data-i18n="lbl_font_color">文字色/透:</div>
                        <div class="prop-controls">
                            <input type="color" id="elem-font-color" value="#ffffff" onchange="updateElem()">
                            <input type="number" id="elem-font-color-a" value="100" min="0" max="100" onchange="updateElem()">%
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_font">
                        <div class="prop-label" data-i18n="lbl_font">フォント:</div>
                        <div class="prop-controls">
                            <select id="elem-font" onchange="updateElem()">
                                <option value="'Segoe UI', Tahoma, sans-serif" data-i18n="font_default">Segoe UI (Default)</option>
                                <option value="Arial, sans-serif">Arial</option>
                                <option value="'Arial Black', sans-serif">Arial Black</option>
                                <option value="'Comic Sans MS', cursive">Comic Sans</option>
                                <option value="'Courier New', monospace">Courier New</option>
                                <option value="Georgia, serif">Georgia</option>
                                <option value="Impact, sans-serif">Impact</option>
                                <option value="Tahoma, sans-serif">Tahoma</option>
                                <option value="'Times New Roman', serif">Times</option>
                                <option value="Verdana, sans-serif">Verdana</option>
                                <option value="'MS Gothic', sans-serif" data-i18n="font_ms_gothic">MS ゴシック</option>
                                <option value="'MS Mincho', serif" data-i18n="font_ms_mincho">MS 明朝</option>
                                <option value="'Meiryo', sans-serif" data-i18n="font_meiryo">メイリオ</option>
                                <option value="'Yu Gothic', sans-serif" data-i18n="font_yu_gothic">游ゴシック</option>
                            </select>
                        </div>
                    </div>
                    <div class="prop-row wrap-safe" data-i18n-title="tt_prop_font">
                        <div class="prop-label" data-i18n="lbl_font_size">サイズ/装飾:</div>
                        <div class="prop-controls font-style-controls" style="flex-wrap: wrap; row-gap:4px; justify-content:flex-start;">
                            <div style="display:flex; align-items:center; gap:4px; flex-wrap:wrap; width:100%;">
                                <input type="number" id="elem-font-size" value="16" onchange="updateElem()" style="max-width:72px;"><span>px</span>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap; width:100%;">
                                <label class="checkbox-label" data-i18n-title="tt_bold"><input type="checkbox" id="elem-bold" onchange="updateElem()"><b>B</b></label>
                                <label class="checkbox-label" data-i18n-title="tt_italic"><input type="checkbox" id="elem-italic" onchange="updateElem()"><i>I</i></label>
                            </div>
                        </div>
                    </div>
                    <div class="prop-row" data-i18n-title="tt_prop_font">
                        <div class="prop-label" data-i18n="lbl_align">配置(横/縦):</div>
                        <div class="prop-controls">
                            <select id="elem-align-h" onchange="updateElem()">
                                <option value="flex-start" data-i18n="opt_align_l">左</option><option value="center" data-i18n="opt_align_c">中</option><option value="flex-end" data-i18n="opt_align_r">右</option>
                            </select>
                            <select id="elem-align-v" onchange="updateElem()">
                                <option value="flex-start" data-i18n="opt_align_t">上</option><option value="center" data-i18n="opt_align_c">中</option><option value="flex-end" data-i18n="opt_align_b">下</option>
                            </select>
                        </div>
                    </div>
                    <div class="prop-row" id="gap-row" style="display:none;" data-i18n-title="tt_prop_gap">
                        <div class="prop-label" data-i18n="lbl_gap">余白(px):</div>
                        <div class="prop-controls"><input type="number" id="elem-gap" value="0" onchange="updateElem()"></div>
                    </div>
                </div>
            </div>
        </details>

        <details class="prop-section" data-i18n-title="tt_panel_effect">
            <summary data-i18n="display_settings">エフェクト (ホバー/選択)</summary>
            <div class="prop-section-content">
                <div class="prop-row" data-i18n-title="tt_hover_state">
                    <div class="prop-label" data-i18n="lbl_hover">ホバー:</div>
                    <div class="prop-controls">
                        <label class="checkbox-label" data-i18n-title="tt_hover_outline"><input type="checkbox" id="hover-outline-chk" checked onchange="updateColors()"><span data-i18n="lbl_outline">枠</span></label>
                        <label class="checkbox-label" data-i18n-title="tt_hover_glow"><input type="checkbox" id="hover-glow-chk" checked onchange="updateColors()"><span data-i18n="lbl_glow">光彩</span></label>
                    </div>
                </div>
                <div class="prop-row" data-i18n-title="tt_hover_colors">
                    <div class="prop-label" data-i18n="lbl_color">色 / 透過:</div>
                    <div class="prop-controls">
                        <input type="color" id="hover-color" value="#f1c40f" onchange="updateColors()">
                        <input type="number" id="hover-opacity" value="25" min="0" max="100" onchange="updateColors()"> %
                    </div>
                </div>
                <hr style="border:0; border-top:1px solid var(--border-color); margin:8px 0;">
                <div class="prop-row" data-i18n-title="tt_select_state">
                    <div class="prop-label" data-i18n="lbl_select">選択時:</div>
                    <div class="prop-controls">
                        <label class="checkbox-label" data-i18n-title="tt_select_outline"><input type="checkbox" id="select-outline-chk" checked onchange="updateColors()"><span data-i18n="lbl_outline">枠</span></label>
                        <label class="checkbox-label" data-i18n-title="tt_select_glow"><input type="checkbox" id="select-glow-chk" checked onchange="updateColors()"><span data-i18n="lbl_glow">光彩</span></label>
                    </div>
                </div>
                <div class="prop-row" data-i18n-title="tt_select_colors">
                    <div class="prop-label" data-i18n="lbl_color">色 / 透過:</div>
                    <div class="prop-controls">
                        <input type="color" id="select-color" value="#e74c3c" onchange="updateColors()">
                        <input type="number" id="select-opacity" value="25" min="0" max="100" onchange="updateColors()"> %
                    </div>
                </div>
            </div>
        </details>

    </div>

    <div id="context-menu">
        <h4 id="ctx-title" data-i18n="ctx_title_elem">操作</h4>
        <button id="ctx-action-btn" class="ctx-btn icon-btn" data-ui-icon="action" onclick="openActionModal()" data-i18n="ctx_action" data-i18n-title="tt_context_action">アクション設定</button>
        <div class="ctx-divider"></div>
        <button id="ctx-lock-btn" class="ctx-btn icon-btn" data-ui-icon="lock" onclick="toggleLock()" style="color:#f39c12;" data-i18n="ctx_lock" data-i18n-title="tt_context_lock">位置をロック</button>
        <button id="ctx-delete-btn" class="ctx-btn icon-btn" data-ui-icon="trash" onclick="deleteElem()" style="color:#e74c3c;" data-i18n="ctx_delete" data-i18n-title="tt_context_delete">削除</button>
    </div>

    <div id="action-modal" class="modal-overlay">
        <div class="modal-content">
            <h3 id="modal-title" data-i18n="modal_title_btn">アクション設定</h3>
            <div id="modal-btn-content" style="display:none;">
                <span data-i18n="lbl_action_type">動作タイプ:</span>
                <select id="modal-action-type" onchange="switchModalActionType()" style="width:100%; margin:8px 0 16px 0; padding:6px;" data-i18n-title="tt_action_type">
                    <option value="node" data-i18n="opt_node">ノード選択</option>
                    <option value="script" data-i18n="opt_script">単発スクリプト実行</option>
                    <option value="toggle" data-i18n="opt_toggle">トグル(ON/OFF) スクリプト</option>
                    <option value="timeline" data-i18n="opt_timeline">タイムライン操作</option>
                    <option value="camera" data-i18n="opt_camera">カメラ/ビュー操作</option>
                    <option value="collection_select" data-i18n="opt_collection_select">コレクション選択</option>
                    <option value="collection_visibility" data-i18n="opt_collection_visibility">コレクション表示切替</option>
                    <option value="bone_select" data-i18n="opt_bone_select">ボーン選択</option>
                    <option value="mesh_selectset" data-i18n="opt_mesh_selectset">メッシュ選択セット</option>
                    <option value="display" data-i18n="opt_display">機能なし (表示・装飾用)</option>
                </select>
                <div id="modal-node-area" data-i18n-title="tt_target_nodes"><span data-i18n="lbl_target_nodes">対象ノード (複数選択可):</span><br><select id="modal-obj-list" multiple style="width:100%; height:150px; margin-top:8px;"></select></div>
                <div id="modal-collection-area" style="display:none;" data-i18n-title="tt_target_collections">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
                        <span data-i18n="lbl_target_collections">対象コレクション (複数選択可):</span>
                    </div>
                    <select id="modal-collection-list" multiple style="width:100%; height:180px; margin-top:8px;"></select>
                    <label class="checkbox-label" style="margin-top:8px;" data-i18n-title="tt_include_children"><input type="checkbox" id="modal-collection-include-children" checked><span data-i18n="lbl_include_children">子コレクションを含める</span></label>
                </div>
                <div id="modal-collection-vis-area" style="display:none;" data-i18n-title="tt_target_collections">
                    <span data-i18n="lbl_target_collections">対象コレクション (複数選択可):</span><br>
                    <select id="modal-collection-vis-list" multiple style="width:100%; height:160px; margin-top:8px;"></select>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
                        <span data-i18n="lbl_vis_action">表示操作:</span>
                        <select id="modal-collection-vis-action" style="width:160px;" data-i18n-title="tt_collection_visibility_action">
                            <option value="toggle" data-i18n="vis_toggle">トグル</option>
                            <option value="show" data-i18n="vis_show">表示</option>
                            <option value="hide" data-i18n="vis_hide">非表示</option>
                        </select>
                    </div>
                </div>
                <div id="modal-bone-area" style="display:none; margin-top:10px;" data-i18n-title="tt_target_bones">
                    <span data-i18n="lbl_target_armature">アーマチュア:</span><br>
                    <select id="modal-armature-list" style="width:100%; margin:8px 0 12px 0; padding:6px;" data-i18n-title="tt_target_armature"></select>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span data-i18n="lbl_target_bones">対象ボーン (複数選択可):</span>
                        <button id="modal-bone-capture" class="icon-btn" data-ui-icon="capture" onclick="captureBones()" style="padding:6px 10px;" data-i18n="btn_capture" data-i18n-title="tt_capture_bones">キャプチャ</button>
                    </div>
                    <select id="modal-bone-list" multiple style="width:100%; height:160px; margin-top:8px;"></select>
                </div>
                <div id="modal-meshset-area" style="display:none; margin-top:10px;" data-i18n-title="tt_target_mesh">
                    <span data-i18n="lbl_target_mesh">メッシュ:</span><br>
                    <select id="modal-mesh-obj" style="width:100%; margin:8px 0 12px 0; padding:6px;" data-i18n-title="tt_target_mesh"></select>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span data-i18n="lbl_elem_mode">要素タイプ:</span>
                        <select id="modal-mesh-elem-mode" style="width:140px;" data-i18n-title="tt_mesh_elem_mode">
                            <option value="VERT" data-i18n="opt_vert">Vert</option>
                            <option value="EDGE" data-i18n="opt_edge">Edge</option>
                            <option value="FACE" data-i18n="opt_face">Face</option>
                        </select>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
                        <span data-i18n="lbl_capture_note">※対象メッシュをアクティブにして編集モードで選択してからキャプチャ</span>
                        <button id="modal-mesh-capture" class="icon-btn" data-ui-icon="capture" onclick="captureMeshSelection()" style="padding:6px 10px;" data-i18n="btn_capture" data-i18n-title="tt_capture_mesh">キャプチャ</button>
                    </div>
                    <div style="margin-top:8px; font-size:12px;"><span data-i18n="lbl_captured_count">キャプチャ数:</span> <span id="mesh-captured-count">0</span></div>
                </div>

                <div id="modal-script-area" style="display:none;" data-i18n-title="tt_script_code"><span data-i18n="lbl_script_code">実行するPythonスクリプト:</span><br><textarea id="modal-script-code" rows="8" placeholder="import bpy&#10;bpy.ops.mesh.primitive_cube_add()" style="margin-top:8px;" data-i18n-title="tt_script_code"></textarea></div>
                <div id="modal-toggle-area" style="display:none;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                        <span data-i18n="lbl_init_state">初期状態:</span>
                        <select id="modal-toggle-default" style="width:120px;" data-i18n-title="tt_toggle_init_state">
                            <option value="false">OFF</option><option value="true">ON</option>
                        </select>
                    </div>
                    <span data-i18n="lbl_script_on">ON時実行スクリプト:</span><br><textarea id="modal-script-on" rows="4" style="margin:8px 0;" data-i18n-title="tt_toggle_script_on"></textarea><br>
                    <span data-i18n="lbl_script_off">OFF時実行スクリプト:</span><br><textarea id="modal-script-off" rows="4" style="margin-top:8px;" data-i18n-title="tt_toggle_script_off"></textarea>
                    <div id="modal-toggle-state-area" style="margin-top:12px; border-top:1px solid var(--border-color); padding-top:10px;" data-i18n-title="tt_toggle_state_path">
                        <span data-i18n="lbl_state_source">Blenderの状態に連動 (任意):</span>
                        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:8px;"><span data-i18n="lbl_state_obj">状態オブジェクト:</span><select id="modal-toggle-state-obj" style="width:60%;" data-i18n-title="tt_toggle_state_obj"></select></div>
                        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:8px;"><span data-i18n="lbl_state_path">状態データパス:</span><input type="text" id="modal-toggle-state-path" style="width:60%;" placeholder="hide_viewport" data-i18n-title="tt_toggle_state_path"></div>
                        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; margin-top:8px;"><span data-i18n="lbl_state_on_value">ONとみなす値:</span><input type="text" id="modal-toggle-state-on" style="width:60%;" data-i18n-title="tt_toggle_state_on"></div>
                    </div>
                </div>
                <div id="modal-timeline-area" style="display:none;" data-i18n-title="tt_timeline_action"><span data-i18n="lbl_timeline_act">アクション:</span><br>
                    <select id="modal-timeline-action" style="width:100%; margin-top:8px; padding:6px;" data-i18n-title="tt_timeline_action">
                        <option value="play" data-i18n="tl_play">再生/一時停止</option><option value="pause" data-i18n="tl_pause">停止</option><option value="prev" data-i18n="tl_prev">前のフレーム</option><option value="next" data-i18n="tl_next">次のフレーム</option><option value="keyframe" data-i18n="tl_keyframe">キーフレーム挿入</option>
                    </select>
                </div>
                <div id="modal-camera-area" style="display:none;" data-i18n-title="tt_camera_action"><span data-i18n="lbl_cam_act">ビュー操作:</span><br>
                    <select id="modal-camera-action" style="width:100%; margin-top:8px; padding:6px;" onchange="switchCameraUI()" data-i18n-title="tt_camera_action">
                        <option value="FRONT" data-i18n="cam_front">正面</option><option value="RIGHT" data-i18n="cam_right">右</option><option value="TOP" data-i18n="cam_top">上</option><option value="CAMERA" data-i18n="cam_cam">カメラ視点へ</option>
                    </select>
                    <div id="modal-camera-obj-wrapper" style="display:none; margin-top:12px;" data-i18n-title="tt_target_camera"><span data-i18n="lbl_target_cam">対象カメラ:</span><br><select id="modal-camera-obj" style="width:100%; margin-top:8px; padding:6px;" data-i18n-title="tt_target_camera"></select></div>
                </div>
                <div id="modal-display-area" style="display:none; margin-top:16px;" data-i18n-title="tt_display_only">
                    <p style="color:var(--text-color); font-size:12px; background:rgba(0,0,0,0.2); padding:8px; border-radius:4px;" data-i18n="msg_display_only">この要素はセレクトモード時にクリックを透過し、背景や装飾として機能します。</p>
                </div>
            </div>
            <div id="modal-slider-content" style="display:none;">
                <span data-i18n="lbl_target_type">操作タイプ:</span><br><select id="slider-target-type" style="width:100%; margin:8px 0 12px 0; padding:6px;" onchange="switchSliderTargetType()" data-i18n-title="tt_slider_target_type"><option value="shapekey" data-i18n="opt_shapekey">シェイプキー</option><option value="datapath" data-i18n="opt_datapath">データパス</option></select>
                <span data-i18n="lbl_target_obj">対象オブジェクト:</span><br><select id="slider-obj-list" style="width:100%; margin:8px 0 12px 0; padding:6px;" onchange="fetchShapeKeys()" data-i18n-title="tt_slider_target_object"></select>
                <div id="slider-shapekey-area" data-i18n-title="tt_slider_shapekey"><span data-i18n="lbl_shapekey">シェイプキー:</span><br><select id="slider-key-list" style="width:100%; margin:8px 0 16px 0; padding:6px;"></select></div>
                <div id="slider-datapath-area" style="display:none;" data-i18n-title="tt_slider_datapath"><span data-i18n="lbl_datapath">データパス (例: pose.bones['Hand']['Prop']):</span><br><input type="text" id="slider-data-path" style="width:100%; margin:8px 0 16px 0; padding:6px; box-sizing:border-box;" data-i18n-title="tt_slider_datapath"></div>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:24px;">
                <button id="modal-cancel-btn" class="icon-btn" data-ui-icon="cancel" onclick="closeActionModal()" style="background:var(--btn-bg); padding:8px 16px; font-weight:bold; border:1px solid var(--border-color);" data-i18n="btn_cancel" data-i18n-title="tt_modal_cancel">キャンセル</button>
                <button id="modal-apply-btn" class="icon-btn" data-ui-icon="apply" onclick="applyActionModal()" style="background:var(--accent-color); color:#fff; padding:8px 16px; font-weight:bold; border:none;" data-i18n="btn_apply" data-i18n-title="tt_modal_apply">適用して閉じる</button>
            </div>
        </div>
    </div>

    <div id="toast-msg" role="status" aria-live="polite"></div>

    <script>

        const API_TOKEN = "{TOKEN}";
        function apiFetch(url, options={}) {
            options = options || {};
            options.headers = options.headers || {};
            options.headers['X-SST-Token'] = API_TOKEN;
            return window.fetch(url, options);
        }

                const i18n = {
                    "ja": {
                                "mode_edit": "✎ 編集モード",
                                "mode_play": "▶ セレクトモード",
                                "pin_on": "Blenderに追従: ON",
                                "pin_off": "Blenderに追従: OFF",
                                "status_ready": "準備完了",
                                "btn_save": "上書き保存",
                                "btn_save_as": "別名保存",
                                "theme_dark": "🌙 ダーク",
                                "theme_light": "☀️ ライト",
                                "display_settings": "エフェクト (ホバー/選択)",
                                "lbl_hover": "ホバー:",
                                "lbl_select": "選択時:",
                                "lbl_outline": "枠",
                                "lbl_glow": "光彩",
                                "lbl_color": "色 / 透過:",
                                "lbl_opacity": "透過:",
                                "bg_settings": "キャンバス設定",
                                "lbl_canvas_size": "サイズ(W/H):",
                                "lbl_size": "サイズ(W/H):",
                                "lbl_pos": "位置(X/Y/Z):",
                                "lbl_rotate": "回転(度):",
                                "lbl_lock": "比率固定",
                                "btn_clear_bg": "背景画像をクリア",
                                "lbl_panzoom": "機能制限:",
                                "lbl_enable": "パン＆ズーム許可",
                                "lbl_tab_colors": "タブカラー設定 (固定)",
                                "lbl_tab_bar_bg": "バー背景:",
                                "lbl_tab_bg": "タブ背景:",
                                "lbl_tab_font_color": "文字色:",
                                "lbl_tab": "タブ",
                                "lbl_text_short": "文字",
                                "lbl_active": "アクティブ",
                                "elem_settings": "要素設定",
                                "lbl_shape": "形状:",
                                "lbl_name": "ID名:",
                                "opt_circle": "〇 円",
                                "opt_square": "□ 四角",
                                "opt_tri": "△ 三角",
                                "opt_star": "☆ 星型",
                                "opt_text": "Ｔ テキストのみ",
                                "lbl_text": "文字:",
                                "btn_clear_elem": "要素の画像をクリア",
                                "lbl_font": "フォント:",
                                "font_default": "Segoe UI（標準）",
                                "font_ms_gothic": "MS ゴシック",
                                "font_ms_mincho": "MS 明朝",
                                "font_meiryo": "メイリオ",
                                "font_yu_gothic": "游ゴシック",
                                "lbl_font_color": "文字色/透:",
                                "lbl_font_size": "サイズ/装飾:",
                                "lbl_bold": "太字",
                                "lbl_align": "配置(横/縦):",
                                "lbl_border": "枠線(色/透/幅):",
                                "lbl_border_style": "枠線種:",
                                "lbl_radius": "角丸(px):",
                                "opt_line_solid": "実線",
                                "opt_line_dash": "破線",
                                "opt_line_dot": "点線",
                                "opt_align_c": "中",
                                "opt_align_l": "左",
                                "opt_align_r": "右",
                                "opt_align_t": "上",
                                "opt_align_b": "下",
                                "lbl_mode": "表示モード:",
                                "opt_both": "両方",
                                "opt_slider": "スライダのみ",
                                "opt_spinner": "数値のみ",
                                "val_min_max": "最小 / 最大:",
                                "lbl_tooltip": "ツールチップ:",
                                "lbl_tooltip_colors": "ツールチップ色:",
                                "lbl_bg_short": "背景",
                                "lbl_multi_img": "背景画像設定（透過PNG対応）",
                                "lbl_img_norm": "通常:",
                                "lbl_img_hov": "ホバー:",
                                "lbl_img_sel": "選択時:",
                                "lbl_sld_widths": "幅(バー/数値):",
                                "lbl_sld_track": "バー色/透:",
                                "lbl_sld_thumb": "ツマミ色/透:",
                                "lbl_sld_spin": "数値背景/透:",
                                "lbl_spin_font": "数値文字/透:",
                                "lbl_gap": "余白(px):",
                                "msg_no_sel": "※要素をクリックして選択",
                                "msg_multi_sel": "(複数選択中)",
                                "msg_confirm_save": "現在の状態を上書き保存しますか？",
                                "msg_prompt_save": "ファイル名を入力してください (拡張子不要):",
                                "layout_settings": "追加・レイアウト・整列",
                                "add_btn": "要素",
                                "add_slider": "スライダー",
                                "add_btn_tip": "ボタン要素を追加します。選択/スクリプト/シェイプキー/カスタムプロパティなどのアクションを割り当てられ、色・枠線・画像で見た目も調整できます。",
                                "add_slider_tip": "スライダー要素を追加します。シェイプキー/カスタムプロパティ/タイムライン値などを、ドラッグや数値入力で操作できます。",
                                "lbl_snap_elem": "スナップ",
                                "lbl_snap_grid": "グリッド表示",
                                "lbl_distribute_h": "横分散",
                                "lbl_distribute_v": "縦分散",
                                "tt_align_l": "左揃え：選択要素の左端を揃えます（編集モード/複数選択）。",
                                "tt_align_c": "中央揃え（横）：選択要素を水平方向の中央に揃えます（編集モード/複数選択）。",
                                "tt_align_r": "右揃え：選択要素の右端を揃えます（編集モード/複数選択）。",
                                "tt_dist_h": "等間隔（横）：選択要素を水平方向に等間隔で分散します（編集モード/複数選択）。",
                                "tt_align_t": "上揃え：選択要素の上端を揃えます（編集モード/複数選択）。",
                                "tt_align_m": "中央揃え（縦）：選択要素を垂直方向の中央に揃えます（編集モード/複数選択）。",
                                "tt_align_b": "下揃え：選択要素の下端を揃えます（編集モード/複数選択）。",
                                "tt_dist_v": "等間隔（縦）：選択要素を垂直方向に等間隔で分散します（編集モード/複数選択）。",
                                "tt_add_tab": "新しいタブ（ページ）を追加します。ページ分けしてセレクターを整理できます。",
                                "tt_tooltip": "ツールチップ本文：セレクトモードで要素にマウスを乗せた時に表示する説明文です。改行も反映されます。",
                                "tt_save": "上書き保存：現在開いているセレクターJSONに保存します。Ctrl+S。未保存の場合は先に「別名保存」を使ってください。",
                                "tt_save_as": "別名保存：新しいファイル名で保存します（上書きしません）。Ctrl+Shift+S。バリエーション作成に便利です。",
                                "tt_undo": "元に戻す：編集モードでは、このウィンドウ内の編集（配置/設定）を1つ戻します。セレクトモードではBlenderのUndo（Ctrl+Z）を実行します。",
                                "tt_redo": "やり直し：編集モードでは、このウィンドウ内の「元に戻す」を1つ進めます。セレクトモードではBlenderのRedo（Ctrl+Shift+Z）を実行します。",
                                "tt_copy": "コピー：選択中の要素をコピーします（編集モード）。Ctrl+C。",
                                "tt_cut": "切り取り：選択中の要素を切り取ります（編集モード）。Ctrl+X。",
                                "tt_paste": "貼り付け：クリップボードから貼り付けます（編集モード）。Ctrl+V。",
                                "tt_zindex": "重なり順（Z）です。値が大きいほど前面に表示されます。",
                                "tt_panel_layout": "追加/整列/分散/グリッドなど、レイアウトを整えるための設定です（編集モード）。",
                                "tt_prop_name": "要素のID名（内部用）です。スクリプト参照や識別に使うため、ファイル内で重複しない名前にしてください。",
                                "tt_prop_size": "要素のサイズ（幅/高さ）です。鍵アイコンで縦横比を固定できます。",
                                "tt_prop_pos": "要素の位置（X/Y）です。Zは重なり順で、値が大きいほど前面に表示されます。",
                                "tt_prop_rot": "回転角度（度）です。正の値で時計回りに回転します。",
                                "tt_prop_shape": "要素の形状です。背景透過を0%にすると、枠線のみ／テキストのみの見た目も作れます。",
                                "tt_prop_bg": "背景色と透過（0〜100%）です。0%にすると背景が透明になります。",
                                "tt_prop_border": "枠線の色・透過（0〜100%）・太さ（px）です。太さ0で枠線を非表示にできます。",
                                "tt_prop_bstyle": "枠線スタイル（実線/破線など）です。ガイドやサブ要素に便利です。",
                                "tt_prop_radius": "角の丸み（px）です（四角/矩形で有効）。値を上げるほど角が丸くなります。",
                                "tt_prop_img": "画像設定：通常/ホバー/選択時の画像を設定できます。PNG透過も反映されます。",
                                "tt_clear_image": "画像クリア：この状態（通常/ホバー/選択）の画像を削除します。",
                                "tt_prop_text": "表示テキストです。ボタン名やメモ（例：ベイク、ミラー）に使えます。",
                                "tt_prop_font": "フォントと揃え（左/中央/右）設定です。ボタン間で揃えると見やすくなります。",
                                "tt_prop_font_size": "文字サイズと装飾（太字/斜体）です。文字が長い場合は要素サイズに応じて折り返されます。",
                                "tt_prop_font_color": "文字色と透過（0〜100%）です。背景とのコントラストを上げると読みやすくなります。",
                                "tt_prop_gap": "要素内の余白（ギャップ）です。テキストやスライダーが詰まって見える時に調整します。",
                                "tt_slider_mode": "スライダー表示：バー＋数値 / バーのみ / 数値のみ を選べます。",
                                "tt_slider_widths": "スライダーバーと数値入力欄の幅（px）を個別に設定します。",
                                "tt_slider_colors": "スライダーのバー色と透過を設定します。",
                                "tt_slider_minmax": "スライダーの最小/最大値です。シェイプキーは通常 0.0〜1.0 を使います。",
                                "tt_panel_bg": "キャンバス設定：キャンバスサイズ、背景色/画像など、要素の土台となる見た目を調整します。",
                                "tt_panel_effect": "ホバー/選択エフェクト：輪郭線や光彩など、見やすさを上げる表示効果を設定します（主にセレクトモード）。",
                                "tt_mode": "モード切替。編集モード：要素の追加/移動/サイズ変更/設定変更ができます。セレクトモード：レイアウト固定で、クリックするとBlender操作を実行します（Tabキーでも切替）。",
                                "tt_lang": "このセレクターウィンドウの表示言語を切り替えます。Blender本体の言語設定は変わりません。",
                                "tt_pin": "ブラウザウィンドウをBlenderに追従させます。ON：Blender前面に追従（Windows向け）。OFF：通常の独立ウィンドウ。",
                                "tt_panel_resize": "ドラッグして設定パネルの横幅を変更します（編集モードのみ）。",
                                "tt_panzoom": "パン＆ズーム：キャンバスの移動（ドラッグ）と拡大縮小（ホイール）を許可します。誤操作防止でOFFにできます。OFFにすると表示位置が初期化されます。",
                                "tt_grid_size": "グリッド間隔（px）です。小さいほど細かくスナップできます（編集モード）。",
                                "tt_grid": "グリッド（方眼）表示を切り替えます。配置/スナップの目安になります（編集モード）。",
                                "tt_snap": "スナップ：要素の移動/サイズ変更時にグリッドやガイドへ吸着させます（編集モード）。",
                                "tt_lock_aspect": "縦横比固定：サイズ変更時に比率を維持します。画像や丸ボタンで便利です。",
                                "tt_bold": "太字のON/OFFを切り替えます。",
                                "tt_italic": "斜体のON/OFFを切り替えます。",
                                "tt_hover_outline": "ホバー輪郭線：マウスを乗せた要素に輪郭線を表示します（セレクトモード）。",
                                "tt_hover_glow": "ホバー光彩：マウスを乗せた要素を発光させます（セレクトモード）。",
                                "tt_select_outline": "選択輪郭線：選択中の要素に輪郭線を表示します（セレクトモード）。",
                                "tt_select_glow": "選択光彩：選択中の要素を発光させます（セレクトモード）。",
                                "tt_tooltip_colors": "ツールチップの色（背景/文字）です。コントラストを高くすると読みやすくなります。",
                                "ctx_title_bg": "背景操作",
                                "ctx_title_elem": "要素操作",
                                "ctx_lock": "位置をロック",
                                "ctx_unlock": "ロック解除",
                                "ctx_delete": "削除",
                                "ctx_action": "アクション設定",
                                "modal_title_btn": "アクション設定",
                                "modal_title_slider": "対象の割り当て",
                                "lbl_action_type": "動作タイプ:",
                                "opt_node": "ノード選択",
                                "opt_script": "単発スクリプト実行",
                                "opt_toggle": "トグル(ON/OFF) スクリプト",
                                "opt_timeline": "タイムライン操作",
                                "opt_camera": "カメラ/ビュー操作",
                                "opt_display": "機能なし (表示・装飾用)",
                                "lbl_target_nodes": "対象ノード (複数選択可):",
                                "lbl_script_code": "Pythonスクリプト:",
                                "lbl_init_state": "初期状態:",
                                "lbl_script_on": "ON時スクリプト:",
                                "lbl_script_off": "OFF時スクリプト:",
                                "lbl_target_type": "操作タイプ:",
                                "opt_shapekey": "シェイプキー",
                                "opt_datapath": "データパス",
                                "lbl_target_obj": "対象オブジェクト:",
                                "opt_select_obj": "-- 選択 --",
                                "lbl_shapekey": "シェイプキー:",
                                "lbl_datapath": "データパス (例: pose.bones['Hand']['Prop']):",
                                "msg_display_only": "この要素はセレクトモード時にクリックを透過し、背景や装飾として機能します。",
                                "msg_delete_tab": "このタブを削除しますか？",
                                "msg_tab_name": "タブ名:",
                                "lbl_timeline_act": "アクション:",
                                "tl_play": "再生/一時停止",
                                "tl_pause": "停止",
                                "tl_prev": "前のフレーム",
                                "tl_next": "次のフレーム",
                                "tl_keyframe": "キーフレーム挿入",
                                "lbl_cam_act": "ビュー操作:",
                                "cam_front": "正面",
                                "cam_right": "右",
                                "cam_top": "上",
                                "cam_cam": "指定カメラ視点へ",
                                "lbl_target_cam": "対象カメラ:",
                                "btn_cancel": "キャンセル",
                                "btn_apply": "適用して閉じる",
                                "msg_copy": "コピー済",
                                "msg_paste": "ペースト済",
                                "msg_save": "保存完了",
                                "msg_load": "読込完了",
                                "msg_new": "新規ファイル",
                                "opt_collection_select": "コレクション選択",
                                "opt_collection_visibility": "コレクション表示切替",
                                "opt_bone_select": "ボーン選択",
                                "opt_mesh_selectset": "メッシュ選択セット",
                                "lbl_target_collections": "対象コレクション (複数選択可):",
                                "lbl_vis_action": "表示操作:",
                                "vis_toggle": "トグル",
                                "vis_show": "表示",
                                "vis_hide": "非表示",
                                "lbl_target_armature": "アーマチュア:",
                                "lbl_target_bones": "対象ボーン (複数選択可):",
                                "lbl_target_mesh": "メッシュ:",
                                "lbl_elem_mode": "要素タイプ:",
                                "btn_capture": "キャプチャ",
                                "lbl_captured_count": "キャプチャ数:",
                                "lbl_capture_note": "※対象メッシュをアクティブにして編集モードで選択してからキャプチャ",
                                "page_prefix": "ページ",
                                "msg_capture_requires_editmode": "キャプチャするには、対象オブジェクトをアクティブにして編集モードで選択してください。",
                                "opt_vert": "頂点",
                                "opt_edge": "辺",
                                "opt_face": "面",
                                "tt_panel_elem": "選択中の要素の見た目・位置・アクション内容を編集するパネルです。まず左のキャンバスで要素をクリックしてから設定します。複数選択時は共通項目だけが表示されます。",
                                "tt_canvas_size": "キャンバスの作業領域サイズです。配置できる範囲そのものを決めます。セレクトモードでは、このサイズがウィンドウ表示の基準にもなります。",
                                "tt_canvas_bg_color": "キャンバス全体の背景色です。要素の見やすさに合わせて選びます。背景画像を使わない場合のベース色にもなります。",
                                "tt_tab_colors": "ページ切り替えタブの色設定です。バー背景、通常タブ、アクティブタブ、文字色を調整して見分けやすくします。",
                                "tt_hover_state": "ホバー時の表示効果を切り替えます。セレクトモードで、マウスを乗せたときに輪郭や光彩を出すかを選びます。",
                                "tt_hover_colors": "ホバー時エフェクトの色と透明度です。弱くしたい時は透明度を下げ、目立たせたい時はコントラストを上げます。",
                                "tt_select_state": "選択中の表示効果を切り替えます。ボタンやトグルの状態を見分けやすくしたい時に使います。",
                                "tt_select_colors": "選択中エフェクトの色と透明度です。ON状態や現在値を強調したい時に調整します。",
                                "tt_context_action": "この要素に実行させる内容を設定します。オブジェクト選択、スクリプト、タイムライン、カメラ、コレクション、ボーン、メッシュ選択セットなどを割り当てられます。",
                                "tt_context_lock": "要素の位置とサイズ変更をロック/解除します。完成レイアウトを誤って動かしたくない時に使います。",
                                "tt_context_delete": "この要素をキャンバスから削除します。保存後はファイルにも反映されます。誤って消した場合はすぐに「元に戻す」を使ってください。",
                                "tt_action_type": "ボタンをクリックした時に何を行うかを選びます。用途が決まっていない場合は、まず「ノード選択」または「機能なし」から始めると安全です。",
                                "tt_target_nodes": "このボタンで選択する対象オブジェクトを複数登録できます。Ctrl / Shift で複数選択して、まとめて選択セット化できます。",
                                "tt_target_collections": "対象コレクションを複数登録します。コレクション単位で選択や表示切替を行いたい時に使います。",
                                "tt_collection_visibility_action": "コレクション表示の動作です。トグルは現状態を反転、表示は必ず表示、非表示は必ず隠します。",
                                "tt_target_armature": "ボーン取得元のアーマチュアを選びます。先に正しいリグを選んでからボーン一覧やキャプチャを使ってください。",
                                "tt_target_bones": "このボタンで扱うボーンを複数登録します。ポーズモードで選択済みのボーンを「キャプチャ」で取り込むと速いです。",
                                "tt_capture_bones": "現在ポーズモードで選択しているボーンを一覧に取り込みます。ボーン名を手入力する必要がないので、取り違え防止に便利です。",
                                "tt_target_mesh": "メッシュ選択セットの対象メッシュです。編集モードで選んだ頂点、辺、面をこのボタンに登録できます。",
                                "tt_mesh_elem_mode": "キャプチャする要素種類です。頂点、辺、面のどれを登録するかを決めます。実際に選んだ要素タイプと合わせてからキャプチャしてください。",
                                "tt_capture_mesh": "現在の編集モード選択を取り込みます。対象メッシュをアクティブにし、同じ要素タイプを選んでから実行してください。",
                                "tt_script_code": "ボタンを押した時に実行する Python コードです。共有ファイルや不明なコードは危険なため、必要な場合だけ使ってください。",
                                "tt_toggle_init_state": "トグルボタンの初期状態です。開いた直後の見た目と、最初に実行される側のスクリプト判定に使われます。",
                                "tt_toggle_script_on": "トグルが ON になった時に実行するスクリプトです。表示切替、値変更、モード切替などを登録できます。",
                                "tt_toggle_script_off": "トグルが OFF になった時に実行するスクリプトです。ON 時の処理を戻す内容にしておくと使いやすくなります。",
                                "tt_timeline_action": "タイムライン操作の種類です。再生、停止、前後フレーム移動、キーフレーム挿入などを割り当てられます。",
                                "tt_camera_action": "ビュー操作の種類です。正面、右、上ビューや、指定カメラ視点への切り替えを設定できます。",
                                "tt_target_camera": "「指定カメラ視点へ」を選んだ時に使うカメラです。シーン内に複数カメラがある場合に使い分けます。",
                                "tt_display_only": "この要素はクリック操作を行わず、飾りや説明表示として使います。背景ラベルや区切り線を作りたい時に便利です。",
                                "tt_slider_target_type": "スライダーが操作する対象の種類です。シェイプキーならメッシュ変形、データパスなら任意の数値プロパティを操作できます。",
                                "tt_slider_target_object": "操作対象のオブジェクトです。シェイプキーやデータパスは、このオブジェクトを基準に参照されます。",
                                "tt_slider_shapekey": "このスライダーで変更するシェイプキーです。一般的には 0.0 から 1.0 の範囲で使います。",
                                "tt_slider_datapath": "数値を変更したいプロパティのデータパスです。例に近い形で正確に入力し、対象オブジェクトに存在するか確認してください。",
                                "tt_modal_cancel": "変更を保存せずにこの設定ダイアログを閉じます。編集中の値は破棄されます。",
                                "tt_modal_apply": "現在の設定をこの要素に適用してダイアログを閉じます。反映後は必要に応じて「上書き保存」を行ってください。",
                                "tt_tab_switch": "このタブを開きます。1つのセレクターをページ分けして管理している場合に使います。",
                                "tt_tab_rename": "タブ名を変更します。編集モードでタブ名をダブルクリックすると変更できます。",
                                "tt_tab_delete": "このタブを削除します。タブ内の要素も一緒に削除されるので、必要なら先に保存や複製を行ってください。",
                                "btn_saving": "保存中...",
                                "lbl_include_children": "子コレクションを含める",
                                "tt_include_children": "ONにすると、子コレクション内のオブジェクトもまとめて選択します。",
                                "lbl_state_source": "Blenderの状態に連動 (任意):",
                                "lbl_state_obj": "状態オブジェクト:",
                                "lbl_state_path": "状態データパス:",
                                "lbl_state_on_value": "ONとみなす値:",
                                "tt_toggle_state_obj": "トグルの点灯状態を読み取るオブジェクトです。データパスが空欄の場合は従来どおりボタン内部のON/OFF状態で動作します。",
                                "tt_toggle_state_path": "状態を読むデータパスです（例: hide_viewport / modifiers['Mirror'].show_viewport / ['my_prop']）。設定するとトグルの点灯はBlenderの実際の値で決まり、クリック時はONならOFF時スクリプト、OFFならON時スクリプトを実行します。",
                                "tt_toggle_state_on": "空欄なら値が真（0 / False / 空文字以外）でON扱いです。列挙・文字列の値は、ONとみなす値をそのまま入力します。",
                                "msg_script_failed": "スクリプトの実行に失敗しました",
                                "msg_script_disabled": "スクリプト実行が無効です（Nパネル設定の「スクリプト実行を許可」をONにしてください）",
                                "msg_state_unknown": "Blenderの状態を読み取れません（オブジェクトとデータパスを確認してください）",
                                "msg_invalid_datapath": "データパスに ; や改行は使えません",
                                "msg_capture_failed": "キャプチャに失敗しました",
                                "msg_capture_need_target": "先に対象（アーマチュア／メッシュ）を選んでください",
                                "msg_action_failed": "Blenderで操作を実行できませんでした",
                                "msg_action_warning": "Blenderからの警告",
                                "code_cancelled": "Blender側でキャンセルされました",
                                "code_task_queue_disabled": "Blenderのタスク処理が無効です（「常時機能切り替え」を確認してください）",
                                "code_task_queue_full": "Blenderが混雑しています。少し待ってから再試行してください",
                                "code_browser_server_disabled": "ブラウザー連携サーバーが無効です",
                                "code_armature_not_found": "アーマチュアが見つかりません",
                                "code_mesh_not_found": "メッシュが見つかりません",
                                "code_rpc_timeout": "Blenderから応答がありません",
                                "code_empty_script": "実行するスクリプトが空です",
                                "code_forbidden": "アクセストークンが一致しません（Blenderからセレクターを開き直してください）",
                                "lbl_empty_click": "空クリック:",
                                "lbl_empty_click_deselect": "Blenderの選択を解除",
                                "tt_empty_click_deselect": "セレクトモードでキャンバスの何もない所をクリックした時に、Blenderの選択を解除するかどうかです。OFFにすると、空クリックしても選択は維持されます。"
                    },
                    "en": {
                                "mode_edit": "✎ Edit Mode",
                                "mode_play": "▶ Select Mode",
                                "pin_on": "Follow: ON",
                                "pin_off": "Follow: OFF",
                                "status_ready": "Ready",
                                "btn_save": "Save",
                                "btn_save_as": "Save As",
                                "theme_dark": "🌙 Dark",
                                "theme_light": "☀️ Light",
                                "display_settings": "Effects (Hover/Select)",
                                "lbl_hover": "Hover:",
                                "lbl_select": "Select:",
                                "lbl_outline": "Line",
                                "lbl_glow": "Glow",
                                "lbl_color": "Color / A:",
                                "lbl_opacity": "Opacity:",
                                "bg_settings": "Canvas Settings",
                                "lbl_canvas_size": "Size(W/H):",
                                "lbl_size": "Size(W/H):",
                                "lbl_pos": "Pos(X/Y/Z):",
                                "lbl_rotate": "Rot(deg):",
                                "lbl_lock": "Lock Ratio",
                                "btn_clear_bg": "Clear BG Image",
                                "lbl_panzoom": "Restriction:",
                                "lbl_enable": "Enable Pan/Zoom",
                                "lbl_tab_colors": "Tab Colors (Fixed)",
                                "lbl_tab_bar_bg": "Bar BG:",
                                "lbl_tab_bg": "Tab BG:",
                                "lbl_tab_font_color": "Text Color:",
                                "lbl_tab": "Tab",
                                "lbl_text_short": "Text",
                                "lbl_active": "Active",
                                "elem_settings": "Element Settings",
                                "lbl_shape": "Shape:",
                                "lbl_name": "ID Name:",
                                "opt_circle": "〇 Circle",
                                "opt_square": "□ Square",
                                "opt_tri": "△ Triangle",
                                "opt_star": "☆ Star",
                                "opt_text": "T Text Only",
                                "lbl_text": "Text:",
                                "btn_clear_elem": "Clear Element Images",
                                "lbl_font": "Font:",
                                "font_default": "Segoe UI (Default)",
                                "font_ms_gothic": "MS Gothic",
                                "font_ms_mincho": "MS Mincho",
                                "font_meiryo": "Meiryo",
                                "font_yu_gothic": "Yu Gothic",
                                "lbl_font_color": "Color/A:",
                                "lbl_font_size": "Size / Style:",
                                "lbl_bold": "B",
                                "lbl_align": "Align(H/V):",
                                "lbl_border": "Border(C/A/W):",
                                "lbl_border_style": "Style:",
                                "lbl_radius": "Radius:",
                                "opt_line_solid": "Solid",
                                "opt_line_dash": "Dash",
                                "opt_line_dot": "Dot",
                                "opt_align_c": "C",
                                "opt_align_l": "L",
                                "opt_align_r": "R",
                                "opt_align_t": "T",
                                "opt_align_b": "B",
                                "lbl_mode": "Mode:",
                                "opt_both": "Both",
                                "opt_slider": "Slider",
                                "opt_spinner": "Spinner",
                                "val_min_max": "Min / Max:",
                                "lbl_tooltip": "Tip:",
                                "lbl_tooltip_colors": "Tip Colors:",
                                "lbl_bg_short": "BG",
                                "lbl_multi_img": "Background Images (PNG Alpha)",
                                "lbl_img_norm": "Norm:",
                                "lbl_img_hov": "Hover:",
                                "lbl_img_sel": "Selected:",
                                "lbl_sld_widths": "Width(Bar/Num):",
                                "lbl_sld_track": "Track/A:",
                                "lbl_sld_thumb": "Thumb/A:",
                                "lbl_sld_spin": "Spin BG/A:",
                                "lbl_spin_font": "Font Color/A:",
                                "lbl_gap": "Gap(px):",
                                "msg_no_sel": "* Click to select",
                                "msg_multi_sel": "(Multi)",
                                "msg_confirm_save": "Overwrite current file?",
                                "msg_prompt_save": "Enter file name (no extension):",
                                "layout_settings": "Add / Layout / Align",
                                "add_btn": "Element",
                                "add_slider": "Slider",
                                "add_btn_tip": "Add a Button element. Buttons can run actions (Select, Script, Shape Key, Custom Property, etc.) and can be styled with colors, borders, and images.",
                                "add_slider_tip": "Add a Slider element. Sliders can drive Shape Keys, custom properties, or timeline values with a draggable bar and/or numeric input.",
                                "lbl_snap_elem": "Snap",
                                "lbl_snap_grid": "Grid",
                                "lbl_distribute_h": "Distribute H",
                                "lbl_distribute_v": "Distribute V",
                                "tt_align_l": "Align selected elements to the left edge (Edit Mode / multi-select).",
                                "tt_align_c": "Align selected elements to the horizontal center (Edit Mode / multi-select).",
                                "tt_align_r": "Align selected elements to the right edge (Edit Mode / multi-select).",
                                "tt_dist_h": "Distribute selected elements evenly in X (Edit Mode / multi-select).",
                                "tt_align_t": "Align selected elements to the top edge (Edit Mode / multi-select).",
                                "tt_align_m": "Align selected elements to the vertical center (Edit Mode / multi-select).",
                                "tt_align_b": "Align selected elements to the bottom edge (Edit Mode / multi-select).",
                                "tt_dist_v": "Distribute selected elements evenly in Y (Edit Mode / multi-select).",
                                "tt_add_tab": "Add a new tab (page) to organize large selectors into pages.",
                                "tt_tooltip": "Tooltip text shown when you hover this element in Select Mode. Line breaks are preserved.",
                                "tt_save": "Save (overwrite) the current selector JSON file. Shortcut: Ctrl+S. If this selector is new (Unsaved), use Save As first.",
                                "tt_save_as": "Save As: save under a new file name (does not overwrite). Shortcut: Ctrl+Shift+S. Useful for making variations.",
                                "tt_undo": "Undo. Edit Mode: undo layout/settings changes in this window. Select Mode: send Blender Undo (Ctrl+Z).",
                                "tt_redo": "Redo. Edit Mode: redo changes in this window. Select Mode: send Blender Redo (Ctrl+Shift+Z).",
                                "tt_copy": "Copy selected elements (Edit Mode). Shortcut: Ctrl+C.",
                                "tt_cut": "Cut selected elements (Edit Mode). Shortcut: Ctrl+X.",
                                "tt_paste": "Paste elements from clipboard (Edit Mode). Shortcut: Ctrl+V.",
                                "tt_zindex": "Draw order (Z). Higher values are drawn on top.",
                                "tt_panel_layout": "Layout tools: add elements, align/distribute, and grid/snap settings (Edit Mode).",
                                "tt_prop_name": "Element ID name (internal). Keep it unique within the file; useful for scripts and identification.",
                                "tt_prop_size": "Element size (Width/Height). Use the lock icon to keep aspect ratio while resizing.",
                                "tt_prop_pos": "Element position (X/Y). Z controls draw order (higher Z = on top).",
                                "tt_prop_rot": "Rotation in degrees. Positive values rotate clockwise.",
                                "tt_prop_shape": "Element shape. Combine with background opacity 0% to make outline-only or text-only controls.",
                                "tt_prop_bg": "Background color and opacity (0–100%). Set opacity to 0% for transparency.",
                                "tt_prop_border": "Border color, opacity (0–100%), and thickness in pixels. Set thickness to 0 to hide the border.",
                                "tt_prop_bstyle": "Border style (solid/dashed). Useful for guides or secondary buttons.",
                                "tt_prop_radius": "Corner radius in pixels (for square/rect). Increase to make rounded corners.",
                                "tt_prop_img": "Images for the element: normal + optional Hover/Selected images. PNG transparency is supported.",
                                "tt_clear_image": "Clear the image for this state (normal/hover/selected).",
                                "tt_prop_text": "Text shown on the element (labels like 'Bake', 'Mirror', etc.).",
                                "tt_prop_font": "Font and alignment settings for the element text (left/center/right).",
                                "tt_prop_font_size": "Text size and style (bold/italic). Long text may wrap depending on element size.",
                                "tt_prop_font_color": "Text color and opacity (0–100%). Increase contrast for readability.",
                                "tt_prop_gap": "Spacing (gap) inside the element, e.g., between text and slider controls.",
                                "tt_slider_mode": "Slider display mode: bar+number, bar only, or number only.",
                                "tt_slider_widths": "Set widths for the slider bar and the number field (pixels).",
                                "tt_slider_colors": "Set slider bar colors and opacity.",
                                "tt_slider_minmax": "Minimum and maximum slider values. Shape Keys typically use 0.0 to 1.0.",
                                "tt_panel_bg": "Canvas settings: adjust canvas size and background color/image (your layout base).",
                                "tt_panel_effect": "Hover/Select effects: outlines and glows to improve readability (mainly Select Mode).",
                                "tt_mode": "Switch modes. Edit Mode: add/move/resize elements and change settings. Select Mode: lock the layout and run Blender actions by clicking elements (Tab also toggles).",
                                "tt_lang": "Change the selector window language. This affects only this browser UI, not Blender's language setting.",
                                "tt_pin": "Attach the browser window to Blender. ON: follow Blender / stay in front (mainly for Windows). OFF: normal independent window.",
                                "tt_panel_resize": "Drag to change the settings panel width (Edit Mode only).",
                                "tt_panzoom": "Allow or lock canvas pan/zoom. Turn OFF to prevent accidental view movement; the view resets when disabled.",
                                "tt_grid_size": "Grid spacing in pixels. Smaller values = finer snapping (Edit Mode).",
                                "tt_grid": "Toggle the grid overlay on the canvas. The grid helps with alignment and snapping (Edit Mode).",
                                "tt_snap": "Snap elements while moving/resizing to the grid and guides (Edit Mode).",
                                "tt_lock_aspect": "Lock aspect ratio while resizing (keep width/height proportion). Useful for images and round buttons.",
                                "tt_bold": "Toggle bold text.",
                                "tt_italic": "Toggle italic text.",
                                "tt_hover_outline": "Show an outline when the mouse hovers an element (Select Mode).",
                                "tt_hover_glow": "Show a glow when the mouse hovers an element (Select Mode).",
                                "tt_select_outline": "Show an outline for selected elements (Select Mode).",
                                "tt_select_glow": "Show a glow for selected elements (Select Mode).",
                                "tt_tooltip_colors": "Tooltip colors for this element (background/text). Use high contrast for readability.",
                                "ctx_title_bg": "BG Action",
                                "ctx_title_elem": "Element Action",
                                "ctx_lock": "Lock Pos",
                                "ctx_unlock": "Unlock Pos",
                                "ctx_delete": "Delete",
                                "ctx_action": "Action Settings",
                                "modal_title_btn": "Action Settings",
                                "modal_title_slider": "Target Assignment",
                                "lbl_action_type": "Type:",
                                "opt_node": "Select Node",
                                "opt_script": "Run Script",
                                "opt_toggle": "Toggle Script",
                                "opt_timeline": "Timeline Control",
                                "opt_camera": "Camera/View Control",
                                "opt_display": "Display Only (No Action)",
                                "lbl_target_nodes": "Target Nodes:",
                                "lbl_script_code": "Python Code:",
                                "lbl_init_state": "Initial:",
                                "lbl_script_on": "ON Script:",
                                "lbl_script_off": "OFF Script:",
                                "lbl_target_type": "Target Type:",
                                "opt_shapekey": "Shape Key",
                                "opt_datapath": "Data Path",
                                "lbl_target_obj": "Object:",
                                "opt_select_obj": "-- Select --",
                                "lbl_shapekey": "Shape Key:",
                                "lbl_datapath": "Data Path (e.g. pose.bones['H']['P']):",
                                "msg_display_only": "This element ignores clicks in Select Mode and acts as decoration.",
                                "lbl_timeline_act": "Action:",
                                "tl_play": "Play/Pause",
                                "tl_pause": "Stop",
                                "tl_prev": "Prev Frame",
                                "tl_next": "Next Frame",
                                "tl_keyframe": "Insert Keyframe",
                                "lbl_cam_act": "View:",
                                "cam_front": "Front",
                                "cam_right": "Right",
                                "cam_top": "Top",
                                "cam_cam": "To Camera View",
                                "lbl_target_cam": "Camera:",
                                "btn_cancel": "Cancel",
                                "btn_apply": "Apply",
                                "msg_copy": "Copied",
                                "msg_paste": "Pasted",
                                "msg_save": "Saved",
                                "msg_load": "Loaded",
                                "msg_new": "New File",
                                "opt_collection_select": "Select Collection",
                                "opt_collection_visibility": "Toggle Collection Visibility",
                                "opt_bone_select": "Select Bones",
                                "opt_mesh_selectset": "Mesh Selection Set",
                                "lbl_target_collections": "Target Collections (multi-select):",
                                "lbl_vis_action": "Visibility:",
                                "vis_toggle": "Toggle",
                                "vis_show": "Show",
                                "vis_hide": "Hide",
                                "lbl_target_armature": "Armature:",
                                "lbl_target_bones": "Target Bones (multi-select):",
                                "lbl_target_mesh": "Mesh:",
                                "lbl_elem_mode": "Element Type:",
                                "btn_capture": "Capture",
                                "lbl_captured_count": "Captured:",
                                "lbl_capture_note": "*Capture requires the target mesh active in Edit Mode",
                                "msg_delete_tab": "Delete this tab?",
                                "msg_tab_name": "Tab name:",
                                "page_prefix": "Page",
                                "msg_capture_requires_editmode": "To capture, make the target object active and select elements in Edit Mode.",
                                "opt_vert": "Vert",
                                "opt_edge": "Edge",
                                "opt_face": "Face",
                                "tt_panel_elem": "Panel for editing the selected element. First click an element on the canvas, then adjust its layout, visuals, tooltip, and action. When multiple elements are selected, only shared settings are shown.",
                                "tt_canvas_size": "Size of the selector canvas. This defines the usable layout area. In Select Mode, the canvas size is also the basis for the window size.",
                                "tt_canvas_bg_color": "Background color for the whole canvas. Choose a color that keeps buttons and labels easy to read. This is also the base color when no background image is used.",
                                "tt_tab_colors": "Colors for the page tabs. Adjust the tab bar, normal tab, active tab, and text colors so users can tell pages apart quickly.",
                                "tt_hover_state": "Enable or disable the hover effects used in Select Mode. Turn outline and glow on or off depending on how strong you want hover feedback to be.",
                                "tt_hover_colors": "Color and opacity for the hover effect. Lower opacity for a subtle hint, or increase contrast when you want hovered controls to stand out clearly.",
                                "tt_select_state": "Enable or disable the visual effects for selected or active elements. Useful for making toggle states and current selections easier to understand.",
                                "tt_select_colors": "Color and opacity for the selected-state effect. Increase contrast when you want active controls or ON states to read more clearly.",
                                "tt_context_action": "Open the action settings for this element. Here you assign what the button or slider should do in Blender, such as object selection, scripts, timeline control, camera view changes, bone selection, or mesh selection sets.",
                                "tt_context_lock": "Lock or unlock this element so it cannot be moved or resized by mistake. Useful after the layout is finished.",
                                "tt_context_delete": "Delete this element from the canvas. The removal is saved into the selector file after you save. If you delete something by mistake, use Undo right away.",
                                "tt_action_type": "Choose what happens when this button is clicked. If you are unsure, start with a safe action such as object selection or display-only.",
                                "tt_target_nodes": "Choose one or more target objects for this button. Use Ctrl or Shift to register a reusable multi-object selection set.",
                                "tt_target_collections": "Choose one or more collections for this action. Use this when you want a button to work at the collection level instead of individual objects.",
                                "tt_collection_visibility_action": "Choose how collection visibility behaves. Toggle flips the current state, Show always shows, and Hide always hides.",
                                "tt_target_armature": "Choose the armature that provides the bone list. Select the correct rig first, then use the bone list or Capture to fill the targets.",
                                "tt_target_bones": "Choose one or more bones for this button. A quick workflow is to select bones in Pose Mode and use Capture instead of picking names manually.",
                                "tt_capture_bones": "Capture the bones currently selected in Pose Mode and put them into the target list. This helps avoid typing mistakes and speeds up setup.",
                                "tt_target_mesh": "Choose the mesh used for this mesh selection set. The button can later restore a saved set of selected vertices, edges, or faces.",
                                "tt_mesh_elem_mode": "Choose which type of mesh element to capture: vertices, edges, or faces. Match this to the element type you actually selected in Edit Mode.",
                                "tt_capture_mesh": "Capture the current Edit Mode selection from the target mesh. Make sure the correct object is active and the correct element type is chosen first.",
                                "tt_script_code": "Python code executed when the button runs. Use this only when needed, and avoid unknown code from shared files unless you trust the source.",
                                "tt_toggle_init_state": "Initial state of the toggle button. This controls how the button looks when the selector opens and which side of the toggle is considered active first.",
                                "tt_toggle_script_on": "Python code to run when the toggle switches ON. Typical uses include enabling visibility, setting values, or switching modes.",
                                "tt_toggle_script_off": "Python code to run when the toggle switches OFF. It is usually easiest to make this reverse the ON action.",
                                "tt_timeline_action": "Choose the timeline command for this button, such as play, stop, step to next or previous frame, or insert a keyframe.",
                                "tt_camera_action": "Choose the viewport action for this button, such as Front, Right, Top, or switching to a specific camera view.",
                                "tt_target_camera": "Choose which camera should be used when the action is set to Camera View. Useful in scenes with multiple cameras.",
                                "tt_display_only": "This element does not run any click action. Use it as decoration, a label, or a visual divider inside the selector layout.",
                                "tt_slider_target_type": "Choose what the slider controls. Shape Key is best for mesh deformation sliders, while Data Path is for any numeric property you want to drive.",
                                "tt_slider_target_object": "Object that owns the target Shape Key or property. The slider reads and writes values relative to this object.",
                                "tt_slider_shapekey": "Choose the Shape Key driven by this slider. A common range is 0.0 to 1.0, but you can set wider limits if needed.",
                                "tt_slider_datapath": "Enter the data path for the numeric property you want to control. Make sure the path is correct and really exists on the chosen object.",
                                "tt_modal_cancel": "Close this dialog without applying the changes. Any edits made in the dialog are discarded.",
                                "tt_modal_apply": "Apply the current settings to the element and close the dialog. Save the selector file afterward if you want the changes stored on disk.",
                                "tt_tab_switch": "Open this tab. Tabs let you split one selector into multiple pages for cleaner organization.",
                                "tt_tab_rename": "Rename this tab. In Edit Mode, you can double-click the tab name to change it.",
                                "tt_tab_delete": "Delete this tab. All elements inside that tab are removed too, so save or duplicate first if you still need them.",
                                "btn_saving": "Saving...",
                                "lbl_include_children": "Include child collections",
                                "tt_include_children": "When ON, objects in child collections are selected as well.",
                                "lbl_state_source": "Follow Blender state (optional):",
                                "lbl_state_obj": "State object:",
                                "lbl_state_path": "State data path:",
                                "lbl_state_on_value": "ON value:",
                                "tt_toggle_state_obj": "Object whose property drives this toggle's lit state. Leave the data path empty to keep the classic internal ON/OFF state.",
                                "tt_toggle_state_path": "Data path read for the state (e.g. hide_viewport / modifiers['Mirror'].show_viewport / ['my_prop']). When set, the toggle lights from the real Blender value; a click runs the OFF script when the value is ON and the ON script when it is OFF.",
                                "tt_toggle_state_on": "Empty: ON when the value is truthy (not 0 / False / empty). For enum or string values, type the value that means ON.",
                                "msg_script_failed": "Script failed",
                                "msg_script_disabled": "Script execution is disabled (turn on 'Allow Execute Script' in the N-panel settings)",
                                "msg_state_unknown": "Cannot read the Blender state (check the object and data path)",
                                "msg_invalid_datapath": "Data paths cannot contain ';' or line breaks",
                                "msg_capture_failed": "Capture failed",
                                "msg_capture_need_target": "Choose the target (armature / mesh) first",
                                "msg_action_failed": "Blender could not run the action",
                                "msg_action_warning": "Blender warning",
                                "code_cancelled": "Cancelled in Blender",
                                "code_task_queue_disabled": "Blender's task queue is disabled (check Always-on Toggles)",
                                "code_task_queue_full": "Blender is busy; wait a moment and try again",
                                "code_browser_server_disabled": "The browser bridge server is disabled",
                                "code_armature_not_found": "Armature not found",
                                "code_mesh_not_found": "Mesh not found",
                                "code_rpc_timeout": "Blender did not respond",
                                "code_empty_script": "The script is empty",
                                "code_forbidden": "Access token mismatch (reopen the selector from Blender)",
                                "lbl_empty_click": "Empty click:",
                                "lbl_empty_click_deselect": "Deselect in Blender",
                                "tt_empty_click_deselect": "In Select Mode, whether clicking an empty spot on the canvas clears Blender's selection. Turn OFF to keep the selection on empty clicks."
                    }
        };

        let currentLang = 'ja';
        function stripJsonExt(fn){ try{ if(!fn) return ''; const s=String(fn); return s.toLowerCase().endsWith('.json') ? s.slice(0, -5) : s; }catch(e){ return fn||''; } }
        function changeTheme() {
            const sel = document.getElementById('theme-select');
            if(!sel) return;
            const th = sel.value;
            if(th==='light') document.body.classList.add('light-theme'); else document.body.classList.remove('light-theme');
            pageSettings.theme = th;
            pushHistory();
        }
        function applyInheritedTooltips(){
            document.querySelectorAll('input, select, button, textarea, summary').forEach(el => {
                if(el.title) return;
                const owner = el.closest('[data-i18n-title]');
                if(owner && owner !== el && owner.title) {
                    el.title = owner.title;
                }
            });
        }
        function translateStatusMessage(msg){
            const lookup = {
                'Capture requires the target object to be active and in Edit Mode.': 'msg_capture_requires_editmode'
            };
            const key = lookup[String(msg || '')];
            return key ? (i18n[currentLang][key] || msg) : msg;
        }
        function applyFallbackTooltips(){
            document.querySelectorAll('#properties input, #properties select, #properties button, #properties textarea, #toolbar button, #toolbar select, #context-menu button, #action-modal input, #action-modal select, #action-modal button, #action-modal textarea').forEach(el => {
                if(el.title) return;
                const row = el.closest('.prop-row');
                const label = row ? row.querySelector('.prop-label') : null;
                const source = label ? label.innerText.replace(/[:：]$/, '') : (el.innerText || el.getAttribute('aria-label') || el.id || '');
                if(source) el.title = currentLang === 'ja' ? `${source} の設定です。` : `Settings for ${source}.`;
            });
        }

        function applyTranslations() {
            document.documentElement.lang = currentLang === 'ja' ? 'ja' : 'en';
            document.querySelectorAll('[data-i18n]').forEach(el => { const key = el.getAttribute('data-i18n'); if (i18n[currentLang][key]) el.innerText = i18n[currentLang][key]; });
            document.querySelectorAll('[data-i18n-title]').forEach(el => { const key = el.getAttribute('data-i18n-title'); if (i18n[currentLang][key]) el.title = i18n[currentLang][key]; });

            ['mode-select', 'btn-shape', 'slider-mode', 'modal-action-type', 'modal-timeline-action', 'modal-camera-action', 'modal-mesh-elem-mode', 'slider-target-type', 'btn-border-s', 'elem-align-h', 'elem-align-v'].forEach(id => { const sel = document.getElementById(id); if(sel) { Array.from(sel.options).forEach(opt => { const key = opt.getAttribute('data-i18n'); if(key && i18n[currentLang][key]) opt.innerText = i18n[currentLang][key]; }); } });
            if(targetMenuObj) {
                const isBg = (targetMenuObj === 'bg'); document.getElementById('ctx-title').innerText = isBg ? i18n[currentLang]['ctx_title_bg'] : (targetMenuObj.dataset.type === 'slider' ? i18n[currentLang]['modal_title_slider'] : i18n[currentLang]['ctx_title_elem']);
                const isLocked = isBg ? bgData.locked : targetMenuObj.dataset.locked === 'true'; document.getElementById('ctx-lock-btn').innerText = isLocked ? i18n[currentLang]['ctx_unlock'] : i18n[currentLang]['ctx_lock'];
            }
            document.getElementById('topmost-btn').innerText = isTopmost ? i18n[currentLang]['pin_on'] : i18n[currentLang]['pin_off'];
            document.getElementById('current-file-label').innerText = fileName ? `[${stripJsonExt(fileName)}]` : (currentLang === 'ja' ? '[未保存]' : '[Unsaved]');
            document.title = `Smart Selector [${fileName ? stripJsonExt(fileName) : (currentLang === 'ja' ? '未保存' : 'Unsaved')}]`;
            if(Array.isArray(pages) && pages.length) renderTabs();
            applyInheritedTooltips();
            applyFallbackTooltips();
        }

        function setStatusMsg(key) { document.getElementById('status').innerText = i18n[currentLang][key] || key; }
        function i18nText(key) { return (i18n[currentLang] && i18n[currentLang][key]) || (i18n.en && i18n.en[key]) || key; }

        function updateImageClearButtons() {
            [['btn-img','image'], ['btn-img-h','imageH'], ['btn-img-s','imageS']].forEach(([inputId, key]) => {
                const input = document.getElementById(inputId);
                if(!input) return;
                const btn = document.getElementById(inputId + '-clear');
                const elem = activeEditBtns.length > 0 ? activeEditBtns[0] : null;
                const hasImg = !!(elem && elem.dataset && elem.dataset[key]);
                if(btn) {
                    btn.style.display = hasImg ? 'block' : 'none';
                }
            });
        }

        const urlParams = new URLSearchParams(window.location.search);
        const projectName = urlParams.get('project') || "Default_Project"; let fileName = urlParams.get('file') || ""; const initMode = urlParams.get('mode') || "edit";
        const launchLang = (urlParams.get('lang') || 'ja').toLowerCase().startsWith('ja') ? 'ja' : 'en';
        const initLang = launchLang;
        currentLang = initLang;

        let isEditMode = true; let isTopmost = true; let targetMenuObj = null;
        let activeEditBtns = []; let dragObjsData = []; let clipboard = [];
        let isSelecting = false; let isResizing = false; let resizeElem = null;
        let startX = 0, startY = 0; let dragMouseStartX = 0; let dragMouseStartY = 0;
        let panX = 0, panY = 0, zoomScale = 1.0; let isPanning = false;
        let isResizingPanel = false; let startPanelW = 380; let panelStartX = 0;

        const viewport = document.getElementById('canvas-viewport'); const workspace = document.getElementById('workspace');
        const gridLayer = document.getElementById('grid-layer'); const bgLayer = document.getElementById('bg-layer');
        const selectionBox = document.getElementById('selection-box'); const snapV = document.getElementById('snap-v'); const snapH = document.getElementById('snap-h');
        const ctxMenu = document.getElementById('context-menu'); const statusText = document.getElementById('status');
        const propsPanel = document.getElementById('properties'); const tabsContainer = document.getElementById('tabs-container'); const tabBar = document.getElementById('tab-bar');

        let historyStack = []; let historyPtr = -1;

        let historyPushTimer = null;
        // 変更中の頻繁な保存を防ぐためのキュー機能
        function queueHistory(){
            if(!isEditMode) return;
            clearTimeout(historyPushTimer);
            historyPushTimer = setTimeout(() => { try{ pushHistory(); }catch(e){} }, 300);
        }

        function serializeHistoryState() {
            saveCurrentPageData();
            return JSON.stringify({ pages: pages, pageSettings: pageSettings, currentPageIndex: currentPageIndex, isTopmost: isTopmost });
        }
        function applyHistoryUIState(){
            document.getElementById('hover-color').value = pageSettings.hoverColor; document.getElementById('select-color').value = pageSettings.selectColor;
            document.getElementById('hover-opacity').value = pageSettings.hoverOpacity; document.getElementById('select-opacity').value = pageSettings.selectOpacity;
            document.getElementById('hover-outline-chk').checked = pageSettings.hoverOutline ?? true; document.getElementById('hover-glow-chk').checked = pageSettings.hoverGlow ?? true;
            document.getElementById('select-outline-chk').checked = pageSettings.selectOutline ?? true; document.getElementById('select-glow-chk').checked = pageSettings.selectGlow ?? true;
            document.getElementById('panzoom-toggle').checked = pageSettings.enablePanZoom ?? true;
            document.getElementById('empty-click-deselect-toggle').checked = pageSettings.emptyClickDeselect !== false;
            document.getElementById('tab-bar-bg').value = pageSettings.tabBarBg || '#2d2d2d'; document.getElementById('tab-bg').value = pageSettings.tabBg || '#1e1e1e'; document.getElementById('tab-act-bg').value = pageSettings.tabActBg || '#0e639c';
            document.getElementById('tab-font-color').value = pageSettings.tabFontColor || '#aaaaaa'; document.getElementById('tab-act-font-color').value = pageSettings.tabActFontColor || '#ffffff';
            document.documentElement.style.setProperty('--panel-width', (pageSettings.panelWidth || 380) + 'px');
            updateColors(true); updateTabColors(); applyTranslations();
            const topBtn = document.getElementById('topmost-btn');
            topBtn.innerText = isTopmost ? i18n[currentLang]['pin_on'] : i18n[currentLang]['pin_off'];
            topBtn.style.background = isTopmost ? '#b7845a' : 'var(--btn-bg)';
            topBtn.style.color = isTopmost ? '#fff' : 'var(--text-color)';
        }
        function pushHistory() {
            const state = serializeHistoryState();
            if(historyPtr >= 0 && historyStack[historyPtr] === state) return;
            historyStack = historyStack.slice(0, historyPtr + 1);
            historyStack.push(state);
            if(historyStack.length > 50) historyStack.shift();
            else historyPtr++;
        }
        function sendBlenderUndo(){ apiFetch('/api/blender_undo', { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' }); }
        function sendBlenderRedo(){ apiFetch('/api/blender_redo', { method:'POST', headers:{'Content-Type':'application/json'}, body:'{}' }); }
        function undo() {
            clearTimeout(historyPushTimer); // Undo直前に未確定の遅延セーブがあればキャンセル
            if(!isEditMode) { sendBlenderUndo(); return; }
            if(historyPtr > 0) { historyPtr--; restoreHistory(); }
        }
        function redo() {
            clearTimeout(historyPushTimer); // Redo直前に未確定の遅延セーブがあればキャンセル
            if(!isEditMode) { sendBlenderRedo(); return; }
            if(historyPtr < historyStack.length - 1) { historyPtr++; restoreHistory(); }
        }
        function restoreHistory() {
            if(historyPtr < 0 || !historyStack[historyPtr]) return;
            const state = safeJsonObject(historyStack[historyPtr]);
            if(!Object.keys(state).length) return;
            pages = Array.isArray(state.pages) ? state.pages : [];
            pageSettings = (state.pageSettings && typeof state.pageSettings === 'object') ? state.pageSettings : pageSettings;
            currentPageIndex = Math.max(0, Math.min(state.currentPageIndex ?? 0, Math.max(0, pages.length - 1)));
            isTopmost = !!state.isTopmost; currentLang = launchLang;
            applyHistoryUIState();
            if(currentPageIndex >= pages.length) currentPageIndex = pages.length - 1;
            switchTab(currentPageIndex, true);
        }

        let pages = []; let currentPageIndex = -1;
        let pageSettings = { hoverColor: "#f1c40f", selectColor: "#e74c3c", hoverOpacity: 25, selectOpacity: 25, hoverOutline: true, hoverGlow: true, selectOutline: true, selectGlow: true, enablePanZoom: true, emptyClickDeselect: true, tabBg: '#1e1e1e', tabBarBg: '#2d2d2d', tabActBg: '#0e639c', tabFontColor: '#aaaaaa', tabActFontColor: '#ffffff', panelWidth: 380 };

        function makeDefaultPageName(index) { const prefix = i18n[currentLang]['page_prefix'] || (currentLang === 'ja' ? 'ページ' : 'Page'); return `${prefix} ${index}`; }
        function createEmptyPage(name) { return { id: "page_" + Date.now(), name: name || makeDefaultPageName(1), canvasW: 500, canvasH: 500, background: { color: "#1e1e1e" }, elems: [], panX:0, panY:0, zoom:1.0 }; }

        function hexToRgba(hex, opacity) { let c; if(/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)){ c= hex.substring(1).split(''); if(c.length== 3){ c= [c[0], c[0], c[1], c[1], c[2], c[2]]; } c= '0x'+c.join(''); return 'rgba('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+','+(opacity/100)+')'; } return `rgba(255,255,255,${opacity/100})`; }
        function safeJsonParse(text, fallback) { try { const value = JSON.parse(text || ''); return value === undefined ? fallback : value; } catch(e) { return fallback; } }
        function safeJsonArray(text) { const value = safeJsonParse(text, []); return Array.isArray(value) ? value : []; }
        function safeJsonObject(text) { const value = safeJsonParse(text, {}); return (value && typeof value === 'object' && !Array.isArray(value)) ? value : {}; }
        function numOr(v, d) { const n = parseFloat(v); return Number.isFinite(n) ? n : d; }
        let _toastTimer = null;
        function showToast(msg) {
            const el = document.getElementById('toast-msg'); if(!el) return;
            el.textContent = String(msg || '').slice(0, 240); el.style.display = 'block';
            clearTimeout(_toastTimer); _toastTimer = setTimeout(() => { el.style.display = 'none'; }, 4000);
        }
        // Blender state cached from /api/state (datapaths / selected pose bones of watched armatures).
        let _lastDatapaths = null; let _lastSelectedBones = {};
        // Action modal: mesh capture taken in this modal session, and whether the async list fill has landed.
        let _modalMeshCapture = null; let _modalDataReady = false;
        function isSafeDataPath(p) { p = String(p || ''); return !!p.trim() && !p.includes(';') && !p.includes(String.fromCharCode(10)) && !p.includes(String.fromCharCode(13)); }
        function updateColors(skipHistory=false) {
            pageSettings.hoverColor = document.getElementById('hover-color').value; pageSettings.selectColor = document.getElementById('select-color').value;
            pageSettings.hoverOpacity = document.getElementById('hover-opacity').value; pageSettings.selectOpacity = document.getElementById('select-opacity').value;
            pageSettings.hoverOutline = document.getElementById('hover-outline-chk').checked; pageSettings.hoverGlow = document.getElementById('hover-glow-chk').checked;
            pageSettings.selectOutline = document.getElementById('select-outline-chk').checked; pageSettings.selectGlow = document.getElementById('select-glow-chk').checked;
            document.documentElement.style.setProperty('--hover-color', pageSettings.hoverColor); document.documentElement.style.setProperty('--select-color', pageSettings.selectColor);
            document.documentElement.style.setProperty('--hover-overlay-color', hexToRgba(pageSettings.hoverColor, pageSettings.hoverOpacity)); document.documentElement.style.setProperty('--select-overlay-color', hexToRgba(pageSettings.selectColor, pageSettings.selectOpacity));
            let hFilter = []; if(pageSettings.hoverGlow) hFilter.push('drop-shadow(0 0 4px var(--hover-color))'); if(pageSettings.hoverOutline) hFilter.push('drop-shadow(0 0 2px var(--hover-color))'); document.documentElement.style.setProperty('--hover-filter', hFilter.length > 0 ? hFilter.join(' ') : 'none');
            let sFilter = []; if(pageSettings.selectGlow) sFilter.push('drop-shadow(0 0 6px var(--select-color))'); if(pageSettings.selectOutline) sFilter.push('drop-shadow(0 0 3px var(--select-color))'); document.documentElement.style.setProperty('--select-filter', sFilter.length > 0 ? sFilter.join(' ') : 'none');
            if(!skipHistory) queueHistory();
        }
        function updateTabColors() {
            pageSettings.tabBarBg = document.getElementById('tab-bar-bg').value; pageSettings.tabBg = document.getElementById('tab-bg').value; pageSettings.tabActBg = document.getElementById('tab-act-bg').value;
            pageSettings.tabFontColor = document.getElementById('tab-font-color').value; pageSettings.tabActFontColor = document.getElementById('tab-act-font-color').value;
            document.documentElement.style.setProperty('--tab-bar-bg', pageSettings.tabBarBg); document.documentElement.style.setProperty('--tab-bg', pageSettings.tabBg); document.documentElement.style.setProperty('--tab-active-bg', pageSettings.tabActBg);
            document.documentElement.style.setProperty('--tab-color', pageSettings.tabFontColor); document.documentElement.style.setProperty('--tab-active-color', pageSettings.tabActFontColor);
            queueHistory();
        }
        function togglePanZoom() { pageSettings.enablePanZoom = document.getElementById('panzoom-toggle').checked; if(!pageSettings.enablePanZoom){ resetCanvasViewAndResize(); } pushHistory(); }
        function toggleEmptyClickDeselect() { pageSettings.emptyClickDeselect = document.getElementById('empty-click-deselect-toggle').checked; pushHistory(); }

        window.onload = () => {
            currentLang = initLang.startsWith('ja') ? 'ja' : 'en';
            applyTranslations();
            // No watch POST here: switchTab() (new page or after loadData) registers the page's real watch set.

            document.getElementById('panel-resizer').onmousedown = (e) => {
                if(!isEditMode) return;
                isResizingPanel = true;
                startPanelW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--panel-width')) || 380;
                panelStartX = e.clientX;
                e.preventDefault();
                document.body.classList.add('resizing-panel');
            };

            if(fileName) { loadData(() => { pushHistory(); if(initMode === 'play') { document.getElementById('mode-select').value = 'play'; toggleMode(); } toggleTopmost(isTopmost); }); }
            else { pages.push(createEmptyPage(makeDefaultPageName(1))); switchTab(0); updateColors(true); pushHistory(); toggleTopmost(isTopmost); applyTranslations(); document.documentElement.style.setProperty('--panel-width', '380px'); pageSettings.panelWidth = 380; }

            document.addEventListener('keydown', (e) => {
                const active = document.activeElement;
                const activeTag = active && active.tagName ? active.tagName.toUpperCase() : '';
                const isInput = activeTag === 'INPUT' || activeTag === 'TEXTAREA' || activeTag === 'SELECT' || !!(active && active.isContentEditable);

                if(e.key === 'Tab' && !isInput) { e.preventDefault(); document.getElementById('mode-select').value = isEditMode ? 'play' : 'edit'; toggleMode(); return; }

                if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
                    e.preventDefault();
                    if(e.shiftKey) { saveAsFile(); } else { saveFile(); }
                    return;
                }

                // 入力中はplay/edit双方でブラウザ標準のテキストUndo/Redoを優先する。
                if((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === 'z') {
                    if(isInput) return;
                    e.preventDefault();
                    if(e.shiftKey) redo(); else undo();
                    return;
                }

                if (!isEditMode) return;
                if(isInput) return;

                // Copy / Cut / Paste
                if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') { e.preventDefault(); copyElems(); }
                if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x') { e.preventDefault(); cutElems(); }
                if((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') { e.preventDefault(); pasteElems(); }
            });

            window.addEventListener('resize', () => {
                if(!isEditMode) {
                    if(pageSettings.fixedW && pageSettings.fixedH) { window.resizeTo(pageSettings.fixedW, pageSettings.fixedH); }
                }
            });
        };

        function getWorkspacePos(clientX, clientY) { const rect = viewport.getBoundingClientRect(); return { x: (clientX - rect.left - panX) / zoomScale, y: (clientY - rect.top - panY) / zoomScale }; }
        function applyTransform() {
            workspace.style.transform = `translate(${panX}px, ${panY}px) scale(${zoomScale})`;
            document.getElementById('scroll-content').style.width = (parseFloat(document.getElementById('canvas-w').value) * zoomScale + panX) + 'px';
            document.getElementById('scroll-content').style.height = (parseFloat(document.getElementById('canvas-h').value) * zoomScale + panY) + 'px';
        }

        function resetCanvasViewAndResize(pW, pH) {
            panX = 0; panY = 0; zoomScale = 1.0; applyTransform();
            let cw = pW || parseFloat(document.getElementById('canvas-w').value) || 500;
            let ch = pH || parseFloat(document.getElementById('canvas-h').value) || 500;
            if(!isEditMode) {
                let diffW = window.outerWidth - window.innerWidth; let diffH = window.outerHeight - window.innerHeight;
                if(diffW < 0 || diffW > 200) diffW = 16; if(diffH < 0 || diffH > 200) diffH = 39;
                let targetW = cw + diffW; let targetH = ch + diffH + (pages.length <= 1 ? 0 : 32);
                try { window.resizeTo(targetW, targetH); pageSettings.fixedW = targetW; pageSettings.fixedH = targetH; } catch(e){}
            }
        }

        viewport.addEventListener('wheel', (e) => {
            if(!pageSettings.enablePanZoom) return;
            if(e.ctrlKey) return; e.preventDefault();
            const zoomAmount = e.deltaY * -0.001; const newZoom = Math.min(Math.max(0.1, zoomScale + zoomAmount), 5.0);
            const rect = viewport.getBoundingClientRect(); const mouseX = e.clientX - rect.left; const mouseY = e.clientY - rect.top;
            panX = mouseX - (mouseX - panX) * (newZoom / zoomScale); panY = mouseY - (mouseY - panY) * (newZoom / zoomScale); zoomScale = newZoom; applyTransform();
        });

        function renderTabs() {
            tabsContainer.innerHTML = "";
            const switchTitle = i18n[currentLang]['tt_tab_switch'] || '';
            const renameTitle = i18n[currentLang]['tt_tab_rename'] || switchTitle;
            const deleteTitle = i18n[currentLang]['tt_tab_delete'] || '';
            pages.forEach((p, idx) => {
                const div = document.createElement('div');
                div.className = "tab " + (idx === currentPageIndex ? "active" : "");
                div.title = switchTitle;

                const nameSpan = document.createElement('span');
                nameSpan.textContent = p.name;
                nameSpan.title = isEditMode ? renameTitle : switchTitle;
                nameSpan.ondblclick = (event) => { if(isEditMode) renameTab(idx, event); };
                div.appendChild(nameSpan);

                if(isEditMode && pages.length > 1) {
                    const closeSpan = document.createElement('span');
                    closeSpan.className = 'tab-close';
                    closeSpan.textContent = '×';
                    closeSpan.title = deleteTitle;
                    closeSpan.onclick = (event) => deleteTab(idx, event);
                    div.appendChild(closeSpan);
                }

                div.onclick = () => switchTab(idx);
                tabsContainer.appendChild(div);
            });
            document.getElementById('add-tab-btn').style.display = isEditMode ? 'block' : 'none';
        }
        function addPage() { pages.push(createEmptyPage(makeDefaultPageName(pages.length + 1))); switchTab(pages.length - 1); pushHistory(); }
        function deleteTab(idx, e) { e.stopPropagation(); if(confirm(i18n[currentLang]['msg_delete_tab'])) { pages.splice(idx, 1); if(currentPageIndex >= pages.length) currentPageIndex = pages.length - 1; switchTab(currentPageIndex); pushHistory(); } }
        function renameTab(idx, e) { e.stopPropagation(); const newName = prompt(i18n[currentLang]['msg_tab_name'], pages[idx].name); if(newName) { pages[idx].name = newName; renderTabs(); pushHistory(); } }

        function saveCurrentPageData() {
            if(currentPageIndex < 0 || !pages[currentPageIndex]) return;
            const p = pages[currentPageIndex]; p.background = { ...bgData }; p.panX = panX; p.panY = panY; p.zoom = zoomScale;
            p.canvasW = parseFloat(document.getElementById('canvas-w').value) || 500; p.canvasH = parseFloat(document.getElementById('canvas-h').value) || 500;
            const elems = [];
            document.querySelectorAll('.selector-btn').forEach(b => {
                if(b.id === 'bg-layer') return;
                elems.push({
                    id: b.id, type: b.dataset.type, itemName: b.dataset.itemName, x: b.style.left, y: b.style.top, z: b.style.zIndex || 10, width: b.style.width, height: b.style.height, rotate: b.dataset.rotate || 0,
                    shape: b.dataset.shape, color: b.dataset.color, colorA: b.dataset.colorA, image: b.dataset.image, imageH: b.dataset.imageH, imageS: b.dataset.imageS, useImgHover: b.dataset.useImgHover, useImgSelect: b.dataset.useImgSelect, text: b.dataset.text,
                    fontFamily: b.dataset.fontFamily, fontSize: b.dataset.fontSize, fontColor: b.dataset.fontColor, fontColorA: b.dataset.fontColorA, fontWeight: b.dataset.fontWeight, fontStyle: b.dataset.fontStyle, alignH: b.dataset.alignH, alignV: b.dataset.alignV,
                    borderW: b.dataset.borderW, borderS: b.dataset.borderS, borderC: b.dataset.borderC, borderA: b.dataset.borderA, radius: b.dataset.radius, tooltip: b.dataset.tooltip, tooltipBg: b.dataset.tooltipBg, tooltipColor: b.dataset.tooltipColor, elemGap: b.dataset.elemGap,
                    trackC: b.dataset.trackC, trackA: b.dataset.trackA, trackW: b.dataset.trackW, thumbC: b.dataset.thumbC, thumbA: b.dataset.thumbA, spinBgC: b.dataset.spinBgC, spinBgA: b.dataset.spinBgA, spinFontC: b.dataset.spinFontC, spinFontA: b.dataset.spinFontA, spinW: b.dataset.spinW,
                    actionType: b.dataset.actionType || "node", scriptCode: b.dataset.scriptCode || "", scriptOn: b.dataset.scriptOn || "", scriptOff: b.dataset.scriptOff || "", toggleState: b.dataset.toggleState || "false",
                    timelineAction: b.dataset.timelineAction || "play", cameraAction: b.dataset.cameraAction || "FRONT", cameraObj: b.dataset.cameraObj || "",
                    stateObj: b.dataset.stateObj || "", statePath: b.dataset.statePath || "", stateOnValue: b.dataset.stateOnValue || "",
                    targets: safeJsonArray(b.dataset.targets),
                    armature: b.dataset.armature || "", bones: safeJsonArray(b.dataset.bones), collections: safeJsonArray(b.dataset.collections), includeChildren: b.dataset.includeChildren !== 'false', collectionVisAction: b.dataset.collectionVisAction || "toggle",
                    meshObject: b.dataset.meshObject || "", meshElemMode: b.dataset.meshElemMode || "VERT", meshIndices: safeJsonArray(b.dataset.meshIndices),
                    targetType: b.dataset.targetType || "shapekey", targetObj: b.dataset.targetObj || "", targetKey: b.dataset.targetKey || "", dataPath: b.dataset.dataPath || "",
                    min: numOr(b.dataset.min, 0), max: numOr(b.dataset.max, 1), sliderMode: b.dataset.sliderMode || "both",
                    locked: b.dataset.locked === 'true'
                });
            }); p.elems = elems;
        }

        function switchTab(idx, skipHistory=false) {
            if(currentPageIndex !== -1 && !skipHistory) saveCurrentPageData();
            currentPageIndex = idx; const p = pages[idx];
            bgData = { ...p.background }; document.getElementById('bg-color').value = bgData.color || "#2b2b2b"; updateBgView();
            let cw = p.canvasW || 500; let ch = p.canvasH || 500;
            document.getElementById('canvas-w').value = cw; document.getElementById('canvas-h').value = ch; updateCanvasSize();

            document.querySelectorAll('.selector-btn').forEach(b => { if(b.id !== 'bg-layer') b.remove(); });
            if(p.elems) p.elems.forEach(eData => addElem(eData.type, eData, false)); else if(p.buttons) p.buttons.forEach(bData => addElem('button', bData, false));
            clearSelection(); renderTabs(); updateWatchShapekeys(); applyCachedBlenderState();

            if(!isEditMode) {
                if(pages.length <= 1) { tabBar.style.display = 'none'; viewport.classList.add('play-mode-canvas-notab'); } else { tabBar.style.display = 'flex'; viewport.classList.remove('play-mode-canvas-notab'); }
            }
            resetCanvasViewAndResize(cw, ch);
        }

        function updateCanvasSize() {
            let cw = parseFloat(document.getElementById('canvas-w').value) || 500; let ch = parseFloat(document.getElementById('canvas-h').value) || 500;
            workspace.style.width = cw + 'px'; workspace.style.height = ch + 'px';
            bgLayer.style.width = cw + 'px'; bgLayer.style.height = ch + 'px';
            applyTransform(); queueHistory();
        }

        function clearSelection() {
            activeEditBtns = []; document.querySelectorAll('.selector-btn').forEach(b => b.classList.remove('selected'));
            document.getElementById('bg-layer').classList.remove('selected');
            document.getElementById('btn-settings').style.display = "none"; document.getElementById('slider-settings').style.display = "none"; document.getElementById('text-settings').style.display = "none"; document.getElementById('common-settings').style.display = "none";
            document.getElementById('no-btn-selected').style.display = "block"; document.getElementById('multi-select-warn').style.display = "none";
        }


        const WATCH_MAX_DATAPATHS = 256; const WATCH_MAX_BONE_ARMATURES = 32;
        function updateWatchShapekeys() {
            // Collect the Blender values this page shows (shapekey sliders, datapath sliders,
            // state-driven toggles, bone button armatures) and register them with Blender (bounded).
            const watch = {}; const dps = []; const dpSeen = new Set(); const arms = [];
            const addDp = (o, p) => {
                o = String(o || '').trim(); p = String(p || '').trim();
                if(!o || !isSafeDataPath(p) || dps.length >= WATCH_MAX_DATAPATHS) return;
                const k = JSON.stringify([o, p]); if(dpSeen.has(k)) return;
                dpSeen.add(k); dps.push({ obj: o, path: p });
            };
            document.querySelectorAll('.selector-btn[data-type="slider"]').forEach(slider => {
                const tType = slider.dataset.targetType || 'shapekey';
                if(tType === 'datapath') { addDp(slider.dataset.targetObj, slider.dataset.dataPath); return; }
                if(tType !== 'shapekey') return;
                const obj = slider.dataset.targetObj || '';
                const key = slider.dataset.targetKey || '';
                if(!obj || !key) return;
                if(!watch[obj]) watch[obj] = [];
                if(!watch[obj].includes(key)) watch[obj].push(key);
            });
            document.querySelectorAll('.selector-btn[data-type="button"]').forEach(btn => {
                const act = btn.dataset.actionType || 'node';
                if(act === 'toggle' && btn.dataset.statePath) addDp(btn.dataset.stateObj, btn.dataset.statePath);
                else if(act === 'bone_select') { const a = String(btn.dataset.armature || ''); if(a && !arms.includes(a) && arms.length < WATCH_MAX_BONE_ARMATURES) arms.push(a); }
            });
            apiFetch('/api/watch', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ shapekeys: watch, datapaths: dps, bone_armatures: arms }) })
                .then(r => { if(!r.ok) console.warn('[SmartSelector] /api/watch failed: HTTP ' + r.status); })
                .catch(err => console.warn('[SmartSelector] /api/watch failed', err));
        }
        let _lastStateRev = -1; let _statePollFailing = false;
        setInterval(() => {
            apiFetch('/api/state?since=' + _lastStateRev).then(r => r.json()).then(data => {
                _statePollFailing = false;
                const rev = (data && data.rev !== undefined) ? data.rev : -1;
                if(rev === _lastStateRev) return;
                _lastStateRev = rev;

                const sel = data.selected || [];
                if(data.shapekeys) {
                    document.querySelectorAll('.selector-btn[data-type="slider"]').forEach(slider => {
                        const tType = slider.dataset.targetType || 'shapekey';
                        if (tType === 'shapekey') {
                            const tObj = slider.dataset.targetObj; const tKey = slider.dataset.targetKey;
                            if(tObj && tKey && data.shapekeys[tObj] && data.shapekeys[tObj][tKey] !== undefined) {
                                let rng = slider.querySelector('.slider-input-range'); let num = slider.querySelector('.slider-input-num'); let val = data.shapekeys[tObj][tKey];
                                if(document.activeElement !== rng && document.activeElement !== num) { if(rng) rng.value = val; if(num) num.value = val; }
                            }
                        }
                    });
                }
                if(data.datapaths && typeof data.datapaths === 'object' && !Array.isArray(data.datapaths)) _lastDatapaths = data.datapaths;
                if(data.selected_bones && typeof data.selected_bones === 'object' && !Array.isArray(data.selected_bones)) _lastSelectedBones = data.selected_bones;
                if(Array.isArray(data.script_results)) handleScriptResults(data.script_results);
                applyCachedBlenderState();
                if (isSelecting || dragObjsData.length > 0 || isResizing || isPanning || isResizingPanel) return;
                document.querySelectorAll('.selector-btn[data-type="button"]').forEach(btn => {
                    const act = btn.dataset.actionType || 'node';
                    if (act !== 'node') return;
                    const targets = safeJsonArray(btn.dataset.targets);
                    if (targets.length === 0) { if (!isEditMode) btn.classList.remove('selected'); return; }
                    const allSelected = targets.every(t => sel.includes(t));
                    if (allSelected) { if(!isEditMode || !activeEditBtns.includes(btn)) btn.classList.add('selected'); }
                    else { if(!isEditMode || !activeEditBtns.includes(btn)) btn.classList.remove('selected'); }
                });
            }).catch(err => {
                // Warn once per outage; the poll keeps retrying on its existing 500 ms interval.
                if(!_statePollFailing) console.warn('[SmartSelector] /api/state poll failed', err);
                _statePollFailing = true;
            });
        }, 500);

        function toggleMode() {
            const willBeEdit = document.getElementById('mode-select').value === 'edit';
            if (isEditMode === willBeEdit) return; isEditMode = willBeEdit;
            if(!isEditMode) {
                document.body.classList.remove('edit-mode'); document.getElementById('toolbar').style.display = 'none';
                if(pages.length <= 1) { tabBar.style.display = 'none'; viewport.classList.add('play-mode-canvas-notab'); } else { tabBar.style.display = 'flex'; tabBar.classList.add('play-mode-tab'); viewport.classList.remove('play-mode-canvas-notab'); }
                propsPanel.classList.add('properties-fullscreen'); viewport.classList.add('play-mode-canvas'); clearSelection(); renderTabs(); updateWatchShapekeys();

                resetCanvasViewAndResize();

                applyCachedBlenderState(); // toggles: real Blender state when statePath is set, else toggleState
            } else {
                document.body.classList.add('edit-mode'); document.getElementById('toolbar').style.display = 'flex';
                tabBar.style.display = 'flex'; tabBar.classList.remove('play-mode-tab'); viewport.classList.remove('play-mode-canvas-notab');
                propsPanel.classList.remove('properties-fullscreen'); viewport.classList.remove('play-mode-canvas'); renderTabs();
                try { window.resizeBy(pageSettings.panelWidth || 380, 44); } catch(e){}
            }
        }

        function updateGrid() {
            const show = document.getElementById('grid-toggle').checked; const size = parseInt(document.getElementById('grid-size').value) || 20;
            if(show) { gridLayer.style.display = 'block'; gridLayer.style.backgroundSize = `${size}px ${size}px`; gridLayer.style.backgroundImage = `linear-gradient(to right, rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.08) 1px, transparent 1px)`; }
            else { gridLayer.style.display = 'none'; }
        }

        let bgData = {};
        function updateBg() { bgData.color = document.getElementById('bg-color').value; updateBgView(); queueHistory(); }
        function updateBgView() {
            workspace.style.backgroundColor = bgData.color || "#2b2b2b";
        }
        function uploadImage(inputElem, type, state='normal') {
            const file = inputElem.files[0]; if(!file) return; const reader = new FileReader();
            reader.onload = function(e) {
                const b64 = e.target.result; const img = new Image();
                img.onload = () => {
                    const ratio = img.naturalWidth / img.naturalHeight;
                    if(type === 'elem' && activeEditBtns.length === 1 && state === 'normal') {
                        let w = parseFloat(document.getElementById(`elem-width`).value) || 40; let h = w / ratio;
                        document.getElementById(`elem-width`).value = w.toFixed(1); document.getElementById(`elem-height`).value = h.toFixed(1);
                        document.getElementById('elem-lock').checked = true; updateElemSize('lock'); activeEditBtns[0].style.width = w + 'px'; activeEditBtns[0].style.height = h + 'px';
                    }
                    setStatusMsg("msg_save");
                    apiFetch(`/api/upload_image?project=${encodeURIComponent(projectName)}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ filename: file.name, data: b64 }) })
                    .then(r => r.json()).then(data => {
                        if(type === 'elem' && activeEditBtns.length === 1) {
                            if(state === 'normal') activeEditBtns[0].dataset.image = data.url;
                            else if(state === 'hover') activeEditBtns[0].dataset.imageH = data.url;
                            else if(state === 'select') activeEditBtns[0].dataset.imageS = data.url;
                            updateElemView(activeEditBtns[0]); pushHistory();
                        }
                        setStatusMsg("msg_load"); inputElem.value = "";
                    });
                }; img.src = b64;
            }; reader.readAsDataURL(file);
        }
        function clearSingleImage(state) {
            if(activeEditBtns.length !== 1) return;
            const elem = activeEditBtns[0];
            if(state === 'normal') { deleteImageOnServer(elem.dataset.image); elem.dataset.image = ""; }
            else if(state === 'hover') { deleteImageOnServer(elem.dataset.imageH); elem.dataset.imageH = ""; }
            else if(state === 'select') { deleteImageOnServer(elem.dataset.imageS); elem.dataset.imageS = ""; }
            updateElemView(elem); pushHistory();
        }
        function deleteImageOnServer(url) { if(!url) return; apiFetch(`/api/delete_image?project=${encodeURIComponent(projectName)}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ url: url }) }); }

        function generateShapeSVG(w, h, shape, bgC, bgA, bdC, bdA, bdW, radius, imgUrl) {
            const bgColor = hexToRgba(bgC, bgA); const bdColor = hexToRgba(bdC, bdA);
            let defs = ''; let fillAttr = bgColor;
            if (imgUrl && shape !== 'text') {
                const patternId = 'img-' + Math.random().toString(36).substr(2, 9);
                defs = `<defs><pattern id="${patternId}" patternUnits="userSpaceOnUse" width="${w}" height="${h}"><image href="${imgUrl}" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="none" /></pattern></defs>`;
            }
            const strokeAttr = bdW > 0 ? `stroke="${bdColor}" stroke-width="${bdW}"` : `stroke="none"`;
            const halfBd = bdW / 2; const innerW = Math.max(0.1, w - bdW); const innerH = Math.max(0.1, h - bdW);
            let path = ''; let bgPath = '';
            if (shape === 'circle') {
                const cx = w/2, cy = h/2, rx = innerW/2, ry = innerH/2;
                bgPath = `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${bgColor}" />`;
                path = `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${imgUrl ? `url(#${defs.match(/id="([^"]+)"/)?.[1]})` : 'none'}" ${strokeAttr} />`;
            } else if (shape === 'square') {
                let rx = radius, ry = radius;
                bgPath = `<rect x="${halfBd}" y="${halfBd}" width="${innerW}" height="${innerH}" rx="${rx}" ry="${ry}" fill="${bgColor}" />`;
                path = `<rect x="${halfBd}" y="${halfBd}" width="${innerW}" height="${innerH}" rx="${rx}" ry="${ry}" fill="${imgUrl ? `url(#${defs.match(/id="([^"]+)"/)?.[1]})` : fillAttr}" ${strokeAttr} />`;
            } else if (shape === 'triangle') {
                const pts = `${w/2},${halfBd} ${w-halfBd},${h-halfBd} ${halfBd},${h-halfBd}`;
                bgPath = `<polygon points="${pts}" fill="${bgColor}" />`; path = `<polygon points="${pts}" fill="${imgUrl ? `url(#${defs.match(/id="([^"]+)"/)?.[1]})` : 'none'}" ${strokeAttr} stroke-linejoin="round" />`;
            } else if (shape === 'star') {
                const cx = w/2, cy = h/2; const R = Math.min(innerW, innerH)/2; const r = R * 0.4; let pts = '';
                for(let i=0; i<10; i++) { const angle = i * Math.PI / 5 - Math.PI / 2; const rad = i % 2 === 0 ? R : r; pts += `${cx + rad * Math.cos(angle)},${cy + rad * Math.sin(angle)} `; }
                bgPath = `<polygon points="${pts.trim()}" fill="${bgColor}" />`; path = `<polygon points="${pts.trim()}" fill="${imgUrl ? `url(#${defs.match(/id="([^"]+)"/)?.[1]})` : 'none'}" ${strokeAttr} stroke-linejoin="round" />`;
            }
            return `<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="position:absolute; top:0; left:0; overflow:visible; pointer-events:none;">${defs}${shape !== 'text' ? bgPath : ''}${shape !== 'text' ? path : ''}</svg>`;
        }

        let elemCounter = 1; let elemRatio = 1.0;
        function addElem(type, data = null, triggerHistory = false) {
            const elem = document.createElement('div'); elem.className = 'selector-btn';
            // Undo時に同じIDを維持するため、dataがあればそれを使う
            elem.id = (data && data.id) ? data.id : "elem_" + Date.now() + "_" + Math.floor(Math.random()*10000);
            elem.dataset.type = type;
            if(data) {
                elem.dataset.itemName = data.itemName || `Item_${elemCounter++}`;
                elem.style.left = data.x || '50px'; elem.style.top = data.y || '50px'; elem.style.zIndex = data.z || 10; elem.style.width = data.width || (type==='slider' ? "200px" : "80px"); elem.style.height = data.height || (type==='slider' ? "60px" : "40px");
                elem.dataset.rotate = data.rotate || 0; elem.dataset.shape = data.shape || "square"; elem.dataset.color = data.color || "#3498db"; elem.dataset.colorA = data.colorA !== undefined ? data.colorA : 100;
                elem.dataset.image = data.image || ""; elem.dataset.imageH = data.imageH || ""; elem.dataset.imageS = data.imageS || ""; elem.dataset.useImgHover = data.useImgHover || "false"; elem.dataset.useImgSelect = data.useImgSelect || "false";
                elem.dataset.text = data.text !== undefined ? data.text : "Label"; elem.dataset.locked = data.locked ? 'true' : 'false';
                elem.dataset.fontFamily = data.fontFamily || "'Segoe UI', Tahoma, sans-serif"; elem.dataset.fontSize = data.fontSize || 16; elem.dataset.fontColor = data.fontColor || "#ffffff"; elem.dataset.fontColorA = data.fontColorA !== undefined ? data.fontColorA : 100; elem.dataset.fontWeight = data.fontWeight || "false"; elem.dataset.fontStyle = data.fontStyle || "false"; elem.dataset.alignH = data.alignH || "center"; elem.dataset.alignV = data.alignV || "center"; elem.dataset.elemGap = data.elemGap !== undefined ? data.elemGap : 0;
                elem.dataset.borderC = data.borderC || "#2980b9"; elem.dataset.borderA = data.borderA !== undefined ? data.borderA : 100; elem.dataset.borderW = data.borderW !== undefined ? data.borderW : 2; elem.dataset.borderS = data.borderS || "solid"; elem.dataset.radius = data.radius !== undefined ? data.radius : 6; elem.dataset.tooltip = data.tooltip || ""; elem.dataset.tooltipBg = data.tooltipBg || "#ffffff"; elem.dataset.tooltipColor = data.tooltipColor || "#000000";
                elem.dataset.trackC = data.trackC || "#2980b9"; elem.dataset.trackA = data.trackA !== undefined ? data.trackA : 100; elem.dataset.trackW = data.trackW !== undefined ? data.trackW : 120; elem.dataset.thumbC = data.thumbC || "#ffffff"; elem.dataset.thumbA = data.thumbA !== undefined ? data.thumbA : 100; elem.dataset.spinBgC = data.spinBgC || "#1e1e1e"; elem.dataset.spinBgA = data.spinBgA !== undefined ? data.spinBgA : 100; elem.dataset.spinFontC = data.spinFontC || "#ffffff"; elem.dataset.spinFontA = data.spinFontA !== undefined ? data.spinFontA : 100;
                if(type === 'button') {
                    elem.dataset.actionType = data.actionType || "node"; elem.dataset.scriptCode = data.scriptCode || ""; elem.dataset.scriptOn = data.scriptOn || ""; elem.dataset.scriptOff = data.scriptOff || ""; elem.dataset.toggleState = data.toggleState || "false"; elem.dataset.timelineAction = data.timelineAction || "play"; elem.dataset.cameraAction = data.cameraAction || "FRONT"; elem.dataset.cameraObj = data.cameraObj || ""; elem.dataset.targets = JSON.stringify(data.targets || []);
                    // Selection targets and real-state fields (all optional; old files load with these defaults).
                    elem.dataset.armature = (typeof data.armature === 'string') ? data.armature : ""; elem.dataset.bones = JSON.stringify(Array.isArray(data.bones) ? data.bones : []);
                    elem.dataset.collections = JSON.stringify(Array.isArray(data.collections) ? data.collections : []); elem.dataset.includeChildren = (data.includeChildren === false) ? 'false' : 'true';
                    elem.dataset.collectionVisAction = ['show','hide','toggle'].includes(data.collectionVisAction) ? data.collectionVisAction : 'toggle';
                    elem.dataset.meshObject = (typeof data.meshObject === 'string') ? data.meshObject : ""; elem.dataset.meshElemMode = ['VERT','EDGE','FACE'].includes(data.meshElemMode) ? data.meshElemMode : 'VERT'; elem.dataset.meshIndices = JSON.stringify(Array.isArray(data.meshIndices) ? data.meshIndices : []);
                    elem.dataset.stateObj = (typeof data.stateObj === 'string') ? data.stateObj : ""; elem.dataset.statePath = (typeof data.statePath === 'string') ? data.statePath : ""; elem.dataset.stateOnValue = (data.stateOnValue === undefined || data.stateOnValue === null) ? "" : String(data.stateOnValue);
                } else if(type === 'slider') {
                    elem.dataset.targetType = data.targetType || "shapekey"; elem.dataset.targetObj = data.targetObj || ""; elem.dataset.targetKey = data.targetKey || ""; elem.dataset.dataPath = data.dataPath || ""; elem.dataset.min = numOr(data.min, 0); elem.dataset.max = numOr(data.max, 1); elem.dataset.sliderMode = data.sliderMode || "both";
                }
            } else {
                elem.dataset.itemName = `Item_${elemCounter++}`;
                elem.style.left = '50px'; elem.style.top = '50px'; elem.style.zIndex = 10; elem.dataset.locked = 'false'; elem.dataset.rotate = 0; elem.dataset.fontFamily = "'Segoe UI', Tahoma, sans-serif"; elem.dataset.fontSize = 16; elem.dataset.fontColor = "#ffffff"; elem.dataset.fontColorA = 100; elem.dataset.fontWeight = "false"; elem.dataset.fontStyle = "false"; elem.dataset.alignH = "center"; elem.dataset.alignV = "center"; elem.dataset.borderC = "#2980b9"; elem.dataset.borderA = 100; elem.dataset.borderW = 2; elem.dataset.borderS = "solid"; elem.dataset.radius = 6; elem.dataset.tooltip = ""; elem.dataset.tooltipBg = "#ffffff"; elem.dataset.tooltipColor = "#000000"; elem.dataset.useImgHover = "false"; elem.dataset.useImgSelect = "false";
                elem.dataset.colorA = 100; elem.dataset.shape = 'square'; elem.dataset.color = '#3498db'; elem.dataset.text = 'Label'; elem.dataset.elemGap = 0;
                elem.dataset.trackC = "#2980b9"; elem.dataset.trackA = 100; elem.dataset.trackW = 120; elem.dataset.thumbC = "#ffffff"; elem.dataset.thumbA = 100; elem.dataset.spinBgC = "#1e1e1e"; elem.dataset.spinBgA = 100; elem.dataset.spinW = 50; elem.dataset.spinFontC = "#ffffff"; elem.dataset.spinFontA = 100;
                if(type === 'button') {
                    elem.style.width = '80px'; elem.style.height = '40px';
                    elem.dataset.image = ''; elem.dataset.imageH = ''; elem.dataset.imageS = ''; elem.dataset.actionType = "node"; elem.dataset.scriptCode = ""; elem.dataset.scriptOn = ""; elem.dataset.scriptOff = ""; elem.dataset.toggleState = "false"; elem.dataset.timelineAction = "play"; elem.dataset.cameraAction = "FRONT"; elem.dataset.cameraObj = ""; elem.dataset.targets = "[]";
                    elem.dataset.armature = ""; elem.dataset.bones = "[]"; elem.dataset.collections = "[]"; elem.dataset.includeChildren = 'true'; elem.dataset.collectionVisAction = 'toggle';
                    elem.dataset.meshObject = ""; elem.dataset.meshElemMode = 'VERT'; elem.dataset.meshIndices = "[]"; elem.dataset.stateObj = ""; elem.dataset.statePath = ""; elem.dataset.stateOnValue = "";
                } else if(type === 'slider') {
                    elem.style.width = '200px'; elem.style.height = '60px'; elem.dataset.image = ''; elem.dataset.targetType = "shapekey"; elem.dataset.targetObj = ""; elem.dataset.targetKey = ""; elem.dataset.dataPath = ""; elem.dataset.min = 0; elem.dataset.max = 1; elem.dataset.sliderMode = "both";
                }
            }
            const handle = document.createElement('div'); handle.className = 'resize-handle'; handle.onmousedown = (e) => onResizeMouseDown(e, elem); elem.appendChild(handle);
            const tooltip = document.createElement('div'); tooltip.className = 'custom-tooltip'; elem.appendChild(tooltip);
            updateElemView(elem); elem.onmousedown = (e) => onElemMouseDown(e, elem); elem.oncontextmenu = (e) => onElemContextMenu(e, elem); workspace.appendChild(elem);
            if(triggerHistory) pushHistory();
            return elem;
        }

        function updateElemView(elem) {
            const type = elem.dataset.type; const shape = elem.dataset.shape || "circle"; const color = elem.dataset.color || "#3498db"; const colorA = elem.dataset.colorA !== undefined ? elem.dataset.colorA : 100;
            const text = elem.dataset.text || ""; const locked = elem.dataset.locked === 'true';

            let imgUrl = elem.dataset.image || "";
            if(elem.dataset.useImgHover === 'true' && elem.matches(':hover') && elem.dataset.imageH) imgUrl = elem.dataset.imageH;
            if(elem.dataset.useImgSelect === 'true' && elem.classList.contains('selected') && elem.dataset.imageS) imgUrl = elem.dataset.imageS;

            elem.style.transform = `rotate(${elem.dataset.rotate || 0}deg)`;
            elem.dataset.shape = shape; elem.dataset.actionType = elem.dataset.actionType || "node";

            // Edit Mode only: in Select Mode 'selected' is owned by Blender state / toggle state (activeEditBtns is always empty there).
            if(isEditMode) { if(activeEditBtns.includes(elem)) elem.classList.add('selected'); else elem.classList.remove('selected'); }
            if(isEditMode && locked) elem.classList.add('locked-elem'); else elem.classList.remove('locked-elem');

            let tt = elem.querySelector('.custom-tooltip');
            if(tt) { if(elem.dataset.tooltip) { tt.innerText = elem.dataset.tooltip; tt.classList.remove('empty-tip'); } else { tt.innerText = ""; tt.classList.add('empty-tip'); } tt.style.setProperty('--tooltip-bg', elem.dataset.tooltipBg || '#ffffff'); tt.style.setProperty('--tooltip-color', elem.dataset.tooltipColor || '#000000'); }

            let inner = elem.querySelector('.btn-inner');
            if(!inner) { inner = document.createElement('div'); elem.insertBefore(inner, elem.firstChild); }
            inner.innerHTML = '';

            elem.style.setProperty('--track-color', hexToRgba(elem.dataset.trackC || '#2980b9', elem.dataset.trackA !== undefined ? elem.dataset.trackA : 100));
            elem.style.setProperty('--thumb-color', hexToRgba(elem.dataset.thumbC || '#ffffff', elem.dataset.thumbA !== undefined ? elem.dataset.thumbA : 100));
            elem.style.setProperty('--spin-bg', hexToRgba(elem.dataset.spinBgC || '#1e1e1e', elem.dataset.spinBgA !== undefined ? elem.dataset.spinBgA : 100));
            elem.style.setProperty('--spin-font', hexToRgba(elem.dataset.spinFontC || '#ffffff', elem.dataset.spinFontA !== undefined ? elem.dataset.spinFontA : 100));
            elem.style.setProperty('--bg-img-url', imgUrl ? `url('${imgUrl}')` : 'none');

            if(type === 'slider') {
                let lSpan = document.createElement('div'); lSpan.className = 'slider-label'; let cDiv = document.createElement('div'); cDiv.className = 'slider-controls';
                let rng = document.createElement('input'); rng.type = 'range'; rng.className = 'slider-input-range'; rng.step = '0.001';
                let num = document.createElement('input'); num.type = 'number'; num.className = 'slider-input-num'; num.step = '0.01';
                const beginUndoGesture = () => {
                    if((elem.dataset.targetType || 'shapekey') === 'datapath' && !elem._undoGestureId) elem._undoGestureId = newRequestId();
                };
                const finishUndoGesture = (control) => {
                    if((elem.dataset.targetType || 'shapekey') === 'datapath' && elem._undoGestureId) {
                        onSliderInput({ target: control }, elem, true);
                        elem._undoGestureId = '';
                    }
                    reapplyReadback();
                };
                rng.oninput = (e) => { beginUndoGesture(); num.value = e.target.value; onSliderInput(e, elem, false); };
                num.oninput = (e) => { beginUndoGesture(); rng.value = e.target.value; onSliderInput(e, elem, false); };
                // A readback that arrived while dragging / typing was skipped; show it once the control is released.
                const reapplyReadback = () => { if(elem._dpReadbackSkipped) setTimeout(applyDatapathSliders, 0); };
                rng.onfocus = beginUndoGesture; num.onfocus = beginUndoGesture;
                rng.onchange = () => finishUndoGesture(rng); num.onchange = () => finishUndoGesture(num); num.onblur = () => finishUndoGesture(num);
                rng.onpointercancel = () => finishUndoGesture(rng);
                rng.onmousedown = (e) => { if(!isEditMode) e.stopPropagation(); }; num.onmousedown = (e) => { if(!isEditMode) e.stopPropagation(); };
                cDiv.appendChild(rng); cDiv.appendChild(num); inner.appendChild(lSpan); inner.appendChild(cDiv);
            } else { let tSpan = document.createElement('div'); tSpan.className = 'btn-text'; inner.appendChild(tSpan); }

            inner.className = type === 'slider' ? 'btn-inner slider-container' : 'btn-inner';

            let txtEl = inner.querySelector('.btn-text') || inner.querySelector('.slider-label');
            if(txtEl) {
                txtEl.style.fontFamily = elem.dataset.fontFamily; txtEl.style.fontWeight = (elem.dataset.fontWeight === 'true') ? 'bold' : 'normal'; txtEl.style.fontStyle = (elem.dataset.fontStyle === 'true') ? 'italic' : 'normal'; txtEl.style.fontSize = (elem.dataset.fontSize || 16) + 'px';
                txtEl.style.color = hexToRgba(elem.dataset.fontColor || '#ffffff', elem.dataset.fontColorA !== undefined ? elem.dataset.fontColorA : 100);

                if(type === 'slider') {
                    const alignMap = {'flex-start':'left', 'center':'center', 'flex-end':'right'};
                    txtEl.style.textAlign = alignMap[elem.dataset.alignH || 'center'];
                    inner.style.flexDirection = (elem.dataset.alignV === 'flex-end') ? 'column-reverse' : 'column';
                    inner.style.justifyContent = 'space-evenly';
                    inner.style.alignItems = 'center';
                    inner.style.gap = (elem.dataset.elemGap !== undefined ? elem.dataset.elemGap : 0) + 'px';
                } else {
                    inner.style.justifyContent = elem.dataset.alignV || 'center';
                    inner.style.alignItems = elem.dataset.alignH || 'center';
                    txtEl.style.textAlign = (elem.dataset.alignH === 'flex-start') ? 'left' : (elem.dataset.alignH === 'flex-end' ? 'right' : 'center');
                }
            }

            let rngEl = inner.querySelector('.slider-input-range'); let numEl = inner.querySelector('.slider-input-num');
            if(rngEl && numEl) {
                let tW = elem.dataset.trackW !== undefined ? elem.dataset.trackW : 120; let sW = elem.dataset.spinW !== undefined ? elem.dataset.spinW : 50;
                rngEl.style.flex = `0 0 ${tW}px`; rngEl.style.width = `${tW}px`; numEl.style.flex = `0 0 ${sW}px`; numEl.style.width = `${sW}px`;
            }

            const bdC = elem.dataset.borderC || "#2980b9"; const bdA = elem.dataset.borderA !== undefined ? elem.dataset.borderA : 100;
            const bdW = parseFloat(elem.dataset.borderW) || 0; const rad = parseFloat(elem.dataset.radius) || 0;

            let w = parseFloat(elem.style.width); let h = parseFloat(elem.style.height);
            let svgHtml = generateShapeSVG(w, h, shape, color, colorA, bdC, bdA, bdW, rad, imgUrl);

            if(type === 'slider') {
                inner.insertAdjacentHTML('afterbegin', svgHtml);
                inner.querySelector('.slider-label').innerText = text;
                rngEl.min = numOr(elem.dataset.min, 0); rngEl.max = numOr(elem.dataset.max, 1); numEl.min = numOr(elem.dataset.min, 0); numEl.max = numOr(elem.dataset.max, 1);
                const mode = elem.dataset.sliderMode || "both"; rngEl.style.display = (mode === 'both' || mode === 'slider') ? 'block' : 'none'; numEl.style.display = (mode === 'both' || mode === 'spinner') ? 'block' : 'none';
            } else {
                if(shape === 'text') { inner.querySelector('.btn-text').innerText = text; }
                else { inner.insertAdjacentHTML('afterbegin', svgHtml); inner.querySelector('.btn-text').innerText = text; }
            }
        }

        function onResizeMouseDown(e, elem) {
            if(!isEditMode || (elem.dataset && elem.dataset.locked === 'true')) return;
            e.stopPropagation(); e.preventDefault(); isResizing = true; resizeElem = elem;
            const pos = getWorkspacePos(e.clientX, e.clientY); startX = pos.x; startY = pos.y;
            resizeElem.dataset.startW = parseFloat(elem.style.width); resizeElem.dataset.startH = parseFloat(elem.style.height);
        }

        function updateElemPos() {
            if(activeEditBtns.length !== 1) return; const elem = activeEditBtns[0];
            elem.style.left = document.getElementById('elem-x').value + 'px'; elem.style.top = document.getElementById('elem-y').value + 'px'; elem.style.zIndex = document.getElementById('elem-z').value; updateElemView(elem); queueHistory();
        }

        function updateElemSize(changed) {
            if(activeEditBtns.length < 1) return;
            const elem = activeEditBtns[0]; const isSlider = elem.dataset.type === 'slider';
            // Apply the same size to all selected elements

            let w = parseFloat(document.getElementById(`elem-width`).value) || 40; let h = parseFloat(document.getElementById(`elem-height`).value) || 40;
            const isLock = document.getElementById('elem-lock').checked; const shape = isSlider ? 'square' : document.getElementById('btn-shape').value;
            if(shape === 'circle') { if(changed === 'w') h = w; else if(changed === 'h') w = h; document.getElementById(`elem-height`).value = h; document.getElementById(`elem-width`).value = w; }
            else { if(changed === 'lock') { elemRatio = w / h; return; } if (isLock) { if (changed === 'w') h = w / elemRatio; else w = h * elemRatio; document.getElementById(`elem-height`).value = h.toFixed(1); document.getElementById(`elem-width`).value = w.toFixed(1); } else { elemRatio = w / h; } }
            activeEditBtns.forEach(el=>{ el.style.width = w + 'px'; el.style.height = h + 'px'; updateElemView(el); }); queueHistory();
        }

        function updateElem() {
            if(activeEditBtns.length < 1) return;
            const single = (activeEditBtns.length === 1);
            const elem = activeEditBtns[0];
            if(single) { elem.dataset.itemName = document.getElementById('elem-name').value; }
            // Common properties apply to all selected
            const rot = document.getElementById('elem-rotate').value;
            const tip = document.getElementById('elem-tooltip').value;
            const tipBg = document.getElementById('elem-tooltip-bg').value;
            const tipCol = document.getElementById('elem-tooltip-color').value;
            activeEditBtns.forEach(el=>{ el.dataset.rotate = rot; el.dataset.tooltip = tip; el.dataset.tooltipBg = tipBg; el.dataset.tooltipColor = tipCol; });
            if(!single){ activeEditBtns.forEach(updateElemView); queueHistory(); return; }
            // (batch) rotate/tooltip handled above;
            if(elem.dataset.type === 'slider') {
                elem.dataset.sliderMode = document.getElementById('slider-mode').value; elem.dataset.text = document.getElementById('elem-text').value; elem.dataset.color = document.getElementById('slider-color').value; elem.dataset.colorA = document.getElementById('slider-color-a').value; elem.dataset.min = document.getElementById('slider-min').value; elem.dataset.max = document.getElementById('slider-max').value;
                elem.dataset.fontFamily = document.getElementById('elem-font').value; elem.dataset.fontSize = document.getElementById('elem-font-size').value; elem.dataset.fontColor = document.getElementById('elem-font-color').value; elem.dataset.fontColorA = document.getElementById('elem-font-color-a').value; elem.dataset.fontWeight = document.getElementById('elem-bold').checked ? "true" : "false"; elem.dataset.fontStyle = document.getElementById('elem-italic').checked ? "true" : "false"; elem.dataset.alignH = document.getElementById('elem-align-h').value; elem.dataset.alignV = document.getElementById('elem-align-v').value; elem.dataset.elemGap = document.getElementById('elem-gap').value;
                elem.dataset.trackC = document.getElementById('slider-track-color').value; elem.dataset.trackA = document.getElementById('slider-track-a').value; elem.dataset.trackW = document.getElementById('slider-track-w').value; elem.dataset.thumbC = document.getElementById('slider-thumb-color').value; elem.dataset.thumbA = document.getElementById('slider-thumb-a').value; elem.dataset.spinBgC = document.getElementById('slider-spin-bg').value; elem.dataset.spinBgA = document.getElementById('slider-spin-bg-a').value; elem.dataset.spinFontC = document.getElementById('slider-spin-font-c').value; elem.dataset.spinFontA = document.getElementById('slider-spin-font-a').value; elem.dataset.spinW = document.getElementById('slider-spin-w').value;
            } else {
                const newShape = document.getElementById('btn-shape').value;
                if(newShape === 'circle' && elem.dataset.shape !== 'circle') { let w = parseFloat(document.getElementById('elem-width').value) || 40; document.getElementById('elem-height').value = w; elem.style.height = w + 'px'; }
                elem.dataset.shape = newShape; elem.dataset.text = document.getElementById('elem-text').value; elem.dataset.color = document.getElementById('btn-color').value; elem.dataset.colorA = document.getElementById('btn-color-a').value;
                elem.dataset.fontFamily = document.getElementById('elem-font').value; elem.dataset.fontSize = document.getElementById('elem-font-size').value; elem.dataset.fontColor = document.getElementById('elem-font-color').value; elem.dataset.fontColorA = document.getElementById('elem-font-color-a').value; elem.dataset.fontWeight = document.getElementById('elem-bold').checked ? "true" : "false"; elem.dataset.fontStyle = document.getElementById('elem-italic').checked ? "true" : "false"; elem.dataset.alignH = document.getElementById('elem-align-h').value; elem.dataset.alignV = document.getElementById('elem-align-v').value;
                elem.dataset.borderC = document.getElementById('btn-border-c').value; elem.dataset.borderA = document.getElementById('btn-border-a').value; elem.dataset.borderW = document.getElementById('btn-border-w').value; elem.dataset.borderS = document.getElementById('btn-border-s').value; elem.dataset.radius = document.getElementById('btn-radius').value;
                elem.dataset.useImgHover = document.getElementById('use-img-hover').checked; elem.dataset.useImgSelect = document.getElementById('use-img-select').checked;
                document.getElementById('radius-row').style.display = (newShape === 'square') ? 'flex' : 'none';
            }
            updateElemView(elem); queueHistory();
        }

        function reflectSelectionUI() {
            if(activeEditBtns.length === 0) { clearSelection(); }
            else if(activeEditBtns.length === 1) {
                const elem = activeEditBtns[0];
                document.getElementById('bg-layer').classList.remove('selected');
                document.getElementById('no-btn-selected').style.display = "none"; document.getElementById('multi-select-warn').style.display = "none";
                document.getElementById('common-settings').style.display = "block"; document.getElementById('elem-name').disabled = false; document.getElementById('elem-name').value = elem.dataset.itemName || "";
                document.getElementById('elem-x').value = parseFloat(elem.style.left).toFixed(1); document.getElementById('elem-y').value = parseFloat(elem.style.top).toFixed(1); document.getElementById('elem-z').value = elem.style.zIndex || 10; document.getElementById('elem-rotate').value = elem.dataset.rotate || 0; document.getElementById('elem-tooltip').value = elem.dataset.tooltip || ""; document.getElementById('elem-tooltip-bg').value = elem.dataset.tooltipBg || '#ffffff'; document.getElementById('elem-tooltip-color').value = elem.dataset.tooltipColor || '#000000';
                let w = parseFloat(elem.style.width) || (elem.dataset.type === 'slider' ? 200 : 80); let h = parseFloat(elem.style.height) || 60; document.getElementById('elem-width').value = w.toFixed(1); document.getElementById('elem-height').value = h.toFixed(1); elemRatio = w / h;

                if(elem.dataset.type === 'slider') {
                    document.getElementById('btn-settings').style.display = "none"; const ts = document.getElementById('text-settings'); ts.style.display = "block"; ts.style.opacity = "1"; ts.style.pointerEvents = "auto"; document.getElementById('gap-row').style.display = "flex";
                    const ss = document.getElementById('slider-settings'); ss.style.display = "block"; ss.style.opacity = "1"; ss.style.pointerEvents = "auto";
                    document.getElementById('slider-mode').value = elem.dataset.sliderMode || "both"; document.getElementById('elem-text').value = elem.dataset.text || ""; document.getElementById('slider-color').value = elem.dataset.color || "#3498db"; document.getElementById('slider-color-a').value = elem.dataset.colorA !== undefined ? elem.dataset.colorA : 100; document.getElementById('slider-min').value = numOr(elem.dataset.min, 0); document.getElementById('slider-max').value = numOr(elem.dataset.max, 1);
                    document.getElementById('elem-font').value = elem.dataset.fontFamily || "'Segoe UI', Tahoma, sans-serif"; document.getElementById('elem-font-size').value = elem.dataset.fontSize || 16; document.getElementById('elem-font-color').value = elem.dataset.fontColor || "#ffffff"; document.getElementById('elem-font-color-a').value = elem.dataset.fontColorA !== undefined ? elem.dataset.fontColorA : 100; document.getElementById('elem-bold').checked = (elem.dataset.fontWeight === 'true'); document.getElementById('elem-italic').checked = (elem.dataset.fontStyle === 'true'); document.getElementById('elem-align-h').value = elem.dataset.alignH || "center"; document.getElementById('elem-align-v').value = elem.dataset.alignV || "center"; document.getElementById('elem-gap').value = elem.dataset.elemGap !== undefined ? elem.dataset.elemGap : 0;
                    document.getElementById('slider-track-color').value = elem.dataset.trackC || "#2980b9"; document.getElementById('slider-track-a').value = elem.dataset.trackA !== undefined ? elem.dataset.trackA : 100; document.getElementById('slider-track-w').value = elem.dataset.trackW !== undefined ? elem.dataset.trackW : 120; document.getElementById('slider-thumb-color').value = elem.dataset.thumbC || "#ffffff"; document.getElementById('slider-thumb-a').value = elem.dataset.thumbA !== undefined ? elem.dataset.thumbA : 100; document.getElementById('slider-spin-bg').value = elem.dataset.spinBgC || "#1e1e1e"; document.getElementById('slider-spin-bg-a').value = elem.dataset.spinBgA !== undefined ? elem.dataset.spinBgA : 100; document.getElementById('slider-spin-font-c').value = elem.dataset.spinFontC || "#ffffff"; document.getElementById('slider-spin-font-a').value = elem.dataset.spinFontA !== undefined ? elem.dataset.spinFontA : 100; document.getElementById('slider-spin-w').value = elem.dataset.spinW !== undefined ? elem.dataset.spinW : 50;
                    document.getElementById('elem-align-v').querySelector('option[value="center"]').style.display = 'none'; if(document.getElementById('elem-align-v').value === 'center') document.getElementById('elem-align-v').value = 'flex-start';
                } else {
                    document.getElementById('slider-settings').style.display = "none"; const bs = document.getElementById('btn-settings'); bs.style.display = "block"; bs.style.opacity = "1"; bs.style.pointerEvents = "auto"; const ts = document.getElementById('text-settings'); ts.style.display = "block"; ts.style.opacity = "1"; ts.style.pointerEvents = "auto"; document.getElementById('gap-row').style.display = "none";
                    const shape = elem.dataset.shape || "circle"; document.getElementById('btn-shape').value = shape; document.getElementById('btn-color').value = elem.dataset.color || "#3498db"; document.getElementById('btn-color-a').value = elem.dataset.colorA !== undefined ? elem.dataset.colorA : 100;
                    document.getElementById('elem-text').value = elem.dataset.text || ""; document.getElementById('elem-font').value = elem.dataset.fontFamily || "'Segoe UI', Tahoma, sans-serif"; document.getElementById('elem-font-size').value = elem.dataset.fontSize || 16; document.getElementById('elem-font-color').value = elem.dataset.fontColor || "#ffffff"; document.getElementById('elem-font-color-a').value = elem.dataset.fontColorA !== undefined ? elem.dataset.fontColorA : 100; document.getElementById('elem-bold').checked = (elem.dataset.fontWeight === 'true'); document.getElementById('elem-italic').checked = (elem.dataset.fontStyle === 'true'); document.getElementById('elem-align-h').value = elem.dataset.alignH || "center"; document.getElementById('elem-align-v').value = elem.dataset.alignV || "center";
                    document.getElementById('btn-border-c').value = elem.dataset.borderC || "#2980b9"; document.getElementById('btn-border-a').value = elem.dataset.borderA !== undefined ? elem.dataset.borderA : 100; document.getElementById('btn-border-w').value = elem.dataset.borderW !== undefined ? elem.dataset.borderW : 2; document.getElementById('btn-border-s').value = elem.dataset.borderS || "solid"; document.getElementById('btn-radius').value = elem.dataset.radius !== undefined ? elem.dataset.radius : 6;
                    document.getElementById('use-img-hover').checked = elem.dataset.useImgHover === 'true'; document.getElementById('use-img-select').checked = elem.dataset.useImgSelect === 'true';
                    document.getElementById('radius-row').style.display = (shape === 'square') ? 'flex' : 'none';
                    document.getElementById('elem-align-v').querySelector('option[value="center"]').style.display = 'block';

                    updateImageClearButtons();
                }
            } else {
                // Multi-select: show common settings for batch editing
                document.getElementById('no-btn-selected').style.display = "none"; document.getElementById('multi-select-warn').style.display = "inline";
                document.getElementById('common-settings').style.display = "block";
                document.getElementById('elem-name').value = ''; document.getElementById('elem-name').disabled = true;
                document.getElementById('btn-settings').style.display = "none"; document.getElementById('slider-settings').style.display = "none"; document.getElementById('text-settings').style.display = "none"; document.getElementById('btn-settings').style.display = "block"; document.getElementById('btn-settings').style.opacity = "0.3"; document.getElementById('btn-settings').style.pointerEvents = "none"; document.getElementById('slider-settings').style.display = "none"; document.getElementById('text-settings').style.display = "none"; document.getElementById('no-btn-selected').style.display = "none"; document.getElementById('multi-select-warn').style.display = "inline";
            }
        }

        function alignElems(type) {
            if(activeEditBtns.length < 2) return; const rects = activeEditBtns.map(b => ({ btn: b, l: parseFloat(b.style.left), t: parseFloat(b.style.top), w: parseFloat(b.style.width), h: parseFloat(b.style.height) }));
            if(type === 'left') { const minX = Math.min(...rects.map(r=>r.l)); rects.forEach(r => r.btn.style.left = minX + 'px'); }
            if(type === 'center') { const minX = Math.min(...rects.map(r=>r.l)), maxX = Math.max(...rects.map(r=>r.l + r.w)); const cX = (minX + maxX) / 2; rects.forEach(r => r.btn.style.left = (cX - r.w/2) + 'px'); }
            if(type === 'right') { const maxX = Math.max(...rects.map(r=>r.l + r.w)); rects.forEach(r => r.btn.style.left = (maxX - r.w) + 'px'); }
            if(type === 'top') { const minY = Math.min(...rects.map(r=>r.t)); rects.forEach(r => r.btn.style.top = minY + 'px'); }
            if(type === 'middle') { const minY = Math.min(...rects.map(r=>r.t)), maxY = Math.max(...rects.map(r=>r.t + r.h)); const cY = (minY + maxY) / 2; rects.forEach(r => r.btn.style.top = (cY - r.h/2) + 'px'); }
            if(type === 'bottom') { const maxY = Math.max(...rects.map(r=>r.t + r.h)); rects.forEach(r => r.btn.style.top = (maxY - r.h) + 'px'); } pushHistory();
        }
        function distributeElems(type) {
            if(activeEditBtns.length < 3) return; let rects = activeEditBtns.map(b => ({ btn: b, l: parseFloat(b.style.left), t: parseFloat(b.style.top), w: parseFloat(b.style.width), h: parseFloat(b.style.height) }));
            if(type === 'h') { rects.sort((a,b) => a.l - b.l); const minX = rects[0].l, maxX = rects[rects.length-1].l; const step = (maxX - minX) / (rects.length - 1); rects.forEach((r, i) => { r.btn.style.left = (minX + step * i) + 'px'; }); }
            else if(type === 'v') { rects.sort((a,b) => a.t - b.t); const minY = rects[0].t, maxY = rects[rects.length-1].t; const step = (maxY - minY) / (rects.length - 1); rects.forEach((r, i) => { r.btn.style.top = (minY + step * i) + 'px'; }); } pushHistory();
        }
        function copyElems() {
            if(activeEditBtns.length === 0) return;
            clipboard = activeEditBtns.map(b => ({
                type: b.dataset.type, itemName: b.dataset.itemName + "_copy", width: b.style.width, height: b.style.height, shape: b.dataset.shape, color: b.dataset.color, colorA: b.dataset.colorA, image: b.dataset.image, imageH: b.dataset.imageH, imageS: b.dataset.imageS, useImgHover: b.dataset.useImgHover, useImgSelect: b.dataset.useImgSelect, text: b.dataset.text,
                fontFamily: b.dataset.fontFamily, fontSize: b.dataset.fontSize, fontColor: b.dataset.fontColor, fontColorA: b.dataset.fontColorA, fontWeight: b.dataset.fontWeight, fontStyle: b.dataset.fontStyle, alignH: b.dataset.alignH, alignV: b.dataset.alignV, borderW: b.dataset.borderW, borderS: b.dataset.borderS, borderC: b.dataset.borderC, borderA: b.dataset.borderA, radius: b.dataset.radius, tooltip: b.dataset.tooltip, tooltipBg: b.dataset.tooltipBg, tooltipColor: b.dataset.tooltipColor, rotate: b.dataset.rotate, z: b.style.zIndex, elemGap: b.dataset.elemGap,
                trackC: b.dataset.trackC, trackA: b.dataset.trackA, trackW: b.dataset.trackW, thumbC: b.dataset.thumbC, thumbA: b.dataset.thumbA, spinBgC: b.dataset.spinBgC, spinBgA: b.dataset.spinBgA, spinFontC: b.dataset.spinFontC, spinFontA: b.dataset.spinFontA, spinW: b.dataset.spinW,
                actionType: b.dataset.actionType, scriptCode: b.dataset.scriptCode, scriptOn: b.dataset.scriptOn, scriptOff: b.dataset.scriptOff, toggleState: b.dataset.toggleState, timelineAction: b.dataset.timelineAction, cameraAction: b.dataset.cameraAction, cameraObj: b.dataset.cameraObj,
                stateObj: b.dataset.stateObj || "", statePath: b.dataset.statePath || "", stateOnValue: b.dataset.stateOnValue || "",
                armature: b.dataset.armature || "", bones: safeJsonArray(b.dataset.bones), collections: safeJsonArray(b.dataset.collections), includeChildren: b.dataset.includeChildren !== 'false', collectionVisAction: b.dataset.collectionVisAction || "toggle",
                meshObject: b.dataset.meshObject || "", meshElemMode: b.dataset.meshElemMode || "VERT", meshIndices: safeJsonArray(b.dataset.meshIndices),
                targets: safeJsonArray(b.dataset.targets), targetType: b.dataset.targetType, targetObj: b.dataset.targetObj, targetKey: b.dataset.targetKey, dataPath: b.dataset.dataPath, min: numOr(b.dataset.min, 0), max: numOr(b.dataset.max, 1), sliderMode: b.dataset.sliderMode, locked: false, x: parseFloat(b.style.left) + 20 + 'px', y: parseFloat(b.style.top) + 20 + 'px'
            })); setStatusMsg('msg_copy');
        }
        function cutElems() { copyElems(); activeEditBtns.forEach(b => b.remove()); clearSelection(); pushHistory(); }
        function pasteElems() {
            if(clipboard.length === 0) return; clearSelection();
            clipboard.forEach(data => {
                const newData = {...data};
                // ペースト時は新しいIDを確実に生成するようID属性を削除
                if(newData.id) delete newData.id;
                const newlyAdded = addElem(newData.type, newData, false);
                data.x = (parseFloat(data.x) + 20) + 'px';
                data.y = (parseFloat(data.y) + 20) + 'px';
                activeEditBtns.push(newlyAdded);
                newlyAdded.classList.add('selected');
            });
            reflectSelectionUI(); pushHistory(); setStatusMsg('msg_paste');
        }

        // Request outcomes: every script / selection / datapath-slider request carries an id. Blender records
        // every script outcome, and select / custom_prop outcomes only when they fail or warn, in
        // /api/state script_results (bounded ring of 64).
        const SCRIPT_PENDING_MAX = 64; let _scriptSeq = 0; const _pendingScripts = new Map();
        const SCRIPT_ACK_TIMEOUT_MS = 8000; const _scriptAckTransports = new Map(); const _scriptAckStates = new Map();
        const ACTION_PENDING_MAX = 256; const _pendingActions = new Map();
        function newRequestId() { return 'ss' + Date.now().toString(36) + '_' + (++_scriptSeq); }
        function codeText(c) { const k = 'code_' + String(c || ''); return (i18n[currentLang] && i18n[currentLang][k]) || (i18n.en && i18n.en[k]) || ''; }
        function failureDetail(code, err) {
            // Machine codes are localized; 'error' and warning entries carry Blender's own report text.
            code = String(code || ''); err = String(err || '');
            const text = (err && err !== code) ? (codeText(err) || err) : (codeText(code) || code);
            return text.slice(0, 160);
        }
        function sendTrackedAction(url, payload) {
            const id = newRequestId();
            _pendingActions.set(id, true);
            while(_pendingActions.size > ACTION_PENDING_MAX) _pendingActions.delete(_pendingActions.keys().next().value);
            apiFetch(url, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(Object.assign({}, payload || {}, { id: id })) })
                .then(r => {
                    if(r.ok) return;
                    _pendingActions.delete(id);
                    return r.json().catch(() => ({})).then(b => {
                        const errCode = (b && typeof b.error === 'string') ? b.error : '';
                        showToast(i18nText('msg_action_failed') + ': ' + (errCode ? failureDetail('', errCode) + ' ' : '') + '(HTTP ' + r.status + ')');
                    });
                })
                .catch(err => { _pendingActions.delete(id); showToast(i18nText('msg_action_failed') + ': ' + (err && err.message ? err.message : err)); });
        }
        function sendSelectPayload(payload){ sendTrackedAction('/api/select', payload); }
        function sendSelection(targets, shiftKey, ctrlKey) { sendSelectPayload({ target_type:'object', objects: targets, shift: shiftKey, ctrl: ctrlKey }); }
        function scriptFailureText(code, err) {
            if(code === 'execute_script_disabled' || err === 'execute_script_disabled') return i18nText('msg_script_disabled');
            const detail = failureDetail(code, err);
            return i18nText('msg_script_failed') + (detail ? ': ' + detail : '');
        }
        function clearScriptAckTransport(id) {
            const transport = _scriptAckTransports.get(id);
            if(transport) {
                clearTimeout(transport.timer);
                try { if(!transport.controller.signal.aborted) transport.controller.abort(); } catch(e) {}
            }
            _scriptAckTransports.delete(id);
        }
        function recordScriptAckState(id, state) {
            _scriptAckStates.set(id, state);
            while(_scriptAckStates.size > SCRIPT_PENDING_MAX) _scriptAckStates.delete(_scriptAckStates.keys().next().value);
        }
        function settleScriptAck(id, controller, state) {
            const transport = _scriptAckTransports.get(id);
            if(!transport || transport.controller !== controller) return false;
            clearScriptAckTransport(id);
            // An authoritative /api/state result may win the race. Never let a late ACK overwrite it.
            if(!_pendingScripts.has(id)) { _scriptAckStates.delete(id); return false; }
            recordScriptAckState(id, state);
            if(state !== 'accepted') showToast(i18nText('msg_script_failed'));
            return true;
        }
        function onScriptFailed(id, msg) {
            clearScriptAckTransport(id); _scriptAckStates.delete(id);
            const p = _pendingScripts.get(id); _pendingScripts.delete(id);
            if(p && p.elem && p.revertTo !== undefined && p.elem.isConnected) {
                // Undo the optimistic flip of a classic toggle: the script did not run.
                p.elem.dataset.toggleState = p.revertTo;
                if(!isEditMode) p.elem.classList.toggle('selected', p.revertTo === 'true');
                updateElemView(p.elem);
            }
            showToast(msg);
        }
        function handleScriptResults(results) {
            results.forEach(r => {
                if(!r || typeof r !== 'object') return;
                const id = String(r.id || ''); if(!id) return;
                const code = String(r.code || ''); const err = String(r.error || '');
                if(_pendingScripts.has(id)) {
                    clearScriptAckTransport(id); _scriptAckStates.delete(id);
                    if(r.ok === true) { _pendingScripts.delete(id); if(err) showToast(i18nText('msg_action_warning') + ': ' + failureDetail(code, err)); return; }
                    onScriptFailed(id, scriptFailureText(code, err));
                } else if(_pendingActions.has(id)) {
                    _pendingActions.delete(id);
                    if(r.ok === true && !err) return;
                    showToast(i18nText(r.ok === true ? 'msg_action_warning' : 'msg_action_failed') + ': ' + failureDetail(code, err));
                }
            });
        }
        function sendScript(code, opts) {
            if(!String(code || '').trim()) return; // nothing to run (Blender would only answer CANCELLED / empty_script)
            const id = newRequestId();
            _pendingScripts.set(id, Object.assign({}, opts || {}));
            while(_pendingScripts.size > SCRIPT_PENDING_MAX) {
                const oldest = _pendingScripts.keys().next().value;
                _pendingScripts.delete(oldest); clearScriptAckTransport(oldest); _scriptAckStates.delete(oldest);
            }
            const controller = new AbortController();
            const timer = setTimeout(() => {
                const transport = _scriptAckTransports.get(id);
                if(!transport || transport.controller !== controller) return;
                try { controller.abort(); } catch(e) {}
                settleScriptAck(id, controller, 'timeout');
            }, SCRIPT_ACK_TIMEOUT_MS);
            _scriptAckTransports.set(id, { controller: controller, timer: timer });
            apiFetch('/api/execute_script', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ script: code, id: id }), signal: controller.signal })
                .then(r => r.text().then(text => ({ response: r, text: text })))
                .then(packet => {
                    const r = packet.response; let body = null;
                    try { body = JSON.parse(packet.text); } catch(e) {}
                    if(!r.ok) {
                        const transport = _scriptAckTransports.get(id);
                        if(!transport || transport.controller !== controller) return;
                        clearScriptAckTransport(id); _scriptAckStates.delete(id);
                        const errCode = (body && typeof body === 'object' && !Array.isArray(body) && typeof body.error === 'string') ? body.error : '';
                        if(r.status === 403 && errCode === 'execute_script_disabled') onScriptFailed(id, i18nText('msg_script_disabled'));
                        else onScriptFailed(id, i18nText('msg_script_failed') + ': ' + (errCode ? failureDetail('', errCode) + ' ' : '') + '(HTTP ' + r.status + ')');
                        return;
                    }
                    const valid = body && typeof body === 'object' && !Array.isArray(body) && body.ok === true && body.id === id;
                    settleScriptAck(id, controller, valid ? 'accepted' : 'malformed');
                })
                .catch(() => settleScriptAck(id, controller, 'transport_failed'));
        }
        function sendTimeline(action) { apiFetch('/api/timeline', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ action: action }) }); }
        function sendCamera(action, obj) { apiFetch('/api/camera', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ action: action, camera_obj: obj }) }); }

        function onSliderInput(e, elem, gestureFinal=false) {
            if(isEditMode) return; const val = parseFloat(e.target.value);
            if(!Number.isFinite(val)) return; // empty / partial number box: nothing to send (JSON would carry null)
            const tType = elem.dataset.targetType || 'shapekey';
            if(tType === 'shapekey') {
                const obj = elem.dataset.targetObj; const key = elem.dataset.targetKey;
                if(obj && key) apiFetch('/api/set_shapekey', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ obj: obj, key: key, value: val }) });
            } else if (tType === 'datapath') {
                const obj = elem.dataset.targetObj; const path = elem.dataset.dataPath;
                if(obj && path) sendTrackedAction('/api/set_custom_prop', { obj: obj, path: path, value: val, gesture_id: elem._undoGestureId || '', gesture_final: !!gestureFinal });
            }
        }

        // ---- Real Blender state (S-2 / S-3): values come from the watched datapaths in /api/state ----
        const TRUE_WORDS = ['true', '1', 'on', 'yes']; const FALSE_WORDS = ['false', '0', 'off', 'no'];
        function realToggleIsOn(val, onValue) {
            const want = String(onValue === undefined || onValue === null ? '' : onValue).trim();
            const wl = want.toLowerCase();
            if(want === '') return (typeof val === 'string') ? (val !== '' && val !== '0' && val.toLowerCase() !== 'false') : !!val;
            if(typeof val === 'boolean') { if(TRUE_WORDS.includes(wl)) return val; if(FALSE_WORDS.includes(wl)) return !val; return false; }
            if(typeof val === 'number') {
                if(TRUE_WORDS.includes(wl) && wl !== '1') return val !== 0;
                if(FALSE_WORDS.includes(wl) && wl !== '0') return val === 0;
                const n = Number(want); return Number.isFinite(n) && Math.abs(val - n) < 1e-6;
            }
            return String(val) === want;
        }
        function readCachedDatapath(obj, path) {
            obj = String(obj || '').trim(); path = String(path || '').trim();
            if(!_lastDatapaths || !obj || !path || !Object.prototype.hasOwnProperty.call(_lastDatapaths, obj)) return undefined;
            const ov = _lastDatapaths[obj];
            if(!ov || typeof ov !== 'object' || !Object.prototype.hasOwnProperty.call(ov, path)) return undefined;
            return ov[path];
        }
        function applyRealToggleStates() {
            document.querySelectorAll('.selector-btn[data-type="button"][data-action-type="toggle"]').forEach(btn => {
                const wasOn = btn.classList.contains('selected');
                if(!btn.dataset.statePath) {
                    btn.classList.remove('state-unknown'); delete btn.dataset.realState;
                    if(!isEditMode) btn.classList.toggle('selected', btn.dataset.toggleState === 'true');
                } else {
                    const val = readCachedDatapath(btn.dataset.stateObj, btn.dataset.statePath);
                    const st = (val === undefined || val === null) ? 'unknown' : (realToggleIsOn(val, btn.dataset.stateOnValue) ? 'on' : 'off');
                    btn.dataset.realState = st; btn.classList.toggle('state-unknown', st === 'unknown');
                    if(!isEditMode) btn.classList.toggle('selected', st === 'on');
                }
                if(!isEditMode && wasOn !== btn.classList.contains('selected') && btn.dataset.useImgSelect === 'true') updateElemView(btn);
            });
        }
        function applyDatapathSliders() {
            document.querySelectorAll('.selector-btn[data-type="slider"][data-target-type="datapath"]').forEach(slider => {
                const obj = slider.dataset.targetObj || ''; const path = slider.dataset.dataPath || '';
                if(!obj.trim() || !path.trim()) { slider.classList.remove('state-unknown'); return; }
                const raw = readCachedDatapath(obj, path);
                const ok = (typeof raw === 'number' && Number.isFinite(raw)) || typeof raw === 'boolean';
                slider.classList.toggle('state-unknown', !ok); if(!ok) return;
                const val = (typeof raw === 'boolean') ? (raw ? 1 : 0) : raw;
                const rng = slider.querySelector('.slider-input-range'); const num = slider.querySelector('.slider-input-num');
                // Not while the user is dragging the range or typing in the number box.
                if((rng && rng.matches(':active')) || (num && document.activeElement === num)) { slider._dpReadbackSkipped = true; return; }
                slider._dpReadbackSkipped = false;
                if(rng) rng.value = val; if(num) num.value = val;
            });
        }
        function applyBoneButtonStates() {
            document.querySelectorAll('.selector-btn[data-type="button"][data-action-type="bone_select"]').forEach(btn => {
                if(isEditMode && activeEditBtns.includes(btn)) return;
                const arm = btn.dataset.armature || ''; const bones = safeJsonArray(btn.dataset.bones);
                const curList = (arm && Object.prototype.hasOwnProperty.call(_lastSelectedBones, arm) && Array.isArray(_lastSelectedBones[arm])) ? _lastSelectedBones[arm] : [];
                const cur = new Set(curList);
                const wasOn = btn.classList.contains('selected');
                btn.classList.toggle('selected', bones.length > 0 && bones.every(b => cur.has(b)));
                // A button with a "selected" image swaps it when Blender's bone selection changes (same as toggles).
                if(!isEditMode && wasOn !== btn.classList.contains('selected') && btn.dataset.useImgSelect === 'true') updateElemView(btn);
            });
        }
        function clearStaleStateLook() {
            // A button whose type changed (toggle -> node, datapath -> shapekey slider) drops the "unknown" look.
            document.querySelectorAll('.selector-btn.state-unknown').forEach(b => {
                const tog = b.dataset.type === 'button' && b.dataset.actionType === 'toggle';
                const dp = b.dataset.type === 'slider' && b.dataset.targetType === 'datapath';
                if(!tog && !dp) { b.classList.remove('state-unknown'); delete b.dataset.realState; }
            });
        }
        function applyCachedBlenderState() { clearStaleStateLook(); applyRealToggleStates(); applyDatapathSliders(); applyBoneButtonStates(); }

        function onElemMouseDown(e, elem) {
            if (e.button === 1) return;
            if (e.button !== 0) return;
            if (isEditMode) {
                e.stopPropagation();
                if(e.shiftKey || e.ctrlKey) { if(activeEditBtns.includes(elem)) { activeEditBtns = activeEditBtns.filter(b => b !== elem); elem.classList.remove('selected'); } else { activeEditBtns.push(elem); elem.classList.add('selected'); } }
                else { if(!activeEditBtns.includes(elem)) { activeEditBtns.forEach(b => b.classList.remove('selected')); activeEditBtns = [elem]; elem.classList.add('selected'); } }
                reflectSelectionUI(); if(activeEditBtns.some(b => b.dataset.locked === 'true')) return;
                const pos = getWorkspacePos(e.clientX, e.clientY); dragMouseStartX = pos.x; dragMouseStartY = pos.y;
                dragObjsData = activeEditBtns.map(b => ({ btn: b, initLeft: parseFloat(b.style.left), initTop: parseFloat(b.style.top) }));
            } else {
                if(elem.dataset.type === 'slider' || elem.dataset.actionType === 'display') return;
                e.stopPropagation(); const action = elem.dataset.actionType || 'node';
                if(action === 'node') { sendSelection(safeJsonArray(elem.dataset.targets), e.shiftKey, e.ctrlKey); }
                else if(action === 'script') { sendScript(elem.dataset.scriptCode || ""); }
                else if(action === 'toggle') {
                    if(elem.dataset.statePath) {
                        // Real-state toggle: the lit state comes from Blender; no optimistic flip.
                        const rs = elem.dataset.realState;
                        if(rs !== 'on' && rs !== 'off') { showToast(i18nText('msg_state_unknown')); return; }
                        sendScript(rs === 'on' ? (elem.dataset.scriptOff || "") : (elem.dataset.scriptOn || ""));
                    } else {
                        const isON = elem.dataset.toggleState === 'true'; const newState = !isON; elem.dataset.toggleState = newState.toString(); if(newState) elem.classList.add('selected'); else elem.classList.remove('selected'); updateElemView(elem);
                        sendScript(newState ? (elem.dataset.scriptOn || "") : (elem.dataset.scriptOff || ""), { elem: elem, revertTo: isON ? 'true' : 'false' });
                    }
                }
                else if(action === 'timeline') { sendTimeline(elem.dataset.timelineAction || 'play'); }
                else if(action === 'camera') { sendCamera(elem.dataset.cameraAction || 'FRONT', elem.dataset.cameraObj || ''); }
                else if(action === 'bone_select') { sendSelectPayload({ target_type: 'bone', armature: elem.dataset.armature || '', bones: safeJsonArray(elem.dataset.bones), shift: e.shiftKey, ctrl: e.ctrlKey }); }
                else if(action === 'collection_select') { sendSelectPayload({ target_type: 'collection', collections: safeJsonArray(elem.dataset.collections), include_children: elem.dataset.includeChildren !== 'false', shift: e.shiftKey, ctrl: e.ctrlKey }); }
                else if(action === 'collection_visibility') { sendSelectPayload({ target_type: 'collection_visibility', collections: safeJsonArray(elem.dataset.collections), action: elem.dataset.collectionVisAction || 'toggle' }); }
                else if(action === 'mesh_selectset') { sendSelectPayload({ target_type: 'mesh_elems', object: elem.dataset.meshObject || '', elem_mode: elem.dataset.meshElemMode || 'VERT', indices: safeJsonArray(elem.dataset.meshIndices), shift: e.shiftKey, ctrl: e.ctrlKey }); }
            }
        }

        viewport.onmousedown = (e) => {
            if(!pageSettings.enablePanZoom && e.button === 1) return;
            if(e.button === 1 || (e.button === 0 && e.target === viewport && e.shiftKey)) { e.preventDefault(); isPanning = true; startX = e.clientX; startY = e.clientY; return; }
            if(e.button !== 0) return;
            if(e.target === viewport || e.target === workspace || e.target === bgLayer || e.target === gridLayer || e.target.id === 'scroll-content') {
                if(isEditMode) {
                    clearSelection();
                }
                else { isSelecting = true; const pos = getWorkspacePos(e.clientX, e.clientY); dragMouseStartX = pos.x; dragMouseStartY = pos.y; selectionBox.style.left = dragMouseStartX + 'px'; selectionBox.style.top = dragMouseStartY + 'px'; selectionBox.style.width = '0px'; selectionBox.style.height = '0px'; selectionBox.style.display = 'block'; }
            }
        };

        function checkSnap(val, targets) { const threshold = 10 / zoomScale; for(let t of targets) { if(Math.abs(val - t) < threshold) return t; } return null; }

        document.addEventListener('mousemove', (e) => {
            if(isResizingPanel) {
                let dx = panelStartX - e.clientX;
                let newW = startPanelW + dx;
                if (newW < 280) newW = 280; if (newW > 800) newW = 800;
                document.documentElement.style.setProperty('--panel-width', newW + 'px');
                return;
            }
            if(isPanning) { panX += (e.clientX - startX); panY += (e.clientY - startY); startX = e.clientX; startY = e.clientY; applyTransform(); }
            else if (isResizing && resizeElem) {
                const pos = getWorkspacePos(e.clientX, e.clientY);
                let dx = pos.x - startX; let dy = pos.y - startY; let w = parseFloat(resizeElem.dataset.startW) + dx; let h = parseFloat(resizeElem.dataset.startH) + dy;
                if (w < 10) w = 10; if (h < 10) h = 10;
                const isSnap = document.getElementById('snap-toggle').checked; const isGrid = document.getElementById('grid-toggle').checked; const gridSize = parseInt(document.getElementById('grid-size').value) || 20; const halfGrid = gridSize / 2;
                snapV.style.display = 'none'; snapH.style.display = 'none'; let ex = parseFloat(resizeElem.style.left); let ey = parseFloat(resizeElem.style.top);

                if (isGrid && isSnap) {
                    let right = ex + w; let bottom = ey + h; let snapX_right = Math.round(right / halfGrid) * halfGrid; if(Math.abs(right - snapX_right) < 10/zoomScale) w = snapX_right - ex;
                    let snapY_bottom = Math.round(bottom / halfGrid) * halfGrid; if(Math.abs(bottom - snapY_bottom) < 10/zoomScale) h = snapY_bottom - ey;
                }
                const isSlider = resizeElem.dataset.type === 'slider';
                if(resizeElem.dataset.shape === 'circle') { h = w; } else if (document.getElementById('elem-lock') && document.getElementById('elem-lock').checked && !isSlider) { let ratio = parseFloat(resizeElem.dataset.startW) / parseFloat(resizeElem.dataset.startH); h = w / ratio; }
                resizeElem.style.width = w + 'px'; resizeElem.style.height = h + 'px';
                if(activeEditBtns.includes(resizeElem)) { document.getElementById('elem-width').value = w.toFixed(1); document.getElementById('elem-height').value = h.toFixed(1); updateElemView(resizeElem); }

            } else if (dragObjsData.length > 0 && isEditMode) {
                const pos = getWorkspacePos(e.clientX, e.clientY);
                let dx = pos.x - dragMouseStartX; let dy = pos.y - dragMouseStartY;
                const isSnap = document.getElementById('snap-toggle').checked; const isGrid = document.getElementById('grid-toggle').checked; const gridSize = parseInt(document.getElementById('grid-size').value) || 20; const halfGrid = gridSize / 2;
                snapV.style.display = 'none'; snapH.style.display = 'none';

                const base = dragObjsData[0]; let nx = base.initLeft + dx; let ny = base.initTop + dy; let w = parseFloat(base.btn.style.width); let h = parseFloat(base.btn.style.height); let snappedX = false; let snappedY = false;
                if (isGrid && isSnap) {
                    let cx = nx + w/2; let cy = ny + h/2; let snapX_left = Math.round(nx / halfGrid) * halfGrid; let snapX_center = Math.round(cx / halfGrid) * halfGrid; let distLeft = Math.abs(nx - snapX_left); let distCenter = Math.abs(cx - snapX_center);
                    if(distCenter < 10/zoomScale && distCenter <= distLeft) { dx = (snapX_center - w/2) - base.initLeft; nx = snapX_center - w/2; snappedX = true; } else if (distLeft < 10/zoomScale) { dx = snapX_left - base.initLeft; nx = snapX_left; snappedX = true; }
                    let snapY_top = Math.round(ny / halfGrid) * halfGrid; let snapY_middle = Math.round(cy / halfGrid) * halfGrid; let distTop = Math.abs(ny - snapY_top); let distMiddle = Math.abs(cy - snapY_middle);
                    if(distMiddle < 10/zoomScale && distMiddle <= distTop) { dy = (snapY_middle - h/2) - base.initTop; ny = snapY_middle - h/2; snappedY = true; } else if (distTop < 10/zoomScale) { dy = snapY_top - base.initTop; ny = snapY_top; snappedY = true; }
                }
                if (isSnap && (!snappedX || !snappedY)) {
                    let snapTargetsX = [0, parseFloat(document.getElementById('canvas-w').value)||500]; let snapTargetsY = [0, parseFloat(document.getElementById('canvas-h').value)||500];
                    document.querySelectorAll('.selector-btn').forEach(b => { if(activeEditBtns.includes(b)) return; snapTargetsX.push(parseFloat(b.style.left), parseFloat(b.style.left) + parseFloat(b.style.width)/2, parseFloat(b.style.left) + parseFloat(b.style.width)); snapTargetsY.push(parseFloat(b.style.top), parseFloat(b.style.top) + parseFloat(b.style.height)/2, parseFloat(b.style.top) + parseFloat(b.style.height)); });
                    if (!snappedX) { let sxL = checkSnap(nx, snapTargetsX); let sxC = checkSnap(nx + w/2, snapTargetsX); let sxR = checkSnap(nx + w, snapTargetsX); if(sxL !== null) { dx = sxL - base.initLeft; snapV.style.left = sxL + 'px'; snapV.style.display = 'block'; } else if(sxC !== null) { dx = sxC - w/2 - base.initLeft; snapV.style.left = sxC + 'px'; snapV.style.display = 'block'; } else if(sxR !== null) { dx = sxR - w - base.initLeft; snapV.style.left = sxR + 'px'; snapV.style.display = 'block'; } }
                    if (!snappedY) { let syT = checkSnap(ny, snapTargetsY); let syM = checkSnap(ny + h/2, snapTargetsY); let syB = checkSnap(ny + h, snapTargetsY); if(syT !== null) { dy = syT - base.initTop; snapH.style.top = syT + 'px'; snapH.style.display = 'block'; } else if(syM !== null) { dy = syM - h/2 - base.initTop; snapH.style.top = syM + 'px'; snapH.style.display = 'block'; } else if(syB !== null) { dy = syB - h - base.initTop; snapH.style.top = syB + 'px'; snapH.style.display = 'block'; } }
                }

                dragObjsData.forEach(d => { let nx = d.initLeft + dx; let ny = d.initTop + dy; d.btn.style.left = nx + 'px'; d.btn.style.top = ny + 'px'; });
                if(activeEditBtns.length === 1 && activeEditBtns[0] === dragObjsData[0].btn) { document.getElementById('elem-x').value = parseFloat(activeEditBtns[0].style.left).toFixed(1); document.getElementById('elem-y').value = parseFloat(activeEditBtns[0].style.top).toFixed(1); }
            } else if (isSelecting && !isEditMode) {
                const pos = getWorkspacePos(e.clientX, e.clientY); const ex = pos.x; const ey = pos.y;
                const x = Math.min(dragMouseStartX, ex); const y = Math.min(dragMouseStartY, ey); const w = Math.abs(ex - dragMouseStartX); const h = Math.abs(ey - dragMouseStartY);
                selectionBox.style.left = x + 'px'; selectionBox.style.top = y + 'px'; selectionBox.style.width = w + 'px'; selectionBox.style.height = h + 'px';
            }
        });

        document.addEventListener('mouseup', (e) => {
            if (isResizingPanel) {
                isResizingPanel = false; document.body.classList.remove('resizing-panel');
                let newW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--panel-width'));
                pageSettings.panelWidth = newW; pushHistory(); return;
            }
            if(isPanning) { isPanning = false; return; }
            if (isResizing) { isResizing = false; resizeElem = null; snapV.style.display = 'none'; snapH.style.display = 'none'; pushHistory(); }
            if (dragObjsData.length > 0) { dragObjsData = []; snapV.style.display = 'none'; snapH.style.display = 'none'; pushHistory(); }
            if (isSelecting) {
                const rect = { left: parseFloat(selectionBox.style.left), top: parseFloat(selectionBox.style.top), right: parseFloat(selectionBox.style.left) + parseFloat(selectionBox.style.width), bottom: parseFloat(selectionBox.style.top) + parseFloat(selectionBox.style.height) };
                isSelecting = false; selectionBox.style.display = 'none';
                if (parseFloat(selectionBox.style.width) < 5 && parseFloat(selectionBox.style.height) < 5) { if(pageSettings.emptyClickDeselect !== false) sendSelection([], false, false); return; }
                let selectedTargets = [];
                document.querySelectorAll('.selector-btn[data-type="button"]').forEach(btn => {
                    if(btn.dataset.actionType !== 'node') return;
                    const bx = parseFloat(btn.style.left); const by = parseFloat(btn.style.top); const bw = parseFloat(btn.style.width); const bh = parseFloat(btn.style.height);
                    if (!(bx + bw < rect.left || bx > rect.right || by + bh < rect.top || by > rect.bottom)) { selectedTargets = selectedTargets.concat(safeJsonArray(btn.dataset.targets)); }
                });
                if (selectedTargets.length > 0) { selectedTargets = [...new Set(selectedTargets)]; sendSelection(selectedTargets, e.shiftKey, e.ctrlKey); }
            }
        });

        viewport.oncontextmenu = (e) => { if(e.target === viewport || e.target === workspace || e.target === bgLayer || e.target === gridLayer || e.target.id === 'scroll-content') onElemContextMenu(e, 'bg'); };

        function onElemContextMenu(e, target) {
            e.preventDefault(); if (!isEditMode) return; targetMenuObj = target; const isBg = (target === 'bg');
            document.getElementById('ctx-title').innerText = isBg ? i18n[currentLang]['ctx_title_bg'] : (target.dataset.type === 'slider' ? i18n[currentLang]['modal_title_slider'] : i18n[currentLang]['ctx_title_elem']);
            document.getElementById('ctx-action-btn').style.display = isBg ? 'none' : 'block'; document.getElementById('ctx-delete-btn').style.display = isBg ? 'none' : 'block';
            let isLocked = false; if(isBg) isLocked = bgData.locked; else { if(!activeEditBtns.includes(target)) { activeEditBtns=[target]; reflectSelectionUI(); } isLocked = target.dataset.locked === 'true'; }
            const lockBtn = document.getElementById('ctx-lock-btn'); lockBtn.innerText = isLocked ? i18n[currentLang]['ctx_unlock'] : i18n[currentLang]['ctx_lock']; lockBtn.style.color = isLocked ? "var(--accent-color)" : "#f39c12";
            ctxMenu.style.display = 'block'; let px = e.clientX, py = e.clientY; if(px + 160 > window.innerWidth) px = window.innerWidth - 160; if(py + 150 > window.innerHeight) py = window.innerHeight - 150; ctxMenu.style.left = px + 'px'; ctxMenu.style.top = py + 'px';
        }

        function toggleLock() { if(targetMenuObj === 'bg') { bgData.locked = !bgData.locked; updateBgView(); } else if(targetMenuObj) { const isLocked = targetMenuObj.dataset.locked === 'true'; activeEditBtns.forEach(b => { b.dataset.locked = (!isLocked).toString(); updateElemView(b); }); } ctxMenu.style.display = 'none'; pushHistory(); }
        function deleteElem() { if(targetMenuObj && targetMenuObj !== 'bg') { activeEditBtns.forEach(b => b.remove()); clearSelection(); ctxMenu.style.display = 'none'; pushHistory(); } }
        document.onclick = (e) => { if(!ctxMenu.contains(e.target) && !e.target.classList.contains('selector-btn') && e.target.id !== 'bg-layer' && e.target !== viewport && e.target !== workspace) { ctxMenu.style.display = 'none'; } };

        function openActionModal() {
            ctxMenu.style.display = 'none'; if(!targetMenuObj || targetMenuObj === 'bg') return; const type = targetMenuObj.dataset.type; document.getElementById('action-modal').style.display = 'flex';
            if(type === 'slider') {
                document.getElementById('modal-title').innerText = i18n[currentLang]['modal_title_slider']; document.getElementById('modal-btn-content').style.display = 'none'; document.getElementById('modal-slider-content').style.display = 'block';
                const tType = targetMenuObj.dataset.targetType || 'shapekey'; document.getElementById('slider-target-type').value = tType;
                document.getElementById('slider-data-path').value = targetMenuObj.dataset.dataPath || "";
                apiFetch('/api/state').then(r => r.json()).then(data => {
                    const sObj = document.getElementById('slider-obj-list'); sObj.innerHTML = ''; const emptyOpt = document.createElement('option'); emptyOpt.value = ""; emptyOpt.innerText = i18n[currentLang]['opt_select_obj']; sObj.appendChild(emptyOpt);
                    data.objects.forEach(objName => { const opt = document.createElement('option'); opt.value = objName; opt.innerText = objName; if(targetMenuObj.dataset.targetObj === objName) opt.selected = true; sObj.appendChild(opt); }); fetchShapeKeys();
                }); switchSliderTargetType();
            } else {
                document.getElementById('modal-title').innerText = i18n[currentLang]['modal_title_btn']; document.getElementById('modal-btn-content').style.display = 'block'; document.getElementById('modal-slider-content').style.display = 'none';
                const action = targetMenuObj.dataset.actionType || 'node'; document.getElementById('modal-action-type').value = action; document.getElementById('modal-script-code').value = targetMenuObj.dataset.scriptCode || ""; document.getElementById('modal-toggle-default').value = targetMenuObj.dataset.toggleState || "false"; document.getElementById('modal-script-on').value = targetMenuObj.dataset.scriptOn || ""; document.getElementById('modal-script-off').value = targetMenuObj.dataset.scriptOff || "";
                document.getElementById('modal-timeline-action').value = targetMenuObj.dataset.timelineAction || "play"; document.getElementById('modal-camera-action').value = targetMenuObj.dataset.cameraAction || "FRONT"; document.getElementById('modal-camera-obj').value = targetMenuObj.dataset.cameraObj || "";
                _modalMeshCapture = null; _modalDataReady = false;
                document.getElementById('modal-toggle-state-path').value = targetMenuObj.dataset.statePath || ""; document.getElementById('modal-toggle-state-on').value = targetMenuObj.dataset.stateOnValue || "";
                document.getElementById('modal-collection-include-children').checked = targetMenuObj.dataset.includeChildren !== 'false';
                const stObjSel = document.getElementById('modal-toggle-state-obj'); stObjSel.innerHTML = ''; { const curSt = targetMenuObj.dataset.stateObj || ''; const e0 = document.createElement('option'); e0.value = ''; e0.innerText = '--'; stObjSel.appendChild(e0); if(curSt) { const o = document.createElement('option'); o.value = curSt; o.innerText = curSt; o.selected = true; stObjSel.appendChild(o); } }
                apiFetch('/api/state').then(r => r.json()).then(data => {
                    const objList = document.getElementById('modal-obj-list'); objList.innerHTML = ''; const currentTargets = safeJsonArray(targetMenuObj.dataset.targets);
                    data.objects.forEach(objName => { const opt = document.createElement('option'); opt.value = objName; opt.innerText = objName; if(currentTargets.includes(objName)) opt.selected = true; objList.appendChild(opt); });
                    const camList = document.getElementById('modal-camera-obj'); camList.innerHTML = '';
                    const colList = document.getElementById('modal-collection-list'); if(colList){ colList.innerHTML=''; const curCols = safeJsonArray(targetMenuObj.dataset.collections); (data.collections||[]).forEach(cn=>{ const opt=document.createElement('option'); opt.value=cn; opt.innerText=cn; if(curCols.includes(cn)) opt.selected=true; colList.appendChild(opt); }); curCols.forEach(cn=>{ if(typeof cn !== 'string' || (data.collections||[]).includes(cn)) return; const opt=document.createElement('option'); opt.value=cn; opt.innerText=cn; opt.selected=true; colList.appendChild(opt); }); }
                    const colVisList = document.getElementById('modal-collection-vis-list'); if(colVisList){ colVisList.innerHTML=''; const curCols2 = safeJsonArray(targetMenuObj.dataset.collections); (data.collections||[]).forEach(cn=>{ const opt=document.createElement('option'); opt.value=cn; opt.innerText=cn; if(curCols2.includes(cn)) opt.selected=true; colVisList.appendChild(opt); }); curCols2.forEach(cn=>{ if(typeof cn !== 'string' || (data.collections||[]).includes(cn)) return; const opt=document.createElement('option'); opt.value=cn; opt.innerText=cn; opt.selected=true; colVisList.appendChild(opt); }); }
                    const armList = document.getElementById('modal-armature-list'); if(armList){ armList.innerHTML=''; const curArm = targetMenuObj.dataset.armature || ''; const empty = document.createElement('option'); empty.value=''; empty.innerText='--'; armList.appendChild(empty); (data.armatures||[]).forEach(an=>{ const opt=document.createElement('option'); opt.value=an; opt.innerText=an; if(curArm===an) opt.selected=true; armList.appendChild(opt); }); if(curArm && !(data.armatures||[]).includes(curArm)) { const opt=document.createElement('option'); opt.value=curArm; opt.innerText=curArm; opt.selected=true; armList.appendChild(opt); } }
                    const meshList = document.getElementById('modal-mesh-obj'); if(meshList){ meshList.innerHTML=''; const curMesh = targetMenuObj.dataset.meshObject || ''; const empty2 = document.createElement('option'); empty2.value=''; empty2.innerText='--'; meshList.appendChild(empty2); (data.mesh_objects||[]).forEach(mn=>{ const opt=document.createElement('option'); opt.value=mn; opt.innerText=mn; if(curMesh===mn) opt.selected=true; meshList.appendChild(opt); }); if(curMesh && !(data.mesh_objects||[]).includes(curMesh)) { const opt=document.createElement('option'); opt.value=curMesh; opt.innerText=curMesh; opt.selected=true; meshList.appendChild(opt); } }
                    const stList = document.getElementById('modal-toggle-state-obj'); if(stList){ stList.innerHTML=''; const curSt = targetMenuObj.dataset.stateObj || ''; const empty3 = document.createElement('option'); empty3.value=''; empty3.innerText='--'; stList.appendChild(empty3); const objs = Array.isArray(data.objects) ? data.objects : []; objs.forEach(on=>{ const opt=document.createElement('option'); opt.value=on; opt.innerText=on; if(curSt===on) opt.selected=true; stList.appendChild(opt); }); if(curSt && !objs.includes(curSt)) { const opt=document.createElement('option'); opt.value=curSt; opt.innerText=curSt; opt.selected=true; stList.appendChild(opt); } }
                    if(document.getElementById('mesh-captured-count')){ try{ const arr=safeJsonArray(targetMenuObj.dataset.meshIndices); document.getElementById('mesh-captured-count').innerText = (arr||[]).length; }catch(e){ document.getElementById('mesh-captured-count').innerText='0'; } }
                    if(document.getElementById('modal-mesh-elem-mode')){ document.getElementById('modal-mesh-elem-mode').value = targetMenuObj.dataset.meshElemMode || 'VERT'; }
                    if(document.getElementById('modal-collection-vis-action')){ document.getElementById('modal-collection-vis-action').value = targetMenuObj.dataset.collectionVisAction || 'toggle'; }
                    if(armList){ armList.onchange = () => fetchBonesForArmature(); fetchBonesForArmature(); }
                    data.objects.forEach(objName => { const opt = document.createElement('option'); opt.value = objName; opt.innerText = objName; if(targetMenuObj.dataset.cameraObj === objName) opt.selected = true; camList.appendChild(opt); });
                    _modalDataReady = true;
                }).catch(err => console.warn('[SmartSelector] action modal: /api/state failed', err)); switchModalActionType();
            }
        }
        function switchModalActionType() {
            const v = document.getElementById('modal-action-type').value;
            document.getElementById('modal-node-area').style.display = (v==='node') ? 'block' : 'none';
            document.getElementById('modal-script-area').style.display = (v==='script') ? 'block' : 'none';
            document.getElementById('modal-toggle-area').style.display = (v==='toggle') ? 'block' : 'none';
            document.getElementById('modal-timeline-area').style.display = (v==='timeline') ? 'block' : 'none';
            document.getElementById('modal-camera-area').style.display = (v==='camera') ? 'block' : 'none';
            document.getElementById('modal-display-area').style.display = (v==='display') ? 'block' : 'none';
            document.getElementById('modal-collection-area').style.display = (v==='collection_select') ? 'block' : 'none';
            document.getElementById('modal-collection-vis-area').style.display = (v==='collection_visibility') ? 'block' : 'none';
            document.getElementById('modal-bone-area').style.display = (v==='bone_select') ? 'block' : 'none';
            document.getElementById('modal-meshset-area').style.display = (v==='mesh_selectset') ? 'block' : 'none';
        }
        function switchCameraUI() { const camAction = document.getElementById('modal-camera-action').value; document.getElementById('modal-camera-obj-wrapper').style.display = (camAction === 'CAMERA') ? 'block' : 'none'; }
        function switchSliderTargetType() { const v = document.getElementById('slider-target-type').value; document.getElementById('slider-shapekey-area').style.display = (v==='shapekey') ? 'block' : 'none'; document.getElementById('slider-datapath-area').style.display = (v==='datapath') ? 'block' : 'none'; }
        function closeActionModal() { document.getElementById('action-modal').style.display = 'none'; }
        function applyActionModal() {
            if(!targetMenuObj) return; const type = targetMenuObj.dataset.type;
            if(type === 'slider') {
                const tType = document.getElementById('slider-target-type').value; const objName = document.getElementById('slider-obj-list').value; const keyName = document.getElementById('slider-key-list').value; const dPath = document.getElementById('slider-data-path').value;
                if(tType === 'datapath' && dPath.trim() && !isSafeDataPath(dPath)) { alert(i18nText('msg_invalid_datapath')); return; }
                activeEditBtns.forEach(b => { b.dataset.targetType = tType; b.dataset.targetObj = objName; b.dataset.targetKey = keyName; b.dataset.dataPath = dPath; });
            }
            else {
                const action = document.getElementById('modal-action-type').value; const targets = Array.from(document.getElementById('modal-obj-list').selectedOptions).map(o => o.value); const sCode = document.getElementById('modal-script-code').value; const tDef = document.getElementById('modal-toggle-default').value; const sOn = document.getElementById('modal-script-on').value; const sOff = document.getElementById('modal-script-off').value;
                const tlAct = document.getElementById('modal-timeline-action').value; const camAct = document.getElementById('modal-camera-action').value; const camObj = document.getElementById('modal-camera-obj').value;
                const stObj = document.getElementById('modal-toggle-state-obj').value; const stPath = document.getElementById('modal-toggle-state-path').value.trim(); const stOn = document.getElementById('modal-toggle-state-on').value.trim();
                if(action === 'toggle' && stPath && !isSafeDataPath(stPath)) { alert(i18nText('msg_invalid_datapath')); return; }
                const cols = Array.from(document.getElementById('modal-collection-list').selectedOptions).map(o => o.value);
                const visCols = Array.from(document.getElementById('modal-collection-vis-list').selectedOptions).map(o => o.value);
                const inclCh = document.getElementById('modal-collection-include-children').checked;
                const visAct = document.getElementById('modal-collection-vis-action').value;
                const arm = document.getElementById('modal-armature-list').value;
                const boneListEl = document.getElementById('modal-bone-list'); const boneSel = Array.from(boneListEl.selectedOptions).map(o => o.value);
                activeEditBtns.forEach(b => {
                    b.dataset.actionType = action; b.dataset.targets = JSON.stringify(targets); b.dataset.scriptCode = sCode; b.dataset.toggleState = tDef; b.dataset.scriptOn = sOn; b.dataset.scriptOff = sOff;
                    b.dataset.timelineAction = tlAct; b.dataset.cameraAction = camAct; b.dataset.cameraObj = camObj;
                    // Selection targets: write only the active type's fields (both collection lists mirror the same saved field),
                    // and only after the async list fill landed, so an early Apply cannot wipe saved targets.
                    if(action === 'toggle') { b.dataset.stateObj = stObj; b.dataset.statePath = stPath; b.dataset.stateOnValue = stOn; }
                    else if(action === 'collection_select' && _modalDataReady) { b.dataset.collections = JSON.stringify(cols); b.dataset.includeChildren = inclCh ? 'true' : 'false'; }
                    else if(action === 'collection_visibility' && _modalDataReady) { b.dataset.collections = JSON.stringify(visCols); b.dataset.collectionVisAction = visAct; }
                    else if(action === 'bone_select' && _modalDataReady) {
                        const keepOld = (arm === (b.dataset.armature || '')) && boneListEl.options.length === 0; // bone list not loaded (yet)
                        b.dataset.armature = arm; if(!keepOld) b.dataset.bones = JSON.stringify(boneSel);
                    }
                    else if(action === 'mesh_selectset' && _modalMeshCapture) { b.dataset.meshObject = _modalMeshCapture.object; b.dataset.meshElemMode = _modalMeshCapture.elem_mode; b.dataset.meshIndices = JSON.stringify(_modalMeshCapture.indices); }
                    if(action === 'toggle' && !stPath && tDef === 'true') b.classList.add('selected'); else b.classList.remove('selected'); updateElemView(b);
                });
            }
            updateWatchShapekeys(); applyCachedBlenderState();
            closeActionModal(); pushHistory();
        }

        let _boneFetchSeq = 0;
        function fetchBonesForArmature() {
            const arm = document.getElementById('modal-armature-list') ? document.getElementById('modal-armature-list').value : '';
            const boneList = document.getElementById('modal-bone-list'); if(!boneList) return;
            boneList.innerHTML = '';
            const seq = ++_boneFetchSeq;
            if(!arm) return;
            apiFetch(`/api/bones?armature=${encodeURIComponent(arm)}`).then(r=>r.json()).then(data=>{
                if(seq !== _boneFetchSeq || !targetMenuObj || targetMenuObj === 'bg') return; // a newer request owns the list
                const names = Array.isArray(data.bones) ? data.bones : [];
                const cur = (targetMenuObj.dataset.armature || '') === arm ? safeJsonArray(targetMenuObj.dataset.bones) : [];
                names.forEach(bn=>{ const opt=document.createElement('option'); opt.value=bn; opt.innerText=bn; if(cur.includes(bn)) opt.selected=true; boneList.appendChild(opt); });
                // Keep saved bones that are not in the armature right now, so Apply does not silently drop them.
                cur.forEach(bn=>{ if(typeof bn !== 'string' || names.includes(bn)) return; const opt=document.createElement('option'); opt.value=bn; opt.innerText=bn; opt.selected=true; boneList.appendChild(opt); });
            }).catch(err => console.warn('[SmartSelector] /api/bones failed', err));
        }

        function captureBones() {
            const arm = document.getElementById('modal-armature-list') ? document.getElementById('modal-armature-list').value : '';
            if(!arm) { showToast(i18nText('msg_capture_need_target')); return; }
            apiFetch('/api/capture_selection', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ cap_kind:'bones', armature: arm }) })
            .then(r=>r.json()).then(data=>{
                if(data && data.error) { showToast(i18nText('msg_capture_failed') + ': ' + failureDetail('', data.error)); return; }
                if(!data || !Array.isArray(data.bones)) { showToast(i18nText('msg_capture_failed')); return; }
                const selected = data.bones;
                const boneList = document.getElementById('modal-bone-list'); if(!boneList) return;
                Array.from(boneList.options).forEach(opt=>{ opt.selected = selected.includes(opt.value); });
            }).catch(err => showToast(i18nText('msg_capture_failed') + ': ' + (err && err.message ? err.message : err)));
        }

        function captureMeshSelection() {
            const obj = document.getElementById('modal-mesh-obj') ? document.getElementById('modal-mesh-obj').value : '';
            const mode = document.getElementById('modal-mesh-elem-mode') ? document.getElementById('modal-mesh-elem-mode').value : 'VERT';
            if(!obj) { showToast(i18nText('msg_capture_need_target')); return; }
            apiFetch('/api/capture_selection', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ cap_kind:'mesh_elems', object: obj, elem_mode: mode }) })
            .then(r=>r.json()).then(data=>{
                if(data && data.error) { showToast(i18nText('msg_capture_failed') + ': ' + failureDetail('', data.error)); return; }
                if(!data || !Array.isArray(data.indices)) { showToast(i18nText('msg_capture_failed')); return; }
                // Not active / not in Edit Mode: nothing was captured and the stored indices stay as they are.
                if(data.note) { showToast(translateStatusMessage(data.note)); return; }
                // Held until Apply (Cancel discards it); written to every selected button by applyActionModal.
                _modalMeshCapture = { object: obj, elem_mode: mode, indices: data.indices };
                if(document.getElementById('mesh-captured-count')) document.getElementById('mesh-captured-count').innerText = data.indices.length;
            }).catch(err => showToast(i18nText('msg_capture_failed') + ': ' + (err && err.message ? err.message : err)));
        }

        function setStatusMsgRaw(msg){
            try{ statusText.innerText = translateStatusMessage(msg); setTimeout(()=>{ statusText.innerText = i18n[currentLang]['status_ready']; }, 1200); }catch(e){}
        }
function fetchShapeKeys() {
            try {
                const objList = document.getElementById('slider-obj-list');
                const keyList = document.getElementById('slider-key-list');
                if(!objList || !keyList) return;
                const objName = objList.value;
                keyList.innerHTML = '';
                if(!objName) return;
                apiFetch(`/api/shapekeys?obj=${encodeURIComponent(objName)}`)
                    .then(r => r.ok ? r.json() : {keys: []})
                    .then(data => { (Array.isArray(data.keys) ? data.keys : []).forEach(k => { const opt = document.createElement('option'); opt.value = k; opt.innerText = k; if(targetMenuObj && targetMenuObj.dataset.targetKey === k) opt.selected = true; keyList.appendChild(opt); }); })
                    .catch(() => {});
            } catch(e) {}
        }

        function saveFile() {
            if(!fileName) { saveAsFile(); return; }
            if(confirm(i18n[currentLang]['msg_confirm_save'])) { execSave(fileName); }
        }
        function saveAsFile() {
            let defaultName = fileName ? stripJsonExt(fileName) : (currentLang === "ja" ? "新規セレクター" : "New_Selector");
            let input = prompt(i18n[currentLang]['msg_prompt_save'], defaultName);
            if(!input) return;
            input = String(input).trim();
            if(!input) return;
            fileName = input.toLowerCase().endsWith('.json') ? input : (input + ".json");
            const displayName = stripJsonExt(fileName);
            document.getElementById('current-file-label').innerText = `[${displayName}]`;
            document.title = `Smart Selector [${displayName}]`;
            execSave(fileName);
        }
        function execSave(targetFile) {
            saveCurrentPageData();
            let pw = pageSettings.panelWidth || 380;
            let saveW = window.outerWidth; let saveH = window.outerHeight; if(!isEditMode) { saveW += pw; saveH += 44; }
            const saveData = { schema_version: 2, meta: { app: 'Smart Selector', saved_at: new Date().toISOString() }, pages: pages, settings: { topmost: isTopmost, winW: saveW, winH: saveH }, pageSettings: pageSettings };
            setStatusMsg('btn_saving');
            apiFetch(`/api/save?project=${encodeURIComponent(projectName)}&file=${encodeURIComponent(targetFile)}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(saveData) })
                .then(r => { if(!r.ok) throw new Error(`HTTP ${r.status}`); return r.json().catch(() => ({})); })
                .then(() => setStatusMsg('msg_save'))
                .catch(err => setStatusMsgRaw((currentLang === 'ja' ? '保存に失敗しました: ' : 'Save failed: ') + (err && err.message ? err.message : err)));
        }

        function loadData(callback) {
            apiFetch(`/api/load?project=${encodeURIComponent(projectName)}&file=${encodeURIComponent(fileName)}`)
            .then(r => r.json()).then(data => {
                if(data.background && data.buttons && !data.pages) { pages = [{ id: "legacy", name: makeDefaultPageName(1), background: data.background, canvasW: 500, canvasH: 500, elems: data.buttons }]; }
                else if(data.pages) { pages = data.pages; } else { pages = [createEmptyPage(makeDefaultPageName(1))]; }

                if(data.pageSettings) {
                    pageSettings = data.pageSettings; try{ delete pageSettings.lang; }catch(e){} document.getElementById('hover-color').value = pageSettings.hoverColor || "#f1c40f"; document.getElementById('select-color').value = pageSettings.selectColor || "#e74c3c";
                    document.getElementById('hover-opacity').value = pageSettings.hoverOpacity ?? 25; document.getElementById('select-opacity').value = pageSettings.selectOpacity ?? 25;
                    document.getElementById('hover-outline-chk').checked = pageSettings.hoverOutline ?? true; document.getElementById('hover-glow-chk').checked = pageSettings.hoverGlow ?? true;
                    document.getElementById('select-outline-chk').checked = pageSettings.selectOutline ?? true; document.getElementById('select-glow-chk').checked = pageSettings.selectGlow ?? true;
                    document.getElementById('panzoom-toggle').checked = pageSettings.enablePanZoom ?? true;
                    document.getElementById('empty-click-deselect-toggle').checked = pageSettings.emptyClickDeselect !== false;
                    document.getElementById('tab-bar-bg').value = pageSettings.tabBarBg || '#2d2d2d'; document.getElementById('tab-bg').value = pageSettings.tabBg || '#1e1e1e'; document.getElementById('tab-act-bg').value = pageSettings.tabActBg || '#0e639c';
                    document.getElementById('tab-font-color').value = pageSettings.tabFontColor || '#aaaaaa'; document.getElementById('tab-act-font-color').value = pageSettings.tabActFontColor || '#ffffff';
                    currentLang = launchLang; applyTranslations();
                    if(pageSettings.panelWidth) { document.documentElement.style.setProperty('--panel-width', pageSettings.panelWidth + 'px'); }
                    updateColors(true); updateTabColors();
                } else { updateColors(true); updateTabColors(); }
                const th = (pageSettings && pageSettings.theme) ? pageSettings.theme : 'dark'; const ts = document.getElementById('theme-select'); if(ts){ ts.value = th; if(th==='light') document.body.classList.add('light-theme'); else document.body.classList.remove('light-theme'); }

                if(data.settings) { if(typeof data.settings.topmost !== 'undefined') isTopmost = !!data.settings.topmost; if(data.settings.winW && data.settings.winH) window.resizeTo(data.settings.winW, data.settings.winH); }
                switchTab(0, true); applyTranslations(); setStatusMsg('msg_load'); if(callback) callback();
            }).catch(() => { pages = [createEmptyPage(makeDefaultPageName(1))]; switchTab(0, true); applyTranslations(); setStatusMsg('msg_new'); if(callback) callback(); });
        }

        function toggleTopmost(forceState = null) {
            isTopmost = forceState !== null ? forceState : !isTopmost;
            const originalTitle = document.title; const tempId = "SYNC_" + Math.random().toString(36).substr(2, 9); document.title = tempId;
            setTimeout(() => {
                apiFetch('/api/topmost', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: tempId, topmost: isTopmost}) })
                .then(() => {
                    document.title = originalTitle;
                    document.getElementById('topmost-btn').innerText = isTopmost ? i18n[currentLang]['pin_on'] : i18n[currentLang]['pin_off'];
                    if(isTopmost) { document.getElementById('topmost-btn').style.background = "#b7845a"; document.getElementById('topmost-btn').style.color = "#fff"; }
                    else { document.getElementById('topmost-btn').style.background = "var(--btn-bg)"; document.getElementById('topmost-btn').style.color = "var(--text-color)"; }
                });

            }, 100);
        }

        // v1.10.45: body-level floating tooltip (see the #floating-tooltip CSS note for why).
        const floatTip = (function(){
            const d = document.createElement('div'); d.id = 'floating-tooltip';
            d.setAttribute('role', 'tooltip'); d.setAttribute('aria-hidden', 'true');
            document.body.appendChild(d); return d;
        })();
        let floatTipOwner = null; let floatTipRaf = 0; let floatTipLastKey = '';
        function hideFloatTip() {
            floatTipOwner = null; floatTipLastKey = '';
            floatTip.style.display = 'none'; floatTip.classList.remove('tip-above');
            if(floatTipRaf) { cancelAnimationFrame(floatTipRaf); floatTipRaf = 0; }
        }
        function placeFloatTip() {
            floatTipRaf = 0;
            const owner = floatTipOwner;
            if(!owner) return;
            if(isEditMode || !owner.isConnected || !owner.dataset.tooltip || owner.style.display === 'none') { hideFloatTip(); return; }
            // Last child of <body> keeps it above anything appended later at the same z-index.
            if(floatTip !== document.body.lastElementChild) document.body.appendChild(floatTip);
            const r = owner.getBoundingClientRect();
            const vw = window.innerWidth || document.documentElement.clientWidth;
            const vh = window.innerHeight || document.documentElement.clientHeight;
            const tw = floatTip.offsetWidth; const th = floatTip.offsetHeight; const gap = 8; const m = 4;
            const above = (r.bottom + gap + th > vh - m) && (r.top - gap - th >= m);
            const top = above ? (r.top - gap - th) : (r.bottom + gap);
            const cx = r.left + r.width / 2;
            const left = Math.min(Math.max(cx - tw / 2, m), Math.max(m, vw - tw - m));
            const arrowX = Math.min(Math.max(cx - left, 10), Math.max(10, tw - 10));
            const key = Math.round(left) + ',' + Math.round(top) + ',' + Math.round(arrowX) + ',' + (above ? 1 : 0);
            if(key !== floatTipLastKey) {
                floatTipLastKey = key;
                floatTip.style.left = Math.round(left) + 'px'; floatTip.style.top = Math.round(top) + 'px';
                floatTip.style.setProperty('--tip-arrow-x', Math.round(arrowX) + 'px');
                floatTip.classList.toggle('tip-above', above);
            }
            // Follow pan / wheel-zoom / scroll / window resize while the tip is shown.
            floatTipRaf = requestAnimationFrame(placeFloatTip);
        }
        function showFloatTip(owner) {
            floatTipOwner = owner; floatTipLastKey = '';
            floatTip.innerText = owner.dataset.tooltip;
            floatTip.style.setProperty('--tooltip-bg', owner.dataset.tooltipBg || '#ffffff');
            floatTip.style.setProperty('--tooltip-color', owner.dataset.tooltipColor || '#000000');
            floatTip.style.display = 'block';
            if(floatTipRaf) { cancelAnimationFrame(floatTipRaf); floatTipRaf = 0; }
            placeFloatTip();
        }
        document.addEventListener('mouseover', (e) => {
            const t = e.target; const btn = (t && t.closest) ? t.closest('.selector-btn') : null;
            if(btn && btn === floatTipOwner) return;
            if(btn && btn.id !== 'bg-layer' && !isEditMode && btn.dataset.tooltip && workspace.contains(btn)) showFloatTip(btn);
            else if(floatTipOwner) hideFloatTip();
        }, true);
        document.documentElement.addEventListener('mouseleave', () => { if(floatTipOwner) hideFloatTip(); });
        window.addEventListener('blur', () => { if(floatTipOwner) hideFloatTip(); });
    </script>
</body>
</html>
"""
