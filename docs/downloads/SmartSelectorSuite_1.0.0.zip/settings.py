# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import bpy

_STATE_CACHE: dict[str, Any] | None = None
_SETTINGS_DIR = 'Smart_Selector_Suite'
_SETTINGS_FILE = 'Smart_Selector_Suite.json'
_PREFS_SAVE_PENDING = False
_STATE_DIRTY = False

_DEFAULTS: dict[str, Any] = {
    'npanel_state_save': True,
    'root_dir': '',
    'state_update_interval': 0.5,
    'max_backup_generations': 20,
    'enable_exec_script': True,
    'show_archived_projects': False,
    'favorite_selectors_json': '{}',
    'enable_collection_manager_tool': True,
    'enable_gp_select_tool': True,
    'show_integrated_tools': True,
    'show_collection_manager_section': False,
    'show_gp_select_section': False,
    'active_project': 'Default_Project',
    'show_favorites_only': False,
    'show_always_on_toggles': False,
    'ui_show_summary': False,
    'ui_show_selection_sets': False,
    'ui_show_project': False,
    'ui_show_selector_data': False,
    'ui_show_collection_manager': False,
    'ui_show_collection_manager_commands': False,
    'ui_show_gp_select': False,
    'ui_show_gp_select_main': False,
    'ui_show_gp_select_renaming_pass': False,
    'ui_show_gp_select_rigging': False,
    'ui_show_settings': False,
    'ui_show_settings_storage': False,
    'ui_show_settings_performance': False,
    'ui_show_settings_project_list': False,
    'ui_show_bridge_actions': False,
    'ui_show_bridge_undo_redo': False,
    'ui_show_bridge_selection': False,
    'ui_show_bridge_shapekey': False,
    'ui_show_bridge_custom_prop': False,
    'ui_show_bridge_script': False,
    'bridge_exec_script_payload': '{"script":"print(\\"Hello Smart Selector\\")"}',
    'bridge_shapekey_payload': '{"obj":"Object","key":"Key 1","value":1.0}',
    'bridge_custom_prop_payload': '{"obj":"Object","path":"location[0]","value":1.0}',
    'bridge_selection_payload': '{"target_type":"object","objects":["Cube"]}',
    # Exact RNA identifier aliases kept beside the historical storage keys.
    'exec_script_payload': '{"script":"print(\\"Hello Smart Selector\\")"}',
    'shapekey_payload': '{"obj":"Object","key":"Key 1","value":1.0}',
    'custom_prop_payload': '{"obj":"Object","path":"location[0]","value":1.0}',
    'selection_payload': '{"target_type":"object","objects":["Cube"]}',
    'smart_selector_suite_active_project': 'Default_Project',
    'smart_selector_suite_show_favorites_only': False,
    'selection_set_new_name': '',
    'gp_rename_str': '',
    'gp_full_name': '',
    'gp_find_str': '',
    'gp_replace_str': '',
    'gp_target_opacity': 0.5,
    'gp_target_pass_index': 0,
    'gp_target_sensitivity': 5.0,
    # Canonical RNA-name mirrors for the GP Renamer PropertyGroup.  The
    # historical ``gp_*`` keys remain authoritative for downgrade
    # compatibility, while these exact identifiers make the JSON schema match
    # the controls users edit in the N-panel and let every setting be audited
    # independently.
    'rename_str': '',
    'full_name': '',
    'find_str': '',
    'replace_str': '',
    'target_opacity': 0.5,
    'target_pass_index': 0,
    'target_sensitivity': 5.0,
    'cm_show_exclude': True,
    'cm_show_selectable': True,
    'cm_show_hide_viewport': True,
    'cm_show_disable_viewport': False,
    'cm_show_render': False,
    'cm_show_holdout': False,
    'cm_show_indirect_only': False,
    'cm_align_local_ops': False,
    # Exact RNA identifiers for Collection Manager's scene PropertyGroup.  The
    # historical ``cm_*`` keys above remain for compatibility, while these
    # aliases make every editable value independently discoverable/restorable
    # from the canonical Smart_Selector_Suite.json file.
    'cm_list_index': 0,
    'show_exclude': True,
    'show_selectable': True,
    'show_hide_viewport': True,
    'show_disable_viewport': False,
    'show_render': False,
    'show_holdout': False,
    'show_indirect_only': False,
    'align_local_ops': False,
    'in_phantom_mode': False,
    'ui_separator': '',
    'qcd_slots_blend_data': '',
    'cm_filter_name': '',
    'cm_use_filter_invert': False,
    'cm_filter_by_selected': False,
    'cm_filter_by_qcd': False,
    # Namespaced values stored in the same external config file.
    'always_on_features': {},
    'persistent_rna_state': {},
}

# Browser synchronization internals are no longer user-facing Always-on Toggles.
# They are normalized as enabled because they are only registered on demand while
# the browser bridge server is running, never as Blender-startup residents.
_AUTO_ON_DEMAND_BROWSER_KEYS = {
    'smart_selector_state_watchers',
    'smart_selector_state_cache_timer',
    'smart_selector_task_queue_timer',
}

_RNA_ALIAS_PAIRS = {
    'bridge_exec_script_payload': 'exec_script_payload',
    'bridge_shapekey_payload': 'shapekey_payload',
    'bridge_custom_prop_payload': 'custom_prop_payload',
    'bridge_selection_payload': 'selection_payload',
    'active_project': 'smart_selector_suite_active_project',
    'show_favorites_only': 'smart_selector_suite_show_favorites_only',
    'cm_show_exclude': 'show_exclude',
    'cm_show_selectable': 'show_selectable',
    'cm_show_hide_viewport': 'show_hide_viewport',
    'cm_show_disable_viewport': 'show_disable_viewport',
    'cm_show_render': 'show_render',
    'cm_show_holdout': 'show_holdout',
    'cm_show_indirect_only': 'show_indirect_only',
    'cm_align_local_ops': 'align_local_ops',
    'gp_rename_str': 'rename_str',
    'gp_full_name': 'full_name',
    'gp_find_str': 'find_str',
    'gp_replace_str': 'replace_str',
    'gp_target_opacity': 'target_opacity',
    'gp_target_pass_index': 'target_pass_index',
    'gp_target_sensitivity': 'target_sensitivity',
}


def _sync_rna_aliases(data: dict[str, Any], changed_key: str = '') -> None:
    if not isinstance(data, dict):
        return
    for source, alias in _RNA_ALIAS_PAIRS.items():
        if changed_key == alias:
            data[source] = data.get(alias, _DEFAULTS.get(alias))
        else:
            data[alias] = data.get(source, data.get(alias, _DEFAULTS.get(alias)))


def _normalize_auto_on_demand_state(data: dict[str, Any]) -> None:
    if not isinstance(data, dict):
        return
    nested = data.get('always_on_features')
    if not isinstance(nested, dict):
        nested = {}
        data['always_on_features'] = nested
    for key in _AUTO_ON_DEMAND_BROWSER_KEYS:
        data[key] = True
        nested[key] = True


def _blender_version_text() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def config_dir(*, create: bool = True) -> Path | None:
    """Return Blender's versioned config directory.

    Windows Blender 5.1 target:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config
    """
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', path='', create=bool(create)) or ''
            except TypeError:
                try:
                    value = user_resource('CONFIG', create=bool(create)) or ''
                except TypeError:
                    value = user_resource('CONFIG') or ''
            if value:
                path = Path(str(value)).expanduser()
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    try:
        import os
        import sys
        version = _blender_version_text()
        if os.name == 'nt':
            base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming')) / 'Blender Foundation' / 'Blender' / version / 'config'
        elif sys.platform == 'darwin':
            base = Path.home() / 'Library' / 'Application Support' / 'Blender' / version / 'config'
        else:
            base = Path.home() / '.config' / 'blender' / version / 'config'
        if create:
            base.mkdir(parents=True, exist_ok=True)
        return base
    except Exception:
        return None


def settings_dir(*, create: bool = True) -> Path | None:
    """Return the dedicated Smart Selector settings folder under Blender CONFIG.

    Windows Blender 5.1 target:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Selector_Suite
    """
    base = config_dir(create=bool(create))
    if base is None:
        return None
    folder = base / _SETTINGS_DIR
    if create:
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return folder


def settings_path() -> Path | None:
    """Return the single external JSON file for all Smart Selector N-panel settings."""
    folder = settings_dir(create=True)
    return (folder / _SETTINGS_FILE) if folder is not None else None


def _read_json_file(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            return raw if isinstance(raw, dict) else {}
    except Exception:
        pass
    return {}


def _legacy_settings_paths() -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        base = config_dir(create=False)
        if base is not None:
            # Previous 1.8.x builds stored the unified file directly under CONFIG.
            # Keep reading it once so existing user state is migrated into
            # CONFIG/Smart_Selector_Suite/Smart_Selector_Suite.json.
            paths.append(base / _SETTINGS_FILE)
    except Exception:
        pass
    legacy_filenames = (
        'smart_selector_suite_npanel_settings.json',
        'smart_selector_suite_always_on_toggles.json',
        'n_panel_settings.json',
    )
    for filename in legacy_filenames:
        try:
            from . import utils
            paths.append(Path(utils.extension_user_root(create=False)) / 'settings' / filename)
        except Exception:
            pass
        try:
            from . import storage
            paths.append(storage.settings_file(filename, create=False))
        except Exception:
            pass
    unique: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        try:
            key = str(Path(path).resolve())
        except Exception:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        unique.append(Path(path))
    return tuple(unique)


def _flatten_legacy_payload(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    if 'window_manager' in raw or 'scene' in raw:
        return {'persistent_rna_state': raw}
    # Old always-on file was a flat mapping of feature_key -> bool.
    bool_like = {k: v for k, v in raw.items() if isinstance(v, bool)}
    if bool_like and not any(k in _DEFAULTS for k in raw):
        return {'always_on_features': bool_like}
    return {str(k or '').strip(): v for k, v in raw.items() if str(k or '').strip()}


def _legacy_state_payload() -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for path in _legacy_settings_paths():
        raw = _flatten_legacy_payload(_read_json_file(path))
        for key, value in raw.items():
            if key in {'persistent_rna_state', 'always_on_features'} and isinstance(merged.get(key), dict) and isinstance(value, dict):
                merged[key].update(value)
            else:
                merged[key] = value
    return merged


def _save_user_preferences_timer():
    # Compatibility placeholder for older code paths.  Smart Selector stores its
    # state in Smart_Selector_Suite.json; no Blender preference write is needed
    # for ordinary N-panel changes.
    global _PREFS_SAVE_PENDING
    _PREFS_SAVE_PENDING = False
    return None


def queue_user_preferences_save(delay: float = 0.5) -> None:
    """Compatibility hook for older code paths; save timing follows N-panel State Save."""
    del delay
    global _PREFS_SAVE_PENDING
    _PREFS_SAVE_PENDING = True


def flush_user_preferences_save() -> None:
    """Flush pending external JSON state without touching Blender user preferences."""
    global _PREFS_SAVE_PENDING
    _PREFS_SAVE_PENDING = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_save_user_preferences_timer):
            timers.unregister(_save_user_preferences_timer)
    except Exception:
        pass
    save_state(force=True)


def _coerce_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {'1', 'true', 'yes', 'on', 'enabled'}:
        return True
    if text in {'0', 'false', 'no', 'off', 'disabled', 'none', 'null', ''}:
        return False
    return bool(default)


def _coerce_value(key: str, value: Any) -> Any:
    default = _DEFAULTS.get(key)
    if isinstance(default, bool):
        return _coerce_bool(value, default)
    if isinstance(default, int) and not isinstance(default, bool):
        try:
            return int(value)
        except Exception:
            return int(default)
    if isinstance(default, float):
        try:
            return float(value)
        except Exception:
            return float(default)
    if isinstance(default, dict):
        return dict(value) if isinstance(value, dict) else dict(default)
    if isinstance(default, list):
        return list(value) if isinstance(value, list) else list(default)
    if default is None:
        return value
    return str(value if value is not None else default)


def load_state(*, force: bool = False) -> dict[str, Any]:
    global _STATE_CACHE
    if _STATE_CACHE is not None and not force:
        return _STATE_CACHE

    data: dict[str, Any] = dict(_DEFAULTS)
    path = settings_path()
    raw = _read_json_file(path)
    if not raw:
        raw = _legacy_state_payload()

    if isinstance(raw.get('settings'), dict):
        merged = dict(raw)
        merged.update(raw.get('settings') or {})
        raw = merged

    for key, value in raw.items():
        key = str(key or '').strip()
        if not key:
            continue
        if key in _DEFAULTS:
            data[key] = _coerce_value(key, value)
        else:
            data[key] = value

    # Keep the Always-on Toggle item and the top-level save policy in sync.
    nested = raw.get('always_on_features') if isinstance(raw, dict) else None
    if isinstance(nested, dict) and 'npanel_state_save' in nested:
        data['npanel_state_save'] = _coerce_bool(nested.get('npanel_state_save'), _DEFAULTS.get('npanel_state_save', True))

    _normalize_auto_on_demand_state(data)
    _sync_rna_aliases(data)
    _STATE_CACHE = data
    if path is not None and (raw or not path.exists()):
        save_state(force=True)
    return _STATE_CACHE


def _state_save_enabled(default: bool = True) -> bool:
    """Return whether every N-panel state change should be written immediately."""
    try:
        if isinstance(_STATE_CACHE, dict):
            nested = _STATE_CACHE.get('always_on_features')
            if isinstance(nested, dict) and 'npanel_state_save' in nested:
                return _coerce_bool(nested.get('npanel_state_save'), default)
            if 'npanel_state_save' in _STATE_CACHE:
                return _coerce_bool(_STATE_CACHE.get('npanel_state_save'), default)
    except Exception:
        pass
    try:
        raw = _read_json_file(settings_path())
        nested = raw.get('always_on_features') if isinstance(raw, dict) else None
        if isinstance(nested, dict) and 'npanel_state_save' in nested:
            return _coerce_bool(nested.get('npanel_state_save'), default)
        if isinstance(raw.get('settings'), dict) and 'npanel_state_save' in raw.get('settings'):
            return _coerce_bool(raw.get('settings', {}).get('npanel_state_save'), default)
        if 'npanel_state_save' in raw:
            return _coerce_bool(raw.get('npanel_state_save'), default)
    except Exception:
        pass
    return bool(default)


def is_immediate_state_save_enabled(default: bool = True) -> bool:
    return _state_save_enabled(default)


def is_state_dirty() -> bool:
    return bool(_STATE_DIRTY)


def _write_state_to_disk() -> None:
    global _STATE_DIRTY
    path = settings_path()
    if path is None:
        return
    state = load_state()
    _normalize_auto_on_demand_state(state)
    nested = state.get('always_on_features')
    if isinstance(nested, dict) and 'npanel_state_save' in nested:
        state['npanel_state_save'] = _coerce_bool(nested.get('npanel_state_save'), _DEFAULTS.get('npanel_state_save', True))
    payload = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True)
    try:
        from . import storage
        try:
            if path.exists() and path.read_text(encoding='utf-8') == payload:
                _STATE_DIRTY = False
                return
        except Exception:
            pass
        storage.atomic_write_text(path, payload, encoding='utf-8')
    except Exception:
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_text(payload, encoding='utf-8')
        tmp.replace(path)
    _STATE_DIRTY = False


def save_state(*, force: bool = False) -> None:
    """Save Smart Selector state according to the N-panel State Save policy.

    Enabled: every change is written immediately to Smart_Selector_Suite.json.
    Disabled: changes remain in memory until scene-close or Save Preferences
    calls this function with ``force=True``.
    """
    global _STATE_DIRTY
    try:
        if not force and not _state_save_enabled(True):
            _STATE_DIRTY = True
            return
        _write_state_to_disk()
    except Exception:
        pass


def reload_state() -> dict[str, Any]:
    return load_state(force=True)


def reset_state_cache() -> None:
    global _STATE_CACHE, _STATE_DIRTY
    _STATE_CACHE = None
    _STATE_DIRTY = False


def has_saved_value(key: str) -> bool:
    key = str(key or '').strip()
    if not key:
        return False
    try:
        if isinstance(_STATE_CACHE, dict) and key in _STATE_CACHE:
            if key not in _DEFAULTS or _STATE_CACHE.get(key) != _DEFAULTS.get(key):
                return True
    except Exception:
        pass
    raw = _read_json_file(settings_path())
    if isinstance(raw.get('settings'), dict) and key in raw.get('settings'):
        return True
    return key in raw


def get_value(key: str, default: Any = None) -> Any:
    key = str(key or '').strip()
    if not key:
        return default
    if default is None and key in _DEFAULTS:
        default = _DEFAULTS[key]
    return load_state().get(key, default)


def set_value(key: str, value: Any, *, save_preferences: bool = True) -> None:
    key = str(key or '').strip()
    if not key:
        return
    if key in _DEFAULTS:
        value = _coerce_value(key, value)
    state = load_state()
    state[key] = value
    _sync_rna_aliases(state, key)
    # The state-save policy switch itself must always be flushed immediately;
    # otherwise turning it off could leave the previous ON value on disk until a
    # later scene-close/preferences-save event.
    save_state(force=(key == 'npanel_state_save'))
    if save_preferences:
        queue_user_preferences_save()


def make_getter(key: str, default: Any = None):
    def _getter(_self):
        return get_value(key, default)
    return _getter


def make_setter(key: str):
    def _setter(_self, value):
        set_value(key, value)
    return _setter


def tag_view3d_redraw(context=None) -> None:
    # Compatibility name retained. Redraw every N-panel editor where Smart
    # Selector can be managed, not only the 3D View.
    try:
        supported = {
            'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR',
            'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR',
            'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET',
        }
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in supported:
                    area.tag_redraw()
    except Exception:
        pass
