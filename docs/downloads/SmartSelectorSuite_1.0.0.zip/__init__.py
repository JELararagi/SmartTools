# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

# Add-on bootstrap: Smart Selector
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Blender Extension policy requires runtime imports to remain under the
# extension namespace (for example bl_ext.user_default.smart_selector_suite).
# Older builds exposed a legacy top-level smart_selector_suite alias in
# sys.modules; remove that alias instead of recreating it.
import os as _os
import sys as _sys


def _sssuite_drop_legacy_top_level_module_alias() -> None:
    if __name__ == 'smart_selector_suite':
        return
    try:
        current = _sys.modules.get(__name__)
        current_file = str(getattr(current, '__file__', '') or '')
        current_root = _os.path.dirname(_os.path.abspath(current_file)) if current_file else ''
        for key in tuple(_sys.modules.keys()):
            text = str(key or '').strip()
            if text != 'smart_selector_suite' and not text.startswith('smart_selector_suite.'):
                continue
            module = _sys.modules.get(text)
            if module is current:
                _sys.modules.pop(text, None)
                continue
            module_file = str(getattr(module, '__file__', '') or '')
            if not module_file:
                _sys.modules.pop(text, None)
                continue
            if current_root:
                try:
                    module_file = _os.path.abspath(module_file)
                    if module_file == current_file or module_file.startswith(current_root + _os.sep):
                        _sys.modules.pop(text, None)
                except Exception:
                    pass
    except Exception:
        pass


_sssuite_drop_legacy_top_level_module_alias()


import bpy


# --- Toolset stale wrapper quarantine START ---
def _safe_purge_stale_wrapper_artifacts() -> None:
    """Unload obsolete wrapper aliases while keeping package files read-only.

    Legacy wrapper files are retained as compatibility/migration sources.  No
    import-time path may delete, rename, create, or rewrite an installed file.
    """
    try:
        import sys
        from pathlib import Path

        root = Path(__file__).resolve().parent
        legacy_prefix = 'smart_' + 'tools'
        legacy_impl = '_smart' + 'tools_impl'
        prefix = str(__package__ or __name__ or '').strip('.')
        if prefix:
            for key in tuple(sys.modules.keys()):
                text = str(key or '').strip()
                if not text:
                    continue
                if not text.startswith(prefix + '.'):
                    continue
                if text.endswith('.' + legacy_prefix + '_unified_entry') or text.endswith('.' + legacy_impl):
                    sys.modules.pop(key, None)
        if str(__name__ or '') != 'smart_selector_suite':
            current = sys.modules.get(str(__name__ or ''))
            try:
                current_root = Path(__file__).resolve().parent
            except Exception:
                current_root = root
            for key in tuple(sys.modules.keys()):
                text = str(key or '').strip()
                if text != 'smart_selector_suite' and not text.startswith('smart_selector_suite.'):
                    continue
                module = sys.modules.get(text)
                if module is current:
                    sys.modules.pop(text, None)
                    continue
                try:
                    module_file = Path(str(getattr(module, '__file__', '') or '')).resolve()
                    if module_file == Path(__file__).resolve() or current_root in module_file.parents:
                        sys.modules.pop(text, None)
                except Exception:
                    if text == 'smart_selector_suite':
                        sys.modules.pop(text, None)
    except Exception:
        pass

_safe_purge_stale_wrapper_artifacts()
# --- Toolset stale wrapper quarantine END ---

from . import runtime as _runtime
def _safe_boot_desired_enabled(default: bool = True) -> bool:
    return bool(default)


def _safe_boot_preflight_cleanup(runtime_module, package_name, module_name, module_file):
    if runtime_module is None:
        return None
    try:
        if not _safe_boot_desired_enabled(True):
            return None
    except Exception:
        pass
    try:
        return runtime_module.preflight_cleanup(package_name, module_name, module_file)
    except TypeError:
        try:
            return runtime_module.preflight_cleanup(package_name, module_name, module_file, force=False)
        except Exception:
            return None
    except Exception:
        return None


__version__ = "1.10.63"
bl_info = {
    "name": 'Smart Selector',
    "author": 'JELararagi',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Sidebar > Smart Selector",
    "description": "Smart Selector adds Sidebar N-panel tools in the Smart Selector category across Smart Tools Manager controlled editors.",
    "category": 'Smart Selector',
}


_SSSUITE_OWNER_KEY = "SMART_SELECTOR_SUITE_OWNER"
_SSSUITE_RUNTIME_REGISTERED = False


# ------------------------------------------------------------------------------
# Duplicate-registration guard:
# If both an old wrapped package and this flattened package are installed,
# only the first one that registers becomes the active owner to avoid
# duplicate keymaps, handlers, and UI registrations.
# ------------------------------------------------------------------------------
def _sssuite_get_owner():
    try:
        return bpy.app.driver_namespace.get(_SSSUITE_OWNER_KEY)
    except Exception:
        return None


def _sssuite_set_owner(owner):
    try:
        bpy.app.driver_namespace[_SSSUITE_OWNER_KEY] = owner
    except Exception:
        pass


def _sssuite_clear_owner(owner):
    try:
        ns = bpy.app.driver_namespace
        if ns.get(_SSSUITE_OWNER_KEY) == owner:
            ns.pop(_SSSUITE_OWNER_KEY, None)
    except Exception:
        pass


def _sssuite_can_register():
    owner = _sssuite_get_owner()
    if owner and owner != __package__:
        return False
    if not owner:
        _sssuite_set_owner(__package__)
    return True


# Remove stale legacy files and previously-loaded legacy modules as early as
# possible. The flattened extension build must stay inside the package
# namespace only, so older top-level compatibility modules are removed instead
# of being reintroduced as aliases.
try:
    _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
except Exception:
    pass


def _prime_preferences_subgroups(context=None):
    # Editable settings are centralized in the Smart Selector N-panel.
    # This function remains as a compatibility hook for older startup paths.
    del context
    return None


def _register_scene_properties() -> None:
    from . import settings

    def _get_active_project(_scene):
        value = str(settings.get_value('active_project', 'Default_Project') or 'Default_Project')
        try:
            from . import utils
            return utils.sanitize_name(value, 'Default_Project')
        except Exception:
            return value or 'Default_Project'

    def _set_active_project(_scene, value):
        text = str(value or 'Default_Project')
        try:
            from . import utils
            text = utils.sanitize_name(text, 'Default_Project')
        except Exception:
            pass
        settings.set_value('active_project', text or 'Default_Project')
        settings.tag_view3d_redraw()

    def _get_show_favorites(_scene):
        return bool(settings.get_value('show_favorites_only', False))

    def _set_show_favorites(_scene, value):
        settings.set_value('show_favorites_only', bool(value))
        settings.tag_view3d_redraw()

    if not hasattr(bpy.types.Scene, 'smart_selector_suite_active_project'):
        bpy.types.Scene.smart_selector_suite_active_project = bpy.props.StringProperty(
            name='Project',
            get=_get_active_project,
            set=_set_active_project,
            description='Function: stores the active Smart Selector project folder name. How to use: choose another project from the Smart Selector N-panel project list; the selected project is saved according to N-panel State Save and restored after Blender restarts or scene changes.',
        )
    if not hasattr(bpy.types.Scene, 'smart_selector_suite_show_favorites_only'):
        bpy.types.Scene.smart_selector_suite_show_favorites_only = bpy.props.BoolProperty(
            name='Favorites Only',
            get=_get_show_favorites,
            set=_set_show_favorites,
            description='Function: filters the Selector Data List to show only selector files marked as favorites in the active project. How to use: enable this from the Smart Selector N-panel when you want to focus on favorite selectors; the filter state is saved according to N-panel State Save and restored after Blender restarts or scene changes.',
        )


def _unregister_scene_properties() -> None:
    for name in (
        'smart_selector_suite_active_project',
        'smart_selector_suite_show_favorites_only',
        'sst_active_project',
        'sst_show_favorites_only',
    ):
        try:
            if hasattr(bpy.types.Scene, name):
                delattr(bpy.types.Scene, name)
        except Exception:
            pass


def _stop_browser_server() -> None:
    try:
        from . import server
        stop_server = getattr(server, 'stop_server', None)
        if callable(stop_server):
            stop_server()
    except Exception:
        pass


def _sssuite_repair_runtime(context=None) -> None:
    _prime_preferences_subgroups(context)

    if not _sssuite_runtime_needs_repair(context):
        return

    try:
        from . import ui_runtime as _ui_runtime
        refresh = getattr(_ui_runtime, 'refresh_all_suites', None)
        if callable(refresh):
            refresh(context or bpy.context)
    except Exception:
        pass


def _sssuite_runtime_needs_repair(context=None) -> bool:
    del context
    try:
        from . import ui_runtime as _ui_runtime
        needs_repair = getattr(_ui_runtime, 'runtime_needs_refresh', None)
        if callable(needs_repair):
            return bool(needs_repair())
    except Exception:
        return False
    return False


def _sssuite_runtime_has_live_hosts() -> bool:
    return False


_SSSUITE_REPAIR_TIMER_ATTEMPTS = 0


def _sssuite_runtime_repair_timer():
    global _SSSUITE_REPAIR_TIMER_ATTEMPTS
    try:
        _sssuite_repair_runtime(bpy.context)
    except Exception:
        pass

    if not _sssuite_runtime_needs_repair(bpy.context):
        _SSSUITE_REPAIR_TIMER_ATTEMPTS = 0
        return None

    _SSSUITE_REPAIR_TIMER_ATTEMPTS -= 1
    if _SSSUITE_REPAIR_TIMER_ATTEMPTS > 0:
        return 0.25
    return None


def _schedule_runtime_repair(attempts: int = 1) -> None:
    global _SSSUITE_REPAIR_TIMER_ATTEMPTS
    attempts = max(int(attempts), 0)
    if attempts <= 0 or not _sssuite_runtime_needs_repair(bpy.context):
        _SSSUITE_REPAIR_TIMER_ATTEMPTS = 0
        try:
            if bpy.app.timers.is_registered(_sssuite_runtime_repair_timer):
                bpy.app.timers.unregister(_sssuite_runtime_repair_timer)
        except Exception:
            pass
        return
    _SSSUITE_REPAIR_TIMER_ATTEMPTS = max(attempts, int(_SSSUITE_REPAIR_TIMER_ATTEMPTS), 0)
    try:
        if not bpy.app.timers.is_registered(_sssuite_runtime_repair_timer):
            bpy.app.timers.register(_sssuite_runtime_repair_timer, first_interval=0.05)
    except Exception:
        pass


# Safe import order to avoid circular imports.
import importlib as _safe_lazy_importlib


class _SUITE_LazyModuleProxy:
    __slots__ = ('_alias', '_relative_name')

    def __init__(self, alias: str, relative_name: str):
        self._alias = str(alias or '').strip()
        self._relative_name = str(relative_name or '').strip().strip('.')

    def _load(self):
        current = globals().get(self._alias)
        if not isinstance(current, _SUITE_LazyModuleProxy):
            return current
        module = _safe_lazy_importlib.import_module(f"{__package__}.{self._relative_name}")
        globals()[self._alias] = module
        return module

    def __getattr__(self, name):
        return getattr(self._load(), name)

    def __dir__(self):
        try:
            return dir(self._load())
        except Exception:
            return []


def _safe_lazy_module_proxy(alias: str, relative_name: str):
    return _SUITE_LazyModuleProxy(alias, relative_name)


translation = _safe_lazy_module_proxy('translation', 'translation_data')
preferences = _safe_lazy_module_proxy('preferences', 'preferences')
ui = _safe_lazy_module_proxy('ui', 'ui')
tool_runtime = _safe_lazy_module_proxy('tool_runtime', 'tool_runtime')
always_on = _safe_lazy_module_proxy('always_on', 'always_on')
icons = _safe_lazy_module_proxy('icons', 'icons')
selection_sets = _safe_lazy_module_proxy('selection_sets', 'selection_sets')
ark_face = _safe_lazy_module_proxy('ark_face', 'ark_face')

modules = [
    preferences,
    always_on,
    icons,
    selection_sets,
    tool_runtime,
    ui,
    ark_face,
]


def ensure_runtime_initialized(context=None, *args, force: bool = False, **kwargs):
    del args, kwargs
    global _SSSUITE_RUNTIME_REGISTERED

    if not _SSSUITE_RUNTIME_REGISTERED:
        if not _sssuite_can_register() and _sssuite_get_owner() != __package__:
            return False
        try:
            register()
        except Exception:
            return False

    try:
        _sssuite_repair_runtime(context or bpy.context)
    except Exception:
        pass

    if force:
        _schedule_runtime_repair(attempts=2)
    return bool(_SSSUITE_RUNTIME_REGISTERED)





def _sssuite_workspace_owner_id() -> str:
    return str(__package__ or __name__.split('.', 1)[0] or 'smart_selector_suite').strip()


def _sssuite_workspace_key_from_manager(module, workspace) -> str:
    try:
        func = getattr(module, '_workspace_key_from_name', None)
        if callable(func):
            key = str(func(getattr(workspace, 'name', '') or '') or '').strip().upper()
            if key:
                return key
    except Exception:
        pass
    try:
        return str(getattr(workspace, 'name', '') or '').strip().upper().replace(' ', '_')
    except Exception:
        return ''


def _sssuite_manager_rule_enabled_for_workspace(module, workspace_key: str) -> bool:
    if module is None or not workspace_key:
        return False
    try:
        load = getattr(module, '_load_settings', None)
        data = load() if callable(load) else {}
        rules = data.get('rules') if isinstance(data, dict) else {}
        workspace_rules = rules.get(workspace_key) if isinstance(rules, dict) else {}
        if not isinstance(workspace_rules, dict):
            return False
        for editor_rules in workspace_rules.values():
            if isinstance(editor_rules, dict) and bool(editor_rules.get('SMART_SELECTOR', False)):
                return True
    except Exception:
        pass
    return False


def _sssuite_ensure_workspace_owner_filter_for_manager(module) -> bool:
    """Ensure Blender's workspace owner filter can show Smart Selector panels.

    Smart Tools Manager controls visibility through WorkSpace.owner_ids.  If the
    Manager creates only its own category anchor, Blender can show a Smart
    Selector tab while the add-on's real Panel is hidden by owner filtering.
    Adding this add-on's owner ID for workspaces where the Manager rule enables
    SMART_SELECTOR makes the native category/header visible without modifying the
    Manager add-on files.
    """
    owner_id = _sssuite_workspace_owner_id()
    if not owner_id:
        return False
    changed = False
    try:
        workspaces = list(getattr(bpy.data, 'workspaces', ()) or ())
    except Exception:
        workspaces = []
    for workspace in workspaces:
        try:
            workspace_key = _sssuite_workspace_key_from_manager(module, workspace)
            if not _sssuite_manager_rule_enabled_for_workspace(module, workspace_key):
                continue
            try:
                if not bool(getattr(workspace, 'use_filter_by_owner', False)):
                    workspace.use_filter_by_owner = True
                    changed = True
            except Exception:
                pass
            owners = getattr(workspace, 'owner_ids', None)
            if owners is None:
                continue
            exists = False
            try:
                exists = owners.find(owner_id) >= 0
            except Exception:
                try:
                    exists = owners.get(owner_id) is not None
                except Exception:
                    exists = any(str(getattr(item, 'name', '') or '') == owner_id for item in owners)
            if not exists:
                try:
                    owners.new(owner_id)
                    changed = True
                except Exception:
                    try:
                        with bpy.context.temp_override(workspace=workspace):
                            bpy.ops.wm.owner_enable(owner_id=owner_id)
                        changed = True
                    except Exception:
                        pass
        except Exception:
            pass
    return changed


def _sssuite_is_own_native_panel(panel_cls) -> bool:
    """Return True only for Smart Selector's real Sidebar panels.

    Smart Tools Manager is allowed to manage every other Smart Tool normally.
    Smart Selector owns one native Panel per Blender space and must not be
    wrapped or proxied, because replacing a registered Panel callback after its
    category is open can leave Blender's C-side panel handler with a stale
    callback and can also produce an active category with an empty body.
    """
    if panel_cls is None:
        return False
    try:
        cls_module = str(getattr(panel_cls, '__module__', '') or '').lower()
        cls_id = str(getattr(panel_cls, 'bl_idname', '') or '').lower()
        cls_name = str(getattr(panel_cls, '__name__', '') or '')
        category = str(getattr(panel_cls, 'bl_category', '') or '')
    except Exception:
        return False
    if 'smart_selector_suite' not in cls_module:
        return False
    return bool(
        cls_name.startswith('SSSUITE_PT_root_')
        or 'smart_selector_suite_root' in cls_id
        or (
            category == 'Smart Selector'
            and bool(getattr(panel_cls, '_smart_tools_manager_source_panel_is_native', False))
        )
    )


def _sssuite_mark_manager_guard(wrapper, kind: str):
    try:
        setattr(wrapper, '_sssuite_manager_guard', True)
        setattr(wrapper, '_sssuite_manager_guard_kind', str(kind or ''))
        setattr(wrapper, '_sssuite_manager_guard_owner', str(__package__ or __name__))
    except Exception:
        pass
    return wrapper


def _sssuite_install_manager_guard(module, attribute: str, factory) -> bool:
    """Install or refresh one reversible runtime guard on Manager."""
    try:
        current = getattr(module, attribute, None)
    except Exception:
        return False
    if not callable(current):
        return False
    try:
        if bool(getattr(current, '_sssuite_manager_guard', False)):
            return False
    except Exception:
        pass
    original_name = f'_sssuite_original_{attribute}'
    # importlib.reload() may redefine Manager functions while leaving custom
    # module attributes intact. In that case update the saved original to the
    # newly defined unguarded function before wrapping it again.
    try:
        setattr(module, original_name, current)
    except Exception:
        return False
    try:
        wrapper = factory(current)
        _sssuite_mark_manager_guard(wrapper, attribute)
        setattr(module, attribute, wrapper)
        return True
    except Exception:
        return False


def _sssuite_repair_native_panels() -> int:
    try:
        from . import ui as _sssuite_ui
        repair = getattr(_sssuite_ui, 'repair_native_npanel_classes', None)
        if callable(repair):
            return int(repair() or 0)
    except Exception:
        pass
    return 0


def _sssuite_manager_has_selector_patches(module) -> bool:
    try:
        patches = getattr(module, '_panel_patches', None)
        if isinstance(patches, dict):
            for panel_cls, patch in tuple(patches.items()):
                try:
                    tool_key = patch[2] if len(patch) > 2 else ''
                except Exception:
                    tool_key = ''
                if str(tool_key or '') == 'SMART_SELECTOR' or _sssuite_is_own_native_panel(panel_cls):
                    return True
    except Exception:
        pass
    try:
        proxies = getattr(module, '_panel_proxy_classes', None)
        values = tuple(proxies.values()) if isinstance(proxies, dict) else ()
        for panel_cls in values:
            if str(getattr(panel_cls, '_smart_tools_manager_tool_key', '') or '') == 'SMART_SELECTOR':
                return True
    except Exception:
        pass
    return False


def _sssuite_patch_smart_tools_manager_context_policy() -> bool:
    """Keep Smart Selector native panels independent from Manager proxies.

    The Manager's workspace/editor rules remain authoritative through Blender's
    workspace-owner filter and Smart Selector's own poll path. Only Manager's
    attempt to replace or proxy Smart Selector's already registered Panel
    callbacks is blocked. Smart Tools Manager files are never edited.
    """
    import sys

    modules = []
    try:
        for name, module in tuple(sys.modules.items()):
            lname = str(name or '').lower()
            if lname.endswith('smart_tools_manager.manager') or lname.endswith('smart_tools_manager'):
                if module is not None and module not in modules:
                    modules.append(module)
    except Exception:
        modules = []

    found_manager = False
    needs_native_repair = False
    for module in modules:
        found_manager = True
        guards_changed = False
        selector_wrapped = _sssuite_manager_has_selector_patches(module)

        try:
            object_tools = getattr(module, '_OBJECT_CONTEXT_PANEL_TOOLS', None)
            if not hasattr(module, '_sssuite_original_object_context_panel_tools'):
                try:
                    setattr(module, '_sssuite_original_object_context_panel_tools', set(object_tools or ()))
                except Exception:
                    pass
            if isinstance(object_tools, set) and 'SMART_SELECTOR' in object_tools:
                object_tools.discard('SMART_SELECTOR')
                guards_changed = True
            elif isinstance(object_tools, (list, tuple)) and 'SMART_SELECTOR' in object_tools:
                setattr(module, '_OBJECT_CONTEXT_PANEL_TOOLS', set(object_tools) - {'SMART_SELECTOR'})
                guards_changed = True
        except Exception:
            pass

        try:
            _sssuite_ensure_workspace_owner_filter_for_manager(module)
        except Exception:
            pass

        # Remove wrappers/proxies only when they actually exist. Repeating
        # Manager-wide cache resets from every Panel draw would itself cause UI
        # latency, so the stable path below is intentionally a no-op.
        if selector_wrapped:
            try:
                unpatch_tool = getattr(module, '_unpatch_tool_panels', None)
                if callable(unpatch_tool):
                    unpatch_tool('SMART_SELECTOR')
            except Exception:
                pass
            try:
                remove_proxies = getattr(module, '_remove_panel_proxies', None)
                if callable(remove_proxies):
                    remove_proxies('SMART_SELECTOR')
            except Exception:
                pass
            needs_native_repair = True

        def _make_tool_key_guard(original):
            def _guard(panel_cls, *args, **kwargs):
                if _sssuite_is_own_native_panel(panel_cls):
                    return None
                return original(panel_cls, *args, **kwargs)
            return _guard

        def _make_patch_panel_guard(original):
            def _guard(panel_cls, tool_key, *args, **kwargs):
                if _sssuite_is_own_native_panel(panel_cls):
                    return None
                return original(panel_cls, tool_key, *args, **kwargs)
            return _guard

        def _make_sync_proxy_guard(original):
            def _guard(tool_panel_classes=None, *args, **kwargs):
                if isinstance(tool_panel_classes, dict) and 'SMART_SELECTOR' in tool_panel_classes:
                    tool_panel_classes = dict(tool_panel_classes)
                    tool_panel_classes.pop('SMART_SELECTOR', None)
                return original(tool_panel_classes, *args, **kwargs)
            return _guard

        def _make_ensure_filters_guard(original, _module=module):
            def _guard(*args, **kwargs):
                had_selector_wrappers = _sssuite_manager_has_selector_patches(_module)
                if had_selector_wrappers:
                    try:
                        unpatch = getattr(_module, '_unpatch_tool_panels', None)
                        if callable(unpatch):
                            unpatch('SMART_SELECTOR')
                    except Exception:
                        pass
                result = original(*args, **kwargs)
                if _sssuite_manager_has_selector_patches(_module):
                    try:
                        unpatch = getattr(_module, '_unpatch_tool_panels', None)
                        if callable(unpatch):
                            unpatch('SMART_SELECTOR')
                    except Exception:
                        pass
                    _sssuite_repair_native_panels()
                elif had_selector_wrappers:
                    _sssuite_repair_native_panels()
                return result
            return _guard

        guards_changed |= _sssuite_install_manager_guard(module, '_tool_key_for_panel_class', _make_tool_key_guard)
        guards_changed |= _sssuite_install_manager_guard(module, '_patch_panel_class', _make_patch_panel_guard)
        guards_changed |= _sssuite_install_manager_guard(module, '_sync_panel_proxies', _make_sync_proxy_guard)
        guards_changed |= _sssuite_install_manager_guard(module, '_ensure_panel_filters', _make_ensure_filters_guard)

        if guards_changed or selector_wrapped:
            for cache_name in ('_panel_tool_key_cache', '_tool_panel_space_types_cache'):
                cache = getattr(module, cache_name, None)
                if hasattr(cache, 'clear'):
                    try:
                        cache.clear()
                    except Exception:
                        pass
            ensure = getattr(module, '_ensure_panel_filters', None)
            if callable(ensure):
                try:
                    ensure(refresh_modules=True, register_proxies=True)
                except TypeError:
                    try:
                        ensure(refresh_modules=True)
                    except Exception:
                        pass
                except Exception:
                    pass
            needs_native_repair = True

    if needs_native_repair:
        _sssuite_repair_native_panels()
    return found_manager


def _sssuite_restore_smart_tools_manager_context_policy() -> None:
    """Undo only this add-on's runtime monkey patches on unregister."""
    import sys

    modules = []
    try:
        for name, module in tuple(sys.modules.items()):
            lname = str(name or '').lower()
            if lname.endswith('smart_tools_manager.manager') or lname.endswith('smart_tools_manager'):
                if module is not None and module not in modules:
                    modules.append(module)
    except Exception:
        modules = []

    guarded_names = (
        '_ensure_panel_filters',
        '_sync_panel_proxies',
        '_patch_panel_class',
        '_tool_key_for_panel_class',
    )
    for module in modules:
        try:
            unpatch = getattr(module, '_unpatch_tool_panels', None)
            if callable(unpatch):
                unpatch('SMART_SELECTOR')
        except Exception:
            pass
        for attribute in guarded_names:
            original_name = f'_sssuite_original_{attribute}'
            try:
                current = getattr(module, attribute, None)
                original = getattr(module, original_name, None)
                if callable(original) and bool(getattr(current, '_sssuite_manager_guard', False)):
                    setattr(module, attribute, original)
                if hasattr(module, original_name):
                    delattr(module, original_name)
            except Exception:
                pass
        try:
            original_object_tools = getattr(module, '_sssuite_original_object_context_panel_tools', None)
            if original_object_tools is not None:
                setattr(module, '_OBJECT_CONTEXT_PANEL_TOOLS', set(original_object_tools))
                delattr(module, '_sssuite_original_object_context_panel_tools')
        except Exception:
            pass
        for cache_name in ('_panel_tool_key_cache', '_tool_panel_space_types_cache'):
            cache = getattr(module, cache_name, None)
            if hasattr(cache, 'clear'):
                try:
                    cache.clear()
                except Exception:
                    pass
        try:
            schedule = getattr(module, '_schedule_panel_filter_refresh', None)
            if callable(schedule):
                schedule(refresh_modules=True, delay=0.10, register_proxies=True)
        except Exception:
            pass


_SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS = 0


def _sssuite_manager_patch_timer():
    global _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS
    patched = _sssuite_patch_smart_tools_manager_context_policy()
    _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS -= 1
    if patched:
        _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS = 0
        return None
    return 1.0 if _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS > 0 else None


def _sssuite_schedule_manager_patch_attempts(attempts: int = 90) -> None:
    global _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS
    _SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS = max(int(attempts), int(_SSSUITE_MANAGER_PATCH_TIMER_ATTEMPTS), 0)
    try:
        if not bpy.app.timers.is_registered(_sssuite_manager_patch_timer):
            bpy.app.timers.register(_sssuite_manager_patch_timer, first_interval=0.10, persistent=False)
    except Exception:
        pass

def register():
    global _SSSUITE_RUNTIME_REGISTERED

    if not _sssuite_can_register():
        return
    if _SSSUITE_RUNTIME_REGISTERED:
        _prime_preferences_subgroups(bpy.context)
        if _sssuite_runtime_has_live_hosts():
            try:
                _sssuite_repair_runtime(bpy.context)
            except Exception:
                pass
            if _sssuite_runtime_needs_repair(bpy.context):
                _schedule_runtime_repair(attempts=1)
        return

    try:
        _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
    except Exception:
        pass

    registered_modules = []
    translations_registered = False
    scene_props_registered = False
    try:
        _register_scene_properties()
        scene_props_registered = True

        for mod in modules:
            if hasattr(mod, "register"):
                mod.register()
                registered_modules.append(mod)

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, translation.blender_translations)
        translations_registered = True

        _prime_preferences_subgroups(bpy.context)
        try:
            from . import always_on as _always_on
            _always_on.apply_all(bpy.context)
        except Exception:
            pass
        _sssuite_patch_smart_tools_manager_context_policy()
        # Smart Tools Manager now owns its own event-driven panel repair.  A
        # long retry loop here kept a timer alive for 90 seconds even when all
        # Smart Selector runtime switches were disabled.
        _SSSUITE_RUNTIME_REGISTERED = True
        if _sssuite_runtime_has_live_hosts() and _sssuite_runtime_needs_repair(bpy.context):
            _schedule_runtime_repair(attempts=1)
    except Exception:
        if translations_registered:
            try:
                bpy.app.translations.unregister(__name__)
            except Exception:
                pass
        for mod in reversed(registered_modules):
            if hasattr(mod, "unregister"):
                try:
                    mod.unregister()
                except Exception:
                    pass
        if scene_props_registered:
            _unregister_scene_properties()
        _SSSUITE_RUNTIME_REGISTERED = False
        _sssuite_clear_owner(__package__)
        raise


def unregister():
    global _SSSUITE_RUNTIME_REGISTERED

    # Only the owner should unregister shared handlers/keymaps.
    if _sssuite_get_owner() not in (None, __package__):
        return
    try:
        try:
            if bpy.app.timers.is_registered(_sssuite_runtime_repair_timer):
                bpy.app.timers.unregister(_sssuite_runtime_repair_timer)
        except Exception:
            pass
        try:
            if bpy.app.timers.is_registered(_sssuite_manager_patch_timer):
                bpy.app.timers.unregister(_sssuite_manager_patch_timer)
        except Exception:
            pass

        _stop_browser_server()

        # Integrated tools may also be materialized directly by Blender-side
        # recovery/restore paths instead of through ``loader`` records.  Always
        # tear down a loaded Collection Manager package here so a subsequent
        # add-on disable cannot leave its RNA classes or Scene pointer behind.
        try:
            _collection_manager = _sys.modules.get(f'{__package__}.collection_manager')
            _collection_manager_unregister = getattr(_collection_manager, 'unregister', None)
            if callable(_collection_manager_unregister):
                _collection_manager_unregister()
        except Exception:
            pass

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass

        for mod in reversed(modules):
            if hasattr(mod, "unregister"):
                try:
                    mod.unregister()
                except Exception:
                    pass

        try:
            _sssuite_restore_smart_tools_manager_context_policy()
        except Exception:
            pass

        _unregister_scene_properties()
        _SSSUITE_RUNTIME_REGISTERED = False
    finally:
        _sssuite_clear_owner(__package__)


# SUITE_TOOLTIP_AUDIT_WRAPPER_DISABLED


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')


def register():
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        if _SMART_COMMON is not None:
            _SMART_COMMON.register()
    finally:
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass


def unregister():
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.unregister()
        except Exception:
            pass
    if callable(_SMART_ORIGINAL_UNREGISTER):
        _SMART_ORIGINAL_UNREGISTER()
# --- Smart common extension patch END ---


# --- JELararagi shared single-slot status integration v2 ---
try:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = register
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = unregister
except Exception:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = None
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = None


def _jel_status_instrument_class_v2(cls):
    try:
        from . import status_runtime as _jel_status_runtime_v2
        return _jel_status_runtime_v2.instrument_operator_class(
            cls, 'smart_selector_suite', 'Smart Selector Suite'
        )
    except Exception:
        return cls


def register():
    if not callable(_JEL_STATUS_ORIGINAL_REGISTER_V2):
        return None
    try:
        import bpy as _jel_bpy_v2
        from . import status_runtime as _jel_status_runtime_v2
        _jel_original_register_class_v2 = _jel_bpy_v2.utils.register_class
    except Exception:
        _jel_bpy_v2 = None
        _jel_status_runtime_v2 = None
        _jel_original_register_class_v2 = None

    def _jel_register_class_v2(cls):
        _jel_status_instrument_class_v2(cls)
        return _jel_original_register_class_v2(cls)

    if _jel_bpy_v2 is not None and callable(_jel_original_register_class_v2):
        try:
            _jel_bpy_v2.utils.register_class = _jel_register_class_v2
        except Exception:
            pass
    try:
        if _jel_status_runtime_v2 is not None:
            with _jel_status_runtime_v2.capture_registration_callbacks('smart_selector_suite', 'Smart Selector Suite'):
                result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
        else:
            result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
    finally:
        if _jel_bpy_v2 is not None and callable(_jel_original_register_class_v2):
            try:
                _jel_bpy_v2.utils.register_class = _jel_original_register_class_v2
            except Exception:
                pass
    try:
        if _jel_status_runtime_v2 is None:
            from . import status_runtime as _jel_status_runtime_v2
        _jel_status_runtime_v2.instrument_loaded_package_operators(
            'smart_selector_suite', 'smart_selector_suite', 'Smart Selector Suite'
        )
        _jel_status_runtime_v2.instrument_loaded_package_handlers(
            'smart_selector_suite', 'smart_selector_suite', 'Smart Selector Suite'
        )
    except Exception:
        pass
    return result


def unregister():
    try:
        from . import status_runtime as _jel_status_runtime_v2
        # Restore the package's original handler function objects first so its
        # own unregister() routine can remove them by identity.
        _jel_status_runtime_v2.restore_package_handlers('smart_selector_suite')
    except Exception:
        _jel_status_runtime_v2 = None
    try:
        if callable(_JEL_STATUS_ORIGINAL_UNREGISTER_V2):
            if _jel_status_runtime_v2 is not None:
                with _jel_status_runtime_v2.capture_runtime_resources('smart_selector_suite', 'Smart Selector Suite'):
                    return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()
            return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()
        return None
    finally:
        try:
            if _jel_status_runtime_v2 is None:
                from . import status_runtime as _jel_status_runtime_v2
            _jel_status_runtime_v2.clear_prefix('smart_selector_suite')
        except Exception:
            pass
# --- JELararagi shared single-slot status integration v2 --- END

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
