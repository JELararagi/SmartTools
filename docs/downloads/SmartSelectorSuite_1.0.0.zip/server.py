import bpy
import threading
import http.server
import socketserver
import json
import os
import subprocess
import ctypes
import ctypes.wintypes
import time
import base64
import urllib.parse
import queue
import re
import secrets
from collections import deque
from . import utils

def _always_on_enabled(feature_key: str, default: bool=True) -> bool:
    try:
        from . import always_on
        return bool(always_on.is_feature_enabled(feature_key, default=default))
    except Exception:
        return bool(default)

def is_server_running() -> bool:
    return httpd is not None
current_port = 0
httpd = None
server_thread = None
global_blender_hwnd = 0
global_scene_objects = []
global_all_objects = []
global_selected_objects = []
global_active_obj = ''
global_shapekeys = {}
server_token = ''
state_rev = 0
_MAX_WATCHED_OBJECTS = 256
_MAX_WATCHED_KEYS_PER_OBJECT = 256
_MAX_WATCHED_TOTAL_KEYS = 4096
watched_shapekeys = {}
_watched_lock = threading.Lock()
_watched_dirty = True
_rpc_lock = threading.Lock()
_rpc_events = {}
_rpc_results = {}
_MAX_WATCHED_DATAPATHS = 256
_MAX_WATCHED_BONE_ARMATURES = 32
_MAX_SELECTED_BONES_PER_ARMATURE = 4096
_MAX_WATCH_NAME_LEN = 256
_MAX_WATCH_PATH_LEN = 512
_MAX_STATE_TEXT_LEN = 256
watched_datapaths = []
watched_bone_armatures = []
global_datapaths = {}
global_selected_bones = {}
_force_state_bump = False
_MAX_SCRIPT_RESULTS = 64
_MAX_SCRIPT_ERROR_LEN = 500
_TASK_ID_RE = re.compile('^[A-Za-z0-9_.:-]{1,64}$')
# Tasks whose outcome is published in /api/state script_results under the request id
# (scripts always; select / custom_prop only when they fail or warn).
_TASKS_WITH_RESULT = frozenset({'script', 'select', 'custom_prop'})
script_results = deque(maxlen=_MAX_SCRIPT_RESULTS)
_script_results_lock = threading.Lock()
_CUSTOM_PROP_FAILURE_REPEAT_S = 2.0
_last_custom_prop_failure = (None, 0.0)
_CUSTOM_PROP_GESTURE_ID_RE = re.compile('^[A-Za-z0-9_.:-]{1,64}$')
_custom_prop_undo_gestures = {}
_CUSTOM_PROP_GESTURE_IDLE_S = 1.0
_CUSTOM_PROP_VALUE_MISSING = object()
global_collections = []
global_armatures = []
global_mesh_objects = []
_dirty_objlist = True
_dirty_collections = True
_selection_dirty_event = threading.Event()
_selection_dirty_event.set()
_msgbus_owner = object()
_MAX_TASK_QUEUE_SIZE = 1024
_MAX_POST_BYTES = 8 * 1024 * 1024
task_queue = queue.Queue(maxsize=_MAX_TASK_QUEUE_SIZE)

def _bytes_response(handler, status: int, body: bytes=b'', content_type: str='') -> bool:
    """Write and flush one framed response; callers can observe transport failure."""
    try:
        body = bytes(body or b'')
        handler.send_response(int(status))
        if content_type:
            handler.send_header('Content-type', str(content_type))
        handler.send_header('Cache-Control', 'no-store')
        handler.send_header('Content-Length', str(len(body)))
        handler.end_headers()
        if body:
            handler.wfile.write(body)
        handler.wfile.flush()
        return True
    except Exception:
        return False

def _json_response(handler, status: int, payload=None) -> bool:
    body = b'' if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
    return _bytes_response(handler, status, body, 'application/json; charset=utf-8')

def _empty_response(handler, status: int=200) -> bool:
    return _bytes_response(handler, status, b'')

def _read_raw_body(handler, max_bytes: int=_MAX_POST_BYTES):
    raw_len = handler.headers.get('Content-Length', '0')
    try:
        content_length = int(raw_len or 0)
    except Exception:
        return ('', (400, {'error': 'invalid_content_length'}))
    if content_length < 0:
        return ('', (400, {'error': 'invalid_content_length'}))
    if content_length > max_bytes:
        return ('', (413, {'error': 'payload_too_large'}))
    try:
        raw = handler.rfile.read(content_length) if content_length > 0 else b''
        return (raw.decode('utf-8'), None)
    except UnicodeDecodeError as exc:
        return ('', (400, {'error': 'invalid_utf8', 'detail': str(exc)}))
    except Exception as exc:
        return ('', (400, {'error': 'body_read_failed', 'detail': str(exc)}))

def _read_json_body(handler):
    body, err = _read_raw_body(handler)
    if err:
        return ({}, err)
    try:
        data = json.loads(body or '{}')
    except Exception as exc:
        return ({}, (400, {'error': 'invalid_json', 'detail': str(exc)}))
    if data is None:
        data = {}
    if not isinstance(data, dict):
        return ({}, (400, {'error': 'json_object_required'}))
    return (data, None)

def _queue_task(handler, task_type: str, data=None):
    payload = data if isinstance(data, dict) else {}
    if not _always_on_enabled('smart_selector_browser_server', True):
        _json_response(handler, 503, {'error': 'browser_server_disabled'})
        return False
    if not _always_on_enabled('smart_selector_task_queue_timer', True):
        _json_response(handler, 503, {'error': 'task_queue_disabled'})
        return False
    task_id = _task_request_id(payload) if str(task_type) in _TASKS_WITH_RESULT else ''
    try:
        task_queue.put_nowait((str(task_type), payload, task_id))
    except queue.Full:
        _json_response(handler, 429, {'error': 'task_queue_full'})
        return False
    response = {'ok': True}
    if task_id:
        response['id'] = task_id
    _json_response(handler, 200, response)
    return True

def _task_request_id(payload: dict) -> str:
    """Use the browser's request id when it is well formed, otherwise make one."""
    raw = payload.get('id')
    if isinstance(raw, str) and _TASK_ID_RE.fullmatch(raw):
        return raw
    return 'srv' + secrets.token_hex(8)

def _drain_task_queue():
    """Main thread (queue timer disabled): drop waiting tasks, recording each dropped request as a failure."""
    while True:
        try:
            item = task_queue.get_nowait()
        except queue.Empty:
            break
        except Exception:
            break
        if len(item) >= 3 and item[2]:
            _record_script_result(item[2], False, 'task_queue_disabled', 'task_queue_disabled')

def _payload_bool(value, default: bool=False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {'1', 'true', 'yes', 'on', 'y'}:
            return True
        if text in {'0', 'false', 'no', 'off', 'n', 'none', 'null', ''}:
            return False
    return bool(default)

def _payload_string_list(value):
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, (list, tuple, set)):
        out = []
        for item in value:
            text = str(item).strip()
            if text:
                out.append(text)
        return out
    text = str(value).strip()
    return [text] if text else []

def _normalize_watched_shapekeys(value) -> dict[str, set[str]]:
    """Normalize browser watch input into a deterministic bounded cache."""
    if not isinstance(value, dict):
        return {}
    normalized: dict[str, set[str]] = {}
    total_keys = 0
    for raw_object_name, raw_keys in value.items():
        if len(normalized) >= _MAX_WATCHED_OBJECTS or total_keys >= _MAX_WATCHED_TOTAL_KEYS:
            break
        object_name = str(raw_object_name or '').strip()
        if not object_name or object_name in normalized:
            continue
        keys: set[str] = set()
        for raw_key in _payload_string_list(raw_keys):
            key_name = str(raw_key or '').strip()
            if not key_name or key_name in keys:
                continue
            keys.add(key_name)
            total_keys += 1
            if len(keys) >= _MAX_WATCHED_KEYS_PER_OBJECT or total_keys >= _MAX_WATCHED_TOTAL_KEYS:
                break
        if keys:
            normalized[object_name] = keys
    return normalized

def _normalize_watched_datapaths(value):
    """Validate browser datapath watch entries into a bounded, de-duplicated (obj, path) list.

    Returns (entries, rejected_count). Paths follow the set_custom_prop rule
    (utils.is_safe_data_path: non-empty, no ';' / CR / LF).
    """
    if not isinstance(value, (list, tuple)):
        return ([], 0)
    entries = []
    seen = set()
    rejected = 0
    for item in value:
        if len(entries) >= _MAX_WATCHED_DATAPATHS or not isinstance(item, dict):
            rejected += 1
            continue
        obj_name = str(item.get('obj') or '').strip()
        path = str(item.get('path') or '').strip()
        if not obj_name or len(obj_name) > _MAX_WATCH_NAME_LEN or len(path) > _MAX_WATCH_PATH_LEN or (not utils.is_safe_data_path(path)):
            rejected += 1
            continue
        key = (obj_name, path)
        if key not in seen:
            seen.add(key)
            entries.append(key)
    return (entries, rejected)

def _normalize_watched_bone_armatures(value) -> list:
    """Bounded, de-duplicated list of armature object names whose selected pose bones are published."""
    out = []
    for name in _payload_string_list(value):
        if len(out) >= _MAX_WATCHED_BONE_ARMATURES:
            break
        if len(name) <= _MAX_WATCH_NAME_LEN and name not in out:
            out.append(name)
    return out

def _script_results_snapshot() -> list:
    with _script_results_lock:
        return list(script_results)

def _record_script_result(task_id: str, ok: bool, code: str='', error: str=''):
    """Main thread: store one execute_script outcome and publish it through /api/state."""
    global state_rev
    if not task_id:
        return
    entry = {'id': str(task_id), 'ok': bool(ok), 'code': str(code or ''), 'error': str(error or '')[:_MAX_SCRIPT_ERROR_LEN], 't': round(time.time(), 3)}
    with _script_results_lock:
        script_results.append(entry)
    state_rev += 1

def _operator_error_text(exc) -> str:
    """bpy.ops raises RuntimeError('Error: <report>') for an operator ERROR report; keep the report text."""
    text = str(exc or '').strip()
    if text.startswith('Error: '):
        text = text[len('Error: '):].strip()
    return text

def _run_operator_task(op, data: dict):
    """Main thread: run one bridge operator and return (ok, code, error) instead of hiding the outcome.

    bpy.ops keeps an operator's reports private: an ERROR report comes back as RuntimeError, a WARNING
    only reaches the system console. The bridge operators therefore also note their WARNING text in
    utils (note_bridge_warning), taken here. FINISHED with a warning -> (True, 'warning', text);
    CANCELLED -> (False, 'cancelled', warning text or 'cancelled').
    """
    utils.reset_bridge_warnings()
    try:
        result = op('EXEC_DEFAULT', payload=json.dumps(data))
    except RuntimeError as exc:
        utils.reset_bridge_warnings()
        # ERROR report (or a failed poll), raised by bpy.ops as RuntimeError.
        return (False, 'error', _operator_error_text(exc) or 'error')
    except Exception as exc:
        utils.reset_bridge_warnings()
        return (False, 'error', f'{type(exc).__name__}: {exc}')
    warning = utils.take_bridge_warnings()
    if 'FINISHED' in (result or set()):
        return (True, 'warning' if warning else '', warning)
    return (False, 'cancelled', warning or 'cancelled')

def _history_override():
    """Return only stable UI context members for ed.undo_push.

    Scene and view-layer references are intentionally omitted because Undo
    replaces datablocks and would leave those override members stale.
    """
    ctx_dict = get_view3d_context()
    if not ctx_dict:
        return None
    return {key: ctx_dict[key] for key in ('window', 'screen', 'area', 'region') if ctx_dict.get(key) is not None}

def _browser_undo_push_available() -> bool:
    if bool(getattr(bpy.app, 'background', False)):
        return False
    try:
        ctx_dict = _history_override()
        if ctx_dict:
            with bpy.context.temp_override(**ctx_dict):
                return bool(bpy.ops.ed.undo_push.poll())
        return bool(bpy.ops.ed.undo_push.poll())
    except Exception:
        return False

def _push_browser_undo_step(message: str) -> bool:
    """Commit the already-applied browser mutation as one global Undo state."""
    try:
        ctx_dict = _history_override()
        if ctx_dict:
            with bpy.context.temp_override(**ctx_dict):
                if not bpy.ops.ed.undo_push.poll():
                    return False
                result = bpy.ops.ed.undo_push(message=str(message or 'Smart Selector Browser'))
        else:
            if not bpy.ops.ed.undo_push.poll():
                return False
            result = bpy.ops.ed.undo_push(message=str(message or 'Smart Selector Browser'))
        return 'FINISHED' in (result or set())
    except Exception:
        return False

def _custom_prop_value(data: dict):
    obj = bpy.data.objects.get(str(data.get('obj') or ''))
    path = str(data.get('path') or '')
    if obj is None or not path:
        return _CUSTOM_PROP_VALUE_MISSING
    try:
        return utils.read_data_path_value(obj, path, max_text=_MAX_STATE_TEXT_LEN)
    except Exception:
        return _CUSTOM_PROP_VALUE_MISSING

def _custom_prop_gesture_id(data: dict) -> str:
    value = str(data.get('gesture_id') or '')
    return value if _CUSTOM_PROP_GESTURE_ID_RE.fullmatch(value) else ''

def _commit_pending_custom_prop_gestures(except_id: str='', *, expired_only: bool=False, now=None):
    """Close prior gesture boundaries before another operation can mutate state.

    The task timer also calls this with ``expired_only`` so a lost browser final
    event cannot retain a changed gesture indefinitely.  Entries are removed on
    both success and explicit push failure; the latter blocks the later mutation
    rather than silently combining its state with an uncommitted gesture.
    """
    current = time.monotonic() if now is None else float(now)
    for gesture_id, state in list(_custom_prop_undo_gestures.items()):
        if gesture_id == except_id:
            continue
        if expired_only and current - state['updated_at'] < _CUSTOM_PROP_GESTURE_IDLE_S:
            continue
        _custom_prop_undo_gestures.pop(gesture_id, None)
        if state['changed'] and not _push_browser_undo_step('Smart Selector Browser Property'):
            return (False, 'undo_push_failed', 'pending browser property gesture could not be committed')
    return (True, '', '')

def _run_custom_prop_task(data: dict):
    """Apply one datapath update and create exactly one history step per operation/gesture.

    Standalone requests commit immediately. Slider input requests share a
    gesture id and commit only on the final event. Failed/no-op writes never
    create history. A gesture id may never combine different targets.
    """
    gesture_id = _custom_prop_gesture_id(data)
    gesture_final = _payload_bool(data.get('gesture_final', False), False)
    target = (str(data.get('obj') or ''), str(data.get('path') or ''))
    state = _custom_prop_undo_gestures.get(gesture_id) if gesture_id else None
    if state is not None and state['target'] != target:
        return (False, 'mixed_gesture_target', 'gesture_id may batch only one object and data path')
    boundary_ok, boundary_code, boundary_error = _commit_pending_custom_prop_gestures(except_id=gesture_id)
    if not boundary_ok:
        return (boundary_ok, boundary_code, boundary_error)
    if state is None:
        if not _browser_undo_push_available():
            return (False, 'undo_unavailable', 'global Undo is unavailable in the current Blender context')
        state = {'target': target, 'changed': False, 'updated_at': time.monotonic()}
        if gesture_id:
            _custom_prop_undo_gestures[gesture_id] = state
    else:
        state['updated_at'] = time.monotonic()

    before = _custom_prop_value(data)
    ok, code, error = _run_operator_task(bpy.ops.smart_selector_suite.set_custom_prop, data)
    after = _custom_prop_value(data)
    changed = bool(ok and (before is _CUSTOM_PROP_VALUE_MISSING or after is _CUSTOM_PROP_VALUE_MISSING or before != after))
    state['changed'] = bool(state['changed'] or changed)

    should_commit = (not gesture_id) or gesture_final
    if should_commit:
        if state['changed'] and not _push_browser_undo_step('Smart Selector Browser Property'):
            if gesture_id:
                _custom_prop_undo_gestures.pop(gesture_id, None)
            return (False, 'undo_push_failed', 'browser property changed but its global Undo state could not be committed')
        if gesture_id:
            _custom_prop_undo_gestures.pop(gesture_id, None)
    return (ok, code, error)

def _custom_prop_failure_is_new(data: dict, code: str, error: str) -> bool:
    """A slider drag sends one task per input event; record one identical failure per (obj, path) every
    _CUSTOM_PROP_FAILURE_REPEAT_S so a refused drag does not push script results out of the ring."""
    global _last_custom_prop_failure
    key = (str(data.get('obj') or ''), str(data.get('path') or ''), str(code or ''), str(error or ''))
    now = time.monotonic()
    last_key, last_time = _last_custom_prop_failure
    if key == last_key and now - last_time < _CUSTOM_PROP_FAILURE_REPEAT_S:
        return False
    _last_custom_prop_failure = (key, now)
    return True

def _run_script_task(data: dict):
    """Main thread: run exec_script and return (ok, code, error) instead of hiding the failure."""
    prefs = utils.get_prefs()
    if prefs is not None and (not bool(getattr(prefs, 'enable_exec_script', True))):
        return (False, 'execute_script_disabled', 'execute_script_disabled')
    # The operator reports the script's exception as ERROR, which bpy.ops raises as RuntimeError.
    return _run_operator_task(bpy.ops.smart_selector_suite.exec_script, data)

def _mark_dirty_selection():
    _selection_dirty_event.set()

def _mark_watched_dirty():
    global _watched_dirty
    with _watched_lock:
        _watched_dirty = True

def _mark_all_state_dirty():
    _mark_dirty_selection()
    _mark_dirty_objlist()
    _mark_dirty_collections()
    _mark_watched_dirty()

def update_blender_state_cache():
    """Update cached Blender state on the main thread.

    Optimizations:
    - Selection uses bpy.context.selected_objects (no full view_layer scan)
    - Object list updates only when dirty (depsgraph/msgbus)
    - Shape key values update only for watched keys requested by UI
    - Watched datapaths and selected pose bones of watched armatures are read
      in the same watched pass (bounded lists registered through /api/watch)
    """
    if not _always_on_enabled('smart_selector_browser_server', True) or not _always_on_enabled('smart_selector_state_cache_timer', True):
        return None
    global global_all_objects, global_selected_objects, global_active_obj, global_shapekeys
    global global_collections, global_armatures, global_mesh_objects
    global global_datapaths, global_selected_bones, _force_state_bump
    global state_rev, _dirty_objlist, _dirty_collections, _watched_dirty
    try:
        prefs = utils.get_prefs()
        interval = float(getattr(prefs, 'state_update_interval', 0.5) or 0.5)
    except Exception:
        interval = 0.5
    interval = max(0.1, min(2.0, interval))
    try:
        if _selection_dirty_event.is_set():
            _selection_dirty_event.clear()
            sel = []
            active_name = ''
            try:
                sel = [o.name for o in bpy.context.selected_objects or []]
                a = bpy.context.view_layer.objects.active if bpy.context and bpy.context.view_layer else None
                active_name = a.name if a else ''
            except Exception:
                sel = global_selected_objects
                active_name = global_active_obj
                _selection_dirty_event.set()
            if sel != global_selected_objects or active_name != global_active_obj:
                global_selected_objects = sel
                global_active_obj = active_name
                state_rev += 1
        if _dirty_objlist:
            try:
                global_all_objects = list(bpy.data.objects.keys())
                global_armatures = [o.name for o in bpy.data.objects if o.type == 'ARMATURE']
                global_mesh_objects = [o.name for o in bpy.data.objects if o.type == 'MESH']
                _dirty_objlist = False
                state_rev += 1
            except Exception:
                pass
        if _dirty_collections:
            try:
                global_collections = list(bpy.data.collections.keys())
                _dirty_collections = False
                state_rev += 1
            except Exception:
                pass
        watched = {}
        watched_dp = []
        watched_arms = []
        watched_dirty = False
        with _watched_lock:
            watched_dirty = bool(_watched_dirty)
            if watched_dirty:
                if watched_shapekeys:
                    watched = {k: set(v) for k, v in watched_shapekeys.items()}
                watched_dp = list(watched_datapaths)
                watched_arms = list(watched_bone_armatures)
                _watched_dirty = False
        if watched_dirty:
            new_sk = {}
            if watched:
                for obj_name, keys in watched.items():
                    obj = bpy.data.objects.get(obj_name)
                    if not obj or obj.type != 'MESH':
                        continue
                    sk = getattr(obj.data, 'shape_keys', None)
                    if not sk:
                        continue
                    kb = sk.key_blocks
                    d = {}
                    for k in keys:
                        try:
                            block = kb.get(k)
                            if block is not None:
                                d[k] = float(block.value)
                        except Exception:
                            pass
                    if d:
                        new_sk[obj_name] = d
            if new_sk != global_shapekeys:
                global_shapekeys = new_sk
                state_rev += 1
            new_dp = {}
            for obj_name, path in watched_dp:
                obj = bpy.data.objects.get(obj_name)
                value = None
                if obj is not None:
                    try:
                        value = utils.read_data_path_value(obj, path, max_text=_MAX_STATE_TEXT_LEN)
                    except (ValueError, TypeError, KeyError, IndexError, AttributeError, ReferenceError):
                        # Published as null: the page shows "unknown" instead of guessing a state.
                        value = None
                new_dp.setdefault(obj_name, {})[path] = value
            if new_dp != global_datapaths:
                global_datapaths = new_dp
                state_rev += 1
            new_bones = {}
            for arm_name in watched_arms:
                arm = bpy.data.objects.get(arm_name)
                if arm is None or arm.type != 'ARMATURE' or arm.pose is None:
                    continue
                names = []
                for pb in arm.pose.bones:
                    if pb.select:
                        names.append(pb.name)
                        if len(names) >= _MAX_SELECTED_BONES_PER_ARMATURE:
                            break
                new_bones[arm_name] = names
            if new_bones != global_selected_bones:
                global_selected_bones = new_bones
                state_rev += 1
            if _force_state_bump:
                _force_state_bump = False
                state_rev += 1
    except Exception as e:
        pass
    return interval

def _safe_call_operator(op, *args, **kwargs):
    try:
        poll = getattr(op, 'poll', None)
        if callable(poll) and (not bool(poll())):
            return False
    except Exception:
        return False
    try:
        op(*args, **kwargs)
        return True
    except Exception as exc:
        try:
            pass
        except Exception:
            pass
        return False

def process_task_queue():
    global _force_state_bump
    if not _always_on_enabled('smart_selector_browser_server', True) or not _always_on_enabled('smart_selector_task_queue_timer', True):
        _drain_task_queue()
        return None
    _commit_pending_custom_prop_gestures(expired_only=True)
    while not task_queue.empty():
        try:
            task_type, data, task_id = task_queue.get_nowait()
            data = data if isinstance(data, dict) else {}
            if task_type == 'select':
                ok, code, error = _run_operator_task(bpy.ops.smart_selector_suite.apply_selection, data)
                if not ok or error:
                    # Only failures and warnings are recorded, so rapid clicks do not crowd the ring.
                    _record_script_result(task_id, ok, code, error)
                # Selection may change even when the operator ends CANCELLED; refresh objects and pose bones.
                _mark_dirty_selection()
                _mark_watched_dirty()
            elif task_type == 'script':
                ok, code, error = _run_script_task(data)
                _record_script_result(task_id, ok, code, error)
                _mark_all_state_dirty()
            elif task_type == 'shapekey':
                if _safe_call_operator(bpy.ops.smart_selector_suite.set_shapekey, 'EXEC_DEFAULT', payload=json.dumps(data)):
                    _mark_watched_dirty()
            elif task_type == 'custom_prop':
                ok, code, error = _run_custom_prop_task(data)
                if (not ok or error) and _custom_prop_failure_is_new(data, code, error):
                    _record_script_result(task_id, ok, code, error)
                # Publish the read-back value even when it equals the cached one (coerced or refused).
                _force_state_bump = True
                _mark_watched_dirty()
            elif task_type == 'timeline':
                exec_timeline(data)
                _mark_watched_dirty()
            elif task_type == 'camera':
                exec_camera(data)
            elif task_type == 'undo':
                if _safe_call_operator(bpy.ops.smart_selector_suite.blender_undo, 'EXEC_DEFAULT'):
                    _mark_all_state_dirty()
            elif task_type == 'redo':
                if _safe_call_operator(bpy.ops.smart_selector_suite.blender_redo, 'EXEC_DEFAULT'):
                    _mark_all_state_dirty()
            elif task_type == 'rpc':
                _exec_rpc(data)
        except queue.Empty:
            break
        except Exception as e:
            pass
    return 0.05

def _exec_rpc(data: dict):
    kind = (data or {}).get('kind', '')
    req_id = (data or {}).get('req_id', '')
    payload = (data or {}).get('payload', {}) or {}
    result = {}
    try:
        if kind == 'shapekey_keys':
            obj_name = str(payload.get('obj', '') or '')
            obj = bpy.data.objects.get(obj_name)
            keys = []
            if obj and obj.type == 'MESH':
                sk = getattr(obj.data, 'shape_keys', None)
                if sk:
                    keys = [kb.name for kb in sk.key_blocks]
            result = {'keys': keys}
        elif kind == 'bones_list':
            arm_name = str(payload.get('armature', '') or '')
            arm = bpy.data.objects.get(arm_name)
            bones = []
            if arm and arm.type == 'ARMATURE':
                bones = [b.name for b in arm.data.bones]
            result = {'bones': bones}
        elif kind == 'capture_selection':
            cap_kind = str(payload.get('cap_kind', '') or '')
            if cap_kind == 'bones':
                arm_name = str(payload.get('armature', '') or '')
                arm = bpy.data.objects.get(arm_name) if arm_name else bpy.context.active_object if bpy.context else None
                if arm and arm.type == 'ARMATURE' and arm.pose is not None:
                    # Blender 5.x: selection is PoseBone.select (Bone.select no longer exists).
                    result = {'bones': [pb.name for pb in arm.pose.bones if pb.select]}
                else:
                    result = {'bones': [], 'error': 'armature_not_found'}
            elif cap_kind == 'mesh_elems':
                obj_name = str(payload.get('object', '') or '')
                elem_mode = str(payload.get('elem_mode', 'VERT') or 'VERT').upper()
                obj = bpy.data.objects.get(obj_name) if obj_name else bpy.context.active_object if bpy.context else None
                indices = []
                note = ''
                if obj and obj.type == 'MESH':
                    if getattr(obj, 'mode', '') != 'EDIT' or bpy.context.active_object != obj:
                        note = 'Capture requires the target object to be active and in Edit Mode.'
                    else:
                        import bmesh
                        bm = bmesh.from_edit_mesh(obj.data)
                        # Sequence positions: exactly what apply_selection addresses after ensure_lookup_table().
                        if elem_mode == 'EDGE':
                            indices = [i for i, e in enumerate(bm.edges) if e.select]
                        elif elem_mode == 'FACE':
                            indices = [i for i, f in enumerate(bm.faces) if f.select]
                        else:
                            indices = [i for i, v in enumerate(bm.verts) if v.select]
                    result = {'indices': indices, 'note': note}
                else:
                    result = {'indices': [], 'note': '', 'error': 'mesh_not_found'}
        else:
            result = {'error': 'unknown_kind'}
    except Exception as e:
        result = {'error': str(e)}
    if req_id:
        _rpc_set_result(req_id, result)

def _mark_dirty_objlist():
    global _dirty_objlist
    _dirty_objlist = True

def _mark_dirty_collections():
    global _dirty_collections
    _dirty_collections = True

def _safe_handler_list(name: str):
    try:
        return getattr(bpy.app.handlers, str(name or ''), None)
    except Exception:
        return None

def _on_active_object_change():
    _mark_dirty_selection()

def _depsgraph_post_handler(*args):
    depsgraph = args[1] if len(args) > 1 else None
    _mark_dirty_selection()
    _mark_watched_dirty()
    try:
        if depsgraph is not None and hasattr(depsgraph, 'id_type_updated'):
            if depsgraph.id_type_updated('OBJECT'):
                _mark_dirty_objlist()
            if depsgraph.id_type_updated('COLLECTION'):
                _mark_dirty_collections()
        else:
            _mark_dirty_objlist()
            _mark_dirty_collections()
    except Exception:
        _mark_dirty_objlist()
        _mark_dirty_collections()

def register_state_listeners():
    """Register msgbus / handlers for cheap dirtiness tracking."""
    if not _always_on_enabled('smart_selector_browser_server', True) or not _always_on_enabled('smart_selector_state_watchers', True):
        unregister_state_listeners()
        return
    try:
        bpy.msgbus.clear_by_owner(_msgbus_owner)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(key=(bpy.types.LayerObjects, 'active'), owner=_msgbus_owner, args=(), notify=_on_active_object_change)
    except Exception:
        pass
    try:
        handlers = _safe_handler_list('depsgraph_update_post')
        if handlers is not None and _depsgraph_post_handler not in handlers:
            handlers.append(_depsgraph_post_handler)
    except Exception:
        pass

def unregister_state_listeners():
    try:
        bpy.msgbus.clear_by_owner(_msgbus_owner)
    except Exception:
        pass
    try:
        handlers = _safe_handler_list('depsgraph_update_post')
        if handlers is not None and _depsgraph_post_handler in handlers:
            handlers.remove(_depsgraph_post_handler)
    except Exception:
        pass

def register_state_cache_timer():
    if not _always_on_enabled('smart_selector_browser_server', True) or not _always_on_enabled('smart_selector_state_cache_timer', True):
        unregister_state_cache_timer()
        return
    try:
        if not bpy.app.timers.is_registered(update_blender_state_cache):
            bpy.app.timers.register(update_blender_state_cache)
    except Exception:
        pass

def unregister_state_cache_timer():
    try:
        if bpy.app.timers.is_registered(update_blender_state_cache):
            bpy.app.timers.unregister(update_blender_state_cache)
    except Exception:
        pass

def register_task_queue_timer():
    if not _always_on_enabled('smart_selector_browser_server', True) or not _always_on_enabled('smart_selector_task_queue_timer', True):
        unregister_task_queue_timer()
        return
    try:
        if not bpy.app.timers.is_registered(process_task_queue):
            bpy.app.timers.register(process_task_queue)
    except Exception:
        pass

def unregister_task_queue_timer():
    try:
        if bpy.app.timers.is_registered(process_task_queue):
            bpy.app.timers.unregister(process_task_queue)
    except Exception:
        pass

def _rpc_call(kind: str, payload: dict, timeout: float=1.2) -> dict:
    """Call a main-thread RPC and wait for result (used by HTTP thread)."""
    if not _always_on_enabled('smart_selector_task_queue_timer', True):
        return {'error': 'task_queue_disabled'}
    req_id = f'{time.time():.6f}_{threading.get_ident()}_{secrets.token_hex(4)}'
    ev = threading.Event()
    with _rpc_lock:
        _rpc_events[req_id] = ev
    try:
        task_queue.put_nowait(('rpc', {'kind': kind, 'req_id': req_id, 'payload': payload or {}}, ''))
    except queue.Full:
        with _rpc_lock:
            _rpc_events.pop(req_id, None)
        return {'error': 'task_queue_full'}
    ev.wait(timeout)
    with _rpc_lock:
        res = _rpc_results.pop(req_id, None)
        _rpc_events.pop(req_id, None)
    if res is None:
        # No answer from the main thread in time (busy, or the server stopped): not an empty result.
        return {'error': 'rpc_timeout'}
    return res if isinstance(res, dict) else {}

def _rpc_set_result(req_id: str, result: dict):
    with _rpc_lock:
        ev = _rpc_events.get(req_id)
        if ev is None:
            return False
        _rpc_results[req_id] = result or {}
        ev.set()
        return True

def get_view3d_context():
    try:
        if bpy.context.window:
            for area in bpy.context.window.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            return {'window': bpy.context.window, 'screen': bpy.context.window.screen, 'area': area, 'region': region, 'scene': bpy.context.window.scene, 'view_layer': bpy.context.window.view_layer}
        for window in bpy.data.window_managers[0].windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            return {'window': window, 'screen': window.screen, 'area': area, 'region': region, 'scene': window.scene, 'view_layer': window.view_layer}
    except Exception:
        pass
    return None

def _check_token(handler, qs=None) -> bool:
    """Verify request token for /api endpoints."""
    try:
        if not server_token:
            return True
        hdr = handler.headers.get('X-SST-Token', '')
        if hdr == server_token:
            return True
        if qs:
            t = qs.get('token', [''])[0]
            if t and t == server_token:
                return True
    except Exception:
        pass
    return False

def _forbidden(handler):
    _json_response(handler, 403, {'error': 'forbidden'})

class SelectorHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)
        if path.startswith('/images/'):
            parts = path.split('/')
            if len(parts) >= 4:
                project = urllib.parse.unquote(parts[2])
                filename = urllib.parse.unquote(parts[3])
                try:
                    filepath = utils.safe_project_image_path(project, filename)
                except Exception:
                    _empty_response(self, 404)
                    return
                if os.path.exists(filepath):
                    ext = os.path.splitext(filepath)[1].lower()
                    ctype = 'application/octet-stream'
                    if ext in ('.png',):
                        ctype = 'image/png'
                    elif ext in ('.jpg', '.jpeg'):
                        ctype = 'image/jpeg'
                    elif ext in ('.webp',):
                        ctype = 'image/webp'
                    self.send_response(200)
                    self.send_header('Content-type', ctype)
                    self.send_header('Cache-Control', 'no-store')
                    self.end_headers()
                    with open(filepath, 'rb') as f:
                        self.wfile.write(f.read())
                    return
            _empty_response(self, 404)
            return
        if path.startswith('/api/'):
            if not _check_token(self, qs):
                _forbidden(self)
                return
        if path == '/api/state':
            _mark_dirty_selection()
            _mark_watched_dirty()
            try:
                since = int(qs.get('since', ['-1'])[0] or -1)
            except Exception:
                since = -1
            payload = {'rev': state_rev}
            if since != state_rev:
                payload.update({'objects': global_all_objects, 'selected': global_selected_objects, 'active_obj': global_active_obj, 'shapekeys': global_shapekeys, 'collections': global_collections, 'armatures': global_armatures, 'mesh_objects': global_mesh_objects, 'datapaths': global_datapaths, 'selected_bones': global_selected_bones, 'script_results': _script_results_snapshot()})
            _json_response(self, 200, payload)
            return
        if path == '/api/shapekeys':
            obj_name = qs.get('obj', [''])[0]
            res = _rpc_call('shapekey_keys', {'obj': obj_name})
            keys = res.get('keys', []) if isinstance(res, dict) else []
            _json_response(self, 200, {'keys': keys})
            return
        if path == '/api/bones':
            arm_name = qs.get('armature', [''])[0]
            res = _rpc_call('bones_list', {'armature': arm_name})
            bones = res.get('bones', []) if isinstance(res, dict) else []
            _json_response(self, 200, {'bones': bones})
            return
        if path == '/api/load':
            project = qs.get('project', [''])[0]
            filename = qs.get('file', [''])[0]
            try:
                filepath = utils.safe_project_file_path(project, filename, allow_ext=('.json',))
            except Exception:
                _empty_response(self, 404)
                return
            if filename and os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = f.read()
                _bytes_response(self, 200, data.encode('utf-8'), 'application/json; charset=utf-8')
            else:
                _empty_response(self, 404)
            return
        if path == '/' or path.startswith('/?'):
            from .html import HTML_CONTENT
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            html = HTML_CONTENT.replace('{TOKEN}', server_token)
            self.wfile.write(html.encode('utf-8'))
            return
        _empty_response(self, 404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)
        if path.startswith('/api/'):
            if not _check_token(self, qs):
                _forbidden(self)
                return
        try:
            queued_json_endpoints = {'/api/select': 'select', '/api/execute_script': 'script', '/api/set_shapekey': 'shapekey', '/api/set_custom_prop': 'custom_prop', '/api/timeline': 'timeline', '/api/camera': 'camera'}
            if path in queued_json_endpoints:
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                if path == '/api/execute_script':
                    try:
                        prefs = utils.get_prefs()
                        if prefs is not None and (not bool(getattr(prefs, 'enable_exec_script', True))):
                            _json_response(self, 403, {'error': 'execute_script_disabled'})
                            return
                    except Exception:
                        pass
                    script = data.get('script')
                    if not isinstance(script, str) or not script.strip():
                        # Nothing to run: answer now instead of queueing a task Blender would CANCEL silently.
                        _json_response(self, 400, {'error': 'empty_script'})
                        return
                _queue_task(self, queued_json_endpoints[path], data)
                return
            if path == '/api/blender_undo':
                _queue_task(self, 'undo', {})
                return
            if path == '/api/blender_redo':
                _queue_task(self, 'redo', {})
                return
            if path == '/api/watch':
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                # Every POST replaces all three watch sets; an absent key means empty.
                sk = data.get('shapekeys', {}) if isinstance(data, dict) else {}
                normalized = _normalize_watched_shapekeys(sk)
                datapaths, rejected = _normalize_watched_datapaths(data.get('datapaths', []))
                bone_armatures = _normalize_watched_bone_armatures(data.get('bone_armatures', []))
                with _watched_lock:
                    watched_shapekeys.clear()
                    watched_shapekeys.update(normalized)
                    watched_datapaths[:] = datapaths
                    watched_bone_armatures[:] = bone_armatures
                    globals()['_watched_dirty'] = True
                _json_response(self, 200, {'ok': True, 'datapaths': len(datapaths), 'datapaths_rejected': rejected, 'bone_armatures': len(bone_armatures)})
                return
            if path == '/api/capture_selection':
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                cap_kind = data.get('cap_kind', '')
                payload = {'cap_kind': cap_kind}
                payload.update(data)
                res = _rpc_call('capture_selection', payload, timeout=1.5)
                _json_response(self, 200, res)
                return
            if path == '/api/upload_image':
                project = qs.get('project', ['Default_Project'])[0]
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                filename = str(data.get('filename') or f'img_{int(time.time())}.png')
                b64_str = str(data.get('data', '') or '')
                if ',' in b64_str:
                    b64_str = b64_str.split(',', 1)[1]
                try:
                    filepath = utils.safe_project_image_path(project, filename)
                    raw = base64.b64decode(b64_str, validate=True)
                    utils.atomic_write_bytes(filepath, raw)
                    url = f'/images/{urllib.parse.quote(utils.sanitize_name(project))}/{urllib.parse.quote(os.path.basename(filepath))}'
                    _json_response(self, 200, {'url': url})
                    return
                except Exception as e:
                    pass
                    _json_response(self, 400, {'error': 'upload_image_failed', 'detail': str(e)})
                    return
            if path == '/api/delete_image':
                project = qs.get('project', ['Default_Project'])[0]
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                img_url = str(data.get('url', '') or '')
                try:
                    filepath = utils.safe_image_url_to_path(project, img_url)
                    if filepath and os.path.exists(filepath):
                        try:
                            utils.make_backup(filepath)
                            os.remove(filepath)
                        except Exception as exc:
                            _json_response(self, 500, {'error': 'delete_image_failed', 'detail': str(exc)})
                            return
                    _json_response(self, 200, {'ok': True})
                    return
                except Exception as exc:
                    _json_response(self, 400, {'error': 'delete_image_failed', 'detail': str(exc)})
                    return
            if path == '/api/save':
                project = qs.get('project', ['Default_Project'])[0]
                filename = qs.get('file', [''])[0]
                if not filename:
                    _json_response(self, 400, {'error': 'missing_filename'})
                    return
                post_data, err = _read_raw_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                try:
                    filepath = utils.safe_project_file_path(project, filename, allow_ext=('.json',))
                    try:
                        json.loads(post_data or '{}')
                    except Exception as exc:
                        _json_response(self, 400, {'error': 'invalid_json', 'detail': str(exc)})
                        return
                    utils.atomic_write_text(filepath, post_data, encoding='utf-8')
                    _json_response(self, 200, {'ok': True})
                    return
                except Exception as e:
                    pass
                    _json_response(self, 500, {'error': 'save_failed', 'detail': str(e)})
                    return
            if path == '/api/topmost':
                data, err = _read_json_body(self)
                if err:
                    _json_response(self, err[0], err[1])
                    return
                self.set_topmost(data.get('id'), _payload_bool(data.get('topmost', False), False))
                _json_response(self, 200, {'ok': True})
                return
            _empty_response(self, 404)
            return
        except Exception as e:
            pass
            _json_response(self, 500, {'error': 'post_failed', 'detail': str(e)})

    def set_topmost(self, target_id, is_topmost):
        if os.name != 'nt':
            return
        global global_blender_hwnd
        try:
            if not target_id or not global_blender_hwnd:
                return
            user32 = ctypes.windll.user32
            GWL_HWNDPARENT = -8
            SetWindowLongPtr = user32.SetWindowLongPtrW if hasattr(user32, 'SetWindowLongPtrW') else user32.SetWindowLongW
            SetWindowLongPtr.argtypes = [ctypes.wintypes.HWND, ctypes.c_int, ctypes.wintypes.HWND]
            SetWindowLongPtr.restype = ctypes.wintypes.HWND
            browser_hwnd = 0
            for _ in range(10):
                browser_hwnd = user32.FindWindowW(None, target_id)
                if browser_hwnd:
                    break
                time.sleep(0.1)
            if browser_hwnd:
                if is_topmost:
                    SetWindowLongPtr(browser_hwnd, GWL_HWNDPARENT, global_blender_hwnd)
                else:
                    SetWindowLongPtr(browser_hwnd, GWL_HWNDPARENT, 0)
        except Exception:
            pass

def exec_selection(data):
    data = data if isinstance(data, dict) else {}
    target_names = _payload_string_list(data.get('objects', []))
    is_shift = _payload_bool(data.get('shift', False), False)
    is_ctrl = _payload_bool(data.get('ctrl', False), False)
    try:
        if not is_shift and (not is_ctrl):
            for obj in bpy.data.objects:
                obj.select_set(False)
        for name in target_names:
            obj = bpy.data.objects.get(name)
            if obj:
                if is_ctrl:
                    obj.select_set(False)
                else:
                    obj.select_set(True)
                    if bpy.context.view_layer:
                        bpy.context.view_layer.objects.active = obj
        _mark_dirty_selection()
        for window in bpy.data.window_managers[0].windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception as e:
        pass

def exec_script(data):
    try:
        prefs = utils.get_prefs()
        if prefs is not None and (not bool(getattr(prefs, 'enable_exec_script', True))):
            pass
            return
    except Exception:
        pass
    script_code = data.get('script', '') if isinstance(data, dict) else ''
    if not script_code:
        return
    try:
        ctx_dict = get_view3d_context()
        glb = {'bpy': bpy, 'C': bpy.context, 'D': bpy.data, '__name__': '__smart_selector_suite__'}
        if ctx_dict:
            with bpy.context.temp_override(**ctx_dict):
                exec(script_code, glb)
        else:
            exec(script_code, glb)
    except Exception as e:
        pass

def exec_set_shapekey(data):
    data = data if isinstance(data, dict) else {}
    try:
        obj = bpy.data.objects.get(str(data.get('obj') or ''))
        if obj and getattr(obj.data, 'shape_keys', None):
            kb = obj.data.shape_keys.key_blocks.get(str(data.get('key') or ''))
            if kb:
                kb.value = float(data.get('value'))
        _mark_watched_dirty()
        for window in bpy.data.window_managers[0].windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception as e:
        pass

def exec_set_custom_prop(data):
    data = data if isinstance(data, dict) else {}
    try:
        obj_name = str(data.get('obj') or '')
        path = str(data.get('path') or '')
        obj = bpy.data.objects.get(obj_name)
        if obj and path:
            from . import utils as _utils
            _utils.assign_numeric_data_path(obj, path, data.get('value'))
            for window in bpy.data.window_managers[0].windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
    except Exception as e:
        pass

def exec_timeline(data):
    data = data if isinstance(data, dict) else {}
    try:
        action = str(data.get('action') or '')
        ctx_dict = get_view3d_context()
        if not ctx_dict:
            return
        with bpy.context.temp_override(**ctx_dict):
            if action == 'play':
                bpy.ops.screen.animation_play()
            elif action == 'pause':
                bpy.ops.screen.animation_cancel(restore_frame=False)
            elif action == 'next':
                bpy.context.scene.frame_set(bpy.context.scene.frame_current + 1)
            elif action == 'prev':
                bpy.context.scene.frame_set(bpy.context.scene.frame_current - 1)
            elif action == 'keyframe':
                if bpy.context.active_object:
                    bpy.ops.anim.keyframe_insert_menu('INVOKE_DEFAULT')
    except Exception as e:
        pass

def exec_camera(data):
    data = data if isinstance(data, dict) else {}
    try:
        cam_action = str(data.get('action') or '')
        cam_obj_name = str(data.get('camera_obj') or '')
        ctx_dict = get_view3d_context()
        if not ctx_dict:
            return
        with bpy.context.temp_override(**ctx_dict):
            if cam_action == 'CAMERA':
                if cam_obj_name:
                    cam = bpy.data.objects.get(cam_obj_name)
                    if cam:
                        bpy.context.scene.camera = cam
                bpy.ops.view3d.view_camera()
            else:
                bpy.ops.view3d.view_axis(type=cam_action)
    except Exception as e:
        pass

def start_server(project, filename, mode, lang=None):
    global httpd, server_thread, current_port, global_blender_hwnd
    if not _always_on_enabled('smart_selector_browser_server', True):
        return False
    if os.name == 'nt':
        global_blender_hwnd = ctypes.windll.user32.GetActiveWindow() if hasattr(ctypes, 'windll') and hasattr(ctypes.windll, 'user32') else 0
    else:
        global_blender_hwnd = 0
    if httpd is None:
        global server_token
        if not server_token:
            server_token = secrets.token_urlsafe(24)
        _mark_all_state_dirty()
        register_state_listeners()
        pass

        class _ThreadingHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
            daemon_threads = True
        httpd = _ThreadingHTTPServer(('127.0.0.1', 0), SelectorHandler)
        current_port = httpd.server_address[1]
        server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        server_thread.start()
        register_state_cache_timer()
        register_task_queue_timer()
    else:
        _mark_all_state_dirty()
        register_state_listeners()
        register_state_cache_timer()
        register_task_queue_timer()
    if lang is None:
        try:
            ui_lang = str(getattr(bpy.context.preferences.view, 'language', '') or '').strip()
            if ui_lang and ui_lang != 'DEFAULT':
                lang = 'ja' if ui_lang.lower().startswith('ja') else 'en'
            else:
                locale = str(getattr(bpy.app.translations, 'locale', None) or 'ja_JP')
                lang = 'ja' if locale.lower().startswith('ja') else 'en'
        except Exception:
            locale = str(getattr(bpy.app.translations, 'locale', None) or 'ja_JP')
            lang = 'ja' if locale.lower().startswith('ja') else 'en'
    else:
        lang = 'ja' if str(lang).lower().startswith('ja') else 'en'
    url = f'http://127.0.0.1:{current_port}/?project={urllib.parse.quote(project)}&file={urllib.parse.quote(filename)}&mode={mode}&lang={lang}&t={time.time()}'
    paths = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/usr/bin/google-chrome', '/usr/bin/microsoft-edge']
    for p in paths:
        if os.path.exists(p):
            title_name = os.path.splitext(filename)[0] if filename else '未保存' if lang == 'ja' else 'Unsaved'
            app_title = f'Smart Selector [{title_name}]'
            try:
                subprocess.Popen([p, f'--app={url}', f'--app-id={app_title}', f'--lang={lang}', '--disable-features=Translate,TranslateUI', '--disable-translate'])
            except Exception:
                subprocess.Popen([p, f'--app={url}', f'--lang={lang}', '--disable-features=Translate,TranslateUI', '--disable-translate'])
            return True
    import webbrowser
    webbrowser.open(url)
    return True

def stop_server():
    unregister_state_listeners()
    global httpd, server_thread, current_port, global_blender_hwnd, global_datapaths, global_selected_bones, _last_custom_prop_failure
    unregister_state_cache_timer()
    unregister_task_queue_timer()
    local_httpd = httpd
    local_thread = server_thread
    httpd = None
    server_thread = None
    current_port = 0
    global_blender_hwnd = 0
    if local_httpd is not None:
        try:
            local_httpd.shutdown()
        except Exception:
            pass
        try:
            local_httpd.server_close()
        except Exception:
            pass
    if local_thread is not None and getattr(local_thread, 'is_alive', None):
        try:
            if local_thread.is_alive():
                local_thread.join(timeout=0.5)
        except Exception:
            pass
    try:
        with _rpc_lock:
            for ev in list(_rpc_events.values()):
                try:
                    ev.set()
                except Exception:
                    pass
            _rpc_events.clear()
            _rpc_results.clear()
    except Exception:
        pass
    try:
        with _watched_lock:
            watched_shapekeys.clear()
            watched_datapaths.clear()
            watched_bone_armatures.clear()
    except Exception:
        pass
    global_datapaths = {}
    global_selected_bones = {}
    _last_custom_prop_failure = (None, 0.0)
    _custom_prop_undo_gestures.clear()
    with _script_results_lock:
        script_results.clear()
    try:
        while True:
            task_queue.get_nowait()
    except queue.Empty:
        pass
    except Exception:
        pass
