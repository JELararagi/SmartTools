# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""1.10.51: help text added for the SmartTools common help spec (2026-10-17).

Every explanation of the Smart Selector N-panel lives in the ? help popup of its section header.  This module adds,
for the general (non face) sections, the parts the older topics did not have: what to prepare, numbered steps, how
to check the result, and how to undo / cautions / limits.  It also holds the topics that had no help at all.

Only plain data.  Imported lazily by help.py when a help popup is drawn; never at registration.
"""

from __future__ import annotations


def supplements(_t) -> dict[str, dict[str, object]]:
    """Per existing topic: prep / usage (numbered steps, replaces the old usage) / check / notes / settings_add."""
    return {
        'smart_selector': {
            'prep': [
                _t('Open the 3D View, press N to show the Sidebar, and click the "Smart Selector" tab.', '3D ビューで N キーを押してサイドバーを出し、「スマートセレクター」のタブを押します。'),
                _t('Nothing has to be selected to open the panel. Each group below says what it needs in its own ? help.', 'パネルを開くだけなら、何も選ぶ必要はありません。各グループで必要な物は、そのグループの ？ に書いてあります。'),
            ],
            'usage': [
                _t('Click the triangle at the left of a group title to open or close that group. Click ? at the right end of a title to read its help.', 'グループの見出しの左の三角を押すと、そのグループが開閉します。見出しの右端の ？ を押すと、そのグループのヘルプが開きます。'),
                _t('Selection Sets: save and recall object selections by name.', '「選択セット」：オブジェクトの選択を名前を付けて保存し、呼び出します。'),
                _t('Project: choose the folder where your selector files are kept.', '「プロジェクト」：セレクターのファイルを置くフォルダーを選びます。'),
                _t('Selector Data List: create a new selector, or open one in your web browser in play mode (the button with its name) or edit mode (the pencil icon).', '「セレクターデータ一覧」：新しいセレクターを作るか、作ってある物をブラウザーで開きます（名前のボタンで再生、鉛筆のアイコンで編集）。'),
                _t('Collection Manager / GP Select: load these extra tools only when you need them.', '「コレクションマネージャー」「GP セレクト」：使う時だけ読み込む追加の道具です。'),
                _t('Face ARKit: tools for the ARKit face rig (shown open when the file has that rig).', '「顔 ARKit」：ARKit の顔のリグ用の道具です（そのリグがあるファイルでは開いた状態で出ます）。'),
                _t('Settings and Bridge Actions: storage, safety and test tools. Normally you do not need to change them.', '「設定」「ブリッジ操作」：保存先・安全・試験用の道具です。ふつうは変えなくて構いません。'),
            ],
            'check': [
                _t('The Smart Selector summary shows the current project and how many selector files it contains.', '「スマートセレクター」のまとめに、今のプロジェクト名と、その中のセレクターの数が出ます。'),
            ],
            'notes': [
                _t('Opening and closing groups changes nothing in your scene. The open/closed state is remembered (see Always-on Toggles > N-panel State Save).', 'グループの開閉は、シーンを何も変えません。開閉の状態は覚えておきます（「常時起動切り替え」→「Nパネル状態保存」）。'),
                _t('All explanations are in these ? popups; the panel itself shows only buttons, settings and one-line states.', '説明はすべてこの ？ のヘルプにあります。パネルには、ボタン・設定・1 行の状態だけを出します。'),
            ],
        },
        'selection_sets': {
            'prep': [
                _t('Object Mode is the normal mode for this tool. Select the objects you want to remember (click, Shift+click, or box select).', 'ふつうはオブジェクトモードで使います。覚えておきたいオブジェクトを選びます（クリック、Shift+クリック、矩形選択）。'),
            ],
            'usage': [
                _t('1. Select the objects.', '1. オブジェクトを選びます。'),
                _t('2. Type a name in the field at the top (for example "Hair" or "Props").', '2. 一番上の欄に名前を入れます（例：「髪」「小物」）。'),
                _t('3. Press Create. The set appears in the list. When there is no set yet, the panel says "No selection sets yet."', '3. 「作成」を押します。一覧にセットが出ます。まだ 1 つも無い時は、パネルに「選択セットはまだありません。」と出ます。'),
                _t('4. Later, click the set in the list, then press Select to select exactly those objects again.', '4. 後で一覧のセットを押してから「選択」を押すと、その物だけが選ばれた状態に戻ります。'),
                _t('5. Use Add / Subtract / Toggle to combine the set with what is selected now. The set itself does not change.', '5. 「追加」「除外」「切り替え」で、今の選択とセットを組み合わせます。セットの中身は変わりません。'),
                _t('6. To change the set itself, select objects and press Update (replace all), or use the add-member / remove-member icons.', '6. セットの中身を変える時は、物を選んでから「更新」（全部入れ替え）か、メンバーを足す・外すアイコンを使います。'),
            ],
            'check': [
                _t('After Select, the Outliner and the 3D View show the set members selected. The list row shows the set name.', '「選択」の後、アウトライナーと 3D ビューでセットの物が選ばれています。一覧の行にセット名が出ます。'),
            ],
            'notes': [
                _t('Undo (Ctrl+Z) undoes a create, update or delete of a set.', '作成・更新・削除は、元に戻す（Ctrl+Z）で戻せます。'),
                _t('"Delete Selection Set" (the trash icon) removes only the set, never the objects. Renaming an object keeps it in the set.', '「選択セットを削除」（ごみ箱のアイコン）はセットだけを消し、オブジェクトは消しません。オブジェクトの名前を変えてもセットに残ります。'),
                _t('Sets are saved inside the .blend file of this scene. They do not move to other files.', 'セットはこのシーンの .blend の中に保存されます。他のファイルには移りません。'),
                _t('Recommended: short names that say what the group is (body, hair, props). Selecting hidden or disabled objects can fail silently in Blender.', 'おすすめ：何の組か分かる短い名前（体・髪・小物）。隠した物や選べない物は、Blender の仕組みで選べない事があります。'),
            ],
        },
        'project': {
            'prep': [
                _t('Decide one project per job or character, for example "MIK". A project is just a folder.', '案件やキャラクターごとに 1 つのプロジェクトを決めます（例：「MIK」）。プロジェクトはただのフォルダーです。'),
            ],
            'usage': [
                _t('1. Click the large button with the project name. A searchable list opens.', '1. プロジェクト名の大きなボタンを押します。検索できる一覧が開きます。'),
                _t('2. Pick a project. The Selector Data List now shows that project\'s files.', '2. プロジェクトを選びます。「セレクターデータ一覧」がそのプロジェクトのファイルに変わります。'),
                _t('3. To make a new one, press + and enter a name (letters, numbers and _ are safest).', '3. 新しく作る時は ＋ を押し、名前を入れます（英数字と _ が安全です）。'),
                _t('4. Rename, Duplicate and Archive are the icon buttons beside +. The folder icon opens the project folder in your file browser.', '4. 名前変更・複製・アーカイブは ＋ の隣のアイコンです。フォルダーのアイコンで、プロジェクトのフォルダーをファイルブラウザーで開きます。'),
            ],
            'check': [
                _t('The project button shows the new name, and the Smart Selector summary shows "Project: <name>".', 'プロジェクトのボタンに新しい名前が出て、「スマートセレクター」のまとめに「プロジェクト：（名前）」と出ます。'),
            ],
            'notes': [
                _t('Archive does not delete: the folder moves into __ARCHIVE__. Turn on Settings > Project List > Show Archived Projects to pick it again.', 'アーカイブは消しません。フォルダーが __ARCHIVE__ へ移るだけです。また使う時は「設定」→「プロジェクト一覧」→「アーカイブ済みプロジェクトを表示」をオンにして選びます。'),
                _t('Renaming or duplicating is done on disk; there is no Ctrl+Z for it. Back up the folder first if it matters.', '名前変更・複製はディスクの上で行うので、Ctrl+Z では戻りません。大事な物は先にフォルダーを控えてください。'),
            ],
        },
        'selector_data': {
            'prep': [
                _t('Choose the project first (Project group). A web browser must be available on this computer.', '先に「プロジェクト」でプロジェクトを選びます。このパソコンでウェブブラウザーが使える必要があります。'),
                _t('Always-on Toggles > Browser server must be on (it is off by default, so turn it on the first time).', '「常時起動切り替え」の「ブラウザーサーバー」がオンである事（既定はオフなので、最初にオンにします）。'),
            ],
            'usage': [
                _t('1. Press Create New Selector. An empty selector opens in your browser in edit mode.', '1. 「新規セレクター作成」を押します。空のセレクターが、ブラウザーの編集モードで開きます。'),
                _t('2. In the browser, place buttons, sliders and images, and set what each one controls (objects, bones, shape keys, properties and so on).', '2. ブラウザーで、ボタン・スライダー・画像を置き、それぞれが何を動かすか（オブジェクト・骨・シェイプキー・プロパティ等）を決めます。'),
                _t('3. Save it in the browser. The file appears in this list (press the refresh icon if it does not).', '3. ブラウザーで保存します。この一覧にファイルが出ます（出ない時は更新のアイコンを押します）。'),
                _t('4. Use the button with the selector name to use the selector (play), and the pencil icon to change it (edit).', '4. 行のセレクター名のボタンで使い（再生）、鉛筆のアイコンで直します（編集）。'),
                _t('5. Click the star to make a favourite; Favorites Only shows only the starred ones.', '5. 星を押すとお気に入りになり、「お気に入りのみ」で星の付いた物だけを出せます。'),
            ],
            'check': [
                _t('Pressing a button in the browser selects or changes the target in Blender at once. If nothing happens, check that Blender is not busy and that the target names still exist.', 'ブラウザーのボタンを押すと、すぐに Blender の対象が選ばれる・変わります。何も起きない時は、Blender が処理中でないか、対象の名前が今もあるかを確かめます。'),
            ],
            'notes': [
                _t('Every save keeps .bak backups beside the file (Settings > Performance / Safety > Backup Generations, default 20). To go back, copy a .bak over the file.', '保存のたびに、ファイルの横に .bak の控えが残ります（「設定」→「パフォーマンスと安全性」→「バックアップ世代数」、既定 20）。戻す時は .bak をファイルに上書きコピーします。'),
                _t('Script buttons run Python only while Allow Execute Script is on. Turn it off for files you did not make yourself.', 'スクリプトのボタンは「スクリプト実行を許可」がオンの時だけ Python を動かします。自分で作っていないファイルではオフにしてください。'),
                _t('Very large scenes make the browser update slower. Raise State Sync Interval (s) if Blender feels heavy.', 'とても大きなシーンでは、ブラウザーの更新が遅くなります。重い時は「状態同期間隔（秒）」を上げます。'),
            ],
        },
        'settings': {
            'prep': [
                _t('Nothing to select. Open Settings only when you want to change where data is stored or a safety option.', '選ぶ物はありません。保存先や安全の設定を変えたい時だけ開きます。'),
            ],
            'usage': [
                _t('1. Open the sub-group you need: Data Storage, Performance / Safety, or Project List. Each has its own ? help.', '1. 必要な小グループを開きます：「データ保存先」「パフォーマンスと安全性」「プロジェクト一覧」。それぞれに ？ があります。'),
                _t('2. Change the value. It is saved immediately when N-panel State Save is on.', '2. 値を変えます。「Nパネル状態保存」がオンなら、すぐに保存されます。'),
            ],
            'check': [
                _t('Restart Blender: the values you set are still there.', 'Blender を再起動しても、変えた値が残っています。'),
            ],
            'notes': [
                _t('To go back, type the old value again. Recommended values: State Sync Interval 0.5 s, Backup Generations 20, Allow Execute Script on only for your own selectors, root folder blank.', '戻す時は、前の値を入れ直します。おすすめ：状態同期間隔 0.5 秒、バックアップ世代数 20、スクリプト実行の許可は自分のセレクターだけでオン、保存ルートは空欄。'),
            ],
        },
        'bridge_actions': {
            'prep': [
                _t('This group is for testing and recovery. A normal user does not need it; selectors call these actions for you.', 'このグループは試験と復旧用です。ふつうは使いません（セレクターが自動でこれらを呼びます）。'),
            ],
            'usage': [
                _t('1. Open the sub-group of the action you want to test (each has its own ? help).', '1. 試したい処理の小グループを開きます（それぞれに ？ があります）。'),
                _t('2. Type the JSON payload in the field.', '2. 欄に JSON を入れます。'),
                _t('3. Press the button under the field.', '3. 欄の下のボタンを押します。'),
            ],
            'check': [
                _t('The result appears in Blender at once (selection, shape key value, property value). A wrong JSON does nothing and reports an error.', '結果はすぐ Blender に出ます（選択・シェイプキーの値・プロパティの値）。JSON が違うと何もせず、エラーを出します。'),
            ],
            'notes': [
                _t('Changes made through these actions can be undone with Ctrl+Z (or Undo in the Undo / Redo sub-group).', 'ここで行った変更は Ctrl+Z（または「元に戻す・やり直し」の「元に戻す」）で戻せます。'),
            ],
        },
        'collection_manager': {
            'prep': [
                _t('Always-on Toggles > Collection Manager must be on. Work in Object Mode.', '「常時起動切り替え」で「コレクションマネージャー」がオンである事。オブジェクトモードで使います。'),
            ],
            'usage': [
                _t('1. Press Open Collection Manager. The first time it loads the tool, then a popup opens.', '1. 「コレクションマネージャーを開く」を押します。初回は道具を読み込んでから、ポップアップが開きます。'),
                _t('2. In the popup, click the icons on each collection row to hide, exclude or disable it; use the filter field to find collections.', '2. ポップアップで、各コレクションの行のアイコンを押して、隠す・除外・無効を切り替えます。名前の欄で絞り込めます。'),
                _t('3. The Display Options button (top of the popup) chooses which restriction columns are shown.', '3. ポップアップ上の「表示オプション」で、どの制限の列を出すかを選びます。'),
                _t('4. Close the popup by moving the mouse away from it.', '4. マウスをポップアップの外へ動かすと閉じます。'),
            ],
            'check': [
                _t('The status line above the button says Loaded. The Outliner shows the same visibility changes.', 'ボタンの上の状態の行に「読み込み済み」と出ます。アウトライナーにも同じ表示の変化が出ます。'),
            ],
            'notes': [
                _t('The popup has its own Undo / Redo buttons; Ctrl+Z also works after closing it.', 'ポップアップには専用の元に戻す・やり直しがあります。閉じた後は Ctrl+Z でも戻せます。'),
                _t('When the status says "Disabled in Always-on Toggles", turn the tool on there first.', '状態に「常時起動切り替えで無効」と出ている時は、先にそこでオンにします。'),
                _t('Very many collections make the popup slower to open.', 'コレクションがとても多いと、ポップアップを開くのが遅くなります。'),
            ],
        },
        'gp_select': {
            'prep': [
                _t('Always-on Toggles > GP Select must be on. Select a Grease Pencil object (the panel says so when none is active).', '「常時起動切り替え」で「GP セレクト」がオンである事。Grease Pencil のオブジェクトを選びます（選んでいない時はパネルにそう出ます）。'),
            ],
            'usage': [
                _t('1. Press Load GP Select UI (only the first time in a session).', '1. 「GP セレクトUIを読み込む」を押します（その回の最初だけ）。'),
                _t('2. Open GP Select Controls and use the mode, layer, visibility and mask buttons.', '2. 「GP セレクトの操作」を開き、モード・レイヤー・表示・マスクのボタンを使います。'),
                _t('3. Renaming and Pass Index and Rigging Tools are separate sub-groups with their own ? help.', '3. 「リネームとパスインデックス」「リギングツール」は別の小グループで、それぞれに ？ があります。'),
            ],
            'check': [
                _t('The Grease Pencil layers in the Properties editor show the change (order, visibility, opacity, mask).', 'プロパティエディターの Grease Pencil のレイヤーに変化が出ます（順番・表示・不透明度・マスク）。'),
            ],
            'notes': [
                _t('Ctrl+Z undoes the layer changes. Delete-type buttons (delete layers, remove empty layers) ask for confirmation first.', 'レイヤーの変更は Ctrl+Z で戻せます。消す種類のボタン（レイヤー削除・空レイヤー削除）は、先に確認を出します。'),
                _t('With another object type active, the controls are hidden and the panel says why.', '別の種類の物を選んでいる時は、操作は隠れ、その旨がパネルに出ます。'),
            ],
        },
        'gp_select_renaming_pass': {
            'prep': [
                _t('Select the Grease Pencil object, then the layers (or strokes) to rename or number.', 'Grease Pencil のオブジェクトを選び、名前や番号を変えたいレイヤー（またはストローク）を選びます。'),
            ],
            'usage': [
                _t('1. Type the text (prefix/suffix, new name, or find/replace) or the Pass value.', '1. 文字（接頭辞・接尾辞、新しい名前、検索・置換）か、パスの値を入れます。'),
                _t('2. Press the button for that action.', '2. その処理のボタンを押します。'),
            ],
            'check': [
                _t('The layer names or Pass Index values in the Properties editor change.', 'プロパティエディターのレイヤー名かパスインデックスが変わります。'),
            ],
            'notes': [
                _t('Ctrl+Z undoes renames. Replace changes every match in the selected layer names.', '名前の変更は Ctrl+Z で戻せます。置換は、選んだレイヤー名の中の当たる所を全部変えます。'),
            ],
        },
        'gp_select_rigging': {
            'prep': [
                _t('Select the Grease Pencil object and, when needed, the armature that will control the time offset.', 'Grease Pencil のオブジェクトと、必要なら時間をずらす操作に使うアーマチュアを選びます。'),
            ],
            'usage': [
                _t('1. Set Controller Sensitivity (start with the default). It becomes the strength of the setup you create.', '1. 「コントローラー感度」を決めます（まず既定の値で）。作る仕掛けの強さになります。'),
                _t('2. Press Create Layer Time Control or Create Pass Index Time Control.', '2. 「レイヤーの時間オフセット制御を作成」か「インデックスパスの時間オフセット制御を作成」を押します。'),
                _t('3. Move the created controller and check that the drawing changes.', '3. できたコントローラーを動かし、絵が切り替わる事を確かめます。'),
            ],
            'check': [
                _t('Moving the controller switches the Grease Pencil frames. Drivers appear in the Drivers editor.', 'コントローラーを動かすと、Grease Pencil の絵が切り替わります。ドライバーエディターにドライバーが出ます。'),
            ],
            'notes': [
                _t('Remove Setup deletes the generated controller and drivers. Ctrl+Z also undoes a creation.', '「セットアップを削除」で、作ったコントローラーとドライバーを消します。作成は Ctrl+Z でも戻せます。'),
            ],
        },
        'settings_performance': {
            'prep': [
                _t('Nothing to select.', '選ぶ物はありません。'),
            ],
            'usage': [
                _t('1. State Sync Interval (s): raise it (0.8 to 1.0 s) when Blender feels heavy while a selector is open; lower it (0.3 s) for quicker feedback.', '1. 「状態同期間隔（秒）」：セレクターを開いて Blender が重い時は上げ（0.8〜1.0 秒）、反応を速くしたい時は下げます（0.3 秒）。'),
                _t('2. Backup Generations: how many .bak copies are kept per selector file.', '2. 「バックアップ世代数」：セレクターのファイル 1 つに何個の .bak を残すか。'),
                _t('3. Allow Execute Script: on lets selector buttons run Python.', '3. 「スクリプト実行を許可」：オンでセレクターのボタンが Python を動かせます。'),
            ],
            'check': [
                _t('The browser selector follows Blender selection at the new speed.', 'ブラウザーのセレクターが、新しい速さで Blender の選択に追いつきます。'),
            ],
            'notes': [
                _t('Recommended: 0.5 s, 20 generations. Backups take disk space; 0 disables them (no way back after a bad save).', 'おすすめ：0.5 秒、20 世代。控えはディスクを使います。0 にすると控えが無くなり、失敗した保存を戻せません。'),
                _t('With Allow Execute Script off, the Face ARKit rig tools that run Texts are refused too.', '「スクリプト実行を許可」がオフの時は、顔 ARKit のリグの Text を動かす道具も断られます。'),
            ],
        },
        'settings_project_list': {
            'prep': [
                _t('Nothing to select.', '選ぶ物はありません。'),
            ],
            'usage': [
                _t('1. Turn on Show Archived Projects to see archived projects in the project list.', '1. 「アーカイブ済みプロジェクトを表示」をオンにすると、アーカイブした物も一覧に出ます。'),
                _t('2. Pick the old project in the Project group, then turn the option off again.', '2. 「プロジェクト」で古いプロジェクトを選び、終わったらまたオフにします。'),
            ],
            'check': [
                _t('Archived projects appear in the list while the option is on.', 'オンの間、アーカイブしたプロジェクトが一覧に出ます。'),
            ],
            'notes': [
                _t('Recommended: off. The option only changes the list; it never moves folders.', 'おすすめ：オフ。一覧の出し方を変えるだけで、フォルダーは動かしません。'),
            ],
        },
        'bridge_undo_redo': {
            'prep': [
                _t('Nothing to select.', '選ぶ物はありません。'),
            ],
            'usage': [
                _t('1. Press Undo to go one step back, Redo to go one step forward again.', '1. 「元に戻す」で 1 つ前へ、「やり直し」で 1 つ先へ進みます。'),
            ],
            'check': [
                _t('The scene changes back exactly as with Ctrl+Z / Ctrl+Shift+Z.', 'Ctrl+Z／Ctrl+Shift+Z と同じに、シーンが戻ります。'),
            ],
            'notes': [
                _t('These are the same as Blender\'s own Undo / Redo, with the same limits (Edit > Undo History).', 'Blender の元に戻す・やり直しと同じ物で、限界も同じです（編集 → 元に戻す履歴）。'),
            ],
        },
        'bridge_selection': {
            'prep': [
                _t('Know the names of the objects (or bones / collections) you want to select.', '選びたいオブジェクト（または骨・コレクション）の名前を調べておきます。'),
            ],
            'usage': [
                _t('1. Type a JSON such as {"target_type": "object", "objects": ["Cube"]}.', '1. {"target_type": "object", "objects": ["Cube"]} のような JSON を入れます。'),
                _t('2. Press Apply Selection.', '2. 「選択を適用」を押します。'),
            ],
            'check': [
                _t('The named items are selected in the 3D View and the Outliner.', '名前の物が 3D ビューとアウトライナーで選ばれます。'),
            ],
            'notes': [
                _t('Ctrl+Z restores the previous selection. Names that do not exist are skipped.', 'Ctrl+Z で前の選択に戻ります。無い名前は飛ばします。'),
            ],
        },
        'bridge_shapekey': {
            'prep': [
                _t('Know the object name and the shape key name.', 'オブジェクト名とシェイプキー名を調べておきます。'),
            ],
            'usage': [
                _t('1. Type a JSON with the object, the shape key and the value (0 to 1).', '1. オブジェクト・シェイプキー・値（0〜1）を入れた JSON を書きます。'),
                _t('2. Press Set Shape Key.', '2. 「シェイプキーを設定」を押します。'),
            ],
            'check': [
                _t('The value in Object Data > Shape Keys changes and the mesh changes shape.', 'オブジェクトデータ → シェイプキーの値が変わり、形が変わります。'),
            ],
            'notes': [
                _t('Ctrl+Z restores the old value. A key is inserted only when Auto Keying is on.', 'Ctrl+Z で前の値に戻ります。キーは自動キーがオンの時だけ入ります。'),
            ],
        },
        'bridge_custom_prop': {
            'prep': [
                _t('Know the object name and the property path (for example ["my_value"]).', 'オブジェクト名とプロパティのパス（例：["my_value"]）を調べておきます。'),
            ],
            'usage': [
                _t('1. Type a JSON with the object, the path and the number.', '1. オブジェクト・パス・数を入れた JSON を書きます。'),
                _t('2. Press Set Custom Property.', '2. 「カスタムプロパティを設定」を押します。'),
            ],
            'check': [
                _t('The value in Object Properties > Custom Properties changes.', 'オブジェクトプロパティ → カスタムプロパティの値が変わります。'),
            ],
            'notes': [
                _t('Ctrl+Z restores the old value. Only numbers are accepted.', 'Ctrl+Z で前の値に戻ります。数だけを受け付けます。'),
            ],
        },
        'bridge_script': {
            'prep': [
                _t('Settings > Performance / Safety > Allow Execute Script must be on.', '「設定」→「パフォーマンスと安全性」→「スクリプト実行を許可」がオンである事。'),
            ],
            'usage': [
                _t('1. Type a JSON such as {"script": "print(1)"}.', '1. {"script": "print(1)"} のような JSON を入れます。'),
                _t('2. Press Execute Script.', '2. 「スクリプトを実行」を押します。'),
            ],
            'check': [
                _t('The script\'s effect appears in Blender; printed text goes to the system console.', 'スクリプトの効果が Blender に出ます。print の文字はシステムコンソールへ出ます。'),
            ],
            'notes': [
                _t('A script can change or delete anything. Run only code you wrote or trust. Ctrl+Z may not undo every script.', 'スクリプトは何でも変え・消せます。自分で書いた物か、信頼できる物だけを動かします。Ctrl+Z で全部戻るとは限りません。'),
            ],
        },
    }


def topics(_t) -> dict[str, dict[str, object]]:
    """Topics that had no help before 1.10.51."""
    return {
        'settings_storage': {
            'title': _t('Data Storage Help', 'データ保存先 ヘルプ'),
            'overview': [
                _t('Chooses the root folder where all Smart Selector projects (selector JSON files and images) are kept.', 'スマートセレクターの全プロジェクト（セレクターの JSON と画像）を置く、一番上のフォルダーを決めます。'),
            ],
            'prep': [
                _t('Decide whether you need a special place (for example a shared drive). Most users leave it blank.', '特別な場所（共有ドライブ等）が要るかを決めます。ほとんどの場合は空欄のままです。'),
            ],
            'usage': [
                _t('1. Leave Data Save Root Directory blank to use CONFIG/Smart_Selector_Suite (recommended).', '1. 「データ保存ルートディレクトリ」を空欄にすると CONFIG/Smart_Selector_Suite を使います（おすすめ）。'),
                _t('2. Or click the folder icon and choose another folder.', '2. 別の場所にする時は、フォルダーのアイコンを押して選びます。'),
                _t('3. Open the Project group and check that your projects are listed.', '3. 「プロジェクト」を開き、プロジェクトが一覧に出る事を確かめます。'),
            ],
            'settings': [
                (_t('Data Save Root Directory', 'データ保存ルートディレクトリ'), _t('Blank = CONFIG/Smart_Selector_Suite (recommended).', '空欄＝CONFIG/Smart_Selector_Suite（おすすめ）。')),
            ],
            'check': [
                _t('The folder icon of the Project group opens a folder inside the new root.', '「プロジェクト」のフォルダーのアイコンで、新しいルートの中のフォルダーが開きます。'),
            ],
            'notes': [
                _t('Changing the root does not move existing projects. Copy the project folders yourself, or clear the field to go back to the old place.', 'ルートを変えても、今あるプロジェクトは移りません。自分でフォルダーをコピーするか、欄を空に戻すと元の場所に戻ります。'),
                _t('If the active project is not in the new location, the first project there becomes active. Choose another one with the large button in the Project group.', '今のプロジェクトが新しい場所に無い時は、その場所の一覧の先頭のプロジェクトに切り替わります。別のプロジェクトは「プロジェクト」の大きなボタンで選びます。'),
            ],
        },
        'collection_manager_display': {
            'title': _t('Display Options Help', '表示オプション ヘルプ'),
            'overview': [
                _t('Chooses which restriction columns the Collection Manager popup shows on each collection row.', 'コレクションマネージャーのポップアップで、各行にどの制限の列を出すかを選びます。'),
            ],
            'prep': [
                _t('Open the Collection Manager popup and press its display-options button.', 'コレクションマネージャーのポップアップを開き、表示オプションのボタンを押します。'),
            ],
            'usage': [
                _t('1. Under Restriction Toggles, click the icons of the columns you want to see. Hover an icon to read its name.', '1. 「制限トグル」の下で、出したい列のアイコンを押します。アイコンにマウスを載せると名前が出ます。'),
                _t('2. Turn on Align Local Options to line the local options up on the right.', '2. 「ローカルオプションを整列」をオンにすると、ローカルの項目が右にそろいます。'),
            ],
            # 1.10.52 (review fix 1): the meaning and the recommended value of each setting of this popover.
            'settings': [
                (_t('[EC] Exclude from View Layer', '[EC] ビューレイヤーから除外'), _t('Shows the checkbox column that takes a collection out of the view layer (like the checkbox in the Outliner). Default and recommended: on.', 'コレクションをビューレイヤーから外すチェックの列を出します（アウトライナーのチェックと同じ）。既定・おすすめ：オン。')),
                (_t('[SS] Disable Selection', '[SS] 選択を無効化'), _t('Shows the arrow column that makes the objects of a collection unselectable. Default and recommended: on.', 'コレクションの物を選べなくする矢印の列を出します。既定・おすすめ：オン。')),
                (_t('[VV] Hide in Viewport', '[VV] ビューポートで非表示'), _t('Shows the eye column that hides a collection in the viewport for this view layer only. Default and recommended: on.', 'このビューレイヤーだけで、コレクションをビューポートから隠す目の列を出します。既定・おすすめ：オン。')),
                (_t('[DV] Disable in Viewports', '[DV] ビューポートで無効化'), _t('Shows the monitor column that switches a collection off in every viewport of every view layer. Default: off. Recommended: on only if you use that switch.', 'すべてのビューレイヤーのビューポートでコレクションを切るモニターの列を出します。既定：オフ。おすすめ：その切り替えを使う時だけオン。')),
                (_t('[RR] Disable in Renders', '[RR] レンダーで無効化'), _t('Shows the camera column that leaves a collection out of renders. Default: off. Recommended: on while you prepare renders.', 'コレクションをレンダーに出さないカメラの列を出します。既定：オフ。おすすめ：レンダーの準備をする間だけオン。')),
                (_t('[HH] Holdout', '[HH] ホールドアウト'), _t('Shows the Holdout column (the collection cuts a hole in the render). Default and recommended: off.', 'ホールドアウトの列を出します（そのコレクションがレンダーに穴を開けます）。既定・おすすめ：オフ。')),
                (_t('[IO] Indirect Only', '[IO] 間接のみ'), _t('Shows the Indirect Only column (Cycles: the collection appears only in reflections and light). Default and recommended: off.', '間接のみの列を出します（Cycles：そのコレクションは反射と光だけに出ます）。既定・おすすめ：オフ。')),
                (_t('Align Local Options', 'ローカルオプションを整列'), _t('Lines the local options of each row up in a column on the right. Default: off. Recommended: on when many columns are shown.', '各行のローカルの項目を、右の 1 列にそろえます。既定：オフ。おすすめ：列を多く出す時はオン。')),
            ],
            'check': [
                _t('The popup rows now show the chosen columns.', 'ポップアップの行に、選んだ列が出ます。'),
            ],
            'notes': [
                _t('These options change only what is shown, never the collections. Recommended: [EC] Exclude from View Layer, [SS] Disable Selection and [VV] Hide in Viewport on (the defaults).', '出し方を変えるだけで、コレクションは変えません。おすすめ：「[EC] ビューレイヤーから除外」「[SS] 選択を無効化」「[VV] ビューポートで非表示」をオン（既定のまま）。'),
            ],
        },
    }


def always_on_extra(_t) -> dict[str, list]:
    """Extra sections of the special always_on_toggles help."""
    return {
        'prep': [
            _t('Nothing to select. Change these only when you know you need or do not need a background feature.', '選ぶ物はありません。裏で動く機能が要る・要らないと分かっている時だけ変えます。'),
        ],
        'check': [
            _t('The tool groups (Collection Manager, GP Select) show "Disabled in Always-on Toggles" while their toggle is off.', 'オフにした道具（コレクションマネージャー・GP セレクト）のグループには「常時起動切り替えで無効」と出ます。'),
        ],
        'notes': [
            _t('Recommended: leave the defaults. Turn a toggle back on to restore the feature; nothing is deleted.', 'おすすめ：既定のまま。戻す時はもう一度オンにします。何も消しません。'),
            _t('Turning Browser server off stops new selector windows from opening.', '「ブラウザーサーバー」をオフにすると、新しいセレクターの画面が開きません。'),
        ],
    }
