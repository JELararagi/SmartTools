# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""「外部 Action（保管庫）」 child section of 「顔 ARKit」 (1.10.60; library choice kept by name since 1.10.61).

Switches an Action that the model moved out to an archive .blend back in, one at a time, through the
model's Action catalog (see action_catalog.py for the rules), and puts the original Actions, slots and
values back with one button.  The explanation is in the header ? help (topic ``ark_archive``).

Registered and unregistered by ark_face.register() / unregister().
"""

from __future__ import annotations

import json
import os

import bpy
from bpy.props import EnumProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup

from . import action_catalog as _cat

SCENE_PROP = 'smart_selector_suite_action_catalog'
HELP_TOPIC = 'ark_archive'
_MAX_ROWS = 40
_LAST = {'text': '', 'ok': True}
# Dynamic enum items must stay referenced while Blender may read them.
_ENUM_KEEP = {'target': []}


def _is_ja() -> bool:
    try:
        prefs = bpy.context.preferences
        if prefs is not None and not bool(getattr(prefs.view, 'use_translate_interface', True)):
            return False
    except Exception:
        pass
    try:
        return str(bpy.app.translations.locale or '').lower().startswith('ja')
    except Exception:
        return False


def _t(en: str, ja: str) -> str:
    return ja if _is_ja() else en


def _set_last(text: str, ok: bool) -> None:
    _LAST['text'] = text
    _LAST['ok'] = ok


def _props(context=None):
    try:
        return getattr((context or bpy.context).scene, SCENE_PROP, None)
    except Exception:
        return None


def _catalog_abspath(props) -> str:
    raw = str(getattr(props, 'catalog_path', '') or '')
    if not raw:
        return ''
    try:
        return bpy.path.abspath(raw)
    except Exception:
        return raw


def current_catalog(context=None):
    """(catalog or None, refusal or None) for the scene's chosen catalog."""
    props = _props(context)
    if props is None:
        return None, None
    path = _catalog_abspath(props)
    if not path:
        return None, None
    try:
        return _cat.read_catalog(path), None
    except _cat.CatalogError as exc:
        return None, exc


def legacy_block(context, script: str) -> list:
    """Legacy Texts (catalog dynamic_references) that a selector script would run; [] when none or no catalog."""
    cat, _err = current_catalog(context)
    return _cat.legacy_text_blocks(cat, script)


def _state(props) -> dict:
    try:
        st = json.loads(props.restore_json or '{}')
    except Exception:
        st = {}
    if not isinstance(st, dict):
        st = {}
    st.setdefault('records', [])
    st.setdefault('loaded', [])
    return st


def _store(props, st: dict) -> None:
    props.restore_json = json.dumps(st, ensure_ascii=False, separators=(',', ':')) if st.get('records') or st.get('loaded') else ''


def _library_search(self, context, edit_text):
    """Candidates for the Library field: the library names of the chosen catalog (1.10.61)."""
    cat, _err = current_catalog(context)
    if cat is None:
        return []
    needle = str(edit_text or '').lower()
    return [name for name in sorted(cat['libraries']) if not needle or needle in name.lower()]


def library_choice(props, cat) -> str:
    """The chosen library name when the catalog lists it; '' (all libraries) otherwise.

    1.10.60 kept the choice as a dynamic-enum index, so after switching to a catalog with fewer libraries the
    index matched nothing (a console WARNING on every draw) and with the same count it silently pointed at
    another library.  The name is kept now, and a name the catalog does not list means all libraries.
    """
    name = str(getattr(props, 'library_name', '') or '')
    if cat is None or name not in cat['libraries']:
        return ''
    return name


def _catalog_path_update(self, context):
    # A new catalog has its own libraries: start again from all of them.
    if self.library_name:
        self.library_name = ''


def _target_items(self, context):
    items = [
        ('SLOT', _t('By slot name', 'スロットの名前の相手'),
         _t('Assign each slot of the Action to the object / shape keys its slot is named after', 'Action の各スロットを、スロットの名前と同じオブジェクト・シェイプキーに割り当てます')),
        ('ACTIVE', _t('Active object', 'アクティブなオブジェクト'),
         _t('Assign the Action to the active object (or its shape keys, for a shape-key Action)', 'Action をアクティブなオブジェクト（シェイプキーの Action ならそのシェイプキー）に割り当てます')),
    ]
    _ENUM_KEEP['target'] = items
    return items


class SSSUITE_ActionCatalogProps(PropertyGroup):
    catalog_path: StringProperty(
        name='Action Catalog', subtype='FILE_PATH', default='', update=_catalog_path_update,
        description='JSON Action catalog of this model (portable_libraries / external_actions). Only libraries it declares, with a matching SHA-256, are opened')
    # 1.10.61: a library NAME.  1.10.60 used the dynamic EnumProperty library_filter, whose stored index outlived the catalog.
    library_name: StringProperty(name='Library', default='', search=_library_search, search_options={'SORT', 'SUGGESTION'},
                                 description='Show only the Actions of this archive library (empty: all libraries)')
    name_filter: StringProperty(name='Filter', default='', options={'TEXTEDIT_UPDATE'}, description='Show only Actions whose name contains this text')
    target_mode: EnumProperty(name='Assign to', items=_target_items, description='Which data block receives the Action')
    restore_json: StringProperty(name='Restore State', default='', options={'HIDDEN'},
                                 description='Original Actions, slots and values recorded before the first switch (JSON)')


def _targets(context, action, mode: str) -> list:
    """[(id_block, slot)] for ``action``; CatalogError when nothing suitable is found."""
    data = bpy.data
    slots = list(action.slots)
    if not slots:
        raise _cat.CatalogError('no_slot', 'Action "%s" has no slot' % action.name, 'Action「%s」にスロットがありません' % action.name)
    pairs = []
    if mode == 'ACTIVE':
        ob = getattr(context, 'active_object', None)
        if ob is None:
            raise _cat.CatalogError('no_active', 'No active object', 'アクティブなオブジェクトがありません')
        obdata = getattr(ob, 'data', None)
        keys = getattr(obdata, 'shape_keys', None)
        data_type = str(getattr(obdata, 'id_type', '') or '') if obdata is not None else ''
        cand = []
        for sl in slots:
            if sl.target_id_type == 'KEY' and keys is not None:
                cand.append((keys, sl))
            elif sl.target_id_type in {'OBJECT', 'UNSPECIFIED'}:
                cand.append((ob, sl))
            elif data_type and sl.target_id_type == data_type and getattr(obdata, 'library', None) is None:
                cand.append((obdata, sl))
        if len(cand) > 1:
            named = [c for c in cand if c[1].name_display == c[0].name]
            cand = named if len(named) == 1 else cand
        if len(cand) != 1:
            raise _cat.CatalogError('ambiguous_slot', 'Action "%s" has %d slots that fit "%s"; use "By slot name"' % (action.name, len(cand), ob.name),
                                    'Action「%s」に「%s」に合うスロットが %d 個あります。「スロットの名前の相手」を使ってください' % (action.name, ob.name, len(cand)))
        return cand
    for sl in slots:
        coll = _cat.id_collection(data, sl.target_id_type)
        if coll is None:
            continue
        for idb in coll:
            if idb.name == sl.name_display and idb.library is None:
                pairs.append((idb, sl))
                break
    if not pairs:
        raise _cat.CatalogError('no_target', 'No object / shape keys named after the slots of "%s" in this file' % action.name,
                                'Action「%s」のスロットの名前のオブジェクト・シェイプキーがこのファイルにありません' % action.name)
    return pairs


def _redraw() -> None:
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in {'VIEW_3D', 'GRAPH_EDITOR', 'DOPESHEET_EDITOR'}:
                    area.tag_redraw()
    except Exception:
        pass


def _can_relative(blend_path: str, lib_path: str) -> bool:
    """A relative library path only when the .blend is saved on the same drive (else Blender warns and keeps it absolute)."""
    if not blend_path:
        return False
    a = os.path.splitdrive(os.path.abspath(blend_path))[0].lower()
    b = os.path.splitdrive(os.path.abspath(lib_path))[0].lower()
    return a == b


def apply_action(context, action_name: str) -> dict:
    """The whole switch, with rollback.  Returns a report dict; raises CatalogError on refusal."""
    data = bpy.data
    props = _props(context)
    if props is None:
        raise _cat.CatalogError('no_scene', 'No scene', 'シーンがありません')
    cat = _cat.read_catalog(_catalog_abspath(props))
    plan = _cat.plan_load(cat, action_name, _cat.existing_actions(data))
    act, newly = _cat.link_action(data, plan, relative=_can_relative(data.filepath, plan['path']))
    request = []          # (id, fresh record) for rollback of this request only
    try:
        pairs = _targets(context, act, str(props.target_mode))
        for idb, _sl in pairs:
            _cat.check_target(idb)
        for idb, sl in pairs:
            request.append((idb, _cat.snapshot(idb, act, sl)))
        for idb, sl in pairs:
            _cat.protect_current(idb)
            _cat.assign(idb, act, sl)
    except Exception:
        for idb, rec in reversed(request):
            try:
                _cat.restore(data, rec)
            except Exception:
                pass
        if newly:
            try:
                _cat.remove_if_unused(data, act)
            except Exception:
                pass
        raise
    st = _state(props)
    by_key = {(r['id_type'], r['id_name']): r for r in st['records']}
    for idb, rec in request:
        key = (rec['id_type'], rec['id_name'])
        if key in by_key:
            # Keep the first (original) record; only add values the earlier switches did not cover.
            seen = {(v[0], v[1]) for v in by_key[key]['values']}
            by_key[key]['values'].extend(v for v in rec['values'] if (v[0], v[1]) not in seen)
        else:
            st['records'].append(rec)
            by_key[key] = rec
    entry = [act.name, plan['path']]
    if entry not in st['loaded']:
        st['loaded'].append(entry)
    _store(props, st)
    return {'action': act.name, 'library': plan['library'], 'targets': [i.name for i, _s in pairs], 'linked': newly}


def restore_all(context) -> dict:
    data = bpy.data
    props = _props(context)
    st = _state(props)
    for rec in st['records']:
        idb = _cat.resolve_id(data, rec)
        if idb is not None:
            _cat.check_target(idb)
    problems = []
    for rec in reversed(st['records']):
        problems.extend(_cat.restore(data, rec))
    removed = 0
    for name, lib in st['loaded']:
        act = _cat.find_action(data, name, lib)
        if act is not None and _cat.remove_if_unused(data, act):
            removed += 1
    _store(props, {'records': [], 'loaded': []})
    return {'records': len(st['records']), 'removed': removed, 'problems': problems}


class SSSUITE_OT_action_catalog_apply(Operator):
    bl_idname = 'smart_selector_suite.action_catalog_apply'
    bl_label = 'Switch to Archived Action'
    bl_options = {'UNDO', 'INTERNAL'}
    action_name: StringProperty(name='Action', default='', options={'SKIP_SAVE'}, description='Catalog name of the Action to switch to')

    @classmethod
    def description(cls, context, properties):
        return _t('Link this one Action from its archive library (SHA-256 checked) and assign it. The original Action, slot and values are kept for Restore',
                  'この Action を 1 つだけ保管庫のライブラリから（SHA-256 を確かめて）リンクし、割り当てます。元の Action・スロット・値は「元に戻す」のために控えます')

    def execute(self, context):
        try:
            rep = apply_action(context, self.action_name)
        except _cat.CatalogError as exc:
            _set_last(exc.text(_is_ja()), False)
            self.report({'WARNING'}, exc.text(_is_ja()))
            _redraw()
            return {'CANCELLED'}
        except Exception as exc:
            msg = _t('Switch failed, put back: %s' % exc, '切り替えに失敗したので元に戻しました：%s' % exc)
            _set_last(msg, False)
            self.report({'WARNING'}, msg)
            _redraw()
            return {'CANCELLED'}
        names = ', '.join(rep['targets'])
        _set_last(_t('"%s" → %s' % (rep['action'], names), '「%s」→ %s' % (rep['action'], names)), True)
        _redraw()
        return {'FINISHED'}


class SSSUITE_OT_action_catalog_restore(Operator):
    bl_idname = 'smart_selector_suite.action_catalog_restore'
    bl_label = 'Restore Original Actions'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def description(cls, context, properties):
        return _t('Put back the Actions, slots and values recorded before the first switch, and unlink the archived Actions nothing uses',
                  '最初の切り替えの前に控えた Action・スロット・値を戻し、使われなくなった保管庫の Action のリンクを外します')

    @classmethod
    def poll(cls, context):
        props = _props(context)
        if props is None or not props.restore_json:
            cls.poll_message_set(_t('Nothing switched', '切り替えた物がありません'))
            return False
        return True

    def execute(self, context):
        try:
            rep = restore_all(context)
        except _cat.CatalogError as exc:
            _set_last(exc.text(_is_ja()), False)
            self.report({'WARNING'}, exc.text(_is_ja()))
            _redraw()
            return {'CANCELLED'}
        if rep['problems']:
            msg = _t('Restored with %d problem(s): %s' % (len(rep['problems']), '; '.join(rep['problems'][:3])),
                     '戻しましたが %d 件戻せませんでした：%s' % (len(rep['problems']), '、'.join(rep['problems'][:3])))
            _set_last(msg, False)
            self.report({'WARNING'}, msg)
        else:
            _set_last(_t('Restored %d target(s)' % rep['records'], '%d 個を元に戻しました' % rep['records']), True)
        _redraw()
        return {'FINISHED'}


def draw(layout, context) -> None:
    props = _props(context)
    col = layout.column(align=True)
    if props is None:
        return
    col.prop(props, 'catalog_path', text=_t('Catalog', 'カタログ'))
    cat, err = current_catalog(context)
    if err is not None:
        row = col.row(align=True)
        row.alert = True
        row.label(text=err.text(_is_ja()), icon='ERROR')
    if cat is not None:
        col.label(text=_t('%d archived Actions in %d libraries' % (len(cat['actions']), len(cat['libraries'])),
                          '保管庫の Action %d 個（ライブラリ %d 本）' % (len(cat['actions']), len(cat['libraries']))), icon='LIBRARY_DATA_DIRECT')
        col.prop(props, 'library_name', text=_t('Library', 'ライブラリ'), icon='LIBRARY_DATA_DIRECT',
                 placeholder=_t('All libraries', '全部のライブラリ'))
        lib = library_choice(props, cat)
        if props.library_name and not lib:
            col.label(text=_t('"%s" is not in this catalog: all libraries shown' % props.library_name,
                              '「%s」はこのカタログにないので、全部のライブラリを出しています' % props.library_name))
        col.prop(props, 'name_filter', text='', icon='VIEWZOOM')
        row = col.row(align=True)
        row.prop(props, 'target_mode', expand=True)
        needle = str(props.name_filter or '').lower()
        names = [n for n, e in sorted(cat['actions'].items())
                 if (not lib or e['library'] == lib) and (not needle or needle in n.lower())]
        box = col.box()
        sub = box.column(align=True)
        for n in names[:_MAX_ROWS]:
            op = sub.operator(SSSUITE_OT_action_catalog_apply.bl_idname, text=n, icon='ACTION', translate=False)
            op.action_name = n
        if not names:
            sub.label(text=_t('No Action matches', '合う Action がありません'))
        elif len(names) > _MAX_ROWS:
            sub.label(text=_t('… %d more; narrow the filter' % (len(names) - _MAX_ROWS), '…ほか %d 個。絞り込んでください' % (len(names) - _MAX_ROWS)))
    st = _state(props)
    row = col.row(align=True)
    row.operator(SSSUITE_OT_action_catalog_restore.bl_idname,
                 text=_t('Restore originals (%d)' % len(st['records']), '元に戻す（%d）' % len(st['records'])), icon='LOOP_BACK')
    if _LAST['text']:
        row = col.row(align=True)
        row.alert = not _LAST['ok']
        row.label(text=_LAST['text'][:300], icon='CHECKMARK' if _LAST['ok'] else 'ERROR')


# --------------------------------------------------------------------------- translations (property tooltips)
_JA = {
    'Action Catalog': 'Action カタログ',
    'JSON Action catalog of this model (portable_libraries / external_actions). Only libraries it declares, with a matching SHA-256, are opened':
        'このモデルの Action カタログ（JSON。portable_libraries・external_actions）。そこに書かれ SHA-256 が一致するライブラリだけを開きます',
    'Library': 'ライブラリ',
    'Show only the Actions of this archive library (empty: all libraries)': 'この保管庫のライブラリの Action だけを出します（空欄なら全部のライブラリ）',
    'Filter': '絞り込み',
    'Show only Actions whose name contains this text': '名前にこの文字を含む Action だけを出します',
    'Assign to': '割り当て先',
    'Which data block receives the Action': 'Action を受け取るデータ',
    'Restore State': '戻すための控え',
    'Original Actions, slots and values recorded before the first switch (JSON)': '最初の切り替えの前に控えた元の Action・スロット・値（JSON）',
    'Action': 'Action',
    'Catalog name of the Action to switch to': '切り替える Action のカタログの名前',
    'Switch to Archived Action': '保管庫の Action に切り替える',
    'Restore Original Actions': '元の Action に戻す',
}
_TR_KEY = __name__ + '.action_catalog'


def _translations() -> dict:
    table = {}
    for en, ja in _JA.items():
        table[('*', en)] = ja
        table[('Operator', en)] = ja
    return {'ja_JP': table}


classes = (
    SSSUITE_ActionCatalogProps,
    SSSUITE_OT_action_catalog_apply,
    SSSUITE_OT_action_catalog_restore,
)


def register() -> None:
    for cls in classes:
        existing = getattr(bpy.types, cls.__name__, None)
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        bpy.utils.register_class(cls)
    setattr(bpy.types.Scene, SCENE_PROP, PointerProperty(
        type=SSSUITE_ActionCatalogProps, name='Smart Selector Action Catalog',
        description='Action catalog and restore state of the Smart Selector external Action section. Saved with the scene'))
    try:
        bpy.app.translations.unregister(_TR_KEY)
    except Exception:
        pass
    try:
        bpy.app.translations.register(_TR_KEY, _translations())
    except Exception:
        pass


def unregister() -> None:
    try:
        bpy.app.translations.unregister(_TR_KEY)
    except Exception:
        pass
    try:
        if hasattr(bpy.types.Scene, SCENE_PROP):
            delattr(bpy.types.Scene, SCENE_PROP)
    except Exception:
        pass
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _ENUM_KEEP['target'] = []
    _set_last('', True)
    _cat.clear_caches()
