import json
import re
import sys
from pathlib import Path
import bpy
from .translation import exception_text
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty
PACKAGE_ID = 'smart_selector_suite'
ADDON_NAME = 'Smart_Selector_Suite'
TOOL_LABEL_EN = 'Smart Selector'
TOOL_LABEL_JA = 'スマートセレクター'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'
_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_TRANSLATIONS = {('*', 'Help'): 'ヘルプ', ('*', 'Open Help'): 'ヘルプを開く', ('*', 'Feature Overview'): '機能概要', ('*', 'Usage'): '使用方法', ('*', 'Settings'): '設定項目', ('*', 'Commands'): 'コマンド', ('*', 'Always-on Toggle'): '常時起動切り替え', ('*', 'Enabled'): '有効', ('*', 'Disabled'): '無効', ('*', 'Save Preferences'): 'プリファレンスを保存', ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。', ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。', ('*', TOOL_LABEL_EN): TOOL_LABEL_JA}

def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and (not bool(getattr(view, 'use_translate_interface', True))):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False

def text(en, ja=None, context=None):
    return str(ja if ja is not None and _ui_is_japanese(context) else en)

def package_root():
    return Path(__file__).resolve().parent

def storage_root(create=True):
    try:
        from . import utils as _utils
        return _utils.extension_user_root(create=create)
    except Exception:
        pass
    try:
        from . import storage as _storage
        root = _storage.extension_user_root(create=create)
    except Exception:
        try:
            import os
            version = getattr(getattr(bpy, 'app', None), 'version', (5, 1))
            version_text = f'{int(version[0])}.{int(version[1])}' if version and len(version) >= 2 else '5.1'
            if os.name == 'nt':
                roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
                root = Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'config' / ADDON_NAME
            elif sys.platform == 'darwin':
                root = Path.home() / 'Library' / 'Application Support' / 'Blender' / version_text / 'config' / ADDON_NAME
            else:
                root = Path.home() / '.config' / 'blender' / version_text / 'config' / ADDON_NAME
        except Exception:
            root = Path.home() / '.config' / 'blender' / '5.1' / 'config' / ADDON_NAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root

def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(bool(create_parent)).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path

def settings_path():
    try:
        from . import settings as _settings
        return _settings.settings_path()
    except Exception:
        return storage_path('settings', 'Smart_Selector_Suite', 'Smart_Selector_Suite.json')

def _load_previews():
    return None

def icon_value(name, fallback=0):
    return int(fallback or 0)

def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None

def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}

_DETAIL_HELP_POPUP_WIDTH = 680

def _wrap_lines(value, width_px, context):
    from .help import _wrap_pixels

    lines = []
    for paragraph in str(value or '').splitlines():
        lines.extend(_wrap_pixels(paragraph, width_px, context) or [''])
    return lines

def _draw_wrapped(layout, context, value, width_px):
    for line in _wrap_lines(value, width_px, context):
        if line:
            layout.label(text=line)
        else:
            layout.separator(factor=0.35)

def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []

class SMART_SELECTOR_OT_open_help(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'
    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            if bool(getattr(bpy.app, 'background', False)) or context is None or getattr(context, 'window', None) is None:
                return self.execute(context)
            wm = getattr(context, 'window_manager', None)
            if wm is None:
                return self.execute(context)
            return wm.invoke_popup(self, width=_DETAIL_HELP_POPUP_WIDTH)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .help import _estimate_text_width_px, _ui_scale

        layout = self.layout
        scale = _ui_scale(context)
        dialog_px = round(_DETAIL_HELP_POPUP_WIDTH * scale)
        if context.window:
            dialog_px = min(dialog_px, context.window.width)
        width_px = _estimate_text_width_px(context, dialog_px)
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            from . import guide
            group = guide.get_group(topic)
        except Exception as exc:
            group = {'title_en': TOOL_LABEL_EN + ' Help', 'title_ja': TOOL_LABEL_JA + ' ヘルプ', 'overview_en': ['The help catalog could not be loaded: ' + str(exc)], 'overview_ja': ['ヘルプカタログを読み込めませんでした: ' + str(exc)], 'usage_en': [], 'usage_ja': [], 'settings': [], 'operators': []}
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text='', icon='QUESTION')
        row.label(text=str(title))
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='QUESTION')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item, width_px)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item, width_px)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and (not ops):
            _draw_wrapped(box, context, text('No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.', 'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。', context), width_px)
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc), width_px)
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc), width_px)

class SMART_SELECTOR_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_options = {'UNDO'}
    bl_description = 'Set an always-on feature to enabled or disabled. The save timing follows N-panel State Save.'
    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, exception_text(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, exception_text(exc))
        try:
            save_persistent_settings(context, force=True)
        except Exception:
            pass
        return {'FINISHED'}

class SMART_SELECTOR_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_options = set()
    _sms_no_undo = True
    bl_description = 'Save current Smart Selector N-panel settings to Smart_Selector_Suite.json and request Blender to save user preferences.'

    def execute(self, context):
        save_persistent_settings(context, force=True)
        try:
            from . import settings as _settings
            _settings.save_state(force=True)
            flush = getattr(_settings, 'flush_user_preferences_save', None)
            if callable(flush):
                flush()
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}

def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []

def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()

def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False

def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID

def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))

def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw

def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return '_SUITE_OT_OPEN_HELP' in upper or '_SUITE_OT_SET_ALWAYS_ON' in upper or '_SUITE_PT_ROOT' in upper or ('_SUITE_PT_ALWAYS_ON' in upper)

def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = ('BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty', 'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty', 'PointerProperty', 'StringProperty')
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and ('(' in value):
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls

def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False

def _flatten_npanel_parent_before_register(cls):
    """Keep all SmartTools N-panel sections horizontally aligned.

    Blender indents Panel classes that use ``bl_parent_id``.  In a deep or
    lazily loaded SmartTools UI this compounds every time a child/grandchild
    section is exposed.  Flatten only sidebar (``bl_region_type == 'UI'``)
    panels before registration; non-sidebar panels keep their native parents.
    """
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            if str(getattr(cls, 'bl_region_type', '') or '') == 'UI':
                if str(getattr(cls, 'bl_parent_id', '') or ''):
                    cls.bl_parent_id = ''
    except Exception:
        pass
    return cls

def _register_class_wrapper(cls):
    _flatten_npanel_parent_before_register(cls)
    _materialize_annotations(cls)
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type) and existing is not cls:
            if _same_package_class(existing) or _old_generated_name(getattr(existing, '__name__', '')):
                _safe_unregister_class(existing)
    except Exception:
        pass
    try:
        return _ORIGINAL_REGISTER_CLASS(cls)
    except ValueError:
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
            if isinstance(existing, type):
                _safe_unregister_class(existing)
        except Exception:
            pass
        return _ORIGINAL_REGISTER_CLASS(cls)

def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    try:
        _ORIGINAL_REGISTER_CLASS = bpy.utils.register_class
        pass
    except Exception:
        _ORIGINAL_REGISTER_CLASS = None

def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    if _ORIGINAL_REGISTER_CLASS is not None:
        try:
            pass
        except Exception:
            pass
    _ORIGINAL_REGISTER_CLASS = None

def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and (not (module_name == prefix or module_name.startswith(prefix + '.'))):
            continue
        yield cls

def _is_always_panel(cls):
    value = ' '.join((str(getattr(cls, '__name__', '') or ''), str(getattr(cls, 'bl_idname', '') or ''), str(getattr(cls, 'bl_label', '') or ''))).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value

def _purge_standalone_always_on_panels():
    """Remove legacy standalone always-on panels; the UI lives in the root Smart Selector panel."""
    target_names = {'SMART_SELECTOR_PT_always_on', 'SMART_SELECTOR_SUITE_PT_always_on', 'SSSUITE_PT_always_on_toggles', 'SSSUITE_PT_always_on_switches'}
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    for cls in values:
        if not isinstance(cls, type):
            continue
        class_name = str(getattr(cls, '__name__', '') or '')
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
        if class_name in target_names or bl_idname in target_names:
            _safe_unregister_class(cls)

def _patch_panel_headers():
    """Compatibility no-op. Process-global patching and name-based purge are intentionally disabled."""
    return None

def _unpatch_panel_headers():
    """Compatibility no-op. Process-global patching and name-based purge are intentionally disabled."""
    return None

def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and (not (module_name == prefix or module_name.startswith(prefix + '.'))):
            continue
        yield cls

def _patch_addon_preferences():
    """Compatibility no-op. Process-global patching and name-based purge are intentionally disabled."""
    return None

def _unpatch_addon_preferences():
    """Compatibility no-op. Process-global patching and name-based purge are intentionally disabled."""
    return None

def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None

def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots

def _owner_rna_identifier(owner) -> str:
    try:
        return str(getattr(getattr(owner, 'rna_type', None), 'identifier', '') or '')
    except Exception:
        return ''

def _owner_module_name(owner) -> str:
    try:
        return str(getattr(type(owner), '__module__', '') or '')
    except Exception:
        return ''

def _is_smart_selector_property_group(owner) -> bool:
    module_name = _owner_module_name(owner).lower()
    prefix = _module_prefix().lower()
    return bool(prefix and module_name.startswith(prefix))

def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if not lower or lower == 'rna_type':
        return False
    owner_id = _owner_rna_identifier(owner)
    if owner_id == 'WindowManager':
        allowed = {_ALWAYS_ON_PROP.lower(), 'smart_selector_suite_npanel_settings', 'smart_selector_suite_bridge_payloads', 'smart_selector_suite_always_on_toggle_state'}
        return lower in allowed
    if owner_id == 'Scene':
        return False
    if _is_smart_selector_property_group(owner):
        return True
    return False

def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data

def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload

def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if _owner_rna_identifier(obj) == 'Scene' and key in {'smart_selector_suite_active_project', 'smart_selector_suite_show_favorites_only'}:
                continue
            if not hasattr(obj, key):
                continue
            current_value = getattr(obj, key, None)
            if not _prop_relevant(key, current_value, obj):
                continue
            if isinstance(value, dict):
                child = current_value
                if child is not None:
                    _apply_group(child, value, depth + 1)
            else:
                setattr(obj, key, value)
        except Exception:
            pass

def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)

def load_settings_file():
    global _LOADED_SETTINGS
    try:
        from . import settings as _settings
        raw = _settings.get_value('persistent_rna_state', {})
        if isinstance(raw, dict):
            _LOADED_SETTINGS = dict(raw)
            scene_state = _LOADED_SETTINGS.get('scene')
            if isinstance(scene_state, dict):
                scene_state = dict(scene_state)
                scene_state.pop('smart_selector_suite_active_project', None)
                scene_state.pop('smart_selector_suite_show_favorites_only', None)
                if scene_state:
                    _LOADED_SETTINGS['scene'] = scene_state
                else:
                    _LOADED_SETTINGS.pop('scene', None)
            return _LOADED_SETTINGS
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}

def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        from . import settings as _settings
        _settings.set_value('persistent_rna_state', data, save_preferences=False)
        if force:
            _settings.save_state(force=True)
    except Exception:
        pass

def _autosave_timer():
    try:
        save_persistent_settings(bpy.context)
    except Exception:
        pass
    return 5.0

def _delayed_load_apply():
    try:
        apply_persistent_settings(bpy.context)
    except Exception:
        pass
    return None

@persistent
def _load_pre_handler(*_args):
    """Flush deferred N-panel state before the current scene is closed."""
    try:
        save_persistent_settings(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    try:
        from . import settings as _settings
        _settings.save_state(force=True)
    except Exception:
        pass

@persistent
def _load_post_handler(*_args):
    try:
        try:
            from . import settings as _settings
            _settings.reload_state()
        except Exception:
            pass
        try:
            from . import always_on as _always_on
            reset = getattr(_always_on, 'reset_state_cache', None)
            if callable(reset):
                reset()
            apply_all = getattr(_always_on, 'apply_all', None)
            if callable(apply_all):
                apply_all(getattr(bpy, 'context', None))
        except Exception:
            pass
        load_settings_file()
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None:
            try:
                if hasattr(timers, 'is_registered') and (not timers.is_registered(_delayed_load_apply)):
                    timers.register(_delayed_load_apply, first_interval=0.25)
                elif not hasattr(timers, 'is_registered'):
                    timers.register(_delayed_load_apply, first_interval=0.25)
            except Exception:
                apply_persistent_settings(bpy.context)
        else:
            apply_persistent_settings(bpy.context)
    except Exception:
        pass

def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass

def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass

def register():
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(name='Always-on', description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.', default=False))
    except Exception:
        pass
    for cls in (SMART_SELECTOR_OT_open_help, SMART_SELECTOR_OT_set_always_on, SMART_SELECTOR_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    _purge_standalone_always_on_panels()
    load_settings_file()
    try:
        apply_persistent_settings(bpy.context)
    except Exception:
        pass
    _append_handler_once(bpy.app.handlers.load_pre, _load_pre_handler)
    _append_handler_once(bpy.app.handlers.load_post, _load_post_handler)
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _patch_panel_headers()
    _patch_addon_preferences()

def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    try:
        from . import settings as _settings
        _settings.save_state(force=True)
    except Exception:
        pass
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_delayed_load_apply):
            timers.unregister(_delayed_load_apply)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_pre, _load_pre_handler)
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    try:
        if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    _remove_previews()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()
