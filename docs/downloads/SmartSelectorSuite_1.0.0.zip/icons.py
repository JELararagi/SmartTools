# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Standard-first icon routing for Smart Selector Suite.

Blender's built-in UI icons are used whenever they communicate the target
function clearly. Custom preview PNGs are loaded only for concepts that do not
have a sufficiently specific built-in shape.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict

import bpy

try:
    import bpy.utils.previews as _previews
except Exception:  # pragma: no cover - Blender-only module outside Blender
    _previews = None

_ICON_PREVIEW_KEY = 'smart_selector_suite_icons'
_PREVIEW_COLLECTIONS: Dict[str, object] = {}

# Custom PNGs. Every file listed here is actively referenced by UI draw code.
_ICON_FILES = {
    'smart_selector': 'smart_selector.png',
    'selector_list': 'selector_list.png',
    'rename': 'rename.png',
    'archive': 'archive.png',
    'bridge': 'bridge.png',
}

# Logical-token defaults used only when a caller does not supply a Blender
# fallback icon. Call sites that pass a Blender icon keep that exact standard
# icon unless the logical token is one of the custom PNGs above.
_FALLBACK_BLENDER_ICONS = {
    'smart_selector': 'RESTRICT_SELECT_OFF',
    'always_on': 'TIME',
    'clock': 'TIME',
    'project': 'FILE_FOLDER',
    'selector_list': 'PRESET',
    'folder': 'FILE_FOLDER',
    'add': 'ADD',
    'rename': 'FILE_REFRESH',
    'duplicate': 'DUPLICATE',
    'archive': 'TRASH',
    'trash': 'TRASH',
    'favorite_on': 'SOLO_ON',
    'favorite_off': 'SOLO_OFF',
    'play': 'PLAY',
    'edit': 'GREASEPENCIL',
    'help': 'QUESTION',
    'settings': 'PREFERENCES',
    'bridge': 'URL',
    'undo': 'LOOP_BACK',
    'redo': 'LOOP_FORWARDS',
    'apply': 'CHECKMARK',
    'shapekey': 'SHAPEKEY_DATA',
    'property': 'RNA',
    'script': 'TEXT',
    'collection': 'OUTLINER_COLLECTION',
    'gp_select': 'GREASEPENCIL',
    'menu': 'MENU_PANEL',
    'lock': 'LOCKED',
    'cancel': 'X',
    'visibility': 'HIDE_OFF',
    'hidden': 'HIDE_ON',
    'select': 'RESTRICT_SELECT_OFF',
    'render': 'RESTRICT_RENDER_OFF',
    'group': 'GROUP',
    'material': 'MATERIAL',
    'bone': 'BONE_DATA',
    'layer': 'OUTLINER_DATA_GP_LAYER',
    'move_up': 'TRIA_UP_BAR',
    'move_down': 'TRIA_DOWN_BAR',
    'search': 'VIEWZOOM',
    'time': 'TIME',
    'brush': 'STROKE',
    'weight': 'WPAINT_HLT',
    'file': 'CURRENT_FILE',
    'send': 'FORWARD',
    'header': 'RESTRICT_SELECT_OFF',
}

# Deliberately do not remap Blender icon names to custom files. If code asks
# for a built-in icon, the built-in icon is rendered.
_BLENDER_ICON_TO_CUSTOM = {}


def _asset_dir() -> Path:
    return Path(__file__).resolve().parent / 'icons'


def _preview_collection():
    return _PREVIEW_COLLECTIONS.get(_ICON_PREVIEW_KEY)


def _should_use_custom(name: str) -> bool:
    return str(name or '').strip() in _ICON_FILES


def register() -> None:
    if _previews is None:
        return
    if _preview_collection() is not None:
        return
    pcoll = _previews.new()
    base = _asset_dir()
    for icon_name, filename in _ICON_FILES.items():
        path = base / filename
        if not path.exists():
            continue
        try:
            pcoll.load(icon_name, str(path), 'IMAGE', True)
        except Exception:
            pass
    _PREVIEW_COLLECTIONS[_ICON_PREVIEW_KEY] = pcoll


def unregister() -> None:
    if _previews is None:
        _PREVIEW_COLLECTIONS.clear()
        return
    for pcoll in tuple(_PREVIEW_COLLECTIONS.values()):
        try:
            _previews.remove(pcoll)
        except Exception:
            pass
    _PREVIEW_COLLECTIONS.clear()


def icon_value(name: str) -> int:
    name = str(name or '').strip()
    if not _should_use_custom(name):
        return 0
    pcoll = _preview_collection()
    if pcoll is None:
        return 0
    try:
        icon = pcoll.get(name)
        return int(getattr(icon, 'icon_id', 0) or 0) if icon is not None else 0
    except Exception:
        return 0


def fallback_icon(name: str, default: str = 'NONE') -> str:
    default = str(default or '').strip() or 'NONE'
    if default.upper() != 'NONE' and default == default.upper():
        return default
    mapped = _FALLBACK_BLENDER_ICONS.get(str(name or '').strip(), '')
    if mapped:
        return mapped
    return 'NONE' if default.upper() == 'NONE' else default


def kwargs(name: str, fallback: str = 'NONE') -> dict:
    name = str(name or '').strip()
    value = icon_value(name)
    if value:
        return {'icon_value': value}
    return {'icon': fallback_icon(name, fallback)}


def custom_name_for_blender_icon(icon: str) -> str:
    return _BLENDER_ICON_TO_CUSTOM.get(str(icon or '').strip(), '')


def kwargs_for_blender_icon(icon: str, default: str = 'NONE') -> dict:
    standard = str(icon or default or 'NONE').strip() or 'NONE'
    if _should_use_custom(standard):
        return kwargs(standard, fallback_icon(standard, str(default or 'NONE').strip() or 'NONE'))
    if standard in _FALLBACK_BLENDER_ICONS and standard.upper() != standard:
        return {'icon': fallback_icon(standard, 'NONE')}
    custom_name = custom_name_for_blender_icon(standard)
    if custom_name:
        return kwargs(custom_name, standard)
    return {'icon': standard}
