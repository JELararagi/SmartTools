# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

CONTRACT_VERSION = 1
EXTENSION_ID = 'smart_selector_suite'
CONFIG_FOLDER = 'Smart_Selector_Suite'
CONFIG_FILE = 'Smart_Selector_Suite.json'
STATE_SAVE_PATH = 'window_manager.smart_selector_suite_always_on_toggle_state.npanel_state_save'
SECTION_OPEN_PATH = 'window_manager.smart_selector_suite_npanel_settings.show_always_on_toggles'
RUNTIME_TOGGLE_PATHS = (
    'window_manager.smart_selector_suite_always_on_toggle_state.collection_manager_state_handlers',
    'window_manager.smart_selector_suite_always_on_toggle_state.collection_manager_object_menu',
    'window_manager.smart_selector_suite_always_on_toggle_state.collection_manager_popup_hotkey',
    'window_manager.smart_selector_suite_always_on_toggle_state.collection_manager_disable_objects_override',
    'window_manager.smart_selector_suite_always_on_toggle_state.qcd_system',
    'window_manager.smart_selector_suite_always_on_toggle_state.qcd_view_hotkeys',
    'window_manager.smart_selector_suite_always_on_toggle_state.qcd_edit_mode_hotkeys',
    'window_manager.smart_selector_suite_always_on_toggle_state.qcd_header_widget',
    'window_manager.smart_selector_suite_always_on_toggle_state.legacy_proxy_cleanup',
    # On-demand resident services are still canonical Always-on controls: OFF
    # prevents creation and immediately tears down any currently owned runtime.
    'window_manager.smart_selector_suite_always_on_toggle_state.gp_select_weight_cleanup_handlers',
    'window_manager.smart_selector_suite_always_on_toggle_state.smart_selector_browser_server',
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = (
    'VIEW3D_PT_smart_selector_suite_root',
    'IMAGE_PT_smart_selector_suite_root',
    'NODE_PT_smart_selector_suite_root',
    'SEQUENCER_PT_smart_selector_suite_root',
    'CLIP_PT_smart_selector_suite_root',
    'DOPESHEET_PT_smart_selector_suite_root',
    'GRAPH_PT_smart_selector_suite_root',
    'NLA_PT_smart_selector_suite_root',
    'TEXT_PT_smart_selector_suite_root',
    'FILEBROWSER_PT_smart_selector_suite_root',
    'SPREADSHEET_PT_smart_selector_suite_root',
)
PERSISTENCE_ROOTS = (
    'window_manager.smart_selector_suite_always_on_toggle_state',
    'window_manager.smart_selector_suite_npanel_settings',
    'window_manager.smart_selector_suite_bridge_payloads',
    'scene.smart_selector_suite_active_project',
    'scene.smart_selector_suite_show_favorites_only',
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    'scene.collection_manager',
    'scene.gp_renamer_props',
)
EXCLUDED_TRANSIENT_PATHS = (
    # Built-in PropertyGroup metadata.  The seven editable GP Renamer values
    # use JSON-backed custom getters/setters; ``name`` is not one of them and
    # must not be advertised as an N-panel setting.
    'scene.gp_renamer_props.name',
    'scene.collection_manager.name',
    'window_manager.smart_selector_suite_always_on_toggle_state.name',
    'window_manager.smart_selector_suite_npanel_settings.name',
    'window_manager.smart_selector_suite_bridge_payloads.name',
)
