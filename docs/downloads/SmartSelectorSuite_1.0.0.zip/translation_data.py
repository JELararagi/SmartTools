# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Redistribution, modification, resale, or relicensing is prohibited without
# explicit permission from the rights holder.
# ------------------------------------------------------------------------------
# translation_data.py

blender_translations = {'ja_JP': {('*', '(No data available)'): '(データがありません)',
           ('*', 'Allow Execute Script'): 'スクリプト実行を許可',
           ('*', 'Allow selector buttons to execute custom Python scripts from the browser. Turn OFF for safety when sharing files or when you only need selection/slider actions.'): 'ブラウザのボタンからカスタムPythonスクリプトを実行することを許可します。共有データを使う時や、選択/スライダー操作だけで十分な場合はOFF推奨です。',
           ('*', 'Apply Selection'): '選択を適用',
           ('*', 'Archive Project'): 'プロジェクトをアーカイブ',
           ('*', 'Backup Generations'): 'バックアップ世代数',
           ('*', 'Blender Redo'): 'やり直し',
           ('*', 'Blender Undo'): '元に戻す',
           ('*', 'Choose the active Smart Selector project folder. Each project is a subfolder that contains selector JSON files and images. The selector list below shows files inside the chosen project.'): '作業対象のプロジェクト（フォルダ）を選びます。プロジェクトはセレクターJSONと画像をまとめる入れ物です。下の一覧には選択中プロジェクト内のセレクターが表示されます。',
           ('*', 'Create New Selector'): '新規セレクター作成',
           ('*', 'Create Project'): 'プロジェクト作成',
           ('*', 'Data Save Root Directory'): 'データ保存ルートディレクトリ',
           ('*', 'Duplicate Project'): 'プロジェクト複製',
           ('*', 'Execute Script is disabled in Smart Selector N-panel Settings.'): 'スマートセレクターの Nパネル設定で「スクリプト実行を許可」がOFFになっています。',
           ('*', 'Execute Smart Selector Script'): 'スマートセレクター スクリプト実行',
           ('*', 'Favorites Only'): 'お気に入りのみ',
           ('*', 'How many backup generations (.bak) to keep in a .backup folder next to each JSON/image when saving. Set 0 to disable backups. Higher values use more disk space but make it easier to restore older versions.'): '保存時に作成されるバックアップ（.bak）を、各ファイル隣の '
                                                                                                                                                                                                                                   '.backup '
                                                                                                                                                                                                                                   'フォルダに何世代残すかです。0で無効。値を増やすと容量は増えますが、古い状態に戻しやすくなります。',
           ('*', 'How many backup generations (.bak) to keep when saving JSON/images. Set 0 to disable backups. Higher values use more disk space but make it easier to recover older versions.'): 'JSON/画像を保存する際に保持するバックアップ（.bak）の世代数です。0で無効。値を増やすと容量は増えますが、古い状態に戻しやすくなります。',
           ('*', 'How often Blender state is synced to the browser (selection, active object, and watched Shape Keys). Increase this value if Blender feels slow in heavy scenes. Typical: 0.5–1.0 seconds.'): 'ブラウザへBlenderの状態（選択/アクティブ/監視中シェイプキー）を同期する間隔です。重いシーンで重く感じる場合は値を大きくしてください。目安：0.5〜1.0秒。',
           ('*', 'How often the add-on syncs Blender state to the browser (selection, active object, Shape Keys, etc.). Increase this value if the viewport feels slow in heavy scenes.'): 'ブラウザへBlenderの状態（選択/アクティブ/シェイプキーなど）を同期する間隔です。重いシーンで動作が重い場合は値を大きくしてください。',
           ('*', 'Launch and manage Smart Selector (browser-based selector UI) for the active project. Create/open selector JSON files and mark favorites.'): 'Smart '
                                                                                                                                                              'Selector（ブラウザUI）を起動・管理します。セレクターJSONの新規作成/編集/使用、そしてお気に入り登録ができます。',
           ('*', 'Launch and manage Smart Selector (browser-based selector UI) for the active project. Create/open selector JSON files and mark favorites.'): 'Smart Selector '
                                                                                                                                                                    '（ブラウザUI）を起動・管理します。セレクターJSONの新規作成/編集/使用、そしてお気に入り登録ができます。',
           ('*', 'Name for the new project folder. Use letters, numbers, and underscores to avoid OS path issues.'): '新しいプロジェクトフォルダ名です。OSのパス問題を避けるため、英数字とアンダースコア（_）中心の名前がおすすめです。',
           ('*', 'Name of the duplicated project folder that will be created. All selector files and images are copied.'): '複製して作成するプロジェクトフォルダ名です。セレクターJSONと画像がすべてコピーされます。',
           ('*', 'New Name'): '新しい名前',
           ('*', 'New Project Name'): '新規プロジェクト名',
           ('*', 'New folder name for the current project. This renames the folder on disk.'): '現在のプロジェクトをリネームする新しいフォルダ名です。ディスク上のフォルダ名が変更されます。',
           ('*', 'Open Project Folder'): 'プロジェクトフォルダを開く',
           ('*', 'Open Selector'): 'セレクターを開く',
           ('*', 'Open Smart Selector controls in the Properties editor. Click again to return to the standard Properties tabs.'): 'プロパティエディター内でスマートセレクターのコントロールを開きます。もう一度押すと通常のプロパティのタブ表示へ戻ります。',
           ('*', 'Performance / Safety'): 'パフォーマンス / 安全',
           ('*', 'Project'): 'プロジェクト',
           ('*', 'Project List'): 'プロジェクト一覧',
           ('*', 'Project Name'): 'プロジェクト名',
           ('*', 'Rename Project'): 'プロジェクト名変更',
           ('*', 'Root folder where Smart Selector projects are stored (one subfolder per project). Changing this does not move existing projects automatically. Use this if you want to store projects on a different drive or shared folder.'): 'Smart '
                                                                                                                                                                                                                                                  'Selector '
                                                                                                                                                                                                                                                  'のプロジェクトを保存するルートフォルダです（プロジェクト=サブフォルダ1つ）。変更しても既存プロジェクトは自動移動しません。別ドライブ/共有フォルダに保存したい時に設定します。',
           ('*', 'Root folder where Smart Selector projects are stored (one subfolder per project). Leave blank to use CONFIG/Smart_Selector_Suite for this add-on. Changing this does not move existing projects automatically. Use this if you want to store projects on a different drive or shared folder.'): 'Smart '
                                                                                                                                                                                                                                                                                                                                 'Selector '
                                                                                                                                                                                                                                                                                                                                 'のプロジェクトを保存するルートフォルダです（プロジェクト=サブフォルダ1つ）。空欄のままにすると、CONFIG/Smart_Selector_Suite '
                                                                                                                                                                                                                                                                                                                                 'を使います。変更しても既存プロジェクトは自動移動しません。別ドライブや共有フォルダへ保存したい時に設定します。',
           ('*', 'Root folder where Smart Selector projects are stored. Each project is a subfolder (one folder per job). Changing this does not move existing projects automatically.'): 'Smart Selector '
                                                                                                                                                                                          'のプロジェクトを保存するルートフォルダです。プロジェクトはサブフォルダ（案件ごとに1フォルダ）として作成されます。変更しても既存データは自動で移動しません。',
           ('*', 'Select the active Smart Selector project folder (one folder per job). The selector list below shows all selector .json files inside this project. Use the folder icon to open the project on disk, and use Duplicate/Archive to manage versions.'): '作業対象のプロジェクト（案件フォルダ）を選びます。下の一覧には、このプロジェクト内のセレクターJSON（.json）が表示されます。フォルダアイコンで場所を開き、複製/アーカイブでバージョン管理できます。',
           ('*', 'Selector Data List'): 'セレクターデータ一覧',
           ('*', 'Selector Data List:'): 'セレクターデータ一覧:',
           ('*', 'Set Custom Property'): 'カスタムプロパティ設定',
           ('*', 'Set Shape Key'): 'シェイプキー設定',
           ('*', 'Show Archived Projects'): 'アーカイブ済みプロジェクトを表示',
           ('*', 'Show archived projects inside the __ARCHIVE__ folder in the Project dropdown. Archived projects typically have a timestamp suffix. Enable this when you need to reopen an old job.'): '__ARCHIVE__ '
                                                                                                                                                                                                        'フォルダ内のアーカイブ済みプロジェクトも、プロジェクトのプルダウンに表示します。アーカイブは日時サフィックス付きで保存されます。過去案件を開き直す時にONにしてください。',
           ('*', 'Show only selectors marked as Favorites (star). Click the star icon at the left of each selector row to add/remove it from Favorites. Favorites are stored per project and persist across sessions.'): '星（お気に入り）に登録したセレクターだけを一覧表示します。各行の左の星アイコンで登録/解除できます。お気に入りはプロジェクトごとに保存され、Blender再起動後も保持されます。',
           ('*', 'Show projects stored under the __ARCHIVE__ folder in the Project dropdown. Useful when you need to reopen an archived job.'): '__ARCHIVE__ フォルダに移動したプロジェクトを、プロジェクトのプルダウンに表示します。過去案件を再度開きたい時に使います。',
           ('*', 'Smart Selector'): 'スマートセレクター',
           ('*', 'Smart Selector'): 'スマートセレクター',
           ('*', 'State Sync Interval (s)'): '状態同期間隔 (秒)',
           ('*', 'Tip: Leave the directory blank to store projects in CONFIG/Smart_Selector_Suite.'): 'ヒント: 空欄のままにすると、CONFIG/Smart_Selector_Suite にプロジェクトが保存されます。',
           ('*', 'Tip: Projects are stored as subfolders inside this directory (one subfolder per project name).'): 'ヒント: このフォルダ内にプロジェクト名のサブフォルダが作成されます（プロジェクト=1フォルダ）。',
           ('*', 'Toggle Favorite'): 'お気に入り切替',
           ('*', 'When enabled, only selectors marked with a star are shown in the list. Use the star icon next to a selector to add/remove it from Favorites.'): 'ONにすると、星マーク（お気に入り）に登録したセレクターだけを一覧に表示します。各行の星アイコンで登録/解除できます。',
           ('*', 'tt_apply_selection'): '選択アクションを実行します。設定に応じてオブジェクト/コレクション/ボーン/メッシュ要素セットを選択します。Shiftで追加、Ctrlで解除（基本）。',
           ('*', 'tt_blender_redo'): 'Blender の「やり直し」を実行します。元に戻した後で戻す時に使います。',
           ('*', 'tt_blender_undo'): 'Blender の「元に戻す」を実行します。セレクターから行った操作を戻したい時に使います。',
           ('*', 'tt_exec_script'): 'ボタンに設定されたPythonスクリプトを実行します。共有データや不明なデータを使う場合は、NパネルNパネル設定の「スクリプト実行を許可」をOFF推奨です。',
           ('*', 'tt_new_selector'): '空のセレクターをブラウザ（編集モード）で開きます。配置後、ブラウザの「別名保存」で .json を新規作成してください。',
           ('*', 'tt_open_project_folder'): '現在のプロジェクト（案件）フォルダをOSのファイルブラウザで開きます。中にセレクター .json と画像が入ります。バックアップ/コピー/整理に使ってください。',
           ('*', 'tt_open_selector'): 'このセレクターをブラウザの編集モードで開きます。配置/設定を変更して「上書き保存」するとファイルが更新されます。コピーしたい時は「別名保存」。',
           ('*', 'tt_open_selector_play'): 'このセレクターをセレクトモードで開きます。レイアウトは固定され、クリック/スライダー操作がBlenderに反映されます。',
           ('*', 'tt_project_archive'): '現在のプロジェクトを __ARCHIVE__ フォルダへ移動して一覧から隠します。過去案件として保管したい時に使います。再表示したい時はNパネルNパネル設定の「アーカイブ済みプロジェクトを表示」をONにしてください。',
           ('*', 'tt_project_create'): '新しいプロジェクト（案件フォルダ）を作成します。案件ごとに分けるとデータが混ざりません。作成後は「新規セレクター作成」で中にセレクターを作ります。',
           ('*', 'tt_project_duplicate'): '現在のプロジェクトを丸ごと複製します（セレクター .json と画像も全部コピー）。バックアップやバリエーション作成に便利です。',
           ('*', 'tt_project_rename'): '現在のプロジェクト名（フォルダ名）を変更します。ディスク上のフォルダ名も変わります。ブラウザでセレクターを開いている場合は閉じてから行うと安全です。',
           ('*', 'tt_set_custom_prop'): 'カスタムプロパティ（データパス）を数値で変更します。例：location[0] など。対象とパスが正しいか確認してください。',
           ('*', 'tt_set_shapekey'): 'シェイプキー値を変更します（ボタン/スライダー）。対象メッシュにシェイプキーがある必要があります。Blender の「元に戻す」で戻せます。',
           ('*', 'tt_toggle_favorite'): 'このセレクターをお気に入り（星）に登録/解除します。右側の「お気に入りのみ」をONにすると、星だけに絞り込めます。'}}


blender_translations.setdefault('ja_JP', {}).update({
    ('*', 'tt_project_pick_search'): 'プロジェクト一覧ポップアップを開き、現在使うプロジェクトへ切り替えます。Blender 5.1 でも安定して登録できる方式で、従来と同じボタンから安全に選択できます。',
    ('*', 'tt_set_active_project'): 'このプロジェクトを現在の作業対象として切り替えます。下のセレクターデータ一覧は、選択したプロジェクト内の .json を表示します。',
})

# --- full UI i18n extension START ---
_SUITE_EXTRA_JA_TEXTS = {'  * Ctrl+LMB - Expand/Collapse all sublevels\n  * Shift+LMB - Isolate tree/Restore\n  * Alt+LMB - Discard history': '  * Ctrl+左クリック - すべての下位階層を展開 / 折りたたみ\n'
                                                                                                                      '  * Shift+左クリック - ツリーを分離 / 復元\n'
                                                                                                                      '  * Alt+左クリック - 履歴を破棄',
 '  * LMB - Enable all/Restore.\n  * Shift+LMB - Invert.\n  * Shift+Ctrl+LMB - Isolate collections w/ selected objects.\n  * Shift+Alt+LMB - Disable collections w/ selected objects.\n  * Ctrl+LMB - Copy/Paste RTOs.\n  * Ctrl+Alt+LMB - Swap RTOs.\n  * Alt+LMB - Discard history': '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       '左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'すべて有効化 '
                                                                                                                                                                                                                                                                                       '/ '
                                                                                                                                                                                                                                                                                       '復元\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '反転\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+Ctrl+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '選択オブジェクトを含むコレクションを分離\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '選択オブジェクトを含むコレクションを無効化\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Ctrl+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'RTO '
                                                                                                                                                                                                                                                                                       'をコピー '
                                                                                                                                                                                                                                                                                       '/ '
                                                                                                                                                                                                                                                                                       '貼り付け\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Ctrl+Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'RTO '
                                                                                                                                                                                                                                                                                       'を入れ替え\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '履歴を破棄',
 '  * LMB - Move objects to collection.\n  * Shift+LMB - Add/Remove objects from collection': '  * 左クリック - オブジェクトをコレクションへ移動\n'
                                                                                              '  * Shift+左クリック - コレクションへ追加 / コレクションから解除',
 '  * LMB - Select all objects in collection.\n  * Shift+LMB - Add/Remove collection objects from selection.\n  * Ctrl+LMB - Isolate nested selection.\n  * Ctrl+Shift+LMB - Add/Remove nested from selection': '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                '左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'コレクション内の全オブジェクトを選択\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Shift+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                '選択へ追加 '
                                                                                                                                                                                                                '/ '
                                                                                                                                                                                                                '選択から解除\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Ctrl+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'ネストした選択を分離\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Ctrl+Shift+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'ネスト対象を選択へ追加 '
                                                                                                                                                                                                                '/ '
                                                                                                                                                                                                                '解除',
 '  * Shift+LMB - Isolate/Restore.\n  * Shift+Ctrl+LMB - Isolate nested/Restore.\n  * Ctrl+LMB - Toggle nested.\n  * Alt+LMB - Discard history': '  * '
                                                                                                                                                 'Shift+左クリック '
                                                                                                                                                 '- 分離 / 復元\n'
                                                                                                                                                 '  * '
                                                                                                                                                 'Shift+Ctrl+左クリック '
                                                                                                                                                 '- ネストを分離 / '
                                                                                                                                                 '復元\n'
                                                                                                                                                 '  * '
                                                                                                                                                 'Ctrl+左クリック - '
                                                                                                                                                 'ネストを切り替え\n'
                                                                                                                                                 '  * '
                                                                                                                                                 'Alt+左クリック - '
                                                                                                                                                 '履歴を破棄',
 ' Remove all masks from layers of the selected strokes ': '選択ストロークのレイヤーからすべてのマスクを削除します。',
 ' Toggles mask visablity of all layers ': 'すべてのレイヤーのマスク表示を切り替えます。',
 '1 or more objects moved to Scene Collection.': '1 個以上のオブジェクトをシーンコレクションへ移動しました。',
 '3D Viewport header widget for the QCD slots. This widget is kept active with the QCD system.': 'QCD スロット用の 3D ビューポートヘッダーウィジェットです。QCD システムと一緒に常時有効として扱われます。',
 'A': 'A',
 'Active Smart Selector project folder name. Change it from the Smart Selector Project picker; the selector list below reads selector .json files from this project.': '現在の '
                                                                                                                                                                    'Smart '
                                                                                                                                                                    'Selector '
                                                                                                                                                                    'プロジェクトフォルダー名です。Smart '
                                                                                                                                                                    'Tools '
                                                                                                                                                                    'のプロジェクトピッカーで切り替えると、下のセレクター一覧はこのプロジェクト内の '
                                                                                                                                                                    '.json '
                                                                                                                                                                    'ファイルを読み込みます。',
 'Active layer is hidden': 'アクティブレイヤーが非表示です。',
 "Active layer's group is hidden": 'アクティブレイヤーのグループが非表示です。',
 'Add Collection': 'コレクションを追加',
 'Add New Collection': '新規コレクションを追加',
 'Add Prefix to Selected': '選択へ接頭辞を追加',
 'Add Prefix to layers with selected strokes': '選択ストロークがあるレイヤーへ接頭辞を追加します。レイヤー名を分類しやすくするための操作です。',
 'Add SubCollection': 'サブコレクションを追加',
 'Add Suffix': '接尾辞を追加',
 'Add suffix to layers with selected strokes': '選択ストロークがあるレイヤーへ接尾辞を追加します。レイヤー名の末尾で分類したい時に使います。',
 'Adds all layers of the selected strokes to a new group': '選択ストロークのすべてのレイヤーを新しいグループへ追加します。',
 'Affixes': '付ける文字',
 'Align Local Options': 'ローカルオプションを整列',
 'Align local options in a column to the right': 'ローカルオプションを右側の列にそろえて表示します。',
 'All QCD slots are already enabled and isolated.': 'すべての QCD スロットは既に有効かつ分離済みです。',
 'All QCD slots are already enabled.': 'すべての QCD スロットは既に有効です。',
 'All collections are already disabled.': 'すべてのコレクションは既に無効です。',
 'All non QCD slots are already disabled.': 'QCD 以外のスロットは既にすべて無効です。',
 'All objects made selectable': 'すべてのオブジェクトを選択可能にしました。',
 'Allow Execute Script': 'スクリプト実行を許可',
 'Allow selector buttons to execute custom Python scripts from the browser. Turn OFF for safety when sharing files or when you only need selection/slider actions.': 'ブラウザーのセレクターボタンからカスタム '
                                                                                                                                                                     'Python '
                                                                                                                                                                     'スクリプトを実行できるようにします。ファイル共有時や選択 '
                                                                                                                                                                     '/ '
                                                                                                                                                                     'スライダー操作だけで十分な場合は、安全のため '
                                                                                                                                                                     'OFF '
                                                                                                                                                                     'にしてください。',
 'Apply Layer Pass Index?': 'レイヤーパスインデックスを適用しますか？',
 'Apply Opacity': '不透明度を適用',
 'Apply Phantom Mode': 'ファントムモードを適用',
 'Apply Selection': '選択を適用',
 'Apply Sensitivity': '感度を適用',
 'Apply changes and quit Phantom Mode': 'ファントムモード中の変更を適用して終了します。保存された RTO 状態へ戻す必要がないことを確認してから実行してください。',
 'Archive Project': 'プロジェクトをアーカイブ',
 'Assign Weight': 'ウェイト割り当て',
 'Assign Weight To Selected': '選択へウェイトを割り当て',
 'Assign Weight by Name': '名前でウェイト割り当て',
 'Assign weight to selected stroke Layers from Vertex Groups of the same name (For Premade rigs with already set names. Or use Sync layer names in WP mode)': '同名の頂点グループから、選択ストロークのレイヤーへウェイトを割り当てます。既に名前が設定されたリグ向けです。必要に応じてウェイトペイントモードでレイヤー名同期を使ってください。',
 'Assign weight to selected strokes using the selected bone/v-group. Works on Mutiple frames with Multiframe on ( Use with Weight selected )': '選択ボーンまたは頂点グループを使って選択ストロークへウェイトを割り当てます。マルチフレームを有効にすると複数フレームで動作します。「選択へウェイト」と組み合わせて使います。',
 'B': 'B',
 'Backup Generations': 'バックアップ世代数',
 'Blender Redo': 'Blender やり直し',
 'Blender Undo': 'Blender 元に戻す',
 'Can only be executed in Object Mode': 'オブジェクトモードでのみ実行できます。',
 "Can't set excluded collection as active": '除外中のコレクションはアクティブにできません。',
 'Cannot execute.  The active object would be lost.': '実行できません。アクティブオブジェクトが失われます。',
 'Clean Digits/Punctuation': '数字 / 記号を削除',
 'Clear': 'クリア',
 'Clear Selected Stroke Weights': '選択ストロークのウェイトをクリア',
 'Clear a specific text field': '指定したテキスト入力欄をクリアします。検索語やリネーム文字列を消したい時に使います。',
 'Clear all vertex weight from the selected strokes': '選択ストロークからすべての頂点ウェイトをクリアします。',
 'Cleared weights from selected strokes': '選択ストロークのウェイトをクリアしました。',
 'Collection Manager': 'コレクションマネージャー',
 "Control Opacity of all selected stroke's layers.(set value then click apply)": '選択ストロークがあるすべてのレイヤーの不透明度を調整します。値を設定してから適用を押してください。',
 'Controller Sensitivity:': 'コントローラー感度:',
 'Create All QCD Slots': 'すべてのQCDスロットを作成',
 'Create Pass Index Time Control': 'インデックスパスの時間オフセット制御を作成',
 'Create Indexed Time Offset Rig': 'インデックス付き時間オフセットリグを作成',
 'Create Layers from Vertex Group names ( For premade rigs, Then you can draw on the layers that have the correct names)': '頂点グループ名からレイヤーを作成します。既存リグ向けで、正しい名前のレイヤー上に描画できるようになります。',
 'Create New Selector': '新規セレクターを作成',
 'Create Project': 'プロジェクト作成',
 'Create Time Offset Rig': '時間オフセットリグを作成',
 "Create a Time Offset Controller for every selected stroke layer ( Will make a new armature if you don't have one parented )": '選択ストロークの各レイヤーに時間オフセットコントローラーを作成します。親アーマチュアが無い場合は新しいアーマチュアを作成します。',
 'Create a Time Offset rig/modifier to control multiple layers with Pass Index ( For the Selected strokes. Will make a rig if gp is not parented )': 'パスインデックスで複数レイヤーを制御する時間オフセットリグ / モディファイアを作成します。選択ストローク用で、GP に親が無い場合はリグを作成します。',
 'Create any missing QCD slots so you have a full 20': '不足している QCD スロットを作成し、20 個すべてをそろえます。',
 'Create Layer Time Control': 'レイヤーの時間オフセット制御を作成',
 'Data Save Root Directory': 'データ保存ルートディレクトリ',
 'Delete Empty Layers: Are you sure!?': '空レイヤーを削除します。本当に実行しますか？',
 'Delete Layers?': 'レイヤーを削除しますか？',
 'Delete Selected Layers': '選択レイヤーを削除',
 'Delete empty Grease Pencil layers (Skips Hidden, Locked, or Hidden Groups)': '空の Grease Pencil レイヤーを削除します。非表示、ロック中、または非表示グループ内のレイヤーは除外されます。',
 'Delete layers of the selected strokes': '選択ストロークのレイヤーを削除します。実行前に対象を確認してください。',
 'Disable All Non QCD Slots': 'QCD以外の全スロットを無効化',
 'Disable All collections': 'すべてのコレクションを無効化',
 'Disable Selected': '選択を無効化',
 'Disable Selected Objects Collections': '選択オブジェクトのコレクションを無効化',
 'Disable Unselected': '未選択を無効化',
 'Disable all collections that contain the selected objects': '選択オブジェクトを含むすべてのコレクションを無効化します。選択対象に関連するコレクションを一括で隠したい時に使います。',
 'Disable objects instead of Hiding': '非表示の代わりにオブジェクトを無効化',
 'Disable selected objects in viewports': '選択中のオブジェクトをビューポートで無効化します。非表示ではなく無効化したい場合に使います。',
 'Disable unselected objects in viewports': '未選択のオブジェクトをビューポートで無効化します。選択中の対象だけを作業しやすくする時に使います。',
 'Discard History': '履歴を破棄',
 'Discard QCD History': 'QCD の履歴を破棄します。復元履歴を使わず現在状態を基準にしたい場合に実行します。',
 'Display Options': '表示オプション',
 'Draw': '描画',
 'Draw Brush': '描画ブラシ',
 'Dup & Hide Original': '複製して元を非表示',
 'Duplicate & Assign Material': '複製してマテリアルを割り当て',
 'Duplicate & Hide Original': '複製して元を非表示',
 'Duplicate Project': 'プロジェクトを複製',
 "Duplicate Stroke's material and assign the new one(s) to the strokes.": 'ストロークのマテリアルを複製し、新しいマテリアルをストロークへ割り当てます。',
 'Duplicate layers of selected strokes and hide the originals': '選択ストロークのレイヤーを複製し、元のレイヤーを非表示にします。元データを残して別案を作りたい時に使います。',
 'Enable All QCD Slots': 'すべてのQCDスロットを有効化',
 'Enable All QCD Slots Isolated': 'すべてのQCDスロットを分離して有効化',
 'Enable/Disable QCD System.\nThe Quick Content Display system allows you to specify collections as QCD "slots" up to a maximum of 20. You can then interact with them through numerical hotkeys, a popup move widget, and a 3D Viewport header widget': 'QCD システムを有効 / 無効にします。\nQCD は、最大 20 個までのコレクションを QCD「スロット」として指定できる仕組みです。数値ホットキー、ポップアップ移動ウィジェット、3Dビューポートヘッダーウィジェットから操作できます。',
 'Error removing 1 or more objects from the Scene Collection.  Objects would be left without a collection.': 'シーンコレクションから 1 個以上のオブジェクトを削除できません。コレクションに属さないオブジェクトが発生します。',
 'Execute Smart Selector Script': 'スマートセレクター スクリプトを実行',
 'Expand All Items': 'すべて展開',
 'Expand Sublevel Items': '下位階層を展開',
 'Expand/Collapse all collections': 'コレクションツリー全体を展開または折りたたみます。階層が多いシーンで一覧を素早く整理するための操作です。',
 'Favorites Only': 'お気に入りのみ',
 'Filter By Name': '名前でフィルター',
 'Filter By QCD': 'QCDでフィルター',
 'Filter By Selected': '選択でフィルター',
 'Filter collections by name': '名前でコレクションを絞り込みます。',
 'Filter collections to only show the ones that are QCD slots': 'QCD スロットになっているコレクションだけを表示します。',
 'Filter collections to only show the ones that contain the selected objects': '選択中オブジェクトを含むコレクションだけを表示します。',
 'Find': '検索',
 'Find and replace text in layers of selected strokes': '選択ストロークがあるレイヤー名の文字列を検索して置換します。複数レイヤー名をまとめて修正できます。',
 'GP Select': 'GP セレクト',
 'Global QCD Slot Actions': 'QCDスロット全体操作',
 'Gp Select': 'GP セレクト',
 'Group Name': 'グループ名',
 'Group Selected Stroke Layers': '選択ストロークのレイヤーをグループ化',
 'Group selected': '選択をグループ化',
 'Hide Selected': '選択を非表示',
 'Hide Selected Layers': '選択レイヤーを非表示',
 'Hide layer of the selected strokes': '選択ストロークのレイヤーを非表示にします。',
 'How many backup generations (.bak) to keep in a .backup folder next to each JSON/image when saving. Set 0 to disable backups. Higher values use more disk space but make it easier to restore older versions.': '保存時に各 '
                                                                                                                                                                                                                  'JSON '
                                                                                                                                                                                                                  '/ '
                                                                                                                                                                                                                  '画像の隣にある '
                                                                                                                                                                                                                  '.backup '
                                                                                                                                                                                                                  'フォルダーへ保持するバックアップ（.bak）の世代数です。0 '
                                                                                                                                                                                                                  'にすると無効です。値を大きくするとディスク容量は増えますが、古い状態へ戻しやすくなります。',
 'How often Blender state is synced to the browser (selection, active object, and watched Shape Keys). Increase this value if Blender feels slow in heavy scenes. Typical: 0.5–1.0 seconds.': 'Blender '
                                                                                                                                                                                              'の状態（選択、アクティブオブジェクト、監視中シェイプキー）をブラウザーへ同期する間隔です。重いシーンで '
                                                                                                                                                                                              'Blender '
                                                                                                                                                                                              'が遅く感じる場合は値を大きくしてください。目安は '
                                                                                                                                                                                              '0.5～1.0 '
                                                                                                                                                                                              '秒です。',
 'If enabled, all selected strokes will share one duplicated material': '有効にすると、選択ストロークは複製された 1 つのマテリアルを共有します。',
 'Infix': '中間文字',
 'Initializing...': '初期化中...',
 'Inner': '内側',
 'Integrated Tools': '統合ツール',
 'Invert': '反転',
 'Invert Masks': 'マスクを反転',
 'Invert filtering (show hidden items, and vice-versa)': 'フィルター結果を反転します（非表示項目を表示し、表示項目を隠します）。',
 'Invert masks on layers of the selected strokes': '選択ストロークのレイヤー上のマスクを反転します。',
 'Inverted masks': 'マスクを反転しました。',
 'Isolate Selected': '選択を分離',
 'Isolate Selected Objects Collections': '選択オブジェクトのコレクションを分離',
 'Isolate Stroke': 'ストロークを分離',
 'Isolate collections (via EC) that contain the selected objects': '選択オブジェクトを含むコレクションを EC 経由で分離します。対象コレクションだけを確認したい場合に使います。',
 'JSON': 'JSON',
 'Lasso': '投げ縄',
 'Lasso Edit': '投げ縄編集',
 'Launch and manage Smart Selector (browser-based selector UI) for the active project. Create/open selector JSON files and mark favorites.': 'アクティブプロジェクト用の '
                                                                                                                                                   'Smart '
                                                                                                                                                   'Selector '
                                                                                                                                                   '（ブラウザーベースのセレクターUI）を起動・管理します。セレクター '
                                                                                                                                                   'JSON '
                                                                                                                                                   'ファイルの作成 / '
                                                                                                                                                   'オープン、お気に入り登録を行えます。',
 'Mask Layer with Strokes': 'ストロークでレイヤーをマスク',
 'Layer Tools': 'レイヤーツール',
 'Layer sent to Bottom.': 'レイヤーを最下部へ移動しました。',
 'Layer sent to Top.': 'レイヤーを最上部へ移動しました。',
 'Layout': 'レイアウト',
 'Lock Selected layers': '選択レイヤーをロック',
 "Lock materials of unselected stroke's (Toggleable)": '未選択ストロークのマテリアルをロックします。もう一度実行すると切り替えできます。',
 'Lock the layers of selected strokes (Toggleable)': '選択ストロークのレイヤーをロックします。もう一度実行すると切り替えできます。',
 'Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when ran again )': '選択ストロークのレイヤーとマテリアルをロックし、アーマチュアを選択し、他オブジェクトを選択不可にしてウェイトペイントモードへ入ります。もう一度実行すると解除できます。',
 'Make layers From Groups': 'グループからレイヤーを作成',
 'Manage and control collections, with advanced features, in a popup UI': 'ポップアップ UI でコレクションを管理・制御します。表示制限、選択制限、QCD などの高度な機能をまとめて扱えます。',
 'Mask Active to Selected': 'アクティブを選択へマスク',
 'Mask selected strokes layers to the active layer ': '選択ストロークのレイヤーをアクティブレイヤーへマスクします。',
 'Mask the active layer to the selected strokes layers': 'アクティブレイヤーを選択ストロークのレイヤーへマスクします。',
 'Mask to Active': 'アクティブへマスク',
 'Mask:': 'マスク:',
 'Menu': 'メニュー',
 'Modes': 'モード',
 'Modifier Name': 'モディファイア名',
 'Move Above': '上へ移動',
 'Move Below': '下へ移動',
 'Move Group Above Selection': 'グループを選択の上へ移動',
 'Move Group Below Selection': 'グループを選択の下へ移動',
 'Move Layers to Bottom': 'レイヤーを最下部へ移動',
 'Move Layers to Top': 'レイヤーを最上部へ移動',
 'Move Selected Above': '選択を上へ移動',
 'Move Selected Below': '選択を下へ移動',
 'Move To QCD Slot': 'QCDスロットへ移動',
 'Move layers of the selected strokes to the bottom': '選択ストロークのレイヤーを最下部へ移動します。',
 'Move layers of the selected strokes to the top': '選択ストロークのレイヤーを最上部へ移動します。',
 'Move object(s) to QCD slot': '選択中の 1 個以上のオブジェクトを指定 QCD スロットへ移動します。',
 'Move objects to QCD Slots': '選択オブジェクトを QCD スロットへ移動します。スロットを指定してコレクション整理を素早く行うための操作です。',
 'Move the active Group Bellow the selected stroke layer': 'アクティブグループを選択ストロークのレイヤーより下へ移動します。',
 'Move the active Group above the selected stroke layer': 'アクティブグループを選択ストロークのレイヤーより上へ移動します。',
 "Move the selected stroke's layers Above the active layer": '選択ストロークのレイヤーをアクティブレイヤーの上へ移動します。',
 "Move the selected stroke's layers Bellow the active layer": '選択ストロークのレイヤーをアクティブレイヤーの下へ移動します。',
 'Name for the new project folder. Use letters, numbers, and underscores to avoid OS path issues.': '新しいプロジェクトフォルダー名です。OS のパス問題を避けるため、英数字とアンダースコアの使用を推奨します。',
 'Name of the duplicated project folder that will be created. All selector files and images are copied.': '複製して作成するプロジェクトフォルダー名です。すべてのセレクターファイルと画像がコピーされます。',
 'New Name': '新しい名前',
 'New Project Name': '新規プロジェクト名',
 'New folder name for the current project. This renames the folder on disk.': '現在のプロジェクトに付ける新しいフォルダー名です。ディスク上のフォルダー名も変更されます。',
 'No Active Group Found': 'アクティブグループが見つかりません。',
 'No QCD slots.': 'QCD スロットがありません。',
 'No V-Groups Found': '頂点グループが見つかりません。',
 'No active Vertex Group found': 'アクティブな頂点グループが見つかりません。',
 'No active Vertex Group selected': 'アクティブな頂点グループが選択されていません。',
 'No connected Time Offset drivers found for selection.': '選択対象に接続された時間オフセットドライバーが見つかりません。',
 'No connected Time Offset modifiers found.': '接続された時間オフセットモディファイアが見つかりません。',
 'No empty layers found': '空レイヤーは見つかりませんでした。',
 'No layers have masks': 'マスクを持つレイヤーがありません。',
 'No objects present to select.': '選択できるオブジェクトがありません。',
 'No selected strokes found': '選択されたストロークが見つかりません。',
 'No selected strokes found.': '選択されたストロークが見つかりません。',
 'Not in Gp Edit mode': 'GP 編集モードではありません。',
 'Numerical hotkeys for viewing QCD slots in Edit Mode. These are kept active with the QCD system.': '編集モードで QCD スロットを表示する数値ホットキーです。QCD システムと一緒に常時有効として扱われます。',
 'Numerical hotkeys for viewing QCD slots. These are kept active with the QCD system.': 'QCD スロット表示用の数値ホットキーです。QCD システムと一緒に常時有効として扱われます。',
 'ONLY FOR CLEAN UP. This deletes layers with nothing found on them.': 'クリーンアップ専用です。中身が見つからないレイヤーを削除します。',
 'Objects': 'オブジェクト',
 'Only Works on Single layers': '単一レイヤーでのみ動作します。',
 'Opacity': '不透明度',
 'Open Project Folder': 'プロジェクトフォルダーを開く',
 'Open Selector': 'セレクターを開く',
 'Open Smart Selector controls in the Properties editor': 'プロパティエディターでスマートセレクターのコントロールを開きます。',
 'Outline': '輪郭',
 'Pass': 'パス',
 'Pass Index': 'パスインデックス',
 'Phantom Mode\nSaves the state of all RTOs and only allows changes to them, on exit all RTOs are returned to their saved state.\nNote: modifying collections (except RTOs) externally will exit Phantom Mode and your initial state will be lost': 'ファントムモード\n'
                                                                                                                                                                                                                                                    'すべての '
                                                                                                                                                                                                                                                    'RTO '
                                                                                                                                                                                                                                                    '状態を保存し、RTO '
                                                                                                                                                                                                                                                    'の変更だけを許可します。終了時に各 '
                                                                                                                                                                                                                                                    'RTO '
                                                                                                                                                                                                                                                    'は保存時の状態へ戻ります。\n'
                                                                                                                                                                                                                                                    '注意: '
                                                                                                                                                                                                                                                    'RTO '
                                                                                                                                                                                                                                                    '以外のコレクションを外部から変更するとファントムモードが終了し、初期状態は失われます。',
 'Pinch': 'つまむ',
 'Prefix': '接頭辞',
 'Proceed with cleanup?': 'クリーンアップを実行しますか？',
 'Proceed?': '実行しますか？',
 'Project': 'プロジェクト',
 'Project List': 'プロジェクト一覧',
 'Project Name': 'プロジェクト名',
 'Project folder name to make active in Smart Selector.': 'スマートセレクターでアクティブにするプロジェクトフォルダー名です。',
 'Pull': '引っ張り',
 'Purge All Collections Without Objects': 'オブジェクトの無いコレクションをすべて削除',
 'QCD': 'QCD',
 'QCD 3D Viewport Header Widget': 'QCD 3Dビューポートヘッダーウィジェット',
 'QCD All Meta Operator': 'QCD の全体操作をまとめて扱うメタオペレーターです。複数スロットの状態を一括で切り替える時に使います。',
 'QCD Edit Mode Hotkeys': 'QCD編集モードホットキー',
 'QCD Hotkeys': 'QCDホットキー',
 'QCD Move Widget': 'QCD移動ウィジェット',
 'QCD Runtime: Always Active': 'QCD 実行時機能: 常時有効',
 'QCD Slot': 'QCDスロット',
 'Quick View Toggles': 'クイック表示切替',
 'Redo': 'やり直し',
 'Redo previous action': '元に戻した操作をやり直します。',
 'Remove Collection': '選択したコレクションを削除します。中のオブジェクトや所属状態を確認してから実行してください。',
 'Remove Digits and Punctuation from layers with selected strokes': '選択ストロークがあるレイヤー名から数字と記号を削除します。名前を整理したい場合に使います。',
 'Remove Empty Collections': '空のコレクションを削除',
 'Remove Setup': 'セットアップを削除',
 'Remove Setup From Selected Bone': '選択ボーンからセットアップを削除',
 'Rename': 'リネーム',
 'Rename Full Name': '名前全体を変更',
 'Rename Project': 'プロジェクト名を変更',
 "Rename stroke's layer based off the selected vertex group (Use inside WP mode For Assign Weight by Name)": '選択中の頂点グループに基づいてストロークのレイヤー名を変更します。ウェイトペイントモード内で「名前でウェイト割り当て」と組み合わせて使います。',
 'Renaming and Pass Index': 'リネームとパスインデックス',
 'Renumber QCD Slots': 'QCDスロット番号を振り直し',
 'Renumber QCD slots.\n  * LMB - Renumber (breadth first) from slot 1.\n  * +Ctrl - Linear.\n  * +Alt - Reset.\n  * +Shift - Constrain to branch': 'QCD '
                                                                                                                                                   'スロット番号を振り直します。\n'
                                                                                                                                                   '  * 左クリック '
                                                                                                                                                   '- スロット 1 '
                                                                                                                                                   'から幅優先で番号を振り直し\n'
                                                                                                                                                   '  * Ctrl '
                                                                                                                                                   '追加 - 直線順\n'
                                                                                                                                                   '  * Alt 追加 '
                                                                                                                                                   '- リセット\n'
                                                                                                                                                   '  * Shift '
                                                                                                                                                   '追加 - '
                                                                                                                                                   'ブランチ内に限定',
 'Replace': '置換',
 'Replace Text': 'テキストを置換',
 'Replace full name of layers ': '選択ストロークがあるレイヤーの名前全体を置き換えます。実行前に新しい名前を確認してください。',
 'Replace the entire name of selected layers': '選択したレイヤー名全体を置き換えます。',
 'Replace the object hiding hotkeys with object disabling hotkeys and add them to the Object->Show/Hide menu.\nDisabling objects prevents them from being automatically shown again when collections are unexcluded': 'オブジェクト非表示用ホットキーを、オブジェクト無効化用ホットキーへ置き換え、Object '
                                                                                                                                                                                                                      '> '
                                                                                                                                                                                                                      'Show/Hide '
                                                                                                                                                                                                                      'メニューへ追加します。\n'
                                                                                                                                                                                                                      'オブジェクトを無効化すると、コレクションの除外解除時に自動で再表示されにくくなります。',
 'Reset Indexes?': 'インデックスをリセットしますか？',
 'Reset all layers to 100% opacity': 'すべてのレイヤーの不透明度を 100% に戻します。',
 'Reset layers and materials Pass Index to 0 for the selected strokes': '選択ストロークのレイヤーとマテリアルのパスインデックスを 0 に戻します。',
 'Reset layers, remove the GP modifiers, and delete control bones (Select the control bone for this)': 'レイヤーをリセットし、GP '
                                                                                                       'モディファイアを削除し、制御ボーンを削除します。この操作では制御ボーンを選択してください。',
 'Restore All Opacity': 'すべての不透明度を復元',
 'Restore Disabled Objects': '無効化オブジェクトを復元',
 'Restore disabled objects in viewports': 'ビューポートで無効化されているオブジェクトを復元します。無効化状態を戻したい場合に使います。',
 'Restriction Toggles': '制限切替',
 'Rigging': 'リギング',
 'Rigging Tools': 'リギングツール',
 'Root folder where Smart Selector projects are stored (one subfolder per project). Leave blank to use CONFIG/Smart_Selector_Suite for this add-on. Changing this does not move existing projects automatically. Use this if you want to store projects on a different drive or shared folder.': 'Smart '
                                                                                                                                                                                                                                                                                                                'Selector '
                                                                                                                                                                                                                                                                                                                'プロジェクトを保存するルートフォルダーです（1プロジェクトにつき1サブフォルダー）。空欄の場合は、CONFIG/Smart_Selector_Suite '
                                                                                                                                                                                                                                                                                                                'を使います。変更しても既存プロジェクトは自動移動しません。別ドライブや共有フォルダーへ保存したい場合に使用します。',
 'Scene Collection': 'シーンコレクション',
 'Select A Grease Pencil Object.': 'Grease Pencil オブジェクトを選択してください。',
 'Select All Cumulative Objects': '重複所属オブジェクトをすべて選択',
 'Select All Objects in the Collection': 'コレクション内の全オブジェクトを選択',
 'Select All QCD Objects': 'すべてのQCDオブジェクトを選択',
 'Select By:': '条件で選択:',
 'Select Similar Infix': '同じ中間文字を選択',
 'Select Similar Prefix': '同じ接頭辞を選択',
 'Select Similar Suffix': '同じ接尾辞を選択',
 'Select all objects in QCD slots': 'QCD スロット内のすべてのオブジェクトを選択します。スロット対象をまとめて選択したい時に使います。',
 'Select all objects that are present in more than one collection': '複数のコレクションに所属しているオブジェクトをすべて選択します。重複所属の確認や整理に使います。',
 'Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected ) ': '選択ストロークと同じ中間文字列を持つストロークを全レイヤーから選択します。マルチフレーム設定を尊重し、各条件につき '
                                                                                                                                                           '1 '
                                                                                                                                                           'つ選択しておけば実行できます。',
 'Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected ) ': '選択ストロークと同じ接頭辞を持つストロークを全レイヤーから選択します。マルチフレーム設定を尊重し、各接頭辞につき '
                                                                                                                                                              '1 '
                                                                                                                                                              'つ選択しておけば実行できます。',
 'Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected ) ': '選択ストロークと同じ接尾辞を持つストロークを全レイヤーから選択します。記号にも対応し、マルチフレーム設定を尊重します。各接尾辞につき '
                                                                                                                                                                                      '1 '
                                                                                                                                                                                      'つ選択しておけば実行できます。',
 'Selected': '選択中',
 'Selection': '選択',
 'Selection & Reordering': '選択と並べ替え',
 'Selector Data List': 'セレクターデータ一覧',
 'Send Objects to Collection': 'オブジェクトをコレクションへ送る',
 'Send Report': 'レポートを表示',
 'Send to Bottom': '最下部へ送る',
 'Send to Top': '最上部へ送る',
 'Sensitivity': '感度',
 'Set -> Layer <- Pass Index For Multiple selected strokes': '複数の選択ストロークに対して、レイヤーのパスインデックスを設定します。',
 'Set -> Material <- Pass Index For Multiple selected strokes': '複数の選択ストロークに対して、マテリアルのパスインデックスを設定します。',
 'Set Active Collection': 'アクティブコレクションを設定',
 'Set Active Project': 'アクティブプロジェクトを設定',
 'Set Custom Property': 'カスタムプロパティを設定',
 'Set Material Pass Index?': 'マテリアルパスインデックスを設定しますか？',
 'Set Shape Key': 'シェイプキーを設定',
 'Set opacity for all layers Of the selected strokes': '選択ストロークがあるすべてのレイヤーの不透明度を設定します。',
 'Set the active collection': '指定したコレクションをアクティブコレクションに設定します。選択や移動操作の基準にしたいコレクションを切り替える時に使います。',
 'Shared Material Name': '共有マテリアル名',
 'Show Archived Projects': 'アーカイブ済みプロジェクトを表示',
 'Show archived projects inside the __ARCHIVE__ folder in the Project dropdown. Archived projects typically have a timestamp suffix. Enable this when you need to reopen an old job.': 'プロジェクトのドロップダウンに __ARCHIVE__ フォルダー内のアーカイブ済みプロジェクトも表示します。通常、アーカイブ済みプロジェクトには日時サフィックスが付きます。過去案件を開き直す場合に有効にしてください。',
 'Show only selectors marked as Favorites (star). Click the star icon at the left of each selector row to add or remove it from Favorites. Favorites are stored per project and persist across sessions.': '星マークのお気に入りに登録されたセレクターだけを表示します。各行左側の星アイコンで登録・解除できます。お気に入りはプロジェクトごとに保存され、セッションをまたいで保持されます。',
 'Smart Selector': 'スマートセレクター',
 'Specials': '特殊操作',
 'State Sync Interval (s)': '状態同期間隔（秒）',
 'Strength': '強さ',
 'Strip': '除去',
 'Stroke-> Layer': 'ストローク → レイヤー',
 'Suffix': '接尾辞',
 'Switch to Layer': 'レイヤーへ切り替え',
 "Switch to the selected stroke's layer (Hotkey This, and Lasso for best results) ": '選択ストロークが属するレイヤーへ切り替えます。投げ縄選択と合わせてホットキー登録すると便利です。',
 'Sync Layer Name': 'レイヤー名を同期',
 'Text': '文字',
 'Text to add as a prefix or suffix': '接頭辞または接尾辞として追加する文字列です。',
 'Thickness': '厚み',
 'Toggle All Masks': 'すべてのマスクを切替',
 'Toggle Favorite': 'お気に入りを切替',
 'Toggle Phantom Mode': 'ファントムモード切替',
 'Toggle Time Visibility': '時間表示を切替',
 'Toggle Viewport Visibility of Time Drivers for Selected Strokes or Bones': '選択ストロークまたはボーンに関連する時間オフセットのドライバーのビューポート表示を切り替えます。',
 'Toggles between the current state and all collections disabled': '現在の状態と、すべてのコレクションを無効にした状態を切り替えます。',
 'Toggles between the current state and all enabled': '現在の状態と、すべての QCD スロットを有効にした状態を切り替えます。',
 'Toggles between the current state and all enabled (non-QCD collections disabled)': '現在の状態と、QCD スロットを有効化し QCD 以外のコレクションを無効にした状態を切り替えます。',
 'Toggles between the current state and all non-QCD collections disabled': '現在の状態と、QCD 以外のすべてのコレクションを無効にした状態を切り替えます。',
 'UI Separator Button': 'UI区切りボタン',
 'Undo': '元に戻す',
 'Undo previous action': '直前の操作を元に戻します。',
 'Unlock All': 'すべてロック解除',
 'Unlocks all GP layers/materials and Makes all objects selectable': 'すべての GP レイヤー / マテリアルのロックを解除し、すべてのオブジェクトを選択可能にします。',
 'Unmask Selected': '選択のマスク解除',
 'Update Time Drivers based on Selected Strokes OR Selected Rig Bones': '選択ストロークまたは選択リグボーンに基づいて時間オフセットのドライバーを更新します。',
 'Use Single Material for All': 'すべてに単一マテリアルを使用',
 'Value': '値',
 'Value for the Time Offset Driver Generator (x^1)': '時間オフセットドライバー生成で使う感度値です（x^1）。',
 'Value to apply to selected stroke layers': '選択ストロークのレイヤーへ適用する値です。',
 'View QCD Slot': 'QCDスロットを表示',
 'View objects in QCD slot': '指定 QCD スロット内のオブジェクトを表示します。スロット内容を確認したい場合に使います。',
 'View3D not found, cannot run operator': '3D ビューが見つからないため、オペレーターを実行できません。',
 'Visibility & Opacity': '表示と不透明度',
 'Weight Assigned': 'ウェイトを割り当てました。',
 'Weight Selected': '選択へウェイト',
 '[DV Global] Disable in Viewports': '[DV 全体] ビューポートで無効化',
 '[DV] Disable in Viewports': '[DV] ビューポートで無効化',
 '[EC Global] Exclude from View Layer': '[EC 全体] ビューレイヤーから除外',
 '[EC] Exclude from View Layer': '[EC] ビューレイヤーから除外',
 '[HH Global] Holdout': '[HH 全体] ホールドアウト',
 '[HH] Holdout': '[HH] ホールドアウト',
 '[IO Global] Indirect Only': '[IO 全体] 間接のみ',
 '[IO] Indirect Only': '[IO] 間接のみ',
 '[RR Global] Disable in Renders': '[RR 全体] レンダーで無効化',
 '[RR] Disable in Renders': '[RR] レンダーで無効化',
 '[SS Global] Disable Selection': '[SS 全体] 選択を無効化',
 '[SS] Disable Selection': '[SS] 選択を無効化',
 '[VV Global] Hide in Viewport': '[VV 全体] ビューポートで非表示',
 '[VV] Hide in Viewport': '[VV] ビューポートで非表示',
 'layer is hidden, cannot apply mask': 'レイヤーが非表示のため、マスクを適用できません。',
 '• Only layers that are NOT hidden or locked will be checked.': '• 非表示またはロックされていないレイヤーだけを確認します。',
 '• This includes checking nested groups.': '• ネストされたグループ内も確認します。'}

blender_translations.setdefault('ja_JP', {}).update({('*', _k): _v for _k, _v in _SUITE_EXTRA_JA_TEXTS.items()})

def safe_extra_ja_texts():
    return dict(_SUITE_EXTRA_JA_TEXTS)
# --- full UI i18n extension END ---

# --- full UI i18n completion patch START ---
_SUITE_EXTRA_JA_TEXTS.update({
    'Replace full name of layers': 'レイヤー名全体を置き換えます。対象レイヤーを確認してから実行してください。',
    'Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected )': '選択中ストロークと同じ接頭辞を持つストロークを、すべてのレイヤーから選択します。マルチフレーム設定を反映し、各種類を1つ選択しておけば判定できます。',
    'Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected )': '選択中ストロークと同じ接尾辞を持つストロークを、すべてのレイヤーから選択します。句読点を含む名前にも対応し、マルチフレーム設定を反映します。各種類を1つ選択しておけば判定できます。',
    'Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected )': '選択中ストロークと同じ中間文字列を持つストロークを、すべてのレイヤーから選択します。マルチフレーム設定を反映し、各種類を1つ選択しておけば判定できます。',
    'Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when switching modes. Respects the Multiframe setting, and Auto lock )': '選択ストロークのレイヤーとマテリアルをロックし、アーマチュアを選択して、他のオブジェクトを選択不可にしたうえでウェイトペイントモードへ入ります。切り替え式で、モード変更時に解除されます。マルチフレーム設定と自動ロックを反映します。',
    "Switch to the selected stroke's layer (Hotkey This, and Lasso for best results)": '選択ストロークが属するレイヤーへ切り替えます。投げ縄選択と組み合わせてホットキー登録すると効率的です。',
    'Mask selected strokes layers to the active layer': '選択ストロークがあるレイヤーを、現在のアクティブレイヤーへマスクします。対象レイヤーを確認してから実行してください。',
    'Remove all masks from layers of the selected strokes': '選択ストロークがあるレイヤーから、すべてのマスク設定を削除します。解除対象を確認してから実行してください。',
    'Toggles mask visablity of all layers': 'すべてのレイヤーのマスク表示状態を切り替えます。表示確認や編集対象の整理に使います。',
    'Creates a Panel in the 3D Viewport Sidebar': '3Dビューポートのサイドバーに、このツール用パネルを作成します。',
})
blender_translations.setdefault('ja_JP', {}).update({('*', _k): _v for _k, _v in _SUITE_EXTRA_JA_TEXTS.items()})
# --- full UI i18n completion patch END ---

# --- full UI i18n extension v5 START ---
# Additional UI strings added so the add-on uses Blender's active language
# instead of showing two language variants at once.
_SSSUITE_EXTRA_JA_TRANSLATIONS = {'  * Ctrl+LMB - Expand/Collapse all sublevels\n  * Shift+LMB - Isolate tree/Restore\n  * Alt+LMB - Discard history': '  * Ctrl+左クリック - '
                                                                                                                      '全サブ階層を展開/折りたたみ\n'
                                                                                                                      '  * Shift+左クリック - '
                                                                                                                      'ツリーを分離表示/復元\n'
                                                                                                                      '  * Alt+左クリック - '
                                                                                                                      '履歴を破棄',
 '  * LMB - Enable all/Restore.\n  * Shift+LMB - Invert.\n  * Shift+Ctrl+LMB - Isolate collections w/ selected objects.\n  * Shift+Alt+LMB - Disable collections w/ selected objects.\n  * Ctrl+LMB - Copy/Paste RTOs.\n  * Ctrl+Alt+LMB - Swap RTOs.\n  * Alt+LMB - Discard history': '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       '左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'すべて有効/復元\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '反転\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+Ctrl+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '選択オブジェクトを含むコレクションを分離表示\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Shift+Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '選択オブジェクトを含むコレクションを無効化\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Ctrl+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'RTO '
                                                                                                                                                                                                                                                                                       'をコピー/貼り付け\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Ctrl+Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       'RTO '
                                                                                                                                                                                                                                                                                       'を入れ替え\n'
                                                                                                                                                                                                                                                                                       '  '
                                                                                                                                                                                                                                                                                       '* '
                                                                                                                                                                                                                                                                                       'Alt+左クリック '
                                                                                                                                                                                                                                                                                       '- '
                                                                                                                                                                                                                                                                                       '履歴を破棄',
 '  * LMB - Move objects to collection.\n  * Shift+LMB - Add/Remove objects from collection': '  * 左クリック - オブジェクトをコレクションへ移動\n'
                                                                                              '  * Shift+左クリック - オブジェクトをコレクションに追加/解除',
 '  * LMB - Select all objects in collection.\n  * Shift+LMB - Add/Remove collection objects from selection.\n  * Ctrl+LMB - Isolate nested selection.\n  * Ctrl+Shift+LMB - Add/Remove nested from selection': '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                '左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'コレクション内の全オブジェクトを選択\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Shift+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'コレクション内オブジェクトを選択に追加/解除\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Ctrl+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'ネスト選択を分離表示\n'
                                                                                                                                                                                                                '  '
                                                                                                                                                                                                                '* '
                                                                                                                                                                                                                'Ctrl+Shift+左クリック '
                                                                                                                                                                                                                '- '
                                                                                                                                                                                                                'ネスト項目を選択に追加/解除',
 '  * Shift+LMB - Isolate/Restore.\n  * Shift+Ctrl+LMB - Isolate nested/Restore.\n  * Ctrl+LMB - Toggle nested.\n  * Alt+LMB - Discard history': '  '
                                                                                                                                                 '* '
                                                                                                                                                 'Shift+左クリック '
                                                                                                                                                 '- '
                                                                                                                                                 '分離表示/復元\n'
                                                                                                                                                 '  '
                                                                                                                                                 '* '
                                                                                                                                                 'Shift+Ctrl+左クリック '
                                                                                                                                                 '- '
                                                                                                                                                 'ネストを分離表示/復元\n'
                                                                                                                                                 '  '
                                                                                                                                                 '* '
                                                                                                                                                 'Ctrl+左クリック '
                                                                                                                                                 '- '
                                                                                                                                                 'ネストを切替\n'
                                                                                                                                                 '  '
                                                                                                                                                 '* '
                                                                                                                                                 'Alt+左クリック '
                                                                                                                                                 '- '
                                                                                                                                                 '履歴を破棄',
 '1 or more objects moved to Scene Collection.': '1 個以上のオブジェクトをシーンコレクションへ移動しました。',
 '3D Viewport header widget for the QCD slots. This widget is kept active with the QCD system.': 'QCD スロット用の 3D ビューポートヘッダーウィジェットです。QCD '
                                                                                                 'システムと一緒に有効になります。',
 'About': '説明',
 'Active Smart Selector project folder name. Change it from the Smart Selector Project picker; the selector list below reads selector .json files from this project.': 'アクティブな '
                                                                                                                                                                    'Smart '
                                                                                                                                                                    'Selector '
                                                                                                                                                                    'プロジェクトフォルダ名です。Smart '
                                                                                                                                                                    'Tools '
                                                                                                                                                                    'のプロジェクト選択で切り替えます。下のセレクター一覧は、このプロジェクト内の '
                                                                                                                                                                    '.json '
                                                                                                                                                                    'ファイルを読み込みます。',
 'Active layer is hidden': 'アクティブレイヤーが非表示です。',
 "Active layer's group is hidden": 'アクティブレイヤーのグループが非表示です。',
 'Add Collection': 'コレクションを追加',
 'Add New Collection': '新規コレクションを追加',
 'Add Prefix to Selected': '選択項目へ接頭辞を追加',
 'Add Prefix to layers with selected strokes': '選択中ストロークがあるレイヤーへ接頭辞を追加します。',
 'Add SubCollection': 'サブコレクションを追加',
 'Add Suffix': '接尾辞を追加',
 'Add suffix to layers with selected strokes': '選択中ストロークがあるレイヤーへ接尾辞を追加します。',
 'Adds all layers of the selected strokes to a new group': '選択ストロークの全レイヤーを新しいグループへ追加します。',
 'Affixes': '付ける文字',
 'Align Local Options': 'ローカルオプションを整列',
 'Align local options in a column to the right': 'ローカルオプションを右側の列に整列します。',
 'All QCD slots are already enabled and isolated.': 'すべての QCD スロットは既に有効で分離表示されています。',
 'All QCD slots are already enabled.': 'すべての QCD スロットは既に有効です。',
 'All collections are already disabled.': 'すべてのコレクションは既に無効です。',
 'All non QCD slots are already disabled.': 'QCD 以外のスロットは既に無効です。',
 'All objects made selectable': 'すべてのオブジェクトを選択可能にしました。',
 'Allow Execute Script': 'スクリプト実行を許可',
 'Allow selector buttons to execute custom Python scripts from the browser. Turn OFF for safety when sharing files or when you only need selection/slider actions.': 'ブラウザのセレクターボタンからカスタム '
                                                                                                                                                                     'Python '
                                                                                                                                                                     'スクリプトを実行することを許可します。ファイルを共有する場合や、選択/スライダー操作だけで十分な場合は安全のため '
                                                                                                                                                                     'OFF '
                                                                                                                                                                     'にしてください。',
 'Always Active': '常時有効',
 'Apply Layer Pass Index?': 'レイヤーパスインデックスを適用しますか？',
 'Apply Opacity': '不透明度を適用',
 'Apply Phantom Mode': 'ファントムモードを適用',
 'Apply Selection': '選択を適用',
 'Apply Sensitivity': '感度を適用',
 'Apply changes and quit Phantom Mode': '変更を適用してファントムモードを終了します。',
 'Archive Project': 'プロジェクトをアーカイブ',
 'Assign Weight': 'ウェイト割り当て',
 'Assign Weight To Selected': '選択項目へウェイト割り当て',
 'Assign Weight by Name': '名前でウェイト割り当て',
 'Assign weight to selected stroke Layers from Vertex Groups of the same name (For Premade rigs with already set names. Or use Sync layer names in WP mode)': '同名の頂点グループから、選択ストロークのレイヤーへウェイトを割り当てます。既に名前が設定された既存リグ向けです。必要に応じてウェイトペイントモードで レイヤー名を同期 を使ってください。',
 'Assign weight to selected strokes using the selected bone/v-group. Works on Mutiple frames with Multiframe on ( Use with Weight selected )': '選択中のボーンまたは頂点グループを使って、選択ストロークへウェイトを割り当てます。マルチフレーム ON の場合は複数フレームに対応します。「選択へウェイト」 と組み合わせて使います。',
 'Backup Generations': 'バックアップ世代数',
 'Blender Redo': 'やり直し',
 'Blender Undo': '元に戻す',
 'Bridge Actions': 'ブリッジ操作',
 'Can only be executed in Object Mode': 'オブジェクトモードでのみ実行できます。',
 "Can't set excluded collection as active": '除外されたコレクションはアクティブにできません。',
 'Cannot execute.  The active object would be lost.': '実行できません。アクティブオブジェクトが失われます。',
 'Clean Digits/Punctuation': '数字・記号を整理',
 'Clear': 'クリア',
 'Clear Selected Stroke Weights': '選択ストロークのウェイトをクリア',
 'Clear a specific text field': '指定したテキスト欄をクリアします。',
 'Clear all vertex weight from the selected strokes': '選択ストロークからすべての頂点ウェイトをクリアします。',
 'Cleared weights from selected strokes': '選択中ストロークのウェイトをクリアしました。',
 'Collection Manager': 'コレクションマネージャー',
 'Collection Manager Integration': 'コレクションマネージャー',
 "Control Opacity of all selected stroke's layers.(set value then click apply)": '選択中ストロークがあるすべてのレイヤーの不透明度を調整します。値を設定してから適用を押してください。',
 'Controller Sensitivity:': 'コントローラー感度:',
 'Create All QCD Slots': '全 QCD スロットを作成',
 'Create Pass Index Time Control': 'インデックスパスの時間オフセット制御を作成',
 'Create Indexed Time Offset Rig': 'インデックス付き時間オフセットリグを作成',
 'Create Layers from Vertex Group names ( For premade rigs, Then you can draw on the layers that have the correct names)': '頂点グループ名からレイヤーを作成します。既存リグ向けで、正しい名前のレイヤーへ描画できるようになります。',
 'Create New Selector': '新規セレクター作成',
 'Create Project': 'プロジェクト作成',
 'Create Time Offset Rig': '時間オフセットリグを作成',
 "Create a Time Offset Controller for every selected stroke layer ( Will make a new armature if you don't have one parented )": '選択ストロークレイヤーごとに時間オフセットコントローラーを作成します。親になっているアーマチュアがない場合は新規作成します。',
 'Create a Time Offset rig/modifier to control multiple layers with Pass Index ( For the Selected strokes. Will make a rig if gp is not parented )': 'パスインデックスで複数レイヤーを制御する時間オフセットリグ/モディファイアを作成します。選択ストローク向けです。GP に親がない場合はリグを作成します。',
 'Create any missing QCD slots so you have a full 20': '不足している QCD スロットを作成し、20 個すべて揃えます。',
 'Create Layer Time Control': 'レイヤー時間オフセット制御を作成',
 'Creates a Panel in the 3D Viewport Sidebar': '3D ビューポートサイドバーにパネルを作成します。',
 'Custom Property Payload': 'カスタムプロパティペイロード',
 'Data Save Root Directory': 'データ保存ルートディレクトリ',
 'Delete Empty Layers: Are you sure!?': '空レイヤーを削除します。よろしいですか？',
 'Delete Layers?': 'レイヤーを削除しますか？',
 'Delete Selected Layers': '選択レイヤーを削除',
 'Delete empty Grease Pencil layers (Skips Hidden, Locked, or Hidden Groups)': '空の Grease Pencil レイヤーを削除します。非表示、ロック済み、非表示グループはスキップします。',
 'Delete layers of the selected strokes': '選択ストロークのレイヤーを削除します。',
 'Disable All Non QCD Slots': 'QCD 以外の全スロットを無効化',
 'Disable All collections': '全コレクションを無効化',
 'Disable Objects Override': '非表示の代わりに無効化',
 'Disable Selected': '選択項目を無効化',
 'Disable Selected Objects Collections': '選択オブジェクトのコレクションを無効化',
 'Disable Unselected': '未選択項目を無効化',
 'Disable all collections that contain the selected objects': '選択オブジェクトを含むすべてのコレクションを無効化します。',
 'Disable objects instead of Hiding': '非表示の代わりにオブジェクトを無効化',
 'Disable selected objects in viewports': '選択中オブジェクトをビューポートで無効化します。',
 'Disable unselected objects in viewports': '未選択オブジェクトをビューポートで無効化します。',
 'Discard History': '履歴を破棄',
 'Discard QCD History': 'QCD 履歴を破棄します。',
 'Display Options': '表示オプション',
 'Draw': '描画',
 'Draw Brush': '描画ブラシ',
 'Dup & Hide Original': '複製して元を非表示',
 'Duplicate & Assign Material': '複製してマテリアル割り当て',
 'Duplicate & Hide Original': '複製して元を非表示',
 'Duplicate Project': 'プロジェクト複製',
 "Duplicate Stroke's material and assign the new one(s) to the strokes.": 'ストロークのマテリアルを複製し、新しいマテリアルをストロークへ割り当てます。',
 'Duplicate layers of selected strokes and hide the originals': '選択ストロークのレイヤーを複製し、元レイヤーを非表示にします。',
 'Enable All QCD Slots': '全 QCD スロットを有効化',
 'Enable All QCD Slots Isolated': '全 QCD スロットを分離状態で有効化',
 'Enable/Disable QCD System.\nThe Quick Content Display system allows you to specify collections as QCD "slots" up to a maximum of 20. You can then interact with them through numerical hotkeys, a popup move widget, and a 3D Viewport header widget': 'QCD システムを有効/無効にします。\nQCD では、最大 20 個までのコレクションを QCD「スロット」として指定できます。数値ホットキー、ポップアップ移動ウィジェット、3D ビューポートヘッダーウィジェットから操作できます。',
 'Error removing 1 or more objects from the Scene Collection.  Objects would be left without a collection.': 'シーンコレクションから 1 '
                                                                                                             '個以上のオブジェクトを削除できませんでした。コレクションに属さないオブジェクトが発生します。',
 'Execute Smart Selector Script': 'スマートセレクター スクリプト実行',
 'Expand All Items': '全項目を展開',
 'Expand Sublevel Items': 'サブ階層を展開',
 'Expand/Collapse all collections': 'すべてのコレクションを展開/折りたたみします。',
 'Favorites Only': 'お気に入りのみ',
 'Filter By Name': '名前でフィルター',
 'Filter By QCD': 'QCDでフィルター',
 'Filter By Selected': '選択項目でフィルター',
 'Filter collections by name': '名前でコレクションを絞り込みます。',
 'Filter collections to only show the ones that are QCD slots': 'QCDスロットのコレクションだけを表示します。',
 'Filter collections to only show the ones that contain the selected objects': '選択中オブジェクトを含むコレクションだけを表示します。',
 'Find': '検索',
 'Find and replace text in layers of selected strokes': '選択中ストロークがあるレイヤー名の文字列を検索して置換します。',
 'Function: Collection Manager QCD system with slot controls, move widget access, and related runtime hooks. How to use: use QCD slots or widget workflows directly while Smart Selector is enabled.': '機能: コレクションマネージャーの QCD システムとして、スロット操作、移動ウィジェット、関連する実行時フックを提供します。使い方: スマートセレクターが有効な間、QCD スロットやウィジェット操作をそのまま使用してください。',
 'Function: QCD slot widget shown in the 3D View header. How to use: click slot controls directly in the 3D View header.': '機能: 3Dビューヘッダーに表示される QCD スロットウィジェットです。使い方: 3Dビューヘッダーからスロットを直接クリックして操作します。',
 'Function: keeps the integrated Collection Manager available inside Smart Selector across Blender sessions. How to use: use the migrated package directly while Smart Selector is enabled.': '機能: コレクションマネージャーを Smart Tools 内で Blender セッションをまたいで利用できる状態に保ちます。使い方: スマートセレクターが有効な間、移植済みパッケージをそのまま使用してください。',
 'Function: keeps the integrated GP Select package available inside Smart Selector across Blender sessions. How to use: use Grease Pencil selection, layer management, masking, or rigging helpers directly from Smart Selector.': '機能: GP セレクトパッケージを Smart Tools 内で Blender セッションをまたいで利用できる状態に保ちます。使い方: Grease Pencil の選択、レイヤー管理、マスク、リギング補助を Smart Tools から直接使用してください。',
 'Function: numeric QCD hotkeys inside supported Edit modes. How to use: switch QCD slots while editing geometry or Grease Pencil strokes.': '機能: '
                                                                                                                                             '対応している編集モード中の数値キー '
                                                                                                                                             'QCD '
                                                                                                                                             'ホットキーです。使い方: '
                                                                                                                                             'ジオメトリ編集中や '
                                                                                                                                             'Grease '
                                                                                                                                             'Pencil '
                                                                                                                                             'ストローク編集中に '
                                                                                                                                             'QCD '
                                                                                                                                             'スロットを切り替えます。',
 'Function: numeric QCD hotkeys used in Object, Pose, and Weight Paint modes. How to use: use the keyboard to switch slot views while QCD is active.': '機能: オブジェクト・ポーズ・ウェイトペイントのモードで使う数値キーの QCD ホットキーです。使い方: QCD が有効な状態でキーボードからスロット表示を切り替えます。',
 'Function: replaces the H-based hide shortcuts with Disable Object controls and adds the related commands to Collection Manager runtime. How to use: use this option when you want hidden objects to stay disabled instead of being revealed by collection changes.': '機能: H 系の非表示ショートカットを オブジェクト無効化の系の操作に置き換え、コレクションマネージャーの実行時機能へ関連コマンドを追加します。使い方: コレクション変更で再表示されないよう、オブジェクトを無効化したい場合に使用します。',
 'Function: stores the JSON payload used by the internal Custom Property bridge operator. How to use: paste a JSON object such as {"obj":"Cube","path":"location[0]","value":1.0} and press Set Custom Property below.': '機能: 内部の カスタムプロパティ ブリッジオペレーターで使う JSON ペイロードを保持します。使い方: {"obj":"Cube","path":"location[0]","value":1.0} のような JSON オブジェクトを貼り付け、下の カスタムプロパティを設定 を押してください。',
 'Function: stores the JSON payload used by the internal Execute Script bridge operator. How to use: paste a JSON object such as {"script":"print(\'Hello\')"} and press Execute Script below.': '機能: 内部の スクリプトを実行 ブリッジオペレーターで使う JSON ペイロードを保持します。使い方: {"script":"print(\'Hello\')"} のような JSON オブジェクトを貼り付け、下の スクリプトを実行 を押してください。',
 'Function: stores the JSON payload used by the internal Shape Key bridge operator. How to use: paste a JSON object such as {"obj":"Character","key":"Smile","value":1.0} and press Set Shape Key below.': '機能: 内部のシェイプキーブリッジオペレーターで使う JSON ペイロードを保持します。使い方: {"obj":"Character","key":"Smile","value":1.0} のような JSON オブジェクトを貼り付け、下のシェイプキーを設定 を押してください。',
 'Function: stores the JSON payload used by the internal selection bridge operator. How to use: paste a JSON object such as {"target_type":"object","objects":["Cube"]} and press Apply Selection below.': '機能: 内部の選択ブリッジオペレーターで使う JSON ペイロードを保持します。使い方: {"target_type":"object","objects":["Cube"]} のような JSON オブジェクトを貼り付け、下の 選択を適用 を押してください。',
 'GP Select': 'GP セレクト',
 'GP Select Integration': 'GP セレクト',
 'Global QCD Slot Actions': 'QCDスロット全体操作',
 'Gp Select': 'GP セレクト',
 'Group Name': 'グループ名',
 'Group Selected Stroke Layers': '選択ストロークレイヤーをグループ化',
 'Group selected': '選択項目をグループ化',
 'Hide Selected': '選択項目を非表示',
 'Hide Selected Layers': '選択レイヤーを非表示',
 'Hide layer of the selected strokes': '選択ストロークのレイヤーを非表示にします。',
 'How many backup generations (.bak) to keep in a .backup folder next to each JSON/image when saving. Set 0 to disable backups. Higher values use more disk space but make it easier to restore older versions.': '保存時に各 '
                                                                                                                                                                                                                  'JSON/画像の隣の '
                                                                                                                                                                                                                  '.backup '
                                                                                                                                                                                                                  'フォルダへ残すバックアップ（.bak）の世代数です。0 '
                                                                                                                                                                                                                  'にするとバックアップを無効化します。値を大きくすると使用容量は増えますが、古い状態へ戻しやすくなります。',
 'How often Blender state is synced to the browser (selection, active object, and watched Shape Keys). Increase this value if Blender feels slow in heavy scenes. Typical: 0.5–1.0 seconds.': 'Blender '
                                                                                                                                                                                              'の状態（選択、アクティブオブジェクト、監視中のシェイプキー）をブラウザへ同期する間隔です。重いシーンで '
                                                                                                                                                                                              'Blender '
                                                                                                                                                                                              'が遅く感じる場合は値を大きくしてください。目安は '
                                                                                                                                                                                              '0.5〜1.0 '
                                                                                                                                                                                              '秒です。',
 'If enabled, all selected strokes will share one duplicated material': '有効にすると、選択した全ストロークが 1 つの複製マテリアルを共有します。',
 'Infix': '中間文字',
 'Initializing...': '初期化中...',
 'Inner': '内側',
 'Integrated Add-on Info': '統合アドオン情報',
 'Integrated Tool': 'ツールコマンド',
 'Integrated Tools': 'ツールグループ',
 'Integrated tools are loaded automatically while this toolset add-on is enabled. Runtime switching controls have been removed.': 'このツールセットアドオンが有効な間、ツールは自動で読み込まれます。ランタイムの切替操作は廃止されています。',
 'Invert': '反転',
 'Invert Masks': 'マスクを反転',
 'Invert filtering (show hidden items, and vice-versa)': 'フィルター結果を反転します。非表示項目を表示し、表示項目を隠します。',
 'Invert masks on layers of the selected strokes': '選択ストロークのレイヤー上のマスクを反転します。',
 'Inverted masks': 'マスクを反転しました。',
 'Isolate Selected': '選択項目を分離表示',
 'Isolate Selected Objects Collections': '選択オブジェクトのコレクションを分離表示',
 'Isolate Stroke': 'ストロークを分離表示',
 'Isolate collections (via EC) that contain the selected objects': '選択オブジェクトを含むコレクションを EC で分離表示します。',
 'Lasso': '投げ縄',
 'Lasso Edit': '投げ縄編集',
 'Launch and manage Smart Selector (browser-based selector UI) for the active project. Create/open selector JSON files and mark favorites.': 'アクティブプロジェクトの '
                                                                                                                                                   'Smart '
                                                                                                                                                   'Selector '
                                                                                                                                                   '（ブラウザ式セレクター '
                                                                                                                                                   'UI）を起動・管理します。セレクター '
                                                                                                                                                   'JSON '
                                                                                                                                                   'の作成/表示とお気に入り登録ができます。',
 'Mask Layer with Strokes': 'ストロークでレイヤーをマスク',
 'Layer Tools': 'レイヤーツール',
 'Layer sent to Bottom.': 'レイヤーを最下部へ移動しました。',
 'Layer sent to Top.': 'レイヤーを最上部へ移動しました。',
 'Layout': 'レイアウト',
 'Lock Selected layers': '選択レイヤーをロック',
 "Lock materials of unselected stroke's (Toggleable)": '未選択ストロークのマテリアルをロックします。切替式です。',
 'Lock the layers of selected strokes (Toggleable)': '選択ストロークのレイヤーをロックします。切替式です。',
 'Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when switching modes. Respects the Multiframe setting, and Auto lock )': '選択ストロークのレイヤーとマテリアルをロックし、アーマチュアを選択して他オブジェクトを選択不可にしたうえでウェイトペイントモードへ入ります。切替式で、モード変更時に解除されます。マルチフレーム設定と自動ロックを尊重します。',
 'Make V-Group Layers?': '頂点グループレイヤーを作成しますか？',
 'Make layers From Groups': 'グループからレイヤー作成',
 'Mask Active to Selected': 'アクティブを選択項目へマスク',
 'Mask selected strokes layers to the active layer ': '選択ストロークのレイヤーをアクティブレイヤーへマスクします。',
 'Mask the active layer to the selected strokes layers': 'アクティブレイヤーを選択ストロークのレイヤーへマスクします。',
 'Mask to Active': 'アクティブへマスク',
 'Mask:': 'マスク:',
 'Menu': 'メニュー',
 'Menu Inner Color': 'メニュー内側色',
 'Menu Inner Override': 'メニュー内側色上書き',
 'Menu Outline Color': 'メニュー輪郭色',
 'Menu Outline Override': 'メニュー輪郭色上書き',
 'Menu Text Color': 'メニュー文字色',
 'Menu Text Override': 'メニュー文字色上書き',
 'Modes': 'モード',
 'Modifier Name': 'モディファイア名',
 'Move Above': '上へ移動',
 'Move Below': '下へ移動',
 'Move Group Above Selection': 'グループを選択項目の上へ移動',
 'Move Group Below Selection': 'グループを選択項目の下へ移動',
 'Move Layers to Bottom': 'レイヤーを最下部へ移動',
 'Move Layers to Top': 'レイヤーを最上部へ移動',
 'Move Selected Above': '選択項目を上へ移動',
 'Move Selected Below': '選択項目を下へ移動',
 'Move To QCD Slot': 'QCD スロットへ移動',
 'Move layers of the selected strokes to the bottom': '選択ストロークのレイヤーを最下部へ移動します。',
 'Move layers of the selected strokes to the top': '選択ストロークのレイヤーを最上部へ移動します。',
 'Move object(s) to QCD slot': 'オブジェクトを QCD スロットへ移動します。',
 'Move objects to QCD Slots': 'オブジェクトを QCD スロットへ移動します。',
 'Move the active Group Bellow the selected stroke layer': 'アクティブグループを選択ストロークレイヤーの下へ移動します。',
 'Move the active Group above the selected stroke layer': 'アクティブグループを選択ストロークレイヤーの上へ移動します。',
 "Move the selected stroke's layers Above the active layer": '選択ストロークのレイヤーをアクティブレイヤーの上へ移動します。',
 "Move the selected stroke's layers Bellow the active layer": '選択ストロークのレイヤーをアクティブレイヤーの下へ移動します。',
 'Name for the new project folder. Use letters, numbers, and underscores to avoid OS path issues.': '新しいプロジェクトフォルダ名です。OS '
                                                                                                    'のパス問題を避けるため、英数字とアンダースコア（_）中心の名前を推奨します。',
 'Name of the duplicated project folder that will be created. All selector files and images are copied.': '複製して作成するプロジェクトフォルダ名です。すべてのセレクターファイルと画像がコピーされます。',
 'New Name': '新しい名前',
 'New Project Name': '新規プロジェクト名',
 'New folder name for the current project. This renames the folder on disk.': '現在のプロジェクトに設定する新しいフォルダ名です。ディスク上のフォルダ名も変更されます。',
 'No Active Group Found': 'アクティブグループが見つかりません。',
 'No QCD slots.': 'QCDスロットがありません。',
 'No V-Groups Found': '頂点グループが見つかりません。',
 'No active Vertex Group found': 'アクティブな頂点グループが見つかりません。',
 'No active Vertex Group selected': 'アクティブな頂点グループが選択されていません。',
 'No collections selected.': 'コレクションが選択されていません。',
 'No connected Time Offset drivers found for selection.': '選択対象に接続済み時間オフセットドライバーが見つかりません。',
 'No connected Time Offset modifiers found.': '接続済み時間オフセットモディファイアが見つかりません。',
 'No empty layers found': '空レイヤーは見つかりませんでした。',
 'No layers have masks': 'マスクを持つレイヤーがありません。',
 'No objects present to select.': '選択できるオブジェクトがありません。',
 'No objects selected.': 'オブジェクトが選択されていません。',
 'No selected strokes found': '選択中のストロークが見つかりません。',
 'No selected strokes found.': '選択中のストロークが見つかりません。',
 'Not in Gp Edit mode': 'GP 編集モードではありません。',
 'Numerical hotkeys for viewing QCD slots in Edit Mode. These are kept active with the QCD system.': '編集モードで QCD スロットを表示するための数値ホットキーです。QCD '
                                                                                                     'システムと一緒に有効になります。',
 'Numerical hotkeys for viewing QCD slots. These are kept active with the QCD system.': 'QCD スロット表示用の数値ホットキーです。QCD システムと一緒に有効になります。',
 'ONLY FOR CLEAN UP. This deletes layers with nothing found on them.': 'クリーンアップ専用です。中身が見つからないレイヤーを削除します。',
 'Objects': 'オブジェクト',
 'Only Works on Single layers': '単一レイヤーでのみ使用できます。',
 'Opacity': '不透明度',
 'Open Project Folder': 'プロジェクトフォルダを開く',
 'Open Selector': 'セレクターを開く',
 'Open Smart Selector controls in the Properties editor': 'スマートセレクターの操作パネルをプロパティエディターで開きます。',
 'Outline': '輪郭',
 'Pass': 'パス',
 'Pass Index': 'パスインデックス',
 'Performance / Safety': 'パフォーマンスと安全性',
 'Phantom Mode\nSaves the state of all RTOs and only allows changes to them, on exit all RTOs are returned to their saved state.\nNote: modifying collections (except RTOs) externally will exit Phantom Mode and your initial state will be lost': 'ファントムモード\n'
                                                                                                                                                                                                                                                    'すべての '
                                                                                                                                                                                                                                                    'RTO '
                                                                                                                                                                                                                                                    '状態を保存し、RTO '
                                                                                                                                                                                                                                                    'だけを変更できるようにします。終了時に '
                                                                                                                                                                                                                                                    'RTO '
                                                                                                                                                                                                                                                    'は保存状態へ戻ります。\n'
                                                                                                                                                                                                                                                    '注意: '
                                                                                                                                                                                                                                                    '外部からコレクション（RTO '
                                                                                                                                                                                                                                                    '以外）を変更するとファントムモードが終了し、初期状態は失われます。',
 'Pinch': 'ピンチ',
 'Prefix': '接頭辞',
 'Proceed with cleanup?': 'クリーンアップを続行しますか？',
 'Proceed?': '続行しますか？',
 'Project': 'プロジェクト',
 'Project List': 'プロジェクト一覧',
 'Project Name': 'プロジェクト名',
 'Project folder name to make active in Smart Selector.': 'スマートセレクターでアクティブにするプロジェクトフォルダ名です。',
 'Pull': '引き寄せ',
 'Purge All Collections Without Objects': 'オブジェクトなしの全コレクションを削除',
 'QCD': 'QCD',
 'QCD 3D Viewport Header Widget': 'QCD 3Dビューポートヘッダーウィジェット',
 'QCD All Meta Operator': 'QCD 全体操作のメタオペレーターです。',
 'QCD Edit Hotkeys': 'QCD編集モードホットキー',
 'QCD Edit Mode Hotkeys': 'QCD編集モードホットキー',
 'QCD Header Widget': 'QCDヘッダーウィジェット',
 'QCD Hotkeys': 'QCDホットキー',
 'QCD Move Widget': 'QCD移動ウィジェット',
 'QCD Move Widget Menu Back Inner Color': 'QCD移動ウィジェットのメニュー内側色',
 'QCD Move Widget Menu Back Outline Color': 'QCD移動ウィジェットのメニュー輪郭色',
 'QCD Move Widget Menu Back Text Color': 'QCD移動ウィジェットのメニュー文字色',
 'QCD Move Widget Tool Inner Color': 'QCD移動ウィジェットのツール内側色',
 'QCD Move Widget Tool Inner Selection Color': 'QCD移動ウィジェットのツール選択内側色',
 'QCD Move Widget Tool Outline Color': 'QCD移動ウィジェットのツール輪郭色',
 'QCD Move Widget Tool Text Color': 'QCD移動ウィジェットのツール文字色',
 'QCD Move Widget Tool Text Selection Color': 'QCD移動ウィジェットのツール選択文字色',
 'QCD Move Widget Tooltip Inner Color': 'QCD移動ウィジェットのツールチップ内側色',
 'QCD Move Widget Tooltip Outline Color': 'QCD移動ウィジェットのツールチップ輪郭色',
 'QCD Move Widget Tooltip Text Color': 'QCD移動ウィジェットのツールチップ文字色',
 'QCD Runtime': 'QCD実行時機能',
 'QCD Runtime: Always Active': 'QCD実行時機能: 常時有効',
 'QCD Slot': 'QCDスロット',
 'QCD View Hotkeys': 'QCD表示ホットキー',
 'Quick View Toggles': 'クイック表示切替',
 'Redo': 'やり直し',
 'Redo previous action': '前の操作をやり直します。',
 'Remove Collection': 'コレクションを削除',
 'Remove Digits and Punctuation from layers with selected strokes': '選択中ストロークがあるレイヤー名から数字と記号を削除します。',
 'Remove Empty Collections': '空コレクションを削除',
 'Remove Setup': 'セットアップ削除',
 'Remove Setup From Selected Bone': '選択ボーンからセットアップを削除',
 'Remove all masks from layers of the selected strokes ': '選択ストロークのレイヤーからすべてのマスクを削除します。',
 'Rename': '名前変更',
 'Rename Full Name': '名前全体を変更',
 'Rename Project': 'プロジェクト名変更',
 "Rename stroke's layer based off the selected vertex group (Use inside WP mode For Assign Weight by Name)": '選択中の頂点グループを基準にストロークのレイヤー名を変更します。名前でウェイト割り当て 用にウェイトペイントモード内で使います。',
 'Renaming and Pass Index': 'リネームとパスインデックス',
 'Renumber QCD Slots': 'QCD スロット番号を振り直し',
 'Renumber QCD slots.\n  * LMB - Renumber (breadth first) from slot 1.\n  * +Ctrl - Linear.\n  * +Alt - Reset.\n  * +Shift - Constrain to branch': 'QCD '
                                                                                                                                                   'スロット番号を振り直します。\n'
                                                                                                                                                   '  '
                                                                                                                                                   '* '
                                                                                                                                                   '左クリック '
                                                                                                                                                   '- '
                                                                                                                                                   'スロット '
                                                                                                                                                   '1 '
                                                                                                                                                   'から幅優先で番号を振り直し\n'
                                                                                                                                                   '  '
                                                                                                                                                   '* '
                                                                                                                                                   '+Ctrl '
                                                                                                                                                   '- '
                                                                                                                                                   '線形\n'
                                                                                                                                                   '  '
                                                                                                                                                   '* '
                                                                                                                                                   '+Alt '
                                                                                                                                                   '- '
                                                                                                                                                   'リセット\n'
                                                                                                                                                   '  '
                                                                                                                                                   '* '
                                                                                                                                                   '+Shift '
                                                                                                                                                   '- '
                                                                                                                                                   'ブランチ内に制限',
 'Replace': '置換',
 'Replace Text': 'テキスト置換',
 'Replace full name of layers ': 'レイヤー名全体を置き換えます。',
 'Replace the entire name of selected layers': '選択したレイヤー名全体を置き換えます。',
 'Replace the object hiding hotkeys with object disabling hotkeys and add them to the Object->Show/Hide menu.\nDisabling objects prevents them from being automatically shown again when collections are unexcluded': 'オブジェクト非表示ホットキーをオブジェクト無効化ホットキーに置き換え、Object→Show/Hide '
                                                                                                                                                                                                                      'メニューへ追加します。\n'
                                                                                                                                                                                                                      'オブジェクトを無効化すると、コレクションの除外解除時に自動で再表示されることを防げます。',
 'Reset Indexes?': 'インデックスをリセットしますか？',
 'Reset Pass Indexes to 0 ': 'パスインデックスを 0 にリセットしました。',
 'Reset all layers to 100% opacity': 'すべてのレイヤーの不透明度を 100% に戻します。',
 'Reset layers and materials Pass Index to 0 for the selected strokes': '選択ストロークのレイヤーとマテリアルのパスインデックスを 0 にリセットします。',
 'Reset layers, remove the GP modifiers, and delete control bones (Select the control bone for this)': 'レイヤーをリセットし、GP '
                                                                                                       'モディファイアを削除し、制御ボーンを削除します。この操作では制御ボーンを選択してください。',
 'Restore All Opacity': '全不透明度を復元',
 'Restore Disabled Objects': '無効化オブジェクトを復元',
 'Restore disabled objects in viewports': 'ビューポートで無効化したオブジェクトを復元します。',
 'Restriction Toggles': '制限切替',
 'Rigging': 'リギング',
 'Rigging Tools': 'リギングツール',
 'Root folder where Smart Selector projects are stored (one subfolder per project). Leave blank to use CONFIG/Smart_Selector_Suite for this add-on. Changing this does not move existing projects automatically. Use this if you want to store projects on a different drive or shared folder.': 'Smart '
                                                                                                                                                                                                                                                                                                                'Selector '
                                                                                                                                                                                                                                                                                                                'のプロジェクトを保存するルートフォルダです（1プロジェクトにつき1サブフォルダ）。空欄の場合は、CONFIG/Smart_Selector_Suite '
                                                                                                                                                                                                                                                                                                                'を使用します。変更しても既存プロジェクトは自動移動しません。別ドライブや共有フォルダに保存したい場合に使います。',
 'Runtime': '実行時機能',
 'Runtime state is unavailable.': '実行時状態を取得できません。',
 'Scene Collection': 'シーンコレクション',
 'Script Payload': 'スクリプトペイロード',
 'Select A Grease Pencil Object.': 'Grease Pencil オブジェクトを選択してください。',
 'Select All Cumulative Objects': '累積オブジェクトをすべて選択',
 'Select All Objects in the Collection': 'コレクション内の全オブジェクトを選択',
 'Select All QCD Objects': '全 QCD オブジェクトを選択',
 'Select By:': '選択条件:',
 'Select Similar Infix': '同じ中間文字を選択',
 'Select Similar Prefix': '同じ接頭辞を選択',
 'Select Similar Suffix': '同じ接尾辞を選択',
 'Select all objects in QCD slots': 'QCD スロット内の全オブジェクトを選択します。',
 'Select all objects that are present in more than one collection': '複数のコレクションに存在する全オブジェクトを選択します。',
 'Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected ) ': '選択中ストロークと同じ中間文字を持つ全レイヤーのストロークを選択します。マルチフレーム設定を尊重します。代表となるストロークを '
                                                                                                                                                           '1 '
                                                                                                                                                           'つ選べば実行できます。',
 'Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected ) ': '選択中ストロークと同じ接頭辞を持つ全レイヤーのストロークを選択します。マルチフレーム設定を尊重します。代表となるストロークを '
                                                                                                                                                              '1 '
                                                                                                                                                              'つ選べば実行できます。',
 'Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected )': '選択中ストロークと同じ接尾辞を持つ全レイヤーのストロークを選択します。記号を含む名前にも対応し、マルチフレーム設定を尊重します。代表となるストロークを '
                                                                                                                                                                                     '1 '
                                                                                                                                                                                     'つ選べば実行できます。',
 'Selected': '選択',
 'Selection': '選択',
 'Selection & Reordering': '選択と並べ替え',
 'Selection Payload': '選択ペイロード',
 'Selector Data List': 'セレクターデータ一覧',
 'Send Objects to Collection': 'オブジェクトをコレクションへ送る',
 'Send Report': 'レポート送信',
 'Send to Bottom': '最下部へ送る',
 'Send to Top': '最上部へ送る',
 'Sensitivity': '感度',
 'Set -> Layer <- Pass Index For Multiple selected strokes': '複数の選択ストロークに対してレイヤーパスインデックスを設定します。',
 'Set -> Material <- Pass Index For Multiple selected strokes': '複数の選択ストロークに対してマテリアルパスインデックスを設定します。',
 'Set Active Collection': 'アクティブコレクションを設定',
 'Set Active Project': 'アクティブプロジェクトを設定',
 'Set Custom Property': 'カスタムプロパティ設定',
 'Set Material Pass Index?': 'マテリアルパスインデックスを設定しますか？',
 'Set Shape Key': 'シェイプキー設定',
 'Set opacity for all layers Of the selected strokes': '選択ストロークがあるすべてのレイヤーの不透明度を設定します。',
 'Set the active collection': 'アクティブコレクションを設定します。',
 'Settings': '設定',
 'Settings are not available.': '設定を取得できません。',
 'Shape Key Payload': 'シェイプキーペイロード',
 'Shared Material Name': '共有マテリアル名',
 'Show Archived Projects': 'アーカイブ済みプロジェクトを表示',
 'Show archived projects inside the __ARCHIVE__ folder in the Project dropdown. Archived projects typically have a timestamp suffix. Enable this when you need to reopen an old job.': 'プロジェクトのドロップダウンに __ARCHIVE__ フォルダ内のアーカイブ済みプロジェクトを表示します。アーカイブ済みプロジェクトには通常、日時サフィックスが付きます。過去案件を開き直す必要がある場合に有効にしてください。',
 'Show only selectors marked as Favorites (star). Click the star icon at the left of each selector row to add or remove it from Favorites. Favorites are stored per project and persist across sessions.': 'お気に入り（星）に登録されたセレクターだけを表示します。各セレクター行の左にある星アイコンで登録/解除できます。お気に入りはプロジェクトごとに保存され、セッションをまたいで保持されます。',
 'Smart Selector': 'スマートセレクター',
 'Specials': '特殊操作',
 'State Sync Interval (s)': '状態同期間隔（秒）',
 'Strength': '強さ',
 'Strip': '削除',
 'Stroke-> Layer': 'ストローク → レイヤー',
 'Suffix': '接尾辞',
 'Switch to Layer': 'レイヤーへ切替',
 "Switch to the selected stroke's layer (Hotkey This, and Lasso for best results) ": '選択ストロークのレイヤーへ切り替えます。投げ縄選択 と一緒にホットキー化すると使いやすくなります。',
 'Sync Layer Name': 'レイヤー名を同期',
 'Text': 'テキスト',
 'Text to add as a prefix or suffix': '接頭辞または接尾辞として追加する文字列です。',
 'Thickness': '太さ',
 'This integrated package is disabled on the current platform.': 'このパッケージは現在の環境では無効です。',
 'This package is intentionally disabled because a duplicate or superseded version was skipped.': '重複または上位互換により無効化されています。',
 'This tool is disabled in Always-on Toggles. Turn it back on there to make it available inside Smart Selector.': 'このツールはスマートセレクターの設定で無効です。スマートセレクター内で使うには、設定パネルで有効に戻してください。',
 'Toggle All Masks': '全マスク切替',
 'Toggle Favorite': 'お気に入り切替',
 'Toggle Phantom Mode': 'ファントムモード切替',
 'Toggle Time Visibility': '時間表示を切替',
 'Toggle Viewport Visibility of Time Drivers for Selected Strokes or Bones': '選択ストロークまたはボーンに関連する時間オフセットのドライバー のビューポート表示を切り替えます。',
 'Toggles between the current state and all collections disabled': '現在の状態と全コレクション無効状態を切り替えます。',
 'Toggles between the current state and all enabled': '現在の状態と全有効状態を切り替えます。',
 'Toggles between the current state and all enabled (non-QCD collections disabled)': '現在の状態と全有効状態（QCD 以外のコレクションは無効）を切り替えます。',
 'Toggles between the current state and all non-QCD collections disabled': '現在の状態と QCD 以外の全コレクション無効状態を切り替えます。',
 'Toggles mask visablity of all layers ': 'すべてのレイヤーのマスク表示を切り替えます。',
 'Tool Command': 'ツールコマンド',
 'Tool Groups': 'ツールグループ',
 'Tool Inner Color': 'ツール内側色',
 'Tool Inner Override': 'ツール内側色上書き',
 'Tool Inner Selection Color': 'ツール選択内側色',
 'Tool Inner Selection Override': 'ツール選択内側色上書き',
 'Tool Outline Color': 'ツール輪郭色',
 'Tool Outline Override': 'ツール輪郭色上書き',
 'Tool Selection Text Color': 'ツール選択文字色',
 'Tool Selection Text Override': 'ツール選択文字色上書き',
 'Tool Text Color': 'ツール文字色',
 'Tool Text Override': 'ツール文字色上書き',
 'Tooltip Inner Color': 'ツールチップ内側色',
 'Tooltip Inner Override': 'ツールチップ内側色上書き',
 'Tooltip Outline Color': 'ツールチップ輪郭色',
 'Tooltip Outline Override': 'ツールチップ輪郭色上書き',
 'Tooltip Text Color': 'ツールチップ文字色',
 'Tooltip Text Override': 'ツールチップ文字色上書き',
 'UI Separator Button': 'UI区切りボタン',
 'Undo': '元に戻す',
 'Undo previous action': '前の操作を元に戻します。',
 'Unlock All': 'すべてロック解除',
 'Unlocks all GP layers/materials and Makes all objects selectable': 'すべての GP レイヤー/マテリアルのロックを解除し、すべてのオブジェクトを選択可能にします。',
 'Unmask Selected': '選択項目のマスク解除',
 'Update Time Drivers based on Selected Strokes OR Selected Rig Bones': '選択ストロークまたは選択リグボーンを基準に時間オフセットのドライバー を更新します。',
 'Use Single Material for All': '全てに単一マテリアルを使用',
 'Value': '値',
 'Value for the Time Offset Driver Generator (x^1)': '時間オフセットドライバージェネレーターで使う感度値です。',
 'Value to apply to selected stroke layers': '選択したストロークレイヤーへ適用する値です。',
 'View QCD Slot': 'QCD スロットを表示',
 'View objects in QCD slot': 'QCD スロット内のオブジェクトを表示します。',
 'View3D not found, cannot run operator': '3Dビューが見つからないため、オペレーターを実行できません。',
 'Visibility & Opacity': '表示と不透明度',
 'Weight Assigned': 'ウェイトを割り当てました。',
 'Weight Selected': '選択項目にウェイト',
 '[DV Global] Disable in Viewports': '[DV 全体] ビューポートで無効化',
 '[DV] Disable in Viewports': '[DV] ビューポートで無効化',
 '[EC Global] Exclude from View Layer': '[EC 全体] ビューレイヤーから除外',
 '[EC] Exclude from View Layer': '[EC] ビューレイヤーから除外',
 '[HH Global] Holdout': '[HH 全体] ホールドアウト',
 '[HH] Holdout': '[HH] ホールドアウト',
 '[IO Global] Indirect Only': '[IO 全体] 間接のみ',
 '[IO] Indirect Only': '[IO] 間接のみ',
 '[RR Global] Disable in Renders': '[RR 全体] レンダーで無効化',
 '[RR] Disable in Renders': '[RR] レンダーで無効化',
 '[SS Global] Disable Selection': '[SS 全体] 選択を無効化',
 '[SS] Disable Selection': '[SS] 選択を無効化',
 '[VV Global] Hide in Viewport': '[VV 全体] ビューポートで非表示',
 '[VV] Hide in Viewport': '[VV] ビューポートで非表示',
 'layer is hidden, cannot apply mask': 'レイヤーが非表示のため、マスクを適用できません。',
 '• Only layers that are NOT hidden or locked will be checked.': '• 非表示またはロックされていないレイヤーのみ確認します。',
 '• This includes checking nested groups.': '• ネストされたグループも確認対象です。'}
_SSSUITE_TRANSLATION_CONTEXTS = ('*', 'Operator', 'Property', 'Tooltip', 'UI', 'Panel', 'Menu', 'Addon')
for _sssuite_msgid, _sssuite_ja in _SSSUITE_EXTRA_JA_TRANSLATIONS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
# Duplicate existing wildcard entries into common Blender UI contexts so labels,
# property names, tooltips, menu entries, and panels all resolve consistently.
for (_sssuite_ctx, _sssuite_msgid), _sssuite_ja in list(blender_translations.get('ja_JP', {}).items()):
    if _sssuite_ctx == '*':
        for _sssuite_ctx2 in _SSSUITE_TRANSLATION_CONTEXTS:
            blender_translations.setdefault('ja_JP', {}).setdefault((_sssuite_ctx2, _sssuite_msgid), _sssuite_ja)

_SSSUITE_REPORT_EXACT_JA = {k: v for k, v in _SSSUITE_EXTRA_JA_TRANSLATIONS.items()}
_SSSUITE_REPORT_REGEX_JA = [('^(\\d+)/(\\d+) Cumulative Objects Selected$', '累積オブジェクトを \\1/\\2 個選択しました。'),
 ('^Removed (\\d+) collections$', '\\1 個のコレクションを削除しました。'),
 ('^Renamed (\\d+) layers\\.$', '\\1 個のレイヤー名を変更しました。'),
 ("^Renamed (\\d+) layers to '(.+)'\\.$", '\\1 個のレイヤー名を「\\2」に変更しました。'),
 ('^Added suffix to (\\d+) layers\\.$', '\\1 個のレイヤーへ接尾辞を追加しました。'),
 ('^Cleaned (\\d+) layer names\\.$', '\\1 個のレイヤー名を整理しました。'),
 ('^Modified (\\d+) layer names\\.$', '\\1 個のレイヤー名を変更しました。'),
 ('^Selected: (.+)$', '選択: \\1'),
 ('^Selected suffix: (.+)$', '選択した接尾辞: \\1'),
 ('^Selected infix: (.+)$', '選択した中間文字: \\1'),
 ('^Duplicated (\\d+) layers$', '\\1 個のレイヤーを複製しました。'),
 ('^Deleted (\\d+) layers$', '\\1 個のレイヤーを削除しました。'),
 ("^Applied '(.+)' as mask to (\\d+) layers$", '「\\1」を \\2 個のレイヤーにマスクとして適用しました。'),
 ('^Added (\\d+) new mask layers to (.+)$', '\\2 に \\1 個の新規マスクレイヤーを追加しました。'),
 ('^Unmasked (\\d+) layers$', '\\1 個のレイヤーのマスクを解除しました。'),
 ('^All masks turned (.+)$', 'すべてのマスクを \\1 にしました。'),
 ('^Assigned (\\d+) points to (.+)$', '\\1 個のポイントを \\2 に割り当てました。'),
 ('^Set layers Pass Index to (.+?) ?$', 'レイヤーのパスインデックスを \\1 に設定しました。'),
 ('^Set Material Pass Index to (.+)$', 'マテリアルのパスインデックスを \\1 に設定しました。'),
 ('^Removed (\\d+) empty layer\\(s\\)$', '\\1 個の空レイヤーを削除しました。'),
 ('^Updated sensitivity for (\\d+) drivers\\.$', '\\1 個のドライバーの感度を更新しました。'),
 ('^Toggled (.+): (.+)$', '\\1 を切り替えました: \\2'),
 ('^Created rig for: (.+)$', 'リグを作成しました: \\1'),
 ('^Removed: (.+)$', '削除しました: \\1')]


def _sssuite_is_japanese_locale() -> bool:
    try:
        import bpy  # type: ignore
        try:
            language = str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or '').strip()
            if language and language.upper() != 'DEFAULT':
                return language.lower().startswith('ja')
        except Exception:
            pass
        try:
            locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').strip().lower()
            return locale.startswith('ja')
        except Exception:
            return False
    except Exception:
        return False


def translate_runtime_message(message):
    text = str(message or '')
    if not _sssuite_is_japanese_locale():
        return text
    exact = _SSSUITE_REPORT_EXACT_JA.get(text)
    if exact is not None:
        return exact
    try:
        import re
        for pattern, repl in _SSSUITE_REPORT_REGEX_JA:
            if re.match(pattern, text):
                return re.sub(pattern, repl, text)
    except Exception:
        pass
    return text


def report_runtime_message(operator, report_types, message) -> None:
    try:
        operator.report(report_types, translate_runtime_message(message))
    except Exception:
        try:
            operator.report(report_types, str(message or ''))
        except Exception:
            pass
# --- full UI i18n extension v5 END ---

# --- supplemental runtime report i18n v5b START ---
_SSSUITE_SUPPLEMENTAL_JA_TRANSLATIONS = {'Error removing 1 or more objects from the Scene Collection.\nObjects would be left without a collection.': 'シーンコレクションから 1 個以上のオブジェクトを削除できませんでした。\nコレクションに属さないオブジェクトが発生します。', 'Cannot create new collection.\nNo collection is selected and collections are filtered.': '新しいコレクションを作成できません。\nコレクションが選択されておらず、コレクションがフィルターされています。', "Cannot create new collection.\nThe selected collection isn't visible.": '新しいコレクションを作成できません。\n選択中のコレクションが表示されていません。', 'No selected objects': '選択中のオブジェクトがありません。', 'Collection already isolated': 'コレクションは既に分離表示されています。', 'Tools are loaded automatically while this toolset add-on is enabled. Runtime switching controls have been removed.': 'このツールセットアドオンが有効な間、ツールは自動で読み込まれます。ランタイムの切替操作は廃止されています。'}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_SUPPLEMENTAL_JA_TRANSLATIONS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
_SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_SUPPLEMENTAL_JA_TRANSLATIONS)
# --- supplemental runtime report i18n v5b END ---

# --- supplemental feature-toggle i18n v5c START ---
_SSSUITE_FEATURE_TOGGLE_JA_TRANSLATIONS = {
    'Toggle Feature': '機能を切り替え',
    'Switch an always-on feature on or off. The save timing follows N-panel State Save.': '常時発動機能の有効・無効を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
    'Toggle an always-on Smart Selector feature. The save timing follows N-panel State Save.': 'スマートセレクターの常時発動機能を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
    'Click to switch this feature between enabled and disabled.': 'クリックすると、この機能の有効・無効を切り替えます。',
    'The selected feature could not be changed.': '選択した機能を変更できませんでした。',
    'Feature setting saved.': '機能設定を保存しました。',
    'Enabled': '有効',
    'Disabled': '無効',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_FEATURE_TOGGLE_JA_TRANSLATIONS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
_SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_FEATURE_TOGGLE_JA_TRANSLATIONS)
# --- supplemental feature-toggle i18n v5c END ---


# --- full locale UI coverage v7 START ---
_SSSUITE_FULL_I18N_V7_TRANSLATIONS = {
    'Collection Manager': 'コレクションマネージャー',
    'GP Select': 'GP セレクト',
    'GP Select Controls': 'GP セレクトの操作',
    'Gp Select': 'GP セレクト',
    'Integrated Add-on': '統合アドオン',
    'Integrated Add-on Info': '統合アドオン情報',
    'N-panel Menu': 'Nパネルメニュー',
    'N-panel List': 'Nパネルリスト',
    'N-panel Pie Menu': 'Nパネルパイメニュー',
    'Open this menu from the Smart Selector N-panel.': 'スマートセレクターの N パネルからこのメニューを開きます。',
    'Open operator choices from the Smart Selector N-panel.': 'スマートセレクターの N パネルからオペレーター候補を開きます。',
    'Open this pie menu from the Smart Selector N-panel.': 'スマートセレクターの N パネルからこのパイメニューを開きます。',
    'Show the Smart Selector settings in the N-panel.': 'スマートセレクターの Nパネル設定を N パネルに表示します。',
    'Current Name': '現在の名前',
    'New Name': '新しい名前',
    'Layer': 'レイヤー',
    'Duplicating': '複製対象',
    'Segoe UI (Default)': 'Segoe UI（標準）',
    'MS Gothic': 'MS ゴシック',
    'MS Mincho': 'MS 明朝',
    'Meiryo': 'メイリオ',
    'Yu Gothic': '游ゴシック',
    'Function': '機能',
    'How to use': '使い方',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_FULL_I18N_V7_TRANSLATIONS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
_SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_FULL_I18N_V7_TRANSLATIONS)
# --- full locale UI coverage v7 END ---


# Always-on toggle UI additions.
_SSSUITE_ALWAYS_ON_TOGGLE_JA_TRANSLATIONS = {
    'Always-on Toggles': '常時機能切り替え',
    'Toggle Always-on Feature': '常時起動機能を切り替え',
    'Switch an always-on Smart Selector feature on or off.': 'スマートセレクターの常時起動機能を有効・無効に切り替えます。',
    'Enable or disable Smart Selector background modules, handlers, timers, watchers, menu hooks, header widgets, and hotkeys from one place.': 'スマートセレクターのバックグラウンドモジュール、ハンドラー、タイマー、監視、メニュー追加、ヘッダーウィジェット、ホットキーを一か所で有効・無効に切り替えます。',
    'Use top toggle group': '最上部の切り替えを使用',
    'Availability is controlled from the Always-on Toggles group at the top of the Smart Selector N-panel.': '利用状態はスマートセレクターの Nパネル最上部の「常時機能切り替え」グループで制御します。',
    'Runtime toggles are shown in the Smart Selector N-panel.': '実行時の切り替え項目はスマートセレクターの Nパネルに表示されます。',
    'Runtime toggles are shown in the Always-on Toggles group at the top of the Smart Selector N-panel.': '実行時の切り替え項目は、スマートセレクターの Nパネル最上部の「常時機能切り替え」グループに表示されます。',
    'Browser server is disabled in Always-on Toggles.': 'ブラウザーサーバーは「常時機能切り替え」で無効になっています。',
    'Always-on Toggles could not be drawn.': '常時機能切り替えを描画できませんでした。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_ALWAYS_ON_TOGGLE_JA_TRANSLATIONS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
_SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_ALWAYS_ON_TOGGLE_JA_TRANSLATIONS)
# Always-on toggle UI additions END


# --- Smart Selector v13 startup-lazy / persistent N-panel text additions ---
_SUITE_V13_I18N = {
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Toggle Always-on Feature'): '常時起動機能を切り替え',
    ('*', 'Switch an always-on Smart Selector feature on or off. The save timing follows N-panel State Save.'): 'スマートセレクターの常時起動機能の有効・無効を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
    ('*', 'Load Tool UI'): 'ツールUIを読み込む',
    ('*', 'Load GP Select UI'): 'GP セレクトUIを読み込む',
    ('*', 'Load GP Select only when needed and keep startup light while still showing the tool entry in the Smart Selector N-panel.'): 'スマートセレクターの Nパネルにツール項目を表示したまま、必要な時だけGP セレクトを読み込み、起動を軽くします。',
    ('*', 'Active Smart Selector project folder name. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): '現在使用するスマートセレクターのプロジェクトフォルダー名です。設定は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    ('*', 'Show only selectors marked as Favorites. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): 'お気に入りに登録したセレクターだけを表示します。設定は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    ('*', 'Function: opens or closes the Always-on Toggles group at the top of the Smart Selector N-panel. How to use: click the triangle in the group header. The open/closed state is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): '機能: スマートセレクターの Nパネル最上部の常時機能切り替えグループを開閉します。使い方: グループヘッダーの三角アイコンをクリックします。開閉状態は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    ('*', "Function: stores the JSON payload used by the internal Execute Script bridge operator. How to use: paste a JSON object such as {\"script\":\"print('Hello')\"} and press Execute Script below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes."): "機能: 内部のスクリプト実行ブリッジオペレーターで使うJSONペイロードを保存します。使い方: {\"script\":\"print('Hello')\"} のようなJSONオブジェクトを貼り付け、下の「スクリプトを実行」を押します。このテキストは「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。",
    ('*', 'Function: stores the JSON payload used by the internal Shape Key bridge operator. How to use: paste a JSON object such as {"obj":"Character","key":"Smile","value":1.0} and press Set Shape Key below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): '機能: 内部のシェイプキーブリッジオペレーターで使うJSONペイロードを保存します。使い方: {"obj":"Character","key":"Smile","value":1.0} のようなJSONオブジェクトを貼り付け、下の「シェイプキーを設定」を押します。このテキストは「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    ('*', 'Function: stores the JSON payload used by the internal Custom Property bridge operator. How to use: paste a JSON object such as {"obj":"Cube","path":"location[0]","value":1.0} and press Set Custom Property below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): '機能: 内部のカスタムプロパティブリッジオペレーターで使うJSONペイロードを保存します。使い方: {"obj":"Cube","path":"location[0]","value":1.0} のようなJSONオブジェクトを貼り付け、下の「カスタムプロパティを設定」を押します。このテキストは「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    ('*', 'Function: stores the JSON payload used by the internal selection bridge operator. How to use: paste a JSON object such as {"target_type":"object","objects":["Cube"]} and press Apply Selection below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.'): '機能: 内部の選択ブリッジオペレーターで使うJSONペイロードを保存します。使い方: {"target_type":"object","objects":["Cube"]} のようなJSONオブジェクトを貼り付け、下の「選択を適用」を押します。このテキストは「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
}
try:
    blender_translations.setdefault('ja_JP', {}).update(_SUITE_V13_I18N)
except Exception:
    pass


# --- Smart Selector v13 additional tooltip coverage ---
_SUITE_V13_EXTRA_I18N = {
    ('*', 'Open and use Collection Manager from a standard 3D View Sidebar N-panel without altering Blender theme opacity or sidebar transparency.'): 'Blenderテーマの不透明度やサイドバー透明度を変更せず、通常の3DビューNパネルからコレクションマネージャーを開いて使用します。',
    ('*', 'Collection Manager Commands'): 'コマンド一覧',
    ('*', 'Lists Collection Manager commands as ordinary N-panel buttons. Click a button to run the corresponding command or open a menu.'): 'コレクションマネージャーのコマンドを通常のNパネルボタンとして一覧表示します。ボタンを押すと、対応するコマンドを実行するかメニューを開きます。',
}
try:
    blender_translations.setdefault('ja_JP', {}).update(_SUITE_V13_EXTRA_I18N)
except Exception:
    pass
# --- Smart Selector v13 additional tooltip coverage END ---


# --- Smart Selector v13 collection-manager persistent filter tooltip coverage ---
_SUITE_V13_CM_FILTER_I18N = {
    ('*', 'Filter collections by name. This N-panel value is saved according to N-panel State Save and restored after Blender restarts or scene changes.'): '名前でコレクションを絞り込みます。このNパネル値は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も復元されます。',
    ('*', 'Invert filtering (show hidden items, and vice versa). This N-panel value is saved according to N-panel State Save and restored after Blender restarts or scene changes.'): '絞り込み結果を反転します。非表示になる項目を表示し、表示される項目を非表示にします。このNパネル値は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も復元されます。',
    ('*', 'Filter collections to only show the ones that contain the selected objects. This N-panel value is saved according to N-panel State Save and restored after Blender restarts or scene changes.'): '選択中オブジェクトを含むコレクションだけを表示するように絞り込みます。このNパネル値は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も復元されます。',
    ('*', 'Filter collections to only show the ones that are QCD slots. This N-panel value is saved according to N-panel State Save and restored after Blender restarts or scene changes.'): 'QCD スロットになっているコレクションだけを表示するように絞り込みます。このNパネル値は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も復元されます。',
}
try:
    blender_translations.setdefault('ja_JP', {}).update(_SUITE_V13_CM_FILTER_I18N)
except Exception:
    pass
# --- Smart Selector v13 collection-manager persistent filter tooltip coverage END ---

# --- Smart Selector v13 exact multiline Collection Manager tooltip coverage ---
_SUITE_V13_CM_MULTILINE_TOOLTIPS = {
    '* Ctrl+LMB - Expand/Collapse all sublevels\n  * Shift+LMB - Isolate tree/Restore\n  * Alt+LMB - Discard history': '* Ctrl+左クリック - すべての下位階層を展開 / 折りたたみ\n  * Shift+左クリック - ツリーを分離 / 復元\n  * Alt+左クリック - 履歴を破棄',
    '* LMB - Select all objects in collection.\n  * Shift+LMB - Add/Remove collection objects from selection.\n  * Ctrl+LMB - Isolate nested selection.\n  * Ctrl+Shift+LMB - Add/Remove nested from selection': '* 左クリック - コレクション内のすべてのオブジェクトを選択\n  * Shift+左クリック - コレクション内オブジェクトを選択へ追加 / 選択から解除\n  * Ctrl+左クリック - ネストした選択を分離\n  * Ctrl+Shift+左クリック - ネスト対象を選択へ追加 / 選択から解除',
    '* LMB - Move objects to collection.\n  * Shift+LMB - Add/Remove objects from collection': '* 左クリック - オブジェクトをコレクションへ移動\n  * Shift+左クリック - オブジェクトをコレクションへ追加 / コレクションから解除',
    '* Shift+LMB - Isolate/Restore.\n  * Shift+Ctrl+LMB - Isolate nested/Restore.\n  * Ctrl+LMB - Toggle nested.\n  * Alt+LMB - Discard history': '* Shift+左クリック - 分離 / 復元\n  * Shift+Ctrl+左クリック - ネストを分離 / 復元\n  * Ctrl+左クリック - ネストを切り替え\n  * Alt+左クリック - 履歴を破棄',
    '* LMB - Enable all/Restore.\n  * Shift+LMB - Invert.\n  * Shift+Ctrl+LMB - Isolate collections w/ selected objects.\n  * Shift+Alt+LMB - Disable collections w/ selected objects.\n  * Ctrl+LMB - Copy/Paste RTOs.\n  * Ctrl+Alt+LMB - Swap RTOs.\n  * Alt+LMB - Discard history': '* 左クリック - すべて有効 / 復元\n  * Shift+左クリック - 反転\n  * Shift+Ctrl+左クリック - 選択オブジェクトを含むコレクションを分離\n  * Shift+Alt+左クリック - 選択オブジェクトを含むコレクションを無効化\n  * Ctrl+左クリック - RTO をコピー / 貼り付け\n  * Ctrl+Alt+左クリック - RTO を入れ替え\n  * Alt+左クリック - 履歴を破棄',
}
for _sssuite_msgid, _sssuite_ja in _SUITE_V13_CM_MULTILINE_TOOLTIPS.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SUITE_V13_CM_MULTILINE_TOOLTIPS)
except Exception:
    pass
# --- Smart Selector v13 exact multiline Collection Manager tooltip coverage END ---


# --- Smart Selector v14 stable always-on checkbox i18n START ---
_SUITE_V14_ALWAYS_ON_STABLE_CHECKBOX_I18N = {
    'Collection Manager': 'コレクションマネージャー',
    'Function: allows the Collection Manager tool UI and commands to be loaded on demand from the Smart Selector N-panel. How to use: keep this enabled if you want Collection Manager available. Disabling it unloads its panels, operators, handlers, menus, header widgets, and hotkeys so the tool stays completely inactive.': '機能: スマートセレクターのNパネルから、必要な時だけコレクションマネージャーのUIとコマンドを読み込めるようにします。使い方: コレクションマネージャーを使う場合は有効にしてください。無効にすると、関連パネル、オペレーター、ハンドラー、メニュー、ヘッダーウィジェット、ホットキーを解除し、完全に停止します。',
    'GP Select': 'GP セレクト',
    'Function: allows the GP Select tool UI and commands to be loaded on demand from the Smart Selector N-panel. How to use: keep this enabled if you want Grease Pencil selection, renaming, pass-index, material, and rigging helpers available. Disabling it unloads its panels and operators so it stays completely inactive.': '機能: スマートセレクターのNパネルから、必要な時だけGP セレクトのUIとコマンドを読み込めるようにします。使い方: Grease Pencil の選択、リネーム、パスインデックス、マテリアル、リギング補助を使う場合は有効にしてください。無効にすると、関連パネルとオペレーターを解除し、完全に停止します。',
    'Collection cleanup handlers': 'コレクションの後片付け',
    'Function: enables Collection Manager handlers that automatically clear temporary move-selection state after dependency-graph updates, Undo, Redo, and file loading. How to use: enable this only when you need automatic Collection Manager cleanup in the background. The save timing follows N-panel State Save, and the setting remains after Blender restarts and scene changes.': '機能: 依存グラフ更新、元に戻す、やり直し、ファイル読込後に、コレクションマネージャーの一時的な移動選択状態を自動整理するハンドラーを有効化します。使い方: バックグラウンドで自動クリーンアップが必要な場合だけ有効にしてください。設定は「Nパネル状態保存」に従って保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    'Collection menu entries': 'コレクションメニューの項目',
    'Function: adds Collection Manager and QCD Move Widget commands to Blender’s Object Collection menu. How to use: enable this when you want those commands available from the 3D View object menu in addition to the N-panel. Disabling it removes the menu callbacks.': '機能: Blender のオブジェクトのコレクションメニューへ、コレクションマネージャーとQCD 移動ウィジェットの項目を追加します。使い方: Nパネルだけでなく3Dビューのオブジェクトメニューからも実行したい場合に有効にしてください。無効にするとメニュー追加コールバックを解除します。',
    'Popup hotkey': 'ポップアップのホットキー',
    'Function: enables the Object Mode shortcut that opens the Collection Manager popup. How to use: enable this only when you want the popup shortcut active in the background. Disabling it removes the add-on keymap item.': '機能: コレクションマネージャーのポップアップを開くオブジェクトモード用ショートカットを有効化します。使い方: バックグラウンドでポップアップ用ショートカットを使いたい場合だけ有効にしてください。無効にするとアドオンキーマップ項目を解除します。',
    'Disable Objects override': 'オブジェクト無効化の置き換え',
    'Function: adds Disable Selected Objects, Disable Unselected Objects, and Restore Disabled Objects to the Object Show/Hide menu and enables the H, Shift+H, and Alt+H shortcuts for that workflow. How to use: enable this only when object disabling should replace the usual hide workflow. Disabling it removes the menu entry and hotkeys.': '機能: 「選択物を無効化」「非選択物を無効化」「無効化した物を戻す」 をオブジェクトの表示/非表示メニューに追加し、H、Shift+H、Alt+H のショートカットを有効化します。使い方: 通常の非表示操作ではなくオブジェクト無効化を中心に使う場合だけ有効にしてください。無効にするとメニュー項目とホットキーを解除します。',
    'QCD system': 'QCD システム',
    'Function: enables the Quick Content Display system, including QCD operators, the popup move widget shortcut, QCD save/load handlers, and optional QCD subfeatures. How to use: enable this when QCD slots must be active in the background. Disabling it unregisters QCD, its handlers, its hotkeys, and its header widget.': '機能: QCD オペレーター、ポップアップ移動ウィジェットショートカット、QCD 保存/読込ハンドラー、任意の QCD サブ機能を含む QCD システムを有効化します。使い方: QCD スロットをバックグラウンドで常時使う場合に有効にしてください。無効にすると QCD、関連ハンドラー、ホットキー、ヘッダーウィジェットを解除します。',
    'QCD hotkeys (non-edit)': 'QCD ホットキー（編集以外）',
    'Function: enables number-key QCD slot shortcuts in Object Mode, Pose Mode, and Weight Paint. How to use: enable this when you want numeric QCD slot switching outside Edit Mode. This requires the QCD system to be enabled.': '機能: オブジェクトモード・ポーズモード・ウェイトペイントで数値キーによる QCD スロットショートカットを有効化します。使い方: 編集モード以外で数値キーによる QCD スロット切り替えを使う場合に有効にしてください。この項目は QCD システムが有効な場合に機能します。',
    'QCD edit-mode hotkeys': 'QCD 編集モード用ホットキー',
    'Function: enables number-key QCD slot shortcuts in Mesh, Curve, Armature, Metaball, Lattice, and Grease Pencil Stroke Edit Mode. How to use: enable this when you want QCD slot switching while editing geometry. This requires the QCD system to be enabled.': '機能: メッシュ・カーブ・アーマチュア・メタボール・ラティス・Grease Pencil ストロークの編集モードで数値キーによる QCD スロットショートカットを有効化します。使い方: ジオメトリ編集中も QCD スロット切り替えを使う場合に有効にしてください。この項目は QCD システムが有効な場合に機能します。',
    'QCD 3D View header widget': 'QCD ヘッダーウィジェット',
    'Function: draws the QCD slot widget in the 3D View header and updates it when the active View Layer changes. How to use: enable this only when QCD buttons should appear in the 3D View header. Disabling it removes the header draw callbacks.': '機能: 3Dビューのヘッダーに QCD スロットウィジェットを表示し、アクティブビューレイヤーの変更に合わせて更新します。使い方: 3Dビューのヘッダーに QCD ボタンを表示したい場合だけ有効にしてください。無効にするとヘッダー描画コールバックを解除します。',
    'GP weight cleanup handlers': 'GP ウェイトの後片付け',
    'Function: allows GP Select’s Weight Selected workflow to install temporary cleanup handlers that restore layer, material, armature, and object selectability after leaving Weight Paint or using Undo and Redo. How to use: keep this enabled for normal Weight Selected behavior. Disabling it removes existing cleanup handlers and prevents new ones from being installed.': '機能: GP セレクトの 「選択へウェイト」 ワークフローで、ウェイトペイント終了後や 元に戻す・やり直し 後にレイヤー、マテリアル、アーマチュア、オブジェクトの選択可否を戻す一時クリーンアップハンドラーを許可します。使い方: 通常の 「選択へウェイト」 動作では有効にしてください。無効にすると既存ハンドラーを解除し、新規追加も防ぎます。',
    'Browser server': 'ブラウザーサーバー',
    'Function: allows Smart Selector to start the local browser bridge server used by selector edit and play windows. How to use: keep this enabled to open selectors in the browser. Disabling it immediately stops the server and prevents new browser selector windows from starting.': '機能: セレクターの編集ウィンドウと再生ウィンドウで使うローカルブラウザーブリッジサーバーの起動を許可します。使い方: ブラウザーでセレクターを開く場合は有効にしてください。無効にするとサーバーを即停止し、新しいブラウザーセレクターウィンドウの起動も止めます。',
    'Browser data watchers': 'ブラウザーデータ監視',
    'Function: enables the message-bus subscription and dependency-graph handler that mark object and collection lists dirty for the browser bridge. How to use: keep this enabled for responsive selector lists while the browser bridge is running. Disabling it removes the watchers.': '機能: ブラウザーブリッジ用のオブジェクト一覧とコレクション一覧を更新対象としてマークするメッセージバス購読と依存グラフハンドラーを有効化します。使い方: ブラウザーブリッジ起動中にセレクター一覧を追従させたい場合は有効にしてください。無効にすると監視を解除します。',
    'Browser state-sync timer': 'ブラウザー状態同期タイマー',
    'Function: enables the repeating timer that syncs Blender selection, active object, object lists, collection lists, and watched Shape Key values to the browser bridge. How to use: keep this enabled for live browser feedback while the browser bridge is running. Disabling it unregisters the timer.': '機能: Blender の選択状態、アクティブオブジェクト、オブジェクト一覧、コレクション一覧、監視中のシェイプキー値をブラウザーブリッジへ同期する反復タイマーを有効化します。使い方: ブラウザー側のライブ反映が必要な場合は有効にしてください。無効にするとタイマーを解除します。',
    'Browser task-queue timer': 'ブラウザータスクキュータイマー',
    'Function: enables the repeating timer that executes selection, script, Shape Key, custom-property, timeline, camera, Undo, Redo, and remote-procedure tasks sent from the browser on Blender’s main thread. How to use: keep this enabled when browser buttons and sliders should control Blender. Disabling it stops browser-to-Blender task execution.': '機能: ブラウザーから送られた選択、スクリプト、シェイプキー、カスタムプロパティ、タイムライン、カメラ、元に戻す、やり直し、リモート処理タスクを Blender のメインスレッドで実行する反復タイマーを有効化します。使い方: ブラウザーのボタンやスライダーで Blender を操作する場合は有効にしてください。無効にするとブラウザーから Blender へのタスク実行を止めます。',
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggle State': '常時機能切り替え状態',
    'Toggle this always-on Smart Selector feature. The setting is saved immediately.': 'スマートセレクターの常時起動機能を切り替えます。保存タイミングは「Nパネル状態保存」に従います。',
}
for _sssuite_msgid, _sssuite_ja in _SUITE_V14_ALWAYS_ON_STABLE_CHECKBOX_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SUITE_V14_ALWAYS_ON_STABLE_CHECKBOX_I18N)
except Exception:
    pass
# --- Smart Selector v14 stable always-on checkbox i18n END ---


# --- Smart Selector v15 single Smart Selector panel i18n START ---
_SUITE_V15_SINGLE_PANEL_I18N = {
    'Launch and manage every Smart Selector function from one standard 3D View Sidebar N-panel. Project tools, selector data, integrated tools, settings, and bridge actions are grouped inside this single panel.': '通常の3DビューNパネル内にある1つのスマートセレクターのパネルから、スマートセレクターの全機能を起動・管理します。プロジェクト、セレクター一覧、統合ツール、設定、ブリッジ操作は、この単一パネル内にグループ化されています。',
    'Integrated tools are initializing.': '統合ツールを初期化中です。',
    'Integrated tools are not available.': '統合ツールを取得できません。',
    'Scene is not available.': 'シーンを取得できません。',
    'Tool section draw failed': 'ツールセクション描画に失敗しました',
    'GP Select UI draw failed': 'GP セレクトUI描画に失敗しました',
    'Draw failed': '描画に失敗しました',
    'Collection Manager Commands': 'コマンド一覧',
}
for _sssuite_msgid, _sssuite_ja in _SUITE_V15_SINGLE_PANEL_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SUITE_V15_SINGLE_PANEL_I18N)
except Exception:
    pass
# --- Smart Selector v15 single Smart Selector panel i18n END ---

# --- Smart Selector v16 click-loaded help popup i18n START ---
_SUITE_V16_HELP_POPUP_I18N = {
    'Help': 'ヘルプ',
    'Smart Selector Help': 'スマートセレクター ヘルプ',
    'Help Topic': 'ヘルプ項目',
    'Open detailed help for this Smart Selector group.': 'このスマートセレクターのグループの詳細ヘルプを開きます。',
    'Help draw failed': 'ヘルプ描画に失敗しました',
}
for _sssuite_msgid, _sssuite_ja in _SUITE_V16_HELP_POPUP_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SUITE_V16_HELP_POPUP_I18N)
except Exception:
    pass
# --- Smart Selector v16 click-loaded help popup i18n END ---

# --- Smart Selector v23 generated i18n START ---
_SSSUITE_V23_GENERATED_I18N = {
    'Function: stores Smart Selector Always On Toggle State runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Feature Key parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores Collection manager List Collection runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the Collection manager List Index value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: controls the Collection Manager Exclude from View Layer column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「ビューレイヤーから除外」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Disable Selection column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「選択を無効化」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Hide in Viewport column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「ビューポートで非表示」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Disable in Viewports column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「ビューポートで無効化」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Disable in Renders column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「レンダーで無効化」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Holdout column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「ホールドアウト」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: controls the Collection Manager Indirect Only column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': 'コレクションマネージャーの「間接のみ」の列を出すかどうかを切り替えます。変更内容は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: stores the In Phantom Mode value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores Update Header runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the UI Separator value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the QCD Slots Blend Data value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores Collection Manager runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Name parameter used by the CMListCollection command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores the Last Name value used by CMListCollection. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the QCD Slot Idx value used by CMListCollection. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Message parameter used by the CMSendReport command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores Is Master Collection runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Collection Name parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Expand parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Index parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores Is Master Collection runtime data used by CMSelectCollectionObjectsOperator. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Collection Name parameter used by the CMSelectCollectionObjectsOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores Is Master Collection runtime data used by CMSendObjectsToCollectionOperator. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Collection Name parameter used by the CMSendObjectsToCollectionOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMExcludeOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMRestrictSelectOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMHideOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMDisableViewportOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMDisableRenderOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMHoldoutOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Name parameter used by the CMIndirectOnlyOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Collection Name parameter used by the CMRemoveCollectionOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Without Objects parameter used by the CMRemoveEmptyCollectionsOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Child parameter used by the CMNewCollectionOperator command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Toggle parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Toggle parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Slot parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: identifies the master scene collection row in Collection Manager. How to use: this label is managed automatically and marks the top of the collection tree.': '機能: コレクションマネージャー内のマスターシーンコレクション行を識別します。使い方: このラベルは自動管理され、コレクションツリーの最上位を示します。',
    'Function: stores the Grease Pencil layer rename find str text. How to use: enter text in the GP Select rename panel, then run the matching find-and-replace command.': '機能: Grease Pencil のレイヤー名を変える時に検索する文字を保存します。使い方: GP セレクトのリネーム欄へ文字を入力し、対応する検索・置換のボタンを押します。',
    'Function: stores the Grease Pencil layer rename replace str text. How to use: enter text in the GP Select rename panel, then run the matching find-and-replace command.': '機能: Grease Pencil のレイヤー名を変える時に置き換える文字を保存します。使い方: GP セレクトのリネーム欄へ文字を入力し、対応する検索・置換のボタンを押します。',
    'Function: supplies the Field Name parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: stores the new Grease Pencil layer group name. How to use: enter a clear group name before grouping the selected stroke layers.': '機能: 新しい Grease Pencil レイヤーグループ名を保存します。使い方: 選択中のストロークレイヤーをグループ化する前に、わかりやすいグループ名を入力します。',
    'Function: stores candidate material name 1 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.': '機能: 複製とマテリアル割り当て用の候補マテリアル名 1 を保存します。使い方: コピーしたストローク内容を新しいマテリアルへ割り当てる時に、使用するマテリアル名を指定します。',
    'Function: stores candidate material name 2 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.': '機能: 複製とマテリアル割り当て用の候補マテリアル名 2 を保存します。使い方: コピーしたストローク内容を新しいマテリアルへ割り当てる時に、使用するマテリアル名を指定します。',
    'Function: stores candidate material name 3 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.': '機能: 複製とマテリアル割り当て用の候補マテリアル名 3 を保存します。使い方: コピーしたストローク内容を新しいマテリアルへ割り当てる時に、使用するマテリアル名を指定します。',
    'Function: stores candidate material name 4 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.': '機能: 複製とマテリアル割り当て用の候補マテリアル名 4 を保存します。使い方: コピーしたストローク内容を新しいマテリアルへ割り当てる時に、使用するマテリアル名を指定します。',
    'Function: stores candidate material name 5 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.': '機能: 複製とマテリアル割り当て用の候補マテリアル名 5 を保存します。使い方: コピーしたストローク内容を新しいマテリアルへ割り当てる時に、使用するマテリアル名を指定します。',
    'Function: stores the Found Stroke Count value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores Layer Names runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores Mat Names runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the Target Pass Index value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores the New Mod Name value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores GP Renamer Props runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Manage scene collections, visibility restrictions, selection restrictions, holdout, indirect-only flags, and QCD slot workflows from one integrated package.': 'シーン内コレクションの管理、表示制限、選択制限、ホールドアウト、間接のみ、QCD スロット運用を1つの統合パッケージから扱います。',
    'Enable this tool from the Smart Selector N-panel Always-on Toggles, then use the quick buttons or migrated child panels. QCD remains active automatically while this suite is enabled.': 'スマートセレクターの Nパネルの「常時機能切り替え」でこのツールを有効化してから、クイックボタンまたは移植済み子パネルを使用します。QCD はこのツールセットが有効な間、自動的に有効になります。',
    'Provides Grease Pencil selection, layer management, renaming, masking, material utilities, pass-index workflows, and rigging helpers inside the integrated Smart Selector environment.': '統合されたスマートセレクターの環境内で、Grease Pencil の選択、レイヤー管理、リネーム、マスク、マテリアル補助、パスインデックス運用、リギング補助を提供します。',
    'Enable this tool from the Smart Selector N-panel Always-on Toggles, then expand the migrated GP Select panels. Use the renamed sections in order: selection and cleanup first, then layer utilities, then rigging tools when needed.': 'スマートセレクターの Nパネルの「常時機能切り替え」でこのツールを有効化してから、移植済みのGP セレクトパネルを展開します。基本的には、選択と整理、レイヤー補助、必要時のリギングツールの順に使用します。',
    'Function: supplies the Topic ID parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Filename parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Mode parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Filename parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Mode parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: chooses the root folder for Smart Selector project folders. How to use: leave this blank to store all automatically generated project data inside CONFIG/Smart_Selector_Suite. Enter a directory only when you intentionally want manual external project storage; existing projects are not moved automatically. If the active project is not in the new location, the first project there becomes active.': '機能: スマートセレクターのプロジェクトフォルダーのルート保存先を選びます。使い方: 空欄のままなら、CONFIG/Smart_Selector_Suite 内に、すべての自動生成プロジェクトデータを保存します。外部保存を明示的に使う場合だけディレクトリを入力してください。既存プロジェクトは自動移動されません。今のプロジェクトが新しい場所に無い時は、その場所の先頭のプロジェクトに切り替わります。',
    'Function: controls how often Blender selection, active object, object lists, collection lists, and watched Shape Key values are synchronized to the browser bridge. How to use: lower values update faster; raise this to reduce overhead in heavy scenes. Typical values are 0.5 to 1.0 seconds. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: Blender の選択、アクティブオブジェクト、オブジェクト一覧、コレクション一覧、監視中のシェイプキー値をブラウザー連携へ同期する間隔を制御します。使い方: 値を小さくすると更新が速くなります。重いシーンでは値を大きくして負荷を下げてください。目安は0.5〜1.0秒です。この設定は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: sets how many .bak backup generations are kept beside saved selector JSON and image files. How to use: set 0 to disable backups, or increase the value when you need more restore points. Higher values use more disk space. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: セレクターJSONと画像ファイルの保存時に、隣接するバックアップとして保持する .bak 世代数を設定します。使い方: 0でバックアップ無効、復元ポイントを多く残したい場合は値を増やします。値を増やすとディスク容量を多く使います。この設定は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: allows selector buttons to execute Python scripts sent from the browser. How to use: keep this off when opening shared or untrusted selector files, and turn it on only when you need script buttons to control Blender. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: ブラウザーから送られる Python スクリプトをセレクターボタンで実行できるようにします。使い方: 共有ファイルや信頼できないセレクターを開く場合はOFFにし、スクリプトボタンで Blender を制御する必要がある場合だけONにしてください。この設定は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: includes project folders stored in the __ARCHIVE__ folder in the Project list. How to use: enable this when you need to reopen an archived job; disable it to keep the Project list focused on active projects. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: __ARCHIVE__ フォルダー内のプロジェクトをプロジェクト一覧に含めます。使い方: アーカイブ済み作業を再度開く必要がある場合にONにし、通常はOFFにして作業中プロジェクトだけを表示します。この設定は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Favorite Selectors': 'お気に入りセレクター',
    'Function: stores the internal per-project favorite selector map used by the star buttons and Favorites Only filter. How to use: edit this only for recovery or migration; normal favorite changes are made with the star buttons. This value is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: 星ボタンと「お気に入りのみ」フィルターで使う、プロジェクト別のお気に入りセレクター情報を保存します。使い方: 通常のお気に入り変更は星ボタンで行います。手動編集は復旧または移行時だけにしてください。この値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: stores the N-panel integration flag for Collection Manager compatibility. How to use: use the Always-on Toggles group to control actual availability; this saved value remains for migration compatibility and does not create any separate settings UI.': '機能: コレクションマネージャー互換用のNパネル統合フラグを保存します。使い方: 実際の有効/無効は「常時機能切り替え」で制御してください。この保存値は移行互換用で、別個の設定UIは作成しません。',
    'Function: stores the N-panel integration flag for GP Select compatibility. How to use: use the Always-on Toggles group to control actual availability; this saved value remains for migration compatibility and does not create any separate settings UI.': '機能: GP セレクト互換用のNパネル統合フラグを保存します。使い方: 実際の有効/無効は「常時機能切り替え」で制御してください。この保存値は移行互換用で、別個の設定UIは作成しません。',
    'Function: stores the open or closed state of the integrated tool information group in the Smart Selector N-panel. How to use: this is maintained automatically by the N-panel UI and saved according to N-panel State Save.': '機能: スマートセレクターの Nパネル内の統合ツール情報グループの開閉状態を保存します。使い方: NパネルUIが自動的に管理し、保存タイミングは「Nパネル状態保存」に従います。',
    'Function: opens or closes the Collection Manager information section inside Smart Selector settings. How to use: click the row triangle to show what the integrated tool does and where to control it. This state is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: スマートセレクターの Nパネル設定内のコレクションマネージャー情報セクションを開閉します。使い方: 行の三角ボタンをクリックし、統合ツールの内容と制御場所を確認します。この状態は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: opens or closes the GP Select information section inside Smart Selector settings. How to use: click the row triangle to show what the integrated tool does and where to control it. This state is saved according to N-panel State Save and remains after Blender restarts or scene changes.': '機能: スマートセレクターの Nパネル設定内のGP セレクト情報セクションを開閉します。使い方: 行の三角ボタンをクリックし、統合ツールの内容と制御場所を確認します。この状態は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も維持されます。',
    'Function: stores Smart Selector Bridge Payloads runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: stores Smart Selector Npanel Settings runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.': 'アドオンが内部で使うデータです。自動で管理されます。',
    'Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Target Label parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Target Kind parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Target ID parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Target Label parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Target Desc parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
    'Function: supplies the Is Pie Menu parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.': '操作の内部で使う値です。ボタンが自動で設定します。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_V23_GENERATED_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_V23_GENERATED_I18N)
except Exception:
    pass
# --- Smart Selector v23 generated i18n END ---

# --- Smart Selector v24 operator tooltip i18n START ---
_SSSUITE_V24_OPERATOR_TOOLTIP_I18N = {
    'Function: runs the Send Report command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'メッセージを報告として表示します。',
    'Function: runs the UI Separator Button command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': '一覧の区切りです。',
    'Function: Set the active collection. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '指定したコレクションをアクティブコレクションに設定します。選択や移動操作の基準にしたいコレクションを切り替える時に使います。',
    'Function: Expand/Collapse all collections. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'コレクションツリー全体を展開または折りたたみます。階層が多いシーンで一覧を素早く整理するための操作です。',
    'Function: Select all objects that are present in more than one collection. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '複数のコレクションに所属しているオブジェクトをすべて選択します。重複所属の確認や整理に使います。',
    'Function: Remove Collection. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択したコレクションを削除します。中のオブジェクトや所属状態を確認してから実行してください。',
    'Function: Apply changes and quit Phantom Mode. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'ファントムモード中の変更を適用して終了します。保存された RTO 状態へ戻す必要がないことを確認してから実行してください。',
    'Function: Disable selected objects in viewports. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択中のオブジェクトをビューポートで無効化します。非表示ではなく無効化したい場合に使います。',
    'Function: Disable unselected objects in viewports. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '未選択のオブジェクトをビューポートで無効化します。選択中の対象だけを作業しやすくする時に使います。',
    'Function: Restore disabled objects in viewports. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'ビューポートで無効化されているオブジェクトを復元します。無効化状態を戻したい場合に使います。',
    'Function: runs the Undo command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': '直前の操作を元に戻します。',
    'Function: runs the Redo command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': '元に戻した操作をやり直します。',
    'Function: Move objects to QCD Slots. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択オブジェクトを QCD スロットへ移動します。スロットを指定してコレクション整理を素早く行うための操作です。',
    'Function: Toggles between the current state and all enabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '現在の状態と、すべての QCD スロットを有効にした状態を切り替えます。',
    'Function: Toggles between the current state and all enabled (non-QCD collections disabled). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '現在の状態と、QCD スロットを有効化し QCD 以外のコレクションを無効にした状態を切り替えます。',
    'Function: Isolate collections (via EC) that contain the selected objects. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択オブジェクトを含むコレクションを EC 経由で分離します。対象コレクションだけを確認したい場合に使います。',
    'Function: Disable all collections that contain the selected objects. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択オブジェクトを含むすべてのコレクションを無効化します。選択対象に関連するコレクションを一括で隠したい時に使います。',
    'Function: Toggles between the current state and all non-QCD collections disabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '現在の状態と、QCD 以外のすべてのコレクションを無効にした状態を切り替えます。',
    'Function: Toggles between the current state and all collections disabled. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '現在の状態と、すべてのコレクションを無効にした状態を切り替えます。',
    'Function: Select all objects in QCD slots. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'QCD スロット内のすべてのオブジェクトを選択します。スロット対象をまとめて選択したい時に使います。',
    'Function: Discard QCD History. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'QCD の履歴を破棄します。復元履歴を使わず現在状態を基準にしたい場合に実行します。',
    'Function: Move object(s) to QCD slot. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択中の 1 個以上のオブジェクトを指定 QCD スロットへ移動します。',
    'Function: View objects in QCD slot. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '指定 QCD スロット内のオブジェクトを表示します。スロット内容を確認したい場合に使います。',
    'Function: Manage and control collections, with advanced features, in a popup UI. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'ポップアップ UI でコレクションを管理・制御します。表示制限、選択制限、QCD などの高度な機能をまとめて扱えます。',
    'Function: Add Prefix to layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるレイヤーへ接頭辞を追加します。レイヤー名を分類しやすくするための操作です。',
    'Function: Replace full name of layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるレイヤーの名前全体を置き換えます。',
    'Function: Add suffix to layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるレイヤーへ接尾辞を追加します。レイヤー名の末尾で分類したい時に使います。',
    'Function: Remove Digits and Punctuation from layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるレイヤー名から数字と記号を削除します。名前を整理したい場合に使います。',
    'Function: Find and replace text in layers of selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるレイヤー名の文字列を検索して置換します。複数レイヤー名をまとめて修正できます。',
    'Function: Clear a specific text field. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '指定したテキスト入力欄をクリアします。検索語やリネーム文字列を消したい時に使います。',
    'Function: Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択中のストロークと同じ接頭辞を持つ全レイヤーのストロークを選択します。マルチフレームの設定に従います。代表のストロークを 1 つ選べば実行できます。',
    'Function: Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択中ストロークと同じ接尾辞を持つ全レイヤーのストロークを選択します。記号を含む名前にも対応し、マルチフレーム設定を尊重します。代表となるストロークを 1 つ選べば実行できます。',
    'Function: Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択中のストロークと同じ中間の文字列を持つ全レイヤーのストロークを選択します。マルチフレームの設定に従います。代表のストロークを 1 つ選べば実行できます。',
    'Function: Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when switching modes. Respects the Multiframe setting, and Auto lock ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーとマテリアルをロックし、アーマチュアを選択して他オブジェクトを選択不可にしたうえでウェイトペイントモードへ入ります。切替式で、モード変更時に解除されます。マルチフレーム設定と自動ロックを尊重します。',
    'Function: Duplicate layers of selected strokes and hide the originals. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーを複製し、元のレイヤーを非表示にします。元データを残して別案を作りたい時に使います。',
    "Function: Rename stroke's layer based off the selected vertex group (Use inside WP mode For Assign Weight by Name). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '選択中の頂点グループに基づいてストロークのレイヤー名を変更します。ウェイトペイントモード内で「名前でウェイト割り当て」と組み合わせて使います。',
    'Function: Assign weight to selected stroke Layers from Vertex Groups of the same name (For Premade rigs with already set names. Or use Sync layer names in WP mode). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '同名の頂点グループから、選択ストロークのレイヤーへウェイトを割り当てます。既に名前が設定されたリグ向けです。必要に応じてウェイトペイントモードでレイヤー名同期を使ってください。',
    'Function: Create Layers from Vertex Group names ( For premade rigs, Then you can draw on the layers that have the correct names). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '頂点グループ名からレイヤーを作成します。既存リグ向けで、正しい名前のレイヤー上に描画できるようになります。',
    "Function: Switch to the selected stroke's layer (Hotkey This, and Lasso for best results). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '選択ストロークのレイヤーへ切り替えます。投げ縄選択と一緒にショートカットへ割り当てると使いやすくなります。',
    "Function: Move the selected stroke's layers Above the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '選択ストロークのレイヤーをアクティブレイヤーの上へ移動します。',
    "Function: Move the selected stroke's layers Bellow the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '選択ストロークのレイヤーをアクティブレイヤーの下へ移動します。',
    'Function: Move the active Group above the selected stroke layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'アクティブグループを選択ストロークのレイヤーより上へ移動します。',
    'Function: Move the active Group Bellow the selected stroke layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'アクティブグループを選択ストロークのレイヤーより下へ移動します。',
    'Function: Move layers of the selected strokes to the top. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーを最上部へ移動します。',
    'Function: Move layers of the selected strokes to the bottom. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーを最下部へ移動します。',
    'Function: Hide layer of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーを非表示にします。',
    "Function: Lock materials of unselected stroke's (Toggleable). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '未選択ストロークのマテリアルをロックします。もう一度実行すると切り替えできます。',
    'Function: Delete layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーを削除します。実行前に対象を確認してください。',
    'Function: Clear all vertex weight from the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークからすべての頂点ウェイトをクリアします。',
    'Function: Set opacity for all layers Of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークがあるすべてのレイヤーの不透明度を設定します。',
    'Function: Reset all layers to 100% opacity. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'すべてのレイヤーの不透明度を 100% に戻します。',
    'Function: Mask selected strokes layers to the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーをアクティブレイヤーでマスクします。',
    'Function: Mask the active layer to the selected strokes layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'アクティブレイヤーを選択ストロークのレイヤーへマスクします。',
    'Function: Remove all masks from layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーのマスクをすべて外します。',
    'Function: Invert masks on layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤー上のマスクを反転します。',
    'Function: Toggles mask visablity of all layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'すべてのレイヤーのマスクの表示を切り替えます。',
    'Function: Adds all layers of the selected strokes to a new group. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのすべてのレイヤーを新しいグループへ追加します。',
    'Function: Lock the layers of selected strokes (Toggleable). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーをロックします。もう一度実行すると切り替えできます。',
    "Function: Duplicate Stroke's material and assign the new one(s) to the strokes.. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": 'ストロークのマテリアルを複製し、新しいマテリアルをストロークへ割り当てます。',
    'Function: Assign weight to selected strokes using the selected bone/v-group. Works on Mutiple frames with Multiframe on ( Use with Weight selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ボーンまたは頂点グループを使って選択ストロークへウェイトを割り当てます。マルチフレームを有効にすると複数フレームで動作します。「選択へウェイト」と組み合わせて使います。',
    'Function: Set -> Layer <- Pass Index For Multiple selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '複数の選択ストロークに対して、レイヤーのパスインデックスを設定します。',
    'Function: Set -> Material <- Pass Index For Multiple selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '複数の選択ストロークに対して、マテリアルのパスインデックスを設定します。',
    'Function: Reset layers and materials Pass Index to 0 for the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークのレイヤーとマテリアルのパスインデックスを 0 に戻します。',
    'Function: Unlocks all GP layers/materials and Makes all objects selectable. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'すべての GP レイヤー / マテリアルのロックを解除し、すべてのオブジェクトを選択可能にします。',
    'Function: Delete empty Grease Pencil layers (Skips Hidden, Locked, or Hidden Groups). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '空の Grease Pencil レイヤーを削除します。非表示、ロック中、または非表示グループ内のレイヤーは除外されます。',
    'Function: Update Time Drivers based on Selected Strokes OR Selected Rig Bones. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークまたは選択リグボーンに基づいて時間オフセットのドライバーを更新します。',
    'Function: Toggle Viewport Visibility of Time Drivers for Selected Strokes or Bones. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': '選択ストロークまたはボーンに関連する時間オフセットのドライバーのビューポート表示を切り替えます。',
    "Function: Create a Time Offset Controller for every selected stroke layer ( Will make a new armature if you don't have one parented ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.": '選択ストロークの各レイヤーに時間オフセットコントローラーを作成します。親アーマチュアが無い場合は新しいアーマチュアを作成します。',
    'Function: Create a Time Offset rig/modifier to control multiple layers with Pass Index ( For the Selected strokes. Will make a rig if gp is not parented ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'パスインデックスで複数レイヤーを制御する時間オフセットリグ / モディファイアを作成します。選択ストローク用で、GP に親が無い場合はリグを作成します。',
    'Function: Reset layers, remove the GP modifiers, and delete control bones (Select the control bone for this). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.': 'レイヤーをリセットし、GP モディファイアを削除し、制御ボーンを削除します。この操作では制御ボーンを選択してください。',
    'Function: runs the Lasso Edit command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': '編集モードにして投げ縄選択の道具へ切り替えます。',
    'Function: runs the Draw Brush command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'ドローモードにして描画ブラシへ切り替えます。',
    'Function: runs the Pull command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'スカルプトモードにして引っ張りのブラシへ切り替えます。',
    'Function: runs the Pinch command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'スカルプトモードにしてつまむブラシへ切り替えます。',
    'Function: runs the Strength command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'スカルプトモードにして強さのブラシへ切り替えます。',
    'Function: runs the Thickness command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.': 'スカルプトモードにして厚みのブラシへ切り替えます。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_V24_OPERATOR_TOOLTIP_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_V24_OPERATOR_TOOLTIP_I18N)
except Exception:
    pass
# --- Smart Selector v24 operator tooltip i18n END ---

# --- Smart Selector full audit tooltip i18n START ---
_SSSUITE_FULL_AUDIT_TOOLTIP_I18N = {
    'Function: stores the active Smart Selector project folder name. How to use: choose another project from the Smart Selector N-panel project list; the selected project is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: スマートセレクターのアクティブプロジェクトフォルダー名を保存します。使い方: スマートセレクターの Nパネルのプロジェクト一覧から別プロジェクトを選択します。選択したプロジェクトは「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: filters the Selector Data List to show only selector files marked as favorites in the active project. How to use: enable this from the Smart Selector N-panel when you want to focus on favorite selectors; the filter state is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: セレクターデータ一覧を、現在のプロジェクトでお気に入り登録されたセレクターファイルだけに絞り込みます。使い方: お気に入りだけを表示したい時にスマートセレクターの Nパネルで有効化します。このフィルター状態は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: supplies the project folder name that will become active in Smart Selector. How to use: the project picker fills this automatically when you choose a project; manual editing is normally unnecessary. The chosen project is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: スマートセレクターでアクティブにするプロジェクトフォルダー名を渡します。使い方: プロジェクト選択時に自動入力されるため、通常は手動編集不要です。選択したプロジェクトは「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: sets the folder name for a new Smart Selector project. How to use: enter a safe project name, then confirm the dialog; the folder is created inside the current project root, which defaults to CONFIG/Smart_Selector_Suite unless a manual root directory is set.': '機能: 新しいスマートセレクターのプロジェクトのフォルダー名を設定します。使い方: 安全なプロジェクト名を入力してダイアログを確定します。手動ルートディレクトリを指定していない場合、フォルダーは CONFIG/Smart_Selector_Suite 内に作成されます。',
    'Function: sets the destination folder name when renaming the active Smart Selector project. How to use: enter the new name and confirm; selector JSON files and images stay inside the renamed folder. Existing projects are not overwritten.': '機能: アクティブなスマートセレクターのプロジェクトをリネームする時の変更先フォルダー名を設定します。使い方: 新しい名前を入力して確定します。セレクターJSONと画像はリネーム後のフォルダー内に保持され、既存プロジェクトは上書きされません。',
    'Function: sets the folder name created by Duplicate Project. How to use: enter the copy name and confirm; all selector JSON files and images from the active project are copied into the new folder without changing the original project.': '機能: プロジェクト複製で作成するフォルダー名を設定します。使い方: コピー名を入力して確定します。アクティブプロジェクト内のセレクターJSONと画像が新しいフォルダーへコピーされ、元のプロジェクトは変更されません。',
    'Function: aligns local Collection Manager option buttons in a right-side column. How to use: toggle this in the Collection Manager N-panel or popup when you want local row controls visually separated; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: コレクションマネージャーのローカル操作ボタンを右側の列に揃えます。使い方: 行ごとの操作を視覚的に分けたい場合、コレクションマネージャーのNパネルまたはポップアップで切り替えます。選択状態は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: filters Collection Manager rows by collection name. How to use: type part of a collection name in the filter field to narrow the visible collection list; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: コレクション名でコレクションマネージャーの行を絞り込みます。使い方: フィルター欄にコレクション名の一部を入力すると、表示されるコレクション一覧を絞り込めます。入力値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: inverts the current Collection Manager filter result. How to use: enable this after entering a filter when you want to show the collections that would normally be hidden; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 現在のコレクションマネージャーフィルター結果を反転します。使い方: フィルター入力後、通常は非表示になるコレクションを表示したい場合に有効化します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: filters the Collection Manager list to collections that contain the currently selected objects. How to use: select objects in the scene, then enable this filter to focus on their collections; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 現在選択中のオブジェクトを含むコレクションだけに、コレクションマネージャー一覧を絞り込みます。使い方: シーン内でオブジェクトを選択してからこのフィルターを有効化し、そのオブジェクトが所属するコレクションに集中します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: filters the Collection Manager list to collections assigned to QCD slots. How to use: enable this when you want to work only with QCD-managed collections; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: QCD スロットに割り当てられたコレクションだけに、コレクションマネージャー一覧を絞り込みます。使い方: QCD管理下のコレクションだけを扱いたい場合に有効化します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: stores the text used as a prefix or suffix for selected Grease Pencil layer names. How to use: enter the affix text, then press Prefix or Suffix in the Renaming and Pass Index group; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 選択した Grease Pencil レイヤー名へ接頭辞または接尾辞として追加する文字列を保存します。使い方: 追加したい文字列を入力し、リネームとパスインデックスグループの接頭辞または接尾辞を押します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: stores the full replacement name for selected Grease Pencil layers. How to use: enter the new layer name, then press Rename in the Renaming and Pass Index group; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 選択した Grease Pencil レイヤー名を完全に置き換える名前を保存します。使い方: 新しいレイヤー名を入力し、リネームとパスインデックスグループの「リネーム」を押します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: stores the opacity value applied to layers that contain selected Grease Pencil strokes. How to use: set the slider value, then press the opacity apply button; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 選択した Grease Pencil ストロークを含むレイヤーへ適用する不透明度を保存します。使い方: スライダー値を設定し、不透明度の適用ボタンを押します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: stores the Pass Index value applied to selected Grease Pencil layers or materials. How to use: enter the numeric Pass value, then press the layer or material Pass Index button; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 選択した Grease Pencil レイヤーまたはマテリアルへ適用するパスインデックス値を保存します。使い方: 数値のパスの値を入力し、レイヤーまたはマテリアルのパスインデックスボタンを押します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: stores the Time Offset Driver Generator sensitivity value. How to use: adjust this before creating or updating GP Select rigging drivers; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.': '機能: 時間オフセットのドライバー生成 の感度値を保存します。使い方: GP セレクトのリギング用ドライバーを作成または更新する前に調整します。値は「Nパネル状態保存」に従って保存され、Blender再起動後やシーン変更後も復元されます。',
    'Function: controls whether all selected strokes share one duplicated material during Duplicate & Assign Material. How to use: enable this in the operator dialog when every selected stroke should receive the same new material; disable it when each source material should be duplicated separately.': '機能: 「複製してマテリアルを割り当て」の実行時に、選択ストロークすべてで1つの複製マテリアルを共有するかを制御します。使い方: すべての選択ストロークへ同じ新規マテリアルを割り当てたい場合は、オペレーターダイアログで有効化します。元マテリアルごとに個別複製したい場合は無効化します。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_FULL_AUDIT_TOOLTIP_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_FULL_AUDIT_TOOLTIP_I18N)
except Exception:
    pass
# --- Smart Selector full audit tooltip i18n END ---

# --- Smart Selector full audit collection operator i18n START ---
_SSSUITE_FULL_AUDIT_COLLECTION_OPERATOR_I18N = {
    'Function: expands or collapses a Collection Manager tree branch. How to use: click a collection disclosure arrow to open or close that branch; Ctrl expands or collapses all sublevels, Shift isolates or restores that tree, and Alt clears expand history.': '機能: コレクションマネージャーのツリー分岐を展開または折りたたみます。使い方: コレクションの開閉矢印をクリックして分岐を開閉します。Ctrlで全サブレベルを展開/折りたたみ、Shiftでそのツリーを分離/復元し、Altで展開履歴を消去します。',
    'Function: selects objects contained in the target collection. How to use: click the collection selection button to select its objects; Shift adds or removes them from the current selection, Ctrl isolates nested collection selection, and Ctrl+Shift adds or removes nested objects.': '機能: 対象コレクションに含まれるオブジェクトを選択します。使い方: コレクションの選択ボタンをクリックしてオブジェクトを選択します。Shiftで現在の選択へ追加/削除し、Ctrlでネストしたコレクション選択を分離し、Ctrl+Shiftでネストしたオブジェクトを追加/削除します。',
    'Function: moves or links the current selected objects to the target collection. How to use: click a collection move button to move selected objects there; Shift adds objects to that collection or removes them when they are already linked.': '機能: 現在選択中のオブジェクトを対象コレクションへ移動またはリンクします。使い方: コレクションの移動ボタンをクリックして選択オブジェクトを移動します。Shiftでは、そのコレクションへ追加するか、既にリンク済みの場合は削除します。',
    'Function: toggles the Exclude from View Layer state for the target collection. How to use: click the [EC] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションのビューレイヤーから除外状態を切り替えます。使い方: [EC] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes Exclude from View Layer states for all collections. How to use: click the [EC] header button to enable all or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt disables collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションのビューレイヤーから除外状態を復元または変更します。使い方: [EC] ヘッダーボタンをクリックして全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションを無効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles whether the target collection is selectable in the viewport. How to use: click the [SS] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションをビューポートで選択可能にするかを切り替えます。使い方: [SS] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes selectable states for all collections. How to use: click the [SS] header button to enable all or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt disables collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションの選択可否状態を復元または変更します。使い方: [SS] ヘッダーボタンをクリックして全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションを無効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles viewport visibility for the target collection. How to use: click the [VV] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションのビューポート表示を切り替えます。使い方: [VV] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes viewport visibility states for all collections. How to use: click the [VV] header button to show all or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt hides collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションのビューポート表示状態を復元または変更します。使い方: [VV] ヘッダーボタンをクリックして全表示または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションを非表示、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles Disable in Viewports for the target collection. How to use: click the [DV] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションのビューポートで無効状態を切り替えます。使い方: [DV] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes Disable in Viewports states for all collections. How to use: click the [DV] header button to enable all or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt disables collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションのビューポートで無効状態を復元または変更します。使い方: [DV] ヘッダーボタンをクリックして全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションを無効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles render visibility for the target collection. How to use: click the [RR] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションのレンダー表示を切り替えます。使い方: [RR] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes render visibility states for all collections. How to use: click the [RR] header button to enable all for render or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt disables render for collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションのレンダー表示状態を復元または変更します。使い方: [RR] ヘッダーボタンをクリックしてレンダーを全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションのレンダーを無効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles the Holdout render state for the target collection. How to use: click the [HH] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションのホールドアウトレンダー状態を切り替えます。使い方: [HH] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes Holdout states for all collections. How to use: click the [HH] header button to enable all holdout or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt enables holdout for collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションのホールドアウト状態を復元または変更します。使い方: [HH] ヘッダーボタンをクリックしてホールドアウトを全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションのホールドアウトを有効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles the Indirect Only render state for the target collection. How to use: click the [IO] column button; Shift isolates or restores, Ctrl toggles nested collections, Shift+Ctrl isolates nested collections, and Alt clears history.': '機能: 対象コレクションの間接のみレンダー状態を切り替えます。使い方: [IO] 列ボタンをクリックします。Shiftで分離/復元、Ctrlでネストしたコレクションを切り替え、Shift+Ctrlでネストしたコレクションを分離し、Altで履歴を消去します。',
    'Function: restores or changes Indirect Only states for all collections. How to use: click the [IO] header button to enable all Indirect Only states or restore previous states; Shift inverts, Shift+Ctrl isolates collections with selected objects, Shift+Alt enables Indirect Only for collections with selected objects, Ctrl copies or pastes RTO values, Ctrl+Alt swaps RTO values, and Alt clears history.': '機能: 全コレクションの間接のみ状態を復元または変更します。使い方: [IO] ヘッダーボタンをクリックして間接のみを全有効化または前回状態を復元します。Shiftで反転、Shift+Ctrlで選択オブジェクトを含むコレクションを分離、Shift+Altで選択オブジェクトを含むコレクションの間接のみを有効化、CtrlでRTO値のコピー/貼り付け、Ctrl+AltでRTO値を入れ替え、Altで履歴を消去します。',
    'Function: toggles Collection Manager Phantom Mode. How to use: enable it before experimenting with collection restriction-toggle states; the add-on saves the current RTO state, allows temporary RTO edits, and restores the saved state when Phantom Mode is turned off. Editing collections externally can cancel the saved state.': '機能: コレクションマネージャーのファントムモードを切り替えます。使い方: コレクションの制限トグル状態を試す前に有効化します。アドオンは現在のRTO状態を保存し、一時的なRTO編集を許可し、ファントムモードをオフにした時に保存状態へ戻します。外部でコレクションを編集すると保存状態が破棄される場合があります。',
    'Function: creates any missing QCD slot collections until all 20 QCD slots exist. How to use: run this when the scene needs a complete QCD slot set; existing slot assignments are kept and only missing slots are created.': '機能: 20個すべての QCD スロットが揃うまで、不足している QCD スロット用コレクションを作成します。使い方: シーンに完全な QCD スロット一式が必要な時に実行します。既存のスロット割り当ては保持され、不足分だけ作成されます。',
    'Function: renumbers QCD slot assignments. How to use: click to renumber from slot 1 in breadth-first order; Ctrl uses linear order, Alt resets assignments, and Shift constrains the operation to the current branch.': '機能: QCD スロット割り当ての番号を振り直します。使い方: クリックするとスロット1から幅優先順で番号を振り直します。Ctrlで線形順、Altで割り当てをリセット、Shiftで現在の分岐内に処理を制限します。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_FULL_AUDIT_COLLECTION_OPERATOR_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_FULL_AUDIT_COLLECTION_OPERATOR_I18N)
except Exception:
    pass
# --- Smart Selector full audit collection operator i18n END ---

# --- Smart Selector phantom mode repair i18n START ---
_SSSUITE_PHANTOM_MODE_REPAIR_I18N = {
    'Function: toggles Collection Manager Phantom Mode. How to use: turn it on before temporarily testing collection restriction-toggle states; the current Exclude, Selectable, Viewport, Render, Holdout, and Indirect Only states are saved. Turn it off to restore the saved state. Use Apply Phantom Mode if you want to keep the temporary changes. Avoid externally adding, removing, or renaming collections while Phantom Mode is active because that can invalidate the saved state.': '機能: コレクションマネージャーのファントムモードを切り替えます。使い方: コレクション制限トグルの状態を一時的に試す前にオンにします。現在の除外、選択可能、ビューポート、レンダー、ホールドアウト、間接のみの状態を保存します。オフにすると保存状態へ復元します。一時変更を保持したい場合は 「ファントムモードを適用」を使ってください。ファントムモード中に外部からコレクションの追加、削除、リネームを行うと保存状態が無効になる場合があります。',
    'Function: applies the current temporary Collection Manager Phantom Mode restriction-toggle state and exits Phantom Mode without restoring the previously saved state. How to use: click this after testing Exclude, Selectable, Viewport, Render, Holdout, or Indirect Only changes that you want to keep.': '機能: 現在の一時的なコレクションマネージャーのファントムモード制限トグル状態を適用し、以前の保存状態へ復元せずにファントムモードを終了します。使い方: 保持したい除外、選択可能、ビューポート、レンダー、ホールドアウト、間接のみの変更をテストした後にクリックします。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_PHANTOM_MODE_REPAIR_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_PHANTOM_MODE_REPAIR_I18N)
except Exception:
    pass
# --- Smart Selector phantom mode repair i18n END ---

# --- Smart Selector named selection sets i18n START ---
_SSSUITE_SELECTION_SET_I18N = {
    'Selection Sets': '選択セット',
    'Selection Set': '選択セット',
    'Selection Set Name': '選択セット名',
    'New Selection Set Name': '新規選択セット名',
    'Active Selection Set': 'アクティブ選択セット',
    'Create Selection Set': '選択セットを作成',
    'Apply Selection Set': '選択セットを適用',
    'Replace Selection Set Contents': '選択セット内容を置き換え',
    'Add Objects to Selection Set': '選択セットへオブジェクトを追加',
    'Remove Objects from Selection Set': '選択セットからオブジェクトを除外',
    'Rename Selection Set': '選択セット名を変更',
    'Delete Selection Set': '選択セットを削除',
    'Selection Mode': '選択モード',
    'Replace': '置換',
    'Add': '追加',
    'Subtract': '除外',
    'Toggle': '反転',
    'Create': '作成',
    'Select': '選択',
    'Update': '更新',
    'Object': 'オブジェクト',
    'Active Object': 'アクティブオブジェクト',
    'Object reference stored in this named selection set.': 'この名前付き選択セットに保存されるオブジェクト参照です。',
    'Name shown for this named object selection set.': 'この名前付きオブジェクト選択セットに表示する名前です。',
    'Object that was active when this selection set was last updated.': 'この選択セットを最後に更新した時にアクティブだったオブジェクトです。',
    'Named object selection sets stored in this scene.': 'このシーンに保存される名前付きオブジェクト選択セットです。',
    'Active row in the Smart Selector selection-set list.': 'スマートセレクターの選択セット一覧でアクティブな行です。',
    'Name used when creating the next selection set. This UI value follows N-panel State Save.': '次に作成する選択セットへ使う名前です。このUI値は「Nパネル状態保存」に従います。',
    'Selection Set Members': '選択セットメンバー',
    'Object references contained in this named selection set. Use the Add and Remove member buttons in the N-panel to edit this list.': 'この名前付き選択セットに含まれるオブジェクト参照です。Nパネルのメンバー追加・除外ボタンで一覧を編集します。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_SELECTION_SET_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_SELECTION_SET_I18N)
except Exception:
    pass
# --- Smart Selector named selection sets i18n END ---

# --- Smart Selector userfix 20260818 i18n START ---
# Operator/panel labels and tooltips that were confirmed to display in English
# under the Japanese locale because no catalog entry existed for them.
_SSSUITE_USERFIX_20260818_I18N = {
    'Open the detailed help popup for this tool group.': 'このツールグループの詳細ヘルプポップアップを開きます。',
    'Set an always-on feature to enabled or disabled. The save timing follows N-panel State Save.': '常時起動機能の有効/無効を設定します。保存タイミングは「Nパネル状態保存」に従います。',
    'Save current Smart Selector N-panel settings to Smart_Selector_Suite.json and request Blender to save user preferences.': '現在のスマートセレクターの Nパネル設定を Smart_Selector_Suite.json へ保存し、Blender にユーザープリファレンスの保存を要求します。',
    'Refresh Selector Data List': 'セレクターデータ一覧を更新',
    'Rescan the active Project folder and refresh the cached Selector data list. The N-panel itself never performs filesystem scans while drawing.': 'アクティブなプロジェクトフォルダーを再スキャンし、キャッシュされたセレクターデータ一覧を更新します。Nパネル自体は描画中にファイルシステムのスキャンを行いません。',
    'Launch and manage every Smart Selector function from one standard Sidebar N-panel. Named selection sets, project tools, selector data, integrated tools, settings, and bridge actions are grouped inside this single panel.': 'スマートセレクターのすべての機能を、標準のサイドバーNパネル1つから起動・管理します。名前付き選択セット、プロジェクトツール、セレクターデータ、統合ツール、設定、ブリッジ操作をこの単一パネル内にまとめています。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_USERFIX_20260818_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SUITE_EXTRA_JA_TEXTS.update(_SSSUITE_USERFIX_20260818_I18N)
except Exception:
    pass
try:
    _SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_USERFIX_20260818_I18N)
except Exception:
    pass
# --- Smart Selector userfix 20260818 i18n END ---


# --- face ARKit 1.10.46 i18n START ---
# English is the source text of ark_face.py (bl_label, bl_description, property and enum names); Japanese here.
_SSSUITE_ARK_FACE_1_10_46_I18N = {
    'Face ARKit': '顔 ARKit',
    'Light Display': '軽い表示',
    'Toggle only the viewport display of the non-last subdivision modifiers (Subdivision Surface, Multiresolution) on every mesh. Render settings, levels and order are never changed and are checked after the switch. The state to restore is kept in the file':
        '全メッシュで、スタックの最後でない細分化（サブディビジョンサーフェス・マルチレゾリューション）のビューポート表示だけを切り替えます。レンダーの設定・レベル・順番は変えず、切替の後に自分で確かめます。戻すための状態はファイルに残ります',
    'Light Display Switch': '切替',
    'How to switch the light display': '切り替え方',
    'Toggle Light Display': '切替',
    'Switch the light display on when off, off when on': 'オンならオフ、オフならオンにします',
    'Light Display On': 'オン',
    'Turn the light display on': '軽い表示にします',
    'Light Display Off': 'オフ',
    'Return to the original display': '元の表示へ戻します',
    'Run with Light Display Released': '軽い表示を解除して実行',
    'Release the light display, run the bake / cache / render operator, then put the light display back':
        '軽い表示を自動で解除してから焼き・キャッシュ・レンダーの操作を行い、終わったら軽い表示へ戻します',
    'Operation to Run Released': '操作',
    'Clean-up Operation': '操作',
    'Operator to run after releasing the light display': '解除してから行う操作',
    'Release and Bake All Caches': '解除して全キャッシュを焼く',
    'Release the light display, bake every physics cache (cloth and so on), then put it back':
        '軽い表示を解除してから、全部の物理キャッシュ（クロス等）を焼き、終わったら戻します',
    'Release and Viewport Render (Image)': '解除してビューポートレンダー（静止画）',
    'Release the light display, render a viewport still, then put it back':
        '軽い表示を解除してからビューポートの静止画を描き、終わったら戻します',
    'Release and Viewport Render (Animation)': '解除してビューポートレンダー（動画）',
    'Release the light display, write the viewport animation, then put it back':
        '軽い表示を解除してからビューポートの動画を書き出し、終わったら戻します',
    'Release and Bake SmartRig Jiggle': '解除して SmartRig の揺れを焼く',
    'Release the light display and open the SmartRig jiggle bake. When it continues in a dialog, the light display stays released (switch it on again afterwards)':
        '軽い表示を解除してから SmartRig の揺れの焼きを開きます。確認の画面などで続く時は、解除したままにします（終わったら「軽い表示」をもう一度押してください）',
    'Release and Bake SmartRig Parts': '解除して SmartRig の部位を焼く',
    'Release the light display and open the SmartRig part bake. When it continues, it stays released':
        '軽い表示を解除してから SmartRig の部位の焼きを開きます。続く時は解除したままにします',
    'Release and Bake SmartRig Cloth': '解除して SmartRig のクロスを焼く',
    'Release the light display and open the SmartRig cloth bake. When it continues, it stays released':
        '軽い表示を解除してから SmartRig のクロスの焼きを開きます。続く時は解除したままにします',
    'Bake Face for Hand Keys': '顔を手付け用に焼く',
    'Bake the result of the 52 sliders into keys on every frame of c_*, cc_nose_sneer and ark_hand_*, stop the ARK constraints and switch to hand-key mode. The light display is released and put back automatically. Progress shows on the mouse cursor; Esc cancels and restores from the backup':
        '52 本の結果を c_*・cc_nose_sneer・ark_hand_* の全コマのキーに焼き、ARK の拘束を止めて手付けモードにします。軽い表示は自動で解除して戻します。進み具合はマウスのカーソルに出ます。Esc で中断でき、中断した時は控えから元へ戻します',
    'Back to Capture State': '流し込み直しの状態に戻す',
    'Remove the keys in the baked range, enable the ARK constraints again and return to expression mode (the current action is copied to a backup first). Keys made before the bake are put back from the bake backup':
        '焼いたチャンネルの範囲内のキーを消し、ARK の拘束を戻し、表情モードへ戻します（今のアクションは先に控えへ写します）。焼く前に打ってあったキーは、焼いた時の控えから戻します',
    'Re-apply after ARP Update': 'ARP 更新の後に当て直す',
    'After ARP Update Armature, re-apply the constraints, drivers and bones of the ARKit face rig from the spec stored in the file. Running it again gives the same result. The SmartRig jaw / teeth / tongue clamp is never used':
        'ARP の Update Armature の後に、ARKit 顔リグの拘束・ドライバー・骨をファイル内の正本へ当て直します。何度実行しても同じ結果です。SmartRig の顎・歯・舌のクランプは使いません',
    'Dry Run Only': 'ずれを見るだけ',
    'Change nothing; only report how many things differ': '何も変えず、ずれている物の数だけを報告します',
    'Expressions to 0': '表情を 0',
    'Set the 52 cc_arkit_* values to 0. No keys are inserted':
        '52 本の cc_arkit_* の値を 0 にします。キーは打ちません',
    'Face to Default': '顔を既定へ',
    'Put location, rotation and scale of the ARK-driven c_* and cc_nose_sneer, and ark_hand_*, back to the defaults. This also resets the ark_* values that ARP Reset All does not':
        'ARK の当たる c_*・cc_nose_sneer の位置・回転・拡大と ark_hand_* を既定値へ戻します。ARP の Reset All が戻さない ark_* もここで戻ります',
    'Check State': '状態を確かめる',
    'Count the mode, the ARK constraints and how many are enabled, and the light display':
        'モード・ARK の拘束の数と有効な数・軽い表示を数えて報告します',
    'Paste Face Flipped': '左右反転して貼る',
    "Copy the current pose of the selected visible face bones (all face ARKit bones when no visible face bone is selected, also those in hidden bone collections) and paste it mirrored with Blender's Paste Flipped. The mouthPress helper values are swapped left and right too":
        '選んだ見えている顔の骨（見えている顔の骨を選んでいなければ、隠れたボーンコレクションの物も含めて顔 ARKit の骨すべて）の今の姿勢を写し、左右反転して貼ります。補助の値 mouthPress の左右も入れ替えます。',
    'Select Bone': '骨を選ぶ',
    'Select the cc_arkit_* bone of this expression (hold Shift to add to the selection). The rig goes to Pose Mode, and a hidden bone is made visible':
        'この表情の cc_arkit_* の骨を選びます（Shift を押しながらで足して選ぶ）。リグをポーズモードにし、骨が隠れていれば表示します',
    'ARKit Bone': '骨',
    'Name of the bone to select': '選ぶ骨の名前',
    'Extend Bone Selection': '足して選ぶ',
    'Add to the current selection': '今の選択に足します',
    'Clean-up after Baking': '手直しの補助',
    'Call an existing Blender operator to make the baked every-frame keys easier to fix': '焼いた後の全コマのキーを直しやすくするため、Blender の既存の操作を呼びます',
    'Operator to call': '呼ぶ操作',
    'Smooth (Gaussian)': 'なだらか（ガウス）',
    'Smooth (Butterworth)': 'なだらか（バターワース）',
    'Blend Keys to Neighbor': '隣へ寄せる',
    'Ease Keys': 'イーズ',
    'Blend Keys Offset': 'ずらして寄せる',
    'Decimate Keys': 'キーを間引く',
    'Relax Pose': 'ほぐす',
    'Push Pose': '強める',
    'Blend to Neighbor Pose': '隣のポーズへ寄せる',
    'Smooth the selected keys with a Gaussian filter': '選んだキーをガウスでなだらかにします',
    'Remove fine jitter of the selected keys by frequency': '選んだキーの細かい揺れを周波数で落とします',
    'Blend the selected keys toward the neighbouring keys': '選んだキーを前後のキーへ寄せます',
    'Align the selected keys on an ease curve between the neighbouring keys': '選んだキーを前後のキーの間でイーズの形に並べます',
    'Shift the selected block of keys to match the neighbouring keys': '選んだキーの塊を前後のキーへずらして合わせます',
    'Remove keys within the allowed error and report the difference to the original': '許す誤差の中でキーを間引き、元との差を報告します',
    'Relax the current-frame pose of the selected bones toward the neighbouring keys': '選んだ骨の今のフレームの姿勢を前後のキーの間へほぐします',
    'Push the current-frame pose of the selected bones away from the neighbouring keys': '選んだ骨の今のフレームの姿勢を前後のキーから押し出します',
    'Blend the current-frame pose of the selected bones toward the neighbouring keys': '選んだ骨の今のフレームの姿勢を前後のキーへ寄せます',
    'Approve Texts': 'Text の実行を許可',
    'Set by the confirmation dialog: run the rig Texts of this file this session': '確認の画面が付けます：このファイルのリグの Text を、この起動の間は実行します',
    'Smooth Face': '顔は滑らかに',
    'Keep the subdivision of the face pair (MIK_geo_faceA and JEL_nor_faceA) even in the light display. About 13 ms heavier per frame (design 10.4). Switching it while the light display is on re-applies at once':
        '軽い表示の時も、顔（MIK_geo_faceA と JEL_nor_faceA の組）の細分化だけ残します。1 フレームあたり約 13ms 重くなります。オンの間に切り替えると、すぐに当て直します',
    'Clean-up Strength': '強さ',
    'Factor passed to the clean-up operators (smooth, blend, relax and so on)': '「手直しの補助」のボタンが呼ぶ操作（なだらか・寄せる・ほぐす等）に渡す強さ',
    'Decimate Allowed Error': '許す誤差',
    'Error margin of key decimation. The difference to the original is reported afterwards': 'キーの間引きで許す誤差。間引いた後に元との差を報告します',
    'Also Reset SmartRig Limits': 'SmartRig の上限も戻す',
    'When re-applying, also put the 12 SmartRig jaw / teeth / tongue limits back to the values in the spec':
        '当て直しの時、SmartRig の顎・歯・舌の上限 12 本も 正本の値へ戻します',
    'Pad Left/Right': 'パッド 左右',
    'Pad Down/Up': 'パッド 上下',
    '2D pad: writes 2 to 4 paired cc_arkit_* values at once without new bones. Above 0 is the second side (right / up), below 0 the first side (left / down). Keys are inserted when Auto Keying is on':
        '2D パッド：骨を増やさず、対になる 2〜4 本の cc_arkit_* の値へ同時に書きます。0 より上は後ろ側（右・上）、下は前側（左・下）の表情。自動キーがオンならキーも打ちます',
    'Values of the Smart Selector "Face ARKit" UI (smooth face option, 2D pads, clean-up strength). Saved with the scene':
        'SmartSelector の「顔 ARKit」の UI の値（顔は滑らかに・2D パッド・手直しの強さ）。シーンと一緒に保存します',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_ARK_FACE_1_10_46_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SUITE_EXTRA_JA_TEXTS.update(_SSSUITE_ARK_FACE_1_10_46_I18N)
except Exception:
    pass
# --- face ARKit 1.10.46 i18n END ---

# --- face ARKit 1.10.47 i18n START ---
# 1.10.47 animator view (light display stage 2). English is the source text of ark_face.py; Japanese here.
_SSSUITE_ARK_FACE_1_10_47_I18N = {
    'Toggle the light display (viewport only). Stage 1: the non-last subdivision modifiers (Subdivision Surface, Multiresolution) on every mesh. Stage 2: also the last subdivision, the small props (hidden) and Solid shading. Render settings, levels and order are never changed and are checked after the switch. The state to restore is kept in the file':
        '軽い表示を切り替えます（ビューポートだけ）。段 1：全メッシュで、スタックの最後でない細分化（サブディビジョンサーフェス・マルチレゾリューション）。段 2：それに加えて最後の細分化・小物（隠す）・ソリッド表示。レンダーの設定・レベル・順番は変えず、切替の後に自分で確かめます。戻すための状態はファイルに残ります',
    'Light Display Stage': '軽い表示の段',
    'What the light display switches off. Switching it while the light display is on re-applies at once':
        '軽い表示で何を止めるか。オンの間に切り替えると、すぐに当て直します',
    'Stage 1 (Light)': '段 1（軽い表示）',
    'Viewport only: the subdivision modifiers that are not the last of their stack':
        'ビューポートだけ：スタックの最後でない細分化を止めます',
    'Stage 2 (Animator)': '段 2（作業用）',
    'Viewport only: stage 1, plus the last subdivision of each stack, plus hiding the small props, plus Solid shading. Clothes and props look faceted and the props are hidden: do not use it to check the final look':
        'ビューポートだけ：段 1 に加えて、各スタックの最後の細分化を止め、小物を隠し、表示をソリッドにします。服・小物が角ばって見え、小物が隠れます。最終の見た目の確認には使わないでください',
    'Hide Small Props': '小物を隠す',
    'Stage 2: hide the small props (necklaces, belt, piercings, hair metal parts and so on). Hidden objects are not evaluated, so a script reading their matrices gets stale values':
        '段 2：小物（ネックレス・ベルト・ピアス・髪の金具など）を隠します。隠れた物は評価されないので、その行列を読むスクリプトは古い値を読みます',
    'Small Prop Names': '小物の名前',
    'Comma-separated name fragments (case-sensitive) of the small props hidden in stage 2. An object property ark_light_prop = 1 / 0 always includes / excludes that object':
        '段 2 で隠す小物の名前の一部（カンマ区切り、大文字と小文字を区別）。オブジェクトのプロパティ ark_light_prop が 1 なら必ず含め、0 なら必ず外します',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_ARK_FACE_1_10_47_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SUITE_EXTRA_JA_TEXTS.update(_SSSUITE_ARK_FACE_1_10_47_I18N)
except Exception:
    pass
# --- face ARKit 1.10.47 i18n END ---

# --- face ARKit 1.10.48 i18n START ---
# 1.10.48 layers (design 8.6). English is the source text of ark_face.py; Japanese here.
_SSSUITE_ARK_FACE_1_10_48_I18N = {
    'Animation Layer Weight': '層の重み',
    'Weight of this layer (NLA strip influence). With no or one key it is constant; when the weight already has several keys, a key is written at the current frame':
        'この層の重み（NLA ストリップの影響度）。キーが 0 か 1 個なら一定の値、既に複数のキーがある時は今のフレームにキーを書きます',
    'Show Base While Editing': '編集中も基層を見せる',
    'While a layer is edited, show the base under it through the guide track SS_BASE_VIEW (Blender itself does not evaluate the base action in tweak mode). Location, scale and custom properties match the playback exactly; a rotation keyed on another axis than the base rotation can differ from the playback':
        '層の編集中、表示用のトラック SS_BASE_VIEW で基層を下に敷いて見せます（Blender の微調整モード では基層のアクションは評価されません）。位置・拡大・カスタムプロパティは再生と一致します。基層と違う軸の回転は、再生とずれる事があります',
    'Add Animation Layer': '層を足す',
    'Add an animation layer: a new NLA track <base action>_L<n> with its own action, blend Add (added on top), weight 1, the frame range of the base. The base layer stays the current action; its blend becomes Add':
        'アニメーションの層を足します：新しい NLA トラック <基層のアクション>_L<n>（専用のアクション、合成は加算、重み 1、範囲は基層と同じ）。基層は今のアクションのままで、合成が加算になります',
    'Edit This Animation Layer': 'この層を編集',
    'Enter or leave the edit of a layer (NLA tweak mode). While editing, new keys go into the layer; with "Show base while editing" the base is shown under it':
        '層の編集（NLA の微調整モード）に入る・出る。編集中に打つキーは層に入ります。「編集中も基層を見せる」がオンなら基層を下に敷いて見せます',
    'Animation Layer Index': '層の番号',
    'Layer to edit, counted from the bottom': '編集する層（下から数える）',
    'Layer to remove, counted from the bottom': '消す層（下から数える）',
    'Layer to switch, counted from the bottom': '切り替える層（下から数える）',
    'Animation Layer Edit': '層の編集',
    'Enter or leave the layer edit': '層の編集に入るか出るか',
    'Enter Layer Edit': '層の編集に入る',
    'Start editing the layer': '層の編集を始めます',
    'Exit Layer Edit': '層の編集を出る',
    'Stop editing the layer and go back to the base': '層の編集を終えて基層に戻ります',
    'Collapse Animation Layers': '畳み込む',
    'Evaluate base + enabled layers on every frame of their range and key the result into the base action (linear keys on the channels the layers animate; the animated values, not the visual transform, so constraints are not keyed twice). The collapsed layers are muted and kept as a backup. Esc cancels':
        '基層＋有効な層を範囲の全フレームで評価し、その結果を基層のアクションへキーとして書きます（層が動かすチャンネルに直線補間のキー。見た目の変形ではなくアニメーションの値を書くので、拘束の分は二重になりません）。畳み込んだ層はミュートして控えとして残します。Esc で中断できます',
    'Remove Animation Layer': '層を消す',
    'Remove the layer (its NLA track, and its action when nothing else uses it). Removing the last layer puts the base blend back to Replace':
        '層を消します（NLA トラックと、他で使われていなければそのアクション）。最後の層を消すと、基層の合成を置換 に戻します',
    'Animation Layer Blend': '層の合成',
    'Switch the layer between Add (added on top) and Replace (overrides what is below)':
        '層を加算（上に足す）と置換（下を上書き）で切り替えます',
    'How the layer is blended': '層の合成のしかた',
    'Add (Combine)': '加算',
    'Added on top of the layers below': '下の層の上に足します',
    'Replace (Override)': '置換',
    'Overrides the layers below': '下の層を上書きします',
    'Enable Animation Layer': '層の有効・無効',
    'Enable or disable the layer (NLA track mute). Disabling puts the channels that only this layer animates back to their default, so no last value is left behind':
        '層を有効・無効にします（NLA トラックのミュート）。無効にする時は、この層だけが動かしていたチャンネルを既定の値へ戻すので、最後の値が残りません',
    'Enable Layer': '層を有効に',
    'True enables the layer, False disables (mutes) it': 'オンで層を有効に、オフで無効（ミュート）にします',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_ARK_FACE_1_10_48_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
try:
    _SUITE_EXTRA_JA_TEXTS.update(_SSSUITE_ARK_FACE_1_10_48_I18N)
except Exception:
    pass
# --- face ARKit 1.10.48 i18n END ---

# --- exception report i18n START ---
_SSSUITE_EXCEPTION_I18N = {
    'Source project not found': '元のプロジェクトが見つかりません。',
    'Target project already exists': '同じ名前のプロジェクトが既にあります。',
    'Unsafe path traversal detected': 'プロジェクト名に使えない文字が含まれています。',
    'Target object is not available': '対象のオブジェクトがありません。',
    'Unsafe or empty data path': 'データパスが空か、使えない形です。',
    'QCD move failed.': 'QCD スロットへ移動できませんでした。',
    'QCD Move Widget could not start.': 'QCD 移動ウィジェットを開始できませんでした。',
}
for _sssuite_msgid, _sssuite_ja in _SSSUITE_EXCEPTION_I18N.items():
    for _sssuite_ctx in _SSSUITE_TRANSLATION_CONTEXTS:
        blender_translations.setdefault('ja_JP', {})[(_sssuite_ctx, _sssuite_msgid)] = _sssuite_ja
_SSSUITE_REPORT_EXACT_JA.update(_SSSUITE_EXCEPTION_I18N)
# --- exception report i18n END ---
