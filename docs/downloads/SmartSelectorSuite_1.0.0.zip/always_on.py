# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import bpy

from .translation import is_japanese_locale as _is_japanese_locale, localize_class as _localize_class

_OPERATOR_ID = 'smart_selector_suite.toggle_always_on_feature'
_REGISTERED_CLASSES: list[type] = []
_TOGGLE_PROPERTY_GROUP_CLASS: type | None = None
_TOGGLE_POINTER_ATTR = 'smart_selector_suite_always_on_toggle_state'
_STATE_CACHE: dict[str, bool] | None = None
_TOOL_REBUILDING = False
_ICONS_RUNTIME_MODULE = None


def _icons_runtime():
    global _ICONS_RUNTIME_MODULE
    if _ICONS_RUNTIME_MODULE is None:
        try:
            from . import icons as _module
        except Exception:
            _module = None
        _ICONS_RUNTIME_MODULE = _module
    return _ICONS_RUNTIME_MODULE


def _icon_kwargs(name: str, fallback: str = 'NONE') -> dict:
    runtime = _icons_runtime()
    if runtime is not None:
        try:
            return dict(runtime.kwargs(str(name or '').strip(), fallback))
        except Exception:
            pass
    return {'icon': fallback}


def _feature_icon_name(info_or_icon) -> str:
    icon = ''
    if isinstance(info_or_icon, dict):
        icon = str(info_or_icon.get('icon') or '').strip()
        key = str(info_or_icon.get('key') or '').strip()
    else:
        icon = str(info_or_icon or '').strip()
        key = ''
    if key.startswith('tool_collection') or icon == 'OUTLINER_COLLECTION':
        return 'collection'
    if key.startswith('tool_gp') or key.startswith('gp_select') or icon in {'GREASEPENCIL', 'WPAINT_HLT'}:
        return 'gp_select'
    if key.startswith('smart_selector') or icon in {'URL', 'PLAY', 'TIME'}:
        if icon == 'URL':
            return 'bridge'
        if icon == 'TIME':
            return 'clock'
        return 'always_on'
    if key.startswith('qcd') or icon in {'PRESET', 'EVENT_ONEKEY', 'EDITMODE_HLT', 'TOPBAR'}:
        return 'selector_list'
    if icon in {'MENU_PANEL', 'EVENT_C'}:
        return 'menu'
    if icon in {'FILE_REFRESH', 'HIDE_OFF'}:
        return 'settings'
    return 'always_on'


class _SSS_DummyUIOperator:
    def __setattr__(self, _name, _value):
        return None
    def __getattr__(self, _name):
        return ''


def _safe_icon_string(icon: str, fallback: str = 'NONE') -> str:
    value = str(icon or fallback or 'NONE').strip() or 'NONE'
    return value if value.upper() != 'NONE' else 'NONE'


def _label_with_icon(layout, text: str, icon_name: str, fallback: str = 'NONE') -> None:
    label = str(text or '')
    try:
        layout.label(text=label, **_icon_kwargs(icon_name, fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon=_safe_icon_string(fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon='NONE')
    except Exception:
        pass


def _operator_with_icon(layout, operator_id: str, *, text: str = '', icon_name: str = '', fallback: str = 'NONE', **kwargs):
    label = str(text or '')
    call_kwargs = dict(kwargs)
    has_icon = bool(str(icon_name or '').strip()) or str(fallback or '').strip().upper() not in {'', 'NONE'}
    if label == '' and has_icon and call_kwargs.get('emboss') is False:
        call_kwargs.pop('emboss', None)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    icon_kwargs = {'icon_value': explicit_icon_value} if explicit_icon_value > 0 else _icon_kwargs(icon_name, fallback)
    try:
        return layout.operator(operator_id, text=label, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon_value', None)
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon=_safe_icon_string(fallback), **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon='NONE', **call_kwargs)
    except Exception:
        try:
            layout.label(text=label if label else '', icon='ERROR')
        except Exception:
            pass
        return _SSS_DummyUIOperator()


def _prop_with_icon(layout, data, property_name: str, *, text: str = '', icon_name: str = '', fallback: str = 'NONE', **kwargs) -> None:
    label = str(text or '')
    try:
        layout.prop(data, property_name, text=label, **_icon_kwargs(icon_name, fallback), **kwargs)
        return
    except Exception:
        pass
    try:
        layout.prop(data, property_name, text=label, icon=_safe_icon_string(fallback), **kwargs)
        return
    except Exception:
        pass
    try:
        layout.prop(data, property_name, text=label, icon='NONE', **kwargs)
    except Exception:
        pass


_FEATURE_DEFS: tuple[dict[str, Any], ...] = (
    {
        'key': 'npanel_state_save',
        'default': True,
        'label_en': 'N-panel State Save',
        'label_ja': 'Nパネル状態保存',
        'icon': 'FILE_TICK',
        "description_en": "Function: controls when Smart Selector writes all N-panel state, Always-on Toggles, section open states, bridge payloads, project choices, and integrated-tool UI settings to Smart_Selector_Suite/Smart_Selector_Suite.json in Blender's config folder. How to use: enable this to save every setting change immediately and keep it across scene changes and Blender restarts. Disable it when you want changes kept in memory until the current scene is closed or Save Preferences is executed.",
        'description_ja': '機能: Nパネル状態、常時機能切り替え、セクション開閉状態、ブリッジ入力、プロジェクト選択、統合ツールUI設定を、Blender の 設定フォルダー内の Smart_Selector_Suite/Smart_Selector_Suite.json へ保存するタイミングを制御します。使い方: 有効にすると全ての設定変更を即時保存し、シーン切り替え後や Blender 再起動後も維持します。無効にすると、現在のシーンを閉じるタイミング、または「プリファレンスを保存」を実行したタイミングまで現在セッション内に保持します。',
    },
    {
        'key': 'tool_collection_manager',
        'default': True,
        'ui_visible': False,
        'label_en': 'Collection Manager',
        'label_ja': 'コレクションマネージャー',
        'icon': 'OUTLINER_COLLECTION',
        'description_en': 'Function: allows the Collection Manager tool UI and commands to be loaded on demand from the Smart Selector N-panel. How to use: keep this enabled if you want Collection Manager available. Disabling it unloads its panels, operators, handlers, menus, header widgets, and hotkeys so the tool stays completely inactive.',
        'description_ja': '機能: スマートセレクターのNパネルから、必要な時だけコレクションマネージャーのUIとコマンドを読み込めるようにします。使い方: コレクションマネージャーを使う場合は有効にしてください。無効にすると、関連パネル、オペレーター、ハンドラー、メニュー、ヘッダーウィジェット、ホットキーを解除し、完全に停止します。',
    },
    {
        'key': 'tool_gp_select',
        'default': True,
        'ui_visible': False,
        'label_en': 'GP Select',
        'label_ja': 'GP セレクト',
        'icon': 'GREASEPENCIL',
        'description_en': 'Function: allows the GP Select tool UI and commands to be loaded on demand from the Smart Selector N-panel. How to use: keep this enabled if you want Grease Pencil selection, renaming, pass-index, material, and rigging helpers available. Disabling it unloads its panels and operators so it stays completely inactive.',
        'description_ja': '機能: スマートセレクターのNパネルから、必要な時だけ GP セレクトのUIとコマンドを読み込めるようにします。使い方: Grease Pencil の選択、リネーム、パスインデックス、マテリアル、リギング補助を使う場合は有効にしてください。無効にすると、関連パネルとオペレーターを解除し、完全に停止します。',
    },
    {
        'key': 'collection_manager_state_handlers',
        'default': False,
        'label_en': 'Collection cleanup handlers',
        'label_ja': 'コレクションの後片付け',
        'icon': 'FILE_REFRESH',
        'description_en': 'Function: enables Collection Manager handlers that automatically clear temporary move-selection state after dependency-graph updates, Undo, Redo, and file loading. How to use: enable this only when you need automatic Collection Manager cleanup in the background. The save timing follows N-panel State Save, and the setting remains after Blender restarts and scene changes.',
        'description_ja': '機能: 依存グラフ更新、元に戻す、やり直し、ファイル読込後に、コレクションマネージャーの一時的な移動選択状態を自動整理するハンドラーを有効化します。使い方: バックグラウンドで自動クリーンアップが必要な場合だけ有効にしてください。保存タイミングは「Nパネル状態保存」に従い、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    {
        'key': 'collection_manager_object_menu',
        'default': False,
        'label_en': 'Collection menu entries',
        'label_ja': 'コレクションメニューの項目',
        'icon': 'MENU_PANEL',
        'description_en': 'Function: adds Collection Manager and QCD Move Widget commands to Blender’s Object Collection menu. How to use: enable this when you want those commands available from the 3D View object menu in addition to the N-panel. Disabling it removes the menu callbacks.',
        'description_ja': '機能: Blender のオブジェクトのコレクションメニューへ、コレクションマネージャーと QCD 移動ウィジェットの項目を追加します。使い方: Nパネルだけでなく3Dビューのオブジェクトメニューからも実行したい場合に有効にしてください。無効にするとメニュー追加コールバックを解除します。',
    },
    {
        'key': 'collection_manager_popup_hotkey',
        'default': False,
        'label_en': 'Popup hotkey',
        'label_ja': 'ポップアップのホットキー',
        'icon': 'EVENT_C',
        'description_en': 'Function: enables the Object Mode shortcut that opens the Collection Manager popup. How to use: enable this only when you want the popup shortcut active in the background. Disabling it removes the add-on keymap item.',
        'description_ja': '機能: コレクションマネージャーのポップアップを開くオブジェクトモード用ショートカットを有効化します。使い方: バックグラウンドでポップアップ用ショートカットを使いたい場合だけ有効にしてください。無効にするとアドオンキーマップ項目を解除します。',
    },
    {
        'key': 'collection_manager_disable_objects_override',
        'default': False,
        'label_en': 'Disable Objects override',
        'label_ja': 'オブジェクト無効化の置き換え',
        'icon': 'HIDE_OFF',
        'description_en': 'Function: adds Disable Selected Objects, Disable Unselected Objects, and Restore Disabled Objects to the Object Show/Hide menu and enables the H, Shift+H, and Alt+H shortcuts for that workflow. How to use: enable this only when object disabling should replace the usual hide workflow. Disabling it removes the menu entry and hotkeys.',
        'description_ja': '機能: 「選択物を無効化」「非選択物を無効化」「無効化した物を戻す」をオブジェクトの表示/非表示メニューに追加し、H、Shift+H、Alt+H のショートカットを有効化します。使い方: 通常の非表示操作ではなくオブジェクト無効化を中心に使う場合だけ有効にしてください。無効にするとメニュー項目とホットキーを解除します。',
    },
    {
        'key': 'qcd_system',
        'default': False,
        'label_en': 'QCD system',
        'label_ja': 'QCD システム',
        'icon': 'PRESET',
        'description_en': 'Function: enables the Quick Content Display system, including QCD operators, the popup move widget shortcut, QCD save/load handlers, and optional QCD subfeatures. How to use: enable this when QCD slots must be active in the background. Disabling it unregisters QCD, its handlers, its hotkeys, and its header widget.',
        'description_ja': '機能: QCD オペレーター、ポップアップ移動ウィジェットショートカット、QCD 保存/読込ハンドラー、任意の QCD サブ機能を含む QCD システムを有効化します。使い方: QCD スロットをバックグラウンドで常時使う場合に有効にしてください。無効にすると QCD、関連ハンドラー、ホットキー、ヘッダーウィジェットを解除します。',
    },
    {
        'key': 'qcd_view_hotkeys',
        'default': False,
        'label_en': 'QCD hotkeys (non-edit)',
        'label_ja': 'QCD ホットキー（編集以外）',
        'icon': 'EVENT_ONEKEY',
        'description_en': 'Function: enables number-key QCD slot shortcuts in Object Mode, Pose Mode, and Weight Paint. How to use: enable this when you want numeric QCD slot switching outside Edit Mode. This requires the QCD system to be enabled.',
        'description_ja': '機能: オブジェクトモード、ポーズモード、ウェイトペイントで数値キーによる QCD スロットショートカットを有効化します。使い方: 編集モード以外で数値キーによる QCD スロット切り替えを使う場合に有効にしてください。この項目は QCD システムが有効な場合に機能します。',
    },
    {
        'key': 'qcd_edit_mode_hotkeys',
        'default': False,
        'label_en': 'QCD edit-mode hotkeys',
        'label_ja': 'QCD 編集モード用ホットキー',
        'icon': 'EDITMODE_HLT',
        'description_en': 'Function: enables number-key QCD slot shortcuts in Mesh, Curve, Armature, Metaball, Lattice, and Grease Pencil Stroke Edit Mode. How to use: enable this when you want QCD slot switching while editing geometry. This requires the QCD system to be enabled.',
        'description_ja': '機能: メッシュ・カーブ・アーマチュア・メタボール・ラティス・Grease Pencil ストロークの編集モードで数値キーによる QCD スロットショートカットを有効化します。使い方: ジオメトリ編集中も QCD スロット切り替えを使う場合に有効にしてください。この項目は QCD システムが有効な場合に機能します。',
    },
    {
        'key': 'qcd_header_widget',
        'default': False,
        'label_en': 'QCD 3D View header widget',
        'label_ja': 'QCD ヘッダーウィジェット',
        'icon': 'TOPBAR',
        'description_en': 'Function: draws the QCD slot widget in the 3D View header and updates it when the active View Layer changes. How to use: enable this only when QCD buttons should appear in the 3D View header. Disabling it removes the header draw callbacks.',
        'description_ja': '機能: 3Dビューのヘッダーに QCD スロットウィジェットを表示し、アクティブビューレイヤーの変更に合わせて更新します。使い方: 3Dビューのヘッダーに QCD ボタンを表示したい場合だけ有効にしてください。無効にするとヘッダー描画コールバックを解除します。',
    },
    {
        'key': 'legacy_proxy_cleanup',
        'default': False,
        'label_en': 'Legacy Proxy Cleanup',
        'label_ja': '旧プロキシ整理',
        'icon': 'BRUSH_DATA',
        'description_en': 'Function: installs file-boundary handlers and a low-frequency maintenance timer that remove legacy Smart Tools proxy markers from old .blend files. How to use: enable only while repairing files created by older releases. Disabling it removes every cleanup handler and timer so normal idle load is zero.',
        'description_ja': '機能: 旧版の .blend に残った Smart Tools プロキシ識別子を整理するファイル境界ハンドラーと低頻度タイマーを有効にします。使い方: 旧版で作成したファイルの修復中だけ有効にしてください。無効にするとすべての整理ハンドラーとタイマーを解除し、通常待機時の負荷をゼロにします。',
    },
    {
        'key': 'gp_select_weight_cleanup_handlers',
        'default': False,
        'label_en': 'GP weight cleanup handlers',
        'label_ja': 'GP ウェイトの後片付け',
        'icon': 'WPAINT_HLT',
        'description_en': 'Function: allows GP Select’s Weight Selected workflow to install temporary cleanup handlers that restore layer, material, armature, and object selectability after leaving Weight Paint or using Undo and Redo. How to use: keep this enabled for normal Weight Selected behavior. Disabling it removes existing cleanup handlers and prevents new ones from being installed.',
        'description_ja': '機能: GP セレクトの「選択へウェイト」ワークフローで、ウェイトペイント終了後や 元に戻す・やり直し 後にレイヤー、マテリアル、アーマチュア、オブジェクトの選択可否を戻す一時クリーンアップハンドラーを許可します。使い方: 通常の「選択へウェイト」動作では有効にしてください。無効にすると既存ハンドラーを解除し、新規追加も防ぎます。',
    },
    {
        'key': 'smart_selector_browser_server',
        'default': False,
        'label_en': 'Browser server',
        'label_ja': 'ブラウザーサーバー',
        'icon': 'URL',
        'description_en': 'Function: allows Smart Selector to start the local browser bridge server only when a selector edit/play window is opened. How to use: keep this enabled to open selectors in the browser. Disabling it immediately stops the server and prevents new browser selector windows from starting. It does not keep a server running at Blender startup.',
        'description_ja': '機能: セレクターの編集・再生ウィンドウを開いた時だけ、ローカルブラウザーブリッジサーバーの起動を許可します。使い方: ブラウザーでセレクターを開く場合は有効にしてください。無効にするとサーバーを即停止し、新しいブラウザーセレクターウィンドウの起動も止めます。Blender起動時にサーバーを常駐起動する項目ではありません。',
    },
    {
        'key': 'smart_selector_state_watchers',
        'default': True,
        'ui_visible': False,
        'label_en': 'Browser data watchers',
        'label_ja': 'ブラウザーデータ監視',
        'icon': 'HIDE_OFF',
        'description_en': 'Internal on-demand browser data watchers. They are registered only while the browser bridge server is running and are removed when the server stops.',
        'description_ja': 'ブラウザーブリッジ稼働中だけ自動登録され、サーバー停止時に解除されるオンデマンド内部監視です。',
    },
    {
        'key': 'smart_selector_state_cache_timer',
        'default': True,
        'ui_visible': False,
        'label_en': 'Browser state-sync timer',
        'label_ja': 'ブラウザー状態同期タイマー',
        'icon': 'TIME',
        'description_en': 'Internal on-demand browser state-sync timer. It runs only while the browser bridge server is running and is removed when the server stops.',
        'description_ja': 'ブラウザーブリッジ稼働中だけ動作し、サーバー停止時に解除されるオンデマンド内部同期タイマーです。',
    },
    {
        'key': 'smart_selector_task_queue_timer',
        'default': True,
        'ui_visible': False,
        'label_en': 'Browser task-queue timer',
        'label_ja': 'ブラウザータスクキュータイマー',
        'icon': 'PLAY',
        'description_en': 'Internal on-demand browser task-queue timer. It runs only while the browser bridge server is running and is removed when the server stops.',
        'description_ja': 'ブラウザーブリッジ稼働中だけ動作し、サーバー停止時に解除されるオンデマンド内部タスクキュータイマーです。',
    },
)

_FEATURES_BY_KEY = {str(item['key']): dict(item) for item in _FEATURE_DEFS}
_TOOL_ALIAS_TO_FEATURE = {
    'collection_manager': 'tool_collection_manager',
    'gp_select': 'tool_gp_select',
}
_RUNTIME_FLAG_TO_FEATURE = {
    'enable_disable_objects_override': 'collection_manager_disable_objects_override',
    'enable_qcd': 'qcd_system',
    'enable_qcd_view_hotkeys': 'qcd_view_hotkeys',
    'enable_qcd_view_edit_mode_hotkeys': 'qcd_edit_mode_hotkeys',
    'enable_qcd_3dview_header_widget': 'qcd_header_widget',
}

# These browser internals used to be exposed as Always-on Toggles.  They do not
# need to be persistent background features: the same behavior is achieved by
# registering them only while the browser bridge server is running, then
# unregistering them when the server stops.  Old saved disabled values are
# ignored so browser operation remains intact after upgrading.
_AUTO_ON_DEMAND_FEATURE_KEYS = {
    'smart_selector_state_watchers',
    'smart_selector_state_cache_timer',
    'smart_selector_task_queue_timer',
}


def _t(en: str, ja: str) -> str:
    return str(ja if _is_japanese_locale() else en)


def _settings_path() -> Path | None:
    try:
        from . import settings as _settings
        return _settings.settings_path()
    except Exception:
        return None


def reset_state_cache() -> None:
    global _STATE_CACHE
    _STATE_CACHE = None


def _coerce_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {'1', 'true', 'yes', 'on', 'enabled'}:
        return True
    if text in {'0', 'false', 'no', 'off', 'disabled', 'none', 'null', ''}:
        return False
    return bool(default)


def _load_state() -> dict[str, bool]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, bool] = {key: feature_default(key) for key in _FEATURES_BY_KEY}
    try:
        from . import settings as _settings
        raw = _settings.load_state()
        for key in _FEATURES_BY_KEY:
            if key in raw:
                data[key] = _coerce_bool(raw.get(key), feature_default(key))
        nested = raw.get('always_on_features') if isinstance(raw, dict) else None
        if isinstance(nested, dict):
            for key in _FEATURES_BY_KEY:
                if key in nested:
                    data[key] = _coerce_bool(nested.get(key), feature_default(key))
        for key in _AUTO_ON_DEMAND_FEATURE_KEYS:
            if key in data:
                data[key] = True
    except Exception:
        path = _settings_path()
        if path is not None and path.exists():
            try:
                raw = json.loads(path.read_text(encoding='utf-8'))
                if isinstance(raw, dict):
                    for key, value in raw.items():
                        key = str(key or '').strip()
                        if key in _FEATURES_BY_KEY:
                            data[key] = _coerce_bool(value, feature_default(key))
            except Exception:
                data = {key: feature_default(key) for key in _FEATURES_BY_KEY}
    for key in _AUTO_ON_DEMAND_FEATURE_KEYS:
        if key in data:
            data[key] = True
    _STATE_CACHE = data
    return _STATE_CACHE


def _save_state(*, force: bool = False) -> None:
    try:
        from . import settings as _settings
        state = _settings.load_state()
        feature_state = {key: bool(value) for key, value in _load_state().items() if key in _FEATURES_BY_KEY}
        state.update(feature_state)
        state['always_on_features'] = dict(feature_state)
        if 'npanel_state_save' in feature_state:
            state['npanel_state_save'] = bool(feature_state.get('npanel_state_save'))
        _settings.save_state(force=bool(force))
        try:
            _settings.queue_user_preferences_save()
        except Exception:
            pass
        return
    except Exception:
        pass
    path = _settings_path()
    if path is None:
        return
    try:
        payload = json.dumps(_load_state(), ensure_ascii=False, indent=2, sort_keys=True)
        try:
            from . import storage
            storage.atomic_write_text(path, payload, encoding='utf-8')
        except Exception:
            tmp = path.with_name(path.name + '.tmp')
            tmp.write_text(payload, encoding='utf-8')
            tmp.replace(path)
    except Exception:
        pass


def feature_default(feature_key: str, default: bool = True) -> bool:
    info = _FEATURES_BY_KEY.get(str(feature_key or '').strip())
    if info is None:
        return bool(default)
    return bool(info.get('default', default))


def is_feature_enabled(feature_key: str, default: bool | None = None) -> bool:
    key = str(feature_key or '').strip()
    if not key:
        return bool(default if default is not None else True)
    if key in _AUTO_ON_DEMAND_FEATURE_KEYS:
        return True
    fallback = feature_default(key, True) if key in _FEATURES_BY_KEY else bool(default if default is not None else True)
    return bool(_load_state().get(key, fallback))


def is_runtime_flag_enabled(flag_name: str, default: bool = True) -> bool:
    feature_key = _RUNTIME_FLAG_TO_FEATURE.get(str(flag_name or '').strip())
    if not feature_key:
        return bool(default)
    return is_feature_enabled(feature_key, default=default)


def set_runtime_flag_enabled(flag_name: str, enabled: bool, *, apply: bool = True) -> bool:
    feature_key = _RUNTIME_FLAG_TO_FEATURE.get(str(flag_name or '').strip())
    if not feature_key:
        return False
    return set_feature_enabled(feature_key, bool(enabled), apply=apply)


def tool_enabled(alias: str, default: bool = True) -> bool:
    feature_key = _TOOL_ALIAS_TO_FEATURE.get(str(alias or '').strip())
    if not feature_key:
        return bool(default)
    return is_feature_enabled(feature_key, default=default)


def _feature_default(feature_key: str, fallback: bool = False) -> bool:
    info = _FEATURES_BY_KEY.get(str(feature_key or '').strip())
    if not info:
        return bool(fallback)
    return bool(info.get('default', fallback))


def _feature_bool_getter(feature_key: str):
    key = str(feature_key or '').strip()

    def _getter(_self) -> bool:
        return bool(is_feature_enabled(key, default=_feature_default(key)))

    return _getter


def _feature_bool_setter(feature_key: str):
    key = str(feature_key or '').strip()

    def _setter(_self, value) -> None:
        set_feature_enabled(key, bool(value), apply=True, context=getattr(bpy, 'context', None))

    return _setter


def _make_toggle_property_group_class() -> type:
    annotations: dict[str, Any] = {}
    for info in _FEATURE_DEFS:
        key = str(info.get('key') or '').strip()
        if not key or info.get('ui_visible', True) is False:
            continue
        annotations[key] = bpy.props.BoolProperty(
            name=str(info.get('label_en') or key),
            description=str(info.get('description_en') or 'Toggle this always-on Smart Selector feature. The save timing follows N-panel State Save.'),
            default=bool(info.get('default', False)),
            get=_feature_bool_getter(key),
            set=_feature_bool_setter(key),
        )

    cls = type(
        'SSSUITE_AlwaysOnToggleProperties',
        (bpy.types.PropertyGroup,),
        {
            '__module__': __name__,
            '__annotations__': annotations,
        },
    )
    return cls


def _toggle_property_owner(context=None):
    try:
        if not hasattr(bpy.types.WindowManager, _TOGGLE_POINTER_ATTR):
            return None
    except Exception:
        return None
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None)
        if wm is None:
            return None
        return getattr(wm, _TOGGLE_POINTER_ATTR, None)
    except Exception:
        return None

def set_feature_enabled(feature_key: str, enabled: bool, *, apply: bool = True, context=None) -> bool:
    key = str(feature_key or '').strip()
    if key not in _FEATURES_BY_KEY:
        return False
    if key in _AUTO_ON_DEMAND_FEATURE_KEYS:
        enabled = True
    _load_state()[key] = bool(enabled)
    _save_state(force=(key == 'npanel_state_save'))
    if apply:
        apply_feature(key, context=context)
    _tag_redraw()
    return True


def feature_definitions(*, visible_only: bool = True) -> tuple[dict[str, Any], ...]:
    if visible_only:
        return tuple(dict(item) for item in _FEATURE_DEFS if item.get('ui_visible', True) is not False)
    return tuple(dict(item) for item in _FEATURE_DEFS)


def _cm_registered() -> bool:
    try:
        return hasattr(bpy.types.Scene, 'collection_manager')
    except Exception:
        return False


def _qcd_registered() -> bool:
    try:
        module = sys.modules.get(f'{__package__}.collection_manager.qcd_init')
        if module is None:
            return False
        return bool(getattr(module, 'qcd_registered', False))
    except Exception:
        return False


def _server_module():
    return sys.modules.get(f'{__package__}.server')


def _server_running() -> bool:
    try:
        module = _server_module()
        return bool(module is not None and getattr(module, 'httpd', None) is not None)
    except Exception:
        return False


def _refresh_runtime_records(context=None) -> None:
    try:
        from . import ui_runtime as ui_runtime
        refresh = getattr(ui_runtime, 'refresh_all_suites', None)
        if callable(refresh):
            refresh(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _ensure_tool_runtime_loaded(alias: str, context=None) -> bool:
    alias = str(alias or '').strip()
    if not alias or not tool_enabled(alias, True):
        return False
    try:
        from . import loader as loader
        record = loader.ensure_record_loaded(alias)
        _refresh_runtime_records(context)
        return isinstance(record, dict) and str(record.get('status') or '') == 'loaded'
    except Exception:
        return False


def _ensure_tool_runtime_unloaded(alias: str, context=None) -> bool:
    alias = str(alias or '').strip()
    if not alias:
        return False
    try:
        from . import loader as loader
        record = loader.ensure_record_unloaded(alias)
        _refresh_runtime_records(context)
        return isinstance(record, dict)
    except Exception:
        return False


def _rebuild_tool_modules(context=None) -> None:
    global _TOOL_REBUILDING
    if _TOOL_REBUILDING:
        return
    _TOOL_REBUILDING = True
    try:
        try:
            from . import registry as registry
            registry.clear_cache()
        except Exception:
            pass
        try:
            from . import tool_runtime as runtime
            rebuild = getattr(runtime, 'rebuild_if_registered', None)
            if callable(rebuild):
                rebuild(context or getattr(bpy, 'context', None))
        except Exception:
            pass
        apply_all(context=context, include_tool_modules=False)
    finally:
        _TOOL_REBUILDING = False


def _apply_collection_manager_feature(feature_key: str, enabled: bool, context=None) -> None:
    if enabled and not _ensure_tool_runtime_loaded('collection_manager', context=context):
        return
    if not enabled and not _cm_registered():
        return
    try:
        from .collection_manager import cm_init
    except Exception:
        return
    if feature_key == 'collection_manager_state_handlers':
        fn = getattr(cm_init, 'register_collection_manager_state_handlers', None) if enabled and _cm_registered() else getattr(cm_init, 'unregister_collection_manager_state_handlers', None)
    elif feature_key == 'collection_manager_object_menu':
        fn = getattr(cm_init, 'register_collection_manager_object_menu', None) if enabled and _cm_registered() else getattr(cm_init, 'unregister_collection_manager_object_menu', None)
    elif feature_key == 'collection_manager_popup_hotkey':
        fn = getattr(cm_init, 'register_collection_manager_popup_hotkey', None) if enabled and _cm_registered() else getattr(cm_init, 'unregister_collection_manager_popup_hotkey', None)
    elif feature_key == 'collection_manager_disable_objects_override':
        fn = getattr(cm_init, 'register_disable_objects_override', None) if enabled and _cm_registered() else getattr(cm_init, 'unregister_disable_objects_override', None)
    else:
        fn = None
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def _apply_qcd_feature(feature_key: str, enabled: bool, context=None) -> None:
    if feature_key != 'qcd_system' and enabled and not is_feature_enabled('qcd_system', True):
        return
    if enabled and not _ensure_tool_runtime_loaded('collection_manager', context=context):
        return
    if not enabled and not (_cm_registered() or _qcd_registered()):
        return
    try:
        from .collection_manager import qcd_init
    except Exception:
        return
    cm_active = tool_enabled('collection_manager', True) and _cm_registered()
    if feature_key == 'qcd_system':
        if enabled and cm_active:
            try:
                qcd_init.register_qcd()
            except Exception:
                pass
        else:
            try:
                qcd_init.unregister_qcd()
            except Exception:
                pass
        return
    qcd_active = cm_active and is_feature_enabled('qcd_system', True) and _qcd_registered()
    if feature_key == 'qcd_view_hotkeys':
        fn = getattr(qcd_init, 'register_qcd_view_hotkeys', None) if enabled and qcd_active else getattr(qcd_init, 'unregister_qcd_view_hotkeys', None)
    elif feature_key == 'qcd_edit_mode_hotkeys':
        fn = getattr(qcd_init, 'register_qcd_view_edit_mode_hotkeys', None) if enabled and qcd_active else getattr(qcd_init, 'unregister_qcd_view_edit_mode_hotkeys', None)
    elif feature_key == 'qcd_header_widget':
        fn = getattr(qcd_init, 'register_qcd_3dview_header_widget', None) if enabled and qcd_active else getattr(qcd_init, 'unregister_qcd_3dview_header_widget', None)
    else:
        fn = None
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def _apply_gp_select_feature(feature_key: str, enabled: bool) -> None:
    if feature_key != 'gp_select_weight_cleanup_handlers':
        return
    if enabled:
        return
    module = sys.modules.get(f'{__package__}.gp_select')
    if module is None:
        return
    cleanup = getattr(module, 'remove_weight_cleanup_handlers', None)
    if callable(cleanup):
        try:
            cleanup()
        except Exception:
            pass


def _apply_browser_feature(feature_key: str, enabled: bool) -> None:
    server_module = _server_module()
    if server_module is None:
        # Browser bridge support stays completely unloaded at startup.  Disabled
        # entries do not import the server merely to stop timers/listeners that
        # cannot exist before the server module has been loaded.  When the module
        # is already loaded, the code below unregisters or stops the active parts.
        return
    if feature_key == 'smart_selector_browser_server':
        if not enabled:
            stop = getattr(server_module, 'stop_server', None)
            if callable(stop):
                try:
                    stop()
                except Exception:
                    pass
        return
    if feature_key == 'smart_selector_state_watchers':
        if enabled and _server_running() and is_feature_enabled('smart_selector_browser_server', True):
            fn = getattr(server_module, 'register_state_listeners', None)
        else:
            fn = getattr(server_module, 'unregister_state_listeners', None)
    elif feature_key == 'smart_selector_state_cache_timer':
        if enabled and _server_running() and is_feature_enabled('smart_selector_browser_server', True):
            fn = getattr(server_module, 'register_state_cache_timer', None)
        else:
            fn = getattr(server_module, 'unregister_state_cache_timer', None)
    elif feature_key == 'smart_selector_task_queue_timer':
        if enabled and _server_running() and is_feature_enabled('smart_selector_browser_server', True):
            fn = getattr(server_module, 'register_task_queue_timer', None)
        else:
            fn = getattr(server_module, 'unregister_task_queue_timer', None)
    else:
        fn = None
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def apply_feature(feature_key: str, context=None) -> None:
    key = str(feature_key or '').strip()
    enabled = is_feature_enabled(key)
    if key == 'tool_collection_manager':
        if not enabled:
            _ensure_tool_runtime_unloaded('collection_manager', context=context)
        _rebuild_tool_modules(context=context)
    elif key == 'tool_gp_select':
        if not enabled:
            _ensure_tool_runtime_unloaded('gp_select', context=context)
        _rebuild_tool_modules(context=context)
    elif key.startswith('collection_manager_'):
        _apply_collection_manager_feature(key, enabled, context=context)
    elif key.startswith('qcd_'):
        _apply_qcd_feature(key, enabled, context=context)
    elif key.startswith('gp_select_'):
        _apply_gp_select_feature(key, enabled)
    elif key.startswith('smart_selector_'):
        _apply_browser_feature(key, enabled)
    elif key == 'legacy_proxy_cleanup':
        import sys
        module_name = f'{__package__}.proxy_cleanup'
        module = sys.modules.get(module_name)
        if enabled:
            if module is None:
                import importlib
                module = importlib.import_module(module_name)
            register_fn = getattr(module, 'register', None)
            if callable(register_fn):
                register_fn()
        elif module is not None:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                unregister_fn()
    _tag_redraw()


def apply_all(context=None, *, include_tool_modules: bool = True) -> None:
    if include_tool_modules:
        for key, alias in (('tool_collection_manager', 'collection_manager'), ('tool_gp_select', 'gp_select')):
            if not is_feature_enabled(key, True):
                _ensure_tool_runtime_unloaded(alias, context=context)
    for item in _FEATURE_DEFS:
        key = str(item.get('key') or '')
        if key in {'tool_collection_manager', 'tool_gp_select'}:
            continue
        try:
            apply_feature(key, context=context)
        except Exception:
            pass


def _tag_redraw() -> None:
    try:
        supported = {
            'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR',
            'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR',
            'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET',
        }
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in supported:
                    area.tag_redraw()
    except Exception:
        pass


def _feature_label(info: dict[str, Any]) -> str:
    return _t(str(info.get('label_en') or info.get('key') or ''), str(info.get('label_ja') or info.get('label_en') or info.get('key') or ''))


def _feature_description(info: dict[str, Any]) -> str:
    return _t(str(info.get('description_en') or ''), str(info.get('description_ja') or info.get('description_en') or ''))


def _operator_description(context, properties) -> str:
    key = str(getattr(properties, 'feature_key', '') or '').strip()
    info = _FEATURES_BY_KEY.get(key)
    if not info:
        return _t('Toggle an always-on feature for Smart Selector. The save timing follows N-panel State Save.', 'スマートセレクターの常時起動機能を切り替えます。保存タイミングは「Nパネル状態保存」に従います。')
    state = is_feature_enabled(key)
    action = _t('Click to disable this feature.' if state else 'Click to enable this feature.', 'クリックすると、この機能を無効にします。' if state else 'クリックすると、この機能を有効にします。')
    return f'{_feature_label(info)}: {_feature_description(info)} {action}'


def _state_text(enabled: bool) -> str:
    return _t('On', '有効') if enabled else _t('Off', '無効')


def draw_toggle_group(layout, context=None, settings=None) -> int:
    """Draw the Smart Render-style collapsed always-on group."""
    box = layout.box()
    is_open = False
    if settings is not None and hasattr(settings, 'show_always_on_toggles'):
        try:
            is_open = bool(getattr(settings, 'show_always_on_toggles', False))
        except Exception:
            is_open = False
    else:
        try:
            from . import settings
            is_open = bool(settings.get_value('show_always_on_toggles', False))
        except Exception:
            is_open = False

    header_label = _t('Always-on Toggles', '常時機能切り替え')
    # The header is the shared Smart Selector top-level section header
    # (ui._draw_section_toggle_header: triangle, borderless icon+title, 0.35
    # gap, compact help) so it lines up with every other top-level section.
    # Section key 'show_always_on_toggles' reads and toggles the same persisted
    # state as the N-panel property above.  The sibling ui module is taken from
    # sys.modules (no import while drawing); the hand-drawn header below is
    # only the fallback.
    drawn_open = None
    try:
        ui_module = sys.modules.get(f'{__package__}.ui') if __package__ else None
        draw_section_header = getattr(ui_module, '_draw_section_toggle_header', None)
        if callable(draw_section_header):
            drawn_open = bool(draw_section_header(box, section_key='show_always_on_toggles', label=header_label, icon='TIME', icon_name='clock', help_topic='always_on_toggles', default=False))
    except Exception:
        drawn_open = None
    if drawn_open is not None:
        is_open = drawn_open
    else:
        header = box.row(align=True)
        header.use_property_split = False
        header.use_property_decorate = False
        try:
            op = header.operator('smart_selector_suite.toggle_ui_section', text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=True, depress=is_open)
            op.section_key = 'show_always_on_toggles'
            op.label = header_label
            op.default_state = False
        except Exception:
            header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
        title_op = _operator_with_icon(header, 'smart_selector_suite.toggle_ui_section', text=header_label, icon_name='clock', fallback='TIME', emboss=False, depress=is_open)
        try:
            title_op.section_key = 'show_always_on_toggles'
            title_op.label = header_label
            title_op.default_state = False
        except Exception:
            pass
        try:
            header.separator(factor=0.35)
        except Exception:
            pass
        try:
            help_row = header.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
            op.topic_id = 'always_on_toggles'
        except TypeError:
            try:
                op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
                op.topic_id = 'always_on_toggles'
            except Exception:
                pass
        except Exception:
            pass

    if not is_open:
        return 0

    col = box.column(align=True)
    owner = _toggle_property_owner(context)
    count = 0
    for info in _FEATURE_DEFS:
        key = str(info.get('key') or '').strip()
        if not key or info.get('ui_visible', True) is False:
            continue
        enabled = is_feature_enabled(key, default=bool(info.get('default', False)))
        # Shared Smart Tools always-on row: the function name on the left and
        # one checkbox-style Enabled/Disabled toggle aligned to the right.
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)

        left = split.row(align=True)
        left.label(text=_feature_label(info))

        button = split.row(align=True)
        button.alignment = 'RIGHT'
        button.use_property_split = False
        button.use_property_decorate = False
        toggle_icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
        state_text = _state_text(enabled)
        if owner is not None and hasattr(owner, key):
            try:
                button.row(align=True).prop(
                    owner,
                    key,
                    text=state_text,
                    icon=toggle_icon,
                    toggle=True,
                )
            except Exception:
                op = _operator_with_icon(
                    button.row(align=True),
                    _OPERATOR_ID,
                    text=state_text,
                    icon_name='',
                    fallback=toggle_icon,
                    depress=enabled,
                )
                op.feature_key = key
        else:
            op = _operator_with_icon(
                button.row(align=True),
                _OPERATOR_ID,
                text=state_text,
                icon_name='',
                fallback=toggle_icon,
                depress=enabled,
            )
            op.feature_key = key
        count += 1
        if key == 'npanel_state_save':
            try:
                col.separator(factor=0.5)
            except Exception:
                pass
    return count


def register() -> None:
    global _TOGGLE_PROPERTY_GROUP_CLASS
    if _REGISTERED_CLASSES:
        return

    try:
        if hasattr(bpy.types.WindowManager, _TOGGLE_POINTER_ATTR):
            delattr(bpy.types.WindowManager, _TOGGLE_POINTER_ATTR)
    except Exception:
        pass

    try:
        existing_pg = getattr(bpy.types, 'SSSUITE_AlwaysOnToggleProperties', None)
        if isinstance(existing_pg, type):
            try:
                bpy.utils.unregister_class(existing_pg)
            except Exception:
                pass
    except Exception:
        pass

    _TOGGLE_PROPERTY_GROUP_CLASS = _make_toggle_property_group_class()
    try:
        bpy.utils.register_class(_TOGGLE_PROPERTY_GROUP_CLASS)
        bpy.types.WindowManager.smart_selector_suite_always_on_toggle_state = bpy.props.PointerProperty(type=_TOGGLE_PROPERTY_GROUP_CLASS, description='Function: stores Smart Selector Always On Toggle State runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')
    except Exception:
        _TOGGLE_PROPERTY_GROUP_CLASS = None

    class SSSUITE_OT_toggle_always_on_feature(bpy.types.Operator):
        bl_idname = _OPERATOR_ID
        bl_label = 'Toggle Always-on Feature'
        bl_description = 'Switch an always-on Smart Selector feature on or off. The save timing follows N-panel State Save.'
        bl_options = {'UNDO', 'INTERNAL'}

        feature_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'}, description='Function: supplies the Feature Key parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            key = str(getattr(self, 'feature_key', '') or '').strip()
            if key not in _FEATURES_BY_KEY:
                self.report({'WARNING'}, _t('Unknown always-on feature.', '不明な常時起動機能です。'))
                return {'CANCELLED'}
            new_state = not is_feature_enabled(key)
            set_feature_enabled(key, new_state, apply=True, context=context)
            self.report({'INFO'}, _t('Always-on feature setting updated.', '常時起動機能の設定を更新しました。'))
            return {'FINISHED'}

    SSSUITE_OT_toggle_always_on_feature.__name__ = 'SSSUITE_OT_toggle_always_on_feature'
    SSSUITE_OT_toggle_always_on_feature.__qualname__ = SSSUITE_OT_toggle_always_on_feature.__name__
    SSSUITE_OT_toggle_always_on_feature.__module__ = __name__
    try:
        existing = getattr(bpy.types, SSSUITE_OT_toggle_always_on_feature.__name__, None)
        if isinstance(existing, type) and existing is not SSSUITE_OT_toggle_always_on_feature:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    cls = _localize_class(SSSUITE_OT_toggle_always_on_feature)
    bpy.utils.register_class(cls)
    _REGISTERED_CLASSES.append(cls)


def unregister() -> None:
    global _TOGGLE_PROPERTY_GROUP_CLASS
    try:
        if hasattr(bpy.types.WindowManager, _TOGGLE_POINTER_ATTR):
            delattr(bpy.types.WindowManager, _TOGGLE_POINTER_ATTR)
    except Exception:
        pass
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    pg_cls = _TOGGLE_PROPERTY_GROUP_CLASS
    if pg_cls is None:
        try:
            existing_pg = getattr(bpy.types, 'SSSUITE_AlwaysOnToggleProperties', None)
            if isinstance(existing_pg, type):
                pg_cls = existing_pg
        except Exception:
            pg_cls = None
    if pg_cls is not None:
        try:
            bpy.utils.unregister_class(pg_cls)
        except Exception:
            pass
    _TOGGLE_PROPERTY_GROUP_CLASS = None
