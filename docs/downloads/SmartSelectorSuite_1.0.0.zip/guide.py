# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Static help catalog for the lightweight common help popup.

The richer N-panel Help operator uses help.py. This catalog is kept compact and
accurate so dynamically patched panel headers can display useful guidance without
scanning operator source code at runtime.
"""

from __future__ import annotations

from copy import deepcopy


def _setting(key: str, name_en: str, name_ja: str, desc_en: str, desc_ja: str) -> dict[str, str]:
    return {
        'key': key,
        'name_en': name_en,
        'name_ja': name_ja,
        'description_en': desc_en,
        'description_ja': desc_ja,
    }


def _operator(key: str, name_en: str, name_ja: str, desc_en: str, desc_ja: str) -> dict[str, str]:
    return _setting(key, name_en, name_ja, desc_en, desc_ja)


HELP_GROUPS: dict[str, dict[str, object]] = {
    'overview': {
        'title_en': 'Smart Selector Help',
        'title_ja': 'スマートセレクター ヘルプ',
        'overview_en': [
            'Smart Selector is a View3D N-panel toolset for browser-based selectors, project folders, persistent N-panel settings, bridge actions, Collection Manager, and GP Select.',
            'Generated settings, reports, runtime files, projects, and backups use CONFIG/Smart_Selector_Suite unless the Data Save Root Directory is manually set.',
        ],
        'overview_ja': [
            'スマートセレクターは、ブラウザー型セレクター、プロジェクトフォルダー、Nパネル永続設定、ブリッジ操作、コレクションマネージャー、GP セレクトを View3D のNパネルから扱うツールセットです。',
            '設定、レポート、実行時ファイル、プロジェクト、バックアップは、Data Save Root Directory を手動指定した場合を除き、CONFIG/Smart_Selector_Suite へ作成されます。',
        ],
        'usage_en': [
            'Use the panel from top to bottom: set Always-on Toggles, choose a project, create or open selector data, then use integrated tools or bridge actions only when required.',
            'When N-panel State Save is enabled, editable N-panel values are written immediately to Smart_Selector_Suite/Smart_Selector_Suite.json; when disabled, they are flushed when the current scene is closed or Save Preferences is executed.',
        ],
        'usage_ja': [
            'パネルは上から順に、常時起動切り替え、プロジェクト選択、セレクターデータ作成または起動、必要時の統合ツールまたはブリッジ操作、という流れで使います。',
            'Nパネルで編集できる値はすべて即時に永続設定へ保存され、Blender再起動後や別シーンを開いた後も復元されます。',
        ],
        'settings': [
            _setting('root_dir', 'Data Save Root Directory', 'データ保存ルートディレクトリ', 'Manual project root. Leave blank to use CONFIG/Smart_Selector_Suite/projects.', 'プロジェクト用の手動ルートです。空欄では CONFIG/Smart_Selector_Suite/projects を使います。'),
            _setting('active_project', 'Project', 'プロジェクト', 'Current project folder name used by selector JSON and image files.', 'セレクターJSONと画像ファイルで使う現在のプロジェクトフォルダー名です。'),
            _setting('show_favorites_only', 'Favorites Only', 'お気に入りのみ', 'Persistent list filter that shows only selectors marked with the favorite star.', 'お気に入りスターを付けたセレクターだけを表示する永続フィルターです。'),
        ],
        'operators': [
            _operator('create_selector', 'Create New Selector', '新規セレクター作成', 'Opens a new browser selector in edit mode.', '新しいブラウザー型セレクターを編集モードで開きます。'),
            _operator('save_preferences', 'Save Preferences', 'プリファレンスを保存', 'Saves current N-panel settings and requests Blender to save user preferences.', '現在のNパネル設定を保存し、Blenderのユーザープリファレンス保存も要求します。'),
        ],
    },
    'always_on_toggles': {
        'title_en': 'Always-on Toggles Help',
        'title_ja': '常時起動切り替え ヘルプ',
        'overview_en': ['This group controls features that may register handlers, timers, hotkeys, header widgets, menus, or browser bridge services.'],
        'overview_ja': ['このグループは、ハンドラー、タイマー、ホットキー、ヘッダーウィジェット、メニュー、ブラウザーブリッジサービスを登録する可能性がある機能を制御します。'],
        'usage_en': ['Enable only the background features you need. Disabled items are saved as disabled and are kept unloaded or unregistered whenever possible.'],
        'usage_ja': ['必要なバックグラウンド機能だけを有効にしてください。無効にした項目は無効状態として保存され、可能な限り未読み込みまたは登録解除状態に保たれます。'],
        'settings': [
            _setting('tool_collection_manager', 'Collection Manager', 'コレクションマネージャー', 'Allows the Collection Manager UI and commands to be loaded from the N-panel.', 'NパネルからコレクションマネージャーのUIとコマンドを読み込めるようにします。'),
            _setting('tool_gp_select', 'GP Select', 'GP セレクト', 'Allows GP Select tools to be loaded from the N-panel.', 'Nパネルから GP セレクトツールを読み込めるようにします。'),
            _setting('smart_selector_browser_server', 'Browser server', 'ブラウザーサーバー', 'Allows selector edit/play windows to start the local browser bridge server.', 'セレクター編集/再生ウィンドウ用のローカルブラウザーブリッジサーバー起動を許可します。'),
            _setting('smart_selector_state_cache_timer', 'Browser state-sync timer', 'ブラウザー状態同期タイマー', 'Synchronizes selection, object lists, collection lists, and watched values to the browser bridge.', '選択状態、オブジェクト一覧、コレクション一覧、監視値をブラウザーブリッジへ同期します。'),
        ],
        'operators': [],
    },
    'project': {
        'title_en': 'Project Help',
        'title_ja': 'プロジェクト ヘルプ',
        'overview_en': ['Projects are folders that separate selector JSON files and image data by job, character, scene, or shot.'],
        'overview_ja': ['プロジェクトは、セレクターJSONと画像データを案件、キャラクター、シーン、カットごとに分けるためのフォルダーです。'],
        'usage_en': ['Choose a project from the project list, then create or open selector files in that project. Use archive instead of delete when you want to keep old jobs recoverable.'],
        'usage_ja': ['プロジェクト一覧から使用するプロジェクトを選び、その中でセレクターファイルを作成または起動します。古い案件を復旧可能に残したい場合は削除ではなくアーカイブを使います。'],
        'settings': [
            _setting('active_project', 'Active Project', 'アクティブプロジェクト', 'The currently selected project folder. It is stored globally, not only in the current scene.', '現在選択中のプロジェクトフォルダーです。現在のシーンだけでなくグローバルに保存されます。'),
            _setting('show_archived_projects', 'Show Archived Projects', 'アーカイブ済みプロジェクトを表示', 'Shows archived project folders in the picker.', 'アーカイブ済みプロジェクトフォルダーを選択一覧に表示します。'),
            _setting('root_dir', 'Data Save Root Directory', 'データ保存ルートディレクトリ', 'Manual project storage root. Blank uses CONFIG/Smart_Selector_Suite.', 'プロジェクト保存用の手動ルートです。空欄では CONFIG/Smart_Selector_Suite を使います。'),
        ],
        'operators': [
            _operator('create_project', 'Create Project', 'プロジェクト作成', 'Creates a new project folder and switches to it.', '新しいプロジェクトフォルダーを作成し、そのプロジェクトへ切り替えます。'),
            _operator('rename_project', 'Rename Project', 'プロジェクト名変更', 'Renames the active project folder.', 'アクティブプロジェクトフォルダー名を変更します。'),
            _operator('duplicate_project', 'Duplicate Project', 'プロジェクト複製', 'Copies the active project to a new folder.', 'アクティブプロジェクトを新しいフォルダーへコピーします。'),
            _operator('archive_project', 'Archive Project', 'プロジェクトをアーカイブ', 'Moves the active project to the archive folder.', 'アクティブプロジェクトをアーカイブフォルダーへ移動します。'),
        ],
    },
    'selector_data': {
        'title_en': 'Selector Data List Help',
        'title_ja': 'セレクターデータ一覧 ヘルプ',
        'overview_en': ['Selector Data List shows selector JSON files in the active project and opens the browser selector UI in play or edit mode.'],
        'overview_ja': ['セレクターデータ一覧は、アクティブプロジェクト内のセレクターJSONを表示し、ブラウザー型セレクターUIを再生または編集モードで開きます。'],
        'usage_en': ['Use Create New Selector for a blank selector, the play button for normal use, and the edit button to change layout, targets, images, buttons, sliders, and actions.'],
        'usage_ja': ['空のセレクターは新規セレクター作成、通常使用は再生ボタン、レイアウト、対象、画像、ボタン、スライダー、アクションの変更は編集ボタンを使います。'],
        'settings': [
            _setting('favorite_selectors_json', 'Favorite Selectors', 'お気に入りセレクター', 'Internal map used by star buttons and the Favorites Only filter.', 'スターとお気に入りのみフィルターで使う内部マップです。'),
            _setting('max_backup_generations', 'Backup Generations', 'バックアップ世代数', 'Number of previous selector versions to keep when saving.', '保存時に保持する過去セレクターバージョン数です。'),
        ],
        'operators': [
            _operator('open_play', 'Open in Play Mode', '再生モードで開く', 'Opens the selected selector for normal operation.', '選択したセレクターを通常操作用に開きます。'),
            _operator('open_edit', 'Open in Edit Mode', '編集モードで開く', 'Opens the selected selector for editing.', '選択したセレクターを編集用に開きます。'),
            _operator('favorite_star', 'Favorite Star', 'お気に入りスター', 'Adds or removes a selector from the favorites list.', 'セレクターをお気に入りに追加または解除します。'),
        ],
    },
    'settings': {
        'title_en': 'Settings Help',
        'title_ja': '設定 ヘルプ',
        'overview_en': ['All editable settings are shown in the N-panel. Add-on Preferences properties are not used for configuration.'],
        'overview_ja': ['編集可能な設定はすべてNパネルに表示されます。設定用のアドオンプリファレンスプロパティは使用しません。'],
        'usage_en': ['Change values in the N-panel. With N-panel State Save enabled, changes are saved immediately; with it disabled, Save Preferences is the explicit flush point.'],
        'usage_ja': ['値はNパネルで変更します。「Nパネル状態保存」が有効な場合は即時保存され、無効な場合は「プリファレンスを保存」ボタンが明示的な保存反映として使えます。'],
        'settings': [
            _setting('state_update_interval', 'State Sync Interval (s)', '状態同期間隔（秒）', 'Controls browser bridge synchronization frequency.', 'ブラウザーブリッジの同期頻度を制御します。'),
            _setting('max_backup_generations', 'Backup Generations', 'バックアップ世代数', 'Controls selector backup retention.', 'セレクターバックアップの保持数を制御します。'),
            _setting('enable_exec_script', 'Allow Execute Script', 'スクリプト実行を許可', 'Allows trusted selector files to run Python scripts.', '信頼できるセレクターファイルから Python スクリプトを実行できるようにします。'),
        ],
        'operators': [_operator('save_preferences', 'Save Preferences', 'プリファレンスを保存', 'Saves N-panel state and requests Blender to save user preferences.', 'Nパネル状態保存を実行し、Blenderのユーザープリファレンス保存を要求します。')],
    },
    'bridge_actions': {
        'title_en': 'Bridge Actions Help',
        'title_ja': 'ブリッジ操作 ヘルプ',
        'overview_en': ['Bridge actions run internal Smart Selector payload operations from the N-panel for testing, diagnosis, or manual execution.'],
        'overview_ja': ['ブリッジ操作は、テスト、診断、手動実行のためにスマートセレクターの内部ペイロード処理をNパネルから実行します。'],
        'usage_en': ['Edit the JSON payload first, then press the matching action button. Use script execution only with trusted selector data.'],
        'usage_ja': ['先にJSONペイロードを編集し、対応する実行ボタンを押します。スクリプト実行は信頼できるセレクターデータに対してのみ使ってください。'],
        'settings': [
            _setting('bridge_selection_payload', 'Selection Payload', '選択ペイロード', 'JSON that describes object, collection, bone, or component selection.', 'オブジェクト、コレクション、ボーン、コンポーネント選択を記述するJSONです。'),
            _setting('bridge_shapekey_payload', 'Shape Key Payload', 'シェイプキーペイロード', 'JSON that contains target object, shape key, and value.', '対象オブジェクト、シェイプキー、値を含むJSONです。'),
            _setting('bridge_custom_prop_payload', 'Custom Property Payload', 'カスタムプロパティペイロード', 'JSON that contains target object, property path, and numeric value.', '対象オブジェクト、プロパティパス、数値を含むJSONです。'),
            _setting('bridge_exec_script_payload', 'Script Payload', 'スクリプトペイロード', 'JSON that contains a Python script string.', 'Python スクリプト文字列を含むJSONです。'),
        ],
        'operators': [
            _operator('apply_selection', 'Apply Selection', '選択を適用', 'Applies selection JSON to Blender.', '選択JSONをBlenderへ適用します。'),
            _operator('set_shapekey', 'Set Shape Key', 'シェイプキーを設定', 'Writes a value to the target Shape Key.', '対象シェイプキーへ値を書き込みます。'),
            _operator('set_custom_prop', 'Set Custom Property', 'カスタムプロパティを設定', 'Writes a numeric value to a custom property or data path.', 'カスタムプロパティまたはデータパスへ数値を書き込みます。'),
            _operator('execute_script', 'Execute Script', 'スクリプトを実行', 'Runs a trusted Python script when script execution is allowed.', 'スクリプト実行が許可されている場合に、信頼済み Python スクリプトを実行します。'),
        ],
    },
    'collection_manager': {
        'title_en': 'Collection Manager Help',
        'title_ja': 'コレクションマネージャー ヘルプ',
        'overview_en': ['Collection Manager manages collection visibility, selection, render, QCD slots, and collection operations from the Smart Selector N-panel.'],
        'overview_ja': ['コレクションマネージャーは、コレクションの表示、選択、レンダー、QCDスロット、コレクション操作をスマートセレクターのNパネルから管理します。'],
        'usage_en': ['Enable the tool in Always-on Toggles, load it when needed, then use the Collection Manager section for collection state and QCD workflows.'],
        'usage_ja': ['常時起動切り替えでツールを有効にし、必要時に読み込んでから、コレクションマネージャーセクションでコレクション状態とQCDワークフローを操作します。'],
        'settings': [
            _setting('cm_filter_name', 'Collection Filter', 'コレクションフィルター', 'Filters collection rows by name.', 'コレクション行を名前で絞り込みます。'),
            _setting('cm_show_exclude', 'Exclude Column', '除外列', 'Shows or hides the Exclude control column.', 'Exclude 制御列の表示を切り替えます。'),
            _setting('cm_show_render', 'Render Column', 'レンダー列', 'Shows or hides the render visibility column.', 'レンダー表示列の表示を切り替えます。'),
        ],
        'operators': [
            _operator('load_collection_manager', 'Load Collection Manager UI', 'コレクションマネージャーUIを読み込む', 'Registers and displays Collection Manager on demand.', '必要時にコレクションマネージャーを登録して表示します。'),
            _operator('qcd_slots', 'QCD Slots', 'QCDスロット', 'Uses numbered quick collection display slots.', '番号付きのクイックコレクション表示スロットを使います。'),
        ],
    },
    'gp_select': {
        'title_en': 'GP Select Help',
        'title_ja': 'GP セレクト ヘルプ',
        'overview_en': ['GP Select provides Grease Pencil selection, layer operations, opacity tools, pass-index tools, renaming, mask tools, and rigging helpers.'],
        'overview_ja': ['GP セレクトは、Grease Pencil の選択、レイヤー操作、不透明度ツール、Pass Index ツール、リネーム、マスクツール、リギング補助を提供します。'],
        'usage_en': ['Enable GP Select in Always-on Toggles, load the UI, then select compatible Grease Pencil objects, layers, strokes, or bones before running commands.'],
        'usage_ja': ['常時起動切り替えで GP セレクトを有効にし、UIを読み込んでから、対応する Grease Pencil オブジェクト、レイヤー、ストローク、ボーンを選択してコマンドを実行します。'],
        'settings': [
            _setting('gp_rename_str', 'Affixes', '付ける文字', 'Text used for prefix and suffix operations.', '接頭辞と接尾辞操作で使う文字列です。'),
            _setting('gp_full_name', 'Rename', 'Rename', 'Replacement name for selected layers.', '選択レイヤーを置き換える名前です。'),
            _setting('gp_target_pass_index', 'Pass Index', 'Pass Index', 'Pass Index value applied by GP tools.', 'GP ツールで適用する Pass Index 値です。'),
            _setting('gp_target_sensitivity', 'Sensitivity', '感度', 'Driver sensitivity used by rigging helpers.', 'リギング補助で使うドライバー感度です。'),
        ],
        'operators': [
            _operator('load_gp_select', 'Load GP Select UI', 'GP セレクトUIを読み込む', 'Registers and displays GP Select on demand.', '必要時に GP セレクトを登録して表示します。'),
            _operator('weight_selected', 'Weight Selected', '選択部位をウェイト化', 'Prepares selected strokes for weight workflows.', '選択ストロークをウェイトワークフロー用に準備します。'),
            _operator('mask_tools', 'Mask Tools', 'マスクツール', 'Applies, removes, inverts, and toggles Grease Pencil masks.', 'Grease Pencil マスクの適用、解除、反転、切り替えを行います。'),
        ],
    },
    'gp_select_renaming_pass': {
        'title_en': 'Renaming and Pass Index Help',
        'title_ja': 'リネームとPass Index ヘルプ',
        'overview_en': ['This GP Select subgroup edits Grease Pencil layer names and Pass Index values.'],
        'overview_ja': ['この GP セレクト内グループは、Grease Pencil レイヤー名と Pass Index 値を編集します。'],
        'usage_en': ['Select strokes or layers first, enter text or a Pass value, then run the matching rename or pass-index command.'],
        'usage_ja': ['先にストロークまたはレイヤーを選択し、文字列または Pass 値を入力してから、対応するリネームまたは Pass Index コマンドを実行します。'],
        'settings': [
            _setting('gp_rename_str', 'Affixes', '付ける文字', 'Text used for prefix and suffix operations.', '接頭辞と接尾辞操作で使う文字列です。'),
            _setting('gp_find_str', 'Find', '検索', 'Text to find in selected layer names.', '選択レイヤー名から検索する文字列です。'),
            _setting('gp_replace_str', 'Replace', '置換', 'Replacement text used by find-and-replace.', '検索文字列を置き換える文字列です。'),
            _setting('gp_target_pass_index', 'Pass', 'Pass', 'Numeric Pass Index value to apply.', '適用する数値の Pass Index です。'),
        ],
        'operators': [
            _operator('prefix_suffix', 'Prefix / Suffix', '接頭辞 / 接尾辞', 'Adds the Affixes text before or after selected layer names.', '「付ける文字」の文字列を選択レイヤー名の前後へ追加します。'),
            _operator('replace_name', 'Replace', '置換', 'Replaces matching text in selected layer names.', '選択レイヤー名内の一致文字列を置き換えます。'),
            _operator('apply_pass', 'Apply Pass Index', 'Pass Index適用', 'Applies the Pass value to selected layers or materials.', '選択レイヤーまたはマテリアルへ Pass 値を適用します。'),
        ],
    },
    'gp_select_rigging': {
        'title_en': 'Rigging Tools Help',
        'title_ja': 'リギングツール ヘルプ',
        'overview_en': ['Rigging Tools creates and maintains Grease Pencil time-offset driver setups.'],
        'overview_ja': ['リギングツールは、Grease Pencil 用の Time Offset ドライバーセットアップを作成・管理します。'],
        'usage_en': ['Select the relevant layers, bones, or setup targets, set Sensitivity if needed, then run a creation or maintenance command.'],
        'usage_ja': ['対象レイヤー、ボーン、セットアップ対象を選択し、必要に応じて感度を設定してから、作成または管理コマンドを実行します。'],
        'settings': [_setting('gp_target_sensitivity', 'Sensitivity', '感度', 'Controls the strength of time-offset driver response.', 'Time Offset ドライバー反応の強さを制御します。')],
        'operators': [
            _operator('create_layer_time_con', 'Create Layer Time Controller', 'レイヤー Time Controller 作成', 'Creates a layer-based time-offset controller setup.', 'レイヤーベースの Time Offset コントローラーセットアップを作成します。'),
            _operator('remove_setup', 'Remove Setup', 'セットアップ削除', 'Removes the generated rigging setup from the selected target.', '選択対象から生成済みリギングセットアップを削除します。'),
            _operator('apply_sensitivity', 'Apply Sensitivity', '感度を適用', 'Applies Sensitivity to existing drivers.', '既存ドライバーへ感度を適用します。'),
        ],
    },
}

# Topic aliases used by panel class names and subgroup help buttons.
_ALIASES = {
    'smart_selector': 'overview',
    'settings_performance': 'settings',
    'settings_project_list': 'project',
    'bridge_undo_redo': 'bridge_actions',
    'bridge_selection': 'bridge_actions',
    'bridge_shapekey': 'bridge_actions',
    'bridge_custom_prop': 'bridge_actions',
    'bridge_script': 'bridge_actions',
    'sssuite_pt_main': 'overview',
    'sssuite_pt_root': 'overview',
    'sssuite_pt_settings': 'settings',
    'sssuite_pt_project': 'project',
    'sssuite_pt_selector': 'selector_data',
    'sssuite_pt_collection_manager': 'collection_manager',
    'sssuite_pt_gp_select': 'gp_select',
}


def _normalize_topic(topic: object) -> str:
    value = str(topic or 'overview').strip()
    key = value.lower().replace(' ', '_')
    if key in HELP_GROUPS:
        return key
    if key in _ALIASES:
        return _ALIASES[key]
    if 'always' in key or 'toggle' in key:
        return 'always_on_toggles'
    if 'collection' in key or 'qcd' in key:
        return 'collection_manager'
    if 'gp' in key or 'grease' in key or 'renam' in key or 'rig' in key:
        if 'rig' in key:
            return 'gp_select_rigging'
        if 'rename' in key or 'pass' in key:
            return 'gp_select_renaming_pass'
        return 'gp_select'
    if 'project' in key:
        return 'project'
    if 'selector' in key or 'data' in key:
        return 'selector_data'
    if 'bridge' in key or 'payload' in key or 'script' in key or 'shape' in key or 'custom' in key:
        return 'bridge_actions'
    if 'setting' in key or 'preference' in key:
        return 'settings'
    return 'overview'


def get_group(topic: object = 'overview') -> dict[str, object]:
    key = _normalize_topic(topic)
    return deepcopy(HELP_GROUPS.get(key, HELP_GROUPS['overview']))
