# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Any
import textwrap

import bpy

from . import settings as _sssuite_settings
from . import loader as loader, registry as registry
from .translation import (
    is_japanese_locale as _i18n_is_japanese_locale,
    localize_class as _i18n_localize_class,
    t as _i18n_text,
)

_REGISTERED_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_ICONS_RUNTIME_MODULE = None
_RECORD_CACHE_DIRTY = True


def _icons_runtime():
    global _ICONS_RUNTIME_MODULE
    if _ICONS_RUNTIME_MODULE is None:
        try:
            from . import icons as _module
        except Exception:
            _module = None
        _ICONS_RUNTIME_MODULE = _module
    return _ICONS_RUNTIME_MODULE


def _icon_kwargs(name: str, fallback: str = 'NONE') -> dict:
    runtime = _icons_runtime()
    if runtime is not None:
        try:
            return dict(runtime.kwargs(str(name or '').strip(), fallback))
        except Exception:
            pass
    return {'icon': fallback}


class _SSS_DummyUIOperator:
    def __setattr__(self, _name, _value):
        return None
    def __getattr__(self, _name):
        return ''


def _safe_icon_string(icon: str, fallback: str = 'NONE') -> str:
    value = str(icon or fallback or 'NONE').strip() or 'NONE'
    return value if value.upper() != 'NONE' else 'NONE'


def _label_with_icon(layout, text: str, icon_name: str, fallback: str = 'NONE') -> None:
    label = str(text or '')
    try:
        layout.label(text=label, **_icon_kwargs(icon_name, fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon=_safe_icon_string(fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon='NONE')
    except Exception:
        pass


def _operator_with_icon(layout, operator_id: str, *, text: str = '', icon_name: str = '', fallback: str = 'NONE', **kwargs):
    label = str(text or '')
    call_kwargs = dict(kwargs)
    has_icon = bool(str(icon_name or '').strip()) or str(fallback or '').strip().upper() not in {'', 'NONE'}
    if label == '' and has_icon and call_kwargs.get('emboss') is False:
        call_kwargs.pop('emboss', None)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    icon_kwargs = {'icon_value': explicit_icon_value} if explicit_icon_value > 0 else _icon_kwargs(icon_name, fallback)
    try:
        return layout.operator(operator_id, text=label, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon_value', None)
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon=_safe_icon_string(fallback), **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon='NONE', **call_kwargs)
    except Exception:
        try:
            layout.label(text=label if label else '', icon='ERROR')
        except Exception:
            pass
        return _SSS_DummyUIOperator()


def _section_icon_name(icon: str, label: str = '') -> str:
    key = str(icon or '').strip()
    mapping = {
        'OUTLINER_COLLECTION': 'collection',
        'GREASEPENCIL': 'gp_select',
        'MENU_PANEL': 'menu',
        'TOOL_SETTINGS': 'settings',
        'PRESET': 'selector_list',
        'QUESTION': 'help',
        'TIME': 'clock',
    }
    if key in mapping:
        return mapping[key]
    text = str(label or '').lower()
    if 'collection' in text or 'コレクション' in text:
        return 'collection'
    if 'gp' in text or 'grease' in text or 'セレクト' in text:
        return 'gp_select'
    if 'menu' in text or 'メニュー' in text:
        return 'menu'
    return 'settings'


def _ui_section_setting_key(section_key: str) -> str:
    key = str(section_key or '').strip()
    if not key:
        return ''
    if key.startswith('show_') or key.startswith('ui_show_'):
        return key
    clean = ''.join(ch.lower() if ch.isalnum() else '_' for ch in key).strip('_')
    return f'ui_show_{clean}' if clean else ''


def _ui_section_state_get(section_key: str, default: bool = False) -> bool:
    key = _ui_section_setting_key(section_key)
    if not key:
        return bool(default)
    try:
        return bool(_sssuite_settings.get_value(key, bool(default)))
    except Exception:
        return bool(default)


def _assign_toggle_props(op, section_key: str, label: str, default: bool = False) -> None:
    try:
        op.section_key = str(section_key or '')
        op.label = str(label or '')
        op.default_state = bool(default)
    except Exception:
        pass


def _draw_group_help_button(row, topic_id: str) -> None:
    if not topic_id:
        return
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    try:
        help_row = row.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        help_row = row
    try:
        op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id or '')
    except TypeError:
        try:
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
            op.topic_id = str(topic_id or '')
        except Exception:
            pass
    except Exception:
        pass

def _collapsible_section_box(layout, *, section_key: str, label: str, icon: str = 'NONE', help_topic: str = '', default: bool = False):
    display = str(label or '')
    expanded = _ui_section_state_get(section_key, default)
    box = layout.box()
    box.use_property_split = False
    box.use_property_decorate = False
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    try:
        op = row.operator('smart_selector_suite.toggle_ui_section', text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True, depress=expanded)
        _assign_toggle_props(op, section_key, display, default)
    except Exception:
        row.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
    # Shared Smart Tools top-level section header: triangle, borderless
    # icon+title toggling the same section, then the small gap and the compact
    # embossed help (_draw_group_help_button adds the 0.35 gap and 0.82 row).
    title_op = _operator_with_icon(row, 'smart_selector_suite.toggle_ui_section', text=display, icon_name=_section_icon_name(icon, display), fallback=icon, emboss=False, depress=expanded)
    _assign_toggle_props(title_op, section_key, display, default)
    _draw_group_help_button(row, help_topic)
    if not expanded:
        return box, None
    body = box.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return box, body


def _child_panel_prop_name(section_key: str) -> str:
    key = _ui_section_setting_key(section_key)
    return key if key and key.startswith('ui_show_') else ''


def _child_panel_state_owner(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is None or not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
        return getattr(wm, 'smart_selector_suite_npanel_settings', None)
    except Exception:
        return None

def _child_collapsible_section_box(layout, *, section_key: str, label: str, help_topic: str = '', default: bool = False):
    """Draw a nested section only through Blender's native panel API."""
    display = str(label or '')
    prop_name = _child_panel_prop_name(section_key)
    state_owner = _child_panel_state_owner()
    header = None
    panel = None

    if state_owner is not None and prop_name and hasattr(state_owner, prop_name) and hasattr(layout, 'panel_prop'):
        try:
            header, panel = layout.panel_prop(state_owner, prop_name)
        except Exception:
            header = None
            panel = None

    if header is None:
        if not hasattr(layout, 'panel'):
            return layout, None
        panel_key = ''.join(ch if ch.isalnum() else '_' for ch in str(section_key or 'section'))
        try:
            header, panel = layout.panel(
                f'SSSUITE_CHILD_{panel_key}',
                default_closed=not bool(default),
            )
        except Exception:
            return layout, None

    header.use_property_split = False
    header.use_property_decorate = False
    try:
        header.label(text=display)
    except Exception:
        pass
    # 1.10.51: the ? help sits at the right end of the header (SmartTools common help spec 2026-10-17).
    try:
        help_lane = header.row(align=True)
        help_lane.alignment = 'RIGHT'
    except Exception:
        help_lane = header
    _draw_group_help_button(help_lane, help_topic)

    if panel is None:
        return header, None
    panel.use_property_split = False
    panel.use_property_decorate = False
    body = panel.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return header, body

def _is_japanese_locale() -> bool:
    return _i18n_is_japanese_locale()


def _lang_text(en: str, ja: str) -> str:
    return str(ja if _is_japanese_locale() else en)


def _safe_register_class(cls: type) -> None:
    try:
        existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
        if existing is cls:
            if cls not in _REGISTERED_CLASSES:
                _REGISTERED_CLASSES.append(cls)
            return
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    cls = _i18n_localize_class(cls)
    bpy.utils.register_class(cls)
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)


def _safe_unregister_registered_classes() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def mark_record_cache_dirty() -> None:
    global _RECORD_CACHE_DIRTY
    _RECORD_CACHE_DIRTY = True


def _collect_records() -> None:
    global _RECORD_CACHE_DIRTY
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '').strip()
        suite_key = str(spec.get('suite') or '').strip()
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)
    _RECORD_CACHE_DIRTY = False


def _collect_records_if_needed(*, force: bool = False) -> None:
    if force or _RECORD_CACHE_DIRTY or not _RECORDS_BY_ALIAS:
        _collect_records()


def _record(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if alias in _RECORDS_BY_ALIAS:
        return _RECORDS_BY_ALIAS[alias]
    _collect_records_if_needed()
    if alias in _RECORDS_BY_ALIAS:
        return _RECORDS_BY_ALIAS[alias]
    rec = loader.get_record(alias)
    if isinstance(rec, dict):
        _RECORDS_BY_ALIAS[alias] = rec
        return rec
    return None


def _spec_display_name(spec: dict, fallback: str = 'Integrated Add-on') -> str:
    spec = spec if isinstance(spec, dict) else {}
    en = str(spec.get('display_name') or fallback or '').strip()
    ja = str(spec.get('display_name_ja') or en or fallback or '').strip()
    return _lang_text(en, ja)


def _status_text(record: dict | None) -> str:
    if not isinstance(record, dict):
        return _lang_text('Not loaded', '未読み込み')
    status = str(record.get('status') or '')
    spec = record.get('spec') or {}
    if status == 'loaded':
        return _lang_text('Loaded', '読み込み済み')
    if status == 'standby':
        return _lang_text('Standby', '待機中')
    if status == 'loading':
        return _lang_text('Loading', '読み込み中')
    if status == 'unsupported_platform':
        return _lang_text('Unsupported platform', '現在の OS・CPU では無効')
    if status == 'failed':
        return _lang_text('Load failed', '読み込み失敗')
    if status == 'disabled':
        if str(spec.get('disabled_reason') or '') in {'always_on', 'preference'}:
            return _lang_text('Disabled in Always-on Toggles', '常時機能切り替えで無効')
        return _lang_text('Disabled', '無効')
    return status or _lang_text('Unknown', '不明')


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    for index, line in enumerate(lines):
        if index == 0:
            layout.label(text=line, icon=icon)
        else:
            layout.label(text=line)


def _menu_entries(record: dict | None) -> list[tuple[str, str, bool]]:
    items: list[tuple[str, str, bool]] = []
    seen: set[str] = set()
    if not isinstance(record, dict):
        return items
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _i18n_text(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip())
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        items.append((menu_id, label or menu_id, 'PIE' in upper))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict | None) -> list[tuple[str, str, str]]:
    items: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    if not isinstance(record, dict):
        return items
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = _i18n_text(str(getattr(cls, 'bl_label', '') or '').strip() or op_id)
        desc = _i18n_text(str(getattr(cls, 'bl_description', '') or '').strip())
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _operator_exists(op_id: str) -> bool:
    return callable(_resolve_operator_callable(op_id))


def _safe_button(layout, op_id: str, *, text: str, icon: str = 'NONE', icon_name: str = '') -> bool:
    if not _operator_exists(op_id):
        return False
    try:
        _operator_with_icon(layout, op_id, text=text, icon_name=icon_name or _section_icon_name(icon, text), fallback=icon)
        return True
    except Exception:
        return False


def _invoke_button(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False, icon: str | None = None, icon_name: str = '') -> None:
    icon = icon or ('PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS'))
    icon_name = icon_name or ('menu' if target_kind == 'menu' else _section_icon_name(icon, label))
    try:
        op = _operator_with_icon(layout, SSSUITE_OT_integrated_invoke.bl_idname, text=label, icon_name=icon_name, fallback=icon)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=label)


def _tool_is_available(record: dict | None) -> bool:
    if not isinstance(record, dict):
        return False
    status = str(record.get('status') or '')
    return status not in {'disabled', 'unsupported_platform'}


def _disabled_tool_message(record: dict | None) -> str:
    if not isinstance(record, dict):
        return _lang_text('Runtime information is unavailable.', '実行時情報を取得できません。')
    status = str(record.get('status') or '')
    if status == 'disabled':
        return _lang_text('This tool is disabled in Always-on Toggles.', 'このツールは常時機能切り替えで無効になっています。')
    if status == 'unsupported_platform':
        return _lang_text('This tool is not supported on the current platform.', 'このツールは現在の環境ではサポートされていません。')
    return _status_text(record)


def _draw_tool_list(layout, record: dict | None, *, compact: bool = False) -> None:
    if not isinstance(record, dict):
        layout.label(text=_lang_text('Runtime information is unavailable.', '実行時情報を取得できません。'), icon='ERROR')
        return
    spec = record.get('spec') or {}
    alias = str(spec.get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(text=_lang_text('No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。'), icon='NONE')
        return
    if menus:
        box = layout.box()
        _label_with_icon(box, _lang_text('Menus', 'メニュー'), 'menu', 'MENU_PANEL')
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_button(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)
    if operators:
        box = layout.box()
        _label_with_icon(box, _lang_text('Operators', 'オペレーター'), 'settings', 'TOOL_SETTINGS')
        flow = box.grid_flow(row_major=True, columns=1 if compact else 2, even_columns=True, even_rows=False, align=True)
        for op_id, label, desc in operators:
            _invoke_button(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)


def _addon_help(spec: dict) -> str:
    spec = spec if isinstance(spec, dict) else {}
    if _is_japanese_locale():
        overview = str(spec.get('overview_ja') or '').strip()
        usage = str(spec.get('usage_ja') or '').strip()
        name = _spec_display_name(spec, 'Integrated Add-on')
        body = overview or f'{name} の機能を通常の 3Dビュー Nパネル内に配置しています。'
        tail = usage or 'Nパネル内の各ボタン、または元の標準パネルから必要な機能を実行してください。'
        return f'機能: {body} 使い方: {tail}'
    overview = str(spec.get('overview_en') or '').strip()
    usage = str(spec.get('usage_en') or '').strip()
    name = _spec_display_name(spec, 'Integrated Add-on')
    body = overview or f'{name} is available as a standard 3D View Sidebar panel.'
    tail = usage or 'Use the buttons in the N-panel or the native panels registered by the tool.'
    return f'Function: {body}. How to use: {tail}'


def _target_help(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or _lang_text('Tool Command', 'ツールコマンド')
    desc = str(desc or '').strip()
    if _is_japanese_locale():
        if kind == 'menu':
            menu_kind = 'パイメニュー' if is_pie else 'メニュー'
            return f'機能: {label} {menu_kind} を開きます。使い方: このボタンを押し、表示された項目から目的の機能を選びます。'
        body = desc or label
        return f'機能: {body}。使い方: このボタンを押すと対応するコマンドを実行します。選択状態やモードが必要な場合があります。'
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return f'Function: opens the {label} {menu_kind}. How to use: click this button, then choose a command from the opened menu.'
    body = desc or label
    return f'Function: {body}. How to use: click this button to run the command. Some tools require a valid selection or mode.'


def _ensure_loaded(alias: str) -> dict[str, Any] | None:
    record = _record(alias)
    if isinstance(record, dict) and str(record.get('status') or '') == 'loaded':
        return record
    try:
        record = loader.ensure_record_loaded(alias)
        _collect_records()
        return record if isinstance(record, dict) else None
    except Exception:
        return record if isinstance(record, dict) else None


def suite_is_active(context, suite_key: str) -> bool:
    del context
    suite_key = str(suite_key or '').strip()
    if suite_key not in registry.SUITE_META:
        return False
    return True


def suite_panel_context(suite_key: str) -> str:
    del suite_key
    return 'n_panel'


def refresh_all_suites(context=None) -> None:
    del context
    # Runtime refresh is an explicit event path, so RNA repair is safe here and
    # never occurs from a Panel draw callback.
    _ensure_integrated_operator_classes_registered()
    _collect_records_if_needed(force=True)
    try:
        supported = {
            'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR',
            'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR',
            'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET',
        }
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in supported:
                    area.tag_redraw()
    except Exception:
        pass


def _refresh_runtime_records(context=None) -> None:
    refresh_all_suites(context)


def runtime_needs_refresh() -> bool:
    return not _integrated_operator_classes_registered()


def schedule_runtime_ui_rebuild() -> None:
    # A standard N-panel add-on must not unregister/register Panel classes from
    # a redraw-triggered timer.  Just refresh cached records and tag redraw.
    refresh_all_suites(getattr(bpy, 'context', None))


class SSSUITE_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.integrated_addon_info'
    bl_label = 'Integrated Add-on Info'
    bl_options = {'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _record(alias)
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        return ' '.join((_spec_display_name(spec, alias), _addon_help(spec), _status_text(record)))

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = _record(alias)
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        self.report({'INFO'}, f'{_spec_display_name(spec, alias)} - {_status_text(record)}')
        return {'FINISHED'}


class SSSUITE_OT_integrated_load_tool(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.integrated_load_tool'
    bl_label = 'Load Tool UI'
    bl_options = {'UNDO', 'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Target Label parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, _context, properties):
        label = str(getattr(properties, 'target_label', '') or '').strip() or _lang_text('Tool', 'ツール')
        if _is_japanese_locale():
            return f'機能: {label} のUIとコマンドを必要な時だけ読み込みます。使い方: このボタンを押すと対象ツールだけを遅延読み込みし、スマートセレクターパネル内にコマンドを表示します。設定は常時機能切り替えで無効にできます。'
        return f'Function: loads the {label} UI and commands only when needed. How to use: click this button to lazy-load this tool and show its commands inside the single Smart Selector panel. Availability can be disabled from Always-on Toggles.'

    def execute(self, context):
        alias = str(self.addon_alias or '').strip()
        if not alias:
            self.report({'WARNING'}, _lang_text('No integrated tool was selected.', '統合ツールが選択されていません。'))
            return {'CANCELLED'}
        record = _ensure_loaded(alias)
        if not isinstance(record, dict) or str(record.get('status') or '') != 'loaded':
            excerpt = _trace_excerpt((record or {}).get('error', '') if isinstance(record, dict) else '')
            if excerpt:
                self.report({'ERROR'}, _lang_text(f'Tool load failed: {excerpt}', f'ツール読込に失敗しました: {excerpt}'))
            else:
                self.report({'ERROR'}, _lang_text(f'Tool load failed: {alias}', f'ツール読込に失敗しました: {alias}'))
            return {'CANCELLED'}
        _refresh_runtime_records(context)
        self.report({'INFO'}, _lang_text('Tool UI loaded.', 'ツールUIを読み込みました。'))
        return {'FINISHED'}


class SSSUITE_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.integrated_invoke'
    bl_label = 'Tool Command'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Addon Alias parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Target Kind parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Target ID parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Target Label parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Target Desc parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'}, description='Function: supplies the Is Pie Menu parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, _context, properties):
        return _target_help(
            str(getattr(properties, 'target_kind', '') or ''),
            str(getattr(properties, 'target_label', '') or ''),
            str(getattr(properties, 'target_desc', '') or ''),
            is_pie=bool(getattr(properties, 'is_pie_menu', False)),
        )

    def execute(self, _context):
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        addon_alias = str(self.addon_alias or '').strip()
        if not target_id:
            self.report({'WARNING'}, _lang_text('No tool command was selected.', 'ツールコマンドが選択されていません。'))
            return {'CANCELLED'}
        if addon_alias:
            record = _ensure_loaded(addon_alias)
            if not isinstance(record, dict) or str(record.get('status') or '') != 'loaded':
                excerpt = _trace_excerpt((record or {}).get('error', '') if isinstance(record, dict) else '')
                if excerpt:
                    self.report({'ERROR'}, _lang_text(f'Runtime enable failed: {excerpt}', f'実行時有効化に失敗しました: {excerpt}'))
                else:
                    self.report({'ERROR'}, _lang_text(f'Runtime enable failed: {addon_alias}', f'実行時有効化に失敗しました: {addon_alias}'))
                return {'CANCELLED'}
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _lang_text(f'Could not open "{self.target_label}".', f'「{self.target_label}」を開けませんでした。'))
                return {'CANCELLED'}
        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _lang_text(f'"{self.target_label}" was not found.', f'「{self.target_label}」が見つかりません。'))
            return {'CANCELLED'}
        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = op_callable(*args)
                return result if isinstance(result, set) else {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _lang_text(f'Could not run "{self.target_label}".', f'「{self.target_label}」を実行できませんでした。'))
        return {'CANCELLED'}


def _section_box(layout, label: str, icon: str, help_topic: str = ''):
    # Compatibility helper kept for any older internal callers. New N-panel
    # sections use _collapsible_section_box() so every top-level group can close.
    box = layout.box()
    row = box.row(align=True)
    _label_with_icon(row, str(label or ''), _section_icon_name(icon, label), icon)
    if help_topic:
        try:
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
        except Exception:
            help_row = row
        try:
            op = _operator_with_icon(help_row, 'smart_selector_suite.show_help', text='', icon_name='help', fallback='QUESTION')
            op.topic_id = str(help_topic or '')
        except Exception:
            pass
    return box


def _draw_record_header(layout, alias: str, record: dict | None) -> None:
    del alias
    row = layout.row(align=True)
    row.label(text=_status_text(record), icon='PLUGIN')


def _draw_load_error(layout, record: dict | None) -> None:
    if not isinstance(record, dict) or str(record.get('status') or '') != 'failed':
        return
    excerpt = _trace_excerpt(record.get('error', ''))
    if excerpt:
        warn = layout.box()
        warn.alert = True
        _wrap_lines(warn, _lang_text(f'Load error: {excerpt}', '読み込めませんでした。アドオンを入れ直してください。'), width=70, icon='ERROR')


def _draw_collection_manager_section(layout, context) -> None:
    del context
    record = _record('collection_manager')
    box, body = _collapsible_section_box(
        layout,
        section_key='collection_manager',
        label=_lang_text('Collection Manager', 'コレクションマネージャー'),
        icon='OUTLINER_COLLECTION',
        help_topic='collection_manager',
        default=False,
    )
    if body is None:
        return
    _draw_record_header(body, 'collection_manager', record)

    if _tool_is_available(record):
        _invoke_button(
            body,
            addon_alias='collection_manager',
            target_kind='operator',
            target_id='view3d.collection_manager',
            label=_lang_text('Open Collection Manager', 'コレクションマネージャーを開く'),
            desc=_lang_text('Open the Collection Manager popup after loading the tool if needed.', '必要な場合だけツールを読み込んでから、コレクションマネージャーのポップアップを開きます。'),
            icon='OUTLINER_COLLECTION',
            icon_name='collection',
        )
    else:
        body.label(text=_disabled_tool_message(record), icon='CANCEL')


    _draw_load_error(body, record)


def _draw_gp_select_section(layout, context) -> None:
    record = _record('gp_select')
    box, body = _collapsible_section_box(
        layout,
        section_key='gp_select',
        label=_lang_text('GP Select', 'GP セレクト'),
        icon='GREASEPENCIL',
        help_topic='gp_select',
        default=False,
    )
    if body is None:
        return
    _draw_record_header(body, 'gp_select', record)

    if not _tool_is_available(record):
        body.label(text=_disabled_tool_message(record), icon='CANCEL')
        _draw_load_error(body, record)
        return

    if not (isinstance(record, dict) and str(record.get('status') or '') == 'loaded'):
        op = _operator_with_icon(
            body,
            SSSUITE_OT_integrated_load_tool.bl_idname,
            text=_lang_text('Load GP Select UI', 'GP セレクトUIを読み込む'),
            icon_name='gp_select',
            fallback='GREASEPENCIL',
        )
        op.addon_alias = 'gp_select'
        op.target_label = _lang_text('GP Select', 'GP セレクト')
        _draw_load_error(body, record)
        return

    module = record.get('module') if isinstance(record, dict) else None
    draw_func = getattr(module, 'draw_gp_select_into_layout', None)
    if callable(draw_func):
        try:
            draw_func(body, context)
            return
        except Exception as exc:
            err = body.box()
            err.alert = True
            err.label(text=_lang_text(f'GP Select UI draw failed: {exc}', 'GP セレクトを表示できませんでした。'), icon='ERROR')
            return
    _draw_tool_list(body, record, compact=True)


def _integrated_operator_class_registered(cls: type) -> bool:
    """Check local bookkeeping and Blender's RNA registration flag safely."""
    try:
        if cls not in _REGISTERED_CLASSES:
            return False
    except Exception:
        return False
    try:
        registered = getattr(cls, 'is_registered', None)
    except Exception:
        registered = None
    # Blender exposes Struct.is_registered for runtime classes. Keep the local
    # registry as a compatibility fallback when a host build omits that flag.
    return bool(registered) if isinstance(registered, bool) else True


def _integrated_operator_classes_registered() -> bool:
    try:
        return all(_integrated_operator_class_registered(cls) for cls in _CLASSES)
    except Exception:
        return False


def _ensure_integrated_operator_classes_registered() -> bool:
    if _integrated_operator_classes_registered():
        return True
    try:
        for cls in _CLASSES:
            if not _integrated_operator_class_registered(cls):
                _safe_register_class(cls)
    except Exception:
        return False
    return _integrated_operator_classes_registered()


def draw_integrated_sections(layout, context) -> None:
    # Never register RNA classes from a Panel draw callback. ui_runtime.register()
    # owns normal class registration; explicit runtime refresh can repair an
    # externally removed class outside Blender's draw stack.
    if not _integrated_operator_classes_registered():
        box = layout.box()
        box.label(text=_lang_text('Integrated tools are initializing.', '統合ツールを初期化中です。'), icon='TIME')
        return
    # Panel drawing must remain side-effect-light. Refresh cached records only;
    # do not tag redraw from inside draw().
    _collect_records_if_needed()
    _draw_collection_manager_section(layout, context)
    _draw_gp_select_section(layout, context)


def _purge_legacy_npanel_classes() -> None:
    for name in (
        'SSSUITE_PT_collection_manager',
        'SSSUITE_PT_collection_manager_commands',
        'SSSUITE_PT_gp_select_loader',
        'GP_PT_gp_select_panel',
        'GP_PT_renaming_subpanel',
        'GP_PT_rigging_subpanel',
    ):
        cls = getattr(bpy.types, name, None)
        if isinstance(cls, type):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass


_CLASSES = (
    SSSUITE_OT_integrated_addon_info,
    SSSUITE_OT_integrated_load_tool,
    SSSUITE_OT_integrated_invoke,
)


def register() -> None:
    _safe_unregister_registered_classes()
    _purge_legacy_npanel_classes()
    _collect_records_if_needed(force=True)
    for cls in _CLASSES:
        _safe_register_class(cls)


def unregister() -> None:
    _safe_unregister_registered_classes()
    _purge_legacy_npanel_classes()
