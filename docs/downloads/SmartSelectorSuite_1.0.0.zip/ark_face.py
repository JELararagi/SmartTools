# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Face ARKit section for the Smart Selector N-panel (1.10.49; layers 1.10.48).

What this module adds (design: ARKit 基準フェイシャルリグ設計 r3 §6, §8.3-8.6, §10.4):

* Layers (§8.6, 1.10.48): Biped-like animation layers on any armature (the active one, else the face rig).
  The base layer is the current action; each layer is an NLA track (one strip, one action, COMBINE, weight =
  animated influence).  action_blend_type is COMBINE while layers exist and REPLACE after the last one is
  removed.  Edit = NLA tweak mode; the base is shown under the edited layer through the muted-by-default
  guide track SS_BASE_VIEW (a depsgraph handler mutes it again when tweak mode ends elsewhere).  Collapse
  keys the evaluated property values (not visual) into the base and keeps the layers muted.  The face
  bake, restore and re-apply mute the layers while they run (§8.3-0).
* Redo to stage 2 sets the views to Solid again (1.10.48, O1).

* Light display (§10.4), in two stages:
  - Stage 1 (1.10.46 behaviour): turns off ``show_viewport`` of every SUBSURF / MULTIRES modifier that
    is not the last one of its stack, on every mesh.
  - Stage 2 "animator view" (1.10.47, GUI_30fps round 2): stage 1, plus the last enabled SUBSURF of
    each stack (viewport only), plus ``hide_set(True)`` on the small props (a name-fragment rule kept
    in the scene settings; default = the 34 props measured on MIK_192), plus SOLID shading in the
    3D views of the open windows that were MATERIAL / RENDERED.
  The pair ``MIK_geo_faceA`` + ``JEL_nor_faceA`` (``JEL_geo_faceA.002`` before 1.10.63) is switched together; the "smooth face" option
  keeps that pair on in both stages.  Every switched modifier is stored on its object as
  ``ark_light_saved`` (JSON list of modifier names), the same format the rig's own Text
  ``ARK_facial_tools.py`` uses, so both sides can restore it; the stage-2 extras are also listed in
  ``ark_light_s2``.  Hidden props carry ``ark_light_hidden`` (scene / view layer), changed views carry
  ``ark_light_shading`` on their Screen (area, space, original type).  Only what was switched is put
  back.  ``show_render``, levels, modifier order and hide_render / hide_viewport are never written and
  are checked after every switch.
* Save guard (1.10.47): a ``save_pre`` handler puts the light display back before the file is written
  and ``save_post`` re-applies the same stage afterwards, so a file is never saved with it on.
  Blender's auto-save and quit.blend do not run save_pre: those files keep it (load_post says so).
  Screen records (outside Undo, kept by File > Open without Load UI) count only while the scene data
  says the display is on; stale ones are put back by undo_post / redo_post / load_post / save_pre.
  Disabling the add-on releases the display.
* Cancelled bake (Esc): F-curves come back from the backup and the pre-bake pose / ark_hand_* values
  are written back, then the frame is evaluated again (1.10.47, fork23 review E1).
* The "顔 ARKit" page: the 52 ``cc_arkit_*`` values, 2D pads that write 2-4 sliders at once (no new
  bones), expression / hand-key mode display, zero / default / flip-paste, the five ``ark_hand_*``
  helpers and the four hand-over notes.
* Bake / restore / re-apply buttons.  They call the functions of the rig file's Texts
  ``ARK_facial_tools.py`` and ``ark_reapply.py``; nothing of their logic is duplicated here.
* Curve clean-up buttons that call existing Blender operators only (§8.4).

No bone is added, no mesh is reshaped, and ``srs.hygiene_clamp_face`` is never called.
"""

from __future__ import annotations

import json
import os
import sys
import time

import bpy
from .translation import exception_text
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.app.handlers import persistent
from bpy.types import Operator, PropertyGroup

TOOLS_TEXT = 'ARK_facial_tools.py'
LAYOUT_TEXT = 'ARK_board_layout.json'
REAPPLY_TEXT = 'ark_reapply.py'
REAPPLY_SPEC_TEXT = 'ark_reapply_spec.json'
BOARD_BONE = 'cc_arkit_board'
SLIDER_PREFIX = 'cc_arkit_'
NOSE_PREFIX = 'cc_nose_sneer'
ARK_CONSTRAINT_PREFIX = 'ARK '
LIGHT_KEY = 'ark_light_saved'
# 1.10.63: the face normal source was renamed JEL_nor_faceA (v1.1.1 delivery); the old name stays for older files.
LIGHT_PAIR = ('MIK_geo_faceA', 'JEL_nor_faceA', 'JEL_geo_faceA.002')
LIGHT_TYPES = ('SUBSURF', 'MULTIRES')
# 1.10.47 stage 2 ("animator view")
LIGHT_S2_KEY = 'ark_light_s2'            # object: JSON list of the stage-2 extra modifier names
LIGHT_HIDDEN_KEY = 'ark_light_hidden'    # object: JSON list of [scene name, view layer name] it was hidden in
LIGHT_SHADING_KEY = 'ark_light_shading'  # screen: JSON list of [area index, space index, original shading type]
# scene: set while stage 2 has views switched.  Screens are UI data: Undo does not restore them and
# File > Open without "Load UI" keeps them, so a Screen record only counts while the scene data (object
# records or this marker, both undoable and per file) says the light display is on (1.10.47 review fix).
LIGHT_SCENE_KEY = 'ark_light_on'
LIGHT_S2_TYPES = ('SUBSURF',)
LIGHT_SOLID_FROM = ('MATERIAL', 'RENDERED')
PROP_OVERRIDE_KEY = 'ark_light_prop'     # object: 1 = always a small prop, 0 = never (overrides the name rule)
# Name fragments of the small props hidden in stage 2.  On MIK_192 this matches exactly the 34 props of
# GUI_30fps round 2 (12 named + 22 hair metal parts).  Editable per scene in the panel.
DEFAULT_PROP_RULE = 'pierceA_, neck_acc, arm_acc, headsetA, bodyA_ring, bodyA_nail, outerA_zip, shoesA_zip, outerA_belt, metal'
HAND_PROPS = ('ark_hand_lips_retain', 'ark_hand_aux_mouthFunnel', 'ark_hand_aux_mouthPucker',
              'ark_hand_aux_mouthPressLeft', 'ark_hand_aux_mouthPressRight')
PUCKER_PROP = 'ark_hand_aux_mouthPucker'
LIPS_RETAIN_PROP = 'ark_hand_lips_retain'
LIPS_BONE = 'c_jawbone.x'
LIPS_BONE_PROP = 'lips_retain'
PAD_SLOTS = 8
WM_PROP = 'smart_selector_suite_ark_face'

# Fallback copy of the rig file's Text ARK_board_layout.json (MIK_192).  Used only when the Text is
# missing or unreadable; the Text always wins.
_FALLBACK_SLIDERS = (
    ('browOuterUpRight', 0, -3, False), ('browDownRight', 0, -2, False), ('browInnerUp', 0, 0, False),
    ('browDownLeft', 0, 2, False), ('browOuterUpLeft', 0, 3, False),
    ('eyeLookDownRight', 1, -4, False), ('eyeLookUpRight', 1, -3, False), ('eyeLookOutRight', 1, -2, False),
    ('eyeLookInRight', 1, -1, False), ('eyeLookInLeft', 1, 1, False), ('eyeLookOutLeft', 1, 2, False),
    ('eyeLookUpLeft', 1, 3, False), ('eyeLookDownLeft', 1, 4, False),
    ('eyeWideRight', 2, -3, False), ('eyeSquintRight', 2, -2, False), ('eyeBlinkRight', 2, -1, False),
    ('eyeBlinkLeft', 2, 1, False), ('eyeSquintLeft', 2, 2, False), ('eyeWideLeft', 2, 3, False),
    ('cheekSquintRight', 3, -2, False), ('noseSneerRight', 3, -1, False), ('cheekPuff', 3, 0, False),
    ('noseSneerLeft', 3, 1, False), ('cheekSquintLeft', 3, 2, False),
    ('jawRight', 4, -2, False), ('jawForward', 4, -1, True), ('jawOpen', 4, 0, False),
    ('mouthClose', 4, 1, False), ('jawLeft', 4, 2, False),
    ('mouthFunnel', 5, -2, False), ('mouthRight', 5, -1, False), ('mouthPucker', 5, 0, False),
    ('mouthLeft', 5, 1, False),
    ('mouthFrownRight', 6, -2, False), ('mouthSmileRight', 6, -1, False), ('mouthSmileLeft', 6, 1, False),
    ('mouthFrownLeft', 6, 2, False),
    ('mouthDimpleRight', 7, -2, False), ('mouthStretchRight', 7, -1, False), ('mouthStretchLeft', 7, 1, False),
    ('mouthDimpleLeft', 7, 2, False),
    ('mouthLowerDownRight', 8, -3, False), ('mouthUpperUpRight', 8, -2, False), ('mouthPressRight', 8, -1, False),
    ('mouthPressLeft', 8, 1, False), ('mouthUpperUpLeft', 8, 2, False), ('mouthLowerDownLeft', 8, 3, False),
    ('mouthShrugUpper', 9, -2, False), ('mouthRollUpper', 9, -1, False), ('mouthRollLower', 9, 1, False),
    ('mouthShrugLower', 9, 2, False),
    ('tongueOut', 10, 0, False),
)
_FALLBACK_ROWS = ('眉', '視線', '瞼', '頬・鼻', '顎', '口 位置', '口角 上下', '口角 横', '唇 上下', '唇 ロール・すくめ', '舌')
_FALLBACK_PADS = (
    {'name': '視線 L', 'x': ['eyeLookInLeft', 'eyeLookOutLeft'], 'y': ['eyeLookDownLeft', 'eyeLookUpLeft']},
    {'name': '視線 R', 'x': ['eyeLookInRight', 'eyeLookOutRight'], 'y': ['eyeLookDownRight', 'eyeLookUpRight']},
    {'name': '視線 両目', 'x': [['eyeLookInLeft', 'eyeLookOutRight'], ['eyeLookOutLeft', 'eyeLookInRight']],
     'y': [['eyeLookDownLeft', 'eyeLookDownRight'], ['eyeLookUpLeft', 'eyeLookUpRight']]},
    {'name': '顎', 'x': ['jawRight', 'jawLeft'], 'y': [None, 'jawOpen']},
    {'name': '口の位置', 'x': ['mouthRight', 'mouthLeft'], 'y': ['mouthRollLower', 'mouthShrugLower']},
    {'name': '口角 L', 'x': ['mouthPucker', 'mouthStretchLeft'], 'y': ['mouthFrownLeft', 'mouthSmileLeft']},
    {'name': '口角 R', 'x': ['mouthPucker', 'mouthStretchRight'], 'y': ['mouthFrownRight', 'mouthSmileRight']},
)
_FALLBACK_MANUAL_ONLY = ('cheekPuff', 'tongueOut')
_FALLBACK_TONGUE_HINT = '顎を 0.3 以上開けてから（舌は手付け専用）'
# The rig's board layout names its rows, pads and hint in Japanese; English UI shows these instead.
_BOARD_LABELS_EN = {
    '眉': 'Brows', '視線': 'Gaze', '瞼': 'Eyelids', '頬・鼻': 'Cheeks / nose', '顎': 'Jaw', '口 位置': 'Mouth position',
    '口角 上下': 'Mouth corners up/down', '口角 横': 'Mouth corners sideways', '唇 上下': 'Lips up/down',
    '唇 ロール・すくめ': 'Lips roll / shrug', '舌': 'Tongue', '視線 L': 'Gaze L', '視線 R': 'Gaze R', '視線 両目': 'Gaze both eyes',
    '口の位置': 'Mouth position', '口角 L': 'Mouth corner L', '口角 R': 'Mouth corner R',
    _FALLBACK_TONGUE_HINT: 'Open the jaw 0.3 or more first (the tongue is hand-keyed only)',
}

# Internal test hook: when set to an int N, the N-th Esc check of a bake raises the cancel path
# exactly as a real Esc would.  Always None in normal use.
_TEST_CANCEL_AFTER = None
# Internal test hook (1.10.48 review fix 2, D1): when True, the face bake and 畳み込む do NOT mute the user's own NLA
# tracks -- the 1.10.48 F9CE49FA08B2 behaviour -- so the shape check and its rollback can be exercised.  Always None.
_TEST_NO_USER_MUTE = None

_LAYOUT_CACHE = {'key': None, 't': 0.0, 'data': None}
# The last report is shown only for the file and rig it was made for (owner = (filepath, rig session_uid)).
_LAST_REPORT = {'text': '', 'ok': True, 'owner': None}
# Rig-file Texts the user allowed to run in this session although Blender's Auto Run did not trust the
# file: {(filepath, text name, sha1 of the text)}.  Cleared on unregister; never saved.
_APPROVED_TEXTS = set()


def _is_ja() -> bool:
    try:
        prefs = bpy.context.preferences
        if prefs is not None and not bool(getattr(prefs.view, 'use_translate_interface', True)):
            return False
    except Exception:
        pass
    try:
        return str(bpy.app.translations.locale or '').lower().startswith('ja')
    except Exception:
        return False


def _t(en: str, ja: str) -> str:
    return ja if _is_ja() else en


def _board_label(name: str) -> str:
    return _t(_BOARD_LABELS_EN.get(name, name), name)


class ArkError(Exception):
    pass


class _ArkCancelled(Exception):
    pass


# ---------------------------------------------------------------------------------------------- data
def _fallback_layout() -> dict:
    return {
        'rig': 'rig',
        'sliders': [{'arkit': a, 'bone': SLIDER_PREFIX + a, 'row': r, 'col': c, 'live_after_bake': live}
                    for a, r, c, live in _FALLBACK_SLIDERS],
        'rows': list(_FALLBACK_ROWS),
        'pads': [dict(p) for p in _FALLBACK_PADS],
        'manual_only': list(_FALLBACK_MANUAL_ONLY),
        'tongue_hint': _FALLBACK_TONGUE_HINT,
        'collections': {'board': 'ARKit52', 'hand': 'ARKit52_hand'},
    }


def _normalise_layout(raw) -> dict:
    if not isinstance(raw, dict) or not isinstance(raw.get('sliders'), list) or not raw['sliders']:
        raise ValueError('no sliders')
    out = _fallback_layout()
    sliders = []
    for s in raw['sliders']:
        if not isinstance(s, dict) or not s.get('arkit'):
            continue
        a = str(s['arkit'])
        sliders.append({'arkit': a, 'bone': str(s.get('bone') or SLIDER_PREFIX + a),
                        'row': int(s.get('row', 0)), 'col': int(s.get('col', 0)),
                        'live_after_bake': bool(s.get('live_after_bake', False))})
    if not sliders:
        raise ValueError('no sliders')
    out['sliders'] = sorted(sliders, key=lambda s: (s['row'], s['col']))
    for key in ('rig', 'tongue_hint'):
        if isinstance(raw.get(key), str) and raw[key]:
            out[key] = raw[key]
    if isinstance(raw.get('rows'), list):
        out['rows'] = [str(x) for x in raw['rows']]
    if isinstance(raw.get('pads'), list):
        out['pads'] = [p for p in raw['pads'] if isinstance(p, dict) and 'x' in p and 'y' in p][:PAD_SLOTS]
    if isinstance(raw.get('manual_only'), list):
        out['manual_only'] = [str(x) for x in raw['manual_only']]
    if isinstance(raw.get('collections'), dict):
        out['collections'].update({k: str(v) for k, v in raw['collections'].items()})
    return out


def layout_data() -> dict:
    """The board layout: the rig file's Text when readable, otherwise the built-in copy (cached 2 s)."""
    try:
        text = bpy.data.texts.get(LAYOUT_TEXT)
    except Exception:
        text = None
    key = text.as_pointer() if text is not None else None
    now = time.monotonic()
    cache = _LAYOUT_CACHE
    if cache['data'] is not None and cache['key'] == key and now - cache['t'] < 2.0:
        return cache['data']
    data = None
    if text is not None:
        try:
            data = _normalise_layout(json.loads(text.as_string()))
            data['_source'] = 'text'
        except Exception:
            data = None
    if data is None:
        data = _fallback_layout()
        data['_source'] = 'builtin'
    cache.update(key=key, t=now, data=data)
    return data


def find_rig():
    """The armature that carries the ARKit board (``cc_arkit_board``), or None."""
    try:
        objects = bpy.data.objects
    except Exception:
        return None
    name = layout_data().get('rig') or 'rig'
    ob = objects.get(name)
    if ob is not None and ob.type == 'ARMATURE' and ob.pose is not None and ob.pose.bones.get(BOARD_BONE):
        return ob
    for ob in objects:
        if ob.type == 'ARMATURE' and ob.pose is not None and ob.pose.bones.get(BOARD_BONE):
            return ob
    return None


def is_expression_mode(rig) -> bool:
    try:
        return int(rig.get('ark_live', 1)) != 0
    except Exception:
        return True


def _suite_prefs():
    try:
        from . import utils as _utils
        return _utils.get_prefs()
    except Exception:
        return None


def _exec_script_allowed() -> bool:
    """The suite-wide 「Allow Execute Script」 setting (enable_exec_script), as the bridge uses it."""
    prefs = _suite_prefs()
    return not (prefs is not None and not bool(getattr(prefs, 'enable_exec_script', True)))


def _autoexec_trusted() -> bool:
    """Blender's own trust for this file: Auto Run Python Scripts on, the file not in the excluded
    paths, and nothing was blocked when the file was loaded."""
    try:
        if bool(getattr(bpy.app, 'autoexec_fail', False)):
            return False
        prefs = bpy.context.preferences
        if not bool(prefs.filepaths.use_scripts_auto_execute):
            return False
        path = os.path.normcase(os.path.abspath(bpy.data.filepath)) if bpy.data.filepath else ''
        if path:
            import fnmatch
            for item in prefs.autoexec_paths:
                raw = str(getattr(item, 'path', '') or '')
                if not raw:
                    continue
                pat = os.path.normcase(os.path.abspath(bpy.path.abspath(raw)))
                if getattr(item, 'use_glob', False):
                    if fnmatch.fnmatch(path, pat):
                        return False
                elif path.startswith(pat):
                    return False
        return True
    except Exception:
        return False


def _text_key(name: str):
    try:
        text = bpy.data.texts.get(name)
    except Exception:
        text = None
    if text is None:
        return None
    import hashlib
    digest = hashlib.sha1(text.as_string().encode('utf-8', 'surrogatepass')).hexdigest()
    return (bpy.data.filepath or '', name, digest)


def text_trusted(name: str) -> bool:
    """True when the rig file's Text may be executed without asking."""
    if not _exec_script_allowed():
        return False
    if _autoexec_trusted():
        return True
    key = _text_key(name)
    return key is not None and key in _APPROVED_TEXTS


def _approve_text(name: str) -> None:
    key = _text_key(name)
    if key is not None:
        _APPROVED_TEXTS.add(key)


def _untrusted_message(names) -> str:
    joined = ', '.join(names)
    return _t('This file is not trusted by Auto Run Python Scripts. Run the Python code of its Text "%s"? '
              'Press OK only if you trust this .blend.' % joined,
              'このファイルは Python の自動実行が許可されていません。中の Text「%s」の Python を実行しますか。'
              '信頼できる .blend の時だけ OK を押してください' % '」「'.join(names))


def _exec_text(name: str, module_name: str) -> dict:
    try:
        text = bpy.data.texts.get(name)
    except Exception:
        text = None
    if text is None:
        raise ArkError(_t('Text "%s" is not in this file' % name, 'このファイルに Text「%s」がありません' % name))
    if not _exec_script_allowed():
        raise ArkError(_t('Execute Script is disabled in Smart Selector N-panel Settings; Text "%s" was not run.' % name,
                          'スマートセレクターの設定で「スクリプト実行を許可」がオフなので、Text「%s」は実行しませんでした' % name))
    if not text_trusted(name):
        raise ArkError(_t('Text "%s" was not run: Auto Run Python Scripts does not trust this file. '
                          'Press the button in the N-panel "Face ARKit" once and confirm.' % name,
                          'Text「%s」は実行しませんでした：このファイルは Python の自動実行が許可されていません。'
                          'N パネルの「顔 ARKit」のボタンから一度押し、確認で OK を押してください' % name))
    ns = {'__name__': module_name}
    exec(compile(text.as_string(), name, 'exec'), ns)
    return ns


def load_tools() -> dict:
    ns = _exec_text(TOOLS_TEXT, 'ark_tools')
    missing = [f for f in ('ark_bake', 'ark_restore', 'ark_zero_expressions', 'ark_face_default', 'ark_state')
               if not callable(ns.get(f))]
    if missing:
        raise ArkError(_t('%s lacks: %s' % (TOOLS_TEXT, ', '.join(missing)),
                          '%s に関数がありません: %s' % (TOOLS_TEXT, ', '.join(missing))))
    return ns


def _has_text(name: str) -> bool:
    try:
        return bpy.data.texts.get(name) is not None
    except Exception:
        return False


def _report_owner():
    rig = find_rig()
    try:
        uid = int(rig.session_uid) if rig is not None else None
    except Exception:
        uid = None
    try:
        path = bpy.data.filepath or ''
    except Exception:
        path = ''
    return (path, uid)


def _set_report(text: str, ok: bool = True) -> None:
    _LAST_REPORT['text'] = str(text or '')
    _LAST_REPORT['ok'] = bool(ok)
    _LAST_REPORT['owner'] = _report_owner() if text else None


def last_report_text() -> str:
    """The last report, only when it belongs to the open file and its rig (not a previous file's)."""
    if not _LAST_REPORT['text']:
        return ''
    if _LAST_REPORT.get('owner') != _report_owner():
        return ''
    return _LAST_REPORT['text']


def _tag_redraw() -> None:
    try:
        for win in bpy.context.window_manager.windows:
            for area in win.screen.areas:
                if area.type in {'VIEW_3D', 'GRAPH_EDITOR', 'DOPESHEET_EDITOR'}:
                    area.tag_redraw()
    except Exception:
        pass


# ------------------------------------------------------------------------------------- light display
def _mesh_objects():
    try:
        return [ob for ob in bpy.data.objects if ob.type == 'MESH']
    except Exception:
        return []


def _has_key(idb, key: str) -> bool:
    try:
        return key in idb.keys()
    except Exception:
        return False


def _json_list(idb, key: str) -> list:
    try:
        raw = idb.get(key)
        return list(json.loads(raw) if isinstance(raw, str) else list(raw or []))
    except Exception:
        return []


def _shading_screens() -> list:
    try:
        return [sc for sc in bpy.data.screens if _has_key(sc, LIGHT_SHADING_KEY)]
    except Exception:
        return []


def _object_records() -> bool:
    for ob in _mesh_objects():
        if _has_key(ob, LIGHT_KEY) or _has_key(ob, LIGHT_S2_KEY) or _has_key(ob, LIGHT_HIDDEN_KEY):
            return True
    return False


def _scene_marked() -> bool:
    try:
        return any(_has_key(sc, LIGHT_SCENE_KEY) for sc in bpy.data.scenes)
    except Exception:
        return False


def _light_anchor() -> bool:
    """The scene data says the light display is on (object records or the scene marker)."""
    return _object_records() or _scene_marked()


def light_is_on() -> bool:
    if _object_records():
        return True
    return _scene_marked() and bool(_shading_screens())


def _light_saved_names(ob) -> list:
    return [str(n) for n in _json_list(ob, LIGHT_KEY)]


def light_status() -> dict:
    """What is switched now.  ``stage`` is 0 (off), 1 or 2 (stage-2 extras, hidden props or changed views present)."""
    objs = 0
    mods = 0
    s2_mods = 0
    hidden = 0
    pair_saved = False
    pair_present = False
    for ob in _mesh_objects():
        if ob.name in LIGHT_PAIR:
            pair_present = True
        has = _has_key(ob, LIGHT_KEY)
        if has:
            objs += 1
            mods += len(_light_saved_names(ob))
            if ob.name in LIGHT_PAIR:
                pair_saved = True
        if _has_key(ob, LIGHT_S2_KEY):
            s2_mods += len(_json_list(ob, LIGHT_S2_KEY))
            if ob.name in LIGHT_PAIR:
                pair_saved = True
        if _has_key(ob, LIGHT_HIDDEN_KEY):
            hidden += 1
    # A Screen record without the scene data behind it is stale (after Undo, or kept by File > Open
    # without Load UI): it does not make the display "on" (cleaned by the undo / load / save handlers).
    anchored = bool(objs or s2_mods or hidden) or _scene_marked()
    views = sum(len(_json_list(sc, LIGHT_SHADING_KEY)) for sc in _shading_screens()) if anchored else 0
    stage2 = bool(s2_mods or hidden or views)
    on = objs > 0 or stage2
    return {'on': on, 'objects': objs, 'modifiers': mods, 'stage': (2 if stage2 else 1) if on else 0,
            'stage2_modifiers': s2_mods, 'hidden': hidden, 'views': views,
            'face_smooth': bool(on and pair_present and not pair_saved)}


def _light_candidates(ob, face_smooth: bool) -> list:
    mods = list(ob.modifiers)
    if not mods:
        return []
    if face_smooth and ob.name in LIGHT_PAIR:
        return []
    last = mods[-1]
    return [m.name for m in mods if m.type in LIGHT_TYPES and m != last and m.show_viewport]


def _stage2_candidates(ob, face_smooth: bool, stage1: list) -> list:
    """Stage 2: the last modifier that is still enabled in the viewport after stage 1, when it is a SUBSURF
    (the 「最後の Subdivision」 of GUI_30fps round 2: 24 on MIK_192)."""
    if face_smooth and ob.name in LIGHT_PAIR:
        return []
    enabled = [m for m in ob.modifiers if m.show_viewport and m.name not in stage1]
    if enabled and enabled[-1].type in LIGHT_S2_TYPES:
        return [enabled[-1].name]
    return []


def prop_rule_fragments(rule) -> list:
    return [f.strip() for f in str(rule or '').replace('\n', ',').split(',') if f.strip()]


def light_prop_objects(rule=None) -> list:
    """Mesh objects treated as small props: ``ark_light_prop`` on the object decides first (1 yes, 0 no),
    otherwise any name fragment of the rule (case-sensitive) in the object name."""
    frags = prop_rule_fragments(DEFAULT_PROP_RULE if rule is None else rule)
    out = []
    for ob in _mesh_objects():
        if _has_key(ob, PROP_OVERRIDE_KEY):
            try:
                if bool(ob[PROP_OVERRIDE_KEY]):
                    out.append(ob)
            except Exception:
                pass
            continue
        if any(f in ob.name for f in frags):
            out.append(ob)
    return out


def _window_screens() -> list:
    """Screens shown in the open windows (the views the animator plays in)."""
    out = []
    try:
        for win in bpy.context.window_manager.windows:
            scr = win.screen
            if scr is not None and scr not in out:
                out.append(scr)
    except Exception:
        pass
    return out


def _modifier_snapshot() -> dict:
    snap = {}
    for ob in _mesh_objects():
        snap[ob.name] = ([(m.name, m.type, bool(m.show_render), getattr(m, 'levels', None), getattr(m, 'render_levels', None))
                          for m in ob.modifiers], bool(ob.hide_render), bool(ob.hide_viewport))
    return snap


def _view_layer_by_names(scene_name: str, layer_name: str):
    try:
        scene = bpy.data.scenes.get(scene_name)
        return scene.view_layers.get(layer_name) if scene is not None else None
    except Exception:
        return None


def _restore_screens(views: list, failed: list) -> None:
    """Put the shading recorded on the Screens back and drop the records (and the scene marker)."""
    for scr in _shading_screens():
        for rec in _json_list(scr, LIGHT_SHADING_KEY):
            try:
                space = scr.areas[int(rec[0])].spaces[int(rec[1])]
                # Put the original back only while the view is still the SOLID we set (a user change wins).
                if space.type == 'VIEW_3D' and space.shading.type == 'SOLID' and rec[2] in LIGHT_SOLID_FROM:
                    space.shading.type = rec[2]
                    views.append('%s / %d' % (scr.name, int(rec[0])))
            except Exception:
                pass
        try:
            del scr[LIGHT_SHADING_KEY]
        except Exception as exc:
            failed.append('%s: %s' % (scr.name, exc))
    try:
        for sc in bpy.data.scenes:
            if _has_key(sc, LIGHT_SCENE_KEY):
                del sc[LIGHT_SCENE_KEY]
    except Exception as exc:
        failed.append('scene: %s' % exc)


def _switch_views_solid(views: list, failed: list) -> None:
    """Stage 2: set the MATERIAL / RENDERED 3D views of the open windows to SOLID and record the original
    type on their Screen (``ark_light_shading``), the record the OFF switch puts back."""
    for scr in _window_screens():
        rec = []
        for ai, area in enumerate(scr.areas):
            if area.type != 'VIEW_3D':
                continue
            for si, space in enumerate(area.spaces):
                try:
                    if space.type == 'VIEW_3D' and space.shading.type in LIGHT_SOLID_FROM:
                        rec.append([ai, si, space.shading.type])
                        space.shading.type = 'SOLID'
                except Exception as exc:
                    failed.append('%s / view %d: %s' % (scr.name, ai, exc))
        if rec:
            try:
                scr[LIGHT_SHADING_KEY] = json.dumps(rec)
                views.extend('%s / %d' % (scr.name, r[0]) for r in rec)
            except Exception as exc:
                failed.append('%s: %s' % (scr.name, exc))


def resync_stage2_views() -> list:
    """After Redo (or Undo) lands on a state where stage 2 had switched the views (the undoable scene marker
    ``ark_light_on`` is back) while no Screen record exists -- Screens are outside Undo, so the earlier Undo
    put the views back to MATERIAL and dropped the record -- switch those views to SOLID again with a fresh
    record (1.10.48, review O1).  Does nothing when the marker is absent or a record already exists."""
    if not _scene_marked() or _shading_screens():
        return []
    views = []
    failed = []
    _switch_views_solid(views, failed)
    if failed:
        print('SmartSelector resync_stage2_views: %s' % '; '.join(failed[:3]))
    if views:
        _tag_redraw()
    return views


def clear_stale_light_records() -> list:
    """Screen records left without the scene data behind them -- after Undo of the switch (Screens are not
    part of Undo) or File > Open without Load UI (the old Screens are kept) -- are put back and dropped,
    so the header does not claim 「軽い表示 中」 and save_post does not re-apply a stage nobody chose."""
    if not _shading_screens() or _light_anchor():
        return []
    views = []
    failed = []
    _restore_screens(views, failed)
    if views or failed:
        _tag_redraw()
    return views


def light_set(on: bool, face_smooth: bool = False, stage: int = 1, hide_props: bool = True, prop_rule=None) -> dict:
    """Switch the light display (stage 1 or 2).  Returns a report with the switched names and a self-check."""
    clear_stale_light_records()
    before = _modifier_snapshot()
    switched = []
    stage2 = []
    hidden = []
    views = []
    failed = []
    stage = 2 if int(stage or 1) >= 2 else 1
    if on:
        if light_is_on():
            light_set(False)
            before = _modifier_snapshot()
        for ob in _mesh_objects():
            names = _light_candidates(ob, face_smooth)
            extra = _stage2_candidates(ob, face_smooth, names) if stage == 2 else []
            if not names and not extra:
                continue
            done = []
            for n in names + extra:
                try:
                    ob.modifiers[n].show_viewport = False
                    done.append(n)
                except Exception as exc:
                    failed.append('%s / %s: %s' % (ob.name, n, exc))
            if done:
                try:
                    ob[LIGHT_KEY] = json.dumps(sorted(done))
                    done_extra = [n for n in extra if n in done]
                    if done_extra:
                        ob[LIGHT_S2_KEY] = json.dumps(done_extra)
                except Exception as exc:
                    for n in done:
                        ob.modifiers[n].show_viewport = True
                    failed.append('%s: %s' % (ob.name, exc))
                    continue
                switched.extend('%s / %s' % (ob.name, n) for n in done)
                stage2.extend('%s / %s' % (ob.name, n) for n in done if n in extra)
        if stage == 2 and hide_props:
            try:
                scene = bpy.context.scene
                layer = bpy.context.view_layer
                where = [scene.name, layer.name]
            except Exception:
                scene = layer = None
                where = None
            if layer is not None:
                for ob in light_prop_objects(prop_rule):
                    try:
                        if not ob.visible_get(view_layer=layer) or ob.hide_get(view_layer=layer):
                            continue
                        ob.hide_set(True, view_layer=layer)
                        ob[LIGHT_HIDDEN_KEY] = json.dumps([where])
                        hidden.append(ob.name)
                    except Exception as exc:
                        failed.append('%s: %s' % (ob.name, exc))
        if stage == 2:
            _switch_views_solid(views, failed)
            if views:
                try:
                    bpy.context.scene[LIGHT_SCENE_KEY] = 2
                except Exception as exc:
                    failed.append('scene: %s' % exc)
    else:
        for ob in _mesh_objects():
            has = _has_key(ob, LIGHT_KEY)
            has2 = _has_key(ob, LIGHT_S2_KEY)
            if has or has2:
                names = list(dict.fromkeys(_light_saved_names(ob) + [str(n) for n in _json_list(ob, LIGHT_S2_KEY)]))
                for n in names:
                    m = ob.modifiers.get(n)
                    if m is None:
                        failed.append('%s / %s: %s' % (ob.name, n, _t('modifier is gone', '修飾子がありません')))
                        continue
                    try:
                        m.show_viewport = True
                        switched.append('%s / %s' % (ob.name, n))
                    except Exception as exc:
                        failed.append('%s / %s: %s' % (ob.name, n, exc))
                for key in (LIGHT_KEY, LIGHT_S2_KEY):
                    if _has_key(ob, key):
                        try:
                            del ob[key]
                        except Exception as exc:
                            failed.append('%s: %s' % (ob.name, exc))
            if _has_key(ob, LIGHT_HIDDEN_KEY):
                for where in _json_list(ob, LIGHT_HIDDEN_KEY):
                    try:
                        layer = _view_layer_by_names(str(where[0]), str(where[1]))
                        if layer is None:
                            continue
                        ob.hide_set(False, view_layer=layer)
                        hidden.append(ob.name)
                    except Exception as exc:
                        failed.append('%s: %s' % (ob.name, exc))
                try:
                    del ob[LIGHT_HIDDEN_KEY]
                except Exception as exc:
                    failed.append('%s: %s' % (ob.name, exc))
        _restore_screens(views, failed)
    after = _modifier_snapshot()
    # Self-check: show_render, levels, render_levels, modifier order, hide_render, hide_viewport untouched.
    changed_render = [name for name in before if before[name] != after.get(name)]
    status = light_status()
    if on:
        state_ok = status['on'] == bool(switched or hidden or views)
        if stage == 1:
            state_ok = state_ok and status['stage'] in (0, 1)
    else:
        state_ok = not status['on']
    _tag_redraw()
    return {'on': status['on'], 'stage': status['stage'], 'switched': switched, 'count': len(switched), 'failed': failed,
            'stage2': stage2, 'hidden': hidden, 'views': views,
            'render_unchanged': not changed_render, 'render_changed_objects': changed_render,
            'state_ok': bool(state_ok), 'face_smooth': status['face_smooth']}


def _status_params(st=None, props=None) -> dict:
    """The light_set() arguments that re-create the current light display."""
    st = st or light_status()
    if props is None:
        props = _props()
    return {'face_smooth': bool(st['face_smooth']), 'stage': 2 if st['stage'] == 2 else 1,
            'hide_props': bool(st['hidden']),
            'prop_rule': getattr(props, 'light_prop_rule', None) if props is not None else None}


def _props_params(props) -> dict:
    """The light_set() arguments chosen in the panel."""
    stage = 2 if str(getattr(props, 'light_stage', 'STAGE2')) == 'STAGE2' else 1
    return {'face_smooth': bool(getattr(props, 'face_smooth', False)), 'stage': stage,
            'hide_props': bool(getattr(props, 'light_hide_props', True)),
            'prop_rule': getattr(props, 'light_prop_rule', None) if props is not None else None}


class _LightOff:
    """Context helper: turn the light display (stage 1 or 2) off for a computation and put the same back afterwards."""

    def __init__(self):
        self.was = None

    def __enter__(self):
        st = light_status()
        self.was = _status_params(st) if st['on'] else None
        if self.was:
            light_set(False)
        return self

    def __exit__(self, *exc):
        if self.was:
            light_set(True, **self.was)
        return False


# Save guard: light display off while the file is written, the same stage back afterwards.
_SAVE_STASH = {'params': None, 'guides': []}


def _guides_mute_for_save() -> list:
    """1.10.48 review fix: a layer edit that shows the base has the guide track SS_BASE_VIEW unmuted.  Written like that, the
    file opened without SmartSelector (no watch) evaluates the base twice after Tab out of the edit (measured on a
    small rig: 1.0 -> 2.0).  Mute it for the write; save_post (or the load_post rescan) unmutes it again."""
    done = []
    for ob in bpy.data.objects:
        if not _has_key(ob, LAYER_GUIDE_KEY) or ob.animation_data is None:
            continue
        g = _guide_track(ob)
        if g is not None and not g.mute:
            g.mute = True
            done.append(ob.name)
    return done


def _guides_unmute_after_save(names) -> None:
    for name in names or ():
        ob = bpy.data.objects.get(name)
        if ob is None or ob.animation_data is None or not ob.animation_data.use_tweak_mode or not _has_key(ob, LAYER_GUIDE_KEY):
            continue
        g = _guide_track(ob)
        if g is not None and len(g.strips):
            g.mute = False
            try:
                ob.update_tag(refresh={'TIME'})
            except Exception:
                pass


@persistent
def ark_light_save_pre(*_args):
    try:
        clear_stale_light_records()
        st = light_status()
        if st['on']:
            params = _status_params(st)
            light_set(False)
            _SAVE_STASH['params'] = params
    except Exception as exc:
        print('SmartSelector ark_light_save_pre: %s' % exc)
    try:
        _SAVE_STASH['guides'] = _guides_mute_for_save()
    except Exception as exc:
        print('SmartSelector layer guide save_pre: %s' % exc)


@persistent
def ark_light_save_post(*_args):
    guides = _SAVE_STASH.get('guides') or []
    _SAVE_STASH['guides'] = []
    try:
        _guides_unmute_after_save(guides)
    except Exception as exc:
        print('SmartSelector layer guide save_post: %s' % exc)
    params = _SAVE_STASH.get('params')
    _SAVE_STASH['params'] = None
    if not params:
        return
    try:
        light_set(True, **params)
    except Exception as exc:
        print('SmartSelector ark_light_save_post: %s' % exc)


@persistent
def ark_light_sync_post(*_args):
    """After Undo / Redo: drop Screen records whose switch was undone (Screens are outside Undo), and when the
    step landed on a stage-2 state whose views were put back by an earlier Undo, set them to SOLID again
    (1.10.48 O1: Redo to stage 2 left the 3D view in MATERIAL)."""
    try:
        clear_stale_light_records()
        resync_stage2_views()
    except Exception as exc:
        print('SmartSelector ark_light_sync_post: %s' % exc)
    try:
        layer_guide_rescan()
    except Exception as exc:
        print('SmartSelector layer guide rescan: %s' % exc)


@persistent
def ark_light_load_post(*_args):
    """After File > Open: drop Screen records carried over from the previous file (Load UI off), and say
    so when the opened file itself has the light display on (auto-save / recovered file: Blender writes
    those without save_pre, so they keep the light display)."""
    _SAVE_STASH['params'] = None
    _SAVE_STASH['guides'] = []
    try:
        clear_stale_light_records()
        st = light_status()
        if st['on']:
            msg = _t('This file was saved with the light display ON (stage %d), e.g. an auto-save or recovered file. '
                     'Switch it OFF before checking the look.' % st['stage'],
                     'このファイルは軽い表示（段 %d）が入ったまま保存されています（自動保存・復旧のファイル等）。'
                     '見た目を確かめる前に一度オフにしてください。' % st['stage'])
            _set_report(msg, False)
            print('SmartSelector: %s' % msg)
    except Exception as exc:
        print('SmartSelector ark_light_load_post: %s' % exc)
    try:
        _GUIDE_WATCH.clear()
        layer_guide_rescan()
    except Exception as exc:
        print('SmartSelector layer guide rescan: %s' % exc)


def ark_layer_guide_watch(*_args):
    """While a layer is edited through the panel, the base is shown through the guide track.  When the
    tweak mode ends some other way (Tab in the NLA editor, the Action editor), mute the guide again so the
    base is not evaluated twice.  Returns at once when no layer is being edited (empty watch set).

    Added to depsgraph_update_post only when an edit starts (_watch_handler_ensure), and deliberately NOT
    persistent and not registered with the save handlers: a handler present at registration gets a
    per-call status marker from status_runtime, which would run on every depsgraph update (playback)."""
    if not _GUIDE_WATCH:
        return
    try:
        for name in list(_GUIDE_WATCH):
            ob = bpy.data.objects.get(name)
            ad = getattr(ob, 'animation_data', None) if ob is not None else None
            if ad is None or not ad.use_tweak_mode:
                _GUIDE_WATCH.discard(name)
                if ob is not None:
                    _guide_release(ob)
    except Exception as exc:
        _GUIDE_WATCH.clear()
        print('SmartSelector ark_layer_guide_watch: %s' % exc)


_SAVE_HANDLERS = (('save_pre', ark_light_save_pre), ('save_post', ark_light_save_post), ('save_post_fail', ark_light_save_post),
                  ('undo_post', ark_light_sync_post), ('redo_post', ark_light_sync_post), ('load_post', ark_light_load_post))
_SAVE_HANDLER_NAMES = {'ark_light_save_pre', 'ark_light_save_post', 'ark_light_sync_post', 'ark_light_load_post',
                       'ark_layer_guide_watch'}


def _watch_handler_ensure() -> None:
    """Add the guide watch to depsgraph_update_post once (only while a layer edit shows the base)."""
    lst = bpy.app.handlers.depsgraph_update_post
    for f in lst:
        if getattr(f, '__name__', '') == 'ark_layer_guide_watch' and str(getattr(f, '__module__', '')).endswith('ark_face'):
            return
    lst.append(ark_layer_guide_watch)


def _remove_save_handlers() -> None:
    for attr in [a for a, _fn in _SAVE_HANDLERS] + ['depsgraph_update_post']:
        lst = getattr(bpy.app.handlers, attr, None)
        if lst is None:
            continue
        for f in list(lst):
            if getattr(f, '__name__', '') in _SAVE_HANDLER_NAMES and str(getattr(f, '__module__', '')).endswith('ark_face'):
                try:
                    lst.remove(f)
                except Exception:
                    pass


def _add_save_handlers() -> None:
    _remove_save_handlers()
    for attr, fn in _SAVE_HANDLERS:
        lst = getattr(bpy.app.handlers, attr, None)
        if lst is not None and fn not in lst:
            lst.append(fn)


# -------------------------------------------------------------------------------------------- layers
# Biped-like animation layers (design §8.6, 1.10.48).  The base layer is the current (active) action of the
# armature; every layer is one NLA track with one strip and its own action.  While at least one layer exists
# AnimData.action_blend_type is COMBINE, so the base is added on top of the layers (measured: REPLACE would
# hide them).  The guide track LAYER_GUIDE holds the base action and is muted except while a layer is edited
# from the panel: in NLA tweak mode Blender does not evaluate the stored base action, so without it the
# animator would edit a layer on the rest pose.
LAYER_GUIDE = 'SS_BASE_VIEW'
LAYER_GUIDE_KEY = 'ss_layer_guide_on'   # object: set while the guide is unmuted for a panel edit
# 1.10.48 review fix: a layer is marked on its action, so NLA tracks the user had before (a pushed-down idle, a retargeted
# mocap) are never listed, muted, collapsed or removed as layers.
LAYER_MARK = 'ss_anim_layer'            # action: set on the action of every layer made by 層を足す
LAYER_BLEND_KEY = 'ss_layer_base_blend'  # object: action_blend_type before the first layer, put back with the last
# 1.10.48 review fix 2 (D2): key-less values (set by hand or by the rig) that differ from the default, recorded when a layer is
# added / edited / switched, so removing or disabling a layer puts them back instead of the default.  JSON {"path|index": value}.
LAYER_STATIC_KEY = 'ss_layer_static'
SHAPE_CHECK_MM = 0.01                   # D1: the face bake and 畳み込む fail (and roll back) above this shape difference
LAYER_SLOTS = 16
_GUIDE_WATCH = set()                    # object names whose guide is unmuted for a tweak edit
_ROT_SUFFIXES = ('rotation_quaternion', 'rotation_axis_angle')


def layer_target(context=None):
    """The armature the layer panel works on: the active object when it is an armature (body rigs too),
    otherwise the face rig, otherwise an armature called "rig" (ARP)."""
    ctx = context or bpy.context
    try:
        ob = ctx.active_object
    except Exception:
        ob = None
    if ob is not None and ob.type == 'ARMATURE':
        return ob
    rig = find_rig()
    if rig is not None:
        return rig
    try:
        ob = bpy.data.objects.get('rig')
    except Exception:
        ob = None
    return ob if ob is not None and ob.type == 'ARMATURE' else None


def _is_guide(track) -> bool:
    return str(track.name).startswith(LAYER_GUIDE)


def _is_layer(track) -> bool:
    """A layer track: not the guide, and a strip whose action carries LAYER_MARK (made by 層を足す)."""
    if _is_guide(track):
        return False
    try:
        return any(s.action is not None and _has_key(s.action, LAYER_MARK) for s in track.strips)
    except Exception:
        return False


def layer_tracks(ob) -> list:
    """The layers of ``ob`` from the bottom up (marked layer tracks; the guide and the user's own tracks are not layers)."""
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    if ad is None:
        return []
    return [t for t in ad.nla_tracks if _is_layer(t)]


def live_user_tracks(ob) -> list:
    """NLA tracks of ``ob`` that are neither layers nor the guide and are evaluated (not muted, with strips)."""
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    if ad is None:
        return []
    return [t for t in ad.nla_tracks if not _is_guide(t) and not _is_layer(t) and not t.mute and len(t.strips)]


def _guide_track(ob):
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    if ad is None:
        return None
    for t in ad.nla_tracks:
        if _is_guide(t):
            return t
    return None


def _layer_strip(track):
    try:
        return track.strips[0] if len(track.strips) else None
    except Exception:
        return None


def base_action(ob):
    """The base layer: the active action, or the action stored away while a layer is tweaked."""
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    if ad is None:
        return None
    return ad.action_tweak_storage if ad.use_tweak_mode else ad.action


def _base_slot(ob):
    ad = ob.animation_data
    act = base_action(ob)
    if act is None:
        return None
    if ad.use_tweak_mode:
        handle = int(ad.action_slot_handle_tweak_storage)
        for s in act.slots:
            if int(s.handle) == handle:
                return s
        return None
    return ad.action_slot


def _action_range(act) -> tuple:
    r = act.frame_range
    f0, f1 = float(r[0]), float(r[1])
    return f0, max(f1, f0 + 1.0)


def tweaked_layer_index(ob) -> int:
    """Index (in layer_tracks) of the layer being tweaked, or -1."""
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    if ad is None or not ad.use_tweak_mode:
        return -1
    for i, t in enumerate(layer_tracks(ob)):
        st = _layer_strip(t)
        if st is not None and st.action is not None and st.action == ad.action:
            return i
    return -1


def layer_weight_get(st, frame: float) -> float:
    if st is None:
        return 0.0
    if not st.use_animated_influence:
        return 1.0
    fc = st.fcurves.find('influence')
    if fc is not None and len(fc.keyframe_points):
        return max(0.0, min(1.0, float(fc.evaluate(frame))))
    return float(st.influence)


def layer_weight_set(ob, st, value: float, frame: float) -> None:
    """The weight of a layer (strip influence; use_animated_influence is switched on, Blender ignores the
    influence otherwise).  With 0 or 1 key the weight is constant and that key is moved; with several keys
    (an animated weight) a key is written at the current frame."""
    v = max(0.0, min(1.0, float(value)))
    if not st.use_animated_influence:
        st.use_animated_influence = True
    fc = st.fcurves.find('influence')
    if fc is not None:
        pts = fc.keyframe_points
        if len(pts) == 0:
            pts.insert(frame, v)
        elif len(pts) == 1:
            k = pts[0]
            k.co.y = v
            k.handle_left.y = v
            k.handle_right.y = v
        else:
            pts.insert(frame, v, options={'REPLACE'})
        fc.update()
    st.influence = v
    try:
        ob.update_tag(refresh={'TIME'})
    except Exception:
        pass


def _new_layer_name(base_name: str) -> str:
    used = set(a.name for a in bpy.data.actions)
    n = 1
    while True:
        name = '%s_L%d' % (base_name, n)
        if name not in used:
            return name
        n += 1


def layer_add(ob) -> dict:
    """層を足す: a new layer <base>_L<n> (COMBINE, weight 1, the frame range of the base)."""
    ad = ob.animation_data
    base = base_action(ob)
    if ad is None or base is None:
        raise ArkError(_t('"%s" has no action (base layer). Key something first.' % ob.name,
                          '「%s」にアクション（基層）がありません。先にキーを打ってください' % ob.name))
    if ad.use_tweak_mode:
        layer_edit_exit(ob)
    _static_refresh(ob)
    slot = _base_slot(ob)
    if slot is None:
        raise ArkError(_t('The action "%s" has no slot assigned to "%s"' % (base.name, ob.name),
                          'アクション「%s」に「%s」のスロットがありません' % (base.name, ob.name)))
    from bpy_extras import anim_utils
    f0, f1 = _action_range(base)
    first = not layer_tracks(ob)
    blend_before = str(ad.action_blend_type)
    if first or not _has_key(ob, LAYER_BLEND_KEY):
        ob[LAYER_BLEND_KEY] = blend_before
    # The user's own live tracks are added to (not replaced by) the base once it is COMBINE: say so.
    live_user = [t.name for t in live_user_tracks(ob)] if blend_before != 'COMBINE' else []
    guide = _guide_track(ob)
    if guide is None:
        tracks = list(ad.nla_tracks)
        guide = ad.nla_tracks.new(prev=tracks[-1]) if tracks else ad.nla_tracks.new()
        guide.name = LAYER_GUIDE
        guide.mute = True
        guide.lock = True
    name = _new_layer_name(base.name)
    act = bpy.data.actions.new(name)
    act[LAYER_MARK] = 1
    lslot = act.slots.new(slot.target_id_type, slot.name_display)
    act.use_frame_range = True
    act.frame_start = f0
    act.frame_end = f1
    anim_utils.action_ensure_channelbag_for_slot(act, lslot)
    track = ad.nla_tracks.new(prev=list(ad.nla_tracks)[-1])
    track.name = name
    st = track.strips.new(name, int(round(f0)), act)
    st.action_slot = lslot
    st.blend_type = 'COMBINE'
    # NOTHING: outside its range the layer adds nothing, so 畳み込む over the range is exact.
    st.extrapolation = 'NOTHING'
    layer_weight_set(ob, st, 1.0, f0)
    ad.action_blend_type = 'COMBINE'
    ad.use_nla = True
    return {'name': name, 'range': [f0, f1], 'index': len(layer_tracks(ob)) - 1, 'live_user_tracks': live_user}


def _guide_fill(ob) -> bool:
    """Put the base action into the guide track (below the layers) and unmute it."""
    ad = ob.animation_data
    guide = _guide_track(ob)
    base = ad.action
    slot = ad.action_slot
    if guide is None or base is None or slot is None:
        return False
    for s in list(guide.strips):
        guide.strips.remove(s)
    f0, _f1 = _action_range(base)
    gs = guide.strips.new(LAYER_GUIDE, int(round(f0)), base)
    gs.action_slot = slot
    gs.blend_type = ad.action_blend_type
    gs.extrapolation = ad.action_extrapolation
    if float(ad.action_influence) < 1.0:
        layer_weight_set(ob, gs, float(ad.action_influence), f0)
    guide.mute = False
    guide.is_solo = False
    return True


def _guide_release(ob) -> None:
    guide = _guide_track(ob)
    if guide is not None:
        try:
            guide.mute = True
            for s in list(guide.strips):
                guide.strips.remove(s)
        except Exception as exc:
            print('SmartSelector guide release: %s' % exc)
    if _has_key(ob, LAYER_GUIDE_KEY):
        try:
            del ob[LAYER_GUIDE_KEY]
        except Exception:
            pass
    _GUIDE_WATCH.discard(ob.name)


def layer_guide_rescan() -> None:
    """After load / undo / redo: watch the objects whose guide is on for an edit; release a guide left
    unmuted outside tweak mode."""
    for ob in bpy.data.objects:
        if not _has_key(ob, LAYER_GUIDE_KEY):
            guide = _guide_track(ob) if ob.animation_data is not None else None
            if guide is not None and not guide.mute and not ob.animation_data.use_tweak_mode:
                _guide_release(ob)
            continue
        ad = ob.animation_data
        if ad is not None and ad.use_tweak_mode:
            # The file was saved during the edit: save_pre muted the guide for the write (1.10.48 review fix); show the base again.
            _guides_unmute_after_save([ob.name])
            _GUIDE_WATCH.add(ob.name)
            _watch_handler_ensure()
        else:
            _guide_release(ob)


def layer_edit_enter(ob, index: int, show_base: bool = True) -> dict:
    """この層を編集: NLA tweak mode on the layer.  With show_base, the base is shown under the layer
    through the guide track (keys are remapped through it, so what you see is what you key)."""
    ad = ob.animation_data
    layers = layer_tracks(ob)
    if ad is None or not 0 <= index < len(layers):
        raise ArkError(_t('No such layer', 'その層はありません'))
    if ad.use_tweak_mode:
        layer_edit_exit(ob)
    # D2: the key-less values right before keys go into the layer.
    _static_refresh(ob)
    track = layers[index]
    st = _layer_strip(track)
    if st is None or st.action is None:
        raise ArkError(_t('The layer "%s" has no strip with an action' % track.name,
                          '層「%s」にアクションのストリップがありません' % track.name))
    guided = False
    if show_base:
        guide = _guide_track(ob)
        order = list(ad.nla_tracks)
        if guide is not None and order.index(guide) < order.index(track):
            guided = _guide_fill(ob)
    for t in ad.nla_tracks:
        for s in t.strips:
            s.select = False
    ad.nla_tracks.active = track
    st.select = True
    ad.use_tweak_mode = True
    if not ad.use_tweak_mode or ad.action != st.action:
        if guided:
            _guide_release(ob)
        raise ArkError(_t('Could not enter tweak mode on "%s"' % track.name, '「%s」の編集に入れませんでした' % track.name))
    if guided:
        ob[LAYER_GUIDE_KEY] = 1
        _GUIDE_WATCH.add(ob.name)
        _watch_handler_ensure()
    return {'name': track.name, 'guided': guided}


def layer_edit_exit(ob) -> bool:
    ad = getattr(ob, 'animation_data', None)
    was = bool(ad is not None and ad.use_tweak_mode)
    if was:
        ad.use_tweak_mode = False
    _guide_release(ob)
    return was


def layer_remove(ob, index: int) -> dict:
    """層を消す: remove the track and its action (when nothing else uses it).  Removing the last layer
    removes the guide and puts action_blend_type back to REPLACE."""
    ad = ob.animation_data
    layers = layer_tracks(ob)
    if ad is None or not 0 <= index < len(layers):
        raise ArkError(_t('No such layer', 'その層はありません'))
    if ad.use_tweak_mode:
        layer_edit_exit(ob)
    _static_refresh(ob)
    track = layers[index]
    name = track.name
    acts = [s.action for s in track.strips if s.action is not None]
    was_live = not track.mute
    track.mute = True
    # D2: back to the key-less value recorded before the layer (the default only when none differed from it).
    reset = _reset_orphan_channels(ob, [track], static=True) if was_live else []
    ad.nla_tracks.remove(track)
    removed = []
    for a in acts:
        if a.users == 0 and not a.use_fake_user:
            removed.append(a.name)
            bpy.data.actions.remove(a)
    last = not layer_tracks(ob)
    blend = None
    if last:
        guide = _guide_track(ob)
        if guide is not None:
            ad.nla_tracks.remove(guide)
        blend = str(ob.get(LAYER_BLEND_KEY, 'REPLACE')) if _has_key(ob, LAYER_BLEND_KEY) else 'REPLACE'
        if blend not in ('REPLACE', 'COMBINE', 'ADD', 'SUBTRACT', 'MULTIPLY'):
            blend = 'REPLACE'
        ad.action_blend_type = blend
        if _has_key(ob, LAYER_BLEND_KEY):
            del ob[LAYER_BLEND_KEY]
        if _has_key(ob, LAYER_STATIC_KEY):
            del ob[LAYER_STATIC_KEY]
    return {'name': name, 'removed_actions': removed, 'last': last, 'reset': reset, 'blend': blend}


class _LayersMuted:
    """Context helper for the face bake, restore and re-apply (design §8.3-0): leave tweak mode, mute every
    layer while the rig Text computes, then unmute exactly those layers and re-enter the edit (measured:
    a bake with live layers bakes the layers into the base and they are added twice)."""

    def __init__(self, ob, users: bool = False):
        self.ob = ob
        self.users = users
        self.muted = []
        self.user_muted = []
        self.solo = []
        self.tweak = -1
        self.guided = False
        self.reset = []

    def __enter__(self):
        ob = self.ob
        ad = getattr(ob, 'animation_data', None) if ob is not None else None
        if ad is None:
            return self
        if ad.use_tweak_mode:
            self.tweak = tweaked_layer_index(ob)
            self.guided = _has_key(ob, LAYER_GUIDE_KEY)
            layer_edit_exit(ob)
        for t in layer_tracks(ob):
            if t.is_solo:
                self.solo.append(t.name)
                t.is_solo = False
            if not t.mute:
                t.mute = True
                self.muted.append(t.name)
        off = [t for t in layer_tracks(ob) if t.name in self.muted]
        if self.users and user_tracks_add_to_base(ob) and not _TEST_NO_USER_MUTE:
            # 1.10.48 review fix 2 (D1): with the base blend COMBINE (layers present) the base is added on top of the
            # user's own NLA tracks, so their share must not be evaluated into the base: mute them for the run.
            for t in live_user_tracks(ob):
                t.mute = True
                self.user_muted.append(t.name)
                off.append(t)
        self.reset = _reset_orphan_channels(ob, off)
        return self

    def __exit__(self, *exc):
        ob = self.ob
        ad = getattr(ob, 'animation_data', None) if ob is not None else None
        if ad is None:
            return False
        for t in ad.nla_tracks:
            if t.name in self.user_muted and not _is_layer(t) and not _is_guide(t):
                t.mute = False
        for t in layer_tracks(ob):
            if t.name in self.muted:
                t.mute = False
            if t.name in self.solo:
                t.is_solo = True
        if self.tweak >= 0:
            try:
                layer_edit_enter(ob, self.tweak, show_base=self.guided)
            except Exception as e:
                print('SmartSelector: layer edit not re-entered: %s' % e)
        return False

    def note(self) -> str:
        out = ''
        if self.muted or self.tweak >= 0:
            out += _t(' | %d layers muted during the run and put back' % len(self.muted),
                      '｜層 %d 本をその間だけミュートして戻しました' % len(self.muted))
        if self.user_muted:
            out += _t(' | your NLA tracks %s were muted during the run and put back (they still act on top of the base)' %
                      ', '.join('"%s"' % n for n in self.user_muted[:3]),
                      '｜層ではない NLA のトラック %s もその間だけミュートして戻しました（基層の上にそのまま効きます）' %
                      '、'.join('「%s」' % n for n in self.user_muted[:3]))
        return out


def _bone_group(path: str) -> str:
    if path.startswith('pose.bones["'):
        end = path.find('"]', 12)
        if end > 12:
            return path[12:end]
    return ''


def _leaf_strips(strips, skip_muted: bool = False) -> list:
    """1.10.50 (D4): the strips that carry an action, the strips inside META strips included (recursively).  A META
    strip has no action of its own -- its actions are on the strips inside it -- so a check that skipped strips without
    an action let a user track grouped into a meta strip pass the D3 stop and the shape check (measured 0.330 mm)."""
    out = []
    for st in strips:
        if skip_muted and st.mute:
            continue
        if str(st.type) == 'META':
            out.extend(_leaf_strips(st.strips, skip_muted))
        elif st.action is not None:
            out.append(st)
    return out


def _unreadable_strips(strips) -> list:
    """1.10.50 (D4): names of the strips (inside META strips too) that have no action and are not META -- a transition,
    a sound strip or anything else whose channels cannot be read.  The face bake refuses a live track that has one."""
    out = []
    for st in strips:
        if str(st.type) == 'META':
            out.extend(_unreadable_strips(st.strips))
        elif st.action is None:
            out.append('%s (%s)' % (st.name, st.type))
    return out


def _layer_channels(tracks) -> list:
    """(data_path, index) of every F-curve of the given layers; rotations as whole quaternions.
    1.10.50 (D4): the strips inside META strips are read too."""
    from bpy_extras import anim_utils
    out = []
    for t in tracks:
        for st in _leaf_strips(t.strips):
            if st.action is None or st.action_slot is None:
                continue
            bag = anim_utils.action_get_channelbag_for_slot(st.action, st.action_slot)
            if bag is None:
                continue
            for fc in bag.fcurves:
                p = fc.data_path
                if p.endswith(_ROT_SUFFIXES):
                    out.extend((p, i) for i in range(4))
                else:
                    out.append((p, int(fc.array_index)))
    return list(dict.fromkeys(out))


def slider_layers(ob) -> list:
    """Names of the enabled layers that animate one of the 52 sliders (bones / properties ``cc_arkit_*``).
    The face bake mutes the layers, so such a layer is not baked into the base, and after the bake the ARK
    constraints are off, so it no longer moves the face (1.10.48 F1, measured 11.289 mm).  The bake refuses them."""
    out = []
    for t in layer_tracks(ob):
        if t.mute:
            continue
        for path, _idx in _layer_channels([t]):
            if _bone_group(path).startswith(SLIDER_PREFIX) or ('["%s' % SLIDER_PREFIX) in path:
                out.append(t.name)
                break
    return out


def _read_channel(ob, path: str, index: int):
    v = ob.path_resolve(path)
    try:
        return float(v[index])
    except TypeError:
        return float(v)


def _base_channels(ob) -> set:
    from bpy_extras import anim_utils
    ad = ob.animation_data
    act = base_action(ob)
    slot = _base_slot(ob) if act is not None else None
    bag = anim_utils.action_get_channelbag_for_slot(act, slot) if slot is not None else None
    return set((f.data_path, int(f.array_index)) for f in bag.fcurves) if bag is not None else set()


def _channel_owner(ob, path: str):
    """(owner, key, is_idprop) for an F-curve data path on ob."""
    if path.endswith('"]'):
        i = path.rfind('["')
        owner = ob.path_resolve(path[:i]) if i > 0 else ob
        return owner, path[i + 2:-2], True
    head, _, prop = path.rpartition('.')
    return (ob.path_resolve(head) if head else ob), prop, False


def _channel_default(ob, path: str, index: int) -> float:
    owner, key, idprop = _channel_owner(ob, path)
    if idprop:
        try:
            d = owner.id_properties_ui(key).as_dict().get('default', 0.0)
        except Exception:
            d = 0.0
        if isinstance(d, (list, tuple)):
            return float(d[index]) if index < len(d) else 0.0
        return float(d or 0.0)
    rp = owner.bl_rna.properties[key]
    if getattr(rp, 'is_array', False):
        return float(rp.default_array[index])
    return float(rp.default)


def user_tracks_add_to_base(ob) -> bool:
    """True when the base action is blended on top of the NLA tracks below it instead of replacing them (blend not
    REPLACE, e.g. COMBINE while layers exist): then a live user track's share is added to whatever is keyed in the base."""
    ad = getattr(ob, 'animation_data', None) if ob is not None else None
    return bool(ad is not None and str(ad.action_blend_type) != 'REPLACE')


_STATIC_POSE_PROPS = (('location', 3), ('rotation_quaternion', 4), ('rotation_euler', 3), ('rotation_axis_angle', 4),
                      ('scale', 3))


def _animated_channels(ob) -> set:
    """(data_path, index) driven by the base action, any live NLA track (layers, the user's, the guide) or a driver."""
    from bpy_extras import anim_utils
    out = set(_base_channels(ob))
    ad = ob.animation_data
    if ad is None:
        return out
    for t in ad.nla_tracks:
        if t.mute:
            continue
        for st in _leaf_strips(t.strips):
            if st.action is None or st.action_slot is None:
                continue
            bag = anim_utils.action_get_channelbag_for_slot(st.action, st.action_slot)
            if bag is not None:
                out.update((f.data_path, int(f.array_index)) for f in bag.fcurves)
    try:
        out.update((d.data_path, int(d.array_index)) for d in ad.drivers)
    except Exception:
        pass
    return out


def _numeric_idprops(owner, prefix: str):
    """(path, index, value) of the int / float custom properties (and their arrays) of owner."""
    for k in list(owner.keys()):
        if k.startswith('ss_') or k == '_RNA_UI':
            continue
        try:
            v = owner[k]
        except Exception:
            continue
        path = '%s["%s"]' % (prefix, bpy.utils.escape_identifier(k))
        if isinstance(v, bool):
            continue
        if isinstance(v, (int, float)):
            yield path, 0, float(v)
            continue
        try:
            seq = list(v)
        except Exception:
            continue
        if seq and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in seq):
            for i, x in enumerate(seq):
                yield path, i, float(x)


def _static_candidates(ob):
    """(path, index, value) of every pose-bone transform channel and numeric custom property of ob."""
    for k in _numeric_idprops(ob, ''):
        yield k
    for pb in ob.pose.bones if ob.pose is not None else ():
        head = 'pose.bones["%s"]' % bpy.utils.escape_identifier(pb.name)
        for prop, n in _STATIC_POSE_PROPS:
            vals = getattr(pb, prop)
            for i in range(n):
                yield '%s.%s' % (head, prop), i, float(vals[i])
        for k in _numeric_idprops(pb, head):
            yield k


def _static_load(ob) -> dict:
    try:
        return dict(json.loads(str(ob[LAYER_STATIC_KEY]))) if _has_key(ob, LAYER_STATIC_KEY) else {}
    except Exception:
        return {}


def _static_refresh(ob) -> int:
    """D2: record the key-less value of every channel that nothing animates right now (base, live tracks, drivers) when it
    differs from its default; channels animated now keep the value recorded earlier (the one from before the layer).
    Only values that differ from the default are kept, so the record stays small."""
    if ob is None or getattr(ob, 'type', '') != 'ARMATURE':
        return 0
    try:
        rec = _static_load(ob)
        animated = _animated_channels(ob)
        for path, idx, val in _static_candidates(ob):
            if (path, idx) in animated:
                continue
            key = '%s|%d' % (path, idx)
            try:
                d = _channel_default(ob, path, idx)
            except Exception:
                d = 0.0
            if abs(val - d) > 1e-7:
                rec[key] = val
            else:
                rec.pop(key, None)
        if rec:
            ob[LAYER_STATIC_KEY] = json.dumps(rec, sort_keys=True)
        elif _has_key(ob, LAYER_STATIC_KEY):
            del ob[LAYER_STATIC_KEY]
        return len(rec)
    except Exception as exc:
        print('SmartSelector layer static record: %s' % exc)
        return 0


def _reset_orphan_channels(ob, tracks_off, static: bool = False) -> list:
    """Muting (or removing) a layer stops the animation of its channels, and Blender then leaves the last
    evaluated value on them (measured on MIK_193: the lips stayed 3 mm out and a face bake baked it in, 1.99 mm).
    Channels animated only by the given tracks -- not by the base or a live layer -- go back to their default
    (the value NLA COMBINE adds the layers to; right for the bake, which evaluates without the tracks).
    With ``static`` (layer removed / disabled, D2) they go back to the key-less value recorded before the layer
    (_static_refresh), and to the default only when none was recorded."""
    ad = getattr(ob, 'animation_data', None)
    if ad is None:
        return []
    off = set(t.name for t in tracks_off)
    live = _base_channels(ob)
    live.update(_layer_channels([t for t in layer_tracks(ob) if not t.mute and t.name not in off]))
    rec = _static_load(ob) if static else {}
    done = []
    for path, idx in _layer_channels(tracks_off):
        if (path, idx) in live:
            continue
        try:
            key = '%s|%d' % (path, idx)
            d = float(rec[key]) if key in rec else _channel_default(ob, path, idx)
            owner, key, idprop = _channel_owner(ob, path)
            cur = owner[key] if idprop else getattr(owner, key)
            if idprop and isinstance(cur, int) and not isinstance(cur, bool):
                d = int(round(d))
            try:
                cur[idx] = d
            except TypeError:
                if idprop:
                    owner[key] = d
                else:
                    setattr(owner, key, d)
            done.append('%s[%d]' % (path, idx))
        except Exception as exc:
            print('SmartSelector layer reset %s[%d]: %s' % (path, idx, exc))
    if done:
        try:
            ob.update_tag()
        except Exception:
            pass
    return done


def layer_set_enabled(ob, index: int, enabled: bool) -> dict:
    """有効 / 無効 of a layer (track.mute), resetting the channels that only this layer animated."""
    layers = layer_tracks(ob)
    if not 0 <= index < len(layers):
        raise ArkError(_t('No such layer', 'その層はありません'))
    t = layers[index]
    # D2: record the key-less values first (enabling: the value the layer is about to cover; disabling: nothing new).
    _static_refresh(ob)
    t.mute = not enabled
    reset = [] if enabled else _reset_orphan_channels(ob, [t], static=True)
    return {'name': t.name, 'reset': reset}


def _shape_meshes(ob) -> list:
    """Visible meshes the armature ``ob`` can move: an Armature modifier on it, parented to it, or a driver (shape keys,
    modifiers) reading it.  All visible meshes when none is found."""
    vl = bpy.context.view_layer
    out = []
    allv = []
    for m in vl.objects:
        if m.type != 'MESH':
            continue
        try:
            if not m.visible_get():
                continue
        except Exception:
            continue
        allv.append(m)
        hit = False
        p = m.parent
        while p is not None and not hit:
            hit = p == ob
            p = p.parent
        if not hit:
            hit = any(md.type == 'ARMATURE' and md.object == ob for md in m.modifiers)
        if not hit:
            for idb in (m, getattr(m.data, 'shape_keys', None)):
                adx = getattr(idb, 'animation_data', None) if idb is not None else None
                if adx is None:
                    continue
                for d in adx.drivers:
                    if any(t.id == ob for v in d.driver.variables for t in v.targets):
                        hit = True
                        break
                if hit:
                    break
        if hit:
            out.append(m)
    return out or allv


# 1.10.49 (speed): the shape check evaluates the meshes with their trailing subdivision switched off (the cage).
# Subdivision is a convex, fixed function of the cage, so equal cages give equal subdivided meshes and a cage difference
# bounds the subdivided one: nothing the check catches is lost.  Measured on MIK_193: 5 frames x 73 meshes 3.7 s -> 0.07 s.
# Only a SUBSURF / MULTIRES followed by nothing but the modifiers below is switched off, and never on an object with a
# physics modifier (a point cache or a collider would see another mesh).  Everything is put back in a finally.
# An ARMATURE after the subdivision (MIK's hair tails) skins the cage instead of the subdivided mesh: positions and weights
# are both interpolated from the cage, so a change of the bones shows on the cage as well (to first order the same size).
_CAGE_SAFE_AFTER = frozenset(('SUBSURF', 'MULTIRES', 'WEIGHTED_NORMAL', 'DATA_TRANSFER', 'TRIANGULATE', 'EDGE_SPLIT',
                              'UV_PROJECT', 'UV_WARP', 'NORMAL_EDIT', 'ARMATURE'))
_CAGE_PHYSICS = frozenset(('CLOTH', 'SOFT_BODY', 'COLLISION', 'DYNAMIC_PAINT', 'FLUID', 'PARTICLE_SYSTEM', 'OCEAN',
                           'SURFACE', 'EXPLODE', 'PARTICLE_INSTANCE'))


# Modifiers after a switched-off subdivision that cannot move a vertex: switched off as well while the cage is read, so a
# topology-based one (DATA_TRANSFER "Topology") does not report an error on the cage.
_CAGE_NON_POSITIONAL = frozenset(('WEIGHTED_NORMAL', 'DATA_TRANSFER', 'NORMAL_EDIT', 'UV_PROJECT', 'UV_WARP'))


def _weights_feed_deform(trailing) -> bool:
    """1.10.49 review (LOW): True when a DATA_TRANSFER in ``trailing`` writes vertex-group weights (or cannot be read) and an
    ARMATURE comes after it.  Switching that DATA_TRANSFER off for the cage would leave the ARMATURE without weights, so the
    shape check would not see the bones move (measured: 5.000 mm on the full stack, 0.0 mm on the cage).  Such a mesh is
    compared with its subdivision on (slower, exact)."""
    for j, x in enumerate(trailing):
        if x.type != 'DATA_TRANSFER':
            continue
        try:
            weights = bool(x.use_vert_data) and 'VGROUP_WEIGHTS' in set(x.data_types_verts)
        except Exception:
            weights = True
        if weights and any(y.type == 'ARMATURE' for y in trailing[j + 1:]):
            return True
    return False


class _CageOnly:
    """Switch off (viewport) the trailing subdivision modifiers of the given meshes (and the non-positional modifiers after
    them), and switch exactly those back on exit.  A mesh another object's DATA_TRANSFER reads is left alone (its corners
    must keep matching)."""

    def __init__(self, meshes):
        self.meshes = meshes
        self.off = []

    def __enter__(self):
        sources = set()
        try:
            for o in bpy.data.objects:
                if o.type == 'MESH':
                    for md in o.modifiers:
                        if md.type == 'DATA_TRANSFER' and md.object is not None and md.object != o:
                            sources.add(md.object.name)
        except Exception:
            pass
        for m in self.meshes:
            try:
                if m.name in sources:
                    continue
                mods = list(m.modifiers)
                if any(md.type in _CAGE_PHYSICS for md in mods):
                    continue
                for i, md in enumerate(mods):
                    if md.type not in ('SUBSURF', 'MULTIRES') or not md.show_viewport:
                        continue
                    if all(x.type in _CAGE_SAFE_AFTER for x in mods[i + 1:]) and not _weights_feed_deform(mods[i + 1:]):
                        md.show_viewport = False
                        self.off.append((m.name, md.name))
                        for x in mods[i + 1:]:
                            if x.type in _CAGE_NON_POSITIONAL and x.show_viewport:
                                x.show_viewport = False
                                self.off.append((m.name, x.name))
            except Exception as exc:
                print('SmartSelector shape check (cage) %s: %s' % (getattr(m, 'name', '?'), exc))
        return self

    def __exit__(self, *exc):
        for obn, mdn in self.off:
            try:
                bpy.data.objects[obn].modifiers[mdn].show_viewport = True
            except Exception as e:
                print('SmartSelector shape check: could not switch %s / %s back on: %s' % (obn, mdn, e))
        self.off = []
        return False


def _shape_capture(meshes, frames, scene, end=None) -> dict:
    """World-space vertex positions of the evaluated meshes (the cage, see _CageOnly) on each frame:
    {(frame, name): array}.  The evaluated mesh is read in place (no to_mesh copy), as float32 positions.
    ``end`` = (frame, subframe): set that frame before the subdivision is switched back on, so the full mesh is evaluated
    once, on the user's frame, by whatever evaluates next (saves a full evaluation of every subdivision)."""
    import numpy as np
    out = {}
    with _CageOnly(meshes):
        for f in frames:
            scene.frame_set(int(f))
            dg = bpy.context.evaluated_depsgraph_get()
            for m in meshes:
                try:
                    oe = m.evaluated_get(dg)
                    me = oe.data
                    a = np.empty(len(me.vertices) * 3, dtype=np.float32)
                    me.attributes['position'].data.foreach_get('vector', a)
                    mw = np.array(oe.matrix_world)
                    out[(int(f), m.name)] = a.reshape(-1, 3).astype(np.float64) @ mw[:3, :3].T + mw[:3, 3]
                except Exception:
                    pass
        if end is not None:
            scene.frame_set(end[0], subframe=end[1])
    return out


def _shape_diff_mm(a: dict, b: dict) -> tuple:
    """(max difference in mm, where, meshes skipped because their vertex count changed)."""
    import numpy as np
    worst, where, skipped = 0.0, '', []
    for k, va in a.items():
        vb = b.get(k)
        if vb is None or vb.shape != va.shape:
            skipped.append('%s@%d' % (k[1], k[0]))
            continue
        if va.size:
            d = float(np.abs(va - vb).max()) * 1000.0
            if d > worst:
                worst, where = d, '%s@%d' % (k[1], k[0])
    return worst, where, skipped


def _check_frames(f0: float, f1: float, n: int = 5) -> list:
    import math
    a, b = int(math.ceil(f0 - 1e-6)), int(math.floor(f1 + 1e-6))
    if b <= a:
        return [a]
    return sorted(set(int(round(a + (b - a) * i / float(n - 1))) for i in range(n)))


SHAPE_CHECK_MAX_FRAMES = 24             # 1.10.49 (D3): at most this many frames in a shape check


def _strip_key_frames(st) -> list:
    """Scene frames of the keys of a strip's action (all repeats, scale and reverse applied).
    1.10.50 (D4): a META strip gives the key frames of the strips inside it (their frames are scene frames)."""
    from bpy_extras import anim_utils
    out = []
    if str(st.type) == 'META':
        for sub in st.strips:
            if not sub.mute:
                out += _strip_key_frames(sub)
        return out
    if st.action is None or st.action_slot is None:
        return out
    bag = anim_utils.action_get_channelbag_for_slot(st.action, st.action_slot)
    if bag is None:
        return out
    a0, a1 = float(st.action_frame_start), float(st.action_frame_end)
    span = max(a1 - a0, 1e-6)
    scale = float(st.scale) or 1.0
    reps = max(1, int(round(float(st.repeat))))
    keys = set()
    for fc in bag.fcurves:
        for k in fc.keyframe_points:
            x = float(k.co.x)
            if a0 - 1e-4 <= x <= a1 + 1e-4:
                keys.add(x)
    for r in range(min(reps, 64)):
        for x in keys:
            off = (a1 - x) if st.use_reverse else (x - a0)
            out.append(float(st.frame_start) + (r * span + off) * scale)
    return out


def _extra_check_frames(ob, lo: float, hi: float, base: list) -> list:
    """1.10.49 (D3): the shape check also looks where something changes between the 5 evenly spaced frames: start, end
    and middle of every strip of the live NLA tracks (the user's and the layers), the frames just outside them and the
    frames of the keys of those strips' actions.  Inside [lo, hi], integer frames, at most SHAPE_CHECK_MAX_FRAMES in all;
    filled in that order of priority, a group that does not fit is thinned evenly.
    1.10.49 review: the base action's own key frames are NOT added.  The bake keys from the base itself, so a base key
    between the 5 frames cannot hide a double; adding them made every retargeted base (a key on every frame) check 24
    frames even with no NLA track at all (3-6x the 1.10.47 bake time).  Without a live track or layer: the 5 frames only."""
    import math
    have = set(int(f) for f in base)
    core, outer, tkeys = [], [], []
    ad = getattr(ob, 'animation_data', None)
    if ad is not None:
        for t in ad.nla_tracks:
            if t.mute or _is_guide(t):
                continue
            for top in t.strips:
                if top.mute:
                    continue
                # 1.10.50 (D4): the META strip itself and every strip inside it (recursively).
                stack, flat = [top], []
                while stack:
                    st = stack.pop(0)
                    flat.append(st)
                    if str(st.type) == 'META':
                        stack.extend(s for s in st.strips if not s.mute)
                for st in flat:
                    s0, s1 = float(st.frame_start), float(st.frame_end)
                    core += [s0, s1, (s0 + s1) * 0.5]
                    outer += [s0 - 1.0, s1 + 1.0]
                tkeys += _strip_key_frames(top)
    out = set(have)
    for group in (core, outer, tkeys):
        room = SHAPE_CHECK_MAX_FRAMES - len(out)
        if room <= 0:
            break
        cand = []
        for v in group:
            for f in (int(math.floor(v + 1e-6)), int(math.ceil(v - 1e-6))):
                if lo - 1e-6 <= f <= hi + 1e-6 and f not in out and f not in cand:
                    cand.append(f)
        if len(cand) > room:
            if group is core or group is outer:
                cand = cand[:room]
            else:
                cand = sorted(cand)
                cand = [cand[int(round(i * (len(cand) - 1) / float(max(room - 1, 1))))] for i in range(room)]
        out.update(cand)
    return sorted(out)


def _curve_backup(bag, channels) -> dict:
    """Keyframes of the given channels (None when there was no F-curve), to put back after a failed check."""
    out = {}
    for path, idx in channels:
        fc = bag.fcurves.find(path, index=idx) if bag is not None else None
        if fc is None:
            out[(path, idx)] = None
            continue
        out[(path, idx)] = [(tuple(k.co), k.interpolation, k.easing, k.type, k.back, k.amplitude, k.period,
                             k.handle_left_type, k.handle_right_type, tuple(k.handle_left), tuple(k.handle_right))
                            for k in fc.keyframe_points]
    return out


def _curve_restore(bag, backup: dict) -> int:
    n = 0
    for (path, idx), keys in backup.items():
        fc = bag.fcurves.find(path, index=idx)
        if keys is None:
            if fc is not None:
                bag.fcurves.remove(fc)
                n += 1
            continue
        if fc is None:
            continue
        pts = fc.keyframe_points
        pts.clear()
        pts.add(len(keys))
        for p, k in zip(pts, keys):
            (p.co, p.interpolation, p.easing, p.type, p.back, p.amplitude, p.period,
             p.handle_left_type, p.handle_right_type, p.handle_left, p.handle_right) = k
        fc.update()
        n += 1
    return n


def layer_collapse(ob, context, watch=None) -> dict:
    """畳み込む: evaluate base + enabled layers on every frame of their range and key the result into the
    base (linear keys on the channels the layers animate).  The animated property values are read -- not the
    visual transform -- so constraints (ARK, jawForward) are not keyed a second time.  The collapsed layers
    are muted and kept as a backup."""
    ad = ob.animation_data
    if ad is None:
        raise ArkError(_t('No animation data', 'アニメーションのデータがありません'))
    if ad.use_tweak_mode:
        layer_edit_exit(ob)
    base = ad.action
    slot = ad.action_slot
    if base is None or slot is None:
        raise ArkError(_t('No base action', '基層のアクションがありません'))
    live = [t for t in layer_tracks(ob) if not t.mute and _layer_strip(t) is not None]
    if not live:
        raise ArkError(_t('No enabled layer to collapse', '畳み込む（有効な）層がありません'))
    channels = []
    unreadable = []
    for path, idx in _layer_channels(live):
        try:
            _read_channel(ob, path, idx)
            channels.append((path, idx))
        except Exception:
            unreadable.append('%s[%d]' % (path, idx))
    if not channels:
        raise ArkError(_t('The enabled layers have no keys', '有効な層にキーがありません'))
    import math
    f0 = min(min(s.frame_start for s in t.strips) for t in live)
    f1 = max(max(s.frame_end for s in t.strips) for t in live)
    frames = list(range(int(math.ceil(f0 - 1e-6)), int(math.floor(f1 + 1e-6)) + 1))
    scene = context.scene
    frame_before = (int(scene.frame_current), float(scene.frame_subframe))
    # 1.10.48 review fix 2 (D1): the shape with every track (what the user sees) before anything is written.
    # 1.10.49 (D3): also on the strip bounds / middles and key frames, not only 5 evenly spaced frames.
    meshes = _shape_meshes(ob)
    cframes = _extra_check_frames(ob, frames[0], frames[-1], _check_frames(frames[0], frames[-1]))
    user_muted = []
    layers_muted = []
    bag = None
    backup = None
    groups_before = set()
    clean = [False]

    def _unmute_users():
        for t in ad.nla_tracks:
            if t.name in user_muted and not _is_layer(t) and not _is_guide(t):
                t.mute = False

    def _put_back_keys():
        # 1.10.49: an exception after the keys were written puts the base keys back from the backup and the layers on.
        if bag is not None and backup is not None:
            _curve_restore(bag, backup)
            try:
                for g in list(bag.groups):
                    if g.name not in groups_before and len(g.channels) == 0:
                        bag.groups.remove(g)
            except Exception:
                pass
        for t in ad.nla_tracks:
            if t.name in layers_muted:
                t.mute = False
        try:
            ob.update_tag()
        except Exception:
            pass

    try:
        shape_before = _shape_capture(meshes, cframes, scene)
        # The base is COMBINE while layers exist, so the user's own NLA tracks are added on top of it: evaluate without
        # them, or their share is keyed into the base and added a second time (D1, measured 10.52 mm).
        if user_tracks_add_to_base(ob) and not _TEST_NO_USER_MUTE:
            for t in live_user_tracks(ob):
                t.mute = True
                user_muted.append(t.name)
        values = {c: [] for c in channels}
        try:
            for n, f in enumerate(frames):
                if watch is not None:
                    watch.check('collapse')
                scene.frame_set(f)
                for c in channels:
                    values[c].append(_read_channel(ob, c[0], c[1]))
                if n and n % 50 == 0:
                    print('SmartSelector 畳み込み: %d / %d コマ（Esc で中断）' % (n, len(frames)))
        except _ArkCancelled:
            return {'ok': False, 'cancelled': True}
        from bpy_extras import anim_utils
        bag_ = anim_utils.action_ensure_channelbag_for_slot(base, slot)
        groups_before = set(g.name for g in bag_.groups)
        backup = _curve_backup(bag_, channels)
        bag = bag_
        lo, hi = frames[0] - 1e-4, frames[-1] + 1e-4
        keys = 0
        for (path, idx) in channels:
            fc = bag.fcurves.find(path, index=idx)
            if fc is None:
                grp = _bone_group(path)
                fc = bag.fcurves.new(path, index=idx, group_name=grp) if grp else bag.fcurves.new(path, index=idx)
            pts = fc.keyframe_points
            for k in reversed([k for k in pts if lo <= k.co.x <= hi]):
                pts.remove(k, fast=True)
            n0 = len(pts)
            pts.add(len(frames))
            for j, (f, v) in enumerate(zip(frames, values[(path, idx)])):
                p = pts[n0 + j]
                p.co = (float(f), v)
                p.handle_left = (float(f) - 0.3, v)
                p.handle_right = (float(f) + 0.3, v)
                p.interpolation = 'LINEAR'
            fc.update()
            keys += len(frames)
        for t in live:
            t.mute = True
            layers_muted.append(t.name)
        # Self-check on the first, middle and last frame: the base alone gives what base + layers gave (values, user tracks off).
        diff = 0.0
        for j in sorted(set((0, len(frames) // 2, len(frames) - 1))):
            scene.frame_set(frames[j])
            for c in channels:
                diff = max(diff, abs(_read_channel(ob, c[0], c[1]) - values[c][j]))
        _unmute_users()
        # D1: the shape with every track again (layers now muted, the user's tracks back on) must equal the shape before.
        shape_after = _shape_capture(meshes, cframes, scene, end=frame_before)
        mm, where, skipped = _shape_diff_mm(shape_before, shape_after)
        out = {'layers': [t.name for t in live], 'channels': len(channels), 'frames': [frames[0], frames[-1]],
               'keys': keys, 'max_diff': diff, 'unreadable': unreadable, 'shape_mm': mm, 'shape_where': where,
               'shape_frames': cframes, 'shape_meshes': len(meshes), 'shape_skipped': skipped, 'user_muted': user_muted}
        if mm > SHAPE_CHECK_MM:
            # Failed: put the base keys back from the backup, the layers back on, and stop.
            _put_back_keys()
            back = _shape_capture(meshes, cframes, scene, end=frame_before)
            out['rollback_mm'] = _shape_diff_mm(shape_before, back)[0]
            out['ok'] = False
            out['rolled_back'] = True
            clean[0] = True
            return out
        out['ok'] = True
        clean[0] = True
        return out
    except _ArkCancelled:
        raise
    except Exception:
        _put_back_keys()
        raise
    finally:
        # 1.10.49: whatever happens, the user's tracks get their mute back and the scene its frame.
        try:
            _unmute_users()
        finally:
            # The last shape capture already ended on the user's frame (end=); otherwise (cancel, exception) set it again.
            if not clean[0] or (int(scene.frame_current), float(scene.frame_subframe)) != frame_before:
                scene.frame_set(frame_before[0], subframe=frame_before[1])


# ---------------------------------------------------------------------------------------------- pads
def _side(entry) -> list:
    if entry is None:
        return []
    if isinstance(entry, str):
        return [entry]
    if isinstance(entry, (list, tuple)):
        return [str(x) for x in entry if x]
    return []


def _pad(i: int):
    pads = layout_data().get('pads') or []
    return pads[i] if 0 <= i < len(pads) else None


def _slider_bone(rig, arkit: str):
    return rig.pose.bones.get(SLIDER_PREFIX + arkit) if rig is not None else None


def _mean_value(rig, names) -> float:
    vals = [pb.location[1] for pb in (_slider_bone(rig, n) for n in names) if pb is not None]
    return sum(vals) / len(vals) if vals else 0.0


def pad_get(i: int, axis: str) -> float:
    rig = find_rig()
    pad = _pad(i)
    if rig is None or pad is None:
        return 0.0
    try:
        sides = pad[axis]
        neg, pos = _side(sides[0]), _side(sides[1])
    except Exception:
        return 0.0
    v = _mean_value(rig, pos) - (_mean_value(rig, neg) if neg else 0.0)
    return max(-1.0, min(1.0, v))


def _pad_axes() -> list:
    """Every (neg names, pos names) pair of every pad axis."""
    out = []
    for pad in layout_data().get('pads') or []:
        for axis in ('x', 'y'):
            try:
                sides = pad[axis]
                out.append((_side(sides[0]), _side(sides[1])))
            except Exception:
                pass
    return out


def _may_zero(name: str, active: list) -> bool:
    """A name on the idle side of an axis is set to 0 only when it is an antagonist of the written
    names in every pad axis it belongs to.  mouthPucker is the negative side of both 「口角 L」 and
    「口角 R」; writing mouthStretchLeft must not wipe the Pucker that 「口角 R」 (or a mocap) holds."""
    act = set(active)
    for neg, pos in _pad_axes():
        if name in neg and not (act & set(pos)):
            return False
        if name in pos and not (act & set(neg)):
            return False
    return True


def pad_set(i: int, axis: str, value: float) -> None:
    rig = find_rig()
    pad = _pad(i)
    if rig is None or pad is None:
        return
    try:
        sides = pad[axis]
        neg, pos = _side(sides[0]), _side(sides[1])
    except Exception:
        return
    v = max(-1.0, min(1.0, float(value)))
    if not neg:
        v = max(0.0, v)
    try:
        auto = bool(bpy.context.scene.tool_settings.use_keyframe_insert_auto)
    except Exception:
        auto = False
    active = pos if v > 0.0 else neg if v < 0.0 else []
    for names, val in ((pos, max(v, 0.0)), (neg, max(-v, 0.0))):
        for n in names:
            if val == 0.0 and active and not _may_zero(n, active):
                continue
            pb = _slider_bone(rig, n)
            if pb is None:
                continue
            pb.location[1] = val
            if auto:
                try:
                    pb.keyframe_insert(data_path='location', index=1, group=pb.name)
                except Exception:
                    pass
    try:
        rig.update_tag()
    except Exception:
        pass


def _make_pad_accessors(i: int, axis: str):
    def _get(self):
        return pad_get(i, axis)

    def _set(self, value):
        pad_set(i, axis, value)
    return _get, _set


def _face_smooth_update(self, context):
    """Any light-display option changed while it is on: re-apply at once with the panel's choice."""
    if light_is_on():
        rep = light_set(True, **_props_params(self))
        _set_report(_light_report_text(rep), rep['render_unchanged'] and not rep['failed'])


_props_annotations = {
    'face_smooth': BoolProperty(
        name='Smooth Face',
        description='Keep the subdivision of the face pair (MIK_geo_faceA and JEL_nor_faceA) even in the light display. '
                    'About 13 ms heavier per frame (design 10.4). Switching it while the light display is on re-applies at once',
        default=False, update=_face_smooth_update),
    'light_stage': EnumProperty(
        name='Light Display Stage',
        description='What the light display switches off. Switching it while the light display is on re-applies at once',
        items=(('STAGE1', 'Stage 1 (Light)',
                'Viewport only: the subdivision modifiers that are not the last of their stack'),
               ('STAGE2', 'Stage 2 (Animator)',
                'Viewport only: stage 1, plus the last subdivision of each stack, plus hiding the small props, plus Solid shading. '
                'Clothes and props look faceted and the props are hidden: do not use it to check the final look')),
        default='STAGE2', update=_face_smooth_update),
    'light_hide_props': BoolProperty(
        name='Hide Small Props',
        description='Stage 2: hide the small props (necklaces, belt, piercings, hair metal parts and so on). '
                    'Hidden objects are not evaluated, so a script reading their matrices gets stale values',
        default=True, update=_face_smooth_update),
    'light_prop_rule': StringProperty(
        name='Small Prop Names',
        description='Comma-separated name fragments (case-sensitive) of the small props hidden in stage 2. '
                    'An object property ark_light_prop = 1 / 0 always includes / excludes that object',
        default=DEFAULT_PROP_RULE, update=_face_smooth_update),
    'curve_factor': FloatProperty(
        name='Clean-up Strength', description='Factor passed to the clean-up operators (smooth, blend, relax and so on)',
        default=0.5, min=0.0, max=1.0, subtype='FACTOR'),
    'decimate_error': FloatProperty(
        name='Decimate Allowed Error', description='Error margin of key decimation. The difference to the original is reported afterwards',
        default=0.001, min=0.0, max=1.0, precision=4),
    'reapply_srs_limits': BoolProperty(
        name='Also Reset SmartRig Limits',
        description='When re-applying, also put the 12 SmartRig jaw / teeth / tongue limits back to the values in the spec',
        default=True),
}
for _i in range(PAD_SLOTS):
    for _axis in ('x', 'y'):
        _g, _s = _make_pad_accessors(_i, _axis)
        _props_annotations['pad_%d_%s' % (_i, _axis)] = FloatProperty(
            name='Pad Left/Right' if _axis == 'x' else 'Pad Down/Up',
            description='2D pad: writes 2 to 4 paired cc_arkit_* values at once without new bones. '
                        'Above 0 is the second side (right / up), below 0 the first side (left / down). Keys are inserted when Auto Keying is on',
            min=-1.0, max=1.0, get=_g, set=_s, subtype='FACTOR')
del _i, _axis, _g, _s


def _make_layer_weight_accessors(i: int):
    def _get(self):
        ob = layer_target()
        layers = layer_tracks(ob)
        if not 0 <= i < len(layers):
            return 0.0
        try:
            frame = float(bpy.context.scene.frame_current)
        except Exception:
            frame = 1.0
        return layer_weight_get(_layer_strip(layers[i]), frame)

    def _set(self, value):
        ob = layer_target()
        layers = layer_tracks(ob)
        if not 0 <= i < len(layers):
            return
        st = _layer_strip(layers[i])
        if st is None:
            return
        try:
            frame = float(bpy.context.scene.frame_current)
        except Exception:
            frame = 1.0
        layer_weight_set(ob, st, value, frame)
    return _get, _set


for _i in range(LAYER_SLOTS):
    _g, _s = _make_layer_weight_accessors(_i)
    _props_annotations['layer_weight_%d' % _i] = FloatProperty(
        name='Animation Layer Weight',
        description='Weight of this layer (NLA strip influence). With no or one key it is constant; '
                    'when the weight already has several keys, a key is written at the current frame',
        # options=set(): not ANIMATABLE.  A key on this get/set Scene property never reaches the strip (1.10.48 review fix);
        # an animated weight is keyed on the strip influence (several keys: the slider keys the current frame).
        min=0.0, max=1.0, get=_g, set=_s, subtype='FACTOR', options=set())
del _i, _g, _s
_props_annotations['layer_show_base'] = BoolProperty(
    name='Show Base While Editing',
    description='While a layer is edited, show the base under it through the guide track SS_BASE_VIEW (Blender itself does not '
                'evaluate the base action in tweak mode). Location, scale and custom properties match the playback exactly; '
                'a rotation keyed on another axis than the base rotation can differ from the playback',
    default=True)

# The File Browser's top UI region sizes itself to the panel's full height.
# Show one section at a time so the native region stays inside the editor.
_FILE_BROWSER_TABS = (
    ('light', 'Light display', '軽い表示'),
    ('buttons', 'Reset / mirror', 'リセット・反転'),
    ('bake', 'Bake / restore / re-apply', '焼き・戻し・当て直し'),
    ('layers', 'Layers', '層'),
    ('pads', '2D pads', '2D パッド'),
    ('sliders', '52 expressions', '52 表情'),
    ('hand', 'Helper sliders', '補助のスライダー'),
    ('curves', 'Clean-up after baking', '手直しの補助'),
    ('archive', 'External Actions (archive)', '外部 Action（保管庫）'),
)
_FILE_BROWSER_TAB_ITEMS = {
    japanese: tuple((key, ja if japanese else en, '') for key, en, ja in _FILE_BROWSER_TABS)
    for japanese in (False, True)
}


def _file_browser_tab_items(_props, _context):
    return _FILE_BROWSER_TAB_ITEMS[_t('en', 'ja') == 'ja']


_props_annotations['file_browser_tab'] = EnumProperty(
    items=_file_browser_tab_items, options={'SKIP_SAVE'})
_props_annotations['file_browser_later_expressions'] = BoolProperty(options={'SKIP_SAVE'})

SSSUITE_ArkFaceProps = type('SSSUITE_ArkFaceProps', (PropertyGroup,), {
    '__module__': __name__, '__annotations__': _props_annotations})


def _props(context=None):
    """The UI values live on the Scene (1.10.46 fix): saved with the file (「Smooth Face」 survives a
    reopen) and changed through an undoable owner, so the UI pushes an undo step after a pad drag."""
    try:
        scene = (context or bpy.context).scene
        return getattr(scene, WM_PROP, None)
    except Exception:
        return None


def _light_report_text(rep: dict) -> str:
    if rep.get('failed'):
        head = _t('Light display: %d switched, %d failed' % (rep['count'], len(rep['failed'])),
                  '軽い表示：%d 個を切り替え、%d 個は失敗' % (rep['count'], len(rep['failed'])))
    elif rep.get('on'):
        stage = int(rep.get('stage') or 1)
        head = _t('Light display ON (stage %d): %d subdivision modifiers hidden in the viewport' % (stage, rep['count']),
                  '軽い表示 オン（段 %d）：細分化 %d 個をビューポートで止めました' % (stage, rep['count']))
        if stage == 2:
            head += _t(', %d props hidden, %d views to Solid' % (len(rep.get('hidden') or []), len(rep.get('views') or [])),
                       '、小物 %d 個を隠し、%d 個のビューをソリッドに' % (len(rep.get('hidden') or []), len(rep.get('views') or [])))
        if rep.get('face_smooth'):
            head += _t(' (face kept smooth)', '（顔は滑らか）')
    else:
        head = _t('Light display OFF: %d modifiers, %d props, %d views restored' % (
            rep['count'], len(rep.get('hidden') or []), len(rep.get('views') or [])),
            '軽い表示 オフ：細分化 %d 個・小物 %d 個・ビュー %d 個を戻しました' % (
            rep['count'], len(rep.get('hidden') or []), len(rep.get('views') or [])))
    if not rep.get('render_unchanged', True):
        head += _t(' | WARNING: render settings changed on %s' % ', '.join(rep['render_changed_objects'][:3]),
                   '｜警告：レンダー側の設定が変わった物があります（%s）' % '、'.join(rep['render_changed_objects'][:3]))
    else:
        head += _t(' | render settings unchanged (checked)', '｜レンダーの設定・レベル・順番は不変（確認済み）')
    return head


# ------------------------------------------------------------------------------------------- helpers
def _ark_face_bones(rig) -> list:
    names = []
    for pb in rig.pose.bones:
        n = pb.name
        if (n.startswith(SLIDER_PREFIX) and n != BOARD_BONE) or n.startswith(NOSE_PREFIX):
            names.append(n)
            continue
        for c in pb.constraints:
            if c.type == 'ACTION' and c.name.startswith(ARK_CONSTRAINT_PREFIX):
                names.append(n)
                break
    return names


def _esc_pressed() -> bool:
    if sys.platform != 'win32':
        return False
    try:
        import ctypes
        user32 = ctypes.windll.user32
        if not (user32.GetAsyncKeyState(0x1B) & 0x8000):
            return False
        hwnd = user32.GetForegroundWindow()
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value) == os.getpid()
    except Exception:
        return False


class _EscWatch:
    def __init__(self):
        self.n = 0
        self.frames = 0

    def check(self, phase: str) -> None:
        self.n += 1
        if _TEST_CANCEL_AFTER is not None and self.n >= int(_TEST_CANCEL_AFTER):
            raise _ArkCancelled(phase)
        if _esc_pressed():
            raise _ArkCancelled(phase)


def _copy_key(k, p) -> None:
    """Every stored attribute of a keyframe: value, handles, interpolation, easing, key type and the
    BACK / ELASTIC parameters (a BREAKDOWN or JITTER key comes back as itself)."""
    p.co = k.co
    p.interpolation = k.interpolation
    p.easing = k.easing
    p.type = k.type
    p.back = k.back
    p.amplitude = k.amplitude
    p.period = k.period
    p.handle_left_type = k.handle_left_type
    p.handle_right_type = k.handle_right_type
    p.handle_left = k.handle_left
    p.handle_right = k.handle_right


def _copy_keyframes(src, dst) -> None:
    pts = dst.keyframe_points
    pts.clear()
    pts.add(len(src.keyframe_points))
    for k, p in zip(src.keyframe_points, pts):
        _copy_key(k, p)
    dst.update()


def _drop_actions(actions) -> list:
    """Remove the given actions when nothing but their fake user holds them."""
    removed = []
    for a in actions:
        try:
            if a.use_fake_user:
                a.use_fake_user = False
            if a.users == 0:
                name = a.name
                bpy.data.actions.remove(a)
                removed.append(name)
        except Exception:
            pass
    return removed


def _slot_bag(action, identifier):
    from bpy_extras import anim_utils
    if action is None:
        return None
    for s in action.slots:
        if s.identifier == identifier:
            return anim_utils.action_get_channelbag_for_slot(action, s)
    return None


def _rollback_bake(rig, actions_before: set, had_action: bool, groups_before: set, touched: list) -> dict:
    """Undo a cancelled ark_bake: put touched F-curves back from the backup the Text just made."""
    ad = rig.animation_data
    new_actions = [a for a in bpy.data.actions if a.name not in actions_before]
    backups = [a for a in new_actions if '_prebake_' in a.name]
    out = {'restored_curves': 0, 'removed_curves': 0, 'backup': backups[-1].name if backups else '',
           'removed_backups': []}
    if ad is None or ad.action is None:
        out['removed_backups'] = _drop_actions(backups)
        out['backup'] = ''
        return out
    if not had_action:
        act = ad.action
        ad.action = None
        out['removed_backups'] = _drop_actions([act] + backups)
        out['backup'] = ''
        out['removed_new_action'] = True
        return out
    act = ad.action
    slot = ad.action_slot
    bag = _slot_bag(act, slot.identifier) if slot is not None else None
    src_bag = _slot_bag(backups[-1], slot.identifier) if (backups and slot is not None) else None
    if bag is not None:
        for path, idx in dict.fromkeys(touched):
            fc = bag.fcurves.find(path, index=idx)
            if fc is None:
                continue
            src = src_bag.fcurves.find(path, index=idx) if src_bag is not None else None
            if src is None or len(src.keyframe_points) == 0:
                bag.fcurves.remove(fc)
                out['removed_curves'] += 1
            else:
                _copy_keyframes(src, fc)
                out['restored_curves'] += 1
        try:
            for g in list(bag.groups):
                if g.name not in groups_before and len(g.channels) == 0:
                    bag.groups.remove(g)
        except Exception:
            pass
    # The backup the Text made for this (cancelled) bake is no longer needed: remove it so a cancel
    # does not leave one more fake-user action in the file each time.
    out['removed_backups'] = _drop_actions(backups)
    out['backup'] = ''
    return out


_POSE_ATTRS = ('location', 'rotation_quaternion', 'rotation_euler', 'rotation_axis_angle', 'scale')


def _value_snapshot(rig) -> dict:
    """Pose-bone transform values and ark_hand_* values of the rig, to put back after a cancelled bake."""
    pose = {}
    for pb in rig.pose.bones:
        pose[pb.name] = tuple(tuple(getattr(pb, a)) for a in _POSE_ATTRS)
    props = {}
    for k in list(rig.keys()):
        if str(k).startswith('ark_hand_') or k in HAND_PROPS:
            v = rig[k]
            if isinstance(v, (int, float)):
                props[k] = v
    return {'pose': pose, 'props': props}


def _write_back_values(rig, snap: dict) -> dict:
    """Write the snapshot values back where they differ (review E1: a cancelled bake removed its F-curves
    but left the last baked values on the bones and ark_hand_*, so the ARK constraints added them twice)."""
    out = {'pose_channels': 0, 'props': 0}
    pose = snap.get('pose') or {}
    for pb in rig.pose.bones:
        rec = pose.get(pb.name)
        if rec is None:
            continue
        for a, val in zip(_POSE_ATTRS, rec):
            try:
                if tuple(getattr(pb, a)) != val:
                    setattr(pb, a, val)
                    out['pose_channels'] += 1
            except Exception:
                pass
    keys = set(rig.keys())
    for k, v in (snap.get('props') or {}).items():
        if k not in keys:
            continue
        try:
            if rig[k] != v:
                rig[k] = v
                out['props'] += 1
        except Exception:
            pass
    return out


def _run_text_bake(context) -> dict:
    rig = find_rig()
    if rig is None:
        raise ArkError(_t('No ARKit rig', '顔 ARKit のリグがありません'))
    ns = load_tools()
    from bpy_extras import anim_utils
    ad = rig.animation_data
    had_action = bool(ad is not None and ad.action is not None)
    groups_before = set()
    if had_action and ad.action_slot is not None:
        bag0 = anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot)
        if bag0 is not None:
            groups_before = set(g.name for g in bag0.groups)
    actions_before = set(a.name for a in bpy.data.actions)
    values_before = _value_snapshot(rig)
    try:
        frame_before = (int(context.scene.frame_current), float(context.scene.frame_subframe))
    except Exception:
        frame_before = None
    watch = _EscWatch()
    touched = []
    orig_hand = ns['_hand_values']
    orig_write = ns['_write_keys']
    orig_capture = ns['_capture']

    def hand_values(read, frame):
        watch.check('compute')
        watch.frames += 1
        if watch.frames % 50 == 0:
            print('SmartSelector 顔を焼く: %d コマ目を計算中（Esc で中断）' % watch.frames)
        return orig_hand(read, frame)

    def write_keys(rig_, bag, path, index, frames, values, group):
        watch.check('write')
        touched.append((path, index))
        return orig_write(rig_, bag, path, index, frames, values, group)

    def capture(objs):
        if not touched:
            watch.check('prepare')
        return orig_capture(objs)

    ns['_hand_values'] = hand_values
    ns['_write_keys'] = write_keys
    ns['_capture'] = capture
    try:
        with _LightOff():
            rep = ns['ark_bake']()
    except _ArkCancelled as exc:
        rb = _rollback_bake(rig, actions_before, had_action, groups_before, touched)
        # F-curves alone are not enough: put the pre-bake values back, then evaluate the frame again so
        # channels that still have F-curves take their (restored) curve values.
        rb['written_back'] = _write_back_values(rig, values_before)
        try:
            rig.update_tag()
            if frame_before is not None:
                context.scene.frame_set(frame_before[0], subframe=frame_before[1])
            context.view_layer.update()
        except Exception:
            pass
        return {'ok': False, 'cancelled': True, 'phase': str(exc), 'rollback': rb}
    if isinstance(rep, dict) and rep.get('ok'):
        # What a rollback after a failed shape check needs (1.10.48 review fix 2, D1).
        rep['_txn'] = {'actions_before': actions_before, 'had_action': had_action, 'groups_before': groups_before,
                       'touched': list(touched), 'values_before': values_before, 'frame_before': frame_before}
    return rep


_BAKE_ACTION_KEYS = ('ark_baked_channels', 'ark_baked_extra', 'ark_bake_static', 'ark_bake_backup', 'ark_bake_slot', 'ark_bake_range')
_HAND_KS_LABEL = '顔の手付け'


def _hand_keying_set(scene):
    for k in scene.keying_sets:
        if k.bl_label == _HAND_KS_LABEL:
            return k
    return None


def _bake_state_snapshot(rig, scene) -> dict:
    """What ark_bake changes besides the keys: constraint switches, ark_live, the two bone collections, the hand keying set."""
    ad = rig.animation_data
    act = ad.action if ad is not None else None
    ks = _hand_keying_set(scene)
    colls = {}
    for n in ('ARKit52', 'ARKit52_hand'):
        c = rig.data.collections_all.get(n)
        if c is not None:
            colls[n] = bool(c.is_visible)
    return {'cons': {(pb.name, c.name): bool(c.enabled) for pb in rig.pose.bones for c in pb.constraints},
            'ark_live': rig['ark_live'] if 'ark_live' in rig.keys() else None,
            'colls': colls,
            'act_keys': set(k for k in act.keys() if k in _BAKE_ACTION_KEYS) if act is not None else set(),
            'ks': None if ks is None else [(p.id, p.data_path, int(p.array_index), p.group_method, p.group, bool(p.use_entire_array))
                                          for p in ks.paths],
            'ks_active': int(scene.keying_sets.active_index)}


def _undo_text_bake(rig, context, txn: dict, state: dict) -> dict:
    """Put the rig back to before a bake that failed the shape check: the keys (from the Text's own backup, which is then
    removed), the bake record on the action, the constraint switches, ark_live, the bone collections, the hand keying set
    and the values."""
    scene = context.scene
    out = _rollback_bake(rig, txn['actions_before'], txn['had_action'], txn['groups_before'], txn['touched'])
    ad = rig.animation_data
    act = ad.action if ad is not None else None
    if act is not None:
        for k in _BAKE_ACTION_KEYS:
            if k in act.keys() and k not in state['act_keys']:
                del act[k]
    n = 0
    for pb in rig.pose.bones:
        for c in pb.constraints:
            want = state['cons'].get((pb.name, c.name))
            if want is not None and bool(c.enabled) != want:
                c.enabled = want
                n += 1
    out['constraints'] = n
    if state['ark_live'] is None:
        if 'ark_live' in rig.keys():
            del rig['ark_live']
    else:
        rig['ark_live'] = state['ark_live']
    for name, vis in state['colls'].items():
        c = rig.data.collections_all.get(name)
        if c is not None:
            c.is_visible = vis
    ks = _hand_keying_set(scene)
    if ks is not None:
        try:
            while len(ks.paths):
                ks.paths.remove(ks.paths[0])
            for idb, path, idx, gm, grp, whole in state['ks'] or []:
                if idb is not None:
                    ks.paths.add(idb, path, index=-1 if whole else idx, group_method=gm, group_name=grp)
            if state['ks'] is None:
                out['keying_set_left_empty'] = ks.bl_label
            scene.keying_sets.active_index = state['ks_active']
        except Exception as exc:
            out['keying_set_error'] = str(exc)
    out['written_back'] = _write_back_values(rig, txn['values_before'])
    try:
        rig.update_tag()
        fb = txn.get('frame_before')
        if fb is not None:
            scene.frame_set(fb[0], subframe=fb[1])
        context.view_layer.update()
    except Exception:
        pass
    return out


def _bake_check_frames(rig, scene) -> list:
    """Frames for the shape check: inside the range ark_bake() (no arguments) bakes -- the scene range joined with the
    keyed range of the sliders and ark_hand_* (Text _keyed_range).  Outside it the Text leaves the keys alone by design."""
    lo, hi = float(scene.frame_start), float(scene.frame_end)
    try:
        from bpy_extras import anim_utils
        ns = load_tools()
        act = base_action(rig)      # the base (not the layer being tweaked): the bake runs after the edit is left
        slot = _base_slot(rig) if act is not None else None
        bag = anim_utils.action_get_channelbag_for_slot(act, slot) if slot is not None else None
        keyed = ns['_keyed_range'](bag) if bag is not None else None
        if keyed:
            lo, hi = min(lo, float(keyed[0])), max(hi, float(keyed[1]))
    except Exception:
        pass
    # 1.10.49 (D3): plus the strip bounds / middles and the key frames inside the range.
    return _extra_check_frames(rig, lo, hi, _check_frames(lo, hi))


# Internal test hook (1.10.49, D3): when True, the face bake does not refuse a live user track on the baked channels
# while the base replaces (REPLACE), so the widened shape check can be exercised on its own.  Always None.
_TEST_NO_REPLACE_BLOCK = None


def _bake_read_channels(rig) -> set:
    """Data paths the Text's ark_bake writes (its _plan: the ARK-driven bones, every axis it keys; ark_hand_*) or reads
    (the 52 sliders cc_arkit_*).  On a failure to read the plan: every c_* / cc_* bone transform and ark_hand_*."""
    paths = set('["%s"]' % p for p in HAND_PROPS)
    try:
        ns = load_tools()
        for _bn, path, _idx, _kind, _lst in ns['_plan'](rig):
            paths.add(path)
        for p in ns.get('HAND_PROPS', ()):
            paths.add('["%s"]' % p)
    except Exception as exc:
        print('SmartSelector bake channel plan not read (%s): using every c_* / cc_* bone' % exc)
        return None
    for pb in rig.pose.bones:
        if pb.name.startswith(SLIDER_PREFIX):
            paths.add('pose.bones["%s"].location' % bpy.utils.escape_identifier(pb.name))
    return paths


def _base_covered_channels(rig) -> set:
    """1.10.49 review: (data_path, index) the base action sets on EVERY frame while it REPLACEs the tracks below it --
    blend REPLACE, influence 1, extrapolation HOLD, an F-curve with keys that is not muted (nor its group) and has no
    range-restricted modifier.  A user track below such a channel is never seen, so baking it loses nothing (measured:
    base 0.5 / track 0.2 -> 0.5 with the track live or muted).  Empty (nothing exempted) in tweak mode or on any doubt."""
    from bpy_extras import anim_utils
    out = set()
    try:
        ad = rig.animation_data
        if ad is None or ad.use_tweak_mode or ad.action is None:
            return out
        if str(ad.action_blend_type) != 'REPLACE' or float(ad.action_influence) < 1.0 - 1e-6:
            return out
        if str(ad.action_extrapolation) != 'HOLD':
            return out
        slot = ad.action_slot
        bag = anim_utils.action_get_channelbag_for_slot(ad.action, slot) if slot is not None else None
        if bag is None:
            return out
        for fc in bag.fcurves:
            if fc.mute or not len(fc.keyframe_points):
                continue
            if fc.group is not None and fc.group.mute:
                continue
            if any(m.use_restricted_range for m in fc.modifiers):
                continue
            out.add((fc.data_path, int(fc.array_index)))
    except Exception as exc:
        print('SmartSelector base channels not read (%s): no track is exempted' % exc)
        return set()
    return out


def replace_user_tracks_on_bake(rig) -> list:
    """1.10.49 (D3): [(track name, [channel, ...])] of the live user NLA tracks that animate a channel the face bake writes or
    reads, while the base action REPLACEs the tracks below it (no layers).  The bake keys those channels on every frame of
    its range from the base alone, so the track's share would be replaced by another value (measured 0.28-0.40 mm where
    the track acts only between the checked frames).  The bake refuses them.
    1.10.50 (D4): the strips inside META strips are read too, and a live user track with a strip that cannot be read
    (no action and not META: a transition, a sound strip...) is refused whatever the blend, naming the strip."""
    if rig is None:
        return []
    tracks = live_user_tracks(rig) if getattr(rig, 'animation_data', None) is not None else []
    out = []
    for t in tracks:
        bad = _unreadable_strips(t.strips)
        if bad:
            out.append((t.name, ['strip %s: channels not readable' % b for b in bad]))
    if user_tracks_add_to_base(rig):
        return out
    tracks = [t for t in tracks if t.name not in set(n for n, _c in out)]
    if not tracks:
        return out
    paths = _bake_read_channels(rig)
    covered = _base_covered_channels(rig)
    for t in tracks:
        hit = []
        for path, idx in _layer_channels([t]):
            if (path, int(idx)) in covered:
                continue        # the base replaces it on every frame: the track is not seen, the bake loses nothing
            if paths is None:
                ok = ('["ark_hand_' in path) or _bone_group(path).startswith(('c_', 'cc_'))
            else:
                ok = path in paths
            if ok:
                hit.append('%s[%d]' % (path, idx))
        if hit:
            out.append((t.name, list(dict.fromkeys(hit))))
    return out


def _bake_record(rig) -> dict | None:
    """What ark_bake wrote on the action (read before ark_restore deletes it)."""
    ad = rig.animation_data
    act = ad.action if ad is not None else None
    if act is None or 'ark_baked_channels' not in act.keys():
        return None
    try:
        return {'backup': str(act.get('ark_bake_backup', '')), 'slot': str(act.get('ark_bake_slot', '')),
                'range': [float(x) for x in list(act['ark_bake_range'])],
                'channels': [(str(p), int(i)) for p, i in json.loads(act['ark_baked_channels'])],
                'static': json.loads(act['ark_bake_static']) if 'ark_bake_static' in act.keys() else {}}
    except Exception:
        return None


def _restore_prebake_keys(rig, rec) -> dict:
    """Put back the keys (and key-less values of ark_hand_*) that existed before the bake.

    Text ARK_facial_tools.py ark_restore() (MIK_192) removes every key inside the baked range of every
    baked channel, but brings keys back from the bake's backup action only for the "extra" axes.  Keys the
    animator had made before baking -- on ark_hand_* (review D2: ark_hand_aux_mouthFunnel, 0.4704 mm) or on
    an ARK-driven c_* channel -- were lost, and a key-less ark_hand_* value was reset to its default.
    This adds back exactly the pre-bake keys inside the range from that backup (rig_action_prebake_NNN),
    with all their attributes.  Keys already present at a frame are left alone, so it does nothing for
    channels the Text already restored, and nothing at all once the Text is fixed."""
    out = {'keys': 0, 'values': 0, 'channels': []}
    if rec is None:
        return out
    pre = bpy.data.actions.get(rec['backup']) if rec.get('backup') else None
    pre_bag = _slot_bag(pre, rec['slot']) if pre is not None and rec.get('slot') else None
    ad = rig.animation_data
    if ad is None or ad.action is None or ad.action_slot is None:
        return out
    from bpy_extras import anim_utils
    bag = anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot)
    f0, f1 = rec['range']
    channels = list(dict.fromkeys(list(rec.get('channels') or []) + [('["%s"]' % p, 0) for p in HAND_PROPS]))
    for path, idx in channels:
        src = pre_bag.fcurves.find(path, index=idx) if pre_bag is not None else None
        ks = [k for k in src.keyframe_points if f0 - 1e-4 <= k.co.x <= f1 + 1e-4] if src is not None else []
        if not ks:
            continue
        fc = bag.fcurves.find(path, index=idx) if bag is not None else None
        if fc is None:
            if bag is None:
                bag = anim_utils.action_ensure_channelbag_for_slot(ad.action, ad.action_slot)
            group = src.group.name if src.group is not None else ''
            fc = bag.fcurves.new(path, index=idx, group_name=group) if group else bag.fcurves.new(path, index=idx)
        # Inside the range, the only keys left after ark_restore are the ones it copied back itself from
        # this same backup (extra axes) -- without key type, BACK / ELASTIC parameters.  Give those keys
        # every attribute of the backup key; add the keys that are missing.
        add = []
        fixed = 0
        for k in ks:
            hit = None
            for p in fc.keyframe_points:
                if abs(p.co.x - k.co.x) < 1e-4:
                    hit = p
                    break
            if hit is None:
                add.append(k)
            elif (hit.type != k.type or hit.interpolation != k.interpolation or hit.easing != k.easing
                  or abs(hit.back - k.back) > 1e-7 or abs(hit.amplitude - k.amplitude) > 1e-7 or abs(hit.period - k.period) > 1e-7
                  or hit.handle_left_type != k.handle_left_type or hit.handle_right_type != k.handle_right_type
                  or abs(hit.co.y - k.co.y) > 1e-9):
                _copy_key(k, hit)
                fixed += 1
        if add:
            pts = fc.keyframe_points
            n0 = len(pts)
            pts.add(len(add))
            for j, k in enumerate(add):
                _copy_key(k, pts[n0 + j])
        if not add and not fixed:
            continue
        fc.update()
        out['keys'] += len(add)
        out['fixed'] = out.get('fixed', 0) + fixed
        out['channels'].append('%s[%d]' % (path, idx))
    # ark_hand_* without keys before the bake: the Text resets them to the default; give back the value.
    static = rec.get('static') or {}
    for p in HAND_PROPS:
        path = '["%s"]' % p
        key = '%s|0' % path
        has_fc = bag is not None and bag.fcurves.find(path, index=0) is not None
        if has_fc or key not in static or p not in rig.keys():
            continue
        v = float(static[key])
        if abs(float(rig[p]) - v) > 1e-9:
            rig[p] = v
            out['values'] += 1
            out['channels'].append(path)
    if out['keys'] or out['values'] or out.get('fixed'):
        try:
            rig.update_tag()
            bpy.context.view_layer.update()
        except Exception:
            pass
    return out


def _find_area(context, area_type: str):
    try:
        if context.area is not None and context.area.type == area_type:
            return context.window, context.area
    except Exception:
        pass
    try:
        for win in context.window_manager.windows:
            for area in win.screen.areas:
                if area.type == area_type:
                    return win, area
    except Exception:
        pass
    return None, None


def _window_region(area):
    for r in area.regions:
        if r.type == 'WINDOW':
            return r
    return None


_CURVE_TOOLS = (
    # key, module, operator, takes factor, label en, label ja, description en, description ja
    ('GAUSSIAN', 'graph', 'gaussian_smooth', True, 'Smooth (Gaussian)', 'なだらか（ガウス）',
     'Smooth the selected keys with a Gaussian filter',
     '選んだキーをガウスでなだらかにします'),
    ('BUTTERWORTH', 'graph', 'butterworth_smooth', False, 'Smooth (Butterworth)', 'なだらか（バターワース）',
     'Remove fine jitter of the selected keys by frequency',
     '選んだキーの細かい揺れを周波数で落とします'),
    ('GRAPH_BLEND_NEIGHBOR', 'graph', 'blend_to_neighbor', True, 'Blend Keys to Neighbor', '隣へ寄せる',
     'Blend the selected keys toward the neighbouring keys',
     '選んだキーを前後のキーへ寄せます'),
    ('EASE', 'graph', 'ease', True, 'Ease Keys', 'イーズ',
     'Align the selected keys on an ease curve between the neighbouring keys',
     '選んだキーを前後のキーの間でイーズの形に並べます'),
    ('BLEND_OFFSET', 'graph', 'blend_offset', True, 'Blend Keys Offset', 'ずらして寄せる',
     'Shift the selected block of keys to match the neighbouring keys',
     '選んだキーの塊を前後のキーへずらして合わせます'),
    ('DECIMATE', 'graph', 'decimate', False, 'Decimate Keys', 'キーを間引く',
     'Remove keys within the allowed error and report the difference to the original',
     '許す誤差の中でキーを間引き、元との差を報告します'),
    ('RELAX', 'pose', 'relax', True, 'Relax Pose', 'ほぐす',
     'Relax the current-frame pose of the selected bones toward the neighbouring keys',
     '選んだ骨の今のフレームの姿勢を前後のキーの間へほぐします'),
    ('PUSH', 'pose', 'push', True, 'Push Pose', '強める',
     'Push the current-frame pose of the selected bones away from the neighbouring keys',
     '選んだ骨の今のフレームの姿勢を前後のキーから押し出します'),
    ('POSE_BLEND_NEIGHBOR', 'pose', 'blend_to_neighbor', True, 'Blend to Neighbor Pose', '隣のポーズへ寄せる',
     'Blend the current-frame pose of the selected bones toward the neighbouring keys',
     '選んだ骨の今のフレームの姿勢を前後のキーへ寄せます'),
)
_CURVE_TOOL_MAP = {t[0]: t for t in _CURVE_TOOLS}

_GUARD_TARGETS = (
    # key, module, operator, call, kwargs, label en, label ja, description en, description ja
    ('PTCACHE_BAKE_ALL', 'ptcache', 'bake_all', 'EXEC', {'bake': True},
     'Release and Bake All Caches', '解除して全キャッシュを焼く',
     'Release the light display, bake every physics cache (cloth and so on), then put it back',
     '軽い表示を解除してから、全部の物理キャッシュ（クロス等）を焼き、終わったら戻します'),
    ('VIEWPORT_RENDER', 'render', 'opengl', 'EXEC', {},
     'Release and Viewport Render (Image)', '解除してビューポートレンダー（静止画）',
     'Release the light display, render a viewport still, then put it back',
     '軽い表示を解除してからビューポートの静止画を描き、終わったら戻します'),
    ('VIEWPORT_RENDER_ANIM', 'render', 'opengl', 'EXEC', {'animation': True},
     'Release and Viewport Render (Animation)', '解除してビューポートレンダー（動画）',
     'Release the light display, write the viewport animation, then put it back',
     '軽い表示を解除してからビューポートの動画を書き出し、終わったら戻します'),
    ('SRS_JIGGLE_BAKE', 'srs', 'jiggle_bake', 'INVOKE', {},
     'Release and Bake SmartRig Jiggle', '解除して SmartRig の揺れを焼く',
     'Release the light display and open the SmartRig jiggle bake. When it continues in a dialog, '
     'the light display stays released (switch it on again afterwards)',
     '軽い表示を解除してから SmartRig の揺れの焼きを開きます。'
     '確認の画面などで続く時は、解除したままにします（終わったら「軽い表示」をもう一度押してください）'),
    ('SRS_PART_BAKE', 'srs', 'part_bake', 'INVOKE', {},
     'Release and Bake SmartRig Parts', '解除して SmartRig の部位を焼く',
     'Release the light display and open the SmartRig part bake. When it continues, it stays released',
     '軽い表示を解除してから SmartRig の部位の焼きを開きます。続く時は解除したままにします'),
    ('SRS_CLOTH_BAKE', 'srs', 'cloth_bake', 'INVOKE', {},
     'Release and Bake SmartRig Cloth', '解除して SmartRig のクロスを焼く',
     'Release the light display and open the SmartRig cloth bake. When it continues, it stays released',
     '軽い表示を解除してから SmartRig のクロスの焼きを開きます。続く時は解除したままにします'),
)
_GUARD_MAP = {t[0]: t for t in _GUARD_TARGETS}


def _op_available(module: str, name: str) -> bool:
    try:
        getattr(getattr(bpy.ops, module), name).get_rna_type()
        return True
    except Exception:
        return False


def _rig_reachable(context, rig):
    """(ok, message): the rig can become the active object in Pose Mode.

    An eye-icon hide (hide_set) is lifted as before.  A monitor-icon hide (hide_viewport), a hidden or
    excluded collection cannot be lifted here: then nothing is changed and the reason is returned,
    instead of object.mode_set raising "Cannot edit hidden object" after the selection was changed."""
    vl = context.view_layer
    try:
        in_layer = vl.objects.get(rig.name) is not None
    except Exception:
        in_layer = False
    if not in_layer:
        return False, _t('The rig "%s" is not in this view layer (its collection is excluded). Include it first.' % rig.name,
                         'rig「%s」がこのビューレイヤーにありません（コレクションが除外されています）。先に含めてください' % rig.name)
    try:
        was_hidden = bool(rig.hide_get(view_layer=vl))
    except Exception:
        was_hidden = False
    if was_hidden:
        try:
            rig.hide_set(False, view_layer=vl)
        except Exception:
            pass
    try:
        visible = bool(rig.visible_get(view_layer=vl))
    except Exception:
        visible = False
    if not visible:
        if was_hidden:
            try:
                rig.hide_set(True, view_layer=vl)
            except Exception:
                pass
        return False, _t('The rig "%s" is hidden (monitor icon or hidden collection). Show it first.' % rig.name,
                         'rig「%s」が非表示です（モニターのアイコンかコレクションの非表示）。先に表示してください' % rig.name)
    return True, ''


class _SelState:
    """Active object, object selection and mode, to put back when entering the rig's Pose Mode fails."""

    def __init__(self, context):
        vl = context.view_layer
        self.vl = vl
        self.active = vl.objects.active
        self.mode = self.active.mode if self.active is not None else 'OBJECT'
        self.selected = [ob for ob in vl.objects if ob.select_get(view_layer=vl)]

    def restore(self):
        vl = self.vl
        try:
            if vl.objects.active is not None and vl.objects.active.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        try:
            for ob in vl.objects:
                ob.select_set(ob in self.selected, view_layer=vl)
        except Exception:
            pass
        try:
            vl.objects.active = self.active
        except Exception:
            pass
        if self.active is not None and self.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode=self.mode)
            except Exception:
                pass


def _enter_rig_pose(context, rig):
    """Make the rig active in Pose Mode.  Returns (ok, message, state); on failure everything is put back."""
    ok, msg = _rig_reachable(context, rig)
    if not ok:
        return False, msg, None
    state = _SelState(context)
    vl = context.view_layer
    try:
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        rig.select_set(True, view_layer=vl)
        vl.objects.active = rig
        bpy.ops.object.mode_set(mode='POSE')
    except Exception as exc:
        state.restore()
        return False, _t('Cannot enter Pose Mode of "%s": %s' % (rig.name, str(exc)[:120]),
                         '「%s」のポーズモードに入れません。' % rig.name), None
    return True, '', state


def _blend_name(blend, japanese: bool) -> str:
    names = {'COMBINE': ('Add', '加算'), 'REPLACE': ('Replace', '置換'), 'ADD': ('Add', '足し算'), 'SUBTRACT': ('Subtract', '引き算'), 'MULTIPLY': ('Multiply', '掛け算')}
    return names.get(str(blend), (str(blend), str(blend)))[1 if japanese else 0]


# ----------------------------------------------------------------------------------------- operators
class _ArkOp:
    bl_options = {'REGISTER', 'UNDO'}
    # Rig-file Texts this operator executes (checked against Blender's Auto Run trust).
    _texts = ()

    @classmethod
    def _need_rig(cls):
        if find_rig() is None:
            cls.poll_message_set(_t('No armature with cc_arkit_board in this file',
                                    'cc_arkit_board を持つアーマチュアがありません'))
            return False
        return True

    @classmethod
    def _need_text(cls, name):
        if not _has_text(name):
            cls.poll_message_set(_t('Text "%s" is not in this file' % name, 'このファイルに Text「%s」がありません' % name))
            return False
        return True

    def _untrusted(self) -> list:
        if not _exec_script_allowed():
            return []
        return [n for n in self._texts if _has_text(n) and not text_trusted(n)]

    def _confirm(self, context, event, message: str = ''):
        """Ask before running.  When a Text that would be executed is not trusted by Blender's Auto Run,
        the dialog names it, and OK approves exactly that Text (this file, this content) for the session."""
        untrusted = self._untrusted()
        if untrusted:
            self.approve_texts = True
            message = _untrusted_message(untrusted) + ((' ' + message) if message else '')
        if not message:
            return self.execute(context)
        return context.window_manager.invoke_confirm(self, event, title=_t(self.bl_label, self._label_ja), message=message)

    def _take_approval(self) -> None:
        if getattr(self, 'approve_texts', False):
            for n in self._texts:
                _approve_text(n)

    def _finish(self, text: str, ok: bool = True, changed: bool = None):
        """ok=False reports a WARNING.  ``changed`` (default: ok) says whether data was written: then FINISHED is
        returned even with a warning, so the change gets its own Undo step (1.10.48 review fix)."""
        _set_report(text, ok)
        self.report({'INFO'} if ok else {'WARNING'}, text)
        _tag_redraw()
        return {'FINISHED'} if (ok if changed is None else changed) else {'CANCELLED'}


_APPROVE_PROP = dict(name='Approve Texts', description='Set by the confirmation dialog: run the rig Texts of this file this session',
                     default=False, options={'HIDDEN', 'SKIP_SAVE'})


class SSSUITE_OT_ark_light_toggle(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_light_toggle'
    bl_label = 'Light Display'
    _label_ja = '軽い表示'
    bl_description = ('Toggle the light display (viewport only). Stage 1: the non-last subdivision modifiers (Subdivision Surface, Multiresolution) on every mesh. '
                      'Stage 2: also the last subdivision, the small props (hidden) and Solid shading. '
                      'Render settings, levels and order are never changed and are checked after the switch. The state to restore is kept in the file')
    state: EnumProperty(name='Light Display Switch', description='How to switch the light display', items=(
        ('TOGGLE', 'Toggle Light Display', 'Switch the light display on when off, off when on'),
        ('ON', 'Light Display On', 'Turn the light display on'),
        ('OFF', 'Light Display Off', 'Return to the original display')), default='TOGGLE', options={'SKIP_SAVE'})

    def execute(self, context):
        props = _props(context)
        target = {'ON': True, 'OFF': False}.get(self.state, not light_is_on())
        rep = light_set(True, **_props_params(props)) if target else light_set(False)
        ok = rep['render_unchanged'] and not rep['failed'] and rep['state_ok']
        return self._finish(_light_report_text(rep), ok)


class SSSUITE_OT_ark_light_guarded_run(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_light_guarded_run'
    bl_label = 'Run with Light Display Released'
    _label_ja = '軽い表示を解除して実行'
    bl_description = 'Release the light display, run the bake / cache / render operator, then put the light display back'
    target: EnumProperty(name='Operation to Run Released', description='Operator to run after releasing the light display',
                         items=tuple((t[0], t[5], t[7]) for t in _GUARD_TARGETS), options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        t = _GUARD_MAP.get(getattr(properties, 'target', ''), None)
        return _t(t[7], t[8]) if t else _t(cls.bl_description, '軽い表示を自動で解除してから焼き・キャッシュ・レンダーの操作を行い、終わったら軽い表示へ戻します')

    def execute(self, context):
        spec = _GUARD_MAP.get(self.target)
        if spec is None:
            return {'CANCELLED'}
        _key, mod, name, how, kw, label_en, label_ja, _de, _dj = spec
        label = _t(label_en, label_ja)
        if not _op_available(mod, name):
            return self._finish(_t('%s.%s is not available (add-on disabled?)' % (mod, name),
                                   '%s.%s がありません（アドオンが無効です）' % (mod, name)), False)
        st = light_status()
        params = _status_params(st) if st['on'] else None
        if st['on']:
            light_set(False)
        op = getattr(getattr(bpy.ops, mod), name)
        result = set()
        err = ''
        try:
            result = op('INVOKE_DEFAULT', **kw) if how == 'INVOKE' else op('EXEC_DEFAULT', **kw)
        except Exception as exc:
            err = exception_text(exc)
        if st['on']:
            if 'RUNNING_MODAL' in result:
                return self._finish(_t('%s started; light display stays OFF until you switch it on again' % label,
                                       '%s を始めました。軽い表示は解除したままです（終わったらもう一度オンにしてください）' % label), True)
            light_set(True, **params)
        if err:
            return self._finish('%s: %s' % (label, err[:160]), False)
        return self._finish(_t('%s: %s (light display %s)' % (label, '/'.join(sorted(result)) or '-', 'restored' if st['on'] else 'was off'),
                               '%s：%s（軽い表示は%s）' % (label, '/'.join(sorted(result)) or '-', '戻しました' if st['on'] else 'もともとオフ')),
                            'FINISHED' in result)


class SSSUITE_OT_ark_face_bake(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_face_bake'
    bl_label = 'Bake Face for Hand Keys'
    _label_ja = '顔を手付け用に焼く'
    bl_description = ('Bake the result of the 52 sliders into keys on every frame of c_*, cc_nose_sneer and ark_hand_*, stop the ARK '
                      'constraints and switch to hand-key mode. The light display is '
                      'released and put back automatically. Progress shows on the mouse cursor; Esc cancels and restores from the backup')
    _texts = (TOOLS_TEXT,)
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        if not cls._need_rig() or not cls._need_text(TOOLS_TEXT):
            return False
        if not is_expression_mode(find_rig()):
            cls.poll_message_set(_t('Already in hand-key mode (use "Back to Capture State" first)',
                                    '既に手付けモードです（先に「流し込み直しの状態に戻す」）'))
            return False
        return True

    def invoke(self, context, event):
        return self._confirm(context, event, _t('Bake the 52 sliders into hand keys?', '52 本の表情を手付け用のキーに焼きますか'))

    def execute(self, context):
        self._take_approval()
        rig = find_rig()
        blocked = slider_layers(rig)
        if blocked:
            # 1.10.48 review fix (F1): a layer on the 52 sliders would silently stop working after the bake.
            return self._finish(_t('Not baked: the enabled layers %s animate the 52 sliders (cc_arkit_*). After the bake the ARK '
                                   'constraints are off and these layers would no longer move the face. Collapse them into the '
                                   'base first (or disable them), then bake' % ', '.join('"%s"' % n for n in blocked),
                                   '焼いていません：有効な層 %s が 52 本のスライダー（cc_arkit_*）を動かしています。焼いた後は ARK の拘束が'
                                   '止まるので、この層は顔を動かさなくなります。先に「畳み込む」で基層へ入れるか、無効にしてから焼いてください' %
                                   '、'.join('「%s」' % n for n in blocked)), False)
        replaced = [] if _TEST_NO_REPLACE_BLOCK else replace_user_tracks_on_bake(rig)
        if replaced:
            # 1.10.49 (D3): without layers the base replaces the user's NLA tracks, so a track on a baked channel would be
            # overwritten by the bake.  Stop before anything is changed; name the tracks and the channels.
            def _list(sep, q):
                return sep.join(q % (n, ', '.join(ch[:4]) + (' …(+%d)' % (len(ch) - 4) if len(ch) > 4 else ''))
                                for n, ch in replaced[:3])
            return self._finish(_t('Not baked: your NLA tracks act on channels the bake keys, and without layers the base '
                                   'replaces them (their share would be lost): %s. Mute these tracks, or move their keys into '
                                   'the base action, or add a layer (then they are kept on top), and bake again' %
                                   _list('; ', '"%s": %s'),
                                   '焼いていません：層ではない NLA のトラックが、焼くチャンネルを動かしています。層が無い時は基層が'
                                   'トラックを置き換えるので、トラックの分が消えます：%s。トラックをミュートするか、キーを基層へ移すか、'
                                   '層を足してから（トラックは上に残ります）焼いてください' % _list('；', '「%s」：%s')), False)
        # 1.10.48 review fix 2 (D1): the shape with every track (layers and the user's own NLA tracks), as the user sees it.
        scene = context.scene
        frame_now = (int(scene.frame_current), float(scene.frame_subframe))
        meshes = _shape_meshes(rig)
        cframes = _bake_check_frames(rig, scene)
        try:
            shape_before = _shape_capture(meshes, cframes, scene, end=frame_now)
        finally:
            if (int(scene.frame_current), float(scene.frame_subframe)) != frame_now:
                scene.frame_set(frame_now[0], subframe=frame_now[1])
        state = _bake_state_snapshot(rig, scene)
        lm = _LayersMuted(rig, users=True)
        try:
            with lm:
                rep = _run_text_bake(context)
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Bake failed: %s' % exc, '焼き落としに失敗しました：%s' % exc), False)
        if rep.get('ok') and not rep.get('cancelled'):
            shape_after = _shape_capture(meshes, cframes, scene, end=frame_now)
            mm, where, skipped = _shape_diff_mm(shape_before, shape_after)
            rep['shape_mm'], rep['shape_where'], rep['shape_skipped'] = mm, where, skipped
            if mm > SHAPE_CHECK_MM:
                rb = _undo_text_bake(rig, context, rep['_txn'], state)
                back = _shape_capture(meshes, cframes, scene)
                bmm = _shape_diff_mm(shape_before, back)[0]
                scene.frame_set(frame_now[0], subframe=frame_now[1])
                print('SmartSelector bake rolled back: %s' % {k: v for k, v in rb.items() if k != 'written_back'})
                return self._finish(_t('Not baked: with every track on, the shape changed by %.4f mm (%s, limit %.2f mm). The keys, '
                                       'constraints and expression mode were put back from the backup (difference after the rollback '
                                       '%.4f mm)' % (mm, where, SHAPE_CHECK_MM, bmm),
                                       '焼いていません：全トラック込みの形が %.4f mm 変わったため（%s、上限 %.2f mm）。キー・拘束・表情モードを'
                                       '控えから戻しました（戻した後の差 %.4f mm）' % (mm, where, SHAPE_CHECK_MM, bmm)) + lm.note(), False)
        if rep.get('cancelled'):
            rb = rep.get('rollback', {})
            n = rb.get('restored_curves', 0) + rb.get('removed_curves', 0)
            return self._finish(_t('Bake cancelled (%s). Restored %d curves from the backup and removed the backup.' % (rep.get('phase'), n),
                                   '焼き落としを中断しました（%sの途中）。控えから %d 本の F カーブを戻し、控えは消しました' % (
                                       {'prepare': '確認の準備', 'compute': '計算', 'write': '書き込み'}.get(rep.get('phase'), rep.get('phase')), n)),
                                False)
        if not rep.get('ok'):
            return self._finish(exception_text(rep.get('reason') or 'Could not complete the operation.'), False)
        text = _t('Baked %d channels, frames %s, %d constraints off, max diff %s mm (%s), backup %s' % (
            rep.get('channels', 0), rep.get('frames'), rep.get('constraints_disabled', 0), rep.get('verify_max_diff_mm'),
            'PASS' if rep.get('verify_pass') else 'CHECK', rep.get('backup')),
            '焼きました：%d チャンネル、フレーム %s、拘束 %d 本を停止、焼く前後の差 %s mm（%s）、控え %s' % (
            rep.get('channels', 0), rep.get('frames'), rep.get('constraints_disabled', 0), rep.get('verify_max_diff_mm'),
            '合格' if rep.get('verify_pass') else '要確認', rep.get('backup')))
        if rep.get('warning'):
            text += '｜' + str(rep['warning'])
        if 'shape_mm' in rep:
            text += _t(' | with every track on: %.4f mm on %d frames (PASS)' % (rep['shape_mm'], len(cframes)),
                       '｜全トラック込みの形の差 %.4f mm（%d コマ、合格）' % (rep['shape_mm'], len(cframes)))
        if rep.get('shape_skipped'):
            text += _t(' | shape not compared (vertex count changed): %s' % ', '.join(rep['shape_skipped'][:3]),
                       '｜頂点の数が変わったので形を比べなかった物：%s' % '、'.join(rep['shape_skipped'][:3]))
        return self._finish(text + lm.note(), True)


class SSSUITE_OT_ark_face_restore(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_face_restore'
    bl_label = 'Back to Capture State'
    _label_ja = '流し込み直しの状態に戻す'
    bl_description = ('Remove the keys in the baked range, enable the ARK constraints again and return to expression mode '
                      '(the current action is copied to a backup first). '
                      'Keys made before the bake are put back from the bake backup')
    _texts = (TOOLS_TEXT,)
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        return cls._need_rig() and cls._need_text(TOOLS_TEXT)

    def invoke(self, context, event):
        return self._confirm(context, event, _t('Remove the baked keys and return to expression mode? (the backup is kept)',
                                                '焼いたキーを消して表情モードへ戻しますか（控えは残ります）'))

    def execute(self, context):
        self._take_approval()
        rig = find_rig()
        rec = _bake_record(rig) if rig is not None else None
        lm = _LayersMuted(rig)
        try:
            with lm:
                rep = load_tools()['ark_restore']()
                hand = {'keys': 0, 'values': 0}
                if rep.get('ok'):
                    try:
                        hand = _restore_prebake_keys(rig, rec)
                    except Exception as exc:
                        hand = {'keys': 0, 'values': 0, 'error': exception_text(exc)}
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Restore failed: %s' % exc, '戻しに失敗しました。'), False)
        if not rep.get('ok'):
            return self._finish(exception_text(rep.get('reason') or 'Could not complete the operation.'), False)
        text_layers = lm.note()
        text = _t('Restored: %d keys removed, %d constraints on, backup %s' % (
            rep.get('keys_removed', 0), rep.get('constraints_enabled', 0), rep.get('backup')),
            '戻しました：キー %d 個を消去、拘束 %d 本を有効、控え %s' % (
            rep.get('keys_removed', 0), rep.get('constraints_enabled', 0), rep.get('backup')))
        if hand.get('keys') or hand.get('values') or hand.get('fixed'):
            nk = hand.get('keys', 0) + hand.get('fixed', 0)
            text += _t(' | pre-bake keys put back from the bake backup: %d keys, %d values' % (nk, hand['values']),
                       '｜焼く前のキーを焼いた時の控えから戻しました：キー %d 個、値 %d 個' % (nk, hand['values']))
        if hand.get('error'):
            return self._finish(text + _t(' | WARNING: pre-bake keys could not be put back: %s' % hand['error'],
                                          '｜警告：焼く前のキーを戻せませんでした：%s' % hand['error']) + text_layers, False, changed=True)
        return self._finish(text + text_layers, True)


class SSSUITE_OT_ark_reapply(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_reapply'
    bl_label = 'Re-apply after ARP Update'
    _label_ja = 'ARP 更新の後に当て直す'
    bl_description = ('After ARP Update Armature, re-apply the constraints, drivers and bones of the ARKit face rig from the spec '
                      'stored in the file. Running it again gives the same result. The SmartRig jaw / teeth / tongue clamp is never used')
    _texts = (REAPPLY_TEXT,)
    dry_run: BoolProperty(name='Dry Run Only', description='Change nothing; only report how many things differ', default=False, options={'SKIP_SAVE'})
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        return cls._need_rig() and cls._need_text(REAPPLY_TEXT) and cls._need_text(REAPPLY_SPEC_TEXT)

    def invoke(self, context, event):
        if self.dry_run:
            return self._confirm(context, event, '')
        return self._confirm(context, event, _t('Re-apply the ARKit face rig from the spec?', '正本の値へ当て直しますか'))

    def execute(self, context):
        self._take_approval()
        props = _props(context)
        try:
            ns = _exec_text(REAPPLY_TEXT, 'ark_reapply')
            fn = ns.get('ark_reapply')
            if not callable(fn):
                raise ArkError(_t('%s has no ark_reapply()' % REAPPLY_TEXT, '%s に ark_reapply がありません' % REAPPLY_TEXT))
            spec = json.loads(bpy.data.texts[REAPPLY_SPEC_TEXT].as_string())
            with _LayersMuted(find_rig()):
                rep = fn(spec=spec, dry_run=bool(self.dry_run), srs_limits=bool(getattr(props, 'reapply_srs_limits', True)))
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Re-apply failed: %s' % exc, '当て直しに失敗しました：%s' % exc), False)
        errors = list(rep.get('errors') or [])
        first = '｜' + str((rep.get('changed') or [''])[0])[:120] if rep.get('changed') else ''
        text = _t('%s: %d differences%s, %d errors%s' % ('Dry run' if self.dry_run else 'Re-applied', rep.get('changed_count', 0),
                                                         '' if self.dry_run else ' fixed', len(errors), first),
                  '%s：%d 件%s、エラー %d 件%s' % ('ずれの確認' if self.dry_run else '当て直し', rep.get('changed_count', 0),
                                            'のずれ' if self.dry_run else 'を直しました', len(errors), first))
        return self._finish(text, not errors)


class SSSUITE_OT_ark_zero_expressions(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_zero_expressions'
    bl_label = 'Expressions to 0'
    _label_ja = '表情を 0'
    bl_description = 'Set the 52 cc_arkit_* values to 0. No keys are inserted'
    _texts = (TOOLS_TEXT,)
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        return cls._need_rig() and cls._need_text(TOOLS_TEXT)

    def invoke(self, context, event):
        return self._confirm(context, event, '')

    def execute(self, context):
        self._take_approval()
        try:
            rep = load_tools()['ark_zero_expressions']()
        except Exception as exc:
            return self._finish(exception_text(exc), False)
        return self._finish(_t('%d sliders set to 0' % rep.get('zeroed', 0), '%d 本を 0 にしました' % rep.get('zeroed', 0)), True)


class SSSUITE_OT_ark_face_default(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_face_default'
    bl_label = 'Face to Default'
    _label_ja = '顔を既定へ'
    bl_description = ('Put location, rotation and scale of the ARK-driven c_* and cc_nose_sneer, and ark_hand_*, back to the defaults. '
                      'This also resets the ark_* values that ARP Reset All does not')
    _texts = (TOOLS_TEXT,)
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        return cls._need_rig() and cls._need_text(TOOLS_TEXT)

    def invoke(self, context, event):
        return self._confirm(context, event, '')

    def execute(self, context):
        self._take_approval()
        try:
            rep = load_tools()['ark_face_default']()
        except Exception as exc:
            return self._finish(exception_text(exc), False)
        return self._finish(_t('Reset %d bones and %d helper values' % (rep.get('reset_bones', 0), rep.get('hand_props', 0)),
                               '骨 %d 本と補助の値 %d 個を既定へ戻しました' % (rep.get('reset_bones', 0), rep.get('hand_props', 0))), True)


class SSSUITE_OT_ark_state_report(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_state_report'
    bl_label = 'Check State'
    _label_ja = '状態を確かめる'
    bl_description = 'Count the mode, the ARK constraints and how many are enabled, and the light display'
    bl_options = {'REGISTER'}
    _texts = (TOOLS_TEXT,)
    approve_texts: BoolProperty(**_APPROVE_PROP)

    @classmethod
    def poll(cls, context):
        return cls._need_rig() and cls._need_text(TOOLS_TEXT)

    def invoke(self, context, event):
        return self._confirm(context, event, '')

    def execute(self, context):
        self._take_approval()
        try:
            rep = load_tools()['ark_state']()
        except Exception as exc:
            return self._finish(exception_text(exc), False)
        return self._finish(_t('%s: ARK constraints %d (%d enabled), light display %s' % (
            'expression mode' if rep.get('ark_live') else 'hand-key mode', rep.get('ark_constraints', 0), rep.get('enabled', 0),
            'ON' if rep.get('light') else 'OFF'),
            '%s：ARK の拘束 %d 本（有効 %d 本）、軽い表示 %s' % (rep.get('mode'), rep.get('ark_constraints', 0), rep.get('enabled', 0),
                                                 'オン' if rep.get('light') else 'オフ')), True)


def _bone_visible(rig, pb) -> bool:
    """Whether Pose Mode shows this bone (what pose.copy and selected_pose_bones go by)."""
    if pb.hide:
        return False
    colls = pb.bone.collections
    if not colls:
        return not rig.data.collections.is_solo_active
    return any(c.is_visible_effectively for c in colls)


def _show_bones(rig, names) -> list:
    """Make the named bones visible; returns the (owner, attribute, old value) list that puts it back."""
    changes = []

    def setv(owner, attr, value):
        if getattr(owner, attr) != value:
            changes.append((owner, attr, getattr(owner, attr)))
            setattr(owner, attr, value)

    for coll in rig.data.collections_all:
        setv(coll, 'is_solo', False)
    for name in names:
        pb = rig.pose.bones.get(name)
        if pb is None:
            continue
        setv(pb, 'hide', False)
        colls = list(pb.bone.collections)
        if colls and not any(c.is_visible_effectively for c in colls):
            coll = colls[0]
            while coll is not None:
                setv(coll, 'is_visible', True)
                coll = coll.parent
    return changes


class SSSUITE_OT_ark_flip_paste(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_flip_paste'
    bl_label = 'Paste Face Flipped'
    _label_ja = '左右反転して貼る'
    bl_description = ('Copy the current pose of the selected visible face bones (all face ARKit bones when no visible face bone is selected, also those in '
                      "hidden bone collections) and paste it mirrored with Blender's Paste Flipped. "
                      'The mouthPress helper values are swapped left and right too')

    @classmethod
    def poll(cls, context):
        return cls._need_rig()

    def execute(self, context):
        rig = find_rig()
        vl = context.view_layer
        prev_active = vl.objects.active
        prev_mode = context.mode
        entered = not (prev_active == rig and prev_mode == 'POSE')
        state = None
        if entered:
            if prev_mode != 'OBJECT':
                return self._finish(_t('Switch to Object mode or to Pose mode of the rig first',
                                       'オブジェクトモードか、rig のポーズモードにしてから押してください'), False)
            ok, msg, state = _enter_rig_pose(context, rig)
            if not ok:
                return self._finish(msg, False)
        selected_before = [pb.name for pb in rig.pose.bones if pb.select]
        face_bones = _ark_face_bones(rig)
        # A selection left on a hidden bone is not on screen, so it does not count as chosen.
        chosen = {n for n in selected_before if n in face_bones and _bone_visible(rig, rig.pose.bones[n])}
        targets = sorted(chosen) if chosen else face_bones
        result = set()
        err = ''
        # pose.copy takes only visible selected bones, and the face bones normally sit in a hidden bone collection.
        shown = _show_bones(rig, targets)
        try:
            for pb in rig.pose.bones:
                pb.select = pb.name in targets
            if not any(pb.select for pb in rig.pose.bones):
                err = _t('No face bones to copy', '写す顔の骨がありません')
            else:
                bpy.ops.pose.copy()
                result = bpy.ops.pose.paste(flipped=True, selected_mask=False)
        except Exception as exc:
            err = exception_text(exc)
        finally:
            sel = set(selected_before)
            for pb in rig.pose.bones:
                pb.select = pb.name in sel
            for owner, attr, value in reversed(shown):
                setattr(owner, attr, value)
        swapped = []
        try:
            auto = bool(context.scene.tool_settings.use_keyframe_insert_auto)
        except Exception:
            auto = False
        if not err:
            for p in HAND_PROPS:
                q = bpy.utils.flip_name(p)
                if q != p and q in HAND_PROPS and p < q and p in rig.keys() and q in rig.keys():
                    rig[p], rig[q] = rig[q], rig[p]
                    swapped.append(p.replace('ark_hand_aux_', '').replace('Left', '').replace('Right', ''))
                    if auto:
                        for n in (p, q):
                            try:
                                rig.keyframe_insert(data_path='["%s"]' % n, group='ARK hand')
                            except Exception:
                                pass
        rig.update_tag()
        if entered and state is not None:
            state.restore()
        if err:
            return self._finish(_t('Flip paste failed: %s' % err, '左右反転の貼り付けに失敗しました：%s' % err), False)
        return self._finish(_t('Pasted flipped onto %d bones (%s)%s' % (len(targets), 'selection' if chosen else 'all face bones', ('; helper values %s swapped left and right' % ', '.join(swapped)) if swapped else ''),
                               '%d 本を左右反転して貼りました（%s）%s' % (len(targets), '選んだ骨' if chosen else '顔の骨すべて', ('。補助の値 %s の左右も入れ替えました' % '、'.join(swapped)) if swapped else '')),
                            'FINISHED' in result)


class SSSUITE_OT_ark_select_bone(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_select_bone'
    bl_label = 'Select Bone'
    _label_ja = '骨を選ぶ'
    bl_description = 'Select the cc_arkit_* bone of this expression (hold Shift to add to the selection). The rig goes to Pose Mode, and a hidden bone is made visible'
    bl_options = {'UNDO', 'INTERNAL'}
    bone: StringProperty(name='ARKit Bone', description='Name of the bone to select', default='', options={'SKIP_SAVE'})
    extend: BoolProperty(name='Extend Bone Selection', description='Add to the current selection', default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return cls._need_rig()

    def invoke(self, context, event):
        self.extend = bool(getattr(event, 'shift', False))
        return self.execute(context)

    def execute(self, context):
        rig = find_rig()
        pb = rig.pose.bones.get(self.bone)
        if pb is None:
            return self._finish(_t('Bone %s not found' % self.bone, '骨 %s がありません' % self.bone), False)
        vl = context.view_layer
        if not (vl.objects.active == rig and context.mode == 'POSE'):
            ok, msg, _state = _enter_rig_pose(context, rig)
            if not ok:
                return self._finish(msg, False)
        # A bone in a hidden bone collection takes pb.select but is not selected on screen and cannot be keyed.
        revealed = not _bone_visible(rig, pb)
        if revealed:
            _show_bones(rig, [pb.name])
        if not self.extend:
            for other in rig.pose.bones:
                other.select = False
        pb.select = True
        rig.data.bones.active = pb.bone
        if revealed:
            return self._finish(_t('Made bone %s visible and selected it' % pb.name, '隠れていた骨 %s を表示して選びました' % pb.name), True)
        _tag_redraw()
        return {'FINISHED'}


class SSSUITE_OT_ark_curve_tool(_ArkOp, Operator):
    bl_idname = 'smart_selector_suite.ark_curve_tool'
    bl_label = 'Clean-up after Baking'
    _label_ja = '手直しの補助'
    bl_description = 'Call an existing Blender operator to make the baked every-frame keys easier to fix'
    tool: EnumProperty(name='Clean-up Operation', description='Operator to call', items=tuple((t[0], t[4], t[6]) for t in _CURVE_TOOLS), options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        t = _CURVE_TOOL_MAP.get(getattr(properties, 'tool', ''), None)
        return _t(t[6], t[7]) if t else _t(cls.bl_description, '焼いた後の全コマのキーを直しやすくするため、Blender の既存の操作を呼びます')

    def execute(self, context):
        spec = _CURVE_TOOL_MAP.get(self.tool)
        if spec is None:
            return {'CANCELLED'}
        key, mod, name, has_factor, label_en, label_ja, _de, _dj = spec
        label = _t(label_en, label_ja)
        props = _props(context)
        kw = {}
        if has_factor:
            kw['factor'] = float(getattr(props, 'curve_factor', 0.5))
        if key == 'DECIMATE':
            kw.update(mode='ERROR', remove_error_margin=float(getattr(props, 'decimate_error', 0.001)))
        area_type = 'GRAPH_EDITOR' if mod == 'graph' else 'VIEW_3D'
        win, area = _find_area(context, area_type)
        if area is None:
            return self._finish(_t('Open a %s and select the keys first' % ('Graph Editor' if mod == 'graph' else '3D Viewport'),
                                   '%sを開き、直すキー（骨）を選んでから押してください' % ('グラフエディター' if mod == 'graph' else '3D ビューポート')), False)
        region = _window_region(area)
        op = getattr(getattr(bpy.ops, mod), name)
        before = None
        try:
            with context.temp_override(window=win, area=area, region=region):
                if key == 'DECIMATE':
                    before = _sample_selected_curves(bpy.context)
                result = op('EXEC_DEFAULT', **kw)
                diff = _decimate_diff(bpy.context, before) if before is not None else None
        except Exception as exc:
            return self._finish('%s: %s' % (label, exception_text(exc)[:160]), False)
        text = '%s：%s' % (label, '/'.join(sorted(result)) or '-')
        if diff is not None:
            text += _t(' | keys %d -> %d, max diff %.6f' % (diff['keys_before'], diff['keys_after'], diff['max_diff']),
                       '｜キー %d → %d 個、元との差の最大 %.6f' % (diff['keys_before'], diff['keys_after'], diff['max_diff']))
        return self._finish(text, 'FINISHED' in result)


class _LayerOp(_ArkOp):
    @classmethod
    def _need_target(cls, context, need_layers: bool = False):
        ob = layer_target(context)
        if ob is None:
            cls.poll_message_set(_t('Select an armature (the rig)', 'アーマチュア（rig）を選んでください'))
            return False
        if need_layers and not layer_tracks(ob):
            cls.poll_message_set(_t('"%s" has no layer' % ob.name, '「%s」に層がありません' % ob.name))
            return False
        return True

    def _redraw(self, context):
        try:
            context.view_layer.update()
        except Exception:
            pass
        _tag_redraw()


class SSSUITE_OT_ark_layer_add(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_add'
    bl_label = 'Add Animation Layer'
    _label_ja = '層を足す'
    bl_description = ('Add an animation layer: a new NLA track <base action>_L<n> with its own action, blend Add (added on top), '
                      'weight 1, the frame range of the base. The base layer stays the current action; its blend becomes Add')

    @classmethod
    def poll(cls, context):
        if not cls._need_target(context):
            return False
        if base_action(layer_target(context)) is None:
            cls.poll_message_set(_t('The armature has no action (base layer)', 'アーマチュアにアクション（基層）がありません'))
            return False
        return True

    def execute(self, context):
        ob = layer_target(context)
        try:
            rep = layer_add(ob)
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Add layer failed: %s' % exc, '層を足せませんでした：%s' % exc), False)
        self._redraw(context)
        text = _t('Layer "%s" added (frames %g-%g, Add)' % (rep['name'], rep['range'][0], rep['range'][1]),
                  '層「%s」を足しました（フレーム %g〜%g、加算）' % (rep['name'], rep['range'][0], rep['range'][1]))
        user = rep.get('live_user_tracks') or []
        if user:
            # The base blend became COMBINE, so the base is now added to these tracks instead of replacing them.
            names = ', '.join('"%s"' % n for n in user[:3])
            return self._finish(text + _t(' | WARNING: the NLA tracks %s are live and not layers; the base is now added on top of '
                                          'them (blend Add), so the pose can change. Mute them, or undo' % names,
                                          '｜警告：NLA のトラック %s が効いています（層ではありません）。基層の合成を加算にしたので、'
                                          '基層はそのトラックに足され、姿勢が変わる事があります。そのトラックをミュートするか、取り消してください' %
                                          '、'.join('「%s」' % n for n in user[:3])), False, changed=True)
        return self._finish(text, True)


class SSSUITE_OT_ark_layer_edit(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_edit'
    bl_label = 'Edit This Animation Layer'
    _label_ja = 'この層を編集'
    bl_description = ('Enter or leave the edit of a layer (NLA tweak mode). While editing, new keys go into the layer; '
                      'with "Show base while editing" the base is shown under it')
    index: IntProperty(name='Animation Layer Index', description='Layer to edit, counted from the bottom', default=0, min=0,
                                 options={'SKIP_SAVE', 'HIDDEN'})
    mode: EnumProperty(name='Animation Layer Edit', description='Enter or leave the layer edit', items=(
        ('ENTER', 'Enter Layer Edit', 'Start editing the layer'),
        ('EXIT', 'Exit Layer Edit', 'Stop editing the layer and go back to the base')), default='ENTER', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return cls._need_target(context)

    def execute(self, context):
        ob = layer_target(context)
        props = _props(context)
        try:
            if self.mode == 'EXIT':
                was = layer_edit_exit(ob)
                self._redraw(context)
                return self._finish(_t('Layer edit ended' if was else 'No layer was being edited',
                                       '層の編集を終えました' if was else '編集中の層はありませんでした'), True)
            rep = layer_edit_enter(ob, int(self.index), show_base=bool(getattr(props, 'layer_show_base', True)))
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Layer edit failed: %s' % exc, '層の編集に入れませんでした：%s' % exc), False)
        self._redraw(context)
        text = _t('Editing layer "%s": new keys go into the layer' % rep['name'], '層「%s」を編集中：打つキーは層に入ります' % rep['name'])
        if not rep['guided'] and bool(getattr(props, 'layer_show_base', True)):
            text += _t(' (the base cannot be shown: no guide track below this layer)',
                       '（この層の下に表示用のトラックが無いので、基層は見えません）')
        return self._finish(text, True)


class SSSUITE_OT_ark_layer_collapse(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_collapse'
    bl_label = 'Collapse Animation Layers'
    _label_ja = '畳み込む'
    bl_description = ('Evaluate base + enabled layers on every frame of their range and key the result into the base action '
                      '(linear keys on the channels the layers animate; the animated values, not the visual transform, so '
                      'constraints are not keyed twice). The collapsed layers are muted and kept as a backup. Esc cancels')

    @classmethod
    def poll(cls, context):
        return cls._need_target(context, need_layers=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event, title=_t(self.bl_label, self._label_ja),
            message=_t('Key base + enabled layers into the base on every frame? The layers are muted and kept.',
                       '基層＋有効な層を、全フレームのキーとして基層へ書きますか。層はミュートして残します'))

    def execute(self, context):
        ob = layer_target(context)
        try:
            rep = layer_collapse(ob, context, _EscWatch())
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Collapse failed: %s. The base keys, the layers, your NLA tracks and the frame were put back' % exc,
                                   '畳み込みに失敗しました：%s。基層のキー・層・NLA のトラックの mute・フレームは元に戻しました' % exc), False)
        self._redraw(context)
        if rep.get('cancelled'):
            return self._finish(_t('Collapse cancelled; nothing was written', '畳み込みを中断しました（何も書いていません）'), False)
        if rep.get('rolled_back'):
            # 1.10.48 review fix 2 (D1): the shape changed -- the base keys were put back and the layers are on again.
            return self._finish(_t('Not collapsed: the shape would change by %.4f mm (%s, limit %.2f mm). The base keys were put back '
                                   'and the layers are enabled again (difference after the rollback %.4f mm)' % (
                                       rep['shape_mm'], rep['shape_where'], SHAPE_CHECK_MM, rep.get('rollback_mm', -1.0)),
                                   '畳み込みませんでした：形が %.4f mm 変わるため（%s、上限 %.2f mm）。基層のキーを控えから戻し、'
                                   '層を有効に戻しました（戻した後の差 %.4f mm）' % (
                                       rep['shape_mm'], rep['shape_where'], SHAPE_CHECK_MM, rep.get('rollback_mm', -1.0))), False)
        text = _t('Collapsed %d layers into the base: %d channels, frames %d-%d, check diff %.6f, shape diff %.4f mm; '
                  'the layers are muted (backup)' % (
                      len(rep['layers']), rep['channels'], rep['frames'][0], rep['frames'][1], rep['max_diff'], rep['shape_mm']),
                  '%d 本の層を基層へ畳み込みました：%d チャンネル、フレーム %d〜%d、確認の差 %.6f、形の差 %.4f mm。'
                  '層はミュートして残しました（控え）' % (
                      len(rep['layers']), rep['channels'], rep['frames'][0], rep['frames'][1], rep['max_diff'], rep['shape_mm']))
        if rep.get('user_muted'):
            text += _t(' | your NLA tracks %s were muted while evaluating and put back (they still act on top of the base)' %
                       ', '.join('"%s"' % n for n in rep['user_muted'][:3]),
                       '｜層ではない NLA のトラック %s は評価の間だけミュートして戻しました（基層の上にそのまま効きます）' %
                       '、'.join('「%s」' % n for n in rep['user_muted'][:3]))
        if rep.get('unreadable'):
            text += _t(' | not collapsed (unreadable): %s' % ', '.join(rep['unreadable'][:3]),
                       '｜読めないので畳み込まなかった物：%s' % '、'.join(rep['unreadable'][:3]))
        if rep.get('shape_skipped'):
            text += _t(' | shape not compared (vertex count changed): %s' % ', '.join(rep['shape_skipped'][:3]),
                       '｜頂点の数が変わったので形を比べなかった物：%s' % '、'.join(rep['shape_skipped'][:3]))
        # The keys are written and the layers muted: always FINISHED (own Undo step); a failed check is a WARNING.
        return self._finish(text, rep['max_diff'] <= 1e-4 and not rep.get('unreadable') and not rep.get('shape_skipped'),
                            changed=True)


class SSSUITE_OT_ark_layer_remove(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_remove'
    bl_label = 'Remove Animation Layer'
    _label_ja = '層を消す'
    bl_description = ('Remove the layer (its NLA track, and its action when nothing else uses it). Removing the last layer '
                      'puts the base blend back to Replace')
    index: IntProperty(name='Animation Layer Index', description='Layer to remove, counted from the bottom', default=0, min=0,
                                 options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return cls._need_target(context, need_layers=True)

    def invoke(self, context, event):
        layers = layer_tracks(layer_target(context))
        name = layers[self.index].name if 0 <= self.index < len(layers) else '?'
        return context.window_manager.invoke_confirm(self, event, title=_t(self.bl_label, self._label_ja),
                                                     message=_t('Remove the layer "%s" and its keys?' % name,
                                                                '層「%s」とそのキーを消しますか' % name))

    def execute(self, context):
        ob = layer_target(context)
        try:
            rep = layer_remove(ob, int(self.index))
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        except Exception as exc:
            return self._finish(_t('Remove layer failed: %s' % exc, '層を消せませんでした：%s' % exc), False)
        self._redraw(context)
        text = _t('Layer "%s" removed' % rep['name'], '層「%s」を消しました' % rep['name'])
        if rep['last']:
            text += _t(' (last layer: base blend back to %s)' % _blend_name(rep.get('blend'), False),
                       '（最後の層なので、基層の合成を %s に戻しました）' % _blend_name(rep.get('blend'), True))
        return self._finish(text, True)


class SSSUITE_OT_ark_layer_enable(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_enable'
    bl_label = 'Enable Animation Layer'
    _label_ja = '層の有効・無効'
    bl_description = ('Enable or disable the layer (NLA track mute). Disabling puts the channels that only this layer animates '
                      'back to their default, so no last value is left behind')
    index: IntProperty(name='Animation Layer Index', description='Layer to switch, counted from the bottom', default=0, min=0,
                       options={'SKIP_SAVE', 'HIDDEN'})
    enable: BoolProperty(name='Enable Layer', description='True enables the layer, False disables (mutes) it', default=True,
                         options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return cls._need_target(context, need_layers=True)

    def execute(self, context):
        ob = layer_target(context)
        try:
            rep = layer_set_enabled(ob, int(self.index), bool(self.enable))
        except ArkError as exc:
            return self._finish(exception_text(exc), False)
        self._redraw(context)
        return self._finish(_t('Layer "%s" %s' % (rep['name'], 'enabled' if self.enable else 'disabled'),
                               '層「%s」を%s' % (rep['name'], '有効にしました' if self.enable else '無効にしました')), True)


class SSSUITE_OT_ark_layer_blend(_LayerOp, Operator):
    bl_idname = 'smart_selector_suite.ark_layer_blend'
    bl_label = 'Animation Layer Blend'
    _label_ja = '層の合成'
    bl_description = 'Switch the layer between Add (added on top) and Replace (overrides what is below)'
    index: IntProperty(name='Animation Layer Index', description='Layer to switch, counted from the bottom', default=0, min=0,
                                 options={'SKIP_SAVE', 'HIDDEN'})
    blend: EnumProperty(name='Animation Layer Blend', description='How the layer is blended', items=(
        ('COMBINE', 'Add (Combine)', 'Added on top of the layers below'),
        ('REPLACE', 'Replace (Override)', 'Overrides the layers below')), default='COMBINE', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return cls._need_target(context, need_layers=True)

    def execute(self, context):
        ob = layer_target(context)
        layers = layer_tracks(ob)
        if not 0 <= self.index < len(layers) or _layer_strip(layers[self.index]) is None:
            return self._finish(_t('No such layer', 'その層はありません'), False)
        for st in layers[self.index].strips:
            st.blend_type = self.blend
        self._redraw(context)
        return self._finish(_t('Layer "%s": %s' % (layers[self.index].name, 'Add' if self.blend == 'COMBINE' else 'Replace'),
                               '層「%s」：%s' % (layers[self.index].name, '加算' if self.blend == 'COMBINE' else '置換')), True)


def _sample_selected_curves(ctx) -> list:
    out = []
    for fc in list(getattr(ctx, 'selected_editable_fcurves', None) or []):
        pts = fc.keyframe_points
        if len(pts) < 2:
            continue
        f0 = int(min(p.co.x for p in pts))
        f1 = int(max(p.co.x for p in pts))
        out.append((fc, len(pts), [(f, fc.evaluate(f)) for f in range(f0, f1 + 1)]))
    return out


def _decimate_diff(ctx, before) -> dict:
    kb = ka = 0
    md = 0.0
    for fc, n, samples in before or []:
        kb += n
        try:
            ka += len(fc.keyframe_points)
            for f, v in samples:
                md = max(md, abs(fc.evaluate(f) - v))
        except Exception:
            pass
    return {'keys_before': kb, 'keys_after': ka, 'max_diff': md}


# ---------------------------------------------------------------------------------------------- draw
def draw_light_header(self, context):
    """3D View header: shows 「軽い表示 中」 while the light display is on (saved in the file)."""
    try:
        if not light_is_on():
            return
        st = light_status()
        row = self.layout.row(align=True)
        row.alert = True
        text = _t('Light display ON', '軽い表示 中')
        if st['stage'] == 2:
            text += _t(' (stage 2)', '（段 2）')
        row.operator(SSSUITE_OT_ark_light_toggle.bl_idname, text=text, icon='MOD_SUBSURF').state = 'OFF'
    except Exception:
        pass


# 1.10.49: long notices were cut in the middle with "…" in the N-panel (fork23 GUI shot_05).  They are drawn as a short
# heading plus a body wrapped to the width of the region (labels never wrap by themselves).
_DRAW_WIDTH = [0]


def _set_draw_width(context) -> None:
    w = 0
    try:
        r = context.region
        if r is not None and r.type == 'UI':
            w = int(r.width)
    except Exception:
        w = 0
    try:
        scale = float(bpy.context.preferences.system.ui_scale) or 1.0
    except Exception:
        scale = 1.0
    if w < 80:
        w = int(300 * scale)        # no UI region (scripts, background): a typical N-panel
    # 1.10.50 (W1): the floor was 60 half-width characters (about 330-380 px of text), so in any region narrower than about
    # 454 px -- the default sidebar is about 220 px -- every wrapped line was still cut with "…".  The width now follows
    # the region down to a floor of 16; 56 px are kept for the panel margins, the icon and two nested boxes.
    _DRAW_WIDTH[0] = max(16, int((w - 56 * scale) / (7.0 * scale)))     # width in half-width characters


def _char_units(ch: str) -> int:
    import unicodedata
    return 2 if unicodedata.east_asian_width(ch) in ('W', 'F', 'A') else 1


_NO_LINE_START = set('、。，．）」』】・：；！？ー…,.;:!?)]')


def _wrap_text(text: str, units: int) -> list:
    """Split text into lines of at most ``units`` half-width characters: words of Latin text stay whole, Japanese
    breaks between characters, and closing punctuation never starts a line."""
    tokens = []
    word = ''
    for ch in text:
        if ord(ch) < 128 and not ch.isspace():
            word += ch
            continue
        if word:
            tokens.append(word)
            word = ''
        tokens.append(ch)
    if word:
        tokens.append(word)
    # 1.10.50 (W1): a Latin word longer than a line (a 63-character track name, a data path) is split, else it is cut.
    room = max(4, units - 2)
    split = []
    for tok in tokens:
        if len(tok) > room and all(ord(c) < 128 for c in tok):
            split.extend(tok[i:i + room] for i in range(0, len(tok), room))
        else:
            split.append(tok)
    tokens = split
    lines, cur, n = [], '', 0
    for tok in tokens:
        w = sum(_char_units(c) for c in tok)
        # Two half-width characters are kept free for closing punctuation hanging at the end of a line.
        if cur and n + w > units - 2 and not tok.isspace() and tok not in _NO_LINE_START:
            lines.append(cur.rstrip())
            cur, n = '', 0
        if not cur and tok.isspace():
            continue
        cur += tok
        n += w
    if cur.strip():
        lines.append(cur.rstrip())
    return lines or ['']


def _wlabel(layout, text: str, icon: str = 'NONE') -> None:
    """A label wrapped onto as many lines as the panel needs; the icon on the first line, the rest indented."""
    units = _DRAW_WIDTH[0] or 40
    lines = _wrap_text(text, units - (3 if icon != 'NONE' else 0))
    col = layout.column(align=True)
    for i, line in enumerate(lines):
        if i == 0:
            col.label(text=line, icon=icon)
        else:
            col.label(text=line, icon='BLANK1' if icon != 'NONE' else 'NONE')


def _note(layout, head: str, body: str = '', icon: str = 'NONE') -> None:
    """A short heading (with the icon) and its body wrapped below it.  1.10.51: state lines only, no information icon."""
    _wlabel(layout, head, icon)
    if body:
        _wlabel(layout, body, 'BLANK1' if icon != 'NONE' else 'NONE')


# 1.10.51 (SmartTools common spec 2026-10-17): every explanation lives in the ? help popup of its section header.
# The panel body keeps the controls and one-line states only; the help keys are the ark_* topics of help_ark.py.
HELP_OPERATOR = 'smart_selector_suite.show_help'


def _help_button(layout, topic_id: str) -> None:
    """The ? button of a section header (right end of the header row)."""
    if not topic_id:
        return
    try:
        right = layout.row(align=True)
        right.alignment = 'RIGHT'
        op = right.operator(HELP_OPERATOR, text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id)
    except Exception:
        pass


def _sub_panel(layout, idname: str, title: str, default_closed: bool = False, help_topic: str = ''):
    """A collapsible sub-panel with its ? help on the header.  Returns its body layout, or None while it is collapsed."""
    panel = getattr(layout, 'panel', None)
    if callable(panel):
        try:
            header, body = panel(idname, default_closed=default_closed)
            header.label(text=title)
            _help_button(header, help_topic)
            return body
        except Exception:
            pass
    box = layout.box()
    row = box.row(align=True)
    row.label(text=title)
    _help_button(row, help_topic)
    return box


def _draw_light(layout, context, props) -> None:
    st = light_status()
    col = layout.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1.2
    op = row.operator(SSSUITE_OT_ark_light_toggle.bl_idname,
                      text=_t('Light display', '軽い表示') + (_t(' (ON)', '（オン）') if st['on'] else ''),
                      icon='MOD_SUBSURF', depress=st['on'])
    op.state = 'TOGGLE'
    if props is not None:
        row.prop(props, 'face_smooth', text=_t('Smooth face', '顔は滑らかに'), toggle=True)
        row = col.row(align=True)
        row.prop(props, 'light_stage', expand=True)
    chosen2 = props is not None and str(getattr(props, 'light_stage', 'STAGE2')) == 'STAGE2'
    if chosen2:
        row = col.row(align=True)
        row.prop(props, 'light_hide_props', text=_t('Hide small props', '小物を隠す'), toggle=True)
        if bool(getattr(props, 'light_hide_props', True)):
            row = col.row(align=True)
            row.prop(props, 'light_prop_rule', text=_t('Props', '小物'))
            n_props = len(light_prop_objects(props.light_prop_rule))
            row = col.row(align=True)
            _wlabel(row, _t('%d objects match' % n_props, '%d 個が当たります' % n_props), 'VIEWZOOM')
    if st['on']:
        warn = col.column(align=True)
        warn.alert = True
        _note(warn, _t('Light display ON (stage %d)' % st['stage'], '軽い表示 中（段 %d）' % st['stage']),
              _t('%d modifiers hidden on %d objects' % (st['modifiers'], st['objects']),
                 '%d 個の物で細分化 %d 個を止めています' % (st['objects'], st['modifiers'])), 'ERROR')
        if st['stage'] == 2:
            _wlabel(warn, _t('Stage 2: %d last subdivisions off, %d props hidden, %d views set to Solid' % (
                st['stage2_modifiers'], st['hidden'], st['views']),
                '段 2：最後の細分化 %d 個を止め、小物 %d 個を隠し、%d 個のビューをソリッドに' % (
                st['stage2_modifiers'], st['hidden'], st['views'])), 'HIDE_ON')
        if st['face_smooth']:
            _wlabel(warn, _t('Face kept smooth (+13 ms per frame)', '顔は滑らか（1 フレーム約 +13ms）'), 'MOD_SUBSURF')
        _wlabel(warn, _t('Bakes of other add-ons: use the buttons below', '他のアドオンの焼きは下のボタンから'), 'ERROR')
        grid = col.grid_flow(columns=1, even_columns=True, align=True)
        for key, mod, name, _how, _kw, label_en, label_ja, _de, _dj in _GUARD_TARGETS:
            cell = grid.row(align=True)
            cell.enabled = _op_available(mod, name)
            cell.operator(SSSUITE_OT_ark_light_guarded_run.bl_idname, text=_t(label_en, label_ja), icon='RENDER_ANIMATION').target = key


def _draw_buttons(layout, rig, has_tools: bool) -> None:
    row = layout.column(align=True)
    row.operator(SSSUITE_OT_ark_zero_expressions.bl_idname, text=_t('Expressions to 0', '表情を 0'), icon='LOOP_BACK')
    row.operator(SSSUITE_OT_ark_face_default.bl_idname, text=_t('Face to default', '顔を既定へ'), icon='FILE_REFRESH')
    row = layout.column(align=True)
    row.operator(SSSUITE_OT_ark_flip_paste.bl_idname, text=_t('Paste flipped', '左右反転して貼る'), icon='MOD_MIRROR')
    row.operator(SSSUITE_OT_ark_state_report.bl_idname, text=_t('Check state', '状態を確かめる'), icon='VIEWZOOM')


def _draw_bake(layout, rig, expression: bool, props) -> None:
    col = layout.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1.2
    row.operator(SSSUITE_OT_ark_face_bake.bl_idname, text=_t('Bake face for hand keys', '顔を手付け用に焼く'), icon='KEYFRAME_HLT')
    row = col.row(align=True)
    row.operator(SSSUITE_OT_ark_face_restore.bl_idname, text=_t('Back to capture state', '流し込み直しの状態に戻す'), icon='LOOP_BACK')
    col.separator()
    row = col.column(align=True)
    op = row.operator(SSSUITE_OT_ark_reapply.bl_idname, text=_t('Re-apply after ARP update', 'ARP 更新の後に当て直す'), icon='FILE_REFRESH')
    op.dry_run = False
    op = row.operator(SSSUITE_OT_ark_reapply.bl_idname, text=_t('Dry run', 'ずれを見る'), icon='VIEWZOOM')
    op.dry_run = True
    if props is not None:
        col.prop(props, 'reapply_srs_limits', text=_t('Also reset SmartRig limits', 'SmartRig の上限も戻す'))


def _draw_pads(layout, rig, props, expression: bool, *, columns: int = 1) -> None:
    pads = layout_data().get('pads') or []
    col = layout.column(align=True)
    col.enabled = expression
    if not expression:
        _wlabel(col, _t('Hand-key mode: the pads have no effect.', '手付けモード：パッドは効きません。'), 'LOCKED')
    if columns > 1:
        col = col.grid_flow(columns=columns, row_major=True, even_columns=True, align=True)
    for i, pad in enumerate(pads[:PAD_SLOTS]):
        box = col.box()
        box.label(text=_board_label(str(pad.get('name') or ('Pad %d' % (i + 1)))), icon='EMPTY_ARROWS', translate=False)
        row = box.row(align=True)
        if props is not None:
            row.prop(props, 'pad_%d_x' % i, text=_t('L/R', '左右'), slider=True)
            row.prop(props, 'pad_%d_y' % i, text=_t('D/U', '下上'), slider=True)
        names = []
        for axis in ('x', 'y'):
            try:
                for side in pad[axis]:
                    names.extend(_side(side))
            except Exception:
                pass
        _wlabel(box, ' / '.join(dict.fromkeys(names)))


def _short(arkit: str) -> str:
    return arkit


def _draw_sliders(layout, rig, expression: bool, *, file_browser_props=None) -> None:
    data = layout_data()
    rows = data.get('rows') or []
    manual = set(data.get('manual_only') or [])
    tongue_hint = str(data.get('tongue_hint') or _FALLBACK_TONGUE_HINT)
    col = layout.column(align=True)
    if not expression:
        _wlabel(col, _t('Hand-key mode: the 52 sliders are greyed (only jawForward stays live).',
                        '手付けモード：52 本は灰色（jawForward だけ効きます）。'), 'LOCKED')
    sliders = data.get('sliders') or []
    if file_browser_props is not None:
        col.prop(file_browser_props, 'file_browser_later_expressions',
                 text=_t('Show later expressions', '後半の表情を表示'), toggle=True)
        midpoint = (len(sliders) + 1) // 2
        sliders = sliders[midpoint:] if file_browser_props.file_browser_later_expressions else sliders[:midpoint]
        col = col.column_flow(columns=3, align=True)
    current_row = None
    for s in sliders:
        if s['row'] != current_row:
            current_row = s['row']
            title = rows[current_row] if 0 <= current_row < len(rows) else str(current_row)
            col.separator()
            col.label(text=_board_label(title), translate=False)
        pb = rig.pose.bones.get(s['bone'])
        line = col.row(align=True)
        live = expression or bool(s.get('live_after_bake'))
        line.enabled = live
        if pb is None:
            line.alert = True
            line.label(text=_t('%s: bone missing' % s['bone'], '%s：骨がありません' % s['bone']), icon='ERROR')
            continue
        op = line.operator(SSSUITE_OT_ark_select_bone.bl_idname, text=_short(s['arkit']), translate=False,
                           icon='HAND' if s['arkit'] in manual else 'BONE_DATA')
        op.bone = s['bone']
        line.prop(pb, 'location', index=1, text='')
        if s['arkit'] == 'tongueOut':
            # The rig's own one-line condition for the tongue (from ARK_board_layout.json); the reason is in the help.
            hint = col.row(align=True)
            hint.alert = True
            _wlabel(hint, _board_label(tongue_hint), 'ERROR')


def _draw_hand(layout, rig, expression: bool) -> None:
    col = layout.column(align=True)
    for p in HAND_PROPS:
        row = col.row(align=True)
        if p in rig.keys():
            row.prop(rig, '["%s"]' % p, text=p.replace('ark_hand_', ''), slider=True, translate=False)
        else:
            row.alert = True
            row.label(text=_t('%s missing' % p, '%s がありません' % p), icon='ERROR')
            continue
        if p == PUCKER_PROP:
            note = col.row(align=True)
            note.alert = True
            _wlabel(note, _t('No effect: the Pucker helper key is empty.', '効かない（Pucker の補助キーは空）'), 'ERROR')
    jb = rig.pose.bones.get(LIPS_BONE)
    if jb is not None and LIPS_BONE_PROP in jb.keys():
        col.separator()
        grey = col.row(align=True)
        grey.enabled = False
        grey.prop(jb, '["%s"]' % LIPS_BONE_PROP, text='%s ["%s"]' % (LIPS_BONE, LIPS_BONE_PROP), translate=False)


def _draw_curve_tools(layout, context, props) -> None:
    col = layout.column(align=True)
    if props is not None:
        row = col.row(align=True)
        row.prop(props, 'curve_factor', text=_t('Clean-up Strength', '強さ'), slider=True)
        row.prop(props, 'decimate_error', text=_t('Allowed error', '許す誤差'))
    _wlabel(col, _t('Graph Editor (selected keys)', 'グラフエディター（選んだキー）'), 'GRAPH')
    grid = col.grid_flow(columns=2, even_columns=True, align=True)
    for key, mod, name, _f, label_en, label_ja, _de, _dj in _CURVE_TOOLS:
        if mod != 'graph':
            continue
        grid.operator(SSSUITE_OT_ark_curve_tool.bl_idname, text=_t(label_en, label_ja),
                      icon='SMOOTHCURVE' if key != 'DECIMATE' else 'MOD_DECIM').tool = key
    _wlabel(col, _t('Pose (current frame, selected bones)', 'ポーズ（今のフレーム、選んだ骨）'), 'POSE_HLT')
    row = col.row(align=True)
    for key, mod, name, _f, label_en, label_ja, _de, _dj in _CURVE_TOOLS:
        if mod != 'pose':
            continue
        row.operator(SSSUITE_OT_ark_curve_tool.bl_idname, text=_t(label_en, label_ja), icon='IPO_EASE_IN_OUT').tool = key


def _draw_layers(layout, context, props) -> None:
    """層 (design §8.6): the base and the NLA-track layers of the target armature, top layer first."""
    ob = layer_target(context)
    col = layout.column(align=True)
    if ob is None:
        _wlabel(col, _t('Select an armature (the rig).', 'アーマチュア（rig）を選んでください。'), 'ARMATURE_DATA')
        return
    ad = ob.animation_data
    base = base_action(ob)
    layers = layer_tracks(ob)
    editing = tweaked_layer_index(ob)
    _wlabel(col, _t('Target: %s' % ob.name, '対象：%s' % ob.name), 'OUTLINER_OB_ARMATURE')
    if ad is not None and ad.use_tweak_mode:
        box = col.box()
        box.alert = True
        name = layers[editing].name if 0 <= editing < len(layers) else (ad.action.name if ad.action else '?')
        _wlabel(box, _t('Editing layer "%s": keys go into the layer' % name, '層「%s」を編集中：キーは層に入ります' % name), 'GREASEPENCIL')
        op = box.operator(SSSUITE_OT_ark_layer_edit.bl_idname, text=_t('Stop editing the layer', '層の編集を終える'), icon='LOOP_BACK')
        op.mode = 'EXIT'
        op.index = 0
        if editing >= 0 and not _has_key(ob, LAYER_GUIDE_KEY):
            _wlabel(box, _t('The base is not shown while editing (Blender tweak mode).',
                            '編集中は基層が見えていません（Blender の微調整モードの動き）。'), 'HIDE_ON')
    if layers and ad is not None and not ad.use_nla:
        warn = col.row(align=True)
        warn.alert = True
        _wlabel(warn, _t('NLA is off for this object: the layers have no effect.', 'この物は NLA がオフです：層は効きません。'), 'ERROR')
    user = live_user_tracks(ob)
    if user:
        warn = col.column(align=True)   # 1.10.49 review: a row put the two notes side by side, each cut at half width
        warn.alert = bool(layers) and ad is not None and ad.action_blend_type == 'COMBINE'
        _wlabel(warn, _t('Other NLA tracks are live (not layers): %s' % ', '.join(t.name for t in user[:3]),
                         '層ではない NLA のトラックが効いています：%s' % '、'.join(t.name for t in user[:3])), 'NLA')
    frame = float(context.scene.frame_current)
    for i in reversed(range(len(layers))):
        t = layers[i]
        st = _layer_strip(t)
        row = col.row(align=True)
        if i == editing:
            row.alert = True
        op = row.operator(SSSUITE_OT_ark_layer_enable.bl_idname, text='', icon='CHECKBOX_DEHLT' if t.mute else 'CHECKBOX_HLT', emboss=False)
        op.index = i
        op.enable = bool(t.mute)
        row.prop(t, 'name', text='')
        if st is None:
            row.label(text=_t('(no strip)', '（ストリップ無し）'), icon='ERROR')
        else:
            if props is not None and i < LAYER_SLOTS:
                row.prop(props, 'layer_weight_%d' % i, text=_t('Weight', '重み'), slider=True)
            else:
                row.label(text='%.2f' % layer_weight_get(st, frame))
            blend = str(st.blend_type)
            label = {'COMBINE': _t('Add', '加算'), 'REPLACE': _t('Replace', '置換')}.get(blend, blend)
            op = row.operator(SSSUITE_OT_ark_layer_blend.bl_idname, text=label)
            op.index = i
            op.blend = 'REPLACE' if blend == 'COMBINE' else 'COMBINE'
            op = row.operator(SSSUITE_OT_ark_layer_edit.bl_idname, text='', icon='GREASEPENCIL', depress=(i == editing))
            op.index = i
            op.mode = 'EXIT' if i == editing else 'ENTER'
        op = row.operator(SSSUITE_OT_ark_layer_remove.bl_idname, text='', icon='X')
        op.index = i
    row = col.row(align=True)
    row.label(text=_t('Base: %s' % (base.name if base else '(no action)'), '基層：%s' % (base.name if base else '（アクション無し）')),
              icon='ACTION')
    if ad is not None and layers:
        row.label(text=_t('blend %s' % _blend_name(ad.action_blend_type, False), '合成 %s' % _blend_name(ad.action_blend_type, True)))
    col.separator()
    row = col.row(align=True)
    row.operator(SSSUITE_OT_ark_layer_add.bl_idname, text=_t('Add layer', '層を足す'), icon='ADD')
    row.operator(SSSUITE_OT_ark_layer_collapse.bl_idname, text=_t('Collapse', '畳み込む'), icon='NLA_PUSHDOWN')
    if props is not None:
        col.prop(props, 'layer_show_base', text=_t('Show base while editing', '編集中も基層を見せる'))


def _draw_archive(layout, context) -> None:
    """Body of the 「外部 Action（保管庫）」 child section (1.10.60, action_catalog_ui)."""
    try:
        from . import action_catalog_ui as _acu
    except Exception as exc:
        layout.label(text=_t('External Actions unavailable: %s' % exc, '外部 Action を使えません：%s' % exc), icon='ERROR')
        return
    _acu.draw(layout, context)


def draw_section(layout, context) -> None:
    """Body of the 「顔 ARKit」 section of the Smart Selector N-panel (its ? help is the ark_face topic)."""
    rig = find_rig()
    props = _props(context)
    area = getattr(context, 'area', None)
    compact = props is not None and getattr(area, 'type', '') == 'FILE_BROWSER'
    _set_draw_width(context)
    col = layout.column(align=True)
    if rig is None:
        _wlabel(col, _t('No ARKit face rig (armature with cc_arkit_board) in this file.',
                        '顔 ARKit のリグ（cc_arkit_board を持つアーマチュア）がこのファイルにありません。'), 'ARMATURE_DATA')
        body = _sub_panel(col, 'SSSUITE_ARK_light', _t('Light display', '軽い表示'), default_closed=False, help_topic='ark_light')
        if body is not None:
            _draw_light(body, context, props)
        if layer_target(context) is not None:
            body = _sub_panel(col, 'SSSUITE_ARK_layers', _t('Layers', '層'), default_closed=False, help_topic='ark_layers')
            if body is not None:
                _draw_layers(body, context, props)
        body = _sub_panel(col, 'SSSUITE_ARK_archive', _t('External Actions (archive)', '外部 Action（保管庫）'), default_closed=True, help_topic='ark_archive')
        if body is not None:
            _draw_archive(body, context)
        return
    expression = is_expression_mode(rig)
    head = col.column(align=True)
    head.label(text=_t('Mode: %s' % ('Expression' if expression else 'Hand keys'),
                       'モード：%s' % ('表情モード' if expression else '手付けモード')),
               icon='SHAPEKEY_DATA' if expression else 'KEYFRAME_HLT')
    head.label(text=rig.name, icon='OUTLINER_OB_ARMATURE', translate=False)
    data = layout_data()
    has_tools = _has_text(TOOLS_TEXT)
    if data.get('_source') != 'text' or not has_tools:
        warn = col.row(align=True)
        warn.alert = True
        _wlabel(warn, _t('Rig Texts missing: %s' % ', '.join(n for n in (TOOLS_TEXT, LAYOUT_TEXT) if not _has_text(n)),
                         'リグの Text がありません：%s' % '、'.join(n for n in (TOOLS_TEXT, LAYOUT_TEXT) if not _has_text(n))), 'ERROR')
    report = last_report_text()
    if report:
        rep = col.row(align=True)
        rep.alert = not _LAST_REPORT['ok']
        _wlabel(rep, report[:400], 'CHECKMARK' if _LAST_REPORT['ok'] else 'ERROR')
    untrusted = [n for n in (TOOLS_TEXT, REAPPLY_TEXT) if _has_text(n) and not text_trusted(n)]
    if untrusted:
        warn = col.column(align=True)
        warn.alert = True
        if not _exec_script_allowed():
            _wlabel(warn, _t('Execute Script is OFF in Smart Selector settings: the rig Texts are not run.',
                             'スマートセレクターの設定で「スクリプト実行を許可」がオフ：リグの Text は実行しません。'), 'ERROR')
        else:
            _wlabel(warn, _t('Auto Run is off for this file', 'このファイルは Python の自動実行が未許可'), 'ERROR')
    # layout.panel() returns body=None for a collapsed sub-panel: draw a body only when it is open.
    # ("手直しの補助" starts collapsed, so this is the state every user sees first.)
    sections = (
        ('SSSUITE_ARK_light', _t('Light display', '軽い表示'), False, 'ark_light', lambda b: _draw_light(b, context, props)),
        ('SSSUITE_ARK_buttons', _t('Reset / mirror', 'リセット・反転'), False, 'ark_buttons', lambda b: _draw_buttons(b, rig, has_tools)),
        ('SSSUITE_ARK_bake', _t('Bake / restore / re-apply', '焼き・戻し・当て直し'), False, 'ark_bake', lambda b: _draw_bake(b, rig, expression, props)),
        ('SSSUITE_ARK_layers', _t('Layers', '層'), False, 'ark_layers', lambda b: _draw_layers(b, context, props)),
        ('SSSUITE_ARK_pads', _t('2D pads', '2D パッド'), False, 'ark_pads', lambda b: _draw_pads(b, rig, props, expression, columns=2 if compact else 1)),
        ('SSSUITE_ARK_sliders', _t('52 expressions', '52 表情'), False, 'ark_sliders', lambda b: _draw_sliders(b, rig, expression, file_browser_props=props if compact else None)),
        ('SSSUITE_ARK_hand', _t('Helper sliders', '補助のスライダー'), False, 'ark_hand', lambda b: _draw_hand(b, rig, expression)),
        ('SSSUITE_ARK_curves', _t('Clean-up after baking', '手直しの補助'), True, 'ark_curves', lambda b: _draw_curve_tools(b, context, props)),
        ('SSSUITE_ARK_archive', _t('External Actions (archive)', '外部 Action（保管庫）'), True, 'ark_archive', lambda b: _draw_archive(b, context)),
    )
    if compact:
        selected = props.file_browser_tab or 'light'
        section = next(entry for entry in sections if entry[3] == f'ark_{selected}')
        row = col.row(align=True)
        row.prop(props, 'file_browser_tab', text='')
        _help_button(row, section[3])
        section[4](col)
        return
    for idname, title, closed, topic, fn in sections:
        body = _sub_panel(col, idname, title, default_closed=closed, help_topic=topic)
        if body is not None:
            fn(body)


# Help keys of this section, in panel order (read by the help popup and by the 1.10.51 help draw test).
HELP_TOPICS = ('ark_face', 'ark_light', 'ark_buttons', 'ark_bake', 'ark_layers', 'ark_pads', 'ark_sliders', 'ark_hand', 'ark_curves', 'ark_archive')


# ---------------------------------------------------------------------------------------- register
classes = (
    SSSUITE_ArkFaceProps,
    SSSUITE_OT_ark_light_toggle,
    SSSUITE_OT_ark_light_guarded_run,
    SSSUITE_OT_ark_face_bake,
    SSSUITE_OT_ark_face_restore,
    SSSUITE_OT_ark_reapply,
    SSSUITE_OT_ark_zero_expressions,
    SSSUITE_OT_ark_face_default,
    SSSUITE_OT_ark_state_report,
    SSSUITE_OT_ark_flip_paste,
    SSSUITE_OT_ark_select_bone,
    SSSUITE_OT_ark_curve_tool,
    SSSUITE_OT_ark_layer_add,
    SSSUITE_OT_ark_layer_edit,
    SSSUITE_OT_ark_layer_collapse,
    SSSUITE_OT_ark_layer_remove,
    SSSUITE_OT_ark_layer_enable,
    SSSUITE_OT_ark_layer_blend,
)


def _unregister_existing(cls) -> None:
    existing = getattr(bpy.types, cls.__name__, None)
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass


def register() -> None:
    for cls in classes:
        _unregister_existing(cls)
        bpy.utils.register_class(cls)
    # On the Scene (not the WindowManager): saved with the file and undoable (1.10.46 review fix).
    setattr(bpy.types.Scene, WM_PROP, PointerProperty(
        type=SSSUITE_ArkFaceProps, name='Face ARKit',
        description='Values of the Smart Selector "Face ARKit" UI (smooth face option, 2D pads, clean-up strength). Saved with the scene'))
    try:
        bpy.types.VIEW3D_HT_header.remove(draw_light_header)
    except Exception:
        pass
    bpy.types.VIEW3D_HT_header.append(draw_light_header)
    _add_save_handlers()
    from . import action_catalog_ui as _acu
    _acu.register()


def unregister() -> None:
    # Disabling the add-on removes the save guard, so put the light display back first: otherwise the
    # next save would write it switched, with nothing left to undo it (1.10.47 review).  An update to a
    # newer version also passes here; the display is then simply off and can be switched on again.
    try:
        if light_is_on() or _shading_screens():
            light_set(False)
    except Exception as exc:
        print('SmartSelector unregister: light display not released: %s' % exc)
    # A layer edited with the base shown: leave the edit and mute the guide while the watch still runs,
    # otherwise ending the tweak later would evaluate the base twice.
    for name in list(_GUIDE_WATCH):
        try:
            ob = bpy.data.objects.get(name)
            if ob is not None:
                layer_edit_exit(ob)
        except Exception as exc:
            print('SmartSelector unregister: layer edit not ended: %s' % exc)
    _GUIDE_WATCH.clear()
    _remove_save_handlers()
    _SAVE_STASH['params'] = None
    try:
        from . import action_catalog_ui as _acu
        _acu.unregister()
    except Exception as exc:
        print('SmartSelector unregister: external Action section not released: %s' % exc)
    try:
        bpy.types.VIEW3D_HT_header.remove(draw_light_header)
    except Exception:
        pass
    try:
        if hasattr(bpy.types.Scene, WM_PROP):
            delattr(bpy.types.Scene, WM_PROP)
    except Exception:
        pass
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _LAYOUT_CACHE.update(key=None, t=0.0, data=None)
    _set_report('', True)
    _APPROVED_TEXTS.clear()
