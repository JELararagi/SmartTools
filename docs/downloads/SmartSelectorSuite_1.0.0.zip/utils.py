# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Redistribution, modification, resale, or relicensing is prohibited without
# explicit permission from the rights holder.
# ------------------------------------------------------------------------------
# utils.py
import ast
import bpy
import math
import os
import re
import shutil
import tempfile
import time
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# -----------------------------------------------------------------------------
# Preferences helpers
# -----------------------------------------------------------------------------

def addon_id_candidates() -> List[str]:
    candidates: List[str] = []
    package_name = str(__package__ or "").strip()
    leaf_name = package_name.split(".")[-1] if package_name else ""
    module_name = Path(__file__).resolve().parent.name
    legacy_ids = ["smart_selector_tool", "Smart_Selector_Tool"]
    current_ids = ["smart_selector_suite", "smart_selector_suite"]
    for candidate in (package_name, leaf_name, module_name, *current_ids, *legacy_ids):
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    return candidates


class _NPanelSettingsProxy:
    """Runtime proxy for Smart Selector N-panel settings.

    This is not a separate preferences-panel object. It reads and writes the
    user_default JSON store used by the N-panel PropertyGroup so non-UI code can
    access the same persistent values even outside a Panel.draw() context.
    """

    __slots__ = ()

    def __getattr__(self, name):
        try:
            from . import settings as _settings
            if str(name) in getattr(_settings, '_DEFAULTS', {}):
                return _settings.get_value(str(name))
        except Exception:
            pass
        raise AttributeError(name)

    def __setattr__(self, name, value):
        try:
            from . import settings as _settings
            if str(name) in getattr(_settings, '_DEFAULTS', {}):
                _settings.set_value(str(name), value)
                return
        except Exception:
            pass
        raise AttributeError(name)


_PREFS_PROXY = _NPanelSettingsProxy()


def _window_manager_npanel_settings():
    try:
        if not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
        ctx = getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is not None:
            value = getattr(wm, 'smart_selector_suite_npanel_settings', None)
            if value is not None:
                return value
    except Exception:
        pass
    return None


def get_prefs():
    """Return persistent N-panel settings, never a separate preferences-panel object."""
    return _window_manager_npanel_settings() or _PREFS_PROXY


# -----------------------------------------------------------------------------
# Path + name sanitizing
# -----------------------------------------------------------------------------

_INVALID_CHARS = set(['\0'])
_PATH_SEPS = {'/', '\\'}

def sanitize_name(name: str, default: str = "Default_Project", max_len: int = 80) -> str:
    """Sanitize project names / ids for filesystem safety (keeps unicode, blocks traversal)."""
    if not name:
        return default
    s = str(name).strip()
    # strip control chars / nulls
    s = ''.join(ch for ch in s if ch not in _INVALID_CHARS and ord(ch) >= 32)
    # block traversal and separators
    s = s.replace('..', '_')
    for sep in _PATH_SEPS:
        s = s.replace(sep, '_')
    s = s.strip().strip('.')
    if not s:
        return default
    if len(s) > max_len:
        s = s[:max_len].rstrip()
    if s in ('.', '..'):
        return default
    return s

def sanitize_filename(filename: str, default: str = "selector.json", allow_ext: Optional[Tuple[str, ...]] = ('.json',), max_len: int = 120) -> str:
    if not filename:
        return default
    s = str(filename).strip()
    s = ''.join(ch for ch in s if ch not in _INVALID_CHARS and ord(ch) >= 32)
    for sep in _PATH_SEPS:
        s = s.replace(sep, '_')
    s = s.replace('..', '_').strip().strip('.')
    if len(s) > max_len:
        root, ext = os.path.splitext(s)
        s = root[:max_len-len(ext)] + ext
    if allow_ext:
        ext = os.path.splitext(s)[1].lower()
        if ext not in allow_ext:
            # if missing ext, append first allowed one
            if ext == '':
                s += allow_ext[0]
            else:
                # replace ext
                s = os.path.splitext(s)[0] + allow_ext[0]
    return s or default

def _safe_resolve_under(base_dir: str, *parts: str) -> Path:
    base = Path(base_dir).resolve()
    p = base.joinpath(*parts).resolve()
    if p == base:
        return p
    if base not in p.parents:
        raise ValueError("Unsafe path traversal detected")
    return p


def _last_data_path_dot(text: str) -> int:
    depth = 0
    quote = ''
    escaped = False
    last = -1
    for idx, ch in enumerate(text):
        if quote:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == quote:
                quote = ''
            continue
        if ch in {'\"', "'"}:
            quote = ch
            continue
        if ch == '[':
            depth += 1
        elif ch == ']':
            depth = max(0, depth - 1)
        elif ch == '.' and depth == 0:
            last = idx
    return last


def _find_final_bracket_start(text: str) -> int:
    if not text.endswith(']'):
        return -1
    stack: list[int] = []
    quote = ''
    escaped = False
    final = -1
    for idx, ch in enumerate(text):
        if quote:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == quote:
                quote = ''
            continue
        if ch in {'\"', "'"}:
            quote = ch
            continue
        if ch == '[':
            stack.append(idx)
        elif ch == ']':
            if not stack:
                return -1
            start = stack.pop()
            if idx == len(text) - 1 and not stack:
                final = start
    return final if not stack else -1


def _parse_data_path_key(raw_key: str):
    raw_key = str(raw_key or '').strip()
    if not raw_key:
        raise ValueError('Empty data-path index')
    try:
        return ast.literal_eval(raw_key)
    except Exception:
        try:
            return int(raw_key)
        except Exception as exc:
            raise ValueError(f'Unsupported data-path index: {raw_key}') from exc


class DataPathValueRefused(ValueError):
    """A slider value was refused so the target keeps its type.

    ``reason`` is 'string', 'enum', 'array', 'unsupported' or 'non_finite';
    UI code turns it into a localized report.
    """

    def __init__(self, reason: str, path: str, type_name: str = '') -> None:
        self.reason = str(reason or 'unsupported')
        self.path = str(path or '')
        self.type_name = str(type_name or '')
        super().__init__(f'{self.reason}: {self.path} ({self.type_name})')


_UNSAFE_DATA_PATH_CHARS = '\r\n;'
_MISSING = object()


def is_safe_data_path(data_path) -> bool:
    """Shared browser data-path rule: non-empty, no statement or line separators."""
    path = str(data_path or '').strip()
    return bool(path) and not any(ch in path for ch in _UNSAFE_DATA_PATH_CHARS)


def _coerce_like_existing(existing, numeric_value: float, path: str):
    """Convert a slider number to the Python type of the value already stored."""
    if isinstance(existing, bool):
        return numeric_value >= 0.5
    if isinstance(existing, int):
        return int(round(numeric_value))
    if isinstance(existing, float):
        return float(numeric_value)
    if isinstance(existing, str):
        raise DataPathValueRefused('string', path, 'str')
    raise DataPathValueRefused('unsupported', path, type(existing).__name__)


def _coerce_for_rna_property(rna_prop, numeric_value: float, path: str):
    """Convert a slider number to the type declared by an RNA property (Property.type)."""
    prop_type = str(rna_prop.type)
    if prop_type in {'BOOLEAN', 'INT', 'FLOAT'}:
        if bool(rna_prop.is_array):
            raise DataPathValueRefused('array', path, prop_type)
        if prop_type == 'BOOLEAN':
            return numeric_value >= 0.5
        if prop_type == 'INT':
            return int(round(numeric_value))
        return float(numeric_value)
    if prop_type in {'STRING', 'ENUM'}:
        raise DataPathValueRefused(prop_type.lower(), path, prop_type)
    raise DataPathValueRefused('unsupported', path, prop_type)


def assign_numeric_data_path(owner, data_path: str, value) -> None:
    """Assign a numeric value to a safe Blender RNA/custom-property data path.

    Supported examples include ``location[0]``, ``rotation_euler.z``,
    ``modifiers["Name"].show_viewport``, and ``["custom_prop"]``.
    The function intentionally avoids ``exec`` and rejects obvious statement
    separators so browser slider payloads cannot run arbitrary Python code.

    The target keeps its type: bool -> ``value >= 0.5``, int -> ``round``,
    float -> ``float``. Strings, enums, whole arrays and non-finite numbers
    raise :class:`DataPathValueRefused` instead of corrupting the target.
    A missing custom property (``["new_prop"]``) is still created as a float,
    as before.
    """
    if owner is None:
        raise ValueError('Target object is not available')
    path = str(data_path or '').strip()
    if not is_safe_data_path(path):
        raise ValueError('Unsafe or empty data path')
    numeric_value = float(value)
    if not math.isfinite(numeric_value):
        raise DataPathValueRefused('non_finite', path, 'float')

    dot_index = _last_data_path_dot(path)
    parent_path = path[:dot_index] if dot_index >= 0 else ''
    leaf = path[dot_index + 1:] if dot_index >= 0 else path
    leaf = leaf.strip()
    if not leaf:
        raise ValueError('Empty data-path assignment target')

    bracket_start = _find_final_bracket_start(leaf)
    if bracket_start >= 0:
        base_name = leaf[:bracket_start].strip()
        raw_key = leaf[bracket_start + 1:-1]
        key = _parse_data_path_key(raw_key)
        target_path = '.'.join(part for part in (parent_path, base_name) if part)
        target = owner.path_resolve(target_path, False) if target_path else owner
        try:
            existing = target[key]
        except KeyError:
            existing = _MISSING
        if existing is _MISSING:
            target[key] = numeric_value
        else:
            target[key] = _coerce_like_existing(existing, numeric_value, path)
        return

    if not leaf.isidentifier():
        raise ValueError(f'Unsupported data-path assignment target: {leaf}')
    # 名前付き成分にはRNAが変換した四元数・オイラー角・ベクトルを使う。
    component = leaf in ('x', 'y', 'z', 'w') and bool(parent_path)
    target = owner.path_resolve(parent_path, component) if parent_path else owner
    bl_rna = getattr(target, 'bl_rna', None)
    rna_prop = bl_rna.properties.get(leaf) if bl_rna is not None else None
    if rna_prop is not None:
        setattr(target, leaf, _coerce_for_rna_property(rna_prop, numeric_value, path))
    else:
        setattr(target, leaf, _coerce_like_existing(getattr(target, leaf), numeric_value, path))


def read_data_path_value(owner, data_path: str, max_text: int = 256):
    """Read one watched data path for /api/state without eval.

    Uses ``bpy_struct.path_resolve`` (RNA path parsing, never Python execution).
    Returns bool / int / float / str (enum identifier, enum-flag set joined by
    ',', or string; truncated to ``max_text``) or None when the value is not a
    finite scalar. Raises ValueError for unsafe or unresolvable paths.
    """
    if owner is None:
        raise ValueError('Target object is not available')
    path = str(data_path or '').strip()
    if not is_safe_data_path(path):
        raise ValueError('Unsafe or empty data path')
    value = owner.path_resolve(path)
    limit = max(0, int(max_text))
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        # json.dumps would emit NaN/Infinity, which breaks JSON.parse for the whole poll.
        return value if math.isfinite(value) else None
    if isinstance(value, str):
        return value[:limit]
    if isinstance(value, (set, frozenset)):
        return ','.join(sorted(str(item) for item in value))[:limit]
    return None


# -----------------------------------------------------------------------------
# Browser-bridge warnings
# -----------------------------------------------------------------------------
# An operator called through bpy.ops keeps its reports to itself: WARNING text is
# only printed to the system console and never reaches the status bar, the Info
# editor or the caller (only ERROR comes back, as RuntimeError). The bridge
# operators therefore also note their WARNING text here, and the server's task
# queue takes it after each call so the browser can show it. Main thread only.
_MAX_BRIDGE_WARNINGS = 4
_MAX_BRIDGE_WARNING_LEN = 500
_bridge_warnings: List[str] = []


def reset_bridge_warnings() -> None:
    _bridge_warnings.clear()


def note_bridge_warning(text) -> None:
    message = str(text or '').strip()
    if message and len(_bridge_warnings) < _MAX_BRIDGE_WARNINGS:
        _bridge_warnings.append(message[:_MAX_BRIDGE_WARNING_LEN])


def take_bridge_warnings() -> str:
    message = ' '.join(_bridge_warnings)[:_MAX_BRIDGE_WARNING_LEN]
    _bridge_warnings.clear()
    return message


# -----------------------------------------------------------------------------
# Directories
# -----------------------------------------------------------------------------

def _smart_selector_mutable_config_root(create: bool = False) -> Path:
    """Return the only automatic writable root used by Smart Selector.

    Windows Blender 5.1 resolves this to
    ``.../5.1/config/Smart_Selector_Suite``.  The legacy function names below
    remain for API compatibility, but no create request is allowed to target an
    installed Extension package.
    """
    config_text = ''
    try:
        config_text = _smart_selector_config_dir()
    except Exception:
        config_text = ''
    if config_text:
        root = Path(config_text).expanduser() / 'Smart_Selector_Suite'
    else:
        version = _smart_selector_blender_version_text()
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            root = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Selector_Suite'
        elif sys.platform == 'darwin':
            root = Path.home() / 'Library' / 'Application Support' / 'Blender' / version / 'config' / 'Smart_Selector_Suite'
        else:
            root = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_Selector_Suite'
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def extension_user_root(create: bool = False) -> Path:
    """Legacy writable-root API redirected to CONFIG/Smart_Selector_Suite."""
    return _smart_selector_mutable_config_root(create=create)


def legacy_extension_user_root(create: bool = False) -> Path | None:
    """Return a read-only legacy package location for compatibility reads."""
    del create
    try:
        return _smart_selector_readonly_extension_root('smart_selector_tool')
    except Exception:
        return None


def legacy_extension_project_root(create: bool = False) -> Path:
    del create
    legacy_root = legacy_extension_user_root(create=False)
    if legacy_root is None:
        return default_project_root(create=False)
    return legacy_root / 'projects'

def _directory_has_visible_entries(path: Path) -> bool:
    try:
        if not path.exists() or not path.is_dir():
            return False
        for child in path.iterdir():
            if child.name.startswith('.'):
                continue
            return True
    except Exception:
        return False
    return False

def legacy_default_root_dir() -> Path:
    return legacy_extension_project_root(create=False)


def default_project_root(create: bool = False) -> Path:
    root = extension_user_root(create=create) / 'projects'
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def _uses_default_root(raw_path: str | None) -> bool:
    text = str(raw_path or '').strip()
    if not text:
        return True
    try:
        resolved = Path(bpy.path.abspath(text)).resolve()
    except Exception:
        return False
    try:
        if resolved == legacy_default_root_dir().resolve():
            return True
    except Exception:
        pass
    for candidate in (default_project_root(create=False), legacy_extension_project_root(create=False)):
        try:
            if resolved == candidate.resolve():
                return True
        except Exception:
            pass
    return False


_ARCHIVE_DIRNAME = "__ARCHIVE__"

def _legacy_project_sources() -> tuple[Path, ...]:
    """Return known package-local project roots without creating any path."""
    candidates: list[Path] = []
    try:
        candidates.append(_smart_selector_manifest_dir() / 'projects')
    except Exception:
        pass
    for package_id in ('smart_selector_suite', 'smart_selector_tool', 'Smart_Selector_Tool'):
        try:
            root = _smart_selector_readonly_extension_root(package_id)
            if root is not None:
                candidates.append(root / 'projects')
        except Exception:
            pass
    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            key = str(candidate.resolve()).replace('\\', '/').lower()
        except Exception:
            key = str(candidate).replace('\\', '/').lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(candidate)
    return tuple(unique)


def _copy_legacy_projects_to_config(target: Path) -> None:
    """Copy legacy projects into CONFIG and leave every source untouched."""
    target.mkdir(parents=True, exist_ok=True)
    for source in _legacy_project_sources():
        if not _directory_has_visible_entries(source):
            continue
        try:
            for item in source.iterdir():
                if item.name in {'.DS_Store', 'Thumbs.db'}:
                    continue
                destination = target / item.name
                if item.is_dir():
                    _smart_selector_merge_tree(item, destination)
                elif item.is_file() and not destination.exists():
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, destination)
        except Exception:
            continue


def get_root_dir(create: bool = False) -> str:
    """Resolve the project root without allowing N-panel draw to write.

    Compatibility behavior:
    - Prefer an explicit custom root when set.
    - Otherwise use CONFIG/Smart_Selector_Suite/projects.
    - Read-only callers may inspect legacy package projects directly.
    - Mutating callers copy legacy projects into CONFIG first and never move,
      rename, or delete the package-local source.
    """
    prefs = get_prefs()
    raw_root = getattr(prefs, "root_dir", "") if prefs else ""
    if raw_root and not _uses_default_root(raw_root):
        try:
            custom_root = Path(bpy.path.abspath(raw_root)).resolve()
            if create:
                custom_root.mkdir(parents=True, exist_ok=True)
            return str(custom_root)
        except Exception:
            pass

    default_dir = default_project_root(create=create)
    if create:
        _copy_legacy_projects_to_config(default_dir)
        return str(default_dir)
    if _directory_has_visible_entries(default_dir):
        return str(default_dir)
    for legacy_dir in _legacy_project_sources():
        if _directory_has_visible_entries(legacy_dir):
            return str(legacy_dir)
    return str(default_dir)


def get_archive_root() -> str:
    root = get_root_dir(create=True)
    arc = os.path.join(root, _ARCHIVE_DIRNAME)
    try:
        os.makedirs(arc, exist_ok=True)
    except Exception:
        pass
    return arc

def _project_search_roots() -> List[Path]:
    """The folders that hold projects: the chosen root alone, or the default root and its legacy sources."""
    prefs = get_prefs()
    raw_root = getattr(prefs, "root_dir", "") if prefs else ""
    if raw_root and not _uses_default_root(raw_root):
        try:
            return [Path(bpy.path.abspath(raw_root)).resolve()]
        except Exception:
            pass
    return [default_project_root(create=False), *_legacy_project_sources()]


def list_projects(include_archived: bool = False) -> List[str]:
    """List project folders under the root directory.

    Normal projects:
        <root>/<ProjectName>

    Archived projects (optional):
        <root>/__ARCHIVE__/<ProjectName>
    """
    def _is_safe_foldername(n: str) -> bool:
        return bool(n) and sanitize_name(n, n) == n and n != _ARCHIVE_DIRNAME

    projects: List[str] = []
    roots = _project_search_roots()
    seen_roots: set[str] = set()
    for root_path in roots:
        try:
            root_key = str(root_path.resolve()).replace('\\', '/').lower()
        except Exception:
            root_key = str(root_path).replace('\\', '/').lower()
        if root_key in seen_roots or not root_path.is_dir():
            continue
        seen_roots.add(root_key)
        try:
            for child in root_path.iterdir():
                if child.is_dir() and _is_safe_foldername(child.name):
                    projects.append(child.name)
        except Exception:
            pass
        if include_archived:
            arc_root = root_path / _ARCHIVE_DIRNAME
            try:
                for child in arc_root.iterdir():
                    if child.is_dir() and sanitize_name(child.name, child.name) == child.name:
                        projects.append(child.name)
            except Exception:
                pass

    if not projects:
        return ["Default_Project"]
    return sorted(set(projects), key=lambda s: s.lower())


def _project_dir_candidates(project_name: str) -> List[Path]:
    name = sanitize_name(project_name, "Default_Project")
    roots = _project_search_roots()
    candidates: List[Path] = []
    seen: set[str] = set()
    for root in roots:
        for candidate in (root / name, root / _ARCHIVE_DIRNAME / name):
            try:
                resolved = candidate.resolve()
                key = str(resolved).replace('\\', '/').lower()
            except Exception:
                resolved = candidate
                key = str(candidate).replace('\\', '/').lower()
            if key in seen:
                continue
            seen.add(key)
            candidates.append(resolved)
    return candidates


def find_existing_project_dir(project_name: str) -> Optional[Path]:
    """Return existing project directory (root or archive) without creating folders."""
    for p in _project_dir_candidates(project_name):
        try:
            if p.exists() and p.is_dir():
                return p
        except Exception:
            continue
    return None


def resolve_project_dir(project_name: str, create_if_missing: bool = True) -> str:
    """Resolve project directory path.

    If an archived folder exists with the same name, it is preferred.
    If nothing exists and create_if_missing is True, it creates a normal project folder in root.
    """
    name = sanitize_name(project_name, "Default_Project")
    if create_if_missing:
        # Materialize/copy legacy package data into CONFIG before resolving the
        # writable project.  The package-local source remains untouched.
        get_root_dir(create=True)
    existing = find_existing_project_dir(name)
    if existing:
        return str(existing)

    root = Path(get_root_dir(create=create_if_missing)).resolve()
    p_dir = (root / name).resolve()
    if create_if_missing:
        try:
            p_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return str(p_dir)


def get_project_dir(project_name: str) -> str:
    """Back-compat wrapper: always returns a usable directory."""
    return resolve_project_dir(project_name, create_if_missing=True)

def get_image_dir(project_name: str) -> str:
    i_dir = os.path.join(get_project_dir(project_name), "image")
    try:
        os.makedirs(i_dir, exist_ok=True)
    except Exception:
        pass
    return i_dir

def safe_project_file_path(project_name: str, filename: str, allow_ext: Tuple[str, ...] = ('.json',)) -> str:
    project_name = sanitize_name(project_name, "Default_Project")
    filename = sanitize_filename(filename, default="selector.json", allow_ext=allow_ext)
    p = _safe_resolve_under(get_project_dir(project_name), filename)
    return str(p)

def safe_project_image_path(project_name: str, filename: str) -> str:
    project_name = sanitize_name(project_name, "Default_Project")
    filename = sanitize_filename(filename, default=f"img_{int(time.time())}.png", allow_ext=('.png', '.jpg', '.jpeg', '.webp'))
    p = _safe_resolve_under(get_image_dir(project_name), filename)
    return str(p)

def safe_image_url_to_path(project_name: str, img_url: str) -> Optional[str]:
    if not img_url or not img_url.startswith('/images/'):
        return None
    try:
        filename = img_url.split('/')[-1]
        return safe_project_image_path(project_name, filename)
    except Exception:
        return None


# -----------------------------------------------------------------------------
# Project management
# -----------------------------------------------------------------------------

def _project_location_parent(project_name: str) -> Path:
    """Return parent directory for an existing project (root or archive root).

    If the project does not exist yet, root is returned.
    """
    get_root_dir(create=True)
    existing = find_existing_project_dir(project_name)
    if existing:
        return existing.parent
    return Path(get_root_dir(create=True)).resolve()


def create_project(new_name: str) -> str:
    """Create a new normal project under the root directory."""
    name = sanitize_name(new_name, "New_Project")
    p_dir = Path(get_root_dir(create=True)).resolve() / name
    try:
        p_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return name


def rename_project(old_name: str, new_name: str) -> str:
    """Rename an existing project folder (works for normal + archived projects)."""
    old_name = sanitize_name(old_name, "Default_Project")
    new_name = sanitize_name(new_name, old_name)
    if old_name == new_name:
        return new_name

    get_root_dir(create=True)
    src = find_existing_project_dir(old_name)
    if not src:
        raise FileNotFoundError("Source project not found")

    parent = src.parent
    dst = (parent / new_name).resolve()

    # prevent conflicts in both root + archive
    if find_existing_project_dir(new_name):
        raise FileExistsError("Target project already exists")

    shutil.move(str(src), str(dst))
    return new_name


def duplicate_project(src_name: str, new_name: str) -> str:
    """Duplicate an existing project folder (keeps location: root stays root, archive stays archive)."""
    src_name = sanitize_name(src_name, "Default_Project")
    new_name = sanitize_name(new_name, src_name + "_copy")

    get_root_dir(create=True)
    src = find_existing_project_dir(src_name)
    if not src:
        raise FileNotFoundError("Source project not found")

    parent = src.parent
    dst = (parent / new_name).resolve()

    if dst.exists() or find_existing_project_dir(new_name):
        raise FileExistsError("Target project already exists")

    shutil.copytree(str(src), str(dst))
    return new_name


def archive_project(name: str) -> str:
    """Move a normal project into the __ARCHIVE__ folder and return the archived folder name.

    If the project is already archived, it is left as-is.
    """
    name = sanitize_name(name, "Default_Project")
    get_root_dir(create=True)
    src = find_existing_project_dir(name)
    if not src:
        return name

    # already archived
    if src.parent.name == _ARCHIVE_DIRNAME:
        return src.name

    ts = time.strftime("%Y%m%d_%H%M%S")
    archived_name = f"{name}__{ts}"
    dst = (Path(get_archive_root()).resolve() / archived_name).resolve()
    shutil.move(str(src), str(dst))
    return archived_name


# -----------------------------------------------------------------------------
# Atomic save + backups
# -----------------------------------------------------------------------------

def _max_backups() -> int:
    prefs = get_prefs()
    try:
        v = int(getattr(prefs, "max_backup_generations", 20))
        return max(0, min(200, v))
    except Exception:
        return 20

def _backup_dir_for(path: str) -> Path:
    p = Path(path)
    bdir = p.parent / ".backup"
    try:
        bdir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return bdir

def _rotate_backups(bdir: Path, stem_prefix: str, max_keep: int):
    if max_keep <= 0:
        return
    try:
        files = sorted([f for f in bdir.glob(stem_prefix + "*.bak")], key=lambda x: x.stat().st_mtime, reverse=True)
        for f in files[max_keep:]:
            try:
                f.unlink()
            except Exception:
                pass
    except Exception:
        pass

def make_backup(path: str):
    max_keep = _max_backups()
    if max_keep <= 0:
        return
    p = Path(path)
    if not p.exists() or not p.is_file():
        return
    bdir = _backup_dir_for(path)
    ts = time.strftime("%Y%m%d_%H%M%S")
    backup_name = f"{p.stem}__{ts}{p.suffix}.bak"
    dst = bdir / backup_name
    try:
        shutil.copy2(str(p), str(dst))
        _rotate_backups(bdir, p.stem + "__", max_keep)
    except Exception:
        pass

def atomic_write_text(path: str, text: str, encoding: str = "utf-8"):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    make_backup(path)
    fd, tmp = tempfile.mkstemp(prefix=p.stem + "_", suffix=p.suffix + ".tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="\n") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, str(p))
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

def atomic_write_bytes(path: str, data: bytes):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    make_backup(path)
    fd, tmp = tempfile.mkstemp(prefix=p.stem + "_", suffix=p.suffix + ".tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, str(p))
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# UI list helpers
# -----------------------------------------------------------------------------

def get_project_items(self, context):
    prefs = get_prefs()
    include_archived = bool(getattr(prefs, "show_archived_projects", False)) if prefs else False
    folders = list_projects(include_archived=include_archived)
    return [(f, f, "") for f in folders]

def get_selector_files(project_name: str):
    p_dir = resolve_project_dir(project_name, create_if_missing=False)
    try:
        return sorted([f for f in os.listdir(p_dir) if f.lower().endswith('.json') and os.path.isfile(os.path.join(p_dir, f))])
    except Exception:
        return []

# --- Smart Selector unified user_default path patch (2026-03-27) ---
def _smart_selector_manifest_extension_id(default: str = "") -> str:
    """Return a safe extension id.

    The current package id is read from blender_manifest.toml when resolving the
    active add-on. Explicit legacy ids are preserved so migration candidates do
    not collapse back to the current package id.
    """
    raw_default = str(default or "").strip()

    def _normalize(value: str) -> str:
        value = str(value or "").strip().strip('"').strip("'")
        if not value:
            return ""
        if ".user_default." in value or value.startswith("bl_ext."):
            value = value.rsplit(".", 1)[-1]
        elif "." in value:
            value = value.rsplit(".", 1)[-1]
        return value.strip()

    if raw_default not in {"smart_selector_tool", "Smart_Selector_Tool"}:
        try:
            current = Path(__file__).resolve().parent
            while True:
                manifest = current / "blender_manifest.toml"
                if manifest.is_file():
                    for raw_line in manifest.read_text(encoding="utf-8").splitlines():
                        line = raw_line.strip()
                        if not line.startswith("id"):
                            continue
                        _, _, value = line.partition("=")
                        manifest_id = _normalize(value)
                        if manifest_id:
                            return manifest_id
                    break
                if current.parent == current:
                    break
                current = current.parent
        except Exception:
            pass

    normalized = _normalize(raw_default)
    if normalized in {"utils", "common", "settings", "storage", "ui", "server"}:
        return "smart_selector_suite"
    return normalized


def _smart_selector_selector_current_candidates() -> tuple[str, ...]:
    values = ['smart_selector_suite', 'smart_selector_suite']
    try:
        values.extend(list(addon_id_candidates()))
    except Exception:
        pass
    out = []
    for value in values:
        value = _smart_selector_manifest_extension_id(value)
        if value and value.lower() not in {'smart_selector_tool'} and value not in out:
            out.append(value)
    return tuple(out) or ('smart_selector_suite',)

def _smart_selector_selector_legacy_candidates() -> tuple[str, ...]:
    values = ['smart_selector_tool', 'Smart_Selector_Tool']
    out = []
    for value in values:
        value = _smart_selector_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or ('smart_selector_tool',)


def _smart_selector_readonly_extension_root(package_id: str) -> Path | None:
    """Locate an installed/legacy package for reads; never create it."""
    package_id = _smart_selector_manifest_extension_id(package_id) or 'smart_selector_suite'
    candidates: list[Path] = []
    try:
        candidate = _smart_selector_extension_path_user_candidate(package_id)
        if candidate is not None:
            candidates.append(candidate)
    except Exception:
        pass
    try:
        manifest_dir = _smart_selector_manifest_dir()
        if package_id.lower() == 'smart_selector_suite':
            candidates.append(manifest_dir)
        candidates.append(manifest_dir.parent / package_id)
    except Exception:
        pass
    config_dir = _smart_selector_config_dir()
    if config_dir:
        config_path = Path(config_dir).expanduser()
        version_root = config_path.parent if config_path.name.lower() == 'config' else config_path
        candidates.append(version_root / 'extensions' / 'user_default' / package_id)
    scripts_dir = _smart_selector_scripts_dir()
    if scripts_dir:
        scripts_root = Path(scripts_dir).expanduser()
        candidates.append(scripts_root / 'extensions' / 'user_default' / package_id)
        candidates.append(scripts_root / 'extensions_user' / package_id)
    for candidate in candidates:
        try:
            if candidate.exists():
                return candidate
        except Exception:
            continue
    return candidates[0] if candidates else None


def _smart_selector_selector_extension_user_root(create: bool = False) -> Path:
    return _smart_selector_mutable_config_root(create=create)

def _smart_selector_selector_legacy_extension_user_root(create: bool = False) -> Path | None:
    del create
    for package_id in _smart_selector_selector_legacy_candidates():
        path = _smart_selector_readonly_extension_root(package_id)
        if path:
            return path
    return _smart_selector_readonly_extension_root('smart_selector_tool')

extension_user_root = _smart_selector_selector_extension_user_root
legacy_extension_user_root = _smart_selector_selector_legacy_extension_user_root

# --- Smart Selector user_default migration patch (2026-03-27) ---
def _smart_selector_manifest_dir() -> Path:
    try:
        current = Path(__file__).resolve().parent
        while True:
            if (current / "blender_manifest.toml").is_file():
                return current
            if current.parent == current:
                break
            current = current.parent
    except Exception:
        pass
    return Path(__file__).resolve().parent

def _smart_selector_has_visible_entries(path: Path) -> bool:
    try:
        return any(item.name not in {".DS_Store", "Thumbs.db"} for item in path.iterdir())
    except Exception:
        return False

def _smart_selector_merge_tree(src: Path, dst: Path) -> None:
    import shutil
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in {".DS_Store", "Thumbs.db"}:
            continue
        target = dst / item.name
        if item.is_dir():
            _smart_selector_merge_tree(item, target)
        elif item.is_file() and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)

def _smart_selector_blender_version_text() -> str:
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def _smart_selector_config_dir() -> str:
    utils_mod = getattr(bpy, "utils", None)
    user_resource = getattr(utils_mod, "user_resource", None) if utils_mod is not None else None
    if callable(user_resource):
        try:
            return str(user_resource("CONFIG", create=False) or "")
        except TypeError:
            try:
                return str(user_resource("CONFIG") or "")
            except Exception:
                return ""
        except Exception:
            return ""
    return ""


def _smart_selector_scripts_dir() -> str:
    utils_mod = getattr(bpy, "utils", None)
    user_resource = getattr(utils_mod, "user_resource", None) if utils_mod is not None else None
    if callable(user_resource):
        try:
            return str(user_resource("SCRIPTS", create=False) or "")
        except TypeError:
            try:
                return str(user_resource("SCRIPTS") or "")
            except Exception:
                return ""
        except Exception:
            return ""
    return ""


def _smart_selector_config_user_default_root(package_id: str, create: bool = False) -> Path:
    package_id = _smart_selector_manifest_extension_id(package_id) or "smart_selector_suite"
    config_dir = _smart_selector_config_dir()
    if config_dir:
        config_path = Path(config_dir).expanduser()
        # Blender's CONFIG resource normally points to <Blender>/<version>/config.
        version_root = config_path.parent if config_path.name.lower() == "config" else config_path
        target = version_root / "extensions" / "user_default" / package_id
    elif os.name == "nt":
        roaming = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        target = Path(roaming) / "Blender Foundation" / "Blender" / _smart_selector_blender_version_text() / "extensions" / "user_default" / package_id
    elif sys.platform == "darwin":
        target = Path.home() / "Library" / "Application Support" / "Blender" / _smart_selector_blender_version_text() / "extensions" / "user_default" / package_id
    else:
        target = Path.home() / ".config" / "blender" / _smart_selector_blender_version_text() / "extensions" / "user_default" / package_id
    if create:
        target.mkdir(parents=True, exist_ok=True)
    return target


def _smart_selector_normalized_path(path: Path) -> str:
    try:
        return str(path.resolve()).replace('\\', '/').rstrip('/').lower()
    except Exception:
        return str(path).replace('\\', '/').rstrip('/').lower()


def _smart_selector_same_path(a: Path, b: Path) -> bool:
    return _smart_selector_normalized_path(a) == _smart_selector_normalized_path(b)


def _smart_selector_extension_path_user_candidate(package_id: str) -> Path | None:
    utils_mod = getattr(bpy, "utils", None)
    ext_fn = getattr(utils_mod, "extension_path_user", None) if utils_mod is not None else None
    if not callable(ext_fn) or not package_id:
        return None
    call_variants = (
        ((package_id,), {"path": "", "create": False}),
        ((package_id, ""), {"create": False}),
        ((package_id,), {"create": False}),
        ((), {"module": package_id, "path": "", "create": False}),
        ((), {"module": package_id, "create": False}),
    )
    for args, kwargs in call_variants:
        try:
            value = ext_fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            return Path(value)
    return None


def _smart_selector_merge_known_legacy_subdirs(manifest_dir: Path, target_path: Path) -> None:
    """Migrate generated data from older package-local layouts without copying code files."""
    mappings = (
        ("user_data", target_path / "user_data"),
        ("settings", target_path / "settings"),
        ("projects", target_path / "projects"),
    )
    for dirname, dst in mappings:
        src = manifest_dir / dirname
        if not _smart_selector_has_visible_entries(src):
            continue
        try:
            _smart_selector_merge_tree(src, dst)
        except Exception:
            pass


def _smart_selector_version_user_default_root(package_id: str, create: bool = False) -> Path:
    """Compatibility API: current writes go to CONFIG, legacy roots are read-only."""
    package_id = _smart_selector_manifest_extension_id(package_id) or 'smart_selector_suite'
    if package_id.lower() in {'smart_selector_tool'}:
        legacy = _smart_selector_readonly_extension_root(package_id)
        return legacy if legacy is not None else _smart_selector_mutable_config_root(create=False)

    target_path = _smart_selector_mutable_config_root(create=create)
    if create:
        # Copy only known mutable subdirectories.  Never copy code and never
        # delete or rewrite the package-local source.
        legacy_candidates: list[Path] = []
        for candidate_id in ('smart_selector_suite', 'smart_selector_tool', 'Smart_Selector_Tool'):
            legacy = _smart_selector_readonly_extension_root(candidate_id)
            if legacy is not None:
                legacy_candidates.append(legacy)
        for legacy in legacy_candidates:
            if _smart_selector_same_path(legacy, target_path):
                continue
            _smart_selector_merge_known_legacy_subdirs(legacy, target_path)
    return target_path
