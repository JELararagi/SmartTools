# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

"""Single, atomic Smart Node Suite settings authority.

No timer, application handler, message-bus subscription, thread or modal loop is
registered here.  UI/property callbacks update the in-memory schema and, when
N-panel State Save is enabled, perform one bounded atomic write.  Unregister is
the deferred-save boundary when immediate saving is disabled.
"""

from __future__ import annotations

import copy
import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Any

import bpy

from .version import SCHEMA_VERSION

ADDON_ID = 'smart_node_suite'
CONFIG_FOLDER = 'Smart_Node_Suite'
CONFIG_FILE = 'Smart_Node_Suite.json'
_MAX_DEPTH = 4
_MAX_DICT_ITEMS = 512
_MAX_LIST_ITEMS = 256
_MAX_STRING_LENGTH = 16384
_MAX_FILE_BYTES = 4 * 1024 * 1024

_DATA: dict[str, Any] | None = None
_LAST_TEXT = ''
_APPLYING = False
_REGISTRATION_GUARD = False
_REGISTERED = False
_MAIN_WAS_CORRUPT = False
_CORRUPT_PRESERVED = False
_WRITE_BLOCKED_BY_CORRUPTION = False
_owned_rna_properties = []

_UI_PREFIXES = (
    'smart_node_suite_section_',
    'smart_node_suite_migrated_group_',
)
_SCENE_GROUPS = ('na_settings', 'node_color_tools')
_TRANSIENT_NAMES = {
    'rna_type', 'bl_rna', 'id_data', 'name', 'bl_idname',
    'capturing_key', 'capturing_key_2',
}


def settings_path(create: bool = True) -> Path:
    try:
        root = Path(bpy.utils.user_resource('CONFIG', create=create))
    except Exception:
        root = Path.home() / '.config' / 'blender' / '5.1' / 'config'
    folder = root / CONFIG_FOLDER
    if create:
        folder.mkdir(parents=True, exist_ok=True)
    return folder / CONFIG_FILE


def _empty_data() -> dict[str, Any]:
    return {
        'schema_version': SCHEMA_VERSION,
        'addon_id': ADDON_ID,
        'ui_state': {},
        'runtime': {
            'n_panel_state_save': True,
            'legacy_cleanup': False,
            'noise_background_callbacks': False,
            'node_wrangler_override': False,
        },
        'addon_preferences': {},
        'scene_tool_settings': {},
        'legacy': {},
    }


def _sanitize(value: Any, *, depth: int = 0) -> Any:
    if depth > _MAX_DEPTH:
        raise ValueError('settings nesting is too deep')
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return max(-(2 ** 63), min(2 ** 63 - 1, value))
    if isinstance(value, float):
        if value != value or value in (float('inf'), float('-inf')):
            raise ValueError('non-finite float in settings')
        return value
    if isinstance(value, str):
        return value[:_MAX_STRING_LENGTH]
    if isinstance(value, (list, tuple)):
        return [_sanitize(item, depth=depth + 1) for item in list(value)[:_MAX_LIST_ITEMS]]
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for index, (key, item) in enumerate(value.items()):
            if index >= _MAX_DICT_ITEMS:
                break
            text_key = str(key)[:256]
            out[text_key] = _sanitize(item, depth=depth + 1)
        return out
    try:
        seq = list(value)
    except Exception as exc:
        raise ValueError(f'unsupported settings value: {type(value).__name__}') from exc
    return _sanitize(seq, depth=depth)


def _validate_schema(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError('settings root must be an object')
    safe = _sanitize(raw)
    if not isinstance(safe, dict):
        raise ValueError('settings root is invalid')

    data = _empty_data()
    known_groups = {'ui_state', 'runtime', 'addon_preferences', 'scene_tool_settings', 'legacy'}
    for key in known_groups:
        value = safe.get(key)
        if isinstance(value, dict):
            if key == 'runtime':
                data[key].update(value)
            else:
                data[key] = value

    unknown = {
        key: value for key, value in safe.items()
        if key not in known_groups | {'schema_version', 'addon_id'}
    }
    if unknown:
        legacy = data.setdefault('legacy', {})
        existing_unknown = legacy.get('unknown_top_level')
        merged_unknown = dict(existing_unknown) if isinstance(existing_unknown, dict) else {}
        merged_unknown.update(unknown)
        legacy['unknown_top_level'] = merged_unknown

    runtime = data['runtime']
    aliases = {
        'smart_node_suite_npanel_state_save': 'n_panel_state_save',
        'smart_node_suite_legacy_cleanup_enabled': 'legacy_cleanup',
        'noise_nodes_background_callbacks': 'noise_background_callbacks',
        'noise_nodes_node_wrangler_override': 'node_wrangler_override',
    }
    for old_key, new_key in aliases.items():
        if old_key in runtime and new_key not in runtime:
            runtime[new_key] = bool(runtime[old_key])
    for key, default in (
        ('n_panel_state_save', True),
        ('legacy_cleanup', False),
        ('noise_background_callbacks', False),
        ('node_wrangler_override', False),
    ):
        runtime[key] = bool(runtime.get(key, default))

    data['schema_version'] = SCHEMA_VERSION
    data['addon_id'] = ADDON_ID
    return data


def _load_json_file(path: Path) -> dict[str, Any]:
    stat = path.stat()
    if stat.st_size > _MAX_FILE_BYTES:
        raise ValueError('settings file exceeds the size limit')
    with path.open('r', encoding='utf-8') as handle:
        return _validate_schema(json.load(handle))



def _read() -> dict[str, Any]:
    global _DATA, _LAST_TEXT, _MAIN_WAS_CORRUPT, _WRITE_BLOCKED_BY_CORRUPTION
    if isinstance(_DATA, dict):
        return _DATA

    path = settings_path(create=False)
    backup = path.with_suffix(path.suffix + '.bak')
    data = _empty_data()
    valid_source = ''
    main_exists = path.exists()
    backup_exists = backup.exists()

    if main_exists:
        try:
            data = _load_json_file(path)
            valid_source = 'main'
        except Exception:
            _MAIN_WAS_CORRUPT = True
    if not valid_source and backup_exists:
        try:
            data = _load_json_file(backup)
            valid_source = 'backup'
        except Exception:
            pass

    # When files exist but neither passes schema validation, keep every byte on
    # disk and block automatic writes.  Defaults may be shown in RNA for safety,
    # but unregister/property callbacks cannot overwrite the damaged authority.
    _WRITE_BLOCKED_BY_CORRUPTION = bool((main_exists or backup_exists) and not valid_source)
    _DATA = data
    try:
        _LAST_TEXT = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        _LAST_TEXT = ''
    return data

def begin_registration() -> None:
    global _DATA, _REGISTRATION_GUARD, _MAIN_WAS_CORRUPT, _CORRUPT_PRESERVED, _WRITE_BLOCKED_BY_CORRUPTION
    _DATA = None
    _MAIN_WAS_CORRUPT = False
    _CORRUPT_PRESERVED = False
    _WRITE_BLOCKED_BY_CORRUPTION = False
    _read()
    _REGISTRATION_GUARD = True


def _fsync_directory(directory: Path) -> None:
    flags = getattr(os, 'O_DIRECTORY', 0) | os.O_RDONLY
    try:
        descriptor = os.open(str(directory), flags)
    except Exception:
        return
    try:
        os.fsync(descriptor)
    except Exception:
        pass
    finally:
        os.close(descriptor)


def _write_bytes_unique(path: Path, payload: bytes) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temp_name = tempfile.mkstemp(
        prefix=f'.{path.name}.', suffix=f'.{uuid.uuid4().hex}.tmp', dir=str(path.parent)
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(descriptor, 'wb') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        return temp_path
    except Exception:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _preserve_corrupt_main(path: Path) -> None:
    global _CORRUPT_PRESERVED
    if _CORRUPT_PRESERVED or not _MAIN_WAS_CORRUPT or not path.exists():
        return
    target = path.with_name(f'{path.name}.corrupt.{uuid.uuid4().hex}')
    try:
        shutil.copy2(path, target)
        with target.open('rb') as handle:
            os.fsync(handle.fileno())
        _CORRUPT_PRESERVED = True
    except Exception:
        # A failed preservation must abort the replacement; callers check this.
        _CORRUPT_PRESERVED = False
        raise


def _replace_atomic(path: Path, payload: bytes) -> None:
    temp_path = _write_bytes_unique(path, payload)
    try:
        os.replace(str(temp_path), str(path))
        _fsync_directory(path.parent)
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass


def _canonical_payload(data: dict[str, Any]) -> bytes:
    validated = _validate_schema(data)
    return json.dumps(validated, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8')


def _validated_payload_from_path(path: Path) -> bytes | None:
    try:
        return _canonical_payload(_load_json_file(path))
    except Exception:
        return None


def _readback_matches(path: Path, expected: dict[str, Any]) -> bool:
    try:
        return _load_json_file(path) == expected
    except Exception:
        return False


def _restore_original_file(path: Path, existed: bool, original_bytes: bytes | None) -> None:
    """Best-effort rollback that never discards the file present before a write."""
    try:
        if existed and original_bytes is not None:
            _replace_atomic(path, original_bytes)
        elif not existed and path.exists():
            path.unlink()
            _fsync_directory(path.parent)
    except Exception:
        pass


def _write(data: dict[str, Any], *, allow_corrupt_recovery: bool = True) -> bool:
    global _DATA, _LAST_TEXT, _MAIN_WAS_CORRUPT
    if _WRITE_BLOCKED_BY_CORRUPTION:
        return False
    validated = _validate_schema(data)
    payload = _canonical_payload(validated)
    text = payload.decode('utf-8')
    path = settings_path(create=True)
    backup = path.with_suffix(path.suffix + '.bak')

    if text == _LAST_TEXT and path.exists() and not _MAIN_WAS_CORRUPT:
        if _readback_matches(path, validated) and _validated_payload_from_path(backup) is not None:
            _DATA = validated
            return True

    original_existed = path.exists()
    backup_existed = backup.exists()
    original_bytes: bytes | None = None
    backup_original_bytes: bytes | None = None
    if original_existed:
        try:
            original_bytes = path.read_bytes()
        except Exception:
            return False
    if backup_existed:
        try:
            backup_original_bytes = backup.read_bytes()
        except Exception:
            return False

    old_main_payload = _validated_payload_from_path(path) if original_existed else None
    old_backup_payload = _validated_payload_from_path(backup) if backup_existed else None

    try:
        if _MAIN_WAS_CORRUPT or (original_existed and old_main_payload is None):
            if not allow_corrupt_recovery:
                return False
            _MAIN_WAS_CORRUPT = True
            _preserve_corrupt_main(path)
            if original_existed and not _CORRUPT_PRESERVED:
                return False

        # The backup is prepared before replacing the authority. Prefer the last
        # valid main file, then an existing valid backup, and finally the new
        # validated payload for first-run installs.
        backup_payload = old_main_payload or old_backup_payload or payload
        _replace_atomic(backup, backup_payload)
        backup_expected = _validate_schema(json.loads(backup_payload.decode('utf-8')))
        if not _readback_matches(backup, backup_expected):
            raise ValueError('settings backup readback mismatch')

        _replace_atomic(path, payload)
        if not _readback_matches(path, validated):
            raise ValueError('settings authority readback mismatch')

        _DATA = validated
        _LAST_TEXT = text
        _MAIN_WAS_CORRUPT = False
        return True
    except Exception:
        # Restore the exact pre-write main bytes, even when they were malformed;
        # a separately preserved .corrupt copy is retained when recovery was
        # attempted. This guarantees that a failed save never erases prior data.
        _restore_original_file(path, original_existed, original_bytes)
        _restore_original_file(backup, backup_existed, backup_original_bytes)
        return False


def _simple(value):
    try:
        return _sanitize(value)
    except Exception:
        return None


def _serialize_group(obj, depth: int = 0) -> dict[str, Any]:
    if obj is None or depth > 2:
        return {}
    out: dict[str, Any] = {}
    try:
        props = tuple(getattr(getattr(obj, 'bl_rna', None), 'properties', ()) or ())
    except Exception:
        props = ()
    for prop in props[:_MAX_DICT_ITEMS]:
        try:
            name = str(getattr(prop, 'identifier', '') or '')
            if not name or name in _TRANSIENT_NAMES:
                continue
            if bool(getattr(prop, 'is_readonly', False)) or bool(getattr(prop, 'is_hidden', False)):
                continue
            value = getattr(obj, name)
        except Exception:
            continue
        if isinstance(value, (bool, int, float, str)) or value is None:
            simple = _simple(value)
            if simple is not None:
                out[name] = simple
            continue
        try:
            if hasattr(value, 'bl_rna'):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    out[name] = nested
                continue
        except Exception:
            pass
        simple = _simple(value)
        if simple is not None:
            out[name] = simple
    return out


def _apply_group(obj, values, depth: int = 0) -> None:
    if obj is None or not isinstance(values, dict) or depth > 2:
        return
    for name, value in list(values.items())[:_MAX_DICT_ITEMS]:
        if name in _TRANSIENT_NAMES or not hasattr(obj, name):
            continue
        if isinstance(value, dict):
            try:
                _apply_group(getattr(obj, name), value, depth + 1)
            except Exception:
                pass
            continue
        try:
            setattr(obj, name, value)
        except Exception:
            pass


def _addon_preferences(context=None):
    try:
        from .tool_preferences import addon_preferences
        return addon_preferences(context or getattr(bpy, 'context', None))
    except Exception:
        return None


def state_save_enabled(context=None) -> bool:
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None)
        if wm is not None and hasattr(wm, 'smart_node_suite_npanel_state_save'):
            return bool(wm.smart_node_suite_npanel_state_save)
    except Exception:
        pass
    return bool(_read().get('runtime', {}).get('n_panel_state_save', True))


def _collect(context=None) -> dict[str, Any]:
    data = copy.deepcopy(_read())
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    scene = getattr(ctx, 'scene', None) if ctx is not None else None

    ui_state: dict[str, Any] = {}
    if wm is not None:
        try:
            for key in tuple(wm.keys())[:_MAX_DICT_ITEMS]:
                text = str(key or '')
                if any(text.startswith(prefix) for prefix in _UI_PREFIXES):
                    ui_state[text] = bool(wm[key])
        except Exception:
            pass
        for name in ('smart_node_suite_section_always_on',):
            try:
                if hasattr(wm, name):
                    ui_state[name] = bool(getattr(wm, name))
            except Exception:
                pass
    data['ui_state'] = ui_state

    runtime = data.setdefault('runtime', {})
    if wm is not None:
        for prop_name, key, default in (
            ('smart_node_suite_npanel_state_save', 'n_panel_state_save', True),
            ('smart_node_suite_legacy_cleanup_enabled', 'legacy_cleanup', False),
            ('noise_nodes_background_callbacks', 'noise_background_callbacks', False),
            ('noise_nodes_node_wrangler_override', 'node_wrangler_override', False),
        ):
            try:
                runtime[key] = bool(getattr(wm, prop_name, default))
            except Exception:
                runtime[key] = bool(runtime.get(key, default))

    data['addon_preferences'] = _serialize_group(_addon_preferences(ctx))
    groups = data.setdefault('scene_tool_settings', {})
    if scene is not None:
        for name in _SCENE_GROUPS:
            values = _serialize_group(getattr(scene, name, None))
            if values:
                groups[name] = values
    return _validate_schema(data)


def save(context=None, *, force: bool = False) -> bool:
    if _APPLYING or _REGISTRATION_GUARD:
        return False
    data = _collect(context)
    global _DATA
    _DATA = data
    if not force and not state_save_enabled(context):
        return True
    return _write(data)


def request_save(context=None, *, force: bool = False) -> bool:
    return save(context, force=force)


def load_named_group(name: str) -> dict[str, Any]:
    value = _read().get('scene_tool_settings', {}).get(str(name or ''), {})
    return copy.deepcopy(value) if isinstance(value, dict) else {}


def save_named_group(name: str, values: dict[str, Any], context=None, source=None) -> bool:
    if _APPLYING or _REGISTRATION_GUARD:
        return False
    group_name = str(name or '').strip()[:128]
    if not group_name:
        return False
    payload = _serialize_group(source) if source is not None else _sanitize(values or {})
    if not isinstance(payload, dict):
        return False
    data = copy.deepcopy(_read())
    data.setdefault('scene_tool_settings', {})[group_name] = payload
    global _DATA
    _DATA = _validate_schema(data)
    if not state_save_enabled(context):
        return True
    return _write(_DATA)


def _sync_runtimes(context=None) -> None:
    """Apply only non-scanning runtime state after JSON restoration.

    Heavy legacy-node conversion is deliberately excluded here: a saved toggle
    must never trigger a full .blend/node-tree scan during add-on startup. The
    conversion runs only when the user changes that toggle or invokes Sync.
    """
    ctx = context or getattr(bpy, 'context', None)
    # Persisted one-shot cleanup/conversion toggles are restored as values only;
    # startup must not replay their file-wide scans. Only the lightweight,
    # explicitly opted-in Node Wrangler callable bridge is synchronized here.
    try:
        from . import noise_nodes
        noise_nodes.sync_persistent_runtime_from_properties(ctx)
    except Exception:
        pass


def apply(context=None) -> None:
    global _APPLYING
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _read()
    wm = getattr(ctx, 'window_manager', None)
    scene = getattr(ctx, 'scene', None)
    _APPLYING = True
    try:
        runtime = data.get('runtime', {})
        if wm is not None:
            for prop_name, key, default in (
                ('smart_node_suite_npanel_state_save', 'n_panel_state_save', True),
                ('smart_node_suite_legacy_cleanup_enabled', 'legacy_cleanup', False),
                ('noise_nodes_background_callbacks', 'noise_background_callbacks', False),
                ('noise_nodes_node_wrangler_override', 'node_wrangler_override', False),
            ):
                if hasattr(wm, prop_name):
                    try:
                        setattr(wm, prop_name, bool(runtime.get(key, default)))
                    except Exception:
                        pass
            for key, value in (data.get('ui_state', {}) or {}).items():
                text = str(key)
                if any(text.startswith(prefix) for prefix in _UI_PREFIXES):
                    try:
                        if hasattr(wm, text):
                            setattr(wm, text, bool(value))
                        else:
                            wm[text] = bool(value)
                    except Exception:
                        pass
        _apply_group(_addon_preferences(ctx), data.get('addon_preferences', {}))
        groups = data.get('scene_tool_settings', {})
        if scene is not None and isinstance(groups, dict):
            for name in _SCENE_GROUPS:
                _apply_group(getattr(scene, name, None), groups.get(name, {}))
    finally:
        _APPLYING = False
    _sync_runtimes(ctx)


def is_applying() -> bool:
    return bool(_APPLYING or _REGISTRATION_GUARD)


def _state_update(self, context):
    if is_applying():
        return
    enabled = bool(getattr(self, 'smart_node_suite_npanel_state_save', True))
    data = copy.deepcopy(_read())
    data.setdefault('runtime', {})['n_panel_state_save'] = enabled
    global _DATA
    _DATA = _validate_schema(data)
    # The transition itself is always durable. Re-enabling flushes deferred data.
    _write(_collect(context) if enabled else _DATA)


def _legacy_cleanup_update(self, context):
    if is_applying():
        return
    # This callback persists only the opt-in value. It never scans or edits the
    # current .blend, because property update callbacks cannot provide a clean
    # one-operation Undo boundary. The explicit operator owns that mutation.
    value = bool(getattr(self, 'smart_node_suite_legacy_cleanup_enabled', False))
    data = copy.deepcopy(_read())
    data.setdefault('runtime', {})['legacy_cleanup'] = value
    global _DATA
    _DATA = _validate_schema(data)
    if state_save_enabled(context):
        _write(_DATA)


def _ui_section_update(_self, context):
    if not is_applying():
        request_save(context, force=False)



def register_properties() -> None:
    global _owned_rna_properties
    from . import rna_ownership

    if _owned_rna_properties and all(
        rna_ownership.token_matches(token) for token in _owned_rna_properties
    ):
        return

    definitions = (
        (
            'smart_node_suite_npanel_state_save',
            bpy.props.BoolProperty(
                name='N-panel State Save',
                description='Function: saves Smart Node settings and section states to one schema-validated JSON file. How to use: enable for immediate atomic saving; disable to defer writes until the add-on is disabled or Blender closes normally.',
                default=True,
                update=_state_update,
            ),
        ),
        (
            'smart_node_suite_legacy_cleanup_enabled',
            bpy.props.BoolProperty(
                name='Legacy Proxy Cleanup',
                description='Function: makes the Run Legacy Cleanup Once button available. Turning this on does not scan or change the current file. How to use: enable this option, then click the button before saving normally in Blender.',
                default=False,
                update=_legacy_cleanup_update,
            ),
        ),
        (
            'smart_node_suite_section_always_on',
            bpy.props.BoolProperty(
                name='Always-on Toggles',
                description='Function: opens or closes the Always-on Toggles section at the top of the Smart Node N-panel. How to use: click its section header; the setting is saved by N-panel State Save.',
                default=False,
                update=_ui_section_update,
            ),
        ),
    )
    acquired = []
    try:
        for name, prop in definitions:
            acquired.append(rna_ownership.install_property(bpy.types.WindowManager, name, prop))
    except Exception:
        for token in reversed(acquired):
            try:
                rna_ownership.remove_property(token)
            except Exception:
                pass
        raise
    _owned_rna_properties = acquired


def unregister_properties() -> None:
    global _owned_rna_properties
    from . import rna_ownership
    while _owned_rna_properties:
        token = _owned_rna_properties.pop()
        try:
            rna_ownership.remove_property(token)
        except Exception:
            pass

def sync_scene_subscription(context=None) -> None:
    """Compatibility no-op: persistence has no resident scene subscription."""
    return None


def register() -> None:
    global _REGISTERED, _REGISTRATION_GUARD
    _REGISTERED = True
    try:
        apply(getattr(bpy, 'context', None))
    finally:
        _REGISTRATION_GUARD = False


def unregister() -> None:
    global _REGISTERED
    try:
        save(getattr(bpy, 'context', None), force=True)
    finally:
        _REGISTERED = False
        try:
            from . import legacy_cleanup
            legacy_cleanup.set_enabled(False)
        except Exception:
            pass
