# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

_RUNTIME_VALUES: dict[str, object] = {}


def prop_name(alias: str, field: str) -> str:
    clean_alias = ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(alias or '')).strip('_')
    clean_field = ''.join(ch.lower() if ch.isalnum() else '_' for ch in str(field or '')).strip('_')
    return f'integrated_{clean_alias}_{clean_field}'


def addon_preferences(context=None):
    try:
        import bpy
        ctx = context or bpy.context
        package_name = str(__package__ or 'smart_node_suite')
        candidates = (package_name, 'smart_node_suite')
        for module_name in dict.fromkeys(candidates):
            try:
                return ctx.preferences.addons[module_name].preferences
            except Exception:
                pass
    except Exception:
        pass
    return None


def _has_rna_property(data, name: str) -> bool:
    if data is None or not name:
        return False
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        if props is None:
            return False
        try:
            return props.get(name) is not None
        except Exception:
            return name in props.keys()
    except Exception:
        return False


def tool_value(alias: str, field: str, *, context=None, default=None):
    key = prop_name(alias, field)
    prefs = addon_preferences(context)
    if _has_rna_property(prefs, key):
        try:
            return getattr(prefs, key)
        except Exception:
            pass
    return _RUNTIME_VALUES.get(key, default)


def set_tool_value(alias: str, field: str, value, *, context=None) -> None:
    key = prop_name(alias, field)
    prefs = addon_preferences(context)
    if _has_rna_property(prefs, key):
        try:
            setattr(prefs, key, value)
        except Exception:
            pass
    _RUNTIME_VALUES[key] = value
    try:
        from . import persistent_settings
        if not persistent_settings.is_applying():
            persistent_settings.request_save(context, force=False)
    except Exception:
        pass
