# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from contextlib import contextmanager


@contextmanager
def preserve_object_transforms(reason: str = ''):
    _ = reason
    yield
