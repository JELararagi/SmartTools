# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

"""Pure Smart Tools Manager placement bridge for native Smart Node roots.

The bridge reads only already-loaded public Manager modules from the two fixed
package names used by Blender Extensions and legacy add-on installs.  It never
imports, enables, reloads, scans, patches, or mutates Manager state.  No cache,
I/O, timer, handler, redraw request, class mutation, or background work is used
from Panel.poll or Panel.draw.
"""

from __future__ import annotations

import sys
from types import ModuleType
from typing import Final

TOOL_KEY: Final[str] = 'SMART_NODE'
PUBLIC_RULE_FUNCTION: Final[str] = 'placement_allowed'
WORKSPACE_RUNTIME_FUNCTION: Final[str] = 'workspace_tool_allowed'
MANAGER_MODULE_NAMES: Final[tuple[str, str]] = (
    'bl_ext.user_default.smart_tools_manager',
    'smart_tools_manager',
)

LOGICAL_EDITOR_KEYS: Final[tuple[str, ...]] = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'UV_EDITOR',
    'SHADER_EDITOR',
    'COMPOSITOR',
    'GEOMETRY_NODE_EDITOR',
    'TEXTURE_NODE_EDITOR',
    'VIDEO_SEQUENCER',
    'MOVIE_CLIP_EDITOR',
    'DOPE_SHEET',
    'GRAPH_EDITOR',
    'DRIVERS',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'ASSET_BROWSER',
    'FILE_BROWSER',
    'SPREADSHEET',
)

PHYSICAL_TO_LOGICAL: Final[dict[str, tuple[str, ...]]] = {
    'VIEW_3D': ('VIEW_3D',),
    'IMAGE_EDITOR': ('IMAGE_EDITOR', 'UV_EDITOR'),
    'NODE_EDITOR': (
        'SHADER_EDITOR',
        'COMPOSITOR',
        'GEOMETRY_NODE_EDITOR',
        'TEXTURE_NODE_EDITOR',
    ),
    'SEQUENCE_EDITOR': ('VIDEO_SEQUENCER',),
    'CLIP_EDITOR': ('MOVIE_CLIP_EDITOR',),
    'DOPESHEET_EDITOR': ('DOPE_SHEET',),
    'GRAPH_EDITOR': ('GRAPH_EDITOR', 'DRIVERS'),
    'NLA_EDITOR': ('NLA_EDITOR',),
    'TEXT_EDITOR': ('TEXT_EDITOR',),
    'FILE_BROWSER': ('ASSET_BROWSER', 'FILE_BROWSER'),
    'SPREADSHEET': ('SPREADSHEET',),
}

_NODE_TREE_TO_LOGICAL: Final[dict[str, str]] = {
    'ShaderNodeTree': 'SHADER_EDITOR',
    'CompositorNodeTree': 'COMPOSITOR',
    'GeometryNodeTree': 'GEOMETRY_NODE_EDITOR',
    'TextureNodeTree': 'TEXTURE_NODE_EDITOR',
}
_DIRECT_PHYSICAL_TO_LOGICAL: Final[dict[str, str]] = {
    'VIEW_3D': 'VIEW_3D',
    'SEQUENCE_EDITOR': 'VIDEO_SEQUENCER',
    'CLIP_EDITOR': 'MOVIE_CLIP_EDITOR',
    'DOPESHEET_EDITOR': 'DOPE_SHEET',
    'NLA_EDITOR': 'NLA_EDITOR',
    'TEXT_EDITOR': 'TEXT_EDITOR',
    'SPREADSHEET': 'SPREADSHEET',
}

_NOT_READY_STRINGS: Final[frozenset[str]] = frozenset({
    'NOT_READY',
    'DISABLED',
    'UNAVAILABLE',
})



def _loaded_manager_modules() -> tuple[tuple[str, ModuleType], ...]:
    """Return only exact, already-loaded Manager package modules."""

    found: list[tuple[str, ModuleType]] = []
    for module_name in MANAGER_MODULE_NAMES:
        candidate = sys.modules.get(module_name)
        if isinstance(candidate, ModuleType):
            found.append((module_name, candidate))
    return tuple(found)


def _explicit_not_ready(result) -> bool:
    """Recognize only explicit non-authoritative Manager states."""

    if result is None:
        return True
    if isinstance(result, str):
        return result.strip().upper() in _NOT_READY_STRINGS
    if isinstance(result, dict):
        status = str(result.get('status', '') or '').strip().upper()
        return status in _NOT_READY_STRINGS and not isinstance(result.get('allowed'), bool)
    status = str(getattr(result, 'status', '') or '').strip().upper()
    allowed = getattr(result, 'allowed', None)
    return status in _NOT_READY_STRINGS and not isinstance(allowed, bool)


def _placement_result(callback, context, logical_key: str):
    """Call the public API using its documented current-cell arguments.

    Manager 1.5.57 exposes ``placement_allowed(tool_key, context=...,
    editor_key=...)``.  A positional compatibility retry is used only when a
    wrapper rejects those keyword names; no alternate Manager API is consulted.
    """

    try:
        return callback(TOOL_KEY, context=context, editor_key=logical_key)
    except TypeError as keyword_error:
        try:
            return callback(TOOL_KEY, context, logical_key)
        except TypeError:
            raise keyword_error


def manager_rule_allows(context, logical_key: str) -> bool:
    """Return the Manager's authoritative current-cell result.

    Known invalid editor keys fail closed.  If Manager is absent, explicitly
    disabled, lacks the public API, raises while unavailable, or explicitly
    reports NOT_READY without an authoritative boolean, Smart Node fails open so
    it remains independently usable.  Any other non-boolean result is an invalid
    authority response and fails closed.
    """

    editor_key = str(logical_key or '')
    if editor_key not in LOGICAL_EDITOR_KEYS:
        return False

    loaded = _loaded_manager_modules()
    if not loaded:
        return True

    for _module_name, module in loaded:
        if getattr(module, '__addon_enabled__', None) is False:
            continue

        callback = getattr(module, PUBLIC_RULE_FUNCTION, None)
        if not callable(callback):
            continue

        try:
            result = _placement_result(callback, context, editor_key)
        except Exception:
            return True

        if isinstance(result, bool):
            return result

        if isinstance(result, dict):
            allowed = result.get('allowed')
        else:
            allowed = getattr(result, 'allowed', None)
        if isinstance(allowed, bool):
            return allowed

        if _explicit_not_ready(result):
            return True

        return False

    return True


def _workspace_runtime_result(callback, context):
    """Call the public workspace aggregate API without importing Manager."""

    try:
        return callback(TOOL_KEY, context=context)
    except TypeError as keyword_error:
        try:
            return callback(TOOL_KEY, context)
        except TypeError:
            raise keyword_error


def workspace_runtime_allowed(context) -> bool:
    """Return Manager's any-editor workspace result for Suite runtime only.

    The public Manager callback owns workspace resolution and its cached
    any-editor OR.  Missing, disabled, unready, invalid, or temporarily failing
    Manager authority fails open so Smart Node is never stopped by a bridge
    availability problem.  The bridge caches no result, and only a boolean
    callback result is authoritative.
    """

    loaded = _loaded_manager_modules()
    if not loaded:
        return True

    for _module_name, module in loaded:
        try:
            if getattr(module, '__addon_enabled__', None) is False:
                continue

            callback = getattr(module, WORKSPACE_RUNTIME_FUNCTION, None)
            if not callable(callback):
                continue

            result = _workspace_runtime_result(callback, context)
        except Exception:
            return True

        if isinstance(result, bool):
            return result
        return True

    return True


def logical_editor_key(context) -> str | None:
    """Resolve one of the 17 known logical editors without guessing."""

    area = getattr(context, 'area', None)
    space = getattr(context, 'space_data', None)
    area_type = str(getattr(area, 'type', '') or '')
    space_type = str(getattr(space, 'type', '') or '')
    if not area_type or not space_type or area_type != space_type:
        return None

    if area_type == 'NODE_EDITOR':
        return _NODE_TREE_TO_LOGICAL.get(str(getattr(space, 'tree_type', '') or ''))

    if area_type == 'IMAGE_EDITOR':
        mode = str(getattr(space, 'mode', '') or '')
        area_ui_type = str(getattr(area, 'ui_type', '') or '')
        if mode == 'UV' or area_ui_type == 'UV':
            return 'UV_EDITOR'
        if mode in {'VIEW', 'PAINT', 'MASK'} or area_ui_type == 'IMAGE_EDITOR':
            return 'IMAGE_EDITOR'
        return None

    if area_type == 'GRAPH_EDITOR':
        mode = str(getattr(space, 'mode', '') or '')
        if mode == 'DRIVERS':
            return 'DRIVERS'
        if mode == 'FCURVES':
            return 'GRAPH_EDITOR'
        return None

    if area_type == 'FILE_BROWSER':
        browse_mode = str(getattr(space, 'browse_mode', '') or '')
        if browse_mode == 'ASSETS':
            return 'ASSET_BROWSER'
        if browse_mode == 'FILES':
            return 'FILE_BROWSER'
        return None

    return _DIRECT_PHYSICAL_TO_LOGICAL.get(area_type)


def panel_poll(context, *, physical_space: str, logical_keys: tuple[str, ...]) -> bool:
    """Pure native-root poll: physical match, logical match, Manager rule."""

    expected_space = str(physical_space or '')
    allowed_logical = tuple(str(item) for item in logical_keys)
    if expected_space not in PHYSICAL_TO_LOGICAL:
        return False
    if not allowed_logical or any(key not in PHYSICAL_TO_LOGICAL[expected_space] for key in allowed_logical):
        return False

    area = getattr(context, 'area', None)
    space = getattr(context, 'space_data', None)
    if str(getattr(area, 'type', '') or '') != expected_space:
        return False
    if str(getattr(space, 'type', '') or '') != expected_space:
        return False

    logical_key = logical_editor_key(context)
    if logical_key is None or logical_key not in allowed_logical:
        return False
    return manager_rule_allows(context, logical_key)


def clear_runtime_state() -> None:
    """Compatibility no-op; placement polling keeps no runtime state."""

    return None


def runtime_snapshot() -> dict[str, object]:
    """Return plain diagnostics without mutating placement state."""

    loaded_names = tuple(
        name for name in MANAGER_MODULE_NAMES
        if isinstance(sys.modules.get(name), ModuleType)
    )
    return {
        'loaded_public_modules': loaded_names,
        'placement_cache_count': 0,
        'logical_editor_count': len(LOGICAL_EDITOR_KEYS),
        'physical_space_count': len(PHYSICAL_TO_LOGICAL),
        'module_lookup_names': MANAGER_MODULE_NAMES,
        'public_rule_function': PUBLIC_RULE_FUNCTION,
    }
