# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

__version__ = "1.4.33"

bl_info = {
    'name': 'Smart Node',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'Node Editor > Sidebar (N) > Smart Node or Shift-W',
    'description': 'Smart Node tools for node creation, wiring, labels, layout, branch selection, and node-tree management.',
    'warning': '',
    'doc_url': '',
    'support': 'COMMUNITY',
    'category': 'Node',
}

import importlib
from types import ModuleType

import bpy
from bpy.props import IntProperty, StringProperty

from .version import ADDON_VERSION, ADDON_VERSION_STRING

_MODULE_ORDER = (
    'i18n',
    'persistent_settings',
    'node_arrange',
    'node_color_tools',
    'node_presets',
    'noise_nodes',
    'operators',
    'interface',
    'preferences',
    'sidebar_guard',
)
_loaded_modules: dict[str, ModuleType] = {}
_registered_steps: list[tuple[str, int]] = []
_registered = False
_registration_token = ''
_owned_scene_properties = []
_registration_blocked_reason = ''


def _module(name: str) -> ModuleType:
    module = _loaded_modules.get(name)
    if module is None:
        module = importlib.import_module(f'.{name}', __name__)
        _loaded_modules[name] = module
    return module



def _register_scene_properties() -> None:
    global _owned_scene_properties
    rna_ownership = importlib.import_module('.rna_ownership', __name__)
    if _owned_scene_properties and all(
        rna_ownership.token_matches(token) for token in _owned_scene_properties
    ):
        return
    tip = _module('i18n').tip
    definitions = {
        'SmartNodeSuiteBusyDrawing': StringProperty(
            name='Smart Node Drawing State',
            default='',
            options={'HIDDEN', 'SKIP_SAVE'},
            description=tip(
                'Function: stores transient coordinates used only while a Smart Node lazy gesture is active. How to use: Smart Node manages this internal value automatically; do not edit it manually.',
                '機能: Smart Node の簡単コネクト操作実行中だけ使う一時座標を保持します。使い方: Smart Node が自動管理する内部値のため、手動編集は不要です。',
            ),
        ),
        'SmartNodeSuiteLazySource': StringProperty(
            name='Smart Node Lazy Source',
            default='',
            options={'HIDDEN', 'SKIP_SAVE'},
            description=tip(
                'Function: internal value kept only for compatibility with older files. How to use: do not edit it manually.',
                '機能: 古いファイルとの互換のためだけに残している内部の値です。使い方: 手動編集は不要です。',
            ),
        ),
        'SmartNodeSuiteLazyTarget': StringProperty(
            name='Smart Node Lazy Target',
            default='',
            options={'HIDDEN', 'SKIP_SAVE'},
            description=tip(
                'Function: internal value kept only for compatibility with older files. How to use: do not edit it manually.',
                '機能: 古いファイルとの互換のためだけに残している内部の値です。使い方: 手動編集は不要です。',
            ),
        ),
        'SmartNodeSuiteSourceSocket': IntProperty(
            name='Smart Node Source Socket',
            default=0,
            min=0,
            options={'HIDDEN', 'SKIP_SAVE'},
            description=tip(
                'Function: internal value kept only for compatibility with older files. How to use: do not edit it manually.',
                '機能: 古いファイルとの互換のためだけに残している内部の値です。使い方: 手動編集は不要です。',
            ),
        ),
    }
    acquired = []
    try:
        for name, prop in definitions.items():
            acquired.append(rna_ownership.install_property(bpy.types.Scene, name, prop))
    except Exception:
        for token in reversed(acquired):
            try:
                rna_ownership.remove_property(token)
            except Exception:
                pass
        raise
    _owned_scene_properties = acquired


def _unregister_scene_properties() -> None:
    global _owned_scene_properties
    rna_ownership = importlib.import_module('.rna_ownership', __name__)
    while _owned_scene_properties:
        token = _owned_scene_properties.pop()
        try:
            rna_ownership.remove_property(token)
        except Exception:
            pass


def _record_unregister(label: str, callback) -> None:
    lifecycle = importlib.import_module('.runtime_lifecycle', __name__)
    cleanup_id = lifecycle.register_cleanup(
        callback,
        token=_registration_token,
        label=label,
    )
    _registered_steps.append((label, cleanup_id))


def _rollback_registered_steps() -> None:
    lifecycle = importlib.import_module('.runtime_lifecycle', __name__)
    while _registered_steps:
        _label, cleanup_id = _registered_steps.pop()
        lifecycle.unregister_cleanup(
            cleanup_id,
            token=_registration_token,
            run=True,
        )


def register() -> None:
    global _registered, _registration_token, _registration_blocked_reason
    if _registered:
        return

    _registration_blocked_reason = ''
    lifecycle = importlib.import_module('.runtime_lifecycle', __name__)
    _registered_steps.clear()
    _registration_token = lifecycle.begin_generation()
    try:
        i18n = _module('i18n')
        i18n.begin_definitions()
        i18n.register()
        _record_unregister('i18n', i18n.unregister)

        settings = _module('persistent_settings')
        settings.begin_registration()
        settings.register_properties()
        _record_unregister('persistent properties', settings.unregister_properties)

        _register_scene_properties()
        _record_unregister('scene properties', _unregister_scene_properties)

        for name in ('node_arrange', 'node_color_tools', 'node_presets', 'noise_nodes', 'operators', 'interface', 'preferences'):
            module = _module(name)
            module.register()
            _record_unregister(name, module.unregister)

        settings.register()
        _record_unregister('persistent settings', settings.unregister)

        guard = _module('sidebar_guard')
        guard.register()
        _record_unregister('sidebar guard', guard.unregister)
        i18n.end_definitions()
        i18n.register()
        _registered = True
    except Exception as exc:
        _module('i18n').end_definitions()
        _rollback_registered_steps()
        lifecycle.end_generation(_registration_token)
        _registration_token = ''
        _registered = False
        ownership = importlib.import_module('.rna_ownership', __name__)
        if isinstance(exc, ownership.RestartRequiredError):
            _registration_blocked_reason = str(exc)
            return
        raise


def unregister() -> None:
    global _registered, _registration_token, _registration_blocked_reason
    lifecycle = importlib.import_module('.runtime_lifecycle', __name__)
    token = _registration_token
    _rollback_registered_steps()
    lifecycle.end_generation(token)
    _registration_token = ''
    _registered = False
    _registration_blocked_reason = ''

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
