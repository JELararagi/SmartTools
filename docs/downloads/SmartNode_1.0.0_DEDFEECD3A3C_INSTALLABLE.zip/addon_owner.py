# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

_DEFAULT_ADDON_ID = 'smart_node_suite'


def addon_owner_id() -> str:
    """Return the workspace owner ID for Smart Node Suite UI classes.

    Blender's Workspace add-on filter matches Panel.bl_owner_id against the
    enabled owner IDs stored on the workspace.  Extension installs use a module
    ID such as ``bl_ext.user_default.smart_node_suite``; development or legacy
    installs can use the package name directly.
    """
    package = str(__package__ or '').strip()
    if package:
        return package
    module = str(__name__ or '').strip()
    if '.' in module:
        return module.rsplit('.', 1)[0]
    return _DEFAULT_ADDON_ID
