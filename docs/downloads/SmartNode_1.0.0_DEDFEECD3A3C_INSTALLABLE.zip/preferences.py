# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.props import EnumProperty, BoolProperty, StringProperty, FloatProperty, FloatVectorProperty, IntProperty
from bpy.app.translations import (
    pgettext_n as n_,
    pgettext_iface as iface_,
    contexts as i18n_contexts,
)

from . import interface, rna_ownership
from .i18n import t as _t, tip as _tip

from .utils.constants import nice_hotkey_name


# Principled prefs
class SNSPrincipledPreferences(bpy.types.PropertyGroup):
    base_color: StringProperty(
        name='Base Color',
        default='diffuse diff albedo base col color basecolor',
        description=_tip('Function: words used to detect base-color texture maps automatically. How to use: add space-separated name fragments that appear in your texture filenames.', '機能: ベースカラーテクスチャを自動検出するための名前キーワードです。使い方: テクスチャファイル名に含まれる断片をスペース区切りで追加します。'))
    metallic: StringProperty(
        name='Metallic',
        default='metallic metalness metal mtl',
        description=_tip('Function: words used to detect metallic/metalness texture maps automatically. How to use: add filename fragments used by your asset library.', '機能: メタリック/メタルネステクスチャを自動検出するための名前キーワードです。使い方: 使用しているアセットライブラリのファイル名断片を追加します。'))
    specular: StringProperty(
        name='Specular',
        default='specularity specular spec spc',
        description=_tip('Function: words used to detect specular texture maps automatically. How to use: add common filename fragments for specular maps.', '機能: スペキュラーテクスチャを自動検出するための名前キーワードです。使い方: スペキュラーマップで使う一般的なファイル名断片を追加します。'))
    normal: StringProperty(
        name='Normal',
        default='normal nor nrm nrml norm',
        description=_tip('Function: words used to detect normal maps automatically. How to use: add terms such as nrm or normal that appear in your normal-map filenames.', '機能: ノーマルマップを自動検出するための名前キーワードです。使い方: nrm や normal など、ノーマルマップのファイル名に含まれる語を追加します。'))
    bump: StringProperty(
        name='Bump',
        default='bump bmp',
        description=_tip('Function: words used to detect bump maps automatically. How to use: add filename fragments for grayscale bump textures.', '機能: バンプマップを自動検出するための名前キーワードです。使い方: グレースケールバンプ画像のファイル名断片を追加します。'))
    rough: StringProperty(
        name='Roughness',
        default='roughness rough rgh',
        description=_tip('Function: words used to detect roughness maps automatically. How to use: add filename fragments that identify roughness textures.', '機能: ラフネスマップを自動検出するための名前キーワードです。使い方: ラフネステクスチャを識別するファイル名断片を追加します。'))
    gloss: StringProperty(
        name='Gloss',
        default='gloss glossy glossiness',
        description=_tip('Function: words used to detect gloss/glossiness maps automatically. How to use: add terms used by older or non-PBR texture sets.', '機能: グロス/グロシネスマップを自動検出するための名前キーワードです。使い方: 古い形式や非PBR系テクスチャセットで使う語を追加します。'))
    displacement: StringProperty(
        name='Displacement',
        default='displacement displace disp dsp height heightmap',
        description=_tip('Function: words used to detect displacement or height maps automatically. How to use: add terms such as height, disp, or displacement.', '機能: ディスプレイスメント/ハイトマップを自動検出するための名前キーワードです。使い方: height、disp、displacement などの語を追加します。'))
    transmission: StringProperty(
        name='Transmission',
        default='transmission transparency',
        description=_tip('Function: words used to detect transmission or transparency maps automatically. How to use: add filename fragments that identify transparent material maps.', '機能: 透過/トランスミッション系マップを自動検出するための名前キーワードです。使い方: 透明素材マップを識別するファイル名断片を追加します。'))
    emission: StringProperty(
        name='Emission',
        default='emission emissive emit',
        description=_tip('Function: words used to detect emission maps automatically. How to use: add terms used for glowing or self-illuminated texture maps.', '機能: 発光マップを自動検出するための名前キーワードです。使い方: 発光または自己発光テクスチャで使う語を追加します。'))
    alpha: StringProperty(
        name='Alpha',
        default='alpha opacity',
        description=_tip('Function: words used to detect alpha or opacity maps automatically. How to use: add filename fragments used for cutout or transparency masks.', '機能: アルファ/不透明度マップを自動検出するための名前キーワードです。使い方: 切り抜きや透明マスク用ファイル名断片を追加します。'))
    ambient_occlusion: StringProperty(
        name='Ambient Occlusion',
        default='ao ambient occlusion',
        description=_tip('Function: words used to detect ambient occlusion maps automatically. How to use: add AO-related filename fragments used in your texture library.', '機能: アンビエントオクルージョンマップを自動検出するための名前キーワードです。使い方: テクスチャライブラリで使う AO 関連のファイル名断片を追加します。'))


# Addon prefs
class SNSSmartNodeSuite(bpy.types.AddonPreferences):
    bl_idname = __package__

    merge_hide: EnumProperty(
        name="Hide Mix Nodes",
        items=(
            ("ALWAYS", "Always", "Always collapse the new merge nodes"),
            ("NON_SHADER", "Non-Shader", "Collapse in all cases except for shaders"),
            ("NEVER", "Never", "Never collapse the new merge nodes")
        ),
        default='NON_SHADER',
        description=_tip('Function: controls whether newly created merge nodes are collapsed after merge hotkeys. How to use: choose Always for compact graphs, Non-Shader to keep shader nodes editable, or Never to leave all merge nodes expanded.', '機能: マージ系ホットキーで作成した結合ノードを折りたたむか制御します。使い方: グラフをコンパクトにするなら常に、シェーダーは編集しやすく残すなら非シェーダー、すべて展開したいならしないを選びます。'),
    )
    merge_position: EnumProperty(
        name="Mix Node Position",
        items=(
            ("CENTER", "Center", "Place the Mix node between the two nodes"),
            ("BOTTOM", "Bottom", "Place the Mix node at the same height as the lowest node")
        ),
        default='CENTER',
        description=_tip('Function: controls where newly inserted Mix nodes are placed between selected nodes. How to use: choose Center for balanced graphs or Bottom when you prefer new Mix nodes to follow the lowest selected node.', '機能: 選択ノード間に挿入される ミックスノードの配置位置を制御します。使い方: バランス良く置くなら中央、最も下の選択ノードに合わせたい場合は下を選びます。'),
    )


    # Node editor visual theme controls.
    view_show_advanced: BoolProperty(
        name='Show Advanced View Colors',
        default=False,
        description=_tip('Function: shows additional node-editor color controls in the Smart Node panel. How to use: enable this when you also want to edit wire, active node, selected node, and backdrop colors instead of only grid and background settings.', '機能: Smart Node パネルに追加のノードエディター配色項目を表示します。使い方: グリッドと背景だけでなく、ワイヤ、アクティブノード、選択ノード、バックドロップ色も調整したい場合に有効にします。'),
    )
    view_grid_color: FloatVectorProperty(
        name='Grid Color',
        subtype='COLOR_GAMMA',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.1882, 0.1882, 0.1882),
        description=_tip('Function: stores the node-editor grid-dot color to apply to the active Blender theme. How to use: choose a brighter color for stronger grid visibility or a darker color for a calmer graph background, then press Apply View Settings.', '機能: 現在の Blender テーマへ適用するノードエディターのグリッド点カラーを保存します。使い方: グリッドを見やすくしたい場合は明るめ、背景を落ち着かせたい場合は暗めにして「表示設定を適用」を押します。'),
    )
    view_background_color: FloatVectorProperty(
        name='Background Color',
        subtype='COLOR_GAMMA',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.1020, 0.1020, 0.1020),
        description=_tip('Function: stores the node-editor background color for the active Blender theme. How to use: set this together with Grid Color so the grid remains visible without overpowering node cards.', '機能: 現在の Blender テーマで使うノードエディター背景色を保存します。使い方: グリッドカラーと合わせて設定し、ノードカードを邪魔せずグリッドが見える状態にします。'),
    )
    view_grid_levels: IntProperty(
        name='Grid Levels',
        min=0,
        max=3,
        default=3,
        description=_tip('Function: controls how many subdivision levels the node-editor dot grid displays. How to use: use 0 for the simplest background, or 3 when you want the normal detailed dot grid while arranging nodes.', '機能: ノードエディターのドットグリッドに表示する分割レベル数を設定します。使い方: 背景を最小限にしたい場合は 0、通常の細かいドットグリッドで整列したい場合は 3 を使います。'),
    )
    view_node_backdrop_color: FloatVectorProperty(
        name='Node Backdrop Color',
        subtype='COLOR_GAMMA',
        size=4,
        min=0.0,
        max=1.0,
        default=(0.1882, 0.1882, 0.1882, 1.0),
        description=_tip('Function: stores the background shade used behind node cards in the node editor theme. How to use: adjust this when the node field feels too bright or too flat compared with the grid.', '機能: ノードエディターテーマ内でノードカード背面に使われる背景色を保存します。使い方: グリッドに対してノード領域が明るすぎる、または平坦に見える場合に調整します。'),
    )
    view_wire_color: FloatVectorProperty(
        name='Wire Color',
        subtype='COLOR_GAMMA',
        size=4,
        min=0.0,
        max=1.0,
        default=(0.1020, 0.1020, 0.1020, 1.0),
        description=_tip('Function: stores the default wire color for unselected node links. How to use: raise brightness or alpha when links are hard to read against the selected background.', '機能: 未選択ノードリンクの標準ワイヤカラーを保存します。使い方: 背景に対してリンクが読みづらい場合は明度またはアルファを上げます。'),
    )
    view_wire_select_color: FloatVectorProperty(
        name='Selected Wire Color',
        subtype='COLOR_GAMMA',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 0.7020),
        description=_tip('Function: stores the color used for selected node links. How to use: choose a clear high-contrast color so selected wiring is easy to identify in dense graphs.', '機能: 選択中のノードリンクに使うカラーを保存します。使い方: 密なグラフでも選択配線を見分けやすい高コントラスト色を選びます。'),
    )
    view_selected_node_color: FloatVectorProperty(
        name='Selected Node Color',
        subtype='COLOR_GAMMA',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.9294, 0.3412, 0.0),
        description=_tip('Function: stores the outline/accent color for selected nodes in the active Blender theme. How to use: choose a color that stands out from the graph background and custom node colors.', '機能: 現在の Blender テーマで選択ノードの輪郭/アクセントに使うカラーを保存します。使い方: 背景やカスタムノード色からはっきり区別できる色を選びます。'),
    )
    view_active_node_color: FloatVectorProperty(
        name='Active Node Color',
        subtype='COLOR_GAMMA',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
        description=_tip('Function: stores the accent color for the active node. How to use: choose a clean highlight color so the active node can be found quickly before running node operations.', '機能: アクティブノードのアクセントカラーを保存します。使い方: ノード操作前にアクティブノードを素早く見つけられる明確な色を選びます。'),
    )
    view_noodle_curving: IntProperty(
        name='Noodle Curving',
        min=0,
        max=10,
        default=4,
        description=_tip('Function: controls the curvature of node link noodles in the active Blender theme. How to use: lower the value for straighter technical diagrams or raise it for softer curved connections.', '機能: 現在の Blender テーマにおけるノードリンク曲線の曲がり具合を設定します。使い方: 技術図のように直線寄りにしたい場合は小さく、柔らかい曲線にしたい場合は大きくします。'),
    )
    view_dash_alpha: FloatProperty(
        name='Dash Alpha',
        min=0.0,
        max=1.0,
        default=0.5,
        description=_tip('Function: controls opacity for dashed wire lines in the active Blender theme. How to use: increase the value when dashed links are too faint or lower it when they distract from node labels.', '機能: 現在の Blender テーマで破線ワイヤの不透明度を設定します。使い方: 破線リンクが薄すぎる場合は上げ、ノードラベルを邪魔する場合は下げます。'),
    )

    # Major-grid-aware layout controls.
    layout_use_major_grid_spacing: BoolProperty(
        name='Use Major Grid Spacing',
        default=True,
        description=_tip('Function: makes Smart Node layout, distribute, stack, and grid tools use major grid-dot counts instead of free numeric gaps. How to use: enable this when you want columns and rows to land on the same thick grid rhythm across the whole node tree.', '機能: Smart Node の整列、均等配置、スタック、グリッド配置ツールで自由な数値間隔ではなく太いグリッド点の個数を使います。使い方: ノードツリー全体の列と行を同じ太いグリッド間隔にそろえたい場合に有効にします。'),
    )
    layout_major_grid_unit: FloatProperty(
        name='Major Grid Unit',
        min=8.0,
        max=1000.0,
        default=120.0,
        description=_tip('Function: defines how many node-editor units count as one major grid dot for Smart Node layout tools. How to use: set this to the visual distance between thick grid dots in your preferred theme; all Column Major Dots and Row Major Dots values multiply this unit.', '機能: Smart Node のレイアウトツールで「太いグリッド点 1 個」として扱うノードエディター単位を定義します。使い方: 使用テーマで見やすい太いグリッド点間の距離に合わせます。「列の太い点数」と「行の太い点数」はこの値に掛けられます。'),
    )
    layout_column_major_steps: IntProperty(
        name='Column Major Dots',
        min=1,
        max=50,
        default=3,
        description=_tip('Function: sets how many major grid dots separate neighboring layout columns. How to use: increase this when parent and child columns need more horizontal breathing room or when node titles and sockets are wide.', '機能: 隣り合うレイアウト列を太いグリッド点何個分離すかを設定します。使い方: 親列と子列の横方向余白が必要な場合や、ノード名/ソケット名が長い場合は大きくします。'),
    )
    layout_row_major_steps: IntProperty(
        name='Row Major Dots',
        min=1,
        max=50,
        default=2,
        description=_tip('Function: sets how many major grid dots separate neighboring layout rows. How to use: increase this when sibling nodes overlap vertically or when tall nodes need more readable row spacing.', '機能: 隣り合うレイアウト行を太いグリッド点何個分離すかを設定します。使い方: 兄弟ノードが縦に重なる場合や、背の高いノードの行間を読みやすくしたい場合は大きくします。'),
    )
    layout_min_gap_major_steps: FloatProperty(
        name='Minimum Bounds Gap Dots',
        min=0.0,
        max=20.0,
        default=1.0,
        description=_tip('Function: keeps a minimum empty gap, measured in major grid dots, when node size would otherwise make left-edge or top-edge spacing overlap. How to use: leave 1.0 for a safe visible gap, or lower it for compact technical graphs.', '機能: 左端/上端基準の間隔だけではノードサイズにより重なる場合、太いグリッド点単位の最小空き幅を確保します。使い方: 見やすい隙間を保つなら 1.0、コンパクトな技術グラフでは小さくします。'),
    )
    layout_spacing_reference: EnumProperty(
        name='Spacing Reference',
        items=(
            ('EDGE_GUARDED', 'Left/Top Edge with Size Guard', 'Use major-dot distance between left/top edges, but expand automatically when node dimensions would overlap.'),
            ('BOUNDS_GAP', 'Gap Between Node Bounds', 'Use major-dot distance as the empty gap between node bounds, adding node width or height automatically.'),
        ),
        default='EDGE_GUARDED',
        description=_tip('Function: chooses whether major-dot counts mean left/top-edge distance or empty distance between node bounds. How to use: use Left/Top Edge with Size Guard for the requested parent-left to child-left style, or Gap Between Node Bounds when you want the visible empty space itself to equal the grid-dot count.', '機能: 太いグリッド点数を左端/上端どうしの距離として扱うか、ノード境界どうしの空き幅として扱うかを選びます。使い方: 親の左端から子の左端までの指定に近い動作は「左/上端 + サイズ保護」、見た目の空き幅自体をグリッド点数にしたい場合は「ノード境界間の隙間」を使います。'),
    )
    layout_snap_after_arrange: BoolProperty(
        name='Snap Result to Major Grid',
        default=True,
        description=_tip('Function: snaps arranged node top-left positions to the configured Major Grid Unit after Smart Node layout operations. How to use: enable this when you want every arranged node to land directly on major grid dots; disable it when keeping the original group center is more important.', '機能: Smart Node のレイアウト操作後、ノード左上位置を設定した太いグリッド単位へスナップします。使い方: 整列後の各ノードを太いグリッド点上へそろえたい場合は有効、元のグループ中心維持を優先する場合は無効にします。'),
    )



    # Migrated node-tool settings integrated into existing Smart Node sections.
    integrated_node_presets_search_path: StringProperty(
        name='Node Preset Folder',
        subtype='DIR_PATH',
        default='',
        description=_tip(
            'Function: stores the folder scanned by the migrated Node Presets tool for .blend files containing public node groups. How to use: set a folder from the Texture Setup section, then use the template buttons to add node-group presets to the active node tree.',
            '機能: ノードプリセットが公開ノードグループ入り .blend ファイルを検索するフォルダーを保存します。使い方: 「テクスチャ設定」内でフォルダーを指定し、テンプレートボタンから現在のノードツリーへノードグループプリセットを追加します。',
        ),
    )
    integrated_node_color_tools_pie_menu_hotkey: StringProperty(
        name='Precise Color Pie Key',
        default='Z',
        description=_tip(
            'Function: stores the recommended key name for the migrated precise node-color pie menu. How to use: use Blender Preferences > Keymap if you want to bind this key manually; Smart Node does not add extra automatic hotkeys.',
            '機能: 移植済みの詳細ノードカラーパイメニューに推奨するキー名を保存します。使い方: 実際に割り当てる場合は Blender の「プリファレンス > キーマップ」で手動設定します。Smart Node は追加ホットキーを自動登録しません。',
        ),
    )
    integrated_node_color_tools_pie_menu_hotkey_2: StringProperty(
        name='Quick Color Pie Key',
        default='D',
        description=_tip(
            'Function: stores the recommended key name for the migrated quick node-color pie menu. How to use: use it as a memo when manually assigning the quick pie command in Blender keymap settings.',
            '機能: 移植済みの簡易ノードカラーパイメニューに推奨するキー名を保存します。使い方: Blender のキーマップ設定で簡易パイコマンドを手動登録する際のメモとして使います。',
        ),
    )
    integrated_node_color_tools_ctrl: BoolProperty(name='Precise Pie Ctrl', default=False, description=_tip('Function: remembers whether Ctrl is part of the recommended precise node-color pie shortcut. How to use: enable this only when you manually assign the same modifier in Blender keymap settings.', '機能: 詳細ノードカラーパイの推奨ショートカットに Ctrl を含めるか記録します。使い方: Blender キーマップで同じ修飾キーを手動設定する場合のみ有効にします。'))
    integrated_node_color_tools_alt: BoolProperty(name='Precise Pie Alt', default=False, description=_tip('Function: remembers whether Alt is part of the recommended precise node-color pie shortcut. How to use: match this with your manually assigned Blender keymap entry.', '機能: 詳細ノードカラーパイの推奨ショートカットに Alt を含めるか記録します。使い方: 手動設定した Blender キーマップ項目と合わせます。'))
    integrated_node_color_tools_shift: BoolProperty(name='Precise Pie Shift', default=False, description=_tip('Function: remembers whether Shift is part of the recommended precise node-color pie shortcut. How to use: match this with your manually assigned Blender keymap entry.', '機能: 詳細ノードカラーパイの推奨ショートカットに Shift を含めるか記録します。使い方: 手動設定した Blender キーマップ項目と合わせます。'))
    integrated_node_color_tools_ctrl_2: BoolProperty(name='Quick Pie Ctrl', default=False, description=_tip('Function: remembers whether Ctrl is part of the recommended quick node-color pie shortcut. How to use: match this with your manually assigned Blender keymap entry.', '機能: 簡易ノードカラーパイの推奨ショートカットに Ctrl を含めるか記録します。使い方: 手動設定した Blender キーマップ項目と合わせます。'))
    integrated_node_color_tools_alt_2: BoolProperty(name='Quick Pie Alt', default=False, description=_tip('Function: remembers whether Alt is part of the recommended quick node-color pie shortcut. How to use: match this with your manually assigned Blender keymap entry.', '機能: 簡易ノードカラーパイの推奨ショートカットに Alt を含めるか記録します。使い方: 手動設定した Blender キーマップ項目と合わせます。'))
    integrated_node_color_tools_shift_2: BoolProperty(name='Quick Pie Shift', default=False, description=_tip('Function: remembers whether Shift is part of the recommended quick node-color pie shortcut. How to use: match this with your manually assigned Blender keymap entry.', '機能: 簡易ノードカラーパイの推奨ショートカットに Shift を含めるか記録します。使い方: 手動設定した Blender キーマップ項目と合わせます。'))

    show_hotkey_list: BoolProperty(
        name="Show Hotkey List",
        default=False,
        description=_tip('Function: expands the add-on preferences to show Smart Node Suite hotkeys. How to use: enable this when checking or searching assigned shortcuts.', '機能: アドオン設定内に Smart Node Suite のホットキー一覧を表示します。使い方: 割り当て済みショートカットを確認または検索したい時に有効にします。')
    )
    hotkey_list_filter: StringProperty(
        name="        Filter by Name",
        default="",
        description=_tip('Function: filters the hotkey list by command name. How to use: type part of a command name such as merge, link, or layout to narrow the list.', '機能: コマンド名でホットキー一覧を絞り込みます。使い方: merge、link、layout など、探したいコマンド名の一部を入力します。'),
        options={'TEXTEDIT_UPDATE'}
    )
    show_principled_lists: BoolProperty(
        name="Show Principled Naming Tags",
        default=False,
        description=_tip('Function: expands the list of texture-name tags used by Principled BSDF automatic setup. How to use: enable this when your texture filenames use studio-specific abbreviations.', '機能: Principled BSDF 自動設定で使うテクスチャ名タグ一覧を展開します。使い方: テクスチャファイル名にスタジオ独自の略語がある場合に有効にして編集します。')
    )
    principled_tags: bpy.props.PointerProperty(
        type=SNSPrincipledPreferences,
        description=_tip('Function: stores the editable texture-name tag groups used by the automatic Principled BSDF setup. How to use: expand the naming-tag section in preferences and adjust each tag list to match your studio filenames.', '機能: Principled BSDF 自動設定で使う編集可能なテクスチャ名タグ群を保存します。使い方: 設定内の命名タグ欄を展開し、スタジオのファイル名規則に合わせて各リストを調整します。'),
    )

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, "merge_position")
        col.prop(self, "merge_hide")


        box = layout.box()
        col = box.column(align=True)
        col.label(text=_t('Node Editor View Settings', 'ノードエディター表示設定'), icon='HIDE_OFF')
        col.prop(self, 'view_grid_color', text=_t('Grid Color', 'グリッドカラー'))
        col.prop(self, 'view_background_color', text=_t('Background Color', '背景色'))
        col.prop(self, 'view_grid_levels', text=_t('Grid Levels', 'グリッドレベル'))
        col.prop(self, 'view_show_advanced', text=_t('Advanced View Colors', '詳細表示カラー'))
        if self.view_show_advanced:
            col.prop(self, 'view_node_backdrop_color', text=_t('Node Backdrop Color', 'ノード背景色'))
            col.prop(self, 'view_wire_color', text=_t('Wire Color', 'ワイヤカラー'))
            col.prop(self, 'view_wire_select_color', text=_t('Selected Wire Color', '選択ワイヤカラー'))
            col.prop(self, 'view_selected_node_color', text=_t('Selected Node Color', '選択ノードカラー'))
            col.prop(self, 'view_active_node_color', text=_t('Active Node Color', 'アクティブノードカラー'))
            col.prop(self, 'view_noodle_curving', text=_t('Noodle Curving', 'リンク曲線'))
            col.prop(self, 'view_dash_alpha', text=_t('Dash Alpha', '破線アルファ'))

        box = layout.box()
        col = box.column(align=True)
        col.label(text=_t('Major Grid Layout Spacing', '太いグリッド基準のレイアウト間隔'), icon='MESH_GRID')
        col.prop(self, 'layout_use_major_grid_spacing', text=_t('Use Major Grid Spacing', '太いグリッド間隔を使用'))
        col.prop(self, 'layout_major_grid_unit', text=_t('Major Grid Unit', '太いグリッド単位'))
        col.prop(self, 'layout_column_major_steps', text=_t('Column Major Dots', '列の太い点数'))
        col.prop(self, 'layout_row_major_steps', text=_t('Row Major Dots', '行の太い点数'))
        col.prop(self, 'layout_min_gap_major_steps', text=_t('Minimum Bounds Gap Dots', '最小空き太点数'))
        col.prop(self, 'layout_spacing_reference', text=_t('Spacing Reference', '距離基準'))
        col.prop(self, 'layout_snap_after_arrange', text=_t('Snap Result to Major Grid', '結果を太いグリッドへスナップ'))

        box = layout.box()
        col = box.column(align=True)
        col.prop(
            self,
            "show_principled_lists",
            text=_t('Edit tags for auto texture detection in Principled BSDF setup'),
            toggle=True)
        if self.show_principled_lists:
            tags = self.principled_tags

            col.prop(tags, "base_color")
            col.prop(tags, "metallic")
            col.prop(tags, "specular")
            col.prop(tags, "rough")
            col.prop(tags, "gloss")
            col.prop(tags, "normal")
            col.prop(tags, "bump")
            col.prop(tags, "displacement")
            col.prop(tags, "transmission")
            col.prop(tags, "emission")
            col.prop(tags, "alpha")
            col.prop(tags, "ambient_occlusion")


        box = layout.box()
        col = box.column(align=True)
        col.label(text=_t('Migrated Node Tools', '移植済みノードツール'), icon='NODETREE')
        col.prop(self, 'integrated_node_presets_search_path', text=_t('Node Preset Folder', 'ノードプリセットフォルダー'))
        row = col.row(align=True)
        row.prop(self, 'integrated_node_color_tools_pie_menu_hotkey', text=_t('Precise Color Pie Key', '詳細カラーパイキー'))
        row.prop(self, 'integrated_node_color_tools_pie_menu_hotkey_2', text=_t('Quick Color Pie Key', '簡易カラーパイキー'))

        box = layout.box()
        col = box.column(align=True)
        hotkey_button_name = iface_("Hide Hotkey List") if self.show_hotkey_list else iface_("Show Hotkey List")
        col.prop(self, "show_hotkey_list", text=hotkey_button_name, translate=False, toggle=True)
        if self.show_hotkey_list:
            col.prop(self, "hotkey_list_filter", icon="VIEWZOOM")
            col.separator()
            for hotkey in kmi_defs:
                if hotkey[7]:
                    hotkey_name = hotkey[7]

                    if (self.hotkey_list_filter.lower() in hotkey_name.lower()
                            or self.hotkey_list_filter.lower() in iface_(hotkey_name).lower()):
                        row = col.row(align=True)
                        row.label(text=iface_(hotkey_name))
                        keystr = iface_(nice_hotkey_name(hotkey[1]), i18n_contexts.ui_events_keymaps)
                        if hotkey[4]:
                            keystr = iface_("Shift", i18n_contexts.ui_events_keymaps) + " " + keystr
                        if hotkey[5]:
                            keystr = iface_("Alt", i18n_contexts.ui_events_keymaps) + " " + keystr
                        if hotkey[3]:
                            keystr = iface_("Ctrl", i18n_contexts.ui_events_keymaps) + " " + keystr
                        row.label(text=keystr, translate=False)


#
#  REGISTER/UNREGISTER CLASSES AND KEYMAP ITEMS
#
addon_keymaps = []
# kmi_defs entry: (identifier, key, action, CTRL, SHIFT, ALT, props, nice name)
# props entry: (property name, property value)
kmi_defs = (
    # MERGE NODES
    # SNSMergeNodes with Ctrl (AUTO).
    ("smart_node_suite.merge_nodes", 'NUMPAD_0', 'PRESS', True, False, False,
        (('mode', 'MIX'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Automatic)")),
    ("smart_node_suite.merge_nodes", 'ZERO', 'PRESS', True, False, False,
        (('mode', 'MIX'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Automatic)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_PLUS', 'PRESS', True, False, False,
        (('mode', 'ADD'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Add)")),
    ("smart_node_suite.merge_nodes", 'EQUAL', 'PRESS', True, False, False,
        (('mode', 'ADD'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Add)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_ASTERIX', 'PRESS', True, False, False,
        (('mode', 'MULTIPLY'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Multiply)")),
    ("smart_node_suite.merge_nodes", 'EIGHT', 'PRESS', True, False, False,
        (('mode', 'MULTIPLY'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Multiply)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_MINUS', 'PRESS', True, False, False,
        (('mode', 'SUBTRACT'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Subtract)")),
    ("smart_node_suite.merge_nodes", 'MINUS', 'PRESS', True, False, False,
        (('mode', 'SUBTRACT'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Subtract)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_SLASH', 'PRESS', True, False, False,
        (('mode', 'DIVIDE'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Divide)")),
    ("smart_node_suite.merge_nodes", 'SLASH', 'PRESS', True, False, False,
        (('mode', 'DIVIDE'), ('merge_type', 'AUTO'),), n_("Merge Nodes (Divide)")),
    ("smart_node_suite.merge_nodes", 'COMMA', 'PRESS', True, False, False,
        (('mode', 'LESS_THAN'), ('merge_type', 'MATH'),), n_("Merge Nodes (Less Than)")),
    ("smart_node_suite.merge_nodes", 'PERIOD', 'PRESS', True, False, False,
        (('mode', 'GREATER_THAN'), ('merge_type', 'MATH'),), n_("Merge Nodes (Greater Than)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_PERIOD', 'PRESS', True, False, False,
        (('mode', 'MIX'), ('merge_type', 'DEPTH_COMBINE'),), n_("Merge Nodes (Depth Combine)")),
    # SNSMergeNodes with Ctrl Alt (MIX or ALPHAOVER)
    ("smart_node_suite.merge_nodes", 'NUMPAD_0', 'PRESS', True, False, True,
        (('mode', 'MIX'), ('merge_type', 'ALPHAOVER'),), n_("Merge Nodes (Alpha Over)")),
    ("smart_node_suite.merge_nodes", 'ZERO', 'PRESS', True, False, True,
        (('mode', 'MIX'), ('merge_type', 'ALPHAOVER'),), n_("Merge Nodes (Alpha Over)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_PLUS', 'PRESS', True, False, True,
        (('mode', 'ADD'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Add)")),
    ("smart_node_suite.merge_nodes", 'EQUAL', 'PRESS', True, False, True,
        (('mode', 'ADD'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Add)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_ASTERIX', 'PRESS', True, False, True,
        (('mode', 'MULTIPLY'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Multiply)")),
    ("smart_node_suite.merge_nodes", 'EIGHT', 'PRESS', True, False, True,
        (('mode', 'MULTIPLY'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Multiply)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_MINUS', 'PRESS', True, False, True,
        (('mode', 'SUBTRACT'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Subtract)")),
    ("smart_node_suite.merge_nodes", 'MINUS', 'PRESS', True, False, True,
        (('mode', 'SUBTRACT'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Subtract)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_SLASH', 'PRESS', True, False, True,
        (('mode', 'DIVIDE'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Divide)")),
    ("smart_node_suite.merge_nodes", 'SLASH', 'PRESS', True, False, True,
        (('mode', 'DIVIDE'), ('merge_type', 'MIX'),), n_("Merge Nodes (Color, Divide)")),
    # SNSMergeNodes with Ctrl Shift (MATH)
    ("smart_node_suite.merge_nodes", 'NUMPAD_PLUS', 'PRESS', True, True, False,
        (('mode', 'ADD'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Add)")),
    ("smart_node_suite.merge_nodes", 'EQUAL', 'PRESS', True, True, False,
        (('mode', 'ADD'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Add)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_ASTERIX', 'PRESS', True, True, False,
        (('mode', 'MULTIPLY'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Multiply)")),
    ("smart_node_suite.merge_nodes", 'EIGHT', 'PRESS', True, True, False,
        (('mode', 'MULTIPLY'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Multiply)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_MINUS', 'PRESS', True, True, False,
        (('mode', 'SUBTRACT'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Subtract)")),
    ("smart_node_suite.merge_nodes", 'MINUS', 'PRESS', True, True, False,
        (('mode', 'SUBTRACT'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Subtract)")),
    ("smart_node_suite.merge_nodes", 'NUMPAD_SLASH', 'PRESS', True, True, False,
        (('mode', 'DIVIDE'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Divide)")),
    ("smart_node_suite.merge_nodes", 'SLASH', 'PRESS', True, True, False,
        (('mode', 'DIVIDE'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Divide)")),
    ("smart_node_suite.merge_nodes", 'COMMA', 'PRESS', True, True, False,
        (('mode', 'LESS_THAN'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Less than)")),
    ("smart_node_suite.merge_nodes", 'PERIOD', 'PRESS', True, True, False,
        (('mode', 'GREATER_THAN'), ('merge_type', 'MATH'),), n_("Merge Nodes (Math, Greater than)")),
    # BATCH CHANGE NODES
    # SNSBatchChangeNodes with Alt
    ("smart_node_suite.batch_change", 'NUMPAD_0', 'PRESS', False, False, True,
        (('blend_type', 'MIX'), ('operation', 'CURRENT'),), n_("Batch Change Blend Type (Mix)")),
    ("smart_node_suite.batch_change", 'ZERO', 'PRESS', False, False, True,
        (('blend_type', 'MIX'), ('operation', 'CURRENT'),), n_("Batch Change Blend Type (Mix)")),
    ("smart_node_suite.batch_change", 'NUMPAD_PLUS', 'PRESS', False, False, True,
        (('blend_type', 'ADD'), ('operation', 'ADD'),), n_("Batch Change Blend Type (Add)")),
    ("smart_node_suite.batch_change", 'EQUAL', 'PRESS', False, False, True,
        (('blend_type', 'ADD'), ('operation', 'ADD'),), n_("Batch Change Blend Type (Add)")),
    ("smart_node_suite.batch_change", 'NUMPAD_ASTERIX', 'PRESS', False, False, True,
        (('blend_type', 'MULTIPLY'), ('operation', 'MULTIPLY'),), n_("Batch Change Blend Type (Multiply)")),
    ("smart_node_suite.batch_change", 'EIGHT', 'PRESS', False, False, True,
        (('blend_type', 'MULTIPLY'), ('operation', 'MULTIPLY'),), n_("Batch Change Blend Type (Multiply)")),
    ("smart_node_suite.batch_change", 'NUMPAD_MINUS', 'PRESS', False, False, True,
        (('blend_type', 'SUBTRACT'), ('operation', 'SUBTRACT'),), n_("Batch Change Blend Type (Subtract)")),
    ("smart_node_suite.batch_change", 'MINUS', 'PRESS', False, False, True,
        (('blend_type', 'SUBTRACT'), ('operation', 'SUBTRACT'),), n_("Batch Change Blend Type (Subtract)")),
    ("smart_node_suite.batch_change", 'NUMPAD_SLASH', 'PRESS', False, False, True,
        (('blend_type', 'DIVIDE'), ('operation', 'DIVIDE'),), n_("Batch Change Blend Type (Divide)")),
    ("smart_node_suite.batch_change", 'SLASH', 'PRESS', False, False, True,
        (('blend_type', 'DIVIDE'), ('operation', 'DIVIDE'),), n_("Batch Change Blend Type (Divide)")),
    ("smart_node_suite.batch_change", 'COMMA', 'PRESS', False, False, True,
        (('blend_type', 'CURRENT'), ('operation', 'LESS_THAN'),), n_("Batch Change Blend Type (Current)")),
    ("smart_node_suite.batch_change", 'PERIOD', 'PRESS', False, False, True,
        (('blend_type', 'CURRENT'), ('operation', 'GREATER_THAN'),), n_("Batch Change Blend Type (Current)")),
    ("smart_node_suite.batch_change", 'DOWN_ARROW', 'PRESS', False, False, True,
        (('blend_type', 'NEXT'), ('operation', 'NEXT'),), n_("Batch Change Blend Type (Next)")),
    ("smart_node_suite.batch_change", 'UP_ARROW', 'PRESS', False, False, True,
        (('blend_type', 'PREV'), ('operation', 'PREV'),), n_("Batch Change Blend Type (Previous)")),
    # LINK ACTIVE TO SELECTED
    # Don't use names, don't replace links (K)
    ("smart_node_suite.link_active_to_selected", 'K', 'PRESS', False, False, False,
        (('replace', False), ('use_node_name', False), ('use_outputs_names', False),),
        n_("Link Active to Selected (Don't Replace Links)")),
    # Don't use names, replace links (Shift K)
    ("smart_node_suite.link_active_to_selected", 'K', 'PRESS', False, True, False,
        (('replace', True), ('use_node_name', False), ('use_outputs_names', False),),
        n_("Link Active to Selected (Replace Links)")),
    # Use node name, don't replace links (')
    ("smart_node_suite.link_active_to_selected", 'QUOTE', 'PRESS', False, False, False,
        (('replace', False), ('use_node_name', True), ('use_outputs_names', False),),
        n_("Link Active to Selected (Don't Replace Links, Node Names)")),
    # Use node name, replace links (Shift ')
    ("smart_node_suite.link_active_to_selected", 'QUOTE', 'PRESS', False, True, False,
        (('replace', True), ('use_node_name', True), ('use_outputs_names', False),),
        n_("Link Active to Selected (Replace Links, Node Names)")),
    # Don't use names, don't replace links (;)
    ("smart_node_suite.link_active_to_selected", 'SEMI_COLON', 'PRESS', False, False, False,
        (('replace', False), ('use_node_name', False), ('use_outputs_names', True),),
        n_("Link Active to Selected (Don't Replace Links, Output Names)")),
    # Don't use names, replace links (')
    ("smart_node_suite.link_active_to_selected", 'SEMI_COLON', 'PRESS', False, True, False,
        (('replace', True), ('use_node_name', False), ('use_outputs_names', True),),
        n_("Link Active to Selected (Replace Links, Output Names)")),
    # CHANGE MIX FACTOR
    ("smart_node_suite.factor", 'LEFT_ARROW', 'PRESS', False,
     False, True, (('option', -0.1),), n_("Reduce Mix Factor by 0.1")),
    ("smart_node_suite.factor", 'RIGHT_ARROW', 'PRESS', False,
     False, True, (('option', 0.1),), n_("Increase Mix Factor by 0.1")),
    ("smart_node_suite.factor", 'LEFT_ARROW', 'PRESS', False,
     True, True, (('option', -0.01),), n_("Reduce Mix Factor by 0.01")),
    ("smart_node_suite.factor", 'RIGHT_ARROW', 'PRESS', False,
     True, True, (('option', 0.01),), n_("Increase Mix Factor by 0.01")),
    ("smart_node_suite.factor", 'LEFT_ARROW', 'PRESS',
     True, True, True, (('option', 0.0),), n_("Set Mix Factor to 0.0")),
    ("smart_node_suite.factor", 'RIGHT_ARROW', 'PRESS',
     True, True, True, (('option', 1.0),), n_("Set Mix Factor to 1.0")),
    ("smart_node_suite.factor", 'NUMPAD_0', 'PRESS',
     True, True, True, (('option', 0.0),), n_("Set Mix Factor to 0.0")),
    ("smart_node_suite.factor", 'ZERO', 'PRESS', True, True, True, (('option', 0.0),), n_("Set Mix Factor to 0.0")),
    ("smart_node_suite.factor", 'NUMPAD_1', 'PRESS', True, True, True, (('option', 1.0),), n_("Mix Factor to 1.0")),
    ("smart_node_suite.factor", 'ONE', 'PRESS', True, True, True, (('option', 1.0),), n_("Set Mix Factor to 1.0")),
    # CLEAR LABEL (Alt L)
    ("smart_node_suite.clear_label", 'L', 'PRESS', False, False, True, (('option', False),), n_("Clear Node Labels")),
    # MODIFY LABEL (Alt Shift L)
    ("smart_node_suite.modify_labels", 'L', 'PRESS', False, True, True, None, n_("Modify Node Labels")),
    # Copy Label from active to selected
    ("smart_node_suite.copy_label", 'V', 'PRESS', False, True, False,
     (('option', 'FROM_ACTIVE'),), n_("Copy label from active to selected")),
    # DETACH OUTPUTS (Alt Shift D)
    ("smart_node_suite.detach_outputs", 'D', 'PRESS', False, True, True, None, n_("Detach Outputs")),
    # LINK TO OUTPUT NODE (O)
    ("smart_node_suite.link_out", 'O', 'PRESS', False, False, False, None, n_("Link to Output Node")),
    # SELECT PARENT/CHILDREN
    # Select Children
    ("smart_node_suite.select_parent_child", 'RIGHT_BRACKET', 'PRESS',
     False, False, False, (('option', 'CHILD'),), n_("Select Children")),
    # Select Parent
    ("smart_node_suite.select_parent_child", 'LEFT_BRACKET', 'PRESS',
     False, False, False, (('option', 'PARENT'),), n_("Select Parent")),
    # Add Texture Setup
    ("smart_node_suite.add_texture", 'T', 'PRESS', True, False, False, None, n_("Add Texture Setup")),
    # Add Principled BSDF Texture Setup
    ("smart_node_suite.add_textures_for_principled", 'T', 'PRESS', True, True, False, None, n_("Add Principled Texture Setup")),
    # Reset backdrop
    ("smart_node_suite.bg_reset", 'Z', 'PRESS', False, False, False, None, n_("Reset Backdrop Image Zoom")),
    # Delete unused
    ("smart_node_suite.del_unused", 'X', 'PRESS', False, False, True, None, n_("Delete Unused Nodes")),
    # Frame Selected
    ('node.join', 'P', 'PRESS', False, True, False, None, n_("Frame Selected Nodes")),
    # Swap Links
    ("smart_node_suite.swap_links", 'S', 'PRESS', False, False, True, None, n_("Swap Links")),
    # Reload Images
    ("smart_node_suite.reload_images", 'R', 'PRESS', False, False, True, None, n_("Reload Images")),
    # Lazy Mix
    ("smart_node_suite.lazy_mix", 'RIGHTMOUSE', 'PRESS', True, True, False, None, n_("Lazy Mix")),
    # Lazy Connect
    ("smart_node_suite.lazy_connect", 'RIGHTMOUSE', 'PRESS', False, False, True, (('with_menu', False),), n_("Lazy Connect")),
    # Lazy Connect with Menu
    ("smart_node_suite.lazy_connect", 'RIGHTMOUSE', 'PRESS', False,
     True, True, (('with_menu', True),), n_("Lazy Connect with Socket Menu")),
    # Align Nodes
    ("smart_node_suite.align_nodes", 'EQUAL', 'PRESS', False, True,
     False, None, n_("Align Nodes")),
    # Reset Nodes (Back Space)
    ("smart_node_suite.reset_nodes", 'BACK_SPACE', 'PRESS', False, False,
     False, None, n_("Reset Nodes")),
    # MENUS
    ('wm.call_menu', 'W', 'PRESS', False, True, False,
     (('name', interface.SmartNodeSuiteMenu.bl_idname),), n_("Smart Node Suite (Menu)")),
    ('wm.call_menu', 'SLASH', 'PRESS', False, False, False,
     (('name', interface.SNSAddReroutesMenu.bl_idname),), n_("Add Reroutes (Menu)")),
    ('wm.call_menu', 'NUMPAD_SLASH', 'PRESS', False, False, False,
     (('name', interface.SNSAddReroutesMenu.bl_idname),), n_("Add Reroutes (Menu)")),
    ('wm.call_menu', 'BACK_SLASH', 'PRESS', False, False, False,
     (('name', interface.SNSLinkActiveToSelectedMenu.bl_idname),), n_("Link Active to Selected (Menu)")),
    ('wm.call_menu', 'C', 'PRESS', False, True, False,
     (('name', interface.SNSCopyToSelectedMenu.bl_idname),), n_("Copy to Selected (Menu)")),
)

def _sns_make_persisting_update(existing_update):
    def _update(self, context):
        if callable(existing_update):
            try:
                existing_update(self, context)
            except Exception:
                pass
        try:
            from . import persistent_settings
            persistent_settings.request_save(context, force=False)
        except Exception:
            pass
    return _update


def _sns_install_persistence_updates(*owner_classes) -> None:
    for owner_cls in owner_classes:
        annotations = getattr(owner_cls, '__annotations__', None)
        if not isinstance(annotations, dict):
            continue
        for name, prop_def in list(annotations.items()):
            factory = getattr(prop_def, 'function', None)
            keywords = getattr(prop_def, 'keywords', None)
            if not callable(factory) or not isinstance(keywords, dict):
                continue
            if str(getattr(factory, '__name__', '') or '') == 'CollectionProperty':
                continue
            updated = dict(keywords)
            updated['update'] = _sns_make_persisting_update(updated.get('update'))
            try:
                annotations[name] = factory(**updated)
            except Exception:
                pass


_sns_install_persistence_updates(SNSPrincipledPreferences, SNSSmartNodeSuite)


classes = (
    SNSPrincipledPreferences, SNSSmartNodeSuite
)


_registered_class_tokens = []


def register():
    if _registered_class_tokens:
        return
    # Smart Node Suite never alters the user's keymap automatically.
    addon_keymaps.clear()
    _registered_class_tokens.extend(rna_ownership.register_classes(classes))


def unregister():
    # Compatibility cleanup is restricted to exact objects captured in this
    # module's own legacy list; current versions never append automatic items.
    for km, kmi in tuple(addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()
    rna_ownership.unregister_classes(_registered_class_tokens)
