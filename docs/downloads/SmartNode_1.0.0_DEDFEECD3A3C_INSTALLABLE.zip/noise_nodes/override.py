"""Non-invasive Node Wrangler compatibility surface.

Smart Node Suite never replaces, wraps, imports for patching, or otherwise
mutates Node Wrangler internals.  The compatibility setting and these public
functions remain for saved-setting/API compatibility; callers can query the
exact Smart Node noise types without installing a persistent hook.
"""

from __future__ import annotations

_NOISE_TEXTURE_TYPES = (
    'ShaderNodeCrackleNoiseNode',
    'ShaderNodeCranalNoiseNode',
    'ShaderNodeDentNoiseNode',
    'ShaderNodeDotNoiseNode',
    'ShaderNodeFluidNoiseNode',
    'ShaderNodeFractalNoiseNode',
    'ShaderNodePerlinNoiseNode',
    'ShaderNodePixelatorNode',
    'ShaderNodeRegularNoiseNode',
    'ShaderNodeScratchesNoiseNode',
    'ShaderNodeStepNoiseNode',
    'ShaderNodeStreaksNoiseNode',
    'ShaderNodeVoxelNoiseNode',
    'ShaderNodeWavyNoiseNode',
)


def noise_texture_node_types() -> tuple[str, ...]:
    """Return immutable Smart Node texture-node identifiers."""

    return _NOISE_TEXTURE_TYPES


def enable_override_node_wrangler() -> bool:
    """Compatibility no-op; no third-party callable is patched."""

    return False


def disable_override_node_wrangler() -> None:
    """Compatibility no-op; this module owns no external mutation."""

    return None
