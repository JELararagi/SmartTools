# Noise Nodes Source Evidence

The compared upstream Noise Nodes project identifies its author/maintainer as
haseebahmad295. Its source repository is:
https://github.com/haseebahmed295/Noise-Nodes

Comparison revision: b1285e257c527fe85433141c018f67e2943ff379
The manifest at that revision declares version 0.7.0 and
SPDX:GPL-3.0-or-later. The compared repository tree has no standalone
LICENSE, LICENCE or COPYING file. This notice does not claim to restore
an original license file absent from that tree.

The bounded comparison against the SmartNode 1.4.31 baseline established:
- noise_nodes/translations.py is byte-identical to the compared source.
- noise_nodes/na.py contains one exactly matching nontrivial function AST.
- noise_nodes/nodes/utils.py contains five exactly matching nontrivial function ASTs.
- All 33 bundled Python files have candidate path mappings, but mapping paths
  alone does not establish derivation. The other files' origins remain unconfirmed.

Exact function comparison includes identifiers and docstrings, excludes source
positions, and requires at least 30 AST nodes. The original acquired archive
and its exact version have not been established. The manifest version above
is a comparison-source version, not a verified bundled-version claim.

The upstream listing credits inspiration from Simon Thommes' Procedural Noise
Pack. That statement does not establish code copying or a separate permission.

This documentation stage does not change the existing implementation or
source headers. It records source evidence and does not establish complete
attribution, license compliance, source-offer compliance or sales clearance.
