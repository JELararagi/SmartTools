"""Deterministic Noise Nodes registry.

No directory iteration or package-wide module scan is used.  Exact module and
class names are part of the extension surface and are imported only by the
Noise Nodes registration or an explicit conversion operator.
"""

from __future__ import annotations

import importlib
from typing import List, Tuple, Type

_GEOMETRY_REGISTRY = (
    ('crackle_node', 'GeometryNodeCrackleNoiseNode'),
    ('cranal_node', 'GeometryNodeCranalNoiseNode'),
    ('dent_node', 'GeometryNodeDentNoiseNode'),
    ('dots_node', 'GeometryNodeDotNoiseNode'),
    ('fluid_node', 'GeometryNodeFluidNoiseNode'),
    ('fractal_node', 'GeometryNodeFractalNoiseNode'),
    ('perlin_node', 'GeometryNodePerlinNoiseNode'),
    ('pixelator_node', 'GeometryNodePixelatorNode'),
    ('regular_node', 'GeometryNodeRegularNoiseNode'),
    ('scratches_node', 'GeometryNodeScratchesNoiseNode'),
    ('step_node', 'GeometryNodeStepNoiseNode'),
    ('streaks_node', 'GeometryNodeStreaksNoiseNode'),
)
_SHADER_REGISTRY = (
    ('crackle_node', 'ShaderNodeCrackleNoiseNode'),
    ('cranal_node', 'ShaderNodeCranalNoiseNode'),
    ('dent_node', 'ShaderNodeDentNoiseNode'),
    ('dots_node', 'ShaderNodeDotNoiseNode'),
    ('fluid_node', 'ShaderNodeFluidNoiseNode'),
    ('fractal_node', 'ShaderNodeFractalNoiseNode'),
    ('perlin_node', 'ShaderNodePerlinNoiseNode'),
    ('pixelator_node', 'ShaderNodePixelatorNode'),
    ('regular_node', 'ShaderNodeRegularNoiseNode'),
    ('scratches_node', 'ShaderNodeScratchesNoiseNode'),
    ('step_node', 'ShaderNodeStepNoiseNode'),
    ('streaks_node', 'ShaderNodeStreaksNoiseNode'),
    ('voxel_node', 'ShaderNodeVoxelNoiseNode'),
    ('wavy_node', 'ShaderNodeWavyNoiseNode'),
)


class NodeLib:
    _cached_geometry: tuple[Type, ...] = ()
    _cached_shader: tuple[Type, ...] = ()

    @classmethod
    def _load_registry(cls, subpackage: str, registry) -> list[Type]:
        package = str(__package__ or '')
        classes: list[Type] = []
        for module_stem, class_name in registry:
            module_name = f'{package}.nodes.{subpackage}.{module_stem}'
            module = importlib.import_module(module_name)
            node_class = getattr(module, class_name, None)
            if not isinstance(node_class, type):
                raise ImportError(f'{module_name}.{class_name} is missing')
            classes.append(node_class)
        return classes

    @classmethod
    def get_node_sets(cls, *, force_reload: bool = False) -> Tuple[List[Type], List[Type]]:
        # ``force_reload`` is retained for API compatibility.  Reloading a module
        # that owns registered RNA classes would create shadow class identities,
        # so the deterministic registry always reuses the imported exact module.
        _ = force_reload
        if not cls._cached_geometry or not cls._cached_shader:
            geometry = cls._load_registry('geometry', _GEOMETRY_REGISTRY)
            shader = cls._load_registry('core', _SHADER_REGISTRY)
            cls._cached_geometry = tuple(geometry)
            cls._cached_shader = tuple(shader)
        return list(cls._cached_geometry), list(cls._cached_shader)

    @classmethod
    def clear_cache(cls) -> None:
        cls._cached_geometry = ()
        cls._cached_shader = ()

    def __call__(self):
        return self.get_node_sets()
