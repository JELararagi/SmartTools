import bpy
from ..translation import loc_text as _lt, _STATIC_EN_JA, _STATIC_JA_EN
from .node_imp import NodeLib
from .. import rna_ownership
from ..utils.node_transactions import restore_tree_links, snapshot_tree_links


_NODE_INFO_CLASS_TOKEN = None
_NODE_INFO_PROPERTY_TOKENS = []

def _socket_name_variants(name):
    aliases = []
    for item in (name, _lt(name), _STATIC_EN_JA.get(str(name)), _STATIC_JA_EN.get(str(name))):
        if item and item not in aliases:
            aliases.append(item)
    return aliases


def _socket_get(sockets, name):
    for item in _socket_name_variants(name):
        socket = sockets.get(item)
        if socket is not None:
            return socket
    return None


class Node_Info(bpy.types.PropertyGroup):
    is_noise_node: bpy.props.BoolProperty(description=_lt('JP: このグループがノイズノード由来かどうかを示す内部フラグです。旧リンクデータの変換・同期判定に使用します。\nEN: Internal flag indicating whether this group comes from Noise Nodes. Used for conversion and synchronization of older linked data.'), default=False)
    bl_idname: bpy.props.StringProperty(description=_lt('JP: 元ノイズノードの識別子です。再リンクや変換時に対応するノード種類を判定するために使用します。\nEN: Identifier of the original noise node. Used to determine the corresponding node type during relinking or conversion.'))
    dimension: bpy.props.StringProperty(description=_lt('JP: 元ノイズノードの次元情報です。シェーダー / ジオメトリ向けの互換変換で使用します。\nEN: Dimension information for the original noise node. Used by compatibility conversion for Shader or Geometry nodes.'))
    ng_name: bpy.props.StringProperty(description=_lt('JP: 対応するノードグループ名です。既存グループを探して再利用するために使用します。\nEN: Corresponding node group name. Used to locate and reuse existing groups.'))


def _ensure_node_info_registered():
    global _NODE_INFO_CLASS_TOKEN
    owners = (
        getattr(bpy.types, 'ShaderNodeGroup', None),
        getattr(bpy.types, 'GeometryNodeGroup', None),
    )
    if any(owner is None for owner in owners):
        return False
    if (
        _NODE_INFO_CLASS_TOKEN is not None
        and len(_NODE_INFO_PROPERTY_TOKENS) == len(owners)
        and all(rna_ownership.token_matches(token) for token in _NODE_INFO_PROPERTY_TOKENS)
    ):
        return True

    acquired = []
    class_token = None
    try:
        # Remove only legacy pointer properties whose current fixed type is the
        # exact prior Smart Node Node_Info class.  Foreign properties are left
        # untouched and will result in a safe compatibility/restart decision.
        for owner in owners:
            rna_ownership.release_legacy_pointer_property(owner, 'Node_Info', Node_Info)
        class_token = rna_ownership.register_class(Node_Info)
        descriptions = (
            _lt('JP: シェーダーノードグループに保持するノイズノードの互換情報です。変換・同期処理で使用します。\nEN: Noise Nodes compatibility information stored on Shader node groups. Used by conversion and synchronization.'),
            _lt('JP: ジオメトリノードグループに保持するノイズノードの互換情報です。変換・同期処理で使用します。\nEN: Noise Nodes compatibility information stored on Geometry node groups. Used by conversion and synchronization.'),
        )
        for owner, description in zip(owners, descriptions):
            acquired.append(rna_ownership.install_property(
                owner,
                'Node_Info',
                bpy.props.PointerProperty(type=Node_Info, description=description),
            ))
    except Exception:
        for token in reversed(acquired):
            try:
                rna_ownership.remove_property(token)
            except Exception:
                pass
        if class_token is not None:
            try:
                rna_ownership.remove_class(class_token)
            except Exception:
                pass
        return False

    _NODE_INFO_PROPERTY_TOKENS.extend(acquired)
    _NODE_INFO_CLASS_TOKEN = class_token
    return True


def _noise_node_ids():
    try:
        geometrynodes, shadernodes = NodeLib.get_node_sets()
    except Exception:
        return set(), set(), set()
    geometry_ids = {str(getattr(node, '__name__', '') or '') for node in geometrynodes}
    shader_ids = {str(getattr(node, '__name__', '') or '') for node in shadernodes}
    return geometry_ids, shader_ids, geometry_ids | shader_ids


def _iter_node_trees():
    seen = set()

    def _yield(node_tree):
        if node_tree is None:
            return None
        try:
            ptr = node_tree.as_pointer()
        except Exception:
            ptr = id(node_tree)
        if ptr in seen:
            return None
        seen.add(ptr)
        return node_tree

    try:
        for material in bpy.data.materials:
            node_tree = _yield(getattr(material, 'node_tree', None))
            if node_tree is not None:
                yield node_tree
    except Exception:
        pass
    try:
        for scene in bpy.data.scenes:
            node_tree = _yield(getattr(scene, 'node_tree', None))
            if node_tree is not None:
                yield node_tree
    except Exception:
        pass
    try:
        for obj in bpy.data.objects:
            for mod in getattr(obj, 'modifiers', []):
                if getattr(mod, 'type', '') == 'NODES':
                    node_tree = _yield(getattr(mod, 'node_group', None))
                    if node_tree is not None:
                        yield node_tree
    except Exception:
        pass
    try:
        for node_group in bpy.data.node_groups:
            node_tree = _yield(node_group)
            if node_tree is not None:
                yield node_tree
    except Exception:
        pass


def _node_has_links(node):
    try:
        for socket in tuple(getattr(node, 'inputs', ())) + tuple(getattr(node, 'outputs', ())):
            if getattr(socket, 'is_linked', False):
                return True
    except Exception:
        pass
    return False


def _node_info_is_noise(node):
    try:
        return bool(hasattr(node, 'Node_Info') and node.Node_Info.is_noise_node)
    except Exception:
        return False


def _node_tree_ptr(node_tree):
    if node_tree is None:
        return None
    try:
        return node_tree.as_pointer()
    except Exception:
        return id(node_tree)


def _referenced_node_group_ptrs():
    refs = set()
    for node_tree in _iter_node_trees():
        try:
            for node in list(getattr(node_tree, 'nodes', ())):
                target = getattr(node, 'node_tree', None)
                if target is not None:
                    ptr = _node_tree_ptr(target)
                    if ptr is not None:
                        refs.add(ptr)
        except Exception:
            pass
    try:
        for obj in bpy.data.objects:
            for mod in getattr(obj, 'modifiers', []):
                if getattr(mod, 'type', '') == 'NODES':
                    target = getattr(mod, 'node_group', None)
                    ptr = _node_tree_ptr(target)
                    if ptr is not None:
                        refs.add(ptr)
    except Exception:
        pass
    return refs


def _remove_node_group_if_unreferenced(node_group):
    """Compatibility no-op: unreferenced status alone is never ownership."""

    del node_group
    return False


def _is_marked_runtime_proxy(node_group):
    """Return False; old marker-only ownership is intentionally not trusted."""

    del node_group
    return False


def cleanup_stale_proxy_data(*_args):
    """Compatibility no-op; no name/link/user-count cleanup is performed."""

    return 0


def register_proxy_cleanup():
    """Compatibility no-op; no startup or operator-time cleanup scan is installed."""
    return None


def unregister_proxy_cleanup():
    """Compatibility no-op: proxy cleanup owns no persistent resource."""
    return None

def _selection_state(node_tree):
    selected = {}
    try:
        for node in tuple(node_tree.nodes):
            selected[str(node.name)] = bool(node.select)
    except Exception:
        pass
    try:
        active = str(getattr(getattr(node_tree.nodes, 'active', None), 'name', '') or '')
    except Exception:
        active = ''
    return selected, active


def _restore_selection_state(node_tree, state) -> None:
    selected, active_name = state
    try:
        for node in tuple(node_tree.nodes):
            node.select = bool(selected.get(str(node.name), False))
        node_tree.nodes.active = node_tree.nodes.get(active_name) if active_name else None
    except Exception:
        pass


def _rollback_replacement(node_tree, created_node, links_before, selection_before) -> None:
    if created_node is not None:
        try:
            node_tree.nodes.remove(created_node)
        except Exception:
            pass
    restore_tree_links(node_tree, links_before)
    _restore_selection_state(node_tree, selection_before)


def _copy_socket_value(source, target) -> None:
    try:
        target.default_value = source.default_value
    except Exception:
        try:
            values = tuple(source.default_value)
            for index, value in enumerate(values):
                target.default_value[index] = value
        except Exception:
            pass


def check_mat_nodes(mat):
    '''Blender 5.0 will remove use_nodes'''
    return (hasattr(mat, "use_nodes") and mat.use_nodes) and mat.node_tree and mat.node_tree.nodes

def convert_to_nodegroup(*_args):
    _ensure_node_info_registered()
    cleanup_stale_proxy_data()
    from .. import transform_guard as _sss_transform_guard
    failures = []
    converted = 0
    with _sss_transform_guard.preserve_object_transforms('noise nodes explicit group conversion'):
        geometrynodes, shadernodes = NodeLib.get_node_sets()
        shader_ids = [node.__name__ for node in shadernodes]
        geometry_ids = [node.__name__ for node in geometrynodes]
        visited = set()
        for mat in tuple(bpy.data.materials):
            if check_mat_nodes(mat):
                count, errors = search_noise_nodes(mat.node_tree, shader_ids, visited=visited)
                converted += count
                failures.extend(errors)
        for obj in tuple(bpy.data.objects):
            for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
                if getattr(mod, 'type', '') == 'NODES' and getattr(mod, 'node_group', None):
                    count, errors = search_noise_nodes(mod.node_group, geometry_ids, visited=visited)
                    converted += count
                    failures.extend(errors)
    cleanup_stale_proxy_data()
    return {'converted': converted, 'failures': tuple(failures)}


def search_noise_nodes(node_tree, node_list, *, visited=None):
    visited = visited if visited is not None else set()
    pointer = _node_tree_ptr(node_tree)
    if pointer in visited:
        return 0, []
    visited.add(pointer)
    converted = 0
    failures = []
    for node in list(getattr(node_tree, 'nodes', ()) or ()):
        try:
            if getattr(node, 'type', '') == 'GROUP' and getattr(node, 'node_tree', None):
                count, errors = search_noise_nodes(node.node_tree, node_list, visited=visited)
                converted += count
                failures.extend(errors)
            if getattr(node, 'bl_idname', '') in node_list:
                process_node(node_tree, node)
                converted += 1
        except Exception as exc:
            failures.append(f'{getattr(node_tree, "name", "NodeTree")}::{getattr(node, "name", "Node")}: {exc}')
    return converted, failures


def search_noise_group(node_tree, nds: list, type: str = 'SHADER', *, visited=None, failures=None):
    visited = visited if visited is not None else set()
    failures = failures if failures is not None else []
    pointer = _node_tree_ptr(node_tree)
    if pointer in visited:
        return failures
    visited.add(pointer)
    if not getattr(node_tree, 'nodes', None):
        return failures
    for node in list(node_tree.nodes):
        try:
            if getattr(node, 'type', '') != 'GROUP':
                continue
            child_tree = getattr(node, 'node_tree', None)
            if child_tree is None or not getattr(child_tree, 'nodes', None):
                continue
            if hasattr(node, 'Node_Info') and node.Node_Info.is_noise_node:
                item = process_node_group(node_tree, node)
                if item is not None:
                    nds.append(item)
            else:
                search_noise_group(child_tree, nds, type, visited=visited, failures=failures)
        except Exception as exc:
            failures.append(f'{getattr(node_tree, "name", "NodeTree")}::{getattr(node, "name", "Node")}: {exc}')
    return failures


def convert_to_node(*_args):
    _ensure_node_info_registered()
    cleanup_stale_proxy_data()
    from .. import transform_guard as _sss_transform_guard
    nds = []
    failures = []
    visited = set()
    with _sss_transform_guard.preserve_object_transforms('noise nodes explicit runtime conversion'):
        for mat in tuple(bpy.data.materials):
            if check_mat_nodes(mat):
                search_noise_group(mat.node_tree, nds, visited=visited, failures=failures)
        for obj in tuple(bpy.data.objects):
            for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
                if getattr(mod, 'type', '') == 'NODES' and getattr(mod, 'node_group', None):
                    search_noise_group(mod.node_group, nds, 'GEOMETRY', visited=visited, failures=failures)

        cleanup_groups = []
        for item in nds:
            try:
                if len(item) >= 3 and item[2] is not None and item[2] not in cleanup_groups:
                    cleanup_groups.append(item[2])
            except Exception:
                pass
        for node_group in cleanup_groups:
            _remove_node_group_if_unreferenced(node_group)
        for item in nds:
            try:
                item[0].name = item[1]
            except Exception:
                pass
    cleanup_stale_proxy_data()
    return {'converted': len(nds), 'failures': tuple(failures)}


def check_linked_nodes(*_args):
    """Run one explicit linked/appended-data compatibility pass."""
    _ensure_node_info_registered()
    cleanup_stale_proxy_data()
    from .. import transform_guard as _sss_transform_guard
    failures = []
    converted = []
    visited = set()
    with _sss_transform_guard.preserve_object_transforms('noise nodes explicit linked conversion'):
        for mat in tuple(bpy.data.materials):
            if check_mat_nodes(mat):
                search_noise_group(mat.node_tree, converted, visited=visited, failures=failures)
        for obj in tuple(bpy.data.objects):
            for mod in tuple(getattr(obj, 'modifiers', ()) or ()):
                if getattr(mod, 'type', '') == 'NODES' and getattr(mod, 'node_group', None):
                    search_noise_group(mod.node_group, converted, 'GEOMETRY', visited=visited, failures=failures)
    cleanup_stale_proxy_data()
    return {'converted': len(converted), 'failures': tuple(failures)}


# noise node to node group
def process_node(node_tree, node):
    """Replace one custom Noise Node with a marked group atomically."""
    if not _ensure_node_info_registered():
        raise RuntimeError('Noise Nodes compatibility properties are unavailable')
    old_node_tree = getattr(node, 'node_tree', None)
    if old_node_tree is None:
        raise ValueError('Noise node has no generated node tree')
    links_before = snapshot_tree_links(node_tree)
    selection_before = _selection_state(node_tree)
    new_node = None
    old_name = str(node.name)
    try:
        group_type = 'ShaderNodeGroup' if node_tree.type == 'SHADER' else 'GeometryNodeGroup'
        new_node = node_tree.nodes.new(group_type)
        new_node.node_tree = old_node_tree
        new_node.parent = node.parent
        new_node.label = node.label
        new_node.location = node.location
        if not hasattr(new_node, 'Node_Info'):
            raise RuntimeError('replacement group does not expose Node_Info')
        new_node.Node_Info.is_noise_node = True
        new_node.Node_Info.bl_idname = node.bl_idname
        new_node.Node_Info.ng_name = old_node_tree.name
        if hasattr(node, 'dimension'):
            new_node.Node_Info.dimension = node.dimension
        for input_socket in tuple(node.inputs):
            target = _socket_get(new_node.inputs, input_socket.name)
            if target is None:
                continue
            _copy_socket_value(input_socket, target)
            if input_socket.is_linked and input_socket.links:
                node_tree.links.new(input_socket.links[0].from_socket, target)
        for output_socket in tuple(node.outputs):
            source = _socket_get(new_node.outputs, output_socket.name)
            if source is None:
                continue
            for link in tuple(output_socket.links) if output_socket.is_linked else ():
                node_tree.links.new(source, link.to_socket)
        node_tree.nodes.remove(node)
        try:
            new_node.name = old_name
        except Exception:
            pass
        try:
            from .nodes.utils import clear_runtime_node_tree_marker
            clear_runtime_node_tree_marker(old_node_tree, node)
        except Exception:
            pass
        return new_node
    except Exception:
        _rollback_replacement(node_tree, new_node, links_before, selection_before)
        raise


def process_node_group(node_tree, node):
    """Replace one marked compatibility group with its custom node atomically."""
    if not _ensure_node_info_registered() or not hasattr(node, 'Node_Info'):
        raise RuntimeError('group does not contain Noise Nodes compatibility data')
    old_node_tree = getattr(node, 'node_tree', None)
    links_before = snapshot_tree_links(node_tree)
    selection_before = _selection_state(node_tree)
    new_node = None
    old_name = str(node.name)
    ng_name = str(node.Node_Info.ng_name)
    try:
        new_node = node_tree.nodes.new(node.Node_Info.bl_idname)
        new_node.parent = node.parent
        new_node.location = node.location
        new_node.label = node.label
        if hasattr(new_node, 'dimension') and node.Node_Info.dimension:
            new_node.dimension = node.Node_Info.dimension
        for input_socket in tuple(node.inputs):
            target = _socket_get(new_node.inputs, input_socket.name)
            if target is None:
                continue
            _copy_socket_value(input_socket, target)
            if input_socket.is_linked and input_socket.links:
                node_tree.links.new(input_socket.links[0].from_socket, target)
        for output_socket in tuple(node.outputs):
            source = _socket_get(new_node.outputs, output_socket.name)
            if source is None:
                continue
            for link in tuple(output_socket.links) if output_socket.is_linked else ():
                node_tree.links.new(source, link.to_socket)
        node_tree.nodes.remove(node)
        try:
            new_node.name = old_name
        except Exception:
            pass
        return new_node.node_tree, ng_name, old_node_tree
    except Exception:
        _rollback_replacement(node_tree, new_node, links_before, selection_before)
        raise


def replace_legacy_node(node_tree, node, shadernode_id):
    """Replace one recoverable undefined node without leaving partial links."""
    links_before = snapshot_tree_links(node_tree)
    selection_before = _selection_state(node_tree)
    new_node = None
    old_name = str(node.name)
    try:
        new_node = node_tree.nodes.new(shadernode_id)
        new_node.location = node.location
        new_node.parent = node.parent
        new_node.label = node.label
        for input_socket in tuple(node.inputs):
            target = _socket_get(new_node.inputs, input_socket.name)
            if target is None:
                continue
            _copy_socket_value(input_socket, target)
            if input_socket.is_linked and input_socket.links:
                node_tree.links.new(input_socket.links[0].from_socket, target)
        for output_socket in tuple(node.outputs):
            source = _socket_get(new_node.outputs, output_socket.name)
            if source is None:
                continue
            for link in tuple(output_socket.links) if output_socket.is_linked else ():
                node_tree.links.new(source, link.to_socket)
        node_tree.nodes.remove(node)
        try:
            new_node.name = old_name
        except Exception:
            pass
        return new_node
    except Exception:
        _rollback_replacement(node_tree, new_node, links_before, selection_before)
        raise


def handle_legacy_nodes():
    """Do not infer undefined legacy nodes from names or temporary proxy classes."""

    return {'converted': 0, 'failures': ()}


def ng_register():
    """Perform one explicit compatibility conversion pass with no idle retry."""
    if not _ensure_node_info_registered():
        raise RuntimeError('Noise Nodes compatibility properties could not be registered')
    cleanup_stale_proxy_data()
    legacy = handle_legacy_nodes()
    runtime = convert_to_node()
    linked = check_linked_nodes() if bpy.app.version >= (4, 3, 0) else {'converted': 0, 'failures': ()}
    cleanup_stale_proxy_data()
    failures = tuple(legacy.get('failures', ())) + tuple(runtime.get('failures', ())) + tuple(linked.get('failures', ()))
    return {
        'converted': int(legacy.get('converted', 0)) + int(runtime.get('converted', 0)) + int(linked.get('converted', 0)),
        'failures': failures,
    }


def ng_unregister(run_conversion: bool = False):
    """Release exact compatibility RNA only; unregister never converts data."""

    global _NODE_INFO_CLASS_TOKEN
    del run_conversion
    while _NODE_INFO_PROPERTY_TOKENS:
        token = _NODE_INFO_PROPERTY_TOKENS.pop()
        try:
            rna_ownership.remove_property(token)
        except Exception:
            pass
    token = _NODE_INFO_CLASS_TOKEN
    _NODE_INFO_CLASS_TOKEN = None
    if token is not None:
        try:
            rna_ownership.remove_class(token)
        except Exception:
            pass

