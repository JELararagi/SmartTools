import uuid

import bpy

from ... import runtime_lifecycle
from ...translation import loc_text as _lt, _STATIC_EN_JA, _STATIC_JA_EN


SNS_NOISE_RUNTIME_PROXY_PROP = 'smart_node_suite_noise_runtime_proxy'
SNS_NOISE_RUNTIME_PROXY_OWNER_PROP = 'smart_node_suite_noise_runtime_proxy_owner'
SNS_NOISE_RUNTIME_PROXY_VERSION_PROP = 'smart_node_suite_noise_runtime_proxy_version'
SNS_NOISE_RUNTIME_PROXY_ARTIFACT_UUID_PROP = 'smart_node_suite_noise_runtime_proxy_artifact_uuid'
SNS_NOISE_RUNTIME_PROXY_SOURCE_UUID_PROP = 'smart_node_suite_noise_runtime_proxy_source_uuid'
SNS_NOISE_RUNTIME_PROXY_SESSION_PROP = 'smart_node_suite_noise_runtime_proxy_session_generation'
SNS_NOISE_RUNTIME_SOURCE_UUID_PROP = 'smart_node_suite_noise_runtime_source_uuid'
SNS_NOISE_RUNTIME_PROXY_OWNER_UUID = '68d477db-1a29-49b5-a8be-99cfb6156384'
SNS_NOISE_RUNTIME_PROXY_SCHEMA = 2


def _canonical_uuid(value):
    try:
        text = str(value or '').lower()
        return str(uuid.UUID(text)) if str(uuid.UUID(text)) == text else ''
    except Exception:
        return ''


def _source_uuid(node) -> str:
    try:
        current = _canonical_uuid(node.get(SNS_NOISE_RUNTIME_SOURCE_UUID_PROP, ''))
        if current:
            return current
        current = str(uuid.uuid4())
        node[SNS_NOISE_RUNTIME_SOURCE_UUID_PROP] = current
        return current
    except Exception:
        return ''


def mark_runtime_node_tree(node, node_tree):
    if node is None or node_tree is None:
        return False
    source_uuid = _source_uuid(node)
    session_generation = runtime_lifecycle.generation_token()
    if not source_uuid or not session_generation or not runtime_lifecycle.is_current(session_generation):
        return False
    try:
        artifact_uuid = _canonical_uuid(node_tree.get(SNS_NOISE_RUNTIME_PROXY_ARTIFACT_UUID_PROP, '')) or str(uuid.uuid4())
        node_tree[SNS_NOISE_RUNTIME_PROXY_PROP] = True
        node_tree[SNS_NOISE_RUNTIME_PROXY_OWNER_PROP] = SNS_NOISE_RUNTIME_PROXY_OWNER_UUID
        node_tree[SNS_NOISE_RUNTIME_PROXY_VERSION_PROP] = SNS_NOISE_RUNTIME_PROXY_SCHEMA
        node_tree[SNS_NOISE_RUNTIME_PROXY_ARTIFACT_UUID_PROP] = artifact_uuid
        node_tree[SNS_NOISE_RUNTIME_PROXY_SOURCE_UUID_PROP] = source_uuid
        node_tree[SNS_NOISE_RUNTIME_PROXY_SESSION_PROP] = session_generation
        return runtime_node_tree_owned_by(node, node_tree, require_current=True)
    except Exception:
        return False


def runtime_node_tree_owned_by(node, node_tree, *, require_current: bool) -> bool:
    if node is None or node_tree is None:
        return False
    try:
        source_uuid = _canonical_uuid(node.get(SNS_NOISE_RUNTIME_SOURCE_UUID_PROP, ''))
        artifact_uuid = _canonical_uuid(node_tree.get(SNS_NOISE_RUNTIME_PROXY_ARTIFACT_UUID_PROP, ''))
        session_generation = str(node_tree.get(SNS_NOISE_RUNTIME_PROXY_SESSION_PROP, '') or '')
        if not source_uuid or not artifact_uuid:
            return False
        if not bool(node_tree.get(SNS_NOISE_RUNTIME_PROXY_PROP, False)):
            return False
        if node_tree.get(SNS_NOISE_RUNTIME_PROXY_OWNER_PROP) != SNS_NOISE_RUNTIME_PROXY_OWNER_UUID:
            return False
        if int(node_tree.get(SNS_NOISE_RUNTIME_PROXY_VERSION_PROP, -1)) != SNS_NOISE_RUNTIME_PROXY_SCHEMA:
            return False
        if node_tree.get(SNS_NOISE_RUNTIME_PROXY_SOURCE_UUID_PROP) != source_uuid:
            return False
        if require_current and not runtime_lifecycle.is_current(session_generation):
            return False
        return bool(session_generation)
    except Exception:
        return False


def _default_excluded(id_data) -> bool:
    try:
        return bool(
            getattr(id_data, 'library', None)
            or getattr(id_data, 'override_library', None)
            or getattr(id_data, 'asset_data', None)
            or getattr(id_data, 'use_fake_user', False)
            or getattr(id_data, 'packed_file', None)
            or tuple(getattr(id_data, 'packed_files', ()) or ())
            or getattr(id_data, 'is_library_indirect', False)
        )
    except Exception:
        return True


def clear_runtime_node_tree_marker(node_tree, node=None):
    if node_tree is None:
        return False
    if node is not None and not runtime_node_tree_owned_by(node, node_tree, require_current=False):
        return False
    keys = (
        SNS_NOISE_RUNTIME_PROXY_PROP,
        SNS_NOISE_RUNTIME_PROXY_OWNER_PROP,
        SNS_NOISE_RUNTIME_PROXY_VERSION_PROP,
        SNS_NOISE_RUNTIME_PROXY_ARTIFACT_UUID_PROP,
        SNS_NOISE_RUNTIME_PROXY_SOURCE_UUID_PROP,
        SNS_NOISE_RUNTIME_PROXY_SESSION_PROP,
    )
    snapshot = {}
    try:
        for key in keys:
            if key in node_tree:
                snapshot[key] = node_tree[key]
        for key in keys:
            if key in node_tree:
                del node_tree[key]
        return not any(key in node_tree for key in keys)
    except Exception:
        for key, value in snapshot.items():
            try:
                node_tree[key] = value
            except Exception:
                pass
        return False


class Node:
    dimension: bpy.props.EnumProperty(
        name=_lt("Dimension"),
        items=[
            ("1D", "1D", _lt("Use the scalar value W as input")),
            (
                "2D",
                "2D",
                _lt("Use the 2D vector (X,Y) as input. The Z component is ignored", "2Dベクトル (X,Y) を入力として使用します。Z成分は無視されます"),
            ),
            ("3D", "3D", _lt("Use the 3D vector (X,Y,Z) as input", "3Dベクトル (X,Y,Z) を入力として使用します")),
            ("4D", "4D", _lt("Use the 4D vector (X,Y,Z,W) as input", "4Dベクトル (X,Y,Z,W) を入力として使用します")),
        ],
        update=lambda self, context: self.update_dim(context),
        default="3D",
        description=_lt("Number of dimension to output noise for", "ノイズを出力する次元数です"),
    )

    def update_dim(self, context):
        """Update function that runs when dimension changes"""
        if not self.node_tree:
            return
        self._ensure_own_node_tree()

        # Update noise-related nodes
        for node in self.node_tree.nodes:
            if node.type == "TEX_NOISE":
                node.noise_dimensions = self.dimension
            elif node.type == "TEX_VORONOI":
                node.voronoi_dimensions = self.dimension

        # Show/hide Vector input
        vector = self.inputs.get("Vector")
        if vector:
            vector.hide = self.dimension == "1D"
        w = self.inputs.get("W")
        if w:
            w.hide = not (self.dimension in ["1D", "4D"])
            

    def _node_tree_is_shared(self):
        # ID.users reads 2 for a tree created in init(), so count the real users.
        node_tree = self.node_tree
        count = 0
        for owner in bpy.data.user_map(subset=[node_tree]).get(node_tree, ()):
            owner_tree = owner if isinstance(owner, bpy.types.NodeTree) else getattr(owner, 'node_tree', None)
            if owner_tree is None:
                return True
            count += sum(1 for node in owner_tree.nodes if getattr(node, 'node_tree', None) == node_tree)
        return count > 1

    def _ensure_own_node_tree(self):
        # A duplicated node shares its tree with the original. Dimension is
        # written into the tree, so give this node its own before changing it.
        node_tree = self.node_tree
        if not self._node_tree_is_shared():
            return
        copied = node_tree.copy()
        clear_runtime_node_tree_marker(copied)
        if SNS_NOISE_RUNTIME_SOURCE_UUID_PROP in self:
            del self[SNS_NOISE_RUNTIME_SOURCE_UUID_PROP]
        self.node_tree = copied
        mark_runtime_node_tree(self, copied)

    def _socket_name_variants(self, name):
        aliases = []
        for item in (name, _lt(name), _STATIC_EN_JA.get(str(name)), _STATIC_JA_EN.get(str(name))):
            if item and item not in aliases:
                aliases.append(item)
        return aliases

    def _input(self, name):
        for item in self._socket_name_variants(name):
            socket = self.inputs.get(item)
            if socket is not None:
                return socket
        return self.inputs[name]

    def _output(self, name):
        for item in self._socket_name_variants(name):
            socket = self.outputs.get(item)
            if socket is not None:
                return socket
        return self.outputs[name]

    def draw_buttons(self, context, layout):
        if getattr(self, "ss_label_key", self.bl_label) != "Pixelator":
            layout.prop(self, "dimension", text="")

    def createNodetree(self, name):
        pass

    def getNodetree(self, name):
        self.createNodetree(name)
        mark_runtime_node_tree(self, getattr(self, 'node_tree', None))

        # if bpy.data.node_groups.find(name)==-1:
        #     self.createNodetree(name)
        # else:
        #     self.node_tree=bpy.data.node_groups[name]

    def addSocket(self, is_output, sockettype, name):
        if is_output == True:
            socket = self.node_tree.interface.new_socket(
                name, in_out="OUTPUT", socket_type=sockettype
            )
        else:
            socket = self.node_tree.interface.new_socket(
                name, in_out="INPUT", socket_type=sockettype
            )

        return socket

    def addNode(self, nodetype, attrs):
        node = self.node_tree.nodes.new(nodetype)
        for attr in attrs:
            self.value_set(node, attr, attrs[attr])
        return node

    def getNode(self, nodename):
        if self.node_tree.nodes.find(nodename) > -1:
            return self.node_tree.nodes[nodename]
        return None

    def innerLink(self, socketin, socketout):
        SI = self.node_tree.path_resolve(socketin)
        SO = self.node_tree.path_resolve(socketout)
        self.node_tree.links.new(SI, SO)

    def value_set(self, obj, path, value):
        if "." in path:
            path_prop, path_attr = path.rsplit(".", 1)
            prop = obj.path_resolve(path_prop)
        else:
            prop = obj
            path_attr = path
        setattr(prop, path_attr, value)

    def free(self):
        node_tree = getattr(self, 'node_tree', None)
        if (
            node_tree is not None
            and runtime_node_tree_owned_by(self, node_tree, require_current=True)
            and not _default_excluded(node_tree)
            and int(getattr(node_tree, 'users', 0)) == 1
        ):
            bpy.data.node_groups.remove(node_tree, do_unlink=True)


class ShaderNode(Node, bpy.types.ShaderNodeCustomGroup):
    pass


class GeometryNode(Node, bpy.types.GeometryNodeCustomGroup):
    pass
