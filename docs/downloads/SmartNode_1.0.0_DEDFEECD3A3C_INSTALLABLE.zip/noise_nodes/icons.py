# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from pathlib import Path

try:
    import bpy.utils.previews as _previews
except Exception:  # pragma: no cover - Blender-only module
    _previews = None


class Icon:
    ICON_RENAME_ALIASES = {
        'crackle_noise': 'crackle_noise',
        'crackle': 'crackle_noise',
        'cranal_noise': 'cranal_noise',
        'cranal': 'cranal_noise',
        'dent_noise': 'dent_noise',
        'dent': 'dent_noise',
        'fluid_noise': 'fluid_noise',
        'fluid': 'fluid_noise',
        'fractal_noise': 'fractal_noise',
        'fractal': 'fractal_noise',
        'perlin_noise': 'perlin_noise',
        'perlin': 'perlin_noise',
        'regular_noise': 'regular_noise',
        'regular': 'regular_noise',
        'scratches_noise': 'scratches_noise',
        'scratches': 'scratches_noise',
        'step_noise': 'step_noise',
        'step': 'step_noise',
        'streaks_noise': 'streaks_noise',
        'streaks': 'streaks_noise',
        'voxel_noise': 'voxel_noise',
        'voxel': 'voxel_noise',
        'dot_noise': 'dot_noise',
        'dots_noise': 'dot_noise',
        'dot': 'dot_noise',
        'dots': 'dot_noise',
        'wavy_noise': 'wavy_noise',
        'wavy': 'wavy_noise',
        'pixelator': 'pixelator',
        'pixelator_node': 'pixelator',
    }

    ICON_FILES = (
        'crackle_noise.png', 'cranal_noise.png', 'dent_noise.png', 'dot_noise.png',
        'fluid_noise.png', 'fractal_noise.png', 'perlin_noise.png', 'pixelator.png',
        'regular_noise.png', 'scratches_noise.png', 'step_noise.png',
        'streaks_noise.png', 'voxel_noise.png', 'wavy_noise.png',
    )
    icons = None
    loaded_count = 0
    missing = ()

    @staticmethod
    def _normalize(name):
        text = str(name or '').strip()
        text = ''.join(ch.lower() if ch.isalnum() else '_' for ch in text)
        while '__' in text:
            text = text.replace('__', '_')
        return text.strip('_')

    @classmethod
    def _search_dirs(cls):
        package_dir = Path(__file__).resolve().parent
        candidates = (
            package_dir.parent / 'icons',
            package_dir / 'icons',
            package_dir.parent / 'icon',
            package_dir / 'icon',
            package_dir.parent / 'icon' / 'noise_nodes',
            package_dir.parent / 'icons' / 'noise_nodes',
        )
        seen = set()
        for path in candidates:
            try:
                resolved = path.resolve()
            except Exception:
                resolved = path
            key = str(resolved)
            if key in seen:
                continue
            seen.add(key)
            yield resolved

    @classmethod
    def register_icons(cls, force=False):
        if _previews is None:
            cls.icons = None
            cls.loaded_count = 0
            return
        if cls.icons is not None and not force:
            return
        if cls.icons is not None and force:
            try:
                _previews.remove(cls.icons)
            except Exception:
                pass
            cls.icons = None
        try:
            icons = _previews.new()
        except Exception:
            cls.icons = None
            cls.loaded_count = 0
            return
        loaded = set()
        aliases = cls.ICON_RENAME_ALIASES
        folder = Path(__file__).resolve().parent.parent / 'icons'
        missing = []
        for filename in cls.ICON_FILES:
            item = folder / filename
            iconname = item.stem
            if not item.is_file():
                missing.append(filename)
                continue
            try:
                icons.load(iconname, str(item), 'IMAGE')
                loaded.add(iconname)
            except Exception:
                missing.append(filename)
        cls.missing = tuple(missing)
        for alias, target in aliases.items():
            if alias in loaded or target not in loaded:
                continue
            target_item = None
            try:
                target_item = icons.get(target)
            except Exception:
                target_item = None
            # Blender preview collections cannot alias an existing item directly,
            # so aliases are resolved in get_icon(); this records the known names.
            if target_item is not None:
                loaded.add(alias)
        cls.icons = icons
        cls.loaded_count = len(loaded)

    @classmethod
    def unregister_icons(cls):
        try:
            if _previews is not None and cls.icons is not None:
                _previews.remove(cls.icons)
        except Exception:
            pass
        cls.icons = None
        cls.loaded_count = 0

    @classmethod
    def get_icon(cls, name):
        if cls.icons is None:
            return 0
        raw = str(name or '').strip()
        normalized = cls._normalize(raw)
        aliases = cls.ICON_RENAME_ALIASES
        candidates = []
        pending = [raw, raw.replace(' ', '_'), raw.replace(' ', '_').lower(), normalized, aliases.get(normalized)]
        while pending:
            value = str(pending.pop(0) or '').strip()
            if not value or value in candidates:
                continue
            candidates.append(value)
            mapped = aliases.get(value)
            if mapped and mapped not in candidates:
                pending.append(mapped)
        for item in candidates:
            try:
                preview = cls.icons.get(item)
            except Exception:
                preview = None
            icon_id = int(getattr(preview, 'icon_id', 0) or 0)
            if icon_id:
                return icon_id
        # Never recreate preview collections from a menu/panel draw.  If an icon
        # cannot be resolved here, let Blender draw the standard fallback instead.
        return 0
