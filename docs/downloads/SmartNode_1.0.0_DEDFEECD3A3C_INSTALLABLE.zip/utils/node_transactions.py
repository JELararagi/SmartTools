# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

"""Direct node-tree mutation helpers used to keep one Blender undo boundary.

The helpers never call ``bpy.ops`` and never retain RNA references after the
calling operator returns.
"""

from __future__ import annotations

from typing import Any

_SKIP_NODE_PROPERTIES = {
    'rna_type', 'type', 'bl_idname', 'bl_label', 'name', 'location',
    'dimensions', 'inputs', 'outputs', 'internal_links', 'parent', 'select',
    'interface', 'is_active_output',
}
_SKIP_SOCKET_PROPERTIES = {
    'rna_type', 'bl_idname', 'name', 'identifier', 'type', 'links', 'node', 'id_data',
    'is_output', 'is_linked', 'is_multi_input', 'link_limit', 'index',
}


def _copyable_value(value: Any):
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return value
    if hasattr(value, 'bl_rna'):
        # Blender ID/RNA pointer values are assigned only during this operation;
        # they are never stored in a module-level cache.
        return value
    try:
        sequence = tuple(value)
    except Exception:
        return None
    if len(sequence) > 64:
        return None
    if all(isinstance(item, (bool, int, float, str)) for item in sequence):
        return sequence
    return None


def copy_rna_properties(source, target, *, skip=frozenset()) -> None:
    try:
        properties = tuple(source.bl_rna.properties)
    except Exception:
        return
    for prop in properties:
        identifier = str(getattr(prop, 'identifier', '') or '')
        if not identifier or identifier in skip:
            continue
        if bool(getattr(prop, 'is_readonly', False)):
            continue
        try:
            value = _copyable_value(getattr(source, identifier))
        except Exception:
            continue
        if value is None and getattr(source, identifier, None) is not None:
            continue
        try:
            setattr(target, identifier, value)
        except Exception:
            try:
                target_value = getattr(target, identifier)
                if isinstance(value, tuple):
                    for index, item in enumerate(value):
                        target_value[index] = item
            except Exception:
                pass


def copy_socket_defaults(source_sockets, target_sockets) -> None:
    for index, source in enumerate(tuple(source_sockets)):
        if index >= len(target_sockets):
            break
        target = target_sockets[index]
        try:
            if hasattr(source, 'default_value') and hasattr(target, 'default_value'):
                value = _copyable_value(source.default_value)
                if value is not None or source.default_value is None:
                    try:
                        target.default_value = value
                    except Exception:
                        if isinstance(value, tuple):
                            for component_index, component in enumerate(value):
                                target.default_value[component_index] = component
        except Exception:
            pass
        copy_rna_properties(source, target, skip=_SKIP_SOCKET_PROPERTIES | {'default_value'})


def clone_node(tree, source, *, location=None, parent=None, select=False):
    node = None
    try:
        node = tree.nodes.new(type=str(source.bl_idname))
        copy_rna_properties(source, node, skip=_SKIP_NODE_PROPERTIES)
        copy_socket_defaults(source.inputs, node.inputs)
        copy_socket_defaults(source.outputs, node.outputs)
        try:
            node.label = source.label
        except Exception:
            pass
        try:
            node.hide = bool(source.hide)
        except Exception:
            pass
        try:
            node.width = float(source.width)
        except Exception:
            pass
        try:
            node.height = float(source.height)
        except Exception:
            pass
        try:
            node.location = location if location is not None else source.location.copy()
        except Exception:
            pass
        try:
            node.parent = parent
        except Exception:
            pass
        try:
            node.select = bool(select)
        except Exception:
            pass
        return node
    except Exception:
        if node is not None:
            try:
                tree.nodes.remove(node)
            except Exception:
                pass
        raise


def socket_index(sockets, socket) -> int:
    for index, candidate in enumerate(tuple(sockets)):
        if candidate == socket:
            return index
    return -1


def link_if_compatible(tree, output_socket, input_socket):
    if output_socket is None or input_socket is None:
        return None
    if not bool(getattr(output_socket, 'is_output', False)):
        return None
    if bool(getattr(input_socket, 'is_output', False)):
        return None
    try:
        return tree.links.new(output_socket, input_socket)
    except Exception:
        return None


def snapshot_links(tree, nodes) -> list[tuple[object, int, object, int]]:
    node_set = set(nodes)
    records = []
    for link in tuple(tree.links):
        if link.from_node in node_set or link.to_node in node_set:
            records.append((
                link.from_node,
                socket_index(link.from_node.outputs, link.from_socket),
                link.to_node,
                socket_index(link.to_node.inputs, link.to_socket),
            ))
    return records


def restore_links(tree, records, node_map=None) -> None:
    mapping = node_map or {}
    for from_node, from_index, to_node, to_index in records:
        source = mapping.get(from_node, from_node)
        target = mapping.get(to_node, to_node)
        try:
            link_if_compatible(tree, source.outputs[from_index], target.inputs[to_index])
        except Exception:
            pass



def snapshot_tree_links(tree) -> tuple[tuple[str, int, str, int], ...]:
    """Capture all links as plain node names and socket indices."""
    records = []
    for link in tuple(tree.links):
        try:
            from_index = socket_index(link.from_node.outputs, link.from_socket)
            to_index = socket_index(link.to_node.inputs, link.to_socket)
            if from_index < 0 or to_index < 0:
                continue
            records.append((
                str(link.from_node.name),
                int(from_index),
                str(link.to_node.name),
                int(to_index),
            ))
        except Exception:
            continue
    return tuple(records)


def restore_tree_links(tree, records) -> bool:
    """Replace current links with a previously captured plain-data snapshot."""
    try:
        for link in tuple(tree.links):
            tree.links.remove(link)
        for from_name, from_index, to_name, to_index in tuple(records):
            source = tree.nodes.get(str(from_name))
            target = tree.nodes.get(str(to_name))
            if source is None or target is None:
                continue
            if not (0 <= int(from_index) < len(source.outputs)):
                continue
            if not (0 <= int(to_index) < len(target.inputs)):
                continue
            tree.links.new(source.outputs[int(from_index)], target.inputs[int(to_index)])
        return True
    except Exception:
        return False

def bypass_node(tree, node) -> None:
    incoming_by_input = {}
    outgoing_by_output = {}
    for link in tuple(tree.links):
        if link.to_node == node:
            incoming_by_input.setdefault(link.to_socket, []).append(link.from_socket)
        if link.from_node == node:
            outgoing_by_output.setdefault(link.from_socket, []).append(link.to_socket)

    routed = set()
    for internal in tuple(getattr(node, 'internal_links', ()) or ()):
        in_socket = getattr(internal, 'from_socket', None)
        out_socket = getattr(internal, 'to_socket', None)
        for source_socket in incoming_by_input.get(in_socket, ()):
            for target_socket in outgoing_by_output.get(out_socket, ()):
                key = (id(source_socket), id(target_socket))
                if key not in routed:
                    link_if_compatible(tree, source_socket, target_socket)
                    routed.add(key)

    # Nodes without internal links receive a conservative index/name fallback.
    if not routed:
        for in_socket, sources in incoming_by_input.items():
            candidates = [
                output for output in outgoing_by_output
                if str(getattr(output, 'name', '')) == str(getattr(in_socket, 'name', ''))
            ]
            if not candidates:
                index = socket_index(node.inputs, in_socket)
                if 0 <= index < len(node.outputs):
                    candidates = [node.outputs[index]]
            for out_socket in candidates[:1]:
                for source_socket in sources:
                    for target_socket in outgoing_by_output.get(out_socket, ()):
                        link_if_compatible(tree, source_socket, target_socket)


def remove_node_with_bypass(tree, node) -> None:
    records = snapshot_tree_links(tree)
    try:
        bypass_node(tree, node)
        tree.nodes.remove(node)
    except Exception:
        restore_tree_links(tree, records)
        raise
