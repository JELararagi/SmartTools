# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import bpy
from mathutils import Vector


def _package_root() -> str:
    package = __package__ or 'smart_node_suite.utils'
    for suffix in ('.utils', '.operators'):
        if package.endswith(suffix):
            return package[:-len(suffix)]
    return package or 'smart_node_suite'


def addon_preferences(context=None):
    """Return Smart Node Suite add-on preferences for add-on or extension installs."""
    try:
        ctx = context or bpy.context
        candidates = (_package_root(), 'smart_node_suite')
        for module_name in dict.fromkeys(candidates):
            try:
                return ctx.preferences.addons[module_name].preferences
            except Exception:
                pass
    except Exception:
        pass
    return None


def major_grid_size(context=None) -> float:
    prefs = addon_preferences(context)
    try:
        return max(1.0, float(getattr(prefs, 'layout_major_grid_unit', 120.0)))
    except Exception:
        return 120.0


def use_major_grid_spacing(context=None) -> bool:
    prefs = addon_preferences(context)
    try:
        return bool(getattr(prefs, 'layout_use_major_grid_spacing', True))
    except Exception:
        return False


def layout_snap_after_arrange(context=None) -> bool:
    prefs = addon_preferences(context)
    try:
        return bool(getattr(prefs, 'layout_snap_after_arrange', False))
    except Exception:
        return False


def spacing_reference(context=None) -> str:
    prefs = addon_preferences(context)
    try:
        value = str(getattr(prefs, 'layout_spacing_reference', 'EDGE_GUARDED'))
    except Exception:
        value = 'EDGE_GUARDED'
    return value if value in {'EDGE_GUARDED', 'BOUNDS_GAP'} else 'EDGE_GUARDED'


def _major_steps(context=None, axis: str = 'HORIZONTAL') -> float:
    prefs = addon_preferences(context)
    attr = 'layout_column_major_steps' if axis == 'HORIZONTAL' else 'layout_row_major_steps'
    default = 3.0 if axis == 'HORIZONTAL' else 2.0
    try:
        return max(1.0, float(getattr(prefs, attr, default)))
    except Exception:
        return default


def guard_gap(context=None) -> float:
    prefs = addon_preferences(context)
    try:
        units = max(0.0, float(getattr(prefs, 'layout_min_gap_major_steps', 1.0)))
    except Exception:
        units = 1.0
    return units * major_grid_size(context)


def major_axis_distance(context=None, axis: str = 'HORIZONTAL') -> float:
    return major_grid_size(context) * _major_steps(context, axis)


def axis_advance(context, item_size: float, fallback_gap: float, axis: str = 'HORIZONTAL') -> float:
    """Distance from one node top-left anchor to the next anchor.

    In major-grid mode the distance is expressed in major grid dots.  The
    EDGE_GUARDED reference keeps left/top-edge distances at the requested major
    dot count when possible, but automatically expands when a node is larger so
    adjacent node bounds still keep the configured guard gap.
    """
    try:
        item_size = max(0.0, float(item_size))
    except Exception:
        item_size = 0.0
    try:
        fallback_gap = max(0.0, float(fallback_gap))
    except Exception:
        fallback_gap = 0.0

    if not use_major_grid_spacing(context):
        return item_size + fallback_gap

    target = major_axis_distance(context, axis)
    if spacing_reference(context) == 'BOUNDS_GAP':
        return item_size + target
    return max(target, item_size + guard_gap(context))


def snap_value(value: float, size: float) -> float:
    try:
        size = max(1.0, float(size))
        return round(float(value) / size) * size
    except Exception:
        return value


def snap_vector_to_grid(location, size: float) -> Vector:
    loc = Vector(location)
    return Vector((snap_value(loc.x, size), snap_value(loc.y, size)))


def snap_aligned_nodes_to_major_grid(nodes, context=None, get_location=None, set_location=None) -> None:
    """Snap nodes that were just aligned to each other with one shared offset.

    Nodes differ in size, so snapping each node on its own pulls center, right and
    bottom edges apart again. Frames are skipped: they follow their children.
    """
    if not layout_snap_after_arrange(context):
        return
    targets = [node for node in nodes if node is not None and getattr(node, 'type', '') != 'FRAME']
    if not targets:
        return
    read = get_location or (lambda node: node.location)
    anchor = Vector(read(targets[0]))
    offset = snap_vector_to_grid(anchor, major_grid_size(context)) - Vector((anchor.x, anchor.y))
    for node in targets:
        loc = Vector(read(node))
        moved = Vector((loc.x + offset.x, loc.y + offset.y))
        if set_location:
            set_location(node, moved)
        else:
            node.location.x = moved.x
            node.location.y = moved.y


def snap_nodes_to_major_grid(nodes, context=None, get_location=None, set_location=None, axes: str = 'XY') -> None:
    """Snap arranged nodes to the major grid, only on the axes the arrangement owns.

    A one-axis sort or distribute promises to leave the other axis alone, so its
    callers pass axes='X' or axes='Y'.
    """
    if not layout_snap_after_arrange(context):
        return
    size = major_grid_size(context)
    for node in nodes:
        try:
            loc = get_location(node) if get_location else node.location
            snapped = snap_vector_to_grid(loc, size)
            if 'X' not in axes:
                snapped.x = loc.x
            if 'Y' not in axes:
                snapped.y = loc.y
            if set_location:
                set_location(node, snapped)
            else:
                node.location.x = snapped.x
                node.location.y = snapped.y
        except Exception:
            pass
