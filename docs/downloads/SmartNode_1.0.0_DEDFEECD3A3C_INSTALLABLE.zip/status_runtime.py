# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Finite compatibility surface for the former shared status instrumentation.

The public functions remain import-compatible, but this implementation never
patches Blender APIs or registered RNA callbacks and never creates a timer,
handler, message-bus subscription, draw service, thread, or retry loop.
Transient entries expire only when this API is called again or inspected.
"""

from __future__ import annotations

from collections import OrderedDict
from contextlib import contextmanager
from time import monotonic
from typing import Any, Dict, Iterator, Optional

_VERSION = 3
_DEFAULT_TRANSIENT_SECONDS = 0.35
_MAX_ENTRIES = 128
_sequence = 0
_entries: "OrderedDict[str, dict[str, Any]]" = OrderedDict()
_stats: dict[str, dict[str, int]] = {}


def _now() -> float:
    return monotonic()


def _purge_expired() -> None:
    now = _now()
    for key, entry in tuple(_entries.items()):
        expires_at = entry.get('expires_at')
        if expires_at is not None and float(expires_at) <= now:
            _entries.pop(key, None)


def _upsert(
    key: str,
    owner: str,
    text: str,
    *,
    priority: int,
    duration: float | None,
    kind: str,
    context=None,
) -> str:
    del context
    global _sequence
    _purge_expired()
    _sequence += 1
    _entries.pop(key, None)
    _entries[key] = {
        'key': key,
        'owner': str(owner or ''),
        'text': str(text or ''),
        'priority': int(priority),
        'sequence': _sequence,
        'kind': str(kind or ''),
        'expires_at': None if duration is None else _now() + max(0.0, float(duration)),
    }
    while len(_entries) > _MAX_ENTRIES:
        _entries.popitem(last=False)
    return key


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None) -> str:
    key = f'transient:{owner}'
    return _upsert(key, owner, text, priority=20, duration=duration, kind='transient', context=context)


def set_service(owner: str, text: str, *, context=None) -> str:
    key = f'service:{owner}'
    return _upsert(key, owner, text, priority=10, duration=None, kind='service', context=context)


def begin_task(owner: str, text: str, *, context=None) -> str:
    global _sequence
    _sequence += 1
    token = f'task:{owner}:{_sequence}'
    return _upsert(token, owner, text, priority=30, duration=None, kind='task', context=context)


def update_task(token: str, text: str, *, context=None) -> bool:
    del context
    global _sequence
    _purge_expired()
    entry = _entries.get(str(token))
    if entry is None:
        return False
    _sequence += 1
    entry['sequence'] = _sequence
    entry['text'] = str(text or '')
    _entries.move_to_end(str(token))
    return True


def finish_task(
    token: str,
    final_text: Optional[str] = None,
    duration: float = 0.12,
    *,
    context=None,
) -> None:
    entry = _entries.pop(str(token), None)
    owner = str(entry.get('owner', token)) if entry else str(token)
    if final_text:
        set_transient(owner, final_text, duration=duration, context=context)


def clear(owner_or_token: str, *, context=None) -> None:
    del context
    target = str(owner_or_token)
    _entries.pop(target, None)
    for key, entry in tuple(_entries.items()):
        if str(entry.get('owner', '')) == target:
            _entries.pop(key, None)


def clear_prefix(prefix: str, *, context=None) -> None:
    del context
    text = str(prefix or '')
    for key, entry in tuple(_entries.items()):
        if str(key).startswith(text) or str(entry.get('owner', '')).startswith(text):
            _entries.pop(key, None)


def clear_all(*, context=None) -> None:
    del context
    _entries.clear()


def snapshot() -> Dict[str, Any]:
    _purge_expired()
    entries = [dict(item) for item in _entries.values()]
    top = max(entries, key=lambda item: (int(item['priority']), int(item['sequence'])), default=None)
    return {
        'version': _VERSION,
        'entry_count': len(entries),
        'entry_limit': _MAX_ENTRIES,
        'entries': entries,
        'visible_text': None if top is None else top.get('text'),
        'timer_registered': False,
        'captured_timer_count': 0,
        'captured_draw_count': 0,
        'resource_capture_depth': 0,
        'resource_monitor_registered': False,
        'stats': {suite: dict(values) for suite, values in _stats.items()},
    }


@contextmanager
def task_scope(
    owner: str,
    text: str,
    *,
    context=None,
    completed_text: Optional[str] = None,
    error_prefix: Optional[str] = None,
) -> Iterator[str]:
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception as exc:
        finish_task(token, f"{error_prefix or 'Error'}: {exc}", duration=2.5, context=context)
        raise
    else:
        finish_task(token, completed_text, context=context)


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    del suite_id, suite_label
    return cls


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str) -> int:
    del package_marker, suite_id, suite_label
    return 0


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None) -> int:
    del suite_id
    return 0


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str) -> int:
    del package_marker, suite_id, suite_label
    return 0


def restore_package_handlers(suite_id: str) -> int:
    del suite_id
    return 0
