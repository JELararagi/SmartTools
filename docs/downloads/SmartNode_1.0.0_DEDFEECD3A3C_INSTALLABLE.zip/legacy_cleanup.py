# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

"""Ownership-exact RNA-only legacy artifact migration.

This module never reads, decompresses, patches, recompresses, replaces, or
otherwise writes a saved ``.blend`` file.  It removes only two exact ID-property
records from artifacts whose owner, artifact, source, file generation, session
generation, schema, source manifest, and payload fingerprint all match.  The
explicit operator runs dry-run -> frozen candidate set -> revalidation ->
journal -> commit, and rolls the complete journal back on any failure.  Blender
itself persists the resulting RNA state during a later normal save.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import uuid
from typing import Any, Final

import bpy

from . import runtime_lifecycle

SCHEMA_VERSION: Final[int] = 1
OWNER_UUID: Final[str] = '401276e5-595a-49e2-bda3-89a0b539051f'
ARTIFACT_KIND: Final[str] = 'legacy_proxy_id_property'
FILE_MANIFEST_PROPERTY: Final[str] = '_smart_node_suite_file_manifest_v1'
SOURCE_MANIFEST_PROPERTY: Final[str] = '_smart_node_suite_source_manifest_v1'
ARTIFACT_MANIFEST_PROPERTY: Final[str] = '_smart_node_suite_artifact_manifest_v1'
PAYLOAD_PROPERTY: Final[str] = '_smart_node_suite_legacy_payload_v1'
_MAX_VALUE_DEPTH: Final[int] = 8
_MAX_CONTAINER_ITEMS: Final[int] = 1024
_MAX_STRING_LENGTH: Final[int] = 65536

# Fixed collection names only.  There is no bpy.data/dir scan, class-name scan,
# panel unregister, proxy-name match, prefix match, unowned-user-count deletion, or ID
# datablock removal.
_SUPPORTED_ID_COLLECTIONS: Final[tuple[str, ...]] = (
    'actions',
    'armatures',
    'brushes',
    'cameras',
    'collections',
    'curves',
    'fonts',
    'grease_pencils_v3',
    'images',
    'lattices',
    'lightprobes',
    'lights',
    'linestyles',
    'masks',
    'materials',
    'meshes',
    'metaballs',
    'movieclips',
    'node_groups',
    'objects',
    'paint_curves',
    'palettes',
    'particles',
    'pointclouds',
    'scenes',
    'screens',
    'shape_keys',
    'sounds',
    'speakers',
    'texts',
    'textures',
    'volumes',
    'worlds',
)

_FILE_KEYS: Final[frozenset[str]] = frozenset({
    'schema', 'owner_uuid', 'file_generation',
})
_SOURCE_KEYS: Final[frozenset[str]] = frozenset({
    'schema', 'owner_uuid', 'source_uuid', 'file_generation', 'session_generation',
})
_ARTIFACT_KEYS: Final[frozenset[str]] = frozenset({
    'schema',
    'owner_uuid',
    'artifact_uuid',
    'source_uuid',
    'file_generation',
    'session_generation',
    'artifact_kind',
    'artifact_collection',
    'artifact_name',
    'source_collection',
    'source_name',
    'payload_property',
    'payload_sha256',
})


@dataclass(frozen=True)
class CleanupCandidate:
    artifact_collection: str
    artifact_name: str
    artifact_pointer: int
    artifact_uuid: str
    source_collection: str
    source_name: str
    source_pointer: int
    source_uuid: str
    file_generation: str
    session_generation: str
    manifest_json: str
    payload_sha256: str


@dataclass(frozen=True)
class JournalEntry:
    artifact_collection: str
    artifact_name: str
    artifact_pointer: int
    artifact_manifest: Any
    payload: Any


_LAST_REPORT: dict[str, Any] = {
    'phase': 'idle',
    'candidate_count': 0,
    'committed_count': 0,
    'rolled_back': False,
    'error': '',
}


def _plain(value: Any, *, depth: int = 0) -> Any:
    if depth > _MAX_VALUE_DEPTH:
        raise ValueError('legacy artifact metadata nesting exceeds the limit')
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        if len(value) > _MAX_STRING_LENGTH:
            raise ValueError('legacy artifact metadata string exceeds the limit')
        return value
    if isinstance(value, dict) or hasattr(value, 'keys'):
        try:
            keys = tuple(value.keys())
        except Exception as exc:
            raise ValueError('legacy artifact metadata mapping is unreadable') from exc
        if len(keys) > _MAX_CONTAINER_ITEMS:
            raise ValueError('legacy artifact metadata mapping exceeds the limit')
        result: dict[str, Any] = {}
        for key in keys:
            text_key = str(key)
            if len(text_key) > 256:
                raise ValueError('legacy artifact metadata key exceeds the limit')
            result[text_key] = _plain(value[key], depth=depth + 1)
        return result
    if isinstance(value, (list, tuple)) or hasattr(value, '__iter__'):
        try:
            items = tuple(value)
        except Exception as exc:
            raise ValueError('legacy artifact metadata sequence is unreadable') from exc
        if len(items) > _MAX_CONTAINER_ITEMS:
            raise ValueError('legacy artifact metadata sequence exceeds the limit')
        return [_plain(item, depth=depth + 1) for item in items]
    raise ValueError(f'unsupported legacy artifact metadata type: {type(value).__name__}')


def _canonical_json(value: Any) -> str:
    return json.dumps(_plain(value), ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _payload_sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode('utf-8')).hexdigest()


def _canonical_uuid(value: Any) -> str | None:
    text = str(value or '').strip().lower()
    try:
        parsed = str(uuid.UUID(text))
    except Exception:
        return None
    return parsed if parsed == text else None


def _as_pointer(value) -> int:
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _property_value(id_data, name: str):
    try:
        if name not in id_data:
            return None
        return id_data[name]
    except Exception:
        return None


def _is_default_excluded(id_data) -> bool:
    try:
        if getattr(id_data, 'library', None) is not None:
            return True
        if getattr(id_data, 'override_library', None) is not None:
            return True
        if getattr(id_data, 'asset_data', None) is not None:
            return True
        if bool(getattr(id_data, 'use_fake_user', False)):
            return True
        if getattr(id_data, 'packed_file', None) is not None:
            return True
        packed_files = getattr(id_data, 'packed_files', None)
        if packed_files is not None and len(packed_files) > 0:
            return True
        if bool(getattr(id_data, 'is_library_indirect', False)):
            return True
    except Exception:
        return True
    return False


def _collection(name: str):
    if name not in _SUPPORTED_ID_COLLECTIONS:
        return None
    return getattr(getattr(bpy, 'data', None), name, None)


def _resolve_id(collection_name: str, item_name: str):
    collection = _collection(collection_name)
    if collection is None:
        return None
    try:
        return collection.get(item_name)
    except Exception:
        try:
            for item in collection:
                if str(getattr(item, 'name', '') or '') == item_name:
                    return item
        except Exception:
            return None
    return None


def _file_manifest(context) -> dict[str, Any] | None:
    scene = getattr(context, 'scene', None)
    if scene is None or _is_default_excluded(scene):
        return None
    raw = _property_value(scene, FILE_MANIFEST_PROPERTY)
    if raw is None:
        return None
    try:
        value = _plain(raw)
    except Exception:
        return None
    if not isinstance(value, dict) or frozenset(value) != _FILE_KEYS:
        return None
    if value.get('schema') != SCHEMA_VERSION or value.get('owner_uuid') != OWNER_UUID:
        return None
    generation = _canonical_uuid(value.get('file_generation'))
    if generation is None:
        return None
    value['file_generation'] = generation
    return value


def _source_manifest(source, *, file_generation: str, session_generation: str, source_uuid: str) -> dict[str, Any] | None:
    raw = _property_value(source, SOURCE_MANIFEST_PROPERTY)
    if raw is None:
        return None
    try:
        value = _plain(raw)
    except Exception:
        return None
    if not isinstance(value, dict) or frozenset(value) != _SOURCE_KEYS:
        return None
    expected = {
        'schema': SCHEMA_VERSION,
        'owner_uuid': OWNER_UUID,
        'source_uuid': source_uuid,
        'file_generation': file_generation,
        'session_generation': session_generation,
    }
    return value if value == expected else None


def _validate_artifact_manifest(
    id_data,
    collection_name: str,
    *,
    file_generation: str,
    session_generation: str,
) -> tuple[dict[str, Any], Any, object] | None:
    raw = _property_value(id_data, ARTIFACT_MANIFEST_PROPERTY)
    payload = _property_value(id_data, PAYLOAD_PROPERTY)
    if raw is None or payload is None:
        return None
    try:
        record = _plain(raw)
    except Exception:
        return None
    if not isinstance(record, dict) or frozenset(record) != _ARTIFACT_KEYS:
        return None
    if record.get('schema') != SCHEMA_VERSION or record.get('owner_uuid') != OWNER_UUID:
        return None
    artifact_uuid = _canonical_uuid(record.get('artifact_uuid'))
    source_uuid = _canonical_uuid(record.get('source_uuid'))
    if artifact_uuid is None or source_uuid is None:
        return None
    if record.get('file_generation') != file_generation:
        return None
    if record.get('session_generation') != session_generation:
        return None
    if record.get('artifact_kind') != ARTIFACT_KIND:
        return None
    if record.get('artifact_collection') != collection_name:
        return None
    if record.get('artifact_name') != str(getattr(id_data, 'name', '') or ''):
        return None
    if record.get('payload_property') != PAYLOAD_PROPERTY:
        return None
    source_collection = str(record.get('source_collection') or '')
    source_name = str(record.get('source_name') or '')
    if source_collection not in _SUPPORTED_ID_COLLECTIONS or not source_name:
        return None
    source = _resolve_id(source_collection, source_name)
    if source is None or _is_default_excluded(source):
        return None
    if _source_manifest(
        source,
        file_generation=file_generation,
        session_generation=session_generation,
        source_uuid=source_uuid,
    ) is None:
        return None
    try:
        payload_digest = _payload_sha256(payload)
    except Exception:
        return None
    if record.get('payload_sha256') != payload_digest:
        return None
    record['artifact_uuid'] = artifact_uuid
    record['source_uuid'] = source_uuid
    return record, payload, source


def dry_run_candidates(context=None) -> tuple[CleanupCandidate, ...]:
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return ()
    file_manifest = _file_manifest(ctx)
    if file_manifest is None:
        return ()
    session_generation = runtime_lifecycle.generation_token()
    if not session_generation or not runtime_lifecycle.is_current(session_generation):
        return ()
    file_generation = str(file_manifest['file_generation'])
    candidates: list[CleanupCandidate] = []
    artifact_uuids: set[str] = set()

    for collection_name in _SUPPORTED_ID_COLLECTIONS:
        collection = _collection(collection_name)
        if collection is None:
            continue
        try:
            items = tuple(collection)
        except Exception:
            continue
        for id_data in items:
            if _is_default_excluded(id_data):
                continue
            validated = _validate_artifact_manifest(
                id_data,
                collection_name,
                file_generation=file_generation,
                session_generation=session_generation,
            )
            if validated is None:
                continue
            record, payload, source = validated
            artifact_uuid = str(record['artifact_uuid'])
            if artifact_uuid in artifact_uuids:
                # Ambiguous ownership invalidates the complete candidate set.
                return ()
            artifact_uuids.add(artifact_uuid)
            candidates.append(CleanupCandidate(
                artifact_collection=collection_name,
                artifact_name=str(record['artifact_name']),
                artifact_pointer=_as_pointer(id_data),
                artifact_uuid=artifact_uuid,
                source_collection=str(record['source_collection']),
                source_name=str(record['source_name']),
                source_pointer=_as_pointer(source),
                source_uuid=str(record['source_uuid']),
                file_generation=file_generation,
                session_generation=session_generation,
                manifest_json=_canonical_json(record),
                payload_sha256=_payload_sha256(payload),
            ))
    candidates.sort(key=lambda item: (item.artifact_collection, item.artifact_name, item.artifact_uuid))
    return tuple(candidates)


def _revalidate_candidate(context, candidate: CleanupCandidate):
    file_manifest = _file_manifest(context)
    if file_manifest is None or file_manifest.get('file_generation') != candidate.file_generation:
        return None
    if not runtime_lifecycle.is_current(candidate.session_generation):
        return None
    artifact = _resolve_id(candidate.artifact_collection, candidate.artifact_name)
    if artifact is None or _as_pointer(artifact) != candidate.artifact_pointer or _is_default_excluded(artifact):
        return None
    validated = _validate_artifact_manifest(
        artifact,
        candidate.artifact_collection,
        file_generation=candidate.file_generation,
        session_generation=candidate.session_generation,
    )
    if validated is None:
        return None
    record, payload, source = validated
    if _canonical_json(record) != candidate.manifest_json:
        return None
    if _payload_sha256(payload) != candidate.payload_sha256:
        return None
    if _as_pointer(source) != candidate.source_pointer:
        return None
    return artifact


def _restore_journal(entries: tuple[JournalEntry, ...]) -> bool:
    restored = True
    for entry in reversed(entries):
        artifact = _resolve_id(entry.artifact_collection, entry.artifact_name)
        if artifact is None or _as_pointer(artifact) != entry.artifact_pointer:
            restored = False
            continue
        try:
            artifact[PAYLOAD_PROPERTY] = entry.payload
            artifact[ARTIFACT_MANIFEST_PROPERTY] = entry.artifact_manifest
        except Exception:
            restored = False
    return restored


def cleanup_legacy_proxy_data(context=None) -> int:
    """Run one ownership-exact RNA transaction before a normal Blender save."""

    global _LAST_REPORT
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        _LAST_REPORT = {
            'phase': 'cancelled', 'candidate_count': 0, 'committed_count': 0,
            'rolled_back': False, 'error': 'No Blender context',
        }
        return 0

    frozen_candidates = dry_run_candidates(ctx)
    _LAST_REPORT = {
        'phase': 'dry_run',
        'candidate_count': len(frozen_candidates),
        'committed_count': 0,
        'rolled_back': False,
        'error': '',
    }
    if not frozen_candidates:
        _LAST_REPORT['phase'] = 'complete'
        return 0

    resolved = []
    for candidate in frozen_candidates:
        artifact = _revalidate_candidate(ctx, candidate)
        if artifact is None:
            _LAST_REPORT.update({'phase': 'revalidation_failed', 'error': 'Frozen candidate changed before commit'})
            return 0
        resolved.append((candidate, artifact))

    journal: list[JournalEntry] = []
    try:
        for candidate, artifact in resolved:
            # Revalidate immediately before journaling and commit.
            artifact = _revalidate_candidate(ctx, candidate)
            if artifact is None:
                raise RuntimeError('Frozen candidate changed during transaction')
            manifest_snapshot = _plain(artifact[ARTIFACT_MANIFEST_PROPERTY])
            payload_snapshot = _plain(artifact[PAYLOAD_PROPERTY])
            journal.append(JournalEntry(
                artifact_collection=candidate.artifact_collection,
                artifact_name=candidate.artifact_name,
                artifact_pointer=candidate.artifact_pointer,
                artifact_manifest=manifest_snapshot,
                payload=payload_snapshot,
            ))
            del artifact[PAYLOAD_PROPERTY]
            del artifact[ARTIFACT_MANIFEST_PROPERTY]
            if PAYLOAD_PROPERTY in artifact or ARTIFACT_MANIFEST_PROPERTY in artifact:
                raise RuntimeError('Artifact property removal did not commit')
        _LAST_REPORT.update({
            'phase': 'complete',
            'committed_count': len(journal),
            'rolled_back': False,
        })
        return len(journal)
    except Exception as exc:
        rolled_back = _restore_journal(tuple(journal))
        _LAST_REPORT.update({
            'phase': 'rolled_back' if rolled_back else 'rollback_failed',
            'committed_count': 0,
            'rolled_back': rolled_back,
            'error': str(exc),
        })
        if not rolled_back:
            raise RuntimeError(f'Legacy cleanup rollback failed after: {exc}') from exc
        return 0


def cleanup_before_save(context=None) -> int:
    """Explicit pre-save entry point; Blender performs the later file save."""

    return cleanup_legacy_proxy_data(context)


def last_report() -> dict[str, Any]:
    return dict(_LAST_REPORT)


def patch_saved_blend_file(*_args, **_kwargs) -> bool:
    """Retired compatibility API; saved Blend-file bytes are never modified."""

    return False


def cleanup_legacy_proxy_panel_classes(*_args, **_kwargs) -> int:
    """Retired compatibility API; registered Panel classes are never scanned."""

    return 0


def cleanup_stale_smart_node_panel_classes(*_args, **_kwargs) -> int:
    """Retired compatibility API; class-name ownership is never inferred."""

    return 0


def cleanup_visible_legacy_proxy_id_properties(*_args, **_kwargs) -> int:
    """Retired compatibility API; use cleanup_legacy_proxy_data explicitly."""

    return 0


def register() -> None:
    return None


def unregister() -> None:
    return None


def set_enabled(enabled: bool) -> None:
    # Compatibility API only.  Toggling a setting must never scan or mutate data.
    del enabled
    return None
