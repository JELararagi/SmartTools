# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

"""Generation-owned finite lifecycle ledger for Smart Node Suite.

The ledger lives in ``bpy.app.driver_namespace`` so a re-imported package can
invalidate stale modal/draw callbacks and release only the exact callbacks
recorded by the preceding Smart Node generation.  It registers no Blender
handler, timer, message-bus subscription, thread, or polling loop.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any
import uuid

import bpy

_OWNER_UUID = '8a901fb6-03d3-4d4d-a70d-5bf44311e4bc'
_SCHEMA = 1
_SLOT_KEY = '_SMART_NODE_SUITE_RUNTIME_LEDGER_V1'
_HOST_SLOT_KEY = '_smart_node_suite_runtime_ledger_v1'
_MAX_CLEANUPS = 256
_local_token = ''
_fallback_record: dict[str, Any] = {
    'owner_uuid': _OWNER_UUID,
    'schema': _SCHEMA,
    'generation': 0,
    'token': '',
    'active': False,
    'next_cleanup_id': 1,
    'cleanups': [],
}


def _new_record() -> dict[str, Any]:
    return {
        'owner_uuid': _OWNER_UUID,
        'schema': _SCHEMA,
        'generation': 0,
        'token': '',
        'active': False,
        'next_cleanup_id': 1,
        'cleanups': [],
    }


def _namespace():
    try:
        namespace = bpy.app.driver_namespace
        if isinstance(namespace, dict):
            return namespace
    except Exception:
        pass
    return None


def _host_type():
    try:
        return getattr(bpy.types, 'WindowManager', None)
    except Exception:
        return None


def _host_value():
    host = _host_type()
    if host is None:
        return None
    try:
        return vars(host).get(_HOST_SLOT_KEY)
    except Exception:
        try:
            return getattr(host, _HOST_SLOT_KEY, None)
        except Exception:
            return None


def _publish_host_value(value: dict[str, Any]) -> bool:
    host = _host_type()
    if host is None:
        return False
    try:
        setattr(host, _HOST_SLOT_KEY, value)
        return vars(host).get(_HOST_SLOT_KEY) is value
    except Exception:
        return False


def _valid_record(value) -> bool:
    return bool(
        isinstance(value, dict)
        and value.get('owner_uuid') == _OWNER_UUID
        and value.get('schema') == _SCHEMA
        and isinstance(value.get('cleanups'), list)
    )


def _record() -> dict[str, Any]:
    """Return a process-session ledger that survives Blend-file loading."""

    global _fallback_record
    namespace = _namespace()
    host_value = _host_value()
    if _valid_record(host_value):
        if namespace is not None and namespace.get(_SLOT_KEY) is not host_value:
            namespace[_SLOT_KEY] = host_value
        return host_value

    namespace_value = namespace.get(_SLOT_KEY) if namespace is not None else None
    if _valid_record(namespace_value):
        _publish_host_value(namespace_value)
        return namespace_value

    value = _new_record()
    published = _publish_host_value(value)
    if namespace is not None:
        namespace[_SLOT_KEY] = value
    if published or namespace is not None:
        return value
    _fallback_record = value
    return _fallback_record


def _run_cleanup_entries(record: dict[str, Any], entries) -> None:
    for entry in reversed(tuple(entries)):
        callback = entry.get('callback') if isinstance(entry, dict) else None
        if not callable(callback):
            continue
        try:
            callback()
        except Exception:
            pass


def _retire_record(record: dict[str, Any]) -> None:
    entries = tuple(record.get('cleanups', ()))
    record['cleanups'] = []
    record['active'] = False
    _run_cleanup_entries(record, entries)


def _retire_exact_resources(token: str) -> int:
    if not token:
        return 0
    try:
        from . import rna_ownership
        return int(rna_ownership.retire_generation_resources(token))
    except Exception:
        return 0


def begin_generation() -> str:
    """Retire the preceding exact ledger and begin a fresh generation."""

    global _local_token
    record = _record()
    previous_token = str(record.get('token', '') or '')
    _retire_record(record)
    _retire_exact_resources(previous_token)
    generation = max(0, int(record.get('generation', 0))) + 1
    token = f'{generation}:{uuid.uuid4().hex}'
    record.update({
        'generation': generation,
        'token': token,
        'active': True,
        'next_cleanup_id': 1,
        'cleanups': [],
    })
    _local_token = token
    return token


def end_generation(token: str | None = None) -> bool:
    """Release exact current-generation callbacks and invalidate its token."""

    global _local_token
    record = _record()
    expected = str(token or _local_token or '')
    if not expected or not bool(record.get('active')) or str(record.get('token', '')) != expected:
        if _local_token == expected:
            _local_token = ''
        return False
    entries = tuple(record.get('cleanups', ()))
    record['cleanups'] = []
    record['active'] = False
    _run_cleanup_entries(record, entries)
    _retire_exact_resources(expected)
    if _local_token == expected:
        _local_token = ''
    return True


def generation_token() -> str:
    return str(_local_token or _record().get('token', '') or '')


def generation_number() -> int:
    return int(_record().get('generation', 0))


def is_current(token: str) -> bool:
    record = _record()
    return bool(
        token
        and record.get('active')
        and str(record.get('token', '')) == str(token)
    )


def register_cleanup(
    callback: Callable[[], Any],
    *,
    token: str | None = None,
    label: str = '',
) -> int:
    if not callable(callback):
        raise TypeError('cleanup callback must be callable')
    record = _record()
    expected = str(token or _local_token or '')
    if not is_current(expected):
        raise RuntimeError('cleanup registration requires the current generation token')
    cleanup_id = max(1, int(record.get('next_cleanup_id', 1)))
    record['next_cleanup_id'] = cleanup_id + 1
    entries = record.setdefault('cleanups', [])
    entries.append({
        'id': cleanup_id,
        'token': expected,
        'label': str(label or '')[:256],
        'callback': callback,
    })
    if len(entries) > _MAX_CLEANUPS:
        oldest = entries.pop(0)
        _run_cleanup_entries(record, (oldest,))
    return cleanup_id


def unregister_cleanup(
    cleanup_id: int,
    *,
    token: str | None = None,
    run: bool = False,
) -> bool:
    record = _record()
    expected = str(token or _local_token or '')
    entries = record.get('cleanups', [])
    for index, entry in enumerate(tuple(entries)):
        if not isinstance(entry, dict):
            continue
        if int(entry.get('id', -1)) != int(cleanup_id):
            continue
        if str(entry.get('token', '')) != expected:
            return False
        removed = entries.pop(index)
        if run:
            _run_cleanup_entries(record, (removed,))
        return True
    return False


def registered_cleanup_count() -> int:
    record = _record()
    token = str(record.get('token', '') or '')
    return sum(
        1 for entry in record.get('cleanups', ())
        if isinstance(entry, dict) and str(entry.get('token', '')) == token
    )


def runtime_snapshot() -> dict[str, object]:
    record = _record()
    return {
        'owner_uuid': _OWNER_UUID,
        'schema': _SCHEMA,
        'generation': int(record.get('generation', 0)),
        'token': str(record.get('token', '') or ''),
        'active': bool(record.get('active')),
        'cleanup_count': registered_cleanup_count(),
        'cleanup_limit': _MAX_CLEANUPS,
    }
