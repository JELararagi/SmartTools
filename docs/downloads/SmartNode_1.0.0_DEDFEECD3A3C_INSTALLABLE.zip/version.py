# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

ADDON_VERSION = (1, 4, 33)
ADDON_VERSION_STRING = '1.4.33'
SCHEMA_VERSION = 2
