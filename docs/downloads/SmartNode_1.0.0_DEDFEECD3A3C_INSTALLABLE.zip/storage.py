# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from pathlib import Path
import tempfile

try:
    import bpy
except Exception:  # pragma: no cover
    bpy = None


def settings_dir(create: bool = True) -> Path:
    if bpy is not None:
        try:
            path = Path(bpy.utils.user_resource('CONFIG', path='smart_node_suite', create=create))
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
        except Exception:
            pass
    path = Path(tempfile.gettempdir()) / 'smart_node_suite'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def settings_file(name: str, create: bool = True) -> Path:
    safe = ''.join(ch if ch.isalnum() or ch in '._-' else '_' for ch in str(name or 'settings.json'))
    return settings_dir(create=create) / safe


def canonical_settings_dir(create: bool = True) -> Path:
    if bpy is not None:
        try:
            root = Path(bpy.utils.user_resource('CONFIG', create=create))
            path = root / 'Smart_Node_Suite'
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
        except Exception:
            pass
    path = Path(tempfile.gettempdir()) / 'Smart_Node_Suite'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def canonical_settings_file(create: bool = True) -> Path:
    return canonical_settings_dir(create=create) / 'Smart_Node_Suite.json'
