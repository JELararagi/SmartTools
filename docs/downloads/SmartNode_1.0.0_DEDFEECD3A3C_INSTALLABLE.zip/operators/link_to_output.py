# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.node_transactions import link_if_compatible
from ..utils.nodes import (
    force_update,
    get_nodes_links,
    is_visible_socket,
    sns_check,
    sns_check_active,
    sns_check_space_type,
    sns_check_visible_outputs,
)


class SMART_NODE_SUITE_OT_link_to_output(Operator):
    """Link the active node to the group or node-tree output."""

    bl_idname = 'smart_node_suite.link_out'
    bl_label = 'Connect to Output'
    bl_description = _tip(
        'Function: connects the first compatible visible output of the active node to an existing active output node, or creates one when needed. How to use: select the source node and run once; validation occurs before creation so a failed operation leaves no orphan output node.',
        '機能: アクティブノードの最初の互換表示出力を、既存のアクティブ出力ノードへ接続し、必要な場合だけ出力ノードを作成します。使い方: ソースノードを選択して実行します。作成前に検証するため、失敗時に孤立出力ノードを残しません。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            sns_check(cls, context)
            and sns_check_space_type(
                cls, context,
                {'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree', 'GeometryNodeTree'},
            )
            and sns_check_active(cls, context)
            and sns_check_visible_outputs(cls, context)
        )

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        active = nodes.active
        tree_type = context.space_data.tree_type
        shader_outputs = {
            'OBJECT': 'ShaderNodeOutputMaterial',
            'WORLD': 'ShaderNodeOutputWorld',
            'LINESTYLE': 'ShaderNodeOutputLineStyle',
        }
        try:
            output_type = {
                'ShaderNodeTree': shader_outputs[context.space_data.shader_type],
                'CompositorNodeTree': 'NodeGroupOutput',
                'TextureNodeTree': 'TextureNodeOutput',
                'GeometryNodeTree': 'NodeGroupOutput',
            }[tree_type]
        except Exception:
            self.report({'ERROR'}, _tip('No supported output node type is available', '対応する出力ノードタイプがありません'))
            return {'CANCELLED'}

        visible_outputs = [socket for socket in active.outputs if is_visible_socket(socket)]
        if not visible_outputs:
            return {'CANCELLED'}

        output_node = next(
            (
                node for node in nodes
                if node.rna_type.identifier == output_type
                and (node.is_active_output if hasattr(node, 'is_active_output') else True)
            ),
            None,
        )

        source_socket = visible_outputs[0]
        created_output = None
        try:
            if output_node is None:
                created_output = nodes.new(type=output_type)
                output_node = created_output
                output_node.location.x = active.location.x + active.dimensions.x + 80.0
                output_node.location.y = active.location.y

            if tree_type == 'GeometryNodeTree':
                geometry_outputs = [socket for socket in visible_outputs if socket.type == 'GEOMETRY']
                if not geometry_outputs:
                    raise ValueError('The active node has no visible Geometry output')
                source_socket = geometry_outputs[0]
                target_index = 0
            else:
                target_index = 0
                compatible = [
                    socket for socket in visible_outputs
                    if output_node.inputs and socket.type == output_node.inputs[0].type
                ]
                if compatible:
                    source_socket = compatible[0]
                if tree_type == 'ShaderNodeTree':
                    if source_socket.name == 'Volume':
                        target_index = 1
                    elif source_socket.name == 'Displacement':
                        target_index = 2
            if target_index >= len(output_node.inputs):
                raise ValueError('The output node has no compatible input socket')
            link = link_if_compatible(context.space_data.edit_tree, source_socket, output_node.inputs[target_index])
            if link is None:
                raise ValueError('Blender rejected the output link')
        except Exception as exc:
            if created_output is not None:
                try:
                    nodes.remove(created_output)
                except Exception:
                    pass
            self.report({'ERROR'}, _tip('Could not connect to output: {exc}', '出力へ接続できませんでした。').format(exc=exc))
            return {'CANCELLED'}

        force_update(context)
        return {'FINISHED'}
