# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import EnumProperty

from ..i18n import tip as _tip

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_copy_label(Operator, SNSBase):
    bl_idname = "smart_node_suite.copy_label"
    bl_label = "Copy Label"
    bl_options = {'UNDO'}
    bl_description = _tip('Function: copies a chosen label source into selected node labels. How to use: select target nodes, make the source node active when needed, then choose whether to copy from the active node, linked node, or linked socket.', '機能: 選択した取得元の文字列を選択ノードのラベルへコピーします。使い方: 対象ノードを選択し、必要に応じてコピー元をアクティブにして、アクティブノード、リンク元ノード、リンク元ソケットのどれからコピーするか選びます。')

    option: EnumProperty(
        name="Option",
        description=_tip('Function: chooses which text source is copied into selected node labels. How to use: use From Active for the active node label, From Node for the connected node label, or From Socket for the connected socket name.', '機能: 選択ノードのラベルへコピーする文字列の取得元を選びます。使い方: アクティブノードのラベルを使う場合は「アクティブから」、接続元ノードのラベルは「ノードから」、接続元ソケット名は「ソケットから」を使います。'),
        items=(
            ('FROM_ACTIVE', 'From Active', 'From active node',),
            ('FROM_NODE', 'From Node', 'From node linked to selected node'),
            ('FROM_SOCKET', 'From Socket', 'From socket linked to selected node'),
        )
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context, min=2)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        option = self.option
        active = nodes.active
        if option == 'FROM_ACTIVE':
            if active:
                src_label = active.label
                for node in [n for n in nodes if n.select and nodes.active != n]:
                    node.label = src_label
        elif option == 'FROM_NODE':
            selected = [n for n in nodes if n.select]
            for node in selected:
                for input in node.inputs:
                    if input.links:
                        src = input.links[0].from_node
                        node.label = src.label
                        break
        elif option == 'FROM_SOCKET':
            selected = [n for n in nodes if n.select]
            for node in selected:
                for input in node.inputs:
                    if input.links:
                        src = input.links[0].from_socket
                        node.label = src.name
                        break

        return {'FINISHED'}
