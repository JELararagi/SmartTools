# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import FloatProperty

from ..i18n import tip as _tip

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_change_factor(Operator, SNSBase):
    bl_idname = "smart_node_suite.factor"
    bl_label = "Change Factor"
    bl_description = _tip('Function: sets or offsets the factor values of selected Mix and Mix Shader nodes. How to use: select target mix nodes and use the preset factor commands to quickly set 0, set 1, or nudge the current value.', '機能: 選択した ミックス / シェーダーミックスノードの係数値を設定または増減します。使い方: 対象のミックスノードを選択し、プリセット係数コマンドで 0、1、または現在値の微調整を素早く行います。')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    # option: Change factor.
    # If option is 1.0 or 0.0 - set to 1.0 or 0.0
    # Else - change factor by option value.
    option: FloatProperty(
        name='Factor Change',
        description=_tip('Function: sets or offsets the factor value on selected Mix and Mix Shader nodes. How to use: use 0.0 or 1.0 buttons to force a value, or +/- buttons to nudge the current factor.', '機能: 選択した ミックス / シェーダーミックスノードの係数を設定または増減します。使い方: 0.0/1.0 ボタンで値を固定し、+/- ボタンで現在値を少し調整します。'),
    )

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        option = self.option
        selected = []  # entry = index
        for si, node in enumerate(nodes):
            if node.select:
                if node.type in {'MIX_RGB', 'MIX_SHADER'} or node.bl_idname == 'ShaderNodeMix':
                    selected.append(si)

        for si in selected:
            fac = nodes[si].inputs[0]
            nodes[si].hide = False
            if option in {0.0, 1.0}:
                fac.default_value = option
            else:
                fac.default_value += option

        return {'FINISHED'}
