# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, EnumProperty
from bpy_extras.io_utils import ExportHelper
from ..i18n import tip as _tip

from ..utils.nodes import (
    sns_check,
    sns_check_space_type,
    sns_check_viewer_node,
    get_viewer_image,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_save_viewer_image(Operator, ExportHelper):
    """Save the current viewer node to an image file"""
    bl_idname = "smart_node_suite.save_viewer"
    bl_label = "Save Viewer Image"

    filepath: StringProperty(
        name='File Path',
        subtype="FILE_PATH",
        description=_tip('Function: destination path used when saving the current Viewer image. How to use: choose a folder and filename in the file browser before confirming the export.', '機能: 現在のビューアー画像を保存する出力先パスです。使い方: 書き出し確認前にファイルブラウザーでフォルダーとファイル名を選びます。'),
    )
    filename_ext: EnumProperty(
        name="Format",
        description=_tip('Function: chooses the image format used when saving the compositor Viewer output. How to use: choose PNG for general use, EXR/HDR for high dynamic range data, or another format required by your pipeline.', '機能: コンポジターのビューアー出力を保存する画像形式を選びます。使い方: 通常は PNG、高ダイナミックレンジデータは EXR/HDR、パイプラインで指定がある場合はその形式を選びます。'),
        items=(
            ('.bmp', "BMP", ""),
            ('.rgb', 'IRIS', ""),
            ('.png', 'PNG', ""),
            ('.jpg', 'JPEG', ""),
            ('.jp2', 'JPEG2000', ""),
            ('.tga', 'TARGA', ""),
            ('.cin', 'CINEON', ""),
            ('.dpx', 'DPX', ""),
            ('.exr', 'OPEN_EXR', ""),
            ('.hdr', 'HDR', ""),
            ('.tif', 'TIFF', ""),
            ('.webp', 'WEBP', ""),
        ),
        default='.png',
    )

    @classmethod
    def poll(cls, context):
        return (sns_check(cls, context)
                and sns_check_space_type(cls, context, {'CompositorNodeTree'})
                and sns_check_viewer_node(cls))

    def execute(self, context):
        fp = self.filepath
        if not fp:
            return {'CANCELLED'}

        formats = {
            '.bmp': 'BMP',
            '.rgb': 'IRIS',
            '.png': 'PNG',
            '.jpg': 'JPEG',
            '.jpeg': 'JPEG',
            '.jp2': 'JPEG2000',
            '.tga': 'TARGA',
            '.cin': 'CINEON',
            '.dpx': 'DPX',
            '.exr': 'OPEN_EXR',
            '.hdr': 'HDR',
            '.tiff': 'TIFF',
            '.tif': 'TIFF',
            '.webp': 'WEBP',
        }
        image_settings = context.scene.render.image_settings
        old_media_type = image_settings.media_type
        old_file_format = image_settings.file_format
        image_settings.media_type = 'IMAGE'
        image_settings.file_format = formats[self.filename_ext]

        try:
            get_viewer_image().save_render(fp)
        except RuntimeError as e:
            self.report({'ERROR'}, _tip("Could not write image: {}", "画像を書き込めませんでした: {}").format(e))

        image_settings.media_type = old_media_type
        image_settings.file_format = old_file_format
        return {'FINISHED'}
