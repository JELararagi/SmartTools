# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from bpy.props import StringProperty
from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_space_type


class SMART_NODE_SUITE_OT_add_attribute_node(Operator, SNSBase):
    """Add an Attribute node with this name."""

    bl_idname = 'smart_node_suite.add_attr_node'
    bl_label = 'Add Attribute'
    bl_description = _tip(
        'Function: creates a Shader Attribute node and assigns the requested attribute name. How to use: choose an attribute from Smart Node; the node is placed at the Node Editor cursor and the complete change is one Undo step.',
        '機能: シェーダーの属性ノードを作成し、指定した属性名を設定します。使い方: Smart Node から属性を選ぶと、ノードエディターカーソル位置へ追加され、変更全体が 1 回の Undo になります。',
    )
    bl_options = {'UNDO'}

    attr_name: StringProperty(
        name='Attribute Name',
        description=_tip(
            'Function: sets the attribute name assigned to the new Attribute node. How to use: choose an entry from the Attribute menu, or type the geometry/color attribute name you want the shader to read.',
            '機能: 新しく作成する 属性ノードに設定する属性名です。使い方: 属性メニューから項目を選ぶか、シェーダーで読みたいジオメトリ/カラー属性名を入力します。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(cls, context, {'ShaderNodeTree'})

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        previous_selection = {node.name for node in nodes if node.select}
        previous_active = getattr(nodes.active, 'name', '') if nodes.active else ''
        node = None
        try:
            for candidate in nodes:
                candidate.select = False
            node = nodes.new(type='ShaderNodeAttribute')
            node.attribute_name = str(self.attr_name or '')
            try:
                cursor = context.space_data.cursor_location
                node.location = cursor
            except Exception:
                pass
            node.select = True
            nodes.active = node
        except Exception as exc:
            if node is not None:
                try:
                    nodes.remove(node)
                except Exception:
                    pass
            for candidate in nodes:
                candidate.select = candidate.name in previous_selection
            try:
                nodes.active = nodes.get(previous_active)
            except Exception:
                pass
            self.report({'ERROR'}, _tip('Could not add Attribute node: {exc}', '属性ノードを追加できませんでした。').format(exc=exc))
            return {'CANCELLED'}
        return {'FINISHED'}
