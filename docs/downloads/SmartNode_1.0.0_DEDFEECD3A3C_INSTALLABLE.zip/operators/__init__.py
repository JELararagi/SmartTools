# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy

from .. import rna_ownership

from .add_attribute_node import *
from .add_image_sequence import *
from .add_principled_setup import *
from .add_reroutes import *
from .add_texture_setup import *
from .align_selected import *
from .batch_change import *
from .center_selected import *
from .change_factor import *
from .copy_label import *
from .copy_settings import *
from .delete_unused import *
from .detach_outputs import *
from .labels_clear import *
from .labels_modify import *
from .lazy_connect import *
from .lazy_mix import *
from .link_active_to_selected import *
from .link_to_output import *
from .merge_selected import *
from .reload_images import *
from .reset_backdrop import *
from .reset_selected import *
from .save_viewer_image import *
from .select_hierarchy import *
from .swap_links import *
from .node_layout_tools import *
from .node_view_tools import *


#### ------------------------------ REGISTRATION ------------------------------ ####

classes = (
    SMART_NODE_SUITE_OT_add_attribute_node,
    SMART_NODE_SUITE_OT_add_image_sequence,
    SMART_NODE_SUITE_OT_add_principled_setup,
    SMART_NODE_SUITE_OT_add_reroutes,
    SMART_NODE_SUITE_OT_add_texture_setup,
    SMART_NODE_SUITE_OT_align_selected,
    SMART_NODE_SUITE_OT_batch_change,
    SMART_NODE_SUITE_OT_center_selected,
    SMART_NODE_SUITE_OT_change_factor,
    SMART_NODE_SUITE_OT_copy_label,
    SMART_NODE_SUITE_OT_copy_settings,
    SMART_NODE_SUITE_OT_delete_unused,
    SMART_NODE_SUITE_OT_detach_outputs,
    SMART_NODE_SUITE_OT_labels_clear,
    SMART_NODE_SUITE_OT_labels_modify,
    SMART_NODE_SUITE_OT_lazy_connect,
    SMART_NODE_SUITE_OT_lazy_mix,
    SMART_NODE_SUITE_OT_link_active_to_selected,
    SMART_NODE_SUITE_OT_link_to_output,
    SMART_NODE_SUITE_OT_merge_selected,
    SMART_NODE_SUITE_OT_reload_images,
    SMART_NODE_SUITE_OT_reset_backdrop,
    SMART_NODE_SUITE_OT_reset_selected,
    SMART_NODE_SUITE_OT_save_viewer_image,
    SMART_NODE_SUITE_OT_select_hierarchy,
    SMART_NODE_SUITE_OT_swap_links,
    SMART_NODE_SUITE_OT_node_view_settings,

    SMART_NODE_SUITE_OT_layout_hierarchy,
    SMART_NODE_SUITE_OT_arrange_children,
    SMART_NODE_SUITE_OT_arrange_selected,
    SMART_NODE_SUITE_OT_sort_nodes,
    SMART_NODE_SUITE_OT_lay_out_all,
    SMART_NODE_SUITE_OT_align_edges,
    SMART_NODE_SUITE_OT_distribute_nodes,
    SMART_NODE_SUITE_OT_distribute_grid,
    SMART_NODE_SUITE_OT_snap_to_grid,
    SMART_NODE_SUITE_OT_stream_aware_align,
    SMART_NODE_SUITE_OT_stack_nodes,
    SMART_NODE_SUITE_OT_offset_branch,
    SMART_NODE_SUITE_OT_hide_child_tree,
    SMART_NODE_SUITE_OT_hide_unused_sockets,
    SMART_NODE_SUITE_OT_color_nodes,
    SMART_NODE_SUITE_OT_swap_node_positions,
    SMART_NODE_SUITE_OT_optimize_reroute_links,
    SMART_NODE_SUITE_OT_bypass_delete_nodes,
    SMART_NODE_SUITE_OT_free_from_frame,
    SMART_NODE_SUITE_OT_select_material_users,
    SMART_NODE_SUITE_OT_select_linked_branch,
    SMART_NODE_SUITE_OT_select_terminal_nodes,
    SMART_NODE_SUITE_OT_select_same_type,
    SMART_NODE_SUITE_OT_frame_branch,
    SMART_NODE_SUITE_OT_collapse_expand_nodes,
    SMART_NODE_SUITE_OT_mute_unmute_nodes,
    SMART_NODE_SUITE_OT_select_by_text,
    SMART_NODE_SUITE_OT_select_graph_state,
    SMART_NODE_SUITE_OT_rename_selected_nodes,

    SMART_NODE_SUITE_OT_lazy_connect_call_inputs_menu,
    SMART_NODE_SUITE_OT_lazy_connect_make_link,

    SMART_NODE_SUITE_MT_lazy_connect_outputs,
    SMART_NODE_SUITE_MT_lazy_connect_inputs,
)


_OPERATOR_TOOLTIPS = {
    'smart_node_suite.add_attr_node': 'Function: creates an Attribute node for a material attribute used by the active object material. How to use: choose an attribute from the Add > Input menu or Smart Node attribute list; the new node is added to the editable shader tree.',
    'smart_node_suite.add_sequence': 'Function: imports an image sequence as an image node. How to use: choose the first file in the sequence, set relative-path and start-frame options, then confirm to create a linked image sequence node.',
    'smart_node_suite.add_textures_for_principled': 'Function: scans selected texture files and builds a Principled BSDF texture network automatically. How to use: select image maps with recognizable names such as base color, roughness, normal, or displacement, then confirm the file browser.',
    'smart_node_suite.add_reroutes': 'Function: inserts reroute nodes on selected node outputs to make long noodle links easier to read. How to use: select one or more nodes and choose whether reroutes are added to all, loose, or linked outputs.',
    'smart_node_suite.add_texture': 'Function: adds a texture-coordinate, mapping, and image-texture setup for selected shader nodes. How to use: select shader nodes that need texture inputs, then run the command and adjust mapping nodes as needed.',
    'smart_node_suite.align_nodes': 'Function: aligns selected nodes using the original Smart Node Suite quick alignment behavior. How to use: select nodes in the Node Editor and run the command to straighten their placement with the configured margin.',
    'smart_node_suite.batch_change': 'Function: changes blend modes or math operations on multiple selected nodes at once. How to use: select Mix or Math nodes, choose a target operation from the Batch Change menu, and the compatible nodes update together.',
    'smart_node_suite.center_nodes': 'Function: moves the center of the selected nodes to the center of the current node-editor view. How to use: select a node group and press the button when you want the selection in the middle of the screen.',
    'smart_node_suite.factor': 'Function: adjusts mix factors on selected Mix and Mix Shader nodes. How to use: use the assigned hotkeys to increase, decrease, or set factors without opening each node manually.',
    'smart_node_suite.copy_label': 'Function: copies a label source to selected nodes. How to use: make one node active, select target nodes, and choose whether to copy from the active label, linked node label, or linked output name.',
    'smart_node_suite.copy_settings': 'Function: copies editable settings from the active node to compatible selected nodes. How to use: select the source node last so it is active, select target nodes of the same type, then run this command.',
    'smart_node_suite.del_unused': 'Function: removes unused nodes and empty frames, and bypasses muted nodes. How to use: press the button after material or compositor cleanup and confirm. All changes are one Undo step.',
    'smart_node_suite.detach_outputs': 'Function: detaches outgoing links from selected nodes while keeping the nodes themselves. How to use: select nodes whose outputs should be disconnected, then run the command before rebuilding links.',
    'smart_node_suite.clear_label': 'Function: clears labels on selected nodes. How to use: select nodes with custom labels and run this command; use the option property when a menu or hotkey supplies a specific clear mode.',
    'smart_node_suite.modify_labels': 'Function: batch-edits selected node labels with prefix, suffix, and replace text fields. How to use: select labeled nodes, run the command, enter the text changes, and confirm.',
    'smart_node_suite.lazy_connect': 'Function: connects nodes by drawing a temporary line instead of manually dragging individual sockets. How to use: start the hotkey gesture over a source node and finish over a target node; enable the socket menu when you need a specific socket.',
    'smart_node_suite.lazy_mix': 'Function: quickly creates a mix operation by gesture between nodes. How to use: trigger the lazy mix hotkey in the Node Editor and connect the chosen nodes to create the appropriate mix setup.',
    'smart_node_suite.link_active_to_selected': 'Function: links the active node to selected nodes using socket names, node names, or compatible sockets. How to use: select target nodes first, select the source node last as active, then choose the desired linking mode.',
    'smart_node_suite.link_out': 'Function: connects the active node to the appropriate output node. How to use: select the node you want to preview or output, then run this command to create or reuse the needed output connection.',
    'smart_node_suite.merge_nodes': 'Function: inserts Mix, Math, Shader, Geometry, Alpha Over, or Depth Combine nodes between selected nodes. How to use: select two or more nodes in the order you want to combine, then choose the merge mode from the Smart Node menu.',
    'smart_node_suite.reload_images': 'Function: reloads image data used by image nodes so external file changes appear in Blender. How to use: run it after editing texture files on disk or when image nodes show stale content.',
    'smart_node_suite.bg_reset': 'Function: resets the compositor backdrop view. How to use: run this in a Compositor node tree when the backdrop zoom or pan no longer matches the working area.',
    'smart_node_suite.reset_nodes': 'Function: resets selected nodes to clean default node instances while preserving practical placement and links where possible. How to use: select one resettable node or a frame and run the command from the active-node panel or menu.',
    'smart_node_suite.save_viewer': 'Function: saves the current compositor Viewer image to disk. How to use: make a Viewer node active in the Compositor, run this command, choose the format and file path, then confirm.',
    'smart_node_suite.select_parent_child': 'Function: selects a selected frame node’s children or a selected node’s parent frame. How to use: use this for frame-based organization before moving, deleting, or relabeling framed node groups.',
    'smart_node_suite.swap_links': 'Function: swaps input or output links on selected compatible nodes to change wiring order quickly. How to use: select nodes with multiple links and run this command instead of manually reconnecting sockets.',
    'smart_node_suite.lazy_connect_call_inputs_menu': 'Function: opens the Lazy Connect input socket menu. How to use: this is normally called internally by Lazy Connect when multiple target sockets are available.',
    'smart_node_suite.lazy_connect_make_link': 'Function: creates the Lazy Connect link chosen from the socket menu. How to use: this is normally executed from the Lazy Connect popup and does not need manual operation.',
    'smart_node_suite.node_view_settings': 'Function: applies, reads, resets, or presets node-editor visual settings including grid color, background color, grid levels, wire colors, and noodle curvature. How to use: adjust Smart Node view settings in the N-panel, then apply them to the active Blender theme.',
    'smart_node_suite.select_by_text': 'Function: selects nodes by name, label, type, or socket text. How to use: press the button, enter search text in the dialog, choose Target, and confirm with OK to isolate nodes in large graphs.',
    'smart_node_suite.select_graph_state': 'Function: selects nodes by graph-management state such as unconnected, muted, collapsed, framed, unframed, or reroute. How to use: choose a state before cleanup, layout, or relabeling.',
    'smart_node_suite.rename_selected_nodes': 'Function: renames selected nodes and optional visible labels in a single pass. How to use: press the button, set a new name, prefix, suffix, find/replace, or numbering in the dialog, then confirm with OK.',
    'smart_node_suite.stream_aware_align': 'Function: aligns nodes per connected stream rather than forcing unrelated branches onto one global line. How to use: select branch nodes and press the button. Vertical centers are aligned inside each stream.',
    'smart_node_suite.stack_nodes': 'Function: stacks selected nodes into a clean column from top to bottom. How to use: select loose nodes and press the button.',
    'smart_node_suite.offset_branch': 'Function: moves the selected nodes and every node connected to them a fixed distance to the right (160), similar to Move Children workflows. How to use: select a seed node and press the button.',
    'smart_node_suite.hide_child_tree': 'Function: switches the input-side (upstream) nodes of the selected parent node between collapsed and expanded. How to use: select a parent/output/material node and press the button. Press it again to switch back.',
    'smart_node_suite.hide_unused_sockets': 'Function: switches unused input/output sockets on selected nodes between hidden and shown. If nothing is selected, all nodes are changed. How to use: use it to simplify dense node cards while keeping connected sockets visible.',
    'smart_node_suite.color_nodes': 'Function: gives the selected nodes one shared marker color (blue), or removes it with Reset Color. If nothing is selected, all nodes are changed. It does not color nodes by type. How to use: select the nodes of one role and press the button. Use Color 1 to Color 5 in Node Color Presets for other colors.',
    'smart_node_suite.swap_node_positions': 'Function: swaps the editor positions of exactly two selected nodes. How to use: select two nodes and run it to exchange placement without changing links.',
    'smart_node_suite.optimize_reroute_links': 'Function: inserts reroute nodes into selected links for cleaner wire paths. How to use: select nodes around messy links and run local optimization before adjusting reroutes manually.',
    'smart_node_suite.bypass_delete_nodes': 'Function: deletes selected nodes while reconnecting compatible input and output links where possible. How to use: select utility nodes in a chain and run this command instead of plain delete.',
    'smart_node_suite.free_from_frame': 'Function: removes selected nodes from parent frames while keeping absolute positions. How to use: select framed nodes before reorganizing or deleting a frame/backdrop.',
    'smart_node_suite.select_material_users': 'Function: selects scene objects that use the material currently edited in the Shader Node Editor. How to use: open a material node tree and press the button to audit material assignments. Hidden objects are not selected.',
}

_OPERATOR_TOOLTIPS_JA = {
    'smart_node_suite.add_attr_node': '機能: アクティブオブジェクトのマテリアルで使う属性ノードを作成します。使い方: 追加メニューまたは Smart Node の属性リストから属性を選ぶと、編集可能なシェーダーツリーに新しいノードが追加されます。',
    'smart_node_suite.add_sequence': '機能: 画像シーケンスを画像ノードとして読み込みます。使い方: シーケンスの最初のファイルを選択し、相対パスと開始フレームを設定して確定します。',
    'smart_node_suite.add_textures_for_principled': '機能: 選択したテクスチャファイルを解析し、Principled BSDF 用のテクスチャネットワークを自動構築します。使い方: base color、roughness、normal、displacement など識別しやすい名前の画像を選択して確定します。',
    'smart_node_suite.add_reroutes': '機能: 選択ノードの出力にリルートノードを挿入し、長いリンクを読みやすくします。使い方: ノードを選択し、すべて、未接続、接続済みのどの出力に追加するかを選びます。',
    'smart_node_suite.add_texture': '機能: 選択したシェーダーノードへテクスチャ座標、マッピング、画像テクスチャ構成を追加します。使い方: テクスチャ入力が必要なシェーダーノードを選択して実行し、必要に応じてマッピングを調整します。',
    'smart_node_suite.align_nodes': '機能: Smart Node Suite の従来クイック整列で選択ノードをそろえます。使い方: ノードエディターでノードを選択し、設定済みの余白で配置を整えます。',
    'smart_node_suite.batch_change': '機能: 複数の選択ノードのブレンドモードや数式演算をまとめて変更します。使い方: ミックスまたは数式ノードを選択し、一括変更メニューから変更先を選びます。',
    'smart_node_suite.center_nodes': '機能: 選択ノードのまとまりの中心を、今のノードエディター表示の中央へ移動します。使い方: ノード群を選択し、画面の真ん中に寄せたい時に押します。',
    'smart_node_suite.factor': '機能: 選択した ミックス / シェーダーミックスノードの係数を調整します。使い方: ホットキーで係数を増減または指定値へ設定し、各ノードを個別に開かず調整します。',
    'smart_node_suite.copy_label': '機能: ラベル元の情報を選択ノードへコピーします。使い方: コピー元をアクティブにし、対象ノードを選択して、アクティブラベル、リンク元ノード、リンク元出力名のどれを使うか選びます。',
    'smart_node_suite.copy_settings': '機能: アクティブノードの編集可能設定を互換性のある選択ノードへコピーします。使い方: ソースノードを最後に選んでアクティブにし、同タイプの対象ノードへ実行します。',
    'smart_node_suite.del_unused': '機能: 未使用ノードと空フレームを削除し、ミュートノードをバイパスして整理します。使い方: マテリアルやコンポジターの整理後に押して確定します。変更全体が 1 回の Undo です。',
    'smart_node_suite.detach_outputs': '機能: 選択ノード自体は残したまま、出力リンクを切り離します。使い方: 出力接続を作り直したいノードを選択して実行します。',
    'smart_node_suite.clear_label': '機能: 選択ノードのラベルをクリアします。使い方: カスタムラベル付きノードを選択して実行します。メニューやホットキーから特定のクリアモードを渡す場合があります。',
    'smart_node_suite.modify_labels': '機能: 選択ノードのラベルに接頭辞、接尾辞、置換テキストを一括適用します。使い方: ラベル付きノードを選択し、変更内容を入力して確定します。',
    'smart_node_suite.lazy_connect': '機能: 個別ソケットを手動ドラッグせず、一時ライン操作でノード同士を接続します。使い方: ソースノード上でホットキー操作を開始し、ターゲットノード上で終了します。必要に応じてソケットメニューを使います。',
    'smart_node_suite.lazy_mix': '機能: ジェスチャー操作でノード間にミックス処理を素早く作成します。使い方: ノードエディターで 簡単ミックスのホットキーを使い、対象ノードを接続して適切なミックス構成を作ります。',
    'smart_node_suite.link_active_to_selected': '機能: アクティブノードを選択ノードへ、ソケット名、ノード名、互換ソケットを使ってリンクします。使い方: 対象ノードを先に選択し、ソースノードを最後に選んで実行します。',
    'smart_node_suite.link_out': '機能: アクティブノードを適切な出力ノードへ接続します。使い方: プレビューまたは出力したいノードを選択し、必要な出力接続を作成または再利用します。',
    'smart_node_suite.merge_nodes': '機能: 選択ノード間に ミックス、数式、シェーダー、ジオメトリ、アルファオーバー、深度で合成 などの結合ノードを挿入します。使い方: 結合したい順に2つ以上のノードを選択し、Smart Node メニューから結合モードを選びます。',
    'smart_node_suite.reload_images': '機能: 画像ノードが参照する画像データを再読み込みし、外部ファイルの変更を Blender に反映します。使い方: ディスク上のテクスチャを編集した後や表示が古い時に実行します。',
    'smart_node_suite.bg_reset': '機能: コンポジターの背景表示をリセットします。使い方: 背景画像のズームやパンが作業領域と合わなくなった時に実行します。',
    'smart_node_suite.reset_nodes': '機能: 選択ノードをクリーンな初期ノードへ戻し、可能な範囲で位置やリンクを保持します。使い方: リセット可能なノード1つまたはフレームを選択し、アクティブノードパネルやメニューから実行します。',
    'smart_node_suite.save_viewer': '機能: コンポジターのビューアー画像をディスクへ保存します。使い方: コンポジターでビューアーノードをアクティブにし、形式と保存先を選んで確定します。',
    'smart_node_suite.select_parent_child': '機能: 選択フレーム内の子ノード、または選択ノードの親フレームを選択します。使い方: フレーム単位で移動、削除、ラベル変更する前の整理に使います。',
    'smart_node_suite.swap_links': '機能: 互換性のある選択ノードの入力または出力リンクを入れ替え、配線順を素早く変更します。使い方: 複数リンクを持つノードを選択し、手動でつなぎ直す代わりに実行します。',
    'smart_node_suite.lazy_connect_call_inputs_menu': '機能: 簡単コネクトの入力ソケットメニューを開きます。使い方: 複数のターゲットソケットがある時に通常は内部から呼び出されます。',
    'smart_node_suite.lazy_connect_make_link': '機能: ソケットメニューで選んだ簡単コネクトのリンクを作成します。使い方: 通常は簡単コネクトのポップアップから実行され、手動操作は不要です。',
    'smart_node_suite.node_view_settings': '機能: グリッドカラー、背景色、グリッドレベル、ワイヤカラー、リンク曲線など、ノードエディター表示設定を適用、読み込み、リセット、プリセット化します。使い方: Nパネルの Smart Node 表示設定を調整して、アクティブな Blender テーマへ適用します。',
    'smart_node_suite.select_by_text': '機能: ノード名、ラベル、タイプ、ソケット名でノードを選択します。使い方: 押すと開く画面で検索文字を入れ、「ターゲット」を選んで OK を押すと、大きなグラフ内のノードを絞り込めます。',
    'smart_node_suite.select_graph_state': '機能: 未接続、ミュート、折りたたみ、フレーム内外、リルートなどの管理状態でノードを選択します。使い方: クリーンアップ、整列、リネーム前の抽出に使います。',
    'smart_node_suite.rename_selected_nodes': '機能: 選択ノード名と必要に応じて表示ラベルを一括リネームします。使い方: 押すと開く画面で、新規名、接頭辞、接尾辞、検索/置換、連番を設定して OK を押します。',
    'smart_node_suite.stream_aware_align': '機能: 関係のないブランチを1本の基準線へ押し込まず、接続ストリームごとに整列します。使い方: ブランチノードを選択して押します。流れごとに縦の中心をそろえます。',
    'smart_node_suite.stack_nodes': '機能: 選択ノードを上から下へきれいな縦列に積み直します。使い方: 散らばったノードを選択して押します。',
    'smart_node_suite.offset_branch': '機能: 選択ノードとつながるノード全部を、決まった距離（160）だけ右へ移動します。使い方: 起点ノードを選択して押します。',
    'smart_node_suite.hide_child_tree': '機能: 選択した親ノードの入力側（上流）のノードの、折りたたみと展開を切り替えます。使い方: 親、出力、マテリアル相当のノードを選択して押します。もう一度押すと元に戻ります。',
    'smart_node_suite.hide_unused_sockets': '機能: 選択ノードの未使用の入力/出力ソケットの、表示と非表示を切り替えます。何も選んでいない時は全ノードが対象です。使い方: 接続済みソケットを残したまま密なノードカードを簡略化します。',
    'smart_node_suite.color_nodes': '機能: 選択ノードを同じ 1 色（青）の目印にします。「色をリセット」で色を外します。何も選んでいない時は全ノードが対象です。種類ごとの色分けはしません。使い方: 役割ごとにノードを選んで押します。別の色は「ノード色プリセット」の「色 1」〜「色 5」で付けます。',
    'smart_node_suite.swap_node_positions': '機能: 選択した2つのノードのエディター位置を交換します。使い方: 2つのノードを選択して実行し、リンクを変えず配置だけ入れ替えます。',
    'smart_node_suite.optimize_reroute_links': '機能: 選択周辺のリンクへリルートノードを挿入し、ワイヤ経路を整理しやすくします。使い方: 散らかったリンク周辺のノードを選び、局所最適化してから手動で微調整します。',
    'smart_node_suite.bypass_delete_nodes': '機能: 選択ノードを削除しつつ、互換性のある入力/出力リンクを可能な範囲で再接続します。使い方: チェーン内のユーティリティノードを通常削除の代わりにバイパス削除します。',
    'smart_node_suite.free_from_frame': '機能: 選択ノードを親フレームから外し、絶対位置を維持します。使い方: フレーム/バックドロップの整理や削除前にフレーム内ノードを選択して実行します。',
    'smart_node_suite.select_material_users': '機能: シェーダーエディターで編集中のマテリアルを使うシーンオブジェクトを選択します。使い方: マテリアルノードツリーを開いて押し、マテリアル割り当ての確認に使います。非表示のオブジェクトは選びません。',
}


def _apply_operator_tooltips() -> None:
    from ..i18n import t
    for cls in classes:
        identifier = str(getattr(cls, 'bl_idname', '') or '')
        desc = _OPERATOR_TOOLTIPS.get(identifier)
        if desc:
            try:
                cls.bl_description = t(desc, _OPERATOR_TOOLTIPS_JA.get(identifier))
            except Exception:
                pass


_registered_class_tokens = []


def register():
    _apply_operator_tooltips()
    if _registered_class_tokens:
        return
    _registered_class_tokens.extend(rna_ownership.register_classes(classes))


def unregister():
    rna_ownership.unregister_classes(_registered_class_tokens)
