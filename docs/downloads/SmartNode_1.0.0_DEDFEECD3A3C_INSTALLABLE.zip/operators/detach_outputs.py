# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_selected


def _link_exists(links, from_socket, to_socket) -> bool:
    for link in tuple(links):
        if link.from_socket == from_socket and link.to_socket == to_socket:
            return True
    return False


def _restore_removed_links(links, records) -> bool:
    """Restore the exact local journal and verify every endpoint."""

    # Remove only links created by an earlier failed restoration attempt.
    for from_socket, to_socket in records:
        for link in tuple(links):
            if link.from_socket == from_socket and link.to_socket == to_socket:
                try:
                    links.remove(link)
                except Exception:
                    return False
    try:
        for from_socket, to_socket in records:
            links.new(from_socket, to_socket)
    except Exception:
        return False
    return all(_link_exists(links, source, target) for source, target in records)


class SMART_NODE_SUITE_OT_detach_outputs(Operator, SNSBase):
    """Detach outgoing links while preserving nodes and their input links."""

    bl_idname = 'smart_node_suite.detach_outputs'
    bl_label = 'Detach Outputs'
    bl_description = _tip(
        'Function: removes outgoing links from selected nodes while preserving the nodes, their locations, and all incoming links. How to use: select nodes whose downstream connections should be detached, then run once; no nested move operator or second Undo step is created.',
        '機能: 選択ノード本体・位置・入力リンクを維持したまま、出力リンクだけを切り離します。使い方: 下流接続を外したいノードを選択して実行します。入れ子の移動処理や 2 回目の Undo は作成されません。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        _nodes, links = get_nodes_links(context)
        selected = set(context.selected_nodes)
        outgoing = tuple(link for link in tuple(links) if link.from_node in selected)
        if not outgoing:
            self.report({'INFO'}, _tip('No output links to detach', '切り離す出力リンクがありません'))
            return {'CANCELLED'}

        # Socket references live only for this operator call and identify the exact
        # links removed by the transaction. No module cache retains RNA objects.
        journal = tuple((link.from_socket, link.to_socket) for link in outgoing)
        removed_count = 0
        try:
            for link in outgoing:
                links.remove(link)
                removed_count += 1
            if any(_link_exists(links, source, target) for source, target in journal):
                raise RuntimeError('one or more output links remained attached')
        except Exception as exc:
            removed_journal = journal[:removed_count]
            restored = _restore_removed_links(links, removed_journal)
            if not restored:
                # One immediate bounded retry handles transient RNA ordering without
                # installing a timer or background retry path.
                restored = _restore_removed_links(links, removed_journal)
            if not restored:
                raise RuntimeError(f'Detach Outputs rollback failed after: {exc}') from exc
            self.report({'ERROR'}, _tip('Could not detach outputs; all removed links were restored: {exc}', '出力を切り離せませんでした。削除したリンクはすべて復元しました。').format(exc=exc))
            return {'CANCELLED'}
        return {'FINISHED'}
