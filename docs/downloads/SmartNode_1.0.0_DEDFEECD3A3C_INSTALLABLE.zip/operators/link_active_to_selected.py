# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import BoolProperty
from bpy_extras.node_utils import connect_sockets

from ..i18n import tip as _tip

from ..utils.constants import (
    rl_outputs,
)
from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_active,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_link_active_to_selected(Operator, SNSBase):
    """Link active node to selected nodes basing on various criteria"""
    bl_idname = "smart_node_suite.link_active_to_selected"
    bl_label = "Link Active Node to Selected"
    bl_options = {'UNDO'}

    replace: BoolProperty(
        name='Replace Existing Links',
        description=_tip('Function: allows Smart Node to replace existing input links on selected target nodes. How to use: enable when the active node should override current connections; disable to fill only empty compatible inputs.', '機能: 選択ターゲットノードの既存入力リンクを置き換えるか制御します。使い方: アクティブノードで現在の接続を上書きする場合は有効、空き入力だけ埋める場合は無効にします。'),
    )
    use_node_name: BoolProperty(
        name='Match by Node Name',
        description=_tip('Function: links only targets whose name or label matches the active node name or label. How to use: enable for name-based batch linking in large shader or compositor graphs.', '機能: アクティブノードの名前またはラベルに一致するターゲットだけをリンクします。使い方: 大きなシェーダー/コンポジターグラフで名前ベースの一括接続を行う場合に有効にします。'),
    )
    use_outputs_names: BoolProperty(
        name='Match by Output Name',
        description=_tip('Function: links only targets whose name or label matches an output socket name on the active node. How to use: enable when connecting render-layer passes or named outputs to matching nodes.', '機能: アクティブノードの出力ソケット名に一致するターゲットだけをリンクします。使い方: レンダーレイヤーパスや名前付き出力を対応するノードへ接続する場合に有効にします。'),
    )

    @classmethod
    def poll(cls, context):
        return (sns_check(cls, context)
                and sns_check_active(cls, context)
                and sns_check_selected(cls, context, min=2))

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        replace = self.replace
        use_node_name = self.use_node_name
        use_outputs_names = self.use_outputs_names
        active = nodes.active
        selected = [node for node in nodes if node.select and node != active]
        outputs = []  # Only usable outputs of active nodes will be stored here.
        for out in active.outputs:
            if active.type != 'R_LAYERS':
                outputs.append(out)
            else:
                # 'R_LAYERS' node type needs special handling.
                # outputs of 'R_LAYERS' are callable even if not seen in UI.
                # Only outputs that represent used passes should be taken into account
                # Check if pass represented by output is used.
                # global 'rl_outputs' list will be used for that
                for rlo in rl_outputs:
                    pass_used = False  # initial value. Will be set to True if pass is used
                    if out.name == 'Alpha':
                        # Alpha output is always present. Doesn't have representation in render pass. Assume it's used.
                        pass_used = True
                    elif out.name in {rlo.output_name, rlo.exr_output_name}:
                        # example 'render_pass' entry: 'use_pass_uv' Check if True in scene render layers
                        pass_used = getattr(active.scene.view_layers[active.layer], rlo.render_pass)
                        break
                if pass_used:
                    outputs.append(out)
        doit = True  # Will be changed to False when links successfully added to previous output.
        for out in outputs:
            if doit:
                for node in selected:
                    dst_name = node.name  # Will be compared with src_name if needed.
                    # When node has label - use it as dst_name
                    if node.label:
                        dst_name = node.label
                    valid = True  # Initial value. Will be changed to False if names don't match.
                    src_name = dst_name  # If names not used - this assignment will keep valid = True.
                    if use_node_name:
                        # Set src_name to source node name or label
                        src_name = active.name
                        if active.label:
                            src_name = active.label
                    elif use_outputs_names:
                        src_name = (out.name, )
                        for rlo in rl_outputs:
                            if out.name in {rlo.output_name, rlo.exr_output_name}:
                                src_name = (rlo.output_name, rlo.exr_output_name)
                    if dst_name not in src_name:
                        valid = False
                    if valid:
                        for input in node.inputs:
                            if input.type == out.type or node.type == 'REROUTE':
                                if replace or not input.is_linked:
                                    connect_sockets(out, input)
                                    if not use_node_name and not use_outputs_names:
                                        doit = False
                                    break

        return {'FINISHED'}
