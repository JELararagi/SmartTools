# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from collections import defaultdict, deque
from math import ceil, sqrt

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty
from bpy.types import Operator
from mathutils import Vector

from ..i18n import t as _t, tip as _tip
from ..utils.nodes import get_nodes_links, sns_check, sns_check_not_empty, abs_node_location
from ..utils.layout_grid import axis_advance, major_grid_size, snap_aligned_nodes_to_major_grid, snap_nodes_to_major_grid, use_major_grid_spacing


_DIRECTIONS = (
    ('LEFT_RIGHT', 'Left to Right', 'Place source/input nodes on the left and output/dependent nodes on the right.'),
    ('RIGHT_LEFT', 'Right to Left', 'Place source/input nodes on the right and output/dependent nodes on the left.'),
    ('TOP_BOTTOM', 'Top to Bottom', 'Place source/input nodes above and output/dependent nodes below.'),
    ('BOTTOM_TOP', 'Bottom to Top', 'Place source/input nodes below and output/dependent nodes above.'),
)


def _node_width(node) -> float:
    try:
        value = float(node.dimensions.x)
        if value > 1.0:
            return max(value, 80.0)
    except Exception:
        pass
    try:
        return max(float(node.width), 120.0)
    except Exception:
        return 160.0


def _node_height(node) -> float:
    try:
        value = float(node.dimensions.y)
        if value > 1.0:
            return max(value, 40.0)
    except Exception:
        pass
    try:
        # Blender nodes often report a usable height only after UI redraw. A
        # conservative default prevents overlap during background tests too.
        return max(float(node.height), 60.0)
    except Exception:
        return 90.0


def _absolute_location(node) -> Vector:
    try:
        return Vector(abs_node_location(node))
    except Exception:
        try:
            return Vector((float(node.location.x), float(node.location.y)))
        except Exception:
            return Vector((0.0, 0.0))


def _set_absolute_location(node, location: Vector) -> None:
    loc = Vector(location)
    parent = getattr(node, 'parent', None)
    if parent is not None:
        try:
            loc -= _absolute_location(parent)
        except Exception:
            pass
    try:
        node.location.x = loc.x
        node.location.y = loc.y
    except Exception:
        pass


def _normal_nodes(nodes, selected_only: bool = False, include_frames: bool = False) -> list:
    result = []
    for node in nodes:
        if not include_frames and getattr(node, 'type', '') == 'FRAME':
            continue
        if selected_only and not bool(getattr(node, 'select', False)):
            continue
        result.append(node)
    return result


def _selected_or_active(nodes) -> list:
    all_nodes = _normal_nodes(nodes)
    selected = [node for node in all_nodes if bool(getattr(node, 'select', False))]
    if selected:
        return selected
    active = getattr(nodes, 'active', None)
    return [active] if active in all_nodes else []


def _graph(nodes, links):
    node_set = set(nodes)
    out_map = defaultdict(list)
    in_map = defaultdict(list)
    for link in links:
        try:
            if not bool(getattr(link, 'is_valid', True)):
                continue
            src = link.from_node
            dst = link.to_node
        except Exception:
            continue
        if src in node_set and dst in node_set and src is not dst:
            out_map[src].append(dst)
            in_map[dst].append(src)
    for node in nodes:
        out_map.setdefault(node, [])
        in_map.setdefault(node, [])
    return out_map, in_map


def _collect_connected(start_nodes, out_map, in_map, direction: str) -> list:
    start_nodes = [node for node in start_nodes if node is not None]
    seen = set(start_nodes)
    queue = deque(start_nodes)
    while queue:
        node = queue.popleft()
        targets = []
        if direction in {'DOWNSTREAM', 'BOTH'}:
            targets.extend(out_map.get(node, ()))
        if direction in {'UPSTREAM', 'BOTH'}:
            targets.extend(in_map.get(node, ()))
        for target in targets:
            if target not in seen:
                seen.add(target)
                queue.append(target)
    return list(seen)


def _topological_depths(nodes, out_map, in_map):
    node_set = set(nodes)
    indegree = {node: len([src for src in in_map.get(node, ()) if src in node_set]) for node in nodes}
    depth = {node: 0 for node in nodes}
    queue = deque(sorted((node for node in nodes if indegree.get(node, 0) == 0), key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name)))
    visited = set()
    while queue:
        node = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        for dst in out_map.get(node, ()):
            if dst not in node_set:
                continue
            depth[dst] = max(depth.get(dst, 0), depth.get(node, 0) + 1)
            indegree[dst] = indegree.get(dst, 0) - 1
            if indegree[dst] <= 0:
                queue.append(dst)

    # Cycles are uncommon in shader/material graphs but can exist in some node
    # systems. The relaxation pass assigns stable layers without infinite loops.
    if len(visited) < len(nodes):
        for node in nodes:
            depth.setdefault(node, 0)
        for _ in range(max(1, len(nodes))):
            changed = False
            for src in nodes:
                for dst in out_map.get(src, ()):
                    if dst not in node_set:
                        continue
                    proposed = min(depth.get(src, 0) + 1, len(nodes))
                    if depth.get(dst, 0) < proposed:
                        depth[dst] = proposed
                        changed = True
            if not changed:
                break
    return depth


def _socket_index(socket, sockets=None) -> int:
    """Return a stable top-to-bottom socket index for Blender node sockets."""
    try:
        value = int(getattr(socket, 'index'))
        if value >= 0:
            return value
    except Exception:
        pass
    if sockets is not None:
        try:
            for index, candidate in enumerate(sockets):
                if candidate == socket:
                    return index
        except Exception:
            pass
    return 0


def _same_node(a, b) -> bool:
    if a is b:
        return True
    try:
        if a == b:
            return True
    except Exception:
        pass
    try:
        return int(a.as_pointer()) == int(b.as_pointer())
    except Exception:
        return False


def _node_identity(node):
    try:
        return int(node.as_pointer())
    except Exception:
        return getattr(node, 'name', repr(node))


def _valid_link_records(links, node_set=None) -> list[tuple]:
    records = []
    for link in links:
        try:
            if not bool(getattr(link, 'is_valid', True)):
                continue
            src = link.from_node
            dst = link.to_node
            if src is None or dst is None or src is dst:
                continue
            if node_set is not None and (src not in node_set or dst not in node_set):
                continue
            from_index = _socket_index(link.from_socket, getattr(src, 'outputs', None))
            to_index = _socket_index(link.to_socket, getattr(dst, 'inputs', None))
            records.append((src, dst, from_index, to_index, link))
        except Exception:
            continue
    return records


def _socket_neighbor_score(node, link_records, order_map, parent_role: str):
    """Score child order by the socket order on the connected parent node.

    parent_role SOURCE means the neighbor is upstream/source and the child's
    order follows the parent's output socket order. parent_role DESTINATION
    means the neighbor is downstream/destination and the child's order follows
    the parent's input socket order. Blender lists node sockets from top to
    bottom, so lower socket indexes sort higher in the layer.
    """
    values = []
    if not order_map:
        return None
    for src, dst, from_index, to_index, _link in link_records:
        if parent_role == 'SOURCE' and _same_node(dst, node) and src in order_map:
            values.append(float(order_map[src]) * 100000.0 + float(from_index) * 100.0 + float(to_index))
        elif parent_role == 'DESTINATION' and _same_node(src, node) and dst in order_map:
            values.append(float(order_map[dst]) * 100000.0 + float(to_index) * 100.0 + float(from_index))
    if not values:
        return None
    return sum(values) / len(values)


def _socket_layer_sort_key(node, link_records, order_map, parent_role: str, fallback_neighbors, fallback_order):
    score = _socket_neighbor_score(node, link_records, order_map, parent_role)
    if score is not None:
        return (0, score, -_absolute_location(node).y, _absolute_location(node).x, getattr(node, 'name', ''))
    return (
        1,
        _neighbor_barycenter(node, fallback_neighbors, fallback_order),
        -_absolute_location(node).y,
        _absolute_location(node).x,
        getattr(node, 'name', ''),
    )


def _socket_parent_visual_key(parent) -> tuple:
    loc = _absolute_location(parent)
    return (-loc.y, loc.x, getattr(parent, 'name', ''))


def _direct_parent_socket_key_from_records(node, link_records):
    """Return a direct parent/socket key for vertical manual arrange tools.

    Upstream children feeding a parent input are prioritized because this is the
    common Blender shader/material case. Downstream children are still sorted by
    the selected/source parent's output socket order when no destination-parent
    input relationship is available.
    """
    destination_parent_candidates = []
    source_parent_candidates = []
    for src, dst, from_index, to_index, _link in link_records:
        if _same_node(src, node):
            destination_parent_candidates.append((0, _socket_parent_visual_key(dst), to_index, from_index, getattr(dst, 'name', ''), getattr(node, 'name', '')))
        elif _same_node(dst, node):
            source_parent_candidates.append((1, _socket_parent_visual_key(src), from_index, to_index, getattr(src, 'name', ''), getattr(node, 'name', '')))
    if destination_parent_candidates:
        destination_parent_candidates.sort()
        return destination_parent_candidates[0]
    if source_parent_candidates:
        source_parent_candidates.sort()
        return source_parent_candidates[0]
    return None


def _direct_parent_socket_key(node, links):
    return _direct_parent_socket_key_from_records(node, _valid_link_records(links, None))


def _socket_aware_vertical_order(nodes, links) -> list:
    """Order nodes from top to bottom using connected parent socket order first."""
    target = [node for node in nodes if node is not None]
    records = _valid_link_records(links or (), None)

    def key(node):
        direct = _direct_parent_socket_key_from_records(node, records)
        if direct is not None:
            return (0, direct)
        loc = _absolute_location(node)
        return (1, -loc.y, loc.x, getattr(node, 'name', ''))
    return sorted(target, key=key)


def _crossing_sort(layers, out_map, in_map, links=None):
    # Socket-aware barycentric pass. It keeps siblings feeding the same parent in
    # the same top-to-bottom order as the parent's sockets, so shader noodles are
    # less likely to cross after automatic layout.
    ordered_keys = sorted(layers.keys())
    for key in ordered_keys:
        layers[key].sort(key=lambda n: (-_absolute_location(n).y, _absolute_location(n).x, getattr(n, 'name', '')))

    node_set = {node for group in layers.values() for node in group}
    link_records = _valid_link_records(links or (), node_set)
    passes = 4 if link_records else 2
    for _ in range(passes):
        previous_order = {}
        for key in ordered_keys:
            if key != ordered_keys[0]:
                fallback_order = dict(previous_order)
                layers[key].sort(key=lambda n: _socket_layer_sort_key(n, link_records, previous_order, 'SOURCE', in_map.get(n, ()), fallback_order))
            previous_order.update({node: i for i, node in enumerate(layers[key])})

        next_order = {}
        for key in reversed(ordered_keys):
            if key != ordered_keys[-1]:
                fallback_order = dict(next_order)
                layers[key].sort(key=lambda n: _socket_layer_sort_key(n, link_records, next_order, 'DESTINATION', out_map.get(n, ()), fallback_order))
            next_order.update({node: i for i, node in enumerate(layers[key])})
    return layers


def _neighbor_barycenter(node, neighbors, order_map):
    values = [order_map[n] for n in neighbors if n in order_map]
    if not values:
        return 0.0
    return sum(values) / len(values)


def _layout(nodes, links, direction='LEFT_RIGHT', x_spacing=280.0, y_spacing=90.0, keep_center=True, roots=None, context=None) -> int:
    nodes = [node for node in nodes if node is not None and getattr(node, 'type', '') != 'FRAME']
    if not nodes:
        return 0

    old_center = Vector((
        sum(_absolute_location(node).x for node in nodes) / len(nodes),
        sum(_absolute_location(node).y for node in nodes) / len(nodes),
    ))

    out_map, in_map = _graph(nodes, links)
    depth = _topological_depths(nodes, out_map, in_map)

    # When active roots are supplied, keep those roots in the deepest relevant
    # layer for an upstream child layout. This mimics a parent material/output
    # node with its dependency tree laid out to the side.
    if roots:
        root_set = {node for node in roots if node in nodes}
        if root_set:
            max_depth = max(depth.values()) if depth else 0
            for node in root_set:
                depth[node] = max_depth

    layers = defaultdict(list)
    for node in nodes:
        layers[int(depth.get(node, 0))].append(node)
    layers = _crossing_sort(layers, out_map, in_map, links)

    sorted_layers = sorted(layers.keys())
    layer_sizes = {}
    for layer in sorted_layers:
        group = layers[layer]
        heights = [_node_height(n) for n in group]
        if heights:
            total_height = heights[-1]
            for height in heights[:-1]:
                total_height += axis_advance(context, height, y_spacing, 'VERTICAL')
        else:
            total_height = 0.0
        layer_sizes[layer] = (
            max((_node_width(n) for n in group), default=120.0),
            total_height,
        )

    layer_x = {}
    cursor_x = 0.0
    for layer in sorted_layers:
        if layer not in layer_x:
            layer_x[layer] = cursor_x
        cursor_x += axis_advance(context, layer_sizes[layer][0], x_spacing, 'HORIZONTAL')

    for layer in sorted_layers:
        group = layers[layer]
        total_height = layer_sizes[layer][1]
        y = total_height / 2.0
        x = layer_x[layer]
        for node in group:
            _set_absolute_location(node, Vector((x, y)))
            y -= axis_advance(context, _node_height(node), y_spacing, 'VERTICAL')

    # Reverse or rotate after base layout.
    if direction == 'RIGHT_LEFT':
        min_x = min(_absolute_location(n).x for n in nodes)
        max_x = max(_absolute_location(n).x for n in nodes)
        for node in nodes:
            loc = _absolute_location(node)
            _set_absolute_location(node, Vector((max_x - (loc.x - min_x), loc.y)))
    elif direction in {'TOP_BOTTOM', 'BOTTOM_TOP'}:
        for node in nodes:
            loc = _absolute_location(node)
            if direction == 'TOP_BOTTOM':
                _set_absolute_location(node, Vector((loc.y, -loc.x)))
            else:
                _set_absolute_location(node, Vector((loc.y, loc.x)))

    if keep_center:
        new_center = Vector((
            sum(_absolute_location(node).x for node in nodes) / len(nodes),
            sum(_absolute_location(node).y for node in nodes) / len(nodes),
        ))
        delta = old_center - new_center
        for node in nodes:
            _set_absolute_location(node, _absolute_location(node) + delta)

    snap_nodes_to_major_grid(nodes, context, _absolute_location, _set_absolute_location)
    return len(nodes)


def _bounds(nodes):
    if not nodes:
        return (0.0, 0.0, 0.0, 0.0)
    left = min(_absolute_location(n).x for n in nodes)
    top = max(_absolute_location(n).y for n in nodes)
    right = max(_absolute_location(n).x + _node_width(n) for n in nodes)
    bottom = min(_absolute_location(n).y - _node_height(n) for n in nodes)
    return left, top, right, bottom


def _target_nodes_by_scope(nodes, links, scope: str, branch_direction='BOTH') -> list:
    all_nodes = _normal_nodes(nodes)
    selected = [node for node in all_nodes if bool(getattr(node, 'select', False))]
    active = getattr(nodes, 'active', None)
    if scope == 'ALL' or (scope == 'SELECTED' and not selected):
        return all_nodes
    if scope == 'SELECTED':
        return selected
    seeds = selected or ([active] if active in all_nodes else all_nodes[:1])
    out_map, in_map = _graph(all_nodes, links)
    return _collect_connected(seeds, out_map, in_map, branch_direction if scope == 'BRANCH' else scope)




def _layout_roots_from_seeds(seeds, target, out_map, in_map, branch: str) -> list:
    target_set = {node for node in target if node is not None}
    seed_list = [node for node in seeds if node in target_set]
    if not seed_list:
        return []
    if branch == 'UPSTREAM':
        roots = [node for node in seed_list if not any(dst in target_set for dst in out_map.get(node, ())) ]
    elif branch == 'DOWNSTREAM':
        roots = [node for node in seed_list if not any(src in target_set for src in in_map.get(node, ())) ]
    else:
        roots = []
    return roots or seed_list[:1]

class SMART_NODE_SUITE_OT_layout_hierarchy(Operator):
    bl_idname = 'smart_node_suite.layout_hierarchy'
    bl_label = 'Smart Hierarchy Layout'
    bl_description = _tip(
        'Function: arranges the selected nodes into readable dependency layers from left to right. If nothing is selected, all nodes are arranged. How to use: select nodes in the Node Editor and run this command.',
        '機能: 選択ノードを依存関係の階層ごとに左から右へ読みやすく整列します。何も選んでいない時は全ノードを整列します。使い方: ノードエディターでノードを選択して実行します。',
    )
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=(
            ('SELECTED', 'Selected', 'Arrange selected nodes only. If nothing is selected, all nodes are arranged.'),
            ('ALL', 'All', 'Arrange every node in the edited node tree.'),
            ('UPSTREAM', 'Upstream', 'Arrange selected nodes and all input/dependency nodes feeding them.'),
            ('DOWNSTREAM', 'Downstream', 'Arrange selected nodes and all output/dependent nodes after them.'),
            ('BOTH', 'Connected', 'Arrange the full connected component around the selected or active nodes.'),
        ),
        default='SELECTED',
        description=_tip('Function: chooses which nodes are included in the hierarchy layout. How to use: use Selected for local cleanup, All for a full graph cleanup, or Upstream/Downstream/Connected to follow links from the active selection.', '機能: 階層整列に含めるノード範囲を選びます。使い方: 局所整理は選択中、全体整理はすべて、リンクをたどる場合は上流/下流/接続全体を選びます。'),
    )
    direction: EnumProperty(
        name='Direction',
        items=_DIRECTIONS,
        default='LEFT_RIGHT',
        description=_tip('Function: chooses the visual flow direction for the arranged graph. How to use: use Left to Right for Blender shader/material graphs, or choose another direction when matching a studio layout convention.', '機能: 整列後のグラフの流れ方向を選びます。使い方: Blender のシェーダー/マテリアルでは左から右が基本です。スタジオの表示ルールに合わせる場合は別方向を選びます。'),
    )
    x_spacing: FloatProperty(name='Layer Spacing', default=280.0, min=40.0, max=3000.0, description=_tip('Function: sets the distance between dependency layers. How to use: increase this when links overlap or socket labels need more space.', '機能: 依存階層どうしの距離を設定します。使い方: リンクが重なる場合やソケット名を見やすくしたい場合は値を大きくします。'))
    y_spacing: FloatProperty(name='Node Spacing', default=90.0, min=10.0, max=2000.0, description=_tip('Function: sets the vertical or secondary-axis distance between nodes within the same layer. How to use: increase this for tall nodes or dense material graphs.', '機能: 同じ階層内にあるノードどうしの縦方向または副軸方向の距離を設定します。使い方: 背の高いノードや密なマテリアルでは値を大きくします。'))
    keep_center: BoolProperty(name='Keep Center', default=True, description=_tip('Function: keeps the arranged node group centered around its original position. How to use: leave enabled when cleaning a graph without losing your current workspace location.', '機能: 整列したノード群の中心を元の位置付近に維持します。使い方: 作業中の場所を大きく動かさず整理したい場合は有効のままにします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        if not all_nodes:
            return {'CANCELLED'}
        if self.scope in {'SELECTED', 'ALL'}:
            target = _target_nodes_by_scope(nodes, links, self.scope)
        else:
            target = _target_nodes_by_scope(nodes, links, self.scope)
        count = _layout(target, links, self.direction, self.x_spacing, self.y_spacing, self.keep_center, context=context)
        self.report({'INFO'}, _t('Arranged {count} nodes in hierarchy.', '階層で {count} 個のノードを整列しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_arrange_children(Operator):
    bl_idname = 'smart_node_suite.arrange_children'
    bl_label = 'Lay Out Children'
    bl_description = _tip(
        'Function: arranges the branch connected to the active or selected parent node, similar to 3ds Max Slate Material Editor Lay Out Children. How to use: select the parent/output/material node and press the button. The nodes on its input side (upstream) are treated as the children.',
        '機能: 3ds Max のスレートマテリアルエディタの「子を整列」に近い動作で、アクティブまたは選択した親ノードに接続するブランチを階層ごとに整列します。使い方: 親、出力、マテリアル相当のノードを選択して押します。入力側（上流）のノードを子として扱います。',
    )
    bl_options = {'UNDO'}

    branch: EnumProperty(
        name='Scope',
        items=(
            ('UPSTREAM', 'Upstream', 'Treat input/dependency nodes as children. This is usually best for Blender shader graphs.'),
            ('DOWNSTREAM', 'Downstream', 'Treat output/dependent nodes as children.'),
            ('BOTH', 'Connected', 'Arrange both input and output branches around the selected parent.'),
        ),
        default='UPSTREAM',
        description=_tip('Function: decides which linked nodes count as children of the selected parent. How to use: use Upstream for texture/map trees feeding a shader, Downstream for procedural outputs, or Connected for both sides.', '機能: 選択した親ノードの子として扱うリンク方向を決めます。使い方: シェーダーへ入るテクスチャ/マップは上流、プロシージャル出力側は下流、両方整理したい場合は接続全体を使います。'),
    )
    direction: EnumProperty(name='Direction', items=_DIRECTIONS, default='LEFT_RIGHT', description=_tip('Function: sets the direction used for the child layout. How to use: keep Left to Right for most Blender node trees, or reverse it when matching a right-to-left graph convention.', '機能: 子ブランチを整列する方向を設定します。使い方: 通常の Blender ノードツリーでは左から右のまま使い、右から左の規則に合わせる場合だけ反転します。'))
    x_spacing: FloatProperty(name='Layer Spacing', default=280.0, min=40.0, max=3000.0, description=_tip('Function: controls distance between child hierarchy levels. How to use: increase when child branches overlap.', '機能: 子階層の間隔を調整します。使い方: 子ブランチが重なる場合は値を大きくします。'))
    y_spacing: FloatProperty(name='Node Spacing', default=90.0, min=10.0, max=2000.0, description=_tip('Function: controls spacing between siblings in the same child layer. How to use: increase for tall nodes or many siblings.', '機能: 同じ子階層にある兄弟ノード間の距離を調整します。使い方: 背の高いノードや兄弟ノードが多い場合は値を大きくします。'))
    keep_center: BoolProperty(name='Keep Center', default=True, description=_tip('Function: keeps the child branch near its original center. How to use: disable only when you want the layout to start from a fresh origin.', '機能: 子ブランチを元の中心位置付近に維持します。使い方: 新しい原点から並べ直したい場合だけ無効にします。'))
    pin_parent: BoolProperty(name='Pin Parent', default=True, description=_tip('Function: keeps the selected parent node at its original position while the connected child branch is arranged around it. How to use: leave enabled to mimic Slate-style child layout where the material/output node stays anchored; disable when the whole branch may move as a group.', '機能: 選択した親ノードの位置を固定したまま、接続された子ブランチを周囲に整列します。使い方: マテリアル/出力相当の親を動かさず子だけ整える場合は有効のまま使い、ブランチ全体を動かしてよい場合だけ無効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        seeds = _selected_or_active(nodes)
        if not seeds:
            return {'CANCELLED'}

        active = getattr(nodes, 'active', None)
        parent = active if active in seeds else seeds[0]
        pinned_location = _absolute_location(parent) if bool(self.pin_parent) and parent is not None else None

        out_map, in_map = _graph(all_nodes, links)
        target = _collect_connected(seeds, out_map, in_map, self.branch)
        layout_roots = _layout_roots_from_seeds(seeds, target, out_map, in_map, self.branch)
        count = _layout(
            target,
            links,
            self.direction,
            self.x_spacing,
            self.y_spacing,
            self.keep_center,
            roots=layout_roots if self.branch in {'UPSTREAM', 'DOWNSTREAM'} else None,
            context=context,
        )

        if pinned_location is not None and parent in target:
            delta = pinned_location - _absolute_location(parent)
            for node in target:
                _set_absolute_location(node, _absolute_location(node) + delta)

        self.report({'INFO'}, _t('Laid out {count} child nodes.', '{count} 個の子ノードを整列しました。').format(count=count))
        return {'FINISHED'}



class SMART_NODE_SUITE_OT_arrange_selected(Operator):
    bl_idname = 'smart_node_suite.arrange_selected'
    bl_label = 'Arrange Selected Nodes'
    bl_description = _tip(
        'Function: arranges only the selected nodes into a compact dependency layout from left to right without touching unselected nodes. How to use: select the nodes you want to clean up and run this command.',
        '機能: 未選択ノードを動かさず、選択ノードだけを依存関係に沿って左から右へコンパクトに整列します。使い方: 整理したいノードだけを選択して実行します。',
    )
    bl_options = {'UNDO'}

    direction: EnumProperty(name='Direction', items=_DIRECTIONS, default='LEFT_RIGHT', description=_tip('Function: chooses the flow direction for the selected-node layout. How to use: keep Left to Right for most Blender material graphs, or choose vertical directions for tall production graphs.', '機能: 選択ノード整列の流れ方向を選びます。使い方: 通常の Blender マテリアルグラフでは左から右を使い、縦長の制作用グラフでは上下方向を選びます。'))
    x_spacing: FloatProperty(name='Layer Spacing', default=260.0, min=40.0, max=3000.0, description=_tip('Function: sets spacing between dependency layers inside the selected nodes. How to use: increase when links or socket labels overlap.', '機能: 選択ノード内の依存階層間隔を設定します。使い方: リンクやソケット表示が重なる場合は値を大きくします。'))
    y_spacing: FloatProperty(name='Node Spacing', default=80.0, min=10.0, max=2000.0, description=_tip('Function: sets spacing between selected nodes in the same layer. How to use: increase for tall nodes or dense branches.', '機能: 同じ階層にある選択ノードどうしの距離を設定します。使い方: 背の高いノードや密なブランチでは値を大きくします。'))
    keep_center: BoolProperty(name='Keep Center', default=True, description=_tip('Function: keeps the selected group near its original center. How to use: leave enabled when cleaning local areas without losing the current working position.', '機能: 選択グループを元の中心位置付近に維持します。使い方: 作業中の局所領域を見失わず整理したい場合は有効のまま使います。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if not target:
            self.report({'WARNING'}, _t('Select at least two nodes to arrange.', '整列するノードを2つ以上選択してください。'))
            return {'CANCELLED'}
        if len(target) == 1:
            self.report({'WARNING'}, _t('Select at least two nodes to arrange.', '整列するノードを2つ以上選択してください。'))
            return {'CANCELLED'}
        count = _layout(target, links, self.direction, self.x_spacing, self.y_spacing, self.keep_center, context=context)
        self.report({'INFO'}, _t('Arranged {count} selected nodes.', '選択ノードを {count} 個整列しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_sort_nodes(Operator):
    bl_idname = 'smart_node_suite.sort_nodes'
    bl_label = 'Sort Nodes'
    bl_description = _tip(
        'Function: sorts nodes in all directions, horizontally, or vertically, inspired by node-editor sort tools in DCC applications. How to use: choose All for dependency-aware cleanup, Horizontal to redistribute x positions, or Vertical to redistribute y positions.',
        '機能: DCCアプリのノードエディター整列機能を参考に、ノードを全体、水平、垂直方向へソートします。使い方: 依存関係込みで整理する場合はすべて、X位置だけ整える場合は水平、Y位置だけ整える場合は垂直を選びます。',
    )
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name='Mode',
        items=(
            ('SMART', 'Sort All', 'Arrange nodes into dependency-aware rows and columns.'),
            ('HORIZONTAL', 'Sort Horizontally', 'Redistribute nodes evenly on the X axis without changing their Y positions.'),
            ('VERTICAL', 'Sort Vertically', 'Redistribute nodes evenly on the Y axis without changing their X positions.'),
        ),
        default='SMART',
        description=_tip('Function: selects the sorting behavior. How to use: Sort All rebuilds a graph layout; Horizontal or Vertical only redistributes positions along one axis.', '機能: ソート方法を選びます。使い方: すべてはグラフ配置を作り直し、水平/垂直は1軸だけを均等配置します。'),
    )
    scope: EnumProperty(
        name='Scope',
        items=(
            ('SELECTED', 'Selected', 'Sort selected nodes; if nothing is selected, sort all nodes.'),
            ('ALL', 'All', 'Sort every node in the edited node tree.'),
            ('BRANCH', 'Connected', 'Sort the connected branch around the current selection or active node.'),
        ),
        default='SELECTED',
        description=_tip('Function: chooses which nodes are sorted. How to use: use Selected for local cleanup, All for a complete node tree, or Connected for a linked branch around the current selection.', '機能: ソート対象を選びます。使い方: 局所整理は選択中、全体整理はすべて、現在の選択周辺のリンクブランチは接続全体を使います。'),
    )
    spacing: FloatProperty(name='Spacing', default=180.0, min=20.0, max=3000.0, description=_tip('Function: sets the distance between redistributed nodes. How to use: increase when nodes overlap or labels need more room.', '機能: 再配置されるノード間隔を設定します。使い方: ノードが重なる場合やラベルに余白が必要な場合は値を大きくします。'))
    direction: EnumProperty(name='Direction', items=_DIRECTIONS, default='LEFT_RIGHT', description=_tip('Function: chooses the flow direction used by Sort All. How to use: leave Left to Right for typical shader graphs; it is ignored by Horizontal and Vertical modes.', '機能: すべてソートで使う流れ方向を選びます。使い方: 一般的なシェーダーグラフでは左から右のまま使います。水平/垂直モードでは無視されます。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _target_nodes_by_scope(nodes, links, self.scope)
        target = [node for node in target if getattr(node, 'type', '') != 'FRAME']
        if len(target) < 2:
            self.report({'WARNING'}, _t('Select at least two nodes to sort.', 'ソートするノードを2つ以上選択してください。'))
            return {'CANCELLED'}

        if self.mode == 'SMART':
            count = _layout(target, links, self.direction, max(self.spacing, 40.0), max(self.spacing * 0.5, 10.0), True, context=context)
        elif self.mode == 'HORIZONTAL':
            ordered = sorted(target, key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name))
            min_x = min(_absolute_location(n).x for n in ordered)
            for index, node in enumerate(ordered):
                loc = _absolute_location(node)
                if index == 0:
                    loc.x = min_x
                else:
                    previous = ordered[index - 1]
                    loc.x = _absolute_location(previous).x + axis_advance(context, _node_width(previous), self.spacing, 'HORIZONTAL')
                _set_absolute_location(node, Vector((loc.x, loc.y)))
            count = len(ordered)
        else:
            ordered = _socket_aware_vertical_order(target, links)
            max_y = max(_absolute_location(n).y for n in ordered)
            for index, node in enumerate(ordered):
                loc = _absolute_location(node)
                if index == 0:
                    loc.y = max_y
                else:
                    previous = ordered[index - 1]
                    loc.y = _absolute_location(previous).y - axis_advance(context, _node_height(previous), self.spacing, 'VERTICAL')
                _set_absolute_location(node, Vector((loc.x, loc.y)))
            count = len(ordered)

        snap_nodes_to_major_grid(target, context, _absolute_location, _set_absolute_location, axes={'HORIZONTAL': 'X', 'VERTICAL': 'Y'}.get(self.mode, 'XY'))
        self.report({'INFO'}, _t('Sorted {count} nodes.', '{count} 個のノードをソートしました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_lay_out_all(Operator):
    bl_idname = 'smart_node_suite.lay_out_all'
    bl_label = 'Lay Out All'
    bl_description = _tip(
        'Function: arranges the entire edited node tree into readable dependency layers. How to use: run it when a material, compositor setup, or geometry node tree has become scattered; use Undo if you want to restore the previous manual layout.',
        '機能: 編集中のノードツリー全体を依存関係の階層ごとに読みやすく整列します。使い方: マテリアル、コンポジター、ジオメトリノードが散らかった時に実行します。元の手動配置に戻したい場合は元に戻すを使います。',
    )
    bl_options = {'UNDO'}

    direction: EnumProperty(name='Direction', items=_DIRECTIONS, default='LEFT_RIGHT', description=_tip('Function: chooses graph flow direction for the full layout. How to use: Left to Right follows Blender and Cinema 4D style material data flow.', '機能: 全体整列の流れ方向を選びます。使い方: 左から右は Blender と Cinema 4D 風のマテリアルデータフローに合います。'))
    x_spacing: FloatProperty(name='Layer Spacing', default=300.0, min=40.0, max=3000.0, description=_tip('Function: sets distance between full-graph dependency layers. How to use: use larger values for complex production node trees.', '機能: ノードツリー全体の依存階層間の距離を設定します。使い方: 複雑な制作用ノードツリーでは大きめにします。'))
    y_spacing: FloatProperty(name='Node Spacing', default=100.0, min=10.0, max=2000.0, description=_tip('Function: sets spacing between nodes inside each layer. How to use: increase when node cards overlap vertically.', '機能: 各階層内のノード同士の距離を設定します。使い方: ノードカードが縦に重なる場合は値を大きくします。'))
    keep_center: BoolProperty(name='Keep Center', default=True, description=_tip('Function: keeps the whole graph near its previous center. How to use: leave enabled to avoid losing your current visual area.', '機能: ノードツリー全体を元の中心位置付近に維持します。使い方: 現在見ている作業領域から大きく離したくない場合は有効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes)
        count = _layout(target, links, self.direction, self.x_spacing, self.y_spacing, self.keep_center, context=context)
        self.report({'INFO'}, _t('Laid out all {count} nodes.', 'すべての {count} 個のノードを整列しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_align_edges(Operator):
    bl_idname = 'smart_node_suite.align_edges'
    bl_label = 'Align Node Edges'
    bl_description = _tip(
        'Function: aligns selected nodes to a shared left, center, right, top, middle, or bottom line while keeping their links unchanged. How to use: select two or more nodes and choose the edge or center alignment that makes the graph easier to scan.',
        '機能: 選択ノードを左端、中央、右端、上端、中央Y、下端の基準線へそろえます。リンク自体は変更しません。使い方: 2つ以上のノードを選択し、見やすくなる整列方向を選びます。',
    )
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name='Direction',
        items=(
            ('LEFT', 'Left', 'Align the left edge of selected nodes to the leftmost selected node.'),
            ('CENTER_X', 'Center X', 'Align horizontal centers to the selected bounding-box center.'),
            ('RIGHT', 'Right', 'Align the right edge of selected nodes to the rightmost selected node.'),
            ('TOP', 'Top', 'Align top edges to the highest selected node.'),
            ('CENTER_Y', 'Center Y', 'Align vertical centers to the selected bounding-box center.'),
            ('BOTTOM', 'Bottom', 'Align bottom edges to the lowest selected node.'),
        ),
        default='LEFT',
        description=_tip('Function: chooses the edge or center line used for alignment. How to use: Left/Right controls X edges; Top/Bottom controls Y edges; center modes align to the selected bounding box.', '機能: 整列に使う端または中心線を選びます。使い方: 左/右はX端、上/下はY端、中央系は選択範囲の中心へそろえます。'),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if len(target) < 2:
            self.report({'WARNING'}, _t('Select at least two nodes to align.', '整列するには2つ以上のノードを選択してください。'))
            return {'CANCELLED'}
        left, top, right, bottom = _bounds(target)
        center_x = (left + right) * 0.5
        center_y = (top + bottom) * 0.5
        for node in target:
            loc = _absolute_location(node)
            if self.mode == 'LEFT':
                loc.x = left
            elif self.mode == 'CENTER_X':
                loc.x = center_x - _node_width(node) * 0.5
            elif self.mode == 'RIGHT':
                loc.x = right - _node_width(node)
            elif self.mode == 'TOP':
                loc.y = top
            elif self.mode == 'CENTER_Y':
                loc.y = center_y + _node_height(node) * 0.5
            elif self.mode == 'BOTTOM':
                loc.y = bottom + _node_height(node)
            _set_absolute_location(node, loc)
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_distribute_nodes(Operator):
    bl_idname = 'smart_node_suite.distribute_nodes'
    bl_label = 'Distribute Nodes'
    bl_description = _tip(
        'Function: evenly spaces selected nodes horizontally or vertically using node dimensions to avoid overlap. How to use: select two or more nodes and press Horizontal or Vertical. The gap between nodes is fixed.',
        '機能: ノードの実寸を考慮し、選択ノードを水平または垂直に均等配置して重なりを避けます。使い方: 2つ以上のノードを選択し、「水平」または「垂直」を押します。ノードの間隔は決まった値です。',
    )
    bl_options = {'UNDO'}

    axis: EnumProperty(
        name='Direction',
        items=(('HORIZONTAL', 'Horizontal', 'Distribute selected nodes from left to right.'), ('VERTICAL', 'Vertical', 'Distribute selected nodes from top to bottom.')),
        default='HORIZONTAL',
        description=_tip('Function: chooses whether spacing is applied along the X axis or Y axis. How to use: choose Horizontal for left-to-right rows or Vertical for top-to-bottom columns.', '機能: 間隔をX軸またはY軸のどちらに適用するかを選びます。使い方: 横並びは水平、縦並びは垂直を選びます。'),
    )
    spacing: FloatProperty(name='Spacing', default=80.0, min=0.0, max=2000.0, description=_tip('Function: sets the empty gap between neighboring node bounds. How to use: use zero for tight packing or a larger value for readable link spacing.', '機能: 隣り合うノードの境界間に空ける距離を設定します。使い方: 詰める場合は0、リンクを読みやすくする場合は大きめにします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if len(target) < 2:
            self.report({'WARNING'}, _t('Select at least two nodes to distribute.', '均等配置するには2つ以上のノードを選択してください。'))
            return {'CANCELLED'}
        if self.axis == 'HORIZONTAL':
            target.sort(key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name))
            x = _absolute_location(target[0]).x
            y_reference = [_absolute_location(n).y for n in target]
            for i, node in enumerate(target):
                loc = _absolute_location(node)
                loc.x = x
                loc.y = y_reference[i]
                _set_absolute_location(node, loc)
                x += axis_advance(context, _node_width(node), self.spacing, 'HORIZONTAL')
        else:
            target = _socket_aware_vertical_order(target, links)
            y = _absolute_location(target[0]).y
            x_reference = [_absolute_location(n).x for n in target]
            for i, node in enumerate(target):
                loc = _absolute_location(node)
                loc.x = x_reference[i]
                loc.y = y
                _set_absolute_location(node, loc)
                y -= axis_advance(context, _node_height(node), self.spacing, 'VERTICAL')
        snap_nodes_to_major_grid(target, context, _absolute_location, _set_absolute_location, axes='X' if self.axis == 'HORIZONTAL' else 'Y')
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_distribute_grid(Operator):
    bl_idname = 'smart_node_suite.distribute_grid'
    bl_label = 'Distribute Node Grid'
    bl_description = _tip(
        'Function: places selected nodes into a compact grid without changing node links. The number of columns is chosen automatically. How to use: select a loose group of nodes and run this command.',
        '機能: 選択ノードをコンパクトなグリッド状に配置します。ノードリンクは変更しません。列数は自動で決まります。使い方: 散らばったノード群を選択して実行します。',
    )
    bl_options = {'UNDO'}

    columns: IntProperty(name='Columns', default=0, min=0, max=64, description=_tip('Function: sets the number of grid columns. How to use: set 0 for automatic square-like layout, or enter a fixed column count.', '機能: グリッドの列数を設定します。使い方: 0は自動で正方形に近い配置、固定したい場合は列数を入力します。'))
    x_spacing: FloatProperty(name='X Spacing', default=240.0, min=20.0, max=3000.0, description=_tip('Function: sets horizontal grid spacing. How to use: increase if wide nodes overlap.', '機能: グリッドの横間隔を設定します。使い方: 横幅の広いノードが重なる場合は大きくします。'))
    y_spacing: FloatProperty(name='Y Spacing', default=140.0, min=20.0, max=3000.0, description=_tip('Function: sets vertical grid spacing. How to use: increase if tall nodes overlap.', '機能: グリッドの縦間隔を設定します。使い方: 背の高いノードが重なる場合は大きくします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True) or _normal_nodes(nodes)
        if not target:
            return {'CANCELLED'}
        target = _socket_aware_vertical_order(target, _links)
        center = Vector((sum(_absolute_location(n).x for n in target) / len(target), sum(_absolute_location(n).y for n in target) / len(target)))
        cols = int(self.columns) if int(self.columns) > 0 else max(1, int(ceil(sqrt(len(target)))))
        rows = max(1, int(ceil(len(target) / cols)))
        col_widths = [0.0 for _ in range(cols)]
        row_heights = [0.0 for _ in range(rows)]
        for index, node in enumerate(target):
            row = index // cols
            col = index % cols
            col_widths[col] = max(col_widths[col], _node_width(node))
            row_heights[row] = max(row_heights[row], _node_height(node))
        x_positions = [0.0 for _ in range(cols)]
        y_positions = [0.0 for _ in range(rows)]
        cursor_x = 0.0
        for col in range(cols):
            x_positions[col] = cursor_x
            cursor_x += axis_advance(context, col_widths[col], self.x_spacing, 'HORIZONTAL')
        cursor_y = 0.0
        for row in range(rows):
            y_positions[row] = -cursor_y
            cursor_y += axis_advance(context, row_heights[row], self.y_spacing, 'VERTICAL')
        for index, node in enumerate(target):
            row = index // cols
            col = index % cols
            _set_absolute_location(node, Vector((x_positions[col], y_positions[row])))
        new_center = Vector((sum(_absolute_location(n).x for n in target) / len(target), sum(_absolute_location(n).y for n in target) / len(target)))
        delta = center - new_center
        for node in target:
            _set_absolute_location(node, _absolute_location(node) + delta)
        snap_nodes_to_major_grid(target, context, _absolute_location, _set_absolute_location)
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_snap_to_grid(Operator):
    bl_idname = 'smart_node_suite.snap_to_grid'
    bl_label = 'Snap Nodes to Grid'
    bl_description = _tip(
        'Function: snaps node positions to a fixed grid for cleaner graph spacing. How to use: select nodes and press the button. If nothing is selected, all nodes are snapped.',
        '機能: ノード位置を固定グリッドにスナップし、グラフ間隔を整理します。使い方: ノードを選択して押します。何も選んでいない時は全ノードをスナップします。',
    )
    bl_options = {'UNDO'}

    grid_size: FloatProperty(name='Grid Size', default=40.0, min=1.0, max=1000.0, description=_tip('Function: sets the grid interval used for snapping when Major Grid Unit is disabled for this operation. How to use: use smaller values for fine layouts or larger values for blocky production templates.', '機能: この操作で太いグリッド単位を使わない場合に、スナップ間隔を設定します。使い方: 細かな配置には小さめ、テンプレート的な大まかな配置には大きめを使います。'))
    use_major_grid: BoolProperty(name='Use Major Grid Unit', default=True, description=_tip('Function: snaps to the configured Major Grid Unit instead of the local Grid Size field. How to use: keep enabled when matching the thick grid-dot layout spacing; disable for custom numeric snapping.', '機能: この欄のグリッドサイズではなく、設定済みの太いグリッド単位へスナップします。使い方: 太いグリッド点基準のレイアウト間隔に合わせる場合は有効、任意の数値スナップを使う場合は無効にします。'))
    only_selected: BoolProperty(name='Only Selected', default=True, description=_tip('Function: limits snapping to selected nodes. How to use: keep enabled for local cleanup; disable to snap the whole edited node tree.', '機能: スナップ対象を選択ノードだけに限定します。使い方: 局所整理では有効、ノードツリー全体を整える場合は無効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=self.only_selected) if self.only_selected else _normal_nodes(nodes)
        if self.only_selected and not target:
            target = _normal_nodes(nodes)
        size = major_grid_size(context) if bool(self.use_major_grid) else max(float(self.grid_size), 1.0)
        for node in target:
            loc = _absolute_location(node)
            loc.x = round(loc.x / size) * size
            loc.y = round(loc.y / size) * size
            _set_absolute_location(node, loc)
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_select_linked_branch(Operator):
    bl_idname = 'smart_node_suite.select_linked_branch'
    bl_label = 'Select Linked Branch'
    bl_description = _tip(
        'Function: selects all upstream, downstream, or fully connected nodes linked to the current selection. How to use: select one or more seed nodes and press Upstream, Downstream, or Connected. The result replaces the current selection.',
        '機能: 現在の選択からリンクをたどり、上流、下流、接続全体のノードを選択します。使い方: 起点ノードを1つ以上選択し、「上流」「下流」「接続全体」のどれかを押します。今の選択は結果に置き換わります。',
    )
    bl_options = set()

    direction: EnumProperty(
        name='Direction',
        items=(('UPSTREAM', 'Upstream', 'Select input/dependency nodes.'), ('DOWNSTREAM', 'Downstream', 'Select output/dependent nodes.'), ('BOTH', 'Connected', 'Select the full connected branch.')),
        default='BOTH',
        description=_tip('Function: chooses which link direction to follow from the selected seed nodes. How to use: Upstream finds inputs, Downstream finds outputs, Connected finds the whole branch.', '機能: 選択した起点ノードからたどるリンク方向を選びます。使い方: 上流は入力側、下流は出力側、接続全体はブランチ全体を探します。'),
    )
    extend: BoolProperty(name='Extend Selection', default=False, description=_tip('Function: keeps the current selection while adding linked nodes. How to use: enable this when building a larger selection step by step.', '機能: 現在の選択を残したままリンク先ノードを追加します。使い方: 段階的に大きな選択範囲を作る場合に有効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        seeds = _selected_or_active(nodes)
        if not seeds:
            return {'CANCELLED'}
        out_map, in_map = _graph(all_nodes, links)
        target = _collect_connected(seeds, out_map, in_map, self.direction)
        if not self.extend:
            for node in all_nodes:
                node.select = False
        for node in target:
            node.select = True
        self.report({'INFO'}, _t('Selected {count} linked nodes.', '{count} 個のリンクノードを選択しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_select_terminal_nodes(Operator):
    bl_idname = 'smart_node_suite.select_terminal_nodes'
    bl_label = 'Select Terminal Nodes'
    bl_description = _tip(
        'Function: selects source nodes with no inputs, sink nodes with no outputs, or both inside the selected branch or entire node tree. How to use: use this to find graph starts, outputs, or isolated endpoints before arranging or framing.',
        '機能: 選択ブランチまたはノードツリー全体から、入力のないソースノード、出力のない終端ノード、またはその両方を選択します。使い方: 整列やフレーム化の前に、グラフの開始点、出力、孤立端点を探す時に使います。',
    )
    bl_options = set()

    mode: EnumProperty(name='Scope', items=(('SOURCES', 'Sources', 'Select nodes that have no incoming links.'), ('SINKS', 'Sinks', 'Select nodes that have no outgoing links.'), ('BOTH', 'Both', 'Select both source and sink nodes.')), default='BOTH', description=_tip('Function: chooses which terminal node type to select. How to use: Sources finds graph inputs; Sinks finds graph outputs; Both finds all endpoints.', '機能: 選択する端点タイプを選びます。使い方: ソースはグラフ入力、終端はグラフ出力、両方向はすべての端点を探します。'))
    branch_only: BoolProperty(name='Only Selected', default=False, description=_tip('Function: limits endpoint search to the connected branch around the current selection. How to use: enable this when you do not want endpoints from unrelated node islands.', '機能: 端点検索を現在選択している接続ブランチ内に限定します。使い方: 無関係なノード島の端点を選びたくない場合に有効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        if self.branch_only and _selected_or_active(nodes):
            out_map_all, in_map_all = _graph(all_nodes, links)
            candidates = _collect_connected(_selected_or_active(nodes), out_map_all, in_map_all, 'BOTH')
        else:
            candidates = all_nodes
        out_map, in_map = _graph(candidates, links)
        selected = []
        for node in candidates:
            is_source = len(in_map.get(node, ())) == 0
            is_sink = len(out_map.get(node, ())) == 0
            if (self.mode in {'SOURCES', 'BOTH'} and is_source) or (self.mode in {'SINKS', 'BOTH'} and is_sink):
                selected.append(node)
        for node in all_nodes:
            node.select = False
        for node in selected:
            node.select = True
        self.report({'INFO'}, _t('Selected {count} terminal nodes.', '{count} 個の端点ノードを選択しました。').format(count=len(selected)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_select_same_type(Operator):
    bl_idname = 'smart_node_suite.select_same_type'
    bl_label = 'Select Same Type'
    bl_description = _tip(
        'Function: selects all nodes in the tree with the same Blender node type as the active node. How to use: click one example node and run this command.',
        '機能: アクティブノードと同じ Blender ノードタイプを持つノードを、ツリー全体から選択します。使い方: 例となるノードを1つクリックして実行します。',
    )
    bl_options = set()

    only_selected: BoolProperty(name='Only Selected', default=False, description=_tip('Function: filters only the current selected nodes by type. How to use: enable this after making a broad selection and narrowing it to the active node type.', '機能: 現在選択中のノードだけをタイプで絞り込みます。使い方: 大きめの選択範囲を作ったあと、アクティブノードと同じタイプだけに絞る場合に有効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        active = getattr(nodes, 'active', None) or getattr(context, 'active_node', None)
        if active not in all_nodes:
            self.report({'WARNING'}, _t('No active node is available.', 'アクティブノードがありません。'))
            return {'CANCELLED'}
        target_id = getattr(active, 'bl_idname', '') or getattr(active, 'type', '')
        candidates = _normal_nodes(nodes, selected_only=True) if self.only_selected else all_nodes
        if not self.only_selected:
            for node in all_nodes:
                node.select = False
        count = 0
        for node in candidates:
            if (getattr(node, 'bl_idname', '') or getattr(node, 'type', '')) == target_id:
                node.select = True
                count += 1
            elif self.only_selected:
                node.select = False
        self.report({'INFO'}, _t('Selected {count} nodes of the same type.', '同じタイプのノードを {count} 個選択しました。').format(count=count))
        return {'FINISHED'}


def _frame_items(nodes, target) -> list:
    """新しいフレームへ入れる単位を返す。中身が全部 target の既存フレームは、ばらさずフレームごと入れる。"""
    children = defaultdict(list)
    for node in nodes:
        parent = getattr(node, 'parent', None)
        if parent is not None:
            children[parent].append(node)
    target_set = set(target)

    def covered(frame):
        kids = children.get(frame)
        return bool(kids) and all(kid in target_set or covered(kid) for kid in kids)

    items = []
    for node in target:
        item = node
        parent = getattr(item, 'parent', None)
        while parent is not None and covered(parent):
            item = parent
            parent = getattr(item, 'parent', None)
        if item not in items:
            items.append(item)
    return items


class SMART_NODE_SUITE_OT_frame_branch(Operator):
    bl_idname = 'smart_node_suite.frame_branch'
    bl_label = 'Create Backdrop Frame'
    bl_description = _tip(
        'Function: creates a Blender Frame around nodes, similar to backdrop/group organization in node-based paint and material tools. Create Backdrop Frame frames the selected nodes only; Frame Upstream, Frame Downstream, and Frame Connected also include the linked nodes. A frame that already holds only the framed nodes goes into the new frame as it is, so your groups are kept. How to use: select nodes or a seed node and press the button for the range you want. Change the frame label in the Node tab of the sidebar.',
        '機能: ノードベースのペイント/マテリアルツールにあるバックドロップやグループ整理に近い形で、ノードを Blender のフレームで囲みます。「背景フレームを作成」は選択ノードだけ、「上流まで囲む」「下流まで囲む」「接続全体を囲む」はつながるノードも一緒に囲みます。囲むノードだけが入った既存のフレームは、そのまま新しいフレームの中に入り、まとまりを保ちます。使い方: ノードまたは起点ノードを選択し、囲みたい範囲のボタンを押します。フレームのラベルはサイドバーの「ノード」タブで変更します。',
    )
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=(('SELECTED', 'Selected', 'Frame selected nodes only.'), ('UPSTREAM', 'Upstream', 'Frame selected nodes and upstream dependencies.'), ('DOWNSTREAM', 'Downstream', 'Frame selected nodes and downstream dependents.'), ('BOTH', 'Connected', 'Frame the entire connected branch.')), default='SELECTED', description=_tip('Function: chooses which nodes are placed in the new frame. How to use: Selected is safest; Upstream/Downstream/Connected automatically collects linked branch nodes.', '機能: 新しいフレームへ入れるノード範囲を選びます。使い方: 選択中が最も安全です。上流/下流/接続全体はリンクブランチを自動収集します。'))
    label: StringProperty(name='Frame Label', default='', description=_tip('Function: sets the visible label on the created frame. How to use: enter a short purpose name such as Base Color, Mask, Utility, or Output.', '機能: 作成するフレームの表示ラベルを設定します。使い方: Base Color、Mask、Utility、Output など用途が分かる短い名前を入力します。'))
    margin: FloatProperty(name='Margin', default=80.0, min=0.0, max=1000.0, description=_tip('Function: adds empty space around the framed nodes. How to use: increase this when labels or links touch the frame border.', '機能: フレーム内のノード周囲に余白を追加します。使い方: ラベルやリンクがフレーム枠に近い場合は値を大きくします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        if self.scope == 'SELECTED':
            target = _normal_nodes(nodes, selected_only=True)
        else:
            seeds = _selected_or_active(nodes)
            out_map, in_map = _graph(all_nodes, links)
            target = _collect_connected(seeds, out_map, in_map, self.scope)
        target = [node for node in target if getattr(node, 'type', '') != 'FRAME']
        if not target:
            self.report({'WARNING'}, _t('No nodes are available for framing.', 'フレーム化できるノードがありません。'))
            return {'CANCELLED'}
        left, top, right, bottom = _bounds(target)
        tree = getattr(context.space_data, 'edit_tree', None)
        if tree is None:
            return {'CANCELLED'}
        items = _frame_items(nodes, target)
        if len(items) == 1 and getattr(items[0], 'type', '') == 'FRAME':
            self.report({'INFO'}, _t('These nodes are already in one frame.', 'これらのノードはすでに 1 つのフレームに入っています。'))
            return {'CANCELLED'}
        parents = {getattr(item, 'parent', None) for item in items}
        placed = [(item, _absolute_location(item)) for item in items]
        frame = tree.nodes.new(type='NodeFrame')
        frame.label = str(self.label or _t('Smart Node Frame', 'Smart Node フレーム'))
        frame.name = frame.label
        if len(parents) == 1:
            frame.parent = next(iter(parents))
        _set_absolute_location(frame, Vector((left - self.margin, top + self.margin)))
        for item, abs_loc in placed:
            try:
                item.parent = frame
                _set_absolute_location(item, abs_loc)
            except Exception:
                pass
        frame.select = True
        try:
            nodes.active = frame
        except Exception:
            pass
        self.report({'INFO'}, _t('Created frame for {count} nodes.', '{count} 個のノードを囲むフレームを作成しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_collapse_expand_nodes(Operator):
    bl_idname = 'smart_node_suite.collapse_expand_nodes'
    bl_label = 'Collapse / Expand Nodes'
    bl_description = _tip(
        'Function: collapses, expands, or toggles selected node cards to manage dense graphs. How to use: select nodes and choose Collapse to reduce visual size or Expand to edit sockets and settings again.',
        '機能: 選択ノードカードを折りたたみ、展開、または切り替えて、密なグラフを管理します。使い方: ノードを選択し、表示を小さくしたい場合は折りたたみ、ソケットや設定を編集する場合は展開を選びます。',
    )
    bl_options = {'UNDO'}

    action: EnumProperty(name='Direction', items=(('COLLAPSE', 'Collapse', 'Collapse selected nodes.'), ('EXPAND', 'Expand', 'Expand selected nodes.'), ('TOGGLE', 'Toggle', 'Toggle collapsed state for selected nodes.')), default='TOGGLE', description=_tip('Function: chooses the collapsed-state operation. How to use: Toggle is fast; use Collapse or Expand when you need a predictable result.', '機能: 折りたたみ状態の操作を選びます。使い方: すばやく切り替えるなら「切替」、確実に結果を決めたい場合は「折りたたむ」か「展開」を使います。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if not target:
            target = _normal_nodes(nodes)
        for node in target:
            if self.action == 'COLLAPSE':
                node.hide = True
            elif self.action == 'EXPAND':
                node.hide = False
            else:
                node.hide = not bool(getattr(node, 'hide', False))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_mute_unmute_nodes(Operator):
    bl_idname = 'smart_node_suite.mute_unmute_nodes'
    bl_label = 'Mute / Unmute Nodes'
    bl_description = _tip(
        'Function: mutes, unmutes, or toggles selected nodes without deleting them. How to use: use this to temporarily bypass parts of a material, compositor, or geometry setup while keeping the graph structure available.',
        '機能: 選択ノードを削除せずにミュート、ミュート解除、または切り替えます。使い方: マテリアル、コンポジター、ジオメトリ設定の一部を一時的にバイパスしつつ、グラフ構造を残したい場合に使います。',
    )
    bl_options = {'UNDO'}

    action: EnumProperty(name='Direction', items=(('MUTE', 'Mute', 'Mute selected nodes.'), ('UNMUTE', 'Unmute', 'Unmute selected nodes.'), ('TOGGLE', 'Toggle', 'Toggle mute state for selected nodes.')), default='TOGGLE', description=_tip('Function: chooses the mute operation. How to use: Toggle is fast; use Mute or Unmute for a predictable branch state.', '機能: ミュート操作を選びます。使い方: すばやく切り替えるなら「切替」、ブランチの状態を確実に決める場合は「ミュート」か「ミュート解除」を使います。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if not target:
            target = _normal_nodes(nodes)
        count = 0
        for node in target:
            if not hasattr(node, 'mute'):
                continue
            if self.action == 'MUTE':
                node.mute = True
            elif self.action == 'UNMUTE':
                node.mute = False
            else:
                node.mute = not bool(getattr(node, 'mute', False))
            count += 1
        self.report({'INFO'}, _t('Updated mute state on {count} nodes.', '{count} 個のノードのミュート状態を更新しました。').format(count=count))
        return {'FINISHED'}


def _display_text(text: str) -> str:
    return bpy.app.translations.pgettext_iface(text) if text else ''


def _header_texts(node) -> list:
    """Names shown in a node header besides its type: data names and the chosen operation."""
    texts = []
    for attr in ('node_tree', 'image'):
        data = getattr(node, attr, None)
        if data is not None:
            texts.append(data.name)
    props = ['operation', 'filter_type']
    if getattr(node, 'bl_idname', '') != 'ShaderNodeMix' or getattr(node, 'data_type', '') == 'RGBA':
        props.append('blend_type')
    for prop_name in props:
        value = getattr(node, prop_name, None)
        prop = node.bl_rna.properties.get(prop_name)
        if not isinstance(value, str) or prop is None or prop.type != 'ENUM':
            continue
        item = prop.enum_items.get(value)
        if item is not None:
            texts.append(item.name)
            texts.append(bpy.app.translations.pgettext_iface(item.name, prop.translation_context))
    return texts


class SMART_NODE_SUITE_OT_select_by_text(Operator):
    bl_idname = 'smart_node_suite.select_by_text'
    bl_label = 'Select Nodes by Text'
    bl_description = _tip(
        'Function: selects nodes by matching text against names, labels, node types, and socket names. How to use: press the button, enter a search word such as color, normal, bsdf, or reroute in the dialog, choose Target, and confirm with OK to isolate matching nodes in large graphs.',
        '機能: ノード名、ラベル、ノードタイプ、ソケット名に含まれる文字でノードを選択します。使い方: 押すと開く画面で、color、normal、bsdf、reroute などの検索文字を入れ、「ターゲット」を選んで OK を押すと、大きなグラフ内の一致ノードを選択できます。',
    )
    bl_options = set()
    bl_property = 'query'

    query: StringProperty(
        name='Search Text',
        default='',
        description=_tip(
            'Function: text used to find matching nodes. How to use: enter a partial node name, label, Blender node type, or socket name; empty text cancels the search to avoid accidental full selection.',
            '機能: 一致ノードを探すための検索文字です。使い方: ノード名、ラベル、Blenderノードタイプ、ソケット名の一部を入力します。空欄では誤選択防止のため検索を中止します。',
        ),
    )
    target: EnumProperty(
        name='Target',
        items=(
            ('NAME_LABEL', 'Name / Label', 'Search node names, labels, and the names shown in node headers.'),
            ('TYPE', 'Node Type', 'Search the internal English type name, such as math or bsdf.'),
            ('SOCKETS', 'Sockets', 'Search input and output socket names.'),
            ('ALL', 'All Text Fields', 'Search names, labels, types, and socket names.'),
        ),
        default='NAME_LABEL',
        description=_tip(
            'Function: chooses which node text fields are searched. How to use: use Name / Label for names, labels, and header text, Node Type for internal English type names such as math or bsdf, Sockets for input/output names, or All Text Fields for a broad search.',
            '機能: 検索対象にするノード文字情報を選びます。使い方: 名前やラベル、見出しの文字は「名前 / ラベル」、math や bsdf などの内部の英語の種類名は「ノードタイプ」、入出力の名前は「ソケット」、広く探す場合は「すべての文字フィールド」を使います。',
        ),
    )
    match_case: BoolProperty(
        name='Match Case',
        default=False,
        description=_tip(
            'Function: requires uppercase and lowercase letters to match exactly. How to use: leave disabled for normal searches; enable when similar names differ only by case.',
            '機能: 大文字と小文字を区別して完全に一致させます。使い方: 通常検索では無効のままにし、大小文字だけが異なる名前を区別したい場合に有効にします。',
        ),
    )
    extend: BoolProperty(
        name='Extend Selection',
        default=False,
        description=_tip(
            'Function: keeps existing selected nodes while adding search results. How to use: enable this when building a working set from multiple searches.',
            '機能: 既存の選択を残したまま検索結果を追加します。使い方: 複数回の検索で作業対象を増やす場合に有効にします。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'query')
        layout.prop(self, 'target')
        layout.prop(self, 'match_case')
        layout.prop(self, 'extend')

    def _texts_for_node(self, node):
        texts = []
        if self.target in {'NAME_LABEL', 'ALL'}:
            texts.extend([getattr(node, 'name', ''), getattr(node, 'label', ''), _display_text(getattr(node, 'bl_label', ''))])
            texts.extend(_header_texts(node))
        if self.target in {'TYPE', 'ALL'}:
            texts.extend([getattr(node, 'type', ''), getattr(node, 'bl_idname', '')])
        if self.target in {'SOCKETS', 'ALL'}:
            try:
                texts.extend(_display_text(sock.name) for sock in node.inputs)
                texts.extend(sock.name for sock in node.inputs)
            except Exception:
                pass
            try:
                texts.extend(_display_text(sock.name) for sock in node.outputs)
                texts.extend(sock.name for sock in node.outputs)
            except Exception:
                pass
        return [str(t) for t in texts if str(t)]

    def execute(self, context):
        query = str(self.query or '')
        if not query:
            self.report({'WARNING'}, _t('Enter search text before selecting nodes.', 'ノード選択前に検索文字を入力してください。'))
            return {'CANCELLED'}
        needle = query if self.match_case else query.lower()
        nodes, _links = get_nodes_links(context)
        candidates = _normal_nodes(nodes, include_frames=True)
        if not self.extend:
            for node in candidates:
                node.select = False
        matched = []
        for node in candidates:
            haystack = self._texts_for_node(node)
            if not self.match_case:
                haystack = [text.lower() for text in haystack]
            if any(needle in text for text in haystack):
                node.select = True
                matched.append(node)
        if matched:
            try:
                nodes.active = matched[-1]
            except Exception:
                pass
        self.report({'INFO'}, _t('Selected {count} matching nodes.', '一致したノードを {count} 個選択しました。').format(count=len(matched)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_select_graph_state(Operator):
    bl_idname = 'smart_node_suite.select_graph_state'
    bl_label = 'Select Nodes by State'
    bl_description = _tip(
        'Function: selects nodes by graph-management state such as unconnected, muted, collapsed, framed, unframed, or reroute nodes. How to use: choose a state and run this command before cleanup, framing, deletion, or layout operations.',
        '機能: 未接続、ミュート、折りたたみ、フレーム内、フレーム外、リルートなど、管理状態に応じてノードを選択します。使い方: 状態を選んで実行し、クリーンアップ、フレーム化、削除、整列の前処理に使います。',
    )
    bl_options = set()

    state: EnumProperty(
        name='State',
        items=(
            ('UNCONNECTED', 'Unconnected', 'Select nodes with no incoming or outgoing links.'),
            ('MUTED', 'Muted', 'Select muted nodes.'),
            ('COLLAPSED', 'Collapsed', 'Select collapsed node cards.'),
            ('FRAMED', 'Inside Frames', 'Select nodes that have a parent frame.'),
            ('UNFRAMED', 'Outside Frames', 'Select nodes that do not have a parent frame.'),
            ('REROUTES', 'Reroutes', 'Select reroute nodes.'),
        ),
        default='UNCONNECTED',
        description=_tip(
            'Function: chooses the graph state used for selection. How to use: Unconnected finds loose nodes; Muted and Collapsed find bypassed or compacted nodes; Framed and Unframed help organize branches; Reroutes isolates routing nodes.',
            '機能: 選択に使うグラフ状態を選びます。使い方: 未接続は孤立ノード、ミュート/折りたたみは一時処理や圧縮表示ノード、フレーム内/外はブランチ整理、リルートは配線整理用ノードの抽出に使います。',
        ),
    )
    extend: BoolProperty(
        name='Extend Selection',
        default=False,
        description=_tip(
            'Function: keeps the current selection while adding nodes that match the chosen state. How to use: enable this when combining multiple state selections.',
            '機能: 現在の選択を残し、指定状態に一致するノードを追加します。使い方: 複数状態の選択を組み合わせる場合に有効にします。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes, include_frames=True)
        link_counts = defaultdict(int)
        for link in links:
            try:
                if not bool(getattr(link, 'is_valid', True)):
                    continue
                link_counts[link.from_node] += 1
                link_counts[link.to_node] += 1
            except Exception:
                pass
        if not self.extend:
            for node in all_nodes:
                node.select = False
        matched = []
        for node in all_nodes:
            state_match = False
            if self.state == 'UNCONNECTED':
                state_match = link_counts.get(node, 0) == 0 and getattr(node, 'type', '') != 'FRAME'
            elif self.state == 'MUTED':
                state_match = bool(getattr(node, 'mute', False))
            elif self.state == 'COLLAPSED':
                state_match = bool(getattr(node, 'hide', False))
            elif self.state == 'FRAMED':
                state_match = getattr(node, 'parent', None) is not None
            elif self.state == 'UNFRAMED':
                state_match = getattr(node, 'parent', None) is None and getattr(node, 'type', '') != 'FRAME'
            elif self.state == 'REROUTES':
                state_match = getattr(node, 'bl_idname', '') == 'NodeReroute' or getattr(node, 'type', '') == 'REROUTE'
            if state_match:
                node.select = True
                matched.append(node)
        if matched:
            try:
                nodes.active = matched[-1]
            except Exception:
                pass
        self.report({'INFO'}, _t('Selected {count} nodes by state.', '状態に一致するノードを {count} 個選択しました。').format(count=len(matched)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_rename_selected_nodes(Operator):
    bl_idname = 'smart_node_suite.rename_selected_nodes'
    bl_label = 'Rename Selected Nodes'
    bl_description = _tip(
        'Function: renames selected nodes and optional visible labels in one pass. How to use: press the button, then enter a new name, prefix, suffix, or find/replace text, or enable numbering, in the dialog and confirm with OK.',
        '機能: 選択ノード名と必要に応じて表示ラベルを一括変更します。使い方: 押すと開く画面で、新規名、接頭辞、接尾辞、検索/置換、連番を設定して OK を押します。大きなノードグラフを読みやすく検索しやすい名前に整理できます。',
    )
    bl_options = {'UNDO'}
    bl_property = 'new_name'

    new_name: StringProperty(
        name='New Name',
        default='',
        options={'SKIP_SAVE'},
        description=_tip(
            'Function: replaces the current name of each selected node with this text. How to use: leave empty to keep the current names and only apply the other fields.',
            '機能: 選択ノードの今の名前を、この文字に置き換えます。使い方: 空欄なら今の名前のまま、ほかの欄だけを適用します。',
        ),
    )
    prefix: StringProperty(
        name='Prefix',
        default='',
        options={'SKIP_SAVE'},
        description=_tip(
            'Function: text added to the beginning of each selected node name or label. How to use: enter a short category such as MAT_, MASK_, UTIL_, or OUT_.',
            '機能: 選択ノード名またはラベルの先頭に追加する文字です。使い方: MAT_、MASK_、UTIL_、OUT_ など短い分類名を入力します。',
        ),
    )
    suffix: StringProperty(
        name='Suffix',
        default='',
        options={'SKIP_SAVE'},
        description=_tip(
            'Function: text added to the end of each selected node name or label. How to use: use this for branch names, version tags, or material purpose notes.',
            '機能: 選択ノード名またはラベルの末尾に追加する文字です。使い方: ブランチ名、バージョンタグ、マテリアル用途メモなどに使います。',
        ),
    )
    find: StringProperty(
        name='Find',
        default='',
        options={'SKIP_SAVE'},
        description=_tip(
            'Function: text to search for inside existing node names or labels. How to use: enter the old fragment you want to replace; leave empty to skip replacement.',
            '機能: 既存のノード名またはラベル内で探す文字です。使い方: 置き換えたい古い文字列を入力します。空欄の場合、置換処理は行いません。',
        ),
    )
    replace: StringProperty(
        name='Replace',
        default='',
        options={'SKIP_SAVE'},
        description=_tip(
            'Function: replacement text used with Find. How to use: enter the new fragment that should replace each matched old fragment.',
            '機能: 「検索」で見つけた文字列の置換先です。使い方: 一致した古い文字列を置き換える新しい文字列を入力します。',
        ),
    )
    numbering: BoolProperty(
        name='Add Numbering',
        default=False,
        description=_tip(
            'Function: appends sequential numbers to each selected node. How to use: enable this when creating ordered names for repeated utility, mask, or texture nodes.',
            '機能: 選択ノードへ連番を追加します。使い方: 繰り返し使うユーティリティ、マスク、テクスチャノードを順序付きの名前にしたい場合に有効にします。',
        ),
    )
    start_index: IntProperty(
        name='Start Index',
        default=1,
        min=0,
        max=100000,
        description=_tip(
            'Function: first number used by Add Numbering. How to use: set 1 for normal counting or another value when continuing an existing naming sequence.',
            '機能: 連番追加で使う最初の番号です。使い方: 通常は 1、既存の命名連番に続けたい場合は任意の開始番号を指定します。',
        ),
    )
    digits: IntProperty(
        name='Digits',
        default=2,
        min=1,
        max=8,
        description=_tip(
            'Function: minimum digit count for added numbers. How to use: use 2 for 01, 02 style names or 3 for 001, 002 style production names.',
            '機能: 追加する数字の最小桁数です。使い方: 01、02 形式なら 2、001、002 形式の制作名なら 3 を指定します。',
        ),
    )
    affect_label: BoolProperty(
        name='Rename Visible Label',
        default=True,
        description=_tip(
            'Function: also writes the renamed text into the visible node label. How to use: keep enabled when the graph should show the cleaned names directly; disable when internal node names only should change.',
            '機能: 変更後の文字を表示ラベルにも書き込みます。使い方: グラフ上に整理済み名を直接表示したい場合は有効、内部ノード名だけ変えたい場合は無効にします。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def invoke(self, context, event):
        nodes, _links = get_nodes_links(context)
        if not _normal_nodes(nodes, selected_only=True, include_frames=True):
            self.report({'WARNING'}, _t('Select nodes before renaming.', 'リネームするノードを選択してください。'))
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'new_name')
        layout.prop(self, 'prefix')
        layout.prop(self, 'suffix')
        layout.prop(self, 'find')
        layout.prop(self, 'replace')
        layout.prop(self, 'numbering')
        row = layout.row()
        row.enabled = self.numbering
        row.prop(self, 'start_index')
        row = layout.row()
        row.enabled = self.numbering
        row.prop(self, 'digits')
        layout.prop(self, 'affect_label')

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True, include_frames=True)
        if not target:
            self.report({'WARNING'}, _t('Select nodes before renaming.', 'リネームするノードを選択してください。'))
            return {'CANCELLED'}
        if not (self.new_name or self.prefix or self.suffix or self.find or self.numbering):
            self.report({'WARNING'}, _t('Enter the text to change.', '変更する文字を入力してください。'))
            return {'CANCELLED'}
        target.sort(key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name))
        changes = []
        for index, node in enumerate(target, start=int(self.start_index)):
            name = str(getattr(node, 'name', '') or 'Node')
            current = str(getattr(node, 'label', '') or name) if self.affect_label else name
            base = str(self.new_name or current)
            if self.find:
                base = base.replace(str(self.find), str(self.replace))
            new_text = f'{self.prefix}{base}{self.suffix}'
            if self.numbering:
                new_text = f'{new_text}_{index:0{int(self.digits)}d}'
            if new_text == current and (name == new_text or not (self.new_name or self.numbering)):
                continue
            changes.append((node, name, new_text))
        # Free the names first so nodes renamed together do not collide with each other.
        for index, (node, _name, _new_text) in enumerate(changes):
            try:
                node.name = f'__smart_node_rename_{index}'
            except Exception:
                pass
        count = 0
        for node, name, new_text in changes:
            old_label = str(getattr(node, 'label', '') or '')
            try:
                node.name = new_text
            except Exception:
                pass
            if self.affect_label:
                try:
                    node.label = new_text
                except Exception:
                    pass
            if node.name != name or (self.affect_label and old_label != new_text):
                count += 1
        self.report({'INFO'}, _t('Renamed {count} selected nodes.', '選択ノードを {count} 個リネームしました。').format(count=count))
        return {'FINISHED'}

# ------------------------------------------------------------------------------
# DCC-style node layout and management additions
# ------------------------------------------------------------------------------

def _selected_or_all_normal(nodes, include_frames: bool = False) -> list:
    selected = _normal_nodes(nodes, selected_only=True, include_frames=include_frames)
    return selected or _normal_nodes(nodes, include_frames=include_frames)


def _connected_components(target_nodes, links) -> list[list]:
    target = [node for node in target_nodes if node is not None]
    if not target:
        return []
    node_set = set(target)
    neighbors = {node: set() for node in target}
    external_families = defaultdict(list)
    for link in links:
        try:
            a = link.from_node
            b = link.to_node
        except Exception:
            continue
        a_in = a in node_set
        b_in = b in node_set
        if a_in and b_in and not _same_node(a, b):
            neighbors[a].add(b)
            neighbors[b].add(a)
        elif a_in and not b_in:
            external_families[_node_identity(b)].append(a)
        elif b_in and not a_in:
            external_families[_node_identity(a)].append(b)

    # Selected sibling nodes often only meet at an unselected parent shader or
    # output node. Treat siblings sharing that external parent as one stream so
    # vertical stack/stream operations can order them by the parent's sockets.
    for family in external_families.values():
        unique = []
        for node in family:
            if node not in unique:
                unique.append(node)
        if len(unique) < 2:
            continue
        anchor = unique[0]
        for other in unique[1:]:
            neighbors[anchor].add(other)
            neighbors[other].add(anchor)

    components = []
    seen = set()
    for node in target:
        if node in seen:
            continue
        queue = deque([node])
        seen.add(node)
        group = []
        while queue:
            current = queue.popleft()
            group.append(current)
            for other in neighbors.get(current, ()):
                if other not in seen:
                    seen.add(other)
                    queue.append(other)
        components.append(group)
    components.sort(key=lambda group: (_bounds(group)[0], -_bounds(group)[1], len(group)))
    return components


def _align_group(target, mode: str, stack: bool = False, spacing: float = 40.0, context=None, links=None) -> int:
    target = [node for node in target if node is not None]
    if len(target) < 2:
        return len(target)
    left, top, right, bottom = _bounds(target)
    center_x = (left + right) * 0.5
    center_y = (top + bottom) * 0.5
    for node in target:
        loc = _absolute_location(node)
        if mode == 'LEFT':
            loc.x = left
        elif mode == 'CENTER_X':
            loc.x = center_x - _node_width(node) * 0.5
        elif mode == 'RIGHT':
            loc.x = right - _node_width(node)
        elif mode == 'TOP':
            loc.y = top
        elif mode == 'CENTER_Y':
            loc.y = center_y + _node_height(node) * 0.5
        elif mode == 'BOTTOM':
            loc.y = bottom + _node_height(node)
        _set_absolute_location(node, loc)

    if stack:
        gap = max(float(spacing), 0.0)
        if mode in {'LEFT', 'CENTER_X', 'RIGHT'}:
            ordered = _socket_aware_vertical_order(target, links or ())
            cursor_y = max(_absolute_location(n).y for n in ordered)
            for node in ordered:
                loc = _absolute_location(node)
                loc.y = cursor_y
                _set_absolute_location(node, loc)
                cursor_y -= axis_advance(context, _node_height(node), gap, 'VERTICAL')
        else:
            ordered = sorted(target, key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name))
            cursor_x = min(_absolute_location(n).x for n in ordered)
            for node in ordered:
                loc = _absolute_location(node)
                loc.x = cursor_x
                _set_absolute_location(node, loc)
                cursor_x += axis_advance(context, _node_width(node), gap, 'HORIZONTAL')
    return len(target)


def _link_endpoint_selected(link) -> bool:
    try:
        return bool(getattr(link.from_node, 'select', False) or getattr(link.to_node, 'select', False))
    except Exception:
        return False


def _link_both_endpoints_selected(link) -> bool:
    try:
        return bool(getattr(link.from_node, 'select', False) and getattr(link.to_node, 'select', False))
    except Exception:
        return False


def _socket_type(socket) -> str:
    try:
        return str(socket.type or '')
    except Exception:
        return ''


def _can_link_sockets(from_socket, to_socket) -> bool:
    a = _socket_type(from_socket)
    b = _socket_type(to_socket)
    if not a or not b:
        return True
    return a == b or a == 'CUSTOM' or b == 'CUSTOM'


class SMART_NODE_SUITE_OT_offset_branch(Operator):
    bl_idname = 'smart_node_suite.offset_branch'
    bl_label = 'Move Linked Branch'
    bl_description = _tip(
        'Function: moves the selected nodes and every node connected to them a fixed distance to the right (160), similar to Move Children behavior in node editors. How to use: select a seed node and run this command.',
        '機能: 選択ノードとつながるノード全部を、決まった距離（160）だけ右へ移動します。使い方: 起点ノードを選択して実行します。',
    )
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=(
            ('SELECTED', 'Selected', 'Move selected nodes only.'),
            ('UPSTREAM', 'Upstream', 'Move selected nodes and input/dependency nodes feeding them.'),
            ('DOWNSTREAM', 'Downstream', 'Move selected nodes and output/dependent nodes after them.'),
            ('BOTH', 'Connected', 'Move the full connected branch around the selection.'),
        ),
        default='BOTH',
        description=_tip('Function: chooses which nodes move with the seed selection. How to use: use Upstream for texture/map children, Downstream for dependent outputs, Connected for a whole node island, or Selected for only highlighted nodes.', '機能: 起点選択と一緒に動かすノード範囲を選びます。使い方: テクスチャ/マップ側の子は上流、出力側は下流、ノード島全体は接続全体、選択済みだけ動かす場合は選択中を使います。'),
    )
    offset_x: FloatProperty(name='X Offset', default=160.0, min=-10000.0, max=10000.0, description=_tip('Function: sets horizontal movement in node-editor units. How to use: positive values move right; negative values move left.', '機能: ノードエディター単位で横方向の移動量を設定します。使い方: 正の値で右、負の値で左へ移動します。'))
    offset_y: FloatProperty(name='Y Offset', default=0.0, min=-10000.0, max=10000.0, description=_tip('Function: sets vertical movement in node-editor units. How to use: positive values move up; negative values move down.', '機能: ノードエディター単位で縦方向の移動量を設定します。使い方: 正の値で上、負の値で下へ移動します。'))
    include_frames: BoolProperty(name='Include Frames', default=True, description=_tip('Function: also moves selected frame nodes with the branch. How to use: keep enabled when frames/backdrops are part of the organized branch.', '機能: 選択中のフレームノードもブランチと一緒に移動します。使い方: フレーム/バックドロップも整理単位に含める場合は有効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes, include_frames=self.include_frames)
        seeds = _selected_or_active(nodes)
        if self.scope == 'SELECTED':
            target = [node for node in all_nodes if bool(getattr(node, 'select', False))]
        else:
            if not seeds:
                self.report({'WARNING'}, _t('Select at least one seed node.', '起点ノードを1つ以上選択してください。'))
                return {'CANCELLED'}
            graph_nodes = _normal_nodes(nodes)
            out_map, in_map = _graph(graph_nodes, links)
            target = _collect_connected(seeds, out_map, in_map, self.scope)
            if self.include_frames:
                for node in all_nodes:
                    if getattr(node, 'type', '') == 'FRAME' and bool(getattr(node, 'select', False)) and node not in target:
                        target.append(node)
        if not target:
            self.report({'WARNING'}, _t('No nodes are available to move.', '移動できるノードがありません。'))
            return {'CANCELLED'}
        delta = Vector((float(self.offset_x), float(self.offset_y)))
        for node in target:
            _set_absolute_location(node, _absolute_location(node) + delta)
        self.report({'INFO'}, _t('Moved {count} nodes.', '{count} 個のノードを移動しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_hide_child_tree(Operator):
    bl_idname = 'smart_node_suite.hide_child_tree'
    bl_label = 'Hide / Show Child Tree'
    bl_description = _tip(
        'Function: switches the input-side (upstream) nodes of the selected parent node between collapsed and expanded. How to use: select a parent/output/material node and run this command. Run it again to switch back.',
        '機能: 選択した親ノードの入力側（上流）のノードの、折りたたみと展開を切り替えます。使い方: 親、出力、マテリアル相当のノードを選択して実行します。もう一度押すと元に戻ります。',
    )
    bl_options = {'UNDO'}

    action: EnumProperty(name='Action', items=(('HIDE', 'Hide', 'Hide/collapse child branch nodes.'), ('SHOW', 'Show', 'Show/expand child branch nodes.'), ('TOGGLE', 'Toggle', 'Toggle child branch visibility.')), default='TOGGLE', description=_tip('Function: chooses how the child tree display changes. How to use: Toggle is quick; Hide or Show gives predictable branch state.', '機能: 子ツリーの表示状態をどう変更するか選びます。使い方: 素早く切り替えるなら「切替」、確実に状態を決めたい場合は非表示または表示を使います。'))
    branch: EnumProperty(name='Scope', items=(('UPSTREAM', 'Upstream', 'Treat input/dependency nodes as children.'), ('DOWNSTREAM', 'Downstream', 'Treat output/dependent nodes as children.'), ('BOTH', 'Connected', 'Process the whole connected branch.')), default='UPSTREAM', description=_tip('Function: decides which linked nodes count as children. How to use: use Upstream for texture/map trees feeding a shader, Downstream for output-side branches, or Connected for both.', '機能: どのリンク方向を子として扱うか決めます。使い方: シェーダーへ入るテクスチャ/マップは上流、出力側のブランチは下流、両方は接続全体を使います。'))
    include_parent: BoolProperty(name='Include Parent', default=False, description=_tip('Function: also collapses or expands the selected parent node. How to use: keep disabled when the parent should remain readable as the branch anchor.', '機能: 選択した親ノードも折りたたみ/展開対象に含めます。使い方: 親ノードをブランチの目印として見せておきたい場合は無効のまま使います。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        all_nodes = _normal_nodes(nodes)
        seeds = _selected_or_active(nodes)
        if not seeds:
            self.report({'WARNING'}, _t('Select a parent node first.', '先に親ノードを選択してください。'))
            return {'CANCELLED'}
        out_map, in_map = _graph(all_nodes, links)
        target = _collect_connected(seeds, out_map, in_map, self.branch)
        if not self.include_parent:
            seed_set = set(seeds)
            target = [node for node in target if node not in seed_set]
        if not target:
            self.report({'WARNING'}, _t('No child nodes were found.', '子ノードが見つかりません。'))
            return {'CANCELLED'}
        for node in target:
            if self.action == 'HIDE':
                node.hide = True
            elif self.action == 'SHOW':
                node.hide = False
            else:
                node.hide = not bool(getattr(node, 'hide', False))
        self.report({'INFO'}, _t('Updated child tree display for {count} nodes.', '{count} 個の子ノード表示を更新しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_hide_unused_sockets(Operator):
    bl_idname = 'smart_node_suite.hide_unused_sockets'
    bl_label = 'Hide / Show Unused Sockets'
    bl_description = _tip(
        'Function: hides, shows, or toggles unlinked input/output sockets to make dense nodes easier to read. How to use: select nodes and press the button. Unused inputs and outputs switch between hidden and shown. If nothing is selected, all nodes are changed.',
        '機能: 未接続の入力/出力ソケットを非表示、表示、切替して、密なノードを読みやすくします。使い方: ノードを選択して押します。未接続の入力と出力の表示と非表示が切り替わります。何も選んでいない時は全ノードが対象です。',
    )
    bl_options = {'UNDO'}

    action: EnumProperty(name='Action', items=(('HIDE', 'Hide', 'Hide unused sockets.'), ('SHOW', 'Show', 'Show unused sockets.'), ('TOGGLE', 'Toggle', 'Toggle unused sockets.')), default='TOGGLE', description=_tip('Function: chooses how unused sockets are displayed. How to use: Hide cleans up dense cards; Show restores socket editing.', '機能: 未使用ソケットの表示状態を選びます。使い方: 非表示は密なノードを整理し、表示はソケット編集を戻します。'))
    include_inputs: BoolProperty(name='Inputs', default=True, description=_tip('Function: processes input sockets. How to use: keep enabled when cleaning shader, compositor, or geometry nodes with many unused inputs.', '機能: 入力ソケットを処理します。使い方: 未使用入力が多いシェーダー、コンポジター、ジオメトリノードの整理で有効にします。'))
    include_outputs: BoolProperty(name='Outputs', default=True, description=_tip('Function: processes output sockets. How to use: enable when output-heavy nodes should also be simplified.', '機能: 出力ソケットを処理します。使い方: 出力が多いノードも簡略表示したい場合に有効にします。'))
    only_selected: BoolProperty(name='Only Selected', default=True, description=_tip('Function: limits the operation to selected nodes. How to use: keep enabled for local cleanup; disable to process the whole editable tree.', '機能: 処理対象を選択ノードだけに限定します。使い方: 局所整理では有効、ツリー全体を処理する場合は無効にします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=self.only_selected) if self.only_selected else _normal_nodes(nodes)
        if self.only_selected and not target:
            target = _normal_nodes(nodes)
        count = 0
        for node in target:
            sockets = []
            if self.include_inputs:
                sockets.extend(getattr(node, 'inputs', ()))
            if self.include_outputs:
                sockets.extend(getattr(node, 'outputs', ()))
            for socket in sockets:
                try:
                    if bool(getattr(socket, 'is_linked', False)) or not hasattr(socket, 'hide'):
                        continue
                    if self.action == 'HIDE':
                        socket.hide = True
                    elif self.action == 'SHOW':
                        socket.hide = False
                    else:
                        socket.hide = not bool(getattr(socket, 'hide', False))
                    count += 1
                except Exception:
                    pass
        if count == 0:
            self.report({'WARNING'}, _t('No unused sockets were found.', '未使用ソケットが見つかりません。'))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Updated {count} unused sockets.', '{count} 個の未使用ソケットを更新しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_color_nodes(Operator):
    bl_idname = 'smart_node_suite.color_nodes'
    bl_label = 'Color Nodes'
    bl_description = _tip(
        'Function: gives the selected nodes one shared marker color (blue), or removes it with Reset Color. If nothing is selected, all nodes are changed. It does not color nodes by type. How to use: select the nodes of one role and press the button. Use Color 1 to Color 5 in Node Color Presets for other colors.',
        '機能: 選択ノードを同じ 1 色（青）の目印にします。「色をリセット」で色を外します。何も選んでいない時は全ノードが対象です。種類ごとの色分けはしません。使い方: 役割ごとにノードを選んで押します。別の色は「ノード色プリセット」の「色 1」〜「色 5」で付けます。',
    )
    bl_options = {'UNDO'}

    action: EnumProperty(
        name='Action',
        items=(
            ('APPLY', 'Apply Color', 'Apply the chosen custom color to the target nodes.'),
            ('RESET', 'Reset Color', 'Disable custom colors on the target nodes so Blender displays the default node type colors.'),
        ),
        default='APPLY',
        description=_tip('Function: chooses whether to apply a custom node color or return nodes to their default colors. How to use: use Apply Color for visual grouping and Reset Color when the group marker is no longer needed.', '機能: カスタムノード色を適用するか、標準色へ戻すかを選びます。使い方: 視覚的なグループ分けには色を適用、不要になった分類色を消す場合は色をリセットを使います。'),
    )
    scope: EnumProperty(
        name='Scope',
        items=(
            ('SELECTED', 'Selected', 'Change selected nodes only. If nothing is selected, all nodes are changed.'),
            ('BRANCH', 'Connected', 'Change the linked branch around the selected or active seed node.'),
            ('ALL', 'All', 'Change every node in the edited node tree.'),
        ),
        default='SELECTED',
        description=_tip('Function: chooses which nodes receive the color change. How to use: use Selected for manual groups, Connected for an upstream/downstream branch, or All for a full graph color reset.', '機能: 色変更の対象ノードを選びます。使い方: 手動グループは選択中、上流/下流ブランチは接続全体、全体リセットはすべてを使います。'),
    )
    branch: EnumProperty(
        name='Direction',
        items=(
            ('UPSTREAM', 'Upstream', 'Use nodes that feed into the selected seed.'),
            ('DOWNSTREAM', 'Downstream', 'Use nodes driven by the selected seed.'),
            ('BOTH', 'Connected', 'Use all connected nodes around the seed.'),
        ),
        default='BOTH',
        description=_tip('Function: chooses link direction when Scope is Connected. How to use: select Upstream for texture/map sources, Downstream for outputs, or Connected for both sides.', '機能: 対象範囲が接続全体の場合に、リンクをたどる方向を選びます。使い方: テクスチャ/マップ元は上流、出力側は下流、両側を含める場合は接続全体を使います。'),
    )
    color: FloatVectorProperty(
        name='Color',
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.35, 0.48, 0.75),
        description=_tip('Function: custom display color assigned to the target nodes. How to use: choose a color that marks a branch role such as texture sources, masks, utilities, outputs, or review items.', '機能: 対象ノードへ割り当てるカスタム表示色です。使い方: テクスチャ元、マスク、ユーティリティ、出力、確認項目などブランチの役割を区別できる色を選びます。'),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        if self.scope == 'BRANCH':
            target = _target_nodes_by_scope(nodes, links, 'BRANCH', self.branch)
        else:
            target = _target_nodes_by_scope(nodes, links, self.scope)
        target = [node for node in target if getattr(node, 'type', '') != 'FRAME']
        if not target:
            self.report({'WARNING'}, _t('No nodes are available for color changes.', '色変更できるノードがありません。'))
            return {'CANCELLED'}

        if self.action == 'RESET':
            for node in target:
                try:
                    node.use_custom_color = False
                except Exception:
                    pass
        else:
            value = tuple(float(v) for v in self.color[:3])
            for node in target:
                try:
                    node.use_custom_color = True
                    node.color = value
                except Exception:
                    pass
        self.report({'INFO'}, _t('Updated color on {count} nodes.', '{count} 個のノード色を更新しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_swap_node_positions(Operator):
    bl_idname = 'smart_node_suite.swap_node_positions'
    bl_label = 'Swap Node Positions'
    bl_description = _tip(
        'Function: swaps the editor positions of exactly two selected nodes. How to use: select two nodes and run this command to exchange their placement without changing links.',
        '機能: 選択した2つのノードのエディター上の位置を交換します。使い方: 2つのノードを選択して実行し、リンクを変えずに配置だけ入れ替えます。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True, include_frames=True)
        if len(target) != 2:
            self.report({'WARNING'}, _t('Select exactly two nodes to swap positions.', '位置を交換するノードをちょうど2つ選択してください。'))
            return {'CANCELLED'}
        a, b = target
        loc_a = _absolute_location(a)
        loc_b = _absolute_location(b)
        _set_absolute_location(a, loc_b)
        _set_absolute_location(b, loc_a)
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_stream_aware_align(Operator):
    bl_idname = 'smart_node_suite.stream_aware_align'
    bl_label = 'Stream-Aware Align'
    bl_description = _tip(
        'Function: aligns nodes per connected stream instead of forcing unrelated branches onto one global line. How to use: select nodes from several branches and press the button. Vertical centers are aligned inside each stream.',
        '機能: 関係のないブランチを1本の基準線へ押し込まず、接続ストリームごとに端や中心をそろえます。使い方: 複数ブランチのノードを選択して押します。流れごとに縦の中心をそろえます。',
    )
    bl_options = {'UNDO'}

    mode: EnumProperty(name='Direction', items=(('LEFT', 'Left', 'Align left edges inside each stream.'), ('CENTER_X', 'Center X', 'Align horizontal centers inside each stream.'), ('RIGHT', 'Right', 'Align right edges inside each stream.'), ('TOP', 'Top', 'Align top edges inside each stream.'), ('CENTER_Y', 'Center Y', 'Align vertical centers inside each stream.'), ('BOTTOM', 'Bottom', 'Align bottom edges inside each stream.')), default='CENTER_Y', description=_tip('Function: chooses the edge or center used inside each connected stream. How to use: Center Y works well for left-to-right node chains.', '機能: 各接続ストリーム内でそろえる端または中心を選びます。使い方: 左から右のノードチェーンでは中央Yが扱いやすいです。'))
    stack: BoolProperty(name='Stack', default=False, description=_tip('Function: prevents overlap by stacking nodes after alignment inside each stream. How to use: enable when nodes have different sizes.', '機能: ストリーム内で整列後にノードを積み、重なりを防ぎます。使い方: ノードサイズが異なる場合に有効です。'))
    spacing: FloatProperty(name='Spacing', default=50.0, min=0.0, max=2000.0, description=_tip('Function: sets the gap used when Stack is enabled. How to use: increase if titles or sockets are still too close.', '機能: スタック有効時の隙間を設定します。使い方: タイトルやソケットが近すぎる場合は値を大きくします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if len(target) < 2:
            self.report({'WARNING'}, _t('Select at least two nodes to align.', '整列するには2つ以上のノードを選択してください。'))
            return {'CANCELLED'}
        count = 0
        for component in _connected_components(target, links):
            count += _align_group(component, self.mode, self.stack, self.spacing, context=context, links=links)
            snap_aligned_nodes_to_major_grid(component, context, _absolute_location, _set_absolute_location)
        self.report({'INFO'}, _t('Stream-aligned {count} nodes.', '{count} 個のノードをストリーム単位で整列しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_stack_nodes(Operator):
    bl_idname = 'smart_node_suite.stack_nodes'
    bl_label = 'Stack Nodes'
    bl_description = _tip(
        'Function: stacks selected nodes into a clean column from top to bottom with a fixed readable gap. How to use: select loose nodes and run this command.',
        '機能: 選択ノードを固定の読みやすい間隔で、上から下へ縦列に積み直します。使い方: 散らばったノードを選択して実行します。',
    )
    bl_options = {'UNDO'}

    axis: EnumProperty(name='Direction', items=(('VERTICAL', 'Vertical', 'Stack from top to bottom.'), ('HORIZONTAL', 'Horizontal', 'Stack from left to right.')), default='VERTICAL', description=_tip('Function: chooses stack direction. How to use: Vertical is useful for sibling nodes in one dependency layer; Horizontal is useful for linear chains.', '機能: 積み方向を選びます。使い方: 同じ依存階層の兄弟ノードには縦、直線的なチェーンには横が便利です。'))
    spacing: FloatProperty(name='Spacing', default=80.0, min=0.0, max=2000.0, description=_tip('Function: sets the empty gap between stacked nodes. How to use: increase for large node cards or dense links.', '機能: 積み直したノード間の空き幅を設定します。使い方: 大きなノードカードや密なリンクでは値を大きくします。'))
    use_active_axis: BoolProperty(name='Use Active Node Axis', default=True, description=_tip('Function: uses the active node as the fixed alignment axis when possible. How to use: select the anchor node last to keep the stack lined up with it.', '機能: 可能な場合、アクティブノードを固定軸として使います。使い方: 基準にしたいノードを最後に選択してアクティブにします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        target = _normal_nodes(nodes, selected_only=True)
        if len(target) < 2:
            self.report({'WARNING'}, _t('Select at least two nodes to stack.', '積み直すには2つ以上のノードを選択してください。'))
            return {'CANCELLED'}
        active = getattr(nodes, 'active', None)
        gap = max(float(self.spacing), 0.0)
        if self.axis == 'VERTICAL':
            ordered = _socket_aware_vertical_order(target, links)
            x_anchor = _absolute_location(active).x if self.use_active_axis and active in target else min(_absolute_location(n).x for n in target)
            y = max(_absolute_location(n).y for n in target)
            for node in ordered:
                _set_absolute_location(node, Vector((x_anchor, y)))
                y -= axis_advance(context, _node_height(node), gap, 'VERTICAL')
        else:
            ordered = sorted(target, key=lambda n: (_absolute_location(n).x, -_absolute_location(n).y, n.name))
            y_anchor = _absolute_location(active).y if self.use_active_axis and active in target else max(_absolute_location(n).y for n in target)
            x = min(_absolute_location(n).x for n in target)
            for node in ordered:
                _set_absolute_location(node, Vector((x, y_anchor)))
                x += axis_advance(context, _node_width(node), gap, 'HORIZONTAL')
        snap_nodes_to_major_grid(target, context, _absolute_location, _set_absolute_location)
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_optimize_reroute_links(Operator):
    bl_idname = 'smart_node_suite.optimize_reroute_links'
    bl_label = 'Optimize Link Reroutes'
    bl_description = _tip(
        'Function: inserts Blender reroute nodes into selected links so long diagonal noodles can be guided as cleaner wire paths. How to use: select nodes around messy links, run this command, and use All Links only for full-tree cleanup.',
        '機能: 選択周辺のリンクへ Blender のリルートノードを挿入し、長い斜めリンクを整理しやすくします。使い方: 散らかったリンク周辺のノードを選択して実行します。全体整理の時だけ全リンク対象を使います。',
    )
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=(('TOUCH_SELECTED', 'Touch Selected', 'Process links touching selected nodes; if nothing is selected, process all links.'), ('BETWEEN_SELECTED', 'Between Selected', 'Process only links whose source and target are both selected.'), ('ALL', 'All', 'Process every link in the edited node tree.')), default='TOUCH_SELECTED', description=_tip('Function: chooses which links receive reroute nodes. How to use: Touch Selected is safest for local cleanup; All processes the whole graph.', '機能: どのリンクへリルートを追加するか選びます。使い方: 局所整理は選択に接続、全体整理はすべてを使います。'))
    style: EnumProperty(name='Style', items=(('TWO_POINT', 'Two Point', 'Create two reroutes to make a clearer elbow-style path.'), ('MIDPOINT', 'Midpoint', 'Create one reroute at the middle of the link.')), default='TWO_POINT', description=_tip('Function: chooses how many reroute points are inserted per link. How to use: Two Point gives more control for orthogonal wire paths; Midpoint is lighter.', '機能: 1本のリンクに追加するリルート数を選びます。使い方: 直交風に曲げたい場合は2点、軽く整理するだけなら中点を使います。'))
    skip_existing_reroutes: BoolProperty(name='Skip Existing Reroutes', default=True, description=_tip('Function: avoids processing links already connected to reroute nodes. How to use: keep enabled to prevent repeated reroute chains when running the command multiple times.', '機能: 既にリルートノードへ接続しているリンクを処理しません。使い方: コマンドを複数回実行する時にリルートが連続しすぎないよう有効のままにします。'))

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        tree = getattr(context.space_data, 'edit_tree', None)
        if tree is None:
            return {'CANCELLED'}
        nodes, links = get_nodes_links(context)
        selected_exists = any(bool(getattr(n, 'select', False)) for n in nodes)
        process_links = []
        for link in list(links):
            try:
                if not bool(getattr(link, 'is_valid', True)):
                    continue
                if self.skip_existing_reroutes and (getattr(link.from_node, 'type', '') == 'REROUTE' or getattr(link.to_node, 'type', '') == 'REROUTE'):
                    continue
                if self.scope == 'ALL' or not selected_exists:
                    process_links.append(link)
                elif self.scope == 'BETWEEN_SELECTED' and _link_both_endpoints_selected(link):
                    process_links.append(link)
                elif self.scope == 'TOUCH_SELECTED' and _link_endpoint_selected(link):
                    process_links.append(link)
            except Exception:
                pass
        if not process_links:
            self.report({'WARNING'}, _t('No links are available for reroute optimization.', 'リルート最適化できるリンクがありません。'))
            return {'CANCELLED'}
        count = 0
        for link in process_links[:200]:
            try:
                from_socket = link.from_socket
                to_socket = link.to_socket
                src = link.from_node
                dst = link.to_node
                src_loc = _absolute_location(src)
                dst_loc = _absolute_location(dst)
                tree.links.remove(link)
                if self.style == 'MIDPOINT':
                    r1 = tree.nodes.new(type='NodeReroute')
                    _set_absolute_location(r1, Vector(((src_loc.x + dst_loc.x) * 0.5, (src_loc.y + dst_loc.y) * 0.5)))
                    tree.links.new(from_socket, r1.inputs[0])
                    tree.links.new(r1.outputs[0], to_socket)
                    count += 1
                else:
                    r1 = tree.nodes.new(type='NodeReroute')
                    r2 = tree.nodes.new(type='NodeReroute')
                    mid_x = (src_loc.x + dst_loc.x) * 0.5
                    _set_absolute_location(r1, Vector((mid_x, src_loc.y)))
                    _set_absolute_location(r2, Vector((mid_x, dst_loc.y)))
                    tree.links.new(from_socket, r1.inputs[0])
                    tree.links.new(r1.outputs[0], r2.inputs[0])
                    tree.links.new(r2.outputs[0], to_socket)
                    count += 2
            except Exception:
                pass
        self.report({'INFO'}, _t('Added {count} reroute nodes.', '{count} 個のリルートノードを追加しました。').format(count=count))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_bypass_delete_nodes(Operator):
    bl_idname = 'smart_node_suite.bypass_delete_nodes'
    bl_label = 'Bypass Delete Selected'
    bl_description = _tip(
        'Function: deletes selected nodes while reconnecting compatible input and output links where possible. How to use: select utility nodes you want to remove from a chain, run this command, and review the resulting links.',
        '機能: 選択ノードを削除しつつ、互換性のある入力リンクと出力リンクを可能な範囲で再接続します。使い方: チェーンから外したいユーティリティノードを選択して実行し、結果のリンクを確認します。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        tree = getattr(context.space_data, 'edit_tree', None)
        if tree is None:
            return {'CANCELLED'}
        nodes, _links = get_nodes_links(context)
        target = [node for node in _normal_nodes(nodes, selected_only=True) if getattr(node, 'type', '') != 'FRAME']
        if not target:
            self.report({'WARNING'}, _t('Select nodes before bypass delete.', 'バイパス削除するノードを選択してください。'))
            return {'CANCELLED'}
        deleted = 0
        for node in list(target):
            try:
                in_links = [link for socket in node.inputs for link in socket.links]
                out_links = [link for socket in node.outputs for link in socket.links]
                for in_link in in_links:
                    for out_link in out_links:
                        try:
                            if _can_link_sockets(in_link.from_socket, out_link.to_socket):
                                tree.links.new(in_link.from_socket, out_link.to_socket)
                        except Exception:
                            pass
                tree.nodes.remove(node)
                deleted += 1
            except Exception:
                pass
        self.report({'INFO'}, _t('Bypass-deleted {count} nodes.', '{count} 個のノードをバイパス削除しました。').format(count=deleted))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_free_from_frame(Operator):
    bl_idname = 'smart_node_suite.free_from_frame'
    bl_label = 'Free From Frame'
    bl_description = _tip(
        'Function: removes selected nodes from their parent frame while keeping their absolute editor positions. How to use: select framed nodes and run this command before reorganizing or deleting the backdrop frame.',
        '機能: 選択ノードを親フレームから外しつつ、エディター上の絶対位置を維持します。使い方: フレーム内のノードを選択し、バックドロップ整理や削除の前に実行します。',
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        target = [node for node in _normal_nodes(nodes, selected_only=True) if getattr(node, 'parent', None) is not None]
        if not target:
            self.report({'WARNING'}, _t('No selected framed nodes were found.', '選択中のフレーム内ノードが見つかりません。'))
            return {'CANCELLED'}
        for node in target:
            loc = _absolute_location(node)
            try:
                node.parent = None
                node.location.x = loc.x
                node.location.y = loc.y
            except Exception:
                pass
        self.report({'INFO'}, _t('Freed {count} nodes from frames.', '{count} 個のノードをフレームから外しました。').format(count=len(target)))
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_select_material_users(Operator):
    bl_idname = 'smart_node_suite.select_material_users'
    bl_label = 'Select Objects Using Material'
    bl_description = _tip(
        'Function: selects scene objects that use the material currently edited in the Shader Node Editor. How to use: open a material node tree and press the button. Hidden objects are not selected.',
        '機能: シェーダーエディターで現在編集中のマテリアルを使用しているシーンオブジェクトを選択します。使い方: マテリアルノードツリーを開いて押します。非表示のオブジェクトは選びません。',
    )
    bl_options = set()

    extend: BoolProperty(name='Extend Selection', default=False, description=_tip('Function: adds material users to the existing object selection. How to use: disable to replace the current object selection, enable to accumulate selections from multiple materials.', '機能: 既存のオブジェクト選択へマテリアル使用オブジェクトを追加します。使い方: 現在の選択を置き換える場合は無効、複数マテリアルから選択を積み上げる場合は有効にします。'))
    include_hidden: BoolProperty(name='Include Hidden', default=False, description=_tip('Function: allows hidden scene objects to be selected when they use the edited material. How to use: keep disabled for visible-scene work; enable when auditing all material assignments.', '機能: 編集中マテリアルを使用している非表示オブジェクトも選択対象にします。使い方: 表示中シーンの作業では無効のまま、すべての割り当てを確認する場合は有効にします。'))

    @staticmethod
    def _material_from_context(context):
        space = getattr(context, 'space_data', None)
        candidate = getattr(space, 'id', None) if space is not None else None
        if isinstance(candidate, bpy.types.Material):
            return candidate
        tree = getattr(space, 'edit_tree', None) if space is not None else None
        if tree is not None:
            for material in bpy.data.materials:
                try:
                    if material.node_tree == tree:
                        return material
                except Exception:
                    pass
        obj = getattr(context, 'object', None)
        mat = getattr(obj, 'active_material', None) if obj is not None else None
        if isinstance(mat, bpy.types.Material):
            return mat
        return None

    @classmethod
    def poll(cls, context):
        try:
            space = getattr(context, 'space_data', None)
            return space is not None and getattr(space, 'type', '') == 'NODE_EDITOR'
        except Exception:
            return False

    def execute(self, context):
        material = self._material_from_context(context)
        if material is None:
            self.report({'WARNING'}, _t('No edited material was found.', '編集中のマテリアルが見つかりません。'))
            return {'CANCELLED'}
        if getattr(context, 'mode', 'OBJECT') != 'OBJECT':
            self.report({'WARNING'}, _t(
                'Switch to Object Mode before selecting material users.',
                'マテリアル使用オブジェクトを選択する前にオブジェクトモードへ切り替えてください。',
            ))
            return {'CANCELLED'}
        if not self.extend:
            for obj in getattr(context.scene, 'objects', ()): 
                try:
                    obj.select_set(False)
                except Exception:
                    pass
        selected = []
        for obj in getattr(context.scene, 'objects', ()): 
            try:
                if not self.include_hidden and obj.hide_get():
                    continue
            except Exception:
                pass
            uses_material = False
            for slot in getattr(obj, 'material_slots', ()): 
                try:
                    if slot.material == material:
                        uses_material = True
                        break
                except Exception:
                    pass
            if not uses_material:
                continue
            try:
                obj.select_set(True)
                selected.append(obj)
            except Exception:
                pass
        if selected:
            try:
                context.view_layer.objects.active = selected[0]
            except Exception:
                pass
        self.report({'INFO'}, _t('Selected {count} material users.', '{count} 個のマテリアル使用オブジェクトを選択しました。').format(count=len(selected)))
        return {'FINISHED'}

