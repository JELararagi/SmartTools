# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

"""Finite Lazy Connect modal workflow.

Only the active operator owns a draw handler.  The handler is removed on every
success, cancel, exception, reload, and unregister path.  Socket-menu state is
bounded plain data (strings/integers); no RNA object is retained globally.
"""

from __future__ import annotations

import bpy
from bpy.types import Menu, Operator
from bpy.props import BoolProperty, IntProperty
from bpy_extras.node_utils import connect_sockets
from bpy.app.translations import contexts as i18n_contexts

from ..interface import socket_to_icon
from ..i18n import tip as _tip
from .. import runtime_lifecycle
from ..manager_rules import workspace_runtime_allowed
from ..utils.node_transactions import restore_tree_links, snapshot_tree_links
from ..utils.nodes import (
    SNSBase,
    SNSBaseMenu,
    autolink,
    force_update,
    get_nodes_links,
    node_at_pos,
    sns_check,
    sns_check_not_empty,
)
from ..utils.draw import draw_callback_nodeoutline


# One popup chain at a time. Values are intentionally plain Python data only.
_MENU_STATE: dict[str, object] = {}
_MENU_CLEANUP_ID: int | None = None


def _menu_state_cleanup() -> None:
    global _MENU_CLEANUP_ID
    _MENU_STATE.clear()
    _MENU_CLEANUP_ID = None


def _clear_menu_state() -> None:
    global _MENU_CLEANUP_ID
    cleanup_id = _MENU_CLEANUP_ID
    _MENU_CLEANUP_ID = None
    if cleanup_id is not None:
        runtime_lifecycle.unregister_cleanup(cleanup_id, run=False)
    _MENU_STATE.clear()


def _tree_pointer(context) -> int:
    try:
        tree = context.space_data.edit_tree
        return int(tree.as_pointer()) if tree is not None else 0
    except Exception:
        return 0


def _set_menu_state(context, source_name: str, target_name: str, source_socket: int = -1) -> bool:
    global _MENU_CLEANUP_ID
    tree_pointer = _tree_pointer(context)
    if not tree_pointer or not source_name or not target_name:
        _clear_menu_state()
        return False
    _clear_menu_state()
    _MENU_STATE.update({
        'generation': str(runtime_lifecycle.generation_token()),
        'tree_pointer': int(tree_pointer),
        'source_name': str(source_name),
        'target_name': str(target_name),
        'source_socket': int(source_socket),
    })
    _MENU_CLEANUP_ID = runtime_lifecycle.register_cleanup(_menu_state_cleanup)
    return True


def _menu_state_valid(context) -> bool:
    if not _MENU_STATE:
        return False
    try:
        if not runtime_lifecycle.is_current(str(_MENU_STATE.get('generation', '') or '')):
            return False
        return int(_MENU_STATE.get('tree_pointer', 0)) == _tree_pointer(context)
    except Exception:
        return False


def _lazy_link_nodes(context):
    """Resolve popup endpoints without raising on stale context or reload."""
    try:
        nodes, links = get_nodes_links(context)
        if not _menu_state_valid(context):
            return nodes, links, None, None
        source_name = str(_MENU_STATE.get('source_name', '') or '')
        target_name = str(_MENU_STATE.get('target_name', '') or '')
        source = nodes.get(source_name) if source_name else None
        target = nodes.get(target_name) if target_name else None
        return nodes, links, source, target
    except Exception:
        return None, None, None, None


def _menu_source_socket(context) -> int:
    if _menu_state_valid(context):
        try:
            return int(_MENU_STATE.get('source_socket', -1))
        except Exception:
            return -1
    return -1


def _lazy_link_poll(cls, context):
    if not sns_check(cls, context):
        return False
    _nodes, _links, source, target = _lazy_link_nodes(context)
    if source is None or target is None:
        cls.poll_message_set('Lazy Connect source and target nodes are not available.')
        return False
    return True


def _snapshot_selection(nodes) -> tuple[tuple[str, ...], str]:
    selected = tuple(str(node.name) for node in nodes if bool(getattr(node, 'select', False)))
    active = getattr(nodes, 'active', None)
    return selected, str(getattr(active, 'name', '') or '')


def _restore_selection(nodes, selected_names: tuple[str, ...], active_name: str) -> None:
    selected = set(selected_names)
    for node in tuple(nodes):
        try:
            node.select = str(node.name) in selected
        except Exception:
            pass
    try:
        nodes.active = nodes.get(active_name) if active_name else None
    except Exception:
        pass


def _clear_scene_transients(context) -> None:
    # Compatibility API only.  Modal/popup state is plain bounded memory and
    # cancelling with Esc never writes Scene or other Blend data.
    _ = context
    return None


def _draw_nodeoutline_origin_area(operator, context, mode) -> None:
    """Draw only in the Node Editor area that owns this modal operator."""

    try:
        draw_area = getattr(getattr(bpy, 'context', None), 'area', None)
        if (
            draw_area is None
            or int(draw_area.as_pointer())
            != int(getattr(operator, '_origin_area_pointer', 0))
        ):
            return
    except Exception:
        return
    draw_callback_nodeoutline(operator, context, mode)


def _direct_link_transaction(tree, output_socket, input_socket) -> bool:
    records = snapshot_tree_links(tree)
    try:
        connect_sockets(output_socket, input_socket)
        return True
    except Exception:
        restore_tree_links(tree, records)
        return False


class SMART_NODE_SUITE_OT_lazy_connect(Operator, SNSBase):
    """Connect two nodes without clicking a specific socket."""

    bl_idname = 'smart_node_suite.lazy_connect'
    bl_label = 'Lazy Connect'
    bl_options = {'UNDO'}

    with_menu: BoolProperty(
        name='Show Socket Menu',
        description=_tip(
            'Function: opens a popup for choosing the exact source and target sockets after the two nodes are selected. How to use: enable it when automatic socket matching is not sufficient; press Esc to cancel without changing the node tree.',
            '機能: 2つのノードを選んだ後、正確な出力・入力ソケットを選ぶポップアップを開きます。使い方: 自動ソケット判定では足りない場合に有効にし、変更せず中止する場合は Esc を押します。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def _remove_draw_handler(self) -> None:
        handle = getattr(self, '_handle', None)
        self._handle = None
        if handle is not None:
            try:
                bpy.types.SpaceNodeEditor.draw_handler_remove(handle, 'WINDOW')
            except Exception:
                pass

    def _release_resources(self) -> None:
        cleanup_id = getattr(self, '_cleanup_id', None)
        self._cleanup_id = None
        if cleanup_id is not None:
            runtime_lifecycle.unregister_cleanup(cleanup_id, run=True)
        else:
            self._remove_draw_handler()

    def _cancel(self, context, *, clear_menu=True):
        self._release_resources()
        if clear_menu:
            _clear_menu_state()
        try:
            if _tree_pointer(context) == getattr(self, '_tree_pointer', 0):
                nodes, _links = get_nodes_links(context)
                _restore_selection(nodes, self._selected_names, self._active_name)
        except Exception:
            pass
        _clear_scene_transients(context)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'CANCELLED'}

    def modal(self, context, event):
        if not runtime_lifecycle.is_current(getattr(self, '_generation', -1)):
            return self._cancel(context)
        if getattr(context, 'area', None) is None or context.area.type != 'NODE_EDITOR':
            return self._cancel(context)
        if _tree_pointer(context) != getattr(self, '_tree_pointer', 0):
            return self._cancel(context)
        if not workspace_runtime_allowed(context):
            return self._cancel(context)

        try:
            context.area.tag_redraw()
            nodes, links = get_nodes_links(context)
            source = nodes.get(getattr(self, '_source_name', ''))
            if source is None:
                return self._cancel(context)

            target = node_at_pos(nodes, context, event)
            self._target_name = str(getattr(target, 'name', '') or '')
            if event.type == 'MOUSEMOVE':
                point = (int(event.mouse_region_x), int(event.mouse_region_y))
                self.mouse_path = [self.mouse_path[0], point]
                return {'RUNNING_MODAL'}

            if event.type == 'ESC':
                return self._cancel(context)

            if event.type != 'RIGHTMOUSE' or event.value != 'RELEASE':
                return {'RUNNING_MODAL'}

            self._release_resources()
            _restore_selection(nodes, self._selected_names, self._active_name)
            _clear_scene_transients(context)

            if target is None or target == source:
                _clear_menu_state()
                return {'CANCELLED'}

            available_outputs = [
                (index, socket) for index, socket in enumerate(source.outputs)
                if bool(getattr(socket, 'enabled', False))
            ]
            available_inputs = [
                (index, socket) for index, socket in enumerate(target.inputs)
                if bool(getattr(socket, 'enabled', False))
            ]
            if not available_outputs or not available_inputs:
                _clear_menu_state()
                self.report({'WARNING'}, _tip('No enabled sockets are available for Lazy Connect.', '簡単コネクトに使用できる有効なソケットがありません。'))
                return {'CANCELLED'}

            if not self.with_menu:
                records = snapshot_tree_links(context.space_data.edit_tree)
                try:
                    if not autolink(source, target, links):
                        restore_tree_links(context.space_data.edit_tree, records)
                        return {'CANCELLED'}
                    force_update(context)
                    return {'FINISHED'}
                except Exception as exc:
                    restore_tree_links(context.space_data.edit_tree, records)
                    self.report({'WARNING'}, _tip('Lazy Connect failed: {exc}', '簡単コネクトが失敗しました。').format(exc=exc))
                    return {'CANCELLED'}

            if len(available_outputs) == 1 and len(available_inputs) == 1:
                if _direct_link_transaction(
                        context.space_data.edit_tree,
                        available_outputs[0][1],
                        available_inputs[0][1]):
                    force_update(context)
                    return {'FINISHED'}
                self.report({'WARNING'}, _tip('Lazy Connect could not create the link.', '簡単コネクトはリンクを作成できませんでした。'))
                return {'CANCELLED'}

            if not _set_menu_state(context, source.name, target.name):
                return {'CANCELLED'}
            if len(available_outputs) == 1:
                _MENU_STATE['source_socket'] = int(available_outputs[0][0])
                bpy.ops.wm.call_menu(
                    'INVOKE_DEFAULT',
                    name=SMART_NODE_SUITE_MT_lazy_connect_inputs.bl_idname,
                )
            else:
                bpy.ops.wm.call_menu(
                    'INVOKE_DEFAULT',
                    name=SMART_NODE_SUITE_MT_lazy_connect_outputs.bl_idname,
                )
            # No Blend data changed yet; the final link operator owns the sole
            # Undo step. Esc from either menu therefore leaves the tree intact.
            return {'CANCELLED'}
        except Exception as exc:
            self.report({'WARNING'}, _tip('Lazy Connect cancelled safely: {exc}', '簡単コネクトを安全にキャンセルしました。').format(exc=exc))
            return self._cancel(context)

    def invoke(self, context, event):
        if getattr(context, 'area', None) is None or context.area.type != 'NODE_EDITOR':
            self.report({'WARNING'}, _tip('Active editor should be a node editor for the operator to run.', 'このオペレーターはノードエディターがアクティブな状態で実行してください。'))
            return {'CANCELLED'}

        try:
            self._origin_area_pointer = int(context.area.as_pointer())
        except Exception:
            return {'CANCELLED'}
        _clear_menu_state()
        _clear_scene_transients(context)
        try:
            nodes, _links = get_nodes_links(context)
            source = node_at_pos(nodes, context, event)
        except Exception:
            source = None
        if source is None:
            self.report({'WARNING'}, _tip('No source node is available under the cursor.', 'カーソル位置にソースノードがありません。'))
            return {'CANCELLED'}

        self._generation = runtime_lifecycle.generation_token()
        if not runtime_lifecycle.is_current(self._generation):
            return {'CANCELLED'}
        self._tree_pointer = _tree_pointer(context)
        self._source_name = str(source.name)
        self._target_name = str(source.name)
        self._selected_names, self._active_name = _snapshot_selection(nodes)
        point = (int(event.mouse_region_x), int(event.mouse_region_y))
        self.mouse_path = [point, point]
        self._handle = None
        self._cleanup_id = None

        try:
            mode = 'LINKMENU' if self.with_menu else 'LINK'
            args = (self, context, mode)
            self._handle = bpy.types.SpaceNodeEditor.draw_handler_add(
                _draw_nodeoutline_origin_area, args, 'WINDOW', 'POST_PIXEL')
            self._cleanup_id = runtime_lifecycle.register_cleanup(self._remove_draw_handler)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            self.report({'WARNING'}, _tip('Lazy Connect could not start: {exc}', '簡単コネクトを開始できませんでした。').format(exc=exc))
            return self._cancel(context)


class SMART_NODE_SUITE_OT_lazy_connect_call_inputs_menu(Operator, SNSBase):
    """Open the target-input popup for the selected output socket."""

    bl_idname = 'smart_node_suite.lazy_connect_call_inputs_menu'
    bl_label = 'Make Link'
    bl_options = set()
    _sms_no_undo = True

    from_socket: IntProperty(
        name='Source Socket Index',
        description=_tip(
            'Function: stores the output socket chosen in the Lazy Connect popup. How to use: select an output; Smart Node then opens the target-input popup. Esc closes the popup without changing the node tree.',
            '機能: 簡単コネクトポップアップで選んだ出力ソケット番号を保持します。使い方: 出力を選ぶと入力選択ポップアップが開き、Esc でノードツリーを変更せず閉じられます。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return _lazy_link_poll(cls, context)

    def execute(self, context):
        _nodes, _links, source, target = _lazy_link_nodes(context)
        if source is None or target is None:
            self.report({'WARNING'}, _tip('Lazy Connect source and target nodes are not available.', '簡単コネクトのソースノードとターゲットノードが利用できません。'))
            return {'CANCELLED'}
        if self.from_socket < 0 or self.from_socket >= len(source.outputs):
            self.report({'WARNING'}, _tip('Lazy Connect source socket is no longer available.', '簡単コネクトのソースソケットが利用できなくなりました。'))
            return {'CANCELLED'}
        if not _menu_state_valid(context):
            if not _set_menu_state(context, source.name, target.name, self.from_socket):
                return {'CANCELLED'}
        _MENU_STATE['source_socket'] = int(self.from_socket)
        bpy.ops.wm.call_menu(
            'INVOKE_DEFAULT',
            name=SMART_NODE_SUITE_MT_lazy_connect_inputs.bl_idname,
        )
        return {'FINISHED'}


class SMART_NODE_SUITE_OT_lazy_connect_make_link(Operator, SNSBase):
    """Create the final socket link as one Blender Undo step."""

    bl_idname = 'smart_node_suite.lazy_connect_make_link'
    bl_label = 'Make Link'
    bl_options = {'UNDO'}

    from_socket: IntProperty(
        name='Source Socket Index',
        description=_tip(
            'Function: identifies the source output used for the final Lazy Connect link. How to use: Smart Node fills this when you choose an output socket.',
            '機能: 簡単コネクトの最終リンクに使う出力ソケットを指定します。使い方: 出力ソケットを選ぶと Smart Node が自動設定します。',
        ),
    )
    to_socket: IntProperty(
        name='Target Socket Index',
        description=_tip(
            'Function: identifies the target input used for the final Lazy Connect link. How to use: choose the desired input from the popup; the link is then created as one Undo step.',
            '機能: 簡単コネクトの最終リンクに使う入力ソケットを指定します。使い方: ポップアップで目的の入力を選ぶと、1回の Undo 単位でリンクが作成されます。',
        ),
    )

    @classmethod
    def poll(cls, context):
        return _lazy_link_poll(cls, context)

    def execute(self, context):
        _nodes, _links, source, target = _lazy_link_nodes(context)
        if source is None or target is None:
            self.report({'WARNING'}, _tip('Lazy Connect source and target nodes are not available.', '簡単コネクトのソースノードとターゲットノードが利用できません。'))
            _clear_menu_state()
            return {'CANCELLED'}
        if self.from_socket < 0 or self.from_socket >= len(source.outputs):
            self.report({'WARNING'}, _tip('Lazy Connect source socket is no longer available.', '簡単コネクトのソースソケットが利用できなくなりました。'))
            _clear_menu_state()
            return {'CANCELLED'}
        if self.to_socket < 0 or self.to_socket >= len(target.inputs):
            self.report({'WARNING'}, _tip('Lazy Connect target socket is no longer available.', '簡単コネクトのターゲットソケットが利用できなくなりました。'))
            _clear_menu_state()
            return {'CANCELLED'}

        tree = context.space_data.edit_tree
        success = _direct_link_transaction(
            tree,
            source.outputs[self.from_socket],
            target.inputs[self.to_socket],
        )
        _clear_menu_state()
        _clear_scene_transients(context)
        if not success:
            self.report({'WARNING'}, _tip('Lazy Connect could not create the link.', '簡単コネクトはリンクを作成できませんでした。'))
            return {'CANCELLED'}
        force_update(context)
        return {'FINISHED'}


_USER_SOCKET_NODE_TYPES = frozenset({
    'NodeGroupInput',
    'NodeGroupOutput',
    'GeometryNodeRepeatInput',
    'GeometryNodeRepeatOutput',
    'GeometryNodeSimulationInput',
    'GeometryNodeSimulationOutput',
    'GeometryNodeBake',
    'GeometryNodeCaptureAttribute',
    'GeometryNodeMenuSwitch',
    'GeometryNodeForeachGeometryElementInput',
    'GeometryNodeForeachGeometryElementOutput',
})


def _has_user_socket_names(node) -> bool:
    # Group nodes, group input/output and zone nodes show names the user typed; built-in sockets are translated.
    return (
        getattr(node, 'node_tree', None) is not None
        or getattr(node, 'bl_idname', '') in _USER_SOCKET_NODE_TYPES
    )


class SMART_NODE_SUITE_MT_lazy_connect_outputs(Menu, SNSBaseMenu):
    bl_idname = 'SMART_NODE_SUITE_MT_lazy_connect_outputs'
    bl_label = ''

    def draw(self, context):
        layout = self.layout
        _nodes, _links, source, _target = _lazy_link_nodes(context)
        if source is None:
            layout.label(text=_tip('Lazy Connect source node is no longer available.', '接続元のノードがなくなりました。'))
            return

        layout.label(text=_tip('From Socket', '接続元のソケット'), icon='RADIOBUT_OFF')
        layout.separator()
        for index, output in enumerate(source.outputs):
            if bool(getattr(output, 'enabled', False)):
                layout.operator(
                    'smart_node_suite.lazy_connect_call_inputs_menu',
                    text=output.name,
                    text_ctxt=i18n_contexts.default,
                    translate=not _has_user_socket_names(source),
                    icon=socket_to_icon(output),
                ).from_socket = index


class SMART_NODE_SUITE_MT_lazy_connect_inputs(Menu, SNSBaseMenu):
    bl_idname = 'SMART_NODE_SUITE_MT_lazy_connect_inputs'
    bl_label = ''

    def draw(self, context):
        layout = self.layout
        _nodes, _links, source, target = _lazy_link_nodes(context)
        source_socket = _menu_source_socket(context)
        if source is None or target is None or not (0 <= source_socket < len(source.outputs)):
            layout.label(text=_tip('Lazy Connect socket state is no longer available.', '接続するソケットがなくなりました。'))
            return

        layout.label(text=_tip('To Socket', '接続先のソケット'), icon='FORWARD')
        layout.separator()
        for index, input_socket in enumerate(target.inputs):
            if bool(getattr(input_socket, 'enabled', False)):
                op = layout.operator(
                    'smart_node_suite.lazy_connect_make_link',
                    text=input_socket.name,
                    text_ctxt=i18n_contexts.default,
                    translate=not _has_user_socket_names(target),
                    icon=socket_to_icon(input_socket),
                )
                op.from_socket = source_socket
                op.to_socket = index
