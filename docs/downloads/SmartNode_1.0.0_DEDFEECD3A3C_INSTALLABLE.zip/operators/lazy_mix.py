# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

"""Finite interactive Mix-node creation with one Undo boundary."""

from __future__ import annotations

import bpy
from bpy.types import Operator

from .. import runtime_lifecycle
from ..i18n import tip as _tip
from ..manager_rules import workspace_runtime_allowed
from ..utils.nodes import (
    SNSBase,
    get_nodes_links,
    node_at_pos,
    sns_check,
    sns_check_not_empty,
)
from ..utils.draw import draw_callback_nodeoutline
from .merge_selected import merge_selected_nodes


def _tree_pointer(context) -> int:
    try:
        tree = context.space_data.edit_tree
        return int(tree.as_pointer()) if tree is not None else 0
    except Exception:
        return 0


def _snapshot_selection(nodes) -> tuple[tuple[str, ...], str]:
    selected = tuple(str(node.name) for node in tuple(nodes) if bool(getattr(node, 'select', False)))
    active = getattr(nodes, 'active', None)
    return selected, str(getattr(active, 'name', '') or '')


def _restore_selection(nodes, selected_names: tuple[str, ...], active_name: str) -> None:
    selected = set(selected_names)
    for node in tuple(nodes):
        try:
            node.select = str(node.name) in selected
        except Exception:
            pass
    try:
        nodes.active = nodes.get(active_name) if active_name else None
    except Exception:
        pass


def _clear_scene_transients(context) -> None:
    # Compatibility API only. Interactive state remains on the finite operator;
    # Esc never mutates Scene or other Blend data.
    _ = context
    return None


def _draw_nodeoutline_origin_area(operator, context, mode) -> None:
    """Draw only in the Node Editor area that owns this modal operator."""

    try:
        draw_area = getattr(getattr(bpy, 'context', None), 'area', None)
        if (
            draw_area is None
            or int(draw_area.as_pointer())
            != int(getattr(operator, '_origin_area_pointer', 0))
        ):
            return
    except Exception:
        return
    draw_callback_nodeoutline(operator, context, mode)



class SMART_NODE_SUITE_OT_lazy_mix(Operator, SNSBase):
    """Add a Mix/merge node by interactively drawing between two nodes."""

    bl_idname = 'smart_node_suite.lazy_mix'
    bl_label = 'Mix Nodes'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_not_empty(cls, context)

    def _remove_draw_handler(self) -> None:
        handle = getattr(self, '_handle', None)
        self._handle = None
        if handle is not None:
            try:
                bpy.types.SpaceNodeEditor.draw_handler_remove(handle, 'WINDOW')
            except Exception:
                pass

    def _release_resources(self) -> None:
        cleanup_id = getattr(self, '_cleanup_id', None)
        self._cleanup_id = None
        if cleanup_id is not None:
            runtime_lifecycle.unregister_cleanup(cleanup_id, run=True)
        else:
            self._remove_draw_handler()

    def _cancel(self, context):
        self._release_resources()
        try:
            if _tree_pointer(context) == getattr(self, '_tree_pointer', 0):
                nodes, _links = get_nodes_links(context)
                _restore_selection(nodes, self._selected_names, self._active_name)
        except Exception:
            pass
        _clear_scene_transients(context)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        return {'CANCELLED'}

    def modal(self, context, event):
        if not runtime_lifecycle.is_current(getattr(self, '_generation', -1)):
            return self._cancel(context)
        if getattr(context, 'area', None) is None or context.area.type != 'NODE_EDITOR':
            return self._cancel(context)
        if _tree_pointer(context) != getattr(self, '_tree_pointer', 0):
            return self._cancel(context)
        if not workspace_runtime_allowed(context):
            return self._cancel(context)

        try:
            context.area.tag_redraw()
            nodes, _links = get_nodes_links(context)
            source = nodes.get(getattr(self, '_source_name', ''))
            if source is None:
                return self._cancel(context)
            target = node_at_pos(nodes, context, event)
            self._target_name = str(getattr(target, 'name', '') or '')
            if event.type == 'MOUSEMOVE':
                point = (int(event.mouse_region_x), int(event.mouse_region_y))
                self.mouse_path = [self.mouse_path[0], point]
                return {'RUNNING_MODAL'}
            if event.type == 'ESC':
                return self._cancel(context)
            if event.type != 'RIGHTMOUSE' or event.value != 'RELEASE':
                return {'RUNNING_MODAL'}

            self._release_resources()
            _clear_scene_transients(context)
            if target is None or target == source:
                _restore_selection(nodes, self._selected_names, self._active_name)
                return {'CANCELLED'}

            for node in tuple(nodes):
                node.select = False
            source.select = True
            target.select = True
            try:
                nodes.active = target
            except Exception:
                pass

            result = merge_selected_nodes(
                context,
                mode='MIX',
                merge_type='AUTO',
                report=self.report,
            )
            if 'FINISHED' not in result:
                _restore_selection(nodes, self._selected_names, self._active_name)
                return {'CANCELLED'}
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, _tip('Mix Nodes cancelled safely: {exc}', 'ミックスノードを安全にキャンセルしました。').format(exc=exc))
            return self._cancel(context)

    def invoke(self, context, event):
        if getattr(context, 'area', None) is None or context.area.type != 'NODE_EDITOR':
            self.report({'WARNING'}, _tip('Active editor should be a node editor for the operator to run.', 'このオペレーターはノードエディターがアクティブな状態で実行してください。'))
            return {'CANCELLED'}

        try:
            self._origin_area_pointer = int(context.area.as_pointer())
        except Exception:
            return {'CANCELLED'}
        _clear_scene_transients(context)
        try:
            nodes, _links = get_nodes_links(context)
            source = node_at_pos(nodes, context, event)
        except Exception:
            source = None
        if source is None:
            self.report({'WARNING'}, _tip('No source node is available under the cursor.', 'カーソル位置にソースノードがありません。'))
            return {'CANCELLED'}

        self._generation = runtime_lifecycle.generation_token()
        if not runtime_lifecycle.is_current(self._generation):
            return {'CANCELLED'}
        self._tree_pointer = _tree_pointer(context)
        self._source_name = str(source.name)
        self._target_name = str(source.name)
        self._selected_names, self._active_name = _snapshot_selection(nodes)
        point = (int(event.mouse_region_x), int(event.mouse_region_y))
        self.mouse_path = [point, point]
        self._handle = None
        self._cleanup_id = None

        try:
            args = (self, context, 'MIX')
            self._handle = bpy.types.SpaceNodeEditor.draw_handler_add(
                _draw_nodeoutline_origin_area, args, 'WINDOW', 'POST_PIXEL')
            self._cleanup_id = runtime_lifecycle.register_cleanup(self._remove_draw_handler)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            self.report({'WARNING'}, _tip('Mix Nodes could not start: {exc}', 'ミックスノードを開始できませんでした。').format(exc=exc))
            return self._cancel(context)
