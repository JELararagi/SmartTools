# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    abs_node_location,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_center_selected(Operator, SNSBase):
    """Move selected nodes to the center of the current node editor view"""
    bl_idname = "smart_node_suite.center_nodes"
    bl_label = "Center Nodes"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        selection = context.selected_nodes

        # Pick outermost selected nodes
        nodes = []
        for node in selection:
            if node.parent and node.parent.select:
                continue
            nodes.append(node)

        # Get bound center of picked nodes
        ui_scale = context.preferences.system.ui_scale
        nodes_x = []
        nodes_y = []
        nodes_right = []
        nodes_bottom = []
        for n in nodes:
            loc_abs = abs_node_location(n)
            nodes_x.append(loc_abs.x)
            nodes_y.append(loc_abs.y)
            if n.type == 'FRAME':
                nodes_right.append(loc_abs.x + n.width)
                nodes_bottom.append(loc_abs.y - n.height)
            elif n.type == 'REROUTE':
                nodes_right.append(loc_abs.x)
                nodes_bottom.append(loc_abs.y)
            else:
                nodes_right.append(loc_abs.x + n.width)
                nodes_bottom.append(loc_abs.y - n.dimensions.y / ui_scale)
        mid_x = (min(nodes_x) + max(nodes_right)) / 2
        mid_y = (max(nodes_y) + min(nodes_bottom)) / 2

        # The button runs from the sidebar, so look up the editor's main region.
        target_x = target_y = 0.0
        area = context.area
        window_region = next((r for r in area.regions if r.type == 'WINDOW'), None) if area else None
        if window_region is not None:
            view_x, view_y = window_region.view2d.region_to_view(window_region.width / 2, window_region.height / 2)
            target_x = view_x / ui_scale
            target_y = view_y / ui_scale

        for node in nodes:
            node.location.x += target_x - mid_x
            node.location.y += target_y - mid_y

        return {'FINISHED'}
