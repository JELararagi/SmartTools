# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator

from ..i18n import t as _t, tip as _tip
from ..utils.layout_grid import addon_preferences


_NODE_VIEW_DEFAULTS = {
    'view_grid_color': (0.1882, 0.1882, 0.1882),
    'view_background_color': (0.1020, 0.1020, 0.1020),
    'view_grid_levels': 3,
    'view_node_backdrop_color': (0.1882, 0.1882, 0.1882, 1.0),
    'view_wire_color': (0.1020, 0.1020, 0.1020, 1.0),
    'view_wire_select_color': (1.0, 1.0, 1.0, 0.7020),
    'view_selected_node_color': (0.9294, 0.3412, 0.0),
    'view_active_node_color': (1.0, 1.0, 1.0),
    'view_noodle_curving': 4,
    'view_dash_alpha': 0.5,
}

_NODE_VIEW_PRESETS = {
    'SOFT': {
        'view_grid_color': (0.145, 0.145, 0.145),
        'view_background_color': (0.090, 0.090, 0.090),
        'view_grid_levels': 2,
        'view_node_backdrop_color': (0.155, 0.155, 0.155, 1.0),
        'view_wire_color': (0.160, 0.160, 0.160, 0.900),
        'view_wire_select_color': (0.900, 0.900, 0.900, 0.740),
        'view_selected_node_color': (0.850, 0.420, 0.080),
        'view_active_node_color': (1.0, 1.0, 1.0),
        'view_noodle_curving': 4,
        'view_dash_alpha': 0.40,
    },
    'STRONG': {
        'view_grid_color': (0.280, 0.280, 0.280),
        'view_background_color': (0.070, 0.070, 0.070),
        'view_grid_levels': 3,
        'view_node_backdrop_color': (0.210, 0.210, 0.210, 1.0),
        'view_wire_color': (0.460, 0.460, 0.460, 1.0),
        'view_wire_select_color': (1.0, 1.0, 1.0, 0.900),
        'view_selected_node_color': (1.0, 0.520, 0.0),
        'view_active_node_color': (1.0, 1.0, 1.0),
        'view_noodle_curving': 3,
        'view_dash_alpha': 0.70,
    },
    'TECHNICAL': {
        'view_grid_color': (0.210, 0.230, 0.250),
        'view_background_color': (0.060, 0.070, 0.080),
        'view_grid_levels': 3,
        'view_node_backdrop_color': (0.130, 0.150, 0.170, 1.0),
        'view_wire_color': (0.320, 0.360, 0.390, 1.0),
        'view_wire_select_color': (0.820, 0.940, 1.0, 0.880),
        'view_selected_node_color': (0.0, 0.650, 1.0),
        'view_active_node_color': (0.920, 1.0, 1.0),
        'view_noodle_curving': 1,
        'view_dash_alpha': 0.80,
    },
}


def _theme_node_editor(context):
    try:
        theme = context.preferences.themes[0]
        return theme.node_editor
    except Exception:
        return None


def _assign_color(target, attr: str, value) -> None:
    try:
        prop = getattr(target, attr)
        for i, component in enumerate(value):
            prop[i] = float(component)
    except TypeError:
        try:
            setattr(target, attr, value)
        except Exception:
            pass
    except Exception:
        try:
            setattr(target, attr, value)
        except Exception:
            pass


def _apply_to_theme(context, prefs) -> bool:
    ne = _theme_node_editor(context)
    if ne is None or prefs is None:
        return False
    try:
        _assign_color(ne, 'grid', prefs.view_grid_color)
        _assign_color(ne.space, 'back', prefs.view_background_color)
        ne.grid_levels = int(prefs.view_grid_levels)
        _assign_color(ne, 'node_backdrop', prefs.view_node_backdrop_color)
        _assign_color(ne, 'wire', prefs.view_wire_color)
        _assign_color(ne, 'wire_select', prefs.view_wire_select_color)
        _assign_color(ne, 'node_selected', prefs.view_selected_node_color)
        _assign_color(ne, 'node_active', prefs.view_active_node_color)
        ne.noodle_curving = int(prefs.view_noodle_curving)
        ne.dash_alpha = float(prefs.view_dash_alpha)
        return True
    except Exception:
        return False


def _read_from_theme(context, prefs) -> bool:
    ne = _theme_node_editor(context)
    if ne is None or prefs is None:
        return False
    try:
        prefs.view_grid_color = tuple(ne.grid)
        prefs.view_background_color = tuple(ne.space.back)
        prefs.view_grid_levels = int(ne.grid_levels)
        prefs.view_node_backdrop_color = tuple(ne.node_backdrop)
        prefs.view_wire_color = tuple(ne.wire)
        prefs.view_wire_select_color = tuple(ne.wire_select)
        prefs.view_selected_node_color = tuple(ne.node_selected)
        prefs.view_active_node_color = tuple(ne.node_active)
        prefs.view_noodle_curving = int(ne.noodle_curving)
        prefs.view_dash_alpha = float(ne.dash_alpha)
        return True
    except Exception:
        return False


def _write_pref_values(prefs, values: dict) -> None:
    if prefs is None:
        return
    for key, value in values.items():
        try:
            setattr(prefs, key, value)
        except Exception:
            pass


class SMART_NODE_SUITE_OT_node_view_settings(Operator):
    bl_idname = 'smart_node_suite.node_view_settings'
    bl_label = 'Node Editor View Settings'
    bl_description = _tip(
        'Function: applies, reads, resets, or presets node-editor visual theme settings such as grid color, background color, grid levels, wire colors, and noodle curvature. How to use: adjust the view settings in the Smart Node panel, then press Apply; press Read to copy the active Blender theme into the panel fields.',
        '機能: グリッドカラー、背景色、グリッドレベル、ワイヤカラー、リンク曲線など、ノードエディターの視覚テーマ設定を適用、読み込み、リセット、プリセット化します。使い方: Smart Node パネルで表示設定を調整して「適用」を押します。現在の Blender テーマを欄へ取り込む場合は「読み込み」を押します。',
    )
    bl_options = set()

    action: EnumProperty(
        name='Action',
        items=(
            ('APPLY', 'Apply View Settings', 'Apply the panel values to the active Blender theme.'),
            ('READ', 'Read Current Settings', 'Copy the active Blender theme values into the Smart Node panel fields.'),
            ('RESET', 'Reset to Blender Default', 'Restore the stored panel values to Blender default node-editor colors and apply them.'),
            ('SOFT', 'Soft Grid Preset', 'Apply a subdued grid preset for long material editing sessions.'),
            ('STRONG', 'Strong Grid Preset', 'Apply a high-contrast grid preset for precise alignment work.'),
            ('TECHNICAL', 'Technical Preset', 'Apply a straighter, technical-diagram style preset.'),
        ),
        default='APPLY',
        description=_tip('Function: chooses what the view-settings command does. How to use: Apply writes the current panel values to the theme, Read imports the active theme values, Reset restores Blender defaults, and presets quickly change several view settings at once.', '機能: 表示設定コマンドの動作を選びます。使い方: 適用は現在の欄の値をテーマへ書き込み、読み込みはアクティブテーマを欄へ取り込み、リセットは Blender 初期値へ戻し、プリセットは複数の表示設定をまとめて変更します。'),
    )

    def execute(self, context):
        prefs = addon_preferences(context)
        if prefs is None:
            self.report({'ERROR'}, _t('Smart Node Suite preferences were not found.', 'Smart Node Suite 設定が見つかりません。'))
            return {'CANCELLED'}

        if self.action == 'READ':
            ok = _read_from_theme(context, prefs)
            if ok:
                self.report({'INFO'}, _t('Read current node-editor view settings.', '現在のノードエディター表示設定を読み込みました。'))
                return {'FINISHED'}
            self.report({'ERROR'}, _t('Could not read node-editor theme settings.', 'ノードエディターテーマ設定を読み込めませんでした。'))
            return {'CANCELLED'}

        if self.action == 'RESET':
            _write_pref_values(prefs, _NODE_VIEW_DEFAULTS)
        elif self.action in _NODE_VIEW_PRESETS:
            _write_pref_values(prefs, _NODE_VIEW_PRESETS[self.action])

        ok = _apply_to_theme(context, prefs)
        if ok:
            self.report({'INFO'}, _t('Applied node-editor view settings.', 'ノードエディター表示設定を適用しました。'))
            return {'FINISHED'}
        self.report({'ERROR'}, _t('Could not apply node-editor theme settings.', 'ノードエディターテーマ設定を適用できませんでした。'))
        return {'CANCELLED'}
