# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.app.translations import pgettext_rpt as rpt_

from ..i18n import tip as _tip

from ..utils.nodes import (
    sns_check,
    sns_check_space_type,
    get_nodes_links,
    force_update,
)


class SMART_NODE_SUITE_OT_reload_images(Operator):
    bl_idname = "smart_node_suite.reload_images"
    bl_label = "Reload Images"
    bl_description = _tip('Function: reloads image data referenced by image nodes so external file changes appear in Blender. How to use: run this after editing texture files on disk or when image nodes show stale image data.', '機能: 画像ノードが参照している画像データを再読み込みし、外部ファイルの変更を Blender に反映します。使い方: ディスク上のテクスチャを編集した後、または画像ノードの表示が古い時に実行します。')

    @classmethod
    def poll(cls, context):
        """Disabled for custom node trees."""
        return (sns_check(cls, context)
                and sns_check_space_type(cls, context, {'ShaderNodeTree', 'CompositorNodeTree',
                                                       'TextureNodeTree', 'GeometryNodeTree'}))

    def execute(self, context):
        edit_tree = context.space_data.edit_tree
        nodes, links = get_nodes_links(context)
        images_to_reload = set()

        for node in nodes:
            if (node.bl_idname == 'TextureNodeTexture'
                    and node.texture is not None
                    and node.texture.type == 'IMAGE'
                    and node.texture.image is not None):
                # Legacy texture nodes.
                images_to_reload.add(node.texture.image)
            elif (node.bl_idname in {'CompositorNodeImage',
                                     'GeometryNodeInputImage',
                                     'ShaderNodeTexEnvironment',
                                     'ShaderNodeTexImage',
                                     'TextureNodeImage'}
                    and node.image is not None):
                # Image and environment textures.
                images_to_reload.add(node.image)
            elif node.bl_idname in {'GeometryNodeGroup',
                                    'GeometryNodeImageInfo',
                                    'GeometryNodeImageTexture'}:
                # For these Geometry Nodes, check each input since images can be defined in sockets.
                for sock in node.inputs:
                    if (sock.bl_idname == 'NodeSocketImage'
                            and sock.default_value is not None):
                        images_to_reload.add(sock.default_value)

        # Images defined in group interface, typically used by modifier.
        if edit_tree.bl_idname == 'GeometryNodeTree':
            interface_ids = []
            items = edit_tree.interface.items_tree
            for item in items:
                if (isinstance(item, bpy.types.NodeTreeInterfaceSocketImage)
                        and item.in_out == 'INPUT'):
                    interface_ids.append(item.identifier)
            if interface_ids:
                for obj in context.scene.objects:
                    for mod in obj.modifiers:
                        if not (mod.type == 'NODES' and mod.node_group == edit_tree):
                            continue
                        for id in interface_ids:
                            if not (img := mod.get(id)):
                                continue
                            images_to_reload.add(img)

        if not images_to_reload:
            self.report({'WARNING'}, _tip('No images found to reload in this node tree', 'このノードツリーに再読み込みする画像が見つかりません'))
            return {'CANCELLED'}

        for img in images_to_reload:
            img.reload()
        force_update(context)
        edit_tree.interface_update(context)

        self.report({'INFO'}, rpt_("Reloaded {:d} image(s)").format(len(images_to_reload)))
        return {'FINISHED'}
