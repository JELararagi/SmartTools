# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import StringProperty

from ..i18n import tip as _tip

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_labels_modify(Operator, SNSBase):
    """Modify labels of all selected nodes"""
    bl_idname = "smart_node_suite.modify_labels"
    bl_label = "Modify Labels"
    bl_options = {'UNDO'}

    prepend: StringProperty(
        name="Add to Beginning",
        description=_tip('Function: text added before each selected node label. How to use: enter a prefix such as material or pass name when grouping labels by purpose.', '機能: 選択ノードのラベル先頭へ追加する文字列です。使い方: マテリアル名やパス名など、用途で分類する接頭辞を入力します。'),
    )
    append: StringProperty(
        name="Add to End",
        description=_tip('Function: text added after each selected node label. How to use: enter a suffix such as version, variant, or status marker.', '機能: 選択ノードのラベル末尾へ追加する文字列です。使い方: バージョン、バリアント、状態マークなどの接尾辞を入力します。'),
    )
    replace_from: StringProperty(
        name="Text to Replace",
        description=_tip('Function: text fragment to find inside selected node labels. How to use: type the old word, abbreviation, or naming token you want to replace.', '機能: 選択ノードのラベル内で検索する文字列です。使い方: 置き換えたい古い語、略語、命名トークンを入力します。'),
    )
    replace_to: StringProperty(
        name="Replace with",
        description=_tip('Function: replacement text written into selected node labels. How to use: enter the new word or leave it empty to remove the found text.', '機能: 選択ノードのラベルへ書き込む置換後の文字列です。使い方: 新しい語を入力します。見つけた文字を削除したい場合は空欄にします。'),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context) -> set[str]:
        nodes, links = get_nodes_links(context)
        for node in [n for n in nodes if n.select]:
            node.label = self.prepend + node.label.replace(self.replace_from, self.replace_to) + self.append

        return {'FINISHED'}

    def invoke(self, context, event):
        # Opening the dialog must not alter labels or operator values. Blender
        # commits label changes only through execute(); Esc therefore exits with
        # the node tree and the last explicit input values untouched.
        return context.window_manager.invoke_props_dialog(self)
