# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import BoolProperty
from bpy_extras.node_utils import connect_sockets
from bpy.app.translations import pgettext_rpt as rpt_

from ..i18n import tip as _tip

from ..utils.constants import (
    get_texture_node_types,
)
from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    sns_check_space_type,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_add_texture_setup(Operator, SNSBase):
    bl_idname = "smart_node_suite.add_texture"
    bl_label = "Add Texture Setup"
    bl_description = _tip('Function: adds image texture, mapping, and coordinate nodes for selected shader nodes. How to use: select shader nodes that need a texture input, run the command, then assign images and adjust mapping as needed.', '機能: 選択したシェーダーノード用に画像テクスチャ、マッピング、座標ノードを追加します。使い方: テクスチャ入力が必要なシェーダーノードを選択して実行し、必要に応じて画像割り当てやマッピング調整を行います。')
    bl_options = {'UNDO'}

    add_mapping: BoolProperty(
        name="Add Mapping Nodes",
        description=_tip('Function: adds Texture Coordinate and Mapping nodes together with the new image texture setup. How to use: keep enabled when a shader needs UV or generated-coordinate control; disable when adding only the image texture node.', '機能: 新しい画像テクスチャ設定と一緒に テクスチャ座標とマッピングノードを追加します。使い方: UV や生成座標を調整したいシェーダーでは有効、画像テクスチャだけ追加したい場合は無効にします。'),
        default=True)

    @classmethod
    def poll(cls, context):
        return (sns_check(cls, context)
                and sns_check_space_type(cls, context, {'ShaderNodeTree'})
                and sns_check_selected(cls, context))

    def execute(self, context):
        nodes, links = get_nodes_links(context)

        texture_types = get_texture_node_types()
        selected_nodes = [n for n in nodes if n.select]

        for node in selected_nodes:
            if not node.inputs:
                continue

            input_index = 0
            target_input = node.inputs[0]
            for input in node.inputs:
                if input.enabled:
                    input_index += 1
                    if not input.is_linked:
                        target_input = input
                        break
            else:
                self.report({'WARNING'}, rpt_("No free inputs for node {}").format(node.name))
                continue

            x_offset = 0
            padding = 40.0
            locx = node.location.x
            locy = node.location.y - (input_index * padding)

            is_texture_node = node.rna_type.identifier in texture_types
            use_environment_texture = node.type == 'BACKGROUND'

            # Add an image texture before normal shader nodes.
            if not is_texture_node:
                image_texture_type = 'ShaderNodeTexEnvironment' if use_environment_texture else 'ShaderNodeTexImage'
                image_texture_node = nodes.new(image_texture_type)
                x_offset = x_offset + image_texture_node.width + padding
                image_texture_node.location = [locx - x_offset, locy]
                nodes.active = image_texture_node
                connect_sockets(image_texture_node.outputs[0], target_input)

                # The mapping setup following this will connect to the first input of this image texture.
                target_input = image_texture_node.inputs[0]

            node.select = False

            if is_texture_node or self.add_mapping:
                # Add Mapping node.
                mapping_node = nodes.new('ShaderNodeMapping')
                x_offset = x_offset + mapping_node.width + padding
                mapping_node.location = [locx - x_offset, locy]
                connect_sockets(mapping_node.outputs[0], target_input)

                # Add Texture Coordinates node.
                tex_coord_node = nodes.new('ShaderNodeTexCoord')
                x_offset = x_offset + tex_coord_node.width + padding
                tex_coord_node.location = [locx - x_offset, locy]

                is_procedural_texture = is_texture_node and node.type != 'TEX_IMAGE'
                use_generated_coordinates = is_procedural_texture or use_environment_texture
                tex_coord_output = tex_coord_node.outputs[0 if use_generated_coordinates else 2]
                connect_sockets(tex_coord_output, mapping_node.inputs[0])

        return {'FINISHED'}
