# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from bpy.app.translations import pgettext_rpt as rpt_
from bpy.props import BoolProperty
from bpy.types import Operator

from ..i18n import tip as _tip
from ..utils.node_transactions import remove_node_with_bypass
from ..utils.nodes import SNSBase, get_nodes_links, sns_check, sns_check_not_empty, sns_check_space_type


class SMART_NODE_SUITE_OT_delete_unused(Operator, SNSBase):
    """Delete all nodes with unused outputs."""

    bl_idname = 'smart_node_suite.del_unused'
    bl_label = 'Delete Unused Nodes'
    bl_description = _tip(
        'Function: deletes nodes whose outputs are unused, removes empty frames, and bypasses muted nodes. How to use: press the button and confirm; all direct node-tree changes are grouped into one Undo step.',
        '機能: 出力が未使用のノードを削除し、空フレームの削除とミュートノードのバイパスも行います。使い方: 押して確定します。ノードツリーへの直接変更全体が 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    delete_muted: BoolProperty(
        name='Delete Muted',
        description=_tip(
            'Function: removes muted nodes and reconnects compatible links where their internal bypass permits it. How to use: enable only when muted nodes are no longer required as visible bypass placeholders.',
            '機能: ミュートノードを削除し、内部バイパスが許す互換リンクを再接続します。使い方: ミュートノードを可視のバイパスとして残す必要がない場合だけ有効にします。',
        ),
        default=True,
    )
    delete_frames: BoolProperty(
        name='Delete Empty Frames',
        description=_tip(
            'Function: deletes Frame nodes that contain no child nodes, including newly empty nested frames. How to use: enable after large cleanup operations to remove empty organization frames.',
            '機能: 子ノードを含まない フレームノードを、新たに空になった入れ子フレームも含めて削除します。使い方: 大きな整理後に空の整理フレームも削除する場合に有効にします。',
        ),
        default=True,
    )

    @staticmethod
    def is_unused_node(node):
        end_types = {
            'OUTPUT_MATERIAL', 'OUTPUT', 'VIEWER', 'COMPOSITE', 'SPLITVIEWER',
            'OUTPUT_FILE', 'LEVELS', 'OUTPUT_LIGHT', 'OUTPUT_WORLD',
            'GROUP_INPUT', 'GROUP_OUTPUT', 'FRAME', 'WARNING',
        }
        if node.type in end_types:
            return False
        return not any(output.links for output in node.outputs)

    @classmethod
    def poll(cls, context):
        return (
            sns_check(cls, context)
            and sns_check_not_empty(cls, context)
            and sns_check_space_type(
                cls, context,
                {'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree', 'GeometryNodeTree'},
            )
        )

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        selection_names = {node.name for node in nodes if node.select}
        deleted_names: list[str] = []

        # Recompute candidates after every finite pass because deleting an end
        # node can expose another unused upstream node.
        max_passes = max(1, len(nodes))
        for _pass in range(max_passes):
            candidates = [node for node in tuple(nodes) if self.is_unused_node(node)]
            if not candidates:
                break
            for node in candidates:
                name = node.name
                try:
                    nodes.remove(node)
                    deleted_names.append(name)
                except Exception as exc:
                    self.report({'WARNING'}, _tip('Could not delete {name}: {exc}', '{name} を削除できませんでした。').format(name=name, exc=exc))

        if self.delete_frames:
            for _pass in range(max_passes):
                parents_in_use = {node.parent for node in tuple(nodes) if node.parent is not None}
                frames = [node for node in tuple(nodes) if node.type == 'FRAME' and node not in parents_in_use]
                if not frames:
                    break
                for frame in frames:
                    name = frame.name
                    try:
                        nodes.remove(frame)
                        deleted_names.append(name)
                    except Exception as exc:
                        self.report({'WARNING'}, _tip('Could not delete frame {name}: {exc}', 'フレーム {name} を削除できませんでした。').format(name=name, exc=exc))

        if self.delete_muted:
            for node in [candidate for candidate in tuple(nodes) if candidate.mute]:
                name = node.name
                try:
                    remove_node_with_bypass(context.space_data.edit_tree, node)
                    deleted_names.append(name)
                except Exception as exc:
                    self.report({'WARNING'}, _tip('Could not bypass-delete {name}: {exc}', '{name} をバイパス削除できませんでした。').format(name=name, exc=exc))

        unique_names = list(dict.fromkeys(deleted_names))
        for name in unique_names:
            self.report({'INFO'}, rpt_('Node {} deleted').format(name))
        if not unique_names:
            self.report({'INFO'}, _tip('Nothing to delete', '削除するものがありません'))
            return {'CANCELLED'}

        for node in tuple(nodes):
            node.select = node.name in selection_names
        count = len(unique_names)
        self.report({'INFO'}, rpt_('Deleted {} nodes').format(count) if count != 1 else rpt_('Deleted 1 node'))
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
