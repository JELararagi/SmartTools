# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import EnumProperty

from ..i18n import tip as _tip

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_select_hierarchy(Operator, SNSBase):
    bl_idname = "smart_node_suite.select_parent_child"
    bl_label = "Select Parent or Children"
    bl_options = set()

    parent_desc = "Select frame containing the selected nodes"
    child_desc = "Select members of the selected frame"

    option: EnumProperty(
        name="Option",
        description=_tip('Function: chooses whether to select the frame parent or children of the selected frame. How to use: use Select Parent to find the containing frame, or Select Children to select every node inside a selected frame.', '機能: 選択ノードの親フレームを選ぶか、選択フレーム内の子ノードを選ぶかを指定します。使い方: 含んでいるフレームを探す場合は親を選択、フレーム内の全ノードを選ぶ場合は子を選択を使います。'),
        items=(
            ('PARENT', 'Select Parent', parent_desc),
            ('CHILD', 'Select Children', child_desc),
        )
    )

    @classmethod
    def description(cls, _context, properties):
        option = properties.option

        if option == 'PARENT':
            return cls.parent_desc
        elif option == 'CHILD':
            return cls.child_desc

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        option = self.option
        selected = [node for node in nodes if node.select]
        if option == 'PARENT':
            for sel in selected:
                parent = sel.parent
                if parent:
                    parent.select = True
        else:  # option == 'CHILD'
            for sel in selected:
                children = [node for node in nodes if node.parent == sel]
                for kid in children:
                    kid.select = True

        return {'FINISHED'}
