# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_space_type,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_reset_backdrop(Operator, SNSBase):
    """Reset the zoom and position of the background image"""
    bl_idname = 'smart_node_suite.bg_reset'
    bl_label = 'Reset Backdrop'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(cls, context, {'CompositorNodeTree'})

    def execute(self, context):
        context.space_data.backdrop_zoom = 1
        context.space_data.backdrop_offset[0] = 0
        context.space_data.backdrop_offset[1] = 0
        return {'FINISHED'}
