# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

import bpy
from bpy.types import Operator
from bpy.props import BoolProperty

from ..i18n import tip as _tip

from ..utils.nodes import (
    SNSBase,
    sns_check,
    sns_check_selected,
    get_nodes_links,
)


#### ------------------------------ OPERATORS ------------------------------ ####

class SMART_NODE_SUITE_OT_labels_clear(Operator, SNSBase):
    bl_idname = "smart_node_suite.clear_label"
    bl_label = "Clear Label"
    bl_options = {'UNDO'}
    bl_description = _tip('Function: removes custom labels from selected nodes. How to use: select nodes whose visible labels should be cleared, then run this command or confirm the prompt when it appears.', '機能: 選択ノードのカスタムラベルを削除します。使い方: 表示ラベルを消したいノードを選択し、このコマンドを実行します。確認画面が出た場合は確定します。')

    option: BoolProperty(
        name='Immediate Clear',
        description=_tip('Function: controls whether label clearing runs immediately or asks for confirmation. How to use: Smart Node sets this automatically from the UI; disable when you want Blender to show a confirmation dialog.', '機能: ラベル消去を即時実行するか確認を出すか制御します。使い方: パネル側で Smart Node が自動設定します。確認ダイアログを出したい場合だけ無効にします。'),
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_selected(cls, context)

    def execute(self, context):
        nodes, links = get_nodes_links(context)
        for node in [n for n in nodes if n.select]:
            node.label = ''

        return {'FINISHED'}

    def invoke(self, context, event):
        if self.option:
            return self.execute(context)
        else:
            return context.window_manager.invoke_confirm(self, event)
