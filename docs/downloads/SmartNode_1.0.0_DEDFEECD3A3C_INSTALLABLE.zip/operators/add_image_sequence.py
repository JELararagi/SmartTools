# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

from glob import glob
from os import path

import bpy
from bpy.app.translations import pgettext_rpt as rpt_
from bpy.props import BoolProperty, CollectionProperty, IntProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from ..i18n import tip as _tip
from ..utils.nodes import SNSBase, get_nodes_links, node_mid_pt, sns_check, sns_check_space_type


class SMART_NODE_SUITE_OT_add_image_sequence(Operator, SNSBase, ImportHelper):
    """Add an Image Sequence."""

    bl_idname = 'smart_node_suite.add_sequence'
    bl_label = 'Import Sequence'
    bl_description = _tip(
        'Function: imports one numbered image sequence into a Shader or Compositor image node. How to use: select any numbered frame in the file browser, set Relative Path and Start Frame, then confirm; Esc closes the browser without changing data.',
        '機能: 連番画像をシェーダーまたはコンポジターの画像ノードへ読み込みます。使い方: ファイルブラウザーで連番フレームを選び、相対パスと開始フレームを設定して確定します。Esc ではデータを変更せず閉じます。',
    )
    bl_options = {'UNDO'}

    directory: StringProperty(
        name='Directory',
        subtype='DIR_PATH',
        description=_tip(
            'Function: stores the folder selected for image-sequence import. How to use: choose the directory that contains the ordered image files you want to load as one animated texture.',
            '機能: 画像シーケンス読み込み用に選択したフォルダーを保持します。使い方: アニメーションテクスチャとして読み込みたい連番画像が入っているフォルダーを選びます。',
        ),
    )
    filename: StringProperty(
        name='File Name',
        subtype='FILE_NAME',
        description=_tip(
            'Function: stores the active file name chosen in the file browser. How to use: Smart Node uses this with the file list to create the sequence node automatically.',
            '機能: ファイルブラウザーで選択中のファイル名を保持します。使い方: Smart Node がファイル一覧と合わせてシーケンスノードを自動作成するために使います。',
        ),
    )
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'},
        description=_tip(
            'Function: stores the selected image files used to build the sequence. How to use: select the frames in the file browser; Smart Node sorts them before creating the Image node.',
            '機能: シーケンス作成に使う選択済み画像ファイル一覧を保持します。使い方: ファイルブラウザーでフレーム画像を選択すると、Smart Node が順序を整理して 画像ノードを作成します。',
        ),
    )
    relative_path: BoolProperty(
        name='Relative Path',
        description=_tip(
            'Function: stores the imported image path relative to the current .blend file when possible. How to use: leave enabled for portable project folders; disable when an absolute disk path is required.',
            '機能: 可能な場合、読み込む画像パスを現在の .blend ファイルからの相対パスにします。使い方: 共有するプロジェクトでは有効のままにし、絶対パスが必要な場合だけ無効にします。',
        ),
        default=True,
    )
    frame_start: IntProperty(
        name='Start Frame',
        description=_tip(
            'Function: sets the timeline frame used by the first image in the sequence. How to use: enter the frame where playback should start.',
            '機能: シーケンス先頭画像をタイムライン上のどのフレームから再生するか設定します。使い方: 再生開始フレームを入力します。',
        ),
        default=1,
    )

    @classmethod
    def poll(cls, context):
        return sns_check(cls, context) and sns_check_space_type(
            cls, context, {'ShaderNodeTree', 'CompositorNodeTree'}
        )

    def draw(self, context):
        _ = context
        layout = self.layout
        layout.alignment = 'LEFT'
        layout.prop(self, 'relative_path')
        layout.prop(self, 'frame_start')

    def execute(self, context):
        nodes, _links = get_nodes_links(context)
        tree = context.space_data.node_tree
        tree_kind = str(getattr(tree, 'type', '') or '')
        if tree_kind == 'SHADER':
            node_type = 'ShaderNodeTexImage'
        elif tree_kind == 'COMPOSITING':
            node_type = 'CompositorNodeImage'
        else:
            self.report({'ERROR'}, _tip('Unsupported node tree type', '対応していないノードツリータイプです'))
            return {'CANCELLED'}

        directory = bpy.path.abspath(self.directory)
        filename = str(self.filename or '').strip()
        selected_names = [str(item.name or '').strip() for item in self.files if str(item.name or '').strip()]
        if not selected_names and not filename:
            self.report({'WARNING'}, _tip('No file chosen', 'ファイルが選択されていません'))
            return {'CANCELLED'}
        if selected_names and (not filename or not path.exists(path.join(directory, filename))):
            filename = selected_names[0]

        source_path = path.join(directory, filename)
        if not path.isfile(source_path):
            self.report({'ERROR'}, rpt_('{} does not exist').format(filename))
            return {'CANCELLED'}

        without_ext, extension_with_dot = path.splitext(filename)
        if not without_ext or not without_ext[-1].isdigit() or not extension_with_dot:
            self.report({'ERROR'}, rpt_('{} does not seem to be part of a sequence').format(filename))
            return {'CANCELLED'}

        count_numbers = 0
        for char in reversed(without_ext):
            if not char.isdigit():
                break
            count_numbers += 1
        prefix = without_ext[:-count_numbers]
        extension = extension_with_dot[1:]
        sequence_files = sorted(glob(path.join(directory, prefix + '[0-9]' * count_numbers + '.' + extension)))
        if not sequence_files:
            self.report({'ERROR'}, _tip('No matching sequence frames were found', '一致するシーケンスフレームが見つかりませんでした'))
            return {'CANCELLED'}

        existing_nodes = tuple(nodes)
        previous_selection = {node.name for node in existing_nodes if node.select}
        previous_active = getattr(nodes.active, 'name', '') if nodes.active else ''
        if existing_nodes:
            left = min(existing_nodes, key=lambda item: item.location.x)
            xloc = float(left.location.x) - 220.0
            yloc = sum(node_mid_pt(node, 'y') for node in existing_nodes) / len(existing_nodes)
        else:
            xloc = yloc = 0.0

        node = None
        image = None
        image_was_existing = False
        try:
            for candidate in existing_nodes:
                candidate.select = False
            node = nodes.new(type=node_type)
            node.location = (xloc, yloc)
            name_with_hashes = prefix + '#' * count_numbers + extension_with_dot
            node.label = name_with_hashes

            image_path = source_path
            if self.relative_path and bpy.data.filepath:
                try:
                    image_path = bpy.path.relpath(image_path)
                except ValueError:
                    pass

            absolute_source = bpy.path.abspath(image_path)
            image_was_existing = any(
                bpy.path.abspath(str(getattr(candidate, 'filepath', '') or '')) == absolute_source
                for candidate in bpy.data.images
            )
            image = bpy.data.images.load(image_path, check_existing=True)
            image.source = 'SEQUENCE'
            image.name = name_with_hashes
            node.image = image
            image_user = node.image_user if tree_kind == 'SHADER' else node
            first_stem = path.splitext(path.basename(sequence_files[0]))[0]
            image_user.frame_offset = int(first_stem[-count_numbers:]) - 1
            image_user.frame_duration = len(sequence_files)
            image_user.frame_start = int(self.frame_start)
            node.select = True
            nodes.active = node
        except Exception as exc:
            if node is not None:
                try:
                    nodes.remove(node)
                except Exception:
                    pass
            if image is not None and not image_was_existing:
                try:
                    excluded = bool(
                        getattr(image, 'library', None)
                        or getattr(image, 'override_library', None)
                        or getattr(image, 'asset_data', None)
                        or getattr(image, 'use_fake_user', False)
                        or getattr(image, 'packed_file', None)
                        or tuple(getattr(image, 'packed_files', ()) or ())
                    )
                    if not excluded and image.users == 0:
                        bpy.data.images.remove(image)
                except Exception:
                    pass
            for candidate in tuple(nodes):
                candidate.select = candidate.name in previous_selection
            try:
                nodes.active = nodes.get(previous_active)
            except Exception:
                pass
            self.report({'ERROR'}, _tip('Could not import image sequence: {exc}', '画像シーケンスを読み込めませんでした。').format(exc=exc))
            return {'CANCELLED'}

        return {'FINISHED'}
