# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

"""Compatibility façade for the retired sidebar mutation guard.

Panel visibility is owned by ``NODE_PT_smart_node_suite.poll`` and the public
Smart Tools Manager query.  This module intentionally does not scan windows,
change workspace owner filters, alter categories, register handlers, or start
timers.
"""

from __future__ import annotations


_ROOT_PANEL_IDS = (
    'VIEW3D_PT_smart_node_suite',
    'IMAGE_PT_smart_node_suite',
    'NODE_PT_smart_node_suite',
    'SEQUENCER_PT_smart_node_suite',
    'CLIP_PT_smart_node_suite',
    'DOPESHEET_PT_smart_node_suite',
    'GRAPH_PT_smart_node_suite',
    'NLA_PT_smart_node_suite',
    'TEXT_PT_smart_node_suite',
    'FILEBROWSER_PT_smart_node_suite',
    'ASSETBROWSER_PT_smart_node_suite',
    'SPREADSHEET_PT_smart_node_suite',
)


def _smart_node_panel_registered() -> bool:
    try:
        import bpy
        return all(getattr(bpy.types, panel_id, None) is not None for panel_id in _ROOT_PANEL_IDS)
    except Exception:
        return False


def _addon_owner_ids() -> tuple[str, ...]:
    package = str(__package__ or 'smart_node_suite')
    return tuple(dict.fromkeys((package, 'smart_node_suite')))


def ensure_workspace_owner_filters() -> int:
    return 0


def _iter_visible_node_editor_ui_regions(context=None):
    return iter(())


def _region_is_drawn(region) -> bool:
    return False


def _sidebar_is_visible(space, region) -> bool:
    return False


def _set_active_category(region, category: str) -> bool:
    return False


def refresh_smart_node_sidebars(context=None, *, force_if_active: bool = True, activate_category: bool = False) -> int:
    return 0


def register() -> None:
    return None


def unregister() -> None:
    return None
