CONTRACT_VERSION = 2
EXTENSION_ID = "smart_node_suite"
CONFIG_FOLDER = "Smart_Node_Suite"
CONFIG_FILE = "Smart_Node_Suite.json"
STATE_SAVE_PATH = "window_manager.smart_node_suite_npanel_state_save"
SECTION_OPEN_PATH = "window_manager.smart_node_suite_section_always_on"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.smart_node_suite_legacy_cleanup_enabled",
    "window_manager.noise_nodes_background_callbacks",
    "window_manager.noise_nodes_node_wrangler_override",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (
    "window_manager.smart_node_suite_*",
    "window_manager.noise_nodes_*",
    "preferences",
    "scene.na_settings",
    "scene.node_color_tools",
)
EXCLUDED_TRANSIENT_PATHS = (
    "preferences.bl_idname",
    "scene.na_settings.name",
    "scene.node_color_tools.name",
)
ROOT_PANEL_IDS = (
    "VIEW3D_PT_smart_node_suite",
    "IMAGE_PT_smart_node_suite",
    "NODE_PT_smart_node_suite",
    "SEQUENCER_PT_smart_node_suite",
    "CLIP_PT_smart_node_suite",
    "DOPESHEET_PT_smart_node_suite",
    "GRAPH_PT_smart_node_suite",
    "NLA_PT_smart_node_suite",
    "TEXT_PT_smart_node_suite",
    "FILEBROWSER_PT_smart_node_suite",
    "ASSETBROWSER_PT_smart_node_suite",
    "SPREADSHEET_PT_smart_node_suite",
)
