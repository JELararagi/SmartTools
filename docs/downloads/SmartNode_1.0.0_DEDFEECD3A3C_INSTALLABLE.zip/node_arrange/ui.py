from bpy.types import Context, Panel

from .utils import get_ntree
from .. import manager_rules, ui_sections, rna_ownership
from ..translation import loc_text as _lt
from ..addon_owner import addon_owner_id


class NodePanel:
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Node')

    @classmethod
    def poll(cls, context: Context) -> bool:
        if not manager_rules.panel_poll(
            context,
            physical_space='NODE_EDITOR',
            logical_keys=(
                'SHADER_EDITOR', 'COMPOSITOR',
                'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR',
            ),
        ):
            return False
        try:
            return get_ntree() is not None
        except Exception:
            return False


class NA_PT_node_arrange(NodePanel, Panel):
    bl_idname = 'NA_PT_node_arrange'
    bl_label = _lt('Node Arrange', 'ノード整列')

    def draw(self, context: Context) -> None:
        layout = self.layout
        try:
            settings = context.scene.na_settings  # type: ignore
        except Exception:
            return
        _box, layout, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_panel', _lt('Node Arrange', 'ノード整列'), icon='NODETREE', topic='node_arrange', default_open=False)
        layout.use_property_split = True

        _box, spacing, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_spacing', _lt('Spacing'), icon='ARROW_LEFTRIGHT', topic='node_arrange', default_open=False)
        spacing.prop(settings, "margin", text=" ")

        _box, align_box, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_alignment', _lt('Alignment'), icon='ORIENTATION_GLOBAL', topic='node_arrange', default_open=False)
        col = align_box.column()
        col.prop(settings, "direction", text=_lt("Nodes"))
        col.prop(settings, "socket_alignment", text=_lt("Sockets"))

        _box, crossed, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_crossed_links', _lt('Crossed Links'), icon='LINKED', topic='node_arrange', default_open=False)
        col = crossed.column()
        col.prop(settings, "iterations")

        _box, reroutes, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_reroutes', _lt('Reroutes'), icon='NODETREE', topic='node_arrange', default_open=False)
        col = reroutes.column(heading=_lt("Reroutes"))
        col.prop(settings, "add_reroutes", text=_lt("Add"))
        sub = col.column()
        sub.active = True
        sub.prop(settings, "keep_reroutes_outside_frames", text=_lt("Place Outside Frames", "フレーム外へ配置"))

        _box, collapsed, _expanded = ui_sections.draw_group(layout, context, 'node_arrange_collapsed_nodes', _lt('Collapsed Nodes'), icon='FULLSCREEN_EXIT', topic='node_arrange', default_open=False)
        col = collapsed.column()
        col.prop(settings, "stack_collapsed")
        sub = col.column()
        sub.active = True
        sub.prop(settings, "stack_margin_y_fac")

        layout.use_property_split = False
        layout.prop(settings, "arrange_mode", expand=True)
        layout.use_property_split = True
        if settings.arrange_mode == 'NODES':
            layout.operator("node.arrange_selected_nodes", text=_lt("Arrange Selected Nodes"))
        else:
            layout.operator("node.arrange_all_trees")


class NA_PT_node_recenter(NodePanel, Panel):
    bl_idname = 'NA_PT_node_recenter'
    bl_label = _lt('Node Recenter', 'ノード再センター')

    def draw(self, context: Context) -> None:
        layout = self.layout
        try:
            settings = context.scene.na_settings  # type: ignore
        except Exception:
            return

        _box, layout, _expanded = ui_sections.draw_group(layout, context, 'node_recenter_panel', _lt('Node Recenter', 'ノード再センター'), icon='PIVOT_MEDIAN', topic='node_arrange', default_open=False)
        layout.use_property_split = True
        layout.prop(settings, "origin")
        layout.use_property_split = False
        layout.prop(settings, "recenter_mode", expand=True)
        if settings.recenter_mode == 'NODES':
            layout.operator("node.recenter_selected_nodes", text=_lt("Recenter Selected Nodes"))
        else:
            layout.operator("node.recenter_all_trees")


classes = (
  NA_PT_node_arrange,
  NA_PT_node_recenter,
)


_registered_class_tokens = []


def register() -> None:
    if _registered_class_tokens:
        return
    _registered_class_tokens.extend(rna_ownership.register_classes(classes))


def unregister() -> None:
    rna_ownership.unregister_classes(_registered_class_tokens)
