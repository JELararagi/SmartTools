# type: ignore

"""Node Arrange properties backed only by Smart Node Suite's canonical JSON.

This module intentionally owns no timer, handler, message bus subscription, thread,
or alternate settings file. Property updates request one bounded atomic save through
``persistent_settings``; applying saved values suppresses those update writes.
"""

from __future__ import annotations

import bpy
from bpy.props import (
    BoolProperty as _BoolProperty,
    EnumProperty as _EnumProperty,
    FloatProperty as _FloatProperty,
    IntProperty as _IntProperty,
    IntVectorProperty as _IntVectorProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup, Scene

from ..i18n import table_ja
from ..translation import loc_text as _lt


_NA_PERSISTENCE_APPLYING = False
_NA_CACHE: dict[str, object] | None = None
_NA_PROPS = (
    'arrange_mode',
    'margin',
    'iterations',
    'direction',
    'socket_alignment',
    'add_reroutes',
    'keep_reroutes_outside_frames',
    'stack_collapsed',
    'stack_margin_y_fac',
    'recenter_mode',
    'enable_recenter_hotkey',
    'origin',
)
_registered_class_tokens = []
_na_settings_token = None


def _canonical_settings():
    try:
        from .. import persistent_settings
        return persistent_settings
    except Exception:
        return None


def _na_json_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        sequence = list(value)
    except Exception:
        return str(value)
    return sequence[:64]


def _na_has_rna_property(settings, name: str) -> bool:
    if settings is None or not name:
        return False
    try:
        props = getattr(getattr(settings, 'bl_rna', None), 'properties', None)
        return props is not None and props.get(str(name)) is not None
    except Exception:
        try:
            return hasattr(settings, str(name))
        except Exception:
            return False


def _na_collect(settings) -> dict[str, object]:
    data: dict[str, object] = {}
    if settings is None:
        return data
    for name in _NA_PROPS:
        if not _na_has_rna_property(settings, name):
            continue
        try:
            data[name] = _na_json_value(getattr(settings, name))
        except Exception:
            continue
    return data


def _na_read() -> dict[str, object]:
    canonical = _canonical_settings()
    if canonical is None:
        return {}
    try:
        values = canonical.load_named_group('na_settings')
    except Exception:
        return {}
    return values if isinstance(values, dict) else {}


def save_node_arrange_settings(settings=None, context=None) -> None:
    """Save one Node Arrange group through the suite's canonical store only."""
    global _NA_CACHE
    canonical = _canonical_settings()
    if canonical is None or _NA_PERSISTENCE_APPLYING:
        return
    try:
        if canonical.is_applying():
            return
    except Exception:
        pass
    if settings is None:
        try:
            settings = getattr(getattr(bpy.context, 'scene', None), 'na_settings', None)
        except Exception:
            settings = None
    data = _na_collect(settings)
    if not data or data == _NA_CACHE:
        return
    try:
        if canonical.save_named_group('na_settings', data, context=context, source=settings):
            _NA_CACHE = dict(data)
    except Exception:
        # Saving is best-effort from an RNA update callback. The canonical writer
        # keeps the prior valid main/.bak files if a write fails.
        return


def apply_node_arrange_settings(settings=None) -> None:
    """Apply saved values once; no scene scan or persistent callback is installed."""
    global _NA_PERSISTENCE_APPLYING, _NA_CACHE
    if settings is None:
        try:
            settings = getattr(getattr(bpy.context, 'scene', None), 'na_settings', None)
        except Exception:
            settings = None
    if settings is None:
        return
    data = _na_read()
    if not data:
        _NA_CACHE = _na_collect(settings)
        return
    _NA_PERSISTENCE_APPLYING = True
    try:
        for name, value in tuple(data.items())[:64]:
            if name not in _NA_PROPS or not _na_has_rna_property(settings, name):
                continue
            try:
                setattr(settings, name, value)
            except Exception:
                continue
    finally:
        _NA_PERSISTENCE_APPLYING = False
    _NA_CACHE = _na_collect(settings)


def _na_chain_update(callback):
    def _update(self, context):
        if callable(callback):
            callback(self, context)
        if _NA_PERSISTENCE_APPLYING:
            return
        canonical = _canonical_settings()
        try:
            if canonical is not None and canonical.is_applying():
                return
        except Exception:
            pass
        save_node_arrange_settings(self, context=context)

    return _update


def _na_fallback_property_description(kwargs: dict) -> str:
    label = str(kwargs.get('name') or '').strip() or _lt('Node Arrange setting', 'ノード整列設定')
    return _lt(
        f'Function: configures {label}. How to use: change it in the Smart Node N-panel; when N-panel State Save is enabled, the value is written immediately to the suite JSON and restored on the next registration.',
        f'機能: {table_ja(label)}を設定します。使い方: Smart Node の N パネルで変更します。「Nパネル状態保存」が有効な場合は単一 JSON へ即時保存され、次回登録時に復元されます。',
    )


def _na_wrap_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _na_fallback_property_description(kwargs)
        kwargs['update'] = _na_chain_update(kwargs.get('update'))
        return factory(*args, **kwargs)

    return _wrapped


BoolProperty = _na_wrap_property(_BoolProperty)
EnumProperty = _na_wrap_property(_EnumProperty)
FloatProperty = _na_wrap_property(_FloatProperty)
IntProperty = _na_wrap_property(_IntProperty)
IntVectorProperty = _na_wrap_property(_IntVectorProperty)


def _na_register_handler() -> None:
    """Compatibility no-op: Node Arrange owns no resident handler."""
    return None


def _na_unregister_handler() -> None:
    """Compatibility no-op paired with :func:`_na_register_handler`."""
    return None


def _na_update_hotkey(self, context):
    # Automatic keymap installation is intentionally disabled suite-wide.
    _ = (self, context)


_MODE_KWARGS = dict(
    items=(
        ('NODES', _lt('Nodes', 'ノード'), _lt('Selected nodes in the current node tree', '現在のノードツリーで選択中のノード')),
        ('TREES', _lt('Trees', 'ツリー'), _lt('All node trees in the current .blend file', '現在の .blend ファイル内の全ノードツリー')),
    ),
    name=_lt('Mode', 'モード'),
    default='NODES',
    options=set(),
)


class NA_PG_Settings(PropertyGroup):
    arrange_mode: EnumProperty(
        **_MODE_KWARGS,
        description=_lt(
            'Function: selects whether Arrange affects the current selection or every node tree. How to use: choose Nodes for the active tree, or Trees for an explicit whole-file operation.',
            '機能: 整列対象を現在の選択または全ノードツリーから選びます。使い方: アクティブツリーだけなら「ノード」、ファイル全体を明示処理する場合は「ツリー」を選びます。',
        ),
    )

    margin: IntVectorProperty(
        name=_lt('Spacing', '間隔'),
        description=_lt(
            'Function: sets horizontal and vertical space between arranged nodes. How to use: increase X or Y when links or node bodies overlap.',
            '機能: 整列後のノード間の横・縦間隔を設定します。使い方: リンクやノード本体が重なる場合は X または Y を増やします。',
        ),
        default=(50, 50),
        min=0,
        options=set(),
        subtype='XYZ',
        size=2,
    )

    iterations: IntProperty(
        name=_lt('Iterations', '反復回数'),
        description=_lt(
            'Function: sets the finite number of crossing-reduction passes used only when Arrange is executed. How to use: raise it for complex graphs; higher values take longer but create no idle work.',
            '機能: 整列実行時だけ使う交差低減処理の有限反復回数を設定します。使い方: 複雑なグラフでは増やします。値を上げるほど実行時間は増えますが、待機時処理は発生しません。',
        ),
        default=25,
        min=1,
        max=10000,
        options=set(),
    )

    direction: EnumProperty(
        items=(
            ('LEFT_DOWN', _lt('Bottom Left', '左下'), ''),
            ('RIGHT_DOWN', _lt('Bottom Right', '右下'), ''),
            ('LEFT_UP', _lt('Top Left', '左上'), ''),
            ('RIGHT_UP', _lt('Top Right', '右上'), ''),
            None,
            (
                'BALANCED',
                _lt('Balanced', '均等'),
                _lt(
                    'Function: combines four directional layouts to reduce directional bias. How to use: choose this for a neutral automatic result.',
                    '機能: 4方向の配置を組み合わせて方向の偏りを抑えます。使い方: 中立的な自動整列結果が必要な場合に選びます。',
                ),
            ),
        ),
        name=_lt('Node Alignment', 'ノード配置'),
        description=_lt(
            'Function: controls the primary layout direction. How to use: choose the corner toward which upstream/downstream ranks should be arranged.',
            '機能: レイアウトの主方向を設定します。使い方: 上流・下流の段を配置したい方向を選びます。',
        ),
        default='BALANCED',
        options=set(),
    )

    socket_alignment: EnumProperty(
        items=(
            ('NONE', _lt('None', 'なし'), _lt('Align node tops without forcing socket alignment', 'ソケット位置を強制せずノード上端を基準に配置します')),
            ('MODERATE', _lt('Moderate', '中程度'), _lt('Balance socket alignment and node-top alignment', 'ソケット位置とノード上端の配置を両立します')),
            ('FULL', _lt('Full', '完全'), _lt('Always try to align connected sockets', '接続ソケットの位置を常に揃えます')),
        ),
        name=_lt('Socket Alignment', 'ソケット配置'),
        description=_lt(
            'Function: chooses how strongly connected sockets are aligned vertically. How to use: use Moderate for general graphs and Full when straight links are more important.',
            '機能: 接続ソケットを縦方向に揃える強さを選びます。使い方: 通常は「中程度」、直線的なリンクを優先する場合は「完全」を選びます。',
        ),
        default='MODERATE',
        options=set(),
    )

    add_reroutes: BoolProperty(
        name=_lt('Add Reroutes', 'リルートを追加'),
        description=_lt(
            'Function: allows Arrange to insert or simplify reroute nodes while routing long links. How to use: enable for clearer routed links; disable to move existing nodes without creating reroutes.',
            '機能: 長いリンクを整理する際にリルートノードの追加・簡略化を許可します。使い方: 見やすい配線にする場合は有効、リルートを新規作成せず既存ノードだけ移動する場合は無効にします。',
        ),
        default=True,
        options=set(),
    )

    keep_reroutes_outside_frames: BoolProperty(
        name=_lt('Place Reroutes Outside Frames', 'リルートをフレーム外へ配置'),
        description=_lt(
            'Function: attaches generated reroutes to the lowest common frame instead of nesting them deeply. How to use: enable when frame contents should remain uncluttered.',
            '機能: 生成するリルートを深いフレーム内ではなく最下位の共通フレームへ配置します。使い方: フレーム内部を整理して保ちたい場合に有効にします。',
        ),
        default=False,
        options=set(),
    )

    stack_collapsed: BoolProperty(
        name=_lt('Stack Collapsed Nodes', '折りたたみノードを積層'),
        description=_lt(
            'Function: stacks compatible collapsed Math and Vector Math nodes during Arrange. How to use: enable to compress repeated collapsed chains.',
            '機能: 整列時に互換性のある折りたたみ済みの数式 / ベクトル演算ノードを積層します。使い方: 反復する折りたたみチェーンを圧縮したい場合に有効にします。',
        ),
        default=False,
        options=set(),
    )

    stack_margin_y_fac: FloatProperty(
        name=_lt('Spacing Y Factor', 'Y 間隔係数'),
        description=_lt(
            'Function: scales vertical spacing between stacked collapsed nodes. How to use: lower it for a tighter stack or raise it for clearer separation.',
            '機能: 積層した折りたたみノード間の縦間隔を倍率で設定します。使い方: 密にする場合は下げ、見分けやすくする場合は上げます。',
        ),
        default=0.5,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        options=set(),
    )

    recenter_mode: EnumProperty(
        **_MODE_KWARGS,
        description=_lt(
            'Function: selects whether Recenter affects selected nodes or every node tree. How to use: choose Trees only when you intentionally want a whole-file operation.',
            '機能: 再センター対象を選択ノードまたは全ノードツリーから選びます。使い方: ファイル全体を意図して処理する場合だけ「ツリー」を選びます。',
        ),
    )

    enable_recenter_hotkey: BoolProperty(
        name=_lt('Enable Alt+G Hotkey', 'Alt+G ホットキーを有効化'),
        description=_lt(
            'Function: records the preferred manual hotkey state without installing a keymap. How to use: right-click the Recenter Selected button in the sidebar and assign a shortcut to it; Smart Node never takes Alt+G automatically.',
            '機能: キーマップを自動登録せず、手動ホットキー利用の設定だけを保持します。使い方: サイドバーの「選択を再センター」のボタンを右クリックして、ショートカットを割り当てます。Smart Node が Alt+G を自動で取ることはありません。',
        ),
        default=False,
        options=set(),
        update=_na_update_hotkey,
    )

    origin: EnumProperty(
        items=(
            ('CENTER', _lt('Center', '中央'), _lt('Move the selected roots so the average selected-node location becomes (0, 0)', '選択ノードの平均位置が (0, 0) になるよう選択ルートを移動します')),
            ('ACTIVE_OUTPUT', _lt('Active Output', 'アクティブ出力'), _lt('Move the selected roots so active output nodes become centered at (0, 0)', 'アクティブ出力ノードが (0, 0) の中心になるよう選択ルートを移動します')),
            ('ACTIVE_NODE', _lt('Active Node', 'アクティブノード'), _lt('Move the selected roots so the active node is placed at (0, 0)', 'アクティブノードが (0, 0) に配置されるよう選択ルートを移動します')),
        ),
        name=_lt('Origin', '基準'),
        description=_lt(
            'Function: chooses the point used as the recenter origin. How to use: choose Center, Active Output, or Active Node before running Recenter.',
            '機能: 再センター時の基準点を選びます。使い方: 実行前に「中央」「アクティブ出力」「アクティブノード」から選択します。',
        ),
        default='CENTER',
        options=set(),
    )



def register() -> None:
    global _na_settings_token
    if _registered_class_tokens or _na_settings_token is not None:
        return
    from .. import rna_ownership
    try:
        rna_ownership.release_legacy_pointer_property(Scene, 'na_settings', NA_PG_Settings)
        _registered_class_tokens.append(rna_ownership.register_class(NA_PG_Settings))
        _na_settings_token = rna_ownership.install_property(
            Scene,
            'na_settings',
            PointerProperty(
                type=NA_PG_Settings,
                description=_lt(
                    'Function: stores Node Arrange controls for the active scene. How to use: edit them from Smart Node > Layout / Arrange.',
                    '機能: アクティブシーンのノード整列設定を保持します。使い方: Smart Node > レイアウト / 整列から編集します。',
                ),
            ),
        )
        # A finite one-shot supports direct submodule reloads; root registration
        # performs the authoritative apply after every property group exists.
        apply_node_arrange_settings(getattr(getattr(bpy.context, 'scene', None), 'na_settings', None))
    except Exception:
        if _na_settings_token is not None:
            try:
                rna_ownership.remove_property(_na_settings_token)
            except Exception:
                pass
            _na_settings_token = None
        rna_ownership.unregister_classes(_registered_class_tokens)
        raise


def unregister() -> None:
    global _NA_CACHE, _na_settings_token
    from .. import rna_ownership
    if _na_settings_token is not None:
        try:
            rna_ownership.remove_property(_na_settings_token)
        except Exception:
            pass
        _na_settings_token = None
    rna_ownership.unregister_classes(_registered_class_tokens)
    _NA_CACHE = None

