# Node Arrange upstream source notice

The `node_arrange` component is attributed to Leonardo Pike-Excell and the
original repository:

https://github.com/Leonardo-Pike-Excell/node-arrange

The pinned upstream reference is commit `8ca5e29193f4934378c0ba064a4734f7eb12c9bf`,
upstream version `1.12.1`. This notice records a source comparison against the
referenced upstream material; an independently acquired archive/version was not
established. The comparison found 16 same-path mappings, 113 non-trivial AST
matches across 10 files, and 0 byte-exact matches.

The upstream manifest declares GPL-3.0-or-later. The root LICENSE is the GPL
version 3 text (included unchanged as UPSTREAM_LICENSE.txt). The compared
Python file headers declare GPL-2.0-or-later.

The separate NetworkX/PADS secondary declaration review remains unresolved.
No sales, license, or source-offer clearance is asserted by this notice.
