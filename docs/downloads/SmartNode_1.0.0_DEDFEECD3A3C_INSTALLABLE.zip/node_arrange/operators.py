from __future__ import annotations

from collections.abc import Iterable
from statistics import fmean
from typing import Type, cast

import bpy
from bl_operators.node_editor.node_functions import node_editor_poll
from bpy.types import Context, Operator
from mathutils import Vector

from . import config
from .utils import abs_loc, get_ntree
from ..translation import loc_text as _lt
from .. import rna_ownership
from ..utils.node_transactions import socket_index


_registered_class_tokens = []


def _node_size(node):
    try:
        width = float(getattr(getattr(node, 'dimensions', None), 'x', 0.0) or 0.0)
    except Exception:
        width = 0.0
    try:
        height = float(getattr(getattr(node, 'dimensions', None), 'y', 0.0) or 0.0)
    except Exception:
        height = 0.0
    if width <= 1.0:
        try:
            width = float(getattr(node, 'width', 180.0) or 180.0)
        except Exception:
            width = 180.0
    if height <= 1.0:
        height = 120.0
    return width, height


def _simple_sugiyama_layout(ntree):
    """Finite built-in fallback that changes locations only."""
    selected = list(getattr(config, 'selected', ()) or [])
    nodes = [node for node in selected if getattr(node, 'bl_idname', '') != 'NodeFrame']
    if not nodes:
        return
    node_set = set(nodes)
    incoming = {node: set() for node in nodes}
    outgoing = {node: set() for node in nodes}
    try:
        links = tuple(getattr(ntree, 'links', ()) or ())
    except Exception:
        links = ()
    for link in links:
        try:
            src = link.from_node
            dst = link.to_node
        except Exception:
            continue
        if src in node_set and dst in node_set and src is not dst:
            outgoing[src].add(dst)
            incoming[dst].add(src)

    ranks = {node: 0 for node in nodes}
    ready = [node for node in nodes if not incoming[node]] or list(nodes)
    seen = set()
    while ready:
        node = ready.pop(0)
        if node in seen:
            continue
        seen.add(node)
        for child in sorted(outgoing[node], key=lambda item: str(getattr(item, 'name', ''))):
            ranks[child] = max(ranks.get(child, 0), ranks.get(node, 0) + 1)
            if incoming[child].issubset(seen):
                ready.append(child)
    for node in nodes:
        if node not in seen:
            ranks[node] = max(ranks.values(), default=0) + 1

    levels: dict[int, list] = {}
    for node, rank in ranks.items():
        levels.setdefault(rank, []).append(node)
    for values in levels.values():
        values.sort(
            key=lambda item: (
                float(getattr(getattr(item, 'location', None), 'y', 0.0) or 0.0),
                str(getattr(item, 'name', '')),
            ),
            reverse=True,
        )

    try:
        settings = getattr(config, 'SETTINGS', None)
        margin = tuple(float(v) for v in getattr(settings, 'margin', (50.0, 50.0)))
        direction = str(getattr(settings, 'direction', 'BALANCED') or 'BALANCED')
    except Exception:
        margin = (50.0, 50.0)
        direction = 'BALANCED'
    max_w = max((_node_size(node)[0] for node in nodes), default=180.0)
    max_h = max((_node_size(node)[1] for node in nodes), default=120.0)
    x_step = max_w + max(20.0, margin[0])
    y_step = max_h + max(20.0, margin[1])
    x_sign = -1.0 if direction.startswith('LEFT') else 1.0
    y_sign = 1.0 if direction.endswith('UP') else -1.0

    old_x = [float(getattr(node.location, 'x', 0.0) or 0.0) for node in nodes]
    old_y = [float(getattr(node.location, 'y', 0.0) or 0.0) for node in nodes]
    old_center = Vector((sum(old_x) / len(old_x), sum(old_y) / len(old_y)))
    new_positions = {}
    for rank in sorted(levels):
        for row_index, node in enumerate(levels[rank]):
            new_positions[node] = Vector((rank * x_step * x_sign, row_index * y_step * y_sign))
    new_center = Vector((
        sum(pos.x for pos in new_positions.values()) / len(new_positions),
        sum(pos.y for pos in new_positions.values()) / len(new_positions),
    ))
    offset = old_center - new_center
    for node, position in new_positions.items():
        node.location.x = position.x + offset.x
        node.location.y = position.y + offset.y


def sugiyama_layout(ntree):
    """Import the optional heavy graph implementation only when Arrange executes."""
    try:
        from .arrange.sugiyama import sugiyama_layout as graph_layout
    except Exception:
        graph_layout = None
    if graph_layout is not None:
        return graph_layout(ntree)
    return _simple_sugiyama_layout(ntree)


def _rna_pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _simple_id_properties(node) -> dict[str, object]:
    values: dict[str, object] = {}
    try:
        keys = tuple(node.keys())[:128]
    except Exception:
        keys = ()
    for key in keys:
        try:
            value = node[key]
        except Exception:
            continue
        if value is None or isinstance(value, (bool, int, float, str)):
            values[str(key)[:256]] = value
            continue
        try:
            sequence = tuple(value)
        except Exception:
            continue
        if len(sequence) <= 32 and all(isinstance(item, (bool, int, float, str)) for item in sequence):
            values[str(key)[:256]] = sequence
    return values


def _snapshot_tree_state(ntree) -> dict[str, object]:
    """Capture enough plain state to roll back the arranger's structural edits.

    The heavy arranger only creates/removes reroutes, rewires links, changes
    multi-input order, moves nodes, reparents nodes, and toggles frame shrink.
    No RNA object is stored outside this function's caller-local transaction.
    """
    records: list[dict[str, object]] = []
    pointers: set[int] = set()
    for node in tuple(ntree.nodes):
        pointer = _rna_pointer(node)
        pointers.add(pointer)
        try:
            location = (float(node.location.x), float(node.location.y))
        except Exception:
            location = (0.0, 0.0)
        try:
            color = tuple(float(value) for value in node.color)
        except Exception:
            color = (0.0, 0.0, 0.0)
        record: dict[str, object] = {
            'pointer': pointer,
            'name': str(getattr(node, 'name', '') or ''),
            'bl_idname': str(getattr(node, 'bl_idname', '') or ''),
            'parent': str(getattr(getattr(node, 'parent', None), 'name', '') or ''),
            'location': location,
            'select': bool(getattr(node, 'select', False)),
            'hide': bool(getattr(node, 'hide', False)),
            'mute': bool(getattr(node, 'mute', False)),
            'label': str(getattr(node, 'label', '') or ''),
            'width': float(getattr(node, 'width', 140.0) or 140.0),
            'use_custom_color': bool(getattr(node, 'use_custom_color', False)),
            'color': color,
            'shrink': bool(getattr(node, 'shrink', False)),
            'socket_idname': str(getattr(node, 'socket_idname', '') or ''),
            'id_properties': _simple_id_properties(node),
        }
        records.append(record)

    links: list[tuple[str, int, str, int, int]] = []
    for link in tuple(ntree.links):
        try:
            from_index = socket_index(link.from_node.outputs, link.from_socket)
            to_index = socket_index(link.to_node.inputs, link.to_socket)
            if from_index < 0 or to_index < 0:
                continue
            links.append((
                str(link.from_node.name), int(from_index),
                str(link.to_node.name), int(to_index),
                int(getattr(link, 'multi_input_sort_id', -1)),
            ))
        except Exception:
            continue
    active = str(getattr(getattr(ntree.nodes, 'active', None), 'name', '') or '')
    return {'nodes': tuple(records), 'pointers': frozenset(pointers), 'links': tuple(links), 'active': active}


def _restore_tree_state(ntree, state: dict[str, object]) -> bool:
    records = tuple(state.get('nodes', ()) or ())
    original_pointers = set(state.get('pointers', ()) or ())
    try:
        for node in reversed(tuple(ntree.nodes)):
            if _rna_pointer(node) not in original_pointers:
                ntree.nodes.remove(node)

        by_name = {str(node.name): node for node in tuple(ntree.nodes)}
        for record in records:
            name = str(record.get('name', '') or '')
            if name in by_name:
                continue
            if str(record.get('bl_idname', '') or '') != 'NodeReroute':
                raise RuntimeError(f'cannot restore removed non-reroute node: {name}')
            node = ntree.nodes.new(type='NodeReroute')
            node.name = name
            by_name[name] = node

        # Detach first so all recorded locations can be restored as local values.
        for record in records:
            node = by_name.get(str(record.get('name', '') or ''))
            if node is not None:
                try:
                    node.parent = None
                except Exception:
                    pass

        for record in records:
            node = by_name.get(str(record.get('name', '') or ''))
            if node is None:
                raise RuntimeError(f'missing node during rollback: {record.get("name", "")}')
            for attr in ('select', 'hide', 'mute', 'label', 'width', 'use_custom_color', 'shrink'):
                try:
                    setattr(node, attr, record.get(attr))
                except Exception:
                    pass
            try:
                color = tuple(record.get('color', ()) or ())
                for index, value in enumerate(color[:3]):
                    node.color[index] = float(value)
            except Exception:
                pass
            try:
                socket_idname = str(record.get('socket_idname', '') or '')
                if socket_idname and hasattr(node, 'socket_idname'):
                    node.socket_idname = socket_idname
            except Exception:
                pass
            try:
                for key in tuple(node.keys()):
                    if key not in record.get('id_properties', {}):
                        del node[key]
                for key, value in dict(record.get('id_properties', {}) or {}).items():
                    node[key] = value
            except Exception:
                pass

        for record in records:
            node = by_name[str(record.get('name', '') or '')]
            parent_name = str(record.get('parent', '') or '')
            try:
                node.parent = by_name.get(parent_name) if parent_name else None
            except Exception:
                pass
            try:
                x, y = tuple(record.get('location', (0.0, 0.0)))[:2]
                node.location.x = float(x)
                node.location.y = float(y)
            except Exception:
                pass

        for link in tuple(ntree.links):
            ntree.links.remove(link)
        created_links: list[tuple[object, int]] = []
        for from_name, from_index, to_name, to_index, sort_id in tuple(state.get('links', ()) or ()):
            source = by_name.get(str(from_name))
            target = by_name.get(str(to_name))
            if source is None or target is None:
                raise RuntimeError('link endpoint missing during rollback')
            if not (0 <= int(from_index) < len(source.outputs) and 0 <= int(to_index) < len(target.inputs)):
                raise RuntimeError('socket index changed during rollback')
            created = ntree.links.new(source.outputs[int(from_index)], target.inputs[int(to_index)])
            created_links.append((created, int(sort_id)))

        # Re-establish multi-input ordering when Blender exposes the swap API.
        groups: dict[tuple[str, int], list[tuple[object, int]]] = {}
        for link, desired_id in created_links:
            try:
                if bool(getattr(link.to_socket, 'is_multi_input', False)):
                    key = (str(link.to_node.name), socket_index(link.to_node.inputs, link.to_socket))
                    groups.setdefault(key, []).append((link, desired_id))
            except Exception:
                continue
        for values in groups.values():
            for link, desired_id in sorted(values, key=lambda item: item[1]):
                try:
                    current = int(getattr(link, 'multi_input_sort_id', desired_id))
                    if current == desired_id:
                        continue
                    other = min(
                        (candidate for candidate, _ in values),
                        key=lambda candidate: abs(int(getattr(candidate, 'multi_input_sort_id', desired_id)) - desired_id),
                    )
                    link.swap_multi_input_sort_id(other)
                except Exception:
                    pass

        active_name = str(state.get('active', '') or '')
        ntree.nodes.active = by_name.get(active_name) if active_name else None
        return True
    except Exception:
        return False


def _snapshot_locations(nodes) -> dict[object, tuple[float, float, object]]:
    snapshot = {}
    for node in tuple(nodes):
        try:
            snapshot[node] = (float(node.location.x), float(node.location.y), node.parent)
        except Exception:
            continue
    return snapshot


def _restore_locations(snapshot) -> None:
    for node, (x, y, parent) in snapshot.items():
        try:
            node.parent = parent
            node.location.x = x
            node.location.y = y
        except Exception:
            continue


def _arrange_tree(ntree, selected, settings) -> bool:
    if not selected:
        return False
    snapshot = _snapshot_tree_state(ntree)
    config.selected = list(selected)
    config.SETTINGS = settings
    config.MARGIN = Vector(settings.margin).freeze()
    try:
        sugiyama_layout(ntree)
        return True
    except Exception as exc:
        if not _restore_tree_state(ntree, snapshot):
            raise RuntimeError(f'arrange failed and graph rollback could not be completed: {exc}') from exc
        raise
    finally:
        config.reset()


def _selected_roots(selected):
    selected_set = set(selected)
    return [node for node in selected if getattr(node, 'parent', None) not in selected_set]


def _recenter_tree(ntree, selected, origin_type: str) -> tuple[bool, str | None]:
    non_frames = [node for node in selected if getattr(node, 'bl_idname', '') != 'NodeFrame']
    if not non_frames:
        return False, _lt('No valid nodes selected', '有効なノードが選択されていません')

    if origin_type == 'ACTIVE_NODE':
        active = getattr(ntree.nodes, 'active', None)
        if active not in non_frames:
            return False, _lt('No valid active node', '有効なアクティブノードがありません')
        origin = abs_loc(active)
    else:
        if origin_type == 'ACTIVE_OUTPUT':
            # The output must move with the nodes to end at (0, 0), as ACTIVE_NODE requires too.
            origin_nodes = [node for node in non_frames if getattr(node, 'is_active_output', False)]
            if not origin_nodes:
                return False, _lt('The active output is not selected', 'アクティブ出力が選択されていません')
        else:
            origin_nodes = non_frames
        origin = Vector(map(fmean, zip(*map(abs_loc, origin_nodes))))

    roots = _selected_roots(selected)
    snapshot = _snapshot_locations(roots)
    try:
        for node in roots:
            node.location.x -= origin.x
            node.location.y -= origin.y
    except Exception:
        _restore_locations(snapshot)
        raise
    return True, None


class NodeOperator:
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls: Type[Operator], context: Context) -> bool:  # type: ignore
        if not node_editor_poll(cls, context):
            return False
        try:
            ntree = getattr(getattr(context, 'space_data', None), 'edit_tree', None)
        except Exception:
            ntree = None
        if ntree is None or getattr(ntree, 'bl_idname', '') == 'NodeTreeUndefined':
            cls.poll_message_set(_lt('Active node tree is undefined.', 'アクティブなノードツリーが未定義です。'))
            return False
        return True


class NA_OT_ArrangeSelectedNodes(NodeOperator, Operator):
    bl_idname = 'node.arrange_selected_nodes'
    bl_label = _lt('Arrange Selected Nodes', '選択ノードを整列')
    bl_description = _lt(
        'Function: arranges selected nodes while preserving the graph center. How to use: select nodes, configure Layout / Arrange, then run this command; the complete mutation is one Undo step.',
        '機能: グラフの中心を維持しながら選択ノードを整列します。使い方: ノードを選択し、「レイアウト / 整列」を設定して実行します。変更全体は 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    def execute(self, context: Context) -> set[str]:
        ntree = get_ntree()
        selected = [node for node in ntree.nodes if node.select]
        if not selected:
            self.report({'WARNING'}, _lt('No nodes selected', 'ノードが選択されていません'))
            return {'CANCELLED'}
        try:
            _arrange_tree(ntree, selected, context.scene.na_settings)
        except Exception as exc:
            self.report({'ERROR'}, _lt(f'Arrange failed: {exc}', '整列に失敗しました。'))
            return {'CANCELLED'}
        return {'FINISHED'}


def get_all_ntrees() -> list[bpy.types.ID]:
    """Explicit-operation-only scan of Blender IDs that own node trees."""
    bl_data: list[bpy.types.ID] = []
    seen: set[int] = set()
    for key, prop in tuple(bpy.types.BlendData.bl_rna.properties.items()):
        if prop.type != 'COLLECTION' or key == 'scenes':
            continue
        try:
            properties = prop.fixed_type.bl_rna.properties  # type: ignore
        except Exception:
            continue
        if not {'node_tree', 'nodes'}.intersection(properties.keys()):
            continue
        try:
            collection = getattr(bpy.data, key)
        except Exception:
            continue
        for item in collection:
            pointer = int(item.as_pointer()) if hasattr(item, 'as_pointer') else id(item)
            if pointer in seen:
                continue
            seen.add(pointer)
            bl_data.append(item)
    return bl_data


def _tree_from_id(id_data):
    if not getattr(id_data, 'use_nodes', True):
        return None
    return cast(bpy.types.NodeTree, getattr(id_data, 'node_tree', id_data))


def batch_modify(bl_data: Iterable[bpy.types.ID], cls: Type[Operator], *, redraw_ui: bool) -> int:
    """Compatibility entry point with direct mutation and no nested operators.

    ``redraw_ui`` is retained for API compatibility but intentionally ignored;
    batch work does not mutate area type, path, or viewport state.
    """
    _ = redraw_ui
    context = cast(Context, bpy.context)
    settings = getattr(getattr(context, 'scene', None), 'na_settings', None)
    if settings is None:
        return 0
    count = 0
    for id_data in bl_data:
        ntree = _tree_from_id(id_data)
        if ntree is None or getattr(ntree, 'bl_idname', '') == 'NodeTreeUndefined':
            continue
        nodes = tuple(ntree.nodes)
        if not nodes:
            continue
        old_selection = {node for node in nodes if node.select}
        old_active = getattr(ntree.nodes, 'active', None)
        try:
            for node in nodes:
                node.select = True
            if cls is NA_OT_ArrangeSelectedNodes:
                changed = _arrange_tree(ntree, list(nodes), settings)
            elif cls is NA_OT_RecenterSelectedNodes:
                changed, _message = _recenter_tree(ntree, list(nodes), str(settings.origin))
            else:
                changed = False
            if changed:
                count += 1
        except Exception:
            # Continue other trees only after the helper has restored its complete
            # local node/link transaction snapshot.
            continue
        finally:
            for node in nodes:
                try:
                    node.select = node in old_selection
                except Exception:
                    pass
            try:
                ntree.nodes.active = old_active
            except Exception:
                pass
    return count


class NA_OT_ArrangeAllTrees(NodeOperator, Operator):
    bl_idname = 'node.arrange_all_trees'
    bl_label = _lt('Arrange All Trees', '全ツリーを整列')
    bl_description = _lt(
        'Function: explicitly scans and arranges every node tree in the current .blend file. How to use: choose Trees and run this command; the scan occurs only during execution and the whole command is one Undo step.',
        '機能: 現在の .blend ファイル内の全ノードツリーを明示的に走査して整列します。使い方: 「ツリー」を選んで実行します。走査は実行中だけ行われ、コマンド全体が 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    def execute(self, context: Context) -> set[str]:
        count = batch_modify(get_all_ntrees(), NA_OT_ArrangeSelectedNodes, redraw_ui=False)
        self.report({'INFO'}, _lt(f'Arranged {count} node tree(s)', f'{count} 個のノードツリーを整列しました。'))
        return {'FINISHED'}


class NA_OT_RecenterSelectedNodes(NodeOperator, Operator):
    bl_idname = 'node.recenter_selected_nodes'
    bl_label = _lt('Recenter Selected Nodes', '選択ノードを再センター')
    bl_description = _lt(
        'Function: moves selected node roots so the chosen origin is at (0, 0). How to use: select nodes, choose an Origin, and run; child nodes are not moved twice and the action is one Undo step.',
        '機能: 選択したノードルートを移動し、選択した基準を (0, 0) に合わせます。使い方: ノードを選択し、基準を選んで実行します。子ノードは二重移動せず、操作は 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    def execute(self, context: Context) -> set[str]:
        ntree = get_ntree()
        selected = [node for node in ntree.nodes if node.select]
        if not selected:
            self.report({'WARNING'}, _lt('No nodes selected', 'ノードが選択されていません'))
            return {'CANCELLED'}
        try:
            changed, message = _recenter_tree(ntree, selected, str(context.scene.na_settings.origin))
        except Exception as exc:
            self.report({'ERROR'}, _lt(f'Recenter failed: {exc}', '再センターに失敗しました。'))
            return {'CANCELLED'}
        if not changed:
            self.report({'WARNING'}, message or _lt('Nothing to recenter', '再センター対象がありません'))
            return {'CANCELLED'}
        return {'FINISHED'}


class NA_OT_RecenterAllTrees(NodeOperator, Operator):
    bl_idname = 'node.recenter_all_trees'
    bl_label = _lt('Recenter All Trees', '全ツリーを再センター')
    bl_description = _lt(
        'Function: explicitly scans and recenters every node tree in the current .blend file. How to use: choose Trees and run; no scan remains active afterward and the command is one Undo step.',
        '機能: 現在の .blend ファイル内の全ノードツリーを明示的に走査して再センターします。使い方: 「ツリー」を選んで実行します。終了後に走査は残らず、コマンド全体が 1 回の Undo です。',
    )
    bl_options = {'UNDO'}

    def execute(self, context: Context) -> set[str]:
        count = batch_modify(get_all_ntrees(), NA_OT_RecenterSelectedNodes, redraw_ui=False)
        self.report({'INFO'}, _lt(f'Recentered {count} node tree(s)', f'{count} 個のノードツリーを再センターしました。'))
        return {'FINISHED'}


classes = (
    NA_OT_ArrangeSelectedNodes,
    NA_OT_ArrangeAllTrees,
    NA_OT_RecenterSelectedNodes,
    NA_OT_RecenterAllTrees,
)


def register() -> None:
    if _registered_class_tokens:
        return
    _registered_class_tokens.extend(rna_ownership.register_classes(classes))


def unregister() -> None:
    rna_ownership.unregister_classes(_registered_class_tokens)
