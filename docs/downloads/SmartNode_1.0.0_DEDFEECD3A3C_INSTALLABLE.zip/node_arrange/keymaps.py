"""Manual keymap placeholder. Automatic keymap registration is intentionally disabled."""

addon_keymaps = []


def register() -> None:
    return None


def sync_from_settings(context=None) -> None:
    _ = context
    return None


def unregister() -> None:
    return None
