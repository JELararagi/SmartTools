# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-2.0-or-later

"""Generation-exact ownership for Smart Node Blender registrations.

The registry is stored in ``bpy.app.driver_namespace`` and records the exact
Python/RNA objects returned by Blender together with an owner UUID, generation
token, monotonically increasing sequence, and a captured native remover.  It
never scans ``bpy.types`` or ``sys.modules``.  Known resources are resolved only
by their exact owner and identifier.

Existing foreign resources are never unregistered.  RNA properties with an
exactly compatible public shape can be borrowed without taking ownership; an
incompatible collision raises :class:`RestartRequiredError` before mutation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable
import uuid

import bpy

_OWNER_UUID = '8a901fb6-03d3-4d4d-a70d-5bf44311e4bc'
_SCHEMA = 4
_SLOT_KEY = '_SMART_NODE_SUITE_EXACT_RESOURCE_LEDGER_V4'
_HOST_SLOT_KEY = '_smart_node_suite_exact_resource_ledger_v4'
_MAX_RESOURCES = 512

STATUS_REGISTERED = 'REGISTERED'
STATUS_ALREADY_CURRENT = 'ALREADY_CURRENT'
STATUS_REPLACED_OLD_OWNED = 'REPLACED_OLD_OWNED'
STATUS_COMPATIBLE_EXISTING = 'COMPATIBLE_EXISTING'
STATUS_REMOVED = 'REMOVED'
STATUS_NOT_OWNED = 'NOT_OWNED'

_CLASS_OWNER_ATTR = '_smart_node_suite_owner_uuid'
_CLASS_GENERATION_ATTR = '_smart_node_suite_generation_token'
_CLASS_RESOURCE_ATTR = '_smart_node_suite_resource_key'

_fallback_record: dict[str, Any] = {
    'owner_uuid': _OWNER_UUID,
    'schema': _SCHEMA,
    'next_sequence': 1,
    'resources': {},
}


class RestartRequiredError(RuntimeError):
    """A known registration slot is occupied by an incompatible foreign item."""


@dataclass(frozen=True)
class RNAPropertyToken:
    owner: object
    name: str
    rna_pointer: int
    descriptor: object
    resource_key: str = ''
    generation_token: str = ''
    resource_id: str = ''
    python_descriptor: object = None
    status: str = STATUS_REGISTERED
    owned: bool = True


@dataclass(frozen=True)
class RNAClassToken:
    cls: type
    resource_key: str
    generation_token: str
    resource_id: str
    status: str = STATUS_REGISTERED
    owned: bool = True


@dataclass(frozen=True)
class UIHookToken:
    owner: object
    callback: Callable[..., Any]
    resource_key: str
    generation_token: str
    resource_id: str
    status: str = STATUS_REGISTERED
    owned: bool = True


@dataclass(frozen=True)
class KeymapToken:
    keymap: object
    item: object
    resource_key: str
    generation_token: str
    resource_id: str
    status: str = STATUS_REGISTERED
    owned: bool = True


def _namespace():
    try:
        namespace = bpy.app.driver_namespace
        if isinstance(namespace, dict):
            return namespace
    except Exception:
        pass
    return None


def _host_type():
    try:
        return getattr(bpy.types, 'WindowManager', None)
    except Exception:
        return None


def _host_value():
    host = _host_type()
    if host is None:
        return None
    try:
        return vars(host).get(_HOST_SLOT_KEY)
    except Exception:
        try:
            return getattr(host, _HOST_SLOT_KEY, None)
        except Exception:
            return None


def _publish_host_value(value: dict[str, Any]) -> bool:
    host = _host_type()
    if host is None:
        return False
    try:
        setattr(host, _HOST_SLOT_KEY, value)
        return vars(host).get(_HOST_SLOT_KEY) is value
    except Exception:
        return False


def _valid_record(value) -> bool:
    return bool(
        isinstance(value, dict)
        and value.get('owner_uuid') == _OWNER_UUID
        and value.get('schema') == _SCHEMA
        and isinstance(value.get('resources'), dict)
    )


def _new_record() -> dict[str, Any]:
    return {
        'owner_uuid': _OWNER_UUID,
        'schema': _SCHEMA,
        'next_sequence': 1,
        'resources': {},
    }


def _record() -> dict[str, Any]:
    """Return the process-session ledger without depending on file state.

    ``bpy.app.driver_namespace`` is cleared by Blend-file loading.  The same
    plain Python dictionary is therefore also anchored as a private attribute on
    Blender's stable ``WindowManager`` RNA type.  No RNA property is created and
    no type scan is performed.  The driver namespace remains a secondary mirror
    for compatibility and diagnostics.
    """

    global _fallback_record
    namespace = _namespace()
    host_value = _host_value()
    if _valid_record(host_value):
        if namespace is not None and namespace.get(_SLOT_KEY) is not host_value:
            namespace[_SLOT_KEY] = host_value
        return host_value

    namespace_value = namespace.get(_SLOT_KEY) if namespace is not None else None
    if _valid_record(namespace_value):
        _publish_host_value(namespace_value)
        return namespace_value

    value = _new_record()
    published = _publish_host_value(value)
    if namespace is not None:
        namespace[_SLOT_KEY] = value
    if published or namespace is not None:
        return value
    _fallback_record = value
    return _fallback_record


def _resources() -> dict[str, dict[str, Any]]:
    return _record()['resources']


def _next_sequence() -> int:
    record = _record()
    sequence = max(1, int(record.get('next_sequence', 1)))
    record['next_sequence'] = sequence + 1
    return sequence


def _generation_token() -> str:
    try:
        from . import runtime_lifecycle
        token = str(runtime_lifecycle.generation_token() or '')
    except Exception:
        token = ''
    if not token:
        raise RuntimeError('Smart Node registration requires an active generation token')
    return token


def _pointer(value) -> int:
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _rna_property(owner, name: str):
    try:
        properties = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        if properties is None:
            return None
        try:
            return properties.get(name)
        except Exception:
            for prop in properties:
                if str(getattr(prop, 'identifier', '') or '') == name:
                    return prop
    except Exception:
        return None
    return None


def _python_property(owner, name: str):
    try:
        return vars(owner).get(name)
    except Exception:
        return None


def _owner_identifier(owner) -> str:
    rna_id = str(getattr(getattr(owner, 'bl_rna', None), 'identifier', '') or '')
    module = str(getattr(owner, '__module__', '') or '')
    name = str(getattr(owner, '__name__', '') or rna_id or type(owner).__name__)
    return f'{module}:{name}:{rna_id}'


def _property_key(owner, name: str) -> str:
    return f'RNA_PROPERTY:{_owner_identifier(owner)}:{str(name)}'


def _suite_root(module_name: str) -> str:
    parts = str(module_name or '').split('.')
    indexes = [index for index, part in enumerate(parts) if part == 'smart_node_suite']
    if not indexes:
        return ''
    return '.'.join(parts[:indexes[-1] + 1])


def _same_suite_module(left: str, right: str) -> bool:
    left_root = _suite_root(left)
    right_root = _suite_root(right)
    return bool(left_root and right_root and left_root == right_root)


def _deferred_keywords(value) -> dict[str, Any]:
    keywords = getattr(value, 'keywords', None)
    return dict(keywords) if isinstance(keywords, dict) else {}


def _deferred_function_name(value) -> str:
    function = getattr(value, 'function', None)
    return str(getattr(function, '__name__', '') or '')


def _expected_rna_type(function_name: str) -> str:
    return {
        'BoolProperty': 'BOOLEAN',
        'StringProperty': 'STRING',
        'IntProperty': 'INT',
        'IntVectorProperty': 'INT',
        'FloatProperty': 'FLOAT',
        'FloatVectorProperty': 'FLOAT',
        'EnumProperty': 'ENUM',
        'PointerProperty': 'POINTER',
        'CollectionProperty': 'COLLECTION',
    }.get(str(function_name), '')


def _fixed_type_identifier(value) -> str:
    if value is None:
        return ''
    # For an unregistered Python PropertyGroup class, inherited ``bl_rna`` is
    # the base PropertyGroup RNA.  The class name is the identifier Blender will
    # publish after registration, so prefer it for Python types.
    if isinstance(value, type):
        return str(getattr(value, '__name__', '') or '')
    # ``RNAProperty.fixed_type`` is an RNA Struct descriptor.  Its direct
    # ``identifier`` is the fixed class name, while ``fixed_type.bl_rna`` merely
    # identifies the metadata object as ``Struct``.  Prefer the direct value.
    direct_id = str(getattr(value, 'identifier', '') or '')
    if direct_id:
        return direct_id
    rna_id = str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or '')
    return rna_id or str(getattr(value, '__name__', '') or '')


def _deferred_signature(value) -> dict[str, Any]:
    keywords = _deferred_keywords(value)
    function_name = _deferred_function_name(value)
    default = keywords.get('default')
    size = keywords.get('size')
    array_length = 0
    if isinstance(size, int):
        array_length = max(0, int(size))
    elif isinstance(default, (tuple, list)):
        array_length = len(default)
    options = keywords.get('options', ())
    try:
        option_names = tuple(sorted(str(item) for item in options))
    except Exception:
        option_names = ()
    return {
        'factory': function_name,
        'rna_type': _expected_rna_type(function_name),
        'array_length': array_length,
        'fixed_type': _fixed_type_identifier(keywords.get('type')),
        'subtype': str(keywords.get('subtype', '') or ''),
        'skip_save': 'SKIP_SAVE' in option_names,
        'hidden': 'HIDDEN' in option_names,
    }


def _rna_signature(prop) -> dict[str, Any]:
    if prop is None:
        return {}
    fixed_type = getattr(prop, 'fixed_type', None)
    return {
        'rna_type': str(getattr(prop, 'type', '') or ''),
        'array_length': max(0, int(getattr(prop, 'array_length', 0) or 0)),
        'fixed_type': _fixed_type_identifier(fixed_type),
        'subtype': str(getattr(prop, 'subtype', '') or ''),
        'skip_save': bool(getattr(prop, 'is_skip_save', False)),
        'hidden': bool(getattr(prop, 'is_hidden', False)),
    }


def _property_compatible(current, current_python, deferred_property) -> bool:
    expected = _deferred_signature(deferred_property)
    actual = _rna_signature(current)
    if not actual and current_python is not None:
        actual = _deferred_signature(current_python)
    expected_type = str(expected.get('rna_type', '') or '')
    actual_type = str(actual.get('rna_type', '') or '')
    if not expected_type or not actual_type or expected_type != actual_type:
        return False
    expected_length = int(expected.get('array_length', 0) or 0)
    actual_length = int(actual.get('array_length', 0) or 0)
    if expected_length and actual_length and expected_length != actual_length:
        return False
    expected_fixed = str(expected.get('fixed_type', '') or '')
    actual_fixed = str(actual.get('fixed_type', '') or '')
    if expected_fixed and actual_fixed and expected_fixed != actual_fixed:
        return False
    expected_subtype = str(expected.get('subtype', '') or '')
    actual_subtype = str(actual.get('subtype', '') or '')
    if expected_subtype and actual_subtype and expected_subtype != actual_subtype:
        return False
    if bool(expected.get('skip_save')) and not bool(actual.get('skip_save')):
        return False
    return True


def property_exists(owner, name: str) -> bool:
    if _rna_property(owner, name) is not None:
        return True
    return _python_property(owner, name) is not None


def _property_entry_exact(entry: dict[str, Any]) -> bool:
    owner = entry.get('owner_ref')
    name = str(entry.get('name', '') or '')
    if owner is None or not name:
        return False
    current = _rna_property(owner, name)
    current_python = _python_property(owner, name)
    if current is None and current_python is None:
        return False
    expected_pointer = int(entry.get('rna_pointer', 0) or 0)
    current_pointer = _pointer(current)
    if expected_pointer and current_pointer:
        return expected_pointer == current_pointer
    descriptor = entry.get('descriptor_ref')
    if descriptor is not None and current is descriptor:
        return True
    python_descriptor = entry.get('python_descriptor_ref')
    if python_descriptor is not None and current_python is python_descriptor:
        return True
    return False


def _drop_entry_if_same(resource_key: str, resource_id: str) -> None:
    current = _resources().get(resource_key)
    if isinstance(current, dict) and str(current.get('resource_id', '')) == str(resource_id):
        _resources().pop(resource_key, None)


def _make_property_remover(entry: dict[str, Any]) -> Callable[[], bool]:
    owner = entry['owner_ref']
    name = entry['name']
    resource_key = entry['resource_key']
    resource_id = entry['resource_id']

    def _remove() -> bool:
        current_entry = _resources().get(resource_key)
        if not isinstance(current_entry, dict):
            return not property_exists(owner, name)
        if str(current_entry.get('resource_id', '')) != resource_id:
            return False
        if not bool(current_entry.get('owned', False)):
            _drop_entry_if_same(resource_key, resource_id)
            return True
        if not _property_entry_exact(current_entry):
            if not property_exists(owner, name):
                _drop_entry_if_same(resource_key, resource_id)
                return True
            return False
        try:
            delattr(owner, name)
        except Exception:
            return False
        if property_exists(owner, name):
            return False
        _drop_entry_if_same(resource_key, resource_id)
        return True

    return _remove


def _property_token(entry: dict[str, Any], *, status: str | None = None) -> RNAPropertyToken:
    return RNAPropertyToken(
        owner=entry.get('owner_ref'),
        name=str(entry.get('name', '') or ''),
        rna_pointer=int(entry.get('rna_pointer', 0) or 0),
        descriptor=entry.get('descriptor_ref'),
        resource_key=str(entry.get('resource_key', '') or ''),
        generation_token=str(entry.get('generation_token', '') or ''),
        resource_id=str(entry.get('resource_id', '') or ''),
        python_descriptor=entry.get('python_descriptor_ref'),
        status=str(status or entry.get('status', STATUS_REGISTERED)),
        owned=bool(entry.get('owned', False)),
    )


def install_property(owner, name: str, deferred_property) -> RNAPropertyToken:
    """Install or reuse one exact RNA property without touching foreign owners.

    Returns an ownership token whose ``status`` is one of ``REGISTERED``,
    ``ALREADY_CURRENT``, ``REPLACED_OLD_OWNED`` or ``COMPATIBLE_EXISTING``.
    Compatible existing properties are borrowed and never removed by this Suite.
    """

    property_name = str(name or '')
    if not property_name:
        raise ValueError('RNA property name is empty')
    generation = _generation_token()
    resource_key = _property_key(owner, property_name)
    resources = _resources()
    prior = resources.get(resource_key)
    replaced_old = False

    if isinstance(prior, dict) and prior.get('owner_uuid') == _OWNER_UUID:
        if _property_entry_exact(prior):
            if str(prior.get('generation_token', '')) == generation:
                if not _property_compatible(
                    _rna_property(owner, property_name),
                    _python_property(owner, property_name),
                    deferred_property,
                ):
                    raise RestartRequiredError(
                        f'Current-generation RNA property shape changed: {property_name}'
                    )
                prior['status'] = STATUS_ALREADY_CURRENT
                return _property_token(prior, status=STATUS_ALREADY_CURRENT)
            remover = prior.get('remover')
            if callable(remover) and bool(remover()):
                replaced_old = True
            else:
                current = _rna_property(owner, property_name)
                current_python = _python_property(owner, property_name)
                if _property_compatible(current, current_python, deferred_property):
                    prior['owned'] = False
                    prior['generation_token'] = generation
                    prior['status'] = STATUS_COMPATIBLE_EXISTING
                    prior['remover'] = _make_property_remover(prior)
                    return _property_token(prior, status=STATUS_COMPATIBLE_EXISTING)
                raise RestartRequiredError(
                    f'Old Smart Node RNA property could not be released exactly: {property_name}'
                )
        elif not property_exists(owner, property_name):
            resources.pop(resource_key, None)
        else:
            current = _rna_property(owner, property_name)
            current_python = _python_property(owner, property_name)
            if _property_compatible(current, current_python, deferred_property):
                prior['owned'] = False
                prior['generation_token'] = generation
                prior['status'] = STATUS_COMPATIBLE_EXISTING
                prior['descriptor_ref'] = current
                prior['python_descriptor_ref'] = current_python
                prior['rna_pointer'] = _pointer(current)
                prior['remover'] = _make_property_remover(prior)
                return _property_token(prior, status=STATUS_COMPATIBLE_EXISTING)
            raise RestartRequiredError(
                f'RNA property ownership identity is ambiguous: {property_name}'
            )

    current = _rna_property(owner, property_name)
    current_python = _python_property(owner, property_name)
    if current is not None or current_python is not None:
        if not _property_compatible(current, current_python, deferred_property):
            raise RestartRequiredError(
                f'RNA property is occupied by an incompatible foreign definition: {property_name}'
            )
        resource_id = uuid.uuid4().hex
        entry = {
            'owner_uuid': _OWNER_UUID,
            'resource_type': 'RNA_PROPERTY',
            'resource_key': resource_key,
            'resource_id': resource_id,
            'generation_token': generation,
            'sequence': _next_sequence(),
            'owned': False,
            'status': STATUS_COMPATIBLE_EXISTING,
            'owner_ref': owner,
            'name': property_name,
            'descriptor_ref': current,
            'python_descriptor_ref': current_python,
            'rna_pointer': _pointer(current),
            'signature': _deferred_signature(deferred_property),
        }
        entry['remover'] = _make_property_remover(entry)
        resources[resource_key] = entry
        return _property_token(entry)

    setattr(owner, property_name, deferred_property)
    descriptor = _rna_property(owner, property_name)
    python_descriptor = _python_property(owner, property_name)
    if descriptor is None and python_descriptor is None:
        try:
            delattr(owner, property_name)
        except Exception:
            pass
        raise RuntimeError(f'RNA property registration did not publish a descriptor: {property_name}')
    if not _property_compatible(descriptor, python_descriptor, deferred_property):
        try:
            delattr(owner, property_name)
        except Exception:
            pass
        raise RuntimeError(f'RNA property registration produced an incompatible descriptor: {property_name}')

    resource_id = uuid.uuid4().hex
    entry = {
        'owner_uuid': _OWNER_UUID,
        'resource_type': 'RNA_PROPERTY',
        'resource_key': resource_key,
        'resource_id': resource_id,
        'generation_token': generation,
        'sequence': _next_sequence(),
        'owned': True,
        'status': STATUS_REPLACED_OLD_OWNED if replaced_old else STATUS_REGISTERED,
        'owner_ref': owner,
        'name': property_name,
        'descriptor_ref': descriptor,
        'python_descriptor_ref': python_descriptor,
        'rna_pointer': _pointer(descriptor),
        'signature': _deferred_signature(deferred_property),
    }
    entry['remover'] = _make_property_remover(entry)
    resources[resource_key] = entry
    _trim_registry()
    return _property_token(entry)


def token_matches(token: RNAPropertyToken) -> bool:
    resource_key = str(getattr(token, 'resource_key', '') or _property_key(token.owner, token.name))
    resource_id = str(getattr(token, 'resource_id', '') or '')
    entry = _resources().get(resource_key)
    if isinstance(entry, dict) and resource_id and str(entry.get('resource_id', '')) == resource_id:
        if bool(entry.get('owned', False)):
            return _property_entry_exact(entry)
        current = _rna_property(entry.get('owner_ref'), str(entry.get('name', '') or ''))
        current_python = _python_property(entry.get('owner_ref'), str(entry.get('name', '') or ''))
        expected_pointer = int(entry.get('rna_pointer', 0) or 0)
        current_pointer = _pointer(current)
        if expected_pointer and current_pointer:
            return expected_pointer == current_pointer
        return current is entry.get('descriptor_ref') or current_python is entry.get('python_descriptor_ref')
    current = _rna_property(token.owner, token.name)
    current_python = _python_property(token.owner, token.name)
    pointer = int(getattr(token, 'rna_pointer', 0) or 0)
    if pointer and _pointer(current):
        return pointer == _pointer(current)
    return current is getattr(token, 'descriptor', None) or current_python is getattr(token, 'python_descriptor', None)


def remove_property(token: RNAPropertyToken) -> bool:
    resource_key = str(getattr(token, 'resource_key', '') or _property_key(token.owner, token.name))
    resource_id = str(getattr(token, 'resource_id', '') or '')
    entry = _resources().get(resource_key)
    if not isinstance(entry, dict) or (resource_id and str(entry.get('resource_id', '')) != resource_id):
        return False
    remover = entry.get('remover')
    return bool(callable(remover) and remover())


def release_legacy_pointer_property(owner, name: str, expected_type: type) -> bool:
    """Release a pre-ledger Suite pointer property by exact fixed-type provenance.

    This narrow migration path exists for 1.4.14 and earlier.  It never removes a
    primitive property and never relies on the property name alone: the current
    RNA descriptor must be a POINTER whose fixed Python class has the expected
    identifier and belongs to the exact same Smart Node package root.
    """

    property_name = str(name or '')
    resource_key = _property_key(owner, property_name)
    entry = _resources().get(resource_key)
    if isinstance(entry, dict) and entry.get('owner_uuid') == _OWNER_UUID:
        remover = entry.get('remover')
        if callable(remover) and bool(remover()):
            return True
    current = _rna_property(owner, property_name)
    if current is None or str(getattr(current, 'type', '') or '') != 'POINTER':
        return False
    fixed = getattr(current, 'fixed_type', None)
    fixed_identifier = _fixed_type_identifier(fixed)
    expected_identifier = _fixed_type_identifier(expected_type)
    if not fixed_identifier or fixed_identifier != expected_identifier:
        return False
    current_type = _rna_class_by_identifier(fixed_identifier)
    if current_type is None:
        return False
    if not _same_suite_module(
        str(getattr(current_type, '__module__', '') or ''),
        str(getattr(expected_type, '__module__', '') or ''),
    ):
        return False
    try:
        delattr(owner, property_name)
    except Exception:
        return False
    return not property_exists(owner, property_name)


def _class_kind(cls: type) -> str:
    mro_names = {str(getattr(base, '__name__', '') or '') for base in getattr(cls, '__mro__', ())}
    for name in ('Operator', 'Panel', 'Menu', 'UIList', 'PropertyGroup', 'AddonPreferences', 'Node'):
        if name in mro_names:
            return name
    return 'RNAClass'


def _class_key(cls: type) -> str:
    identifier = str(getattr(cls, 'bl_idname', '') or getattr(cls, '__name__', '') or '')
    return f'RNA_CLASS:{_class_kind(cls)}:{identifier}:{str(getattr(cls, "__name__", "") or "")}'


def _rna_class_by_identifier(identifier: str):
    name = str(identifier or '')
    if not name:
        return None
    try:
        candidate = getattr(bpy.types, name, None)
    except Exception:
        candidate = None
    if isinstance(candidate, type):
        return candidate
    # Blender Extensions do not always publish every registered Python class as
    # ``bpy.types.<PythonName>``.  Resolve only this exact RNA identifier through
    # the public Struct lookup; this is not a bpy.types scan.
    try:
        struct_type = getattr(bpy.types, 'Struct', None)
        resolver = getattr(struct_type, 'bl_rna_get_subclass_py', None)
        if callable(resolver):
            try:
                candidate = resolver(name, None)
            except TypeError:
                candidate = resolver(name)
            if isinstance(candidate, type):
                return candidate
    except Exception:
        pass
    return None


def _registered_class_by_name(cls: type):
    return _rna_class_by_identifier(str(getattr(cls, '__name__', '') or ''))


def _class_registered_exact(cls: type) -> bool:
    try:
        if bool(getattr(cls, 'is_registered', False)):
            return True
    except Exception:
        pass
    # Blender injects a class-owned bl_rna entry into vars(cls) at successful
    # registration.  Checking vars avoids mistaking an inherited base bl_rna for
    # a registered Extension class and works when bpy.types mapping is absent.
    try:
        owned_rna = vars(cls).get('bl_rna')
    except Exception:
        owned_rna = None
    if owned_rna is not None:
        identifier = str(getattr(owned_rna, 'identifier', '') or '')
        if identifier == str(getattr(cls, '__name__', '') or ''):
            return True
    return _registered_class_by_name(cls) is cls


def _legacy_class_owned(existing: type, requested: type) -> bool:
    if existing is requested:
        return True
    if str(getattr(existing, _CLASS_OWNER_ATTR, '') or '') == _OWNER_UUID:
        return True
    if not _same_suite_module(
        str(getattr(existing, '__module__', '') or ''),
        str(getattr(requested, '__module__', '') or ''),
    ):
        return False
    if str(getattr(existing, '__name__', '') or '') != str(getattr(requested, '__name__', '') or ''):
        return False
    existing_id = str(getattr(existing, 'bl_idname', '') or '')
    requested_id = str(getattr(requested, 'bl_idname', '') or '')
    return existing_id == requested_id and _class_kind(existing) == _class_kind(requested)


def _class_entry_exact(entry: dict[str, Any]) -> bool:
    cls = entry.get('class_ref')
    return isinstance(cls, type) and _class_registered_exact(cls)


def _make_class_remover(entry: dict[str, Any]) -> Callable[[], bool]:
    cls = entry['class_ref']
    resource_key = entry['resource_key']
    resource_id = entry['resource_id']

    def _remove() -> bool:
        current_entry = _resources().get(resource_key)
        if not isinstance(current_entry, dict):
            return not _class_registered_exact(cls)
        if str(current_entry.get('resource_id', '')) != resource_id:
            return False
        if not bool(current_entry.get('owned', False)):
            _drop_entry_if_same(resource_key, resource_id)
            return True
        if not _class_entry_exact(current_entry):
            if not _class_registered_exact(cls):
                _drop_entry_if_same(resource_key, resource_id)
                return True
            return False
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            if _class_registered_exact(cls):
                return False
        if _class_registered_exact(cls):
            return False
        _drop_entry_if_same(resource_key, resource_id)
        return True

    return _remove


def _class_token(entry: dict[str, Any], *, status: str | None = None) -> RNAClassToken:
    return RNAClassToken(
        cls=entry.get('class_ref'),
        resource_key=str(entry.get('resource_key', '') or ''),
        generation_token=str(entry.get('generation_token', '') or ''),
        resource_id=str(entry.get('resource_id', '') or ''),
        status=str(status or entry.get('status', STATUS_REGISTERED)),
        owned=bool(entry.get('owned', False)),
    )


def register_class(cls: type) -> RNAClassToken:
    if not isinstance(cls, type):
        raise TypeError('register_class expects a class')
    generation = _generation_token()
    resource_key = _class_key(cls)
    resources = _resources()
    prior = resources.get(resource_key)
    replaced_old = False

    if isinstance(prior, dict) and prior.get('owner_uuid') == _OWNER_UUID:
        if _class_entry_exact(prior):
            prior_cls = prior.get('class_ref')
            if str(prior.get('generation_token', '')) == generation and prior_cls is cls:
                prior['status'] = STATUS_ALREADY_CURRENT
                return _class_token(prior, status=STATUS_ALREADY_CURRENT)
            remover = prior.get('remover')
            if callable(remover) and bool(remover()):
                replaced_old = True
            else:
                raise RestartRequiredError(
                    f'Old Smart Node class could not be released exactly: {getattr(cls, "__name__", "")}'
                )
        elif not _class_registered_exact(prior.get('class_ref')):
            resources.pop(resource_key, None)
        else:
            raise RestartRequiredError(
                f'Class ownership identity is ambiguous: {getattr(cls, "__name__", "")}'
            )

    existing = _registered_class_by_name(cls)
    if existing is not None and existing is not cls:
        if not _legacy_class_owned(existing, cls):
            raise RestartRequiredError(
                f'Class slot is occupied by a foreign class: {getattr(cls, "__name__", "")}'
            )
        try:
            bpy.utils.unregister_class(existing)
        except Exception as exc:
            if _class_registered_exact(existing):
                raise RestartRequiredError(
                    f'Legacy Smart Node class requires restart: {getattr(cls, "__name__", "")}'
                ) from exc
        if _class_registered_exact(existing):
            raise RestartRequiredError(
                f'Legacy Smart Node class remains registered: {getattr(cls, "__name__", "")}'
            )
        replaced_old = True
    elif existing is cls or _class_registered_exact(cls):
        owner_marker = str(getattr(cls, _CLASS_OWNER_ATTR, '') or '')
        generation_marker = str(getattr(cls, _CLASS_GENERATION_ATTR, '') or '')
        if owner_marker and owner_marker != _OWNER_UUID:
            raise RestartRequiredError(
                f'Class is registered by a foreign owner: {getattr(cls, "__name__", "")}'
            )
        if owner_marker == _OWNER_UUID and generation_marker == generation:
            resource_id = uuid.uuid4().hex
            entry = {
                'owner_uuid': _OWNER_UUID,
                'resource_type': 'RNA_CLASS',
                'resource_key': resource_key,
                'resource_id': resource_id,
                'generation_token': generation,
                'sequence': _next_sequence(),
                'owned': True,
                'status': STATUS_ALREADY_CURRENT,
                'class_ref': cls,
            }
            entry['remover'] = _make_class_remover(entry)
            resources[resource_key] = entry
            return _class_token(entry)
        if not _legacy_class_owned(cls, cls):
            raise RestartRequiredError(
                f'Registered class ownership is unknown: {getattr(cls, "__name__", "")}'
            )
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            if _class_registered_exact(cls):
                raise RestartRequiredError(
                    f'Registered Smart Node class requires restart: {getattr(cls, "__name__", "")}'
                ) from exc
        replaced_old = True

    try:
        setattr(cls, _CLASS_OWNER_ATTR, _OWNER_UUID)
        setattr(cls, _CLASS_GENERATION_ATTR, generation)
        setattr(cls, _CLASS_RESOURCE_ATTR, resource_key)
    except Exception:
        pass
    bpy.utils.register_class(cls)
    if not _class_registered_exact(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'Class registration did not become active: {getattr(cls, "__name__", "")}')

    resource_id = uuid.uuid4().hex
    entry = {
        'owner_uuid': _OWNER_UUID,
        'resource_type': 'RNA_CLASS',
        'resource_key': resource_key,
        'resource_id': resource_id,
        'generation_token': generation,
        'sequence': _next_sequence(),
        'owned': True,
        'status': STATUS_REPLACED_OLD_OWNED if replaced_old else STATUS_REGISTERED,
        'class_ref': cls,
    }
    entry['remover'] = _make_class_remover(entry)
    resources[resource_key] = entry
    _trim_registry()
    return _class_token(entry)


def remove_class(token: RNAClassToken) -> bool:
    resource_key = str(getattr(token, 'resource_key', '') or '')
    resource_id = str(getattr(token, 'resource_id', '') or '')
    entry = _resources().get(resource_key)
    if not isinstance(entry, dict) or (resource_id and str(entry.get('resource_id', '')) != resource_id):
        return False
    remover = entry.get('remover')
    return bool(callable(remover) and remover())


def register_classes(classes) -> list[RNAClassToken]:
    acquired: list[RNAClassToken] = []
    try:
        for cls in tuple(classes):
            acquired.append(register_class(cls))
    except Exception:
        while acquired:
            remove_class(acquired.pop())
        raise
    return acquired


def unregister_classes(tokens) -> None:
    while tokens:
        token = tokens.pop()
        try:
            remove_class(token)
        except Exception:
            pass


def _ui_hook_key(owner, callback, prepend: bool) -> str:
    owner_id = _owner_identifier(owner)
    callback_id = f'{getattr(callback, "__module__", "")}:{getattr(callback, "__qualname__", getattr(callback, "__name__", ""))}'
    return f'UI_HOOK:{owner_id}:{"PREPEND" if prepend else "APPEND"}:{callback_id}'


def _make_ui_hook_remover(entry: dict[str, Any]) -> Callable[[], bool]:
    owner = entry['owner_ref']
    callback = entry['callback_ref']
    resource_key = entry['resource_key']
    resource_id = entry['resource_id']

    def _remove() -> bool:
        current = _resources().get(resource_key)
        if not isinstance(current, dict) or str(current.get('resource_id', '')) != resource_id:
            return False
        if bool(current.get('owned', False)):
            try:
                owner.remove(callback)
            except Exception:
                # Blender's remove raises when the exact callback is already gone.
                pass
        _drop_entry_if_same(resource_key, resource_id)
        return True

    return _remove


def install_ui_hook(owner, callback, *, prepend: bool = False) -> UIHookToken:
    generation = _generation_token()
    resource_key = _ui_hook_key(owner, callback, prepend)
    prior = _resources().get(resource_key)
    if isinstance(prior, dict) and prior.get('owner_uuid') == _OWNER_UUID:
        if str(prior.get('generation_token', '')) == generation and prior.get('callback_ref') is callback:
            return UIHookToken(owner, callback, resource_key, generation, str(prior.get('resource_id', '')), STATUS_ALREADY_CURRENT, True)
        remover = prior.get('remover')
        if callable(remover):
            remover()
    method = getattr(owner, 'prepend' if prepend else 'append')
    method(callback)
    resource_id = uuid.uuid4().hex
    entry = {
        'owner_uuid': _OWNER_UUID,
        'resource_type': 'UI_HOOK',
        'resource_key': resource_key,
        'resource_id': resource_id,
        'generation_token': generation,
        'sequence': _next_sequence(),
        'owned': True,
        'status': STATUS_REGISTERED,
        'owner_ref': owner,
        'callback_ref': callback,
        'prepend': bool(prepend),
    }
    entry['remover'] = _make_ui_hook_remover(entry)
    _resources()[resource_key] = entry
    _trim_registry()
    return UIHookToken(owner, callback, resource_key, generation, resource_id)


def remove_ui_hook(token: UIHookToken) -> bool:
    entry = _resources().get(str(getattr(token, 'resource_key', '') or ''))
    if not isinstance(entry, dict) or str(entry.get('resource_id', '')) != str(getattr(token, 'resource_id', '') or ''):
        return False
    remover = entry.get('remover')
    return bool(callable(remover) and remover())


def _keymap_key(keymap, idname: str, event_type: str, value: str, kwargs: dict[str, Any]) -> str:
    km_id = ':'.join((
        str(getattr(keymap, 'name', '') or ''),
        str(getattr(keymap, 'space_type', '') or ''),
        str(getattr(keymap, 'region_type', '') or ''),
    ))
    flags = ','.join(f'{key}={kwargs[key]!r}' for key in sorted(kwargs))
    return f'KEYMAP:{km_id}:{idname}:{event_type}:{value}:{flags}'


def _iter_keymap_items(keymap) -> tuple[object, ...]:
    try:
        return tuple(getattr(keymap, 'keymap_items', ()))
    except Exception:
        return ()


def _keymap_item_present(keymap, item) -> bool:
    return any(candidate is item for candidate in _iter_keymap_items(keymap))


def _keymap_item_compatible(item, idname: str, event_type: str, value: str, kwargs: dict[str, Any]) -> bool:
    if item is None:
        return False
    try:
        if str(getattr(item, 'idname', '') or '') != str(idname):
            return False
        if str(getattr(item, 'type', '') or '') != str(event_type):
            return False
        if str(getattr(item, 'value', '') or '') != str(value):
            return False
    except Exception:
        return False

    # Blender's KeyMapItems.new() defaults are part of the public event identity.
    # Compare only public fields and never mutate an existing user/foreign item.
    expected = {
        'any': False,
        'shift': False,
        'ctrl': False,
        'alt': False,
        'oskey': False,
        'key_modifier': 'NONE',
        'direction': 'ANY',
        'repeat': False,
        'head': False,
    }
    expected.update(kwargs)
    for name, wanted in expected.items():
        try:
            current = getattr(item, name)
        except Exception:
            # Older Blender builds may not expose newer optional event fields.
            if name in kwargs:
                return False
            continue
        if isinstance(wanted, bool):
            if bool(current) != bool(wanted):
                return False
        elif str(current) != str(wanted):
            return False
    return True


def _keymap_entry_exact(entry: dict[str, Any]) -> bool:
    keymap = entry.get('keymap_ref')
    item = entry.get('item_ref')
    return keymap is not None and item is not None and _keymap_item_present(keymap, item)


def _make_keymap_remover(entry: dict[str, Any]) -> Callable[[], bool]:
    keymap = entry['keymap_ref']
    item = entry['item_ref']
    resource_key = entry['resource_key']
    resource_id = entry['resource_id']

    def _remove() -> bool:
        current = _resources().get(resource_key)
        if not isinstance(current, dict) or str(current.get('resource_id', '')) != resource_id:
            return False
        if not bool(current.get('owned', False)):
            _drop_entry_if_same(resource_key, resource_id)
            return True
        if not _keymap_entry_exact(current):
            _drop_entry_if_same(resource_key, resource_id)
            return True
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            if _keymap_item_present(keymap, item):
                return False
        if _keymap_item_present(keymap, item):
            return False
        _drop_entry_if_same(resource_key, resource_id)
        return True

    return _remove


def _keymap_token(entry: dict[str, Any], *, status: str | None = None) -> KeymapToken:
    return KeymapToken(
        keymap=entry.get('keymap_ref'),
        item=entry.get('item_ref'),
        resource_key=str(entry.get('resource_key', '') or ''),
        generation_token=str(entry.get('generation_token', '') or ''),
        resource_id=str(entry.get('resource_id', '') or ''),
        status=str(status or entry.get('status', STATUS_REGISTERED)),
        owned=bool(entry.get('owned', False)),
    )


def install_keymap_item(keymap, idname: str, event_type: str, value: str, **kwargs) -> KeymapToken:
    generation = _generation_token()
    resource_key = _keymap_key(keymap, idname, event_type, value, kwargs)
    resources = _resources()
    prior = resources.get(resource_key)
    replaced_old = False

    if isinstance(prior, dict) and prior.get('owner_uuid') == _OWNER_UUID:
        if _keymap_entry_exact(prior):
            if str(prior.get('generation_token', '')) == generation:
                if not _keymap_item_compatible(prior.get('item_ref'), idname, event_type, value, kwargs):
                    raise RestartRequiredError(f'Current-generation keymap item shape changed: {idname}')
                prior['status'] = STATUS_ALREADY_CURRENT
                return _keymap_token(prior, status=STATUS_ALREADY_CURRENT)
            remover = prior.get('remover')
            if callable(remover) and bool(remover()):
                replaced_old = True
            else:
                raise RestartRequiredError(f'Old Smart Node keymap item could not be released exactly: {idname}')
        else:
            resources.pop(resource_key, None)

    # When a matching item already exists without an exact Smart Node ledger,
    # borrow it read-only.  This preserves user/foreign keymaps and avoids adding a
    # duplicate after a lost pre-1.4.16 generation record.
    for existing in _iter_keymap_items(keymap):
        if not _keymap_item_compatible(existing, idname, event_type, value, kwargs):
            continue
        resource_id = uuid.uuid4().hex
        entry = {
            'owner_uuid': _OWNER_UUID,
            'resource_type': 'KEYMAP',
            'resource_key': resource_key,
            'resource_id': resource_id,
            'generation_token': generation,
            'sequence': _next_sequence(),
            'owned': False,
            'status': STATUS_COMPATIBLE_EXISTING,
            'keymap_ref': keymap,
            'item_ref': existing,
        }
        entry['remover'] = _make_keymap_remover(entry)
        resources[resource_key] = entry
        _trim_registry()
        return _keymap_token(entry)

    item = keymap.keymap_items.new(idname, event_type, value, **kwargs)
    if not _keymap_item_present(keymap, item):
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            pass
        raise RuntimeError(f'Keymap registration did not publish an exact item: {idname}')
    resource_id = uuid.uuid4().hex
    entry = {
        'owner_uuid': _OWNER_UUID,
        'resource_type': 'KEYMAP',
        'resource_key': resource_key,
        'resource_id': resource_id,
        'generation_token': generation,
        'sequence': _next_sequence(),
        'owned': True,
        'status': STATUS_REPLACED_OLD_OWNED if replaced_old else STATUS_REGISTERED,
        'keymap_ref': keymap,
        'item_ref': item,
    }
    entry['remover'] = _make_keymap_remover(entry)
    resources[resource_key] = entry
    _trim_registry()
    return _keymap_token(entry)

def remove_keymap_item(token: KeymapToken) -> bool:
    entry = _resources().get(str(getattr(token, 'resource_key', '') or ''))
    if not isinstance(entry, dict) or str(entry.get('resource_id', '')) != str(getattr(token, 'resource_id', '') or ''):
        return False
    remover = entry.get('remover')
    return bool(callable(remover) and remover())


def retire_generation_resources(generation_token: str) -> int:
    """Run captured removers for one exact generation in reverse acquisition order."""

    token = str(generation_token or '')
    if not token:
        return 0
    entries = [
        entry for entry in tuple(_resources().values())
        if isinstance(entry, dict)
        and entry.get('owner_uuid') == _OWNER_UUID
        and str(entry.get('generation_token', '')) == token
    ]
    entries.sort(key=lambda item: int(item.get('sequence', 0)), reverse=True)
    removed = 0
    for entry in entries:
        remover = entry.get('remover')
        if callable(remover):
            try:
                removed += int(bool(remover()))
            except Exception:
                pass
    return removed


def _trim_registry() -> None:
    resources = _resources()
    if len(resources) <= _MAX_RESOURCES:
        return
    entries = sorted(
        (entry for entry in resources.values() if isinstance(entry, dict)),
        key=lambda item: int(item.get('sequence', 0)),
    )
    for entry in entries:
        if len(resources) <= _MAX_RESOURCES:
            break
        if bool(entry.get('owned', False)):
            continue
        resources.pop(str(entry.get('resource_key', '') or ''), None)


def ownership_snapshot() -> dict[str, object]:
    counts: dict[str, int] = {}
    owned_counts: dict[str, int] = {}
    borrowed_counts: dict[str, int] = {}
    generations: set[str] = set()
    for entry in tuple(_resources().values()):
        if not isinstance(entry, dict) or entry.get('owner_uuid') != _OWNER_UUID:
            continue
        resource_type = str(entry.get('resource_type', 'UNKNOWN') or 'UNKNOWN')
        counts[resource_type] = counts.get(resource_type, 0) + 1
        if bool(entry.get('owned', False)):
            owned_counts[resource_type] = owned_counts.get(resource_type, 0) + 1
        else:
            borrowed_counts[resource_type] = borrowed_counts.get(resource_type, 0) + 1
        generation = str(entry.get('generation_token', '') or '')
        if generation:
            generations.add(generation)
    return {
        'owner_uuid': _OWNER_UUID,
        'schema': _SCHEMA,
        'resource_limit': _MAX_RESOURCES,
        'resource_count': sum(counts.values()),
        'counts': dict(sorted(counts.items())),
        'owned_counts': dict(sorted(owned_counts.items())),
        'borrowed_counts': dict(sorted(borrowed_counts.items())),
        'generation_count': len(generations),
    }
