# SPDX-FileCopyrightText: 2013-2026 Blender Foundation
# SPDX-FileCopyrightText: 2026 JELararagi
#
# SPDX-License-Identifier: GPL-2.0-or-later

from __future__ import annotations

import re

try:
    import bpy
except Exception:  # pragma: no cover
    bpy = None

try:
    from .i18n import t as _sns_t
except Exception:  # pragma: no cover
    def _sns_t(en, ja=None):
        return ja if ja is not None else en

_JA_RE = re.compile(r'[\u3040-\u30ff\u3400-\u9fff]')

_STATIC_EN_JA = {
    'Node Arrange': 'ノード整列',
    'Smart Node > Layout / Arrange': 'Smart Node > レイアウト / 整列',
    'Node arranging and recentering tools integrated into Smart Node Suite': 'Smart Node Suite に統合されたノード整列と再センターツール',
    'Node Recenter': 'ノード再センター',
    'Spacing': '間隔',
    'Alignment': '配置',
    'Crossed Links': '交差リンク',
    'Reroutes': 'リルート',
    'Collapsed Nodes': '折りたたみノード',
    'Arrange Selected Nodes': '選択ノードを整列',
    'Arrange All Trees': '全ツリーを整列',
    'Recenter Selected Nodes': '選択ノードを再センター',
    'Recenter All Trees': '全ツリーを再センター',
    'Node Presets': 'ノードプリセット',
    'Node Templates': 'ノードテンプレート',
    'Template Folder': 'テンプレートフォルダー',
    'Templates': 'テンプレート一覧',
    'Choose Preset Folder': 'プリセットフォルダーを選択',
    'Clear Preset Folder': 'プリセットフォルダーを解除',
    'Noise Nodes': 'ノイズノード',
    'Noise Node Menu': 'ノイズノードメニュー',
    'Manual Runtime Sync': '手動ランタイム同期',
    'Shader Noise Nodes': 'シェーダーノイズノード',
    'Geometry Noise Nodes': 'ジオメトリノイズノード',
    'Sync Runtime': 'ランタイム同期',
    'Node Color Tools': 'ノード色ツール',
    'Node Color Tools Pie': 'ノード色ツールパイ',
    'Node Color Adjustment': 'ノードカラー調整',
    'Smart Node > Node Management': 'Smart Node > ノード管理',
    'Quick, organized node colors with pie menu controls integrated into Smart Node Suite': 'Smart Node Suite に統合された、素早く整理しやすいパイメニュー式ノードカラー ツール',
    'Set Slot Color': 'スロット色を設定',
    'Remove Color': '色を削除',
    'Copy Active Node Color': 'アクティブノード色をコピー',
    'Set Random Color': 'ランダムカラーを設定',
    'Precise Node Color Pie': '精密ノードカラーパイ',
    'Quick Node Color Pie': 'クイックノードカラーパイ',
    'Precise Pie': '詳細パイ',
    'Quick Pie': 'クイックパイ',
    'Set Manual Hotkey': '手動ホットキー設定',
    'Open Quick Color Pie': 'クイックカラーパイを開く',
    'Randomize Color': '色をランダム化',
    'Set Color Preset 1': '色プリセット1を設定',
    'Set Color Preset 2': '色プリセット2を設定',
    'Set Color Preset 3': '色プリセット3を設定',
    'Set Color Preset 4': '色プリセット4を設定',
    'Set Color Preset 5': '色プリセット5を設定',
    'Nodes': 'ノード',
    'Sockets': 'ソケット',
    'Add': '追加',
    'Geometry Crackle Noise Node': 'クラックルノイズ',
    'Geometry Cranal Noise Node': 'クラナルノイズ',
    'Geometry Dent Noise Node': 'デントノイズ',
    'Geometry Dot Noise Node': 'ドットノイズ',
    'Geometry Fluid Noise Node': '流体ノイズ',
    'Geometry Fractal Noise Node': 'フラクタルノイズ',
    'Geometry Perlin Noise Node': 'パーリンノイズ',
    'Geometry Pixelator Node': 'ピクセレーター',
    'Geometry Regular Noise Node': 'レギュラーノイズ',
    'Geometry Scratches Noise Node': 'スクラッチノイズ',
    'Geometry Step Noise Node': 'ステップノイズ',
    'Geometry Streaks Noise Node': 'ストリークノイズ',
    'Shader Crackle Noise Node': 'クラックルノイズ',
    'Shader Cranal Noise Node': 'クラナルノイズ',
    'Shader Dent Noise Node': 'デントノイズ',
    'Shader Dot Noise Node': 'ドットノイズ',
    'Shader Fluid Noise Node': '流体ノイズ',
    'Shader Fractal Noise Node': 'フラクタルノイズ',
    'Shader Perlin Noise Node': 'パーリンノイズ',
    'Shader Pixelator Node': 'ピクセレーター',
    'Shader Regular Noise Node': 'レギュラーノイズ',
    'Shader Scratches Noise Node': 'スクラッチノイズ',
    'Shader Step Noise Node': 'ステップノイズ',
    'Shader Streaks Noise Node': 'ストリークノイズ',
    'Shader Voxel Noise Node': 'ボクセルノイズ',
    'Shader Wavy Noise Node': '波状ノイズ',
}
_STATIC_JA_EN = {value: key for key, value in _STATIC_EN_JA.items()}


def _is_japanese_locale() -> bool:
    try:
        locale = str(getattr(bpy.app.translations, 'locale', '') or '').lower().replace('-', '_')
        return locale.startswith('ja')
    except Exception:
        return False


def _contains_japanese(text: str) -> bool:
    return bool(_JA_RE.search(text or ''))


def _parse_tagged(text: str) -> tuple[str, str] | None:
    raw = str(text or '')
    # smarttools-ui-style: migration-alias
    if 'JP:' not in raw and 'EN:' not in raw:
        return None
    # Handles multiline and inline "EN: ... JP: ..." / "JP: ... EN: ..." forms.
    pattern = re.compile(r'(JP|EN):\s*(.*?)(?=(?:\n|\s)(?:JP|EN):|$)', re.DOTALL)
    parts: dict[str, str] = {}
    for lang, value in pattern.findall(raw):
        parts[lang] = value.strip()
    if not parts:
        return None
    en = parts.get('EN') or parts.get('JP') or raw
    ja = parts.get('JP') or parts.get('EN') or raw
    return en, ja


def _normalize_display_text(value) -> str:
    # Blender labels must use ordinary half-width spaces; simultaneous
    # English/Japanese migration strings are resolved before this step.
    return str(value or '').replace('\u3000', ' ')


def loc_text(en: str, ja: str | None = None) -> str:
    parsed = _parse_tagged(str(en or ''))
    if parsed is not None:
        en, parsed_ja = parsed
        ja = parsed_ja
    elif ja is None:
        text = str(en or '')
        if ' / ' in text:
            left, right = text.split(' / ', 1)
            if _contains_japanese(right):
                en, ja = left.strip(), right.strip()
            else:
                en = text
        else:
            en = text
            ja = _STATIC_EN_JA.get(text)
    return _normalize_display_text(_sns_t(en, ja))


def tx(en: str, ja: str | None = None) -> str:
    return loc_text(en, ja)
