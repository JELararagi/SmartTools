"""Conservative, reference-aware cleanup of explicitly selected release work data.

No import-time Blender resources. The UI never mutates the open input scene.
"""
from __future__ import annotations

from collections import deque
import hashlib
from contextlib import ExitStack
from datetime import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

SCHEMA = "smarttools.release-cleanup.v1"
TYPES = ("OBJECT", "DATABLOCK", "TEXT", "ACTION", "VERTEX_GROUP", "SHAPE_KEY",
         "NLA_TRACK", "CACHE", "WORK_MARK")
_PLAN = None
_STATUS = ("Ready", "準備完了")
_LAST_EXECUTION = None
_CHOICES = []
_CHOICE_IDS = set()
_SELECTED = set()
_CONTRACT = {}
# Interface data. Its RNA strings (recent folders, keymap items) follow the
# session, never the file, so they neither protect data nor stale an inspection.
_UI_TYPES = {"Screen", "WorkSpace", "WindowManager"}
_REFERENCE_TYPES = {"STRING", "POINTER", "COLLECTION"}
_BASES_OF_REFERENCES = set()
MAX_IDS = 12000


def reset_selection():
    global _CHOICES, _CHOICE_IDS, _SELECTED, _CONTRACT
    _CHOICES, _CHOICE_IDS, _SELECTED, _CONTRACT = [], set(), set(), {}


class CleanupRefused(RuntimeError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":")).encode()).hexdigest().upper()


def file_sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def id_key(item):
    library = getattr(getattr(item, "library", None), "filepath", "")
    return f"{item.bl_rna.identifier}:{item.name_full}:{library}"


def _custom_strings(value, path, output, depth=0):
    if depth > 8:
        raise CleanupRefused("Custom-property nesting exceeds the inspection bound")
    if isinstance(value, str):
        output.append((path, value))
    elif hasattr(value, "items"):
        try:
            entries = value.items()
        except TypeError as exc:
            # Every bpy_struct exposes items(), including RNA types which
            # cannot own IDProperties. Only that exact native capability error
            # means there are no custom properties; ordinary RNA traversal
            # still runs in _strings(). All other read failures block apply.
            if (getattr(value, "bl_rna", None) is not None
                    and str(exc) == "bpy_struct.items(): this type doesn't support IDProperties"):
                return
            raise CleanupRefused("Unreadable custom-property references at " + path) from exc
        except Exception as exc:
            raise CleanupRefused("Unreadable custom-property references at " + path) from exc
        try:
            for key, child in entries:
                output.append((path + ".key", str(key)))
                _custom_strings(child, path + "." + str(key), output, depth + 1)
        except CleanupRefused:
            raise
        except Exception as exc:
            raise CleanupRefused("Unreadable custom-property iteration at " + path) from exc
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _custom_strings(child, f"{path}[{index}]", output, depth + 1)


def _own_references(struct):
    return any(prop.type in _REFERENCE_TYPES and prop.identifier != "rna_type"
               for prop in struct.properties)


def _holds_references(struct):
    """False for element types that are numbers only, such as keyframes or normals.

    An element can be a subclass of the declared type (an ActionStrip is really
    an ActionKeyframeStrip), so a type also counts when any subclass has references.
    """
    if struct is None or _own_references(struct):
        return True
    if not _BASES_OF_REFERENCES:
        import bpy
        for name in dir(bpy.types):
            rna = getattr(getattr(bpy.types, name, None), "bl_rna", None)
            if rna is not None and _own_references(rna):
                while rna is not None:
                    _BASES_OF_REFERENCES.add(rna.identifier)
                    rna = rna.base
    return struct.identifier in _BASES_OF_REFERENCES


def _strings(item):
    """Inspect reference-bearing RNA structures; never evaluate script strings."""
    result, seen = [], set()
    budget = [40000]
    owner = id_key(item)
    if item.bl_rna.identifier in _UI_TYPES:
        _custom_strings(item, owner, result)
        return sorted(set(result))
    # Breadth first: a struct is reached by its shortest path, so a long chain of
    # linked items (bones, nested layer collections) costs its size, not its length.
    queue = deque([(item, owner)])
    while queue:
        value, path = queue.popleft()
        if value is None:
            continue
        try:
            marker = (type(value).__name__, getattr(value, "as_pointer", lambda: id(value))())
        except ReferenceError as exc:
            raise CleanupRefused("Unreadable reference: " + path) from exc
        if marker in seen:
            continue
        seen.add(marker)
        budget[0] -= 1
        if budget[0] < 0:
            raise CleanupRefused("Too many references to inspect: " + owner)
        rna = getattr(value, "bl_rna", None)
        if rna is None:
            continue
        for prop in rna.properties:
            name = prop.identifier
            if name in {"rna_type", "id_data", "name", "name_full", "original"}:
                continue
            # An evaluation result, not authored data; its items also expire while iterating.
            if name == "depsgraph":
                continue
            # Geometry arrays contain no named references. Geometry is protected
            # by native ID edges and unchanged input bytes, never edited here.
            if name in {"vertices", "edges", "polygons", "loops", "points", "splines",
                        "pixels", "uv_layers", "attributes", "color_attributes"}:
                continue
            # Only these types carry references. Reading the others can run an
            # add-on's dynamic enum or getter, which must not decide the result.
            if prop.type not in _REFERENCE_TYPES:
                continue
            if prop.type != "STRING" and not _holds_references(prop.fixed_type):
                continue
            try:
                child = getattr(value, name)
            except Exception as exc:
                raise CleanupRefused(f"Unreadable reference: {path}.{name}") from exc
            if prop.type == "STRING" and child:
                result.append((path + "." + name, str(child)))
            elif prop.type == "POINTER":
                # Native ID links are already in BlendData.user_map().
                if child is not None and not hasattr(child, "name_full"):
                    queue.append((child, path + "." + name))
            elif prop.type == "COLLECTION":
                for index, element in enumerate(child):
                    if not hasattr(element, "name_full"):
                        queue.append((element, f"{path}.{name}[{index}]"))
        if hasattr(value, "items"):
            _custom_strings(value, path, result)
    return sorted(set(result))


def _non_membership_object_refs(owner):
    """Prove Scene/Collection object edges, excluding only membership RNA.

    user_map coalesces membership and semantic references into the same edge.
    Never drop that edge until camera/driver/node/custom-ID references have all
    been read. An unreadable/over-bound branch refuses the proof and apply.
    """
    refs, seen = set(), set()
    budget = [40000]
    queue = deque([owner])
    while queue:
        value = queue.popleft()
        if value is None or isinstance(value, (str, int, float, bool, bytes)):
            continue
        if budget[0] <= 0:
            raise CleanupRefused("Membership reference proof exceeds the inspection bound")
        marker = getattr(value, "as_pointer", lambda: id(value))()
        if marker in seen:
            continue
        seen.add(marker)
        budget[0] -= 1
        rna = getattr(value, "bl_rna", None)
        if value is not owner and hasattr(value, "name_full"):
            if rna is not None and rna.identifier == "Object":
                refs.add(id_key(value))
            elif rna is not None and rna.identifier == "Collection":
                # A semantic collection pointer (e.g. rigid-body world) uses
                # its contents. Scene/layer membership pointers are excluded
                # explicitly below, not by dropping every Collection link.
                refs.update(id_key(member) for member in value.all_objects)
            continue  # Other ID dependencies retain their own user_map edges.
        if rna is not None:
            for prop in rna.properties:
                name = prop.identifier
                if name in {"rna_type", "id_data", "original"}:
                    continue
                if (rna.identifier, name) in {
                    ("Scene", "objects"), ("Collection", "objects"),
                    ("Collection", "all_objects"), ("ViewLayer", "objects"),
                    ("Scene", "collection"), ("LayerCollection", "collection"),
                    # This is an evaluation result, not an authored dependency.
                    # Traversing its ids/objects reintroduces every scene member
                    # as a semantic use. Do not even request the derived graph;
                    # camera/drivers/custom IDs/semantic collections still walk.
                    ("ViewLayer", "depsgraph"),
                }:
                    continue
                if prop.type not in {"POINTER", "COLLECTION"} or not _holds_references(prop.fixed_type):
                    continue
                try:
                    child = getattr(value, name)
                    if prop.type == "POINTER":
                        queue.append(child)
                    else:
                        queue.extend(child)
                except Exception as exc:
                    raise CleanupRefused("Unreadable membership reference: " + name) from exc
        if hasattr(value, "items"):
            try:
                entries = value.items()
            except TypeError as exc:
                if rna is not None and str(exc) == "bpy_struct.items(): this type doesn't support IDProperties":
                    continue
                raise CleanupRefused("Unreadable membership custom references") from exc
            except Exception as exc:
                raise CleanupRefused("Unreadable membership custom references") from exc
            try:
                queue.extend(child for _, child in entries)
            except Exception as exc:
                raise CleanupRefused("Unreadable membership custom references") from exc
        elif isinstance(value, (tuple, list)):
            queue.extend(value)
    return refs


def graph_snapshot(bpy, contract):
    mapping = bpy.data.user_map()
    items = set(mapping)
    for users in mapping.values():
        items.update(users)
    items = sorted(items, key=id_key)
    if len(items) > MAX_IDS:
        raise CleanupRefused(f"Too many data-blocks to inspect (limit {MAX_IDS})")
    by_key = {id_key(item): item for item in items}
    by_name = {}
    for key, item in by_key.items():
        by_name.setdefault(item.name, []).append(key)
        # External contracts may name expression keys, deform bones or groups,
        # rather than their enclosing ID. Preserve that owner and its closure.
        for member in getattr(item, "vertex_groups", ()):
            by_name.setdefault(member.name, []).append(key)
        for member in getattr(item, "bones", ()):
            by_name.setdefault(member.name, []).append(key)
        for member in getattr(item, "key_blocks", ()):
            by_name.setdefault(member.name, []).append(key)
    edges = {key: set() for key in by_key}
    reasons = {key: [] for key in by_key}
    blockers, roots = [], set()
    membership_refs = {}
    for user in items:
        if user.bl_rna.identifier in {"Scene", "Collection"}:
            try:
                membership_refs[user] = (_non_membership_object_refs(user), set(user.objects))
            except Exception as exc:
                # Keep all native edges, and prevent apply on incomplete proof.
                blockers.append(str(exc) + ": " + id_key(user))
    for dependency, users in mapping.items():
        dep = id_key(dependency)
        for user in users:
            # Scene membership alone is not evidence of active release use.
            # Visible objects and instanced-collection contents become explicit
            # roots below; hidden working objects still require user selection.
            if dependency.bl_rna.identifier == "Object" and user in membership_refs:
                semantic, members = membership_refs[user]
                if dependency in members and dep not in semantic:
                    continue
            edges[id_key(user)].add(dep)
            reasons[dep].append("ID reference from " + id_key(user))
    all_strings = {}
    for key, item in by_key.items():
        if item.bl_rna.identifier == "Object":
            if item.users_collection and (not item.hide_viewport or not item.hide_render):
                roots.add(key)
                reasons[key].append("Visible viewport/render release object")
            instance = item.instance_collection
            if instance is not None:
                for member in instance.all_objects:
                    roots.add(id_key(member))
                    reasons[id_key(member)].append("Instanced collection content")
        if item.bl_rna.identifier in {"Scene", "Screen", "WorkSpace", "WindowManager"}:
            roots.add(key)
            reasons[key].append("Active release scene/UI root")
        if getattr(item, "library", None) or getattr(item, "use_fake_user", False):
            roots.add(key)
            reasons[key].append("Library link or fake-user intent")
        try:
            strings = _strings(item)
        except CleanupRefused as exc:
            blockers.append(str(exc))
            strings = []
        all_strings[key] = strings
        for path, value in strings:
            if path.endswith(".expression") and re.search(r"\b(bpy|exec|eval|__import__)\b", value):
                blockers.append("Unresolved dynamic driver: " + path)
            # Match complete identifiers/quoted names; no naming-convention purge.
            tokens = {value, *re.findall(r"[\w.]+", value), *re.findall(r"[\w. -]+", value)}
            for token in tokens:
                for target in by_name.get(token, ()):
                    if target != key:
                        edges[key].add(target)
                        reasons[target].append("Name reference at " + path)
        if item.bl_rna.identifier == "Text":
            text = item.as_string()
            if re.search(r"\b(bpy|exec|eval|__import__|import)\b", text):
                roots.add(key)
                reasons[key].append("Script text retained")
                if contract.get("preserve_all_for_dynamic_scripts") is True:
                    roots.update(by_key)
                else:
                    blockers.append("Unresolved dynamic script: " + key)
    for name in contract.get("preserve_names", []):
        matches = by_name.get(name, [])
        if not matches:
            blockers.append("Declared reference missing: " + name)
        roots.update(matches)
        for key in matches:
            reasons[key].append("Explicit external-name preservation contract")
    for key in contract.get("preserve_ids", []):
        if key not in by_key:
            blockers.append("Declared ID missing: " + key)
        else:
            roots.add(key)
            reasons[key].append("Explicit ID preservation contract")
    for key, item in by_key.items():
        if item.bl_rna.identifier in {"Image", "Library", "Sound", "MovieClip", "Volume"}:
            filepath = getattr(item, "filepath", "")
            if filepath and not getattr(item, "packed_file", None):
                external = Path(bpy.path.abspath(filepath))
                if not external.exists() and not any(mark in filepath for mark in ("<UDIM>", "#")):
                    blockers.append("Missing external dependency: " + key)
                elif "<UDIM>" in filepath or "#" in filepath:
                    blockers.append("Unresolved external sequence: " + key)
            roots.add(key)
            reasons[key].append("External/texture data always retained")
    protected, queue = set(roots), list(roots)
    while queue:
        for child in edges[queue.pop()]:
            if child not in protected:
                protected.add(child)
                queue.append(child)
    # What is compared between inspections. Windows and screens come and go with
    # the session (a file browser adds one), so only the file's own data counts.
    interface = {key for key, item in by_key.items() if item.bl_rna.identifier in _UI_TYPES}
    serial = {
        "nodes": [{"id": key, "users": item.users,
                   "fake_user": bool(item.use_fake_user),
                   "memberships": sorted(c.name for c in getattr(item, "users_collection", ())),
                   "hidden": [bool(getattr(item, "hide_viewport", False)), bool(getattr(item, "hide_render", False))],
                   "strings": all_strings[key]} for key, item in by_key.items() if key not in interface],
        "edges": {key: sorted(value) for key, value in edges.items() if key not in interface},
        "roots": sorted(roots - interface), "protected": sorted(protected - interface),
        "blockers": sorted(set(blockers)),
    }
    return by_key, edges, reasons, {**serial, "all_roots": sorted(roots), "all_protected": sorted(protected)}


def _contract(value):
    if not isinstance(value, dict) or set(value) - {
        "preserve_names", "preserve_ids", "preserve_all_for_dynamic_scripts"
    }:
        raise CleanupRefused("Unknown preservation contract")
    for key in ("preserve_names", "preserve_ids"):
        if not isinstance(value.get(key, []), list) or not all(
            isinstance(name, str) and name for name in value.get(key, [])
        ):
            raise CleanupRefused("Invalid preservation names/IDs")
    return value


def _source_sha(bpy):
    source = Path(bpy.data.filepath) if bpy.data.filepath else None
    return file_sha(source) if source and source.is_file() else None


def inspect(bpy, request=None, _known=None, _bytes_proven=False):
    """_known: a snapshot and input hash just taken for the same contract, to avoid re-reading.

    _bytes_proven: the caller compares the input hash itself, so the session flag says nothing."""
    request = request or {}
    if set(request) - {"operations", "contract"}:
        raise CleanupRefused("Unknown cleanup request fields")
    contract = _contract(request.get("contract", {}))
    operations = request.get("operations", [])
    if not isinstance(operations, list) or len(operations) > MAX_IDS:
        raise CleanupRefused("Invalid explicit operations")
    snapshot, source_sha = _known or (graph_snapshot(bpy, contract), _source_sha(bpy))
    by_key, edges, reasons, graph = snapshot
    protected_ids = graph["all_protected"]
    source = Path(bpy.data.filepath) if bpy.data.filepath else None
    blockers = list(graph["blockers"])
    dirty = bpy.data.is_dirty and not _bytes_proven
    if source_sha is None or dirty:
        blockers.append("Apply requires a saved, unchanged input .blend")
    rows, seen = [], set()
    selected_ids = {op.get("id") for op in operations if isinstance(op, dict)}
    incoming = {key: [] for key in by_key}
    for user, targets in edges.items():
        for target in targets:
            incoming[target].append(user)
    for operation in operations:
        if not isinstance(operation, dict) or set(operation) - {"kind", "id", "member"}:
            raise CleanupRefused("Malformed explicit operation")
        kind, key = operation.get("kind"), operation.get("id")
        signature = (kind, key, operation.get("member"))
        if kind not in TYPES or signature in seen:
            raise CleanupRefused("Unknown or duplicate typed operation")
        seen.add(signature)
        item = by_key.get(key)
        why = list(reasons.get(key, []))
        state = "CANDIDATE"
        if item is None:
            state, why = "BLOCKED", ["Requested ID does not exist"]
        elif key in protected_ids:
            state = "PROTECTED"
            why.append("Reachable from a retained release root")
        elif any(user not in selected_ids for user in incoming[key]):
            state = "PROTECTED"
            why.append("Referenced by unselected data")
        elif kind in {"VERTEX_GROUP", "SHAPE_KEY", "NLA_TRACK", "CACHE", "WORK_MARK"}:
            # Sub-ID edits can change adopted shape, deformation, animation or
            # opaque runtime values. No inference from apparent inactivity.
            state = "BLOCKED"
            why.append("Sub-ID/cache preservation cannot be proved; retained")
        elif kind == "OBJECT" and item.bl_rna.identifier != "Object":
            state, why = "BLOCKED", ["OBJECT kind requires an Object ID"]
        elif kind in {"TEXT", "ACTION"} and item.bl_rna.identifier != kind.title():
            state, why = "BLOCKED", ["Typed ID mismatch"]
        elif getattr(item, "is_embedded_data", False):
            state, why = "PROTECTED", ["Embedded owner data"]
        elif source_sha is not None and not dirty and item.users == 0:
            # Blender does not write zero-user IDs, so the copy cannot contain or remove it.
            state, why = "BLOCKED", ["Unused data is not stored in the saved file"]
        if state == "CANDIDATE":
            why.append("No retained root or external incoming reference")
        rows.append({"operation": operation, "decision": state,
                     "reasons": sorted(set(why)), "outcome": "NOT_APPLIED"})
    # A retained selection cannot silently release dependencies of its own.
    changed = True
    while changed:
        changed = False
        candidate_ids = {row["operation"]["id"] for row in rows if row["decision"] == "CANDIDATE"}
        for row in rows:
            if row["decision"] == "CANDIDATE" and any(
                user not in candidate_ids for user in incoming[row["operation"]["id"]]
            ):
                row["decision"] = "PROTECTED"
                row["reasons"].append("Dependency of retained data")
                changed = True
    return {
        "schema": SCHEMA, "version": 1, "state": "INSPECTED",
        "input": {"path": str(source) if source else "", "sha256": source_sha},
        "request": request,
        "graph_sha256": digest({field: graph[field] for field in ("nodes", "edges", "roots", "protected", "blockers")}),
        "preserved_roots": graph["all_roots"], "protected_ids": protected_ids,
        "reference_reasons": {key: sorted(set(value)) for key, value in reasons.items()},
        "blockers": sorted(set(blockers)), "decisions": rows,
        "actual_removals": [], "failures": [],
    }


def summary(plan, japanese=False):
    # The plan holds only the checked rows; count the whole list the dialog shows.
    current = {row["operation"]["id"]: row["decision"] for row in plan["decisions"]}
    decisions = [current.get(row["operation"]["id"], row["decision"]) for row in _CHOICES] or list(current.values())
    counts = {name: decisions.count(name) for name in ("CANDIDATE", "PROTECTED", "BLOCKED")}
    selected = len(plan["decisions"])
    state = plan.get("state", "INSPECTED_NOT_APPLIED")
    label = {"APPLIED_TO_COPY": ("Committed", "確定"), "FAILED_COPY_DISCARDED": ("Failed/discarded", "失敗・破棄"),
             "COPY_NOT_COMMITTED": ("Not committed", "未確定")}.get(state, ("Inspected/not applied", "点検・未適用"))
    if japanese:
        return (f"{label[1]} / 候補 {counts['CANDIDATE']} / 保護 {counts['PROTECTED']} / 保留 {counts['BLOCKED']} / 選択 {selected}"
                f" / 阻害 {len(plan['blockers'])} / 実削除 {len(plan['actual_removals'])}")
    return (f"{label[0]} / Candidates {counts['CANDIDATE']} / Protected {counts['PROTECTED']} / Blocked {counts['BLOCKED']} / Selected {selected}"
            f" / Blockers {len(plan['blockers'])} / Removed {len(plan['actual_removals'])}")


def prepare_selection(bpy, contract=None):
    """Nonmutating inventory, explicit empty default, no hand-authored IDs."""
    global _CHOICES, _CHOICE_IDS, _SELECTED, _CONTRACT, _PLAN
    reset_selection()
    _PLAN = None
    contract = _contract(contract or {})
    snapshot = graph_snapshot(bpy, contract)
    known = (snapshot, _source_sha(bpy))
    operations = [{"kind": {"Object": "OBJECT", "Text": "TEXT", "Action": "ACTION"}.get(
        item.bl_rna.identifier, "DATABLOCK"), "id": key} for key, item in snapshot[0].items()]
    inventory = inspect(bpy, {"operations": operations, "contract": contract}, known)
    _CHOICES = inventory["decisions"]
    _CHOICE_IDS = {row["operation"]["id"] for row in _CHOICES}
    _CONTRACT = contract
    _PLAN = inspect(bpy, {"operations": [], "contract": contract}, known)
    return _CHOICES


def select_item(bpy, key, selected):
    global _SELECTED, _PLAN
    choices = {row["operation"]["id"]: row for row in _CHOICES}
    if key not in choices or (selected and choices[key]["decision"] != "CANDIDATE"):
        raise CleanupRefused("Protected, blocked or unknown selection")
    selection = (_SELECTED | {key}) if selected else (_SELECTED - {key})
    request = {"operations": [choices[k]["operation"] for k in sorted(selection)], "contract": _CONTRACT}
    plan = inspect(bpy, request)
    if _PLAN is None or any(plan[field] != _PLAN[field] for field in ("input", "graph_sha256")):
        raise CleanupRefused("Stale source or reference graph; inspect again")
    _SELECTED, _PLAN = selection, plan
    return plan


_ID_KIND_NAMES = {
    "Action": ("Action", "アクション"), "Annotation": ("Annotation", "アノテーション"),
    "AreaLight": ("Area Light", "エリアライト"), "Armature": ("Armature", "アーマチュア"),
    "Brush": ("Brush", "ブラシ"), "CacheFile": ("Cache File", "キャッシュファイル"),
    "Camera": ("Camera", "カメラ"), "Collection": ("Collection", "コレクション"),
    "CompositorNodeTree": ("Compositor Node Tree", "コンポジターノードツリー"),
    "Curve": ("Curve", "カーブ"), "Curves": ("Hair Curves", "ヘアーカーブ"),
    "FreestyleLineStyle": ("Line Style", "ラインスタイル"),
    "GeometryNodeTree": ("Geometry Node Tree", "ジオメトリノードツリー"),
    "GreasePencil": ("Grease Pencil", "グリースペンシル"), "Image": ("Image", "画像"),
    "Key": ("Shape Keys", "シェイプキー"), "Lattice": ("Lattice", "ラティス"),
    "Library": ("Library", "ライブラリ"), "Light": ("Light", "ライト"),
    "LightProbe": ("Light Probe", "ライトプローブ"),
    "LightProbePlane": ("Light Probe", "ライトプローブ"),
    "LightProbeSphere": ("Light Probe", "ライトプローブ"),
    "LightProbeVolume": ("Light Probe", "ライトプローブ"),
    "Mask": ("Mask", "マスク"), "Material": ("Material", "マテリアル"), "Mesh": ("Mesh", "メッシュ"),
    "MetaBall": ("Metaball", "メタボール"), "MovieClip": ("Movie Clip", "ムービークリップ"),
    "Object": ("Object", "オブジェクト"), "PaintCurve": ("Paint Curve", "ペイントカーブ"),
    "Palette": ("Palette", "パレット"), "ParticleSettings": ("Particle Settings", "パーティクル設定"),
    "PointCloud": ("Point Cloud", "ポイントクラウド"), "PointLight": ("Point Light", "ポイントライト"),
    "Scene": ("Scene", "シーン"), "Screen": ("Screen", "スクリーン"),
    "ShaderNodeTree": ("Shader Node Tree", "シェーダーノードツリー"),
    "Sound": ("Sound", "サウンド"), "Speaker": ("Speaker", "スピーカー"),
    "SpotLight": ("Spot Light", "スポットライト"), "SunLight": ("Sun Light", "サンライト"),
    "SurfaceCurve": ("Surface", "サーフェス"), "Text": ("Text", "テキスト"),
    "TextCurve": ("Text Curve", "テキストカーブ"),
    "TextureNodeTree": ("Texture Node Tree", "テクスチャノードツリー"),
    "VectorFont": ("Font", "フォント"), "Volume": ("Volume", "ボリューム"),
    "WindowManager": ("Window Manager", "ウィンドウマネージャー"),
    "WorkSpace": ("Workspace", "ワークスペース"), "World": ("World", "ワールド"),
}


def _id_kind_name(identifier, japanese):
    names = _ID_KIND_NAMES.get(identifier)
    if names is None:
        if identifier.endswith("NodeTree"):
            names = ("Node Tree", "ノードツリー")
        elif identifier.endswith("Texture"):
            names = ("Texture", "テクスチャ")
        else:
            names = ("Data", "データ")
    return names[int(japanese)]


def id_label(key, japanese=False):
    """Readable name of an id_key() string; the key itself stays the data identity."""
    kind, _, rest = key.partition(":")
    name, library = rest, ""
    if rest.endswith(":"):
        name = rest[:-1]
    else:
        # name_full of linked data is "name [library]", followed by the library file path.
        linked = re.fullmatch(r"(.*) \[.*\]:(.+)", rest, re.DOTALL)
        if linked:
            name, library = linked.groups()
    if japanese:
        label = f"{_id_kind_name(kind, True)}「{name}」"
    else:
        label = f"{_id_kind_name(kind, False)}: {name}"
    if library:
        label += ("（リンク: " if japanese else " (linked: ") + re.split(r"[\\/]", library)[-1] + ("）" if japanese else ")")
    return label


def _reference_owner(path):
    """The owning ID key at the start of a reference path from _strings()."""
    if path in _CHOICE_IDS:
        return path
    # Names may contain any delimiter, so match the inspected keys, longest first.
    for mark in reversed(list(re.finditer(r"[.\[]", path))):
        if path[:mark.start()] in _CHOICE_IDS:
            return path[:mark.start()]
    match = (re.match(r"\w+:.* \[.*\]:.+?\.blend(?=[.\[]|$)", path, re.IGNORECASE)
             or re.match(r"\w+:.*?:(?=[.\[]|$)", path))
    if match:
        return match.group(0)
    parts = path.split(":", 2)
    return parts[0] + ":" + parts[1] + ":" if len(parts) == 3 else ""


# English prefix, Japanese prefix, whether the text after it is a reference path (else a whole ID key).
_ID_MESSAGES = (
    ("ID reference from ", "ID参照元: ", False),
    ("Name reference at ", "名前参照箇所: ", True),
    ("Unresolved dynamic driver: ", "未解決の動的ドライバー: ", True),
    ("Unresolved dynamic script: ", "未解決の動的スクリプト: ", False),
    ("Missing external dependency: ", "外部の依存先が見つかりません: ", False),
    ("Unresolved external sequence: ", "未解決の外部連番: ", False),
    ("No safe ID collection: ", "安全に削除できる格納先がありません: ", False),
    ("Live user before ID removal: ", "削除の前に使用者があります: ", False),
    ("Live user appeared before removal: ", "削除の前に使用者が現れました: ", False),
    ("Unreadable reference: ", "読み取れない参照: ", True),
    ("Too many references to inspect: ", "参照が多すぎて点検しきれません: ", False),
    ("Unreadable custom-property references at ", "読み取れないカスタムプロパティ参照: ", True),
    ("Unreadable custom-property iteration at ", "読み取れないカスタムプロパティ参照: ", True),
    ("Membership reference proof exceeds the inspection bound: ", "所属の参照の確認が点検の上限を超えました: ", False),
)
_MESSAGES = {
    "Visible viewport/render release object": "ビューポートまたはレンダー表示中のオブジェクト",
    "Instanced collection content": "インスタンス化コレクションの内容",
    "Active release scene/UI root": "シーンまたはUIの保持ルート",
    "Library link or fake-user intent": "ライブラリリンクまたは偽ユーザー指定",
    "Script text retained": "スクリプトテキストを保持",
    "Explicit external-name preservation contract": "外部名前の明示的保護契約",
    "Explicit ID preservation contract": "IDの明示的保護契約",
    "External/texture data always retained": "外部素材・テクスチャを常に保持",
    "Requested ID does not exist": "指定IDが存在しません",
    "Reachable from a retained release root": "保持するルートから参照されています",
    "Referenced by unselected data": "未選択データが参照しています",
    "Sub-ID/cache preservation cannot be proved; retained": "部分ID・キャッシュの保全を証明できないため保持",
    "OBJECT kind requires an Object ID": "オブジェクト種別にはObject IDが必要です",
    "Typed ID mismatch": "指定種別とIDが一致しません",
    "Embedded owner data": "所有者に埋め込まれたデータ",
    "Unused data is not stored in the saved file": "使っていないデータは保存されないため、保存ファイルにありません",
    "No retained root or external incoming reference": "保持ルートや外部からの参照なし",
    "Referenced by retained selection": "保持する選択対象が参照しています",
    "Dependency of retained data": "保持するデータの依存先です",
    "Declared reference missing: ": "保護契約の名前が見つかりません: ",
    "Declared ID missing: ": "保護契約のIDが見つかりません: ",
    "Apply requires a saved, unchanged input .blend": "保存済みで変更のない入力.blendが必要です",
    "Custom-property nesting exceeds the inspection bound": "カスタムプロパティの階層が点検の上限を超えました",
    "Membership reference proof exceeds the inspection bound": "所属の参照の確認が点検の上限を超えました",
    "Unreadable membership reference: ": "読み取れない所属の参照: ",
    "Unreadable membership custom references": "読み取れない所属のカスタム参照",
    f"Too many data-blocks to inspect (limit {MAX_IDS})": f"データが多すぎて点検できません（上限 {MAX_IDS} 個）",
    "Unknown preservation contract": "保護契約の形式が正しくありません",
    "Invalid preservation names/IDs": "保護契約の名前またはIDが正しくありません",
    "Unknown cleanup request fields": "要求に不明な項目があります",
    "Invalid explicit operations": "要求の対象が正しくありません",
    "Malformed explicit operation": "要求の対象の形式が正しくありません",
    "Unknown or duplicate typed operation": "対象の種類が不明か、重複しています",
    "Protected, blocked or unknown selection": "保護・保留・不明の行は選択できません",
    "Stale source or reference graph; inspect again": "入力または参照が変わりました。点検し直してください",
    "Stale source or reference graph": "入力または参照が変わりました",
    "Choose a new JSON output path": "新しいJSONの出力先を指定してください",
    "Visible object cannot be removed": "表示中のオブジェクトは削除できません",
    "Non-membership object user appeared": "コレクション以外の使用者が現れました",
    "Cannot measure available memory": "空きメモリを測れません",
    "Copy worker requires at least 10 GiB available memory": "コピーの作成には10 GiB以上の空きメモリが必要です",
    "Disposable worker copy required": "使い捨てのコピーでだけ実行できます",
    "Unresolved inspection blockers": "点検の阻害が残っています",
    "Requested operation is blocked": "選択した行が保留になりました",
    "Stale typed decisions": "判定が点検の時と変わりました",
    "Cyclic candidate references retained": "候補同士が循環して参照しているため保持します",
    "Choose a new .blend release-copy output": "新しい.blendの出力先を指定してください",
    "Blockers remain; see the list in this dialog": "阻害が残っているため適用できません。画面の阻害の行を確かめてください",
    "Already applied; inspect again to make another copy": "適用は済んでいます。もう一度コピーを作る時は、先に点検してください",
    "The output folder does not exist": "出力先のフォルダーがありません。パスを確かめてください",
    "Cannot write to the output folder": "出力先のフォルダーに書き込めません",
    "Cannot write the output file": "出力先のファイルを書き込めません",
    "No proven removal candidates selected": "削除できる候補が選択されていません",
    "Output manifest already exists": "出力先の結果ファイルがすでにあります",
    "A cleanup copy worker already owns the slot": "別のコピー作成が実行中です",
    "Copy worker timed out; copy discarded": "コピーの作成が時間切れになり、破棄しました",
    "Copy worker failed: ": "コピーの作成に失敗しました",
    "Inspect first": "先に点検してください",
    "Cannot read the preservation contract": "保護契約のファイルを読めません",
    "Input changed while copy worker was running": "コピーの作成中に入力が変わりました",
    "Copy discarded; failure manifest: ": "コピーを破棄しました。失敗の記録: ",
    "Cannot commit exclusive release copy": "コピーを確定できません",
    "Owned staging file is missing or unsafe": "作業用ファイルが見つからないか、安全ではありません",
    "Staging save did not finish; copy discarded": "作業用ファイルの保存が終わらず、コピーを破棄しました",
}


def reason_text(text, japanese=False):
    """Display text of a reason, blocker or refusal; the stored text keeps the internal path."""
    for english, localized, is_path in _ID_MESSAGES:
        if text.startswith(english):
            rest = text[len(english):]
            owner = _reference_owner(rest) if is_path else rest
            if owner and ":" in owner:
                return (localized if japanese else english) + id_label(owner, japanese)
    if not japanese:
        return text
    for english, localized, _ in _ID_MESSAGES:
        if text.startswith(english):
            return localized + text[len(english):]
    # A longer message may start with a shorter one, so the longest match wins.
    for english in sorted(_MESSAGES, key=len, reverse=True):
        if text.startswith(english):
            if english == "Copy worker failed: ":
                return _MESSAGES[english]  # Blender's own output stays in the result JSON.
            return _MESSAGES[english] + text[len(english):]
    # Plans keep the exact text in "failures", which Export Result writes to its JSON.
    return "予期しない問題が起きました。操作をやり直してください"


def refusal_message(exc):
    """Stable text of a failed write; anything else keeps its own message."""
    if isinstance(exc, FileNotFoundError):
        return "The output folder does not exist"
    if isinstance(exc, PermissionError):
        return "Cannot write to the output folder"
    if isinstance(exc, OSError):
        return "Cannot write the output file"
    return str(exc)


def human_summary(plan, japanese=False):
    state = plan.get("state", "INSPECTED_NOT_APPLIED")
    states = {
        "INSPECTED_NOT_APPLIED": ("Inspected; nothing committed", "点検済み・未確定"),
        "APPLIED_TO_COPY": ("Committed to new copy", "新規コピーへ確定"),
        "FAILED_COPY_DISCARDED": ("Failed copy discarded; no committed removals", "失敗コピー破棄・確定削除なし"),
        "COPY_NOT_COMMITTED": ("Copy not committed; no removals", "コピー未確定・削除なし"),
    }
    title = states.get(state, ("Uncommitted result", "未確定の結果"))[int(japanese)]
    lines = [title, summary(plan, japanese),
             ("入力: " if japanese else "Input: ") + str(plan["input"]["path"])]
    if "output" in plan:
        lines.append(("出力: " if japanese else "Output: ") + plan["output"]["path"])
    lines.append(("確定した実削除: " if japanese else "Committed removals: ") + str(len(plan["actual_removals"])))
    lines.extend("  " + id_label(key, japanese) for key in plan["actual_removals"])
    lines.append(("保留・保護・未実行: " if japanese else "Blocked, protected or not applied: ") + str(sum(
        row.get("outcome") != "REMOVED" for row in plan["decisions"])))
    lines.extend("  " + ({"CANDIDATE": "候補", "PROTECTED": "保護", "BLOCKED": "保留"}.get(row["decision"], row["decision"]) if japanese else row["decision"])
                 + " / " + id_label(row["operation"]["id"], japanese) + " / " + "; ".join(dict.fromkeys(reason_text(reason, japanese) for reason in row["reasons"]))
                 for row in plan["decisions"] if row.get("outcome") != "REMOVED")
    lines.extend(("阻害: " if japanese else "Blocker: ") + reason_text(text, japanese) for text in plan["blockers"])
    lines.extend(("失敗: " if japanese else "Failure: ") + reason_text(str(text), japanese) for text in plan.get("failures", []))
    lines.append("復旧: 保存した原本を開きます。外部ファイルは削除していません。" if japanese else
                 "Restore: open the saved original. External files were not deleted.")
    return "\n".join(lines) + "\n"


def export_result(plan, path, japanese=False):
    target = Path(path).absolute()
    summary_path = target.with_suffix(".txt")
    if target.exists() or summary_path.exists() or target.suffix.lower() != ".json":
        raise CleanupRefused("Choose a new JSON output path")
    created = []
    try:
        # Reserve both with exclusive create; remove only this call's outputs
        # if either creation/write fails. Never truncate an existing result.
        with target.open("x", encoding="utf-8") as stream:
            created.append(target)
            json.dump(plan, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
        with summary_path.open("x", encoding="utf-8") as stream:
            created.append(summary_path)
            stream.write(human_summary(plan, japanese))
    except Exception:
        for owned in created:
            owned.unlink(missing_ok=True)
        raise
    return str(target)


def _remove_id(bpy, item):
    if item.bl_rna.identifier == "Object":
        if not item.hide_viewport or not item.hide_render:
            raise CleanupRefused("Visible object cannot be removed")
        collections = tuple(item.users_collection)
        if item.users != len(collections):
            raise CleanupRefused("Non-membership object user appeared")
        for collection in collections:
            collection.objects.unlink(item)
    collection = next((getattr(bpy.data, prop.identifier)
                       for prop in bpy.data.bl_rna.properties
                       if prop.type == "COLLECTION" and hasattr(bpy.data, prop.identifier)
                       and any(value == item for value in getattr(bpy.data, prop.identifier))), None)
    if collection is None:
        raise CleanupRefused("No safe ID collection: " + id_key(item))
    try:
        collection.remove(item, do_unlink=False)
    except TypeError:
        if item.users != 0:
            raise CleanupRefused("Live user before ID removal: " + id_key(item))
        collection.remove(item)


def _worker_memory_gate():
    """No worker launch under measured memory pressure; no resident monitor."""
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        class Memory(ctypes.Structure):
            _fields_ = [("length", wintypes.DWORD), ("load", wintypes.DWORD)] + [
                (name, ctypes.c_ulonglong) for name in
                ("total", "available", "page_total", "page_available", "virtual_total", "virtual_available", "extended")]
        value = Memory()
        value.length = ctypes.sizeof(value)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
            raise CleanupRefused("Cannot measure available memory")
        if value.available < 10 * 2**30:
            raise CleanupRefused("Copy worker requires at least 10 GiB available memory")


def apply_in_disposable_copy(bpy, plan, *, disposable=False):
    """Worker-only transaction. A failed copy is discarded, never published."""
    if disposable is not True:
        raise CleanupRefused("Disposable worker copy required")
    fresh = inspect(bpy, plan["request"], _bytes_proven=True)
    # This worker runs without add-ons or UI, so its graph legitimately lacks the
    # session's add-on strings; those were judged in the session. Identical input
    # bytes prove the data, and every removal must still be a candidate here.
    # Opening a file can mark this worker's session as changed; the bytes decide.
    if fresh["input"] != plan["input"]:
        raise CleanupRefused("Stale source or reference graph")
    if fresh["blockers"]:
        raise CleanupRefused("Unresolved inspection blockers")
    if any(row["decision"] == "BLOCKED" for row in fresh["decisions"]):
        raise CleanupRefused("Requested operation is blocked")
    candidates = {row["operation"]["id"] for row in fresh["decisions"] if row["decision"] == "CANDIDATE"}
    if any(row["decision"] == "CANDIDATE" and row["operation"]["id"] not in candidates for row in plan["decisions"]):
        raise CleanupRefused("Stale typed decisions")
    result = json.loads(json.dumps(plan))
    by_key, edges, _, _ = graph_snapshot(bpy, plan["request"].get("contract", {}))
    pending = {row["operation"]["id"] for row in result["decisions"] if row["decision"] == "CANDIDATE"}
    attempted = []
    try:
        while pending:
            ready = sorted(key for key in pending if not any(
                key in edges[user] for user in pending if user != key
            ))
            if not ready:
                raise CleanupRefused("Cyclic candidate references retained")
            for key in ready:
                item = by_key[key]
                membership_users = len(item.users_collection) if item.bl_rna.identifier == "Object" else 0
                if item.users != membership_users:
                    raise CleanupRefused("Live user appeared before removal: " + key)
                # No recursive orphan purge and no unlink of retained users.
                # Objects default to do_unlink=True in Blender; override that
                # explicitly so no hidden user can be changed as a side effect.
                _remove_id(bpy, item)
                attempted.append(key)
                pending.remove(key)
        result["actual_removals"] = attempted
        result["state"] = "APPLIED_TO_COPY"
        for row in result["decisions"]:
            row["outcome"] = "REMOVED" if row["operation"]["id"] in attempted else "RETAINED"
    except Exception as exc:
        result["state"] = "FAILED_COPY_DISCARDED"
        result["failures"] = [str(exc)]
        result["attempted_in_discarded_copy"] = attempted
        result["actual_removals"] = []
        for row in result["decisions"]:
            row["outcome"] = "NOT_COMMITTED"
    return result


def _plan_verdict(plan):
    return (plan["input"], plan["request"], plan["graph_sha256"], plan["blockers"],
            [(row["operation"], row["decision"]) for row in plan["decisions"]])


def apply_copy(bpy, plan, output, japanese=False):
    global _LAST_EXECUTION
    source = Path(plan["input"]["path"]).resolve()
    output = Path(output).absolute()
    if output.suffix.lower() != ".blend" or output.exists() or output.resolve() == source:
        raise CleanupRefused("Choose a new .blend release-copy output")
    if not output.parent.is_dir():
        raise CleanupRefused("The output folder does not exist")
    if plan.get("state") == "APPLIED_TO_COPY":
        raise CleanupRefused("Already applied; inspect again to make another copy")
    fresh = inspect(bpy, plan["request"])
    if fresh["blockers"]:
        raise CleanupRefused("Blockers remain; see the list in this dialog")
    # Reasons list every referrer, including the interface; only the verdicts count.
    if _plan_verdict(fresh) != _plan_verdict(plan):
        raise CleanupRefused("Stale source or reference graph; inspect again")
    # A refused attempt only marks the result fields; it does not make the inspection stale.
    plan = {**plan, "state": fresh["state"], "actual_removals": [], "failures": []}
    if not any(row["decision"] == "CANDIDATE" for row in plan["decisions"]):
        raise CleanupRefused("No proven removal candidates selected")
    report_path = Path(str(output) + ".cleanup.json")
    if report_path.exists() or report_path.with_suffix(".txt").exists():
        raise CleanupRefused("Output manifest already exists")
    _worker_memory_gate()
    # Work directory belongs only to this bounded invocation; worker never opens
    # source for saving and never receives user scripts/config/add-on paths.
    with tempfile.TemporaryDirectory(prefix="stm_release_", dir=output.parent) as work, ExitStack() as staging_cleanup:
        work = Path(work)
        # Blender remaps // references against the saved .blend's directory.
        # The staged file and its final hardlink must therefore share a parent,
        # even when the source is in an unrelated directory. Reserve this exact
        # invocation-owned leaf; never overwrite a pre-existing staging file.
        stage = work.with_suffix(".blend")
        with stage.open("xb"):
            pass
        staging_cleanup.callback(stage.unlink, missing_ok=True)
        (work / "plan.json").write_text(json.dumps(plan), encoding="utf-8")
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", TMP=str(work), TEMP=str(work))
        for variable in ("PYTHONPATH", "PYTHONHOME", "BLENDER_USER_RESOURCES", "BLENDER_USER_EXTENSIONS"):
            env.pop(variable, None)
        for name in ("CONFIG", "SCRIPTS", "DATAFILES"):
            directory = work / name.lower()
            directory.mkdir()
            env["BLENDER_USER_" + name] = str(directory)
        command = [bpy.app.binary_path, "--background", "--factory-startup", "--disable-autoexec",
                   str(source), "--python", str(Path(__file__).resolve()), "--", str(work)]
        _LAST_EXECUTION = {"command": command, "started_at": datetime.now().astimezone().isoformat(),
                           "timeout_seconds": 180, "pid": None, "child_remaining": False}
        child = None
        lock = Path(tempfile.gettempdir()) / "smarttools_release_cleanup.worker.lock"
        try:
            with lock.open("x", encoding="utf-8") as stream:
                json.dump({"owner": "smart_tools_manager.release_cleanup", "pid": os.getpid()}, stream)
        except FileExistsError as exc:
            raise CleanupRefused("A cleanup copy worker already owns the slot") from exc
        try:
            child = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     text=True, creationflags=getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0))
            _LAST_EXECUTION.update(pid=child.pid, child_remaining=True)
            try:
                stdout, stderr = child.communicate(timeout=180)
            except subprocess.TimeoutExpired as exc:
                child.kill()
                child.communicate()
                raise CleanupRefused("Copy worker timed out; copy discarded") from exc
            returncode = child.returncode
        finally:
            if child is not None and child.poll() is None:
                child.kill()
                child.wait()
            _LAST_EXECUTION.update(child_remaining=False, ended_at=datetime.now().astimezone().isoformat())
            if lock.exists():
                owner = json.loads(lock.read_text(encoding="utf-8"))
                if owner == {"owner": "smart_tools_manager.release_cleanup", "pid": os.getpid()}:
                    lock.unlink()
        result_path = work / "result.json"
        if not result_path.exists():
            raise CleanupRefused("Copy worker failed: " + stderr[-500:])
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if file_sha(source) != plan["input"]["sha256"]:
            raise CleanupRefused("Input changed while copy worker was running")
        result["worker_execution"] = _LAST_EXECUTION
        if returncode or result["state"] != "APPLIED_TO_COPY":
            export_result(result, report_path, japanese)
            raise CleanupRefused("Copy discarded; failure manifest: " + str(report_path))
        try:
            # Exclusive hardlink atomically publishes a complete file on the same
            # volume. An existing output, including a race, is never replaced.
            os.link(stage, output)
        except OSError as exc:
            raise CleanupRefused("Cannot commit exclusive release copy") from exc
        result["output"] = {"path": str(output), "sha256": file_sha(output)}
        try:
            export_result(result, report_path, japanese)
        except Exception:
            # Only our just-created exact copy is removed on paired-manifest
            # failure. Original and pre-existing files are never deleted.
            if output.is_file() and file_sha(output) == result["output"]["sha256"]:
                output.unlink()
            raise
        return result


def _worker():
    import bpy
    work = Path(sys.argv[sys.argv.index("--") + 1])
    plan = json.loads((work / "plan.json").read_text(encoding="utf-8"))
    try:
        result = apply_in_disposable_copy(bpy, plan, disposable=True)
        if result["state"] == "APPLIED_TO_COPY":
            stage = work.with_suffix(".blend")
            if not stage.is_file() or stage.is_symlink():
                raise CleanupRefused("Owned staging file is missing or unsafe")
            # Only this disposable child's in-memory preferences are changed.
            # The reserved empty leaf must not produce an unowned .blend1.
            bpy.context.preferences.filepaths.save_version = 0
            saved = bpy.ops.wm.save_as_mainfile(filepath=str(stage), check_existing=False, relative_remap=True)
            if saved != {"FINISHED"} or stage.stat().st_size == 0:
                raise CleanupRefused("Staging save did not finish; copy discarded")
    except Exception as exc:
        result = {**plan, "state": "FAILED_COPY_DISCARDED", "actual_removals": [], "failures": [str(exc)]}
    (work / "result.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")


if __name__ == "__main__":
    _worker()
