# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import bpy
from bpy.props import IntProperty,StringProperty
from .interface import clean,language,notify,text
from . import transactions

def failure(operator,context,exc):
    message=str(exc)
    operator.report({'WARNING'},message)
    notify(context,message)
    return {'CANCELLED'}

class SMARTTOOLS_OT_release_cleanup(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup'
    bl_label='Release Cleanup'
    request_path:StringProperty(name='Preservation contract (optional)',subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    output_path:StringProperty(name='New copy',subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    result_path:StringProperty(name='Result JSON',subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    page:IntProperty(name='Target page',default=0,min=0,options={'SKIP_SAVE'})
    def invoke(self,context,event):
        if bpy.data.filepath:
            src=Path(bpy.data.filepath)
            self.output_path='//'+src.stem+'_release.blend'
            self.result_path='//'+src.stem+'_inspection.json'
        return context.window_manager.invoke_props_dialog(self,width=610,title=text(context,'Prepare a delivery copy','引き渡し用のコピーを作る'))
    def draw(self,context):
        layout=self.layout
        header=layout.row()
        header.label(text=text(context,'Inspect the saved file','保存済みファイルを点検'))
        header.operator('smart_tools.release_cleanup_help',text='',icon='QUESTION')
        layout.prop(self,'request_path',text=text(context,'Preservation file','保持指定ファイル'))
        layout.operator('smart_tools.release_cleanup_inspect',text=text(context,'Inspect','点検')).request_path=self.request_path
        if not clean.inspection:return
        for item in clean.inspection['blockers'][:5]:
            layout.label(text=item['code']+' '+item['detail'],icon='ERROR')
        rows=sorted(clean.inspection['rows'],key=lambda r:(r['status']!='CANDIDATE',r['name'].casefold(),r['kind']))
        count=len(clean.inspection['candidates'])
        chosen=len(clean.selected)
        layout.label(text=text(context,f'{count} candidates, {chosen} selected',f'除去候補 {count} 件・選択 {chosen} 件'))
        page=min(self.page,max(0,(len(rows)-1)//8))
        if len(rows)>8:layout.prop(self,'page',text=text(context,'Page (from 0)','ページ（0から）'))
        for item in rows[page*8:page*8+8]:
            row=layout.row()
            if item['status']=='CANDIDATE':
                row.operator('smart_tools.release_cleanup_select',text=item['name']+' · '+item['kind'],
                             icon='CHECKBOX_HLT' if item['id'] in clean.selected else 'CHECKBOX_DEHLT').key=item['id']
            else:
                row.label(text=item['name']+' · '+item['kind'],icon='LOCKED')
        layout.prop(self,'output_path',text=text(context,'Save separate copy','コピーの保存先'))
        row=layout.row()
        row.enabled=bool(clean.selected and not clean.inspection['blockers'])
        row.operator('smart_tools.release_cleanup_apply',text=text(context,'Apply to Copy','コピーに適用')).output_path=self.output_path
        layout.prop(self,'result_path',text=text(context,'Result file','結果ファイル'))
        layout.operator('smart_tools.release_cleanup_export',text=text(context,'Export Result','結果を書き出す')).result_path=self.result_path
    def execute(self,context):return {'FINISHED'}

class SMARTTOOLS_OT_release_cleanup_inspect(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup_inspect'
    bl_label='Inspect'
    request_path:StringProperty(subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    def execute(self,context):
        try:
            candidates,blockers=clean.inspect(self.request_path)
            notify(context,text(context,f'{candidates} candidates, {blockers} blockers',f'候補 {candidates} 件、阻害 {blockers} 件'))
        except (ValueError,OSError,RuntimeError,TypeError) as exc:return failure(self,context,exc)
        return {'FINISHED'}

class SMARTTOOLS_OT_release_cleanup_select(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup_select'
    bl_label='Toggle cleanup target'
    key:StringProperty(options={'SKIP_SAVE'})
    def execute(self,context):
        try:clean.toggle(self.key)
        except ValueError as exc:return failure(self,context,exc)
        return {'FINISHED'}

class SMARTTOOLS_OT_release_cleanup_apply(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup_apply'
    bl_label='Apply to Copy'
    output_path:StringProperty(subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    def invoke(self,context,event):return context.window_manager.invoke_confirm(self,event)
    def execute(self,context):
        try:
            result=clean.apply(self.output_path,language(context))
            count=len(result['actual_removals'])
            notify(context,text(context,f'New copy saved. Removed {count}.',f'コピーを保存しました。除いたデータは {count} 件です。'))
        except (ValueError,OSError,RuntimeError) as exc:return failure(self,context,exc)
        return {'FINISHED'}

class SMARTTOOLS_OT_release_cleanup_export(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup_export'
    bl_label='Export Result'
    result_path:StringProperty(subtype='FILE_PATH',options={'SKIP_SAVE','PATH_SUPPORTS_BLEND_RELATIVE'})
    def execute(self,context):
        if not clean.result or not self.result_path:return {'CANCELLED'}
        try:transactions.export_result(clean.result,Path(bpy.path.abspath(self.result_path)),language=language(context))
        except (ValueError,OSError) as exc:return failure(self,context,exc)
        return {'FINISHED'}

class SMARTTOOLS_OT_release_cleanup_help(bpy.types.Operator):
    bl_idname='smart_tools.release_cleanup_help'
    bl_label='Release Cleanup Help'
    def invoke(self,context,event):return context.window_manager.invoke_popup(self,width=560)
    def draw(self,context):
        for en,ja in [('Save the original first. Inspect it to see protected and working data.','原本を保存して点検すると、保護する物と取り除ける作業用データが表示されます。'),
                      ('Select each working object and its unused data explicitly.','除きたい作業用の物と、それ専用のメッシュなどを個別に選んでください。'),
                      ('Use a new filename. Read the result beside the new copy.','新しい名前でコピーを保存し、隣にできる整理結果を確認してください。'),
                      ('If links are missing, restore them in the source and inspect again.','リンクが見つからない時は原本で直し、もう一度点検してください。')]:
            self.layout.label(text=text(context,en,ja))
    def execute(self,context):return {'FINISHED'}
