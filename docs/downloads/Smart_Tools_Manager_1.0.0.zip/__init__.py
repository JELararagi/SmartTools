# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Tools Manager for Blender 5.1."""
bl_info={'name':'Smart Tools Manager','author':'JELararagi','version':(1,0,0),'blender':(5,1,0),'category':'Interface'}
__version__='1.0.0'

import bpy
from bpy.app.handlers import persistent
from . import manager, interface, cleanup_ui, native_filters, runtime_endpoint
from .matrix_service import MatrixService

PROPERTIES=(interface.SmartToolsRuntimeMessageLine,interface.SmartToolsManagerProperties)
CONTROLS=(interface.SMARTTOOLS_UL_runtime_messages,interface.SmartToolsManagerPreferences,
          interface.SMARTTOOLS_OT_select_workspace,interface.SMARTTOOLS_OT_select_editor,interface.SMARTTOOLS_OT_set_all_tools,
          interface.SMARTTOOLS_OT_manager_help,interface.SMARTTOOLS_OT_refresh_manager,interface.SMARTTOOLS_OT_reload_manager,
          interface.SMARTTOOLS_OT_open_manager,interface.SMARTTOOLS_OT_open_runtime_messages,interface.SMARTTOOLS_OT_copy_runtime_messages,
          cleanup_ui.SMARTTOOLS_OT_release_cleanup,cleanup_ui.SMARTTOOLS_OT_release_cleanup_inspect,cleanup_ui.SMARTTOOLS_OT_release_cleanup_select,
          cleanup_ui.SMARTTOOLS_OT_release_cleanup_apply,cleanup_ui.SMARTTOOLS_OT_release_cleanup_export,cleanup_ui.SMARTTOOLS_OT_release_cleanup_help)
completed=[]
installed_hooks=[]
hooked_ui=[]
message_owner=object()
subscribed=False

def context_changed():
    if manager.service.model.document['switches']['source_filter']:
        native_filters.apply_owners(bpy.context)
    interface.refresh_windows(bpy.context)

def synchronize_hooks():
    global subscribed
    options=manager.service.model.document['switches']
    header=(bpy.types.TOPBAR_HT_upper_bar,interface.redraw_header)
    if options['topbar'] and header not in hooked_ui:
        header[0].append(header[1])
        hooked_ui.append(header)
    elif not options['topbar'] and header in hooked_ui:
        header[0].remove(header[1])
        hooked_ui.remove(header)
    for collection in (bpy.app.handlers.undo_post,bpy.app.handlers.redo_post):
        if options['undo_redo_sync'] and after_history not in collection:
            collection.append(after_history)
            installed_hooks.append((collection,after_history))
        elif not options['undo_redo_sync'] and after_history in collection:
            collection.remove(after_history)
            installed_hooks[:]=[(c,cb) for c,cb in installed_hooks if not (c is collection and cb is after_history)]
    if options['auto_sync'] and not subscribed:
        for key in ((bpy.types.Window,'workspace'),(bpy.types.Area,'type'),(bpy.types.Area,'ui_type')):
            bpy.msgbus.subscribe_rna(key=key,owner=message_owner,args=(),notify=context_changed)
        subscribed=True
    elif subscribed and not options['auto_sync']:
        bpy.msgbus.clear_by_owner(message_owner)
        subscribed=False


@persistent
def after_load(_):
    global subscribed
    bpy.msgbus.clear_by_owner(message_owner)
    subscribed=False
    interface.clean.reset()
    native_filters.leases.clear()
    service=manager.service
    if service.model.document['switches']['restore_after_load']:
        service.load(bpy.utils.user_resource('CONFIG'))
    interface.synchronize(bpy.context)
    if service.model.document['switches']['source_filter']:
        native_filters.apply_owners(bpy.context)

@persistent
def after_history(*_):
    if manager.service.model.document['switches']['undo_redo_sync']:
        interface.synchronize(bpy.context)

def startup():
    interface.synchronize(bpy.context)
    if manager.service.model.document['switches']['source_filter']:
        native_filters.apply_owners(bpy.context)
    return None

def register():
    if completed:return
    manager.service.on_commit=runtime_endpoint.update
    try:
        for cls in PROPERTIES:
            bpy.utils.register_class(cls);completed.append(cls)
        bpy.types.WindowManager.smart_tools_manager=bpy.props.PointerProperty(type=interface.SmartToolsManagerProperties)
        for cls in CONTROLS:
            bpy.utils.register_class(cls);completed.append(cls)
        for owner,callback in ((bpy.types.TOPBAR_MT_window,interface.draw_menu),):
            owner.append(callback);hooked_ui.append((owner,callback))
        for handler,callback in ((bpy.app.handlers.load_post,after_load),):
            handler.append(callback);installed_hooks.append((handler,callback))
        # File access only uses the selected Blender config. UI hydration runs after
        # Blender releases its registration-only context on startup.
        manager.service.load(bpy.utils.user_resource('CONFIG'))
        bpy.app.timers.register(startup,first_interval=0.0)
    except Exception:
        unregister()
        raise

def unregister():
    global subscribed
    bpy.msgbus.clear_by_owner(message_owner)
    subscribed=False
    runtime_endpoint.detach()
    manager.service.on_commit=None
    if bpy.app.timers.is_registered(startup):bpy.app.timers.unregister(startup)
    while installed_hooks:
        handler,callback=installed_hooks.pop()
        if callback in handler:handler.remove(callback)
    while hooked_ui:
        owner,callback=hooked_ui.pop();owner.remove(callback)
    if native_filters.leases:native_filters.restore_owners()
    interface.clean.reset()
    while completed and completed[-1] not in PROPERTIES:bpy.utils.unregister_class(completed.pop())
    if completed and hasattr(bpy.types.WindowManager,'smart_tools_manager'):del bpy.types.WindowManager.smart_tools_manager
    while completed:bpy.utils.unregister_class(completed.pop())
    manager.service=MatrixService()
