# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "Smart Tools Manager",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Preferences > Add-ons; optional Top Bar > Smart Tools",
    "description": "Workspace and logical-editor placement manager for Smart Tool add-ons.",
    "category": "System",
}

__addon_enabled__ = False

# Other suites may import this package before Blender enables it. Blender reads
# this timestamp when it enables the add-on; matching it avoids a second load.
import os as _os

__time__ = _os.path.getmtime(__file__)

from . import manager

# Stable read-only integration surface for native Smart Tool Suite Panels.
placement_allowed = manager.placement_allowed
panel_rule_allows_context = manager.panel_rule_allows_context
workspace_tool_allowed = manager.workspace_tool_allowed
get_placement_state = manager.get_placement_state
get_rule_matrix_snapshot = manager.get_rule_matrix_snapshot
get_rule_matrix_state = manager.get_rule_matrix_state
get_catalog_snapshot = manager.get_catalog_snapshot
get_current_cell_rule = manager.get_current_cell_rule
apply_rule_matrix = manager.apply_rule_matrix
subscribe_rule_matrix_commits = manager.subscribe_rule_matrix_commits
unsubscribe_rule_matrix_commits = manager.unsubscribe_rule_matrix_commits
get_placement_contract = manager.get_placement_contract
logical_editor_key_from_context = manager.logical_editor_key_from_context
notify_panel_sources_changed = manager.notify_panel_sources_changed
_panel_allowed_for_context = manager._panel_allowed_for_context


def register():
    global __addon_enabled__
    manager.register()
    __addon_enabled__ = True


def unregister():
    global __addon_enabled__
    try:
        manager.unregister()
    finally:
        manager.release_cleanup._PLAN = None
        manager.release_cleanup._LAST_EXECUTION = None
        manager.release_cleanup._STATUS = ("Ready", "準備完了")
        manager.release_cleanup.reset_selection()
        __addon_enabled__ = False
