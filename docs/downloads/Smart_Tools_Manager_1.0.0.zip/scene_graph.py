# SPDX-License-Identifier: GPL-3.0-or-later
"""Read saved Blender data without changing the scene or executing its scripts."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import bpy

from .cleanup import InputIdentity, Node, Reference, ReferenceGraph, digest
from .transactions import file_sha256


def id_key(block):
    kind = block.bl_rna.identifier
    if isinstance(block, bpy.types.Object):
        kind = 'Object'
    elif isinstance(block, bpy.types.NodeTree):
        kind = 'NodeTree'
    lib = block.library
    # A linked ID's owner distinguishes same-named datablocks from different libraries.
    return f'{kind}:{block.name}:' + (absolute(lib.filepath, lib.parent) if lib else '')


def absolute(value, library=None):
    return str(Path(bpy.path.abspath(value, library=library)).resolve())


def plain(value):
    if isinstance(value, bpy.types.ID):
        return id_key(value)
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    if hasattr(value, 'items'):
        return {str(k):plain(v) for k,v in value.items()}
    if hasattr(value, '__iter__'):
        return [plain(v) for v in value]
    return type(value).__name__


def scalar_fields(item):
    data = {}
    for p in item.bl_rna.properties:
        if p.identifier in ('rna_type','name','type') or p.is_runtime or p.is_readonly:
            continue
        if p.type in ('FLOAT','INT','BOOLEAN','ENUM','STRING','POINTER'):
            v = getattr(item, p.identifier)
            if p.type != 'POINTER' or isinstance(v, bpy.types.ID):
                data[p.identifier] = sorted(v) if isinstance(v, set) else plain(v)
    return data


def sequence_hash(items):
    """Hash one record at a time so large meshes do not create another full mesh in RAM."""
    result = sha256()
    for item in items:
        data = json.dumps(item,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')
        result.update(data)
        result.update(b'\n')
    return result.hexdigest()

def action_curves(block):
    for layer in block.layers:
        for strip in layer.strips:
            for bag in strip.channelbags:
                for curve in bag.fcurves:
                    points=sequence_hash((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),
                                          p.handle_left_type,p.handle_right_type,p.interpolation,p.easing,
                                          p.back,p.amplitude,p.period) for p in curve.keyframe_points)
                    sampled=sequence_hash(tuple(p.co) for p in curve.sampled_points)
                    yield (layer.name,bag.slot_handle,curve.data_path,curve.array_index,curve.extrapolation,
                           curve.mute,points,sampled,[(m.type,scalar_fields(m)) for m in curve.modifiers])

def saved_ui():
    views={}
    for screen in bpy.data.screens:
        if screen.is_temporary:
            continue
        areas=[]
        for area in screen.areas:
            space=area.spaces.active
            details=[area.type,area.ui_type]
            if area.type=='VIEW_3D':
                details.extend((space.shading.type,space.shading.color_type))
            areas.append(details)
        views[screen.name]=sorted(areas)
    return {'layouts':sorted(w.name for w in bpy.data.workspaces),'views':views}


def fingerprint(block):
    """Evidence for explicitly protected artist data in addition to the ID graph."""
    fields = {'properties':plain(dict(block.items())) if hasattr(block, 'items') else {}}
    if isinstance(block, bpy.types.Mesh):
        fields['vertices'] = sequence_hash((tuple(v.co),[(g.group,g.weight) for g in v.groups]) for v in block.vertices)
        fields['edges'] = sequence_hash(tuple(e.vertices) for e in block.edges)
        fields['faces'] = sequence_hash((tuple(p.vertices),p.material_index,p.use_smooth) for p in block.polygons)
        fields['uv'] = [(layer.name,sequence_hash(tuple(uv.vector) for uv in layer.uv)) for layer in block.uv_layers]
    elif isinstance(block, bpy.types.Object):
        fields.update(transform=[list(row) for row in block.matrix_basis],
                      groups=[g.name for g in block.vertex_groups],
                      modifiers=[(m.name,m.type,scalar_fields(m)) for m in block.modifiers],
                      constraints=[(c.name,c.type,scalar_fields(c)) for c in block.constraints])
        if block.pose:
            fields['pose']=[(b.name,[list(row) for row in b.matrix_basis]) for b in block.pose.bones]
    elif isinstance(block, bpy.types.Scene):
        fields['saved_ui']=saved_ui()
    elif isinstance(block, bpy.types.Armature):
        fields['bones']=[(b.name,tuple(b.head_local),tuple(b.tail_local),b.use_deform) for b in block.bones]
    elif isinstance(block, bpy.types.Key):
        fields['keys']=[(k.name,k.value,sequence_hash(tuple(p.co) for p in k.data)) for k in block.key_blocks]
    elif isinstance(block, bpy.types.Action):
        fields['curves']=sequence_hash(action_curves(block))
    elif isinstance(block,bpy.types.Curve):
        fields['splines']=[(sp.type,sp.use_cyclic_u,
            sequence_hash((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),p.tilt,p.radius) for p in sp.bezier_points),
            sequence_hash((tuple(p.co),p.tilt,p.radius) for p in sp.points)) for sp in block.splines]
        fields['materials']=[id_key(m) if m else None for m in block.materials]
    elif isinstance(block, bpy.types.Text):
        fields['text']=block.as_string()
    elif isinstance(block, bpy.types.Image):
        fields['path'] = absolute(block.filepath,block.library) if block.filepath else ''
        fields['source'] = block.source
        fields['packed'] = [sha256(x.packed_file.data).hexdigest() for x in block.packed_files if x.packed_file]
    elif isinstance(block, bpy.types.Material):
        fields['color']=tuple(block.diffuse_color)
    tree = block if isinstance(block,bpy.types.NodeTree) else getattr(block,'node_tree',None)
    if tree:
        fields['nodes']=[(n.name,n.bl_idname,[(s.identifier,plain(s.default_value)) for s in n.inputs if hasattr(s,'default_value')]) for n in tree.nodes]
        fields['links']=[(l.from_node.name,l.from_socket.identifier,l.to_node.name,l.to_socket.identifier) for l in tree.links]
    return digest(fields)


def scene_graph(filename, *, dirty=False):
    path=Path(filename)
    source=InputIdentity(str(path.resolve()),file_sha256(path),path.stat().st_size,True,dirty)
    users=bpy.data.user_map()
    ids=set(users)
    for owners in users.values():
        ids.update(owners)
    # Screens and workspaces are saved, but their transient view state must not
    # be interpreted as permission to remove a selected datablock.
    ids={x for x in ids if not getattr(x,'is_embedded_data',False)
         and x.bl_rna.identifier not in {'WindowManager','Screen','WorkSpace'} and not x.is_runtime_data
         and not (isinstance(x,bpy.types.Image) and x.source=='VIEWER')}
    key={b:id_key(b) for b in ids}
    hidden={o for o in ids if isinstance(o,bpy.types.Object) and o.hide_render and o.hide_viewport}
    names=defaultdict(list)
    for b in ids:
        names[b.name].append(b)
    refs=set()
    def ref(a,b,family,detail,membership=False):
        if a in key and b in key and a != b:
            refs.add(Reference(key[a],key[b],family,detail,membership))
    for target in ids:
        for owner in users.get(target,()):
            if owner not in ids:
                continue
            membership=(isinstance(owner,(bpy.types.Collection,bpy.types.Scene))
                        and isinstance(target,(bpy.types.Object,bpy.types.Collection)))
            ref(owner,target,'id_dependency','datablock membership' if membership else 'datablock user',membership)
    missing=set()
    dynamic=set()
    def named_targets(value):
        if isinstance(value,str):
            yield from names.get(value,())
        elif isinstance(value,bpy.types.ID):
            if value in key:yield value
        elif hasattr(value,'items'):
            for _,item in value.items():yield from named_targets(item)
        elif isinstance(value,(list,tuple)):
            for item in value:yield from named_targets(item)

    def strings(owner,value,family):
        for target in named_targets(value):
            ref(owner,target,family,'stored ID or name')

    # A Screen and a WorkSpace are roots in the saved file. They are never
    # editable cleanup rows, but their pins, custom names and ID pointers matter.
    ui_roots=set(bpy.data.workspaces) | {screen for screen in bpy.data.screens if not screen.is_temporary}
    ui_protected=defaultdict(set)
    for target in ids:
        for owner in ui_roots.intersection(users.get(target,())):
            ui_protected[target].add('SAVED_UI:'+owner.name)
    for owner in ui_roots:
        for field,value in owner.items():
            for target in named_targets(value):
                ui_protected[target].add('SAVED_UI:'+owner.name+'/'+field)
    for screen in bpy.data.screens:
        if screen.is_temporary:continue
        for area in screen.areas:
            for space in area.spaces:
                if space.type=='PROPERTIES' and space.use_pin_id:
                    pinned=space.pin_id
                    if pinned in key:ui_protected[pinned].add('SAVED_PIN:'+screen.name)
    covered={'ui_name','id_dependency'}
    nodes=[]
    for block in sorted(ids,key=lambda b:key[b]):
        kind=block.bl_rna.identifier.upper()
        if isinstance(block,bpy.types.Object):kind='OBJECT'
        if isinstance(block,bpy.types.NodeTree):kind='NODETREE'
        owners={o for o in users.get(block,()) if o in ids}
        working=block in hidden or bool(owners and owners <= hidden)
        try:
            explicit_work=bool(block.get('smart_tools_working_data', False))
        except TypeError:
            explicit_work=False
        if explicit_work:working=True
        visible=isinstance(block,bpy.types.Object) and block not in hidden
        if getattr(block,'library',None):ref(block,block.library,'library_link','owner library')
        if isinstance(block,bpy.types.Library):
            if not Path(absolute(block.filepath,block.parent)).is_file():missing.add(block.filepath)
        if isinstance(block,bpy.types.Image) and block.source in {'FILE','MOVIE','TILED','SEQUENCE'} and not block.packed_file:
            fp=block.filepath
            if fp:
                if block.source=='TILED':
                    for tile in block.tiles:
                        target=fp.replace('<UDIM>',str(tile.number)).replace('<UVTILE>',f'u{(tile.number-1001)%10+1}_v{(tile.number-1001)//10+1}')
                        if not Path(absolute(target,block.library)).is_file():missing.add(target)
                elif not Path(absolute(fp,block.library)).is_file():missing.add(fp)
        if isinstance(block,bpy.types.Text):
            content=block.as_string()
            if content and (block.name.lower().endswith('.py') or block.use_module):
                dynamic.add(key[block])
            else:
                for name in names:
                    if name and name in content:
                        for target in names[name]:ref(block,target,'script_name','text reference')
        for k in block.keys() if hasattr(block,'keys') else ():
            try:strings(block,block[k],'smarttools_name' if 'smart' in k.lower() else 'custom_property')
            except TypeError:continue
        anim=getattr(block,'animation_data',None)
        if anim:
            ref(block,anim.action,'action_curve','active action')
            for t in anim.nla_tracks:
                for strip in t.strips:ref(block,getattr(strip,'action',None),'action_nla',t.name)
            for curve in anim.drivers:
                if curve.driver.type=='SCRIPTED' and not curve.driver.is_simple_expression:
                    dynamic.add(key[block]+' '+curve.data_path)
                for variable in curve.driver.variables:
                    for target in variable.targets:
                        ref(block,target.id,'shape_key_driver' if isinstance(block,bpy.types.Key) else 'driver_target',curve.data_path)
        if isinstance(block,bpy.types.Object):
            ref(block,block.instance_collection,'collection_instance','instanced collection')
            for m in block.modifiers:
                for p in m.bl_rna.properties:
                    if p.identifier=='rna_type':continue
                    if p.type=='POINTER':
                        v=getattr(m,p.identifier)
                        if isinstance(v,bpy.types.ID):ref(block,v,'modifier',m.name)
                    elif p.type=='STRING' and 'group' in p.identifier:
                        strings(block,getattr(m,p.identifier),'physics_group')
            constraints=list(block.constraints)
            if block.pose:constraints.extend(c for b in block.pose.bones for c in b.constraints)
            for c in constraints:
                for prop in c.bl_rna.properties:
                    if prop.type=='POINTER' and prop.identifier!='rna_type':
                        val=getattr(c,prop.identifier)
                        if isinstance(val,bpy.types.ID):ref(block,val,'constraint',c.name)
            # Groups are fingerprinted with the weights and never removed as orphans.
            for group in block.vertex_groups:strings(block,group.name,'deform_group')
        tree=block if isinstance(block,bpy.types.NodeTree) else getattr(block,'node_tree',None)
        if tree:
            for node in tree.nodes:
                for prop in node.bl_rna.properties:
                    if prop.type=='POINTER' and prop.identifier!='rna_type':
                        value=getattr(node,prop.identifier)
                        if isinstance(value,bpy.types.ID):
                            ref(block,value,'material_node',node.name)
                for socket in node.inputs:
                    value=getattr(socket,'default_value',None)
                    if isinstance(value,bpy.types.ID):ref(block,value,'material_node',node.name+'/'+socket.identifier)
        reasons=tuple(sorted(ui_protected.get(block,())))
        if isinstance(block,bpy.types.Scene):reasons+=('SCENE',)
        if isinstance(block,bpy.types.Image):kind='IMAGE'
        nodes.append(Node(key[block],kind,block.name,working=working,release_root=visible,
                          fake_user=block.use_fake_user,linked=block.library is not None,
                          external_texture=kind=='IMAGE',content_sha256=fingerprint(block),protected_reasons=reasons))
    # Only report the collectors this implementation actually runs. New reference
    # kinds added to the planning contract must add a collector here first.
    covered.update(('modifier','constraint','driver_target','deform_group','physics_group',
                    'shape_key_driver','action_curve','action_nla','material_node','collection_instance',
                    'library_link','texture','custom_property','smarttools_name','script_name'))
    return ReferenceGraph(source,tuple(nodes),tuple(sorted(refs,key=lambda r:(r.source,r.target,r.family,r.detail))),
                          tuple(sorted(covered)),tuple(sorted(missing)),tuple(sorted(dynamic)))
