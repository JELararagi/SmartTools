# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Owner-filter proposals. Applying proposals is an explicit host operation.

No add-on is imported, enabled, disabled, registered or removed here. Existing
user exclusions and non-SmartTools integrations are retained.
"""
from dataclasses import dataclass
from .registry import canonical_suite

@dataclass(frozen=True)
class FilterView:
    enabled: bool
    owners: frozenset

    def __post_init__(self):
        if type(self.enabled) is not bool or not isinstance(self.owners,frozenset):
            raise TypeError('FilterView requires a boolean and a frozenset.')
        if any(not isinstance(v,str) or not v for v in self.owners):
            raise TypeError('Owner identifiers must be nonempty strings.')


class FilterLease:
    """Record only this manager's edits and respect later user edits.

    A pre-existing owner filter does not receive newly enabled external add-ons.
    If filtering was initially off, external add-ons are initially included and
    subsequently enabled external add-ons are included unless manually excluded.
    """
    def __init__(self, baseline):
        self.baseline = baseline
        self.last = None
        self.original_membership = {}
        self.manual_membership = set()
        self.manual_exclusions = set()
        self.closed = False

    def _observe(self, current):
        if self.last is not None:
            changed = set(current.owners) ^ set(self.last.owners)
            self.manual_membership.update(changed)
            self.manual_exclusions.update(set(self.last.owners)-set(current.owners))
            self.manual_exclusions.difference_update(set(current.owners)-set(self.last.owners))

    def propose(self, current, installed_owners, managed_allowed, manager_owner):
        if self.closed:
            raise RuntimeError('A closed filter lease cannot be reused.')
        installed = set(installed_owners)
        if any(not isinstance(v,str) or not v for v in installed):
            raise ValueError('Invalid installed owner identifier.')
        if not isinstance(manager_owner,str) or not manager_owner:
            raise ValueError('The manager owner must be explicit.')
        if any(canonical_suite(k) is None or type(v) is not bool for k,v in managed_allowed.items()):
            raise ValueError('Only recognized SmartTools owners may be controlled.')
        self._observe(current)
        desired = set(current.owners)
        controlled = set(managed_allowed) | {manager_owner}
        if not self.baseline.enabled:
            desired.update(installed-controlled-self.manual_exclusions)
        desired.difference_update(controlled)
        desired.update(k for k,v in managed_allowed.items()
                       if v and k in installed and k not in self.manual_exclusions)
        if manager_owner not in self.manual_exclusions:
            desired.add(manager_owner)
        changed = desired ^ set(current.owners)
        for owner in changed:
            self.original_membership.setdefault(owner,owner in current.owners)
        result = FilterView(True,frozenset(desired))
        self.last = result
        return result

    def restore(self, current):
        if self.closed:
            return current
        self._observe(current)
        desired = set(current.owners)
        for owner, was_present in self.original_membership.items():
            if owner in self.manual_membership:
                continue
            if was_present:
                desired.add(owner)
            else:
                desired.discard(owner)
        # An independently disabled native filter is never re-enabled on release.
        enabled = self.baseline.enabled if current.enabled else False
        self.closed = True
        return FilterView(enabled,frozenset(desired))


def managed_owner_rules(state, workspace, installed_owners):
    return {owner:state.workspace_allowed(suite,workspace)
            for owner in installed_owners
            for suite in (canonical_suite(owner),) if suite is not None}
