# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Pure placement rules. No Blender imports, filesystem access or draw mutation."""
from copy import deepcopy
from .registry import (TOOL_KEYS, WORKSPACE_KEYS, EDITOR_KEYS,
                       CATALOG_SHA256, DEFAULT_SWITCHES)

SCHEMA = 'jel-smart-tools-manager-settings/1'


class InvalidSettings(ValueError):
    pass


def new_document():
    return {
        'schema':SCHEMA, 'catalog_sha256':CATALOG_SHA256,
        'switches':dict(DEFAULT_SWITCHES),
        'selection':{'workspace':'Layout', 'editor':'VIEW_3D'},
        'cells':[],
    }


def validate_document(value):
    if not isinstance(value, dict) or set(value) != {'schema','catalog_sha256','switches','selection','cells'}:
        raise InvalidSettings('Unrecognized settings structure; existing data is not migrated implicitly.')
    if value['schema'] != SCHEMA or value['catalog_sha256'] != CATALOG_SHA256:
        raise InvalidSettings('Unknown or stale settings schema/catalog.')
    switches = value['switches']
    if isinstance(switches,dict) and set(switches)==set(DEFAULT_SWITCHES)-{'show_runtime_options'}:
        value = deepcopy(value)
        switches = value['switches']
        switches['show_runtime_options'] = False
    if not isinstance(switches, dict) or set(switches) != set(DEFAULT_SWITCHES):
        raise InvalidSettings('Missing or unknown resident switch.')
    if any(type(v) is not bool for v in switches.values()):
        raise InvalidSettings('Resident switches require JSON booleans.')
    selection = value['selection']
    if not isinstance(selection, dict) or set(selection) != {'workspace','editor'}:
        raise InvalidSettings('Invalid selected cell.')
    if selection['workspace'] not in WORKSPACE_KEYS or selection['editor'] not in EDITOR_KEYS:
        raise InvalidSettings('Unknown selected workspace/editor.')
    cells = value['cells']
    if not isinstance(cells, list) or len(cells) > len(TOOL_KEYS)*len(WORKSPACE_KEYS)*len(EDITOR_KEYS):
        raise InvalidSettings('Invalid placement cell list.')
    seen = set()
    for cell in cells:
        if not isinstance(cell, dict) or set(cell) != {'workspace','editor','suite','enabled'}:
            raise InvalidSettings('Invalid placement cell.')
        if (cell['workspace'] not in WORKSPACE_KEYS or cell['editor'] not in EDITOR_KEYS
                or cell['suite'] not in TOOL_KEYS or type(cell['enabled']) is not bool):
            raise InvalidSettings('Invalid placement key or boolean.')
        key = (cell['workspace'],cell['editor'],cell['suite'])
        if key in seen:
            raise InvalidSettings('Duplicate placement cell.')
        seen.add(key)
    return deepcopy(value)


class PlacementState:
    """Snapshot validated once on ingestion; polling is O(1), without I/O."""
    def __init__(self, document=None, *, available=True):
        self.available = False
        self.document = new_document()
        self._cells = {}
        self.reason = 'unavailable'
        if available:
            self.replace(new_document() if document is None else document)

    def replace(self, document):
        try:
            checked = validate_document(document)
        except (InvalidSettings, TypeError, KeyError, ValueError) as exc:
            self.available = False
            self.reason = str(exc)
            self._cells = {}
            return False
        self.document = checked
        self._cells = {(c['workspace'],c['editor'],c['suite']):c['enabled'] for c in checked['cells']}
        self.available = True
        self.reason = ''
        return True

    def export(self):
        return deepcopy(self.document)

    def allowed(self, suite, workspace, editor, *, suite_enabled=True):
        if not suite_enabled:
            return False
        if not self.available:
            return True
        if suite not in TOOL_KEYS or workspace not in WORKSPACE_KEYS or editor not in EDITOR_KEYS:
            return True
        return self._cells.get((workspace,editor,suite), True)

    def workspace_allowed(self, suite, workspace, *, suite_enabled=True):
        if not suite_enabled:
            return False
        if not self.available or suite not in TOOL_KEYS or workspace not in WORKSPACE_KEYS:
            return True
        return any(self._cells.get((workspace,editor,suite),True) for editor in EDITOR_KEYS)

    def runtime_allowed(self, suite, workspace, *, suite_enabled=True, scope='WORKSPACE'):
        if scope == 'PROCESS_GLOBAL':
            return bool(suite_enabled)
        if scope != 'WORKSPACE':
            raise ValueError('Unknown runtime scope.')
        return self.workspace_allowed(suite,workspace,suite_enabled=suite_enabled)

    def _require_valid(self):
        if not self.available:
            raise InvalidSettings('Settings unavailable; reload valid data before editing.')

    def _write_cells(self):
        self.document['cells'] = [
            {'workspace':w,'editor':e,'suite':s,'enabled':enabled}
            for (w,e,s),enabled in sorted(self._cells.items())
        ]

    def set_cell(self, suite, workspace, editor, enabled):
        self._require_valid()
        if suite not in TOOL_KEYS or workspace not in WORKSPACE_KEYS or editor not in EDITOR_KEYS:
            raise InvalidSettings('Unknown placement cell.')
        if type(enabled) is not bool:
            raise InvalidSettings('Enabled must be a boolean.')
        self._cells[(workspace,editor,suite)] = enabled
        self._write_cells()

    def set_all(self, workspace, editor, enabled):
        self._require_valid()
        if workspace not in WORKSPACE_KEYS or editor not in EDITOR_KEYS or type(enabled) is not bool:
            raise InvalidSettings('Invalid bulk placement request.')
        for suite in TOOL_KEYS:
            self._cells[(workspace,editor,suite)] = enabled
        self._write_cells()

    def select(self, workspace, editor):
        self._require_valid()
        if workspace not in WORKSPACE_KEYS or editor not in EDITOR_KEYS:
            raise InvalidSettings('Unknown selection.')
        self.document['selection'] = {'workspace':workspace,'editor':editor}

    def set_switch(self, key, enabled):
        self._require_valid()
        if key not in DEFAULT_SWITCHES or type(enabled) is not bool:
            raise InvalidSettings('Invalid resident switch.')
        self.document['switches'][key] = enabled


def placement_allowed(state, suite, workspace, editor, *, suite_enabled=True):
    if not isinstance(state, PlacementState):
        return bool(suite_enabled)
    return state.allowed(suite,workspace,editor,suite_enabled=suite_enabled)


def workspace_tool_allowed(state, suite, workspace, *, suite_enabled=True):
    if not isinstance(state, PlacementState):
        return bool(suite_enabled)
    return state.workspace_allowed(suite,workspace,suite_enabled=suite_enabled)
