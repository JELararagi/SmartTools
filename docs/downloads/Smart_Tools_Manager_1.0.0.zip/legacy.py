# SPDX-License-Identifier: GPL-3.0-or-later
"""Round-trip the documented Manager settings, retaining fields from previous releases."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from .catalog_api import E, W, public_matrix, sparse_cells
from .placement import PlacementState, new_document, validate_document, InvalidSettings
from .storage import SettingsStore, LoadResult, _unique_keys, MAX_BYTES

NAME = 'Smart_Tools_Manager_Suite.json'
SCHEMA = 'jelararagi.smart_tools_manager.matrix'
SWITCHES = {'automatic_context_sync':'auto_sync', 'source_panel_filters':'source_filter',
            'topbar_button':'topbar', 'load_restore_handler':'restore_after_load',
            'undo_redo_handlers':'undo_redo_sync', 'runtime_api_bridge':'notify'}
RESERVED = ('runtime_panel_proxies','category_anchors','ui_callback_repair',
            'transform_guard','stale_proxy_cleanup')

def checksum(body):
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(',',':'), allow_nan=False)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def unpack(raw):
    if len(raw) > MAX_BYTES:
        raise InvalidSettings('The settings file is too large.')
    body = json.loads(raw.decode('utf-8-sig'), object_pairs_hook=_unique_keys)
    if not isinstance(body,dict) or body.get('schema') != SCHEMA or body.get('version') != 5:
        raise InvalidSettings('Unrecognized Manager settings format.')
    stamp = body.pop('checksum',None)
    if checksum(body) != stamp:
        raise InvalidSettings('The Manager settings checksum does not match.')
    if type(body.get('generation')) is not int or body['generation'] < 0:
        raise InvalidSettings('Invalid saved settings generation.')
    doc = new_document()
    doc['cells'] = sparse_cells(body['matrix'])
    choice = body['selection']
    doc['selection'] = {'workspace':W[choice['workspace']], 'editor':E[choice['editor']]}
    doc['switches']['persist'] = body['ui']['n_panel_state_save']
    doc['switches']['show_runtime_options'] = body['ui'].get('show_always_on_toggles',False)
    for public, internal in SWITCHES.items():
        doc['switches'][internal] = body['runtime'][public]
    return body, validate_document(doc)

class PublicSettingsStore(SettingsStore):
    def __init__(self, root):
        super().__init__(root)
        self.path = self.path.with_name(NAME)
        self.backup = self.path.with_suffix('.json.bak')
        self.previous_bytes = None
        self.body = {}

    def load(self):
        errors = []
        for path in (self.path,self.backup):
            if not path.exists():
                continue
            try:
                raw = self._read(path)
                self.body, doc = unpack(raw)
            except (KeyError,TypeError,ValueError,OSError,UnicodeError) as exc:
                errors.append(path.name+' '+str(exc))
                continue
            if path == self.path:
                self.previous_bytes = raw
                return LoadResult('PRIMARY',doc)
            return LoadResult('BACKUP_IN_MEMORY',doc,' '.join(errors) or 'Primary settings are missing.')
        if errors:
            return LoadResult('UNAVAILABLE',None,' '.join(errors))
        # A prerelease used a separate path. Leave that file intact on migration.
        return SettingsStore(self.root).load()

    def save(self, document):
        model = PlacementState(validate_document(document))
        switches = model.document['switches']
        body = deepcopy(self.body)
        selection = body.setdefault('selection',{'mode':'FAST'})
        sw = model.document['selection']['workspace']
        ed = model.document['selection']['editor']
        selection.update(workspace=next(k for k,v in W.items() if v==sw),
                         editor=next(k for k,v in E.items() if v==ed))
        flags = body.setdefault('runtime',{})
        for name in RESERVED:
            flags.setdefault(name,False)
        flags.update({k:switches[v] for k,v in SWITCHES.items()})
        body.setdefault('ui',{}).update(n_panel_state_save=switches['persist'],
                                        show_always_on_toggles=switches['show_runtime_options'])
        body.update(schema=SCHEMA, version=5, extension_version='1.0.0', matrix=public_matrix(model))
        with self._lock():
            existing = self._read(self.path) if self.path.exists() else None
            if existing != self.previous_bytes:
                raise InvalidSettings('The settings changed in another session. Reload before saving.')
            if body == self.body:
                return
            body['generation'] = self.body.get('generation',0)+1
            output = dict(body,checksum=checksum(body))
            raw = (json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode('utf-8')
            if len(raw)>MAX_BYTES:
                raise InvalidSettings('The settings file is too large.')
            if existing is not None:
                self._atomic_write(self.backup,existing)
            self._atomic_write(self.path,raw)
            self.previous_bytes, self.body = raw, body
