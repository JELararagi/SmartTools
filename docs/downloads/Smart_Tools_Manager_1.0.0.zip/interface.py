# SPDX-License-Identifier: GPL-3.0-or-later
"""Manager matrix, release-copy dialogs and public Blender controls."""
from contextlib import contextmanager
from pathlib import Path
import bpy
from bpy.props import BoolProperty, EnumProperty, CollectionProperty, IntProperty, StringProperty

from . import catalog_api as catalog, manager, native_filters, registry, transactions
from .clean_session import CleanupSession

clean=CleanupSession()
_sync=False
flags={'show_always_on_toggles':'show_runtime_options','n_panel_state_save':'persist','runtime_automatic_context_sync':'auto_sync',
       'runtime_source_panel_filters':'source_filter','runtime_topbar_button':'topbar',
       'runtime_load_restore_handler':'restore_after_load','runtime_undo_redo_handlers':'undo_redo_sync',
       'runtime_api_bridge':'notify'}

FLAG_LABELS = {
    'runtime_automatic_context_sync': ('Follow workspace changes','ワークスペースの切り替えに追従'),
    'runtime_source_panel_filters': ('Apply workspace filters','ワークスペースの表示条件を反映'),
    'runtime_topbar_button': ('Show top bar button','上部にボタンを表示'),
    'runtime_load_restore_handler': ('Restore after opening a file','ファイルを開いた後に配置を復元'),
    'runtime_undo_redo_handlers': ('Refresh after undo or redo','元に戻す・やり直し後に表示を更新'),
    'runtime_api_bridge': ('Share rules with other add-ons','ほかのアドオンと表示条件を共有'),
}

def language(context):
    return 'ja' if bpy.app.translations.locale.startswith('ja') else 'en'

def text(context,en,ja):
    return ja if language(context)=='ja' else en

def notify(context,message):
    manager.service.message(message)
    props=context.window_manager.smart_tools_manager
    props.runtime_message_text=message
    row=props.runtime_message_lines.add()
    row.text=message
    if len(props.runtime_message_lines)>100:props.runtime_message_lines.remove(0)

def refresh_windows(context):
    for window in getattr(getattr(context,'window_manager',None),'windows',()):
        if window.screen:
            for area in window.screen.areas:area.tag_redraw()

def synchronize(context):
    global _sync
    pg=getattr(context.window_manager,'smart_tools_manager',None)
    if pg is None:return
    prev=_sync
    _sync=True
    try:
        doc=manager.service.model.document
        sw=doc['selection']['workspace']
        ed=doc['selection']['editor']
        pg.selected_workspace=next(k for k,v in catalog.W.items() if v==sw)
        pg.selected_editor=next(k for k,v in catalog.E.items() if v==ed)
        for tool,suite in catalog.T.items():
            setattr(pg,'tool_'+tool.lower(),manager.service.model.allowed(suite,sw,ed))
        for name,flag in flags.items():setattr(pg,name,doc['switches'][flag])
    finally:_sync=prev
    from . import synchronize_hooks
    synchronize_hooks()
    refresh_windows(context)

def run_change(context, method, *args,authority):
    manager.service.change(method,*args,authority=authority)
    synchronize(context)
    pg=context.window_manager.smart_tools_manager
    if pg.runtime_source_panel_filters:
        native_filters.apply_owners(context)
    elif native_filters.leases:
        native_filters.restore_owners()

def switch_update(name):
    def update(self,context):
        if _sync:return
        try:run_change(context,'set_switch',flags[name],getattr(self,name),authority='SWITCH_UPDATE')
        except (OSError,ValueError) as exc:
            synchronize(context);notify(context,str(exc))
    return update

def tool_update(key):
    def update(self,context):
        if _sync:return
        try:run_change(context,'set_cell',catalog.T[key],catalog.W[self.selected_workspace],catalog.E[self.selected_editor],
                       getattr(self,'tool_'+key.lower()),authority='TOOL_RULE_UPDATE')
        except (OSError,ValueError,KeyError) as exc:
            synchronize(context);notify(context,str(exc))
    return update

def selection_update(self,context):
    if _sync:return
    try:
        run_change(context,'select',catalog.W[self.selected_workspace],catalog.E[self.selected_editor],authority='SELECTION_UPDATE')
    except (ValueError,OSError,KeyError) as exc:
        synchronize(context)
        notify(context,str(exc))

WORKSPACE_ITEMS=[(key,entry.en,'') for key,entry in zip(catalog.W,registry.WORKSPACES)]
EDITOR_ITEMS=[(key,entry.en,'') for key,entry in zip(catalog.E,registry.EDITORS)]

def compat_disabled(self):
    return False

class SmartToolsRuntimeMessageLine(bpy.types.PropertyGroup):
    text:StringProperty()

class SmartToolsManagerProperties(bpy.types.PropertyGroup):
    selected_workspace:EnumProperty(name='Workspace',items=WORKSPACE_ITEMS,default='LAYOUT',update=selection_update)
    selected_editor:EnumProperty(name='Editor',items=EDITOR_ITEMS,default='VIEW_3D',update=selection_update)
    runtime_message_lines:CollectionProperty(type=SmartToolsRuntimeMessageLine)
    runtime_message_index:IntProperty(min=0)
    runtime_message_text:StringProperty()

for name,flag in flags.items():
    SmartToolsManagerProperties.__annotations__[name]=BoolProperty(name=name.replace('runtime_','').replace('_',' ').title(),
        default=registry.DEFAULT_SWITCHES[flag],update=switch_update(name))
for field in ('runtime_panel_proxies','runtime_category_anchors','runtime_ui_callback_repair','runtime_transform_guard','runtime_stale_proxy_cleanup'):
    SmartToolsManagerProperties.__annotations__[field]=BoolProperty(name=field,get=compat_disabled,options={'SKIP_SAVE'})
for key in catalog.T:
    name='tool_'+key.lower()
    SmartToolsManagerProperties.__annotations__[name]=BoolProperty(name=key.replace('_',' ').title(),update=tool_update(key))

def draw_matrix(layout,context):
    pg=context.window_manager.smart_tools_manager
    top=layout.row(align=True)
    top.operator('smart_tools.manager_help',text='',icon='QUESTION')
    top.operator('smart_tools.refresh_manager',text=text(context,'Refresh','再読み込み'),icon='FILE_REFRESH')
    top.operator('smart_tools.release_cleanup',text=text(context,'Release Cleanup','引き渡し前の整理'),icon='FILE_BLEND')
    columns=layout.row(align=False)
    selectors=((registry.WORKSPACES,catalog.W,'smart_tools.select_workspace',pg.selected_workspace,'Workspace','ワークスペース'),
               (registry.EDITORS,catalog.E,'smart_tools.select_editor',pg.selected_editor,'Editor','エディター'))
    for entries,keys,operator,selected,en,ja in selectors:
        col=columns.column(align=True)
        col.label(text=text(context,en,ja))
        for key,entry in zip(keys,entries):
            button=col.operator(operator,text=registry.label(entry,language(context)),depress=key==selected)
            button.key=key
    col=columns.column(align=True)
    col.label(text=text(context,'Tools','ツール'))
    row=col.row(align=True)
    for val,en,ja in [(True,'All on','全て表示'),(False,'All off','全て隠す')]:
        row.operator('smart_tools.set_all_tools',text=text(context,en,ja)).state=val
    for key,entry in zip(catalog.T,registry.TOOLS):
        col.prop(pg,'tool_'+key.lower(),text=registry.label(entry,language(context)))
    layout.prop(pg,'n_panel_state_save',text=text(context,'Save placement','配置を保存'))
    layout.prop(pg,'show_always_on_toggles',text=text(context,'Runtime options','常時動作の設定'),toggle=True)
    if pg.show_always_on_toggles:
        for name in flags:
            if name not in ('n_panel_state_save','show_always_on_toggles'):layout.prop(pg,name,text=text(context,*FLAG_LABELS[name]))
    if pg.runtime_message_text:layout.label(text=pg.runtime_message_text)

def redraw_header(self,context):
    pg=getattr(context.window_manager,'smart_tools_manager',None)
    if pg and pg.runtime_topbar_button:self.layout.operator('smart_tools.open_manager',text='Smart Tools')

def draw_menu(self,context):
    self.layout.operator('smart_tools.open_manager',text='Smart Tools Manager')

class SmartToolsManagerPreferences(bpy.types.AddonPreferences):
    bl_idname=__package__
    def draw(self,context):
        draw_matrix(self.layout,context)

class SMARTTOOLS_UL_runtime_messages(bpy.types.UIList):
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index=0,flt_flag=0):
        layout.label(text=item.text)

class SMARTTOOLS_OT_open_manager(bpy.types.Operator):
    bl_idname='smart_tools.open_manager'
    bl_label='Smart Tools Manager'
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self,width=735,title=text(context,'Smart Tools Manager','スマートツールマネージャー'))
    def draw(self,context):draw_matrix(self.layout,context)
    def execute(self,context):return {'FINISHED'}

class SMARTTOOLS_OT_select_workspace(bpy.types.Operator):
    bl_idname='smart_tools.select_workspace'
    bl_label='Select Workspace'
    key:StringProperty(options={'SKIP_SAVE'})
    def execute(self,context):
        pg=context.window_manager.smart_tools_manager
        if self.key not in catalog.W:return {'CANCELLED'}
        run_change(context,'select',catalog.W[self.key],catalog.E[pg.selected_editor],authority='SELECTION_UPDATE')
        return {'FINISHED'}

class SMARTTOOLS_OT_select_editor(bpy.types.Operator):
    bl_idname='smart_tools.select_editor'
    bl_label='Select Editor'
    key:StringProperty(options={'SKIP_SAVE'})
    def execute(self,context):
        pg=context.window_manager.smart_tools_manager
        if self.key not in catalog.E:return {'CANCELLED'}
        run_change(context,'select',catalog.W[pg.selected_workspace],catalog.E[self.key],authority='SELECTION_UPDATE')
        return {'FINISHED'}

class SMARTTOOLS_OT_set_all_tools(bpy.types.Operator):
    bl_idname='smart_tools.set_all_tools'
    bl_label='Set All Smart Tools'
    state:BoolProperty(default=True,options={'SKIP_SAVE'})
    def execute(self,context):
        pg=context.window_manager.smart_tools_manager
        run_change(context,'set_all',catalog.W[pg.selected_workspace],catalog.E[pg.selected_editor],self.state,authority='TOOL_RULE_UPDATE')
        return {'FINISHED'}

class SMARTTOOLS_OT_refresh_manager(bpy.types.Operator):
    bl_idname='smart_tools.refresh_manager'
    bl_label='Refresh Smart Tools Manager'
    def execute(self,context):
        synchronize(context)
        if context.window_manager.smart_tools_manager.runtime_source_panel_filters:
            native_filters.apply_owners(context)
        return {'FINISHED'}

class SMARTTOOLS_OT_reload_manager(bpy.types.Operator):
    bl_idname='smart_tools.reload_manager'
    bl_label='Reload Smart Tools'
    def execute(self,context):
        if not manager.service.load(bpy.utils.user_resource('CONFIG')):
            self.report({'WARNING'}, manager.service.storage_error)
            return {'CANCELLED'}
        synchronize(context)
        return {'FINISHED'}

class SMARTTOOLS_OT_manager_help(bpy.types.Operator):
    bl_idname='smart_tools.manager_help'
    bl_label='Smart Tools Manager Help'
    def invoke(self,context,event):return context.window_manager.invoke_popup(self,width=460)
    def draw(self,context):
        for en,ja in [('Choose a workspace and an editor.','ワークスペースとエディターを順に選んでください。'),
                      ('The checkboxes affect SmartTools in that cell.','右列のチェックで、その組み合わせで表示するツールを選びます。'),
                      ('Save placement keeps the settings across sessions.','「配置を保存」で次回の起動時にも同じ配置を使えます。')]:
            self.layout.label(text=text(context,en,ja))
    def execute(self,context):return {'FINISHED'}

class SMARTTOOLS_OT_open_runtime_messages(bpy.types.Operator):
    bl_idname='smart_tools.open_runtime_messages'
    bl_label='Runtime Messages'
    message_text:StringProperty(options={'SKIP_SAVE'})
    def invoke(self,context,event):return context.window_manager.invoke_popup(self,width=500)
    def draw(self,context):
        for ln in (self.message_text or '\n'.join(manager.service.messages)).splitlines()[-16:]:
            self.layout.label(text=ln[:100])
    def execute(self,context):return {'FINISHED'}

class SMARTTOOLS_OT_copy_runtime_messages(bpy.types.Operator):
    bl_idname='smart_tools.copy_runtime_messages'
    bl_label='Copy Runtime Messages'
    def execute(self,context):
        context.window_manager.clipboard='\n'.join(manager.service.messages)
        return {'FINISHED'}
