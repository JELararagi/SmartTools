# SPDX-License-Identifier: GPL-3.0-or-later
"""Edition-independent placement model; changes are validated before installation."""
from copy import deepcopy
from hashlib import sha256
import json
from uuid import uuid4

from .catalog_api import E, T, W, SELF_POLICY, public_matrix, sparse_cells
from .placement import PlacementState, new_document
from .legacy import PublicSettingsStore


class MatrixService:
    def __init__(self):
        self.token = uuid4().hex
        self.model = PlacementState()
        self.revision = 0
        self.ready = False
        self.authority = 'NOT_READY'
        self._matrix = {}
        self.store = None
        self.storage_error = None
        self.subscribers = {}
        self.on_commit = None
        self.source_revisions = {}
        self.messages = []

    def message(self, text):
        self.messages.append(str(text))
        del self.messages[:-100]

    def load(self, config_root):
        store = PublicSettingsStore(config_root)
        self.store = store
        self.storage_error = None
        result = store.load()
        if result.document is None:
            self.storage_error = result.detail
            self.message(result.detail)
            return False
        if result.status != 'NEW':
            self.commit(result.document, 'VERIFIED_SETTINGS', write=False)
        if result.status == 'BACKUP_IN_MEMORY':
            self.storage_error = result.detail or 'Restored backup in memory. Recover the primary file before saving.'
            self.message(self.storage_error)
        return True

    def commit(self, document, authority, *, write=True, source_revision=None):
        model = PlacementState(document)
        if not model.available:
            raise ValueError(model.reason)
        matrix = public_matrix(model)
        if write and self.storage_error:
            raise ValueError(self.storage_error)
        was_persistent = self.model.document['switches']['persist']
        if write and self.store is not None and (document['switches']['persist'] or was_persistent):
            self.store.save(document)
        self.model, self._matrix = model, matrix
        self.revision += 1
        self.ready = True
        self.authority = authority
        if self.on_commit is not None:
            self.on_commit()
        event = self.commit_event(source_revision)
        for key, (callback, _) in tuple(self.subscribers.items()):
            try:
                callback(dict(event))
            except Exception as exc:
                self.message(f'{key}: {exc}')
        return self.revision

    def change(self, method, *args, authority):
        change = PlacementState(self.model.export())
        getattr(change, method)(*args)
        return self.commit(change.export(), authority)

    def snapshot(self):
        return deepcopy(self._matrix)

    def matrix_state(self):
        return dict(api_version=3, status='READY' if self.ready else 'NOT_READY', ready=self.ready,
                    authoritative=self.ready, declared_authoritative_cache=self.ready, cache_valid=True,
                    used_last_known_state=False, generation=self.revision,
                    authority_source=self.authority, matrix_cells=len(W)*len(E)*len(T) if self.ready else 0,
                    matrix=self.snapshot())

    def cell(self, workspace, editor, tool):
        enabled = self._matrix.get(workspace, {}).get(editor, {}).get(tool, True)
        return dict(status='READY' if self.ready else 'NOT_READY', generation=self.token,
                    revision=self.revision, enabled=enabled, manager_self_rule_policy=SELF_POLICY)

    def matrix_digest(self):
        data=json.dumps(self._matrix,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf8')
        return sha256(data).hexdigest()

    def commit_event(self, source_revision):
        return dict(schema='jelararagi.smart_tools_manager.rule_matrix_commit',api_revision=1,runtime_generation=self.token,
                    manager_revision=self.revision,source_id=self.authority,source_revision=source_revision,
                    matrix_sha256=self.matrix_digest(),manager_self_rule_policy=SELF_POLICY)

    def apply(self, matrix, *, source_revision, runtime_generation, expected_manager_revision, source_id):
        previous = self.revision
        def answer(ok, status, **extra):
            return dict(ok=ok, status=status, api_revision=1, runtime_generation=self.token,
                        previous_manager_revision=previous, manager_revision=self.revision,
                        source_revision=source_revision, source_id=source_id, manager_self_rule_policy=SELF_POLICY, **extra)
        if runtime_generation != self.token:
            return answer(False, 'RUNTIME_GENERATION_MISMATCH')
        if type(expected_manager_revision) is not int or expected_manager_revision != previous:
            return answer(False, 'MANAGER_REVISION_MISMATCH')
        if type(source_revision) is not int or not isinstance(source_id, str) or not source_id:
            return answer(False, 'INVALID_SOURCE_REVISION')
        try:
            cells = sparse_cells(matrix)
            if self.ready and matrix == self._matrix:
                return answer(True,'UNCHANGED',committed=False,matrix_sha256=self.matrix_digest())
            if source_revision <= self.source_revisions.get(source_id,-1):
                return answer(False,'STALE_SOURCE_REVISION')
            doc = self.model.export()
            doc['cells'] = cells
            self.commit(doc, source_id, source_revision=source_revision)
        except (ValueError, OSError) as exc:
            self.message(exc)
            return answer(False, 'INVALID_MATRIX',error=str(exc))
        self.source_revisions[source_id] = source_revision
        return answer(True,'COMMITTED',committed=True,matrix_sha256=self.matrix_digest())

    def reply(self, accepted, reason):
        return dict(ok=accepted, status=reason, manager_revision=self.revision, runtime_generation=self.token)
