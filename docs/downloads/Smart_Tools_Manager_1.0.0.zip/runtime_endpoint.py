# SPDX-License-Identifier: GPL-3.0-or-later
"""Advertise Manager's optional, generation-bound Python integration."""
import bpy

KEY='JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1'
PUBLIC=('placement_allowed','panel_rule_allows_context','workspace_tool_allowed','get_placement_state',
        'get_rule_matrix_snapshot','get_rule_matrix_state','get_catalog_snapshot','get_current_cell_rule',
        'apply_rule_matrix','subscribe_rule_matrix_commits','unsubscribe_rule_matrix_commits','get_placement_contract',
        'logical_editor_key_from_context','notify_panel_sources_changed')
owned=None

def detach():
    global owned
    namespace=bpy.app.driver_namespace
    if owned is not None and namespace.get(KEY) is owned:
        namespace.pop(KEY)
    owned=None

def update():
    global owned
    from . import manager
    service=manager.service
    if not service.ready or not service.model.document['switches']['notify']:
        detach()
        service.subscribers.clear()
        return
    namespace=bpy.app.driver_namespace
    active=namespace.get(KEY)
    if active is not None and active is not owned:
        service.message('Another Smart Tools Manager generation owns the runtime endpoint.')
        return
    if owned is None:
        owned=dict(schema=1,api_revision=1,package_id='smart_tools_manager',status='ACTIVE',
                   runtime_identity=object(),generation=service.token,manager_self_rule_policy=manager.SELF_POLICY,
                   public_api={name:getattr(manager,name) for name in PUBLIC},subscribers=service.subscribers)
    owned['revision']=service.revision
    namespace[KEY]=owned
