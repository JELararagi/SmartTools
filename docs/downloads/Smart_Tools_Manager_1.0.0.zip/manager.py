# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later

"""Smart Tools Manager.

A workspace/editor placement manager for the 21 JELararagi Smart Tool suites.

Stability contract for Blender 5.1:
- the Manager never rewrites third-party Panel attributes;
- the Manager never enables, disables, registers, unregisters, or reloads a Suite;
- the Manager owns no proxy or category-anchor Panels;
- native Suite Panels query a read-only, fail-open placement API;
- one explicit 16 x 17 x 21 boolean matrix is the sole routing authority;
- settings changes are persisted atomically with checksum and backup recovery;
- no periodic background service, recursive Panel scan, manifest scan, or file-stat poll is used.
"""

from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import tempfile
import textwrap
import time
import traceback
import uuid
from contextlib import contextmanager
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, CollectionProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList
from . import release_cleanup

ADDON_ID = "smart_tools_manager"
ADDON_NAME = "Smart Tools Manager"
VERSION = (1, 5, 85)
VERSION_TEXT = ".".join(str(part) for part in VERSION)

SETTINGS_SCHEMA = "jelararagi.smart_tools_manager.matrix"
SETTINGS_SCHEMA_VERSION = 5
SETTINGS_FOLDER_NAME = "Smart_Tools_Manager"
SETTINGS_FILE_NAME = "Smart_Tools_Manager.json"
LEGACY_SETTINGS_FILE_NAME = "Smart_Tools_Manager_Suite.json"
SETTINGS_BACKUP_SUFFIX = ".bak"
CHECKSUM_ALGORITHM = "sha256"

PLACEMENT_API_VERSION = 3
RULE_MATRIX_WRITE_API_REVISION = 1
MANAGER_SELF_RULE_POLICY = "NOT_CATALOGUED_NO_N_PANEL"
PLACEMENT_STATUS_READY = "READY"
PLACEMENT_STATUS_NOT_READY = "NOT_READY"
PLACEMENT_POLICY = MappingProxyType({
    "known_invalid_key": "FAIL_CLOSED",
    "logical_editor_mismatch": "FAIL_CLOSED",
    "verified_matrix": "EXPLICIT_CELL",
    "not_ready_with_last_known_authoritative_state": "LAST_KNOWN_CELL",
    "not_ready_without_authoritative_state": "FAIL_OPEN",
    "custom_or_unresolved_context": "FAIL_OPEN",
    "context_resolution_exception": "FAIL_OPEN",
    "trusted_cache_exception": "FAIL_CLOSED",
    "workspace_owner_retention_exception": "FAIL_OPEN",
})
PURE_PLACEMENT_API_NAMES = (
    "placement_allowed",
    "_panel_allowed_for_context",
    "panel_rule_allows_context",
    "workspace_tool_allowed",
    "get_placement_state",
    "get_rule_matrix_snapshot",
    "get_rule_matrix_state",
    "get_catalog_snapshot",
    "get_placement_contract",
    "logical_editor_key_from_context",
)
COMPATIBILITY_ACTION_API_NAMES = ("notify_panel_sources_changed",)
RULE_MATRIX_WRITE_API_NAMES = (
    "apply_rule_matrix",
    "subscribe_rule_matrix_commits",
    "unsubscribe_rule_matrix_commits",
)
PERSISTENCE_BOUNDARY_NAMES = (
    "register",
    "_load_post_handler",
    "SMARTTOOLS_OT_reload_manager.execute",
    "explicit_property_update_callbacks",
    "_save_pre_handler_when_dirty",
    "undo_redo_handlers_after_verified_authority",
    "unregister_when_dirty",
)

# v1.5.54 and earlier placed callable routing state in this Manager-owned
# driver namespace slot. v1.5.56 never stores callbacks there. The key is
# removed once at register/load boundaries so an old Manager closure cannot be
# kept alive through driver_namespace after an in-process extension update.
_LEGACY_PANEL_ROUTER_NAMESPACE_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_PANEL_ROUTER_V1"
_LIFECYCLE_LEDGER_NAMESPACE_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_LIFECYCLE_V1"
_LIFECYCLE_LEDGER_SCHEMA = 1
_RUNTIME_API_NAMESPACE_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1"
_RUNTIME_API_SCHEMA = 1
_RUNTIME_API_IDENTITY = object()
_WORKSPACE_BRIDGE_ENDPOINT_NAMESPACE_KEY = (
    "JELARARAGI_SMART_WORKSPACE_SUITE_MANAGER_BRIDGE_V1"
)

RUNTIME_MESSAGE_WRAP_WIDTH = 74
RUNTIME_MESSAGE_POPUP_WRAP_WIDTH = 112
RUNTIME_MESSAGE_PREVIEW_ROWS = 7
RUNTIME_MESSAGE_POPUP_ROWS = 42
UNDO_CACHE_MAX_ITEMS = 256
WORKSPACE_SNAPSHOT_MAX_ITEMS = 64
SETTINGS_COMMIT_RETRY_LIMIT = 3
_WRITE_AUTHORITY_ORDINARY = "ORDINARY"
_WRITE_AUTHORITY_SAVE_DISABLE = "SAVE_DISABLE_TRANSITION"
_WRITE_AUTHORITY_SAVE_ENABLE = "SAVE_ENABLE_TRANSITION"
_WRITE_AUTHORITY_VERIFIED_RECOVERY = "VERIFIED_RECOVERY"
SETTINGS_LOCK_TIMEOUT_MS = 5000

MODE_FAST = "FAST"
MODE_STRICT = "STRICT"
MODE_MANUAL = "MANUAL"
_MODE_KEYS = {MODE_FAST, MODE_STRICT, MODE_MANUAL}
_DEFAULT_MODE = MODE_FAST
_MODE_ITEMS = {
    MODE_FAST: {
        "en": "Fast",
        "ja": "高速",
    },
    MODE_STRICT: {
        "en": "Strict",
        "ja": "厳格",
    },
    MODE_MANUAL: {
        "en": "Manual",
        "ja": "手動",
    },
}

_WORKSPACE_ITEMS = (
    ("LAYOUT", "Layout", "レイアウト", ("Layout", "レイアウト")),
    ("MODELING", "Modeling", "モデリング", ("Modeling", "モデリング")),
    ("SCULPTING", "Sculpting", "スカルプト", ("Sculpting", "スカルプト")),
    ("UV_EDITING", "UV Editing", "UVエディティング", ("UV Editing", "UVエディティング", "UV編集")),
    ("TEXTURE_PAINT", "Texture Paint", "テクスチャペイント", ("Texture Paint", "テクスチャペイント")),
    ("SHADING", "Shading", "シェーディング", ("Shading", "シェーディング")),
    ("ANIMATION", "Animation", "アニメーション", ("Animation", "アニメーション")),
    ("RENDERING", "Rendering", "レンダリング", ("Rendering", "レンダリング")),
    ("COMPOSITING", "Compositing", "コンポジティング", ("Compositing", "コンポジティング")),
    ("GEOMETRY_NODES", "Geometry Nodes", "ジオメトリノード", ("Geometry Nodes", "Geometry Node", "ジオメトリノード")),
    ("SCRIPTING", "Scripting", "スクリプティング", ("Scripting", "スクリプティング", "スクリプト作成")),
    ("ANIMATION_2D", "2D Animation", "2Dアニメーション", ("2D Animation", "2Dアニメーション")),
    ("FULL_CANVAS_2D", "2D Full Canvas", "2Dフルキャンバス", ("2D Full Canvas", "2Dフルキャンバス")),
    ("MASKING", "Masking", "マスキング", ("Masking", "マスキング")),
    ("MOTION_TRACKING", "Motion Tracking", "モーショントラッキング", ("Motion Tracking", "モーショントラッキング")),
    ("VIDEO_EDITING", "Video Editing", "ビデオ編集", ("Video Editing", "ビデオ編集")),
)

_EDITOR_ITEMS = (
    ("VIEW_3D", "3D Viewport", "3Dビューポート"),
    ("IMAGE_EDITOR", "Image Editor", "画像エディター"),
    ("UV_EDITOR", "UV Editor", "UVエディター"),
    ("SHADER_EDITOR", "Shader Editor", "シェーダーエディター"),
    ("COMPOSITOR", "Compositor", "コンポジター"),
    ("GEOMETRY_NODE_EDITOR", "Geometry Node Editor", "ジオメトリノードエディター"),
    ("TEXTURE_NODE_EDITOR", "Texture Node Editor", "テクスチャノードエディター"),
    ("VIDEO_SEQUENCER", "Video Sequencer", "ビデオシーケンサー"),
    ("MOVIE_CLIP_EDITOR", "Movie Clip Editor", "ムービークリップエディター"),
    ("DOPE_SHEET", "Dope Sheet", "ドープシート"),
    ("GRAPH_EDITOR", "Graph Editor", "グラフエディター"),
    ("DRIVERS", "Drivers", "ドライバー"),
    ("NLA_EDITOR", "Nonlinear Animation", "ノンリニアアニメーション"),
    ("TEXT_EDITOR", "Text Editor", "テキストエディター"),
    ("ASSET_BROWSER", "Asset Browser", "アセットブラウザー"),
    ("FILE_BROWSER", "File Browser", "ファイルブラウザー"),
    ("SPREADSHEET", "Spreadsheet", "スプレッドシート"),
)

# Exact public ordering invariant for the popup's Smart Tools column.
_TOOLS = (
    {"key": "SMART_FILE", "en": "Smart File", "ja": "Smart File", "module": "smart_file_suite", "addon_name": "Smart_File_Suite"},
    {"key": "SMART_WORKSPACE", "en": "Smart Workspace", "ja": "Smart Workspace", "module": "smart_workspace_suite", "addon_name": "Smart_WorkSpace_Suite"},
    {"key": "SMART_OVERLAY", "en": "Smart Overlay", "ja": "Smart Overlay", "module": "smart_overlay_suite", "addon_name": "Smart_Overlay_Suite"},
    {"key": "SMART_TRANSFORM", "en": "Smart Transform", "ja": "Smart Transform", "module": "smart_transform_suite", "addon_name": "Smart_Transform_Suite"},
    {"key": "SMART_ID", "en": "Smart ID", "ja": "Smart ID", "module": "smart_id_suite", "addon_name": "Smart_ID_Suite"},
    {"key": "SMART_GEOMETRY", "en": "Smart Geometry", "ja": "Smart Geometry", "module": "smart_geometry_suite", "addon_name": "Smart_Geometry_Suite", "module_aliases": ("smart_geometrynode_suite",)},
    {"key": "SMART_CAMLIGHT", "en": "Smart CamLight", "ja": "Smart CamLight", "module": "smart_camlight_suite", "addon_name": "Smart_CamLight_Suite"},
    {"key": "SMART_MODELING", "en": "Smart Modeling", "ja": "Smart Modeling", "module": "smart_modeling_suite", "addon_name": "Smart_Modeling_Suite"},
    {"key": "SMART_MODIFIER", "en": "Smart Modifier", "ja": "Smart Modifier", "module": "smart_modifier_suite", "addon_name": "Smart_Modifier_Suite"},
    {"key": "SMART_SCULPT", "en": "Smart Sculpt", "ja": "Smart Sculpt", "module": "smart_sculpt_suite", "addon_name": "Smart_Sculpt_Suite"},
    {"key": "SMART_SHAPEKEY", "en": "Smart Shapekey", "ja": "Smart Shapekey", "module": "smart_shapekey_suite", "addon_name": "Smart_Shapekey_Suite"},
    {"key": "SMART_UV", "en": "Smart UV", "ja": "Smart UV", "module": "smart_uv_suite", "addon_name": "Smart_UV_Suite"},
    {"key": "SMART_PAINT", "en": "Smart Paint", "ja": "Smart Paint", "module": "smart_paint_suite", "addon_name": "Smart_Paint_Suite"},
    {"key": "SMART_SHADER", "en": "Smart Shader", "ja": "Smart Shader", "module": "smart_shader_suite", "addon_name": "Smart_Shader_Suite"},
    {"key": "SMART_RIG", "en": "Smart Rig", "ja": "Smart Rig", "module": "smart_rig_suite", "addon_name": "Smart_Rig_Suite"},
    {"key": "SMART_CLOTH", "en": "Smart Cloth", "ja": "Smart Cloth", "module": "smart_cloth_suite", "addon_name": "Smart_Cloth_Suite"},
    {"key": "SMART_ANIMATION", "en": "Smart Animation", "ja": "Smart Animation", "module": "smart_animation_suite", "addon_name": "Smart_Animation_Suite"},
    {"key": "SMART_SELECTOR", "en": "Smart Selector", "ja": "Smart Selector", "module": "smart_selector_suite", "addon_name": "Smart_Selector_Suite"},
    {"key": "SMART_RENDER", "en": "Smart Render", "ja": "Smart Render", "module": "smart_render_suite", "addon_name": "Smart_Render_Suite"},
    {"key": "SMART_NODE", "en": "Smart Node", "ja": "Smart Node", "module": "smart_node_suite", "addon_name": "Smart_Node_Suite"},
    {"key": "SMART_COMPOSITE", "en": "Smart Composite", "ja": "Smart Composite", "module": "smart_composite_suite", "addon_name": "Smart_Composite_Suite"},
)

_LEGACY_TOOL_KEY_MAP = {"SMART_GEOMETRYNODE": "SMART_GEOMETRY"}
_TOOL_BY_KEY = {item["key"]: item for item in _TOOLS}
_TOOL_PROP_BY_KEY = {item["key"]: "tool_" + item["key"].lower() for item in _TOOLS}
_WORKSPACE_KEYS = {item[0] for item in _WORKSPACE_ITEMS}
_EDITOR_KEYS = {item[0] for item in _EDITOR_ITEMS}
_WORKSPACE_ORDER = tuple(item[0] for item in _WORKSPACE_ITEMS)
_EDITOR_ORDER = tuple(item[0] for item in _EDITOR_ITEMS)
_TOOL_ORDER = tuple(item["key"] for item in _TOOLS)
_SCHEMA_V3_TOOL_ORDER = (*_TOOL_ORDER, "SMART_TOOLS_MANAGER")
MATRIX_CELL_COUNT = len(_WORKSPACE_ORDER) * len(_EDITOR_ORDER) * len(_TOOL_ORDER)
SCHEMA_V3_MATRIX_CELL_COUNT = (
    len(_WORKSPACE_ORDER) * len(_EDITOR_ORDER) * len(_SCHEMA_V3_TOOL_ORDER)
)

_EXPECTED_PUBLIC_TOOL_ORDER = (
    "SMART_FILE",
    "SMART_WORKSPACE",
    "SMART_OVERLAY",
    "SMART_TRANSFORM",
    "SMART_ID",
    "SMART_GEOMETRY",
    "SMART_CAMLIGHT",
    "SMART_MODELING",
    "SMART_MODIFIER",
    "SMART_SCULPT",
    "SMART_SHAPEKEY",
    "SMART_UV",
    "SMART_PAINT",
    "SMART_SHADER",
    "SMART_RIG",
    "SMART_CLOTH",
    "SMART_ANIMATION",
    "SMART_SELECTOR",
    "SMART_RENDER",
    "SMART_NODE",
    "SMART_COMPOSITE",
)
if _TOOL_ORDER != _EXPECTED_PUBLIC_TOOL_ORDER:
    raise RuntimeError("Smart Tools catalog order does not match the public popup order")
if len(_SCHEMA_V3_TOOL_ORDER) != 22:
    raise RuntimeError("Smart Tools schema v3 catalog must contain exactly 22 keys")

PHYSICAL_SPACE_TYPES = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "NODE_EDITOR",
    "SEQUENCE_EDITOR",
    "CLIP_EDITOR",
    "DOPESHEET_EDITOR",
    "GRAPH_EDITOR",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "FILE_BROWSER",
    "SPREADSHEET",
)

_LEGACY_ANCHOR_PREFIX_BY_SPACE = {
    "VIEW_3D": "VIEW3D_PT",
    "IMAGE_EDITOR": "IMAGE_PT",
    "NODE_EDITOR": "NODE_PT",
    "SEQUENCE_EDITOR": "SEQUENCER_PT",
    "CLIP_EDITOR": "CLIP_PT",
    "DOPESHEET_EDITOR": "DOPESHEET_PT",
    "GRAPH_EDITOR": "GRAPH_PT",
    "NLA_EDITOR": "NLA_PT",
    "TEXT_EDITOR": "TEXT_PT",
    "FILE_BROWSER": "FILEBROWSER_PT",
    "SPREADSHEET": "SPREADSHEET_PT",
}

_EDITOR_SPACE_TYPES = {
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
}

RETIRED_RUNTIME_VALUES = {
    "runtime_panel_proxies": False,
    "category_anchors": False,
    "ui_callback_repair": False,
    "transform_guard": False,
    "stale_proxy_cleanup": False,
}

RESIDENT_RUNTIME_DEFAULTS = {
    "automatic_context_sync": False,
    "source_panel_filters": False,
    "topbar_button": False,
    "load_restore_handler": False,
    "undo_redo_handlers": False,
    # Publishing the rule-matrix record is data only (no panel callbacks are
    # replaced). Sibling Smart suites read it to keep their sidebar tabs in step
    # with the matrix, so it is on by default.
    "runtime_api_bridge": True,
}

# Settings written by 1.5.84 and earlier stored the old default (False) for
# runtime_api_bridge. Those files are switched on once while they are rewritten
# for this version; a later explicit "off" is kept.
_RUNTIME_API_BRIDGE_DEFAULT_ON_VERSION = (1, 5, 85)


def _extension_version_tuple(text: Any) -> tuple[int, ...]:
    parts: list[int] = []
    for piece in str(text or "").strip().split("."):
        if not piece.isdigit():
            return ()
        parts.append(int(piece))
    return tuple(parts)

RESIDENT_RUNTIME_PROPERTY_BY_KEY = {
    "automatic_context_sync": "runtime_automatic_context_sync",
    "source_panel_filters": "runtime_source_panel_filters",
    "topbar_button": "runtime_topbar_button",
    "load_restore_handler": "runtime_load_restore_handler",
    "undo_redo_handlers": "runtime_undo_redo_handlers",
    "runtime_api_bridge": "runtime_api_bridge",
}

_settings_cache: dict[str, Any] | None = None
_settings_authoritative = False
_settings_ready = False
_settings_authority_source = "UNINITIALIZED"
_settings_disk_snapshot: tuple[tuple[str, int, str, str, int], tuple[str, int, str, str, int]] | None = None
_settings_load_attempted = False
_pending_settings: dict[str, Any] | None = None
_settings_dirty = False
_settings_write_in_progress = False
_persistence_blocked_reason = ""
_runtime_errors: dict[str, str] = {}
_runtime_status: dict[str, str] = {}
_syncing_properties = False
_undo_restore_in_progress = False
_undo_checkpoint_counter = 0
_undo_state_store: dict[int, str] = {}
_last_undo_state_text = ""
_workspace_filter_deltas: dict[tuple[int, str], dict[str, Any]] = {}
_manager_registered = False
_registration_token = ""
_registered_classes: list[type] = []
_registered_handlers: list[tuple[list, Any]] = []
_topbar_draw_registered = False
_pointer_property_registered = False
_scene_undo_property_registered = False
_translations_registered = False
_preview_collection = None
_custom_icons: dict[str, Any] = {}
_active_lifecycle_ledger: dict[str, Any] | None = None
_active_runtime_api_record: dict[str, Any] | None = None


class SettingsValidationError(ValueError):
    """Raised when a settings payload cannot be trusted."""


class RegistrationTransactionError(RuntimeError):
    """Raised when Manager-owned class registration cannot be rolled back fully."""

    def __init__(
        self,
        message: str,
        *,
        remaining_new: Iterable[type] = (),
        stale_not_restored: Iterable[type] = (),
    ) -> None:
        super().__init__(message)
        self.remaining_new = tuple(remaining_new)
        self.stale_not_restored = tuple(stale_not_restored)


def _extension_root() -> Path:
    return Path(__file__).resolve().parent


def _config_root() -> Path:
    try:
        value = bpy.utils.user_resource("CONFIG")
        if value:
            return Path(value)
    except Exception:
        pass
    try:
        return Path(bpy.utils.resource_path("USER")) / "config"
    except Exception:
        return Path.home() / ".config" / "blender"


def _settings_path() -> Path:
    return _config_root() / SETTINGS_FOLDER_NAME / SETTINGS_FILE_NAME


def _legacy_settings_path() -> Path:
    return _config_root() / SETTINGS_FOLDER_NAME / LEGACY_SETTINGS_FILE_NAME


def _settings_backup_path(path: Path | None = None) -> Path:
    target = path or _settings_path()
    return target.with_name(target.name + SETTINGS_BACKUP_SUFFIX)


def _settings_mutex_name(path: Path) -> str:
    normalized = os.path.normcase(os.path.abspath(str(path)))
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:32]
    return rf"Local\JELararagiSmartToolsManagerSettings_{digest}"


@contextmanager
def _settings_interprocess_lock(
    path: Path,
    *,
    timeout_ms: int = SETTINGS_LOCK_TIMEOUT_MS,
):
    """Serialize settings transactions across Blender processes on Windows."""
    if os.name != "nt":
        yield
        return

    import ctypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    create_mutex = kernel32.CreateMutexW
    create_mutex.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    create_mutex.restype = ctypes.c_void_p
    wait_for_single_object = kernel32.WaitForSingleObject
    wait_for_single_object.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    wait_for_single_object.restype = ctypes.c_uint32
    release_mutex = kernel32.ReleaseMutex
    release_mutex.argtypes = [ctypes.c_void_p]
    release_mutex.restype = ctypes.c_int
    close_handle = kernel32.CloseHandle
    close_handle.argtypes = [ctypes.c_void_p]
    close_handle.restype = ctypes.c_int

    handle = create_mutex(None, False, _settings_mutex_name(path))
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    acquired = False
    try:
        status = int(wait_for_single_object(handle, max(0, int(timeout_ms))))
        if status in {0x00000000, 0x00000080}:  # OBJECT_0, ABANDONED
            acquired = True
        elif status == 0x00000102:
            raise TimeoutError("Smart Tools Manager settings lock timed out")
        else:
            raise ctypes.WinError(ctypes.get_last_error())
        yield
    finally:
        if acquired and not release_mutex(handle):
            _runtime_errors["SETTINGS_LOCK_RELEASE"] = (
                f"WinError {ctypes.get_last_error()}: settings mutex release failed"
            )
        close_handle(handle)


def _is_japanese(context=None) -> bool:
    try:
        prefs = (context or bpy.context).preferences
        view = prefs.view
        if not bool(getattr(view, "use_translate_interface", True)):
            return False
        language = str(getattr(view, "language", "") or "").lower()
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "").lower()
        return language.startswith("ja") or locale.startswith("ja") or "japanese" in language
    except Exception:
        return False


def _text(en: str, ja: str, context=None) -> str:
    return ja if _is_japanese(context) else en


def _format_text(en: str, ja: str, context=None, **values) -> str:
    return _text(en, ja, context).format(**values)


_TRANSLATION_MESSAGES_JA = {
    "Release Cleanup": "リリース整理",
    "Make a new copy without the working data you choose": "選んだ作業データを除いた、新しいコピーを作ります",
    "Selection JSON": "選択JSON",
    "Preservation contract (optional)": "保護契約（任意）",
    "Target page": "対象ページ",
    "Toggle cleanup target": "整理対象のチェック切替",
    "Select only proven disposable working data": "破棄可能と証明された作業データだけを選択",
    "New copy": "新規コピー",
    "Result JSON": "結果JSON",
    "Inspect": "点検",
    "Check which data can be removed, without changing anything": "どのデータを消せるかを、何も変えずに確かめます",
    "Apply to Copy": "コピーへ適用",
    "Create a new copy without the selected data": "選んだデータを除いた新しいコピーを作ります",
    "Export Result": "結果を書出",
    "Save the inspection and removal results to a file": "点検と削除の結果をファイルに保存します",
    "Release Cleanup Help": "リリース整理ヘルプ",
    "Target, steps, recovery and limits": "対象・手順・復旧・限界",
    "Text": "テキスト",
    "Workspace": "ワークスペース",
    "Editor": "エディター",
    "Mode": "モード",
    "N-panel State Save": "Nパネル状態保存",
    "Always-on Toggles": "常時機能切り替え",
    "Resident Feature Toggles": "常時機能切り替え",
    "Automatic Context Sync": "自動コンテキスト同期",
    "Source Panel Filters": "ソースパネルフィルター",
    "Top Bar Button": "トップバーボタン",
    "File-load Restore": "ファイル読込後の復元",
    "Undo/Redo Synchronization": "元に戻す／やり直し同期",
    "Notify Other Smart Tools": "他のスマートツールへの通知",
    "Runtime Panel Proxies": "ランタイムパネルプロキシ",
    "Category Anchors": "カテゴリーアンカー",
    "UI Callback Repair": "UIコールバック修復",
    "Transform Guard": "トランスフォーム保護",
    "Stale Proxy Cleanup": "旧プロキシ清掃",
    "Select Workspace": "ワークスペースを選択",
    "Set All Smart Tools": "スマートツールをまとめて切り替え",
    "Enable or disable every Smart Tool for the selected workspace and editor": "選んだワークスペースとエディターで、すべてのスマートツールを有効または無効にします",
    "Select Editor": "エディターを選択",
    "System": "システム",
    "Top Bar > Smart Tools": "トップバー > スマートツール",
    "Choose the workspaces and editors where each Smart Tool shows its panels.": "各スマートツールのパネルを出すワークスペースとエディターを決めます。",
    "Smart Tools": "スマートツール",
    "Smart Tools Manager": "スマートツールマネージャー",
    "Refresh Smart Tools Manager": "スマートツールマネージャーを更新",
    "Reload Smart Tools": "スマートツールを再読み込み",
    "Copy Runtime Messages": "実行メッセージをコピー",
    "Runtime Messages": "実行メッセージ",
    "Runtime Message": "実行メッセージ",
    "Runtime Message Text": "実行メッセージ本文",
    "Displays one line of the current Smart Tools Manager runtime message.": "現在のスマートツールマネージャー実行メッセージを1行表示します。",
    "Selects the line shown in the manager runtime-message list.": "マネージャーの実行メッセージ一覧で表示対象の行を選択します。",
    "Stores the current Smart Tools Manager status message displayed in its dialog.": "ダイアログに表示する現在のスマートツールマネージャー状態メッセージを保持します。",
    "Choose the Blender workspace whose Smart Tool ON/OFF rules are being edited. The selection is saved when N-panel State Save is enabled.": "スマートツールのON/OFFルールを編集するBlenderワークスペースを選択します。「Nパネル状態保存」が有効な場合、選択を保存します。",
    "Choose the editor whose Smart Tool panel rules are being edited.": "スマートツールのパネルのルールを編集するエディターを選択します。",
    "Open or close the common runtime-toggle section at the top of the Smart Tools Manager N-panel.": "スマートツールマネージャーのNパネル最上部にある共通常時起動切替セクションを開閉します。",
    "Apply the Manager rules the moment you change them or switch workspace. Nothing keeps running in the background.": "ルールやワークスペースを変えたその場で、マネージャーのルールを反映します。裏で動き続ける処理は始めません。",
    "Match Blender's workspace add-on filter to the Manager rules. The Manager never replaces how a panel is drawn.": "Blender のワークスペースのアドオンの絞り込みを、マネージャーのルールに合わせます。パネルの描き方は置き換えません。",
    "Save Manager settings to Smart_Tools_Manager/Smart_Tools_Manager.json. Turning this off is saved once; later edits stay memory-only until it is enabled again.": "マネージャー設定をSmart_Tools_Manager/Smart_Tools_Manager.jsonへ保存します。OFFへの変更は1回保存され、その後の編集は再びONにするまでメモリ内だけに保持されます。",
    "Open or close the resident-feature section in Smart Tools Manager preferences and popup.": "スマートツールマネージャーのプリファレンスとポップアップにある常時機能セクションを開閉します。",
    "Keep the Smart Tools Manager button registered in Blender's Top Bar.": "Blenderのトップバーにスマートツールマネージャーボタンを登録します。",
    "Restore Manager settings after a Blender file is loaded.": "Blenderファイル読込後にマネージャー設定を復元します。",
    "Match the Manager rules again after Blender undo and redo.": "Blender の元に戻す／やり直しの後に、マネージャーのルールを合わせ直します。",
    "Let enabled Smart Tools receive a notice when the Manager rules change.": "有効なスマートツールが、マネージャーのルールの変更の知らせを受け取れるようにします。",
    "Choose the Blender workspace whose Smart Tool ON/OFF rules are being edited. The selection and all checkboxes are saved to Smart_Tools_Manager.json when saving is enabled.": "スマートツールのON/OFFルールを編集するBlenderワークスペースを選択します。保存が有効な場合、選択と全チェックはSmart_Tools_Manager.jsonへ保存されます。",
    "Compatibility property retained for existing files. Runtime Panel proxies are permanently disabled and no proxy Panel is registered.": "既存ファイル互換用に保持する項目です。ランタイムパネルプロキシは常に無効で、プロキシパネルは登録されません。",
    "Compatibility property retained for existing files. Manager-owned category anchors are permanently disabled; each Suite owns its native category and body.": "既存ファイル互換用に保持する項目です。マネージャー所有カテゴリーアンカーは常に無効で、各スイートがネイティブカテゴリーと本文を所有します。",
    "Compatibility property retained for existing files. Registered UI callbacks are never repaired or replaced by the Manager.": "既存ファイル互換用に保持する項目です。登録済みUIコールバックをマネージャーが修復・置換することはありません。",
    "Compatibility property retained for existing files. The Manager never edits object transforms.": "既存ファイル互換用に保持する項目です。マネージャーはオブジェクトのトランスフォームを変更しません。",
    "Compatibility property retained for existing files. The Manager never scans or removes third-party proxy Panels.": "既存ファイル互換用に保持する項目です。マネージャーは第三者プロキシパネルを走査・削除しません。",
    "Choose the editor whose N-panel Smart Tool rules are being edited. This decides where each Smart Tool's panels can appear; it does not open or close the N-panel itself.": "Nパネル用スマートツールルールを編集するエディターを選択します。各スマートツールのパネルを出せる場所を決めますが、Nパネル自体は開閉しません。",
    "Turn this Smart Tool ON for the selected workspace and editor. When saving is enabled, the setting is saved immediately. The add-on stays enabled; only where its panels appear changes.": "選択中のワークスペースとエディターで、このスマートツールをONにします。保存が有効な場合は即時保存します。アドオンの有効・無効は変えず、パネルを出す場所だけを変えます。",
    "Open the Smart Tools Manager dialog. Changes are saved when N-panel State Save is enabled, and OK applies the rules to the workspace add-on filter. No add-on is enabled or disabled.": "スマートツールマネージャーの画面を開きます。「Nパネル状態保存」が有効な場合は変更を保存し、OKでワークスペースのアドオンの絞り込みをルールに合わせます。アドオンの有効・無効は変えません。",
    "Update the Manager status and the workspace add-on filter from the current settings. No add-on is reloaded, enabled or disabled.": "今の設定から、マネージャーの状態とワークスペースのアドオンの絞り込みを更新します。アドオンの再読み込み・有効化・無効化は行いません。",
    "Copy Smart Tools Manager runtime messages to the clipboard.": "スマートツールマネージャーの実行メッセージをクリップボードへコピーします。",
    "Open Smart Tools Manager runtime messages in a copyable popup.": "スマートツールマネージャーの実行メッセージをコピー可能なポップアップで開きます。",
    "Smart Tools Manager Help": "スマートツールマネージャーのヘルプ",
    "Show how to select, save and restore Manager rules": "マネージャーの設定・保存・復元の使い方を表示します",
    "Runtime issue [{key}]: {message}": "実行時の問題 [{key}]: {message}",
    "Cleanup Target": "整理対象",
    "The cleanup row whose check this button switches.": "このボタンでチェックを切り替える整理対象の行です。",
    "The workspace this button selects for rule editing.": "このボタンでルールの編集対象に選ぶワークスペースです。",
    "The editor this button selects for rule editing.": "このボタンでルールの編集対象に選ぶエディターです。",
    "Turn Smart Tools On": "スマートツールをON",
    "On turns every Smart Tool on for the selected workspace and editor; off turns them all off.": "ONなら選んだワークスペースとエディターのすべてのスマートツールをONに、OFFならすべてをOFFにします。",
    "Runtime Message Lines": "実行メッセージの行",
    "Lines of the current Smart Tools Manager runtime message shown in the list.": "一覧に表示する、現在のスマートツールマネージャー実行メッセージの行です。",
    "Smart Tools Manager settings for this Blender session.": "このBlenderの起動中のスマートツールマネージャー設定です。",
    "Manager Undo Checkpoint": "マネージャーの元に戻す区切り",
    "Internal counter that lets the Manager match its rules again after undo and redo.": "元に戻す／やり直しの後に、マネージャーがルールを合わせ直すための内部の番号です。",
}


def _build_translations() -> dict:
    contexts = ("*", "Operator", "RNA", "Property", "UI")
    entries = {
        (context, english): japanese
        for english, japanese in _TRANSLATION_MESSAGES_JA.items()
        for context in contexts
    }
    return {"ja_JP": entries, "ja": entries}


_TRANSLATIONS = _build_translations()


def _register_translations() -> None:
    global _translations_registered
    if _translations_registered:
        return
    try:
        # A leftover table under the same id (for example from a generation whose
        # flag was lost) makes register() raise ValueError and aborts enabling.
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    bpy.app.translations.register(ADDON_ID, _TRANSLATIONS)
    _translations_registered = True


def _unregister_translations() -> None:
    global _translations_registered
    if not _translations_registered:
        return
    bpy.app.translations.unregister(ADDON_ID)
    _translations_registered = False


def _mode_label(mode: str, context=None) -> str:
    item = _MODE_ITEMS.get(mode, _MODE_ITEMS[_DEFAULT_MODE])
    return item["ja"] if _is_japanese(context) else item["en"]


def _tool_label(tool: dict, context=None) -> str:
    if not _is_japanese(context):
        return tool["en"]
    # Use the same interface lookup as Blender sidebar category labels.
    return bpy.app.translations.pgettext_iface(tool["en"])


def _new_matrix(
    default: bool = False,
) -> dict[str, dict[str, dict[str, bool]]]:
    if type(default) is not bool:
        raise TypeError("matrix default must be bool")
    return {
        workspace_key: {
            editor_key: {tool_key: default for tool_key in _TOOL_ORDER}
            for editor_key in _EDITOR_ORDER
        }
        for workspace_key in _WORKSPACE_ORDER
    }


def _default_state() -> dict[str, Any]:
    return {
        "schema": SETTINGS_SCHEMA,
        "version": SETTINGS_SCHEMA_VERSION,
        "extension_version": VERSION_TEXT,
        "generation": 0,
        "checksum": "",
        "matrix": _new_matrix(True),
        "selection": {
            "workspace": "LAYOUT",
            "editor": "VIEW_3D",
            "mode": _DEFAULT_MODE,
        },
        "ui": {
            "n_panel_state_save": True,
            "show_always_on_toggles": False,
        },
        "runtime": {
            **RESIDENT_RUNTIME_DEFAULTS,
            **RETIRED_RUNTIME_VALUES,
        },
    }


def _strict_bool(value: Any, path: str) -> bool:
    if type(value) is not bool:
        raise SettingsValidationError(f"{path} must be a JSON boolean")
    return value


def _strict_nonnegative_int(value: Any, path: str) -> int:
    if type(value) is not int or value < 0:
        raise SettingsValidationError(f"{path} must be a non-negative integer")
    return value


def _canonical_bytes_without_checksum(payload: dict[str, Any]) -> bytes:
    body = copy.deepcopy(payload)
    body.pop("checksum", None)
    return json.dumps(
        body,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def _checksum_for_payload(payload: dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_bytes_without_checksum(payload)).hexdigest()


def _payload_with_checksum(state: dict[str, Any]) -> dict[str, Any]:
    payload = copy.deepcopy(state)
    payload["schema"] = SETTINGS_SCHEMA
    payload["version"] = SETTINGS_SCHEMA_VERSION
    payload["extension_version"] = VERSION_TEXT
    payload["selection"]["mode"] = _DEFAULT_MODE
    payload["checksum"] = _checksum_for_payload(payload)
    return payload


def _validate_matrix_for_tools(
    raw: Any,
    *,
    tool_order: tuple[str, ...],
) -> dict[str, dict[str, dict[str, bool]]]:
    if not isinstance(raw, dict) or set(raw) != _WORKSPACE_KEYS:
        raise SettingsValidationError("matrix must contain exactly 16 workspace keys")
    expected_tools = set(tool_order)
    result: dict[str, dict[str, dict[str, bool]]] = {}
    for workspace_key in _WORKSPACE_ORDER:
        workspace_rules = raw.get(workspace_key)
        if not isinstance(workspace_rules, dict) or set(workspace_rules) != _EDITOR_KEYS:
            raise SettingsValidationError(f"matrix.{workspace_key} must contain exactly 17 editor keys")
        result[workspace_key] = {}
        for editor_key in _EDITOR_ORDER:
            tool_rules = workspace_rules.get(editor_key)
            if not isinstance(tool_rules, dict) or set(tool_rules) != expected_tools:
                raise SettingsValidationError(
                    f"matrix.{workspace_key}.{editor_key} must contain exactly {len(tool_order)} tool keys"
                )
            result[workspace_key][editor_key] = {
                tool_key: _strict_bool(
                    tool_rules.get(tool_key),
                    f"matrix.{workspace_key}.{editor_key}.{tool_key}",
                )
                for tool_key in tool_order
            }
    return result


def _validate_matrix(raw: Any) -> dict[str, dict[str, dict[str, bool]]]:
    return _validate_matrix_for_tools(raw, tool_order=_TOOL_ORDER)


def _validate_schema_v3_matrix(raw: Any) -> dict[str, dict[str, dict[str, bool]]]:
    return _validate_matrix_for_tools(raw, tool_order=_SCHEMA_V3_TOOL_ORDER)


def _strip_schema_v3_manager_cells(
    previous: dict[str, dict[str, dict[str, bool]]],
) -> dict[str, dict[str, dict[str, bool]]]:
    """Preserve all Suite cells while dropping the retired Manager self-rule."""
    result = _new_matrix(False)
    for workspace_key in _WORKSPACE_ORDER:
        for editor_key in _EDITOR_ORDER:
            for tool_key in _TOOL_ORDER:
                result[workspace_key][editor_key][tool_key] = (
                    previous[workspace_key][editor_key][tool_key] is True
                )
    return result


def _validate_schema_payload(
    raw: Any,
    *,
    schema_version: int,
    matrix_validator,
    matrix_migration=None,
) -> tuple[dict[str, Any], bool]:
    if not isinstance(raw, dict):
        raise SettingsValidationError("settings root must be an object")
    expected_root_keys = {
        "schema",
        "version",
        "extension_version",
        "generation",
        "checksum",
        "matrix",
        "selection",
        "ui",
        "runtime",
    }
    if set(raw) != expected_root_keys:
        raise SettingsValidationError(
            "settings root must contain only the single-matrix schema keys"
        )
    if raw.get("schema") != SETTINGS_SCHEMA:
        raise SettingsValidationError("settings schema does not match")
    if raw.get("version") != schema_version:
        raise SettingsValidationError("settings schema version does not match")
    generation = _strict_nonnegative_int(raw.get("generation"), "generation")
    extension_version = raw.get("extension_version")
    if not isinstance(extension_version, str) or not extension_version:
        raise SettingsValidationError("extension_version must be a non-empty string")
    checksum = raw.get("checksum")
    if not isinstance(checksum, str) or len(checksum) != 64:
        raise SettingsValidationError("checksum must be a 64-character SHA-256 value")
    expected_checksum = _checksum_for_payload(raw)
    if checksum.lower() != expected_checksum:
        raise SettingsValidationError("checksum mismatch")

    matrix = matrix_validator(raw.get("matrix"))
    if matrix_migration is not None:
        matrix = matrix_migration(matrix)
    selection = raw.get("selection")
    if not isinstance(selection, dict) or set(selection) != {"workspace", "editor", "mode"}:
        raise SettingsValidationError(
            "selection must contain exactly workspace, editor, and mode"
        )
    workspace = selection.get("workspace")
    editor = selection.get("editor")
    mode = selection.get("mode")
    if workspace not in _WORKSPACE_KEYS:
        raise SettingsValidationError("selection.workspace is invalid")
    if editor not in _EDITOR_KEYS:
        raise SettingsValidationError("selection.editor is invalid")
    if mode not in _MODE_KEYS:
        raise SettingsValidationError("selection.mode is invalid")

    raw_ui = raw.get("ui")
    if not isinstance(raw_ui, dict) or set(raw_ui) != {
        "n_panel_state_save",
        "show_always_on_toggles",
    }:
        raise SettingsValidationError(
            "ui must contain exactly n_panel_state_save and show_always_on_toggles"
        )
    n_panel_state_save = _strict_bool(
        raw_ui.get("n_panel_state_save"), "ui.n_panel_state_save"
    )
    show_always = _strict_bool(
        raw_ui.get("show_always_on_toggles"), "ui.show_always_on_toggles"
    )

    raw_runtime = raw.get("runtime")
    old_runtime_keys = {"automatic_context_sync", "source_panel_filters", *RETIRED_RUNTIME_VALUES}
    expected_runtime_keys = (
        set(RESIDENT_RUNTIME_DEFAULTS) | set(RETIRED_RUNTIME_VALUES)
        if schema_version >= 5
        else old_runtime_keys
    )
    if not isinstance(raw_runtime, dict) or set(raw_runtime) != expected_runtime_keys:
        raise SettingsValidationError(
            "runtime must contain exactly the supported compatibility keys"
        )
    normalized_runtime = {}
    for key, default in RESIDENT_RUNTIME_DEFAULTS.items():
        if schema_version >= 5:
            normalized_runtime[key] = _strict_bool(raw_runtime.get(key), f"runtime.{key}")
        elif key == "automatic_context_sync":
            normalized_runtime[key] = _strict_bool(raw_runtime.get(key), f"runtime.{key}")
        elif key == "source_panel_filters":
            normalized_runtime[key] = _strict_bool(raw_runtime.get(key), f"runtime.{key}")
        else:
            normalized_runtime[key] = True
    if (
        schema_version >= 5
        and _extension_version_tuple(extension_version)
        < _RUNTIME_API_BRIDGE_DEFAULT_ON_VERSION
    ):
        normalized_runtime["runtime_api_bridge"] = True
    needs_repair = bool(
        schema_version != SETTINGS_SCHEMA_VERSION
        or matrix_migration is not None
        or mode != _DEFAULT_MODE
        or extension_version != VERSION_TEXT
    )
    for key, retired_value in RETIRED_RUNTIME_VALUES.items():
        current = _strict_bool(raw_runtime.get(key), f"runtime.{key}")
        if current is not retired_value:
            needs_repair = True
        normalized_runtime[key] = retired_value

    state = {
        "schema": SETTINGS_SCHEMA,
        "version": schema_version,
        "extension_version": extension_version,
        "generation": generation,
        "checksum": checksum.lower(),
        "matrix": matrix,
        "selection": {
            "workspace": workspace,
            "editor": editor,
            "mode": _DEFAULT_MODE,
        },
        "ui": {
            "n_panel_state_save": n_panel_state_save,
            "show_always_on_toggles": show_always,
        },
        "runtime": normalized_runtime,
    }
    return state, needs_repair


def _validate_current_payload(raw: Any) -> tuple[dict[str, Any], bool]:
    return _validate_schema_payload(
        raw,
        schema_version=SETTINGS_SCHEMA_VERSION,
        matrix_validator=_validate_matrix,
    )


def _validate_schema_v4_payload(raw: Any) -> tuple[dict[str, Any], bool]:
    return _validate_schema_payload(
        raw,
        schema_version=4,
        matrix_validator=_validate_matrix,
    )


def _validate_previous_payload(raw: Any) -> tuple[dict[str, Any], bool]:
    return _validate_schema_payload(
        raw,
        schema_version=3,
        matrix_validator=_validate_schema_v3_matrix,
        matrix_migration=_strip_schema_v3_manager_cells,
    )


def _validate_schema_v2_payload(raw: Any) -> tuple[dict[str, Any], bool]:
    return _validate_schema_payload(
        raw,
        schema_version=2,
        matrix_validator=_validate_matrix,
    )


def _select_legacy_sparse_rule_source(
    raw: dict[str, Any],
) -> tuple[str, dict[str, Any]]:
    """Select the actual v1.5.54 enabled-only rule authority.

    v1.5.54 treated an omitted known cell as ``False`` and retained only
    enabled cells in its normalized in-memory representation.  When an
    ``n_panel.rules`` object exists it is the latest visible edit state and is
    therefore the complete legacy authority; values are never merged
    cell-by-cell with the older top-level ``rules`` object.
    """
    n_panel = raw.get("n_panel")
    if n_panel is not None and not isinstance(n_panel, dict):
        raise SettingsValidationError("legacy n_panel must be an object")
    if isinstance(n_panel, dict) and "rules" in n_panel:
        rules = n_panel.get("rules")
        if not isinstance(rules, dict):
            raise SettingsValidationError("legacy n_panel.rules must be an object")
        return "n_panel.rules", rules
    if "rules" in raw:
        rules = raw.get("rules")
        if not isinstance(rules, dict):
            raise SettingsValidationError("legacy rules must be an object")
        return "rules", rules
    raise SettingsValidationError("legacy settings contain no recognized sparse rules")


def _expand_legacy_sparse_matrix(
    raw: dict[str, Any],
    *,
    path: str,
) -> dict[str, dict[str, dict[str, bool]]]:
    """Expand sparse v1.5.54 rules into exactly 5,712 explicit booleans.

    Unknown workspace/editor/tool keys are ignored, matching the old
    normalizer.  Containers for known keys and values for known cells are
    validated strictly; a JSON string such as ``"false"`` is never coerced to
    ``True``.
    """
    if not isinstance(raw, dict):
        raise SettingsValidationError(f"legacy {path} must be an object")
    result = _new_matrix(False)
    for raw_workspace_key, workspace_rules in raw.items():
        workspace_key = str(raw_workspace_key or "").strip().upper()
        if workspace_key not in _WORKSPACE_KEYS:
            continue
        if not isinstance(workspace_rules, dict):
            raise SettingsValidationError(
                f"legacy {path}.{workspace_key} must be an object"
            )
        for raw_editor_key, tool_rules in workspace_rules.items():
            editor_key = str(raw_editor_key or "").strip().upper()
            if editor_key not in _EDITOR_KEYS:
                continue
            if not isinstance(tool_rules, dict):
                raise SettingsValidationError(
                    f"legacy {path}.{workspace_key}.{editor_key} must be an object"
                )
            for raw_tool_key, raw_enabled in tool_rules.items():
                raw_tool = str(raw_tool_key or "").strip().upper()
                tool_key = _LEGACY_TOOL_KEY_MAP.get(raw_tool, raw_tool)
                if tool_key not in _TOOL_BY_KEY:
                    continue
                result[workspace_key][editor_key][tool_key] = _strict_bool(
                    raw_enabled,
                    f"legacy {path}.{workspace_key}.{editor_key}.{raw_tool_key}",
                )
    return result


def _legacy_selection_value(
    source: dict[str, Any],
    key: str,
    allowed: set[str],
) -> str:
    """Read one required legacy selector without manufacturing a default."""
    if key not in source:
        raise SettingsValidationError(f"legacy {key} is missing")
    value = source.get(key)
    if value not in allowed:
        raise SettingsValidationError(f"legacy {key} is invalid")
    return value


def _validate_legacy_payload(raw: Any) -> dict[str, Any]:
    """Validate and deterministically migrate a sparse pre-schema payload."""
    if not isinstance(raw, dict):
        raise SettingsValidationError("legacy settings root must be an object")
    if raw.get("schema") == SETTINGS_SCHEMA:
        # A damaged current payload must never be reinterpreted as legacy data.
        raise SettingsValidationError("invalid current-schema payload")
    legacy_version = raw.get("version")
    if type(legacy_version) is not int or legacy_version < 1:
        raise SettingsValidationError("legacy version must be a positive integer")

    source_name, sparse_rules = _select_legacy_sparse_rule_source(raw)
    state = _default_state()
    state["matrix"] = _expand_legacy_sparse_matrix(
        sparse_rules,
        path=source_name,
    )

    raw_n_panel = raw.get("n_panel")
    selection_source = raw_n_panel if isinstance(raw_n_panel, dict) else raw
    state["selection"] = {
        "workspace": _legacy_selection_value(
            selection_source, "selected_workspace", _WORKSPACE_KEYS
        ),
        "editor": _legacy_selection_value(
            selection_source, "selected_editor", _EDITOR_KEYS
        ),
        "mode": _DEFAULT_MODE,
    }

    if "show_always_on_toggles" not in raw:
        raise SettingsValidationError("legacy show_always_on_toggles is missing")
    state["ui"]["show_always_on_toggles"] = _strict_bool(
        raw["show_always_on_toggles"],
        "legacy show_always_on_toggles",
    )
    if "n_panel_state_save" not in raw:
        raise SettingsValidationError("legacy n_panel_state_save is missing")
    state["ui"]["n_panel_state_save"] = _strict_bool(
        raw["n_panel_state_save"], "legacy n_panel_state_save"
    )

    raw_runtime = raw.get("runtime_features")
    if not isinstance(raw_runtime, dict):
        raise SettingsValidationError("legacy runtime_features must be an object")
    if "automatic_context_sync" not in raw_runtime:
        raise SettingsValidationError(
            "legacy runtime_features.automatic_context_sync is missing"
        )
    state["runtime"]["automatic_context_sync"] = _strict_bool(
        raw_runtime["automatic_context_sync"],
        "legacy runtime_features.automatic_context_sync",
    )
    state["runtime"]["source_panel_filters"] = True
    state["runtime"]["topbar_button"] = True
    state["runtime"]["load_restore_handler"] = True
    state["runtime"]["undo_redo_handlers"] = True
    state["runtime"]["runtime_api_bridge"] = True
    if "generation" in raw:
        state["generation"] = _strict_nonnegative_int(
            raw["generation"], "legacy generation"
        )
    return state


def _parse_settings_bytes(raw_bytes: bytes) -> tuple[dict[str, Any], str, bool]:
    try:
        # utf-8 rejects a BOM instead of silently accepting utf-8-sig.
        decoded = raw_bytes.decode("utf-8")
        raw = json.loads(decoded)
    except Exception as exc:
        raise SettingsValidationError(f"JSON decode failed: {exc}") from exc
    if isinstance(raw, dict) and raw.get("schema") == SETTINGS_SCHEMA:
        version = raw.get("version")
        if version == SETTINGS_SCHEMA_VERSION:
            state, needs_repair = _validate_current_payload(raw)
            return state, "current", needs_repair
        if version == 4:
            state, _needs_repair = _validate_schema_v4_payload(raw)
            return state, "previous", True
        if version == 3:
            state, _needs_repair = _validate_previous_payload(raw)
            return state, "previous", True
        if version == 2:
            state, _needs_repair = _validate_schema_v2_payload(raw)
            return state, "previous", True
        # A damaged or unknown current-schema payload must never be
        # reinterpreted as the sparse legacy format.
        raise SettingsValidationError("unsupported current-schema version")
    legacy = _validate_legacy_payload(raw)
    return legacy, "legacy", True


_MISSING_DISK_TOKEN = ("missing", 0, "", "", -1)
_USE_GLOBAL_DISK_SNAPSHOT = object()
_VERIFIED_DISK_KINDS = frozenset({"current", "previous", "legacy"})
_MIGRATABLE_DISK_KINDS = frozenset({"previous", "legacy"})


def _disk_token_from_verified_bytes(
    raw_bytes: bytes,
    state: dict[str, Any],
    kind: str,
) -> tuple[str, int, str, str, int]:
    return (
        str(kind),
        len(raw_bytes),
        hashlib.sha256(raw_bytes).hexdigest(),
        str(state.get("checksum", "") or "")
        if kind in {"current", "previous"}
        else "",
        int(state.get("generation", 0) or 0),
    )


def _disk_token_from_unverified_bytes(
    raw_bytes: bytes,
) -> tuple[str, int, str, str, int]:
    return (
        "unverified",
        len(raw_bytes),
        hashlib.sha256(raw_bytes).hexdigest(),
        "",
        -1,
    )


def _observe_file(path: Path) -> dict[str, Any]:
    """Read and classify one persistence file at a safe non-draw boundary."""
    if not path.exists():
        return {
            "path": path,
            "token": _MISSING_DISK_TOKEN,
            "bytes": None,
            "state": None,
            "kind": "missing",
            "needs_repair": False,
            "error": "",
        }
    raw_bytes = path.read_bytes()
    try:
        state, kind, needs_repair = _parse_settings_bytes(raw_bytes)
    except Exception:
        return {
            "path": path,
            "token": _disk_token_from_unverified_bytes(raw_bytes),
            "bytes": raw_bytes,
            "state": None,
            "kind": "unverified",
            "needs_repair": False,
            "error": traceback.format_exc(limit=6),
        }
    return {
        "path": path,
        "token": _disk_token_from_verified_bytes(raw_bytes, state, kind),
        "bytes": raw_bytes,
        "state": state,
        "kind": kind,
        "needs_repair": bool(needs_repair),
        "error": "",
    }


def _observe_disk_pair(target: Path) -> tuple[
    tuple[tuple[str, int, str, str, int], tuple[str, int, str, str, int]],
    dict[str, Any],
    dict[str, Any],
]:
    primary = _observe_file(target)
    backup = _observe_file(_settings_backup_path(target))
    return (primary["token"], backup["token"]), primary, backup


def _disk_token_description(token: tuple[str, int, str, str, int] | None) -> str:
    if token is None:
        return "none"
    kind, size, raw_sha256, checksum, generation = token
    return (
        f"kind={kind},size={size},raw_sha256={raw_sha256},"
        f"checksum={checksum},generation={generation}"
    )


def _disk_snapshot_description(snapshot) -> str:
    if not isinstance(snapshot, tuple) or len(snapshot) != 2:
        return "none"
    return (
        "primary[" + _disk_token_description(snapshot[0]) + "] "
        "backup[" + _disk_token_description(snapshot[1]) + "]"
    )


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        # _atomic_replace uses MoveFileExW + MOVEFILE_WRITE_THROUGH on Windows.
        return
    flags = os.O_RDONLY | int(getattr(os, "O_DIRECTORY", 0) or 0)
    descriptor = os.open(str(path), flags)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _atomic_replace(source: Path, target: Path) -> None:
    """Atomically replace target and request durable metadata completion."""
    if os.name != "nt":
        os.replace(str(source), str(target))
        return

    import ctypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    move_file_ex = kernel32.MoveFileExW
    move_file_ex.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
    move_file_ex.restype = ctypes.c_int
    flags = 0x00000001 | 0x00000008  # REPLACE_EXISTING | WRITE_THROUGH
    if not move_file_ex(str(source), str(target), flags):
        raise ctypes.WinError(ctypes.get_last_error())


def _write_unique_temp(directory: Path, target_name: str, payload_bytes: bytes) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    descriptor, temp_name = tempfile.mkstemp(
        prefix=f".{target_name}.{uuid.uuid4().hex}.",
        suffix=".tmp",
        dir=str(directory),
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        if temp_path.read_bytes() != payload_bytes:
            raise OSError("temporary settings readback mismatch")
        _parse_settings_bytes(payload_bytes)
        return temp_path
    except Exception:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _serialize_state(state: dict[str, Any]) -> tuple[dict[str, Any], bytes]:
    payload = _payload_with_checksum(state)
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ).encode("utf-8") + b"\n"
    parsed, kind, needs_repair = _parse_settings_bytes(encoded)
    if kind != "current" or needs_repair:
        raise SettingsValidationError("serialized payload did not validate as current schema")
    if parsed["generation"] != payload["generation"]:
        raise SettingsValidationError("serialized generation changed during validation")
    return payload, encoded


def _cas_replace_verified_bytes(
    target: Path,
    payload_bytes: bytes,
    *,
    expected_token: tuple[str, int, str, str, int],
) -> tuple[dict[str, Any], str, bool, tuple[str, int, str, str, int]]:
    """Replace one file only if its exact observed identity is unchanged."""
    parsed, kind, needs_repair = _parse_settings_bytes(payload_bytes)
    first = _observe_file(target)
    if first["token"] != expected_token:
        raise SettingsValidationError(
            "settings CAS conflict before staging: expected "
            + _disk_token_description(expected_token)
            + "; observed "
            + _disk_token_description(first["token"])
        )
    temp_path = _write_unique_temp(target.parent, target.name, payload_bytes)
    try:
        second = _observe_file(target)
        if second["token"] != expected_token:
            raise SettingsValidationError(
                "settings CAS conflict before atomic replace: expected "
                + _disk_token_description(expected_token)
                + "; observed "
                + _disk_token_description(second["token"])
            )
        _atomic_replace(temp_path, target)
        _fsync_directory(target.parent)
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass
    readback = target.read_bytes()
    if readback != payload_bytes:
        raise SettingsValidationError("atomic settings readback bytes changed")
    readback_state, readback_kind, readback_repair = _parse_settings_bytes(readback)
    token = _disk_token_from_verified_bytes(
        readback, readback_state, readback_kind
    )
    return readback_state, readback_kind, readback_repair, token


def _cas_delete_file(
    target: Path,
    *,
    expected_token: tuple[str, int, str, str, int],
) -> None:
    observed = _observe_file(target)
    if observed["token"] != expected_token:
        raise SettingsValidationError("settings CAS conflict before rollback delete")
    target.unlink(missing_ok=True)
    _fsync_directory(target.parent)
    if _observe_file(target)["token"] != _MISSING_DISK_TOKEN:
        raise SettingsValidationError("rollback delete did not produce a missing file")


def _restore_file_if_unchanged(
    target: Path,
    *,
    expected_current_token: tuple[str, int, str, str, int] | None,
    original_token: tuple[str, int, str, str, int],
    original_bytes: bytes | None,
) -> None:
    """Best-effort rollback that never overwrites a concurrent external edit."""
    if expected_current_token is None:
        return
    current = _observe_file(target)
    if current["token"] != expected_current_token:
        return
    if original_token == _MISSING_DISK_TOKEN:
        _cas_delete_file(target, expected_token=expected_current_token)
        return
    if original_bytes is None:
        return
    _cas_replace_verified_bytes(
        target,
        original_bytes,
        expected_token=expected_current_token,
    )


def _mark_not_ready(
    reason: str,
    *,
    preserve_authority: bool,
    source: str | None = None,
    keep_disk_snapshot: bool = True,
) -> None:
    global _settings_authoritative, _settings_ready, _settings_authority_source
    global _settings_disk_snapshot, _persistence_blocked_reason
    _settings_authoritative = bool(preserve_authority)
    _settings_ready = False
    _settings_authority_source = source or (
        "LAST_KNOWN_AUTHORITATIVE" if preserve_authority else "NOT_READY"
    )
    if not keep_disk_snapshot:
        _settings_disk_snapshot = None
    _persistence_blocked_reason = str(reason or "settings are not ready")
    _publish_lifecycle_state()


def _adopt_verified_state(
    state: dict[str, Any],
    *,
    snapshot,
    source: str,
    ready: bool = True,
) -> None:
    global _settings_cache, _settings_authoritative, _settings_ready
    global _settings_authority_source, _settings_disk_snapshot
    global _settings_dirty, _pending_settings, _persistence_blocked_reason
    _settings_cache = copy.deepcopy(state)
    _settings_authoritative = True
    _settings_ready = bool(ready)
    _settings_authority_source = str(source)
    _settings_disk_snapshot = snapshot
    _settings_dirty = False
    _pending_settings = None
    _persistence_blocked_reason = ""
    _runtime_errors.pop("SETTINGS_NOT_READY", None)
    _publish_lifecycle_state()


def _trusted_state() -> dict[str, Any] | None:
    if _settings_authoritative and isinstance(_settings_cache, dict):
        return _settings_cache
    return None


def _cached_state_for_ui() -> dict[str, Any]:
    """Return trusted memory or an ephemeral default without disk access."""
    trusted = _trusted_state()
    return trusted if trusted is not None else _default_state()


def _settings_status() -> str:
    if _manager_registered and _settings_ready and _settings_authoritative:
        return PLACEMENT_STATUS_READY
    return PLACEMENT_STATUS_NOT_READY


def _settings_payload_write_allowed(
    state: dict[str, Any],
    *,
    write_authority: str,
) -> bool:
    """Reject ordinary disk writes while an authoritative save-OFF state exists."""
    if write_authority == _WRITE_AUTHORITY_VERIFIED_RECOVERY:
        return True
    trusted = _trusted_state()
    if not (_settings_authoritative and isinstance(trusted, dict)):
        return True
    save_before = bool(trusted.get("ui", {}).get("n_panel_state_save", True))
    save_after = bool(state.get("ui", {}).get("n_panel_state_save", True))
    if save_before and not save_after:
        return write_authority == _WRITE_AUTHORITY_SAVE_DISABLE
    if not save_before and save_after:
        return write_authority == _WRITE_AUTHORITY_SAVE_ENABLE
    if not save_before:
        return False
    return write_authority == _WRITE_AUTHORITY_ORDINARY


def _write_settings_payload_locked(
    state: dict[str, Any],
    path: Path | None = None,
    *,
    expected_disk_snapshot: object = _USE_GLOBAL_DISK_SNAPSHOT,
    mark_dirty_on_failure: bool = True,
    authority_source: str = "PRIMARY_WRITE",
    commit_source_id: str = "smart_tools_manager",
    commit_source_revision: int | None = None,
    write_authority: str = _WRITE_AUTHORITY_ORDINARY,
) -> bool:
    """Durably write one full matrix using primary+backup CAS protection."""
    global _settings_write_in_progress, _settings_cache, _settings_dirty
    global _settings_authoritative, _settings_ready, _settings_authority_source
    global _settings_disk_snapshot, _pending_settings, _persistence_blocked_reason

    if not _settings_payload_write_allowed(
        state,
        write_authority=write_authority,
    ):
        _runtime_errors["SETTINGS_WRITE_BLOCKED"] = (
            "Settings saving is OFF; the requested disk-write authority does not "
            "match an OFF self-commit, explicit ON transition, or verified recovery."
        )
        return False

    target = path or _settings_path()
    backup_path = _settings_backup_path(target)
    trusted_before = _trusted_state()
    matrix_before = (
        copy.deepcopy(trusted_before.get("matrix"))
        if isinstance(trusted_before, dict)
        else None
    )
    expected = (
        _settings_disk_snapshot
        if expected_disk_snapshot is _USE_GLOBAL_DISK_SNAPSHOT
        else expected_disk_snapshot
    )
    if _settings_write_in_progress:
        if mark_dirty_on_failure:
            _settings_dirty = True
            _pending_settings = copy.deepcopy(state)
        return False
    if not isinstance(expected, tuple) or len(expected) != 2:
        _runtime_errors["SETTINGS_CONFLICT"] = (
            "No verified primary/backup disk snapshot is available for CAS."
        )
        if mark_dirty_on_failure:
            _settings_dirty = True
            _pending_settings = copy.deepcopy(state)
        return False

    _settings_write_in_progress = True
    primary_original_token = expected[0]
    backup_original_token = expected[1]
    primary_original_bytes: bytes | None = None
    backup_original_bytes: bytes | None = None
    primary_written_token = None
    backup_written_token = None
    try:
        observed, primary, backup = _observe_disk_pair(target)
        if observed != expected:
            raise SettingsValidationError(
                "settings CAS conflict before write: expected "
                + _disk_snapshot_description(expected)
                + "; observed "
                + _disk_snapshot_description(observed)
            )
        if primary["kind"] == "unverified" or backup["kind"] == "unverified":
            raise SettingsValidationError(
                "refusing to overwrite an unverified primary or backup file"
            )

        primary_original_bytes = primary["bytes"]
        backup_original_bytes = backup["bytes"]
        payload, encoded = _serialize_state(state)

        # Rotate the exact verified primary to .bak.  With a missing primary,
        # retain an existing verified backup; on first creation establish the
        # new verified payload as backup before committing the primary.
        if primary["kind"] in _VERIFIED_DISK_KINDS:
            if backup["bytes"] != primary["bytes"]:
                _backup_state, _backup_kind, _backup_repair, backup_written_token = (
                    _cas_replace_verified_bytes(
                        backup_path,
                        primary["bytes"],
                        expected_token=backup_original_token,
                    )
                )
            else:
                backup_written_token = backup_original_token
        elif primary["kind"] == "missing":
            if backup["kind"] in _VERIFIED_DISK_KINDS:
                backup_written_token = backup_original_token
            elif backup["kind"] == "missing":
                _backup_state, _backup_kind, _backup_repair, backup_written_token = (
                    _cas_replace_verified_bytes(
                        backup_path,
                        encoded,
                        expected_token=backup_original_token,
                    )
                )
            else:
                raise SettingsValidationError("backup state is not writable")
        else:
            raise SettingsValidationError("primary state is not writable")

        # Recheck both files after backup staging and immediately before the
        # primary replacement.  This detects external updates during the write.
        rechecked, _re_primary, _re_backup = _observe_disk_pair(target)
        expected_after_backup = (primary_original_token, backup_written_token)
        if rechecked != expected_after_backup:
            raise SettingsValidationError(
                "settings CAS conflict after backup staging: expected "
                + _disk_snapshot_description(expected_after_backup)
                + "; observed "
                + _disk_snapshot_description(rechecked)
            )

        readback_state, readback_kind, readback_repair, primary_written_token = (
            _cas_replace_verified_bytes(
                target,
                encoded,
                expected_token=primary_original_token,
            )
        )
        if readback_kind != "current" or readback_repair:
            raise SettingsValidationError("final primary did not validate as current")
        if readback_state["checksum"] != payload["checksum"]:
            raise SettingsValidationError("final primary checksum changed")
        if readback_state["generation"] != payload["generation"]:
            raise SettingsValidationError("final primary generation changed")

        final_snapshot, final_primary, final_backup = _observe_disk_pair(target)
        if final_primary["token"] != primary_written_token:
            raise SettingsValidationError("primary changed after verified commit")
        if final_backup["token"] != backup_written_token:
            raise SettingsValidationError("backup changed after verified commit")

        _settings_cache = copy.deepcopy(readback_state)
        _settings_authoritative = True
        _settings_ready = True
        _settings_authority_source = str(authority_source)
        _settings_disk_snapshot = final_snapshot
        _settings_dirty = False
        _pending_settings = None
        _persistence_blocked_reason = ""
        for key in (
            "SETTINGS",
            "SETTINGS_BACKUP",
            "SETTINGS_RECOVERY",
            "SETTINGS_WRITE_BLOCKED",
            "SETTINGS_CONFLICT",
            "SETTINGS_UNREGISTER",
            "SETTINGS_NOT_READY",
        ):
            _runtime_errors.pop(key, None)
        _publish_lifecycle_state()
        if matrix_before != readback_state.get("matrix"):
            _notify_rule_matrix_commit(
                readback_state,
                source_id=commit_source_id,
                source_revision=commit_source_revision,
            )
        return True
    except Exception as exc:
        # Roll back only if each file still has the exact token written by this
        # call. A concurrent external edit is never overwritten by rollback.
        try:
            _restore_file_if_unchanged(
                target,
                expected_current_token=primary_written_token,
                original_token=primary_original_token,
                original_bytes=primary_original_bytes,
            )
        except Exception:
            _runtime_errors["SETTINGS_RECOVERY"] = traceback.format_exc(limit=6)
        try:
            _restore_file_if_unchanged(
                backup_path,
                expected_current_token=backup_written_token
                if backup_written_token != backup_original_token
                else None,
                original_token=backup_original_token,
                original_bytes=backup_original_bytes,
            )
        except Exception:
            _runtime_errors["SETTINGS_BACKUP_ROLLBACK"] = traceback.format_exc(limit=6)

        text = traceback.format_exc(limit=8)
        if isinstance(exc, SettingsValidationError) and (
            "CAS conflict" in str(exc) or "unverified" in str(exc)
        ):
            _runtime_errors["SETTINGS_CONFLICT"] = text
        else:
            _runtime_errors["SETTINGS"] = text
        if mark_dirty_on_failure:
            _settings_dirty = True
            _pending_settings = copy.deepcopy(state)
        _mark_not_ready(
            "The settings commit failed or disk identity changed. The last "
            "verified in-memory state was retained and stale memory did not "
            "overwrite the external file.",
            preserve_authority=bool(_settings_authoritative),
            source=(
                "LAST_KNOWN_AUTHORITATIVE"
                if _settings_authoritative
                else "NOT_READY"
            ),
            keep_disk_snapshot=True,
        )
        return False
    finally:
        _settings_write_in_progress = False


def _write_settings_payload(
    state: dict[str, Any],
    path: Path | None = None,
    *,
    expected_disk_snapshot: object = _USE_GLOBAL_DISK_SNAPSHOT,
    mark_dirty_on_failure: bool = True,
    authority_source: str = "PRIMARY_WRITE",
    commit_source_id: str = "smart_tools_manager",
    commit_source_revision: int | None = None,
    write_authority: str = _WRITE_AUTHORITY_ORDINARY,
) -> bool:
    """Run one complete primary/backup transaction under a process mutex."""
    global _settings_dirty, _pending_settings
    if not _settings_payload_write_allowed(
        state,
        write_authority=write_authority,
    ):
        _runtime_errors["SETTINGS_WRITE_BLOCKED"] = (
            "Settings saving is OFF; ordinary payload writers cannot acquire the "
            "settings lock or reach the durable writer."
        )
        return False
    target = path or _settings_path()
    try:
        with _settings_interprocess_lock(target):
            result = _write_settings_payload_locked(
                state,
                target,
                expected_disk_snapshot=expected_disk_snapshot,
                mark_dirty_on_failure=mark_dirty_on_failure,
                authority_source=authority_source,
                commit_source_id=commit_source_id,
                commit_source_revision=commit_source_revision,
                write_authority=write_authority,
            )
        if result:
            _runtime_errors.pop("SETTINGS_LOCK", None)
            _runtime_errors.pop("SETTINGS_LOCK_RELEASE", None)
        return result
    except (OSError, TimeoutError):
        _runtime_errors["SETTINGS_LOCK"] = traceback.format_exc(limit=6)
        if mark_dirty_on_failure:
            _settings_dirty = True
            _pending_settings = copy.deepcopy(state)
        _mark_not_ready(
            "The settings transaction lock could not be acquired. The last "
            "verified state was retained.",
            preserve_authority=bool(_settings_authoritative),
            source=(
                "LAST_KNOWN_AUTHORITATIVE"
                if _settings_authoritative
                else "NOT_READY"
            ),
            keep_disk_snapshot=True,
        )
        return False


def _repair_backup_from_verified_primary(
    target: Path,
    *,
    disk_snapshot,
    primary: dict[str, Any],
    backup: dict[str, Any],
) -> tuple[
    tuple[tuple[str, int, str, str, int], tuple[str, int, str, str, int]],
    dict[str, Any],
    dict[str, Any],
]:
    """Replace only a missing/unverified backup with the verified primary bytes.

    The primary token and backup token must still equal the one finite load
    observation.  No default state is serialized, and a concurrent primary or
    backup edit causes a NOT_READY result rather than an overwrite.
    """
    if primary.get("kind") not in _VERIFIED_DISK_KINDS or primary.get("bytes") is None:
        raise SettingsValidationError("backup repair requires a verified primary")
    if backup.get("kind") not in {"missing", "unverified"}:
        return disk_snapshot, primary, backup
    observed, observed_primary, observed_backup = _observe_disk_pair(target)
    if observed != disk_snapshot:
        raise SettingsValidationError(
            "settings CAS conflict before backup repair: expected "
            + _disk_snapshot_description(disk_snapshot)
            + "; observed "
            + _disk_snapshot_description(observed)
        )
    _state, _kind, _repair, written_token = _cas_replace_verified_bytes(
        _settings_backup_path(target),
        primary["bytes"],
        expected_token=backup["token"],
    )
    final_snapshot, final_primary, final_backup = _observe_disk_pair(target)
    if final_primary["token"] != primary["token"]:
        raise SettingsValidationError(
            "primary changed while repairing the settings backup"
        )
    if final_backup["token"] != written_token:
        raise SettingsValidationError(
            "backup changed after verified backup repair"
        )
    _runtime_errors.pop("SETTINGS_BACKUP", None)
    return final_snapshot, final_primary, final_backup


def _recover_primary_from_backup(
    target: Path,
    *,
    disk_snapshot,
    primary: dict[str, Any],
    backup: dict[str, Any],
) -> bool:
    """Recover a verified backup through an exact primary-token CAS."""
    if backup["kind"] not in _VERIFIED_DISK_KINDS or backup["state"] is None:
        return False
    recovered_state = copy.deepcopy(backup["state"])
    if backup["kind"] in _MIGRATABLE_DISK_KINDS or backup["needs_repair"]:
        _advance_generation(recovered_state)
        _payload, payload_bytes = _serialize_state(recovered_state)
    else:
        payload_bytes = backup["bytes"]
    readback_state, readback_kind, readback_repair, _primary_token = (
        _cas_replace_verified_bytes(
            target,
            payload_bytes,
            expected_token=primary["token"],
        )
    )
    if readback_kind != "current" or readback_repair:
        raise SettingsValidationError("backup recovery did not create a current primary")
    final_snapshot, final_primary, final_backup = _observe_disk_pair(target)
    if final_primary["kind"] != "current" or final_backup["token"] != backup["token"]:
        raise SettingsValidationError("backup recovery final identity mismatch")
    _adopt_verified_state(
        readback_state,
        snapshot=final_snapshot,
        source="BACKUP_RECOVERY",
        ready=True,
    )
    _runtime_errors.pop("SETTINGS", None)
    _runtime_errors.pop("SETTINGS_BACKUP", None)
    return True


def _load_settings_from_disk_locked(*, force: bool = False) -> dict[str, Any]:
    """Perform one finite disk load at register/load_post/explicit reload.

    Failure preserves the *exact* prior authority flag.  A non-None Python dict,
    an ephemeral default, or an unverified prior cache is never promoted merely
    because ``force=True`` is called repeatedly.
    """
    global _settings_cache, _settings_authoritative, _settings_ready
    global _settings_authority_source, _settings_disk_snapshot
    global _settings_dirty, _pending_settings, _persistence_blocked_reason
    global _settings_load_attempted

    if _settings_load_attempted and not force:
        return _cached_state_for_ui()

    prior_state = (
        copy.deepcopy(_settings_cache)
        if _settings_authoritative and isinstance(_settings_cache, dict)
        else None
    )
    prior_authority = bool(_settings_authoritative)
    prior_source = str(_settings_authority_source)
    prior_dirty = bool(_settings_dirty)
    prior_pending = (
        copy.deepcopy(_pending_settings)
        if isinstance(_pending_settings, dict)
        else None
    )
    target = _settings_path()
    snapshot, primary, backup = _observe_disk_pair(target)
    _settings_load_attempted = True

    backup_repair_failed = False
    if (
        primary["kind"] in _VERIFIED_DISK_KINDS
        and primary["state"] is not None
        and backup["kind"] in {"missing", "unverified"}
    ):
        try:
            snapshot, primary, backup = _repair_backup_from_verified_primary(
                target,
                disk_snapshot=snapshot,
                primary=primary,
                backup=backup,
            )
        except Exception:
            backup_repair_failed = True
            _runtime_errors["SETTINGS_BACKUP"] = traceback.format_exc(limit=8)

    if primary["kind"] in _VERIFIED_DISK_KINDS and primary["state"] is not None:
        if backup_repair_failed:
            _settings_cache = copy.deepcopy(primary["state"])
            _settings_authoritative = True
            _settings_ready = False
            _settings_authority_source = "LAST_KNOWN_VERIFIED_PRIMARY"
            _settings_disk_snapshot = None
            _settings_dirty = prior_dirty
            _pending_settings = prior_pending
            _persistence_blocked_reason = (
                "The primary settings payload is verified, but the missing or "
                "invalid backup could not be repaired. Writes are blocked until "
                "a finite reload verifies both disk identities."
            )
            return _cached_state_for_ui()
        state = copy.deepcopy(primary["state"])
        if primary["kind"] in _MIGRATABLE_DISK_KINDS or primary["needs_repair"]:
            _settings_disk_snapshot = snapshot
            _persistence_blocked_reason = ""
            migrated = copy.deepcopy(state)
            _advance_generation(migrated)
            if _write_settings_payload(
                migrated,
                target,
                expected_disk_snapshot=snapshot,
                mark_dirty_on_failure=False,
                authority_source="PRIMARY_MIGRATION",
                write_authority=_WRITE_AUTHORITY_VERIFIED_RECOVERY,
            ):
                return _cached_state_for_ui()
            # The parsed primary itself remains a verified last-known state.
            _settings_cache = state
            _settings_authoritative = True
            _settings_ready = False
            _settings_authority_source = "LAST_KNOWN_VERIFIED_PRIMARY"
            _settings_disk_snapshot = snapshot
            _settings_dirty = False
            _pending_settings = None
            return _cached_state_for_ui()

        _adopt_verified_state(
            state,
            snapshot=snapshot,
            source="PRIMARY",
            ready=True,
        )
        return _cached_state_for_ui()

    if backup["kind"] in _VERIFIED_DISK_KINDS and backup["state"] is not None:
        try:
            if _recover_primary_from_backup(
                target,
                disk_snapshot=snapshot,
                primary=primary,
                backup=backup,
            ):
                return _cached_state_for_ui()
        except Exception:
            _runtime_errors["SETTINGS_BACKUP"] = traceback.format_exc(limit=8)
        # The backup remains independently verified even if restoring primary
        # failed due to I/O or a concurrent primary edit.
        _settings_cache = copy.deepcopy(backup["state"])
        _settings_authoritative = True
        _settings_ready = False
        _settings_authority_source = "LAST_KNOWN_VERIFIED_BACKUP"
        _settings_disk_snapshot = None
        _settings_dirty = False
        _pending_settings = None
        _persistence_blocked_reason = (
            "A verified backup is available in memory, but primary recovery did "
            "not complete. Writes are blocked until a new finite reload succeeds."
        )
        return _cached_state_for_ui()

    # Neither candidate is verified. Preserve prior authority exactly; never use
    # bool(previous) as a trust decision and never manufacture a default file.
    if prior_authority and prior_state is not None:
        _settings_cache = prior_state
        _settings_authoritative = True
        prior_label = (
            prior_source
            if prior_source not in {"", "UNINITIALIZED", "NOT_READY"}
            else "VERIFIED_MEMORY"
        )
        _settings_authority_source = f"LAST_KNOWN_AUTHORITATIVE:{prior_label}"
    else:
        _settings_authoritative = False
        if not isinstance(_settings_cache, dict) or prior_state is None:
            _settings_cache = None
        _settings_authority_source = "NOT_READY"
    _settings_ready = False
    _settings_disk_snapshot = snapshot
    # A failed finite reload is not permission to discard a previously queued
    # CAS-protected user edit.  Retain the exact dirty/pending pair; any later
    # save still rechecks the newly observed primary+backup identity and cannot
    # overwrite an external update.
    _settings_dirty = prior_dirty
    _pending_settings = prior_pending

    both_missing = (
        primary["token"] == _MISSING_DISK_TOKEN
        and backup["token"] == _MISSING_DISK_TOKEN
    )
    if both_missing:
        _persistence_blocked_reason = ""
        _runtime_errors.pop("SETTINGS_NOT_READY", None)
    else:
        _persistence_blocked_reason = (
            "Neither primary nor backup passed strict JSON/schema/type/checksum "
            "validation. Existing files were not overwritten."
        )
        if primary["error"]:
            _runtime_errors["SETTINGS"] = primary["error"]
        if backup["error"]:
            _runtime_errors["SETTINGS_BACKUP"] = backup["error"]
    return _cached_state_for_ui()


def _migrate_legacy_settings_file_once() -> None:
    target = _settings_path()
    legacy = _legacy_settings_path()
    if target.exists() or not legacy.is_file():
        return
    try:
        state, _kind, _needs_repair = _parse_settings_bytes(legacy.read_bytes())
    except (SettingsValidationError, OSError):
        # Broken or empty legacy file: leave it untouched and start from defaults.
        return
    _payload, encoded = _serialize_state(state)
    temp_path = _write_unique_temp(target.parent, target.name, encoded)
    try:
        _atomic_replace(temp_path, target)
        _fsync_directory(target.parent)
    finally:
        temp_path.unlink(missing_ok=True)


def _load_settings_from_disk(*, force: bool = False) -> dict[str, Any]:
    """Observe, migrate, and recover settings under the same process mutex."""
    target = _settings_path()
    try:
        with _settings_interprocess_lock(target):
            _migrate_legacy_settings_file_once()
            result = _load_settings_from_disk_locked(force=force)
        _runtime_errors.pop("SETTINGS_LOCK", None)
        _runtime_errors.pop("SETTINGS_LOCK_RELEASE", None)
        return result
    except (OSError, TimeoutError):
        _runtime_errors["SETTINGS_LOCK"] = traceback.format_exc(limit=6)
        _mark_not_ready(
            "The settings transaction lock could not be acquired. The last "
            "verified state was retained.",
            preserve_authority=bool(_settings_authoritative),
            source=(
                "LAST_KNOWN_AUTHORITATIVE"
                if _settings_authoritative
                else "NOT_READY"
            ),
            keep_disk_snapshot=True,
        )
        return _cached_state_for_ui()


def _reload_settings_from_file(
    *,
    sync_props: bool = True,
    reset_draft: bool = True,
) -> dict[str, Any]:
    del reset_draft
    data = _load_settings_from_disk(force=True)
    if sync_props:
        _sync_properties_from_settings(_manager_props(bpy.context))
    return data


def _save_settings(*, force: bool = False, capture_rna: bool = True) -> bool:
    del force, capture_rna
    if not _settings_dirty:
        return True
    if not isinstance(_pending_settings, dict):
        return False
    trusted = _trusted_state()
    save_before = bool(
        trusted.get("ui", {}).get("n_panel_state_save", True)
    ) if isinstance(trusted, dict) else True
    save_after = bool(
        _pending_settings.get("ui", {}).get("n_panel_state_save", True)
    )
    if not save_before and not save_after:
        return True
    write_authority = _WRITE_AUTHORITY_ORDINARY
    if save_before and not save_after:
        write_authority = _WRITE_AUTHORITY_SAVE_DISABLE
    elif not save_before and save_after:
        write_authority = _WRITE_AUTHORITY_SAVE_ENABLE
    return _write_settings_payload(
        copy.deepcopy(_pending_settings),
        _settings_path(),
        write_authority=write_authority,
    )


def _state_semantic_payload(state: dict[str, Any] | None = None) -> dict[str, Any]:
    source = state if isinstance(state, dict) else _cached_state_for_ui()
    return {
        "matrix": copy.deepcopy(source.get("matrix", {})),
        "selection": copy.deepcopy(source.get("selection", {})),
        "ui": copy.deepcopy(source.get("ui", {})),
        "runtime": copy.deepcopy(source.get("runtime", {})),
    }


def _state_semantic_text(state: dict[str, Any] | None = None) -> str:
    return json.dumps(
        _state_semantic_payload(state),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )


def _advance_generation(state: dict[str, Any]) -> None:
    state["generation"] = int(state.get("generation", 0)) + 1
    state["extension_version"] = VERSION_TEXT
    state["checksum"] = ""


def _commit_settings_mutation(
    mutation,
    *,
    authority_source: str,
    commit_source_id: str = "smart_tools_manager",
    commit_source_revision: int | None = None,
) -> tuple[bool, bool, dict[str, Any]]:
    """Commit one user intent against the latest verified disk generation.

    Multiple Blender processes may keep independent in-memory snapshots.  A
    conflicting writer is handled by one finite reload followed by replaying
    only this mutation, never by overwriting the newer full matrix.
    """
    last_state = copy.deepcopy(_cached_state_for_ui())
    for attempt in range(SETTINGS_COMMIT_RETRY_LIMIT):
        current = copy.deepcopy(_cached_state_for_ui())
        state = copy.deepcopy(current)
        save_before = bool(current.get("ui", {}).get("n_panel_state_save", True))
        try:
            mutation(state)
        except Exception:
            _runtime_errors["SETTINGS_MUTATION"] = traceback.format_exc(limit=6)
            return False, False, last_state
        last_state = state
        if _state_semantic_text(state) == _state_semantic_text(current):
            _runtime_errors.pop("SETTINGS_MUTATION", None)
            return True, False, current
        _advance_generation(state)
        save_after = bool(state.get("ui", {}).get("n_panel_state_save", True))
        if not save_before and not save_after:
            _adopt_verified_state(
                state,
                snapshot=_settings_disk_snapshot,
                source="MEMORY_SAVE_DISABLED",
            )
            if current.get("matrix") != state.get("matrix"):
                _notify_rule_matrix_commit(
                    state,
                    source_id=commit_source_id,
                    source_revision=commit_source_revision,
                )
            return True, True, copy.deepcopy(_cached_state_for_ui())
        write_authority = _WRITE_AUTHORITY_ORDINARY
        if save_before and not save_after:
            write_authority = _WRITE_AUTHORITY_SAVE_DISABLE
        elif not save_before and save_after:
            write_authority = _WRITE_AUTHORITY_SAVE_ENABLE
        if _write_settings_payload(
            state,
            authority_source=authority_source,
            commit_source_id=commit_source_id,
            commit_source_revision=commit_source_revision,
            write_authority=write_authority,
        ):
            _runtime_errors.pop("SETTINGS_MUTATION", None)
            return True, True, copy.deepcopy(_cached_state_for_ui())
        if attempt + 1 < SETTINGS_COMMIT_RETRY_LIMIT:
            time.sleep(0.025 * (attempt + 1))
            _load_settings_from_disk(force=True)
    return False, False, last_state


def _immediate_workspace_sync_enabled(state: dict[str, Any]) -> bool:
    runtime = state.get("runtime", {})
    return bool(
        runtime.get("automatic_context_sync", False)
        and runtime.get("source_panel_filters", False)
    )


def _normalize_tool_key(tool_key: Any) -> str:
    raw = str(tool_key or "").strip().upper()
    return _LEGACY_TOOL_KEY_MAP.get(raw, raw)


def _rule_value(workspace_key: str, editor_key: str, tool_key: str) -> bool:
    """Read one cached cell; this function never touches disk or Blender UI."""
    workspace_key = str(workspace_key or "").strip().upper()
    editor_key = str(editor_key or "").strip().upper()
    tool_key = _normalize_tool_key(tool_key)
    if workspace_key not in _WORKSPACE_KEYS:
        return False
    if editor_key not in _EDITOR_KEYS:
        return False
    if tool_key not in _TOOL_BY_KEY:
        return False
    state = _trusted_state()
    if state is None:
        return True
    try:
        return state["matrix"][workspace_key][editor_key][tool_key] is True
    except Exception:
        # A claimed authoritative cache that cannot answer an explicit known
        # cell fails closed. Unavailable/unverified Manager state fails open in
        # get_placement_state before this helper is used.
        return False


class RuleMatrixSnapshot(dict):
    """Detached matrix with explicit READY/NOT_READY metadata.

    It remains a ``dict`` for compatibility with v1.5.55 callers. Mutating it
    never changes Manager state. When no verified state exists, it is empty and
    ``status`` is ``NOT_READY``; defaults are never returned as authority.
    """

    def __init__(self, matrix: dict[str, Any], metadata: dict[str, Any]) -> None:
        super().__init__(matrix)
        self.status = metadata["status"]
        self.ready = metadata["ready"]
        self.authoritative = metadata["authoritative"]
        self.used_last_known_state = metadata["used_last_known_state"]
        self.generation = metadata["generation"]
        self.authority_source = metadata["authority_source"]
        self.metadata = MappingProxyType(dict(metadata))


def _placement_snapshot_metadata(*, cache_valid: bool = True) -> dict[str, Any]:
    state = _trusted_state()
    declared_authority = bool(state is not None)
    usable_authority = bool(declared_authority and cache_valid)
    try:
        generation = int(state.get("generation", 0) or 0) if usable_authority else 0
    except Exception:
        generation = 0
        cache_valid = False
        usable_authority = False
    ready = bool(
        _manager_registered
        and _settings_ready
        and usable_authority
    )
    return {
        "api_version": PLACEMENT_API_VERSION,
        "status": PLACEMENT_STATUS_READY if ready else PLACEMENT_STATUS_NOT_READY,
        "ready": ready,
        "authoritative": usable_authority,
        "declared_authoritative_cache": declared_authority,
        "cache_valid": bool(cache_valid),
        "used_last_known_state": bool(
            usable_authority and not ready
        ),
        "generation": generation,
        "authority_source": str(_settings_authority_source),
        "matrix_cells": MATRIX_CELL_COUNT if usable_authority else 0,
    }


def get_rule_matrix_snapshot() -> RuleMatrixSnapshot:
    """Return a pure cached snapshot with explicit status metadata.

    No file read/stat, migration, repair, backup restore, default creation,
    dirty mutation, timer, redraw, registration, or RNA/UI mutation can occur.
    The detached matrix is strictly revalidated in memory; an impossible cache
    corruption returns an empty NOT_READY snapshot instead of raising or
    manufacturing defaults.
    """
    state = _trusted_state()
    if state is None:
        return RuleMatrixSnapshot({}, _placement_snapshot_metadata(cache_valid=True))
    try:
        matrix = _validate_matrix(copy.deepcopy(state["matrix"]))
    except Exception:
        return RuleMatrixSnapshot({}, _placement_snapshot_metadata(cache_valid=False))
    return RuleMatrixSnapshot(matrix, _placement_snapshot_metadata(cache_valid=True))


def get_rule_matrix_state() -> dict[str, Any]:
    """Return status plus the detached cached matrix as a plain mapping."""
    snapshot = get_rule_matrix_snapshot()
    return {
        **dict(snapshot.metadata),
        "matrix": snapshot,
    }


def get_catalog_snapshot() -> dict[str, Any]:
    """Return immutable key order without disk or Blender state access."""
    return {
        "workspaces": _WORKSPACE_ORDER,
        "editors": _EDITOR_ORDER,
        "tools": _TOOL_ORDER,
        "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
    }


def _matrix_sha256(matrix: dict[str, Any]) -> str:
    normalized = _validate_matrix(copy.deepcopy(matrix))
    raw = json.dumps(
        normalized,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _runtime_api_revision() -> int:
    state = _trusted_state()
    try:
        return int(state.get("generation", 0) or 0) if state is not None else 0
    except Exception:
        return 0


def get_current_cell_rule(
    workspace_key: str,
    editor_key: str,
    tool_key: str,
) -> dict[str, Any]:
    """Return one generation/revision-bound authoritative cell decision."""
    runtime_generation = str(_registration_token or "")
    manager_revision = _runtime_api_revision()
    ready = bool(
        _manager_registered
        and runtime_generation
        and _settings_authoritative
        and isinstance(_trusted_state(), dict)
    )
    return {
        "status": "READY" if ready else "NOT_READY",
        "generation": runtime_generation,
        "revision": manager_revision,
        "enabled": bool(_rule_value(workspace_key, editor_key, tool_key)) if ready else True,
        "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
    }


def apply_rule_matrix(
    matrix: dict[str, Any],
    *,
    source_revision: int,
    runtime_generation: str,
    expected_manager_revision: int,
    source_id: str = "external",
) -> dict[str, Any]:
    """CAS-apply one exact 16 x 17 x 21 Suite matrix and verify readback."""
    current_runtime_generation = str(_registration_token or "")
    current_revision = _runtime_api_revision()
    result = {
        "ok": False,
        "status": "NOT_READY",
        "api_revision": RULE_MATRIX_WRITE_API_REVISION,
        "runtime_generation": current_runtime_generation,
        "previous_manager_revision": current_revision,
        "manager_revision": current_revision,
        "source_revision": source_revision,
        "source_id": str(source_id or ""),
        "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
    }
    if (
        not _manager_registered
        or not current_runtime_generation
        or str(runtime_generation or "") != current_runtime_generation
    ):
        result["status"] = "RUNTIME_GENERATION_MISMATCH"
        return result
    if type(source_revision) is not int or source_revision < 0:
        result["status"] = "INVALID_SOURCE_REVISION"
        return result
    if (
        type(expected_manager_revision) is not int
        or expected_manager_revision < 0
        or expected_manager_revision != current_revision
    ):
        result["status"] = "MANAGER_REVISION_MISMATCH"
        return result
    source_text = str(source_id or "").strip()
    if not source_text or len(source_text) > 160:
        result["status"] = "INVALID_SOURCE_ID"
        return result
    try:
        normalized = _validate_matrix(copy.deepcopy(matrix))
    except Exception as exc:
        result["status"] = "INVALID_MATRIX"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    state = copy.deepcopy(_cached_state_for_ui())
    if state.get("matrix") == normalized:
        snapshot = get_rule_matrix_snapshot()
        if dict(snapshot) != normalized:
            result["status"] = "READBACK_MISMATCH"
            return result
        result.update({
            "ok": True,
            "status": "UNCHANGED",
            "committed": False,
            "matrix_sha256": _matrix_sha256(normalized),
        })
        return result

    def mutation(candidate_state):
        candidate_state["matrix"] = copy.deepcopy(normalized)

    ok, committed, state = _commit_settings_mutation(
        mutation,
        authority_source="EXTERNAL_MATRIX_APPLY",
        commit_source_id=source_text,
        commit_source_revision=source_revision,
    )
    if not ok:
        result["status"] = "COMMIT_FAILED"
        return result
    snapshot = get_rule_matrix_snapshot()
    new_revision = int(getattr(snapshot, "generation", 0) or 0)
    if (
        dict(snapshot) != normalized
        or new_revision != int(state.get("generation", -1))
        or str(_registration_token or "") != current_runtime_generation
    ):
        result["status"] = "READBACK_MISMATCH"
        result["manager_revision"] = new_revision
        return result
    _sync_properties_from_settings(_manager_props(getattr(bpy, "context", None)))
    _sync_workspace_owner_filters(context=getattr(bpy, "context", None))
    _update_runtime_status(getattr(bpy, "context", None))
    result.update({
        "ok": True,
        "status": "COMMITTED",
        "committed": committed,
        "manager_revision": new_revision,
        "matrix_sha256": _matrix_sha256(normalized),
    })
    return result


def subscribe_rule_matrix_commits(
    subscriber_id: str,
    callback,
    *,
    runtime_generation: str,
    subscriber_generation: str = "",
) -> dict[str, Any]:
    """Subscribe one callback to verified commits for this exact runtime."""
    record = _current_runtime_api_record()
    subscriber_key = str(subscriber_id or "").strip()
    if (
        record is None
        or str(runtime_generation or "") != str(record.get("generation") or "")
        or not subscriber_key
        or len(subscriber_key) > 200
        or not callable(callback)
    ):
        return {
            "ok": False,
            "status": "NOT_READY_OR_INVALID",
            "runtime_generation": str(_registration_token or ""),
            "manager_revision": _runtime_api_revision(),
        }
    subscribers = record.setdefault("subscribers", {})
    subscribers[subscriber_key] = {
        "callback": callback,
        "subscriber_generation": str(subscriber_generation or ""),
    }
    return {
        "ok": True,
        "status": "SUBSCRIBED",
        "runtime_generation": str(record.get("generation") or ""),
        "manager_revision": int(record.get("revision") or 0),
    }


def unsubscribe_rule_matrix_commits(
    subscriber_id: str,
    *,
    runtime_generation: str,
    callback=None,
) -> dict[str, Any]:
    """Remove only an exact subscription owned by the requested runtime."""
    record = _current_runtime_api_record()
    subscriber_key = str(subscriber_id or "").strip()
    if (
        record is None
        or str(runtime_generation or "") != str(record.get("generation") or "")
    ):
        return {"ok": False, "status": "RUNTIME_GENERATION_MISMATCH"}
    subscribers = record.setdefault("subscribers", {})
    existing = subscribers.get(subscriber_key)
    if not isinstance(existing, dict):
        return {"ok": True, "status": "ALREADY_ABSENT"}
    if callback is not None and existing.get("callback") is not callback:
        return {"ok": False, "status": "CALLBACK_IDENTITY_MISMATCH"}
    subscribers.pop(subscriber_key, None)
    return {"ok": True, "status": "UNSUBSCRIBED"}


def _notify_rule_matrix_commit(
    state: dict[str, Any],
    *,
    source_id: str,
    source_revision: int | None,
) -> None:
    """Notify subscribers only after a verified settings readback."""
    if not isinstance(state, dict):
        return
    try:
        record = _current_runtime_api_record()
        if record is None:
            return
        manager_revision = int(state.get("generation", 0) or 0)
        record["revision"] = manager_revision
        matrix = _validate_matrix(copy.deepcopy(state.get("matrix")))
        event = {
            "schema": "jelararagi.smart_tools_manager.rule_matrix_commit",
            "api_revision": RULE_MATRIX_WRITE_API_REVISION,
            "runtime_generation": str(record.get("generation") or ""),
            "manager_revision": manager_revision,
            "source_id": str(source_id or "smart_tools_manager"),
            "source_revision": (
                int(source_revision)
                if type(source_revision) is int and source_revision >= 0
                else None
            ),
            "matrix_sha256": _matrix_sha256(matrix),
            "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
        }
        failures = []
        for subscriber_id, item in tuple(record.get("subscribers", {}).items()):
            callback = item.get("callback") if isinstance(item, dict) else None
            if not callable(callback):
                failures.append(str(subscriber_id))
                continue
            try:
                callback(copy.deepcopy(event))
            except Exception:
                failures.append(str(subscriber_id))
        if failures:
            _runtime_errors["RULE_MATRIX_COMMIT_SUBSCRIBER"] = (
                "Commit notification failed for: " + ", ".join(failures[:16])
            )
        else:
            _runtime_errors.pop("RULE_MATRIX_COMMIT_SUBSCRIBER", None)
    except Exception:
        _runtime_errors["RULE_MATRIX_COMMIT_SUBSCRIBER"] = traceback.format_exc(limit=4)


def get_placement_contract() -> MappingProxyType:
    """Return the stable Suite-owned root Panel integration contract.

    * Every Suite owns/registers its root Panels and categories.
    * Each root ``Panel.poll`` calls ``placement_allowed`` with its exact tool
      key and expected logical editor.
    * Individual Panel visibility uses the current logical-editor cell.
    * ``workspace_tool_allowed`` is only for whole-Suite owner-filter/runtime
      retention: any ON editor keeps the owner available; it is not a Panel
      visibility decision.
    * All decision/snapshot calls are pure cached reads.
    * Invalid catalog keys, known editor mismatch, or trusted-cache corruption
      fail closed. Manager inactive/NOT_READY without verified state, custom
      workspace, or temporarily unresolved context fails open.
    * NOT_READY with a verified last-known state uses that exact matrix and
      reports ``used_last_known_state=True``.
    """
    return MappingProxyType(
        {
            "api_version": PLACEMENT_API_VERSION,
            "status_values": (
                PLACEMENT_STATUS_READY,
                PLACEMENT_STATUS_NOT_READY,
            ),
            "workspaces": _WORKSPACE_ORDER,
            "logical_editors": _EDITOR_ORDER,
            "physical_spaces": PHYSICAL_SPACE_TYPES,
            "tools": _TOOL_ORDER,
            "matrix_cells": MATRIX_CELL_COUNT,
            "policy": PLACEMENT_POLICY,
            "pure_decision_snapshot_api": PURE_PLACEMENT_API_NAMES,
            "compatibility_action_api": COMPATIBILITY_ACTION_API_NAMES,
            "persistence_boundaries": PERSISTENCE_BOUNDARY_NAMES,
            "suite_owns_root_panels": True,
            "manager_proxies_panels": False,
            "panel_poll_uses_current_logical_editor_cell": True,
            "workspace_owner_filter_any_editor_on_only": True,
            "poll_and_snapshot_are_pure_cached_reads": True,
        }
    )


def _normalize_enum_text(value: Any) -> str:
    try:
        identifier = getattr(value, "identifier", None)
        if identifier:
            return str(identifier).strip().upper()
    except Exception:
        pass
    try:
        return str(value or "").strip().upper()
    except Exception:
        return ""


def _active_space_for_area(area):
    if area is None:
        return None
    try:
        return getattr(getattr(area, "spaces", None), "active", None)
    except Exception:
        return None


def _value_text(value: Any, *names: str) -> str:
    if value is None:
        return ""
    for name in names:
        try:
            text = _normalize_enum_text(getattr(value, name, None))
        except Exception:
            text = ""
        if text:
            return text
    return ""


def editor_key_from_area(area, space=None) -> str | None:
    """Map exactly 11 physical Blender spaces to 17 logical editors."""
    space = space or _active_space_for_area(area)
    area_type = _value_text(area, "type")
    space_type = _value_text(space, "type")
    physical = space_type or area_type
    area_ui = _value_text(area, "ui_type")
    space_ui = _value_text(space, "ui_type")

    if physical == "VIEW_3D":
        return "VIEW_3D"
    if physical == "IMAGE_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        uv_tokens = {"UV", "UV_EDIT", "UVS", "UV_EDITOR"}
        return "UV_EDITOR" if {mode, area_ui, space_ui}.intersection(uv_tokens) else "IMAGE_EDITOR"
    if physical == "NODE_EDITOR":
        tree = _value_text(space, "tree_type")
        tokens = {tree, area_ui, space_ui}
        if tokens.intersection({"SHADERNODETREE", "SHADER", "SHADER_NODE_TREE", "SHADER_EDITOR"}):
            return "SHADER_EDITOR"
        if tokens.intersection({"COMPOSITORNODETREE", "COMPOSITOR", "COMPOSITOR_NODE_TREE", "COMPOSITING"}):
            return "COMPOSITOR"
        if tokens.intersection({"GEOMETRYNODETREE", "GEOMETRY", "GEOMETRY_NODE_TREE", "GEOMETRY_NODES", "GEOMETRY_NODE_EDITOR"}):
            return "GEOMETRY_NODE_EDITOR"
        if tokens.intersection({"TEXTURENODETREE", "TEXTURE", "TEXTURE_NODE_TREE", "TEXTURE_NODE_EDITOR"}):
            return "TEXTURE_NODE_EDITOR"
        return None
    if physical == "SEQUENCE_EDITOR":
        # Both SEQUENCER and PREVIEW surfaces are valid Video Sequencer areas.
        return "VIDEO_SEQUENCER"
    if physical == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if physical == "DOPESHEET_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        if {mode, area_ui, space_ui}.intersection({"TIMELINE", "DRIVER", "DRIVERS"}):
            return None
        return "DOPE_SHEET"
    if physical == "GRAPH_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        return "DRIVERS" if {mode, area_ui, space_ui}.intersection({"DRIVER", "DRIVERS"}) else "GRAPH_EDITOR"
    if physical == "NLA_EDITOR":
        return "NLA_EDITOR"
    if physical == "TEXT_EDITOR":
        return "TEXT_EDITOR"
    if physical == "FILE_BROWSER":
        browse = _value_text(space, "browse_mode", "mode")
        params = getattr(space, "params", None) if space is not None else None
        params_browse = _value_text(params, "browse_mode")
        return "ASSET_BROWSER" if {browse, params_browse, area_ui, space_ui}.intersection({"ASSETS", "ASSET_BROWSER"}) else "FILE_BROWSER"
    if physical == "SPREADSHEET":
        return "SPREADSHEET"
    return None


def _area_matches_editor(area, editor_key: str) -> bool:
    return editor_key_from_area(area) == editor_key


def _editor_keys_for_area_cached(area) -> tuple[str, ...]:
    key = editor_key_from_area(area)
    return (key,) if key else tuple()


def _visible_editor_keys_for_screen(screen) -> set[str]:
    result: set[str] = set()
    for area in tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ():
        key = editor_key_from_area(area)
        if key:
            result.add(key)
    return result


def _context_editor_key(context=None) -> str | None:
    context = context or bpy.context
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    key = editor_key_from_area(area, space)
    if key:
        return key
    screen = getattr(context, "screen", None)
    if screen is None:
        screen = getattr(getattr(context, "window", None), "screen", None)
    visible = _visible_editor_keys_for_screen(screen)
    return next(iter(visible)) if len(visible) == 1 else None


def _workspace_key_from_name(name: str) -> str | None:
    text = str(name or "").strip()
    if not text:
        return None
    lowered = text.casefold()
    for key, _en, _ja, aliases in _WORKSPACE_ITEMS:
        if text == key:
            return key
        for alias in aliases:
            if lowered == str(alias).casefold():
                return key
    return None


def _active_workspace_key(context=None) -> str | None:
    context = context or bpy.context
    for workspace in (
        getattr(context, "workspace", None),
        getattr(getattr(context, "window", None), "workspace", None),
    ):
        key = _workspace_key_from_name(getattr(workspace, "name", ""))
        if key:
            return key
    return None


def logical_editor_key_from_context(context=None) -> str | None:
    """Return the exact cached-free logical editor classification for context."""
    return _context_editor_key(context)


def get_placement_state(
    tool_key: str,
    context=None,
    *,
    workspace_key: str | None = None,
    editor_key: str | None = None,
) -> dict[str, Any]:
    """Return one pure cached placement decision for a Suite-owned Panel.

    The function does not read/stat/write files, migrate settings, restore a
    backup, create defaults, mutate dirty state, start a timer, request redraw,
    register RNA/UI, or touch another Suite lifecycle.
    """
    normalized_tool = _normalize_tool_key(tool_key)
    explicit_workspace = workspace_key is not None and bool(str(workspace_key).strip())
    explicit_editor = editor_key is not None and bool(str(editor_key).strip())
    requested_workspace = str(workspace_key or "").strip().upper()
    requested_editor = str(editor_key or "").strip().upper()
    trusted = _trusted_state()
    generation = int(trusted.get("generation", 0) or 0) if trusted is not None else 0

    base = {
        "api_version": PLACEMENT_API_VERSION,
        "status": _settings_status(),
        "manager_active": bool(_manager_registered),
        "ready": bool(_manager_registered and _settings_ready and trusted is not None),
        "authoritative": bool(trusted is not None),
        "authority_source": str(_settings_authority_source),
        "used_last_known_state": bool(
            trusted is not None and not (_manager_registered and _settings_ready)
        ),
        "tool_key": normalized_tool,
        "workspace_key": requested_workspace or None,
        "editor_key": requested_editor or None,
        "context_editor_key": None,
        "editor_matches_context": True,
        "explicit": False,
        "generation": generation,
        "allowed": True,
        "reason": "not_ready_without_verified_state_fail_open",
        "policy": "FAIL_OPEN",
    }

    # Invalid integration keys are deterministic contract violations.
    if normalized_tool not in _TOOL_BY_KEY:
        base.update(allowed=False, reason="invalid_tool_key", policy="FAIL_CLOSED")
        return base
    if explicit_workspace and requested_workspace not in _WORKSPACE_KEYS:
        base.update(allowed=False, reason="invalid_workspace_key", policy="FAIL_CLOSED")
        return base
    if explicit_editor and requested_editor not in _EDITOR_KEYS:
        base.update(allowed=False, reason="invalid_editor_key", policy="FAIL_CLOSED")
        return base

    context = context if context is not None else getattr(bpy, "context", None)
    try:
        resolved_workspace = requested_workspace or _active_workspace_key(context)
        context_editor = _context_editor_key(context)
    except Exception:
        base.update(
            allowed=True,
            reason="context_resolution_exception_fail_open",
            policy="FAIL_OPEN",
        )
        return base

    resolved_editor = requested_editor or context_editor
    base["workspace_key"] = resolved_workspace
    base["editor_key"] = resolved_editor
    base["context_editor_key"] = context_editor

    editor_mismatch = bool(
        requested_editor in _EDITOR_KEYS
        and context_editor in _EDITOR_KEYS
        and requested_editor != context_editor
    )
    base["editor_matches_context"] = not editor_mismatch
    if editor_mismatch:
        base.update(
            allowed=False,
            reason="logical_editor_mismatch",
            policy="FAIL_CLOSED",
        )
        return base

    if resolved_workspace not in _WORKSPACE_KEYS:
        base.update(
            allowed=True,
            reason="unresolved_or_custom_workspace_fail_open",
            policy="FAIL_OPEN",
        )
        return base
    if resolved_editor not in _EDITOR_KEYS:
        base.update(
            allowed=True,
            reason="unresolved_logical_editor_fail_open",
            policy="FAIL_OPEN",
        )
        return base
    if not _manager_registered:
        base.update(
            allowed=True,
            reason="manager_inactive_fail_open",
            policy="FAIL_OPEN",
        )
        return base
    if trusted is None:
        base.update(
            allowed=True,
            reason="not_ready_without_verified_state_fail_open",
            policy="FAIL_OPEN",
        )
        return base

    try:
        allowed = (
            trusted["matrix"][resolved_workspace][resolved_editor][normalized_tool]
            is True
        )
    except Exception:
        # Once a cache is asserted authoritative and all keys are known, a
        # structural cache failure must not turn an explicit OFF into visible.
        base.update(
            allowed=False,
            reason="trusted_cache_exception_fail_closed",
            policy="FAIL_CLOSED",
        )
        return base

    base.update(
        explicit=True,
        allowed=allowed,
        reason=(
            "explicit_matrix_cell"
            if _settings_ready
            else "last_known_authoritative_matrix_cell"
        ),
        policy=("EXPLICIT_CELL" if _settings_ready else "LAST_KNOWN_CELL"),
    )
    return base


def placement_allowed(
    tool_key: str,
    context=None,
    *,
    workspace_key: str | None = None,
    editor_key: str | None = None,
) -> bool:
    """Stable memory-only API for each Suite-owned root ``Panel.poll``."""
    return bool(
        get_placement_state(
            tool_key,
            context,
            workspace_key=workspace_key,
            editor_key=editor_key,
        )["allowed"]
    )


def _panel_allowed_for_context(
    tool_key: str,
    context=None,
    *,
    panel_cls=None,
    expected_editor_key: str | None = None,
) -> bool:
    """Legacy Suite alias; ``panel_cls`` is never inspected or modified."""
    del panel_cls
    return placement_allowed(
        tool_key,
        context,
        editor_key=expected_editor_key,
    )


def panel_rule_allows_context(
    tool_key: str,
    context=None,
    editor_key: str | None = None,
) -> bool:
    """Backward-compatible pure alias for native Suite ``Panel.poll``."""
    return placement_allowed(tool_key, context, editor_key=editor_key)


def workspace_tool_allowed(
    tool_key: str,
    context=None,
    workspace_key: str | None = None,
) -> bool:
    """Return any-editor ON solely for Suite owner/runtime retention.

    This must never be used for individual N-panel visibility. Every Suite root
    Panel uses ``placement_allowed`` for the current logical editor cell.
    """
    normalized_tool = _normalize_tool_key(tool_key)
    requested_workspace = str(workspace_key or "").strip().upper()
    if normalized_tool not in _TOOL_BY_KEY:
        return False
    if workspace_key is not None and requested_workspace not in _WORKSPACE_KEYS:
        return False
    try:
        resolved_workspace = requested_workspace or _active_workspace_key(context)
    except Exception:
        return True
    if resolved_workspace not in _WORKSPACE_KEYS:
        return True
    trusted = _trusted_state()
    if not _manager_registered or trusted is None:
        return True
    try:
        workspace_matrix = trusted["matrix"][resolved_workspace]
        return any(
            workspace_matrix[logical_editor][normalized_tool] is True
            for logical_editor in _EDITOR_ORDER
        )
    except Exception:
        # Owner retention fails open so a Manager cache fault cannot unload or
        # owner-filter an otherwise enabled Suite.
        return True


def notify_panel_sources_changed(*, delay: float = 0.0) -> None:
    """Explicit compatibility action; never call it from Panel.poll/draw.

    Unlike the decision/snapshot API, this action deliberately requests redraw.
    It performs no registration, file I/O, migration, timer, or Suite lifecycle.
    """
    del delay
    _tag_supported_areas_redraw()


# Some Suites keep their tab whatever the rule says: their root Panels never ask
# the Manager, ask only in some editors, or ask through a binding that stays empty
# when the Suite loads first. The Manager gives every Suite's root sidebar Panels
# the rule; the Suite's own poll still runs after it.
_PLACEMENT_GATE_RETRY_SECONDS = 3.0
_placement_gate_timer_runs = 0


def _placement_gate_allows(tool_key: str, context) -> bool:
    try:
        return placement_allowed(tool_key, context)
    except Exception:
        return True


def _gated_poll(tool_key: str, suite_poll):
    # Blender passes as many arguments as the function declares, so this must
    # keep exactly (cls, context) and carry the rest in its closure.
    def poll(_cls, context):
        return _placement_gate_allows(tool_key, context) and suite_poll(context)

    return classmethod(poll)


def _registered_sidebar_root_panels(tool_key: str):
    leaves = _tool_module_leaves(tool_key)
    category = _TOOL_BY_KEY[tool_key]["en"]
    pending = list(Panel.__subclasses__())
    seen: set[type] = set()
    while pending:
        cls = pending.pop()
        if cls in seen:
            continue
        seen.add(cls)
        pending.extend(cls.__subclasses__())
        # A Suite may build its Panels in a module outside its package; the tab name still tells.
        if getattr(cls, "bl_category", "") != category and not leaves.intersection(
            str(getattr(cls, "__module__", "")).lower().split(".")
        ):
            continue
        if (
            getattr(cls, "is_registered", False)
            and getattr(cls, "bl_region_type", "") == "UI"
            and getattr(cls, "bl_category", "")
            and not getattr(cls, "bl_parent_id", "")
            and callable(getattr(cls, "poll", None))
        ):
            yield cls


def _remove_placement_gate(cls) -> None:
    original = cls.__dict__.get("_stm_gate_original")
    if original is None:
        return
    if original[0] is None:
        del cls.poll
    else:
        cls.poll = original[0]
    del cls._stm_gate_original
    del cls._stm_gate_owner


def _install_placement_gates() -> None:
    """Idempotent; also takes over the gates of a previous Manager generation."""
    if not _manager_registered:
        return
    try:
        for tool_key in _TOOL_ORDER:
            for cls in _registered_sidebar_root_panels(tool_key):
                if cls.__dict__.get("_stm_gate_owner") is _placement_gate_allows:
                    continue
                _remove_placement_gate(cls)
                suite_poll = cls.poll
                cls._stm_gate_original = (cls.__dict__.get("poll"),)
                cls._stm_gate_owner = _placement_gate_allows
                cls.poll = _gated_poll(tool_key, suite_poll)
        _runtime_errors.pop("PLACEMENT_GATE", None)
    except Exception:
        _runtime_errors["PLACEMENT_GATE"] = traceback.format_exc(limit=4)


def _remove_placement_gates() -> None:
    if bpy.app.timers.is_registered(_placement_gate_timer):
        bpy.app.timers.unregister(_placement_gate_timer)
    for tool_key in _TOOL_ORDER:
        for cls in _registered_sidebar_root_panels(tool_key):
            if cls.__dict__.get("_stm_gate_owner") is _placement_gate_allows:
                _remove_placement_gate(cls)


def _placement_gate_timer():
    """Runs twice after registration, so Suites enabled after the Manager are covered."""
    global _placement_gate_timer_runs
    _install_placement_gates()
    _tag_supported_areas_redraw()
    _placement_gate_timer_runs += 1
    return _PLACEMENT_GATE_RETRY_SECONDS if _placement_gate_timer_runs < 2 else None


def _schedule_placement_gates() -> None:
    global _placement_gate_timer_runs
    _placement_gate_timer_runs = 0
    if not bpy.app.timers.is_registered(_placement_gate_timer):
        bpy.app.timers.register(_placement_gate_timer, first_interval=0.0, persistent=True)


def _enabled_addon_owner_ids(context=None) -> tuple[str, ...]:
    context = context or getattr(bpy, "context", None)
    try:
        addons = getattr(getattr(context, "preferences", None), "addons", None)
        return tuple(str(key) for key in addons.keys()) if addons is not None else tuple()
    except Exception:
        return tuple()


def _module_leaf(module_name: str) -> str:
    return str(module_name or "").strip().split(".")[-1].lower()


def _tool_module_leaves(tool_key: str) -> set[str]:
    tool = _TOOL_BY_KEY.get(tool_key)
    if not tool:
        return set()
    values = {str(tool.get("module", "") or "").lower()}
    values.update(str(value or "").lower() for value in tool.get("module_aliases", ()))
    return {value for value in values if value}


def _tool_owner_ids(tool_key: str, enabled_owner_ids: Iterable[str] = ()) -> set[str]:
    leaves = _tool_module_leaves(tool_key)
    if not leaves:
        return set()
    return {
        owner_id
        for owner_id in enabled_owner_ids
        if _module_leaf(owner_id) in leaves
    }


def _manager_owner_ids(enabled_owner_ids: Iterable[str] = ()) -> set[str]:
    actual = {
        owner_id
        for owner_id in enabled_owner_ids
        if _module_leaf(owner_id) == ADDON_ID
    }
    if actual:
        return actual
    package_id = str(__package__ or "").strip()
    if package_id and _module_leaf(package_id) == ADDON_ID:
        return {package_id}
    return {f"bl_ext.user_default.{ADDON_ID}"}


def _workspace_owner_names(workspace) -> set[str]:
    try:
        return {
            str(getattr(item, "name", "") or "")
            for item in tuple(getattr(workspace, "owner_ids", ()) or ())
            if str(getattr(item, "name", "") or "")
        }
    except Exception:
        return set()


def _workspace_owner_find(workspace, owner_id: str):
    owners = getattr(workspace, "owner_ids", None)
    if owners is None:
        return None
    try:
        return owners.get(owner_id)
    except Exception:
        pass
    try:
        index = owners.find(owner_id)
        return owners[index] if index >= 0 else None
    except Exception:
        return None


def _workspace_add_owner_id(workspace, owner_id: str) -> bool:
    owner_id = str(owner_id or "").strip()
    if workspace is None or not owner_id or _workspace_owner_find(workspace, owner_id) is not None:
        return False
    try:
        workspace.owner_ids.new(owner_id)
        return True
    except Exception:
        try:
            with bpy.context.temp_override(workspace=workspace):
                bpy.ops.wm.owner_enable(owner_id=owner_id)
            return True
        except Exception:
            return False


def _workspace_remove_owner_id(workspace, owner_id: str) -> bool:
    owner_id = str(owner_id or "").strip()
    if workspace is None or not owner_id:
        return False
    item = _workspace_owner_find(workspace, owner_id)
    if item is None:
        return False
    try:
        workspace.owner_ids.remove(item)
        return True
    except Exception:
        try:
            with bpy.context.temp_override(workspace=workspace):
                bpy.ops.wm.owner_disable(owner_id=owner_id)
            return True
        except Exception:
            return False


def _workspace_snapshot_key(workspace) -> tuple[int, str]:
    try:
        uid = int(getattr(workspace, "session_uid", 0) or 0)
    except Exception:
        uid = 0
    if not uid:
        try:
            uid = int(workspace.as_pointer())
        except Exception:
            uid = id(workspace)
    return uid, str(getattr(workspace, "name", "") or "")


def _workspace_filter_delta(workspace, *, create: bool = True) -> dict[str, Any] | None:
    """Return the exact Manager-owned owner-filter delta for one workspace."""
    if workspace is None:
        return None
    key = _workspace_snapshot_key(workspace)
    existing = _workspace_filter_deltas.get(key)
    if existing is not None or not create:
        return existing
    if len(_workspace_filter_deltas) >= WORKSPACE_SNAPSHOT_MAX_ITEMS:
        _runtime_errors["WORKSPACE_FILTER_LIMIT"] = (
            "Workspace owner-filter ownership ledger reached its fixed bound; "
            "the additional workspace was left unchanged."
        )
        return None
    entry = {
        "uid": key[0],
        "name": key[1],
        "added_owner_ids": set(),
        "removed_owner_ids": set(),
        "enabled_filter": False,
        # A filter that is already on is the user's own narrowing: it stays
        # narrowed, and nothing outside the catalog is added to it.
        "keeps_own_narrowing": bool(getattr(workspace, "use_filter_by_owner", False)),
        # Add-ons outside the catalog are listed once, so one the user takes
        # off the list afterwards stays off.
        "offered_owner_ids": set(),
    }
    _workspace_filter_deltas[key] = entry
    return entry


def _find_workspace_for_snapshot(snapshot: dict[str, Any]):
    workspaces = tuple(getattr(getattr(bpy, "data", None), "workspaces", ()) or ())
    uid = int(snapshot.get("uid", 0) or 0)
    name = str(snapshot.get("name", "") or "")
    for workspace in workspaces:
        try:
            current_uid = int(getattr(workspace, "session_uid", 0) or 0)
        except Exception:
            current_uid = 0
        if uid and current_uid == uid:
            return workspace
    for workspace in workspaces:
        if str(getattr(workspace, "name", "") or "") == name:
            return workspace
    return None


def _record_workspace_owner_add(entry: dict[str, Any], owner_id: str) -> None:
    removed = entry["removed_owner_ids"]
    added = entry["added_owner_ids"]
    if owner_id in removed:
        removed.discard(owner_id)
    else:
        added.add(owner_id)


def _record_workspace_owner_remove(entry: dict[str, Any], owner_id: str) -> None:
    removed = entry["removed_owner_ids"]
    added = entry["added_owner_ids"]
    if owner_id in added:
        added.discard(owner_id)
    else:
        removed.add(owner_id)


def _restore_workspace_filter_state() -> None:
    """Reverse only owner/filter mutations made by this Manager generation."""
    errors: list[str] = []
    remaining: dict[tuple[int, str], dict[str, Any]] = {}
    for key, delta in tuple(_workspace_filter_deltas.items()):
        workspace = _find_workspace_for_snapshot(delta)
        if workspace is None:
            continue
        try:
            for owner_id in sorted(tuple(delta.get("added_owner_ids", ()))):
                if _workspace_owner_find(workspace, owner_id) is not None:
                    if not _workspace_remove_owner_id(workspace, owner_id):
                        raise RuntimeError(f"failed to remove Manager-added owner {owner_id}")
            for owner_id in sorted(tuple(delta.get("removed_owner_ids", ()))):
                if _workspace_owner_find(workspace, owner_id) is None:
                    if not _workspace_add_owner_id(workspace, owner_id):
                        raise RuntimeError(f"failed to restore Manager-removed owner {owner_id}")
            if bool(delta.get("enabled_filter", False)):
                if bool(getattr(workspace, "use_filter_by_owner", False)):
                    workspace.use_filter_by_owner = False
        except Exception:
            remaining[key] = delta
            errors.append(traceback.format_exc(limit=4))
    _workspace_filter_deltas.clear()
    _workspace_filter_deltas.update(remaining)
    if errors:
        _runtime_errors["WORKSPACE_FILTER_RESTORE"] = "\n".join(errors)
    else:
        _runtime_errors.pop("WORKSPACE_FILTER_RESTORE", None)


def _workspace_rules_enabled_tools(workspace_key: str) -> set[str]:
    if workspace_key not in _WORKSPACE_KEYS:
        return set()
    return {
        tool_key
        for tool_key in _TOOL_ORDER
        if any(_rule_value(workspace_key, editor_key, tool_key) for editor_key in _EDITOR_ORDER)
    }


def _sync_workspace_owner_filters(
    *,
    workspace_keys: set[str] | None = None,
    context=None,
    redraw_acknowledgement: list[bool] | None = None,
) -> bool:
    """Synchronize only exact Manager-owned Workspace owner-filter deltas.

    This function never enables, disables, registers, unregisters, or reloads a
    Suite.  Any-editor ON is used only to retain an already enabled Suite owner;
    individual Panel visibility remains the current logical-editor cell.
    """
    if not _settings_authoritative or not bool(
        _cached_state_for_ui().get("runtime", {}).get("source_panel_filters", False)
    ):
        return False
    selected_keys = set(workspace_keys or _WORKSPACE_KEYS)
    enabled_owner_ids = _enabled_addon_owner_ids(context)
    managed_tool_keys = _TOOL_ORDER
    all_known_tool_owners: set[str] = set()
    for tool_key in managed_tool_keys:
        all_known_tool_owners.update(_tool_owner_ids(tool_key, enabled_owner_ids))

    manager_owners = _manager_owner_ids(enabled_owner_ids)
    changed = False
    workspaces = tuple(getattr(getattr(bpy, "data", None), "workspaces", ()) or ())
    for workspace in workspaces:
        workspace_key = _workspace_key_from_name(getattr(workspace, "name", ""))
        if workspace_key not in selected_keys:
            continue
        delta = _workspace_filter_delta(workspace)
        if delta is None:
            continue
        desired_tools = _workspace_rules_enabled_tools(workspace_key)
        desired_tool_owners: set[str] = set()
        for tool_key in managed_tool_keys:
            if tool_key in desired_tools:
                desired_tool_owners.update(
                    _tool_owner_ids(tool_key, enabled_owner_ids)
                )

        current = _workspace_owner_names(workspace)
        for owner_id in sorted((current & all_known_tool_owners) - desired_tool_owners):
            if _workspace_remove_owner_id(workspace, owner_id):
                _record_workspace_owner_remove(delta, owner_id)
                changed = True
        current = _workspace_owner_names(workspace)
        for owner_id in sorted(desired_tool_owners - current):
            if _workspace_add_owner_id(workspace, owner_id):
                _record_workspace_owner_add(delta, owner_id)
                changed = True

        # The Manager is not a matrix item, but its Top Bar popup must remain
        # available when workspace owner filtering is enabled. Blender hides
        # every owner missing from this list, so add-ons outside the catalog
        # stay listed: the rules only speak for the Smart Tools. The user keeps
        # the final say over those add-ons through Blender's own filter.
        current = _workspace_owner_names(workspace)
        other_owners = set(enabled_owner_ids) - all_known_tool_owners - manager_owners
        retained_owners = set(manager_owners)
        if not delta["keeps_own_narrowing"]:
            retained_owners |= other_owners - delta["offered_owner_ids"]
        delta["offered_owner_ids"] |= other_owners
        for owner_id in sorted(retained_owners - current):
            if _workspace_add_owner_id(workspace, owner_id):
                _record_workspace_owner_add(delta, owner_id)
                changed = True

        if not bool(getattr(workspace, "use_filter_by_owner", False)):
            try:
                workspace.use_filter_by_owner = True
                delta["enabled_filter"] = True
                changed = True
            except Exception:
                _runtime_errors["WORKSPACE_FILTER"] = traceback.format_exc(limit=4)
    if changed:
        redraw_succeeded = _tag_supported_areas_redraw()
        if redraw_acknowledgement is not None:
            redraw_acknowledgement.append(redraw_succeeded)
        _publish_lifecycle_state()
    return changed


def _workspace_filter_tool_enabled(workspace, tool_key: str) -> bool:
    if workspace is None or tool_key not in _TOOL_BY_KEY:
        return True
    try:
        if not bool(getattr(workspace, "use_filter_by_owner", False)):
            return True
    except Exception:
        return True
    owners = _workspace_owner_names(workspace)
    candidates = _tool_owner_ids(tool_key, _enabled_addon_owner_ids())
    return bool(owners.intersection(candidates)) if candidates else True


def _workspace_filter_tool_enabled_in_context(tool_key: str, context=None) -> bool:
    context = context or bpy.context
    workspace = getattr(context, "workspace", None) or getattr(getattr(context, "window", None), "workspace", None)
    return _workspace_filter_tool_enabled(workspace, tool_key)


def _tool_active_in_preferences(tool_key: str, context=None) -> bool:
    enabled = _enabled_addon_owner_ids(context)
    leaves = _tool_module_leaves(tool_key)
    return any(_module_leaf(owner_id) in leaves for owner_id in enabled)


def _tag_supported_areas_redraw() -> bool:
    physical = set(PHYSICAL_SPACE_TYPES)
    try:
        window_managers = tuple(getattr(getattr(bpy, "data", None), "window_managers", ()) or ())
        for window_manager in window_managers:
            for window in tuple(getattr(window_manager, "windows", ()) or ()):
                screen = getattr(window, "screen", None)
                for area in tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ():
                    if _value_text(area, "type") in physical:
                        area.tag_redraw()
    except Exception:
        return False
    return True


def _retire_legacy_panel_router_namespace() -> None:
    """Remove the old Manager-owned callback slot without touching Panels."""
    try:
        namespace = getattr(bpy.app, "driver_namespace", None)
        if isinstance(namespace, dict):
            namespace.pop(_LEGACY_PANEL_ROUTER_NAMESPACE_KEY, None)
    except Exception:
        _runtime_errors["LEGACY_ROUTER_RETIRE"] = traceback.format_exc(limit=3)


def _driver_namespace_dict() -> dict[str, Any] | None:
    try:
        namespace = getattr(bpy.app, "driver_namespace", None)
        return namespace if isinstance(namespace, dict) else None
    except Exception:
        return None


def _lifecycle_ledger_is_valid(value: Any) -> bool:
    return bool(
        isinstance(value, dict)
        and value.get("schema") == _LIFECYCLE_LEDGER_SCHEMA
        and value.get("owner_id") == ADDON_ID
        and value.get("complete") is True
        and isinstance(value.get("token"), str)
        and bool(value.get("token", "").strip())
        and isinstance(value.get("classes", ()), (tuple, list))
        and isinstance(value.get("handlers", ()), (tuple, list))
        and isinstance(value.get("topbar_callbacks", ()), (tuple, list))
        and type(value.get("pointer_property_installed", False)) is bool
        and type(value.get("scene_property_installed", False)) is bool
        and type(value.get("translations_registered", False)) is bool
    )


def _get_lifecycle_ledger() -> dict[str, Any] | None:
    namespace = _driver_namespace_dict()
    if namespace is None:
        return None
    value = namespace.get(_LIFECYCLE_LEDGER_NAMESPACE_KEY)
    return value if _lifecycle_ledger_is_valid(value) else None


def _set_lifecycle_ledger(ledger: dict[str, Any]) -> None:
    global _active_lifecycle_ledger
    if not _lifecycle_ledger_is_valid(ledger):
        raise RuntimeError("refusing to publish an invalid Manager lifecycle ledger")
    namespace = _driver_namespace_dict()
    if namespace is None:
        raise RuntimeError("Blender driver_namespace is unavailable")
    namespace[_LIFECYCLE_LEDGER_NAMESPACE_KEY] = ledger
    _active_lifecycle_ledger = ledger


def _clear_lifecycle_ledger(*, expected_token: str) -> bool:
    global _active_lifecycle_ledger
    namespace = _driver_namespace_dict()
    current = (
        namespace.get(_LIFECYCLE_LEDGER_NAMESPACE_KEY)
        if namespace is not None
        else None
    )
    if current is None:
        # Blender may retire driver_namespace before add-on unregister during
        # normal application shutdown. In that state there is no external
        # ledger left to clear, so accept only this exact live generation.
        if expected_token != _registration_token:
            return False
        active = _active_lifecycle_ledger
        if active is not None and not (
            _lifecycle_ledger_is_valid(active)
            and active.get("token") == expected_token
        ):
            return False
        _active_lifecycle_ledger = None
        return True
    if not (
        _lifecycle_ledger_is_valid(current)
        and current.get("token") == expected_token
    ):
        return False
    namespace.pop(_LIFECYCLE_LEDGER_NAMESPACE_KEY, None)
    if _active_lifecycle_ledger is current:
        _active_lifecycle_ledger = None
    return True


def _runtime_api_record_is_owned(value: Any) -> bool:
    return bool(
        isinstance(value, dict)
        and value.get("schema") == _RUNTIME_API_SCHEMA
        and value.get("package_id") == ADDON_ID
        and value.get("status") == "ACTIVE"
        and isinstance(value.get("generation"), str)
        and bool(value.get("generation", "").strip())
        and type(value.get("revision")) is int
        and value.get("revision", -1) >= 0
        and isinstance(value.get("public_api"), dict)
        and isinstance(value.get("subscribers"), dict)
    )


def _current_runtime_api_record() -> dict[str, Any] | None:
    namespace = _driver_namespace_dict()
    if namespace is None:
        return None
    value = namespace.get(_RUNTIME_API_NAMESPACE_KEY)
    if not (
        _runtime_api_record_is_owned(value)
        and value.get("runtime_identity") is _RUNTIME_API_IDENTITY
        and value.get("generation") == _registration_token
        and value is _active_runtime_api_record
        and _manager_registered
    ):
        return None
    return value


def _runtime_public_api() -> dict[str, Any]:
    return {
        "placement_allowed": placement_allowed,
        "panel_rule_allows_context": panel_rule_allows_context,
        "workspace_tool_allowed": workspace_tool_allowed,
        "get_placement_state": get_placement_state,
        "get_rule_matrix_snapshot": get_rule_matrix_snapshot,
        "get_rule_matrix_state": get_rule_matrix_state,
        "get_catalog_snapshot": get_catalog_snapshot,
        "get_current_cell_rule": get_current_cell_rule,
        "apply_rule_matrix": apply_rule_matrix,
        "subscribe_rule_matrix_commits": subscribe_rule_matrix_commits,
        "unsubscribe_rule_matrix_commits": unsubscribe_rule_matrix_commits,
        "get_placement_contract": get_placement_contract,
        "logical_editor_key_from_context": logical_editor_key_from_context,
        "notify_panel_sources_changed": notify_panel_sources_changed,
    }


def _publish_runtime_api_record(
    *,
    transfer_from: dict[str, Any] | None = None,
) -> dict[str, Any]:
    global _active_runtime_api_record
    # A clean first install has no verified settings payload yet. Publish the
    # generation-bound API in NOT_READY state so the first explicit Manager or
    # Workspace matrix commit can establish generation 1.
    if not (_manager_registered and _registration_token):
        raise RuntimeError("Manager runtime API cannot publish before activation")
    namespace = _driver_namespace_dict()
    if namespace is None:
        raise RuntimeError("Blender driver_namespace is unavailable")
    subscribers: dict[str, Any] = {}
    if _runtime_api_record_is_owned(transfer_from):
        subscribers = dict(transfer_from.get("subscribers", {}))
    record = {
        "schema": _RUNTIME_API_SCHEMA,
        "package_id": ADDON_ID,
        "status": "ACTIVE",
        "runtime_identity": _RUNTIME_API_IDENTITY,
        "generation": _registration_token,
        "revision": _runtime_api_revision(),
        "api_revision": RULE_MATRIX_WRITE_API_REVISION,
        "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
        "public_api": _runtime_public_api(),
        "subscribers": subscribers,
    }
    namespace[_RUNTIME_API_NAMESPACE_KEY] = record
    _active_runtime_api_record = record
    if _current_runtime_api_record() is not record:
        raise RuntimeError("Manager runtime API exact publication verification failed")
    return record


def _refresh_runtime_api_record() -> None:
    record = _current_runtime_api_record()
    if record is None:
        return
    record["revision"] = _runtime_api_revision()
    record["public_api"] = _runtime_public_api()


def _republish_active_runtime_api_record_exact() -> dict[str, Any] | None:
    """Restore the current generation after Blender clears driver_namespace."""
    record = _active_runtime_api_record
    if not (
        _runtime_api_record_is_owned(record)
        and record.get("runtime_identity") is _RUNTIME_API_IDENTITY
        and record.get("generation") == _registration_token
        and _manager_registered
    ):
        return None
    namespace = _driver_namespace_dict()
    if namespace is None:
        return None
    current = namespace.get(_RUNTIME_API_NAMESPACE_KEY)
    if current is None:
        namespace[_RUNTIME_API_NAMESPACE_KEY] = record
    elif current is not record:
        return None
    record["revision"] = _runtime_api_revision()
    record["public_api"] = _runtime_public_api()
    return record if _current_runtime_api_record() is record else None


def _clear_runtime_api_record_exact(*, expected_generation: str) -> bool:
    global _active_runtime_api_record
    namespace = _driver_namespace_dict()
    current = (
        namespace.get(_RUNTIME_API_NAMESPACE_KEY)
        if namespace is not None
        else None
    )
    if current is None:
        # As with the lifecycle ledger, a missing namespace at shutdown means
        # the externally reachable API record is already gone. Clear only an
        # absent or exact current-generation in-memory record.
        if expected_generation != _registration_token:
            return False
        active = _active_runtime_api_record
        if active is not None and not (
            _runtime_api_record_is_owned(active)
            and active.get("runtime_identity") is _RUNTIME_API_IDENTITY
            and active.get("generation") == expected_generation
        ):
            return False
        _active_runtime_api_record = None
        return True
    if not (
        _runtime_api_record_is_owned(current)
        and current is _active_runtime_api_record
        and current.get("runtime_identity") is _RUNTIME_API_IDENTITY
        and current.get("generation") == expected_generation
    ):
        return False
    namespace.pop(_RUNTIME_API_NAMESPACE_KEY, None)
    _active_runtime_api_record = None
    return True


def _notify_workspace_bridge_runtime_available() -> None:
    """Wake one exact Suite endpoint without installing a Manager timer."""
    try:
        namespace = _driver_namespace_dict()
        endpoint = (
            namespace.get(_WORKSPACE_BRIDGE_ENDPOINT_NAMESPACE_KEY)
            if namespace is not None
            else None
        )
        if not (
            isinstance(endpoint, dict)
            and endpoint.get("schema") == 1
            and endpoint.get("package_id") == "smart_workspace_suite"
            and endpoint.get("status") == "ACTIVE"
            and isinstance(endpoint.get("suite_generation"), str)
            and bool(endpoint.get("suite_generation", "").strip())
            and callable(endpoint.get("callback"))
        ):
            return
        endpoint["callback"]({
            "schema": "jelararagi.smart_tools_manager.runtime_available",
            "api_revision": RULE_MATRIX_WRITE_API_REVISION,
            "runtime_generation": str(_registration_token or ""),
            "manager_revision": _runtime_api_revision(),
            "suite_generation": str(endpoint["suite_generation"]),
            "manager_self_rule_policy": MANAGER_SELF_RULE_POLICY,
        })
        _runtime_errors.pop("WORKSPACE_BRIDGE_ENDPOINT", None)
    except Exception:
        _runtime_errors["WORKSPACE_BRIDGE_ENDPOINT"] = traceback.format_exc(limit=4)


def _normalized_authoritative_state_for_ledger() -> dict[str, Any] | None:
    state = _trusted_state()
    if state is None:
        return None
    try:
        payload = _payload_with_checksum(state)
        validated, needs_repair = _validate_current_payload(payload)
        if needs_repair:
            return None
        return validated
    except Exception:
        return None


def _publish_lifecycle_state() -> None:
    """Refresh and, after file load, republish this exact generation ledger."""
    ledger = _active_lifecycle_ledger or _get_lifecycle_ledger()
    if not (
        _lifecycle_ledger_is_valid(ledger)
        and ledger.get("token") == _registration_token
    ):
        return
    ledger["settings_authoritative"] = bool(_settings_authoritative)
    ledger["settings_ready"] = bool(_settings_ready)
    ledger["settings_authority_source"] = str(_settings_authority_source)
    ledger["settings_state"] = _normalized_authoritative_state_for_ledger()
    ledger["settings_disk_snapshot"] = copy.deepcopy(_settings_disk_snapshot)
    ledger["settings_dirty"] = bool(_settings_dirty)
    ledger["workspace_filter_deltas"] = _workspace_filter_deltas
    namespace = _driver_namespace_dict()
    if namespace is not None and namespace.get(_LIFECYCLE_LEDGER_NAMESPACE_KEY) is not ledger:
        namespace[_LIFECYCLE_LEDGER_NAMESPACE_KEY] = ledger
    if _active_runtime_api_record is not None:
        if _republish_active_runtime_api_record_exact() is None:
            raise RuntimeError(
                "Manager current-generation runtime API could not be restored after file load"
            )


def _adopt_lifecycle_state(ledger: dict[str, Any] | None) -> None:
    """Adopt only a checksum-verified data snapshot from an old generation."""
    global _settings_cache, _settings_authoritative, _settings_ready
    global _settings_authority_source, _settings_disk_snapshot
    global _settings_dirty, _pending_settings, _workspace_filter_deltas
    if not _lifecycle_ledger_is_valid(ledger):
        return
    if ledger.get("settings_authoritative") is True:
        # Older live generations may store checksum-verified schema-v2/v3
        # matrices in their ledger. Normalize that exact verified snapshot to
        # schema v4 so
        # an in-process Manager update keeps its last-known authoritative state
        # even when the finite disk reload is temporarily NOT_READY. Unverified
        # or malformed generation data is never promoted.
        state = _normalize_generation_settings_state(ledger.get("settings_state"))
        if state is not None:
            _settings_cache = copy.deepcopy(state)
            _settings_authoritative = True
            _settings_ready = False
            _settings_authority_source = (
                "LAST_KNOWN_GENERATION:" + str(ledger.get("token", ""))
            )
            snapshot = ledger.get("settings_disk_snapshot")
            _settings_disk_snapshot = (
                copy.deepcopy(snapshot)
                if isinstance(snapshot, tuple) and len(snapshot) == 2
                else None
            )
            # Pending writes are deliberately not inherited across code
            # generations. A new finite disk load must re-establish the CAS
            # identity before any edit can be committed.
            _settings_dirty = False
            _pending_settings = None
    deltas = ledger.get("workspace_filter_deltas")
    if isinstance(deltas, dict):
        _workspace_filter_deltas = deltas


def _manager_props(context=None):
    context = context or bpy.context
    try:
        return context.window_manager.smart_tools_manager
    except Exception:
        return None


def _assign_property(owner, name: str, value: Any) -> None:
    owner.__setattr__(name, value)


@contextmanager
def _property_sync_guard():
    global _syncing_properties
    previous = _syncing_properties
    _syncing_properties = True
    try:
        yield
    finally:
        _syncing_properties = previous


def _sync_tool_booleans(props) -> None:
    if props is None:
        return
    state = _cached_state_for_ui()
    workspace_key = state["selection"]["workspace"]
    editor_key = state["selection"]["editor"]
    with _property_sync_guard():
        for tool_key in _TOOL_ORDER:
            _assign_property(
                props,
                _TOOL_PROP_BY_KEY[tool_key],
                state["matrix"][workspace_key][editor_key][tool_key],
            )


def _sync_properties_from_settings(props) -> None:
    if props is None:
        return
    state = _cached_state_for_ui()
    selection = state["selection"]
    ui = state["ui"]
    runtime = state["runtime"]
    with _property_sync_guard():
        _assign_property(props, "n_panel_state_save", ui["n_panel_state_save"])
        _assign_property(props, "show_always_on_toggles", ui["show_always_on_toggles"])
        _assign_property(props, "runtime_automatic_context_sync", runtime["automatic_context_sync"])
        _assign_property(props, "runtime_source_panel_filters", runtime["source_panel_filters"])
        _assign_property(props, "runtime_topbar_button", runtime["topbar_button"])
        _assign_property(props, "runtime_load_restore_handler", runtime["load_restore_handler"])
        _assign_property(props, "runtime_undo_redo_handlers", runtime["undo_redo_handlers"])
        _assign_property(props, "runtime_api_bridge", runtime["runtime_api_bridge"])
        _assign_property(props, "runtime_panel_proxies", False)
        _assign_property(props, "runtime_category_anchors", False)
        _assign_property(props, "runtime_ui_callback_repair", False)
        _assign_property(props, "runtime_transform_guard", False)
        _assign_property(props, "runtime_stale_proxy_cleanup", False)
        _assign_property(props, "selected_workspace", selection["workspace"])
        _assign_property(props, "selected_editor", selection["editor"])
        for tool_key in _TOOL_ORDER:
            _assign_property(
                props,
                _TOOL_PROP_BY_KEY[tool_key],
                state["matrix"][selection["workspace"]][selection["editor"]][tool_key],
            )


def _persist_n_panel_settings() -> None:
    props = _manager_props(bpy.context)
    if props is None:
        return
    _on_selection_update(props, bpy.context)


def _on_selection_update(self, context) -> None:
    if _syncing_properties or _undo_restore_in_progress:
        return
    current = _cached_state_for_ui()
    workspace = str(getattr(self, "selected_workspace", "") or "")
    editor = str(getattr(self, "selected_editor", "") or "")
    intended = {}
    for key, value, allowed in (
        ("workspace", workspace, _WORKSPACE_KEYS),
        ("editor", editor, _EDITOR_KEYS),
    ):
        if value in allowed and value != current["selection"][key]:
            intended[key] = value

    def mutation(state):
        state["selection"].update(intended)

    ok, committed, state = _commit_settings_mutation(
        mutation,
        authority_source="SELECTION_UPDATE",
    )
    if not ok:
        _sync_properties_from_settings(self)
        return
    _sync_properties_from_settings(self)
    if committed and _immediate_workspace_sync_enabled(state):
        _sync_workspace_owner_filters(
            workspace_keys={state["selection"]["workspace"]},
            context=context,
        )
    if committed:
        _set_scene_undo_state(context, reason="selection", push=True)


def _on_tool_rule_update(self, context) -> None:
    if _syncing_properties or _undo_restore_in_progress:
        return
    current = _cached_state_for_ui()
    workspace = str(getattr(self, "selected_workspace", "") or "")
    editor = str(getattr(self, "selected_editor", "") or "")
    if workspace not in _WORKSPACE_KEYS:
        workspace = current["selection"]["workspace"]
    if editor not in _EDITOR_KEYS:
        editor = current["selection"]["editor"]
    values = {
        tool_key: bool(getattr(self, _TOOL_PROP_BY_KEY[tool_key], False))
        for tool_key in _TOOL_ORDER
    }
    intended_values = {
        tool_key: value
        for tool_key, value in values.items()
        if current["matrix"][workspace][editor][tool_key] is not value
    }
    intended_selection = {
        key: value
        for key, value in (
            ("workspace", workspace),
            ("editor", editor),
        )
        if current["selection"][key] != value
    }

    def mutation(state):
        state["selection"].update(intended_selection)
        for tool_key, value in intended_values.items():
            state["matrix"][workspace][editor][tool_key] = value

    ok, committed, state = _commit_settings_mutation(
        mutation,
        authority_source="TOOL_RULE_UPDATE",
    )
    if not ok:
        _sync_properties_from_settings(self)
        return
    _sync_properties_from_settings(self)
    _install_placement_gates()
    if committed and _immediate_workspace_sync_enabled(state):
        _sync_workspace_owner_filters(workspace_keys={workspace}, context=context)
    if committed:
        _set_scene_undo_state(context, reason="tool_rule", push=True)
        _update_runtime_status(context)


def _on_manager_common_update(self, context) -> None:
    if _syncing_properties or _undo_restore_in_progress:
        return
    current = _cached_state_for_ui()
    ui_values = {
        "n_panel_state_save": bool(getattr(self, "n_panel_state_save", True)),
        "show_always_on_toggles": bool(getattr(self, "show_always_on_toggles", False)),
    }
    runtime_values = {
        key: bool(getattr(self, RESIDENT_RUNTIME_PROPERTY_BY_KEY[key], default))
        for key, default in RESIDENT_RUNTIME_DEFAULTS.items()
    }
    with _property_sync_guard():
        _assign_property(self, "runtime_panel_proxies", False)
        _assign_property(self, "runtime_category_anchors", False)
        _assign_property(self, "runtime_ui_callback_repair", False)
        _assign_property(self, "runtime_transform_guard", False)
        _assign_property(self, "runtime_stale_proxy_cleanup", False)

    def mutation(state):
        state["ui"].update(ui_values)
        state["runtime"].update(runtime_values)
        state["runtime"].update(RETIRED_RUNTIME_VALUES)

    ok, committed, state = _commit_settings_mutation(
        mutation,
        authority_source="MANAGER_COMMON_UPDATE",
    )
    if not ok:
        _sync_properties_from_settings(self)
        return
    _sync_properties_from_settings(self)
    if committed:
        _reconcile_resident_resources(state, context=context)
        _set_scene_undo_state(context, reason="manager_common", push=True)


def _undo_scene(context=None):
    context = context or getattr(bpy, "context", None)
    return getattr(context, "scene", None) if context is not None else None


def _matrix_to_bits(matrix: dict[str, dict[str, dict[str, bool]]]) -> str:
    raw = bytearray((MATRIX_CELL_COUNT + 7) // 8)
    index = 0
    for workspace_key in _WORKSPACE_ORDER:
        for editor_key in _EDITOR_ORDER:
            for tool_key in _TOOL_ORDER:
                if matrix[workspace_key][editor_key][tool_key]:
                    raw[index // 8] |= 1 << (index % 8)
                index += 1
    return base64.b64encode(bytes(raw)).decode("ascii")


def _bits_to_matrix(encoded: str) -> dict[str, dict[str, dict[str, bool]]]:
    if not isinstance(encoded, str):
        raise SettingsValidationError("undo matrix bits must be text")
    raw = base64.b64decode(encoded.encode("ascii"), validate=True)
    expected_size = (MATRIX_CELL_COUNT + 7) // 8
    schema_v3_size = (SCHEMA_V3_MATRIX_CELL_COUNT + 7) // 8
    if len(raw) not in {expected_size, schema_v3_size}:
        raise SettingsValidationError("undo matrix bit length is invalid")
    tool_order = _TOOL_ORDER if len(raw) == expected_size else _SCHEMA_V3_TOOL_ORDER
    matrix = _new_matrix(False)
    index = 0
    for workspace_key in _WORKSPACE_ORDER:
        for editor_key in _EDITOR_ORDER:
            for tool_key in tool_order:
                enabled = bool(raw[index // 8] & (1 << (index % 8)))
                if tool_key in _TOOL_BY_KEY:
                    matrix[workspace_key][editor_key][tool_key] = enabled
                index += 1
    return matrix


def _capture_undo_state(context=None, *, reason: str = "") -> dict[str, Any]:
    del context
    state = _cached_state_for_ui()
    return {
        "schema": "jelararagi.smart_tools_manager.undo",
        "version": 3,
        "reason": str(reason or ""),
        "generation": int(state.get("generation", 0) or 0),
        "matrix_bits": _matrix_to_bits(state["matrix"]),
        "selection": copy.deepcopy(state["selection"]),
        "ui": copy.deepcopy(state["ui"]),
        "runtime": copy.deepcopy(state["runtime"]),
    }


def _undo_state_text(state: dict[str, Any]) -> str:
    return json.dumps(state, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _undo_state_semantic_text(state: dict[str, Any] | None) -> str:
    if not isinstance(state, dict):
        return ""
    semantic = dict(state)
    semantic.pop("reason", None)
    semantic.pop("sequence", None)
    return _undo_state_text(semantic)


def _push_undo_step(context=None, message: str = "Smart Tools Manager") -> None:
    del context
    if _undo_restore_in_progress or bool(getattr(bpy.app, "background", False)):
        return
    bpy.ops.ed.undo_push(message=str(message or "Smart Tools Manager"))


def _set_scene_undo_state(context=None, *, reason: str = "", push: bool = False) -> None:
    global _undo_checkpoint_counter, _last_undo_state_text
    if _undo_restore_in_progress:
        return
    scene = _undo_scene(context)
    if scene is None or not hasattr(scene, "smart_tools_manager_undo_index"):
        return
    state = _capture_undo_state(context, reason=reason)
    previous = None
    if _last_undo_state_text:
        try:
            previous = json.loads(_last_undo_state_text)
        except Exception:
            previous = None
    if _undo_state_semantic_text(previous) == _undo_state_semantic_text(state):
        return
    _undo_checkpoint_counter += 1
    state["sequence"] = _undo_checkpoint_counter
    text = _undo_state_text(state)
    _undo_state_store[_undo_checkpoint_counter] = text
    scene.smart_tools_manager_undo_index = _undo_checkpoint_counter
    _last_undo_state_text = text
    while len(_undo_state_store) > UNDO_CACHE_MAX_ITEMS:
        oldest = min(_undo_state_store)
        _undo_state_store.pop(oldest, None)
    if push:
        _push_undo_step(context, _text("Smart Tools Manager", "スマートツールマネージャー", context))


def _restore_undo_payload(payload: dict[str, Any], context=None) -> bool:
    global _undo_restore_in_progress, _last_undo_state_text
    # Never turn an ephemeral default checkpoint into persisted authority. Undo
    # restoration is available only after a settings payload has been verified
    # or an explicit Manager edit has completed its generation-checked commit.
    if not _settings_authoritative:
        return False
    if (
        payload.get("schema") != "jelararagi.smart_tools_manager.undo"
        or payload.get("version") not in {1, 2, 3}
    ):
        return False
    matrix = _bits_to_matrix(payload.get("matrix_bits"))
    selection = payload.get("selection")
    ui = payload.get("ui")
    runtime = payload.get("runtime")
    if not isinstance(selection, dict) or not isinstance(ui, dict) or not isinstance(runtime, dict):
        return False
    workspace = selection.get("workspace")
    editor = selection.get("editor")
    mode = selection.get("mode")
    if workspace not in _WORKSPACE_KEYS or editor not in _EDITOR_KEYS or mode not in _MODE_KEYS:
        return False
    current = _cached_state_for_ui()
    restored = copy.deepcopy(current)
    restored["matrix"] = matrix
    restored["selection"] = {
        "workspace": workspace,
        "editor": editor,
        "mode": _DEFAULT_MODE,
    }
    for key in ("n_panel_state_save", "show_always_on_toggles"):
        if key in ui:
            restored["ui"][key] = _strict_bool(ui.get(key), f"undo ui.{key}")
    for key in RESIDENT_RUNTIME_DEFAULTS:
        if key in runtime:
            restored["runtime"][key] = _strict_bool(runtime.get(key), f"undo runtime.{key}")
    restored["runtime"].update(RETIRED_RUNTIME_VALUES)

    def mutation(state):
        state["matrix"] = copy.deepcopy(restored["matrix"])
        state["selection"] = copy.deepcopy(restored["selection"])
        state["ui"] = copy.deepcopy(restored["ui"])
        state["runtime"] = copy.deepcopy(restored["runtime"])

    previous = _undo_restore_in_progress
    _undo_restore_in_progress = True
    try:
        ok, committed, state = _commit_settings_mutation(
            mutation,
            authority_source="UNDO_RESTORE",
        )
        if not ok:
            return False
        _sync_properties_from_settings(_manager_props(context or bpy.context))
        if committed:
            _reconcile_resident_resources(state, context=context)
        _update_runtime_status(context)
        _last_undo_state_text = _undo_state_text(payload)
        return True
    finally:
        _undo_restore_in_progress = previous


def _restore_undo_state_from_scene(context=None, *, reason: str = "undo") -> None:
    del reason
    scene = _undo_scene(context)
    if scene is None:
        return
    try:
        index = int(getattr(scene, "smart_tools_manager_undo_index", 0) or 0)
    except Exception:
        return
    text = _undo_state_store.get(index, "")
    if not text:
        return
    try:
        payload = json.loads(text)
        _restore_undo_payload(payload, context)
    except Exception:
        _runtime_errors["UNDO_RESTORE"] = traceback.format_exc(limit=5)


@persistent
def _undo_post_handler(_dummy=None) -> None:
    _restore_undo_state_from_scene(bpy.context, reason="undo")


@persistent
def _redo_post_handler(_dummy=None) -> None:
    _restore_undo_state_from_scene(bpy.context, reason="redo")


def _initialize_undo_state(context=None) -> None:
    # Missing/corrupt primary+backup leaves only an ephemeral UI default. Do not
    # place that unverified state in Blender's undo stream, because an unrelated
    # Undo/Redo event could otherwise persist it as generation 1.
    if not _settings_authoritative:
        return
    scene = _undo_scene(context)
    if scene is None or not hasattr(scene, "smart_tools_manager_undo_index"):
        return
    _set_scene_undo_state(context, reason="initialize", push=False)


def _runtime_message_text(context=None) -> str:
    state = _cached_state_for_ui()
    lines = [
        _format_text(
            "Placement matrix: {workspace_count} workspaces x {editor_count} editors x {tool_count} tools = {cell_count} explicit booleans.",
            "配置マトリクス: {workspace_count}ワークスペース x {editor_count}エディター x {tool_count}ツール = {cell_count}個の明示的真偽値です。",
            context,
            workspace_count=len(_WORKSPACE_ORDER),
            editor_count=len(_EDITOR_ORDER),
            tool_count=len(_TOOL_ORDER),
            cell_count=MATRIX_CELL_COUNT,
        ),
        _text(
            "Native Suite Panels own their categories and bodies. The Manager uses only its read-only placement API and Blender workspace owner filters.",
            "各スイートのネイティブパネルがカテゴリーと本文を所有します。マネージャーは読み取り専用配置APIとBlenderワークスペース所有者フィルターだけを使用します。",
            context,
        ),
        _format_text(
            "Settings generation: {generation}.",
            "設定世代: {generation}。",
            context,
            generation=int(state.get('generation', 0) or 0),
        ),
    ]
    if not _settings_authoritative:
        lines.append(_text(
            "Placement API is currently fail-open because no verified settings payload is available.",
            "検証済み設定を使用できないため、現在の配置APIはフェイルオープンです。",
            context,
        ))
    for key, message in sorted(_runtime_errors.items()):
        lines.append(_format_text(
            "Runtime issue [{key}]: {message}",
            "実行時の問題 [{key}]: {message}",
            context,
            key=str(key or ""),
            message=str(message or ""),
        ))
    return "\n".join(lines)


_RUNTIME_ERROR_TEXT = {
    "CLASS_UNREGISTER": ("Some Manager parts could not be unloaded.", "マネージャーの一部を終了できませんでした。"),
    "LEGACY_ROUTER_RETIRE": ("An old panel-routing setup could not be removed.", "古いパネル振り分けの設定を外せませんでした。"),
    "RULE_MATRIX_COMMIT_SUBSCRIBER": ("A tool could not receive a rule change.", "ルールの変更をツールへ知らせられませんでした。"),
    "SETTINGS": ("The settings file could not be read or saved.", "設定ファイルを読み書きできませんでした。"),
    "SETTINGS_BACKUP": ("The settings backup could not be made.", "設定のバックアップを作れませんでした。"),
    "SETTINGS_BACKUP_ROLLBACK": ("The settings backup could not be restored.", "設定のバックアップを戻せませんでした。"),
    "SETTINGS_CONFLICT": ("Another Blender changed the settings file. Reload to read it again.", "別の Blender が設定ファイルを変えました。読み直してください。"),
    "SETTINGS_LOCK": ("The settings file is in use by another Blender.", "設定ファイルを別の Blender が使っています。"),
    "SETTINGS_LOCK_RELEASE": ("The settings file could not be released.", "設定ファイルの使用を終えられませんでした。"),
    "SETTINGS_MUTATION": ("A rule change could not be saved.", "ルールの変更を保存できませんでした。"),
    "SETTINGS_NOT_READY": ("The settings are not ready yet.", "設定の準備ができていません。"),
    "SETTINGS_RECOVERY": ("The settings could not be recovered from the backup.", "バックアップから設定を戻せませんでした。"),
    "SETTINGS_UNREGISTER": ("The settings could not be saved when closing.", "終了の時に設定を保存できませんでした。"),
    "SETTINGS_WRITE_BLOCKED": ("Saving is stopped to protect the settings file.", "設定ファイルを守るため、保存を止めています。"),
    "UNDO_RESTORE": ("The rules could not be restored after Undo or Redo.", "元に戻す／やり直しの後にルールを戻せませんでした。"),
    "WORKSPACE_BRIDGE_ENDPOINT": ("The connection between tools could not be set up.", "ツールとのつなぎを作れませんでした。"),
    "WORKSPACE_FILTER": ("The rules could not be applied to a workspace.", "ワークスペースへルールを当てはめられませんでした。"),
    "WORKSPACE_FILTER_LIMIT": ("Too many add-ons to apply the rules to a workspace.", "アドオンが多すぎて、ワークスペースへルールを当てはめられませんでした。"),
    "WORKSPACE_FILTER_RESTORE": ("A workspace filter could not be put back.", "ワークスペースの絞り込みを元に戻せませんでした。"),
}


def _runtime_message_summary(context=None) -> str:
    """Readable problem lines for the screen; Copy All keeps the full technical text."""
    lines = []
    if not _settings_authoritative:
        lines.append(_text(
            "The settings could not be verified, so every tool's panels are shown for now.",
            "設定を確かめられないため、今は全ツールのパネルを表示しています。",
            context,
        ))
    for key in sorted(_runtime_errors):
        lines.append(_text(*_RUNTIME_ERROR_TEXT.get(
            key, ("An unexpected problem occurred.", "予期しない問題が起きました。")), context))
    return "\n".join(dict.fromkeys(lines))


def _wrap_text_for_ui(text: str, width: int = RUNTIME_MESSAGE_WRAP_WIDTH) -> list[str]:
    result: list[str] = []
    for raw_line in str(text or "").splitlines() or [""]:
        wrapped = textwrap.wrap(raw_line, width=max(20, int(width)), replace_whitespace=False)
        result.extend(wrapped or [""])
    return result


def _sync_runtime_message_lines(props, context=None, *, popup_width: bool = False) -> None:
    if props is None:
        return
    message = _runtime_message_text(context)
    width = RUNTIME_MESSAGE_POPUP_WRAP_WIDTH if popup_width else RUNTIME_MESSAGE_WRAP_WIDTH
    lines = _wrap_text_for_ui(message, width=width)
    with _property_sync_guard():
        _assign_property(props, "runtime_message_text", message)
        props.runtime_message_lines.clear()
        for line in lines:
            item = props.runtime_message_lines.add()
            item.text = line
        maximum = max(len(props.runtime_message_lines) - 1, 0)
        _assign_property(
            props,
            "runtime_message_index",
            min(max(int(getattr(props, "runtime_message_index", 0)), 0), maximum),
        )


def _update_runtime_status(context=None) -> None:
    _runtime_status.clear()
    for tool_key in _TOOL_ORDER:
        _runtime_status[tool_key] = (
            "active" if _tool_active_in_preferences(tool_key, context) else "not_active"
        )


def _tool_runtime_label(tool_key: str, props=None, context=None):
    if tool_key in _runtime_errors:
        return _text("Error", "エラー", context), "ERROR"
    active = _tool_active_in_preferences(tool_key, context)
    rule_on = False
    if props is not None:
        rule_on = bool(getattr(props, _TOOL_PROP_BY_KEY[tool_key], False))
    if active and rule_on:
        return _text("Rule ON / Suite active", "ルールON / スイート有効", context), "CHECKMARK"
    if active:
        return _text("Rule OFF / Suite active", "ルールOFF / スイート有効", context), "FILTER"
    if rule_on:
        return _text("Rule ON / Suite inactive", "ルールON / スイート無効", context), "UNLINKED"
    return _text("Rule OFF / Suite inactive", "ルールOFF / スイート無効", context), "HIDE_ON"


def _selected_rule_matches_current_screen(props, context=None) -> bool:
    if props is None:
        return False
    workspace_key = _active_workspace_key(context)
    if workspace_key != getattr(props, "selected_workspace", ""):
        return False
    editor_key = _context_editor_key(context)
    return editor_key == getattr(props, "selected_editor", "")


def _rule_has_enabled_tool(workspace_key: str, editor_key: str) -> bool:
    if workspace_key not in _WORKSPACE_KEYS or editor_key not in _EDITOR_KEYS:
        return False
    return any(_rule_value(workspace_key, editor_key, tool_key) for tool_key in _TOOL_ORDER)


def _draft_current_keys_from_props(props) -> tuple[str, str]:
    state = _cached_state_for_ui()
    if props is None:
        return state["selection"]["workspace"], state["selection"]["editor"]
    workspace = str(getattr(props, "selected_workspace", "") or "")
    editor = str(getattr(props, "selected_editor", "") or "")
    return (
        workspace if workspace in _WORKSPACE_KEYS else state["selection"]["workspace"],
        editor if editor in _EDITOR_KEYS else state["selection"]["editor"],
    )


def _draft_flush_current_props(props, persist: bool = True) -> None:
    del persist
    if props is not None:
        _on_tool_rule_update(props, bpy.context)


def _begin_edit_session(props=None) -> None:
    _sync_properties_from_settings(props or _manager_props(bpy.context))


def apply_current_context(
    context=None,
    *,
    force: bool = False,
    force_sidebar: bool = False,
    selected_workspace: str | None = None,
    selected_editor: str | None = None,
    source: str = "manual",
) -> bool:
    del force, force_sidebar, source
    context = context or bpy.context
    workspace_key = selected_workspace or _active_workspace_key(context)
    editor_key = selected_editor or _context_editor_key(context)
    redraw_acknowledgement: list[bool] = []
    owner_filters_changed = _sync_workspace_owner_filters(
        workspace_keys={workspace_key} if workspace_key in _WORKSPACE_KEYS else None,
        context=context,
        redraw_acknowledgement=redraw_acknowledgement,
    )
    if not (owner_filters_changed and redraw_acknowledgement == [True]):
        _tag_supported_areas_redraw()
    return bool(
        workspace_key in _WORKSPACE_KEYS
        and editor_key in _EDITOR_KEYS
        and _rule_has_enabled_tool(workspace_key, editor_key)
    )


def apply_all_manager_rules(context=None, *, force_sidebar: bool = False) -> bool:
    del force_sidebar
    redraw_acknowledgement: list[bool] = []
    owner_filters_changed = _sync_workspace_owner_filters(
        context=context,
        redraw_acknowledgement=redraw_acknowledgement,
    )
    props = _manager_props(context or bpy.context)
    workspace_key, editor_key = _draft_current_keys_from_props(props)
    if not (owner_filters_changed and redraw_acknowledgement == [True]):
        _tag_supported_areas_redraw()
    return _rule_has_enabled_tool(workspace_key, editor_key)


def _load_custom_icons() -> None:
    global _preview_collection, _custom_icons
    _custom_icons = {}
    try:
        import bpy.utils.previews

        _preview_collection = bpy.utils.previews.new()
        icon_path = _extension_root() / "icon" / "smart_tools.png"
        if icon_path.exists():
            _custom_icons["manager"] = _preview_collection.load(
                "manager", str(icon_path), "IMAGE"
            )
    except Exception:
        _preview_collection = None
        _custom_icons = {}


def _unload_custom_icons() -> None:
    global _preview_collection, _custom_icons
    if _preview_collection is not None:
        import bpy.utils.previews

        bpy.utils.previews.remove(_preview_collection)
    _preview_collection = None
    _custom_icons = {}


def _manager_icon_value() -> int:
    try:
        return int(getattr(_custom_icons.get("manager"), "icon_id", 0) or 0)
    except Exception:
        return 0


class SmartToolsRuntimeMessageLine(PropertyGroup):
    text: StringProperty(
        name="Text",
        description="Displays one line of the current Smart Tools Manager runtime message.",
        default="",
        options={"SKIP_SAVE"},
    )


class SMARTTOOLS_UL_runtime_messages(UIList):
    bl_idname = "SMARTTOOLS_UL_runtime_messages"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        del context, data, icon, active_data, active_propname, index
        row = layout.row(align=True)
        row.label(text=getattr(item, "text", "") or " ", translate=False)


class SmartToolsManagerProperties(PropertyGroup):
    n_panel_state_save: BoolProperty(
        name="N-panel State Save",
        description="Save Manager settings to Smart_Tools_Manager/Smart_Tools_Manager.json. Turning this off is saved once; later edits stay memory-only until it is enabled again.",
        default=True,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    show_always_on_toggles: BoolProperty(
        name="Resident Feature Toggles",
        description="Open or close the resident-feature section in Smart Tools Manager preferences and popup.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_automatic_context_sync: BoolProperty(
        name="Automatic Context Sync",
        description="Apply the Manager rules the moment you change them or switch workspace. Nothing keeps running in the background.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_source_panel_filters: BoolProperty(
        name="Source Panel Filters",
        description="Match Blender's workspace add-on filter to the Manager rules. The Manager never replaces how a panel is drawn.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_topbar_button: BoolProperty(
        name="Top Bar Button",
        description="Keep the Smart Tools Manager button registered in Blender's Top Bar.",
        default=False, options={"SKIP_SAVE"}, update=_on_manager_common_update,
    )
    runtime_load_restore_handler: BoolProperty(
        name="File-load Restore",
        description="Restore Manager settings after a Blender file is loaded.",
        default=False, options={"SKIP_SAVE"}, update=_on_manager_common_update,
    )
    runtime_undo_redo_handlers: BoolProperty(
        name="Undo/Redo Synchronization",
        description="Match the Manager rules again after Blender undo and redo.",
        default=False, options={"SKIP_SAVE"}, update=_on_manager_common_update,
    )
    runtime_api_bridge: BoolProperty(
        name="Notify Other Smart Tools",
        description="Let enabled Smart Tools receive a notice when the Manager rules change.",
        default=True, options={"SKIP_SAVE"}, update=_on_manager_common_update,
    )
    runtime_panel_proxies: BoolProperty(
        name="Runtime Panel Proxies",
        description="Compatibility property retained for existing files. Runtime Panel proxies are permanently disabled and no proxy Panel is registered.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_category_anchors: BoolProperty(
        name="Category Anchors",
        description="Compatibility property retained for existing files. Manager-owned category anchors are permanently disabled; each Suite owns its native category and body.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_ui_callback_repair: BoolProperty(
        name="UI Callback Repair",
        description="Compatibility property retained for existing files. Registered UI callbacks are never repaired or replaced by the Manager.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_transform_guard: BoolProperty(
        name="Transform Guard",
        description="Compatibility property retained for existing files. The Manager never edits object transforms.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    runtime_stale_proxy_cleanup: BoolProperty(
        name="Stale Proxy Cleanup",
        description="Compatibility property retained for existing files. The Manager never scans or removes third-party proxy Panels.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_manager_common_update,
    )
    selected_workspace: StringProperty(
        name="Workspace",
        description="Choose the Blender workspace whose Smart Tool ON/OFF rules are being edited. The selection and all checkboxes are saved to Smart_Tools_Manager.json when saving is enabled.",
        default="LAYOUT",
        options={"SKIP_SAVE"},
        update=_on_selection_update,
    )
    selected_editor: StringProperty(
        name="Editor",
        description="Choose the editor whose N-panel Smart Tool rules are being edited. This decides where each Smart Tool's panels can appear; it does not open or close the N-panel itself.",
        default="VIEW_3D",
        options={"SKIP_SAVE"},
        update=_on_selection_update,
    )
    runtime_message_lines: CollectionProperty(
        type=SmartToolsRuntimeMessageLine,
        name="Runtime Message Lines",
        description="Lines of the current Smart Tools Manager runtime message shown in the list.",
        options={"SKIP_SAVE"},
    )
    runtime_message_index: IntProperty(
        name="Runtime Message",
        description="Selects the line shown in the manager runtime-message list.",
        default=0,
        options={"SKIP_SAVE"},
    )
    runtime_message_text: StringProperty(
        name="Runtime Message Text",
        description="Stores the current Smart Tools Manager status message displayed in its dialog.",
        default="",
        options={"SKIP_SAVE"},
    )


for _tool in _TOOLS:
    _prop_id = _TOOL_PROP_BY_KEY[_tool["key"]]
    SmartToolsManagerProperties.__annotations__[_prop_id] = BoolProperty(
        name=_tool["en"],
        description="Turn this Smart Tool ON for the selected workspace and editor. When saving is enabled, the setting is saved immediately. The add-on stays enabled; only where its panels appear changes.",
        default=False,
        options={"SKIP_SAVE"},
        update=_on_tool_rule_update,
    )


def _draw_manager_toggle_row(layout, owner, prop_name: str, label: str, *, locked: bool = False) -> None:
    enabled = bool(getattr(owner, prop_name, False))
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    split.row(align=True).label(text=label)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.use_property_split = False
    right.use_property_decorate = False
    right.enabled = not locked
    right.prop(
        owner,
        prop_name,
        text=_text("On", "有効") if enabled else _text("Off", "無効"),
        icon="CHECKBOX_HLT" if enabled else "CHECKBOX_DEHLT",
        toggle=True,
    )


class SMARTTOOLS_PT_manager(Panel):
    bl_idname = "SMARTTOOLS_PT_manager"
    bl_label = "Smart Tools Manager"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Tools"

    @classmethod
    def poll(cls, context):
        del cls
        return bool(
            _manager_registered
            and placement_allowed("SMART_TOOLS_MANAGER", context)
        )

    def draw(self, context):
        layout = self.layout
        props = _manager_props(context)
        if props is None:
            layout.label(
                text=_text(
                    "Manager properties are not available.",
                    "マネージャープロパティを使用できません。",
                    context,
                ),
                icon="ERROR",
            )
            return
        box = layout.box()
        open_state = _draw_always_on_header(box, props, context)
        if open_state:
            body = box.column(align=True)
            body.use_property_split = False
            body.use_property_decorate = False
            _draw_manager_toggle_row(
                body,
                props,
                "n_panel_state_save",
                _text("N-panel State Save", "Nパネル状態保存", context),
                locked=True,
            )
            body.separator(factor=0.5)
            _draw_manager_toggle_row(
                body,
                props,
                "runtime_automatic_context_sync",
                _text("Automatic Context Sync", "自動コンテキスト同期", context),
            )
            _draw_manager_toggle_row(
                body,
                props,
                "runtime_panel_proxies",
                _text("Runtime Panel Proxies", "ランタイムパネルプロキシ", context),
                locked=True,
            )
            _draw_manager_toggle_row(
                body,
                props,
                "runtime_ui_callback_repair",
                _text("UI Callback Repair", "UIコールバック修復", context),
                locked=True,
            )
            _draw_manager_toggle_row(
                body,
                props,
                "runtime_transform_guard",
                _text("Transform Guard", "トランスフォーム保護", context),
                locked=True,
            )
            _draw_manager_toggle_row(
                body,
                props,
                "runtime_stale_proxy_cleanup",
                _text("Stale Proxy Cleanup", "旧プロキシ清掃", context),
                locked=True,
            )
        layout.separator()
        layout.operator(
            "smart_tools.open_manager",
            text=_text("Open Manager", "マネージャーを開く", context),
            icon="PREFERENCES",
        )


class _SmartToolsManagerRootPanelMixin:
    """Static full-body Manager root used by the other ten physical spaces."""

    bl_label = "Smart Tools Manager"
    bl_region_type = "UI"
    bl_category = "Smart Tools"

    @classmethod
    def poll(cls, context):
        del cls
        return bool(
            _manager_registered
            and placement_allowed("SMART_TOOLS_MANAGER", context)
        )

    def draw(self, context):
        # Reuse the complete canonical body; these are not category anchors and
        # never delegate drawing to a third-party Suite Panel.
        SMARTTOOLS_PT_manager.draw(self, context)


class SMARTTOOLS_PT_manager_image(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_image"
    bl_space_type = "IMAGE_EDITOR"


class SMARTTOOLS_PT_manager_node(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_node"
    bl_space_type = "NODE_EDITOR"


class SMARTTOOLS_PT_manager_sequence(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_sequence"
    bl_space_type = "SEQUENCE_EDITOR"


class SMARTTOOLS_PT_manager_clip(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_clip"
    bl_space_type = "CLIP_EDITOR"


class SMARTTOOLS_PT_manager_dopesheet(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_dopesheet"
    bl_space_type = "DOPESHEET_EDITOR"


class SMARTTOOLS_PT_manager_graph(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_graph"
    bl_space_type = "GRAPH_EDITOR"


class SMARTTOOLS_PT_manager_nla(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_nla"
    bl_space_type = "NLA_EDITOR"


class SMARTTOOLS_PT_manager_text(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_text"
    bl_space_type = "TEXT_EDITOR"


class SMARTTOOLS_PT_manager_filebrowser(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_filebrowser"
    bl_space_type = "FILE_BROWSER"


class SMARTTOOLS_PT_manager_spreadsheet(_SmartToolsManagerRootPanelMixin, Panel):
    bl_idname = "SMARTTOOLS_PT_manager_spreadsheet"
    bl_space_type = "SPREADSHEET"


def _draw_workspace_column(layout, props, context) -> None:
    box = layout.box()
    box.label(text=_text("Workspace", "ワークスペース", context), icon="WORKSPACE")
    col = box.column(align=True)
    selected = props.selected_workspace if props.selected_workspace in _WORKSPACE_KEYS else "LAYOUT"
    for key, en, ja, _aliases in _WORKSPACE_ITEMS:
        op = col.operator(
            "smart_tools.select_workspace",
            text=_text(en, ja, context),
            icon="RADIOBUT_ON" if key == selected else "RADIOBUT_OFF",
            depress=key == selected,
        )
        op.key = key


def _draw_editor_column(layout, props, context) -> None:
    box = layout.box()
    box.label(
        text=_text("Editor with N-panel", "Nパネル対応エディター", context),
        icon="WINDOW",
    )
    col = box.column(align=True)
    selected = props.selected_editor if props.selected_editor in _EDITOR_KEYS else "VIEW_3D"
    for key, en, ja in _EDITOR_ITEMS:
        op = col.operator(
            "smart_tools.select_editor",
            text=_text(en, ja, context),
            icon="RADIOBUT_ON" if key == selected else "RADIOBUT_OFF",
            depress=key == selected,
        )
        op.key = key


def _draw_tools_column(layout, props, context) -> None:
    box = layout.box()
    title = box.row(align=True)
    title.label(text=_text("Smart Tools", "スマートツール", context), icon="TOOL_SETTINGS")
    title.operator("smart_tools.set_all_tools", text=_text("All Enabled", "全部有効", context)).state = True
    title.operator("smart_tools.set_all_tools", text=_text("All Disabled", "全部無効", context)).state = False
    col = box.column(align=True)
    for tool in _TOOLS:
        tool_key = tool["key"]
        prop_id = _TOOL_PROP_BY_KEY[tool_key]
        status_text, status_icon = _tool_runtime_label(tool_key, props, context)
        state = bool(getattr(props, prop_id, False))
        row = col.row(align=True)
        split = row.split(factor=0.17, align=True)
        toggle = split.row(align=True)
        toggle.prop(
            props,
            prop_id,
            text=_text("Enabled", "有効", context) if state else _text("Disabled", "無効", context),
            toggle=True,
        )
        name_status = split.split(factor=0.50, align=True)
        name_status.label(text=_tool_label(tool, context), icon="DOT", translate=False)
        status = name_status.row(align=True)
        status.alignment = "LEFT"
        status.label(text=status_text, icon=status_icon)
    if _runtime_errors:
        err_box = box.box()
        title = err_box.row(align=True)
        title.label(text=_text("Runtime messages", "実行メッセージ", context), icon="ERROR")
        title.operator(
            "smart_tools.open_runtime_messages",
            text=_text("Open", "開く", context),
            icon="TEXT",
        )
        for line in _wrap_text_for_ui(_runtime_message_summary(context))[:RUNTIME_MESSAGE_PREVIEW_ROWS]:
            err_box.label(text=line or " ", icon="DOT", translate=False)


def _draw_always_on_header(box, props, context) -> bool:
    """Top-level heading: arrow button, borderless title, separator, help."""
    open_state = bool(getattr(props, "show_always_on_toggles", False))
    header = box.row(align=True)
    header.prop(
        props,
        "show_always_on_toggles",
        text="",
        icon="TRIA_DOWN" if open_state else "TRIA_RIGHT",
        emboss=True,
        toggle=True,
    )
    header.prop(
        props,
        "show_always_on_toggles",
        text=_text("Always-on Toggles", "常時機能切り替え", context),
        icon="TIME",
        emboss=False,
        toggle=True,
    )
    header.separator(factor=0.35)
    header.operator("smart_tools.manager_help", text="", icon="QUESTION")
    return open_state


def _draw_resident_settings(layout, props, context) -> None:
    box = layout.box()
    if not _draw_always_on_header(box, props, context):
        return
    column = box.column(align=True)
    column.prop(
        props,
        "n_panel_state_save",
        text=_text("N-panel State Save", "Nパネル状態保存", context),
    )
    column.prop(
        props,
        "runtime_automatic_context_sync",
        text=_text("Automatic context sync", "コンテキストを自動同期", context),
    )
    column.prop(
        props,
        "runtime_source_panel_filters",
        text=_text("Source panel filters", "ソースパネルフィルター", context),
    )
    column.prop(
        props,
        "runtime_topbar_button",
        text=_text("Top Bar button", "トップバーボタン", context),
    )
    column.prop(
        props,
        "runtime_load_restore_handler",
        text=_text("Restore after file load", "ファイル読込後に復元", context),
    )
    column.prop(
        props,
        "runtime_undo_redo_handlers",
        text=_text("Undo/Redo synchronization", "元に戻す／やり直し同期", context),
    )
    column.prop(
        props,
        "runtime_api_bridge",
        text=_text("Notify other Smart Tools", "他のスマートツールへの通知", context),
    )


def draw_manager_ui(layout, context) -> None:
    props = _manager_props(context)
    if props is None:
        layout.label(
            text=_text(
                    "Manager properties are not available.",
                    "マネージャープロパティを使用できません。",
                    context,
                ),
            icon="ERROR",
        )
        return
    header = layout.row(align=True)
    icon_value = _manager_icon_value()
    if icon_value:
        header.label(
            text=_text("Smart Tools Manager", "スマートツールマネージャー", context),
            icon_value=icon_value,
        )
    else:
        header.label(
            text=_text("Smart Tools Manager", "スマートツールマネージャー", context),
            icon="PREFERENCES",
        )
    header.operator("smart_tools.manager_help", text="", icon="QUESTION")
    header.operator("smart_tools.refresh_manager", text="", icon="FILE_REFRESH")
    layout.operator("smart_tools.release_cleanup", text=_text("Release Cleanup", "リリース整理", context))
    layout.separator()
    _draw_resident_settings(layout, props, context)
    layout.separator()
    split = layout.split(factor=0.23, align=False)
    col1 = split.column(align=True)
    split_right = split.split(factor=0.37, align=False)
    col2 = split_right.column(align=True)
    col3 = split_right.column(align=True)
    _draw_workspace_column(col1, props, context)
    _draw_editor_column(col2, props, context)
    _draw_tools_column(col3, props, context)


class SmartToolsManagerPreferences(AddonPreferences):
    bl_idname = __package__ or ADDON_ID

    def draw(self, context) -> None:
        props = _manager_props(context)
        if props is None:
            self.layout.label(
                text=_text(
                    "Manager properties are not available.",
                    "マネージャープロパティを使用できません。",
                    context,
                ),
                icon="ERROR",
            )
            return
        row = self.layout.row(align=True)
        row.operator("smart_tools.open_manager", text=_text("Open Smart Tools Manager", "スマートツールマネージャーを開く", context))
        row.operator("smart_tools.release_cleanup", text=_text("Release Cleanup", "リリース整理", context))
        _draw_resident_settings(self.layout, props, context)


# A props dialog still owns its Operator RNA until Blender closes the popup.
# Retire that RNA only on the next event-loop turn after the last dialog closes.
_active_dialogs = set()
_dialog_unregister_pending = False


def _finish_deferred_dialog_unregister():
    global _dialog_unregister_pending
    if _dialog_unregister_pending and not _active_dialogs:
        _dialog_unregister_pending = False
        unregister()
    return None


def _finish_manager_dialog(operator):
    _active_dialogs.discard(operator.as_pointer())
    pending = _dialog_unregister_pending
    if pending and not _active_dialogs:
        if not bpy.app.timers.is_registered(_finish_deferred_dialog_unregister):
            bpy.app.timers.register(_finish_deferred_dialog_unregister, first_interval=0.2)
    return pending


def _invoke_manager_dialog(operator, context, **kwargs):
    if _dialog_unregister_pending:
        return {'CANCELLED'}
    token = operator.as_pointer()
    _active_dialogs.add(token)
    try:
        result = context.window_manager.invoke_props_dialog(operator, **kwargs)
    except Exception:
        _active_dialogs.discard(token)
        raise
    if 'RUNNING_MODAL' not in result:
        _active_dialogs.discard(token)
    return result


class SMARTTOOLS_OT_release_cleanup(Operator):
    bl_idname = "smart_tools.release_cleanup"
    bl_label = "Release Cleanup"
    bl_description = "Make a new copy without the working data you choose"
    bl_options = {"INTERNAL"}

    request_path: StringProperty(name="Preservation contract (optional)", subtype="FILE_PATH", options={"SKIP_SAVE"})
    output_path: StringProperty(name="New copy", subtype="FILE_PATH", options={"SKIP_SAVE"})
    result_path: StringProperty(name="Result JSON", subtype="FILE_PATH", options={"SKIP_SAVE"})
    page: IntProperty(name="Target page", default=0, min=0, max=release_cleanup.MAX_IDS // 8 - 1, options={"SKIP_SAVE"})

    def invoke(self, context, event):
        release_cleanup.reset_selection()
        release_cleanup._PLAN = None
        context.window.cursor_set("WAIT")
        try:
            release_cleanup.prepare_selection(bpy)
            source = Path(bpy.data.filepath)
            if bpy.data.filepath:
                self.output_path = str(source.with_name(source.stem + "_release.blend"))
                self.result_path = str(source.with_name(source.stem + "_cleanup.json"))
        except Exception as exc:
            release_cleanup._STATUS = ("Inspection failed: " + release_cleanup.reason_text(str(exc), False), "点検失敗: " + release_cleanup.reason_text(str(exc), True))
            self.report({"ERROR"}, _text("Inspection failed: ", "点検失敗: ", context) + release_cleanup.reason_text(str(exc), _text("en", "ja", context) == "ja"))
        context.window.cursor_set("DEFAULT")
        return _invoke_manager_dialog(self, context, width=660)

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.label(text=_text("Release Cleanup", "リリース整理", context))
        row.operator("smart_tools.release_cleanup_help", text="", icon="QUESTION")
        layout.prop(self, "request_path", text=_text("Contract (optional)", "保護契約（任意）", context))
        layout.prop(self, "output_path", text=_text("New copy", "新規コピー", context))
        layout.prop(self, "result_path", text=_text("Result JSON", "結果JSON", context))
        buttons = layout.row(align=True)
        inspect = buttons.operator("smart_tools.release_cleanup_inspect", text=_text("Inspect", "点検", context))
        inspect.request_path = self.request_path
        apply = buttons.operator("smart_tools.release_cleanup_apply", text=_text("Apply to Copy", "コピーへ適用", context))
        apply.output_path = self.output_path
        export = buttons.operator("smart_tools.release_cleanup_export", text=_text("Export Result", "結果を書出", context))
        export.result_path = self.result_path
        japanese = _text("en", "ja", context) == "ja"
        choices = release_cleanup._CHOICES
        if choices:
            layout.prop(self, "page", text=_text("Target page", "対象ページ", context))
            start = min(self.page, (len(choices) - 1) // 8) * 8
            current = {r["operation"]["id"]: r for r in (release_cleanup._PLAN or {}).get("decisions", [])}
            for choice in choices[start:start + 8]:
                key = choice["operation"]["id"]
                decision = current.get(key, choice)
                row = layout.row(align=True)
                row.enabled = choice["decision"] == "CANDIDATE"
                toggle = row.operator("smart_tools.release_cleanup_select", text=release_cleanup.id_label(key, japanese),
                                      translate=False, icon="CHECKBOX_HLT" if key in release_cleanup._SELECTED else "CHECKBOX_DEHLT")
                toggle.key = key
                state = {"CANDIDATE": ("Candidate", "候補"), "PROTECTED": ("Protected", "保護"),
                         "BLOCKED": ("Blocked", "保留")}[decision["decision"]]
                row.label(text=_text(*state, context))
                layout.label(text=release_cleanup.reason_text(decision["reasons"][0], japanese)
                             if decision["reasons"] else "", translate=False)
        layout.label(text=release_cleanup.summary(release_cleanup._PLAN, japanese)
                     if release_cleanup._PLAN else _text(*release_cleanup._STATUS, context))
        blockers = (release_cleanup._PLAN or {}).get("blockers", ())
        for text in blockers[:3]:
            layout.label(text=release_cleanup.reason_text(text, japanese), icon="ERROR", translate=False)
        if len(blockers) > 3:
            layout.label(text=_format_text("{count} more in Export Result", "ほか {count} 件は「結果を書出」で確かめられます", context, count=len(blockers) - 3), translate=False)

    def execute(self, context):
        if _finish_manager_dialog(self):
            return {'CANCELLED'}
        return {"FINISHED"}

    def cancel(self, context):
        _finish_manager_dialog(self)


class SMARTTOOLS_OT_release_cleanup_select(Operator):
    bl_idname = "smart_tools.release_cleanup_select"
    bl_label = "Toggle cleanup target"
    bl_description = "Select only proven disposable working data"
    bl_options = {"INTERNAL"}
    key: StringProperty(
        name="Cleanup Target",
        description="The cleanup row whose check this button switches.",
        options={"SKIP_SAVE"},
    )

    @classmethod
    def description(cls, context, properties):
        row = next((r for r in release_cleanup._CHOICES if r["operation"]["id"] == properties.key), None)
        if row is None:
            return _text("Select only proven disposable working data", "破棄可能と証明された作業データだけを選択", context)
        return "; ".join(dict.fromkeys(release_cleanup.reason_text(reason, _text("en", "ja", context) == "ja") for reason in row["reasons"]))

    def execute(self, context):
        try:
            release_cleanup.select_item(bpy, self.key, self.key not in release_cleanup._SELECTED)
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, _text("Selection refused: ", "選択拒否: ", context) + release_cleanup.reason_text(str(exc), _text("en", "ja", context) == "ja"))
            return {"CANCELLED"}


class SMARTTOOLS_OT_release_cleanup_inspect(Operator):
    bl_idname = "smart_tools.release_cleanup_inspect"
    bl_label = "Inspect"
    bl_description = "Check which data can be removed, without changing anything"
    bl_options = {"INTERNAL"}
    request_path: StringProperty(name="Preservation contract (optional)", subtype="FILE_PATH", options={"SKIP_SAVE"})

    def execute(self, context):
        try:
            try:
                contract = json.loads(Path(bpy.path.abspath(self.request_path)).read_text(encoding="utf-8-sig")) if self.request_path else {}
            except (OSError, ValueError) as exc:
                raise release_cleanup.CleanupRefused("Cannot read the preservation contract") from exc
            if not isinstance(contract, dict):
                raise release_cleanup.CleanupRefused("Unknown preservation contract")
            if set(contract) == {"contract"}:
                contract = contract["contract"]
            release_cleanup.prepare_selection(bpy, contract)
            release_cleanup._STATUS = ("Inspected", "点検済み")
            self.report({"INFO"}, release_cleanup.summary(release_cleanup._PLAN, _text("en", "ja", context) == "ja"))
            return {"FINISHED"}
        except Exception as exc:
            release_cleanup._PLAN = None
            release_cleanup._STATUS = ("Inspection failed: " + release_cleanup.reason_text(str(exc), False), "点検失敗: " + release_cleanup.reason_text(str(exc), True))
            self.report({"ERROR"}, _text("Inspection failed: ", "点検失敗: ", context) + release_cleanup.reason_text(str(exc), _text("en", "ja", context) == "ja"))
            return {"CANCELLED"}


class SMARTTOOLS_OT_release_cleanup_apply(Operator):
    bl_idname = "smart_tools.release_cleanup_apply"
    bl_label = "Apply to Copy"
    bl_description = "Create a new copy without the selected data"
    bl_options = {"INTERNAL"}
    output_path: StringProperty(name="New copy", subtype="FILE_PATH", options={"SKIP_SAVE"})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        try:
            if release_cleanup._PLAN is None:
                raise release_cleanup.CleanupRefused("Inspect first")
            release_cleanup._PLAN = release_cleanup.apply_copy(bpy, release_cleanup._PLAN, bpy.path.abspath(self.output_path), _text("en", "ja", context) == "ja")
            self.report({"INFO"}, _text("Release copy saved", "リリースコピーを保存しました", context))
            return {"FINISHED"}
        except Exception as exc:
            release_cleanup._STATUS = ("Copy not committed", "コピー未確定")
            if release_cleanup._PLAN is not None and release_cleanup._PLAN.get("state") != "APPLIED_TO_COPY":
                release_cleanup._PLAN["state"] = "COPY_NOT_COMMITTED"
                release_cleanup._PLAN["actual_removals"] = []
                release_cleanup._PLAN["failures"] = [release_cleanup.refusal_message(exc)]
            self.report({"ERROR"}, _text("Copy refused: ", "コピー適用拒否: ", context) + release_cleanup.reason_text(release_cleanup.refusal_message(exc), _text("en", "ja", context) == "ja"))
            return {"CANCELLED"}


class SMARTTOOLS_OT_release_cleanup_export(Operator):
    bl_idname = "smart_tools.release_cleanup_export"
    bl_label = "Export Result"
    bl_description = "Save the inspection and removal results to a file"
    bl_options = {"INTERNAL"}
    result_path: StringProperty(name="Result JSON", subtype="FILE_PATH", options={"SKIP_SAVE"})

    def execute(self, context):
        try:
            if release_cleanup._PLAN is None:
                raise release_cleanup.CleanupRefused("Inspect first")
            release_cleanup.export_result(release_cleanup._PLAN, bpy.path.abspath(self.result_path), _text("en", "ja", context) == "ja")
            self.report({"INFO"}, _text("Result exported", "結果を書き出しました", context))
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, _text("Export failed: ", "書出失敗: ", context) + release_cleanup.reason_text(release_cleanup.refusal_message(exc), _text("en", "ja", context) == "ja"))
            return {"CANCELLED"}


class SMARTTOOLS_OT_release_cleanup_help(Operator):
    bl_idname = "smart_tools.release_cleanup_help"
    bl_label = "Release Cleanup Help"
    bl_description = "Target, steps, recovery and limits"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        return _invoke_manager_dialog(self, context, width=820)

    def draw(self, context):
        lines = (
            ("Save your input .blend first. Inspection never changes it.", "入力.blendを先に保存します。点検では入力を変更しません。"),
            ("Open this dialog to inspect. Nothing is selected for removal initially; Inspect resets all checks.", "この画面を開くと点検します。最初の削除選択は0です。点検ボタンでチェックを全解除します。"),
            ("Browse Target page and check only disposable work items. Protected/blocked rows cannot be selected.", "対象ページを送り、破棄してよい作業データだけにチェックします。保護・保留の行は選択できません。"),
            ("Rows show the decision and reason; hover the checkbox for full reasons. No handwritten JSON is required.", "各行で判定と理由を確認し、チェックにマウスを重ねると全理由を見られます。JSON手書きは不要です。"),
            ("Select an unused object and its data together. Selecting data alone retains it while an unselected owner uses it.", "未使用オブジェクトとそのデータを一緒に選びます。データだけでは未選択の所有者が使うため保持します。"),
            ("Optional preservation JSON accepts preserve_names / preserve_ids and preserve_all_for_dynamic_scripts only; Inspect loads it.", "任意の保護JSONはpreserve_names／preserve_ids／preserve_all_for_dynamic_scriptsだけを受け付け、点検で読み込みます。"),
            ("Visible scene content, dependencies, fake users, links and textures are retained.", "表示シーン、依存、偽ユーザー、リンク、テクスチャは保持します。外部ファイルは削除しません。"),
            ("Group/key, NLA, cache and work-mark requests remain blocked when preservation is unprovable.", "グループ・キー・NLA・キャッシュ・作業印は保全を証明できないため保留します。"),
            ("Data with no users is not written to the saved file, so its row stays blocked and the copy does not contain it.", "使っていないデータは保存ファイルに入らないため、その行は保留になります。コピーにも入りません。"),
            ("Unknown scripts or missing dependencies block apply; preserve_all_for_dynamic_scripts retains all IDs.", "不明なスクリプトや依存欠落は適用を止めます。preserve_all_for_dynamic_scriptsは全IDを保持します。"),
            ("Blockers are listed at the bottom of this dialog. Inspecting again does not clear them until their cause is gone.", "阻害は画面のいちばん下に出ます。原因を除くまでは、点検し直しても消えません。"),
            ("Large files take a while when the dialog opens and at each Inspect or check; Blender does not respond until it finishes.", "大きなファイルでは、画面を開く時と、点検やチェックのたびに時間がかかります。終わるまでBlenderは反応しません。"),
            (f"A file with more than {release_cleanup.MAX_IDS} data-blocks cannot be inspected.", f"データが {release_cleanup.MAX_IDS} 個を超えるファイルは点検できません。"),
            ("Inspect, choose a new .blend output, then Apply to Copy and confirm. Existing files are never replaced.", "点検後、新規.blend出力先を指定し、コピーへ適用を確認します。既存ファイルは上書きしません。"),
            ("A changed source/graph requires another inspection. Failed copies are discarded; inspect the failure JSON.", "入力や参照が変われば再点検します。失敗コピーは破棄され、失敗JSONで理由を確認できます。"),
            ("The sidecar .cleanup.json and .cleanup.txt record committed removals separately from failures and retained items.", "付属.cleanup.jsonと.cleanup.txtで確定した実削除と、失敗・保護・保留を区別します。"),
            ("Export Result also writes JSON plus a readable TXT in the UI language. Neither file is overwritten.", "結果を書出でJSONと画面言語の要約TXTを保存します。どちらも既存ファイルを上書きしません。"),
            ("To restore, close the new copy and open your unchanged original .blend. Keep originals and external assets.", "戻すには新規コピーを閉じ、変更していない原本.blendを開きます。原本と外部素材を保管してください。"),
            ("No recursive orphan purge. Geometry, deform weights and adopted rig values are never adjusted.", "孤立データの再帰一括削除は行いません。形状・変形ウェイト・採用リグ値を調整しません。"),
        )
        for english, japanese in lines:
            self.layout.label(text=_text(english, japanese, context))

    def execute(self, context):
        if _finish_manager_dialog(self):
            return {'CANCELLED'}
        return {"FINISHED"}

    def cancel(self, context):
        _finish_manager_dialog(self)


class SMARTTOOLS_OT_select_workspace(Operator):
    bl_idname = "smart_tools.select_workspace"
    bl_label = "Select Workspace"
    bl_description = "Choose the Blender workspace whose Smart Tool ON/OFF rules are being edited. The selection is saved when N-panel State Save is enabled."
    bl_options = {"INTERNAL"}

    key: StringProperty(
        name="Workspace",
        description="The workspace this button selects for rule editing.",
        default="",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        if self.key not in _WORKSPACE_KEYS:
            return {"CANCELLED"}
        props = _manager_props(context)
        if props is None or props.selected_workspace == self.key:
            return {"CANCELLED"}
        props.selected_workspace = self.key
        return {"FINISHED"}


class SMARTTOOLS_OT_set_all_tools(Operator):
    bl_idname = "smart_tools.set_all_tools"
    bl_label = "Set All Smart Tools"
    bl_description = "Enable or disable every Smart Tool for the selected workspace and editor"
    bl_options = {"INTERNAL"}

    state: BoolProperty(
        name="Turn Smart Tools On",
        description="On turns every Smart Tool on for the selected workspace and editor; off turns them all off.",
        default=True,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        props = _manager_props(context)
        if props is None:
            return {"CANCELLED"}
        workspace, editor = _draft_current_keys_from_props(props)
        value = bool(self.state)

        def mutation(state):
            for tool_key in _TOOL_ORDER:
                state["matrix"][workspace][editor][tool_key] = value

        ok, committed, state = _commit_settings_mutation(
            mutation,
            authority_source="TOOL_RULE_UPDATE",
        )
        _sync_properties_from_settings(props)
        if not ok:
            return {"CANCELLED"}
        _install_placement_gates()
        if committed:
            if _immediate_workspace_sync_enabled(state):
                _sync_workspace_owner_filters(workspace_keys={workspace}, context=context)
            _set_scene_undo_state(context, reason="tool_rule", push=True)
            _update_runtime_status(context)
            _tag_supported_areas_redraw()
        return {"FINISHED"}


class SMARTTOOLS_OT_select_editor(Operator):
    bl_idname = "smart_tools.select_editor"
    bl_label = "Select Editor"
    bl_description = "Choose the editor whose Smart Tool panel rules are being edited."
    bl_options = {"INTERNAL"}

    key: StringProperty(
        name="Editor",
        description="The editor this button selects for rule editing.",
        default="",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        if self.key not in _EDITOR_KEYS:
            return {"CANCELLED"}
        props = _manager_props(context)
        if props is None or props.selected_editor == self.key:
            return {"CANCELLED"}
        props.selected_editor = self.key
        return {"FINISHED"}


class SMARTTOOLS_OT_manager_help(Operator):
    bl_idname = "smart_tools.manager_help"
    bl_label = "Smart Tools Manager Help"
    bl_description = "Show how to select, save and restore Manager rules"
    bl_options = set()

    def invoke(self, context, event):
        return _invoke_manager_dialog(self, context, width=620)

    def draw(self, context):
        lines = (
            ("Choose a workspace and an editor, then switch each Smart Tool on or off.",
             "ワークスペースとエディターを選び、各ツールの有効・無効を切り替えます。"),
            ("Rules take effect when the selected workspace and editor are active.",
             "設定は、選んだワークスペースとエディターで適用されます。"),
            ("Every tool starts Enabled. All Enabled and All Disabled switch the whole list at once.",
             "最初はどのツールも「有効」です。「全部有効」「全部無効」で一覧をまとめて切り替えられます。"),
            ("Add-ons other than Smart Tools are not hidden by Source panel filters.",
             "「ソースパネルフィルター」でも、スマートツール以外のアドオンは隠れません。"),
            ("Add-ons you removed with Blender's own add-on filter stay removed.",
             "Blender の絞り込みで自分で外したアドオンは、外れたままです。"),
            ("Top Bar button is also in Preferences > Add-ons > Smart Tools Manager.",
             "「トップバーボタン」は、プリファレンスのアドオンの欄にもあります。"),
            ("Enable N-panel State Save under Always-on Toggles to keep changes after restarting Blender.",
             "再起動後も設定を保つには、常時機能切り替えの「Nパネル状態保存」を有効にします。"),
            ("When saving is enabled, tool rules and the selected workspace and editor are saved immediately.",
             "保存が有効な間は、ツールの設定と選択状態が変更のたびに保存されます。"),
            ("The Manager controls panel visibility. It does not enable or disable the add-ons themselves.",
             "マネージャーはパネル表示を制御します。アドオン本体の有効・無効は変更しません。"),
            ("If a problem occurs, Runtime messages appears under the tool list.",
             "問題が起きると、ツールの列の下に「実行メッセージ」が出ます。"),
            ("Press Open and then Copy All to copy the full text for an inquiry.",
             "「開く」→「全文コピー」で、問い合わせ用の全文をコピーできます。"),
        )
        for english, japanese in lines:
            self.layout.label(text=_text(english, japanese, context))

    def execute(self, context):
        if _finish_manager_dialog(self):
            return {'CANCELLED'}
        return {'FINISHED'}

    def cancel(self, context):
        _finish_manager_dialog(self)


class SMARTTOOLS_OT_open_manager(Operator):
    bl_idname = "smart_tools.open_manager"
    bl_label = "Smart Tools Manager"
    bl_description = "Open the Smart Tools Manager dialog. Changes are saved when N-panel State Save is enabled, and OK applies the rules to the workspace add-on filter. No add-on is enabled or disabled."
    bl_options = set()

    def invoke(self, context, event):
        del event
        props = _manager_props(context)
        _install_placement_gates()
        _begin_edit_session(props)
        _update_runtime_status(context)
        _sync_runtime_message_lines(props, context)
        return _invoke_manager_dialog(self, context, width=1040)

    def draw(self, context):
        draw_manager_ui(self.layout, context)

    def execute(self, context):
        if _finish_manager_dialog(self):
            return {'CANCELLED'}
        apply_all_manager_rules(context, force_sidebar=False)
        _set_scene_undo_state(context, reason="open_manager_ok", push=False)
        self.report(
            {"INFO"},
            _text(
                "The rules were applied to the workspace add-on filter. No add-on or N-panel open state was changed.",
                "ルールをワークスペースのアドオンの絞り込みに反映しました。アドオンの有効・無効とNパネルの開閉は変えていません。",
                context,
            ),
        )
        return {"FINISHED"}

    def cancel(self, context):
        _finish_manager_dialog(self)


class SMARTTOOLS_OT_refresh_manager(Operator):
    bl_idname = "smart_tools.refresh_manager"
    bl_label = "Refresh Smart Tools Manager"
    bl_description = "Update the Manager status and the workspace add-on filter from the current settings. No add-on is reloaded, enabled or disabled."
    bl_options = set()

    def execute(self, context):
        _runtime_errors.clear()
        redraw_acknowledged = _reconcile_resident_resources(
            _cached_state_for_ui(),
            context=context,
        )
        _update_runtime_status(context)
        props = _manager_props(context)
        _sync_runtime_message_lines(props, context)
        if not redraw_acknowledged:
            _tag_supported_areas_redraw()
        self.report(
            {"INFO"},
            _text(
                "Smart Tools Manager status was updated.",
                "スマートツールマネージャーの状態を更新しました。",
                context,
            ),
        )
        return {"FINISHED"}


class SMARTTOOLS_OT_reload_manager(Operator):
    bl_idname = "smart_tools.reload_manager"
    bl_label = "Reload Smart Tools"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        del cls, properties
        return _text(
                "Read Smart_Tools_Manager.json again, restore it from its backup if needed, and apply the rules. No add-on is reloaded.",
            "Smart_Tools_Manager.jsonを読み直し、必要ならバックアップから戻して、ルールを反映します。アドオンの再読み込みは行いません。",
            context,
        )

    def execute(self, context):
        before = _state_semantic_text(_cached_state_for_ui())
        previous_generation = int(_cached_state_for_ui().get("generation", 0) or 0)
        _runtime_errors.clear()
        state = _reload_settings_from_file(sync_props=True, reset_draft=True)
        redraw_acknowledged = _reconcile_resident_resources(state, context=context)
        _update_runtime_status(context)
        props = _manager_props(context)
        _sync_runtime_message_lines(props, context)
        after = _state_semantic_text(_cached_state_for_ui())
        if after != before:
            _set_scene_undo_state(context, reason="reload_manager", push=True)
        if not redraw_acknowledged:
            _tag_supported_areas_redraw()
        current_generation = int(_cached_state_for_ui().get("generation", 0) or 0)
        self.report(
            {"INFO"},
            _format_text(
                "Smart Tools Manager settings validated. Generation {previous_generation} -> {current_generation}.",
                "スマートツールマネージャー設定を検証しました。世代 {previous_generation} -> {current_generation}。",
                context,
                previous_generation=previous_generation,
                current_generation=current_generation,
            ),
        )
        return {"FINISHED"}


class SMARTTOOLS_OT_copy_runtime_messages(Operator):
    bl_idname = "smart_tools.copy_runtime_messages"
    bl_label = "Copy Runtime Messages"
    bl_description = "Copy Smart Tools Manager runtime messages to the clipboard."

    def execute(self, context):
        try:
            context.window_manager.clipboard = _runtime_message_text(context)
            self.report(
                {"INFO"},
                _text(
                    "Runtime messages copied to the clipboard.",
                    "実行メッセージをクリップボードへコピーしました。",
                    context,
                ),
            )
            return {"FINISHED"}
        except Exception:
            self.report(
                {"ERROR"},
                _text(
                    "Failed to copy runtime messages.",
                    "実行メッセージのコピーに失敗しました。",
                    context,
                ),
            )
            return {"CANCELLED"}


class SMARTTOOLS_OT_open_runtime_messages(Operator):
    bl_idname = "smart_tools.open_runtime_messages"
    bl_label = "Runtime Messages"
    bl_description = "Open Smart Tools Manager runtime messages in a copyable popup."
    bl_options = {"INTERNAL"}

    message_text: StringProperty(
        name="Runtime Message Text",
        description="Stores the current Smart Tools Manager status message displayed in its dialog.",
        default="",
        options={"SKIP_SAVE"},
    )

    def invoke(self, context, event):
        del event
        props = _manager_props(context)
        if props is not None:
            _sync_runtime_message_lines(props, context, popup_width=True)
        self.message_text = _runtime_message_summary(context)
        return _invoke_manager_dialog(self, context, width=920)

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator(
            "smart_tools.copy_runtime_messages",
            text=_text("Copy All", "全文コピー", context),
            icon="COPYDOWN",
        )
        box = layout.box()
        for line in _wrap_text_for_ui(
            self.message_text or _runtime_message_summary(context),
            width=RUNTIME_MESSAGE_POPUP_WRAP_WIDTH,
        )[:RUNTIME_MESSAGE_POPUP_ROWS]:
            box.label(text=line or " ", translate=False)

    def execute(self, context):
        if _finish_manager_dialog(self):
            return {'CANCELLED'}
        del context
        return {"FINISHED"}

    def cancel(self, context):
        _finish_manager_dialog(self)


def _is_workspace_tab_topbar_region(context) -> bool:
    try:
        return str(getattr(getattr(context, "region", None), "alignment", "") or "").upper() != "RIGHT"
    except Exception:
        return True


def _draw_topbar_button(self, context) -> None:
    if (
        not _manager_registered
        or not bool(getattr(SMARTTOOLS_OT_open_manager, "is_registered", False))
        or not bool(getattr(SMARTTOOLS_OT_reload_manager, "is_registered", False))
    ):
        return
    if not _is_workspace_tab_topbar_region(context):
        return
    row = self.layout.row(align=True)
    icon_value = _manager_icon_value()
    if icon_value:
        row.operator("smart_tools.open_manager", text=_text("Smart Tools", "スマートツール", context), icon_value=icon_value)
    else:
        row.operator("smart_tools.open_manager", text=_text("Smart Tools", "スマートツール", context), icon="PREFERENCES")
    row.operator("smart_tools.reload_manager", text="", icon="FILE_REFRESH")


@persistent
def _save_pre_handler(_dummy=None) -> None:
    if _settings_dirty:
        _save_settings(force=True)


@persistent
def _load_post_handler(_dummy=None) -> None:
    # One finite restore attempt. _load_settings_from_disk preserves the exact prior
    # authority flag; the mere existence of a previous Python dict never
    # promotes unverified defaults or cache data to authoritative state.
    _workspace_filter_deltas.clear()
    _retire_legacy_panel_router_namespace()
    state = _load_settings_from_disk(force=True)
    _sync_properties_from_settings(_manager_props(bpy.context))
    redraw_acknowledged = _reconcile_resident_resources(state, context=bpy.context)
    _initialize_undo_state(bpy.context)
    _update_runtime_status(bpy.context)
    _publish_lifecycle_state()
    if not redraw_acknowledged:
        _tag_supported_areas_redraw()


@persistent
def _runtime_record_load_post_handler(_dummy=None) -> None:
    # Blender empties driver_namespace when a file is opened. Put back only the
    # exact current-generation data records (lifecycle ledger and rule-matrix
    # API record). No settings reload, no Panel or callback changes.
    try:
        _publish_lifecycle_state()
        if (
            _active_runtime_api_record is not None
            and _current_runtime_api_record() is None
        ):
            _republish_active_runtime_api_record_exact()
        _runtime_errors.pop("RUNTIME_RECORD_LOAD_POST", None)
    except Exception:
        _runtime_errors["RUNTIME_RECORD_LOAD_POST"] = traceback.format_exc(limit=4)


def _append_handler_once(handler_list: list, callback) -> bool:
    if callback in handler_list:
        return False
    handler_list.append(callback)
    _registered_handlers.append((handler_list, callback))
    return True


def _set_handler_enabled(handler_list: list, callback, enabled: bool) -> None:
    global _registered_handlers
    pair = (handler_list, callback)
    if enabled:
        _mark_owned_callable(callback, _registration_token, "handler")
        _append_handler_once(handler_list, callback)
        return
    while callback in handler_list:
        handler_list.remove(callback)
    _registered_handlers = [item for item in _registered_handlers if item != pair]


def _reconcile_resident_resources(
    state: dict[str, Any],
    *,
    context=None,
    transfer_runtime_api_from: dict[str, Any] | None = None,
    publish_ledger: bool = True,
) -> bool:
    global _topbar_draw_registered
    if not _manager_registered or not _registration_token:
        return False
    runtime = state.get("runtime", {})
    ui = state.get("ui", {})
    topbar_enabled = bool(runtime.get("topbar_button", False))
    if topbar_enabled and not _topbar_draw_registered:
        _mark_owned_callable(_draw_topbar_button, _registration_token, "topbar")
        _topbar_remove_exact(_draw_topbar_button)
        bpy.types.TOPBAR_HT_upper_bar.append(_draw_topbar_button)
        _topbar_draw_registered = True
    elif not topbar_enabled:
        _topbar_remove_exact(_draw_topbar_button)
        draw_funcs = _topbar_draw_funcs()
        if isinstance(draw_funcs, (list, tuple)) and _draw_topbar_button in draw_funcs:
            raise RuntimeError("Manager Top Bar callback remained after disable")
        _topbar_draw_registered = False
    _set_handler_enabled(bpy.app.handlers.save_pre, _save_pre_handler, bool(ui.get("n_panel_state_save", True)))
    _set_handler_enabled(bpy.app.handlers.load_post, _load_post_handler, bool(runtime.get("load_restore_handler", False)))
    for collection, callback in ((bpy.app.handlers.undo_post, _undo_post_handler), (bpy.app.handlers.redo_post, _redo_post_handler)):
        _set_handler_enabled(collection, callback, bool(runtime.get("undo_redo_handlers", False)))
    redraw_acknowledgement: list[bool] = []
    owner_filters_changed = False
    if bool(runtime.get("source_panel_filters", False)):
        owner_filters_changed = _sync_workspace_owner_filters(
            context=context,
            redraw_acknowledgement=redraw_acknowledgement,
        )
    else:
        _restore_workspace_filter_state()
    bridge_enabled = bool(runtime.get("runtime_api_bridge", False))
    if bridge_enabled and _current_runtime_api_record() is None:
        _publish_runtime_api_record(transfer_from=transfer_runtime_api_from)
        _notify_workspace_bridge_runtime_available()
    elif not bridge_enabled and _current_runtime_api_record() is not None:
        if not _clear_runtime_api_record_exact(expected_generation=_registration_token):
            raise RuntimeError("Manager runtime API bridge remained after disable")
    _set_handler_enabled(bpy.app.handlers.load_post, _runtime_record_load_post_handler, bridge_enabled)
    if publish_ledger:
        _set_lifecycle_ledger(_current_generation_ledger(_registration_token))
    return bool(owner_filters_changed and redraw_acknowledgement == [True])


def _remove_registered_handlers() -> list[str]:
    errors: list[str] = []
    for handler_list, callback in reversed(tuple(_registered_handlers)):
        try:
            while callback in handler_list:
                handler_list.remove(callback)
        except Exception:
            errors.append(traceback.format_exc(limit=3))
    if not errors:
        _registered_handlers.clear()
    return errors


_MANAGER_HANDLER_NAMES = {
    "_save_pre_handler",
    "_load_post_handler",
    "_runtime_record_load_post_handler",
    "_undo_post_handler",
    "_redo_post_handler",
}


def _module_name_is_manager_owned(module_name: Any) -> bool:
    text = str(module_name or "").strip().lower()
    return bool(
        text == "smart_tools_manager.manager"
        or text.endswith(".smart_tools_manager.manager")
        or text == str(__name__).lower()
    )


def _retire_stale_manager_handlers() -> list[tuple[list, Any]]:
    """Remove only verified old Manager handlers from finite known lists."""
    current_callbacks = {
        _save_pre_handler,
        _load_post_handler,
        _runtime_record_load_post_handler,
        _undo_post_handler,
        _redo_post_handler,
    }
    collections = [
        getattr(bpy.app.handlers, "save_pre", None),
        getattr(bpy.app.handlers, "load_post", None),
        getattr(bpy.app.handlers, "undo_post", None),
        getattr(bpy.app.handlers, "redo_post", None),
        getattr(bpy.app.handlers, "load_factory_startup_post", None),
    ]
    retired: list[tuple[list, Any]] = []
    for collection in collections:
        if not isinstance(collection, list):
            continue
        for callback in tuple(collection):
            if callback in current_callbacks:
                continue
            target = getattr(callback, "__func__", callback)
            if (
                getattr(target, "__name__", "") in _MANAGER_HANDLER_NAMES
                and _module_name_is_manager_owned(getattr(target, "__module__", ""))
            ):
                try:
                    collection.remove(callback)
                    retired.append((collection, callback))
                except Exception:
                    raise RuntimeError("failed to retire a verified stale Manager handler")
    return retired


def _restore_retired_manager_handlers(retired: Iterable[tuple[list, Any]]) -> None:
    for collection, callback in retired:
        if callback not in collection:
            collection.append(callback)


def _topbar_draw_funcs() -> list[Any] | tuple[Any, ...] | None:
    """Return Blender's live dynamic draw list across supported layouts."""
    header = bpy.types.TOPBAR_HT_upper_bar
    for owner in (getattr(header, "draw", None), header):
        callbacks = getattr(owner, "_draw_funcs", None)
        if isinstance(callbacks, (list, tuple)):
            return callbacks
    return None


def _retire_stale_manager_topbar_callbacks() -> list[Any]:
    """Remove only verified old Manager callbacks from the Top Bar draw list."""
    header = bpy.types.TOPBAR_HT_upper_bar
    callbacks = _topbar_draw_funcs()
    if not isinstance(callbacks, (list, tuple)):
        return []
    retired: list[Any] = []
    for callback in tuple(callbacks):
        if callback is _draw_topbar_button:
            continue
        target = getattr(callback, "__func__", callback)
        if (
            getattr(target, "__name__", "") == "_draw_topbar_button"
            and _module_name_is_manager_owned(getattr(target, "__module__", ""))
        ):
            header.remove(callback)
            retired.append(callback)
    return retired


def _restore_retired_manager_topbar_callbacks(retired: Iterable[Any]) -> None:
    header = bpy.types.TOPBAR_HT_upper_bar
    callbacks = _topbar_draw_funcs()
    for callback in retired:
        if isinstance(callbacks, (list, tuple)) and callback in callbacks:
            continue
        header.append(callback)


def _class_owned_by_manager(cls: Any) -> bool:
    try:
        token = getattr(cls, "_stm_owner_token", "")
        return bool(
            isinstance(cls, type)
            and getattr(cls, "_stm_owner_id", "") == ADDON_ID
            and getattr(cls, "_stm_owner_class_name", "") == getattr(cls, "__name__", "")
            and isinstance(token, str)
            and bool(token.strip())
            and _module_name_is_manager_owned(getattr(cls, "__module__", ""))
            and _module_name_is_manager_owned(getattr(cls, "_stm_owner_module", ""))
        )
    except Exception:
        return False


def _manager_class_surface_matches(existing: Any, expected: type) -> bool:
    """Match a Manager RNA class across Python module generations."""
    try:
        if not isinstance(existing, type) or existing.__name__ != expected.__name__:
            return False
        expected_idname = getattr(expected, "bl_idname", None)
        if expected_idname is not None and getattr(existing, "bl_idname", None) != expected_idname:
            return False
        for rna_base in (AddonPreferences, Operator, Panel, PropertyGroup, UIList):
            if issubclass(expected, rna_base):
                return issubclass(existing, rna_base)
        return False
    except Exception:
        return False


def _verified_tokenized_manager_class(existing: Any, expected: type) -> bool:
    """Verify a stale class from a tokenized Manager generation."""
    return bool(
        _class_owned_by_manager(existing)
        and _manager_class_surface_matches(existing, expected)
    )


def _legacy_anchor_class_name(tool_key: str, space_type: str) -> str:
    prefix = _LEGACY_ANCHOR_PREFIX_BY_SPACE[space_type]
    raw = f"{tool_key}:{space_type}"
    digest = hashlib.md5(raw.encode("utf-8", errors="ignore")).hexdigest()[:12]
    return f"{prefix}_stm_anchor_{digest}"


def _verified_legacy_anchor_class(
    cls: Any,
    *,
    tool_key: str,
    space_type: str,
) -> bool:
    """Verify the exact v1 category-anchor generation signature."""
    expected_name = _legacy_anchor_class_name(tool_key, space_type)
    try:
        poll = getattr(cls, "poll", None)
        poll_target = getattr(poll, "__func__", poll)
        draw = getattr(cls, "draw", None)
        draw_target = getattr(draw, "__func__", draw)
        return bool(
            isinstance(cls, type)
            and getattr(cls, "__name__", "") == expected_name
            and getattr(cls, "bl_idname", "") == expected_name
            and getattr(cls, "_smart_tools_manager_anchor", False) is True
            and getattr(cls, "_smart_tools_manager_tool_key", "") == tool_key
            and getattr(cls, "_smart_tools_manager_space_type", "") == space_type
            and getattr(cls, "bl_space_type", "") == space_type
            and getattr(cls, "bl_region_type", "") == "UI"
            and _module_name_is_manager_owned(getattr(cls, "__module__", ""))
            and getattr(poll_target, "__name__", "") == "_smart_tools_manager_anchor_poll"
            and _module_name_is_manager_owned(getattr(poll_target, "__module__", ""))
            and getattr(draw_target, "__name__", "") == "_smart_tools_manager_anchor_draw"
            and _module_name_is_manager_owned(getattr(draw_target, "__module__", ""))
        )
    except Exception:
        return False


def _discover_verified_legacy_anchor_classes(types_namespace=None) -> tuple[type, ...]:
    """Resolve 231 deterministic old IDs without recursively scanning Panels."""
    namespace = types_namespace or bpy.types
    result: list[type] = []
    for tool_key in _TOOL_ORDER:
        for space_type in PHYSICAL_SPACE_TYPES:
            class_name = _legacy_anchor_class_name(tool_key, space_type)
            try:
                candidate = getattr(namespace, class_name)
            except Exception:
                candidate = None
            if _verified_legacy_anchor_class(
                candidate,
                tool_key=tool_key,
                space_type=space_type,
            ):
                result.append(candidate)
    return tuple(result)


def _verified_legacy_manager_class(existing: Any, expected: type) -> bool:
    """Recognize only an exact pre-token Manager class generation."""
    try:
        if not _manager_class_surface_matches(existing, expected):
            return False
        if not _module_name_is_manager_owned(getattr(existing, "__module__", "")):
            return False
        # Tokenized classes use the current ownership path instead.  This path
        # is reserved for exact v1.5.54-and-earlier registration leftovers.
        return not bool(getattr(existing, "_stm_owner_id", ""))
    except Exception:
        return False


def _mark_owned_class(cls: type, token: str) -> None:
    cls._stm_owner_id = ADDON_ID
    cls._stm_owner_token = token
    cls._stm_owner_class_name = cls.__name__
    cls._stm_owner_module = __name__


def _lookup_registered_type(cls: type, types_namespace=None):
    namespace = types_namespace or bpy.types
    try:
        return getattr(namespace, cls.__name__)
    except Exception:
        return None


def _discover_registered_retired_manager_panels(types_namespace=None) -> tuple[type, ...]:
    """Find only the finite set of verified retired Manager Panel RNA types."""
    namespace = types_namespace or bpy.types
    result: list[type] = []
    for expected in _RETIRED_MANAGER_PANEL_CLASSES:
        existing = _lookup_registered_type(expected, namespace)
        if existing is None:
            continue
        if not (
            _verified_tokenized_manager_class(existing, expected)
            or _verified_legacy_manager_class(existing, expected)
        ):
            raise RuntimeError(
                f"retired Manager Panel name is occupied by a foreign class: {expected.__name__}"
            )
        result.append(existing)
    return tuple(result)


def _register_owned_classes_transaction(
    classes: Iterable[type],
    *,
    token: str,
    retire_owned_classes: Iterable[type] = (),
    register_class=None,
    unregister_class=None,
    types_namespace=None,
) -> tuple[list[type], list[type]]:
    """Register Manager-owned classes transactionally.

    A foreign collision aborts before touching the foreign class. Verified stale
    Manager-owned classes may be replaced; if any later step fails, every newly
    registered Manager class is removed in reverse order and every removed stale
    Manager class is restored. Incomplete rollback state is carried by the raised
    RegistrationTransactionError instead of being silently discarded.
    """
    register_fn = register_class or bpy.utils.register_class
    unregister_fn = unregister_class or bpy.utils.unregister_class
    namespace = types_namespace or bpy.types
    class_tuple = tuple(classes)
    stale: list[type] = []
    seen_stale: set[int] = set()

    for existing in tuple(retire_owned_classes):
        verified_anchor = any(
            _verified_legacy_anchor_class(
                existing,
                tool_key=tool_key,
                space_type=space_type,
            )
            for tool_key in _TOOL_ORDER
            for space_type in PHYSICAL_SPACE_TYPES
            if getattr(existing, "__name__", "")
            == _legacy_anchor_class_name(tool_key, space_type)
        )
        verified_retired_panel = any(
            getattr(existing, "__name__", "") == expected.__name__
            and (
                _verified_tokenized_manager_class(existing, expected)
                or _verified_legacy_manager_class(existing, expected)
            )
            for expected in _RETIRED_MANAGER_PANEL_CLASSES
        )
        if not (verified_anchor or verified_retired_panel):
            raise RuntimeError(
                f"refusing to unregister unverified retired class: {getattr(existing, '__name__', repr(existing))}"
            )
        if id(existing) not in seen_stale:
            stale.append(existing)
            seen_stale.add(id(existing))

    for cls in class_tuple:
        existing = _lookup_registered_type(cls, namespace)
        if existing is None:
            continue
        if existing is cls and not bool(getattr(existing, "is_registered", False)):
            continue
        if not (
            _verified_tokenized_manager_class(existing, cls)
            or _verified_legacy_manager_class(existing, cls)
        ):
            raise RuntimeError(
                f"class collision with non-Manager class: {cls.__name__}"
            )
        if id(existing) not in seen_stale:
            stale.append(existing)
            seen_stale.add(id(existing))

    removed_stale: list[type] = []
    registered_new: list[type] = []
    try:
        for existing in reversed(stale):
            try:
                unregister_fn(existing)
            except Exception:
                # Blender or a test double may remove the RNA class and then
                # raise. Record that state before propagating so rollback can
                # restore the verified Manager-owned class instead of leaving
                # a partially retired generation behind.
                if (
                    not bool(getattr(existing, "is_registered", False))
                    and _lookup_registered_type(existing, namespace) is not existing
                ):
                    removed_stale.append(existing)
                raise
            if bool(getattr(existing, "is_registered", False)):
                raise RuntimeError(
                    f"verified stale Manager class remained registered: {existing.__name__}"
                )
            if _lookup_registered_type(existing, namespace) is existing:
                raise RuntimeError(
                    f"verified stale Manager class remained in RNA namespace: {existing.__name__}"
                )
            removed_stale.append(existing)

        for cls in class_tuple:
            existing = _lookup_registered_type(cls, namespace)
            if existing is not None and existing is not cls:
                raise RuntimeError(
                    f"Manager class namespace remained occupied after stale retirement: {cls.__name__}"
                )
            if existing is cls and bool(getattr(cls, "is_registered", False)):
                raise RuntimeError(
                    f"Manager class remained registered before transaction register: {cls.__name__}"
                )
            _mark_owned_class(cls, token)
            register_fn(cls)
            if not (
                bool(getattr(cls, "is_registered", False))
                or _lookup_registered_type(cls, namespace) is cls
            ):
                raise RuntimeError(f"Manager class did not register: {cls.__name__}")
            registered_new.append(cls)
        return registered_new, removed_stale
    except Exception as original_error:
        rollback_errors: list[str] = []
        remaining_new: list[type] = []
        stale_not_restored: list[type] = []

        # Include a class whose register function partially succeeded before
        # raising, even if it was not yet appended to registered_new.
        rollback_candidates = list(registered_new)
        for cls in class_tuple:
            if (
                cls not in rollback_candidates
                and _class_owned_by_manager(cls)
                and getattr(cls, "_stm_owner_token", "") == token
                and (
                    bool(getattr(cls, "is_registered", False))
                    or _lookup_registered_type(cls, namespace) is cls
                )
            ):
                rollback_candidates.append(cls)

        for cls in reversed(rollback_candidates):
            try:
                if not (
                    _class_owned_by_manager(cls)
                    and getattr(cls, "_stm_owner_token", "") == token
                ):
                    raise RuntimeError(
                        f"ownership changed before rollback: {getattr(cls, '__name__', repr(cls))}"
                    )
                unregister_fn(cls)
                if (
                    bool(getattr(cls, "is_registered", False))
                    or _lookup_registered_type(cls, namespace) is cls
                ):
                    raise RuntimeError(
                        f"rollback left Manager class registered: {cls.__name__}"
                    )
            except Exception:
                remaining_new.append(cls)
                rollback_errors.append(traceback.format_exc(limit=3))

        for existing in reversed(removed_stale):
            try:
                register_fn(existing)
                if not (
                    bool(getattr(existing, "is_registered", False))
                    or _lookup_registered_type(existing, namespace) is existing
                ):
                    raise RuntimeError(
                        f"rollback did not restore stale Manager class: {existing.__name__}"
                    )
            except Exception:
                stale_not_restored.append(existing)
                rollback_errors.append(traceback.format_exc(limit=3))

        if rollback_errors:
            raise RegistrationTransactionError(
                "Manager class registration failed and rollback was incomplete:\n"
                + "\n".join(rollback_errors),
                remaining_new=remaining_new,
                stale_not_restored=stale_not_restored,
            ) from original_error
        raise


def _unregister_owned_classes(
    classes: Iterable[type],
    *,
    token: str,
    unregister_class=None,
) -> list[type]:
    unregister_fn = unregister_class or bpy.utils.unregister_class
    failed: list[type] = []
    errors: list[str] = []
    for cls in reversed(tuple(classes)):
        if not _class_owned_by_manager(cls) or getattr(cls, "_stm_owner_token", "") != token:
            failed.append(cls)
            errors.append(f"ownership mismatch: {getattr(cls, '__name__', repr(cls))}")
            continue
        try:
            existing = _lookup_registered_type(cls)
            if existing is not None and existing is not cls:
                failed.append(cls)
                errors.append(
                    f"foreign class occupies Manager class name during unregister: {cls.__name__}"
                )
                continue
            if bool(getattr(cls, "is_registered", False)) or existing is cls:
                unregister_fn(cls)
            if bool(getattr(cls, "is_registered", False)) or _lookup_registered_type(cls) is cls:
                raise RuntimeError(f"Manager class remained registered: {cls.__name__}")
        except Exception:
            failed.append(cls)
            errors.append(traceback.format_exc(limit=4))
    if errors:
        _runtime_errors["CLASS_UNREGISTER"] = "\n".join(errors)
    return failed


_RETIRED_MANAGER_PANEL_CLASSES = (
    SMARTTOOLS_PT_manager,
    SMARTTOOLS_PT_manager_image,
    SMARTTOOLS_PT_manager_node,
    SMARTTOOLS_PT_manager_sequence,
    SMARTTOOLS_PT_manager_clip,
    SMARTTOOLS_PT_manager_dopesheet,
    SMARTTOOLS_PT_manager_graph,
    SMARTTOOLS_PT_manager_nla,
    SMARTTOOLS_PT_manager_text,
    SMARTTOOLS_PT_manager_filebrowser,
    SMARTTOOLS_PT_manager_spreadsheet,
)


_CLASSES = (
    SMARTTOOLS_OT_release_cleanup_select,
    SMARTTOOLS_OT_release_cleanup,
    SMARTTOOLS_OT_release_cleanup_inspect,
    SMARTTOOLS_OT_release_cleanup_apply,
    SMARTTOOLS_OT_release_cleanup_export,
    SMARTTOOLS_OT_release_cleanup_help,
    SmartToolsRuntimeMessageLine,
    SMARTTOOLS_UL_runtime_messages,
    SmartToolsManagerProperties,
    SmartToolsManagerPreferences,
    SMARTTOOLS_OT_select_workspace,
    SMARTTOOLS_OT_set_all_tools,
    SMARTTOOLS_OT_select_editor,
    SMARTTOOLS_OT_open_manager,
    SMARTTOOLS_OT_manager_help,
    SMARTTOOLS_OT_refresh_manager,
    SMARTTOOLS_OT_reload_manager,
    SMARTTOOLS_OT_copy_runtime_messages,
    SMARTTOOLS_OT_open_runtime_messages,
)

if set(_CLASSES).intersection(_RETIRED_MANAGER_PANEL_CLASSES):
    raise RuntimeError("Retired Smart Tools Manager Panels cannot be registered")
if any(issubclass(cls, Panel) for cls in _CLASSES):
    raise RuntimeError("Smart Tools Manager must not register any N-panel class")


def _mark_owned_callable(callback, token: str, kind: str):
    """Attach exact generation ownership to one Manager callback."""
    target = getattr(callback, "__func__", callback)
    target._stm_owner_id = ADDON_ID
    target._stm_owner_token = token
    target._stm_owner_kind = str(kind)
    target._stm_owner_module = __name__
    return callback


def _callable_owned_by_manager(
    callback,
    *,
    token: str | None = None,
    kind: str | None = None,
) -> bool:
    try:
        target = getattr(callback, "__func__", callback)
        if getattr(target, "_stm_owner_id", "") != ADDON_ID:
            return False
        if not _module_name_is_manager_owned(getattr(target, "_stm_owner_module", "")):
            return False
        if token is not None and getattr(target, "_stm_owner_token", "") != token:
            return False
        if kind is not None and getattr(target, "_stm_owner_kind", "") != kind:
            return False
        return True
    except Exception:
        return False


def _known_handler_collections() -> tuple[list, ...]:
    collections: list[list] = []
    for name in (
        "save_pre",
        "load_post",
        "undo_post",
        "redo_post",
        "load_factory_startup_post",
    ):
        value = getattr(bpy.app.handlers, name, None)
        if isinstance(value, list):
            collections.append(value)
    return tuple(collections)


def _callback_globals(callback) -> dict[str, Any] | None:
    target = getattr(callback, "__func__", callback)
    value = getattr(target, "__globals__", None)
    return value if isinstance(value, dict) else None


def _normalize_generation_settings_state(raw_state: Any) -> dict[str, Any] | None:
    """Normalize a verified old-generation cache into the current schema."""
    if not isinstance(raw_state, dict):
        return None
    try:
        if raw_state.get("schema") == SETTINGS_SCHEMA:
            version = raw_state.get("version")
            if version == SETTINGS_SCHEMA_VERSION:
                state, needs_repair = _validate_current_payload(raw_state)
                if needs_repair:
                    payload = _payload_with_checksum(state)
                    state, _unused = _validate_current_payload(payload)
                return state
            if version == 4:
                state, _unused = _validate_schema_v4_payload(raw_state)
                state["version"] = SETTINGS_SCHEMA_VERSION
                state["extension_version"] = VERSION_TEXT
                state["checksum"] = ""
                payload = _payload_with_checksum(state)
                state, _unused = _validate_current_payload(payload)
                return state
            if version == 3:
                state, _unused = _validate_previous_payload(raw_state)
                state["version"] = SETTINGS_SCHEMA_VERSION
                state["extension_version"] = VERSION_TEXT
                state["checksum"] = ""
                payload = _payload_with_checksum(state)
                state, _unused = _validate_current_payload(payload)
                return state
            if version == 2:
                state, _unused = _validate_schema_v2_payload(raw_state)
                state["version"] = SETTINGS_SCHEMA_VERSION
                state["extension_version"] = VERSION_TEXT
                state["checksum"] = ""
                payload = _payload_with_checksum(state)
                state, _unused = _validate_current_payload(payload)
                return state
            return None
        state = _validate_legacy_payload(raw_state)
        state["version"] = SETTINGS_SCHEMA_VERSION
        state["extension_version"] = VERSION_TEXT
        state["checksum"] = ""
        payload = _payload_with_checksum(state)
        state, _unused = _validate_current_payload(payload)
        return state
    except Exception:
        return None


def _verified_manager_class_for_generation(
    cls: Any,
    *,
    token: str | None = None,
) -> bool:
    if not isinstance(cls, type):
        return False
    class_name = str(getattr(cls, "__name__", "") or "")
    expected = next(
        (
            item
            for item in (*_CLASSES, *_RETIRED_MANAGER_PANEL_CLASSES)
            if item.__name__ == class_name
        ),
        None,
    )
    if expected is not None:
        if _verified_tokenized_manager_class(cls, expected):
            return token is None or getattr(cls, "_stm_owner_token", "") == token
        return _verified_legacy_manager_class(cls, expected)
    if getattr(cls, "_smart_tools_manager_anchor", False) is True:
        tool_key = str(getattr(cls, "_smart_tools_manager_tool_key", "") or "")
        space_type = str(getattr(cls, "_smart_tools_manager_space_type", "") or "")
        return bool(
            tool_key in _TOOL_BY_KEY
            and space_type in PHYSICAL_SPACE_TYPES
            and _verified_legacy_anchor_class(
                cls,
                tool_key=tool_key,
                space_type=space_type,
            )
        )
    return False


def _capture_preledger_generation() -> dict[str, Any] | None:
    """Capture only finite, exactly verified pre-ledger Manager resources.

    This compatibility path exists for 1.5.56 and earlier. It does not recurse
    through Panel subclasses, scan modules, or inspect third-party callbacks.
    """
    classes: list[type] = []
    for expected in (*_CLASSES, *_RETIRED_MANAGER_PANEL_CLASSES):
        existing = _lookup_registered_type(expected)
        if existing is None:
            continue
        if _verified_tokenized_manager_class(existing, expected) or _verified_legacy_manager_class(existing, expected):
            classes.append(existing)
    for legacy in _discover_verified_legacy_anchor_classes():
        if legacy not in classes:
            classes.append(legacy)

    handlers: list[tuple[list, Any]] = []
    for collection in _known_handler_collections():
        for callback in tuple(collection):
            target = getattr(callback, "__func__", callback)
            if (
                getattr(target, "__name__", "") in _MANAGER_HANDLER_NAMES
                and _module_name_is_manager_owned(getattr(target, "__module__", ""))
            ):
                pair = (collection, callback)
                if pair not in handlers:
                    handlers.append(pair)

    topbar_callbacks: list[Any] = []
    draw_funcs = _topbar_draw_funcs()
    if isinstance(draw_funcs, (list, tuple)):
        for callback in tuple(draw_funcs):
            target = getattr(callback, "__func__", callback)
            if (
                getattr(target, "__name__", "") == "_draw_topbar_button"
                and _module_name_is_manager_owned(getattr(target, "__module__", ""))
            ):
                topbar_callbacks.append(callback)

    globals_source = None
    for _collection, callback in handlers:
        globals_source = _callback_globals(callback)
        if globals_source is not None:
            break
    if globals_source is None:
        for callback in topbar_callbacks:
            globals_source = _callback_globals(callback)
            if globals_source is not None:
                break

    property_group_class = next(
        (
            cls
            for cls in classes
            if getattr(cls, "__name__", "") == "SmartToolsManagerProperties"
        ),
        None,
    )
    pointer_property_installed = bool(
        property_group_class is not None
        and hasattr(bpy.types.WindowManager, "smart_tools_manager")
    )
    scene_property_installed = bool(
        classes
        and hasattr(bpy.types.Scene, "smart_tools_manager_undo_index")
    )

    if not (
        classes
        or handlers
        or topbar_callbacks
        or pointer_property_installed
        or scene_property_installed
    ):
        return None

    token_candidates = {
        str(getattr(cls, "_stm_owner_token", "") or "")
        for cls in classes
        if str(getattr(cls, "_stm_owner_token", "") or "")
    }
    for _collection, callback in handlers:
        value = str(
            getattr(getattr(callback, "__func__", callback), "_stm_owner_token", "")
            or ""
        )
        if value:
            token_candidates.add(value)
    if len(token_candidates) > 1:
        raise RuntimeError("multiple stale Smart Tools Manager generations were detected")
    token = (
        next(iter(token_candidates))
        if token_candidates
        else f"preledger:{uuid.uuid4().hex}"
    )

    settings_state = None
    settings_authoritative = False
    settings_ready = False
    settings_source = "PRELEDGER_NOT_READY"
    settings_disk_snapshot = None
    workspace_deltas: dict[tuple[int, str], dict[str, Any]] = {}
    translations_registered = False
    translations_data = _TRANSLATIONS
    preview_collection = None
    custom_icons: dict[str, Any] = {}
    if globals_source is not None:
        settings_authoritative = globals_source.get("_settings_authoritative") is True
        if settings_authoritative:
            settings_state = _normalize_generation_settings_state(
                globals_source.get("_settings_cache")
            )
            settings_authoritative = settings_state is not None
        settings_ready = bool(
            settings_authoritative
            and globals_source.get("_settings_ready") is True
        )
        settings_source = str(
            globals_source.get("_settings_authority_source", "PRELEDGER") or "PRELEDGER"
        )
        snapshot = globals_source.get("_settings_disk_snapshot")
        if isinstance(snapshot, tuple) and len(snapshot) == 2:
            settings_disk_snapshot = copy.deepcopy(snapshot)
        old_deltas = globals_source.get("_workspace_filter_deltas")
        if isinstance(old_deltas, dict):
            workspace_deltas = old_deltas
        translations_registered = globals_source.get("_translations_registered") is True
        candidate_translations = globals_source.get("_TRANSLATIONS")
        if isinstance(candidate_translations, dict):
            translations_data = candidate_translations
        preview_collection = globals_source.get("_preview_collection")
        candidate_icons = globals_source.get("_custom_icons")
        if isinstance(candidate_icons, dict):
            custom_icons = candidate_icons

    return {
        "schema": _LIFECYCLE_LEDGER_SCHEMA,
        "owner_id": ADDON_ID,
        "token": token,
        "version": str(
            globals_source.get("VERSION_TEXT", "preledger")
            if globals_source is not None
            else "preledger"
        ),
        "complete": True,
        "classes": tuple(classes),
        "handlers": tuple(handlers),
        "topbar_callbacks": tuple(topbar_callbacks),
        "pointer_property_installed": pointer_property_installed,
        "scene_property_installed": scene_property_installed,
        "property_group_class": property_group_class,
        "translations_registered": translations_registered,
        "translations_data": translations_data,
        "preview_collection": preview_collection,
        "custom_icons": custom_icons,
        "workspace_filter_deltas": workspace_deltas,
        "settings_authoritative": settings_authoritative,
        "settings_ready": settings_ready,
        "settings_authority_source": settings_source,
        "settings_state": settings_state,
        "settings_disk_snapshot": settings_disk_snapshot,
        "settings_dirty": False,
    }


def _remove_exact_list_item(collection: list, item: Any) -> int:
    count = 0
    while item in collection:
        collection.remove(item)
        count += 1
    return count


def _topbar_remove_exact(callback: Any) -> int:
    header = bpy.types.TOPBAR_HT_upper_bar
    draw_funcs = _topbar_draw_funcs()
    if not isinstance(draw_funcs, (list, tuple)):
        return 0
    count = 0
    while callback in draw_funcs:
        header.remove(callback)
        count += 1
        draw_funcs = _topbar_draw_funcs()
        if not isinstance(draw_funcs, (list, tuple)):
            break
    return count


def _topbar_append_exact(callback: Any, count: int = 1) -> None:
    header = bpy.types.TOPBAR_HT_upper_bar
    for _index in range(max(0, int(count))):
        header.append(callback)


def _retire_generation_resources(ledger: dict[str, Any]) -> dict[str, Any]:
    """Retire one verified Manager generation, leaving its preview alive.

    The returned record is sufficient to restore every completed operation in
    reverse if a later registration step fails. No third-party resource is
    touched: each class and callback is verified against Manager ownership.
    """
    if not _lifecycle_ledger_is_valid(ledger):
        raise RuntimeError("cannot retire an invalid Manager lifecycle ledger")
    token = str(ledger["token"])
    record = {
        "ledger": ledger,
        "handler_counts": [],
        "topbar_counts": [],
        "pointer_removed": False,
        "scene_removed": False,
        "classes_removed": [],
        "translations_removed": False,
    }
    try:
        for collection, callback in tuple(ledger.get("handlers", ())):
            target = getattr(callback, "__func__", callback)
            verified = _callable_owned_by_manager(callback, token=token, kind="handler") or (
                getattr(target, "__name__", "") in _MANAGER_HANDLER_NAMES
                and _module_name_is_manager_owned(getattr(target, "__module__", ""))
            )
            if not verified:
                raise RuntimeError("refusing to remove an unverified Manager handler")
            count = _remove_exact_list_item(collection, callback)
            if count:
                record["handler_counts"].append((collection, callback, count))

        for callback in tuple(ledger.get("topbar_callbacks", ())):
            target = getattr(callback, "__func__", callback)
            verified = _callable_owned_by_manager(callback, token=token, kind="topbar") or (
                getattr(target, "__name__", "") == "_draw_topbar_button"
                and _module_name_is_manager_owned(getattr(target, "__module__", ""))
            )
            if not verified:
                raise RuntimeError("refusing to remove an unverified Manager Top Bar callback")
            count = _topbar_remove_exact(callback)
            if count:
                record["topbar_counts"].append((callback, count))

        # A Blender module reload can leave an older Manager draw callback that
        # predates the current lifecycle ledger. Retire only the exact Manager
        # callback signature and keep it in the rollback record.
        draw_funcs = _topbar_draw_funcs()
        if isinstance(draw_funcs, (list, tuple)):
            for callback in tuple(draw_funcs):
                target = getattr(callback, "__func__", callback)
                if not (
                    getattr(target, "__name__", "") == "_draw_topbar_button"
                    and _module_name_is_manager_owned(getattr(target, "__module__", ""))
                ):
                    continue
                count = _topbar_remove_exact(callback)
                if count:
                    record["topbar_counts"].append((callback, count))

        remaining_draw_funcs = _topbar_draw_funcs()
        if isinstance(remaining_draw_funcs, (list, tuple)):
            remaining_owned = []
            for callback in tuple(remaining_draw_funcs):
                target = getattr(callback, "__func__", callback)
                if (
                    getattr(target, "__name__", "") == "_draw_topbar_button"
                    and _module_name_is_manager_owned(getattr(target, "__module__", ""))
                ):
                    remaining_owned.append(callback)
            if remaining_owned:
                raise RuntimeError("Manager Top Bar callbacks remain after generation retirement")

        property_group_class = ledger.get("property_group_class")
        property_class_verified = bool(
            property_group_class is None
            or _verified_manager_class_for_generation(property_group_class)
        )
        if ledger.get("pointer_property_installed") is True:
            if not property_class_verified:
                raise RuntimeError("Manager PointerProperty owner class is unverified")
            if hasattr(bpy.types.WindowManager, "smart_tools_manager"):
                del bpy.types.WindowManager.smart_tools_manager
                record["pointer_removed"] = True
        if ledger.get("scene_property_installed") is True:
            if not property_class_verified:
                raise RuntimeError("Manager Scene property owner class is unverified")
            if hasattr(bpy.types.Scene, "smart_tools_manager_undo_index"):
                del bpy.types.Scene.smart_tools_manager_undo_index
                record["scene_removed"] = True

        classes = tuple(ledger.get("classes", ()))
        for cls in reversed(classes):
            if not _verified_manager_class_for_generation(cls, token=token):
                raise RuntimeError(
                    "refusing to unregister an unverified Manager class: "
                    + str(getattr(cls, "__name__", repr(cls)))
                )
            existing = _lookup_registered_type(cls)
            if existing is not None and existing is not cls:
                raise RuntimeError(
                    f"foreign class occupies Manager class name: {cls.__name__}"
                )
            if bool(getattr(cls, "is_registered", False)) or existing is cls:
                try:
                    bpy.utils.unregister_class(cls)
                except Exception:
                    if (
                        not bool(getattr(cls, "is_registered", False))
                        and _lookup_registered_type(cls) is not cls
                    ):
                        record["classes_removed"].append(cls)
                    raise
                if (
                    bool(getattr(cls, "is_registered", False))
                    or _lookup_registered_type(cls) is cls
                ):
                    raise RuntimeError(
                        f"Manager class remained registered: {cls.__name__}"
                    )
                record["classes_removed"].append(cls)

        if ledger.get("translations_registered") is True:
            bpy.app.translations.unregister(ADDON_ID)
            record["translations_removed"] = True
        return record
    except Exception:
        try:
            _restore_retired_generation(record, publish_ledger=False)
        except Exception as rollback_error:
            raise RegistrationTransactionError(
                "Manager generation retirement failed and rollback was incomplete: "
                + str(rollback_error)
            )
        raise


def _restore_retired_generation(
    record: dict[str, Any],
    *,
    publish_ledger: bool = True,
) -> None:
    ledger = record["ledger"]
    errors: list[str] = []
    if record.get("translations_removed"):
        try:
            bpy.app.translations.register(
                ADDON_ID,
                ledger.get("translations_data") or _TRANSLATIONS,
            )
        except Exception:
            errors.append(traceback.format_exc(limit=4))

    removed_ids = {id(cls) for cls in record.get("classes_removed", ())}
    for cls in tuple(ledger.get("classes", ())):
        if id(cls) not in removed_ids:
            continue
        try:
            existing = _lookup_registered_type(cls)
            if existing is not None and existing is not cls:
                raise RuntimeError(
                    f"cannot restore Manager class over foreign class: {cls.__name__}"
                )
            bpy.utils.register_class(cls)
            if not (
                bool(getattr(cls, "is_registered", False))
                or _lookup_registered_type(cls) is cls
            ):
                raise RuntimeError(f"Manager class restore failed: {cls.__name__}")
        except Exception:
            errors.append(traceback.format_exc(limit=4))

    property_group_class = ledger.get("property_group_class")
    if record.get("pointer_removed"):
        try:
            if property_group_class is None:
                raise RuntimeError("missing Manager PropertyGroup for PointerProperty restore")
            if hasattr(bpy.types.WindowManager, "smart_tools_manager"):
                raise RuntimeError("WindowManager.smart_tools_manager collision during restore")
            bpy.types.WindowManager.smart_tools_manager = PointerProperty(
                type=property_group_class,
                name="Smart Tools Manager",
                description="Smart Tools Manager settings for this Blender session.",
            )
        except Exception:
            errors.append(traceback.format_exc(limit=4))
    if record.get("scene_removed"):
        try:
            if hasattr(bpy.types.Scene, "smart_tools_manager_undo_index"):
                raise RuntimeError("Scene.smart_tools_manager_undo_index collision during restore")
            bpy.types.Scene.smart_tools_manager_undo_index = IntProperty(
                name="Manager Undo Checkpoint",
                description="Internal counter that lets the Manager match its rules again after undo and redo.",
                default=0,
                options={"SKIP_SAVE"},
            )
        except Exception:
            errors.append(traceback.format_exc(limit=4))

    for callback, count in record.get("topbar_counts", ()):
        try:
            _topbar_append_exact(callback, count)
        except Exception:
            errors.append(traceback.format_exc(limit=4))
    for collection, callback, count in record.get("handler_counts", ()):
        try:
            for _index in range(int(count)):
                collection.append(callback)
        except Exception:
            errors.append(traceback.format_exc(limit=4))

    if publish_ledger:
        try:
            _set_lifecycle_ledger(ledger)
        except Exception:
            errors.append(traceback.format_exc(limit=4))
    if errors:
        raise RuntimeError("Manager generation restore incomplete:\n" + "\n".join(errors))


def _remove_preview_collection_exact(collection: Any) -> None:
    if collection is None:
        return
    import bpy.utils.previews

    bpy.utils.previews.remove(collection)


def _current_generation_ledger(token: str) -> dict[str, Any]:
    return {
        "schema": _LIFECYCLE_LEDGER_SCHEMA,
        "owner_id": ADDON_ID,
        "token": token,
        "version": VERSION_TEXT,
        "complete": True,
        "classes": tuple(_registered_classes),
        "handlers": tuple(_registered_handlers),
        "topbar_callbacks": (_draw_topbar_button,) if _topbar_draw_registered else (),
        "pointer_property_installed": bool(_pointer_property_registered),
        "scene_property_installed": bool(_scene_undo_property_registered),
        "property_group_class": SmartToolsManagerProperties,
        "translations_registered": bool(_translations_registered),
        "translations_data": _TRANSLATIONS,
        "preview_collection": _preview_collection,
        "custom_icons": _custom_icons,
        "workspace_filter_deltas": _workspace_filter_deltas,
        "settings_authoritative": bool(_settings_authoritative),
        "settings_ready": bool(_settings_ready),
        "settings_authority_source": str(_settings_authority_source),
        "settings_state": _normalized_authoritative_state_for_ledger(),
        "settings_disk_snapshot": copy.deepcopy(_settings_disk_snapshot),
        "settings_dirty": bool(_settings_dirty),
    }


def _reset_registration_globals() -> None:
    global _manager_registered, _registration_token, _registered_classes
    global _registered_handlers, _topbar_draw_registered
    global _pointer_property_registered, _scene_undo_property_registered
    global _translations_registered, _preview_collection, _custom_icons
    global _active_lifecycle_ledger, _active_runtime_api_record
    _manager_registered = False
    _registration_token = ""
    _registered_classes = []
    _registered_handlers = []
    _topbar_draw_registered = False
    _pointer_property_registered = False
    _scene_undo_property_registered = False
    _translations_registered = False
    _preview_collection = None
    _custom_icons = {}
    _active_lifecycle_ledger = None
    _active_runtime_api_record = None


def register() -> None:
    global _dialog_unregister_pending
    _dialog_unregister_pending = False
    if bpy.app.timers.is_registered(_finish_deferred_dialog_unregister):
        bpy.app.timers.unregister(_finish_deferred_dialog_unregister)
    global _manager_registered, _registration_token, _registered_classes
    global _registered_handlers, _topbar_draw_registered
    global _pointer_property_registered, _scene_undo_property_registered
    global _active_lifecycle_ledger

    current_ledger = _get_lifecycle_ledger()
    if (
        _manager_registered
        and _lifecycle_ledger_is_valid(current_ledger)
        and current_ledger.get("token") == _registration_token
        and current_ledger.get("complete") is True
    ):
        bridge_enabled = bool(
            _cached_state_for_ui().get("runtime", {}).get("runtime_api_bridge", False)
        )
        if bridge_enabled and _current_runtime_api_record() is None:
            raise RuntimeError("Manager runtime API bridge is enabled without its exact record")
        if not bridge_enabled and _current_runtime_api_record() is not None:
            raise RuntimeError("Manager runtime API bridge is disabled but a record remains")
        return

    namespace = _driver_namespace_dict()
    old_runtime_api_record = (
        namespace.get(_RUNTIME_API_NAMESPACE_KEY)
        if namespace is not None
        else None
    )
    token = f"{VERSION_TEXT}:{uuid.uuid4().hex}"
    old_ledger = current_ledger or _capture_preledger_generation()
    retirement_record: dict[str, Any] | None = None
    classes_registered: list[type] = []
    retired_stale_classes: list[type] = []
    translations_done = False
    pointer_done = False
    scene_done = False
    icons_done = False
    topbar_done = False
    new_ledger_published = False
    new_runtime_api_published = False

    try:
        _retire_legacy_panel_router_namespace()
        _adopt_lifecycle_state(old_ledger)
        _load_settings_from_disk(force=True)

        if old_ledger is not None:
            retirement_record = _retire_generation_resources(old_ledger)

        _register_translations()
        translations_done = True
        classes_registered, retired_stale_classes = _register_owned_classes_transaction(
            _CLASSES,
            token=token,
            retire_owned_classes=_discover_registered_retired_manager_panels(),
        )
        if _discover_registered_retired_manager_panels():
            raise RuntimeError("retired Smart Tools Manager Panels remain registered")

        if hasattr(bpy.types.WindowManager, "smart_tools_manager"):
            raise RuntimeError("WindowManager.smart_tools_manager already exists")
        bpy.types.WindowManager.smart_tools_manager = PointerProperty(
            type=SmartToolsManagerProperties,
            name="Smart Tools Manager",
            description="Smart Tools Manager settings for this Blender session.",
        )
        pointer_done = True

        if hasattr(bpy.types.Scene, "smart_tools_manager_undo_index"):
            raise RuntimeError("Scene.smart_tools_manager_undo_index already exists")
        bpy.types.Scene.smart_tools_manager_undo_index = IntProperty(
            name="Manager Undo Checkpoint",
            description="Internal counter that lets the Manager match its rules again after undo and redo.",
            default=0,
            options={"SKIP_SAVE"},
        )
        scene_done = True

        _load_custom_icons()
        icons_done = _preview_collection is not None

        _registered_handlers = []
        _registration_token = token
        _registered_classes = list(classes_registered)
        _topbar_draw_registered = topbar_done
        _pointer_property_registered = pointer_done
        _scene_undo_property_registered = scene_done
        _manager_registered = True
        _schedule_placement_gates()

        _sync_properties_from_settings(_manager_props(bpy.context))
        _reconcile_resident_resources(
            _cached_state_for_ui(),
            context=bpy.context,
            transfer_runtime_api_from=old_runtime_api_record,
            publish_ledger=False,
        )
        topbar_done = _topbar_draw_registered
        new_runtime_api_published = _current_runtime_api_record() is not None
        _set_lifecycle_ledger(_current_generation_ledger(token))
        new_ledger_published = True

        _initialize_undo_state(bpy.context)
        _update_runtime_status(bpy.context)
        _publish_lifecycle_state()

        if old_ledger is not None:
            old_preview = old_ledger.get("preview_collection")
            if old_preview is not None and old_preview is not _preview_collection:
                _remove_preview_collection_exact(old_preview)
        _notify_rule_matrix_commit(
            copy.deepcopy(_trusted_state()),
            source_id="smart_tools_manager.runtime_publish",
            source_revision=None,
        )
    except Exception as register_error:
        rollback_errors: list[str] = []
        _manager_registered = False
        current_runtime_api = _current_runtime_api_record()
        if new_runtime_api_published or (
            current_runtime_api is not None
            and current_runtime_api.get("generation") == token
        ):
            try:
                if not _clear_runtime_api_record_exact(expected_generation=token):
                    raise RuntimeError("new Manager runtime API record identity changed")
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if namespace is not None and old_runtime_api_record is not None:
            try:
                namespace[_RUNTIME_API_NAMESPACE_KEY] = old_runtime_api_record
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if new_ledger_published:
            try:
                _clear_lifecycle_ledger(expected_token=token)
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))

        try:
            rollback_errors.extend(_remove_registered_handlers())
        except Exception:
            rollback_errors.append(traceback.format_exc(limit=4))
        if topbar_done or _topbar_draw_registered:
            try:
                _topbar_remove_exact(_draw_topbar_button)
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if scene_done and hasattr(bpy.types.Scene, "smart_tools_manager_undo_index"):
            try:
                del bpy.types.Scene.smart_tools_manager_undo_index
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if pointer_done and hasattr(bpy.types.WindowManager, "smart_tools_manager"):
            try:
                del bpy.types.WindowManager.smart_tools_manager
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if icons_done or _preview_collection is not None:
            try:
                _unload_custom_icons()
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if classes_registered:
            failed = _unregister_owned_classes(classes_registered, token=token)
            if failed:
                rollback_errors.append(
                    "new Manager classes remained registered: "
                    + ", ".join(cls.__name__ for cls in failed)
                )
        if translations_done:
            try:
                _unregister_translations()
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))

        if old_ledger is None:
            try:
                _restore_workspace_filter_state()
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        elif retirement_record is not None:
            try:
                _restore_retired_generation(retirement_record, publish_ledger=True)
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=6))
        for stale_class in reversed(retired_stale_classes):
            try:
                if not _verified_manager_class_for_generation(stale_class):
                    raise RuntimeError(
                        f"refusing to restore unverified retired class: {stale_class.__name__}"
                    )
                existing = _lookup_registered_type(stale_class)
                if existing is not None and existing is not stale_class:
                    raise RuntimeError(
                        f"cannot restore retired Manager Panel over a foreign class: {stale_class.__name__}"
                    )
                if existing is None:
                    bpy.utils.register_class(stale_class)
                if _lookup_registered_type(stale_class) is not stale_class:
                    raise RuntimeError(
                        f"retired Manager Panel restore failed: {stale_class.__name__}"
                    )
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))

        _reset_registration_globals()
        if old_ledger is not None:
            # _reset_registration_globals intentionally clears only this module's
            # globals. Republish the restored old generation's exact ledger.
            try:
                _set_lifecycle_ledger(old_ledger)
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=4))
        if rollback_errors:
            raise RuntimeError(
                "Smart Tools Manager registration failed and rollback was incomplete:\n"
                + "\n".join(rollback_errors)
            ) from register_error
        raise


def unregister() -> None:
    global _dialog_unregister_pending
    if _active_dialogs:
        _dialog_unregister_pending = True
        return
    global _manager_registered, _active_lifecycle_ledger
    global _active_runtime_api_record

    _retire_legacy_panel_router_namespace()
    if _settings_dirty:
        try:
            if not _save_settings(force=True):
                _runtime_errors.setdefault(
                    "SETTINGS_UNREGISTER",
                    "Dirty settings were not written because CAS validation failed.",
                )
        except Exception:
            _runtime_errors["SETTINGS_UNREGISTER"] = traceback.format_exc(limit=4)

    ledger = _get_lifecycle_ledger()
    if ledger is None and (
        _manager_registered
        or _registered_classes
        or _registered_handlers
        or _topbar_draw_registered
    ):
        ledger = _current_generation_ledger(_registration_token or f"recovered:{uuid.uuid4().hex}")
    if ledger is None:
        _reset_registration_globals()
        return
    bridge_enabled = bool(
        _cached_state_for_ui().get("runtime", {}).get("runtime_api_bridge", False)
    )
    runtime_api_record = _current_runtime_api_record()
    if bridge_enabled and runtime_api_record is None:
        runtime_api_record = _republish_active_runtime_api_record_exact()
    if runtime_api_record is None:
        namespace = _driver_namespace_dict()
        if (
            namespace is not None
            and namespace.get(_RUNTIME_API_NAMESPACE_KEY) is not None
        ):
            raise RuntimeError(
                "Manager exact runtime API record is missing during unregister"
            )

    retirement_record: dict[str, Any] | None = None
    old_preview = ledger.get("preview_collection")
    try:
        _manager_registered = False
        _remove_placement_gates()
        retirement_record = _retire_generation_resources(ledger)
        _restore_workspace_filter_state()
        if _workspace_filter_deltas:
            raise RuntimeError("Manager workspace owner-filter deltas did not fully restore")
        if not _clear_lifecycle_ledger(expected_token=str(ledger["token"])):
            raise RuntimeError("Manager lifecycle ledger identity changed during unregister")
        if old_preview is not None:
            _remove_preview_collection_exact(old_preview)
        if runtime_api_record is not None:
            if not _clear_runtime_api_record_exact(
                expected_generation=str(ledger["token"])
            ):
                raise RuntimeError("Manager runtime API identity changed during unregister")
    except Exception as unregister_error:
        rollback_errors: list[str] = []
        if retirement_record is not None:
            try:
                _restore_retired_generation(retirement_record, publish_ledger=True)
            except Exception:
                rollback_errors.append(traceback.format_exc(limit=6))
        try:
            _adopt_lifecycle_state(ledger)
            _manager_registered = True
            namespace = _driver_namespace_dict()
            if namespace is None:
                raise RuntimeError("Blender driver_namespace is unavailable")
            if runtime_api_record is not None:
                namespace[_RUNTIME_API_NAMESPACE_KEY] = runtime_api_record
                _active_runtime_api_record = runtime_api_record
            _sync_workspace_owner_filters(context=bpy.context)
            _publish_lifecycle_state()
        except Exception:
            rollback_errors.append(traceback.format_exc(limit=6))
        if rollback_errors:
            raise RuntimeError(
                "Smart Tools Manager unregister failed and rollback was incomplete:\n"
                + "\n".join(rollback_errors)
            ) from unregister_error
        raise

    _reset_registration_globals()
