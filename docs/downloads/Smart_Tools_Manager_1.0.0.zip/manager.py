# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender-facing placement API; panel polling reads only the current immutable settings."""
from types import MappingProxyType
import bpy
from . import catalog_api as catalog
from .matrix_service import MatrixService

service = MatrixService()
SELF_POLICY = catalog.SELF_POLICY

def get_rule_matrix_snapshot():
    return service.snapshot()

def get_rule_matrix_state():
    return service.matrix_state()

get_catalog_snapshot = catalog.get_catalog_snapshot
editor_key_from_area = catalog.editor_key_from_area

def _key(value):
    return value.strip().upper() if isinstance(value,str) else value

def get_current_cell_rule(workspace_key, editor_key, tool_key):
    return service.cell(_key(workspace_key),_key(editor_key),_key(tool_key))

def apply_rule_matrix(matrix, *, source_revision, runtime_generation, expected_manager_revision, source_id='external'):
    result=service.apply(matrix,source_revision=source_revision,runtime_generation=runtime_generation,
                         expected_manager_revision=expected_manager_revision,source_id=source_id)
    if result.get('ok'):
        from .interface import synchronize
        synchronize(bpy.context)
    return result

def subscribe_rule_matrix_commits(subscriber_id, callback, *, runtime_generation, subscriber_generation=''):
    valid=(service.ready and service.model.document['switches']['notify'] and
           runtime_generation==service.token and bool(subscriber_id) and callable(callback))
    if valid:service.subscribers[subscriber_id]=(callback,subscriber_generation)
    return service.reply(bool(valid),'SUBSCRIBED' if valid else 'NOT_READY_OR_INVALID')

def unsubscribe_rule_matrix_commits(subscriber_id, *, runtime_generation, callback=None):
    if not service.model.document['switches']['notify'] or runtime_generation!=service.token:
        return dict(ok=False,status='RUNTIME_GENERATION_MISMATCH')
    entry=service.subscribers.get(subscriber_id)
    valid=runtime_generation==service.token and entry is not None and (callback is None or entry[0]==callback)
    if valid:del service.subscribers[subscriber_id]
    return dict(ok=valid,status='UNSUBSCRIBED' if valid else 'STALE_SUBSCRIBER')

def logical_editor_key_from_context(context=None):
    context=context or bpy.context
    area=getattr(context,'area',None)
    if area is None:
        screen=getattr(context,'screen',None)
        area=next((entry for entry in getattr(screen,'areas',()) if entry.type=='VIEW_3D'),None)
    return editor_key_from_area(area)

def get_placement_state(tool_key,context=None,*,workspace_key=None,editor_key=None):
    context=context or bpy.context
    tool_key,workspace_key,editor_key=map(_key,(tool_key,workspace_key,editor_key))
    invalid=None
    if tool_key not in catalog.T:
        invalid='invalid_tool_key'
    elif workspace_key is not None and workspace_key not in catalog.W:
        invalid='invalid_workspace_key'
    elif editor_key is not None and editor_key not in catalog.E:
        invalid='invalid_editor_key'
    context_editor=None if invalid else logical_editor_key_from_context(context)
    workspace=workspace_key
    if not invalid and workspace is None:
        workspace=catalog.WORKSPACE_NAMES.get(getattr(getattr(context,'workspace',None),'name',''))
    editor=editor_key if editor_key is not None else context_editor
    matches=not editor_key or not context_editor or editor_key==context_editor
    if invalid:
        allowed,reason,policy=False,invalid,'FAIL_CLOSED'
    elif not matches:
        allowed,reason,policy=False,'logical_editor_mismatch','FAIL_CLOSED'
    elif not service.ready or workspace not in catalog.W or editor not in catalog.E:
        allowed,reason,policy=True,'no_authoritative_cell','FAIL_OPEN'
    else:
        allowed=service.model.allowed(catalog.T[tool_key],catalog.W[workspace],catalog.E[editor])
        reason,policy='explicit_matrix_cell','EXPLICIT_CELL'
    return dict(api_version=3,status='READY' if service.ready else 'NOT_READY',
                manager_active=True,ready=service.ready,authoritative=service.ready,authority_source=service.authority,
                used_last_known_state=False,tool_key=tool_key,workspace_key=workspace,editor_key=editor,
                context_editor_key=context_editor,editor_matches_context=bool(matches),explicit=policy=='EXPLICIT_CELL',
                generation=service.revision,allowed=allowed,reason=reason,policy=policy)

def placement_allowed(tool_key,context=None,*,workspace_key=None,editor_key=None):
    return get_placement_state(tool_key,context,workspace_key=workspace_key,editor_key=editor_key)['allowed']

def panel_rule_allows_context(tool_key,context=None,editor_key=None):
    return placement_allowed(tool_key,context,editor_key=editor_key)

_panel_allowed_for_context=panel_rule_allows_context

def workspace_tool_allowed(tool_key,context=None,workspace_key=None):
    tool_key,workspace_key=_key(tool_key),_key(workspace_key)
    workspace=workspace_key or catalog.WORKSPACE_NAMES.get(getattr(getattr(context or bpy.context,'workspace',None),'name',''))
    if tool_key not in catalog.T or (workspace_key is not None and workspace_key not in catalog.W):return False
    if not service.ready or workspace not in catalog.W:return True
    return service.model.workspace_allowed(catalog.T[tool_key],catalog.W[workspace])

def get_placement_contract():
    from .registry import PHYSICAL_EDITORS
    return MappingProxyType(dict(api_version=3,status_values=('READY','NOT_READY'),workspaces=catalog.WORKSPACES,
            logical_editors=catalog.EDITORS,physical_spaces=PHYSICAL_EDITORS,tools=catalog.TOOLS,
            matrix_cells=len(catalog.W)*len(catalog.E)*len(catalog.T),suite_owns_root_panels=True,
            manager_proxies_panels=False,panel_poll_uses_current_logical_editor_cell=True,
            workspace_owner_filter_any_editor_on_only=True,poll_and_snapshot_are_pure_cached_reads=True,
            policy=dict(known_invalid_key='FAIL_CLOSED',logical_editor_mismatch='FAIL_CLOSED',verified_matrix='EXPLICIT_CELL',
              not_ready_with_last_known_authoritative_state='LAST_KNOWN_CELL',not_ready_without_authoritative_state='FAIL_OPEN',
              custom_or_unresolved_context='FAIL_OPEN',context_resolution_exception='FAIL_OPEN',
              trusted_cache_exception='FAIL_CLOSED',workspace_owner_retention_exception='FAIL_OPEN'),
            pure_decision_snapshot_api=('placement_allowed','_panel_allowed_for_context','panel_rule_allows_context',
              'workspace_tool_allowed','get_placement_state','get_rule_matrix_snapshot','get_rule_matrix_state',
              'get_catalog_snapshot','get_placement_contract','logical_editor_key_from_context'),
            compatibility_action_api=('notify_panel_sources_changed',),
            persistence_boundaries=('register','explicit_property_update_callbacks','unregister_when_dirty')))

def apply_current_context(context=None,*,force=False,force_sidebar=False,selected_workspace=None,selected_editor=None,source='manual'):
    from .interface import refresh_windows
    refresh_windows(context or bpy.context)
    return True

def apply_all_manager_rules(context=None,*,force_sidebar=False):
    return apply_current_context(context,force=True,force_sidebar=force_sidebar)

def notify_panel_sources_changed(*args,**kwargs):
    return apply_current_context()

def draw_manager_ui(layout,context):
    from .interface import draw_matrix
    draw_matrix(layout,context)
