# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent catalog transcribed from the public manual, sections 5-5 to 5-7.

Logical editor keys below are this candidate's declared interface. They are not
asserted to be the unpublished legacy JSON keys. Physical Blender editor names
are kept separate from the seventeen user-facing choices.
"""
from dataclasses import dataclass
import hashlib
import json

@dataclass(frozen=True)
class Entry:
    key: str
    en: str
    ja: str
    physical: str = ''

TOOLS = (
    Entry('smart_file_suite', 'Smart File', 'Smart File'),
    Entry('smart_workspace_suite', 'Smart Workspace', 'スマートワークスペース'),
    Entry('smart_overlay_suite', 'Smart Overlay', 'スマートオーバーレイ'),
    Entry('smart_transform_suite', 'Smart Transform', 'スマートトランスフォーム'),
    Entry('smart_id_suite', 'Smart ID', 'Smart ID'),
    Entry('smart_geometry_suite', 'Smart Geometry', 'Smart Geometry'),
    Entry('smart_camlight_suite', 'Smart CamLight', 'Smart CamLight'),
    Entry('smart_modeling_suite', 'Smart Modeling', 'Smart Modeling'),
    Entry('smart_modifier_suite', 'Smart Modifier', 'スマートモディファイア'),
    Entry('smart_sculpt_suite', 'Smart Sculpt', 'スマートスカルプト'),
    Entry('smart_shapekey_suite', 'Smart Shapekey', 'Smart Shapekey'),
    Entry('smart_uv_suite', 'Smart UV', 'スマートUV'),
    Entry('smart_paint_suite', 'Smart Paint', 'スマートペイント'),
    Entry('smart_shader_suite', 'Smart Shader', 'スマートシェーダー'),
    Entry('smart_rig_suite', 'Smart Rig', 'スマートリグ'),
    Entry('smart_cloth_suite', 'Smart Cloth', 'Smart Cloth'),
    Entry('smart_animation_suite', 'Smart Animation', 'Smart Animation'),
    Entry('smart_selector_suite', 'Smart Selector', 'スマートセレクター'),
    Entry('smart_render_suite', 'Smart Render', 'スマートレンダー'),
    Entry('smart_node_suite', 'Smart Node', 'Smart Node'),
    Entry('smart_composite_suite', 'Smart Composite', 'Smart Composite'),
)
WORKSPACES = (
    Entry('Layout', 'Layout', 'レイアウト'),
    Entry('Modeling', 'Modeling', 'モデリング'),
    Entry('Sculpting', 'Sculpting', 'スカルプト'),
    Entry('UV Editing', 'UV Editing', 'UVエディティング'),
    Entry('Texture Paint', 'Texture Paint', 'テクスチャペイント'),
    Entry('Shading', 'Shading', 'シェーディング'),
    Entry('Animation', 'Animation', 'アニメーション'),
    Entry('Rendering', 'Rendering', 'レンダリング'),
    Entry('Compositing', 'Compositing', 'コンポジティング'),
    Entry('Geometry Nodes', 'Geometry Nodes', 'ジオメトリノード'),
    Entry('Scripting', 'Scripting', 'スクリプティング'),
    Entry('2D Animation', '2D Animation', '2Dアニメーション'),
    Entry('2D Full Canvas', '2D Full Canvas', '2Dフルキャンバス'),
    Entry('Masking', 'Masking', 'マスキング'),
    Entry('Motion Tracking', 'Motion Tracking', 'モーショントラッキング'),
    Entry('Video Editing', 'Video Editing', 'ビデオ編集'),
)
EDITORS = (
    Entry('VIEW_3D', '3D Viewport', '3Dビューポート', 'VIEW_3D'),
    Entry('IMAGE_EDITOR', 'Image Editor', '画像エディター', 'IMAGE_EDITOR'),
    Entry('UV_EDITOR', 'UV Editor', 'UVエディター', 'IMAGE_EDITOR'),
    Entry('SHADER_EDITOR', 'Shader Editor', 'シェーダーエディター', 'NODE_EDITOR'),
    Entry('COMPOSITOR', 'Compositor', 'コンポジター', 'NODE_EDITOR'),
    Entry('GEOMETRY_NODE_EDITOR', 'Geometry Node Editor', 'ジオメトリノードエディター', 'NODE_EDITOR'),
    Entry('TEXTURE_NODE_EDITOR', 'Texture Node Editor', 'テクスチャノードエディター', 'NODE_EDITOR'),
    Entry('SEQUENCE_EDITOR', 'Video Sequencer', 'ビデオシーケンサー', 'SEQUENCE_EDITOR'),
    Entry('CLIP_EDITOR', 'Movie Clip Editor', 'ムービークリップエディター', 'CLIP_EDITOR'),
    Entry('DOPESHEET_EDITOR', 'Dope Sheet', 'ドープシート', 'DOPESHEET_EDITOR'),
    Entry('GRAPH_EDITOR', 'Graph Editor', 'グラフエディター', 'GRAPH_EDITOR'),
    Entry('DRIVERS', 'Drivers', 'ドライバー', 'GRAPH_EDITOR'),
    Entry('NLA_EDITOR', 'Nonlinear Animation', 'ノンリニアアニメーション', 'NLA_EDITOR'),
    Entry('TEXT_EDITOR', 'Text Editor', 'テキストエディター', 'TEXT_EDITOR'),
    Entry('ASSET_BROWSER', 'Asset Browser', 'アセットブラウザー', 'FILE_BROWSER'),
    Entry('FILE_BROWSER', 'File Browser', 'ファイルブラウザー', 'FILE_BROWSER'),
    Entry('SPREADSHEET', 'Spreadsheet', 'スプレッドシート', 'SPREADSHEET'),
)
TOOL_KEYS = tuple(e.key for e in TOOLS)
WORKSPACE_KEYS = tuple(e.key for e in WORKSPACES)
EDITOR_KEYS = tuple(e.key for e in EDITORS)
PHYSICAL_EDITORS = tuple(dict.fromkeys(e.physical for e in EDITORS))
DEFAULT_SWITCHES = {
    'persist': True,
    'show_runtime_options': False,
    'auto_sync': False,
    'source_filter': False,
    'topbar': False,
    'restore_after_load': False,
    'undo_redo_sync': False,
    'notify': False,
}
CATALOG_SHA256 = hashlib.sha256(json.dumps(
    {'tools':TOOL_KEYS, 'workspaces':WORKSPACE_KEYS,
     'editors':[(e.key,e.physical) for e in EDITORS]},
    ensure_ascii=False, sort_keys=True, separators=(',',':')
).encode('utf-8')).hexdigest()


def label(entry, language):
    return entry.ja if str(language).lower().startswith('ja') else entry.en


def canonical_suite(module_name):
    """Match exact module tail, including bl_ext.user_default.<suite>.

    Never imports or enables another add-on and never matches a prefix.
    """
    if not isinstance(module_name, str):
        return None
    tail = module_name.rsplit('.', 1)[-1]
    return tail if tail in TOOL_KEYS else None


def catalog_assertions():
    if len(TOOLS) != 21 or len(set(TOOL_KEYS)) != 21:
        raise ValueError('The support map must contain exactly 21 unique suites.')
    if len(WORKSPACES) != 16 or len(EDITORS) != 17 or len(PHYSICAL_EDITORS) != 11:
        raise ValueError('Workspace/editor catalog does not match the public contract.')
    return True
