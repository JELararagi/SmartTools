# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline Blender child. No add-ons or scripts from the customer file are enabled."""
import importlib
import json
import sys
from pathlib import Path

import bpy


def run(request):
    package = Path(__file__).resolve().parent
    sys.path.insert(0, str(package.parent))
    graph = importlib.import_module(package.name + '.scene_graph')
    transactions = importlib.import_module(package.name + '.transactions')
    source = Path(request['source']).resolve(strict=True)
    if transactions.file_sha256(source) != request['input_sha']:
        raise ValueError('The saved input has changed.')
    bpy.ops.wm.open_mainfile(filepath=str(source), load_ui=True, use_scripts=False)
    if request.get('inspect_only'):
        result=graph.scene_graph(source).as_dict()
        Path(request['result']).write_text(json.dumps(result,ensure_ascii=False),'utf8')
        return
    bpy.context.preferences.filepaths.save_version = 0
    selection = request['requests']
    wanted = {r['id'] for r in selection}
    typed = {r['id']:r['operation'] for r in selection}
    removable = {}
    for id_block in bpy.data.user_map():
        key = graph.id_key(id_block)
        if key not in wanted:
            continue
        if id_block.library or id_block.use_fake_user:
            raise ValueError('Protected data in the selection: '+key)
        kind = id_block.bl_rna.identifier.upper()
        expected = {'OBJECT':'REMOVE_OBJECT','ACTION':'REMOVE_ACTION','TEXT':'REMOVE_TEXT'}.get(kind, 'REMOVE_DATA')
        if typed[key] != expected:
            raise ValueError('Data kind changed: '+key)
        removable[key] = id_block
    if set(removable) != wanted:
        raise ValueError('Selected data no longer exist.')
    bpy.data.batch_remove(ids=tuple(removable.values()))
    # Blender normally drops an unowned ID on save. Keep surviving local IDs in
    # this write only. Blender clears the extra user on reload. Persistent fake
    # users and the original file stay intact; the reopened graph is verified.
    for remaining in bpy.data.user_map():
        if remaining.users == 0 and not remaining.library and not remaining.is_embedded_data:
            remaining.use_extra_user = True
    if bpy.ops.wm.save_as_mainfile(filepath=request['staged'], copy=True, relative_remap=True,
                                  check_existing=False) != {'FINISHED'}:
        raise RuntimeError('Blender did not save the cleaned copy.')
    # Reopen bytes that will reach the buyer, with scripts disabled again.
    bpy.ops.wm.open_mainfile(filepath=request['staged'],load_ui=True,use_scripts=False)
    result=graph.scene_graph(request['staged']).as_dict()
    Path(request['result']).write_text(json.dumps(result,ensure_ascii=False),'utf8')

if __name__ == '__main__':
    request_path=Path(sys.argv[sys.argv.index('--')+1])
    run(json.loads(request_path.read_text('utf8')))
