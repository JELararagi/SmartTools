# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit-root settings storage; unknown legacy formats are never overwritten."""
from dataclasses import dataclass
from pathlib import Path
from contextlib import contextmanager
import hashlib
import json
import os
import uuid
from .placement import validate_document, new_document, InvalidSettings

MAX_BYTES = 2 * 1024 * 1024
RELATIVE_PATH = Path('Smart_Tools_Manager') / 'placement_v1.json'


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidSettings('Duplicate JSON key: '+key)
        result[key] = value
    return result


def decode(raw):
    if len(raw) > MAX_BYTES:
        raise InvalidSettings('Settings file exceeds the candidate limit.')
    try:
        value = json.loads(raw.decode('utf-8-sig'), object_pairs_hook=_unique_keys)
        return validate_document(value)
    except (UnicodeError, json.JSONDecodeError, TypeError, KeyError) as exc:
        raise InvalidSettings(str(exc)) from exc


def encode(document):
    checked = validate_document(document)
    raw = (json.dumps(checked,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')
    if len(raw) > MAX_BYTES:
        raise InvalidSettings('Settings file exceeds the candidate limit.')
    return raw


@dataclass(frozen=True)
class LoadResult:
    status: str
    document: object
    detail: str = ''


class SettingsStore:
    def __init__(self, config_root):
        # Callers must supply the root. No HOME, APPDATA, registry or install path.
        self.root = Path(config_root).resolve()
        self.path = self.root / RELATIVE_PATH
        self.backup = self.path.with_suffix('.json.bak')

    def _checked(self, path):
        path = Path(path)
        if not path.resolve().is_relative_to(self.root):
            raise OSError('Settings path escapes the supplied root.')
        current = path
        while current != self.root:
            if current.is_symlink():
                raise OSError('Symbolic links are not accepted for settings writes.')
            current = current.parent
        return path

    def _read(self, path):
        self._checked(path)
        with path.open('rb') as stream:
            return stream.read(MAX_BYTES+1)

    def load(self):
        problems = []
        primary_missing = not self.path.exists()
        for index, path in enumerate((self.path,self.backup)):
            if not path.exists():
                continue
            try:
                value = decode(self._read(path))
                return LoadResult('PRIMARY' if index == 0 else 'BACKUP_IN_MEMORY',value,'; '.join(problems))
            except (OSError,InvalidSettings,ValueError) as exc:
                problems.append(path.name+': '+str(exc))
        if primary_missing and not self.backup.exists():
            return LoadResult('NEW',new_document())
        return LoadResult('UNAVAILABLE',None,'; '.join(problems))

    @contextmanager
    def _lock(self):
        self._checked(self.path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        lock = self.path.with_suffix('.json.lock')
        self._checked(lock)
        fd = os.open(str(lock),os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        try:
            os.write(fd,b'SmartToolsManager settings transaction\n')
            os.close(fd)
            fd = None
            yield
        finally:
            if fd is not None:
                os.close(fd)
            lock.unlink()

    def _atomic_write(self, path, raw):
        self._checked(path)
        temporary = path.parent / ('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            with temporary.open('xb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(str(temporary),str(path))
        finally:
            if temporary.exists():
                temporary.unlink()

    def save(self, document):
        raw = encode(document)
        with self._lock():
            previous = None
            if self.path.exists():
                previous = self._read(self.path)
                decode(previous)  # Reject unknown/corrupt legacy settings before mutation.
            if self.backup.exists():
                decode(self._read(self.backup))
            if previous == raw:
                return {'changed':False,'sha256':hashlib.sha256(raw).hexdigest()}
            if previous is not None:
                self._atomic_write(self.backup,previous)
            self._atomic_write(self.path,raw)
        return {'changed':True,'sha256':hashlib.sha256(raw).hexdigest()}
