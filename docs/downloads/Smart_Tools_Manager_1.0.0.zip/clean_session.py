# SPDX-License-Identifier: GPL-3.0-or-later
"""Hold one inspected input and publish only separately verified user-selected copies."""
import ctypes
import json
import os
from pathlib import Path
import subprocess
import tempfile

import bpy

from . import cleanup, scene_graph, transactions


def memory_available():
    if os.name == 'nt':
        class Memory(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[
                (k,ctypes.c_ulonglong) for k in ('physical','free','page','page_free','v','v_free','extended')]
        data=Memory()
        data.length=ctypes.sizeof(data)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(data)):
            return int(data.free)
    else:
        try:return os.sysconf('SC_AVPHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
        except (OSError,ValueError,AttributeError):pass
    return None


def child_graph(source, input_sha, parent, requests=None, staged=None):
    with tempfile.TemporaryDirectory(prefix='.stm-worker-',dir=parent) as folder:
        scratch=Path(folder)
        result=scratch/'output.json'
        req=scratch/'request.json'
        req.write_text(json.dumps(dict(source=str(source),input_sha=input_sha,
                  inspect_only=staged is None,requests=requests,staged=str(staged),result=str(result))),'utf8')
        env=os.environ.copy()
        for name in ('TEMP','TMP','TMPDIR','HOME','APPDATA','LOCALAPPDATA','USERPROFILE',
                     'XDG_CACHE_HOME','BLENDER_USER_RESOURCES','BLENDER_USER_CONFIG','BLENDER_USER_DATAFILES',
                     'BLENDER_USER_SCRIPTS','BLENDER_USER_EXTENSIONS'):
            target=scratch/name
            target.mkdir()
            env[name]=str(target)
        env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',CUDA_CACHE_DISABLE='1',__GL_SHADER_DISK_CACHE='0')
        worker=Path(__file__).resolve().with_name('copy_worker.py')
        args=[bpy.app.binary_path,'--background','--factory-startup','--disable-autoexec','--offline-mode',
              '--threads','1','--python-exit-code','1','--python',str(worker),'--',str(req)]
        with (scratch/'worker.log').open('wb') as log:
            run=subprocess.run(args,cwd=scratch,env=env,stdin=subprocess.DEVNULL,stdout=log,
                               stderr=subprocess.STDOUT,timeout=300,check=False,
                               creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if run.returncode or not result.is_file():
            trace=(scratch/'worker.log').read_text('utf8',errors='replace').strip().splitlines()
            reason=next((line for line in reversed(trace) if 'Error:' in line), 'No verified file returned.')
            raise RuntimeError(reason)
        return cleanup.graph_from_dict(json.loads(result.read_text('utf8')))


class CleanupSession:
    def __init__(self):
        self.inspection=None
        self.selected=set()
        self.contract=None
        self.result=None
        self.live_fingerprint=None
        self.disk_graph=None

    def inspect(self, request_path=''):
        self.reset()
        if not bpy.data.filepath:
            raise ValueError('Save the input .blend before inspection.')
        if request_path:
            filename=Path(bpy.path.abspath(request_path))
            if filename.stat().st_size>4*1024*1024:
                raise ValueError('The preservation file is too large.')
            self.contract=cleanup.preservation_contract(json.loads(filename.read_text('utf-8-sig')))
        graph=scene_graph.scene_graph(bpy.data.filepath,dirty=bpy.data.is_dirty)
        if bpy.data.is_dirty:
            saved_graph=graph
        else:
            # Unsaved zero-user IDs and transient viewer images can remain alive in
            # the UI after saving. Only a reopened file describes what a copy contains.
            scratch_dir=Path(bpy.app.tempdir or tempfile.gettempdir())
            saved_graph=child_graph(Path(bpy.data.filepath),graph.input.sha256,scratch_dir)
        self.live_fingerprint=graph.fingerprint
        self.disk_graph=saved_graph
        self.inspection=cleanup.inspect_graph(saved_graph,self.contract)
        self.result=self.inspection
        return len(self.inspection['candidates']),len(self.inspection['blockers'])

    def reset(self):
        self.inspection=None
        self.selected.clear()
        self.contract=None
        self.result=None
        self.live_fingerprint=None
        self.disk_graph=None

    def toggle(self,key):
        if not self.inspection or key not in self.inspection['candidates']:
            raise ValueError('Only an inspected candidate can be selected.')
        if key in self.selected:self.selected.remove(key)
        else:self.selected.add(key)

    def apply(self, output, language='en'):
        if not self.inspection or not self.selected:
            raise ValueError('Inspect and explicitly select working data first.')
        if not output or not bpy.data.filepath or bpy.data.is_dirty:
            raise ValueError('A saved input and a new output filename are required.')
        original=Path(bpy.data.filepath).resolve(strict=True)
        destination=Path(bpy.path.abspath(output))
        rows=[{'id':r['id'],'operation':r['operation']} for r in self.inspection['rows'] if r['id'] in self.selected]
        outputs={}
        def read_graph(path):
            if path.resolve()==original:
                live=scene_graph.scene_graph(path,dirty=bpy.data.is_dirty)
                if live.fingerprint!=self.live_fingerprint:
                    raise ValueError('STALE_INPUT_OR_REFERENCE_GRAPH')
                return self.disk_graph
            return outputs[path.resolve()]
        def mutate(staged,plan):
            outputs[staged.resolve()]=child_graph(original,plan['input']['sha256'],destination.parent,rows,staged)
        self.result=transactions.apply_copy(original,destination,self.inspection,rows,read_graph,mutate,
                    contract=self.contract,confirmed=True,free_memory_bytes=memory_available(),language=language)
        if self.result.get('outcome')!='APPLIED_TO_NEW_COPY':
            raise ValueError(self.result.get('error') or self.result.get('outcome'))
        return self.result
