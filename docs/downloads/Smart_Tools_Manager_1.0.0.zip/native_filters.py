# SPDX-License-Identifier: GPL-3.0-or-later
"""Reversible Blender workspace owners for existing SmartTools panels."""
import bpy
from . import manager
from .catalog_api import W, WORKSPACE_NAMES
from .filtering import FilterView, FilterLease, managed_owner_rules

leases={}

def current(workspace):
    return FilterView(workspace.use_filter_by_owner,frozenset(x.name for x in workspace.owner_ids))

def write_view(workspace,desired):
    for tag in list(workspace.owner_ids):
        if tag.name not in desired.owners:workspace.owner_ids.remove(tag)
    known={tag.name for tag in workspace.owner_ids}
    for name in sorted(desired.owners-known):workspace.owner_ids.new(name)
    workspace.use_filter_by_owner=desired.enabled

def restore_owners():
    for ws in bpy.data.workspaces:
        entry=leases.pop(ws.as_pointer(),None)
        if entry:write_view(ws,entry.restore(current(ws)))
    leases.clear()

def apply_owners(context):
    active={addon.module for addon in context.preferences.addons}
    for ws in bpy.data.workspaces:
        key=WORKSPACE_NAMES.get(ws.name)
        if key is None:continue
        before=current(ws)
        lease=leases.get(ws.as_pointer())
        if lease is None:
            lease=FilterLease(before)
            leases[ws.as_pointer()]=lease
        rules=managed_owner_rules(manager.service.model,W[key],active)
        write_view(ws,lease.propose(before,active,rules,__package__))
