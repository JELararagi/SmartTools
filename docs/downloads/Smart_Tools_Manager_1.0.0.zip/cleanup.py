# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Reference-aware, deterministic inspection and explicit-removal planning.

This module never reads Blender data or changes files. Host collectors must
supply complete reference-family evidence; an uninspected family blocks apply.
Names and user counts never establish that a node may be removed.
"""
from collections import defaultdict, deque
from copy import deepcopy
from dataclasses import asdict, dataclass, field
import hashlib
import json

SCHEMA = 'jel-stm-cleanup-manifest/1'
MAX_NODES = 12000
REFERENCE_FAMILIES = (
    'modifier','constraint','driver_target','deform_group','physics_group',
    'shape_key_driver','action_curve','action_nla','material_node',
    'collection_instance','library_link','texture','custom_property',
    'smarttools_name','ui_name','script_name','id_dependency',
)
OPERATIONS = {
    'OBJECT':'REMOVE_OBJECT', 'MESH':'REMOVE_DATA', 'CURVE':'REMOVE_DATA',
    'CAMERA':'REMOVE_DATA', 'LIGHT':'REMOVE_DATA', 'ARMATURE':'REMOVE_DATA',
    'COLLECTION':'REMOVE_DATA', 'MATERIAL':'REMOVE_DATA', 'NODETREE':'REMOVE_DATA',
    'TEXT':'REMOVE_TEXT', 'ACTION':'REMOVE_ACTION', 'NLA':'REMOVE_ACTION',
    'VERTEX_GROUP':'REMOVE_GROUP', 'SHAPE_KEY':'REMOVE_KEY',
    'WORK_MARK':'REMOVE_WORK_MARK', 'CACHE':'CLEAR_CACHE',
    'ORPHAN':'REMOVE_ORPHAN',
}


class CleanupError(ValueError):
    pass


def stable_bytes(value):
    return (json.dumps(value,ensure_ascii=False,sort_keys=True,
                       separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')


def digest(value):
    return hashlib.sha256(stable_bytes(value)).hexdigest()


@dataclass(frozen=True)
class InputIdentity:
    path: str
    sha256: str
    size: int
    saved: bool = True
    dirty: bool = False


@dataclass(frozen=True)
class Node:
    id: str
    kind: str
    name: str
    working: bool = False
    persisted: bool = True
    release_root: bool = False
    fake_user: bool = False
    linked: bool = False
    external_texture: bool = False
    content_sha256: str = ''
    protected_reasons: tuple = ()


@dataclass(frozen=True)
class Reference:
    source: str
    target: str
    family: str
    detail: str = ''
    membership_only: bool = False


@dataclass(frozen=True)
class ReferenceGraph:
    input: InputIdentity
    nodes: tuple
    references: tuple = ()
    complete_families: tuple = ()
    missing_dependencies: tuple = ()
    dynamic_sources: tuple = ()
    unresolved_references: tuple = ()

    def validate(self):
        if len(self.nodes) > MAX_NODES:
            raise CleanupError('NODE_LIMIT_EXCEEDED: 12000')
        ids = [n.id for n in self.nodes]
        if len(ids) != len(set(ids)) or any(not isinstance(v,str) or not v for v in ids):
            raise CleanupError('INVALID_NODE_IDENTIFIERS')
        known = set(ids)
        for node in self.nodes:
            if not isinstance(node.kind,str) or not isinstance(node.name,str):
                raise CleanupError('INVALID_NODE_TYPE')
            for key in ('working','persisted','release_root','fake_user','linked','external_texture'):
                if type(getattr(node,key)) is not bool:
                    raise CleanupError('INVALID_NODE_BOOLEAN: '+key)
        if type(self.input.saved) is not bool or type(self.input.dirty) is not bool:
            raise CleanupError('INVALID_INPUT_FLAGS')
        if type(self.input.size) is not int or self.input.size < 0:
            raise CleanupError('INVALID_INPUT_SIZE')
        for ref in self.references:
            if ref.source not in known:
                raise CleanupError('UNKNOWN_REFERENCE_OWNER: '+ref.source)
            if ref.family not in REFERENCE_FAMILIES:
                raise CleanupError('UNKNOWN_REFERENCE_FAMILY: '+ref.family)
            if type(ref.membership_only) is not bool:
                raise CleanupError('INVALID_MEMBERSHIP_FLAG')
        if any(f not in REFERENCE_FAMILIES for f in self.complete_families):
            raise CleanupError('UNKNOWN_INSPECTION_FAMILY')
        stable_bytes(self.as_dict())
        return True

    def as_dict(self):
        return {
            'input':asdict(self.input),
            'nodes':[asdict(n) for n in sorted(self.nodes,key=lambda n:n.id)],
            'references':[asdict(r) for r in sorted(self.references,key=lambda r:(r.source,r.target,r.family,r.detail,r.membership_only))],
            'complete_families':sorted(set(self.complete_families)),
            'missing_dependencies':sorted(set(self.missing_dependencies)),
            'dynamic_sources':sorted(set(self.dynamic_sources)),
            'unresolved_references':sorted(set(self.unresolved_references)),
        }

    @property
    def fingerprint(self):
        return digest(self.as_dict())


def graph_from_dict(value):
    try:
        graph = ReferenceGraph(
            input=InputIdentity(**value['input']),
            nodes=tuple(Node(**{**n,'protected_reasons':tuple(n.get('protected_reasons',()))}) for n in value['nodes']),
            references=tuple(Reference(**r) for r in value.get('references',())),
            complete_families=tuple(value.get('complete_families',())),
            missing_dependencies=tuple(value.get('missing_dependencies',())),
            dynamic_sources=tuple(value.get('dynamic_sources',())),
            unresolved_references=tuple(value.get('unresolved_references',())),
        )
    except (TypeError,KeyError,ValueError) as exc:
        raise CleanupError('INVALID_GRAPH: '+str(exc)) from exc
    graph.validate()
    return graph


def preservation_contract(value=None):
    value = {} if value is None else value
    allowed = {'preserve_names','preserve_ids','preserve_all_for_dynamic_scripts'}
    if not isinstance(value,dict) or set(value)-allowed:
        raise CleanupError('UNKNOWN_PRESERVATION_FIELD')
    result = {'preserve_names':[],'preserve_ids':[], 'preserve_all_for_dynamic_scripts':False}
    for key in ('preserve_names','preserve_ids'):
        entries = value.get(key,[])
        if not isinstance(entries,list) or any(not isinstance(s,str) or not s for s in entries):
            raise CleanupError('INVALID_PRESERVATION_LIST: '+key)
        result[key] = sorted(set(entries))
    flag = value.get('preserve_all_for_dynamic_scripts',False)
    if type(flag) is not bool:
        raise CleanupError('INVALID_DYNAMIC_PRESERVATION_FLAG')
    result['preserve_all_for_dynamic_scripts'] = flag
    return result


def inspect_graph(graph, contract=None):
    graph.validate()
    contract = preservation_contract(contract)
    nodes = {n.id:n for n in graph.nodes}
    reasons = defaultdict(set)
    blockers = []
    if not graph.input.saved or graph.input.dirty or not graph.input.path or not graph.input.sha256:
        blockers.append({'code':'INPUT_NOT_SAVED_CLEAN','detail':graph.input.path})
    for family in sorted(set(REFERENCE_FAMILIES)-set(graph.complete_families)):
        blockers.append({'code':'REFERENCE_FAMILY_NOT_INSPECTED','detail':family})
    for name in sorted(set(graph.missing_dependencies)):
        blockers.append({'code':'MISSING_OR_UNREADABLE_DEPENDENCY','detail':name})
    for name in sorted(set(graph.unresolved_references)):
        blockers.append({'code':'UNRESOLVED_REFERENCE','detail':name})
    for name in sorted(set(graph.dynamic_sources)):
        if not contract['preserve_all_for_dynamic_scripts']:
            blockers.append({'code':'UNRESOLVED_DYNAMIC_SCRIPT','detail':name})
    force_all = bool(graph.dynamic_sources) and contract['preserve_all_for_dynamic_scripts']
    names = set(contract['preserve_names'])
    ids = set(contract['preserve_ids'])
    for missing in sorted(ids-set(nodes)):
        blockers.append({'code':'PRESERVE_ID_NOT_FOUND','detail':missing})
    for missing in sorted(names-{n.name for n in graph.nodes}):
        blockers.append({'code':'PRESERVE_NAME_NOT_FOUND','detail':missing})
    follow_memberships = set()
    for node in graph.nodes:
        if (not isinstance(node.content_sha256,str) or len(node.content_sha256) != 64
                or any(c not in '0123456789abcdef' for c in node.content_sha256)):
            blockers.append({'code':'CONTENT_NOT_FINGERPRINTED','detail':node.id})
            reasons[node.id].add('CONTENT_NOT_FINGERPRINTED')
        if node.release_root:
            reasons[node.id].add('VISIBLE_RELEASE_ROOT')
        if node.fake_user:
            reasons[node.id].add('FAKE_USER_INTENT')
        if node.linked:
            reasons[node.id].add('LINKED_DATA')
        if node.external_texture or node.kind in {'IMAGE','TEXTURE'}:
            reasons[node.id].add('TEXTURE_CONTENT')
        if node.id in ids or node.name in names:
            reasons[node.id].add('EXPLICIT_PRESERVATION_CONTRACT')
            follow_memberships.add(node.id)
        if force_all:
            reasons[node.id].add('PRESERVE_ALL_FOR_DYNAMIC_SCRIPTS')
        reasons[node.id].update(node.protected_reasons)
    roots = sorted(k for k,v in reasons.items() if v)
    # Nonworking and unsupported nodes are retained and therefore retain their
    # dependencies, even when they are not a visible release root.
    held = {n.id for n in graph.nodes if not n.working or n.kind not in OPERATIONS or not n.persisted}
    outward = defaultdict(list)
    for ref in graph.references:
        if ref.target not in nodes:
            blockers.append({'code':'MISSING_REFERENCE_TARGET','detail':ref.source+' -> '+ref.target})
        else:
            outward[ref.source].append(ref)
    queue = deque((key,key in follow_memberships) for key in sorted(set(roots)|held))
    visited = set()
    while queue:
        owner, follow_all = queue.popleft()
        if (owner,follow_all) in visited:
            continue
        visited.add((owner,follow_all))
        for ref in outward[owner]:
            if ref.membership_only and not follow_all:
                continue
            reasons[ref.target].add('REFERENCE:'+ref.family+':'+ref.source+':'+ref.detail)
            next_follow = follow_all or ref.family == 'collection_instance'
            queue.append((ref.target,next_follow))
    rows = []
    for node in sorted(graph.nodes,key=lambda n:n.id):
        why = sorted(reasons[node.id])
        if why:
            status = 'PROTECTED'
        elif not node.persisted:
            status = 'HOLD'
            why = ['NOT_PRESENT_IN_SAVED_INPUT']
        elif not node.working:
            status = 'HOLD'
            why = ['WORKING_DATA_NOT_ESTABLISHED']
        elif node.kind not in OPERATIONS:
            status = 'HOLD'
            why = ['UNSUPPORTED_TYPED_OPERATION']
        else:
            status = 'CANDIDATE'
            why = ['EXPLICIT_WORKING_DATA_WITH_NO_RETAINED_STRONG_REFERENCE']
        rows.append({'id':node.id,'kind':node.kind,'name':node.name,'status':status,
                     'operation':OPERATIONS.get(node.kind),'reasons':why})
    unique_blockers = {digest(b):b for b in blockers}
    blockers = sorted(unique_blockers.values(),key=lambda b:(b['code'],b['detail']))
    result = {
        'schema':SCHEMA, 'input':asdict(graph.input),
        'graph_sha256':graph.fingerprint, 'preservation_contract':contract,
        'preserved_roots':roots, 'rows':rows,
        'candidates':[r['id'] for r in rows if r['status']=='CANDIDATE'],
        'blockers':blockers,
        'reference_reasons':[asdict(r) for r in sorted(graph.references,key=lambda r:(r.source,r.target,r.family,r.detail,r.membership_only))],
        'requested_operations':[], 'actual_removals':[], 'actual_changes':[],
        'outcome':'INSPECTED_NOT_APPLIED',
        'counts':{'candidates':sum(r['status']=='CANDIDATE' for r in rows),
                  'protected':sum(r['status']=='PROTECTED' for r in rows),
                  'held':sum(r['status']=='HOLD' for r in rows),
                  'selected':0,'blockers':len(blockers),'actual_removed':0},
    }
    result['inspection_sha256'] = digest(result)
    return result


def prepare_apply(inspection, current_graph, requests, contract=None):
    current = inspect_graph(current_graph,contract)
    if inspection != current:
        raise CleanupError('STALE_INPUT_OR_REFERENCE_GRAPH')
    if current['blockers']:
        raise CleanupError('BLOCKERS_REMAIN')
    if not isinstance(requests,(list,tuple)) or not requests:
        raise CleanupError('NO_EXPLICIT_SELECTION')
    candidates = {r['id']:r['operation'] for r in current['rows'] if r['status']=='CANDIDATE'}
    selected = {}
    for item in requests:
        if not isinstance(item,dict) or set(item) != {'id','operation'}:
            raise CleanupError('INVALID_REQUEST')
        node_id = item['id']
        if node_id in selected:
            raise CleanupError('DUPLICATE_SELECTION')
        if node_id not in candidates or item['operation'] != candidates[node_id]:
            raise CleanupError('NOT_A_CANDIDATE_OR_WRONG_OPERATION: '+str(node_id))
        selected[node_id] = item['operation']
    for ref in current_graph.references:
        if ref.target in selected and ref.source not in selected and not ref.membership_only:
            raise CleanupError('UNSELECTED_OWNER_STILL_REFERENCES_TARGET: '+ref.source+' -> '+ref.target)
    result = deepcopy(current)
    result['requested_operations'] = [{'id':key,'operation':selected[key]} for key in sorted(selected)]
    result['counts']['selected'] = len(selected)
    result['outcome'] = 'READY_FOR_EXPLICIT_COPY'
    result['request_sha256'] = digest(result)
    return result


def confirm_output(plan, before, after):
    """Verify reopened output, not a worker's optimistic deletion counter."""
    before.validate()
    after.validate()
    if (set(after.complete_families) != set(REFERENCE_FAMILIES)
            or after.missing_dependencies or after.dynamic_sources or after.unresolved_references):
        raise CleanupError('OUTPUT_REFERENCE_EVIDENCE_INCOMPLETE')
    original = {n.id:n for n in before.nodes}
    actual = {n.id:n for n in after.nodes}
    requested = {r['id']:r['operation'] for r in plan['requested_operations']}
    remove_ids = {k for k,v in requested.items() if v != 'CLEAR_CACHE'}
    removed = set(original)-set(actual)
    if removed != remove_ids or set(actual)-set(original):
        raise CleanupError('OUTPUT_REMOVAL_SET_MISMATCH: missing '+str(sorted(removed-remove_ids))+' retained '+str(sorted(remove_ids-removed))+' added '+str(sorted(set(actual)-set(original))))
    changed = []
    for node_id in sorted(set(original)&set(actual)):
        left,right = asdict(original[node_id]),asdict(actual[node_id])
        if requested.get(node_id) == 'CLEAR_CACHE':
            left.pop('content_sha256')
            right.pop('content_sha256')
            if left != right:
                raise CleanupError('UNEXPECTED_CACHE_NODE_CHANGE')
            if actual[node_id].content_sha256 != digest({'cache_entries':[]}):
                raise CleanupError('CACHE_NOT_CONFIRMED_EMPTY')
            changed.append({'id':node_id,'operation':'CLEAR_CACHE'})
        elif left != right:
            raise CleanupError('UNSELECTED_CONTENT_CHANGED: '+node_id)
    expected_refs = {stable_bytes(asdict(r)) for r in before.references if r.source not in removed and r.target not in removed}
    actual_refs = {stable_bytes(asdict(r)) for r in after.references}
    if expected_refs != actual_refs:
        raise CleanupError('RETAINED_REFERENCE_GRAPH_CHANGED')
    result = deepcopy(plan)
    result['actual_removals'] = sorted(removed)
    result['actual_changes'] = changed
    result['counts']['actual_removed'] = len(removed)
    result['outcome'] = 'OUTPUT_VERIFIED'
    return result
