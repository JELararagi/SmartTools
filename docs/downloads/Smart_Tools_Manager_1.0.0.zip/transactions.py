# Copyright (c) 2026 JELararagi.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Disposable-copy transaction. Neither source nor external files are written.

The host supplies read_graph(path) and transform_copy(path, plan). The latter
receives only the transaction-owned staging file. Verification reads the saved
output independently instead of trusting a deletion count from the transformer.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import os
import shutil
import tempfile
from .cleanup import CleanupError, prepare_apply, confirm_output, stable_bytes

MIN_FREE_MEMORY = 10 * 1024**3


def file_sha256(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            value.update(chunk)
    return value.hexdigest()


def summary_text(manifest, language='en'):
    ja = str(language).lower().startswith('ja')
    removed = manifest.get('actual_removals',[])
    lines = [
        'リリース整理の結果' if ja else 'Release cleanup result',
        ('状態: ' if ja else 'Outcome: ')+manifest.get('outcome','UNKNOWN'),
        ('確定した実削除: ' if ja else 'Confirmed removals: ')+str(len(removed)),
    ]
    rows = {r['id']:r for r in manifest.get('rows',[])}
    for node_id in removed:
        row = rows.get(node_id,{})
        lines.append('- '+row.get('name',node_id)+' ['+row.get('kind','')+']')
    for blocker in manifest.get('blockers',[]):
        lines.append(('阻害: ' if ja else 'Blocker: ')+blocker['code']+' '+blocker.get('detail',''))
    if manifest.get('error'):
        lines.append(('理由: ' if ja else 'Reason: ')+manifest['error'])
    lines.append('元のファイルは変更対象に含めません。' if ja else 'The source file is never a write target.')
    return '\n'.join(lines)+'\n'


def _stamp(path):
    stat = Path(path).stat()
    return (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)


def _write_new(path, source, created):
    """O_EXCL creation; remember identity even when a partial write fails."""
    path = Path(path)
    if path.is_symlink():
        raise CleanupError('OUTPUT_IS_LINK')
    stream = path.open('xb')
    try:
        with stream:
            if isinstance(source,bytes):
                stream.write(source)
            else:
                with Path(source).open('rb') as incoming:
                    shutil.copyfileobj(incoming,stream,1024*1024)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        if path.exists():
            created.append((path,_stamp(path)))


def _rollback(created):
    retained = []
    for path, stamp in reversed(created):
        if not path.exists():
            continue
        if path.is_symlink() or _stamp(path) != stamp:
            retained.append(str(path))
            continue
        path.unlink()
    return retained


def _targets(destination):
    destination = Path(destination)
    return (destination,destination.with_suffix('.cleanup.json'),destination.with_suffix('.cleanup.txt'))


def _failure(inspection, error, outcome='FAILED', requested=()):
    result = deepcopy(inspection)
    result['requested_operations'] = deepcopy(list(requested))
    result['actual_removals'] = []
    result['actual_changes'] = []
    result['counts']['actual_removed'] = 0
    result['counts']['selected'] = len(requested)
    result['outcome'] = outcome
    result['error'] = str(error)
    return result


from contextlib import contextmanager

@contextmanager
def _sibling_stage(parent):
    fd, name = tempfile.mkstemp(prefix='.stm-copy-', suffix='.blend', dir=parent)
    os.close(fd)
    staged = Path(name)
    try:
        yield staged
    finally:
        staged.unlink(missing_ok=True)

def apply_copy(source, destination, inspection, requests, read_graph,
               transform_copy, *, contract=None, confirmed=False,
               free_memory_bytes=None, language='en'):
    source = Path(source)
    destination = Path(destination)
    requested = list(requests) if isinstance(requests,(list,tuple)) else []
    if not confirmed:
        return _failure(inspection,'EXPLICIT_CONFIRMATION_NOT_GIVEN','CANCELLED',requested)
    created = []
    preflight_ok = False
    source_hash = None
    try:
        if type(free_memory_bytes) is not int or free_memory_bytes < MIN_FREE_MEMORY:
            raise CleanupError('INSUFFICIENT_OR_UNKNOWN_FREE_MEMORY')
        if source.is_symlink() or not source.is_file():
            raise CleanupError('INVALID_SOURCE_FILE')
        if destination.suffix.lower() != '.blend' or not destination.parent.is_dir():
            raise CleanupError('INVALID_NEW_BLEND_DESTINATION')
        if source.resolve() == destination.resolve():
            raise CleanupError('SOURCE_CANNOT_BE_OUTPUT')
        paths = _targets(destination)
        if any(p.exists() or p.is_symlink() for p in paths):
            raise CleanupError('OUTPUT_ALREADY_EXISTS')
        if any(p.resolve() == source.resolve() for p in paths):
            raise CleanupError('SOURCE_CANNOT_BE_OUTPUT')
        source_hash = file_sha256(source)
        current = read_graph(source)
        if (current.input.sha256 != source_hash or current.input.size != source.stat().st_size
                or Path(current.input.path).resolve() != source.resolve()):
            raise CleanupError('INPUT_IDENTITY_MISMATCH')
        plan = prepare_apply(inspection,current,requested,contract)
        preflight_ok = True
        # Keep the staged .blend beside the destination so Blender's relative paths
        # remain valid after the verified bytes are published under their final name.
        with _sibling_stage(destination.parent) as staged:
            shutil.copyfile(source,staged)
            if file_sha256(staged) != source_hash or file_sha256(source) != source_hash:
                raise CleanupError('SOURCE_CHANGED_DURING_COPY')
            # Revalidate immediately before invoking the transformer.
            prepare_apply(inspection,read_graph(source),requested,contract)
            transform_copy(staged,plan)
            if not staged.is_file() or staged.is_symlink():
                raise CleanupError('TRANSFORMER_DID_NOT_PRODUCE_REGULAR_COPY')
            after = read_graph(staged)
            result = confirm_output(plan,current,after)
            if file_sha256(source) != source_hash:
                raise CleanupError('SOURCE_CHANGED_DURING_TRANSACTION')
            result['outcome'] = 'APPLIED_TO_NEW_COPY'
            result['output'] = {'path':str(destination.resolve()),'sha256':file_sha256(staged),'bytes':staged.stat().st_size}
            _write_new(paths[0],staged,created)
            _write_new(paths[1],stable_bytes(result),created)
            _write_new(paths[2],summary_text(result,language).encode('utf-8'),created)
            if file_sha256(paths[0]) != result['output']['sha256']:
                raise CleanupError('PUBLISHED_COPY_HASH_MISMATCH')
            if json.loads(paths[1].read_text(encoding='utf-8')) != result:
                raise CleanupError('MANIFEST_READBACK_MISMATCH')
            if file_sha256(source) != source_hash:
                raise CleanupError('SOURCE_CHANGED_BEFORE_COMMIT')
            return result
    except Exception as exc:
        retained = _rollback(created)
        result = _failure(inspection,str(exc),'FAILED',requested)
        result['source_unchanged'] = bool(source_hash and source.is_file() and file_sha256(source)==source_hash)
        result['rollback_retained_paths'] = retained
        # A rejected preflight does not create files. A failed transformation
        # gets truthful sidecars if their previously unused paths remain free.
        if preflight_ok and not retained:
            failed_files = []
            paths = _targets(destination)
            try:
                if any(p.exists() or p.is_symlink() for p in paths):
                    raise CleanupError('FAILURE_REPORT_DESTINATION_TAKEN')
                _write_new(paths[1],stable_bytes(result),failed_files)
                _write_new(paths[2],summary_text(result,language).encode('utf-8'),failed_files)
            except Exception as report_error:
                result['failure_report_error'] = str(report_error)
                result['rollback_retained_paths'].extend(_rollback(failed_files))
        return result


def export_result(manifest, json_path, *, language='en'):
    target = Path(json_path)
    if target.suffix.lower() != '.json' or not target.parent.is_dir():
        raise CleanupError('INVALID_RESULT_DESTINATION')
    text = target.with_suffix('.txt')
    if any(p.exists() or p.is_symlink() for p in (target,text)):
        raise CleanupError('OUTPUT_ALREADY_EXISTS')
    created = []
    try:
        _write_new(target,stable_bytes(manifest),created)
        _write_new(text,summary_text(manifest,language).encode('utf-8'),created)
        if json.loads(target.read_text(encoding='utf-8')) != manifest:
            raise CleanupError('MANIFEST_READBACK_MISMATCH')
    except Exception:
        _rollback(created)
        raise
    return {'json':str(target),'text':str(text),'sha256':file_sha256(target)}
