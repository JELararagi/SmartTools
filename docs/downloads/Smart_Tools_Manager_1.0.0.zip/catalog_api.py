# SPDX-License-Identifier: GPL-3.0-or-later
"""Public placement identifiers used by Blender operators and SmartTools panels."""
from . import registry

WORKSPACES = ('LAYOUT', 'MODELING', 'SCULPTING', 'UV_EDITING', 'TEXTURE_PAINT',
              'SHADING', 'ANIMATION', 'RENDERING', 'COMPOSITING', 'GEOMETRY_NODES',
              'SCRIPTING', 'ANIMATION_2D', 'FULL_CANVAS_2D', 'MASKING',
              'MOTION_TRACKING', 'VIDEO_EDITING')
EDITORS = ('VIEW_3D', 'IMAGE_EDITOR', 'UV_EDITOR', 'SHADER_EDITOR', 'COMPOSITOR',
           'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR', 'VIDEO_SEQUENCER',
           'MOVIE_CLIP_EDITOR', 'DOPE_SHEET', 'GRAPH_EDITOR', 'DRIVERS',
           'NLA_EDITOR', 'TEXT_EDITOR', 'ASSET_BROWSER', 'FILE_BROWSER', 'SPREADSHEET')
TOOLS = tuple(name.removesuffix('_suite').upper() for name in registry.TOOL_KEYS)
W = dict(zip(WORKSPACES, registry.WORKSPACE_KEYS, strict=True))
E = dict(zip(EDITORS, registry.EDITOR_KEYS, strict=True))
T = dict(zip(TOOLS, registry.TOOL_KEYS, strict=True))
WORKSPACE_NAMES = {name:key for key, entry in zip(WORKSPACES, registry.WORKSPACES)
                   for name in (key, entry.key, entry.en, entry.ja)}
EDITOR_ALIASES = {
    'UV':'UV_EDITOR', 'ShaderNodeTree':'SHADER_EDITOR', 'CompositorNodeTree':'COMPOSITOR',
    'GeometryNodeTree':'GEOMETRY_NODE_EDITOR', 'TextureNodeTree':'TEXTURE_NODE_EDITOR',
    'SEQUENCE_EDITOR':'VIDEO_SEQUENCER', 'CLIP_EDITOR':'MOVIE_CLIP_EDITOR',
    'DOPESHEET_EDITOR':'DOPE_SHEET', 'FCURVES':'GRAPH_EDITOR', 'ASSETS':'ASSET_BROWSER',
}
SELF_POLICY = 'NOT_CATALOGUED_NO_N_PANEL'

def editor_key_from_area(area, space=None):
    if not area:
        return None
    space = space or getattr(getattr(area, 'spaces', None), 'active', None)
    kind = area.type
    if kind == 'NODE_EDITOR':
        node = getattr(space, 'tree_type', None) or getattr(area, 'ui_type', '')
        return EDITOR_ALIASES.get(node)
    if kind == 'IMAGE_EDITOR':
        return 'UV_EDITOR' if getattr(area, 'ui_type', '') == 'UV' or getattr(space, 'ui_mode', '') == 'UV' else 'IMAGE_EDITOR'
    if kind == 'GRAPH_EDITOR':
        return 'DRIVERS' if 'DRIVERS' in (getattr(area, 'ui_type', ''), getattr(space, 'mode', '')) else kind
    if kind == 'FILE_BROWSER':
        return 'ASSET_BROWSER' if 'ASSETS' in (getattr(area, 'ui_type', ''), getattr(space, 'browse_mode', '')) else kind
    return EDITOR_ALIASES.get(kind, kind if kind in E else None)

def sparse_cells(matrix):
    """Validate the complete public matrix before making any changes."""
    if not isinstance(matrix, dict) or set(matrix) != set(W):
        raise ValueError('The workspace list differs from the SmartTools catalog.')
    disabled = []
    for workspace, rows in matrix.items():
        if not isinstance(rows, dict) or set(rows) != set(E):
            raise ValueError('Incomplete editor list for ' + workspace)
        for editor, tools in rows.items():
            if not isinstance(tools, dict) or set(tools) != set(T):
                raise ValueError('Incomplete tool list for ' + workspace + '/' + editor)
            for key, enabled in tools.items():
                if type(enabled) is not bool:
                    raise ValueError('A placement cell must be true or false.')
                if not enabled:
                    disabled.append(dict(workspace=W[workspace], editor=E[editor], suite=T[key], enabled=False))
    return disabled

def public_matrix(state):
    return {w:{e:{t:state.allowed(suite, workspace, editor) for t, suite in T.items()}
               for e, editor in E.items()} for w, workspace in W.items()}

def get_catalog_snapshot():
    return dict(workspaces=list(W), editors=list(E), tools=list(T),
                manager_self_rule_policy=SELF_POLICY)
