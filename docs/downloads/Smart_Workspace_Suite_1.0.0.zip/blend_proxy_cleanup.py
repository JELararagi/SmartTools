# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Owned, RNA-only legacy proxy migration for Smart Workspace Suite.

No saved ``.blend`` file is opened, scanned, byte-patched, recompressed, or
replaced by this module.  No datablock collection is purged and no datablock is
removed.  Blender remains the only writer of ``.blend`` files.

A candidate can participate only when it was recorded by this exact runtime in
the bounded generation ledger and all RNA ownership fields match exactly.  The
save-pre migration is journalled and rolled back as one transaction.  Manual
cleanup defaults to dry-run.
"""

from __future__ import annotations

import copy
import time
import uuid
from typing import Any, Dict, Iterable

import bpy
from bpy.app.handlers import persistent

from . import runtime_ledger as _runtime_ledger

_REGISTERED = False
_HANDLER_GENERATION = ""
_LAST_COUNTS: Dict[str, int] = {}

PACKAGE_ID = "smart_workspace_suite"
OWNER_UUID = "9091461c-413d-4a91-9517-767331d5e6bb"
LEGACY_SCHEMA = "SWS_PROXY_ARTIFACT_V1"
CURRENT_SCHEMA = "SWS_PROXY_ARTIFACT_V2"
_LEDGER_KEY = "JELARARAGI_SMART_WORKSPACE_PROXY_ARTIFACT_LEDGER_V2"
_MAX_LEDGER_RECORDS = 1024
_MODULE_IDENTITY = object()

_OWNER_KEY = "_sws_proxy_owner_uuid"
_ARTIFACT_KEY = "_sws_proxy_artifact_uuid"
_SOURCE_KEY = "_sws_proxy_source_uuid"
_FILE_GENERATION_KEY = "_sws_proxy_file_generation"
_SESSION_GENERATION_KEY = "_sws_proxy_session_generation"
_SCHEMA_KEY = "_sws_proxy_schema"
_MIGRATED_KEY = "_sws_proxy_migrated"
_MIGRATED_AT_KEY = "_sws_proxy_migrated_at_monotonic"
_EXACT_KEYS = (
    _OWNER_KEY,
    _ARTIFACT_KEY,
    _SOURCE_KEY,
    _FILE_GENERATION_KEY,
    _SESSION_GENERATION_KEY,
    _SCHEMA_KEY,
)
_MISSING = object()


def _namespace() -> dict[str, Any]:
    try:
        return bpy.app.driver_namespace
    except Exception:
        return globals()


def _ledger() -> dict[str, Any]:
    """Return a fresh exact-generation ledger; never adopt an older ledger."""
    namespace = _namespace()
    generation = _runtime_ledger.current_generation()
    value = namespace.get(_LEDGER_KEY)
    if not (
        isinstance(value, dict)
        and value.get('package_id') == PACKAGE_ID
        and value.get('owner_uuid') == OWNER_UUID
        and value.get('generation') == generation
        and value.get('module_identity') is _MODULE_IDENTITY
    ):
        value = {
            'package_id': PACKAGE_ID,
            'owner_uuid': OWNER_UUID,
            'generation': generation,
            'module_identity': _MODULE_IDENTITY,
            'file_generation': uuid.uuid4().hex,
            'records': {},
        }
        namespace[_LEDGER_KEY] = value
    value.setdefault('records', {})
    return value



def _valid_uuid_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    try:
        return str(uuid.UUID(value))
    except Exception:
        return ""


def _idprop_get(owner: Any, key: str, default: Any = _MISSING) -> Any:
    try:
        return owner.get(key, default)
    except Exception:
        try:
            return owner[key]
        except Exception:
            return default


def _idprop_set(owner: Any, key: str, value: Any) -> None:
    owner[key] = value


def _idprop_restore(owner: Any, key: str, value: Any) -> None:
    if value is _MISSING:
        try:
            del owner[key]
        except Exception:
            pass
    else:
        owner[key] = value


def _excluded_datablock(datablock: Any) -> bool:
    """Default-exclude linked, overridden, assets, fake users, and packed data."""
    try:
        if getattr(datablock, "library", None) is not None:
            return True
    except Exception:
        return True
    try:
        if getattr(datablock, "override_library", None) is not None:
            return True
    except Exception:
        return True
    try:
        if getattr(datablock, "asset_data", None) is not None:
            return True
    except Exception:
        return True
    try:
        if bool(getattr(datablock, "use_fake_user", False)):
            return True
    except Exception:
        return True
    try:
        if getattr(datablock, "packed_file", None) is not None:
            return True
    except Exception:
        return True
    try:
        packed_files = getattr(datablock, "packed_files", None)
        if packed_files is not None and len(packed_files) > 0:
            return True
    except Exception:
        pass
    return False


def record_generated_artifact(
    datablock: Any,
    *,
    artifact_uuid: str,
    source_uuid: str,
    file_generation: str | None = None,
    schema: str = CURRENT_SCHEMA,
) -> bool:
    """Record a newly generated Suite artifact after exact RNA tagging.

    This function never tags an existing unowned datablock.  Callers must have
    already created the datablock in the current operation and supplied all
    ownership properties.
    """
    generation = _runtime_ledger.current_generation()
    ledger = _ledger()
    expected_file_generation = str(file_generation or ledger.get("file_generation") or "")
    artifact = _valid_uuid_text(artifact_uuid)
    source = _valid_uuid_text(source_uuid)
    if not generation or not artifact or not source or not expected_file_generation:
        return False
    expected = {
        _OWNER_KEY: OWNER_UUID,
        _ARTIFACT_KEY: artifact,
        _SOURCE_KEY: source,
        _FILE_GENERATION_KEY: expected_file_generation,
        _SESSION_GENERATION_KEY: generation,
        _SCHEMA_KEY: str(schema),
    }
    if any(_idprop_get(datablock, key) != value for key, value in expected.items()):
        return False
    records = ledger.setdefault("records", {})
    if len(records) >= _MAX_LEDGER_RECORDS and artifact not in records:
        return False
    records[artifact] = {
        "datablock_identity": datablock,
        "artifact_uuid": artifact,
        "source_uuid": source,
        "owner_uuid": OWNER_UUID,
        "file_generation": expected_file_generation,
        "session_generation": generation,
        "schema": str(schema),
        "recorded_monotonic": time.monotonic(),
    }
    return True


def _record_matches_exact_ownership(record: Any) -> tuple[bool, str]:
    if not isinstance(record, dict):
        return False, "record-invalid"
    generation = _runtime_ledger.current_generation()
    if not generation or record.get("session_generation") != generation:
        return False, "generation-mismatch"
    ledger = _ledger()
    if record.get("file_generation") != ledger.get("file_generation"):
        return False, "file-generation-mismatch"
    if record.get("owner_uuid") != OWNER_UUID:
        return False, "owner-mismatch"
    artifact = _valid_uuid_text(record.get("artifact_uuid"))
    source = _valid_uuid_text(record.get("source_uuid"))
    if not artifact or not source:
        return False, "uuid-invalid"
    datablock = record.get("datablock_identity")
    if datablock is None or _excluded_datablock(datablock):
        return False, "excluded"
    expected = {
        _OWNER_KEY: OWNER_UUID,
        _ARTIFACT_KEY: artifact,
        _SOURCE_KEY: source,
        _FILE_GENERATION_KEY: str(record.get("file_generation") or ""),
        _SESSION_GENERATION_KEY: generation,
        _SCHEMA_KEY: str(record.get("schema") or ""),
    }
    for key, value in expected.items():
        if _idprop_get(datablock, key) != value:
            return False, f"rna-mismatch:{key}"
    if expected[_SCHEMA_KEY] not in {LEGACY_SCHEMA, CURRENT_SCHEMA}:
        return False, "schema-mismatch"
    return True, "owned"


def _candidate_records() -> Iterable[dict[str, Any]]:
    ledger = _ledger()
    records = ledger.get("records")
    if not isinstance(records, dict):
        return ()
    # Bounded snapshot; no global Blender datablock collection traversal occurs.
    return tuple(value for value in list(records.values())[:_MAX_LEDGER_RECORDS] if isinstance(value, dict))


def _migrate_records_transaction(records: Iterable[dict[str, Any]], *, dry_run: bool) -> Dict[str, int]:
    counts = {
        "examined": 0,
        "owned_candidates": 0,
        "migrated": 0,
        "excluded": 0,
        "rejected": 0,
        "rolled_back": 0,
        "datablocks_removed": 0,
        "raw_blend_writes": 0,
        "orphan_purges": 0,
        "dry_run": int(bool(dry_run)),
    }
    journal: list[tuple[Any, dict[str, Any], dict[str, Any], str]] = []
    candidates: list[dict[str, Any]] = []
    for record in records:
        counts["examined"] += 1
        valid, reason = _record_matches_exact_ownership(record)
        if not valid:
            if reason == "excluded":
                counts["excluded"] += 1
            else:
                counts["rejected"] += 1
            continue
        counts["owned_candidates"] += 1
        candidates.append(record)
    if dry_run:
        return counts
    try:
        for record in candidates:
            # Revalidate immediately before mutation to close the scan/commit gap.
            valid, _reason = _record_matches_exact_ownership(record)
            if not valid:
                raise RuntimeError("proxy ownership changed before commit")
            datablock = record["datablock_identity"]
            old = {
                _SCHEMA_KEY: _idprop_get(datablock, _SCHEMA_KEY),
                _MIGRATED_KEY: _idprop_get(datablock, _MIGRATED_KEY),
                _MIGRATED_AT_KEY: _idprop_get(datablock, _MIGRATED_AT_KEY),
            }
            journal.append((datablock, old, record, str(record.get("schema") or "")))
            _idprop_set(datablock, _SCHEMA_KEY, CURRENT_SCHEMA)
            _idprop_set(datablock, _MIGRATED_KEY, True)
            _idprop_set(datablock, _MIGRATED_AT_KEY, float(time.monotonic()))
            record["schema"] = CURRENT_SCHEMA
            # Post-write exact revalidation is mandatory.
            valid, _reason = _record_matches_exact_ownership(record)
            if not valid:
                raise RuntimeError("proxy ownership failed post-write validation")
            counts["migrated"] += 1
        return counts
    except Exception as original_error:
        rollback_errors: list[str] = []
        for datablock, old, record, old_record_schema in reversed(journal):
            try:
                for key, value in old.items():
                    _idprop_restore(datablock, key, value)
                record["schema"] = old_record_schema
                for key, value in old.items():
                    restored = _idprop_get(datablock, key)
                    if value is _MISSING:
                        if restored is not _MISSING:
                            raise RuntimeError(f"rollback retained {key}")
                    elif restored != value:
                        raise RuntimeError(f"rollback mismatch for {key}")
                if str(record.get("schema") or "") != old_record_schema:
                    raise RuntimeError("ledger schema rollback mismatch")
                counts["rolled_back"] += 1
            except Exception as rollback_error:
                rollback_errors.append(f"{type(rollback_error).__name__}: {rollback_error}")
        counts["migrated"] = 0
        if rollback_errors:
            raise RuntimeError(
                "proxy migration rollback incomplete: " + "; ".join(rollback_errors)
            ) from original_error
        raise


def cleanup_stale_blend_proxy_data(
    context=None,
    *,
    reason: str = "manual",
    throttle: float = 0.0,
    dry_run: bool = True,
) -> Dict[str, int]:
    """Audit/migrate only exact current-ledger Suite artifacts.

    ``context``, ``reason``, and ``throttle`` are retained for public API
    compatibility.  No timer or polling path exists.  The default is dry-run.
    """
    del context, reason, throttle
    global _LAST_COUNTS
    if not _runtime_ledger.current_generation():
        result = {
            "examined": 0,
            "owned_candidates": 0,
            "migrated": 0,
            "excluded": 0,
            "rejected": 0,
            "rolled_back": 0,
            "datablocks_removed": 0,
            "raw_blend_writes": 0,
            "orphan_purges": 0,
            "dry_run": int(bool(dry_run)),
        }
        _LAST_COUNTS = dict(result)
        return result
    result = _migrate_records_transaction(_candidate_records(), dry_run=bool(dry_run))
    _LAST_COUNTS = dict(result)
    return result


@persistent
def sws_blend_proxy_cleanup_load_pre(_dummy=None):
    """Rotate the file generation before Blender replaces the current Main.

    The bounded in-memory UUID ledger is file-local.  Clearing only these
    references prevents a previous file's records from authorizing mutation in
    the next file; no Blender datablock or user data is removed.
    """
    generation = _HANDLER_GENERATION
    if not generation or not _runtime_ledger.generation_matches(generation):
        return None
    ledger = _ledger()
    if ledger.get("generation") != generation or ledger.get("module_identity") is not _MODULE_IDENTITY:
        return None
    ledger["file_generation"] = uuid.uuid4().hex
    ledger["records"] = {}
    ledger.pop("last_transaction_failure", None)
    return None


@persistent
def sws_blend_proxy_cleanup_save_pre(_dummy=None):
    global _LAST_COUNTS
    generation = _HANDLER_GENERATION
    if not generation or not _runtime_ledger.generation_matches(generation):
        return None
    # Blender itself performs the subsequent .blend save.  This callback never
    # opens or rewrites Blender's active file path.  A transaction failure has already
    # rolled back every RNA mutation and is recorded as a failure, never as a
    # successful migration.
    try:
        cleanup_stale_blend_proxy_data(reason="save_pre", dry_run=False)
    except Exception as exc:
        _LAST_COUNTS = {
            "examined": int(_LAST_COUNTS.get("examined", 0)) if isinstance(_LAST_COUNTS, dict) else 0,
            "owned_candidates": int(_LAST_COUNTS.get("owned_candidates", 0)) if isinstance(_LAST_COUNTS, dict) else 0,
            "migrated": 0,
            "excluded": int(_LAST_COUNTS.get("excluded", 0)) if isinstance(_LAST_COUNTS, dict) else 0,
            "rejected": int(_LAST_COUNTS.get("rejected", 0)) if isinstance(_LAST_COUNTS, dict) else 0,
            "rolled_back": int(_LAST_COUNTS.get("rolled_back", 0)) if isinstance(_LAST_COUNTS, dict) else 0,
            "datablocks_removed": 0,
            "raw_blend_writes": 0,
            "orphan_purges": 0,
            "dry_run": 0,
            "failed": 1,
            "error_type": type(exc).__name__,
        }
        try:
            _ledger()["last_transaction_failure"] = {
                "generation": generation,
                "error_type": type(exc).__name__,
                "recorded_monotonic": time.monotonic(),
            }
        except Exception:
            pass
    return None



def _remove_exact_handler(handle: Any, handler_list: Any) -> None:
    try:
        while handle in handler_list:
            handler_list.remove(handle)
    except Exception:
        pass


def register() -> bool:
    global _REGISTERED, _HANDLER_GENERATION
    generation = _runtime_ledger.current_generation()
    if not generation:
        return False
    if _REGISTERED and _HANDLER_GENERATION == generation:
        return True
    unregister()
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    load_pre = getattr(handlers, "load_pre", None) if handlers is not None else None
    save_pre = getattr(handlers, "save_pre", None) if handlers is not None else None
    if load_pre is None or save_pre is None:
        return False
    _HANDLER_GENERATION = generation
    installed: list[tuple[Any, Any, str]] = []
    try:
        for handler_list, callback, region in (
            (load_pre, sws_blend_proxy_cleanup_load_pre, "LOAD_PRE"),
            (save_pre, sws_blend_proxy_cleanup_save_pre, "SAVE_PRE"),
        ):
            while callback in handler_list:
                handler_list.remove(callback)
            handler_list.append(callback)
            installed.append((handler_list, callback, region))
            if not _runtime_ledger.register_lease(
                feature="proxy-cleanup",
                space="APP",
                region=region,
                handle=callback,
                native_remover=_remove_exact_handler,
                remove_args=(handler_list,),
            ):
                raise RuntimeError(f"proxy cleanup {region} lease registration failed")
    except Exception:
        for handler_list, callback, _region in reversed(installed):
            _remove_exact_handler(callback, handler_list)
        _runtime_ledger.remove_feature_leases("proxy-cleanup", any_generation=False)
        _HANDLER_GENERATION = ""
        _REGISTERED = False
        raise
    _REGISTERED = True
    return True

def unregister() -> bool:
    global _REGISTERED, _HANDLER_GENERATION
    _runtime_ledger.remove_feature_leases("proxy-cleanup", any_generation=False)
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    load_pre = getattr(handlers, "load_pre", None) if handlers is not None else None
    save_pre = getattr(handlers, "save_pre", None) if handlers is not None else None
    if load_pre is not None:
        _remove_exact_handler(sws_blend_proxy_cleanup_load_pre, load_pre)
    if save_pre is not None:
        _remove_exact_handler(sws_blend_proxy_cleanup_save_pre, save_pre)
    _REGISTERED = False
    _HANDLER_GENERATION = ""
    return True

