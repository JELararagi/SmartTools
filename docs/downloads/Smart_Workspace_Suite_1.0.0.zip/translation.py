# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
import bpy

_JAPANESE_RE = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uff66-\uff9f]")
_ASCII_RE = re.compile(r"[A-Za-z]")
_SPACE_RE = re.compile(r"\s+")
_CAMEL_RE = re.compile(r"([a-z0-9])([A-Z])")

_TRANSLATION_CONTEXTS = (
    '', '*', 'Operator', 'Property', 'Tooltip', 'UI', 'Panel', 'Menu', 'Addon',
    'WindowManager', 'Preferences', 'Button', 'Label', 'Info',
)

# Exact phrase replacements used only as a last-resort fallback when a string was
# not present in the generated catalog.  Proper nouns intentionally remain in
# English when that is the natural Blender/add-on name.
_PHRASE_JA = {
    'Smart Workspace': 'Smart Workspace',
    'Smart Workspace': 'Smart Workspace',
    'Smart Tools': 'Smart Tools',
    'Screencast Keys': 'Screencast Keys',
    'Keyboard Layout Emulation': 'Keyboard Layout Emulation',
    'Script Launcher': 'Script Launcher',
    'Icon Viewer': 'Icon Viewer',
    '3D Viewport Pie Menus': '3D Viewport Pie Menus',
    '2D Pan View': '2D Pan View',
    # smarttools-ui-style: migration-alias
    'N-Panel': 'Nパネル',
    # smarttools-ui-style: migration-alias
    'N Panel': 'Nパネル',
    'Sidebar': 'サイドバー',
    'View3D': 'View3D',
    '3D View': '3Dビュー',
    'Add-on Preferences': 'アドオンプリファレンス',
    'User Preferences': 'ユーザープリファレンス',
    'Preferences': 'プリファレンス',
    'Keymap': 'キーマップ',
    'Hotbox': 'Hotbox',
    'Quick Access': 'クイックアクセス',
    'Quick Launcher': 'クイックランチャー',
    'Open Popup': 'ポップアップを開く',
    'Set Origin': '原点を設定',
    'Toggle Favorite': 'お気に入り切替',
    'Favorite Panels': 'お気に入りパネル',
    'Favorite Panel': 'お気に入りパネル',
    'Favorite Tabs': 'お気に入りタブ',
    'Favorite Tab': 'お気に入りタブ',
    'Apply Transforms': 'トランスフォームを適用',
    'Clear All Transforms': '全トランスフォームをクリア',
    'Mesh Delete': 'メッシュ削除',
    'Mesh Merge': 'メッシュ結合',
    'Mesh Flatten': 'メッシュ平坦化',
    'Object Display': 'オブジェクト表示',
    'Object Parenting': 'オブジェクト親子付け',
    'Object Relationships': 'オブジェクト関係',
    'Object Select': 'オブジェクト選択',
    'Sculpt Brush Select': 'スカルプトブラシ選択',
    'Editor Switch': 'エディター切替',
    'Proportional Edit': 'プロポーショナル編集',
}

_WORD_JA = {
    'about': '説明', 'active': 'アクティブ', 'add': '追加', 'addon': 'アドオン', 'align': '整列',
    'all': 'すべて', 'alpha': 'アルファ', 'animation': 'アニメーション', 'apply': '適用',
    'armature': 'アーマチュア', 'attribute': '属性', 'auto': '自動', 'axis': '軸', 'background': '背景',
    'base': 'ベース', 'blend': '.blend', 'bone': 'ボーン', 'bottom': '下', 'box': 'ボックス',
    'browser': 'ブラウザー', 'brush': 'ブラシ', 'camera': 'カメラ', 'cancel': 'キャンセル',
    'category': 'カテゴリー', 'center': '中央', 'children': '子', 'clear': 'クリア', 'close': '閉じる',
    'collapse': '折りたたみ', 'color': 'カラー', 'column': '列', 'console': 'コンソール',
    'constraint': 'コンストレイント', 'contents': '内容', 'controls': '操作', 'copy': 'コピー',
    'corner': '角', 'create': '作成', 'current': '現在', 'cursor': 'カーソル', 'custom': 'カスタム',
    'data': 'データ', 'debug': 'デバッグ', 'default': '既定', 'delete': '削除', 'deleted': '削除済み',
    'development': '開発用', 'display': '表示', 'down': '下へ', 'draw': '描画', 'edit': '編集',
    'editor': 'エディター', 'enable': '有効化', 'enabled': '有効', 'error': 'エラー', 'event': 'イベント',
    'experimental': '実験機能', 'export': '書き出し', 'failed': '失敗', 'file': 'ファイル',
    'filter': 'フィルター', 'focus': 'フォーカス', 'folder': 'フォルダー', 'font': 'フォント',
    'frame': 'フレーム', 'from': 'から', 'global': 'グローバル', 'guide': 'ガイド', 'header': 'ヘッダー',
    'height': '高さ', 'hide': '非表示', 'history': '履歴', 'hotkey': 'ホットキー', 'hotkeys': 'ホットキー',
    'icon': 'アイコン', 'id': 'ID', 'image': '画像', 'import': '読み込み', 'index': '番号',
    'info': '情報', 'input': '入力', 'interface': 'インターフェース', 'item': '項目', 'key': 'キー',
    'keyboard': 'キーボード', 'label': 'ラベル', 'last': '前回', 'launch': '起動', 'launcher': 'ランチャー',
    'layout': 'レイアウト', 'left': '左', 'list': '一覧', 'load': '読み込み', 'loaded': '読み込み済み',
    'location': '位置', 'lock': 'ロック', 'manager': '管理', 'mapping': '割り当て', 'margin': '余白',
    'material': 'マテリアル', 'menu': 'メニュー', 'middle': '中央', 'mode': 'モード', 'monitor': '監視',
    'mouse': 'マウス', 'move': '移動', 'name': '名前', 'navigation': 'ナビゲーション', 'new': '新規',
    'node': 'ノード', 'object': 'オブジェクト', 'offset': 'オフセット', 'open': '開く', 'operator': 'オペレーター',
    'operators': 'オペレーター', 'option': 'オプション', 'options': 'オプション', 'order': '順序',
    'origin': '原点', 'overlay': 'オーバーレイ', 'panel': 'パネル', 'pan': 'パン', 'parent': '親',
    'path': 'パス', 'pie': 'パイ', 'pin': 'ピン', 'pinned': '固定', 'popup': 'ポップアップ',
    'position': '位置', 'preset': 'プリセット', 'presets': 'プリセット', 'preview': 'プレビュー',
    'property': 'プロパティ', 'radius': '半径', 'recent': '最近使った', 'refresh': '更新', 'remove': '削除',
    'rename': 'リネーム', 'render': 'レンダー', 'reset': 'リセット', 'restore': '復元', 'revert': '解除',
    'right': '右', 'root': 'ルート', 'rotation': '回転', 'run': '実行', 'save': '保存', 'scale': 'スケール',
    'scene': 'シーン', 'screen': '画面', 'search': '検索', 'select': '選択', 'selected': '選択中',
    'settings': '設定', 'shading': 'シェーディング', 'shortcut': 'ショートカット', 'shortcuts': 'ショートカット',
    'show': '表示', 'size': 'サイズ', 'smooth': 'スムーズ', 'split': '分割', 'startup': '起動時',
    'status': '状態', 'sync': '同期', 'synchronize': '同期', 'tab': 'タブ', 'tabs': 'タブ',
    'target': 'ターゲット', 'text': 'テキスト', 'texture': 'テクスチャ', 'theme': 'テーマ', 'timer': 'タイマー',
    'toggle': '切替', 'tool': 'ツール', 'tools': 'ツール', 'top': '上', 'transform': 'トランスフォーム',
    'transforms': 'トランスフォーム', 'type': '種類', 'ui': 'UI', 'unload': 'アンロード', 'update': '更新',
    'up': '上へ', 'use': '使用', 'value': '値', 'view': 'ビュー', 'viewport': 'ビューポート',
    'visible': '表示', 'warning': '警告', 'width': '幅', 'window': 'ウィンドウ', 'wire': 'ワイヤー',
    'wireframe': 'ワイヤーフレーム', 'workspace': 'ワークスペース', 'x': 'X', 'y': 'Y', 'z': 'Z', 'zoom': 'ズーム',
}

_MANUAL_REVERSE = {
    'コピー': 'Copy', '説明': 'About', '概要': 'Overview', '使い方': 'How to Use', '設定': 'Settings',
    'ツール': 'Tools', 'メニュー': 'Menus', 'オペレーター': 'Operators', 'パネル': 'Panels',
    '補足': 'Note', '状態': 'Status', '有効': 'Enabled', '無効': 'Disabled', '読み込みエラー': 'Load Error',
    '設定描画に失敗': 'Settings draw failed', 'プロキシ描画に失敗': 'Proxy draw failed',
    'カテゴリー': 'Categories', '全タブ': 'All Tabs', 'パネル一覧': 'Panel List', '検索': 'Search',
}


def contains_japanese(text) -> bool:
    try:
        return bool(_JAPANESE_RE.search(str(text or "")))
    except Exception:
        return False


def contains_ascii(text) -> bool:
    try:
        return bool(_ASCII_RE.search(str(text or "")))
    except Exception:
        return False


def _interface_translation_enabled(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    for source in (ctx, getattr(bpy, 'context', None)):
        try:
            view = getattr(getattr(getattr(source, 'preferences', None), 'view', None), 'use_translate_interface', None)
            if view is False:
                return False
        except Exception:
            pass
    return True


def is_japanese(context=None) -> bool:
    if not _interface_translation_enabled(context):
        return False

    def _is_ja_code(value: str) -> bool:
        low = str(value or '').strip().lower()
        return bool(low in {'ja_jp', 'ja-jp', 'japanese'} or low.startswith('ja'))

    ctx = context or getattr(bpy, 'context', None)
    for source in (ctx, getattr(bpy, 'context', None)):
        try:
            language = str(getattr(getattr(getattr(source, 'preferences', None), 'view', None), 'language', '') or '').strip()
        except Exception:
            language = ''
        if language and language.upper() != 'DEFAULT':
            return _is_ja_code(language)

    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').strip()
        return _is_ja_code(locale)
    except Exception:
        return False


def _catalog_pairs() -> tuple[tuple[str, str], ...]:
    try:
        from .translation_catalog import TRANSLATIONS
    except Exception:
        try:
            from translation_catalog import TRANSLATIONS
        except Exception:
            TRANSLATIONS = ()
    pairs: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for en, ja in TRANSLATIONS:
        en = str(en or '').strip()
        ja = str(ja or '').strip()
        if not en or not ja or en == ja:
            continue
        key = (en, ja)
        if key in seen:
            continue
        seen.add(key)
        pairs.append(key)
    return tuple(pairs)


_CATALOG_PAIRS = _catalog_pairs()
_EN_TO_JA = {en: ja for en, ja in _CATALOG_PAIRS}
_JA_COUNTS: dict[str, int] = {}
for _en, _ja in _CATALOG_PAIRS:
    _JA_COUNTS[_ja] = _JA_COUNTS.get(_ja, 0) + 1
_JA_TO_EN = {ja: en for en, ja in _CATALOG_PAIRS if _JA_COUNTS.get(ja, 0) == 1}
_JA_TO_EN.update(_MANUAL_REVERSE)


def add_ui_pairs(table: dict) -> None:
    """Add a feature's own English/Japanese pairs to the text used in drawing."""
    for key, ja in table.items():
        en = str(key[1] if isinstance(key, tuple) else key).strip()
        ja = str(ja or '').strip()
        if en and ja and en != ja:
            _EN_TO_JA[en] = ja
            _JA_TO_EN.setdefault(ja, en)


def _native_ja(text: str) -> str | None:
    """Return Blender's own translation when it is a complete Japanese text."""
    try:
        value = bpy.app.translations.pgettext_iface(text)
    except Exception:
        return None
    if value != text and contains_japanese(value) and not re.search(r'[A-Za-z]{2}', value):
        return value
    return None


def error_text(exc, en: str, ja: str, context=None) -> str:
    """失敗の知らせの文。日本語設定では英語の例外文を出さない。"""
    message = str(exc or '').strip()
    if is_japanese(context):
        return f'{ja}: {message}' if message and contains_japanese(message) else ja
    return f'{en}: {message}' if message and not contains_japanese(message) else en


def ui_pair(en: str, ja: str, context=None) -> str:
    # Static RNA/class definitions must keep English as the source string.
    # Blender's translation table then displays Japanese only when the UI language is Japanese.
    if context is None:
        return str(en)
    return str(ja if is_japanese(context) else en)


def _split_bilingual_text(text: str):
    raw = str(text or '')
    cleaned = raw.strip()
    if not cleaned:
        return None

    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    # smarttools-ui-style: migration-alias
    if len(lines) == 2 and lines[0].upper().startswith('EN:') and lines[1].upper().startswith('JA:'):
        return lines[0][3:].strip(), lines[1][3:].strip()
    # smarttools-ui-style: migration-alias
    if len(lines) == 2 and lines[0].upper().startswith('JA:') and lines[1].upper().startswith('EN:'):
        return lines[1][3:].strip(), lines[0][3:].strip()

    if ' / ' not in raw:
        return None

    left, right = raw.split(' / ', 1)
    left = left.strip()
    right = right.strip()
    if not left or not right:
        return None

    left_is_ja = contains_japanese(left)
    right_is_ja = contains_japanese(right)
    if left_is_ja and not right_is_ja:
        return right, left
    if right_is_ja and not left_is_ja:
        return left, right
    return None


def _looks_internal_identifier(text: str) -> bool:
    s = str(text or '').strip()
    if not s:
        return True
    low = s.lower()
    if low.startswith(('wm.', 'view3d.', 'screen.', 'object.', 'mesh.', 'nptl.', 'bpy.', 'bl_', 'rna_', 'panview_')):
        return True
    if s.endswith(('.py', '.toml', '.json', '.txt')):
        return True
    if '/' in s or '\\' in s:
        return True
    if re.fullmatch(r'[A-Z0-9_]{3,}', s):
        return True
    if re.fullmatch(r'[A-Za-z0-9_.:-]+', s) and ('.' in s or '_' in s) and ' ' not in s:
        return True
    return False


def _humanize_english(text: str) -> str:
    s = str(text or '').strip()
    s = s.replace('_', ' ').replace('-', ' ')
    s = _CAMEL_RE.sub(r'\1 \2', s)
    return _SPACE_RE.sub(' ', s).strip()


def _auto_label_ja(text: str) -> str:
    s = _humanize_english(text)
    if not s:
        return str(text or '')
    # Phrase replacements first, longest first.
    for en in sorted(_PHRASE_JA, key=len, reverse=True):
        if en in s:
            s = s.replace(en, _PHRASE_JA[en])
    tokens = re.split(r'(\W+)', s)
    out: list[str] = []
    for token in tokens:
        if not token or re.fullmatch(r'\W+', token):
            out.append(token)
            continue
        low = token.lower()
        out.append(_WORD_JA.get(low, token))
    result = ''.join(out)
    if contains_japanese(result) and re.search(r'[A-Za-z]{2}', ''.join(out)) and any(
        token and re.search(r'[A-Za-z]{2}', token) and token.lower() not in _WORD_JA and token not in _PHRASE_JA.values()
        for token in tokens
    ):
        return str(text or '')
    result = result.replace('  ', ' ').strip()
    # Clean spaces between Japanese words left by token replacement.
    result = re.sub(r'(?<=[\u3040-\u30ff\u3400-\u9fff])\s+(?=[\u3040-\u30ff\u3400-\u9fff])', '', result)
    result = result.replace(' :', ':')
    return result or str(text or '')


def _auto_sentence_ja(text: str) -> str:
    # 内容の分からない定型の文に置き換えず、原文を残す。
    return str(text or '')


def auto_ja(text: str) -> str:
    raw = str(text or '').strip()
    if not raw or contains_japanese(raw) or _looks_internal_identifier(raw):
        return raw
    if raw in _EN_TO_JA:
        return _EN_TO_JA[raw]
    if len(raw) > 64 or any(ch in raw for ch in '.!?\n'):
        return _auto_sentence_ja(raw)
    return _auto_label_ja(raw)


def auto_en(text: str) -> str:
    raw = str(text or '').strip()
    if not raw or not contains_japanese(raw):
        return raw
    if raw in _JA_TO_EN:
        return _JA_TO_EN[raw]
    if len(raw) > 24 or any(ch in raw for ch in '。！？\n'):
        return 'This text explains a Smart Tools operation. Check the target and settings before using it.'
    return 'Smart Tools Item'


def _translate_dynamic_prefix(raw: str, context=None) -> str | None:
    japanese = is_japanese(context)
    if japanese:
        for en, ja in sorted(_EN_TO_JA.items(), key=lambda item: len(item[0]), reverse=True):
            if not en or len(en) < 3:
                continue
            for sep in (': ', ':', ' - ', ' – '):
                prefix = en + sep
                if raw.startswith(prefix):
                    return ja + sep + raw[len(prefix):]
    else:
        for ja, en in sorted(_JA_TO_EN.items(), key=lambda item: len(item[0]), reverse=True):
            if not ja or len(ja) < 2:
                continue
            for sep in (': ', ':', ' - ', ' – '):
                prefix = ja + sep
                if raw.startswith(prefix):
                    return en + sep + raw[len(prefix):]
    return None


def ui_text(text: str, context=None) -> str:
    raw = str(text or '')
    if raw == '':
        return raw

    pair = _split_bilingual_text(raw)
    if pair is not None:
        en, ja = pair
        return str(ja if is_japanese(context) else en)

    exact = None
    if is_japanese(context):
        exact = _EN_TO_JA.get(raw.strip())
        if exact:
            return raw.replace(raw.strip(), exact, 1) if raw != raw.strip() else exact
    else:
        exact = _JA_TO_EN.get(raw.strip())
        if exact:
            return raw.replace(raw.strip(), exact, 1) if raw != raw.strip() else exact

    prefixed = _translate_dynamic_prefix(raw, context)
    if prefixed is not None:
        return prefixed

    if is_japanese(context):
        if contains_ascii(raw) and not contains_japanese(raw):
            return _native_ja(raw) or auto_ja(raw)
        return raw

    if contains_japanese(raw):
        return auto_en(raw)
    return raw


def static_source_text(text: str) -> str:
    """Return a safe English source string for static RNA class/property registration."""
    raw = str(text or '')
    pair = _split_bilingual_text(raw)
    if pair is not None:
        return pair[0]
    stripped = raw.strip()
    if stripped in _JA_TO_EN:
        return _JA_TO_EN[stripped]
    if contains_japanese(raw):
        return auto_en(raw)
    return raw


class LocalizedUILayout:
    _LAYOUT_METHODS = {
        'row', 'column', 'box', 'split', 'column_flow', 'grid_flow', 'menu_pie',
        'panel', 'panel_prop',
    }

    def __init__(self, layout, context=None):
        object.__setattr__(self, '_layout', layout)
        object.__setattr__(self, '_context', context)

    def __setattr__(self, name, value):
        if name in {'_layout', '_context'}:
            object.__setattr__(self, name, value)
            return
        setattr(self._layout, name, value)

    def _is_layout_instance(self, value) -> bool:
        try:
            layout_type = getattr(bpy.types, 'UILayout', None)
            return layout_type is not None and isinstance(value, layout_type)
        except Exception:
            return False

    def _wrap(self, result):
        if result is None:
            return result
        if isinstance(result, LocalizedUILayout):
            return result
        if isinstance(result, tuple):
            return tuple(self._wrap(item) for item in result)
        if isinstance(result, list):
            return [self._wrap(item) for item in result]
        if self._is_layout_instance(result):
            return LocalizedUILayout(result, self._context)
        return result

    def __bool__(self):
        return bool(self._layout)

    def _localize_kwargs(self, method_name: str, kwargs: dict):
        localized = dict(kwargs)
        for key in ('text', 'heading', 'placeholder'):
            if key == 'text' and localized.get('translate') is False:
                continue
            if key in localized and localized[key] not in (None, ''):
                localized[key] = ui_text(localized[key], self._context)
        if method_name == 'prop':
            data = localized.pop('_smart_tools_prop_data', None)
            prop_name = localized.pop('_smart_tools_prop_name', None)
            # Preserve an explicit empty label. Blender UI code commonly uses
            # text="" for compact selectors, color swatches, preset indices,
            # and other fields where the label is drawn separately. Re-injecting
            # the RNA name here breaks those layouts, especially the 2D Pan View
            # settings panel. Only synthesize a localized label when the caller
            # omitted the text argument entirely.
            if 'text' not in localized:
                label = ''
                if data is not None and prop_name:
                    try:
                        label = str(data.bl_rna.properties[prop_name].name or '')
                    except Exception:
                        label = ''
                if label:
                    localized['text'] = ui_text(label, self._context)
        return localized

    def __getattr__(self, name):
        attr = getattr(self._layout, name)
        if not callable(attr):
            return attr

        def _wrapped(*args, **kwargs):
            local_kwargs = dict(kwargs)
            if name == 'prop' and len(args) >= 2:
                local_kwargs.setdefault('_smart_tools_prop_data', args[0])
                local_kwargs.setdefault('_smart_tools_prop_name', args[1])
            local_kwargs = self._localize_kwargs(name, local_kwargs)
            result = attr(*args, **local_kwargs)
            if name in self._LAYOUT_METHODS:
                return self._wrap(result)
            return result

        return _wrapped


def localized_layout(layout, context=None):
    if isinstance(layout, LocalizedUILayout):
        return layout
    try:
        layout_type = getattr(bpy.types, 'UILayout', None)
        if layout_type is not None and isinstance(layout, layout_type):
            return LocalizedUILayout(layout, context)
    except Exception:
        pass
    return layout



def _build_translation_dict() -> dict:
    table = {'ja_JP': {}, 'en_US': {}}

    def add(en: str, ja: str) -> None:
        en = str(en or '').strip()
        ja = str(ja or '').strip()
        if not en or not ja or en == ja:
            return
        for ctx in _TRANSLATION_CONTEXTS:
            table['ja_JP'][(ctx, en)] = ja
            table['en_US'].setdefault((ctx, ja), en)

    for en, ja in _CATALOG_PAIRS:
        add(en, ja)
    return table


translation_dict = _build_translation_dict()
