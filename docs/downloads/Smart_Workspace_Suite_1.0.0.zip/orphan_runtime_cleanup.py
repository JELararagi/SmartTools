# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Retain the legacy lookup surface without discovering unowned callbacks."""
_CACHE = {}


def orphan_functions(kind):
    return ()


def invalidate():
    _CACHE.clear()


mark_scan_required = invalidate
