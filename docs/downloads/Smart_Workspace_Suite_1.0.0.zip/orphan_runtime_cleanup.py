# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Compatibility no-op for retired orphan callback discovery.

The Suite never scans the Python heap or infers callback ownership from names.
Exact native-resource leases in ``runtime_ledger`` are the only cleanup source.
"""

from __future__ import annotations

_CACHE: dict[str, tuple[object, ...]] = {}


def mark_scan_required() -> None:
    _CACHE.clear()
    return None


def orphan_functions(kind: str) -> tuple[object, ...]:
    del kind
    return ()


def invalidate() -> None:
    _CACHE.clear()
    return None
