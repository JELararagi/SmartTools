# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable, Sequence

import bpy
from . import runtime_ledger as _runtime_ledger

# The former Window-menu SmartTools bootstrap is intentionally disabled because
# SmartTools is now hosted entirely in each suite's 3D View N-panel category.

# Compatibility entry points retained for callers from older builds. 1.1.129
# never changes other add-ons, user preferences, or user/add-on keymaps.

def _schedule_userpref_save() -> None:
    return None


def cleanup_stale_external_addons(*, save_preferences: bool = False) -> bool:
    del save_preferences
    return False


def cleanup_empty_user_interface_keymaps() -> bool:
    return False


def ensure_user_interface_keymap() -> bool:
    return True


def safe_register_class(cls: type) -> bool:
    """Register an exact class only; never purge/adopt a live same-name class."""
    if not isinstance(cls, type) or not _runtime_ledger.current_generation():
        return False
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='BOOTSTRAP_CLASS',
    )
    return bool(success)


def safe_unregister_class(cls: type) -> None:
    """Remove only the exact class recorded by the active generation."""
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return None
    _runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='BOOTSTRAP_CLASS',
    )
    return None


def safe_register_classes(classes: Iterable[type], *, registered: list[type] | None = None) -> tuple[type, ...]:
    out: list[type] = []
    for cls in classes:
        if safe_register_class(cls):
            out.append(cls)
            if isinstance(registered, list):
                registered.append(cls)
    return tuple(out)


def safe_unregister_classes(classes: Iterable[type]) -> None:
    for cls in reversed(tuple(classes)):
        safe_unregister_class(cls)


def iter_window_menu_classes(menu_names: Sequence[str] | None = None):
    del menu_names
    return iter(())


def iter_window_menu_draw_functions(menu_cls) -> tuple[object, ...]:
    del menu_cls
    return ()


def purge_window_menu_callbacks(menu_cls, matcher, *, keep=None) -> int:
    del menu_cls, matcher, keep
    return 0


def install_window_menu_entry(draw_fn, *, matcher=None, menu_names=None, install_all=False, redraw_area_types=None) -> tuple[str, ...]:
    del draw_fn, matcher, menu_names, install_all, redraw_area_types
    return ()


def remove_window_menu_entry(draw_fn=None, *, matcher=None, menu_names=None, redraw_area_types=None) -> None:
    del draw_fn, matcher, menu_names, redraw_area_types
    return None


def remove_window_menu_entry_if_unused(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_shared_window_menu_button_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def schedule_window_menu_refresh(*args, **kwargs) -> None:
    del args, kwargs
    return None


def tag_redraw_window_menu_areas(area_types: Sequence[str] | None = None) -> None:
    del area_types
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass
