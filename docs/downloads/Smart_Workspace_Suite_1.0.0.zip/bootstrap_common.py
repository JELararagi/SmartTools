"""Compatibility API for a sidebar-only add-on and exact, owned RNA registrations."""

import bpy

from . import runtime_ledger


def safe_register_class(cls):
    if not isinstance(cls, type) or not runtime_ledger.current_generation():
        return False
    owned, _registered_now = runtime_ledger.register_class_exact(
        cls, native_register=bpy.utils.register_class, native_unregister=bpy.utils.unregister_class,
        reason_prefix="BOOTSTRAP_CLASS",
    )
    return bool(owned)


def safe_unregister_class(cls):
    if isinstance(cls, type) and runtime_ledger.class_recorded_current(cls):
        runtime_ledger.unregister_class_exact(
            cls, native_unregister=bpy.utils.unregister_class, reason_prefix="BOOTSTRAP_CLASS",
        )


def safe_register_classes(classes, *, registered=None):
    accepted = tuple(cls for cls in classes if safe_register_class(cls))
    if isinstance(registered, list):
        registered.extend(accepted)
    return accepted


def safe_unregister_classes(classes):
    for cls in reversed(tuple(classes)):
        safe_unregister_class(cls)


def tag_redraw_window_menu_areas(area_types=None):
    manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(manager, "windows", ()):
        for area in getattr(window.screen, "areas", ()):
            if area.type == "VIEW_3D":
                area.tag_redraw()


def cleanup_stale_external_addons(*, save_preferences=False):
    return False


def cleanup_empty_user_interface_keymaps():
    return False


def ensure_user_interface_keymap():
    return True


def iter_window_menu_classes(menu_names=None):
    return iter(())


def iter_window_menu_draw_functions(menu_cls):
    return ()


def purge_window_menu_callbacks(menu_cls, matcher, *, keep=None):
    return 0


def install_window_menu_entry(draw_fn, *, matcher=None, menu_names=None,
                              install_all=False, redraw_area_types=None):
    return ()


def remove_window_menu_entry(draw_fn=None, *, matcher=None, menu_names=None, redraw_area_types=None):
    """Support older callers while leaving the Window menu intact."""


def remove_window_menu_entry_if_unused(*args, **kwargs):
    """Support older callers while leaving the Window menu intact."""


def schedule_shared_window_menu_button_refresh(*args, **kwargs):
    """Support older callers without scheduling Blender timers."""


def schedule_window_menu_refresh(*args, **kwargs):
    """Support older callers without scheduling Blender timers."""
