# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib.util
import platform
import sys
import traceback
from pathlib import Path
from typing import Any

import bpy
from . import feature_toggle as _feature_toggle
from . import runtime_ledger as _runtime_ledger

from . import registry as registry

_RECORDS: list[dict[str, Any]] = []

def clear_records() -> None:
    _RECORDS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    return package or 'smart_workspace_suite'


def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'


def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (src_dir / init_relpath).resolve() if src_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    package_dir = init_path.parent if init_path.name == '__init__.py' else src_dir
    return module_name, str(init_path), package_dir


def _purge_module_family(module_name: str, *, original_module_name: str = '') -> None:
    prefixes = [str(module_name or '').strip()]
    original_module_name = str(original_module_name or '').strip()
    if original_module_name:
        prefixes.append(original_module_name)
    prefixes = [value for value in prefixes if value]
    if not prefixes:
        return
    for loaded_name in list(sys.modules):
        for prefix in prefixes:
            if loaded_name == prefix or loaded_name.startswith(prefix + '.'):
                sys.modules.pop(loaded_name, None)
                break


def _load_module_from_spec(spec: dict[str, Any]):
    module_name, init_path_str, package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')

    original_module_name = str(spec.get('original_module_name') or '').strip()
    _purge_module_family(module_name, original_module_name=original_module_name)

    spec_obj = importlib.util.spec_from_file_location(
        module_name,
        str(init_path),
        submodule_search_locations=[str(package_dir)],
    )
    if spec_obj is None or spec_obj.loader is None:
        raise ImportError(f'Failed to create module spec for {init_path}')

    module = importlib.util.module_from_spec(spec_obj)
    sys.modules[module_name] = module
    spec_obj.loader.exec_module(module)
    return module


def _module_family_live_classes(module_prefix: str) -> dict[str, type]:
    result: dict[str, type] = {}
    prefix = str(module_prefix or '').strip()
    if not prefix:
        return result
    for module_name, module in tuple(sys.modules.items()):
        if module is None or not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        try:
            values = tuple(vars(module).values())
        except Exception:
            continue
        for cls in values:
            if not isinstance(cls, type) or getattr(cls, '__module__', '') != module_name:
                continue
            name = str(getattr(cls, '__name__', '') or '')
            if not name:
                continue
            if _runtime_ledger.class_has_valid_registered_rna(cls):
                publication_state, _published = _runtime_ledger.class_publication_state(cls)
                if publication_state not in {'ABSENT', 'EXACT'}:
                    continue
                result[f"{module_name}:{getattr(cls, '__qualname__', name)}"] = cls
    return result


def _capture_registered_classes(callable_obj):
    """Capture exact module-family class deltas without patching Blender APIs."""
    module_prefix = str(getattr(callable_obj, '__module__', '') or '').strip()
    before = _module_family_live_classes(module_prefix)
    callable_obj()
    after = _module_family_live_classes(module_prefix)
    return [cls for key, cls in after.items() if before.get(key) is not cls]


def _addon_preferences(context=None):
    try:
        from . import preferences as _suite_preferences
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None)
        if callable(get_settings):
            return get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None

def _enabled_in_preferences(spec: dict[str, Any], context=None) -> bool:
    return True

def _record_status_for_spec(spec: dict[str, Any], context=None) -> str:
    if not bool(spec.get('load', True)):
        return 'disabled'
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'idle'



def _blank_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        'spec': spec,
        'status': _record_status_for_spec(spec, context=getattr(bpy, 'context', None)),
        'module': None,
        'registered_classes': [],
        'error': '',
    }


def _reset_record_runtime(record: dict[str, Any], context=None) -> dict[str, Any]:
    record['module'] = None
    record['registered_classes'] = []
    record['error'] = ''
    record['status'] = _record_status_for_spec(record.get('spec') or {}, context=context)
    return record


def prepare_records(force: bool = False) -> list[dict[str, Any]]:
    if _RECORDS and not force:
        return get_records()
    clear_records()
    specs = registry.build_specs(force=True)
    for spec in specs:
        _RECORDS.append(_blank_record(spec))
    return get_records()


def _record_for_alias(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    for record in _RECORDS:
        spec = record.get('spec') or {}
        if str(spec.get('alias') or '').strip() == alias:
            return record
    return None


def _load_record(record: dict[str, Any]) -> dict[str, Any]:
    spec = record.get('spec') or {}
    if str(record.get('status') or '') != 'loaded':
        record['status'] = _record_status_for_spec(spec, context=getattr(bpy, 'context', None))
    status = str(record.get('status') or '')
    if status == 'loaded':
        return record
    if status in {'disabled', 'unsupported_platform'}:
        return record

    _reset_record_runtime(record, context=getattr(bpy, 'context', None))
    try:
        module = _load_module_from_spec(spec)
        record['module'] = module
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        captured: list[type] = []
        with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
            if callable(register_fn):
                captured = _capture_registered_classes(register_fn)
        record['registered_classes'] = captured
        record['status'] = 'loaded'
    except Exception as exc:
        _reset_record_runtime(record, context=getattr(bpy, 'context', None))
        record['status'] = 'failed'
        record['error'] = f'{exc}\n{traceback.format_exc()}'
    return record


def ensure_loaded(alias: str) -> dict[str, Any] | None:
    if not _RECORDS:
        prepare_records(force=True)
    record = _record_for_alias(alias)
    if record is None:
        return None
    return _load_record(record)


def ensure_unloaded(alias: str) -> dict[str, Any] | None:
    record = _record_for_alias(alias)
    if record is None:
        return None
    spec = record.get('spec') or {}
    status = str(record.get('status') or '')
    if status == 'loaded':
        module = record.get('module')
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                unregister_fn()
        except Exception:
            pass
        _purge_module_family(_module_name_for_spec(spec), original_module_name=str(spec.get('original_module_name') or ''))
        _reset_record_runtime(record, context=getattr(bpy, 'context', None))
    elif status == 'failed':
        _purge_module_family(_module_name_for_spec(spec), original_module_name=str(spec.get('original_module_name') or ''))
        _reset_record_runtime(record, context=getattr(bpy, 'context', None))
    return record


def register_all() -> list[dict[str, Any]]:
    """Prepare the integrated-tool inventory without importing every tool.

    Individual tools are loaded only when a retained always-on feature invokes
    them.  The removed quick-launcher metadata/catalog is not rebuilt here.
    """
    try:
        _feature_toggle.register_ui()
    except Exception:
        pass
    prepare_records(force=True)
    return get_records()


def unregister_all(*, clear_records: bool = True) -> None:
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        if alias:
            ensure_unloaded(alias)
        elif str(record.get('status') or '') == 'failed':
            _reset_record_runtime(record, context=getattr(bpy, 'context', None))
    if clear_records:
        clear_records_fn = globals().get('clear_records')
        if callable(clear_records_fn):
            clear_records_fn()
        registry.clear_cache()
    else:
        for record in _RECORDS:
            _reset_record_runtime(record, context=getattr(bpy, 'context', None))
