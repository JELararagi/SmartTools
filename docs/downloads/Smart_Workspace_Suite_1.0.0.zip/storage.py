# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import datetime
import json
import copy
import errno
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

from . import strict_json_contract as _strict_json
from . import settings_vfs as _vfs

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_workspace_suite'
USER_DATA_DIRNAME = 'user_data'
CENTRAL_SETTINGS_DIRNAME = 'Smart_Workspace_Suite'
CENTRAL_SETTINGS_FILENAME = 'Smart_Workspace_Suite.json'
CENTRAL_N_PANEL_STATE_SAVE_KEY = 'n_panel_state_save_enabled'
MUTABLE_SIDECAR_DIRNAME = 'sidecars'
VIEWPORT_OPTIMIZER_DIRNAME = 'viewport_optimizer'
LEGACY_VIEWPORT_OPTIMIZER_DIRNAME = 'smart_viewport_optimizer_plus'
_CENTRAL_SETTINGS_WRITING = False
_REGISTRATION_WRITE_GUARD_DEPTH = 0
_CENTRAL_WRITE_BATCH_DEPTH = 0
_CENTRAL_PAYLOAD_CACHE: dict[str, Any] | None = None
_CENTRAL_PAYLOAD_SIGNATURE: tuple[int, int] | None = None
_CENTRAL_PAYLOAD_VALIDATED = False
_LEGACY_STORAGE_CLEANED = False
_N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE: bool | None = None
_TIMER_REGISTRY_NAMESPACE_KEY = 'JELARARAGI_SMART_WORKSPACE_SUITE_TIMER_REGISTRY_V1'
_FALLBACK_TIMER_REGISTRY: dict[str, Any] = {}
if '_SESSION_TIMER_REGISTRY' not in globals():
    _SESSION_TIMER_REGISTRY: dict[str, Any] | None = None


def _timer_registry() -> dict[str, Any]:
    """Return the fixed-slot timer registry shared across same-session reloads."""
    global _SESSION_TIMER_REGISTRY
    if bpy is None:
        return _FALLBACK_TIMER_REGISTRY
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY)
        if not isinstance(registry, dict):
            registry = {}
            namespace[_TIMER_REGISTRY_NAMESPACE_KEY] = registry
            _SESSION_TIMER_REGISTRY = registry
        elif registry is _SESSION_TIMER_REGISTRY:
            namespace[_TIMER_REGISTRY_NAMESPACE_KEY] = registry
        return registry
    except Exception:
        return _FALLBACK_TIMER_REGISTRY


def release_quiescent_timer_registry() -> str:
    """Release only this module's exact empty registry after full teardown."""
    global _SESSION_TIMER_REGISTRY
    if bpy is None:
        return 'NO_BPY'
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY)
    except Exception:
        return 'NAMESPACE_UNAVAILABLE'
    if not isinstance(registry, dict) or registry is not _SESSION_TIMER_REGISTRY:
        return 'RETAINED_FOREIGN_OR_UNOWNED'
    if registry:
        return 'RETAINED_NONQUIESCENT'
    if namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY) is not registry:
        return 'RETAINED_IDENTITY_CHANGED'
    namespace.pop(_TIMER_REGISTRY_NAMESPACE_KEY, None)
    _SESSION_TIMER_REGISTRY = None
    return 'RELEASED'


def unregister_timer_slot(slot: str, *callbacks: Any) -> bool:
    """Unregister one bounded timer slot and verify that no candidate remains."""
    key = str(slot or '').strip()
    registry = _timer_registry()
    candidates = []
    if key:
        try:
            candidates.append(registry.pop(key, None))
        except Exception:
            pass
    candidates.extend(callbacks)
    seen = set()
    ok = True
    for callback in candidates:
        if not callable(callback):
            continue
        marker = id(callback)
        if marker in seen:
            continue
        seen.add(marker)
        if bpy is None:
            continue
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
            if bpy.app.timers.is_registered(callback):
                ok = False
        except Exception:
            ok = False
    if key:
        try:
            if registry.get(key) is not None:
                ok = False
        except Exception:
            ok = False
    return bool(ok)


def register_timer_slot(
    slot: str,
    callback: Any,
    *,
    first_interval: float,
    persistent: bool = False,
) -> bool:
    """Replace and register one timer callback under a stable bounded slot."""
    key = str(slot or '').strip()
    if not key or not callable(callback) or bpy is None:
        return False
    unregister_timer_slot(key, callback)
    try:
        bpy.app.timers.register(
            callback,
            first_interval=max(0.0, float(first_interval)),
            persistent=bool(persistent),
        )
        if not bool(bpy.app.timers.is_registered(callback)):
            return False
        _timer_registry()[key] = callback
        if _timer_registry().get(key) is not callback:
            raise RuntimeError('timer slot identity readback failed')
        return True
    except Exception:
        unregister_timer_slot(key, callback)
        return False


def _fsync_parent_directory(path: str | Path) -> None:
    """Sync the containing directory without masking supported-platform I/O errors."""
    target = Path(path)
    flags = getattr(os, 'O_RDONLY', 0) | getattr(os, 'O_DIRECTORY', 0)
    fd = None
    try:
        fd = os.open(str(target.parent), flags)
        os.fsync(fd)
    except AttributeError:
        return
    except OSError as exc:
        unsupported = {
            getattr(errno, 'EINVAL', -1),
            getattr(errno, 'ENOTSUP', -1),
            getattr(errno, 'EOPNOTSUPP', -1),
            getattr(errno, 'ENOSYS', -1),
            getattr(errno, 'EBADF', -1),
        }
        if os.name == 'nt' or exc.errno in unsupported:
            return
        raise
    finally:
        if fd is not None:
            os.close(fd)


def _atomic_replace_bytes(
    path: str | Path,
    payload: bytes,
    *,
    backup: bool = False,
) -> bool:
    """Durably replace one file through a unique sibling temporary file.

    Returns ``True`` when bytes changed and ``False`` when the existing target
    already contained the same payload.  A unique temporary file prevents two
    nested settings transactions from sharing ``<name>.tmp``.  When ``backup``
    is requested, the previous complete target is atomically published as
    ``<name>.bak`` before the new revision replaces it.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = bytes(payload)

    previous: bytes | None = None
    if target.exists():
        previous = target.read_bytes()
        if previous == raw:
            return False

    if backup and previous is not None:
        backup_path = target.with_name(target.name + '.bak')
        _atomic_replace_bytes(backup_path, previous, backup=False)

    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='wb',
            dir=str(target.parent),
            prefix=f'.{target.name}.',
            suffix='.tmp',
            delete=False,
        ) as handle:
            tmp_path = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(str(tmp_path), str(target))
        tmp_path = None
        _fsync_parent_directory(target)
        return True
    finally:
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except Exception:
                pass


def _atomic_replace_text(
    path: str | Path,
    text: str,
    *,
    encoding: str = 'utf-8',
    backup: bool = False,
) -> bool:
    return _atomic_replace_bytes(
        path,
        str(text).encode(encoding),
        backup=backup,
    )


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_workspace_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path




def blender_config_dir(create: bool = True) -> Path:
    """Return Blender's versioned user config directory."""
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', create=create) or ''
            except TypeError:
                try:
                    value = user_resource('CONFIG') or ''
                except Exception:
                    value = ''
            except Exception:
                value = ''
            if value:
                path = Path(value)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def central_settings_dir(create: bool = True) -> Path:
    path = blender_config_dir(create=create) / CENTRAL_SETTINGS_DIRNAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_settings_root(package: object | None = None, *, create: bool = True) -> Path:
    """Return the CONFIG-owned root for every mutable Workspace sidecar.

    Blender Extension package directories are release artifacts and must stay
    byte-for-byte immutable after installation.  Older builds used
    ``extension_path_user`` as a writable data directory; in an Extension that
    API resolves to the installed package itself.  Keep all compatibility
    sidecars below the suite's versioned CONFIG folder instead.  The canonical
    Smart_Workspace_Suite.json remains authoritative and mirrors these files.
    """
    pkg = str(package or PACKAGE_ID).strip() or PACKAGE_ID
    path = central_settings_dir(create=create) / MUTABLE_SIDECAR_DIRNAME
    if pkg != PACKAGE_ID:
        path = path / _clean_part(pkg)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _legacy_central_settings_paths() -> tuple[Path, ...]:
    """Return read-only migration inputs used by older Workspace builds."""
    root = blender_config_dir(create=False)
    return (
        root / 'Smart_WorkSpace_Suite' / 'Smart_WorkSpace_Suite.json',
        root / 'Smart_WorkSpace_Suite.json',
        root / CENTRAL_SETTINGS_FILENAME,
    )


def central_settings_path(create: bool = True) -> Path:
    path = central_settings_dir(create=create) / CENTRAL_SETTINGS_FILENAME
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _central_empty_payload() -> dict[str, Any]:
    """Return an in-memory central skeleton; do not publish defaults to disk."""
    return {
        'schema': _strict_json.CENTRAL_SCHEMA,
        'schema_version': _strict_json.CENTRAL_SCHEMA_VERSION,
        'addon': PACKAGE_ID,
        'settings_file': CENTRAL_SETTINGS_FILENAME,
        'blender_version': _blender_version(),
        CENTRAL_N_PANEL_STATE_SAVE_KEY: True,
        'files': {},
    }


def _central_file_signature(path: Path) -> tuple[int, int] | None:
    try:
        stat = path.stat()
        return int(stat.st_mtime_ns), int(stat.st_size)
    except Exception:
        return None


def _central_read_validated(path: Path) -> dict[str, Any]:
    """Strictly read one complete settings envelope (main file or its backup)."""
    stat = path.stat()
    if int(stat.st_size) > int(_strict_json.MAX_JSON_BYTES):
        raise _strict_json.CandidateInvalid('central-settings exceeds bounded JSON size')
    raw_bytes = path.read_bytes()
    if len(raw_bytes) > int(_strict_json.MAX_JSON_BYTES):
        raise _strict_json.CandidateInvalid('central-settings exceeds bounded JSON size')
    raw = _strict_json.strict_json_loads(
        raw_bytes.decode('utf-8', errors='strict'),
        source='central-settings',
    )
    data, _legacy = _strict_json.validate_central_payload(
        raw, allow_legacy=False, source='central-settings'
    )
    return data


def _central_backup_path() -> Path:
    path = central_settings_path(create=False)
    return path.with_name(path.name + '.bak')


def _central_load_cached_payload() -> dict[str, Any]:
    """Load one strictly validated central envelope per explicit lifecycle.

    Missing or corrupt files yield an in-memory default with a *false* validation
    marker.  That marker prevents registration-time RNA defaults from becoming
    authority.  A corrupt main file is preserved for diagnosis and the previous
    valid file (``Smart_Workspace_Suite.json.bak``) is used instead.  Former
    sidecar files are imported once (read only) by :mod:`settings_vfs`.
    """
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    if isinstance(_CENTRAL_PAYLOAD_CACHE, dict):
        return _CENTRAL_PAYLOAD_CACHE
    path = central_settings_path(create=False)
    data = None
    validated = False
    if path.exists():
        try:
            data = _central_read_validated(path)
            validated = True
        except Exception:
            try:
                _strict_json.preserve_corrupt_file(path)
            except Exception:
                pass
    if data is None:
        backup = _central_backup_path()
        if backup.exists():
            try:
                data = _central_read_validated(backup)
                validated = True
            except Exception:
                data = None
    if data is None:
        data = _central_empty_payload()
    if not isinstance(data.get('files'), dict):
        data['files'] = {}
    _CENTRAL_PAYLOAD_CACHE = data
    _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(path)
    _CENTRAL_PAYLOAD_VALIDATED = validated
    try:
        changed = _vfs.migrate_loaded_payload(data)
    except Exception:
        changed = False
    _vfs.note_loaded(tuple(data['files']))
    if changed:
        _vfs.mark_dirty()
        _vfs.schedule_flush()
    return _CENTRAL_PAYLOAD_CACHE


def central_payload_validated() -> bool:
    _central_load_cached_payload()
    return bool(_CENTRAL_PAYLOAD_VALIDATED)


def _central_peek_payload() -> dict[str, Any]:
    """Return a read-only-by-contract cached payload.

    Internal callers using this helper must not mutate the returned graph.
    It avoids copying large mirrored Viewport/N-panel files for simple policy
    checks and settings reads.
    """
    return _central_load_cached_payload()


def _central_read_payload() -> dict[str, Any]:
    """Return a detached payload suitable for an update transaction."""
    return copy.deepcopy(_central_load_cached_payload())


def registration_write_guard_active() -> bool:
    """Return whether internal RNA registration is write-protected.

    Update callbacks can fire hundreds of times while optional PropertyGroups
    are being registered.  They are internal materialisation events, not user
    changes, so persistence callers should return before collecting or copying
    the complete canonical JSON graph.
    """
    return _REGISTRATION_WRITE_GUARD_DEPTH > 0


def begin_registration_write_guard() -> dict[str, Any]:
    """Freeze the canonical N-panel profile during RNA registration."""
    global _REGISTRATION_WRITE_GUARD_DEPTH
    payload = _central_read_payload()
    _REGISTRATION_WRITE_GUARD_DEPTH += 1
    return payload


def begin_central_write_batch() -> None:
    """Block nested central mirror writes without blocking sidecar serializers."""
    global _CENTRAL_WRITE_BATCH_DEPTH
    _CENTRAL_WRITE_BATCH_DEPTH += 1


def end_central_write_batch() -> None:
    global _CENTRAL_WRITE_BATCH_DEPTH
    _CENTRAL_WRITE_BATCH_DEPTH = max(0, _CENTRAL_WRITE_BATCH_DEPTH - 1)
    if _CENTRAL_WRITE_BATCH_DEPTH == 0:
        _vfs.schedule_flush()


def central_write_batch_active() -> bool:
    """Return whether mirror publication is owned by an outer transaction."""
    return _CENTRAL_WRITE_BATCH_DEPTH > 0


def end_registration_write_guard() -> None:
    global _REGISTRATION_WRITE_GUARD_DEPTH
    _REGISTRATION_WRITE_GUARD_DEPTH = max(0, _REGISTRATION_WRITE_GUARD_DEPTH - 1)
    if _REGISTRATION_WRITE_GUARD_DEPTH == 0:
        # Registration may discover legacy mirrored layout snapshots while the
        # canonical file is intentionally write-protected.  Finish that finite
        # migration immediately after the guard opens instead of marking it as
        # completed without publishing the compact payload.
        try:
            cleanup_legacy_storage_dirs(force=True)
        except Exception:
            pass
        _vfs.schedule_flush()


def _central_signature_changed() -> bool:
    return _central_file_signature(central_settings_path(create=False)) != _CENTRAL_PAYLOAD_SIGNATURE


def _central_disk_payload() -> dict[str, Any] | None:
    """Read the published file again (another Blender process may have written it)."""
    for candidate in (central_settings_path(create=False), _central_backup_path()):
        if not candidate.exists():
            continue
        try:
            return _central_read_validated(candidate)
        except Exception:
            continue
    return None


def _embedded_current(files: Any) -> dict[str, Any] | None:
    """Return the validated N-panel current settings member or ``None``."""
    if not isinstance(files, dict):
        return None
    value = files.get(_vfs.CURRENT_KEY)
    if not isinstance(value, dict):
        return None
    try:
        payload, legacy = _strict_json.validate_current_payload(
            value, allow_legacy=False, source='central-current'
        )
    except Exception:
        return None
    return None if legacy else payload


def _int_or_zero(value: Any) -> int:
    try:
        return int(value) if isinstance(value, int) and not isinstance(value, bool) else 0
    except Exception:
        return 0


def _next_central_revision() -> int:
    """Return max(known revision)+1 over the cache and a changed file on disk."""
    cache = _central_peek_payload()
    revisions = [0, _int_or_zero(cache.get('revision'))]
    current = _embedded_current(cache.get('files'))
    if current is not None:
        revisions.append(_int_or_zero(current.get('revision')))
    if _central_signature_changed():
        disk = _central_disk_payload()
        if isinstance(disk, dict):
            revisions.append(_int_or_zero(disk.get('revision')))
    return max(revisions) + 1


_NO_JOURNAL = object()


def _central_publish_cache(verified: dict[str, Any], *, journal: Any = _NO_JOURNAL) -> None:
    """Adopt a verified publication as the in-memory settings graph."""
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    if not isinstance(verified.get('files'), dict):
        verified['files'] = {}
    _CENTRAL_PAYLOAD_CACHE = verified
    _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(central_settings_path(create=False))
    _CENTRAL_PAYLOAD_VALIDATED = True
    _vfs.note_published(tuple(verified['files']))
    _vfs.forget_session_values(verified['files'])
    if journal is not _NO_JOURNAL:
        # A full commit supersedes the crash journal; keep it in memory until the
        # caller retires it, and publish it again only when it is still present.
        verified['files'][_vfs.LIVE_STATE_KEY] = journal
        _vfs.mark_key_dirty(_vfs.LIVE_STATE_KEY)
        _vfs.schedule_flush()


def _durable_publish(payload: dict[str, Any], revision: int, writer: str) -> dict[str, Any]:
    _strict_json.durable_write_json(
        central_settings_path(create=True),
        payload,
        validator=_strict_json.validate_central_payload,
        backup=True,
        expected_revision=revision,
        expected_writer_id=writer,
        expected_checksum=payload['payload_checksum'],
    )
    verified = _strict_json.last_durable_write_result()
    if not isinstance(verified, dict):
        raise _strict_json.ContractError('central durable readback unavailable')
    return verified


def _central_write_payload(data: dict[str, Any]) -> bool:
    """Publish the one settings file ``Smart_Workspace_Suite.json``.

    Former sidecars are members of ``files``.  The N-panel current settings keep
    their revision/writer/checksum unless their content changes (so a crash
    journal based on them stays applicable); the envelope revision always equals
    the embedded current revision.  The previous valid file becomes
    ``Smart_Workspace_Suite.json.bak``.  ``False`` means an owner transaction or
    registration currently holds writes and the caller keeps its dirty state;
    I/O, permission, replace and readback failures propagate.
    """
    global _CENTRAL_SETTINGS_WRITING
    if (
        _CENTRAL_SETTINGS_WRITING
        or _REGISTRATION_WRITE_GUARD_DEPTH > 0
        or _CENTRAL_WRITE_BATCH_DEPTH > 0
    ):
        return False
    if not isinstance(data, dict):
        raise TypeError('central payload must be a dict')
    _CENTRAL_SETTINGS_WRITING = True
    try:
        enabled = _strict_json.strict_bool(
            data.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
        base = copy.deepcopy(data)
        files = _layer_files(base.get('files'))
        base['files'] = files
        _vfs.overlay_pending(files)
        current = _embedded_current(files)
        cached = _embedded_current(_central_peek_payload().get('files'))
        if cached is not None and (
            current is None
            or _int_or_zero(cached.get('revision')) > _int_or_zero(current.get('revision'))
        ):
            # A caller's detached copy never drops or rolls back the authority.
            current = cached
        if _central_signature_changed():
            disk = _central_disk_payload()
            disk_current = _embedded_current(disk.get('files')) if isinstance(disk, dict) else None
            if disk_current is not None and (
                current is None
                or _int_or_zero(disk_current.get('revision')) > _int_or_zero(current.get('revision'))
            ):
                current = disk_current
        base[_vfs.LAYOUT_FIELD] = _vfs.LAYOUT_MARK
        base['blender_version'] = _blender_version()
        if current is not None:
            files[_vfs.CURRENT_KEY] = current
            revision = _int_or_zero(current.get('revision'))
            writer = str(current.get('writer_id') or '')
            payload = _strict_json.finalize_central_payload(
                base, revision=revision, writer_id=writer, state_save_enabled=enabled,
            )
            if payload['files'][_vfs.CURRENT_KEY].get('payload_checksum') != current.get('payload_checksum'):
                # The policy changed the N-panel content: that is a new revision.
                revision = _next_central_revision()
                writer = _contract_writer_id()
                payload = _strict_json.finalize_central_payload(
                    base, revision=revision, writer_id=writer, state_save_enabled=enabled,
                )
        else:
            files.pop(_vfs.CURRENT_KEY, None)
            revision = max(1, _int_or_zero(_central_peek_payload().get('revision')))
            writer = _contract_writer_id()
            payload = _strict_json.finalize_central_payload(
                base, revision=revision, writer_id=writer, state_save_enabled=enabled,
            )
        verified = _durable_publish(payload, revision, writer)
        _central_publish_cache(verified)
        return True
    finally:
        _CENTRAL_SETTINGS_WRITING = False


def flush_settings() -> bool:
    """Publish staged settings members now (file/exit boundaries, unregister)."""
    try:
        return bool(_vfs.flush())
    except Exception:
        return False


def read_previous_current_candidate():
    """Return the N-panel current held by ``Smart_Workspace_Suite.json.bak``."""
    backup = _central_backup_path()
    data = _central_read_validated(backup)
    current = _embedded_current(data.get('files'))
    if current is None:
        raise _strict_json.CandidateInvalid('settings backup holds no N-panel current settings')
    return _strict_json.Candidate(
        source='backup',
        path=str(backup),
        payload=current,
        revision=int(current['revision']),
        writer_id=str(current['writer_id']),
        checksum=str(current['payload_checksum']),
        mtime_ns=0,
    )


def install_recovered_current(payload: dict[str, Any]) -> bool:
    """Store a recovered (migrated) N-panel authority in the settings file."""
    current, _legacy = _strict_json.validate_current_payload(
        payload, allow_legacy=False, source='recovered-current'
    )
    current['authority'] = 'central'
    current['payload_checksum'] = _strict_json.payload_checksum(current)
    if (
        _CENTRAL_SETTINGS_WRITING
        or _REGISTRATION_WRITE_GUARD_DEPTH > 0
        or _CENTRAL_WRITE_BATCH_DEPTH > 0
    ):
        # Former builds repaired the primary file even while registration held
        # the central file.  Keep the recovered authority in the cached
        # envelope; the settings flush publishes it once writes are open.
        cached = _central_peek_payload()
        files = cached.get('files')
        if not isinstance(files, dict):
            files = {}
            cached['files'] = files
        for key in [key for key in files if _strict_json.is_current_key(key)]:
            files.pop(key, None)
        files[_vfs.CURRENT_KEY] = current
        _vfs.mark_key_dirty(_vfs.CURRENT_KEY)
        _vfs.schedule_flush()
        return True
    data = _central_read_payload()
    files = data.get('files')
    if not isinstance(files, dict):
        files = {}
        data['files'] = files
    for key in [key for key in files if _strict_json.is_current_key(key)]:
        files.pop(key, None)
    files[_vfs.CURRENT_KEY] = current
    return bool(_central_write_payload(data))


def n_panel_state_save_enabled(default: bool = True) -> bool:
    """Return strict policy; missing/invalid values always migrate to ``True``."""
    del default
    if isinstance(_N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE, bool):
        return _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE
    try:
        payload = _central_peek_payload()
        return _strict_json.strict_bool(
            payload.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
    except Exception:
        return True


def set_n_panel_state_save_runtime_policy(enabled: bool | None) -> None:
    """Update the in-session policy without rewriting the central JSON graph."""
    global _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE
    _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE = enabled if isinstance(enabled, bool) else None


def set_n_panel_state_save_enabled(enabled: bool) -> bool:
    """Persist a strict Boolean policy and return verified success."""
    value = _strict_json.strict_bool(enabled, field=CENTRAL_N_PANEL_STATE_SAVE_KEY)
    set_n_panel_state_save_runtime_policy(value)
    payload = _central_read_payload()
    payload[CENTRAL_N_PANEL_STATE_SAVE_KEY] = value
    return bool(_central_write_payload(payload))




def _normalize_central_storage_key(key: str) -> str:
    """Normalize central mirror keys and permanently retire legacy tool folders."""
    try:
        text = str(key or '').replace('\\', '/').strip('/')
    except Exception:
        return ''
    if not text:
        return ''
    parts = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    if not parts:
        return ''
    normalized = []
    for piece in parts:
        if piece == LEGACY_VIEWPORT_OPTIMIZER_DIRNAME:
            piece = VIEWPORT_OPTIMIZER_DIRNAME
        normalized.append(piece)
    return '/'.join(normalized)








def cleanup_legacy_storage_dirs(*, force: bool = False) -> None:
    """Mark the finite migration check complete without deleting user data.

    Historical builds recursively removed a legacy config directory and pruned
    central entries.  1.1.129 keeps those bytes for diagnosis/import and performs
    no automatic file or directory deletion during registration.
    """
    del force
    global _LEGACY_STORAGE_CLEANED
    _LEGACY_STORAGE_CLEANED = True





_SENTINEL = object()


def central_read_json_for_path(path: str | Path, default: Any = None) -> Any:
    """Return the settings member stored for ``path`` (``default`` when absent)."""
    if not _vfs.key_of(path):
        return default
    return _vfs.read(path, default)


def same_json_ignoring_saved_at(a: Any, b: Any) -> bool:
    """同じ内容か（毎回変わる saved_at だけは無視）。変わっていない保存を省くための比較。"""
    def _norm(x: Any) -> str:
        if isinstance(x, dict) and 'saved_at' in x:
            x = {k: v for k, v in x.items() if k != 'saved_at'}
        return json.dumps(x, sort_keys=True, ensure_ascii=False, default=str)
    try:
        return _norm(a) == _norm(b)
    except Exception:
        return False


def mirror_json_file(path: str | Path, data: Any, *, force: bool = False) -> bool:
    """Stage one settings member inside ``Smart_Workspace_Suite.json``.

    No sidecar file is written.  The settings flush (one 0.5 s timer or a
    load/save/exit boundary) publishes the whole file once.  With N-panel State
    Save off and ``force`` false the value lives for this session only, as the
    former physical sidecar did until the next startup restore.  During
    registration or an owner batch the value is staged but ``False`` is returned
    so that callers keep their retry state, as before.
    """
    if not _vfs.key_of(path):
        # Explicit snapshots stay physical files; nothing is mirrored for them.
        return True
    _vfs.write(path, data, force=force)
    return not (_REGISTRATION_WRITE_GUARD_DEPTH > 0 or _CENTRAL_WRITE_BATCH_DEPTH > 0)


def unmirror_json_file(path: str | Path, *, force: bool = False) -> bool:
    """Compatibility no-op: physical snapshots are never mirrored any more."""
    del path, force
    return True





def _parse_saved_at(value: Any) -> None:
    """Compatibility stub: wall-clock timestamps never determine authority."""
    del value
    return None


def _json_saved_at_from_path(path: Path) -> None:
    del path
    return None


def _json_saved_at_from_value(value: Any) -> None:
    del value
    return None





def restore_central_settings_to_files(*, force: bool = False) -> bool:
    """Return to the published settings members (session-only values end).

    Settings live only inside ``Smart_Workspace_Suite.json``; there is no
    sidecar to rewrite.  Values held for this session while N-panel State Save
    was off (or written during registration) are discarded, exactly as the
    former restore replaced such sidecars with the published copy.
    """
    del force
    _central_load_cached_payload()
    _vfs.clear_session_values()
    return True


def _layer_files(files: Any) -> dict[str, Any]:
    """Map member names to layer keys; drop physical snapshots.

    Pre-layer names (``config/<rel>.json`` and ``user_data/<rel>.json``) are
    renamed; an existing layer key wins over an old spelling of the same key.
    """
    result: dict[str, Any] = {}
    if not isinstance(files, dict):
        return result
    old_spellings: list[tuple[str, Any]] = []
    for raw_key, value in files.items():
        text = str(raw_key)
        if _strict_json.is_current_key(text):
            if text == _vfs.CURRENT_KEY:
                result[_vfs.CURRENT_KEY] = value
            else:
                old_spellings.append((_vfs.CURRENT_KEY, value))
            continue
        key = _vfs.migrate_key(text)
        if not key or _vfs.is_physical_key(key):
            continue
        if key == text:
            result[key] = value
        else:
            old_spellings.append((key, value))
    for key, value in old_spellings:
        result.setdefault(key, value)
    return result


def collect_json_storage_into_payload(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return one detached settings envelope including every staged member.

    Former builds collected physical sidecars here.  The settings members now
    live in the cached envelope, so the cached members and this session's
    unpublished values (N-panel State Save off) are overlaid on ``payload``.
    The N-panel current settings of ``payload`` are kept.
    """
    try:
        cleanup_legacy_storage_dirs()
    except Exception:
        pass
    payload = dict(payload or _central_read_payload())
    files = _layer_files(payload.get('files'))
    cached = _central_peek_payload().get('files')
    if isinstance(cached, dict):
        for key, value in cached.items():
            if key != _vfs.CURRENT_KEY:
                files[key] = copy.deepcopy(value)
    _vfs.overlay_session(files)
    payload['files'] = files
    return payload


def snapshot_json_storage_to_central(*, force: bool = False) -> bool:
    """Mirror explicit JSON files with one strict, verified central replace."""
    if not force and not n_panel_state_save_enabled(True):
        return False
    return bool(_central_write_payload(collect_json_storage_into_payload()))


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    pkg = str(package_id or PACKAGE_ID).strip() or PACKAGE_ID
    root = mutable_settings_root(pkg, create=create)
    clean = _clean_parts(parts)
    # Historical callers passed the package ID positionally even though this
    # function already selected that package.  Treat it as an identifier, not
    # as a second nested folder (the old behavior produced
    # smart_workspace_suite/smart_workspace_suite_config.json in the package).
    if clean and clean[0] in {pkg, PACKAGE_ID}:
        clean = clean[1:]
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = mutable_settings_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = mutable_settings_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> bool:
    path = user_data_file(subdir, filename, create_parent=True)
    return bool(atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=True))


def read_json(path: str | Path, default: Any = None) -> Any:
    if _vfs.key_of(path):
        return _vfs.read(path, default)
    try:
        return _strict_json.read_json_document(Path(path))
    except Exception:
        return default


def atomic_write_text(
    path: str | Path,
    text: str,
    *,
    encoding: str = 'utf-8',
    mirror: bool = True,
    backup: bool = False,
) -> bool:
    """Write one file; a settings member is staged in the one settings file.

    ``mirror=False`` (former "this sidecar only") stores the member even while
    N-panel State Save is off.  Explicit snapshots and exports stay physical
    files written through a unique temporary file with readback.
    """
    serialized = str(text)
    if _vfs.key_of(path):
        parsed = _strict_json.strict_json_loads(
            serialized or '{}', source=f'settings-member:{_vfs.key_of(path)}'
        )
        return bool(_vfs.write(path, parsed, force=not mirror))
    target = Path(path)
    _atomic_replace_text(
        target,
        serialized,
        encoding=encoding,
        backup=backup,
    )
    # Mandatory readback: a successful os.replace is not enough when AV or
    # filesystem filters can alter/withhold the final bytes.
    if target.read_text(encoding=encoding) != serialized:
        raise OSError(f'atomic readback mismatch: {target}')
    return True


def atomic_write_json(
    path: str | Path,
    data: Any,
    *,
    indent: int = 2,
    ensure_ascii: bool = False,
    sort_keys: bool = False,
    mirror: bool = True,
    backup: bool = False,
) -> bool:
    serialized = json.dumps(
        data,
        indent=indent,
        ensure_ascii=ensure_ascii,
        sort_keys=sort_keys,
        allow_nan=False,
    )
    return atomic_write_text(
        path,
        serialized,
        encoding='utf-8',
        mirror=mirror,
        backup=backup,
    )


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy legacy data into CONFIG without deleting or modifying its source.

    ``remove_legacy`` remains in the public call signature for compatibility but
    is intentionally ignored.  Migration must never delete user data, another
    Suite's data, or a package-local diagnostic source.
    """
    del remove_legacy
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        return bool(target.is_file() and target.stat().st_size == legacy.stat().st_size)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 1.1.130 strict N-panel authority contract
# ---------------------------------------------------------------------------
_CONTRACT_WRITER_NAMESPACE_KEY = 'JELARARAGI_SMART_WORKSPACE_SUITE_JSON_WRITER_ID_V1'
_FALLBACK_CONTRACT_WRITER_ID = ''
_LAST_N_PANEL_COMMIT_RESULT: dict[str, Any] | None = None


def _contract_writer_id() -> str:
    global _FALLBACK_CONTRACT_WRITER_ID
    if bpy is not None:
        try:
            namespace = bpy.app.driver_namespace
            value = namespace.get(_CONTRACT_WRITER_NAMESPACE_KEY)
            if not isinstance(value, str) or not value.strip():
                value = _strict_json.new_writer_id(PACKAGE_ID)
                namespace[_CONTRACT_WRITER_NAMESPACE_KEY] = value
            return value
        except Exception:
            pass
    if not _FALLBACK_CONTRACT_WRITER_ID:
        _FALLBACK_CONTRACT_WRITER_ID = _strict_json.new_writer_id(PACKAGE_ID)
    return _FALLBACK_CONTRACT_WRITER_ID


def invalidate_central_cache() -> None:
    """Drop the cached envelope; staged members are published first."""
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    if isinstance(_CENTRAL_PAYLOAD_CACHE, dict) and _vfs.dirty():
        try:
            published = bool(_vfs.flush())
        except Exception:
            published = False
        if not published:
            # Keep unpublished settings in memory; the next boundary retries.
            return
    _CENTRAL_PAYLOAD_CACHE = None
    _CENTRAL_PAYLOAD_SIGNATURE = None
    _CENTRAL_PAYLOAD_VALIDATED = False


def n_panel_current_settings_key(path: str | Path | None = None) -> str:
    """Return the settings member that holds the N-panel current settings."""
    del path
    return _vfs.CURRENT_KEY


def _current_candidate(payload: dict[str, Any], source: str, path: Path) -> Any:
    return _strict_json.Candidate(
        source=source,
        path=str(path),
        payload=copy.deepcopy(payload),
        revision=int(payload['revision']),
        writer_id=str(payload['writer_id']),
        checksum=str(payload['payload_checksum']),
        mtime_ns=0,
    )


def resolve_n_panel_current_settings(path: str | Path | None = None, *, repair_primary: bool = True):
    """Return the N-panel authority held by ``Smart_Workspace_Suite.json``.

    The embedded member is the primary.  When the file is missing or damaged,
    the previous valid file ``Smart_Workspace_Suite.json.bak`` is used (the
    loader already falls back to it).  Defaults never become authority.
    """
    del path, repair_primary
    current = _embedded_current(_central_peek_payload().get('files'))
    if current is not None:
        payload = copy.deepcopy(current)
        payload['authority'] = 'primary'
        candidate = _current_candidate(current, 'primary', central_settings_path(create=False))
        return _strict_json.AuthorityResult(payload, 'primary', False, (candidate,), ())
    invalid = ['primary:missing']
    try:
        backup = read_previous_current_candidate()
    except Exception as exc:
        backup = None
        invalid.append(f'backup:{type(exc).__name__}')
    if backup is not None:
        payload = copy.deepcopy(backup.payload)
        payload['authority'] = 'recovered'
        return _strict_json.AuthorityResult(payload, 'backup', False, (backup,), tuple(invalid))
    return _strict_json.AuthorityResult(None, 'none', False, (), tuple(invalid))


def _commit_current_into_central(
    values: dict[str, Any],
    base: dict[str, Any],
    enabled: bool,
) -> dict[str, Any]:
    """Assign ``max(known)+1`` to the N-panel current and publish the file.

    The crash journal is not published with a commit (it belongs to the older
    revision); it stays in memory until its owner retires it.  Success is
    returned only after strict readback with exact revision/writer/checksum
    agreement; every failure raises and leaves the cache unchanged.
    """
    global _CENTRAL_SETTINGS_WRITING
    if _CENTRAL_SETTINGS_WRITING:
        raise _strict_json.ContractError('settings file write already in progress')
    _CENTRAL_SETTINGS_WRITING = True
    try:
        revision = _next_central_revision()
        writer = _contract_writer_id()
        source = _detached_strict_json(values, source='n-panel-current-commit')
        ui_state = source.get('ui_state')
        if not isinstance(ui_state, dict):
            ui_state = {}
            source['ui_state'] = ui_state
        ui_state[CENTRAL_N_PANEL_STATE_SAVE_KEY] = enabled
        current = _strict_json.finalize_current_payload(
            source,
            revision=revision,
            writer_id=writer,
            authority='primary',
        )
        embedded = copy.deepcopy(current)
        embedded['authority'] = 'central'
        embedded['payload_checksum'] = _strict_json.payload_checksum(embedded)
        files = {
            key: value
            for key, value in _layer_files(base.get('files')).items()
            if key not in {_vfs.CURRENT_KEY, _vfs.LIVE_STATE_KEY}
        }
        files[_vfs.CURRENT_KEY] = embedded
        publish = dict(base)
        publish['files'] = files
        publish[_vfs.LAYOUT_FIELD] = _vfs.LAYOUT_MARK
        publish['blender_version'] = _blender_version()
        payload = _strict_json.finalize_central_payload(
            publish,
            revision=revision,
            writer_id=writer,
            state_save_enabled=enabled,
        )
        verified = _durable_publish(payload, revision, writer)
        embedded_verified, _legacy = _strict_json.validate_current_payload(
            verified.get('files', {}).get(_vfs.CURRENT_KEY),
            allow_legacy=False,
            source='central-current-readback',
        )
        for field in ('revision', 'writer_id', 'payload_checksum'):
            if embedded_verified.get(field) != current.get(field):
                raise _strict_json.ContractError(f'settings file {field} mismatch')
        if _strict_json.strict_bool(
            verified.get(CENTRAL_N_PANEL_STATE_SAVE_KEY), field='central policy'
        ) != enabled:
            raise _strict_json.ContractError('settings file policy mismatch')
        cached_files = _central_peek_payload().get('files')
        journal = (
            cached_files.get(_vfs.LIVE_STATE_KEY, _NO_JOURNAL)
            if isinstance(cached_files, dict)
            else _NO_JOURNAL
        )
        _central_publish_cache(copy.deepcopy(verified), journal=journal)
        return {
            'success': True,
            'revision': revision,
            'writer_id': writer,
            'payload_checksum': current['payload_checksum'],
            'primary': current,
            'central': verified,
        }
    finally:
        _CENTRAL_SETTINGS_WRITING = False


def commit_n_panel_current_settings(
    path: str | Path,
    values: dict[str, Any],
    *,
    state_save_enabled: bool,
    central_updates: dict[str, Any] | None = None,
) -> bool:
    """Commit the N-panel current inside the settings file; verified Boolean."""
    global _LAST_N_PANEL_COMMIT_RESULT
    del path
    _LAST_N_PANEL_COMMIT_RESULT = None
    if not isinstance(values, dict):
        raise TypeError('N-panel values must be a dict')
    enabled = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    central_base = _central_read_payload()
    if isinstance(central_updates, dict):
        for key, value in central_updates.items():
            central_base[str(key)] = copy.deepcopy(value)
    result = _commit_current_into_central(values, central_base, enabled)
    _LAST_N_PANEL_COMMIT_RESULT = copy.deepcopy(result)
    return True


def last_n_panel_commit_result() -> dict[str, Any] | None:
    """Return a copy of the last verified N-panel save result."""
    return copy.deepcopy(_LAST_N_PANEL_COMMIT_RESULT) if isinstance(_LAST_N_PANEL_COMMIT_RESULT, dict) else None


_EXPLICIT_CENTRAL_METADATA_KEYS = frozenset({
    'contract', 'contract_version', 'schema', 'schema_version', 'addon',
    'settings_file', 'revision', 'writer_id', 'authority', 'payload_checksum',
    'saved_at', CENTRAL_N_PANEL_STATE_SAVE_KEY,
})


def _explicit_state_save_from_current(current_payload: dict[str, Any]) -> bool:
    ui_state = current_payload.get('ui_state')
    if not isinstance(ui_state, dict):
        ui_state = {}
    return _strict_json.strict_bool(
        ui_state.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
        default=True,
        field=f'current.ui_state.{CENTRAL_N_PANEL_STATE_SAVE_KEY}',
    )


def _detached_strict_json(value: Any, *, source: str) -> Any:
    raw = _strict_json.canonical_json_bytes(value, pretty=False)
    return _strict_json.strict_json_loads(raw.decode('utf-8'), source=source)


def _remove_embedded_current_authorities(files: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in files.items():
        clean_key = _strict_json._validate_central_file_key(key, source='explicit-central-files')
        if _strict_json.is_current_key(clean_key):
            continue
        result[clean_key] = _detached_strict_json(value, source=f'explicit-central:{clean_key}')
    return result


def _explicit_central_base(
    value: dict[str, Any] | None,
    *,
    state_save_enabled: bool,
    preserve_local_when_missing: bool,
) -> dict[str, Any]:
    """Return a metadata-free central base for an explicit adopt transaction.

    Local settings members stay unless the imported graph provides the same
    member (the former local sidecar files survived an import the same way).
    """
    if isinstance(value, dict):
        try:
            source, _legacy = _strict_json.validate_central_payload(
                value,
                allow_legacy=True,
                source='explicit-central-base',
            )
        except Exception:
            # parse_explicit_settings_import() already performs strict salvage;
            # this fallback accepts a bounded internal base assembled by that
            # helper, never an arbitrary unvalidated document.
            source = _detached_strict_json(value, source='explicit-central-base')
    elif preserve_local_when_missing and central_payload_validated():
        source = _central_read_payload()
    else:
        source = _central_empty_payload()
    base = {
        str(key): copy.deepcopy(item)
        for key, item in source.items()
        if str(key) not in _EXPLICIT_CENTRAL_METADATA_KEYS
    }
    files = {
        key: copy.deepcopy(item)
        for key, item in (_central_peek_payload().get('files') or {}).items()
        if key not in {_vfs.CURRENT_KEY, _vfs.LIVE_STATE_KEY}
    }
    imported = source.get('files')
    if not isinstance(imported, dict):
        imported = {}
    for key, item in _layer_files(_remove_embedded_current_authorities(imported)).items():
        if key in {_vfs.CURRENT_KEY, _vfs.LIVE_STATE_KEY}:
            continue
        files[key] = item
    base['files'] = files
    base['blender_version'] = _blender_version()
    base[CENTRAL_N_PANEL_STATE_SAVE_KEY] = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    _detached_strict_json(base, source='explicit-central-base-final')
    return base


def _validate_explicit_current_candidate(value: Any, *, source: str):
    """Validate strict current JSON or bounded pre-contract authority JSON.

    Builds before the strict contract sometimes emitted ``revision`` or
    ``writer_id`` fields without the contract/checksum pair.  The normal
    validator correctly rejects that ambiguous partial authority.  Explicit
    user import may salvage it only when the remaining document is a recognized
    N-panel schema; imported authority metadata is discarded because the local
    adopt transaction always assigns a fresh revision and writer.
    """
    try:
        return _strict_json.validate_current_payload(
            value, allow_legacy=True, source=source
        )
    except Exception as original_error:
        if not isinstance(value, dict):
            raise
        if value.get('contract') == _strict_json.CONTRACT_NAME:
            raise
        candidate = copy.deepcopy(value)
        if not _strict_json._recognize_legacy_current(candidate):
            raise original_error
        for key in (
            'contract', 'contract_version', 'revision', 'writer_id',
            'authority', 'payload_checksum', 'saved_at',
        ):
            candidate.pop(key, None)
        try:
            normalized, _migrated = _strict_json.validate_current_payload(
                candidate, allow_legacy=True, source=f'{source}:pre-contract'
            )
        except Exception:
            raise original_error
        return normalized, True


def parse_explicit_settings_import(document: Any) -> dict[str, Any]:
    """Parse strict or pre-1.1.151 settings without adopting its old revision.

    Returns a normalized current payload, an optional detached central base,
    strict State Save policy, and the recognized format.  Legacy envelopes with
    revision-like fields but no strict checksum are salvaged only when their
    bounded ``files`` graph contains one recognized N-panel payload.
    """
    if not isinstance(document, dict):
        raise _strict_json.CandidateInvalid('explicit import root must be an object')
    errors: list[str] = []

    try:
        central, migrated = _strict_json.validate_central_payload(
            document,
            allow_legacy=True,
            source='explicit-central-import',
        )
        current_entries = [
            (str(key), value)
            for key, value in central.get('files', {}).items()
            if _strict_json.is_current_key(key)
        ]
        if len(current_entries) != 1:
            raise _strict_json.CandidateInvalid(
                'explicit central import must contain exactly one N-panel authority'
            )
        current, current_migrated = _validate_explicit_current_candidate(
            current_entries[0][1],
            source=f'explicit-central-current:{current_entries[0][0]}',
        )
        enabled = _strict_json.strict_bool(
            central.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
        return {
            'current_payload': current,
            'central_payload': central,
            'state_save_enabled': enabled,
            'format': 'central-legacy' if migrated or current_migrated else 'central-strict',
        }
    except Exception as exc:
        errors.append(f'central:{type(exc).__name__}:{exc}')

    # Pre-contract central exports could contain a revision field without the
    # strict contract/checksum, which intentionally fails the validator above.
    # Salvage only a strict JSON files graph with one recognized current entry.
    files_value = document.get('files')
    if isinstance(files_value, dict):
        try:
            clean_files: dict[str, Any] = {}
            current = None
            current_migrated = False
            for raw_key, raw_value in files_value.items():
                key = _strict_json._validate_central_file_key(
                    raw_key,
                    source='explicit-legacy-central',
                )
                copied = _detached_strict_json(
                    raw_value,
                    source=f'explicit-legacy-central:{key}',
                )
                if _strict_json.is_current_key(key):
                    if current is not None:
                        raise _strict_json.CandidateInvalid(
                            'legacy central import contains multiple N-panel authorities'
                        )
                    current, current_migrated = _validate_explicit_current_candidate(
                        copied,
                        source=f'explicit-legacy-current:{key}',
                    )
                clean_files[key] = copied
            if not isinstance(current, dict):
                raise _strict_json.CandidateInvalid(
                    'legacy central import contains no recognized N-panel settings'
                )
            if CENTRAL_N_PANEL_STATE_SAVE_KEY in document:
                enabled = _strict_json.strict_bool(
                    document.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
                    field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
                )
            else:
                enabled = _explicit_state_save_from_current(current)
            central_base = _central_empty_payload()
            central_base['files'] = clean_files
            if isinstance(document.get('rna_state'), dict):
                central_base['rna_state'] = _detached_strict_json(
                    document['rna_state'], source='explicit-legacy-rna-state'
                )
            central_base[CENTRAL_N_PANEL_STATE_SAVE_KEY] = enabled
            return {
                'current_payload': current,
                'central_payload': central_base,
                'state_save_enabled': enabled,
                'format': 'central-pre-contract',
            }
        except Exception as exc:
            errors.append(f'legacy-central:{type(exc).__name__}:{exc}')

    current_candidates = [
        ('root', document),
        ('current_settings', document.get('current_settings')),
        ('n_panel_settings', document.get('n_panel_settings')),
        ('n_panel_manager', document.get('n_panel_manager')),
    ]
    for label, candidate in current_candidates:
        if not isinstance(candidate, dict):
            continue
        try:
            current, migrated = _validate_explicit_current_candidate(
                candidate,
                source=f'explicit-current-import:{label}',
            )
            return {
                'current_payload': current,
                'central_payload': None,
                'state_save_enabled': _explicit_state_save_from_current(current),
                'format': 'current-legacy' if migrated else 'current-strict',
            }
        except Exception as exc:
            errors.append(f'{label}:{type(exc).__name__}:{exc}')
    raise _strict_json.CandidateInvalid(
        'settings import is not a recognized Smart Workspace payload; '
        + ' | '.join(errors[:6])
    )


def adopt_n_panel_current_settings(
    path: str | Path,
    values: dict[str, Any],
    *,
    state_save_enabled: bool,
    central_payload: dict[str, Any] | None = None,
    preserve_local_when_missing: bool = True,
    source: str = 'explicit-user-operation',
) -> bool:
    """Adopt an explicit import/export graph as a new local authority revision.

    This operation is intentionally independent of lifecycle snapshot fences.
    Imported revision/writer/checksum metadata is validated but never reused as
    local authority.  The local strict contract assigns ``max(local)+1`` and
    verifies the settings file and its embedded readback before success.
    """
    global _LAST_N_PANEL_COMMIT_RESULT
    del path
    _LAST_N_PANEL_COMMIT_RESULT = None
    if not isinstance(values, dict):
        raise TypeError('explicit N-panel values must be a dict')
    normalized, _migrated = _strict_json.validate_current_payload(
        values,
        allow_legacy=True,
        source=str(source or 'explicit-user-operation'),
    )
    enabled = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    base = _explicit_central_base(
        central_payload,
        state_save_enabled=enabled,
        preserve_local_when_missing=bool(preserve_local_when_missing),
    )
    result = _commit_current_into_central(normalized, base, enabled)
    expected = _strict_json.finalize_current_payload(
        normalized,
        revision=int(result['revision']),
        writer_id=str(result['writer_id']),
        authority='primary',
    )
    if result['primary'].get('payload_checksum') != expected.get('payload_checksum'):
        raise _strict_json.ContractError('explicit authority semantic checksum mismatch')
    _LAST_N_PANEL_COMMIT_RESULT = copy.deepcopy(result)
    return True
