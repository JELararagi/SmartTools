# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import datetime
import json
import copy
import errno
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

from . import strict_json_contract as _strict_json

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_workspace_suite'
USER_DATA_DIRNAME = 'user_data'
CENTRAL_SETTINGS_DIRNAME = 'Smart_Workspace_Suite'
CENTRAL_SETTINGS_FILENAME = 'Smart_Workspace_Suite.json'
CENTRAL_N_PANEL_STATE_SAVE_KEY = 'n_panel_state_save_enabled'
MUTABLE_SIDECAR_DIRNAME = 'sidecars'
VIEWPORT_OPTIMIZER_DIRNAME = 'viewport_optimizer'
LEGACY_VIEWPORT_OPTIMIZER_DIRNAME = 'smart_viewport_optimizer_plus'
_CENTRAL_SETTINGS_WRITING = False
_REGISTRATION_WRITE_GUARD_DEPTH = 0
_CENTRAL_WRITE_BATCH_DEPTH = 0
_CENTRAL_PAYLOAD_CACHE: dict[str, Any] | None = None
_CENTRAL_PAYLOAD_SIGNATURE: tuple[int, int] | None = None
_CENTRAL_PAYLOAD_VALIDATED = False
_LEGACY_STORAGE_CLEANED = False
_N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE: bool | None = None
_TIMER_REGISTRY_NAMESPACE_KEY = 'JELARARAGI_SMART_WORKSPACE_SUITE_TIMER_REGISTRY_V1'
_FALLBACK_TIMER_REGISTRY: dict[str, Any] = {}
if '_SESSION_TIMER_REGISTRY' not in globals():
    _SESSION_TIMER_REGISTRY: dict[str, Any] | None = None


def _timer_registry() -> dict[str, Any]:
    """Return the fixed-slot timer registry shared across same-session reloads."""
    global _SESSION_TIMER_REGISTRY
    if bpy is None:
        return _FALLBACK_TIMER_REGISTRY
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY)
        if not isinstance(registry, dict):
            registry = {}
            namespace[_TIMER_REGISTRY_NAMESPACE_KEY] = registry
            _SESSION_TIMER_REGISTRY = registry
        elif registry is _SESSION_TIMER_REGISTRY:
            namespace[_TIMER_REGISTRY_NAMESPACE_KEY] = registry
        return registry
    except Exception:
        return _FALLBACK_TIMER_REGISTRY


def release_quiescent_timer_registry() -> str:
    """Release only this module's exact empty registry after full teardown."""
    global _SESSION_TIMER_REGISTRY
    if bpy is None:
        return 'NO_BPY'
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY)
    except Exception:
        return 'NAMESPACE_UNAVAILABLE'
    if not isinstance(registry, dict) or registry is not _SESSION_TIMER_REGISTRY:
        return 'RETAINED_FOREIGN_OR_UNOWNED'
    if registry:
        return 'RETAINED_NONQUIESCENT'
    if namespace.get(_TIMER_REGISTRY_NAMESPACE_KEY) is not registry:
        return 'RETAINED_IDENTITY_CHANGED'
    namespace.pop(_TIMER_REGISTRY_NAMESPACE_KEY, None)
    _SESSION_TIMER_REGISTRY = None
    return 'RELEASED'


def unregister_timer_slot(slot: str, *callbacks: Any) -> bool:
    """Unregister one bounded timer slot and verify that no candidate remains."""
    key = str(slot or '').strip()
    registry = _timer_registry()
    candidates = []
    if key:
        try:
            candidates.append(registry.pop(key, None))
        except Exception:
            pass
    candidates.extend(callbacks)
    seen = set()
    ok = True
    for callback in candidates:
        if not callable(callback):
            continue
        marker = id(callback)
        if marker in seen:
            continue
        seen.add(marker)
        if bpy is None:
            continue
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
            if bpy.app.timers.is_registered(callback):
                ok = False
        except Exception:
            ok = False
    if key:
        try:
            if registry.get(key) is not None:
                ok = False
        except Exception:
            ok = False
    return bool(ok)


def register_timer_slot(
    slot: str,
    callback: Any,
    *,
    first_interval: float,
    persistent: bool = False,
) -> bool:
    """Replace and register one timer callback under a stable bounded slot."""
    key = str(slot or '').strip()
    if not key or not callable(callback) or bpy is None:
        return False
    unregister_timer_slot(key, callback)
    try:
        bpy.app.timers.register(
            callback,
            first_interval=max(0.0, float(first_interval)),
            persistent=bool(persistent),
        )
        if not bool(bpy.app.timers.is_registered(callback)):
            return False
        _timer_registry()[key] = callback
        if _timer_registry().get(key) is not callback:
            raise RuntimeError('timer slot identity readback failed')
        return True
    except Exception:
        unregister_timer_slot(key, callback)
        return False


def _fsync_parent_directory(path: str | Path) -> None:
    """Sync the containing directory without masking supported-platform I/O errors."""
    target = Path(path)
    flags = getattr(os, 'O_RDONLY', 0) | getattr(os, 'O_DIRECTORY', 0)
    fd = None
    try:
        fd = os.open(str(target.parent), flags)
        os.fsync(fd)
    except AttributeError:
        return
    except OSError as exc:
        unsupported = {
            getattr(errno, 'EINVAL', -1),
            getattr(errno, 'ENOTSUP', -1),
            getattr(errno, 'EOPNOTSUPP', -1),
            getattr(errno, 'ENOSYS', -1),
            getattr(errno, 'EBADF', -1),
        }
        if os.name == 'nt' or exc.errno in unsupported:
            return
        raise
    finally:
        if fd is not None:
            os.close(fd)


def _atomic_replace_bytes(
    path: str | Path,
    payload: bytes,
    *,
    backup: bool = False,
) -> bool:
    """Durably replace one file through a unique sibling temporary file.

    Returns ``True`` when bytes changed and ``False`` when the existing target
    already contained the same payload.  A unique temporary file prevents two
    nested settings transactions from sharing ``<name>.tmp``.  When ``backup``
    is requested, the previous complete target is atomically published as
    ``<name>.bak`` before the new revision replaces it.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = bytes(payload)

    previous: bytes | None = None
    if target.exists():
        previous = target.read_bytes()
        if previous == raw:
            return False

    if backup and previous is not None:
        backup_path = target.with_name(target.name + '.bak')
        _atomic_replace_bytes(backup_path, previous, backup=False)

    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='wb',
            dir=str(target.parent),
            prefix=f'.{target.name}.',
            suffix='.tmp',
            delete=False,
        ) as handle:
            tmp_path = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(str(tmp_path), str(target))
        tmp_path = None
        _fsync_parent_directory(target)
        return True
    finally:
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except Exception:
                pass


def _atomic_replace_text(
    path: str | Path,
    text: str,
    *,
    encoding: str = 'utf-8',
    backup: bool = False,
) -> bool:
    return _atomic_replace_bytes(
        path,
        str(text).encode(encoding),
        backup=backup,
    )


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.name == PACKAGE_ID and current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_workspace_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path




def blender_config_dir(create: bool = True) -> Path:
    """Return Blender's versioned user config directory."""
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', create=create) or ''
            except TypeError:
                try:
                    value = user_resource('CONFIG') or ''
                except Exception:
                    value = ''
            except Exception:
                value = ''
            if value:
                path = Path(value)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def central_settings_dir(create: bool = True) -> Path:
    path = blender_config_dir(create=create) / CENTRAL_SETTINGS_DIRNAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def mutable_settings_root(package: object | None = None, *, create: bool = True) -> Path:
    """Return the CONFIG-owned root for every mutable Workspace sidecar.

    Blender Extension package directories are release artifacts and must stay
    byte-for-byte immutable after installation.  Older builds used
    ``extension_path_user`` as a writable data directory; in an Extension that
    API resolves to the installed package itself.  Keep all compatibility
    sidecars below the suite's versioned CONFIG folder instead.  The canonical
    Smart_Workspace_Suite.json remains authoritative and mirrors these files.
    """
    pkg = str(package or PACKAGE_ID).strip() or PACKAGE_ID
    path = central_settings_dir(create=create) / MUTABLE_SIDECAR_DIRNAME
    if pkg != PACKAGE_ID:
        path = path / _clean_part(pkg)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _legacy_central_settings_paths() -> tuple[Path, ...]:
    """Return read-only migration inputs used by older Workspace builds."""
    root = blender_config_dir(create=False)
    return (
        root / 'Smart_WorkSpace_Suite' / 'Smart_WorkSpace_Suite.json',
        root / 'Smart_WorkSpace_Suite.json',
        root / CENTRAL_SETTINGS_FILENAME,
    )


def central_settings_path(create: bool = True) -> Path:
    path = central_settings_dir(create=create) / CENTRAL_SETTINGS_FILENAME
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _central_empty_payload() -> dict[str, Any]:
    """Return an in-memory central skeleton; do not publish defaults to disk."""
    return {
        'schema': _strict_json.CENTRAL_SCHEMA,
        'schema_version': _strict_json.CENTRAL_SCHEMA_VERSION,
        'addon': PACKAGE_ID,
        'settings_file': CENTRAL_SETTINGS_FILENAME,
        'blender_version': _blender_version(),
        CENTRAL_N_PANEL_STATE_SAVE_KEY: True,
        'files': {},
    }


def _central_file_signature(path: Path) -> tuple[int, int] | None:
    try:
        stat = path.stat()
        return int(stat.st_mtime_ns), int(stat.st_size)
    except Exception:
        return None


def _central_load_cached_payload() -> dict[str, Any]:
    """Load one strictly validated central envelope per explicit lifecycle.

    Missing or corrupt files yield an in-memory default with a *false* validation
    marker.  That marker prevents registration-time RNA defaults from becoming
    authority.  No file stat or watchdog is performed after the explicit load.
    """
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    if isinstance(_CENTRAL_PAYLOAD_CACHE, dict):
        return _CENTRAL_PAYLOAD_CACHE
    path = central_settings_path(create=False)
    if not path.exists():
        _CENTRAL_PAYLOAD_CACHE = _central_empty_payload()
        _CENTRAL_PAYLOAD_SIGNATURE = None
        _CENTRAL_PAYLOAD_VALIDATED = False
        return _CENTRAL_PAYLOAD_CACHE
    try:
        stat = path.stat()
        if int(stat.st_size) > int(_strict_json.MAX_JSON_BYTES):
            raise _strict_json.CandidateInvalid('central-settings exceeds bounded JSON size')
        raw_bytes = path.read_bytes()
        if len(raw_bytes) > int(_strict_json.MAX_JSON_BYTES):
            raise _strict_json.CandidateInvalid('central-settings exceeds bounded JSON size')
        raw = _strict_json.strict_json_loads(
            raw_bytes.decode('utf-8', errors='strict'),
            source='central-settings',
        )
        data, _legacy = _strict_json.validate_central_payload(
            raw, allow_legacy=False, source='central-settings'
        )
        _CENTRAL_PAYLOAD_VALIDATED = True
    except Exception:
        try:
            _strict_json.preserve_corrupt_file(path)
        except Exception:
            pass
        data = _central_empty_payload()
        _CENTRAL_PAYLOAD_VALIDATED = False
    _CENTRAL_PAYLOAD_CACHE = data
    _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(path)
    return _CENTRAL_PAYLOAD_CACHE


def central_payload_validated() -> bool:
    _central_load_cached_payload()
    return bool(_CENTRAL_PAYLOAD_VALIDATED)


def _central_peek_payload() -> dict[str, Any]:
    """Return a read-only-by-contract cached payload.

    Internal callers using this helper must not mutate the returned graph.
    It avoids copying large mirrored Viewport/N-panel files for simple policy
    checks and settings reads.
    """
    return _central_load_cached_payload()


def _central_read_payload() -> dict[str, Any]:
    """Return a detached payload suitable for an update transaction."""
    return copy.deepcopy(_central_load_cached_payload())


def registration_write_guard_active() -> bool:
    """Return whether internal RNA registration is write-protected.

    Update callbacks can fire hundreds of times while optional PropertyGroups
    are being registered.  They are internal materialisation events, not user
    changes, so persistence callers should return before collecting or copying
    the complete canonical JSON graph.
    """
    return _REGISTRATION_WRITE_GUARD_DEPTH > 0


def begin_registration_write_guard() -> dict[str, Any]:
    """Freeze the canonical N-panel profile during RNA registration."""
    global _REGISTRATION_WRITE_GUARD_DEPTH
    payload = _central_read_payload()
    _REGISTRATION_WRITE_GUARD_DEPTH += 1
    return payload


def begin_central_write_batch() -> None:
    """Block nested central mirror writes without blocking sidecar serializers."""
    global _CENTRAL_WRITE_BATCH_DEPTH
    _CENTRAL_WRITE_BATCH_DEPTH += 1


def end_central_write_batch() -> None:
    global _CENTRAL_WRITE_BATCH_DEPTH
    _CENTRAL_WRITE_BATCH_DEPTH = max(0, _CENTRAL_WRITE_BATCH_DEPTH - 1)


def central_write_batch_active() -> bool:
    """Return whether mirror publication is owned by an outer transaction."""
    return _CENTRAL_WRITE_BATCH_DEPTH > 0


def end_registration_write_guard() -> None:
    global _REGISTRATION_WRITE_GUARD_DEPTH
    _REGISTRATION_WRITE_GUARD_DEPTH = max(0, _REGISTRATION_WRITE_GUARD_DEPTH - 1)
    if _REGISTRATION_WRITE_GUARD_DEPTH == 0:
        # Registration may discover legacy mirrored layout snapshots while the
        # canonical file is intentionally write-protected.  Finish that finite
        # migration immediately after the guard opens instead of marking it as
        # completed without publishing the compact payload.
        try:
            cleanup_legacy_storage_dirs(force=True)
        except Exception:
            pass


def _central_write_payload(data: dict[str, Any]) -> bool:
    """Commit central changes through the same strict primary revision.

    A central-only replace could create a mirror whose revision/writer/checksum
    no longer agrees with ``current_settings.json``.  Therefore every successful
    central save first resolves a validated N-panel authority and then commits
    primary plus central through ``commit_current_and_central``.  Missing or
    corrupt authority is not replaced by RNA defaults; the caller receives
    ``False`` and must retain dirty state.  I/O, disk-full, permission, AV,
    replace and readback failures propagate.
    """
    global _CENTRAL_SETTINGS_WRITING, _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    if (
        _CENTRAL_SETTINGS_WRITING
        or _REGISTRATION_WRITE_GUARD_DEPTH > 0
        or _CENTRAL_WRITE_BATCH_DEPTH > 0
    ):
        return False
    if not isinstance(data, dict):
        raise TypeError('central payload must be a dict')
    _CENTRAL_SETTINGS_WRITING = True
    try:
        enabled = _strict_json.strict_bool(
            data.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
        primary = central_settings_dir(create=True) / 'n-panel_manager' / 'current_settings.json'
        current_key = n_panel_current_settings_key(primary)
        authority = _strict_json.resolve_current_authority(
            primary,
            primary.with_name(primary.name + '.bak'),
            central_settings_path(create=False),
            current_key,
            repair_primary=False,
        )
        if not authority.valid or not isinstance(authority.payload, dict):
            # A valid backup or central mirror may be newer than a damaged or
            # missing primary.  Repair primary once through the strict resolver
            # before refusing the central write; never manufacture authority
            # from live RNA defaults.
            authority = _strict_json.resolve_current_authority(
                primary,
                primary.with_name(primary.name + '.bak'),
                central_settings_path(create=False),
                current_key,
                repair_primary=True,
            )
        if not authority.valid or not isinstance(authority.payload, dict):
            return False
        base = copy.deepcopy(data)
        base['blender_version'] = _blender_version()
        committed = _strict_json.commit_current_and_central(
            primary_path=primary,
            central_path=central_settings_path(create=True),
            current_key=current_key,
            current_payload=authority.payload,
            central_base=base,
            writer_id=_contract_writer_id(),
            state_save_enabled=enabled,
        )
        result = _strict_json.last_commit_result()
        if committed is not True or not isinstance(result, dict):
            raise _strict_json.ContractError('central dual transaction result unavailable')
        primary_verified, _ = _strict_json.validate_current_payload(
            _strict_json.read_json_document(primary),
            allow_legacy=False,
            source='central-write-primary-readback',
        )
        central_verified, _ = _strict_json.validate_central_payload(
            _strict_json.read_json_document(central_settings_path(create=False)),
            allow_legacy=False,
            source='central-write-central-readback',
        )
        embedded = central_verified.get('files', {}).get(current_key)
        embedded_verified, _ = _strict_json.validate_current_payload(
            embedded,
            allow_legacy=False,
            source='central-write-embedded-readback',
        )
        for field in ('revision', 'writer_id', 'payload_checksum'):
            if primary_verified.get(field) != embedded_verified.get(field):
                raise _strict_json.ContractError(f'central write {field} mismatch')
        if int(central_verified.get('revision', -1)) != int(primary_verified.get('revision', -2)):
            raise _strict_json.ContractError('central envelope revision mismatch')
        if central_verified.get('writer_id') != primary_verified.get('writer_id'):
            raise _strict_json.ContractError('central envelope writer_id mismatch')
        if not bool(result.get('success')):
            raise _strict_json.ContractError('central dual transaction was not verified')
        _CENTRAL_PAYLOAD_CACHE = copy.deepcopy(central_verified)
        _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(central_settings_path(create=False))
        _CENTRAL_PAYLOAD_VALIDATED = True
        return True
    finally:
        _CENTRAL_SETTINGS_WRITING = False


def n_panel_state_save_enabled(default: bool = True) -> bool:
    """Return strict policy; missing/invalid values always migrate to ``True``."""
    del default
    if isinstance(_N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE, bool):
        return _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE
    try:
        payload = _central_peek_payload()
        return _strict_json.strict_bool(
            payload.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
    except Exception:
        return True


def set_n_panel_state_save_runtime_policy(enabled: bool | None) -> None:
    """Update the in-session policy without rewriting the central JSON graph."""
    global _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE
    _N_PANEL_STATE_SAVE_RUNTIME_OVERRIDE = enabled if isinstance(enabled, bool) else None


def set_n_panel_state_save_enabled(enabled: bool) -> bool:
    """Persist a strict Boolean policy and return verified success."""
    value = _strict_json.strict_bool(enabled, field=CENTRAL_N_PANEL_STATE_SAVE_KEY)
    set_n_panel_state_save_runtime_policy(value)
    payload = _central_read_payload()
    payload[CENTRAL_N_PANEL_STATE_SAVE_KEY] = value
    return bool(_central_write_payload(payload))




def _normalize_central_storage_key(key: str) -> str:
    """Normalize central mirror keys and permanently retire legacy tool folders."""
    try:
        text = str(key or '').replace('\\', '/').strip('/')
    except Exception:
        return ''
    if not text:
        return ''
    parts = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    if not parts:
        return ''
    normalized = []
    for piece in parts:
        if piece == LEGACY_VIEWPORT_OPTIMIZER_DIRNAME:
            piece = VIEWPORT_OPTIMIZER_DIRNAME
        normalized.append(piece)
    return '/'.join(normalized)


def _central_should_mirror_key(key: str) -> bool:
    """Return whether one CONFIG JSON belongs in the canonical settings file.

    Explicit Viewport Optimizer layouts can contain the state of tens of
    thousands of objects.  They are user-created data snapshots, not N-panel
    settings, and serializing them into ``Smart_WorkSpace_Suite.json`` makes
    every unrelated setting change rewrite multiple megabytes.  Keep those
    snapshots as physical sidecars while mirroring their compact reference
    metadata through the normal settings JSON.
    """
    normalized = _normalize_central_storage_key(str(key or '')).lower()
    if not normalized:
        return False
    if normalized.endswith('user_data/storage/n_panel_manager/live_state.json'):
        # This is a crash journal tied to one canonical revision. Embedding it
        # in central settings resurrects a retired journal on the next startup.
        return False
    if normalized == 'config/workspace_manager/save_state_order.json':
        # This indexes the snapshot sidecars below, not N-panel preferences.
        # Saving/deleting a workspace must also work before N-panel settings
        # have a canonical revision in a fresh configuration.
        return False
    if normalized.startswith((
        'config/workspace_manager/backups/',
        'config/workspace_manager/diagnostics/',
        'config/workspace_manager/save_states/',
    )):
        # These are user data snapshots, not preferences. Keep their physical
        # sidecars without rewriting them for every N-panel setting change.
        return False
    if normalized.endswith('viewport_optimizer/settings/workspace_settings.json'):
        return False
    return not normalized.endswith('.layout.json')


def _central_should_mirror_path(path: str | Path) -> bool:
    return _central_should_mirror_key(_central_file_key(path))


def cleanup_legacy_storage_dirs(*, force: bool = False) -> None:
    """Mark the finite migration check complete without deleting user data.

    Historical builds recursively removed a legacy config directory and pruned
    central entries.  1.1.129 keeps those bytes for diagnosis/import and performs
    no automatic file or directory deletion during registration.
    """
    del force
    global _LEGACY_STORAGE_CLEANED
    _LEGACY_STORAGE_CLEANED = True


def _central_file_key(path: str | Path) -> str:
    try:
        target = Path(path).resolve()
    except Exception:
        return ''
    try:
        if target == central_settings_path(create=False).resolve():
            return ''
    except Exception:
        pass
    try:
        if any(target == path.resolve() for path in _legacy_central_settings_paths()):
            return ''
    except Exception:
        pass
    if target.suffix.lower() != '.json':
        return ''

    # CONFIG-owned mutable settings cache.  Never map a release-package path as
    # a writable target: doing so would mutate the installed Extension.
    try:
        root = mutable_settings_root(PACKAGE_ID, create=False).resolve()
        rel = target.relative_to(root)
        if any(piece in {'.', '..'} for piece in rel.parts):
            return ''
        return _normalize_central_storage_key(rel.as_posix())
    except Exception:
        pass

    # Versioned Blender config folder:
    #   .../5.1/config/Smart_WorkSpace_Suite/<tool settings>.json
    try:
        cfg_root = central_settings_dir(create=False).resolve()
        rel = target.relative_to(cfg_root)
        if not rel.parts or rel.parts[0] == CENTRAL_SETTINGS_FILENAME:
            return ''
        if any(piece in {'.', '..'} for piece in rel.parts):
            return ''
        return _normalize_central_storage_key('config/' + rel.as_posix())
    except Exception:
        pass

    return ''


_SENTINEL = object()


def central_read_json_for_path(path: str | Path, default: Any = None) -> Any:
    key = _normalize_central_storage_key(_central_file_key(path))
    if not key:
        return default
    data = _central_peek_payload()
    files = data.get('files')
    if isinstance(files, dict) and key in files:
        return copy.deepcopy(files.get(key))
    return default


def mirror_json_file(path: str | Path, data: Any, *, force: bool = False) -> bool:
    if _REGISTRATION_WRITE_GUARD_DEPTH > 0:
        return False
    if _CENTRAL_WRITE_BATCH_DEPTH > 0:
        # Staged mirror changes are not a verified save result.  The caller must
        # retry after the owner transaction closes and completes readback.
        return False
    key = _normalize_central_storage_key(_central_file_key(path))
    if not key:
        return False
    if not _central_should_mirror_key(key):
        return unmirror_json_file(path, force=force)
    if not force and not n_panel_state_save_enabled(True):
        return False
    payload = _central_read_payload()
    files = payload.setdefault('files', {})
    if not isinstance(files, dict):
        raise TypeError('central files must be a dict')
    files[key] = copy.deepcopy(data)
    return bool(_central_write_payload(payload))


def unmirror_json_file(path: str | Path, *, force: bool = False) -> bool:
    """Remove one mirror entry without deleting the physical sidecar."""
    if _REGISTRATION_WRITE_GUARD_DEPTH > 0:
        return False
    if _CENTRAL_WRITE_BATCH_DEPTH > 0:
        return False
    key = _normalize_central_storage_key(_central_file_key(path))
    if not key:
        return False
    if not force and not n_panel_state_save_enabled(True):
        return False
    payload = _central_read_payload()
    files = payload.get('files')
    if not isinstance(files, dict) or key not in files:
        # Nothing is mirrored for this key, which is the requested end state.
        return True
    del files[key]
    return bool(_central_write_payload(payload))


def _central_path_for_key(key: str) -> Path | None:
    key = _normalize_central_storage_key(key)
    clean = _clean_parts([key])
    if not clean:
        return None
    if clean[0] == 'config':
        if len(clean) < 2:
            return None
        return central_settings_dir(create=True).joinpath(*clean[1:])
    return mutable_settings_root(PACKAGE_ID, create=True).joinpath(*clean)


def _parse_saved_at(value: Any) -> None:
    """Compatibility stub: wall-clock timestamps never determine authority."""
    del value
    return None


def _json_saved_at_from_path(path: Path) -> None:
    del path
    return None


def _json_saved_at_from_value(value: Any) -> None:
    del value
    return None


def _should_preserve_existing_file(key: str, path: Path, value: Any, *, force: bool = False) -> bool:
    """Current settings are resolved by strict revision/checksum, never time."""
    del value, force
    return _normalize_central_storage_key(str(key or '')).lower().endswith(
        'n-panel_manager/current_settings.json'
    ) and path.exists()


def restore_central_settings_to_files(*, force: bool = False) -> bool:
    """Restore validated mirrors; current_settings uses three-way authority.

    A valid primary remains direct authority.  If it is invalid or missing, the
    newest validated backup/central revision repairs primary through a unique,
    fsynced temporary file.  When all candidates are invalid, no RNA/default
    state is published and every corrupt file remains available for diagnosis.
    """
    del force
    payload = _central_peek_payload()
    files = payload.get('files')
    if not isinstance(files, dict):
        return False
    restored = False
    for key, value in list(files.items()):
        key = _normalize_central_storage_key(str(key or ''))
        if not _central_should_mirror_key(key):
            continue
        path = _central_path_for_key(key)
        if path is None or path.suffix.lower() != '.json':
            continue
        if key.lower().endswith('n-panel_manager/current_settings.json'):
            result = _strict_json.resolve_current_authority(
                path,
                path.with_name(path.name + '.bak'),
                central_settings_path(create=False),
                key,
                repair_primary=True,
            )
            restored = restored or result.valid
            continue
        # Only the already validated central envelope may restore ordinary
        # sidecars.  Generic JSON is still reread after atomic replacement.
        sidecar_ok = atomic_write_json(
            path,
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
            backup=False,
        )
        if sidecar_ok is not True:
            return False
        restored = True
    return restored


def collect_json_storage_into_payload(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Collect sidecar JSON into one in-memory canonical payload."""
    try:
        cleanup_legacy_storage_dirs()
    except Exception:
        pass
    roots: list[Path] = []
    try:
        roots.append(central_settings_dir(create=False))
    except Exception:
        pass
    payload = dict(payload or _central_read_payload())
    files = payload.setdefault('files', {})
    if not isinstance(files, dict):
        files = {}
        payload['files'] = files
    else:
        # Retire large explicit layout snapshots that may have been mirrored
        # by an older release before the sidecar split.
        files = {
            key: value
            for key, value in files.items()
            if _central_should_mirror_key(str(key or ''))
        }
        payload['files'] = files
    failures: list[str] = []
    for root in roots:
        if not root.exists():
            continue
        for path in sorted(root.rglob('*.json')):
            if path.name.endswith(('.tmp', '.bak')) or '.corrupt.' in path.name:
                continue
            if LEGACY_VIEWPORT_OPTIMIZER_DIRNAME in path.parts:
                continue
            key = _central_file_key(path)
            if not key or not _central_should_mirror_key(key):
                continue
            try:
                raw = path.read_bytes()
                if len(raw) > int(_strict_json.MAX_JSON_BYTES):
                    raise OSError('JSON sidecar exceeds bounded size')
                value = _strict_json.strict_json_loads(
                    raw.decode('utf-8', errors='strict'),
                    source=f'sidecar:{key}',
                )
                # Ensure a detached strict JSON graph before mirroring.
                _strict_json.canonical_json_bytes(value, pretty=False)
                files[key] = value
            except Exception as exc:
                failures.append(f'{key}:{type(exc).__name__}:{exc}')
    if failures:
        raise OSError('sidecar collection failed: ' + '; '.join(failures[:16]))
    return payload


def snapshot_json_storage_to_central(*, force: bool = False) -> bool:
    """Mirror explicit JSON files with one strict, verified central replace."""
    if not force and not n_panel_state_save_enabled(True):
        return False
    return bool(_central_write_payload(collect_json_storage_into_payload()))


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    pkg = str(package_id or PACKAGE_ID).strip() or PACKAGE_ID
    root = mutable_settings_root(pkg, create=create)
    clean = _clean_parts(parts)
    # Historical callers passed the package ID positionally even though this
    # function already selected that package.  Treat it as an identifier, not
    # as a second nested folder (the old behavior produced
    # smart_workspace_suite/smart_workspace_suite_config.json in the package).
    if clean and clean[0] in {pkg, PACKAGE_ID}:
        clean = clean[1:]
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = mutable_settings_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = mutable_settings_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = mutable_settings_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> bool:
    path = user_data_file(subdir, filename, create_parent=True)
    return bool(atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=True))


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return _strict_json.read_json_document(Path(path))
    except Exception:
        fallback = central_read_json_for_path(path, _SENTINEL)
        return default if fallback is _SENTINEL else fallback


def atomic_write_text(
    path: str | Path,
    text: str,
    *,
    encoding: str = 'utf-8',
    mirror: bool = True,
    backup: bool = False,
) -> bool:
    target = Path(path)
    serialized = str(text)
    changed = _atomic_replace_text(
        target,
        serialized,
        encoding=encoding,
        backup=backup,
    )
    # Mandatory readback: a successful os.replace is not enough when AV or
    # filesystem filters can alter/withhold the final bytes.
    if target.read_text(encoding=encoding) != serialized:
        raise OSError(f'atomic readback mismatch: {target}')
    if mirror and target.suffix.lower() == '.json':
        parsed = _strict_json.strict_json_loads(
            serialized or '{}', source=f'atomic-write:{target}'
        )
        if central_write_batch_active():
            # The outer save_all_settings transaction owns the one canonical
            # primary+central commit.  This is a verified sidecar staging result,
            # not a public settings-save success by itself.
            return True
        # An unchanged physical sidecar is not sufficient evidence that its
        # central mirror and the strict current-settings revision still agree.
        # With N-panel state saving off the central file is deliberately left
        # alone, so only the physical file written above has to be verified.
        if not mirror_json_file(target, parsed) and n_panel_state_save_enabled(True):
            raise OSError(f'central mirror was not verified: {target}')
    return True


def atomic_write_json(
    path: str | Path,
    data: Any,
    *,
    indent: int = 2,
    ensure_ascii: bool = False,
    sort_keys: bool = False,
    mirror: bool = True,
    backup: bool = False,
) -> bool:
    serialized = json.dumps(
        data,
        indent=indent,
        ensure_ascii=ensure_ascii,
        sort_keys=sort_keys,
        allow_nan=False,
    )
    return atomic_write_text(
        path,
        serialized,
        encoding='utf-8',
        mirror=mirror,
        backup=backup,
    )


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy legacy data into CONFIG without deleting or modifying its source.

    ``remove_legacy`` remains in the public call signature for compatibility but
    is intentionally ignored.  Migration must never delete user data, another
    Suite's data, or a package-local diagnostic source.
    """
    del remove_legacy
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        return bool(target.is_file() and target.stat().st_size == legacy.stat().st_size)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# 1.1.130 strict N-panel authority contract
# ---------------------------------------------------------------------------
_CONTRACT_WRITER_NAMESPACE_KEY = 'JELARARAGI_SMART_WORKSPACE_SUITE_JSON_WRITER_ID_V1'
_FALLBACK_CONTRACT_WRITER_ID = ''
_LAST_N_PANEL_COMMIT_RESULT: dict[str, Any] | None = None


def _contract_writer_id() -> str:
    global _FALLBACK_CONTRACT_WRITER_ID
    if bpy is not None:
        try:
            namespace = bpy.app.driver_namespace
            value = namespace.get(_CONTRACT_WRITER_NAMESPACE_KEY)
            if not isinstance(value, str) or not value.strip():
                value = _strict_json.new_writer_id(PACKAGE_ID)
                namespace[_CONTRACT_WRITER_NAMESPACE_KEY] = value
            return value
        except Exception:
            pass
    if not _FALLBACK_CONTRACT_WRITER_ID:
        _FALLBACK_CONTRACT_WRITER_ID = _strict_json.new_writer_id(PACKAGE_ID)
    return _FALLBACK_CONTRACT_WRITER_ID


def invalidate_central_cache() -> None:
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED
    _CENTRAL_PAYLOAD_CACHE = None
    _CENTRAL_PAYLOAD_SIGNATURE = None
    _CENTRAL_PAYLOAD_VALIDATED = False


def n_panel_current_settings_key(path: str | Path) -> str:
    key = _normalize_central_storage_key(_central_file_key(path))
    if not key:
        key = 'config/n-panel_manager/current_settings.json'
    return key


def resolve_n_panel_current_settings(path: str | Path, *, repair_primary: bool = True):
    target = Path(path)
    return _strict_json.resolve_current_authority(
        target,
        target.with_name(target.name + '.bak'),
        central_settings_path(create=False),
        n_panel_current_settings_key(target),
        repair_primary=repair_primary,
    )


def commit_n_panel_current_settings(
    path: str | Path,
    values: dict[str, Any],
    *,
    state_save_enabled: bool,
    central_updates: dict[str, Any] | None = None,
) -> bool:
    """Commit primary and central; return verified Boolean success."""
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED, _LAST_N_PANEL_COMMIT_RESULT
    _LAST_N_PANEL_COMMIT_RESULT = None
    if not isinstance(values, dict):
        raise TypeError('N-panel values must be a dict')
    enabled = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    central_base = _central_read_payload()
    if isinstance(central_updates, dict):
        for key, value in central_updates.items():
            central_base[str(key)] = copy.deepcopy(value)
    committed = _strict_json.commit_current_and_central(
        primary_path=path,
        central_path=central_settings_path(create=True),
        current_key=n_panel_current_settings_key(path),
        current_payload=values,
        central_base=central_base,
        writer_id=_contract_writer_id(),
        state_save_enabled=enabled,
    )
    result = _strict_json.last_commit_result()
    if committed is not True or not isinstance(result, dict) or result.get('success') is not True:
        raise _strict_json.ContractError('N-panel strict transaction result unavailable')
    _CENTRAL_PAYLOAD_CACHE = copy.deepcopy(result['central'])
    _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(central_settings_path(create=False))
    _CENTRAL_PAYLOAD_VALIDATED = True
    _LAST_N_PANEL_COMMIT_RESULT = copy.deepcopy(result)
    return True


def last_n_panel_commit_result() -> dict[str, Any] | None:
    """Return a copy of the last verified N-panel save result."""
    return copy.deepcopy(_LAST_N_PANEL_COMMIT_RESULT) if isinstance(_LAST_N_PANEL_COMMIT_RESULT, dict) else None


_EXPLICIT_CENTRAL_METADATA_KEYS = frozenset({
    'contract', 'contract_version', 'schema', 'schema_version', 'addon',
    'settings_file', 'revision', 'writer_id', 'authority', 'payload_checksum',
    'saved_at', CENTRAL_N_PANEL_STATE_SAVE_KEY,
})


def _explicit_state_save_from_current(current_payload: dict[str, Any]) -> bool:
    ui_state = current_payload.get('ui_state')
    if not isinstance(ui_state, dict):
        ui_state = {}
    return _strict_json.strict_bool(
        ui_state.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
        default=True,
        field=f'current.ui_state.{CENTRAL_N_PANEL_STATE_SAVE_KEY}',
    )


def _detached_strict_json(value: Any, *, source: str) -> Any:
    raw = _strict_json.canonical_json_bytes(value, pretty=False)
    return _strict_json.strict_json_loads(raw.decode('utf-8'), source=source)


def _remove_embedded_current_authorities(files: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in files.items():
        clean_key = _strict_json._validate_central_file_key(key, source='explicit-central-files')
        if clean_key.lower().endswith('n-panel_manager/current_settings.json'):
            continue
        result[clean_key] = _detached_strict_json(value, source=f'explicit-central:{clean_key}')
    return result


def _explicit_central_base(
    value: dict[str, Any] | None,
    *,
    state_save_enabled: bool,
    preserve_local_when_missing: bool,
) -> dict[str, Any]:
    """Return a metadata-free central base for an explicit adopt transaction."""
    if isinstance(value, dict):
        try:
            source, _legacy = _strict_json.validate_central_payload(
                value,
                allow_legacy=True,
                source='explicit-central-base',
            )
        except Exception:
            # parse_explicit_settings_import() already performs strict salvage;
            # this fallback accepts a bounded internal base assembled by that
            # helper, never an arbitrary unvalidated document.
            source = _detached_strict_json(value, source='explicit-central-base')
    elif preserve_local_when_missing and central_payload_validated():
        source = _central_read_payload()
    else:
        source = _central_empty_payload()
    base = {
        str(key): copy.deepcopy(item)
        for key, item in source.items()
        if str(key) not in _EXPLICIT_CENTRAL_METADATA_KEYS
    }
    files = base.get('files')
    if not isinstance(files, dict):
        files = {}
    base['files'] = _remove_embedded_current_authorities(files)
    base['blender_version'] = _blender_version()
    base[CENTRAL_N_PANEL_STATE_SAVE_KEY] = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    _detached_strict_json(base, source='explicit-central-base-final')
    return base


def _validate_explicit_current_candidate(value: Any, *, source: str):
    """Validate strict current JSON or bounded pre-contract authority JSON.

    Builds before the strict contract sometimes emitted ``revision`` or
    ``writer_id`` fields without the contract/checksum pair.  The normal
    validator correctly rejects that ambiguous partial authority.  Explicit
    user import may salvage it only when the remaining document is a recognized
    N-panel schema; imported authority metadata is discarded because the local
    adopt transaction always assigns a fresh revision and writer.
    """
    try:
        return _strict_json.validate_current_payload(
            value, allow_legacy=True, source=source
        )
    except Exception as original_error:
        if not isinstance(value, dict):
            raise
        if value.get('contract') == _strict_json.CONTRACT_NAME:
            raise
        candidate = copy.deepcopy(value)
        if not _strict_json._recognize_legacy_current(candidate):
            raise original_error
        for key in (
            'contract', 'contract_version', 'revision', 'writer_id',
            'authority', 'payload_checksum', 'saved_at',
        ):
            candidate.pop(key, None)
        try:
            normalized, _migrated = _strict_json.validate_current_payload(
                candidate, allow_legacy=True, source=f'{source}:pre-contract'
            )
        except Exception:
            raise original_error
        return normalized, True


def parse_explicit_settings_import(document: Any) -> dict[str, Any]:
    """Parse strict or pre-1.1.151 settings without adopting its old revision.

    Returns a normalized current payload, an optional detached central base,
    strict State Save policy, and the recognized format.  Legacy envelopes with
    revision-like fields but no strict checksum are salvaged only when their
    bounded ``files`` graph contains one recognized N-panel payload.
    """
    if not isinstance(document, dict):
        raise _strict_json.CandidateInvalid('explicit import root must be an object')
    errors: list[str] = []

    try:
        central, migrated = _strict_json.validate_central_payload(
            document,
            allow_legacy=True,
            source='explicit-central-import',
        )
        current_entries = [
            (str(key), value)
            for key, value in central.get('files', {}).items()
            if str(key).replace('\\', '/').lower().endswith('n-panel_manager/current_settings.json')
        ]
        if len(current_entries) != 1:
            raise _strict_json.CandidateInvalid(
                'explicit central import must contain exactly one N-panel authority'
            )
        current, current_migrated = _validate_explicit_current_candidate(
            current_entries[0][1],
            source=f'explicit-central-current:{current_entries[0][0]}',
        )
        enabled = _strict_json.strict_bool(
            central.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
            default=True,
            field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
        return {
            'current_payload': current,
            'central_payload': central,
            'state_save_enabled': enabled,
            'format': 'central-legacy' if migrated or current_migrated else 'central-strict',
        }
    except Exception as exc:
        errors.append(f'central:{type(exc).__name__}:{exc}')

    # Pre-contract central exports could contain a revision field without the
    # strict contract/checksum, which intentionally fails the validator above.
    # Salvage only a strict JSON files graph with one recognized current entry.
    files_value = document.get('files')
    if isinstance(files_value, dict):
        try:
            clean_files: dict[str, Any] = {}
            current = None
            current_migrated = False
            for raw_key, raw_value in files_value.items():
                key = _strict_json._validate_central_file_key(
                    raw_key,
                    source='explicit-legacy-central',
                )
                copied = _detached_strict_json(
                    raw_value,
                    source=f'explicit-legacy-central:{key}',
                )
                if key.lower().endswith('n-panel_manager/current_settings.json'):
                    if current is not None:
                        raise _strict_json.CandidateInvalid(
                            'legacy central import contains multiple N-panel authorities'
                        )
                    current, current_migrated = _validate_explicit_current_candidate(
                        copied,
                        source=f'explicit-legacy-current:{key}',
                    )
                clean_files[key] = copied
            if not isinstance(current, dict):
                raise _strict_json.CandidateInvalid(
                    'legacy central import contains no recognized N-panel settings'
                )
            if CENTRAL_N_PANEL_STATE_SAVE_KEY in document:
                enabled = _strict_json.strict_bool(
                    document.get(CENTRAL_N_PANEL_STATE_SAVE_KEY),
                    field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
                )
            else:
                enabled = _explicit_state_save_from_current(current)
            central_base = _central_empty_payload()
            central_base['files'] = clean_files
            if isinstance(document.get('rna_state'), dict):
                central_base['rna_state'] = _detached_strict_json(
                    document['rna_state'], source='explicit-legacy-rna-state'
                )
            central_base[CENTRAL_N_PANEL_STATE_SAVE_KEY] = enabled
            return {
                'current_payload': current,
                'central_payload': central_base,
                'state_save_enabled': enabled,
                'format': 'central-pre-contract',
            }
        except Exception as exc:
            errors.append(f'legacy-central:{type(exc).__name__}:{exc}')

    current_candidates = [
        ('root', document),
        ('current_settings', document.get('current_settings')),
        ('n_panel_settings', document.get('n_panel_settings')),
        ('n_panel_manager', document.get('n_panel_manager')),
    ]
    for label, candidate in current_candidates:
        if not isinstance(candidate, dict):
            continue
        try:
            current, migrated = _validate_explicit_current_candidate(
                candidate,
                source=f'explicit-current-import:{label}',
            )
            return {
                'current_payload': current,
                'central_payload': None,
                'state_save_enabled': _explicit_state_save_from_current(current),
                'format': 'current-legacy' if migrated else 'current-strict',
            }
        except Exception as exc:
            errors.append(f'{label}:{type(exc).__name__}:{exc}')
    raise _strict_json.CandidateInvalid(
        'settings import is not a recognized Smart Workspace payload; '
        + ' | '.join(errors[:6])
    )


def adopt_n_panel_current_settings(
    path: str | Path,
    values: dict[str, Any],
    *,
    state_save_enabled: bool,
    central_payload: dict[str, Any] | None = None,
    preserve_local_when_missing: bool = True,
    source: str = 'explicit-user-operation',
) -> bool:
    """Adopt an explicit import/export graph as a new local authority revision.

    This operation is intentionally independent of lifecycle snapshot fences.
    Imported revision/writer/checksum metadata is validated but never reused as
    local authority.  The local strict contract assigns ``max(local)+1`` and
    verifies primary, central, and embedded readback before success.
    """
    global _CENTRAL_PAYLOAD_CACHE, _CENTRAL_PAYLOAD_SIGNATURE
    global _CENTRAL_PAYLOAD_VALIDATED, _LAST_N_PANEL_COMMIT_RESULT
    _LAST_N_PANEL_COMMIT_RESULT = None
    if not isinstance(values, dict):
        raise TypeError('explicit N-panel values must be a dict')
    normalized, _migrated = _strict_json.validate_current_payload(
        values,
        allow_legacy=True,
        source=str(source or 'explicit-user-operation'),
    )
    enabled = _strict_json.strict_bool(
        state_save_enabled,
        field=CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )
    base = _explicit_central_base(
        central_payload,
        state_save_enabled=enabled,
        preserve_local_when_missing=bool(preserve_local_when_missing),
    )
    target = Path(path)
    committed = _strict_json.commit_current_and_central(
        primary_path=target,
        central_path=central_settings_path(create=True),
        current_key=n_panel_current_settings_key(target),
        current_payload=normalized,
        central_base=base,
        writer_id=_contract_writer_id(),
        state_save_enabled=enabled,
    )
    result = _strict_json.last_commit_result()
    if committed is not True or not isinstance(result, dict) or result.get('success') is not True:
        raise _strict_json.ContractError('explicit authority adoption result unavailable')
    primary = result.get('primary')
    central = result.get('central')
    if not isinstance(primary, dict) or not isinstance(central, dict):
        raise _strict_json.ContractError('explicit authority readback is incomplete')
    expected = _strict_json.finalize_current_payload(
        normalized,
        revision=int(result['revision']),
        writer_id=str(result['writer_id']),
        authority='primary',
    )
    if primary.get('payload_checksum') != expected.get('payload_checksum'):
        raise _strict_json.ContractError('explicit authority semantic checksum mismatch')
    current_key = n_panel_current_settings_key(target)
    embedded = central.get('files', {}).get(current_key)
    embedded, _legacy = _strict_json.validate_current_payload(
        embedded,
        allow_legacy=False,
        source='explicit-authority-central-readback',
    )
    for field in ('revision', 'writer_id', 'payload_checksum'):
        if primary.get(field) != embedded.get(field):
            raise _strict_json.ContractError(f'explicit authority {field} mismatch')
    _CENTRAL_PAYLOAD_CACHE = copy.deepcopy(central)
    _CENTRAL_PAYLOAD_SIGNATURE = _central_file_signature(central_settings_path(create=False))
    _CENTRAL_PAYLOAD_VALIDATED = True
    _LAST_N_PANEL_COMMIT_RESULT = copy.deepcopy(result)
    return True
