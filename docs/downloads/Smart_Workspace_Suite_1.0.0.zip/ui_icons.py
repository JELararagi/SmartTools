# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Smart Workspace UI icon helpers.

This add-on prioritizes Blender standard icons for every icon button.
Custom PNG icons are not bundled in this cleaned build.  Icon-only controls
are drawn as normal embossed buttons so Blender highlights the button on hover.
"""

from __future__ import annotations

from typing import Any


class _NullOperatorProxy:
    """Accept assigned operator properties when drawing had to fall back to a no-op."""

    def __setattr__(self, name: str, value: Any) -> None:
        object.__setattr__(self, name, value)

    def __getattr__(self, name: str) -> Any:
        return None


_FALLBACKS: dict[str, str] = {
    'plus': 'ADD',
    'minus': 'REMOVE',
    'up': 'TRIA_UP',
    'down': 'TRIA_DOWN',
    'left': 'BACK',
    'right': 'FORWARD',
    'launch': 'PLAY',
    'window': 'WINDOW',
    'panel': 'MENU_PANEL',
    'folder': 'FILE_FOLDER',
    'file': 'FILE',
    'runfile': 'FILE_SCRIPT',
    'refresh': 'FILE_REFRESH',
    'trash': 'TRASH',
    'help': 'QUESTION',
    'settings': 'PREFERENCES',
    'pin': 'PINNED',
    'unpin': 'UNPINNED',
    'search': 'VIEWZOOM',
    'check': 'CHECKMARK',
    'close': 'PANEL_CLOSE',
    'copy': 'DUPLICATE',
    'import': 'IMPORT',
    'export': 'EXPORT',
    'preset': 'PRESET',
    'camera': 'CAMERA_DATA',
    'menu': 'COLLAPSEMENU',
    'star': 'SOLO_OFF',
    'favorite': 'SOLO_ON',
    'keyboard': 'EVENT_K',
    'sync': 'UV_SYNC_SELECT',
    'eye': 'HIDE_OFF',
    'hidden': 'HIDE_ON',
    'repair': 'LOOP_BACK',
    'tool': 'TOOL_SETTINGS',
    'pie': 'MENU_PANEL',
    'toggle_on': 'CHECKBOX_HLT',
    'toggle_off': 'CHECKBOX_DEHLT',
    'lock': 'LOCKED',
    'unlock': 'UNLOCKED',
    'script': 'FILE_SCRIPT',
    'workspace': 'WORKSPACE',
    'info': 'INFO',
    'header': 'WORKSPACE',
    'clock': 'TIME',
}


def register() -> None:
    return None


def unregister() -> None:
    return None


def icon_value(name: str, default: int = 0) -> int:
    return int(default)


def fallback_icon(name: str, fallback: str = 'NONE') -> str:
    key = str(name or '').strip()
    return str(_FALLBACKS.get(key, fallback) or fallback or 'NONE')


def icon_kwargs(name: str, fallback: str = 'NONE') -> dict[str, Any]:
    return {'icon': fallback_icon(name, fallback)}


def set_large_icon_scale(layout: Any, scale: float = 1.45) -> None:
    try:
        layout.scale_y = max(float(getattr(layout, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass


def label(layout: Any, text: str = '', name: str = 'info', *, fallback: str = 'INFO', translate: bool = True) -> Any:
    try:
        return layout.label(text=text, translate=translate, **icon_kwargs(name, fallback))
    except Exception:
        for icon_name in (fallback_icon(name, fallback), 'NONE'):
            try:
                return layout.label(text=text, translate=translate, icon=icon_name)
            except Exception:
                pass
        try:
            return layout.label(text=text, translate=translate)
        except Exception:
            return None


def operator(
    layout: Any,
    operator_id: str,
    *,
    name: str,
    text: str = '',
    fallback: str = 'NONE',
    emboss: bool | None = None,
    depress: bool | None = None,
) -> Any:
    kwargs = {'text': text}
    icon_only = not bool(str(text or '').strip())
    if icon_only:
        if str(name or '').strip() == 'help':
            try:
                layout.scale_x = 0.82
                layout.scale_y = 1.0
            except Exception:
                pass
        else:
            set_large_icon_scale(layout, 1.65)
    kwargs.update(icon_kwargs(name, fallback))
    if icon_only:
        kwargs['emboss'] = True
    elif emboss is not None:
        kwargs['emboss'] = emboss
    if depress is not None:
        kwargs['depress'] = depress

    attempts: list[dict[str, Any]] = [dict(kwargs)]

    no_emboss_kwargs = dict(kwargs)
    if not icon_only:
        no_emboss_kwargs.pop('emboss', None)
    attempts.append(no_emboss_kwargs)

    none_icon_kwargs = dict(no_emboss_kwargs)
    none_icon_kwargs['icon'] = 'NONE'
    attempts.append(none_icon_kwargs)

    attempts.append({'text': text})

    for candidate in attempts:
        try:
            return layout.operator(operator_id, **candidate)
        except Exception:
            continue

    try:
        layout.label(text=text or '', icon='NONE')
    except Exception:
        pass
    return _NullOperatorProxy()


def prop(layout: Any, owner: Any, prop_name: str, *, name: str, text: str = '', fallback: str = 'NONE', **kwargs: Any) -> Any:
    params = {'text': text}
    icon_only = not bool(str(text or '').strip())
    if icon_only:
        if str(name or '').strip() == 'help':
            try:
                layout.scale_x = 0.82
                layout.scale_y = 1.0
            except Exception:
                pass
        else:
            set_large_icon_scale(layout, 1.65)
    params.update(kwargs)
    if icon_only:
        params['emboss'] = True
    params.update(icon_kwargs(name, fallback))

    attempts: list[dict[str, Any]] = [dict(params)]

    none_icon_params = dict(params)
    none_icon_params['icon'] = 'NONE'
    attempts.append(none_icon_params)

    text_only_params = dict(kwargs)
    text_only_params['text'] = text
    attempts.append(text_only_params)

    for candidate in attempts:
        try:
            return layout.prop(owner, prop_name, **candidate)
        except Exception:
            continue

    try:
        layout.label(text=text or prop_name, icon='NONE')
    except Exception:
        pass
    return None
