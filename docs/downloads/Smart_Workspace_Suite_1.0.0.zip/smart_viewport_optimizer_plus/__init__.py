# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Smart Viewport Optimizer Plus",
    "author": "JELararagi",
    "version": (11, 4, 1),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar (N) > Smart Tools",
    "description": "Temporarily applies Blender-standard viewport, overlay, object, modifier, preference, and navigation settings only while the toggle is ON; restores the saved baseline on OFF/file events.",
    "category": "3D View",
}

import datetime
import hashlib
import json
import os
import re
import sys
import tempfile
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import bpy
from bpy.app.handlers import persistent

from .. import translation as _suite_translation

try:
    from .. import storage as _sws_storage
except Exception:
    _sws_storage = None

ADDON_ID = "smart_viewport_optimizer_plus"
STORAGE_DIRNAME = "viewport_optimizer"
ADDON_NAME = "Smart Viewport Optimizer Plus"
ADDON_VERSION = "11.4.1"

# -----------------------------------------------------------------------------
# Translation
# -----------------------------------------------------------------------------

_TRANSLATIONS_JA = {
    # Panels / labels
    "Smart Viewport Optimizer Plus": 'ビューポート最適化',
    "Smart Tools": "スマートツール",
    "Quick Controls": "クイック操作",
    "Groups": "対象グループ",
    "Scene Simplify": "シーン簡略化",
    "Viewport Shading": "ビューポート描画",
    "Overlays": "オーバーレイ",
    "Gizmos": "ギズモ",
    "Viewport Object Filters": "ビューポート表示フィルター",
    "Object Display": "オブジェクト表示",
    "Modifiers": "モディファイア",
    "Particles": "パーティクル",
    "Preferences": "プリファレンス",
    "Navigation Start Lag": "ナビゲーション初動ラグ",
    "System Latency": "システム遅延対策",
    "Constraints": "制約",
    "Viewport Prewarm": "ビューポート事前ウォームアップ",
    "Snapshot": "スナップショット",
    "Unsupported or missing property calls are skipped safely.": "未対応または存在しないプロパティは安全にスキップされます。",
    "Stored snapshot": "保存済みスナップショット",
    "No snapshot stored": "スナップショット未保存",
    "Apply Performance Preset": "パフォーマンスプリセットを適用",
    "Apply Current Options": "現在の設定を適用",
    "Restore Snapshot": "スナップショットを復元",
    "Reset Options to Performance High": "設定をパフォーマンス優先：高へ戻す",
    "Clear Snapshot": "スナップショットを消去",
    "Capture Snapshot": "現在状態を保存",
    "Status": "状態",
    "Ready": "待機中",
    "Applied": "適用済み",
    "Restored": "復元済み",
    "Snapshot cleared": "スナップショット消去済み",
    "Snapshot captured": "スナップショット保存済み",
    "No stored snapshot was found. Nothing was restored.": "保存済みスナップショットが見つかりません。復元は行われませんでした。",
    "Performance preset options were restored.": "パフォーマンスプリセット設定に戻しました。",
    "Smart Viewport Optimizer Plus: applied current options.": 'ビューポート最適化: 現在の設定を適用しました。',
    "Smart Viewport Optimizer Plus: restored the stored snapshot.": 'ビューポート最適化: 保存済みスナップショットを復元しました。',
    "Smart Viewport Optimizer Plus: snapshot captured.": 'ビューポート最適化: 現在状態を保存しました。',
    "Smart Viewport Optimizer Plus: snapshot cleared.": 'ビューポート最適化: スナップショットを消去しました。',
    "Smart Viewport Optimizer Plus: performance preset options reset.": 'ビューポート最適化: パフォーマンスプリセット設定へ戻しました。',
    "Snapshot contains the previous viewport/object/modifier state captured before optimization. Restore it to return the scene closer to its original state.": "スナップショットには、最適化前に取得したビューポート、オブジェクト、モディファイアの状態が保存されます。復元すると元の状態に近づけられます。",

    # Operators descriptions
    "Apply the default high-performance viewport preset, save a repair backup if needed, and immediately update configured targets.": "既定の高パフォーマンスビューポートプリセットを適用し、必要に応じて修復用バックアップを保存してから対象設定を即時更新します。",
    "Apply the current individual ON/OFF options without changing the option values.": "個別のON/OFF設定値は変更せず、現在の設定内容をそのまま適用します。",
    "Restore the state captured before the optimizer changed viewport, object, modifier, particle, and preference settings.": "最適化前に保存したビューポート、オブジェクト、モディファイア、パーティクル、プリファレンス設定を復元します。",
    "Set all optimization options back to the Performance Priority: High preset.": "すべての最適化項目をパフォーマンス優先：高プリセットへ戻します。",
    "Delete the stored restore snapshot. This does not change the current scene or viewport settings.": "保存済みの復元用スナップショットを削除します。現在のシーンやビューポート設定は変更しません。",
    "Capture the current state as the restore snapshot without applying optimization.": "最適化を適用せず、現在状態だけを復元用スナップショットとして保存します。",

    # Settings names and descriptions
    "Apply on add-on enable": "アドオン有効化時に適用",
    "Automatically apply the lightweight preset once after the add-on is enabled. Use this when you want the viewport to become light immediately after installation or activation.": "アドオンを有効化した直後に、軽量化プリセットを一度だけ自動適用します。インストールや有効化後すぐにビューポートを軽くしたい場合に使います。",
    "Apply on file load": "ファイル読込時に適用",
    "Automatically re-apply the selected lightweight options after a .blend file is loaded. This is useful when heavy scenes reopen in an expensive viewport state.": ".blendファイルを読み込んだ後、選択中の軽量化設定を自動で再適用します。重いビューポート状態でファイルが開かれる場合に便利です。",
    "Protect existing snapshot": "既存スナップショットを保護",
    "Keep the first captured restore snapshot instead of overwriting it on every apply. Leave this on when you want Restore Snapshot to return to the state before the first optimization.": "適用のたびに上書きせず、最初に取得した復元用スナップショットを保持します。復元時に最初の最適化前の状態へ戻したい場合は有効のままにします。",
    "Apply all scenes": "全シーンへ適用",
    "Apply scene-level Simplify settings to every scene in the file, not only the active scene. This helps when multiple scenes share heavy assets.": "シーン単位の簡略化設定をアクティブシーンだけでなくファイル内の全シーンへ適用します。複数シーンが重いアセットを共有している場合に有効です。",
    "Object scope": "オブジェクト対象範囲",
    "Choose which objects are affected by object display, modifier, and particle optimization. All gives the strongest speed-up, while Selected is safer for focused editing.": "オブジェクト表示、モディファイア、パーティクルの最適化対象を選びます。全オブジェクトは最も軽くなり、選択中のみは集中編集時に安全です。",
    "All Objects": "全オブジェクト",
    "Selected Objects": "選択中のみ",
    "Visible Objects": "表示中のみ",
    "Include Scene Simplify": "シーン簡略化を対象にする",
    "Enable the scene Simplify section. When on, the add-on can force lower subdivision, volume, texture, Grease Pencil, and particle preview cost.": "シーン簡略化セクションを有効にします。ONにすると、サブディビジョン、ボリューム、テクスチャ、グリースペンシル、パーティクルのプレビュー負荷を下げられます。",
    "Include Viewport Shading": "ビューポート描画を対象にする",
    "Enable viewport shading optimization. This changes each 3D View to wireframe or flat solid display and disables expensive lighting effects.": "ビューポート描画の最適化を有効にします。各3Dビューをワイヤーまたはフラットなソリッド表示へ変更し、高負荷なライティング効果を無効にします。",
    "Include Overlays": "オーバーレイを対象にする",
    "Enable overlay optimization. Relationship lines, grid axes, normals, edit guides, annotations, and statistics can be hidden to reduce redraw work.": "オーバーレイ最適化を有効にします。リレーションライン、グリッド軸、法線、編集ガイド、注釈、統計表示を隠して再描画負荷を下げられます。",
    "Include Gizmos": "ギズモを対象にする",
    "Enable gizmo optimization. Transform, tool, context, and navigation gizmos can be hidden so the viewport has fewer interactive elements to draw and update.": "ギズモ最適化を有効にします。移動、ツール、コンテキスト、ナビゲーションの各ギズモを隠し、描画と更新が必要な操作要素を減らします。",
    "Include Object Filters": "表示フィルターを対象にする",
    "Enable viewport object-type filters. Cameras, lights, empties, armatures, curves, volumes, and other helper types can be hidden in the 3D View without deleting them.": "ビューポートのオブジェクト種類フィルターを有効にします。カメラ、ライト、エンプティ、アーマチュア、カーブ、ボリュームなどを削除せず3Dビュー上で非表示にできます。",
    "Include Object Display": "オブジェクト表示を対象にする",
    "Enable per-object display optimization. Objects can be switched to bounding box or wire display, which is often much lighter than shaded geometry.": "オブジェクト単位の表示最適化を有効にします。オブジェクトをバウンディングボックスやワイヤー表示に変更でき、シェーディングされた形状より軽くなりやすいです。",
    "Include Modifiers": "モディファイアを対象にする",
    "Enable modifier viewport suppression. Expensive viewport modifiers can be disabled temporarily and restored from the snapshot later.": "モディファイアのビューポート抑制を有効にします。重いモディファイアを一時的に無効化し、後でスナップショットから復元できます。",
    "Include Particles": "パーティクルを対象にする",
    "Enable particle preview reduction. Particle display percentage and draw steps can be reduced to make dense particle systems lighter in the viewport.": "パーティクルプレビュー削減を有効にします。表示率や描画ステップを下げることで、密度の高いパーティクルを軽く表示できます。",
    "Include Preferences": "プリファレンスを対象にする",
    "Enable session-level preference optimization. This can disable viewport anti-aliasing and reduce cache retention for the current Blender session without saving user preferences.": "セッション単位のプリファレンス最適化を有効にします。ユーザー設定を保存せず、現在のBlenderセッションでビューポートAA無効化やキャッシュ保持の削減を行えます。",

    "Use Simplify": "簡略化を有効化",
    "Turn on Blender's Simplify system for the target scene. Simplify is a global scene switch that lets Blender use cheaper viewport representations.": "対象シーンでBlenderの簡略化を有効化します。簡略化はシーン全体の表示を低負荷にできるグローバルな切り替えです。",
    "Force subdivision level": "サブディビジョン段階を固定",
    "Clamp the viewport subdivision preview level. Set the value to 0 for the strongest speed-up on Subdivision Surface and similar preview levels.": "ビューポートのサブディビジョンプレビュー段階を制限します。0にするとサブディビジョンサーフェスなどのプレビュー負荷を最も強く下げます。",
    "Subdivision level": "サブディビジョン段階",
    "Viewport subdivision level used when Force subdivision level is on. Lower values are lighter; 0 means no viewport subdivision preview.": "サブディビジョン段階固定がONのときに使うビューポート段階です。値が低いほど軽く、0はプレビュー分割なしを意味します。",
    "Force volume resolution": "ボリューム解像度を固定",
    "Reduce viewport volume resolution through Simplify. A value of 0 is the lightest and can make volumetric previews very coarse or hidden depending on Blender internals.": "簡略化でビューポートのボリューム解像度を下げます。0は最軽量で、Blenderの内部処理によっては非常に粗い表示または非表示になります。",
    "Volume value": "ボリューム値",
    "Volume Simplify value applied to scenes. Smaller values are lighter and reduce the cost of volume drawing.": "シーンへ適用するボリューム簡略化値です。小さい値ほど軽く、ボリューム描画の負荷を下げます。",
    "Force child particle percentage": "子パーティクル表示率を固定",
    "Reduce the scene-level child particle percentage. Set this to 0 for maximum speed when hair or instanced particles are heavy.": "シーン単位の子パーティクル表示率を下げます。ヘアやインスタンス系パーティクルが重い場合、0で最も軽くなります。",
    "Child particle percentage": "子パーティクル表示率",
    "Percentage of child particles kept by scene Simplify. Lower values reduce particle drawing and evaluation cost.": "シーンの簡略化で保持する子パーティクルの割合です。低い値ほどパーティクルの描画と評価の負荷を下げます。",
    "Force texture size": "テクスチャサイズを制限",
    "Ask Simplify to limit viewport texture size where Blender exposes that property. This reduces texture upload and sampling cost in material-like display modes.": "Blenderが対応する場合、簡略化でビューポートテクスチャサイズを制限します。マテリアル系表示でのテクスチャ転送や参照負荷を下げます。",
    "Texture size": "テクスチャサイズ",
    "Texture size limit used by Simplify when available. Smaller values are lighter but blurrier.": "対応環境で簡略化に使用するテクスチャサイズ上限です。小さい値ほど軽くなりますが、表示は粗くなります。",
    "Simplify Grease Pencil": "グリースペンシル簡略化",
    "Enable Grease Pencil simplification when the property exists. This helps scenes containing many strokes or complex Grease Pencil objects.": "対応プロパティがある場合、グリースペンシルの簡略化を有効にします。大量のストロークや複雑なグリースペンシルを含むシーンで有効です。",

    "Force wireframe mode": "ワイヤーフレーム表示へ変更",
    "Switch every 3D View to Wireframe mode. This is the most aggressive display shortcut because surfaces, materials, shadows, and many lighting calculations are bypassed.": "すべての3Dビューをワイヤーフレーム表示へ変更します。面、マテリアル、影、多くのライティング計算を避けるため、最も強力な表示軽量化です。",
    "Use flat solid fallback": "フラットソリッドを使用",
    "When wireframe mode is off, switch the viewport to Solid mode with Flat lighting. This keeps shaded shapes visible while avoiding studio and material lighting cost.": "ワイヤーフレーム表示がOFFのとき、フラットライティングのソリッド表示へ変更します。形状の面表示を残しつつ、スタジオやマテリアル照明の負荷を避けます。",
    "Use single color": "単色表示を使用",
    "Use a single viewport color instead of material, texture, object, or random colors. This reduces color lookup complexity and makes dense scenes easier to redraw.": "マテリアル、テクスチャ、オブジェクト、ランダム色ではなく単色表示を使います。色参照の複雑さを下げ、密なシーンを再描画しやすくします。",
    "Disable shadows": "影を無効化",
    "Hide viewport shadows. Shadows add extra drawing work, so disabling them improves navigation responsiveness on weaker GPUs or very heavy scenes.": "ビューポートの影を非表示にします。影は追加の描画処理を必要とするため、低性能GPUや重いシーンで操作の反応を改善します。",
    "Disable cavity": "キャビティを無効化",
    "Disable cavity shading. Cavity highlights edges and surface dents, but it adds screen-space shading work that is unnecessary in a pure speed mode.": "キャビティ表示を無効化します。キャビティはエッジや凹凸を強調しますが、速度優先時には不要なスクリーンスペース処理を増やします。",
    "Disable object outlines": "オブジェクト輪郭を無効化",
    "Disable object outline drawing. Outlines are useful for visibility but require additional overlay-style drawing around selected or visible objects.": "オブジェクト輪郭描画を無効化します。輪郭は視認性に便利ですが、選択中または表示中オブジェクト周囲の追加描画を必要とします。",
    "Disable specular highlights": "スペキュラーを無効化",
    "Disable specular highlights in viewport shading. This avoids glossy highlight calculations and gives a flatter, lighter display.": "ビューポート描画のスペキュラーハイライトを無効化します。光沢ハイライト計算を避け、より平坦で軽い表示にします。",
    "Disable X-Ray": "透過表示を無効化",
    "Turn off X-Ray display. X-Ray blends front and back geometry and can increase overdraw, especially in dense meshes.": "透過表示を無効化します。透過表示は前面と背面の形状を合成するため、密なメッシュではオーバードローが増える場合があります。",
    "Disable scene lights": "シーンライトを無効化",
    "Ignore scene lights in viewport display when the property is available. This avoids expensive preview lighting in material or rendered-like modes.": "対応プロパティがある場合、ビューポート表示でシーンライトを無視します。マテリアルまたはレンダー風表示での高負荷なプレビュー照明を避けます。",
    "Disable scene world": "シーンワールドを無効化",
    "Ignore the scene world background in viewport display when available. This keeps the viewport independent from potentially expensive world lighting previews.": "対応プロパティがある場合、ビューポート表示でシーンワールド背景を無視します。高負荷になり得るワールド照明プレビューからビューポートを切り離します。",
    "Enable backface culling": "背面カリングを有効化",
    "Hide back-facing polygons where Blender supports it. This can reduce visible surface work, but double-sided surfaces may look different.": "Blenderが対応する範囲で背面ポリゴンを非表示にします。表示面の処理を減らせますが、両面表示前提の面は見た目が変わる場合があります。",
    "Limit far clip": "遠方クリップを制限",
    "Reduce the 3D View far clipping distance. Objects farther than this distance are not drawn, which can help extremely large scenes.": "3Dビューの遠方クリップ距離を下げます。この距離より遠いオブジェクトは描画されないため、非常に大きなシーンで有効です。",
    "Far clip": "遠方クリップ",
    "Far clipping distance applied to 3D Views. Use a larger value if distant objects disappear unintentionally.": "3Dビューへ適用する遠方クリップ距離です。遠くのオブジェクトが意図せず消える場合は値を大きくします。",
    "Limit near clip": "近方クリップを調整",
    "Set the near clipping distance. A slightly larger near clip can improve depth precision, but too large a value hides close geometry.": "近方クリップ距離を設定します。少し大きくすると深度精度が改善する場合がありますが、大きすぎると近くの形状が消えます。",
    "Near clip": "近方クリップ",
    "Near clipping distance applied to 3D Views. Keep this small if you need to edit close-up details.": "3Dビューへ適用する近方クリップ距離です。近接した細部を編集する場合は小さめに保ちます。",

    "Hide all overlays": "全オーバーレイを非表示",
    "Turn off the overlay master switch. This gives the strongest overlay speed-up because grids, guides, text, normals, and helper drawings are hidden at once.": "オーバーレイのマスタースイッチをOFFにします。グリッド、ガイド、文字、法線、補助表示を一括で隠すため、最も強力なオーバーレイ軽量化です。",
    "Hide relationship lines": "リレーションラインを非表示",
    "Hide parent, constraint, and relationship lines. These helper lines can clutter and slow the viewport in complex rigs or linked scenes.": "親子関係、制約、関連線を非表示にします。複雑なリグやリンクシーンでは、これらの補助線がビューポートを重く見づらくする場合があります。",
    "Hide grid and axes": "グリッドと軸を非表示",
    "Hide the floor grid and axis lines. This reduces background drawing and is useful when you only need object silhouettes or bounding boxes.": "床グリッドと軸線を非表示にします。背景描画を減らせるため、オブジェクトのシルエットやバウンディングボックスだけ確認したい場合に有効です。",
    "Hide text and stats": "テキストと統計を非表示",
    "Hide viewport text information and statistics. This removes small but constant UI overlay updates while navigating or editing.": "ビューポート上のテキスト情報と統計表示を非表示にします。ナビゲーションや編集時に常時更新される小さなUIオーバーレイを減らします。",
    "Hide extras": "エクストラを非表示",
    "Hide extra helper drawings such as light and camera widgets where supported. This is useful when helper objects are not needed during speed-focused editing.": "対応する範囲でライトやカメラなどの補助表示を非表示にします。速度優先の編集で補助オブジェクトが不要な場合に有効です。",
    "Hide wire overlay": "ワイヤーオーバーレイを非表示",
    "Hide additional wire overlays and set their opacity as low as possible. This avoids drawing extra mesh lines over shaded objects.": "追加のワイヤーオーバーレイを非表示にし、可能な限り不透明度を下げます。シェーディング表示上に余分なメッシュ線を描く処理を避けます。",
    "Hide normals": "法線表示を非表示",
    "Hide vertex, face, and split normal overlays. Normal vectors are expensive and unnecessary unless you are debugging mesh direction.": "頂点、面、分割法線のオーバーレイを非表示にします。法線ベクトルは重く、メッシュ方向を確認している時以外は不要です。",
    "Hide edit guides": "編集ガイドを非表示",
    "Hide edit-mode guides such as face centers, seams, sharp edges, crease indicators, and extra indices when available.": "対応する範囲で、面中心、シーム、シャープエッジ、クリース表示、追加インデックスなどの編集モード用ガイドを非表示にします。",
    "Hide motion paths": "モーションパスを非表示",
    "Hide animation motion paths. These can become heavy when many animated objects, bones, or long frame ranges are visible.": "アニメーションのモーションパスを非表示にします。多数のアニメーションオブジェクト、ボーン、長いフレーム範囲があると重くなります。",
    "Hide annotations": "注釈を非表示",
    "Hide annotation strokes and related overlay drawings. This removes extra 2D/3D annotation display work from the viewport.": "注釈ストロークと関連オーバーレイを非表示にします。ビューポート上の追加2D/3D注釈表示処理を減らします。",

    "Hide all gizmos": "全ギズモを非表示",
    "Turn off the 3D View gizmo master switch. This removes transform, tool, and navigation widgets from drawing and hit-testing.": "3DビューのギズモマスタースイッチをOFFにします。変形、ツール、ナビゲーションの各ウィジェットを描画とヒットテスト対象から外します。",
    "Hide navigation gizmo": "ナビゲーションギズモを非表示",
    "Hide the viewport navigation gizmo. This reduces UI drawing in the corner of the 3D View while mouse and keyboard navigation still work.": "ビューポートのナビゲーションギズモを非表示にします。マウスやキーボードでの視点操作は残したまま、3Dビュー隅のUI描画を減らします。",
    "Hide tool gizmos": "ツールギズモを非表示",
    "Hide active tool gizmos. This is useful when you use shortcuts instead of on-screen handles.": "アクティブツールのギズモを非表示にします。画面上のハンドルではなくショートカットで操作する場合に有効です。",
    "Hide context gizmos": "コンテキストギズモを非表示",
    "Hide context-dependent gizmos. This reduces additional widgets that appear depending on the selected object or mode.": "コンテキスト依存のギズモを非表示にします。選択オブジェクトやモードに応じて表示される追加ウィジェットを減らします。",
    "Hide object transform gizmos": "オブジェクト変形ギズモを非表示",
    "Hide object translate, rotate, and scale gizmos. This reduces interactive handle drawing during object manipulation.": "オブジェクトの移動、回転、拡縮ギズモを非表示にします。オブジェクト操作時のインタラクティブなハンドル描画を減らします。",

    "Hide lights": "ライトを非表示",
    "Hide light objects in the 3D View object-type filter. The objects remain in the file and can be shown again by restoring or turning this off.": "3Dビューの種類フィルターでライトを非表示にします。オブジェクトはファイル内に残り、復元または設定OFFで再表示できます。",
    "Hide cameras": "カメラを非表示",
    "Hide camera objects in the viewport filter. This removes camera frame/helper drawing when layout work does not require cameras.": "ビューポートフィルターでカメラを非表示にします。レイアウト作業でカメラが不要な場合、カメラ枠や補助表示の描画を減らします。",
    "Hide empties": "エンプティを非表示",
    "Hide Empty objects in the viewport filter. This is effective in rigged or linked scenes containing many control empties.": "ビューポートフィルターでエンプティを非表示にします。多数の制御用エンプティを含むリグやリンクシーンで有効です。",
    "Hide armatures": "アーマチュアを非表示",
    "Hide armature objects in the viewport filter. This can strongly reduce rig drawing cost, but turn it off when you need to pose or edit bones.": "ビューポートフィルターでアーマチュアを非表示にします。リグ描画負荷を大きく下げられますが、ポーズやボーン編集が必要な場合はOFFにしてください。",
    "Hide curves": "カーブを非表示",
    "Hide curve objects in the viewport filter. Useful for scenes with many bevelled curves, splines, or motion paths represented as curves.": "ビューポートフィルターでカーブを非表示にします。多数のベベル付きカーブ、スプライン、カーブ表現のモーションパスがあるシーンで有効です。",
    "Hide surfaces": "サーフェスを非表示",
    "Hide surface objects in the viewport filter. This reduces display work for NURBS or surface-based assets.": "ビューポートフィルターでサーフェスオブジェクトを非表示にします。NURBSやサーフェスベースのアセット表示負荷を減らします。",
    "Hide fonts": "テキストを非表示",
    "Hide font/text objects in the viewport filter. Text objects can become expensive when converted visually to curves for display.": "ビューポートフィルターでフォント/テキストオブジェクトを非表示にします。テキストは表示時にカーブとして扱われるため、重くなる場合があります。",
    "Hide metaballs": "メタボールを非表示",
    "Hide metaball objects in the viewport filter. Metaballs can be costly because their visible surface is evaluated procedurally.": "ビューポートフィルターでメタボールを非表示にします。メタボールは手続き的に表示面を評価するため、負荷が高くなる場合があります。",
    "Hide lattices": "ラティスを非表示",
    "Hide lattice objects in the viewport filter. This is useful when deformer cages are not needed during navigation.": "ビューポートフィルターでラティスを非表示にします。ナビゲーション時に変形ケージが不要な場合に有効です。",
    "Hide speakers": "スピーカーを非表示",
    "Hide speaker objects in the viewport filter. Audio helper icons are usually unnecessary for geometry-heavy viewport work.": "ビューポートフィルターでスピーカーを非表示にします。ジオメトリ中心のビューポート作業では音声補助アイコンは通常不要です。",
    "Hide light probes": "ライトプローブを非表示",
    "Hide light probe objects in the viewport filter. Light probe helper drawings are not needed for speed-focused editing.": "ビューポートフィルターでライトプローブを非表示にします。速度優先の編集ではライトプローブの補助表示は不要です。",
    "Hide volumes": "ボリュームを非表示",
    "Hide volume objects in the viewport filter. Volumes are often expensive to draw, so hiding them can improve responsiveness dramatically.": "ビューポートフィルターでボリュームを非表示にします。ボリュームは描画負荷が高くなりやすいため、非表示にすると反応が大きく改善する場合があります。",
    "Hide Grease Pencil": "グリースペンシルを非表示",
    "Hide Grease Pencil objects in the viewport filter. This reduces stroke drawing cost in scenes with many 2D or 3D strokes.": "ビューポートフィルターでグリースペンシルオブジェクトを非表示にします。多数の2D/3Dストロークがあるシーンで描画負荷を減らします。",
    "Hide point clouds": "ポイントクラウドを非表示",
    "Hide point cloud objects in the viewport filter when the property exists. Dense point data can be very expensive to draw.": "対応プロパティがある場合、ビューポートフィルターでポイントクラウドを非表示にします。高密度の点群データは描画負荷が非常に高くなる場合があります。",

    "Force object display type": "オブジェクト表示タイプを固定",
    "Set target objects to a cheaper display type. Bounding Box is the lightest because Blender draws only the box around the object.": "対象オブジェクトを低負荷な表示タイプへ変更します。バウンディングボックスはオブジェクトの箱だけを描くため最も軽量です。",
    "Display type": "表示タイプ",
    "Display type assigned to target objects. Bounding Box is fastest, Wire is still light, and Solid is less aggressive.": "対象オブジェクトへ割り当てる表示タイプです。バウンディングボックスが最速、ワイヤーは軽量、ソリッドは比較的控えめです。",
    "Bounding Box": "バウンディングボックス",
    "Wire": "ワイヤー",
    "Solid": "ソリッド",

    "Apply object-level optimization to every object in the file.": "ファイル内の全オブジェクトへオブジェクト単位の最適化を適用します。",
    "Apply object-level optimization only to selected objects.": "選択中のオブジェクトだけへオブジェクト単位の最適化を適用します。",
    "Apply object-level optimization only to objects visible in the current view layer.": "現在のビューレイヤーで表示されているオブジェクトだけへオブジェクト単位の最適化を適用します。",
    "Draw only the object's bounding box.": "オブジェクトのバウンディングボックスだけを描画します。",
    "Draw object geometry as wireframe.": "オブジェクトの形状をワイヤーフレームで描画します。",
    "Draw object geometry as solid shapes.": "オブジェクトの形状をソリッド表示で描画します。",
    "Hide object names and axes": "オブジェクト名と軸を非表示",
    "Disable per-object name, axis, and texture-space helper drawings when available. These small overlays add up in scenes with many objects.": "対応する範囲で、オブジェクト名、軸、テクスチャ空間などの補助表示をOFFにします。多数のオブジェクトがあるシーンでは小さなオーバーレイも負荷になります。",

    "Disable viewport modifiers": "ビューポート用モディファイアを無効化",
    "Temporarily turn off selected modifier categories in the viewport. This is very powerful but changes the preview shape until Restore Snapshot is used.": "選択した種類のモディファイアをビューポート上で一時的にOFFにします。非常に強力ですが、スナップショット復元までプレビュー形状が変わります。",
    "Disable subdivision modifiers": "サブディビジョン系を無効化",
    "Disable Subdivision Surface and Multiresolution modifiers in the viewport. These are common sources of heavy geometry evaluation.": "サブディビジョンサーフェスとマルチレゾリューション系モディファイアをビューポートで無効化します。これらは重い形状評価の代表的な原因です。",
    "Disable Geometry Nodes": "ジオメトリノードを無効化",
    "Disable Geometry Nodes modifiers in the viewport. Node-generated geometry can be extremely heavy, so this often gives a large speed-up.": "ジオメトリノードモディファイアをビューポートで無効化します。ノード生成ジオメトリは非常に重い場合があり、大きな高速化が期待できます。",
    "Disable simulation modifiers": "シミュレーション系を無効化",
    "Disable simulation-related modifiers such as Cloth, Fluid, Soft Body, Dynamic Paint, Ocean, and Particle System in the viewport.": "クロス、流体、ソフトボディ、ダイナミックペイント、オーシャン、パーティクルシステムなどのシミュレーション系をビューポートで無効化します。",
    "Disable deformer modifiers": "変形系を無効化",
    "Disable deformation modifiers such as Armature, Lattice, Mesh Deform, Shrinkwrap, Warp, Curve, and Smooth variants in the viewport.": "アーマチュア、ラティス、メッシュ変形、シュリンクラップ、ワープ、カーブ、スムーズ系などの変形モディファイアをビューポートで無効化します。",
    "Disable generator modifiers": "生成系を無効化",
    "Disable generator modifiers such as Boolean, Bevel, Array, Mirror, Solidify, Remesh, Screw, Skin, and Wireframe in the viewport.": "ブーリアン、ベベル、配列、ミラー、ソリッド化、リメッシュ、スクリュー、スキン、ワイヤーフレームなどの生成系をビューポートで無効化します。",
    "Disable normal/data modifiers": "法線/データ系を無効化",
    "Disable normal and data transfer modifiers such as Weighted Normal, Normal Edit, and Data Transfer in the viewport.": "Weighted Normal、Normal Edit、Data Transferなどの法線/データ系モディファイアをビューポートで無効化します。",
    "Disable other modifiers": "その他を無効化",
    "Disable any modifier category not explicitly listed above. Keep this on for maximum speed, or turn it off if unknown modifiers must stay visible.": "上記に分類されていないモディファイアも無効化します。最速化したい場合はON、未知のモディファイアを表示したい場合はOFFにします。",

    "Reduce particle previews": "パーティクルプレビューを削減",
    "Reduce particle settings used for viewport display. This affects particle data blocks and can be restored from the snapshot.": "ビューポート表示に使われるパーティクル設定を削減します。パーティクルデータブロックに影響しますが、スナップショットから復元できます。",
    "Particle display percentage": "パーティクル表示率",
    "Viewport particle display percentage. 0 is the lightest and hides most particle preview drawing.": "ビューポートでのパーティクル表示率です。0が最軽量で、ほとんどのパーティクルプレビュー描画を隠します。",
    "Particle display step": "パーティクル表示ステップ",
    "Viewport particle draw step when supported. 0 is the cheapest setting and reduces preview sampling.": "対応環境で使うビューポートのパーティクル描画ステップです。0が最も軽く、プレビューサンプリングを減らします。",

    "Disable viewport anti-aliasing": "ビューポートAAを無効化",
    "Set viewport anti-aliasing to Off for the current session when supported. This reduces smoothing quality but can improve redraw speed.": "対応環境で、現在のセッションのビューポートアンチエイリアスをOFFにします。滑らかさは下がりますが、再描画速度が改善する場合があります。",
    "Keep texture/VBO cache warm": "テクスチャ/VBOキャッシュを保持",
    "Keep viewport texture and VBO data alive longer instead of collecting it immediately. This is important for navigation start lag because a short timeout can force Blender to rebuild GPU data when you begin orbiting, panning, or zooming.": "テクスチャとVBOのビューポート用キャッシュをすぐ破棄せず長く保持します。タイムアウトが短いと、回転、移動、ズームを始めた瞬間にGPUデータの再構築が起きやすいため、初動ラグ対策では重要です。",
    "Texture cache seconds": "テクスチャキャッシュ秒数",
    "Seconds Blender keeps viewport textures before collecting them. Larger values reduce reload spikes during repeated navigation, but use more memory.": "Blenderがビューポートテクスチャを回収せず保持する秒数です。大きい値ほど繰り返し操作時の再読み込みスパイクを減らしますが、メモリ使用量は増えます。",
    "VBO cache seconds": "VBOキャッシュ秒数",
    "Seconds Blender keeps viewport VBO buffers before collecting them. Larger values reduce first-move rebuild spikes, but use more memory.": "BlenderがビューポートVBOバッファを回収せず保持する秒数です。大きい値ほど操作開始時の再構築スパイクを減らしますが、メモリ使用量は増えます。",
    "VBO collection rate": "VBO回収間隔",
    "Collection-rate value applied to VBO buffers when the property exists. Higher values make collection less aggressive and reduce cache churn while navigating.": "対応する場合にVBOバッファへ適用する回収間隔です。値を高くすると回収が緩やかになり、ナビゲーション中のキャッシュ破棄と再構築を減らします。",
    "Texture collection rate": "テクスチャ回収間隔",
    "Collection-rate value applied to viewport textures when the property exists. Higher values make collection less aggressive and reduce reloads during navigation.": "対応する場合にビューポートテクスチャへ適用する回収間隔です。値を高くすると回収が緩やかになり、ナビゲーション中の再読み込みを減らします。",
    "GL texture limit": "GLテクスチャ制限",
    "Texture size limit used by the preference system. Lower values can reduce upload and sampling cost in textured views. Off keeps Blender's current default behavior.": "プリファレンス側で使うテクスチャサイズ制限です。値を低くするとテクスチャ表示での転送と参照負荷を下げられます。制限なしはBlenderの現在の既定動作を維持します。",
    "Off": "制限なし",
    "Do not limit texture size.": "テクスチャサイズを制限しません。",
    "Limit viewport textures to 8192 pixels.": "ビューポートテクスチャを8192ピクセルに制限します。",
    "Limit viewport textures to 4096 pixels.": "ビューポートテクスチャを4096ピクセルに制限します。",
    "Limit viewport textures to 2048 pixels.": "ビューポートテクスチャを2048ピクセルに制限します。",
    "Limit viewport textures to 1024 pixels.": "ビューポートテクスチャを1024ピクセルに制限します。",
    "Limit viewport textures to 512 pixels.": "ビューポートテクスチャを512ピクセルに制限します。",
    "Limit viewport textures to 256 pixels.": "ビューポートテクスチャを256ピクセルに制限します。",
    "Limit viewport textures to 128 pixels.": "ビューポートテクスチャを128ピクセルに制限します。",
    "Navigation Start Lag": "ナビゲーション初動ラグ",
    "Enable input, undo, selection, and view settings that directly target the small hitch when orbit, pan, or zoom begins.": "回転、移動、ズームの開始時に発生する小さな引っかかりを直接狙う入力、Undo、選択、ビュー設定を有効化します。",
    "Enable session-level preference optimization. This can disable viewport anti-aliasing and keep viewport cache data warm for the current Blender session without saving user preferences.": "セッション単位のプリファレンス最適化を有効にします。ユーザー設定を保存せず、現在のBlenderセッションでビューポートAA無効化やキャッシュ保持を行えます。",
    "Enable temporary muting of object and pose constraints to reduce dependency-graph evaluation during navigation.": "ナビゲーション中の依存グラフ評価を減らすため、オブジェクト制約とポーズ制約の一時ミュートを有効にします。",
    "Enable redraw and dependency update prewarming so startup cost is shifted before the first manual navigation event.": "初回の手動ナビゲーションイベント前へ開始コストを移すため、再描画と依存更新の事前ウォームアップを有効にします。",
    "Disable depth-based navigation": "深度ベースナビゲーションを無効化",
    "Disable mouse-depth navigation so Blender does not need to query scene depth under the cursor when navigation begins. This can reduce the small hitch before the first orbit, pan, or zoom in heavy scenes.": "マウス位置の下にあるシーン深度を参照するナビゲーションを無効化します。重いシーンで回転、移動、ズームを始める前の小さな引っかかりを減らせる場合があります。",
    "Disable zoom to mouse": "マウス位置ズームを無効化",
    "Disable zoom-to-mouse so zooming does not need a cursor-centered target lookup. Use this when the first wheel zoom or view zoom has a small delay.": "マウス位置を中心にしたズームを無効化します。ズーム時にカーソル中心のターゲット探索を避けるため、ホイールズームやビューズームの初動に遅れがある場合に使います。",
    "Disable rotate around active": "アクティブ中心回転を無効化",
    "Disable rotation around the active selection. This avoids active-object or selection-center calculations and makes navigation pivoting simpler.": "アクティブ選択を中心にした回転を無効化します。アクティブオブジェクトや選択中心の計算を避け、視点回転の基準を単純化します。",
    "Disable auto perspective": "自動パース切替を無効化",
    "Disable automatic orthographic/perspective switching during navigation. This removes an extra view-state change that can occur while starting view movement.": "ナビゲーション中の自動的な平行投影/透視投影切り替えを無効化します。視点移動開始時に起こり得る追加のビュー状態変更を減らします。",
    "Disable smooth view": "スムーズビューを無効化",
    "Set Smooth View to zero so view changes happen immediately without transition animation. This removes animation work and makes the start of navigation feel more direct.": "スムーズビューを0にして、視点変更時の遷移アニメーションを使わないようにします。アニメーション処理を減らし、操作開始の反応を直接的にします。",
    "Hide global navigation UI": "グローバルナビゲーションUIを非表示",
    "Hide the global navigation UI preference where available. This reduces additional UI drawing around the viewport without disabling mouse or keyboard navigation.": "対応する場合、グローバルなナビゲーションUI表示を非表示にします。マウスやキーボードの視点操作は残したまま、ビューポート周辺の追加UI描画を減らします。",
    "Disable overlay smooth wires": "滑らかワイヤーを無効化",
    "Disable smooth wire drawing preferences when available. Smooth wires look nicer, but they can add overhead in dense wire or edit-mode scenes.": "対応する場合、滑らかなワイヤー描画のプリファレンスを無効化します。見た目は良くなりますが、密なワイヤーや編集モードでは負荷が増える場合があります。",
    "Force Object Mode before apply": "適用前にオブジェクトモードへ切替",
    "Switch to Object Mode before applying a preset when that preset requests it. Edit Mode overlays and editable mesh caches can be heavier during navigation.": "プリセットが要求する場合、適用前にオブジェクトモードへ切り替えます。編集モードのオーバーレイや編集メッシュキャッシュは、ナビゲーション中に重くなりやすいためです。",
    "Clear selection on apply": "適用時に選択解除",
    "Deselect objects when applying the speed mode. Selection outlines and selected-object pivot calculations are common causes of first-move lag in large scenes.": "速度優先モードの適用時にオブジェクト選択を解除します。大規模シーンでは、選択輪郭や選択オブジェクト中心の計算が初動ラグの原因になりやすいためです。",
    "Disable object selection hit tests": "オブジェクト選択判定を無効化",
    "Temporarily make target objects unselectable. This reduces selection hit-test and outline-related work while navigating. Restore Snapshot returns the original selectable state.": "対象オブジェクトを一時的に選択不可にします。ナビゲーション中の選択判定や輪郭関連処理を減らします。スナップショット復元で元の選択可能状態に戻ります。",
    "Hide instancer viewport display": "インスタンサー表示を非表示",
    "Hide instancer display for target objects when available. This can reduce duplicated viewport drawing in scenes using collection or object instancing.": "対応する場合、対象オブジェクトのインスタンサー表示を非表示にします。コレクションやオブジェクトインスタンスを使うシーンで重複表示を減らせます。",
    "Disable Global Undo": "グローバルUndoを無効化",
    "Disable Global Undo for the current session while the optimizer is active. This reduces memory and bookkeeping pressure, but use Restore Snapshot or re-enable it before normal editing.": "最適化中の現在セッションでグローバルUndoを無効化します。メモリと記録処理の圧迫を減らしますが、通常編集に戻る前にスナップショット復元または再有効化してください。",
    "Undo steps": "Undo回数",
    "Undo step count to use while latency optimization is active. Zero is most aggressive and minimizes undo bookkeeping.": "遅延対策が有効な間に使うUndo回数です。0が最も強力で、Undo記録処理を最小化します。",
    "Undo memory limit": "Undoメモリ制限",
    "Undo memory limit in megabytes while latency optimization is active. Zero is the most aggressive setting.": "遅延対策が有効な間のUndoメモリ制限です。0が最も強力な設定です。",
    "Disable auto keying": "自動キー挿入を無効化",
    "Disable auto key insertion in the target scenes. This avoids accidental animation bookkeeping while using the speed-focused navigation mode.": "対象シーンで自動キー挿入を無効化します。速度優先ナビゲーション中の不要なアニメーション記録処理を避けます。",
    "Mute object constraints": "オブジェクト制約をミュート",
    "Temporarily mute object constraints on target objects. This can reduce dependency-graph evaluation cost in rigged or constraint-heavy scenes. Restore Snapshot returns the original mute states.": "対象オブジェクトのオブジェクト制約を一時的にミュートします。リグや制約の多いシーンで依存グラフ評価の負荷を下げられます。スナップショット復元で元のミュート状態に戻ります。",
    "Mute pose constraints": "ポーズ制約をミュート",
    "Temporarily mute pose-bone constraints on target armatures. This is aggressive and useful when rigs cause view movement to stall at the start of navigation.": "対象アーマチュアのポーズボーン制約を一時的にミュートします。強力な設定で、リグが視点操作開始時の停止感を引き起こす場合に有効です。",
    "Enable navigation prewarm guard": "ナビゲーション事前待機を有効化",
    "Run a lightweight modal guard that keeps the 3D View in a prewarmed low-cost state before orbit, pan, or zoom begins. It passes events through and is intended to reduce first-move hitches.": "軽量なモーダル監視を動かし、回転、移動、ズームが始まる前に3Dビューを低負荷で事前ウォームアップ済みの状態へ保ちます。イベントは透過し、初動の引っかかりを減らす目的です。",
    "Prewarm on mouse move": "マウス移動で事前ウォームアップ",
    "Prewarm redraw and dependency updates when the mouse moves over the viewport before navigation starts. This shifts some startup cost away from the first orbit, pan, or zoom event.": "ナビゲーション開始前にマウスがビューポート上で動いた時点で、再描画と依存更新を事前に行います。最初の回転、移動、ズームイベントから一部の開始コストを前倒しします。",
    "Prewarm interval": "事前ウォームアップ間隔",
    "Minimum seconds between prewarm attempts. Smaller values react more often but can add overhead; 0.25 to 0.5 seconds is usually a practical range.": "事前ウォームアップを試行する最小間隔です。小さいほど頻繁に反応しますが負荷が増えます。通常は0.25〜0.5秒程度が実用的です。",
    "Prewarm redraw iterations": "事前再描画回数",
    "Number of redraw attempts used by the prewarm step. One iteration is the safest default; higher values may move more cost before navigation but can feel heavier while idle.": "事前ウォームアップで試行する再描画回数です。1回が安全な既定値です。大きくするとナビゲーション前に多くのコストを移せますが、待機中が重く感じる場合があります。",
    "Restore after navigation idle": "ナビゲーション停止後に復元",
    "Restore the stored snapshot after navigation has been idle for the specified time. This is off by default because restoring heavy display settings can recreate the next start lag.": "指定時間ナビゲーション操作が止まった後、保存済みスナップショットを復元します。重い表示へ戻すと次の初動ラグを再発しやすいため、既定ではOFFです。",
    "Navigation idle seconds": "ナビゲーション停止秒数",
    "Idle time before optional post-navigation restore is triggered. This only matters when Restore after navigation idle is enabled.": "ナビゲーション停止後の自動復元までの待機秒数です。ナビゲーション停止後に復元がONの場合のみ使われます。",
    "Navigation Prewarm Guard": "ナビゲーション事前待機",
    "Keep the 3D View in a prewarmed low-cost state before navigation events begin.": "ナビゲーションイベントが始まる前に、3Dビューを低負荷で事前ウォームアップ済みの状態へ保ちます。",
    "Start Navigation Guard": "事前待機を開始",
    "Start the modal navigation prewarm guard manually. The guard passes mouse and keyboard events through and only performs lightweight prewarm work at controlled intervals.": "モーダルのナビゲーション事前待機を手動で開始します。マウスとキーボードイベントは透過し、制御された間隔で軽量な事前ウォームアップのみを行います。",
    "Stop Navigation Guard": "事前待機を停止",
    "Stop the modal navigation prewarm guard. This does not restore the scene; use Restore Snapshot if you also want to return the viewport and objects to their saved state.": "モーダルのナビゲーション事前待機を停止します。シーンは復元しません。表示やオブジェクトを保存状態へ戻すにはスナップショット復元を使ってください。",
    "Navigation guard could not be started.": "ナビゲーション事前待機を開始できませんでした。",
    "Navigation guard started.": "ナビゲーション事前待機を開始しました。",
    "Navigation guard stopped.": "ナビゲーション事前待機を停止しました。",
    "Disable GPU subdivision": "GPUサブディビジョンを無効化",
    "Disable GPU subdivision evaluation when the preference exists. Use this only if GPU subdivision causes instability or overhead on the current machine.": "対応する場合、GPUサブディビジョン評価を無効化します。現在の環境でGPUサブディビジョンが不安定または高負荷な場合にのみ使います。",
}


_TRANSLATIONS_JA.update({
    "Standard": "標準",
    "Optimized": "最適化",
    "Setting Load": "設定の読込",
    "Setting": "設定",
    "Current Workspace": "今のワークスペース",
    "Paste Source": "ペースト元",
    "Paste Settings to Current Workspace": "今のワークスペースへペースト",
    "Workspace settings pasted to current workspace.": "現在開いているワークスペースに設定をペーストしました。",
    "Load Current View Settings": "現在のビュー設定を読み込み",
    "Current View Settings loaded into Detailed Settings.": "現在のビュー設定を詳細設定へ読み込みました。",
    "Store and load Detailed Settings per Blender workspace. The paste button copies the source workspace settings into the currently open workspace.": "詳細設定をBlenderワークスペースごとに保存・保持します。ペーストボタンはペースト元ワークスペースの設定を現在開いているワークスペースへコピーします。",
    "Presets": "プリセット",
    "Backup / Recovery": "バックアップ / 復旧",
    "Apply Selected Preset": "選択プリセットを適用",
    "Save Custom Preset": "自作プリセットを保存",
    "Delete Custom Preset": "自作プリセットを削除",
    "Capture External Backup": "外部バックアップを保存",
    "Restore External Backup": "外部バックアップを復元",
    "Open Backup Folder": "バックアップフォルダーを開く",
    "Preset": "プリセット",
    "Choose a built-in or custom preset. Tooltips explain the expected speed effect and how strongly the viewport may change.": "内蔵または自作プリセットを選びます。ツールチップには期待できる速度効果と表示変化の強さが表示されます。",
    "Custom preset name": "自作プリセット名",
    "Name used when saving the current individual ON/OFF options as a custom preset.": "現在の個別ON/OFF設定を自作プリセットとして保存するときの名前です。",
    "Backup to restore": "復元するバックアップ",
    "Choose which external JSON backup is restored. Use Latest Any when you are unsure.": "復元する外部JSONバックアップの種類を選びます。迷う場合は最新すべてを使います。",
    "Latest Any": "最新すべて",
    "Latest Before Apply": "最新の適用前",
    "Startup Backup": "起動時バックアップ",
    "Install Baseline": "インストール基準",
    "File Load Backup": "ファイル読込バックアップ",
    "Manual Backup": "手動バックアップ",
    "Backup at add-on registration": "アドオン登録時にバックアップ",
    "Save a baseline JSON backup outside the .blend file as soon as the add-on registers. This protects the original state before automatic optimization can run.": "アドオン登録直後に.blend外へ基準JSONバックアップを保存します。自動最適化が動く前の元状態を保護します。",
    "Backup at Blender startup": "Blender起動時にバックアップ",
    "Save a startup JSON backup outside the .blend file after Blender initializes this add-on. Keep this on for maximum repair safety.": "Blenderがこのアドオンを初期化した後、.blend外へ起動時JSONバックアップを保存します。修復安全性を最大化するためON推奨です。",
    "Backup before every apply": "適用前に毎回バックアップ",
    "Save an external JSON backup immediately before every optimization apply. This is the main repair path if a setting does not return as expected.": "最適化を適用する直前に毎回、外部JSONバックアップを保存します。設定が期待通り戻らない場合の主修復経路です。",
    "Backup on file load": "ファイル読込時にバックアップ",
    "Save an external JSON backup when a .blend file is loaded, before automatic file-load optimization runs.": " .blendファイル読込時、自動最適化が動く前に外部JSONバックアップを保存します。",
    "Keep backup history": "バックアップ履歴を保持",
    "Keep timestamped backup files in addition to latest repair files. Turn off only when disk space is more important than rollback choices.": "最新修復ファイルに加え、時刻付きバックアップも保持します。復元候補よりディスク容量を優先する場合のみOFFにします。",
    "Max backup files": "最大バックアップ数",
    "Maximum number of timestamped external backup files to keep. Latest repair files are kept separately.": "保持する時刻付き外部バックアップファイルの最大数です。最新修復ファイルは別に保持されます。",
    "Force orthographic view": "正投影へ変更",
    "Switch visible 3D Views to Orthographic. This can remove perspective transition cost but changes navigation feel.": "表示中の3Dビューを正投影へ切り替えます。透視切替負荷を避けられますが操作感が変わります。",
    "Clear view locks": "視点ロックを解除",
    "Clear common 3D View locks such as camera, cursor, bone, and object locks. Locks can add state checks during navigation.": "カメラ、カーソル、ボーン、オブジェクトなどの3Dビューロックを解除します。ロックはナビゲーション時の状態確認を増やす場合があります。",
    "Hide mesh objects": "メッシュオブジェクト非表示",
    "Hide mesh objects through 3D View filters. This is extreme and intended for rescue presets when a file is almost unusable.": "3Dビューのフィルターでメッシュを隠します。非常に強力で、ファイルがほぼ操作不能な場合の救出用です。",
    "Disable object-type selection filters": "種類別選択フィルターを無効化",
    "Disable object-type selection filters in the 3D View where Blender exposes them. This reduces hit-testing during navigation-only mode.": "Blenderが公開している3Dビューの種類別選択フィルターを無効化します。ナビゲーション専用モードで選択判定を減らします。",
    "Disable mesh selection filter": "メッシュ選択フィルターを無効化",
    "Disable mesh selection in the 3D View object filter. This is aggressive and best for navigation-only playback or inspection.": "3Dビューのオブジェクトフィルターでメッシュ選択を無効化します。強力な設定で、ナビゲーション専用の確認に向きます。",
    "Hide unselected objects": "非選択オブジェクトを非表示",
    "Hide unselected objects. This strongly reduces visible scene cost for focused work, and can be restored from the backup snapshot.": "非選択オブジェクトを隠します。集中作業では表示負荷を大きく減らし、バックアップスナップショットから復元できます。",
    "Force bounds type box": "バウンディングを箱に固定",
    "Use box bounds for objects where supported. Box bounds are the cheapest rescue display.": "対応する場合、バウンディング形状を箱にします。箱表示は最も軽い救出表示です。",
    "Pause object simulation cache": "オブジェクトシミュレーションキャッシュ停止",
    "Disable per-object simulation cache usage where exposed. This can reduce simulation bookkeeping during viewport movement.": "公開されている場合、オブジェクト単位のシミュレーションキャッシュ使用をOFFにします。ビューポート移動中のシミュレーション管理負荷を減らせます。",
    "Cull heavy objects": "重いオブジェクトを間引く",
    "Detect objects above vertex, modifier, or particle thresholds and apply the selected heavy-object action.": "頂点数、モディファイア数、パーティクル数がしきい値を超えるオブジェクトへ、選択した重オブジェクト処理を適用します。",
    "Heavy object action": "重オブジェクト処理",
    "Action applied to detected heavy objects. Hide Viewport is strongest; Bounds and Wire are safer.": "重いと判定されたオブジェクトへ適用する処理です。ビューポート非表示が最強で、バウンディングやワイヤーは安全寄りです。",
    "Hide Viewport": "ビューポート非表示",
    "Bounds": "バウンディング",
    "Wire": "ワイヤー",
    "Disable Selection": "選択不可",
    "Heavy vertex threshold": "重オブジェクト頂点しきい値",
    "Objects with at least this many vertices are treated as heavy.": "この頂点数以上のオブジェクトを重い対象として扱います。",
    "Heavy modifier threshold": "重オブジェクトモディファイアしきい値",
    "Objects with at least this many modifiers are treated as heavy.": "この数以上のモディファイアを持つオブジェクトを重い対象として扱います。",
    "Heavy particle threshold": "重オブジェクトパーティクルしきい値",
    "Objects with at least this many particle systems are treated as heavy.": "この数以上のパーティクルシステムを持つオブジェクトを重い対象として扱います。",
    "Use threaded shader compilation": "スレッド式シェーダーコンパイル",
    "Use threaded shader compilation when available. This can reduce UI blocking from shader compilation.": "対応する場合、スレッド式シェーダーコンパイルを使います。シェーダーコンパイルによるUIブロックを減らせます。",
    "GPU shader workers": "GPUシェーダーワーカー数",
    "GPU shader worker count when exposed. Zero lets Blender choose automatically.": "公開されている場合のGPUシェーダーワーカー数です。0はBlender自動選択です。",
    "Set memory cache limit": "メモリキャッシュ上限を設定",
    "Set Blender's memory cache limit for this session. Use only when memory pressure is suspected.": "現在セッションのBlenderメモリキャッシュ上限を設定します。メモリ圧迫が疑われる場合のみ使います。",
    "Memory cache limit MB": "メモリキャッシュ上限MB",
    "Memory cache limit in megabytes when Set memory cache limit is enabled.": "メモリキャッシュ上限を設定がONのときに使うMB値です。",
    "Disable region overlap": "リージョン重なりを無効化",
    "Disable region overlap where available. This can reduce UI compositing work around panels.": "対応する場合、リージョン重なりを無効化します。パネル周辺のUI合成負荷を減らせます。",
    "Reduce status bar drawing": "ステータスバー描画を削減",
    "Hide several status-bar information fields where available. Reduces small but constant UI redraw work.": "対応する場合、ステータスバーの情報表示を減らします。小さいながら常時発生するUI再描画を抑えます。",
    "Enable reduce motion": "モーション削減を有効化",
    "Enable reduced motion in preferences where available. This avoids unnecessary interface animation.": "対応する場合、プリファレンスのモーション削減を有効にします。不要なUIアニメーションを避けます。",
    "Simplify navigation method": "ナビゲーション方式を単純化",
    "Use simpler navigation methods such as Turntable rotation and Scale zoom where available.": "対応する場合、ターンテーブル回転やスケールズームなど単純な方式へ変更します。",
    "View rotate method": "視点回転方式",
    "View zoom method": "視点ズーム方式",
    "View zoom axis": "ズーム入力軸",
    "Disable NDOF guides": "NDOFガイド無効化",
    "Disable 3D mouse guide and helper options where available.": "対応する場合、3Dマウス用ガイドや補助設定を無効化します。",
    "Disable snapping and auto-merge": "スナップと自動マージを無効化",
    "Disable snapping and mesh auto-merge in tool settings where available. Helps avoid edit-tool bookkeeping.": "対応する場合、スナップとメッシュ自動マージをOFFにします。編集ツールの管理負荷を避けます。",
    "Prewarm view matrix nudge": "視点行列ナッジで事前ウォーム",
    "Slightly nudge and restore the view matrix during prewarm. This can force lazy view data to refresh before manual navigation.": "事前ウォーム時に視点行列を微小に動かして戻します。遅延更新される視点データを手動操作前に更新させます。",
    "Enable idle warm pulse": "常駐ウォームパルスを有効化",
    "Keep a low-frequency timer active to prevent viewport data from going cold between navigation attempts.": "低頻度タイマーで、操作間にビューポートデータが冷えるのを抑えます。",
    "Idle pulse interval": "常駐パルス間隔",
    "Seconds between idle warm pulses. Lower values reduce cold starts more strongly but add idle work.": "常駐ウォームパルスの間隔秒です。低いほどコールドスタートを強く抑えますが待機時負荷が増えます。",
    "Update view layer in idle pulse": "常駐パルスでビューレイヤー更新",
    "Also update the view layer during idle pulse. Stronger but may add idle CPU use; keep off unless needed.": "常駐パルス時にもビューレイヤーを更新します。強力ですが待機中CPU負荷が増えるため必要時のみONにします。",
    "Idle pulse redraw iterations": "常駐パルス再描画回数",
    "Redraw iterations used by idle pulse. Keep zero unless idle prewarm must be stronger.": "常駐パルスで使う再描画回数です。強い待機ウォームが必要な時以外は0推奨です。",
})



_TRANSLATIONS_JA.update({
    "Apply Performance Preset": "パフォーマンスプリセットを適用",
    "Reset Options to Performance High": "設定をパフォーマンス優先：高へ戻す",
    "Apply the default high-performance viewport preset, save a repair backup if needed, and immediately update configured targets.": "既定の高パフォーマンスビューポートプリセットを適用し、必要に応じて修復用バックアップを保存してから対象設定を即時更新します。",
    "Set all optimization options back to the Performance Priority: High preset.": "すべての最適化項目をパフォーマンス優先：高プリセットへ戻します。",
    "Performance preset options were restored.": "パフォーマンスプリセット設定に戻しました。",
    "Smart Viewport Optimizer Plus: performance preset options reset.": 'ビューポート最適化: パフォーマンスプリセット設定へ戻しました。',
    "My Viewport Preset": "マイビューポートプリセット",
    "Layout": "レイアウト",
    "Modeling": "モデリング",
    "Sculpting": "スカルプト",
    "UV Editing": "UVエディティング",
    "Texture Paint": "テクスチャペイント",
    "Shading": "シェーディング",
    "Animation": "アニメーション",
    "Rendering": "レンダリング",
    "Compositing": "コンポジティング",
    "Geometry Nodes": "ジオメトリノード",
    "Scripting": "スクリプティング",
    "2D Animation": "2Dアニメーション",
    "2D Full Canvas": "2Dフルキャンバス",
    "Masking": "マスキング",
    "Motion Tracking": "モーショントラッキング",
    "Video Editing": "ビデオ編集",
})

_TRANSLATIONS_JA.update({
    "Auto-save preset changes": "プリセット変更を自動保存",
    "Automatically save manual ON/OFF and numeric setting changes into the currently applied preset as an external user override. Reset Preset removes only this override and restores the factory preset.": "現在適用中のプリセットに対して、手動で変更したON/OFFや数値設定を外部ユーザー上書きとして自動保存します。プリセットリセットはこの上書きだけを削除し、初期プリセットへ戻します。",
    "Reset Selected Preset": "選択プリセットをリセット",
    "Reset the selected built-in preset to its original factory definition, delete its external user override, and apply the restored preset immediately.": "選択中の内蔵プリセットを元の初期定義へ戻し、外部ユーザー上書きを削除して、復元したプリセットをすぐ適用します。",
    "Preset user override saved": "プリセット上書き保存済み",
    "Factory preset restored": "初期プリセットへ復元済み",
    "Smart Viewport Optimizer Plus: selected preset factory settings restored.": 'ビューポート最適化: 選択プリセットを初期設定へ戻しました。',
    "User changes are saved automatically for the applied preset. Use Reset Selected Preset to discard them.": "手動変更は適用中のプリセットへ自動保存されます。破棄するには選択プリセットをリセットを使います。",
    "Crash-safe prewarm skips redraw_timer and UI operators; it only tags existing 3D Views for redraw and avoids file-load header drawing conflicts.": "クラッシュ安全型の事前ウォームアップはredraw_timerやUIオペレーターを使わず、既存3Dビューの再描画要求だけを行い、ファイル読込直後のヘッダー描画衝突を避けます。",
})



_TRANSLATIONS_JA.update({
    "Operation / Preset / Restore / Keymap": "操作・プリセット・復元・キーマップ",
    "Optimizer Toggle": "最適化トグル",
    "Enable / Disable Optimizer": "最適化 ON/OFF",
    "Turn ON temporary viewport optimization using the selected preset and current detailed settings. ON is blocked until a baseline state has been saved or loaded; turning it OFF restores the maintained baseline state.": "選択プリセットと現在の詳細設定を使って一時的なビューポート最適化をONにします。基準状態が保存または読み込み済みでない場合はONにできません。OFFにすると維持中の基準状態へ復元します。",
    "Optimization is ON": "最適化ON",
    "Optimization is OFF": "最適化OFF",
    "Toggle ON": "ONにする",
    "Toggle OFF / Restore": "OFFにして復元",
    "Preset and options are not applied while the toggle is OFF. They are applied only during the ON state.": "トグルOFF中はプリセットや詳細設定を実環境へ反映しません。ON中だけ反映します。",
    "Auto restore on file open/close": "ファイル開閉時に自動復元",
    "Before loading another file, saving, quitting, or disabling the add-on, restore the maintained baseline state when the optimizer is ON. Keep this enabled to avoid saving or leaving Blender in an optimized state.": "別ファイル読込、保存、終了、アドオン無効化の前に、最適化ON中なら維持中の基準状態へ復元します。最適化状態を保存・放置する危険を避けるため有効のままにしてください。",
    "Re-apply after save when ON": "ON中の保存後に再反映",
    "When a save starts while the optimizer is ON, the add-on restores the maintained baseline state for the saved file, then re-applies the temporary optimization after saving so the current session remains responsive.": "最適化ON中に保存すると、保存されるファイルは維持中の基準状態へ戻し、保存後に現在セッションへ一時最適化を再反映します。",
    "Keymap operator ID": "キーマップ登録ID",
    "Copy Keymap ID": "登録IDをコピー",
    "Copy the toggle operator ID to the clipboard. Register it in Preferences > Keymap > 3D View > 3D View (Global).": "トグル操作の登録IDをクリップボードへコピーします。プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）へ登録してください。",
    "Recommended keymap location: Preferences > Keymap > 3D View > 3D View (Global).": "推奨登録場所: プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）。",
    "Copyable operator ID: view3d.svo_plus_toggle_optimizer": "コピー用登録ID: view3d.svo_plus_toggle_optimizer",
    "Save baseline now": "現在状態を基準として保存",
    "Restore baseline now": "基準状態へ復元",
    "Open repair folder": "修復フォルダーを開く",
    "Reset selected preset": "選択プリセットをリセット",
    "Apply preset settings only": "プリセット設定だけ読込",
    "Load the selected preset into the detailed options. If the optimizer toggle is ON, the active temporary optimization is rebuilt from the maintained baseline. If OFF, the scene is not changed.": "選択プリセットを詳細設定へ読み込みます。最適化トグルがONの場合は維持中の基準状態を基準に一時最適化を再構築します。OFFの場合はシーンへ変更を加えません。",
    "Reset the selected preset to its factory settings. If the optimizer toggle is ON, temporary optimization is rebuilt from the maintained baseline. If OFF, only the option values change.": "選択プリセットを初期設定へ戻します。最適化トグルがONの場合は維持中の基準状態を基準に一時最適化を再構築します。OFFの場合は設定値だけ変更します。",
    "Temporary optimization enabled.": "一時最適化を有効化しました。",
    "Original state restored and temporary optimization disabled.": "基準状態へ復元し、一時最適化を無効化しました。",
    "Preset loaded. Toggle ON to apply it.": "プリセットを読み込みました。反映するにはトグルをONにしてください。",
    "Preset loaded and active optimization rebuilt.": "プリセットを読み込み、ON中の一時最適化を再構築しました。",
    "Keymap ID copied to clipboard.": "キーマップ登録IDをクリップボードへコピーしました。",
    "Baseline snapshot is session-only and is normally cleared after OFF restore. External JSON backups remain available for repair.": "基準スナップショットはセッション専用で、通常はOFF復元後に消去されます。外部JSONバックアップは修復用に残ります。",
    "Toggle Smart Viewport Optimizer": "スマートビューポート最適化を切替",
    "Toggle temporary viewport optimization. ON is blocked until a baseline state has been saved or loaded; OFF restores the maintained baseline state.": "一時的なビューポート最適化を切り替えます。基準状態が保存または読み込み済みでない場合はONにできません。OFFにすると維持中の基準状態へ復元します。",
    "Settings changed while ON; active optimization was rebuilt from the maintained baseline.": "ON中の設定変更を検出し、維持中の基準状態を基に一時最適化を再構築しました。",
    "Restored before file event.": "ファイルイベント前に復元しました。",
})

_TRANSLATIONS_JA.update({
    "Optimization Toggle": "最適化トグル",
    "Operation / Preset / Restore / Keymap": "操作・プリセット・復元・キーマップ",
    "Detailed Settings": "各種設定",
    "Header Settings": "ヘッダー設定",
    "Toggle ON": "ONにする",
    "Toggle OFF / Restore": "OFFにして復元",
    "Optimization is ON": "最適化ON",
    "Optimization is OFF": "最適化OFF",
    "Settings are applied only while this toggle is ON. Turning it OFF restores the maintained baseline state.": "このトグルがONの間だけ設定が反映されます。OFFにすると保存・読み込み済みの基準状態へ戻します。",
    "Preset and recovery tools are collapsed by default to keep the panel compact.": "パネルを見やすくするため、プリセットと復元ツールは初期状態で閉じています。",
    "Open the detailed viewport optimization settings in this header popover. These settings are applied only while the optimizer toggle is ON.": "ヘッダーのポップオーバー内で詳細なビューポート最適化設定を開きます。これらの設定は最適化トグルがONの間だけ反映されます。",
    "Temporarily turn viewport optimization ON or OFF. OFF restores the baseline captured immediately before ON.": "ビューポート最適化を一時的にON/OFFします。OFFにするとON直前に取得した基準状態へ復元します。",
    "Open detailed Smart Viewport Optimizer settings.": "スマートビューポート最適化の詳細設定を開きます。",
    "Apply preset settings only": "プリセット設定だけ読込",
    "Reset selected preset": "選択プリセットをリセット",
    "Save Custom Preset": "自作プリセットを保存",
    "Delete Custom Preset": "自作プリセットを削除",
    "Save baseline now": "基準状態を保存",
    "Restore baseline now": "基準状態を復元",
    "Capture External Backup": "外部バックアップを保存",
    "Restore External Backup": "外部バックアップを復元",
    "Open repair folder": "修復フォルダーを開く",
    "Copy Keymap ID": "キーマップIDをコピー",
    "Recommended keymap location: Preferences > Keymap > 3D View > 3D View (Global).": "推奨キーマップ登録場所: プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）",
    "Preset and options are not applied while the toggle is OFF. They are applied only during the ON state.": "トグルOFF中、プリセットや詳細設定は実際のBlender状態へ反映されません。ON中のみ反映されます。",
    "Baseline snapshot is session-only and is normally cleared after OFF restore. External JSON backups remain available for repair.": "基準スナップショットはセッション専用で、OFF復元後に通常消去されます。外部JSONバックアップは修復用として残ります。",
})


_TRANSLATIONS_JA.update({
    "Operation / Preset / Restore / Keymap": "操作・プリセット・復元・キーマップ",
    "Preset Section": "プリセット",
    "Baseline Section": "基準状態",
    "Keymap Section": "キーマップ",
    "Auto-save preset setting changes": "プリセット設定変更の自動保存",
    "Automatically save manual ON/OFF and numeric setting changes for the selected preset to the preset override JSON file. The file name is generated from the preset ID so the setting is maintained across Blender sessions.": "設定変更時、選択中プリセット用の外部JSONファイルへON/OFFや数値設定を自動保存します。ファイル名はプリセットIDから自動生成され、Blenderを再起動しても設定を維持します。",
    "Save Selected Preset Settings": "選択中のプリセット設定の保存",
    "Save the current detailed optimizer settings to an external JSON file and keep them as the selected preset settings. The file browser opens with a suitable default file name based on the selected preset.": "現在の詳細最適化設定を外部JSONファイルへ手動保存し、選択中プリセットの設定として維持します。ファイルブラウザーには選択中プリセットに応じた適切な既定ファイル名を入れて開きます。",
    "Load Settings as Selected Preset": "選択中のプリセットとして設定を読み込み",
    "Load an external JSON settings file into the currently selected preset and keep those settings as the selected preset override.": "外部JSONファイルの設定を現在選択中のプリセットへ読み込み、そのプリセットの上書き設定として維持します。",
    "Reset Selected Preset Settings": "選択中のプリセット設定をリセット",
    "Reset the selected built-in preset to its installation-time factory settings and delete only its external override file.": "選択中の内蔵プリセットをインストール時の初期設定へ戻し、そのプリセットの外部上書きファイルだけを削除します。",
    "Save Current Settings as Baseline State": "現在の設定を基準状態として保存",
    "Save the current Blender settings as an external baseline JSON file and keep that state as the maintained restore target. Optimization cannot be turned ON until this baseline is saved or loaded.": "現在のBlender設定を外部JSONファイルとして保存し、その状態を復元先の基準状態として維持します。この基準状態を保存または読み込むまで、最適化をONにできません。",
    "Load Baseline State": "基準状態として設定を読み込み",
    "Load an external JSON baseline file, keep it as the maintained baseline state, and immediately restore Blender to that state while optimization is OFF.": "外部JSONファイルから基準状態を読み込み、維持する基準状態として保持し、最適化OFF中の現在状態もその基準状態へ即時復元します。",
    "Save the selected preset settings file": "選択中プリセット設定ファイルを保存",
    "Load the selected preset settings file": "選択中プリセット設定ファイルを読み込み",
    "Save the baseline state file": "基準状態ファイルを保存",
    "Load the baseline state file": "基準状態ファイルを読み込み",
    "Selected preset settings saved.": "選択中プリセット設定を保存しました。",
    "Selected preset settings loaded.": "選択中プリセットとして設定を読み込みました。",
    "Baseline state saved and set.": "現在の設定を基準状態として保存しました。",
    "Baseline state loaded and restored.": "基準状態として設定を読み込み、現在の状態へ反映しました。",
    "The selected file is not a preset settings file.": "選択したファイルはプリセット設定ファイルではありません。",
    "The selected file is not a baseline snapshot file.": "選択したファイルは基準状態スナップショットファイルではありません。",
    "Keymap operator ID": "キーマップ登録ID",
    "Copy Keymap ID": "キーマップIDをコピー",
    "Recommended keymap location: Preferences > Keymap > 3D View > 3D View (Global).": "推奨キーマップ登録場所: プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）",
    "Save the baseline after turning optimization OFF.": "最適化をOFFに戻してから基準状態を保存してください。",
})


_TRANSLATIONS_JA.update({
    "Baseline state is not set. Save the current settings as the baseline state or load a baseline state before turning optimization ON.": "基準状態が設定されていません。最適化をONにする前に「現在の設定を基準状態として保存」または「基準状態として設定を読み込み」を実行してください。",
    "Invalid baseline state file. Save current settings as a baseline or load a valid baseline state before turning optimization ON.": "基準状態ファイルが無効です。最適化をONにする前に、現在の設定を基準状態として保存するか、有効な基準状態を読み込んでください。",
    "Baseline state loaded, but the current UI context could not be fully restored.": "基準状態として設定を読み込みましたが、現在のUIコンテキストでは一部を復元できませんでした。",
    "Baseline state restored and temporary optimization disabled.": "基準状態へ復元し、一時最適化を無効化しました。",
    "Settings are applied only while this toggle is ON. Turning it OFF restores the maintained baseline state.": "このトグルがONの間だけ設定が反映されます。OFFにすると保存・読み込み済みの基準状態へ戻します。",
    "Toggle temporary viewport optimization. ON is blocked until a baseline state has been saved or loaded; OFF restores the maintained baseline state.": "一時的なビューポート最適化を切り替えます。基準状態が保存または読み込み済みでない場合はONにできません。OFFにすると維持中の基準状態へ復元します。",
})

_TRANSLATIONS_JA.update({
    "Performance": "パフォーマンス",
    "Balanced": "バランス",
    "Quality": "クオリティ",
    "Apply Preset": "プリセットを適用",
    "Setting Load": "設定の読込",
    "Copy the selected preset into every Detailed Settings item and immediately apply the resulting settings to the current viewport.": "選択したプリセットの内容を詳細設定の全項目へコピーし、その結果を現在のビューへすぐ反映します。",
    "Setting Save / Keymap": "設定の保存・キーマップ",
    "Save Standard Settings": "標準設定の保存",
    "Load Standard Settings": "標準設定の読み込み",
    "Save Optimized Settings": "最適化設定の保存",
    "Load Optimized Settings": "最適化設定の読み込み",
    "Auto-save Settings": "設定の自動保存",
    "When enabled, each Detailed Settings change is immediately written to the active Standard or Optimized settings file and to the current settings file after it is applied to the viewport.": "有効にすると、詳細設定の変更をビューへ反映した直後に、現在有効な標準設定または最適化設定のファイルとカレント設定ファイルへ保存します。",
    "Save the current Detailed Settings values as the Standard settings file, update the current settings file, and keep this slot active for auto-save.": "現在の詳細設定値を標準設定ファイルとして保存し、カレント設定ファイルも更新して、自動保存の対象を標準設定にします。",
    "Load a Standard settings JSON file, update the maintained current settings file, and immediately apply it to the viewport.": "標準設定JSONファイルを読み込み、維持されるカレント設定ファイルを更新して、すぐにビューへ反映します。",
    "Save the current Detailed Settings values as the Optimized settings file, update the current settings file, and keep this slot active for auto-save.": "現在の詳細設定値を最適化設定ファイルとして保存し、カレント設定ファイルも更新して、自動保存の対象を最適化設定にします。",
    "Load an Optimized settings JSON file, update the maintained current settings file, and immediately apply it to the viewport.": "最適化設定JSONファイルを読み込み、維持されるカレント設定ファイルを更新して、すぐにビューへ反映します。",
    "Current settings applied and saved.": "現在の設定を反映して保存しました。",
    "Selected preset was copied into Detailed Settings and applied.": "選択したプリセットを詳細設定へコピーして反映しました。",
    "Preset selected. Press Apply Preset to copy it into Detailed Settings.": "プリセットを選択しました。詳細設定へコピーするには「プリセットを適用」を押してください。",
    "Detailed Settings": "詳細設定",
    "Settings Mode": "設定モード",
    "Current settings applied.": "現在の設定を反映しました。",
    "Current settings could not be applied.": "現在の設定を反映できませんでした。",
    "Standard Settings": "標準設定",
    "Optimized Settings": "最適化設定",
    "Standard Settings saved and applied.": "標準設定を保存して反映しました。",
    "Standard Settings loaded and applied.": "標準設定を読み込んで反映しました。",
    "Optimized Settings saved and applied.": "最適化設定を保存して反映しました。",
    "Optimized Settings loaded and applied.": "最適化設定を読み込んで反映しました。",
    "Settings file could not be loaded.": "設定ファイルを読み込めませんでした。",
    "Detailed settings are applied to the viewport in real time. The current settings file is updated in real time only while Auto-save Settings is ON.": "詳細設定はリアルタイムでビューに反映されます。カレント設定ファイルのリアルタイム更新は「設定の自動保存」がONの時だけ行います。",
    "Warmup timers are kept stopped in this performance-focused build.": "このパフォーマンス優先版では、ウォームアップ用タイマーは停止したまま保持されます。",
    "Copy the selected Performance, Balanced, or Quality preset into all Detailed Settings items and apply it to the current viewport immediately. JSON files are updated only when Auto-save Settings is ON or when a save button is pressed.": "選択したパフォーマンス、バランス、クオリティのプリセットを詳細設定の全項目へコピーし、現在のビューへ即時反映します。JSONファイルは「設定の自動保存」がONの時、または保存ボタンを押した時だけ更新します。",
})

_SVO_V14_TRANSLATIONS = {
    "Current View Settings loaded into Detailed Settings without applying changes to Blender.": "現在のビュー設定を詳細設定へ読み込みました。Blender側の設定は変更していません。",
    "Read the current Blender viewport, overlay, object, preference, and navigation settings into Detailed Settings only. This does not apply or change Blender's current viewport settings.": "現在のBlenderのビューポート、オーバーレイ、オブジェクト、プリファレンス、ナビゲーション設定を詳細設定へ読み込むだけです。Blender側の現在のビューポート設定は適用・変更しません。",
    "Toggle between Standard and Optimized viewport optimization settings for the current workspace and apply the selected mode to the viewport.": "現在のワークスペースの標準設定と最適化設定をトグル切り替えし、選択したモードをビューポートへ反映します。",
    "Standard settings applied.": "標準設定を適用しました。",
    "Optimized settings applied.": "最適化設定を適用しました。",
    "Apply Controls": "適用時の制御",
    "Optimized settings reapplied after save.": "保存後に最適化設定を再適用しました。",
    "Switched to Standard before save.": "保存前に標準へ切り替えました。",
    "Switched to Standard before file close or Blender exit.": "ファイルを閉じる前またはBlender終了前に標準へ切り替えました。",
}
_TRANSLATIONS_JA.update(_SVO_V14_TRANSLATIONS)

_TRANSLATION_DICT = {
    "ja_JP": {("*", key): value for key, value in _TRANSLATIONS_JA.items()}
}


def iface(text: str) -> str:
    # Blender's catalog and other add-ons can answer before this table, so the
    # feature's own wording is looked up first.
    if _suite_translation.is_japanese():
        own = _TRANSLATION_DICT["ja_JP"].get(("*", text))
        if own:
            return own
    return bpy.app.translations.pgettext_iface(text)


# -----------------------------------------------------------------------------
# Defaults
# -----------------------------------------------------------------------------

MAX_SPEED_DEFAULTS: Dict[str, Any] = {
    "auto_apply_on_enable": False,
    "auto_apply_on_load": False,
    "protect_existing_snapshot": True,
    "apply_all_scenes": True,
    "object_scope": "ALL",
    "include_scene_simplify": True,
    "include_viewport_shading": True,
    "include_overlays": True,
    "include_gizmos": True,
    "include_object_filters": True,
    "include_object_display": True,
    "include_modifiers": True,
    "include_particles": True,
    "include_preferences": True,
    "include_navigation_latency": True,
    "include_constraints": True,
    "include_viewport_prewarm": False,
    "use_simplify": True,
    "force_subdivision_level": True,
    "subdivision_level": 0,
    "force_volume_resolution": True,
    "volume_value": 0.0,
    "force_child_particles": True,
    "child_particle_percentage": 0.0,
    "force_texture_size": True,
    "texture_size": 128,
    "simplify_grease_pencil": True,
    "force_wireframe_mode": True,
    "use_flat_solid_fallback": True,
    "use_single_color": True,
    "disable_shadows": True,
    "disable_cavity": True,
    "disable_object_outlines": True,
    "disable_specular": True,
    "disable_xray": True,
    "disable_scene_lights": True,
    "disable_scene_world": True,
    "enable_backface_culling": True,
    "limit_far_clip": True,
    "clip_end": 1000.0,
    "limit_near_clip": True,
    "clip_start": 0.05,
    "hide_all_overlays": True,
    "hide_relationship_lines": True,
    "hide_grid_axes": True,
    "hide_text_stats": True,
    "hide_extras": True,
    "hide_wire_overlay": True,
    "hide_normals": True,
    "hide_edit_guides": True,
    "hide_motion_paths": True,
    "hide_annotations": True,
    "hide_all_gizmos": True,
    "hide_navigation_gizmo": True,
    "hide_tool_gizmos": True,
    "hide_context_gizmos": True,
    "hide_object_transform_gizmos": True,
    "hide_lights": True,
    "hide_cameras": True,
    "hide_empties": True,
    "hide_armatures": True,
    "hide_curves": True,
    "hide_surfaces": True,
    "hide_fonts": True,
    "hide_metaballs": True,
    "hide_lattices": True,
    "hide_speakers": True,
    "hide_light_probes": True,
    "hide_volumes": True,
    "hide_grease_pencil": True,
    "hide_pointclouds": True,
    "force_object_display_type": True,
    "object_display_type": "BOUNDS",
    "hide_object_names_axes": True,
    "disable_object_selection": True,
    "hide_instancer_viewport": True,
    "disable_viewport_modifiers": True,
    "disable_subdivision_modifiers": True,
    "disable_geometry_nodes": True,
    "disable_simulation_modifiers": True,
    "disable_deformer_modifiers": True,
    "disable_generator_modifiers": True,
    "disable_normal_data_modifiers": True,
    "disable_other_modifiers": True,
    "mute_object_constraints": True,
    "mute_pose_constraints": True,
    "reduce_particle_previews": True,
    "particle_display_percentage": 0,
    "particle_display_step": 0,
    "disable_viewport_aa": True,
    "keep_texture_vbo_cache_warm": True,
    "texture_cache_seconds": 1800,
    "vbo_cache_seconds": 1800,
    "texture_collection_rate": 1800,
    "vbo_collection_rate": 1800,
    "gl_texture_limit": "CLAMP_512",
    "disable_gpu_subdivision": True,
    "disable_smooth_wires": True,
    "disable_depth_navigation": True,
    "disable_zoom_to_mouse": True,
    "disable_rotate_around_active": True,
    "disable_auto_perspective": True,
    "disable_smooth_view": True,
    "hide_global_navigation_ui": True,
    "force_object_mode_on_apply": True,
    "clear_selection_on_apply": True,
    "disable_global_undo": True,
    "undo_steps": 0,
    "undo_memory_limit": 0,
    "disable_auto_keying": True,
    "enable_navigation_guard": False,
    "prewarm_on_mouse_move": False,
    "prewarm_interval": 0.35,
    "prewarm_redraw_iterations": 0,
    "restore_after_navigation_idle": False,
    "navigation_idle_seconds": 2.0,
}

MAX_SPEED_DEFAULTS.update({
    "external_backup_on_register": False,
    "external_backup_on_startup": False,
    "external_backup_before_apply": False,
    "external_backup_on_file_load": False,
    "keep_backup_history": False,
    "max_backup_files": 120,
    "selected_preset": "PERFORMANCE",
    "custom_preset_name": "My Viewport Preset",
    "backup_restore_kind": "last_any",
    "force_orthographic_view": False,
    "clear_view3d_locks": True,
    "hide_meshes_filter": False,
    "disable_object_type_selection_filters": True,
    "disable_mesh_selection_filter": True,
    "hide_unselected_objects": False,
    "force_bounds_type_box": True,
    "pause_object_simulation_cache": True,
    "enable_heavy_object_culling": True,
    "heavy_object_action": "HIDE_VIEWPORT",
    "heavy_vertex_threshold": 50000,
    "heavy_modifier_threshold": 2,
    "heavy_particle_threshold": 1,
    "set_shader_compilation_threaded": True,
    "gpu_shader_workers": 0,
    "set_memory_cache_limit": False,
    "memory_cache_limit_mb": 4096,
    "disable_region_overlap": True,
    "reduce_ui_status_draw": True,
    "enable_reduce_motion": True,
    "simplify_navigation_method": True,
    "view_rotate_method": "TURNTABLE",
    "view_zoom_method": "SCALE",
    "view_zoom_axis": "VERTICAL",
    "disable_ndof_guides": True,
    "disable_snapping_automerge": True,
    "prewarm_view_matrix_nudge": False,
    "enable_idle_warm_pulse": False,
    "idle_warm_pulse_interval": 0.8,
    "idle_pulse_view_layer_update": False,
    "idle_pulse_redraw_iterations": 0,
    "auto_save_workspace_preset_changes": False,
    "optimizer_active": False,
    "restore_before_file_events": True,
    "reapply_after_save_if_active": True,
    "keymap_operator_id": "view3d.svo_plus_toggle_optimizer",
})


OPTIMIZER_SAFE_DEFAULTS: Dict[str, Any] = {
    "auto_apply_on_enable": False,
    "auto_apply_on_load": False,
    "protect_existing_snapshot": True,
    "apply_all_scenes": True,
    "object_scope": "VISIBLE",
    "include_scene_simplify": True,
    "include_viewport_shading": True,
    "include_overlays": True,
    "include_gizmos": True,
    "include_object_filters": True,
    "include_object_display": True,
    "include_modifiers": True,
    "include_particles": True,
    "include_preferences": True,
    "include_navigation_latency": True,
    "include_constraints": False,
    "include_viewport_prewarm": False,
    "use_simplify": True,
    "force_subdivision_level": True,
    "subdivision_level": 1,
    "force_volume_resolution": True,
    "volume_value": 0.5,
    "force_child_particles": True,
    "child_particle_percentage": 0.5,
    "force_texture_size": True,
    "texture_size": 1024,
    "simplify_grease_pencil": False,
    "force_wireframe_mode": False,
    "use_flat_solid_fallback": True,
    "use_single_color": False,
    "disable_shadows": True,
    "disable_cavity": False,
    "disable_object_outlines": False,
    "disable_specular": True,
    "disable_xray": True,
    "disable_scene_lights": False,
    "disable_scene_world": False,
    "enable_backface_culling": False,
    "limit_far_clip": False,
    "clip_end": 2000.0,
    "limit_near_clip": False,
    "clip_start": 0.01,
    "hide_all_overlays": False,
    "hide_relationship_lines": True,
    "hide_grid_axes": False,
    "hide_text_stats": True,
    "hide_extras": False,
    "hide_wire_overlay": False,
    "hide_normals": True,
    "hide_edit_guides": False,
    "hide_motion_paths": False,
    "hide_annotations": False,
    "hide_all_gizmos": False,
    "hide_navigation_gizmo": True,
    "hide_tool_gizmos": False,
    "hide_context_gizmos": False,
    "hide_object_transform_gizmos": False,
    "hide_lights": False,
    "hide_cameras": False,
    "hide_empties": False,
    "hide_armatures": False,
    "hide_curves": False,
    "hide_surfaces": False,
    "hide_fonts": False,
    "hide_metaballs": False,
    "hide_lattices": False,
    "hide_speakers": True,
    "hide_light_probes": False,
    "hide_volumes": False,
    "hide_grease_pencil": False,
    "hide_pointclouds": False,
    "hide_meshes_filter": False,
    "force_object_display_type": False,
    "object_display_type": "SOLID",
    "hide_object_names_axes": False,
    "disable_object_selection": False,
    "hide_instancer_viewport": False,
    "disable_viewport_modifiers": False,
    "disable_subdivision_modifiers": False,
    "disable_geometry_nodes": False,
    "disable_simulation_modifiers": False,
    "disable_deformer_modifiers": False,
    "disable_generator_modifiers": False,
    "disable_normal_data_modifiers": False,
    "disable_other_modifiers": False,
    "mute_object_constraints": False,
    "mute_pose_constraints": False,
    "reduce_particle_previews": True,
    "particle_display_percentage": 50,
    "particle_display_step": 2,
    "disable_viewport_aa": True,
    "keep_texture_vbo_cache_warm": True,
    "texture_cache_seconds": 1800,
    "vbo_cache_seconds": 1800,
    "texture_collection_rate": 1800,
    "vbo_collection_rate": 1800,
    "gl_texture_limit": "CLAMP_2048",
    "disable_gpu_subdivision": False,
    "disable_smooth_wires": False,
    "disable_depth_navigation": True,
    "disable_zoom_to_mouse": False,
    "disable_rotate_around_active": False,
    "disable_auto_perspective": True,
    "disable_smooth_view": True,
    "hide_global_navigation_ui": False,
    "force_object_mode_on_apply": False,
    "clear_selection_on_apply": False,
    "disable_global_undo": False,
    "undo_steps": 32,
    "undo_memory_limit": 0,
    "disable_auto_keying": False,
    "enable_navigation_guard": False,
    "prewarm_on_mouse_move": False,
    "prewarm_interval": 0.35,
    "prewarm_redraw_iterations": 0,
    "restore_after_navigation_idle": False,
    "navigation_idle_seconds": 2.0,
    "external_backup_on_register": False,
    "external_backup_on_startup": False,
    "external_backup_before_apply": False,
    "external_backup_on_file_load": False,
    "keep_backup_history": False,
    "max_backup_files": 120,
    "selected_preset": "PERFORMANCE",
    "custom_preset_name": "My Viewport Preset",
    "backup_restore_kind": "last_any",
    "force_orthographic_view": False,
    "clear_view3d_locks": False,
    "disable_object_type_selection_filters": False,
    "disable_mesh_selection_filter": False,
    "hide_unselected_objects": False,
    "force_bounds_type_box": False,
    "pause_object_simulation_cache": False,
    "enable_heavy_object_culling": False,
    "heavy_object_action": "WIRE",
    "heavy_vertex_threshold": 500000,
    "heavy_modifier_threshold": 5,
    "heavy_particle_threshold": 2,
    "set_shader_compilation_threaded": True,
    "gpu_shader_workers": 0,
    "set_memory_cache_limit": False,
    "memory_cache_limit_mb": 4096,
    "disable_region_overlap": False,
    "reduce_ui_status_draw": True,
    "enable_reduce_motion": True,
    "simplify_navigation_method": True,
    "view_rotate_method": "TURNTABLE",
    "view_zoom_method": "SCALE",
    "view_zoom_axis": "VERTICAL",
    "disable_ndof_guides": True,
    "disable_snapping_automerge": False,
    "prewarm_view_matrix_nudge": False,
    "enable_idle_warm_pulse": False,
    "idle_warm_pulse_interval": 0.8,
    "idle_pulse_view_layer_update": False,
    "idle_pulse_redraw_iterations": 0,
    "auto_save_workspace_preset_changes": False,
    "optimizer_active": False,
    "restore_before_file_events": True,
    "reapply_after_save_if_active": True,
    "keymap_operator_id": "view3d.svo_plus_toggle_optimizer",
}

MAX_SPEED_DEFAULTS.update(OPTIMIZER_SAFE_DEFAULTS)

# -----------------------------------------------------------------------------
# Robust RNA helpers
# -----------------------------------------------------------------------------


def _json_value(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (tuple, list)):
        return [_json_value(v) for v in value]
    try:
        return list(value)
    except Exception:
        return str(value)


def _get_bl_rna_property(target: Any, attr: str) -> Any:
    try:
        return target.bl_rna.properties.get(attr)
    except Exception:
        return None


def _safe_get(target: Any, attr: str, default: Any = None) -> Any:
    try:
        if hasattr(target, attr):
            return getattr(target, attr)
    except Exception:
        pass
    return default


def _safe_set(target: Any, attr: str, value: Any) -> bool:
    try:
        # Blender 5.1 can crash when some SpaceView3D region visibility flags are
        # written during restore/file-event/update contexts. Skip them completely;
        # they are UI layout states, not essential optimizer targets.
        if attr in {"show_region_toolbar", "show_region_tool_header", "show_region_ui", "show_region_hud", "show_region_asset_shelf"} and type(target).__name__ == "SpaceView3D":
            return False
        if not hasattr(target, attr):
            return False
        prop = _get_bl_rna_property(target, attr)
        if prop is not None:
            try:
                if getattr(prop, "is_readonly", False):
                    return False
            except Exception:
                pass
            try:
                if getattr(prop, "type", None) == "ENUM":
                    keys = {item.identifier for item in prop.enum_items}
                    if value not in keys:
                        return False
            except Exception:
                pass
        setattr(target, attr, value)
        return True
    except Exception:
        return False


def _safe_set_any(target: Any, attrs: Sequence[str], value: Any) -> int:
    count = 0
    for attr in attrs:
        if _safe_set(target, attr, value):
            count += 1
    return count


def _record_props(target: Any, attrs: Sequence[str]) -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    for attr in attrs:
        try:
            if hasattr(target, attr):
                data[attr] = _json_value(getattr(target, attr))
        except Exception:
            continue
    return data


def _restore_props(target: Any, data: Dict[str, Any]) -> int:
    count = 0
    for attr, value in data.items():
        if _safe_set(target, attr, value):
            count += 1
    return count


def _iter_view3d_spaces(context: bpy.types.Context) -> Iterable[Tuple[Optional[bpy.types.Window], bpy.types.Screen, int, bpy.types.Area, int, bpy.types.SpaceView3D]]:
    seen = set()
    wm = getattr(context, "window_manager", None)
    windows = list(getattr(wm, "windows", [])) if wm else []
    if windows:
        for window_index, window in enumerate(windows):
            screen = getattr(window, "screen", None)
            if screen is None:
                continue
            for area_index, area in enumerate(screen.areas):
                if area.type != "VIEW_3D":
                    continue
                for space_index, space in enumerate(area.spaces):
                    if space.type == "VIEW_3D":
                        key = (id(screen), area_index, space_index)
                        seen.add(key)
                        yield window, screen, area_index, area, space_index, space
    screen = getattr(context, "screen", None)
    if screen is not None:
        for area_index, area in enumerate(screen.areas):
            if area.type != "VIEW_3D":
                continue
            for space_index, space in enumerate(area.spaces):
                if space.type == "VIEW_3D":
                    key = (id(screen), area_index, space_index)
                    if key not in seen:
                        yield None, screen, area_index, area, space_index, space


def _tag_view3d_redraw(context: bpy.types.Context) -> None:
    global _SVO_V12_LAST_REDRAW_TS
    try:
        now = time.monotonic()
        if now - float(_SVO_V12_LAST_REDRAW_TS or 0.0) < 0.08:
            return
        _SVO_V12_LAST_REDRAW_TS = now
    except Exception:
        pass
    try:
        area = getattr(context, "area", None)
        if area is not None and getattr(area, "type", None) == "VIEW_3D":
            area.tag_redraw()
            return
    except Exception:
        pass
    for _window, _screen, _area_index, area, _space_index, _space in _iter_view3d_spaces(context):
        try:
            area.tag_redraw()
        except Exception:
            pass



def _target_scenes(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> List[bpy.types.Scene]:
    if getattr(settings, "apply_all_scenes", True):
        return list(bpy.data.scenes)
    scene = getattr(context, "scene", None)
    return [scene] if scene else []


def _target_objects(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> List[bpy.types.Object]:
    scope = getattr(settings, "object_scope", "ALL")
    if scope == "SELECTED":
        return list(getattr(context, "selected_objects", []))
    if scope == "VISIBLE":
        objects: List[bpy.types.Object] = []
        view_layer = getattr(context, "view_layer", None)
        for obj in bpy.data.objects:
            try:
                if view_layer is not None and obj.visible_get(view_layer=view_layer):
                    objects.append(obj)
            except Exception:
                try:
                    if not obj.hide_get():
                        objects.append(obj)
                except Exception:
                    pass
        return objects
    return list(bpy.data.objects)


# -----------------------------------------------------------------------------
# Property name sets
# -----------------------------------------------------------------------------

SCENE_RENDER_PROPS = (
    "use_simplify",
    "simplify_subdivision",
    "simplify_volumes",
    "simplify_child_particles",
    "simplify_texture_size",
    "simplify_gpencil",
)

SPACE_PROPS = (
    "clip_start",
    "clip_end",
    "show_gizmo",
    "show_gizmo_tool",
    "show_gizmo_context",
    "show_gizmo_navigate",
    "show_gizmo_object_translate",
    "show_gizmo_object_rotate",
    "show_gizmo_object_scale",
    "show_object_viewport_armature",
    "show_object_viewport_camera",
    "show_object_viewport_curve",
    "show_object_viewport_empty",
    "show_object_viewport_font",
    "show_object_viewport_grease_pencil",
    "show_object_viewport_gpencil",
    "show_object_viewport_lattice",
    "show_object_viewport_light",
    "show_object_viewport_light_probe",
    "show_object_viewport_mesh",
    "show_object_viewport_metaball",
    "show_object_viewport_pointcloud",
    "show_object_viewport_speaker",
    "show_object_viewport_surface",
    "show_object_viewport_volume",
)

SHADING_PROPS = (
    "type",
    "light",
    "color_type",
    "show_shadows",
    "show_cavity",
    "show_object_outline",
    "show_specular_highlight",
    "show_xray",
    "show_xray_wireframe",
    "xray_alpha",
    "xray_alpha_wireframe",
    "show_backface_culling",
    "show_scene_lights",
    "show_scene_world",
    "use_scene_lights",
    "use_scene_world",
    "use_scene_lights_render",
    "use_scene_world_render",
    "shadow_intensity",
)

OVERLAY_PROPS = (
    "show_overlays",
    "show_relationship_lines",
    "show_floor",
    "show_axis_x",
    "show_axis_y",
    "show_axis_z",
    "show_grid",
    "show_text",
    "show_stats",
    "show_extras",
    "show_wireframes",
    "wireframe_opacity",
    "show_face_orientation",
    "show_face_center",
    "show_edge_crease",
    "show_edge_sharp",
    "show_edge_bevel_weight",
    "show_edge_seams",
    "show_extra_indices",
    "show_faces",
    "show_face_normals",
    "show_vertex_normals",
    "show_split_normals",
    "normals_length",
    "show_motion_paths",
    "show_annotation",
    "show_fade_inactive",
    "fade_inactive_alpha",
    "show_outline_selected",
    "show_object_origins",
    "show_object_origins_all",
)

OBJECT_PROPS = (
    "display_type",
    "hide_select",
    "show_instancer_for_viewport",
    "show_name",
    "show_axis",
    "show_texture_space",
    "show_bounds",
    "display_show_bounds",
    "show_wire",
    "show_in_front",
)

PARTICLE_SETTING_PROPS = (
    "display_percentage",
    "display_step",
    "draw_percentage",
    "draw_step",
)

PREFERENCE_SYSTEM_PROPS = (
    "viewport_aa",
    "gl_texture_limit",
    "texture_time_out",
    "texture_collection_rate",
    "vbo_time_out",
    "vbo_collection_rate",
    "use_gpu_subdivision",
    "use_overlay_smooth_wire",
    "use_edit_mode_smooth_wire",
)

PREFERENCE_INPUT_PROPS = (
    "use_mouse_depth_navigate",
    "use_zoom_to_mouse",
    "use_rotate_around_active",
    "use_auto_perspective",
)

PREFERENCE_VIEW_PROPS = (
    "smooth_view",
    "show_navigate_ui",
    "show_gizmo",
)

PREFERENCE_EDIT_PROPS = (
    "use_global_undo",
    "undo_steps",
    "undo_memory_limit",
    "use_auto_keying",
    "use_auto_keyframe_insert_needed",
)

TOOL_SETTINGS_PROPS = (
    "use_keyframe_insert_auto",
    "use_snap",
    "use_mesh_automerge",
)

CONSTRAINT_PROPS = (
    "mute",
)

SUBDIVISION_MODIFIERS = {"SUBSURF", "MULTIRES"}
GEOMETRY_NODE_MODIFIERS = {"NODES"}
SIMULATION_MODIFIERS = {"CLOTH", "FLUID", "SOFT_BODY", "DYNAMIC_PAINT", "OCEAN", "PARTICLE_SYSTEM"}
DEFORMER_MODIFIERS = {
    "ARMATURE",
    "CAST",
    "CURVE",
    "DISPLACE",
    "HOOK",
    "LAPLACIANDEFORM",
    "LATTICE",
    "MESH_DEFORM",
    "SHRINKWRAP",
    "SIMPLE_DEFORM",
    "SMOOTH",
    "CORRECTIVE_SMOOTH",
    "LAPLACIANSMOOTH",
    "WARP",
    "WAVE",
}
GENERATOR_MODIFIERS = {
    "ARRAY",
    "BEVEL",
    "BOOLEAN",
    "BUILD",
    "DECIMATE",
    "EDGE_SPLIT",
    "MIRROR",
    "REMESH",
    "SCREW",
    "SKIN",
    "SOLIDIFY",
    "TRIANGULATE",
    "WIREFRAME",
    "WELD",
}
NORMAL_DATA_MODIFIERS = {"WEIGHTED_NORMAL", "NORMAL_EDIT", "DATA_TRANSFER"}
KNOWN_MODIFIER_TYPES = (
    SUBDIVISION_MODIFIERS
    | GEOMETRY_NODE_MODIFIERS
    | SIMULATION_MODIFIERS
    | DEFORMER_MODIFIERS
    | GENERATOR_MODIFIERS
    | NORMAL_DATA_MODIFIERS
)


# -----------------------------------------------------------------------------
# Snapshot
# -----------------------------------------------------------------------------


# v6: capture additional state that the deeper optimizer may change.
SPACE_PROPS = tuple(dict.fromkeys(SPACE_PROPS + (
    "show_object_viewport_mesh", "show_object_select_mesh", "show_object_select_camera", "show_object_select_light",
    "show_object_select_empty", "show_object_select_armature", "show_object_select_curve", "show_object_select_surface",
    "show_object_select_font", "show_object_select_metaball", "show_object_select_lattice", "show_object_select_speaker",
    "show_object_select_light_probe", "show_object_select_volume", "show_object_select_grease_pencil", "show_object_select_pointcloud",
    "lock_camera", "lock_cursor", "lock_bone",
)))
OBJECT_PROPS = tuple(dict.fromkeys(OBJECT_PROPS + (
    "hide_viewport", "display_bounds_type", "use_simulation_cache",
)))
PREFERENCE_SYSTEM_PROPS = tuple(dict.fromkeys(PREFERENCE_SYSTEM_PROPS + (
    "shader_compilation_method", "gpu_shader_workers", "memory_cache_limit", "use_region_overlap",
)))
PREFERENCE_INPUT_PROPS = tuple(dict.fromkeys(PREFERENCE_INPUT_PROPS + (
    "view_rotate_method", "view_zoom_method", "view_zoom_axis", "show_nDOF_settings", "show_ndof_settings",
    "use_ndof_orbit", "use_ndof_pan", "use_ndof_zoom",
)))
PREFERENCE_VIEW_PROPS = tuple(dict.fromkeys(PREFERENCE_VIEW_PROPS + (
    "use_reduce_motion", "show_statusbar_stats", "show_statusbar_memory", "show_statusbar_vram", "show_statusbar_version",
)))


def _snapshot_exists(scene: Optional[bpy.types.Scene]) -> bool:
    if scene is None:
        return False
    try:
        return bool(scene.smart_viewport_optimizer_snapshot_json)
    except Exception:
        return False


def _capture_snapshot(context: bpy.types.Context, force: bool = False) -> bool:
    scene = getattr(context, "scene", None)
    if scene is None:
        return False
    settings = scene.smart_viewport_optimizer_settings
    if not force and getattr(settings, "protect_existing_snapshot", True) and _snapshot_exists(scene):
        return False

    snapshot: Dict[str, Any] = {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "scenes": [],
        "view3d_spaces": [],
        "objects": [],
        "modifiers": [],
        "constraints": [],
        "pose_constraints": [],
        "particle_settings": [],
        "preferences_system": {},
        "preferences_inputs": {},
        "preferences_view": {},
        "preferences_edit": {},
        "tool_settings": [],
        "selection": {},
    }

    for scn in _target_scenes(context, settings):
        scene_entry: Dict[str, Any] = {"name": scn.name}
        render = getattr(scn, "render", None)
        if render is not None:
            scene_entry["render"] = _record_props(render, SCENE_RENDER_PROPS)
        display = getattr(scn, "display", None)
        if display is not None:
            scene_entry["display"] = _record_props(display, globals().get("SCENE_DISPLAY_PROPS", ()))
        eevee = getattr(scn, "eevee", None)
        if eevee is not None:
            scene_entry["eevee"] = _record_props(eevee, globals().get("SCENE_EEVEE_PROPS", ()))
        cycles = getattr(scn, "cycles", None)
        if cycles is not None:
            scene_entry["cycles"] = _record_props(cycles, globals().get("SCENE_CYCLES_PROPS", ()))
        snapshot["scenes"].append(scene_entry)

    for window, screen, area_index, _area, space_index, space in _iter_view3d_spaces(context):
        snapshot["view3d_spaces"].append({
            "window_index": -1 if window is None else list(context.window_manager.windows).index(window),
            "screen_name": getattr(screen, "name", ""),
            "area_index": area_index,
            "space_index": space_index,
            "space": _record_props(space, SPACE_PROPS),
            "shading": _record_props(space.shading, SHADING_PROPS),
            "overlay": _record_props(space.overlay, OVERLAY_PROPS),
        })

    for obj in _target_objects(context, settings):
        snapshot["objects"].append({"name": obj.name, "props": _record_props(obj, OBJECT_PROPS)})
        for mod in getattr(obj, "modifiers", []):
            try:
                snapshot["modifiers"].append({
                    "object": obj.name,
                    "modifier": mod.name,
                    "show_viewport": bool(mod.show_viewport),
                })
            except Exception:
                continue
        for con in getattr(obj, "constraints", []):
            try:
                snapshot["constraints"].append({
                    "object": obj.name,
                    "constraint": con.name,
                    "props": _record_props(con, CONSTRAINT_PROPS),
                })
            except Exception:
                continue
        pose = getattr(obj, "pose", None)
        if pose is not None:
            for bone in getattr(pose, "bones", []):
                for con in getattr(bone, "constraints", []):
                    try:
                        snapshot["pose_constraints"].append({
                            "object": obj.name,
                            "bone": bone.name,
                            "constraint": con.name,
                            "props": _record_props(con, CONSTRAINT_PROPS),
                        })
                    except Exception:
                        continue

    try:
        particle_settings = list(bpy.data.particles)
    except Exception:
        particle_settings = []
    for pset in particle_settings:
        snapshot["particle_settings"].append({"name": pset.name, "props": _record_props(pset, PARTICLE_SETTING_PROPS)})

    prefs = getattr(context, "preferences", None)
    system = getattr(prefs, "system", None)
    if system is not None:
        snapshot["preferences_system"] = _record_props(system, PREFERENCE_SYSTEM_PROPS)
    inputs = getattr(prefs, "inputs", None)
    if inputs is not None:
        snapshot["preferences_inputs"] = _record_props(inputs, PREFERENCE_INPUT_PROPS)
    view = getattr(prefs, "view", None)
    if view is not None:
        snapshot["preferences_view"] = _record_props(view, PREFERENCE_VIEW_PROPS)
    edit = getattr(prefs, "edit", None)
    if edit is not None:
        snapshot["preferences_edit"] = _record_props(edit, PREFERENCE_EDIT_PROPS)

    for scn in _target_scenes(context, settings):
        tool_settings = getattr(scn, "tool_settings", None)
        if tool_settings is not None:
            snapshot["tool_settings"].append({"scene": scn.name, "props": _record_props(tool_settings, TOOL_SETTINGS_PROPS)})

    active_obj = getattr(getattr(context, "view_layer", None), "objects", None)
    active_obj = getattr(active_obj, "active", None) if active_obj is not None else None
    try:
        selected_names = [obj.name for obj in getattr(context, "selected_objects", [])]
    except Exception:
        selected_names = []
    snapshot["selection"] = {
        "selected": selected_names,
        "active": getattr(active_obj, "name", "") if active_obj is not None else "",
        "active_mode": getattr(active_obj, "mode", "OBJECT") if active_obj is not None else "OBJECT",
    }

    try:
        # A restore point must hold the view as it is now; the short-lived cache
        # would write the overlay/shading of up to 1.25 s ago into it.
        layout_data = _svo_v14_get_cached_view3d_layout(context, max_age=-1.0)
        if isinstance(layout_data, dict) and layout_data.get("areas"):
            snapshot["view3d_layout"] = layout_data
    except Exception:
        pass

    try:
        scene.smart_viewport_optimizer_snapshot_json = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":"))
        return True
    except Exception:
        return False


def _restore_snapshot(context: bpy.types.Context) -> bool:
    scene = getattr(context, "scene", None)
    if scene is None or not _snapshot_exists(scene):
        return False
    try:
        snapshot = json.loads(scene.smart_viewport_optimizer_snapshot_json)
    except Exception:
        return False

    for scene_data in snapshot.get("scenes", []):
        scn = bpy.data.scenes.get(scene_data.get("name", ""))
        if scn and getattr(scn, "render", None):
            _restore_props(scn.render, scene_data.get("render", {}))
        if scn and getattr(scn, "display", None):
            _restore_props(scn.display, scene_data.get("display", {}))
        if scn and getattr(scn, "eevee", None):
            _restore_props(scn.eevee, scene_data.get("eevee", {}))
        if scn and getattr(scn, "cycles", None):
            _restore_props(scn.cycles, scene_data.get("cycles", {}))

    current_spaces = list(_iter_view3d_spaces(context))
    used_indices = set()
    for space_data in snapshot.get("view3d_spaces", []):
        target_tuple = None
        for idx, item in enumerate(current_spaces):
            if idx in used_indices:
                continue
            _window, screen, area_index, _area, space_index, space = item
            if (
                getattr(screen, "name", "") == space_data.get("screen_name", "")
                and area_index == space_data.get("area_index")
                and space_index == space_data.get("space_index")
            ):
                target_tuple = item
                used_indices.add(idx)
                break
        if target_tuple is None and current_spaces:
            for idx, item in enumerate(current_spaces):
                if idx not in used_indices:
                    target_tuple = item
                    used_indices.add(idx)
                    break
        if target_tuple is None:
            continue
        _window, _screen, _area_index, _area, _space_index, space = target_tuple
        _restore_props(space, space_data.get("space", {}))
        _restore_props(space.shading, space_data.get("shading", {}))
        _restore_props(space.overlay, space_data.get("overlay", {}))

    if _svo_v16_can_apply_view3d_layout(context):
        try:
            _svo_v14_apply_view3d_layout(context, snapshot.get("view3d_layout"))
        except Exception:
            pass

    for obj_data in snapshot.get("objects", []):
        obj = bpy.data.objects.get(obj_data.get("name", ""))
        if obj:
            _restore_props(obj, obj_data.get("props", {}))

    for mod_data in snapshot.get("modifiers", []):
        obj = bpy.data.objects.get(mod_data.get("object", ""))
        if not obj:
            continue
        mod = obj.modifiers.get(mod_data.get("modifier", ""))
        if mod is not None:
            _safe_set(mod, "show_viewport", bool(mod_data.get("show_viewport", True)))

    for con_data in snapshot.get("constraints", []):
        obj = bpy.data.objects.get(con_data.get("object", ""))
        constraints = getattr(obj, "constraints", None) if obj else None
        con = constraints.get(con_data.get("constraint", "")) if constraints is not None else None
        if con is not None:
            _restore_props(con, con_data.get("props", {}))

    for con_data in snapshot.get("pose_constraints", []):
        obj = bpy.data.objects.get(con_data.get("object", ""))
        pose = getattr(obj, "pose", None) if obj else None
        bone = pose.bones.get(con_data.get("bone", "")) if pose is not None else None
        con = bone.constraints.get(con_data.get("constraint", "")) if bone is not None else None
        if con is not None:
            _restore_props(con, con_data.get("props", {}))

    for pset_data in snapshot.get("particle_settings", []):
        pset = bpy.data.particles.get(pset_data.get("name", "")) if hasattr(bpy.data, "particles") else None
        if pset is not None:
            _restore_props(pset, pset_data.get("props", {}))

    prefs = getattr(context, "preferences", None)
    system = getattr(prefs, "system", None)
    if system is not None:
        _restore_props(system, snapshot.get("preferences_system", {}))
    inputs = getattr(prefs, "inputs", None)
    if inputs is not None:
        _restore_props(inputs, snapshot.get("preferences_inputs", {}))
    view = getattr(prefs, "view", None)
    if view is not None:
        _restore_props(view, snapshot.get("preferences_view", {}))
    edit = getattr(prefs, "edit", None)
    if edit is not None:
        _restore_props(edit, snapshot.get("preferences_edit", {}))

    for tool_data in snapshot.get("tool_settings", []):
        scn = bpy.data.scenes.get(tool_data.get("scene", ""))
        tool_settings = getattr(scn, "tool_settings", None) if scn else None
        if tool_settings is not None:
            _restore_props(tool_settings, tool_data.get("props", {}))

    selection = snapshot.get("selection", {})
    try:
        if _svo_v16_can_use_mode_operator(context) and getattr(context, "active_object", None) is not None and getattr(context.active_object, "mode", "OBJECT") != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    try:
        for obj in bpy.data.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
        for name in selection.get("selected", []):
            obj = bpy.data.objects.get(name)
            if obj is not None:
                try:
                    obj.select_set(True)
                except Exception:
                    pass
        active_name = selection.get("active", "")
        if active_name and getattr(context, "view_layer", None):
            active_obj = bpy.data.objects.get(active_name)
            if active_obj is not None:
                context.view_layer.objects.active = active_obj
                mode = selection.get("active_mode", "OBJECT")
                if mode and mode != "OBJECT" and _svo_v16_can_use_mode_operator(context):
                    try:
                        bpy.ops.object.mode_set(mode=mode)
                    except Exception:
                        pass
    except Exception:
        pass

    _request_navigation_guard_stop(context, restore=False)
    _tag_view3d_redraw(context)
    return True


# -----------------------------------------------------------------------------
# Apply optimization
# -----------------------------------------------------------------------------


def _modifier_matches(settings: bpy.types.PropertyGroup, modifier_type: str) -> bool:
    if modifier_type in SUBDIVISION_MODIFIERS:
        return bool(settings.disable_subdivision_modifiers)
    if modifier_type in GEOMETRY_NODE_MODIFIERS:
        return bool(settings.disable_geometry_nodes)
    if modifier_type in SIMULATION_MODIFIERS:
        return bool(settings.disable_simulation_modifiers)
    if modifier_type in DEFORMER_MODIFIERS:
        return bool(settings.disable_deformer_modifiers)
    if modifier_type in GENERATOR_MODIFIERS:
        return bool(settings.disable_generator_modifiers)
    if modifier_type in NORMAL_DATA_MODIFIERS:
        return bool(settings.disable_normal_data_modifiers)
    return bool(settings.disable_other_modifiers)


def _apply_scene_simplify(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_scene_simplify:
        return
    for scn in _target_scenes(context, settings):
        render = getattr(scn, "render", None)
        if render is None:
            continue
        if settings.use_simplify:
            _safe_set(render, "use_simplify", True)
        if settings.force_subdivision_level:
            _safe_set(render, "simplify_subdivision", int(settings.subdivision_level))
        if settings.force_volume_resolution:
            _safe_set(render, "simplify_volumes", float(settings.volume_value))
        if settings.force_child_particles:
            _safe_set(render, "simplify_child_particles", float(settings.child_particle_percentage))
        if settings.force_texture_size:
            _safe_set(render, "simplify_texture_size", int(settings.texture_size))
        if settings.simplify_grease_pencil:
            _safe_set(render, "simplify_gpencil", True)


def _apply_viewport_shading(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_viewport_shading:
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        shading = space.shading
        if settings.force_wireframe_mode:
            _safe_set(shading, "type", "WIREFRAME")
        elif settings.use_flat_solid_fallback:
            _safe_set(shading, "type", "SOLID")
        if settings.use_flat_solid_fallback:
            _safe_set(shading, "light", "FLAT")
        if settings.use_single_color:
            _safe_set(shading, "color_type", "SINGLE")
        if settings.disable_shadows:
            _safe_set(shading, "show_shadows", False)
            _safe_set(shading, "shadow_intensity", 0.0)
        if settings.disable_cavity:
            _safe_set(shading, "show_cavity", False)
        if settings.disable_object_outlines:
            _safe_set(shading, "show_object_outline", False)
        if settings.disable_specular:
            _safe_set(shading, "show_specular_highlight", False)
        if settings.disable_xray:
            _safe_set(shading, "show_xray", False)
            _safe_set(shading, "show_xray_wireframe", False)
            _safe_set(shading, "xray_alpha", 0.0)
            _safe_set(shading, "xray_alpha_wireframe", 0.0)
        if settings.disable_scene_lights:
            _safe_set_any(shading, ("show_scene_lights", "use_scene_lights", "use_scene_lights_render"), False)
        if settings.disable_scene_world:
            _safe_set_any(shading, ("show_scene_world", "use_scene_world", "use_scene_world_render"), False)
        if settings.enable_backface_culling:
            _safe_set(shading, "show_backface_culling", True)
        if settings.limit_far_clip:
            _safe_set(space, "clip_end", float(settings.clip_end))
        if settings.limit_near_clip:
            _safe_set(space, "clip_start", float(settings.clip_start))


def _apply_overlays(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_overlays:
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        overlay = space.overlay
        if settings.hide_all_overlays:
            _safe_set(overlay, "show_overlays", False)
        if settings.hide_relationship_lines:
            _safe_set(overlay, "show_relationship_lines", False)
        if settings.hide_grid_axes:
            _safe_set_any(overlay, ("show_floor", "show_axis_x", "show_axis_y", "show_axis_z", "show_grid"), False)
        if settings.hide_text_stats:
            _safe_set_any(overlay, ("show_text", "show_stats"), False)
        if settings.hide_extras:
            _safe_set_any(overlay, ("show_extras", "show_outline_selected", "show_object_origins", "show_object_origins_all"), False)
        if settings.hide_wire_overlay:
            _safe_set(overlay, "show_wireframes", False)
            _safe_set(overlay, "wireframe_opacity", 0.0)
        if settings.hide_normals:
            _safe_set_any(overlay, ("show_face_normals", "show_vertex_normals", "show_split_normals"), False)
            _safe_set(overlay, "normals_length", 0.0)
        if settings.hide_edit_guides:
            _safe_set_any(
                overlay,
                (
                    "show_face_center",
                    "show_edge_crease",
                    "show_edge_sharp",
                    "show_edge_bevel_weight",
                    "show_edge_seams",
                    "show_extra_indices",
                    "show_face_orientation",
                ),
                False,
            )
        if settings.hide_motion_paths:
            _safe_set(overlay, "show_motion_paths", False)
        if settings.hide_annotations:
            _safe_set(overlay, "show_annotation", False)
        _safe_set(overlay, "show_fade_inactive", False)
        _safe_set(overlay, "fade_inactive_alpha", 0.0)


def _apply_gizmos(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_gizmos:
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        if settings.hide_all_gizmos:
            _safe_set(space, "show_gizmo", False)
        if settings.hide_navigation_gizmo:
            _safe_set(space, "show_gizmo_navigate", False)
        if settings.hide_tool_gizmos:
            _safe_set(space, "show_gizmo_tool", False)
        if settings.hide_context_gizmos:
            _safe_set(space, "show_gizmo_context", False)
        if settings.hide_object_transform_gizmos:
            _safe_set_any(space, ("show_gizmo_object_translate", "show_gizmo_object_rotate", "show_gizmo_object_scale"), False)


def _apply_object_filters(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_object_filters:
        return
    mapping = {
        "hide_lights": ("show_object_viewport_light",),
        "hide_cameras": ("show_object_viewport_camera",),
        "hide_empties": ("show_object_viewport_empty",),
        "hide_armatures": ("show_object_viewport_armature",),
        "hide_curves": ("show_object_viewport_curve", "show_object_viewport_curves"),
        "hide_surfaces": ("show_object_viewport_surface", "show_object_viewport_surf"),
        "hide_fonts": ("show_object_viewport_font",),
        "hide_metaballs": ("show_object_viewport_metaball", "show_object_viewport_meta"),
        "hide_lattices": ("show_object_viewport_lattice",),
        "hide_speakers": ("show_object_viewport_speaker",),
        "hide_light_probes": ("show_object_viewport_light_probe",),
        "hide_volumes": ("show_object_viewport_volume",),
        "hide_grease_pencil": ("show_object_viewport_grease_pencil", "show_object_viewport_gpencil"),
        "hide_pointclouds": ("show_object_viewport_pointcloud",),
    }
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        for setting_name, attrs in mapping.items():
            if bool(getattr(settings, setting_name, False)):
                _safe_set_any(space, attrs, False)


def _apply_object_display(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_object_display:
        return
    for obj in _target_objects(context, settings):
        if settings.force_object_display_type:
            _safe_set(obj, "display_type", settings.object_display_type)
        if settings.hide_object_names_axes:
            _safe_set_any(obj, ("show_name", "show_axis", "show_texture_space", "show_in_front"), False)
            _safe_set(obj, "show_bounds", True)
            _safe_set(obj, "display_show_bounds", True)
        if getattr(settings, "disable_object_selection", False):
            _safe_set(obj, "hide_select", True)
        if getattr(settings, "hide_instancer_viewport", False):
            _safe_set(obj, "show_instancer_for_viewport", False)


def _apply_modifiers(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_modifiers or not settings.disable_viewport_modifiers:
        return
    for obj in _target_objects(context, settings):
        for mod in getattr(obj, "modifiers", []):
            try:
                if _modifier_matches(settings, mod.type):
                    _safe_set(mod, "show_viewport", False)
            except Exception:
                continue


def _apply_particles(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_particles or not settings.reduce_particle_previews:
        return
    try:
        particle_settings = list(bpy.data.particles)
    except Exception:
        particle_settings = []
    for pset in particle_settings:
        _safe_set(pset, "display_percentage", int(settings.particle_display_percentage))
        _safe_set(pset, "draw_percentage", int(settings.particle_display_percentage))
        _safe_set(pset, "display_step", int(settings.particle_display_step))
        _safe_set(pset, "draw_step", int(settings.particle_display_step))


def _apply_render_preview_settings(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_render_preview_settings", True):
        return
    for scn in _target_scenes(context, settings):
        render = getattr(scn, "render", None)
        if render is not None:
            for prop, key in (
                ("preview_pixel_size", "target_render_preview_pixel_size"),
                ("use_high_quality_normals", "target_render_use_high_quality_normals"),
                ("use_simplify_normals", "target_render_use_simplify_normals"),
                ("use_persistent_data", "target_render_use_persistent_data"),
            ):
                _safe_set(render, prop, _svo_v11_get(settings, key))
        display = getattr(scn, "display", None)
        if display is not None:
            for prop, key in (
                ("viewport_aa", "target_scene_viewport_aa"),
                ("render_aa", "target_scene_render_aa"),
            ):
                _safe_set(display, prop, _svo_v11_get(settings, key))
        eevee = getattr(scn, "eevee", None)
        if eevee is not None:
            for prop, key in (
                ("taa_samples", "target_eevee_taa_samples"),
                ("use_taa_reprojection", "target_eevee_use_taa_reprojection"),
                ("use_shadows", "target_eevee_use_shadows"),
                ("shadow_pool_size", "target_eevee_shadow_pool_size"),
                ("shadow_resolution_scale", "target_eevee_shadow_resolution_scale"),
                ("shadow_ray_count", "target_eevee_shadow_ray_count"),
                ("shadow_step_count", "target_eevee_shadow_step_count"),
                ("use_raytracing", "target_eevee_use_raytracing"),
                ("ray_tracing_method", "target_eevee_ray_tracing_method"),
                ("volumetric_tile_size", "target_eevee_volumetric_tile_size"),
                ("volumetric_samples", "target_eevee_volumetric_samples"),
                ("volumetric_ray_depth", "target_eevee_volumetric_ray_depth"),
                ("use_volumetric_shadows", "target_eevee_use_volumetric_shadows"),
                ("volumetric_shadow_samples", "target_eevee_volumetric_shadow_samples"),
            ):
                _safe_set(eevee, prop, _svo_v11_get(settings, key))
        cycles = getattr(scn, "cycles", None)
        if cycles is not None:
            for prop, key in (
                ("preview_samples", "target_cycles_preview_samples"),
                ("use_preview_denoising", "target_cycles_use_preview_denoising"),
                ("preview_denoising_quality", "target_cycles_preview_denoising_quality"),
                ("texture_limit", "target_cycles_texture_limit"),
                ("volume_preview_step_rate", "target_cycles_volume_preview_step_rate"),
                ("preview_dicing_rate", "target_cycles_preview_dicing_rate"),
            ):
                _safe_set(cycles, prop, _svo_v11_get(settings, key))


def _apply_preferences(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not settings.include_preferences:
        return
    prefs = getattr(context, "preferences", None)
    system = getattr(prefs, "system", None)
    if system is not None:
        if settings.disable_viewport_aa:
            _safe_set(system, "viewport_aa", "OFF")
        if getattr(settings, "keep_texture_vbo_cache_warm", False):
            _safe_set(system, "texture_time_out", int(settings.texture_cache_seconds))
            _safe_set(system, "vbo_time_out", int(settings.vbo_cache_seconds))
            _safe_set(system, "texture_collection_rate", int(settings.texture_collection_rate))
            _safe_set(system, "vbo_collection_rate", int(settings.vbo_collection_rate))
        gl_limit = getattr(settings, "gl_texture_limit", "OFF")
        if gl_limit != "CLAMP_OFF":
            _safe_set(system, "gl_texture_limit", gl_limit)
        if settings.disable_gpu_subdivision:
            _safe_set(system, "use_gpu_subdivision", False)
        if getattr(settings, "disable_smooth_wires", False):
            _safe_set(system, "use_overlay_smooth_wire", False)
            _safe_set(system, "use_edit_mode_smooth_wire", False)


def _apply_navigation_latency(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not getattr(settings, "include_navigation_latency", True):
        return
    prefs = getattr(context, "preferences", None)
    inputs = getattr(prefs, "inputs", None)
    if inputs is not None:
        if settings.disable_depth_navigation:
            _safe_set(inputs, "use_mouse_depth_navigate", False)
        if settings.disable_zoom_to_mouse:
            _safe_set(inputs, "use_zoom_to_mouse", False)
        if settings.disable_rotate_around_active:
            _safe_set(inputs, "use_rotate_around_active", False)
        if settings.disable_auto_perspective:
            _safe_set(inputs, "use_auto_perspective", False)
    view = getattr(prefs, "view", None)
    if view is not None:
        if settings.disable_smooth_view:
            _safe_set(view, "smooth_view", 0)
        if settings.hide_global_navigation_ui:
            _safe_set(view, "show_navigate_ui", False)
    edit = getattr(prefs, "edit", None)
    if edit is not None:
        if settings.disable_global_undo:
            _safe_set(edit, "use_global_undo", False)
            _safe_set(edit, "undo_steps", int(settings.undo_steps))
            _safe_set(edit, "undo_memory_limit", int(settings.undo_memory_limit))
        if settings.disable_auto_keying:
            _safe_set(edit, "use_auto_keying", False)
            _safe_set(edit, "use_auto_keyframe_insert_needed", False)

    if settings.disable_auto_keying:
        for scn in _target_scenes(context, settings):
            tool_settings = getattr(scn, "tool_settings", None)
            if tool_settings is not None:
                _safe_set(tool_settings, "use_keyframe_insert_auto", False)

    if settings.force_object_mode_on_apply and _svo_v16_can_use_mode_operator(context):
        try:
            if getattr(context, "active_object", None) is not None and getattr(context.active_object, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass



def _apply_selection_latency(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not getattr(settings, "include_navigation_latency", True):
        return
    if settings.clear_selection_on_apply:
        for obj in list(getattr(context, "selected_objects", [])):
            try:
                obj.select_set(False)
            except Exception:
                pass


def _apply_constraints(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not getattr(settings, "include_constraints", True):
        return
    for obj in _target_objects(context, settings):
        if settings.mute_object_constraints:
            for con in getattr(obj, "constraints", []):
                _safe_set(con, "mute", True)
        if settings.mute_pose_constraints:
            pose = getattr(obj, "pose", None)
            if pose is not None:
                for bone in getattr(pose, "bones", []):
                    for con in getattr(bone, "constraints", []):
                        _safe_set(con, "mute", True)


def _prewarm_viewport(context: bpy.types.Context, settings: bpy.types.PropertyGroup, quick: bool = False) -> None:
    """Crash-safe viewport prewarm.

    Blender 5.1 crash reports showed that calling bpy.ops.wm.redraw_timer from
    file-load/update code can collide with View3D header drawing. This function
    intentionally avoids redraw_timer and other UI operators. It only requests
    redraw on existing 3D View areas and, when explicitly enabled, performs a
    guarded view-layer update outside background mode.
    """
    if not getattr(settings, "include_viewport_prewarm", True):
        return
    try:
        if (not bpy.app.background
                and not quick
                and bool(getattr(settings, "idle_pulse_view_layer_update", False))
                and getattr(context, "view_layer", None) is not None):
            context.view_layer.update()
    except Exception:
        pass
    _tag_view3d_redraw(context)

def _svo_force_latency_static_settings(settings: Any) -> None:
    """Disable all live/timer-based optimization helpers for latency-sensitive navigation."""
    if settings is None:
        return
    for _name, _value in (
        ("include_viewport_prewarm", False),
        ("enable_navigation_guard", False),
        ("prewarm_on_mouse_move", False),
        ("prewarm_view_matrix_nudge", False),
        ("enable_idle_warm_pulse", False),
        ("idle_pulse_view_layer_update", False),
        ("idle_pulse_redraw_iterations", 0),
        ("prewarm_redraw_iterations", 0),
        ("external_backup_on_register", False),
        ("external_backup_on_startup", False),
        ("external_backup_on_file_load", False),
        ("external_backup_before_apply", False),
        ("keep_backup_history", False),
        ("auto_save_workspace_preset_changes", False),
    ):
        try:
            if hasattr(settings, _name):
                setattr(settings, _name, _value)
        except Exception:
            pass


def apply_optimizer(context: bpy.types.Context, capture_snapshot: bool = True, allow_ui_warm: bool = True, allow_guard: bool = True) -> None:
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    settings = scene.smart_viewport_optimizer_settings
    _svo_force_latency_static_settings(settings)
    allow_ui_warm = False
    allow_guard = False
    capture_snapshot = bool(capture_snapshot and False)
    if capture_snapshot:
        if getattr(settings, "external_backup_before_apply", True):
            _svo_v6_capture_external_backup(context, "before_apply")
        _capture_snapshot(context, force=False)
    _apply_navigation_latency(context, settings)
    _apply_scene_simplify(context, settings)
    _apply_render_preview_settings(context, settings)
    _apply_viewport_shading(context, settings)
    _apply_overlays(context, settings)
    _apply_gizmos(context, settings)
    _apply_object_filters(context, settings)
    _apply_object_display(context, settings)
    _apply_modifiers(context, settings)
    _apply_constraints(context, settings)
    _apply_selection_latency(context, settings)
    _apply_particles(context, settings)
    _apply_preferences(context, settings)
    _svo_v6_apply_system_deep(context, settings)
    _svo_v6_apply_deeper_view(context, settings)
    if allow_ui_warm:
        _svo_v6_prewarm_view_matrix(context, settings)
        _prewarm_viewport(context, settings, quick=False)
        _svo_v6_ensure_idle_warm(context)
    if allow_guard:
        _ensure_navigation_guard(context)
    settings.status_text = "Applied"
    _tag_view3d_redraw(context)


def reset_options_to_max_speed(settings: bpy.types.PropertyGroup) -> None:
    _svo_v6_apply_preset_to_settings(settings, "PERFORMANCE")


# -----------------------------------------------------------------------------
# Properties
# -----------------------------------------------------------------------------


class SVO_PLUS_PG_settings(bpy.types.PropertyGroup):
    status_text: bpy.props.StringProperty(default="Ready", options={"SKIP_SAVE"})

    show_quick: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_targets: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_scene: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_viewport: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_overlay: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_gizmo: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_filter: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_object: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_modifier: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_constraint: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_navigation: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_prewarm: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_particle: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_pref: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    show_snapshot: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    auto_apply_on_enable: bpy.props.BoolProperty(
        name="Apply on add-on enable",
        description="Automatically apply the lightweight preset once after the add-on is enabled. Use this when you want the viewport to become light immediately after installation or activation.",
        default=MAX_SPEED_DEFAULTS["auto_apply_on_enable"],
    )
    auto_apply_on_load: bpy.props.BoolProperty(
        name="Apply on file load",
        description="Automatically re-apply the selected lightweight options after a .blend file is loaded. This is useful when heavy scenes reopen in an expensive viewport state.",
        default=MAX_SPEED_DEFAULTS["auto_apply_on_load"],
    )
    protect_existing_snapshot: bpy.props.BoolProperty(
        name="Protect existing snapshot",
        description="Keep the first captured restore snapshot instead of overwriting it on every apply. Leave this on when you want Restore Snapshot to return to the state before the first optimization.",
        default=MAX_SPEED_DEFAULTS["protect_existing_snapshot"],
    )
    apply_all_scenes: bpy.props.BoolProperty(
        name="Apply all scenes",
        description="Apply scene-level Simplify settings to every scene in the file, not only the active scene. This helps when multiple scenes share heavy assets.",
        default=MAX_SPEED_DEFAULTS["apply_all_scenes"],
    )
    object_scope: bpy.props.EnumProperty(
        name="Object scope",
        description="Choose which objects are affected by object display, modifier, and particle optimization. All gives the strongest speed-up, while Selected is safer for focused editing.",
        items=(
            ("ALL", "All Objects", "Apply object-level optimization to every object in the file."),
            ("SELECTED", "Selected Objects", "Apply object-level optimization only to selected objects."),
            ("VISIBLE", "Visible Objects", "Apply object-level optimization only to objects visible in the current view layer."),
        ),
        default=MAX_SPEED_DEFAULTS["object_scope"],
    )

    include_scene_simplify: bpy.props.BoolProperty(name="Include Scene Simplify", description="Enable the scene Simplify section. When on, the add-on can force lower subdivision, volume, texture, Grease Pencil, and particle preview cost.", default=MAX_SPEED_DEFAULTS["include_scene_simplify"])
    include_viewport_shading: bpy.props.BoolProperty(name="Include Viewport Shading", description="Enable viewport shading optimization. This changes each 3D View to wireframe or flat solid display and disables expensive lighting effects.", default=MAX_SPEED_DEFAULTS["include_viewport_shading"])
    include_overlays: bpy.props.BoolProperty(name="Include Overlays", description="Enable overlay optimization. Relationship lines, grid axes, normals, edit guides, annotations, and statistics can be hidden to reduce redraw work.", default=MAX_SPEED_DEFAULTS["include_overlays"])
    include_gizmos: bpy.props.BoolProperty(name="Include Gizmos", description="Enable gizmo optimization. Transform, tool, context, and navigation gizmos can be hidden so the viewport has fewer interactive elements to draw and update.", default=MAX_SPEED_DEFAULTS["include_gizmos"])
    include_object_filters: bpy.props.BoolProperty(name="Include Object Filters", description="Enable viewport object-type filters. Cameras, lights, empties, armatures, curves, volumes, and other helper types can be hidden in the 3D View without deleting them.", default=MAX_SPEED_DEFAULTS["include_object_filters"])
    include_object_display: bpy.props.BoolProperty(name="Include Object Display", description="Enable per-object display optimization. Objects can be switched to bounding box or wire display, which is often much lighter than shaded geometry.", default=MAX_SPEED_DEFAULTS["include_object_display"])
    include_modifiers: bpy.props.BoolProperty(name="Include Modifiers", description="Enable modifier viewport suppression. Expensive viewport modifiers can be disabled temporarily and restored from the snapshot later.", default=MAX_SPEED_DEFAULTS["include_modifiers"])
    include_particles: bpy.props.BoolProperty(name="Include Particles", description="Enable particle preview reduction. Particle display percentage and draw steps can be reduced to make dense particle systems lighter in the viewport.", default=MAX_SPEED_DEFAULTS["include_particles"])
    include_preferences: bpy.props.BoolProperty(name="Include Preferences", description="Enable session-level preference optimization. This can disable viewport anti-aliasing and keep viewport cache data warm for the current Blender session without saving user preferences.", default=MAX_SPEED_DEFAULTS["include_preferences"])
    include_navigation_latency: bpy.props.BoolProperty(name="Navigation Start Lag", description="Enable input, undo, selection, and view settings that directly target the small hitch when orbit, pan, or zoom begins.", default=MAX_SPEED_DEFAULTS["include_navigation_latency"])
    include_constraints: bpy.props.BoolProperty(name="Constraints", description="Enable temporary muting of object and pose constraints to reduce dependency-graph evaluation during navigation.", default=MAX_SPEED_DEFAULTS["include_constraints"])
    include_viewport_prewarm: bpy.props.BoolProperty(name="Viewport Prewarm", description="Enable redraw and dependency update prewarming so startup cost is shifted before the first manual navigation event.", default=MAX_SPEED_DEFAULTS["include_viewport_prewarm"])

    use_simplify: bpy.props.BoolProperty(name="Use Simplify", description="Turn on Blender's Simplify system for the target scene. Simplify is a global scene switch that lets Blender use cheaper viewport representations.", default=MAX_SPEED_DEFAULTS["use_simplify"])
    force_subdivision_level: bpy.props.BoolProperty(name="Force subdivision level", description="Clamp the viewport subdivision preview level. Set the value to 0 for the strongest speed-up on Subdivision Surface and similar preview levels.", default=MAX_SPEED_DEFAULTS["force_subdivision_level"])
    subdivision_level: bpy.props.IntProperty(name="Subdivision level", description="Viewport subdivision level used when Force subdivision level is on. Lower values are lighter; 0 means no viewport subdivision preview.", default=MAX_SPEED_DEFAULTS["subdivision_level"], min=0, max=16)
    force_volume_resolution: bpy.props.BoolProperty(name="Force volume resolution", description="Reduce viewport volume resolution through Simplify. A value of 0 is the lightest and can make volumetric previews very coarse or hidden depending on Blender internals.", default=MAX_SPEED_DEFAULTS["force_volume_resolution"])
    volume_value: bpy.props.FloatProperty(name="Volume value", description="Volume Simplify value applied to scenes. Smaller values are lighter and reduce the cost of volume drawing.", default=MAX_SPEED_DEFAULTS["volume_value"], min=0.0, max=1.0, precision=2)
    force_child_particles: bpy.props.BoolProperty(name="Force child particle percentage", description="Reduce the scene-level child particle percentage. Set this to 0 for maximum speed when hair or instanced particles are heavy.", default=MAX_SPEED_DEFAULTS["force_child_particles"])
    child_particle_percentage: bpy.props.FloatProperty(name="Child particle percentage", description="Percentage of child particles kept by scene Simplify. Lower values reduce particle drawing and evaluation cost.", default=MAX_SPEED_DEFAULTS["child_particle_percentage"], min=0.0, max=1.0, precision=2)
    force_texture_size: bpy.props.BoolProperty(name="Force texture size", description="Ask Simplify to limit viewport texture size where Blender exposes that property. This reduces texture upload and sampling cost in material-like display modes.", default=MAX_SPEED_DEFAULTS["force_texture_size"])
    texture_size: bpy.props.IntProperty(name="Texture size", description="Texture size limit used by Simplify when available. Smaller values are lighter but blurrier.", default=MAX_SPEED_DEFAULTS["texture_size"], min=16, max=8192)
    simplify_grease_pencil: bpy.props.BoolProperty(name="Simplify Grease Pencil", description="Enable Grease Pencil simplification when the property exists. This helps scenes containing many strokes or complex Grease Pencil objects.", default=MAX_SPEED_DEFAULTS["simplify_grease_pencil"])

    force_wireframe_mode: bpy.props.BoolProperty(name="Force wireframe mode", description="Switch every 3D View to Wireframe mode. This is the most aggressive display shortcut because surfaces, materials, shadows, and many lighting calculations are bypassed.", default=MAX_SPEED_DEFAULTS["force_wireframe_mode"])
    use_flat_solid_fallback: bpy.props.BoolProperty(name="Use flat solid fallback", description="When wireframe mode is off, switch the viewport to Solid mode with Flat lighting. This keeps shaded shapes visible while avoiding studio and material lighting cost.", default=MAX_SPEED_DEFAULTS["use_flat_solid_fallback"])
    use_single_color: bpy.props.BoolProperty(name="Use single color", description="Use a single viewport color instead of material, texture, object, or random colors. This reduces color lookup complexity and makes dense scenes easier to redraw.", default=MAX_SPEED_DEFAULTS["use_single_color"])
    disable_shadows: bpy.props.BoolProperty(name="Disable shadows", description="Hide viewport shadows. Shadows add extra drawing work, so disabling them improves navigation responsiveness on weaker GPUs or very heavy scenes.", default=MAX_SPEED_DEFAULTS["disable_shadows"])
    disable_cavity: bpy.props.BoolProperty(name="Disable cavity", description="Disable cavity shading. Cavity highlights edges and surface dents, but it adds screen-space shading work that is unnecessary in a pure speed mode.", default=MAX_SPEED_DEFAULTS["disable_cavity"])
    disable_object_outlines: bpy.props.BoolProperty(name="Disable object outlines", description="Disable object outline drawing. Outlines are useful for visibility but require additional overlay-style drawing around selected or visible objects.", default=MAX_SPEED_DEFAULTS["disable_object_outlines"])
    disable_specular: bpy.props.BoolProperty(name="Disable specular highlights", description="Disable specular highlights in viewport shading. This avoids glossy highlight calculations and gives a flatter, lighter display.", default=MAX_SPEED_DEFAULTS["disable_specular"])
    disable_xray: bpy.props.BoolProperty(name="Disable X-Ray", description="Turn off X-Ray display. X-Ray blends front and back geometry and can increase overdraw, especially in dense meshes.", default=MAX_SPEED_DEFAULTS["disable_xray"])
    disable_scene_lights: bpy.props.BoolProperty(name="Disable scene lights", description="Ignore scene lights in viewport display when the property is available. This avoids expensive preview lighting in material or rendered-like modes.", default=MAX_SPEED_DEFAULTS["disable_scene_lights"])
    disable_scene_world: bpy.props.BoolProperty(name="Disable scene world", description="Ignore the scene world background in viewport display when available. This keeps the viewport independent from potentially expensive world lighting previews.", default=MAX_SPEED_DEFAULTS["disable_scene_world"])
    enable_backface_culling: bpy.props.BoolProperty(name="Enable backface culling", description="Hide back-facing polygons where Blender supports it. This can reduce visible surface work, but double-sided surfaces may look different.", default=MAX_SPEED_DEFAULTS["enable_backface_culling"])
    limit_far_clip: bpy.props.BoolProperty(name="Limit far clip", description="Reduce the 3D View far clipping distance. Objects farther than this distance are not drawn, which can help extremely large scenes.", default=MAX_SPEED_DEFAULTS["limit_far_clip"])
    clip_end: bpy.props.FloatProperty(name="Far clip", description="Far clipping distance applied to 3D Views. Use a larger value if distant objects disappear unintentionally.", default=MAX_SPEED_DEFAULTS["clip_end"], min=1.0, max=10000000.0, subtype="DISTANCE")
    limit_near_clip: bpy.props.BoolProperty(name="Limit near clip", description="Set the near clipping distance. A slightly larger near clip can improve depth precision, but too large a value hides close geometry.", default=MAX_SPEED_DEFAULTS["limit_near_clip"])
    clip_start: bpy.props.FloatProperty(name="Near clip", description="Near clipping distance applied to 3D Views. Keep this small if you need to edit close-up details.", default=MAX_SPEED_DEFAULTS["clip_start"], min=0.0001, max=1000.0, subtype="DISTANCE")

    hide_all_overlays: bpy.props.BoolProperty(name="Hide all overlays", description="Turn off the overlay master switch. This gives the strongest overlay speed-up because grids, guides, text, normals, and helper drawings are hidden at once.", default=MAX_SPEED_DEFAULTS["hide_all_overlays"])
    hide_relationship_lines: bpy.props.BoolProperty(name="Hide relationship lines", description="Hide parent, constraint, and relationship lines. These helper lines can clutter and slow the viewport in complex rigs or linked scenes.", default=MAX_SPEED_DEFAULTS["hide_relationship_lines"])
    hide_grid_axes: bpy.props.BoolProperty(name="Hide grid and axes", description="Hide the floor grid and axis lines. This reduces background drawing and is useful when you only need object silhouettes or bounding boxes.", default=MAX_SPEED_DEFAULTS["hide_grid_axes"])
    hide_text_stats: bpy.props.BoolProperty(name="Hide text and stats", description="Hide viewport text information and statistics. This removes small but constant UI overlay updates while navigating or editing.", default=MAX_SPEED_DEFAULTS["hide_text_stats"])
    hide_extras: bpy.props.BoolProperty(name="Hide extras", description="Hide extra helper drawings such as light and camera widgets where supported. This is useful when helper objects are not needed during speed-focused editing.", default=MAX_SPEED_DEFAULTS["hide_extras"])
    hide_wire_overlay: bpy.props.BoolProperty(name="Hide wire overlay", description="Hide additional wire overlays and set their opacity as low as possible. This avoids drawing extra mesh lines over shaded objects.", default=MAX_SPEED_DEFAULTS["hide_wire_overlay"])
    hide_normals: bpy.props.BoolProperty(name="Hide normals", description="Hide vertex, face, and split normal overlays. Normal vectors are expensive and unnecessary unless you are debugging mesh direction.", default=MAX_SPEED_DEFAULTS["hide_normals"])
    hide_edit_guides: bpy.props.BoolProperty(name="Hide edit guides", description="Hide edit-mode guides such as face centers, seams, sharp edges, crease indicators, and extra indices when available.", default=MAX_SPEED_DEFAULTS["hide_edit_guides"])
    hide_motion_paths: bpy.props.BoolProperty(name="Hide motion paths", description="Hide animation motion paths. These can become heavy when many animated objects, bones, or long frame ranges are visible.", default=MAX_SPEED_DEFAULTS["hide_motion_paths"])
    hide_annotations: bpy.props.BoolProperty(name="Hide annotations", description="Hide annotation strokes and related overlay drawings. This removes extra 2D/3D annotation display work from the viewport.", default=MAX_SPEED_DEFAULTS["hide_annotations"])

    hide_all_gizmos: bpy.props.BoolProperty(name="Hide all gizmos", description="Turn off the 3D View gizmo master switch. This removes transform, tool, and navigation widgets from drawing and hit-testing.", default=MAX_SPEED_DEFAULTS["hide_all_gizmos"])
    hide_navigation_gizmo: bpy.props.BoolProperty(name="Hide navigation gizmo", description="Hide the viewport navigation gizmo. This reduces UI drawing in the corner of the 3D View while mouse and keyboard navigation still work.", default=MAX_SPEED_DEFAULTS["hide_navigation_gizmo"])
    hide_tool_gizmos: bpy.props.BoolProperty(name="Hide tool gizmos", description="Hide active tool gizmos. This is useful when you use shortcuts instead of on-screen handles.", default=MAX_SPEED_DEFAULTS["hide_tool_gizmos"])
    hide_context_gizmos: bpy.props.BoolProperty(name="Hide context gizmos", description="Hide context-dependent gizmos. This reduces additional widgets that appear depending on the selected object or mode.", default=MAX_SPEED_DEFAULTS["hide_context_gizmos"])
    hide_object_transform_gizmos: bpy.props.BoolProperty(name="Hide object transform gizmos", description="Hide object translate, rotate, and scale gizmos. This reduces interactive handle drawing during object manipulation.", default=MAX_SPEED_DEFAULTS["hide_object_transform_gizmos"])

    hide_lights: bpy.props.BoolProperty(name="Hide lights", description="Hide light objects in the 3D View object-type filter. The objects remain in the file and can be shown again by restoring or turning this off.", default=MAX_SPEED_DEFAULTS["hide_lights"])
    hide_cameras: bpy.props.BoolProperty(name="Hide cameras", description="Hide camera objects in the viewport filter. This removes camera frame/helper drawing when layout work does not require cameras.", default=MAX_SPEED_DEFAULTS["hide_cameras"])
    hide_empties: bpy.props.BoolProperty(name="Hide empties", description="Hide Empty objects in the viewport filter. This is effective in rigged or linked scenes containing many control empties.", default=MAX_SPEED_DEFAULTS["hide_empties"])
    hide_armatures: bpy.props.BoolProperty(name="Hide armatures", description="Hide armature objects in the viewport filter. This can strongly reduce rig drawing cost, but turn it off when you need to pose or edit bones.", default=MAX_SPEED_DEFAULTS["hide_armatures"])
    hide_curves: bpy.props.BoolProperty(name="Hide curves", description="Hide curve objects in the viewport filter. Useful for scenes with many bevelled curves, splines, or motion paths represented as curves.", default=MAX_SPEED_DEFAULTS["hide_curves"])
    hide_surfaces: bpy.props.BoolProperty(name="Hide surfaces", description="Hide surface objects in the viewport filter. This reduces display work for NURBS or surface-based assets.", default=MAX_SPEED_DEFAULTS["hide_surfaces"])
    hide_fonts: bpy.props.BoolProperty(name="Hide fonts", description="Hide font/text objects in the viewport filter. Text objects can become expensive when converted visually to curves for display.", default=MAX_SPEED_DEFAULTS["hide_fonts"])
    hide_metaballs: bpy.props.BoolProperty(name="Hide metaballs", description="Hide metaball objects in the viewport filter. Metaballs can be costly because their visible surface is evaluated procedurally.", default=MAX_SPEED_DEFAULTS["hide_metaballs"])
    hide_lattices: bpy.props.BoolProperty(name="Hide lattices", description="Hide lattice objects in the viewport filter. This is useful when deformer cages are not needed during navigation.", default=MAX_SPEED_DEFAULTS["hide_lattices"])
    hide_speakers: bpy.props.BoolProperty(name="Hide speakers", description="Hide speaker objects in the viewport filter. Audio helper icons are usually unnecessary for geometry-heavy viewport work.", default=MAX_SPEED_DEFAULTS["hide_speakers"])
    hide_light_probes: bpy.props.BoolProperty(name="Hide light probes", description="Hide light probe objects in the viewport filter. Light probe helper drawings are not needed for speed-focused editing.", default=MAX_SPEED_DEFAULTS["hide_light_probes"])
    hide_volumes: bpy.props.BoolProperty(name="Hide volumes", description="Hide volume objects in the viewport filter. Volumes are often expensive to draw, so hiding them can improve responsiveness dramatically.", default=MAX_SPEED_DEFAULTS["hide_volumes"])
    hide_grease_pencil: bpy.props.BoolProperty(name="Hide Grease Pencil", description="Hide Grease Pencil objects in the viewport filter. This reduces stroke drawing cost in scenes with many 2D or 3D strokes.", default=MAX_SPEED_DEFAULTS["hide_grease_pencil"])
    hide_pointclouds: bpy.props.BoolProperty(name="Hide point clouds", description="Hide point cloud objects in the viewport filter when the property exists. Dense point data can be very expensive to draw.", default=MAX_SPEED_DEFAULTS["hide_pointclouds"])

    force_object_display_type: bpy.props.BoolProperty(name="Force object display type", description="Set target objects to a cheaper display type. Bounding Box is the lightest because Blender draws only the box around the object.", default=MAX_SPEED_DEFAULTS["force_object_display_type"])
    object_display_type: bpy.props.EnumProperty(
        name="Display type",
        description="Display type assigned to target objects. Bounding Box is fastest, Wire is still light, and Solid is less aggressive.",
        items=(
            ("BOUNDS", "Bounding Box", "Draw only the object's bounding box."),
            ("WIRE", "Wire", "Draw object geometry as wireframe."),
            ("SOLID", "Solid", "Draw object geometry as solid shapes."),
        ),
        default=MAX_SPEED_DEFAULTS["object_display_type"],
    )
    hide_object_names_axes: bpy.props.BoolProperty(name="Hide object names and axes", description="Disable per-object name, axis, and texture-space helper drawings when available. These small overlays add up in scenes with many objects.", default=MAX_SPEED_DEFAULTS["hide_object_names_axes"])
    disable_object_selection: bpy.props.BoolProperty(name="Disable object selection hit tests", description="Temporarily make target objects unselectable. This reduces selection hit-test and outline-related work while navigating. Restore Snapshot returns the original selectable state.", default=MAX_SPEED_DEFAULTS["disable_object_selection"])
    hide_instancer_viewport: bpy.props.BoolProperty(name="Hide instancer viewport display", description="Hide instancer display for target objects when available. This can reduce duplicated viewport drawing in scenes using collection or object instancing.", default=MAX_SPEED_DEFAULTS["hide_instancer_viewport"])

    disable_viewport_modifiers: bpy.props.BoolProperty(name="Disable viewport modifiers", description="Temporarily turn off selected modifier categories in the viewport. This is very powerful but changes the preview shape until Restore Snapshot is used.", default=MAX_SPEED_DEFAULTS["disable_viewport_modifiers"])
    disable_subdivision_modifiers: bpy.props.BoolProperty(name="Disable subdivision modifiers", description="Disable Subdivision Surface and Multiresolution modifiers in the viewport. These are common sources of heavy geometry evaluation.", default=MAX_SPEED_DEFAULTS["disable_subdivision_modifiers"])
    disable_geometry_nodes: bpy.props.BoolProperty(name="Disable Geometry Nodes", description="Disable Geometry Nodes modifiers in the viewport. Node-generated geometry can be extremely heavy, so this often gives a large speed-up.", default=MAX_SPEED_DEFAULTS["disable_geometry_nodes"])
    disable_simulation_modifiers: bpy.props.BoolProperty(name="Disable simulation modifiers", description="Disable simulation-related modifiers such as Cloth, Fluid, Soft Body, Dynamic Paint, Ocean, and Particle System in the viewport.", default=MAX_SPEED_DEFAULTS["disable_simulation_modifiers"])
    disable_deformer_modifiers: bpy.props.BoolProperty(name="Disable deformer modifiers", description="Disable deformation modifiers such as Armature, Lattice, Mesh Deform, Shrinkwrap, Warp, Curve, and Smooth variants in the viewport.", default=MAX_SPEED_DEFAULTS["disable_deformer_modifiers"])
    disable_generator_modifiers: bpy.props.BoolProperty(name="Disable generator modifiers", description="Disable generator modifiers such as Boolean, Bevel, Array, Mirror, Solidify, Remesh, Screw, Skin, and Wireframe in the viewport.", default=MAX_SPEED_DEFAULTS["disable_generator_modifiers"])
    disable_normal_data_modifiers: bpy.props.BoolProperty(name="Disable normal/data modifiers", description="Disable normal and data transfer modifiers such as Weighted Normal, Normal Edit, and Data Transfer in the viewport.", default=MAX_SPEED_DEFAULTS["disable_normal_data_modifiers"])
    disable_other_modifiers: bpy.props.BoolProperty(name="Disable other modifiers", description="Disable any modifier category not explicitly listed above. Keep this on for maximum speed, or turn it off if unknown modifiers must stay visible.", default=MAX_SPEED_DEFAULTS["disable_other_modifiers"])

    mute_object_constraints: bpy.props.BoolProperty(name="Mute object constraints", description="Temporarily mute object constraints on target objects. This can reduce dependency-graph evaluation cost in rigged or constraint-heavy scenes. Restore Snapshot returns the original mute states.", default=MAX_SPEED_DEFAULTS["mute_object_constraints"])
    mute_pose_constraints: bpy.props.BoolProperty(name="Mute pose constraints", description="Temporarily mute pose-bone constraints on target armatures. This is aggressive and useful when rigs cause view movement to stall at the start of navigation.", default=MAX_SPEED_DEFAULTS["mute_pose_constraints"])

    reduce_particle_previews: bpy.props.BoolProperty(name="Reduce particle previews", description="Reduce particle settings used for viewport display. This affects particle data blocks and can be restored from the snapshot.", default=MAX_SPEED_DEFAULTS["reduce_particle_previews"])
    particle_display_percentage: bpy.props.IntProperty(name="Particle display percentage", description="Viewport particle display percentage. 0 is the lightest and hides most particle preview drawing.", default=MAX_SPEED_DEFAULTS["particle_display_percentage"], min=0, max=100, subtype="PERCENTAGE")
    particle_display_step: bpy.props.IntProperty(name="Particle display step", description="Viewport particle draw step when supported. 0 is the cheapest setting and reduces preview sampling.", default=MAX_SPEED_DEFAULTS["particle_display_step"], min=0, max=10)

    disable_viewport_aa: bpy.props.BoolProperty(name="Disable viewport anti-aliasing", description="Set viewport anti-aliasing to Off for the current session when supported. This reduces smoothing quality but can improve redraw speed.", default=MAX_SPEED_DEFAULTS["disable_viewport_aa"])
    keep_texture_vbo_cache_warm: bpy.props.BoolProperty(name="Keep texture/VBO cache warm", description="Keep viewport texture and VBO data alive longer instead of collecting it immediately. This is important for navigation start lag because a short timeout can force Blender to rebuild GPU data when you begin orbiting, panning, or zooming.", default=MAX_SPEED_DEFAULTS["keep_texture_vbo_cache_warm"])
    texture_cache_seconds: bpy.props.IntProperty(name="Texture cache seconds", description="Seconds Blender keeps viewport textures before collecting them. Larger values reduce reload spikes during repeated navigation, but use more memory.", default=MAX_SPEED_DEFAULTS["texture_cache_seconds"], min=1, max=86400)
    vbo_cache_seconds: bpy.props.IntProperty(name="VBO cache seconds", description="Seconds Blender keeps viewport VBO buffers before collecting them. Larger values reduce first-move rebuild spikes, but use more memory.", default=MAX_SPEED_DEFAULTS["vbo_cache_seconds"], min=1, max=86400)
    texture_collection_rate: bpy.props.IntProperty(name="Texture collection rate", description="Collection-rate value applied to viewport textures when the property exists. Higher values make collection less aggressive and reduce reloads during navigation.", default=MAX_SPEED_DEFAULTS["texture_collection_rate"], min=1, max=86400)
    vbo_collection_rate: bpy.props.IntProperty(name="VBO collection rate", description="Collection-rate value applied to VBO buffers when the property exists. Higher values make collection less aggressive and reduce cache churn while navigating.", default=MAX_SPEED_DEFAULTS["vbo_collection_rate"], min=1, max=86400)
    gl_texture_limit: bpy.props.EnumProperty(
        name="GL texture limit",
        description="Texture size limit used by the preference system. Lower values can reduce upload and sampling cost in textured views. Off keeps Blender's current default behavior.",
        items=(
            ("CLAMP_OFF", "Off", "Do not limit texture size."),
            ("CLAMP_8192", "8192", "Limit viewport textures to 8192 pixels."),
            ("CLAMP_4096", "4096", "Limit viewport textures to 4096 pixels."),
            ("CLAMP_2048", "2048", "Limit viewport textures to 2048 pixels."),
            ("CLAMP_1024", "1024", "Limit viewport textures to 1024 pixels."),
            ("CLAMP_512", "512", "Limit viewport textures to 512 pixels."),
            ("CLAMP_256", "256", "Limit viewport textures to 256 pixels."),
            ("CLAMP_128", "128", "Limit viewport textures to 128 pixels."),
        ),
        default=MAX_SPEED_DEFAULTS["gl_texture_limit"],
    )
    disable_gpu_subdivision: bpy.props.BoolProperty(name="Disable GPU subdivision", description="Disable GPU subdivision evaluation when the preference exists. Use this only if GPU subdivision causes instability or overhead on the current machine.", default=MAX_SPEED_DEFAULTS["disable_gpu_subdivision"])
    disable_smooth_wires: bpy.props.BoolProperty(name="Disable overlay smooth wires", description="Disable smooth wire drawing preferences when available. Smooth wires look nicer, but they can add overhead in dense wire or edit-mode scenes.", default=MAX_SPEED_DEFAULTS["disable_smooth_wires"])

    disable_depth_navigation: bpy.props.BoolProperty(name="Disable depth-based navigation", description="Disable mouse-depth navigation so Blender does not need to query scene depth under the cursor when navigation begins. This can reduce the small hitch before the first orbit, pan, or zoom in heavy scenes.", default=MAX_SPEED_DEFAULTS["disable_depth_navigation"])
    disable_zoom_to_mouse: bpy.props.BoolProperty(name="Disable zoom to mouse", description="Disable zoom-to-mouse so zooming does not need a cursor-centered target lookup. Use this when the first wheel zoom or view zoom has a small delay.", default=MAX_SPEED_DEFAULTS["disable_zoom_to_mouse"])
    disable_rotate_around_active: bpy.props.BoolProperty(name="Disable rotate around active", description="Disable rotation around the active selection. This avoids active-object or selection-center calculations and makes navigation pivoting simpler.", default=MAX_SPEED_DEFAULTS["disable_rotate_around_active"])
    disable_auto_perspective: bpy.props.BoolProperty(name="Disable auto perspective", description="Disable automatic orthographic/perspective switching during navigation. This removes an extra view-state change that can occur while starting view movement.", default=MAX_SPEED_DEFAULTS["disable_auto_perspective"])
    disable_smooth_view: bpy.props.BoolProperty(name="Disable smooth view", description="Set Smooth View to zero so view changes happen immediately without transition animation. This removes animation work and makes the start of navigation feel more direct.", default=MAX_SPEED_DEFAULTS["disable_smooth_view"])
    hide_global_navigation_ui: bpy.props.BoolProperty(name="Hide global navigation UI", description="Hide the global navigation UI preference where available. This reduces additional UI drawing around the viewport without disabling mouse or keyboard navigation.", default=MAX_SPEED_DEFAULTS["hide_global_navigation_ui"])
    force_object_mode_on_apply: bpy.props.BoolProperty(name="Force Object Mode before apply", description="Switch to Object Mode before applying a preset when that preset requests it. Edit Mode overlays and editable mesh caches can be heavier during navigation.", default=MAX_SPEED_DEFAULTS["force_object_mode_on_apply"])
    clear_selection_on_apply: bpy.props.BoolProperty(name="Clear selection on apply", description="Deselect objects when applying the speed mode. Selection outlines and selected-object pivot calculations are common causes of first-move lag in large scenes.", default=MAX_SPEED_DEFAULTS["clear_selection_on_apply"])
    disable_global_undo: bpy.props.BoolProperty(name="Disable Global Undo", description="Disable Global Undo for the current session while the optimizer is active. This reduces memory and bookkeeping pressure, but use Restore Snapshot or re-enable it before normal editing.", default=MAX_SPEED_DEFAULTS["disable_global_undo"])
    undo_steps: bpy.props.IntProperty(name="Undo steps", description="Undo step count to use while latency optimization is active. Zero is most aggressive and minimizes undo bookkeeping.", default=MAX_SPEED_DEFAULTS["undo_steps"], min=0, max=256)
    undo_memory_limit: bpy.props.IntProperty(name="Undo memory limit", description="Undo memory limit in megabytes while latency optimization is active. Zero is the most aggressive setting.", default=MAX_SPEED_DEFAULTS["undo_memory_limit"], min=0, max=32768)
    disable_auto_keying: bpy.props.BoolProperty(name="Disable auto keying", description="Disable auto key insertion in the target scenes. This avoids accidental animation bookkeeping while using the speed-focused navigation mode.", default=MAX_SPEED_DEFAULTS["disable_auto_keying"])

    enable_navigation_guard: bpy.props.BoolProperty(name="Enable navigation prewarm guard", description="Run a lightweight modal guard that keeps the 3D View in a prewarmed low-cost state before orbit, pan, or zoom begins. It passes events through and is intended to reduce first-move hitches.", default=MAX_SPEED_DEFAULTS["enable_navigation_guard"])
    prewarm_on_mouse_move: bpy.props.BoolProperty(name="Prewarm on mouse move", description="Prewarm redraw and dependency updates when the mouse moves over the viewport before navigation starts. This shifts some startup cost away from the first orbit, pan, or zoom event.", default=MAX_SPEED_DEFAULTS["prewarm_on_mouse_move"])
    prewarm_interval: bpy.props.FloatProperty(name="Prewarm interval", description="Minimum seconds between prewarm attempts. Smaller values react more often but can add overhead; 0.25 to 0.5 seconds is usually a practical range.", default=MAX_SPEED_DEFAULTS["prewarm_interval"], min=0.05, max=10.0, unit="TIME")
    prewarm_redraw_iterations: bpy.props.IntProperty(name="Prewarm redraw iterations", description="Number of redraw attempts used by the prewarm step. One iteration is the safest default; higher values may move more cost before navigation but can feel heavier while idle.", default=MAX_SPEED_DEFAULTS["prewarm_redraw_iterations"], min=0, max=3)
    restore_after_navigation_idle: bpy.props.BoolProperty(name="Restore after navigation idle", description="Restore the stored snapshot after navigation has been idle for the specified time. This is off by default because restoring heavy display settings can recreate the next start lag.", default=MAX_SPEED_DEFAULTS["restore_after_navigation_idle"])
    navigation_idle_seconds: bpy.props.FloatProperty(name="Navigation idle seconds", description="Idle time before optional post-navigation restore is triggered. This only matters when Restore after navigation idle is enabled.", default=2.0, min=0.1, max=60.0, unit="TIME")



# -----------------------------------------------------------------------------
# v6 external backups, preset management, and deeper latency controls
# -----------------------------------------------------------------------------


# Preset set: seven performance/quality levels.
# Workspace-specific built-ins were intentionally removed. The built-in presets
# now express only viewport performance-vs-quality strength so they can be used
# consistently from any Blender workspace.
SVO_V6_PRESETS: Dict[str, Dict[str, Any]] = {
    "PERFORMANCE_HIGH": {
        "name": "Performance Priority: High",
        "effect": "Maximum viewport speed preset. Strongly reduces redraw cost by using wire/bounds display, hiding overlays and gizmos, limiting textures, disabling expensive viewport evaluation, keeping VBO/texture cache warm, and simplifying orbit/pan/zoom startup. Visual fidelity and edit feedback are intentionally reduced.",
        "values": {},
    },
    "PERFORMANCE_MEDIUM": {
        "name": "Performance Priority: Medium",
        "effect": "Strong speed preset for heavy scenes. Uses flat solid display, suppresses most helper drawing, lowers Simplify and texture limits, keeps cache data warm, and reduces modifier/particle/navigation overhead while preserving more object visibility than the High preset.",
        "values": {},
    },
    "PERFORMANCE_LOW": {
        "name": "Performance Priority: Low",
        "effect": "Mild speed preset for normal editing. Keeps solid object feedback and most safe editing behavior while disabling the redraw costs most likely to cause orbit, pan, and zoom start lag: anti-aliasing, smooth view, depth lookup, heavy overlays, and unnecessary preview effects.",
        "values": {},
    },
    "BALANCED": {
        "name": "Balanced Priority",
        "effect": "Balanced preset for day-to-day work. Keeps normal solid visual feedback, modifiers, selection, and common overlays usable while reducing avoidable AA, cache churn, navigation transition, particle, texture, and material-preview costs.",
        "values": {},
    },
    "QUALITY_LOW": {
        "name": "Quality Priority: Low",
        "effect": "Light quality preset. Preserves more shading, outlines, gizmos, and helper visibility than Balanced, but still limits expensive preview samples and navigation-start costs so the viewport remains responsive.",
        "values": {},
    },
    "QUALITY_MEDIUM": {
        "name": "Quality Priority: Medium",
        "effect": "Quality-oriented preset. Keeps material inspection, higher texture limits, modifiers, scene helpers, and moderate preview samples while still using cache warmup and simpler navigation settings to reduce first-move lag.",
        "values": {},
    },
    "QUALITY_HIGH": {
        "name": "Quality Priority: High",
        "effect": "Maximum visual fidelity preset. Keeps rendered/material visual checks, higher anti-aliasing, scene lights/world, modifiers, and high texture limits. This is the heaviest built-in preset and is intended for look-development checks rather than fastest navigation.",
        "values": {},
    },
}

_SVO_LEGACY_PRESET_MIGRATION = {
    "WORKSPACE_LAYOUT": "BALANCED",
    "WORKSPACE_MODELING": "PERFORMANCE_LOW",
    "WORKSPACE_SCULPTING": "QUALITY_LOW",
    "WORKSPACE_UV_EDITING": "PERFORMANCE_LOW",
    "WORKSPACE_TEXTURE_PAINT": "QUALITY_MEDIUM",
    "WORKSPACE_SHADING": "QUALITY_MEDIUM",
    "WORKSPACE_ANIMATION": "BALANCED",
    "WORKSPACE_RENDERING": "QUALITY_HIGH",
    "WORKSPACE_COMPOSITING": "PERFORMANCE_MEDIUM",
    "WORKSPACE_GEOMETRY_NODES": "BALANCED",
    "WORKSPACE_SCRIPTING": "PERFORMANCE_MEDIUM",
    "WORKSPACE_2D_ANIMATION": "QUALITY_LOW",
    "WORKSPACE_2D_FULL_CANVAS": "QUALITY_LOW",
    "WORKSPACE_MASKING": "BALANCED",
    "WORKSPACE_MOTION_TRACKING": "BALANCED",
    "WORKSPACE_VIDEO_EDITING": "PERFORMANCE_MEDIUM",
}


_PRESET_ENUM_CACHE: List[Tuple[str, str, str]] = []
_IDLE_PULSE_RUNNING = False
_IDLE_PULSE_RUNTIME_ALLOWED = False

def _svo_v6_migrate_legacy_user_root(new_root: str) -> None:
    """Move any legacy smart_viewport_optimizer_plus config into viewport_optimizer.

    The legacy folder is now fully retired and must not remain or be generated.
    Existing files are copied into the new folder first, then the legacy directory
    is removed.  Missing or unreadable files are ignored to avoid startup errors.
    """
    try:
        if not new_root:
            return
        legacy_root = os.path.join(os.path.dirname(new_root), ADDON_ID)
        if not os.path.isdir(legacy_root) or os.path.abspath(legacy_root) == os.path.abspath(new_root):
            return
        os.makedirs(new_root, exist_ok=True)
        import shutil as _shutil
        for dirpath, _dirnames, filenames in os.walk(legacy_root):
            rel = os.path.relpath(dirpath, legacy_root)
            target_dir = new_root if rel == "." else os.path.join(new_root, rel)
            os.makedirs(target_dir, exist_ok=True)
            for filename in filenames:
                src = os.path.join(dirpath, filename)
                dst = os.path.join(target_dir, filename)
                if not os.path.exists(dst):
                    try:
                        _shutil.copy2(src, dst)
                    except Exception:
                        pass
        try:
            _shutil.rmtree(legacy_root, ignore_errors=True)
        except Exception:
            pass
    except Exception:
        pass


_SVO_V6_USER_ROOT_CACHE = ''


def _svo_v6_user_root() -> str:
    """Return the integrated Smart Workspace config root for this tool.

    Automatically generated Viewport Optimizer folders and JSON files are kept
    under Blender's versioned config/Smart_WorkSpace_Suite/viewport_optimizer
    directory, matching the requested Smart Workspace Suite storage policy.
    """
    global _SVO_V6_USER_ROOT_CACHE
    if _SVO_V6_USER_ROOT_CACHE:
        return _SVO_V6_USER_ROOT_CACHE
    try:
        if _sws_storage is not None:
            root = _sws_storage.central_settings_dir(create=True) / STORAGE_DIRNAME
            root.mkdir(parents=True, exist_ok=True)
            _svo_v6_migrate_legacy_user_root(str(root))
            try:
                cleanup = getattr(_sws_storage, 'cleanup_legacy_storage_dirs', None)
                if callable(cleanup):
                    cleanup()
            except Exception:
                pass
            _SVO_V6_USER_ROOT_CACHE = str(root)
            return _SVO_V6_USER_ROOT_CACHE
    except Exception:
        pass

    version = "5.1"
    try:
        app_version = getattr(getattr(bpy, "app", None), "version", None)
        if app_version and len(app_version) >= 2:
            version = f"{int(app_version[0])}.{int(app_version[1])}"
    except Exception:
        pass

    try:
        config_root = bpy.utils.user_resource("CONFIG", create=True) or ""
    except Exception:
        config_root = ""

    if not config_root:
        if os.name == "nt":
            base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
            config_root = os.path.join(base, "Blender Foundation", "Blender", version, "config")
        else:
            config_root = os.path.join(os.path.expanduser("~"), ".config", "blender", version, "config")

    path = os.path.join(config_root, "Smart_WorkSpace_Suite", STORAGE_DIRNAME)
    os.makedirs(path, exist_ok=True)
    _svo_v6_migrate_legacy_user_root(path)
    try:
        if _sws_storage is not None:
            cleanup = getattr(_sws_storage, 'cleanup_legacy_storage_dirs', None)
            if callable(cleanup):
                cleanup()
    except Exception:
        pass
    return path

def _svo_v6_backup_root() -> str:
    path = os.path.join(_svo_v6_user_root(), "backups")
    os.makedirs(path, exist_ok=True)
    return path

def _svo_v6_preset_root() -> str:
    path = os.path.join(_svo_v6_user_root(), "presets")
    os.makedirs(path, exist_ok=True)
    return path

def _svo_v8_builtin_override_root() -> str:
    path = os.path.join(_svo_v6_user_root(), "workspace_preset_overrides")
    os.makedirs(path, exist_ok=True)
    return path


SVO_V8_PRESET_EXCLUDED_KEYS = {
    "selected_preset", "custom_preset_name", "backup_restore_kind",
    "external_backup_on_register", "external_backup_on_startup",
    "external_backup_before_apply", "external_backup_on_file_load",
    "keep_backup_history", "max_backup_files",
    "auto_apply_on_enable", "auto_apply_on_load",
    "auto_save_workspace_preset_changes",
    "optimizer_active", "restore_before_file_events", "reapply_after_save_if_active", "keymap_operator_id",
}

_SVO_V8_AUTOSAVE_RUNNING = False
_SVO_V8_AUTOSAVE_SUSPEND_UNTIL = 0.0
_SVO_V8_LAST_SIGNATURE = ""
_SVO_V8_LAST_ACTIVE_PRESET = ""


def _svo_v8_preset_setting_keys(settings: Optional[bpy.types.PropertyGroup] = None) -> List[str]:
    keys = []
    for key in MAX_SPEED_DEFAULTS.keys():
        if key in SVO_V8_PRESET_EXCLUDED_KEYS:
            continue
        if settings is not None and not hasattr(settings, key):
            continue
        keys.append(key)
    return keys


def _svo_v8_current_preset_values(settings: bpy.types.PropertyGroup) -> Dict[str, Any]:
    values: Dict[str, Any] = {}
    for key in _svo_v8_preset_setting_keys(settings):
        try:
            values[key] = _json_value(getattr(settings, key))
        except Exception:
            pass
    return values


def _svo_v8_settings_signature(settings: bpy.types.PropertyGroup) -> str:
    payload = {
        "selected_preset": getattr(settings, "selected_preset", ""),
        "active_preset": getattr(settings, "auto_save_active_preset", ""),
        "values": _svo_v8_current_preset_values(settings),
    }
    try:
        return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except Exception:
        return str(payload)


def _svo_v8_safe_identifier(identifier: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", (identifier or "preset").strip())[:96] or "preset"


def _svo_v8_override_path(identifier: str) -> str:
    return os.path.join(_svo_v8_builtin_override_root(), "svo_preset_" + _svo_v8_safe_identifier(identifier) + ".json")


def _svo_v8_legacy_override_path(identifier: str) -> str:
    return os.path.join(_svo_v8_builtin_override_root(), _svo_v8_safe_identifier(identifier) + ".json")


def _svo_v8_load_builtin_override(identifier: str) -> Dict[str, Any]:
    if identifier not in SVO_V6_PRESETS:
        return {}
    data = None
    for path in (_svo_v8_override_path(identifier), _svo_v8_legacy_override_path(identifier)):
        data = _svo_v6_read_json(path)
        if data and isinstance(data.get("values"), dict):
            break
    if not data or not isinstance(data.get("values"), dict):
        return {}
    return {k: v for k, v in data["values"].items() if k in MAX_SPEED_DEFAULTS and k not in SVO_V8_PRESET_EXCLUDED_KEYS}


def _svo_v8_save_builtin_override(settings: bpy.types.PropertyGroup, identifier: str) -> Optional[str]:
    if identifier not in SVO_V6_PRESETS:
        return None
    path = _svo_v8_override_path(identifier)
    data = {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "identifier": identifier,
        "saved_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "values": _svo_v8_current_preset_values(settings),
    }
    _svo_v6_atomic_json(path, data)
    return path


def _svo_v8_delete_builtin_override(identifier: str) -> bool:
    removed = False
    for path in (_svo_v8_override_path(identifier), _svo_v8_legacy_override_path(identifier)):
        if not os.path.exists(path):
            continue
        try:
            os.remove(path)
            removed = True
        except Exception:
            pass
    return removed


def _svo_v10_safe_file_stem(value: str, fallback: str = "file") -> str:
    value = (value or fallback).strip()
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
    value = value.strip("._")
    return value[:96] or fallback


def _svo_v10_selected_preset_identifier(settings: bpy.types.PropertyGroup) -> str:
    return getattr(settings, "selected_preset", "PERFORMANCE") or "PERFORMANCE"


def _svo_v10_preset_display_name(identifier: str) -> str:
    if identifier in SVO_V6_PRESETS:
        return SVO_V6_PRESETS[identifier].get("name", identifier)
    if identifier.startswith("CUSTOM::"):
        data = _svo_v6_read_json(os.path.join(_svo_v6_preset_root(), identifier.split("::", 1)[1] + ".json")) or {}
        return str(data.get("name") or identifier.split("::", 1)[1])
    return identifier or "Preset"


def _svo_v10_default_preset_export_path(settings: bpy.types.PropertyGroup) -> str:
    ident = _svo_v10_selected_preset_identifier(settings)
    if ident in SVO_V6_PRESETS:
        return _svo_v8_override_path(ident)
    stem = _svo_v10_safe_file_stem(ident.replace("CUSTOM::", "custom_"), "custom_preset")
    return os.path.join(_svo_v6_preset_root(), "svo_preset_" + stem + ".json")


def _svo_v10_baseline_root() -> str:
    path = os.path.join(_svo_v6_user_root(), "baseline")
    os.makedirs(path, exist_ok=True)
    return path


def _svo_v10_current_baseline_path() -> str:
    return os.path.join(_svo_v10_baseline_root(), "svo_current_baseline.json")


def _svo_v10_default_baseline_export_path() -> str:
    blend = os.path.basename(getattr(bpy.data, "filepath", "") or "unsaved_blend")
    blend = os.path.splitext(blend)[0] or "unsaved_blend"
    stamp = datetime.datetime.now().strftime("%Y%m%d")
    stem = _svo_v10_safe_file_stem(f"svo_baseline_{blend}_{stamp}", "svo_baseline")
    return os.path.join(_svo_v10_baseline_root(), stem + ".json")


def _svo_v10_normalize_json_path(path: str, fallback: str) -> str:
    path = bpy.path.abspath(path or fallback)
    if not path.lower().endswith(".json"):
        path += ".json"
    return path


def _svo_v10_extract_preset_values(data: Dict[str, Any], settings: bpy.types.PropertyGroup) -> Dict[str, Any]:
    raw = data.get("values") if isinstance(data.get("values"), dict) else data.get("settings")
    if not isinstance(raw, dict):
        raw = data
    allowed = set(_svo_v8_preset_setting_keys(settings))
    out: Dict[str, Any] = {}
    for key, value in raw.items():
        if key in allowed and hasattr(settings, key):
            out[key] = value
    return out


def _svo_v10_write_preset_file(settings: bpy.types.PropertyGroup, filepath: str, identifier: Optional[str] = None) -> Optional[str]:
    ident = identifier or _svo_v10_selected_preset_identifier(settings)
    filepath = _svo_v10_normalize_json_path(filepath, _svo_v10_default_preset_export_path(settings))
    data = {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "role": "preset_settings",
        "identifier": ident,
        "name": _svo_v10_preset_display_name(ident),
        "saved_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "values": _svo_v8_current_preset_values(settings),
    }
    _svo_v6_atomic_json(filepath, data)
    # Keep the selected preset settings, not only the exported copy.
    if ident in SVO_V6_PRESETS:
        _svo_v6_atomic_json(_svo_v8_override_path(ident), data)
    elif ident.startswith("CUSTOM::"):
        custom_path = os.path.join(_svo_v6_preset_root(), ident.split("::", 1)[1] + ".json")
        custom_data = _svo_v6_read_json(custom_path) or {}
        custom_data.update({
            "addon": ADDON_ID,
            "version": ADDON_VERSION,
            "role": "custom_preset",
            "name": custom_data.get("name") or _svo_v10_preset_display_name(ident),
            "description": custom_data.get("description") or "User-saved optimizer preset. Expected effect depends on the saved settings.",
            "values": data["values"],
            "saved_at": data["saved_at"],
        })
        _svo_v6_atomic_json(custom_path, custom_data)
    _svo_v8_mark_preset_baseline(settings, ident if ident in SVO_V6_PRESETS else "")
    return filepath


def _svo_v10_load_preset_file_into_selected(settings: bpy.types.PropertyGroup, filepath: str) -> bool:
    data = _svo_v6_read_json(filepath)
    if not data:
        return False
    values = _svo_v10_extract_preset_values(data, settings)
    if not values:
        return False
    _svo_v8_suspend_autosave(1.5)
    selected = _svo_v10_selected_preset_identifier(settings)
    for key, value in values.items():
        try:
            setattr(settings, key, value)
        except Exception:
            pass
    # Persist the imported settings as the selected preset override.
    _svo_v10_write_preset_file(settings, _svo_v10_default_preset_export_path(settings), selected)
    _svo_v8_mark_preset_baseline(settings, selected if selected in SVO_V6_PRESETS else "")
    return True


def _svo_v10_is_snapshot_data(data: Dict[str, Any]) -> bool:
    return isinstance(data, dict) and ("scenes" in data or "view3d_spaces" in data or "preferences_system" in data)


def _svo_v10_write_current_baseline_data(data: Dict[str, Any], filepath: str) -> str:
    filepath = _svo_v10_normalize_json_path(filepath, _svo_v10_default_baseline_export_path())
    data = dict(data)
    data["addon"] = data.get("addon") or ADDON_ID
    data["version"] = ADDON_VERSION
    data["role"] = "baseline_snapshot"
    data["saved_at"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    _svo_v6_atomic_json(filepath, data)
    _svo_v6_atomic_json(_svo_v10_current_baseline_path(), data)
    return filepath


def _svo_v10_read_current_baseline_data() -> Optional[Dict[str, Any]]:
    data = _svo_v6_read_json(_svo_v10_current_baseline_path())
    if not data or not _svo_v10_is_snapshot_data(data):
        return None
    return data


def _svo_v10_snapshot_json_from_data(data: Dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def _svo_v10_restore_stored_baseline(context: bpy.types.Context, *, keep_session_snapshot: bool = False) -> bool:
    scene = getattr(context, "scene", None)
    data = _svo_v10_read_current_baseline_data()
    if scene is None or data is None:
        return False
    old = getattr(scene, "smart_viewport_optimizer_snapshot_json", "")
    baseline_json = _svo_v10_snapshot_json_from_data(data)
    try:
        scene.smart_viewport_optimizer_snapshot_json = baseline_json
        restored = _restore_snapshot(context)
        if keep_session_snapshot and restored:
            scene.smart_viewport_optimizer_snapshot_json = baseline_json
        return restored
    finally:
        if not keep_session_snapshot:
            try:
                scene.smart_viewport_optimizer_snapshot_json = old
            except Exception:
                pass


def _svo_v10_snapshot_keyed_merge(live_items: Any, baseline_items: Any, key_names: Tuple[str, ...]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    index: Dict[Tuple[Any, ...], int] = {}

    def key_of(item: Any) -> Optional[Tuple[Any, ...]]:
        if not isinstance(item, dict):
            return None
        return tuple(item.get(name) for name in key_names)

    for item in live_items or []:
        key = key_of(item)
        if key is None:
            continue
        index[key] = len(result)
        result.append(dict(item))
    for item in baseline_items or []:
        key = key_of(item)
        if key is None:
            continue
        if key in index:
            result[index[key]] = dict(item)
        else:
            index[key] = len(result)
            result.append(dict(item))
    return result


def _svo_v10_merge_live_snapshot_with_baseline(live: Dict[str, Any], baseline: Dict[str, Any]) -> Dict[str, Any]:
    live = live if isinstance(live, dict) else {}
    baseline = baseline if isinstance(baseline, dict) else {}
    merged: Dict[str, Any] = dict(live)
    merged["addon"] = ADDON_ID
    merged["version"] = ADDON_VERSION
    merged["role"] = "session_restore_baseline"
    merged["restore_target"] = "maintained_baseline"
    merged["baseline_source"] = _svo_v10_current_baseline_path()
    merged["session_created_at"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    list_keys = {
        "scenes": ("name",),
        "view3d_spaces": ("screen_name", "area_index", "space_index"),
        "objects": ("name",),
        "modifiers": ("object", "modifier"),
        "constraints": ("object", "constraint"),
        "pose_constraints": ("object", "bone", "constraint"),
        "particle_settings": ("name",),
        "tool_settings": ("scene",),
    }
    for key, key_names in list_keys.items():
        merged[key] = _svo_v10_snapshot_keyed_merge(live.get(key, []), baseline.get(key, []), key_names)
    for key in ("preferences_system", "preferences_inputs", "preferences_view", "preferences_edit", "selection", "view3d_layout"):
        if isinstance(baseline.get(key), dict) and baseline.get(key):
            merged[key] = dict(baseline.get(key, {}))
        elif isinstance(live.get(key), dict):
            merged[key] = dict(live.get(key, {}))
    return merged


def _svo_v10_prepare_session_restore_from_baseline(context: bpy.types.Context) -> bool:
    scene = getattr(context, "scene", None)
    baseline = _svo_v10_read_current_baseline_data()
    if scene is None or baseline is None:
        return False
    try:
        live = _svo_v6_build_external_snapshot(context, "live_before_temporary_optimization")
    except Exception:
        live = {}
    try:
        merged = _svo_v10_merge_live_snapshot_with_baseline(live, baseline)
        scene.smart_viewport_optimizer_snapshot_json = _svo_v10_snapshot_json_from_data(merged)
        return _restore_snapshot(context)
    except Exception:
        return False


def _svo_v10_baseline_state_status() -> Tuple[bool, str]:
    path = _svo_v10_current_baseline_path()
    if not os.path.exists(path):
        return False, "Baseline state is not set. Save the current settings as the baseline state or load a baseline state before turning optimization ON."
    if _svo_v10_read_current_baseline_data() is None:
        return False, "Invalid baseline state file. Save current settings as a baseline or load a valid baseline state before turning optimization ON."
    return True, ""


def _svo_v8_suspend_autosave(seconds: float = 1.5) -> None:
    global _SVO_V8_AUTOSAVE_SUSPEND_UNTIL
    _SVO_V8_AUTOSAVE_SUSPEND_UNTIL = max(_SVO_V8_AUTOSAVE_SUSPEND_UNTIL, time.monotonic() + seconds)


def _svo_v8_mark_preset_baseline(settings: bpy.types.PropertyGroup, identifier: Optional[str] = None) -> None:
    global _SVO_V8_LAST_SIGNATURE, _SVO_V8_LAST_ACTIVE_PRESET
    ident = identifier or getattr(settings, "selected_preset", "")
    try:
        settings.auto_save_active_preset = ident if ident in SVO_V6_PRESETS else ""
    except Exception:
        pass
    _SVO_V8_LAST_ACTIVE_PRESET = ident
    _SVO_V8_LAST_SIGNATURE = _svo_v8_settings_signature(settings)


def _svo_v8_autosave_timer() -> Optional[float]:
    global _SVO_V8_AUTOSAVE_RUNNING, _SVO_V8_LAST_SIGNATURE, _SVO_V8_LAST_ACTIVE_PRESET
    try:
        scene = getattr(bpy.context, "scene", None)
        settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
        if settings is None or not getattr(settings, "auto_save_workspace_preset_changes", False):
            _SVO_V8_AUTOSAVE_RUNNING = False
            return None
        if time.monotonic() < _SVO_V8_AUTOSAVE_SUSPEND_UNTIL:
            return 1.0
        selected = getattr(settings, "selected_preset", "")
        active = getattr(settings, "auto_save_active_preset", "")
        if selected not in SVO_V6_PRESETS or active != selected:
            _SVO_V8_LAST_SIGNATURE = _svo_v8_settings_signature(settings)
            _SVO_V8_LAST_ACTIVE_PRESET = selected
            return 1.0
        sig = _svo_v8_settings_signature(settings)
        if not _SVO_V8_LAST_SIGNATURE or _SVO_V8_LAST_ACTIVE_PRESET != selected:
            _SVO_V8_LAST_SIGNATURE = sig
            _SVO_V8_LAST_ACTIVE_PRESET = selected
            return 1.0
        if sig != _SVO_V8_LAST_SIGNATURE:
            _svo_v8_save_builtin_override(settings, selected)
            _SVO_V8_LAST_SIGNATURE = sig
            _SVO_V8_LAST_ACTIVE_PRESET = selected
            try:
                settings.status_text = "Preset user override saved"
            except Exception:
                pass
            try:
                if getattr(settings, "optimizer_active", False):
                    _svo_v9_reapply_active_optimizer(bpy.context, reason="settings_changed", allow_guard=False)
            except Exception:
                pass
    except Exception:
        pass
    return 1.0


def _svo_v8_ensure_autosave_timer() -> None:
    global _SVO_V8_AUTOSAVE_RUNNING
    if _SVO_V8_AUTOSAVE_RUNNING:
        return
    try:
        scene = getattr(bpy.context, "scene", None)
        settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
        if settings is None or not getattr(settings, "auto_save_workspace_preset_changes", False):
            _SVO_V8_AUTOSAVE_RUNNING = False
            return
        bpy.app.timers.register(_svo_v8_autosave_timer, first_interval=10.0, persistent=True)
        _SVO_V8_AUTOSAVE_RUNNING = True
    except Exception:
        _SVO_V8_AUTOSAVE_RUNNING = False


def _svo_v8_stop_autosave_timer() -> None:
    global _SVO_V8_AUTOSAVE_RUNNING
    _SVO_V8_AUTOSAVE_RUNNING = False
    try:
        if bpy.app.timers.is_registered(_svo_v8_autosave_timer):
            bpy.app.timers.unregister(_svo_v8_autosave_timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_svo_v8_autosave_timer):
            bpy.app.timers.unregister(_svo_v8_autosave_timer)
    except Exception:
        pass


def _svo_v6_atomic_json(path: str, data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        _prev = _svo_v6_read_json(path)
        if _prev is not None and _sws_storage is not None and _sws_storage.same_json_ignoring_saved_at(_prev, data):
            # 内容が同じ（saved_at だけの違い）なら書き直さない。
            try:
                _sws_storage.mirror_json_file(path, data)
            except Exception:
                pass
            return
    except Exception:
        pass
    fd, tmp = tempfile.mkstemp(prefix=".tmp_", suffix=".json", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            try: os.remove(tmp)
            except Exception: pass
    try:
        if _sws_storage is not None:
            _sws_storage.mirror_json_file(path, data)
    except Exception:
        pass

def _svo_v6_read_json(path: str) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None

# -----------------------------------------------------------------------------
# v12 simple Standard / Optimized settings files and live viewport apply
# -----------------------------------------------------------------------------

_SVO_V12_SETTINGS_IO_GUARD = False
_SVO_V12_LIVE_APPLY_GUARD = False
_SVO_CANONICAL_PERSIST_UPDATE_DEPTH = 0
_SVO_CANONICAL_PERSIST_PENDING = False

def _svo_v12_settings_root() -> str:
    path = os.path.join(_svo_v6_user_root(), "settings")
    os.makedirs(path, exist_ok=True)
    return path

def _svo_v12_current_settings_path() -> str:
    return os.path.join(_svo_v12_settings_root(), "current_settings.json")

def _svo_v12_slot_settings_path(slot: str) -> str:
    slot = "STANDARD" if str(slot).upper() == "STANDARD" else "OPTIMIZED"
    name = "standard_settings.json" if slot == "STANDARD" else "optimized_settings.json"
    return os.path.join(_svo_v12_settings_root(), name)

def _svo_v12_slot_label(slot: str) -> str:
    return "Standard" if str(slot).upper() == "STANDARD" else "Optimized"

def _svo_v12_canonical_slot(slot: Any) -> str:
    return "STANDARD" if str(slot or "").upper() == "STANDARD" else "OPTIMIZED"

def _svo_v12_set_active_slot_value(settings: bpy.types.PropertyGroup, slot: Any) -> None:
    global _SVO_V12_SETTINGS_IO_GUARD
    if settings is None:
        return
    old_guard = _SVO_V12_SETTINGS_IO_GUARD
    _SVO_V12_SETTINGS_IO_GUARD = True
    try:
        settings.active_settings_slot = _svo_v12_canonical_slot(slot)
    except Exception:
        pass
    finally:
        _SVO_V12_SETTINGS_IO_GUARD = old_guard

def _svo_v12_detail_setting_keys(settings: Optional[bpy.types.PropertyGroup] = None) -> List[str]:
    excluded = {
        "optimizer_active", "restore_before_file_events", "reapply_after_save_if_active",
        "keymap_operator_id", "custom_preset_name", "backup_restore_kind",
        "external_backup_on_register", "external_backup_on_startup",
        "external_backup_before_apply", "external_backup_on_file_load",
        "keep_backup_history", "max_backup_files", "auto_save_active_preset",
    }
    keys: List[str] = []
    for key in MAX_SPEED_DEFAULTS.keys():
        if key in excluded:
            continue
        if settings is not None and not hasattr(settings, key):
            continue
        keys.append(key)
    for key in ("selected_preset", "auto_save_workspace_preset_changes"):
        if key not in keys and (settings is None or hasattr(settings, key)):
            keys.append(key)
    return keys

def _svo_v12_current_values(settings: bpy.types.PropertyGroup) -> Dict[str, Any]:
    values: Dict[str, Any] = {}
    for key in _svo_v12_detail_setting_keys(settings):
        try:
            values[key] = _json_value(getattr(settings, key))
        except Exception:
            pass
    return values


def _svo_v12_layout_sidecar_path(filepath: str) -> str:
    """Return a stable sibling file for one explicit View3D layout."""
    path = os.path.abspath(str(filepath or ""))
    stem, _ext = os.path.splitext(path)
    return stem + ".layout.json"


def _svo_v12_workspace_layout_sidecar_path(workspace_name: str, slot: str) -> str:
    workspace_key = _svo_v13_safe_workspace_key(workspace_name)
    digest = hashlib.sha1(workspace_key.encode("utf-8", "replace")).hexdigest()[:16]
    slot_key = _svo_v12_canonical_slot(slot).lower()
    return os.path.join(
        _svo_v12_settings_root(),
        f"workspace_{digest}_{slot_key}.layout.json",
    )


def _svo_v12_safe_layout_ref_path(base_dir: str, reference: Any) -> str:
    name = os.path.basename(str(reference or "").strip())
    if not name:
        return ""
    root = os.path.abspath(str(base_dir or ""))
    candidate = os.path.abspath(os.path.join(root, name))
    try:
        if os.path.commonpath((root, candidate)) != root:
            return ""
    except Exception:
        return ""
    return candidate


def _svo_v12_write_layout_sidecar(filepath: str, layout: Any) -> str:
    if not isinstance(layout, dict):
        return ""
    sidecar = os.path.abspath(str(filepath or ""))
    if not sidecar:
        return ""
    payload = {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "role": "viewport_optimizer_explicit_view3d_layout",
        "saved_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "view3d_layout": layout,
    }
    os.makedirs(os.path.dirname(sidecar), exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=".tmp_layout_",
        suffix=".json",
        dir=os.path.dirname(sidecar),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.replace(tmp, sidecar)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass
    # Full layouts are explicit user data snapshots, not N-panel settings.
    # Remove any mirror left by a previous version without deleting the file.
    try:
        if _sws_storage is not None:
            _sws_storage.unmirror_json_file(sidecar, force=True)
    except Exception:
        pass
    return os.path.basename(sidecar)


def _svo_v12_attach_layout_reference(payload: Dict[str, Any], base_dir: str) -> Dict[str, Any]:
    """Return a detached payload with an explicit layout sidecar resolved."""
    result = dict(payload) if isinstance(payload, dict) else {}
    if isinstance(result.get("view3d_layout"), dict):
        return result
    ref_path = _svo_v12_safe_layout_ref_path(base_dir, result.get("view3d_layout_ref"))
    if not ref_path:
        return result
    sidecar = _svo_v6_read_json(ref_path) or {}
    layout = sidecar.get("view3d_layout") if isinstance(sidecar, dict) else None
    if isinstance(layout, dict):
        result["view3d_layout"] = layout
    return result


def _svo_v12_compact_layout_payload(
    payload: Dict[str, Any],
    *,
    sidecar_path: str,
    previous: Optional[Dict[str, Any]] = None,
    include_layout: bool,
) -> Dict[str, Any]:
    """Move a complete explicit layout out of the frequently rewritten JSON.

    Startup, file-load, and real-time N-panel updates now rewrite only compact
    values. Explicit Save still captures exactly the same complete layout, but
    stores it in a sibling JSON that is not serialized again on every setting
    change. Legacy inline layouts are migrated once.
    """
    result = dict(payload) if isinstance(payload, dict) else {}
    old = previous if isinstance(previous, dict) else {}
    layout = result.pop("view3d_layout", None)
    if not isinstance(layout, dict):
        layout = old.get("view3d_layout") if isinstance(old.get("view3d_layout"), dict) else None

    explicit = bool(include_layout and isinstance(layout, dict))
    if not explicit:
        explicit = bool(
            old.get("view3d_layout_source") == "explicit"
            and (
                isinstance(old.get("view3d_layout"), dict)
                or bool(old.get("view3d_layout_ref"))
            )
        )

    reference = ""
    if explicit and isinstance(layout, dict):
        reference = _svo_v12_write_layout_sidecar(sidecar_path, layout)
    elif explicit:
        old_ref = _svo_v12_safe_layout_ref_path(
            os.path.dirname(sidecar_path),
            old.get("view3d_layout_ref"),
        )
        if old_ref and os.path.isfile(old_ref):
            reference = os.path.basename(old_ref)

    if reference:
        result["view3d_layout_ref"] = reference
        result["view3d_layout_source"] = "explicit"
    else:
        result.pop("view3d_layout_ref", None)
        result.pop("view3d_layout_source", None)
    return result

def _svo_v12_payload(
    settings: bpy.types.PropertyGroup,
    slot: str,
    context: Optional[bpy.types.Context] = None,
    *,
    include_layout: bool = True,
) -> Dict[str, Any]:
    slot = "STANDARD" if str(slot).upper() == "STANDARD" else "OPTIMIZED"
    payload = {
        "addon": ADDON_ID,
        "storage_dir": STORAGE_DIRNAME,
        "version": ADDON_VERSION,
        "role": "viewport_optimizer_detail_settings",
        "slot": slot,
        "name": _svo_v12_slot_label(slot),
        "saved_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "values": _svo_v12_current_values(settings),
    }
    try:
        if include_layout and context is not None:
            layout_data = _svo_v14_get_cached_view3d_layout(context)
            if isinstance(layout_data, dict) and layout_data.get("areas"):
                payload["view3d_layout"] = layout_data
                payload["view3d_layout_source"] = "explicit"
    except Exception:
        pass
    return payload

def _svo_v12_write_settings_file(
    settings: bpy.types.PropertyGroup,
    filepath: str,
    slot: str,
    context: Optional[bpy.types.Context] = None,
    *,
    include_layout: bool = True,
) -> str:
    filepath = _svo_v10_normalize_json_path(filepath, _svo_v12_slot_settings_path(slot))
    payload = _svo_v12_payload(
        settings,
        slot,
        context=context,
        include_layout=include_layout,
    )
    old_payload = _svo_v6_read_json(filepath) or {}
    payload = _svo_v12_compact_layout_payload(
        payload,
        sidecar_path=_svo_v12_layout_sidecar_path(filepath),
        previous=old_payload,
        include_layout=include_layout,
    )
    _svo_v6_atomic_json(filepath, payload)
    return filepath

def _svo_v12_write_current_settings_file(
    settings: bpy.types.PropertyGroup,
    slot: Optional[str] = None,
    context: Optional[bpy.types.Context] = None,
    *,
    include_layout: bool = True,
) -> str:
    slot = slot or getattr(settings, "active_settings_slot", "OPTIMIZED") or "OPTIMIZED"
    _svo_v12_set_active_slot_value(settings, slot)
    return _svo_v12_write_settings_file(
        settings,
        _svo_v12_current_settings_path(),
        slot,
        context=context,
        include_layout=include_layout,
    )

def _svo_v12_extract_values(data: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    values = data.get("values")
    if isinstance(values, dict):
        return dict(values)
    # Legacy compatibility: accept direct dictionaries containing setting keys.
    return {k: v for k, v in data.items() if k in MAX_SPEED_DEFAULTS or k in {"selected_preset", "auto_save_workspace_preset_changes"}}


# -----------------------------------------------------------------------------
# v14 per-3D-View layout/view state capture
# -----------------------------------------------------------------------------

_SVO_V14_REGION_SPACE_PROPS = (
    "show_region_header",
    "show_region_tool_header",
    "show_menus",
    "show_region_ui",
    "show_region_toolbar",
    "show_region_hud",
    "show_region_asset_shelf",
)
_SVO_V14_VIEW_SPACE_PROPS = (
    "lens",
    "clip_start",
    "clip_end",
    "use_local_camera",
    "camera",
    "lock_camera",
    "lock_object",
    "lock_bone",
    "lock_cursor",
    "show_reconstruction",
    "show_camera_path",
    "show_camera_frame",
    "show_camera_guides",
    "show_camera_passepartout",
    "show_safe_areas",
    "show_bundle_names",
    "stereo_3d_camera",
    "show_stereo_3d_cameras",
    "show_stereo_3d_volume",
    "show_stereo_3d_convergence_plane",
    "use_render_border",
    "render_border_min_x",
    "render_border_min_y",
    "render_border_max_x",
    "render_border_max_y",
)
_SVO_V14_REGION3D_PROPS = (
    "view_perspective",
    "view_location",
    "view_rotation",
    "view_distance",
    "view_camera_zoom",
    "view_camera_offset",
    "lock_rotation",
)
_SVO_V14_EXTRA_OVERLAY_PROPS = (
    "wireframe_threshold",
    "show_freestyle_edge_marks",
    "show_freestyle_face_marks",
    "show_curve_normals",
    "show_sculpt_face_sets",
    "show_sculpt_mask",
    "use_gpencil_edit_lines",
    "use_debug_freeze_view_culling",
)
_SVO_V14_EXTRA_SHADING_PROPS = (
    "studiolight_intensity",
    "studiolight_background_alpha",
    "studiolight_background_blur",
    "background_type",
    "background_color",
    "single_color",
    "wire_color_type",
)


def _svo_v14_area_rect(area: Any) -> Dict[str, int]:
    return {
        "x": int(getattr(area, "x", 0) or 0),
        "y": int(getattr(area, "y", 0) or 0),
        "w": int(getattr(area, "width", 0) or 0),
        "h": int(getattr(area, "height", 0) or 0),
    }


def _svo_v14_object_ref(value: Any) -> str:
    try:
        return str(getattr(value, "name", "") or "")
    except Exception:
        return ""


def _svo_v14_json_value(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        # mathutils Vector/Quaternion and Blender float arrays.
        if hasattr(value, "__len__"):
            return [_svo_v14_json_value(v) for v in value]
    except Exception:
        pass
    try:
        return str(value)
    except Exception:
        return None


def _svo_v14_simple_rna_identifiers(target: Any) -> Tuple[str, ...]:
    props: List[str] = []
    try:
        rna = getattr(target, "bl_rna", None)
        for prop in getattr(rna, "properties", []) or []:
            ident = str(getattr(prop, "identifier", "") or "")
            if not ident or ident == "rna_type":
                continue
            try:
                prop_type = str(getattr(prop, "type", "") or "")
            except Exception:
                prop_type = ""
            if prop_type in {"BOOLEAN", "INT", "FLOAT", "STRING", "ENUM"}:
                props.append(ident)
    except Exception:
        pass
    return tuple(dict.fromkeys(props))


def _svo_v14_record_props(target: Any, attrs: Sequence[str], *, skip_refs: bool = False) -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    if target is None:
        return data
    for attr in attrs:
        try:
            if not hasattr(target, attr):
                continue
            value = getattr(target, attr)
            if skip_refs and hasattr(value, "name") and not isinstance(value, (str, int, float, bool)):
                continue
            data[attr] = _svo_v14_json_value(value)
        except Exception:
            continue
    return data


def _svo_v14_dynamic_space_props(space: Any) -> Tuple[str, ...]:
    props = (
        list(SPACE_PROPS)
        + list(_SVO_V14_REGION_SPACE_PROPS)
        + list(_SVO_V14_VIEW_SPACE_PROPS)
        + list(_svo_v14_simple_rna_identifiers(space))
    )
    return tuple(dict.fromkeys(p for p in props if p))


def _svo_v14_dynamic_overlay_props(overlay: Any) -> Tuple[str, ...]:
    props = list(OVERLAY_PROPS) + list(_SVO_V14_EXTRA_OVERLAY_PROPS) + list(_svo_v14_simple_rna_identifiers(overlay))
    return tuple(dict.fromkeys(p for p in props if p))


def _svo_v14_dynamic_shading_props(shading: Any) -> Tuple[str, ...]:
    props = list(SHADING_PROPS) + list(_SVO_V14_EXTRA_SHADING_PROPS) + list(_svo_v14_simple_rna_identifiers(shading))
    return tuple(dict.fromkeys(p for p in props if p))


def _svo_v14_dynamic_region3d_props(region_3d: Any) -> Tuple[str, ...]:
    props = list(_SVO_V14_REGION3D_PROPS) + list(_svo_v14_simple_rna_identifiers(region_3d))
    return tuple(dict.fromkeys(p for p in props if p))


def _svo_v14_pointer_id(value: Any) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _svo_v14_index_in_collection(collection: Any, item: Any) -> int:
    try:
        for index, value in enumerate(collection or []):
            if value == item:
                return int(index)
    except Exception:
        pass
    return -1


def _svo_v14_workspace_screens(workspace: Any) -> Tuple[Any, ...]:
    try:
        return tuple(getattr(workspace, "screens", []) or [])
    except Exception:
        return ()


def _svo_v14_iter_all_view3d_spaces(context: Optional[bpy.types.Context]) -> Iterable[Tuple[Optional[bpy.types.Window], str, int, bpy.types.Screen, int, int, bpy.types.Area, int, bpy.types.SpaceView3D]]:
    """Yield 3D View spaces across all reachable workspaces/screens.

    The regular snapshot iterator only sees the active window/screen.  Detailed
    settings, however, must preserve multiple 3D View windows inside every
    workspace and restore each one to the same layout slot.  This iterator uses
    window screens first, then workspace.screens, and finally orphaned screens so
    saved data is not limited to the currently active workspace.
    """
    ctx = context or getattr(bpy, "context", None)
    seen_slots = set()
    seen_screen_ptrs = set()

    def _emit(window: Optional[bpy.types.Window], workspace: Any, screen: Any):
        if screen is None:
            return
        try:
            areas = tuple(getattr(screen, "areas", []) or [])
        except Exception:
            return
        ws_name = ""
        if workspace is not None:
            try:
                ws_name = str(getattr(workspace, "name", "") or "")
            except Exception:
                ws_name = ""
        if not ws_name and window is not None:
            try:
                ws_name = str(getattr(getattr(window, "workspace", None), "name", "") or "")
            except Exception:
                ws_name = ""
        try:
            workspaces = tuple(getattr(bpy.data, "workspaces", []) or [])
        except Exception:
            workspaces = ()
        try:
            screens = tuple(getattr(bpy.data, "screens", []) or [])
        except Exception:
            screens = ()
        workspace_index = _svo_v14_index_in_collection(workspaces, workspace) if workspace is not None else -1
        screen_index = _svo_v14_index_in_collection(screens, screen)
        screen_ptr = _svo_v14_pointer_id(screen)
        seen_screen_ptrs.add(screen_ptr)
        for area_index, area in enumerate(areas):
            try:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
            except Exception:
                continue
            try:
                spaces = tuple(getattr(area, "spaces", []) or [])
            except Exception:
                spaces = ()
            for space_index, space in enumerate(spaces):
                try:
                    if getattr(space, "type", "") != "VIEW_3D":
                        continue
                except Exception:
                    continue
                key = (ws_name, screen_ptr, int(area_index), int(space_index))
                if key in seen_slots:
                    continue
                seen_slots.add(key)
                yield window, ws_name, workspace_index, screen, screen_index, int(area_index), area, int(space_index), space

    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    try:
        windows = tuple(getattr(wm, "windows", []) or []) if wm is not None else ()
    except Exception:
        windows = ()
    for window in windows:
        try:
            workspace = getattr(window, "workspace", None)
        except Exception:
            workspace = None
        try:
            screen = getattr(window, "screen", None)
        except Exception:
            screen = None
        yield from _emit(window, workspace, screen)

    try:
        workspaces = tuple(getattr(bpy.data, "workspaces", []) or [])
    except Exception:
        workspaces = ()
    for workspace in workspaces:
        for screen in _svo_v14_workspace_screens(workspace):
            yield from _emit(None, workspace, screen)

    # Some background/transition contexts expose screens without a workspace link.
    try:
        screens = tuple(getattr(bpy.data, "screens", []) or [])
    except Exception:
        screens = ()
    for screen in screens:
        try:
            screen_ptr = _svo_v14_pointer_id(screen)
        except Exception:
            screen_ptr = id(screen)
        if screen_ptr in seen_screen_ptrs:
            continue
        yield from _emit(None, None, screen)


_SVO_OBJECT_STATE_PROPS = (
    "hide_viewport", "hide_select", "display_type", "display_bounds_type", "show_name", "show_axis",
    "show_texture_space", "show_bounds", "show_wire", "show_all_edges", "show_in_front", "show_transparent",
    "show_instancer_for_viewport", "use_simulation_cache",
)


_SVO_PREFERENCE_STATE_PROPS = {
    "system": (
        "viewport_aa", "gl_texture_limit", "texture_time_out", "vbo_time_out", "texture_collection_rate",
        "vbo_collection_rate", "use_gpu_subdivision", "use_overlay_smooth_wire", "use_edit_mode_smooth_wire",
        "shader_compilation_method", "gpu_shader_workers", "memory_cache_limit", "use_region_overlap",
    ),
    "inputs": (
        "use_mouse_depth_navigate", "use_zoom_to_mouse", "use_rotate_around_active", "use_auto_perspective",
        "view_rotate_method", "view_zoom_method", "view_zoom_axis", "ndof_show_guide_orbit_axis",
        "ndof_show_guide_orbit_center",
    ),
    "view": (
        "smooth_view", "show_navigate_ui", "use_reduce_motion", "show_statusbar_stats", "show_statusbar_memory",
        "show_statusbar_vram", "show_statusbar_version",
    ),
    "edit": (
        "use_global_undo", "undo_steps", "undo_memory_limit", "use_auto_keying", "use_auto_keyframe_insert_needed",
    ),
}


def _svo_read_object_state(obj: bpy.types.Object) -> Dict[str, Any]:
    try:
        data = json.loads(getattr(obj, "smart_viewport_optimizer_object_state", "") or "{}")
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _svo_modifier_state_key(mod: Any) -> str:
    return str(getattr(mod, "persistent_uid", mod.name))


def _svo_record_object_states(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    """Remember each target object's own values once, before the optimizer first changes them.

    The record lives on the object, so it follows a rename and a duplicate carries the source's
    values. Modifiers and constraints that appear later are added to the record before they change.
    """
    for obj in _target_objects(context, settings):
        entry = _svo_read_object_state(obj)
        before = dict(entry)
        if not entry:
            try:
                selected = bool(obj.select_get())
            except Exception:
                selected = False
            entry = {"props": _svo_v14_record_props(obj, _SVO_OBJECT_STATE_PROPS), "selected": selected}
        modifiers = dict(entry.get("modifiers") or {})
        for mod in getattr(obj, "modifiers", []):
            modifiers.setdefault(_svo_modifier_state_key(mod), bool(mod.show_viewport))
        constraints = dict(entry.get("constraints") or {})
        for con in getattr(obj, "constraints", []):
            constraints.setdefault(con.name, bool(con.mute))
        pose_constraints = dict(entry.get("pose_constraints") or {})
        pose = getattr(obj, "pose", None)
        for bone in (pose.bones if pose is not None else []):
            if len(bone.constraints):
                cons = dict(pose_constraints.get(bone.name) or {})
                for con in bone.constraints:
                    cons.setdefault(con.name, bool(con.mute))
                pose_constraints[bone.name] = cons
        entry.update({"modifiers": modifiers, "constraints": constraints, "pose_constraints": pose_constraints})
        if entry != before:
            _safe_set(obj, "smart_viewport_optimizer_object_state", json.dumps(entry, ensure_ascii=False, separators=(",", ":")))


def _svo_restore_object_states(context: bpy.types.Context) -> None:
    """Return every remembered object to the values it had before optimization."""
    to_select: List[bpy.types.Object] = []
    for obj in bpy.data.objects:
        entry = _svo_read_object_state(obj)
        if not entry:
            continue
        for attr, value in (entry.get("props") or {}).items():
            _safe_set(obj, attr, value)
        modifiers = entry.get("modifiers") or {}
        for mod in getattr(obj, "modifiers", []):
            value = modifiers.get(_svo_modifier_state_key(mod))
            if value is not None:
                _safe_set(mod, "show_viewport", value)
        for con_name, value in (entry.get("constraints") or {}).items():
            con = obj.constraints.get(con_name)
            if con is not None:
                _safe_set(con, "mute", value)
        pose = getattr(obj, "pose", None)
        if pose is not None:
            for bone_name, cons in (entry.get("pose_constraints") or {}).items():
                bone = pose.bones.get(bone_name)
                if bone is None:
                    continue
                for con_name, value in cons.items():
                    con = bone.constraints.get(con_name)
                    if con is not None:
                        _safe_set(con, "mute", value)
        if entry.get("selected"):
            to_select.append(obj)
        _safe_set(obj, "smart_viewport_optimizer_object_state", "")
    # A selection the user made while optimized wins over the remembered one.
    if to_select and not list(getattr(context, "selected_objects", [])):
        # select_set ignores objects the view layer still treats as unselectable.
        context.view_layer.update()
        for obj in to_select:
            try:
                obj.select_set(True)
            except Exception:
                pass


def _svo_preference_state_path() -> str:
    return os.path.join(_svo_v12_settings_root(), "preferences_before_optimization.json")


def _svo_capture_preferences(context: bpy.types.Context) -> Dict[str, Any]:
    prefs = getattr(context, "preferences", None)
    return {group: _svo_v14_record_props(getattr(prefs, group, None), attrs) for group, attrs in _SVO_PREFERENCE_STATE_PROPS.items()}


def _svo_read_preference_state() -> Dict[str, Any]:
    path = _svo_preference_state_path()
    return (_svo_v6_read_json(path) or {}) if os.path.exists(path) else {}


def _svo_record_preferences(context: bpy.types.Context) -> None:
    """Preferences outlive the file, so their pre-optimization values are kept next to the slot settings."""
    if not _svo_read_preference_state():
        _svo_v6_atomic_json(_svo_preference_state_path(), _svo_capture_preferences(context))


def _svo_write_preferences(context: bpy.types.Context, state: Dict[str, Any]) -> None:
    prefs = getattr(context, "preferences", None)
    for group, values in state.items():
        target = getattr(prefs, group, None)
        if target is not None and isinstance(values, dict):
            for attr, value in values.items():
                _safe_set(target, attr, value)


def _svo_is_work_object(context: bpy.types.Context, obj: bpy.types.Object) -> bool:
    """The active object and the selection are what the user is working on."""
    try:
        return obj == context.view_layer.objects.active or obj.select_get()
    except Exception:
        return False


def _svo_object_draws_without_overlays(settings: bpy.types.PropertyGroup, display_type: str) -> bool:
    """Bounds and Wire are drawn by the overlay pass, so they vanish while overlays are off."""
    if display_type not in {"BOUNDS", "WIRE"}:
        return True
    if not getattr(settings, "include_overlays", True):
        return True
    return bool(getattr(settings, "target_show_overlays", True))


def _svo_v14_capture_view3d_layout(context: Optional[bpy.types.Context]) -> Dict[str, Any]:
    areas: List[Dict[str, Any]] = []
    try:
        iterator = list(_svo_v14_iter_all_view3d_spaces(context or bpy.context))
    except Exception:
        iterator = []
    for window, workspace_name, workspace_index, screen, screen_index, area_index, area, space_index, space in iterator:
        try:
            overlay = getattr(space, "overlay", None)
            shading = getattr(space, "shading", None)
            rv3d = getattr(space, "region_3d", None)
            space_props = _svo_v14_record_props(space, _svo_v14_dynamic_space_props(space), skip_refs=True)
            refs = {
                "camera": _svo_v14_object_ref(getattr(space, "camera", None)),
                "lock_object": _svo_v14_object_ref(getattr(space, "lock_object", None)),
            }
            try:
                window_index = -1 if window is None else list((getattr(context or bpy.context, "window_manager", None) or bpy.context.window_manager).windows).index(window)
            except Exception:
                window_index = -1
            area_rect = _svo_v14_area_rect(area)
            area_entry = {
                "workspace_name": str(workspace_name or ""),
                "workspace_index": int(workspace_index),
                "window_index": int(window_index),
                "screen_name": str(getattr(screen, "name", "") or ""),
                "screen_index": int(screen_index),
                "area_index": int(area_index),
                "space_index": int(space_index),
                "area_rect": area_rect,
                "layout_key": "{}|{}|{}|{}|{}".format(str(workspace_name or ""), str(getattr(screen, "name", "") or ""), int(area_index), int(space_index), area_rect),
                "space": space_props,
                "space_refs": refs,
                "overlay": _svo_v14_record_props(overlay, _svo_v14_dynamic_overlay_props(overlay)),
                "shading": _svo_v14_record_props(shading, _svo_v14_dynamic_shading_props(shading)),
                "region_3d": _svo_v14_record_props(rv3d, _svo_v14_dynamic_region3d_props(rv3d)),
            }
            areas.append(area_entry)
        except Exception:
            continue
    return {
        "schema": "SVO_VIEW3D_LAYOUT_V2",
        "captured_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "areas": areas,
    }


def _svo_v14_layout_signature(context: Optional[bpy.types.Context]) -> Tuple[Any, ...]:
    parts: List[Any] = []
    try:
        iterator = list(_svo_v14_iter_all_view3d_spaces(context or bpy.context))
    except Exception:
        iterator = []
    for _window, workspace_name, _workspace_index, screen, _screen_index, area_index, area, space_index, _space in iterator:
        try:
            rect = _svo_v14_area_rect(area)
            parts.append((str(workspace_name or ""), str(getattr(screen, "name", "") or ""), int(area_index), int(space_index), int(rect.get("x", 0)), int(rect.get("y", 0)), int(rect.get("w", 0)), int(rect.get("h", 0))))
        except Exception:
            continue
    try:
        obj_count = len(getattr(bpy.data, "objects", []) or [])
    except Exception:
        obj_count = 0
    parts.append(("objects", obj_count))
    return tuple(parts)


def _svo_v14_get_cached_view3d_layout(context: Optional[bpy.types.Context], *, max_age: float = 1.25) -> Dict[str, Any]:
    """Return captured multi-View3D layout with short-lived caching.

    Capturing this layout walks every workspace/3D View and every object state.
    Doing that repeatedly from live setting writes or panel redraw makes the
    Viewport Optimization section feel very heavy.  A sub-second cache preserves
    the same saved data semantics for explicit saves while eliminating redundant
    captures during one redraw/update burst.
    """
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    try:
        sig = _svo_v14_layout_signature(context)
    except Exception:
        sig = None
    try:
        cached = _SVO_V14_LAYOUT_CACHE.get("data")
        if isinstance(cached, dict) and cached.get("areas") and sig == _SVO_V14_LAYOUT_CACHE.get("sig") and (now - float(_SVO_V14_LAYOUT_CACHE.get("ts") or 0.0)) <= max_age:
            return cached
    except Exception:
        pass
    data = _svo_v14_capture_view3d_layout(context)
    try:
        _SVO_V14_LAYOUT_CACHE["data"] = data
        _SVO_V14_LAYOUT_CACHE["sig"] = sig
        _SVO_V14_LAYOUT_CACHE["ts"] = now or time.monotonic()
    except Exception:
        pass
    return data


def _svo_v14_set_space_prop(context: Optional[bpy.types.Context], target: Any, attr: str, value: Any, *, window: Optional[bpy.types.Window] = None, screen: Optional[bpy.types.Screen] = None, area: Optional[bpy.types.Area] = None) -> bool:
    """Set SpaceView3D properties without operators or context overrides.

    Blender 5.1.0 Windows can crash during startup/file-read when
    a context override enters an inactive workspace/screen and the native
    window manager changes workspace while edit mode/undo is not ready.  Region
    visibility and other SpaceView3D values are therefore restored only through
    direct RNA assignment.  If Blender rejects the write, the add-on skips that
    UI value instead of risking a native access violation.
    """
    try:
        if target is None or not attr or not hasattr(target, attr):
            return False
        prop = _get_bl_rna_property(target, attr)
        try:
            if prop is not None and getattr(prop, "is_readonly", False):
                return False
        except Exception:
            pass
        return _safe_set(target, attr, value)
    except Exception:
        return False


def _svo_v14_restore_props(context: Optional[bpy.types.Context], target: Any, data: Dict[str, Any], *, space_target: bool = False, window: Optional[bpy.types.Window] = None, screen: Optional[bpy.types.Screen] = None, area: Optional[bpy.types.Area] = None) -> int:
    if target is None or not isinstance(data, dict):
        return 0
    count = 0
    for attr, value in data.items():
        try:
            if attr in {"camera", "lock_object", "show_locked_time"}:
                continue
            ok = _svo_v14_set_space_prop(context, target, attr, value, window=window, screen=screen, area=area) if space_target else _safe_set(target, attr, value)
            if ok:
                count += 1
        except Exception:
            continue
    return count


def _svo_v14_restore_refs(space: Any, refs: Dict[str, Any]) -> None:
    if space is None or not isinstance(refs, dict):
        return
    for attr in ("camera", "lock_object"):
        name = str(refs.get(attr) or "").strip()
        try:
            obj = bpy.data.objects.get(name) if name else None
            if obj is not None and hasattr(space, attr):
                setattr(space, attr, obj)
        except Exception:
            pass



def _svo_v14_apply_region_visibility_exact(context: Optional[bpy.types.Context], space: Any, entry: Dict[str, Any], *, window: Optional[bpy.types.Window] = None, screen: Optional[bpy.types.Screen] = None, area: Optional[bpy.types.Area] = None) -> None:
    data = entry.get("space") if isinstance(entry, dict) else {}
    if not isinstance(data, dict):
        return
    # Apply Sidebar last because some other region toggles can force area rebuilds.
    ordered = (
        "show_region_header",
        "show_region_tool_header",
        "show_menus",
        "show_region_toolbar",
        "show_region_hud",
        "show_region_asset_shelf",
        "show_region_ui",
    )
    for attr in ordered:
        if attr in data:
            try:
                _svo_v14_set_space_prop(context, space, attr, data.get(attr), window=window, screen=screen, area=area)
            except Exception:
                pass


def _svo_v14_rect_score(a: Dict[str, int], b: Dict[str, int]) -> int:
    try:
        return abs(int(a.get("x", 0)) - int(b.get("x", 0))) + abs(int(a.get("y", 0)) - int(b.get("y", 0))) + abs(int(a.get("w", 0)) - int(b.get("w", 0))) + abs(int(a.get("h", 0)) - int(b.get("h", 0)))
    except Exception:
        return 10 ** 9


def _svo_v14_find_target(entry: Dict[str, Any], targets: List[Tuple[int, Optional[bpy.types.Window], str, int, bpy.types.Screen, int, int, bpy.types.Area, int, bpy.types.SpaceView3D]], used: set) -> Optional[Tuple[int, Optional[bpy.types.Window], str, int, bpy.types.Screen, int, int, bpy.types.Area, int, bpy.types.SpaceView3D]]:
    workspace_name = str(entry.get("workspace_name") or "")
    screen_name = str(entry.get("screen_name") or "")
    area_index = int(entry.get("area_index", -1) or -1)
    space_index = int(entry.get("space_index", -1) or -1)

    # First preference: same workspace, same screen, same area/space slot.
    for target in targets:
        idx, _window, ws_name, _ws_index, screen, _screen_index, ai, _area, si, _space = target
        if idx in used:
            continue
        if ws_name == workspace_name and str(getattr(screen, "name", "") or "") == screen_name and ai == area_index and si == space_index:
            return target
    # Backward-compatible V2 match: same screen and area/space slot.
    for target in targets:
        idx, _window, _ws_name, _ws_index, screen, _screen_index, ai, _area, si, _space = target
        if idx in used:
            continue
        if str(getattr(screen, "name", "") or "") == screen_name and ai == area_index and si == space_index:
            return target
    entry_rect = entry.get("area_rect") if isinstance(entry.get("area_rect"), dict) else {}
    best = None
    best_score = 10 ** 9
    for target in targets:
        idx, _window, ws_name, _ws_index, screen, _screen_index, _ai, area, _si, _space = target
        if idx in used:
            continue
        # Prefer the same workspace/screen when matching by rectangle.
        score = _svo_v14_rect_score(entry_rect, _svo_v14_area_rect(area))
        if workspace_name and ws_name != workspace_name:
            score += 1000000
        if screen_name and str(getattr(screen, "name", "") or "") != screen_name:
            score += 100000
        if score < best_score:
            best = target
            best_score = score
    return best


def _svo_v14_apply_view3d_layout(context: Optional[bpy.types.Context], layout_data: Any) -> bool:
    if _svo_v16_is_unsafe_ui_suppressed() or _svo_v16_in_file_boundary_stack():
        return False
    if not isinstance(layout_data, dict):
        return False
    entries = layout_data.get("areas")
    if not isinstance(entries, list):
        return False
    try:
        targets = []
        for idx, item in enumerate(_svo_v14_iter_all_view3d_spaces(context or bpy.context)):
            window, workspace_name, workspace_index, screen, screen_index, area_index, area, space_index, space = item
            targets.append((idx, window, workspace_name, workspace_index, screen, screen_index, area_index, area, space_index, space))
    except Exception:
        targets = []
    applied = False
    if not targets:
        return applied
    used = set()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        target = _svo_v14_find_target(entry, targets, used)
        if not target:
            continue
        idx, _window, _workspace_name, _workspace_index, _screen, _screen_index, _area_index, area, _space_index, space = target
        used.add(idx)
        try:
            _svo_v14_restore_props(context, space, entry.get("space") or {}, space_target=True, window=_window, screen=_screen, area=area)
            _svo_v14_restore_refs(space, entry.get("space_refs") or {})
            _svo_v14_restore_props(context, getattr(space, "overlay", None), entry.get("overlay") or {})
            _svo_v14_restore_props(context, getattr(space, "shading", None), entry.get("shading") or {})
            rv3d = getattr(space, "region_3d", None)
            _svo_v14_restore_props(context, rv3d, entry.get("region_3d") or {})
            _svo_v14_apply_region_visibility_exact(context, space, entry, window=_window, screen=_screen, area=area)
            try:
                area.tag_redraw()
            except Exception:
                pass
            applied = True
        except Exception:
            continue
    return applied



# -----------------------------------------------------------------------------
# v13 workspace-specific Detailed Settings store
# -----------------------------------------------------------------------------

_SVO_V13_WORKSPACE_SYNC_GUARD = False


def _svo_v13_workspace_settings_path() -> str:
    return os.path.join(_svo_v12_settings_root(), "workspace_settings.json")


def _svo_v13_active_workspace_name(context: Optional[bpy.types.Context]) -> str:
    try:
        ws = getattr(context, "workspace", None) if context is not None else None
        name = str(getattr(ws, "name", "") or "").strip()
        if name:
            return name
    except Exception:
        pass
    return "__default__"


def _svo_v13_workspace_display_name(context: Optional[bpy.types.Context]) -> str:
    name = _svo_v13_active_workspace_name(context)
    return "-" if name == "__default__" else name


def _svo_v13_safe_workspace_key(name: Any) -> str:
    text = str(name or "").strip() or "__default__"
    return text


def _svo_v13_read_workspace_store() -> Dict[str, Any]:
    data = _svo_v6_read_json(_svo_v13_workspace_settings_path()) or {}
    if not isinstance(data, dict):
        data = {}
    workspaces = data.get("workspaces")
    if not isinstance(workspaces, dict):
        workspaces = {}
    return {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "role": "viewport_optimizer_workspace_detail_settings",
        "updated_at": data.get("updated_at") or "",
        "workspaces": dict(workspaces),
    }


def _svo_v13_write_workspace_store(data: Dict[str, Any]) -> None:
    if not isinstance(data, dict):
        data = {}
    data["addon"] = ADDON_ID
    data["version"] = ADDON_VERSION
    data["role"] = "viewport_optimizer_workspace_detail_settings"
    data["updated_at"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    if not isinstance(data.get("workspaces"), dict):
        data["workspaces"] = {}
    _svo_v6_atomic_json(_svo_v13_workspace_settings_path(), data)


def _svo_v13_workspace_payload(
    settings: bpy.types.PropertyGroup,
    slot: str,
    workspace_name: str,
    context: Optional[bpy.types.Context] = None,
    *,
    include_layout: bool = True,
) -> Dict[str, Any]:
    payload = _svo_v12_payload(
        settings,
        slot,
        context=context,
        include_layout=include_layout,
    )
    payload["workspace"] = _svo_v13_safe_workspace_key(workspace_name)
    return payload


def _svo_v13_save_workspace_slot(
    context: Optional[bpy.types.Context],
    settings: bpy.types.PropertyGroup,
    slot: Optional[str] = None,
    workspace_name: Optional[str] = None,
    *,
    include_layout: bool = True,
) -> bool:
    if settings is None:
        return False
    slot = _svo_v12_canonical_slot(slot or getattr(settings, "active_settings_slot", "OPTIMIZED"))
    workspace_name = _svo_v13_safe_workspace_key(workspace_name or _svo_v13_active_workspace_name(context))
    try:
        data = _svo_v13_read_workspace_store()
        workspaces = data.setdefault("workspaces", {})
        entry = workspaces.setdefault(workspace_name, {})
        previous = entry.get(slot) if isinstance(entry, dict) else None
        payload = _svo_v13_workspace_payload(
            settings,
            slot,
            workspace_name,
            context=context,
            include_layout=include_layout,
        )
        payload = _svo_v12_compact_layout_payload(
            payload,
            sidecar_path=_svo_v12_workspace_layout_sidecar_path(workspace_name, slot),
            previous=previous if isinstance(previous, dict) else None,
            include_layout=include_layout,
        )
        entry[slot] = payload
        _svo_v13_write_workspace_store(data)
        try:
            settings.svo_workspace_active_name = workspace_name
        except Exception:
            pass
        return True
    except Exception:
        return False


def _svo_save_persistence_snapshot_verified(
    context: Optional[bpy.types.Context],
    settings: bpy.types.PropertyGroup,
    slot: Optional[str] = None,
    *,
    include_layout: bool = False,
) -> bool:
    """Persist current/workspace settings under a strict Boolean contract.

    Success is returned only after both JSON files are parsed back as UTF-8 JSON
    objects and their canonical central mirrors complete their own strict
    primary/central readback transaction.  Filesystem, permission, antivirus,
    replace, parse, and mirror failures are not converted into success.
    """
    if settings is None:
        return False
    canonical_slot = _svo_v12_canonical_slot(
        slot or getattr(settings, "active_settings_slot", "OPTIMIZED")
    )
    try:
        current_path = _svo_v12_write_current_settings_file(
            settings,
            canonical_slot,
            context=context,
            include_layout=include_layout,
        )
        if not _svo_v13_save_workspace_slot(
            context,
            settings,
            canonical_slot,
            include_layout=include_layout,
        ):
            return False
        paths = (
            str(current_path or ""),
            str(_svo_v13_workspace_settings_path() or ""),
        )
        if any(not path for path in paths):
            return False
        for path in paths:
            data = _svo_v6_read_json(path)
            if not isinstance(data, dict):
                return False
            # A direct byte readback prevents a stale in-memory payload from
            # being mistaken for a successful replace.
            with open(path, "r", encoding="utf-8", errors="strict") as handle:
                reread = json.load(handle)
            if not isinstance(reread, dict) or reread != data:
                return False
            if _sws_storage is not None:
                # During the suite-wide transaction every sidecar is first
                # durably staged and the complete canonical central payload is
                # committed exactly once by persistence.save_all_settings().
                # A nested mirror here would either recurse or manufacture a
                # partial central authority.
                batch_active = getattr(_sws_storage, "central_write_batch_active", None)
                if callable(batch_active) and bool(batch_active()):
                    continue
                mirrored = _sws_storage.mirror_json_file(path, data, force=True)
                if mirrored is not True:
                    return False
        return True
    except Exception:
        return False


def _svo_v13_workspace_slot_payload(workspace_name: str, slot: str) -> Dict[str, Any]:
    slot = _svo_v12_canonical_slot(slot)
    workspace_name = _svo_v13_safe_workspace_key(workspace_name)
    data = _svo_v13_read_workspace_store()
    entry = (data.get("workspaces") or {}).get(workspace_name)
    if isinstance(entry, dict):
        slot_data = entry.get(slot)
        if isinstance(slot_data, dict):
            return _svo_v12_attach_layout_reference(
                slot_data,
                _svo_v12_settings_root(),
            )
    return {}


def _svo_v13_workspace_slot_values(workspace_name: str, slot: str) -> Dict[str, Any]:
    payload = _svo_v13_workspace_slot_payload(workspace_name, slot)
    values = _svo_v12_extract_values(payload)
    return values if values else {}


def _svo_v13_load_workspace_slot_to_settings(context: bpy.types.Context, settings: bpy.types.PropertyGroup, slot: Optional[str] = None, workspace_name: Optional[str] = None, *, save_current: bool = False, apply_view: bool = True, apply_layout: bool = True, fallback_to_global: bool = True) -> bool:
    if settings is None:
        return False
    slot = _svo_v12_canonical_slot(slot or getattr(settings, "active_settings_slot", "OPTIMIZED"))
    workspace_name = _svo_v13_safe_workspace_key(workspace_name or _svo_v13_active_workspace_name(context))
    payload = _svo_v13_workspace_slot_payload(workspace_name, slot)
    values = _svo_v12_extract_values(payload)
    if not values and fallback_to_global:
        payload = _svo_v6_read_json(_svo_v12_slot_settings_path(slot)) or {}
        values = _svo_v12_extract_values(payload)
    if not values:
        preset = "BALANCED" if slot == "STANDARD" else "PERFORMANCE"
        values = dict(SVO_V6_PRESETS.get(preset, {}).get("values", {}))
        values["selected_preset"] = preset
        payload = {"values": values}
    if not values:
        return False
    _svo_v12_apply_values_to_settings(settings, values)
    _svo_v12_set_active_slot_value(settings, slot)
    try:
        settings.svo_workspace_active_name = workspace_name
    except Exception:
        pass
    if apply_view:
        ok = _svo_v12_apply_details_to_view(
            context,
            settings,
            save_current=False,
            status="Current settings applied and saved." if save_current else "Current settings applied.",
        )
        if apply_layout and _svo_v16_can_apply_view3d_layout(context):
            try:
                _svo_v14_apply_view3d_layout(context, payload.get("view3d_layout"))
            except Exception:
                pass
        if save_current:
            try:
                _svo_v12_write_current_settings_file(settings, slot, context=context)
                _svo_v13_save_workspace_slot(context, settings, slot, workspace_name)
                if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                    _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(slot), slot, context=context)
            except Exception:
                pass
        return bool(ok)
    return True


def _svo_v13_sync_active_workspace_if_needed(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    """Synchronize Detailed Settings with the visible workspace without applying them.

    This function is called from the N-panel draw path. Drawing the panel must
    never change Blender's actual viewport, overlay, region, workspace, or
    preference state. Saved workspace values are copied only into the Detailed
    Settings RNA controls. The actual viewport is updated only from explicit
    user actions such as pressing Standard / Optimized, Apply Preset, Load,
    Save, Paste, or changing a detailed property directly.
    """
    global _SVO_V13_WORKSPACE_SYNC_GUARD
    if settings is None or context is None or _SVO_V13_WORKSPACE_SYNC_GUARD:
        return
    workspace_name = _svo_v13_active_workspace_name(context)
    old_name = str(getattr(settings, "svo_workspace_active_name", "") or "").strip()
    slot = _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED"))
    try:
        now = time.monotonic()
        if old_name == workspace_name:
            return
        if (_SVO_V13_LAST_DRAW_SYNC.get("workspace") == workspace_name
                and _SVO_V13_LAST_DRAW_SYNC.get("slot") == slot
                and now - float(_SVO_V13_LAST_DRAW_SYNC.get("ts") or 0.0) < 0.75):
            return
        _SVO_V13_LAST_DRAW_SYNC["workspace"] = workspace_name
        _SVO_V13_LAST_DRAW_SYNC["slot"] = slot
        _SVO_V13_LAST_DRAW_SYNC["ts"] = now
    except Exception:
        if old_name == workspace_name:
            return
    _SVO_V13_WORKSPACE_SYNC_GUARD = True
    try:
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        if old_name and auto_save:
            _svo_v13_save_workspace_slot(context, settings, slot, old_name)
        # Draw-path synchronization must not touch the actual 3D View.
        _svo_v13_load_workspace_slot_to_settings(
            context,
            settings,
            slot,
            workspace_name,
            save_current=False,
            apply_view=False,
            fallback_to_global=True,
        )
        try:
            settings.status_text = "Workspace settings loaded into Detailed Settings. Press Standard or Optimized to apply."
        except Exception:
            pass
    except Exception:
        try:
            settings.svo_workspace_active_name = workspace_name
        except Exception:
            pass
    finally:
        _SVO_V13_WORKSPACE_SYNC_GUARD = False

def _svo_v13_selected_source_workspace(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> str:
    name = ""
    try:
        name = str(getattr(settings, "workspace_paste_source", "") or "").strip()
    except Exception:
        name = ""
    if not name:
        name = _svo_v13_active_workspace_name(context)
    return _svo_v13_safe_workspace_key(name)


def _svo_v13_copy_workspace_settings(context: bpy.types.Context, settings: bpy.types.PropertyGroup, source_name: str, destination_name: str) -> bool:
    if settings is None:
        return False
    source_name = _svo_v13_safe_workspace_key(source_name)
    destination_name = _svo_v13_safe_workspace_key(destination_name)
    data = _svo_v13_read_workspace_store()
    workspaces = data.setdefault("workspaces", {})
    src_entry = workspaces.get(source_name)
    if not isinstance(src_entry, dict) or not src_entry:
        _svo_v13_save_workspace_slot(context, settings, getattr(settings, "active_settings_slot", "OPTIMIZED"), source_name)
        data = _svo_v13_read_workspace_store()
        workspaces = data.setdefault("workspaces", {})
        src_entry = workspaces.get(source_name)
    if not isinstance(src_entry, dict) or not src_entry:
        return False
    copied: Dict[str, Any] = {}
    for slot in ("STANDARD", "OPTIMIZED"):
        slot_data = src_entry.get(slot)
        if isinstance(slot_data, dict):
            copied[slot] = dict(slot_data)
            copied[slot]["workspace"] = destination_name
    if not copied:
        return False
    workspaces[destination_name] = copied
    _svo_v13_write_workspace_store(data)
    slot = _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED"))
    return _svo_v13_load_workspace_slot_to_settings(context, settings, slot, destination_name, save_current=True, apply_view=True, fallback_to_global=True)

def _svo_v12_migrated_preset_id(value: Any) -> str:
    ident = str(value or "PERFORMANCE")
    ident = _SVO_LEGACY_PRESET_MIGRATION.get(ident, ident)
    return ident if ident in SVO_V6_PRESETS else "PERFORMANCE"

def _svo_v12_apply_values_to_settings(settings: bpy.types.PropertyGroup, values: Dict[str, Any]) -> bool:
    if settings is None or not isinstance(values, dict):
        return False
    global _SVO_V12_SETTINGS_IO_GUARD, _SVO_V10_PRESET_UPDATE_GUARD
    old_guard = _SVO_V12_SETTINGS_IO_GUARD
    old_preset_guard = _SVO_V10_PRESET_UPDATE_GUARD
    _SVO_V12_SETTINGS_IO_GUARD = True
    _SVO_V10_PRESET_UPDATE_GUARD = True
    if values.get("heavy_object_action") == "HIDE_VIEWPORT" and values.get("heavy_modifier_threshold") == 1 and values.get("target_object_display_type") == "BOUNDS":
        values = dict(values, target_object_display_type="SOLID", enable_heavy_object_culling=False, heavy_object_action="BOUNDS")
    try:
        for key, value in values.items():
            if key == "selected_preset":
                value = _svo_v12_migrated_preset_id(value)
            if hasattr(settings, key):
                try:
                    setattr(settings, key, value)
                except Exception:
                    pass
        return True
    finally:
        _SVO_V12_SETTINGS_IO_GUARD = old_guard
        _SVO_V10_PRESET_UPDATE_GUARD = old_preset_guard

def _svo_v12_apply_details_to_view(context: bpy.types.Context, settings: bpy.types.PropertyGroup, *, save_current: bool = True, status: Optional[str] = None, apply_object_targets: bool = False) -> bool:
    if context is None or settings is None:
        return False
    global _SVO_V12_LIVE_APPLY_GUARD, _SVO_V12_LAST_APPLY_TS
    if _SVO_V12_LIVE_APPLY_GUARD:
        return False
    try:
        now = time.monotonic()
        if save_current and now - float(_SVO_V12_LAST_APPLY_TS or 0.0) < 0.05:
            return False
        _SVO_V12_LAST_APPLY_TS = now
    except Exception:
        pass
    _SVO_V12_LIVE_APPLY_GUARD = True
    try:
        # No modal guard, no idle pulse, no redraw_timer, no snapshot capture.
        # Each call only writes Blender's actual current settings and tags one redraw.
        _request_navigation_guard_stop(context, restore=False)
        _svo_v6_stop_idle_warm()
        _svo_v8_stop_autosave_timer()
        # Switching to Standard gives the objects back; detail edits and presets apply their object values.
        restore_objects = not apply_object_targets and _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED")) == "STANDARD"
        restore_preferences: Dict[str, Any] = {}
        if restore_objects:
            restore_preferences = _svo_read_preference_state() or _svo_capture_preferences(context)
            _svo_restore_object_states(context)
        else:
            _svo_record_object_states(context, settings)
            if _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED")) != "STANDARD":
                _svo_record_preferences(context)
        _apply_navigation_latency(context, settings)
        _apply_scene_simplify(context, settings)
        _apply_render_preview_settings(context, settings)
        _apply_viewport_shading(context, settings)
        _apply_overlays(context, settings)
        _apply_gizmos(context, settings)
        _apply_object_filters(context, settings)
        if not restore_objects:
            _apply_object_display(context, settings)
            _apply_modifiers(context, settings)
            _apply_constraints(context, settings)
        if not restore_objects:
            try:
                _apply_selection_latency(context, settings)
            except Exception:
                pass
        _apply_particles(context, settings)
        _apply_preferences(context, settings)
        if restore_objects:
            _svo_write_preferences(context, restore_preferences)
            if _svo_read_preference_state():
                _svo_v6_atomic_json(_svo_preference_state_path(), {})
        _svo_v6_apply_deeper_view(context, settings)
        if status:
            try:
                settings.status_text = status
            except Exception:
                pass
        if save_current:
            active_slot = getattr(settings, "active_settings_slot", "OPTIMIZED")
            _svo_v12_write_current_settings_file(settings, active_slot, context=context)
            _svo_v13_save_workspace_slot(context, settings, active_slot)
            if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(active_slot), active_slot, context=context)
        _tag_view3d_redraw(context)
        return True
    except Exception:
        return False
    finally:
        _SVO_V12_LIVE_APPLY_GUARD = False

_SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = False
_SVO_V12_LIVE_UPDATE_DELAY = 0.12
_SVO_V12_LIVE_UPDATE_DEADLINE = 0.0


def _svo_v12_apply_live_update_now(settings: bpy.types.PropertyGroup, context: bpy.types.Context) -> None:
    """Apply the latest edit once after a burst of RNA changes."""
    try:
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        central_save = False
        try:
            central_save = bool(_sws_storage is not None and _sws_storage.n_panel_state_save_enabled(True))
        except Exception:
            central_save = False
        _svo_v12_apply_details_to_view(
            context,
            settings,
            save_current=bool(central_save and auto_save),
            status="Current settings applied and saved." if (central_save and auto_save) else "Current settings applied.",
            apply_object_targets=True,
        )
        # The central save switch also covers optimizer settings. Coalescing this
        # write prevents one full scene pass plus two JSON transactions per slider
        # event while preserving the final value after the user releases control.
        if central_save and not auto_save:
            try:
                active_slot = str(getattr(settings, "active_settings_slot", "OPTIMIZED") or "OPTIMIZED")
                _svo_v12_write_current_settings_file(settings, active_slot, context=context)
                _svo_v13_save_workspace_slot(context, settings, active_slot)
            except Exception:
                pass
    except Exception:
        pass


def _svo_v12_cancel_live_update_timer(*, flush_pending: bool = False) -> None:
    global _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE, _SVO_V12_LIVE_UPDATE_DEADLINE
    had_pending = bool(
        _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE
        or _SVO_V12_LIVE_UPDATE_DEADLINE > 0.0
    )
    _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = False
    _SVO_V12_LIVE_UPDATE_DEADLINE = 0.0
    try:
        if bpy.app.timers.is_registered(_svo_v12_live_update_timer):
            bpy.app.timers.unregister(_svo_v12_live_update_timer)
    except Exception:
        pass
    if flush_pending and had_pending:
        try:
            settings = _svo_runtime_settings(getattr(bpy, "context", None))
            if settings is not None:
                _svo_v12_apply_live_update_now(settings, bpy.context)
        except Exception:
            pass


def _svo_v12_live_update_timer() -> Optional[float]:
    global _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE, _SVO_V12_LIVE_UPDATE_DEADLINE
    wm = getattr(bpy.context, "window_manager", None)
    if bool(getattr(wm, "is_interface_locked", False)):
        return 0.2
    remaining = float(_SVO_V12_LIVE_UPDATE_DEADLINE or 0.0) - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    try:
        scene = getattr(bpy.context, "scene", None)
        settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
        if settings is not None:
            _svo_v12_apply_live_update_now(settings, bpy.context)
    finally:
        _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = False
        _SVO_V12_LIVE_UPDATE_DEADLINE = 0.0
    return None


def _svo_v12_live_update(settings: bpy.types.PropertyGroup, context: bpy.types.Context) -> None:
    """Debounce expensive live application without leaving an idle timer."""
    global _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE, _SVO_V12_LIVE_UPDATE_DEADLINE
    if _SVO_V12_SETTINGS_IO_GUARD or _SVO_V10_PRESET_UPDATE_GUARD:
        return
    _SVO_V12_LIVE_UPDATE_DEADLINE = time.monotonic() + _SVO_V12_LIVE_UPDATE_DELAY
    try:
        if bpy.app.timers.is_registered(_svo_v12_live_update_timer):
            _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = True
            return
        bpy.app.timers.register(
            _svo_v12_live_update_timer,
            first_interval=_SVO_V12_LIVE_UPDATE_DELAY,
            persistent=False,
        )
        _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = True
    except Exception:
        _SVO_V12_LIVE_UPDATE_TIMER_ACTIVE = False
        _SVO_V12_LIVE_UPDATE_DEADLINE = 0.0
        _svo_v12_apply_live_update_now(settings, context)

def _svo_v12_load_settings_file(context: bpy.types.Context, filepath: str, slot: str) -> bool:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    if settings is None:
        return False
    data = _svo_v6_read_json(filepath)
    if isinstance(data, dict):
        data = _svo_v12_attach_layout_reference(data, os.path.dirname(filepath))
    if not data:
        return False
    values = _svo_v12_extract_values(data)
    if not values:
        return False
    slot = "STANDARD" if str(slot).upper() == "STANDARD" else "OPTIMIZED"
    _svo_v12_apply_values_to_settings(settings, values)
    _svo_v12_set_active_slot_value(settings, slot)
    _svo_v12_apply_details_to_view(context, settings, save_current=False, status="Current settings applied and saved.")
    if _svo_v16_can_apply_view3d_layout(context):
        try:
            _svo_v14_apply_view3d_layout(context, data.get("view3d_layout"))
        except Exception:
            pass
    _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(slot), slot, context=context)
    _svo_v12_write_current_settings_file(settings, slot, context=context)
    _svo_v13_save_workspace_slot(context, settings, slot)
    return True

def _svo_v12_save_settings_slot(context: bpy.types.Context, filepath: str, slot: str) -> Optional[str]:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    if settings is None:
        return None
    slot = "STANDARD" if str(slot).upper() == "STANDARD" else "OPTIMIZED"
    # An explicit save records the view as it is now, not the burst cache of up to 1.25 s ago.
    _SVO_V14_LAYOUT_CACHE["ts"] = 0.0
    _svo_v12_set_active_slot_value(settings, slot)
    path = _svo_v12_write_settings_file(settings, filepath or _svo_v12_slot_settings_path(slot), slot, context=context)
    _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(slot), slot, context=context)
    _svo_v12_write_current_settings_file(settings, slot, context=context)
    _svo_v13_save_workspace_slot(context, settings, slot)
    _svo_v12_apply_details_to_view(context, settings, save_current=False, status="Current settings applied and saved.", apply_object_targets=True)
    return path

def _svo_v12_ensure_default_settings_files(settings: bpy.types.PropertyGroup) -> None:
    try:
        if not os.path.exists(_svo_v12_slot_settings_path("STANDARD")):
            values = dict(SVO_V6_PRESETS.get("BALANCED", {}).get("values", {}))
            old = _svo_v12_current_values(settings)
            _svo_v12_apply_values_to_settings(settings, values)
            try:
                settings.selected_preset = "BALANCED"
            except Exception:
                pass
            _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path("STANDARD"), "STANDARD")
            _svo_v12_apply_values_to_settings(settings, old)
        if not os.path.exists(_svo_v12_slot_settings_path("OPTIMIZED")):
            values = dict(SVO_V6_PRESETS.get("PERFORMANCE", {}).get("values", {}))
            old = _svo_v12_current_values(settings)
            _svo_v12_apply_values_to_settings(settings, values)
            try:
                settings.selected_preset = "PERFORMANCE"
            except Exception:
                pass
            _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path("OPTIMIZED"), "OPTIMIZED")
            _svo_v12_apply_values_to_settings(settings, old)
        if not os.path.exists(_svo_v12_current_settings_path()):
            data = _svo_v6_read_json(_svo_v12_slot_settings_path("STANDARD")) or {}
            values = _svo_v12_extract_values(data)
            _svo_v12_apply_values_to_settings(settings, values)
            _svo_v12_set_active_slot_value(settings, "STANDARD")
            _svo_v12_write_current_settings_file(settings, "STANDARD")
    except Exception:
        pass

def _svo_v12_fallback_payload(slot: str, preset_id: str) -> Dict[str, Any]:
    slot = _svo_v12_canonical_slot(slot)
    values = dict(SVO_V6_PRESETS.get(preset_id, {}).get("values", {}))
    values["selected_preset"] = preset_id if preset_id in SVO_V6_PRESETS else ("BALANCED" if slot == "STANDARD" else "PERFORMANCE")
    values["auto_save_workspace_preset_changes"] = False
    return {
        "addon": ADDON_ID,
        "version": ADDON_VERSION,
        "role": "viewport_optimizer_detail_settings",
        "slot": slot,
        "name": _svo_v12_slot_label(slot),
        "saved_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "values": values,
    }

def _svo_v12_ensure_settings_files_without_context() -> None:
    try:
        if not os.path.exists(_svo_v12_slot_settings_path("STANDARD")):
            _svo_v6_atomic_json(_svo_v12_slot_settings_path("STANDARD"), _svo_v12_fallback_payload("STANDARD", "BALANCED"))
        if not os.path.exists(_svo_v12_slot_settings_path("OPTIMIZED")):
            _svo_v6_atomic_json(_svo_v12_slot_settings_path("OPTIMIZED"), _svo_v12_fallback_payload("OPTIMIZED", "PERFORMANCE"))
        if not os.path.exists(_svo_v12_current_settings_path()):
            data = _svo_v6_read_json(_svo_v12_slot_settings_path("STANDARD")) or _svo_v12_fallback_payload("STANDARD", "BALANCED")
            _svo_v6_atomic_json(_svo_v12_current_settings_path(), data)
    except Exception:
        pass

def _svo_v12_load_slot_to_settings(context: bpy.types.Context, settings: bpy.types.PropertyGroup, slot: str, *, save_current: bool) -> bool:
    if settings is None:
        return False
    slot = _svo_v12_canonical_slot(slot)
    _svo_v12_ensure_settings_files_without_context()
    slot_path = _svo_v12_slot_settings_path(slot)
    data = _svo_v6_read_json(slot_path) or {}
    data = _svo_v12_attach_layout_reference(data, os.path.dirname(slot_path))
    values = _svo_v12_extract_values(data)
    if not values:
        return False
    _svo_v12_apply_values_to_settings(settings, values)
    _svo_v12_set_active_slot_value(settings, slot)
    ok = _svo_v12_apply_details_to_view(
        context, settings, save_current=False,
        status="Current settings applied and saved." if save_current else "Current settings applied."
    )
    if _svo_v16_can_apply_view3d_layout(context):
        try:
            _svo_v14_apply_view3d_layout(context, data.get("view3d_layout"))
        except Exception:
            pass
    if save_current:
        try:
            _svo_v12_write_current_settings_file(settings, slot, context=context)
            _svo_v13_save_workspace_slot(context, settings, slot)
            if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(slot), slot, context=context)
        except Exception:
            pass
    return bool(ok)

def _svo_v12_active_slot_update(settings: bpy.types.PropertyGroup, context: bpy.types.Context) -> None:
    if _SVO_V12_SETTINGS_IO_GUARD or _SVO_V10_PRESET_UPDATE_GUARD:
        return
    try:
        slot = _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED"))
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        central_save = bool(_sws_storage is not None and _sws_storage.n_panel_state_save_enabled(True))
        _svo_v13_load_workspace_slot_to_settings(context, settings, slot, _svo_v13_active_workspace_name(context), save_current=bool(auto_save and central_save), apply_view=True, fallback_to_global=True)
    except Exception:
        pass

def _svo_v12_load_current_settings_if_available(context: bpy.types.Context) -> bool:
    """Crash-safe restore used by persistence load/startup handlers.

    This function runs from Blender's file-read/startup callback path. It must
    never restore saved UI layout, toggle Sidebar regions, enter context
    overrides, change workspace, or call operators.  Any stale OPTIMIZED current
    file is normalized to STANDARD, then Blender's actually-open state is read
    into Detailed Settings like the manual "Load Current View Settings" action.
    """
    _svo_v12_ensure_settings_files_without_context()
    scene = getattr(context, "scene", None) if context is not None else None
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    if settings is None:
        return False
    _svo_v12_ensure_default_settings_files(settings)
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        ok = _svo_v15_sync_standard_details_from_current_view(
            context,
            settings,
            save_like_manual=False,
            status="Current View Settings loaded into Detailed Settings without applying changes to Blender.",
        )
        try:
            _svo_v12_write_current_settings_file(
                settings,
                "STANDARD",
                context=context,
                include_layout=False,
            )
            _svo_v13_save_workspace_slot(
                context,
                settings,
                "STANDARD",
                include_layout=False,
            )
        except Exception:
            pass
        return bool(ok)
    except Exception:
        return False
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)


def _svo_v6_scene_key() -> str:
    name = os.path.basename(getattr(bpy.data, "filepath", "") or "unsaved") or "unsaved"
    raw = f"{name}|{time.time()}".encode("utf-8", "replace")
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)[:40] + "_" + hashlib.sha1(raw).hexdigest()[:8]

def _svo_v6_build_external_snapshot(context: bpy.types.Context, reason: str) -> Dict[str, Any]:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    old_json = getattr(scene, "smart_viewport_optimizer_snapshot_json", "") if scene else ""
    old_scope = getattr(settings, "object_scope", None) if settings else None
    old_apply_all = getattr(settings, "apply_all_scenes", None) if settings else None
    try:
        _svo_v8_suspend_autosave(1.0)
        if settings:
            settings.object_scope = "ALL"
            settings.apply_all_scenes = True
        _capture_snapshot(context, force=True)
        data = json.loads(scene.smart_viewport_optimizer_snapshot_json) if scene else {}
    finally:
        if scene is not None:
            try: scene.smart_viewport_optimizer_snapshot_json = old_json
            except Exception: pass
        if settings:
            try:
                if old_scope is not None: settings.object_scope = old_scope
                if old_apply_all is not None: settings.apply_all_scenes = old_apply_all
            except Exception: pass
    data["external_backup"] = True
    data["reason"] = reason
    data["created_at"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    data["blend_file"] = getattr(bpy.data, "filepath", "") or ""
    return data

def _svo_v6_backup_paths(kind: str) -> Tuple[str, str]:
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    return (os.path.join(_svo_v6_backup_root(), f"{stamp}_{kind}_{_svo_v6_scene_key()}.json"),
            os.path.join(_svo_v6_backup_root(), f"latest_{kind}.json"))

def _svo_v6_prune_backups(settings: bpy.types.PropertyGroup) -> None:
    if not getattr(settings, "keep_backup_history", True):
        return
    try:
        files = [os.path.join(_svo_v6_backup_root(), f) for f in os.listdir(_svo_v6_backup_root()) if f.endswith(".json") and not f.startswith("latest_")]
        files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        for path in files[int(getattr(settings, "max_backup_files", 120)):]:
            try: os.remove(path)
            except Exception: pass
    except Exception:
        pass

def _svo_v6_capture_external_backup(context: bpy.types.Context, kind: str = "manual") -> Optional[str]:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    try:
        history_path, latest_path = _svo_v6_backup_paths(kind)
        if kind == "install" and os.path.exists(latest_path):
            return latest_path
        data = _svo_v6_build_external_snapshot(context, kind)
        _svo_v6_atomic_json(latest_path, data)
        if settings is None or getattr(settings, "keep_backup_history", True):
            _svo_v6_atomic_json(history_path, data)
        if settings is not None:
            _svo_v6_prune_backups(settings)
        return latest_path
    except Exception:
        return None

def _svo_v6_latest_backup_path(kind: str) -> Optional[str]:
    root = _svo_v6_backup_root()
    if kind != "last_any":
        p = os.path.join(root, f"latest_{kind}.json")
        return p if os.path.exists(p) else None
    try:
        files = [os.path.join(root, f) for f in os.listdir(root) if f.endswith(".json")]
        files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        return files[0] if files else None
    except Exception:
        return None

def _svo_v6_restore_external_backup(context: bpy.types.Context, kind: str) -> bool:
    scene = getattr(context, "scene", None)
    path = _svo_v6_latest_backup_path(kind)
    if scene is None or not path:
        return False
    data = _svo_v6_read_json(path)
    if not data:
        return False
    old = scene.smart_viewport_optimizer_snapshot_json
    try:
        scene.smart_viewport_optimizer_snapshot_json = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        return _restore_snapshot(context)
    finally:
        try: scene.smart_viewport_optimizer_snapshot_json = old
        except Exception: pass

def _svo_v6_custom_presets() -> List[Tuple[str, str, str]]:
    out: List[Tuple[str, str, str]] = []
    try:
        for file in sorted(os.listdir(_svo_v6_preset_root())):
            if not file.endswith(".json"):
                continue
            data = _svo_v6_read_json(os.path.join(_svo_v6_preset_root(), file)) or {}
            label = data.get("name") or os.path.splitext(file)[0]
            desc = data.get("description") or "User-saved optimizer preset. Expected effect depends on the saved settings."
            out.append(("CUSTOM::" + os.path.splitext(file)[0], label, desc))
    except Exception:
        pass
    return out

def _svo_v6_preset_items(self, context):
    global _PRESET_ENUM_CACHE
    # Built-in presets are intentionally limited to the three requested modes.
    # Custom/user-saved presets are no longer exposed through this selector.
    items = [(key, iface(data["name"]), iface(data["effect"])) for key, data in SVO_V6_PRESETS.items()]
    _PRESET_ENUM_CACHE = items
    return _PRESET_ENUM_CACHE

def _svo_v6_preset_values(identifier: str, use_user_override: bool = True) -> Optional[Dict[str, Any]]:
    identifier = _SVO_LEGACY_PRESET_MIGRATION.get(identifier, identifier)
    if identifier in SVO_V6_PRESETS:
        values = dict(MAX_SPEED_DEFAULTS)
        values.update(SVO_V6_PRESETS[identifier].get("values", {}))
        if use_user_override:
            values.update(_svo_v8_load_builtin_override(identifier))
        values["selected_preset"] = identifier
        return values
    return None

def _svo_v6_apply_preset_to_settings(settings: bpy.types.PropertyGroup, identifier: str, use_user_override: bool = True, mark_active: bool = True) -> bool:
    values = _svo_v6_preset_values(identifier, use_user_override=use_user_override)
    if not values:
        return False
    _svo_v8_suspend_autosave(1.5)
    preset_apply_skip = {
        "auto_save_workspace_preset_changes", "active_settings_slot", "optimizer_active",
        "keymap_operator_id", "custom_preset_name", "backup_restore_kind",
    }
    global _SVO_V12_SETTINGS_IO_GUARD, _SVO_V10_PRESET_UPDATE_GUARD
    old_guard = _SVO_V12_SETTINGS_IO_GUARD
    old_preset_guard = _SVO_V10_PRESET_UPDATE_GUARD
    _SVO_V12_SETTINGS_IO_GUARD = True
    _SVO_V10_PRESET_UPDATE_GUARD = True
    try:
        for key, value in values.items():
            if key in preset_apply_skip:
                continue
            if hasattr(settings, key):
                try:
                    setattr(settings, key, value)
                except Exception:
                    pass
    finally:
        _SVO_V12_SETTINGS_IO_GUARD = old_guard
        _SVO_V10_PRESET_UPDATE_GUARD = old_preset_guard
    if mark_active:
        _svo_v8_mark_preset_baseline(settings, identifier if identifier in SVO_V6_PRESETS else "")
    return True

def _svo_v6_safe_preset_file(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", (name or "Custom Preset").strip())[:80] or "Custom_Preset"

def _svo_v6_object_vertex_count(obj: bpy.types.Object) -> int:
    data = getattr(obj, "data", None)
    verts = getattr(data, "vertices", None)
    try: return len(verts)
    except Exception: return 0

def _svo_v6_is_heavy_object(obj: bpy.types.Object, settings: bpy.types.PropertyGroup) -> bool:
    return (_svo_v6_object_vertex_count(obj) >= int(settings.heavy_vertex_threshold)
            or len(getattr(obj, "modifiers", [])) >= int(settings.heavy_modifier_threshold)
            or len(getattr(obj, "particle_systems", [])) >= int(settings.heavy_particle_threshold))

def _svo_v6_apply_heavy_action(context: bpy.types.Context, obj: bpy.types.Object, settings: bpy.types.PropertyGroup) -> None:
    action = settings.heavy_object_action
    if action == "HIDE_VIEWPORT":
        if not _svo_is_work_object(context, obj): _safe_set(obj, "hide_viewport", True)
    elif action in {"BOUNDS", "WIRE"}:
        if _svo_object_draws_without_overlays(settings, action): _safe_set(obj, "display_type", action)
    elif action == "HIDE_SELECT": _safe_set(obj, "hide_select", True)

def _svo_v6_apply_deeper_view(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    selected = {obj.name for obj in getattr(context, "selected_objects", [])}
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        if getattr(settings, "force_orthographic_view", False):
            rv3d = getattr(space, "region_3d", None)
            if rv3d: _safe_set(rv3d, "view_perspective", "ORTHO")
        if getattr(settings, "clear_view3d_locks", True):
            _safe_set_any(space, ("lock_camera", "lock_cursor", "lock_bone"), False)
            _safe_set(space, "lock_object", None)
        if getattr(settings, "hide_meshes_filter", False):
            _safe_set(space, "show_object_viewport_mesh", False)
        if getattr(settings, "disable_object_type_selection_filters", True):
            _safe_set_any(space, (
                "show_object_select_camera", "show_object_select_light", "show_object_select_empty", "show_object_select_armature",
                "show_object_select_curve", "show_object_select_surface", "show_object_select_font", "show_object_select_metaball",
                "show_object_select_lattice", "show_object_select_speaker", "show_object_select_light_probe", "show_object_select_volume",
                "show_object_select_grease_pencil", "show_object_select_pointcloud"), False)
        if getattr(settings, "disable_mesh_selection_filter", True):
            _safe_set(space, "show_object_select_mesh", False)
    if getattr(settings, "include_object_display", True):
        for obj in _target_objects(context, settings):
            if getattr(settings, "hide_unselected_objects", False) and selected and obj.name not in selected:
                _safe_set(obj, "hide_viewport", True)
            if getattr(settings, "force_bounds_type_box", True):
                _safe_set(obj, "display_bounds_type", "BOX")
            if getattr(settings, "pause_object_simulation_cache", True):
                _safe_set(obj, "use_simulation_cache", False)
            if getattr(settings, "enable_heavy_object_culling", True) and _svo_v6_is_heavy_object(obj, settings):
                _svo_v6_apply_heavy_action(context, obj, settings)

def _svo_v6_apply_system_deep(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    prefs = getattr(context, "preferences", None)
    system = getattr(prefs, "system", None)
    if system is not None:
        if getattr(settings, "set_shader_compilation_threaded", True): _safe_set(system, "shader_compilation_method", "THREAD")
        _safe_set(system, "gpu_shader_workers", int(getattr(settings, "gpu_shader_workers", 0)))
        if getattr(settings, "set_memory_cache_limit", False): _safe_set(system, "memory_cache_limit", int(settings.memory_cache_limit_mb))
        if getattr(settings, "disable_region_overlap", True): _safe_set(system, "use_region_overlap", False)
    view = getattr(prefs, "view", None)
    if view is not None:
        if getattr(settings, "enable_reduce_motion", True): _safe_set(view, "use_reduce_motion", True)
        if getattr(settings, "reduce_ui_status_draw", True):
            _safe_set_any(view, ("show_statusbar_stats", "show_statusbar_memory", "show_statusbar_vram", "show_statusbar_version"), False)
    inputs = getattr(prefs, "inputs", None)
    if inputs is not None:
        if getattr(settings, "simplify_navigation_method", True):
            _safe_set(inputs, "view_rotate_method", settings.view_rotate_method)
            _safe_set(inputs, "view_zoom_method", settings.view_zoom_method)
            _safe_set(inputs, "view_zoom_axis", settings.view_zoom_axis)
        if getattr(settings, "disable_ndof_guides", True):
            _safe_set_any(inputs, ("show_nDOF_settings", "show_ndof_settings", "use_ndof_orbit", "use_ndof_pan", "use_ndof_zoom"), False)
    if getattr(settings, "disable_snapping_automerge", True):
        for scn in _target_scenes(context, settings):
            tool_settings = getattr(scn, "tool_settings", None)
            if tool_settings is not None:
                _safe_set(tool_settings, "use_snap", False)
                _safe_set(tool_settings, "use_mesh_automerge", False)

def _svo_v6_prewarm_view_matrix(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not getattr(settings, "prewarm_view_matrix_nudge", False):
        return
    try:
        from mathutils import Vector
    except Exception:
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        rv3d = getattr(space, "region_3d", None)
        if rv3d is None or not hasattr(rv3d, "view_location"):
            continue
        try:
            loc = rv3d.view_location.copy()
            rv3d.view_location = loc + Vector((0.000001, 0.0, 0.0))
            rv3d.view_location = loc
        except Exception:
            pass

def _svo_v6_idle_pulse_timer() -> Optional[float]:
    global _IDLE_PULSE_RUNNING
    scene = getattr(bpy.context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    if (
        not _IDLE_PULSE_RUNTIME_ALLOWED
        or not settings
        or not getattr(settings, "enable_idle_warm_pulse", False)
    ):
        _IDLE_PULSE_RUNNING = False
        return None
    try:
        if getattr(settings, "idle_pulse_view_layer_update", False) and getattr(bpy.context, "view_layer", None):
            bpy.context.view_layer.update()
        _svo_v6_prewarm_view_matrix(bpy.context, settings)
        _tag_view3d_redraw(bpy.context)
        # Crash-safe: never call wm.redraw_timer from timers.  Blender 5.1 can
        # enter header drawing while handlers/timers are active; tag redraw only.
        _ = max(0, min(int(getattr(settings, "idle_pulse_redraw_iterations", 0)), 2))
    except Exception:
        pass
    return max(0.1, float(getattr(settings, "idle_warm_pulse_interval", 0.8)))

def _svo_v6_ensure_idle_warm(context: bpy.types.Context) -> None:
    global _IDLE_PULSE_RUNNING
    settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
    if (
        not _IDLE_PULSE_RUNTIME_ALLOWED
        or not settings
        or not getattr(settings, "enable_idle_warm_pulse", False)
        or _IDLE_PULSE_RUNNING
    ):
        return
    try:
        bpy.app.timers.register(_svo_v6_idle_pulse_timer, first_interval=max(0.1, float(settings.idle_warm_pulse_interval)))
        _IDLE_PULSE_RUNNING = True
    except Exception:
        pass

def _svo_v6_stop_idle_warm() -> None:
    global _IDLE_PULSE_RUNNING
    _IDLE_PULSE_RUNNING = False
    try:
        if bpy.app.timers.is_registered(_svo_v6_idle_pulse_timer):
            bpy.app.timers.unregister(_svo_v6_idle_pulse_timer)
    except Exception:
        pass


def _svo_runtime_settings(context=None):
    ctx = context or getattr(bpy, "context", None)
    scene = getattr(ctx, "scene", None) if ctx is not None else None
    return getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None


def _svo_set_runtime_bool(settings, prop_name: str, enabled: bool) -> bool:
    if settings is None or not hasattr(settings, prop_name):
        return False
    global _SVO_V12_SETTINGS_IO_GUARD
    old_guard = _SVO_V12_SETTINGS_IO_GUARD
    _SVO_V12_SETTINGS_IO_GUARD = True
    try:
        setattr(settings, prop_name, bool(enabled))
        return bool(getattr(settings, prop_name, False)) == bool(enabled)
    except Exception:
        return False
    finally:
        _SVO_V12_SETTINGS_IO_GUARD = old_guard


def set_preset_autosave_runtime_enabled(enabled: bool, context=None) -> bool:
    """Set event-driven preset saving; no polling timer is kept alive."""
    settings = _svo_runtime_settings(context)
    ok = _svo_set_runtime_bool(settings, "auto_save_workspace_preset_changes", enabled)
    # Property updates already schedule one coalesced save. The legacy one-second
    # signature polling timer is unnecessary and must remain absent in both states.
    _svo_v8_stop_autosave_timer()
    return bool(ok or (not enabled and settings is None))


def set_idle_warm_pulse_runtime_enabled(enabled: bool, context=None) -> bool:
    """Own the only continuous optimizer timer from the central toggle UI."""
    global _IDLE_PULSE_RUNTIME_ALLOWED
    ctx = context or getattr(bpy, "context", None)
    settings = _svo_runtime_settings(ctx)
    ok = _svo_set_runtime_bool(settings, "enable_idle_warm_pulse", enabled)
    _IDLE_PULSE_RUNTIME_ALLOWED = bool(enabled and ok)
    if enabled and ok:
        _svo_v6_ensure_idle_warm(ctx)
    else:
        _svo_v6_stop_idle_warm()
    return bool(ok or (not enabled and settings is None))


def stop_continuous_runtime(*, flush_pending: bool = False) -> bool:
    """Remove every optimizer-owned idle resource without changing settings."""
    global _IDLE_PULSE_RUNTIME_ALLOWED
    _IDLE_PULSE_RUNTIME_ALLOWED = False
    _svo_v12_cancel_live_update_timer(flush_pending=flush_pending)
    _svo_v8_stop_autosave_timer()
    _svo_v6_stop_idle_warm()
    try:
        _request_navigation_guard_stop(getattr(bpy, "context", None), restore=False)
    except Exception:
        pass
    return True

_SVO_V10_PRESET_UPDATE_GUARD = False


def _svo_v10_selected_preset_update(settings: bpy.types.PropertyGroup, context: bpy.types.Context) -> None:
    """Keep preset selection passive.

    The preset selector is now only a source selector. It must not save, load,
    apply, rebuild optimization, or touch the viewport until the user presses
    the dedicated Apply Preset button.
    """
    global _SVO_V10_PRESET_UPDATE_GUARD
    if _SVO_V10_PRESET_UPDATE_GUARD:
        return
    ident = getattr(settings, "selected_preset", "") or "PERFORMANCE"
    if ident in _SVO_LEGACY_PRESET_MIGRATION:
        ident = _SVO_LEGACY_PRESET_MIGRATION.get(ident, "PERFORMANCE")
    if ident not in SVO_V6_PRESETS:
        ident = "PERFORMANCE"
    if getattr(settings, "selected_preset", "") != ident:
        try:
            _SVO_V10_PRESET_UPDATE_GUARD = True
            settings.selected_preset = ident
        except Exception:
            pass
        finally:
            _SVO_V10_PRESET_UPDATE_GUARD = False
    try:
        settings.status_text = "Preset selected. Press Apply Preset to copy it into Detailed Settings."
    except Exception:
        pass

def _svo_v6_define_properties() -> None:
    ann = SVO_PLUS_PG_settings.__annotations__
    ann["show_presets"] = bpy.props.BoolProperty(default=True, options={"SKIP_SAVE"})
    ann["show_backup"] = bpy.props.BoolProperty(default=True, options={"SKIP_SAVE"})
    ann["selected_preset"] = bpy.props.EnumProperty(name="Setting Load", description="Choose Performance, Balanced, or Quality. The selection only changes Detailed Settings after pressing Apply Preset.", items=_svo_v6_preset_items, update=_svo_v10_selected_preset_update)
    ann["auto_save_active_preset"] = bpy.props.StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})
    ann["custom_preset_name"] = bpy.props.StringProperty(name="Custom preset name", description="Name used when saving the current individual ON/OFF options as a custom preset.", default=MAX_SPEED_DEFAULTS["custom_preset_name"])
    ann["backup_restore_kind"] = bpy.props.EnumProperty(name="Backup to restore", description="Choose which external JSON backup is restored. Use Latest Any when you are unsure.", items=(("last_any", "Latest Any", "Restore the newest external backup of any kind."), ("before_apply", "Latest Before Apply", "Restore the latest backup captured immediately before optimization."), ("startup", "Startup Backup", "Restore the latest startup backup."), ("install", "Install Baseline", "Restore the first add-on registration baseline backup."), ("file_load", "File Load Backup", "Restore the latest file-load backup."), ("manual", "Manual Backup", "Restore the latest manual backup.")), default="last_any")
    ann["optimizer_active"] = bpy.props.BoolProperty(name="Optimizer Toggle", description="Turn ON temporary viewport optimization using the selected preset and current detailed settings. ON is blocked until a baseline state has been saved or loaded; turning OFF restores the maintained baseline state.", default=False, options={"SKIP_SAVE"})
    ann["restore_before_file_events"] = bpy.props.BoolProperty(name="Auto restore on file open/close", description="Before loading another file, saving, quitting, or disabling the add-on, restore the maintained baseline state when the optimizer is ON. Keep this enabled to avoid saving or leaving Blender in an optimized state.", default=True)
    ann["reapply_after_save_if_active"] = bpy.props.BoolProperty(name="Re-apply after save when ON", description="When a save starts while the optimizer is ON, the add-on restores the maintained baseline state for the saved file, then re-applies the temporary optimization after saving so the current session remains responsive.", default=True)
    ann["keymap_operator_id"] = bpy.props.StringProperty(name="Keymap operator ID", description="Copyable operator ID for Blender Keymap registration. Recommended location: Preferences > Keymap > 3D View > 3D View (Global).", default="view3d.svo_plus_toggle_optimizer", options={"SKIP_SAVE"})
    bools = {
        "external_backup_on_register": ("Backup at add-on registration", "Save a baseline JSON backup outside the .blend file as soon as the add-on registers. This protects the original state before automatic optimization can run."),
        "external_backup_on_startup": ("Backup at Blender startup", "Save a startup JSON backup outside the .blend file after Blender initializes this add-on. Keep this on for maximum repair safety."),
        "external_backup_before_apply": ("Backup before every apply", "Save an external JSON backup immediately before every optimization apply. This is the main repair path if a setting does not return as expected."),
        "external_backup_on_file_load": ("Backup on file load", "Save an external JSON backup when a .blend file is loaded, before automatic file-load optimization runs."),
        "keep_backup_history": ("Keep backup history", "Keep timestamped backup files in addition to latest repair files. Turn off only when disk space is more important than rollback choices."),
        "restore_before_file_events": ("Auto restore on file open/close", "Before loading another file, saving, quitting, or disabling the add-on, restore the baseline captured before the optimizer was turned ON. Keep this enabled to avoid saving or leaving Blender in an optimized state."),
        "reapply_after_save_if_active": ("Re-apply after save when ON", "When a save starts while the optimizer is ON, the add-on restores the original state for the saved file, then re-applies the temporary optimization after saving so the current session remains responsive."),
        "force_orthographic_view": ("Force orthographic view", "Switch visible 3D Views to Orthographic. This can remove perspective transition cost but changes navigation feel."),
        "clear_view3d_locks": ("Clear view locks", "Clear common 3D View locks such as camera, cursor, bone, and object locks. Locks can add state checks during navigation."),
        "hide_meshes_filter": ("Hide mesh objects", "Hide mesh objects through 3D View filters. This is extreme and intended for rescue presets when a file is almost unusable."),
        "disable_object_type_selection_filters": ("Disable object-type selection filters", "Disable object-type selection filters in the 3D View where Blender exposes them. This reduces hit-testing during navigation-only mode."),
        "disable_mesh_selection_filter": ("Disable mesh selection filter", "Disable mesh selection in the 3D View object filter. This is aggressive and best for navigation-only playback or inspection."),
        "hide_unselected_objects": ("Hide unselected objects", "Hide unselected objects. This strongly reduces visible scene cost for focused work, and can be restored from the backup snapshot."),
        "force_bounds_type_box": ("Force bounds type box", "Use box bounds for objects where supported. Box bounds are the cheapest rescue display."),
        "pause_object_simulation_cache": ("Pause object simulation cache", "Disable per-object simulation cache usage where exposed. This can reduce simulation bookkeeping during viewport movement."),
        "enable_heavy_object_culling": ("Cull heavy objects", "Detect objects above vertex, modifier, or particle thresholds and apply the selected heavy-object action."),
        "set_shader_compilation_threaded": ("Use threaded shader compilation", "Use threaded shader compilation when available. This can reduce UI blocking from shader compilation."),
        "set_memory_cache_limit": ("Set memory cache limit", "Set Blender's memory cache limit for this session. Use only when memory pressure is suspected."),
        "disable_region_overlap": ("Disable region overlap", "Disable region overlap where available. This can reduce UI compositing work around panels."),
        "reduce_ui_status_draw": ("Reduce status bar drawing", "Hide several status-bar information fields where available. Reduces small but constant UI redraw work."),
        "enable_reduce_motion": ("Enable reduce motion", "Enable reduced motion in preferences where available. This avoids unnecessary interface animation."),
        "simplify_navigation_method": ("Simplify navigation method", "Use simpler navigation methods such as Turntable rotation and Scale zoom where available."),
        "disable_ndof_guides": ("Disable NDOF guides", "Disable 3D mouse guide and helper options where available."),
        "disable_snapping_automerge": ("Disable snapping and auto-merge", "Disable snapping and mesh auto-merge in tool settings where available. Helps avoid edit-tool bookkeeping."),
        "prewarm_view_matrix_nudge": ("Prewarm view matrix nudge", "Slightly nudge and restore the view matrix during prewarm. This can force lazy view data to refresh before manual navigation."),
        "enable_idle_warm_pulse": ("Enable idle warm pulse", "Keep a low-frequency timer active to prevent viewport data from going cold between navigation attempts."),
        "idle_pulse_view_layer_update": ("Update view layer in idle pulse", "Also update the view layer during idle pulse. Stronger but may add idle CPU use; keep off unless needed."),
        "auto_save_workspace_preset_changes": ("Auto-save preset setting changes", "Automatically save manual ON/OFF and numeric setting changes for the selected preset to the preset override JSON file. The file name is generated from the preset ID so the setting is maintained across Blender sessions."),
    }
    for key, (name, desc) in bools.items():
        ann[key] = bpy.props.BoolProperty(name=name, description=desc, default=bool(MAX_SPEED_DEFAULTS[key]))
    ann["max_backup_files"] = bpy.props.IntProperty(name="Max backup files", description="Maximum number of timestamped external backup files to keep. Latest repair files are kept separately.", default=MAX_SPEED_DEFAULTS["max_backup_files"], min=1, max=999)
    ann["gpu_shader_workers"] = bpy.props.IntProperty(name="GPU shader workers", description="GPU shader worker count when exposed. Zero lets Blender choose automatically.", default=MAX_SPEED_DEFAULTS["gpu_shader_workers"], min=0, max=64)
    ann["memory_cache_limit_mb"] = bpy.props.IntProperty(name="Memory cache limit MB", description="Memory cache limit in megabytes when Set memory cache limit is enabled.", default=MAX_SPEED_DEFAULTS["memory_cache_limit_mb"], min=0, max=131072)
    ann["heavy_vertex_threshold"] = bpy.props.IntProperty(name="Heavy vertex threshold", description="Objects with at least this many vertices are treated as heavy.", default=MAX_SPEED_DEFAULTS["heavy_vertex_threshold"], min=1, max=100000000)
    ann["heavy_modifier_threshold"] = bpy.props.IntProperty(name="Heavy modifier threshold", description="Objects with at least this many modifiers are treated as heavy.", default=MAX_SPEED_DEFAULTS["heavy_modifier_threshold"], min=0, max=1024)
    ann["heavy_particle_threshold"] = bpy.props.IntProperty(name="Heavy particle threshold", description="Objects with at least this many particle systems are treated as heavy.", default=MAX_SPEED_DEFAULTS["heavy_particle_threshold"], min=0, max=1024)
    ann["idle_pulse_redraw_iterations"] = bpy.props.IntProperty(name="Idle pulse redraw iterations", description="Redraw iterations used by idle pulse. Keep zero unless idle prewarm must be stronger.", default=MAX_SPEED_DEFAULTS["idle_pulse_redraw_iterations"], min=0, max=2)
    ann["idle_warm_pulse_interval"] = bpy.props.FloatProperty(name="Idle pulse interval", description="Seconds between idle warm pulses. Lower values reduce cold starts more strongly but add idle work.", default=MAX_SPEED_DEFAULTS["idle_warm_pulse_interval"], min=0.1, max=60.0, unit="TIME")
    ann["heavy_object_action"] = bpy.props.EnumProperty(name="Heavy object action", description="Action applied to detected heavy objects. Hide Viewport is strongest; Bounds and Wire are safer.", items=(("HIDE_VIEWPORT", "Hide Viewport", "Hide heavy objects in the viewport."), ("BOUNDS", "Bounds", "Show heavy objects as bounding boxes."), ("WIRE", "Wire", "Show heavy objects as wire."), ("HIDE_SELECT", "Disable Selection", "Make heavy objects unselectable.")), default=MAX_SPEED_DEFAULTS["heavy_object_action"])
    ann["view_rotate_method"] = bpy.props.EnumProperty(name="View rotate method", description="Rotation method used when simplifying navigation.", items=(("TURNTABLE", "Turntable", "Predictable turntable rotation."), ("TRACKBALL", "Trackball", "Trackball rotation.")), default=MAX_SPEED_DEFAULTS["view_rotate_method"])
    ann["view_zoom_method"] = bpy.props.EnumProperty(name="View zoom method", description="Zoom method used when simplifying navigation.", items=(("SCALE", "Scale", "Scale zoom."), ("DOLLY", "Dolly", "Dolly zoom."), ("CONTINUE", "Continue", "Continuous zoom.")), default=MAX_SPEED_DEFAULTS["view_zoom_method"])
    ann["view_zoom_axis"] = bpy.props.EnumProperty(name="View zoom axis", description="Zoom input axis used when simplifying navigation.", items=(("VERTICAL", "Vertical", "Vertical input."), ("HORIZONTAL", "Horizontal", "Horizontal input.")), default=MAX_SPEED_DEFAULTS["view_zoom_axis"])

_svo_v6_define_properties()

# -----------------------------------------------------------------------------
# Navigation prewarm guard
# -----------------------------------------------------------------------------

_NAV_GUARD_SHOULD_RUN = False
_NAV_GUARD_RUNNING = False
_NAV_GUARD_TIMER = None
_NAV_GUARD_LAST_PREWARM = 0.0
_NAV_GUARD_LAST_NAV = 0.0
_NAVIGATION_EVENTS = {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN", "TRACKPADZOOM", "NDOF_MOTION"}


def _request_navigation_guard_stop(context: bpy.types.Context, restore: bool = False) -> None:
    global _NAV_GUARD_SHOULD_RUN
    _NAV_GUARD_SHOULD_RUN = False
    if restore:
        try:
            _restore_snapshot(context)
        except Exception:
            pass


def _ensure_navigation_guard(context: bpy.types.Context, *, manual: bool = False) -> None:
    global _NAV_GUARD_SHOULD_RUN, _NAV_GUARD_RUNNING
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    settings = scene.smart_viewport_optimizer_settings
    # The setting controls the automatic start only; the Start operator is an
    # explicit request and must not be silently dropped by it.
    if not manual and not getattr(settings, "enable_navigation_guard", False):
        return
    try:
        if bpy.app.background:
            return
    except Exception:
        pass
    if _NAV_GUARD_RUNNING:
        _NAV_GUARD_SHOULD_RUN = True
        return
    _NAV_GUARD_SHOULD_RUN = True
    try:
        bpy.ops.view3d.svo_plus_navigation_guard("INVOKE_DEFAULT")
    except Exception:
        pass



# -----------------------------------------------------------------------------
# v9 temporary toggle mode and file-event safety
# -----------------------------------------------------------------------------

_SVO_V9_SAVE_REAPPLY_PENDING = False
_SVO_V9_SAVE_SNAPSHOT_JSON = ""
_SVO_V9_FILE_EVENT_RESTORE_RUNNING = False
_SVO_V9_REAPPLY_RUNNING = False


def _svo_v9_settings(context: bpy.types.Context) -> Optional[bpy.types.PropertyGroup]:
    scene = getattr(context, "scene", None)
    return getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None


def _svo_v9_is_active(context: bpy.types.Context) -> bool:
    settings = _svo_v9_settings(context)
    return bool(settings and getattr(settings, "optimizer_active", False))


def _svo_v9_set_active(settings: Optional[bpy.types.PropertyGroup], value: bool) -> None:
    if settings is None:
        return
    try:
        settings.optimizer_active = bool(value)
    except Exception:
        pass


def _svo_v9_clear_session_snapshot(context: bpy.types.Context) -> None:
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    try:
        scene.smart_viewport_optimizer_snapshot_json = ""
    except Exception:
        pass


def _svo_v9_activate_optimizer(context: bpy.types.Context, *, report: bool = False) -> bool:
    scene = getattr(context, "scene", None)
    settings = _svo_v9_settings(context)
    if scene is None or settings is None:
        return False
    global _SVO_V9_REAPPLY_RUNNING
    if getattr(settings, "optimizer_active", False):
        return True
    baseline_ready, baseline_message = _svo_v10_baseline_state_status()
    if not baseline_ready:
        try:
            settings.status_text = baseline_message
        except Exception:
            pass
        return False
    _svo_v8_suspend_autosave(1.0)
    try:
        if getattr(settings, "external_backup_before_apply", True):
            _svo_v6_capture_external_backup(context, "before_apply")
    except Exception:
        pass
    if not _svo_v10_prepare_session_restore_from_baseline(context):
        try:
            settings.status_text = "Invalid baseline state file. Save current settings as a baseline or load a valid baseline state before turning optimization ON."
        except Exception:
            pass
        return False
    _svo_v9_set_active(settings, True)
    try:
        _SVO_V9_REAPPLY_RUNNING = True
        apply_optimizer(context, capture_snapshot=False, allow_ui_warm=True, allow_guard=True)
    finally:
        _SVO_V9_REAPPLY_RUNNING = False
    try:
        settings.status_text = "Optimization is ON"
    except Exception:
        pass
    return True


def _svo_v9_deactivate_optimizer(context: bpy.types.Context, *, clear_snapshot: bool = True, reason: str = "manual") -> bool:
    settings = _svo_v9_settings(context)
    if settings is None:
        return False
    restored = False
    try:
        restored = _restore_snapshot(context)
    except Exception:
        restored = False
    if not restored:
        # Safety fallback: restore the maintained external baseline directly if
        # the in-memory session restore snapshot was cleared or damaged.
        try:
            restored = _svo_v10_restore_stored_baseline(context)
        except Exception:
            restored = False
    _request_navigation_guard_stop(context, restore=False)
    _svo_v6_stop_idle_warm()
    _svo_v9_set_active(settings, False)
    if restored and clear_snapshot:
        _svo_v9_clear_session_snapshot(context)
    try:
        settings.status_text = "Baseline state restored and temporary optimization disabled." if restored else "No snapshot stored"
    except Exception:
        pass
    return restored


def _svo_v9_reapply_active_optimizer(context: bpy.types.Context, *, reason: str = "settings", allow_guard: bool = True) -> bool:
    settings = _svo_v9_settings(context)
    scene = getattr(context, "scene", None)
    if scene is None or settings is None or not getattr(settings, "optimizer_active", False):
        return False
    global _SVO_V9_REAPPLY_RUNNING
    if _SVO_V9_REAPPLY_RUNNING:
        return False
    old_snapshot = getattr(scene, "smart_viewport_optimizer_snapshot_json", "")
    if not old_snapshot:
        if not _svo_v10_prepare_session_restore_from_baseline(context):
            _svo_v9_set_active(settings, False)
            return False
        old_snapshot = getattr(scene, "smart_viewport_optimizer_snapshot_json", "")
        if not old_snapshot:
            _svo_v9_set_active(settings, False)
            return False
    _svo_v8_suspend_autosave(1.0)
    try:
        _SVO_V9_REAPPLY_RUNNING = True
        try:
            _restore_snapshot(context)
        except Exception:
            pass
        try:
            scene.smart_viewport_optimizer_snapshot_json = old_snapshot
        except Exception:
            pass
        apply_optimizer(context, capture_snapshot=False, allow_ui_warm=False, allow_guard=allow_guard)
        try:
            settings.status_text = "Settings changed while ON; active optimization was rebuilt from the maintained baseline."
        except Exception:
            pass
        return True
    finally:
        _SVO_V9_REAPPLY_RUNNING = False


def _svo_v9_restore_for_file_event(context: bpy.types.Context, reason: str) -> bool:
    settings = _svo_v9_settings(context)
    if settings is None or not getattr(settings, "restore_before_file_events", True):
        return False
    if not getattr(settings, "optimizer_active", False):
        return False
    restored = _svo_v9_deactivate_optimizer(context, clear_snapshot=True, reason=reason)
    try:
        settings.status_text = "Restored before file event." if restored else "No snapshot stored"
    except Exception:
        pass
    return restored


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


class VIEW3D_OT_svo_plus_apply_max_speed(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_apply_max_speed"
    bl_label = "Apply Performance Preset"
    bl_description = "Apply the default high-performance viewport preset, save a repair backup if needed, and immediately update configured targets."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        reset_options_to_max_speed(settings)
        if getattr(settings, "optimizer_active", False):
            _svo_v9_reapply_active_optimizer(context, reason="performance_preset", allow_guard=True)
            self.report({"INFO"}, iface("Preset loaded and active optimization rebuilt."))
        else:
            settings.status_text = "Preset loaded. Toggle ON to apply it."
            self.report({"INFO"}, iface("Preset loaded. Toggle ON to apply it."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_apply_current(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_apply_current"
    bl_label = "Apply Current Options"
    bl_description = "Apply the current individual ON/OFF options without changing the option values."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if getattr(settings, "optimizer_active", False):
            applied = _svo_v9_reapply_active_optimizer(context, reason="manual_reapply", allow_guard=True)
        else:
            applied = _svo_v12_apply_details_to_view(
                context, settings, save_current=False, status="Current settings applied."
            )
        if not applied:
            self.report({"WARNING"}, iface("Current settings could not be applied."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Current settings applied."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_restore_snapshot(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_restore_snapshot"
    bl_label = "Restore Snapshot"
    bl_description = "Restore the state captured before the optimizer changed viewport, object, modifier, particle, and preference settings."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        restored = _svo_v9_deactivate_optimizer(context, clear_snapshot=True, reason="manual_restore")
        if restored:
            self.report({"INFO"}, iface("Baseline state restored and temporary optimization disabled."))
            return {"FINISHED"}
        self.report({"WARNING"}, iface("No stored snapshot was found. Nothing was restored."))
        return {"CANCELLED"}


class VIEW3D_OT_svo_plus_reset_options(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_reset_options"
    bl_label = "Reset Options to Performance High"
    bl_description = "Set all optimization options back to the Performance Priority: High preset."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        reset_options_to_max_speed(context.scene.smart_viewport_optimizer_settings)
        context.scene.smart_viewport_optimizer_settings.status_text = "Ready"
        self.report({"INFO"}, iface("Smart Viewport Optimizer Plus: performance preset options reset."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_clear_snapshot(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_clear_snapshot"
    bl_label = "Clear Snapshot"
    bl_description = "Delete the stored restore snapshot. This does not change the current scene or viewport settings."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        context.scene.smart_viewport_optimizer_snapshot_json = ""
        context.scene.smart_viewport_optimizer_settings.status_text = "Snapshot cleared"
        self.report({"INFO"}, iface("Smart Viewport Optimizer Plus: snapshot cleared."))
        return {"FINISHED"}



class VIEW3D_OT_svo_plus_toggle_optimizer(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_toggle_optimizer"
    bl_label = "Toggle Smart Viewport Optimizer"
    bl_description = "Toggle between Standard and Optimized viewport optimization settings for the current workspace and apply the selected mode to the viewport."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if settings is None:
            return {"CANCELLED"}
        current_slot = _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED"))
        target_slot = "OPTIMIZED" if current_slot == "STANDARD" else "STANDARD"
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        ok = _svo_v13_load_workspace_slot_to_settings(
            context,
            settings,
            target_slot,
            _svo_v13_active_workspace_name(context),
            save_current=auto_save,
            apply_view=True,
            fallback_to_global=True,
        )
        if not ok:
            try:
                _svo_v12_set_active_slot_value(settings, target_slot)
                ok = _svo_v12_apply_details_to_view(
                    context,
                    settings,
                    save_current=auto_save,
                    status="Current settings applied and saved." if auto_save else "Current settings applied.",
                )
            except Exception:
                ok = False
        if ok:
            self.report({"INFO"}, iface("Optimized settings applied." if target_slot == "OPTIMIZED" else "Standard settings applied."))
            return {"FINISHED"}
        self.report({"ERROR"}, iface("Settings file could not be loaded."))
        return {"CANCELLED"}


class VIEW3D_OT_svo_plus_copy_keymap_id(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_copy_keymap_id"
    bl_label = "Copy Keymap ID"
    bl_description = "Copy the toggle operator ID to the clipboard. Register it in Preferences > Keymap > 3D View > 3D View (Global)."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        try:
            context.window_manager.clipboard = "view3d.svo_plus_toggle_optimizer"
        except Exception:
            pass
        try:
            context.scene.smart_viewport_optimizer_settings.keymap_operator_id = "view3d.svo_plus_toggle_optimizer"
            context.scene.smart_viewport_optimizer_settings.status_text = "Keymap ID copied to clipboard."
        except Exception:
            pass
        self.report({"INFO"}, iface("Keymap ID copied to clipboard."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_navigation_guard(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_navigation_guard"
    bl_label = "Navigation Prewarm Guard"
    bl_description = "Keep the 3D View in a prewarmed low-cost state before navigation events begin."
    bl_options = {"INTERNAL"}

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        global _NAV_GUARD_RUNNING, _NAV_GUARD_TIMER
        wm = getattr(context, "window_manager", None)
        if wm is None:
            return {"CANCELLED"}
        _NAV_GUARD_RUNNING = True
        try:
            _NAV_GUARD_TIMER = wm.event_timer_add(0.25, window=context.window)
        except Exception:
            _NAV_GUARD_TIMER = None
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event):
        global _NAV_GUARD_RUNNING, _NAV_GUARD_TIMER, _NAV_GUARD_LAST_PREWARM, _NAV_GUARD_LAST_NAV
        if not _NAV_GUARD_SHOULD_RUN:
            wm = getattr(context, "window_manager", None)
            if wm is not None and _NAV_GUARD_TIMER is not None:
                try:
                    wm.event_timer_remove(_NAV_GUARD_TIMER)
                except Exception:
                    pass
            _NAV_GUARD_TIMER = None
            _NAV_GUARD_RUNNING = False
            return {"FINISHED"}

        scene = getattr(context, "scene", None)
        if scene is None:
            return {"PASS_THROUGH"}
        settings = scene.smart_viewport_optimizer_settings
        now = time.monotonic()
        if event.type in _NAVIGATION_EVENTS:
            _NAV_GUARD_LAST_NAV = now

        do_prewarm = False
        if event.type == "MOUSEMOVE" and settings.prewarm_on_mouse_move:
            do_prewarm = True
        elif event.type in _NAVIGATION_EVENTS:
            do_prewarm = True

        if do_prewarm and now - _NAV_GUARD_LAST_PREWARM >= float(settings.prewarm_interval):
            _NAV_GUARD_LAST_PREWARM = now
            try:
                # Event-time work must stay minimal. The heavy RNA changes are
                # already applied by Apply Preset / Apply Current Options; during
                # mouse movement we only request a safe redraw tag.
                _prewarm_viewport(context, settings, quick=True)
            except Exception:
                pass

        if event.type == "TIMER" and settings.restore_after_navigation_idle and _NAV_GUARD_LAST_NAV > 0.0:
            if now - _NAV_GUARD_LAST_NAV >= float(settings.navigation_idle_seconds):
                try:
                    _restore_snapshot(context)
                except Exception:
                    pass
                _NAV_GUARD_LAST_NAV = 0.0
        return {"PASS_THROUGH"}


class VIEW3D_OT_svo_plus_start_navigation_guard(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_start_navigation_guard"
    bl_label = "Start Navigation Guard"
    bl_description = "Start the modal navigation prewarm guard manually. The guard passes mouse and keyboard events through and only performs lightweight prewarm work at controlled intervals."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        _ensure_navigation_guard(context, manual=True)
        if not _NAV_GUARD_RUNNING:
            self.report({"WARNING"}, iface("Navigation guard could not be started."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Navigation guard started."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_stop_navigation_guard(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_stop_navigation_guard"
    bl_label = "Stop Navigation Guard"
    bl_description = "Stop the modal navigation prewarm guard. This does not restore the scene; use Restore Snapshot if you also want to return the viewport and objects to their saved state."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        _request_navigation_guard_stop(context, restore=False)
        self.report({"INFO"}, iface("Navigation guard stopped."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_capture_snapshot(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_capture_snapshot"
    bl_label = "Capture Snapshot"
    bl_description = "Capture the current state as the restore snapshot without applying optimization."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        if getattr(settings, "optimizer_active", False):
            self.report({"WARNING"}, iface("Baseline state restored and temporary optimization disabled."))
            return {"CANCELLED"}
        ok = _capture_snapshot(context, force=True)
        if ok:
            settings.status_text = "Snapshot captured"
            self.report({"INFO"}, iface("Smart Viewport Optimizer Plus: snapshot captured."))
            return {"FINISHED"}
        return {"CANCELLED"}




def _svo_v13_draw_workspace_source_block(layout: bpy.types.UILayout, context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    active_ws_name = _svo_v13_workspace_display_name(context)
    cur_row = layout.split(factor=0.6, align=True)
    cur_row.label(text=iface("Current Workspace"))
    cur_row.label(text=active_ws_name, translate=False)

    src_row = layout.split(factor=0.6, align=True)
    src_row.label(text=iface("Paste Source"))
    source_name = _svo_v13_selected_source_workspace(context, settings)
    if source_name == "__default__":
        source_name = active_ws_name
    src_row.menu(SVO_MT_workspace_source_menu.bl_idname, text=source_name or active_ws_name, translate=False)

    paste_row = layout.row(align=True)
    paste_row.scale_y = 1.15
    paste_row.operator(VIEW3D_OT_svo_plus_paste_workspace_settings.bl_idname, text=iface("Paste Settings to Current Workspace"), icon="DUPLICATE")


class SVO_MT_workspace_source_menu(bpy.types.Menu):
    bl_idname = "SVO_MT_workspace_source_menu"
    bl_label = "Paste Source"

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        active_name = _svo_v13_active_workspace_name(context)
        try:
            workspaces = list(getattr(bpy.data, "workspaces", []) or [])
        except Exception:
            workspaces = []
        if not workspaces:
            op = layout.operator(VIEW3D_OT_svo_plus_set_workspace_source.bl_idname, text=active_name, translate=False)
            op.workspace_name = active_name
            return
        for ws in workspaces:
            name = str(getattr(ws, "name", "") or "").strip()
            if not name:
                continue
            icon = "CHECKMARK" if settings is not None and _svo_v13_selected_source_workspace(context, settings) == name else "WORKSPACE"
            op = layout.operator(VIEW3D_OT_svo_plus_set_workspace_source.bl_idname, text=name, translate=False, icon=icon)
            op.workspace_name = name


class VIEW3D_OT_svo_plus_set_workspace_source(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_set_workspace_source"
    bl_label = "Set Paste Source Workspace"
    bl_description = "Select the workspace whose saved viewport optimization Detailed Settings will be pasted into the currently open workspace."
    bl_options = set()

    workspace_name: bpy.props.StringProperty(name="Workspace", default="")

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if settings is None:
            return {"CANCELLED"}
        try:
            settings.workspace_paste_source = _svo_v13_safe_workspace_key(self.workspace_name or _svo_v13_active_workspace_name(context))
        except Exception:
            return {"CANCELLED"}
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_paste_workspace_settings(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_paste_workspace_settings"
    bl_label = "Paste Settings to Current Workspace"
    bl_description = "Copy the selected source workspace viewport optimization Detailed Settings into the currently open workspace, update the current settings file, and apply the active mode to the viewport."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if settings is None:
            return {"CANCELLED"}
        source_name = _svo_v13_selected_source_workspace(context, settings)
        destination_name = _svo_v13_active_workspace_name(context)
        if not source_name or not destination_name:
            return {"CANCELLED"}
        ok = _svo_v13_copy_workspace_settings(context, settings, source_name, destination_name)
        if not ok:
            self.report({"ERROR"}, iface("Settings file could not be loaded."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Workspace settings pasted to current workspace."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_set_settings_slot(bpy.types.Operator):
    bl_idname = "view3d.svo_plus_set_settings_slot"
    bl_label = "Set Settings Mode"
    bl_description = "Switch between Standard and Optimized viewport optimization settings for the current workspace."
    bl_options = set()

    target_slot: bpy.props.EnumProperty(
        name="Settings Mode",
        items=(("STANDARD", "Standard", "Use Standard settings."), ("OPTIMIZED", "Optimized", "Use Optimized settings.")),
        default="OPTIMIZED",
    )

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if settings is None:
            return {"CANCELLED"}
        slot = _svo_v12_canonical_slot(self.target_slot)
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        ok = _svo_v13_load_workspace_slot_to_settings(
            context,
            settings,
            slot,
            _svo_v13_active_workspace_name(context),
            save_current=auto_save,
            apply_view=True,
            fallback_to_global=True,
        )
        if not ok:
            try:
                _svo_v12_set_active_slot_value(settings, slot)
                ok = _svo_v12_apply_details_to_view(
                    context,
                    settings,
                    save_current=auto_save,
                    status="Current settings applied and saved." if auto_save else "Current settings applied.",
                )
            except Exception:
                ok = False
        return {"FINISHED"} if ok else {"CANCELLED"}

class VIEW3D_OT_svo_plus_apply_selected_preset(bpy.types.Operator):
    """Copy the selected built-in preset into Detailed Settings and apply the resulting values to the viewport."""
    bl_idname = "view3d.svo_plus_apply_selected_preset"
    bl_label = "Apply Preset"
    bl_description = "Copy the selected Performance, Balanced, or Quality preset into all Detailed Settings items and apply it to the current viewport immediately. JSON files are updated only when Auto-save Settings is ON or when a save button is pressed."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        ident = _svo_v12_migrated_preset_id(getattr(settings, "selected_preset", "PERFORMANCE"))
        if ident == "PERFORMANCE":
            # Performance belongs to Optimized, so Standard stays the way back.
            _svo_v12_set_active_slot_value(settings, "OPTIMIZED")
        if not _svo_v6_apply_preset_to_settings(settings, ident, use_user_override=False, mark_active=False):
            self.report({'ERROR'}, iface("Preset not found"))
            return {'CANCELLED'}
        try:
            settings.selected_preset = ident
        except Exception:
            pass
        auto_save = bool(getattr(settings, "auto_save_workspace_preset_changes", False))
        _svo_v12_apply_details_to_view(context, settings, save_current=auto_save, status="Selected preset was copied into Detailed Settings and applied.", apply_object_targets=True)
        self.report({'INFO'}, iface("Selected preset was copied into Detailed Settings and applied."))
        return {'FINISHED'}

class _SVO_PLUS_OT_settings_slot_file_base:
    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})
    _slot = "OPTIMIZED"

    def _default_path(self) -> str:
        return _svo_v12_slot_settings_path(self._slot)

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if not getattr(self, "filepath", ""):
            self.filepath = self._default_path()
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class VIEW3D_OT_svo_plus_save_standard_settings(_SVO_PLUS_OT_settings_slot_file_base, bpy.types.Operator):
    """Save the current Detailed Settings as the Standard Settings file and update the current settings file."""
    bl_idname = "view3d.svo_plus_save_standard_settings"
    bl_label = "Save Standard Settings"
    bl_description = "Save the current Detailed Settings as Standard Settings. The selected file, the internal Standard file, and the current settings file are updated, then the settings remain applied."
    bl_options = set()
    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})
    _slot = "STANDARD"

    def execute(self, context: bpy.types.Context):
        path = _svo_v12_save_settings_slot(context, self.filepath or self._default_path(), "STANDARD")
        if not path:
            self.report({"ERROR"}, iface("Settings are unavailable."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Standard Settings saved and applied."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_load_standard_settings(_SVO_PLUS_OT_settings_slot_file_base, bpy.types.Operator):
    """Load a Standard Settings file, apply it, and update the current settings file."""
    bl_idname = "view3d.svo_plus_load_standard_settings"
    bl_label = "Load Standard Settings"
    bl_description = "Load Standard Settings from a JSON file. The loaded values are applied to the viewport, copied to the internal Standard file, and written to the current settings file."
    bl_options = set()
    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})
    _slot = "STANDARD"

    def execute(self, context: bpy.types.Context):
        if not _svo_v12_load_settings_file(context, self.filepath or self._default_path(), "STANDARD"):
            self.report({"ERROR"}, iface("Settings file could not be loaded."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Standard Settings loaded and applied."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_save_optimized_settings(_SVO_PLUS_OT_settings_slot_file_base, bpy.types.Operator):
    """Save the current Detailed Settings as the Optimized Settings file and update the current settings file."""
    bl_idname = "view3d.svo_plus_save_optimized_settings"
    bl_label = "Save Optimized Settings"
    bl_description = "Save the current Detailed Settings as Optimized Settings. The selected file, the internal Optimized file, and the current settings file are updated, then the settings remain applied."
    bl_options = set()
    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})
    _slot = "OPTIMIZED"

    def execute(self, context: bpy.types.Context):
        path = _svo_v12_save_settings_slot(context, self.filepath or self._default_path(), "OPTIMIZED")
        if not path:
            self.report({"ERROR"}, iface("Settings are unavailable."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Optimized Settings saved and applied."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_load_optimized_settings(_SVO_PLUS_OT_settings_slot_file_base, bpy.types.Operator):
    """Load an Optimized Settings file, apply it, and update the current settings file."""
    bl_idname = "view3d.svo_plus_load_optimized_settings"
    bl_label = "Load Optimized Settings"
    bl_description = "Load Optimized Settings from a JSON file. The loaded values are applied to the viewport, copied to the internal Optimized file, and written to the current settings file."
    bl_options = set()
    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})
    _slot = "OPTIMIZED"

    def execute(self, context: bpy.types.Context):
        if not _svo_v12_load_settings_file(context, self.filepath or self._default_path(), "OPTIMIZED"):
            self.report({"ERROR"}, iface("Settings file could not be loaded."))
            return {"CANCELLED"}
        self.report({"INFO"}, iface("Optimized Settings loaded and applied."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_reset_selected_preset(bpy.types.Operator):
    """Reset the selected built-in preset to its factory definition."""
    bl_idname = "view3d.svo_plus_reset_selected_preset"
    bl_label = "Reset Selected Preset Settings"
    bl_description = "Reset the selected built-in preset to its installation-time factory settings and delete only its external override file."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        ident = settings.selected_preset
        if ident not in SVO_V6_PRESETS:
            self.report({'WARNING'}, iface("Custom presets do not have factory defaults. Delete or overwrite the custom preset instead."))
            return {'CANCELLED'}
        _svo_v8_suspend_autosave(2.0)
        _svo_v8_delete_builtin_override(ident)
        if not _svo_v6_apply_preset_to_settings(settings, ident, use_user_override=False, mark_active=True):
            self.report({'ERROR'}, iface("Preset not found"))
            return {'CANCELLED'}
        if getattr(settings, "optimizer_active", False):
            _svo_v9_reapply_active_optimizer(context, reason="preset_reset", allow_guard=True)
            settings.status_text = "Preset loaded and active optimization rebuilt."
        else:
            settings.status_text = "Factory preset restored"
        _svo_v8_mark_preset_baseline(settings, ident)
        self.report({'INFO'}, iface("Smart Viewport Optimizer Plus: selected preset factory settings restored."))
        return {'FINISHED'}

class VIEW3D_OT_svo_plus_save_selected_preset_settings(bpy.types.Operator):
    """Save the selected preset settings to an external JSON file."""
    bl_idname = "view3d.svo_plus_save_selected_preset_settings"
    bl_label = "Save Selected Preset Settings"
    bl_description = "Save the current detailed optimizer settings to an external JSON file and keep them as the selected preset settings. The file browser opens with a suitable default file name based on the selected preset."
    bl_options = set()

    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        settings = context.scene.smart_viewport_optimizer_settings
        self.filepath = _svo_v10_default_preset_export_path(settings)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        path = _svo_v10_write_preset_file(settings, self.filepath or _svo_v10_default_preset_export_path(settings))
        if not path:
            self.report({"ERROR"}, iface("The selected file is not a preset settings file."))
            return {"CANCELLED"}
        settings.status_text = "Selected preset settings saved."
        self.report({"INFO"}, iface("Selected preset settings saved."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_load_settings_as_selected_preset(bpy.types.Operator):
    """Load an external JSON settings file into the selected preset."""
    bl_idname = "view3d.svo_plus_load_settings_as_selected_preset"
    bl_label = "Load Settings as Selected Preset"
    bl_description = "Load an external JSON settings file into the currently selected preset and keep those settings as the selected preset override."
    bl_options = set()

    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        settings = context.scene.smart_viewport_optimizer_settings
        self.filepath = _svo_v10_default_preset_export_path(settings)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        path = _svo_v10_normalize_json_path(self.filepath, _svo_v10_default_preset_export_path(settings))
        if not _svo_v10_load_preset_file_into_selected(settings, path):
            self.report({"ERROR"}, iface("The selected file is not a preset settings file."))
            return {"CANCELLED"}
        if getattr(settings, "optimizer_active", False):
            _svo_v9_reapply_active_optimizer(context, reason="preset_import", allow_guard=True)
        settings.status_text = "Selected preset settings loaded."
        self.report({"INFO"}, iface("Selected preset settings loaded."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_save_current_baseline_state(bpy.types.Operator):
    """Save the current Blender state as an external baseline snapshot."""
    bl_idname = "view3d.svo_plus_save_current_baseline_state"
    bl_label = "Save Current Settings as Baseline State"
    bl_description = "Save the current Blender settings as an external baseline JSON file and keep that state as the maintained restore target. Optimization cannot be turned ON until this baseline is saved or loaded."
    bl_options = set()

    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        return bool(settings is not None and not getattr(settings, "optimizer_active", False))

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.filepath = _svo_v10_default_baseline_export_path()
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        if getattr(settings, "optimizer_active", False):
            self.report({"WARNING"}, iface("Save the baseline after turning optimization OFF."))
            return {"CANCELLED"}
        data = _svo_v6_build_external_snapshot(context, "baseline")
        path = _svo_v10_write_current_baseline_data(data, self.filepath or _svo_v10_default_baseline_export_path())
        ready, message = _svo_v10_baseline_state_status()
        if not ready:
            settings.status_text = message
            self.report({"ERROR"}, iface(message))
            return {"CANCELLED"}
        settings.status_text = "Baseline state saved and set."
        self.report({"INFO"}, iface("Baseline state saved and set."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_load_baseline_state(bpy.types.Operator):
    """Load an external baseline snapshot and keep it as the maintained baseline."""
    bl_idname = "view3d.svo_plus_load_baseline_state"
    bl_label = "Load Baseline State"
    bl_description = "Load an external JSON baseline file, keep it as the maintained baseline state, and immediately restore Blender to that state while optimization is OFF."
    bl_options = set()

    filepath: bpy.props.StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        return bool(settings is not None and not getattr(settings, "optimizer_active", False))

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.filepath = _svo_v10_current_baseline_path()
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        path = _svo_v10_normalize_json_path(self.filepath, _svo_v10_current_baseline_path())
        data = _svo_v6_read_json(path)
        if not data or not _svo_v10_is_snapshot_data(data):
            self.report({"ERROR"}, iface("The selected file is not a baseline snapshot file."))
            return {"CANCELLED"}
        _svo_v10_write_current_baseline_data(data, _svo_v10_current_baseline_path())
        restored = _svo_v10_restore_stored_baseline(context, keep_session_snapshot=False)
        _svo_v9_clear_session_snapshot(context)
        settings.status_text = "Baseline state loaded and restored." if restored else "Baseline state loaded, but the current UI context could not be fully restored."
        self.report({"INFO"}, iface("Baseline state loaded and restored."))
        return {"FINISHED"}


class VIEW3D_OT_svo_plus_save_custom_preset(bpy.types.Operator):
    """Save current optimizer options as an external custom preset."""
    bl_idname = "view3d.svo_plus_save_custom_preset"
    bl_label = "Save Custom Preset"
    bl_description = "Save the current individual ON/OFF settings as a custom preset outside the .blend file."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        label = settings.custom_preset_name.strip() or "Custom Preset"
        file_id = _svo_v6_safe_preset_file(label)
        values = {key: getattr(settings, key) for key in _svo_v8_preset_setting_keys(settings)}
        data = {"addon": ADDON_ID, "version": ADDON_VERSION, "name": label, "description": "User-saved optimizer preset. Expected effect depends on the saved settings.", "values": values, "created_at": datetime.datetime.utcnow().isoformat() + "Z"}
        _svo_v6_atomic_json(os.path.join(_svo_v6_preset_root(), file_id + ".json"), data)
        # Exporting a custom file must not assign an identifier absent from
        # the intentionally built-in-only preset selector. Keep its selection.
        self.report({'INFO'}, iface("Smart Viewport Optimizer Plus: custom preset saved"))
        return {'FINISHED'}

class VIEW3D_OT_svo_plus_delete_custom_preset(bpy.types.Operator):
    """Delete the named custom preset file."""
    bl_idname = "view3d.svo_plus_delete_custom_preset"
    bl_label = "Delete Custom Preset"
    bl_description = "Delete the custom preset file by the same name used to save it."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        label = settings.custom_preset_name.strip() or "Custom Preset"
        file_id = _svo_v6_safe_preset_file(label)
        try:
            os.remove(os.path.join(_svo_v6_preset_root(), file_id + ".json"))
        except OSError as error:
            self.report({'WARNING'}, f"{iface('Could not delete the custom preset')}: {error.strerror}")
            return {'CANCELLED'}
        self.report({'INFO'}, iface("Smart Viewport Optimizer Plus: custom preset deleted"))
        return {'FINISHED'}

class VIEW3D_OT_svo_plus_capture_external_backup(bpy.types.Operator):
    """Capture an external JSON repair backup without applying optimization."""
    bl_idname = "view3d.svo_plus_capture_external_backup"
    bl_label = "Capture External Backup"
    bl_description = "Save the current state to an external JSON repair backup without applying optimization. Use this before testing aggressive presets."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        _capture_snapshot(context, force=True)
        path = _svo_v6_capture_external_backup(context, "manual")
        self.report({'INFO'}, f"{iface('Smart Viewport Optimizer Plus: external backup saved')}: {path or iface('failed')}")
        return {'FINISHED'}

class VIEW3D_OT_svo_plus_restore_external_backup(bpy.types.Operator):
    """Restore from the selected external JSON repair backup."""
    bl_idname = "view3d.svo_plus_restore_external_backup"
    bl_label = "Restore External Backup"
    bl_description = "Restore viewport, object, modifier, constraint, particle, and preference settings from the selected external JSON repair backup."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = context.scene.smart_viewport_optimizer_settings
        if not _svo_v6_restore_external_backup(context, settings.backup_restore_kind):
            self.report({'WARNING'}, iface("No external backup was found"))
            return {'CANCELLED'}
        _svo_v9_set_active(settings, False)
        _svo_v9_clear_session_snapshot(context)
        self.report({'INFO'}, iface("Smart Viewport Optimizer Plus: external backup restored"))
        return {'FINISHED'}

class VIEW3D_OT_svo_plus_open_backup_folder(bpy.types.Operator):
    """Open the external backup and preset folder."""
    bl_idname = "view3d.svo_plus_open_backup_folder"
    bl_label = "Open Backup Folder"
    bl_description = "Open the folder that contains external JSON backups and custom preset files."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        path = _svo_v6_user_root()
        try:
            bpy.ops.wm.path_open(filepath=path)
        except Exception:
            self.report({'INFO'}, path)
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# UI
# -----------------------------------------------------------------------------


def _draw_header(layout: bpy.types.UILayout, settings: SVO_PLUS_PG_settings, prop: str, label: str, icon: str = "NONE", *, use_native_panel: bool = True) -> Optional[bpy.types.UILayout]:
    if use_native_panel:
        try:
            header, body = layout.panel_prop(settings, prop)
        except Exception:
            header, body = layout.panel(
                idname=f"smart_workspace_svo_child_{prop}",
                default_closed=not bool(getattr(settings, prop)),
            )
    else:
        # Header popovers do not support UILayout panels. Keep the same RNA
        # disclosure property and content, using ordinary popup-safe layout.
        expanded = bool(getattr(settings, prop))
        header = layout.row(align=True)
        header.prop(settings, prop, text="", icon="NONE", toggle=True)
        body = layout.box() if expanded else None
    _svo_child_title(header, label, icon)
    header.separator(factor=0.35)
    op = header.operator('smart_workspace_suite.open_help', text='', icon='QUESTION')
    op.help_id = 'viewport_optimization'
    return body


def _svo_child_title(header: bpy.types.UILayout, label: str, icon: str = "NONE") -> None:
    # 子の開閉の見出し（layout.panel の header）。題は label → separator → ？ の順（A1-44）。
    if icon and icon != "NONE":
        header.label(text=iface(label), icon=icon)
    else:
        header.label(text=iface(label))


def _prop_column(layout: bpy.types.UILayout, settings: SVO_PLUS_PG_settings, props: Sequence[str]) -> None:
    col = layout.column(align=True)
    for prop in props:
        col.prop(settings, prop)



def draw_smart_workspace_section(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene else None
    if settings is None:
        layout.label(text=iface("Smart Workspace"), icon="ERROR")
        layout.label(text=iface("Settings are unavailable."))
        return

    workspace_box = layout.box()
    _svo_v13_draw_workspace_source_block(workspace_box, context, settings)

    mode_box = layout.box()
    mode_box.label(text=iface("Settings Mode"), icon="PRESET")
    mode_row = mode_box.row(align=True)
    current_slot = _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED"))
    op = mode_row.operator(VIEW3D_OT_svo_plus_set_settings_slot.bl_idname, text=iface("Standard"), depress=(current_slot == "STANDARD"))
    op.target_slot = "STANDARD"
    op = mode_row.operator(VIEW3D_OT_svo_plus_set_settings_slot.bl_idname, text=iface("Optimized"), depress=(current_slot == "OPTIMIZED"))
    op.target_slot = "OPTIMIZED"

    save_box = _draw_header(layout, settings, "show_quick", "Setting Save / Keymap", "NONE")
    if save_box:
        _svo_plus_draw_operation_controls(save_box, context, settings)

    details = _draw_header(layout, settings, "show_snapshot", "Detailed Settings", "NONE")
    if details:
        _svo_plus_draw_detail_settings(details, settings)


class VIEW3D_PT_svo_plus_header_popover(bpy.types.Panel):
    bl_label = "Header Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "HEADER"
    bl_ui_units_x = 24

    def draw_header_preset(self, context):
        op = self.layout.operator('smart_workspace_suite.open_help', text='', icon='QUESTION')
        op.help_id = 'viewport_optimization'

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        scene = context.scene
        settings = scene.smart_viewport_optimizer_settings
        layout.label(text=iface("Detailed Settings"), icon="PREFERENCES")
        layout.separator()
        _svo_plus_draw_detail_settings(layout, settings, use_native_panel=False)


def _svo_plus_draw_toggle_status(layout: bpy.types.UILayout, context: bpy.types.Context, settings: bpy.types.PropertyGroup, compact: bool = False) -> None:
    box = layout.box() if not compact else layout
    active = bool(getattr(settings, "optimizer_active", False))
    toggle_text = iface("Toggle OFF / Restore") if active else iface("Toggle ON")
    row = box.row(align=True)
    if not compact:
        row.scale_y = 1.35
    row.operator(
        VIEW3D_OT_svo_plus_toggle_optimizer.bl_idname,
        text=toggle_text if not compact else "",
        icon="CHECKBOX_HLT" if active else "MODIFIER",
        depress=active,
    )
    if not compact:
        box.label(text=iface("Optimization is ON") if active else iface("Optimization is OFF"))
        box.label(text=f"{iface('Status')}: {iface(settings.status_text)}")


def _svo_plus_draw_operation_controls(layout: bpy.types.UILayout, context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    save_box = layout.box()
    save_box.label(text=iface("Auto-save Settings"), icon="FILE_TICK")
    save_box.prop(settings, "auto_save_workspace_preset_changes")

    standard_box = layout.box()
    standard_box.label(text=iface("Standard Settings"), icon="FILE")
    row = standard_box.column(align=True)
    row.operator(VIEW3D_OT_svo_plus_save_standard_settings.bl_idname, text=iface("Save Standard Settings"), icon="FILE_TICK")
    row.operator(VIEW3D_OT_svo_plus_load_standard_settings.bl_idname, text=iface("Load Standard Settings"), icon="IMPORT")

    optimized_box = layout.box()
    optimized_box.label(text=iface("Optimized Settings"), icon="MODIFIER")
    row = optimized_box.column(align=True)
    row.operator(VIEW3D_OT_svo_plus_save_optimized_settings.bl_idname, text=iface("Save Optimized Settings"), icon="FILE_TICK")
    row.operator(VIEW3D_OT_svo_plus_load_optimized_settings.bl_idname, text=iface("Load Optimized Settings"), icon="IMPORT")

    keymap_box = layout.box()
    keymap_box.label(text=iface("Keymap"), icon="KEYINGSET")
    row = keymap_box.column(align=True)
    row.operator(VIEW3D_OT_svo_plus_copy_keymap_id.bl_idname, text=iface("Copy Keymap ID"), icon="COPYDOWN")

def _svo_plus_draw_detail_settings(layout: bpy.types.UILayout, settings: bpy.types.PropertyGroup, *, use_native_panel: bool = True) -> None:
    preset_box = layout.box()
    preset_box.label(text=iface("Setting Load"), icon="PRESET")
    preset_box.prop(settings, "selected_preset", text=iface("Setting"))
    preset_box.operator(VIEW3D_OT_svo_plus_apply_selected_preset.bl_idname, text=iface("Apply Preset"), icon="CHECKMARK")
    preset_box.operator(VIEW3D_OT_svo_plus_sync_details_from_current_settings.bl_idname, text=iface("Load Current View Settings"), icon="IMPORT")

    groups = _draw_header(layout, settings, "show_targets", "Groups", "NONE", use_native_panel=use_native_panel)
    if groups:
        _prop_column(groups, settings, (
            "protect_existing_snapshot",
            "apply_all_scenes",
            "object_scope",
            "include_scene_simplify",
            "include_viewport_shading",
            "include_overlays",
            "include_gizmos",
            "include_object_filters",
            "include_object_display",
            "include_modifiers",
            "include_particles",
            "include_preferences",
            "include_navigation_latency",
            "include_constraints",
            "include_viewport_prewarm",
        ))

    scene_box = _draw_header(layout, settings, "show_scene", "Scene Simplify", "NONE", use_native_panel=use_native_panel)
    if scene_box:
        _prop_column(scene_box, settings, (
            "use_simplify",
            "force_subdivision_level",
            "subdivision_level",
            "force_volume_resolution",
            "volume_value",
            "force_child_particles",
            "child_particle_percentage",
            "force_texture_size",
            "texture_size",
            "simplify_grease_pencil",
        ))

    viewport_box = _draw_header(layout, settings, "show_viewport", "Viewport Shading", "NONE", use_native_panel=use_native_panel)
    if viewport_box:
        _prop_column(viewport_box, settings, (
            "force_wireframe_mode",
            "use_flat_solid_fallback",
            "use_single_color",
            "disable_shadows",
            "disable_cavity",
            "disable_object_outlines",
            "disable_specular",
            "disable_xray",
            "disable_scene_lights",
            "disable_scene_world",
            "enable_backface_culling",
            "limit_far_clip",
            "clip_end",
            "limit_near_clip",
            "clip_start",
            "force_orthographic_view",
            "clear_view3d_locks",
        ))

    overlay_box = _draw_header(layout, settings, "show_overlay", "Overlays", "NONE", use_native_panel=use_native_panel)
    if overlay_box:
        _prop_column(overlay_box, settings, (
            "hide_all_overlays",
            "hide_relationship_lines",
            "hide_grid_axes",
            "hide_text_stats",
            "hide_extras",
            "hide_wire_overlay",
            "hide_normals",
            "hide_edit_guides",
            "hide_motion_paths",
            "hide_annotations",
        ))

    gizmo_box = _draw_header(layout, settings, "show_gizmo", "Gizmos", "NONE", use_native_panel=use_native_panel)
    if gizmo_box:
        _prop_column(gizmo_box, settings, (
            "hide_all_gizmos",
            "hide_navigation_gizmo",
            "hide_tool_gizmos",
            "hide_context_gizmos",
            "hide_object_transform_gizmos",
        ))

    filter_box = _draw_header(layout, settings, "show_filter", "Viewport Object Filters", "NONE", use_native_panel=use_native_panel)
    if filter_box:
        _prop_column(filter_box, settings, (
            "hide_lights",
            "hide_cameras",
            "hide_empties",
            "hide_armatures",
            "hide_curves",
            "hide_surfaces",
            "hide_fonts",
            "hide_metaballs",
            "hide_lattices",
            "hide_speakers",
            "hide_light_probes",
            "hide_volumes",
            "hide_grease_pencil",
            "hide_pointclouds",
            "hide_meshes_filter",
            "disable_object_type_selection_filters",
            "disable_mesh_selection_filter",
        ))

    object_box = _draw_header(layout, settings, "show_object", "Object Display", "NONE", use_native_panel=use_native_panel)
    if object_box:
        _prop_column(object_box, settings, (
            "force_object_display_type",
            "object_display_type",
            "hide_object_names_axes",
            "disable_object_selection",
            "hide_instancer_viewport",
            "hide_unselected_objects",
            "force_bounds_type_box",
            "pause_object_simulation_cache",
            "enable_heavy_object_culling",
            "heavy_object_action",
            "heavy_vertex_threshold",
            "heavy_modifier_threshold",
            "heavy_particle_threshold",
        ))

    modifier_box = _draw_header(layout, settings, "show_modifier", "Modifiers", "NONE", use_native_panel=use_native_panel)
    if modifier_box:
        _prop_column(modifier_box, settings, (
            "disable_viewport_modifiers",
            "disable_subdivision_modifiers",
            "disable_geometry_nodes",
            "disable_simulation_modifiers",
            "disable_deformer_modifiers",
            "disable_generator_modifiers",
            "disable_normal_data_modifiers",
            "disable_other_modifiers",
        ))

    constraint_box = _draw_header(layout, settings, "show_constraint", "Constraints", "NONE", use_native_panel=use_native_panel)
    if constraint_box:
        _prop_column(constraint_box, settings, (
            "mute_object_constraints",
            "mute_pose_constraints",
        ))

    particle_box = _draw_header(layout, settings, "show_particle", "Particles", "NONE", use_native_panel=use_native_panel)
    if particle_box:
        _prop_column(particle_box, settings, (
            "reduce_particle_previews",
            "particle_display_percentage",
            "particle_display_step",
        ))

    pref_box = _draw_header(layout, settings, "show_pref", "Preferences", "NONE", use_native_panel=use_native_panel)
    if pref_box:
        _prop_column(pref_box, settings, (
            "disable_viewport_aa",
            "keep_texture_vbo_cache_warm",
            "texture_cache_seconds",
            "vbo_cache_seconds",
            "texture_collection_rate",
            "vbo_collection_rate",
            "gl_texture_limit",
            "disable_gpu_subdivision",
            "disable_smooth_wires",
            "set_shader_compilation_threaded",
            "gpu_shader_workers",
            "set_memory_cache_limit",
            "memory_cache_limit_mb",
            "disable_region_overlap",
            "reduce_ui_status_draw",
            "enable_reduce_motion",
        ))

    nav_box = _draw_header(layout, settings, "show_navigation", "Navigation Start Lag", "NONE", use_native_panel=use_native_panel)
    if nav_box:
        _prop_column(nav_box, settings, (
            "disable_depth_navigation",
            "disable_zoom_to_mouse",
            "disable_rotate_around_active",
            "disable_auto_perspective",
            "disable_smooth_view",
            "hide_global_navigation_ui",
            "force_object_mode_on_apply",
            "clear_selection_on_apply",
            "disable_global_undo",
            "undo_steps",
            "undo_memory_limit",
            "disable_auto_keying",
            "simplify_navigation_method",
            "view_rotate_method",
            "view_zoom_method",
            "view_zoom_axis",
            "disable_ndof_guides",
            "disable_snapping_automerge",
        ))

    prewarm_box = _draw_header(layout, settings, "show_prewarm", "Viewport Prewarm", "NONE", use_native_panel=use_native_panel)
    if prewarm_box:
        _prop_column(prewarm_box, settings, (
            "enable_navigation_guard",
            "prewarm_on_mouse_move",
            "prewarm_interval",
            "prewarm_redraw_iterations",
            "restore_after_navigation_idle",
            "navigation_idle_seconds",
            "prewarm_view_matrix_nudge",
            "enable_idle_warm_pulse",
            "idle_warm_pulse_interval",
            "idle_pulse_view_layer_update",
            "idle_pulse_redraw_iterations",
        ))


_SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW = None


def _svo_plus_draw_header_buttons(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    try:
        scene = context.scene
        settings = scene.smart_viewport_optimizer_settings if scene else None
        if settings is None:
            return
        active = bool(getattr(settings, "optimizer_active", False))
        row = layout.row(align=True)
        op = row.operator(
            VIEW3D_OT_svo_plus_toggle_optimizer.bl_idname,
            text="",
            icon="CHECKBOX_HLT" if active else "MODIFIER",
            depress=active,
        )
        row.popover(
            panel="VIEW3D_PT_svo_plus_header_popover",
            text="",
        )
    except Exception:
        pass


def _svo_plus_editor_menus_draw_injected(self: bpy.types.Menu, context: bpy.types.Context) -> None:
    layout = self.layout
    obj = context.active_object
    mode_string = context.mode
    edit_object = context.edit_object
    tool_settings = context.tool_settings
    i18n_contexts = bpy.app.translations.contexts

    layout.menu("VIEW3D_MT_view")

    if mode_string in {'PAINT_WEIGHT', 'PAINT_VERTEX', 'PAINT_TEXTURE'}:
        mesh = obj.data
        if mesh.use_paint_mask:
            layout.menu("VIEW3D_MT_select_paint_mask")
        elif mesh.use_paint_mask_vertex and mode_string in {'PAINT_WEIGHT', 'PAINT_VERTEX'}:
            layout.menu("VIEW3D_MT_select_paint_mask_vertex")
    elif mode_string not in {
            'SCULPT', 'SCULPT_CURVES', 'PAINT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL', 'WEIGHT_GREASE_PENCIL',
            'VERTEX_GREASE_PENCIL',
    }:
        layout.menu("VIEW3D_MT_select_" + mode_string.lower())

    if mode_string == 'OBJECT':
        layout.menu("VIEW3D_MT_add")
    elif mode_string == 'EDIT_MESH':
        layout.menu("VIEW3D_MT_mesh_add", text="Add", text_ctxt=i18n_contexts.operator_default)
    elif mode_string == 'EDIT_CURVE':
        layout.menu("VIEW3D_MT_curve_add", text="Add", text_ctxt=i18n_contexts.operator_default)
    elif mode_string == 'EDIT_CURVES':
        layout.menu("VIEW3D_MT_edit_curves_add", text="Add", text_ctxt=i18n_contexts.operator_default)
    elif mode_string == 'EDIT_SURFACE':
        layout.menu("VIEW3D_MT_surface_add", text="Add", text_ctxt=i18n_contexts.operator_default)
    elif mode_string == 'EDIT_METABALL':
        layout.menu("VIEW3D_MT_metaball_add", text="Add", text_ctxt=i18n_contexts.operator_default)
    elif mode_string == 'EDIT_ARMATURE':
        layout.menu("TOPBAR_MT_edit_armature_add", text="Add", text_ctxt=i18n_contexts.operator_default)

    inserted = False
    if edit_object:
        layout.menu("VIEW3D_MT_edit_" + edit_object.type.lower())

        if mode_string == 'EDIT_MESH':
            layout.menu("VIEW3D_MT_edit_mesh_vertices")
            layout.menu("VIEW3D_MT_edit_mesh_edges")
            layout.menu("VIEW3D_MT_edit_mesh_faces")
            layout.menu("VIEW3D_MT_uv_map", text="UV")
            _svo_plus_draw_header_buttons(layout, context)
            inserted = True
            layout.template_node_operator_asset_root_items()
        elif mode_string in {'EDIT_CURVE', 'EDIT_SURFACE'}:
            layout.menu("VIEW3D_MT_edit_curve_ctrlpoints")
            layout.menu("VIEW3D_MT_edit_curve_segments")
        elif mode_string == 'EDIT_POINTCLOUD':
            layout.template_node_operator_asset_root_items()
        elif mode_string == 'EDIT_CURVES':
            layout.menu("VIEW3D_MT_edit_curves_control_points")
            layout.menu("VIEW3D_MT_edit_curves_segments")
            layout.template_node_operator_asset_root_items()
        elif mode_string == 'EDIT_GREASE_PENCIL':
            layout.menu("VIEW3D_MT_edit_greasepencil_point")
            layout.menu("VIEW3D_MT_edit_greasepencil_stroke")
            layout.template_node_operator_asset_root_items()

    elif obj:
        if mode_string not in {'PAINT_TEXTURE', 'SCULPT_CURVES', 'SCULPT_GREASE_PENCIL', 'VERTEX_GREASE_PENCIL'}:
            layout.menu("VIEW3D_MT_" + mode_string.lower())
        if mode_string == 'SCULPT':
            layout.menu("VIEW3D_MT_mask")
            layout.menu("VIEW3D_MT_face_sets")
            layout.template_node_operator_asset_root_items()
        elif mode_string == 'SCULPT_CURVES':
            layout.menu("VIEW3D_MT_select_sculpt_curves")
            layout.menu("VIEW3D_MT_sculpt_curves")
            layout.template_node_operator_asset_root_items()
        elif mode_string == 'VERTEX_GREASE_PENCIL':
            layout.menu("VIEW3D_MT_select_edit_grease_pencil")
            layout.menu("VIEW3D_MT_paint_vertex_grease_pencil")
            layout.template_node_operator_asset_root_items()
        elif mode_string == 'SCULPT_GREASE_PENCIL':
            is_selection_mask = (
                tool_settings.use_gpencil_select_mask_point or
                tool_settings.use_gpencil_select_mask_stroke or
                tool_settings.use_gpencil_select_mask_segment
            )
            if is_selection_mask:
                layout.menu("VIEW3D_MT_select_edit_grease_pencil")
            layout.template_node_operator_asset_root_items()
        else:
            layout.template_node_operator_asset_root_items()

    else:
        layout.menu("VIEW3D_MT_object")
        layout.template_node_operator_asset_root_items()

    if not inserted:
        _svo_plus_draw_header_buttons(layout, context)


def _svo_plus_editor_menus_draw(self: bpy.types.Menu, context: bpy.types.Context) -> None:
    try:
        _svo_plus_editor_menus_draw_injected(self, context)
    except Exception:
        global _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW
        if _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW is not None:
            try:
                _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW(self, context)
                _svo_plus_draw_header_buttons(self.layout, context)
            except Exception:
                pass


def _svo_plus_install_header_menu_patch() -> None:
    global _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW
    try:
        menu_type = getattr(bpy.types, "VIEW3D_MT_editor_menus", None)
        if menu_type is None:
            return
        if _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW is None:
            _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW = menu_type.draw
        if menu_type.draw is not _svo_plus_editor_menus_draw:
            menu_type.draw = _svo_plus_editor_menus_draw
    except Exception:
        pass


def _svo_plus_remove_header_menu_patch() -> None:
    global _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW
    try:
        menu_type = getattr(bpy.types, "VIEW3D_MT_editor_menus", None)
        if menu_type is not None:
            replacement = _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW
            current_draw = getattr(menu_type, "draw", None)
            current_name = getattr(current_draw, "__name__", "")
            if replacement is None and current_name == "_svo_plus_editor_menus_draw":
                try:
                    for module in tuple(sys.modules.values()):
                        if module is None:
                            continue
                        module_name = str(getattr(module, "__name__", "") or "")
                        if "smart_workspace_suite" not in module_name or "smart_viewport_optimizer_plus" not in module_name:
                            continue
                        candidate = getattr(module, "_SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW", None)
                        if candidate is not None and candidate is not current_draw:
                            replacement = candidate
                            break
                except Exception:
                    replacement = None
            if replacement is not None:
                menu_type.draw = replacement
    except Exception:
        pass
    _SVO_PLUS_ORIGINAL_VIEW3D_MT_EDITOR_MENUS_DRAW = None




def _svo_plus_collapse_ui_sections(settings: Optional[bpy.types.PropertyGroup]) -> None:
    if settings is None:
        return
    for prop in (
        "show_quick", "show_targets", "show_scene", "show_viewport", "show_overlay",
        "show_gizmo", "show_filter", "show_object", "show_modifier", "show_constraint",
        "show_navigation", "show_prewarm", "show_particle", "show_pref", "show_snapshot",
    ):
        try:
            setattr(settings, prop, False)
        except Exception:
            pass

# -----------------------------------------------------------------------------
# v15/v16 crash-safe Standard / Optimized file-boundary behavior
# -----------------------------------------------------------------------------

_SVO_V15_SAVE_REAPPLY_PENDING = False
_SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON = ""
_SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS = False
_SVO_V14_LAYOUT_CACHE = {"ts": 0.0, "sig": None, "data": None}
_SVO_V12_LAST_APPLY_TS = 0.0
_SVO_V12_LAST_REDRAW_TS = 0.0
_SVO_V13_LAST_DRAW_SYNC = {"workspace": "", "slot": "", "ts": 0.0}


def _svo_v16_begin_unsafe_ui_suppression() -> bool:
    global _SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS
    old = bool(_SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS)
    _SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS = True
    return old


def _svo_v16_end_unsafe_ui_suppression(old: bool) -> None:
    global _SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS
    _SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS = bool(old)


def _svo_v16_is_unsafe_ui_suppressed() -> bool:
    try:
        return bool(_SVO_V16_SUPPRESS_UNSAFE_UI_OPERATORS)
    except Exception:
        return True


def _svo_v16_in_file_boundary_stack() -> bool:
    """True while automatic startup/load/save persistence callbacks are active."""
    try:
        import inspect
        for frame in inspect.stack(context=0)[:24]:
            fn = str(getattr(frame, 'function', '') or '')
            filename = str(getattr(frame, 'filename', '') or '').replace('\\', '/').lower()
            if fn in {
                'sws_persistent_load_post',
                'sws_persistent_load_pre',
                'sws_persistent_save_pre',
                'sws_persistent_save_post',
                'load_all_settings',
                '_load_explicit_json_settings',
                '_load_viewport_optimizer_settings',
                '_svo_v12_load_current_settings_if_available',
            }:
                return True
            if filename.endswith('/smart_workspace_suite/persistence.py'):
                return True
    except Exception:
        return True
    return False


def _svo_v16_can_apply_view3d_layout(context: Optional[bpy.types.Context]) -> bool:
    if _svo_v16_is_unsafe_ui_suppressed() or _svo_v16_in_file_boundary_stack():
        return False
    try:
        ctx = context or getattr(bpy, "context", None)
        if ctx is None:
            return False
        if getattr(ctx, "window", None) is None or getattr(ctx, "screen", None) is None:
            return False
    except Exception:
        return False
    return True


def _svo_v16_can_use_mode_operator(context: Optional[bpy.types.Context]) -> bool:
    # Mode switching from add-on file handlers, popup launchers, or overridden UI
    # contexts has caused native Blender 5.1 Windows access violations through the
    # undo/workspace path.  The optimizer therefore does not force edit/object mode
    # as part of automatic restore/apply. Object visibility and View3D settings are
    # still restored through direct RNA.
    return False


def _svo_v15_scene_settings(context: Optional[bpy.types.Context] = None) -> Tuple[Optional[bpy.types.Scene], Optional[bpy.types.PropertyGroup]]:
    ctx = context or getattr(bpy, "context", None)
    scene = getattr(ctx, "scene", None) if ctx is not None else None
    settings = getattr(scene, "smart_viewport_optimizer_settings", None) if scene is not None else None
    return scene, settings


def _svo_v15_active_slot(settings: Optional[bpy.types.PropertyGroup]) -> str:
    return _svo_v12_canonical_slot(getattr(settings, "active_settings_slot", "OPTIMIZED") if settings is not None else "OPTIMIZED")


def _svo_v15_sync_standard_details_from_current_view(
    context: Optional[bpy.types.Context],
    settings: Optional[bpy.types.PropertyGroup],
    *,
    save_like_manual: bool = False,
    status: Optional[str] = None,
) -> bool:
    """Read Blender's live state into Standard detailed settings without applying saved values."""
    if context is None:
        context = getattr(bpy, "context", None)
    if context is None or settings is None:
        return False
    global _SVO_V12_SETTINGS_IO_GUARD
    old_guard = _SVO_V12_SETTINGS_IO_GUARD
    _SVO_V12_SETTINGS_IO_GUARD = True
    try:
        _svo_v12_set_active_slot_value(settings, "STANDARD")
        _svo_v11_sync_detail_settings_from_context(context, settings)
        try:
            settings.svo_workspace_active_name = _svo_v13_active_workspace_name(context)
        except Exception:
            pass
    finally:
        _SVO_V12_SETTINGS_IO_GUARD = old_guard
    try:
        if status:
            settings.status_text = status
    except Exception:
        pass
    if save_like_manual:
        try:
            _svo_v12_write_current_settings_file(
                settings,
                "STANDARD",
                context=context,
                include_layout=False,
            )
            _svo_v13_save_workspace_slot(
                context,
                settings,
                "STANDARD",
                include_layout=False,
            )
            if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path("STANDARD"), "STANDARD", context=context)
        except Exception:
            pass
    try:
        _tag_view3d_redraw(context)
    except Exception:
        pass
    return True


def _svo_v15_saved_payload_from_settings(context: Optional[bpy.types.Context], settings: Optional[bpy.types.PropertyGroup], slot: str) -> Dict[str, Any]:
    if settings is None:
        return {}
    try:
        return _svo_v12_payload(settings, _svo_v12_canonical_slot(slot), context=context)
    except Exception:
        return {"slot": _svo_v12_canonical_slot(slot), "values": _svo_v12_current_values(settings)}


def _svo_v15_restore_payload_to_settings_and_view(context: Optional[bpy.types.Context], settings: Optional[bpy.types.PropertyGroup], payload: Dict[str, Any], *, save_current: bool = True) -> bool:
    if context is None:
        context = getattr(bpy, "context", None)
    if context is None or settings is None or not isinstance(payload, dict):
        return False
    slot = _svo_v12_canonical_slot(payload.get("slot") or "OPTIMIZED")
    values = _svo_v12_extract_values(payload)
    if values:
        _svo_v12_apply_values_to_settings(settings, values)
    _svo_v12_set_active_slot_value(settings, slot)
    try:
        settings.svo_workspace_active_name = _svo_v13_active_workspace_name(context)
    except Exception:
        pass
    ok = _svo_v12_apply_details_to_view(
        context,
        settings,
        save_current=False,
        status="Optimized settings reapplied after save." if slot == "OPTIMIZED" else "Standard settings applied.",
    )
    if _svo_v16_can_apply_view3d_layout(context):
        try:
            _svo_v14_apply_view3d_layout(context, payload.get("view3d_layout"))
        except Exception:
            pass
    if save_current:
        try:
            _svo_v12_write_current_settings_file(settings, slot, context=context)
            _svo_v13_save_workspace_slot(context, settings, slot)
            if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(slot), slot, context=context)
        except Exception:
            pass
    try:
        _tag_view3d_redraw(context)
    except Exception:
        pass
    return bool(ok or values)


def _svo_v15_switch_to_standard_for_boundary(context: Optional[bpy.types.Context], *, reason: str, save_current: bool = True, preserve_optimized_payload: bool = False) -> Tuple[bool, Dict[str, Any]]:
    if context is None:
        context = getattr(bpy, "context", None)
    scene, settings = _svo_v15_scene_settings(context)
    if context is None or scene is None or settings is None:
        return False, {}
    current_slot = _svo_v15_active_slot(settings)
    if current_slot != "OPTIMIZED":
        return False, {}
    optimized_payload = _svo_v15_saved_payload_from_settings(context, settings, "OPTIMIZED") if preserve_optimized_payload else {}
    try:
        _request_navigation_guard_stop(context, restore=False)
    except Exception:
        pass
    try:
        _svo_v6_stop_idle_warm()
    except Exception:
        pass
    try:
        _svo_v8_stop_autosave_timer()
    except Exception:
        pass
    ok = False
    try:
        ok = _svo_v13_load_workspace_slot_to_settings(
            context,
            settings,
            "STANDARD",
            _svo_v13_active_workspace_name(context),
            save_current=save_current,
            apply_view=True,
            apply_layout=False,
            fallback_to_global=True,
        )
    except Exception:
        ok = False
    if not ok:
        try:
            data = _svo_v6_read_json(_svo_v12_slot_settings_path("STANDARD")) or _svo_v12_fallback_payload("STANDARD", "BALANCED")
            values = _svo_v12_extract_values(data)
            if values:
                _svo_v12_apply_values_to_settings(settings, values)
            _svo_v12_set_active_slot_value(settings, "STANDARD")
            ok = _svo_v12_apply_details_to_view(context, settings, save_current=False, status="Standard settings applied.")
            if save_current:
                _svo_v12_write_current_settings_file(settings, "STANDARD", context=context)
                _svo_v13_save_workspace_slot(context, settings, "STANDARD")
        except Exception:
            ok = False
    try:
        if ok:
            settings.status_text = "Switched to Standard before save." if reason == "save" else "Switched to Standard before file close or Blender exit."
    except Exception:
        pass
    return bool(ok), optimized_payload


def _svo_v15_save_pre_boundary(context: Optional[bpy.types.Context]) -> None:
    global _SVO_V15_SAVE_REAPPLY_PENDING, _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON
    _SVO_V15_SAVE_REAPPLY_PENDING = False
    _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON = ""
    scene, settings = _svo_v15_scene_settings(context)
    if settings is None or _svo_v15_active_slot(settings) != "OPTIMIZED":
        return
    ok, payload = _svo_v15_switch_to_standard_for_boundary(context, reason="save", save_current=True, preserve_optimized_payload=True)
    if ok:
        _SVO_V15_SAVE_REAPPLY_PENDING = True
        try:
            _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON = json.dumps(payload or {}, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON = ""


def _svo_v15_save_post_boundary(context: Optional[bpy.types.Context]) -> None:
    global _SVO_V15_SAVE_REAPPLY_PENDING, _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON
    if not _SVO_V15_SAVE_REAPPLY_PENDING:
        return
    _SVO_V15_SAVE_REAPPLY_PENDING = False
    payload: Dict[str, Any] = {}
    try:
        payload = json.loads(_SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON) if _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON else {}
    except Exception:
        payload = {}
    _SVO_V15_SAVE_OPTIMIZED_PAYLOAD_JSON = ""
    scene, settings = _svo_v15_scene_settings(context)
    if settings is None:
        return
    if not payload:
        try:
            data = _svo_v6_read_json(_svo_v12_slot_settings_path("OPTIMIZED")) or _svo_v12_fallback_payload("OPTIMIZED", "PERFORMANCE")
            payload = data if isinstance(data, dict) else {}
        except Exception:
            payload = {}
    _svo_v15_restore_payload_to_settings_and_view(context, settings, payload, save_current=True)


def _svo_v15_close_pre_boundary(context: Optional[bpy.types.Context], *, reason: str = "close") -> None:
    scene, settings = _svo_v15_scene_settings(context)
    if settings is None or _svo_v15_active_slot(settings) != "OPTIMIZED":
        return
    _svo_v15_switch_to_standard_for_boundary(context, reason=reason, save_current=True, preserve_optimized_payload=False)


def _svo_v15_standard_startup_or_load_sync(context: Optional[bpy.types.Context]) -> None:
    scene, settings = _svo_v15_scene_settings(context)
    if settings is None:
        return
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        _svo_v15_sync_standard_details_from_current_view(
            context,
            settings,
            save_like_manual=False,
            status="Current View Settings loaded into Detailed Settings without applying changes to Blender.",
        )
        try:
            _svo_v12_write_current_settings_file(
                settings,
                "STANDARD",
                context=context,
                include_layout=False,
            )
            _svo_v13_save_workspace_slot(
                context,
                settings,
                "STANDARD",
                include_layout=False,
            )
        except Exception:
            pass
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)


def _svo_v15_insert_handler_first(handler_list: Any, fn: Any) -> None:
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass
    try:
        handler_list.insert(0, fn)
    except Exception:
        try:
            if fn not in handler_list:
                handler_list.append(fn)
        except Exception:
            pass


def _svo_v15_remove_handler(handler_list: Any, fn: Any) -> None:
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass


def _svo_v15_sync_file_boundary_handlers(enabled: bool) -> None:
    handlers = getattr(bpy.app, "handlers", None)
    if handlers is None:
        return
    pairs = (
        (getattr(handlers, "load_pre", []), _svo_plus_load_pre),
        (getattr(handlers, "load_post", []), _svo_plus_load_post),
        (getattr(handlers, "save_pre", []), _svo_plus_save_pre),
        (getattr(handlers, "save_post", []), _svo_plus_save_post),
    )
    for handler_list, fn in pairs:
        if enabled:
            _svo_v15_insert_handler_first(handler_list, fn)
        else:
            _svo_v15_remove_handler(handler_list, fn)
    try:
        exit_pre = getattr(handlers, "exit_pre", None)
        if exit_pre is not None:
            if enabled:
                _svo_v15_insert_handler_first(exit_pre, _svo_plus_exit_pre)
            else:
                _svo_v15_remove_handler(exit_pre, _svo_plus_exit_pre)
    except Exception:
        pass


def set_file_boundary_handlers_enabled(enabled: bool, context=None) -> bool:
    """Enable/disable SVO file-boundary handlers from 常時機能切り替え."""
    del context
    try:
        _svo_v15_sync_file_boundary_handlers(bool(enabled))
        if not bool(enabled):
            _svo_v8_stop_autosave_timer()
            _svo_v6_stop_idle_warm()
        return bool(enabled)
    except Exception:
        return False


# -----------------------------------------------------------------------------
# Handlers
# -----------------------------------------------------------------------------


@persistent
def _svo_plus_load_pre(_dummy: Any) -> None:
    _svo_v8_stop_autosave_timer()
    _svo_v6_stop_idle_warm()
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        _svo_v15_close_pre_boundary(getattr(bpy, "context", None), reason="load_pre")
    except Exception:
        pass
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)
    return None


@persistent
def _svo_plus_load_post(_dummy: Any) -> None:
    _svo_v8_stop_autosave_timer()
    _svo_v6_stop_idle_warm()
    try:
        _svo_v15_standard_startup_or_load_sync(getattr(bpy, "context", None))
    except Exception:
        pass
    return None


@persistent
def _svo_plus_save_pre(_dummy: Any) -> None:
    global _SVO_V9_SAVE_REAPPLY_PENDING, _SVO_V9_SAVE_SNAPSHOT_JSON
    _SVO_V9_SAVE_REAPPLY_PENDING = False
    _SVO_V9_SAVE_SNAPSHOT_JSON = ""
    _svo_v8_stop_autosave_timer()
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        _svo_v15_save_pre_boundary(getattr(bpy, "context", None))
    except Exception:
        pass
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)
    return None


@persistent
def _svo_plus_save_post(_dummy: Any) -> None:
    global _SVO_V9_SAVE_REAPPLY_PENDING, _SVO_V9_SAVE_SNAPSHOT_JSON
    _SVO_V9_SAVE_REAPPLY_PENDING = False
    _SVO_V9_SAVE_SNAPSHOT_JSON = ""
    _svo_v8_stop_autosave_timer()
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        _svo_v15_save_post_boundary(getattr(bpy, "context", None))
    except Exception:
        pass
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)
    return None


@persistent
def _svo_plus_exit_pre(_dummy: Any) -> None:
    _svo_v8_stop_autosave_timer()
    _svo_v6_stop_idle_warm()
    old = _svo_v16_begin_unsafe_ui_suppression()
    try:
        _svo_v15_close_pre_boundary(getattr(bpy, "context", None), reason="exit_pre")
    except Exception:
        pass
    finally:
        _svo_v16_end_unsafe_ui_suppression(old)
    return None


def _svo_plus_delayed_enable_apply() -> Optional[float]:
    _svo_v8_stop_autosave_timer()
    _svo_v6_stop_idle_warm()
    return None


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------



# -----------------------------------------------------------------------------
# v11: Blender-standard detailed settings UI and positive setting semantics
# -----------------------------------------------------------------------------

# v11 changes the detailed options from "disable this" controls to target values
# that mirror Blender's own UI wording and boolean direction. Existing legacy
# properties are intentionally kept for compatibility with older preset JSON
# files, but the UI and runtime application below use the standard target props.

_SVO_V11_DEFAULTS: Dict[str, Any] = {
    # 3D View > Viewport Shading
    "target_shading_type": "SOLID",
    "target_shading_light": "FLAT",
    "target_shading_color_type": "MATERIAL",
    "target_wireframe_color_type": "THEME",
    "target_background_type": "THEME",
    "target_cavity_type": "SCREEN",
    "target_use_compositor": "DISABLED",
    # Preferences > System / GPU drawing path. gpu_backend changes require a Blender restart to fully take effect,
    # but exposing it here keeps the preset target clear for RTX-class Windows systems.
    "target_gpu_backend": "OPENGL",
    "target_gpu_preferred_device": "AUTO",
    "target_show_shadows": False,
    "target_shadow_intensity": 0.25,
    "target_show_cavity": False,
    "target_show_object_outline": True,
    "target_show_specular_highlight": False,
    "target_show_xray": False,
    "target_xray_alpha": 0.50,
    "target_show_xray_wireframe": False,
    "target_xray_alpha_wireframe": 0.50,
    "target_show_backface_culling": False,
    "target_use_scene_lights": False,
    "target_use_scene_world": False,
    "target_use_scene_lights_render": False,
    "target_use_scene_world_render": False,
    "target_use_dof": False,
    "target_studiolight_intensity": 1.0,
    "target_studiolight_background_alpha": 0.0,
    "target_studiolight_background_blur": 0.0,
    # 3D View > Overlays
    "target_show_overlays": True,
    "target_show_relationship_lines": False,
    "target_show_floor": True,
    "target_show_axis_x": True,
    "target_show_axis_y": True,
    "target_show_axis_z": True,
    "target_show_text": True,
    "target_show_stats": False,
    "target_show_extras": True,
    "target_show_wireframes": False,
    "target_wireframe_opacity": 0.50,
    "target_wireframe_threshold": 0.50,
    "target_show_outline_selected": True,
    "target_show_object_origins": True,
    "target_show_object_origins_all": False,
    "target_show_motion_paths": False,
    "target_show_annotation": True,
    "target_show_bones": True,
    "target_show_faces": True,
    "target_show_face_center": False,
    "target_show_face_orientation": False,
    "target_show_edge_crease": False,
    "target_show_edge_sharp": False,
    "target_show_edge_bevel_weight": False,
    "target_show_edge_seams": True,
    "target_show_extra_indices": False,
    "target_show_extra_edge_length": False,
    "target_show_extra_edge_angle": False,
    "target_show_extra_face_area": False,
    "target_show_extra_face_angle": False,
    "target_show_freestyle_edge_marks": False,
    "target_show_freestyle_face_marks": False,
    "target_show_face_normals": False,
    "target_show_vertex_normals": False,
    "target_show_split_normals": False,
    "target_show_curve_normals": False,
    "target_normals_length": 0.10,
    "target_show_fade_inactive": False,
    "target_fade_inactive_alpha": 0.0,
    "target_show_face_sets": False,
    "target_show_sculpt_mask": False,
    "target_show_onion_skins": True,
    "target_use_gpencil_grid": True,
    "target_use_gpencil_onion_skin": True,
    "target_use_gpencil_edit_lines": True,
    "target_use_debug_freeze_view_culling": False,
    # 3D View > Gizmos
    "target_show_gizmo": True,
    "target_show_gizmo_navigate": False,
    "target_show_gizmo_tool": True,
    "target_show_gizmo_context": True,
    "target_show_gizmo_object_translate": True,
    "target_show_gizmo_object_rotate": True,
    "target_show_gizmo_object_scale": True,
    "target_show_gizmo_modifier": True,
    "target_show_gizmo_light_size": True,
    "target_show_gizmo_light_look_at": True,
    "target_show_gizmo_camera_lens": True,
    "target_show_gizmo_camera_dof_distance": True,
    "target_show_gizmo_empty_image": True,
    "target_show_gizmo_empty_force_field": True,
    # 3D View > Object Type Visibility / Selectability
    "target_show_object_viewport_mesh": True,
    "target_show_object_viewport_camera": True,
    "target_show_object_viewport_light": True,
    "target_show_object_viewport_empty": True,
    "target_show_object_viewport_armature": True,
    "target_show_object_viewport_curve": True,
    "target_show_object_viewport_surface": True,
    "target_show_object_viewport_font": True,
    "target_show_object_viewport_metaball": True,
    "target_show_object_viewport_lattice": True,
    "target_show_object_viewport_speaker": False,
    "target_show_object_viewport_light_probe": True,
    "target_show_object_viewport_volume": True,
    "target_show_object_viewport_grease_pencil": True,
    "target_show_object_viewport_pointcloud": True,
    "target_show_object_select_mesh": True,
    "target_show_object_select_camera": True,
    "target_show_object_select_light": True,
    "target_show_object_select_empty": True,
    "target_show_object_select_armature": True,
    "target_show_object_select_curve": True,
    "target_show_object_select_surface": True,
    "target_show_object_select_font": True,
    "target_show_object_select_metaball": True,
    "target_show_object_select_lattice": True,
    "target_show_object_select_speaker": False,
    "target_show_object_select_light_probe": True,
    "target_show_object_select_volume": True,
    "target_show_object_select_grease_pencil": True,
    "target_show_object_select_pointcloud": True,
    # 3D View > Regions
    "target_show_region_toolbar": True,
    "target_show_region_tool_header": True,
    "target_show_region_ui": True,
    "target_show_region_hud": True,
    "target_show_region_asset_shelf": True,
    # Object > Viewport Display
    "target_object_display_type": "SOLID",
    "target_display_bounds_type": "BOX",
    "target_object_show_name": False,
    "target_object_show_axis": False,
    "target_object_show_texture_space": False,
    "target_object_show_bounds": False,
    "target_object_show_wire": False,
    "target_object_show_all_edges": False,
    "target_object_show_in_front": False,
    "target_object_show_transparent": True,
    "target_object_selectable": True,
    "target_object_show_instancer_for_viewport": True,
    "target_object_use_simulation_cache": True,
    # Modifiers and constraints use the same positive direction as Blender UI.
    "target_show_viewport_modifiers": True,
    "target_show_subdivision_modifiers": True,
    "target_show_geometry_nodes": True,
    "target_show_simulation_modifiers": True,
    "target_show_deformer_modifiers": True,
    "target_show_generator_modifiers": True,
    "target_show_normal_data_modifiers": True,
    "target_show_other_modifiers": True,
    "target_object_constraints_enabled": True,
    "target_pose_constraints_enabled": True,
    # Preferences > System / View / Input / Edit
    "target_viewport_aa": "OFF",
    "target_gl_texture_limit": "CLAMP_2048",
    "target_texture_time_out": 1800,
    "target_vbo_time_out": 1800,
    "target_texture_collection_rate": 1800,
    "target_vbo_collection_rate": 1800,
    "target_use_gpu_subdivision": False,
    "target_use_overlay_smooth_wire": False,
    "target_use_edit_mode_smooth_wire": False,
    "target_shader_compilation_method": "THREAD",
    "target_gpu_shader_workers": 0,
    "target_memory_cache_limit": 4096,
    "target_use_region_overlap": False,
    "target_use_reduce_motion": True,
    "target_show_navigate_ui": False,
    "target_show_statusbar_stats": False,
    "target_show_statusbar_memory": False,
    "target_show_statusbar_vram": False,
    "target_show_statusbar_version": False,
    "target_use_mouse_depth_navigate": False,
    "target_use_zoom_to_mouse": False,
    "target_use_rotate_around_active": False,
    "target_use_auto_perspective": False,
    "target_smooth_view": 0,
    "target_view_rotate_method": "TURNTABLE",
    "target_view_zoom_method": "SCALE",
    "target_view_zoom_axis": "VERTICAL",
    "target_ndof_show_guide_orbit_axis": False,
    "target_ndof_show_guide_orbit_center": False,
    "target_use_global_undo": True,
    "target_undo_steps": 32,
    "target_undo_memory_limit": 0,
    "target_use_auto_keying": False,
    "target_use_auto_keyframe_insert_needed": False,
    "target_use_snap": False,
    "target_use_mesh_automerge": False,
    "target_use_mesh_automerge_and_split": False,
    "target_use_keyframe_insert_auto": False,
    # Render-preview and engine viewport cost controls. These are restored from the baseline
    # snapshot and are applied only while the optimizer toggle is ON.
    "include_render_preview_settings": True,
    "target_render_preview_pixel_size": "AUTO",
    "target_render_use_high_quality_normals": False,
    "target_render_use_simplify_normals": False,
    "target_render_use_persistent_data": False,
    "target_scene_viewport_aa": "FXAA",
    "target_scene_render_aa": "8",
    "target_eevee_taa_samples": 8,
    "target_eevee_use_taa_reprojection": True,
    "target_eevee_use_shadows": False,
    "target_eevee_shadow_pool_size": "256",
    "target_eevee_shadow_resolution_scale": 0.5,
    "target_eevee_shadow_ray_count": 1,
    "target_eevee_shadow_step_count": 4,
    "target_eevee_use_raytracing": False,
    "target_eevee_ray_tracing_method": "SCREEN",
    "target_eevee_volumetric_tile_size": "8",
    "target_eevee_volumetric_samples": 16,
    "target_eevee_volumetric_ray_depth": 8,
    "target_eevee_use_volumetric_shadows": False,
    "target_eevee_volumetric_shadow_samples": 4,
    "target_cycles_preview_samples": 16,
    "target_cycles_use_preview_denoising": False,
    "target_cycles_preview_denoising_quality": "FAST",
    "target_cycles_texture_limit": "1024",
    "target_cycles_volume_preview_step_rate": 2.0,
    "target_cycles_preview_dicing_rate": 16.0,
}


# Latency-safe defaults used when the Detailed Settings property group is first
# created. These are defined before v11 property annotations are materialized.
_SVO_V11_DEFAULTS.update({
    "include_viewport_prewarm": False,
    "enable_navigation_guard": False,
    "prewarm_on_mouse_move": False,
    "prewarm_view_matrix_nudge": False,
    "enable_idle_warm_pulse": False,
    "idle_pulse_view_layer_update": False,
    "idle_pulse_redraw_iterations": 0,
    "prewarm_redraw_iterations": 0,
    "auto_save_workspace_preset_changes": False,
    "external_backup_on_register": False,
    "external_backup_on_startup": False,
    "external_backup_before_apply": False,
    "external_backup_on_file_load": False,
    "keep_backup_history": False,
    "target_texture_time_out": 0,
    "target_vbo_time_out": 0,
    "target_texture_collection_rate": 1800,
    "target_vbo_collection_rate": 1800,
    "target_viewport_aa": "OFF",
    "target_scene_viewport_aa": "OFF",
    "target_use_mouse_depth_navigate": False,
    "target_use_zoom_to_mouse": False,
    "target_use_rotate_around_active": False,
    "target_use_auto_perspective": False,
    "target_smooth_view": 0,
    "target_show_navigate_ui": False,
})
MAX_SPEED_DEFAULTS.update(_SVO_V11_DEFAULTS)

# Capture everything v11 can change so OFF and external baseline restore cover it.
SCENE_RENDER_PROPS = tuple(dict.fromkeys(SCENE_RENDER_PROPS + (
    "simplify_texture_size", "simplify_gpencil_modifier", "simplify_gpencil_shader_fx", "simplify_gpencil_antialiasing",
    "simplify_gpencil_onplay", "simplify_gpencil_view_fill", "simplify_gpencil_tint", "use_simplify_normals",
    "use_high_quality_normals", "preview_pixel_size", "use_lock_interface", "use_persistent_data",
)))
SPACE_PROPS = tuple(dict.fromkeys(SPACE_PROPS + (
    "show_object_viewport_curves", "show_object_viewport_surf", "show_object_viewport_meta",
    "show_object_select_curves", "show_object_select_surf", "show_object_select_meta",
    "show_gizmo_modifier", "show_gizmo_light_size", "show_gizmo_light_look_at", "show_gizmo_camera_lens",
    "show_gizmo_camera_dof_distance", "show_gizmo_empty_image", "show_gizmo_empty_force_field",
)))
SHADING_PROPS = tuple(dict.fromkeys(SHADING_PROPS + (
    "wireframe_color_type", "background_type", "cavity_type", "use_compositor", "use_dof", "studiolight_intensity",
    "studiolight_background_alpha", "studiolight_background_blur", "use_scene_lights_render", "use_scene_world_render",
)))
OVERLAY_PROPS = tuple(dict.fromkeys(OVERLAY_PROPS + (
    "show_bones", "show_extra_edge_length", "show_extra_edge_angle", "show_extra_face_area", "show_extra_face_angle",
    "show_freestyle_edge_marks", "show_freestyle_face_marks", "show_curve_normals", "show_sculpt_face_sets",
    "show_sculpt_mask", "show_onion_skins", "use_gpencil_grid", "use_gpencil_onion_skin", "use_gpencil_edit_lines",
    "use_debug_freeze_view_culling", "wireframe_threshold",
)))
OBJECT_PROPS = tuple(dict.fromkeys(OBJECT_PROPS + (
    "show_all_edges", "show_transparent", "use_simulation_cache", "display_bounds_type", "hide_viewport",
)))

SCENE_DISPLAY_PROPS = (
    "viewport_aa", "render_aa",
)
SCENE_EEVEE_PROPS = (
    "taa_samples", "use_taa_reprojection", "use_shadows", "shadow_pool_size", "shadow_resolution_scale",
    "shadow_ray_count", "shadow_step_count", "use_raytracing", "ray_tracing_method", "volumetric_tile_size",
    "volumetric_samples", "volumetric_ray_depth", "use_volumetric_shadows", "volumetric_shadow_samples",
)
SCENE_CYCLES_PROPS = (
    "preview_samples", "use_preview_denoising", "preview_denoising_quality", "texture_limit",
    "volume_preview_step_rate", "preview_dicing_rate",
)
PREFERENCE_SYSTEM_PROPS = tuple(dict.fromkeys(PREFERENCE_SYSTEM_PROPS + (
    "shader_compilation_method", "gpu_shader_workers", "memory_cache_limit", "use_region_overlap",
)))
PREFERENCE_INPUT_PROPS = tuple(dict.fromkeys(PREFERENCE_INPUT_PROPS + (
    "view_rotate_method", "view_zoom_method", "view_zoom_axis", "ndof_show_guide_orbit_axis", "ndof_show_guide_orbit_center",
    "show_nDOF_settings", "show_ndof_settings", "use_ndof_orbit", "use_ndof_pan", "use_ndof_zoom",
)))
PREFERENCE_VIEW_PROPS = tuple(dict.fromkeys(PREFERENCE_VIEW_PROPS + (
    "use_reduce_motion", "show_statusbar_stats", "show_statusbar_memory", "show_statusbar_vram", "show_statusbar_version",
)))
PREFERENCE_EDIT_PROPS = tuple(dict.fromkeys(PREFERENCE_EDIT_PROPS + (
    "use_auto_keying_warning", "auto_keying_mode",
)))
TOOL_SETTINGS_PROPS = tuple(dict.fromkeys(TOOL_SETTINGS_PROPS + (
    "use_mesh_automerge_and_split", "use_keyframe_insert_auto", "use_snap_edit", "use_snap_nonedit",
)))

_SVO_V11_TRANSLATIONS = {
    "Detailed Settings": "詳細設定",
    "Targets": "適用対象",
    "Apply to all scenes": "全シーンに適用",
    "Object Scope": "オブジェクト対象範囲",
    "Use this section": "このセクションを反映",
    "Render Properties > Simplify": "レンダープロパティ > 簡略化",
    "3D Viewport > Viewport Shading": "3Dビュー > シェーディング",
    "3D Viewport > Overlays": "3Dビュー > オーバーレイ",
    "3D Viewport > Gizmos": "3Dビュー > ギズモ",
    "3D Viewport > Object Type Visibility": "3Dビュー > 種類の表示",
    "3D Viewport > Object Type Selectability": "3Dビュー > 種類の選択",
    "3D Viewport > Regions": "3Dビューポート > リージョン",
    "Object Properties > Viewport Display": "オブジェクト > ビューポート表示",
    "Modifier Viewport Display": "モディファイア > ビューポート表示",
    "Constraints": "制約",
    "Particle Preview": "パーティクルプレビュー",
    "Preferences > System": "プリファレンス > システム",
    "Preferences > Navigation": "プリファレンス > ナビゲーション",
    "Preferences > Editing / Tool Settings": "プリファレンス > 編集 / ツール設定",
    "Navigation Warmup": "ナビゲーション事前ウォームアップ",
    "Display Mode": "表示モード",
    "Lighting": "ライティング",
    "Color": "カラー",
    "Wire Color": "ワイヤーカラー",
    "Background": "背景",
    "Cavity Type": "キャビティタイプ",
    "Compositor": "コンポジター",
    "Shadows": "影",
    "Shadow Intensity": "影の強さ",
    "Cavity": "キャビティ",
    "Object Outline": "オブジェクトアウトライン",
    "Specular Highlights": "スペキュラーハイライト",
    "X-Ray": "透過表示",
    "X-Ray Opacity": "透過表示の不透明度",
    "X-Ray Wireframe": "ワイヤーフレームの透過表示",
    "Wireframe X-Ray Opacity": "ワイヤーの透過の不透明度",
    "Backface Culling": "背面カリング",
    "Scene Lights": "シーンライト",
    "Scene World": "シーンワールド",
    "Rendered Scene Lights": "レンダー用シーンライト",
    "Rendered Scene World": "レンダー用シーンワールド",
    "Depth of Field": "被写界深度",
    "Studio Light Intensity": "スタジオライトの強さ",
    "Studio Light Background Alpha": "スタジオライト背景アルファ",
    "Studio Light Background Blur": "スタジオライト背景ぼかし",
    "Overlays": "オーバーレイ",
    "Relationship Lines": "リレーションライン",
    "Floor": "床",
    "X Axis": "X軸",
    "Y Axis": "Y軸",
    "Z Axis": "Z軸",
    "Text Info": "テキスト情報",
    "Statistics": "統計",
    "Extras": "その他表示",
    "Wireframes": "ワイヤーフレーム",
    "Wireframe Opacity": "ワイヤーフレーム不透明度",
    "Wireframe Threshold": "ワイヤーフレームしきい値",
    "Outline Selected": "選択アウトライン",
    "Object Origins": "オブジェクト原点",
    "All Object Origins": "全オブジェクト原点",
    "Motion Paths": "モーションパス",
    "Annotations": "注釈",
    "Bones": "ボーン",
    "Faces": "面",
    "Face Center": "面中心",
    "Face Orientation": "面の向き",
    "Creases": "クリース",
    "Sharp Edges": "シャープ辺",
    "Bevel Weights": "ベベルウェイト",
    "Seams": "シーム",
    "Indices": "インデックス",
    "Edge Length": "辺の長さ",
    "Edge Angle": "辺の角度",
    "Face Area": "面積",
    "Face Angle": "面の角度",
    "Freestyle Edge Marks": "Freestyle辺マーク",
    "Freestyle Face Marks": "Freestyle面マーク",
    "Face Normals": "面法線",
    "Vertex Normals": "頂点法線",
    "Split Normals": "分割法線",
    "Curve Normals": "カーブ法線",
    "Normals Size": "法線サイズ",
    "Fade Inactive": "非アクティブをフェード",
    "Fade Inactive Alpha": "非アクティブフェード量",
    "Sculpt Face Sets": "スカルプト面セット",
    "Sculpt Mask": "スカルプトマスク",
    "Onion Skins": "オニオンスキン",
    "Grease Pencil Grid": "グリースペンシルグリッド",
    "Grease Pencil Onion Skin": "グリースペンシルオニオンスキン",
    "Grease Pencil Edit Lines": "グリースペンシル編集線",
    "Freeze View Culling": "ビューカリング固定",
    "Gizmos": "ギズモ",
    "Navigate": "ナビゲート",
    "Tool": "ツール",
    "Context": "コンテキスト",
    "Translate": "移動",
    "Rotate": "回転",
    "Scale": "スケール",
    "Modifier Gizmos": "モディファイアギズモ",
    "Light Size": "ライトサイズ",
    "Light Look-at": "ライト注視点",
    "Camera Lens": "カメラレンズ",
    "Camera DOF Distance": "カメラ被写界深度距離",
    "Empty Image": "エンプティ画像",
    "Empty Force Field": "エンプティ力場",
    "Mesh": "メッシュ",
    "Camera": "カメラ",
    "Light": "ライト",
    "Empty": "エンプティ",
    "Armature": "アーマチュア",
    "Curve": "カーブ",
    "Surface": "サーフェス",
    "Text": "テキスト",
    "Metaball": "メタボール",
    "Lattice": "ラティス",
    "Speaker": "スピーカー",
    "Light Probe": "ライトプローブ",
    "Volume": "ボリューム",
    "Grease Pencil": "グリースペンシル",
    "Point Cloud": "ポイントクラウド",
    "Toolbar": "ツールバー",
    "Tool Header": "ツールヘッダー",
    "Sidebar": "サイドバー",
    "HUD": "HUD",
    "Asset Shelf": "アセットシェルフ",
    "Display As": "表示方法",
    "Bounds Type": "バウンディングタイプ",
    "Name": "名前",
    "Axis": "軸",
    "Texture Space": "テクスチャ空間",
    "Bounds": "バウンディング",
    "Wire": "ワイヤー",
    "All Edges": "全ての辺",
    "In Front": "最前面",
    "Transparent": "透過",
    "Selectable": "選択可能",
    "Instance in Viewport": "ビューポートのインスタンス",
    "Simulation Cache": "シミュレーションキャッシュ",
    "Show Modifiers in Viewport": "ビューポートでモディファイアを表示",
    "Subdivision / Multires": "サブディビジョン / マルチレゾ",
    "Geometry Nodes": "ジオメトリノード",
    "Simulation Modifiers": "シミュレーション系モディファイア",
    "Deform Modifiers": "変形系モディファイア",
    "Generate Modifiers": "生成系モディファイア",
    "Normals / Data Modifiers": "法線 / データ系モディファイア",
    "Other Modifiers": "その他モディファイア",
    "Object Constraints": "オブジェクト制約",
    "Pose Constraints": "ポーズ制約",
    "Display Percentage": "表示率",
    "Display Step": "表示ステップ",
    "Viewport Anti-Aliasing": "ビューポートアンチエイリアス",
    "Texture Limit": "テクスチャ制限",
    "Texture Time Out": "テクスチャタイムアウト",
    "VBO Time Out": "VBOタイムアウト",
    "Texture Collection Rate": "テクスチャ回収間隔",
    "VBO Collection Rate": "VBO回収間隔",
    "GPU Subdivision": "GPUサブディビジョン",
    "Overlay Smooth Wires": "オーバーレイ滑らかワイヤー",
    "Edit Mode Smooth Wires": "編集モード滑らかワイヤー",
    "Shader Compilation": "シェーダーコンパイル",
    "GPU Shader Workers": "GPUシェーダーワーカー",
    "Memory Cache Limit": "メモリキャッシュ制限",
    "Region Overlap": "リージョン重なり",
    "Navigate UI": "ナビゲーションUI",
    "Reduce Motion": "動きを減らす",
    "Status Bar Statistics": "ステータスバー統計",
    "Status Bar Memory": "ステータスバーメモリ",
    "Status Bar VRAM": "ステータスバーVRAM",
    "Status Bar Version": "ステータスバーバージョン",
    "Mouse Depth Navigation": "マウス深度ナビゲーション",
    "Zoom to Mouse Position": "マウス位置へズーム",
    "Rotate Around Active Selection": "アクティブ選択を中心に回転",
    "Auto Perspective": "自動パース切替",
    "Smooth View": "スムーズビュー",
    "View Rotate Method": "ビュー回転方式",
    "View Zoom Method": "ビューズーム方式",
    "View Zoom Axis": "ビューズーム軸",
    "NDOF Orbit Axis Guide": "NDOF回転軸ガイド",
    "NDOF Orbit Center Guide": "NDOF回転中心ガイド",
    "Global Undo": "グローバルUndo",
    "Undo Steps": "Undo回数",
    "Undo Memory Limit": "Undoメモリ制限",
    "Auto Keying": "自動キー挿入",
    "Only Insert Needed": "必要なキーのみ挿入",
    "Snapping": "スナップ",
    "Auto Merge": "自動マージ",
    "Auto Merge & Split": "自動マージと分割",
    "Record Auto Keying": "自動キー記録",
    "This panel uses Blender-standard labels and ON/OFF direction. Values shown here are the target settings applied only while the optimizer toggle is ON; turning it OFF restores the saved baseline state.": "このパネルはBlender標準UIに近い表記とON/OFF方向で表示します。ここに表示される値は、最適化トグルがONの間だけ反映される目標設定です。OFFにすると保存済みの基準状態へ戻ります。",
    "Load Current Blender Settings into Details": "現在のビュー設定を読み込み",
    "Details now match the current Blender settings.": "現在のビュー設定を詳細設定へ読み込みました。",
    "Turn the optimizer OFF before loading current settings into Details.": "現在の設定を詳細設定へ反映する前に、最適化をOFFにしてください。",
    "Detailed Settings Overview": "詳細設定一覧",
    "Use these controls as a Blender-standard settings overview. ON means the same as Blender default UI; OFF means the item is temporarily off only while optimization is ON.": "この項目はBlender標準UIに近い設定一覧として使用します。ONはBlender標準UIと同じ意味で、OFFは最適化ON中だけ一時的にOFFにする意味です。",
}
_TRANSLATIONS_JA.update(_SVO_V11_TRANSLATIONS)
_TRANSLATION_DICT["ja_JP"].update({("*", key): value for key, value in _SVO_V11_TRANSLATIONS.items()})

_SVO_V12_TRANSLATIONS = {
    "Performance Priority: High": "パフォーマンス優先：高",
    "Performance Priority: Medium": "パフォーマンス優先：中",
    "Performance Priority: Low": "パフォーマンス優先：小",
    "Balanced Priority": "バランス優先",
    "Quality Priority: Low": "クオリティ優先：小",
    "Quality Priority: Medium": "クオリティ優先：中",
    "Quality Priority: High": "クオリティ優先：高",
    "Maximum viewport speed preset. Strongly reduces redraw cost by using wire/bounds display, hiding overlays and gizmos, limiting textures, disabling expensive viewport evaluation, keeping VBO/texture cache warm, and simplifying orbit/pan/zoom startup. Visual fidelity and edit feedback are intentionally reduced.": "最大速度用プリセットです。ワイヤー/バウンディング表示、オーバーレイとギズモの非表示、テクスチャ制限、高負荷なビューポート評価の抑制、VBO/テクスチャキャッシュ保持、回転・移動・ズーム初動の単純化で再描画負荷を強く下げます。画質と編集フィードバックは意図的に減ります。",
    "Strong speed preset for heavy scenes. Uses flat solid display, suppresses most helper drawing, lowers Simplify and texture limits, keeps cache data warm, and reduces modifier/particle/navigation overhead while preserving more object visibility than the High preset.": "重いシーン向けの強めの速度プリセットです。フラットなソリッド表示、多くの補助描画の抑制、簡略化とテクスチャ制限、キャッシュ保持、モディファイア・パーティクル・ナビゲーション負荷の削減を行い、高プリセットよりオブジェクト視認性を残します。",
    "Mild speed preset for normal editing. Keeps solid object feedback and most safe editing behavior while disabling the redraw costs most likely to cause orbit, pan, and zoom start lag: anti-aliasing, smooth view, depth lookup, heavy overlays, and unnecessary preview effects.": "通常編集向けの軽めの速度プリセットです。ソリッド表示と安全な編集挙動を保ちながら、回転・移動・ズーム開始ラグの原因になりやすいアンチエイリアス、スムーズビュー、深度参照、重いオーバーレイ、不要なプレビュー効果を抑えます。",
    "Balanced preset for day-to-day work. Keeps normal solid visual feedback, modifiers, selection, and common overlays usable while reducing avoidable AA, cache churn, navigation transition, particle, texture, and material-preview costs.": "日常作業向けのバランスプリセットです。通常のソリッド視認性、モディファイア、選択、一般的なオーバーレイを使える状態で残しつつ、不要なAA、キャッシュ破棄、ナビゲーション遷移、パーティクル、テクスチャ、マテリアルプレビュー負荷を下げます。",
    "Light quality preset. Preserves more shading, outlines, gizmos, and helper visibility than Balanced, but still limits expensive preview samples and navigation-start costs so the viewport remains responsive.": "軽いクオリティ寄りプリセットです。バランスよりシェーディング、アウトライン、ギズモ、補助表示を多く残しつつ、高負荷なプレビューサンプルとナビゲーション初動コストを制限して反応性を保ちます。",
    "Quality-oriented preset. Keeps material inspection, higher texture limits, modifiers, scene helpers, and moderate preview samples while still using cache warmup and simpler navigation settings to reduce first-move lag.": "クオリティ寄りプリセットです。マテリアル確認、高めのテクスチャ制限、モディファイア、シーン補助表示、中程度のプレビューサンプルを維持しつつ、キャッシュウォームアップと単純なナビゲーション設定で初動ラグを減らします。",
    "Maximum visual fidelity preset. Keeps rendered/material visual checks, higher anti-aliasing, scene lights/world, modifiers, and high texture limits. This is the heaviest built-in preset and is intended for look-development checks rather than fastest navigation.": "最大画質用プリセットです。レンダー/マテリアルの見た目確認、高めのアンチエイリアス、シーンライト/ワールド、モディファイア、高いテクスチャ制限を維持します。内蔵プリセットでは最も重く、最速ナビゲーションではなくルック確認向けです。",
    "Graphics Backend": "グラフィックバックエンド",
    "Preferred GPU Device": "優先GPUデバイス",
    "Render Preview / Engine": "レンダープレビュー / エンジン",
    "Include Render Preview Settings": "レンダープレビュー設定を対象にする",
    "Enable render-preview and engine viewport settings such as preview pixel size, EEVEE viewport samples, Cycles preview samples, and scene display anti-aliasing. These settings affect Material Preview or Rendered viewport cost and are restored when the optimizer turns OFF.": "プレビューピクセルサイズ、EEVEEビューポートサンプル、Cyclesプレビューサンプル、シーン表示AAなどのレンダープレビュー/エンジン系設定を有効にします。マテリアルプレビューやレンダー表示の負荷に影響し、最適化OFF時に復元されます。",
    "Preview Pixel Size": "プレビューピクセルサイズ",
    "High Quality Normals": "高品質法線",
    "Simplify Normals": "法線を簡略化",
    "Persistent Data": "永続データ",
    "Scene Viewport AA": "シーン表示AA",
    "Scene Render AA": "シーンレンダーAA",
    "EEVEE Viewport Samples": "EEVEEビューポートサンプル",
    "EEVEE TAA Reprojection": "EEVEE TAA再投影",
    "EEVEE Shadows": "EEVEE影",
    "EEVEE Shadow Pool Size": "EEVEEシャドウプールサイズ",
    "EEVEE Shadow Resolution Scale": "EEVEE影解像度スケール",
    "EEVEE Shadow Ray Count": "EEVEE影レイ数",
    "EEVEE Shadow Step Count": "EEVEE影ステップ数",
    "EEVEE Ray Tracing": "EEVEEレイトレーシング",
    "EEVEE Ray Tracing Method": "EEVEEレイトレース方式",
    "EEVEE Volume Tile Size": "EEVEEボリュームタイルサイズ",
    "EEVEE Volume Samples": "EEVEEボリュームサンプル",
    "EEVEE Volume Ray Depth": "EEVEEボリュームレイ深度",
    "EEVEE Volume Shadows": "EEVEEボリューム影",
    "EEVEE Volume Shadow Samples": "EEVEEボリューム影サンプル",
    "Cycles Preview Samples": "Cyclesプレビューサンプル",
    "Cycles Preview Denoising": "Cyclesプレビューデノイズ",
    "Cycles Preview Denoising Quality": "Cyclesプレビューデノイズ品質",
    "Cycles Texture Limit": "Cyclesテクスチャ制限",
    "Cycles Volume Preview Step Rate": "Cyclesボリュームプレビューステップ率",
    "Cycles Preview Dicing Rate": "Cyclesプレビューダイシング率",
    "Same as Preferences > System > GPU Backend. Vulkan is recommended first for RTX-class systems, but the change requires restarting Blender to fully take effect; use OpenGL if Vulkan is unstable.": "プリファレンス > システム > GPUバックエンドと同じ項目です。RTXクラスではまずVulkan推奨ですが、完全反映にはBlender再起動が必要です。Vulkanが不安定な場合はOpenGLを使ってください。",
    "Same as Preferences > System > GPU Preferred Device. Auto lets Blender choose the best available GPU; on Windows, also force blender.exe to the RTX GPU in Windows/NVIDIA settings.": "プリファレンス > システム > 優先GPUデバイスと同じ項目です。AutoはBlenderに最適GPUを選ばせます。Windowsでは追加でWindows/NVIDIA側でblender.exeをRTX GPUへ固定してください。",
    "Same as Render Settings > Preview Pixel Size. Larger pixel size is lighter for preview drawing; 1x is highest quality.": "レンダー設定 > プレビューピクセルサイズと同じ項目です。大きい値ほどプレビュー描画は軽く、1xが最高品質です。",
    "Same as Render Settings > High Quality Normals. OFF is lighter; ON improves normal quality for final-look checks.": "レンダー設定 > 高品質法線と同じ項目です。OFFは軽く、ONは最終確認向けに法線品質を高めます。",
    "Same as Render Settings > Simplify Normals. ON can reduce normal-related cost when Simplify is active.": "レンダー設定 > 法線の簡略化と同じ項目です。簡略化有効時にONにすると法線関連の負荷を下げられる場合があります。",
    "Same as Render Settings > Persistent Data. It can keep render data cached for repeated preview checks, but may increase memory use.": "レンダー設定 > 永続データと同じ項目です。繰り返しのプレビュー確認でレンダーデータを保持できますが、メモリ使用量が増える場合があります。",
    "Same as Scene Display viewport anti-aliasing. OFF is lightest; higher samples improve edges at extra redraw cost.": "シーン表示のビューポートアンチエイリアスと同じ項目です。OFFが最軽量で、サンプル数を上げると輪郭品質が上がる代わりに再描画負荷が増えます。",
    "Same as Scene Display render anti-aliasing. Lower values are lighter for preview-oriented rendering.": "シーン表示のレンダーアンチエイリアスと同じ項目です。低い値ほどプレビュー寄りのレンダー確認が軽くなります。",
    "Same as EEVEE viewport sample count. Lower values reduce Material Preview/Rendered viewport redraw cost.": "EEVEEのビューポートサンプル数と同じ項目です。低い値ほどマテリアルプレビュー/レンダー表示の再描画負荷を下げます。",
    "Same as EEVEE TAA reprojection. OFF is lighter and avoids extra temporal history work.": "EEVEEのTAA再投影と同じ項目です。OFFは軽く、時間方向の履歴処理を減らします。",
    "Same as EEVEE shadow enable. OFF is much lighter when lights and shadow maps dominate redraw time.": "EEVEEの影有効設定と同じ項目です。ライトとシャドウマップが再描画時間を支配している場合、OFFで大きく軽くなります。",
    "Same as EEVEE shadow pool size. Smaller values reduce VRAM pressure; larger values preserve shadow quality.": "EEVEEのシャドウプールサイズと同じ項目です。小さい値はVRAM圧迫を減らし、大きい値は影品質を保ちます。",
    "Same as EEVEE shadow resolution scale. Lower values are lighter; 1.0 preserves full resolution.": "EEVEEの影解像度スケールと同じ項目です。低い値は軽く、1.0はフル解像度を維持します。",
    "Same as EEVEE shadow ray count. Lower values reduce shadow cost.": "EEVEEの影レイ数と同じ項目です。低い値ほど影の負荷を下げます。",
    "Same as EEVEE shadow step count. Lower values reduce shadow traversal cost.": "EEVEEの影ステップ数と同じ項目です。低い値ほど影の探索負荷を下げます。",
    "Same as EEVEE ray tracing. OFF is lighter; ON is for higher-quality look checks.": "EEVEEのレイトレーシングと同じ項目です。OFFは軽く、ONは高品質な見た目確認向けです。",
    "Same as EEVEE ray tracing method.": "EEVEEのレイトレーシング方式と同じ項目です。",
    "Same as EEVEE volumetric tile size. Larger divisors are lighter but coarser.": "EEVEEのボリュームタイルサイズと同じ項目です。分割比が大きいほど軽くなりますが粗くなります。",
    "Same as EEVEE volumetric sample count. Lower values reduce volume redraw cost.": "EEVEEのボリュームサンプル数と同じ項目です。低い値ほどボリューム再描画負荷を下げます。",
    "Same as EEVEE volumetric ray depth. Lower values are lighter for volume-heavy scenes.": "EEVEEのボリュームレイ深度と同じ項目です。低い値ほどボリュームの多いシーンで軽くなります。",
    "Same as EEVEE volumetric shadows. OFF is lighter.": "EEVEEのボリューム影と同じ項目です。OFFは軽量です。",
    "Same as EEVEE volumetric shadow samples. Lower values reduce volume shadow cost.": "EEVEEのボリューム影サンプル数と同じ項目です。低い値ほどボリューム影の負荷を下げます。",
    "Same as Cycles viewport preview samples. Lower values make Rendered viewport navigation more responsive.": "Cyclesのビューポートプレビューサンプル数と同じ項目です。低い値ほどレンダー表示中の視点操作が軽くなります。",
    "Same as Cycles preview denoising. OFF is lighter; ON improves noisy previews after sampling.": "Cyclesのプレビューデノイズと同じ項目です。OFFは軽く、ONはサンプル後のノイズを抑えます。",
    "Same as Cycles preview denoising quality.": "Cyclesプレビューデノイズ品質と同じ項目です。",
    "Same as Cycles texture limit. Lower values reduce VRAM and texture sampling cost.": "Cyclesのテクスチャ制限と同じ項目です。低い値ほどVRAM使用量とテクスチャサンプリング負荷を下げます。",
    "Same as Cycles volume preview step rate. Higher values are coarser and lighter.": "Cyclesのボリュームプレビューステップ率と同じ項目です。高い値ほど粗く軽くなります。",
    "Same as Cycles preview dicing rate. Higher values are lighter but less detailed for adaptive subdivision preview.": "Cyclesのプレビューダイシング率と同じ項目です。高い値ほど軽くなりますが、アダプティブサブディビジョンのプレビュー詳細は減ります。",
}
_TRANSLATIONS_JA.update(_SVO_V12_TRANSLATIONS)
_TRANSLATION_DICT["ja_JP"].update({("*", key): value for key, value in _SVO_V12_TRANSLATIONS.items()})

_TRANSLATIONS_JA.update({
    "Apply Performance Preset": "パフォーマンスプリセットを適用",
    "Apply the default high-performance viewport preset, save a repair backup if needed, and immediately update configured targets.": "既定の高パフォーマンスビューポートプリセットを適用し、必要に応じて修復用バックアップを保存してから対象設定を即時更新します。",
    "Reset Options to Performance High": "設定をパフォーマンス優先：高へ戻す",
    "Set all optimization options back to the Performance Priority: High preset.": "すべての最適化項目をパフォーマンス優先：高プリセットへ戻します。",
    "Smart Viewport Optimizer Plus: performance preset options reset.": 'ビューポート最適化: パフォーマンスプリセット設定へ戻しました。',
})
_TRANSLATION_DICT["ja_JP"].update({("*", key): value for key, value in {
    "Apply Performance Preset": "パフォーマンスプリセットを適用",
    "Apply the default high-performance viewport preset, save a repair backup if needed, and immediately update configured targets.": "既定の高パフォーマンスビューポートプリセットを適用し、必要に応じて修復用バックアップを保存してから対象設定を即時更新します。",
    "Reset Options to Performance High": "設定をパフォーマンス優先：高へ戻す",
    "Set all optimization options back to the Performance Priority: High preset.": "すべての最適化項目をパフォーマンス優先：高プリセットへ戻します。",
    "Smart Viewport Optimizer Plus: performance preset options reset.": 'ビューポート最適化: パフォーマンスプリセット設定へ戻しました。',
}.items()})

_TRANSLATIONS_JA.update({
    "Custom presets do not have factory defaults. Delete or overwrite the custom preset instead.": "カスタムプリセットには工場出荷時の既定値がありません。カスタムプリセットを削除するか上書きしてください。",
    "Preset not found": "プリセットが見つかりません",
    "Smart Viewport Optimizer Plus: custom preset saved": "Smart Viewport Optimizer Plus: カスタムプリセットを保存しました",
    "Built-in presets cannot be deleted": "組み込みプリセットは削除できません",
    "Delete the custom preset file by the same name used to save it.": "保存時と同じ名前でカスタムプリセットファイルを削除します。",
    "Could not delete the custom preset": "カスタムプリセットを削除できませんでした",
    "Smart Viewport Optimizer Plus: custom preset deleted": "Smart Viewport Optimizer Plus: カスタムプリセットを削除しました",
    "Smart Viewport Optimizer Plus: external backup saved": "Smart Viewport Optimizer Plus: 外部バックアップを保存しました",
    "failed": "失敗",
    "No external backup was found": "外部バックアップが見つかりませんでした",
    "Smart Viewport Optimizer Plus: external backup restored": "Smart Viewport Optimizer Plus: 外部バックアップから復元しました",
})
_TRANSLATION_DICT["ja_JP"].update({("*", key): value for key, value in {
    "Custom presets do not have factory defaults. Delete or overwrite the custom preset instead.": "カスタムプリセットには工場出荷時の既定値がありません。カスタムプリセットを削除するか上書きしてください。",
    "Preset not found": "プリセットが見つかりません",
    "Smart Viewport Optimizer Plus: custom preset saved": "Smart Viewport Optimizer Plus: カスタムプリセットを保存しました",
    "Built-in presets cannot be deleted": "組み込みプリセットは削除できません",
    "Smart Viewport Optimizer Plus: custom preset deleted": "Smart Viewport Optimizer Plus: カスタムプリセットを削除しました",
    "Smart Viewport Optimizer Plus: external backup saved": "Smart Viewport Optimizer Plus: 外部バックアップを保存しました",
    "failed": "失敗",
    "No external backup was found": "外部バックアップが見つかりませんでした",
    "Smart Viewport Optimizer Plus: external backup restored": "Smart Viewport Optimizer Plus: 外部バックアップから復元しました",
}.items()})

_suite_translation.add_ui_pairs(_TRANSLATION_DICT["ja_JP"])

# -- property definitions ------------------------------------------------------

def _svo_v11_prop_update(settings: bpy.types.PropertyGroup, context: bpy.types.Context) -> None:
    # Detailed Settings are now live settings. Changing any detailed item
    # immediately writes the corresponding Blender setting and optionally saves
    # the active Standard/Optimized profile.
    try:
        _svo_v12_live_update(settings, context)
    except Exception:
        pass


def _svo_v11_bool(name: str, desc: str, key: str):
    return bpy.props.BoolProperty(name=name, description=desc, default=bool(MAX_SPEED_DEFAULTS[key]), update=_svo_v11_prop_update)


def _svo_v11_float(name: str, desc: str, key: str, min_v: float, max_v: float, precision: int = 2):
    return bpy.props.FloatProperty(name=name, description=desc, default=float(MAX_SPEED_DEFAULTS[key]), min=min_v, max=max_v, precision=precision, update=_svo_v11_prop_update)


def _svo_v11_int(name: str, desc: str, key: str, min_v: int, max_v: int):
    return bpy.props.IntProperty(name=name, description=desc, default=int(MAX_SPEED_DEFAULTS[key]), min=min_v, max=max_v, update=_svo_v11_prop_update)


def _svo_v11_enum(name: str, desc: str, key: str, items: Sequence[Tuple[str, str, str]]):
    return bpy.props.EnumProperty(name=name, description=desc, items=items, default=MAX_SPEED_DEFAULTS[key], update=_svo_v11_prop_update)


def _svo_v11_define_standard_properties() -> None:
    ann = SVO_PLUS_PG_settings.__annotations__
    ann["include_render_preview_settings"] = _svo_v11_bool("Include Render Preview Settings", "Enable render-preview and engine viewport settings such as preview pixel size, EEVEE viewport samples, Cycles preview samples, and scene display anti-aliasing. These settings affect Material Preview or Rendered viewport cost and are restored when the optimizer turns OFF.", "include_render_preview_settings")
    ann["target_shading_type"] = _svo_v11_enum("Viewport Shading", "Same as the 3D View viewport shading mode. Use Solid or Wireframe for lighter navigation; Material Preview and Rendered preserve more visual feedback.", "target_shading_type", (("WIREFRAME", "Wireframe", "Wireframe display."), ("SOLID", "Solid", "Solid display."), ("MATERIAL", "Material Preview", "Material preview display."), ("RENDERED", "Rendered", "Rendered display.")))
    ann["target_shading_light"] = _svo_v11_enum("Lighting", "Same as Solid mode lighting. Flat is the lightest; Studio and MatCap preserve more form visibility.", "target_shading_light", (("FLAT", "Flat", "Flat lighting."), ("STUDIO", "Studio", "Studio lighting."), ("MATCAP", "MatCap", "MatCap lighting.")))
    ann["target_shading_color_type"] = _svo_v11_enum("Color", "Same as Solid mode color source. Material/Texture preserve more visual feedback; Single is often lighter and simpler.", "target_shading_color_type", (("MATERIAL", "Material", "Material color."), ("OBJECT", "Object", "Object color."), ("RANDOM", "Random", "Random color."), ("VERTEX", "Attribute", "Attribute color."), ("TEXTURE", "Texture", "Texture color."), ("SINGLE", "Custom", "Single custom color.")))
    ann["target_wireframe_color_type"] = _svo_v11_enum("Wire Color", "Same as Wireframe color source in the 3D View.", "target_wireframe_color_type", (("THEME", "Theme", "Theme color."), ("OBJECT", "Object", "Object color."), ("RANDOM", "Random", "Random color.")))
    ann["target_background_type"] = _svo_v11_enum("Background", "Same as the viewport background source.", "target_background_type", (("THEME", "Theme", "Theme background."), ("WORLD", "World", "World background."), ("VIEWPORT", "Custom", "Custom viewport color.")))
    ann["target_cavity_type"] = _svo_v11_enum("Cavity Type", "Same as the viewport Cavity type.", "target_cavity_type", (("WORLD", "World", "World cavity."), ("SCREEN", "Screen", "Screen cavity."), ("BOTH", "Both", "Both cavity modes.")))
    ann["target_use_compositor"] = _svo_v11_enum("Compositor", "Same as viewport compositor usage. Disabled is lightest.", "target_use_compositor", (("DISABLED", "Disabled", "Do not use compositor in the viewport."), ("CAMERA", "Camera", "Use compositor in camera view."), ("ALWAYS", "Always", "Always use compositor in the viewport.")))
    ann["target_gpu_backend"] = _svo_v11_enum("Graphics Backend", "Same as Preferences > System > GPU Backend. Vulkan is recommended first for RTX-class systems, but the change requires restarting Blender to fully take effect; use OpenGL if Vulkan is unstable.", "target_gpu_backend", (("OPENGL", "OpenGL", "Use OpenGL backend."), ("VULKAN", "Vulkan", "Use Vulkan backend.")))
    ann["target_gpu_preferred_device"] = _svo_v11_enum("Preferred GPU Device", "Same as Preferences > System > GPU Preferred Device. Auto lets Blender choose the best available GPU; on Windows, also force blender.exe to the RTX GPU in Windows/NVIDIA settings.", "target_gpu_preferred_device", (("AUTO", "Auto", "Auto-detect the best available GPU."),))
    for key, name, desc in (
        ("target_show_shadows", "Shadow", "Same as 3D Viewport > Viewport Shading > Shadow. OFF reduces solid viewport drawing cost."),
        ("target_show_cavity", "Cavity", "Show or hide cavity shading. OFF reduces screen-space shading cost."),
        ("target_show_object_outline", "Outline", "Same as 3D Viewport > Viewport Shading > Outline. ON keeps selection visibility clearer; OFF is lighter."),
        ("target_show_specular_highlight", "Specular Highlights", "Show or hide specular highlights in the viewport."),
        ("target_show_xray", "X-Ray", "Show or hide X-Ray display. OFF reduces overdraw."),
        ("target_show_xray_wireframe", "X-Ray Wireframe", "Show or hide X-Ray in Wireframe mode."),
        ("target_show_backface_culling", "Backface Culling", "Use backface culling in the viewport."),
        ("target_use_scene_lights", "Scene Lights", "Use scene lights in the viewport. OFF uses cheaper viewport lighting."),
        ("target_use_scene_world", "Scene World", "Use the scene world in the viewport. OFF uses the viewport background."),
        ("target_use_scene_lights_render", "Rendered Scene Lights", "Use scene lights in rendered viewport mode."),
        ("target_use_scene_world_render", "Rendered Scene World", "Use scene world in rendered viewport mode."),
        ("target_use_dof", "Depth of Field", "Same as 3D Viewport > Viewport Shading > Depth of Field. OFF is lighter."),
    ):
        ann[key] = _svo_v11_bool(name, desc, key)
    ann["target_shadow_intensity"] = _svo_v11_float("Shadow Intensity", "Viewport shadow intensity.", "target_shadow_intensity", 0.0, 1.0)
    ann["target_xray_alpha"] = _svo_v11_float("X-Ray Opacity", "Viewport X-Ray opacity.", "target_xray_alpha", 0.0, 1.0)
    ann["target_xray_alpha_wireframe"] = _svo_v11_float("Wireframe X-Ray Opacity", "Wireframe X-Ray opacity.", "target_xray_alpha_wireframe", 0.0, 1.0)
    ann["target_studiolight_intensity"] = _svo_v11_float("Studio Light Intensity", "Studio light intensity for viewport display.", "target_studiolight_intensity", 0.0, 10.0)
    ann["target_studiolight_background_alpha"] = _svo_v11_float("Studio Light Background Alpha", "Studio light background alpha.", "target_studiolight_background_alpha", 0.0, 1.0)
    ann["target_studiolight_background_blur"] = _svo_v11_float("Studio Light Background Blur", "Studio light background blur.", "target_studiolight_background_blur", 0.0, 1.0)

    overlay_bools = [
        ("target_show_overlays", "Overlays"), ("target_show_relationship_lines", "Relationship Lines"), ("target_show_floor", "Floor"),
        ("target_show_axis_x", "X Axis"), ("target_show_axis_y", "Y Axis"), ("target_show_axis_z", "Z Axis"),
        ("target_show_text", "Text Info"), ("target_show_stats", "Statistics"), ("target_show_extras", "Extras"),
        ("target_show_wireframes", "Wireframes"), ("target_show_outline_selected", "Outline Selected"),
        ("target_show_object_origins", "Object Origins"), ("target_show_object_origins_all", "All Object Origins"),
        ("target_show_motion_paths", "Motion Paths"), ("target_show_annotation", "Annotations"), ("target_show_bones", "Bones"),
        ("target_show_faces", "Faces"), ("target_show_face_center", "Face Center"), ("target_show_face_orientation", "Face Orientation"),
        ("target_show_edge_crease", "Creases"), ("target_show_edge_sharp", "Sharp Edges"), ("target_show_edge_bevel_weight", "Bevel Weights"),
        ("target_show_edge_seams", "Seams"), ("target_show_extra_indices", "Indices"), ("target_show_extra_edge_length", "Edge Length"),
        ("target_show_extra_edge_angle", "Edge Angle"), ("target_show_extra_face_area", "Face Area"), ("target_show_extra_face_angle", "Face Angle"),
        ("target_show_freestyle_edge_marks", "Freestyle Edge Marks"), ("target_show_freestyle_face_marks", "Freestyle Face Marks"),
        ("target_show_face_normals", "Face Normals"), ("target_show_vertex_normals", "Vertex Normals"), ("target_show_split_normals", "Split Normals"),
        ("target_show_curve_normals", "Curve Normals"), ("target_show_fade_inactive", "Fade Inactive"),
        ("target_show_face_sets", "Sculpt Face Sets"), ("target_show_sculpt_mask", "Sculpt Mask"),
        ("target_show_onion_skins", "Onion Skins"), ("target_use_gpencil_grid", "Grease Pencil Grid"),
        ("target_use_gpencil_onion_skin", "Grease Pencil Onion Skin"), ("target_use_gpencil_edit_lines", "Grease Pencil Edit Lines"),
        ("target_use_debug_freeze_view_culling", "Freeze View Culling"),
    ]
    for key, name in overlay_bools:
        ann[key] = _svo_v11_bool(name, f"Same as Blender's {name} overlay setting. Turn it off when the overlay is not needed during navigation.", key)
    ann["target_wireframe_opacity"] = _svo_v11_float("Wireframe Opacity", "Wireframe overlay opacity.", "target_wireframe_opacity", 0.0, 1.0)
    ann["target_wireframe_threshold"] = _svo_v11_float("Wireframe Threshold", "Wireframe overlay threshold.", "target_wireframe_threshold", 0.0, 1.0)
    ann["target_normals_length"] = _svo_v11_float("Normals Size", "Displayed normal length.", "target_normals_length", 0.0, 10.0)
    ann["target_fade_inactive_alpha"] = _svo_v11_float("Fade Inactive Alpha", "Inactive object fade amount.", "target_fade_inactive_alpha", 0.0, 1.0)

    gizmo_bools = [
        ("target_show_gizmo", "Gizmos"), ("target_show_gizmo_navigate", "Navigate Gizmo"), ("target_show_gizmo_tool", "Tool Gizmo"),
        ("target_show_gizmo_context", "Context Gizmo"), ("target_show_gizmo_object_translate", "Translate"),
        ("target_show_gizmo_object_rotate", "Rotate"), ("target_show_gizmo_object_scale", "Scale"),
        ("target_show_gizmo_modifier", "Modifier Gizmos"), ("target_show_gizmo_light_size", "Light Size"),
        ("target_show_gizmo_light_look_at", "Light Look-at"), ("target_show_gizmo_camera_lens", "Camera Lens"),
        ("target_show_gizmo_camera_dof_distance", "Camera DOF Distance"), ("target_show_gizmo_empty_image", "Empty Image"),
        ("target_show_gizmo_empty_force_field", "Empty Force Field"),
    ]
    for key, name in gizmo_bools:
        ann[key] = _svo_v11_bool(name, f"Same as Blender's {name} gizmo setting. Hiding unused gizmos reduces interactive redraw work.", key)

    type_names = [
        ("mesh", "Mesh"), ("camera", "Camera"), ("light", "Light"), ("empty", "Empty"), ("armature", "Armature"),
        ("curve", "Curve"), ("surface", "Surface"), ("font", "Text"), ("metaball", "Metaball"), ("lattice", "Lattice"),
        ("speaker", "Speaker"), ("light_probe", "Light Probe"), ("volume", "Volume"), ("grease_pencil", "Grease Pencil"), ("pointcloud", "Point Cloud"),
    ]
    for suffix, label in type_names:
        ann[f"target_show_object_viewport_{suffix}"] = _svo_v11_bool(label, f"Same as the 3D View object-type visibility filter for {label}.", f"target_show_object_viewport_{suffix}")
        ann[f"target_show_object_select_{suffix}"] = _svo_v11_bool(label, f"Same as the 3D View object-type selectability filter for {label}.", f"target_show_object_select_{suffix}")

    for key, name in (("target_show_region_toolbar", "Toolbar"), ("target_show_region_tool_header", "Tool Header"), ("target_show_region_ui", "Sidebar"), ("target_show_region_hud", "HUD"), ("target_show_region_asset_shelf", "Asset Shelf")):
        ann[key] = _svo_v11_bool(name, f"Show or hide the 3D View {name} region while optimization is ON.", key)

    ann["target_object_display_type"] = _svo_v11_enum("Display As", "Same as Object Properties > Viewport Display > Display As. Bounds and Wire are lighter than textured display.", "target_object_display_type", (("BOUNDS", "Bounds", "Bounds display."), ("WIRE", "Wire", "Wire display."), ("SOLID", "Solid", "Solid display."), ("TEXTURED", "Textured", "Textured display.")))
    ann["target_display_bounds_type"] = _svo_v11_enum("Bounds Type", "Same as Object Properties > Viewport Display > Bounds Type.", "target_display_bounds_type", (("BOX", "Box", "Box bounds."), ("SPHERE", "Sphere", "Sphere bounds."), ("CYLINDER", "Cylinder", "Cylinder bounds."), ("CONE", "Cone", "Cone bounds."), ("CAPSULE", "Capsule", "Capsule bounds.")))
    for key, name in (
        ("target_object_show_name", "Name"), ("target_object_show_axis", "Axis"), ("target_object_show_texture_space", "Texture Space"),
        ("target_object_show_bounds", "Bounds"), ("target_object_show_wire", "Wire"), ("target_object_show_all_edges", "All Edges"),
        ("target_object_show_in_front", "In Front"), ("target_object_show_transparent", "Transparent"),
        ("target_object_selectable", "Selectable"), ("target_object_show_instancer_for_viewport", "Instance in Viewport"),
        ("target_object_use_simulation_cache", "Simulation Cache"),
    ):
        ann[key] = _svo_v11_bool(name, f"Same as the object viewport display option: {name}.", key)

    for key, name in (
        ("target_show_viewport_modifiers", "Show Modifiers in Viewport"), ("target_show_subdivision_modifiers", "Subdivision / Multires"),
        ("target_show_geometry_nodes", "Geometry Nodes"), ("target_show_simulation_modifiers", "Simulation Modifiers"),
        ("target_show_deformer_modifiers", "Deform Modifiers"), ("target_show_generator_modifiers", "Generate Modifiers"),
        ("target_show_normal_data_modifiers", "Normals / Data Modifiers"), ("target_show_other_modifiers", "Other Modifiers"),
        ("target_object_constraints_enabled", "Object Constraints"), ("target_pose_constraints_enabled", "Pose Constraints"),
    ):
        ann[key] = _svo_v11_bool(name, f"Keep {name} enabled while optimization is ON. Turning it off can reduce dependency-graph work during navigation.", key)

    ann["target_viewport_aa"] = _svo_v11_enum("Viewport Anti-Aliasing", "Same as Preferences > System > Viewport Anti-Aliasing. OFF is lightest.", "target_viewport_aa", (("OFF", "No Anti-Aliasing", "No anti-aliasing."), ("FXAA", "Single Pass Anti-Aliasing", "FXAA."), ("5", "5 Samples", "5 samples."), ("8", "8 Samples", "8 samples."), ("11", "11 Samples", "11 samples."), ("16", "16 Samples", "16 samples."), ("32", "32 Samples", "32 samples.")))
    ann["target_gl_texture_limit"] = _svo_v11_enum("Texture Limit", "Same as Preferences > System > Texture Limit. Lower limits reduce texture upload and sampling cost.", "target_gl_texture_limit", (("CLAMP_OFF", "Off", "No limit."), ("CLAMP_8192", "8192", "8192."), ("CLAMP_4096", "4096", "4096."), ("CLAMP_2048", "2048", "2048."), ("CLAMP_1024", "1024", "1024."), ("CLAMP_512", "512", "512."), ("CLAMP_256", "256", "256."), ("CLAMP_128", "128", "128.")))
    ann["target_shader_compilation_method"] = _svo_v11_enum("Shader Compilation", "Same as Preferences > System > Shader Compilation where available. Threaded reduces UI blocking on many systems; Subprocess can isolate compilation work where Blender exposes it.", "target_shader_compilation_method", (("THREAD", "Threaded", "Threaded shader compilation."), ("SUBPROCESS", "Subprocess", "Compile shaders in a subprocess when Blender exposes this option.")))
    for key, name, min_v, max_v in (
        ("target_texture_time_out", "Texture Time Out", 0, 100000), ("target_vbo_time_out", "VBO Time Out", 0, 100000),
        ("target_texture_collection_rate", "Texture Collection Rate", 0, 100000), ("target_vbo_collection_rate", "VBO Collection Rate", 0, 100000),
        ("target_gpu_shader_workers", "GPU Shader Workers", 0, 64), ("target_memory_cache_limit", "Memory Cache Limit", 0, 131072),
        ("target_smooth_view", "Smooth View", 0, 1000), ("target_undo_steps", "Undo Steps", 0, 256),
        ("target_undo_memory_limit", "Undo Memory Limit", 0, 32768),
    ):
        ann[key] = _svo_v11_int(name, f"Same as Blender preference value: {name}.", key, min_v, max_v)
    for key, name in (
        ("target_use_gpu_subdivision", "GPU Subdivision"), ("target_use_overlay_smooth_wire", "Overlay Smooth Wires"),
        ("target_use_edit_mode_smooth_wire", "Edit Mode Smooth Wires"), ("target_use_region_overlap", "Region Overlap"),
        ("target_use_reduce_motion", "Reduce Motion"), ("target_show_navigate_ui", "Navigation Controls"),
        ("target_show_statusbar_stats", "Status Bar Statistics"), ("target_show_statusbar_memory", "Status Bar Memory"),
        ("target_show_statusbar_vram", "Status Bar VRAM"), ("target_show_statusbar_version", "Status Bar Version"),
        ("target_use_mouse_depth_navigate", "Auto Depth"), ("target_use_zoom_to_mouse", "Zoom to Mouse Position"),
        ("target_use_rotate_around_active", "Orbit Around Selection"), ("target_use_auto_perspective", "Auto Perspective"),
        ("target_ndof_show_guide_orbit_axis", "NDOF Orbit Axis Guide"), ("target_ndof_show_guide_orbit_center", "NDOF Orbit Center Guide"),
        ("target_use_global_undo", "Global Undo"), ("target_use_auto_keying", "Auto Keying"),
        ("target_use_auto_keyframe_insert_needed", "Only Insert Needed"), ("target_use_snap", "Snapping"),
        ("target_use_mesh_automerge", "Auto Merge"), ("target_use_mesh_automerge_and_split", "Auto Merge & Split"),
        ("target_use_keyframe_insert_auto", "Record Auto Keying"),
    ):
        ann[key] = _svo_v11_bool(name, f"Same as Blender setting: {name}.", key)
    ann["target_view_rotate_method"] = _svo_v11_enum("View Rotate Method", "Same as Preferences > Navigation > Orbit & Pan > Orbit Method.", "target_view_rotate_method", (("TURNTABLE", "Turntable", "Turntable."), ("TRACKBALL", "Trackball", "Trackball.")))
    ann["target_view_zoom_method"] = _svo_v11_enum("View Zoom Method", "Same as Preferences > Navigation > Zoom Method.", "target_view_zoom_method", (("CONTINUE", "Continue", "Continue."), ("DOLLY", "Dolly", "Dolly."), ("SCALE", "Scale", "Scale.")))
    ann["target_view_zoom_axis"] = _svo_v11_enum("View Zoom Axis", "Same as Preferences > Navigation > Zoom Axis.", "target_view_zoom_axis", (("VERTICAL", "Vertical", "Vertical."), ("HORIZONTAL", "Horizontal", "Horizontal.")))
    ann["target_render_preview_pixel_size"] = _svo_v11_enum("Preview Pixel Size", "Same as Render Settings > Preview Pixel Size. Larger pixel size is lighter for preview drawing; 1x is highest quality.", "target_render_preview_pixel_size", (("AUTO", "Automatic", "Automatic."), ("1", "1×", "1× preview pixels."), ("2", "2×", "2× preview pixels."), ("4", "4×", "4× preview pixels."), ("8", "8×", "8× preview pixels.")))
    for key, name, desc in (
        ("target_render_use_high_quality_normals", "High Quality Normals", "Same as Render Settings > High Quality Normals. OFF is lighter; ON improves normal quality for final-look checks."),
        ("target_render_use_simplify_normals", "Simplify Normals", "Same as Render Settings > Simplify Normals. ON can reduce normal-related cost when Simplify is active."),
        ("target_render_use_persistent_data", "Persistent Data", "Same as Render Settings > Persistent Data. It can keep render data cached for repeated preview checks, but may increase memory use."),
    ):
        ann[key] = _svo_v11_bool(name, desc, key)
    ann["target_scene_viewport_aa"] = _svo_v11_enum("Scene Viewport AA", "Same as Scene Display viewport anti-aliasing. OFF is lightest; higher samples improve edges at extra redraw cost.", "target_scene_viewport_aa", (("OFF", "No Anti-Aliasing", "No anti-aliasing."), ("FXAA", "Single Pass Anti-Aliasing", "FXAA."), ("5", "5 Samples", "5 samples."), ("8", "8 Samples", "8 samples."), ("11", "11 Samples", "11 samples."), ("16", "16 Samples", "16 samples."), ("32", "32 Samples", "32 samples.")))
    ann["target_scene_render_aa"] = _svo_v11_enum("Scene Render AA", "Same as Scene Display render anti-aliasing. Lower values are lighter for preview-oriented rendering.", "target_scene_render_aa", (("OFF", "No Anti-Aliasing", "No anti-aliasing."), ("FXAA", "Single Pass Anti-Aliasing", "FXAA."), ("5", "5 Samples", "5 samples."), ("8", "8 Samples", "8 samples."), ("11", "11 Samples", "11 samples."), ("16", "16 Samples", "16 samples."), ("32", "32 Samples", "32 samples.")))
    ann["target_eevee_shadow_pool_size"] = _svo_v11_enum("EEVEE Shadow Pool Size", "Same as EEVEE shadow pool size. Smaller values reduce VRAM pressure; larger values preserve shadow quality.", "target_eevee_shadow_pool_size", (("16", "16 MB", "16 MB."), ("32", "32 MB", "32 MB."), ("64", "64 MB", "64 MB."), ("128", "128 MB", "128 MB."), ("256", "256 MB", "256 MB."), ("512", "512 MB", "512 MB."), ("1024", "1 GB", "1 GB.")))
    ann["target_eevee_ray_tracing_method"] = _svo_v11_enum("EEVEE Ray Tracing Method", "Same as EEVEE ray tracing method.", "target_eevee_ray_tracing_method", (("PROBE", "Light Probe", "Light Probe."), ("SCREEN", "Screen-Trace", "Screen-Trace.")))
    ann["target_eevee_volumetric_tile_size"] = _svo_v11_enum("EEVEE Volume Tile Size", "Same as EEVEE volumetric tile size. Larger divisors are lighter but coarser.", "target_eevee_volumetric_tile_size", (("1", "1:1", "1:1."), ("2", "1:2", "1:2."), ("4", "1:4", "1:4."), ("8", "1:8", "1:8."), ("16", "1:16", "1:16.")))
    ann["target_cycles_preview_denoising_quality"] = _svo_v11_enum("Cycles Preview Denoising Quality", "Same as Cycles preview denoising quality.", "target_cycles_preview_denoising_quality", (("HIGH", "High", "High."), ("BALANCED", "Balanced", "Balanced."), ("FAST", "Fast", "Fast.")))
    ann["target_cycles_texture_limit"] = _svo_v11_enum("Cycles Texture Limit", "Same as Cycles texture limit. Lower values reduce VRAM and texture sampling cost.", "target_cycles_texture_limit", (("OFF", "No Limit", "No limit."), ("128", "128", "128."), ("256", "256", "256."), ("512", "512", "512."), ("1024", "1024", "1024."), ("2048", "2048", "2048."), ("4096", "4096", "4096."), ("8192", "8192", "8192.")))
    for key, name, desc, min_v, max_v in (
        ("target_eevee_taa_samples", "EEVEE Viewport Samples", "Same as EEVEE viewport sample count. Lower values reduce Material Preview/Rendered viewport redraw cost.", 1, 1024),
        ("target_eevee_shadow_ray_count", "EEVEE Shadow Ray Count", "Same as EEVEE shadow ray count. Lower values reduce shadow cost.", 1, 16),
        ("target_eevee_shadow_step_count", "EEVEE Shadow Step Count", "Same as EEVEE shadow step count. Lower values reduce shadow traversal cost.", 1, 64),
        ("target_eevee_volumetric_samples", "EEVEE Volume Samples", "Same as EEVEE volumetric sample count. Lower values reduce volume redraw cost.", 1, 256),
        ("target_eevee_volumetric_ray_depth", "EEVEE Volume Ray Depth", "Same as EEVEE volumetric ray depth. Lower values are lighter for volume-heavy scenes.", 1, 64),
        ("target_eevee_volumetric_shadow_samples", "EEVEE Volume Shadow Samples", "Same as EEVEE volumetric shadow samples. Lower values reduce volume shadow cost.", 1, 256),
        ("target_cycles_preview_samples", "Cycles Preview Samples", "Same as Cycles viewport preview samples. Lower values make Rendered viewport navigation more responsive.", 1, 4096),
    ):
        ann[key] = _svo_v11_int(name, desc, key, min_v, max_v)
    ann["target_eevee_shadow_resolution_scale"] = _svo_v11_float("EEVEE Shadow Resolution Scale", "Same as EEVEE shadow resolution scale. Lower values are lighter; 1.0 preserves full resolution.", "target_eevee_shadow_resolution_scale", 0.0, 2.0)
    ann["target_cycles_volume_preview_step_rate"] = _svo_v11_float("Cycles Volume Preview Step Rate", "Same as Cycles volume preview step rate. Higher values are coarser and lighter.", "target_cycles_volume_preview_step_rate", 0.01, 100.0)
    ann["target_cycles_preview_dicing_rate"] = _svo_v11_float("Cycles Preview Dicing Rate", "Same as Cycles preview dicing rate. Higher values are lighter but less detailed for adaptive subdivision preview.", "target_cycles_preview_dicing_rate", 0.1, 1000.0)
    for key, name, desc in (
        ("target_eevee_use_taa_reprojection", "EEVEE TAA Reprojection", "Same as EEVEE TAA reprojection. OFF is lighter and avoids extra temporal history work."),
        ("target_eevee_use_shadows", "EEVEE Shadows", "Same as EEVEE shadow enable. OFF is much lighter when lights and shadow maps dominate redraw time."),
        ("target_eevee_use_raytracing", "EEVEE Ray Tracing", "Same as EEVEE ray tracing. OFF is lighter; ON is for higher-quality look checks."),
        ("target_eevee_use_volumetric_shadows", "EEVEE Volume Shadows", "Same as EEVEE volumetric shadows. OFF is lighter."),
        ("target_cycles_use_preview_denoising", "Cycles Preview Denoising", "Same as Cycles preview denoising. OFF is lighter; ON improves noisy previews after sampling."),
    ):
        ann[key] = _svo_v11_bool(name, desc, key)

_svo_v11_define_standard_properties()
SVO_PLUS_PG_settings.__annotations__["show_select_filter"] = bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
SVO_PLUS_PG_settings.__annotations__["show_region"] = bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
SVO_PLUS_PG_settings.__annotations__["show_edit_settings"] = bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
SVO_PLUS_PG_settings.__annotations__["show_render_preview"] = bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

# Add live-update callbacks to the legacy/detail properties that are still used
# by the v11 Detailed Settings UI. These were originally static preset values;
# they now directly control the current Blender view.
def _svo_v12_patch_live_update_properties() -> None:
    ann = SVO_PLUS_PG_settings.__annotations__
    ann["selected_preset"] = bpy.props.EnumProperty(
        name="Setting Load",
        description="Choose Performance, Balanced, or Quality. The selection only changes Detailed Settings after pressing Apply Preset.",
        items=_svo_v6_preset_items,
        update=_svo_v10_selected_preset_update,
    )
    ann["active_settings_slot"] = bpy.props.EnumProperty(
        name="Settings Mode",
        description="Switch between Standard Settings and Optimized Settings. The selected slot is loaded into Detailed Settings and applied to the viewport. When Auto-save Settings is OFF, JSON files are not updated by switching.",
        items=(("STANDARD", "Standard", "Use the saved Standard Settings."), ("OPTIMIZED", "Optimized", "Use the saved Optimized Settings.")),
        default="OPTIMIZED",
        options={"SKIP_SAVE"},
        update=_svo_v12_active_slot_update,
    )
    ann["workspace_paste_source"] = bpy.props.StringProperty(
        name="Paste Source",
        description="Workspace whose saved Detailed Settings are copied into the currently open workspace when the paste button is pressed.",
        default="",
        options={"SKIP_SAVE"},
    )
    ann["svo_workspace_active_name"] = bpy.props.StringProperty(
        name="Active Workspace",
        description="Internal workspace key used to keep viewport optimization Detailed Settings separated per Blender workspace.",
        default="",
        options={"HIDDEN", "SKIP_SAVE"},
    )
    ann["auto_save_workspace_preset_changes"] = bpy.props.BoolProperty(
        name="Auto-save Settings",
        description="When enabled, each Detailed Settings change is immediately written to the active Standard or Optimized settings file and to the current settings file after it is applied to the viewport.",
        default=False,
        update=_svo_v11_prop_update,
    )
    ann["apply_all_scenes"] = bpy.props.BoolProperty(
        name="Apply all scenes",
        description="Apply scene-level settings to every scene in the file. Turn this on when multiple scenes share heavy assets and must remain synchronized.",
        default=bool(MAX_SPEED_DEFAULTS.get("apply_all_scenes", True)),
        update=_svo_v11_prop_update,
    )
    ann["object_scope"] = bpy.props.EnumProperty(
        name="Object Scope",
        description="Choose which objects receive object, modifier, constraint, and particle viewport settings. Visible is safer; All is strongest.",
        items=(("ALL", "All Objects", "All objects."), ("SELECTED", "Selected Objects", "Selected objects."), ("VISIBLE", "Visible Objects", "Visible objects.")),
        default=MAX_SPEED_DEFAULTS.get("object_scope", "VISIBLE"),
        update=_svo_v11_prop_update,
    )
    for key, name, desc in (
        ("include_scene_simplify", "Render Properties > Simplify", "Enable this section and apply Simplify settings to the current view."),
        ("include_viewport_shading", "3D Viewport > Viewport Shading", "Enable this section and apply viewport shading settings."),
        ("include_overlays", "3D Viewport > Overlays", "Enable this section and apply overlay visibility settings."),
        ("include_gizmos", "3D Viewport > Gizmos", "Enable this section and apply gizmo visibility settings."),
        ("include_object_filters", "3D Viewport > Object Type Visibility", "Enable this section and apply object type visibility filters."),
        ("include_object_display", "Object Properties > Viewport Display", "Enable this section and apply per-object viewport display settings."),
        ("include_modifiers", "Modifier Viewport Display", "Enable this section and apply modifier viewport visibility settings."),
        ("include_constraints", "Constraints", "Enable this section and apply object and pose constraint states."),
        ("include_particles", "Particle Preview", "Enable this section and apply particle preview settings."),
        ("include_preferences", "Preferences > System", "Enable this section and apply system and display preference settings."),
        ("include_navigation_latency", "Preferences > Navigation", "Enable this section and apply navigation settings that affect orbit, pan, and zoom startup."),
        ("include_viewport_prewarm", "Navigation Warmup", "Enable warmup settings. Performance presets keep this off to avoid idle overhead."),
    ):
        ann[key] = bpy.props.BoolProperty(name=name, description=desc, default=bool(MAX_SPEED_DEFAULTS.get(key, True)), update=_svo_v11_prop_update)
    for key, name, desc, default, min_v, max_v in (
        ("use_simplify", "Use Simplify", "Same as Render Properties > Simplify. ON lets Blender use cheaper viewport representations.", True, 0, 1),
    ):
        ann[key] = bpy.props.BoolProperty(name=name, description=desc, default=bool(MAX_SPEED_DEFAULTS.get(key, default)), update=_svo_v11_prop_update)
    for key, name, desc, min_v, max_v in (
        ("subdivision_level", "Subdivision level", "Viewport subdivision level. Lower values are lighter; 0 is fastest.", 0, 12),
        ("texture_size", "Texture size", "Viewport texture size limit used by Simplify. Lower values are lighter but blurrier.", 0, 8192),
        ("particle_display_percentage", "Particle display percentage", "Viewport particle display percentage. Lower values reduce particle drawing cost.", 0, 100),
        ("particle_display_step", "Particle display step", "Viewport particle draw step when supported. Lower values reduce preview sampling.", 0, 10),
        ("heavy_vertex_threshold", "Heavy vertex threshold", "Objects at or above this vertex count are treated as heavy when heavy-object culling is enabled.", 1, 100000000),
        ("heavy_modifier_threshold", "Heavy modifier threshold", "Objects at or above this modifier count are treated as heavy when heavy-object culling is enabled.", 0, 1024),
        ("heavy_particle_threshold", "Heavy particle threshold", "Objects at or above this particle-system count are treated as heavy when heavy-object culling is enabled.", 0, 1024),
    ):
        ann[key] = bpy.props.IntProperty(name=name, description=desc, default=int(MAX_SPEED_DEFAULTS.get(key, min_v)), min=min_v, max=max_v, update=_svo_v11_prop_update)
    for key, name, desc, min_v, max_v, precision in (
        ("volume_value", "Volume value", "Simplify volume value. Lower values reduce volume redraw cost.", 0.0, 1.0, 2),
        ("child_particle_percentage", "Child particle percentage", "Simplify child particle percentage. Lower values reduce child particle drawing cost.", 0.0, 1.0, 2),
        ("clip_end", "Clip End", "3D View far clipping distance. Lower values can reduce drawing in extremely large scenes.", 1.0, 1000000000.0, 2),
        ("clip_start", "Clip Start", "3D View near clipping distance. Keep small for close-up editing.", 0.000001, 1000.0, 6),
    ):
        ann[key] = bpy.props.FloatProperty(name=name, description=desc, default=float(MAX_SPEED_DEFAULTS.get(key, min_v)), min=min_v, max=max_v, precision=precision, update=_svo_v11_prop_update)
    for key, name, desc in (
        ("simplify_grease_pencil", "Simplify Grease Pencil", "Apply Grease Pencil simplification when available."),
        ("limit_far_clip", "Limit Far Clip", "Apply the far clipping distance to visible 3D Views."),
        ("limit_near_clip", "Limit Near Clip", "Apply the near clipping distance to visible 3D Views."),
        ("force_orthographic_view", "Force Orthographic View", "Switch visible 3D Views to Orthographic when applying settings."),
        ("clear_view3d_locks", "Clear View Locks", "Clear common 3D View locks such as camera, cursor, bone, and object locks."),
        ("force_object_mode_on_apply", "Force Object Mode before apply", "Switch to Object Mode before applying settings when possible."),
        ("clear_selection_on_apply", "Clear selection on apply", "Deselect objects when applying speed settings. This can reduce outline and pivot-related navigation cost."),
        ("enable_heavy_object_culling", "Cull heavy objects", "Apply the selected heavy-object action to objects above the configured thresholds."),
        ("enable_navigation_guard", "Enable navigation prewarm guard", "Store this preference without starting a background guard. Performance builds keep guard timers stopped."),
        ("prewarm_on_mouse_move", "Prewarm on mouse move", "Store this preference without starting mouse-move prewarm. Performance builds keep it stopped."),
        ("prewarm_view_matrix_nudge", "Prewarm view matrix nudge", "Store this preference without nudging view matrices during navigation."),
        ("enable_idle_warm_pulse", "Enable idle warm pulse", "Store this preference without starting an idle pulse timer."),
        ("idle_pulse_view_layer_update", "Update view layer in idle pulse", "Store this preference without starting an idle pulse timer."),
    ):
        ann[key] = bpy.props.BoolProperty(name=name, description=desc, default=bool(MAX_SPEED_DEFAULTS.get(key, False)), update=_svo_v11_prop_update)
    for key, name, desc, min_v, max_v, precision in (
        ("prewarm_interval", "Prewarm interval", "Stored prewarm interval. Timers stay stopped in the performance build.", 0.02, 10.0, 2),
        ("idle_warm_pulse_interval", "Idle pulse interval", "Stored idle pulse interval. Timers stay stopped in the performance build.", 0.05, 60.0, 2),
    ):
        ann[key] = bpy.props.FloatProperty(name=name, description=desc, default=float(MAX_SPEED_DEFAULTS.get(key, min_v)), min=min_v, max=max_v, precision=precision, update=_svo_v11_prop_update)
    for key, name, desc, min_v, max_v in (
        ("prewarm_redraw_iterations", "Prewarm redraw iterations", "Stored redraw iteration count. Timers stay stopped in the performance build.", 0, 20),
        ("idle_pulse_redraw_iterations", "Idle pulse redraw iterations", "Stored idle redraw iteration count. Timers stay stopped in the performance build.", 0, 20),
    ):
        ann[key] = bpy.props.IntProperty(name=name, description=desc, default=int(MAX_SPEED_DEFAULTS.get(key, min_v)), min=min_v, max=max_v, update=_svo_v11_prop_update)
    ann["heavy_object_action"] = bpy.props.EnumProperty(
        name="Heavy object action",
        description="Action used for heavy objects. Hide Viewport is strongest; Bounds and Wire are safer.",
        items=(("HIDE_VIEWPORT", "Hide Viewport", "Hide heavy objects in the viewport."), ("BOUNDS", "Bounds", "Show heavy objects as bounding boxes."), ("WIRE", "Wire", "Show heavy objects as wire."), ("HIDE_SELECT", "Disable Selection", "Make heavy objects unselectable.")),
        default=MAX_SPEED_DEFAULTS.get("heavy_object_action", "BOUNDS"),
        update=_svo_v11_prop_update,
    )

_svo_v12_patch_live_update_properties()


_SVO_PERSISTENCE_UPDATE_CALLBACKS = {}


def _svo_begin_canonical_rna_restore():
    """Suspend live/preset side effects while central RNA is replayed."""
    global _SVO_V12_SETTINGS_IO_GUARD, _SVO_V10_PRESET_UPDATE_GUARD
    token = (bool(_SVO_V12_SETTINGS_IO_GUARD), bool(_SVO_V10_PRESET_UPDATE_GUARD))
    _SVO_V12_SETTINGS_IO_GUARD = True
    _SVO_V10_PRESET_UPDATE_GUARD = True
    return token


def _svo_end_canonical_rna_restore(token) -> None:
    global _SVO_V12_SETTINGS_IO_GUARD, _SVO_V10_PRESET_UPDATE_GUARD
    try:
        old_io, old_preset = token
    except Exception:
        old_io, old_preset = False, False
    _SVO_V12_SETTINGS_IO_GUARD = bool(old_io)
    _SVO_V10_PRESET_UPDATE_GUARD = bool(old_preset)


def _svo_make_canonical_persistence_update(previous, property_name):
    """Return an RNA-valid two-argument update callback.

    Blender validates the callback signature while registering a property.  A
    closure default argument still counts as a third positional parameter, so
    capture the previous callback and property name in an outer factory.
    """
    def _combined(self, context):
        global _SVO_CANONICAL_PERSIST_UPDATE_DEPTH, _SVO_CANONICAL_PERSIST_PENDING
        if _SVO_CANONICAL_PERSIST_UPDATE_DEPTH > 0 or _SVO_V12_SETTINGS_IO_GUARD or _SVO_V10_PRESET_UPDATE_GUARD:
            _SVO_CANONICAL_PERSIST_PENDING = True
            if callable(previous):
                try:
                    previous(self, context)
                except Exception:
                    pass
            return
        try:
            from .. import persistence as _suite_persistence
            if _suite_persistence.runtime_sidecar_write_blocked(
                verified_user_change=True,
            ):
                return
        except Exception:
            pass
        _SVO_CANONICAL_PERSIST_UPDATE_DEPTH += 1
        storage_guarded = False
        try:
            try:
                if _sws_storage is not None:
                    _sws_storage.begin_central_write_batch()
                    storage_guarded = True
            except Exception:
                storage_guarded = False
            if callable(previous):
                try:
                    previous(self, context)
                except Exception:
                    pass
        finally:
            if storage_guarded:
                try:
                    _sws_storage.end_central_write_batch()
                except Exception:
                    pass
            _SVO_CANONICAL_PERSIST_UPDATE_DEPTH = max(0, _SVO_CANONICAL_PERSIST_UPDATE_DEPTH - 1)
        try:
            from .. import persistence as _suite_persistence
            if not _suite_persistence.persist_immediate_user_change(
                context,
                source=f'viewport-optimizer:{property_name}',
            ):
                _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        _SVO_CANONICAL_PERSIST_PENDING = False

    _combined.__name__ = f'_svo_persist_{property_name}'
    _combined.__module__ = __name__
    return _combined


def _svo_install_canonical_persistence_updates() -> None:
    """Chain canonical JSON persistence onto every optimizer setting."""
    annotations = getattr(SVO_PLUS_PG_settings, '__annotations__', {}) or {}
    for name, deferred in list(annotations.items()):
        try:
            keywords = getattr(deferred, 'keywords', None)
            if not isinstance(keywords, dict) or name in _SVO_PERSISTENCE_UPDATE_CALLBACKS:
                continue
            _combined = _svo_make_canonical_persistence_update(keywords.get('update'), name)
            _SVO_PERSISTENCE_UPDATE_CALLBACKS[name] = _combined
            keywords['update'] = _combined
        except Exception:
            continue


_svo_install_canonical_persistence_updates()


# -- crash-safe setter guard for SpaceView3D RNA properties --
# Blender 5.1 can crash when some SpaceView3D UI/header-only RNA properties are
# restored from file handlers or background contexts. These properties remain in
# the UI, but snapshot restore skips the risky RNA writes.
_SVO_V11_ORIGINAL_SAFE_SET = _safe_set
_SVO_V11_SPACE_SNAPSHOT_SKIP_PREFIXES = (
    "show_region_",
)
_SVO_V11_SPACE_SNAPSHOT_SKIP_ATTRS = {
    "show_object_viewport_pointcloud",
    "show_object_select_pointcloud",
    "show_reconstruction",
    "show_camera_path",
}

def _svo_v11_is_space_view3d(target):
    try:
        return target.__class__.__name__ == "SpaceView3D"
    except Exception:
        return False

def _safe_set(target, attr, value):
    try:
        if _svo_v11_is_space_view3d(target):
            if any(str(attr).startswith(prefix) for prefix in _SVO_V11_SPACE_SNAPSHOT_SKIP_PREFIXES):
                return False
            if attr in _SVO_V11_SPACE_SNAPSHOT_SKIP_ATTRS:
                return False
            if bpy.app.background and (str(attr).startswith("show_object_viewport_") or str(attr).startswith("show_object_select_")):
                return False
    except Exception:
        pass
    return _SVO_V11_ORIGINAL_SAFE_SET(target, attr, value)

# -- presets ------------------------------------------------------------------

def _svo_v11_base_preset(**overrides: Any) -> Dict[str, Any]:
    data = dict(_SVO_V11_DEFAULTS)
    data.update({
        "auto_apply_on_enable": False,
        "auto_apply_on_load": False,
        "object_scope": "VISIBLE",
        "include_scene_simplify": True,
        "include_viewport_shading": True,
        "include_overlays": True,
        "include_gizmos": True,
        "include_object_filters": True,
        "include_object_display": True,
        "include_modifiers": True,
        "include_particles": True,
        "include_preferences": True,
        "include_navigation_latency": True,
        "include_constraints": True,
        "include_viewport_prewarm": False,
        "use_simplify": True,
        "subdivision_level": 1,
        "volume_value": 0.5,
        "child_particle_percentage": 0.5,
        "texture_size": 1024,
        "simplify_grease_pencil": False,
        "reduce_particle_previews": True,
        "particle_display_percentage": 50,
        "particle_display_step": 2,
        "enable_heavy_object_culling": True,
        "heavy_object_action": "BOUNDS",
        "heavy_vertex_threshold": 120000,
        "heavy_modifier_threshold": 5,
        "heavy_particle_threshold": 2,
        "prewarm_view_matrix_nudge": False,
        "enable_idle_warm_pulse": False,
        "idle_warm_pulse_interval": 1.0,
        "idle_pulse_view_layer_update": False,
        "idle_pulse_redraw_iterations": 0,
        "enable_navigation_guard": False,
        "prewarm_on_mouse_move": False,
        "prewarm_interval": 0.35,
        "prewarm_redraw_iterations": 0,
        "restore_after_navigation_idle": False,
        "target_show_navigate_ui": False,
        "target_use_mouse_depth_navigate": False,
        "target_use_auto_perspective": False,
        "target_smooth_view": 0,
        "target_viewport_aa": "OFF",
        "target_texture_time_out": 1800,
        "target_vbo_time_out": 1800,
        "target_texture_collection_rate": 1800,
        "target_vbo_collection_rate": 1800,
        "target_use_region_overlap": False,
        "target_use_reduce_motion": True,
        "target_show_statusbar_stats": False,
        "target_show_statusbar_memory": False,
        "target_show_statusbar_vram": False,
        "target_show_statusbar_version": False,
    })
    data.update(overrides)
    return data

_SVO_V11_PRESET_VALUES = {
    "PERFORMANCE_HIGH": _svo_v11_base_preset(
        object_scope="ALL", include_constraints=True, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="SOLID", target_shading_light="FLAT", target_shading_color_type="SINGLE",
        target_show_shadows=False, target_show_cavity=False, target_show_object_outline=False, target_show_specular_highlight=False,
        target_show_overlays=False, target_show_gizmo=False, target_show_relationship_lines=False,
        target_show_floor=False, target_show_axis_x=False, target_show_axis_y=False, target_show_axis_z=False,
        target_show_text=False, target_show_stats=False, target_show_extras=False, target_show_wireframes=False,
        target_show_outline_selected=False, target_show_object_origins=False, target_show_motion_paths=False,
        target_show_annotation=False, target_show_bones=False, target_show_faces=False, target_show_face_center=False,
        target_show_edge_seams=False, target_show_face_normals=False, target_show_vertex_normals=False,
        target_show_split_normals=False, target_show_onion_skins=False, target_use_gpencil_grid=False,
        target_show_object_viewport_camera=False, target_show_object_viewport_light=False, target_show_object_viewport_empty=False,
        target_show_object_viewport_armature=False, target_show_object_viewport_curve=False, target_show_object_viewport_surface=False,
        target_show_object_viewport_font=False, target_show_object_viewport_metaball=False, target_show_object_viewport_lattice=False,
        target_show_object_viewport_speaker=False, target_show_object_viewport_light_probe=False, target_show_object_viewport_volume=False,
        target_show_object_viewport_grease_pencil=False, target_show_object_viewport_pointcloud=False,
        target_object_display_type="SOLID", target_display_bounds_type="BOX", target_object_show_name=False,
        target_object_show_axis=False, target_object_show_texture_space=False, target_object_show_bounds=False,
        target_object_show_wire=False, target_object_show_all_edges=False, target_object_show_in_front=False,
        target_object_show_transparent=False, target_object_selectable=False, target_object_show_instancer_for_viewport=False,
        target_object_use_simulation_cache=False, target_show_viewport_modifiers=False, target_show_subdivision_modifiers=False,
        target_show_geometry_nodes=False, target_show_simulation_modifiers=False, target_show_deformer_modifiers=False,
        target_show_generator_modifiers=False, target_show_normal_data_modifiers=False, target_show_other_modifiers=False,
        target_object_constraints_enabled=False, target_pose_constraints_enabled=False,
        use_simplify=True, subdivision_level=0, volume_value=0.0, child_particle_percentage=0.0, texture_size=128,
        simplify_grease_pencil=True, particle_display_percentage=0, particle_display_step=0,
        target_viewport_aa="OFF", target_scene_viewport_aa="OFF", target_scene_render_aa="OFF",
        target_gl_texture_limit="CLAMP_512", target_texture_time_out=0, target_vbo_time_out=0,
        target_texture_collection_rate=1800, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=False, target_use_edit_mode_smooth_wire=False, target_shader_compilation_method="THREAD",
        target_use_region_overlap=False, target_show_navigate_ui=False, target_use_reduce_motion=True,
        target_use_mouse_depth_navigate=False, target_use_zoom_to_mouse=False, target_use_rotate_around_active=False,
        target_use_auto_perspective=False, target_smooth_view=0, target_view_rotate_method="TURNTABLE", target_view_zoom_method="SCALE",
        target_view_zoom_axis="VERTICAL", target_ndof_show_guide_orbit_axis=False, target_ndof_show_guide_orbit_center=False,
        target_use_global_undo=False, target_undo_steps=0, target_undo_memory_limit=0, target_use_auto_keying=False,
        target_use_snap=False, target_use_mesh_automerge=False, target_use_mesh_automerge_and_split=False,
        clear_selection_on_apply=True, force_object_mode_on_apply=True, enable_heavy_object_culling=False,
        heavy_object_action="BOUNDS", heavy_vertex_threshold=50000, heavy_modifier_threshold=1, heavy_particle_threshold=1,
        enable_navigation_guard=False, prewarm_on_mouse_move=False, prewarm_interval=0.25, prewarm_redraw_iterations=0,
        prewarm_view_matrix_nudge=False, enable_idle_warm_pulse=False, idle_warm_pulse_interval=0.8,
        target_render_preview_pixel_size="8", target_render_use_high_quality_normals=False,
        target_render_use_simplify_normals=True, target_render_use_persistent_data=False,
        target_eevee_taa_samples=1, target_eevee_use_taa_reprojection=False, target_eevee_use_shadows=False,
        target_eevee_shadow_pool_size="16", target_eevee_shadow_resolution_scale=0.125, target_eevee_shadow_ray_count=1,
        target_eevee_shadow_step_count=1, target_eevee_use_raytracing=False, target_eevee_volumetric_tile_size="16",
        target_eevee_volumetric_samples=1, target_eevee_volumetric_ray_depth=1, target_eevee_use_volumetric_shadows=False,
        target_eevee_volumetric_shadow_samples=1, target_cycles_preview_samples=1, target_cycles_use_preview_denoising=False,
        target_cycles_preview_denoising_quality="FAST", target_cycles_texture_limit="512", target_cycles_volume_preview_step_rate=4.0,
        target_cycles_preview_dicing_rate=32.0),

    "PERFORMANCE_MEDIUM": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=True, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="SOLID", target_shading_light="FLAT", target_shading_color_type="SINGLE",
        target_show_shadows=False, target_show_cavity=False, target_show_object_outline=False, target_show_specular_highlight=False,
        target_show_overlays=False, target_show_gizmo=False, target_object_display_type="WIRE", target_object_selectable=True,
        target_show_viewport_modifiers=True, target_show_subdivision_modifiers=False, target_show_geometry_nodes=False,
        target_show_simulation_modifiers=False, target_show_deformer_modifiers=True, target_show_generator_modifiers=False,
        target_show_normal_data_modifiers=False, target_show_other_modifiers=False, target_object_constraints_enabled=False,
        target_pose_constraints_enabled=False, use_simplify=True, subdivision_level=0, volume_value=0.25,
        child_particle_percentage=0.0, texture_size=512, simplify_grease_pencil=True, particle_display_percentage=10,
        particle_display_step=1, target_viewport_aa="OFF", target_scene_viewport_aa="OFF", target_scene_render_aa="FXAA",
        target_gl_texture_limit="CLAMP_1024", target_texture_time_out=0, target_vbo_time_out=0,
        target_texture_collection_rate=1800, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=False, target_use_edit_mode_smooth_wire=False, target_show_navigate_ui=False,
        target_use_mouse_depth_navigate=False, target_use_zoom_to_mouse=False, target_use_rotate_around_active=False,
        target_use_auto_perspective=False, target_smooth_view=0, target_use_global_undo=True, target_undo_steps=8,
        clear_selection_on_apply=False, force_object_mode_on_apply=False, enable_heavy_object_culling=True,
        heavy_object_action="BOUNDS", heavy_vertex_threshold=100000, heavy_modifier_threshold=3, heavy_particle_threshold=1,
        prewarm_interval=0.30, enable_idle_warm_pulse=False, idle_warm_pulse_interval=1.0,
        target_render_preview_pixel_size="4", target_render_use_high_quality_normals=False,
        target_render_use_simplify_normals=True, target_eevee_taa_samples=2, target_eevee_use_taa_reprojection=False,
        target_eevee_use_shadows=False, target_eevee_shadow_pool_size="32", target_eevee_shadow_resolution_scale=0.25,
        target_eevee_shadow_step_count=2, target_eevee_use_raytracing=False, target_eevee_volumetric_tile_size="16",
        target_eevee_volumetric_samples=4, target_eevee_volumetric_ray_depth=2, target_cycles_preview_samples=4,
        target_cycles_use_preview_denoising=False, target_cycles_texture_limit="1024", target_cycles_volume_preview_step_rate=3.0,
        target_cycles_preview_dicing_rate=24.0),

    "PERFORMANCE_LOW": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=False, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="SOLID", target_shading_light="FLAT", target_shading_color_type="MATERIAL",
        target_show_shadows=False, target_show_cavity=False, target_show_object_outline=True, target_show_specular_highlight=False,
        target_show_overlays=True, target_show_floor=False, target_show_axis_x=False, target_show_axis_y=False, target_show_axis_z=False,
        target_show_text=True, target_show_stats=False, target_show_extras=False, target_show_wireframes=False,
        target_show_gizmo=True, target_show_gizmo_navigate=False, target_object_display_type="SOLID", target_object_selectable=True,
        target_show_viewport_modifiers=True, target_show_subdivision_modifiers=True, target_show_geometry_nodes=True,
        use_simplify=True, subdivision_level=0, volume_value=0.5, child_particle_percentage=0.25, texture_size=1024,
        particle_display_percentage=25, particle_display_step=2, target_viewport_aa="OFF", target_scene_viewport_aa="FXAA",
        target_gl_texture_limit="CLAMP_1024", target_texture_time_out=0, target_vbo_time_out=0,
        target_texture_collection_rate=1800, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=False, target_use_edit_mode_smooth_wire=False, target_show_navigate_ui=False,
        target_use_mouse_depth_navigate=False, target_use_zoom_to_mouse=False, target_use_auto_perspective=False,
        target_smooth_view=0, target_use_global_undo=True, target_undo_steps=16, enable_heavy_object_culling=True,
        heavy_object_action="WIRE", heavy_vertex_threshold=180000, heavy_modifier_threshold=5, heavy_particle_threshold=2,
        target_render_preview_pixel_size="2", target_render_use_high_quality_normals=False,
        target_render_use_simplify_normals=True, target_eevee_taa_samples=4, target_eevee_use_shadows=False,
        target_eevee_shadow_pool_size="64", target_eevee_shadow_resolution_scale=0.5, target_eevee_use_raytracing=False,
        target_eevee_volumetric_tile_size="8", target_eevee_volumetric_samples=8, target_eevee_volumetric_ray_depth=4,
        target_cycles_preview_samples=8, target_cycles_use_preview_denoising=False, target_cycles_texture_limit="1024",
        target_cycles_volume_preview_step_rate=2.0, target_cycles_preview_dicing_rate=16.0),

    "BALANCED": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=False, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="SOLID", target_shading_light="FLAT", target_shading_color_type="MATERIAL",
        target_show_shadows=False, target_show_cavity=False, target_show_object_outline=True, target_show_specular_highlight=False,
        target_show_overlays=True, target_show_relationship_lines=False, target_show_stats=False, target_show_extras=True,
        target_show_gizmo=True, target_show_gizmo_navigate=False, target_object_display_type="SOLID", target_object_selectable=True,
        target_show_viewport_modifiers=True, target_show_subdivision_modifiers=True, target_show_geometry_nodes=True,
        use_simplify=True, subdivision_level=1, volume_value=0.75, child_particle_percentage=0.5, texture_size=2048,
        particle_display_percentage=50, particle_display_step=2, target_viewport_aa="OFF", target_scene_viewport_aa="FXAA",
        target_gl_texture_limit="CLAMP_2048", target_texture_time_out=300, target_vbo_time_out=0,
        target_texture_collection_rate=300, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=False, target_use_edit_mode_smooth_wire=False, target_show_navigate_ui=False,
        target_use_mouse_depth_navigate=False, target_use_zoom_to_mouse=False, target_use_auto_perspective=False,
        target_smooth_view=0, target_use_global_undo=True, target_undo_steps=32, enable_heavy_object_culling=False,
        target_render_preview_pixel_size="AUTO", target_render_use_high_quality_normals=False,
        target_render_use_simplify_normals=False, target_eevee_taa_samples=8, target_eevee_use_shadows=False,
        target_eevee_shadow_pool_size="256", target_eevee_shadow_resolution_scale=0.75, target_eevee_use_raytracing=False,
        target_eevee_volumetric_tile_size="8", target_eevee_volumetric_samples=16, target_eevee_volumetric_ray_depth=8,
        target_cycles_preview_samples=16, target_cycles_use_preview_denoising=False, target_cycles_texture_limit="2048",
        target_cycles_volume_preview_step_rate=1.5, target_cycles_preview_dicing_rate=12.0),

    "QUALITY_LOW": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=False, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="SOLID", target_shading_light="STUDIO", target_shading_color_type="MATERIAL",
        target_show_shadows=True, target_show_cavity=True, target_show_object_outline=True, target_show_specular_highlight=True,
        target_show_overlays=True, target_show_gizmo=True, target_object_display_type="SOLID", target_show_viewport_modifiers=True,
        use_simplify=True, subdivision_level=1, volume_value=1.0, child_particle_percentage=0.75, texture_size=2048,
        particle_display_percentage=75, particle_display_step=3, target_viewport_aa="FXAA", target_scene_viewport_aa="FXAA",
        target_gl_texture_limit="CLAMP_2048", target_texture_time_out=300, target_vbo_time_out=0,
        target_texture_collection_rate=300, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=True, target_use_edit_mode_smooth_wire=True, target_show_navigate_ui=True,
        target_use_mouse_depth_navigate=False, target_use_auto_perspective=False, target_smooth_view=0, target_use_global_undo=True,
        target_undo_steps=32, enable_heavy_object_culling=False, target_render_preview_pixel_size="AUTO",
        target_render_use_high_quality_normals=False, target_eevee_taa_samples=12, target_eevee_use_shadows=True,
        target_eevee_shadow_pool_size="512", target_eevee_shadow_resolution_scale=1.0, target_eevee_use_raytracing=False,
        target_eevee_volumetric_tile_size="8", target_eevee_volumetric_samples=32, target_cycles_preview_samples=32,
        target_cycles_use_preview_denoising=True, target_cycles_preview_denoising_quality="FAST", target_cycles_texture_limit="2048",
        target_cycles_volume_preview_step_rate=1.0, target_cycles_preview_dicing_rate=8.0),

    "QUALITY_MEDIUM": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=False, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="MATERIAL", target_shading_light="STUDIO", target_shading_color_type="MATERIAL",
        target_use_scene_lights=False, target_use_scene_world=False, target_show_specular_highlight=True,
        target_show_shadows=True, target_show_cavity=False, target_show_object_outline=True, target_show_overlays=True,
        target_show_gizmo=True, target_object_display_type="SOLID", target_show_viewport_modifiers=True, target_show_geometry_nodes=True,
        use_simplify=True, subdivision_level=2, volume_value=1.0, child_particle_percentage=1.0, texture_size=4096,
        particle_display_percentage=100, particle_display_step=4, target_viewport_aa="5", target_scene_viewport_aa="5",
        target_gl_texture_limit="CLAMP_4096", target_texture_time_out=300, target_vbo_time_out=0,
        target_texture_collection_rate=300, target_vbo_collection_rate=1800, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=True, target_use_edit_mode_smooth_wire=True, target_show_navigate_ui=True,
        target_use_mouse_depth_navigate=True, target_use_auto_perspective=True, target_smooth_view=120, target_use_global_undo=True,
        target_undo_steps=64, enable_heavy_object_culling=False, target_render_preview_pixel_size="AUTO",
        target_render_use_high_quality_normals=True, target_eevee_taa_samples=16, target_eevee_use_taa_reprojection=True,
        target_eevee_use_shadows=True, target_eevee_shadow_pool_size="512", target_eevee_shadow_resolution_scale=1.0,
        target_eevee_shadow_step_count=6, target_eevee_use_raytracing=False, target_eevee_volumetric_tile_size="4",
        target_eevee_volumetric_samples=48, target_eevee_volumetric_ray_depth=12, target_cycles_preview_samples=64,
        target_cycles_use_preview_denoising=True, target_cycles_preview_denoising_quality="BALANCED", target_cycles_texture_limit="4096",
        target_cycles_volume_preview_step_rate=1.0, target_cycles_preview_dicing_rate=6.0),

    "QUALITY_HIGH": _svo_v11_base_preset(
        object_scope="VISIBLE", include_constraints=False, include_render_preview_settings=True,
        target_gpu_backend="OPENGL", target_shading_type="RENDERED", target_shading_light="STUDIO", target_shading_color_type="MATERIAL",
        target_use_scene_lights=True, target_use_scene_world=True, target_use_scene_lights_render=True, target_use_scene_world_render=True,
        target_show_specular_highlight=True, target_show_shadows=True, target_show_cavity=True, target_show_object_outline=True,
        target_show_overlays=True, target_show_gizmo=True, target_object_display_type="SOLID", target_show_viewport_modifiers=True,
        target_show_geometry_nodes=True, use_simplify=False, subdivision_level=6, volume_value=1.0, child_particle_percentage=1.0,
        texture_size=8192, particle_display_percentage=100, particle_display_step=6, target_viewport_aa="8", target_scene_viewport_aa="8",
        target_scene_render_aa="16", target_gl_texture_limit="CLAMP_OFF", target_texture_time_out=120, target_vbo_time_out=120,
        target_texture_collection_rate=60, target_vbo_collection_rate=60, target_use_gpu_subdivision=True,
        target_use_overlay_smooth_wire=True, target_use_edit_mode_smooth_wire=True, target_show_navigate_ui=True,
        target_use_mouse_depth_navigate=True, target_use_zoom_to_mouse=True, target_use_rotate_around_active=True,
        target_use_auto_perspective=True, target_smooth_view=200, target_use_global_undo=True, target_undo_steps=64,
        enable_heavy_object_culling=False, target_render_preview_pixel_size="1", target_render_use_high_quality_normals=True,
        target_render_use_simplify_normals=False, target_render_use_persistent_data=True, target_eevee_taa_samples=32,
        target_eevee_use_taa_reprojection=True, target_eevee_use_shadows=True, target_eevee_shadow_pool_size="1024",
        target_eevee_shadow_resolution_scale=1.0, target_eevee_shadow_ray_count=2, target_eevee_shadow_step_count=8,
        target_eevee_use_raytracing=True, target_eevee_ray_tracing_method="SCREEN", target_eevee_volumetric_tile_size="2",
        target_eevee_volumetric_samples=64, target_eevee_volumetric_ray_depth=16, target_eevee_use_volumetric_shadows=True,
        target_eevee_volumetric_shadow_samples=16, target_cycles_preview_samples=128, target_cycles_use_preview_denoising=True,
        target_cycles_preview_denoising_quality="HIGH", target_cycles_texture_limit="OFF", target_cycles_volume_preview_step_rate=1.0,
        target_cycles_preview_dicing_rate=4.0),
}

for _ident, _values in _SVO_V11_PRESET_VALUES.items():
    if _ident in SVO_V6_PRESETS:
        SVO_V6_PRESETS[_ident].setdefault("values", {}).update(_values)

# User-facing preset set: exactly three simple modes.
# Older seven-level and workspace-specific identifiers are kept only as hidden
# migration inputs; they are never shown in the preset selector.
SVO_V6_PRESETS.clear()
SVO_V6_PRESETS.update({
    "PERFORMANCE": {
        "name": "Performance",
        "effect": "Maximum speed preset for orbit, pan, and zoom responsiveness. It uses flat Solid display, disables overlays/gizmos/AA/shadows/cavity, keeps cache data hot, and reduces expensive preview, modifier, object, particle, and navigation costs.",
        "values": dict(_SVO_V11_PRESET_VALUES.get("PERFORMANCE_HIGH", {})),
    },
    "BALANCED": {
        "name": "Balanced",
        "effect": "Balanced preset for normal work. It preserves more object visibility and editing feedback than Performance while still reducing the settings that most often create viewport navigation start lag.",
        "values": dict(_SVO_V11_PRESET_VALUES.get("BALANCED", {})),
    },
    "QUALITY": {
        "name": "Quality",
        "effect": "Quality-oriented preset. It keeps more visual feedback, helpers, modifiers, and preview quality than Balanced, so it is heavier but useful for look checking.",
        "values": dict(_SVO_V11_PRESET_VALUES.get("QUALITY_HIGH", {})),
    },
})
_SVO_LEGACY_PRESET_MIGRATION.update({
    "PERFORMANCE_HIGH": "PERFORMANCE",
    "PERFORMANCE_MEDIUM": "PERFORMANCE",
    "PERFORMANCE_LOW": "PERFORMANCE",
    "QUALITY_LOW": "QUALITY",
    "QUALITY_MEDIUM": "QUALITY",
    "QUALITY_HIGH": "QUALITY",
    "BALANCED": "BALANCED",
})
for _legacy_key in list(_SVO_LEGACY_PRESET_MIGRATION.keys()):
    if str(_legacy_key).startswith("WORKSPACE_"):
        _SVO_LEGACY_PRESET_MIGRATION[_legacy_key] = "BALANCED"
MAX_SPEED_DEFAULTS["selected_preset"] = "PERFORMANCE"
OPTIMIZER_SAFE_DEFAULTS["selected_preset"] = "PERFORMANCE"


# Performance-first runtime policy: the built-in presets must not create modal
# event monitors, idle redraw timers, or automatic disk I/O.  The actual
# viewport speed-up comes from reducing redraw complexity, not from doing work
# on every mouse-move or timer tick.
_SVO_PERFORMANCE_RUNTIME_CLAMP = {
    "include_viewport_prewarm": False,
    "enable_navigation_guard": False,
    "prewarm_on_mouse_move": False,
    "prewarm_view_matrix_nudge": False,
    "enable_idle_warm_pulse": False,
    "idle_pulse_view_layer_update": False,
    "idle_pulse_redraw_iterations": 0,
    "prewarm_redraw_iterations": 0,
    "auto_save_workspace_preset_changes": False,
    "external_backup_on_register": False,
    "external_backup_on_startup": False,
    "external_backup_before_apply": False,
    "external_backup_on_file_load": False,
    "keep_backup_history": False,
    "target_texture_time_out": 0,
    "target_vbo_time_out": 0,
    "target_texture_collection_rate": 1800,
    "target_vbo_collection_rate": 1800,
    "target_viewport_aa": "OFF",
    "target_scene_viewport_aa": "OFF",
    "target_use_mouse_depth_navigate": False,
    "target_use_zoom_to_mouse": False,
    "target_use_rotate_around_active": False,
    "target_use_auto_perspective": False,
    "target_smooth_view": 0,
    "target_show_navigate_ui": False,
}
for _preset in SVO_V6_PRESETS.values():
    try:
        _preset.setdefault("values", {}).update(_SVO_PERFORMANCE_RUNTIME_CLAMP)
    except Exception:
        pass
MAX_SPEED_DEFAULTS.update(_SVO_PERFORMANCE_RUNTIME_CLAMP)
OPTIMIZER_SAFE_DEFAULTS.update(_SVO_PERFORMANCE_RUNTIME_CLAMP)


# -- runtime application using positive target values --------------------------

def _svo_v11_get(settings: bpy.types.PropertyGroup, name: str, default: Any = None) -> Any:
    try:
        return getattr(settings, name)
    except Exception:
        return default


def _svo_v11_set_any(target: Any, names: Sequence[str], value: Any) -> None:
    for name in names:
        try:
            if hasattr(target, name):
                setattr(target, name, value)
                return
        except Exception:
            pass


def _svo_v11_modifier_enabled(settings: bpy.types.PropertyGroup, modifier_type: str) -> bool:
    if not _svo_v11_get(settings, "target_show_viewport_modifiers", True):
        return False
    if modifier_type in SUBDIVISION_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_subdivision_modifiers", True))
    if modifier_type in GEOMETRY_NODE_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_geometry_nodes", True))
    if modifier_type in SIMULATION_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_simulation_modifiers", True))
    if modifier_type in DEFORMER_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_deformer_modifiers", True))
    if modifier_type in GENERATOR_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_generator_modifiers", True))
    if modifier_type in NORMAL_DATA_MODIFIERS:
        return bool(_svo_v11_get(settings, "target_show_normal_data_modifiers", True))
    return bool(_svo_v11_get(settings, "target_show_other_modifiers", True))


def _apply_scene_simplify(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_scene_simplify", True):
        return
    for scn in _target_scenes(context, settings):
        render = getattr(scn, "render", None)
        if render is None:
            continue
        _safe_set(render, "use_simplify", bool(_svo_v11_get(settings, "use_simplify", True)))
        _safe_set(render, "simplify_subdivision", int(_svo_v11_get(settings, "subdivision_level", 1)))
        _safe_set(render, "simplify_volumes", float(_svo_v11_get(settings, "volume_value", 0.5)))
        _safe_set(render, "simplify_child_particles", float(_svo_v11_get(settings, "child_particle_percentage", 0.5)))
        _safe_set(render, "simplify_texture_size", int(_svo_v11_get(settings, "texture_size", 1024)))
        gp = bool(_svo_v11_get(settings, "simplify_grease_pencil", False))
        _safe_set(render, "simplify_gpencil", gp)
        _safe_set(render, "simplify_gpencil_modifier", gp)
        _safe_set(render, "simplify_gpencil_shader_fx", gp)
        _safe_set(render, "simplify_gpencil_antialiasing", gp)
        _safe_set(render, "simplify_gpencil_onplay", gp)
        _safe_set(render, "simplify_gpencil_view_fill", gp)
        # Normal quality is controlled by the Render Preview / Engine section so
        # every changed Blender setting has a visible, explicit Detailed Setting.


def _apply_viewport_shading(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_viewport_shading", True):
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        shading = getattr(space, "shading", None)
        if shading is None:
            continue
        for prop, key in (
            ("type", "target_shading_type"), ("light", "target_shading_light"), ("color_type", "target_shading_color_type"),
            ("wireframe_color_type", "target_wireframe_color_type"), ("background_type", "target_background_type"),
            ("cavity_type", "target_cavity_type"), ("use_compositor", "target_use_compositor"),
            ("show_shadows", "target_show_shadows"), ("shadow_intensity", "target_shadow_intensity"),
            ("show_cavity", "target_show_cavity"), ("show_object_outline", "target_show_object_outline"),
            ("show_specular_highlight", "target_show_specular_highlight"), ("show_xray", "target_show_xray"),
            ("xray_alpha", "target_xray_alpha"), ("show_xray_wireframe", "target_show_xray_wireframe"),
            ("xray_alpha_wireframe", "target_xray_alpha_wireframe"), ("show_backface_culling", "target_show_backface_culling"),
            ("use_scene_lights", "target_use_scene_lights"), ("use_scene_world", "target_use_scene_world"),
            ("use_scene_lights_render", "target_use_scene_lights_render"), ("use_scene_world_render", "target_use_scene_world_render"),
            ("use_dof", "target_use_dof"), ("studiolight_intensity", "target_studiolight_intensity"),
            ("studiolight_background_alpha", "target_studiolight_background_alpha"),
            ("studiolight_background_blur", "target_studiolight_background_blur"),
        ):
            _safe_set(shading, prop, _svo_v11_get(settings, key))
        if _svo_v11_get(settings, "limit_far_clip", False):
            _safe_set(space, "clip_end", float(_svo_v11_get(settings, "clip_end", 1000.0)))
        if _svo_v11_get(settings, "limit_near_clip", False):
            _safe_set(space, "clip_start", float(_svo_v11_get(settings, "clip_start", 0.05)))


def _apply_overlays(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_overlays", True):
        return
    overlay_map = {
        "show_overlays": "target_show_overlays", "show_relationship_lines": "target_show_relationship_lines", "show_floor": "target_show_floor",
        "show_axis_x": "target_show_axis_x", "show_axis_y": "target_show_axis_y", "show_axis_z": "target_show_axis_z",
        "show_text": "target_show_text", "show_stats": "target_show_stats", "show_extras": "target_show_extras",
        "show_wireframes": "target_show_wireframes", "wireframe_opacity": "target_wireframe_opacity", "wireframe_threshold": "target_wireframe_threshold",
        "show_outline_selected": "target_show_outline_selected", "show_object_origins": "target_show_object_origins", "show_object_origins_all": "target_show_object_origins_all",
        "show_motion_paths": "target_show_motion_paths", "show_annotation": "target_show_annotation", "show_bones": "target_show_bones",
        "show_faces": "target_show_faces", "show_face_center": "target_show_face_center", "show_face_orientation": "target_show_face_orientation",
        "show_edge_crease": "target_show_edge_crease", "show_edge_sharp": "target_show_edge_sharp", "show_edge_bevel_weight": "target_show_edge_bevel_weight",
        "show_edge_seams": "target_show_edge_seams", "show_extra_indices": "target_show_extra_indices", "show_extra_edge_length": "target_show_extra_edge_length",
        "show_extra_edge_angle": "target_show_extra_edge_angle", "show_extra_face_area": "target_show_extra_face_area", "show_extra_face_angle": "target_show_extra_face_angle",
        "show_freestyle_edge_marks": "target_show_freestyle_edge_marks", "show_freestyle_face_marks": "target_show_freestyle_face_marks",
        "show_face_normals": "target_show_face_normals", "show_vertex_normals": "target_show_vertex_normals", "show_split_normals": "target_show_split_normals",
        "show_curve_normals": "target_show_curve_normals", "normals_length": "target_normals_length", "show_fade_inactive": "target_show_fade_inactive",
        "fade_inactive_alpha": "target_fade_inactive_alpha", "show_sculpt_face_sets": "target_show_face_sets", "show_sculpt_mask": "target_show_sculpt_mask",
        "show_onion_skins": "target_show_onion_skins", "use_gpencil_grid": "target_use_gpencil_grid", "use_gpencil_onion_skin": "target_use_gpencil_onion_skin",
        "use_gpencil_edit_lines": "target_use_gpencil_edit_lines", "use_debug_freeze_view_culling": "target_use_debug_freeze_view_culling",
    }
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        overlay = getattr(space, "overlay", None)
        if overlay is None:
            continue
        for prop, key in overlay_map.items():
            _safe_set(overlay, prop, _svo_v11_get(settings, key))


def _apply_gizmos(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_gizmos", True):
        return
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        for prop, key in (
            ("show_gizmo", "target_show_gizmo"), ("show_gizmo_navigate", "target_show_gizmo_navigate"),
            ("show_gizmo_tool", "target_show_gizmo_tool"), ("show_gizmo_context", "target_show_gizmo_context"),
            ("show_gizmo_object_translate", "target_show_gizmo_object_translate"), ("show_gizmo_object_rotate", "target_show_gizmo_object_rotate"),
            ("show_gizmo_object_scale", "target_show_gizmo_object_scale"), ("show_gizmo_modifier", "target_show_gizmo_modifier"),
            ("show_gizmo_light_size", "target_show_gizmo_light_size"), ("show_gizmo_light_look_at", "target_show_gizmo_light_look_at"),
            ("show_gizmo_camera_lens", "target_show_gizmo_camera_lens"), ("show_gizmo_camera_dof_distance", "target_show_gizmo_camera_dof_distance"),
            ("show_gizmo_empty_image", "target_show_gizmo_empty_image"), ("show_gizmo_empty_force_field", "target_show_gizmo_empty_force_field"),
        ):
            _safe_set(space, prop, _svo_v11_get(settings, key))


def _apply_object_filters(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_object_filters", True):
        return
    if bpy.app.background:
        return
    type_map = {
        "mesh": ("mesh",), "camera": ("camera",), "light": ("light",), "empty": ("empty",), "armature": ("armature",),
        "curve": ("curve", "curves"), "surface": ("surf", "surface"), "font": ("font",), "metaball": ("meta", "metaball"),
        "lattice": ("lattice",), "speaker": ("speaker",), "light_probe": ("light_probe",), "volume": ("volume",),
        "grease_pencil": ("grease_pencil", "gpencil"), "pointcloud": ("pointcloud",),
    }
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        for suffix, aliases in type_map.items():
            _svo_v11_set_any(space, tuple(f"show_object_viewport_{a}" for a in aliases), _svo_v11_get(settings, f"target_show_object_viewport_{suffix}", True))
            _svo_v11_set_any(space, tuple(f"show_object_select_{a}" for a in aliases), _svo_v11_get(settings, f"target_show_object_select_{suffix}", True))


def _apply_object_display(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_object_display", True):
        return
    selected = {obj.name for obj in getattr(context, "selected_objects", [])}
    display_type = _svo_v11_get(settings, "target_object_display_type", "SOLID")
    if not _svo_object_draws_without_overlays(settings, display_type):
        display_type = "SOLID"
    for obj in _target_objects(context, settings):
        _safe_set(obj, "display_type", display_type)
        _safe_set(obj, "display_bounds_type", _svo_v11_get(settings, "target_display_bounds_type", "BOX"))
        for prop, key in (
            ("show_name", "target_object_show_name"), ("show_axis", "target_object_show_axis"),
            ("show_texture_space", "target_object_show_texture_space"), ("show_bounds", "target_object_show_bounds"),
            ("show_wire", "target_object_show_wire"), ("show_all_edges", "target_object_show_all_edges"),
            ("show_in_front", "target_object_show_in_front"), ("show_transparent", "target_object_show_transparent"),
            ("show_instancer_for_viewport", "target_object_show_instancer_for_viewport"), ("use_simulation_cache", "target_object_use_simulation_cache"),
        ):
            _safe_set(obj, prop, _svo_v11_get(settings, key))
        _safe_set(obj, "hide_select", not bool(_svo_v11_get(settings, "target_object_selectable", True)))
        if _svo_v11_get(settings, "hide_unselected_objects", False) and selected and not _svo_is_work_object(context, obj):
            _safe_set(obj, "hide_viewport", True)
        if _svo_v11_get(settings, "enable_heavy_object_culling", True) and _svo_v6_is_heavy_object(obj, settings):
            _svo_v6_apply_heavy_action(context, obj, settings)


def _apply_modifiers(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_modifiers", True):
        return
    for obj in _target_objects(context, settings):
        for mod in getattr(obj, "modifiers", []):
            try:
                _safe_set(mod, "show_viewport", _svo_v11_modifier_enabled(settings, mod.type))
            except Exception:
                continue


def _apply_constraints(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_constraints", True):
        return
    obj_enabled = bool(_svo_v11_get(settings, "target_object_constraints_enabled", True))
    pose_enabled = bool(_svo_v11_get(settings, "target_pose_constraints_enabled", True))
    for obj in _target_objects(context, settings):
        for con in getattr(obj, "constraints", []):
            _safe_set(con, "mute", not obj_enabled)
        pose = getattr(obj, "pose", None)
        if pose is not None:
            for bone in getattr(pose, "bones", []):
                for con in getattr(bone, "constraints", []):
                    _safe_set(con, "mute", not pose_enabled)


def _apply_particles(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_particles", True):
        return
    try:
        particle_settings = list(bpy.data.particles)
    except Exception:
        particle_settings = []
    for pset in particle_settings:
        _safe_set(pset, "display_percentage", int(_svo_v11_get(settings, "particle_display_percentage", 50)))
        _safe_set(pset, "draw_percentage", int(_svo_v11_get(settings, "particle_display_percentage", 50)))
        _safe_set(pset, "display_step", int(_svo_v11_get(settings, "particle_display_step", 2)))
        _safe_set(pset, "draw_step", int(_svo_v11_get(settings, "particle_display_step", 2)))


def _apply_preferences(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_preferences", True):
        return
    prefs = getattr(context, "preferences", None)
    system = getattr(prefs, "system", None)
    if system is not None:
        for prop, key in (
            ("viewport_aa", "target_viewport_aa"), ("gl_texture_limit", "target_gl_texture_limit"),
            ("texture_time_out", "target_texture_time_out"), ("vbo_time_out", "target_vbo_time_out"),
            ("texture_collection_rate", "target_texture_collection_rate"), ("vbo_collection_rate", "target_vbo_collection_rate"),
            ("use_gpu_subdivision", "target_use_gpu_subdivision"), ("use_overlay_smooth_wire", "target_use_overlay_smooth_wire"),
            ("use_edit_mode_smooth_wire", "target_use_edit_mode_smooth_wire"), ("shader_compilation_method", "target_shader_compilation_method"),
            ("gpu_shader_workers", "target_gpu_shader_workers"), ("memory_cache_limit", "target_memory_cache_limit"),
            ("use_region_overlap", "target_use_region_overlap"),
        ):
            _safe_set(system, prop, _svo_v11_get(settings, key))


def _apply_navigation_latency(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    if not _svo_v11_get(settings, "include_navigation_latency", True):
        return
    prefs = getattr(context, "preferences", None)
    inputs = getattr(prefs, "inputs", None)
    if inputs is not None:
        for prop, key in (
            ("use_mouse_depth_navigate", "target_use_mouse_depth_navigate"), ("use_zoom_to_mouse", "target_use_zoom_to_mouse"),
            ("use_rotate_around_active", "target_use_rotate_around_active"), ("use_auto_perspective", "target_use_auto_perspective"),
            ("view_rotate_method", "target_view_rotate_method"), ("view_zoom_method", "target_view_zoom_method"),
            ("view_zoom_axis", "target_view_zoom_axis"), ("ndof_show_guide_orbit_axis", "target_ndof_show_guide_orbit_axis"),
            ("ndof_show_guide_orbit_center", "target_ndof_show_guide_orbit_center"),
        ):
            _safe_set(inputs, prop, _svo_v11_get(settings, key))
        # Compatibility names for older/newer Blender builds.
        if not bool(_svo_v11_get(settings, "target_ndof_show_guide_orbit_axis", False)):
            _safe_set_any(inputs, ("show_nDOF_settings", "show_ndof_settings", "use_ndof_orbit", "use_ndof_pan", "use_ndof_zoom"), False)
    view = getattr(prefs, "view", None)
    if view is not None:
        for prop, key in (
            ("smooth_view", "target_smooth_view"), ("show_navigate_ui", "target_show_navigate_ui"),
            ("use_reduce_motion", "target_use_reduce_motion"), ("show_statusbar_stats", "target_show_statusbar_stats"),
            ("show_statusbar_memory", "target_show_statusbar_memory"), ("show_statusbar_vram", "target_show_statusbar_vram"),
            ("show_statusbar_version", "target_show_statusbar_version"),
        ):
            _safe_set(view, prop, _svo_v11_get(settings, key))
    edit = getattr(prefs, "edit", None)
    if edit is not None:
        for prop, key in (
            ("use_global_undo", "target_use_global_undo"), ("undo_steps", "target_undo_steps"),
            ("undo_memory_limit", "target_undo_memory_limit"), ("use_auto_keying", "target_use_auto_keying"),
            ("use_auto_keyframe_insert_needed", "target_use_auto_keyframe_insert_needed"),
        ):
            _safe_set(edit, prop, _svo_v11_get(settings, key))
    for scn in _target_scenes(context, settings):
        tool_settings = getattr(scn, "tool_settings", None)
        if tool_settings is None:
            continue
        for prop, key in (
            ("use_keyframe_insert_auto", "target_use_keyframe_insert_auto"), ("use_snap", "target_use_snap"),
            ("use_mesh_automerge", "target_use_mesh_automerge"), ("use_mesh_automerge_and_split", "target_use_mesh_automerge_and_split"),
        ):
            _safe_set(tool_settings, prop, _svo_v11_get(settings, key))
    if _svo_v11_get(settings, "force_object_mode_on_apply", False) and _svo_v16_can_use_mode_operator(context):
        try:
            if getattr(context, "active_object", None) is not None and getattr(context.active_object, "mode", "OBJECT") != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass


def _svo_v6_apply_system_deep(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    # v11 routes these settings through _apply_preferences and _apply_navigation_latency
    # using positive Blender-standard target props. This override intentionally does
    # not apply legacy "disable_*" properties again.
    return None


def _svo_v6_apply_deeper_view(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        if _svo_v11_get(settings, "force_orthographic_view", False):
            rv3d = getattr(space, "region_3d", None)
            if rv3d:
                _safe_set(rv3d, "view_perspective", "ORTHO")
        if _svo_v11_get(settings, "clear_view3d_locks", True):
            _safe_set_any(space, ("lock_camera", "lock_cursor", "lock_bone"), False)
            _safe_set(space, "lock_object", None)

# -- sync current Blender settings into target controls ------------------------

def _svo_v11_first_view3d_space(context: bpy.types.Context) -> Optional[Any]:
    # Prefer the View3D area that invoked the operator.  This makes
    # "Load Current View Settings" read the actually open/current view instead
    # of an arbitrary first View3D when multiple 3D Viewports exist.
    try:
        space = getattr(context, "space_data", None)
        if getattr(space, "type", None) == "VIEW_3D":
            return space
    except Exception:
        pass
    try:
        area = getattr(context, "area", None)
        if getattr(area, "type", None) == "VIEW_3D":
            for space in getattr(area, "spaces", []) or []:
                if getattr(space, "type", None) == "VIEW_3D":
                    return space
    except Exception:
        pass
    for _window, _screen, _area_index, _area, _space_index, space in _iter_view3d_spaces(context):
        return space
    return None


def _svo_v11_read_attr(obj: Any, prop: str, default: Any = None) -> Any:
    try:
        return getattr(obj, prop)
    except Exception:
        return default


def _svo_v11_sync_detail_settings_from_context(context: bpy.types.Context, settings: bpy.types.PropertyGroup) -> None:
    """Read current Blender settings into the standard target properties.

    This is used when a baseline is saved or loaded so the detailed settings panel
    reflects the state that OFF will restore to. It is not run every draw call.
    """
    global _SVO_V10_PRESET_UPDATE_GUARD
    old_guard = _SVO_V10_PRESET_UPDATE_GUARD
    _SVO_V10_PRESET_UPDATE_GUARD = True
    _svo_v8_suspend_autosave(1.0)
    try:
        scn = getattr(context, "scene", None)
        render = getattr(scn, "render", None) if scn else None
        if render is not None:
            for prop, key in (("use_simplify", "use_simplify"), ("simplify_subdivision", "subdivision_level"), ("simplify_volumes", "volume_value"), ("simplify_child_particles", "child_particle_percentage"), ("simplify_texture_size", "texture_size"), ("simplify_gpencil", "simplify_grease_pencil"), ("preview_pixel_size", "target_render_preview_pixel_size"), ("use_high_quality_normals", "target_render_use_high_quality_normals"), ("use_simplify_normals", "target_render_use_simplify_normals"), ("use_persistent_data", "target_render_use_persistent_data")):
                if hasattr(settings, key) and hasattr(render, prop):
                    try: setattr(settings, key, getattr(render, prop))
                    except Exception: pass
        display = getattr(scn, "display", None) if scn else None
        if display is not None:
            for prop, key in (("viewport_aa", "target_scene_viewport_aa"), ("render_aa", "target_scene_render_aa")):
                if hasattr(settings, key) and hasattr(display, prop):
                    try: setattr(settings, key, getattr(display, prop))
                    except Exception: pass
        eevee = getattr(scn, "eevee", None) if scn else None
        if eevee is not None:
            for prop, key in (("taa_samples", "target_eevee_taa_samples"), ("use_taa_reprojection", "target_eevee_use_taa_reprojection"), ("use_shadows", "target_eevee_use_shadows"), ("shadow_pool_size", "target_eevee_shadow_pool_size"), ("shadow_resolution_scale", "target_eevee_shadow_resolution_scale"), ("shadow_ray_count", "target_eevee_shadow_ray_count"), ("shadow_step_count", "target_eevee_shadow_step_count"), ("use_raytracing", "target_eevee_use_raytracing"), ("ray_tracing_method", "target_eevee_ray_tracing_method"), ("volumetric_tile_size", "target_eevee_volumetric_tile_size"), ("volumetric_samples", "target_eevee_volumetric_samples"), ("volumetric_ray_depth", "target_eevee_volumetric_ray_depth"), ("use_volumetric_shadows", "target_eevee_use_volumetric_shadows"), ("volumetric_shadow_samples", "target_eevee_volumetric_shadow_samples")):
                if hasattr(settings, key) and hasattr(eevee, prop):
                    try: setattr(settings, key, getattr(eevee, prop))
                    except Exception: pass
        cycles = getattr(scn, "cycles", None) if scn else None
        if cycles is not None:
            for prop, key in (("preview_samples", "target_cycles_preview_samples"), ("use_preview_denoising", "target_cycles_use_preview_denoising"), ("preview_denoising_quality", "target_cycles_preview_denoising_quality"), ("texture_limit", "target_cycles_texture_limit"), ("volume_preview_step_rate", "target_cycles_volume_preview_step_rate"), ("preview_dicing_rate", "target_cycles_preview_dicing_rate")):
                if hasattr(settings, key) and hasattr(cycles, prop):
                    try: setattr(settings, key, getattr(cycles, prop))
                    except Exception: pass
        space = _svo_v11_first_view3d_space(context)
        if space is not None:
            shading = getattr(space, "shading", None)
            overlay = getattr(space, "overlay", None)
            if shading is not None:
                for prop, key in (
                    ("type", "target_shading_type"), ("light", "target_shading_light"), ("color_type", "target_shading_color_type"),
                    ("wireframe_color_type", "target_wireframe_color_type"), ("background_type", "target_background_type"), ("cavity_type", "target_cavity_type"),
                    ("use_compositor", "target_use_compositor"), ("show_shadows", "target_show_shadows"), ("shadow_intensity", "target_shadow_intensity"),
                    ("show_cavity", "target_show_cavity"), ("show_object_outline", "target_show_object_outline"), ("show_specular_highlight", "target_show_specular_highlight"),
                    ("show_xray", "target_show_xray"), ("xray_alpha", "target_xray_alpha"), ("show_xray_wireframe", "target_show_xray_wireframe"),
                    ("xray_alpha_wireframe", "target_xray_alpha_wireframe"), ("show_backface_culling", "target_show_backface_culling"),
                    ("use_scene_lights", "target_use_scene_lights"), ("use_scene_world", "target_use_scene_world"),
                    ("use_scene_lights_render", "target_use_scene_lights_render"), ("use_scene_world_render", "target_use_scene_world_render"),
                    ("use_dof", "target_use_dof"), ("studiolight_intensity", "target_studiolight_intensity"),
                    ("studiolight_background_alpha", "target_studiolight_background_alpha"), ("studiolight_background_blur", "target_studiolight_background_blur"),
                ):
                    if hasattr(settings, key) and hasattr(shading, prop):
                        try: setattr(settings, key, getattr(shading, prop))
                        except Exception: pass
            if overlay is not None:
                for prop, key in (
                    ("show_overlays", "target_show_overlays"), ("show_relationship_lines", "target_show_relationship_lines"),
                    ("show_floor", "target_show_floor"), ("show_axis_x", "target_show_axis_x"),
                    ("show_axis_y", "target_show_axis_y"), ("show_axis_z", "target_show_axis_z"),
                    ("show_text", "target_show_text"), ("show_stats", "target_show_stats"), ("show_extras", "target_show_extras"),
                    ("show_wireframes", "target_show_wireframes"), ("wireframe_opacity", "target_wireframe_opacity"),
                    ("wireframe_threshold", "target_wireframe_threshold"),
                    ("show_outline_selected", "target_show_outline_selected"),
                    ("show_object_origins", "target_show_object_origins"),
                    ("show_object_origins_all", "target_show_object_origins_all"),
                    ("show_motion_paths", "target_show_motion_paths"), ("show_annotation", "target_show_annotation"),
                    ("show_bones", "target_show_bones"), ("show_faces", "target_show_faces"),
                    ("show_face_center", "target_show_face_center"), ("show_face_orientation", "target_show_face_orientation"),
                    ("show_edge_crease", "target_show_edge_crease"), ("show_edge_sharp", "target_show_edge_sharp"),
                    ("show_edge_bevel_weight", "target_show_edge_bevel_weight"), ("show_edge_seams", "target_show_edge_seams"),
                    ("show_extra_indices", "target_show_extra_indices"), ("show_extra_edge_length", "target_show_extra_edge_length"),
                    ("show_extra_edge_angle", "target_show_extra_edge_angle"), ("show_extra_face_area", "target_show_extra_face_area"),
                    ("show_extra_face_angle", "target_show_extra_face_angle"),
                    ("show_freestyle_edge_marks", "target_show_freestyle_edge_marks"),
                    ("show_freestyle_face_marks", "target_show_freestyle_face_marks"),
                    ("show_face_normals", "target_show_face_normals"), ("show_vertex_normals", "target_show_vertex_normals"),
                    ("show_split_normals", "target_show_split_normals"), ("show_curve_normals", "target_show_curve_normals"),
                    ("normals_length", "target_normals_length"),
                    ("show_fade_inactive", "target_show_fade_inactive"), ("fade_inactive_alpha", "target_fade_inactive_alpha"),
                    ("show_sculpt_face_sets", "target_show_face_sets"), ("show_sculpt_mask", "target_show_sculpt_mask"),
                    ("show_onion_skins", "target_show_onion_skins"),
                    ("use_gpencil_grid", "target_use_gpencil_grid"),
                    ("use_gpencil_onion_skin", "target_use_gpencil_onion_skin"),
                    ("use_gpencil_edit_lines", "target_use_gpencil_edit_lines"),
                    ("use_debug_freeze_view_culling", "target_use_debug_freeze_view_culling"),
                ):
                    if hasattr(settings, key) and hasattr(overlay, prop):
                        try: setattr(settings, key, getattr(overlay, prop))
                        except Exception: pass
            for prop, key in (
                ("show_gizmo", "target_show_gizmo"), ("show_gizmo_navigate", "target_show_gizmo_navigate"),
                ("show_gizmo_tool", "target_show_gizmo_tool"), ("show_gizmo_context", "target_show_gizmo_context"),
                ("show_gizmo_object_translate", "target_show_gizmo_object_translate"),
                ("show_gizmo_object_rotate", "target_show_gizmo_object_rotate"),
                ("show_gizmo_object_scale", "target_show_gizmo_object_scale"),
                ("show_gizmo_modifier", "target_show_gizmo_modifier"),
                ("show_gizmo_light_size", "target_show_gizmo_light_size"),
                ("show_gizmo_light_look_at", "target_show_gizmo_light_look_at"),
                ("show_gizmo_camera_lens", "target_show_gizmo_camera_lens"),
                ("show_gizmo_camera_dof_distance", "target_show_gizmo_camera_dof_distance"),
                ("show_gizmo_empty_image", "target_show_gizmo_empty_image"),
                ("show_gizmo_empty_force_field", "target_show_gizmo_empty_force_field"),
            ):
                if hasattr(settings, key) and hasattr(space, prop):
                    try: setattr(settings, key, getattr(space, prop))
                    except Exception: pass
            type_map = {
                "mesh": ("mesh",), "camera": ("camera",), "light": ("light",), "empty": ("empty",),
                "armature": ("armature",), "curve": ("curve", "curves"), "surface": ("surf", "surface"),
                "font": ("font",), "metaball": ("meta", "metaball"), "lattice": ("lattice",),
                "speaker": ("speaker",), "light_probe": ("light_probe",), "volume": ("volume",),
                "grease_pencil": ("grease_pencil", "gpencil"), "pointcloud": ("pointcloud",),
            }
            for suffix, aliases in type_map.items():
                view_key = f"target_show_object_viewport_{suffix}"
                select_key = f"target_show_object_select_{suffix}"
                for alias in aliases:
                    prop_name = f"show_object_viewport_{alias}"
                    if hasattr(settings, view_key) and hasattr(space, prop_name):
                        try:
                            setattr(settings, view_key, getattr(space, prop_name))
                            break
                        except Exception:
                            pass
                for alias in aliases:
                    prop_name = f"show_object_select_{alias}"
                    if hasattr(settings, select_key) and hasattr(space, prop_name):
                        try:
                            setattr(settings, select_key, getattr(space, prop_name))
                            break
                        except Exception:
                            pass
        obj = getattr(context, "active_object", None)
        if obj is None:
            selected = getattr(context, "selected_objects", []) or []
            obj = selected[0] if selected else None
        if obj is not None:
            for prop, key in (
                ("display_type", "target_object_display_type"), ("display_bounds_type", "target_display_bounds_type"),
                ("show_name", "target_object_show_name"), ("show_axis", "target_object_show_axis"),
                ("show_texture_space", "target_object_show_texture_space"), ("show_bounds", "target_object_show_bounds"),
                ("show_wire", "target_object_show_wire"), ("show_all_edges", "target_object_show_all_edges"),
                ("show_in_front", "target_object_show_in_front"), ("show_transparent", "target_object_show_transparent"),
                ("show_instancer_for_viewport", "target_object_show_instancer_for_viewport"), ("use_simulation_cache", "target_object_use_simulation_cache"),
            ):
                if hasattr(settings, key) and hasattr(obj, prop):
                    try: setattr(settings, key, getattr(obj, prop))
                    except Exception: pass
            if hasattr(settings, "target_object_selectable") and hasattr(obj, "hide_select"):
                try: settings.target_object_selectable = not bool(obj.hide_select)
                except Exception: pass
            modifiers = list(getattr(obj, "modifiers", []) or [])
            if modifiers:
                try: settings.target_show_viewport_modifiers = all(bool(getattr(m, "show_viewport", True)) for m in modifiers)
                except Exception: pass
                cat_pairs = (
                    ("target_show_subdivision_modifiers", SUBDIVISION_MODIFIERS),
                    ("target_show_geometry_nodes", GEOMETRY_NODE_MODIFIERS),
                    ("target_show_simulation_modifiers", SIMULATION_MODIFIERS),
                    ("target_show_deformer_modifiers", DEFORMER_MODIFIERS),
                    ("target_show_generator_modifiers", GENERATOR_MODIFIERS),
                    ("target_show_normal_data_modifiers", NORMAL_DATA_MODIFIERS),
                )
                handled = set()
                for key, typeset in cat_pairs:
                    subset = [m for m in modifiers if getattr(m, "type", "") in typeset]
                    handled.update(getattr(m, "type", "") for m in subset)
                    if subset and hasattr(settings, key):
                        try: setattr(settings, key, all(bool(getattr(m, "show_viewport", True)) for m in subset))
                        except Exception: pass
                other_subset = [m for m in modifiers if getattr(m, "type", "") not in handled]
                if other_subset and hasattr(settings, "target_show_other_modifiers"):
                    try: settings.target_show_other_modifiers = all(bool(getattr(m, "show_viewport", True)) for m in other_subset)
                    except Exception: pass
            constraints = list(getattr(obj, "constraints", []) or [])
            if constraints and hasattr(settings, "target_object_constraints_enabled"):
                try: settings.target_object_constraints_enabled = all(not bool(getattr(c, "mute", False)) for c in constraints)
                except Exception: pass
            if getattr(obj, "pose", None) is not None and hasattr(settings, "target_pose_constraints_enabled"):
                pose_constraints = []
                for bone in getattr(obj.pose, "bones", []) or []:
                    pose_constraints.extend(list(getattr(bone, "constraints", []) or []))
                if pose_constraints:
                    try: settings.target_pose_constraints_enabled = all(not bool(getattr(c, "mute", False)) for c in pose_constraints)
                    except Exception: pass
            particle_systems = list(getattr(obj, "particle_systems", []) or [])
            if particle_systems:
                ps = particle_systems[0]
                psettings = getattr(ps, "settings", None)
                if psettings is not None:
                    for prop, key in (("display_percentage", "particle_display_percentage"), ("display_step", "particle_display_step")):
                        if hasattr(settings, key) and hasattr(psettings, prop):
                            try: setattr(settings, key, getattr(psettings, prop))
                            except Exception: pass
        tool_settings = getattr(scn, "tool_settings", None) if scn else None
        if tool_settings is not None:
            for prop, key in (("use_snap", "target_use_snap"), ("use_mesh_automerge", "target_use_mesh_automerge"), ("use_mesh_automerge_and_split", "target_use_mesh_automerge_and_split"), ("use_keyframe_insert_auto", "target_use_keyframe_insert_auto")):
                if hasattr(settings, key) and hasattr(tool_settings, prop):
                    try: setattr(settings, key, getattr(tool_settings, prop))
                    except Exception: pass

        prefs = getattr(context, "preferences", None)
        system = getattr(prefs, "system", None)
        if system is not None:
            for prop, key in (
                ("gpu_backend", "target_gpu_backend"), ("gpu_preferred_device", "target_gpu_preferred_device"),
                ("viewport_aa", "target_viewport_aa"), ("gl_texture_limit", "target_gl_texture_limit"),
                ("texture_time_out", "target_texture_time_out"), ("vbo_time_out", "target_vbo_time_out"),
                ("texture_collection_rate", "target_texture_collection_rate"), ("vbo_collection_rate", "target_vbo_collection_rate"),
                ("use_gpu_subdivision", "target_use_gpu_subdivision"),
                ("use_overlay_smooth_wire", "target_use_overlay_smooth_wire"),
                ("use_edit_mode_smooth_wire", "target_use_edit_mode_smooth_wire"),
                ("shader_compilation_method", "target_shader_compilation_method"),
                ("gpu_shader_workers", "target_gpu_shader_workers"), ("memory_cache_limit", "target_memory_cache_limit"),
                ("use_region_overlap", "target_use_region_overlap"),
            ):
                if hasattr(settings, key) and hasattr(system, prop):
                    try: setattr(settings, key, getattr(system, prop))
                    except Exception: pass
        inputs = getattr(prefs, "inputs", None)
        if inputs is not None:
            for prop, key in (
                ("use_mouse_depth_navigate", "target_use_mouse_depth_navigate"),
                ("use_zoom_to_mouse", "target_use_zoom_to_mouse"),
                ("use_rotate_around_active", "target_use_rotate_around_active"),
                ("use_auto_perspective", "target_use_auto_perspective"),
                ("view_rotate_method", "target_view_rotate_method"),
                ("view_zoom_method", "target_view_zoom_method"),
                ("view_zoom_axis", "target_view_zoom_axis"),
                ("ndof_show_guide_orbit_axis", "target_ndof_show_guide_orbit_axis"),
                ("ndof_show_guide_orbit_center", "target_ndof_show_guide_orbit_center"),
            ):
                if hasattr(settings, key) and hasattr(inputs, prop):
                    try: setattr(settings, key, getattr(inputs, prop))
                    except Exception: pass
        view = getattr(prefs, "view", None)
        if view is not None:
            for prop, key in (("smooth_view", "target_smooth_view"), ("show_navigate_ui", "target_show_navigate_ui"), ("use_reduce_motion", "target_use_reduce_motion"), ("show_statusbar_stats", "target_show_statusbar_stats"), ("show_statusbar_memory", "target_show_statusbar_memory"), ("show_statusbar_vram", "target_show_statusbar_vram"), ("show_statusbar_version", "target_show_statusbar_version")):
                if hasattr(settings, key) and hasattr(view, prop):
                    try: setattr(settings, key, getattr(view, prop))
                    except Exception: pass
        edit = getattr(prefs, "edit", None)
        if edit is not None:
            for prop, key in (("use_global_undo", "target_use_global_undo"), ("undo_steps", "target_undo_steps"), ("undo_memory_limit", "target_undo_memory_limit"), ("use_auto_keying", "target_use_auto_keying"), ("use_auto_keyframe_insert_needed", "target_use_auto_keyframe_insert_needed")):
                if hasattr(settings, key) and hasattr(edit, prop):
                    try: setattr(settings, key, getattr(edit, prop))
                    except Exception: pass
    finally:
        _SVO_V10_PRESET_UPDATE_GUARD = old_guard
        try:
            _svo_v8_mark_preset_baseline(settings, getattr(settings, "selected_preset", ""))
        except Exception:
            pass

# -- UI drawing ----------------------------------------------------------------

def _svo_v11_prop_grid(layout: bpy.types.UILayout, settings: bpy.types.PropertyGroup, props: Sequence[Tuple[str, str]]) -> None:
    col = layout.column(align=True)
    for prop, label in props:
        if hasattr(settings, prop):
            if settings.bl_rna.properties[prop].type == 'ENUM':
                col.label(text=iface(label) + ":")
                col.prop(settings, prop, text="")
            else:
                col.prop(settings, prop, text=iface(label))


def _svo_v11_draw_section_enable(box: bpy.types.UILayout, settings: bpy.types.PropertyGroup, prop: str) -> None:
    row = box.row(align=True)
    row.prop(settings, prop, text=iface("Use this section"))
    box.separator()


def _svo_plus_draw_detail_settings(layout: bpy.types.UILayout, settings: bpy.types.PropertyGroup, *, use_native_panel: bool = True) -> None:
    preset_box = layout.box()
    preset_box.label(text=iface("Setting Load"), icon="PRESET")
    preset_box.prop(settings, "selected_preset", text=iface("Setting"))
    preset_box.operator(VIEW3D_OT_svo_plus_apply_selected_preset.bl_idname, text=iface("Apply Preset"), icon="CHECKMARK")
    preset_box.operator(VIEW3D_OT_svo_plus_sync_details_from_current_settings.bl_idname, text=iface("Load Current View Settings"), icon="IMPORT")

    info = layout.box()
    info.label(text=iface("Detailed Settings Overview"), icon="PREFERENCES")

    groups = _draw_header(layout, settings, "show_targets", "Targets", "NONE", use_native_panel=use_native_panel)
    if groups:
        _svo_v11_prop_grid(groups, settings, (("apply_all_scenes", "Apply to all scenes"), ("object_scope", "Object Scope")))
        _svo_v11_prop_grid(groups, settings, (("include_scene_simplify", "Render Properties > Simplify"), ("include_viewport_shading", "3D Viewport > Viewport Shading"), ("include_overlays", "3D Viewport > Overlays"), ("include_gizmos", "3D Viewport > Gizmos"), ("include_object_filters", "3D Viewport > Object Type Visibility"), ("include_object_display", "Object Properties > Viewport Display"), ("include_modifiers", "Modifier Viewport Display"), ("include_constraints", "Constraints"), ("include_particles", "Particle Preview"), ("include_preferences", "Preferences > System"), ("include_navigation_latency", "Preferences > Navigation"), ("include_viewport_prewarm", "Navigation Warmup")))

    scene_box = _draw_header(layout, settings, "show_scene", "Render Properties > Simplify", "NONE", use_native_panel=use_native_panel)
    if scene_box:
        _svo_v11_draw_section_enable(scene_box, settings, "include_scene_simplify")
        _svo_v11_prop_grid(scene_box, settings, (("use_simplify", "Use Simplify"), ("subdivision_level", "Subdivision level"), ("volume_value", "Volume value"), ("child_particle_percentage", "Child particle percentage"), ("texture_size", "Texture size"), ("simplify_grease_pencil", "Simplify Grease Pencil")))

    viewport_box = _draw_header(layout, settings, "show_viewport", "3D Viewport > Viewport Shading", "NONE", use_native_panel=use_native_panel)
    if viewport_box:
        _svo_v11_draw_section_enable(viewport_box, settings, "include_viewport_shading")
        _svo_v11_prop_grid(viewport_box, settings, (
            ("target_shading_type", "Viewport Shading"), ("target_shading_light", "Lighting"),
            ("target_shading_color_type", "Color"), ("target_wireframe_color_type", "Wire Color"),
            ("target_background_type", "Background"), ("target_use_compositor", "Compositor"),
            ("target_show_shadows", "Shadow"), ("target_shadow_intensity", "Shadow Intensity"),
            ("target_show_cavity", "Cavity"), ("target_cavity_type", "Cavity Type"),
            ("target_show_object_outline", "Outline"), ("target_show_specular_highlight", "Specular Highlights"),
            ("target_show_xray", "X-Ray"), ("target_xray_alpha", "X-Ray Opacity"),
            ("target_show_xray_wireframe", "X-Ray Wireframe"), ("target_xray_alpha_wireframe", "Wireframe X-Ray Opacity"),
            ("target_show_backface_culling", "Backface Culling"), ("target_use_scene_lights", "Scene Lights"),
            ("target_use_scene_world", "Scene World"), ("target_use_scene_lights_render", "Rendered Scene Lights"),
            ("target_use_scene_world_render", "Rendered Scene World"), ("target_use_dof", "Depth of Field"),
            ("target_studiolight_intensity", "Studio Light Intensity"),
            ("target_studiolight_background_alpha", "Studio Light Background Alpha"),
            ("target_studiolight_background_blur", "Studio Light Background Blur"),
            ("limit_far_clip", "Limit Far Clip"), ("clip_end", "Clip End"),
            ("limit_near_clip", "Limit Near Clip"), ("clip_start", "Clip Start"),
            ("force_orthographic_view", "Force Orthographic View"), ("clear_view3d_locks", "Clear View Locks"),
        ))

    overlay_box = _draw_header(layout, settings, "show_overlay", "3D Viewport > Overlays", "NONE", use_native_panel=use_native_panel)
    if overlay_box:
        _svo_v11_draw_section_enable(overlay_box, settings, "include_overlays")
        _svo_v11_prop_grid(overlay_box, settings, (
            ("target_show_overlays", "Overlays"), ("target_show_relationship_lines", "Relationship Lines"),
            ("target_show_floor", "Floor"), ("target_show_axis_x", "X Axis"), ("target_show_axis_y", "Y Axis"),
            ("target_show_axis_z", "Z Axis"), ("target_show_text", "Text Info"), ("target_show_stats", "Statistics"),
            ("target_show_extras", "Extras"), ("target_show_wireframes", "Wireframes"),
            ("target_wireframe_opacity", "Wireframe Opacity"), ("target_wireframe_threshold", "Wireframe Threshold"),
            ("target_show_outline_selected", "Outline Selected"),
            ("target_show_object_origins", "Object Origins"), ("target_show_object_origins_all", "All Object Origins"),
            ("target_show_motion_paths", "Motion Paths"), ("target_show_annotation", "Annotations"),
            ("target_show_bones", "Bones"), ("target_show_faces", "Faces"), ("target_show_face_center", "Face Center"),
            ("target_show_face_orientation", "Face Orientation"), ("target_show_edge_seams", "Seams"),
            ("target_show_edge_crease", "Creases"), ("target_show_edge_sharp", "Sharp Edges"),
            ("target_show_edge_bevel_weight", "Bevel Weights"), ("target_show_extra_indices", "Indices"),
            ("target_show_extra_edge_length", "Edge Length"), ("target_show_extra_edge_angle", "Edge Angle"),
            ("target_show_extra_face_area", "Face Area"), ("target_show_extra_face_angle", "Face Angle"),
            ("target_show_freestyle_edge_marks", "Freestyle Edge Marks"),
            ("target_show_freestyle_face_marks", "Freestyle Face Marks"),
            ("target_show_face_normals", "Face Normals"), ("target_show_vertex_normals", "Vertex Normals"),
            ("target_show_split_normals", "Split Normals"), ("target_show_curve_normals", "Curve Normals"),
            ("target_normals_length", "Normals Size"), ("target_show_fade_inactive", "Fade Inactive"),
            ("target_fade_inactive_alpha", "Fade Inactive Alpha"),
            ("target_show_face_sets", "Sculpt Face Sets"), ("target_show_sculpt_mask", "Sculpt Mask"),
            ("target_show_onion_skins", "Onion Skins"), ("target_use_gpencil_grid", "Grease Pencil Grid"),
            ("target_use_gpencil_onion_skin", "Grease Pencil Onion Skin"),
            ("target_use_gpencil_edit_lines", "Grease Pencil Edit Lines"),
            ("target_use_debug_freeze_view_culling", "Freeze View Culling"),
        ))

    gizmo_box = _draw_header(layout, settings, "show_gizmo", "3D Viewport > Gizmos", "NONE", use_native_panel=use_native_panel)
    if gizmo_box:
        _svo_v11_draw_section_enable(gizmo_box, settings, "include_gizmos")
        _svo_v11_prop_grid(gizmo_box, settings, (("target_show_gizmo", "Gizmos"), ("target_show_gizmo_navigate", "Navigate Gizmo"), ("target_show_gizmo_tool", "Tool Gizmo"), ("target_show_gizmo_context", "Context Gizmo"), ("target_show_gizmo_object_translate", "Translate"), ("target_show_gizmo_object_rotate", "Rotate"), ("target_show_gizmo_object_scale", "Scale"), ("target_show_gizmo_modifier", "Modifier Gizmos"), ("target_show_gizmo_light_size", "Light Size"), ("target_show_gizmo_light_look_at", "Light Look-at"), ("target_show_gizmo_camera_lens", "Camera Lens"), ("target_show_gizmo_camera_dof_distance", "Camera DOF Distance"), ("target_show_gizmo_empty_image", "Empty Image"), ("target_show_gizmo_empty_force_field", "Empty Force Field")))

    filter_box = _draw_header(layout, settings, "show_filter", "3D Viewport > Object Type Visibility", "NONE", use_native_panel=use_native_panel)
    if filter_box:
        _svo_v11_draw_section_enable(filter_box, settings, "include_object_filters")
        _svo_v11_prop_grid(filter_box, settings, (("target_show_object_viewport_mesh", "Mesh"), ("target_show_object_viewport_camera", "Camera"), ("target_show_object_viewport_light", "Light"), ("target_show_object_viewport_empty", "Empty"), ("target_show_object_viewport_armature", "Armature"), ("target_show_object_viewport_curve", "Curve"), ("target_show_object_viewport_surface", "Surface"), ("target_show_object_viewport_font", "Text"), ("target_show_object_viewport_metaball", "Metaball"), ("target_show_object_viewport_lattice", "Lattice"), ("target_show_object_viewport_speaker", "Speaker"), ("target_show_object_viewport_light_probe", "Light Probe"), ("target_show_object_viewport_volume", "Volume"), ("target_show_object_viewport_grease_pencil", "Grease Pencil"), ("target_show_object_viewport_pointcloud", "Point Cloud")))

    select_filter_box = _draw_header(layout, settings, "show_select_filter", "3D Viewport > Object Type Selectability", "NONE", use_native_panel=use_native_panel)
    if select_filter_box:
        _svo_v11_prop_grid(select_filter_box, settings, (("target_show_object_select_mesh", "Mesh"), ("target_show_object_select_camera", "Camera"), ("target_show_object_select_light", "Light"), ("target_show_object_select_empty", "Empty"), ("target_show_object_select_armature", "Armature"), ("target_show_object_select_curve", "Curve"), ("target_show_object_select_surface", "Surface"), ("target_show_object_select_font", "Text"), ("target_show_object_select_metaball", "Metaball"), ("target_show_object_select_lattice", "Lattice"), ("target_show_object_select_speaker", "Speaker"), ("target_show_object_select_light_probe", "Light Probe"), ("target_show_object_select_volume", "Volume"), ("target_show_object_select_grease_pencil", "Grease Pencil"), ("target_show_object_select_pointcloud", "Point Cloud")))

    object_box = _draw_header(layout, settings, "show_object", "Object Properties > Viewport Display", "NONE", use_native_panel=use_native_panel)
    if object_box:
        _svo_v11_draw_section_enable(object_box, settings, "include_object_display")
        _svo_v11_prop_grid(object_box, settings, (
            ("target_object_display_type", "Display As"), ("target_display_bounds_type", "Bounds Type"),
            ("target_object_show_name", "Name"), ("target_object_show_axis", "Axis"),
            ("target_object_show_texture_space", "Texture Space"), ("target_object_show_bounds", "Bounds"),
            ("target_object_show_wire", "Wire"), ("target_object_show_all_edges", "All Edges"),
            ("target_object_show_in_front", "In Front"), ("target_object_show_transparent", "Transparent"),
            ("target_object_selectable", "Selectable"), ("target_object_show_instancer_for_viewport", "Instance in Viewport"),
            ("target_object_use_simulation_cache", "Simulation Cache"),
            ("hide_unselected_objects", "Hide unselected objects"),
            ("enable_heavy_object_culling", "Cull heavy objects"), ("heavy_object_action", "Heavy object action"),
            ("heavy_vertex_threshold", "Heavy vertex threshold"), ("heavy_modifier_threshold", "Heavy modifier threshold"),
            ("heavy_particle_threshold", "Heavy particle threshold"),
        ))
        controls = object_box.box()
        controls.label(text=iface("Apply Controls"), icon="TOOL_SETTINGS")
        _svo_v11_prop_grid(controls, settings, (
            ("force_object_mode_on_apply", "Force Object Mode before apply"),
            ("clear_selection_on_apply", "Clear selection on apply"),
        ))

    modifier_box = _draw_header(layout, settings, "show_modifier", "Modifier Viewport Display", "NONE", use_native_panel=use_native_panel)
    if modifier_box:
        _svo_v11_draw_section_enable(modifier_box, settings, "include_modifiers")
        _svo_v11_prop_grid(modifier_box, settings, (("target_show_viewport_modifiers", "Show Modifiers in Viewport"), ("target_show_subdivision_modifiers", "Subdivision / Multires"), ("target_show_geometry_nodes", "Geometry Nodes"), ("target_show_simulation_modifiers", "Simulation Modifiers"), ("target_show_deformer_modifiers", "Deform Modifiers"), ("target_show_generator_modifiers", "Generate Modifiers"), ("target_show_normal_data_modifiers", "Normals / Data Modifiers"), ("target_show_other_modifiers", "Other Modifiers")))

    constraint_box = _draw_header(layout, settings, "show_constraint", "Constraints", "NONE", use_native_panel=use_native_panel)
    if constraint_box:
        _svo_v11_draw_section_enable(constraint_box, settings, "include_constraints")
        _svo_v11_prop_grid(constraint_box, settings, (("target_object_constraints_enabled", "Object Constraints"), ("target_pose_constraints_enabled", "Pose Constraints")))

    particle_box = _draw_header(layout, settings, "show_particle", "Particle Preview", "NONE", use_native_panel=use_native_panel)
    if particle_box:
        _svo_v11_draw_section_enable(particle_box, settings, "include_particles")
        _svo_v11_prop_grid(particle_box, settings, (("particle_display_percentage", "Display Percentage"), ("particle_display_step", "Display Step")))

    pref_box = _draw_header(layout, settings, "show_pref", "Preferences > System", "NONE", use_native_panel=use_native_panel)
    if pref_box:
        _svo_v11_draw_section_enable(pref_box, settings, "include_preferences")
        _svo_v11_prop_grid(pref_box, settings, (("target_gpu_backend", "Graphics Backend"), ("target_gpu_preferred_device", "Preferred GPU Device"), ("target_viewport_aa", "Viewport Anti-Aliasing"), ("target_gl_texture_limit", "Texture Limit"), ("target_texture_time_out", "Texture Time Out"), ("target_vbo_time_out", "VBO Time Out"), ("target_texture_collection_rate", "Texture Collection Rate"), ("target_vbo_collection_rate", "VBO Collection Rate"), ("target_use_gpu_subdivision", "GPU Subdivision"), ("target_use_overlay_smooth_wire", "Overlay Smooth Wires"), ("target_use_edit_mode_smooth_wire", "Edit Mode Smooth Wires"), ("target_shader_compilation_method", "Shader Compilation"), ("target_gpu_shader_workers", "GPU Shader Workers"), ("target_memory_cache_limit", "Memory Cache Limit"), ("target_use_region_overlap", "Region Overlap")))

    render_preview_box = _draw_header(layout, settings, "show_render_preview", "Render Preview / Engine", "NONE", use_native_panel=use_native_panel)
    if render_preview_box:
        _svo_v11_draw_section_enable(render_preview_box, settings, "include_render_preview_settings")
        _svo_v11_prop_grid(render_preview_box, settings, (("target_render_preview_pixel_size", "Preview Pixel Size"), ("target_render_use_high_quality_normals", "High Quality Normals"), ("target_render_use_simplify_normals", "Simplify Normals"), ("target_render_use_persistent_data", "Persistent Data"), ("target_scene_viewport_aa", "Scene Viewport AA"), ("target_scene_render_aa", "Scene Render AA"), ("target_eevee_taa_samples", "EEVEE Viewport Samples"), ("target_eevee_use_taa_reprojection", "EEVEE TAA Reprojection"), ("target_eevee_use_shadows", "EEVEE Shadows"), ("target_eevee_shadow_pool_size", "EEVEE Shadow Pool Size"), ("target_eevee_shadow_resolution_scale", "EEVEE Shadow Resolution Scale"), ("target_eevee_shadow_ray_count", "EEVEE Shadow Ray Count"), ("target_eevee_shadow_step_count", "EEVEE Shadow Step Count"), ("target_eevee_use_raytracing", "EEVEE Ray Tracing"), ("target_eevee_ray_tracing_method", "EEVEE Ray Tracing Method"), ("target_eevee_volumetric_tile_size", "EEVEE Volume Tile Size"), ("target_eevee_volumetric_samples", "EEVEE Volume Samples"), ("target_eevee_volumetric_ray_depth", "EEVEE Volume Ray Depth"), ("target_eevee_use_volumetric_shadows", "EEVEE Volume Shadows"), ("target_eevee_volumetric_shadow_samples", "EEVEE Volume Shadow Samples"), ("target_cycles_preview_samples", "Cycles Preview Samples"), ("target_cycles_use_preview_denoising", "Cycles Preview Denoising"), ("target_cycles_preview_denoising_quality", "Cycles Preview Denoising Quality"), ("target_cycles_texture_limit", "Cycles Texture Limit"), ("target_cycles_volume_preview_step_rate", "Cycles Volume Preview Step Rate"), ("target_cycles_preview_dicing_rate", "Cycles Preview Dicing Rate")))

    nav_box = _draw_header(layout, settings, "show_navigation", "Preferences > Navigation", "NONE", use_native_panel=use_native_panel)
    if nav_box:
        _svo_v11_draw_section_enable(nav_box, settings, "include_navigation_latency")
        _svo_v11_prop_grid(nav_box, settings, (("target_show_navigate_ui", "Navigation Controls"), ("target_use_reduce_motion", "Reduce Motion"), ("target_show_statusbar_stats", "Status Bar Statistics"), ("target_show_statusbar_memory", "Status Bar Memory"), ("target_show_statusbar_vram", "Status Bar VRAM"), ("target_show_statusbar_version", "Status Bar Version"), ("target_use_mouse_depth_navigate", "Auto Depth"), ("target_use_zoom_to_mouse", "Zoom to Mouse Position"), ("target_use_rotate_around_active", "Orbit Around Selection"), ("target_use_auto_perspective", "Auto Perspective"), ("target_smooth_view", "Smooth View"), ("target_view_rotate_method", "View Rotate Method"), ("target_view_zoom_method", "View Zoom Method"), ("target_view_zoom_axis", "View Zoom Axis"), ("target_ndof_show_guide_orbit_axis", "NDOF Orbit Axis Guide"), ("target_ndof_show_guide_orbit_center", "NDOF Orbit Center Guide")))

    edit_box = _draw_header(layout, settings, "show_edit_settings", "Preferences > Editing / Tool Settings", "NONE", use_native_panel=use_native_panel)
    if edit_box:
        _svo_v11_prop_grid(edit_box, settings, (("target_use_global_undo", "Global Undo"), ("target_undo_steps", "Undo Steps"), ("target_undo_memory_limit", "Undo Memory Limit"), ("target_use_auto_keying", "Auto Keying"), ("target_use_auto_keyframe_insert_needed", "Only Insert Needed"), ("target_use_keyframe_insert_auto", "Record Auto Keying"), ("target_use_snap", "Snapping"), ("target_use_mesh_automerge", "Auto Merge"), ("target_use_mesh_automerge_and_split", "Auto Merge & Split")))

    prewarm_box = _draw_header(layout, settings, "show_prewarm", "Navigation Warmup", "NONE", use_native_panel=use_native_panel)
    if prewarm_box:
        _svo_v11_draw_section_enable(prewarm_box, settings, "include_viewport_prewarm")
        _svo_v11_prop_grid(prewarm_box, settings, (("enable_navigation_guard", "Enable navigation prewarm guard"), ("prewarm_on_mouse_move", "Prewarm on mouse move"), ("prewarm_interval", "Prewarm interval"), ("prewarm_redraw_iterations", "Prewarm redraw iterations"), ("prewarm_view_matrix_nudge", "Prewarm view matrix nudge"), ("enable_idle_warm_pulse", "Enable idle warm pulse"), ("idle_warm_pulse_interval", "Idle pulse interval"), ("idle_pulse_view_layer_update", "Update view layer in idle pulse"), ("idle_pulse_redraw_iterations", "Idle pulse redraw iterations")))
        row = prewarm_box.row(align=True)
        row.operator(VIEW3D_OT_svo_plus_start_navigation_guard.bl_idname, text=iface("Start Navigation Guard"))
        row.operator(VIEW3D_OT_svo_plus_stop_navigation_guard.bl_idname, text=iface("Stop Navigation Guard"))


class VIEW3D_OT_svo_plus_sync_details_from_current_settings(bpy.types.Operator):
    """Load the current Blender settings into Detailed Settings without changing Blender's current view."""
    bl_idname = "view3d.svo_plus_sync_details_from_current_settings"
    bl_label = "Load Current View Settings"
    bl_description = "Read the current Blender viewport, overlay, object, preference, and navigation settings into Detailed Settings only. This does not apply or change Blender's current viewport settings."
    bl_options = set()

    def execute(self, context: bpy.types.Context):
        settings = getattr(getattr(context, "scene", None), "smart_viewport_optimizer_settings", None)
        if settings is None:
            return {"CANCELLED"}
        global _SVO_V12_SETTINGS_IO_GUARD
        old_guard = _SVO_V12_SETTINGS_IO_GUARD
        _SVO_V12_SETTINGS_IO_GUARD = True
        try:
            _svo_v11_sync_detail_settings_from_context(context, settings)
        finally:
            _SVO_V12_SETTINGS_IO_GUARD = old_guard
        try:
            _svo_v8_mark_preset_baseline(settings, getattr(settings, "selected_preset", ""))
        except Exception:
            pass
        try:
            active_slot = getattr(settings, "active_settings_slot", "OPTIMIZED")
            if bool(getattr(settings, "auto_save_workspace_preset_changes", False)):
                _svo_v12_write_current_settings_file(settings, active_slot, context=context)
                _svo_v12_write_settings_file(settings, _svo_v12_slot_settings_path(active_slot), active_slot, context=context)
                _svo_v13_save_workspace_slot(context, settings, active_slot)
            settings.status_text = "Current View Settings loaded into Detailed Settings without applying changes to Blender."
        except Exception:
            pass
        try:
            _tag_view3d_redraw(context)
        except Exception:
            pass
        self.report({"INFO"}, iface("Current View Settings loaded into Detailed Settings without applying changes to Blender."))
        return {"FINISHED"}

# Baseline save/load must also refresh target controls from the state that will
# be restored on OFF.
_SVO_V11_OLD_SAVE_BASELINE_EXECUTE = VIEW3D_OT_svo_plus_save_current_baseline_state.execute

def _svo_v11_save_current_baseline_execute(self, context: bpy.types.Context):
    result = _SVO_V11_OLD_SAVE_BASELINE_EXECUTE(self, context)
    if result == {"FINISHED"} or (isinstance(result, set) and "FINISHED" in result):
        try:
            _svo_v11_sync_detail_settings_from_context(context, context.scene.smart_viewport_optimizer_settings)
        except Exception:
            pass
    return result
VIEW3D_OT_svo_plus_save_current_baseline_state.execute = _svo_v11_save_current_baseline_execute
VIEW3D_OT_svo_plus_save_current_baseline_state.bl_label = "Save Current Settings as Baseline State"

_SVO_V11_OLD_LOAD_BASELINE_EXECUTE = VIEW3D_OT_svo_plus_load_baseline_state.execute

def _svo_v11_load_baseline_execute(self, context: bpy.types.Context):
    result = _SVO_V11_OLD_LOAD_BASELINE_EXECUTE(self, context)
    if result == {"FINISHED"} or (isinstance(result, set) and "FINISHED" in result):
        try:
            _svo_v11_sync_detail_settings_from_context(context, context.scene.smart_viewport_optimizer_settings)
        except Exception:
            pass
    return result
VIEW3D_OT_svo_plus_load_baseline_state.execute = _svo_v11_load_baseline_execute



_SVO_REGISTERED_CLASSES: list[type] = []


def _svo_duplicate_register_error(exc) -> bool:
    text_value = str(exc or '').lower()
    return 'already registered' in text_value or 'registered as a subclass' in text_value


def _svo_clean_panel_registration_fields(cls) -> None:
    if not isinstance(cls, type):
        return
    try:
        if not issubclass(cls, bpy.types.Panel):
            return
    except Exception:
        return
    try:
        # Blender rejects bl_category on HEADER panels. A same-session reload can
        # inherit a category injected by a previous common panel patch, so remove
        # it immediately before every register/unregister attempt.
        if str(getattr(cls, 'bl_region_type', '') or '') != 'UI' and hasattr(cls, 'bl_category'):
            try:
                delattr(cls, 'bl_category')
            except Exception:
                cls.bl_category = ''
    except Exception:
        pass


def _svo_registered_class_candidates(cls: type):
    """Return exact Blender RNA matches without global type/module scans."""
    if not isinstance(cls, type):
        return []
    out = []
    seen = set()
    for identifier in (
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
    ):
        if not identifier:
            continue
        try:
            candidate = getattr(bpy.types, identifier, None)
        except Exception:
            candidate = None
        if not isinstance(candidate, type):
            continue
        ident = id(candidate)
        if ident in seen:
            continue
        seen.add(ident)
        out.append(candidate)
    return out


def _svo_unregister_class_resilient(cls: type) -> bool:
    """Remove only an exact class recorded by the current Suite generation."""
    if not isinstance(cls, type):
        return False
    from .. import runtime_ledger as _runtime_ledger
    if not _runtime_ledger.class_recorded_current(cls):
        return False
    return bool(_runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='SVO_CLASS',
    ))

def _svo_register_class_resilient(cls: type) -> bool:
    """Register once; same-name classes are never adopted or replaced."""
    if not isinstance(cls, type):
        return False
    _svo_clean_panel_registration_fields(cls)
    from .. import runtime_ledger as _runtime_ledger
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='SVO_CLASS',
    )
    return bool(success)

def _svo_v12_unregister_stale_separate_ui() -> None:
    """Compatibility no-op; displayed RNA is never replaced during register."""
    return None

classes = (
    SVO_PLUS_PG_settings,
    VIEW3D_OT_svo_plus_apply_max_speed,
    VIEW3D_OT_svo_plus_apply_current,
    VIEW3D_OT_svo_plus_restore_snapshot,
    VIEW3D_OT_svo_plus_reset_options,
    VIEW3D_OT_svo_plus_clear_snapshot,
    VIEW3D_OT_svo_plus_toggle_optimizer,
    VIEW3D_OT_svo_plus_copy_keymap_id,
    VIEW3D_OT_svo_plus_navigation_guard,
    VIEW3D_OT_svo_plus_start_navigation_guard,
    VIEW3D_OT_svo_plus_stop_navigation_guard,
    VIEW3D_OT_svo_plus_capture_snapshot,
    SVO_MT_workspace_source_menu,
    VIEW3D_OT_svo_plus_set_workspace_source,
    VIEW3D_OT_svo_plus_paste_workspace_settings,
    VIEW3D_OT_svo_plus_set_settings_slot,
    VIEW3D_OT_svo_plus_apply_selected_preset,
    VIEW3D_OT_svo_plus_save_standard_settings,
    VIEW3D_OT_svo_plus_load_standard_settings,
    VIEW3D_OT_svo_plus_save_optimized_settings,
    VIEW3D_OT_svo_plus_load_optimized_settings,
    VIEW3D_OT_svo_plus_reset_selected_preset,
    VIEW3D_OT_svo_plus_save_selected_preset_settings,
    VIEW3D_OT_svo_plus_load_settings_as_selected_preset,
    VIEW3D_OT_svo_plus_save_current_baseline_state,
    VIEW3D_OT_svo_plus_load_baseline_state,
    VIEW3D_OT_svo_plus_save_custom_preset,
    VIEW3D_OT_svo_plus_delete_custom_preset,
    VIEW3D_OT_svo_plus_capture_external_backup,
    VIEW3D_OT_svo_plus_restore_external_backup,
    VIEW3D_OT_svo_plus_open_backup_folder,
    VIEW3D_PT_svo_plus_header_popover,
    VIEW3D_OT_svo_plus_sync_details_from_current_settings,
)


def register() -> bool:
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    bpy.app.translations.register(ADDON_ID, _TRANSLATION_DICT)

    _svo_plus_remove_header_menu_patch()
    scene_props = getattr(getattr(bpy.types.Scene, 'bl_rna', None), 'properties', None)
    getter = getattr(scene_props, 'get', None)
    for name in ('smart_viewport_optimizer_settings', 'smart_viewport_optimizer_snapshot_json'):
        if callable(getter) and getter(name) is not None:
            return False
    if bpy.types.Object.bl_rna.properties.get('smart_viewport_optimizer_object_state') is not None:
        return False

    _SVO_REGISTERED_CLASSES.clear()
    for cls in classes:
        if not _svo_register_class_resilient(cls):
            return False
        _SVO_REGISTERED_CLASSES.append(cls)

    bpy.types.Scene.smart_viewport_optimizer_settings = bpy.props.PointerProperty(type=SVO_PLUS_PG_settings)
    bpy.types.Scene.smart_viewport_optimizer_snapshot_json = bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'}
    )
    bpy.types.Object.smart_viewport_optimizer_object_state = bpy.props.StringProperty(
        default='', options={'HIDDEN'}
    )

    _svo_v12_ensure_settings_files_without_context()
    _svo_v15_sync_file_boundary_handlers(False)
    stop_continuous_runtime()
    _svo_plus_remove_header_menu_patch()

    # The Suite-level strict authority restores settings.  During package
    # registration, defer replay until every RNA owner/root exists; a later
    # explicit feature activation may restore only from the canonical snapshot.
    try:
        from .. import persistence as _suite_persistence
        from .. import storage as _suite_storage
        if not _suite_storage.registration_write_guard_active():
            _suite_persistence.restore_rna_state(getattr(bpy, 'context', None))
    except Exception:
        pass
    return True

def unregister() -> bool:
    try:
        _svo_v15_sync_file_boundary_handlers(False)
        stop_continuous_runtime(flush_pending=True)
        _svo_plus_remove_header_menu_patch()
    except Exception:
        return False

    for handler_list, handler in (
        (bpy.app.handlers.load_pre, _svo_plus_load_pre),
        (bpy.app.handlers.load_post, _svo_plus_load_post),
        (bpy.app.handlers.save_pre, _svo_plus_save_pre),
        (bpy.app.handlers.save_post, _svo_plus_save_post),
    ):
        try:
            while handler in handler_list:
                handler_list.remove(handler)
        except Exception:
            return False
    try:
        if hasattr(bpy.app.handlers, 'exit_pre'):
            while _svo_plus_exit_pre in bpy.app.handlers.exit_pre:
                bpy.app.handlers.exit_pre.remove(_svo_plus_exit_pre)
    except Exception:
        return False

    from .. import runtime_ledger as _runtime_ledger
    if _runtime_ledger.property_recorded_current(bpy.types.Object, 'smart_viewport_optimizer_object_state'):
        del bpy.types.Object.smart_viewport_optimizer_object_state
    for name in ('smart_viewport_optimizer_snapshot_json', 'smart_viewport_optimizer_settings'):
        if _runtime_ledger.property_recorded_current(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)

    for cls in reversed(tuple(_SVO_REGISTERED_CLASSES)):
        if not _svo_unregister_class_resilient(cls):
            return False
    _SVO_REGISTERED_CLASSES.clear()
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    return True

if __name__ == "__main__":
    register()
