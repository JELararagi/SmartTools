# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Lazy-loaded help content. Imported only when the help popup is opened."""

HELP_GROUPS = {'overview': {'title_en': 'Smart Workspace Help',
              'title_ja': 'スマートワークスペース ヘルプ',
              'icon': 'HELP',
              'overview_en': ['Smart Workspace is a Blender 5.1 Extension. It keeps runtime controls in the N-panel, '
                              'stores mutable data under CONFIG/Smart_Workspace_Suite, and avoids Add-on Preferences '
                              'as a user-facing settings surface.'],
              'overview_ja': ['スマートワークスペース は Blender 5.1 Extensionです。操作UIはNパネルへ集約し、生成データと保存設定は '
                              'CONFIG/Smart_Workspace_Suite 配下で管理します。'],
              'usage_en': ['Open the Sidebar with N, select this tool tab, choose the target object or data, adjust '
                           'only the visible controls you need, then run the relevant command button.',
                           'Use the question-mark help icon in each group header when you need detailed explanations.'],
              'usage_ja': ['Nキーでサイドバーを開き、このツールのタブを選びます。対象オブジェクトまたはデータを選択し、必要な表示項目だけを調整してから該当ボタンを実行します。',
                           '各グループヘッダーの「？」ヘルプを押すと詳細を確認できます。'],
              'settings': [],
              'operators': [],
              'errors': []}}


def get_group(topic: str | None = None) -> dict:
    key = str(topic or 'overview')
    return HELP_GROUPS.get(key) or HELP_GROUPS.get('overview') or {}


def all_topics() -> list[str]:
    return sorted(HELP_GROUPS.keys())
