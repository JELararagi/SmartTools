# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Bilingual help for the sidebar entry point."""

HELP_GROUPS = {
    "overview": {
        "title_en": "Smart Workspace Help",
        "title_ja": "スマートワークスペース ヘルプ",
        "icon": "HELP",
        "overview_en": [
            "Smart Workspace keeps its controls in Blender's sidebar. Settings and generated data go in CONFIG/Smart_Workspace_Suite."
        ],
        "overview_ja": [
            "操作は Blender のサイドバーから行います。設定と生成データは CONFIG/Smart_Workspace_Suite に保存されます。"
        ],
        "usage_en": [
            "Press N in the editor, select the Smart Workspace tab and open the group you want to use.",
            "Select the relevant workspace or editor data and use the controls in that group. Click ? for details."
        ],
        "usage_ja": [
            "エディターで N を押し、スマートワークスペースのタブから使いたい欄を開きます。",
            "対象を選んで欄の操作を使います。詳しい手順は「？」から確認できます。"
        ],
        "settings": [],
        "operators": [],
        "errors": [],
    }
}


def get_group(topic=None):
    return HELP_GROUPS.get(str(topic or "overview")) or HELP_GROUPS.get("overview") or {}


def all_topics():
    return sorted(HELP_GROUPS)
