# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Compatibility facade for exact generation-owned runtime cleanup.

All real resources are recorded in ``runtime_ledger`` with object identity,
generation, handle, and the native remover captured at registration time.  The
historical cleanup entry point remains callable but never scans modules,
handler lists, timers, RNA, or other add-ons.
"""

from __future__ import annotations


def cleanup_stale_runtime(package_prefix: str) -> dict[str, int]:
    """Collect only finite handles carrying captured native removers.

    Module/name scans are not ownership proof.  Displayed RNA, handler lists,
    timers and msgbus owners are never searched or modified here.
    """
    del package_prefix
    result = {"timers": 0, "handlers": 0, "msgbus": 0, "leases": 0}
    try:
        from . import runtime_ledger
        result["leases"] = int(runtime_ledger.collect_stale_leases())
    except Exception:
        pass
    return result

