# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Hand cleanup back to the generation that owns the exact native handles."""


def cleanup_stale_runtime(package_prefix):
    totals = dict.fromkeys(("timers", "handlers", "msgbus", "leases"), 0)
    try:
        from .runtime_ledger import collect_stale_leases
        totals["leases"] = int(collect_stale_leases())
    except Exception:
        # A legacy compatibility call must not interrupt normal registration.
        pass
    return totals
