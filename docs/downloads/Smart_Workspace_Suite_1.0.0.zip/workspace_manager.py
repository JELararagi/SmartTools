
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Workspace Manager

Save-state overwrite and exact layout restore manager for Blender 5.1+.

This add-on stores workspace-related state as JSON save states and applies only
Blender 5.1-safe values to the currently open workspace. It intentionally does
not add, delete, append, replace, or remap WorkSpace or Screen data-blocks, and
it does not reconstruct WorkSpace tools. It can rebuild active screen splits from saved geometry when loading layout save states.
"""

from __future__ import annotations

bl_info = {
    "name": "Workspace Manager",
    "author": "JELararagi",
    "version": (3, 3, 9),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Workspace Manager",
    "description": "Save, list, and restore workspace save states and screen layouts without adding workspaces.",
    "category": "Interface",
    "license": "GPL-3.0-or-later",
}

import datetime as _datetime
import json
import math
import os
import re
import sys
import tomllib
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, Set

import bpy
from . import storage as _suite_storage
from . import runtime_ledger as _runtime_ledger
from .translation import error_text
from bpy.props import BoolProperty, CollectionProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup, UIList

ADDON_ID = "workspace_manager"
ADDON_NAME = "Workspace Manager"
with Path(__file__).with_name("blender_manifest.toml").open("rb") as _manifest:
    ADDON_VERSION = tomllib.load(_manifest)["version"]
STATE_SCHEMA = "workspace_manager.save_state.v3"
BACKUP_SCHEMA = "workspace_manager.backup_state.v3"
NONE_ID = ""
_LIST_REFRESHED_ONCE = False

# RNA properties that are known to be safe enough to restore in Blender 5.1
# runtime tests. Wider RNA data is saved for diagnostics, but not blindly written
# back because workspace/tool/screen UI state can crash native Blender code.
SAFE_AREA_ENUM_PROPS = {"type", "ui_type"}
SAFE_SPACE_ENUM_PROPS = {"mode", "display_mode", "view_type", "tree_type"}
RNA_SCALAR_TYPES = {"BOOLEAN", "INT", "FLOAT", "STRING", "ENUM"}
RNA_SKIP_NAMES = {
    "rna_type",
    "bl_rna",
}

RNA_WARNING_PRONE_SPACE_PROPS: Set[Tuple[str, str]] = {
    ("DOPESHEET_EDITOR", "ui_mode"),
    ("NODE_EDITOR", "texture_type"),
    ("IMAGE_EDITOR", "ui_mode"),
}

# Properties that are captured for diagnostics but never restored directly.
# These values either describe read-only identity data, Blender-internal UI
# references, or properties that were involved in Blender 5.1 native crashes in
# earlier test builds.
RESTORE_DENY_PROPS: Set[str] = {
    "rna_type", "bl_rna", "name", "name_full", "id_data", "session_uid",
    "users", "use_fake_user", "is_embedded_data", "is_evaluated", "is_runtime_data",
    "type", "region_3d", "region_quadviews", "space", "spaces", "regions",
    "show_region_header", "show_region_toolbar", "show_region_ui",
    "show_region_tool_header", "show_region_hud",
}

# Wider but still conservative restore allow-lists. The add-on saves broad scalar
# RNA data, but loading only writes properties that can be validated and have
# passed Blender 5.1 runtime tests without increasing WorkSpace or Screen counts.
RESTORE_TOP_PROPS: Dict[str, Set[str]] = {
    "DOPESHEET_EDITOR": {"show_seconds", "show_frame_indicator", "show_sliders"},
    "TIMELINE": {"show_seconds", "show_frame_indicator"},
    "GRAPH_EDITOR": {"mode", "show_seconds", "show_handles"},
    "NLA_EDITOR": {"show_seconds"},
    "VIEW_3D": {"show_gizmo", "show_gizmo_context", "show_gizmo_navigate", "clip_start", "clip_end", "lens", "lock_camera"},
    "OUTLINER": {"display_mode", "filter_text", "use_filter_case_sensitive", "use_filter_complete", "use_filter_object"},
    "PROPERTIES": {"context"},
    "NODE_EDITOR": {"tree_type", "shader_type", "texture_type"},
    "IMAGE_EDITOR": {"mode", "ui_mode", "show_render", "show_paint", "show_uvedit"},
    "SEQUENCE_EDITOR": {"view_type", "display_mode", "show_seconds"},
    "TEXT_EDITOR": {"show_line_numbers", "show_word_wrap", "show_syntax_highlight"},
    "FILE_BROWSER": {"display_type", "sort_method", "show_details_size", "show_details_datetime"},
    "CONSOLE": {"font_size"},
}

RESTORE_NESTED_PROPS: Dict[str, Dict[str, Set[str]]] = {
    "VIEW_3D": {
        "shading": {"type", "color_type", "background_type", "show_xray", "show_shadows", "show_cavity", "show_object_outline"},
        "overlay": {"show_overlays", "show_floor", "show_axis_x", "show_axis_y", "show_axis_z", "show_outline_selected", "show_relationship_lines", "show_stats", "show_text"},
    },
    "DOPESHEET_EDITOR": {"dopesheet": {"show_only_selected", "show_hidden", "show_summary"}},
    "GRAPH_EDITOR": {"dopesheet": {"show_only_selected", "show_hidden", "show_summary"}},
}

NESTED_CAPTURE_NAMES = ("shading", "overlay", "dopesheet", "params", "region_3d")


def _language_is_japanese() -> bool:
    try:
        prefs = bpy.context.preferences
        if not prefs.view.use_translate_interface:
            return False
        language = prefs.view.language or ""
    except Exception:
        language = ""
    try:
        locale = getattr(bpy.app.translations, "locale", "") or ""
    except Exception:
        locale = ""
    return (language or locale).lower().startswith("ja")


def _t(ja: str, en: str) -> str:
    return ja if _language_is_japanese() else en


def _timestamp() -> str:
    return _datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]


def _safe_name(value: str, fallback: str = "Workspace_State") -> str:
    value = (value or "").strip() or fallback
    value = re.sub(r"[^0-9A-Za-zぁ-んァ-ン一-龥_-]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return (value or fallback)[:96]


def _config_root() -> Path:
    try:
        path = _suite_storage.central_settings_dir(create=True) / "workspace_manager"
    except Exception:
        try:
            base = bpy.utils.user_resource("CONFIG", path="Smart_WorkSpace_Suite", create=True)
            path = Path(base) / "workspace_manager"
        except Exception:
            path = Path(os.path.expanduser("~")) / ".config" / "blender" / "Smart_WorkSpace_Suite" / "workspace_manager"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _data_dir(name: str) -> Path:
    path = _config_root() / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def _states_dir() -> Path:
    return _data_dir("save_states")


def _state_order_path() -> Path:
    return _config_root() / "save_state_order.json"


def _state_name_key(name: str) -> str:
    return _safe_name(name or "", "Workspace_State").casefold()


def _read_state_order() -> List[str]:
    data = _read_json(_state_order_path(), {"order": []})
    order = data.get("order") if isinstance(data, dict) else []
    return [str(item) for item in order if item]


def _write_state_order(order: List[str]) -> None:
    seen = set()
    clean = []
    for item in order:
        item = str(item)
        if not item or item in seen:
            continue
        seen.add(item)
        clean.append(item)
    _write_json(_state_order_path(), {"schema": STATE_SCHEMA + ".order", "updated_at": _timestamp(), "order": clean})


def _state_display_name(data: Dict[str, Any]) -> str:
    return (data.get("state_workspace_name") or data.get("display_name") or data.get("source_workspace_name") or "").strip()


def _all_state_paths_unordered() -> List[Path]:
    return [path for path in _states_dir().glob("*.json") if path.name != _state_order_path().name]


def _ordered_state_paths() -> List[Path]:
    available = {path.stem: path for path in _all_state_paths_unordered()}
    order = _read_state_order()
    ordered: List[Path] = []
    used = set()
    for stem in order:
        path = available.get(stem)
        if path and path.exists():
            ordered.append(path)
            used.add(stem)
    remaining = [path for stem, path in available.items() if stem not in used]
    remaining.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    ordered.extend(remaining)
    stems = [p.stem for p in ordered]
    if stems != order:
        _write_state_order(stems)
    return ordered


def _find_state_path_by_name(name: str, *, exclude: Optional[Path] = None) -> Optional[Path]:
    key = _state_name_key(name)
    if not key:
        return None
    for path in _ordered_state_paths():
        if exclude is not None and path.resolve() == exclude.resolve():
            continue
        data = _valid_state_file(path)
        if not data:
            continue
        if _state_name_key(_state_display_name(data)) == key:
            return path
    return None


def _unique_state_path(name: str, *, current: Optional[Path] = None) -> Path:
    base = _safe_name(name, "Workspace_State")
    path = _states_dir() / f"{base}.json"
    if current is not None and path.resolve() == current.resolve():
        return path
    if not path.exists():
        return path
    counter = 2
    while True:
        candidate = _states_dir() / f"{base}_{counter}.json"
        if current is not None and candidate.resolve() == current.resolve():
            return candidate
        if not candidate.exists():
            return candidate
        counter += 1


def _remove_duplicate_state_names(keep_path: Path, name: str) -> int:
    key = _state_name_key(name)
    removed = 0
    for path in list(_ordered_state_paths()):
        if path.resolve() == keep_path.resolve():
            continue
        data = _valid_state_file(path)
        if data and _state_name_key(_state_display_name(data)) == key:
            try:
                path.unlink()
                removed += 1
            except Exception:
                pass
    if removed:
        _write_state_order([p.stem for p in _ordered_state_paths() if p.exists()])
    return removed


def _backups_dir() -> Path:
    return _data_dir("backups")


def _diagnostics_dir() -> Path:
    return _data_dir("diagnostics")


def _read_json(path: Path, default: Any) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        try:
            return _suite_storage.central_read_json_for_path(path, default)
        except Exception:
            return default


def _write_json(path: Path, data: Dict) -> None:
    _suite_storage.atomic_write_json(
        path,
        data,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        mirror=True,
        backup=False,
    )


def _window(context):
    return getattr(context, "window", None)


def _workspace(context):
    win = _window(context)
    if win is not None and getattr(win, "workspace", None) is not None:
        return win.workspace
    return getattr(context, "workspace", None)


def _current_screen(context):
    win = _window(context)
    if win is not None and getattr(win, "screen", None) is not None:
        return win.screen
    screen = getattr(context, "screen", None)
    if screen is not None:
        return screen
    screens = list(getattr(bpy.data, "screens", []) or [])
    return screens[0] if screens else None


def _workspace_name(context) -> str:
    ws = _workspace(context)
    return getattr(ws, "name", "") or ""


def _workspace_index(workspace) -> int:
    try:
        workspaces = list(bpy.data.workspaces)
        return workspaces.index(workspace)
    except Exception:
        return -1


def _screen_for_workspace(context, workspace):
    current_ws = _workspace(context)
    current_screen = _current_screen(context)
    if workspace is not None and current_ws is not None and workspace == current_ws and current_screen is not None:
        return current_screen
    try:
        screens = list(getattr(workspace, "screens", []) or [])
        if screens:
            return screens[0]
    except Exception:
        pass
    try:
        name = getattr(workspace, "name", "") or ""
        if name and name in bpy.data.screens:
            return bpy.data.screens[name]
    except Exception:
        pass
    return current_screen


def _enum_ids(obj, prop_name: str) -> List[str]:
    try:
        prop = obj.bl_rna.properties.get(prop_name)
        if prop is None:
            return []
        return [item.identifier for item in prop.enum_items]
    except Exception:
        return []


def _safe_set_enum(obj, prop_name: str, value: str) -> bool:
    if not obj or not prop_name or not isinstance(value, str):
        return False
    ids = _enum_ids(obj, prop_name)
    if ids and value not in ids:
        return False
    try:
        setattr(obj, prop_name, value)
        return True
    except Exception:
        return False


def _json_scalar(value: Any, *, limit_string: int = 2048) -> Tuple[bool, Any]:
    if value is None:
        return True, None
    if isinstance(value, float) and not math.isfinite(value):
        # RNA includes valid unbounded values. Preserve them without emitting
        # non-standard JSON Infinity/NaN tokens into the strict state store.
        return True, {"__workspace_float__": repr(value)}
    if isinstance(value, (bool, int, float, str)):
        if isinstance(value, str) and len(value) > limit_string:
            return True, value[:limit_string]
        return True, value
    if isinstance(value, (list, tuple)) and len(value) <= 32:
        out = []
        for item in value:
            ok, scalar = _json_scalar(item, limit_string=limit_string)
            if not ok:
                return False, None
            out.append(scalar)
        return True, out
    # Blender vectors and arrays are iterable but not list/tuple.
    if hasattr(value, "__iter__") and not isinstance(value, (dict, bytes, bytearray)):
        try:
            seq = list(value)
        except Exception:
            seq = None
        if seq is not None and len(seq) <= 32:
            out = []
            for item in seq:
                ok, scalar = _json_scalar(item, limit_string=limit_string)
                if not ok:
                    return False, None
                out.append(scalar)
            return True, out
    return False, None


def _rna_scalar_state(obj, *, max_props: int = 256) -> Dict[str, Dict[str, Any]]:
    result: Dict[str, Dict[str, Any]] = {}
    if obj is None or not hasattr(obj, "bl_rna"):
        return result
    try:
        properties = list(obj.bl_rna.properties)
    except Exception:
        return result
    for prop in properties:
        if len(result) >= max_props:
            break
        try:
            identifier = prop.identifier
            prop_type = prop.type
        except Exception:
            continue
        if identifier in RNA_SKIP_NAMES or prop_type not in RNA_SCALAR_TYPES:
            continue
        try:
            obj_type = getattr(obj, "type", "") or ""
        except Exception:
            obj_type = ""
        if (str(obj_type), str(identifier)) in RNA_WARNING_PRONE_SPACE_PROPS:
            continue
        try:
            value = getattr(obj, identifier)
        except Exception:
            continue
        ok, scalar = _json_scalar(value)
        if not ok:
            continue
        item = {
            "type": prop_type,
            "value": scalar,
            "readonly": bool(getattr(prop, "is_readonly", False)),
            "hidden": bool(getattr(prop, "is_hidden", False)),
        }
        if prop_type == "ENUM":
            ids = _enum_ids(obj, identifier)
            item["enum_ids"] = ids
            if isinstance(scalar, str) and ids and scalar not in ids:
                item["invalid_enum"] = True
        result[identifier] = item
    return result


KNOWN_SPACE_ENUM_REPAIR_PROPS = {
    "DOPESHEET_EDITOR": (),
    "NODE_EDITOR": ("texture_type", "tree_type"),
    "IMAGE_EDITOR": ("ui_mode",),
}


def _preferred_enum_value(space, prop_name: str, ids: List[str]) -> Optional[str]:
    if not ids:
        return None
    preferred_by_prop = {
        "ui_mode": ("DOPESHEET", "VIEW", "UV", "ACTION", "TIMELINE", "GREASE_PENCIL", "GPENCIL", "MASK", "PAINT"),
        "texture_type": ("OBJECT", "WORLD", "BRUSH", "LINESTYLE"),
        "tree_type": ("ShaderNodeTree", "CompositorNodeTree", "GeometryNodeTree", "TextureNodeTree"),
    }
    for candidate in preferred_by_prop.get(prop_name, ()): 
        if candidate in ids:
            return candidate
    return ids[0]


def _repair_dopesheet_screen(screen) -> Tuple[int, List[str]]:
    # Historical name kept for compatibility with older internal calls.
    # It now repairs known invalid enum values for several editor spaces because
    # Blender 5.1 logs can contain invalid Dope Sheet, Node Editor, and Image
    # Editor enum values from old UI data.
    fixed = 0
    notes: List[str] = []
    if screen is None:
        return fixed, notes
    for area_index, area in enumerate(list(getattr(screen, "areas", []) or [])):
        for space_index, space in enumerate(list(getattr(area, "spaces", []) or [])):
            space_type = getattr(space, "type", None)
            for prop_name in KNOWN_SPACE_ENUM_REPAIR_PROPS.get(space_type, ()): 
                # These two enums cannot express the editor's real state in these
                # cases: reading one logs a warning, and writing it to a UV Editor
                # would turn that editor into an Image Editor.
                if prop_name == "ui_mode" and getattr(space, "mode", "") == "UV":
                    continue
                if prop_name == "texture_type" and getattr(space, "tree_type", "") != "TextureNodeTree":
                    continue
                ids = _enum_ids(space, prop_name)
                safe = _preferred_enum_value(space, prop_name, ids)
                if not ids or not safe:
                    continue
                should_fix = False
                try:
                    current = getattr(space, prop_name)
                    if current not in ids:
                        should_fix = True
                except Exception:
                    should_fix = True
                if should_fix:
                    try:
                        setattr(space, prop_name, safe)
                        fixed += 1
                        notes.append(f"{getattr(screen, 'name', '')}: area {area_index}, space {space_index}, {prop_name} -> {safe}")
                    except Exception as exc:
                        notes.append(f"{getattr(screen, 'name', '')}: area {area_index}, space {space_index}, {prop_name} failed: {exc}")
    return fixed, notes


def _repair_all_dopesheets() -> Tuple[int, List[str]]:
    total = 0
    notes: List[str] = []
    for screen in list(getattr(bpy.data, "screens", []) or []):
        fixed, subnotes = _repair_dopesheet_screen(screen)
        total += fixed
        notes.extend(subnotes)
    return total, notes


def _region_state(region, index: int) -> Dict[str, Any]:
    return {
        "index": index,
        "type": getattr(region, "type", "") or "",
        "alignment": getattr(region, "alignment", "") or "",
        "width": int(getattr(region, "width", 0) or 0),
        "height": int(getattr(region, "height", 0) or 0),
    }


def _space_state(space, index: int, active: bool) -> Dict[str, Any]:
    nested: Dict[str, Any] = {}
    for nested_name in NESTED_CAPTURE_NAMES:
        try:
            nested_obj = getattr(space, nested_name)
        except Exception:
            continue
        if nested_obj is None:
            continue
        nested[nested_name] = {"rna": _rna_scalar_state(nested_obj, max_props=220)}
    return {
        "index": index,
        "active": bool(active),
        "type": getattr(space, "type", "") or "",
        "rna": _rna_scalar_state(space, max_props=420),
        "nested": nested,
    }


def _area_state(area, index: int) -> Dict[str, Any]:
    spaces = list(getattr(area, "spaces", []) or [])
    active_space = getattr(getattr(area, "spaces", None), "active", None)
    active_index = -1
    for i, space in enumerate(spaces):
        if space == active_space:
            active_index = i
            break
    return {
        "index": index,
        "type": getattr(area, "type", "") or "",
        "ui_type": getattr(area, "ui_type", "") or "",
        "x": int(getattr(area, "x", 0) or 0),
        "y": int(getattr(area, "y", 0) or 0),
        "width": int(getattr(area, "width", 0) or 0),
        "height": int(getattr(area, "height", 0) or 0),
        "active_space_index": active_index,
        "rna": _rna_scalar_state(area, max_props=128),
        "regions": [_region_state(region, i) for i, region in enumerate(list(getattr(area, "regions", []) or []))],
        "spaces": [_space_state(space, i, space == active_space) for i, space in enumerate(spaces)],
    }


def _window_state(context, window, screen, workspace) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "workspace_name": getattr(workspace, "name", "") if workspace else "",
        "screen_name": getattr(screen, "name", "") if screen else "",
        "screen_area_count": len(list(getattr(screen, "areas", []) or [])) if screen else 0,
    }
    try:
        scene = getattr(window, "scene", None) if window is not None else getattr(context, "scene", None)
        data["active_scene_name"] = getattr(scene, "name", "") if scene else ""
    except Exception:
        pass
    if window is not None:
        for name in ("width", "height", "x", "y"):
            try:
                value = getattr(window, name)
            except Exception:
                continue
            ok, scalar = _json_scalar(value)
            if ok:
                data[name] = scalar
    return data


def _capture_workspace_state(
    context,
    *,
    workspace=None,
    screen=None,
    display_name: Optional[str] = None,
    scope: str = "CURRENT",
    custom_workspace_name: Optional[str] = None,
) -> Dict[str, Any]:
    workspace = workspace or _workspace(context)
    screen = screen or _screen_for_workspace(context, workspace)
    if screen is None:
        raise RuntimeError(_t("保存対象のスクリーンを取得できません。", "The target screen for saving is not available."))
    settings = _settings(context)
    repair_notes: List[str] = []
    repair_count = 0
    if settings.auto_repair_dopesheet:
        repair_count, repair_notes = _repair_dopesheet_screen(screen)
    raw_areas = list(getattr(screen, "areas", []) or [])
    invalid_area_count = len([area for area in raw_areas if int(getattr(area, "width", 0) or 0) <= 0 or int(getattr(area, "height", 0) or 0) <= 0])
    areas = [area for area in raw_areas if int(getattr(area, "width", 0) or 0) > 0 and int(getattr(area, "height", 0) or 0) > 0]
    if not areas:
        raise RuntimeError(_t("保存対象のスクリーンに有効なエリアがありません。レイアウト変更直後の場合は一度画面更新後に保存してください。", "The target screen has no valid areas. If the layout was just changed, save after the UI refreshes once."))
    source_workspace_name = getattr(workspace, "name", "") if workspace else _workspace_name(context)
    state_workspace_name = custom_workspace_name or source_workspace_name
    display = display_name or state_workspace_name or source_workspace_name or "Workspace State"
    state_id = f"{_safe_name(display)}_{_timestamp()}"
    data = {
        "schema": STATE_SCHEMA,
        "id": state_id,
        "addon_name": ADDON_NAME,
        "addon_version": ADDON_VERSION,
        "created_at": _timestamp(),
        "display_name": display,
        "scope": scope,
        "blender_version": ".".join(map(str, bpy.app.version)),
        "platform": sys.platform,
        "source_workspace_name": source_workspace_name,
        "state_workspace_name": state_workspace_name,
        "summary": {
            "workspace_name": state_workspace_name,
            "source_workspace_name": source_workspace_name,
            "screen_name": getattr(screen, "name", "") or "",
            "area_count": len(areas),
            "ignored_zero_size_area_count": invalid_area_count,
            "area_types": [getattr(area, "type", "") or "" for area in areas],
        },
        "categories": {
            "workspace_name": {
                "workspace_name": state_workspace_name,
                "source_workspace_name": source_workspace_name,
                "workspace_index": _workspace_index(workspace),
                "workspace_rna": _rna_scalar_state(workspace, max_props=128),
            },
            "window_display": {
                "window": _window_state(context, _window(context), screen, workspace),
                "screen_name": getattr(screen, "name", "") or "",
                "screen_rna": _rna_scalar_state(screen, max_props=128),
            },
            "layout": {
                "screen_name": getattr(screen, "name", "") or "",
                "area_count": len(areas),
                "areas": [_area_state(area, i) for i, area in enumerate(areas)],
            },
            "settings": {
                "areas": [_area_state(area, i) for i, area in enumerate(areas)],
                "note": "Scalar RNA values are saved. Loading writes back only a conservative allow-list that is safe for Blender 5.1.",
            },
        },
        "repair": {
            "dopesheet_fixed": repair_count,
            "dopesheet_notes": repair_notes,
        },
        "restore_limits": {
            "workspace_data_block_added": False,
            "screen_split_count_changed": False,
            "tool_slots_restored": False,
            "unsafe_region_visibility_write": False,
            "ignored_zero_size_area_count": invalid_area_count,
        },
    }
    return data


def _state_files() -> List[Path]:
    return _ordered_state_paths()


def _valid_state_file(path: Path) -> Optional[Dict[str, Any]]:
    data = _read_json(path, {})
    if data.get("schema") != STATE_SCHEMA:
        return None
    return data


def _load_state(path: Path) -> Dict[str, Any]:
    data = _valid_state_file(path)
    if data is None:
        raise RuntimeError(_t("選択したファイルは Workspace Manager のセーブステートではありません。", "The selected file is not a Workspace Manager save state."))
    return data


def _settings(context):
    wm = getattr(context, "window_manager", None) if context is not None else None
    if wm is None:
        try:
            wm = bpy.context.window_manager
        except Exception:
            wm = None
    if wm is not None:
        try:
            return wm.workspace_manager_settings
        except Exception:
            pass
    raise AttributeError("WindowManager.workspace_manager_settings is not available")


def _selected_state_item(context):
    settings = _settings(context)
    idx = settings.save_states_index
    if 0 <= idx < len(settings.save_states):
        return settings.save_states[idx]
    return None


def _selected_state_path(context) -> Optional[Path]:
    item = _selected_state_item(context)
    if item is None or not item.filepath:
        return None
    path = Path(item.filepath)
    return path if path.exists() else None


def _refresh_state_items(context) -> int:
    settings = _settings(context)
    try:
        previous_numeric_index = int(settings.save_states_index)
    except Exception:
        previous_numeric_index = -1
    old_identifier = ""
    old_item = _selected_state_item(context)
    if old_item is not None:
        old_identifier = old_item.identifier
    settings.save_states.clear()
    selected_index = -1
    paths = _ordered_state_paths()
    for path in paths:
        data = _valid_state_file(path)
        if not data:
            continue
        item = settings.save_states.add()
        item.identifier = path.stem
        item.display_name = data.get("display_name") or data.get("state_workspace_name") or path.stem
        item.workspace_name = data.get("state_workspace_name") or data.get("source_workspace_name") or ""
        item.source_workspace_name = data.get("source_workspace_name") or ""
        item.scope = data.get("scope") or ""
        item.created_at = data.get("created_at") or ""
        item.updated_at = data.get("updated_at") or data.get("created_at") or ""
        item.area_count = int((data.get("summary") or {}).get("area_count") or 0)
        item.filepath = str(path)
        if item.identifier == old_identifier:
            selected_index = len(settings.save_states) - 1
    if selected_index < 0:
        if len(settings.save_states) > 0:
            selected_index = 0
        else:
            # An empty list has no item identity to remap.  Preserve the saved
            # numeric N-panel value instead of resetting it during a harmless
            # registration/refresh pass; explicit delete operations still set
            # their desired index before invoking this refresh.
            selected_index = previous_numeric_index
    settings.save_states_index = selected_index
    return len(settings.save_states)


def _write_state_file(context, state: Dict[str, Any]) -> Path:
    name = _state_display_name(state) or state.get("display_name") or "Workspace State"
    existing_path = _find_state_path_by_name(name)
    existing_data = _valid_state_file(existing_path) if existing_path else None
    path = existing_path or _unique_state_path(name)
    if existing_data:
        state["id"] = existing_data.get("id") or path.stem
        state["created_at"] = existing_data.get("created_at") or state.get("created_at") or _timestamp()
        state["overwritten_at"] = _timestamp()
    else:
        state["id"] = path.stem
        state.setdefault("created_at", _timestamp())
    state["updated_at"] = _timestamp()
    # Keep the visible name and all workspace-name fields synchronized.
    display = name
    state["display_name"] = display
    state["state_workspace_name"] = display
    try:
        state.setdefault("summary", {})["workspace_name"] = display
        state.setdefault("categories", {}).setdefault("workspace_name", {})["workspace_name"] = display
    except Exception:
        pass
    _write_json(path, state)
    order = _read_state_order()
    if path.stem not in order:
        order.insert(0, path.stem)
    _write_state_order(order)
    _remove_duplicate_state_names(path, display)
    _refresh_state_items(context)
    try:
        for index, item in enumerate(_settings(context).save_states):
            if item.identifier == path.stem:
                _settings(context).save_states_index = index
                break
    except Exception:
        pass
    return path


def _rename_state_file(context, path: Path, new_name: str) -> Path:
    new_name = _safe_name(new_name, "Workspace_State")
    if not new_name:
        raise RuntimeError(_t("新しい名前が空です。", "The new name is empty."))
    duplicate = _find_state_path_by_name(new_name, exclude=path)
    if duplicate is not None:
        raise RuntimeError(_t("同じ名前のセーブステートが既にあります。", "A save state with the same name already exists."))
    data = _load_state(path)
    new_path = _unique_state_path(new_name, current=path)
    data["display_name"] = new_name
    data["state_workspace_name"] = new_name
    data["renamed_at"] = _timestamp()
    data["updated_at"] = _timestamp()
    data["id"] = new_path.stem
    data.setdefault("summary", {})["workspace_name"] = new_name
    data.setdefault("categories", {}).setdefault("workspace_name", {})["workspace_name"] = new_name
    _write_json(new_path, data)
    if new_path.resolve() != path.resolve():
        try:
            path.unlink()
        except Exception:
            pass
    order = _read_state_order()
    order = [new_path.stem if item == path.stem else item for item in order]
    if new_path.stem not in order:
        order.insert(0, new_path.stem)
    _write_state_order(order)
    _refresh_state_items(context)
    for index, item in enumerate(_settings(context).save_states):
        if item.identifier == new_path.stem:
            _settings(context).save_states_index = index
            break
    return new_path


def _move_selected_state(context, delta: int) -> bool:
    settings = _settings(context)
    idx = settings.save_states_index
    if not (0 <= idx < len(settings.save_states)):
        return False
    new_idx = max(0, min(len(settings.save_states) - 1, idx + delta))
    if new_idx == idx:
        return False
    order = [item.identifier for item in settings.save_states]
    item = order.pop(idx)
    order.insert(new_idx, item)
    _write_state_order(order)
    _refresh_state_items(context)
    settings.save_states_index = new_idx
    return True


def _cleanup_backups(max_items: int = 40) -> None:
    files = sorted(_backups_dir().glob("backup_*.json"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    for path in files[max_items:]:
        try:
            path.unlink()
        except Exception:
            pass


def _backup_current(context, reason: str) -> Optional[Path]:
    if not _settings(context).auto_backup:
        return None
    data = _capture_workspace_state(context, display_name=f"backup_{reason}", scope="BACKUP")
    data["schema"] = BACKUP_SCHEMA
    path = _backups_dir() / f"backup_{reason}_{_timestamp()}.json"
    _write_json(path, data)
    _cleanup_backups(40)
    return path


def _set_workspace_metadata(context, state: Dict[str, Any], notes: List[str]) -> int:
    ws = _workspace(context)
    if ws is None:
        notes.append("metadata skipped: no current workspace")
        return 0
    metadata = {
        "save_state_name": state.get("display_name") or "",
        "source_workspace_name": state.get("source_workspace_name") or "",
        "state_workspace_name": state.get("state_workspace_name") or "",
        "blender_version": state.get("blender_version") or "",
        "created_at": state.get("created_at") or "",
        "updated_at": state.get("updated_at") or "",
        "loaded_at": _timestamp(),
        "saved_workspace_index": (((state.get("categories") or {}).get("workspace_name") or {}).get("workspace_index")),
        "saved_screen_name": (((state.get("categories") or {}).get("window_display") or {}).get("screen_name")),
    }
    applied = 0
    for key, value in metadata.items():
        try:
            ws[f"workspace_manager_{key}"] = "" if value is None else str(value)
            applied += 1
        except Exception as exc:
            notes.append(f"metadata {key} failed: {exc}")
    return applied


def _apply_workspace_name(context, state: Dict[str, Any], notes: List[str]) -> int:
    ws = _workspace(context)
    if ws is None:
        notes.append("workspace name skipped: no current workspace")
        return 0
    name = ((state.get("categories") or {}).get("workspace_name") or {}).get("workspace_name") or state.get("state_workspace_name") or ""
    applied = _set_workspace_metadata(context, state, notes)
    if not name:
        notes.append("workspace name skipped: no saved name")
        return applied
    try:
        ws.name = name
        notes.append(f"workspace name -> {ws.name}")
        applied += 1
    except Exception as exc:
        notes.append(f"workspace name failed: {exc}")
    return applied


def _safe_set_scalar(obj: Any, prop_name: str, value: Any, notes: List[str], label: str) -> bool:
    if obj is None or not prop_name or prop_name in RESTORE_DENY_PROPS:
        return False
    try:
        prop = obj.bl_rna.properties.get(prop_name)
    except Exception:
        prop = None
    if prop is None or getattr(prop, "is_readonly", False) or getattr(prop, "is_hidden", False):
        return False
    try:
        prop_type = prop.type
    except Exception:
        return False
    try:
        if prop_type == "ENUM":
            if not isinstance(value, str):
                return False
            ids = _enum_ids(obj, prop_name)
            if ids and value not in ids:
                return False
            setattr(obj, prop_name, value)
        elif prop_type == "BOOLEAN":
            if not isinstance(value, bool):
                return False
            setattr(obj, prop_name, value)
        elif prop_type == "INT":
            if not isinstance(value, int):
                return False
            setattr(obj, prop_name, value)
        elif prop_type == "FLOAT":
            if isinstance(value, dict) and set(value) == {"__workspace_float__"}:
                token = value["__workspace_float__"]
                if token not in {"inf", "-inf", "nan"}:
                    return False
                value = float(token)
            if not isinstance(value, (int, float)):
                return False
            setattr(obj, prop_name, float(value))
        elif prop_type == "STRING":
            if not isinstance(value, str):
                return False
            setattr(obj, prop_name, value[:2048])
        else:
            return False
        notes.append(f"{label}: {prop_name} -> {value}")
        return True
    except Exception as exc:
        notes.append(f"{label}: {prop_name} failed: {exc}")
        return False


def _apply_rna_block(obj: Any, rna: Dict[str, Any], notes: List[str], label: str, *, allowed: Optional[Set[str]] = None) -> int:
    applied = 0
    if obj is None or not rna:
        return 0
    for prop_name, prop_data in rna.items():
        if allowed is not None and prop_name not in allowed:
            continue
        if prop_name in RESTORE_DENY_PROPS:
            continue
        if not isinstance(prop_data, dict):
            continue
        if prop_data.get("readonly") or prop_data.get("hidden"):
            continue
        if prop_data.get("type") not in RNA_SCALAR_TYPES:
            continue
        if _safe_set_scalar(obj, prop_name, prop_data.get("value"), notes, label):
            applied += 1
    return applied


def _apply_window_display(context, state: Dict[str, Any], notes: List[str]) -> int:
    applied = 0
    saved = ((state.get("categories") or {}).get("window_display") or {})
    win_data = saved.get("window") or {}
    win = _window(context)
    scene_name = win_data.get("active_scene_name") or ""
    if win is not None and scene_name:
        scene = bpy.data.scenes.get(scene_name)
        if scene is not None:
            try:
                win.scene = scene
                applied += 1
                notes.append(f"window scene -> {scene_name}")
            except Exception as exc:
                notes.append(f"window scene failed: {exc}")
    screen = _current_screen(context)
    applied += _apply_rna_block(screen, saved.get("screen_rna") or {}, notes, "screen", allowed={"use_play_3d_editors"})
    # OS-level window position/size and screen assignment are not exposed in a stable, writable way.
    if win_data:
        ws = _workspace(context)
        if ws is not None:
            try:
                ws["workspace_manager_saved_window_info"] = json.dumps(win_data, ensure_ascii=False)[:4096]
                applied += 1
            except Exception:
                pass
    return applied



def _saved_int(saved: Dict[str, Any], *names: str, default: int = 0) -> int:
    for name in names:
        try:
            value = saved.get(name)
        except Exception:
            value = None
        if value is not None:
            try:
                return int(value)
            except Exception:
                pass
    return default


def _area_bbox(area) -> Tuple[int, int, int, int]:
    x = int(getattr(area, "x", 0) or 0)
    y = int(getattr(area, "y", 0) or 0)
    w = int(getattr(area, "width", 0) or 0)
    h = int(getattr(area, "height", 0) or 0)
    return x, y, x + w, y + h


def _saved_bbox(saved: Dict[str, Any]) -> Tuple[int, int, int, int]:
    x = _saved_int(saved, "x")
    y = _saved_int(saved, "y")
    w = _saved_int(saved, "width", "w")
    h = _saved_int(saved, "height", "h")
    return x, y, x + w, y + h


def _bbox_center(bbox: Tuple[int, int, int, int]) -> Tuple[float, float]:
    return (bbox[0] + bbox[2]) / 2.0, (bbox[1] + bbox[3]) / 2.0


def _bbox_size(bbox: Tuple[int, int, int, int]) -> Tuple[float, float]:
    return max(1.0, float(bbox[2] - bbox[0])), max(1.0, float(bbox[3] - bbox[1]))


def _area_saved_distance(area, saved: Dict[str, Any]) -> float:
    ab = _area_bbox(area)
    sb = _saved_bbox(saved)
    acx, acy = _bbox_center(ab)
    scx, scy = _bbox_center(sb)
    aw, ah = _bbox_size(ab)
    sw, sh = _bbox_size(sb)
    return ((acx - scx) ** 2 + (acy - scy) ** 2) + 0.20 * ((aw - sw) ** 2 + (ah - sh) ** 2)


def _match_saved_areas_by_geometry(current_areas: List[Any], saved_areas: List[Dict[str, Any]]) -> List[Tuple[Any, Dict[str, Any], int]]:
    current = list(current_areas)
    saved = list(saved_areas)
    candidates: List[Tuple[float, int, int]] = []
    for ci, area in enumerate(current):
        for si, saved_area in enumerate(saved):
            candidates.append((_area_saved_distance(area, saved_area), ci, si))
    candidates.sort(key=lambda item: (item[0], item[1], item[2]))
    used_current: Set[int] = set()
    used_saved: Set[int] = set()
    pairs: List[Tuple[Any, Dict[str, Any], int]] = []
    for _dist, ci, si in candidates:
        if ci in used_current or si in used_saved:
            continue
        used_current.add(ci)
        used_saved.add(si)
        try:
            saved_index = int(saved[si].get("index", si))
        except Exception:
            saved_index = si
        pairs.append((current[ci], saved[si], saved_index))
        if len(used_current) >= len(current) or len(used_saved) >= len(saved):
            break
    pairs.sort(key=lambda item: item[2])
    return pairs


def _area_rect_from_live(area) -> Dict[str, int]:
    return {
        "x": int(getattr(area, "x", 0) or 0),
        "y": int(getattr(area, "y", 0) or 0),
        "width": int(getattr(area, "width", 0) or 0),
        "height": int(getattr(area, "height", 0) or 0),
    }


def _area_rect_from_saved(saved: Dict[str, Any]) -> Dict[str, int]:
    return {
        "x": int(saved.get("x") or 0),
        "y": int(saved.get("y") or 0),
        "width": int(saved.get("width") or saved.get("w") or 0),
        "height": int(saved.get("height") or saved.get("h") or 0),
    }


def _rect_bounds(rect: Dict[str, Any]) -> Tuple[int, int, int, int]:
    x = int(rect.get("x") or 0)
    y = int(rect.get("y") or 0)
    w = int(rect.get("width") or rect.get("w") or 0)
    h = int(rect.get("height") or rect.get("h") or 0)
    return x, y, x + w, y + h


def _live_area_bounds(area) -> Tuple[int, int, int, int]:
    rect = _area_rect_from_live(area)
    return rect["x"], rect["y"], rect["x"] + rect["width"], rect["y"] + rect["height"]


def _rect_center(bounds: Tuple[int, int, int, int]) -> Tuple[float, float]:
    return (bounds[0] + bounds[2]) * 0.5, (bounds[1] + bounds[3]) * 0.5


def _rect_area(bounds: Tuple[int, int, int, int]) -> int:
    return max(0, bounds[2] - bounds[0]) * max(0, bounds[3] - bounds[1])


def _rect_intersection(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> int:
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))


def _rect_cost(live_bounds: Tuple[int, int, int, int], saved_bounds: Tuple[int, int, int, int]) -> float:
    inter = _rect_intersection(live_bounds, saved_bounds)
    union = max(1, _rect_area(live_bounds) + _rect_area(saved_bounds) - inter)
    iou = inter / union
    lc = _rect_center(live_bounds)
    sc = _rect_center(saved_bounds)
    center_dist = (lc[0] - sc[0]) ** 2 + (lc[1] - sc[1]) ** 2
    size_delta = abs((live_bounds[2] - live_bounds[0]) - (saved_bounds[2] - saved_bounds[0])) + abs((live_bounds[3] - live_bounds[1]) - (saved_bounds[3] - saved_bounds[1]))
    return (1.0 - iou) * 100000000.0 + center_dist + size_delta * 1000.0


def _normalised_saved_area(saved: Dict[str, Any], index: int) -> Dict[str, Any]:
    rect = _area_rect_from_saved(saved)
    out = dict(saved)
    out["index"] = int(saved.get("index", index) or index)
    out["x"] = rect["x"]
    out["y"] = rect["y"]
    out["width"] = rect["width"]
    out["height"] = rect["height"]
    out["w"] = rect["width"]
    out["h"] = rect["height"]
    return out


def _bounds_for_rect_list(bounds_list: Iterable[Tuple[float, float, float, float]]) -> Tuple[float, float, float, float]:
    items = list(bounds_list)
    if not items:
        return (0.0, 0.0, 1.0, 1.0)
    x1 = min(float(item[0]) for item in items)
    y1 = min(float(item[1]) for item in items)
    x2 = max(float(item[2]) for item in items)
    y2 = max(float(item[3]) for item in items)
    return (x1, y1, max(x2, x1 + 1.0), max(y2, y1 + 1.0))


def _normalise_bounds(bounds: Tuple[float, float, float, float], base: Tuple[float, float, float, float]) -> Tuple[float, float, float, float]:
    x1, y1, x2, y2 = base
    width = max(x2 - x1, 1.0)
    height = max(y2 - y1, 1.0)
    return ((float(bounds[0]) - x1) / width, (float(bounds[1]) - y1) / height, (float(bounds[2]) - x1) / width, (float(bounds[3]) - y1) / height)


def _match_area_pairs_by_geometry(current_areas: List[Any], saved_areas: List[Dict[str, Any]]) -> List[Tuple[Any, Dict[str, Any], int]]:
    live = list(current_areas or [])
    saved = [_normalised_saved_area(area, i) for i, area in enumerate(list(saved_areas or []))]
    saved = [area for area in saved if int(area.get("width") or 0) > 0 and int(area.get("height") or 0) > 0]
    live_bounds = [_live_area_bounds(area) for area in live if int(getattr(area, "width", 0) or 0) > 0 and int(getattr(area, "height", 0) or 0) > 0]
    saved_bounds = [_rect_bounds(area) for area in saved]
    live_base = _bounds_for_rect_list(live_bounds)
    saved_base = _bounds_for_rect_list(saved_bounds)
    candidates: List[Tuple[float, int, int]] = []
    for live_i, area in enumerate(live):
        if int(getattr(area, "width", 0) or 0) <= 0 or int(getattr(area, "height", 0) or 0) <= 0:
            continue
        lb = _normalise_bounds(_live_area_bounds(area), live_base)
        for saved_i, saved_area in enumerate(saved):
            sb = _normalise_bounds(_rect_bounds(saved_area), saved_base)
            candidates.append((_rect_cost(lb, sb), live_i, saved_i))
    candidates.sort(key=lambda item: item[0])
    used_live: Set[int] = set()
    used_saved: Set[int] = set()
    pairs: List[Tuple[Any, Dict[str, Any], int]] = []
    for _, live_i, saved_i in candidates:
        if live_i in used_live or saved_i in used_saved:
            continue
        used_live.add(live_i)
        used_saved.add(saved_i)
        pairs.append((live[live_i], saved[saved_i], int(saved[saved_i].get("index", saved_i))))
    return pairs


def _match_saved_areas_to_current(current_areas: List[Any], saved_areas: List[Dict[str, Any]]) -> List[Tuple[Any, Dict[str, Any], int, float]]:
    pairs = _match_area_pairs_by_geometry(current_areas, saved_areas)
    live_bounds = [_live_area_bounds(area) for area in current_areas if int(getattr(area, "width", 0) or 0) > 0 and int(getattr(area, "height", 0) or 0) > 0]
    saved_norm = [_normalised_saved_area(area, i) for i, area in enumerate(list(saved_areas or []))]
    saved_bounds = [_rect_bounds(area) for area in saved_norm if int(area.get("width") or 0) > 0 and int(area.get("height") or 0) > 0]
    live_base = _bounds_for_rect_list(live_bounds)
    saved_base = _bounds_for_rect_list(saved_bounds)
    out: List[Tuple[Any, Dict[str, Any], int, float]] = []
    for area, saved, index in pairs:
        try:
            lb = _normalise_bounds(_live_area_bounds(area), live_base)
            sb = _normalise_bounds(_rect_bounds(_normalised_saved_area(saved, index)), saved_base)
            cost = _rect_cost(lb, sb)
        except Exception:
            cost = 0.0
        out.append((area, saved, index, float(cost)))
    return out


def _sorted_area_pairs(current_areas: List[Any], saved_areas: List[Dict[str, Any]]) -> List[Tuple[Any, Dict[str, Any], int]]:
    return _match_area_pairs_by_geometry(current_areas, saved_areas)


LAYOUT_TREE_EPS = 8
_LAYOUT_RESTORE_JOB: Optional[Dict[str, Any]] = None


def _build_layout_tree_from_saved(saved_areas: List[Dict[str, Any]], eps: int = LAYOUT_TREE_EPS) -> Dict[str, Any]:
    rects = [_normalised_saved_area(area, i) for i, area in enumerate(saved_areas or [])]
    rects = [r for r in rects if int(r.get("width") or 0) > 0 and int(r.get("height") or 0) > 0]
    if not rects:
        raise RuntimeError(_t("保存済みレイアウトに有効なエリア座標がありません。", "The saved layout contains no valid area geometry."))

    def build(items: List[Dict[str, Any]]) -> Dict[str, Any]:
        if len(items) <= 1:
            return {"leaf": items[0], "bbox": list(_rect_bounds(items[0]))}
        x1 = min(int(r["x"]) for r in items)
        y1 = min(int(r["y"]) for r in items)
        x2 = max(int(r["x"] + r["width"]) for r in items)
        y2 = max(int(r["y"] + r["height"]) for r in items)
        xs = sorted({int(r["x"]) for r in items} | {int(r["x"] + r["width"]) for r in items})
        ys = sorted({int(r["y"]) for r in items} | {int(r["y"] + r["height"]) for r in items})
        best = None
        for x in xs:
            if x <= x1 + eps or x >= x2 - eps:
                continue
            left = [r for r in items if int(r["x"] + r["width"]) <= x + eps]
            right = [r for r in items if int(r["x"]) >= x - eps]
            if left and right and len(left) + len(right) == len(items):
                score = (abs(len(left) - len(right)), -min(len(left), len(right)), abs(((x - x1) / max(1, x2 - x1)) - 0.5))
                if best is None or score < best[0]:
                    best = (score, "VERTICAL", x, left, right)
        for y in ys:
            if y <= y1 + eps or y >= y2 - eps:
                continue
            bottom = [r for r in items if int(r["y"] + r["height"]) <= y + eps]
            top = [r for r in items if int(r["y"]) >= y - eps]
            if bottom and top and len(bottom) + len(top) == len(items):
                score = (abs(len(bottom) - len(top)), -min(len(bottom), len(top)), abs(((y - y1) / max(1, y2 - y1)) - 0.5))
                if best is None or score < best[0]:
                    best = (score, "HORIZONTAL", y, bottom, top)
        if best is None:
            width = x2 - x1
            height = y2 - y1
            if width >= height:
                items_sorted = sorted(items, key=lambda r: (int(r["x"] + r["width"] * 0.5), int(r["y"] + r["height"] * 0.5)))
                direction = "VERTICAL"
            else:
                items_sorted = sorted(items, key=lambda r: (int(r["y"] + r["height"] * 0.5), int(r["x"] + r["width"] * 0.5)))
                direction = "HORIZONTAL"
            mid = max(1, len(items_sorted) // 2)
            a, b = items_sorted[:mid], items_sorted[mid:]
            factor = 0.5
        else:
            _, direction, coord, a, b = best
            factor = (coord - x1) / max(1, (x2 - x1)) if direction == "VERTICAL" else (coord - y1) / max(1, (y2 - y1))
        return {"split": direction, "factor": max(0.05, min(0.95, float(factor))), "bbox": [x1, y1, x2, y2], "children": [build(a), build(b)]}
    return build(rects)


def _layout_tree_leaves(node: Dict[str, Any]) -> List[Dict[str, Any]]:
    if "leaf" in node:
        return [node["leaf"]]
    leaves: List[Dict[str, Any]] = []
    for child in node.get("children") or []:
        leaves.extend(_layout_tree_leaves(child))
    return leaves


def _node_bounds(node: Dict[str, Any]) -> Tuple[int, int, int, int]:
    if "bbox" in node:
        b = node["bbox"]
        return int(b[0]), int(b[1]), int(b[2]), int(b[3])
    return _rect_bounds(node["leaf"])


def _area_window_region(area):
    try:
        for region in area.regions:
            if region.type == "WINDOW":
                return region
        return area.regions[-1] if area.regions else None
    except Exception:
        return None


def _find_best_area_for_bounds(screen, target: Tuple[int, int, int, int], used: Optional[Set[int]] = None):
    best = None
    for area in list(getattr(screen, "areas", []) or []):
        ident = id(area)
        if used and ident in used:
            continue
        if int(getattr(area, "width", 0) or 0) <= 0 or int(getattr(area, "height", 0) or 0) <= 0:
            continue
        cost = _rect_cost(_live_area_bounds(area), target)
        if best is None or cost < best[0]:
            best = (cost, area)
    return best[1] if best else None


def _capture_area_summary(screen) -> List[Dict[str, Any]]:
    return [
        {"type": getattr(area, "type", "") or "", "ui_type": getattr(area, "ui_type", "") or "", "x": int(getattr(area, "x", 0) or 0), "y": int(getattr(area, "y", 0) or 0), "width": int(getattr(area, "width", 0) or 0), "height": int(getattr(area, "height", 0) or 0)}
        for area in list(getattr(screen, "areas", []) or [])
    ] if screen is not None else []


def _set_area_to_saved(area, saved: Dict[str, Any], notes: List[str], label: str) -> int:
    applied = 0
    area_type = saved.get("type") or ""
    ui_type = saved.get("ui_type") or ""
    # Apply the broad editor type first, then the more specific ui_type.
    # This prevents a saved 3D View / Outliner / Dope Sheet from being assigned
    # to the correct geometry but left as a previous editor family.
    if area_type and getattr(area, "type", "") != area_type:
        if _safe_set_enum(area, "type", area_type):
            applied += 1
            notes.append(f"{label}: type -> {area_type}")
        else:
            notes.append(f"{label}: type skipped ({area_type})")
    if ui_type and getattr(area, "ui_type", "") != ui_type:
        if _safe_set_enum(area, "ui_type", ui_type):
            applied += 1
            notes.append(f"{label}: ui_type -> {ui_type}")
        else:
            notes.append(f"{label}: ui_type skipped ({ui_type})")
    return applied

def _collapse_one_area(context, notes: List[str], *, window=None, screen=None) -> bool:
    win = window or _window(context)
    screen = screen or (getattr(win, "screen", None) if win is not None else None) or _current_screen(context)
    if screen is None or win is None:
        notes.append("exact layout collapse skipped: no screen/window")
        return False
    areas = list(getattr(screen, "areas", []) or [])
    if len(areas) <= 1:
        return True
    area = areas[-1]
    region = _area_window_region(area)
    if region is None:
        notes.append("exact layout collapse failed: no window region")
        return False
    before = (getattr(area, "type", ""), int(getattr(area, "x", 0) or 0), int(getattr(area, "y", 0) or 0), int(getattr(area, "width", 0) or 0), int(getattr(area, "height", 0) or 0))
    try:
        with context.temp_override(window=win, screen=screen, area=area, region=region):
            result = bpy.ops.screen.area_close()
        notes.append(f"exact layout collapse: {before} -> {result}, remaining={len(list(screen.areas))}")
        return "FINISHED" in result
    except Exception as exc:
        notes.append(f"exact layout collapse failed: {exc}")
        return False


def _split_area_for_node_exact(context, node: Dict[str, Any], notes: List[str], *, window=None, screen=None) -> bool:
    win = window or _window(context)
    screen = screen or (getattr(win, "screen", None) if win is not None else None) or _current_screen(context)
    if screen is None or win is None:
        notes.append("exact layout split skipped: no screen/window")
        return False
    area = _find_best_area_for_bounds(screen, _node_bounds(node))
    if area is None:
        notes.append("exact layout split failed: target area not found")
        return False
    region = _area_window_region(area)
    if region is None:
        notes.append("exact layout split failed: no window region")
        return False
    direction = node.get("split") or "VERTICAL"
    factor = max(0.05, min(0.95, float(node.get("factor") or 0.5)))
    before = _live_area_bounds(area)
    try:
        with context.temp_override(window=win, screen=screen, area=area, region=region):
            result = bpy.ops.screen.area_split(direction=direction, factor=factor)
        notes.append(f"exact layout split: {direction} {factor:.4f} on {before} -> {result}")
        return "FINISHED" in result
    except Exception as exc:
        notes.append(f"exact layout split failed: {exc}")
        return False


def _assign_exact_layout_area_types(context, leaves: List[Dict[str, Any]], notes: List[str], *, screen=None) -> int:
    screen = screen or _current_screen(context)
    if screen is None:
        return 0
    current = list(getattr(screen, "areas", []) or [])
    pairs = _match_area_pairs_by_geometry(current, leaves)
    applied = 0
    for area, saved, saved_index in pairs:
        applied += _set_area_to_saved(area, saved, notes, f"exact area {saved_index}")
    return applied


def _exact_layout_timer_remover(handle):
    _suite_storage.unregister_timer_slot(
        'workspace_manager._exact_layout_restore_tick', handle
    )


def _clear_exact_layout_restore_job() -> None:
    global _LAYOUT_RESTORE_JOB
    _LAYOUT_RESTORE_JOB = None
    _runtime_ledger.remove_feature_leases(
        'workspace-manager-exact-layout', any_generation=False
    )
    _suite_storage.unregister_timer_slot(
        'workspace_manager._exact_layout_restore_tick',
        globals().get('_exact_layout_restore_tick'),
    )


def _start_exact_layout_restore_job(context, state: Dict[str, Any], flags: Dict[str, bool], state_path: str, pre_result: Dict[str, Any]) -> None:
    global _LAYOUT_RESTORE_JOB
    generation = _runtime_ledger.current_generation()
    if not generation or not _runtime_ledger.generation_matches(generation):
        raise RuntimeError('Workspace Manager generation is not current')
    if _LAYOUT_RESTORE_JOB is not None:
        raise RuntimeError(_t("別のレイアウト復元処理が実行中です。", "Another layout restore job is already running."))
    saved_areas = (((state.get("categories") or {}).get("layout") or {}).get("areas") or [])
    if not saved_areas:
        raise RuntimeError(_t("保存済みレイアウト情報がありません。", "The selected save state has no saved layout information."))
    tree = _build_layout_tree_from_saved(saved_areas)
    _LAYOUT_RESTORE_JOB = {
        "generation": generation,
        "state": state,
        "flags": dict(flags),
        "window": _window(context),
        "screen": _current_screen(context),
        "state_path": state_path,
        "pre_result": pre_result,
        "tree": tree,
        "leaves": _layout_tree_leaves(tree),
        "queue": [tree],
        "stage": "collapse",
        "notes": ["exact layout restore started"],
        "counts": {"layout": 0, "settings": 0, "warning_repairs": 0},
        "started_at": _timestamp(),
        "ticks": 0,
        "before_areas": _capture_area_summary(_current_screen(context)),
    }
    ok = _suite_storage.register_timer_slot(
        'workspace_manager._exact_layout_restore_tick',
        _exact_layout_restore_tick,
        first_interval=0.10,
        persistent=False,
    )
    if not ok or not _runtime_ledger.register_lease(
        feature='workspace-manager-exact-layout',
        space='GLOBAL',
        region='TIMER',
        handle=_exact_layout_restore_tick,
        native_remover=_exact_layout_timer_remover,
        is_registered=lambda handle: bool(bpy.app.timers.is_registered(handle)),
    ):
        _clear_exact_layout_restore_job()
        raise RuntimeError('Exact layout restore timer lease failed')


def _exact_layout_restore_tick():
    global _LAYOUT_RESTORE_JOB
    job = _LAYOUT_RESTORE_JOB
    if job is None:
        return None
    if not _runtime_ledger.generation_matches(str(job.get('generation') or '')):
        _clear_exact_layout_restore_job()
        return None
    try:
        context = bpy.context
        job["ticks"] += 1
        if int(job["ticks"]) > 512:
            raise RuntimeError('exact layout restore exceeded finite tick budget')
        win = job.get("window") or _window(context)
        screen = (getattr(win, "screen", None) if win is not None else None) or job.get("screen") or _current_screen(context)
        if screen is None:
            raise RuntimeError("no current screen during exact layout restore")
        stage = job.get("stage")
        notes: List[str] = job["notes"]
        if stage == "collapse":
            if len(list(screen.areas)) > 1:
                ok = _collapse_one_area(context, notes, window=win, screen=screen)
                if not ok:
                    raise RuntimeError("area collapse failed")
                return 0.12
            job["after_collapse"] = _capture_area_summary(screen)
            job["queue"] = [job["tree"]]
            job["stage"] = "split"
            return 0.12
        if stage == "split":
            queue = job["queue"]
            while queue:
                node = queue.pop(0)
                if "leaf" in node:
                    continue
                ok = _split_area_for_node_exact(context, node, notes, window=win, screen=screen)
                if not ok:
                    raise RuntimeError("area split failed")
                children = list(node.get("children") or [])
                if len(children) == 2:
                    queue.insert(0, children[1])
                    queue.insert(0, children[0])
                return 0.12
            job["stage"] = "assign"
            return 0.12
        if stage == "assign":
            job["counts"]["layout"] += _assign_exact_layout_area_types(context, job["leaves"], notes, screen=screen)
            job["after_assign"] = _capture_area_summary(screen)
            job["stage"] = "settings"
            return 0.10
        if stage == "settings":
            flags = job["flags"]
            state = job["state"]
            if flags.get("load_settings"):
                job["counts"]["settings"] += _apply_space_settings(context, state, notes)
            if flags.get("load_warning_repairs"):
                job["counts"]["warning_repairs"] += _apply_warning_repairs(context, state, notes)
            job["after_settings"] = _capture_area_summary(screen)
            _write_diagnostic(context, {"exact_layout_restore": {"state_path": job.get("state_path"), "pre_result": job.get("pre_result"), "counts": job.get("counts"), "notes": notes, "before_areas": job.get("before_areas"), "after_collapse": job.get("after_collapse"), "after_assign": job.get("after_assign"), "after_settings": job.get("after_settings"), "ticks": job.get("ticks")}})
            _clear_exact_layout_restore_job()
            return None
    except Exception as exc:
        try:
            _write_diagnostic(bpy.context, {"exact_layout_restore_error": repr(exc), "job": job})
        except Exception:
            pass
        _clear_exact_layout_restore_job()
        return None



def _apply_layout(context, state: Dict[str, Any], notes: List[str], *, exact_rebuild: bool = False, load_settings: bool = False, load_warning_repairs: bool = False) -> int:
    screen = _current_screen(context)
    if screen is None:
        notes.append("layout skipped: no current screen")
        return 0
    saved_layout = ((state.get("categories") or {}).get("layout") or {})
    saved_areas = saved_layout.get("areas") or []
    current_areas = list(getattr(screen, "areas", []) or [])
    if not current_areas or not saved_areas:
        notes.append("layout skipped: no areas")
        return 0
    if exact_rebuild:
        flags = {"load_settings": bool(load_settings), "load_warning_repairs": bool(load_warning_repairs)}
        _start_exact_layout_restore_job(context, state, flags, "", {"scheduled_by": "_apply_layout"})
        notes.append("exact layout rebuild scheduled")
        return 1
    applied = 0
    if len(current_areas) != len(saved_areas):
        notes.append(f"layout area count differs: current {len(current_areas)}, saved {len(saved_areas)}; applying geometry-matched existing areas only")
    for area, saved, index in _sorted_area_pairs(current_areas, saved_areas):
        applied += _set_area_to_saved(area, saved, notes, f"area {index}")
    ws = _workspace(context)
    if ws is not None:
        try:
            geom = [{k: a.get(k) for k in ("type", "ui_type", "x", "y", "width", "height")} for a in saved_areas]
            ws["workspace_manager_saved_layout_geometry"] = json.dumps(geom, ensure_ascii=False)[:12000]
            applied += 1
        except Exception:
            pass
    return applied

def _saved_active_space_state(saved_area: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    spaces = list(saved_area.get("spaces") or [])
    for space in spaces:
        if space.get("active"):
            return space
    idx = int(saved_area.get("active_space_index") or -1)
    if 0 <= idx < len(spaces):
        return spaces[idx]
    return spaces[0] if spaces else None


def _apply_space_settings(context, state: Dict[str, Any], notes: List[str]) -> int:
    screen = _current_screen(context)
    if screen is None:
        notes.append("settings skipped: no current screen")
        return 0
    saved_areas = (((state.get("categories") or {}).get("settings") or {}).get("areas") or [])
    current_areas = list(getattr(screen, "areas", []) or [])
    pairs = _sorted_area_pairs(current_areas, saved_areas)
    applied = 0
    for area, saved_area, index in pairs:
        active = getattr(getattr(area, "spaces", None), "active", None)
        saved_space = _saved_active_space_state(saved_area)
        if active is None or not saved_space:
            continue
        saved_type = saved_space.get("type") or ""
        active_type = getattr(active, "type", "") or ""
        if saved_type and active_type and saved_type != active_type:
            notes.append(f"area {index}: settings skipped, space type mismatch {active_type} != {saved_type}")
            continue
        # Blender 5.1.1 runtime testing showed that writing broad Space RNA
        # values can crash native Blender. Restore only validated enum values;
        # keep the full saved RNA as metadata and diagnostics.
        rna = saved_space.get("rna") or {}
        for prop_name, prop_data in rna.items():
            if prop_name not in SAFE_SPACE_ENUM_PROPS:
                continue
            if prop_data.get("type") != "ENUM":
                continue
            value = prop_data.get("value")
            if isinstance(value, str) and _safe_set_enum(active, prop_name, value):
                applied += 1
                notes.append(f"area {index}: {prop_name} -> {value}")
    fixed, subnotes = _repair_dopesheet_screen(screen)
    if fixed:
        notes.append(f"dopesheet repaired: {fixed}")
    notes.extend(subnotes)
    return applied

def _apply_warning_repairs(context, state: Dict[str, Any], notes: List[str]) -> int:
    fixed, subnotes = _repair_all_dopesheets()
    if fixed:
        notes.append(f"warning repair -> {fixed}")
    notes.extend(subnotes)
    ws = _workspace(context)
    if ws is not None:
        try:
            ws["workspace_manager_saved_repair_info"] = json.dumps(state.get("repair") or {}, ensure_ascii=False)[:4096]
        except Exception:
            pass
    return fixed


def _apply_state_to_current(context, state: Dict[str, Any], *, load_workspace_name: bool, load_metadata: bool, load_window_display: bool, load_layout: bool, load_settings: bool, load_warning_repairs: bool, exact_layout_rebuild: bool = True) -> Dict[str, Any]:
    notes: List[str] = []
    counts = {"workspace_name": 0, "metadata": 0, "window_display": 0, "layout": 0, "settings": 0, "warning_repairs": 0}
    layout_job_started = False
    if load_metadata:
        counts["metadata"] = _set_workspace_metadata(context, state, notes)
    if load_workspace_name:
        counts["workspace_name"] = _apply_workspace_name(context, state, notes)
    if load_window_display:
        counts["window_display"] = _apply_window_display(context, state, notes)
    if load_layout:
        if exact_layout_rebuild:
            counts["layout"] = _apply_layout(context, state, notes, exact_rebuild=True, load_settings=load_settings, load_warning_repairs=load_warning_repairs)
            layout_job_started = counts["layout"] == 1
            if layout_job_started:
                counts["settings"] = "scheduled_after_exact_layout" if load_settings else 0
                counts["warning_repairs"] = "scheduled_after_exact_layout" if load_warning_repairs else 0
        else:
            counts["layout"] = _apply_layout(context, state, notes, exact_rebuild=False)
    if not layout_job_started:
        if load_settings:
            counts["settings"] = _apply_space_settings(context, state, notes)
        if load_warning_repairs:
            counts["warning_repairs"] = _apply_warning_repairs(context, state, notes)
    return {"counts": counts, "notes": notes, "layout_job_started": layout_job_started}


def _write_diagnostic(context, extra: Optional[Dict[str, Any]] = None) -> Path:
    fixed, repair_notes = _repair_all_dopesheets() if _settings(context).auto_repair_dopesheet else (0, [])
    screen = _current_screen(context)
    areas = list(getattr(screen, "areas", []) or []) if screen else []
    data: Dict[str, Any] = {
        "addon": ADDON_NAME,
        "addon_version": ADDON_VERSION,
        "created_at": _timestamp(),
        "blender_version": ".".join(map(str, bpy.app.version)),
        "platform": sys.platform,
        "workspace": _workspace_name(context),
        "screen": getattr(screen, "name", "") if screen else "",
        "screen_area_count": len(areas),
        "screen_area_types": [getattr(area, "type", "") or "" for area in areas],
        "workspace_count": len(list(getattr(bpy.data, "workspaces", []) or [])),
        "save_state_count": len(_state_files()),
        "paths": {
            "config": str(_config_root()),
            "save_states": str(_states_dir()),
            "backups": str(_backups_dir()),
            "diagnostics": str(_diagnostics_dir()),
        },
        "auto_repair_dopesheet_fixed": fixed,
        "auto_repair_dopesheet_notes": repair_notes,
    }
    if extra:
        data["extra"] = extra
    path = _diagnostics_dir() / f"diagnostic_{_timestamp()}.json"
    _write_json(path, data)
    return path


class WMGR_SaveStateItem(PropertyGroup):
    identifier: StringProperty(name="Identifier")
    display_name: StringProperty(name="Display Name")
    workspace_name: StringProperty(name="Workspace Name")
    source_workspace_name: StringProperty(name="Source Workspace Name")
    scope: StringProperty(name="Scope")
    created_at: StringProperty(name="Created At")
    updated_at: StringProperty(name="Updated At")
    filepath: StringProperty(name="File Path")
    area_count: IntProperty(name="Area Count", default=0)


def _wmgr_setting_update(_self, context):
    try:
        from . import persistence as _suite_persistence
        if not _suite_persistence.persist_immediate_user_change(
            context,
            source='workspace-manager-rna-update',
        ):
            _suite_persistence.mark_deferred_settings_dirty()
    except Exception:
        try:
            _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass


class WMGR_Settings(PropertyGroup):
    save_states: CollectionProperty(type=WMGR_SaveStateItem)
    save_states_index: IntProperty(name="Save State Index", default=-1, update=_wmgr_setting_update)
    auto_backup: BoolProperty(
        name="Backup Before Loading",
        description="Before loading a save state, save the current workspace-related state as a JSON backup. This helps restore manually if a read operation fails.",
        default=True,
        update=_wmgr_setting_update,
    )
    auto_repair_dopesheet: BoolProperty(
        name="Repair Dope Sheet Warning Values",
        description="Before saving or loading, repair invalid Dope Sheet ui_mode enum values when possible. This reduces Blender 5.1 console warnings caused by old or inconsistent UI data.",
        default=True,
        update=_wmgr_setting_update,
    )
    show_advanced: BoolProperty(
        name="Show Advanced Tools",
        description="Show diagnostic, warning repair, refresh, and delete tools. These are separated from the main save-state workflow.",
        default=False,
        update=_wmgr_setting_update,
    )
    list_initialized: BoolProperty(
        name="List Initialized",
        description="Internal flag used to refresh the Workspace Manager save-state list once after the N-panel becomes available.",
        default=False,
        options={'HIDDEN'},
        update=_wmgr_setting_update,
    )


class WMGR_UL_save_states(UIList):
    bl_idname = "WMGR_UL_save_states"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.label(text=item.display_name or item.workspace_name or item.identifier, translate=False, icon="WORKSPACE")
            row.label(text=item.workspace_name or "-", translate=False)
            row.label(text=str(item.area_count), icon="SCREEN_BACK")
        elif self.layout_type == "GRID":
            layout.alignment = "CENTER"
            layout.label(text="", icon="WORKSPACE")


class WMGR_OT_refresh_save_states(Operator):
    bl_idname = "workspace_manager.refresh_save_states"
    bl_label = "Refresh Save State List"
    bl_description = "Reload the save-state list from disk. Use this when files were added or removed outside Blender."
    bl_options = {'UNDO'}

    def execute(self, context):
        count = _refresh_state_items(context)
        self.report({"INFO"}, _t(f"セーブステート一覧を更新しました: {count} 件", f"Refreshed save states: {count}"))
        return {"FINISHED"}


class WMGR_OT_save_current_workspace(Operator):
    bl_idname = "workspace_manager.save_current_workspace"
    bl_label = "Save Current Workspace Settings"
    bl_description = "Save the current open workspace name, window display reference, area layout summary, editor types, and safely readable editor settings as a save state. It does not create or add a workspace."
    bl_options = {'UNDO'}

    def execute(self, context):
        try:
            data = _capture_workspace_state(context, display_name=_workspace_name(context) or "Current Workspace", scope="CURRENT")
            path = _write_state_file(context, data)
        except Exception as exc:
            self.report({"ERROR"}, error_text(exc, "The save state could not be processed", "セーブステートを処理できませんでした", context))
            return {"CANCELLED"}
        self.report({"INFO"}, _t(f"現在のワークスペース設定を保存しました: {path.stem}", f"Saved current workspace settings: {path.stem}"))
        return {"FINISHED"}


class WMGR_OT_save_all_workspaces(Operator):
    bl_idname = "workspace_manager.save_all_workspaces"
    bl_label = "Save All Workspace Settings"
    bl_description = "Save states for every existing workspace. It reads each workspace's available screen information without adding, deleting, or activating new workspaces."
    bl_options = {'UNDO'}

    def execute(self, context):
        workspaces = list(getattr(bpy.data, "workspaces", []) or [])
        if not workspaces:
            self.report({"ERROR"}, _t("保存対象のワークスペースがありません。", "There are no workspaces to save."))
            return {"CANCELLED"}
        saved = 0
        errors: List[str] = []
        batch = _timestamp()
        for ws in workspaces:
            try:
                screen = _screen_for_workspace(context, ws)
                name = getattr(ws, "name", "") or f"Workspace_{saved + 1}"
                data = _capture_workspace_state(context, workspace=ws, screen=screen, display_name=name, scope="ALL", custom_workspace_name=name)
                data["batch_id"] = batch
                _write_state_file(context, data)
                saved += 1
            except Exception as exc:
                errors.append(f"{getattr(ws, 'name', '')}: {exc}")
        _refresh_state_items(context)
        if saved == 0:
            self.report({"ERROR"}, _t("全ワークスペース設定を保存できませんでした。", "Could not save any workspace settings."))
            _write_diagnostic(context, {"save_all_errors": errors})
            return {"CANCELLED"}
        if errors:
            _write_diagnostic(context, {"save_all_saved": saved, "save_all_errors": errors})
            self.report({"WARNING"}, _t(f"{saved} 件保存しました。一部は失敗しました。", f"Saved {saved}; some workspaces failed."))
        else:
            self.report({"INFO"}, _t(f"全てのワークスペース設定を保存しました: {saved} 件", f"Saved all workspace settings: {saved}"))
        return {"FINISHED"}


class WMGR_OT_save_custom_workspace(Operator):
    bl_idname = "workspace_manager.save_custom_workspace"
    bl_label = "Save New Workspace Settings"
    bl_description = "Name a new save state and save the current open workspace's information under that independent save-state name. This does not create a real Blender workspace tab."
    bl_options = {'UNDO'}

    state_name: StringProperty(
        name="New Save-State Workspace Name",
        description="Enter the independent workspace name to show in the save-state list. The current workspace settings are saved under this name without creating a new workspace tab.",
        default="New Workspace State",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        column = self.layout.column(align=True)
        column.label(text=_t("新しいセーブステート名", "New Save-State Name"))
        column.prop(self, "state_name", text="")

    def execute(self, context):
        name = _safe_name(self.state_name, "New_Workspace_State")
        try:
            data = _capture_workspace_state(context, display_name=name, scope="CUSTOM", custom_workspace_name=name)
            path = _write_state_file(context, data)
        except Exception as exc:
            self.report({"ERROR"}, error_text(exc, "The save state could not be processed", "セーブステートを処理できませんでした", context))
            return {"CANCELLED"}
        self.report({"INFO"}, _t(f"新規ワークスペース設定として保存しました: {name}", f"Saved as new workspace settings: {name}"))
        return {"FINISHED"}


class WMGR_OT_load_selected_to_current(Operator):
    bl_idname = "workspace_manager.load_selected_to_current"
    bl_label = "Load Into Current Workspace"
    bl_description = "Open a confirmation popup, choose which saved categories to load, then apply the selected save state to the currently open workspace without adding a new workspace."
    bl_options = {'UNDO'}

    load_workspace_name: BoolProperty(
        name="Workspace Name",
        description="Load the saved workspace name into the currently open workspace. Blender may add a numeric suffix if the name already exists.",
        default=True,
    )
    load_metadata: BoolProperty(
        name="Save-State Metadata",
        description="Load the saved metadata into custom properties on the current workspace, including save-state name, source workspace name, saved Blender version, created date, saved screen name, and saved workspace order. This preserves information that Blender cannot directly apply to the live UI.",
        default=True,
    )
    load_window_display: BoolProperty(
        name="Window Display Information",
        description="Load safe window display information, such as the saved scene reference and saved screen metadata. OS-level window position and size are stored but not forced because Blender's Python API does not expose stable writable window geometry in Blender 5.1.",
        default=True,
    )
    load_layout: BoolProperty(
        name="Layout and Docking Information",
        description="Load the saved docking and layout information. By default this reconstructs the active screen split tree from saved area coordinates, then assigns each saved editor to the matching recreated position.",
        default=True,
    )
    exact_layout_rebuild: BoolProperty(
        name="Exact Layout Reconstruction",
        description="Collapse the current screen to one area, rebuild the saved split layout with screen.area_split, then assign the saved editor types by saved coordinates. This does not add a workspace.",
        default=True,
    )
    load_settings: BoolProperty(
        name="Settings Information",
        description="Apply validated editor setting values and display settings to matching existing editors. Tool slots, WorkSpaceTool data, and unsafe region visibility flags are skipped to avoid native Blender crashes.",
        default=True,
    )
    load_warning_repairs: BoolProperty(
        name="Warning Repair Information",
        description="Run the stored warning-repair workflow, including Dope Sheet, Node Editor, and Image Editor enum value repair, before and after loading.",
        default=True,
    )

    def invoke(self, context, event):
        if _selected_state_path(context) is None:
            self.report({"ERROR"}, _t("読み込むセーブステートを選択してください。", "Select a save state to load."))
            return {"CANCELLED"}
        self.load_workspace_name = True
        self.load_metadata = True
        self.load_window_display = True
        self.load_layout = True
        self.exact_layout_rebuild = True
        self.load_settings = True
        self.load_warning_repairs = True
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        layout = self.layout
        item = _selected_state_item(context)
        if item is not None:
            box = layout.box()
            box.label(text=_t(f"選択中: {item.display_name}", f"Selected: {item.display_name}"), icon="WORKSPACE")
            box.label(text=_t(f"保存名: {item.workspace_name}", f"Saved workspace name: {item.workspace_name}"))
            box.label(text=_t(f"エリア数: {item.area_count}", f"Areas: {item.area_count}"))
        layout.prop(self, "load_workspace_name", text=_t("ワークスペース名", "Workspace Name"))
        layout.prop(self, "load_metadata", text=_t("セーブステート情報", "Save-State Metadata"))
        layout.prop(self, "load_window_display", text=_t("ウィンドウ表示情報", "Window Display Information"))
        layout.prop(self, "load_layout", text=_t("レイアウト・ドッキング情報", "Layout and Docking Information"))
        if self.load_layout:
            layout.prop(self, "exact_layout_rebuild", text=_t("保存時の分割レイアウトを再構成", "Rebuild Saved Split Layout"))
        layout.prop(self, "load_settings", text=_t("設定情報", "Settings Information"))
        layout.prop(self, "load_warning_repairs", text=_t("警告修復情報", "Warning Repair Information"))

    def execute(self, context):
        path = _selected_state_path(context)
        if path is None:
            self.report({"ERROR"}, _t("読み込むセーブステートを選択してください。", "Select a save state to load."))
            return {"CANCELLED"}
        try:
            _backup_current(context, "load")
            data = _load_state(path)
            result = _apply_state_to_current(
                context,
                data,
                load_workspace_name=self.load_workspace_name,
                load_metadata=self.load_metadata,
                load_window_display=self.load_window_display,
                load_layout=self.load_layout,
                load_settings=self.load_settings,
                load_warning_repairs=self.load_warning_repairs,
                exact_layout_rebuild=self.exact_layout_rebuild,
            )
            _write_diagnostic(context, {"load_state": str(path), "load_result": result})
        except Exception as exc:
            self.report({"ERROR"}, error_text(exc, "The save state could not be processed", "セーブステートを処理できませんでした", context))
            return {"CANCELLED"}
        if result.get("layout_job_started"):
            self.report({"INFO"}, _t("セーブステートの読込を開始しました。レイアウト再構成は少し遅れて完了します。", "Started loading the save state. Exact layout reconstruction will finish shortly."))
        else:
            self.report({"INFO"}, _t("セーブステートを現在のワークスペースに読み込みました。", "Loaded the save state into the current workspace."))
        return {"FINISHED"}


class WMGR_OT_delete_selected_save_state(Operator):
    bl_idname = "workspace_manager.delete_selected_save_state"
    bl_label = "Delete Selected Save State"
    bl_description = "Delete the selected save-state JSON file from disk. This does not delete any Blender workspace."
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        old_index = int(settings.save_states_index)
        path = _selected_state_path(context)
        if path is None:
            self.report({"ERROR"}, _t("削除するセーブステートを選択してください。", "Select a save state to delete."))
            return {"CANCELLED"}
        try:
            path.unlink(missing_ok=True)
            _refresh_state_items(context)
            item_count = len(settings.save_states)
            settings.save_states_index = min(max(old_index, 0), item_count - 1) if item_count else -1
        except Exception as exc:
            self.report({"ERROR"}, error_text(exc, "The save state could not be processed", "セーブステートを処理できませんでした", context))
            return {"CANCELLED"}
        self.report({"INFO"}, _t("セーブステートを削除しました。", "Deleted the save state."))
        return {"FINISHED"}


class WMGR_OT_rename_selected_save_state(Operator):
    bl_idname = "workspace_manager.rename_selected_save_state"
    bl_label = "Rename Selected Save State"
    bl_description = "Rename the selected saved workspace setting. The JSON file and list entry are updated, and the new name is used when loading workspace-name information."
    bl_options = {'UNDO'}

    new_name: StringProperty(
        name="New Save-State Name",
        description="Enter the new saved workspace name. If the same name already exists, the rename is cancelled to avoid accidental overwrite.",
        default="",
    )

    def invoke(self, context, event):
        item = _selected_state_item(context)
        if item is None:
            self.report({"ERROR"}, _t("名前を変更するセーブステートを選択してください。", "Select a save state to rename."))
            return {"CANCELLED"}
        self.new_name = item.workspace_name or item.display_name or item.identifier
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        column = self.layout.column(align=True)
        column.label(text=_t("新しいセーブステート名", "New Save-State Name"))
        column.prop(self, "new_name", text="")

    def execute(self, context):
        path = _selected_state_path(context)
        if path is None:
            self.report({"ERROR"}, _t("名前を変更するセーブステートを選択してください。", "Select a save state to rename."))
            return {"CANCELLED"}
        try:
            new_path = _rename_state_file(context, path, self.new_name)
        except Exception as exc:
            self.report({"ERROR"}, error_text(exc, "The save state could not be processed", "セーブステートを処理できませんでした", context))
            return {"CANCELLED"}
        self.report({"INFO"}, _t(f"セーブステート名を変更しました: {new_path.stem}", f"Renamed save state: {new_path.stem}"))
        return {"FINISHED"}


class WMGR_OT_move_save_state_up(Operator):
    bl_idname = "workspace_manager.move_save_state_up"
    bl_label = "Move Save State Up"
    bl_description = "Move the selected saved workspace setting one step upward in the list. The order is saved and restored after restarting Blender."
    bl_options = {'UNDO'}

    def execute(self, context):
        if not _move_selected_state(context, -1):
            return {"CANCELLED"}
        return {"FINISHED"}


class WMGR_OT_move_save_state_down(Operator):
    bl_idname = "workspace_manager.move_save_state_down"
    bl_label = "Move Save State Down"
    bl_description = "Move the selected saved workspace setting one step downward in the list. The order is saved and restored after restarting Blender."
    bl_options = {'UNDO'}

    def execute(self, context):
        if not _move_selected_state(context, 1):
            return {"CANCELLED"}
        return {"FINISHED"}


class WMGR_OT_repair_dopesheet(Operator):
    bl_idname = "workspace_manager.repair_dopesheet"
    bl_label = "Repair Dope Sheet Warnings"
    bl_description = "Repair invalid Dope Sheet ui_mode enum values on all screens to reduce Blender 5.1 console warnings."
    bl_options = {'UNDO'}

    def execute(self, context):
        count, notes = _repair_all_dopesheets()
        _write_diagnostic(context, {"repair_dopesheet_count": count, "notes": notes})
        self.report({"INFO"}, _t(f"Dope Sheet警告要素を修復しました: {count} 件", f"Repaired Dope Sheet warning items: {count}"))
        return {"FINISHED"}


class WMGR_OT_export_diagnostics(Operator):
    bl_idname = "workspace_manager.export_diagnostics"
    bl_label = "Export Diagnostics"
    bl_description = "Write a JSON diagnostic report containing current workspace, screen, save-state, path, and warning-repair information."
    bl_options = {'UNDO'}

    def execute(self, context):
        path = _write_diagnostic(context)
        self.report({"INFO"}, _t(f"診断を書き出しました: {path.name}", f"Exported diagnostics: {path.name}"))
        return {"FINISHED"}


def draw_workspace_manager_ui(layout, context):
    """Draw Workspace Manager inside Smart Workspace without registering a second N-panel tab."""
    try:
        settings = _settings(context)
    except Exception as exc:
        col = layout.column(align=True)
        col.label(text=_t("ワークスペース管理を初期化中です。", "Workspace Manager is initializing."))
        return
    # Draw is deliberately read-only.  Save-state files are scanned at the
    # registration/load boundary or by the explicit Refresh command.
    screen = _current_screen(context)
    areas = list(getattr(screen, "areas", []) or []) if screen else []

    col = layout.column(align=True)
    box = col.box()
    box.label(text=_t("現在のワークスペース", "Current Workspace"), icon="WORKSPACE")
    box.label(text=_t(f"名前: {_workspace_name(context) or '-'}", f"Name: {_workspace_name(context) or '-'}"))
    box.label(text=_t(f"スクリーン: {getattr(screen, 'name', '-') if screen else '-'}", f"Screen: {getattr(screen, 'name', '-') if screen else '-'}"))
    box.label(text=_t(f"エリア数: {len(areas)}", f"Areas: {len(areas)}"))

    col.separator()
    col.label(text=_t("保存", "Save"), icon="FILE_TICK")
    save_box = col.box()
    save_box.operator("workspace_manager.save_current_workspace", text=_t("現在のワークスペース設定を保存", "Save Current Workspace Settings"), icon="FILE_TICK")
    save_box.operator("workspace_manager.save_all_workspaces", text=_t("全てのワークスペース設定を保存", "Save All Workspace Settings"), icon="FILE_FOLDER")
    save_box.operator("workspace_manager.save_custom_workspace", text=_t("新規ワークスペース設定を保存", "Save New Workspace Settings"), icon="ADD")

    col.separator()
    col.label(text=_t("セーブステート", "Save States"), icon="PRESET")
    list_box = col.box()
    list_box.template_list("WMGR_UL_save_states", "", settings, "save_states", settings, "save_states_index", rows=6)
    row = list_box.row(align=True)
    row.operator("workspace_manager.load_selected_to_current", text=_t("現在のワークスペースに読み込み", "Load Into Current Workspace"), icon="IMPORT")
    row.operator("workspace_manager.refresh_save_states", text="", icon="FILE_REFRESH")
    row = list_box.row(align=True)
    row.operator("workspace_manager.rename_selected_save_state", text=_t("名前変更", "Rename"), icon="GREASEPENCIL")
    row.operator("workspace_manager.delete_selected_save_state", text=_t("削除", "Delete"), icon="TRASH")
    row.operator("workspace_manager.move_save_state_up", text="", icon="TRIA_UP")
    row.operator("workspace_manager.move_save_state_down", text="", icon="TRIA_DOWN")

    col.separator()
    col.prop(settings, "show_advanced", text=_t("詳細管理を表示", "Show Advanced Management"), icon="PREFERENCES")
    if settings.show_advanced:
        adv = col.box()
        adv.label(text=_t("安全設定", "Safety Settings"), icon="LOCKED")
        adv.prop(settings, "auto_backup", text=_t("読み込み前にバックアップ", "Backup Before Loading"))
        adv.prop(settings, "auto_repair_dopesheet", text=_t("Dope Sheet警告値を自動修復", "Auto Repair Dope Sheet Warning Values"))
        adv.separator()
        row = adv.row(align=True)
        row.operator("workspace_manager.repair_dopesheet", text=_t("警告修復", "Repair Warnings"), icon="TOOL_SETTINGS")
        adv.operator("workspace_manager.export_diagnostics", text=_t("診断を書き出し", "Export Diagnostics"), icon="TEXT")


classes = (
    WMGR_SaveStateItem,
    WMGR_Settings,
    WMGR_UL_save_states,
    WMGR_OT_refresh_save_states,
    WMGR_OT_save_current_workspace,
    WMGR_OT_save_all_workspaces,
    WMGR_OT_save_custom_workspace,
    WMGR_OT_load_selected_to_current,
    WMGR_OT_delete_selected_save_state,
    WMGR_OT_rename_selected_save_state,
    WMGR_OT_move_save_state_up,
    WMGR_OT_move_save_state_down,
    WMGR_OT_repair_dopesheet,
    WMGR_OT_export_diagnostics,
)


def _initial_refresh_timer():
    try:
        if hasattr(bpy.context.window_manager, "workspace_manager_settings"):
            _refresh_state_items(bpy.context)
            _settings(bpy.context).list_initialized = True
    except Exception:
        pass
    return None


def queue_initial_refresh() -> bool:
    """Scan the save-state files once the startup context can write RNA."""
    return bool(_suite_storage.register_timer_slot(
        "workspace_manager._initial_refresh_timer",
        _initial_refresh_timer,
        first_interval=0.10,
        persistent=True,
    ))


def _registered_class_named(name: str):
    """Return Blender's currently exposed class object for diagnostics only."""
    try:
        candidate = getattr(bpy.types, str(name or ""), None)
        return candidate if isinstance(candidate, type) else None
    except Exception:
        return None


def _class_is_registered(cls) -> bool:
    return bool(isinstance(cls, type) and _runtime_ledger.class_is_current(cls))


def _safe_unregister_class(cls) -> bool:
    """Unregister only an exact class identity owned by this generation."""
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return True
    return bool(_runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix="WORKSPACE_MANAGER_CLASS",
    ))


_WMGR_POINTER_ATTR = "workspace_manager_settings"
_WMGR_SETTINGS_IDENTIFIER = "WMGR_Settings"
_WMGR_SAVE_ITEM_IDENTIFIER = "WMGR_SaveStateItem"
_WMGR_PROPERTY_GROUP_IDENTIFIERS = {
    _WMGR_SETTINGS_IDENTIFIER,
    _WMGR_SAVE_ITEM_IDENTIFIER,
}


def _wmgr_rna_property_definition():
    """Read the live descriptor without inferring ownership from its identifier."""
    try:
        wm_type = getattr(bpy.types, "WindowManager", None)
        properties = getattr(getattr(wm_type, "bl_rna", None), "properties", None)
        getter = getattr(properties, "get", None)
        return getter(_WMGR_POINTER_ATTR) if callable(getter) else None
    except Exception:
        return None


def _wmgr_pointer_fixed_type_identifier() -> str:
    """Compatibility diagnostic only; never used as ownership proof."""
    prop = _wmgr_rna_property_definition()
    try:
        fixed_type = getattr(prop, "fixed_type", None) if prop is not None else None
        return str(getattr(fixed_type, "identifier", "") or "")
    except Exception:
        return ""


def _wmgr_pointer_exists() -> bool:
    return _wmgr_rna_property_definition() is not None


def _wmgr_pointer_is_suite_owned() -> bool:
    return _runtime_ledger.property_is_current(
        bpy.types.WindowManager,
        _WMGR_POINTER_ATTR,
        WMGR_Settings,
    )


def _wmgr_pointer_teardown_unsafe() -> bool:
    try:
        from . import persistence as _suite_persistence
        if bool(
            getattr(_suite_persistence, "_FILE_LOAD_IN_PROGRESS", False)
            or getattr(_suite_persistence, "_RESTORING", False)
            or getattr(_suite_persistence, "_RESTORE_PENDING", False)
        ):
            return True
    except Exception:
        pass
    try:
        return bool(_suite_storage.registration_write_guard_active())
    except Exception:
        return False


def _remove_settings_pointer() -> bool:
    """Remove only the exact descriptor recorded by the current generation."""
    if not _wmgr_pointer_exists():
        return True
    if not _wmgr_pointer_is_suite_owned():
        return True
    if _wmgr_pointer_teardown_unsafe():
        return False
    try:
        delattr(bpy.types.WindowManager, _WMGR_POINTER_ATTR)
    except Exception:
        return False
    return _wmgr_rna_property_definition() is None


def _safe_register_class(cls):
    """Register one exact class; never adopt or unregister another generation."""
    if not isinstance(cls, type):
        return None
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix="WORKSPACE_MANAGER_CLASS",
    )
    return cls if success else None


def _ensure_settings_pointer(settings_cls=None) -> bool:
    """Create one exact current-generation PointerProperty or stop safely."""
    owner = bpy.types.WindowManager
    if _wmgr_pointer_exists():
        if _wmgr_pointer_is_suite_owned():
            return True
        _runtime_ledger.mark_restart_required("FOREIGN_OR_OLD_WORKSPACE_MANAGER_POINTER")
        return False
    settings_type = settings_cls if isinstance(settings_cls, type) else None
    if settings_type is None:
        return False
    if not _runtime_ledger.class_is_current(settings_type):
        _runtime_ledger.mark_restart_required("WORKSPACE_MANAGER_SETTINGS_CLASS_IDENTITY_UNPROVEN")
        return False
    created = False
    try:
        setattr(owner, _WMGR_POINTER_ATTR, PointerProperty(type=settings_type))
        created = True
        if not _runtime_ledger.record_property(
            owner,
            _WMGR_POINTER_ATTR,
            settings_type,
            remover=lambda _handle=None: delattr(owner, _WMGR_POINTER_ATTR),
            newly_registered=True,
        ):
            raise RuntimeError("Workspace Manager pointer ownership ledger failed")
        return _wmgr_pointer_is_suite_owned()
    except Exception:
        if created:
            try:
                delattr(owner, _WMGR_POINTER_ATTR)
            except Exception:
                pass
        _runtime_ledger.mark_restart_required("WORKSPACE_MANAGER_POINTER_REGISTRATION_FAILED")
        return False


def _wmgr_module_matches(module_name: str) -> bool:
    """Compatibility diagnostic retained without module discovery side effects."""
    text = str(module_name or "")
    return "smart_workspace_suite" in text and text.endswith("workspace_manager")


def _purge_stale_initial_refresh_timers() -> None:
    """Remove only the bounded current-generation timer lease, if present."""
    _runtime_ledger.remove_feature_leases("workspace-manager-refresh", any_generation=False)
    try:
        _suite_storage.unregister_timer_slot(
            "workspace_manager._initial_refresh_timer",
            globals().get("_initial_refresh_timer"),
        )
    except Exception:
        pass



def validate_runtime_ownership() -> bool:
    """Validate exact current class/property identities without changing RNA."""
    if not _runtime_ledger.current_generation():
        return False
    for cls in classes:
        if not _runtime_ledger.class_is_current(cls):
            return False
    owner = bpy.types.WindowManager
    descriptor = _wmgr_rna_property_definition()
    if descriptor is None:
        return False
    return bool(_runtime_ledger.property_is_current(owner, _WMGR_POINTER_ATTR, WMGR_Settings))

def ensure_registered(context=None, *, refresh: bool = False, restore: bool = False) -> bool:
    """Transactionally expose Workspace Manager RNA without touching foreign RNA."""
    newly_registered: list[type] = []
    new_properties: list[tuple[type, str]] = []
    try:
        for cls in classes:
            was_current = _class_is_registered(cls)
            if _safe_register_class(cls) is None:
                raise RuntimeError("RESTART_REQUIRED: Workspace Manager class identity mismatch")
            if not was_current:
                newly_registered.append(cls)
        pointer_existed = _wmgr_pointer_exists()
        if not _ensure_settings_pointer(WMGR_Settings):
            raise RuntimeError("RESTART_REQUIRED: Workspace Manager pointer identity mismatch")
        if not pointer_existed:
            new_properties.append((bpy.types.WindowManager, _WMGR_POINTER_ATTR))
        if restore:
            from . import persistence as _suite_persistence
            restored = _suite_persistence.restore_rna_state(
                context or getattr(bpy, "context", None)
            )
            if restored is False:
                raise RuntimeError("Workspace Manager RNA restore failed")
        # The save-state rows come from the files, so they are read after any
        # restore of the saved RNA values.
        if refresh:
            ctx = context or bpy.context
            _refresh_state_items(ctx)
            try:
                _settings(ctx).list_initialized = True
            except Exception:
                pass
        return True
    except Exception:
        _runtime_ledger.rollback_new_items(newly_registered, new_properties)
        return False


def register():
    _purge_stale_initial_refresh_timers()
    # The package-level strict persistence transaction performs the sole
    # startup restore after every RNA owner and native root is registered.
    if not ensure_registered(bpy.context, refresh=True, restore=False):
        raise RuntimeError("RESTART_REQUIRED: Workspace Manager registration transaction failed")


def unregister():
    _clear_exact_layout_restore_job()
    _purge_stale_initial_refresh_timers()
    property_group_safe = _remove_settings_pointer()
    for cls in reversed(classes):
        if cls in {WMGR_Settings, WMGR_SaveStateItem} and not property_group_safe:
            continue
        _safe_unregister_class(cls)


if __name__ == "__main__":
    register()
