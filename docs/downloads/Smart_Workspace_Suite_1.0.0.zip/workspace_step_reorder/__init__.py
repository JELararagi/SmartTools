# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Workspace one-step tab reorder integration for Smart Workspace Suite."""

from __future__ import annotations

import ctypes
from dataclasses import dataclass
from typing import Iterable, Sequence

import bpy
from .. import runtime_ledger as _runtime_ledger
from ..translation import error_text
from bpy.app.translations import contexts as i18n_contexts
from bpy.app.translations import pgettext_iface, pgettext_tip
from bpy.types import Menu, Operator, WorkSpace

ADDON_ID = __package__ or __name__

TOOL_LABEL = "Workspace Step Reorder"
TOOL_LABEL_JA = "ワークスペース順序移動"
ENABLE_LABEL = "Enable"
DISABLE_LABEL = "Disable"
ENABLED_LABEL = "Enabled"
DISABLED_LABEL = "Disabled"
MOVE_FORWARD_LABEL = "Move Forward"
MOVE_BACKWARD_LABEL = "Move Backward"

TOOL_DESCRIPTION = (
    "Adds one-step workspace tab movement commands to the workspace tab right-click menu. "
    "Enable this when you want to move the clicked workspace only one tab at a time instead of sending it all the way to the front or back."
)
MOVE_FORWARD_DESCRIPTION = (
    "Moves the selected workspace one position toward the front of the workspace tabs. "
    "Use this from the workspace tab right-click menu when you want to adjust the order without sending the tab all the way to the front."
)
MOVE_BACKWARD_DESCRIPTION = (
    "Moves the selected workspace one position toward the back of the workspace tabs. "
    "Use this from the workspace tab right-click menu when you want to adjust the order without sending the tab all the way to the back."
)
ENABLE_DESCRIPTION = (
    "Enables Workspace Step Reorder and adds Move Forward and Move Backward to Blender's workspace tab right-click menu. "
    "The setting is saved immediately and remains after Blender restarts or another scene is opened."
)
DISABLE_DESCRIPTION = (
    "Disables Workspace Step Reorder and removes its commands from Blender's workspace tab right-click menu. "
    "Use this when you want Blender's standard workspace menu to remain unchanged."
)
ORDER_READ_ERROR = "The workspace order could not be read in this Blender build."
TARGET_DETECT_ERROR = "The selected workspace could not be detected."

# Blender 5.1 WorkSpace DNA offset of the hidden WorkSpace.order integer.
# This is the same internal order field used by Blender's native workspace tab ordering code.
_WORKSPACE_ORDER_OFFSET = 500
_WORKSPACE_ORDER_VALUE_LIMIT = 1_000_000

_REGISTERED_CLASSES: list[type] = []
_MENU_INSTALLED = False

_TRANSLATIONS = {
    "ja_JP": {
        ("*", TOOL_LABEL): TOOL_LABEL_JA,
        ("*", ENABLE_LABEL): "有効",
        ("*", DISABLE_LABEL): "無効",
        ("*", ENABLED_LABEL): "有効",
        ("*", DISABLED_LABEL): "無効",
        ("*", MOVE_FORWARD_LABEL): "前側に移動",
        ("*", MOVE_BACKWARD_LABEL): "後ろ側に移動",
        (i18n_contexts.operator_default, MOVE_FORWARD_LABEL): "前側に移動",
        (i18n_contexts.operator_default, MOVE_BACKWARD_LABEL): "後ろ側に移動",
        ("*", TOOL_DESCRIPTION): (
            "ワークスペースタブの右クリックメニューに、ワークスペースを1つずつ前後へ移動するコマンドを追加します。"
            "タブを最前面や最後方まで一気に移動せず、クリックしたワークスペースの順番を少しだけ調整したい場合に有効化します。"
        ),
        ("*", MOVE_FORWARD_DESCRIPTION): (
            "選択中のワークスペースを、ワークスペースタブの並びで1つだけ前側へ移動します。"
            "タブを最前面まで移動せず、順番を少しだけ調整したいときに、ワークスペースタブの右クリックメニューから使用します。"
        ),
        ("*", MOVE_BACKWARD_DESCRIPTION): (
            "選択中のワークスペースを、ワークスペースタブの並びで1つだけ後ろ側へ移動します。"
            "タブを最後方まで移動せず、順番を少しだけ調整したいときに、ワークスペースタブの右クリックメニューから使用します。"
        ),
        ("*", ENABLE_DESCRIPTION): (
            "ワークスペース順序移動を有効にし、Blender標準のワークスペースタブ右クリックメニューへ「前側に移動」と「後ろ側に移動」を追加します。"
            "設定は即時保存され、Blender再起動後や別シーンを開いた後も維持されます。"
        ),
        ("*", DISABLE_DESCRIPTION): (
            "ワークスペース順序移動を無効にし、Blender標準のワークスペースタブ右クリックメニューから追加コマンドを外します。"
            "Blender標準のワークスペースメニューを変更せず使いたい場合に無効化します。"
        ),
        ("*", ORDER_READ_ERROR): "このBlenderビルドではワークスペースの並び順を読み取れませんでした。",
        ("*", TARGET_DETECT_ERROR): "選択中のワークスペースを検出できませんでした。",
    }
}


@dataclass(frozen=True)
class _WorkspaceOrderSnapshot:
    workspace: WorkSpace
    order: int


def _iface(message: str) -> str:
    return pgettext_iface(message)


def _tip(message: str) -> str:
    return pgettext_tip(message)


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(context, "preferences", None) if context is not None else getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
        if getattr(view, "use_translate_interface", True) is False:
            return False
        lang = str(getattr(view, "language", "") or "").strip().lower()
        if lang and lang != "default":
            return lang.startswith("ja") or "japanese" in lang
    except Exception:
        pass
    try:
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "").strip().lower()
        return locale.startswith("ja")
    except Exception:
        return False


def ui_label(en: str, ja: str, context=None) -> str:
    return str(ja if _is_ja(context) else en)


def _settings(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    return getattr(wm, "nptl_settings", None) if wm is not None else None


def is_enabled(context=None) -> bool:
    st = _settings(context)
    if st is None or not hasattr(st, "workspace_step_reorder_enabled"):
        return False
    try:
        return bool(getattr(st, "workspace_step_reorder_enabled", False))
    except Exception:
        return False


def _read_workspace_order(workspace: WorkSpace) -> int:
    return int(ctypes.c_int32.from_address(workspace.as_pointer() + _WORKSPACE_ORDER_OFFSET).value)


def _write_workspace_order(workspace: WorkSpace, value: int) -> None:
    ctypes.c_int32.from_address(workspace.as_pointer() + _WORKSPACE_ORDER_OFFSET).value = int(value)


def _workspace_snapshots(workspaces: Iterable[WorkSpace]) -> list[_WorkspaceOrderSnapshot]:
    snapshots = [_WorkspaceOrderSnapshot(workspace=workspace, order=_read_workspace_order(workspace)) for workspace in workspaces]
    if not _orders_are_plausible(snapshots):
        raise RuntimeError(ORDER_READ_ERROR)
    return snapshots


def _orders_are_plausible(snapshots: Sequence[_WorkspaceOrderSnapshot]) -> bool:
    if len(snapshots) <= 1:
        return True
    values = [item.order for item in snapshots]
    if len(set(values)) < 2:
        return False
    return all(-_WORKSPACE_ORDER_VALUE_LIMIT <= value <= _WORKSPACE_ORDER_VALUE_LIMIT for value in values)


def _ordered_workspaces_from_snapshots(snapshots: Sequence[_WorkspaceOrderSnapshot]) -> list[WorkSpace]:
    return [item.workspace for item in sorted(snapshots, key=lambda item: (item.order, item.workspace.name))]


def _changed_workspace(before: Sequence[_WorkspaceOrderSnapshot], after: Sequence[_WorkspaceOrderSnapshot]) -> WorkSpace | None:
    before_by_pointer = {item.workspace.as_pointer(): item for item in before}
    changed: list[WorkSpace] = []
    for item in after:
        previous = before_by_pointer.get(item.workspace.as_pointer())
        if previous is not None and previous.order != item.order:
            changed.append(item.workspace)
    if len(changed) == 1:
        return changed[0]
    return None


def _move_workspace_one_step(context: bpy.types.Context, *, toward_front: bool) -> set[str]:
    workspaces = list(bpy.data.workspaces)
    if len(workspaces) <= 1:
        return {'CANCELLED'}

    try:
        before = _workspace_snapshots(workspaces)
    except RuntimeError as exc:
        raise RuntimeError(_tip(str(exc))) from exc

    # Let Blender's native operator resolve the workspace under the tab context menu.
    # This avoids custom UI context overrides and keeps right-click target handling identical to Blender's own commands.
    if toward_front:
        native_result = bpy.ops.workspace.reorder_to_front()
    else:
        native_result = bpy.ops.workspace.reorder_to_back()
    if not native_result:
        return {'CANCELLED'}

    try:
        after = _workspace_snapshots(workspaces)
    except RuntimeError as exc:
        raise RuntimeError(_tip(str(exc))) from exc

    target = _changed_workspace(before, after)
    if target is None:
        target = getattr(context.window, "workspace", None) if context.window else None
    if target is None:
        raise RuntimeError(_tip(TARGET_DETECT_ERROR))

    ordered = _ordered_workspaces_from_snapshots(before)
    try:
        current_index = ordered.index(target)
    except ValueError as exc:
        raise RuntimeError(_tip(TARGET_DETECT_ERROR)) from exc

    target_index = current_index - 1 if toward_front else current_index + 1
    if 0 <= target_index < len(ordered):
        ordered[current_index], ordered[target_index] = ordered[target_index], ordered[current_index]

    for index, workspace in enumerate(ordered):
        _write_workspace_order(workspace, index)

    try:
        from ..runtime import ui_operators as _workspace_ui
        _workspace_ui.refresh_workspace_ui_order_cache(context)
    except Exception:
        pass
    _tag_workspace_ui_redraw(context)
    return {'FINISHED'}


def _tag_workspace_ui_redraw(context: bpy.types.Context | None = None) -> None:
    try:
        window_manager = getattr(context, "window_manager", None) if context is not None else getattr(getattr(bpy, "context", None), "window_manager", None)
        if window_manager is None:
            return
        for window in getattr(window_manager, "windows", ()) or ():
            screen = getattr(window, "screen", None)
            if screen is None:
                continue
            for area in getattr(screen, "areas", ()) or ():
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


class WORKSPACE_OT_step_move_forward(Operator):
    bl_idname = "workspace.step_move_forward"
    bl_label = MOVE_FORWARD_LABEL
    bl_description = MOVE_FORWARD_DESCRIPTION

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return is_enabled(context) and context.window is not None and len(bpy.data.workspaces) > 1

    def execute(self, context: bpy.types.Context) -> set[str]:
        try:
            return _move_workspace_one_step(context, toward_front=True)
        except RuntimeError as exc:
            self.report({'ERROR'}, error_text(exc, 'The workspace could not be moved', 'ワークスペースを移動できませんでした', context))
            return {'CANCELLED'}
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'The workspace could not be moved', 'ワークスペースを移動できませんでした', context))
            return {'CANCELLED'}


class WORKSPACE_OT_step_move_backward(Operator):
    bl_idname = "workspace.step_move_backward"
    bl_label = MOVE_BACKWARD_LABEL
    bl_description = MOVE_BACKWARD_DESCRIPTION

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return is_enabled(context) and context.window is not None and len(bpy.data.workspaces) > 1

    def execute(self, context: bpy.types.Context) -> set[str]:
        try:
            return _move_workspace_one_step(context, toward_front=False)
        except RuntimeError as exc:
            self.report({'ERROR'}, error_text(exc, 'The workspace could not be moved', 'ワークスペースを移動できませんでした', context))
            return {'CANCELLED'}
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'The workspace could not be moved', 'ワークスペースを移動できませんでした', context))
            return {'CANCELLED'}


class SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled(Operator):
    bl_idname = "smart_workspace.set_workspace_step_reorder_enabled"
    bl_label = "Set Workspace Step Reorder"
    bl_description = "Enable or disable Workspace Step Reorder and save the setting immediately."
    bl_options = {'INTERNAL'}

    enabled: bpy.props.BoolProperty(default=True)

    @classmethod
    def description(cls, context, properties):
        try:
            return _tip(ENABLE_DESCRIPTION if bool(getattr(properties, "enabled", True)) else DISABLE_DESCRIPTION)
        except Exception:
            return _tip(TOOL_DESCRIPTION)

    def execute(self, context):
        desired = bool(getattr(self, "enabled", True))
        st = _settings(context)
        if st is not None and hasattr(st, "workspace_step_reorder_enabled"):
            try:
                setattr(st, "workspace_step_reorder_enabled", desired)
            except Exception:
                pass
        apply_enabled(desired, context=context, save=True)
        self.report({'INFO'}, ui_label("Workspace Step Reorder setting saved.", "ワークスペース順序移動の設定を保存しました。", context))
        return {'FINISHED'}


_CLASSES = (
    WORKSPACE_OT_step_move_forward,
    WORKSPACE_OT_step_move_backward,
    SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled,
)


def _workspace_menu_draw(self: Menu, context: bpy.types.Context) -> None:
    if not is_enabled(context):
        return
    try:
        if len(bpy.data.workspaces) <= 1:
            return
    except Exception:
        return
    layout = self.layout
    try:
        layout.separator()
    except Exception:
        pass
    try:
        layout.operator(WORKSPACE_OT_step_move_forward.bl_idname, text=_iface(MOVE_FORWARD_LABEL), icon='TRIA_LEFT')
        layout.operator(WORKSPACE_OT_step_move_backward.bl_idname, text=_iface(MOVE_BACKWARD_LABEL), icon='TRIA_RIGHT')
    except Exception:
        pass


def _install_menu() -> None:
    global _MENU_INSTALLED
    if _MENU_INSTALLED:
        return
    menu_cls = getattr(bpy.types, "TOPBAR_MT_workspace_menu", None)
    if menu_cls is None:
        return
    try:
        menu_cls.remove(_workspace_menu_draw)
    except Exception:
        pass
    try:
        menu_cls.append(_workspace_menu_draw)
        _MENU_INSTALLED = True
    except Exception:
        _MENU_INSTALLED = False


def _remove_menu() -> None:
    global _MENU_INSTALLED
    menu_cls = getattr(bpy.types, "TOPBAR_MT_workspace_menu", None)
    if menu_cls is None:
        _MENU_INSTALLED = False
        return
    try:
        menu_cls.remove(_workspace_menu_draw)
    except Exception:
        pass
    _MENU_INSTALLED = False


def apply_enabled(enabled: bool | None = None, *, context=None, save: bool = False) -> bool:
    desired = is_enabled(context) if enabled is None else bool(enabled)
    if desired:
        _install_menu()
    else:
        _remove_menu()
    if save:
        try:
            from ..runtime import core as _core
            save_fn = getattr(_core, "save_config_to_file", None)
            if callable(save_fn):
                save_fn(context or getattr(bpy, "context", None))
        except Exception:
            pass
    _tag_workspace_ui_redraw(context)
    return desired


def sync_from_settings(context=None) -> bool:
    return apply_enabled(is_enabled(context), context=context, save=False)


def draw_settings_ui(layout, context) -> None:
    st = _settings(context)
    enabled = is_enabled(context)
    col = layout.column(align=True)
    try:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context), icon='WORKSPACE')
    except Exception:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context))
    row = col.row(align=True)
    op = row.operator(SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled.bl_idname, text=ui_label(ENABLED_LABEL, "有効", context), depress=enabled)
    try:
        op.enabled = True
    except Exception:
        pass
    op = row.operator(SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled.bl_idname, text=ui_label(DISABLED_LABEL, "無効", context), depress=not enabled)
    try:
        op.enabled = False
    except Exception:
        pass
    try:
        if st is not None and hasattr(st, "workspace_step_reorder_enabled"):
            # Keep the RNA BoolProperty present for Blender's normal tooltip/status handling without drawing a duplicate user-facing switch.
            pass
    except Exception:
        pass
    try:
        status = ui_label("Current state: Enabled", "現在の状態: 有効", context) if enabled else ui_label("Current state: Disabled", "現在の状態: 無効", context)
        col.label(text=status, icon='CHECKMARK' if enabled else 'X')
    except Exception:
        pass


def register() -> bool:
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    bpy.app.translations.register(ADDON_ID, _TRANSLATIONS)
    _REGISTERED_CLASSES.clear()
    for cls in _CLASSES:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='WORKSPACE_STEP_REORDER_CLASS',
        )
        if not success:
            raise RuntimeError('RESTART_REQUIRED: Workspace Step Reorder class ownership mismatch')
        _REGISTERED_CLASSES.append(cls)
    sync_from_settings(getattr(bpy, "context", None))
    return len(_REGISTERED_CLASSES) == len(_CLASSES)

def unregister() -> bool:
    _remove_menu()
    for cls in reversed(_REGISTERED_CLASSES):
        if not _runtime_ledger.class_recorded_current(cls):
            return False
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='WORKSPACE_STEP_REORDER_CLASS',
        ):
            return False
    _REGISTERED_CLASSES.clear()
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    return True

if __name__ == "__main__":
    register()
