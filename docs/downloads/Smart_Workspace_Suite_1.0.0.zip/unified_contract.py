# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart Workspace RNA identifiers and boundaries for saving preferences."""

CONTRACT_VERSION = 1
EXTENSION_ID = "smart_workspace_suite"
CONFIG_FOLDER = "Smart_Workspace_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"

_WINDOW = "window_manager"
_RUNTIME = f"{_WINDOW}.smart_workspace_suite_runtime_settings"
_PANEL = f"{_WINDOW}.nptl_settings"
_FEATURE = f"{_WINDOW}.sws_always"
_OPTIMIZER = "scene.smart_viewport_optimizer_settings"
_WORKSPACE = f"{_WINDOW}.workspace_manager_settings"
_KEY_LAYOUT = f"{_WINDOW}.kle_ui_state"
_DETECTED_TABS = f"{_PANEL}.workspace_profiles[*].detected_tabs[*]"

STATE_SAVE_PATH = f"{_PANEL}.n_panel_state_save_enabled"
SECTION_OPEN_PATH = f"{_PANEL}.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    f"{_RUNTIME}.live_pin_follow_enabled",
    *(f"{_PANEL}.{feature}_enabled" for feature in (
        "workspace_step_reorder", "synchronize_workspaces", "floating_window_lock",
    )),
    *(f"{_FEATURE}_{feature}" for feature in (
        "workspace_auto_restore", "panview_follow_camera", "panview_show_hud",
        "icon_viewer_console_header", "icon_viewer_auto_save", "script_launcher_load_restore",
        "screencast_runtime", "screencast_enable_on_startup", "screencast_auto_save",
        "screencast_hotkey", "kle_emulation_active", "kle_reapply_keymap_panel",
        "kle_reapply_reload", "kle_detect_addon_changes", "viewport_pie_hotkeys",
        "viewport_optimizer_file_boundaries", "blend_proxy_cleanup_watch",
        "external_sync_guard_watch",
    )),
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()

_ROOT_PANEL = "NPTL_PT_properties_root"
ROOT_PANEL_IDS = (_ROOT_PANEL, *(f"{_ROOT_PANEL}_{editor}" for editor in (
    "image_editor", "node_editor", "sequence_editor", "clip_editor", "dopesheet_editor",
    "graph_editor", "nla_editor", "text_editor", "file_browser", "spreadsheet",
)))

PERSISTENCE_ROOTS = (_RUNTIME, _PANEL, f"{_FEATURE}_*")
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    "scene.panview_*", "scene.sws_synchronize_workspaces_*", "scene.sl_group",
    _OPTIMIZER, _KEY_LAYOUT, _WORKSPACE,
)
PERSISTED_DYNAMIC_UI_PROJECTIONS = ({
    "path": f"{_FEATURE}_captured_*",
    "authoritative_store": f"feature_toggles/{EXTENSION_ID}_persistent_feature_toggles.json",
    "canonical_json_mirror": "sidecars.feature_toggles",
},)
BLEND_OWNED_NPANEL_PATHS = (
    *(f"tool_settings.{setting}" for setting in (
        "use_keyframe_insert_auto", "use_proportional_edit_objects", "use_proportional_edit",
        "use_proportional_connected", "use_proportional_projected",
    )),
    "scene.camera",
    *(f"object.{setting}" for setting in (
        "show_in_front", "hide_viewport", "hide_render", "show_wire", "color", "show_name",
        "show_axis", "data.show_names", "data.show_axes",
    )),
)
EXCLUDED_TRANSIENT_PATHS = (
    f"{_PANEL}.name", f"{_RUNTIME}.name", f"{_RUNTIME}.auto_restore_on_file_load",
    f"{_PANEL}.workspace_selector", "scene.panview_follow_active_camera", "scene.panview_show_hud",
    f"{_OPTIMIZER}.name", f"{_OPTIMIZER}.status_text", f"{_OPTIMIZER}.svo_workspace_active_name",
    f"{_WORKSPACE}.name", "scene.sl_group.name", f"{_KEY_LAYOUT}.name",
    f"{_KEY_LAYOUT}.listening_key",
    *(f"{_DETECTED_TABS}.{field}" for field in ("identifier", "name", "original_category")),
    f"{_WORKSPACE}.save_states", "scene.synch_settings", f"{_WINDOW}.panview_tracked_windows",
    "scene.remap_targets", "scene.remap_target_libraries",
)
