"""Machine-readable SmartTools N-panel and persistence contract."""

CONTRACT_VERSION = 1
EXTENSION_ID = 'smart_workspace_suite'
CONFIG_FOLDER = 'Smart_Workspace_Suite'
CONFIG_FILE = 'Smart_Workspace_Suite.json'
STATE_SAVE_PATH = 'window_manager.nptl_settings.n_panel_state_save_enabled'
SECTION_OPEN_PATH = 'window_manager.nptl_settings.show_always_on_toggles'
RUNTIME_TOGGLE_PATHS = (
    'window_manager.smart_workspace_suite_runtime_settings.live_pin_follow_enabled',
    'window_manager.nptl_settings.workspace_step_reorder_enabled',
    'window_manager.nptl_settings.synchronize_workspaces_enabled',
    'window_manager.nptl_settings.floating_window_lock_enabled',
    'window_manager.sws_always_workspace_auto_restore',
    'window_manager.sws_always_panview_follow_camera',
    'window_manager.sws_always_panview_show_hud',
    'window_manager.sws_always_icon_viewer_console_header',
    'window_manager.sws_always_icon_viewer_auto_save',
    'window_manager.sws_always_script_launcher_load_restore',
    'window_manager.sws_always_screencast_runtime',
    'window_manager.sws_always_screencast_enable_on_startup',
    'window_manager.sws_always_screencast_auto_save',
    'window_manager.sws_always_screencast_hotkey',
    'window_manager.sws_always_kle_emulation_active',
    'window_manager.sws_always_kle_reapply_keymap_panel',
    'window_manager.sws_always_kle_reapply_reload',
    'window_manager.sws_always_kle_detect_addon_changes',
    'window_manager.sws_always_viewport_pie_hotkeys',
    'window_manager.sws_always_viewport_optimizer_file_boundaries',
    'window_manager.sws_always_blend_proxy_cleanup_watch',
    'window_manager.sws_always_external_sync_guard_watch',
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = (
    'NPTL_PT_properties_root',
    'NPTL_PT_properties_root_image_editor',
    'NPTL_PT_properties_root_node_editor',
    'NPTL_PT_properties_root_sequence_editor',
    'NPTL_PT_properties_root_clip_editor',
    'NPTL_PT_properties_root_dopesheet_editor',
    'NPTL_PT_properties_root_graph_editor',
    'NPTL_PT_properties_root_nla_editor',
    'NPTL_PT_properties_root_text_editor',
    'NPTL_PT_properties_root_file_browser',
    'NPTL_PT_properties_root_spreadsheet',
)
PERSISTENCE_ROOTS = (
    # Suite-level runtime preferences (including the event-driven live panel
    # pin follow switch) are stored in the canonical Smart Workspace JSON.
    'window_manager.smart_workspace_suite_runtime_settings',
    'window_manager.nptl_settings',
    'window_manager.sws_always_*',
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    'scene.panview_*',
    'scene.sws_synchronize_workspaces_*',
    'scene.sl_group',
    'scene.smart_viewport_optimizer_settings',
    'window_manager.kle_ui_state',
    'window_manager.workspace_manager_settings',
)

# Captured runtime switches are generated only after a lazy integrated tool is
# materialized.  Their WindowManager BoolProperties are UI projections, not an
# independent source of truth.  feature_toggle.set_feature_enabled() saves the
# authoritative alias/key map immediately and storage mirrors that sidecar into
# Smart_Workspace_Suite.json.  Declare the projection explicitly instead of
# advertising an RNA wildcard that cannot exist in a clean all-off profile.
PERSISTED_DYNAMIC_UI_PROJECTIONS = (
    {
        'path': 'window_manager.sws_always_captured_*',
        'authoritative_store': 'feature_toggles/smart_workspace_suite_persistent_feature_toggles.json',
        'canonical_json_mirror': 'sidecars.feature_toggles',
    },
)
BLEND_OWNED_NPANEL_PATHS = (
    # Native Blender tool, scene, object, and armature display state exposed by
    # the bundled Viewport Pie panels.  These values belong to the current
    # document and must stay in the .blend instead of the global suite JSON.
    'tool_settings.use_keyframe_insert_auto',
    'tool_settings.use_proportional_edit_objects',
    'tool_settings.use_proportional_edit',
    'tool_settings.use_proportional_connected',
    'tool_settings.use_proportional_projected',
    'scene.camera',
    'object.show_in_front',
    'object.hide_viewport',
    'object.hide_render',
    'object.show_wire',
    'object.color',
    'object.show_name',
    'object.show_axis',
    'object.data.show_names',
    'object.data.show_axes',
)
EXCLUDED_TRANSIENT_PATHS = (
    # Built-in PropertyGroup metadata, not an N-panel setting.
    'window_manager.nptl_settings.name',
    # Built-in PropertyGroup metadata and a compatibility projection of the
    # canonical ``sws_always_workspace_auto_restore`` switch.  Neither is an
    # independent N-panel setting.
    'window_manager.smart_workspace_suite_runtime_settings.name',
    'window_manager.smart_workspace_suite_runtime_settings.auto_restore_on_file_load',
    # Internal active-workspace routing key; the visible workspace pointer and
    # per-workspace profiles are persisted separately.
    'window_manager.nptl_settings.workspace_selector',
    # Runtime mirrors of the canonical sws_always_* controls.  They are drawn
    # inside 2D Pan View too, but represent the same two always-on choices and
    # must not be treated as independent restart settings.
    'scene.panview_follow_active_camera',
    'scene.panview_show_hud',
    'scene.smart_viewport_optimizer_settings.name',
    # Live status/notification text produced by optimizer operations.  It is
    # neither an editable setting nor stable scene state, and is intentionally
    # declared SKIP_SAVE by the owning PropertyGroup.
    'scene.smart_viewport_optimizer_settings.status_text',
    # Hidden SKIP_SAVE routing cache derived from the active workspace.  This
    # is not an editable N-panel setting and is rebuilt from the live workspace.
    'scene.smart_viewport_optimizer_settings.svo_workspace_active_name',
    'window_manager.workspace_manager_settings.name',
    'scene.sl_group.name',
    'window_manager.kle_ui_state.name',
    # Momentary key-capture prompt; it is cleared whenever the operator exits
    # and must not be restored after startup/scene changes.
    'window_manager.kle_ui_state.listening_key',
    # Detected-tab identity metadata is rebuilt from the registered Sidebar
    # panels.  The collection order and user controls (show/custom_name/pin)
    # remain persisted; only these non-editable discovery fields are transient
    # audit metadata used to associate each override with its live tab.
    'window_manager.nptl_settings.workspace_profiles[*].detected_tabs[*].identifier',
    'window_manager.nptl_settings.workspace_profiles[*].detected_tabs[*].name',
    'window_manager.nptl_settings.workspace_profiles[*].detected_tabs[*].original_category',
    # Filesystem-derived save-state inventory shown by the Workspace Manager
    # template list.  Rows are rebuilt from the per-state JSON files; persisting
    # the mirror (or its active index) would resurrect stale entries after a
    # file is renamed/deleted outside Blender.
    'window_manager.workspace_manager_settings.save_states',
    # Disabled compatibility RNA owned by the legacy Synchronize Workspaces shim.
    'scene.synch_settings',
    # Live Window RNA pointers; never meaningful across a restart or scene load.
    'window_manager.panview_tracked_windows',
    # Operator-dialog candidates rebuilt from the current datablock graph on invoke.
    'scene.remap_targets',
    'scene.remap_target_libraries',
)
