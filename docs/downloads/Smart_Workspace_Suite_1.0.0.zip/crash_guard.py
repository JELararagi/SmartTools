# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Non-invasive compatibility state for Smart Workspace Suite.

The generation ledger is the sole owner of classes, RNA, handlers, timers,
msgbus subscriptions, modal handles, and draw handles.  This module keeps the
historical callable surface but never scans ``sys.modules``, rewrites global
Blender/Python APIs, removes another Suite's callback, or guesses ownership by
module/name.
"""

from __future__ import annotations

_INSTALLED_EARLY = False
_INSTALLED_RUNTIME = False
_EXIT_IN_PROGRESS = False


def remove_legacy_global_patches() -> dict[str, int]:
    """Compatibility no-op; unproven global state is never changed."""
    return {
        "addon_utils": 0,
        "bpy_exit": 0,
        "traceback": 0,
        "external_callbacks": 0,
        "local_modal_methods": 0,
    }


def purge_legacy_timers_and_handlers() -> dict[str, int]:
    """Compatibility no-op; runtime_ledger owns exact native removers."""
    return {"timers": 0, "handlers": 0}


def purge_orphan_suite_timer_functions() -> int:
    """Compatibility no-op; no timer enumeration or module scan is allowed."""
    return 0


def harden_external_exit_cleanup() -> int:
    """Compatibility no-op; other Suites are never modified."""
    return 0


def harden_modal_callbacks() -> None:
    """Compatibility no-op; registered class methods are never patched."""
    return None


def install_addon_utils_exit_guard() -> bool:
    """Compatibility no-op; addon_utils is never wrapped."""
    return False


def install_blender_exit_wrapper() -> bool:
    """Compatibility no-op; Blender private exit hooks are never wrapped."""
    return False


def install_early() -> None:
    """Mark import complete without installing callbacks or global wrappers."""
    global _INSTALLED_EARLY
    _INSTALLED_EARLY = True


def install_runtime() -> None:
    """Mark runtime active; all real resources are generation-ledger leases."""
    global _INSTALLED_RUNTIME
    _INSTALLED_RUNTIME = True


def uninstall_runtime() -> None:
    """Clear local flags only; exact resources are released by runtime_ledger."""
    global _INSTALLED_RUNTIME, _INSTALLED_EARLY, _EXIT_IN_PROGRESS
    _INSTALLED_RUNTIME = False
    _INSTALLED_EARLY = False
    _EXIT_IN_PROGRESS = False


def is_exit_in_progress() -> bool:
    return bool(_EXIT_IN_PROGRESS)


install_early()
