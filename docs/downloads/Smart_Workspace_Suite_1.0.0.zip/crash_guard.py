# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Keep the retired patch API callable without changing another add-on."""
_INSTALLED_EARLY = True
_INSTALLED_RUNTIME = False
_EXIT_IN_PROGRESS = False


def remove_legacy_global_patches():
    return dict.fromkeys(
        ("addon_utils", "bpy_exit", "traceback", "external_callbacks", "local_modal_methods"), 0
    )


def purge_legacy_timers_and_handlers():
    return {"timers": 0, "handlers": 0}


def _zero():
    return 0


purge_orphan_suite_timer_functions = _zero
harden_external_exit_cleanup = _zero


def harden_modal_callbacks():
    return None


def _uninstalled():
    return False


install_addon_utils_exit_guard = _uninstalled
install_blender_exit_wrapper = _uninstalled


def install_early():
    global _INSTALLED_EARLY
    _INSTALLED_EARLY = True


def install_runtime():
    global _INSTALLED_RUNTIME
    _INSTALLED_RUNTIME = True


def uninstall_runtime():
    global _INSTALLED_EARLY, _INSTALLED_RUNTIME, _EXIT_IN_PROGRESS
    _INSTALLED_EARLY = _INSTALLED_RUNTIME = _EXIT_IN_PROGRESS = False


def is_exit_in_progress():
    return bool(_EXIT_IN_PROGRESS)
