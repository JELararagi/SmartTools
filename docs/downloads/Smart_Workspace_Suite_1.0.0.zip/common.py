# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

import json
import os
import re
import sys
import textwrap
from pathlib import Path

import bpy
from . import storage as _suite_storage
from . import settings_vfs as _suite_vfs
from . import runtime_ledger as _runtime_ledger
from .translation import error_text
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

PACKAGE_ID = 'smart_workspace_suite'
ADDON_NAME = 'Smart_Workspace_Suite'
TOOL_LABEL_EN = 'Smart Workspace'
TOOL_LABEL_JA = 'スマートワークスペース'
PANEL_CATEGORY = 'Smart Workspace'


def _smart_workspace_category_key(value) -> str:
    try:
        text = str(value or '').casefold()
    except Exception:
        return ''
    return ''.join(ch for ch in text if ch.isalnum())

def _is_smart_workspace_category(value) -> bool:
    return _smart_workspace_category_key(value) == _smart_workspace_category_key(PANEL_CATEGORY)

def _is_current_root_panel_name(cls) -> bool:
    try:
        return str(getattr(cls, '__name__', '') or '') == 'NPTL_PT_properties_root' or str(getattr(cls, 'bl_idname', '') or '') == 'NPTL_PT_properties_root'
    except Exception:
        return False
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_COMMON_ALWAYS_ON_PROPERTY_OWNER = object()
_ALWAYS_ON_OWNER_IDENTITY = object()
_COMMON_CLASS_TRACK_ATTR = '_smart_workspace_common_registered_owner'
_COMMON_CLASS_TRACK_OWNER = PACKAGE_ID + '.common'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_SANITIZED_SETTINGS_MIRROR_DIRTY = False

# Only Smart Workspace Suite-owned top-level RNA may enter this legacy
# sidecar.  Older compatibility code used broad prefixes such as ``smart_``
# and ``show_`` and consequently copied settings from every other SmartTools
# package into Smart Workspace's JSON.  Reapplying that file fired hundreds of
# foreign update callbacks during startup and could overwrite another Suite's
# current state.  Nested properties are accepted when their owner is one of
# this package's PropertyGroups.
_OWN_ROOT_PROPERTY_NAMES = {
    _ALWAYS_ON_PROP,
    'nptl_settings',
    'synch_active',
    'workspace_manager_settings',
}
_OWN_ROOT_PROPERTY_PREFIXES = (
    'panview_',
    'smart_viewport_optimizer_',
    'smart_workspace_suite_',
    'sws_',
)


_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _translation_owner_ids() -> tuple[str, ...]:
    owners: list[str] = []
    for raw in (PACKAGE_ID, __name__):
        owner = str(raw or '').strip()
        if owner and owner not in owners:
            owners.append(owner)
    return tuple(owners)


def _registered_class_tracking_key(cls) -> tuple[str, str]:
    try:
        module = str(getattr(cls, '__module__', '') or '')
    except Exception:
        module = ''
    try:
        qualname = str(getattr(cls, '__qualname__', getattr(cls, '__name__', '')) or '')
    except Exception:
        qualname = ''
    return (module, qualname)


def _remember_registered_class(cls) -> None:
    if not isinstance(cls, type):
        return
    try:
        setattr(cls, _COMMON_CLASS_TRACK_ATTR, _COMMON_CLASS_TRACK_OWNER)
    except Exception:
        pass
    key = _registered_class_tracking_key(cls)
    updated = []
    seen_current = False
    for existing in tuple(_REGISTERED_CLASSES):
        if existing is cls:
            if not seen_current:
                updated.append(existing)
                seen_current = True
            continue
        if _registered_class_tracking_key(existing) != key:
            updated.append(existing)
            continue
        if getattr(existing, _COMMON_CLASS_TRACK_ATTR, None) != _COMMON_CLASS_TRACK_OWNER:
            updated.append(existing)
            continue
        if _runtime_ledger.class_recorded_current(existing):
            updated.append(existing)
            continue
    if not seen_current:
        updated.append(cls)
    _REGISTERED_CLASSES[:] = updated


def _register_common_translations() -> None:
    payload = _translation_payload()
    last_error = None
    for owner in _translation_owner_ids():
        try:
            bpy.app.translations.register(owner, payload)
        except ValueError:
            try:
                bpy.app.translations.unregister(owner)
            except Exception:
                pass
            try:
                bpy.app.translations.register(owner, payload)
            except Exception as exc:
                last_error = exc
        except Exception as exc:
            last_error = exc
    if last_error is not None:
        raise last_error


def _unregister_common_translations() -> None:
    for owner in reversed(_translation_owner_ids()):
        try:
            bpy.app.translations.unregister(owner)
        except Exception:
            pass


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Store generated suite files in the suite-owned Blender CONFIG folder.
    try:
        from . import storage as _suite_storage
        return _suite_storage.user_data_dir(create=bool(create))
    except Exception:
        # Import-time fallback only. Even when storage.py is unavailable, never
        # create startup/user files beside the immutable Extension package.
        try:
            version = getattr(getattr(bpy, 'app', None), 'version', None)
            version_text = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
        except Exception:
            version_text = '5.1'
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            root = Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'config' / 'Smart_Workspace_Suite' / 'sidecars' / _STORAGE_DIRNAME
        else:
            root = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config')) / 'blender' / version_text / 'config' / 'Smart_Workspace_Suite' / 'sidecars' / _STORAGE_DIRNAME
        if create:
            try:
                root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    """Settings-layer key of the N-panel settings (a member of the one settings file)."""
    return _suite_vfs.N_PANEL_SETTINGS_KEY


def _load_previews():
    global _PREVIEW_COLLECTION
    _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    try:
        from . import ui_icons as _suite_ui_icons
        return int(_suite_ui_icons.icon_value(str(name or ''), int(fallback)) or int(fallback))
    except Exception:
        pass
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_WORKSPACE_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group. The help content is loaded only when this button is clicked.'
    bl_options = set()

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})
    help_id: StringProperty(default='runtime', options={'SKIP_SAVE'})

    def _help_topic(self):
        help_id = str(getattr(self, 'help_id', '') or '').strip()
        topic = str(getattr(self, 'topic', '') or '').strip()
        if help_id:
            return help_id
        if topic and topic != 'overview':
            return topic
        return 'runtime'

    def invoke(self, context, event):
        del event
        try:
            from . import help as _suite_help
            from . import guide as _suite_guide
            del _suite_guide
            prepare = getattr(_suite_help, 'prepare_help_snapshot', None)
            if callable(prepare):
                prepare(self._help_topic())
            width = int(getattr(_suite_help, 'HELP_POPUP_DEFAULT_WIDTH_PX', 760) or 760)
        except Exception:
            width = 760
        try:
            return context.window_manager.invoke_popup(self, width=width)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = self._help_topic()
        try:
            _suite_help = sys.modules.get(f'{__package__}.help')
            draw_help = getattr(_suite_help, 'draw_help', None) if _suite_help is not None else None
            if callable(draw_help):
                draw_help(layout, context, topic, popup_width=int(getattr(_suite_help, 'HELP_POPUP_DEFAULT_WIDTH_PX', 760) or 760))
                return
        except Exception:
            pass
        try:
            guide = sys.modules.get(f'{__package__}.guide')
            get_group = getattr(guide, 'get_group', None) if guide is not None else None
            if not callable(get_group):
                raise RuntimeError('prepared help catalog is unavailable')
            group = get_group(topic)
        except Exception as exc:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help catalog could not be loaded: ' + str(exc)],
                'overview_ja': ['ヘルプカタログを読み込めませんでした: ' + str(exc)],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='QUESTION')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_WORKSPACE_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggles'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'
    bl_options = {'UNDO'}

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, error_text(exc, 'The setting could not be changed', '設定を変更できませんでした', context))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, error_text(exc, 'The setting could not be changed', '設定を変更できませんでした', context))
        try:
            from . import persistence as _suite_persistence
            if not _suite_persistence.persist_immediate_user_change(
                context,
                source='common-always-on-operator',
                force=True,
            ):
                _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return {'FINISHED'}


class SMART_WORKSPACE_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save current N-panel settings to CONFIG/Smart_Workspace_Suite and request Blender to save user preferences.'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        try:
            from . import persistence as _suite_persistence
            save_all = getattr(_suite_persistence, 'save_all_settings', None)
            if callable(save_all):
                save_all(context, force_central=True)
        except Exception:
            pass
        save_persistent_settings(context, force=True)
        try:
            _suite_storage.snapshot_json_storage_to_central(force=True)
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


class SMART_WORKSPACE_PT_always_on(bpy.types.Panel):
    bl_idname = 'SMART_WORKSPACE_PT_always_on'
    bl_label = 'Always-on Toggles'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        self.layout.label(text='', icon='TIME')

    def draw(self, context):
        draw_always_on_panel(self.layout, context)


def _rna_property_definition(owner_type, property_name):
    try:
        properties = getattr(getattr(owner_type, 'bl_rna', None), 'properties', None)
        getter = getattr(properties, 'get', None)
        return getter(property_name) if callable(getter) else None
    except Exception:
        return None


def _feature_entries():
    """Return the already prepared feature snapshot without draw imports."""
    try:
        feature_toggle = sys.modules.get(f'{__package__}.feature_toggle')
        entries_fn = getattr(feature_toggle, 'feature_entries', None) if feature_toggle is not None else None
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None) if feature_toggle is not None else None
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic', 'help_id'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _clean_panel_registration_fields(cls) -> None:
    """Do not rewrite live or pending Panel fields."""
    del cls
    return None



def _safe_unregister_class(cls):
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return False
    return _runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='COMMON_COMPAT_CLASS',
    )


def _duplicate_error_message(exc) -> bool:
    text_value = str(exc or '').lower()
    return 'already registered' in text_value or 'registered as a subclass' in text_value


def _managed_class(cls) -> bool:
    if not isinstance(cls, type):
        return False
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    if prefix and (module_name == prefix or module_name.startswith(prefix + '.')):
        return True
    if bl_idname.startswith(PACKAGE_ID + '.') or bl_idname.startswith('nptl.'):
        return True
    return False


def _registered_class_candidates(cls):
    """Return only exact RNA lookup matches for ``cls``.

    Normal extension startup must not enumerate every Blender RNA type or every
    imported module for each class.  Exact lookups cover the stale-class cases
    that can be repaired safely; broader cleanup is reserved for explicit
    migration routines.
    """
    if not isinstance(cls, type):
        return []
    out = []
    seen = set()

    def _add(candidate):
        if not isinstance(candidate, type):
            return
        ident = id(candidate)
        if ident in seen:
            return
        seen.add(ident)
        out.append(candidate)

    for identifier in (
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
    ):
        if not identifier:
            continue
        try:
            _add(getattr(bpy.types, identifier, None))
        except Exception:
            pass
    return out


def _force_unregister_equivalent_class(cls) -> int:
    """Never adopt/unregister an equivalent class by identifier."""
    del cls
    return 0



def _retire_standalone_always_on_panel():
    """Compatibility no-op; displayed Panel RNA is never changed."""
    return None



def _flatten_npanel_parent_before_register(cls):
    """Compatibility no-op; Panel parent/category metadata is immutable."""
    return cls



def _register_class_wrapper(cls):
    """Register the exact class once; duplicate identity requires restart."""
    _materialize_annotations(cls)
    register_class = _ORIGINAL_REGISTER_CLASS or bpy.utils.register_class
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='COMMON_COMPAT_CLASS',
    )
    if not success:
        raise RuntimeError('RESTART_REQUIRED: common compatibility class ownership mismatch')
    return None



def begin_register():
    """No global bpy.utils monkey patch is installed."""
    global _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    return None



def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    _ORIGINAL_REGISTER_CLASS = None
    return None



def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    try:
        stack = list(getattr(bpy.types, 'Panel').__subclasses__())
    except Exception:
        stack = []
    while stack:
        cls = stack.pop()
        values.append(cls)
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        if cls is SMART_WORKSPACE_PT_always_on:
            continue
        yield cls


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    """No live Panel poll/draw/header/category mutation."""
    return None



def _unpatch_panel_headers():
    _PATCHED_PANELS.clear()
    _PATCHED_POLLS.clear()
    return None



def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _patch_addon_preferences():
    """No live AddonPreferences.draw mutation."""
    return None



def _unpatch_addon_preferences():
    _PATCHED_PREFERENCES.clear()
    return None



def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _is_suite_owned_rna(value) -> bool:
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').casefold()
        prefix = _module_prefix().casefold()
        return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))
    except Exception:
        return False


def _root_prop_name_relevant(name: str) -> bool:
    """Filter root RNA names before dereferencing their values.

    PointerProperty access is not exception-safe while Blender rebuilds the home
    file.  At Scene/WindowManager roots, ownership can be decided from the name
    alone, so never touch unrelated or legacy compatibility pointers first.
    """
    identifier = str(name or '')
    lower = identifier.casefold()
    return bool(
        identifier in _OWN_ROOT_PROPERTY_NAMES
        or any(lower.startswith(prefix.casefold()) for prefix in _OWN_ROOT_PROPERTY_PREFIXES)
    )


def _prop_relevant(name, value, owner=None):
    identifier = str(name or '')
    lower = identifier.casefold()
    if _is_suite_owned_rna(owner):
        # Once a top-level PointerProperty is confirmed to belong to this Suite,
        # every writable child property in that group is part of the same
        # settings graph even when its local name is generic (for example
        # ``enabled`` or ``show_quick``).
        return True
    if identifier in _OWN_ROOT_PROPERTY_NAMES:
        return True
    if any(lower.startswith(prefix.casefold()) for prefix in _OWN_ROOT_PROPERTY_PREFIXES):
        return True
    if _is_suite_owned_rna(value):
        return True
    return False


def _sanitize_loaded_settings(data, context=None):
    """Remove foreign Suite keys from the legacy common-settings sidecar.

    Only the top-level Scene/WindowManager keys require ownership filtering.
    Nested dictionaries below a verified Smart Workspace PropertyGroup are
    retained verbatim and are still validated by RNA when applied.
    """
    if not isinstance(data, dict):
        return {}, True
    ctx = context or getattr(bpy, 'context', None)
    roots = {name: root for name, root in _iter_setting_roots(ctx)}
    cleaned = {}
    changed = False
    for root_name, values in data.items():
        if root_name not in roots or not isinstance(values, dict):
            changed = True
            continue
        root = roots[root_name]
        kept = {}
        for key, stored_value in values.items():
            # Decide root ownership from the identifier before any RNA access.
            # This deliberately drops the obsolete scene.synch_settings sidecar
            # entry and avoids dereferencing stale foreign PointerProperties.
            if not _root_prop_name_relevant(key):
                changed = True
                continue
            current = None
            try:
                current = getattr(root, key)
            except Exception:
                # A missing or temporarily unavailable property cannot be safely
                # restored during this file boundary; keep it out of the sidecar.
                changed = True
                continue
            if _prop_relevant(key, current, root):
                kept[key] = stored_value
            else:
                changed = True
        if kept:
            cleaned[root_name] = kept
        elif values:
            changed = True
    if set(cleaned) != {key for key, value in data.items() if isinstance(value, dict) and value}:
        changed = True
    return cleaned, changed


def flush_sanitized_settings_mirror() -> bool:
    """Publish a one-time legacy-sidecar cleanup after registration guard."""
    global _SANITIZED_SETTINGS_MIRROR_DIRTY
    if not _SANITIZED_SETTINGS_MIRROR_DIRTY:
        return False
    try:
        path = settings_path()
        data = _suite_storage.read_json(path, {})
        if not isinstance(data, dict):
            data = {}
        _suite_storage.mirror_json_file(path, data, force=True)
        _SANITIZED_SETTINGS_MIRROR_DIRTY = False
        return True
    except Exception:
        return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            # At the Scene/WindowManager root, reject unrelated properties by
            # identifier before dereferencing them.  This is both faster and avoids
            # native crashes from stale PointerProperty descriptors during WM_init.
            if depth == 0 and not _is_suite_owned_rna(obj) and not _root_prop_name_relevant(identifier):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS, _SANITIZED_SETTINGS_MIRROR_DIRTY
    path = settings_path()
    try:
        raw = _suite_storage.read_json(path, None)
        if isinstance(raw, dict):
            cleaned, changed = _sanitize_loaded_settings(raw, getattr(bpy, 'context', None))
            _LOADED_SETTINGS = cleaned
            if changed:
                # Rewrite only when legacy foreign keys were actually present.
                # During registration the central mirror is write-guarded; the
                # outer lifecycle flushes this exact sidecar once the guard is
                # released.
                _suite_storage.atomic_write_json(
                    path, cleaned, indent=2, ensure_ascii=False, sort_keys=True
                )
                _SANITIZED_SETTINGS_MIRROR_DIRTY = True
            return cleaned
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False) -> bool:
    global _AUTOSAVE_FINGERPRINT
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
    except Exception:
        return False
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return True
    try:
        path = settings_path()
        ok = bool(_suite_storage.atomic_write_json(
            path,
            data,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
            backup=False,
        ))
        if not ok:
            return False
        # This compact compatibility sidecar includes settings that must persist
        # even when N-panel state snapshots are disabled.  The verified local
        # sidecar is authoritative for these values.  A new profile intentionally
        # has no central N-panel authority yet, so its recovery mirror is best
        # effort and must not turn a successful teardown into a restart request.
        try:
            _suite_storage.mirror_json_file(path, data, force=True)
        except Exception:
            pass
        _AUTOSAVE_FINGERPRINT = raw
        return True
    except Exception:
        return False


def _autosave_timer():
    """Legacy callback retained only so old same-session timers can be removed."""
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register() -> bool:
    """Register common RNA as one exact current-generation transaction."""
    if not _runtime_ledger.current_generation():
        _runtime_ledger.mark_restart_required('COMMON_REGISTER_WITHOUT_GENERATION')
        return False
    newly_registered: list[type] = []
    new_properties: list[tuple[type, str]] = []
    try:
        _unregister_common_translations()
        _register_common_translations()

        owner_type = bpy.types.WindowManager
        descriptor = _rna_property_definition(owner_type, _ALWAYS_ON_PROP)
        if descriptor is None:
            setattr(owner_type, _ALWAYS_ON_PROP, BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
            new_properties.append((owner_type, _ALWAYS_ON_PROP))
            if not _runtime_ledger.record_scalar_property(
                owner_type,
                _ALWAYS_ON_PROP,
                _COMMON_ALWAYS_ON_PROPERTY_OWNER,
                remover=None,
                newly_registered=True,
            ):
                raise RuntimeError('Common Always-on property ownership ledger failed')
        elif not _runtime_ledger.scalar_property_is_current(
            owner_type, _ALWAYS_ON_PROP, _COMMON_ALWAYS_ON_PROPERTY_OWNER
        ):
            _runtime_ledger.mark_restart_required('COMMON_ALWAYS_ON_PROPERTY_IDENTITY_MISMATCH')
            raise RuntimeError('RESTART_REQUIRED: Common Always-on property identity mismatch')

        for cls in (SMART_WORKSPACE_OT_open_help, SMART_WORKSPACE_OT_set_always_on, SMART_WORKSPACE_OT_save_preferences):
            _materialize_annotations(cls)
            success, was_new = _runtime_ledger.register_class_exact(
                cls,
                native_register=bpy.utils.register_class,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='COMMON_CLASS',
            )
            if not success:
                raise RuntimeError(f'RESTART_REQUIRED: common class identity mismatch {cls.__name__}')
            if was_new:
                newly_registered.append(cls)
            _remember_registered_class(cls)

        if load_settings_file() is False:
            # Missing optional sidecar is not fatal; malformed/failed authority is
            # handled by the strict canonical N-panel transaction.
            pass
        try:
            apply_persistent_settings(bpy.context)
        except Exception:
            pass
        _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
        try:
            timers = getattr(bpy.app, 'timers', None)
            if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
                timers.unregister(_autosave_timer)
        except Exception:
            pass
        return True
    except Exception:
        _runtime_ledger.rollback_new_items(newly_registered, new_properties)
        for cls in newly_registered:
            while cls in _REGISTERED_CLASSES:
                _REGISTERED_CLASSES.remove(cls)
        raise

    # Registered Panel/AddonPreferences classes are never patched in-place.


def unregister() -> bool:
    """Flush and release only exact common RNA owned by this generation."""
    success = True
    try:
        if save_persistent_settings(bpy.context, force=True) is False:
            success = False
    except Exception:
        success = False
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        success = False
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)

    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        if not _runtime_ledger.class_recorded_current(cls):
            success = False
            continue
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='COMMON_CLASS',
        ):
            success = False
    _REGISTERED_CLASSES.clear()

    owner_type = bpy.types.WindowManager
    descriptor = _rna_property_definition(owner_type, _ALWAYS_ON_PROP)
    if descriptor is not None:
        if _runtime_ledger.scalar_property_is_current(
            owner_type, _ALWAYS_ON_PROP, _COMMON_ALWAYS_ON_PROPERTY_OWNER
        ):
            try:
                delattr(owner_type, _ALWAYS_ON_PROP)
                if _rna_property_definition(owner_type, _ALWAYS_ON_PROP) is None:
                    record = _runtime_ledger.active_record()
                    if isinstance(record, dict):
                        properties = record.get("properties")
                        if isinstance(properties, dict):
                            properties.pop(f"{id(owner_type)}:{_ALWAYS_ON_PROP}", None)
            except Exception:
                success = False
        else:
            _runtime_ledger.mark_restart_required('COMMON_ALWAYS_ON_PROPERTY_TEARDOWN_IDENTITY_MISMATCH')
            success = False
    _remove_previews()
    _unregister_common_translations()
    end_register()
    return bool(success)
