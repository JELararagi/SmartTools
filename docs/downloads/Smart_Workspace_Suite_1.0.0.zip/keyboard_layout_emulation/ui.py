# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations
import time
from typing import List, Dict

import bpy
from ..translation import localized_layout
from .. import ui_icons
# noinspection PyUnresolvedReferences
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup

from .keyboard_layout import is_built_in_layout
from .preferences import kle_prefs, KLEPreferencesUnavailableException, _is_integrated_mode
from .operators import KLEOperators
from .constants import KLELinks

# Layout used to render a keyboard-like button grid
from sys import platform
KEYBOARD_EDITOR_LAYOUT: List[List[Dict[str, object]]] = [
    # Function row
        # While this row may only waste space, it helps make the keyboard
        # editor recognizable as a keyboard
        # In the future, we could make function keys remappable, though
        [{"label": "Esc", "w": 1.2}] +
        [{"label": f"F{i}"} for i in range(1, 13)],
    # Number row
        [{"ch": "`", "w": 1.0}] +
        [{"ch": c} for c in "1234567890-="] +
        [{"label": "Backspace", "w": 2.0}],
    # First row
        [{"label": "Tab", "w": 1.5}] +
        [{"ch": c} for c in "QWERTYUIOP[]"] +
        [{"ch": "\\", "w": 1.5}],
    # Second row
        [{"label": "Caps", "w": 1.9}] +
        [{"ch": c} for c in "ASDFGHJKL;\""] +
        [{"label": "Enter", "w": 2.2}],
    # Third row
        [{"label": "Shift", "w": 1.6}] +
        [{"ch": c} for c in "<ZXCVBNM,./"] +
        [{"label": "Shift", "w": 3.1}],
    # Modifier row
        # While this row may only waste space, it does great work at
        # making the keyboard editor recognizable as a keyboard
        [
            {"label": "Control"},
            {"label": "Option"},
            {"label": "Command"},
            {"label": "Space", "w": 5.0},
            {"label": "Command"},
            {"label": "Option"},
        ] if platform == 'darwin' else [
            {"label": "Ctrl"},
            {"label": "Win"},
            {"label": "Alt"},
            {"label": "Space", "w": 3.6},
            {"label": "Alt"},
            {"label": "Menu"},
            {"label": "Win"},
            {"label": "Ctrl"},
        ] if platform.startswith('win') else [
            {"label": "Ctrl"},
            {"label": "OS"},
            {"label": "Alt"},
            {"label": "Space", "w": 3.6},
            {"label": "Alt"},
            {"label": "Menu"},
            {"label": "OS"},
            {"label": "Ctrl"},
        ],
]



def _suite_always_on_enabled(action: str, default: bool = False) -> bool:
    if not _is_integrated_mode():
        return bool(default)
    try:
        from .. import ui_runtime as _suite_ui_runtime
        remembered = getattr(_suite_ui_runtime, '_remembered_always_state', None)
        if callable(remembered):
            return bool(remembered(action, default))
    except Exception:
        pass
    return bool(default)

# Transient state to conflate reapply requests
_keymap_prefs_reapply_requested = False

def reapply_from_keymap_prefs():
    global _keymap_prefs_reapply_requested
    from .event_handlers import on_reapply_requested
    on_reapply_requested()
    _keymap_prefs_reapply_requested = False


def draw_in_keymap_reapply_probe(self, context):
    """Hidden integrated-mode Keymap Preferences probe.

    It performs only the automatic reapply check and deliberately draws no UI,
    keeping all user-facing controls inside the Smart Workspace N-panel.
    """
    del self, context
    # Compatibility hook only. Reapply detection is owned by the corresponding
    # Always-on timer and never scheduled from a Preferences draw callback.
    return None

def draw_in_keymap_prefs(self, context):
    """
    Prepended block shown inside Keymap preferences panel.
    """
    global _keymap_prefs_reapply_requested

    prefs = kle_prefs(context)
    ui_state = prefs.ui_state(context)

    ui_layout = localized_layout(self.layout, context)
    box = ui_layout.box()
    col = box.column(align=True)

    target_layout_name = prefs.preferred_target_layout
    layout_name = prefs.preferred_input_layout
    if layout_name is None:
        layout_name = 'QWERTY'
    is_built_in = is_built_in_layout(layout_name)
    is_emulation_active = prefs.is_emulation_active
    input_layout_mapping = prefs.get_layout_translation(layout_name)
    target_layout_mapping = prefs.get_layout_translation(target_layout_name)

    split = col.split(factor=0.60, align=False)
    left = split.row(align=True)
    right = split.row(align=True)
    hide_always_toggles = bool(globals().get('_SMART_WORKSPACE_HIDE_ALWAYS_TOGGLES', False))

    # Left: dropdown + +/- + edit toggle
    # Layout selector disabled when a keymap has this layout applied
    li = left.row(align=False)
    if is_emulation_active:
        ui_icons.set_large_icon_scale(li, 1.2)
        ui_icons.operator(li, KLEOperators.Info.layout_locked, text="", name='lock', fallback='LOCKED', emboss=False)
    else:
        ui_icons.set_large_icon_scale(li, 1.2)
        ui_icons.operator(li, KLEOperators.Info.layout_unlocked, text="", name='unlock', fallback='UNLOCKED', emboss=False)
    lr = left.row(align=True)
    lr.enabled = True
    split = lr.split(factor=0.30, align=True)
    lr_target, lr_input = split.row(align=False), split.row(align=True)
    lr_target.enabled = True
    if not target_layout_mapping.is_valid():
        lr_target.alert = True
    lr_target.prop(ui_state, "current_target_layout", text="")

    icon_row = lr_input.row(align=False)
    ui_icons.label(icon_row, text="", name='left', fallback='BACK')
    lr_input.prop(ui_state, "current_input_layout", text="")
    er = left.row(align=True)
    if not input_layout_mapping.is_valid() and not prefs.allow_key_conflicts_in_input_layout:
        er.alert = True
    ui_icons.prop(
        er, ui_state, "show_keyboard_layout_editor",
        toggle=True, text="", name='settings', fallback='GREASEPENCIL',
    )

    # Right: Apply / Revert, right-aligned
    # In Smart Workspace N-panel integration, these persistent apply/revert
    # controls are centralized in the top Always-on Toggles group.
    # right.alignment = 'RIGHT'
    is_emulation_active = prefs.is_emulation_active
    has_pending_keymaps_to_apply = prefs.has_pending_keymaps_to_emulate()
    if not hide_always_toggles:
        ar = right.row(align=True)
        label = "Apply"
        if is_emulation_active and has_pending_keymaps_to_apply:
            # label = "Re-Apply?"
            bound = 99
            pending_number = prefs.bounded_number_of_pending_keymaps_to_emulate(bound)
            label = f"Re-Apply ({pending_number if pending_number is not None else str(bound) + '+'})"
        ar.enabled = True
        ui_icons.operator(ar, KLEOperators.apply_layout_emulation, text=label, name='keyboard', fallback='ANIM')
        rr = right.row(align=True)
        rr.enabled = True
        # if is_emulation_active:
        #     rr.alert = True
        ui_icons.operator(
            rr, KLEOperators.revert_layout_emulation, text="Revert", name='repair', fallback='LOOP_BACK'
        ).request_confirmation = False
        right.separator()
    sr = right.row(align=False)
    ui_icons.prop(
        sr, ui_state, "show_keyboard_layout_emulation_preferences",
        toggle=True, text="", name='settings', fallback='PREFERENCES',
    )

    # Add-on preferences
    if ui_state.show_keyboard_layout_emulation_preferences:
        col.separator()
        sub = col.box()
        header = sub.row()
        header.label(text="Keyboard layout emulation preferences")
        header_right = header.row(align=False)
        header_right.alignment = 'RIGHT'
        ui_icons.operator(header_right, KLEOperators.Info.addon_info, text="More info", name='help', fallback='QUESTION', emboss=False)
        ui_icons.set_large_icon_scale(header_right, 1.2)
        ui_icons.operator(header_right, "wm.url_open", text="", name='help', fallback='QUESTION', emboss=False).url = KLELinks.help
        row = sub.column(align=False)
        split = row.split(factor=0.52, align=False)
        left, right = split.column(align=False), split.column(align=False)
        split = left.column(align=False).split(factor=0.98, align=False)
        left, _ = split.column(align=False), split.column(align=False)
        row = left.row(align=True)
        row.enabled = True
        row.prop(prefs, "allow_non_qwerty_target_layouts")
        split = left.row().split(factor=0.35, align=False)
        left_l, left_r = split.row(align=False), split.row(align=False)
        left_l.prop(prefs, "show_warning_banner", text="Warning button")
        left_r.enabled = True
        split = left_r.split(factor=0.4, align=False)
        left_r_l, left_r_r = split.row(align=False), split.row(align=False)
        left_r_l.prop(prefs, "large_warning_button_height", text="Size")
        left_r_r.prop(prefs, "large_warning_button_style", expand=True)
        if not hide_always_toggles:
            split = left.row(align=True).split(factor=0.35, align=False)
            left_l, left_r = split.row(align=True), split.row(align=True)
            left_l.prop(prefs, "logging_enabled", text="Logging")
            left_r.enabled = True
            left_r.prop(prefs, "logging_level", expand=True)

            split = right.row().split(factor=0.65, align=True)
            right_l, right_r = split.column(align=True), split.column(align=True)
            right_l.prop(prefs, "reapply_on_keymaps_panel", text="Reapply automatically here")
            right_r.enabled = True
            right_r.prop(prefs, "reapply_on_keymaps_panel_delay", text="Delay")
            split = right.row().split(factor=0.65, align=True)
            right_l, right_r = split.column(align=True), split.column(align=True)
            right_l.prop(prefs, "reapply_on_reload", text="Reapply emulation on restart")
            right_r.enabled = True
            right_r.prop(prefs, "reapply_on_reload_delay", text="Delay")
            split = right.row().split(factor=0.65, align=True)
            right_l, right_r = split.column(align=True), split.column(align=True)
            right_l.prop(prefs, "detect_addon_changes", text="Detect add-on installation")
            right_r.enabled = True
            right_r.prop(prefs, "detect_addon_changes_polling_interval", text="Interval")


    # Subpanel for editing the selected input keyboard layout
    if ui_state.show_keyboard_layout_editor:
        is_layout_editable = not is_emulation_active and not is_built_in
        listening_key = ui_state.listening_key

        col.separator()
        sub = col.box()
        header = sub.row()
        split = header.split(factor=0.6, align=False)
        left = split.row(align=True)
        right = split.row(align=True)

        icon = 'UNLOCKED' if is_layout_editable else 'LOCKED'
        if is_built_in:
            msg = f"Built-in layout is read-only: {layout_name}"
        elif is_emulation_active:
            msg = f"Revert emulation to edit this layout."
        elif listening_key:
            msg = f"Press the key [{listening_key}] should correspond to... (Esc/click to cancel)"
        else:
            msg = f"Edit layout: {layout_name}"
        ui_icons.label(left, text=msg, name='unlock' if is_layout_editable else 'lock', fallback=icon)
        right.alignment = 'RIGHT'

        # Load conflicting keys from input keyboard layout
        conflicting_keys = input_layout_mapping.conflicting_keys()
        conflicting_keys = set(conflicting_keys) if conflicting_keys else set()

        # Draw each display row with optimized recursive splitting
        for keys in KEYBOARD_EDITOR_LAYOUT:
            r = sub.row(align=True)
            if not is_layout_editable:
                r.enabled = True

            # Precompute cumulative weights for efficient drawing
            cumulative_weights = [0.0]
            running_sum = 0.0
            for k in keys:
                w = k.get('w', 1.0)
                running_sum += w
                cumulative_weights.append(running_sum)

            total_weight = cumulative_weights[-1] if cumulative_weights else 0.0

            # Recursive function to draw keys with minimal splits
            def draw_keys_recursive(
                    parent_layout, start_idx: int, end_idx: int, start_weight: float, end_weight: float):
                if start_idx >= end_idx:
                    return

                if end_idx - start_idx == 1:
                    # Draw single key
                    k = keys[start_idx]
                    if isinstance(k, dict):
                        if 'ch' in k:
                            qw_ch = str(k.get("ch", ""))
                            if qw_ch:
                                is_listening = ui_state.listening_key == qw_ch
                                ch = input_layout_mapping.map_input_to_output(qw_ch)
                                label = '...' if is_listening else ch
                                red = ch in conflicting_keys and not is_listening
                                if red:
                                    parent_layout.alert = True
                                    # label = f'[{label}]'
                                op = parent_layout.operator(
                                    KLEOperators.capture_key_for_mapping,
                                    text=label,
                                    depress=is_listening,
                                )
                                op.physical = qw_ch
                                op.layout = layout_name
                        else:
                            # Non-editable key: render grayed-out button for context
                            parent_layout.enabled = True
                            label = str(k.get("label", ""))
                            parent_layout.operator(KLEOperators.Info.non_editable_key, text=label)
                else:
                    # Split in half
                    split_idx = (start_idx + end_idx) // 2
                    range_weight = end_weight - start_weight
                    split_weight = cumulative_weights[split_idx]

                    left_weight = split_weight - start_weight
                    factor = left_weight / range_weight

                    # Create split with the correct factor
                    split_layout = parent_layout.split(factor=factor)  # align=True
                    left_row = split_layout.row(align=True)
                    right_row = split_layout.row(align=True)

                    # Recursively draw each half
                    draw_keys_recursive(left_row, start_idx, split_idx, start_weight, split_weight)
                    draw_keys_recursive(right_row, split_idx, end_idx, split_weight, end_weight)

            # Start recursive drawing
            if keys:
                draw_keys_recursive(r, 0, len(keys), 0.0, total_weight)

        if conflicting_keys:
            row = sub.row()
            if not prefs.allow_key_conflicts_in_input_layout:
                row.alert = True
            split = row.split(factor=0.65, align=False)
            left, right = split.row(align=True), split.row(align=True)
            left.label(text=f"Conflicting physical keys: {', '.join(conflicting_keys)}", icon='ERROR')
            right.alignment = 'RIGHT'
            right.prop(prefs, "allow_key_conflicts_in_input_layout", text="Allow conflicts")

    if (not hide_always_toggles) and prefs.is_emulation_active and prefs.show_warning_banner:
        row = ui_layout.row(align=True)
        row.scale_y = prefs.large_warning_button_height
        button_row = row.row(align=True)
        if prefs.large_warning_button_style == 'RED':
            button_row.alert = True
        button_row.operator(
            KLEOperators.revert_layout_emulation,
            text="Keyboard layout emulation is active. Consider reverting it before editing keymaps.",
            icon='ERROR', depress=prefs.large_warning_button_style == 'BLUE',
        ).request_confirmation = True
        ui_icons.prop(
            row, prefs, 'show_warning_banner',
            text="",
            invert_checkbox=True,
            name='close', fallback='PANEL_CLOSE',
        )

# State variables for deferred add-on list polling
_last_addons_prefs_draw_time = 0.0
_last_addons_prefs_poll_time = 0.0
_last_active_addons_set = set()
_addon_check_scheduled = False

def draw_in_addons_prefs(self, context):
    """
    Prepended block shown in the add-ons preferences panel.

    We do not show any UI, this draw code is simply installed to get draw updates
    from the add-ons panel.
    """
    on_addon_menu_draw_call(context)

def draw_in_extensions_prefs(self, context):
    """
    Prepended block shown in the extensions preferences panel.

    We do not show any UI, this draw code is simply installed to get draw updates
    from the extensions panel.
    """
    on_addon_menu_draw_call(context)

def on_addon_menu_draw_call(context):
    del context
    # Compatibility hook only. Add-on change polling is registered and removed
    # at the Always-on/lifecycle boundary, never by Preferences drawing.
    return None

def scheduled_addon_changes_poll():
    global _addon_check_scheduled, _last_addons_prefs_draw_time, _last_addons_prefs_poll_time
    try:
        # logger = kle_logger()
        # if logger:
        #    logger.debug(f"... scheduled poll: {_last_addons_prefs_poll_time} [{_last_addons_prefs_draw_time}]")
        if _last_addons_prefs_poll_time < _last_addons_prefs_draw_time:
            prefs = kle_prefs()
            # Re-register timer
            bpy.app.timers.register(scheduled_addon_changes_poll, first_interval=prefs.detect_addon_changes_polling_interval)
            _last_addons_prefs_poll_time = time.time()
            # if logger:
            #     logger.debug(f"    re-registered")
        else:
            _addon_check_scheduled = False
            # if logger:
            #     logger.debug(f"    last")
        addon_changes_poll()
    except KLEPreferencesUnavailableException:
        # Handler triggered after add-on was uninstalled, skip
        # # kle_logger().debug("! Skipped add-on changes poll, add-on preferences unavailable. Add-on was likely disabled/uninstalled.")
        # If the preferences are not available, the logger is neither
        # print("! Skipped add-on changes poll, add-on preferences unavailable. Add-on was likely disabled/uninstalled.")
        return

def get_current_set_of_addons(context=...) -> set[str]:
    if context is ...:
        context = bpy.context
    return {addon.module for addon in context.preferences.addons}

def addon_changes_poll():
    global _last_active_addons_set
    current_addons = get_current_set_of_addons()
    # logger = kle_logger()
    # if logger:
    #     logger.debug(f"... ! poll")

    # This should only occur on the first poll
    if not _last_active_addons_set:
        _last_active_addons_set = current_addons
        # if logger:
        #     logger.debug(f"    first poll, skipped")
    elif _last_active_addons_set != current_addons:
        _last_active_addons_set = current_addons
        # if logger:
        #     logger.debug(f"    active addons changed, re-running event handlers")
        from .event_handlers import on_addons_set_change
        on_addons_set_change()
    else:
        # if logger:
        #     logger.debug(f"    no change")
        pass


_addons_draw_hook_installed = False
_keymap_draw_hook_installed = False
_integrated_keymap_probe_installed = False
_runtime_poll_timer_registered = False


def _runtime_poll_tick():
    """Poll only while one of the two explicit keyboard-layout toggles is ON."""
    global _runtime_poll_timer_registered, _keymap_prefs_reapply_requested, _last_addons_prefs_poll_time
    try:
        prefs = kle_prefs()
        keymap_needed = bool(prefs.is_emulation_active and prefs.reapply_on_keymaps_panel)
        addon_needed = bool(prefs.is_emulation_active and prefs.detect_addon_changes)
    except Exception:
        keymap_needed = _suite_always_on_enabled('kle_reapply_keymap_panel', False)
        addon_needed = _suite_always_on_enabled('kle_detect_addon_changes', False)
        prefs = None
    if not keymap_needed and not addon_needed:
        _runtime_poll_timer_registered = False
        return None
    if keymap_needed and prefs is not None:
        try:
            pending = bool(prefs.has_pending_keymaps_to_emulate())
            if pending and not _keymap_prefs_reapply_requested:
                _keymap_prefs_reapply_requested = True
                reapply_from_keymap_prefs()
            elif not pending:
                _keymap_prefs_reapply_requested = False
        except Exception:
            pass
    interval = 0.5
    if addon_needed:
        try:
            configured = max(0.1, float(getattr(prefs, 'detect_addon_changes_polling_interval', 0.5) or 0.5))
            now = time.monotonic()
            if now - float(_last_addons_prefs_poll_time or 0.0) >= configured:
                addon_changes_poll()
                _last_addons_prefs_poll_time = now
            interval = min(interval, configured)
        except Exception:
            pass
    return max(0.1, interval)


def _sync_runtime_poll_timer(context=...) -> None:
    global _runtime_poll_timer_registered
    if context is ...:
        context = bpy.context
    try:
        prefs = kle_prefs(context)
        needed = bool(
            prefs.is_emulation_active
            and (prefs.reapply_on_keymaps_panel or prefs.detect_addon_changes)
        )
    except Exception:
        needed = bool(
            _suite_always_on_enabled('kle_reapply_keymap_panel', False)
            or _suite_always_on_enabled('kle_detect_addon_changes', False)
        )
    try:
        registered = bool(bpy.app.timers.is_registered(_runtime_poll_tick))
    except Exception:
        registered = _runtime_poll_timer_registered
    if needed and not registered:
        try:
            bpy.app.timers.register(_runtime_poll_tick, first_interval=0.1)
            _runtime_poll_timer_registered = True
        except Exception:
            _runtime_poll_timer_registered = False
    elif not needed and registered:
        try:
            bpy.app.timers.unregister(_runtime_poll_tick)
        except Exception:
            pass
        _runtime_poll_timer_registered = False

def on_detect_addons_changes_update(context=...):
    _sync_runtime_poll_timer(context)


def append_addons_menu_draw_hooks():
    try:
        bpy.types.USERPREF_PT_addons.prepend(draw_in_addons_prefs)
    except Exception:
        pass
    try:
        bpy.types.USERPREF_PT_extensions.prepend(draw_in_extensions_prefs)
    except Exception:
        pass
    # logger = kle_logger()
    # if logger:
    #     logger.debug(f"! Installed addons draw hook")

def remove_addons_menu_draw_hooks():
    try:
        bpy.types.USERPREF_PT_addons.remove(draw_in_addons_prefs)
    except Exception:
        pass
    try:
        bpy.types.USERPREF_PT_extensions.remove(draw_in_extensions_prefs)
    except Exception:
        pass
    # logger = kle_logger()
    # if logger:
    #     logger.debug(f"! Removed addons draw hook")



def _set_integrated_keymap_probe_enabled(enabled: bool) -> None:
    global _integrated_keymap_probe_installed
    try:
        if _integrated_keymap_probe_installed:
            try:
                bpy.types.USERPREF_PT_keymap.remove(draw_in_keymap_reapply_probe)
            except Exception:
                pass
            _integrated_keymap_probe_installed = False
    except Exception:
        _integrated_keymap_probe_installed = False


def sync_integrated_runtime_hooks(context=...) -> None:
    """Install or remove hidden integrated runtime probes.

    These hooks contain no Preferences UI. They only provide the background
    behavior requested by the centralized always-on toggles.
    """
    global _addons_draw_hook_installed
    if not _is_integrated_mode():
        return
    if context is ...:
        context = bpy.context
    try:
        prefs = kle_prefs(context)
        keymap_needed = bool(prefs.is_emulation_active and prefs.reapply_on_keymaps_panel)
        addon_needed = bool(prefs.is_emulation_active and prefs.detect_addon_changes)
    except Exception:
        keymap_needed = _suite_always_on_enabled('kle_reapply_keymap_panel', False)
        addon_needed = _suite_always_on_enabled('kle_detect_addon_changes', False)
    _set_integrated_keymap_probe_enabled(False)
    if _addons_draw_hook_installed:
        remove_addons_menu_draw_hooks()
        _addons_draw_hook_installed = False
    _sync_runtime_poll_timer(context)


def register():
    global _addons_draw_hook_installed, _keymap_draw_hook_installed

    # In integrated Smart Workspace mode, all settings UI must remain in the
    # N-panel.  Skipping Preferences/Keymap hooks also prevents duplicate draw
    # callbacks after hot reloads.
    if _is_integrated_mode():
        _keymap_draw_hook_installed = False
        sync_integrated_runtime_hooks(context=bpy.context)
        return

    if not _keymap_draw_hook_installed:
        try:
            bpy.types.USERPREF_PT_keymap.prepend(draw_in_keymap_prefs)
            _keymap_draw_hook_installed = True
        except Exception:
            _keymap_draw_hook_installed = False

    # Deferred registration to ensure preferences are loaded.
    try:
        bpy.app.timers.register(on_detect_addons_changes_update, first_interval=1)
    except Exception:
        pass

def unregister():
    global _addons_draw_hook_installed, _keymap_draw_hook_installed, _runtime_poll_timer_registered

    try:
        if bpy.app.timers.is_registered(_runtime_poll_tick):
            bpy.app.timers.unregister(_runtime_poll_tick)
    except Exception:
        pass
    _runtime_poll_timer_registered = False

    try:
        _set_integrated_keymap_probe_enabled(False)
    except Exception:
        pass

    if _keymap_draw_hook_installed:
        try:
            bpy.types.USERPREF_PT_keymap.remove(draw_in_keymap_prefs)
        except Exception:
            pass
        _keymap_draw_hook_installed = False

    if _addons_draw_hook_installed:
        try:
            remove_addons_menu_draw_hooks()
        except Exception:
            pass
        _addons_draw_hook_installed = False
