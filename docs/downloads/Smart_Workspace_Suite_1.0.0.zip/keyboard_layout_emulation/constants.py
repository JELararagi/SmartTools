# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import logging


__all__ = [
    'addon_id',
    'preferences_version',
    'KLEOperators',
    'KLELinks',
]


addon_id = __package__
preferences_version = (1, 1)


class KLEOperators:
    """Operator IDs"""
    apply_layout_emulation = "wm.kle_apply_layout_emulation"  # WM_OT_kle_apply_layout_emulation
    revert_layout_emulation = "wm.kle_revert_layout_emulation"  # WM_OT_kle_revert_layout_emulation
    export_addon_preferences = "wm.kle_export_addon_preferences"  # WM_OT_kle_export_addon_preferences
    import_addon_preferences = "wm.kle_import_addon_preferences"  # WM_OT_kle_import_addon_preferences
    capture_key_for_mapping = "wm.kle_capture_key_for_mapping"  # WM_OT_kle_capture_key_for_mapping
    debug_toggle_expanded_subkey = "wm.kle_debug_toggle_expanded_subkey"  # WM_OT_kle_debug_toggle_expanded_subkey

    class Info:
        """No-op operators used only to display tooltips."""
        non_editable_key = "wm.kle_non_editable_key"  # WM_OT_kle_non_editable_key
        layout_unlocked = "wm.kle_layout_unlocked_info"  # WM_OT_kle_layout_unlocked_info
        layout_locked = "wm.kle_layout_locked_info"  # WM_OT_kle_layout_locked_info
        addon_info = "wm.kle_addon_info"  # WM_OT_kle_addon_info


class KLELinks:
    source = "https://github.com/endorh/blender-keyboard-layout-emulation/"
    help = "https://endorh.github.io/blender-keyboard-layout-emulation/"
