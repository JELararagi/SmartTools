# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Apply and restore transaction records for keyboard layout emulation."""

from copy import deepcopy

import bpy

from .keyboard_layout import char_to_event_type, event_type_to_char
from .preferences import (
    KmiAssignmentDiff, KmiFingerprint, get_current_keyconfig_set,
    keymap_id, kle_prefs, kmi_modifier_string,
)


def reapply_keymap_translation(translation, context=...):
    context = bpy.context if context is ... else context
    prefs = kle_prefs(context)
    logger = prefs.logger
    if not translation.is_valid() and not prefs.allow_key_conflicts_in_input_layout:
        text = "Layout mapping is invalid. Fix errors before applying."
        if logger:
            logger.warning(text)
        return False, text

    original_journal = prefs.remapped_keys_json
    journal = deepcopy(prefs.remapped_keys)
    edits = []
    try:
        for keymap, item, fingerprint, prior in prefs.pending_keymaps_to_emulate(context):
            old = item.type
            new = translation.map_input_type_to_output_type(old)
            if new == old:
                continue
            before = None
            records = journal.setdefault(keymap_id(keymap), {}).setdefault(item.idname, [])
            replacement = KmiAssignmentDiff.from_kmi_and_types(item, old, new)
            if prior is None:
                index = len(records)
                entry = KmiFingerprint.from_kmi(item, logger=logger), replacement
                records.append(entry)
            else:
                index = next(i for i, record in enumerate(records) if record == (fingerprint, prior))
                before = records[index]
                records[index] = fingerprint, replacement
            edits.append((item, old, new, records, index, before))
    except (AttributeError, TypeError, ValueError, RuntimeError, StopIteration) as exc:
        return False, f"Could not prepare layout emulation: {exc}"

    if not edits:
        return True, "Remapped correctly 0 keymap items!"
    # Save the recovery data before modifying Blender's user keymap.
    prefs.remapped_keys = journal
    attempted = 0
    try:
        for item, old, new, records, index, before in edits:
            attempted += 1
            item.type = new
    except (ReferenceError, TypeError, ValueError, RuntimeError) as exc:
        failed = set()
        for number in range(attempted - 1, -1, -1):
            item, old, new, records, index, before = edits[number]
            try:
                if item.type != old:
                    item.type = old
            except (ReferenceError, TypeError, ValueError, RuntimeError):
                failed.add(number)
        if failed:
            for number in range(len(edits) - 1, -1, -1):
                if number in failed:
                    continue
                _, _, _, records, index, before = edits[number]
                if before is None:
                    records.pop(index)
                else:
                    records[index] = before
            remaining = {
                name: {op: rows for op, rows in operators.items() if rows}
                for name, operators in journal.items() if any(operators.values())
            }
            prefs.remapped_keys = remaining
        else:
            prefs.remapped_keys_json = original_journal
        text = f"Failed to remap keymap items: {exc}"
        if failed:
            text += f" Saved recovery journal for {len(failed)} shortcuts."
        if logger:
            logger.warning(text)
        return False, text

    text = f"Remapped correctly {len(edits)} keymap items!"
    if logger:
        logger.info(text)
    return True, text


def revert_keymap_translation(context=...):
    if context is ...:
        context = bpy.context
    prefs = kle_prefs(context)
    logger = prefs.logger

    pending = {
        map_id: {operator: list(rows) for operator, rows in operators.items() if rows}
        for map_id, operators in prefs.remapped_keys.items()
    }
    restored = 0
    for keymap in get_current_keyconfig_set(context).user.keymaps:
        operators = pending.get(keymap_id(keymap))
        if not operators:
            continue

        for item in keymap.keymap_items:
            rows = operators.get(item.idname)
            if not rows or item.map_type != 'KEYBOARD':
                continue
            target = event_type_to_char(item.type)
            modifiers = kmi_modifier_string(item)
            candidates = [
                index
                for index, (_, assignment) in enumerate(rows)
                if assignment.target_char == target
                and assignment.modifiers == modifiers
                and assignment.value == item.value
            ]
            if not candidates:
                continue
            identity = KmiFingerprint.from_kmi(item, logger=logger)
            matches = [index for index in candidates if rows[index][0] == identity]
            sources = {rows[index][1].source_char for index in matches}
            if len(sources) != 1:
                continue
            source = sources.pop()
            if not source:
                continue
            try:
                item.type = char_to_event_type(source)
            except (TypeError, ValueError, ReferenceError, RuntimeError) as exc:
                if logger:
                    logger.warning("Could not restore %s in %s: %s", item.idname, keymap.name, exc)
                continue
            rows.pop(matches[0])
            restored += 1

    unresolved = {}
    for map_id, operators in pending.items():
        remaining = {operator: rows for operator, rows in operators.items() if rows}
        if remaining:
            unresolved[map_id] = remaining
    prefs.remapped_keys = unresolved or None

    remaining_count = sum(len(rows) for operators in unresolved.values() for rows in operators.values())
    if remaining_count:
        message = (
            f"Restored {restored} shortcuts. {remaining_count} could not be restored. "
            "Restore the missing shortcuts to their emulated keys and retry."
        )
        if logger:
            logger.warning(message)
        return False, message

    message = f"Reverted correctly {restored} items from keyboard layout emulation!"
    if logger:
        logger.info(message)
    return True, message
