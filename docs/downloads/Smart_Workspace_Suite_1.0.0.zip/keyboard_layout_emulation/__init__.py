# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Register the optional shortcut layout tools in dependency order."""

from . import constants, event_handlers, operators, preferences, ui

bl_info = {
    "name": "Keyboard Layout Emulation",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "Preferences > Keymap",
    "description": "Use familiar Blender shortcuts with a different keyboard layout.",
    "category": "System",
}

__all__ = ["register", "unregister", "constants", "preferences", "operators", "ui", "event_handlers"]
registered_modules = (preferences, operators, ui, event_handlers)
_owned = []


def register():
    if _owned:
        return
    try:
        for module in registered_modules:
            _owned.append(module)
            module.register()
    except Exception:
        unregister()
        raise


def unregister():
    while _owned:
        module = _owned.pop()
        try:
            module.unregister()
        except Exception:
            # Finish unregistering the remaining RNA even after a partial setup.
            continue
