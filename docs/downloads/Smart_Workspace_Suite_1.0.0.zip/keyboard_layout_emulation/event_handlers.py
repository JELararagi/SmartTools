# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Run keyboard layout updates only while the corresponding setting is enabled."""

import bpy
from bpy.app.handlers import persistent

from .keymap_patch import reapply_keymap_translation, revert_keymap_translation
from .preferences import KLEPreferencesUnavailableException, _is_integrated_mode, kle_prefs

_pending = set()


def _preferences(context):
    try:
        return kle_prefs(context)
    except (AttributeError, KLEPreferencesUnavailableException, ReferenceError):
        return None


def _allowed_on_reload(default=False):
    if not _is_integrated_mode():
        return True
    from .. import ui_runtime

    return bool(ui_runtime._remembered_always_state("kle_reapply_reload", default))


def _set_handlers(enabled):
    for callbacks in (bpy.app.handlers.load_post, bpy.app.handlers.load_post_fail):
        if enabled and on_load_post not in callbacks:
            callbacks.append(on_load_post)
        while not enabled and on_load_post in callbacks:
            callbacks.remove(on_load_post)


def _clear_timers():
    for callback in tuple(_pending):
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _pending.clear()


def sync_integrated_runtime_hooks(context=...):
    if _is_integrated_mode():
        prefs = _preferences(context)
        enabled = (_allowed_on_reload() if prefs is None else
                   bool(prefs.is_emulation_active and prefs.reapply_on_reload))
        _set_handlers(enabled)
        if not enabled:
            _clear_timers()


def maybe_reapply_translation_deferred(context=..., *, for_reload=True):
    if not _allowed_on_reload():
        return
    prefs = _preferences(context)
    if prefs is None or not (prefs.is_emulation_active and prefs.reapply_on_reload):
        return

    def add_timer(delay):
        def update():
            _pending.discard(update)
            if _allowed_on_reload():
                maybe_reapply_translation(for_reload=for_reload)
            return None

        _pending.add(update)
        bpy.app.timers.register(update, first_interval=delay)

    add_timer(0)
    if prefs.reapply_on_reload_delay > 0:
        add_timer(prefs.reapply_on_reload_delay)


def _log(prefs, operation, result):
    if prefs.logger:
        success, message = result
        log = prefs.logger.info if success else prefs.logger.warning
        log("%s: %s", operation, message)


def maybe_reapply_translation(context=..., *, for_reload=True):
    prefs = _preferences(context)
    if prefs is None or not prefs.is_emulation_active or (for_reload and not prefs.reapply_on_reload):
        return
    translation = prefs.get_preferred_layout_translation()
    _log(prefs, "Keyboard layout update", reapply_keymap_translation(translation, context))


def maybe_revert_translation_on_uninstall(context=...):
    prefs = _preferences(context)
    if prefs is not None and prefs.is_emulation_active and prefs.ui_state(context).revert_on_uninstall:
        _log(prefs, "Keyboard layout restored", revert_keymap_translation(context))


def on_addons_set_change():
    maybe_reapply_translation_deferred(for_reload=False)


def on_reapply_requested():
    maybe_reapply_translation(for_reload=False)


@persistent
def on_load_post(*_args, **_kwargs):
    maybe_reapply_translation_deferred()


def register():
    if _is_integrated_mode():
        sync_integrated_runtime_hooks()
    else:
        _set_handlers(True)
    maybe_reapply_translation_deferred()


def unregister():
    _clear_timers()
    _set_handlers(False)
    maybe_revert_translation_on_uninstall()
