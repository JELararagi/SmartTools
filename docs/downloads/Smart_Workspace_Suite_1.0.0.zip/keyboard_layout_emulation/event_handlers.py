# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

from .keymap_patch import reapply_keymap_translation, revert_keymap_translation
from .preferences import kle_prefs, _is_integrated_mode


def _suite_always_on_enabled(action: str, default: bool = False) -> bool:
    if not _is_integrated_mode():
        return bool(default)
    try:
        from .. import ui_runtime as _suite_ui_runtime
        remembered = getattr(_suite_ui_runtime, '_remembered_always_state', None)
        if callable(remembered):
            return bool(remembered(action, default))
    except Exception:
        pass
    return bool(default)


def _set_load_handlers_enabled(enabled: bool) -> None:
    try:
        if enabled:
            if on_load_post not in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.append(on_load_post)
            if on_load_post not in bpy.app.handlers.load_post_fail:
                bpy.app.handlers.load_post_fail.append(on_load_post)
        else:
            while on_load_post in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.remove(on_load_post)
            while on_load_post in bpy.app.handlers.load_post_fail:
                bpy.app.handlers.load_post_fail.remove(on_load_post)
    except Exception:
        pass


def sync_integrated_runtime_hooks(context=...) -> None:
    if not _is_integrated_mode():
        return
    if context is ...:
        context = bpy.context
    try:
        prefs = kle_prefs(context)
        enabled = bool(prefs.is_emulation_active and prefs.reapply_on_reload)
    except Exception:
        enabled = _suite_always_on_enabled('kle_reapply_reload', False)
    _set_load_handlers_enabled(enabled)


def maybe_reapply_translation_deferred(context=..., *, for_reload=True):
    if _is_integrated_mode() and not _suite_always_on_enabled('kle_reapply_reload', False):
        return
    prefs = kle_prefs(context)
    if prefs.is_emulation_active and prefs.reapply_on_reload:
        bpy.app.timers.register(
            lambda: maybe_reapply_translation(context, for_reload=for_reload),
            first_interval=0)
        deferred_wait_time = prefs.reapply_on_reload_delay
        if deferred_wait_time > 0:
            bpy.app.timers.register(
                lambda: maybe_reapply_translation(context, for_reload=for_reload),
                first_interval=deferred_wait_time)


def maybe_reapply_translation(context=..., *, for_reload=True):
    if context is ...:
        context = bpy.context

    prefs = kle_prefs(context)
    if not prefs.is_emulation_active or for_reload and not prefs.reapply_on_reload:
        return

    translation = prefs.get_preferred_layout_translation()

    success, msg = reapply_keymap_translation(translation, context)
    logger = prefs.logger
    if logger:
        if not success:
            logger.warning(f"Failed to apply layout emulation on reload:\n  {msg}")
        else:
            logger.info(f"Applied layout emulation on reload:\n  {msg}")


def maybe_revert_translation_on_uninstall(context=...):
    if context is ...:
        context = bpy.context
    prefs = kle_prefs(context)
    ui_state = prefs.ui_state(context)
    if not prefs.is_emulation_active or not ui_state.revert_on_uninstall:
        return

    success, msg = revert_keymap_translation(context)
    logger = prefs.logger
    if logger:
        if not success:
            logger.warning(f"Failed to revert layout emulation on unload:\n  {msg}")
        else:
            logger.info(f"Reverted keyboard layout emulation on unload:\n  {msg}")


def on_addons_set_change():
    maybe_reapply_translation_deferred(for_reload=False)

def on_reapply_requested():
    maybe_reapply_translation(for_reload=False)


@persistent
def on_load_post(*_, **__):
    """Re-register msgbus subscribers after loading a new file."""
    maybe_reapply_translation_deferred()


def register():
    # Register handlers only when they are required. In Smart Workspace
    # integration this is controlled by the centralized always-on group.
    if _is_integrated_mode():
        sync_integrated_runtime_hooks()
    else:
        _set_load_handlers_enabled(True)

    # Reapply translation if appropriate
    maybe_reapply_translation_deferred()

def unregister():
    # Revert translation if appropriate
    maybe_revert_translation_on_uninstall()

    # Unregister handlers
    _set_load_handlers_enabled(False)
