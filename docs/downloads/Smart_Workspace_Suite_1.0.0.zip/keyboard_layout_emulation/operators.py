# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Optional, Literal, TYPE_CHECKING
import bpy
from ..translation import localized_layout, ui_pair
from .. import runtime_ledger as _runtime_ledger
# noinspection PyUnresolvedReferences
from bpy.types import Operator
from bpy.props import BoolProperty, StringProperty, EnumProperty

from .constants import KLEOperators
from .keyboard_layout import us_qwerty_physical_remappable_keys, event_type_to_char_or_none, is_built_in_layout
from .preferences import kle_prefs, layout_enum_items
from .keymap_patch import reapply_keymap_translation, revert_keymap_translation

if TYPE_CHECKING:
    def BoolProperty(*_, **__) -> Literal[bool]: ...
    def StringProperty(*_, **__) -> Literal[str]: ...
    def EnumProperty(*_, **__) -> Literal[str]: ...


# Apply/revert layout emulation

class WM_OT_kle_apply_layout_emulation(Operator):
    bl_idname = KLEOperators.apply_layout_emulation
    bl_label = "Apply Layout Emulation"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        prefs = kle_prefs(context)
        if not prefs.is_emulation_active:
            mapping = prefs.get_preferred_layout_translation()
            if not prefs.is_preferred_layout_translation_applicable_and_non_trivial(ignore_trivial=True):
                if prefs.get_layout_translation(prefs.preferred_input_layout).is_valid():
                    return ("Cannot apply keyboard layout emulation because the selected target keyboard layout is not valid.\n\n"
                            "Edit it (by temporarily setting it as input keyboard layout) and fix it before applying the keyboard layout emulation")
                return ("Cannot apply keyboard layout emulation because the selected input keyboard layout is not valid.\n\n"
                        "Edit it (use the pencil icon on the left) and fix it before applying the keyboard layout emulation")
            if mapping.is_identity():
                return "Cannot apply keyboard layout emulation because the selected keyboard layouts require no emulation"
            return f"Apply keyboard layout emulation ({prefs.preferred_input_layout} → {prefs.preferred_target_layout})"
        if not prefs.has_pending_keymaps_to_emulate():
            return "Keyboard layout emulation is already applied.\nNo pending keymaps to be remapped were detected"
        return "Re-apply layout emulation to any pending keymaps.\nAlready remapped keyboard shortcuts will not be remapped twice.\n\nKeyboard layout emulation is automatically reapplied on restart by default"

    @classmethod
    def poll(cls, context):
        prefs = kle_prefs(context)
        if not prefs:
            return False
        # Only allow apply when the mapping is valid and non-trivial
        return prefs.is_preferred_layout_translation_applicable_and_non_trivial()

    def execute(self, context):
        prefs = kle_prefs(context)
        ui_state = prefs.ui_state(context)
        translation = prefs.get_preferred_layout_translation()

        success, msg = reapply_keymap_translation(translation, context)
        prefs.is_emulation_active = True
        ui_state.is_emulation_applied = True

        if success:
            if msg:
                self.report({'INFO'}, msg)
        else:
            self.report({'WARNING'}, msg or ui_pair('Failed to apply layout emulation', 'レイアウトエミュレーションの適用に失敗しました', context))
            return {'CANCELLED'}
        return {'FINISHED'}


class WM_OT_kle_revert_layout_emulation(Operator):
    bl_idname = KLEOperators.revert_layout_emulation
    bl_label = "Revert Layout Emulation"
    bl_options = {'UNDO'}

    request_confirmation: BoolProperty(
        name="Request confirmation",
        description="Show a confirmation dialog before reverting layout emulation",
        default=False,
    )

    @classmethod
    def description(cls, context, properties):
        prefs = kle_prefs(context)
        header = "Revert layout emulation"
        if prefs.is_emulation_active:
            return header + (
                ".\n\n"
                "Consider reverting keyboard layout emulation before editing any keyboard shortcuts.\n"
                "Keyboard layout emulation automatically modifies all of your keymaps, but it is not possible to correctly track your modifications during emulation to exempt them from being remapped on the next restart"
            )
        else:
            return header + ".\nKeyboard layout emulation is not currently applied"

    @classmethod
    def poll(cls, context):
        prefs = kle_prefs(context)
        return prefs.is_emulation_active

    def invoke(self, context, event):
        if self.request_confirmation:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        prefs = kle_prefs(context)
        ui_state = prefs.ui_state(context)

        success, msg = revert_keymap_translation(context)
        prefs.is_emulation_active = False
        ui_state.is_emulation_applied = False

        if success:
            if msg:
                self.report({'INFO'}, msg)
        else:
            self.report({'WARNING'}, msg or ui_pair('Failed to revert layout emulation', 'レイアウトエミュレーションの解除に失敗しました', context))
            return {'CANCELLED'}
        return {'FINISHED'}

# Add/remove custom layout





# Import/export layout




# Export/import addon preferences
class WM_OT_kle_export_addon_preferences(Operator):
    bl_idname = KLEOperators.export_addon_preferences
    bl_label = "Export KLE Settings"
    bl_description = "Export the Keyboard Layout Emulation settings to a JSON file"
    bl_options = {'UNDO'}

    # File picker properties
    filepath: StringProperty(
        name="File Path",
        description="Path to export the Keyboard Layout Emulation settings JSON",
        default="kle_preferences.json",
        subtype='FILE_PATH',
    )
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )

    # Filters
    include_custom_layouts: BoolProperty(
        name="Include custom layouts",
        description="Include all custom layouts defined in the 'Preferences > Keymap' panel",
        default=True,
    )
    include_remapped_keymaps: BoolProperty(
        name="Include remapped keymaps",
        description="ONLY FOR DEBUG. Include the journal of remapped keymaps.",
        default=False,
        options={'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        prefs = kle_prefs(context)
        with open(self.filepath, 'w') as f:
            f.write(prefs.export_to_json(
                include_remapped_keymaps=self.include_remapped_keymaps,
            ))

        self.report({'INFO'}, ui_pair(f"Exported Keyboard Layout Emulation settings to '{self.filepath}'", f"キーボードレイアウトエミュレーション設定を '{self.filepath}' へ書き出しました", context))
        return {'FINISHED'}

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        col = layout.column()

        col.label(text="Export filters")
        col.prop(self, "include_custom_layouts")

        debug_box = col.box()
        debug_box.alert = True
        debug_col = debug_box.column()
        debug_col.label(text="Options for debug only", icon='ERROR')
        debug_col.prop(self, "include_remapped_keymaps")


class WM_OT_kle_import_addon_preferences(Operator):
    bl_idname = KLEOperators.import_addon_preferences
    bl_label = "Import KLE Settings"
    bl_description = "Import Keyboard Layout Emulation settings from a JSON file"
    bl_options = {'UNDO'}

    # File picker properties
    filepath: StringProperty(
        name="File Path",
        description="Path to import the Keyboard Layout Emulation settings JSON from",
        default="kle_preferences.json",
        subtype='FILE_PATH',
    )
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )

    # Filters
    import_emulation_status: BoolProperty(
        name="Import emulation status",
        description="Automatically apply/revert emulation to match imported settings.",
        default=True,
    )
    import_custom_layouts: EnumProperty(
        items=[
            ('NO', 'No', 'Do not import custom layouts from file'),
            ('UPDATE', 'Update', 'Update custom layouts from file, without deleting any layouts currently defined with other names'),
            ('REPLACE', 'Replace', 'Replace custom layouts with layouts from file, erasing any currently defined layouts'),
            ('ADD', 'Add', 'Import only custom layouts with names not already defined'),
        ],
        name="Layouts",
        description="How should custom layouts be imported from the imported preferences",
        default='UPDATE',
    )
    import_preferences_locked_by_emulation: BoolProperty(
        name="Import preferences locked by emulation",
        description="ONLY FOR DEBUG. Import preferences that are usually locked while emulation is active even when emulation is active.",
        default=False,
        options={'SKIP_SAVE'},
    )
    import_remapped_keymaps: BoolProperty(
        name="Import remapped keymaps",
        description="ONLY FOR DEBUG. Import the journal of remapped keymaps.",
        default=False,
        options={'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        prefs = kle_prefs(context)
        with open(self.filepath, 'r') as f:
            prefs.import_from_json(
                f.read(),
                context=context,
                import_emulation_status=self.import_emulation_status,
                ignore_emulation_lock=self.import_preferences_locked_by_emulation,
                inverse_update_custom_layouts=self.import_custom_layouts == 'ADD',
                update_custom_layouts=self.import_custom_layouts == 'UPDATE',
                overwrite_custom_layouts=self.import_custom_layouts == 'REPLACE',
                import_remapped_keymaps=self.import_remapped_keymaps,
            )

        self.report({'INFO'}, ui_pair(f"Imported Keyboard Layout Emulation settings from '{self.filepath}'", f"キーボードレイアウトエミュレーション設定を '{self.filepath}' から読み込みました", context))
        return {'FINISHED'}

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        col = layout.column()

        col.label(text="Import options")
        col.prop(self, "import_emulation_status")

        custom_layout_box = col.box()
        custom_layout_box.label(text="Import custom layouts")
        custom_layout_box.prop(self, "import_custom_layouts", expand=True)

        debug_box = col.box()
        debug_box.alert = True
        debug_col = debug_box.column()
        debug_col.label(text="Options for debug only", icon='ERROR')
        debug_col.prop(self, "import_preferences_locked_by_emulation")
        debug_col.prop(self, "import_remapped_keymaps")

# UI
def _event_to_char(event) -> Optional[str]:
    # Try unicode/ascii if available
    ch = getattr(event, 'unicode', '') or getattr(event, 'ascii', '')
    if ch:
        # Normalize to single visible character if possible
        if len(ch) == 1:
            ch = ch.upper() if ch.isalpha() else ch
        if ch in us_qwerty_physical_remappable_keys:
            return ch
    t = getattr(event, 'type', '')
    # TODO: This is a blocker if we want to allow remapping non-character keys (e.g., Backspace/Function keys)
    return event_type_to_char_or_none(t)

class WM_OT_kle_capture_key_for_mapping(Operator):
    bl_idname = KLEOperators.capture_key_for_mapping
    bl_label = "Assign Key Mapping"
    bl_description = "Edit key assignment for this emulated layout"
    bl_options = {'UNDO'}

    physical: StringProperty(name="Physical Key", default="")
    layout: EnumProperty(
        name="Layout",
        description="Layout to edit",
        items=layout_enum_items,
        default=0,
    )

    _capturing: bool = False

    @classmethod
    def description(self, context, properties):
        if is_built_in_layout(properties.layout):
            return f"Cannot reassign keys of built-in layout.\nCreate a copy to edit this layout."
        return f"Reassign key [{properties.physical}] for layout: {properties.layout}"

    def invoke(self, context, event):
        prefs = kle_prefs(context)
        physical, layout = self.physical, self.layout
        if not self.physical or not layout:
            self.report({'WARNING'}, ui_pair('No physical key or layout specified.', '物理キーまたはレイアウトが指定されていません。', context))
            return {'CANCELLED'}
        if is_built_in_layout(layout):
            self.report({'WARNING'}, ui_pair('Cannot edit built-in layout.', '組み込みレイアウトは編集できません。', context))
            return {'CANCELLED'}
        if not prefs.is_layout_editable(layout):
            self.report({'WARNING'}, ui_pair('Cannot modify layout while applied to keymaps. Revert first.', 'キーマップに適用中のレイアウトは変更できません。先に解除してください。', context))
            return {'CANCELLED'}

        # Mark which key is listening so UI can show it as pressed
        ui_state = prefs.ui_state(context)
        ui_state.listening_key = physical

        # Register modal handler
        context.window_manager.modal_handler_add(self)
        self._capturing = True

        self.report({'INFO'}, ui_pair(f"Press a key to assign to '{physical}' (ESC or mouse click to cancel)", f"'{physical}' に割り当てるキーを押してください (ESCまたはマウスクリックでキャンセル)", context))
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        prefs = kle_prefs(context)
        ui_state = prefs.ui_state(context)

        physical, layout = self.physical, self.layout

        # Cancel conditions: ESC or any mouse button click anywhere
        cancel_mouse = event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'} and event.value == 'PRESS'
        cancel_esc = event.type == 'ESC' and event.value == 'PRESS'

        if cancel_mouse or cancel_esc:
            self._capturing = False
            ui_state.listening_key = ""

            self.report({'INFO'}, ui_pair('Remapping cancelled', 'リマップをキャンセルしました', context))

            # Tag area for immediate redraw
            bpy.app.timers.register(context.area.tag_redraw, first_interval=0)

            return {'CANCELLED'}

        # Only react on key presses
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        mapped = _event_to_char(event)
        if mapped is None:
            return {'RUNNING_MODAL'}

        # Normalize to single-char mapping
        prefs.update_layout_key(layout, physical, mapped)
        prefs.ui_state(context).listening_key = ""
        self._capturing = False

        self.report({'INFO'}, f"{physical} → {mapped}")

        # Tag area for immediate redraw
        bpy.app.timers.register(context.area.tag_redraw, first_interval=0)

        return {'FINISHED'}


# UI Debug
class WM_OT_kle_debug_toggle_expanded_subkey(Operator):
    bl_idname = KLEOperators.debug_toggle_expanded_subkey
    bl_label = "Show Content"
    bl_description = "Expand item"
    bl_options = {'UNDO'}

    subkey: StringProperty(
        name="Subkey",
        description="Subkey to toggle",
        default=""
    )
    prefs_prop: StringProperty(
        name="Preferences Property",
        description="Property to edit within the preferences",
        default=""
    )

    def execute(self, context):
        prefs = kle_prefs(context)
        ui_state = prefs.ui_state(context)

        prefs_prop = self.prefs_prop
        if not prefs_prop or not hasattr(ui_state, prefs_prop):
            self.report({'WARNING'}, ui_pair('Invalid preferences property specified.', '無効なプリファレンスプロパティが指定されました。', context))
            return {'CANCELLED'}

        subkey = self.subkey
        if not subkey:
            self.report({'WARNING'}, ui_pair('No subkey specified.', 'サブキーが指定されていません。', context))
            return {'CANCELLED'}

        prop = getattr(ui_state, prefs_prop)
        lines = prop.splitlines()
        is_shown = subkey in lines
        if is_shown:
            lines.remove(subkey)
            prop = '\n'.join(lines)
        else:
            prop = f"{prop}\n{subkey}"

        setattr(ui_state, prefs_prop, prop)
        return {'FINISHED'}


# UI Info
class WM_OT_kle_non_editable_key(Operator):
    bl_idname = KLEOperators.Info.non_editable_key
    bl_label = "Cannot remap this key"
    bl_description = "Cannot remap this key"
    bl_options = {'UNDO'}

    key: StringProperty(name="Key", default="")

    def execute(self, context):
        self.report({"INFO"}, ui_pair(
            "This key cannot be remapped.",
            "このキーは再割り当てできません。",
            context,
        ))
        return {'CANCELLED'}


class WM_OT_kle_layout_unlocked_info(Operator):
    bl_idname = KLEOperators.Info.layout_unlocked
    bl_label = "Choose an input keyboard layout to emulate"
    bl_description = (
        "Keyboard layout emulation lets you automatically remap your entire keymap to emulate a QWERTY keyboard layout when using a non-QWERTY keyboard layout.\n"
        "This lets you use QWERTY keyboard shortcuts while still being able to type text in Blender using your preferred keyboard layout.\n\n"
        "The remap is reapplied on every restart (taking care to not remap the same shortcut twice over).\n"
        "This ensures that even shortcuts added by other add-ons are remapped reliably.\n\n"
        "It is recommended that you revert the emulation before editing any keymaps"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        self.report({"INFO"}, ui_pair(
            "Choose your input keyboard layout to use the target layout shortcuts.",
            "使用中のキーボード配列を選ぶと、対象の配列のショートカットを使えます。",
            context,
        ))
        return {'CANCELLED'}


class WM_OT_kle_layout_locked_info(Operator):
    bl_idname = KLEOperators.Info.layout_locked
    bl_label = "Revert the active emulation to change layout"
    bl_description = (
        "Keyboard layout emulation persistently modifies your keymap.\n"
        "You must revert the active emulation before changing/editing which keyboard layout to emulate"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        self.report({"INFO"}, ui_pair(
            "Revert the active emulation before changing the keyboard layout.",
            "キーボード配列を変更する前に、現在のエミュレーションを解除してください。",
            context,
        ))
        return {'CANCELLED'}


class WM_OT_kle_addon_info(Operator):
    bl_idname = KLEOperators.Info.addon_info
    bl_label = "Keyboard Layout Emulation"
    bl_description = (
        "This add-on injects a dropdown menu above the usual 'Preferences > Keymap' panel, to configure emulation of QWERTY keyboard shortcuts on non-QWERTY keyboard layouts.\n\n"
        "Keyboard layout emulation is achieved by persistently reassigning your keymap on every restart (so add-on shortcuts can be reliably reassigned). Tracking user modifications of the keymap is not possible so, for best results, consider temporarily disabling emulation every time you want to manually edit your keymap.\n\n"
        "If you export a keymap preset while emulation is active, it will contain the remapping baked into it. You may want to use this add-on to only generate remapped presets, but bear in mind that remapping add-on shortcuts using a preset may not be possible due to flaws in Blender's keymap system.\n\n"
        "Unless you opt out in the 'Uninstall options' in 'Preferences > Add-ons', your keymap will be automatically restored when this add-on is disabled or uninstalled."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        self.report({"INFO"}, ui_pair(
            "Keyboard Layout Emulation remaps shortcuts. Revert emulation before editing keymaps.",
            "キーボード配列エミュレーションはショートカットを再割り当てします。キーマップを編集する前に解除してください。",
            context,
        ))
        return {'CANCELLED'}


_registered_classes = (
    WM_OT_kle_apply_layout_emulation,
    WM_OT_kle_revert_layout_emulation,
    WM_OT_kle_export_addon_preferences,
    WM_OT_kle_import_addon_preferences,
    WM_OT_kle_capture_key_for_mapping,
    WM_OT_kle_debug_toggle_expanded_subkey,
    WM_OT_kle_non_editable_key,
    WM_OT_kle_layout_unlocked_info,
    WM_OT_kle_layout_locked_info,
    WM_OT_kle_addon_info,
)

def register():
    for cls in _registered_classes:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='KLE_OPERATOR_CLASS',
        )
        if not success:
            raise RuntimeError('RESTART_REQUIRED: Keyboard Layout operator class ownership mismatch')

def unregister():
    for cls in reversed(_registered_classes):
        if _runtime_ledger.class_recorded_current(cls):
            _runtime_ledger.unregister_class_exact(
                cls,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='KLE_OPERATOR_CLASS',
            )
