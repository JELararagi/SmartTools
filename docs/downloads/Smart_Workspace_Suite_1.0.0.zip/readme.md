# Smart Workspace 1.0.0

Blender 5.1.2 で使用します。エディターのサイドバーを N キーで開き、
Smart Workspace のタブを選択してください。各欄の「？」から操作の説明を表示できます。

For installation and guided examples, see the accompanying Smart Workspace guide.
