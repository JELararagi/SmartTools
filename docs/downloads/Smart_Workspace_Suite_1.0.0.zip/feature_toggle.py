# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy
from . import storage as _suite_storage
from . import ui_icons
from . import runtime_ledger as _runtime_ledger

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_PATCH_DEPTH = 0
_ORIGINALS: dict[str, Any] = {}
_ORIGINAL_DRAW_ADDS: dict[str, Any] = {}
_ORIGINAL_DRAW_REMOVES: dict[str, Any] = {}
_DUMMY_COUNTER = 0

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo / Redo、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'RNAメッセージバス監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する データ変更の購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting is saved immediately and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は即時保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo', 'SpaceProperties',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)


def _clean_identifier(value: str, fallback: str = 'smart_tools') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Tools'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_tools'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _interface_translation_enabled(context=None) -> bool:
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
        if getattr(view, 'use_translate_interface', True) is False:
            return False
    except Exception:
        pass
    return True


def _is_ja(context=None) -> bool:
    if not _interface_translation_enabled(context):
        return False
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').strip().lower()
    except Exception:
        lang = ''
    if lang and lang != 'default':
        return lang.startswith('ja') or 'japanese' in lang
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').strip().lower()
    except Exception:
        locale = ''
    return locale.startswith('ja')


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    # Static class/RNA strings must use English as the translation source.
    return str(en)


def _settings_path() -> Path | None:
    configure()
    try:
        return _suite_storage.addon_storage_path(f'{_SUITE_KEY}_persistent_feature_toggles.json', 'feature_toggles')
    except Exception:
        return None


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    path = _settings_path()
    if path is not None and path.exists():
        try:
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                for alias, values in raw.items():
                    if isinstance(values, dict):
                        data[str(alias)] = {str(k): v for k, v in values.items() if isinstance(v, bool)}
        except Exception:
            data = {}
    _STATE_CACHE = data
    return _STATE_CACHE


def _save_state() -> bool:
    path = _settings_path()
    if path is None:
        return False
    try:
        return bool(_suite_storage.atomic_write_json(
            path, _load_state(), indent=2, ensure_ascii=False, sort_keys=True
        ))
    except Exception:
        return False


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key or not isinstance(enabled, bool):
        return False
    state = _load_state()
    values = state.setdefault(alias, {})
    had_previous = feature_key in values
    previous = values.get(feature_key)
    values[feature_key] = enabled
    if not _save_state():
        if had_previous:
            values[feature_key] = previous
        else:
            values.pop(feature_key, None)
        return False
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, enabled)
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    item = dict(action)
    item['generation'] = _runtime_ledger.current_generation()
    if _action_owned_by_suite(item):
        feature.setdefault('actions', []).append(item)


def toggle_operator_id() -> str:
    configure()
    return _OPERATOR_ID


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = bool((_STATE_CACHE or {}).get(alias_key, {}).get(key, False))
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _keymap_item_identity(kmi) -> int:
    """Return a stable identity for a live Blender KeyMapItem.

    Blender may create a new Python RNA wrapper each time keymap items are
    iterated.  Comparing wrapper ``id()`` values therefore misclassifies
    existing Blender/third-party keymaps as resources created by a Workspace
    feature.  The native RNA address remains stable while the item is alive.
    """
    try:
        ptr = int(getattr(kmi, 'as_pointer', lambda: 0)() or 0)
        if ptr:
            return ptr
    except Exception:
        pass
    return id(kmi)


def _snapshot_keymaps() -> set[int]:
    ids: set[int] = set()
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                ids.add(_keymap_item_identity(kmi))
    except Exception:
        pass
    return ids


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    props_out: dict[str, Any] = {}
    try:
        props = getattr(kmi, 'properties', None)
        bl_rna = getattr(props, 'bl_rna', None)
        for prop in getattr(bl_rna, 'properties', ()) or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type':
                continue
            try:
                value = getattr(props, ident)
            except Exception:
                continue
            if isinstance(value, (str, int, float, bool)):
                props_out[ident] = value
    except Exception:
        pass
    return props_out


def _blank_tool_name(value) -> bool:
    text = str(value or '').strip()
    return text in {'', "''", '""'}


def _decode_operator_kwargs(value) -> dict[str, Any]:
    data = value
    for _ in range(3):
        if isinstance(data, dict):
            return data
        if data is None:
            return {}
        if isinstance(data, str):
            text = data.strip()
            if not text:
                return {}
            try:
                data = json.loads(text)
                continue
            except Exception:
                return {}
        return {}
    return data if isinstance(data, dict) else {}


def _keymap_action_has_empty_tool_reference(action: dict[str, Any]) -> bool:
    idname = str(action.get('idname') or '').strip()
    props = action.get('properties') or {}
    if idname == 'wm.tool_set_by_id':
        return _blank_tool_name(props.get('name', ''))
    if idname == 'wm.call_menu_pie_drag_only':
        fallback_operator = str(props.get('fallback_operator', '') or '').strip()
        if fallback_operator != 'wm.tool_set_by_id':
            return False
        fallback_kwargs = _decode_operator_kwargs(props.get('fallback_op_kwargs', '{}'))
        return _blank_tool_name(fallback_kwargs.get('name', ''))
    return False


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'km': km,
        'kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        for km in kc.keymaps:
            try:
                items = list(km.keymap_items)
            except Exception:
                items = []
            for kmi in items:
                if _keymap_item_identity(kmi) not in before:
                    action = _describe_keymap_item(km, kmi)
                    if _keymap_action_has_empty_tool_reference(action):
                        # A before/after snapshot is not ownership proof.  Ignore
                        # malformed foreign/user entries; never delete or disable them.
                        continue
                    actions.append(action)
    except Exception:
        pass
    return actions


def _package_prefix() -> str:
    return str(__package__ or '').strip()


def _callable_owned_by_suite(value: Any) -> bool:
    module_name = str(getattr(value, '__module__', '') or '')
    prefix = _package_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _known_suite_operator_ids() -> set[str]:
    import sys
    prefix = _package_prefix()
    result: set[str] = set()
    if not prefix:
        return result
    for module_name, module in tuple(sys.modules.items()):
        if module is None or not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        try:
            values = tuple(vars(module).values())
        except Exception:
            continue
        for value in values:
            if not isinstance(value, type) or not _callable_owned_by_suite(value):
                continue
            operator_id = getattr(value, 'bl_idname', None)
            if isinstance(operator_id, str) and '.' in operator_id:
                result.add(operator_id)
    return result


def _action_owned_by_suite(action: dict[str, Any]) -> bool:
    if not isinstance(action, dict):
        return False
    generation = str(action.get('generation') or '')
    if not generation or not _runtime_ledger.generation_matches(generation):
        return False
    kind = str(action.get('kind') or '')
    if kind in {'handlers', 'timers'}:
        return _callable_owned_by_suite(action.get('fn'))
    if kind == 'draw_handlers':
        args = tuple(action.get('args') or ())
        callback = args[0] if args else None
        return _callable_owned_by_suite(callback)
    if kind == 'msgbus':
        kwargs = dict(action.get('kwargs') or {})
        return _callable_owned_by_suite(kwargs.get('notify'))
    if kind == 'keymaps':
        return str(action.get('idname') or '') in _known_suite_operator_ids()
    return False


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)) or not _action_owned_by_suite(action):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = _ORIGINAL_DRAW_REMOVES.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            if km is not None and kmi is not None:
                try:
                    items = getattr(km, 'keymap_items', None)
                    if items is not None and kmi in tuple(items):
                        items.remove(kmi)
                except Exception:
                    try:
                        kmi.active = False
                    except Exception:
                        pass
            action['active_km'] = None
            action['active_kmi'] = None
            action['km'] = None
            action['kmi'] = None
    finally:
        action['active'] = False


def _apply_keymap_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        km_name = str(action.get('km_name') or '')
        idname = str(action.get('idname') or '')
        if not km_name or not idname:
            return
        if _keymap_action_has_empty_tool_reference(action):
            action['active'] = False
            action['active_km'] = None
            action['active_kmi'] = None
            return
        try:
            km = kc.keymaps.get(km_name)
        except Exception:
            km = None
        if km is None:
            try:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'), modal=bool(action.get('modal', False)))
            except TypeError:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'))
        kwargs = {
            'type': str(action.get('type') or 'NONE'),
            'value': str(action.get('value') or 'PRESS'),
            'any': bool(action.get('any', False)),
            'shift': bool(action.get('shift', False)),
            'ctrl': bool(action.get('ctrl', False)),
            'alt': bool(action.get('alt', False)),
            'oskey': bool(action.get('oskey', False)),
            'key_modifier': str(action.get('key_modifier') or 'NONE'),
            'direction': str(action.get('direction') or 'ANY'),
            'repeat': bool(action.get('repeat', False)),
        }
        try:
            kmi = km.keymap_items.new(idname, **kwargs)
        except TypeError:
            kwargs.pop('repeat', None)
            try:
                kmi = km.keymap_items.new(idname, **kwargs)
            except TypeError:
                kwargs.pop('direction', None)
                kmi = km.keymap_items.new(idname, **kwargs)
        for prop_name, value in (action.get('properties') or {}).items():
            try:
                _safe_safe_set_kmi_property_v60(kmi, prop_name, value)
            except Exception:
                pass
        action['active_km'] = km
        action['active_kmi'] = kmi
        action['active'] = True
    except Exception:
        action['active'] = False


def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)) or not _action_owned_by_suite(action):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and fn not in seq:
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = _ORIGINALS.get('timer_register') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = _ORIGINALS.get('msgbus_subscribe') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = _ORIGINAL_DRAW_ADDS.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER += 1
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')


def _timer_register_proxy(function, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['timer_register'](function, *args, **kwargs)
    action = {'kind': 'timers', 'fn': function, 'args': tuple(args), 'kwargs': dict(kwargs), 'active': False}
    cap.record_action('timers', action)
    if cap.kind_enabled('timers'):
        result = _ORIGINALS['timer_register'](function, *args, **kwargs)
        action['active'] = True
        return result
    return None


def _msgbus_subscribe_proxy(*args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
    owner = kwargs.get('owner')
    if owner is None and len(args) >= 2:
        owner = args[1]
    action = {'kind': 'msgbus', 'args': tuple(args), 'kwargs': dict(kwargs), 'owner': owner, 'active': False}
    cap.record_action('msgbus', action)
    if cap.kind_enabled('msgbus'):
        result = _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
        action['active'] = True
        return result
    return None


def _make_draw_add_proxy(space_name: str, space_cls, original_add):
    def _proxy(*args, **kwargs):
        cap = _current_capture()
        if cap is None:
            return original_add(*args, **kwargs)
        region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
        action = {
            'kind': 'draw_handlers',
            'space_name': space_name,
            'space_cls': space_cls,
            'args': tuple(args),
            'kwargs': dict(kwargs),
            'region_type': region_type,
            'handle': None,
            'active': False,
        }
        cap.record_action('draw_handlers', action)
        if cap.kind_enabled('draw_handlers'):
            action['handle'] = original_add(*args, **kwargs)
            action['active'] = True
            return action['handle']
        return _next_dummy_handle()
    return _proxy


def _install_patches() -> None:
    """Startup-safe Blender 5.x mode.

    Older builds temporarily replaced bpy.app.timers, bpy.msgbus, and
    Space*.draw_handler_add in order to capture background hooks created by
    bundled add-ons.  Replacing live Blender API callables is unsafe during
    startup and can leave persistent state behind.  The centralized UI still
    manages known always-on features and captures handlers/keymaps by comparing
    before/after snapshots, but it no longer monkey-patches Blender runtime
    API objects.
    """
    global _PATCH_DEPTH
    _PATCH_DEPTH += 1
    return None


def _uninstall_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH = max(0, _PATCH_DEPTH - 1)
    if _PATCH_DEPTH > 0:
        return None
    _PATCH_DEPTH = 0
    _ORIGINALS.clear()
    _ORIGINAL_DRAW_ADDS.clear()
    _ORIGINAL_DRAW_REMOVES.clear()
    return None


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        _install_patches()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            generation = _runtime_ledger.current_generation()
            for feature_key, actions in (
                ('handlers', _collect_new_handlers(self._before_handlers)),
                ('keymaps', _collect_new_keymaps(self._before_keymaps)),
            ):
                for action in actions:
                    candidate = dict(action)
                    candidate['generation'] = generation
                    if not _action_owned_by_suite(candidate):
                        continue
                    self.record_action(feature_key, candidate)
                    if not self.kind_enabled(feature_key):
                        _remove_action(candidate)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _uninstall_patches()
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
                    for region in getattr(area, 'regions', ()) or ():
                        if getattr(region, 'type', None) in {'UI', 'WINDOW', 'TOOLS', 'HEADER'}:
                            try:
                                region.tag_redraw()
                            except Exception:
                                pass
    except Exception:
        pass


def _toggle_operator_button(layout, operator_id: str, *, text: str, icon: str, enabled: bool):
    """Draw captured always-on toggles with oversized custom on/off glyphs."""
    return ui_icons.operator(layout, operator_id, text=text, name='toggle_on' if enabled else 'toggle_off', fallback=icon, depress=bool(enabled))


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効 / 無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Tools feature. The setting is saved immediately.', 'Smart Tools の常時起動機能を切り替えます。設定は即時保存されます。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> bool:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return all(_runtime_ledger.class_recorded_current(cls) for cls in _REGISTERED_CLASSES)
    operator_id = _OPERATOR_ID

    class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = _static_t('Toggle Feature', '機能を切り替え')
        bl_description = _static_t('Switch an always-on feature on or off and save the setting immediately.', '常時起動機能の有効 / 無効を切り替え、設定を即時保存します。')
        bl_options = {'UNDO'}

        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting saved.', '機能設定を保存しました。'))
            return {'FINISHED'}

    SMARTTOOLS_OT_toggle_persistent_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_toggle_persistent_feature.__qualname__ = SMARTTOOLS_OT_toggle_persistent_feature.__name__
    SMARTTOOLS_OT_toggle_persistent_feature.__module__ = __name__
    cls = SMARTTOOLS_OT_toggle_persistent_feature
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='FEATURE_TOGGLE_CLASS',
    )
    if not success:
        return False
    _REGISTERED_CLASSES.append(cls)
    return True



def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = True
            except Exception:
                pass
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            try:
                op.enabled = False
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> bool:
    success = True
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        if not _runtime_ledger.class_recorded_current(cls):
            success = False
            continue
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='FEATURE_TOGGLE_CLASS',
        ):
            success = False
    if success:
        _REGISTERED_CLASSES.clear()
    return success


def unregister_all() -> None:
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        props = getattr(kmi, 'properties', None)
        rna = getattr(props, 'bl_rna', None)
        prop_map = getattr(rna, 'properties', None)
        has_prop = False
        try:
            has_prop = str(prop_name) in set(prop_map.keys())
        except Exception:
            try:
                has_prop = prop_map.get(str(prop_name)) is not None
            except Exception:
                has_prop = hasattr(props, str(prop_name))
        if not has_prop:
            return False
        setattr(props, str(prop_name), value)
        return True
    except Exception:
        return False
