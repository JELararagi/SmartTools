# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Cross-reload ownership and finite resource lease ledger.

Every record stores exact Python owner/class identities, a generation token, a
unique registration token, stable native RNA metadata, and the native remover
captured at registration time.  Blender may return a fresh Python wrapper for
the same RNA property on every lookup, so wrapper ``is`` identity is never an
ownership condition.  Identifier metadata alone is also insufficient: a slot is
owned only when this generation explicitly recorded the successful registration.
A new generation never adopts or removes older/foreign displayed RNA.
"""

from __future__ import annotations

import dataclasses
import time
import uuid
from typing import Any, Callable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = "smart_workspace_suite"
NAMESPACE_KEY = "JELARARAGI_SMART_WORKSPACE_SUITE_RUNTIME_LEDGER_V2"
# ``importlib.reload`` executes in the existing module dictionary.  Preserve
# the exact owner token so an active generation remains removable by the same
# module across an extension refresh; a fresh import still creates a fresh
# token and therefore cannot adopt another module object's generation.
if "_MODULE_IDENTITY" not in globals():
    _MODULE_IDENTITY = object()
_FALLBACK: dict[str, Any] = {}
_SESSION_LEDGER: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True)
class GenerationDecision:
    allowed: bool
    status: str
    generation: str
    restart_required: bool

    @property
    def reason(self) -> str:
        """Backward-compatible diagnostic alias; never used for ownership."""
        return self.status


def _namespace() -> dict[str, Any]:
    if bpy is None:
        return _FALLBACK
    try:
        return bpy.app.driver_namespace
    except Exception:
        return _FALLBACK


def ledger() -> dict[str, Any]:
    global _SESSION_LEDGER
    namespace = _namespace()
    value = namespace.get(NAMESPACE_KEY)
    if not isinstance(value, dict):
        active = (
            _SESSION_LEDGER.get("active")
            if isinstance(_SESSION_LEDGER, dict)
            else None
        )
        if (
            isinstance(active, dict)
            and active.get("module_identity") is _MODULE_IDENTITY
            and active.get("status") == "ACTIVE"
        ):
            # Blender replaces driver_namespace while opening a .blend, but the
            # registered classes, RNA and persistent callbacks remain live.
            # Republish only this exact module's ledger object; never reconstruct
            # or adopt ownership from stable names or RNA metadata.
            value = _SESSION_LEDGER
        else:
            value = {
                "package_id": PACKAGE_ID,
                "revision": 0,
                "active": None,
                "restart_required": None,
                "lease_slots": {},
            }
        namespace[NAMESPACE_KEY] = value
    active = value.get("active")
    if (
        _SESSION_LEDGER is None
        and (
            active is None
            or (
                isinstance(active, dict)
                and active.get("module_identity") is _MODULE_IDENTITY
            )
        )
    ):
        _SESSION_LEDGER = value
    elif value is _SESSION_LEDGER:
        namespace[NAMESPACE_KEY] = value
    value.setdefault("lease_slots", {})
    return value


def active_record() -> dict[str, Any] | None:
    value = ledger().get("active")
    return value if isinstance(value, dict) else None


def current_generation() -> str:
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return ""
    return str(record.get("generation") or "")


def generation_matches(generation: str) -> bool:
    record = active_record()
    return bool(
        isinstance(record, dict)
        and record.get("module_identity") is _MODULE_IDENTITY
        and str(record.get("generation") or "") == str(generation or "")
        and record.get("status") == "ACTIVE"
    )


def _remove_lease_record(record: dict[str, Any]) -> bool:
    remover = record.get("native_remover")
    handle = record.get("handle")
    args = tuple(record.get("remove_args") or ())
    kwargs = dict(record.get("remove_kwargs") or {})
    if not callable(remover):
        return False
    try:
        remover(handle, *args, **kwargs)
        record["removed"] = True
        return True
    except Exception:
        # Native remove operations can be idempotent only through an explicit
        # is_registered predicate or by accepting an already-removed error.
        predicate = record.get("is_registered")
        if callable(predicate):
            try:
                if not bool(predicate(handle)):
                    record["removed"] = True
                    return True
            except Exception:
                pass
        return False


def collect_stale_leases(*, keep_generation: str = "") -> int:
    """Remove bounded stale callbacks using their captured native removers.

    Failures are retained in the shared ledger.  A caller may not start a new
    generation while any stale native handle remains live.
    """
    root = ledger()
    slots = root.setdefault("lease_slots", {})
    removed = 0
    failures: list[str] = []
    for key, record in list(slots.items()):
        if not isinstance(record, dict):
            slots.pop(key, None)
            continue
        generation = str(record.get("generation") or "")
        if keep_generation and generation == keep_generation and not record.get("removed"):
            continue
        if record.get("removed") or _remove_lease_record(record):
            slots.pop(key, None)
            removed += 1
        else:
            failures.append(str(key))
    root["lease_cleanup_failures"] = tuple(failures)
    return removed


def begin_registration() -> GenerationDecision:
    root = ledger()
    active = active_record()
    if active is not None:
        if active.get("module_identity") is _MODULE_IDENTITY and active.get("status") == "ACTIVE":
            generation = str(active.get("generation") or "")
            collect_stale_leases(keep_generation=generation)
            if root.get("lease_cleanup_failures"):
                mark_restart_required("CURRENT_GENERATION_STALE_LEASE_REMOVE_FAILED")
                return GenerationDecision(False, "RESTART_REQUIRED", generation, True)
            return GenerationDecision(True, "ALREADY_CURRENT", generation, False)
        # Finite callbacks may be removed only through the native remover stored
        # by the generation that created them.  Displayed RNA/classes are never
        # adopted or unregistered by a different module identity.
        collect_stale_leases()
        reason = "ACTIVE_RNA_GENERATION_IDENTITY_MISMATCH"
        if root.get("lease_cleanup_failures"):
            reason = "STALE_NATIVE_LEASE_REMOVE_FAILED"
        restart = {
            "requested_by_module_identity": _MODULE_IDENTITY,
            "active_generation": str(active.get("generation") or ""),
            "active_module_identity": active.get("module_identity"),
            "reason": reason,
            "created_monotonic": time.monotonic(),
        }
        root["restart_required"] = restart
        return GenerationDecision(False, "RESTART_REQUIRED", "", True)
    # No RNA generation is live.  All old finite callbacks still have to be
    # collected successfully before a new token is published.
    collect_stale_leases()
    if root.get("lease_cleanup_failures"):
        root["restart_required"] = {
            "requested_by_module_identity": _MODULE_IDENTITY,
            "active_generation": "",
            "active_module_identity": None,
            "reason": "STALE_NATIVE_LEASE_REMOVE_FAILED",
            "created_monotonic": time.monotonic(),
        }
        return GenerationDecision(False, "RESTART_REQUIRED", "", True)
    generation = uuid.uuid4().hex
    root["revision"] = int(root.get("revision") or 0) + 1
    root["active"] = {
        "package_id": PACKAGE_ID,
        "module_identity": _MODULE_IDENTITY,
        "generation": generation,
        "revision": int(root["revision"]),
        "status": "ACTIVE",
        "classes": {},
        "properties": {},
        "provisional_classes": {},
        "created_monotonic": time.monotonic(),
    }
    root["restart_required"] = None
    root["lease_cleanup_failures"] = ()
    return GenerationDecision(True, "NEW", generation, False)


def mark_restart_required(reason: str) -> None:
    root = ledger()
    active = active_record()
    root["restart_required"] = {
        "reason": str(reason or "UNPROVEN_RNA_OWNERSHIP"),
        "active_generation": str(active.get("generation") or "") if active else "",
        "requested_by_module_identity": _MODULE_IDENTITY,
        "created_monotonic": time.monotonic(),
    }


def restart_required_state() -> dict[str, Any] | None:
    value = ledger().get("restart_required")
    return value if isinstance(value, dict) else None


def _rna_property(owner_type: type, property_name: str) -> Any:
    try:
        properties = getattr(getattr(owner_type, "bl_rna", None), "properties", None)
        getter = getattr(properties, "get", None)
        return getter(property_name) if callable(getter) else None
    except Exception:
        return None


def _rna_identifier(value: Any) -> str:
    try:
        return str(getattr(value, "identifier", "") or "")
    except Exception:
        return ""


def _is_property_deferred(value: Any) -> bool:
    """Reject Blender property declarations that are not registered RNA."""
    if value is None:
        return False
    try:
        value_type = type(value)
        type_name = str(getattr(value_type, "__name__", "") or "")
        module_name = str(getattr(value_type, "__module__", "") or "")
    except Exception:
        return True
    return bool(
        type_name == "_PropertyDeferred"
        or (
            type_name.endswith("PropertyDeferred")
            and (module_name.startswith("bpy") or module_name.startswith("_bpy"))
        )
    )



# Blender registerable base classes have different canonical RNA naming rules.
# The post-registration class-owned StructRNA identifier is authoritative; the
# preflight candidates below exist only to detect a foreign occupant before a
# native register call.
_REGISTERABLE_BASE_SPECS: tuple[tuple[str, str], ...] = (
    ("Macro", "OPERATOR"),
    ("Operator", "OPERATOR"),
    ("Panel", "CLASS_OR_IDNAME"),
    ("Menu", "CLASS_OR_IDNAME"),
    ("UIList", "CLASS_OR_IDNAME"),
    ("Header", "CLASS_OR_IDNAME"),
    ("PropertyGroup", "CLASS_NAME"),
    ("AddonPreferences", "CLASS_NAME"),
    ("Gizmo", "IDNAME_OR_CLASS"),
    ("GizmoGroup", "IDNAME_OR_CLASS"),
    ("RenderEngine", "IDNAME_OR_CLASS"),
    ("NodeTree", "IDNAME_OR_CLASS"),
    ("NodeSocket", "IDNAME_OR_CLASS"),
    ("NodeSocketInterface", "IDNAME_OR_CLASS"),
    ("Node", "IDNAME_OR_CLASS"),
    ("FileHandler", "IDNAME_OR_CLASS"),
    ("AssetShelf", "IDNAME_OR_CLASS"),
    ("KeyingSetInfo", "IDNAME_OR_CLASS"),
)


def _class_key(cls: type) -> str:
    return f"{getattr(cls, '__module__', '')}:{getattr(cls, '__qualname__', getattr(cls, '__name__', ''))}"


def _class_record(cls: type | None) -> dict[str, Any] | None:
    if not isinstance(cls, type):
        return None
    record = active_record()
    if not isinstance(record, dict):
        return None
    item = record.get("classes", {}).get(_class_key(cls))
    if isinstance(item, dict) and item.get("class_identity") is cls:
        return item
    # Dynamic modules can expose the same class object through aliases.  Exact
    # object identity, not a string key, remains authoritative.
    for candidate in record.get("classes", {}).values():
        if isinstance(candidate, dict) and candidate.get("class_identity") is cls:
            return candidate
    return None


def _class_is_registered_flag(cls: type | None) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        return bool(getattr(cls, "is_registered", False))
    except Exception:
        return False


def _class_owned_rna(cls: type | None) -> Any:
    """Return only a real class-owned StructRNA object.

    ``getattr(cls, 'bl_rna')`` is insufficient because an unregistered subclass
    inherits its Blender base's RNA.  Registration proof requires ``bl_rna`` to
    be present in ``vars(cls)`` and not be a deferred property declaration.
    """
    if not isinstance(cls, type):
        return None
    try:
        namespace = vars(cls)
    except Exception:
        return None
    if "bl_rna" not in namespace:
        return None
    value = namespace.get("bl_rna")
    if value is None or _is_property_deferred(value):
        return None
    identifier = _rna_identifier(value)
    if not identifier:
        return None
    # StructRNA exposes semantic metadata.  Avoid accepting arbitrary strings,
    # descriptors, and property declaration placeholders as registration proof.
    try:
        has_rna_shape = any(
            hasattr(value, attr)
            for attr in ("properties", "functions", "base", "name")
        )
    except Exception:
        has_rna_shape = False
    if not has_rna_shape:
        return None
    return value


def _class_registration_base(cls: type | None) -> tuple[str, type | None, str]:
    if not isinstance(cls, type) or bpy is None:
        return ("", None, "GENERIC")
    types_namespace = getattr(bpy, "types", None)
    for base_name, policy in _REGISTERABLE_BASE_SPECS:
        try:
            base = getattr(types_namespace, base_name, None)
            if isinstance(base, type) and cls is not base and issubclass(cls, base):
                return (base_name, base, policy)
        except Exception:
            continue
    # Future Blender registerable bases still receive resolver-based ownership
    # checks when their direct MRO base publishes bl_rna_get_subclass_py.
    try:
        for base in cls.__mro__[1:]:
            if not isinstance(base, type) or base is object:
                continue
            resolver = getattr(base, "bl_rna_get_subclass_py", None)
            if callable(resolver):
                return (str(getattr(base, "__name__", "") or ""), base, "GENERIC")
    except Exception:
        pass
    return ("", None, "GENERIC")


def _declared_bl_idname(cls: type | None) -> str:
    if not isinstance(cls, type):
        return ""
    try:
        value = vars(cls).get("bl_idname", "")
    except Exception:
        value = ""
    try:
        return str(value or "").strip()
    except Exception:
        return ""


def _operator_canonical_identifier(bl_idname: str) -> str:
    value = str(bl_idname or "").strip()
    if value.count(".") != 1:
        return ""
    namespace, operator_name = value.split(".", 1)
    namespace = namespace.strip()
    operator_name = operator_name.strip()
    if not namespace or not operator_name:
        return ""
    return f"{namespace.upper()}_OT_{operator_name}"


def class_preflight_rna_identifiers(cls: type | None) -> tuple[str, ...]:
    """Return base-specific canonical candidates for foreign-occupancy checks.

    These are deliberately not used as post-registration authority.  Blender's
    actual class-owned ``bl_rna.identifier`` is recorded immediately after the
    native registration succeeds.
    """
    if not isinstance(cls, type):
        return ()
    class_name = str(getattr(cls, "__name__", "") or "").strip()
    bl_idname = _declared_bl_idname(cls)
    _base_name, _base, policy = _class_registration_base(cls)
    values: list[str] = []
    if policy == "OPERATOR":
        canonical = _operator_canonical_identifier(bl_idname)
        if canonical:
            values.append(canonical)
    elif policy == "CLASS_NAME":
        if class_name:
            values.append(class_name)
    elif policy == "CLASS_OR_IDNAME":
        if bl_idname:
            values.append(bl_idname)
        if class_name:
            values.append(class_name)
    elif policy == "IDNAME_OR_CLASS":
        if bl_idname:
            values.append(bl_idname)
        if class_name:
            values.append(class_name)
    else:
        if bl_idname:
            values.append(bl_idname)
        if class_name:
            values.append(class_name)
    # The Python class name is always probed as a publication collision even
    # when Blender uses another canonical RNA identifier (notably Operators).
    if class_name:
        values.append(class_name)
    result: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in result:
            result.append(text)
    return tuple(result)


def _resolver_lookup(base: type | None, identifier: str, cls: type | None = None) -> tuple[str, Any]:
    """Resolve a canonical RNA identifier through the correct Blender base."""
    if not isinstance(base, type) or not identifier:
        return ("UNAVAILABLE", None)
    try:
        resolver = getattr(base, "bl_rna_get_subclass_py", None)
    except Exception:
        return ("ERROR", None)
    if not callable(resolver):
        return ("UNAVAILABLE", None)
    try:
        try:
            resolved = resolver(identifier, None)
        except TypeError:
            resolved = resolver(identifier)
    except Exception:
        return ("ERROR", None)
    if resolved is None:
        return ("ABSENT", None)
    if isinstance(cls, type) and resolved is cls:
        return ("EXACT", resolved)
    return ("FOREIGN", resolved)


def _bpy_types_lookup(identifier: str, cls: type | None = None) -> tuple[str, Any]:
    if bpy is None:
        return ("ABSENT", None)
    text = str(identifier or "").strip()
    if not text or not text.isidentifier():
        return ("ABSENT", None)
    try:
        published = getattr(bpy.types, text)
    except AttributeError:
        return ("ABSENT", None)
    except Exception:
        return ("ERROR", None)
    if published is None:
        return ("ABSENT", None)
    if isinstance(cls, type) and published is cls:
        return ("EXACT", published)
    return ("FOREIGN", published)


def class_publication_state(
    cls: type | None,
    *,
    actual_identifier: str = "",
) -> tuple[str, Any]:
    """Return ``ABSENT``, ``EXACT``, ``FOREIGN`` or ``ERROR``.

    Both Python publication names and the correct Blender base's canonical RNA
    resolver are checked.  Missing ``bpy.types.<PythonClassName>`` is accepted;
    a foreign same-name or canonical-name class always fails closed.
    """
    if not isinstance(cls, type):
        return ("ERROR", None)
    base_name, base, _policy = _class_registration_base(cls)
    del base_name
    identifiers = list(class_preflight_rna_identifiers(cls))
    actual = str(actual_identifier or "").strip()
    if not actual:
        own_rna = _class_owned_rna(cls)
        actual = _rna_identifier(own_rna)
    if actual and actual not in identifiers:
        identifiers.insert(0, actual)
    class_name = str(getattr(cls, "__name__", "") or "").strip()
    if class_name and class_name not in identifiers:
        identifiers.append(class_name)

    exact: Any = None
    saw_error = False
    for identifier in identifiers:
        state, value = _bpy_types_lookup(identifier, cls)
        if state == "FOREIGN":
            return ("FOREIGN", value)
        if state == "ERROR":
            saw_error = True
        elif state == "EXACT":
            exact = value

    # Resolver checks use the base-specific canonical candidates and the actual
    # post-registration identifier.  The Python class name may also be canonical
    # for PropertyGroups, Panels, Menus, UILists, and other class families.
    if isinstance(base, type):
        for identifier in identifiers:
            state, value = _resolver_lookup(base, identifier, cls)
            if state == "FOREIGN":
                return ("FOREIGN", value)
            if state == "ERROR":
                saw_error = True
            elif state == "EXACT":
                exact = value

    if exact is not None:
        return ("EXACT", exact)
    if saw_error:
        return ("ERROR", None)
    return ("ABSENT", None)


def _registered_class_evidence(cls: type | None) -> dict[str, Any]:
    """Capture exact native registration evidence for one class object."""
    result: dict[str, Any] = {
        "valid": False,
        "identifier": "",
        "base_name": "",
        "base_identity": None,
        "resolver_available": False,
        "resolver_state": "UNAVAILABLE",
        "publication_state": "ERROR",
        "preflight_identifiers": class_preflight_rna_identifiers(cls),
    }
    if not isinstance(cls, type) or not _class_is_registered_flag(cls):
        return result
    own_rna = _class_owned_rna(cls)
    if own_rna is None:
        return result
    identifier = _rna_identifier(own_rna)
    if not identifier:
        return result
    base_name, base, _policy = _class_registration_base(cls)
    resolver_state, resolved = _resolver_lookup(base, identifier, cls)
    resolver_available = resolver_state != "UNAVAILABLE"
    if resolver_available and resolver_state != "EXACT":
        result.update(
            identifier=identifier,
            base_name=base_name,
            base_identity=base,
            resolver_available=True,
            resolver_state=resolver_state,
        )
        return result
    publication_state, published = class_publication_state(cls, actual_identifier=identifier)
    if publication_state in {"FOREIGN", "ERROR"}:
        result.update(
            identifier=identifier,
            base_name=base_name,
            base_identity=base,
            resolver_available=resolver_available,
            resolver_state=resolver_state,
            publication_state=publication_state,
            publication_identity=published,
        )
        return result
    result.update(
        valid=True,
        identifier=identifier,
        base_name=base_name,
        base_identity=base,
        resolver_available=resolver_available,
        resolver_state=resolver_state,
        resolver_identity=resolved,
        publication_state=publication_state,
        publication_identity=published,
    )
    return result


def _class_rna_identifier(cls: type | None) -> str:
    """Return Blender's actual class-owned registered RNA identifier.

    No equality with ``cls.__name__`` is required.  Operators and several other
    Blender class families intentionally use a canonical identifier derived from
    ``bl_idname`` rather than from the Python class name.
    """
    evidence = _registered_class_evidence(cls)
    return str(evidence.get("identifier") or "") if evidence.get("valid") else ""


def class_rna_identifier(cls: type | None) -> str:
    return _class_rna_identifier(cls)


def class_has_valid_registered_rna(cls: type | None) -> bool:
    return bool(_class_rna_identifier(cls))


def _class_object_is_natively_unregistered(cls: type | None) -> bool:
    if not isinstance(cls, type):
        return False
    if _class_is_registered_flag(cls):
        return False
    return _class_owned_rna(cls) is None


def _class_record_matches_current(item: dict[str, Any], cls: type, *, require_live: bool) -> bool:
    record = active_record()
    generation = current_generation()
    if record is None or not generation or not isinstance(item, dict) or not isinstance(cls, type):
        return False
    if item.get("registered_by_module_identity") is not _MODULE_IDENTITY:
        return False
    if not isinstance(item.get("registration_token"), str) or not item.get("registration_token"):
        return False
    if item.get("class_identity") is not cls:
        return False
    if str(item.get("generation") or "") != generation or item.get("revision") != record.get("revision"):
        return False
    if not require_live:
        return True
    if item.get("native_registered", True) is not True:
        return False
    evidence = _registered_class_evidence(cls)
    expected_identifier = str(item.get("class_rna_identifier") or "")
    if not evidence.get("valid") or not expected_identifier:
        return False
    if str(evidence.get("identifier") or "") != expected_identifier:
        return False
    stored_base = item.get("class_base_identity")
    if stored_base is not None and evidence.get("base_identity") is not stored_base:
        return False
    if bool(item.get("resolver_available")) and evidence.get("resolver_state") != "EXACT":
        return False
    return True


def record_class(
    cls: type,
    *,
    remover: Callable[..., Any] | None = None,
    newly_registered: bool = True,
) -> bool:
    """Record the exact class object and actual canonical RNA identity."""
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    if not isinstance(cls, type):
        return False
    evidence = _registered_class_evidence(cls)
    if not evidence.get("valid"):
        return False
    rna_identifier = str(evidence.get("identifier") or "")
    classes = record.setdefault("classes", {})
    key = _class_key(cls)
    existing = classes.get(key)
    if isinstance(existing, dict):
        if _class_record_matches_current(existing, cls, require_live=True):
            return True
        old_cls = existing.get("class_identity")
        same_class_refresh = bool(
            old_cls is cls
            and existing.get("registered_by_module_identity") is _MODULE_IDENTITY
            and str(existing.get("generation") or "") == current_generation()
            and existing.get("revision") == record.get("revision")
            and existing.get("native_registered", True) is False
        )
        dynamic_replacement = bool(
            isinstance(old_cls, type)
            and old_cls is not cls
            and existing.get("registered_by_module_identity") is _MODULE_IDENTITY
            and str(existing.get("generation") or "") == current_generation()
            and existing.get("revision") == record.get("revision")
            and existing.get("native_registered", True) is False
            and _class_object_is_natively_unregistered(old_cls)
            and str(existing.get("class_rna_identifier") or "") == rna_identifier
        )
        if not (same_class_refresh or dynamic_replacement):
            return False
    classes[key] = {
        "class_identity": cls,
        "class_name": str(getattr(cls, "__name__", "") or ""),
        "class_module": str(getattr(cls, "__module__", "") or ""),
        "class_qualname": str(getattr(cls, "__qualname__", getattr(cls, "__name__", "")) or ""),
        "class_rna_identifier": rna_identifier,
        "class_base_name": str(evidence.get("base_name") or ""),
        "class_base_identity": evidence.get("base_identity"),
        "preflight_rna_identifiers": tuple(evidence.get("preflight_identifiers") or ()),
        "resolver_available": bool(evidence.get("resolver_available")),
        "registered_by_module_identity": _MODULE_IDENTITY,
        "registration_token": uuid.uuid4().hex,
        "remover": remover,
        "newly_registered": bool(newly_registered),
        "native_registered": True,
        "generation": record.get("generation"),
        "revision": record.get("revision"),
    }
    return _class_record_matches_current(classes[key], cls, require_live=True)


def class_recorded_current(cls: type) -> bool:
    item = _class_record(cls)
    return bool(isinstance(item, dict) and _class_record_matches_current(item, cls, require_live=False))


def class_is_current(cls: type) -> bool:
    """Validate exact ledger identity plus Blender's actual canonical RNA."""
    item = _class_record(cls)
    return bool(isinstance(item, dict) and _class_record_matches_current(item, cls, require_live=True))


def class_registration_preflight(cls: type | None) -> str:
    """Classify one exact registration attempt without adopting foreign RNA."""
    if not isinstance(cls, type):
        return "INVALID"
    if class_is_current(cls):
        return "CURRENT"
    if class_recorded_current(cls):
        if class_is_safely_unregistered(cls):
            return "RECORDED_UNREGISTERED"
        return "RECORDED_INVALID"
    publication_state, _published = class_publication_state(cls)
    if publication_state == "FOREIGN":
        return "FOREIGN"
    if publication_state == "ERROR":
        return "LOOKUP_ERROR"
    if publication_state == "EXACT":
        return "UNLEDGERED_EXACT"
    if class_has_valid_registered_rna(cls):
        return "UNLEDGERED_NATIVE"
    # ``is_registered`` true with inherited/deferred/missing class-owned RNA is
    # inconsistent and must not be treated as a clean class.
    if _class_is_registered_flag(cls):
        return "UNLEDGERED_INVALID"
    try:
        own_declared = vars(cls).get("bl_rna")
    except Exception:
        own_declared = None
    if own_declared is not None and not _is_property_deferred(own_declared):
        return "UNLEDGERED_INVALID"
    return "CLEAN"


def class_is_safely_unregistered(cls: type | None) -> bool:
    if not _class_object_is_natively_unregistered(cls):
        return False
    item = _class_record(cls) if isinstance(cls, type) else None
    actual_identifier = str(item.get("class_rna_identifier") or "") if isinstance(item, dict) else ""
    publication_state, _published = class_publication_state(cls, actual_identifier=actual_identifier)
    return publication_state == "ABSENT"


def _local_rollback_new_class(
    cls: type,
    unregister_fn: Callable[[type], Any] | None,
    evidence: dict[str, Any] | None,
) -> bool:
    """Rollback only an exact just-registered class recorded provisionally.

    A failed postcondition must not guess from the Python class name.  The
    active generation records the exact object, actual class-owned RNA ID, base
    resolver, and remover before invoking the native unregister function.
    """
    record = active_record()
    if (
        not callable(unregister_fn)
        or not isinstance(evidence, dict)
        or not isinstance(record, dict)
        or record.get("module_identity") is not _MODULE_IDENTITY
        or not isinstance(cls, type)
    ):
        return False
    identifier = str(evidence.get("identifier") or "")
    base = evidence.get("base_identity")
    if not identifier or not _class_is_registered_flag(cls):
        return False
    own_rna = _class_owned_rna(cls)
    if own_rna is None or _rna_identifier(own_rna) != identifier:
        return False
    resolver_state, _resolved = _resolver_lookup(base if isinstance(base, type) else None, identifier, cls)
    if resolver_state not in {"EXACT", "UNAVAILABLE"}:
        return False
    token = uuid.uuid4().hex
    provisional = record.setdefault("provisional_classes", {})
    provisional[token] = {
        "class_identity": cls,
        "class_rna_identifier": identifier,
        "class_base_identity": base,
        "registered_by_module_identity": _MODULE_IDENTITY,
        "generation": record.get("generation"),
        "revision": record.get("revision"),
        "remover": unregister_fn,
    }
    try:
        try:
            unregister_fn(cls)
        except Exception:
            if not _class_object_is_natively_unregistered(cls):
                return False
        if not _class_object_is_natively_unregistered(cls):
            return False
        state, _value = _resolver_lookup(base if isinstance(base, type) else None, identifier, cls)
        if state in {"EXACT", "ERROR"}:
            return False
        # A foreign class appearing after the exact unregister is left untouched;
        # the rollback of this class object still completed successfully.
        return True
    finally:
        if _class_object_is_natively_unregistered(cls):
            provisional.pop(token, None)


def rollback_unrecorded_class_exact(
    cls: type,
    *,
    native_unregister: Callable[[type], Any] | None = None,
) -> bool:
    """Rollback one just-created exact class through a provisional ledger entry.

    This helper is for bounded registration transactions that discover a native
    class after its local registration helper returned.  It never uses the
    Python class name as ownership proof and never touches a foreign canonical
    occupant.  The exact class object, actual class-owned RNA identifier, base
    resolver and native remover are recorded provisionally before removal.
    """
    if not isinstance(cls, type) or not current_generation():
        return False
    unregister_fn = native_unregister
    if unregister_fn is None and bpy is not None:
        unregister_fn = getattr(getattr(bpy, "utils", None), "unregister_class", None)
    evidence = _registered_class_evidence(cls)
    if not evidence.get("valid"):
        return False
    return _local_rollback_new_class(cls, unregister_fn, evidence)


def _strip_redo_panel_from_owned_operator(cls: type) -> bool:
    """Suppress this Suite's redo panel while preserving one-step Undo.

    Blender exposes Adjust Last Operation only when ``REGISTER`` is present.
    The accepted 1.1.134 contract removes it immediately before native class
    registration, and only from exact Smart Workspace Operator classes that
    already opt into ``UNDO``.  Other add-ons, Blender classes, popup/modal
    behavior, public IDs, and operators without ``UNDO`` remain untouched.
    """
    if not isinstance(cls, type) or bpy is None:
        return False
    module_name = str(getattr(cls, "__module__", "") or "")
    package_name = str(__package__ or "")
    if not package_name or not (module_name == package_name or module_name.startswith(package_name + ".")):
        return False
    try:
        operator_base = getattr(getattr(bpy, "types", None), "Operator", None)
        if not isinstance(operator_base, type) or cls is operator_base or not issubclass(cls, operator_base):
            return False
    except Exception:
        return False
    try:
        declared = vars(cls).get("bl_options", set())
        options = set(declared or ())
    except Exception:
        return False
    if "REGISTER" not in options or "UNDO" not in options:
        return False
    options.discard("REGISTER")
    try:
        cls.bl_options = options
    except Exception:
        return False
    return True


def register_class_exact(
    cls: type,
    *,
    native_register: Callable[[type], Any] | None = None,
    native_unregister: Callable[[type], Any] | None = None,
    reason_prefix: str = "CLASS",
) -> tuple[bool, bool]:
    """Register one exact class without assuming RNA ID equals Python name."""
    if not isinstance(cls, type) or not current_generation():
        mark_restart_required(f"{reason_prefix}_REGISTER_WITHOUT_GENERATION")
        return (False, False)
    _strip_redo_panel_from_owned_operator(cls)
    preflight = class_registration_preflight(cls)
    if preflight == "CURRENT":
        return (True, False)
    if preflight not in {"CLEAN", "RECORDED_UNREGISTERED"}:
        mark_restart_required(f"{reason_prefix}_REGISTRATION_PREFLIGHT_{preflight}")
        return (False, False)
    register_fn = native_register
    unregister_fn = native_unregister
    if register_fn is None and bpy is not None:
        register_fn = getattr(getattr(bpy, "utils", None), "register_class", None)
    if unregister_fn is None and bpy is not None:
        unregister_fn = getattr(getattr(bpy, "utils", None), "unregister_class", None)
    if not callable(register_fn):
        mark_restart_required(f"{reason_prefix}_NATIVE_REGISTER_UNAVAILABLE")
        return (False, False)
    try:
        register_fn(cls)
    except Exception:
        mark_restart_required(f"{reason_prefix}_NATIVE_REGISTRATION_FAILED")
        return (False, False)

    evidence = _registered_class_evidence(cls)
    if not evidence.get("valid"):
        # Never guess ownership from a Python name.  A rollback is attempted only
        # when exact canonical resolver evidence exists for the just-created class.
        _local_rollback_new_class(cls, unregister_fn, evidence)
        mark_restart_required(f"{reason_prefix}_CLASS_RNA_POSTCONDITION_FAILED")
        return (False, False)
    if not record_class(cls, remover=unregister_fn, newly_registered=True):
        _local_rollback_new_class(cls, unregister_fn, evidence)
        mark_restart_required(f"{reason_prefix}_CLASS_LEDGER_FAILED")
        return (False, False)
    if not class_is_current(cls):
        unregister_class_exact(
            cls,
            native_unregister=unregister_fn,
            reason_prefix=f"{reason_prefix}_POSTCONDITION_ROLLBACK",
        )
        mark_restart_required(f"{reason_prefix}_CLASS_POSTCONDITION_FAILED")
        return (False, False)
    return (True, True)


def unregister_class_exact(
    cls: type,
    *,
    native_unregister: Callable[[type], Any] | None = None,
    reason_prefix: str = "CLASS",
) -> bool:
    """Unregister only the exact class object and recorded canonical RNA ID."""
    item = _class_record(cls)
    if not isinstance(cls, type) or not isinstance(item, dict) or not class_recorded_current(cls):
        return False
    if item.get("native_registered", True) is False:
        return class_is_safely_unregistered(cls)
    if not class_is_current(cls):
        mark_restart_required(f"{reason_prefix}_UNREGISTER_OWNERSHIP_UNPROVEN")
        return False
    expected_identifier = str(item.get("class_rna_identifier") or "")
    if not expected_identifier:
        mark_restart_required(f"{reason_prefix}_UNREGISTER_IDENTIFIER_MISSING")
        return False
    unregister_fn = native_unregister or item.get("remover")
    if unregister_fn is None and bpy is not None:
        unregister_fn = getattr(getattr(bpy, "utils", None), "unregister_class", None)
    if not callable(unregister_fn):
        mark_restart_required(f"{reason_prefix}_NATIVE_UNREGISTER_UNAVAILABLE")
        return False
    try:
        unregister_fn(cls)
    except Exception:
        if not _class_object_is_natively_unregistered(cls):
            mark_restart_required(f"{reason_prefix}_NATIVE_UNREGISTER_FAILED")
            return False
    if not _class_object_is_natively_unregistered(cls):
        mark_restart_required(f"{reason_prefix}_UNREGISTER_READBACK_FAILED")
        return False
    # Verify that this exact class is no longer reachable through its recorded
    # canonical identifier.  A newly appearing foreign occupant is never touched.
    base = item.get("class_base_identity")
    resolver_state, resolved = _resolver_lookup(base if isinstance(base, type) else None, expected_identifier, cls)
    if resolver_state == "EXACT":
        mark_restart_required(f"{reason_prefix}_UNREGISTER_RESOLVER_STILL_EXACT")
        return False
    if resolver_state in {"FOREIGN", "ERROR"}:
        mark_restart_required(f"{reason_prefix}_UNREGISTER_CANONICAL_CONFLICT")
        return False
    item["native_registered"] = False
    if not class_is_safely_unregistered(cls):
        mark_restart_required(f"{reason_prefix}_UNREGISTER_PUBLICATION_CONFLICT")
        return False
    return True


def rna_property_signature(descriptor: Any) -> tuple[str, str, str]:
    """Return Blender-stable RNA metadata for one property wrapper.

    Blender 5.1 may create a new Python wrapper on each
    ``bl_rna.properties.get()`` call.  Wrapper ``is`` identity is therefore
    diagnostic only and must never decide ownership.  The stable contract is
    the property RNA type, property identifier and fixed StructRNA identifier.
    """
    if descriptor is None:
        return ("", "", "")
    try:
        property_type = str(getattr(descriptor, "type", "") or "")
    except Exception:
        property_type = ""
    property_identifier = _rna_identifier(descriptor)
    try:
        fixed_identifier = _rna_identifier(getattr(descriptor, "fixed_type", None))
    except Exception:
        fixed_identifier = ""
    return (property_type, property_identifier, fixed_identifier)


def live_property_signature(owner_type: type, property_name: str) -> tuple[str, str, str]:
    return rna_property_signature(_rna_property(owner_type, property_name))


def _descriptor_matches_signature(descriptor: Any, signature: Any) -> bool:
    return bool(
        isinstance(signature, tuple)
        and len(signature) == 3
        and rna_property_signature(descriptor) == signature
        and bool(signature[0])
        and bool(signature[1])
    )


def _property_record_matches_live(
    item: dict[str, Any],
    owner_type: type,
    property_name: str,
    *,
    property_group_class: type | None = None,
    descriptor: Any | None = None,
) -> bool:
    """Validate a current-generation property without Python wrapper identity.

    Ownership comes from the explicit record written immediately after this
    generation successfully created the property.  Stable RNA metadata proves
    that the live slot still has the same shape; it does not authorize adoption
    of a pre-existing slot because pre-existing slots are never recorded.
    """
    record = active_record()
    generation = current_generation()
    if record is None or not generation or not isinstance(item, dict):
        return False
    if item.get("registered_by_module_identity") is not _MODULE_IDENTITY:
        return False
    if not isinstance(item.get("registration_token"), str) or not item.get("registration_token"):
        return False
    if item.get("owner_type_identity") is not owner_type:
        return False
    if item.get("property_name") != str(property_name):
        return False
    if str(item.get("generation") or "") != generation or item.get("revision") != record.get("revision"):
        return False
    live_descriptor = _rna_property(owner_type, property_name)
    if live_descriptor is None:
        return False
    stored_signature = item.get("descriptor_signature")
    if not _descriptor_matches_signature(live_descriptor, stored_signature):
        return False
    if descriptor is not None and rna_property_signature(descriptor) != stored_signature:
        return False
    expected_class = item.get("property_group_class_identity")
    if property_group_class is not None and expected_class is not property_group_class:
        return False
    if isinstance(expected_class, type):
        expected_identifier = str(item.get("property_group_rna_identifier") or "")
        if not expected_identifier or expected_identifier != _class_rna_identifier(expected_class):
            return False
        if stored_signature[2] != expected_identifier:
            return False
        if not class_is_current(expected_class):
            return False
    return True


def record_property(
    owner_type: type,
    property_name: str,
    property_group_class: type,
    *,
    remover: Callable[..., Any] | None = None,
    newly_registered: bool = True,
) -> bool:
    """Record a Pointer/CollectionProperty created by this generation.

    The record is explicit proof of the registration event.  Blender RNA Python
    wrapper identity is intentionally not stored as authority because repeated
    reads can return distinct wrappers for the same native property.
    """
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    if not isinstance(owner_type, type) or not isinstance(property_group_class, type):
        return False
    descriptor = _rna_property(owner_type, property_name)
    signature = rna_property_signature(descriptor)
    class_identifier = _class_rna_identifier(property_group_class)
    if descriptor is None or signature[1] != str(property_name):
        return False
    if signature[0] not in {"POINTER", "COLLECTION"}:
        return False
    if not class_identifier or signature[2] != class_identifier:
        return False
    publication_state, _published = class_publication_state(property_group_class)
    if publication_state not in {"ABSENT", "EXACT"}:
        return False
    if not class_is_current(property_group_class):
        return False
    key = f"{id(owner_type)}:{property_name}"
    existing = record.setdefault("properties", {}).get(key)
    if isinstance(existing, dict):
        # Idempotence is allowed only for the exact current record and live RNA
        # signature.  A dynamic feature may recreate its own storage class and
        # pointer within the same package generation, but the previous record
        # can be replaced only after its exact old class has been explicitly
        # unregistered and is no longer live.  This never authorizes adoption of
        # a pre-existing or foreign property.
        if _property_record_matches_live(
            existing,
            owner_type,
            property_name,
            property_group_class=property_group_class,
            descriptor=descriptor,
        ):
            return True
        old_class = existing.get("property_group_class_identity")
        replace_safe = bool(
            existing.get("registered_by_module_identity") is _MODULE_IDENTITY
            and str(existing.get("generation") or "") == current_generation()
            and existing.get("revision") == record.get("revision")
            and existing.get("owner_type_identity") is owner_type
            and existing.get("property_name") == str(property_name)
            and isinstance(old_class, type)
            and old_class is not property_group_class
            and class_is_safely_unregistered(old_class)
        )
        if not replace_safe:
            return False
    record["properties"][key] = {
        "owner_type_identity": owner_type,
        "property_name": str(property_name),
        "descriptor_signature": signature,
        "property_group_class_identity": property_group_class,
        "property_group_rna_identifier": class_identifier,
        "registered_by_module_identity": _MODULE_IDENTITY,
        "registration_token": uuid.uuid4().hex,
        "remover": remover,
        "newly_registered": bool(newly_registered),
        "generation": record.get("generation"),
        "revision": record.get("revision"),
    }
    return _property_record_matches_live(
        record["properties"][key],
        owner_type,
        property_name,
        property_group_class=property_group_class,
    )

def property_is_current(
    owner_type: type,
    property_name: str,
    property_group_class: type | None = None,
    *,
    descriptor: Any | None = None,
) -> bool:
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    key = f"{id(owner_type)}:{property_name}"
    item = record.get("properties", {}).get(key)
    return _property_record_matches_live(
        item,
        owner_type,
        property_name,
        property_group_class=property_group_class,
        descriptor=descriptor,
    )

def record_scalar_property(
    owner_type: type,
    property_name: str,
    owner_identity: Any,
    *,
    remover: Callable[..., Any] | None = None,
    newly_registered: bool = True,
) -> bool:
    """Record a non-PointerProperty using an explicit generation ledger."""
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    descriptor = _rna_property(owner_type, property_name)
    signature = rna_property_signature(descriptor)
    if descriptor is None or owner_identity is None or signature[1] != str(property_name):
        return False
    key = f"{id(owner_type)}:{property_name}"
    existing = record.setdefault("properties", {}).get(key)
    if isinstance(existing, dict):
        return bool(
            existing.get("property_owner_identity") is owner_identity
            and _property_record_matches_live(existing, owner_type, property_name, descriptor=descriptor)
        )
    record["properties"][key] = {
        "owner_type_identity": owner_type,
        "property_name": str(property_name),
        "descriptor_signature": signature,
        "property_group_class_identity": None,
        "property_group_rna_identifier": "",
        "property_owner_identity": owner_identity,
        "registered_by_module_identity": _MODULE_IDENTITY,
        "registration_token": uuid.uuid4().hex,
        "remover": remover,
        "newly_registered": bool(newly_registered),
        "generation": record.get("generation"),
        "revision": record.get("revision"),
    }
    return _property_record_matches_live(record["properties"][key], owner_type, property_name)

def property_recorded_current(owner_type: type, property_name: str, *, descriptor: Any | None = None) -> bool:
    """Return True only for a slot explicitly created by this generation."""
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    key = f"{id(owner_type)}:{property_name}"
    return _property_record_matches_live(
        record.get("properties", {}).get(key),
        owner_type,
        property_name,
        descriptor=descriptor,
    )

def scalar_property_is_current(owner_type: type, property_name: str, owner_identity: Any) -> bool:
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    key = f"{id(owner_type)}:{property_name}"
    item = record.get("properties", {}).get(key)
    return bool(
        isinstance(item, dict)
        and item.get("property_owner_identity") is owner_identity
        and _property_record_matches_live(item, owner_type, property_name)
    )

def rollback_new_items(class_items: list[type], property_items: list[tuple[type, str]]) -> bool:
    """Rollback only exact resources created by the active transaction.

    Captured remover identities are authoritative.  A descriptor/class that no
    longer matches is left untouched and causes a restart-required result.
    """
    record = active_record()
    generation = current_generation()
    if record is None or not generation:
        return False
    properties = record.get("properties", {}) if isinstance(record.get("properties"), dict) else {}
    classes = record.get("classes", {}) if isinstance(record.get("classes"), dict) else {}
    ok = True
    requested_properties = {(owner, str(name)) for owner, name in property_items}
    requested_classes = set(class_items)

    for key, item in reversed(tuple(properties.items())):
        if not isinstance(item, dict) or item.get("generation") != generation or item.get("newly_registered") is not True:
            continue
        owner = item.get("owner_type_identity")
        name = str(item.get("property_name") or "")
        if (owner, name) not in requested_properties:
            continue
        live = _rna_property(owner, name) if isinstance(owner, type) else None
        if live is None:
            properties.pop(key, None)
            continue
        if not _descriptor_matches_signature(live, item.get("descriptor_signature")):
            ok = False
            mark_restart_required("ROLLBACK_PROPERTY_RNA_SIGNATURE_MISMATCH")
            continue
        remover = item.get("remover")
        try:
            if callable(remover):
                remover(live)
            else:
                delattr(owner, name)
        except TypeError:
            try:
                remover()
            except Exception:
                ok = False
                continue
        except Exception:
            ok = False
            continue
        if _rna_property(owner, name) is None:
            properties.pop(key, None)
        else:
            ok = False

    for key, item in reversed(tuple(classes.items())):
        if not isinstance(item, dict) or item.get("generation") != generation or item.get("newly_registered") is not True:
            continue
        cls = item.get("class_identity")
        if cls not in requested_classes:
            continue
        if class_is_safely_unregistered(cls):
            classes.pop(key, None)
            continue
        if not class_is_current(cls):
            ok = False
            mark_restart_required("ROLLBACK_CLASS_IDENTITY_MISMATCH")
            continue
        remover = item.get("remover")
        if not unregister_class_exact(
            cls,
            native_unregister=remover if callable(remover) else None,
            reason_prefix="ROLLBACK_CLASS",
        ):
            ok = False
            continue
        if class_is_safely_unregistered(cls):
            classes.pop(key, None)
        else:
            ok = False
    return ok



def rollback_current_generation_new_items() -> bool:
    """Rollback every current-generation item marked newly_registered.

    This is used only when the root registration transaction fails.  Existing
    items and every old-generation RNA identity remain untouched.
    """
    record = active_record()
    if not isinstance(record, dict):
        return False
    class_items = [
        item.get("class_identity") for item in record.get("classes", {}).values()
        if isinstance(item, dict) and item.get("newly_registered") is True
    ]
    property_items = [
        (item.get("owner_type_identity"), str(item.get("property_name") or ""))
        for item in record.get("properties", {}).values()
        if isinstance(item, dict) and item.get("newly_registered") is True
    ]
    return rollback_new_items(
        [item for item in class_items if isinstance(item, type)],
        [(owner, name) for owner, name in property_items if isinstance(owner, type) and name],
    )


def register_lease(
    *,
    feature: str,
    space: str,
    region: str,
    handle: Any,
    native_remover: Callable[..., Any],
    remove_args: tuple[Any, ...] = (),
    remove_kwargs: dict[str, Any] | None = None,
    is_registered: Callable[[Any], bool] | None = None,
) -> bool:
    generation = current_generation()
    if not generation or handle is None or not callable(native_remover):
        return False
    key = f"{PACKAGE_ID}:{feature}:{space}:{region}"
    root = ledger()
    slots = root.setdefault("lease_slots", {})
    old = slots.get(key)
    if isinstance(old, dict):
        if (
            str(old.get("generation") or "") == generation
            and old.get("handle") is handle
            and not old.get("removed")
        ):
            return True
        if not (old.get("removed") or _remove_lease_record(old)):
            root["lease_cleanup_failures"] = (key,)
            return False
        slots.pop(key, None)
    slots[key] = {
        "package": PACKAGE_ID,
        "feature": str(feature),
        "space": str(space),
        "region": str(region),
        "generation": generation,
        "handle": handle,
        "native_remover": native_remover,
        "remove_args": tuple(remove_args),
        "remove_kwargs": dict(remove_kwargs or {}),
        "is_registered": is_registered,
        "removed": False,
    }
    root["lease_cleanup_failures"] = ()
    return True


def remove_lease(*, feature: str, space: str, region: str, any_generation: bool = False) -> bool:
    key = f"{PACKAGE_ID}:{feature}:{space}:{region}"
    slots = ledger().setdefault("lease_slots", {})
    record = slots.get(key)
    if not isinstance(record, dict):
        return True
    if not any_generation and str(record.get("generation") or "") != current_generation():
        return False
    ok = bool(record.get("removed")) or _remove_lease_record(record)
    if ok:
        slots.pop(key, None)
    return ok


def remove_feature_leases(feature: str, *, any_generation: bool = False) -> int:
    slots = ledger().setdefault("lease_slots", {})
    removed = 0
    generation = current_generation()
    for key, record in list(slots.items()):
        if not isinstance(record, dict) or record.get("feature") != feature:
            continue
        if not any_generation and str(record.get("generation") or "") != generation:
            continue
        if record.get("removed") or _remove_lease_record(record):
            slots.pop(key, None)
            removed += 1
    return removed


def _rollback_recorded_rna(record: dict[str, Any]) -> tuple[bool, tuple[str, ...]]:
    """Release only exact newly-registered RNA owned by this generation."""
    generation = str(record.get("generation") or "")
    failures: list[str] = []
    properties = record.get("properties") if isinstance(record.get("properties"), dict) else {}
    for key, item in reversed(list(properties.items())):
        if not isinstance(item, dict) or item.get("generation") != generation or item.get("newly_registered") is not True:
            continue
        owner_type = item.get("owner_type_identity")
        property_name = str(item.get("property_name") or "")
        expected_signature = item.get("descriptor_signature")
        live_descriptor = _rna_property(owner_type, property_name) if isinstance(owner_type, type) else None
        if live_descriptor is None:
            properties.pop(key, None)
            continue
        if not _descriptor_matches_signature(live_descriptor, expected_signature):
            failures.append(f"property-rna-signature:{key}")
            continue
        remover = item.get("remover")
        try:
            if callable(remover):
                remover(None)
            else:
                delattr(owner_type, property_name)
        except Exception:
            failures.append(f"property-remove:{key}")
            continue
        if _rna_property(owner_type, property_name) is not None:
            failures.append(f"property-readback:{key}")
            continue
        properties.pop(key, None)

    classes = record.get("classes") if isinstance(record.get("classes"), dict) else {}
    for key, item in reversed(list(classes.items())):
        if not isinstance(item, dict) or item.get("generation") != generation or item.get("newly_registered") is not True:
            continue
        cls = item.get("class_identity")
        if not isinstance(cls, type):
            failures.append(f"class-invalid:{key}")
            continue
        if class_is_safely_unregistered(cls):
            classes.pop(key, None)
            continue
        if not class_is_current(cls):
            failures.append(f"class-identity:{key}")
            continue
        remover = item.get("remover")
        if not unregister_class_exact(
            cls,
            native_unregister=remover if callable(remover) else None,
            reason_prefix="GENERATION_CLASS",
        ):
            failures.append(f"class-remove:{key}")
            continue
        if not class_is_safely_unregistered(cls):
            failures.append(f"class-readback:{key}")
            continue
        classes.pop(key, None)
    return not failures, tuple(failures)



def abort_generation_after_rollback() -> bool:
    """Release a failed generation only after exact new-item rollback emptied it.

    No pre-existing or foreign RNA is touched.  If any class/property record
    remains, ownership is unproven and the live generation is retained with a
    restart-required state.
    """
    root = ledger()
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    generation = str(record.get("generation") or "")
    if not generation:
        return False
    # Finite callbacks are removable only through their captured native remover.
    collect_stale_leases()
    if root.get("lease_cleanup_failures"):
        mark_restart_required("FAILED_REGISTER_NATIVE_LEASE_REMOVE_FAILED")
        record["status"] = "REGISTER_ROLLBACK_FAILED"
        return False
    classes = record.get("classes") if isinstance(record.get("classes"), dict) else {}
    properties = record.get("properties") if isinstance(record.get("properties"), dict) else {}
    provisional = record.get("provisional_classes") if isinstance(record.get("provisional_classes"), dict) else {}
    if classes or properties or provisional:
        mark_restart_required("FAILED_REGISTER_RNA_ROLLBACK_INCOMPLETE")
        record["status"] = "REGISTER_ROLLBACK_FAILED"
        return False
    record["status"] = "ABORTED"
    root["active"] = None
    return True

def finish_generation(*, release_rna: bool) -> bool:
    root = ledger()
    record = active_record()
    if record is None or record.get("module_identity") is not _MODULE_IDENTITY:
        return False
    # Remove every finite native resource owned by this exact generation. The
    # per-slot remover captured at registration time is authoritative.
    slots = root.setdefault("lease_slots", {})
    generation = str(record.get("generation") or "")
    failures: list[str] = []
    for key, lease in list(slots.items()):
        if not isinstance(lease, dict):
            slots.pop(key, None)
            continue
        if str(lease.get("generation") or "") != generation:
            continue
        if lease.get("removed") or _remove_lease_record(lease):
            slots.pop(key, None)
        else:
            failures.append(str(key))
    root["lease_cleanup_failures"] = tuple(failures)
    if failures:
        mark_restart_required("CURRENT_GENERATION_NATIVE_LEASE_REMOVE_FAILED")
        record["status"] = "STOPPING_FAILED"
        return False
    if release_rna:
        rna_ok, rna_failures = _rollback_recorded_rna(record)
        root["rna_cleanup_failures"] = rna_failures
        if not rna_ok:
            mark_restart_required("CURRENT_GENERATION_RNA_ROLLBACK_FAILED")
            record["status"] = "STOPPING_FAILED"
            return False
        record["status"] = "RELEASED"
        root["active"] = None
        root["restart_required"] = None
    return True


def release_quiescent_ledger() -> str:
    """Release this module's exact empty ledger after a completed generation."""
    global _SESSION_LEDGER
    namespace = _namespace()
    root = namespace.get(NAMESPACE_KEY)
    if not isinstance(root, dict) or root is not _SESSION_LEDGER:
        return 'RETAINED_FOREIGN_OR_UNOWNED'
    quiescent = bool(
        root.get('active') is None
        and not root.get('lease_slots')
        and not root.get('restart_required')
        and not root.get('lease_cleanup_failures')
        and not root.get('rna_cleanup_failures')
    )
    if not quiescent:
        return 'RETAINED_NONQUIESCENT'
    if namespace.get(NAMESPACE_KEY) is not root:
        return 'RETAINED_IDENTITY_CHANGED'
    namespace.pop(NAMESPACE_KEY, None)
    _SESSION_LEDGER = None
    return 'RELEASED'



def current_ownership_conflicts() -> tuple[str, ...]:
    """Report identity conflicts for the exact active generation.

    Missing resources are tolerated during an orderly nested teardown.  A live
    same-name class with a different identity or property with different stable
    RNA metadata is never adopted or removed and requires a process restart.
    """
    record = active_record()
    generation = current_generation()
    if record is None or not generation:
        return ("no-current-generation",)
    revision = record.get("revision")
    conflicts: list[str] = []
    provisional = record.get("provisional_classes")
    if isinstance(provisional, dict) and provisional:
        conflicts.extend(f"class-provisional:{key}" for key in sorted(provisional))
    for key, item in tuple(record.get("classes", {}).items()):
        if not isinstance(item, dict):
            conflicts.append(f"class-record:{key}")
            continue
        if str(item.get("generation") or "") != generation or item.get("revision") != revision:
            conflicts.append(f"class-generation:{key}")
            continue
        cls = item.get("class_identity")
        if not isinstance(cls, type):
            conflicts.append(f"class-identity:{key}")
            continue
        if item.get("native_registered", True) is not True:
            if not class_is_safely_unregistered(cls):
                conflicts.append(f"class-unexpected-live:{key}")
            continue
        expected_identifier = str(item.get("class_rna_identifier") or "")
        if not expected_identifier or _class_rna_identifier(cls) != expected_identifier:
            conflicts.append(f"class-rna:{key}")
            continue
        publication_state, _published = class_publication_state(cls)
        if publication_state not in {"ABSENT", "EXACT"}:
            conflicts.append(f"class-live-identity:{key}")
    for key, item in tuple(record.get("properties", {}).items()):
        if not isinstance(item, dict):
            conflicts.append(f"property-record:{key}")
            continue
        if str(item.get("generation") or "") != generation or item.get("revision") != revision:
            conflicts.append(f"property-generation:{key}")
            continue
        owner = item.get("owner_type_identity")
        name = str(item.get("property_name") or "")
        if not isinstance(owner, type) or not name:
            conflicts.append(f"property-owner:{key}")
            continue
        live = _rna_property(owner, name)
        if live is None:
            conflicts.append(f"property-missing:{key}")
        elif not _descriptor_matches_signature(live, item.get("descriptor_signature")):
            conflicts.append(f"property-live-rna-signature:{key}")
    return tuple(conflicts)
