# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,label
from ._radial_navigation import shortcut

class WM_OT_pack_res_and_lib(bpy.types.Operator):
    bl_idname='file.pack_res_and_lib'
    bl_label='Pack Resources and Libraries'
    pack:bpy.props.BoolProperty(name='Pack files',default=False)
    def execute(self,context):
        if self.pack:
            ops=[(bpy.ops.file.pack_all,{})]
            if bpy.data.libraries:ops.append((bpy.ops.file.pack_libraries,{}))
        else:
            ops=[(bpy.ops.file.unpack_all,{'method':'USE_ORIGINAL'})]
            if any(lib.packed_file for lib in bpy.data.libraries):ops.append((bpy.ops.file.unpack_libraries,{}))
        for op,kw in ops:
            status=op(**kw)
            if 'FINISHED' not in status:
                self.report({'WARNING'},label('The file operation did not finish.','ファイル処理が完了しませんでした。'))
                return {'CANCELLED'}
        return {'FINISHED'}

class PIE_MT_file(bpy.types.Menu):
    bl_idname='PIE_MT_file'
    bl_label='File'
    def draw(self,context):
        p=self.layout.menu_pie()
        action(p,'wm.open_mainfile','Open project','プロジェクトを開く',icon='FILEBROWSER')
        action(p,'wm.save_as_mainfile','Save as…','名前を付けて保存…',icon='FILE_TICK')
        p.menu('TOPBAR_MT_file_export',text=label('Export files','書き出し'),icon='EXPORT')
        p.menu('TOPBAR_MT_file_import',text=label('Import files','読み込み'),icon='IMPORT')
        action(p,'wm.call_menu_pie','Linked files and resources','リンクと外部素材',name='PIE_MT_library')
        action(p,'wm.save_mainfile','Save increment','連番で保存',incremental=True)
        p.menu('TOPBAR_MT_file_open_recent',icon='FILE_FOLDER')
        p.menu('TOPBAR_MT_file_recover',icon='RECOVER_LAST')

class PIE_MT_library(bpy.types.Menu):
    bl_idname='PIE_MT_library'
    bl_label='Library'
    def draw(self,context):
        p=self.layout.menu_pie()
        action(p,'wm.link','Link data','データをリンク',icon='LINK_BLEND')
        action(p,'wm.append','Append data','データを追加',icon='APPEND_BLEND')
        action(p,'object.make_local','Make all data local','すべてローカル化',type='ALL')
        p.prop(bpy.data,'use_autopack',text=label('Pack on save','保存時にパック'))
        action(p,'file.pack_res_and_lib','Pack images and libraries','画像とライブラリをパック',pack=True)
        action(p,'file.pack_res_and_lib','Unpack original files','元の場所に展開',pack=False)
        action(p,'file.make_paths_relative','Use relative paths','相対パスに変換')
        action(p,'file.make_paths_absolute','Use absolute paths','絶対パスに変換')

def draw_revert(menu,context):
    action(menu.layout,'wm.revert_mainfile','Reopen from disk','保存済みファイルを開き直す',icon='FILE_REFRESH')

registry=[WM_OT_pack_res_and_lib,PIE_MT_library,PIE_MT_file]
def register():
    shortcut(PIE_MT_file.bl_idname,'Window','S','wm.save_mainfile',ctrl=True)
    bpy.types.TOPBAR_MT_file_recover.prepend(draw_revert)
def unregister():
    bpy.types.TOPBAR_MT_file_recover.remove(draw_revert)
