# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Switch the transform gizmos in the current viewport."""
import bpy
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only

AXES=(('LOC','show_gizmo_object_translate'),('ROT','show_gizmo_object_rotate'),('SCALE','show_gizmo_object_scale'))
MODES=[
    ('ROT','Rotate','回転','CON_ROTLIKE'),('SCALE','Scale','拡縮','CON_SIZELIKE'),
    ('NONE','Hide transform gizmos','移動・回転・拡縮を隠す','X'),('LOC','Move','移動','CON_LOCLIKE'),
    ('LOCROT','Move and rotate','移動と回転','CON_ROTLIKE'),('LOCSCALE','Move and scale','移動と拡縮','CON_SIZELIKE'),
    ('LOCROTSCALE','Move, rotate and scale','移動・回転・拡縮','CON_LOCLIKE')]

class VIEW3D_OT_set_manipulator(bpy.types.Operator):
    bl_idname='view3d.set_manipulator'
    bl_label='Set Manipulator Type'
    manipulator:bpy.props.EnumProperty(name='Manipulator',items=[(code,en,'') for code,en,ja,icon in MODES],default='LOC')
    toggle:bpy.props.BoolProperty(name='Toggle',default=False,options={'SKIP_SAVE'})

    @classmethod
    def poll(cls,context):return isinstance(context.space_data,bpy.types.SpaceView3D)
    def invoke(self,context,event):
        if event.shift:self.toggle=True
        return self.execute(context)
    def execute(self,context):
        space=context.space_data
        for key,attr in AXES:
            requested=key in self.manipulator
            if not self.toggle:setattr(space,attr,requested)
            elif requested:setattr(space,attr,not getattr(space,attr))
        return {'FINISHED'}

class PIE_MT_manipulator(bpy.types.Menu):
    bl_idname='PIE_MT_manipulator'
    bl_label='Manipulator'
    def draw(self,context):
        view=context.space_data
        pie=self.layout.menu_pie()
        ja=bpy.app.translations.locale.startswith('ja')
        for mode,en,jp,icon in MODES:
            active=all(bool(getattr(view,attr))==(key in mode) for key,attr in AXES)
            pie.operator('view3d.set_manipulator',text=jp if ja else en,icon=icon,depress=active).manipulator=mode

registry=[PIE_MT_manipulator,VIEW3D_OT_set_manipulator]
def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(keymap_name='3D View',pie_name=PIE_MT_manipulator.bl_idname,hotkey_kwargs=dict(type='SPACE',value='PRESS',alt=True),on_drag=False)
