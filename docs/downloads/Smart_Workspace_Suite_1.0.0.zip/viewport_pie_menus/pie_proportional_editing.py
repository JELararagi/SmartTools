# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,label
from ._radial_navigation import shortcut

CURVES={
 'SMOOTH':('Smooth','滑らか'),'SHARP':('Sharp','鋭く'),'ROOT':('Root','平方根'),
 'INVERSE_SQUARE':('Inverse square','逆二乗'),'LINEAR':('Linear','線形'),
 'SPHERE':('Sphere','球状'),'CONSTANT':('Constant','一定'),'RANDOM':('Random','ランダム')}

def control(layout,key):
    en,ja=CURVES[key]
    action(layout,'object.set_proportional_falloff',en,ja,falloff_shape=key)

class OBJECT_OT_set_proportional_falloff(bpy.types.Operator):
    bl_idname='object.set_proportional_falloff'
    bl_label='Set Proportional Editing Falloff'
    bl_options={'REGISTER','UNDO'}
    falloff_shape:bpy.props.StringProperty(name='Falloff')
    def execute(self,context):
        settings=context.tool_settings
        choices=settings.bl_rna.properties['proportional_edit_falloff'].enum_items
        if self.falloff_shape not in choices.keys():
            self.report({'WARNING'},label('Choose a falloff shape.','減衰の形を選んでください。'))
            return {'CANCELLED'}
        settings.proportional_edit_falloff=self.falloff_shape
        setattr(settings,'use_proportional_edit_objects' if context.mode=='OBJECT' else 'use_proportional_edit',True)
        return {'FINISHED'}

class PIE_MT_proportional_edit(bpy.types.Menu):
    bl_idname='PIE_MT_proportional_edit'
    bl_label='Proportional Edit'
    def draw(self,context):
        p=self.layout.menu_pie();tools=context.tool_settings;obj=context.mode=='OBJECT'
        control(p,'SMOOTH')
        p.menu('PIE_MT_proportional_edit_obj_more' if obj else 'PIE_MT_proportional_edit_mesh_more',text=label('Other falloffs','その他の減衰'))
        control(p,'SHARP')
        p.prop(tools,'use_proportional_edit_objects' if obj else 'use_proportional_edit',text=label('Proportional editing','プロポーショナル編集'))
        if obj:
            control(p,'ROOT');control(p,'INVERSE_SQUARE')
        else:
            p.prop(tools,'use_proportional_connected',text=label('Connected vertices','連結した頂点だけ'))
            p.prop(tools,'use_proportional_projected',text=label('Use projected distance','画面上の距離を使用'))
        control(p,'LINEAR');control(p,'SPHERE')

class PIE_MT_proportional_edit_obj_more(bpy.types.Menu):
    bl_idname='PIE_MT_proportional_edit_obj_more'
    bl_label='More Falloff Shapes'
    def draw(self,context):
        for key in ('CONSTANT','RANDOM'):control(self.layout,key)
class PIE_MT_proportional_edit_mesh_more(bpy.types.Menu):
    bl_idname='PIE_MT_proportional_edit_mesh_more'
    bl_label='More Falloff Shapes'
    def draw(self,context):
        for key in ('ROOT','INVERSE_SQUARE','CONSTANT','RANDOM'):control(self.layout,key)

registry=[OBJECT_OT_set_proportional_falloff,PIE_MT_proportional_edit_obj_more,PIE_MT_proportional_edit_mesh_more,PIE_MT_proportional_edit]
def register():
    for keymap,prop in [('Object Mode','use_proportional_edit_objects'),('Mesh','use_proportional_edit')]:
        shortcut(PIE_MT_proportional_edit.bl_idname,keymap,'O','wm.context_toggle',{'data_path':'scene.tool_settings.'+prop})
