# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,bind

class PIE_MT_mesh_delete(bpy.types.Menu):
    bl_idname='PIE_MT_mesh_delete'
    bl_label='Mesh Delete'
    def draw(self,context):
        pie=self.layout.menu_pie()
        cleanup=pie.column(align=True)
        action(cleanup,'mesh.dissolve_limited','Dissolve by angle','角度で溶解')
        action(cleanup,'mesh.delete_edgeloop','Remove edge loop','辺ループを削除')
        action(cleanup,'mesh.edge_collapse','Collapse edges','辺を集約')
        action(cleanup,'mesh.remove_doubles','Weld nearby vertices','近い頂点を統合')
        keep=pie.column(align=True)
        action(keep,'mesh.delete','Edges and faces only','辺と面だけを削除',type='EDGE_FACE')
        action(keep,'mesh.delete','Faces only','面だけを削除',type='ONLY_FACE')
        action(pie,'mesh.dissolve_edges','Dissolve edges','辺を溶解',icon='EDGESEL')
        action(pie,'mesh.delete','Delete edges','辺を削除',icon='EDGESEL',type='EDGE')
        action(pie,'mesh.delete','Delete vertices','頂点を削除',icon='VERTEXSEL',type='VERT')
        action(pie,'mesh.delete','Delete faces','面を削除',icon='FACESEL',type='FACE')
        action(pie,'mesh.dissolve_verts','Dissolve vertices','頂点を溶解',icon='VERTEXSEL')
        action(pie,'mesh.dissolve_faces','Dissolve faces','面を溶解',icon='FACESEL')

registry=[PIE_MT_mesh_delete]
def register():
    bind(PIE_MT_mesh_delete,'Mesh','X')
