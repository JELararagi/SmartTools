# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from .bs_utils.hotkeys import register_hotkey

def register():
    register_hotkey(
        'screen.area_join',
        hotkey_kwargs={'type': "ACCENT_GRAVE", 'value': "PRESS", 'alt': True},
        keymap_name="Window",
    )
