# SPDX-License-Identifier: GPL-3.0-or-later
"""Declare the workspace area-move shortcut."""

from .bs_utils.hotkeys import register_hotkey


def register():
    movement = dict(type="ACCENT_GRAVE", value="PRESS", alt=True)
    register_hotkey("screen.area_join", keymap_name="Window", hotkey_kwargs=movement)
