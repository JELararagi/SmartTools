# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,bind,label

class PIE_MT_preferences(bpy.types.Menu):
    bl_idname='PIE_MT_preferences'
    bl_label='Preferences'
    def draw(self,context):
        pie=self.layout.menu_pie()
        pie.operator_context='INVOKE_DEFAULT'
        action(pie,'wm.read_userpref','Reload saved settings','保存済みの設定を読み込む',icon='FILE_REFRESH')
        action(pie,'wm.save_userpref','Save preferences','現在の設定を保存',icon='FILE_TICK')
        pie.separator()
        pie.separator()
        action(pie,'wm.read_factory_userpref','Reset preferences','設定を初期値に戻す',icon='RECOVER_LAST')
        action(pie,'wm.save_homefile','Set startup scene','このシーンを起動ファイルに保存',icon='FILE_NEW')
        action(pie,'wm.read_factory_settings','Reset startup and preferences','起動シーンと設定を初期化',icon='RECOVER_LAST')
        pie.prop(context.preferences,'use_preferences_save',text=label('Save preferences automatically','設定を自動保存'))

registry=[PIE_MT_preferences]
def register():
    bind(PIE_MT_preferences,'Window','U',ctrl=True)
