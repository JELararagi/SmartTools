# SPDX-License-Identifier: GPL-3.0-or-later
"""Provide viewport pie bindings for keymap presets without native controls."""

import bpy

from .bs_utils.hotkeys import register_hotkey
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


def register():
    active = bpy.context.window_manager.keyconfigs.active
    if hasattr(active.preferences, "spacebar_action"):
        return

    viewport = "3D View"
    region = "Object Non-modal"
    bindings = (
        (region, "view3d.object_mode_pie_or_toggle", "TAB", "PRESS", {"ctrl": True}, {}),
        (viewport, "wm.call_menu_pie", "Z", "PRESS", {}, {"name": "VIEW3D_MT_shading_ex_pie"}),
        (viewport, "wm.call_menu_pie", "ACCENT_GRAVE", "CLICK_DRAG", {}, {"name": "VIEW3D_MT_view_pie"}),
        (viewport, "view3d.navigate", "ACCENT_GRAVE", "CLICK", {}, {}),
    )
    for keymap, operator, key, event, modifiers, operation in bindings:
        args = {"keymap_name": keymap, "hotkey_kwargs": {"type": key, "value": event, **modifiers}}
        if operation:
            args["op_kwargs"] = operation
        register_hotkey(operator, **args)

    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="3D View Generic",
        pie_name="WM_MT_region_toggle_pie",
        hotkey_kwargs={"type": "N", "value": "PRESS"},
        default_fallback_op="wm.context_toggle",
        default_fallback_kwargs={"data_path": "space_data.show_region_ui"},
        on_drag=True,
    )
