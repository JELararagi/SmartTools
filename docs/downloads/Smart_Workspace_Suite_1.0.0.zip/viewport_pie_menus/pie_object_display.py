"""Object display and normal operations for the viewport pie."""
import bpy
from bpy.types import Menu, Operator

from .. import ui_icons
from ..translation import localized_layout, ui_pair
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


def _mesh_objects(context):
    return (obj for obj in context.selected_objects if obj.type == "MESH")


class PIE_MT_object_display(Menu):
    bl_idname = "PIE_MT_object_display"
    bl_label = "Object Display"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def draw(self, context):
        pie = localized_layout(self.layout, context).menu_pie()
        obj = context.active_object
        supports_surface = obj.type in {"MESH", "CURVE"}
        bones = obj.data if obj.type == "ARMATURE" else None
        pie.prop(obj, "show_in_front", icon="XRAY")
        if supports_surface:
            pie.prop(obj, "show_wire", text="Wireframe", icon="SHADING_WIRE")
        else:
            pie.separator()
        pie.prop_menu_enum(obj, "display_type", text="Display Mode", icon="THREE_DOTS")
        if supports_surface:
            column = pie.box().column(align=True)
            column.label(text="Color")
            color = column.row(align=True)
            color.prop(obj, "color", text="")
            copy = ui_icons.operator(
                color, "view3d.copy_property_to_selected", text="", name="copy",
                fallback="LOOP_FORWARDS", emboss=False,
            )
            copy.rna_path = "color"
        else:
            pie.separator()
        named_object = bones if bones is not None else obj
        names = ("show_names", "Bone Names") if bones is not None else ("show_name", "Object Name")
        pie.prop(named_object, names[0], text=names[1], icon="FILE_TEXT")
        visibility = pie.box().column(align=True)
        visibility.label(text="Visible:")
        for field, label in (("hide_viewport", "Viewport"), ("hide_render", "Render")):
            hidden = getattr(obj, field)
            visibility.prop(obj, field, text=label, invert_checkbox=hidden,
                            icon="RESTRICT_VIEW_ON" if hidden else "RESTRICT_VIEW_OFF")
        if bones is not None:
            pie.prop(bones, "show_axes", text="Bone Axes", icon="EMPTY_AXIS")
        else:
            pie.prop(obj, "show_axis", icon="EMPTY_AXIS")
        if supports_surface:
            pie.menu("OBJECT_MT_set_object_shading", icon="THREE_DOTS")
        elif bones is not None:
            pie.prop_menu_enum(bones, "display_type", text="Bone Display", icon="THREE_DOTS")
        elif obj.type == "EMPTY":
            pie.prop_menu_enum(obj, "empty_display_type", icon="THREE_DOTS")
        else:
            pie.separator()


class OBJECT_MT_set_object_shading(Menu):
    bl_idname = "OBJECT_MT_set_object_shading"
    bl_label = "Shading Operators"

    def draw(self, context):
        menu = localized_layout(self.layout, context)
        menu.operator("object.shade_flat", icon="MESH_UVSPHERE")
        menu.operator("object.shade_smooth", icon="NODE_MATERIAL")
        if context.active_object.type == "MESH":
            menu.operator("object.add_weighted_normals", icon="MOD_NORMALEDIT")
            menu.operator("object.shade_auto_smooth", icon="MODIFIER")
            menu.separator()
            menu.operator("OBJECT_OT_reset_normals", icon="LOOP_BACK")


class OBJECT_OT_add_weighted_normals(Operator):
    """Add a Weighted Normal modifier where selected meshes lack one"""
    bl_idname = "object.add_weighted_normals"
    bl_label = "Weighted Normals"
    bl_options = {"UNDO"}

    def execute(self, context):
        for obj in _mesh_objects(context):
            if all(modifier.type != "WEIGHTED_NORMAL" for modifier in obj.modifiers):
                obj.modifiers.new(name="WeightedNormal", type="WEIGHTED_NORMAL")
        return {"FINISHED"}


class OBJECT_OT_reset_normals(Operator):
    """Clear custom normals, orient mesh faces consistently, and smooth shading"""
    bl_idname = "object.reset_normals"
    bl_label = "Reset Normals"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        if context.active_object is not None and context.active_object.type == "MESH":
            return True
        cls.poll_message_set(ui_pair(
            "The active object must be a mesh.",
            "アクティブなオブジェクトがメッシュではありません。", context,
        ))
        return False

    def execute(self, context):
        for obj in _mesh_objects(context):
            with context.temp_override(active_object=obj, object=obj):
                bpy.ops.mesh.customdata_custom_splitnormals_clear()
            obj.data.shade_smooth()
        previous_mode = context.active_object.mode
        if previous_mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
        try:
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.select_all(action="SELECT")
            bpy.ops.mesh.normals_make_consistent()
        finally:
            if previous_mode != "EDIT":
                bpy.ops.object.mode_set(mode=previous_mode)
        return {"FINISHED"}


registry = (
    PIE_MT_object_display,
    OBJECT_MT_set_object_shading,
    OBJECT_OT_add_weighted_normals,
    OBJECT_OT_reset_normals,
)


def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="3D View",
        pie_name="PIE_MT_object_display",
        hotkey_kwargs={"type": "W", "value": "PRESS", "shift": True},
        on_drag=False,
    )
