# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,bind,label

SHAPES=(
    ('mesh.primitive_uv_sphere_add','Sphere','UV球','MESH_UVSPHERE'),
    ('mesh.primitive_cube_add','Cube','立方体','MESH_CUBE'),
    ('mesh.primitive_monkey_add','Suzanne','スザンヌ','MESH_MONKEY'),
    ('mesh.primitive_plane_add','Plane','平面','MESH_PLANE'),
    ('mesh.primitive_cylinder_add','Cylinder','円柱','MESH_CYLINDER'),
    ('mesh.primitive_circle_add','Circle','円','MESH_CIRCLE'),
    ('curve.primitive_bezier_curve_add','Bézier curve','ベジェ曲線','CURVE_BEZCURVE'),
)
class PIE_MT_object_add(bpy.types.Menu):
    bl_idname='PIE_MT_object_add'
    bl_label='Add Object'
    def draw(self,context):
        pie=self.layout.menu_pie()
        for identifier,en,ja,icon in SHAPES:
            action(pie,identifier,en,ja,icon=icon)
        pie.menu('VIEW3D_MT_add',text=label('All object types','すべての種類'),icon='THREE_DOTS')

registry=[PIE_MT_object_add]
def register():
    bind(PIE_MT_object_add,'Object Mode','A',ctrl=True,shift=True)
