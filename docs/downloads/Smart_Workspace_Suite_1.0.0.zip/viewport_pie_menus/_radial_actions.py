# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Build labelled native controls for the Workspace radial menus."""
import bpy
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only

def label(en, ja):
    return ja if bpy.app.translations.locale.startswith('ja') else en

def action(layout, identifier, english, japanese, *, icon='NONE', **properties):
    button=layout.operator(identifier, text=label(english,japanese), icon=icon)
    for prop,value in properties.items():
        setattr(button,prop,value)

def bind(menu, keymap, key, **modifiers):
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name=keymap, pie_name=menu.bl_idname,
        hotkey_kwargs={'type':key,'value':'PRESS',**modifiers}, on_drag=False)
