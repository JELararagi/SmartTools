# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
import os
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty
import json
from .bs_utils.hotkeys import register_hotkey
from .. import runtime_ledger as _runtime_ledger


def idname_to_op_class(idname: str):
    parts = idname.split(".")
    op = bpy.ops
    for part in parts:
        op = getattr(op, part)
    return op


def _decode_operator_kwargs(value):
    data = value
    for _ in range(3):
        if isinstance(data, dict):
            return data
        if data is None:
            return {}
        if isinstance(data, str):
            text = data.strip()
            if not text:
                return {}
            try:
                data = json.loads(text)
                continue
            except Exception:
                return {}
        return {}
    return data if isinstance(data, dict) else {}


def _blank_tool_name(value) -> bool:
    text = str(value or '').strip()
    return text in {'', "''", '""'}


def _invalid_tool_set_fallback(operator_id: str, kwargs) -> bool:
    if str(operator_id or '').strip() != 'wm.tool_set_by_id':
        return False
    return _blank_tool_name(_decode_operator_kwargs(kwargs).get('name', ''))


class WM_OT_call_menu_pie_drag_only(Operator):
    """Summon a pie menu only on mouse drag, otherwise initiate an operator"""
    # This class is for cases where we want to overwrite a built-in shortcut which triggers on Press, 
    # with a pie menu that only appears on mouse drag. 
    # If the user does not mouse drag, invoke the provided fallback operator.
    # In register_drag_hotkey(), the fallback operator is automagically extracted from the keymap,
    # at the moment the hotkey is registered.

    bl_idname = "wm.call_menu_pie_drag_only"
    bl_label = "Pie Menu on Drag"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def update_kmi(self, context):
        if not hasattr(context, 'keymapitem'):
            return
        kmi = context.keymapitem # Set via UILayout.context_pointer_set().
        kmi.type = kmi.type

    name: StringProperty(options={'SKIP_SAVE'})
    on_drag: BoolProperty(
        name="On Drag",
        default=True,
        description="Only show this pie menu on mouse drag, otherwise execute a default operator",
        options={'SKIP_SAVE'},
        update=update_kmi,
    )
    fallback_operator: StringProperty(options={'SKIP_SAVE'})
    fallback_op_kwargs: StringProperty(default="{}", options={'SKIP_SAVE'})

    def invoke(self, context, event):
        if not self.on_drag:
            return self.execute(context)
        self.init_mouse_x = event.mouse_x
        self.init_mouse_y = event.mouse_y
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def invoke_fallback_operator(self):
        op_cls = idname_to_op_class(self.fallback_operator)
        if not op_cls:
            return

        fallback_op_kwargs = _decode_operator_kwargs(self.fallback_op_kwargs)
        if _invalid_tool_set_fallback(self.fallback_operator, fallback_op_kwargs):
            return

        if op_cls.poll():
            try:
                # 1. Execute the original operator and capture the result
                result = op_cls('INVOKE_DEFAULT', **fallback_op_kwargs)
                
                # 2. [Added] Check if it's a Save operation and report the message manually
                if 'FINISHED' in result and self.fallback_operator == 'wm.save_mainfile':
                    # Get current filename, or default to untitled
                    filename = os.path.basename(bpy.data.filepath) if bpy.data.filepath else "untitled.blend"
                    self.report({'INFO'}, f'Saved "{filename}"')
            except TypeError:
                # This can apparently happen sometimes, see issue #86.
                print(f"Pie Menu Fallback Operator failed: {self.fallback_operator}, {self.fallback_op_kwargs}")

    def modal(self, context, event):
        if event.value == 'RELEASE':
            if self.fallback_operator:
                self.invoke_fallback_operator()
            return {'CANCELLED'}
        threshold = context.preferences.inputs.drag_threshold
        delta_x = abs(event.mouse_x - self.init_mouse_x)
        delta_y = abs(event.mouse_y - self.init_mouse_y)
        if delta_x > threshold or delta_y > threshold:
            return self.execute(context)

        return {'RUNNING_MODAL'}

    def execute(self, context):
        bpy.ops.wm.call_menu_pie(name=self.name)
        return {'FINISHED'}

    @classmethod
    def register_drag_hotkey(
        cls,
        *,
        keymap_name: str,
        pie_name: str,
        hotkey_kwargs=None,
        default_fallback_op="",
        default_fallback_kwargs=None,
        on_drag=True,
    ):
        if hotkey_kwargs is None:
            hotkey_kwargs = {'type': "SPACE", 'value': "PRESS"}
        context = bpy.context
        fallback_operator = default_fallback_op
        fallback_op_kwargs = default_fallback_kwargs if default_fallback_kwargs is not None else {}

        # IMPORTANT:
        # Do NOT derive fallback operator/kwargs from the USER keyconfig.
        # Other add-ons (eg. Pie Menu Editor) can legitimately alter user keymaps,
        # and baking that dynamic state into our add-on KeyMapItem properties can
        # make Blender fail to match/restore user overrides across restarts.
        #
        # Instead, derive fallback from the DEFAULT (active preset) keyconfig,
        # which is stable and represents expected built-in behavior.
        default_kc = context.window_manager.keyconfigs.default
        km = default_kc.keymaps.get(keymap_name)
        if km:
            for kmi in km.keymap_items:
                for condition in [
                    kmi.idname != 'wm.call_menu_pie_drag_only',
                    kmi.type == hotkey_kwargs.get('type', ""),
                    kmi.value == hotkey_kwargs.get('value', "PRESS"),
                    kmi.ctrl == hotkey_kwargs.get('ctrl', False),
                    kmi.shift == hotkey_kwargs.get('shift', False),
                    kmi.alt == hotkey_kwargs.get('alt', False),
                    kmi.oskey == hotkey_kwargs.get('oskey', False),
                    kmi.any == hotkey_kwargs.get('any', False),
                    kmi.key_modifier == hotkey_kwargs.get('key_modifier', 'NONE'),
                    kmi.active
                ]:
                    if not condition:
                        break
                else:
                    candidate_operator = str(kmi.idname or '')
                    candidate_kwargs = {}
                    if kmi.properties:
                        candidate_kwargs = {k:getattr(kmi.properties, k) if hasattr(kmi.properties, k) else v for k, v in kmi.properties.items()}
                    if not _invalid_tool_set_fallback(candidate_operator, candidate_kwargs):
                        fallback_operator = candidate_operator
                        fallback_op_kwargs = candidate_kwargs
                    break

        if _invalid_tool_set_fallback(fallback_operator, fallback_op_kwargs):
            fallback_operator = ''
            fallback_op_kwargs = {}

        register_hotkey(
            cls.bl_idname,
            op_kwargs={
                'name': pie_name, 
                'fallback_operator': fallback_operator, 
                # Deterministic JSON (sort_keys=True) helps keep KMI identity stable across sessions.
                'fallback_op_kwargs': json.dumps(fallback_op_kwargs, sort_keys=True),
                'on_drag': on_drag,
            },
            hotkey_kwargs=hotkey_kwargs,
            keymap_name=keymap_name,
        )

def register():
    success, _newly_registered = _runtime_ledger.register_class_exact(
        WM_OT_call_menu_pie_drag_only,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='PIE_WRAPPER_CLASS',
    )
    if not success:
        raise RuntimeError('RESTART_REQUIRED: pie wrapper class ownership mismatch')

def unregister():
    if _runtime_ledger.class_recorded_current(WM_OT_call_menu_pie_drag_only):
        _runtime_ledger.unregister_class_exact(
            WM_OT_call_menu_pie_drag_only,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='PIE_WRAPPER_CLASS',
        )
