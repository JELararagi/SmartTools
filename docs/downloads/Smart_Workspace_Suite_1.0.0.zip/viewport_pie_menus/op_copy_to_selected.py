# SPDX-License-Identifier: GPL-3.0-or-later
"""Copy an RNA setting to other selected objects that expose it."""

from bpy.props import StringProperty
from bpy.types import Operator

from ..translation import ui_pair


class VIEW3D_OT_copy_property_to_selected(Operator):
    bl_idname = "view3d.copy_property_to_selected"
    bl_label = "Copy Property to Selected"
    bl_description = "Copy an active object setting to the selected objects that support it"
    bl_options = {"INTERNAL", "UNDO"}

    rna_path: StringProperty(
        name="RNA Path",
        description="Path from the object to the setting being copied",
        options={"SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        if context.active_object is None:
            cls.poll_message_set("No active object.")
            return False
        if not any(obj != context.active_object for obj in context.selected_objects):
            cls.poll_message_set("No selected objects.")
            return False
        return True

    def execute(self, context):
        active = context.active_object
        try:
            value = active.path_resolve(self.rna_path)
        except ValueError:
            self.report({"ERROR"}, ui_pair(
                f"The active object has no setting at {self.rna_path}.",
                f"アクティブオブジェクトに設定 {self.rna_path} がありません。", context))
            return {"CANCELLED"}

        path, _, attribute = self.rna_path.rpartition(".")
        copied = 0
        for target in context.selected_objects:
            if target == active:
                continue
            try:
                owner = target.path_resolve(path) if path else target
                target.path_resolve(self.rna_path)
                setattr(owner, attribute, value)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                continue
            copied += 1

        if not copied:
            self.report({"ERROR"}, ui_pair(
                f"No selected object accepts {self.rna_path}.",
                f"設定 {self.rna_path} をコピーできる選択オブジェクトがありません。", context))
            return {"CANCELLED"}
        self.report({"INFO"}, ui_pair(
            f"Copied the setting to {copied} objects.",
            f"{copied}個のオブジェクトに設定をコピーしました。", context))
        return {"FINISHED"}


registry = [VIEW3D_OT_copy_property_to_selected]
