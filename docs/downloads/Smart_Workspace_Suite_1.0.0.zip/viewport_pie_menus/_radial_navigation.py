# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bind a short press to a Blender action and a drag to the corresponding radial menu."""
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only

def shortcut(menu,context,key,click,arguments=None,**modifiers):
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name=context,pie_name=menu,hotkey_kwargs={'type':key,'value':'PRESS',**modifiers},
        default_fallback_op=click,default_fallback_kwargs=arguments,on_drag=True)
