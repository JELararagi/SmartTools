# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,bind

class PIE_MT_mesh_merge(bpy.types.Menu):
    bl_idname='PIE_MT_mesh_merge'
    bl_label='Mesh Merge'
    def draw(self,context):
        pie=self.layout.menu_pie()
        action(pie,'mesh.remove_doubles','Merge nearby vertices','近い頂点を統合',icon='AUTOMERGE_ON')
        action(pie,'mesh.merge','Selection centre','選択の中央',type='CENTER')
        action(pie,'mesh.merge','Collapse each edge group','辺のまとまりごとに集約',type='COLLAPSE')
        pie.separator()
        action(pie,'mesh.merge','First selected vertex','最初に選んだ頂点',type='FIRST')
        action(pie,'mesh.merge','Last selected vertex','最後に選んだ頂点',type='LAST')
        pie.separator()
        action(pie,'mesh.merge','At the 3D cursor','3Dカーソルの位置',icon='PIVOT_CURSOR',type='CURSOR')

registry=[PIE_MT_mesh_merge]
def register():
    bind(PIE_MT_mesh_merge,'Mesh','M')
