# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from ..translation import localized_layout
from bpy.types import Menu

from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


class PIE_MT_mesh_merge(Menu):
    bl_idname = "PIE_MT_mesh_merge"
    bl_label = "Mesh Merge"

    def draw(self, context):
        pie = localized_layout(self.layout, context).menu_pie()

        # 4 - LEFT
        pie.operator('mesh.remove_doubles', text="By Distance", icon='PROP_ON')

        # 6 - RIGHT
        pie.operator('mesh.merge', text="At Center", icon='SNAP_FACE_CENTER').type = (
            'CENTER'
        )

        # 2 - BOTTOM
        op = pie.operator('mesh.merge', text="Collapse", icon='FULLSCREEN_EXIT')
        op.type = 'COLLAPSE'

        # 8 - TOP
        pie.separator()

        # The implementation of Blender's built-in Merge operator is weird as hell:
        # If no geo is selected, the "At First" and "At Last" options cannot be drawn,
        # even though in such a case, NONE of the options will do ANYTHING anyways.
        # But it is what it is, I choose to be consistent.
        try:
            # This will raise an error if the option isn't available.
            op.type = 'FIRST'
            # 7 - TOP - LEFT
            pie.operator(
                'mesh.merge', text="At First", icon='TRACKING_REFINE_BACKWARDS'
            ).type = 'FIRST'
            # 9 - TOP - RIGHT
            pie.operator(
                'mesh.merge', text="At Last", icon='TRACKING_REFINE_FORWARDS'
            ).type = 'LAST'
        except:
            op.type = 'COLLAPSE'
            pie.separator()
            pie.separator()

        # 1 - BOTTOM - LEFT
        pie.separator()
        # 3 - BOTTOM - RIGHT
        pie.operator('mesh.merge', text="At 3D Cursor", icon='PIVOT_CURSOR').type = (
            'CURSOR'
        )


registry = [PIE_MT_mesh_merge]


def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="Mesh",
        pie_name=PIE_MT_mesh_merge.bl_idname,
        hotkey_kwargs={'type': "M", 'value': "PRESS"},
        on_drag=False,
    )
