"""Viewport shortcuts for baking or clearing object transforms."""
import bpy
from bpy.types import Menu, Operator

from ..translation import localized_layout
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


def _transform_action(pie, label, icon, location, rotation, scale):
    action = pie.operator("object.transform_apply", text=label, icon=icon)
    action.location = location
    action.rotation = rotation
    action.scale = scale


class PIE_MT_apply_transforms(Menu):
    bl_idname = "PIE_MT_apply_transforms"
    bl_label = "Apply Transforms"

    def draw(self, context):
        pie = localized_layout(self.layout, context).menu_pie()
        _transform_action(pie, "Rot/Scale", "CON_SIZELIKE", False, True, True)
        _transform_action(pie, "Loc/Rot/Scale", "ORIENTATION_LOCAL", True, True, True)
        pie.operator("object.apply_transforms_of_constraints",
                     text="Soft-Apply Constraints", icon="CONSTRAINT")
        for label, icon, flags in (
            ("Rotation", "CON_ROTLIKE", (False, True, False)),
            ("Location", "CON_LOCLIKE", (True, False, False)),
            ("Scale", "CON_SIZELIKE", (False, False, True)),
        ):
            _transform_action(pie, label, icon, *flags)
        active = context.active_object
        if active and active.type == "EMPTY" and active.instance_type == "COLLECTION" and active.instance_collection:
            pie.operator("object.instancer_empty_to_collection", icon="LINKED")
        else:
            action = pie.operator("object.make_single_user", text="Make Single-User", icon="DUPLICATE")
            action.obdata = True
        pie.menu("PIE_MT_clear_menu", text="Clear Transforms", icon="THREE_DOTS")


class OBJECT_OT_apply_transforms_of_constraints(Operator):
    """Bake the evaluated object position and orientation into its transforms"""
    bl_idname = "object.apply_transforms_of_constraints"
    bl_label = "Apply Transforms of Constraints"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        for obj in context.selected_objects:
            if any(constraint.enabled and constraint.influence > 0 for constraint in obj.constraints):
                return True
        cls.poll_message_set("No selected objects with enabled constraints.")
        return False

    def execute(self, context):
        return bpy.ops.object.visual_transform_apply()


def _linked_meshes(context):
    return [obj for obj in context.selected_objects if obj.type == "MESH" and obj.data.users > 1]


class OBJECT_OT_make_meshes_single_user(Operator):
    """Give selected objects their own copies of shared meshes"""
    bl_idname = "object.make_meshes_single_user"
    bl_label = "Make Meshes Single User"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        if _linked_meshes(context):
            return True
        cls.poll_message_set("No selected objects with multi-user meshes.")
        return False

    def execute(self, context):
        for obj in _linked_meshes(context):
            if obj.data.users > 1:
                obj.data = obj.data.copy()
        return {"FINISHED"}


class OBJECT_OT_clear_all_transforms(Operator):
    bl_idname = "clear.all"
    bl_label = "Clear All Transforms"
    bl_description = "Clear All Transforms"
    bl_options = {"UNDO"}

    def execute(self, context):
        for channel in ("location", "rotation", "scale"):
            getattr(bpy.ops.object, channel + "_clear")()
        return {"FINISHED"}


class PIE_MT_clear_transforms(Menu):
    bl_idname = "PIE_MT_clear_menu"
    bl_label = "Clear Transforms"

    def draw(self, context):
        menu = localized_layout(self.layout, context)
        menu.operator("clear.all", text="Clear All", icon="NONE")
        for channel in ("Location", "Rotation", "Scale", "Origin"):
            menu.operator(f"object.{channel.lower()}_clear", text=f"Clear {channel}", icon="NONE")


registry = (
    PIE_MT_apply_transforms,
    OBJECT_OT_apply_transforms_of_constraints,
    OBJECT_OT_make_meshes_single_user,
    OBJECT_OT_clear_all_transforms,
    PIE_MT_clear_transforms,
)


def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="Object Mode",
        pie_name="PIE_MT_apply_transforms",
        hotkey_kwargs={"type": "A", "value": "PRESS", "ctrl": True},
        on_drag=False,
    )
