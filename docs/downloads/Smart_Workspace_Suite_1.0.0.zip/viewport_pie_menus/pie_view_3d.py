# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action
from ._radial_navigation import shortcut

class PIE_MT_view_pie(bpy.types.Menu):
    bl_idname='PIE_MT_view_pie'
    bl_label='3D View'
    def draw(self,context):
        p=self.layout.menu_pie()
        action(p,'view3d.render_border','Set render region','レンダー範囲を指定')
        action(p,'view3d.view_selected','Frame selection','選択範囲を表示')
        action(p,'view3d.view_persportho','Switch projection','透視・平行投影を切り替え')
        action(p,'screen.region_quadview','Four views','四分割表示')
        action(p,'view3d.clip_border','Set clipping region','クリッピング領域を指定')
        action(p,'view3d.view_all','Frame the scene','シーン全体を表示',center=False)
        action(p,'view3d.clear_render_border','Clear render region','レンダー範囲を解除')
        local=context.space_data.local_view
        action(p,'view3d.localview','Leave local view' if local else 'Isolate selection','ローカル表示を終了' if local else '選択物を単独表示',frame_selected=False)
registry=[PIE_MT_view_pie]
def register():
    shortcut(PIE_MT_view_pie.bl_idname,'3D View','C','view3d.view_all',{'center':True},shift=True)
