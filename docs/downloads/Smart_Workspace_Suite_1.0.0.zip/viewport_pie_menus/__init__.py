# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "3D Viewport Pie Menus",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "Smart Tools > 3D Viewport Pie Menus",
    "description": "Viewport pie menus and quick access operators for common 3D View workflows.",
    "category": "3D View",
}

import bpy
from .. import runtime_ledger as _runtime_ledger
import importlib

from . import integrated_bridge

_VPM_AGENT_IMMEDIATE_REGISTER_DONE = locals().get("_VPM_AGENT_IMMEDIATE_REGISTER_DONE", False)

module_names = (
    "op_pie_wrappers",
    "op_copy_to_selected",
    "bs_utils",
    "tweak_builtin_pies",

    "pie_animation",
    "pie_apply_transform",
    "pie_camera",
    "pie_preferences",
    "pie_editor_split_merge",
    "pie_editor_switch",
    "pie_file",
    "pie_manipulator",
    "pie_mesh_delete",
    "pie_mesh_flatten",
    "pie_mesh_merge",
    "pie_object_add",
    "pie_object_display",
    "pie_object_parenting",
    "pie_proportional_editing",
    "pie_relationship_delete",
    "pie_sculpt_brush_select",
    "pie_selection",
    "pie_set_origin",
    "pie_view_3d",
    "pie_window",
)

modules = [
    __import__(__package__ + "." + submod, {}, {}, submod)
    for submod in module_names
]

def register_unregister_modules(modules: list, register: bool):
    """Recursively register or unregister modules by looking for either
    un/register() functions or lists named `registry` which should be a list of
    registerable classes.
    """
    for m in modules:
        if register:
            importlib.reload(m)
        if hasattr(m, 'registry'):
            class_iter = tuple(m.registry) if register else tuple(reversed(tuple(m.registry)))
            for c in class_iter:
                if register:
                    success, _newly_registered = _runtime_ledger.register_class_exact(
                        c,
                        native_register=bpy.utils.register_class,
                        native_unregister=bpy.utils.unregister_class,
                        reason_prefix='VIEWPORT_PIE_CLASS',
                    )
                else:
                    success = _runtime_ledger.unregister_class_exact(
                        c,
                        native_unregister=bpy.utils.unregister_class,
                        reason_prefix='VIEWPORT_PIE_CLASS',
                    )
                if not success:
                    raise RuntimeError(
                        'RESTART_REQUIRED: Viewport Pie Menu class ownership mismatch: '
                        + str(getattr(c, '__name__', '<unknown>'))
                    )

        if hasattr(m, 'modules'):
            register_unregister_modules(m.modules, register)

        if register and hasattr(m, 'register'):
            result = m.register()
            if result is False:
                raise RuntimeError('Viewport Pie Menu module registration failed')
        elif hasattr(m, 'unregister'):
            result = m.unregister()
            if result is False:
                raise RuntimeError('Viewport Pie Menu module unregister failed')

def delayed_register(_scene=None):
    # Register whole add-on with a slight delay,
    # to make sure Keymap data we need already exists on Blender launch.
    # Otherwise, keyconfigs.user.keymaps is an empty list, we can't find fallback ops.
    if integrated_bridge.is_integrated_mode():
        return None
    register_unregister_modules(modules, True)
    return None

def register():
    """
    We prefer an *immediate* register during startup, because other add-ons may touch
    keyconfig initialization very early, and Blender's keymap diff application appears
    sensitive to timing.

    If immediate registration fails (e.g. missing WM in edge cases), fall back to the
    legacy timer-based delayed registration. In integrated mode, never schedule the
    legacy sidebar timer fallback.
    """
    global _VPM_AGENT_IMMEDIATE_REGISTER_DONE
    integrated_mode = integrated_bridge.is_integrated_mode()
    if integrated_mode and not integrated_bridge.register_storage():
        raise RuntimeError('RESTART_REQUIRED: Viewport Pie Menu storage ownership mismatch')
    if not _VPM_AGENT_IMMEDIATE_REGISTER_DONE:
        try:
            register_unregister_modules(modules, True)
            _VPM_AGENT_IMMEDIATE_REGISTER_DONE = True
            return
        except Exception:
            if integrated_mode:
                raise

    if integrated_mode:
        return

    # NOTE: persistent=True must be set, otherwise this doesn't work when opening 
    # a .blend file directly from a file browser.
    bpy.app.timers.register(delayed_register, first_interval=0.0, persistent=True)

def unregister():
    global _VPM_AGENT_IMMEDIATE_REGISTER_DONE
    success = True
    try:
        register_unregister_modules(list(reversed(modules)), False)
    except Exception:
        success = False
    finally:
        # Allow clean disable -> enable and hot-reload cycles in the same Python
        # session.  Without this reset, integrated mode may skip re-registration.
        _VPM_AGENT_IMMEDIATE_REGISTER_DONE = False

    if integrated_bridge.is_integrated_mode():
        try:
            if integrated_bridge.unregister_storage(getattr(bpy, 'context', None)) is not True:
                success = False
        except Exception:
            success = False
    return bool(success)
