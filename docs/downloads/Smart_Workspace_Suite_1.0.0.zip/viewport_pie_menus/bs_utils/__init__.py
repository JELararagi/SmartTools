# SPDX-License-Identifier: GPL-3.0-or-later
"""Include the shortcut registry in the viewport pie lifecycle."""

from . import hotkeys

modules = [hotkeys]
