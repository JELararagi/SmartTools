# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from . import (
    properties,
    hotkeys,
)

modules = [
    properties,
    hotkeys,
]
