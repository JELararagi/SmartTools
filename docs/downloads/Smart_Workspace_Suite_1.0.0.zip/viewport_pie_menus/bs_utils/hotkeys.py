# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from typing import Callable

import bpy
from ... import ui_icons
from bpy.types import KeyMap, KeyMapItem, UILayout

from .. import integrated_bridge
from ...translation import ui_pair

# Preserve across Reload Scripts (module reload) when possible, but also keep
# names defined for static analyzers.
ADDON_KEYMAPS = locals().get("ADDON_KEYMAPS", [])

KEYMAP_ICONS = {
    'Object Mode': 'OBJECT_DATAMODE',
    'Window': 'WINDOW',
    '3D View': 'VIEW3D',
    'Mesh': 'OUTLINER_DATA_MESH',
    'Outliner': 'OUTLINER',
    'Object Non-modal': 'OBJECT_DATAMODE',
    'Sculpt': 'SCULPTMODE_HLT',
    'Armature': 'ARMATURE_DATA',
    'Pose': 'POSE_HLT',
    'Weight Paint': 'WPAINT_HLT',
}

KEYMAP_UI_NAMES = {
    'Armature': "Armature Edit",
    'Object Non-modal': "Object Mode",
}

# Match only event parameters accepted by KeyMapItems.new. RNA properties
# like id, active and ctrl_ui describe the created item, not its key event.
KMI_DEFAULTS = {
    parameter.identifier: parameter.default
    for parameter in bpy.types.KeyMapItems.bl_rna.functions["new"].parameters
    if parameter.identifier not in {"idname", "head"}
    and parameter.identifier in KeyMapItem.bl_rna.properties
    and hasattr(parameter, "default")
}

def register_hotkey(bl_idname, *, op_kwargs=None, hotkey_kwargs=None, keymap_name='Window'):
    config = bpy.context.window_manager.keyconfigs
    if config.addon is None:
        return
    properties = {} if op_kwargs is None else op_kwargs
    event = {'type': 'SPACE', 'value': 'PRESS'} if hotkey_kwargs is None else hotkey_kwargs

    maps = config.addon.keymaps
    keymap = maps.get(keymap_name)
    created_map = keymap is None
    if created_map:
        template = config.default.keymaps[keymap_name]
        keymap = maps.new(name=keymap_name, space_type=template.space_type)

    item = find_kmi_in_km_by_data(keymap, event, bl_idname, properties)
    if item is None:
        try:
            item = keymap.keymap_items.new(bl_idname, **event)
            for name, value in properties.items():
                setattr(item.properties, name, value)
        except Exception:
            if item is not None:
                keymap.keymap_items.remove(item)
            if created_map and len(keymap.keymap_items) == 0:
                maps.remove(keymap)
            raise

    tracked = []
    for entry in ADDON_KEYMAPS:
        try:
            entry[1].as_pointer()
        except ReferenceError:
            continue
        tracked.append(entry)
    registered = (keymap, item)
    if registered not in tracked:
        tracked.append(registered)
    ADDON_KEYMAPS[:] = tracked

def draw_hotkey_list(
    context,
    layout,
    *,
    compact=False,
    debug=False,
    sort_mode='BY_KEYMAP',
    ignore_missing=False,
    button_draw_func: Callable = None,
):
    """Draw the list of hotkeys registered by this add-on.
    Will find the corresponding User KeyMapItems, which are safe to modify.
    Supports two sorting modes:
        BY_KEYMAP: Sort by name of containing keymap, then operator name as displayed in the UI.
        Operators with a "name" parameter will use that as the name. No grouping.
        BY_OPERATOR: Sort by operator name as displayed in the UI. Group identical names together.
    """
    if bpy.app.version < (5, 0, 0):
        content_layout.label(text="Only in Blender 5.0 and later.")
        return

    if integrated_bridge.is_integrated_mode() and not ADDON_KEYMAPS:
        content_layout.label(text=ui_pair("Viewport Pie hotkeys are disabled in Always-on Toggles.", "「常時機能切り替え」でビューポートパイのホットキーが無効です。", context))
        return

    assert sort_mode in ('BY_KEYMAP', 'BY_OPERATOR')

    content_layout = layout.column(align=True) if sort_mode == 'BY_OPERATOR' else layout

    if compact is None:
        sidebar = get_sidebar(context)
        if sidebar:
            compact = sidebar.width < 600
        else:
            compact = context.area.width < 600

    if not compact:
        split = content_layout.row().split(factor=0.75)
        row = split.row()
        row.label(text="Operator", icon='BLANK1')
        row.label(text="Group", icon='BLANK1')
        split.row().label(text="Key Combo")
        content_layout.separator()

    user_kmis = get_user_kmis_of_addon(context)
    if sort_mode == 'BY_KEYMAP':
        user_kmis = sorted(user_kmis, key=lambda tup: "".join(list(get_kmi_ui_info(*tup)[1:])))
    elif sort_mode == 'BY_OPERATOR':
        user_kmis = sorted(user_kmis, key=lambda tup: "".join(list(get_kmi_ui_info(*tup)[2])))

    for i, (user_km, user_kmi) in enumerate(user_kmis):
        _, _, kmi_name = get_kmi_ui_info(user_km, user_kmi)
        if "Missing" in kmi_name and ignore_missing:
            continue
        if sort_mode == 'BY_OPERATOR' and i > 0:
            prev_km, prev_kmi = user_kmis[i-1]
            _, _, prev_kmi_name = get_kmi_ui_info(prev_km, prev_kmi)
            if prev_kmi_name != kmi_name:
                content_layout.separator()

        draw_kmi(
            user_km,
            user_kmi,
            layout,
            compact=compact,
            button_draw_func=button_draw_func,
            debug=debug
        )


def get_user_kmis_of_addon(context, *, do_update=True) -> list[tuple[KeyMap, KeyMapItem]]:
    """Return a list of (KeyMap, KeyMapItem) tuples of user-shortcuts (the ones that can be modified by user)."""
    ret = []

    assert bpy.app.version >= (5, 0, 0), "This function requires Blender 5.0 or later."

    if do_update:
        context.window_manager.keyconfigs.update()
    for addon_km, addon_kmi in ADDON_KEYMAPS:
        user_km, user_kmi = get_user_kmi_of_addon(context, addon_km, addon_kmi)
        if user_kmi:
            ret.append((user_km, user_kmi))

    return ret


def get_user_kmi_of_addon(context, addon_km, addon_kmi) -> tuple[KeyMap | None, KeyMapItem | None]:
    user_km = context.window_manager.keyconfigs.user.keymaps.get(addon_km.name)
    if not user_km:
        # This should never happen.
        print("Failed to find User KeyMap: ", addon_km.name)
        return None, None
    user_kmi = user_km.keymap_items.find_match(addon_km, addon_kmi)
    if not user_kmi:
        # This shouldn't really happen, but maybe it can, eg. if user changes idname.
        print("Failed to find User KeyMapItem: ", addon_km.name, addon_kmi.idname)
        return None, None
    return user_km, user_kmi


def get_kmi_ui_info(km, kmi) -> tuple[str, str, str]:
    km_name: str = km.name
    km_icon = KEYMAP_ICONS.get(km_name, 'BLANK1')
    km_name = KEYMAP_UI_NAMES.get(km_name, km_name)
    if kmi.properties and 'name' in kmi.properties:
        name = kmi.properties.name
        if name:
            if hasattr(bpy.types, kmi.properties.name):
                bpy_type = getattr(bpy.types, kmi.properties.name)
                kmi_name = bpy_type.bl_label
            else:
                kmi_name = "Missing (code 1). Try restarting."
        else:
            kmi_name = "Missing (code 2). Try restarting."
    else:
        try:
            parts = kmi.idname.split(".")
            bpy_type = getattr(bpy.ops, parts[0])
            bpy_type = getattr(bpy_type, parts[1])
            kmi_name = bpy_type.get_rna_type().name
        except (AttributeError, IndexError, TypeError):
            kmi_name = "Missing (code 3). Try restarting."

    return km_icon, km_name, kmi_name

def find_kmi_in_km_by_data(km: KeyMap, hotkey_kwargs: dict, op_idname: str, op_kwargs: dict) -> KeyMapItem | None:
    event = KMI_DEFAULTS | {name: value for name, value in hotkey_kwargs.items() if name in KMI_DEFAULTS}
    for item in km.keymap_items:
        if item.idname != op_idname:
            continue
        if any(getattr(item, name) != value for name, value in event.items()):
            continue
        properties = item.properties
        if properties is None:
            if not op_kwargs:
                return item
            continue
        if set(properties.keys()) != set(op_kwargs):
            continue
        for name, value in op_kwargs.items():
            if not isinstance(value, (str, int, float, bool, type(None))) or getattr(properties, name) != value:
                break
        else:
            return item
    return None

def draw_kmi(
    km: KeyMap,
    kmi: KeyMapItem,
    layout: UILayout,
    compact=False,
    button_draw_func: Callable = None,
    debug=False,
):
    """Draw a KeyMapItem in the provided UI.
    This function is designed specifically to be used in an add-on's preferences:
    - It does not allow removing the KeyMapItem, since add-on KMIs should never be removed.
    - It does not allow changing the operator name or kwargs for similar reasons.
    - Caller should pass a KeyMap and KeyMapItem pair from keyconfigs.user.
    - Passing data from keyconfigs.addon can be useful for debugging purposes.
    """
    content_layout = layout.box() if debug else layout

    split = content_layout.split(factor=0.75)

    row1 = split.row(align=True)
    if debug:
        row1.prop(kmi, "show_expanded", text="", emboss=False)
    row1.prop(kmi, "active", text="", emboss=False)
    km_icon, km_name, kmi_name = get_kmi_ui_info(km, kmi)
    if compact:
        km_name = ""
    row1.label(text=kmi_name)
    row1.label(text=km_name, icon=km_icon or "BLANK1")

    row2 = split.row(align=True)
    sub = row2.row(align=True)
    sub.enabled = kmi.active
    if button_draw_func:
        button_draw_func(layout=sub, km=km, kmi=kmi, compact=compact)
    else:
        sub.prop(kmi, "type", text="", full_event=True)

    if kmi.is_user_modified:
        # Make `context.keymap` available in the drawing code (in this case blender's native code)
        row2.context_pointer_set("keymap", km)
        ui_icons.operator(row2, "preferences.keyitem_restore", text="", name='repair', fallback='BACK', emboss=False).item_id = kmi.id

    if debug and kmi.show_expanded:
        layout.template_keymap_item_properties(kmi)


def get_sidebar(context):
    if not context.area.type == 'VIEW_3D':
        return None
    for region in context.area.regions:
        if region.type == 'UI':
            return region


def find_matching_km_and_kmi(context, target_kc, src_km, src_kmi) -> tuple[KeyMap | None, KeyMapItem | None]:
    target_km = find_matching_keymap(context, target_kc, src_km)
    if not target_km:
        raise RuntimeError(f"Failed to find KeyMap '{src_km.name}' in KeyConfig '{target_kc.name}'")
    kc_user = context.window_manager.keyconfigs.user
    # If we want to find a matching User KeyMapItem, that's easy, because that's what the API was meant for.
    if target_kc == kc_user:
        return target_km, target_km.keymap_items.find_match(src_km, src_kmi)

    user_km = src_km
    # If we want to find any other type of KeyMapItem, we have to do it indirectly, since we can only directly check for matches in the User KeyConfig.
    # So eg. if we want to find an Addon KeyMapItem based on a User KeyMapItem, we have to loop over all Addon KeyMapItems, and find which one matches with the given User KeyMapItem.
    for target_kmi in target_km.keymap_items:
        try:
            match = user_km.keymap_items.find_match(target_km, target_kmi)
            if match == src_kmi:
                return target_km, target_kmi
        except RuntimeError:
            print("Failed to find matching KeyMapItem for: ", target_km.name, target_kmi.to_string())

    # raise Exception(f"Failed to find KeyMapItem '{src_kmi.idname}' ({src_kmi.to_string()}) in KeyConfig '{target_kc.name}', KeyMap '{target_km.name}'")
    # We will return here eg. when looking for an add-on keymap in the default keyconfig.
    return None, None

def find_matching_keymap(context, target_kc, src_km):
    """Find the equivalent keymap in another keyconfig."""

    kc_user = context.window_manager.keyconfigs.user

    # If we want to find a matching User KeyMap, that's easy, because that's what the API was meant for.
    if target_kc == kc_user:
        match = target_kc.keymaps.find_match(src_km)
        assert match != src_km, "This is the same exact keymap already."
        return match

    # If we want to find any other type of KeyMap, we have to do it indirectly, since we can only directly check for matches in the User KeyConfig.
    # So eg. if we want to find an Addon KeyMap based on a User KeyMap, we have to loop over all Addon KeyMaps, and find which one matches with the given User KeyMap.
    for km in target_kc.keymaps:
        match = kc_user.keymaps.find_match(km)
        if match == src_km:
            return km


class SMART_WORKSPACE_SUITE_5A97E4_WINDOW_OT_restore_deleted_hotkeys(bpy.types.Operator):
    bl_idname = "window.restore_deleted_hotkeys_workspace"
    bl_description = "Restore any missing built-in or add-on hotkeys.\n(These should be disabled instead of being deleted.)\nThis operation cannot be undone!"
    # Undo flag is omitted, because this operation cannot be un-done.
    bl_options = {'UNDO'}
    bl_label = "Restore Deleted Hotkeys"

    def execute(self, context):
        num_restored = restore_deleted_keymap_items_global(context)
        self.report({'INFO'}, ui_pair(f"Restored {num_restored} deleted keymaps.", f"削除された {num_restored}個のキーマップを復元しました。", context))
        return {'FINISHED'}


def restore_deleted_keymap_items_global(context) -> int:
    """Deleting built-in or add-on KeyMapItems should never be done by users, as there's no way to recover them.
    Changing the operator name also shouldn't be done, since that makes it impossible to track modifications.
    Blender shouldn't even allow either of these things. You can disable instead of delete, and you can disable and add new entry instead of modifying idname.
    This function tries to bring them back, by restoring all KeyMaps to their default state, then re-applying any modifications that were there before
    (Except these deletions.)
    """

    keyconfigs = context.window_manager.keyconfigs
    user_kc = keyconfigs.user
    total_restored = 0
    keymap_names = [km.name for km in user_kc.keymaps]
    for km_name in keymap_names:
        num_restored = restore_deleted_keymap_items(context, km_name)
        user_km = user_kc.keymaps[km_name]
        if num_restored != 0:
            user_km = user_kc.keymaps[km_name]
            print(f"{user_km.name}: Restored {num_restored}")
        total_restored += num_restored
    return total_restored


def restore_deleted_keymap_items(context, user_km_name) -> int:
    from uuid import uuid4

    keyconfigs = context.window_manager.keyconfigs
    user_kc = keyconfigs.user
    default_kc = keyconfigs.default
    addon_kc = keyconfigs.addon

    user_km = user_kc.keymaps[user_km_name]

    if not any(find_matching_keymap(context, config, user_km) for config in (default_kc, addon_kc)):
        return 0
    temp_km_name = f"_sws_restore_{uuid4().hex}"
    while user_kc.keymaps.get(temp_km_name) is not None:
        temp_km_name = f"_sws_restore_{uuid4().hex}"
    temp_km = user_kc.keymaps.new(temp_km_name)
    try:
        kmis_user_modified = []
        kmis_user_defined = []
        for user_kmi in user_km.keymap_items:
            if user_kmi.is_user_defined:
                temp_kmi = temp_km.keymap_items.new_from_item(user_kmi)
                kmis_user_defined.append(temp_kmi)
                continue
            if user_kmi.is_user_modified:
                temp_kmi = temp_km.keymap_items.new_from_item(user_kmi)
                # Find the original keymap in either the Blender default or Addon KeyConfigs.
                # Not sure if this works with presets like Industry Compatible keymap,
                # but I assume they change the contents of the "default" keyconfig, so it would work.
                default_km, default_kmi = find_matching_km_and_kmi(context, default_kc, user_km, user_kmi)
                if not default_kmi:
                    default_km, default_kmi = find_matching_km_and_kmi(context, addon_kc, user_km, user_kmi)
                kmis_user_modified.append(((default_km, default_kmi), (temp_km, temp_kmi)))

        # Step 2: Restore User KeyMap to default.
        num_kmis = len(user_km.keymap_items)
        user_km.restore_to_default()
        # NOTE: restore_to_default() will shuffle the memory addresses, so we need to re-reference user_km.
        # I don't think this was the case pre-Blender 5.0!!
        user_km = user_kc.keymaps[user_km_name]
        temp_km = user_kc.keymaps[temp_km_name]

        # Step 3: Restore modified and added KeyMapItems.
        for temp_def_kmi in kmis_user_defined:
            user_km.keymap_items.new_from_item(temp_def_kmi)

        for (default_km, default_kmi), (temp_km, temp_kmi) in kmis_user_modified:
            user_km, user_kmi = find_matching_km_and_kmi(context, user_kc, default_km, default_kmi)
            for key in ('active', 'alt', 'any', 'ctrl', 'hyper', 'key_modifier',
                        'map_type', 'oskey', 'shift', 'repeat', 'type', 'value'):
                setattr(user_kmi, key, getattr(temp_kmi, key))
            if temp_kmi.properties:
                for key in temp_kmi.properties.keys():
                    temp_value = getattr(temp_kmi.properties, key)
                    if hasattr(temp_value, 'keys'):
                        # Operator properties can be PropertyGroups, and this is the case for some node wrangler ops.
                        temp_propgroup = temp_value
                        real_propgroup = getattr(user_kmi.properties, key)
                        for pg_key in temp_propgroup.keys():
                            pg_val = getattr(temp_propgroup, pg_key)
                            real_propgroup[pg_key] = pg_val
                        continue
                    setattr(user_kmi.properties, key, temp_value)
        return len(user_km.keymap_items) - num_kmis
    finally:
        scratch_map = user_kc.keymaps.get(temp_km_name)
        if scratch_map is not None:
            user_kc.keymaps.remove(scratch_map)



registry = [SMART_WORKSPACE_SUITE_5A97E4_WINDOW_OT_restore_deleted_hotkeys]
