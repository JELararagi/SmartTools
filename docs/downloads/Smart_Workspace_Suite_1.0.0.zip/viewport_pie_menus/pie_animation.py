# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
import bpy
from ._radial_actions import action,label
from ._radial_navigation import shortcut

class PIE_MT_animation(bpy.types.Menu):
    bl_idname='PIE_MT_animation'
    bl_label='Animation'
    def draw(self,context):
        p=self.layout.menu_pie()
        action(p,'screen.frame_jump','First frame','最初のフレーム',icon='REW',end=False)
        action(p,'screen.frame_jump','Last frame','最後のフレーム',icon='FF',end=True)
        if context.screen.is_animation_playing:
            p.separator()
            action(p,'screen.animation_play','Pause playback','再生を一時停止',icon='PAUSE')
        else:
            action(p,'screen.animation_play','Play backwards','逆向きに再生',icon='PLAY_REVERSE',reverse=True)
            action(p,'screen.animation_play','Play forwards','再生',icon='PLAY')
        action(p,'screen.keyframe_jump','Previous key','前のキー',icon='PREV_KEYFRAME',next=False)
        action(p,'screen.keyframe_jump','Next key','次のキー',icon='NEXT_KEYFRAME',next=True)
        p.prop(context.tool_settings,'use_keyframe_insert_auto',text=label('Automatic keyframes','自動キー'))
        p.menu('VIEW3D_MT_object_animation',text=label('Keyframe actions','キーフレーム操作'),icon='KEYINGSET')
registry=[PIE_MT_animation]
def register():
    shortcut(PIE_MT_animation.bl_idname,'Object Non-modal','SPACE','screen.animation_play',shift=True)
