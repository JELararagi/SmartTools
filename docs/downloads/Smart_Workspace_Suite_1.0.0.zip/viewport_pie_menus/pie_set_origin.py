# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
from ..translation import localized_layout, ui_pair
from bpy.types import Menu, Operator
from bpy.props import StringProperty
from mathutils import Matrix, Vector

from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


class PIE_MT_set_origin(Menu):
    bl_idname = "PIE_MT_set_origin"
    bl_label = "Set Origin"

    def draw(self, context):
        pie = localized_layout(self.layout, context).menu_pie()

        # 4 - LEFT
        pie.operator(
            "object.origin_set_any_mode",
            text="Geometry -> Origin",
            icon='TRANSFORM_ORIGINS',
        ).type = 'GEOMETRY_ORIGIN'
        # 6 - RIGHT
        pie.operator(
            "object.origin_set_any_mode",
            text="Origin -> Geometry",
            icon='SNAP_PEEL_OBJECT',
        ).type = 'ORIGIN_GEOMETRY'
        # 2 - BOTTOM
        pie.operator(
            "object.origin_set_to_bottom", text="Origin -> Bottom", icon='TRIA_DOWN'
        )
        # 8 - TOP
        pie.operator(
            "object.origin_set_to_selection",
            text="Origin -> Selection",
            icon='RESTRICT_SELECT_OFF',
        )
        # 7 - TOP - LEFT
        pie.operator(
            "object.origin_set_any_mode", text="Origin -> Cursor", icon='PIVOT_CURSOR'
        ).type = 'ORIGIN_CURSOR'
        # 9 - TOP - RIGHT
        pie.operator(
            "object.origin_set_any_mode", text="Origin -> Mass", icon='SNAP_FACE_CENTER'
        ).type = 'ORIGIN_CENTER_OF_MASS'
        # 1 - BOTTOM - LEFT
        pie.separator()
        # 3 - BOTTOM - RIGHT
        pie.operator(
            "object.origin_set_any_mode",
            text="Origin -> Volume",
            icon='SNAP_FACE_CENTER',
        ).type = 'ORIGIN_CENTER_OF_MASS'


class OBJECT_OT_set_origin_to_selection(Operator):
    bl_idname = "object.origin_set_to_selection"
    bl_label = "Origin To Selection"
    bl_description = "Snap the origin to the selection"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object is None:
            cls.poll_message_set(ui_pair('No active object.', 'アクティブなオブジェクトがありません。', context))
            return False
        return True

    def execute(self, context):
        active = context.active_object
        org_mode = active.mode
        saved_location = context.scene.cursor.location.copy()
        try:
            # With nothing selected the cursor stays put, and the origin must not
            # follow it to an unrelated location.
            if 'FINISHED' not in bpy.ops.view3d.snap_cursor_to_selected():
                self.report({'WARNING'}, ui_pair('Nothing is selected.', '何も選択されていません。', context))
                return {'CANCELLED'}
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        finally:
            if active.mode != org_mode:
                bpy.ops.object.mode_set(mode=org_mode)
            context.scene.cursor.location = saved_location

        self.report({'INFO'}, ui_pair('Snapped the origin point to the selection.', '原点を選択要素にスナップしました。', context))

        return {'FINISHED'}


class OBJECT_OT_set_origin_to_bottom(Operator):
    bl_idname = "object.origin_set_to_bottom"
    bl_label = "Origin To Bottom"
    bl_description = "Move the object origin to the lowest local point without applying rotation or scale. The object location changes only as needed to represent the moved origin."
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return ui_pair(
            'Function: move the origin of each selected mesh or armature to its lowest local point. This version is non-destructive: it preserves rotation, scale, parenting, constraints, and world-space appearance without applying transforms. Because the origin itself moves, the object location changes only as needed to represent the new origin position; it is not reset to zero. How to use: select one or more mesh or armature objects, then run Origin -> Bottom from the Set Origin pie menu.',
            '機能: 選択したメッシュまたはアーマチュアの原点を、各オブジェクトのローカル座標で一番下の位置へ移動します。この版は非破壊です。回転、スケール、親子関係、コンストレイント、ワールド上の見た目を維持し、トランスフォーム適用によるリセットを行いません。原点自体が移動するため、位置は新しい原点位置を表すために必要な分だけ変わりますが、ゼロへリセットされるわけではありません。使い方: メッシュまたはアーマチュアを1つ以上選択し、Set Origin パイメニューの Origin -> Bottom を実行します。',
            context,
        )

    @classmethod
    def poll(cls, context):
        selected = getattr(context, 'selected_objects', None) or []
        if not any(ob and ob.type in {'MESH', 'ARMATURE'} for ob in selected):
            cls.poll_message_set("No mesh or armature objects selected.")
            return False
        return True

    def execute(self, context):
        org_active_obj = getattr(context, 'active_object', None)
        org_selected = list(getattr(context, 'selected_objects', []) or [])
        targets = [obj for obj in org_selected if obj and obj.type in {'MESH', 'ARMATURE'}]

        counter = 0
        for obj in targets:
            counter += int(self.origin_to_bottom(context, obj))

        try:
            for obj in org_selected:
                obj.select_set(True)
            if org_active_obj is not None:
                context.view_layer.objects.active = org_active_obj
        except Exception:
            pass

        self.report(
            {'INFO'}, ui_pair(
                f"Moved the origins of {counter} objects to their lowest point without applying transforms.",
                f"トランスフォームを適用せずに {counter}個のオブジェクトの原点を最下点へ移動しました。",
                context,
            )
        )
        return {'FINISHED'}

    @staticmethod
    def _set_active_object(context, obj) -> None:
        try:
            context.view_layer.objects.active = obj
            obj.select_set(True)
        except Exception:
            pass

    @staticmethod
    def _restore_mode(obj, mode: str) -> None:
        if not mode or mode == 'OBJECT':
            return
        try:
            bpy.ops.object.mode_set(mode=mode)
        except Exception:
            pass

    @staticmethod
    def _shift_mesh_data(obj, min_z: float) -> None:
        shape_keys = getattr(obj.data, 'shape_keys', None)
        key_blocks = getattr(shape_keys, 'key_blocks', None) if shape_keys is not None else None
        if key_blocks:
            for key in key_blocks:
                for point in key.data:
                    point.co.z -= min_z
        else:
            for vert in obj.data.vertices:
                vert.co.z -= min_z
        try:
            obj.data.update()
        except Exception:
            pass

    @staticmethod
    def origin_to_bottom(context, obj) -> bool:
        if obj is None or obj.type not in {'MESH', 'ARMATURE'}:
            return False

        org_mode = str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT')
        old_world = obj.matrix_world.copy()
        local_offset = Vector((0.0, 0.0, 0.0))

        try:
            OBJECT_OT_set_origin_to_bottom._set_active_object(context, obj)
            if obj.type == 'MESH':
                if obj.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
                vertices = getattr(getattr(obj, 'data', None), 'vertices', None)
                if not vertices:
                    return False
                min_z = min(v.co.z for v in vertices)
                local_offset.z = float(min_z)
                OBJECT_OT_set_origin_to_bottom._shift_mesh_data(obj, float(min_z))

            elif obj.type == 'ARMATURE':
                bpy.ops.object.mode_set(mode='EDIT')
                edit_bones = getattr(getattr(obj, 'data', None), 'edit_bones', None)
                if not edit_bones:
                    return False
                min_z = min(min(bone.head.z, bone.tail.z) for bone in edit_bones)
                local_offset.z = float(min_z)
                for bone in edit_bones:
                    bone.head.z -= min_z
                    bone.tail.z -= min_z
                bpy.ops.object.mode_set(mode='OBJECT')

            if local_offset.length == 0.0:
                OBJECT_OT_set_origin_to_bottom._restore_mode(obj, org_mode)
                return True

            # Geometry/bones were shifted by -local_offset.  Multiplying the
            # previous world matrix by Translation(local_offset) moves only the
            # origin in local space while preserving the visible world-space
            # geometry and without applying location/rotation/scale.
            obj.matrix_world = old_world @ Matrix.Translation(local_offset)
            OBJECT_OT_set_origin_to_bottom._restore_mode(obj, org_mode)
            return True
        except Exception:
            try:
                obj.matrix_world = old_world
            except Exception:
                pass
            OBJECT_OT_set_origin_to_bottom._restore_mode(obj, org_mode)
            return False


class OBJECT_OT_set_origin_any_mode(Operator):
    bl_idname = "object.origin_set_any_mode"
    bl_label = "Set Origin"
    bl_description = "Set the Object Origin"
    bl_options = {'UNDO'}

    type: StringProperty()

    messages = {
        'GEOMETRY_ORIGIN': "Snapped the geometry to the object's origin.",
        'ORIGIN_CURSOR': "Snapped the object's origin to the 3D cursor.",
        'ORIGIN_CENTER_OF_MASS': "Snapped the origin to the geometry's center of mass.",
        'ORIGIN_CENTER_OF_VOLUME': "Snapped the origin to the geometry's center of volume.",
        'ORIGIN_GEOMETRY': "Snapped the origin to the geometry.",
    }

    @classmethod
    def description(cls, context, params):
        return cls.messages[params.type].replace("Snapped", "Snap")[:-1]

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.select_get()

    def execute(self, context):
        if self.type not in self.messages:
            return {'CANCELLED'}

        original_mode = context.active_object.mode
        if original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            result = bpy.ops.object.origin_set(type=self.type)
        finally:
            if original_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=original_mode)

        if 'FINISHED' in result:
            self.report({'INFO'}, self.messages[self.type])
        return result


registry = [
    PIE_MT_set_origin,
    OBJECT_OT_set_origin_to_selection,
    OBJECT_OT_set_origin_to_bottom,
    OBJECT_OT_set_origin_any_mode,
]


def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name='3D View',
        pie_name=PIE_MT_set_origin.bl_idname,
        hotkey_kwargs={'type': "X", 'value': "PRESS", 'ctrl': True, 'alt': True},
        on_drag=False,
    )
