# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Window pie controls backed by Blender's native Screen and Window operators."""

from sys import platform

import bpy
from bpy.types import Menu, Operator

from ..translation import error_text, localized_layout, ui_pair
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


class SMARTWORKSPACE_OT_console_toggle(Operator):
    bl_idname = "wm.smart_workspace_console_toggle"
    bl_label = "Toggle System Console"
    bl_description = (
        "Open or close Blender's system console when the current platform provides it. "
        "On platforms without a separate system console, the command reports that "
        "it is unavailable without raising an error."
    )
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    def execute(self, context):
        try:
            console = bpy.ops.wm.console_toggle
            console.get_rna_type()
        except (AttributeError, RuntimeError):
            self.report({"INFO"}, ui_pair(
                "System console toggling is not available on this platform.",
                "このプラットフォームではシステムコンソールの切替は利用できません。", context))
            return {"CANCELLED"}

        try:
            return console()
        except RuntimeError as exc:
            self.report({"WARNING"}, error_text(
                exc, "The window could not be changed", "ウィンドウを変更できませんでした", context))
            return {"CANCELLED"}


class PIE_MT_window(Menu):
    bl_idname = "PIE_MT_window"
    bl_label = "Window"

    def draw(self, context):
        slots = localized_layout(self.layout, context).menu_pie()
        screen = context.screen
        slots.operator("screen.userpref_show", text="Preferences", icon="PREFERENCES")
        if screen.show_fullscreen:
            slots.operator("wm.exit_area_fullscreen", icon="SCREEN_BACK")
        else:
            slots.operator("screen.screen_full_area", text="Maximize Area", icon="PIVOT_BOUNDBOX")

        slots.prop(screen, "show_statusbar", text="Status Bar")
        slots.operator("wm.window_fullscreen_toggle", text="Window Fullscreen", icon="FULLSCREEN_ENTER")
        slots.operator("screen.area_dupli", text="Pop Out Window", icon="WINDOW")
        if screen.show_fullscreen:
            slots.separator()
        else:
            full_area = slots.operator("screen.screen_full_area", text="Fullscreen Area", icon="PIVOT_BOUNDBOX")
            full_area.use_hide_panels = True

        if platform == "win32":
            slots.operator("wm.smart_workspace_console_toggle", icon="CONSOLE")
        else:
            slots.separator()
        slots.operator("screen.area_join", text="Move/Split Area", icon="AREA_DOCK")


class WM_OT_exit_area_fullscreen(Operator):
    bl_idname = "wm.exit_area_fullscreen"
    bl_label = "Exit Area Fullscreen"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    def execute(self, context):
        toggle = bpy.ops.screen.screen_full_area
        if context.screen.show_fullscreen:
            toggle()
            if context.screen.show_fullscreen:
                toggle(use_hide_panels=True)
        return {"FINISHED"}


registry = [SMARTWORKSPACE_OT_console_toggle, PIE_MT_window, WM_OT_exit_area_fullscreen]


def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="Window",
        pie_name=PIE_MT_window.bl_idname,
        hotkey_kwargs={"type": "SPACE", "value": "PRESS", "ctrl": True},
        default_fallback_op="screen.screen_full_area",
    )
