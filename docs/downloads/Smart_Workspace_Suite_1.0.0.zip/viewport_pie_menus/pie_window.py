# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from sys import platform

import bpy
from ..translation import error_text, localized_layout, ui_pair
from bpy.types import Menu, Operator

from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only


class SMARTWORKSPACE_OT_console_toggle(bpy.types.Operator):
    bl_idname = "wm.smart_workspace_console_toggle"
    bl_label = "Toggle System Console"
    bl_description = "Open or close Blender's system console when the current platform provides it. On platforms without a separate system console, the command reports that it is unavailable without raising an error."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        try:
            op = bpy.ops.wm.console_toggle
            op.get_rna_type()
        except Exception:
            self.report({'INFO'}, ui_pair('System console toggling is not available on this platform.', 'このプラットフォームではシステムコンソールの切替は利用できません。', context))
            return {'CANCELLED'}
        try:
            return op()
        except Exception as exc:
            self.report({'WARNING'}, error_text(exc, 'The window could not be changed', 'ウィンドウを変更できませんでした', context))
            return {'CANCELLED'}


class PIE_MT_window(Menu):
    bl_idname = "PIE_MT_window"
    bl_label = "Window"

    def draw(self, context):
        pie = localized_layout(self.layout, context).menu_pie()

        # 4 - LEFT
        pie.operator('screen.userpref_show', text="Preferences", icon='PREFERENCES')
        # 6 - RIGHT
        if not context.screen.show_fullscreen:
            pie.operator(
                "screen.screen_full_area", text="Maximize Area", icon='PIVOT_BOUNDBOX'
            )
        else:
            pie.operator("wm.exit_area_fullscreen", icon='SCREEN_BACK')
        # 2 - BOTTOM
        pie.prop(context.screen, 'show_statusbar', text="Status Bar")
        # 8 - TOP
        pie.operator(
            "wm.window_fullscreen_toggle",
            text="Window Fullscreen",
            icon='FULLSCREEN_ENTER',
        )
        # 7 - TOP - LEFT
        pie.operator("screen.area_dupli", text="Pop Out Window", icon='WINDOW')
        # 9 - TOP - RIGHT
        if not context.screen.show_fullscreen:
            pie.operator(
                "screen.screen_full_area", text="Fullscreen Area", icon='PIVOT_BOUNDBOX'
            ).use_hide_panels = True
        else:
            pie.separator()
        # 1 - BOTTOM - LEFT
        if platform == 'win32':
            pie.operator("wm.smart_workspace_console_toggle", icon='CONSOLE')
        else:
            pie.separator()
        # 3 - BOTTOM - RIGHT
        pie.operator('screen.area_join', text="Move/Split Area", icon='AREA_DOCK')


class WM_OT_exit_area_fullscreen(Operator):
    """Exit area fullscreen"""
    _sms_no_undo = True

    bl_idname = "wm.exit_area_fullscreen"
    bl_label = "Exit Area Fullscreen"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        if context.screen.show_fullscreen:
            bpy.ops.screen.screen_full_area()
        if context.screen.show_fullscreen:
            bpy.ops.screen.screen_full_area(use_hide_panels=True)

        return {'FINISHED'}


registry = [
    SMARTWORKSPACE_OT_console_toggle,
    PIE_MT_window,
    WM_OT_exit_area_fullscreen,
]


def register():
    # NOTE: This sadly results in a console warning from wm_gizmo_map.c, but it seems harmless.
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(
        keymap_name="Window",
        pie_name='PIE_MT_window',
        hotkey_kwargs={'type': "SPACE", 'value': "PRESS", 'ctrl': True},
        default_fallback_op='screen.screen_full_area',
    )
