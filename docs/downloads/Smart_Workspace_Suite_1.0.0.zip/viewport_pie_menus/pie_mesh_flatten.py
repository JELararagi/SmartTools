# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Flatten selected vertices using the viewport pivot or the mesh's local frame."""
import bmesh
import bpy
from bpy.props import EnumProperty
from .op_pie_wrappers import WM_OT_call_menu_pie_drag_only

def axis_option():
    return EnumProperty(name='Axis',items=[(c,c,'') for c in 'XYZ'],default='X')

def editable(context):
    return context.mode=='EDIT_MESH' and context.edit_object is not None

def apply_local(context,axis,bound):
    index='XYZ'.index(axis)
    changed=False
    for ob in context.objects_in_mode_unique_data:
        if ob.type!='MESH':continue
        bm=bmesh.from_edit_mesh(ob.data)
        selected=[v for v in bm.verts if v.select and not v.hide]
        if not selected:continue
        if bound=='POSITIVE':target=max(v.co[index] for v in selected)
        elif bound=='NEGATIVE':target=min(v.co[index] for v in selected)
        else:target=0.0
        for v in selected:v.co[index]=target
        bmesh.update_edit_mesh(ob.data,loop_triangles=True,destructive=False)
        changed=True
    return {'FINISHED'} if changed else {'CANCELLED'}

class TRANSFORM_OT_flatten_to_center(bpy.types.Operator):
    bl_idname='transform.flatten_to_center'
    bl_label='Flatten to Center'
    bl_options={'UNDO'}
    axis:axis_option()

    @classmethod
    def poll(cls,context):return editable(context)
    def execute(self,context):
        if not any(any(v.select and not v.hide for v in bmesh.from_edit_mesh(ob.data).verts)
                   for ob in context.objects_in_mode_unique_data if ob.type=='MESH'):
            return {'CANCELLED'}
        # Use Blender's pivot, multi-object selection and orientation handling.
        return bpy.ops.transform.resize(value=tuple(float(c!=self.axis) for c in 'XYZ'))

class TRANSFORM_OT_flatten_to_object_origin(bpy.types.Operator):
    bl_idname='transform.flatten_to_origin'
    bl_label='Flatten to Origin'
    bl_options={'UNDO'}
    axis:axis_option()

    @classmethod
    def poll(cls,context):return editable(context)
    def execute(self,context):return apply_local(context,self.axis,None)

class TRANSFORM_OT_flatten_to_selection_bounding_box(bpy.types.Operator):
    bl_idname='transform.flatten_to_selection_bounding_box'
    bl_label='Flatten to Selection Bounding Box'
    bl_options={'UNDO'}
    axis:axis_option()
    side:EnumProperty(name='Side',items=[('POSITIVE','Positive',''),('NEGATIVE','Negative','')],default='POSITIVE')

    @classmethod
    def poll(cls,context):return editable(context)
    def execute(self,context):return apply_local(context,self.axis,self.side)

class PIE_MT_mesh_flatten(bpy.types.Menu):
    bl_idname='PIE_MT_mesh_flatten'
    bl_label='Mesh Flatten'
    def draw(self,context):
        pie=self.layout.menu_pie()
        for axis in 'XYZ':
            for sign,side in [('-','NEGATIVE'),('+','POSITIVE')]:
                button=pie.operator('transform.flatten_to_selection_bounding_box',text=sign+axis)
                button.axis=axis;button.side=side
        ja=bpy.app.translations.locale.startswith('ja')
        for mode in ('origin','center'):
            column=pie.column(align=True)
            label={'origin':('原点','Origin'),'center':('中心','Center')}[mode][0 if ja else 1]
            for axis in 'XYZ':
                column.operator('transform.flatten_to_'+mode,text=label+' '+axis).axis=axis

registry=[PIE_MT_mesh_flatten,TRANSFORM_OT_flatten_to_center,TRANSFORM_OT_flatten_to_object_origin,TRANSFORM_OT_flatten_to_selection_bounding_box]
def register():
    WM_OT_call_menu_pie_drag_only.register_drag_hotkey(keymap_name='Mesh',pie_name=PIE_MT_mesh_flatten.bl_idname,hotkey_kwargs=dict(type='X',value='PRESS',alt=True),on_drag=False)
