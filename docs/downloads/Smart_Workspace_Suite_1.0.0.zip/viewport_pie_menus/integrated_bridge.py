# SPDX-License-Identifier: GPL-3.0-or-later
"""Hook the viewport menus into SmartWorkspace without storing extra RNA."""

def is_integrated_mode():
    return "smart_workspace_suite" in (__package__ or "").lower().split(".")


def register_storage():
    return True


def unregister_storage(_context=None):
    return True
