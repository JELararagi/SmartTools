# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations


def is_integrated_mode() -> bool:
    package = str(__package__ or '').lower()
    return (
        '.smart_workspace_suite.' in package
        or package.startswith('smart_workspace_suite.')
        or package.endswith('.smart_workspace_suite')
        or package == 'smart_workspace_suite'
    )


def register_storage() -> bool:
    # The unreachable sidebar/config UI and its private RNA settings were
    # removed in Suite 1.1.151.  Functional pie menus and hotkeys need no
    # preference PropertyGroup.
    return True


def unregister_storage(_context=None) -> bool:
    return True
