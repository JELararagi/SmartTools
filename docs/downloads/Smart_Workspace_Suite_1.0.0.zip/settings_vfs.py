# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""One settings file per product (A2-60).

Every former CONFIG sidecar is one member of the ``files`` object inside
``Smart_Workspace_Suite.json``.  A key is the sidecar's path relative to the
suite CONFIG folder without its extension (``n-panel_manager/current_settings``).
Values keep exactly the JSON graph the sidecar held, so readers and the strict
checksum see the same data.  A write only updates the cached envelope and marks
it; one finite 0.5 s timer and the load/save/exit boundaries publish the whole
envelope once (temporary file + replace; the previous valid file becomes
``Smart_Workspace_Suite.json.bak``).  Former physical sidecars are read once for
migration and are never written, renamed or deleted.
"""

from __future__ import annotations

import copy
import json
import os
import shutil
from typing import Any, Iterable

EXTENSION = '.json'
LAYOUT_FIELD = 'settings_layout'
LAYOUT_MARK = 'single-file-1'
FLUSH_SLOT = 'storage.settings_vfs_flush'
FLUSH_DELAY = 0.5

CURRENT_KEY = 'n-panel_manager/current_settings'
SIDEBAR_LAYOUT_KEY = 'n-panel_manager/sidebar_layout'
N_PANEL_SETTINGS_KEY = 'sidecars/user_data/settings/n_panel_settings'
RUNTIME_SETTINGS_KEY = 'sidecars/user_data/storage/smart_workspace_suite_runtime_settings'
LIVE_STATE_KEY = 'sidecars/user_data/storage/n_panel_manager/live_state'
FEATURE_TOGGLES_DIR_KEY = 'sidecars/user_data/storage/feature_toggles'
PANVIEW_SETTINGS_KEY = 'sidecars/user_data/storage/panview/panview_settings'
ALWAYS_ON_TOGGLES_KEY = 'sidecars/user_data/storage/always_on_toggles'
SYNCHRONIZE_SETTINGS_KEY = (
    'sidecars/user_data/storage/synchronize_workspaces/'
    'smart_workspace_synchronize_workspaces_settings'
)
OPTIMIZER_SETTINGS_DIR_KEY = 'viewport_optimizer/settings'
OPTIMIZER_KEYS = tuple(
    f'{OPTIMIZER_SETTINGS_DIR_KEY}/{name}'
    for name in (
        'current_settings',
        'standard_settings',
        'optimized_settings',
        'workspace_settings',
        'preferences_before_optimization',
    )
)

# User data snapshots and explicit exports stay physical files (not settings).
PHYSICAL_KEYS = frozenset({'workspace_manager/save_state_order'})
PHYSICAL_PREFIXES = (
    'workspace_manager/backups/',
    'workspace_manager/diagnostics/',
    'workspace_manager/save_states/',
    'viewport_optimizer/backups/',
    'viewport_optimizer/presets/',
    'viewport_optimizer/workspace_preset_overrides/',
    'viewport_optimizer/baseline/',
    'sidecars/io/',
)
PHYSICAL_SUFFIXES = ('.layout',)

# Read-only migration inputs (never written).
LEGACY_SIDECAR_SUFFIX = '.json'
LEGACY_BACKUP_SUFFIX = '.json.bak'
LEGACY_DIR_ALIASES = (('viewport_optimizer/', 'smart_viewport_optimizer_plus/'),)
LEGACY_FILE_ALIASES = {
    SYNCHRONIZE_SETTINGS_KEY: (
        'sidecars/user_data/storage/synchronize_workspaces/synchronize_workspaces_settings.json',
    ),
}
LEGACY_IMPORT_KEYS = (
    SIDEBAR_LAYOUT_KEY,
    N_PANEL_SETTINGS_KEY,
    RUNTIME_SETTINGS_KEY,
    LIVE_STATE_KEY,
    PANVIEW_SETTINGS_KEY,
    ALWAYS_ON_TOGGLES_KEY,
    SYNCHRONIZE_SETTINGS_KEY,
    *OPTIMIZER_KEYS,
)
LEGACY_IMPORT_DIRS = (FEATURE_TOGGLES_DIR_KEY,)
# Per-extension data trees of builds before 2026-03-27.  Their content maps to
# the ``sidecars/`` members (former builds copied the tree there); read only.
LEGACY_TREE_PREFIX = 'sidecars/'
LEGACY_TREE_PARENTS = (
    ('SCRIPTS', ('extensions', 'user_default')),
    ('SCRIPTS', ('extensions_user',)),
    ('CONFIG', ('extensions', 'user_default')),
)

_DIRTY_KEYS: set[str] = set()
_META_DIRTY = False
_DISK_KEYS: set[str] = set()
# Values that live for this Blender session only: N-panel State Save is off
# (and the write was not forced) or the add-on is still registering.  The former
# physical sidecars behaved the same way: the next startup restore replaced them
# with the published copy, while an explicit snapshot/commit collected them.
_SESSION_ONLY: dict[str, Any] = {}
_ROOT_CACHE: tuple[str, tuple[str, ...]] | None = None
_MISSING = object()


def _storage():
    from . import storage as _st
    return _st


# ---------------------------------------------------------------------------
# Keys
# ---------------------------------------------------------------------------

def clean_key(text: Any) -> str:
    parts = [
        piece for piece in str(text or '').replace('\\', '/').split('/')
        if piece and piece not in {'.', '..'}
    ]
    return '/'.join(parts)


def is_physical_key(key: str) -> bool:
    low = str(key or '').lower()
    return (
        low in PHYSICAL_KEYS
        or low.startswith(PHYSICAL_PREFIXES)
        or low.endswith(PHYSICAL_SUFFIXES)
    )


def _roots() -> tuple[str, ...]:
    """Return normalized spellings of the suite CONFIG folder (abs + real)."""
    global _ROOT_CACHE
    try:
        root = str(_storage().central_settings_dir(create=False))
    except Exception:
        return ()
    if _ROOT_CACHE is not None and _ROOT_CACHE[0] == root:
        return _ROOT_CACHE[1]
    spellings = []
    for value in (os.path.abspath(root), os.path.realpath(root)):
        norm = os.path.normcase(os.path.normpath(value))
        if norm not in spellings:
            spellings.append(norm)
    _ROOT_CACHE = (root, tuple(spellings))
    return _ROOT_CACHE[1]


def _relative_to_root(path: str) -> str | None:
    candidates = [os.path.abspath(path)]
    try:
        real = os.path.realpath(path)
        if real not in candidates:
            candidates.append(real)
    except Exception:
        pass
    for candidate in candidates:
        norm = os.path.normcase(os.path.normpath(candidate))
        for root in _roots():
            if norm.startswith(root + os.sep):
                rel = os.path.normpath(candidate)[len(root) + 1:]
                return rel.replace(os.sep, '/')
    return None


def raw_key_of(value: Any) -> str:
    """Return the CONFIG-relative key of a path/key even for physical data."""
    if value is None:
        return ''
    try:
        text = os.fspath(value) if isinstance(value, os.PathLike) else str(value)
    except Exception:
        return ''
    text = text.strip()
    if not text:
        return ''
    low = text.lower()
    if not os.path.isabs(text) and ':' not in text:
        if low.endswith(EXTENSION):
            return ''
        return clean_key(text)
    if not low.endswith(EXTENSION):
        return ''
    rel = _relative_to_root(text)
    if not rel:
        return ''
    key = clean_key(rel[:-len(EXTENSION)])
    try:
        central_stem = os.path.splitext(_storage().CENTRAL_SETTINGS_FILENAME)[0]
    except Exception:
        central_stem = ''
    if not key or key == central_stem or key.split('/', 1)[0] in {
        alias.rstrip('/') for _new, alias in LEGACY_DIR_ALIASES
    }:
        return ''
    return key


def key_of(value: Any) -> str:
    """Return the layer key for ``value`` or '' when it stays a physical file."""
    key = raw_key_of(value)
    if not key or is_physical_key(key):
        return ''
    return key


def migrate_key(key: Any) -> str:
    """Map a pre-layer central member name to its layer key."""
    text = str(key or '').replace('\\', '/').strip('/')
    if text.lower().endswith(EXTENSION):
        stem = text[:-len(EXTENSION)]
        if stem.startswith('config/'):
            text = stem[len('config/'):]
        else:
            text = 'sidecars/' + stem
    result = clean_key(text)
    for new, alias in LEGACY_DIR_ALIASES:
        if result.startswith(alias):
            result = new + result[len(alias):]
    return result


# ---------------------------------------------------------------------------
# Cached envelope access
# ---------------------------------------------------------------------------

def _files() -> dict[str, Any]:
    payload = _storage()._central_peek_payload()
    files = payload.get('files')
    if not isinstance(files, dict):
        files = {}
        payload['files'] = files
    return files


def _same(a: Any, b: Any) -> bool:
    try:
        return _storage().same_json_ignoring_saved_at(a, b)
    except Exception:
        return False


def _read_physical(path: Any, default: Any = None) -> Any:
    try:
        with open(os.fspath(path), 'r', encoding='utf-8-sig') as handle:
            return json.load(handle)
    except Exception:
        return default


def _session_only(force: bool) -> bool:
    """Return whether a write must stay in this session (not published)."""
    st = _storage()
    try:
        if st.registration_write_guard_active():
            return True
    except Exception:
        pass
    if force:
        return False
    try:
        return not bool(st.n_panel_state_save_enabled(True))
    except Exception:
        return False


def exists(value: Any) -> bool:
    key = key_of(value)
    if not key:
        try:
            return bool(value) and os.path.exists(os.fspath(value))
        except Exception:
            return False
    if key in _SESSION_ONLY:
        return _SESSION_ONLY[key] is not _MISSING
    try:
        return key in _files()
    except Exception:
        return False


def read(value: Any, default: Any = None) -> Any:
    key = key_of(value)
    if not key:
        return _read_physical(value, default) if value else default
    if key in _SESSION_ONLY:
        held = _SESSION_ONLY[key]
        return default if held is _MISSING else copy.deepcopy(held)
    try:
        files = _files()
    except Exception:
        return default
    if key not in files:
        return default
    return copy.deepcopy(files[key])


def write(value: Any, data: Any, *, force: bool = False) -> bool:
    """Stage one member; the envelope is published by :func:`flush`."""
    key = key_of(value)
    if not key:
        raise ValueError(f'not a settings layer key: {value!r}')
    if key == CURRENT_KEY:
        raise ValueError('N-panel current settings are committed by storage')
    detached = json.loads(json.dumps(data, ensure_ascii=False, allow_nan=False))
    if _session_only(force):
        _SESSION_ONLY[key] = detached
        return True
    _SESSION_ONLY.pop(key, None)
    files = _files()
    if key in files and _same(files[key], detached):
        return True
    files[key] = detached
    _DIRTY_KEYS.add(key)
    schedule_flush()
    return True


def remove(value: Any, *, force: bool = False) -> bool:
    key = key_of(value)
    if not key or key == CURRENT_KEY:
        return False
    if _session_only(force):
        present = exists(value)
        _SESSION_ONLY[key] = _MISSING
        return present
    _SESSION_ONLY.pop(key, None)
    files = _files()
    present = key in files
    if present:
        del files[key]
    if key in _DISK_KEYS:
        _DIRTY_KEYS.add(key)
        schedule_flush()
    else:
        _DIRTY_KEYS.discard(key)
    return present


def list_keys(prefix: str = '') -> list[str]:
    head = clean_key(prefix)
    try:
        keys = set(_files())
    except Exception:
        keys = set()
    for key, held in _SESSION_ONLY.items():
        if held is _MISSING:
            keys.discard(key)
        else:
            keys.add(key)
    if head:
        keys = {key for key in keys if key == head or key.startswith(head + '/')}
    return sorted(keys)


def overlay_session(files: dict[str, Any]) -> None:
    """Apply this session's unpublished values to a detached ``files`` copy."""
    for key, held in _SESSION_ONLY.items():
        if held is _MISSING:
            files.pop(key, None)
        else:
            files[key] = copy.deepcopy(held)


def forget_session_values(published: dict[str, Any]) -> None:
    """Drop session values that a verified publication now holds."""
    for key in tuple(_SESSION_ONLY):
        held = _SESSION_ONLY[key]
        if held is _MISSING:
            if key not in published:
                _SESSION_ONLY.pop(key, None)
        elif key in published and _same(published[key], held):
            _SESSION_ONLY.pop(key, None)


def clear_session_values() -> None:
    """End every session-only value (startup restore returns to the file)."""
    _SESSION_ONLY.clear()


# ---------------------------------------------------------------------------
# Dirty state and publication
# ---------------------------------------------------------------------------

def dirty() -> bool:
    return bool(_DIRTY_KEYS) or bool(_META_DIRTY)


def mark_dirty() -> None:
    global _META_DIRTY
    _META_DIRTY = True


def mark_key_dirty(key: str) -> None:
    _DIRTY_KEYS.add(str(key))


def overlay_pending(files: dict[str, Any]) -> None:
    """Copy staged members (newer than a caller's detached copy) into ``files``."""
    if not _DIRTY_KEYS:
        return
    try:
        cache = _files()
    except Exception:
        return
    for key in tuple(_DIRTY_KEYS):
        if key == CURRENT_KEY:
            continue
        if key in cache:
            files[key] = copy.deepcopy(cache[key])
        else:
            files.pop(key, None)


def note_loaded(files: Iterable[str]) -> None:
    global _META_DIRTY
    _DISK_KEYS.clear()
    _DISK_KEYS.update(str(key) for key in files)
    _DIRTY_KEYS.clear()
    _META_DIRTY = False


def note_published(files: Iterable[str]) -> None:
    note_loaded(files)
    cancel_flush()


def _flush_timer():
    try:
        _storage().unregister_timer_slot(FLUSH_SLOT)
    except Exception:
        pass
    try:
        flush()
    except Exception:
        pass
    return None


def _timer_pending() -> bool:
    bpy = getattr(_storage(), 'bpy', None)
    if bpy is None:
        return False
    try:
        return bool(bpy.app.timers.is_registered(_flush_timer))
    except Exception:
        return False


def schedule_flush(delay: float = FLUSH_DELAY) -> bool:
    if not dirty():
        return False
    st = _storage()
    if getattr(st, 'bpy', None) is None:
        return False
    if _timer_pending():
        return True
    try:
        return bool(st.register_timer_slot(FLUSH_SLOT, _flush_timer, first_interval=float(delay)))
    except Exception:
        return False


def cancel_flush() -> bool:
    try:
        return bool(_storage().unregister_timer_slot(FLUSH_SLOT, _flush_timer))
    except Exception:
        return False


def flush() -> bool:
    """Publish staged members once; False while an owner transaction holds writes."""
    if not dirty():
        cancel_flush()
        return True
    st = _storage()
    if (
        st.registration_write_guard_active()
        or st.central_write_batch_active()
        or getattr(st, '_CENTRAL_SETTINGS_WRITING', False)
    ):
        return False
    cancel_flush()
    return bool(st._central_write_payload(st._central_peek_payload()))


# ---------------------------------------------------------------------------
# One-time migration of former physical sidecars (read-only)
# ---------------------------------------------------------------------------

def legacy_sidecar_path(key: str, suffix: str = LEGACY_SIDECAR_SUFFIX) -> str:
    root = str(_storage().central_settings_dir(create=False))
    return os.path.join(root, *clean_key(key).split('/')) + suffix


def legacy_tree_roots() -> list[str]:
    """Return the former per-extension data trees (read only, never copied)."""
    st = _storage()
    package = str(getattr(st, 'PACKAGE_ID', '') or '').strip()
    if not package:
        return []
    roots = []
    bpy = getattr(st, 'bpy', None)
    if bpy is not None:
        for resource, parts in LEGACY_TREE_PARENTS:
            try:
                base = str(bpy.utils.user_resource(resource) or '')
            except Exception:
                base = ''
            if base:
                roots.append(os.path.join(os.path.normpath(base), *parts, package))
    roots.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_default', package))
    try:
        target = os.path.normcase(os.path.normpath(str(st.user_default_root(create=False))))
    except Exception:
        target = ''
    found = []
    for root in roots:
        if root not in found and os.path.normcase(os.path.normpath(root)) != target:
            found.append(root)
    return found


def _legacy_tree_paths(key: str, tree_roots: list[str]) -> list[str]:
    if not key.startswith(LEGACY_TREE_PREFIX):
        return []
    rest = key[len(LEGACY_TREE_PREFIX):].split('/')
    return [os.path.join(tree, *rest) + LEGACY_SIDECAR_SUFFIX for tree in tree_roots]


def _legacy_paths_for(key: str, tree_roots: list[str] | None = None) -> list[str]:
    root = str(_storage().central_settings_dir(create=False))
    paths = [legacy_sidecar_path(key)]
    for new, alias in LEGACY_DIR_ALIASES:
        if key.startswith(new):
            paths.append(legacy_sidecar_path(alias + key[len(new):]))
    for rel in LEGACY_FILE_ALIASES.get(key, ()):
        paths.append(os.path.join(root, *rel.split('/')))
    paths.extend(_legacy_tree_paths(key, tree_roots or []))
    return paths


def _read_legacy_json(path: str) -> Any:
    """Strictly parse one legacy file; empty/corrupt input yields ``_MISSING``."""
    try:
        if not os.path.isfile(path):
            return _MISSING
        st = _storage()
        if os.path.getsize(path) > int(st._strict_json.MAX_JSON_BYTES):
            return _MISSING
        with open(path, 'rb') as handle:
            raw = handle.read()
        text = raw.decode('utf-8-sig', errors='strict')
        if not text.strip():
            return _MISSING
        return st._strict_json.strict_json_loads(text, source=f'legacy:{os.path.basename(path)}')
    except Exception:
        return _MISSING


def _legacy_import_keys(tree_roots: list[str] | None = None) -> list[str]:
    keys = list(LEGACY_IMPORT_KEYS)
    root = str(_storage().central_settings_dir(create=False))
    for dir_key in LEGACY_IMPORT_DIRS:
        folders = [os.path.join(root, *dir_key.split('/'))]
        if dir_key.startswith(LEGACY_TREE_PREFIX):
            rest = dir_key[len(LEGACY_TREE_PREFIX):].split('/')
            folders.extend(os.path.join(tree, *rest) for tree in tree_roots or [])
        for folder in folders:
            try:
                names = sorted(os.listdir(folder))
            except Exception:
                names = []
            for name in names:
                if name.lower().endswith(LEGACY_SIDECAR_SUFFIX):
                    key = f'{dir_key}/{name[:-len(LEGACY_SIDECAR_SUFFIX)]}'
                    if key not in keys:
                        keys.append(key)
    return keys


def _copy_legacy_physical_data() -> None:
    """Copy explicit user data of a retired folder once (never settings).

    Former builds moved the whole retired folder (for example
    ``smart_viewport_optimizer_plus``) into its new folder and deleted it.
    Settings members are imported into the one settings file instead; only
    physical user data (presets, backups, baselines, layout snapshots) is
    copied, only when the new file does not exist.  The retired folder is
    never written or deleted.
    """
    root = str(_storage().central_settings_dir(create=False))
    for new, alias in LEGACY_DIR_ALIASES:
        legacy_root = os.path.join(root, *clean_key(alias).split('/'))
        if not os.path.isdir(legacy_root):
            continue
        for dirpath, _dirnames, filenames in os.walk(legacy_root):
            rel_dir = os.path.relpath(dirpath, legacy_root)
            for name in filenames:
                rel = name if rel_dir == '.' else os.path.join(rel_dir, name)
                target_key = new + rel.replace(os.sep, '/')
                stem = target_key
                if stem.lower().endswith(EXTENSION):
                    stem = stem[:-len(EXTENSION)]
                if not is_physical_key(stem):
                    continue
                target = os.path.join(root, *target_key.split('/'))
                if os.path.exists(target):
                    continue
                try:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    shutil.copy2(os.path.join(dirpath, name), target)
                except Exception:
                    pass


def _legacy_current_candidates() -> list[dict[str, Any]]:
    st = _storage()
    strict = st._strict_json
    found = []
    for suffix in (LEGACY_SIDECAR_SUFFIX, LEGACY_BACKUP_SUFFIX):
        path = legacy_sidecar_path(CURRENT_KEY, suffix)
        value = _read_legacy_json(path)
        if value is _MISSING:
            continue
        try:
            payload, legacy = strict.validate_current_payload(
                value, allow_legacy=False, source=f'legacy-current{suffix}'
            )
        except Exception:
            continue
        if not legacy:
            found.append(payload)
    return found


def migrate_loaded_payload(payload: dict[str, Any]) -> bool:
    """Rename old members and import former sidecars once; True when changed."""
    global _META_DIRTY
    files = payload.get('files')
    if not isinstance(files, dict):
        files = {}
        payload['files'] = files
    changed = False
    strict = _storage()._strict_json
    for old in list(files):
        new = migrate_key(old)
        if strict.is_current_key(old):
            new = CURRENT_KEY
        elif not new or is_physical_key(new):
            # Explicit snapshots stay physical files; drop the old mirrored copy.
            files.pop(old, None)
            changed = True
            continue
        if new and new != old:
            value = files.pop(old)
            if new not in files:
                files[new] = value
            changed = True
    if payload.get(LAYOUT_FIELD) != LAYOUT_MARK:
        try:
            _copy_legacy_physical_data()
        except Exception:
            pass
        try:
            tree_roots = legacy_tree_roots()
        except Exception:
            tree_roots = []
        for key in _legacy_import_keys(tree_roots):
            if key in files:
                # The published copy was already authoritative: former builds
                # restored it over the sidecar at every startup.
                continue
            for path in _legacy_paths_for(key, tree_roots):
                value = _read_legacy_json(path)
                if value is _MISSING:
                    continue
                files[key] = value
                changed = True
                break
        best = None
        embedded = files.get(CURRENT_KEY)
        if embedded is not None:
            try:
                best, _legacy = strict.validate_current_payload(
                    embedded, allow_legacy=False, source='central-current'
                )
            except Exception:
                best = None
        for candidate in _legacy_current_candidates():
            if best is None or int(candidate.get('revision', 0)) > int(best.get('revision', 0)):
                best = candidate
                files[CURRENT_KEY] = copy.deepcopy(candidate)
                changed = True
    if changed:
        _META_DIRTY = True
    return changed
