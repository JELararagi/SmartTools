# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import copy
import importlib
import sys
import time
from typing import Any, Callable

import bpy
from . import storage as _suite_storage
from . import settings_vfs as _suite_vfs
from bpy.app.handlers import persistent

_RESTORE_PENDING = False
_RESTORING = False
_SAVING = False
_EXPLICIT_SETTINGS_TRANSACTION_ACTIVE = False
_REGISTERED = False
_AUTOSAVE_ENABLED = False
_LAST_SCENE_POINTER = None
_SCENE_MSGBUS_OWNER = object()
_DEFERRED_SETTINGS_DIRTY = False
_REGISTRATION_RESTORE_STATE = None
_REGISTRATION_RESTORE_ATTEMPTS = 0
_FILE_LOAD_IN_PROGRESS = False
_FILE_POST_READY_AT = 0.0
_FILE_POST_RESTORE_TIMER_REGISTERED = False
_FILE_POST_RESTORE_DELAY = 0.90
_FILE_POST_RESTORE_ATTEMPTS = 0
_FILE_POST_RESTORE_MAX_ATTEMPTS = 40
_FILE_LOAD_RNA_STATE = None
_TEARDOWN_RUNTIME_WRITE_BLOCKED = False
# Keep one process-local copy of the last committed portable RNA graph.  A
# Window.scene transition exposes the new Scene's class defaults before every
# message-bus subscriber has run.  Reading CONFIG only after that boundary is
# therefore too late if a legacy/lazy owner managed to request a save first.
# The cache is refreshed only after an authoritative commit or restore and is
# used as the immutable source for the scene-change transaction.
_CANONICAL_RNA_STATE = None

_RUNTIME_RNA_ROOT = 'smart_workspace_suite_runtime_settings'
_REGISTRATION_RESTORE_MAX_ATTEMPTS = 6
_PERSISTENCE_TIMER_NAMES = (
    '_continuous_autosave_timer',
    '_deferred_load_restore',
    '_registration_restore_once',
    '_deferred_file_restore_tick',
)


def _remember_canonical_rna_state(state) -> dict[str, Any]:
    """Cache and return a detached canonical RNA graph."""
    global _CANONICAL_RNA_STATE
    if isinstance(state, dict):
        _CANONICAL_RNA_STATE = copy.deepcopy(state)
    elif _CANONICAL_RNA_STATE is None:
        _CANONICAL_RNA_STATE = {}
    return copy.deepcopy(_CANONICAL_RNA_STATE or {})


def _canonical_rna_state_snapshot(state_override=None) -> dict[str, Any]:
    """Return an immutable CONFIG snapshot, preferring an explicit boundary."""
    if isinstance(state_override, dict):
        return _remember_canonical_rna_state(state_override)
    if isinstance(_CANONICAL_RNA_STATE, dict):
        return copy.deepcopy(_CANONICAL_RNA_STATE)
    try:
        state = _suite_storage._central_read_payload().get('rna_state', {})
    except Exception:
        state = {}
    return _remember_canonical_rna_state(state)


def _window_scene(context=None):
    """Return the active Window's Scene, which owns Window.scene events.

    Blender can expose the previous ``Context.scene`` briefly while an RNA
    message-bus callback is handling a Window.scene transition (and background
    tests do not run the interactive context refresh loop).  Reading the Window
    pointer directly makes scene restoration deterministic in both cases.
    """
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
    except Exception:
        pass
    return getattr(ctx, 'scene', None)


def _json_value(value, depth: int = 0):
    """Convert one RNA setting to stable JSON without retaining live pointers."""
    if depth > 4:
        return None
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        if isinstance(value, bpy.types.ID):
            return {
                '__smarttools_id__': True,
                'id_type': str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or type(value).__name__),
                'name': str(getattr(value, 'name', '') or ''),
            }
    except Exception:
        pass
    try:
        if hasattr(value, 'bl_rna'):
            return _serialize_owner(value, depth=depth + 1)
    except Exception:
        pass
    try:
        return [_json_value(item, depth + 1) for item in value]
    except Exception:
        return None


def _serialize_owner(owner, *, depth: int = 0) -> dict[str, Any]:
    """Serialize writable RNA plus read-only collection containers.

    Blender marks CollectionProperty containers such as
    ``nptl_settings.workspace_profiles`` read-only because callers cannot assign
    a replacement collection object.  Their items are still mutable and are the
    durable user state.  Therefore read-only COLLECTION properties are traversed;
    read-only scalar/pointer properties remain excluded.
    """
    if owner is None or depth > 6:
        return {}
    result: dict[str, Any] = {}
    try:
        props = tuple(getattr(getattr(owner, 'bl_rna', None), 'properties', ()) or ())
    except Exception:
        props = ()
    for prop in props:
        try:
            name = str(getattr(prop, 'identifier', '') or '')
            ptype = str(getattr(prop, 'type', '') or '')
            readonly = bool(getattr(prop, 'is_readonly', False))
            if not name or name == 'rna_type':
                continue
            if readonly and ptype != 'COLLECTION':
                continue
            value = getattr(owner, name)
        except Exception:
            continue
        try:
            if ptype == 'COLLECTION':
                result[name] = [
                    _serialize_owner(item, depth=depth + 1)
                    for item in value
                ]
            elif ptype == 'POINTER':
                converted = _json_value(value, depth + 1)
                if converted is not None or value is None:
                    result[name] = converted
            else:
                converted = _json_value(value, depth + 1)
                if converted is not None:
                    result[name] = converted
        except Exception:
            continue
    return result

def _collect_rna_state(context=None) -> dict[str, Any]:
    ctx = _safe_context(context)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    scene = _window_scene(ctx)
    wm_state: dict[str, Any] = {}
    scene_state: dict[str, Any] = {}
    if wm is not None:
        for root_name in (
            'nptl_settings',
            'workspace_manager_settings',
            _RUNTIME_RNA_ROOT,
        ):
            try:
                owner = getattr(wm, root_name, None)
                if owner is not None:
                    owner_state = _serialize_owner(owner)
                    wm_state[root_name] = owner_state
            except Exception:
                pass
        # sws_always_* is already stored immediately in
        # always_on_toggles.json and mirrored into the central JSON.  Keeping a
        # second copy in rna_state allowed an older value to win during
        # disable/re-enable and could unexpectedly restart a resident feature.
    if scene is not None:
        try:
            for prop in tuple(getattr(getattr(scene, 'bl_rna', None), 'properties', ()) or ()):
                name = str(getattr(prop, 'identifier', '') or '')
                if not (name.startswith('panview_') or name.startswith('sws_synchronize_workspaces_')):
                    continue
                if bool(getattr(prop, 'is_readonly', False)):
                    continue
                scene_state[name] = _json_value(getattr(scene, name, None), 1)
        except Exception:
            pass
        for root_name in ('smart_viewport_optimizer_settings',):
            try:
                owner = getattr(scene, root_name, None)
                if owner is not None:
                    scene_state[root_name] = _serialize_owner(owner)
            except Exception:
                pass
    return {'window_manager': wm_state, 'scene': scene_state}


def ensure_runtime_rna_state(state, context=None) -> dict[str, Any]:
    """Materialize the runtime-preference root in one canonical RNA graph.

    Builds before 1.1.109 stored these values only in the mirrored runtime JSON
    sidecar.  Once that sidecar has been loaded, promote its live PropertyGroup
    into ``rna_state`` exactly once so registration and ``load_post`` can replay
    the values after Blender finishes rebuilding ``WindowManager`` RNA.
    Existing canonical values always win over the compatibility fallback.
    """
    result = copy.deepcopy(state) if isinstance(state, dict) else {}
    wm_state = result.get('window_manager')
    if not isinstance(wm_state, dict):
        wm_state = {}
        result['window_manager'] = wm_state
    if isinstance(wm_state.get(_RUNTIME_RNA_ROOT), dict):
        return result
    ctx = _safe_context(context)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    owner = getattr(wm, _RUNTIME_RNA_ROOT, None) if wm is not None else None
    if owner is not None:
        values = _serialize_owner(owner)
        if values:
            wm_state[_RUNTIME_RNA_ROOT] = values
    return result


def _preserve_unmaterialized_rna_state(current, previous) -> dict[str, Any]:
    """Merge only RNA entries that the current registration cannot expose.

    Optional Smart Workspace tools own PropertyGroups that are removed during
    add-on teardown and registered again on the next enable.  Their absence at
    a teardown save boundary means "not materialized", not "delete the user's
    settings".  Preserve only keys missing from the freshly collected state;
    every currently available RNA value remains authoritative.
    """
    result = dict(current) if isinstance(current, dict) else {}
    old_state = previous if isinstance(previous, dict) else {}
    for scope_name in ('window_manager', 'scene'):
        fresh_scope = result.get(scope_name)
        if not isinstance(fresh_scope, dict):
            fresh_scope = {}
            result[scope_name] = fresh_scope
        old_scope = old_state.get(scope_name)
        if not isinstance(old_scope, dict):
            continue
        for name, value in old_scope.items():
            if name not in fresh_scope:
                fresh_scope[name] = value
    return result


def _publish_verified_user_state(state) -> None:
    """Make a user-authored RNA graph authoritative during finite restore.

    Blender may still be completing the one-shot post-registration replay when
    the user first opens the N-panel and changes a value.  Ignoring that change
    loses it; keeping the old replay snapshot lets the timer overwrite it a few
    milliseconds later.  A verified update callback therefore replaces both
    the canonical in-memory graph and the bounded replay graph.  File-load,
    Scene-boundary, and teardown guards still reject writes before this helper
    can be reached.
    """
    global _REGISTRATION_RESTORE_STATE
    if not isinstance(state, dict):
        return
    detached = _remember_canonical_rna_state(state)
    if _RESTORE_PENDING and isinstance(_REGISTRATION_RESTORE_STATE, dict):
        _REGISTRATION_RESTORE_STATE = copy.deepcopy(detached)


def _merge_authoritative_n_panel_state(state, context=None) -> dict[str, Any]:
    """Replace only the canonical N-panel root with the loaded current file.

    The N-panel Manager's ``current_settings.json`` is the direct, restart-safe
    source for workspace rules and section state.  Other RNA roots remain owned
    by the canonical central snapshot.  This narrow merge prevents an older
    central ``rna_state`` copy from undoing a newer current-file load while
    preserving every unrelated Smart Workspace setting.
    """
    result = copy.deepcopy(state) if isinstance(state, dict) else {}
    ctx = _safe_context(context)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    owner = getattr(wm, 'nptl_settings', None) if wm is not None else None
    if owner is None:
        return result
    values = _serialize_owner(owner)
    if not isinstance(values, dict):
        return result
    wm_state = result.get('window_manager')
    if not isinstance(wm_state, dict):
        wm_state = {}
        result['window_manager'] = wm_state
    wm_state['nptl_settings'] = values
    return result


def _resolve_id_pointer(data):
    if not isinstance(data, dict) or 'name' not in data:
        return None
    name = str(data.get('name') or '')
    id_type = str(data.get('id_type') or '')
    mapping = {
        'Object': getattr(bpy.data, 'objects', None),
        'Collection': getattr(bpy.data, 'collections', None),
        'WorkSpace': getattr(bpy.data, 'workspaces', None),
        'Scene': getattr(bpy.data, 'scenes', None),
        'Image': getattr(bpy.data, 'images', None),
    }
    collection = mapping.get(id_type)
    try:
        return collection.get(name) if collection is not None and name else None
    except Exception:
        return None


def _apply_owner_values(owner, values, *, depth: int = 0) -> None:
    """Apply one RNA graph strictly; caller owns rollback and callback guards."""
    if owner is None or not isinstance(values, dict) or depth > 6:
        raise ValueError('invalid RNA restore graph')
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
    except Exception as exc:
        raise RuntimeError('RNA metadata unavailable') from exc
    for name, value in values.items():
        try:
            prop = props.get(name) if props is not None else None
        except Exception:
            prop = None
        if prop is None:
            # Optional/removed feature state is preserved in central JSON by
            # _preserve_unmaterialized_rna_state and is not written into a
            # different live RNA slot.
            continue
        try:
            ptype = str(getattr(prop, 'type', '') or '')
            readonly = bool(getattr(prop, 'is_readonly', False))
        except Exception as exc:
            raise RuntimeError(f'RNA metadata read failed: {name}') from exc

        if ptype == 'COLLECTION':
            if not isinstance(value, list):
                raise TypeError(f'collection payload must be a list: {name}')
            try:
                collection = getattr(owner, name)
                clear = getattr(collection, 'clear', None)
                add = getattr(collection, 'add', None)
                if not callable(clear) or not callable(add):
                    raise TypeError(f'collection is not mutable: {name}')
                clear()
                for item_values in value:
                    if not isinstance(item_values, dict):
                        raise TypeError(f'collection item must be an object: {name}')
                    item = add()
                    _apply_owner_values(item, item_values, depth=depth + 1)
            except Exception as exc:
                raise RuntimeError(f'collection restore failed: {name}') from exc
            continue

        # Read-only scalars and pointers are metadata/non-serializable values.
        if readonly:
            continue

        try:
            current = getattr(owner, name)
            if ptype == 'POINTER':
                if value is None:
                    setattr(owner, name, None)
                elif isinstance(value, dict) and value.get('__smarttools_id__') is True:
                    setattr(owner, name, _resolve_id_pointer(value))
                elif isinstance(value, dict) and 'id_type' in value:
                    setattr(owner, name, _resolve_id_pointer(value))
                elif isinstance(value, dict) and current is not None and hasattr(current, 'bl_rna'):
                    _apply_owner_values(current, value, depth=depth + 1)
                else:
                    raise TypeError(f'unsupported pointer payload: {name}')
            else:
                setattr(owner, name, tuple(value) if isinstance(value, list) else value)
        except Exception as exc:
            raise RuntimeError(f'RNA value restore failed: {name}') from exc


def _apply_owner(owner, values, *, depth: int = 0) -> bool:
    """Transactionally replace one PropertyGroup graph.

    The pre-restore graph includes nested read-only collection containers.  Any
    failure rolls the entire owner back under the same update-callback guard, so
    workspace_profiles/categories/tabs/detected/favorites/recent never remain
    partially rebuilt.
    """
    if owner is None or not isinstance(values, dict) or depth > 6:
        return False
    before = _serialize_owner(owner, depth=depth)
    try:
        _apply_owner_values(owner, values, depth=depth)
        # Verify every requested property that exists and is serializable on
        # the live owner.  Unknown optional keys are ignored, but a present live
        # collection/scalar may not disappear from readback after a partial
        # clear/add transaction.
        after = _serialize_owner(owner, depth=depth)
        try:
            live_props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        except Exception:
            live_props = None
        for key, expected in values.items():
            try:
                prop = live_props.get(key) if live_props is not None else None
            except Exception:
                prop = None
            if prop is None:
                continue
            try:
                ptype = str(getattr(prop, 'type', '') or '')
                readonly = bool(getattr(prop, 'is_readonly', False))
            except Exception as exc:
                raise RuntimeError(f'RNA readback metadata failed: {key}') from exc
            if readonly and ptype != 'COLLECTION':
                continue
            if key not in after or after.get(key) != expected:
                raise RuntimeError(f'RNA readback mismatch: {key}')
        return True
    except Exception:
        try:
            _apply_owner_values(owner, before, depth=depth)
        except Exception:
            pass
        return False

def restore_rna_state(context=None, *, state_override=None) -> bool:
    """Transactionally apply the canonical RNA snapshot under callback guards."""
    global _RESTORING
    ctx = _safe_context(context)
    state = (
        _canonical_rna_state_snapshot()
        if state_override is None
        else _canonical_rna_state_snapshot(state_override)
    )
    if not isinstance(state, dict):
        return False
    old = _RESTORING
    optimizer_module = None
    optimizer_guard = None
    runtime_core = None
    runtime_guard_active = False
    rollback_actions = []
    success = False
    _RESTORING = True
    try:
        try:
            runtime_core = _module('runtime.core', import_if_missing=False)
            push_guard = getattr(runtime_core, '_push_update_suspend', None)
            if callable(push_guard):
                push_guard()
                runtime_guard_active = True
        except Exception:
            runtime_core = None
            runtime_guard_active = False
        try:
            optimizer_module = _viewport_optimizer_module()
            begin_guard = getattr(optimizer_module, '_svo_begin_canonical_rna_restore', None)
            if callable(begin_guard):
                optimizer_guard = begin_guard()
        except Exception:
            optimizer_module = None
            optimizer_guard = None

        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        scene = _window_scene(ctx)
        wm_values = state.get('window_manager', {})
        scene_values = state.get('scene', {})

        if wm is not None and isinstance(wm_values, dict):
            for name, value in wm_values.items():
                if str(name).startswith('sws_always_'):
                    continue
                owner = getattr(wm, name, None)
                if isinstance(value, dict) and owner is not None and hasattr(owner, 'bl_rna'):
                    before = _serialize_owner(owner)
                    if not _apply_owner(owner, value):
                        raise RuntimeError(f'WindowManager RNA transaction failed: {name}')
                    rollback_actions.append(('owner', owner, before))
                elif hasattr(wm, name):
                    before = _json_value(getattr(wm, name, None), 1)
                    setattr(wm, name, tuple(value) if isinstance(value, list) else value)
                    rollback_actions.append(('value', wm, name, before))

        if scene is not None and isinstance(scene_values, dict):
            for name, value in scene_values.items():
                owner = getattr(scene, name, None)
                if isinstance(value, dict) and owner is not None and hasattr(owner, 'bl_rna') and 'id_type' not in value:
                    before = _serialize_owner(owner)
                    if not _apply_owner(owner, value):
                        raise RuntimeError(f'Scene RNA transaction failed: {name}')
                    rollback_actions.append(('owner', owner, before))
                elif isinstance(value, dict) and 'id_type' in value:
                    before = _json_value(getattr(scene, name, None), 1)
                    setattr(scene, name, _resolve_id_pointer(value))
                    rollback_actions.append(('value', scene, name, before))
                elif hasattr(scene, name):
                    before = _json_value(getattr(scene, name, None), 1)
                    setattr(scene, name, tuple(value) if isinstance(value, list) else value)
                    rollback_actions.append(('value', scene, name, before))
        success = True
        return True
    except Exception:
        for action in reversed(rollback_actions):
            try:
                if action[0] == 'owner':
                    _apply_owner_values(action[1], action[2])
                else:
                    target, name, before = action[1], action[2], action[3]
                    if isinstance(before, dict) and before.get('__smarttools_id__') is True:
                        before = _resolve_id_pointer(before)
                    setattr(target, name, tuple(before) if isinstance(before, list) else before)
            except Exception:
                pass
        return False
    finally:
        try:
            end_guard = getattr(optimizer_module, '_svo_end_canonical_rna_restore', None)
            if callable(end_guard) and optimizer_guard is not None:
                end_guard(optimizer_guard)
        except Exception:
            pass
        if runtime_guard_active:
            try:
                pop_guard = getattr(runtime_core, '_pop_update_suspend', None)
                if callable(pop_guard):
                    pop_guard()
            except Exception:
                pass
        _RESTORING = old

def _root_package() -> str:
    package = str(__package__ or '').strip()
    if package:
        return package
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return 'smart_workspace_suite'


def _safe_context(context=None):
    return context or getattr(bpy, 'context', None)


def _active_scene_pointer(context=None):
    ctx = _safe_context(context)
    scene = _window_scene(ctx)
    if scene is None:
        return None
    try:
        return int(scene.as_pointer())
    except Exception:
        try:
            return id(scene)
        except Exception:
            return None


def _mark_active_scene(context=None) -> None:
    global _LAST_SCENE_POINTER
    pointer = _active_scene_pointer(context)
    if pointer is not None:
        _LAST_SCENE_POINTER = pointer


def _active_scene_changed(context=None) -> bool:
    global _LAST_SCENE_POINTER
    pointer = _active_scene_pointer(context)
    if pointer is None:
        return False
    if _LAST_SCENE_POINTER is None:
        _LAST_SCENE_POINTER = pointer
        return False
    return pointer != _LAST_SCENE_POINTER


def _scene_boundary_pending(context=None) -> bool:
    """Return True while the active Window points at an unrestored Scene."""
    if not _REGISTERED or _RESTORING or _FILE_LOAD_IN_PROGRESS:
        return False
    pointer = _active_scene_pointer(context)
    return bool(
        pointer is not None
        and _LAST_SCENE_POINTER is not None
        and pointer != _LAST_SCENE_POINTER
    )


def _on_active_scene_changed() -> None:
    """Restore the canonical snapshot only at an actual Scene boundary."""
    global _RESTORE_PENDING
    if not _REGISTERED or _RESTORING or not _scene_boundary_pending():
        return
    state = _canonical_rna_state_snapshot()
    old_pending = _RESTORE_PENDING
    _RESTORE_PENDING = True
    try:
        ctx = getattr(bpy, 'context', None)
        load_all_settings(ctx, state_override=state)
        # Republish the same immutable graph after every sidecar loader and
        # RNA update callback has completed.  This also repairs CONFIG if a
        # third-party/legacy callback wrote during Blender's scene hand-off.
        payload = _suite_storage._central_read_payload()
        payload['rna_state'] = copy.deepcopy(state)
        _suite_storage._central_write_payload(payload)
        _remember_canonical_rna_state(state)
    finally:
        _RESTORE_PENDING = old_pending
        _mark_active_scene(getattr(bpy, 'context', None))
        _subscribe_scene_change()


def _subscribe_scene_change() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, 'scene'),
            owner=_SCENE_MSGBUS_OWNER,
            args=(),
            notify=_on_active_scene_changed,
            options={'PERSISTENT'},
        )
    except Exception:
        pass


def _unsubscribe_scene_change() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass


def release_teardown_runtime_write_barrier() -> None:
    """Release the one-shot disable barrier after preferences teardown."""
    global _TEARDOWN_RUNTIME_WRITE_BLOCKED
    _TEARDOWN_RUNTIME_WRITE_BLOCKED = False


def _import_module(relative_name: str):
    return importlib.import_module(f'{_root_package()}.{relative_name.strip(".")}')


def _loaded_module(relative_name: str):
    """Return only this exact package module; never adopt a suffix match."""
    rel = str(relative_name or '').strip('.')
    if not rel:
        return None
    return sys.modules.get(f'{_root_package()}.{rel}')


def _module(relative_name: str, *, import_if_missing: bool = False):
    module = _loaded_module(relative_name)
    if module is None and import_if_missing:
        try:
            module = _import_module(relative_name)
        except Exception:
            module = None
    return module


def _call(fn: Callable[..., Any] | None, *args, **kwargs) -> Any:
    if not callable(fn):
        return None
    try:
        return fn(*args, **kwargs)
    except Exception:
        return None


def _call_module_function(relative_name: str, function_name: str, context=None, *, import_if_missing: bool = False) -> None:
    module = _module(relative_name, import_if_missing=import_if_missing)
    if module is None:
        return
    _call(getattr(module, function_name, None), _safe_context(context))


def _save_runtime_core_settings(
    context=None,
    *,
    force: bool = False,
    verified_user_change: bool = False,
) -> None:
    core = _module('runtime.core', import_if_missing=False)
    if core is None:
        try:
            from .runtime import core as core  # type: ignore[no-redef]
        except Exception:
            core = None
    if core is None:
        return
    _call(
        getattr(core, 'save_config_to_file', None),
        _safe_context(context),
        force=force,
        verified_user_change=verified_user_change,
    )


def _load_runtime_core_settings(context=None) -> None:
    core = _module('runtime.core', import_if_missing=False)
    if core is None:
        try:
            from .runtime import core as core  # type: ignore[no-redef]
        except Exception:
            core = None
    if core is None:
        return
    _call(getattr(core, 'load_config_from_file', None), _safe_context(context))


def _save_common_settings(context=None) -> None:
    common = _module('common', import_if_missing=False)
    if common is None:
        return
    _call(getattr(common, 'save_persistent_settings', None), _safe_context(context), force=True)


def _load_common_settings(context=None) -> None:
    common = _module('common', import_if_missing=False)
    if common is None:
        return
    _call(getattr(common, 'load_settings_file', None))
    _call(getattr(common, 'apply_persistent_settings', None), _safe_context(context))


def _viewport_optimizer_module():
    return _module('smart_viewport_optimizer_plus', import_if_missing=False)


def _viewport_context(context=None):
    ctx = _safe_context(context)
    try:
        current = getattr(bpy, 'context', None)
        if current is not None and getattr(ctx, 'screen', None) is None and getattr(current, 'screen', None) is not None:
            ctx = current
    except Exception:
        pass
    return ctx


def _save_viewport_optimizer_settings(context=None) -> None:
    ctx = _viewport_context(context)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    settings = getattr(scene, 'smart_viewport_optimizer_settings', None) if scene is not None else None
    if settings is None:
        return
    module = _viewport_optimizer_module()
    if module is None:
        return
    slot = str(getattr(settings, 'active_settings_slot', '') or 'OPTIMIZED')
    _call(
        getattr(module, '_svo_v12_write_current_settings_file', None),
        settings,
        slot,
        context=ctx,
        include_layout=False,
    )
    _call(
        getattr(module, '_svo_v13_save_workspace_slot', None),
        ctx,
        settings,
        slot,
        include_layout=False,
    )


def _load_viewport_optimizer_settings(context=None) -> None:
    ctx = _viewport_context(context)
    module = _viewport_optimizer_module()
    if module is None:
        return
    begin = getattr(module, '_svo_v16_begin_unsafe_ui_suppression', None)
    end = getattr(module, '_svo_v16_end_unsafe_ui_suppression', None)
    old_state = None
    if callable(begin):
        try:
            old_state = begin()
        except Exception:
            old_state = None
    try:
        _call(getattr(module, '_svo_v12_load_current_settings_if_available', None), ctx)
    finally:
        if callable(end) and old_state is not None:
            try:
                end(old_state)
            except Exception:
                pass


def _save_panview_settings(context=None, *, force: bool = False) -> None:
    module = _module('runtime.panview', import_if_missing=False)
    if module is not None:
        _call(
            getattr(module, 'save_persistent_panview_settings', None),
            _safe_context(context),
            force=force,
        )


def _save_loaded_integrated_sidecars(context=None, *, force: bool = False) -> None:
    """Flush optional tool sidecars without importing idle tools."""
    ctx = _safe_context(context)
    targets = (
        ('synchronize_workspaces', '_save_persistent_sync_settings'),
    )
    for relative_name, function_name in targets:
        module = _module(relative_name, import_if_missing=False)
        if module is None:
            continue
        if relative_name == 'synchronize_workspaces':
            # The outer suite wrapper tears Synchronize down before the core
            # persistence unregister runs.  Its own unregister has already
            # force-saved the live values; do not serialize class defaults after
            # the Scene pointer has been removed merely because the Python
            # module remains in sys.modules until final cleanup.
            if not bool(getattr(module, '_REGISTERED', False)):
                continue
            scene = _window_scene(ctx)
            if scene is None or not hasattr(scene, 'sws_synchronize_workspaces_settings'):
                continue
        _call(getattr(module, function_name, None), ctx, force=force)


def _load_loaded_integrated_sidecars(context=None) -> None:
    """Restore sidecars only for optional tools already materialized by use."""
    ctx = _safe_context(context)
    targets = (
        ('synchronize_workspaces', '_load_persistent_sync_settings'),
    )
    for relative_name, function_name in targets:
        module = _module(relative_name, import_if_missing=False)
        if module is not None:
            _call(getattr(module, function_name, None), ctx)


def _save_explicit_json_settings(
    context=None,
    *,
    force: bool = False,
    verified_user_change: bool = False,
    raise_on_failure: bool = False,
    explicit_user_io: bool = False,
) -> bool:
    """Flush materialized sidecars and report aggregate verified success.

    ``current_settings.json`` is intentionally excluded here: the single
    strict revision transaction at the end of save_all_settings owns that file.
    Explicit export requests exact serializer diagnostics instead of collapsing
    a permission/I/O/Boolean-contract failure into a generic commit error.
    """
    ctx = _safe_context(context)
    serializer_force = True if explicit_user_io else bool(force)
    failures: list[str] = []
    skips: list[str] = []
    successes: list[str] = []

    def _serializer_loading(module) -> bool:
        if module is None:
            return False
        for flag in (
            '_PERSISTENCE_LOADING',
            '_LOADING',
            '_INTEGRATED_LOADING',
            '_STORAGE_LOADING',
            '_PANVIEW_PERSISTING',
        ):
            try:
                if bool(getattr(module, flag, False)):
                    return True
            except Exception:
                continue
        return False

    def _record(label: str, fn, *args, module=None, **kwargs) -> None:
        if not callable(fn):
            return
        try:
            result = fn(*args, **kwargs)
        except Exception as exc:
            failures.append(f'{label}:{type(exc).__name__}:{exc}')
            return
        if result is True:
            successes.append(label)
            return
        if explicit_user_io and result is False:
            if _serializer_loading(module):
                failures.append(f'{label}:busy-loading-returned-False')
            else:
                # A forced explicit settings export/import may encounter an
                # optional feature with no materialized owner in a fresh file.
                # Several legacy serializers use ``False`` to mean deferred/no
                # target rather than I/O failure.  Treat that as a skipped
                # sidecar; the final strict current/central transaction remains
                # responsible for reporting real authority write failures.
                skips.append(f'{label}:skipped-returned-False')
            return
        failures.append(f'{label}:returned-{type(result).__name__}:{result!r}'[:240])

    preferences_module = _module('preferences', import_if_missing=True)
    if preferences_module is not None:
        _record(
            'preferences.save_runtime_settings',
            getattr(preferences_module, 'save_runtime_settings', None),
            ctx,
            force=serializer_force,
            verified_user_change=verified_user_change,
            module=preferences_module,
        )

    targets = (
        ('common', 'save_persistent_settings', (ctx,), {'force': True}),
        ('runtime.panview', 'save_persistent_panview_settings', (ctx,), {'force': serializer_force}),
    )
    for relative_name, function_name, args, kwargs in targets:
        module = _module(relative_name, import_if_missing=False)
        if module is not None:
            _record(
                f'{relative_name}.{function_name}',
                getattr(module, function_name, None),
                *args,
                module=module,
                **kwargs,
            )

    for relative_name, function_name in (
        ('synchronize_workspaces', '_save_persistent_sync_settings'),
    ):
        module = _module(relative_name, import_if_missing=False)
        if module is None:
            continue
        if relative_name == 'synchronize_workspaces':
            scene = _window_scene(ctx)
            if not bool(getattr(module, '_REGISTERED', False)) or scene is None or not hasattr(scene, 'sws_synchronize_workspaces_settings'):
                continue
        _record(
            f'{relative_name}.{function_name}',
            getattr(module, function_name, None),
            ctx,
            force=serializer_force,
            module=module,
        )

    # Viewport Optimizer remains lazy and is serialized only when its RNA owner
    # is materialized.  Its write is part of this aggregate result.
    scene = getattr(_viewport_context(ctx), 'scene', None)
    settings = getattr(scene, 'smart_viewport_optimizer_settings', None) if scene is not None else None
    module = _viewport_optimizer_module() if settings is not None else None
    if module is not None:
        slot = str(getattr(settings, 'active_settings_slot', '') or 'OPTIMIZED')
        _record(
            'smart_viewport_optimizer_plus._svo_save_persistence_snapshot_verified',
            getattr(module, '_svo_save_persistence_snapshot_verified', None),
            ctx,
            settings,
            slot,
            include_layout=False,
            module=module,
        )
    if failures and raise_on_failure:
        raise OSError('explicit settings serializer failure: ' + '; '.join(failures[:16]))
    if explicit_user_io and not successes:
        message = 'explicit settings serializers produced no exportable sidecars'
        if skips:
            message += ': ' + '; '.join(skips[:16])
        if raise_on_failure:
            raise OSError(message)
        return False
    return bool(successes) if explicit_user_io else not failures


def _load_explicit_json_settings(context=None) -> None:
    ctx = _safe_context(context)
    # This suite-level PropertyGroup is registered eagerly, but its historical
    # serializer lived only in preferences.py.  Load it alongside every other
    # explicit sidecar before canonical RNA replay; omitting this call left the
    # WindowManager defaults live after a .blend/startup boundary.
    preferences_module = _module('preferences', import_if_missing=True)
    if preferences_module is not None:
        _call(getattr(preferences_module, 'load_runtime_settings', None), ctx)
    _load_runtime_core_settings(ctx)
    _load_common_settings(ctx)
    _load_loaded_integrated_sidecars(ctx)
    _load_viewport_optimizer_settings(ctx)


def _activate_restored_runtime_toggles(context=None) -> None:
    """Apply already-restored opt-in runtimes without changing saved values."""
    try:
        package_name = str(__package__ or '').strip()
        if not package_name:
            return
        package = importlib.import_module(package_name)
        runtime_module = importlib.import_module(f'{package_name}.runtime')
        apply_runtime = getattr(runtime_module, 'apply_preference_runtime_state', None)
        if callable(apply_runtime):
            apply_runtime(context, startup=True)

        # All opt-in feature leases are activated only after the complete
        # validated RNA/sidecar graph has been restored.  Disabled features
        # remain unloaded and no timer or poll is introduced.
        tool_runtime = importlib.import_module(f'{package_name}.tool_runtime')
        apply_tools = getattr(tool_runtime, 'apply_preference_runtime_state', None)
        if callable(apply_tools):
            apply_tools(context)

        # Compatibility activation for the two package-owned workspace
        # runtimes remains idempotent and write-free during startup replay.
        apply_fn = getattr(package, '_sws_restore_explicitly_enabled_workspace_runtimes', None)
        if callable(apply_fn):
            apply_fn()
    except Exception:
        pass


def _deferred_load_restore():
    """Legacy timer name retained as a harmless compatibility no-op."""
    return None


def _queue_load_restore(delay: float = 0.05) -> None:
    """Cancel the deprecated deferred loader without scheduling it."""
    del delay
    try:
        _purge_stale_persistence_timers(('_deferred_load_restore',))
    except Exception:
        pass
    return None


def _runtime_rna_matches(state, context=None) -> bool:
    """Return whether the late WindowManager runtime owner matches CONFIG."""
    try:
        expected = state.get('window_manager', {}).get(_RUNTIME_RNA_ROOT)
    except Exception:
        expected = None
    if not isinstance(expected, dict):
        return True
    ctx = _safe_context(context)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    owner = getattr(wm, _RUNTIME_RNA_ROOT, None) if wm is not None else None
    if owner is None:
        return False
    actual = _serialize_owner(owner)
    for name, value in expected.items():
        if name not in actual:
            return False
        actual_value = actual.get(name)
        if isinstance(value, float) and isinstance(actual_value, (int, float)):
            if abs(float(actual_value) - float(value)) > 1.0e-6:
                return False
        elif actual_value != value:
            return False
    return True


def _sync_runtime_sidecar_from_state(state, context=None) -> bool:
    """Publish only a verified restored runtime owner to its CONFIG sidecar."""
    try:
        expected = state.get('window_manager', {}).get(_RUNTIME_RNA_ROOT)
    except Exception:
        expected = None
    if not isinstance(expected, dict):
        return False
    if not _runtime_rna_matches(state, context):
        # Never promote a late PointerProperty's temporary class defaults over
        # the canonical sidecar.  The bounded registration replay will retry
        # after Blender has finished materialising the owner.
        return False
    preferences_module = _module('preferences', import_if_missing=True)
    if preferences_module is not None:
        _call(
            getattr(preferences_module, 'save_runtime_settings', None),
            _safe_context(context),
            force=True,
            verified_restore=True,
        )
        return True
    return False


def _registration_restore_once():
    """Compatibility callback retained only for stale-timer cleanup."""
    return None


def queue_registration_restore(state, delay: float = 0.0) -> None:
    """Queue one generation-bound restore event without a timer or polling."""
    del delay
    if not isinstance(state, dict):
        return None
    lifecycle = _lifecycle_state()
    generation = _suite_generation_token()
    snapshot = {
        'generation': generation,
        'rna_state': copy.deepcopy(state),
        'source': 'legacy-registration-compat',
    }
    token = _uuid.uuid4().hex
    if _enqueue_authority_snapshot(lifecycle, snapshot, token):
        _set_write_barrier(False)
        _install_pending_event_handler()
    return None


def _persistence_module_name_matches(module_name: str) -> bool:
    """Compatibility predicate; never used to discover or remove callbacks."""
    text = str(module_name or '')
    return 'smart_workspace_suite' in text and text.endswith('persistence')


def _purge_stale_continuous_autosave_timers() -> None:
    """Compatibility wrapper for older callers."""
    _purge_stale_persistence_timers(('_continuous_autosave_timer',))


def _continuous_autosave_timer():
    # Performance mode: continuous polling saves are disabled.
    global _AUTOSAVE_ENABLED
    _AUTOSAVE_ENABLED = False
    return None


def _start_continuous_autosave() -> None:
    # Intentionally no-op for viewport performance.
    global _AUTOSAVE_ENABLED
    _AUTOSAVE_ENABLED = False
    _stop_continuous_autosave()


def _stop_continuous_autosave() -> None:
    global _AUTOSAVE_ENABLED
    _AUTOSAVE_ENABLED = False
    try:
        _purge_stale_continuous_autosave_timers()
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_continuous_autosave_timer):
            bpy.app.timers.unregister(_continuous_autosave_timer)
    except Exception:
        pass


def _stable_callback_key(fn) -> tuple[str, str]:
    try:
        module_name = str(getattr(fn, '__module__', '') or '')
    except Exception:
        module_name = ''
    try:
        function_name = str(getattr(fn, '__name__', '') or '')
    except Exception:
        function_name = ''
    marker = 'smart_workspace_suite'
    if marker in module_name:
        module_name = marker + module_name.split(marker, 1)[1]
    return module_name, function_name


def _callbacks_equivalent(candidate, target) -> bool:
    if candidate is target:
        return True
    if not callable(candidate) or not callable(target):
        return False
    return _stable_callback_key(candidate) == _stable_callback_key(target)


def _append_handler(handler_list, fn) -> bool:
    """Install only this generation's exact callback identity.

    Stable names are not ownership proof: a live prior generation may expose the
    same ``__module__``/``__name__`` while still owning native RNA and handler
    state.  Generation retirement is performed exclusively by runtime_ledger's
    recorded native remover; this helper only de-duplicates the exact object.
    """
    try:
        while fn in handler_list:
            handler_list.remove(fn)
        handler_list.append(fn)
        return fn in handler_list
    except Exception:
        return False


def _remove_handler(handler_list, fn) -> bool:
    """Remove only the exact callback registered by this module object."""
    removed = False
    try:
        while fn in handler_list:
            handler_list.remove(fn)
            removed = True
    except Exception:
        return False
    return removed


def _sync_file_boundary_handlers(enabled: bool) -> None:
    handlers = getattr(bpy.app, 'handlers', None)
    if handlers is None:
        return
    # These handlers are event-bound, not polling.  Keep them installed even
    # when continuous state saving is disabled so settings are still preserved
    # when Blender exits or the current .blend is replaced.
    _append_handler(getattr(handlers, 'load_pre', []), sws_persistent_load_pre)
    _append_handler(getattr(handlers, 'load_post', []), sws_persistent_load_post)
    _append_handler(getattr(handlers, 'exit_pre', []), sws_persistent_exit_pre)
    # save_pre は常に 1 つだけ入れる（保存の設定が OFF の時は sws_persistent_save_pre が hook だけ呼ぶ）
    _append_handler(getattr(handlers, 'save_pre', []), sws_persistent_save_pre)
    _remove_handler(getattr(handlers, 'save_post', []), sws_persistent_save_post)


def request_startup_restore(context=None) -> str:
    """Restore validated authority once after registration has fully settled.

    The caller invokes this only after all PropertyGroups, native N-panel roots,
    and bundled UI modules are registered.  A ready runtime restores
    synchronously; otherwise one generation-bound depsgraph event is armed.  No
    timer, watchdog, or repeated poll is created, and invalid/missing authority
    never promotes RNA defaults into the central store.
    """
    state = _lifecycle_state()
    generation = _suite_generation_token()
    if not generation or generation == 'UNREGISTERED' or not _state_generation_current(state):
        state['startup_restore_status'] = 'GENERATION_MISMATCH'
        return 'GENERATION_MISMATCH'
    if state.get('startup_restore_done') is True:
        return str(state.get('startup_restore_status') or 'ALREADY_DONE')
    token = _uuid.uuid4().hex
    state['startup_restore_token'] = token
    state['startup_restore_status'] = 'REQUESTED'
    state['load_post_seen'] = True
    try:
        snapshot = _capture_authority_snapshot(context)
        if not isinstance(snapshot, dict):
            state['startup_restore_done'] = True
            state['startup_restore_status'] = 'NO_VALID_AUTHORITY'
            _set_write_barrier(False)
            return 'NO_VALID_AUTHORITY'
        if not _enqueue_authority_snapshot(state, snapshot, token):
            state['startup_restore_status'] = 'QUEUE_FAILED'
            _set_write_barrier(False)
            return 'QUEUE_FAILED'
        _set_write_barrier(False)
        if _runtime_owners_ready():
            ok = bool(_apply_pending_restore('startup_ready'))
            state['startup_restore_done'] = bool(ok)
            state['startup_restore_status'] = 'APPLIED' if ok else 'APPLY_FAILED'
            return str(state['startup_restore_status'])
        armed = bool(_install_pending_event_handler())
        state['startup_restore_status'] = 'PENDING_EVENT' if armed else 'EVENT_ARM_FAILED'
        return str(state['startup_restore_status'])
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        state['startup_restore_status'] = 'FAILED'
        state['pending_apply'] = bool(_authority_snapshot_queue(state))
        _set_write_barrier(False)
        return 'FAILED'


def _runtime_owners_ready(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None)
        scene = _window_scene(ctx)
        if bpy.app.background:
            # Background Blender has no interactive window/screen hierarchy, but
            # its WindowManager and Scene RNA owners are sufficient for a safe
            # settings replay.  Treating background mode as permanently unready
            # left the file-boundary timer resident forever.
            return wm is not None and scene is not None
        windows = tuple(getattr(wm, 'windows', ()) or ())
        if not windows or scene is None or getattr(ctx, 'view_layer', None) is None:
            return False
        for window in windows:
            screen = getattr(window, 'screen', None)
            if screen is not None and tuple(getattr(screen, 'areas', ()) or ()):
                return True
    except Exception:
        return False
    return False


def _runtime_owner_signature(context=None) -> tuple[int, int, int, int]:
    """Return a primitive owner identity used only at finite load boundaries."""
    ctx = context or getattr(bpy, 'context', None)

    def _identity(value) -> int:
        if value is None:
            return 0
        try:
            pointer = getattr(value, 'as_pointer', None)
            if callable(pointer):
                result = int(pointer())
                if result:
                    return result
        except Exception:
            pass
        try:
            return int(id(value))
        except Exception:
            return 0

    try:
        wm = getattr(ctx, 'window_manager', None)
    except Exception:
        wm = None
    try:
        scene = _window_scene(ctx)
    except Exception:
        scene = None
    try:
        view_layer = getattr(ctx, 'view_layer', None)
    except Exception:
        view_layer = None
    try:
        window = getattr(ctx, 'window', None)
    except Exception:
        window = None
    return (_identity(wm), _identity(scene), _identity(view_layer), _identity(window))


# ---------------------------------------------------------------------------
# 1.1.130 authoritative finite persistence lifecycle
# ---------------------------------------------------------------------------
import uuid as _uuid
from . import runtime_ledger as _runtime_ledger

_PERSISTENCE_STATE_NAMESPACE_KEY_V2 = 'JELARARAGI_SMART_WORKSPACE_SUITE_PERSISTENCE_STATE_V2'
_PENDING_EVENT_HANDLER_INSTALLED = False
_LAST_GOOD_N_PANEL_PAYLOAD = None
_MAX_AUTHORITY_SNAPSHOTS = 8
_JOURNAL_RECOVERY_SOURCE = 'live-journal-no-disk-authority'
_JOURNAL_RECOVERY_REVISION = 1
_JOURNAL_RECOVERY_WRITER_ID = 'journal-recovery'
_USER_CHANGE_SAVE_TIMER_SLOT = 'persistence._user_change_save_once'
_USER_CHANGE_SAVE_DELAY = 0.25
_USER_CHANGE_SAVE_DEADLINE = 0.0
_PERSISTENCE_SESSION_STATE: dict[str, Any] | None = None


def _suite_generation_token() -> str:
    token = _runtime_ledger.current_generation()
    return token or 'UNREGISTERED'


def _lifecycle_state() -> dict[str, Any]:
    global _PERSISTENCE_SESSION_STATE, _DEFERRED_SETTINGS_DIRTY
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        namespace = globals()
    generation = _suite_generation_token()
    state = namespace.get(_PERSISTENCE_STATE_NAMESPACE_KEY_V2)
    if (
        not isinstance(state, dict)
        and isinstance(_PERSISTENCE_SESSION_STATE, dict)
        and generation != 'UNREGISTERED'
        and str(_PERSISTENCE_SESSION_STATE.get('generation') or '') == generation
    ):
        # load_pre runs before Blender replaces driver_namespace. Keep the exact
        # generation-bound state object alive in this imported module so
        # load_post can consume the queued authority after the new Main exists.
        state = _PERSISTENCE_SESSION_STATE
        namespace[_PERSISTENCE_STATE_NAMESPACE_KEY_V2] = state
    if not isinstance(state, dict):
        state = {}
    # Never adopt a prior generation's load snapshots or ownership flags. A
    # pending user edit is different: the RNA values are still live across an
    # importlib reload, so carry only that bounded transaction into the new
    # generation and re-arm its one-shot save after registration.
    if str(state.get('generation') or '') != generation:
        previous_dirty = bool(
            isinstance(state.get('pending_user_payload'), dict)
            or state.get('user_change_save_scheduled')
        )
        previous_payload = (
            copy.deepcopy(state.get('pending_user_payload'))
            if isinstance(state.get('pending_user_payload'), dict)
            else None
        )
        previous_verified = bool(
            previous_payload is not None
            and state.get('pending_user_payload_verified') is True
        )
        previous_source = str(
            state.get('pending_user_change_source')
            or state.get('last_user_change_source')
            or 'hot-reload-pending-user-change'
        )
        try:
            previous_deadline = float(state.get('user_change_save_deadline') or 0.0)
        except Exception:
            previous_deadline = 0.0
        state = {
            'generation': generation,
            'load_token': '',
            'write_blocked': False,
            'authority_snapshot': None,
            'authority_snapshots': [],
            'pending_apply': False,
            'pending_user_payload': previous_payload,
            'pending_user_payload_verified': previous_verified,
            'pending_commit': bool(previous_dirty),
            'dirty': bool(previous_dirty),
            'attempts': 0,
            'timer_registered': False,
            'load_post_seen': False,
            'load_pre_owner_signature': None,
            'last_error': '',
            'last_success_revision': 0,
            'startup_restore_token': '',
            'startup_restore_done': False,
            'startup_restore_status': 'NOT_REQUESTED',
            'user_change_save_scheduled': False,
            'user_change_save_deadline': previous_deadline if previous_dirty else 0.0,
            'pending_user_change_source': previous_source,
        }
        # The module-level dirty cache is only a fast mirror of this record's
        # 'dirty' field; mark/clear always write the pair together.  Rebuilding
        # the record for a new generation without rescoping the cache is the one
        # way the two can diverge, and it leaves a retired bit that names no live
        # unit of work asserting dirt for every later generation in the process.
        # Carry it across exactly like 'dirty': a concrete pending payload or an
        # armed one-shot save survives, a bare bit does not.
        _DEFERRED_SETTINGS_DIRTY = bool(previous_dirty)
        namespace[_PERSISTENCE_STATE_NAMESPACE_KEY_V2] = state
    if str(state.get('generation') or '') == generation:
        _PERSISTENCE_SESSION_STATE = state
    return state


def _authority_snapshot_queue(state: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Return this generation's bounded FIFO without adopting foreign state."""
    state = state if isinstance(state, dict) else _lifecycle_state()
    raw = state.get('authority_snapshots')
    if not isinstance(raw, list):
        raw = []
    # Migrate only this same lifecycle record's pre-queue snapshot.  Snapshot
    # generation is checked again before application.
    legacy = state.get('authority_snapshot')
    if not raw and isinstance(legacy, dict):
        raw.append(copy.deepcopy(legacy))
    state['authority_snapshots'] = raw
    state['authority_snapshot'] = copy.deepcopy(raw[0]) if raw else None
    return raw


def _enqueue_authority_snapshot(state: dict[str, Any], snapshot: dict[str, Any], load_token: str) -> bool:
    queue = _authority_snapshot_queue(state)
    if len(queue) >= _MAX_AUTHORITY_SNAPSHOTS:
        # Never evict an unapplied authority.  A pathological overlapping-load
        # storm is reported as restart-required rather than silently losing the
        # oldest or newest user state.
        state['last_error'] = 'authority snapshot queue full; restart required'
        state['restart_required'] = True
        state['pending_apply'] = bool(queue)
        return False
    item = copy.deepcopy(snapshot)
    item['load_token'] = str(load_token)
    queue.append(item)
    state['authority_snapshot'] = copy.deepcopy(queue[0])
    state['pending_apply'] = True
    return True


def _complete_authority_snapshot(state: dict[str, Any], *, success: bool) -> None:
    queue = _authority_snapshot_queue(state)
    if success and queue:
        queue.pop(0)
    state['authority_snapshot'] = copy.deepcopy(queue[0]) if queue else None
    state['pending_apply'] = bool(queue) if success else bool(queue or state.get('authority_snapshot'))


def _state_generation_current(state: dict[str, Any] | None = None) -> bool:
    state = state if isinstance(state, dict) else _lifecycle_state()
    return str(state.get('generation') or '') == _suite_generation_token()


def _pending_validated_n_panel_base() -> tuple[int, str, str] | None:
    """Return the exact disk base held by this generation's pending restore."""
    state = _lifecycle_state()
    if not _state_generation_current(state):
        return None
    if str(state.get('startup_restore_status') or '') != 'PENDING_EVENT':
        return None
    queue = state.get('authority_snapshots')
    if not isinstance(queue, list) or not queue:
        return None
    snapshot = queue[0]
    if not isinstance(snapshot, dict):
        return None
    generation = str(snapshot.get('generation') or '')
    load_token = str(snapshot.get('load_token') or '')
    if generation != _suite_generation_token():
        return None
    if not load_token or load_token != str(state.get('startup_restore_token') or ''):
        return None
    if snapshot.get('authority_was_validated') is not True:
        return None
    try:
        revision = int(snapshot.get('validated_base_revision') or 0)
    except Exception:
        return None
    writer_id = str(snapshot.get('validated_base_writer_id') or '')
    digest = str(snapshot.get('validated_base_digest') or '')
    if revision <= 0 or not writer_id or not digest:
        return None
    return revision, writer_id, digest


def _set_write_barrier(blocked: bool) -> None:
    global _FILE_LOAD_IN_PROGRESS
    state = _lifecycle_state()
    state['write_blocked'] = bool(blocked)
    _FILE_LOAD_IN_PROGRESS = bool(blocked)


def runtime_sidecar_write_blocked(*, verified_user_change: bool = False) -> bool:
    del verified_user_change
    state = _lifecycle_state()
    # A user-invoked import/export owns a synchronous transaction and must not
    # inherit a stale load-snapshot/write-barrier fence.  Registration, active
    # RNA restore, and teardown ownership barriers still fail closed.
    if _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE:
        return bool(
            _RESTORING
            or _TEARDOWN_RUNTIME_WRITE_BLOCKED
            or _suite_storage.registration_write_guard_active()
        )
    return bool(
        state.get('write_blocked')
        or _RESTORING
        or _TEARDOWN_RUNTIME_WRITE_BLOCKED
        or _suite_storage.registration_write_guard_active()
    )


def mark_deferred_settings_dirty() -> bool:
    global _DEFERRED_SETTINGS_DIRTY
    _DEFERRED_SETTINGS_DIRTY = True
    _lifecycle_state()['dirty'] = True
    return True


def deferred_settings_dirty() -> bool:
    return bool(_DEFERRED_SETTINGS_DIRTY or _lifecycle_state().get('dirty'))


def _clear_deferred_settings_dirty() -> None:
    global _DEFERRED_SETTINGS_DIRTY
    _DEFERRED_SETTINGS_DIRTY = False
    _lifecycle_state()['dirty'] = False


def live_journal_write_suppressed() -> bool:
    """Return whether an N-panel journal write would record an initialization event.

    RNA update callbacks fire while classes are registered, while validated
    state is replayed (``_RESTORING``), while serializers normalize values
    (``_SAVING``) and inside the one startup restore request.  Those callbacks
    are the same ones a user edit runs, but they carry registration defaults
    and rebound identities, not user intent.  ``persist_immediate_user_change``
    already classifies them as handled no-ops; the crash journal must apply the
    same classification, or the first such callback in a new process replaces
    the journal inherited from the previous (killed) session with an empty
    document bound to no authority before the startup snapshot can merge it.

    This rule is a superset of the one ``persist_immediate_user_change``
    applies: the startup-status clause below additionally covers the window
    between ``end_registration_write_guard`` and the return of
    ``request_startup_restore`` (status still NOT_REQUESTED/REQUESTED), where
    the in-memory authority is still empty although the guard is released.
    Once the request has returned (APPLIED, APPLY_FAILED, NO_VALID_AUTHORITY,
    PENDING_EVENT, FAILED) journal writes are never suppressed by this clause.
    """
    if _RESTORING or _SAVING or _suite_storage.registration_write_guard_active():
        return True
    status = str(_lifecycle_state().get('startup_restore_status') or '')
    return status in ('', 'NOT_REQUESTED', 'REQUESTED')


def note_authoritative_n_panel_load(payload) -> None:
    """Remember validated authority without turning a read into a pending save."""
    global _LAST_GOOD_N_PANEL_PAYLOAD
    if isinstance(payload, dict):
        _LAST_GOOD_N_PANEL_PAYLOAD = copy.deepcopy(payload)
        state = _lifecycle_state()
        state['last_loaded_payload'] = copy.deepcopy(payload)


def _live_n_panel_save_policy(context=None, default: bool = True) -> bool:
    ctx = _safe_context(context)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    owner = getattr(wm, 'nptl_settings', None) if wm is not None else None
    try:
        value = getattr(owner, 'n_panel_state_save_enabled') if owner is not None else default
    except Exception:
        value = default
    return value if isinstance(value, bool) else True


def _policy_enabled(default: bool = True) -> bool:
    try:
        return _suite_storage.n_panel_state_save_enabled(True)
    except Exception:
        return True if default is None else bool(default)


def _payload_user_fingerprint(payload) -> bytes | None:
    """Return a metadata-independent fingerprint for one valid N-panel graph."""
    if not isinstance(payload, dict):
        return None
    try:
        normalized, _migrated = _suite_storage._strict_json.validate_current_payload(
            payload,
            allow_legacy=True,
            source='pending-user-payload',
        )
        detached = copy.deepcopy(normalized)
        for key in (
            'revision',
            'writer_id',
            'payload_checksum',
            'saved_at',
            'authority',
            'contract',
            'contract_version',
        ):
            detached.pop(key, None)
        return _suite_storage._strict_json.canonical_json_bytes(detached, pretty=False)
    except Exception:
        return None


def _same_user_payload(left, right) -> bool:
    left_fingerprint = _payload_user_fingerprint(left)
    right_fingerprint = _payload_user_fingerprint(right)
    return bool(
        left_fingerprint is not None
        and right_fingerprint is not None
        and left_fingerprint == right_fingerprint
    )


def _queue_pending_user_payload(
    values,
    *,
    verified_user_change: bool,
    source: str,
    arm_retry: bool = True,
) -> bool:
    """Retain a failed transaction and optionally arm one finite safe event."""
    if not isinstance(values, dict) or not values:
        return False
    state = _lifecycle_state()
    state['pending_user_payload'] = copy.deepcopy(values)
    state['pending_user_payload_verified'] = bool(verified_user_change)
    state['pending_commit'] = True
    state['last_pending_commit_source'] = str(source or 'pending-user-change')
    mark_deferred_settings_dirty()
    if arm_retry:
        try:
            _install_pending_event_handler()
        except Exception as exc:
            state['last_pending_handler_error'] = f'{type(exc).__name__}: {exc}'
    return True


def _accept_verified_n_panel_commit(
    values,
    result,
    rna_state,
    *,
    verified_user_change: bool,
) -> bool:
    """Publish one strict readback without clearing a newer pending payload."""
    global _LAST_GOOD_N_PANEL_PAYLOAD
    state = _lifecycle_state()
    if not isinstance(result, dict) or result.get('success') is not True:
        return False
    verified_primary = result.get('primary')
    if not isinstance(verified_primary, dict):
        return False
    _LAST_GOOD_N_PANEL_PAYLOAD = copy.deepcopy(verified_primary)
    state['last_loaded_payload'] = copy.deepcopy(verified_primary)
    state['last_success_revision'] = int(result.get('revision') or 0)
    state['last_error'] = ''
    _remember_canonical_rna_state(rna_state)
    if verified_user_change:
        _publish_verified_user_state(rna_state)

    pending_now = state.get('pending_user_payload')
    if pending_now is None or _same_user_payload(pending_now, values):
        state['pending_user_payload'] = None
        state['pending_user_payload_verified'] = False
        state['pending_commit'] = False
        _clear_deferred_settings_dirty()
    else:
        # A nested RNA update produced a newer graph while this transaction was
        # in flight.  The older commit succeeded, but the newer graph must remain
        # dirty and receive its own finite event; never clear it as collateral.
        state['pending_commit'] = True
        mark_deferred_settings_dirty()
        try:
            _install_pending_event_handler()
        except Exception:
            pass
    return True


def commit_validated_n_panel_payload_direct(
    context,
    values,
    *,
    verified_user_change: bool,
    source: str,
    arm_retry: bool = True,
) -> bool:
    """Bypass lifecycle deferral for an already validated user/load graph.

    This path intentionally ignores the transient load/Scene write barrier.  It
    still respects registration ownership and nested-save guards, validates the
    complete N-panel schema, performs the same primary+central strict transaction
    as the normal saver, and accepts success only after full readback equivalence.
    """
    global _SAVING
    if not isinstance(values, dict) or not values:
        return False
    state = _lifecycle_state()
    try:
        normalized, _migrated = _suite_storage._strict_json.validate_current_payload(
            values,
            allow_legacy=True,
            source=str(source or 'direct-commit'),
        )
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        return False

    if _SAVING or _suite_storage.registration_write_guard_active():
        _queue_pending_user_payload(
            normalized,
            verified_user_change=verified_user_change,
            source=source,
            arm_retry=arm_retry,
        )
        return False

    _SAVING = True
    try:
        from .runtime import core as _core
        ctx = _safe_context(context)
        sidecar_path = _core._refresh_config_file_path()
        central_before = _suite_storage._central_read_payload()
        previous_rna = central_before.get('rna_state', {}) if isinstance(central_before, dict) else {}
        rna_state = _preserve_unmaterialized_rna_state(
            _collect_rna_state(ctx),
            previous_rna,
        )
        nptl_rna = (
            rna_state.get('window_manager', {}).get('nptl_settings')
            if isinstance(rna_state, dict)
            else None
        )
        if not _core._nptl_rna_state_matches_current_payload(normalized, nptl_rna):
            raise RuntimeError('direct N-panel current/RNA equivalence verification failed')
        collected = _suite_storage.collect_json_storage_into_payload(central_before)
        commit_ok = _suite_storage.commit_n_panel_current_settings(
            sidecar_path,
            normalized,
            state_save_enabled=_live_n_panel_save_policy(ctx, True),
            central_updates={
                'rna_state': rna_state,
                'files': collected.get('files', {}),
            },
        )
        result = _suite_storage.last_n_panel_commit_result()
        if commit_ok is not True or not isinstance(result, dict) or result.get('success') is not True:
            raise OSError('direct strict N-panel transaction did not verify')
        verified_primary = result.get('primary')
        verified_central = result.get('central')
        verified_rna = (
            verified_central.get('rna_state', {}).get('window_manager', {}).get('nptl_settings')
            if isinstance(verified_central, dict)
            else None
        )
        if not _core._nptl_rna_state_matches_current_payload(verified_primary, verified_rna):
            raise OSError('direct strict N-panel central RNA readback mismatch')
        accepted = _accept_verified_n_panel_commit(
            normalized,
            result,
            rna_state,
            verified_user_change=verified_user_change,
        )
        if accepted:
            _core.note_canonical_commit(verified_primary)
            _core.clear_live_state_journal()
        return bool(accepted)
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        _queue_pending_user_payload(
            normalized,
            verified_user_change=verified_user_change,
            source=source,
            arm_retry=arm_retry,
        )
        return False
    finally:
        _SAVING = False


def select_explicit_export_current_payload(context, live_payload) -> tuple[dict[str, Any], str]:
    """Select the canonical N-panel graph for an explicit user export.

    Event-driven saves make the validated primary authority the complete graph
    during ordinary operation.  It may contain workspace/editor entries that
    are intentionally not materialized by the current Screen.  Prefer that
    authority when no newer user payload is dirty; otherwise export the live
    graph so State Save OFF and a failed prior commit cannot hide user edits.
    """
    normalized_live, _migrated = _suite_storage._strict_json.validate_current_payload(
        live_payload,
        allow_legacy=True,
        source='explicit-export-live',
    )
    state = _lifecycle_state()
    pending = state.get('pending_user_payload')
    if deferred_settings_dirty() or isinstance(pending, dict):
        return normalized_live, 'live-dirty'
    try:
        from .runtime import core as _core
        authority = _suite_storage.resolve_n_panel_current_settings(
            _core._refresh_config_file_path(),
            repair_primary=True,
        )
        if getattr(authority, 'valid', False) and isinstance(authority.payload, dict):
            normalized_authority, _migrated = _suite_storage._strict_json.validate_current_payload(
                authority.payload,
                allow_legacy=False,
                source='explicit-export-authority',
            )
            return normalized_authority, 'verified-authority'
    except Exception:
        pass
    return normalized_live, 'live'


def commit_explicit_settings_transaction(
    context,
    current_payload,
    *,
    central_payload=None,
    state_save_enabled=None,
    stage_local_sidecars: bool,
    source: str,
    allow_unmaterialized_n_panel: bool = False,
) -> dict[str, Any]:
    """Adopt one explicit import/export outside lifecycle revision fences.

    User-invoked settings I/O is not a delayed load snapshot.  This transaction
    therefore ignores Scene/load revision fences, while still refusing nested
    serializers and registration-time ownership changes.  Success requires a
    fresh local revision plus verified primary/central authority readback.
    Runtime RNA equivalence remains strict by default; explicit import may allow
    a partial current-Screen projection while retaining the complete canonical
    payload in primary and central storage.
    """
    global _SAVING, _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE
    state = _lifecycle_state()
    ctx = _safe_context(context)
    if _SAVING or _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE:
        raise RuntimeError('explicit settings transaction is already active')
    if _RESTORING:
        raise RuntimeError('explicit settings transaction is unavailable during RNA restore')
    if _suite_storage.registration_write_guard_active():
        raise RuntimeError('explicit settings transaction is unavailable during RNA registration')
    normalized, _migrated = _suite_storage._strict_json.validate_current_payload(
        current_payload,
        allow_legacy=True,
        source=str(source or 'explicit-settings'),
    )
    if state_save_enabled is None:
        ui_state = normalized.get('ui_state') if isinstance(normalized, dict) else None
        state_save_enabled = _suite_storage._strict_json.strict_bool(
            ui_state.get(_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY) if isinstance(ui_state, dict) else None,
            default=True,
            field=_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY,
        )
    enabled = _suite_storage._strict_json.strict_bool(
        state_save_enabled,
        field=_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY,
    )

    _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE = True
    _SAVING = True
    runtime_projection_mismatch = False
    try:
        if isinstance(central_payload, dict):
            base = copy.deepcopy(central_payload)
        elif _suite_storage.central_payload_validated():
            base = _suite_storage._central_read_payload()
        else:
            base = _suite_storage._central_empty_payload()

        if stage_local_sidecars:
            _suite_storage.begin_central_write_batch()
            try:
                if not _save_explicit_json_settings(
                    ctx,
                    force=True,
                    verified_user_change=True,
                    raise_on_failure=True,
                    explicit_user_io=True,
                ):
                    raise OSError('explicit settings serializers returned no verified success')
            finally:
                _suite_storage.end_central_write_batch()
            base = _suite_storage.collect_json_storage_into_payload(base)

        live_rna = _collect_rna_state(ctx)
        if isinstance(central_payload, dict):
            imported_rna = base.get('rna_state', {})
            rna_state = _preserve_unmaterialized_rna_state(imported_rna, live_rna)
            rna_state = _merge_authoritative_n_panel_state(rna_state, ctx)
        else:
            previous_rna = base.get('rna_state', {}) if isinstance(base, dict) else {}
            rna_state = _preserve_unmaterialized_rna_state(live_rna, previous_rna)
        nptl_rna = (
            rna_state.get('window_manager', {}).get('nptl_settings')
            if isinstance(rna_state, dict)
            else None
        )
        from .runtime import core as _core
        if not _core._nptl_rna_state_matches_current_payload(normalized, nptl_rna):
            if not allow_unmaterialized_n_panel:
                raise RuntimeError('explicit N-panel current/RNA equivalence verification failed')
            runtime_projection_mismatch = True
        if not isinstance(base, dict):
            base = _suite_storage._central_empty_payload()
        base['rna_state'] = rna_state
        base[_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY] = enabled

        if not _suite_storage.adopt_n_panel_current_settings(
            _core._refresh_config_file_path(),
            normalized,
            state_save_enabled=enabled,
            central_payload=base,
            preserve_local_when_missing=False,
            source=source,
        ):
            raise OSError('explicit primary/central authority adoption failed')
        result = _suite_storage.last_n_panel_commit_result()
        if not isinstance(result, dict) or result.get('success') is not True:
            raise OSError('explicit primary/central readback result unavailable')
        verified_primary = result.get('primary')
        verified_central = result.get('central')
        verified_rna = (
            verified_central.get('rna_state', {}).get('window_manager', {}).get('nptl_settings')
            if isinstance(verified_central, dict)
            else None
        )
        if not _core._nptl_rna_state_matches_current_payload(verified_primary, verified_rna):
            if not allow_unmaterialized_n_panel:
                raise OSError('explicit central RNA readback mismatch')
            runtime_projection_mismatch = True
        if not _accept_verified_n_panel_commit(
            normalized,
            result,
            rna_state,
            verified_user_change=True,
        ):
            raise OSError('explicit committed revision was not accepted')
        _core.note_canonical_commit(verified_primary)
        _core.clear_live_state_journal()
        state['last_explicit_settings_source'] = str(source or 'explicit-settings')
        state['last_explicit_runtime_projection_mismatch'] = bool(runtime_projection_mismatch)
        returned = copy.deepcopy(result)
        returned['runtime_projection_mismatch'] = bool(runtime_projection_mismatch)
        return returned
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        mark_deferred_settings_dirty()
        raise
    finally:
        _SAVING = False
        _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE = False


def apply_explicit_central_runtime(context, central_payload) -> bool:
    """Apply an already committed explicit central import without re-saving."""
    global _RESTORING
    if not isinstance(central_payload, dict):
        return True
    central, _migrated = _suite_storage._strict_json.validate_central_payload(
        central_payload,
        allow_legacy=False,
        source='explicit-import-committed-central',
    )
    ctx = _safe_context(context)
    old_restoring = _RESTORING
    _RESTORING = True
    try:
        if not _suite_storage.restore_central_settings_to_files(force=True):
            raise OSError('committed central sidecars could not be restored')
        _load_explicit_json_settings(ctx)
        imported_state = central.get('rna_state', {})
        imported_state = _merge_authoritative_n_panel_state(imported_state, ctx)
        imported_state = ensure_runtime_rna_state(imported_state, ctx)
        if restore_rna_state(ctx, state_override=imported_state) is not True:
            raise RuntimeError('imported RNA state transaction failed')
        _remember_canonical_rna_state(imported_state)
        _activate_restored_runtime_toggles(ctx)
        return True
    finally:
        _RESTORING = old_restoring


def persist_immediate_user_change(
    context=None,
    *,
    source: str = 'rna-update',
    force: bool = False,
) -> bool:
    """Persist one explicit user change through the complete strict graph.

    Consecutive UI edits are coalesced into one generation-bound, one-shot save.
    The callback never repeats and therefore contributes no idle load. Explicit
    force/file-boundary saves remain synchronous and retain strict readback.
    """
    state = _lifecycle_state()
    state['last_user_change_source'] = str(source or 'rna-update')

    # RNA update callbacks also run while classes are being registered, while
    # validated state is replayed, and while serializers normalize values.
    # Those are initialization events, not user edits: never promote their
    # defaults into pending authority and never make them dirty.
    if _RESTORING or _SAVING or _suite_storage.registration_write_guard_active():
        state['last_suppressed_change_source'] = str(source or 'rna-update')
        # This callback was generated by registration, strict replay, or a
        # synchronous serializer rather than by a user edit.  Report it as a
        # handled no-op so wrappers do not create a false dirty transaction.
        return True

    if runtime_sidecar_write_blocked(verified_user_change=True):
        try:
            from .runtime import core as _core
            pending = _core._nptl_current_payload(_safe_context(context))
        except Exception:
            pending = None
        if isinstance(pending, dict) and pending:
            return bool(commit_validated_n_panel_payload_direct(
                context,
                pending,
                verified_user_change=True,
                source=f'immediate-blocked:{source}',
            ))
        mark_deferred_settings_dirty()
        try:
            _install_pending_event_handler()
        except Exception:
            pass
        return False
    enabled = _live_n_panel_save_policy(context, True)
    if not enabled and not force:
        _cancel_user_change_save()
        mark_deferred_settings_dirty()
        return False
    if not force:
        return _schedule_user_change_save(context, source=source)
    _cancel_user_change_save()
    ok = bool(save_all_settings(
        context,
        force_central=True,
        verified_user_change=True,
    ))
    if not ok:
        mark_deferred_settings_dirty()
    return ok


def _cancel_user_change_save() -> bool:
    """Remove the exact one-shot UI save callback, if one is pending."""
    global _USER_CHANGE_SAVE_DEADLINE
    state = _lifecycle_state()
    ok = _suite_storage.unregister_timer_slot(
        _USER_CHANGE_SAVE_TIMER_SLOT,
        globals().get('_user_change_save_once'),
    )
    state['user_change_save_scheduled'] = False
    state['user_change_save_deadline'] = 0.0
    _USER_CHANGE_SAVE_DEADLINE = 0.0
    return bool(ok)


def _user_change_save_once():
    """Flush one quiet-period UI edit batch and then leave no timer behind."""
    global _USER_CHANGE_SAVE_DEADLINE
    state = _lifecycle_state()
    if not _state_generation_current(state) or not _REGISTERED:
        state['user_change_save_scheduled'] = False
        _USER_CHANGE_SAVE_DEADLINE = 0.0
        return None
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if bool(getattr(wm, 'is_interface_locked', False)):
        return 0.2
    deadline = float(
        state.get('user_change_save_deadline')
        or _USER_CHANGE_SAVE_DEADLINE
        or 0.0
    )
    remaining = deadline - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    state['user_change_save_scheduled'] = False
    state['user_change_save_deadline'] = 0.0
    _USER_CHANGE_SAVE_DEADLINE = 0.0
    if not _live_n_panel_save_policy(getattr(bpy, 'context', None), True):
        return None
    if not deferred_settings_dirty() and not isinstance(state.get('pending_user_payload'), dict):
        return None
    ok = bool(save_all_settings(
        getattr(bpy, 'context', None),
        force_central=True,
        verified_user_change=True,
    ))
    if not ok:
        try:
            _install_pending_event_handler()
        except Exception:
            pass
    return None


def _schedule_user_change_save(context=None, *, source: str = 'rna-update') -> bool:
    """Mark one edit batch dirty and restart a bounded quiet-period callback.

    Building the N-panel payload reconciles every workspace and serializes every
    detected tab/panel row. Doing that here made the UI update callback itself
    expensive and repeated the same work for every slider/section event. The
    one-shot callback calls ``save_all_settings()``, which captures the current
    payload once at commit time, so pre-capturing it here is redundant.
    """
    global _USER_CHANGE_SAVE_DEADLINE
    state = _lifecycle_state()
    state['pending_user_change_source'] = str(source or 'rna-update')
    mark_deferred_settings_dirty()
    _USER_CHANGE_SAVE_DEADLINE = time.monotonic() + _USER_CHANGE_SAVE_DELAY
    state['user_change_save_deadline'] = _USER_CHANGE_SAVE_DEADLINE

    try:
        if bpy.app.timers.is_registered(_user_change_save_once):
            state['user_change_save_scheduled'] = True
            return True
    except Exception:
        pass

    registered = _suite_storage.register_timer_slot(
        _USER_CHANGE_SAVE_TIMER_SLOT,
        _user_change_save_once,
        first_interval=_USER_CHANGE_SAVE_DELAY,
        persistent=False,
    )
    state['user_change_save_scheduled'] = bool(registered)
    if registered:
        return True

    # Restricted/background contexts can reject timer registration. Preserve
    # the exact prior behavior there instead of dropping a user setting.
    _USER_CHANGE_SAVE_DEADLINE = 0.0
    state['user_change_save_deadline'] = 0.0
    return bool(save_all_settings(
        context,
        force_central=True,
        verified_user_change=True,
    ))


def _capture_authority_snapshot(context=None) -> dict[str, Any] | None:
    """Capture validated authority plus generation-bound pending user values."""
    state = _lifecycle_state()
    try:
        from .runtime import core as _core
        path = _core._refresh_config_file_path()
        authority = _suite_storage.resolve_n_panel_current_settings(path, repair_primary=False)
    except Exception:
        authority = None
    authority_valid = bool(authority is not None and getattr(authority, 'valid', False))
    base_digest = ''
    if authority_valid:
        base_revision = int(authority.payload.get('revision') or 0)
        base_writer_id = str(authority.payload.get('writer_id') or '')
        base_digest = str(_core._authority_content_digest(authority.payload) or '')
        current_payload = _core._merge_live_state_overlay(
            copy.deepcopy(authority.payload)
        )
        source = str(authority.source)
        if current_payload != authority.payload:
            current_payload = _suite_storage._strict_json.finalize_current_payload(
                current_payload,
                revision=base_revision,
                writer_id=base_writer_id,
                authority='memory',
            )
            source += ':live-journal'
    else:
        # Keep an already-captured failed user transaction across a file load,
        # but never manufacture authority from class/RNA defaults.
        pending = state.get('pending_user_payload')
        if (
            deferred_settings_dirty()
            and state.get('pending_user_payload_verified') is True
            and isinstance(pending, dict)
            and pending
        ):
            current_payload = copy.deepcopy(pending)
            source = 'pending-verified-user-change-no-disk-authority'
        else:
            # Primary, backup and central all resolved to no candidate for this
            # storage root.  A structurally valid crash-safe journal is then the
            # only record of the user's committed N-panel edits (it is written
            # solely from RNA update callbacks and explicit import).  Recover it
            # through the same strict finalize/validate/apply/flush path as disk
            # authority; a corrupt-but-present candidate is never bypassed.
            if authority is None or getattr(authority, 'candidates', ()):
                return None
            try:
                recovered = _core.recover_live_state_without_authority(
                    _safe_context(context)
                )
            except Exception as exc:
                state['last_journal_recovery_error'] = f'{type(exc).__name__}: {exc}'
                return None
            if not isinstance(recovered, dict) or not recovered:
                return None
            try:
                current_payload = _suite_storage._strict_json.finalize_current_payload(
                    recovered,
                    revision=_JOURNAL_RECOVERY_REVISION,
                    writer_id=_JOURNAL_RECOVERY_WRITER_ID,
                    authority='memory',
                )
            except Exception as exc:
                state['last_journal_recovery_error'] = f'{type(exc).__name__}: {exc}'
                return None
            source = _JOURNAL_RECOVERY_SOURCE
        base_revision = 0
        base_writer_id = ''
    if deferred_settings_dirty():
        pending = state.get('pending_user_payload')
        if not isinstance(pending, dict):
            try:
                pending = _core._nptl_current_payload(_safe_context(context))
            except Exception:
                pending = None
        if (
            isinstance(pending, dict)
            and pending
            and (
                (authority_valid and int(state.get('last_success_revision') or 0) > 0)
                or (not authority_valid and state.get('pending_user_payload_verified') is True)
            )
        ):
            current_payload = copy.deepcopy(pending)
            source = 'live-pending-over-validated-authority'
    try:
        rna_state = _collect_rna_state(context) if deferred_settings_dirty() else _canonical_rna_state_snapshot()
    except Exception:
        rna_state = {}
    return {
        'generation': _suite_generation_token(),
        'current_payload': current_payload,
        'validated_base_revision': base_revision,
        'validated_base_writer_id': base_writer_id,
        'validated_base_digest': base_digest,
        'authority_was_validated': authority_valid,
        'rna_state': copy.deepcopy(rna_state) if isinstance(rna_state, dict) else {},
        'source': source,
        'captured_monotonic': time.monotonic(),
    }


def save_n_panel_manager_transaction(
    context,
    sidecar_path,
    values,
    *,
    force: bool = False,
    verified_user_change: bool = False,
) -> bool:
    """Commit main+central and report success only after strict dual readback."""
    global _SAVING, _LAST_GOOD_N_PANEL_PAYLOAD
    if not isinstance(values, dict):
        return False
    state = _lifecycle_state()
    if runtime_sidecar_write_blocked() or _scene_boundary_pending(context):
        return bool(commit_validated_n_panel_payload_direct(
            context,
            values,
            verified_user_change=verified_user_change,
            source='n-panel-transaction-blocked',
        ))
    enabled = _live_n_panel_save_policy(context, True)
    if not force and not enabled:
        _queue_pending_user_payload(
            values,
            verified_user_change=verified_user_change,
            source='n-panel-state-save-disabled',
        )
        return False
    if _SAVING:
        # A nested request is deferred; it is not a verified commit.
        _queue_pending_user_payload(
            values,
            verified_user_change=verified_user_change,
            source='nested-n-panel-transaction',
        )
        return False
    _SAVING = True
    try:
        central_before = _suite_storage._central_read_payload()
        previous_rna = central_before.get('rna_state', {}) if isinstance(central_before, dict) else {}
        rna_state = _preserve_unmaterialized_rna_state(
            _collect_rna_state(context),
            previous_rna,
        )
        try:
            from .runtime import core as _core
            nptl_rna = (
                rna_state.get('window_manager', {}).get('nptl_settings')
                if isinstance(rna_state, dict)
                else None
            )
            if not _core._nptl_rna_state_matches_current_payload(values, nptl_rna):
                raise RuntimeError('central N-panel RNA graph does not match current settings')
        except Exception as exc:
            raise RuntimeError('N-panel current/RNA equivalence verification failed') from exc
        collected = _suite_storage.collect_json_storage_into_payload(central_before)
        # current_settings is injected by the strict transaction itself.
        commit_ok = _suite_storage.commit_n_panel_current_settings(
            sidecar_path,
            values,
            state_save_enabled=enabled,
            central_updates={
                'rna_state': rna_state,
                'files': collected.get('files', {}),
            },
        )
        result = _suite_storage.last_n_panel_commit_result()
        if commit_ok is not True or not isinstance(result, dict) or result.get('success') is not True:
            raise OSError('strict N-panel transaction did not verify')
        verified_primary = result.get('primary')
        verified_central = result.get('central')
        verified_rna = (
            verified_central.get('rna_state', {}).get('window_manager', {}).get('nptl_settings')
            if isinstance(verified_central, dict)
            else None
        )
        if not _core._nptl_rna_state_matches_current_payload(verified_primary, verified_rna):
            raise OSError('strict N-panel central RNA readback mismatch')
        return _accept_verified_n_panel_commit(
            values,
            result,
            rna_state,
            verified_user_change=verified_user_change,
        )
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        _queue_pending_user_payload(
            values,
            verified_user_change=verified_user_change,
            source='n-panel-transaction-failed',
        )
        return False
    finally:
        _SAVING = False


def save_runtime_settings_transaction(
    context,
    sidecar_path,
    values,
    *,
    force: bool = False,
    verified_restore: bool = False,
    verified_user_change: bool = False,
) -> bool:
    """Write an explicit sidecar and verified central mirror or return False."""
    del verified_restore
    if not isinstance(values, dict):
        return False
    if runtime_sidecar_write_blocked() or (
        _scene_boundary_pending(context) and not _EXPLICIT_SETTINGS_TRANSACTION_ACTIVE
    ):
        mark_deferred_settings_dirty()
        return False
    enabled = _live_n_panel_save_policy(context, True)
    if not force and not enabled:
        mark_deferred_settings_dirty()
        return False
    try:
        outer_batch = _suite_storage.central_write_batch_active()
        sidecar_ok = _suite_storage.atomic_write_json(
            sidecar_path,
            values,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
        )
        if sidecar_ok is not True:
            raise OSError('sidecar atomic write did not verify')
        if outer_batch:
            # save_all_settings will collect this verified sidecar and publish one
            # primary+central revision for the complete settings graph.
            return True
        payload = _suite_storage.collect_json_storage_into_payload(
            _suite_storage._central_read_payload()
        )
        payload[_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY] = enabled
        ok = _suite_storage._central_write_payload(payload)
        if ok is not True:
            raise OSError('central write blocked or failed verification')
        if verified_user_change:
            _publish_verified_user_state(_collect_rna_state(context))
        return True
    except Exception:
        mark_deferred_settings_dirty()
        return False


def save_rna_state(
    context=None,
    *,
    force: bool = False,
    verified_restore: bool = False,
    verified_user_change: bool = False,
) -> bool:
    del verified_restore
    if runtime_sidecar_write_blocked() and not force:
        mark_deferred_settings_dirty()
        return False
    try:
        payload = _suite_storage._central_read_payload()
        old = payload.get('rna_state', {}) if isinstance(payload, dict) else {}
        state = _preserve_unmaterialized_rna_state(_collect_rna_state(context), old)
        payload['rna_state'] = state
        payload[_suite_storage.CENTRAL_N_PANEL_STATE_SAVE_KEY] = _live_n_panel_save_policy(context, True)
        ok = _suite_storage._central_write_payload(payload)
        if ok is not True:
            mark_deferred_settings_dirty()
            return False
        if verified_user_change:
            _publish_verified_user_state(state)
        else:
            _remember_canonical_rna_state(state)
        return True
    except Exception:
        mark_deferred_settings_dirty()
        return False


def _n_panel_authority_available(sidecar_path=None) -> bool:
    """Return whether a validated N-panel authority exists for this generation.

    A validated payload loaded by this process counts; otherwise the on-disk
    primary/backup/central candidates are probed read-only.  Registration
    defaults never count: a save that has no authority and no verified user
    change is refused by ``save_all_settings`` by design, and the teardown
    uses the same test to recognise that refusal before asking.
    """
    state = _lifecycle_state()
    if _LAST_GOOD_N_PANEL_PAYLOAD or state.get('last_loaded_payload'):
        return True
    if not sidecar_path:
        return False
    try:
        probe = _suite_storage.resolve_n_panel_current_settings(
            sidecar_path,
            repair_primary=False,
        )
        return bool(getattr(probe, 'valid', False))
    except Exception:
        return False


def save_all_settings(
    context=None,
    *,
    force_central: bool = False,
    verified_user_change: bool = False,
) -> bool:
    """Synchronously flush every materialized setting through strict revisions.

    A successful return means that the canonical current settings and central
    mirror were committed and read back, and that every materialized explicit
    sidecar also completed its own verified central publication.  Staged bytes,
    nested saves, and partial failures are never displayed as success.
    """
    global _SAVING
    ctx = _safe_context(context)
    state = _lifecycle_state()
    if _SAVING:
        mark_deferred_settings_dirty()
        return False
    if runtime_sidecar_write_blocked() or _scene_boundary_pending(ctx):
        try:
            from .runtime import core as _core
            pending = _core._nptl_current_payload(ctx)
        except Exception:
            pending = None
        if isinstance(pending, dict) and pending:
            return bool(commit_validated_n_panel_payload_direct(
                ctx,
                pending,
                verified_user_change=verified_user_change,
                source='save-all-blocked',
            ))
        mark_deferred_settings_dirty()
        try:
            _install_pending_event_handler()
        except Exception:
            pass
        return False
    enabled = _live_n_panel_save_policy(ctx, True)
    if not enabled and not force_central:
        mark_deferred_settings_dirty()
        return False

    _SAVING = True
    try:
        try:
            from .runtime import core as _core
            current = _core._nptl_current_payload(ctx)
            sidecar_path = _core._refresh_config_file_path()
        except Exception:
            current = None
            sidecar_path = None

        # Missing/corrupt primary+backup+central must never make registration
        # defaults authoritative.  A real, explicitly verified user edit may
        # initialize revision 1; all other paths retain dirty state unchanged.
        has_valid_authority = _n_panel_authority_available(sidecar_path)
        if not has_valid_authority and not verified_user_change:
            mark_deferred_settings_dirty()
            return False

        if not isinstance(current, dict) or not current:
            current = state.get('pending_user_payload') or _LAST_GOOD_N_PANEL_PAYLOAD
        if not isinstance(current, dict) or not current or not sidecar_path:
            mark_deferred_settings_dirty()
            return False

        # Stage all materialized sidecars without allowing each serializer to
        # create an independent central revision.  Every stage performs its own
        # atomic replacement/readback; only the final canonical transaction may
        # report the complete save as successful.
        _suite_storage.begin_central_write_batch()
        try:
            staged_ok = _save_explicit_json_settings(
                ctx,
                force=True,
                verified_user_change=verified_user_change,
            )
        finally:
            _suite_storage.end_central_write_batch()
        if not staged_ok:
            raise OSError('one or more explicit settings serializers failed')

        # Commit current_settings + every staged sidecar + canonical RNA through
        # one monotonic revision/writer/checksum contract and verify primary and
        # central readback before clearing dirty state.
        _SAVING = False
        try:
            canonical_ok = save_n_panel_manager_transaction(
                ctx,
                sidecar_path,
                current,
                force=True,
                verified_user_change=verified_user_change,
            )
        finally:
            _SAVING = True
        if not canonical_ok:
            mark_deferred_settings_dirty()
            return False
        try:
            commit_result = _suite_storage.last_n_panel_commit_result()
            verified_primary = commit_result.get('primary') if isinstance(commit_result, dict) else None
            if isinstance(verified_primary, dict):
                _core.note_canonical_commit(verified_primary)
            _core.clear_live_state_journal()
        except Exception:
            pass
        return True
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        mark_deferred_settings_dirty()
        return False
    finally:
        _SAVING = False
        _mark_active_scene(ctx)

def load_all_settings(context=None, *, state_override=None):
    """Restore only validated current/central authority without writing."""
    global _RESTORING
    if _RESTORING:
        return None
    _RESTORING = True
    ctx = _safe_context(context)
    restored_state = copy.deepcopy(state_override.get('rna_state', {})) if isinstance(state_override, dict) and 'rna_state' in state_override else None
    try:
        # Other explicit sidecars may be restored only from a validated central
        # envelope. current_settings is independently resolved in core.
        _suite_storage.restore_central_settings_to_files(force=False)
        _load_explicit_json_settings(ctx)
        override_requested = False
        try:
            from .runtime import core as _core
            override_current = (
                copy.deepcopy(state_override.get('current_payload'))
                if isinstance(state_override, dict) and isinstance(state_override.get('current_payload'), dict)
                else None
            )
            if isinstance(override_current, dict):
                override_requested = True
                normalized, _legacy = _core._strict_json.validate_current_payload(
                    override_current,
                    allow_legacy=False,
                    source='generation-bound-load-snapshot',
                )
                prepared = _core._prepare_loaded_workspace_payload(normalized)
                # The snapshot already carries the journal overlay (merged at
                # capture) and has just been rebound to this process's workspace
                # UUIDs.  Re-merging the journal here would put the previous
                # process's UUIDs back and fail the strict readback.
                current_ok = bool(_core._apply_loaded_data(
                    ctx,
                    prepared,
                    use_live_overlay=False,
                ))
                if current_ok:
                    _core._LAST_LOADED_N_PANEL_AUTHORITY = copy.deepcopy(normalized)
                    # ``normalized`` already carries the journal; the journal
                    # base must keep naming the on-disk content it overlays.
                    journal_recovery = (
                        str(state_override.get('source') or '') == _JOURNAL_RECOVERY_SOURCE
                    )
                    if journal_recovery:
                        base_revision = _JOURNAL_RECOVERY_REVISION
                        base_writer_id = _JOURNAL_RECOVERY_WRITER_ID
                        base_digest = str(_core._authority_content_digest(normalized) or '')
                        _core._LAST_LOADED_BASE_DIGEST = ''
                    else:
                        base_revision = int(state_override.get('validated_base_revision') or 0)
                        base_writer_id = str(state_override.get('validated_base_writer_id') or '')
                        base_digest = str(state_override.get('validated_base_digest') or '')
                        _core._LAST_LOADED_BASE_DIGEST = base_digest
                    try:
                        _core.rebase_live_state_journal(base_revision, base_writer_id, base_digest)
                    except Exception:
                        pass
                    note_authoritative_n_panel_load(normalized)
            else:
                current_ok = bool(_core.load_config_from_file(ctx))
        except Exception as exc:
            current_ok = False
            _lifecycle_state()['last_error'] = f'{type(exc).__name__}: {exc}'
        if override_requested and not current_ok:
            # A generation-bound snapshot is newer than central RNA. Never let
            # an invalid/partial snapshot fall through and replay the older,
            # commonly empty N-panel root over the live settings.
            mark_deferred_settings_dirty()
            return None
        central_ok = bool(_suite_storage.central_payload_validated())
        if not current_ok and not central_ok:
            # All authority candidates are invalid/missing.  A mere RNA-state
            # override is not authority and cannot publish startup defaults.
            return None
        if restored_state is None:
            try:
                restored_state = copy.deepcopy(_suite_storage._central_read_payload().get('rna_state', {})) if central_ok else {}
            except Exception:
                restored_state = {}
        if not isinstance(restored_state, dict):
            restored_state = {}
        if current_ok:
            restored_state = _merge_authoritative_n_panel_state(restored_state, ctx)
        restored_state = ensure_runtime_rna_state(restored_state, ctx)
        if restore_rna_state(ctx, state_override=restored_state) is not True:
            # Nested collection restore is transactional.  A failed readback or
            # rollback may not be reported as a successful import/load.
            mark_deferred_settings_dirty()
            return None
        _remember_canonical_rna_state(restored_state)
        _activate_restored_runtime_toggles(ctx)
        return copy.deepcopy(restored_state)
    finally:
        _RESTORING = False
        _mark_active_scene(ctx)


def _remove_pending_event_handler() -> None:
    global _PENDING_EVENT_HANDLER_INSTALLED
    handlers = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
    if handlers is not None:
        _remove_handler(handlers, _pending_restore_event)
    _runtime_ledger.remove_feature_leases('persistence-pending-event', any_generation=False)
    _PENDING_EVENT_HANDLER_INSTALLED = False


def _pending_handler_remover(handle, handlers):
    try:
        while handle in handlers:
            handlers.remove(handle)
    except Exception:
        pass


def _install_pending_event_handler() -> bool:
    """Arm exactly one event-driven retry; it removes itself before work."""
    global _PENDING_EVENT_HANDLER_INSTALLED
    generation = _runtime_ledger.current_generation()
    if (
        _PENDING_EVENT_HANDLER_INSTALLED
        or not generation
        or not _runtime_ledger.generation_matches(generation)
    ):
        return bool(_PENDING_EVENT_HANDLER_INSTALLED)
    handlers = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
    if handlers is None:
        return False
    _append_handler(handlers, _pending_restore_event)
    _PENDING_EVENT_HANDLER_INSTALLED = True
    if not _runtime_ledger.register_lease(
        feature='persistence-pending-event',
        space='GLOBAL',
        region='DEPSGRAPH_UPDATE_POST',
        handle=_pending_restore_event,
        native_remover=_pending_handler_remover,
        remove_args=(handlers,),
        is_registered=lambda handle: handle in handlers,
    ):
        _pending_handler_remover(_pending_restore_event, handlers)
        _PENDING_EVENT_HANDLER_INSTALLED = False
        return False
    return True


def _finish_pending_restore(*, success: bool, keep_snapshot: bool = True) -> None:
    global _FILE_POST_RESTORE_TIMER_REGISTERED, _FILE_POST_RESTORE_ATTEMPTS
    state = _lifecycle_state()
    try:
        _suite_storage.unregister_timer_slot(
            'persistence._deferred_file_restore_tick',
            _deferred_file_restore_tick,
        )
        _runtime_ledger.remove_feature_leases('persistence-restore-timer', any_generation=False)
    finally:
        _FILE_POST_RESTORE_TIMER_REGISTERED = False
        _FILE_POST_RESTORE_ATTEMPTS = 0
        state['timer_registered'] = False
        if success:
            state['attempts'] = 0
        if success and not keep_snapshot:
            _complete_authority_snapshot(state, success=True)
        else:
            _complete_authority_snapshot(state, success=False)
        _remove_pending_event_handler()
        _set_write_barrier(False)


def _apply_pending_restore(reason: str) -> bool:
    """Apply and durably flush one generation-bound snapshot as one success.

    The immutable authority snapshot is removed only after both RNA application
    and the normalized primary+central strict transaction have succeeded.  An
    apply/read/write/readback failure retains the same snapshot and dirty state
    for the next explicit safe boundary; no resident poll is installed.
    """
    state = _lifecycle_state()
    if not _state_generation_current(state):
        state['last_error'] = 'generation mismatch'
        _finish_pending_restore(success=False, keep_snapshot=True)
        return False
    queue = _authority_snapshot_queue(state)
    snapshot = queue[0] if queue else state.get('authority_snapshot')
    if not isinstance(snapshot, dict):
        state['last_error'] = 'authority snapshot unavailable'
        _finish_pending_restore(success=False, keep_snapshot=True)
        return False
    if str(snapshot.get('generation') or '') != _suite_generation_token():
        state['last_error'] = 'authority snapshot generation mismatch'
        _finish_pending_restore(success=False, keep_snapshot=True)
        return False

    # Revision fence: a user/import transaction committed after load_pre is the
    # newer authority.  Replaying the older immutable snapshot at load_post,
    # save_pre, or teardown would otherwise erase that transaction.
    try:
        from .runtime import core as _core
        authority = _suite_storage.resolve_n_panel_current_settings(
            _core._refresh_config_file_path(),
            repair_primary=True,
        )
    except Exception as exc:
        state['last_snapshot_fence_error'] = f'{type(exc).__name__}: {exc}'
        state['last_error'] = 'disk authority resolution failed during snapshot revision fence'
        _finish_pending_restore(success=False, keep_snapshot=True)
        return False
    journal_recovery = bool(
        snapshot.get('authority_was_validated') is False
        and str(snapshot.get('source') or '') == _JOURNAL_RECOVERY_SOURCE
    )
    if not (
        getattr(authority, 'valid', False)
        and isinstance(getattr(authority, 'payload', None), dict)
    ):
        if not journal_recovery:
            state['last_snapshot_fence_error'] = 'validated disk authority unavailable'
            state['last_error'] = 'disk authority unavailable during snapshot revision fence'
            _finish_pending_restore(success=False, keep_snapshot=True)
            return False
        # A journal recovered without any disk authority has nothing to fence
        # against; a disk authority that appears later still wins below.
        disk_revision = 0
    else:
        disk_revision = int(authority.payload.get('revision') or 0)
    snapshot_revision = int(snapshot.get('validated_base_revision') or 0)
    if disk_revision > snapshot_revision:
        # Sidecar mirrors re-stamp the primary (new revision/writer) without
        # changing the N-panel graph.  Such a content-neutral re-stamp is not a
        # newer user transaction and must not discard the queued authority.
        snapshot_digest = str(snapshot.get('validated_base_digest') or '')
        try:
            disk_digest = str(_core._authority_content_digest(authority.payload) or '')
        except Exception:
            disk_digest = ''
        if snapshot_digest and disk_digest and snapshot_digest == disk_digest:
            snapshot_revision = disk_revision
    if disk_revision > snapshot_revision:
        state['last_fenced_snapshot'] = {
            'reason': str(reason),
            'snapshot_revision': snapshot_revision,
            'disk_revision': disk_revision,
            'load_token': str(snapshot.get('load_token') or ''),
        }
        state['last_error'] = ''
        _finish_pending_restore(success=True, keep_snapshot=False)
        if state.get('pending_apply'):
            try:
                _install_pending_event_handler()
            except Exception:
                pass
        return True

    if not _runtime_owners_ready():
        state['pending_apply'] = True
        _set_write_barrier(False)
        return False

    applied = False
    flushed = False
    try:
        loaded = load_all_settings(
            getattr(bpy, 'context', None),
            state_override=snapshot,
        )
        applied = isinstance(loaded, dict)
        if not applied:
            state['last_error'] = 'authority snapshot application failed'
            return False
        state['last_applied_snapshot'] = copy.deepcopy(snapshot)
        state['last_apply_reason'] = str(reason)
        # The finite load boundary owns the barrier only until immutable RNA has
        # been replayed.  Release it before the synchronous strict flush.
        _set_write_barrier(False)
        mark_deferred_settings_dirty()
        unchanged = False
        state['last_restore_skip_debug'] = 'start'
        try:
            cur_payload = _core._nptl_current_payload(getattr(bpy, 'context', None))
            if (
                getattr(authority, 'valid', False)
                and isinstance(cur_payload, dict) and cur_payload
                and not state.get('pending_user_payload')
                and not journal_recovery
                and _core._authority_content_digest(cur_payload)
                == _core._authority_content_digest(authority.payload)
            ):
                unchanged = True
            state['last_restore_skip_debug'] = (
                f"valid={getattr(authority, 'valid', False)} cur={isinstance(cur_payload, dict) and bool(cur_payload)} "
                f"pend={bool(state.get('pending_user_payload'))} jr={journal_recovery}"
            )
        except Exception as _exc:
            state['last_restore_skip_debug'] = f'exc {type(_exc).__name__}: {_exc}'
            unchanged = False
        state['last_restore_flush_skipped'] = bool(unchanged)
        if unchanged:
            _clear_deferred_settings_dirty()
            flushed = True
        else:
            flushed = bool(save_all_settings(
                getattr(bpy, 'context', None),
                force_central=True,
            ))
        if not flushed:
            state['last_error'] = state.get('last_error') or 'normalized strict flush failed'
            return False
        state['last_error'] = ''
        return True
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        return False
    finally:
        complete = bool(applied and flushed)
        _finish_pending_restore(success=complete, keep_snapshot=not complete)
        if complete and state.get('pending_apply'):
            # Overlapping file loads are serialized.  Each remaining immutable
            # snapshot gets one later safe event and no watchdog.
            _install_pending_event_handler()


@persistent
def _pending_restore_event(_scene=None, _depsgraph=None):
    """Consume one finite safe event for pending commits and/or restore."""
    global _FILE_POST_RESTORE_ATTEMPTS
    state = _lifecycle_state()
    try:
        has_restore = bool(state.get('pending_apply'))
        has_commit = bool(
            state.get('pending_commit')
            or isinstance(state.get('pending_user_payload'), dict)
        )
        if not (has_restore or has_commit):
            _remove_pending_event_handler()
            return None
        if not _state_generation_current(state):
            state['last_error'] = 'generation mismatch during pending persistence event'
            _remove_pending_event_handler()
            return None

        attempts = int(state.get('attempts') or 0) + 1
        state['attempts'] = attempts
        _FILE_POST_RESTORE_ATTEMPTS = attempts
        ready = bool(_runtime_owners_ready())
        transition_ready = True
        if has_restore and state.get('load_post_seen') is not True:
            before = state.get('load_pre_owner_signature')
            after = _runtime_owner_signature(getattr(bpy, 'context', None))
            transition_ready = not (
                isinstance(before, tuple) and tuple(before) == tuple(after)
            )

        if not ready or not transition_ready:
            state['last_error'] = (
                'runtime owners unavailable during bounded pending persistence event'
                if not ready else
                'pending restore event occurred before a safe load owner transition'
            )
            if attempts >= _FILE_POST_RESTORE_MAX_ATTEMPTS:
                state['startup_restore_status'] = (
                    'PENDING_BOUNDARY'
                    if state.get('startup_restore_status') == 'PENDING_EVENT'
                    else state.get('startup_restore_status')
                )
                _remove_pending_event_handler()
            return None

        # Remove the lease before work.  A failed attempt remains dirty for the
        # next explicit load/save/teardown boundary and cannot become a poll.
        _remove_pending_event_handler()
        commit_ok = True
        pending = state.get('pending_user_payload')
        if isinstance(pending, dict):
            commit_ok = bool(commit_validated_n_panel_payload_direct(
                getattr(bpy, 'context', None),
                pending,
                verified_user_change=(state.get('pending_user_payload_verified') is True),
                source='pending-safe-event',
                arm_retry=False,
            ))
        elif state.get('pending_commit') or deferred_settings_dirty():
            commit_ok = bool(save_all_settings(
                getattr(bpy, 'context', None),
                force_central=True,
            ))
        state['pending_commit'] = not commit_ok

        applied = True
        if has_restore and commit_ok:
            # Commit first.  _apply_pending_restore then re-resolves disk authority
            # and fences a now-stale load_pre snapshot instead of overwriting it.
            applied = bool(_apply_pending_restore('depsgraph_safe_event'))
        elif has_restore:
            # A failed user/import commit leaves the older snapshot queued.  It
            # must not be replayed over the newer live RNA merely because this
            # finite event reached its restore phase.
            applied = False
        if state.get('startup_restore_status') in {'PENDING_EVENT', 'PENDING_BOUNDARY'}:
            complete = bool(applied and commit_ok)
            state['startup_restore_done'] = complete
            state['startup_restore_status'] = 'APPLIED' if complete else 'APPLY_FAILED'
        return None
    finally:
        _set_write_barrier(False)



def _deferred_file_restore_tick():
    """Compatibility callback retained only for stale-timer cleanup.

    Version 1.1.135 never registers this function.  Startup and file-load
    restoration use load_post or one generation-bound depsgraph event instead.
    """
    return None


def _timer_native_remover(handle):
    _suite_storage.unregister_timer_slot('persistence._deferred_file_restore_tick', handle)


def _schedule_deferred_file_restore(delay: float = _FILE_POST_RESTORE_DELAY) -> bool:
    """Arm one event-driven restore attempt without timers or polling."""
    del delay
    global _FILE_POST_RESTORE_TIMER_REGISTERED, _FILE_POST_RESTORE_ATTEMPTS
    state = _lifecycle_state()
    _FILE_POST_RESTORE_TIMER_REGISTERED = False
    _FILE_POST_RESTORE_ATTEMPTS = 0
    state['timer_registered'] = False
    state['attempts'] = 0
    state['pending_apply'] = bool(_authority_snapshot_queue(state))
    _set_write_barrier(False)
    if not state['pending_apply']:
        return True
    try:
        return bool(_install_pending_event_handler())
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        return False


@persistent
def sws_persistent_load_pre(_dummy=None):
    """Capture one generation-bound authority before Blender replaces Main.

    Every path releases the write barrier in ``finally``.  Existing immutable
    snapshots remain queued and receive at most one later safe event; no timer,
    watchdog, or periodic poll is introduced.
    """
    global _FILE_LOAD_RNA_STATE, _FILE_POST_RESTORE_ATTEMPTS
    state = _lifecycle_state()
    event_owns_barrier = False
    try:
        _cancel_user_change_save()
        if not _state_generation_current(state):
            state['last_error'] = 'generation mismatch during load_pre'
            return None
        try:
            _suite_storage.invalidate_central_cache()
        except Exception as exc:
            state['last_error'] = f'{type(exc).__name__}: {exc}'
        preflush_ok = True
        if deferred_settings_dirty():
            try:
                preflush_ok = bool(save_all_settings(
                    getattr(bpy, 'context', None),
                    force_central=True,
                ))
            except Exception as exc:
                preflush_ok = False
                state['last_error'] = f'{type(exc).__name__}: {exc}'
        try:
            snapshot = _capture_authority_snapshot(getattr(bpy, 'context', None))
        except Exception as exc:
            snapshot = None
            state['last_error'] = f'{type(exc).__name__}: {exc}'
        load_token = _uuid.uuid4().hex
        state.update({
            'generation': _suite_generation_token(),
            'load_token': load_token,
            'attempts': 0,
            'load_post_seen': False,
            'load_pre_owner_signature': _runtime_owner_signature(getattr(bpy, 'context', None)),
            'pre_load_flush_success': preflush_ok,
            'last_error': state.get('last_error', '') if not preflush_ok else state.get('last_error', ''),
        })
        if not preflush_ok and not state.get('last_error'):
            state['last_error'] = 'pre-load strict flush failed'
        try:
            enqueued = bool(
                isinstance(snapshot, dict)
                and _enqueue_authority_snapshot(state, snapshot, load_token)
            )
        except Exception as exc:
            enqueued = False
            state['last_error'] = f'{type(exc).__name__}: {exc}'
        queue = _authority_snapshot_queue(state)
        _FILE_LOAD_RNA_STATE = copy.deepcopy(queue[0]) if queue else None
        _FILE_POST_RESTORE_ATTEMPTS = 0
        if not enqueued:
            # Never discard a prior unapplied snapshot.  One safe event may
            # retry it, but no timer/watchdog remains resident.
            state['pending_apply'] = bool(queue)
            if state['pending_apply']:
                try:
                    _install_pending_event_handler()
                except Exception as exc:
                    state['last_error'] = f'{type(exc).__name__}: {exc}'
            return None
        # load_post is the authoritative file-boundary event.  Do not keep a
        # write barrier or start a timer between load_pre and load_post; the
        # immutable snapshot remains queued and save_pre/unregister can also
        # flush it if Blender aborts before load_post.
        _set_write_barrier(False)
        event_owns_barrier = False
        state['pending_apply'] = bool(_authority_snapshot_queue(state))
        return None
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        state['pending_apply'] = bool(_authority_snapshot_queue(state))
        if state['pending_apply']:
            try:
                _install_pending_event_handler()
            except Exception as event_exc:
                state['last_error'] = f'{type(event_exc).__name__}: {event_exc}'
        return None
    finally:
        # No asynchronous owner may retain a write blockade across load
        # failure, missing load_post, teardown, or an unavailable Window/Scene.
        if not event_owns_barrier:
            _set_write_barrier(False)


@persistent
def sws_persistent_load_post(_dummy=None):
    state = _lifecycle_state()
    state['load_post_seen'] = True
    if not _state_generation_current(state):
        _set_write_barrier(False)
        return None
    if not _authority_snapshot_queue(state):
        _set_write_barrier(False)
        return None
    try:
        if _runtime_owners_ready():
            if not _apply_pending_restore('load_post'):
                # Preserve the generation-bound authority and grant exactly
                # one later safe depsgraph event.  _pending_restore_event
                # removes itself before work and does not self-rearm.
                state['pending_apply'] = bool(_authority_snapshot_queue(state))
                if state['pending_apply']:
                    _install_pending_event_handler()
        elif not _schedule_deferred_file_restore(_FILE_POST_RESTORE_DELAY):
            state['pending_apply'] = True
    except Exception as exc:
        state['last_error'] = f'{type(exc).__name__}: {exc}'
        state['pending_apply'] = True
        _set_write_barrier(False)
        _install_pending_event_handler()
    return None


@persistent
def sws_persistent_save_pre(_dummy=None) -> bool:
    _cancel_user_change_save()
    state = _lifecycle_state()
    if not _state_generation_current(state):
        _set_write_barrier(False)
        return False
    if state.get('pending_apply'):
        if not _runtime_owners_ready():
            state['last_error'] = 'pending authority snapshot cannot be flushed before save_pre'
            _set_write_barrier(False)
            return False
        if not _apply_pending_restore('save_pre'):
            return False
    return bool(save_all_settings(
        getattr(bpy, 'context', None),
        force_central=deferred_settings_dirty(),
    ))


@persistent
def sws_persistent_save_post(_dummy=None):
    # Compatibility symbol only.  It is never registered and never touches a
    # saved .blend file or schedules work.
    return None


def _flush_pending_before_teardown() -> bool:
    _cancel_user_change_save()
    state = _lifecycle_state()
    success = True
    try:
        _set_write_barrier(False)

        # A rapid close can occur before the 120 ms profile-journal timer fires.
        # Drain that finite batch first so first-run edits are still verified as
        # user changes and may initialize strict authority.
        try:
            from .runtime import core as _core
            if not _core.flush_pending_live_state(getattr(bpy, 'context', None)):
                success = False
        except Exception:
            success = False

        # User/import state is newer than any load_pre snapshot.  Commit it first
        # so the later snapshot pass can reject stale state by monotonic revision.
        pending = state.get('pending_user_payload')
        if isinstance(pending, dict):
            if not commit_validated_n_panel_payload_direct(
                getattr(bpy, 'context', None),
                pending,
                verified_user_change=(state.get('pending_user_payload_verified') is True),
                source='teardown-pending-user-payload',
                arm_retry=False,
            ):
                success = False
        # deferred_settings_dirty() also reports the module-level bit, which is
        # not generation-bound and outlives an importlib reload.  Teardown may
        # force a strict save only for a dirty bit raised by this generation;
        # a retired bit names no live unit of work, so the forced save has no
        # authority and no verified change to commit, fails, and blocks the
        # unregister it was supposed to complete.
        if state.get('dirty') and not isinstance(state.get('pending_user_payload'), dict):
            verified_live_change = False
            sidecar_path = None
            try:
                from .runtime import core as _core
                verified_live_change = bool(_core.has_current_session_live_state_changes())
                sidecar_path = _core._refresh_config_file_path()
            except Exception:
                verified_live_change = False
            if not verified_live_change and not _n_panel_authority_available(sidecar_path):
                # No primary/backup/central and no journaled user edit: the only
                # content this generation could commit is registration
                # defaults, which save_all_settings refuses by design.  That
                # refusal is the correct outcome of the dirty bit (raised by a
                # non-edit caller of mark_deferred_settings_dirty), not a failed
                # flush; it must not keep the generation and its RNA alive and
                # block unregister().  The dirty bit is left untouched.
                state['last_teardown_save_skipped'] = 'no-valid-authority-no-verified-change'
            elif not save_all_settings(
                getattr(bpy, 'context', None),
                force_central=True,
                verified_user_change=verified_live_change,
            ):
                success = False

        # Snapshot handling is deliberately last.  Each application begins with
        # a disk revision fence; a snapshot older than the just-committed user
        # payload is consumed without touching RNA.
        if state.get('pending_apply') and success:
            for _index in range(_MAX_AUTHORITY_SNAPSHOTS):
                if not state.get('pending_apply'):
                    break
                if not _apply_pending_restore('teardown'):
                    success = False
                    break
            if state.get('pending_apply'):
                success = False
        elif state.get('pending_apply'):
            # Keep the immutable snapshot queued when the newer user/import
            # transaction could not be committed.  Replaying it now would erase
            # the live values that still need a later explicit flush.
            success = False

        state['last_teardown_flush_success'] = bool(success)
        return bool(success)
    finally:
        # Exit/load/unregister races cannot retain a write blockade.
        _set_write_barrier(False)


@persistent
def sws_persistent_exit_pre(_dummy=None):
    _flush_live_journal()
    try:
        state = _lifecycle_state()
        if not _state_generation_current(state):
            _set_write_barrier(False)
            return False
        return _flush_pending_before_teardown()
    finally:
        _flush_settings_file()


def _purge_stale_persistence_timers(_names=None) -> None:
    """Remove only fixed package timer slots; never scan sys.modules.

    ``_names=None`` retires every fixed slot, drops the restore leases and
    schedules one settings flush.  With ``_names`` only the named slots are
    removed; leases and the settings flush are left untouched.
    """
    slots = (
        ('_continuous_autosave_timer', 'persistence._continuous_autosave_timer', globals().get('_continuous_autosave_timer')),
        ('_deferred_load_restore', 'persistence._deferred_load_restore', globals().get('_deferred_load_restore')),
        ('_registration_restore_once', 'persistence._registration_restore_once', globals().get('_registration_restore_once')),
        ('_deferred_file_restore_tick', 'persistence._deferred_file_restore_tick', globals().get('_deferred_file_restore_tick')),
        ('_user_change_save_once', _USER_CHANGE_SAVE_TIMER_SLOT, globals().get('_user_change_save_once')),
        ('_suite_vfs_flush', _suite_vfs.FLUSH_SLOT, getattr(_suite_vfs, '_flush_timer', None)),
    )
    if _names is not None:
        wanted = {str(n) for n in ((_names,) if isinstance(_names, str) else _names)}
        for name, slot, callback in slots:
            if name in wanted:
                _suite_storage.unregister_timer_slot(slot, callback)
        return None
    for _name, slot, callback in slots:
        _suite_storage.unregister_timer_slot(slot, callback)
    _runtime_ledger.remove_feature_leases('persistence-restore-timer', any_generation=True)
    # A previous module's one-shot settings flush is retired above; members
    # staged by this generation still get exactly one flush.
    _suite_vfs.schedule_flush()


def _persistence_handler_native_remover(handle, handler_list):
    try:
        while handle in handler_list:
            handler_list.remove(handle)
    except Exception:
        pass


def _install_persistence_handler(feature: str, handler_list, callback) -> bool:
    generation = _runtime_ledger.current_generation()
    if not generation or not _runtime_ledger.generation_matches(generation):
        return False
    _runtime_ledger.remove_feature_leases(feature, any_generation=False)
    _remove_handler(handler_list, callback)
    handler_list.append(callback)
    if callback not in handler_list:
        return False
    if not _runtime_ledger.register_lease(
        feature=feature,
        space='APP',
        region=str(feature).upper(),
        handle=callback,
        native_remover=_persistence_handler_native_remover,
        remove_args=(handler_list,),
        is_registered=lambda handle, handlers=handler_list: handle in handlers,
    ):
        _persistence_handler_native_remover(callback, handler_list)
        return False
    return True


def _install_persistence_handlers() -> bool:
    handlers = getattr(bpy.app, 'handlers', None)
    if handlers is None:
        return False
    entries = (
        ('persistence-load-pre', getattr(handlers, 'load_pre', None), sws_persistent_load_pre),
        ('persistence-load-post', getattr(handlers, 'load_post', None), sws_persistent_load_post),
        ('persistence-save-pre', getattr(handlers, 'save_pre', None), sws_persistent_save_pre),
        ('persistence-exit-pre', getattr(handlers, 'exit_pre', None), sws_persistent_exit_pre),
    )
    installed = []
    try:
        for feature, handler_list, callback in entries:
            if handler_list is None or not _install_persistence_handler(feature, handler_list, callback):
                raise RuntimeError(f'Unable to install {feature}')
            installed.append(feature)
        # save_post is intentionally absent: Blender is the sole .blend writer.
        _remove_handler(getattr(handlers, 'save_post', []), sws_persistent_save_post)
        return True
    except Exception:
        for feature in reversed(installed):
            _runtime_ledger.remove_feature_leases(feature, any_generation=False)
        return False


def sync_continuous_autosave_policy() -> bool:
    """Zero idle timers/watchdogs; retain finite leased boundary handlers."""
    _stop_continuous_autosave()
    return bool(_install_persistence_handlers())


def register() -> bool:
    global _REGISTERED, _TEARDOWN_RUNTIME_WRITE_BLOCKED
    state = _lifecycle_state()
    generation = _suite_generation_token()
    if not generation or generation == 'UNREGISTERED':
        return False
    if _REGISTERED and state.get('generation') == generation:
        return True
    _purge_stale_persistence_timers()
    _stop_continuous_autosave()
    state['generation'] = generation
    state['write_blocked'] = False
    state['timer_registered'] = False
    state['attempts'] = 0
    _TEARDOWN_RUNTIME_WRITE_BLOCKED = False
    if not _install_persistence_handlers():
        _set_write_barrier(False)
        return False
    _REGISTERED = True
    _mark_active_scene(getattr(bpy, 'context', None))
    if state.get('pending_apply') and not _install_pending_event_handler():
        _REGISTERED = False
        _runtime_ledger.remove_feature_leases('persistence-load-pre', any_generation=False)
        _runtime_ledger.remove_feature_leases('persistence-load-post', any_generation=False)
        _runtime_ledger.remove_feature_leases('persistence-save-pre', any_generation=False)
        _runtime_ledger.remove_feature_leases('persistence-exit-pre', any_generation=False)
        _set_write_barrier(False)
        return False
    if (
        (
            isinstance(state.get('pending_user_payload'), dict)
            or state.get('user_change_save_scheduled')
        )
        and _live_n_panel_save_policy(getattr(bpy, 'context', None), True)
    ):
        # Module reload can interrupt the quiet-period callback. The fixed timer
        # slot above retired the old callback identity; resume exactly one save
        # for a still-live concrete user-change unit without adding an idle
        # poller.  A bare dirty bit with no payload or armed one-shot save is
        # not enough to recreate a deferred commit during a new generation.
        _schedule_user_change_save(
            getattr(bpy, 'context', None),
            source=str(state.get('pending_user_change_source') or 'hot-reload-resume'),
        )
    return True



def release_deferred_settings_dirty_scope() -> bool:
    """Settle the dirty pair on the generation-release path.

    ``_DEFERRED_SETTINGS_DIRTY`` is a fast mirror of this generation's
    ``state['dirty']``, but unlike the state record it is not generation-bound,
    and the only site that ever rescopes it is the rollover inside
    ``_lifecycle_state()``.  That rollover runs when the NEXT generation's
    record is built -- so after the final unregister it never runs at all, and
    the cache keeps whatever the released generation left in it.  Because
    ``deferred_settings_dirty()`` reads the cache first and short-circuits, it
    never reaches ``_lifecycle_state()``, so a caller that only consults the
    predicate observes a retired dirty bit for the rest of the process.

    Module teardowns that run after this generation's strict flush (preferences,
    ui_runtime, workspace_manager, the runtime package) may raise exactly such a
    mark, which is why settling has to happen after them, on the release path
    itself, rather than inside ``persistence.unregister()``.

    Called once the generation is released, this performs that one rollover
    eagerly instead of waiting for a read that will never come.  It adds no new
    policy: the rescope is the rollover's own contract, so a concrete
    ``pending_user_payload`` or an armed one-shot save carries across untouched
    and a bare retired bit does not.  Real unsaved user work is never cleared
    here.

    Returns the settled dirty value.
    """
    global _DEFERRED_SETTINGS_DIRTY
    # _lifecycle_state() owns the rollover, and the rollover is the single site
    # that defines what survives a generation boundary.  Take its verdict rather
    # than restating the predicate here, then mirror it into the cache so the
    # pair is settled even if the record was already rebuilt by an earlier
    # reader on this same release path.  Writing the pair together is the
    # module's existing invariant; this is the release path honouring it.
    settled = bool(_lifecycle_state().get('dirty'))
    _DEFERRED_SETTINGS_DIRTY = settled
    return settled


def release_quiescent_lifecycle_state() -> str:
    """Release only this module's exact fully settled UNREGISTERED state."""
    global _PERSISTENCE_SESSION_STATE
    try:
        namespace = bpy.app.driver_namespace
        state = namespace.get(_PERSISTENCE_STATE_NAMESPACE_KEY_V2)
    except Exception:
        return 'NAMESPACE_UNAVAILABLE'
    if not isinstance(state, dict) or state is not _PERSISTENCE_SESSION_STATE:
        return 'RETAINED_FOREIGN_OR_UNOWNED'
    quiescent = bool(
        str(state.get('generation') or '') == 'UNREGISTERED'
        and not state.get('authority_snapshot')
        and not state.get('authority_snapshots')
        and not state.get('pending_apply')
        and not isinstance(state.get('pending_user_payload'), dict)
        and not state.get('pending_commit')
        and not state.get('dirty')
        and not state.get('timer_registered')
        and not state.get('user_change_save_scheduled')
        and not state.get('write_blocked')
    )
    if not quiescent:
        return 'RETAINED_NONQUIESCENT'
    if namespace.get(_PERSISTENCE_STATE_NAMESPACE_KEY_V2) is not state:
        return 'RETAINED_IDENTITY_CHANGED'
    namespace.pop(_PERSISTENCE_STATE_NAMESPACE_KEY_V2, None)
    _PERSISTENCE_SESSION_STATE = None
    return 'RELEASED'


def unregister() -> bool:
    global _REGISTERED, _RESTORE_PENDING, _REGISTRATION_RESTORE_STATE
    global _REGISTRATION_RESTORE_ATTEMPTS, _FILE_LOAD_RNA_STATE
    success = _flush_pending_before_teardown()
    if not success:
        # A failed primary+central strict flush leaves every handler, lease,
        # snapshot and displayed RNA intact.  The caller can retry or require a
        # process restart; partial teardown is never reported as success.
        return False
    _suite_storage.unregister_timer_slot(
        'persistence._deferred_file_restore_tick',
        _deferred_file_restore_tick,
    )
    _remove_pending_event_handler()
    _stop_continuous_autosave()
    _unsubscribe_scene_change()
    for feature in (
        'persistence-load-pre', 'persistence-load-post',
        'persistence-save-pre', 'persistence-exit-pre',
    ):
        _runtime_ledger.remove_feature_leases(feature, any_generation=False)
    handlers = getattr(bpy.app, 'handlers', None)
    if handlers is not None:
        _remove_handler(getattr(handlers, 'load_pre', []), sws_persistent_load_pre)
        _remove_handler(getattr(handlers, 'load_post', []), sws_persistent_load_post)
        _remove_handler(getattr(handlers, 'save_pre', []), sws_persistent_save_pre)
        _remove_handler(getattr(handlers, 'save_post', []), sws_persistent_save_post)
        _remove_handler(getattr(handlers, 'exit_pre', []), sws_persistent_exit_pre)
    _RESTORE_PENDING = False
    _REGISTRATION_RESTORE_STATE = None
    _REGISTRATION_RESTORE_ATTEMPTS = 0
    _FILE_LOAD_RNA_STATE = None
    _set_write_barrier(False)
    _REGISTERED = False
    return bool(success)


# ---- 読み込み・保存の handler は製品ごとに各 list 1 つ（A1-07）。ほかのモジュールはここへ hook を足す。
_FILE_HOOKS = {'load_pre': {}, 'load_post': {}, 'save_pre': {}}


def add_file_hook(kind, key, fn):
    """kind の handler の中で呼ぶ hook を足す（同じ key は置き換え）。"""
    _FILE_HOOKS[kind][key] = fn
    return True


def remove_file_hook(kind, key):
    return _FILE_HOOKS[kind].pop(key, None) is not None


def _run_file_hooks(kind, dummy=None):
    for fn in list(_FILE_HOOKS[kind].values()):
        try:
            fn(dummy)
        except Exception as exc:
            _file_hook_warn_once(f'{kind}:{getattr(fn, "__name__", "hook")}', exc)


_FILE_HOOK_WARNED = set()


def _file_hook_warn_once(key, exc):
    if key not in _FILE_HOOK_WARNED:
        _FILE_HOOK_WARNED.add(key)
        print(f'[Smart Workspace] file hook {key}: {exc}')


_sws_persistent_load_pre_impl = sws_persistent_load_pre
_sws_persistent_load_post_impl = sws_persistent_load_post
_sws_persistent_save_pre_impl = sws_persistent_save_pre


def _flush_live_journal():
    try:
        from .runtime import core as _core
        _core.flush_live_state_pending()
    except Exception:
        pass


def _flush_settings_file():
    """Publish staged settings members in one write at a file/exit boundary."""
    try:
        _suite_storage.flush_settings()
    except Exception:
        pass


@persistent
def sws_persistent_load_pre(_dummy=None):
    _flush_live_journal()
    try:
        return _sws_persistent_load_pre_impl(_dummy)
    finally:
        _run_file_hooks('load_pre', _dummy)
        _flush_settings_file()


@persistent
def sws_persistent_load_post(_dummy=None):
    try:
        return _sws_persistent_load_post_impl(_dummy)
    finally:
        _run_file_hooks('load_post', _dummy)


@persistent
def sws_persistent_save_pre(_dummy=None):
    _flush_live_journal()
    try:
        _run_file_hooks('save_pre', _dummy)
        if not _policy_enabled(False):
            return True
        return _sws_persistent_save_pre_impl(_dummy)
    finally:
        _flush_settings_file()
