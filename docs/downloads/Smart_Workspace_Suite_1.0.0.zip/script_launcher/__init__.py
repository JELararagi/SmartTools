# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Script Launcher",
    "author": "JELararagi",
    "version": (1, 2, 0),
    "blender": (5, 0, 0),
    "location": "3D Viewport > Sidebar > Script Launcher",
    "description": "Manage and run Python scripts from multiple root folders",
    "category": "Other",
}

if "bpy" in locals():
    import importlib
    if "core" in locals():
        importlib.reload(core)
    if "operators" in locals():
        importlib.reload(operators)
    if "integrated_bridge" in locals():
        importlib.reload(integrated_bridge)

import bpy
import bpy.props
from ..translation import localized_layout
from .. import ui_icons
from .. import runtime_ledger as _runtime_ledger
from bpy.app.handlers import persistent
from . import core
from . import operators
from . import integrated_bridge


class SCRIPTLAUNCHER_PREFERENCES(bpy.types.AddonPreferences):
    bl_idname = __package__

    sl_panel_category: bpy.props.StringProperty(
        name="Panel Category",
        default="Script Launcher",
        description="Category tab name for Script Launcher's panel",
        update=core.sl_update_category,
    )

    sl_folders: bpy.props.CollectionProperty(
        type=core.SCRIPTLAUNCHER_FOLDER_ROOT,
        name="Script Roots",
    )

    active_root_index: bpy.props.IntProperty(
        name="Active Root Index",
        default=0,
    )

    def draw(self, context):
        layout = localized_layout(self.layout, context)

        layout.prop(self, "sl_panel_category")

        layout.separator()
        ui_icons.label(layout, text="Script Roots:", name="folder", fallback="FILE_FOLDER")

        row = layout.row()
        row.template_list(
            "SCRIPTLAUNCHER_UL_ROOTS", "",
            self, "sl_folders",
            self, "active_root_index",
            rows=4,
        )
        col = row.column(align=True)
        ui_icons.set_large_icon_scale(col, 1.35)
        ui_icons.operator(col, "sl.op_add_root", text="", name='plus', fallback='ADD', emboss=False)
        ui_icons.operator(col, "sl.op_remove_root", text="", name='minus', fallback='REMOVE', emboss=False)
        col.separator()
        ui_icons.operator(col, "sl.op_move_root", text="", name='up', fallback='TRIA_UP', emboss=False).direction = 'UP'
        ui_icons.operator(col, "sl.op_move_root", text="", name='down', fallback='TRIA_DOWN', emboss=False).direction = 'DOWN'

        if self.sl_folders and 0 <= self.active_root_index < len(self.sl_folders):
            folder = self.sl_folders[self.active_root_index]
            box = layout.box()
            box.prop(folder, "path", text="Path")
            box.prop(folder, "label", text="Label")


integrated_proxy_panels = [core.SCRIPTLAUNCHER_PT_PANEL]

classes = [
    core.SCRIPTLAUNCHER_FOLDER_ROOT,
    core.SCRIPTLAUNCHER_TREE_NODE,
    SCRIPTLAUNCHER_PREFERENCES,
    core.SCRIPTLAUNCHER_PG,
    core.SCRIPTLAUNCHER_UL_ROOTS,
    core.SCRIPTLAUNCHER_UL_LIST,
    core.SCRIPTLAUNCHER_PT_PANEL,
    operators.SCRIPTLAUNCHER_OT_REFRESHLIST,
    operators.SCRIPTLAUNCHER_OT_RUNSCRIPT,
    operators.SCRIPTLAUNCHER_OT_OPENFILE,
    operators.SCRIPTLAUNCHER_OT_OPENEXPLORER,
    operators.SCRIPTLAUNCHER_OT_OPENPREFERENCES,
    operators.SCRIPTLAUNCHER_OT_TOGGLEFOLDER,
    operators.SCRIPTLAUNCHER_OT_ADD_ROOT,
    operators.SCRIPTLAUNCHER_OT_REMOVE_ROOT,
    operators.SCRIPTLAUNCHER_OT_MOVE_ROOT,
    operators.SCRIPTLAUNCHER_OT_CLEAR_SEARCH,
]


if integrated_bridge.is_integrated_mode():
    classes = [
        cls for cls in classes
        if cls not in {core.SCRIPTLAUNCHER_PT_PANEL, SCRIPTLAUNCHER_PREFERENCES}
    ]


def _suite_always_on_enabled(action: str, default: bool = False) -> bool:
    if not integrated_bridge.is_integrated_mode():
        return bool(default)
    try:
        from .. import ui_runtime as _suite_ui_runtime
        getter = getattr(_suite_ui_runtime, '_remembered_always_state', None)
        if callable(getter):
            return bool(getter(action, default))
    except Exception:
        pass
    return bool(default)


@persistent
def load_handler(dummy):
    try:
        integrated_bridge.load_prefs(getattr(bpy, 'context', None))
        core.invalidate_fs_cache()
        core.build_visible_tree(getattr(bpy, 'context', None))
    except Exception as e:
        print(f"Script Launcher: failed to restore settings on load: {e}")


def register():
    for cls in classes:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCRIPT_LAUNCHER_CLASS',
        )
        if not success:
            raise RuntimeError('RESTART_REQUIRED: Script Launcher class ownership mismatch')

    if not integrated_bridge.register_storage(core.SCRIPTLAUNCHER_FOLDER_ROOT):
        raise RuntimeError('RESTART_REQUIRED: Script Launcher storage ownership mismatch')
    prefs = integrated_bridge.get_prefs(bpy.context)

    if prefs is not None:
        core.sl_update_category(prefs, bpy.context)

        # 初回インストール時にデフォルトの scripts フォルダを自動登録
        if not prefs.sl_folders:
            import os
            item = prefs.sl_folders.add()
            item.path = os.path.join(os.path.dirname(__file__), "scripts")
            item.label = "Default Scripts"
            integrated_bridge.save_prefs(bpy.context)

    owner = bpy.types.Scene
    if _runtime_ledger.live_property_signature(owner, 'sl_group')[1]:
        if not _runtime_ledger.property_is_current(owner, 'sl_group', core.SCRIPTLAUNCHER_PG):
            _runtime_ledger.mark_restart_required('SCRIPT_LAUNCHER_SCENE_POINTER_CONFLICT')
            raise RuntimeError('RESTART_REQUIRED: Script Launcher Scene pointer ownership mismatch')
    else:
        owner.sl_group = bpy.props.PointerProperty(type=core.SCRIPTLAUNCHER_PG)
        if not _runtime_ledger.record_property(
            owner,
            'sl_group',
            core.SCRIPTLAUNCHER_PG,
            remover=lambda _handle=None: delattr(owner, 'sl_group'),
            newly_registered=True,
        ):
            try:
                delattr(owner, 'sl_group')
            except Exception:
                pass
            raise RuntimeError('RESTART_REQUIRED: Script Launcher Scene pointer ledger failure')
    try:
        integrated_bridge.load_prefs(bpy.context)
        core.invalidate_fs_cache()
        core.build_visible_tree(bpy.context)
    except Exception:
        pass
    # Scene.sl_group is registered lazily.  Its class defaults must never win
    # over the suite-level portable snapshot merely because the user opened
    # Script Launcher after startup or after switching Scenes.
    try:
        from .. import persistence as _suite_persistence
        _suite_persistence.restore_rna_state(getattr(bpy, 'context', None))
    except Exception:
        pass
    # Integrated Smart Workspace restores Script Launcher through the suite-level
    # persistence load path, so this tool no longer owns a separate load_post
    # handler.
    while load_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_handler)


def unregister():
    if load_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_handler)

    # Serialize both the WindowManager preferences and Scene.sl_group while
    # their RNA owners still exist.  Deleting sl_group first silently reduced
    # the lifecycle sidecar to an empty scene_state.
    if integrated_bridge.unregister_storage(bpy.context) is not True:
        return False

    owner = bpy.types.Scene
    if _runtime_ledger.live_property_signature(owner, 'sl_group')[1]:
        if not _runtime_ledger.property_is_current(owner, 'sl_group', core.SCRIPTLAUNCHER_PG):
            return False
        try:
            delattr(owner, 'sl_group')
        except Exception:
            return False

    for cls in reversed(classes):
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCRIPT_LAUNCHER_CLASS',
        ):
            return False
    return True


if __name__ == "__main__":
    register()
