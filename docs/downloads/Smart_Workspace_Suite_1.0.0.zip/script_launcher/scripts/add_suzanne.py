# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy

bpy.ops.mesh.primitive_monkey_add(size=2)
