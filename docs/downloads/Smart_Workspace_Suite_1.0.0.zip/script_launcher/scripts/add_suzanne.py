# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Example for Script Launcher: create Suzanne at the scene cursor."""
from bpy import ops

ops.mesh.primitive_monkey_add(size=2.0)
