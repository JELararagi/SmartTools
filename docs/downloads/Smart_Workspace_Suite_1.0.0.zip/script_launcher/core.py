# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
import bpy.props
from ..translation import localized_layout, ui_pair
from .. import ui_icons
from .. import runtime_ledger as _runtime_ledger
import os

from . import integrated_bridge


# ---------------------------------------------------------------------------
# ファイルシステムキャッシュ
# ---------------------------------------------------------------------------

_fs_cache: dict = {}


def _get_entries(folder_path):
    """キャッシュからサブフォルダとPYファイル一覧を返す。"""
    if folder_path not in _fs_cache:
        try:
            entries = os.listdir(folder_path)
        except (PermissionError, FileNotFoundError):
            entries = []
        folders = sorted([
            e for e in entries
            if not e.startswith('.') and os.path.isdir(os.path.join(folder_path, e))
        ])
        files = sorted([
            e for e in entries
            if not e.startswith('.') and e.endswith('.py')
            and os.path.isfile(os.path.join(folder_path, e))
        ])
        _fs_cache[folder_path] = (folders, files)
    return _fs_cache[folder_path]


def invalidate_fs_cache():
    """キャッシュを破棄する（Refresh時やパス変更時に呼ぶ）。"""
    _fs_cache.clear()




def _draw_suite_help_button(layout, context=None, help_id='runtime') -> None:
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = help_id
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass

def _on_root_path_update(self, context):
    if getattr(integrated_bridge, '_STORAGE_LOADING', False):
        return
    try:
        invalidate_fs_cache()
        build_visible_tree(context)
        integrated_bridge.persist_user_change(context, 'script-launcher-ui-update')
    except (AttributeError, KeyError):
        pass


class SCRIPTLAUNCHER_FOLDER_ROOT(bpy.types.PropertyGroup):
    path: bpy.props.StringProperty(
        name="Path",
        description="Root folder path for scripts",
        subtype='DIR_PATH',
        default="",
        update=_on_root_path_update,
    )
    label: bpy.props.StringProperty(
        name="Label",
        description="Display name (leave empty to use folder name)",
        default="",
        update=_on_root_path_update,
    )


# ---------------------------------------------------------------------------
# PropertyGroup: ツリーノード（Scene 用フラットリスト）
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_TREE_NODE(bpy.types.PropertyGroup):
    # name は PropertyGroup 標準プロパティを使用
    full_path: bpy.props.StringProperty()
    is_folder: bpy.props.BoolProperty(default=False)
    is_expanded: bpy.props.BoolProperty(default=False)
    indent_level: bpy.props.IntProperty(default=0)
    is_root_header: bpy.props.BoolProperty(default=False)


# ---------------------------------------------------------------------------
# PropertyGroup: Scene に登録するグループ
# ---------------------------------------------------------------------------

def _on_search_update(self, context):
    if getattr(integrated_bridge, '_STORAGE_LOADING', False):
        return
    try:
        # ツリー再構築前に現在の選択パスを保存
        current_path = ""
        if self.sl_items and 0 <= self.active_index < len(self.sl_items):
            current_path = self.sl_items[self.active_index].full_path
        build_visible_tree(context)
        # 再構築後にfull_pathで選択を復元
        if current_path:
            for i, item in enumerate(self.sl_items):
                if item.full_path == current_path:
                    self.active_index = i
                    break
        if context.area:
            context.area.tag_redraw()
        integrated_bridge.persist_user_change(context, 'script-launcher-ui-update')
    except (AttributeError, KeyError):
        pass


def _on_active_index_update(self, context):
    if getattr(integrated_bridge, '_STORAGE_LOADING', False):
        return
    try:
        integrated_bridge.persist_user_change(context, 'script-launcher-ui-update')
    except Exception:
        pass


class SCRIPTLAUNCHER_PG(bpy.types.PropertyGroup):
    sl_items: bpy.props.CollectionProperty(type=SCRIPTLAUNCHER_TREE_NODE)
    active_index: bpy.props.IntProperty(update=_on_active_index_update)
    search_text: bpy.props.StringProperty(
        name="Search",
        default="",
        options={"TEXTEDIT_UPDATE"},
        update=_on_search_update,
    )


# ---------------------------------------------------------------------------
# ヘルパー: ツリー構築
# ---------------------------------------------------------------------------

def build_visible_tree(context):
    """全ルートフォルダからフラットなツリーリストを再構築する。"""
    addon_prefs = integrated_bridge.get_prefs(context)
    if addon_prefs is None:
        return
    scene = getattr(context, 'scene', None) if context is not None else None
    sl_group = getattr(scene, 'sl_group', None) if scene is not None else None
    if sl_group is None:
        return
    query = sl_group.search_text.strip().lower()

    # 現在の展開状態を保存（通常モード用）。起動直後や別シーン読み込み直後に
    # Scene側の一時リストが空の場合は、CONFIGに保存した展開状態を使用する。
    expanded_paths = {
        item.full_path
        for item in sl_group.sl_items
        if item.is_expanded
    }
    saved_expanded_paths = set()
    try:
        saved_expanded_paths = set(integrated_bridge.get_saved_expanded_paths(context))
    except Exception:
        saved_expanded_paths = set()
    if not expanded_paths and saved_expanded_paths:
        expanded_paths = set(saved_expanded_paths)
    known_paths = {item.full_path for item in sl_group.sl_items}

    sl_group.sl_items.clear()

    for root in addon_prefs.sl_folders:
        if not root.path or not os.path.isdir(root.path):
            continue

        display_name = root.label.strip() or os.path.basename(root.path.rstrip('/\\')) or root.path

        if query:
            # 検索モード: ルートを仮追加し、子孫にマッチがなければ取り消す
            idx = len(sl_group.sl_items)
            header = sl_group.sl_items.add()
            header.name = display_name
            header.full_path = root.path
            header.is_folder = True
            header.is_root_header = True
            header.indent_level = 0
            header.is_expanded = True
            children_added = _add_folder_contents(sl_group, root.path, expanded_paths, indent=1, query=query)
            if not children_added and query not in display_name.lower():
                sl_group.sl_items.remove(idx)
        else:
            # 通常モード
            is_new = root.path not in known_paths and not saved_expanded_paths
            header = sl_group.sl_items.add()
            header.name = display_name
            header.full_path = root.path
            header.is_folder = True
            header.is_root_header = True
            header.indent_level = 0
            header.is_expanded = is_new or root.path in expanded_paths
            if header.is_expanded:
                _add_folder_contents(sl_group, root.path, expanded_paths, indent=1)

    # active_index を範囲内に収める。保存済みの選択パスがある場合は、
    # ツリー順の変化に強い full_path 優先で復元する。
    total = len(sl_group.sl_items)
    if total > 0:
        restored = False
        try:
            saved_active_path = integrated_bridge.get_saved_active_path(context)
        except Exception:
            saved_active_path = ''
        if saved_active_path:
            for i, item in enumerate(sl_group.sl_items):
                if getattr(item, 'full_path', '') == saved_active_path:
                    sl_group.active_index = i
                    restored = True
                    break
        if not restored:
            sl_group.active_index = min(sl_group.active_index, total - 1)


def _add_folder_contents(sl_group, folder_path, expanded_paths, indent, query=""):
    """フォルダの中身をツリーリストに追加する（再帰）。

    queryが指定された場合は検索モードで動作し、仮追加→不要なら取り消す方式で
    二重スキャンなしにマッチ判定と追加を同時に行う。マッチがあればTrueを返す。
    """
    folders, files = _get_entries(folder_path)
    any_added = False

    for name in folders:
        full = os.path.join(folder_path, name)
        if query:
            if query in name.lower():
                # フォルダ名マッチ: 表示のみ、中身は展開しない
                item = sl_group.sl_items.add()
                item.name = name
                item.full_path = full
                item.is_folder = True
                item.is_root_header = False
                item.indent_level = indent
                item.is_expanded = False
                any_added = True
            else:
                # 仮追加して再帰。子孫にマッチがなければ取り消す
                idx = len(sl_group.sl_items)
                item = sl_group.sl_items.add()
                item.name = name
                item.full_path = full
                item.is_folder = True
                item.is_root_header = False
                item.indent_level = indent
                item.is_expanded = True
                if _add_folder_contents(sl_group, full, expanded_paths, indent + 1, query):
                    any_added = True
                else:
                    sl_group.sl_items.remove(idx)
        else:
            item = sl_group.sl_items.add()
            item.name = name
            item.full_path = full
            item.is_folder = True
            item.is_root_header = False
            item.indent_level = indent
            item.is_expanded = full in expanded_paths
            if item.is_expanded:
                _add_folder_contents(sl_group, full, expanded_paths, indent + 1)

    for name in files:
        full = os.path.join(folder_path, name)
        if query and query not in name.lower():
            continue
        item = sl_group.sl_items.add()
        item.name = name
        item.full_path = full
        item.is_folder = False
        item.is_root_header = False
        item.indent_level = indent
        any_added = True

    return any_added


# ---------------------------------------------------------------------------
# UIList: プリファレンス用ルートフォルダ一覧
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_UL_ROOTS(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        display = item.label.strip() or os.path.basename(item.path.rstrip('/\\')) or item.path
        ui_icons.label(layout, text=display, name='folder', fallback='FILE_FOLDER', translate=False)


# ---------------------------------------------------------------------------
# UIList: スクリプトツリー
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_UL_LIST(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # ルートヘッダー行
        if item.is_root_header:
            row = layout.row(align=True)
            expand_icon = 'TRIA_DOWN' if item.is_expanded else 'TRIA_RIGHT'
            ui_icons.set_large_icon_scale(row, 1.2)
            op = ui_icons.operator(row, "sl.op_togglefolder", text="", name='down' if item.is_expanded else 'right', fallback=expand_icon, emboss=False)
            op.item_index = index
            ui_icons.label(row, text=item.name, name='folder', fallback='FILE_FOLDER', translate=False)
            return

        # 通常行（フォルダ or ファイル）
        row = layout.row(align=True)

        # インデント（BLANK1 アイコンで空白を表現）
        for _ in range(item.indent_level):
            row.label(text="", icon='BLANK1')

        if item.is_folder:
            expand_icon = 'TRIA_DOWN' if item.is_expanded else 'TRIA_RIGHT'
            ui_icons.set_large_icon_scale(row, 1.2)
            op = ui_icons.operator(row, "sl.op_togglefolder", text="", name='down' if item.is_expanded else 'right', fallback=expand_icon, emboss=False)
            op.item_index = index
            ui_icons.label(row, text=item.name, name='folder', fallback='FILE_FOLDER', translate=False)
        else:
            row.label(text="", icon='BLANK1')  # トグルボタン分の空白
            ui_icons.label(row, text=item.name, name='script', fallback='WORDWRAP_ON', translate=False)


# ---------------------------------------------------------------------------
# パネルカテゴリ更新（__init__.py から参照）
# ---------------------------------------------------------------------------

def sl_update_category(self, context):
    if not getattr(self, 'sl_panel_category', '').strip():
        self.sl_panel_category = "Script Launcher"
    SCRIPTLAUNCHER_PT_PANEL.bl_category = self.sl_panel_category
    if integrated_bridge.is_integrated_mode():
        integrated_bridge.persist_user_change(context, 'script-launcher-ui-update')
        return
    if _runtime_ledger.class_recorded_current(SCRIPTLAUNCHER_PT_PANEL):
        if not _runtime_ledger.unregister_class_exact(
            SCRIPTLAUNCHER_PT_PANEL,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCRIPT_LAUNCHER_PANEL_CLASS',
        ):
            raise RuntimeError('RESTART_REQUIRED: Script Launcher panel ownership mismatch')
    success, _newly_registered = _runtime_ledger.register_class_exact(
        SCRIPTLAUNCHER_PT_PANEL,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='SCRIPT_LAUNCHER_PANEL_CLASS',
    )
    if not success:
        raise RuntimeError('RESTART_REQUIRED: Script Launcher panel ownership mismatch')


# ---------------------------------------------------------------------------
# パネル
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Smart Tools 統合設定描画
# ---------------------------------------------------------------------------

def draw_integrated_preferences(layout, context):
    prefs = integrated_bridge.get_prefs(context)
    if prefs is None:
        layout.label(text="Integrated preferences are unavailable", icon='ERROR')
        return

    box = localized_layout(layout, context).box()
    header = box.row(align=True)
    ui_icons.label(header, text=ui_pair('Script Roots', 'スクリプトルート', context), name='folder', fallback='PREFERENCES')
    _draw_suite_help_button(header, context, 'script_launcher')
    row = box.row()
    row.template_list(
        "SCRIPTLAUNCHER_UL_ROOTS", "",
        prefs, "sl_folders",
        prefs, "active_root_index",
        rows=4,
    )
    col = row.column(align=True)
    ui_icons.set_large_icon_scale(col, 1.35)
    ui_icons.operator(col, "sl.op_add_root", text="", name='plus', fallback='ADD', emboss=False)
    ui_icons.operator(col, "sl.op_remove_root", text="", name='minus', fallback='REMOVE', emboss=False)
    col.separator()
    ui_icons.operator(col, "sl.op_move_root", text="", name='up', fallback='TRIA_UP', emboss=False).direction = 'UP'
    ui_icons.operator(col, "sl.op_move_root", text="", name='down', fallback='TRIA_DOWN', emboss=False).direction = 'DOWN'

    if prefs.sl_folders and 0 <= prefs.active_root_index < len(prefs.sl_folders):
        folder = prefs.sl_folders[prefs.active_root_index]
        sub = box.box()
        sub.prop(folder, "path", text="Path")
        sub.prop(folder, "label", text="Label")

class SCRIPTLAUNCHER_PT_PANEL(bpy.types.Panel):
    bl_label = "Script Launcher"
    bl_idname = "SCRIPTLAUNCHER_PT_PANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'

    @classmethod
    def poll(cls, _context):
        return not integrated_bridge.is_integrated_mode()

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        header.label(text=ui_pair('Script Launcher', 'Script Launcher', context), icon='FILE_SCRIPT')
        _draw_suite_help_button(header, context, 'script_launcher')
        box = layout.box()

        scene = getattr(context, 'scene', None)
        sl_group = getattr(scene, 'sl_group', None) if scene is not None else None
        if sl_group is None:
            layout.label(text="Script Launcher is not initialized", icon='ERROR')
            return

        # 検索バー
        row = box.row(align=True)
        ui_icons.prop(row, sl_group, "search_text", text="", name='search', fallback='VIEWZOOM')
        if sl_group.search_text:
            ui_icons.set_large_icon_scale(row, 1.2)
            ui_icons.operator(row, "sl.op_clear_search", text="", name='close', fallback='X', emboss=False)

        # ツリーリスト + 縦ボタン列
        row = box.row()
        row.template_list(
            "SCRIPTLAUNCHER_UL_LIST", "",
            sl_group, "sl_items",
            sl_group, "active_index",
            rows=10,
        )
        col = row.column(align=True)
        ui_icons.set_large_icon_scale(col, 1.35)
        ui_icons.operator(col, "sl.op_refreshlist", text="", name='refresh', fallback='FILE_REFRESH', emboss=False)
        ui_icons.operator(col, "sl.op_openfile", text="", name='runfile', fallback='CURRENT_FILE', emboss=False)
        ui_icons.operator(col, "sl.op_openexplorer", text="", name='folder', fallback='FILEBROWSER', emboss=False)
        if not integrated_bridge.is_integrated_mode():
            col.separator()
            ui_icons.operator(col, "sl.op_openpreferences", text="", name='settings', fallback='PREFERENCES', emboss=False)

        # 実行ボタン
        row = box.row()
        row.scale_y = 1.2
        ui_icons.operator(row, "sl.op_runscript", text="Run Script", name='launch', fallback='PLAY')

        if integrated_bridge.is_integrated_mode():
            draw_integrated_preferences(layout, context)
