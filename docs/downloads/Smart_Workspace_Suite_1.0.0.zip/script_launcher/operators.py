# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
from ..translation import error_text, localized_layout, ui_pair
import os
import importlib.util
import traceback

from . import core
from . import integrated_bridge


def _script_failure_detail(exc, script_path):
    """利用者のスクリプトの失敗の原因（ファイル名・行番号・例外の種類と文）。設定の言語に関わらず出す。"""
    line = getattr(exc, 'lineno', None) if isinstance(exc, SyntaxError) else None
    target = os.path.normpath(script_path)
    for frame in traceback.extract_tb(exc.__traceback__):
        if os.path.normpath(frame.filename) == target:
            line = frame.lineno
    place = os.path.basename(script_path) if line is None else f"{os.path.basename(script_path)}:{line}"
    return f"{place} {type(exc).__name__}: {exc}"


def _get_script_group(context):
    scene = getattr(context, 'scene', None)
    return getattr(scene, 'sl_group', None) if scene is not None else None


def _clamp_active_index(sl_group):
    if sl_group is None or not getattr(sl_group, 'sl_items', None):
        return -1
    count = len(sl_group.sl_items)
    if count <= 0:
        return -1
    index = int(getattr(sl_group, 'active_index', 0))
    if index < 0 or index >= count:
        index = max(0, min(index, count - 1))
        try:
            sl_group.active_index = index
        except Exception:
            pass
    return index



def _localized_list_message(message, context):
    if message == 'No items in list':
        return ui_pair('No items in list', 'リストに項目がありません', context)
    if message == 'No scripts in list':
        return ui_pair('No scripts in list', 'リストにスクリプトがありません', context)
    return message

def _get_active_item(context, operator, empty_message='No items in list'):
    sl_group = _get_script_group(context)
    if sl_group is None or not getattr(sl_group, 'sl_items', None) or len(sl_group.sl_items) == 0:
        operator.report({'WARNING'}, _localized_list_message(empty_message, context))
        return None
    index = _clamp_active_index(sl_group)
    if index < 0:
        operator.report({'WARNING'}, _localized_list_message(empty_message, context))
        return None
    try:
        return sl_group.sl_items[index]
    except (IndexError, TypeError, AttributeError):
        operator.report({'WARNING'}, ui_pair('Selected item is no longer available', '選択した項目は利用できなくなりました', context))
        return None


# ---------------------------------------------------------------------------
# リスト更新
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_REFRESHLIST(bpy.types.Operator):
    bl_idname = "sl.op_refreshlist"
    bl_label = "Refresh List"
    bl_description = "Reload scripts list from all root folders"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        core.invalidate_fs_cache()
        core.build_visible_tree(context)
        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# スクリプト実行
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_RUNSCRIPT(bpy.types.Operator):
    bl_idname = "sl.op_runscript"
    bl_label = "Run Script"
    bl_description = "Execute the selected script"
    bl_options = {'UNDO'}

    def execute(self, context):
        item = _get_active_item(context, self, empty_message="No scripts in list")
        if item is None:
            return {'CANCELLED'}

        if item.is_root_header:
            self.report({'WARNING'}, ui_pair('Select a script file to run', '実行するスクリプトファイルを選択してください', context))
            return {'CANCELLED'}

        if item.is_folder:
            self.report({'WARNING'}, ui_pair('Select a script file, not a folder', 'フォルダーではなくスクリプトファイルを選択してください', context))
            return {'CANCELLED'}

        if not os.path.isfile(item.full_path):
            self.report({'ERROR'}, f"{ui_pair('File not found', 'ファイルが見つかりません', context)}: {item.full_path}")
            return {'CANCELLED'}

        try:
            spec = importlib.util.spec_from_file_location(item.name[:-3], item.full_path)
            if spec is None or spec.loader is None:
                self.report({'ERROR'}, f"{ui_pair('Could not create a Python module loader for', 'Pythonモジュールローダーを作成できませんでした', context)}: {item.full_path}")
                return {'CANCELLED'}
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        except Exception as exc:
            self.report({'ERROR'}, f"{ui_pair('Script execution failed', 'スクリプトの実行に失敗しました', context)}: {_script_failure_detail(exc, item.full_path)}")
            return {'CANCELLED'}

        self.report({'INFO'}, ui_pair(f"{item.name} executed successfully", f"{item.name} を実行しました", context))
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# ファイルを内部テキストエディタで開く
# ---------------------------------------------------------------------------

def _get_or_load_text(filepath):
    """既存のテキストブロックを再利用、なければ新規読み込み。"""
    norm = os.path.normpath(filepath)
    for text in bpy.data.texts:
        if os.path.normpath(bpy.path.abspath(text.filepath)) == norm:
            return text
    return bpy.data.texts.load(filepath)


class SCRIPTLAUNCHER_OT_OPENFILE(bpy.types.Operator):
    bl_idname = "sl.op_openfile"
    bl_label = "Open in Text Editor"
    bl_description = "Open the selected .py file in Blender's Text Editor"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        item = _get_active_item(context, self, empty_message="No scripts in list")
        if item is None:
            return {'CANCELLED'}

        if item.is_folder or item.is_root_header:
            self.report({'WARNING'}, ui_pair('Select a script file to open', '開くスクリプトファイルを選択してください', context))
            return {'CANCELLED'}

        if not os.path.isfile(item.full_path):
            self.report({'ERROR'}, f"{ui_pair('File not found', 'ファイルが見つかりません', context)}: {item.full_path}")
            return {'CANCELLED'}

        try:
            text = _get_or_load_text(item.full_path)
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Could not open file', 'ファイルを開けませんでした', context))
            return {'CANCELLED'}

        # 既存の Text Editor エリアを探して表示
        screen = getattr(context, 'screen', None)
        for area in getattr(screen, 'areas', []):
            if area.type == 'TEXT_EDITOR':
                area.spaces.active.text = text
                return {'FINISHED'}

        # なければ新規ウィンドウで開く
        try:
            bpy.ops.wm.window_new()
            new_win = context.window_manager.windows[-1]
            new_win.screen.areas[0].type = 'TEXT_EDITOR'
            new_win.screen.areas[0].spaces.active.text = text
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Could not create a Text Editor window', 'テキストエディターウィンドウを作成できませんでした', context))
            return {'CANCELLED'}

        return {'FINISHED'}


# ---------------------------------------------------------------------------
# 選択中アイテムのフォルダをエクスプローラーで開く
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_OPENEXPLORER(bpy.types.Operator):
    bl_idname = "sl.op_openexplorer"
    bl_label = "Open in Explorer"
    bl_description = "Open the selected item's folder in the system file manager"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        item = _get_active_item(context, self, empty_message="No items in list")
        if item is None:
            return {'CANCELLED'}

        # ファイルなら親フォルダ、フォルダ/ルートヘッダーはそのパス
        if item.is_folder or item.is_root_header:
            target = item.full_path
        else:
            target = os.path.dirname(item.full_path)

        if not target or not os.path.exists(target):
            self.report({'ERROR'}, f"{ui_pair('Path not found', 'パスが見つかりません', context)}: {target}")
            return {'CANCELLED'}

        try:
            bpy.ops.wm.path_open(filepath=target)
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Could not open folder', 'フォルダーを開けませんでした', context))
            return {'CANCELLED'}
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# プリファレンスを開く
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_OPENPREFERENCES(bpy.types.Operator):
    bl_idname = "sl.op_openpreferences"
    bl_label = "Open Preferences"
    bl_description = "Open Script Launcher addon preferences"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        # The dialog is opened exclusively from invoke().  Calling
        # invoke_props_dialog() again from execute() re-opens the same popup
        # after confirmation and creates an empty Undo boundary.
        if integrated_bridge.is_integrated_mode():
            return {'FINISHED'}
        bpy.ops.preferences.addon_show(module=__package__)
        return {'FINISHED'}

    def draw(self, context):
        core.draw_integrated_preferences(localized_layout(self.layout, context), context)

    def invoke(self, context, _event):
        if integrated_bridge.is_integrated_mode():
            return context.window_manager.invoke_props_dialog(self, width=520)
        return self.execute(context)


# ---------------------------------------------------------------------------
# フォルダのトグル展開
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_TOGGLEFOLDER(bpy.types.Operator):
    bl_idname = "sl.op_togglefolder"
    bl_label = "Toggle Folder"
    bl_description = "Expand or collapse this folder"
    bl_options = {'UNDO'}

    item_index: bpy.props.IntProperty()

    def execute(self, context):
        sl_group = _get_script_group(context)
        if sl_group is None:
            return {'CANCELLED'}

        if self.item_index < 0 or self.item_index >= len(sl_group.sl_items):
            return {'CANCELLED'}

        item = sl_group.sl_items[self.item_index]
        if not item.is_folder:
            return {'CANCELLED'}

        # 展開状態を反転してからツリーを再構築
        item.is_expanded = not item.is_expanded
        current_path = item.full_path

        core.build_visible_tree(context)

        # 操作したフォルダにフォーカスを戻す
        for i, node in enumerate(sl_group.sl_items):
            if node.full_path == current_path:
                sl_group.active_index = i
                break

        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# 検索クリア
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_CLEAR_SEARCH(bpy.types.Operator):
    bl_idname = "sl.op_clear_search"
    bl_label = "Clear Search"
    bl_description = "Clear the search filter"
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        sl_group = _get_script_group(context)
        if sl_group is None:
            return {'CANCELLED'}
        sl_group.search_text = ""
        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# ルートフォルダの追加・削除（プリファレンス用）
# ---------------------------------------------------------------------------

class SCRIPTLAUNCHER_OT_ADD_ROOT(bpy.types.Operator):
    bl_idname = "sl.op_add_root"
    bl_label = "Add Root Folder"
    bl_description = "Add a new root folder to the script roots list"
    bl_options = {'UNDO'}

    def execute(self, context):
        addon_prefs = integrated_bridge.get_prefs(context)
        if addon_prefs is None:
            return {'CANCELLED'}
        addon_prefs.sl_folders.add()
        addon_prefs.active_root_index = len(addon_prefs.sl_folders) - 1
        core.invalidate_fs_cache()
        core.build_visible_tree(context)
        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}


class SCRIPTLAUNCHER_OT_REMOVE_ROOT(bpy.types.Operator):
    bl_idname = "sl.op_remove_root"
    bl_label = "Remove Root Folder"
    bl_description = "Remove the selected root folder from the list"
    bl_options = {'UNDO'}

    def execute(self, context):
        addon_prefs = integrated_bridge.get_prefs(context)
        if addon_prefs is None:
            return {'CANCELLED'}

        if not addon_prefs.sl_folders:
            return {'CANCELLED'}

        idx = int(getattr(addon_prefs, 'active_root_index', 0))
        count = len(addon_prefs.sl_folders)
        if idx < 0 or idx >= count:
            addon_prefs.active_root_index = max(0, min(idx, count - 1))
            return {'CANCELLED'}
        addon_prefs.sl_folders.remove(idx)
        addon_prefs.active_root_index = max(0, min(idx, len(addon_prefs.sl_folders) - 1))

        core.invalidate_fs_cache()
        core.build_visible_tree(context)
        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}


class SCRIPTLAUNCHER_OT_MOVE_ROOT(bpy.types.Operator):
    bl_idname = "sl.op_move_root"
    bl_label = "Move Root Folder"
    bl_description = "Move the selected root folder up or down"
    bl_options = {'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('UP', 'Up', ''), ('DOWN', 'Down', '')],
    )

    def execute(self, context):
        addon_prefs = integrated_bridge.get_prefs(context)
        if addon_prefs is None:
            return {'CANCELLED'}
        idx = int(getattr(addon_prefs, 'active_root_index', 0))
        count = len(addon_prefs.sl_folders)
        if count <= 0 or idx < 0 or idx >= count:
            addon_prefs.active_root_index = max(0, min(idx, count - 1)) if count else 0
            return {'CANCELLED'}

        if self.direction == 'UP' and idx > 0:
            addon_prefs.sl_folders.move(idx, idx - 1)
            addon_prefs.active_root_index -= 1
        elif self.direction == 'DOWN' and idx < count - 1:
            addon_prefs.sl_folders.move(idx, idx + 1)
            addon_prefs.active_root_index += 1
        else:
            return {'CANCELLED'}

        core.invalidate_fs_cache()
        core.build_visible_tree(context)
        integrated_bridge.persist_user_change(context, 'script-launcher-operator')
        return {'FINISHED'}
