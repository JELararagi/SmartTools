# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import json
from pathlib import Path

import bpy
from .. import storage as _suite_storage
from .. import runtime_ledger as _runtime_ledger

_STORAGE_ATTR = "smart_workspace_suite_script_launcher_prefs"
_STORAGE_CLS = None
_STORAGE_LOADING = False
_LAST_SCENE_STATE: dict = {}


def _window_scene(context=None):
    """Resolve the active Window's Scene during load/msgbus boundaries."""
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
    except Exception:
        pass
    return getattr(ctx, 'scene', None)


def is_integrated_mode() -> bool:
    package = str(__package__ or '').lower()
    return (
        '.smart_workspace_suite.' in package
        or package.startswith('smart_workspace_suite.')
        or package.endswith('.smart_workspace_suite')
        or package == 'smart_workspace_suite'
    )


def _prefs_filepath() -> Path:
    return _suite_storage.addon_storage_path('script_launcher_v1_2_0.json', 'script_launcher')


def _storage_default_dict() -> dict:
    return {
        'sl_panel_category': 'Script Launcher',
        'active_root_index': 0,
        'sl_folders': [],
    }


def _scene_state_dict(context=None) -> dict:
    ctx = context or getattr(bpy, 'context', None)
    scene = _window_scene(ctx)
    sl_group = getattr(scene, 'sl_group', None) if scene is not None else None
    if sl_group is None:
        return {}
    active_index = int(getattr(sl_group, 'active_index', 0) or 0)
    active_path = ''
    try:
        items = getattr(sl_group, 'sl_items', ())
        if 0 <= active_index < len(items):
            active_path = str(getattr(items[active_index], 'full_path', '') or '')
    except Exception:
        active_path = ''
    expanded_paths = []
    try:
        expanded_paths = [
            str(getattr(item, 'full_path', '') or '')
            for item in getattr(sl_group, 'sl_items', ())
            if bool(getattr(item, 'is_expanded', False)) and str(getattr(item, 'full_path', '') or '')
        ]
    except Exception:
        expanded_paths = []
    return {
        'search_text': str(getattr(sl_group, 'search_text', '') or ''),
        'active_index': active_index,
        'active_path': active_path,
        'expanded_paths': expanded_paths,
    }


def _serialize_prefs(prefs, context=None) -> dict:
    panel_category = getattr(prefs, 'sl_panel_category', 'Script Launcher')
    data = {
        'format': 'smart_workspace_suite.script_launcher.integrated.v2',
        # Empty is an explicit N-panel value, not a request to restore the
        # default label.  Missing attributes still receive the default above.
        'sl_panel_category': '' if panel_category is None else str(panel_category),
        'active_root_index': int(getattr(prefs, 'active_root_index', 0) or 0),
        'sl_folders': [],
        'scene_state': _scene_state_dict(context),
    }
    for item in getattr(prefs, 'sl_folders', ()):
        data['sl_folders'].append({
            'path': str(getattr(item, 'path', '') or ''),
            'label': str(getattr(item, 'label', '') or ''),
        })
    return data


def _apply_prefs(prefs, data: dict | None) -> None:
    global _STORAGE_LOADING, _LAST_SCENE_STATE
    payload = dict(_storage_default_dict())
    scene_state = {}
    if isinstance(data, dict):
        if isinstance(data.get('preferences'), dict):
            payload.update(data.get('preferences') or {})
        else:
            payload.update(data)
        if isinstance(data.get('scene_state'), dict):
            scene_state = dict(data.get('scene_state') or {})
    _LAST_SCENE_STATE = scene_state
    _STORAGE_LOADING = True
    try:
        panel_category = payload.get('sl_panel_category')
        prefs.sl_panel_category = '' if panel_category is None else str(panel_category)
        prefs.active_root_index = int(payload.get('active_root_index') or 0)
        prefs.sl_folders.clear()
        for entry in payload.get('sl_folders', ()) or ():
            if not isinstance(entry, dict):
                continue
            item = prefs.sl_folders.add()
            item.path = str(entry.get('path') or '')
            item.label = str(entry.get('label') or '')
        count = len(prefs.sl_folders)
        prefs.active_root_index = max(0, min(int(getattr(prefs, 'active_root_index', 0) or 0), count - 1)) if count else 0
    finally:
        _STORAGE_LOADING = False


def _apply_scene_state(context=None, data: dict | None = None) -> None:
    global _STORAGE_LOADING, _LAST_SCENE_STATE
    if data is None:
        data = _LAST_SCENE_STATE
    if not isinstance(data, dict):
        return
    ctx = context or getattr(bpy, 'context', None)
    scene = _window_scene(ctx)
    sl_group = getattr(scene, 'sl_group', None) if scene is not None else None
    if sl_group is None:
        return
    _LAST_SCENE_STATE = dict(data)
    _STORAGE_LOADING = True
    try:
        if 'search_text' in data:
            sl_group.search_text = str(data.get('search_text') or '')
        if 'active_index' in data:
            try:
                sl_group.active_index = max(0, int(data.get('active_index') or 0))
            except Exception:
                pass
    finally:
        _STORAGE_LOADING = False


def get_saved_expanded_paths(context=None) -> set[str]:
    del context
    values = _LAST_SCENE_STATE.get('expanded_paths') if isinstance(_LAST_SCENE_STATE, dict) else None
    if not isinstance(values, (list, tuple, set)):
        return set()
    return {str(value) for value in values if str(value or '')}


def get_saved_active_path(context=None) -> str:
    del context
    if not isinstance(_LAST_SCENE_STATE, dict):
        return ''
    return str(_LAST_SCENE_STATE.get('active_path') or '')


def restore_scene_state(context=None) -> None:
    _apply_scene_state(context, _LAST_SCENE_STATE)


def load_prefs(context=None) -> None:
    prefs = get_prefs(context)
    if prefs is None:
        return
    path = _prefs_filepath()
    if not path.exists():
        _apply_prefs(prefs, None)
        _apply_scene_state(context, _LAST_SCENE_STATE)
        return
    data = _suite_storage.read_json(path, None)
    _apply_prefs(prefs, data if isinstance(data, dict) else None)
    _apply_scene_state(context, _LAST_SCENE_STATE)


def save_prefs(context=None, *, force: bool = False) -> bool:
    try:
        from .. import persistence as _suite_persistence
        if _suite_persistence.runtime_sidecar_write_blocked():
            _suite_persistence.mark_deferred_settings_dirty()
            return False
    except Exception:
        pass
    if not force:
        try:
            if not _suite_storage.n_panel_state_save_enabled(True):
                try:
                    from .. import persistence as _suite_persistence
                    _suite_persistence.mark_deferred_settings_dirty()
                except Exception:
                    pass
                return False
        except Exception:
            return False
    prefs = get_prefs(context)
    if prefs is None:
        return True
    try:
        path = _prefs_filepath()
        payload = _serialize_prefs(prefs, context)
        global _LAST_SCENE_STATE
        _LAST_SCENE_STATE = dict(payload.get('scene_state') or {})
        return bool(_suite_storage.atomic_write_json(
            path, payload, indent=2, ensure_ascii=False
        ))
    except Exception:
        return False

def persist_user_change(context=None, source: str = 'script-launcher-rna-update') -> bool:
    if _STORAGE_LOADING:
        return False
    try:
        from .. import persistence as _suite_persistence
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def _on_storage_update(self, context) -> None:
    del self
    persist_user_change(context)


def register_storage(folder_root_type) -> bool:
    global _STORAGE_CLS
    if not is_integrated_mode():
        return True
    if _STORAGE_CLS is None:
        attrs = {
            '__module__': __name__,
            '__annotations__': {
                'sl_panel_category': bpy.props.StringProperty(
                    name='Panel Category',
                    default='Script Launcher',
                    description='Category tab name for Script Launcher\'s panel',
                    update=_on_storage_update,
                ),
                'sl_folders': bpy.props.CollectionProperty(
                    type=folder_root_type,
                    name='Script Roots',
                ),
                'active_root_index': bpy.props.IntProperty(
                    name='Active Root Index',
                    default=0,
                    update=_on_storage_update,
                ),
            },
        }
        _STORAGE_CLS = type('SCRIPTLAUNCHER_INTEGRATED_PREFERENCES', (bpy.types.PropertyGroup,), attrs)
    class_ok, _newly_registered = _runtime_ledger.register_class_exact(
        _STORAGE_CLS,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='SCRIPT_LAUNCHER_STORAGE_CLASS',
    )
    if not class_ok:
        return False
    owner = bpy.types.WindowManager
    if _runtime_ledger.live_property_signature(owner, _STORAGE_ATTR)[1]:
        if not _runtime_ledger.property_is_current(owner, _STORAGE_ATTR, _STORAGE_CLS):
            _runtime_ledger.mark_restart_required('SCRIPT_LAUNCHER_STORAGE_POINTER_CONFLICT')
            return False
    else:
        setattr(owner, _STORAGE_ATTR, bpy.props.PointerProperty(type=_STORAGE_CLS))
        if not _runtime_ledger.record_property(
            owner,
            _STORAGE_ATTR,
            _STORAGE_CLS,
            remover=lambda _handle=None: delattr(owner, _STORAGE_ATTR),
            newly_registered=True,
        ):
            try:
                delattr(owner, _STORAGE_ATTR)
            except Exception:
                pass
            return False
    load_prefs(getattr(bpy, 'context', None))
    return True


def unregister_storage(context=None) -> bool:
    global _STORAGE_CLS
    if not is_integrated_mode():
        return True
    save_prefs(context, force=True)
    owner = bpy.types.WindowManager
    if _runtime_ledger.live_property_signature(owner, _STORAGE_ATTR)[1]:
        if not _runtime_ledger.property_is_current(owner, _STORAGE_ATTR, _STORAGE_CLS):
            return False
        try:
            delattr(owner, _STORAGE_ATTR)
        except Exception:
            return False
    if _STORAGE_CLS is not None:
        if not _runtime_ledger.unregister_class_exact(
            _STORAGE_CLS,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCRIPT_LAUNCHER_STORAGE_CLASS',
        ):
            return False
        _STORAGE_CLS = None
    return True

def get_prefs(context=None):
    if not is_integrated_mode():
        ctx = context or getattr(bpy, 'context', None)
        if ctx is None:
            return None
        addon = ctx.preferences.addons.get(__package__)
        return addon.preferences if addon else None
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    return getattr(wm, _STORAGE_ATTR, None) if wm is not None else None
