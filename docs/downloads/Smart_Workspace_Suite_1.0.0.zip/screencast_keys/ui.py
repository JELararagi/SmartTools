# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
from ..translation import localized_layout, ui_pair
from .. import ui_icons

from .operators import show_mouse_hold_status
from . import integrated_bridge


def _draw_suite_help_button(layout, context=None, help_id='runtime') -> None:
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = help_id
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass

class SK_PT_ScreencastKeys(bpy.types.Panel):
    bl_idname = "SK_PT_ScreencastKeys"
    bl_label = "Screencast Keys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'

    @classmethod
    def poll(cls, _context):
        return not integrated_bridge.is_integrated_mode()

    def draw_header(self, context):
        # Runtime start/stop is centralized in Smart Workspace > Always-on Toggles.
        return None

    def draw(self, _):
        context = getattr(bpy, 'context', None)
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        header.label(text=ui_pair('Screencast Keys', 'Screencast Keys', context), icon='EVENT_K')
        _draw_suite_help_button(header, context, 'screencast_keys')
        prefs = integrated_bridge.get_prefs(bpy.context)
        if prefs is None:
            layout.label(text="Integrated preferences are unavailable", icon='ERROR')
            return

        column = layout.column()

        column.prop(prefs, "color")

        column.separator()

        column.prop(prefs, "shadow")
        if prefs.shadow:
            column.prop(prefs, "shadow_color", text="")

        column.separator()

        column.prop(prefs, "background")
        if prefs.background:
            background_split = column.split(factor=0.5)
            background_split.prop(prefs, "background_mode", text="")
            background_color_split = background_split.split(factor=1.0)
            background_color_split.prop(prefs, "background_color", text="")
            column.prop(prefs, "background_rounded_corner_radius",
                        text="Corner Radius")

        column.separator()

        column.prop(prefs, "font_size")
        column.prop(prefs, "margin")
        column.prop(prefs, "line_thickness")
        if show_mouse_hold_status(prefs):
            if prefs.use_custom_mouse_image:
                column.label(text="Mouse Size:")
                r = column.row()
                r.prop(prefs, "custom_mouse_size", text="")
                r.enabled = True
            else:
                column.prop(prefs, "mouse_size")

        column.separator()

        column.label(text="Origin:")
        column.prop(prefs, "origin", text="")
        column.operator("wm.sk_set_origin", text="Set Origin")

        column.separator()
        column.label(text="Align:")
        column.prop(prefs, "align", text="")

        column.separator()

        column.label(text="Offset:")
        row = column.row()
        row.prop(prefs, "offset", text="")

        column.separator()

        column.prop(prefs, "display_time")
        column.prop(prefs, "max_event_history")

        column.separator()

        column.prop(prefs, "repeat_count")

        column.separator()

        column.prop(prefs, "show_mouse_events")
        if prefs.show_mouse_events:
            mouse_mode_split = column.split(factor=0.05)
            _ = mouse_mode_split.column()     # spacer.
            mouse_mode_content = mouse_mode_split.split(factor=1.0)
            c = mouse_mode_content.column()
            c.label(text="Mode:")
            c.prop(prefs, "mouse_events_show_mode", text="")

        column.separator()

        column.prop(prefs, "show_last_operator")
        if prefs.show_last_operator:
            operator_mode_split = column.split(factor=0.05)
            _ = operator_mode_split.column()     # spacer.
            operator_mode_content = operator_mode_split.split(factor=1.0)
            c = operator_mode_content.column()
            c.label(text="Mode:")
            c.prop(prefs, "last_operator_show_mode", text="")



class SK_PT_ScreencastKeys_Overlay(bpy.types.Panel):
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_idname = "SK_PT_ScreencastKeys_Overlay"
    bl_parent_id = "VIEW3D_PT_overlay"

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        row = layout.row(align=True)
        enabled = bool(getattr(context.window_manager, 'enable_screencast_keys', False))
        state = ui_pair('Enabled', '有効', context) if enabled else ui_pair('Disabled', '無効', context)
        row.label(text=f'Screencast Keys: {state}', translate=False)
        _draw_suite_help_button(row, context, 'screencast_keys')
