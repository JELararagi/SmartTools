# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Sidebar and compact viewport controls for the native input display."""
import bpy
from . import integrated_bridge
from .language import CONTEXT
from .operators import SK_OT_ScreencastKeys, _manager_allows_screencast
from .. import runtime_ledger

_registered = []
_layout_key = None

def text(en, ja):
    return ja if bpy.app.translations.locale.startswith('ja') else en

def controls(layout, prefs):
    running = SK_OT_ScreencastKeys.is_running()
    row = layout.row(align=True)
    row.operator('wm.sk_screencast_keys', text=text('Stop input display','入力表示を停止') if running else text('Show my input','キーとマウスを表示'), icon='PAUSE' if running else 'PLAY')
    row.operator('wm.sk_set_origin', text=text('Place','位置を指定'), icon='PIVOT_CURSOR')

def draw_settings(layout, context):
    prefs = integrated_bridge.get_prefs(context)
    if prefs is None:
        layout.label(text=text('Open a workspace first','ワークスペースを開いてください'))
        return
    controls(layout,prefs)
    layout.prop(prefs,'category',expand=True)
    if prefs.category == 'DISPLAY_EVENT_TEXT_ALIAS':
        layout.prop(prefs,'enable_display_event_text_aliases',text=text('Use custom key labels','キー名を変更'))
        if prefs.enable_display_event_text_aliases:
            for entry in prefs.display_event_text_aliases_props:
                layout.prop(entry,'alias_text',text=entry.default_text or entry.event_id)
        return
    for key in ('font_size','color','display_time','max_event_history','repeat_count','origin','align','offset','margin','shadow'):
        layout.prop(prefs,key)
    if prefs.shadow:
        layout.prop(prefs,'shadow_color')
    layout.prop(prefs,'background')
    if prefs.background:
        for key in ('background_mode','background_color','background_rounded_corner_radius'):
            layout.prop(prefs,key)
    layout.prop(prefs,'show_mouse_events')
    if prefs.show_mouse_events:
        for key in ('mouse_events_show_mode','mouse_size','line_thickness','use_custom_mouse_image'):
            layout.prop(prefs,key)
        if prefs.use_custom_mouse_image:
            layout.prop(prefs,'custom_mouse_image_display_mode')
            for button in ('BASE','LEFT_MOUSE','MIDDLE_MOUSE','RIGHT_MOUSE'):
                row=layout.row(align=True)
                row.prop(prefs,'custom_mouse_image_'+button.lower())
                row.operator('wm.sk_select_custom_mouse_image',text='',icon='FILE_FOLDER').target=button
            layout.prop(prefs,'use_custom_mouse_image_size')
            if prefs.use_custom_mouse_image_size:
                layout.prop(prefs,'custom_mouse_size')
    layout.prop(prefs,'show_last_operator')
    if prefs.show_last_operator:layout.prop(prefs,'last_operator_show_mode')
    for key in ('enable_on_startup','auto_save','display_draw_area','output_debug_log','show_ui_in_overlay','show_ui_in_sidebar'):
        layout.prop(prefs,key)
    if prefs.show_ui_in_sidebar:
        layout.prop(prefs,'panel_space_type')
        layout.prop(prefs,'panel_category')

def help_button(layout):
    layout.operator('wm.url_open',text='?',emboss=False).url='https://jelararagi.github.io/SmartTools/manuals/SmartWorkspace/'

class SK_PT_ScreencastKeys(bpy.types.Panel):
    bl_idname='SK_PT_ScreencastKeys'
    bl_label='Screencast Keys'
    bl_translation_context=CONTEXT
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Smart Workspace'
    @classmethod
    def poll(cls,context):return _manager_allows_screencast(context)
    def draw_header(self,context):help_button(self.layout)
    def draw(self,context):draw_settings(self.layout,context)

class SK_PT_ScreencastKeys_Overlay(bpy.types.Panel):
    bl_idname='SK_PT_ScreencastKeys_Overlay'
    bl_label='Screencast Keys'
    bl_translation_context=CONTEXT
    bl_space_type='VIEW_3D'
    bl_region_type='HEADER'
    bl_parent_id='VIEW3D_PT_overlay'
    @classmethod
    def poll(cls,context):return _manager_allows_screencast(context)
    def draw_header(self,context):help_button(self.layout)
    def draw(self,context):
        prefs=integrated_bridge.get_prefs(context)
        if prefs:controls(self.layout,prefs)

def _detach():
    while _registered:
        cls=_registered[-1]
        ok=runtime_ledger.unregister_class_exact(cls,native_unregister=bpy.utils.unregister_class,reason_prefix='Screencast display UI')
        if not ok:raise RuntimeError('Input display panel could not be removed: '+cls.__name__)
        _registered.pop()

def configure(prefs):
    global _layout_key
    visible=getattr(prefs,'show_ui_in_sidebar',True)
    header=getattr(prefs,'show_ui_in_overlay',False)
    space=getattr(prefs,'panel_space_type','VIEW_3D') or 'VIEW_3D'
    category=getattr(prefs,'panel_category','') or 'Smart Workspace'
    # The default location is the host suite tab; explicit custom names are kept.
    if category=='Screencast Keys':category='Smart Workspace'
    requested=(visible,header,space,category)
    if _layout_key==requested:return
    unregister()
    SK_PT_ScreencastKeys.bl_space_type=space
    SK_PT_ScreencastKeys.bl_category=category
    try:
        for cls,wanted in ((SK_PT_ScreencastKeys,visible),(SK_PT_ScreencastKeys_Overlay,header)):
            if wanted:
                ok,_=runtime_ledger.register_class_exact(cls,native_register=bpy.utils.register_class,native_unregister=bpy.utils.unregister_class,reason_prefix='Screencast display UI')
                if not ok:raise RuntimeError('Input display panel is owned by another instance: '+cls.__name__)
                _registered.append(cls)
    except Exception:
        unregister()
        raise
    _layout_key=requested

def unregister():
    global _layout_key
    _layout_key=None
    _detach()
