# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent settings and image chooser for the Smart Workspace input display."""
from pathlib import Path
import bpy
from bpy import props
from .utils.bl_class_registry import BlClassRegistry
from .language import CONTEXT


def changed(self,context):
    from . import integrated_bridge
    integrated_bridge.mark_prefs_dirty()

def startup_changed(self,context):
    changed(self,context)
    from . import _set_load_post_handler_enabled, _always, integrated_bridge
    if not integrated_bridge.restoring:
        _set_load_post_handler_enabled(self.enable_on_startup or _always('screencast_enable_on_startup'))

def layout_changed(self,context):
    changed(self,context)
    from . import ui, integrated_bridge
    if not integrated_bridge.restoring:
        ui.configure(self)

class DisplayEventTextAliasProperties(bpy.types.PropertyGroup):
    event_id:props.StringProperty(translation_context=CONTEXT,name='Input')
    default_text:props.StringProperty(translation_context=CONTEXT,name='Blender label')
    alias_text:props.StringProperty(translation_context=CONTEXT,name='Display as', update=changed)

def choice(items):
    return [(k,k.replace('_',' ').title(),'') for k in items.split()]

def vector(name,default,*,color=False,maximum=None):
    if color:
        return props.FloatVectorProperty(translation_context=CONTEXT,name=name,size=4,subtype='COLOR',default=default,min=0,max=1,update=changed)
    return props.IntVectorProperty(translation_context=CONTEXT,name=name,size=len(default),default=default,update=changed,**(maximum or {}))

class SK_INTEGRATED_PREFERENCES(bpy.types.PropertyGroup):
    category:props.EnumProperty(translation_context=CONTEXT,items=choice('CONFIG DISPLAY_EVENT_TEXT_ALIAS'),name='Settings page',default='CONFIG')
    color:vector('Text color',(1,1,1,1),color=True)
    shadow:props.BoolProperty(translation_context=CONTEXT,name='Text shadow',update=changed)
    shadow_color:vector('Shadow color',(0,0,0,1),color=True)
    background:props.BoolProperty(translation_context=CONTEXT,name='Background',update=changed)
    background_mode:props.EnumProperty(translation_context=CONTEXT,name='Background area',items=choice('TEXT DRAW_AREA'),default='DRAW_AREA',update=changed)
    background_color:vector('Background color',(0,0,0,1),color=True)
    background_rounded_corner_radius:props.IntProperty(translation_context=CONTEXT,name='Corner radius',min=0,max=100,update=changed)
    font_size:props.IntProperty(translation_context=CONTEXT,name='Text size',default=11,min=6,max=1000,update=changed)
    margin:props.IntProperty(translation_context=CONTEXT,name='Padding',min=0,max=1000,update=changed)
    line_thickness:props.FloatProperty(translation_context=CONTEXT,name='Line width',default=1,min=1,max=100,update=changed)
    mouse_size:props.IntProperty(translation_context=CONTEXT,name='Mouse icon size',min=18,max=1000,default=33,update=changed)
    origin:props.EnumProperty(translation_context=CONTEXT,name='Anchor',items=choice('REGION AREA WINDOW CURSOR'),default='REGION',update=changed)
    offset:vector('Offset',(20,80))
    align:props.EnumProperty(translation_context=CONTEXT,name='Text alignment',items=choice('LEFT CENTER RIGHT'),default='LEFT',update=changed)
    display_time:props.FloatProperty(translation_context=CONTEXT,name='Seconds visible',min=.5,max=10,default=3,update=changed)
    max_event_history:props.IntProperty(translation_context=CONTEXT,name='History length',default=5,min=1,update=changed)
    repeat_count:props.BoolProperty(translation_context=CONTEXT,name='Count repeated presses',default=True,update=changed)
    show_mouse_events:props.BoolProperty(translation_context=CONTEXT,name='Show mouse input',default=True,update=changed)
    mouse_events_show_mode:props.EnumProperty(translation_context=CONTEXT,name='Mouse display',items=choice('EVENT_HISTORY HOLD_STATUS EVENT_HISTORY_AND_HOLD_STATUS'),default='HOLD_STATUS',update=changed)
    use_custom_mouse_image:props.BoolProperty(translation_context=CONTEXT,name='Custom mouse artwork',update=changed)
    custom_mouse_image_display_mode:props.EnumProperty(translation_context=CONTEXT,name='Mouse image layers',items=choice('NORMAL OVERLAY'),default='OVERLAY',update=changed)
    custom_mouse_image_base:props.StringProperty(translation_context=CONTEXT,name='Base image',subtype='FILE_PATH',update=changed)
    custom_mouse_image_left_mouse:props.StringProperty(translation_context=CONTEXT,name='Left button image',subtype='FILE_PATH',update=changed)
    custom_mouse_image_middle_mouse:props.StringProperty(translation_context=CONTEXT,name='Middle button image',subtype='FILE_PATH',update=changed)
    custom_mouse_image_right_mouse:props.StringProperty(translation_context=CONTEXT,name='Right button image',subtype='FILE_PATH',update=changed)
    use_custom_mouse_image_size:props.BoolProperty(translation_context=CONTEXT,name='Choose image size',update=changed)
    custom_mouse_size:vector('Image width and height',(33,33),maximum=dict(min=18,max=1000))
    show_last_operator:props.BoolProperty(translation_context=CONTEXT,name='Show last command',update=changed)
    last_operator_show_mode:props.EnumProperty(translation_context=CONTEXT,name='Command label',items=choice('LABEL IDNAME LABEL_AND_IDNAME'),default='LABEL_AND_IDNAME',update=changed)
    auto_save:props.BoolProperty(translation_context=CONTEXT,name='Save recovery copies during recording',update=changed)
    output_debug_log:props.BoolProperty(translation_context=CONTEXT,name='Log display lifecycle',update=changed)
    display_draw_area:props.BoolProperty(translation_context=CONTEXT,name='Outline overlay bounds',update=changed)
    panel_space_type:props.EnumProperty(translation_context=CONTEXT,name='Editor for settings',items=choice('VIEW_3D IMAGE_EDITOR NODE_EDITOR SEQUENCE_EDITOR GRAPH_EDITOR DOPESHEET_EDITOR'),default='VIEW_3D',update=layout_changed)
    panel_category:props.StringProperty(translation_context=CONTEXT,name='Sidebar tab',default='Screencast Keys',update=layout_changed)
    enable_on_startup:props.BoolProperty(translation_context=CONTEXT,name='Start after loading a file',update=startup_changed)
    show_ui_in_sidebar:props.BoolProperty(translation_context=CONTEXT,name='Sidebar settings',default=True,update=layout_changed)
    show_ui_in_overlay:props.BoolProperty(translation_context=CONTEXT,name='Viewport header settings',update=layout_changed)
    enable_display_event_text_aliases:props.BoolProperty(translation_context=CONTEXT,name='Use custom key labels',update=changed)
    display_event_text_aliases_props:props.CollectionProperty(type=DisplayEventTextAliasProperties)

class SK_Preferences(bpy.types.AddonPreferences):
    bl_idname=__package__
    def draw(self,context):
        from .ui import draw_settings
        draw_settings(self.layout,context)

@BlClassRegistry()
class SK_OT_SelectCustomMouseImage(bpy.types.Operator):
    bl_idname='wm.sk_select_custom_mouse_image'
    bl_label='Select Custom Mouse Image'
    bl_translation_context=CONTEXT
    bl_description='Choose the artwork for the selected mouse button'
    target:props.EnumProperty(translation_context=CONTEXT,name='Button',items=choice('BASE LEFT_MOUSE RIGHT_MOUSE MIDDLE_MOUSE'),default='BASE')
    filepath:props.StringProperty(translation_context=CONTEXT,subtype='FILE_PATH')
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        from .integrated_bridge import get_prefs
        full=Path(bpy.path.abspath(self.filepath))
        if not self.filepath or not full.is_file():
            self.report({'WARNING'},'Choose an existing image file')
            return {'CANCELLED'}
        setattr(get_prefs(context),'custom_mouse_image_'+self.target.lower(),self.filepath)
        return {'FINISHED'}
