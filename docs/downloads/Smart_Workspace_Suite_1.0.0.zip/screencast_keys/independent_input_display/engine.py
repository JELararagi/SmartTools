# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Pure event reduction and display projection; no Blender or operating-system IO.

This is a new, explicit behavioral contract. It does not claim unobserved legacy
settings, event timing, or rendering behavior to be identical.
"""
from dataclasses import replace

from .labels import (
    MODIFIER_KEYS, MOUSE_BUTTONS, WHEEL_EVENTS, canonical_modifiers,
    entry_label, key_label, modifier_label,
)
from .model import Entry, Frame, Line, State, Visibility, finite_number

_PRESSES = frozenset(('PRESS', 'DOUBLE_CLICK'))
_NO_HISTORY = frozenset(('NONE', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'))


def _clock(state, now):
    now = finite_number(now, 'now')
    if state.last_at is not None and now < state.last_at:
        raise ValueError('now must not move backwards')
    return now


def _live_entries(state, now, settings):
    if settings.max_history == 0 or settings.display_time == 0:
        return ()
    entries = tuple(
        entry for entry in state.entries
        if now < entry.last_at + settings.display_time
        and (settings.mouse_history or entry.device != 'mouse')
    )
    return entries[-settings.max_history:]


def advance(state, now, settings, visibility=Visibility()):
    """Expire history, or discard all input state when its context is hidden."""
    now = _clock(state, now)
    if visibility.reason():
        return State(last_at=now)
    return replace(state, entries=_live_entries(state, now, settings), last_at=now)


def _modifiers(state, event_type, value, snapshot):
    held = set(state.modifier_keys)
    if event_type in MODIFIER_KEYS:
        group = MODIFIER_KEYS[event_type]
        if value in _PRESSES:
            held.discard(group)
            held.add(event_type)
        elif value == 'RELEASE':
            held.discard(event_type)
            held.discard(group)
    if snapshot is not None:
        # A supplied snapshot describes the state AFTER this event. An empty
        # snapshot clears stale physical keys as well as the displayed flags.
        groups = canonical_modifiers(snapshot)
        held = {key for key in held if MODIFIER_KEYS.get(key, key) in groups}
        for group in groups:
            if not any(MODIFIER_KEYS.get(key, key) == group for key in held):
                held.add(group)
    return tuple(sorted(held)), canonical_modifiers(held)


def reduce_event(state, event, now, settings, visibility=Visibility()):
    """Consume one normalized event and return a new immutable state.

    Each PRESS or DOUBLE_CLICK contributes one accepted press. CLICK, RELEASE,
    motion and timer events never add a history row. DOUBLE_CLICK is not expanded
    into two extra presses. Consecutive equal physical inputs merge within the
    inclusive repeat window; labels are deliberately not part of that identity.
    """
    current = advance(state, now, settings, visibility)
    if visibility.reason():
        return current
    event_type = event.event_type.upper()
    value = event.value.upper()
    physical, modifiers = _modifiers(current, event_type, value, event.modifiers)
    buttons = set(current.mouse_buttons)
    if event_type in MOUSE_BUTTONS:
        if value in _PRESSES:
            buttons.add(event_type)
        elif value == 'RELEASE':
            buttons.discard(event_type)
    current = replace(
        current,
        modifier_keys=physical,
        modifiers=modifiers,
        mouse_buttons=tuple(key for key in MOUSE_BUTTONS if key in buttons),
    )
    if (
        value not in _PRESSES
        or event_type in MODIFIER_KEYS
        or event_type in _NO_HISTORY
        or event_type.startswith('TIMER')
        or (event.is_repeat and not settings.auto_repeat)
    ):
        return current
    device = 'mouse' if event_type in MOUSE_BUTTONS + WHEEL_EVENTS else 'keyboard'
    if (
        (device == 'mouse' and not settings.mouse_history)
        or settings.max_history == 0
        or settings.display_time == 0
    ):
        return current
    entries = current.entries
    if entries:
        previous = entries[-1]
        same_input = (
            previous.event_type == event_type
            and previous.modifiers == modifiers
            and previous.device == device
        )
        if same_input and current.last_at - previous.last_at <= settings.repeat_window:
            repeated = replace(previous, count=previous.count + 1, last_at=current.last_at)
            return replace(current, entries=entries[:-1] + (repeated,))
    new_entry = Entry(event_type, modifiers, 1, current.last_at, current.last_at, device)
    return replace(current, entries=(entries + (new_entry,))[-settings.max_history:])


def render_frame(state, now, settings, visibility=Visibility()):
    """Project state into localized display values without changing that state.

    Lines are oldest first. modifier_display controls only the held-modifier
    field; a shortcut's modifiers remain part of its history caption. An empty
    explicit alias hides that event's caption. No clock is read in this module.
    """
    now = _clock(state, now)
    reason = visibility.reason()
    if reason:
        return Frame(hidden_reason=reason)
    visible_entries = tuple(
        entry for entry in _live_entries(state, now, settings)
        if key_label(entry.event_type, settings)
    )
    lines = tuple(
        Line(entry_label(entry, settings), entry.event_type, entry.modifiers,
             entry.count, entry.device)
        for entry in visible_entries
    )
    modifiers = (
        tuple(modifier_label(key, settings) for key in state.modifiers)
        if settings.modifier_display else ()
    )
    buttons = state.mouse_buttons if settings.mouse_hold else ()
    next_change = min(
        (entry.last_at + settings.display_time for entry in visible_entries),
        default=None,
    )
    return Frame(
        lines=lines,
        modifiers=modifiers,
        mouse_buttons=buttons,
        mouse_labels=tuple(key_label(key, settings) for key in buttons),
        next_change=next_change,
    )
