# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent key captions. Each returned caption uses one selected language."""
import re

MODIFIER_ORDER = ('CTRL', 'SHIFT', 'ALT', 'OSKEY')
MODIFIER_KEYS = {
    'LEFT_CTRL': 'CTRL', 'RIGHT_CTRL': 'CTRL',
    'LEFT_SHIFT': 'SHIFT', 'RIGHT_SHIFT': 'SHIFT',
    'LEFT_ALT': 'ALT', 'RIGHT_ALT': 'ALT', 'OSKEY': 'OSKEY',
}
MOUSE_BUTTONS = ('LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE', 'BUTTON4MOUSE', 'BUTTON5MOUSE', 'BUTTON6MOUSE', 'BUTTON7MOUSE')
WHEEL_EVENTS = ('WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE')
_CAPTIONS = {
    'LEFTMOUSE': ('Left Mouse', '左マウス'),
    'MIDDLEMOUSE': ('Middle Mouse', '中マウス'),
    'RIGHTMOUSE': ('Right Mouse', '右マウス'),
    'WHEELUPMOUSE': ('Wheel Up', 'ホイール上'),
    'WHEELDOWNMOUSE': ('Wheel Down', 'ホイール下'),
    'WHEELINMOUSE': ('Wheel In', 'ホイール内向き'),
    'WHEELOUTMOUSE': ('Wheel Out', 'ホイール外向き'),
    'SPACE': ('Space', 'スペース'), 'RET': ('Enter', 'Enter'),
    'NUMPAD_ENTER': ('Numpad Enter', 'テンキー Enter'),
    'ESC': ('Esc', 'Esc'), 'TAB': ('Tab', 'Tab'),
    'BACK_SPACE': ('Backspace', 'Backspace'), 'DEL': ('Delete', 'Delete'),
    'LEFT_ARROW': ('Left Arrow', '左矢印'), 'RIGHT_ARROW': ('Right Arrow', '右矢印'),
    'UP_ARROW': ('Up Arrow', '上矢印'), 'DOWN_ARROW': ('Down Arrow', '下矢印'),
    'HOME': ('Home', 'Home'), 'END': ('End', 'End'),
    'PAGE_UP': ('Page Up', 'Page Up'), 'PAGE_DOWN': ('Page Down', 'Page Down'),
    'INSERT': ('Insert', 'Insert'), 'PAUSE': ('Pause', 'Pause'),
    'CAPSLOCK': ('Caps Lock', 'Caps Lock'),
    'MINUS': ('-', '-'), 'PLUS': ('+', '+'), 'EQUAL': ('=', '='),
    'COMMA': (',', ','), 'PERIOD': ('.', '.'), 'SLASH': ('/', '/'),
    'BACK_SLASH': ('\\', '\\'), 'SEMI_COLON': (';', ';'),
    'QUOTE': ("'", "'"), 'ACCENT_GRAVE': ('`', '`'),
    'LEFT_BRACKET': ('[', '['), 'RIGHT_BRACKET': (']', ']'),
}
_DIGITS = dict(zip(('ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE'), '0123456789'))


def canonical_modifiers(modifiers):
    found = {MODIFIER_KEYS.get(item.upper(), item.upper()) for item in modifiers}
    return tuple(item for item in MODIFIER_ORDER if item in found)


def modifier_label(modifier, settings):
    if modifier == 'OSKEY':
        return {'WINDOWS': 'Win', 'DARWIN': 'Cmd', 'MACOS': 'Cmd', 'LINUX': 'Super'}.get(settings.platform.upper(), 'OS')
    if modifier == 'ALT' and settings.platform.upper() in ('DARWIN', 'MACOS'):
        return 'Option'
    return {'CTRL': 'Ctrl', 'SHIFT': 'Shift', 'ALT': 'Alt'}[modifier]


def key_label(event_type, settings):
    for identifier, caption in settings.aliases:
        if identifier == event_type:
            return caption
    japanese = settings.language.lower().replace('-', '_').startswith('ja')
    if event_type in _CAPTIONS:
        return _CAPTIONS[event_type][int(japanese)]
    if event_type in _DIGITS:
        return _DIGITS[event_type]
    if re.fullmatch(r'[A-Z0-9]|F(?:[1-9]|1[0-9]|2[0-4])', event_type):
        return event_type
    if re.fullmatch(r'NUMPAD_[0-9]', event_type):
        return ('テンキー ' if japanese else 'Numpad ') + event_type[-1]
    if event_type in MOUSE_BUTTONS:
        number = event_type[len('BUTTON'):event_type.index('MOUSE')]
        return ('マウスボタン ' if japanese else 'Mouse Button ') + number
    return '不明なキー' if japanese else 'Unknown Key'


def entry_label(entry, settings):
    tokens = [modifier_label(item, settings) for item in entry.modifiers]
    tokens.append(key_label(entry.event_type, settings))
    text = ' + '.join(tokens)
    return text if entry.count == 1 else text + ' × ' + str(entry.count)
