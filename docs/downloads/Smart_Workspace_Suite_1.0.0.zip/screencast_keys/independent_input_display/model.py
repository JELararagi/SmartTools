# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Immutable values for the independently designed input display pipeline."""
from dataclasses import dataclass
from math import isfinite
from typing import Optional, Tuple


def finite_number(value, name, minimum=0.0):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(name + ' must be a number')
    if not isfinite(value) or value < minimum:
        raise ValueError(name + ' must be finite and >= ' + str(minimum))
    return float(value)


@dataclass(frozen=True)
class Event:
    event_type: str
    value: str = 'PRESS'
    modifiers: Optional[Tuple[str, ...]] = None
    is_repeat: bool = False

    def __post_init__(self):
        if not isinstance(self.event_type, str) or not self.event_type:
            raise ValueError('event_type must be a nonempty string')
        if not isinstance(self.value, str):
            raise TypeError('value must be a string')
        if self.modifiers is not None and not isinstance(self.modifiers, tuple):
            raise TypeError('modifiers must be a tuple or None')
        if self.modifiers is not None and any(not isinstance(item, str) for item in self.modifiers):
            raise TypeError('modifier identifiers must be strings')
        if not isinstance(self.is_repeat, bool):
            raise TypeError('is_repeat must be boolean')


@dataclass(frozen=True)
class Settings:
    """Timing and history limits are explicit inputs, not guessed legacy defaults."""
    display_time: float
    max_history: int
    repeat_window: float
    language: str = 'en_US'
    mouse_history: bool = True
    mouse_hold: bool = True
    modifier_display: bool = True
    auto_repeat: bool = True
    platform: str = 'WINDOWS'
    aliases: Tuple[Tuple[str, str], ...] = ()

    def __post_init__(self):
        finite_number(self.display_time, 'display_time')
        finite_number(self.repeat_window, 'repeat_window')
        if isinstance(self.max_history, bool) or not isinstance(self.max_history, int):
            raise TypeError('max_history must be an integer')
        if self.max_history < 0:
            raise ValueError('max_history must be nonnegative')
        if not isinstance(self.language, str) or not isinstance(self.platform, str):
            raise TypeError('language and platform must be strings')
        for name in ('mouse_history', 'mouse_hold', 'modifier_display', 'auto_repeat'):
            if not isinstance(getattr(self, name), bool):
                raise TypeError(name + ' must be boolean')
        if not isinstance(self.aliases, tuple):
            raise TypeError('aliases must be immutable pairs')
        seen = set()
        for pair in self.aliases:
            if not isinstance(pair, tuple) or len(pair) != 2 or not all(isinstance(item, str) for item in pair):
                raise TypeError('each alias must contain two strings')
            if not pair[0] or pair[0] in seen:
                raise ValueError('alias identifiers must be nonempty and unique')
            seen.add(pair[0])


@dataclass(frozen=True)
class Visibility:
    enabled: bool = True
    area_allowed: bool = True
    active_window: bool = True
    active_view: bool = True
    suspended: bool = False

    def reason(self):
        for allowed, reason in ((self.enabled, 'disabled'), (self.area_allowed, 'area'),
                                (self.active_window, 'window'), (self.active_view, 'view'),
                                (not self.suspended, 'suspended')):
            if not allowed:
                return reason
        return ''


@dataclass(frozen=True)
class Entry:
    event_type: str
    modifiers: Tuple[str, ...]
    count: int
    first_at: float
    last_at: float
    device: str


@dataclass(frozen=True)
class State:
    entries: Tuple[Entry, ...] = ()
    modifier_keys: Tuple[str, ...] = ()
    modifiers: Tuple[str, ...] = ()
    mouse_buttons: Tuple[str, ...] = ()
    last_at: Optional[float] = None


@dataclass(frozen=True)
class Line:
    text: str
    event_type: str
    modifiers: Tuple[str, ...]
    count: int
    device: str


@dataclass(frozen=True)
class Frame:
    lines: Tuple[Line, ...] = ()
    modifiers: Tuple[str, ...] = ()
    mouse_buttons: Tuple[str, ...] = ()
    mouse_labels: Tuple[str, ...] = ()
    next_change: Optional[float] = None
    hidden_reason: str = ''
