# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent input display components; importing this package starts no runtime."""
__version__ = '1.0.0'
