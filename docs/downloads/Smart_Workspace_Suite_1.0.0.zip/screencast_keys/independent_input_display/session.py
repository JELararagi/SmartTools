# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Explicitly owned input state; draw consumers read an immutable cached frame."""
from .engine import advance, reduce_event, render_frame
from .model import Frame, State, Visibility


class InputDisplaySession:
    def __init__(self):
        self._state = State()
        self._frame = Frame()
        self._closed = False

    @property
    def state(self):
        return self._state

    @property
    def frame(self):
        return self._frame

    @property
    def closed(self):
        return self._closed

    def update(self, event, now, settings, visibility=Visibility()):
        if self._closed:
            raise RuntimeError('input display session is closed')
        state = reduce_event(self._state, event, now, settings, visibility)
        frame = render_frame(state, now, settings, visibility)
        self._state, self._frame = state, frame
        return frame

    def tick(self, now, settings, visibility=Visibility()):
        if self._closed:
            raise RuntimeError('input display session is closed')
        state = advance(self._state, now, settings, visibility)
        frame = render_frame(state, now, settings, visibility)
        self._state, self._frame = state, frame
        return frame

    def close(self):
        self._state = State()
        self._frame = Frame(hidden_reason='stopped')
        self._closed = True
        return self._frame
