# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Normalize Blender-local events and draw a cached input frame in the originating view."""
import time

import bpy

from .independent_input_display.model import Event, Visibility
from .independent_input_display.session import InputDisplaySession

def view_region(window, x, y):
    """Identify the native view under a window-relative event, excluding sidebars."""
    if window is None or window.screen is None:
        return None
    for area in window.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        for region in area.regions:
            if (region.type == 'WINDOW' and region.x <= x < region.x + region.width
                    and region.y <= y < region.y + region.height):
                return area, region
    return None

class ViewInput:
    def __init__(self, window, area):
        self.window = window
        self.area = area
        self.session = InputDisplaySession()
        self.handler = None
        self.focused = True

    def attach(self, draw):
        if self.handler is None:
            self.handler = bpy.types.SpaceView3D.draw_handler_add(draw, (self,), 'WINDOW', 'POST_PIXEL')

    def consume(self, event, settings):
        if not event.type.startswith('TIMER'):
            view = view_region(self.window, event.mouse_x, event.mouse_y)
            self.focused = event.type != 'WINDOW_DEACTIVATE' and view is not None and view[0] == self.area
        visible = Visibility(active_view=self.focused)
        now = time.monotonic()
        if event.type.startswith('TIMER'):
            frame = self.session.tick(now, settings, visible)
        else:
            modifiers = tuple(name for name, down in (
                ('CTRL', event.ctrl), ('SHIFT', event.shift), ('ALT', event.alt), ('OSKEY', event.oskey)
            ) if down)
            frame = self.session.update(Event(event.type, event.value, modifiers, event.is_repeat), now, settings, visible)
        self.area.tag_redraw()
        return frame

    def close(self):
        if self.handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self.handler, 'WINDOW')
            self.handler = None
        self.session.close()
