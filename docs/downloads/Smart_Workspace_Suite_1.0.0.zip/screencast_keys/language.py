# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Translate only this feature's controls and commands."""
import bpy
CONTEXT='JEL_Workspace_Input'
KEY=__package__+'.captions'
LABELS={
    'Input':'入力','Blender label':'Blenderの表示名','Display as':'表示する名前','Settings page':'設定ページ',
    'Text color':'文字色','Text shadow':'文字の影','Shadow color':'影の色','Background':'背景','Background area':'背景の範囲',
    'Background color':'背景色','Corner radius':'角の丸み','Text size':'文字サイズ','Padding':'余白',
    'Line width':'線幅','Mouse icon size':'マウスアイコンの大きさ','Anchor':'配置の基準','Offset':'位置のずれ',
    'Text alignment':'文字の配置','Seconds visible':'表示時間（秒）','History length':'履歴の件数',
    'Count repeated presses':'連続入力の回数を表示','Show mouse input':'マウス操作を表示','Mouse display':'マウスの表示方法',
    'Custom mouse artwork':'マウス画像を指定','Mouse image layers':'画像の重ね方','Base image':'通常時の画像',
    'Left button image':'左ボタンの画像','Right button image':'右ボタンの画像','Middle button image':'中央ボタンの画像',
    'Choose image size':'画像サイズを指定','Image width and height':'画像の幅と高さ','Show last command':'最後の操作を表示',
    'Command label':'操作名の表示形式','Save recovery copies during recording':'入力表示中に復元用コピーを保存',
    'Log display lifecycle':'表示開始・終了をログに記録','Outline overlay bounds':'表示範囲の枠を描く',
    'Editor for settings':'設定を表示するエディター','Sidebar tab':'サイドバーのタブ名',
    'Start after loading a file':'ファイルを開いた後に有効化','Sidebar settings':'サイドバーに設定を表示',
    'Viewport header settings':'ビューポートのヘッダーに設定を表示','Use custom key labels':'キー名を変更',
    'Button':'対象ボタン','Show input':'入力を表示','Screencast Keys':'キー入力表示',
    'Screencast Keys Set Origin':'キー入力表示の位置を指定','Select Custom Mouse Image':'マウス画像を選択',
    'Start Screencast Keys When a View Is Ready':'ビューを開いた時にキー入力を表示',
    'Config':'設定','Display Event Text Alias':'キー名の編集','Draw Area':'表示領域','Text':'文字',
    'Hold Status':'押しているボタン','Event History':'入力履歴','Event History And Hold Status':'履歴と押しているボタン',
    'Area':'エリア','Region':'領域','Window':'ウィンドウ','Cursor':'カーソル','Left':'左','Center':'中央','Right':'右',
    'Label':'表示名','Idname':'識別名','Label And Idname':'表示名と識別名','Base':'通常時','Right Mouse':'右マウス',
    'Middle Mouse':'中央マウス','Left Mouse':'左マウス','Normal':'通常','Overlay':'重ねて表示',
}
_active=False
def register():
    global _active
    if _active:return
    entries={(CONTEXT,k):v for k,v in LABELS.items()}
    bpy.app.translations.register(KEY,{'ja_JP':entries,'ja':entries})
    _active=True
def unregister():
    global _active
    if _active:
        bpy.app.translations.unregister(KEY)
        _active=False
