# SPDX-License-Identifier: GPL-3.0-or-later
"""Draw the SmartWorkspace input overlay using Blender's built-in GPU programs."""
import gpu
from gpu_extras.batch import batch_for_shader

GL_LINES, GL_LINE_STRIP, GL_LINE_LOOP = 0, 1, 2
GL_QUADS, GL_TRIANGLES, GL_TRIANGLE_FAN = 4, 5, 6
_LINE_TYPES = {GL_LINES: 'LINES', GL_LINE_STRIP: 'LINE_STRIP', GL_LINE_LOOP: 'LINE_STRIP'}


class _Brush:
    color = (1.0, 1.0, 1.0, 1.0)
    width = 1.0
    texture = None
    previous_scissor = None

    def begin(self, mode):
        self.mode = mode
        self.positions = []
        self.uv = []


_brush = _Brush()


def immColor4f(r, g, b, a):
    _brush.color = (r, g, b, a)


def immColor3f(r, g, b):
    immColor4f(r, g, b, 1.0)


def immLineWidth(width):
    _brush.width = width


def immSetTexture(texture):
    _brush.texture = texture


def immSetScissor(box):
    if box is None:
        gpu.state.scissor_test_set(False)
        if _brush.previous_scissor is not None:
            gpu.state.scissor_set(*_brush.previous_scissor)
            _brush.previous_scissor = None
        return
    if _brush.previous_scissor is None:
        _brush.previous_scissor = tuple(gpu.state.scissor_get())
    x, y, right, top = box
    gpu.state.scissor_set(x, y, right - x, top - y)
    gpu.state.scissor_test_set(True)


def immBegin(mode):
    _brush.begin(mode)


def immVertex2f(x, y):
    _brush.positions.append((x, y, 0.0))


def immVertex3f(x, y, z):
    _brush.positions.append((x, y, z))


def immTexCoord2f(u, v):
    _brush.uv.append((u, v))


def immRecti(x0, y0, x1, y1):
    immBegin(GL_QUADS)
    for point in ((x0, y0), (x0, y1), (x1, y1), (x1, y0)):
        immVertex2f(*point)
    immEnd()


def _triangles(mode, count):
    if mode == GL_TRIANGLES and count % 3 == 0:
        return None
    if mode == GL_TRIANGLE_FAN:
        return [(0, i - 1, i) for i in range(2, count)]
    if mode == GL_QUADS and count % 4 == 0:
        out = []
        for i in range(0, count, 4):
            out.extend(((i, i + 1, i + 2), (i + 2, i + 3, i)))
        return out
    raise ValueError(f"Unsupported polygon input: mode {mode}, {count} vertices")


def immEnd():
    brush = _brush
    positions = brush.positions
    if not positions:
        return
    mode = brush.mode
    indices = None
    attributes = {"pos": positions}
    if mode in _LINE_TYPES:
        primitive = _LINE_TYPES[mode]
        if mode == GL_LINE_LOOP:
            attributes["pos"] = [*positions, positions[0]]
        program = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        program.bind()
        program.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
        program.uniform_float("lineWidth", brush.width)
        if brush.previous_scissor is not None:
            program.uniform_int("lineSmooth", 1)
    else:
        primitive = 'TRIS'
        indices = _triangles(mode, len(positions))
        if brush.uv:
            if len(brush.uv) != len(positions) or brush.texture is None:
                raise ValueError("A textured overlay requires one UV per vertex and a texture")
            attributes["texCoord"] = brush.uv
            program = gpu.shader.from_builtin('IMAGE_COLOR')
            program.bind()
            program.uniform_sampler("image", brush.texture)
        else:
            program = gpu.shader.from_builtin('UNIFORM_COLOR')
            program.bind()
    program.uniform_float("ModelViewProjectionMatrix",
                          gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix())
    program.uniform_float("color", brush.color)
    batch_for_shader(program, primitive, attributes, indices=indices).draw(program)
    brush.begin(None)
