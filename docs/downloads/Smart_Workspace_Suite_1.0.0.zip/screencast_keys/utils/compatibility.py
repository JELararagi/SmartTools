# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender editor and font adapters for the SmartWorkspace input display."""

import blf
import bpy


# The order is part of the saved numeric values of the preferences menu.
_EDITORS = (
    ("VIEW_3D", "View3D"),
    ("CLIP_EDITOR", "ClipEditor"),
    ("CONSOLE", "Console"),
    ("DOPESHEET_EDITOR", "DopeSheetEditor"),
    ("FILE_BROWSER", "FileBrowser"),
    ("GRAPH_EDITOR", "GraphEditor"),
    ("IMAGE_EDITOR", "ImageEditor"),
    ("INFO", "Info"),
    ("LOGIC_EDITOR", "LogicEditor"),
    ("NLA_EDITOR", "NLA"),
    ("NODE_EDITOR", "NodeEditor"),
    ("OUTLINER", "Outliner"),
    ("PREFERENCES", "UserPreferences", "Preferences"),
    ("PROPERTIES", "Properties"),
    ("SEQUENCE_EDITOR", "SequenceEditor"),
    ("SPREADSHEET", "Spreadsheet"),
    ("TEXT_EDITOR", "TextEditor"),
    ("TIMELINE", "Timeline"),
)


def check_version(major, minor, _):
    """Compare the Blender feature release. Patch versions share the same API."""
    installed = tuple(bpy.app.version[:2])
    required = (major, minor)
    return int(installed > required) - int(installed < required)


def get_all_space_types():
    """Return option identifiers paired with the registered RNA editor classes."""
    spaces = {}
    for identifier, *suffixes in _EDITORS:
        for suffix in suffixes:
            editor = getattr(bpy.types, "Space" + suffix, None)
            if editor is not None:
                spaces[identifier] = editor
                break
    return spaces


def blf_size(font_id, font_size, dpi):
    """Set the requested font size, supporting the earlier DPI argument."""
    try:
        blf.size(font_id, font_size)
    except TypeError:
        blf.size(font_id, font_size, dpi)
