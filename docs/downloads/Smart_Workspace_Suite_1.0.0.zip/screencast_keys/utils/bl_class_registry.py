# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
from ... import runtime_ledger as _runtime_ledger


class BlClassRegistry:
    class_list = []

    def __init__(self, *_, **kwargs):
        self.legacy = kwargs.get('legacy', False)

    def __call__(self, cls):
        if hasattr(cls, "bl_idname"):
            BlClassRegistry.add_class(cls.bl_idname, cls, self.legacy)
        elif not hasattr(cls, "bl_context"):
            bl_idname = "{}{}{}".format(cls.bl_space_type,
                                        cls.bl_region_type,
                                        cls.bl_label)
            BlClassRegistry.add_class(bl_idname, cls, self.legacy)
        else:
            bl_idname = "{}{}{}{}".format(cls.bl_space_type,
                                          cls.bl_region_type,
                                          cls.bl_context, cls.bl_label)
            BlClassRegistry.add_class(bl_idname, cls, self.legacy)
        return cls

    @classmethod
    def add_class(cls, bl_idname, op_class, legacy):
        for class_ in cls.class_list:
            if (class_["bl_idname"] == bl_idname) and \
               (class_["legacy"] == legacy):
                raise RuntimeError("{} is already registered"
                                   .format(bl_idname))

        new_op = {
            "bl_idname": bl_idname,
            "class": op_class,
            "legacy": legacy,
        }
        cls.class_list.append(new_op)

    @classmethod
    def register(cls):
        for class_ in cls.class_list:
            target = class_["class"]
            success, _newly_registered = _runtime_ledger.register_class_exact(
                target,
                native_register=bpy.utils.register_class,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='SCREENCAST_REGISTRY_CLASS',
            )
            if not success:
                raise RuntimeError(
                    'RESTART_REQUIRED: Screencast Keys registry class ownership mismatch: '
                    + str(getattr(target, '__name__', '<unknown>'))
                )
        return True

    @classmethod
    def unregister(cls):
        for class_ in reversed(tuple(cls.class_list)):
            target = class_["class"]
            if not _runtime_ledger.class_recorded_current(target):
                continue
            if not _runtime_ledger.unregister_class_exact(
                target,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='SCREENCAST_REGISTRY_CLASS',
            ):
                return False
        return True

    @classmethod
    def cleanup(cls):
        cls.class_list = []
