# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent class registry for SmartWorkspace input display components.

The public behavior is derived from PUBLIC_CONTRACT.json and the additional
public-call observations. No third-party implementation is included or imported.
The containing add-on supplies bpy and its existing runtime_ledger module.
Historical diagnostic text is retained as part of the observed public contract.
"""

from importlib import import_module as _import_module

import bpy


def _resolve_runtime_ledger():
    """Find the owning package's ledger without depending on a vendor package.

    Only ancestors of this module's package are considered. A missing dependency
    inside an existing ledger is propagated, rather than mistaken for an absent
    ledger or replaced with direct Blender registration.
    """
    package = __package__
    while package:
        module_name = package + '.runtime_ledger'
        try:
            return _import_module(module_name)
        except ModuleNotFoundError as error:
            if error.name != module_name:
                raise
        package = package.rpartition('.')[0]
    raise ImportError('The containing add-on must provide runtime_ledger')


_runtime_ledger = _resolve_runtime_ledger()
_REASON_PREFIX = 'SCREENCAST_REGISTRY_CLASS'


class BlClassRegistry:
    """Collect classes, then register and unregister through the ownership ledger.

    Use @BlClassRegistry() on each class. The legacy keyword is retained as
    supplied; positional decorator arguments are accepted and ignored. Classes
    with the same identifier may coexist only when their legacy values differ.
    """

    class_list = []

    def __init__(self, *_, **kwargs):
        self.legacy = kwargs.get('legacy', False)

    def __call__(self, cls):
        if hasattr(cls, 'bl_idname'):
            identifier = cls.bl_idname
        else:
            identifier = '{}{}{}'.format(cls.bl_space_type, cls.bl_region_type, cls.bl_label)
        self.add_class(identifier, cls, self.legacy)
        return cls

    @classmethod
    def add_class(cls, bl_idname, op_class, legacy):
        """Append one declaration; reject a duplicate identifier/legacy pair."""
        for entry in cls.class_list:
            if entry['bl_idname'] == bl_idname and entry['legacy'] == legacy:
                raise RuntimeError('{} is already registered'.format(bl_idname))
        cls.class_list.append({'bl_idname': bl_idname, 'class': op_class, 'legacy': legacy})

    @classmethod
    def register(cls):
        """Register in declaration order, retaining partial ownership on failure.

        The ledger decides whether each exact class is already registered. Its
        exceptions propagate. A refused registration stops at that class; calling
        register again retries the declarations through the same ledger.
        """
        for entry in cls.class_list:
            item = entry['class']
            accepted, _ = _runtime_ledger.register_class_exact(
                item,
                native_register=bpy.utils.register_class,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix=_REASON_PREFIX,
            )
            if not accepted:
                raise RuntimeError(
                    'RESTART_REQUIRED: Screencast Keys registry class ownership mismatch: '
                    + item.__name__
                )
        return True

    @classmethod
    def unregister(cls):
        """Visit declarations in reverse order and remove only recorded classes.

        For compatibility, a false ledger return is not converted into a failed
        public return. Ledger exceptions propagate, and retained ownership can
        be retried by calling unregister again. True alone does not prove that
        every class was removed; the ledger is the ownership authority.
        """
        for entry in reversed(cls.class_list):
            item = entry['class']
            if _runtime_ledger.class_recorded_current(item):
                _runtime_ledger.unregister_class_exact(
                    item,
                    native_unregister=bpy.utils.unregister_class,
                    reason_prefix=_REASON_PREFIX,
                )
        return True

    @classmethod
    def cleanup(cls):
        """Replace the declarations list without unregistering any live classes."""
        cls.class_list = []
