# SPDX-License-Identifier: GPL-3.0-or-later
"""Input display runtime helpers."""
from . import bl_class_registry, compatibility
