# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

if "bpy" in locals():
    import importlib
    # pylint: disable=E0601
    importlib.reload(bl_class_registry)
    importlib.reload(compatibility)
else:
    from . import bl_class_registry
    from . import compatibility

# pylint: disable=C0413
import bpy
