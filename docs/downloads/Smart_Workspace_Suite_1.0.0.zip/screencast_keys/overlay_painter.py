# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Draw input captions and optional user-provided mouse images without adding Blender datablocks."""
from math import cos, sin, pi
from pathlib import Path

import blf
import bpy
import bpy.utils.previews
import gpu
from gpu_extras.batch import batch_for_shader

def polygon(shader, coords, color):
    shader.bind()
    shader.uniform_float('color', color)
    batch_for_shader(shader,'TRI_FAN',{'pos':coords}).draw(shader)

def rect(x,y,w,h,radius=0):
    radius=min(max(0,radius),min(w,h)/2)
    if not radius:
        return ((x,y),(x+w,y),(x+w,y+h),(x,y+h))
    points=[]
    for cx,cy,start in ((x+w-radius,y+radius,-pi/2),(x+w-radius,y+h-radius,0),
                        (x+radius,y+h-radius,pi/2),(x+radius,y+radius,pi)):
        for k in range(7):
            a=start+pi*k/12
            points.append((cx+radius*cos(a),cy+radius*sin(a)))
    return points

class OverlayPainter:
    def __init__(self):
        self._uniform = None
        self._image_shader = None
        self._previews = None
        self._images = {}
        self.cursor = None

    def clear_images(self):
        self._images.clear()
        if self._previews is not None:
            bpy.utils.previews.remove(self._previews)
            self._previews=None
    def close(self):
        self.clear_images()
        self._uniform = self._image_shader = None

    def image(self, name, filepath):
        if not filepath:
            return None
        path = Path(bpy.path.abspath(filepath))
        if name in self._images and self._images[name][0]==path:
            return self._images[name][1]
        if self._previews is None:
            self._previews=bpy.utils.previews.new()
        if name in self._previews:
            del self._previews[name]
        texture=None
        if path.is_file():
            try:
                preview=self._previews.load(name,str(path),'IMAGE')
                size=tuple(preview.image_size)
                if min(size)>0:
                    pixels=gpu.types.Buffer('FLOAT',size[0]*size[1]*4,preview.image_pixels_float[:])
                    texture=gpu.types.GPUTexture(size,format='RGBA8',data=pixels)
            except (OSError,RuntimeError,ValueError) as exc:
                print('Smart Workspace: could not load mouse image:',exc)
        self._images[name]=(path,texture)
        return texture

    def draw_image(self,texture,x,y,w,h):
        if self._image_shader is None:
            self._image_shader=gpu.shader.from_builtin('IMAGE')
        shader=self._image_shader
        shader.bind()
        shader.uniform_sampler('image',texture)
        batch_for_shader(shader,'TRI_FAN',{'pos':rect(x,y,w,h),'texCoord':((0,0),(1,0),(1,1),(0,1))}).draw(shader)

    def draw(self,c,frame,p):
        if frame.hidden_reason:
            return
        lines=[line.text for line in frame.lines]
        if frame.modifiers:
            lines.append(' + '.join(frame.modifiers))
        if p.show_last_operator and c.window_manager.operators:
            recent=next((op for op in reversed(list(c.window_manager.operators)) if not op.bl_idname.startswith('WM_OT_sk_')),None)
            if recent is not None:
                idname=recent.bl_idname.replace('_OT_','.').lower()
                lines.insert(0,{'LABEL':recent.bl_label,'IDNAME':idname,'LABEL_AND_IDNAME':recent.bl_label+' ('+idname+')'}[p.last_operator_show_mode])
        mouse=p.show_mouse_events and p.mouse_events_show_mode!='EVENT_HISTORY'
        if not mouse and not lines:
            return
        if self._uniform is None:
            self._uniform=gpu.shader.from_builtin('UNIFORM_COLOR')
        bg=self._uniform
        blf.size(0,p.font_size)
        line_height=max(1,round(blf.dimensions(0,'Mg')[1]*1.45))
        widths=[blf.dimensions(0,text)[0] for text in lines]
        mw,mh=tuple(p.custom_mouse_size) if p.use_custom_mouse_image and p.use_custom_mouse_image_size else (p.mouse_size,p.mouse_size)
        pad=p.margin+3
        width=max([*widths,mw if mouse else 0])+2*pad
        height=max(1,len(lines)*line_height+(mh if mouse else 0))+2*pad
        region=c.region
        if p.origin=='WINDOW':
            left,bottom,span=-region.x,-region.y,c.window.width
        elif p.origin=='AREA':
            left,bottom,span=c.area.x-region.x,c.area.y-region.y,c.area.width
        elif p.origin=='CURSOR' and self.cursor:
            left,bottom=self.cursor
            span=0
        else:
            left,bottom,span=0,0,region.width
        align={'LEFT':0,'CENTER':.5,'RIGHT':1}[p.align]
        x=left+(span-width)*align+p.offset[0]*(1 if align!=1 else -1)
        y=bottom+p.offset[1]
        x=max(0,min(x,region.width-width))
        y=max(0,min(y,region.height-height))
        prev=gpu.state.blend_get()
        gpu.state.blend_set('ALPHA')
        try:
            if p.background and p.background_mode=='DRAW_AREA':
                polygon(bg,rect(x,y,width,height,p.background_rounded_corner_radius),tuple(p.background_color))
            if p.display_draw_area:
                thickness=max(1,p.line_thickness)
                for sx,sy,w,h in ((x,y,width,thickness),(x,y+height-thickness,width,thickness),
                                  (x,y,thickness,height),(x+width-thickness,y,thickness,height)):
                    polygon(bg,rect(sx,sy,w,h),tuple(p.color))
            baseline=y+pad
            for text,sw in reversed(list(zip(lines,widths))):
                tx=x+pad+(width-2*pad-sw)*align
                if p.background and p.background_mode=='TEXT':
                    polygon(bg,rect(tx-2,baseline-2,sw+4,line_height,p.background_rounded_corner_radius),tuple(p.background_color))
                if p.shadow:
                    blf.position(0,tx+1,baseline-1,0)
                    blf.color(0,*p.shadow_color)
                    blf.draw(0,text)
                blf.color(0,*p.color)
                blf.position(0,tx,baseline,0)
                blf.draw(0,text)
                baseline+=line_height
            if mouse:
                mx=x+pad+(width-2*pad-mw)*align
                images=[]
                if p.use_custom_mouse_image:
                    buttons={'LEFTMOUSE':'left_mouse','MIDDLEMOUSE':'middle_mouse','RIGHTMOUSE':'right_mouse'}
                    layers=['base']+[buttons[k] for k in frame.mouse_buttons if k in buttons]
                    if p.custom_mouse_image_display_mode=='NORMAL':
                        layers=layers[-1:]
                    images=[t for key in layers if (t:=self.image(key,getattr(p,'custom_mouse_image_'+key))) is not None]
                if images:
                    for texture in images:
                        self.draw_image(texture,mx,baseline,mw,mh)
                else:
                    polygon(bg,rect(mx,baseline,mw,mh,min(mw,mh)*.28),tuple(p.color))
                    inset=min(max(p.line_thickness,1),mw/8,mh/8)
                    polygon(bg,rect(mx+inset,baseline+inset,mw-2*inset,mh-2*inset,min(mw,mh)*.22),(.12,.12,.12,.93))
                    for i,k in enumerate(('LEFTMOUSE','MIDDLEMOUSE','RIGHTMOUSE')):
                        shade=tuple(p.color) if k in frame.mouse_buttons else (.4,.4,.4,.85)
                        polygon(bg,rect(mx+inset+i*(mw-2*inset)/3,baseline+mh*.54,(mw-2*inset)/3-inset*.4,mh*.36,1),shade)
        finally:
            gpu.state.blend_set(prev)
