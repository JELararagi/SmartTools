# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Keep an opt-in recovery copy while the modal input display is active."""
import hashlib
import os
from pathlib import Path
from uuid import uuid4
import time

import bpy
from .. import storage

class Recovery:
    def __init__(self):
        self.next_at=None
        self.last_error=None

    def tick(self,context,prefs,now=None):
        now=time.monotonic() if now is None else now
        policy=context.preferences.filepaths
        if not prefs.auto_save or not policy.use_auto_save_temporary_files:
            self.next_at=None
            return
        interval=max(1,policy.auto_save_time)*60
        if self.next_at is None:
            self.next_at=now+interval
            return
        if now<self.next_at:return
        self.next_at=now+interval
        if not bpy.data.is_dirty or not bpy.ops.wm.save_as_mainfile.poll():return
        name=bpy.data.filepath or 'untitled-'+str(os.getpid())
        label=hashlib.sha256(os.fsencode(name)).hexdigest()[:16]
        temp=None
        try:
            target=Path(storage.storage_path(label+'.blend','screencast_keys','recovery',create=True))
            # Save alongside the final pathname: Blender remaps linked assets
            # relative to the save directory, which must remain the same.
            temp=target.with_name('writing-'+uuid4().hex+'.blend')
            result=bpy.ops.wm.save_as_mainfile(filepath=str(temp),copy=True,relative_remap=True,compress=True)
            if result!={'FINISHED'} or not temp.is_file():
                raise OSError('Recovery copy was not saved')
            temp.replace(target)
            self.last_error=None
        except (OSError,RuntimeError) as exc:
            self.last_error=str(exc)
            print('Smart Workspace: unable to write the input-display recovery copy:',exc)
        finally:
            if temp is not None and temp.is_file():temp.unlink()
