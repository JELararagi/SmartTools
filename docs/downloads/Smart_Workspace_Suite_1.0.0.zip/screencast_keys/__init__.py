# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Screencast Keys",
    "author": "JELararagi",
    "version": (4, 2, 2),
    "blender": (5, 0, 0),
    "location": "3D View > Sidebar > Screencast Keys",
    "warning": "",
    "description": "Display keys pressed in Blender",
    "wiki_url": "https://github.com/nutti/Screencast-Keys",
    "doc_url": "https://github.com/nutti/Screencast-Keys",
    "tracker_url": "https://github.com/nutti/Screencast-Keys",
    "category": "System",
}


if "bpy" in locals():
    import importlib
    # pylint: disable=E0601
    importlib.reload(gpu_utils)
    importlib.reload(utils)
    utils.bl_class_registry.BlClassRegistry.cleanup()
    importlib.reload(preferences)
    importlib.reload(ops)
    importlib.reload(ui)
    importlib.reload(common)
    importlib.reload(integrated_bridge)
else:
    import bpy
    from . import gpu_utils
    from . import utils
    from . import preferences
    from . import operators as ops
    from . import ui
    from . import common
    from . import integrated_bridge

# pylint: disable=C0413
import os
from .. import runtime_ledger as _runtime_ledger


addon_keymaps = []
integrated_proxy_panels = [ui.SK_PT_ScreencastKeys]
# pylint: disable=C0103
is_startup = True
_S1_REGISTERED_GENERATION = ""
_S1_ENABLE_PROPERTY_OWNER = object()



def _suite_always_on_enabled(action: str, default: bool = False) -> bool:
    if not integrated_bridge.is_integrated_mode():
        return bool(default)
    if action == 'screencast_hotkey':
        try:
            from .. import feature_toggle as _suite_feature_toggle
            if _suite_feature_toggle.is_feature_enabled('screencast_keys', 'keymaps'):
                return True
        except Exception:
            pass
    try:
        from .. import ui_runtime as _suite_ui_runtime
        remembered = getattr(_suite_ui_runtime, '_remembered_always_state', None)
        if callable(remembered):
            return bool(remembered(action, default))
    except Exception:
        pass
    return bool(default)


def _remove_handler_identity(handle, handler_list):
    try:
        while handle in handler_list:
            handler_list.remove(handle)
    except Exception:
        pass


def _set_load_post_handler_enabled(enabled: bool) -> None:
    enabled = bool(enabled)
    _runtime_ledger.remove_feature_leases('screencast-load-post', any_generation=False)
    handlers = bpy.app.handlers.load_post
    _remove_handler_identity(load_post_handler, handlers)
    if not enabled:
        return
    generation = _runtime_ledger.current_generation()
    if not generation:
        return
    handlers.append(load_post_handler)
    if not _runtime_ledger.register_lease(
        feature='screencast-load-post',
        space='APP',
        region='LOAD_POST',
        handle=load_post_handler,
        native_remover=_remove_handler_identity,
        remove_args=(handlers,),
    ):
        _remove_handler_identity(load_post_handler, handlers)
        raise RuntimeError('Unable to record screencast load_post lease')


@bpy.app.handlers.persistent
def load_post_handler(_dummy):
    global is_startup
    generation = _runtime_ledger.current_generation()
    if not generation or generation != _S1_REGISTERED_GENERATION or not _runtime_ledger.generation_matches(generation):
        is_startup = False
        return
    context = bpy.context
    prefs = integrated_bridge.get_prefs(context)
    if prefs is None:
        is_startup = False
        return
    enable_on_startup = bool(prefs.enable_on_startup and is_startup)
    was_running = bool((not is_startup) and ops.SK_OT_ScreencastKeys.is_running())
    if enable_on_startup or was_running:
        try:
            bpy.ops.wm.sk_wait_blender_initialized_and_start_screencast_keys()
        except Exception:
            ops.SK_OT_ScreencastKeys.stop(None, context)
    is_startup = False


@bpy.app.handlers.persistent
def load_pre_handler(_dummy):
    generation = _runtime_ledger.current_generation()
    if not generation or generation != _S1_REGISTERED_GENERATION or not _runtime_ledger.generation_matches(generation):
        return
    # Exact current-generation teardown before Window/Area/RNA replacement.
    try:
        _runtime_ledger.remove_feature_leases('screencast-origin', any_generation=False)
        _runtime_ledger.remove_feature_leases('screencast-origin-modal', any_generation=False)
        ops.SK_OT_SetOrigin.handlers.clear()
        ops.SK_OT_SetOrigin.draw_snapshots = ops.MappingProxyType({})
        ops.SK_OT_SetOrigin.runtime_generation = ''
    except Exception:
        pass
    try:
        ops.SK_OT_ScreencastKeys.stop(None, getattr(bpy, 'context', None))
    except Exception:
        for feature in ('screencast', 'screencast-timer', 'screencast-modal', 'screencast-autosave'):
            _runtime_ledger.remove_feature_leases(feature, any_generation=False)


def _install_load_pre_handler() -> None:
    handlers = bpy.app.handlers.load_pre
    _runtime_ledger.remove_feature_leases('screencast-load-pre', any_generation=False)
    _remove_handler_identity(load_pre_handler, handlers)
    generation = _runtime_ledger.current_generation()
    if not generation:
        return
    handlers.append(load_pre_handler)
    if not _runtime_ledger.register_lease(
        feature='screencast-load-pre',
        space='APP',
        region='LOAD_PRE',
        handle=load_pre_handler,
        native_remover=_remove_handler_identity,
        remove_args=(handlers,),
    ):
        _remove_handler_identity(load_pre_handler, handlers)
        raise RuntimeError('Unable to record screencast load_pre lease')


def register_shortcut_key():
    if integrated_bridge.is_integrated_mode() and not _suite_always_on_enabled('screencast_hotkey', False):
        return
    if addon_keymaps:
        return
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.get("3D View")
        created_keymap = False
        if km is None:
            km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
            created_keymap = True
        try:
            kmi = km.keymap_items.new("wm.sk_screencast_keys", 'C', 'PRESS',
                                      shift=True, alt=True)
        except Exception:
            if created_keymap:
                try:
                    if len(km.keymap_items) == 0:
                        kc.keymaps.remove(km)
                except Exception:
                    pass
            raise
        addon_keymaps.append((km, kmi))


def unregister_shortcut_key():
    keyconfigs = getattr(getattr(getattr(bpy, 'context', None), 'window_manager', None), 'keyconfigs', None)
    addon_kc = getattr(keyconfigs, 'addon', None) if keyconfigs is not None else None
    for km, kmi in list(addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
        try:
            if addon_kc is not None and len(getattr(km, 'keymap_items', ())) == 0:
                addon_kc.keymaps.remove(km)
        except Exception:
            pass
    addon_keymaps.clear()


def call_silently(fn, *args):
    try:
        fn(*args)
    # pylint: disable=W0702
    except:     # noqa
        pass


def _wm_enable_descriptor():
    try:
        properties = getattr(getattr(bpy.types.WindowManager, "bl_rna", None), "properties", None)
        getter = getattr(properties, "get", None)
        return getter("enable_screencast_keys") if callable(getter) else None
    except Exception:
        return None


def register_addon_enable_property() -> bool:
    owner_type = bpy.types.WindowManager
    property_name = "enable_screencast_keys"
    existing = _wm_enable_descriptor()
    if existing is not None:
        if _runtime_ledger.scalar_property_is_current(
            owner_type, property_name, _S1_ENABLE_PROPERTY_OWNER
        ):
            return True
        _runtime_ledger.mark_restart_required(
            "SCREENCAST_ENABLE_PROPERTY_IDENTITY_MISMATCH"
        )
        return False

    def get_func(_):
        return ops.SK_OT_ScreencastKeys.is_running()

    def set_func(_, __):
        pass

    def update_func(_, __):
        # This is an explicit RNA/user event boundary, never a draw callback.
        generation = _runtime_ledger.current_generation()
        context = getattr(bpy, 'context', None)
        if (
            not generation
            or generation != _S1_REGISTERED_GENERATION
            or not _runtime_ledger.generation_matches(generation)
            or bool(getattr(bpy.app, 'background', False))
            or context is None
            or getattr(context, 'window', None) is None
            or getattr(context, 'screen', None) is None
            or getattr(context, 'area', None) is None
            or not ops._manager_allows_screencast(context)
        ):
            return
        try:
            bpy.ops.wm.sk_screencast_keys('INVOKE_REGION_WIN')
        except Exception:
            ops.SK_OT_ScreencastKeys.stop(None, context)

    created = False
    try:
        setattr(
            owner_type,
            property_name,
            bpy.props.BoolProperty(
                name="Screencast Keys",
                get=get_func,
                set=set_func,
                update=update_func,
                options={'SKIP_SAVE'},
            ),
        )
        created = True
        if not _runtime_ledger.record_scalar_property(
            owner_type,
            property_name,
            _S1_ENABLE_PROPERTY_OWNER,
            remover=None,
            newly_registered=True,
        ):
            raise RuntimeError("Screencast enable property ownership ledger failed")
        return True
    except Exception:
        if created:
            try:
                if _wm_enable_descriptor() is not None:
                    delattr(owner_type, property_name)
            except Exception:
                pass
        _runtime_ledger.mark_restart_required(
            "SCREENCAST_ENABLE_PROPERTY_REGISTRATION_FAILED"
        )
        return False


def unregister_addon_enable_property() -> bool:
    owner_type = bpy.types.WindowManager
    property_name = "enable_screencast_keys"
    descriptor = _wm_enable_descriptor()
    if descriptor is None:
        return True
    if not _runtime_ledger.scalar_property_is_current(
        owner_type, property_name, _S1_ENABLE_PROPERTY_OWNER
    ):
        _runtime_ledger.mark_restart_required(
            "SCREENCAST_ENABLE_PROPERTY_TEARDOWN_IDENTITY_MISMATCH"
        )
        return False
    try:
        delattr(owner_type, property_name)
    except Exception:
        return False
    return _wm_enable_descriptor() is None


def _register_impl():
    if not common.is_console_mode():
        gpu_utils.shader.ShaderManager.register_shaders()
    _install_load_pre_handler()
    # Register Screencast Key's enable property at here to use it in the
    # both SK_PT_ScreencastKeys Panel and SK_PT_ScreencastKeys_Overlay Panel.
    # TODO: This registration should be handled by BlClassRegistry to add
    #       the priority feature.
    if not register_addon_enable_property():
        raise RuntimeError("Screencast enable property could not be registered safely")
    # Register the collection element class before the integrated preference
    # storage that references it. Sidebar/overlay panels are registered only by
    # their explicit preference event below.
    class_ok, _newly_registered = _runtime_ledger.register_class_exact(
        preferences.DisplayEventTextAliasProperties,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='SCREENCAST_ALIAS_CLASS',
    )
    if not class_ok:
        raise RuntimeError('RESTART_REQUIRED: Screencast alias class ownership mismatch')
    if not integrated_bridge.register_storage(preferences.SK_Preferences):
        raise RuntimeError("Screencast preference storage could not be registered safely")
    if integrated_bridge.is_integrated_mode():
        prefs_base = getattr(bpy.types, 'AddonPreferences', None)
        if prefs_base is not None:
            def _is_addon_preferences_entry(entry):
                try:
                    return issubclass(entry.get('class'), prefs_base)
                except TypeError:
                    return False
            utils.bl_class_registry.BlClassRegistry.class_list = [
                entry for entry in utils.bl_class_registry.BlClassRegistry.class_list
                if not _is_addon_preferences_entry(entry)
            ]
    utils.bl_class_registry.BlClassRegistry.register()
    register_shortcut_key()
    if integrated_bridge.is_integrated_mode():
        _set_load_post_handler_enabled(_suite_always_on_enabled('screencast_enable_on_startup', False))
    else:
        _set_load_post_handler_enabled(True)

    # Apply preferences of UI.
    context = bpy.context
    prefs = integrated_bridge.get_prefs(context)
    if prefs is None:
        return
    # Only default panel location is available in < 2.80
    if utils.compatibility.check_version(2, 80, 0) < 0:
        prefs.panel_space_type = 'VIEW_3D'
        prefs.panel_category = "Screencast Key"
        prefs.show_ui_in_sidebar = True
        prefs.show_ui_in_overlay = False
    preferences.SK_Preferences.ui_in_sidebar_update_fn(prefs, context)
    preferences.SK_Preferences.ui_in_overlay_update_fn(prefs, context)

    # Fix: https://github.com/nutti/Screencast-Keys/issues/195
    # TODO: This workaround is hacky. We need to apply a better solution.
    if len(prefs.display_event_text_aliases_props) == 0:
        for event in list(ops.EventType):
            item = prefs.display_event_text_aliases_props.add()
            item.event_id = event.name
            if event in ops.SK_OT_ScreencastKeys.MODIFIER_EVENT_TYPES:
                item.default_text = common.fix_modifier_display_text(
                    ops.EventType.names[event.name]
                )
            else:
                item.default_text = ops.EventType.names[event.name]

    try:
        common.reload_custom_mouse_image(prefs, context)
    # pylint: disable=W0702
    except:     # noqa
        pass


def _unregister_impl():
    context = getattr(bpy, 'context', None)
    success = True
    try:
        ops.SK_OT_ScreencastKeys.stop(None, context)
    except Exception:
        success = False
    for feature in (
        'screencast-load-pre', 'screencast-load-post', 'screencast',
        'screencast-timer', 'screencast-modal', 'screencast-autosave',
        'screencast-origin', 'screencast-origin-modal',
    ):
        try:
            _runtime_ledger.remove_feature_leases(feature, any_generation=False)
        except Exception:
            success = False
    _remove_handler_identity(load_pre_handler, bpy.app.handlers.load_pre)
    _remove_handler_identity(load_post_handler, bpy.app.handlers.load_post)
    prefs = integrated_bridge.get_prefs(context)
    if prefs is not None:
        try:
            preferences.remove_custom_mouse_image(prefs, context)
            if not integrated_bridge.is_integrated_mode():
                prefs.display_event_text_aliases_props.clear()
        except Exception:
            success = False

    unregister_shortcut_key()
    try:
        if utils.bl_class_registry.BlClassRegistry.unregister() is False:
            success = False
    except Exception:
        success = False
    for target, reason in (
        (ui.SK_PT_ScreencastKeys_Overlay, 'SCREENCAST_OVERLAY_CLASS'),
        (ui.SK_PT_ScreencastKeys, 'SCREENCAST_SIDEBAR_CLASS'),
    ):
        if _runtime_ledger.class_recorded_current(target):
            if not _runtime_ledger.unregister_class_exact(
                target,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix=reason,
            ):
                success = False
    try:
        if integrated_bridge.unregister_storage(context) is not True:
            success = False
    except Exception:
        success = False
    if _runtime_ledger.class_recorded_current(preferences.DisplayEventTextAliasProperties):
        if not _runtime_ledger.unregister_class_exact(
            preferences.DisplayEventTextAliasProperties,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCREENCAST_ALIAS_CLASS',
        ):
            success = False
    if not unregister_addon_enable_property():
        success = False
    if not common.is_console_mode():
        try:
            gpu_utils.shader.ShaderManager.unregister_shaders()
        except Exception:
            success = False
    return bool(success)


def register() -> bool:
    global _S1_REGISTERED_GENERATION
    generation = _runtime_ledger.current_generation()
    if not generation or not _runtime_ledger.generation_matches(generation):
        return False
    if _S1_REGISTERED_GENERATION:
        if _S1_REGISTERED_GENERATION == generation:
            return True
        _runtime_ledger.mark_restart_required("SCREENCAST_REGISTER_GENERATION_MISMATCH")
        return False
    _S1_REGISTERED_GENERATION = generation
    try:
        result = _register_impl()
        return result is not False
    except Exception:
        try:
            _unregister_impl()
        except Exception:
            pass
        _S1_REGISTERED_GENERATION = ""
        raise


def unregister() -> bool:
    global _S1_REGISTERED_GENERATION
    generation = str(_S1_REGISTERED_GENERATION or "")
    if not generation:
        return True
    if not _runtime_ledger.generation_matches(generation):
        _runtime_ledger.mark_restart_required("SCREENCAST_UNREGISTER_GENERATION_MISMATCH")
        return False
    result = False
    try:
        result = _unregister_impl()
        if result is not False:
            _S1_REGISTERED_GENERATION = ""
            return True
        return False
    except Exception:
        # Retain the exact generation identity so teardown can be retried; never
        # convert a partial lease/RNA failure into an apparently clean state.
        raise


if __name__ == "__main__":
    register()
