# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Own the input display's controls, saved settings and optional shortcut in Smart Workspace."""
import bpy
from bpy.app.handlers import persistent
from .. import feature_toggle, runtime_ledger
from . import integrated_bridge, language, operators, preferences, ui
from .utils.bl_class_registry import BlClassRegistry

_REGISTERED=False
_owned=[]
_keys=[]
_switch=False

def _always(action):
    from .. import ui_runtime
    return bool(ui_runtime._remembered_always_state(action,False))

def unregister_shortcut_key():
    while _keys:
        km,item=_keys[-1]
        km.keymap_items.remove(item)
        _keys.pop()
    return True

def register_shortcut_key():
    if _keys:return True
    wm=getattr(bpy.context,'window_manager',None)
    config=getattr(getattr(wm,'keyconfigs',None),'addon',None)
    if config is None:return False
    maps=config.keymaps
    km=maps.get('3D View') or maps.new(name='3D View',space_type='VIEW_3D')
    item=km.keymap_items.new('wm.sk_screencast_keys','C','PRESS',shift=True,alt=True)
    _keys.append((km,item))
    return True

@persistent
def load_pre_handler(_):
    operators.SK_OT_ScreencastKeys.stop()

@persistent
def restore_after_load(_):
    p=integrated_bridge.get_prefs()
    if not p:return
    integrated_bridge.load_prefs()
    ui.configure(p)

@persistent
def load_post_handler(_):
    p=integrated_bridge.get_prefs()
    if p and (p.enable_on_startup or _always('screencast_enable_on_startup')):
        bpy.ops.wm.sk_wait_blender_initialized_and_start_screencast_keys()

def _set_load_post_handler_enabled(value):
    handlers=bpy.app.handlers.load_post
    if value and load_post_handler not in handlers:handlers.append(load_post_handler)
    elif not value and load_post_handler in handlers:handlers.remove(load_post_handler)

def _get_enabled(wm):
    return operators.SK_OT_ScreencastKeys.is_running()

def _set_enabled(wm,value):
    if bool(value)==_get_enabled(wm):return
    if value:bpy.ops.wm.sk_wait_blender_initialized_and_start_screencast_keys()
    else:operators.SK_OT_ScreencastKeys.stop()

def _setup_settings():
    for cls in (preferences.DisplayEventTextAliasProperties,preferences.SK_INTEGRATED_PREFERENCES,preferences.SK_Preferences):
        ok,_=runtime_ledger.register_class_exact(cls,native_register=bpy.utils.register_class,native_unregister=bpy.utils.unregister_class,reason_prefix='Workspace input preferences')
        if not ok:raise RuntimeError('Could not register input preferences: '+cls.__name__)
        _owned.append(cls)
    integrated_bridge.register_storage(preferences.SK_INTEGRATED_PREFERENCES)

def _restore():
    if not _REGISTERED:return None
    p=integrated_bridge.get_prefs()
    if not p:return .1
    integrated_bridge.load_prefs()
    ui.configure(p)
    if p.enable_on_startup or _always('screencast_enable_on_startup'):
        _set_load_post_handler_enabled(True)
        bpy.ops.wm.sk_wait_blender_initialized_and_start_screencast_keys()
    if feature_toggle.is_feature_enabled('screencast_keys','keymaps') or _always('screencast_hotkey'):
        register_shortcut_key()
    return None

def register():
    global _REGISTERED,_switch
    if _REGISTERED:return True
    try:
        language.register()
        _setup_settings()
        BlClassRegistry.register()
        if hasattr(bpy.types.WindowManager,'enable_screencast_keys'):
            raise RuntimeError('An input display switch is already registered')
        bpy.types.WindowManager.enable_screencast_keys=bpy.props.BoolProperty(name='Show input',translation_context=language.CONTEXT,get=_get_enabled,set=_set_enabled)
        _switch=True
        if load_pre_handler not in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.append(load_pre_handler)
        if restore_after_load not in bpy.app.handlers.load_post:bpy.app.handlers.load_post.append(restore_after_load)
        _REGISTERED=True
        if integrated_bridge.get_prefs() is None:
            ui.configure(None)
            bpy.app.timers.register(_restore,first_interval=.1)
        else:_restore()
    except Exception:
        unregister()
        raise
    return True

def unregister():
    global _REGISTERED,_switch
    _REGISTERED=False
    if bpy.app.timers.is_registered(_restore):bpy.app.timers.unregister(_restore)
    operators.SK_OT_ScreencastKeys.stop()
    _set_load_post_handler_enabled(False)
    if load_pre_handler in bpy.app.handlers.load_pre:bpy.app.handlers.load_pre.remove(load_pre_handler)
    if restore_after_load in bpy.app.handlers.load_post:bpy.app.handlers.load_post.remove(restore_after_load)
    unregister_shortcut_key()
    ui.unregister()
    if _switch:
        del bpy.types.WindowManager.enable_screencast_keys
        _switch=False
    BlClassRegistry.unregister()
    saved=integrated_bridge.unregister_storage()
    while _owned:
        cls=_owned[-1]
        if not runtime_ledger.unregister_class_exact(cls,native_unregister=bpy.utils.unregister_class,reason_prefix='Workspace input preferences'):
            raise RuntimeError('Could not unregister input preferences: '+cls.__name__)
        _owned.pop()
    language.unregister()
    return saved
