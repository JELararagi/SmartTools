# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Display local input while the recording overlay is enabled in a 3D view."""
from enum import Enum
from types import MappingProxyType
import sys

import bpy

from . import integrated_bridge
from .input_view import ViewInput, view_region
from .independent_input_display.labels import MODIFIER_KEYS
from .independent_input_display.model import Settings
from .overlay_painter import OverlayPainter
from .recovery import Recovery
from .language import CONTEXT
from .utils.bl_class_registry import BlClassRegistry


# Use Blender's registered event names so that optional remapped labels persist.
_event_items = bpy.types.Event.bl_rna.properties['type'].enum_items
EventType = Enum('EventType', {item.identifier: item.value for item in _event_items})
EventType.names = MappingProxyType({item.identifier: item.name for item in _event_items})
_active = None
_pending_start = None
_origin_generation = 0

def _manager_allows_screencast(context):
    endpoint = bpy.app.driver_namespace.get('JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1', {})
    allowed = endpoint.get('public_api', {}).get('placement_allowed')
    return allowed('SMART_WORKSPACE', context) if callable(allowed) else True

def show_mouse_hold_status(prefs):
    return prefs.show_mouse_events and prefs.mouse_events_show_mode in {'HOLD_STATUS','EVENT_HISTORY_AND_HOLD_STATUS'}

def _settings(p):
    aliases = ()
    if p.enable_display_event_text_aliases:
        aliases = tuple({row.event_id:row.alias_text for row in p.display_event_text_aliases_props
                        if row.event_id and row.alias_text}.items())
    return Settings(display_time=p.display_time, max_history=p.max_event_history,
                    repeat_window=p.display_time if p.repeat_count else 0.0,
                    language=bpy.app.translations.locale,
                    mouse_history=p.show_mouse_events and p.mouse_events_show_mode != 'HOLD_STATUS',
                    mouse_hold=show_mouse_hold_status(p), aliases=aliases,
                    platform='MACOS' if sys.platform=='darwin' else 'WINDOWS' if sys.platform=='win32' else 'LINUX')

class DisplayRun:
    def __init__(self, context):
        self.wm = context.window_manager
        self.view = ViewInput(context.window, context.area)
        self.paint = OverlayPainter()
        self.recovery = Recovery()
        self.timer = None
        self.closed = False

    def open(self):
        self.view.attach(self.draw)
        try:
            self.timer = self.wm.event_timer_add(.12, window=self.view.window)
            p = integrated_bridge.get_prefs()
            if p and p.output_debug_log: print("Smart Workspace: input display started")
        except Exception:
            self.close()
            raise

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.timer is not None:
            self.wm.event_timer_remove(self.timer)
            self.timer = None
        self.view.close()
        self.paint.close()
        p=integrated_bridge.get_prefs()
        if p and p.output_debug_log: print("Smart Workspace: input display stopped")

    def draw(self, view):
        c = bpy.context
        if self.closed or c.window != view.window or c.area != view.area or c.region.type != 'WINDOW':
            return
        if not _manager_allows_screencast(c):
            return
        p = integrated_bridge.get_prefs(c)
        if p:
            self.paint.draw(c, view.session.frame, p)

@BlClassRegistry()
class SK_OT_ScreencastKeys(bpy.types.Operator):
    bl_idname = 'wm.sk_screencast_keys'
    bl_label = 'Screencast Keys'
    bl_translation_context=CONTEXT
    bl_description = 'Display the keys and mouse actions used in this 3D view'
    restart: bpy.props.BoolProperty(default=False, options={'HIDDEN','SKIP_SAVE'})
    MODIFIER_EVENT_TYPES = frozenset(v for v in EventType if v.name in MODIFIER_KEYS)
    _run = None

    @classmethod
    def is_running(cls):
        return _active is not None and not _active.closed

    @classmethod
    def stop(cls, self=None, context=None):
        global _active, _pending_start, _origin_generation
        old = _active
        _active = None
        _origin_generation += 1
        if _pending_start is not None and bpy.app.timers.is_registered(_pending_start):
            bpy.app.timers.unregister(_pending_start)
        _pending_start = None
        if old:
            old.close()
        return True

    def invoke(self, context, event):
        global _active
        if _active:
            self.stop()
            if not self.restart:
                return {'FINISHED'}
        if not context.window or not context.area or context.area.type != 'VIEW_3D' or not _manager_allows_screencast(context):
            self.report({'WARNING'}, 'Open a 3D view with Smart Workspace enabled')
            return {'CANCELLED'}
        run = DisplayRun(context)
        run.open()
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            run.close()
            raise
        self._run = _active = run
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if self._run is None or self._run is not _active:
            return {'FINISHED'}
        try:
            available = self._run.view.area in list(self._run.view.window.screen.areas)
        except ReferenceError:
            available = False
        if not available or not _manager_allows_screencast(context):
            self.stop()
            return {'FINISHED'}
        if event.type in {'MOUSEMOVE','INBETWEEN_MOUSEMOVE'}:
            view = view_region(self._run.view.window,event.mouse_x,event.mouse_y)
            if view and view[0] == self._run.view.area:
                self._run.paint.cursor = (event.mouse_x-view[1].x, event.mouse_y-view[1].y)
        prefs=integrated_bridge.get_prefs(context)
        if prefs is None:
            self.stop()
            return {'FINISHED'}
        if event.type=='TIMER':
            self._run.recovery.tick(context,prefs)
        self._run.view.consume(event,_settings(prefs))
        return {'PASS_THROUGH'}

    def cancel(self, context):
        if self._run is not None and self._run is _active:
            self.stop()

@BlClassRegistry()
class SK_OT_SetOrigin(bpy.types.Operator):
    bl_idname = 'wm.sk_set_origin'
    bl_label = 'Screencast Keys Set Origin'
    bl_translation_context=CONTEXT
    bl_description = 'Click in the 3D view to place the input overlay'
    # The host clears these external integration hooks on feature shutdown.
    handlers = {}
    runtime_generation = 0
    draw_snapshots = MappingProxyType({})

    def invoke(self, context, event):
        if not context.window or not context.area or context.area.type != 'VIEW_3D':
            return {'CANCELLED'}
        self._generation = _origin_generation
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC','RIGHTMOUSE'} or self._generation != _origin_generation:
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            view = view_region(context.window,event.mouse_x,event.mouse_y)
            if view is None:
                return {'RUNNING_MODAL'}
            area,region = view
            p = integrated_bridge.get_prefs(context)
            p.origin, p.align = 'REGION', 'LEFT'
            p.offset = (event.mouse_x-region.x,event.mouse_y-region.y)
            area.tag_redraw()
            return {'FINISHED'}
        return {'PASS_THROUGH'}

@BlClassRegistry()
class SK_OT_WaitBlenderInitializedAndStartScreencastKeys(bpy.types.Operator):
    bl_idname='wm.sk_wait_blender_initialized_and_start_screencast_keys'
    bl_label='Start Screencast Keys When a View Is Ready'
    bl_translation_context=CONTEXT
    bl_description='Enable the input display when a 3D view is available'

    def execute(self,context):
        global _pending_start
        if bpy.app.background:
            return {'CANCELLED'}
        if SK_OT_ScreencastKeys.is_running() or _pending_start is not None:
            return {'FINISHED'}
        def start_in_view():
            global _pending_start
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type!='VIEW_3D':
                        continue
                    region = next((r for r in area.regions if r.type=='WINDOW'),None)
                    if region is not None:
                        with bpy.context.temp_override(window=window,area=area,region=region):
                            if not _manager_allows_screencast(bpy.context):
                                continue
                            _pending_start = None
                            bpy.ops.wm.sk_screencast_keys('INVOKE_DEFAULT')
                        return None
            return .5
        _pending_start = start_in_view
        bpy.app.timers.register(start_in_view, first_interval=.1)
        return {'FINISHED'}
