# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import os
import platform
import math
import collections
import enum
import time
from types import MappingProxyType

import blf
import bpy
from .. import storage as _suite_storage
from .. import runtime_ledger as _runtime_ledger
import bpy.props
import gpu
from gpu_extras.batch import batch_for_shader

from . import common
from . import integrated_bridge
from .common import (
    debug_print,
    fix_modifier_display_text,
    output_debug_log
)
from .utils.bl_class_registry import BlClassRegistry
from .utils import compatibility as compat
from .gpu_utils import imm


event_type_enum_items = bpy.types.Event.bl_rna.properties["type"].enum_items
EventType = enum.IntEnum(
    "EventType",
    [(e.identifier, e.value) for e in event_type_enum_items]
)
EventType.names = {e.identifier: e.name for e in event_type_enum_items}

_MANAGER_RUNTIME_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1"


def _safe_tuple_color(value, default):
    try:
        seq = tuple(float(item) for item in value)
        if len(seq) == 4:
            return seq
    except Exception:
        pass
    return tuple(default)


def _viewport_key_from_region(region):
    try:
        return (
            int(getattr(region, "x", 0)),
            int(getattr(region, "y", 0)),
            int(getattr(region, "width", 0)),
            int(getattr(region, "height", 0)),
        )
    except Exception:
        return (0, 0, 0, 0)


def _rna_pointer(value):
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _draw_snapshot_key(space_name, region_type, window, workspace, viewport):
    dimensions = tuple(int(value) for value in viewport)
    return (
        str(space_name),
        str(region_type),
        _rna_pointer(window),
        _rna_pointer(workspace),
        dimensions[-2:] if len(dimensions) >= 2 else dimensions,
    )


def _current_gpu_viewport_key():
    try:
        return tuple(int(value) for value in gpu.state.viewport_get())
    except Exception:
        return ()


def _capture_gpu_state():
    """Capture available GPU state with the exact native setter."""
    captured = []
    specs = (
        ('blend_get', 'blend_set', False),
        ('depth_test_get', 'depth_test_set', False),
        ('depth_mask_get', 'depth_mask_set', False),
        ('face_culling_get', 'face_culling_set', False),
        ('front_facing_get', 'front_facing_set', False),
        ('line_width_get', 'line_width_set', False),
        ('point_size_get', 'point_size_set', False),
        ('scissor_test_get', 'scissor_test_set', False),
        ('scissor_get', 'scissor_set', True),
        ('color_mask_get', 'color_mask_set', True),
    )
    state = getattr(gpu, 'state', None)
    for getter_name, setter_name, unpack in specs:
        getter = getattr(state, getter_name, None)
        setter = getattr(state, setter_name, None)
        if not callable(getter) or not callable(setter):
            continue
        try:
            value = getter()
            args = tuple(value) if unpack and isinstance(value, (tuple, list)) else (value,)
            captured.append((setter, args))
        except Exception:
            continue
    return tuple(captured)


def _restore_gpu_state(captured):
    for setter, args in reversed(tuple(captured or ())):
        try:
            setter(*tuple(args))
        except Exception:
            pass


def _prebuild_rect_batch_command(x1, y1, x2, y2, color):
    """Build immutable GPU geometry outside every draw callback.

    Shader lookup, vertex assembly, index creation and ``batch_for_shader`` are
    deliberately event-side work.  The returned tuple is published only after
    the complete snapshot has been built.
    """
    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        vertices = (
            (float(x1), float(y1)),
            (float(x1), float(y2)),
            (float(x2), float(y2)),
            (float(x2), float(y1)),
        )
        batch = batch_for_shader(
            shader,
            'TRIS',
            {'pos': vertices},
            indices=((0, 1, 2), (0, 2, 3)),
        )
        return ('GPU_BATCH', shader, batch, tuple(float(item) for item in color))
    except Exception:
        return None


def _replay_immutable_commands(generation, commands):
    """Replay prebuilt GPU/BLF commands without RNA or geometry construction."""
    if not _runtime_ledger.generation_matches(str(generation or "")):
        return
    if not isinstance(commands, tuple):
        return
    previous_gpu = _capture_gpu_state()
    try:
        gpu.state.blend_set('ALPHA')
        for command in commands:
            if not isinstance(command, tuple) or not command:
                continue
            kind = command[0]
            if kind == 'GPU_BATCH' and len(command) == 4:
                _kind, shader, batch, color = command
                shader.bind()
                shader.uniform_float('color', tuple(color))
                batch.draw(shader)
            elif kind == 'TEXT' and len(command) == 11:
                (_kind, font_id, font_size, dpi, x, y, text,
                 color, shadow, shadow_color, _reserved) = command
                compat.blf_size(int(font_id), int(font_size), int(dpi))
                blf.position(int(font_id), float(x), float(y), 0.0)
                draw_text(str(text), int(font_id), tuple(color), bool(shadow), tuple(shadow_color))
    finally:
        _restore_gpu_state(previous_gpu)


def _build_immutable_screencast_commands(operator_cls, context, region):
    """Build all text dimensions, alignment, and geometry outside draw."""
    prefs = integrated_bridge.get_prefs(context)
    if prefs is None or region is None:
        return ()
    user_prefs = getattr(context, 'preferences', None)
    system = getattr(user_prefs, 'system', None)
    ui_scale = float(getattr(system, 'ui_scale', 1.0) or 1.0)
    dpi = int(getattr(system, 'dpi', 72) or 72)
    font_id = 0
    font_size = max(1, int(getattr(prefs, 'font_size', 20) or 20))
    compat.blf_size(font_id, font_size, dpi)
    margin = max(0.0, float(getattr(prefs, 'background_rounded_corner_radius', 0.0) or 0.0) * 0.15)
    try:
        offset = tuple(getattr(prefs, 'offset', (20.0, 20.0)))
    except Exception:
        offset = (20.0, 20.0)
    base_x = float(offset[0] if len(offset) > 0 else 20.0) * ui_scale
    base_y = float(offset[1] if len(offset) > 1 else 20.0) * ui_scale
    color = _safe_tuple_color(getattr(prefs, 'color', None), (1.0, 1.0, 1.0, 1.0))
    shadow_color = _safe_tuple_color(getattr(prefs, 'shadow_color', None), (0.0, 0.0, 0.0, 1.0))
    background_color = _safe_tuple_color(getattr(prefs, 'background_color', None), (0.0, 0.0, 0.0, 0.35))
    shadow = bool(getattr(prefs, 'shadow', False))
    background = bool(getattr(prefs, 'background', False)) and str(getattr(prefs, 'background_mode', 'TEXT')) == 'TEXT'
    align = str(getattr(prefs, 'align', 'LEFT') or 'LEFT')
    line_height = max(1.0, float(blf.dimensions(font_id, 'Hy|')[1]) * 1.25)
    lines = []
    try:
        history = operator_cls.removed_old_event_history()
    except Exception:
        history = tuple(operator_cls.event_history)
    max_events = max(0, int(getattr(prefs, 'max_event_history', 5) or 0))
    if max_events:
        history = history[-max_events:]
    for _event_time, event_type, modifiers, repeat_count in reversed(tuple(history)):
        try:
            event_name = getattr(event_type, 'name', str(event_type))
            text = get_display_event_text(event_name)
            if modifiers:
                mod_keys = operator_cls.sorted_modifier_keys(modifiers)
                if mod_keys:
                    text = '{} + {}'.format(' + '.join(mod_keys), text)
            if int(repeat_count) > 1:
                text += ' x{}'.format(int(repeat_count))
            lines.append(text)
        except Exception:
            continue
    try:
        if operator_cls.operator_history:
            label = str(operator_cls.operator_history[-1][1] or '')
            if label:
                lines.append(label)
    except Exception:
        pass
    commands = []
    width = max(0, int(getattr(region, 'width', 0) or 0))
    y = base_y
    for text in lines:
        text_width, text_height = blf.dimensions(font_id, text)
        if align == 'CENTER':
            x = max(0.0, (width - text_width) * 0.5)
        elif align == 'RIGHT':
            x = max(0.0, width - base_x - text_width)
        else:
            x = base_x
        if background:
            correction = float(text_height) * 0.2
            background_command = _prebuild_rect_batch_command(
                x - margin,
                y - correction - margin,
                x + float(text_width) + margin,
                y + float(text_height) - correction + margin,
                background_color,
            )
            if background_command is not None:
                commands.append(background_command)
        commands.append(('TEXT', font_id, font_size, dpi, x, y, text,
                         color, shadow, shadow_color, None))
        y += line_height
    return tuple(commands)


def _remove_draw_handle(handle, space_type, region_type):
    try:
        space_type.draw_handler_remove(handle, region_type)
    except Exception:
        pass


def _remove_event_timer(handle, window_manager):
    try:
        window_manager.event_timer_remove(handle)
    except Exception:
        pass


def _remove_handler_identity(handle, handler_list):
    try:
        while handle in handler_list:
            handler_list.remove(handle)
    except Exception:
        pass


def _cancel_modal_handle(handle):
    try:
        handle._sws_modal_cancelled = True
    except Exception:
        pass


def _manager_allows_screencast(context):
    """Accept OFF only from the active generation's workspace aggregate API."""
    try:
        record = bpy.app.driver_namespace.get(_MANAGER_RUNTIME_KEY)
        if not isinstance(record, dict):
            return True
        if record.get('package_id') != 'smart_tools_manager' or record.get('status') != 'ACTIVE':
            return True
        generation = str(record.get('generation') or '')
        revision = record.get('revision')
        api = record.get('public_api')
        if not generation or not isinstance(revision, int) or not isinstance(api, dict):
            return True
        fn = api.get('workspace_tool_allowed')
        if not callable(fn):
            return True
        value = fn('SMART_WORKSPACE', context)
        current = bpy.app.driver_namespace.get(_MANAGER_RUNTIME_KEY)
        if current is not record:
            return True
        if current.get('package_id') != 'smart_tools_manager' or current.get('status') != 'ACTIVE':
            return True
        if str(current.get('generation') or '') != generation or current.get('revision') != revision:
            return True
        if current.get('public_api') is not api or api.get('workspace_tool_allowed') is not fn:
            return True
        return value if isinstance(value, bool) else True
    except Exception:
        return True


def _origin_area_alive(operator_cls, context):
    del context
    window = getattr(operator_cls, 'origin_window_ref', None)
    screen = getattr(operator_cls, 'origin_screen_ref', None)
    area = getattr(operator_cls, 'origin_area_ref', None)
    if window is None or screen is None or area is None:
        return False
    try:
        if _rna_pointer(getattr(window, 'screen', None)) != _rna_pointer(screen):
            return False
        target = _rna_pointer(area)
        return bool(
            target
            and any(_rna_pointer(item) == target for item in tuple(screen.areas))
        )
    except Exception:
        return False


def draw_default_mouse(x, y, w, h, left_button_status,
                       right_button_status, middle_button_status,
                       color, round_radius, fill=False, fill_color=None,
                       line_thickness=1):
    mouse_body = [x, y, w, h / 2]
    left_mouse_button = [x, y + h / 2, w / 3, h / 2]
    middle_mouse_button = [x + w / 3, y + h / 2, w / 3, h / 2]
    right_mouse_button = [x + 2 * w / 3, y + h / 2, w / 3, h / 2]

    # Mouse body.
    if fill:
        draw_rounded_box(mouse_body[0], mouse_body[1],
                         mouse_body[2], mouse_body[3],
                         round_radius,
                         fill=True, color=fill_color,
                         round_corner=[True, True, False, False],
                         line_thickness=line_thickness)
    draw_rounded_box(mouse_body[0], mouse_body[1],
                     mouse_body[2], mouse_body[3],
                     round_radius,
                     fill=False, color=color,
                     round_corner=[True, True, False, False],
                     line_thickness=line_thickness)

    # Left button.
    if fill:
        draw_rounded_box(
            left_mouse_button[0], left_mouse_button[1],
            left_mouse_button[2], left_mouse_button[3],
            round_radius / 2,
            fill=True, color=fill_color,
            round_corner=[False, False, False, True],
            line_thickness=line_thickness)
    draw_rounded_box(
        left_mouse_button[0], left_mouse_button[1],
        left_mouse_button[2], left_mouse_button[3],
        round_radius / 2,
        fill=False, color=color,
        round_corner=[False, False, False, True],
        line_thickness=line_thickness)
    if left_button_status in ('PRESS', 'CLICK_DRAG'):
        draw_rounded_box(
            left_mouse_button[0], left_mouse_button[1],
            left_mouse_button[2], left_mouse_button[3],
            round_radius / 2,
            fill=True, color=color,
            round_corner=[False, False, False, True],
            line_thickness=line_thickness)

    # Middle button.
    if fill:
        draw_rounded_box(
            middle_mouse_button[0], middle_mouse_button[1],
            middle_mouse_button[2], middle_mouse_button[3],
            round_radius / 2,
            fill=True, color=fill_color,
            round_corner=[False, False, False, False],
            line_thickness=line_thickness)
    draw_rounded_box(
        middle_mouse_button[0], middle_mouse_button[1],
        middle_mouse_button[2], middle_mouse_button[3],
        round_radius / 2,
        fill=False, color=color,
        round_corner=[False, False, False, False],
        line_thickness=line_thickness)
    if middle_button_status in ('PRESS', 'CLICK_DRAG'):
        draw_rounded_box(
            middle_mouse_button[0], middle_mouse_button[1],
            middle_mouse_button[2], middle_mouse_button[3],
            round_radius / 2,
            fill=True, color=color,
            round_corner=[False, False, False, False],
            line_thickness=line_thickness)

    # Right button.
    if fill:
        draw_rounded_box(
            right_mouse_button[0], right_mouse_button[1],
            right_mouse_button[2], right_mouse_button[3],
            round_radius / 2,
            fill=True, color=fill_color,
            round_corner=[False, False, True, False],
            line_thickness=line_thickness)
    draw_rounded_box(
        right_mouse_button[0], right_mouse_button[1],
        right_mouse_button[2], right_mouse_button[3],
        round_radius / 2,
        fill=False, color=color,
        round_corner=[False, False, True, False],
        line_thickness=line_thickness)
    if right_button_status in ('PRESS', 'CLICK_DRAG'):
        draw_rounded_box(
            right_mouse_button[0], right_mouse_button[1],
            right_mouse_button[2], right_mouse_button[3],
            round_radius / 2,
            fill=True, color=color,
            round_corner=[False, False, True, False],
            line_thickness=line_thickness)


def draw_custom_mouse(x, y, w, h, left_button_status,
                      right_button_status, middle_button_status,
                      display_mode,
                      image_name_base, image_name_lmouse,
                      image_name_rmouse, image_name_mmouse):
    def draw_image(img, positions, tex_coords):
        gpu_img = gpu.texture.from_image(img)
        original_state = gpu.state.blend_get()
        gpu.state.blend_set('ALPHA')

        imm.immSetTexture(gpu_img)
        imm.immBegin(imm.GL_QUADS)
        imm.immColor4f(1.0, 1.0, 1.0, 1.0)
        for (v1, v2), (u, v) in zip(positions, tex_coords):
            imm.immTexCoord2f(u, v)
            imm.immVertex2f(v1, v2)
        imm.immEnd()
        imm.immSetTexture(None)

        gpu.state.blend_set(original_state)

    def pressed(button_status):
        return button_status in ('PRESS', 'CLICK_DRAG')

    positions = [
        [x, y],
        [x, y + h],
        [x + w, y + h],
        [x + w, y],
    ]
    tex_coords = [
        [0.0, 0.0],
        [0.0, 1.0],
        [1.0, 1.0],
        [1.0, 0.0],
    ]

    common.ensure_custom_mouse_images()

    if display_mode == 'OVERLAY':
        if image_name_base in bpy.data.images:
            draw_image(bpy.data.images[image_name_base], positions, tex_coords)
        if pressed(left_button_status) and \
                (image_name_lmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_lmouse], positions,
                       tex_coords)
        if pressed(right_button_status) and \
                (image_name_rmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_rmouse], positions,
                       tex_coords)
        if pressed(middle_button_status) and \
                (image_name_mmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_mmouse], positions,
                       tex_coords)
    elif display_mode == 'NORMAL':
        if pressed(left_button_status) and \
                (image_name_lmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_lmouse], positions,
                       tex_coords)
        elif pressed(right_button_status) and \
                (image_name_rmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_rmouse], positions,
                       tex_coords)
        elif pressed(middle_button_status) and \
                (image_name_mmouse in bpy.data.images):
            draw_image(bpy.data.images[image_name_mmouse], positions,
                       tex_coords)
        elif image_name_base in bpy.data.images:
            draw_image(bpy.data.images[image_name_base], positions, tex_coords)


def draw_rounded_box(x, y, w, h, round_radius, fill=False,
                     color=None, round_corner=None, line_thickness=1):
    """round_corner: [Right Bottom, Left Bottom, Right Top, Left Top]"""

    if color is None:
        color = [1.0, 1.0, 1.0, 1.0]
    if round_corner is None:
        round_corner = [True, True, True, True]

    def circle_verts_num(r):
        """Get number of verticies for circle optimized for drawing."""

        num_verts = 32
        threshold = 2.0  # pixcel
        while True:
            if r * 2 * math.pi / num_verts > threshold:
                return num_verts
            num_verts -= 4
            if num_verts < 1:
                return 1

    num_verts = circle_verts_num(round_radius)
    n = int(num_verts / 4) + 1
    dangle = math.pi * 2 / num_verts

    radius = [round_radius if rc else 0 for rc in round_corner]

    x_origin = [
        x + radius[0],
        x + w - radius[1],
        x + w - radius[2],
        x + radius[3],
    ]
    y_origin = [
        y + radius[0],
        y + radius[1],
        y + h - radius[2],
        y + h - radius[3],
    ]
    angle_start = [
        math.pi * 1.0,
        math.pi * 1.5,
        math.pi * 0.0,
        math.pi * 0.5,
    ]

    original_state = gpu.state.blend_get()
    gpu.state.blend_set('ALPHA')
    imm.immColor4f(*color)
    imm.immLineWidth(line_thickness)

    if fill:
        imm.immBegin(imm.GL_TRIANGLE_FAN)
    else:
        imm.immBegin(imm.GL_LINE_LOOP)
    for x0, y0, angle, r in zip(x_origin, y_origin, angle_start, radius):
        for _ in range(n):
            x = x0 + r * math.cos(angle)
            y = y0 + r * math.sin(angle)
            if not fill:
                imm.immVertex3f(x, y, 0)
            else:
                imm.immVertex2f(x, y)
            angle += dangle
    imm.immEnd()

    imm.immLineWidth(1.0)
    imm.immColor4f(1.0, 1.0, 1.0, 1.0)
    gpu.state.blend_set(original_state)


def draw_rect(x1, y1, x2, y2, color):
    imm.immColor4f(*color)

    imm.immBegin(imm.GL_QUADS)
    imm.immVertex2f(x1, y1)
    imm.immVertex2f(x1, y2)
    imm.immVertex2f(x2, y2)
    imm.immVertex2f(x2, y1)
    imm.immEnd()

    imm.immColor4f(1.0, 1.0, 1.0, 1.0)


def draw_text_background(text, font_id, x, y, background_color,
                         margin=0, round_radius=0):
    width = blf.dimensions(font_id, text)[0]
    height = blf.dimensions(font_id, "Hy|")[1]
    correction = height * 0.2

    if round_radius == 0:
        draw_rect(x - margin, y - correction - margin,
                  x + width + margin, y + height - correction + margin,
                  background_color)
    else:
        draw_rounded_box(x - margin, y - correction - margin,
                         width + margin * 2, height + margin * 2,
                         round_radius, True, background_color)


def draw_text(text, font_id, color, shadow=False, shadow_color=None):
    blf.enable(font_id, blf.SHADOW)

    # Draw shadow.
    if shadow:
        blf.shadow_offset(font_id, 3, -3)
        blf.shadow(font_id, 5, *shadow_color)

    # Draw text.
    blf.color(font_id, *color)
    blf.draw(font_id, text)

    blf.disable(font_id, blf.SHADOW)


def draw_line(p1, p2, color, shadow=False, shadow_color=None,
              line_thickness=1):
    # Draw shadow.
    if shadow:
        imm.immLineWidth(line_thickness + 3.0)
        imm.immColor4f(*shadow_color)
        imm.immBegin(imm.GL_LINES)
        imm.immVertex3f(p1[0], p1[1], 0.0)
        imm.immVertex3f(p2[0], p2[1], 0.0)
        imm.immEnd()

    # Draw line.
    imm.immLineWidth(line_thickness + 2.0 if shadow else line_thickness)
    imm.immColor4f(*color)

    imm.immBegin(imm.GL_LINES)
    imm.immVertex3f(p1[0], p1[1], 0.0)
    imm.immVertex3f(p2[0], p2[1], 0.0)
    imm.immEnd()

    imm.immLineWidth(1.0)
    imm.immColor4f(1.0, 1.0, 1.0, 1.0)


def intersect_aabb(min1, max1, min2, max2):
    """Check intersection using AABB method."""

    for mi1, ma1, mi2, ma2 in zip(min1, max1, min2, max2):
        if (ma1 < mi2) or (ma2 < mi1):
            return False

    return True


def get_window_region_rect(area):
    """Return 'WINDOW' region rectangle."""

    rect = [99999, 99999, 0, 0]
    for region in area.regions:
        if region.type == 'WINDOW':
            rect[0] = min(rect[0], region.x)
            rect[1] = min(rect[1], region.y)
            rect[2] = max(region.x + region.width - 1, rect[2])
            rect[3] = max(region.y + region.height - 1, rect[3])

    return rect


def get_region_rect_on_v3d(context, area=None, region=None):
    """On VIEW_3D, we need to handle region overlap.
       This function takes into accout this, and return rectangle.
    """

    if not area:
        area = context.area
    if not region:
        region = context.region

    # We don't need to handle non-'WINDOW' region which is not effected by
    # region overlap. So we can return region rectangle as it is.
    if region.type != 'WINDOW':
        return [region.x, region.y,
                region.x + region.width, region.y + region.height]

    # From here, we handle 'WINDOW' region with considering region overlap.
    window = region
    tools = ui = None
    for ar in area.regions:
        # We need to dicard regions whose width is 1.
        if ar.width > 1:
            if ar.type == 'WINDOW':
                if ar == window:
                    window = ar
            elif ar.type == 'TOOLS':
                tools = ar
            elif ar.type == 'UI':
                ui = ar

    xmin, _, xmax, _ = get_window_region_rect(area)
    sys_pref = context.preferences.system
    if sys_pref.use_region_overlap:
        left_width = right_width = 0

        if tools and ui:
            r1, r2 = sorted([tools, ui], key=lambda ar: ar.x)
            if r1.x == area.x:
                # 'TOOLS' and 'UI' are located on left side.
                if r2.x == r1.x + r1.width:
                    left_width = r1.width + r2.width
                # 'TOOLS' and 'UI' are located on each side.
                else:
                    left_width = r1.width
                    right_width = r2.width
            # 'TOOLS' and 'UI' are located on right side.
            else:
                right_width = r1.width + r2.width

        elif tools:
            # 'TOOLS' is located on left side.
            if tools.x == area.x:
                left_width = tools.width
            # 'TOOLS' is located on right side.
            else:
                right_width = tools.width

        elif ui:
            # 'UI' is located on left side.
            if ui.x == area.x:
                left_width = ui.width
            # 'TOOLS' is located on right side.
            else:
                right_width = ui.width

        # Clip 'UI' and 'TOOLS' region from 'WINDOW' region, which enables us
        # to show only 'WINDOW' region.
        xmin = max(xmin, area.x + left_width)
        xmax = min(xmax, area.x + area.width - right_width - 1)

    ymin = window.y
    ymax = window.y + window.height - 1

    return xmin, ymin, xmax, ymax


def get_display_event_text(event_id):
    user_prefs = bpy.context.preferences
    prefs = integrated_bridge.get_prefs(bpy.context)

    if not prefs.enable_display_event_text_aliases:
        if EventType[event_id] in SK_OT_ScreencastKeys.MODIFIER_EVENT_TYPES:
            return fix_modifier_display_text(EventType.names[event_id])
        else:
            return EventType.names[event_id]

    for prop in prefs.display_event_text_aliases_props:
        if prop.event_id == event_id:
            if prop.alias_text == "":
                return prop.default_text
            else:
                return prop.alias_text

    return "UNKNOWN"


def show_mouse_hold_status(prefs):
    if not prefs.show_mouse_events:
        return False
    return prefs.mouse_events_show_mode in ['HOLD_STATUS',
                                            'EVENT_HISTORY_AND_HOLD_STATUS']


def show_mouse_event_history(prefs):
    if not prefs.show_mouse_events:
        return False
    return prefs.mouse_events_show_mode in ['EVENT_HISTORY',
                                            'EVENT_HISTORY_AND_HOLD_STATUS']


def show_text_background(prefs):
    if not prefs.background:
        return False
    return prefs.background_mode == 'TEXT'


def show_draw_area_background(prefs):
    if not prefs.background:
        return False
    return prefs.background_mode == 'DRAW_AREA'


@BlClassRegistry()
class SK_OT_ScreencastKeys(bpy.types.Operator):
    # pylint: disable=R0904
    bl_idname = "wm.sk_screencast_keys"
    bl_label = "Screencast Keys"
    bl_description = "Display keys pressed"
    bl_options = {'MODAL_PRIORITY'}
    _sms_no_undo = True

    # Last save time by auto save.
    last_auto_saved_time = 0
    # Flag for exclusive execution of auto save.
    auto_saving = False

    # Hold modifier keys.
    hold_modifier_keys = []
    # Hold mouse buttons.
    mouse_buttons_status = {
        'LEFTMOUSE': 'RELEASE',    # One of ['RELEASE', 'PRESS', 'CLICK_DRAG']
        'RIGHTMOUSE': 'RELEASE',
        'MIDDLEMOUSE': 'RELEASE',
    }
    # Hold keys (Used for internal state management).
    # This data is updated by using 'PRESS' and 'RELEASE' events.
    keys_status_internal = {
        'LEFT_ALT': 'RELEASE',
        'RIGHT_ALT': 'RELEASE',
    }

    # Event history.
    # Format: [time, event_type, modifiers, repeat_count]
    event_history = []
    # Operator history.
    # Format: [time, bl_label, idname_py, addr]
    operator_history = []

    MODIFIER_EVENT_TYPES = [
        EventType.LEFT_SHIFT,
        EventType.RIGHT_SHIFT,
        EventType.LEFT_CTRL,
        EventType.RIGHT_CTRL,
        EventType.LEFT_ALT,
        EventType.RIGHT_ALT,
        EventType.OSKEY
    ]

    MOUSE_EVENT_TYPES = {
        EventType.LEFTMOUSE,
        EventType.MIDDLEMOUSE,
        EventType.RIGHTMOUSE,
        EventType.BUTTON4MOUSE,
        EventType.BUTTON5MOUSE,
        EventType.BUTTON6MOUSE,
        EventType.BUTTON7MOUSE,
        EventType.TRACKPADPAN,
        EventType.TRACKPADZOOM,
        EventType.MOUSEROTATE,
        EventType.WHEELUPMOUSE,
        EventType.WHEELDOWNMOUSE,
        EventType.WHEELINMOUSE,
        EventType.WHEELOUTMOUSE,
    }

    SPACE_TYPES = compat.get_all_space_types()

    # Height ratio for separator (against text height).
    HEIGHT_RATIO_FOR_SEPARATOR = 0.6

    # Height ratio for hold mouse status (against width).
    HEIGHT_RATIO_FOR_MOUSE_HOLD_STATUS = 1.3

    # Margin ratio for hold modifier keys box (against text height).
    MARGIN_RATIO_FOR_MODIFIER_KEYS_BOX = 0.2

    # Width ratio for separator between hold mouse status and
    # hold modifier keys (against mouse width).
    WIDTH_RATIO_FOR_SEPARATOR = 0.4

    # Draw area margin.
    DRAW_AREA_MARGIN_LEFT = 15
    DRAW_AREA_MARGIN_RIGHT = 15
    DRAW_AREA_MARGIN_TOP = 15
    DRAW_AREA_MARGIN_BOTTOM = 15

    # Interval for 'TIMER' event (redraw).
    TIMER_STEP = 0.1

    # Maximum interval for ignoring same event.
    INTERVAL_FOR_IGNORE_EVENT = 0.05

    # Previous redraw time.
    prev_time = 0.0

    # Timer handlers.
    # Format: {Window.as_pointer(): Timer}
    timers = {}

    # Draw handlers.
    # Format: {(Space, Region.type): handle}
    handlers = {}

    # Regions which are drawing in previous redraw.
    # Format: {Region.as_pointer()}
    draw_regions_prev = set()

    # Draw target.
    origin = {
        "window": "",       # Window.as_pointer()
        "area": "",         # Area.as_pointer()
        "space": "",        # Space.as_pointer()
        "region_type": "",  # Region.type
    }

    # Area - Space mapping.
    # Format: {Area.as_pointer(), [Space.as_pointer(), ...]}
    # TODO: Clear when this model is finished.
    area_spaces = collections.defaultdict(set)

    # Check if this operator is running.
    # TODO: We can check it with the valid of event handler.
    running = False
    runtime_generation = ""
    active_modal = None
    # Mutable outer index with independently immutable per-window buckets.
    # One bucket replacement is atomic on Blender's main thread; draw callbacks
    # perform two O(1) lookups and never observe a partially built bucket.
    draw_snapshots = {}
    runtime_windows = {}
    runtime_window_workspaces = {}
    runtime_workspace_windows = {}
    origin_window_ref = None
    origin_screen_ref = None
    origin_area_ref = None
    _sws_modal_cancelled = False

    # Should screencast be restarted
    restart: bpy.props.BoolProperty(
        default=False
    )

    # Current mouse coordinate.
    current_mouse_co = [0.0, 0.0]

    @classmethod
    def is_running(cls):
        return cls.running

    @classmethod
    def is_modifier_event(cls, event):
        """Return True if event came from modifier key."""

        event_type = EventType[event.type]
        return event_type in cls.MODIFIER_EVENT_TYPES

    @classmethod
    def sorted_modifier_keys(cls, modifiers):
        """Sort and unique modifier keys."""

        def key_fn(event_type):
            if event_type in cls.MODIFIER_EVENT_TYPES:
                return cls.MODIFIER_EVENT_TYPES.index(event_type)
            else:
                return 100

        modifiers = sorted(modifiers, key=key_fn)
        names = []
        for mod in modifiers:
            name = get_display_event_text(mod.name)
            assert mod in cls.MODIFIER_EVENT_TYPES, \
                "{} must be modifier types".format(name)

            # Unique.
            if name not in names:
                names.append(name)

        return names

    @classmethod
    def removed_old_event_history(cls):
        """Return event history whose old events are removed."""

        user_prefs = bpy.context.preferences
        prefs = integrated_bridge.get_prefs(bpy.context)
        current_time = time.time()

        event_history = []
        for item in cls.event_history:
            event_time = item[0]
            t = current_time - event_time
            if t <= prefs.display_time:
                event_history.append(item)

        if len(event_history) >= prefs.max_event_history:
            event_history = event_history[-prefs.max_event_history:]

        return event_history

    @classmethod
    def removed_old_operator_history(cls):
        """Return operator history whose old operators are removed."""
        # TODO: Control number of history from Preferences.

        return cls.operator_history[-32:]

    @classmethod
    def get_alignment_offset(cls, context, width, margin=0):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)

        dw, _ = cls.draw_area_size(context)
        dw -= cls.DRAW_AREA_MARGIN_LEFT + cls.DRAW_AREA_MARGIN_RIGHT

        offset_x = cls.DRAW_AREA_MARGIN_LEFT
        offset_y = cls.DRAW_AREA_MARGIN_BOTTOM + margin
        if prefs.align == 'LEFT':
            offset_x += margin
        elif prefs.align == 'CENTER':
            offset_x += (dw - width) / 2.0 + margin
        elif prefs.align == 'RIGHT':
            offset_x += dw - width + margin

        return offset_x, offset_y

    @classmethod
    def get_text_offset_for_alignment(cls, context, font_id, text, margin=0):
        tw = blf.dimensions(font_id, text)[0]

        return cls.get_alignment_offset(context, tw, margin)

    @classmethod
    def get_origin(cls, context):
        """Get draw target.
           Retrun value: (Window, Area, Region, x, y)
        """

        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        offset = [prefs.offset[0] * ui_scale, prefs.offset[1] * ui_scale]

        def is_window_match(window):
            return window.as_pointer() == cls.origin["window"]

        def is_area_match(area):
            if area.as_pointer() == cls.origin["area"]:
                # Area is just same as user specified area.
                return True
            elif area.spaces.active.as_pointer() == cls.origin["space"]:
                # Area is not same, but active space information is same.
                return True
            else:
                area_p = area.as_pointer()
                if area_p in cls.area_spaces:
                    spaces_p = {s.as_pointer() for s in area.spaces}
                    if cls.origin["space"] in spaces_p:
                        # Exists in inactive space information.
                        return True
            return False

        def is_region_match(region):
            return region.type == cls.origin["region_type"]

        window = None
        for window in context.window_manager.windows:
            if is_window_match(window):
                break
        else:
            return None, None, None, 0, 0

        # Calculate draw offset
        draw_area_width, draw_area_height = cls.draw_area_size(context)
        if prefs.align == 'LEFT':
            x, y = offset
            if prefs.origin == 'CURSOR':
                x += cls.current_mouse_co[0] - draw_area_width / 2
                y += cls.current_mouse_co[1] - draw_area_height
        elif prefs.align == 'CENTER':
            x, y = offset
            if prefs.origin == 'WINDOW':
                x += (window.width - draw_area_width) / 2
            elif prefs.origin == 'AREA':
                for area in window.screen.areas:
                    if is_area_match(area):
                        x += (area.width - draw_area_width) / 2
                        break
            elif prefs.origin == 'REGION':
                found = False
                for area in window.screen.areas:
                    if found:
                        break
                    if not is_area_match(area):
                        continue
                    for region in area.regions:
                        if not is_region_match(region):
                            continue
                        if area.type == 'VIEW_3D':
                            rect = get_region_rect_on_v3d(
                                context, area, region)
                            x += (rect[2] - rect[0] - draw_area_width) / 2
                        else:
                            x += (region.width - draw_area_width) / 2
                        found = True
                        break
            elif prefs.origin == 'CURSOR':
                x += cls.current_mouse_co[0] - draw_area_width / 2
                y += cls.current_mouse_co[1] - draw_area_height
        elif prefs.align == 'RIGHT':
            x, y = offset
            if prefs.origin == 'WINDOW':
                x += window.width - draw_area_width
            elif prefs.origin == 'AREA':
                for area in window.screen.areas:
                    if is_area_match(area):
                        x += area.width - draw_area_width
                        break
            elif prefs.origin == 'REGION':
                found = False
                for area in window.screen.areas:
                    if found:
                        break
                    if not is_area_match(area):
                        continue
                    for region in area.regions:
                        if not is_region_match(region):
                            continue
                        if area.type == 'VIEW_3D':
                            rect = get_region_rect_on_v3d(
                                context, area, region)
                            x += rect[2] - rect[0] - draw_area_width
                        else:
                            x += region.width - draw_area_width
                        found = True
                        break
            elif prefs.origin == 'CURSOR':
                x += cls.current_mouse_co[0] - draw_area_width / 2
                y += cls.current_mouse_co[1] - draw_area_height

        if prefs.origin in ('WINDOW', 'CURSOR'):
            return window, None, None, x, y
        elif prefs.origin == 'AREA':
            for area in window.screen.areas:
                if is_area_match(area):
                    return window, area, None, x + area.x, y + area.y
        elif prefs.origin == 'REGION':
            for area in window.screen.areas:
                if not is_area_match(area):
                    continue
                for region in area.regions:
                    if is_region_match(region):
                        if area.type == 'VIEW_3D':
                            rect = get_region_rect_on_v3d(
                                context, area, region)
                            x += rect[0]
                            y += rect[1]
                        else:
                            x += region.x
                            y += region.y
                        return window, area, region, x, y

        return None, None, None, 0, 0

    @classmethod
    def text_area_width(cls, text, font_id):
        return blf.dimensions(font_id, text)[0]

    @classmethod
    def text_area_height(cls, font_id):
        return blf.dimensions(font_id, "Hy|")[1]

    @classmethod
    def _area_size_last_operator_layer(cls, context, font_id):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        margin = prefs.margin * ui_scale

        if not prefs.show_last_operator:
            return 0, 0

        sh = cls.text_area_height(font_id) + margin * 2
        layer_height = sh + sh * cls.HEIGHT_RATIO_FOR_SEPARATOR

        operator_history = cls.removed_old_operator_history()
        if not operator_history:
            return 0, layer_height

        current_time = time.time()
        time_, bl_label, idname_py, _ = operator_history[-1]
        if current_time - time_ > prefs.display_time:
            return 0, layer_height

        operator_text = ""
        if prefs.last_operator_show_mode == 'LABEL':
            operator_text += bpy.app.translations.pgettext_iface(
                bl_label, "Operator")
        elif prefs.last_operator_show_mode == 'IDNAME':
            operator_text += "{}".format(idname_py)
        elif prefs.last_operator_show_mode == 'LABEL_AND_IDNAME':
            operator_text += bpy.app.translations.pgettext_iface(
                bl_label, "Operator")
            operator_text += " ('{}')".format(idname_py)

        layer_width = cls.text_area_width(operator_text, font_id) \
            + margin * 2

        return layer_width, layer_height

    @classmethod
    def _area_size_mouse_and_modifier_keys_layer(cls, context, font_id):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        margin = prefs.margin * ui_scale

        drawing = False  # TODO: Need to check if drawing is now on progress.
        modifier_keys_box_margin = cls.text_area_height(font_id) * \
            cls.MARGIN_RATIO_FOR_MODIFIER_KEYS_BOX

        # Setup hold modifier keys text
        modifier_keys_text = ""
        if cls.hold_modifier_keys or drawing:
            mod_keys = cls.sorted_modifier_keys(cls.hold_modifier_keys)
            if drawing:
                modifier_keys_text = ""
            else:
                modifier_keys_text = " + ".join(mod_keys)

        mouse_width = 0.0
        mouse_height = 0.0
        hold_modifier_keys_width = 0.0
        hold_modifier_keys_height = 0.0
        separator_width = 0.0
        if show_mouse_hold_status(prefs):
            if prefs.use_custom_mouse_image:
                mouse_width = prefs.custom_mouse_size[0]
                mouse_height = prefs.custom_mouse_size[1]
            else:
                mouse_width = prefs.mouse_size
                mouse_height = \
                    prefs.mouse_size * cls.HEIGHT_RATIO_FOR_MOUSE_HOLD_STATUS
            mouse_width *= ui_scale
            mouse_height *= ui_scale
        if cls.hold_modifier_keys:
            hold_modifier_keys_width = \
                cls.text_area_width(modifier_keys_text, font_id) \
                + modifier_keys_box_margin * 2
            hold_modifier_keys_height = \
                cls.text_area_height(font_id) + modifier_keys_box_margin * 2

        if prefs.align == 'CENTER':
            hold_modifier_keys_width = max(
                hold_modifier_keys_width, prefs.font_size * 8)
            separator_width = \
                mouse_width * cls.WIDTH_RATIO_FOR_SEPARATOR * ui_scale + margin
        if show_mouse_hold_status(prefs) and cls.hold_modifier_keys:
            separator_width = \
                mouse_width * cls.WIDTH_RATIO_FOR_SEPARATOR * ui_scale + margin

        layer_width = mouse_width + separator_width + \
            hold_modifier_keys_width + margin * 2
        layer_height = \
            max(mouse_height, hold_modifier_keys_height) + margin * 2

        return layer_width, layer_height

    @classmethod
    def _area_size_event_history_layer(cls, context, font_id):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        margin = prefs.margin * ui_scale

        sh = cls.text_area_height(font_id) + margin * 2

        layer_width = 0.0
        layer_height = 0.0

        event_history = cls.removed_old_event_history()
        if event_history:
            layer_height += cls.text_area_height(font_id) * \
                cls.HEIGHT_RATIO_FOR_SEPARATOR
        for _, event_type, modifiers, repeat_count in event_history[::-1]:
            text = get_display_event_text(event_type.name)
            if modifiers:
                mod_keys = cls.sorted_modifier_keys(modifiers)
                text = "{} + {}".format(" + ".join(mod_keys), text)
            if repeat_count > 1:
                text += " x{}".format(repeat_count)

            text_width = cls.text_area_width(text, font_id) + margin * 2
            layer_width = max(text_width, layer_width)
            layer_height += sh

        return layer_width, layer_height

    @classmethod
    def skip_draw(cls, context):
        """Return True if no contents will be displayed."""
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)

        if prefs.show_last_operator:
            operator_history = cls.removed_old_operator_history()
            if operator_history:
                time_, _, _, _ = operator_history[-1]
                current_time = time.time()
                if current_time - time_ <= prefs.display_time:
                    return False

        if show_mouse_hold_status(prefs):
            return False

        if cls.hold_modifier_keys:
            return False

        event_history = cls.removed_old_event_history()
        if event_history:
            return False

        return True

    @classmethod
    def draw_area_baseline(cls, context):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        margin = prefs.margin * ui_scale

        if not prefs.show_last_operator:
            return 0, 0

        font_id = 0         # TODO: font_id should be constant.
        sh = cls.text_area_height(font_id) + margin * 2
        offset_y = sh + sh * cls.HEIGHT_RATIO_FOR_SEPARATOR

        operator_history = cls.removed_old_operator_history()
        if not operator_history:
            return 0, offset_y

        current_time = time.time()
        time_, _, _, _ = operator_history[-1]
        if current_time - time_ > prefs.display_time:
            return 0, offset_y

        return 0, 0

    @classmethod
    def draw_area_size(cls, context):
        """Return draw area size.

        Draw format:

            Overview:
                ....
                Event history[-3]
                Event history[-2]
                Event history[-1]

                Mouse hold status  Hold modifier key list
                ----------------
                Operator history

            Event history format:
                With count: {key} x{count}
                With modifier key: {modifier key} + {key}

            Hold modifier key list format:
                 --------------     --------------
                |{modifier key}| + |{modifier key}|
                 --------------     --------------
        """

        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)

        font_size = prefs.font_size
        font_id = 0         # TODO: font_id should be constant.
        dpi = user_prefs.system.dpi
        compat.blf_size(font_id, font_size, dpi)

        # Calculate width/height of draw area.
        draw_area_width = 0
        draw_area_height = 0

        # Last operator.
        w, h = cls._area_size_last_operator_layer(context, font_id)
        draw_area_width = max(w, draw_area_width)
        draw_area_height += h

        # Hold mouse status / Hold modifier keys.
        w, h = cls._area_size_mouse_and_modifier_keys_layer(context, font_id)
        draw_area_width = max(w, draw_area_width)
        draw_area_height += h

        # Event history.
        w, h = cls._area_size_event_history_layer(context, font_id)
        draw_area_width = max(w, draw_area_width)
        draw_area_height += h

        # Add margin.
        draw_area_width += \
            cls.DRAW_AREA_MARGIN_LEFT + cls.DRAW_AREA_MARGIN_RIGHT
        draw_area_height += \
            cls.DRAW_AREA_MARGIN_TOP + cls.DRAW_AREA_MARGIN_BOTTOM

        return draw_area_width, draw_area_height

    @classmethod
    def draw_area_rect(cls, context):
        """Return draw area rectangle."""

        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)

        # Get draw target.
        window, area, region, x, y = cls.get_origin(context)
        if not window:
            return None

        # Calculate width/height of draw area.
        draw_area_width, draw_area_height = cls.draw_area_size(context)

        if prefs.origin in ('WINDOW', 'CURSOR'):
            return (x,
                    y,
                    x + draw_area_width,
                    y + draw_area_height)
        elif prefs.origin == 'AREA':
            xmin = area.x
            ymin = area.y
            xmax = area.x + area.width - 1
            ymax = area.y + area.height - 1
            return (max(x, xmin),
                    max(y, ymin),
                    min(x + draw_area_width, xmax),
                    min(y + draw_area_height, ymax))
        elif prefs.origin == 'REGION':
            xmin = region.x
            ymin = region.y
            xmax = region.x + region.width - 1
            ymax = region.y + region.height - 1
            return (max(x, xmin),
                    max(y, ymin),
                    min(x + draw_area_width, xmax),
                    min(y + draw_area_height, ymax))

        assert False, "Invalid 'prefs.origin' (value={}).".format(prefs.origin)
        return None

    @classmethod
    def find_redraw_regions(cls, context):
        """Find regions to redraw."""

        rect = cls.draw_area_rect(context)
        if not rect:
            return []       # No draw target.

        draw_area_min_x, draw_area_min_y, draw_area_max_x, draw_area_max_y = \
            rect
        width = draw_area_max_x - draw_area_min_x
        height = draw_area_max_y - draw_area_min_y
        if width == height == 0:
            return []       # Zero size region.

        draw_area_min = [draw_area_min_x, draw_area_min_y]
        draw_area_max = [draw_area_max_x - 1, draw_area_max_y - 1]

        # Collect regions which overlaps with draw area.
        regions = []
        for area in context.screen.areas:
            for region in area.regions:
                if region.type == '':
                    continue    # Skip region with no type.
                region_min = [region.x, region.y]
                region_max = [region.x + region.width - 1,
                              region.y + region.height - 1]
                if intersect_aabb(region_min, region_max,
                                  draw_area_min, draw_area_max):
                    regions.append((area, region))

        return regions

    @classmethod
    def _draw_last_operator_layer(cls, context, font_id, x, y):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        ui_line_width = user_prefs.system.ui_line_width
        margin = prefs.margin * ui_scale

        sh = cls.text_area_height(font_id) + margin * 2

        operator_history = cls.removed_old_operator_history()
        if not operator_history:
            layer_height = sh + sh * cls.HEIGHT_RATIO_FOR_SEPARATOR
            return 0, layer_height, False

        current_time = time.time()
        time_, bl_label, idname_py, _ = operator_history[-1]
        if current_time - time_ > prefs.display_time:
            layer_height = sh + sh * cls.HEIGHT_RATIO_FOR_SEPARATOR
            return 0, layer_height, False

        blf.color(font_id, *prefs.color)

        # Setup operator text.
        operator_text = ""
        if prefs.last_operator_show_mode == 'LABEL':
            operator_text += bpy.app.translations.pgettext_iface(
                bl_label, "Operator")
        elif prefs.last_operator_show_mode == 'IDNAME':
            operator_text += "{}".format(idname_py)
        elif prefs.last_operator_show_mode == 'LABEL_AND_IDNAME':
            operator_text += bpy.app.translations.pgettext_iface(
                bl_label, "Operator")
            operator_text += " ('{}')".format(idname_py)

        # Setup draw target position
        operator_start_x = x
        operator_start_y = y
        operator_width = \
            cls.text_area_width(operator_text, font_id) + margin * 2
        operator_height = sh + sh * cls.HEIGHT_RATIO_FOR_SEPARATOR * 0.2
        separator_start_x = operator_start_x
        separator_start_y = operator_start_y + operator_height
        separator_line_width = blf.dimensions(font_id, "Left Mouse")[0]
        separator_width = separator_line_width + margin * 2
        separator_height = sh * cls.HEIGHT_RATIO_FOR_SEPARATOR * 0.8

        layer_width = max(operator_width, separator_width)
        layer_height = operator_height + separator_height

        operator_offset_x, operator_offset_y = \
            cls.get_alignment_offset(context, operator_width, margin)
        separator_offset_x, separator_offset_y = \
            cls.get_alignment_offset(context, separator_width, margin)
        operator_start_x += operator_offset_x
        operator_start_y += operator_offset_y
        separator_start_x += separator_offset_x
        separator_start_y += separator_offset_y

        # Draw operator history.
        blf.position(font_id, operator_start_x, operator_start_y, 0)
        if show_text_background(prefs):
            draw_text_background(operator_text, font_id,
                                 operator_start_x,
                                 operator_start_y,
                                 prefs.background_color, margin,
                                 prefs.background_rounded_corner_radius)
        draw_text(operator_text, font_id, prefs.color,
                  prefs.shadow, prefs.shadow_color)

        # Draw separator.
        draw_line(
            [separator_start_x, separator_start_y],
            [separator_start_x + separator_line_width, separator_start_y],
            prefs.color, prefs.shadow, prefs.shadow_color,
            prefs.line_thickness * ui_line_width)

        return layer_width, layer_height, True

    @classmethod
    def _draw_mouse_and_modifier_keys_layer(cls, context, font_id, x, y):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        ui_line_width = user_prefs.system.ui_line_width
        margin = prefs.margin * ui_scale

        drawing = False  # TODO: Need to check if drawing is now on progress.
        blf.color(font_id, *prefs.color)
        modifier_keys_box_margin = cls.text_area_height(font_id) * \
            cls.MARGIN_RATIO_FOR_MODIFIER_KEYS_BOX
        region_redraw = False

        # Setup hold modifier keys text
        modifier_keys_text = ""
        if cls.hold_modifier_keys or drawing:
            mod_keys = cls.sorted_modifier_keys(cls.hold_modifier_keys)
            if drawing:
                modifier_keys_text = ""
            else:
                modifier_keys_text = " + ".join(mod_keys)

        # Setup draw target position
        mouse_start_x = 0.0
        mouse_start_y = 0.0
        mouse_icon_width = 0.0
        mouse_icon_height = 0.0
        mouse_width = 0.0
        mouse_height = 0.0
        hold_modifier_keys_start_x = 0.0
        hold_modifier_keys_start_y = 0.0
        hold_modifier_keys_width = 0.0
        hold_modifier_keys_height = 0.0
        separator_width = 0.0
        if show_mouse_hold_status(prefs):
            mouse_start_x = x
            mouse_start_y = y
            if prefs.use_custom_mouse_image:
                mouse_icon_width = prefs.custom_mouse_size[0]
                mouse_icon_height = prefs.custom_mouse_size[1]
            else:
                mouse_icon_width = prefs.mouse_size
                mouse_icon_height = \
                    prefs.mouse_size * cls.HEIGHT_RATIO_FOR_MOUSE_HOLD_STATUS
            mouse_width = mouse_icon_width * ui_scale
            mouse_height = mouse_icon_height * ui_scale
        if cls.hold_modifier_keys:
            hold_modifier_keys_start_x = x
            hold_modifier_keys_start_y = y
            hold_modifier_keys_text_width = \
                cls.text_area_width(modifier_keys_text, font_id) + \
                modifier_keys_box_margin * 2
            hold_modifier_keys_text_height = \
                cls.text_area_height(font_id) + modifier_keys_box_margin * 2
            hold_modifier_keys_width = hold_modifier_keys_text_width
            hold_modifier_keys_height = hold_modifier_keys_text_height

        if prefs.align == 'CENTER':
            hold_modifier_keys_width = max(hold_modifier_keys_width,
                                           prefs.font_size * 8)
            separator_width = \
                mouse_width * cls.WIDTH_RATIO_FOR_SEPARATOR * ui_scale + margin
        if show_mouse_hold_status(prefs) and cls.hold_modifier_keys:
            separator_width = \
                mouse_width * cls.WIDTH_RATIO_FOR_SEPARATOR * ui_scale + margin
            if prefs.align == 'RIGHT':
                mouse_start_x += hold_modifier_keys_width + separator_width
            elif prefs.align in ('LEFT', 'CENTER'):
                hold_modifier_keys_start_x += \
                    mouse_icon_width + separator_width

        layer_width = mouse_width + separator_width + \
            hold_modifier_keys_width + margin * 2
        layer_height = max(mouse_height, hold_modifier_keys_height) + \
            margin * 2

        offset_x, offset_y = cls.get_alignment_offset(
            context, layer_width, margin)
        mouse_start_x += offset_x
        mouse_start_y += offset_y
        hold_modifier_keys_start_x += offset_x
        hold_modifier_keys_start_y += offset_y

        if mouse_height > hold_modifier_keys_height:
            hold_modifier_keys_start_y += \
                (mouse_height - hold_modifier_keys_height) / 2
        else:
            mouse_start_y += (hold_modifier_keys_height - mouse_height) / 2

        # Draw hold mouse status.
        if show_mouse_hold_status(prefs):
            if prefs.use_custom_mouse_image:
                draw_custom_mouse(mouse_start_x,
                                  mouse_start_y,
                                  mouse_icon_width * ui_scale,
                                  mouse_icon_height * ui_scale,
                                  cls.mouse_buttons_status['LEFTMOUSE'],
                                  cls.mouse_buttons_status['RIGHTMOUSE'],
                                  cls.mouse_buttons_status['MIDDLEMOUSE'],
                                  prefs.custom_mouse_image_display_mode,
                                  common.CUSTOM_MOUSE_IMG_BASE_NAME,
                                  common.CUSTOM_MOUSE_IMG_LMOUSE_NAME,
                                  common.CUSTOM_MOUSE_IMG_RMOUSE_NAME,
                                  common.CUSTOM_MOUSE_IMG_MMOUSE_NAME)
            else:
                draw_default_mouse(
                    mouse_start_x, mouse_start_y,
                    mouse_icon_width * ui_scale,
                    mouse_icon_height * ui_scale,
                    cls.mouse_buttons_status['LEFTMOUSE'],
                    cls.mouse_buttons_status['RIGHTMOUSE'],
                    cls.mouse_buttons_status['MIDDLEMOUSE'],
                    prefs.color,
                    prefs.mouse_size * 0.5 * ui_scale,
                    fill=prefs.background,
                    fill_color=prefs.background_color,
                    line_thickness=prefs.line_thickness * ui_line_width)

        # Draw hold modifier keys.
        if cls.hold_modifier_keys or drawing:
            hold_modifier_keys_text_start_x = \
                hold_modifier_keys_start_x + modifier_keys_box_margin
            hold_modifier_keys_text_start_y = \
                hold_modifier_keys_start_y + modifier_keys_box_margin

            if show_text_background(prefs):
                draw_text_background(
                    modifier_keys_text,
                    font_id,
                    hold_modifier_keys_text_start_x,
                    hold_modifier_keys_text_start_y + modifier_keys_box_margin,
                    prefs.background_color, margin,
                    prefs.background_rounded_corner_radius)
            else:
                # Draw rounded box.
                draw_rounded_box(
                    hold_modifier_keys_start_x,
                    hold_modifier_keys_start_y,
                    hold_modifier_keys_text_width,
                    hold_modifier_keys_text_height,
                    hold_modifier_keys_text_height * 0.2,
                    show_text_background(prefs),
                    prefs.background_color if show_text_background(prefs)
                    else prefs.color,
                    line_thickness=prefs.line_thickness * ui_line_width)

            # Draw modifier key text.
            blf.position(
                font_id,
                hold_modifier_keys_text_start_x,
                hold_modifier_keys_text_start_y + modifier_keys_box_margin,
                0)
            draw_text(
                modifier_keys_text, font_id, prefs.color,
                prefs.shadow, prefs.shadow_color)
            imm.immColor4f(*prefs.color)

            region_redraw = True

        return layer_width, layer_height, region_redraw

    @classmethod
    def _draw_event_history_layer(cls, context, font_id, x, y):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        ui_scale = user_prefs.system.ui_scale
        margin = prefs.margin * ui_scale

        sh = cls.text_area_height(font_id) + margin * 2
        region_drawn = False
        color = prefs.color
        blf.color(font_id, *color)

        layer_width = 0.0
        layer_height = 0.0
        event_start_x = x
        event_start_y = y

        event_history = cls.removed_old_event_history()
        if event_history:
            layer_height += cls.text_area_height(font_id) * \
                cls.HEIGHT_RATIO_FOR_SEPARATOR
            event_start_y += cls.text_area_height(font_id) * \
                cls.HEIGHT_RATIO_FOR_SEPARATOR
        for _, event_type, modifiers, repeat_count in event_history[::-1]:
            text = get_display_event_text(event_type.name)
            if modifiers:
                mod_keys = cls.sorted_modifier_keys(modifiers)
                text = "{} + {}".format(" + ".join(mod_keys), text)
            if repeat_count > 1:
                text += " x{}".format(repeat_count)

            text_width = \
                cls.text_area_width(text, font_id) + margin * 2
            offset_x, offset_y = cls.get_alignment_offset(
                context, text_width, margin)
            blf.position(font_id,
                         event_start_x + offset_x, event_start_y + offset_y,
                         0)
            if show_text_background(prefs):
                draw_text_background(text, font_id,
                                     event_start_x + offset_x,
                                     event_start_y + offset_y,
                                     prefs.background_color, margin,
                                     prefs.background_rounded_corner_radius)
            draw_text(text, font_id, prefs.color, prefs.shadow,
                      prefs.shadow_color)

            layer_width = max(text_width, layer_width)
            layer_height += sh
            event_start_y += sh

            region_drawn = True

        return layer_width, layer_height, region_drawn

    @classmethod
    def draw_callback(cls, generation, space_name, region_type):
        if not _runtime_ledger.generation_matches(str(generation or "")):
            return
        viewport = _current_gpu_viewport_key()
        if not viewport:
            return
        window = getattr(bpy.context, 'window', None)
        workspace = getattr(window, 'workspace', None) if window is not None else None
        bucket = cls.draw_snapshots.get(_rna_pointer(window))
        if not isinstance(bucket, MappingProxyType):
            return
        commands = bucket.get(
            _draw_snapshot_key(
                space_name, region_type, window, workspace, viewport,
            )
        )
        if not isinstance(commands, tuple):
            return
        _replay_immutable_commands(generation, commands)

    @staticmethod
    def do_auto_save_before_v41():
        return None     # pylint: disable=W0101

    @staticmethod
    def do_auto_save_after_v42():
        do_auto_save = False
        wm = bpy.context.window_manager
        for window in wm.windows:
            for op in window.modal_operators:
                idname = op.bl_idname
                op_prefix, op_name = idname.split("_OT_")
                idname_py = "{}.{}".format(op_prefix.lower(), op_name)
                if idname_py != SK_OT_ScreencastKeys.bl_idname:
                    debug_print(f"Modal operator '{idname_py}' is "
                                "running. Skip auto save")
                    return None
                do_auto_save = True
        return do_auto_save

    @staticmethod
    @bpy.app.handlers.persistent
    def auto_save(_):
        cls = SK_OT_ScreencastKeys
        context = bpy.context
        prefs = context.preferences

        if not prefs.filepaths.use_auto_save_temporary_files:
            return

        current_time = time.time()
        save_interval = prefs.filepaths.auto_save_time * 60
        if current_time - cls.last_auto_saved_time < save_interval:
            elapsed_time = current_time - cls.last_auto_saved_time
            debug_print("Does not reached save interval (Save interval is "
                        f"{save_interval}, but elapsed time is "
                        f"{elapsed_time})")
            return

        # Perform auto save only if the modal operator is executed from
        # Screencast Keys.
        if compat.check_version(4, 2, 0) < 0:
            do_auto_save = cls.do_auto_save_before_v41()
        else:
            do_auto_save = cls.do_auto_save_after_v42()
        if do_auto_save is None:
            return

        if not do_auto_save:
            debug_print("No modal operator is running. Skip auto save")
            return

        if bpy.data.is_saved:
            filename = os.path.basename(bpy.data.filepath)
            save_basename = os.path.splitext(filename)[0] + ".blend"
        else:
            pid = os.getpid()
            save_basename = f"{pid}.blend"

        save_dir = str(_suite_storage.addon_storage_path('.autosave_anchor', 'screencast_keys', 'autosave').parent)
        save_path = os.path.join(save_dir, save_basename)

        # If .blend file is updated from other methods, update
        # last_auto_saved_time.
        if os.path.exists(save_path):
            stat = os.stat(save_path)
            if cls.last_auto_saved_time < stat.st_mtime:
                cls.last_auto_saved_time = stat.st_mtime
                debug_print(f"Auto saved file '{save_path}'is updated")
            if current_time - cls.last_auto_saved_time < save_interval:
                elapsed_time = current_time - cls.last_auto_saved_time
                debug_print("Does not reached save interval (Save interval is "
                            f"{save_interval}, but elapsed time is "
                            f"{elapsed_time})")
                return

        # Create directory to store auto save .blend file.
        if not os.path.exists(save_dir):
            try:
                os.makedirs(save_dir)
            # pylint: disable=W0702
            except:     # noqa
                debug_print(f"Unable to create directory '{save_dir}'")
                return

        # auto_save function can be called from multiple threads.
        # auto_saving variable makes sure that saving mainfile is called from
        # only 1 thread.
        if cls.auto_saving:
            return
        cls.auto_saving = True

        # Check again if the current time overs save interval.
        if current_time - cls.last_auto_saved_time < save_interval:
            elapsed_time = current_time - cls.last_auto_saved_time
            debug_print("Does not reached save interval (Save interval is "
                        f"{save_interval}, but elapsed time is "
                        f"{elapsed_time})")
            cls.auto_saving = False
            return

        # Save .blend file.
        try:
            bpy.ops.wm.save_as_mainfile(filepath=save_path, copy=True)
        # pylint: disable=W0703
        except Exception as e:
            debug_print(f"Unable to save '{save_path}' (Reason: {e})")
            cls.auto_saving = False
            return

        debug_print(f"Auto saved '{save_path}'")
        cls.last_auto_saved_time = os.stat(save_path).st_mtime
        prefs.filepaths.auto_save_time = prefs.filepaths.auto_save_time
        cls.auto_saving = False


    def update_hold_modifier_keys(self, event):
        """Update hold modifier keys."""

        self.hold_modifier_keys.clear()

        if event.shift:
            self.hold_modifier_keys.append(EventType.LEFT_SHIFT)
        if event.oskey:
            self.hold_modifier_keys.append(EventType.OSKEY)
        if event.alt:
            self.hold_modifier_keys.append(EventType.LEFT_ALT)
        if event.ctrl:
            self.hold_modifier_keys.append(EventType.LEFT_CTRL)

        if EventType[event.type] == EventType.WINDOW_DEACTIVATE:
            self.hold_modifier_keys.clear()

    def update_keys_status_internal(self, event):
        """Update internal keys status."""

        if event.type in ('LEFT_ALT', 'RIGHT_ALT'):
            self.keys_status_internal[event.type] = event.value

    def is_middle_mouse_emulated(self, user_prefs):
        if user_prefs.inputs.use_mouse_emulate_3_button:
            alt_pressed = self.keys_status_internal['LEFT_ALT'] == 'PRESS' or \
                self.keys_status_internal['RIGHT_ALT'] == 'PRESS'
            return alt_pressed
        return False

    def get_original_event_from_emulated(self, event, user_prefs):
        # If "Emulate 3 Button Mouse" option is enabled, we handle the middle
        # mouse event as the left mouse event.
        event_type = event.type
        if self.is_middle_mouse_emulated(user_prefs):
            # From the observation, event.alt will be False when 'MIDDLEMOUSE'
            # event will be issued.
            if event.type == 'MIDDLEMOUSE' and not event.alt:
                return 'LEFTMOUSE'
        return event_type

    def update_mouse_buttons_status(self, event, user_prefs):
        """Update hold mouse buttons."""

        event_type = self.get_original_event_from_emulated(event, user_prefs)

        is_hold_mouse_event = event_type in self.mouse_buttons_status.keys()
        if event_type != 'MOUSEMOVE' and not is_hold_mouse_event:
            return

        # Note: This is not complete solution.
        # Release event is not fired in specific cases (ex. open context menu,
        # mouse drag, ...).
        # To solve this issue, use 'MOUSEMOVE' event which will not be fired
        # when some mouse key is not pressed.
        if event_type == 'MOUSEMOVE':
            if compat.check_version(3, 2, 0) < 0:
                if event_type == 'RELEASE':
                    for k in self.mouse_buttons_status.keys():
                        self.mouse_buttons_status[k] = 'RELEASE'
            elif compat.check_version(4, 2, 0) < 0:
                for k in self.mouse_buttons_status.keys():
                    self.mouse_buttons_status[k] = 'RELEASE'
            else:
                for k, v in self.mouse_buttons_status.items():
                    if k == 'MIDDLEMOUSE':
                        continue
                    if k == 'LEFTMOUSE':
                        if v == 'CLICK_DRAG':
                            continue
                        if self.is_middle_mouse_emulated(user_prefs):
                            continue
                    self.mouse_buttons_status[k] = 'RELEASE'

        self.mouse_buttons_status[event_type] = event.value

    def is_ignore_event(self, event, prefs=None):
        """Return True if event will not be shown."""

        event_type = EventType[event.type]
        if event_type in {EventType.NONE, EventType.MOUSEMOVE,
                          EventType.INBETWEEN_MOUSEMOVE,
                          EventType.WINDOW_DEACTIVATE, EventType.TEXTINPUT}:
            return True
        elif (prefs is not None) and \
                (not show_mouse_event_history(prefs)) and \
                (event_type in self.MOUSE_EVENT_TYPES):
            return True
        elif event_type.name.startswith("EVT_TWEAK"):
            return True
        elif event_type.name.startswith("TIMER"):
            return True

        return False

    def _process_modal_event(self, context, event):
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)

        if not self.__class__.is_running():
            return {'FINISHED'}

        if event.type == '':
            # Many events that should be identified as 'NONE', instead are
            # identified as '' and raise KeyErrors in EventType
            # (i.e. caps lock and the spin tool in edit mode)
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE':
            self.__class__.current_mouse_co = [event.mouse_x, event.mouse_y]

        event_type = self.get_original_event_from_emulated(event, user_prefs)
        event_type = EventType[event_type]

        current_time = time.time()

        # Update Area - Space mapping.
        for area in context.screen.areas:
            for space in area.spaces:
                self.area_spaces[area.as_pointer()].add(space.as_pointer())

        # Update hold modifiers keys.
        self.update_hold_modifier_keys(event)
        current_mod_keys = self.hold_modifier_keys.copy()
        if event_type in current_mod_keys:
            # Remove modifier key which is just pressed.
            current_mod_keys.remove(event_type)

        # Update keys status internal.
        self.update_keys_status_internal(event)

        # Update hold mouse buttons.
        self.update_mouse_buttons_status(event, user_prefs)

        # Update event history.
        if not self.is_ignore_event(event, prefs=prefs) and \
                not self.__class__.is_modifier_event(event) and \
                event.value == 'PRESS':
            current_event = [current_time, event_type, current_mod_keys, 1]

            if self.event_history:
                last_event = self.event_history[-1]
                delta_time = current_time - last_event[0]
                is_same = last_event[1:-1] == current_event[1:-1]
                # If events are raised in short time (e.g. Double Click), the
                # additional events will be raised from the Internal of
                # Blender. This check avoids not to count such events.
                if is_same and delta_time < self.INTERVAL_FOR_IGNORE_EVENT:
                    pass
                # If this event has same event_type and modifiers, we increment
                # repeat_count. However, we reset repeat_count if event
                # interval overs display time.
                elif prefs.repeat_count and is_same and \
                        delta_time < prefs.display_time:
                    last_event[0] = current_time
                    last_event[-1] += 1
                else:
                    self.event_history.append(current_event)
            else:
                self.event_history.append(current_event)
        self.event_history[:] = self.removed_old_event_history()

        # Update operator history.
        operators = list(context.window_manager.operators)
        if operators:
            # Find last operator which detects in previous modal call.
            if self.operator_history:
                addr = self.operator_history[-1][-1]
            else:
                addr = None
            prev_last_op_index = 0
            for i, op in enumerate(operators[::-1]):
                if op.as_pointer() == addr:
                    prev_last_op_index = len(operators) - i
                    break

            # Add operators to history.
            for op in operators[prev_last_op_index:]:
                op_prefix, op_name = op.bl_idname.split("_OT_")
                idname_py = "{}.{}".format(op_prefix.lower(), op_name)
                self.operator_history.append(
                    [current_time, op.bl_label, idname_py, op.as_pointer()])
        self.operator_history[:] = self.removed_old_operator_history()

        # Geometry and immutable command construction happen in the modal event,
        # never in a draw callback.
        self._sync_immutable_draw_runtime(context)
        self.__class__.prev_time = current_time

        return {'PASS_THROUGH'}

    def modal(self, context, event):
        cls = self.__class__
        # A previous invocation may still have one already-queued event after
        # its exact modal lease was cancelled.  That stale instance must exit
        # without tearing down a newer same-generation invocation that now owns
        # the class-wide timers and draw handlers.
        if cls.active_modal is not self:
            self._sws_modal_cancelled = True
            return {'FINISHED'}
        generation = str(getattr(cls, 'runtime_generation', '') or '')
        if not generation or not _runtime_ledger.generation_matches(generation):
            cls.stop(self, context)
            return {'FINISHED'}
        if bool(getattr(self, '_sws_modal_cancelled', False)):
            cls.stop(self, context)
            return {'FINISHED'}
        try:
            if event.type == 'ESC':
                cls.stop(self, context)
                return {'CANCELLED'}
            if not _origin_area_alive(cls, context):
                cls.stop(self, context)
                return {'FINISHED'}
            if not _manager_allows_screencast(context):
                # A modal operator is process-global, but its draw authority is
                # workspace-scoped.  An event from an all-OFF workspace clears
                # only that window's snapshots.  Runtime remains available for
                # another ON workspace and stops once no allowed snapshot is
                # left anywhere.
                cls._sync_immutable_draw_runtime(context)
                if not cls.draw_snapshots:
                    cls.stop(self, context)
                    return {'FINISHED'}
                return {'PASS_THROUGH'}
            return self._process_modal_event(context, event)
        except Exception:
            cls.stop(self, context)
            return {'CANCELLED'}

    @classmethod
    def _cache_runtime_window(cls, window):
        window_key = _rna_pointer(window)
        workspace = getattr(window, 'workspace', None)
        workspace_key = _rna_pointer(workspace)
        if not window_key or not workspace_key:
            return 0, 0
        old_workspace_key = cls.runtime_window_workspaces.get(window_key)
        if old_workspace_key and old_workspace_key != workspace_key:
            old_bucket = cls.runtime_workspace_windows.get(old_workspace_key)
            if isinstance(old_bucket, dict):
                old_bucket.pop(window_key, None)
                if not old_bucket:
                    cls.runtime_workspace_windows.pop(old_workspace_key, None)
        cls.runtime_windows[window_key] = window
        cls.runtime_window_workspaces[window_key] = workspace_key
        cls.runtime_workspace_windows.setdefault(workspace_key, {})[window_key] = window
        return window_key, workspace_key

    @classmethod
    def _sync_immutable_draw_runtime(cls, context, *, discovered_windows=None):
        generation = str(cls.runtime_generation or '')
        if not _runtime_ledger.generation_matches(generation):
            return False
        wanted = {}
        wm = getattr(context, 'window_manager', None)
        current_window = getattr(context, 'window', None)
        if wm is None or current_window is None:
            return False
        if discovered_windows is not None:
            cls.runtime_windows.clear()
            cls.runtime_window_workspaces.clear()
            cls.runtime_workspace_windows.clear()
            windows = tuple(discovered_windows)
            for window in windows:
                cls._cache_runtime_window(window)
        else:
            _current_key, current_workspace_key = cls._cache_runtime_window(current_window)
            windows = tuple(
                cls.runtime_workspace_windows.get(current_workspace_key, {}).values()
            )
        current_workspace_key = _rna_pointer(getattr(current_window, 'workspace', None))
        for window in windows:
            window_key, workspace_key = cls._cache_runtime_window(window)
            if not window_key or not workspace_key:
                continue
            # A cached window may have changed workspace since the last event.
            # Remove its old publication now; its new workspace bucket is handled
            # by a matching event without rediscovering the global window set.
            if discovered_windows is None and workspace_key != current_workspace_key:
                cls.draw_snapshots.pop(window_key, None)
                cls.event_timer_remove_windows((window,))
                continue
            screen = getattr(window, 'screen', None)
            workspace = getattr(window, 'workspace', None)
            if screen is None or workspace is None:
                cls.draw_snapshots.pop(window_key, None)
                cls.event_timer_remove_windows((window,))
                continue
            targets = []
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                space_type = cls.SPACE_TYPES.get(getattr(area, 'type', None))
                space = getattr(getattr(area, 'spaces', None), 'active', None)
                if space_type is None or space is None:
                    continue
                region = next(
                    (
                        item for item in tuple(getattr(area, 'regions', ()) or ())
                        if str(getattr(item, 'type', '') or '') == 'WINDOW'
                    ),
                    None,
                )
                if region is not None:
                    targets.append((area, region, space, space_type))
            if not targets:
                cls.draw_snapshots.pop(window_key, None)
                cls.event_timer_remove_windows((window,))
                continue
            authority_area, authority_region, authority_space, _authority_type = targets[0]
            authority_override = {
                'window': window,
                'workspace': workspace,
                'screen': screen,
                'area': authority_area,
                'region': authority_region,
                'space_data': authority_space,
            }
            authority_region_data = getattr(authority_space, 'region_3d', None)
            if authority_region_data is not None:
                authority_override['region_data'] = authority_region_data
            try:
                with bpy.context.temp_override(**authority_override):
                    if not _manager_allows_screencast(bpy.context):
                        cls.draw_snapshots.pop(window_key, None)
                        cls.event_timer_remove_windows((window,))
                        continue
            except Exception:
                # Manager absence/unready is handled fail-open inside the helper;
                # an invalid RNA context cannot safely publish this window.
                cls.draw_snapshots.pop(window_key, None)
                cls.event_timer_remove_windows((window,))
                continue
            snapshots = {}
            for area, region, space, space_type in targets:
                region_type = 'WINDOW'
                space_name = str(
                    getattr(space_type, '__name__', '') or str(space_type)
                )
                pair = (space_type, region_type)
                wanted[pair] = (space_name, region_type)
                override = {
                    'window': window,
                    'workspace': workspace,
                    'screen': screen,
                    'area': area,
                    'region': region,
                    'space_data': space,
                }
                region_data = getattr(space, 'region_3d', None)
                if region_data is not None:
                    override['region_data'] = region_data
                try:
                    with bpy.context.temp_override(**override):
                        commands = _build_immutable_screencast_commands(
                            cls, bpy.context, region,
                        )
                except Exception:
                    continue
                viewport = _viewport_key_from_region(region)
                snapshots[
                    _draw_snapshot_key(
                        space_name, region_type, window, workspace, viewport,
                    )
                ] = commands
                try:
                    region.tag_redraw()
                except Exception:
                    pass
            # Publish one complete immutable bucket, never a partial command set.
            cls.draw_snapshots[window_key] = MappingProxyType(dict(snapshots))
            cls.event_timer_add(context, windows=(window,))
        for pair, names in wanted.items():
            if pair in cls.handlers:
                continue
            space_type, region_type = pair
            space_name, _ = names
            handle = space_type.draw_handler_add(
                cls.draw_callback,
                (generation, space_name, region_type),
                region_type,
                'POST_PIXEL',
            )
            if not _runtime_ledger.register_lease(
                feature='screencast',
                space=space_name,
                region=region_type,
                handle=handle,
                native_remover=_remove_draw_handle,
                remove_args=(space_type, region_type),
            ):
                _remove_draw_handle(handle, space_type, region_type)
                raise RuntimeError('Unable to record screencast draw lease')
            cls.handlers[pair] = handle
        # Handlers are global by Space/Region type.  Keep each exact lease until
        # stop(); a workspace with no snapshot performs an O(1) no-op draw and
        # must never force-remove a handler still serving another workspace.
        return True

    @classmethod
    def draw_handler_remove_all(cls):
        _runtime_ledger.remove_feature_leases('screencast', any_generation=False)
        cls.handlers.clear()
        cls.draw_snapshots.clear()

    @classmethod
    def event_timer_add(cls, context, *, windows):
        generation = str(cls.runtime_generation or '')
        if not _runtime_ledger.generation_matches(generation):
            return False
        wm = context.window_manager
        for window in tuple(windows):
            key = int(window.as_pointer())
            if key in cls.timers:
                continue
            timer = wm.event_timer_add(cls.TIMER_STEP, window=window)
            if not _runtime_ledger.register_lease(
                feature='screencast-timer',
                space=str(key),
                region='WINDOW_TIMER',
                handle=timer,
                native_remover=_remove_event_timer,
                remove_args=(wm,),
            ):
                _remove_event_timer(timer, wm)
                raise RuntimeError('Unable to record screencast timer lease')
            cls.timers[key] = timer
        return True

    @classmethod
    def event_timer_remove_windows(cls, windows):
        for window in tuple(windows):
            key = _rna_pointer(window)
            if not key or key not in cls.timers:
                continue
            if not _runtime_ledger.remove_lease(
                feature='screencast-timer',
                space=str(key),
                region='WINDOW_TIMER',
            ):
                raise RuntimeError('Unable to remove exact screencast timer lease')
            cls.timers.pop(key, None)

    @classmethod
    def event_timer_remove(cls, context=None):
        del context
        _runtime_ledger.remove_feature_leases('screencast-timer', any_generation=False)
        cls.timers.clear()

    @classmethod
    def start(cls, self, context, event, prefs):
        generation = _runtime_ledger.current_generation()
        if (
            not generation
            or not _runtime_ledger.generation_matches(generation)
            or context is None
            or getattr(context, 'window_manager', None) is None
            or getattr(context, 'window', None) is None
            or getattr(context, 'screen', None) is None
            or getattr(context, 'area', None) is None
            or getattr(context, 'space_data', None) is None
            or getattr(context, 'region', None) is None
            or event is None
            or prefs is None
            or not _manager_allows_screencast(context)
        ):
            raise RuntimeError('Screencast cannot acquire a current-generation runtime lease')
        cls.stop(self, context)
        # This is the sole all-window discovery boundary.  All later modal and
        # timer work uses the workspace-indexed RNA references captured here.
        discovered_windows = tuple(context.window_manager.windows)
        cls.runtime_generation = generation
        cls.active_modal = self
        self._sws_modal_cancelled = False
        common.reload_custom_mouse_image(prefs, context)
        self.update_hold_modifier_keys(event)
        cls.origin["window"] = context.window.as_pointer()
        cls.origin["area"] = context.area.as_pointer()
        cls.origin["space"] = context.space_data.as_pointer()
        cls.origin["region_type"] = context.region.type
        cls.origin_window_ref = context.window
        cls.origin_screen_ref = context.screen
        cls.origin_area_ref = context.area
        cls.running = True
        try:
            if not cls._sync_immutable_draw_runtime(
                context, discovered_windows=discovered_windows,
            ):
                raise RuntimeError('Unable to build immutable screencast draw snapshot')
            if _rna_pointer(context.window) not in cls.draw_snapshots:
                raise RuntimeError('Origin workspace has no allowed screencast snapshot')
            context.window_manager.modal_handler_add(self)
            if not _runtime_ledger.register_lease(
                feature='screencast-modal',
                space=str(context.window.as_pointer()),
                region='MODAL',
                handle=self,
                native_remover=_cancel_modal_handle,
            ):
                raise RuntimeError('Unable to record screencast modal lease')
            if prefs.auto_save:
                handlers = bpy.app.handlers.depsgraph_update_pre
                if cls.auto_save not in handlers:
                    handlers.append(cls.auto_save)
                if not _runtime_ledger.register_lease(
                    feature='screencast-autosave',
                    space='APP',
                    region='DEPSGRAPH_UPDATE_PRE',
                    handle=cls.auto_save,
                    native_remover=_remove_handler_identity,
                    remove_args=(handlers,),
                ):
                    _remove_handler_identity(cls.auto_save, handlers)
                    raise RuntimeError('Unable to record screencast autosave lease')
            context.area.tag_redraw()
        except Exception:
            cls.stop(self, context)
            raise

    @classmethod
    def stop(cls, self=None, context=None):
        _runtime_ledger.remove_feature_leases('screencast-autosave', any_generation=False)
        _runtime_ledger.remove_feature_leases('screencast-modal', any_generation=False)
        cls.event_timer_remove(context)
        cls.draw_handler_remove_all()
        cls.hold_modifier_keys.clear()
        cls.event_history.clear()
        cls.operator_history.clear()
        cls.draw_regions_prev.clear()
        cls.running = False
        cls.runtime_generation = ''
        cls.active_modal = None
        cls.runtime_windows.clear()
        cls.runtime_window_workspaces.clear()
        cls.runtime_workspace_windows.clear()
        cls.origin_window_ref = None
        cls.origin_screen_ref = None
        cls.origin_area_ref = None
        if self is not None:
            try:
                self._sws_modal_cancelled = True
            except Exception:
                pass
        try:
            area = getattr(context, 'area', None) if context is not None else None
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass

    def invoke(self, context, event):
        cls = self.__class__
        user_prefs = context.preferences
        prefs = integrated_bridge.get_prefs(context if "context" in locals() else bpy.context)
        generation = _runtime_ledger.current_generation()
        if (
            not generation
            or not _runtime_ledger.generation_matches(generation)
            or prefs is None
        ):
            cls.stop(self, context)
            return {'CANCELLED'}

        # A non-entry attempt from an all-OFF workspace is local to that
        # workspace.  It must not tear down a process-global modal instance
        # that is still serving an ON workspace.
        if not _manager_allows_screencast(context):
            if cls.is_running():
                cls._sync_immutable_draw_runtime(context)
            return {'CANCELLED'}

        if cls.is_running() and not self.restart:
            self.stop(self, context)
            return {'CANCELLED'}
        try:
            # start() owns the only stop/acquire transition and is the sole
            # start call in this explicit event boundary.
            self.start(self, context, event, prefs)
            return {'RUNNING_MODAL'}
        except Exception:
            self.stop(self, context)
            return {'CANCELLED'}


@BlClassRegistry()
class SK_OT_SetOrigin(bpy.types.Operator):
    bl_idname = "wm.sk_set_origin"
    bl_label = "Screencast Keys Set Origin"
    bl_description = ""
    bl_options = {'UNDO'}
    # Draw handlers.
    # Format: {(Space, Region.type): handle}
    handlers = {}
    draw_snapshots = MappingProxyType({})
    runtime_generation = ""

    # Previous mouseovered area.
    area_prev = None

    # Mouseovered region.
    mouseovered_region = None

    @classmethod
    def draw_callback(cls, generation, space_name, region_type):
        if not _runtime_ledger.generation_matches(str(generation or "")):
            return
        viewport = _current_gpu_viewport_key()
        commands = cls.draw_snapshots.get((str(space_name), str(region_type), viewport))
        if isinstance(commands, tuple):
            _replay_immutable_commands(generation, commands)

    def draw_handler_add(self, context):
        generation = _runtime_ledger.current_generation()
        if not generation:
            return False
        self.__class__.runtime_generation = generation
        screen = getattr(context, 'screen', None)
        wanted = set()
        for area in getattr(screen, 'areas', ()):
            space_type = SK_OT_ScreencastKeys.SPACE_TYPES.get(getattr(area, 'type', None))
            if space_type is None:
                continue
            for region in getattr(area, 'regions', ()):
                region_type = str(getattr(region, 'type', '') or '')
                if not region_type:
                    continue
                pair = (space_type, region_type)
                wanted.add(pair)
                if pair in self.handlers:
                    continue
                space_name = str(getattr(space_type, '__name__', '') or str(space_type))
                handle = space_type.draw_handler_add(
                    self.__class__.draw_callback,
                    (generation, space_name, region_type),
                    region_type,
                    'POST_PIXEL',
                )
                if not _runtime_ledger.register_lease(
                    feature='screencast-origin',
                    space=space_name,
                    region=region_type,
                    handle=handle,
                    native_remover=_remove_draw_handle,
                    remove_args=(space_type, region_type),
                ):
                    _remove_draw_handle(handle, space_type, region_type)
                    raise RuntimeError('Unable to record origin draw lease')
                self.handlers[pair] = handle
        return True

    def draw_handler_remove_all(self):
        # Both the draw handles and modal cancellation token are exact current-
        # generation leases.  Removing either path repeatedly is idempotent.
        _runtime_ledger.remove_feature_leases('screencast-origin-modal', any_generation=False)
        _runtime_ledger.remove_feature_leases('screencast-origin', any_generation=False)
        self.handlers.clear()
        self.__class__.draw_snapshots = MappingProxyType({})
        self.__class__.runtime_generation = ''
        try:
            self._sws_modal_cancelled = True
        except Exception:
            pass

    def get_mouseovered_region(self, context, event):
        """Get mouseovered area and region."""

        x, y = event.mouse_x, event.mouse_y
        for area in context.screen.areas:
            for region in area.regions:
                if region.type == "":
                    continue
                within_x = region.x <= x < region.x + region.width
                within_y = region.y <= y < region.y + region.height
                if within_x and within_y:
                    return area, region

        return None, None

    def modal(self, context, event):
        generation = str(self.__class__.runtime_generation or '')
        if (
            not generation
            or not _runtime_ledger.generation_matches(generation)
            or bool(getattr(self, '_sws_modal_cancelled', False))
            or getattr(context, 'window', None) is None
            or getattr(context, 'screen', None) is None
            or not _manager_allows_screencast(context)
        ):
            self.draw_handler_remove_all()
            return {'FINISHED'}
        try:
            area, region = self.get_mouseovered_region(context, event)
            if self.area_prev:
                self.area_prev.tag_redraw()
            if area:
                area.tag_redraw()
            self.mouseovered_region = region
            self.area_prev = area
            snapshots = {}
            if region is not None and area is not None:
                space_type = SK_OT_ScreencastKeys.SPACE_TYPES.get(getattr(area, 'type', None))
                if space_type is not None:
                    space_name = str(getattr(space_type, '__name__', '') or str(space_type))
                    viewport = _viewport_key_from_region(region)
                    highlight_command = _prebuild_rect_batch_command(
                        0.0,
                        0.0,
                        float(region.width),
                        float(region.height),
                        (1.0, 0.0, 0.0, 0.3),
                    )
                    snapshots[(space_name, str(region.type), viewport)] = (
                        (highlight_command,) if highlight_command is not None else ()
                    )
            self.__class__.draw_snapshots = MappingProxyType(dict(snapshots))
            if event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                if area is None or region is None:
                    return {'RUNNING_MODAL'}
                origin = SK_OT_ScreencastKeys.origin
                origin["window"] = context.window.as_pointer()
                origin["area"] = area.as_pointer()
                origin["space"] = area.spaces.active.as_pointer()
                origin["region_type"] = region.type
                self.draw_handler_remove_all()
                return {'FINISHED'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                self.draw_handler_remove_all()
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}
        except Exception:
            self.draw_handler_remove_all()
            return {'CANCELLED'}

    def invoke(self, context, _event):
        self.area_prev = None
        self.mouseovered_region = None
        self._sws_modal_cancelled = False
        generation = _runtime_ledger.current_generation()
        if (
            not generation
            or not _runtime_ledger.generation_matches(generation)
            or getattr(context, 'window', None) is None
            or getattr(context, 'screen', None) is None
            or not _manager_allows_screencast(context)
        ):
            return {'CANCELLED'}
        try:
            if not self.draw_handler_add(context):
                return {'CANCELLED'}
            context.window_manager.modal_handler_add(self)
            if not _runtime_ledger.register_lease(
                feature='screencast-origin-modal',
                space=str(context.window.as_pointer()),
                region='MODAL',
                handle=self,
                native_remover=_cancel_modal_handle,
            ):
                self.draw_handler_remove_all()
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}
        except Exception:
            self.draw_handler_remove_all()
            return {'CANCELLED'}


@BlClassRegistry()
class SK_OT_WaitBlenderInitializedAndStartScreencastKeys(bpy.types.Operator):
    bl_idname = "wm.sk_wait_blender_initialized_and_start_screencast_keys"
    bl_label = "Wait For Blender Initialized And Start Screencast Keys"

    bl_options = set()
    _sms_no_undo = True
    initialization_handler = None

    def get_first_space_class(self, context):
        space_to_class = {
            'VIEW_3D': bpy.types.SpaceView3D,
            'IMAGE_EDITOR': bpy.types.SpaceImageEditor,
            'NODE_EDITOR': bpy.types.SpaceNodeEditor,
            'SEQUENCE_EDITOR': bpy.types.SpaceSequenceEditor,
            'CLIP_EDITOR': bpy.types.SpaceClipEditor,
            'DOPESHEET_EDITOR': bpy.types.SpaceDopeSheetEditor,
            'GRAPH_EDITOR': bpy.types.SpaceGraphEditor,
            'NLA_EDITOR': bpy.types.SpaceNLA,
            'TEXT_EDITOR': bpy.types.SpaceTextEditor,
            'CONSOLE': bpy.types.SpaceConsole,
            'INFO': bpy.types.SpaceInfo,
            'OUTLINER': bpy.types.SpaceOutliner,
            'PROPERTIES': bpy.types.SpaceProperties,
            'FILE_BROWSER': bpy.types.SpaceFileBrowser,
            'SPREADSHEET': bpy.types.SpaceSpreadsheet,
            'PREFERENCES': bpy.types.SpacePreferences,
        }

        area_types = []
        for area in context.screen.areas:
            if area.type in space_to_class.keys():
                area_types.append(area.type)
        if len(area_types) == 0:
            return None

        area_types.sort(key=lambda t: list(space_to_class.keys()).index(t))

        return space_to_class[area_types[0]]

    def execute(self, context):
        if not _runtime_ledger.current_generation():
            return {'CANCELLED'}
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if area is None or region is None:
            screen = getattr(context, 'screen', None)
            for candidate_area in getattr(screen, 'areas', ()):
                candidate_region = next((item for item in getattr(candidate_area, 'regions', ()) if getattr(item, 'type', '') == 'WINDOW'), None)
                if candidate_region is not None:
                    area, region = candidate_area, candidate_region
                    break
        if area is None or region is None:
            return {'CANCELLED'}
        try:
            override = getattr(context, 'temp_override', None)
            if callable(override):
                with override(area=area, region=region):
                    bpy.ops.wm.sk_screencast_keys('INVOKE_REGION_WIN', restart=True)
            else:
                bpy.ops.wm.sk_screencast_keys('INVOKE_REGION_WIN', restart=True)
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}

    @classmethod
    def intialization_callback(cls, _space_class, _unused):
        # Compatibility no-op.  Startup is event-driven by execute/load_post;
        # draw callbacks never start operators or allocate runtime resources.
        return None
