# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility entry points for input captions and overlay artwork."""
import sys
import bpy
from . import integrated_bridge, operators

def is_console_mode():
    return bpy.app.background

def output_debug_log():
    prefs=integrated_bridge.get_prefs()
    return bool(prefs and prefs.output_debug_log)

def debug_print(s):
    if output_debug_log():print(s)

def fix_modifier_display_text(name):
    for side in ('Left ', 'Right '):
        if name.startswith(side):
            name=name[len(side):]
            break
    if name=='OS Key':
        return {'win32':'Windows Key','darwin':'Command'}.get(sys.platform,'OS Key')
    return name

def ensure_custom_mouse_images():
    run=operators._active
    prefs=integrated_bridge.get_prefs()
    if not run or not prefs or not prefs.use_custom_mouse_image:return
    for name in ('base','left_mouse','middle_mouse','right_mouse'):
        run.paint.image(name,getattr(prefs,'custom_mouse_image_'+name))

def reload_custom_mouse_image(prefs,context):
    run=operators._active
    if run:
        run.paint.clear_images()
        run.view.area.tag_redraw()

def use_3d_polyline(context):
    if bpy.app.background:return False
    import gpu
    try:
        return gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR') is not None
    except (RuntimeError,ValueError):
        return False
