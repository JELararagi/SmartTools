# Screencast Keys upstream attribution

This package includes the Screencast Keys integration under the upstream project's original licensing notices.

- Project: [nutti/Screencast-Keys](https://github.com/nutti/Screencast-Keys)
- Audited source snapshot: `55e34aa8b18ade8e16e3bfff70e5977947c7c960`
- Audited upstream `bl_info` version: `4.2.0`
- Authors declared in that source: nutti, Paulo Gomes, Bart Crouch, John E. Herrenyo, Gaia Clary, Pablo Vazquez, chromoly, Hawkpath, CheeryLee, Kureii.

The corresponding upstream license text is provided in the sibling file `UPSTREAM_LICENSE.txt`.

The bounded comparison mapped 16 of 17 bundled files: 2 byte-exact and 14 modified, with 53 nontrivial AST function matches. `operators.py` was compared with upstream `ops.py`. The local `integrated_bridge.py` origin and exact historically acquired archive remain unestablished.

The root package retains its GPL-3.0-or-later declaration, while separate original Python headers retain their GPL-2.0-or-later declarations. This notice does not resolve how those distinct declarations apply across the complete SmartWorkspace package. It is an attribution and source-reference record, not a license grant, sales approval, complete source-offer assessment, or claim that the integration author wrote the upstream implementation.
