# Input display history

Older Smart Workspace builds bundled code from [Screencast Keys](https://github.com/nutti/Screencast-Keys).
The archived comparison used version 4.2.0, commit `55e34aa8b18ade8e16e3bfff70e5977947c7c960`.
The upstream authors listed in that snapshot are nutti, Paulo Gomes, Bart Crouch,
John E. Herrenyo, Gaia Clary, Pablo Vazquez, chromoly, Hawkpath, and CheeryLee.
The upstream license text is retained in `UPSTREAM_LICENSE.txt` for that history.

This release uses Smart Workspace's independently implemented input display and
keeps the existing Blender command IDs for saved shortcuts. The Smart Workspace
implementation is distributed under GPL-3.0-or-later.
