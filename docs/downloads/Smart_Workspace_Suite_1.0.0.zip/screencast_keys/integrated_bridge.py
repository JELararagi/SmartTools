# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Keep the installed user's input display settings in the Workspace configuration store."""
import json
import bpy
from .. import storage

FIELD='smart_workspace_suite_screencast_keys_prefs'
restoring=False
dirty=False
_last=None
_blocked=None
_registered=False
_saved={}
_SKIP={'rna_type','name','display_event_text_aliases_props'}

def is_integrated_mode():
    return True

def _path():
    return storage.storage_path('screencast_keys_v4_2_2.json','screencast_keys',create=False)

def get_prefs(context=None):
    wm=getattr(context or bpy.context,'window_manager',None)
    return getattr(wm,FIELD,None)

def _read(path):
    if not path.exists():
        return None,{}
    data=path.read_bytes()
    obj=json.loads(data)
    if not isinstance(obj,dict):
        raise ValueError('Input display settings must be an object')
    return data,obj

def _values(p):
    result=dict(_saved)
    for f in p.bl_rna.properties:
        key=f.identifier
        if key in _SKIP:
            continue
        value=getattr(p,key)
        result[key]=list(value) if getattr(f,'is_array',False) else value
    result['name']=p.name
    result['display_event_text_aliases_props']=[
        dict(name=r.name,event_id=r.event_id,default_text=r.default_text,alias_text=r.alias_text)
        for r in p.display_event_text_aliases_props]
    return result

def load_prefs(context=None):
    global _blocked,_saved,_last,restoring,dirty
    p=get_prefs(context)
    if p is None or restoring:
        return False
    path=_path()
    restoring=True
    try:
        _last,values=_read(path)
        for key in values:
            if key in _SKIP or key not in p.bl_rna.properties:
                continue
            prop=p.bl_rna.properties[key]
            if prop.type=='ENUM' and not values[key]:
                continue
            setattr(p,key,values[key])
        saved_aliases=values.get('display_event_text_aliases_props',[])
        if not isinstance(saved_aliases,list):
            raise ValueError('Invalid key labels')
        by_key={r['event_id']:r for r in saved_aliases if isinstance(r,dict) and isinstance(r.get('event_id'),str)}
        events=bpy.types.Event.bl_rna.properties['type'].enum_items
        p.display_event_text_aliases_props.clear()
        for item in events:
            row=p.display_event_text_aliases_props.add()
            row.event_id=item.identifier
            row.name=by_key.get(item.identifier,{}).get('name','')
            row.default_text=item.name
            row.alias_text=by_key.get(item.identifier,{}).get('alias_text','')
        # Preserve custom identifiers from other Blender versions.
        for key in by_key.keys()-{item.identifier for item in events}:
            entry=by_key[key]
            row=p.display_event_text_aliases_props.add()
            row.name=entry.get('name','');row.event_id=key;row.default_text=entry.get('default_text',key);row.alias_text=entry.get('alias_text','')
        _saved=values;_blocked=None;dirty=False
        return True
    except (OSError,TypeError,ValueError) as exc:
        _blocked=str(exc)
        print('Smart Workspace: input settings could not be restored:',exc)
        return False
    finally:
        restoring=False

def mark_prefs_dirty():
    global dirty
    if not restoring:
        dirty=True

def persist_user_change(context=None,source=None):
    mark_prefs_dirty()
    return save_prefs(context)

def _needs_mirror():
    if not storage.n_panel_state_save_enabled(True):
        return False
    primary=storage.central_settings_dir(create=False)/'n-panel_manager'/'current_settings.json'
    central=storage.central_settings_path(create=False)
    if not any(p.exists() for p in (primary,primary.with_name(primary.name+'.bak'),central,central.with_name(central.name+'.bak'))):
        # A fresh profile has no N-panel history. The independently usable
        # display keeps its settings until the first full Workspace save.
        return False
    if storage.central_write_batch_active():
        return True
    authority=storage.resolve_n_panel_current_settings(primary,repair_primary=False)
    if not authority.valid:
        raise ValueError('Existing Workspace settings could not be verified. Check the Workspace settings backup.')
    return True

def save_prefs(context=None,*,force=False):
    global _last,_saved,dirty
    p=get_prefs(context)
    if p is None or restoring or _blocked:
        return False
    if not dirty and not force:
        return True
    if not force and (storage.registration_write_guard_active() or not storage.n_panel_state_save_enabled()):
        return True
    path=_path()
    try:
        raw,previous=_read(path)
        current=_values(p)
        if raw!=_last and previous!=current:
            raise ValueError('Input settings changed in another session. Reload before saving.')
        mirror=_needs_mirror()
        if previous==current and (not mirror or storage.central_read_json_for_path(path)==current):
            _last=raw;_saved=previous;dirty=False
            return True
        storage.atomic_write_json(path,current,mirror=mirror,backup=True)
        _last,_saved=_read(path)
        if _saved!=current:
            raise ValueError('Input settings were not saved')
        dirty=False
        return True
    except (OSError,ValueError,TypeError) as exc:
        print('Smart Workspace: input settings could not be saved:',exc)
        return False

def register_storage(pref_cls):
    global _registered
    if _registered:
        return True
    if hasattr(bpy.types.WindowManager,FIELD):
        raise RuntimeError('Another input display settings instance is registered')
    setattr(bpy.types.WindowManager,FIELD,bpy.props.PointerProperty(type=pref_cls))
    _registered=True
    return True

def unregister_storage(context=None):
    global _registered,dirty,_saved,_last,_blocked
    ok=save_prefs(context) if dirty and _registered else True
    if _registered:
        delattr(bpy.types.WindowManager,FIELD)
        _registered=False
    dirty=False;_saved={};_last=None;_blocked=None
    return ok
