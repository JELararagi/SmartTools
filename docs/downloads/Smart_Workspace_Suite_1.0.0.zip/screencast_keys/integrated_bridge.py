# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
from pathlib import Path

import bpy
from .. import storage as _suite_storage
from .. import persistence as _suite_persistence
from .. import runtime_ledger as _runtime_ledger
from rna_prop_ui import IDPropertyGroup

_STORAGE_ATTR = "smart_workspace_suite_screencast_keys_prefs"
_STORAGE_CLS = None
_LAST_SNAPSHOT = ''
_LOADING = False
_UPDATES_PATCHED = False


def is_integrated_mode() -> bool:
    package = str(__package__ or '').lower()
    return (
        '.smart_workspace_suite.' in package
        or package.startswith('smart_workspace_suite.')
        or package.endswith('.smart_workspace_suite')
        or package == 'smart_workspace_suite'
    )


def _prefs_filepath() -> Path:
    return _suite_storage.addon_storage_path('screencast_keys_v4_2_2.json', 'screencast_keys')


def _props_to_dict_recursive(propgroup: IDPropertyGroup | bpy.types.PropertyGroup) -> dict:
    ret = {}
    for key in propgroup.bl_rna.properties.keys():
        if key in {'rna_type', 'bl_idname'}:
            continue
        value = getattr(propgroup, key)
        if isinstance(value, bpy.types.bpy_prop_collection):
            ret[key] = [_props_to_dict_recursive(elem) for elem in value]
        elif isinstance(value, IDPropertyGroup) or isinstance(value, bpy.types.PropertyGroup):
            ret[key] = _props_to_dict_recursive(value)
        else:
            prop = propgroup.bl_rna.properties[key]
            if hasattr(prop, 'enum_items') and getattr(prop, 'enum_items', None):
                try:
                    ret[key] = prop.enum_items[value].identifier
                    continue
                except Exception:
                    pass
            if isinstance(value, (set, tuple)):
                ret[key] = list(value)
            elif not isinstance(value, (str, bytes, dict)) and hasattr(value, '__iter__'):
                try:
                    ret[key] = list(value)
                except Exception:
                    ret[key] = value
            else:
                ret[key] = value
    return ret


def _apply_from_dict_recursive(propgroup, data: dict):
    for key, value in (data or {}).items():
        if not hasattr(propgroup, key):
            continue
        if isinstance(value, list):
            target = getattr(propgroup, key)
            if isinstance(target, bpy.types.bpy_prop_collection):
                target.clear()
                for elem in value:
                    entry = target.add()
                    if isinstance(elem, dict):
                        _apply_from_dict_recursive(entry, elem)
                    else:
                        try:
                            entry.name = str(elem)
                        except Exception:
                            pass
            else:
                try:
                    setattr(propgroup, key, value)
                except Exception:
                    pass
        elif isinstance(value, dict):
            _apply_from_dict_recursive(getattr(propgroup, key), value)
        else:
            try:
                setattr(propgroup, key, value)
            except Exception:
                pass


def _snapshot(context=None) -> str:
    prefs = get_prefs(context)
    if prefs is None:
        return ''
    try:
        return json.dumps(_props_to_dict_recursive(prefs), ensure_ascii=False, sort_keys=True)
    except Exception:
        return ''


def mark_prefs_dirty() -> None:
    """Record an event-side preference change without installing a poll timer."""
    try:
        _suite_persistence.mark_deferred_settings_dirty()
    except Exception:
        pass


def _storage_descriptor():
    try:
        properties = getattr(getattr(bpy.types.WindowManager, 'bl_rna', None), 'properties', None)
        getter = getattr(properties, 'get', None)
        return getter(_STORAGE_ATTR) if callable(getter) else None
    except Exception:
        return None


def _remove_exact_storage_property(_handle=None, *, expected_signature=None) -> None:
    live = _storage_descriptor()
    if live is None:
        return
    if expected_signature is not None and _runtime_ledger.rna_property_signature(live) != expected_signature:
        raise RuntimeError('Screencast preference PointerProperty RNA signature changed')
    delattr(bpy.types.WindowManager, _STORAGE_ATTR)
    if _storage_descriptor() is not None:
        raise RuntimeError('Screencast preference PointerProperty removal did not verify')


def _storage_owned_by_current_generation() -> bool:
    return bool(
        _STORAGE_CLS is not None
        and _runtime_ledger.generation_matches(_runtime_ledger.current_generation())
        and _runtime_ledger.property_is_current(
            bpy.types.WindowManager,
            _STORAGE_ATTR,
            _STORAGE_CLS,
            descriptor=_storage_descriptor(),
        )
    )



def _persist_integrated_user_change(context=None, source: str = 'screencast-keys-rna-update') -> bool:
    if _LOADING:
        return False
    try:
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def persist_user_change(context=None, source: str = 'screencast-keys-rna-update') -> bool:
    return _persist_integrated_user_change(context, source)


def _patch_integrated_property_updates(pref_cls) -> None:
    """Chain immutable preference persistence onto every integrated property."""
    global _UPDATES_PATCHED
    if _UPDATES_PATCHED:
        return

    update_factories = (
        bpy.props.BoolProperty,
        bpy.props.EnumProperty,
        bpy.props.FloatProperty,
        bpy.props.FloatVectorProperty,
        bpy.props.IntProperty,
        bpy.props.IntVectorProperty,
        bpy.props.StringProperty,
    )

    def make_event_update(old_update, name):
        def event_update(self, context):
            try:
                if callable(old_update):
                    old_update(self, context)
            finally:
                _persist_integrated_user_change(
                    context,
                    source=f'screencast-keys:{name}',
                )

        return event_update

    patched_keywords = []
    for name, deferred in getattr(pref_cls, '__annotations__', {}).items():
        if getattr(deferred, 'function', None) not in update_factories:
            continue
        keywords = getattr(deferred, 'keywords', None)
        if not isinstance(keywords, dict) or keywords.get('_sws_event_persistence'):
            continue
        old_update = keywords.get('update')
        keywords['update'] = make_event_update(old_update, str(name))
        keywords['_sws_event_persistence'] = True
        patched_keywords.append(keywords)
    for keywords in patched_keywords:
        keywords.pop('_sws_event_persistence', None)
    _UPDATES_PATCHED = True

def register_storage(pref_cls) -> bool:
    """Register one exact generation-owned preference PointerProperty.

    Same-name RNA from another module generation is never adopted or replaced.
    The root registration transaction records the dynamic class; this function
    records the exact owner, class identity, descriptor identity, generation, and
    native remover for the PointerProperty itself.
    """
    global _STORAGE_CLS
    if not is_integrated_mode():
        return True
    generation = _runtime_ledger.current_generation()
    if not generation or not _runtime_ledger.generation_matches(generation):
        return False
    if _STORAGE_CLS is not None:
        if _storage_owned_by_current_generation():
            load_prefs(getattr(bpy, 'context', None))
            return True
        _runtime_ledger.mark_restart_required(
            'SCREENCAST_PREFERENCES_CLASS_OR_PROPERTY_GENERATION_MISMATCH'
        )
        return False
    if _storage_descriptor() is not None:
        _runtime_ledger.mark_restart_required(
            'SCREENCAST_PREFERENCES_PREEXISTING_POINTERPROPERTY'
        )
        return False

    _patch_integrated_property_updates(pref_cls)
    attrs = {
        '__module__': __name__,
        '__annotations__': dict(getattr(pref_cls, '__annotations__', {})),
    }
    cls = type('SK_INTEGRATED_PREFERENCES', (bpy.types.PropertyGroup,), attrs)
    class_created = False
    property_created = False
    try:
        registered, class_created = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCREENCAST_PREFERENCES_CLASS',
        )
        if not registered:
            raise RuntimeError('Screencast preference class ownership registration failed')
        _STORAGE_CLS = cls
        setattr(
            bpy.types.WindowManager,
            _STORAGE_ATTR,
            bpy.props.PointerProperty(type=cls),
        )
        property_created = True
        descriptor = _storage_descriptor()
        if descriptor is None:
            raise RuntimeError('Screencast preference PointerProperty readback failed')
        descriptor_signature = _runtime_ledger.rna_property_signature(descriptor)

        def _native_remove(_handle=None, *, _signature=descriptor_signature):
            _remove_exact_storage_property(expected_signature=_signature)

        if not _runtime_ledger.record_property(
            bpy.types.WindowManager,
            _STORAGE_ATTR,
            cls,
            remover=_native_remove,
            newly_registered=True,
        ):
            raise RuntimeError('Screencast preference PointerProperty ownership record failed')
        # A corrupt optional feature sidecar is not authority for N-panel state
        # and must not cause adoption/removal of RNA.  load_prefs reports failure
        # while the exact registration remains valid and user defaults stay live.
        load_prefs(getattr(bpy, 'context', None))
        return True
    except Exception:
        if property_created:
            try:
                live = _storage_descriptor()
                if live is not None:
                    _remove_exact_storage_property(expected_signature=_runtime_ledger.rna_property_signature(live))
            except Exception:
                _runtime_ledger.mark_restart_required(
                    'SCREENCAST_PREFERENCES_PROPERTY_ROLLBACK_FAILED'
                )
        if class_created and _runtime_ledger.class_recorded_current(cls):
            _runtime_ledger.unregister_class_exact(
                cls,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='SCREENCAST_PREFERENCES_CLASS',
            )
        _STORAGE_CLS = None
        raise


def unregister_storage(context=None) -> bool:
    global _STORAGE_CLS
    if not is_integrated_mode():
        return True
    if not save_prefs(context, force=True):
        return False
    cls = _STORAGE_CLS
    descriptor = _storage_descriptor()
    if descriptor is not None:
        if cls is None or not _runtime_ledger.property_is_current(
            bpy.types.WindowManager,
            _STORAGE_ATTR,
            cls,
            descriptor=descriptor,
        ):
            _runtime_ledger.mark_restart_required(
                'SCREENCAST_PREFERENCES_POINTERPROPERTY_TEARDOWN_IDENTITY_MISMATCH'
            )
            return False
        try:
            _remove_exact_storage_property(expected_signature=_runtime_ledger.rna_property_signature(descriptor))
        except Exception:
            return False
    if cls is not None:
        if not _runtime_ledger.class_recorded_current(cls):
            _runtime_ledger.mark_restart_required(
                'SCREENCAST_PREFERENCES_CLASS_TEARDOWN_IDENTITY_MISMATCH'
            )
            return False
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SCREENCAST_PREFERENCES_CLASS',
        ):
            return False
        _STORAGE_CLS = None
    return True


def get_prefs(context=None):
    if not is_integrated_mode():
        ctx = context or getattr(bpy, 'context', None)
        if ctx is None:
            return None
        addon = ctx.preferences.addons.get(__package__)
        return addon.preferences if addon else None
    # An old callback must stop before reading RNA from a different generation.
    if not _storage_owned_by_current_generation():
        return None
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    return getattr(wm, _STORAGE_ATTR, None) if wm is not None else None


def save_prefs(context=None, *, force: bool = False) -> bool:
    if _LOADING:
        return False
    if not force:
        try:
            if not _suite_storage.n_panel_state_save_enabled(True):
                _suite_persistence.mark_deferred_settings_dirty()
                return False
        except Exception:
            return False
    prefs = get_prefs(context)
    if prefs is None:
        return True
    path = _prefs_filepath()
    try:
        return bool(_suite_storage.atomic_write_json(
            path, _props_to_dict_recursive(prefs), indent=2, ensure_ascii=False
        ))
    except Exception:
        return False

def load_prefs(context=None) -> bool:
    global _LOADING, _LAST_SNAPSHOT
    prefs = get_prefs(context)
    if prefs is None:
        return False
    path = _prefs_filepath()
    if not path.exists():
        _LAST_SNAPSHOT = _snapshot(context)
        return True
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        data = None
    if isinstance(data, dict):
        _LOADING = True
        try:
            _apply_from_dict_recursive(prefs, data)
        finally:
            _LOADING = False
    _LAST_SNAPSHOT = _snapshot(context)
    return isinstance(data, dict)
