# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Strict, revisioned and durable JSON transactions for Smart Workspace Suite.

The module deliberately has no Blender dependency.  It is used by both runtime
code and the static fault-injection audit.  Wall-clock timestamps are diagnostic
only; authority is determined by validated schema, monotonic revision,
writer_id, and payload checksum.
"""

from __future__ import annotations

import copy
import errno
import dataclasses
import datetime as _datetime
import hashlib
import json
import math
import os
import tempfile
import threading
import uuid
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

PACKAGE_ID = "smart_workspace_suite"
# Member name of the N-panel current settings inside Smart_Workspace_Suite.json.
CURRENT_KEY = "n-panel_manager/current_settings"
# Member names written by builds before the single-file layout (read only).
LEGACY_CURRENT_KEY_SUFFIX = CURRENT_KEY + ".json"
CURRENT_SCHEMA = "NPTL_CURRENT_SETTINGS"
CURRENT_ROLE = "n_panel_manager_current_settings"
CURRENT_SCHEMA_VERSION = 9
CENTRAL_SCHEMA = "SWS_CENTRAL_SETTINGS"
CENTRAL_SCHEMA_VERSION = 2
CONTRACT_NAME = "SWS_ATOMIC_STRICT_JSON"
CONTRACT_VERSION = 1
MAX_WRITER_ID_LENGTH = 160
MAX_JSON_BYTES = 64 * 1024 * 1024
MAX_CENTRAL_FILES = 4096
MAX_CENTRAL_KEY_LENGTH = 512
MAX_WORKSPACE_PROFILES = 256
MAX_WORKSPACE_TEMPLATES = 64
MANAGER_WORKSPACE_KEYS = (
    "LAYOUT", "MODELING", "SCULPTING", "UV_EDITING", "TEXTURE_PAINT", "SHADING",
    "ANIMATION", "RENDERING", "COMPOSITING", "GEOMETRY_NODES", "SCRIPTING",
    "ANIMATION_2D", "FULL_CANVAS_2D", "MASKING", "MOTION_TRACKING", "VIDEO_EDITING",
)
MANAGER_EDITOR_KEYS = (
    "VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR", "SHADER_EDITOR", "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR", "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR", "DOPE_SHEET", "GRAPH_EDITOR", "DRIVERS", "NLA_EDITOR",
    "TEXT_EDITOR", "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET",
)
MANAGER_TOOL_KEYS = (
    "SMART_FILE", "SMART_WORKSPACE", "SMART_OVERLAY", "SMART_PAINT", "SMART_TRANSFORM",
    "SMART_CAMLIGHT", "SMART_GEOMETRY", "SMART_ID", "SMART_MODELING", "SMART_MODIFIER",
    "SMART_SCULPT", "SMART_SHAPEKEY", "SMART_UV", "SMART_RIG", "SMART_SHADER",
    "SMART_NODE", "SMART_CLOTH", "SMART_SELECTOR", "SMART_ANIMATION", "SMART_RENDER",
    "SMART_COMPOSITE",
)
MANAGER_MATRIX_SHAPE = (len(MANAGER_WORKSPACE_KEYS), len(MANAGER_EDITOR_KEYS), len(MANAGER_TOOL_KEYS))
MANAGER_MATRIX_CELL_COUNT = MANAGER_MATRIX_SHAPE[0] * MANAGER_MATRIX_SHAPE[1] * MANAGER_MATRIX_SHAPE[2]

_CHECKSUM_EXCLUDED = frozenset({"payload_checksum", "authority", "saved_at"})
_ALLOWED_AUTHORITIES = frozenset({"primary", "backup", "central", "recovered", "memory"})
_LOCK = threading.RLock()


class ContractError(RuntimeError):
    """A strict JSON schema, checksum, revision, or durability failure."""


class CandidateInvalid(ContractError):
    """A candidate cannot participate in authority selection."""


@dataclasses.dataclass(frozen=True)
class Candidate:
    source: str
    path: str
    payload: dict[str, Any]
    revision: int
    writer_id: str
    checksum: str
    mtime_ns: int
    mtime_auxiliary: int = 0
    legacy_migrated: bool = False


@dataclasses.dataclass(frozen=True)
class AuthorityResult:
    payload: dict[str, Any] | None
    source: str
    repaired_primary: bool
    candidates: tuple[Candidate, ...]
    invalid_sources: tuple[str, ...]

    @property
    def valid(self) -> bool:
        return isinstance(self.payload, dict)


def utc_diagnostic_timestamp() -> str:
    return _datetime.datetime.now(_datetime.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def new_writer_id(prefix: str = PACKAGE_ID) -> str:
    clean = "".join(ch for ch in str(prefix or PACKAGE_ID) if ch.isalnum() or ch in "._-")[:64]
    return f"{clean}:{os.getpid()}:{uuid.uuid4().hex}"


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def strict_bool(value: Any, *, default: bool | None = None, field: str = "boolean") -> bool:
    if isinstance(value, bool):
        return value
    if value is None and isinstance(default, bool):
        return default
    raise CandidateInvalid(f"{field} must be a JSON boolean")


def _strict_revision(value: Any, *, default: int | None = None) -> int:
    if _is_int(value) and value >= 1:
        return int(value)
    if value is None and _is_int(default) and int(default) >= 1:
        return int(default)
    raise CandidateInvalid("revision must be a positive JSON integer")


def _strict_writer_id(value: Any, *, default: str | None = None) -> str:
    text = value if isinstance(value, str) else default
    if not isinstance(text, str):
        raise CandidateInvalid("writer_id must be a string")
    text = text.strip()
    if not text or len(text) > MAX_WRITER_ID_LENGTH or "\x00" in text:
        raise CandidateInvalid("writer_id is empty or invalid")
    return text


def _reject_nonfinite_json_constant(value: str) -> None:
    raise CandidateInvalid(f"non-finite JSON number is forbidden: {value}")


def _reject_duplicate_object_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise CandidateInvalid(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def _parse_strict_json_float(value: str) -> float:
    try:
        parsed = float(value)
    except Exception as exc:
        raise CandidateInvalid(f"invalid JSON number: {value}") from exc
    if not math.isfinite(parsed):
        raise CandidateInvalid(f"non-finite JSON number is forbidden: {value}")
    return parsed


def strict_json_loads(text: str, *, source: str = "JSON") -> Any:
    """Decode strict UTF-8 JSON text with duplicate/non-finite rejection."""
    if not isinstance(text, str):
        raise CandidateInvalid(f"{source}: JSON text must be a string")
    try:
        return json.loads(
            text,
            object_pairs_hook=_reject_duplicate_object_keys,
            parse_constant=_reject_nonfinite_json_constant,
            parse_float=_parse_strict_json_float,
        )
    except CandidateInvalid:
        raise
    except json.JSONDecodeError as exc:
        raise CandidateInvalid(f"{source}: invalid JSON syntax") from exc
    except Exception as exc:
        raise CandidateInvalid(f"{source}: strict JSON decode failed: {exc}") from exc


def read_json_document(path: str | Path) -> Any:
    """Read one bounded strict UTF-8 JSON document without accepting duplicates."""
    value, _mtime_ns = _read_json_file(Path(path))
    return value


def _copy_json_graph(value: Any) -> Any:
    try:
        # JSON round-trip rejects non-finite and non-JSON values instead of
        # silently stringifying them, which is required for a strict contract.
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        return strict_json_loads(encoded, source="payload")
    except Exception as exc:
        if isinstance(exc, CandidateInvalid):
            raise
        raise CandidateInvalid(f"payload is not strict JSON: {exc}") from exc


def _semantic_graph(payload: Mapping[str, Any]) -> dict[str, Any]:
    graph = {
        str(key): value
        for key, value in payload.items()
        if str(key) not in _CHECKSUM_EXCLUDED
    }
    return _copy_json_graph(graph)


def canonical_json_bytes(value: Any, *, pretty: bool = False) -> bytes:
    graph = _copy_json_graph(value)
    if pretty:
        text = json.dumps(
            graph,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            indent=2,
            separators=(",", ": "),
        ) + "\n"
    else:
        text = json.dumps(
            graph,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    return text.encode("utf-8")


def payload_checksum(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_json_bytes(_semantic_graph(payload), pretty=False)).hexdigest()


def _valid_checksum_text(value: Any) -> str:
    if not isinstance(value, str):
        raise CandidateInvalid("payload_checksum must be a string")
    text = value.strip().lower()
    if len(text) != 64 or any(ch not in "0123456789abcdef" for ch in text):
        raise CandidateInvalid("payload_checksum must be a SHA-256 hex digest")
    return text


def _normalize_ui_state(data: dict[str, Any]) -> None:
    ui_state = data.get("ui_state")
    if ui_state is None:
        ui_state = {}
        data["ui_state"] = ui_state
    if not isinstance(ui_state, dict):
        raise CandidateInvalid("ui_state must be an object")
    if "n_panel_state_save_enabled" in ui_state:
        ui_state["n_panel_state_save_enabled"] = strict_bool(
            ui_state.get("n_panel_state_save_enabled"),
            field="ui_state.n_panel_state_save_enabled",
        )
    else:
        # Every migration/import path uses the same policy default.  A missing
        # value must never silently disable persistence.
        ui_state["n_panel_state_save_enabled"] = True


def _uuid_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    text = value.strip()
    try:
        return str(uuid.UUID(text))
    except Exception:
        return ""


def _normalize_manager_rule_matrix(value: Any) -> dict[str, Any]:
    source = value if isinstance(value, dict) else {}
    normalized: dict[str, Any] = {}
    for workspace_key in MANAGER_WORKSPACE_KEYS:
        workspace_source = source.get(workspace_key)
        workspace_source = workspace_source if isinstance(workspace_source, dict) else {}
        editor_result: dict[str, Any] = {}
        for editor_key in MANAGER_EDITOR_KEYS:
            editor_source = workspace_source.get(editor_key)
            editor_source = editor_source if isinstance(editor_source, dict) else {}
            editor_result[editor_key] = {
                tool_key: editor_source.get(tool_key) if isinstance(editor_source.get(tool_key), bool) else False
                for tool_key in MANAGER_TOOL_KEYS
            }
        normalized[workspace_key] = editor_result
    return normalized


def _validate_manager_rule_matrix(data: Mapping[str, Any], *, source: str) -> None:
    shape = data.get("manager_matrix_shape")
    if not isinstance(shape, list) or len(shape) != 3 or any(not _is_int(item) for item in shape):
        raise CandidateInvalid(f"{source}: manager_matrix_shape must be three JSON integers")
    if tuple(int(item) for item in shape) != MANAGER_MATRIX_SHAPE:
        raise CandidateInvalid(f"{source}: manager_matrix_shape mismatch")
    matrix = data.get("manager_rule_matrix")
    if not isinstance(matrix, dict) or set(matrix) != set(MANAGER_WORKSPACE_KEYS):
        raise CandidateInvalid(f"{source}: manager workspace keys mismatch")
    cell_count = 0
    for workspace_key in MANAGER_WORKSPACE_KEYS:
        editors = matrix.get(workspace_key)
        if not isinstance(editors, dict) or set(editors) != set(MANAGER_EDITOR_KEYS):
            raise CandidateInvalid(f"{source}: manager editor keys mismatch at {workspace_key}")
        for editor_key in MANAGER_EDITOR_KEYS:
            tools = editors.get(editor_key)
            if not isinstance(tools, dict) or set(tools) != set(MANAGER_TOOL_KEYS):
                raise CandidateInvalid(f"{source}: manager tool keys mismatch at {workspace_key}/{editor_key}")
            for tool_key in MANAGER_TOOL_KEYS:
                if not isinstance(tools.get(tool_key), bool):
                    raise CandidateInvalid(f"{source}: manager cell must be Boolean at {workspace_key}/{editor_key}/{tool_key}")
                cell_count += 1
    if cell_count != MANAGER_MATRIX_CELL_COUNT:
        raise CandidateInvalid(f"{source}: manager matrix cell count mismatch")


def _profile_source_list(data: Mapping[str, Any]) -> list[dict[str, Any]]:
    profiles = data.get("workspace_profiles")
    result: list[dict[str, Any]] = []
    if isinstance(profiles, list):
        if any(not isinstance(item, dict) for item in profiles):
            raise CandidateInvalid("workspace profile entry must be an object")
        result.extend(copy.deepcopy(item) for item in profiles)
    elif isinstance(profiles, dict):
        for key, item in profiles.items():
            if not isinstance(item, dict):
                raise CandidateInvalid("workspace profile entry must be an object")
            entry = copy.deepcopy(item)
            if "workspace_name" not in entry:
                entry["workspace_name"] = str(key)
            result.append(entry)
    elif profiles is not None:
        raise CandidateInvalid("workspace_profiles must be an array or object")
    if not result:
        workspaces = data.get("workspaces")
        if workspaces is not None and not isinstance(workspaces, dict):
            raise CandidateInvalid("workspaces must be an object")
        if isinstance(workspaces, dict):
            for key, item in workspaces.items():
                if not isinstance(item, dict):
                    raise CandidateInvalid("workspace index entry must be an object")
                entry = copy.deepcopy(item)
                if "workspace_name" not in entry:
                    entry["workspace_name"] = str(key)
                result.append(entry)
    return result


def _normalize_workspace_profiles(data: Mapping[str, Any]) -> list[dict[str, Any]]:
    raw_profiles = _profile_source_list(data)
    if len(raw_profiles) > MAX_WORKSPACE_PROFILES:
        raise CandidateInvalid("workspace profile count exceeds bounded limit")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_profiles):
        profile = _copy_json_graph(raw)
        name_value = profile.get("workspace_name", profile.get("display_name", ""))
        if not isinstance(name_value, str):
            raise CandidateInvalid("workspace profile display name must be a string")
        name = name_value
        identity = _uuid_text(profile.get("workspace_uuid"))
        legacy_identity = False
        if not identity:
            # One-time legacy migration identity.  The explicit marker is part
            # of the checksummed payload and is the only condition under which
            # Blender-side reconciliation may match this profile by display
            # name.  A real UUID is never rebound to a same-name workspace.
            identity = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{PACKAGE_ID}:legacy-workspace:{name}:{index}"))
            legacy_identity = True
        elif "workspace_uuid_legacy_migration" in profile:
            legacy_identity = strict_bool(
                profile.get("workspace_uuid_legacy_migration"),
                field="workspace_uuid_legacy_migration",
            )
        if identity in seen:
            raise CandidateInvalid("workspace profile UUID must be unique")
        seen.add(identity)
        profile["workspace_uuid"] = identity
        if legacy_identity:
            profile["workspace_uuid_legacy_migration"] = True
        else:
            profile.pop("workspace_uuid_legacy_migration", None)
        profile["workspace_name"] = name
        if "display_name" not in profile:
            profile["display_name"] = name
        elif not isinstance(profile.get("display_name"), str):
            raise CandidateInvalid("workspace profile display_name must be a string")
        result.append(profile)
    return result


def _validate_workspace_profiles(data: Mapping[str, Any], *, source: str) -> None:
    profiles = data.get("workspace_profiles")
    if not isinstance(profiles, list):
        raise CandidateInvalid(f"{source}: workspace_profiles must be an array")
    if len(profiles) > MAX_WORKSPACE_PROFILES:
        raise CandidateInvalid(f"{source}: workspace profile count exceeds bounded limit")
    seen: set[str] = set()
    names: set[str] = set()
    for profile in profiles:
        if not isinstance(profile, dict):
            raise CandidateInvalid(f"{source}: workspace profile entry must be an object")
        identity = _uuid_text(profile.get("workspace_uuid"))
        if not identity or identity in seen:
            raise CandidateInvalid(f"{source}: workspace profile UUID missing or duplicated")
        seen.add(identity)
        name = profile.get("workspace_name")
        display_name = profile.get("display_name")
        if "workspace_uuid_legacy_migration" in profile:
            strict_bool(
                profile.get("workspace_uuid_legacy_migration"),
                field=f"{source}.workspace_uuid_legacy_migration",
            )
        if not isinstance(name, str) or not isinstance(display_name, str):
            raise CandidateInvalid(f"{source}: workspace profile names must be strings")
        if name in names:
            raise CandidateInvalid(f"{source}: workspace profile display name duplicated")
        names.add(name)
    workspaces = data.get("workspaces")
    if not isinstance(workspaces, dict):
        raise CandidateInvalid(f"{source}: workspaces must be an object")
    if set(workspaces) != names:
        raise CandidateInvalid(f"{source}: workspaces/profile display-name index mismatch")
    for name, profile in workspaces.items():
        if not isinstance(profile, dict) or profile.get("workspace_uuid") not in seen:
            raise CandidateInvalid(f"{source}: workspace index entry mismatch for {name}")


def _normalize_workspace_templates(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise CandidateInvalid("workspace_templates must be an object")
    entries = list(value.items())[-MAX_WORKSPACE_TEMPLATES:]
    result: dict[str, Any] = {}
    for key, item in entries:
        text = str(key)
        if not text or len(text) > 160 or not isinstance(item, dict):
            raise CandidateInvalid("workspace template entry is invalid")
        result[text] = _copy_json_graph(item)
    return result


def _validate_current_semantics(data: Mapping[str, Any], *, source: str) -> None:
    ui_state = data.get("ui_state")
    if not isinstance(ui_state, dict):
        raise CandidateInvalid(f"{source}: ui_state must be an object")
    strict_bool(ui_state.get("n_panel_state_save_enabled"), field=f"{source}.ui_state.n_panel_state_save_enabled")
    _validate_workspace_profiles(data, source=source)
    templates = data.get("workspace_templates")
    if not isinstance(templates, dict) or len(templates) > MAX_WORKSPACE_TEMPLATES:
        raise CandidateInvalid(f"{source}: workspace_templates invalid or unbounded")
    for key, item in templates.items():
        if not isinstance(key, str) or not key or len(key) > 160 or not isinstance(item, dict):
            raise CandidateInvalid(f"{source}: workspace template entry invalid")
    _validate_manager_rule_matrix(data, source=source)


def _recognize_legacy_current(data: Mapping[str, Any]) -> bool:
    schema = data.get("schema")
    role = data.get("role")
    addon = data.get("addon")
    if schema in {CURRENT_SCHEMA, "NPTL_V1"}:
        return addon in {None, "", PACKAGE_ID} and role in {None, "", CURRENT_ROLE}
    # Very old flat exports are accepted only when they contain known N-panel
    # fields, never for an arbitrary JSON object.
    known = {"workspaces", "workspace_profiles", "categories", "detected", "detected_tabs", "ui_state"}
    return bool(known.intersection(data.keys())) and addon in {None, "", PACKAGE_ID}


def finalize_current_payload(
    value: Mapping[str, Any],
    *,
    revision: int,
    writer_id: str,
    authority: str = "primary",
    preserve_saved_at: bool = False,
) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CandidateInvalid("current payload must be an object")
    data = _copy_json_graph(dict(value))
    if not _recognize_legacy_current(data):
        raise CandidateInvalid("current payload schema is not recognized")
    profiles = _normalize_workspace_profiles(data)
    data["workspace_profiles"] = profiles
    data["workspaces"] = {
        str(profile["workspace_name"]): copy.deepcopy(profile)
        for profile in profiles
    }
    data["workspace_templates"] = _normalize_workspace_templates(data.get("workspace_templates"))
    data["manager_rule_matrix"] = _normalize_manager_rule_matrix(data.get("manager_rule_matrix"))
    data["manager_matrix_shape"] = list(MANAGER_MATRIX_SHAPE)
    _normalize_ui_state(data)
    data["schema"] = CURRENT_SCHEMA
    data["schema_version"] = CURRENT_SCHEMA_VERSION
    data["addon"] = PACKAGE_ID
    data["role"] = CURRENT_ROLE
    data["contract"] = CONTRACT_NAME
    data["contract_version"] = CONTRACT_VERSION
    data["revision"] = _strict_revision(revision)
    data["writer_id"] = _strict_writer_id(writer_id)
    authority_text = str(authority or "primary").strip().lower()
    if authority_text not in _ALLOWED_AUTHORITIES:
        raise CandidateInvalid("authority is invalid")
    data["authority"] = authority_text
    if not preserve_saved_at or not isinstance(data.get("saved_at"), str):
        data["saved_at"] = utc_diagnostic_timestamp()
    data.pop("payload_checksum", None)
    data["payload_checksum"] = payload_checksum(data)
    _validate_current_semantics(data, source="finalize")
    return data


def validate_current_payload(value: Any, *, allow_legacy: bool = False, source: str = "candidate") -> tuple[dict[str, Any], bool]:
    if not isinstance(value, dict):
        raise CandidateInvalid(f"{source}: current JSON root must be an object")
    data = _copy_json_graph(value)
    strict_contract = data.get("contract") == CONTRACT_NAME or any(
        name in data for name in ("revision", "writer_id", "payload_checksum", "contract_version")
    )
    if strict_contract:
        if data.get("contract") != CONTRACT_NAME:
            raise CandidateInvalid(f"{source}: contract name mismatch")
        if data.get("contract_version") != CONTRACT_VERSION:
            raise CandidateInvalid(f"{source}: contract version mismatch")
        if data.get("schema") != CURRENT_SCHEMA or data.get("role") != CURRENT_ROLE or data.get("addon") != PACKAGE_ID:
            raise CandidateInvalid(f"{source}: current schema/role/addon mismatch")
        schema_version = data.get("schema_version")
        if not _is_int(schema_version) or int(schema_version) < 1 or int(schema_version) > CURRENT_SCHEMA_VERSION:
            raise CandidateInvalid(f"{source}: schema_version mismatch")
        revision = _strict_revision(data.get("revision"))
        writer_id = _strict_writer_id(data.get("writer_id"))
        authority = data.get("authority")
        if not isinstance(authority, str) or authority.strip().lower() not in _ALLOWED_AUTHORITIES:
            raise CandidateInvalid(f"{source}: authority is invalid")
        expected = _valid_checksum_text(data.get("payload_checksum"))
        actual = payload_checksum(data)
        if expected != actual:
            raise CandidateInvalid(f"{source}: checksum mismatch")
        if int(schema_version) != CURRENT_SCHEMA_VERSION:
            if not allow_legacy:
                raise CandidateInvalid(f"{source}: old strict schema requires migration")
            migrated = finalize_current_payload(
                data,
                revision=revision,
                writer_id=writer_id,
                authority="recovered",
                preserve_saved_at=True,
            )
            return migrated, True
        _validate_current_semantics(data, source=source)
        return data, False
    if not allow_legacy or not _recognize_legacy_current(data):
        raise CandidateInvalid(f"{source}: missing strict contract/checksum")
    # A recognized pre-contract payload is schema-validated and migrated in
    # memory.  Missing State Save is always migrated to True.
    if "workspaces" in data and not isinstance(data.get("workspaces"), dict):
        raise CandidateInvalid(f"{source}: legacy workspaces must be an object")
    if "workspace_profiles" in data and not isinstance(data.get("workspace_profiles"), (list, dict)):
        raise CandidateInvalid(f"{source}: legacy workspace_profiles invalid")
    revision = data.get("revision") if _is_int(data.get("revision")) and int(data["revision"]) >= 1 else 1
    writer = data.get("writer_id") if isinstance(data.get("writer_id"), str) and data["writer_id"].strip() else "legacy-migration"
    return finalize_current_payload(data, revision=int(revision), writer_id=str(writer), authority="recovered", preserve_saved_at=True), True


def is_current_key(key: Any) -> bool:
    """Return whether a central member name holds the N-panel current settings."""
    text = str(key or "").replace("\\", "/").strip("/").lower()
    return (
        text == CURRENT_KEY
        or text.endswith("/" + CURRENT_KEY)
        or text.endswith(LEGACY_CURRENT_KEY_SUFFIX)
    )


def _central_current_entries(files: Mapping[str, Any]) -> Iterable[tuple[str, Any]]:
    for key, value in files.items():
        if is_current_key(key):
            yield str(key), value


def _validate_central_file_key(key: Any, *, source: str) -> str:
    if not isinstance(key, str):
        raise CandidateInvalid(f"{source}: central file key must be a string")
    text = key.replace("\\", "/")
    if (
        not text
        or len(text) > MAX_CENTRAL_KEY_LENGTH
        or "\x00" in text
        or text.startswith("/")
        or text.endswith("/")
        or any(part in {"", ".", ".."} for part in text.split("/"))
        or ":" in text.split("/", 1)[0]
    ):
        raise CandidateInvalid(f"{source}: unsafe central file key")
    return text


def _validate_central_semantics(
    data: Mapping[str, Any],
    *,
    source: str,
    allow_legacy_current: bool = False,
) -> None:
    files = data.get("files")
    if not isinstance(files, dict):
        raise CandidateInvalid(f"{source}: files must be an object")
    if len(files) > MAX_CENTRAL_FILES:
        raise CandidateInvalid(f"{source}: central file count exceeds bounded limit")
    current_entries: list[tuple[str, dict[str, Any]]] = []
    for key, value in files.items():
        clean_key = _validate_central_file_key(key, source=source)
        # Reject non-JSON and non-finite sidecar graphs even when they are not
        # interpreted by this module.  The envelope checksum must cover a strict
        # finite JSON graph only.
        _copy_json_graph(value)
        if is_current_key(clean_key):
            embedded, _legacy = validate_current_payload(
                value,
                allow_legacy=allow_legacy_current,
                source=f"{source}:{clean_key}",
            )
            current_entries.append((clean_key, embedded))
    if len(current_entries) > 1:
        raise CandidateInvalid(f"{source}: multiple N-panel current authorities in central files")
    if not current_entries:
        return
    _key, embedded = current_entries[0]
    if _is_int(data.get("revision")) and int(embedded.get("revision", -1)) != int(data["revision"]):
        raise CandidateInvalid(f"{source}: embedded current revision mismatch")
    if isinstance(data.get("writer_id"), str) and embedded.get("writer_id") != data.get("writer_id"):
        raise CandidateInvalid(f"{source}: embedded current writer_id mismatch")
    enabled = strict_bool(
        data.get("n_panel_state_save_enabled"),
        default=True,
        field=f"{source}.n_panel_state_save_enabled",
    )
    ui_state = embedded.get("ui_state")
    if not isinstance(ui_state, dict):
        raise CandidateInvalid(f"{source}: embedded current ui_state missing")
    if strict_bool(
        ui_state.get("n_panel_state_save_enabled"),
        field=f"{source}.embedded.ui_state.n_panel_state_save_enabled",
    ) != enabled:
        raise CandidateInvalid(f"{source}: embedded current State Save policy mismatch")


def finalize_central_payload(
    value: Mapping[str, Any] | None,
    *,
    revision: int,
    writer_id: str,
    state_save_enabled: bool,
) -> dict[str, Any]:
    data = _copy_json_graph(dict(value or {}))
    files = data.get("files")
    if files is None:
        files = {}
    if not isinstance(files, dict):
        raise CandidateInvalid("central files must be an object")
    if len(files) > MAX_CENTRAL_FILES:
        raise CandidateInvalid("central file count exceeds bounded limit")
    revision_value = _strict_revision(revision)
    writer_value = _strict_writer_id(writer_id)
    enabled_value = strict_bool(state_save_enabled, field="n_panel_state_save_enabled")
    normalized_files = _copy_json_graph(files)
    current_entries = list(_central_current_entries(normalized_files))
    if len(current_entries) > 1:
        raise CandidateInvalid("multiple N-panel current authorities in central files")
    if current_entries:
        current_key, current_value = current_entries[0]
        embedded, _legacy = validate_current_payload(
            current_value, allow_legacy=True, source=f"finalize-central:{current_key}"
        )
        embedded_ui = embedded.get("ui_state")
        if not isinstance(embedded_ui, dict):
            embedded_ui = {}
            embedded["ui_state"] = embedded_ui
        embedded_ui["n_panel_state_save_enabled"] = enabled_value
        normalized_files[current_key] = finalize_current_payload(
            embedded,
            revision=revision_value,
            writer_id=writer_value,
            authority="central",
        )
    data["files"] = normalized_files
    data["schema"] = CENTRAL_SCHEMA
    data["schema_version"] = CENTRAL_SCHEMA_VERSION
    data["addon"] = PACKAGE_ID
    data["settings_file"] = "Smart_Workspace_Suite.json"
    data["contract"] = CONTRACT_NAME
    data["contract_version"] = CONTRACT_VERSION
    data["revision"] = revision_value
    data["writer_id"] = writer_value
    data["authority"] = "central"
    data["n_panel_state_save_enabled"] = enabled_value
    data["saved_at"] = utc_diagnostic_timestamp()
    data.pop("payload_checksum", None)
    data["payload_checksum"] = payload_checksum(data)
    _validate_central_semantics(data, source="finalize-central", allow_legacy_current=False)
    return data


def validate_central_payload(value: Any, *, allow_legacy: bool = False, source: str = "central") -> tuple[dict[str, Any], bool]:
    if not isinstance(value, dict):
        raise CandidateInvalid(f"{source}: central root must be an object")
    data = _copy_json_graph(value)
    strict_contract = data.get("contract") == CONTRACT_NAME or any(
        name in data for name in ("revision", "writer_id", "payload_checksum", "contract_version")
    )
    if strict_contract:
        if data.get("contract") != CONTRACT_NAME or data.get("contract_version") != CONTRACT_VERSION:
            raise CandidateInvalid(f"{source}: central contract mismatch")
        if data.get("schema") != CENTRAL_SCHEMA or data.get("addon") != PACKAGE_ID:
            raise CandidateInvalid(f"{source}: central schema/addon mismatch")
        schema_version = data.get("schema_version")
        if not _is_int(schema_version) or int(schema_version) < 1 or int(schema_version) > CENTRAL_SCHEMA_VERSION:
            raise CandidateInvalid(f"{source}: central schema_version mismatch")
        if not isinstance(data.get("files"), dict):
            raise CandidateInvalid(f"{source}: files must be an object")
        enabled = strict_bool(data.get("n_panel_state_save_enabled"), field="central.n_panel_state_save_enabled")
        revision = _strict_revision(data.get("revision"))
        writer_id = _strict_writer_id(data.get("writer_id"))
        authority = data.get("authority")
        if authority != "central":
            raise CandidateInvalid(f"{source}: central authority mismatch")
        expected = _valid_checksum_text(data.get("payload_checksum"))
        actual = payload_checksum(data)
        if expected != actual:
            raise CandidateInvalid(f"{source}: checksum mismatch")
        if int(schema_version) != CENTRAL_SCHEMA_VERSION:
            if not allow_legacy:
                raise CandidateInvalid(f"{source}: old strict central schema requires migration")
            return finalize_central_payload(
                data, revision=revision, writer_id=writer_id, state_save_enabled=enabled
            ), True
        _validate_central_semantics(data, source=source, allow_legacy_current=False)
        return data, False
    if not allow_legacy:
        raise CandidateInvalid(f"{source}: missing strict central contract/checksum")
    if data.get("addon") not in {None, "", PACKAGE_ID}:
        raise CandidateInvalid(f"{source}: legacy central addon mismatch")
    if not isinstance(data.get("files", {}), dict):
        raise CandidateInvalid(f"{source}: legacy central files invalid")
    enabled = strict_bool(data.get("n_panel_state_save_enabled"), default=True, field="central.n_panel_state_save_enabled")
    revision = data.get("revision") if _is_int(data.get("revision")) and int(data["revision"]) >= 1 else 1
    writer = data.get("writer_id") if isinstance(data.get("writer_id"), str) and data["writer_id"].strip() else "legacy-central-migration"
    return finalize_central_payload(data, revision=int(revision), writer_id=str(writer), state_save_enabled=enabled), True


def _read_json_file(path: Path) -> tuple[Any, int]:
    stat = path.stat()
    if int(stat.st_size) > MAX_JSON_BYTES:
        raise CandidateInvalid(f"{path}: JSON exceeds {MAX_JSON_BYTES} bytes")
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise CandidateInvalid(f"{path}: invalid UTF-8") from exc
    value = strict_json_loads(text, source=str(path))
    return value, int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))


def _validated_mtime_auxiliary(payload: Mapping[str, Any], mtime_ns: int) -> int:
    """Use mtime only for a validated candidate lacking saved_at metadata."""
    saved_at = payload.get("saved_at")
    return int(mtime_ns) if not isinstance(saved_at, str) or not saved_at.strip() else 0


def read_current_candidate(path: str | Path, source: str, *, allow_legacy: bool = False) -> Candidate:
    target = Path(path)
    value, mtime_ns = _read_json_file(target)
    payload, legacy = validate_current_payload(value, allow_legacy=allow_legacy, source=source)
    return Candidate(
        source=source,
        path=str(target),
        payload=payload,
        revision=int(payload["revision"]),
        writer_id=str(payload["writer_id"]),
        checksum=str(payload["payload_checksum"]),
        mtime_ns=mtime_ns,
        mtime_auxiliary=_validated_mtime_auxiliary(payload, mtime_ns),
        legacy_migrated=legacy,
    )


def _fsync_directory(path: Path) -> None:
    """Sync an atomic-replace directory without hiding real I/O failures.

    Python cannot portably fsync directory handles on Windows.  Only that
    platform limitation and filesystem-level unsupported-operation errors are
    ignored.  Permission, disk, device, and antivirus-induced failures on
    supported platforms propagate to the caller.
    """
    flags = getattr(os, "O_RDONLY", 0) | getattr(os, "O_DIRECTORY", 0)
    fd = None
    try:
        fd = os.open(str(path), flags)
        os.fsync(fd)
    except AttributeError:
        return
    except OSError as exc:
        unsupported = {
            getattr(errno, "EINVAL", -1),
            getattr(errno, "ENOTSUP", -1),
            getattr(errno, "EOPNOTSUPP", -1),
            getattr(errno, "ENOSYS", -1),
            getattr(errno, "EBADF", -1),
        }
        # CPython/Windows does not expose a portable directory handle suitable
        # for fsync; the file itself has already been flushed and fsynced.
        if os.name == "nt" or exc.errno in unsupported:
            return
        raise
    finally:
        if fd is not None:
            os.close(fd)


def _unique_diagnostic_path(target: Path) -> Path:
    stamp = _datetime.datetime.now(_datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    return target.with_name(f"{target.name}.corrupt.{stamp}.{uuid.uuid4().hex}.json")


def preserve_corrupt_file(path: str | Path) -> Path | None:
    """Retain corrupt bytes once per content digest without replacing source."""
    target = Path(path)
    if not target.exists() or not target.is_file():
        return None
    raw = target.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    diagnostic = target.with_name(f"{target.name}.corrupt.{digest}.json")
    if diagnostic.exists():
        try:
            if diagnostic.read_bytes() == raw:
                return diagnostic
        except Exception:
            pass
        # A collision or damaged diagnostic gets a unique suffix; the source and
        # last-known-good backup are still never altered by this preservation.
        diagnostic = _unique_diagnostic_path(target)
    _atomic_replace_raw(diagnostic, raw)
    return diagnostic


def _atomic_replace_raw(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=str(path.parent),
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            tmp = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(str(tmp), str(path))
        tmp = None
        _fsync_directory(path.parent)
    finally:
        if tmp is not None:
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass


def _durable_write_json_details(
    path: str | Path,
    payload: Mapping[str, Any],
    *,
    validator: Callable[..., tuple[dict[str, Any], bool]],
    backup: bool = True,
    expected_revision: int | None = None,
    expected_writer_id: str | None = None,
    expected_checksum: str | None = None,
) -> dict[str, Any]:
    """Write, flush, fsync, replace, and strictly read back one JSON file.

    A previous *validated* primary is the only value promoted to ``.bak``.
    Invalid bytes are preserved under a unique diagnostic name and never
    overwrite the last known-good backup.
    """
    target = Path(path)
    with _LOCK:
        target.parent.mkdir(parents=True, exist_ok=True)
        previous_valid: bytes | None = None
        if target.exists():
            try:
                previous_value, _ = _read_json_file(target)
                validator(previous_value, allow_legacy=False, source=f"previous:{target.name}")
                previous_valid = target.read_bytes()
            except Exception:
                preserve_corrupt_file(target)
        if backup and previous_valid is not None:
            _atomic_replace_raw(target.with_name(target.name + ".bak"), previous_valid)
        raw = canonical_json_bytes(payload, pretty=True)
        _atomic_replace_raw(target, raw)
        readback_raw = target.read_bytes()
        if readback_raw != raw:
            raise ContractError("durable JSON byte readback mismatch")
        value, _ = _read_json_file(target)
        verified, _legacy = validator(value, allow_legacy=False, source=f"readback:{target.name}")
        if expected_revision is not None and int(verified.get("revision", -1)) != int(expected_revision):
            raise ContractError("readback revision mismatch")
        if expected_writer_id is not None and verified.get("writer_id") != expected_writer_id:
            raise ContractError("readback writer_id mismatch")
        if expected_checksum is not None and verified.get("payload_checksum") != expected_checksum:
            raise ContractError("readback checksum mismatch")
        return verified



_DURABLE_WRITE_RESULT_LOCAL = threading.local()


def last_durable_write_result() -> dict[str, Any] | None:
    value = getattr(_DURABLE_WRITE_RESULT_LOCAL, 'value', None)
    return copy.deepcopy(value) if isinstance(value, dict) else None


def durable_write_json(
    path: str | Path,
    payload: Mapping[str, Any],
    *,
    validator: Callable[..., tuple[dict[str, Any], bool]],
    backup: bool = True,
    expected_revision: int | None = None,
    expected_writer_id: str | None = None,
    expected_checksum: str | None = None,
) -> bool:
    """Durably write strict JSON and return Boolean verified success."""
    _DURABLE_WRITE_RESULT_LOCAL.value = None
    verified = _durable_write_json_details(
        path, payload, validator=validator, backup=backup,
        expected_revision=expected_revision,
        expected_writer_id=expected_writer_id,
        expected_checksum=expected_checksum,
    )
    if not isinstance(verified, dict):
        raise ContractError('durable JSON readback result unavailable')
    _DURABLE_WRITE_RESULT_LOCAL.value = copy.deepcopy(verified)
    return True

def _candidate_from_central(central_path: Path, current_key: str) -> Candidate | None:
    value, mtime_ns = _read_json_file(central_path)
    central, _legacy = validate_central_payload(value, allow_legacy=False, source="central-envelope")
    files = central.get("files", {})
    candidates = []
    if current_key in files:
        candidates.append((current_key, files[current_key]))
    candidates.extend((key, value) for key, value in _central_current_entries(files) if key != current_key)
    for key, embedded in candidates:
        try:
            payload, legacy = validate_current_payload(embedded, allow_legacy=False, source=f"central:{key}")
            if not legacy:
                if int(payload.get("revision", -1)) != int(central.get("revision", -2)):
                    raise CandidateInvalid("central embedded revision mismatch")
                if str(payload.get("writer_id") or "") != str(central.get("writer_id") or ""):
                    raise CandidateInvalid("central embedded writer_id mismatch")
        except CandidateInvalid:
            continue
        return Candidate(
            source="central",
            path=str(central_path),
            payload=payload,
            revision=int(payload["revision"]),
            writer_id=str(payload["writer_id"]),
            checksum=str(payload["payload_checksum"]),
            mtime_ns=mtime_ns,
            mtime_auxiliary=_validated_mtime_auxiliary(payload, mtime_ns),
            legacy_migrated=legacy,
        )
    return None



def _legacy_current_candidate_from_value(
    value: Any,
    *,
    source: str,
    path: str | Path,
    mtime_ns: int,
) -> Candidate:
    """Validate one recognized legacy graph without treating time as authority."""
    had_saved_at = (
        isinstance(value, Mapping)
        and isinstance(value.get("saved_at"), str)
        and bool(value.get("saved_at", "").strip())
    )
    payload, migrated = validate_current_payload(
        value,
        allow_legacy=True,
        source=f"legacy:{source}",
    )
    if not migrated:
        # Current strict candidates are handled by resolve_current_authority.
        # Re-admitting one here would bypass its primary/fallback rules.
        raise CandidateInvalid(f"legacy:{source}: candidate does not require migration")
    return Candidate(
        source=source,
        path=str(path),
        payload=payload,
        revision=int(payload["revision"]),
        writer_id=str(payload["writer_id"]),
        checksum=str(payload["payload_checksum"]),
        mtime_ns=int(mtime_ns),
        mtime_auxiliary=0 if had_saved_at else int(mtime_ns),
        legacy_migrated=True,
    )


def _legacy_candidates_from_central(
    central_path: Path,
    current_key: str,
) -> tuple[list[Candidate], list[str]]:
    """Return schema-validated legacy current entries from one central envelope."""
    value, mtime_ns = _read_json_file(central_path)
    central, central_migrated = validate_central_payload(
        value,
        allow_legacy=True,
        source="legacy-central-envelope",
    )
    files = central.get("files", {})
    if not isinstance(files, dict):
        raise CandidateInvalid("legacy central files are invalid")
    ordered: list[tuple[str, Any]] = []
    if current_key in files:
        ordered.append((str(current_key), files[current_key]))
    ordered.extend(
        (key, embedded)
        for key, embedded in _central_current_entries(files)
        if key != current_key
    )
    candidates: list[Candidate] = []
    invalid: list[str] = []
    for key, embedded in ordered:
        try:
            had_saved_at = (
                isinstance(embedded, Mapping)
                and isinstance(embedded.get("saved_at"), str)
                and bool(embedded.get("saved_at", "").strip())
            )
            payload, embedded_migrated = validate_current_payload(
                embedded,
                allow_legacy=True,
                source=f"legacy-central:{key}",
            )
            if not (central_migrated or embedded_migrated):
                # A fully strict envelope/current pair would already have been
                # considered by resolve_current_authority.
                continue
            candidates.append(Candidate(
                source="central",
                path=str(central_path),
                payload=payload,
                revision=int(payload["revision"]),
                writer_id=str(payload["writer_id"]),
                checksum=str(payload["payload_checksum"]),
                mtime_ns=int(mtime_ns),
                mtime_auxiliary=0 if had_saved_at else int(mtime_ns),
                legacy_migrated=True,
            ))
        except Exception as exc:
            invalid.append(f"central:{key}:{type(exc).__name__}")
    return candidates, invalid


def migrate_legacy_current_authority(
    primary_path: str | Path,
    backup_path: str | Path,
    central_path: str | Path,
    current_key: str,
    *,
    legacy_paths: Iterable[str | Path] = (),
    write_primary: bool = True,
) -> AuthorityResult:
    """Migrate only after strict primary/backup/central authority is absent.

    Recognized pre-contract or older strict-schema graphs are validated in
    memory.  The newest monotonic revision wins; filesystem mtime is used only
    as a deterministic auxiliary for a validated graph that has no ``saved_at``
    diagnostic field.  Invalid strict graphs (including checksum failures) can
    never enter this path because ``allow_legacy=True`` still enforces their
    strict contract.  Source bytes are left in place or preserved as a digest
    diagnostic when the primary is atomically repaired.
    """
    primary = Path(primary_path)
    backup = Path(backup_path)
    central = Path(central_path)
    candidates: list[Candidate] = []
    invalid: list[str] = []

    for path, source in ((primary, "primary"), (backup, "backup")):
        if not path.exists():
            invalid.append(f"{source}:missing")
            continue
        try:
            value, mtime_ns = _read_json_file(path)
            candidates.append(_legacy_current_candidate_from_value(
                value,
                source=source,
                path=path,
                mtime_ns=mtime_ns,
            ))
        except Exception as exc:
            invalid.append(f"{source}:{type(exc).__name__}")

    if central.exists():
        try:
            central_candidates, central_invalid = _legacy_candidates_from_central(
                central,
                str(current_key),
            )
            candidates.extend(central_candidates)
            invalid.extend(central_invalid)
            if not central_candidates:
                invalid.append("central:no-valid-legacy-current")
        except Exception as exc:
            invalid.append(f"central:{type(exc).__name__}")
    else:
        invalid.append("central:missing")

    seen_paths = {str(primary.resolve()), str(backup.resolve()), str(central.resolve())}
    for index, raw_path in enumerate(tuple(legacy_paths)):
        path = Path(raw_path)
        try:
            resolved = str(path.resolve())
        except Exception:
            resolved = str(path)
        if resolved in seen_paths:
            continue
        seen_paths.add(resolved)
        source = f"legacy-file:{index}"
        if not path.exists():
            invalid.append(f"{source}:missing")
            continue
        try:
            value, mtime_ns = _read_json_file(path)
            candidates.append(_legacy_current_candidate_from_value(
                value,
                source=source,
                path=path,
                mtime_ns=mtime_ns,
            ))
        except Exception as exc:
            invalid.append(f"{source}:{type(exc).__name__}")

    if not candidates:
        return AuthorityResult(None, "none", False, tuple(), tuple(invalid))

    source_priority = {
        "primary": 4,
        "backup": 3,
        "central": 2,
    }
    selected = max(
        candidates,
        key=lambda item: (
            item.revision,
            item.mtime_auxiliary,
            source_priority.get(item.source, 1),
            item.writer_id,
            item.checksum,
        ),
    )
    payload = copy.deepcopy(selected.payload)
    payload["authority"] = "recovered"
    payload["payload_checksum"] = payload_checksum(payload)
    if not write_primary:
        # The caller stores the recovered graph inside the one settings file.
        return AuthorityResult(payload, selected.source, False, tuple(candidates), tuple(invalid))
    durable_write_json(
        primary,
        payload,
        validator=validate_current_payload,
        backup=True,
        expected_revision=int(payload["revision"]),
        expected_writer_id=str(payload["writer_id"]),
        expected_checksum=str(payload["payload_checksum"]),
    )
    return AuthorityResult(
        payload,
        selected.source,
        True,
        tuple(candidates),
        tuple(invalid),
    )


def resolve_current_authority(
    primary_path: str | Path,
    backup_path: str | Path,
    central_path: str | Path,
    current_key: str,
    *,
    repair_primary: bool = True,
) -> AuthorityResult:
    """Resolve primary/backup/central without using wall-clock authority.

    A validated primary is the ordinary direct authority.  Only when it is
    missing or invalid are backup and central compared by monotonic revision;
    mtime is a deterministic auxiliary tie-breaker only for validated strict
    candidates lacking diagnostic saved_at metadata, never an authority by itself.
    """
    primary = Path(primary_path)
    backup = Path(backup_path)
    central = Path(central_path)
    valid: list[Candidate] = []
    invalid: list[str] = []
    primary_candidate: Candidate | None = None
    for path, source in ((primary, "primary"), (backup, "backup")):
        if not path.exists():
            invalid.append(f"{source}:missing")
            continue
        try:
            candidate = read_current_candidate(path, source, allow_legacy=False)
            valid.append(candidate)
            if source == "primary":
                primary_candidate = candidate
        except Exception as exc:
            invalid.append(f"{source}:{type(exc).__name__}")
            try:
                preserve_corrupt_file(path)
            except Exception:
                # Preservation failure cannot promote the invalid candidate or
                # destroy a valid backup; the original corrupt bytes remain.
                pass
    if central.exists():
        try:
            central_candidate = _candidate_from_central(central, current_key)
            if central_candidate is not None:
                valid.append(central_candidate)
            else:
                invalid.append("central:no-valid-current")
        except Exception as exc:
            invalid.append(f"central:{type(exc).__name__}")
            try:
                preserve_corrupt_file(central)
            except Exception:
                pass
    else:
        invalid.append("central:missing")

    selected: Candidate | None
    if primary_candidate is not None:
        selected = primary_candidate
    else:
        fallbacks = [item for item in valid if item.source in {"backup", "central"}]
        selected = max(
            fallbacks,
            key=lambda item: (
                item.revision,
                item.mtime_auxiliary,
                1 if item.source == "backup" else 0,
                item.writer_id,
                item.checksum,
            ),
        ) if fallbacks else None
    if selected is None:
        return AuthorityResult(None, "none", False, tuple(valid), tuple(invalid))

    payload = copy.deepcopy(selected.payload)
    payload["authority"] = "primary" if selected.source == "primary" else "recovered"
    # authority/saved_at are excluded from checksum; all semantic identity fields
    # remain unchanged during a recovery repair.
    payload["payload_checksum"] = payload_checksum(payload)
    repaired = False
    if repair_primary and (selected.source != "primary" or selected.legacy_migrated):
        durable_write_json(
            primary,
            payload,
            validator=validate_current_payload,
            backup=True,
            expected_revision=int(payload["revision"]),
            expected_writer_id=str(payload["writer_id"]),
            expected_checksum=str(payload["payload_checksum"]),
        )
        repaired = True
    return AuthorityResult(payload, selected.source, repaired, tuple(valid), tuple(invalid))


def max_known_revision(
    primary_path: str | Path,
    backup_path: str | Path,
    central_path: str | Path,
    current_key: str,
) -> int:
    result = resolve_current_authority(primary_path, backup_path, central_path, current_key, repair_primary=False)
    revisions = [candidate.revision for candidate in result.candidates]
    try:
        value, _ = _read_json_file(Path(central_path))
        central, _ = validate_central_payload(value, allow_legacy=False)
        revisions.append(int(central.get("revision", 0)))
    except Exception:
        pass
    return max([0, *revisions])


def _commit_current_and_central_details(
    *,
    primary_path: str | Path,
    central_path: str | Path,
    current_key: str,
    current_payload: Mapping[str, Any],
    central_base: Mapping[str, Any] | None,
    writer_id: str,
    state_save_enabled: bool,
) -> dict[str, Any]:
    """Commit a user revision and verify both primary and central mirror.

    The primary is replaced first so an interrupted second replace cannot lose
    the user's latest settings.  Success is returned only after strict readback
    of both files and exact revision/writer/checksum agreement.  Callers must
    keep their dirty flag set on any exception.
    """
    primary = Path(primary_path)
    central = Path(central_path)
    backup = primary.with_name(primary.name + ".bak")
    with _LOCK:
        next_revision = max_known_revision(primary, backup, central, current_key) + 1
        enabled = strict_bool(state_save_enabled, field="n_panel_state_save_enabled")
        current_source = _copy_json_graph(dict(current_payload))
        current_ui = current_source.get("ui_state")
        if not isinstance(current_ui, dict):
            current_ui = {}
            current_source["ui_state"] = current_ui
        current_ui["n_panel_state_save_enabled"] = enabled
        current = finalize_current_payload(
            current_source,
            revision=next_revision,
            writer_id=writer_id,
            authority="primary",
        )
        if durable_write_json(
            primary,
            current,
            validator=validate_current_payload,
            backup=True,
            expected_revision=next_revision,
            expected_writer_id=writer_id,
            expected_checksum=current["payload_checksum"],
        ) is not True:
            raise ContractError('primary durable write did not verify')
        current_verified = last_durable_write_result()
        if not isinstance(current_verified, dict):
            raise ContractError('primary durable readback unavailable')
        base: dict[str, Any]
        if isinstance(central_base, Mapping):
            base = _copy_json_graph(dict(central_base))
        elif central.exists():
            try:
                value, _ = _read_json_file(central)
                base, _ = validate_central_payload(value, allow_legacy=False, source="central-before-commit")
            except Exception:
                preserve_corrupt_file(central)
                base = {}
        else:
            base = {}
        files = base.get("files")
        if not isinstance(files, dict):
            files = {}
        embedded = copy.deepcopy(current_verified)
        embedded["authority"] = "central"
        embedded["payload_checksum"] = payload_checksum(embedded)
        files[str(current_key)] = embedded
        base["files"] = files
        central_payload = finalize_central_payload(
            base,
            revision=next_revision,
            writer_id=writer_id,
            state_save_enabled=state_save_enabled,
        )
        if durable_write_json(
            central,
            central_payload,
            validator=validate_central_payload,
            backup=True,
            expected_revision=next_revision,
            expected_writer_id=writer_id,
            expected_checksum=central_payload["payload_checksum"],
        ) is not True:
            raise ContractError('central durable write did not verify')
        central_verified = last_durable_write_result()
        if not isinstance(central_verified, dict):
            raise ContractError('central durable readback unavailable')
        embedded_readback = central_verified.get("files", {}).get(str(current_key))
        embedded_verified, _ = validate_current_payload(
            embedded_readback,
            allow_legacy=False,
            source="central-current-readback",
        )
        for field in ("revision", "writer_id", "payload_checksum"):
            if embedded_verified.get(field) != current_verified.get(field):
                raise ContractError(f"primary/central {field} mismatch")
        if strict_bool(central_verified.get("n_panel_state_save_enabled"), field="central policy") != strict_bool(state_save_enabled):
            raise ContractError("primary/central policy mismatch")
        return {
            "success": True,
            "revision": next_revision,
            "writer_id": writer_id,
            "payload_checksum": current_verified["payload_checksum"],
            "primary": current_verified,
            "central": central_verified,
        }



_COMMIT_RESULT_LOCAL = threading.local()


def last_commit_result() -> dict[str, Any] | None:
    """Return a copy of this thread's last fully verified transaction."""
    value = getattr(_COMMIT_RESULT_LOCAL, 'value', None)
    return copy.deepcopy(value) if isinstance(value, dict) else None


def commit_current_and_central(
    *,
    primary_path: str | Path,
    central_path: str | Path,
    current_key: str,
    current_payload: Mapping[str, Any],
    central_base: Mapping[str, Any] | None,
    writer_id: str,
    state_save_enabled: bool,
) -> bool:
    """Commit and return Boolean success only after strict dual readback.

    Detailed verified fields remain available through :func:`last_commit_result`
    for the immediate caller.  Any disk, permission, sharing, replace, schema,
    checksum, revision, writer, or readback failure raises and leaves no stale
    success result.
    """
    _COMMIT_RESULT_LOCAL.value = None
    result = _commit_current_and_central_details(
        primary_path=primary_path,
        central_path=central_path,
        current_key=current_key,
        current_payload=current_payload,
        central_base=central_base,
        writer_id=writer_id,
        state_save_enabled=state_save_enabled,
    )
    if not isinstance(result, dict) or result.get('success') is not True:
        raise ContractError('strict primary/central transaction did not verify')
    _COMMIT_RESULT_LOCAL.value = copy.deepcopy(result)
    return True

def _update_central_payload_details(
    *,
    central_path: str | Path,
    base: Mapping[str, Any] | None,
    writer_id: str,
    state_save_enabled: bool,
    mutate: Callable[[dict[str, Any]], None] | None = None,
    minimum_revision: int = 0,
) -> dict[str, Any]:
    """Durably update mirrored settings with one coherent central revision.

    When a validated ``current_settings.json`` mirror is present, its revision,
    writer identity and checksum are advanced with the envelope.  This prevents
    a sidecar-only central update from leaving a stale embedded recovery value
    that can no longer satisfy the strict authority contract.
    """
    central = Path(central_path)
    with _LOCK:
        current: dict[str, Any]
        if isinstance(base, Mapping):
            current = _copy_json_graph(dict(base))
            try:
                current, _ = validate_central_payload(current, allow_legacy=False)
            except CandidateInvalid:
                current = {}
        elif central.exists():
            try:
                value, _ = _read_json_file(central)
                current, _ = validate_central_payload(value, allow_legacy=False)
            except Exception:
                preserve_corrupt_file(central)
                current = {}
        else:
            current = {}
        if callable(mutate):
            mutate(current)
        old_revision = int(current.get("revision", 0)) if _is_int(current.get("revision")) else 0
        revision = max(old_revision, int(minimum_revision or 0)) + 1
        writer = _strict_writer_id(writer_id)

        files = current.get("files")
        if not isinstance(files, dict):
            files = {}
        for key, embedded in list(files.items()):
            if not is_current_key(key):
                continue
            try:
                validated, _legacy = validate_current_payload(
                    embedded,
                    allow_legacy=False,
                    source=f"central-update:{key}",
                )
            except CandidateInvalid:
                # Preserve malformed bytes as a diagnostic central member.  They
                # are excluded by _candidate_from_central and are never promoted.
                continue
            files[key] = finalize_current_payload(
                validated,
                revision=revision,
                writer_id=writer,
                authority="central",
            )
        current["files"] = files

        payload = finalize_central_payload(
            current,
            revision=revision,
            writer_id=writer,
            state_save_enabled=state_save_enabled,
        )
        if durable_write_json(
            central,
            payload,
            validator=validate_central_payload,
            backup=True,
            expected_revision=revision,
            expected_writer_id=writer,
            expected_checksum=payload["payload_checksum"],
        ) is not True:
            raise ContractError('central update durable write did not verify')
        verified = last_durable_write_result()
        if not isinstance(verified, dict):
            raise ContractError('central update readback unavailable')
        # Every valid embedded current entry must match the central envelope.
        for key, embedded in _central_current_entries(verified.get("files", {})):
            try:
                embedded_verified, _legacy = validate_current_payload(
                    embedded,
                    allow_legacy=False,
                    source=f"central-update-readback:{key}",
                )
            except CandidateInvalid:
                continue
            if int(embedded_verified.get("revision", -1)) != revision:
                raise ContractError("central/current readback revision mismatch")
            if embedded_verified.get("writer_id") != writer:
                raise ContractError("central/current readback writer_id mismatch")
        return verified

_CENTRAL_UPDATE_RESULT_LOCAL = threading.local()


def last_central_update_result() -> dict[str, Any] | None:
    value = getattr(_CENTRAL_UPDATE_RESULT_LOCAL, 'value', None)
    return copy.deepcopy(value) if isinstance(value, dict) else None


def update_central_payload(
    *,
    central_path: str | Path,
    base: Mapping[str, Any] | None,
    writer_id: str,
    state_save_enabled: bool,
    mutate: Callable[[dict[str, Any]], None] | None = None,
    minimum_revision: int = 0,
) -> bool:
    """Update the central envelope and return Boolean verified success."""
    _CENTRAL_UPDATE_RESULT_LOCAL.value = None
    result = _update_central_payload_details(
        central_path=central_path, base=base, writer_id=writer_id,
        state_save_enabled=state_save_enabled, mutate=mutate,
        minimum_revision=minimum_revision,
    )
    if not isinstance(result, dict):
        raise ContractError('central update result unavailable')
    _CENTRAL_UPDATE_RESULT_LOCAL.value = copy.deepcopy(result)
    return True

