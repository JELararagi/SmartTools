# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Inert legacy synchronization compatibility surface.

This module deliberately does not enumerate, patch, stop, unregister, or delete
third-party add-ons, user RNA, keymaps, handlers, timers, msgbus owners, files,
or data-blocks.  The public PropertyGroup remains available for compatibility,
but no compatibility PointerProperty is installed.  Cross-reload ownership is
handled only by the Suite generation ledger at the package lifecycle boundary.
"""

from __future__ import annotations

from typing import Any

import bpy
from bpy.types import PropertyGroup
from . import runtime_ledger as _runtime_ledger

_REGISTERED = False
_CLASS_REGISTERED = False


class SWS_LegacySynchronizeWorkspacesSettings(PropertyGroup):
    active: bpy.props.BoolProperty(
        name="Legacy Synchronize Workspaces Compatibility",
        description=(
            "Disabled compatibility flag for stale standalone Synchronize Workspaces callbacks. "
            "Smart WorkSpace Suite uses its own workspace synchronization setting."
        ),
        get=lambda _self: False,
        set=lambda _self, _value: None,
    )
    shading_type: bpy.props.BoolProperty(
        name="Legacy Synchronize Shading Type Compatibility",
        description="Disabled compatibility option for stale standalone Synchronize Workspaces callbacks.",
        get=lambda _self: False,
        set=lambda _self, _value: None,
    )
    shading_settings: bpy.props.BoolProperty(
        name="Legacy Synchronize Shading Settings Compatibility",
        description="Disabled compatibility option for stale standalone Synchronize Workspaces callbacks.",
        get=lambda _self: False,
        set=lambda _self, _value: None,
    )
    overlays: bpy.props.BoolProperty(
        name="Legacy Synchronize Overlays Compatibility",
        description="Disabled compatibility option for stale standalone Synchronize Workspaces callbacks.",
        get=lambda _self: False,
        set=lambda _self, _value: None,
    )


def _safe_noop(*_args: Any, **_kwargs: Any) -> None:
    return None


def _make_safe_external_unregister(_module: Any):
    """Return an inert callable without changing the supplied module."""
    return _safe_noop


def ensure_compat_rna() -> bool:
    """Compatibility RNA is intentionally not installed."""
    return False


def cleanup_now(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"success": True, "changed": False, "reason": "third-party-state-untouched"}


def neutralize_external_sync_addons(*_args: Any, **_kwargs: Any) -> int:
    return 0


def neutralize_external_legacy_modules(*_args: Any, **_kwargs: Any) -> int:
    return 0


def _deferred_cleanup_tick() -> None:
    return None


def _watch_timer() -> None:
    return None


def _load_post(_dummy: Any = None) -> None:
    return None


def install_zero_idle_guard(*_args: Any, **_kwargs: Any) -> bool:
    """Register only this module's public class; install no runtime watcher."""
    global _CLASS_REGISTERED
    if _CLASS_REGISTERED:
        return _runtime_ledger.class_is_current(SWS_LegacySynchronizeWorkspacesSettings)
    success, _newly_registered = _runtime_ledger.register_class_exact(
        SWS_LegacySynchronizeWorkspacesSettings,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='EXTERNAL_SYNC_GUARD_CLASS',
    )
    _CLASS_REGISTERED = bool(success)
    return bool(success)


def schedule_cleanup(*_args: Any, **_kwargs: Any) -> bool:
    return False


def stop_watch_runtime() -> bool:
    global _REGISTERED
    _REGISTERED = False
    return True


def set_watch_enabled(enabled: bool) -> bool:
    """Retain the saved toggle without creating idle work."""
    global _REGISTERED
    _REGISTERED = bool(enabled)
    return True


def register(*_args: Any, **_kwargs: Any) -> bool:
    return install_zero_idle_guard()


def unregister(*_args: Any, **_kwargs: Any) -> bool:
    global _REGISTERED, _CLASS_REGISTERED
    _REGISTERED = False
    if not _CLASS_REGISTERED:
        return True
    ok = _runtime_ledger.unregister_class_exact(
        SWS_LegacySynchronizeWorkspacesSettings,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='EXTERNAL_SYNC_GUARD_CLASS',
    )
    if ok:
        _CLASS_REGISTERED = False
    return bool(ok)
