# SPDX-License-Identifier: GPL-3.0-or-later
"""Compatibility names for saved workspaces from before native suite synchronization."""

import bpy

from . import runtime_ledger

_REASON = "EXTERNAL_SYNC_GUARD_CLASS"
_REGISTERED = False
_CLASS_REGISTERED = False


def _inactive(self):
    return False


def _ignore(*args, **kwargs):
    return None


def _discard_value(self, value):
    return None


def _legacy_option(label, summary):
    return bpy.props.BoolProperty(name=label, description=summary, get=_inactive, set=_discard_value)


class SWS_LegacySynchronizeWorkspacesSettings(bpy.types.PropertyGroup):
    active: _legacy_option(
        "Legacy Synchronize Workspaces Compatibility",
        "The old compatibility switch is disabled. Smart WorkSpace Suite has its own synchronization setting.",
    )
    shading_type: _legacy_option("Legacy Synchronize Shading Type Compatibility",
                                 "The old shading type synchronization switch is disabled.")
    shading_settings: _legacy_option("Legacy Synchronize Shading Settings Compatibility",
                                     "The old shading synchronization switch is disabled.")
    overlays: _legacy_option("Legacy Synchronize Overlays Compatibility",
                             "The old overlay synchronization switch is disabled.")


def _make_safe_external_unregister(module):
    return _ignore


def ensure_compat_rna():
    return False


def cleanup_now(*args, **kwargs):
    return dict(success=True, changed=False, reason="third-party-state-untouched")


def neutralize_external_sync_addons(*args, **kwargs):
    return 0


neutralize_external_legacy_modules = neutralize_external_sync_addons
_deferred_cleanup_tick = _ignore
_watch_timer = _ignore
_load_post = _ignore


def install_zero_idle_guard(*args, **kwargs):
    global _CLASS_REGISTERED
    group = SWS_LegacySynchronizeWorkspacesSettings
    if not _CLASS_REGISTERED:
        attached, _new = runtime_ledger.register_class_exact(
            group, native_register=bpy.utils.register_class, native_unregister=bpy.utils.unregister_class,
            reason_prefix=_REASON)
        _CLASS_REGISTERED = bool(attached)
        return _CLASS_REGISTERED
    return runtime_ledger.class_is_current(group)


def schedule_cleanup(*args, **kwargs):
    return False


def set_watch_enabled(enabled):
    global _REGISTERED
    _REGISTERED = bool(enabled)
    return True


def stop_watch_runtime():
    return set_watch_enabled(False)


register = install_zero_idle_guard


def unregister(*args, **kwargs):
    global _CLASS_REGISTERED
    stop_watch_runtime()
    if not _CLASS_REGISTERED:
        return True
    released = runtime_ledger.unregister_class_exact(
        SWS_LegacySynchronizeWorkspacesSettings, native_unregister=bpy.utils.unregister_class,
        reason_prefix=_REASON)
    if released:
        _CLASS_REGISTERED = False
    return bool(released)
