# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
import importlib
import os
import sys
from typing import Any

import bpy
from . import storage as _suite_storage
from . import settings_vfs as _suite_vfs
from . import runtime_ledger as _runtime_ledger

from . import feature_toggle, loader as loader, registry as registry, ui_icons
from .translation import error_text, localized_layout, ui_pair


_REGISTERED_CLASSES: list[type] = []
_NAV_MODULE_CACHE: dict[str, object] = {}


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()


ID_FACTORY = _IdFactory()


def _unregister_registered_class_instance(cls: type) -> bool:
    """Unregister only an exact current-generation class identity."""
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return False
    return bool(_runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='UI_RUNTIME_CLASS',
    ))


def _safe_register_class(cls: type) -> bool:
    """Register and ledger one exact class without live RNA replacement."""
    if not isinstance(cls, type) or not _runtime_ledger.current_generation():
        return False
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='UI_RUNTIME_CLASS',
    )
    if not success:
        return False
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)
    return True


def _safe_unregister_registered_classes() -> bool:
    ok = True
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        if not _unregister_registered_class_instance(cls):
            ok = False
    if ok:
        _REGISTERED_CLASSES.clear()
    return ok


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'..{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass


def _tag_view3d_ui_redraw(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) in {'UI', 'WINDOW', 'TOOLS', 'HEADER'}:
                        try:
                            region.tag_redraw()
                        except Exception:
                            pass
    except Exception:
        pass


def _draw_help_button(layout, context, help_id: str, *, text: bool = True, compact: bool = False, scale: float | None = None):
    del text, compact, scale, context
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = str(help_id or 'runtime')
        return op
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass
        return None


_MANUAL_TOGGLE_TEXT: dict[str, dict[str, str]] = {
    'workspace_auto_restore': {
        'label_en': 'Auto Restore on File Load',
        'label_ja': '読込時に自動復元',
        'desc_en': 'Enable Smart Workspace restoration after Blender starts or after another .blend file is loaded. Use this when profiles, launcher categories, and saved Smart Workspace state should be restored automatically.',
        'desc_ja': 'Blender 起動後や別の .blend ファイル読込後に Smart Workspace の状態を自動復元します。プロファイル、ランチャーカテゴリー、保存済み状態を毎回自動で戻したい場合に有効化します。',
    },
    'workspace_live_pin_follow': {
        'label_en': 'Live Panel Pin Follow',
        'label_ja': 'パネルピン追従',
        'desc_en': 'Keep the panels of pinned tabs visible on the other N-panel tabs, using Blender\'s standard panel pin. A panel is pinned the next time it is drawn open. Turning this off removes the pins.',
        'desc_ja': 'ピンを付けたタブのパネルを、ほかのタブを開いている時も表示します。Blender 標準のパネルのピンを使い、パネルが開いた状態で描かれた時に付きます。無効にするとピンを外します。',
    },
    'sync_workspace_active': {
        'label_en': 'Synchronize 3D Views',
        'label_ja': '3D ビュー同期',
        'desc_en': 'Enable or disable synchronization of 3D View state between workspaces. When enabled, the related message-bus watcher and load handler are also enabled so the synchronization can react automatically.',
        'desc_ja': 'ワークスペース間の 3D ビュー状態同期を有効 / 無効にします。有効化時は同期が自動反応できるよう、関連するメッセージバス監視とロードハンドラーも有効化します。',
    },
    'panview_follow_camera': {
        'label_en': '2D Pan View Follow Active Camera',
        'label_ja': '2Dパンビューアクティブカメラ追従',
        'desc_en': 'Allow open 2D Pan View sessions to follow the scene active camera through a background dependency-graph handler only while a 2D Pan View session is active.',
        'desc_ja': '2Dパンビューセッションが開いている間だけ、依存グラフハンドラーを使って開いている2Dパンビューをシーンのアクティブカメラへ追従させます。',
    },
    'panview_show_hud': {
        'label_en': '2D Pan View HUD',
        'label_ja': '2Dパンビュー HUD',
        'desc_en': 'Show or hide the small live HUD drawn in active 2D Pan View sessions. Disable it when you want a clean capture area.',
        'desc_ja': 'アクティブな2Dパンビューセッションに描画される小さなHUDを表示 / 非表示にします。クリーンな録画領域が必要な場合は無効化してください。',
    },
    'viewport_optimizer_file_boundaries': {
        'label_en': 'Viewport Optimizer File-Boundary Hooks',
        'label_ja': 'ビューポート最適化 ファイル境界処理',
        'desc_en': 'Function: run Viewport Optimization only at file open/save/close boundaries for automatic standardization and restoration. How to use: keep this disabled for zero idle load; enable it only when you need automatic save/open behavior.',
        'desc_ja': '機能: ファイルを開く・保存する・閉じる境界で、ビューポート最適化の標準化や復帰処理を自動実行します。使い方: 待機中の負荷をゼロにしたい場合は無効のままにし、ファイル境界での自動処理が必要な場合だけ有効にします。',
    },
    'viewport_optimizer_preset_autosave': {
        'label_en': 'Viewport Optimizer Settings Auto-save',
        'label_ja': 'ビューポート最適化 設定自動保存',
        'desc_en': 'Save the final Viewport Optimization setting after an edit. Saving is event-driven and coalesced; it performs no polling while Blender is idle. Disable it when settings should change only for the current session.',
        'desc_ja': 'ビューポート最適化の設定変更後に最終値を保存します。変更時だけ一度実行され、待機中のポーリング負荷はありません。現在のセッションだけ変更する場合は無効にします。',
    },
    'viewport_optimizer_idle_warm_pulse': {
        'label_en': 'Viewport Optimizer Idle Warm Pulse',
        'label_ja': 'ビューポート最適化 アイドルウォームパルス',
        'desc_en': 'Keep viewport data warm with a repeating timer. This is optional and can be expensive in heavy scenes. Disable it to unregister the timer immediately and keep idle load at zero.',
        'desc_ja': '繰り返しタイマーでビューポートデータをウォーム状態に保つ任意機能です。重いシーンでは負荷になるため、無効時はタイマーを直ちに登録解除して待機負荷をゼロにします。',
    },
    'blend_proxy_cleanup_watch': {
        'label_en': 'Old Blend Proxy Cleanup Watch',
        'label_ja': '旧Blendプロキシ清掃監視',
        'desc_en': 'Function: at save_pre, inspect only exact Smart Workspace artifacts whose owner UUID, artifact UUID, source UUID, file/session generation, and schema match the current suite ledger. The default is dry-run; linked, override, asset, fake-user, and packed data are excluded. Blender itself writes the .blend file.',
        'desc_ja': '機能: save_pre で、owner UUID・artifact UUID・source UUID・file/session generation・schema が現在のSuite台帳と完全一致する Smart Workspace 所有物だけを検査します。既定はdry-runで、linked・override・asset・fake-user・packedデータは除外し、.blend保存はBlender自身に任せます。',
    },
    'external_sync_guard_watch': {
        'label_en': 'Legacy Synchronize Workspaces Guard',
        'label_ja': '旧ワークスペース同期互換ガード',
        'desc_en': 'Function: watch for the old standalone Synchronize Workspaces add-on and neutralize missing-RNA header callbacks. How to use: keep this disabled for zero idle load; enable it only when the old standalone add-on is still installed or errors appear.',
        'desc_ja': '機能: 旧単体版ワークスペース同期アドオンを監視し、存在しないRNAを参照するヘッダーコールバックを無害化します。使い方: 待機負荷をゼロにする場合は無効のままにし、旧単体版が残っている場合やエラーが出る場合だけ有効にします。',
    },
}


def _manual_text(action: str, field: str, context=None) -> str:
    data = _MANUAL_TOGGLE_TEXT.get(str(action or '').strip(), {})
    return ui_pair(str(data.get(f'{field}_en') or action), str(data.get(f'{field}_ja') or data.get(f'{field}_en') or action), context)


_ALWAYS_ON_ACTION_ORDER: tuple[str, ...] = (
    'workspace_auto_restore',
    'panview_follow_camera',
    'panview_show_hud',
    'viewport_optimizer_file_boundaries',
    'viewport_optimizer_preset_autosave',
    'viewport_optimizer_idle_warm_pulse',
    'blend_proxy_cleanup_watch',
    'external_sync_guard_watch',
)

_ACTION_TOOL_LABELS: dict[str, tuple[str, str]] = {
    'workspace_auto_restore': ('Smart Workspace', 'Smart Workspace'),
    'workspace_live_pin_follow': ('Smart Workspace', 'Smart Workspace'),
    'panview_follow_camera': ('2D Pan View', '2Dパンビュー'),
    'panview_show_hud': ('2D Pan View', '2Dパンビュー'),
    'sync_workspace_active': ('Synchronize Workspaces', 'Synchronize Workspaces'),
    'viewport_optimizer_file_boundaries': ('Viewport Optimization', 'ビューポート最適化'),
    'viewport_optimizer_preset_autosave': ('Viewport Optimization', 'ビューポート最適化'),
    'viewport_optimizer_idle_warm_pulse': ('Viewport Optimization', 'ビューポート最適化'),
    'blend_proxy_cleanup_watch': ('Blend Proxy Cleanup', 'Blendプロキシ清掃'),
    'external_sync_guard_watch': ('Legacy Synchronize Workspaces Guard', '旧ワークスペース同期互換ガード'),
}

_ACTION_ALIAS: dict[str, str] = {
    'sync_workspace_active': 'synchronize_workspaces',
}

_ALWAYS_STATE_CACHE: dict[str, bool] | None = None
_APPLYING_SAVED_ALWAYS_ON_STATES = False
_MANUAL_TOGGLE_SET_DEPTH = 0

_ALWAYS_PROP_SYNCING = False
_REGISTERED_ALWAYS_PROPS: set[str] = set()
_REGISTERED_CAPTURED_PROPS: set[str] = set()
_ALWAYS_UPDATE_CALLBACKS: dict[str, object] = {}
_CAPTURED_UPDATE_CALLBACKS: dict[str, object] = {}
_SUPPRESSED_CAPTURED_TOGGLES: set[tuple[str, str]] = {
    ('synchronize_workspaces', 'handlers'),
    ('synchronize_workspaces', 'msgbus'),
}


def _safe_prop_token(value: object) -> str:
    text = str(value or '').strip().lower()
    out = ''.join(ch if ch.isalnum() else '_' for ch in text)
    while '__' in out:
        out = out.replace('__', '_')
    return out.strip('_') or 'item'


def _always_prop_name(action: str) -> str:
    return f'sws_always_{_safe_prop_token(action)}'


def _captured_prop_name(alias: str, feature_key: str) -> str:
    token = ID_FACTORY.token('captured', alias, feature_key, size=12).lower()
    return f'sws_always_captured_{token}'


def _bool_owner(context=None):
    ctx = context or getattr(bpy, 'context', None)
    return getattr(ctx, 'window_manager', None) if ctx is not None else None


def _enabled_text(value: bool, context=None) -> str:
    return ui_pair('On' if value else 'Off', '有効' if value else '無効', context)


def _checkbox_icon(value: bool) -> str:
    return 'CHECKBOX_HLT' if value else 'CHECKBOX_DEHLT'


def _set_bool_prop_silent(owner, prop_name: str, value: bool) -> None:
    global _ALWAYS_PROP_SYNCING
    if owner is None or not prop_name or not hasattr(owner, prop_name):
        return
    try:
        current = bool(getattr(owner, prop_name))
    except Exception:
        current = not bool(value)
    if current == bool(value):
        return
    previous = _ALWAYS_PROP_SYNCING
    _ALWAYS_PROP_SYNCING = True
    try:
        setattr(owner, prop_name, bool(value))
    except Exception:
        pass
    finally:
        _ALWAYS_PROP_SYNCING = previous


def _always_prop_update_factory(action: str, prop_name: str):
    def _update(self, context):
        if _ALWAYS_PROP_SYNCING:
            return None
        try:
            from . import persistence as _persistence
            if _persistence.runtime_sidecar_write_blocked():
                # Canonical RNA replay only.  Runtime registration/unregistration
                # is deferred until the post-file timer opens the boundary.
                return None
        except Exception:
            pass
        try:
            target = bool(getattr(self, prop_name, False))
        except Exception:
            target = False
        try:
            _manual_toggle_set(action, context, enabled=target)
        except Exception:
            pass
        # _manual_toggle_set() persists this canonical choice through
        # always_on_toggles.json, which storage mirrors into the central JSON.
        # Do not snapshot the entire RNA tree here: a toggle can materialise a
        # lazy tool and its temporary defaults must never replace the user's
        # already-saved settings for unrelated N-panel sections.
        return None
    _update.__name__ = f'_update_{prop_name}'
    _update.__module__ = __name__
    return _update


def _captured_prop_update_factory(alias: str, feature_key: str, prop_name: str):
    def _update(self, context):
        if _ALWAYS_PROP_SYNCING:
            return None
        try:
            from . import persistence as _persistence
            if _persistence.runtime_sidecar_write_blocked():
                return None
        except Exception:
            pass
        try:
            target = bool(getattr(self, prop_name, False))
        except Exception:
            target = False
        try:
            feature_toggle.set_feature_enabled(alias, feature_key, target)
        except Exception:
            pass
        try:
            _tag_view3d_ui_redraw(context)
        except Exception:
            pass
        try:
            from . import persistence as _suite_persistence
            if not _suite_persistence.persist_immediate_user_change(
                context,
                source=f'integrated-feature:{alias}:{feature_key}',
            ):
                _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return None
    _update.__name__ = f'_update_{prop_name}'
    _update.__module__ = __name__
    return _update


def _register_always_toggle_properties() -> None:
    for action in _ALWAYS_ON_ACTION_ORDER:
        prop_name = _always_prop_name(action)
        if hasattr(bpy.types.WindowManager, prop_name):
            _REGISTERED_ALWAYS_PROPS.add(prop_name)
            continue
        cb = _always_prop_update_factory(action, prop_name)
        _ALWAYS_UPDATE_CALLBACKS[prop_name] = cb
        try:
            setattr(
                bpy.types.WindowManager,
                prop_name,
                bpy.props.BoolProperty(
                    name=str(_MANUAL_TOGGLE_TEXT.get(action, {}).get('label_en') or action),
                    description=str(_MANUAL_TOGGLE_TEXT.get(action, {}).get('desc_en') or ''),
                    default=False,
                    update=cb,
                ),
            )
            _REGISTERED_ALWAYS_PROPS.add(prop_name)
        except Exception:
            pass


def _ensure_captured_toggle_property(alias: str, feature_key: str, item: dict[str, Any] | None = None) -> str:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return ''
    prop_name = _captured_prop_name(alias, feature_key)
    if hasattr(bpy.types.WindowManager, prop_name):
        _REGISTERED_CAPTURED_PROPS.add(prop_name)
        return prop_name
    data = item or {}
    tool_label = str(data.get('tool_label') or alias.replace('_', ' ').title())
    feature_label = str(data.get('label_en') or feature_key.replace('_', ' ').title())
    desc = str(data.get('description_en') or '')
    cb = _captured_prop_update_factory(alias, feature_key, prop_name)
    _CAPTURED_UPDATE_CALLBACKS[prop_name] = cb
    try:
        setattr(
            bpy.types.WindowManager,
            prop_name,
            bpy.props.BoolProperty(
                name=f'{tool_label}: {feature_label}',
                description=desc,
                default=False,
                update=cb,
            ),
        )
        _REGISTERED_CAPTURED_PROPS.add(prop_name)
    except Exception:
        pass
    return prop_name


def _register_captured_toggle_properties() -> None:
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        alias = str(item.get('alias') or '').strip()
        feature_key = str(item.get('key') or '').strip()
        if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
            continue
        _ensure_captured_toggle_property(alias, feature_key, item)


def _unregister_always_toggle_properties() -> None:
    prop_names = set(_REGISTERED_ALWAYS_PROPS)
    prop_names.update(_always_prop_name(action) for action in _ALWAYS_ON_ACTION_ORDER)
    prop_names.update(_REGISTERED_CAPTURED_PROPS)
    for prop_name in sorted(prop_names):
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                delattr(bpy.types.WindowManager, prop_name)
        except Exception:
            pass
    _REGISTERED_ALWAYS_PROPS.clear()
    _REGISTERED_CAPTURED_PROPS.clear()
    _ALWAYS_UPDATE_CALLBACKS.clear()
    _CAPTURED_UPDATE_CALLBACKS.clear()


def _sync_always_toggle_props(context=None) -> None:
    owner = _bool_owner(context)
    if owner is None:
        return
    for action in _ALWAYS_ON_ACTION_ORDER:
        try:
            value = _manual_toggle_get(action, context)
        except Exception:
            value = _remembered_always_state(action, False)
        _set_bool_prop_silent(owner, _always_prop_name(action), value)
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        alias = str(item.get('alias') or '').strip()
        feature_key = str(item.get('key') or '').strip()
        if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
            continue
        prop_name = _captured_prop_name(alias, feature_key)
        try:
            _set_bool_prop_silent(owner, prop_name, feature_toggle.is_feature_enabled(alias, feature_key))
        except Exception:
            pass


def _always_state_path() -> str:
    """Settings-layer key of the always-on toggles (inside the one settings file)."""
    return _suite_vfs.ALWAYS_ON_TOGGLES_KEY


def _load_always_state() -> dict[str, bool]:
    global _ALWAYS_STATE_CACHE
    if _ALWAYS_STATE_CACHE is not None:
        return _ALWAYS_STATE_CACHE
    data: dict[str, bool] = {}
    try:
        raw = _suite_storage.read_json(_always_state_path(), {})
        if isinstance(raw, dict):
            for key, value in raw.items():
                key = str(key or '').strip()
                if key in _MANUAL_TOGGLE_TEXT:
                    data[key] = bool(value)
    except Exception:
        data = {}
    _ALWAYS_STATE_CACHE = data
    return data


def _save_always_state() -> None:
    state = _load_always_state()
    try:
        path = _always_state_path()
        payload = dict(state)
        payload.update({_always_prop_name(action): bool(value) for action, value in state.items()})
        _suite_storage.atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception:
        pass


def _remember_always_state(action: str, enabled: bool) -> None:
    action = str(action or '').strip()
    if action not in _MANUAL_TOGGLE_TEXT:
        return
    state = _load_always_state()
    state[action] = bool(enabled)
    _save_always_state()


def _remembered_always_state(action: str, default: bool = False) -> bool:
    action = str(action or '').strip()
    state = _load_always_state()
    return bool(state.get(action, default))


def _manual_row_label(action: str, context=None) -> str:
    action = str(action or '').strip()
    tool_en, tool_ja = _ACTION_TOOL_LABELS.get(action, ('Smart Workspace', 'Smart Workspace'))
    feature = _manual_text(action, 'label', context)
    tool = ui_pair(tool_en, tool_ja, context)
    if feature.startswith(tool):
        return feature
    return f'{tool}: {feature}'


def _action_alias(action: str) -> str:
    return str(_ACTION_ALIAS.get(str(action or '').strip(), '') or '')


def _alias_actions(alias: str) -> tuple[str, ...]:
    alias = str(alias or '').strip()
    if not alias:
        return ()
    return tuple(action for action, action_alias in _ACTION_ALIAS.items() if action_alias == alias)


def _maybe_unload_alias_if_all_disabled(alias: str) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    try:
        if any(_remembered_always_state(action, False) for action in _alias_actions(alias)):
            return
    except Exception:
        pass
    try:
        loader.ensure_unloaded(alias)
    except Exception:
        pass


def _root_addon_preferences(context=None):
    """Return the already loaded runtime owner without draw-time imports."""
    try:
        _suite_preferences = sys.modules.get(f'{__package__}.preferences')
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None) if _suite_preferences is not None else None
        if callable(get_settings):
            return get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _manual_toggle_get(action: str, context=None) -> bool:
    action = str(action or '').strip()
    ctx = context or getattr(bpy, 'context', None)
    saved_state = _load_always_state()
    fallback = bool(saved_state.get(action, False))
    # These WindowManager properties represent the user's requested persistent
    # state.  Some integrations cannot create an editor-only operator or header
    # hook in background/startup contexts; that temporary runtime limitation
    # must not flip the visible toggle back off or erase the saved request.
    if action in saved_state:
        return fallback
    if action in {'workspace_auto_restore', 'workspace_live_pin_follow'}:
        prefs = _root_addon_preferences(ctx)
        prop = 'auto_restore_on_file_load' if action == 'workspace_auto_restore' else 'live_pin_follow_enabled'
        return bool(getattr(prefs, prop, fallback)) if prefs is not None else fallback
    if action == 'viewport_optimizer_file_boundaries':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.smart_viewport_optimizer_plus')
            if mod is None:
                return fallback
            handler = getattr(mod, '_svo_plus_load_post', None)
            return bool(handler is not None and handler in bpy.app.handlers.load_post)
        except Exception:
            return fallback
    if action in {'viewport_optimizer_preset_autosave', 'viewport_optimizer_idle_warm_pulse'}:
        try:
            # A legacy per-scene warm-pulse value must never opt a file into a
            # repeating timer. Only an explicit central always-on choice may do so.
            if action == 'viewport_optimizer_idle_warm_pulse':
                return bool(fallback)
            scene = getattr(ctx, 'scene', None) if ctx is not None else None
            settings = getattr(scene, 'smart_viewport_optimizer_settings', None) if scene is not None else None
            if settings is None:
                return fallback
            prop = (
                'auto_save_workspace_preset_changes'
                if action == 'viewport_optimizer_preset_autosave'
                else 'enable_idle_warm_pulse'
            )
            return bool(getattr(settings, prop, fallback))
        except Exception:
            return fallback
    if action == 'blend_proxy_cleanup_watch':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.blend_proxy_cleanup')
            return bool(getattr(mod, '_REGISTERED', fallback)) if mod is not None else fallback
        except Exception:
            return fallback
    if action == 'external_sync_guard_watch':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.external_sync_guard')
            return bool(getattr(mod, '_REGISTERED', fallback)) if mod is not None else fallback
        except Exception:
            return fallback
    if action == 'sync_workspace_active':
        settings = getattr(getattr(ctx, 'scene', None), 'sws_synchronize_workspaces_settings', None) if ctx is not None else None
        if settings is not None:
            try:
                return bool(getattr(settings, 'active', False))
            except Exception:
                return False
        return False
    if action in {'panview_follow_camera', 'panview_show_hud'}:
        # These Scene properties are ordinary 2D Pan View session options and
        # historically defaulted ON.  They are not the user's resident-runtime
        # choice.  The dedicated persistent always-on state is authoritative
        # and defaults OFF in a clean profile.
        return fallback
    return fallback


def _manual_toggle_set(action: str, context=None, *, enabled: bool | None = None) -> bool:
    global _MANUAL_TOGGLE_SET_DEPTH
    action = str(action or '').strip()
    ctx = context or getattr(bpy, 'context', None)
    target = (not _manual_toggle_get(action, ctx)) if enabled is None else bool(enabled)
    alias = _action_alias(action)

    _MANUAL_TOGGLE_SET_DEPTH += 1

    def _finish(ok: bool) -> bool:
        global _MANUAL_TOGGLE_SET_DEPTH
        try:
            # Runtime availability must not erase the user's requested state.
            _remember_always_state(action, target)
            if not target and alias:
                _maybe_unload_alias_if_all_disabled(alias)
            # The selected setter already updates its exact runtime resource.
            # Refreshing every integrated suite here imported unrelated modules
            # and rebuilt every navigation surface for one checkbox click.
            try:
                _sync_always_toggle_props(ctx)
            except Exception:
                pass
            if not _APPLYING_SAVED_ALWAYS_ON_STATES:
                try:
                    from . import persistence as _suite_persistence
                    if not _suite_persistence.persist_immediate_user_change(
                        ctx,
                        source=f'always-on-toggle:{action}',
                    ):
                        _suite_persistence.mark_deferred_settings_dirty()
                except Exception:
                    pass
            _tag_view3d_ui_redraw(ctx)
            return bool(ok or not target)
        finally:
            _MANUAL_TOGGLE_SET_DEPTH = max(0, _MANUAL_TOGGLE_SET_DEPTH - 1)

    if action in {'workspace_auto_restore', 'workspace_live_pin_follow'}:
        prefs = _root_addon_preferences(ctx)
        if prefs is None:
            return _finish(False)
        prop = 'auto_restore_on_file_load' if action == 'workspace_auto_restore' else 'live_pin_follow_enabled'
        try:
            current = bool(getattr(prefs, prop, False))
        except Exception:
            current = not target
        try:
            if current != bool(target):
                setattr(prefs, prop, target)
            else:
                try:
                    from . import preferences as _suite_preferences
                    save_fn = getattr(_suite_preferences, 'save_runtime_settings', None)
                    if callable(save_fn):
                        save_fn(ctx)
                except Exception:
                    pass
            try:
                from . import runtime as _runtime
                apply_fn = getattr(_runtime, 'apply_preference_runtime_state', None)
                if callable(apply_fn):
                    apply_fn(context=ctx, startup=False)
            except Exception:
                pass
            return _finish(True)
        except Exception:
            return _finish(False)
    if action == 'viewport_optimizer_file_boundaries':
        try:
            from . import smart_viewport_optimizer_plus as _svo
            if target and not hasattr(bpy.types.Scene, 'smart_viewport_optimizer_settings'):
                reg = getattr(_svo, 'register', None)
                if callable(reg):
                    reg()
            setter = getattr(_svo, 'set_file_boundary_handlers_enabled', None) or getattr(_svo, '_svo_v15_sync_file_boundary_handlers', None)
            if callable(setter):
                setter(bool(target))
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action in {'viewport_optimizer_preset_autosave', 'viewport_optimizer_idle_warm_pulse'}:
        try:
            from . import smart_viewport_optimizer_plus as _svo
            if target and not hasattr(bpy.types.Scene, 'smart_viewport_optimizer_settings'):
                reg = getattr(_svo, 'register', None)
                if callable(reg) and not bool(reg()):
                    return _finish(False)
            setter_name = (
                'set_preset_autosave_runtime_enabled'
                if action == 'viewport_optimizer_preset_autosave'
                else 'set_idle_warm_pulse_runtime_enabled'
            )
            setter = getattr(_svo, setter_name, None)
            if not callable(setter):
                return _finish(not target)
            return _finish(bool(setter(bool(target), ctx)))
        except Exception:
            return _finish(not target)
    if action == 'blend_proxy_cleanup_watch':
        try:
            from . import blend_proxy_cleanup as _cleanup
            fn = getattr(_cleanup, 'register' if target else 'unregister', None)
            if callable(fn):
                fn()
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action == 'external_sync_guard_watch':
        try:
            from . import external_sync_guard as _guard
            # An RNA update callback can run inside load_post while Blender is
            # rebuilding Scene ownership.  Toggling the optional watcher must not
            # unregister PointerProperty RNA at that boundary; only the add-on's
            # top-level unregister performs full compatibility teardown.
            setter = getattr(_guard, 'set_watch_enabled', None)
            if callable(setter):
                setter(bool(target))
            else:
                fn = getattr(_guard, 'register' if target else 'stop_watch_runtime', None)
                if callable(fn):
                    fn()
                elif target:
                    return _finish(False)
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action == 'sync_workspace_active':
        try:
            feature_toggle.set_feature_enabled('synchronize_workspaces', 'msgbus', target)
            feature_toggle.set_feature_enabled('synchronize_workspaces', 'handlers', target)
        except Exception:
            pass
        try:
            from . import synchronize_workspaces as _synchronize_workspaces
        except Exception:
            try:
                from .. import synchronize_workspaces as _synchronize_workspaces
            except Exception:
                _synchronize_workspaces = None
        if _synchronize_workspaces is not None:
            try:
                if target and not hasattr(bpy.types.Scene, 'sws_synchronize_workspaces_settings'):
                    reg = getattr(_synchronize_workspaces, 'register', None)
                    if callable(reg):
                        reg()
            except Exception:
                pass
            try:
                fn = getattr(_synchronize_workspaces, 'apply_enabled', None)
                if callable(fn):
                    ok = bool(fn(target, context=ctx, save=True)) == bool(target)
                    return _finish(ok)
            except Exception:
                pass
        settings = getattr(getattr(ctx, 'scene', None), 'sws_synchronize_workspaces_settings', None) if ctx is not None else None
        if settings is None:
            return _finish(not target)
        try:
            setattr(settings, 'active', target)
        except Exception:
            return _finish(False)
        return _finish(True)
    if action in {'panview_follow_camera', 'panview_show_hud'}:
        if target:
            try:
                from .runtime import ensure_panview_runtime as _ensure_panview_runtime
                _ensure_panview_runtime()
            except Exception:
                pass
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        prop = 'panview_follow_active_camera' if action == 'panview_follow_camera' else 'panview_show_hud'
        if scene is None or not hasattr(scene, prop):
            return _finish(not target)
        try:
            setattr(scene, prop, target)
            try:
                from .runtime import panview as _panview
                save_fn = getattr(_panview, 'save_persistent_panview_settings', None)
                if callable(save_fn):
                    save_fn(ctx)
            except Exception:
                pass
            return _finish(True)
        except Exception:
            return _finish(False)
    return _finish(False)

def apply_saved_always_on_states(context=None) -> None:
    """Restore saved always-on choices without importing disabled tools."""
    global _APPLYING_SAVED_ALWAYS_ON_STATES
    if _APPLYING_SAVED_ALWAYS_ON_STATES or _MANUAL_TOGGLE_SET_DEPTH > 0:
        return
    ctx = context or getattr(bpy, 'context', None)
    state = dict(_load_always_state())
    _APPLYING_SAVED_ALWAYS_ON_STATES = True
    try:
        for action in _ALWAYS_ON_ACTION_ORDER:
            if action not in state:
                continue
            try:
                _manual_toggle_set(action, ctx, enabled=bool(state[action]))
            except Exception:
                pass
    finally:
        _APPLYING_SAVED_ALWAYS_ON_STATES = False
        try:
            _sync_always_toggle_props(ctx)
        except Exception:
            pass


def _draw_manual_toggle(layout, context, action: str) -> None:
    """Draw one toggle from registered RNA or an existing memory cache only."""
    label = _manual_row_label(action, context)
    owner = _bool_owner(context)
    prop_name = _always_prop_name(action)
    if owner is not None and hasattr(owner, prop_name):
        try:
            enabled = bool(getattr(owner, prop_name, False))
        except Exception:
            enabled = False
    else:
        cache = _ALWAYS_STATE_CACHE if isinstance(_ALWAYS_STATE_CACHE, dict) else {}
        enabled = bool(cache.get(str(action or '').strip(), False))
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if owner is not None and hasattr(owner, prop_name):
        right.row(align=True).prop(owner, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
    else:
        try:
            right.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
        except Exception:
            pass


def _feature_operator_id() -> str:
    """Return the already registered toggle id without draw-time setup."""
    try:
        return str(getattr(feature_toggle, '_OPERATOR_ID', '') or '')
    except Exception:
        return ''


def _draw_captured_toggle(layout, context, item: dict[str, Any], op_id: str) -> bool:
    del op_id
    alias = str(item.get('alias') or '').strip()
    feature_key = str(item.get('key') or '').strip()
    if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
        return False
    owner = _bool_owner(context)
    prop_name = _captured_prop_name(alias, feature_key)
    if owner is not None and hasattr(owner, prop_name):
        try:
            enabled = bool(getattr(owner, prop_name, False))
        except Exception:
            enabled = bool(item.get('enabled'))
    else:
        # feature_entries() snapshots _STATE_CACHE without loading it.  Drawing
        # must never call is_feature_enabled(), which can read its JSON sidecar.
        enabled = bool(item.get('enabled'))
    tool_label = str(item.get('tool_label') or alias.replace('_', ' ').title())
    feature_label = ui_pair(str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key), context)
    label = f'{tool_label}: {feature_label}'
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if owner is not None and hasattr(owner, prop_name):
        right.row(align=True).prop(owner, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        return True
    disabled = right.row(align=True)
    try:
        disabled.enabled = False
        disabled.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
    except Exception:
        try:
            right.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
        except Exception:
            pass
    return True


class SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_always_toggle(bpy.types.Operator):
    bl_idname = 'smart_workspace_suite.always_toggle'
    bl_label = ui_pair('Toggle Always-on Feature', '常時起動機能を切り替え')
    bl_description = ui_pair('Load only the required integrated tool when needed, then enable or disable the selected always-on feature. The setting is saved immediately.', '必要な場合だけ対象の統合ツールを読み込み、選択した常時起動機能を有効または無効にします。設定は即時保存されます。')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    action: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, 'action', '') or '')
        return _manual_text(action, 'desc', context) or cls.bl_description

    def execute(self, context):
        action = str(self.action or '').strip()
        if not action:
            return {'CANCELLED'}
        if not _manual_toggle_set(action, context):
            self.report({'WARNING'}, ui_pair('The selected always-on feature could not be changed.', '選択した常時起動機能を変更できませんでした。', context))
            return {'CANCELLED'}
        self.report({'INFO'}, ui_pair('Always-on feature setting changed.', '常時起動機能の設定を変更しました。', context))
        return {'FINISHED'}


class SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_n_panel_state_save_toggle(bpy.types.Operator):
    bl_idname = 'smart_workspace_suite.n_panel_state_save_toggle'
    bl_label = ui_pair('N-panel State Save', 'Nパネル状態保存')
    bl_description = ui_pair(
        "Toggle crash-safe N-panel state journaling. Changes are written to a small add-on-owned live journal without rebuilding the complete Smart Workspace settings graph; the canonical settings file is committed at file-save and shutdown boundaries.",
        "Smart Workspace のNパネル設定変更を、Blenderのバージョン別config内 Smart_WorkSpace_Suite/Smart_WorkSpace_Suite.json へ即時保存するかを切り替えます。無効の場合は、現在のファイルを閉じる/置き換える時、またはSmart Workspaceのプリファレンス保存時に保存します。",
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    enabled: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            "Function: control lightweight N-panel state journaling. On: each edit is coalesced into a small atomic live journal. Off: no edit-time journal timer remains; settings are still committed at explicit file-save, add-on disable, and Blender shutdown boundaries.",
            "機能: Nパネル状態の中央保存を制御します。有効: 全ての設定変更を即時に config/Smart_WorkSpace_Suite/Smart_WorkSpace_Suite.json へ反映します。無効: 現在のファイルを閉じる/置き換える時、またはプリファレンス保存時にJSONへ保存します。バックグラウンド保存チェックを減らしつつ、シーン切り替えやBlender起動後も設定を維持したい場合に使います。",
            context,
        )

    def execute(self, context):
        st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
        if st is None or not hasattr(st, 'n_panel_state_save_enabled'):
            return {'CANCELLED'}
        requested = bool(self.enabled)
        try:
            previous = getattr(st, 'n_panel_state_save_enabled', True)
            previous = previous if isinstance(previous, bool) else True
        except Exception:
            previous = True
        try:
            setattr(st, 'n_panel_state_save_enabled', requested)
            from . import storage as _suite_storage
            from .runtime import core as _nptl_core
            live_state = _nptl_core._read_live_state_document(refresh=True)
            live_ui = live_state.get('ui_state') if isinstance(live_state, dict) else None
            if (
                _suite_storage.n_panel_state_save_enabled(True) is not requested
                or not isinstance(live_ui, dict)
                or live_ui.get('n_panel_state_save_enabled') is not requested
            ):
                raise OSError('N-panel state-save journal verification failed')
            from . import persistence as _suite_persistence
            sync_policy = getattr(_suite_persistence, 'sync_continuous_autosave_policy', None)
            if callable(sync_policy) and not bool(sync_policy()):
                raise RuntimeError('Persistence boundary handlers could not be synchronized')
            return {'FINISHED'}
        except Exception as exc:
            try:
                setattr(st, 'n_panel_state_save_enabled', previous)
            except Exception:
                pass
            try:
                from . import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
            except Exception:
                pass
            self.report({'ERROR'}, error_text(exc, 'The setting could not be changed', '設定を変更できませんでした', context))
            return {'CANCELLED'}


def _draw_n_panel_state_save_toggle(layout, context) -> None:
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    enabled = True
    if st is not None and hasattr(st, 'n_panel_state_save_enabled'):
        try:
            enabled = bool(getattr(st, 'n_panel_state_save_enabled', True))
        except Exception:
            enabled = True
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=ui_pair('N-panel State Save', 'Nパネル状態保存', context))
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if st is not None and hasattr(st, 'n_panel_state_save_enabled'):
        right.row(align=True).prop(st, 'n_panel_state_save_enabled', text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        return
    disabled = right.row(align=True)
    try:
        disabled.enabled = False
        disabled.label(text=_enabled_text(False, context), icon='CHECKBOX_DEHLT')
    except Exception:
        try:
            right.label(text=_enabled_text(False, context), icon='CHECKBOX_DEHLT')
        except Exception:
            pass


def _draw_always_on_row_error(layout, context, label: str, exc: Exception | None = None) -> None:
    try:
        row = layout.row(align=True)
        row.label(text=str(label or ui_pair('Always-on feature item', '常時起動機能項目', context)), icon='ERROR')
    except Exception:
        pass


def draw_always_active_panel_body(layout, context) -> None:
    layout = localized_layout(layout, context)
    # Do not synchronize RNA toggle properties from Panel.draw.  Updating RNA
    # during draw can re-enter UI layout in Blender 5.1; buttons below call
    # operators that update state explicitly.

    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    try:
        _draw_n_panel_state_save_toggle(col, context)
    except Exception as exc:
        _draw_always_on_row_error(col, context, ui_pair('N-panel State Save', 'Nパネル状態保存', context), exc)
    try:
        col.separator(factor=0.5)
    except Exception:
        pass
    # Smart Workspace's native pin-follow wrapper is a real resident feature,
    # so expose its exact RNA immediately after N-panel State Save in the same
    # canonical row format as every other Always-on control.
    runtime_settings = _root_addon_preferences(context)
    if runtime_settings is not None and hasattr(runtime_settings, 'live_pin_follow_enabled'):
        try:
            enabled = bool(getattr(runtime_settings, 'live_pin_follow_enabled', False))
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            split.row(align=True).label(text=_manual_row_label('workspace_live_pin_follow', context))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.row(align=True).prop(
                runtime_settings,
                'live_pin_follow_enabled',
                text=_enabled_text(enabled, context),
                icon=_checkbox_icon(enabled),
                toggle=True,
            )
        except Exception as exc:
            _draw_always_on_row_error(col, context, _manual_row_label('workspace_live_pin_follow', context), exc)
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    for prop_name, label_en, label_ja in (
        ('workspace_step_reorder_enabled', 'Workspace Step Reorder', 'ワークスペース順序変更'),
        ('synchronize_workspaces_enabled', 'Synchronize Workspaces', 'ワークスペース同期'),
        ('floating_window_lock_enabled', 'Floating Window Lock', 'フローティングウィンドウ固定'),
    ):
        if st is None or not hasattr(st, prop_name):
            continue
        try:
            enabled = bool(getattr(st, prop_name, False))
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            split.row(align=True).label(text=ui_pair(label_en, label_ja, context))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.row(align=True).prop(st, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        except Exception as exc:
            _draw_always_on_row_error(col, context, ui_pair(label_en, label_ja, context), exc)
    for action in _ALWAYS_ON_ACTION_ORDER:
        try:
            _draw_manual_toggle(col, context, action)
        except Exception as exc:
            _draw_always_on_row_error(col, context, _manual_row_label(action, context), exc)

    op_id = _feature_operator_id()
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        try:
            _draw_captured_toggle(col, context, item, op_id)
        except Exception as exc:
            try:
                label = f"{item.get('tool_label') or item.get('alias') or ''}: {item.get('label_ja') or item.get('label_en') or item.get('key') or ''}"
            except Exception:
                label = ui_pair('Captured always-on item', '検出された常時起動機能項目', context)
            _draw_always_on_row_error(col, context, label, exc)


def draw_always_active_panel(layout, context) -> None:
    layout = localized_layout(layout, context)
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    is_open = bool(getattr(st, 'show_always_on_toggles', False)) if st is not None else False

    if st is not None and hasattr(st, 'show_always_on_toggles'):
        header, body = layout.panel_prop(st, 'show_always_on_toggles')
    else:
        header, body = layout.row(align=True), None
    header.label(text=ui_pair('Always-on Toggles', '常時機能切り替え', context), icon='TIME')
    header.separator(factor=0.35)
    _draw_help_button(header, context, 'always_on_toggles', text=False, compact=True, scale=1.0)

    if body is None:
        return
    draw_always_active_panel_body(body, context)


def _collect_records() -> None:
    if not loader.get_records():
        try:
            loader.prepare_records(force=True)
        except Exception:
            pass


def register() -> bool:
    # This list must be empty on a new exact generation.  Never use registration
    # as an opportunity to remove an older/foreign live class.
    if _REGISTERED_CLASSES and not _safe_unregister_registered_classes():
        return False
    _collect_records()
    if feature_toggle.register_ui() is not True:
        return False
    # Stable RNA mirrors make each resident switch independently persistable
    # while the visible rows retain the common operator presentation.
    _register_always_toggle_properties()
    _register_captured_toggle_properties()
    _sync_always_toggle_props(getattr(bpy, 'context', None))
    classes = (
        SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_always_toggle,
        SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_n_panel_state_save_toggle,
    )
    for cls in classes:
        if not _safe_register_class(cls):
            return False
    return True


def unregister() -> bool:
    classes_ok = _safe_unregister_registered_classes()
    _unregister_always_toggle_properties()
    try:
        feature_ok = feature_toggle.unregister_ui() is not False
    except Exception:
        feature_ok = False
    return bool(classes_ok and feature_ok)
