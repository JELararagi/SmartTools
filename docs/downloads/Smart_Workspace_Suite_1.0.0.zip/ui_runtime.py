# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
import importlib
import os
import sys
from types import ModuleType
from typing import Any

import bpy
from . import storage as _suite_storage
from . import runtime_ledger as _runtime_ledger

from . import feature_toggle, loader as loader, registry as registry, ui_icons
from .translation import error_text, localized_layout, ui_pair


_REGISTERED_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()


ID_FACTORY = _IdFactory()


def _unregister_registered_class_instance(cls: type) -> bool:
    """Unregister only an exact current-generation class identity."""
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return False
    return bool(_runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='UI_RUNTIME_CLASS',
    ))


def _safe_register_class(cls: type) -> bool:
    """Register and ledger one exact class without live RNA replacement."""
    if not isinstance(cls, type) or not _runtime_ledger.current_generation():
        return False
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='UI_RUNTIME_CLASS',
    )
    if not success:
        return False
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)
    return True


def _safe_unregister_registered_classes() -> bool:
    ok = True
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        if not _unregister_registered_class_instance(cls):
            ok = False
    if ok:
        _REGISTERED_CLASSES.clear()
        _RECORDS_BY_ALIAS.clear()
    return ok


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'..{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass


def _tag_view3d_ui_redraw(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                try:
                    area.tag_redraw()
                except Exception:
                    pass
                for region in getattr(area, 'regions', ()) or ():
                    if getattr(region, 'type', None) in {'UI', 'WINDOW', 'TOOLS', 'HEADER'}:
                        try:
                            region.tag_redraw()
                        except Exception:
                            pass
    except Exception:
        pass


def _draw_help_button(layout, context, help_id: str, *, text: bool = True, compact: bool = False, scale: float | None = None):
    del text, compact, scale, context
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = str(help_id or 'runtime')
        return op
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass
        return None


def _iter_module_tree(module):
    seen: set[int] = set()

    def _visit(obj):
        if not isinstance(obj, ModuleType):
            return
        obj_id = id(obj)
        if obj_id in seen:
            return
        seen.add(obj_id)
        yield obj
        for attr_name in ('modules', 'registered_modules'):
            for child in getattr(obj, attr_name, ()) or ():
                yield from _visit(child)
        for attr_name in ('core', 'ui', 'prefs', 'preferences', 'ops', 'common', 'integrated_bridge', 'bs_utils', 'operators', 'tools'):
            child = getattr(obj, attr_name, None)
            yield from _visit(child)
        bs_utils = getattr(obj, 'bs_utils', None)
        if isinstance(bs_utils, ModuleType):
            for attr_name in ('prefs', 'hotkeys', 'ui', 'properties'):
                child = getattr(bs_utils, attr_name, None)
                yield from _visit(child)

    yield from _visit(module)


def _find_module_by_suffix(record: dict, *suffixes: str):
    suffixes = tuple(str(item or '').strip() for item in suffixes if str(item or '').strip())
    module = record.get('module')
    for mod in _iter_module_tree(module):
        name = str(getattr(mod, '__name__', '') or '')
        if any(name.endswith(suffix) for suffix in suffixes):
            return mod
    return None


def _runtime_operator_exists(idname: str) -> bool:
    try:
        namespace, operator = str(idname or '').split('.', 1)
        getattr(getattr(bpy.ops, namespace), operator).get_rna_type()
        return True
    except Exception:
        return False


_MANUAL_TOGGLE_TEXT: dict[str, dict[str, str]] = {
    'icon_viewer_console_header': {
        'label_en': 'Icon Viewer Console Header Button',
        'label_ja': 'アイコンビューアーコンソールヘッダーボタン',
        'desc_en': 'Function: add the Icon Viewer button to the Python Console header. How to use: enable it only if you want quick icon lookup from the Console header; disable it to remove the persistent header draw callback.',
        'desc_ja': '機能: Python コンソール ヘッダーにアイコンビューアーボタンを追加します。使い方: コンソールヘッダーから素早くアイコン検索したい場合だけ有効化し、不要な時は無効化して常駐ヘッダー描画を外します。',
    },
    'icon_viewer_auto_save': {
        'label_en': 'Icon Viewer Event Save',
        'label_ja': 'アイコンビューアーイベント保存',
        'desc_en': 'Function: keep Icon Viewer preferences synchronized by property-change events while Icon Viewer is loaded. How to use: enable it for compatibility with the legacy auto-save switch; no timer or polling is created.',
        'desc_ja': '機能: アイコンビューアー読み込み中に、検索・パネル・ポップアップ設定をプロパティ変更イベントで同期保存します。使い方: 旧自動保存スイッチとの互換が必要な場合に有効化します。タイマーやポーリングは作成しません。',
    },
    'script_launcher_load_restore': {
        'label_en': 'Script Launcher Restore on File Load',
        'label_ja': 'スクリプトランチャー読込時復元',
        'desc_en': 'Function: keep the Script Launcher file-load handler active so registered roots and the visible script tree are restored after opening another .blend file. How to use: enable it only when you rely on Script Launcher in every project; disable it to keep Script Launcher idle until opened.',
        'desc_ja': '機能: 別の .blend ファイル読込後に、登録ルートと表示用スクリプトツリーを復元するスクリプトランチャーのロードハンドラーを有効にします。使い方: すべてのプロジェクトでスクリプトランチャーを常用する場合だけ有効化し、不要な時は開くまで待機させます。',
    },
    'workspace_auto_restore': {
        'label_en': 'Auto Restore on File Load',
        'label_ja': '読込時に自動復元',
        'desc_en': 'Enable Smart Workspace restoration after Blender starts or after another .blend file is loaded. Use this when profiles, launcher categories, and saved Smart Workspace state should be restored automatically.',
        'desc_ja': 'Blender 起動後や別の .blend ファイル読込後に Smart Workspace の状態を自動復元します。プロファイル、ランチャーカテゴリー、保存済み状態を毎回自動で戻したい場合に有効化します。',
    },
    'workspace_live_pin_follow': {
        'label_en': 'Live Panel Pin Follow',
        'label_ja': 'パネルピン追従',
        'desc_en': 'Keep the panels of pinned tabs visible on the other N-panel tabs, using Blender\'s standard panel pin. A panel is pinned the next time it is drawn open. Turning this off removes the pins.',
        'desc_ja': 'ピンを付けたタブのパネルを、ほかのタブを開いている時も表示します。Blender 標準のパネルのピンを使い、パネルが開いた状態で描かれた時に付きます。無効にするとピンを外します。',
    },
    'screencast_runtime': {
        'label_en': 'Screencast Keys Overlay',
        'label_ja': 'Screencast Keys オーバーレイ',
        'desc_en': 'Start or stop the live Screencast Keys overlay that draws pressed keys and mouse input over the viewport. Enable it for recording or demonstrations, then disable it when finished.',
        'desc_ja': '押下キーやマウス入力をビューポート上に描画する Screencast Keys オーバーレイを開始 / 停止します。録画や説明時に有効化し、終了後は無効化してください。',
    },
    'screencast_enable_on_startup': {
        'label_en': 'Enable Screencast Keys on Startup',
        'label_ja': '起動時に Screencast Keys を有効化',
        'desc_en': 'Automatically start the Screencast Keys overlay when Blender starts. Use this only when you need the input display in every session.',
        'desc_ja': 'Blender 起動時に Screencast Keys オーバーレイを自動開始します。毎回入力表示が必要な場合だけ有効化してください。',
    },
    'screencast_auto_save': {
        'label_en': 'Screencast Keys Auto Save',
        'label_ja': 'Screencast Keys 自動保存',
        'desc_en': 'Function: enable the experimental Screencast Keys auto-save behavior while modal operators are running. How to use: keep it disabled unless you specifically need that compatibility behavior.',
        'desc_ja': '機能: モーダル操作中に Screencast Keys の実験的な自動保存処理を有効化します。使い方: その互換動作が明確に必要な場合以外は無効のままにします。',
    },
    'screencast_hotkey': {
        'label_en': 'Screencast Keys Default Hotkey',
        'label_ja': 'Screencast Keys 既定ホットキー',
        'desc_en': 'Function: register the Screencast Keys default shortcut keymap. How to use: enable it only when you want to toggle the overlay by shortcut; disable it to remove the keymap and avoid shortcut conflicts.',
        'desc_ja': '機能: Screencast Keys の既定ショートカットキーマップを登録します。使い方: ショートカットでオーバーレイを切り替えたい場合だけ有効化し、競合を避けたい場合は無効化してキーマップを外します。',
    },
    'sync_workspace_active': {
        'label_en': 'Synchronize 3D Views',
        'label_ja': '3D ビュー同期',
        'desc_en': 'Enable or disable synchronization of 3D View state between workspaces. When enabled, the related message-bus watcher and load handler are also enabled so the synchronization can react automatically.',
        'desc_ja': 'ワークスペース間の 3D ビュー状態同期を有効 / 無効にします。有効化時は同期が自動反応できるよう、関連するメッセージバス監視とロードハンドラーも有効化します。',
    },
    'kle_emulation_active': {
        'label_en': 'Keyboard Layout Emulation',
        'label_ja': 'Keyboard Layout Emulation',
        'desc_en': 'Apply or revert keyboard layout emulation. Enabling remaps Blender keymaps for the selected keyboard layout, while disabling reverts the applied emulation.',
        'desc_ja': 'キーボード配列エミュレーションを適用 / 解除します。有効化すると選択中の配列に合わせて Blender キーマップを再割り当てし、無効化すると適用済みエミュレーションを戻します。',
    },
    'kle_reapply_keymap_panel': {
        'label_en': 'Reapply from Keymap Preferences',
        'label_ja': 'キーマップ設定で自動再適用',
        'desc_en': 'Automatically reapply keyboard layout emulation when pending keymaps are detected while the Keymap preferences panel is updated.',
        'desc_ja': 'キーマップ設定パネル更新中に未適用キーマップが検出された場合、キーボード配列エミュレーションを自動で再適用します。',
    },
    'kle_reapply_reload': {
        'label_en': 'Reapply on Reload / Restart',
        'label_ja': '再読込 / 再起動時に再適用',
        'desc_en': 'Automatically reapply keyboard layout emulation after Blender restarts or a new file is loaded, so add-on shortcuts registered later can also be remapped.',
        'desc_ja': 'Blender 再起動後や新しいファイル読込後にキーボード配列エミュレーションを自動再適用し、後から登録されたアドオンショートカットも再割り当てします。',
    },
    'kle_detect_addon_changes': {
        'label_en': 'Detect Add-on Changes',
        'label_ja': 'アドオン変更を検出',
        'desc_en': 'Watch add-on list changes while the Preferences add-on panels are updated and reapply keyboard layout emulation when needed.',
        'desc_ja': 'プリファレンスのアドオン関連パネル更新中にアドオン一覧の変化を監視し、必要に応じてキーボード配列エミュレーションを再適用します。',
    },
    'kle_logging': {
        'label_en': 'Keyboard Emulation Logging',
        'label_ja': 'キーボードエミュレーションログ',
        'desc_en': 'Enable Keyboard Layout Emulation log output in Blender’s system console. Use it for troubleshooting and keep it disabled during normal work.',
        'desc_ja': 'キーボード配列エミュレーションのログを Blender のシステムコンソールへ出力します。トラブル調査時に使い、通常作業では無効を推奨します。',
    },
    'panview_follow_camera': {
        'label_en': '2D Pan View Follow Active Camera',
        'label_ja': '2Dパンビューアクティブカメラ追従',
        'desc_en': 'Allow open 2D Pan View sessions to follow the scene active camera through a background dependency-graph handler only while a 2D Pan View session is active.',
        'desc_ja': '2Dパンビューセッションが開いている間だけ、依存グラフハンドラーを使って開いている2Dパンビューをシーンのアクティブカメラへ追従させます。',
    },
    'panview_show_hud': {
        'label_en': '2D Pan View HUD',
        'label_ja': '2Dパンビュー HUD',
        'desc_en': 'Show or hide the small live HUD drawn in active 2D Pan View sessions. Disable it when you want a clean capture area.',
        'desc_ja': 'アクティブな2Dパンビューセッションに描画される小さなHUDを表示 / 非表示にします。クリーンな録画領域が必要な場合は無効化してください。',
    },
    'viewport_pie_hotkeys': {
        'label_en': '3D Viewport Pie Menus Hotkeys',
        'label_ja': '3Dビューのパイメニュー ホットキー',
        'desc_en': 'Function: register the default hotkeys used by the bundled 3D Viewport pie menus. How to use: enable it only when you want pie menus to react to keyboard or mouse shortcuts; disable it to remove those keymaps and avoid conflicts.',
        'desc_ja': '機能: 同梱3Dビューのパイメニューの既定ホットキーを登録します。使い方: パイメニューをキーボードやマウスショートカットで呼び出したい場合だけ有効化し、競合を避けたい場合は無効化してキーマップを外します。',
    },
    'viewport_optimizer_file_boundaries': {
        'label_en': 'Viewport Optimizer File-Boundary Hooks',
        'label_ja': 'ビューポート最適化 ファイル境界処理',
        'desc_en': 'Function: run Viewport Optimization only at file open/save/close boundaries for automatic standardization and restoration. How to use: keep this disabled for zero idle load; enable it only when you need automatic save/open behavior.',
        'desc_ja': '機能: ファイルを開く・保存する・閉じる境界で、ビューポート最適化の標準化や復帰処理を自動実行します。使い方: 待機中の負荷をゼロにしたい場合は無効のままにし、ファイル境界での自動処理が必要な場合だけ有効にします。',
    },
    'viewport_optimizer_preset_autosave': {
        'label_en': 'Viewport Optimizer Settings Auto-save',
        'label_ja': 'ビューポート最適化 設定自動保存',
        'desc_en': 'Save the final Viewport Optimization setting after an edit. Saving is event-driven and coalesced; it performs no polling while Blender is idle. Disable it when settings should change only for the current session.',
        'desc_ja': 'ビューポート最適化の設定変更後に最終値を保存します。変更時だけ一度実行され、待機中のポーリング負荷はありません。現在のセッションだけ変更する場合は無効にします。',
    },
    'viewport_optimizer_idle_warm_pulse': {
        'label_en': 'Viewport Optimizer Idle Warm Pulse',
        'label_ja': 'ビューポート最適化 アイドルウォームパルス',
        'desc_en': 'Keep viewport data warm with a repeating timer. This is optional and can be expensive in heavy scenes. Disable it to unregister the timer immediately and keep idle load at zero.',
        'desc_ja': '繰り返しタイマーでビューポートデータをウォーム状態に保つ任意機能です。重いシーンでは負荷になるため、無効時はタイマーを直ちに登録解除して待機負荷をゼロにします。',
    },
    'blend_proxy_cleanup_watch': {
        'label_en': 'Old Blend Proxy Cleanup Watch',
        'label_ja': '旧Blendプロキシ清掃監視',
        'desc_en': 'Function: at save_pre, inspect only exact Smart Workspace artifacts whose owner UUID, artifact UUID, source UUID, file/session generation, and schema match the current suite ledger. The default is dry-run; linked, override, asset, fake-user, and packed data are excluded. Blender itself writes the .blend file.',
        'desc_ja': '機能: save_pre で、owner UUID・artifact UUID・source UUID・file/session generation・schema が現在のSuite台帳と完全一致する Smart Workspace 所有物だけを検査します。既定はdry-runで、linked・override・asset・fake-user・packedデータは除外し、.blend保存はBlender自身に任せます。',
    },
    'external_sync_guard_watch': {
        'label_en': 'Legacy Synchronize Workspaces Guard',
        'label_ja': '旧ワークスペース同期互換ガード',
        'desc_en': 'Function: watch for the old standalone Synchronize Workspaces add-on and neutralize missing-RNA header callbacks. How to use: keep this disabled for zero idle load; enable it only when the old standalone add-on is still installed or errors appear.',
        'desc_ja': '機能: 旧単体版ワークスペース同期アドオンを監視し、存在しないRNAを参照するヘッダーコールバックを無害化します。使い方: 待機負荷をゼロにする場合は無効のままにし、旧単体版が残っている場合やエラーが出る場合だけ有効にします。',
    },
}


def _manual_text(action: str, field: str, context=None) -> str:
    data = _MANUAL_TOGGLE_TEXT.get(str(action or '').strip(), {})
    return ui_pair(str(data.get(f'{field}_en') or action), str(data.get(f'{field}_ja') or data.get(f'{field}_en') or action), context)


_ALWAYS_ON_ACTION_ORDER: tuple[str, ...] = (
    'workspace_auto_restore',
    'panview_follow_camera',
    'panview_show_hud',
    'icon_viewer_console_header',
    'icon_viewer_auto_save',
    'script_launcher_load_restore',
    'screencast_runtime',
    'screencast_enable_on_startup',
    'screencast_auto_save',
    'screencast_hotkey',
    'kle_emulation_active',
    'kle_reapply_keymap_panel',
    'kle_reapply_reload',
    'kle_detect_addon_changes',
    'viewport_pie_hotkeys',
    'viewport_optimizer_file_boundaries',
    'viewport_optimizer_preset_autosave',
    'viewport_optimizer_idle_warm_pulse',
    'blend_proxy_cleanup_watch',
    'external_sync_guard_watch',
)

_ACTION_TOOL_LABELS: dict[str, tuple[str, str]] = {
    'workspace_auto_restore': ('Smart Workspace', 'Smart Workspace'),
    'workspace_live_pin_follow': ('Smart Workspace', 'Smart Workspace'),
    'panview_follow_camera': ('2D Pan View', '2Dパンビュー'),
    'panview_show_hud': ('2D Pan View', '2Dパンビュー'),
    'icon_viewer_console_header': ('Icon Viewer', 'Icon Viewer'),
    'icon_viewer_auto_save': ('Icon Viewer', 'Icon Viewer'),
    'script_launcher_load_restore': ('Script Launcher', 'Script Launcher'),
    'screencast_runtime': ('Screencast Keys', 'Screencast Keys'),
    'screencast_enable_on_startup': ('Screencast Keys', 'Screencast Keys'),
    'screencast_auto_save': ('Screencast Keys', 'Screencast Keys'),
    'screencast_hotkey': ('Screencast Keys', 'Screencast Keys'),
    'sync_workspace_active': ('Synchronize Workspaces', 'Synchronize Workspaces'),
    'kle_emulation_active': ('Keyboard Layout Emulation', 'Keyboard Layout Emulation'),
    'kle_reapply_keymap_panel': ('Keyboard Layout Emulation', 'Keyboard Layout Emulation'),
    'kle_reapply_reload': ('Keyboard Layout Emulation', 'Keyboard Layout Emulation'),
    'kle_detect_addon_changes': ('Keyboard Layout Emulation', 'Keyboard Layout Emulation'),
    'kle_logging': ('Keyboard Layout Emulation', 'Keyboard Layout Emulation'),
    'viewport_pie_hotkeys': ('3D Viewport Pie Menus', '3D Viewport Pie Menus'),
    'viewport_optimizer_file_boundaries': ('Viewport Optimization', 'ビューポート最適化'),
    'viewport_optimizer_preset_autosave': ('Viewport Optimization', 'ビューポート最適化'),
    'viewport_optimizer_idle_warm_pulse': ('Viewport Optimization', 'ビューポート最適化'),
    'blend_proxy_cleanup_watch': ('Blend Proxy Cleanup', 'Blendプロキシ清掃'),
    'external_sync_guard_watch': ('Legacy Synchronize Workspaces Guard', '旧ワークスペース同期互換ガード'),
}

_ACTION_ALIAS: dict[str, str] = {
    'icon_viewer_console_header': 'icon_viewer',
    'icon_viewer_auto_save': 'icon_viewer',
    'script_launcher_load_restore': 'script_launcher',
    'screencast_runtime': 'screencast_keys',
    'screencast_enable_on_startup': 'screencast_keys',
    'screencast_auto_save': 'screencast_keys',
    'screencast_hotkey': 'screencast_keys',
    'sync_workspace_active': 'synchronize_workspaces',
    'kle_emulation_active': 'keyboard_layout_emulation',
    'kle_reapply_keymap_panel': 'keyboard_layout_emulation',
    'kle_reapply_reload': 'keyboard_layout_emulation',
    'kle_detect_addon_changes': 'keyboard_layout_emulation',
    'kle_logging': 'keyboard_layout_emulation',
    'viewport_pie_hotkeys': 'viewport_pie_menus',
}

_ALWAYS_STATE_CACHE: dict[str, bool] | None = None
_APPLYING_SAVED_ALWAYS_ON_STATES = False
_MANUAL_TOGGLE_SET_DEPTH = 0

_ALWAYS_PROP_SYNCING = False
_REGISTERED_ALWAYS_PROPS: set[str] = set()
_REGISTERED_CAPTURED_PROPS: set[str] = set()
_ALWAYS_UPDATE_CALLBACKS: dict[str, object] = {}
_CAPTURED_UPDATE_CALLBACKS: dict[str, object] = {}
_SUPPRESSED_CAPTURED_TOGGLES: set[tuple[str, str]] = {
    ('synchronize_workspaces', 'handlers'),
    ('synchronize_workspaces', 'msgbus'),
    ('script_launcher', 'handlers'),
    ('icon_viewer', 'timers'),
    ('screencast_keys', 'keymaps'),
    ('viewport_pie_menus', 'keymaps'),
}


def _safe_prop_token(value: object) -> str:
    text = str(value or '').strip().lower()
    out = ''.join(ch if ch.isalnum() else '_' for ch in text)
    while '__' in out:
        out = out.replace('__', '_')
    return out.strip('_') or 'item'


def _always_prop_name(action: str) -> str:
    return f'sws_always_{_safe_prop_token(action)}'


def _captured_prop_name(alias: str, feature_key: str) -> str:
    token = ID_FACTORY.token('captured', alias, feature_key, size=12).lower()
    return f'sws_always_captured_{token}'


def _bool_owner(context=None):
    ctx = context or getattr(bpy, 'context', None)
    return getattr(ctx, 'window_manager', None) if ctx is not None else None


def _enabled_text(value: bool, context=None) -> str:
    return ui_pair('On' if value else 'Off', '有効' if value else '無効', context)


def _checkbox_icon(value: bool) -> str:
    return 'CHECKBOX_HLT' if value else 'CHECKBOX_DEHLT'


def _set_bool_prop_silent(owner, prop_name: str, value: bool) -> None:
    global _ALWAYS_PROP_SYNCING
    if owner is None or not prop_name or not hasattr(owner, prop_name):
        return
    try:
        current = bool(getattr(owner, prop_name))
    except Exception:
        current = not bool(value)
    if current == bool(value):
        return
    previous = _ALWAYS_PROP_SYNCING
    _ALWAYS_PROP_SYNCING = True
    try:
        setattr(owner, prop_name, bool(value))
    except Exception:
        pass
    finally:
        _ALWAYS_PROP_SYNCING = previous


def _always_prop_update_factory(action: str, prop_name: str):
    def _update(self, context):
        if _ALWAYS_PROP_SYNCING:
            return None
        try:
            from . import persistence as _persistence
            if _persistence.runtime_sidecar_write_blocked():
                # Canonical RNA replay only.  Runtime registration/unregistration
                # is deferred until the post-file timer opens the boundary.
                return None
        except Exception:
            pass
        try:
            target = bool(getattr(self, prop_name, False))
        except Exception:
            target = False
        try:
            _manual_toggle_set(action, context, enabled=target)
        except Exception:
            pass
        # _manual_toggle_set() persists this canonical choice through
        # always_on_toggles.json, which storage mirrors into the central JSON.
        # Do not snapshot the entire RNA tree here: a toggle can materialise a
        # lazy tool and its temporary defaults must never replace the user's
        # already-saved settings for unrelated N-panel sections.
        return None
    _update.__name__ = f'_update_{prop_name}'
    _update.__module__ = __name__
    return _update


def _captured_prop_update_factory(alias: str, feature_key: str, prop_name: str):
    def _update(self, context):
        if _ALWAYS_PROP_SYNCING:
            return None
        try:
            from . import persistence as _persistence
            if _persistence.runtime_sidecar_write_blocked():
                return None
        except Exception:
            pass
        try:
            target = bool(getattr(self, prop_name, False))
        except Exception:
            target = False
        try:
            feature_toggle.set_feature_enabled(alias, feature_key, target)
        except Exception:
            pass
        try:
            _tag_view3d_ui_redraw(context)
        except Exception:
            pass
        try:
            from . import persistence as _suite_persistence
            if not _suite_persistence.persist_immediate_user_change(
                context,
                source=f'integrated-feature:{alias}:{feature_key}',
            ):
                _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return None
    _update.__name__ = f'_update_{prop_name}'
    _update.__module__ = __name__
    return _update


def _register_always_toggle_properties() -> None:
    for action in _ALWAYS_ON_ACTION_ORDER:
        prop_name = _always_prop_name(action)
        if hasattr(bpy.types.WindowManager, prop_name):
            _REGISTERED_ALWAYS_PROPS.add(prop_name)
            continue
        cb = _always_prop_update_factory(action, prop_name)
        _ALWAYS_UPDATE_CALLBACKS[prop_name] = cb
        try:
            setattr(
                bpy.types.WindowManager,
                prop_name,
                bpy.props.BoolProperty(
                    name=str(_MANUAL_TOGGLE_TEXT.get(action, {}).get('label_en') or action),
                    description=str(_MANUAL_TOGGLE_TEXT.get(action, {}).get('desc_en') or ''),
                    default=False,
                    update=cb,
                ),
            )
            _REGISTERED_ALWAYS_PROPS.add(prop_name)
        except Exception:
            pass


def _ensure_captured_toggle_property(alias: str, feature_key: str, item: dict[str, Any] | None = None) -> str:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return ''
    prop_name = _captured_prop_name(alias, feature_key)
    if hasattr(bpy.types.WindowManager, prop_name):
        _REGISTERED_CAPTURED_PROPS.add(prop_name)
        return prop_name
    data = item or {}
    tool_label = str(data.get('tool_label') or alias.replace('_', ' ').title())
    feature_label = str(data.get('label_en') or feature_key.replace('_', ' ').title())
    desc = str(data.get('description_en') or '')
    cb = _captured_prop_update_factory(alias, feature_key, prop_name)
    _CAPTURED_UPDATE_CALLBACKS[prop_name] = cb
    try:
        setattr(
            bpy.types.WindowManager,
            prop_name,
            bpy.props.BoolProperty(
                name=f'{tool_label}: {feature_label}',
                description=desc,
                default=False,
                update=cb,
            ),
        )
        _REGISTERED_CAPTURED_PROPS.add(prop_name)
    except Exception:
        pass
    return prop_name


def _register_captured_toggle_properties() -> None:
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        alias = str(item.get('alias') or '').strip()
        feature_key = str(item.get('key') or '').strip()
        if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
            continue
        _ensure_captured_toggle_property(alias, feature_key, item)


def _unregister_always_toggle_properties() -> None:
    prop_names = set(_REGISTERED_ALWAYS_PROPS)
    prop_names.update(_always_prop_name(action) for action in _ALWAYS_ON_ACTION_ORDER)
    prop_names.update(_REGISTERED_CAPTURED_PROPS)
    for prop_name in sorted(prop_names):
        try:
            if hasattr(bpy.types.WindowManager, prop_name):
                delattr(bpy.types.WindowManager, prop_name)
        except Exception:
            pass
    _REGISTERED_ALWAYS_PROPS.clear()
    _REGISTERED_CAPTURED_PROPS.clear()
    _ALWAYS_UPDATE_CALLBACKS.clear()
    _CAPTURED_UPDATE_CALLBACKS.clear()


def _sync_always_toggle_props(context=None) -> None:
    owner = _bool_owner(context)
    if owner is None:
        return
    for action in _ALWAYS_ON_ACTION_ORDER:
        try:
            value = _manual_toggle_get(action, context)
        except Exception:
            value = _remembered_always_state(action, False)
        _set_bool_prop_silent(owner, _always_prop_name(action), value)
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        alias = str(item.get('alias') or '').strip()
        feature_key = str(item.get('key') or '').strip()
        if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
            continue
        prop_name = _captured_prop_name(alias, feature_key)
        try:
            _set_bool_prop_silent(owner, prop_name, feature_toggle.is_feature_enabled(alias, feature_key))
        except Exception:
            pass


def _always_state_path() -> str:
    try:
        return str(_suite_storage.addon_storage_path('always_on_toggles.json'))
    except Exception:
        root = str(_suite_storage.user_default_root('smart_workspace_suite', create=True))
        return os.path.join(root, 'always_on_toggles.json')


def _load_always_state() -> dict[str, bool]:
    global _ALWAYS_STATE_CACHE
    if _ALWAYS_STATE_CACHE is not None:
        return _ALWAYS_STATE_CACHE
    data: dict[str, bool] = {}
    try:
        raw = _suite_storage.read_json(_always_state_path(), {})
        if isinstance(raw, dict):
            for key, value in raw.items():
                key = str(key or '').strip()
                if key in _MANUAL_TOGGLE_TEXT:
                    data[key] = bool(value)
    except Exception:
        data = {}
    _ALWAYS_STATE_CACHE = data
    return data


def _save_always_state() -> None:
    state = _load_always_state()
    try:
        path = _always_state_path()
        payload = dict(state)
        payload.update({_always_prop_name(action): bool(value) for action, value in state.items()})
        _suite_storage.atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception:
        pass


def _remember_always_state(action: str, enabled: bool) -> None:
    action = str(action or '').strip()
    if action not in _MANUAL_TOGGLE_TEXT:
        return
    state = _load_always_state()
    state[action] = bool(enabled)
    _save_always_state()


def _remembered_always_state(action: str, default: bool = False) -> bool:
    action = str(action or '').strip()
    state = _load_always_state()
    return bool(state.get(action, default))


def _manual_row_label(action: str, context=None) -> str:
    action = str(action or '').strip()
    tool_en, tool_ja = _ACTION_TOOL_LABELS.get(action, ('Smart Workspace', 'Smart Workspace'))
    feature = _manual_text(action, 'label', context)
    tool = ui_pair(tool_en, tool_ja, context)
    if feature.startswith(tool):
        return feature
    return f'{tool}: {feature}'


def _action_alias(action: str) -> str:
    return str(_ACTION_ALIAS.get(str(action or '').strip(), '') or '')


def _alias_actions(alias: str) -> tuple[str, ...]:
    alias = str(alias or '').strip()
    if not alias:
        return ()
    return tuple(action for action, action_alias in _ACTION_ALIAS.items() if action_alias == alias)


def _maybe_unload_alias_if_all_disabled(alias: str) -> None:
    alias = str(alias or '').strip()
    if not alias:
        return
    # These integrations own editable N-panel PropertyGroups.  Keep their
    # settings surface registered after first use so values remain addressable
    # for synchronous save/scene restore, while their individual runtime
    # switches still remove every handler, timer, keymap and msgbus subscriber.
    # Registered RNA classes alone perform no background work.
    if alias in {
        'icon_viewer',
        'script_launcher',
        'keyboard_layout_emulation',
        'screencast_keys',
    }:
        return
    try:
        if any(_remembered_always_state(action, False) for action in _alias_actions(alias)):
            return
    except Exception:
        pass
    try:
        loader.ensure_unloaded(alias)
    except Exception:
        pass


def _root_addon_preferences(context=None):
    """Return the already loaded runtime owner without draw-time imports."""
    try:
        _suite_preferences = sys.modules.get(f'{__package__}.preferences')
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None) if _suite_preferences is not None else None
        if callable(get_settings):
            return get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _ensure_alias_loaded(alias: str):
    alias = str(alias or '').strip()
    if not alias:
        return None
    try:
        record = loader.ensure_loaded(alias)
        if isinstance(record, dict) and str(record.get('status') or '') == 'loaded':
            return record
    except Exception:
        return None
    return None


def _loaded_record(alias: str):
    alias = str(alias or '').strip()
    if not alias:
        return None
    record = _RECORDS_BY_ALIAS.get(alias)
    if isinstance(record, dict) and str(record.get('status') or '') == 'loaded':
        return record
    try:
        for candidate in loader.get_records():
            spec = candidate.get('spec') or {}
            if str(spec.get('alias') or '') == alias and str(candidate.get('status') or '') == 'loaded':
                return candidate
    except Exception:
        pass
    return None


def _screencast_prefs(context=None, *, load: bool = False):
    record = _ensure_alias_loaded('screencast_keys') if load else _loaded_record('screencast_keys')
    if not isinstance(record, dict):
        return None
    bridge_mod = _find_module_by_suffix(record, '.integrated_bridge')
    get_prefs = getattr(bridge_mod, 'get_prefs', None) if bridge_mod is not None else None
    try:
        return get_prefs(context or getattr(bpy, 'context', None)) if callable(get_prefs) else None
    except Exception:
        return None


def _keyboard_prefs(context=None, *, load: bool = False):
    record = _ensure_alias_loaded('keyboard_layout_emulation') if load else _loaded_record('keyboard_layout_emulation')
    if not isinstance(record, dict):
        return None
    prefs_mod = _find_module_by_suffix(record, '.preferences')
    kle_prefs = getattr(prefs_mod, 'kle_prefs', None) if prefs_mod is not None else None
    try:
        return kle_prefs(context or getattr(bpy, 'context', None)) if callable(kle_prefs) else None
    except Exception:
        return None


def _icon_viewer_prefs(context=None, *, load: bool = False):
    del context
    record = _ensure_alias_loaded('icon_viewer') if load else _loaded_record('icon_viewer')
    if not isinstance(record, dict):
        return None
    module = record.get('module')
    prefs_fn = getattr(module, 'prefs', None)
    try:
        return prefs_fn() if callable(prefs_fn) else None
    except Exception:
        return None


def _save_icon_viewer_prefs(context=None) -> None:
    record = _loaded_record('icon_viewer')
    module = record.get('module') if isinstance(record, dict) else None
    save_fn = getattr(module, 'save_integrated_preferences', None) if module is not None else None
    if callable(save_fn):
        try:
            save_fn(context or getattr(bpy, 'context', None))
        except Exception:
            pass


def _save_screencast_prefs(context=None) -> None:
    record = _loaded_record('screencast_keys')
    bridge_mod = _find_module_by_suffix(record, '.integrated_bridge') if isinstance(record, dict) else None
    save_fn = getattr(bridge_mod, 'save_prefs', None) if bridge_mod is not None else None
    if callable(save_fn):
        try:
            save_fn(context or getattr(bpy, 'context', None))
        except Exception:
            pass


def _save_keyboard_prefs(context=None) -> None:
    record = _loaded_record('keyboard_layout_emulation')
    prefs_mod = _find_module_by_suffix(record, '.preferences') if isinstance(record, dict) else None
    save_fn = getattr(prefs_mod, 'save_integrated_preferences', None) if prefs_mod is not None else None
    if callable(save_fn):
        try:
            save_fn(context or getattr(bpy, 'context', None))
        except Exception:
            pass


def _manual_toggle_get(action: str, context=None) -> bool:
    action = str(action or '').strip()
    ctx = context or getattr(bpy, 'context', None)
    saved_state = _load_always_state()
    fallback = bool(saved_state.get(action, False))
    if action == 'screencast_runtime':
        # Once the lazy integration is registered its WindowManager property
        # is a read-through getter for the live modal operator.  That live
        # postcondition must outrank the remembered request; otherwise an
        # external/non-entry operator call can invert the next public toggle.
        # Before registration, retain the remembered request so startup and
        # background contexts still expose the user's intended state.
        if _loaded_record('screencast_keys') is not None:
            wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
            try:
                return bool(getattr(wm, 'enable_screencast_keys')) if wm is not None else fallback
            except Exception:
                return fallback
        return fallback
    # These WindowManager properties represent the user's requested persistent
    # state.  Some integrations cannot create an editor-only operator or header
    # hook in background/startup contexts; that temporary runtime limitation
    # must not flip the visible toggle back off or erase the saved request.
    if action in saved_state:
        return fallback
    if action == 'icon_viewer_console_header':
        record = _loaded_record('icon_viewer')
        module = record.get('module') if isinstance(record, dict) else None
        if module is not None and hasattr(module, '_HEADER_DRAW_APPENDED'):
            try:
                return bool(getattr(module, '_HEADER_DRAW_APPENDED'))
            except Exception:
                return fallback
        prefs = _icon_viewer_prefs(ctx, load=False)
        return bool(getattr(prefs, 'show_header', fallback)) if prefs is not None else fallback
    if action == 'icon_viewer_auto_save':
        record = _loaded_record('icon_viewer')
        module = record.get('module') if isinstance(record, dict) else None
        if module is not None and hasattr(module, '_INTEGRATED_AUTOSAVE_ENABLED'):
            try:
                return bool(getattr(module, '_INTEGRATED_AUTOSAVE_ENABLED'))
            except Exception:
                return fallback
        return fallback
    if action == 'script_launcher_load_restore':
        record = _loaded_record('script_launcher')
        module = record.get('module') if isinstance(record, dict) else None
        handler = getattr(module, 'load_handler', None) if module is not None else None
        try:
            return bool(handler in bpy.app.handlers.load_post) if handler is not None else fallback
        except Exception:
            return fallback
    if action in {'workspace_auto_restore', 'workspace_live_pin_follow'}:
        prefs = _root_addon_preferences(ctx)
        prop = 'auto_restore_on_file_load' if action == 'workspace_auto_restore' else 'live_pin_follow_enabled'
        return bool(getattr(prefs, prop, fallback)) if prefs is not None else fallback
    if action in {'screencast_enable_on_startup', 'screencast_auto_save'}:
        prefs = _screencast_prefs(ctx, load=False)
        prop = 'enable_on_startup' if action == 'screencast_enable_on_startup' else 'auto_save'
        return bool(getattr(prefs, prop, fallback)) if prefs is not None else fallback
    if action == 'screencast_hotkey':
        try:
            return bool(feature_toggle.is_feature_enabled('screencast_keys', 'keymaps'))
        except Exception:
            return fallback
    if action == 'viewport_pie_hotkeys':
        try:
            return bool(feature_toggle.is_feature_enabled('viewport_pie_menus', 'keymaps'))
        except Exception:
            return fallback
    if action == 'viewport_optimizer_file_boundaries':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.smart_viewport_optimizer_plus')
            if mod is None:
                return fallback
            handler = getattr(mod, '_svo_plus_load_post', None)
            return bool(handler is not None and handler in bpy.app.handlers.load_post)
        except Exception:
            return fallback
    if action in {'viewport_optimizer_preset_autosave', 'viewport_optimizer_idle_warm_pulse'}:
        try:
            # A legacy per-scene warm-pulse value must never opt a file into a
            # repeating timer. Only an explicit central always-on choice may do so.
            if action == 'viewport_optimizer_idle_warm_pulse':
                return bool(fallback)
            scene = getattr(ctx, 'scene', None) if ctx is not None else None
            settings = getattr(scene, 'smart_viewport_optimizer_settings', None) if scene is not None else None
            if settings is None:
                return fallback
            prop = (
                'auto_save_workspace_preset_changes'
                if action == 'viewport_optimizer_preset_autosave'
                else 'enable_idle_warm_pulse'
            )
            return bool(getattr(settings, prop, fallback))
        except Exception:
            return fallback
    if action == 'blend_proxy_cleanup_watch':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.blend_proxy_cleanup')
            return bool(getattr(mod, '_REGISTERED', fallback)) if mod is not None else fallback
        except Exception:
            return fallback
    if action == 'external_sync_guard_watch':
        try:
            import sys as _sys
            mod = _sys.modules.get(f'{__package__}.external_sync_guard')
            return bool(getattr(mod, '_REGISTERED', fallback)) if mod is not None else fallback
        except Exception:
            return fallback
    if action == 'sync_workspace_active':
        settings = getattr(getattr(ctx, 'scene', None), 'sws_synchronize_workspaces_settings', None) if ctx is not None else None
        if settings is not None:
            try:
                return bool(getattr(settings, 'active', False))
            except Exception:
                return False
        return False
    if action.startswith('kle_'):
        prefs = _keyboard_prefs(ctx, load=False)
        mapping = {
            'kle_emulation_active': 'is_emulation_active',
            'kle_reapply_keymap_panel': 'reapply_on_keymaps_panel',
            'kle_reapply_reload': 'reapply_on_reload',
            'kle_detect_addon_changes': 'detect_addon_changes',
            'kle_logging': 'logging_enabled',
        }
        prop = mapping.get(action, '')
        return bool(getattr(prefs, prop, fallback)) if prefs is not None and prop else fallback
    if action in {'panview_follow_camera', 'panview_show_hud'}:
        # These Scene properties are ordinary 2D Pan View session options and
        # historically defaulted ON.  They are not the user's resident-runtime
        # choice.  The dedicated persistent always-on state is authoritative
        # and defaults OFF in a clean profile.
        return fallback
    return fallback


def _set_icon_viewer_header(module, target: bool) -> bool:
    if module is None:
        return False
    try:
        appended = bool(getattr(module, '_HEADER_DRAW_APPENDED', False))
        draw_fn = getattr(module, 'draw_console_header', None)
        header_cls = getattr(bpy.types, 'CONSOLE_HT_header', None)
        if header_cls is None or draw_fn is None:
            return False
        if target and not appended:
            header_cls.append(draw_fn)
            setattr(module, '_HEADER_DRAW_APPENDED', True)
        elif (not target) and appended:
            try:
                header_cls.remove(draw_fn)
            except Exception:
                pass
            setattr(module, '_HEADER_DRAW_APPENDED', False)
        return True
    except Exception:
        return False


def _set_script_launcher_load_handler(module, target: bool) -> bool:
    if module is None:
        return False
    handler = getattr(module, 'load_handler', None)
    if handler is None:
        return False
    try:
        if target:
            if handler not in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.append(handler)
            try:
                bridge = getattr(module, 'integrated_bridge', None)
                core = getattr(module, 'core', None)
                if bridge is not None and hasattr(bridge, 'load_prefs'):
                    bridge.load_prefs(getattr(bpy, 'context', None))
                if core is not None:
                    if hasattr(core, 'invalidate_fs_cache'):
                        core.invalidate_fs_cache()
                    if hasattr(core, 'build_visible_tree'):
                        core.build_visible_tree(getattr(bpy, 'context', None))
            except Exception:
                pass
        else:
            while handler in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.remove(handler)
        return True
    except Exception:
        return False


def _set_module_autosave(module, target: bool) -> bool:
    if module is None:
        return False
    try:
        fn = getattr(module, '_start_integrated_autosave' if target else '_stop_integrated_autosave', None)
        if callable(fn):
            fn()
            return True
    except Exception:
        pass
    return False


def _set_screencast_load_handler(module, target: bool) -> bool:
    if module is None:
        return False
    handler = getattr(module, 'load_post_handler', None)
    if handler is None:
        return False
    try:
        setter = getattr(module, '_set_load_post_handler_enabled', None)
        if callable(setter):
            setter(bool(target))
            return True
        if target:
            if handler not in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.append(handler)
        else:
            while handler in bpy.app.handlers.load_post:
                bpy.app.handlers.load_post.remove(handler)
        return True
    except Exception:
        return False


def _sync_kle_runtime_hooks(context=None) -> None:
    record = _loaded_record('keyboard_layout_emulation')
    if not isinstance(record, dict):
        return
    try:
        ui_mod = _find_module_by_suffix(record, '.ui')
        sync_ui = getattr(ui_mod, 'sync_integrated_runtime_hooks', None) if ui_mod is not None else None
        if callable(sync_ui):
            sync_ui(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        handlers_mod = _find_module_by_suffix(record, '.event_handlers')
        sync_handlers = getattr(handlers_mod, 'sync_integrated_runtime_hooks', None) if handlers_mod is not None else None
        if callable(sync_handlers):
            sync_handlers(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def _set_keymap_feature(alias: str, target: bool) -> bool:
    ok = True
    try:
        feature_toggle.set_feature_enabled(alias, 'keymaps', bool(target))
    except Exception:
        ok = False
    record = _ensure_alias_loaded(alias) if target else _loaded_record(alias)
    if target:
        ok = ok and isinstance(record, dict) and str(record.get('status') or '') == 'loaded'
        try:
            feature_toggle.set_feature_enabled(alias, 'keymaps', bool(target) and ok)
        except Exception:
            pass
    if isinstance(record, dict):
        module = record.get('module')
        try:
            if alias == 'screencast_keys':
                fn = getattr(module, 'register_shortcut_key' if target else 'unregister_shortcut_key', None)
                if callable(fn):
                    fn()
        except Exception:
            ok = False if target else ok
    return bool(ok or not target)


def _manual_toggle_set(action: str, context=None, *, enabled: bool | None = None) -> bool:
    global _MANUAL_TOGGLE_SET_DEPTH
    action = str(action or '').strip()
    ctx = context or getattr(bpy, 'context', None)
    target = (not _manual_toggle_get(action, ctx)) if enabled is None else bool(enabled)
    alias = _action_alias(action)

    _MANUAL_TOGGLE_SET_DEPTH += 1

    def _finish(ok: bool) -> bool:
        global _MANUAL_TOGGLE_SET_DEPTH
        try:
            # Runtime availability must not erase the user's requested state.
            _remember_always_state(action, target)
            if not target and alias:
                _maybe_unload_alias_if_all_disabled(alias)
            # The selected setter already updates its exact runtime resource.
            # Refreshing every integrated suite here imported unrelated modules
            # and rebuilt every navigation surface for one checkbox click.
            try:
                _sync_always_toggle_props(ctx)
            except Exception:
                pass
            if not _APPLYING_SAVED_ALWAYS_ON_STATES:
                try:
                    from . import persistence as _suite_persistence
                    if not _suite_persistence.persist_immediate_user_change(
                        ctx,
                        source=f'always-on-toggle:{action}',
                    ):
                        _suite_persistence.mark_deferred_settings_dirty()
                except Exception:
                    pass
            _tag_view3d_ui_redraw(ctx)
            return bool(ok or not target)
        finally:
            _MANUAL_TOGGLE_SET_DEPTH = max(0, _MANUAL_TOGGLE_SET_DEPTH - 1)

    if action == 'icon_viewer_console_header':
        prefs = _icon_viewer_prefs(ctx, load=target)
        record = _loaded_record('icon_viewer')
        module = record.get('module') if isinstance(record, dict) else None
        if prefs is None:
            return _finish(not target)
        try:
            setattr(prefs, 'show_header', target)
            _set_icon_viewer_header(module, target)
            _save_icon_viewer_prefs(ctx)
            return _finish(True)
        except Exception:
            return _finish(False)
    if action == 'icon_viewer_auto_save':
        if target:
            _ensure_alias_loaded('icon_viewer')
        record = _loaded_record('icon_viewer')
        module = record.get('module') if isinstance(record, dict) else None
        if module is None:
            return _finish(not target)
        return _finish(_set_module_autosave(module, target))
    if action == 'script_launcher_load_restore':
        if target:
            _ensure_alias_loaded('script_launcher')
        record = _loaded_record('script_launcher')
        module = record.get('module') if isinstance(record, dict) else None
        if module is None:
            return _finish(not target)
        return _finish(_set_script_launcher_load_handler(module, target))
    if action in {'workspace_auto_restore', 'workspace_live_pin_follow'}:
        prefs = _root_addon_preferences(ctx)
        if prefs is None:
            return _finish(False)
        prop = 'auto_restore_on_file_load' if action == 'workspace_auto_restore' else 'live_pin_follow_enabled'
        try:
            current = bool(getattr(prefs, prop, False))
        except Exception:
            current = not target
        try:
            if current != bool(target):
                setattr(prefs, prop, target)
            else:
                try:
                    from . import preferences as _suite_preferences
                    save_fn = getattr(_suite_preferences, 'save_runtime_settings', None)
                    if callable(save_fn):
                        save_fn(ctx)
                except Exception:
                    pass
            try:
                from . import runtime as _runtime
                apply_fn = getattr(_runtime, 'apply_preference_runtime_state', None)
                if callable(apply_fn):
                    apply_fn(context=ctx, startup=False)
            except Exception:
                pass
            return _finish(True)
        except Exception:
            return _finish(False)
    if action == 'screencast_runtime':
        if target:
            _ensure_alias_loaded('screencast_keys')
        if not target and _loaded_record('screencast_keys') is None:
            return _finish(True)
        # Screencast Keys is a viewport modal operator.  Background Blender has
        # no region in which it can be invoked; preserve the requested toggle
        # for the next GUI session without issuing an invalid operator call.
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return _finish(True)
        try:
            current = _manual_toggle_get(action, ctx)
            if bool(current) == bool(target):
                return _finish(True)
            result = bpy.ops.wm.sk_screencast_keys('INVOKE_REGION_WIN')
            operator_ok = isinstance(result, set) and 'CANCELLED' not in result
            # Screencast Keys uses CANCELLED for its intentional running->OFF
            # transition.  Treat that result as success only when the public
            # state now proves the requested postcondition; a disallowed ON
            # request remains a real failure and still reports CANCELLED.
            postcondition_ok = False
            try:
                postcondition_ok = bool(_manual_toggle_get(action, ctx)) == bool(target)
            except Exception:
                postcondition_ok = False
            return _finish(bool(operator_ok or postcondition_ok))
        except Exception:
            return _finish(False)
    if action in {'screencast_enable_on_startup', 'screencast_auto_save'}:
        prefs = _screencast_prefs(ctx, load=target)
        if prefs is None:
            return _finish(not target)
        prop = 'enable_on_startup' if action == 'screencast_enable_on_startup' else 'auto_save'
        try:
            setattr(prefs, prop, target)
            if action == 'screencast_enable_on_startup':
                record = _loaded_record('screencast_keys')
                module = record.get('module') if isinstance(record, dict) else None
                _set_screencast_load_handler(module, target)
            _save_screencast_prefs(ctx)
            return _finish(True)
        except Exception:
            return _finish(False)
    if action == 'screencast_hotkey':
        return _finish(_set_keymap_feature('screencast_keys', target))
    if action == 'viewport_pie_hotkeys':
        return _finish(_set_keymap_feature('viewport_pie_menus', target))
    if action == 'viewport_optimizer_file_boundaries':
        try:
            from . import smart_viewport_optimizer_plus as _svo
            if target and not hasattr(bpy.types.Scene, 'smart_viewport_optimizer_settings'):
                reg = getattr(_svo, 'register', None)
                if callable(reg):
                    reg()
            setter = getattr(_svo, 'set_file_boundary_handlers_enabled', None) or getattr(_svo, '_svo_v15_sync_file_boundary_handlers', None)
            if callable(setter):
                setter(bool(target))
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action in {'viewport_optimizer_preset_autosave', 'viewport_optimizer_idle_warm_pulse'}:
        try:
            from . import smart_viewport_optimizer_plus as _svo
            if target and not hasattr(bpy.types.Scene, 'smart_viewport_optimizer_settings'):
                reg = getattr(_svo, 'register', None)
                if callable(reg) and not bool(reg()):
                    return _finish(False)
            setter_name = (
                'set_preset_autosave_runtime_enabled'
                if action == 'viewport_optimizer_preset_autosave'
                else 'set_idle_warm_pulse_runtime_enabled'
            )
            setter = getattr(_svo, setter_name, None)
            if not callable(setter):
                return _finish(not target)
            return _finish(bool(setter(bool(target), ctx)))
        except Exception:
            return _finish(not target)
    if action == 'blend_proxy_cleanup_watch':
        try:
            from . import blend_proxy_cleanup as _cleanup
            fn = getattr(_cleanup, 'register' if target else 'unregister', None)
            if callable(fn):
                fn()
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action == 'external_sync_guard_watch':
        try:
            from . import external_sync_guard as _guard
            # An RNA update callback can run inside load_post while Blender is
            # rebuilding Scene ownership.  Toggling the optional watcher must not
            # unregister PointerProperty RNA at that boundary; only the add-on's
            # top-level unregister performs full compatibility teardown.
            setter = getattr(_guard, 'set_watch_enabled', None)
            if callable(setter):
                setter(bool(target))
            else:
                fn = getattr(_guard, 'register' if target else 'stop_watch_runtime', None)
                if callable(fn):
                    fn()
                elif target:
                    return _finish(False)
            return _finish(True)
        except Exception:
            return _finish(not target)
    if action == 'sync_workspace_active':
        try:
            feature_toggle.set_feature_enabled('synchronize_workspaces', 'msgbus', target)
            feature_toggle.set_feature_enabled('synchronize_workspaces', 'handlers', target)
        except Exception:
            pass
        try:
            from . import synchronize_workspaces as _synchronize_workspaces
        except Exception:
            try:
                from .. import synchronize_workspaces as _synchronize_workspaces
            except Exception:
                _synchronize_workspaces = None
        if _synchronize_workspaces is not None:
            try:
                if target and not hasattr(bpy.types.Scene, 'sws_synchronize_workspaces_settings'):
                    reg = getattr(_synchronize_workspaces, 'register', None)
                    if callable(reg):
                        reg()
            except Exception:
                pass
            try:
                fn = getattr(_synchronize_workspaces, 'apply_enabled', None)
                if callable(fn):
                    ok = bool(fn(target, context=ctx, save=True)) == bool(target)
                    return _finish(ok)
            except Exception:
                pass
        settings = getattr(getattr(ctx, 'scene', None), 'sws_synchronize_workspaces_settings', None) if ctx is not None else None
        if settings is None:
            return _finish(not target)
        try:
            setattr(settings, 'active', target)
        except Exception:
            return _finish(False)
        return _finish(True)
    if action == 'kle_emulation_active':
        if target:
            _ensure_alias_loaded('keyboard_layout_emulation')
        elif _loaded_record('keyboard_layout_emulation') is None:
            return _finish(True)
        try:
            operator_id = 'wm.kle_apply_layout_emulation' if target else 'wm.kle_revert_layout_emulation'
            if not _runtime_operator_exists(operator_id):
                if target:
                    return _finish(False)
                prefs = _keyboard_prefs(ctx, load=False)
                if prefs is not None:
                    setattr(prefs, 'is_emulation_active', False)
                    _save_keyboard_prefs(ctx)
                return _finish(True)
            if target:
                result = bpy.ops.wm.kle_apply_layout_emulation('INVOKE_DEFAULT')
            else:
                result = bpy.ops.wm.kle_revert_layout_emulation('EXEC_DEFAULT', request_confirmation=False)
            ok = isinstance(result, set) and 'CANCELLED' not in result
            if ok:
                _save_keyboard_prefs(ctx)
                _sync_kle_runtime_hooks(ctx)
            return _finish(ok)
        except Exception:
            try:
                if not target:
                    prefs = _keyboard_prefs(ctx, load=False)
                    if prefs is not None:
                        setattr(prefs, 'is_emulation_active', False)
                        _save_keyboard_prefs(ctx)
                        return _finish(True)
            except Exception:
                pass
            return _finish(False)
    if action.startswith('kle_'):
        prefs = _keyboard_prefs(ctx, load=target)
        mapping = {
            'kle_reapply_keymap_panel': 'reapply_on_keymaps_panel',
            'kle_reapply_reload': 'reapply_on_reload',
            'kle_detect_addon_changes': 'detect_addon_changes',
            'kle_logging': 'logging_enabled',
        }
        prop = mapping.get(action, '')
        if prefs is None or not prop:
            return _finish(not target)
        try:
            setattr(prefs, prop, target)
            _save_keyboard_prefs(ctx)
            _sync_kle_runtime_hooks(ctx)
            return _finish(True)
        except Exception:
            return _finish(False)
    if action in {'panview_follow_camera', 'panview_show_hud'}:
        if target:
            try:
                from .runtime import ensure_panview_runtime as _ensure_panview_runtime
                _ensure_panview_runtime()
            except Exception:
                pass
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        prop = 'panview_follow_active_camera' if action == 'panview_follow_camera' else 'panview_show_hud'
        if scene is None or not hasattr(scene, prop):
            return _finish(not target)
        try:
            setattr(scene, prop, target)
            try:
                from .runtime import panview as _panview
                save_fn = getattr(_panview, 'save_persistent_panview_settings', None)
                if callable(save_fn):
                    save_fn(ctx)
            except Exception:
                pass
            return _finish(True)
        except Exception:
            return _finish(False)
    return _finish(False)

def apply_saved_always_on_states(context=None) -> None:
    """Restore saved always-on choices without importing disabled tools."""
    global _APPLYING_SAVED_ALWAYS_ON_STATES
    if _APPLYING_SAVED_ALWAYS_ON_STATES or _MANUAL_TOGGLE_SET_DEPTH > 0:
        return
    ctx = context or getattr(bpy, 'context', None)
    state = dict(_load_always_state())
    _APPLYING_SAVED_ALWAYS_ON_STATES = True
    try:
        for action in _ALWAYS_ON_ACTION_ORDER:
            if action not in state:
                continue
            try:
                _manual_toggle_set(action, ctx, enabled=bool(state[action]))
            except Exception:
                pass
    finally:
        _APPLYING_SAVED_ALWAYS_ON_STATES = False
        try:
            _sync_always_toggle_props(ctx)
        except Exception:
            pass


def _draw_manual_toggle(layout, context, action: str) -> None:
    """Draw one toggle from registered RNA or an existing memory cache only."""
    label = _manual_row_label(action, context)
    owner = _bool_owner(context)
    prop_name = _always_prop_name(action)
    if owner is not None and hasattr(owner, prop_name):
        try:
            enabled = bool(getattr(owner, prop_name, False))
        except Exception:
            enabled = False
    else:
        cache = _ALWAYS_STATE_CACHE if isinstance(_ALWAYS_STATE_CACHE, dict) else {}
        enabled = bool(cache.get(str(action or '').strip(), False))
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if owner is not None and hasattr(owner, prop_name):
        right.row(align=True).prop(owner, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
    else:
        try:
            right.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
        except Exception:
            pass


def _feature_operator_id() -> str:
    """Return the already registered toggle id without draw-time setup."""
    try:
        return str(getattr(feature_toggle, '_OPERATOR_ID', '') or '')
    except Exception:
        return ''


def _draw_captured_toggle(layout, context, item: dict[str, Any], op_id: str) -> bool:
    del op_id
    alias = str(item.get('alias') or '').strip()
    feature_key = str(item.get('key') or '').strip()
    if not alias or not feature_key or (alias, feature_key) in _SUPPRESSED_CAPTURED_TOGGLES:
        return False
    owner = _bool_owner(context)
    prop_name = _captured_prop_name(alias, feature_key)
    if owner is not None and hasattr(owner, prop_name):
        try:
            enabled = bool(getattr(owner, prop_name, False))
        except Exception:
            enabled = bool(item.get('enabled'))
    else:
        # feature_entries() snapshots _STATE_CACHE without loading it.  Drawing
        # must never call is_feature_enabled(), which can read its JSON sidecar.
        enabled = bool(item.get('enabled'))
    tool_label = str(item.get('tool_label') or alias.replace('_', ' ').title())
    feature_label = ui_pair(str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key), context)
    label = f'{tool_label}: {feature_label}'
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if owner is not None and hasattr(owner, prop_name):
        right.row(align=True).prop(owner, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        return True
    disabled = right.row(align=True)
    try:
        disabled.enabled = False
        disabled.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
    except Exception:
        try:
            right.label(text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled))
        except Exception:
            pass
    return True


class SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_always_toggle(bpy.types.Operator):
    bl_idname = 'smart_workspace_suite.always_toggle'
    bl_label = ui_pair('Toggle Always-on Feature', '常時起動機能を切り替え')
    bl_description = ui_pair('Load only the required integrated tool when needed, then enable or disable the selected always-on feature. The setting is saved immediately.', '必要な場合だけ対象の統合ツールを読み込み、選択した常時起動機能を有効または無効にします。設定は即時保存されます。')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    action: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, 'action', '') or '')
        return _manual_text(action, 'desc', context) or cls.bl_description

    def execute(self, context):
        action = str(self.action or '').strip()
        if not action:
            return {'CANCELLED'}
        if not _manual_toggle_set(action, context):
            self.report({'WARNING'}, ui_pair('The selected always-on feature could not be changed.', '選択した常時起動機能を変更できませんでした。', context))
            return {'CANCELLED'}
        self.report({'INFO'}, ui_pair('Always-on feature setting changed.', '常時起動機能の設定を変更しました。', context))
        return {'FINISHED'}


class SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_n_panel_state_save_toggle(bpy.types.Operator):
    bl_idname = 'smart_workspace_suite.n_panel_state_save_toggle'
    bl_label = ui_pair('N-panel State Save', 'Nパネル状態保存')
    bl_description = ui_pair(
        "Toggle crash-safe N-panel state journaling. Changes are written to a small add-on-owned live journal without rebuilding the complete Smart Workspace settings graph; the canonical settings file is committed at file-save and shutdown boundaries.",
        "Smart Workspace のNパネル設定変更を、Blenderのバージョン別config内 Smart_WorkSpace_Suite/Smart_WorkSpace_Suite.json へ即時保存するかを切り替えます。無効の場合は、現在のファイルを閉じる/置き換える時、またはSmart Workspaceのプリファレンス保存時に保存します。",
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    enabled: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            "Function: control lightweight N-panel state journaling. On: each edit is coalesced into a small atomic live journal. Off: no edit-time journal timer remains; settings are still committed at explicit file-save, add-on disable, and Blender shutdown boundaries.",
            "機能: Nパネル状態の中央保存を制御します。有効: 全ての設定変更を即時に config/Smart_WorkSpace_Suite/Smart_WorkSpace_Suite.json へ反映します。無効: 現在のファイルを閉じる/置き換える時、またはプリファレンス保存時にJSONへ保存します。バックグラウンド保存チェックを減らしつつ、シーン切り替えやBlender起動後も設定を維持したい場合に使います。",
            context,
        )

    def execute(self, context):
        st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
        if st is None or not hasattr(st, 'n_panel_state_save_enabled'):
            return {'CANCELLED'}
        requested = bool(self.enabled)
        try:
            previous = getattr(st, 'n_panel_state_save_enabled', True)
            previous = previous if isinstance(previous, bool) else True
        except Exception:
            previous = True
        try:
            setattr(st, 'n_panel_state_save_enabled', requested)
            from . import storage as _suite_storage
            from .runtime import core as _nptl_core
            live_state = _nptl_core._read_live_state_document(refresh=True)
            live_ui = live_state.get('ui_state') if isinstance(live_state, dict) else None
            if (
                _suite_storage.n_panel_state_save_enabled(True) is not requested
                or not isinstance(live_ui, dict)
                or live_ui.get('n_panel_state_save_enabled') is not requested
            ):
                raise OSError('N-panel state-save journal verification failed')
            from . import persistence as _suite_persistence
            sync_policy = getattr(_suite_persistence, 'sync_continuous_autosave_policy', None)
            if callable(sync_policy) and not bool(sync_policy()):
                raise RuntimeError('Persistence boundary handlers could not be synchronized')
            return {'FINISHED'}
        except Exception as exc:
            try:
                setattr(st, 'n_panel_state_save_enabled', previous)
            except Exception:
                pass
            try:
                from . import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
            except Exception:
                pass
            self.report({'ERROR'}, error_text(exc, 'The setting could not be changed', '設定を変更できませんでした', context))
            return {'CANCELLED'}


def _draw_n_panel_state_save_toggle(layout, context) -> None:
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    enabled = True
    if st is not None and hasattr(st, 'n_panel_state_save_enabled'):
        try:
            enabled = bool(getattr(st, 'n_panel_state_save_enabled', True))
        except Exception:
            enabled = True
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=ui_pair('N-panel State Save', 'Nパネル状態保存', context))
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if st is not None and hasattr(st, 'n_panel_state_save_enabled'):
        right.row(align=True).prop(st, 'n_panel_state_save_enabled', text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        return
    disabled = right.row(align=True)
    try:
        disabled.enabled = False
        disabled.label(text=_enabled_text(False, context), icon='CHECKBOX_DEHLT')
    except Exception:
        try:
            right.label(text=_enabled_text(False, context), icon='CHECKBOX_DEHLT')
        except Exception:
            pass


def _draw_always_on_row_error(layout, context, label: str, exc: Exception | None = None) -> None:
    try:
        row = layout.row(align=True)
        row.label(text=str(label or ui_pair('Always-on feature item', '常時起動機能項目', context)), icon='ERROR')
    except Exception:
        pass


def draw_always_active_panel_body(layout, context) -> None:
    layout = localized_layout(layout, context)
    # Do not synchronize RNA toggle properties from Panel.draw.  Updating RNA
    # during draw can re-enter UI layout in Blender 5.1; buttons below call
    # operators that update state explicitly.

    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    try:
        _draw_n_panel_state_save_toggle(col, context)
    except Exception as exc:
        _draw_always_on_row_error(col, context, ui_pair('N-panel State Save', 'Nパネル状態保存', context), exc)
    try:
        col.separator(factor=0.5)
    except Exception:
        pass
    # Smart Workspace's native pin-follow wrapper is a real resident feature,
    # so expose its exact RNA immediately after N-panel State Save in the same
    # canonical row format as every other Always-on control.
    runtime_settings = _root_addon_preferences(context)
    if runtime_settings is not None and hasattr(runtime_settings, 'live_pin_follow_enabled'):
        try:
            enabled = bool(getattr(runtime_settings, 'live_pin_follow_enabled', False))
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            split.row(align=True).label(text=_manual_row_label('workspace_live_pin_follow', context))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.row(align=True).prop(
                runtime_settings,
                'live_pin_follow_enabled',
                text=_enabled_text(enabled, context),
                icon=_checkbox_icon(enabled),
                toggle=True,
            )
        except Exception as exc:
            _draw_always_on_row_error(col, context, _manual_row_label('workspace_live_pin_follow', context), exc)
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    for prop_name, label_en, label_ja in (
        ('workspace_step_reorder_enabled', 'Workspace Step Reorder', 'ワークスペース順序変更'),
        ('synchronize_workspaces_enabled', 'Synchronize Workspaces', 'ワークスペース同期'),
        ('floating_window_lock_enabled', 'Floating Window Lock', 'フローティングウィンドウ固定'),
    ):
        if st is None or not hasattr(st, prop_name):
            continue
        try:
            enabled = bool(getattr(st, prop_name, False))
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            split.row(align=True).label(text=ui_pair(label_en, label_ja, context))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.row(align=True).prop(st, prop_name, text=_enabled_text(enabled, context), icon=_checkbox_icon(enabled), toggle=True)
        except Exception as exc:
            _draw_always_on_row_error(col, context, ui_pair(label_en, label_ja, context), exc)
    for action in _ALWAYS_ON_ACTION_ORDER:
        try:
            _draw_manual_toggle(col, context, action)
        except Exception as exc:
            _draw_always_on_row_error(col, context, _manual_row_label(action, context), exc)

    op_id = _feature_operator_id()
    try:
        entries = list(feature_toggle.feature_entries() or [])
    except Exception:
        entries = []
    for item in entries:
        try:
            _draw_captured_toggle(col, context, item, op_id)
        except Exception as exc:
            try:
                label = f"{item.get('tool_label') or item.get('alias') or ''}: {item.get('label_ja') or item.get('label_en') or item.get('key') or ''}"
            except Exception:
                label = ui_pair('Captured always-on item', '検出された常時起動機能項目', context)
            _draw_always_on_row_error(col, context, label, exc)


def draw_always_active_panel(layout, context) -> None:
    layout = localized_layout(layout, context)
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None) if context is not None else None
    is_open = bool(getattr(st, 'show_always_on_toggles', False)) if st is not None else False

    box = layout.box()
    header = box.row(align=True)
    if st is not None and hasattr(st, 'show_always_on_toggles'):
        header.prop(st, 'show_always_on_toggles', text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=True)
    else:
        header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
    header.label(text=ui_pair('Always-on Toggles', '常時機能切り替え', context), icon='TIME')
    _draw_help_button(header, context, 'always_on_toggles', text=False, compact=True, scale=1.0)

    if not is_open:
        return
    draw_always_active_panel_body(box, context)


def _collect_records() -> None:
    if not loader.get_records():
        try:
            loader.prepare_records(force=True)
        except Exception:
            pass
    _RECORDS_BY_ALIAS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record


def register() -> bool:
    # This list must be empty on a new exact generation.  Never use registration
    # as an opportunity to remove an older/foreign live class.
    if _REGISTERED_CLASSES and not _safe_unregister_registered_classes():
        return False
    _collect_records()
    if feature_toggle.register_ui() is not True:
        return False
    # Stable RNA mirrors make each resident switch independently persistable
    # while the visible rows retain the common operator presentation.
    _register_always_toggle_properties()
    _register_captured_toggle_properties()
    _sync_always_toggle_props(getattr(bpy, 'context', None))
    classes = (
        SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_always_toggle,
        SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_n_panel_state_save_toggle,
    )
    for cls in classes:
        if not _safe_register_class(cls):
            return False
    return True


def unregister() -> bool:
    classes_ok = _safe_unregister_registered_classes()
    _unregister_always_toggle_properties()
    try:
        feature_ok = feature_toggle.unregister_ui() is not False
    except Exception:
        feature_ok = False
    return bool(classes_ok and feature_ok)
