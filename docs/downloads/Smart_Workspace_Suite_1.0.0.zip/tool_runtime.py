# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from . import loader as loader, ui_runtime as ui_runtime


_UI_RUNTIME_REGISTERED = False
_TOOLS_LOAD_TIMER_PENDING = False
_TOOLS_LOADED_ONCE = False


def ensure_ui_runtime() -> None:
    global _UI_RUNTIME_REGISTERED
    if _UI_RUNTIME_REGISTERED:
        return
    ui_runtime.register()
    _UI_RUNTIME_REGISTERED = True


def release_ui_runtime() -> None:
    global _UI_RUNTIME_REGISTERED, _TOOLS_LOAD_TIMER_PENDING, _TOOLS_LOADED_ONCE
    if not _UI_RUNTIME_REGISTERED:
        _TOOLS_LOAD_TIMER_PENDING = False
        _TOOLS_LOADED_ONCE = False
        return
    ui_runtime.unregister()
    _UI_RUNTIME_REGISTERED = False
    _TOOLS_LOAD_TIMER_PENDING = False
    _TOOLS_LOADED_ONCE = False



def _refresh_tool_ui_after_loader_change() -> None:
    if not _UI_RUNTIME_REGISTERED:
        return
    try:
        ui_runtime.register()
    except Exception:
        pass


def _load_all_tools_now(context=None) -> bool:
    global _TOOLS_LOADED_ONCE
    del context
    try:
        # Compatibility name retained.  This refreshes the static tool records
        # only and deliberately does not import every bundled tool.
        loader.register_all()
        _TOOLS_LOADED_ONCE = False
        _refresh_tool_ui_after_loader_change()
        return True
    except Exception:
        return False


def refresh_tool_records(context=None) -> bool:
    """Refresh the visible tool list while keeping tools unloaded until use."""
    return _load_all_tools_now(context)


def _deferred_load_all_tools():
    global _TOOLS_LOAD_TIMER_PENDING
    _TOOLS_LOAD_TIMER_PENDING = False
    # Refresh the inventory only.  Do not auto-load bundled tools.
    _load_all_tools_now(getattr(bpy, 'context', None))
    return None


def schedule_all_tools_load(delay: float = 0.30) -> None:
    """Load bundled tools from a timer, not from Panel.draw()."""
    global _TOOLS_LOAD_TIMER_PENDING
    if _TOOLS_LOAD_TIMER_PENDING or _TOOLS_LOADED_ONCE:
        return
    try:
        if bpy.app.timers.is_registered(_deferred_load_all_tools):
            _TOOLS_LOAD_TIMER_PENDING = True
            return
    except Exception:
        pass
    try:
        bpy.app.timers.register(_deferred_load_all_tools, first_interval=max(0.15, float(delay)))
        _TOOLS_LOAD_TIMER_PENDING = True
    except Exception:
        _TOOLS_LOAD_TIMER_PENDING = False


def ensure_all_tools_loaded(context=None) -> bool:
    """Public compatibility hook: refresh records, do not batch-load tools."""
    return refresh_tool_records(context)


def _addon_preferences(context=None):
    try:
        from . import preferences as _suite_preferences
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None)
        if callable(get_settings):
            return get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None

def _integrated_tools_are_active(context=None) -> bool:
    # Integrated add-ons are not auto-loaded from startup/repair timers.
    # Loading many add-ons mutates registered Panel classes and can collide with
    # Blender's N-panel layout pass. Tools are loaded explicitly from the Smart
    # Workspace UI when invoked.
    return False

def _rebuild_loader_state(context=None) -> None:
    # Keep runtime repair/startup idempotent.  Do not unload/reload bundled
    # add-ons from timers or N-panel preparation, because unregistering or
    # re-registering Panel classes during a UI layout pass can crash Blender.
    try:
        if not loader.get_records():
            loader.prepare_records(force=True)
    except Exception:
        pass


def apply_preference_runtime_state(context=None) -> None:
    try:
        _rebuild_loader_state(context)
    except Exception:
        pass
    try:
        ui_runtime.apply_saved_always_on_states(context)
    except Exception:
        pass


def register() -> None:
    global _TOOLS_LOADED_ONCE
    release_ui_runtime()
    try:
        loader.unregister_all(clear_records=True)
    except Exception:
        pass

    _TOOLS_LOADED_ONCE = False
    loader.prepare_records(force=True)
    # Keep bundled tools statically listed in the N-panel without importing all
    # of them immediately.  Actual loading is done from explicit operator
    # execution or the individual tool command or always-on toggle so Panel.draw() and startup do not
    # mutate Blender UI classes.



def unregister() -> None:
    global _TOOLS_LOAD_TIMER_PENDING, _TOOLS_LOADED_ONCE
    release_ui_runtime()
    try:
        if bpy.app.timers.is_registered(_deferred_load_all_tools):
            bpy.app.timers.unregister(_deferred_load_all_tools)
    except Exception:
        pass
    _TOOLS_LOAD_TIMER_PENDING = False
    _TOOLS_LOADED_ONCE = False
    loader.unregister_all(clear_records=True)
