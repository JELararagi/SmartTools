# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Floating window content lock for Smart WorkSpace Suite.

Blender 5.1 performs workspace changes inside a sensitive mode/undo transition.
This module therefore follows four strict safety rules:

* no Python callback is registered on ``Window.workspace``; workspace changes
  are detected only by the already-running feature timer after Blender returns
  to its normal event loop;
* no Area, Space, Region, Window, Screen, or WorkSpace RNA object is retained
  between timer ticks;
* editor restoration starts only after the window/workspace key and complete
  area layout have remained stable for several consecutive ticks;
* Window.workspace, Window.screen, context overrides, and UI operators are
  never written or invoked by this feature.

Only when the feature is enabled, one lightweight timer records detached-window
state and restores it after the window layout has remained stable for several
consecutive ticks.  Disabled means no timer, handler, or message-bus work.
"""

from __future__ import annotations

import gc
import sys
import time
from types import FunctionType, ModuleType
from typing import Any

import bpy
from . import runtime_ledger as _runtime_ledger
from bpy.app.handlers import persistent
from bpy.app.translations import contexts as i18n_contexts
from bpy.app.translations import pgettext_iface, pgettext_tip
from bpy.types import Operator

ADDON_ID = __package__ or __name__
_WORKSPACE_RUNTIME_API_VERSION = 5
_RUNTIME_QUARANTINE_KEY = "SMART_WORKSPACE_SUITE_WORKSPACE_RUNTIME_QUARANTINE"
TOOL_LABEL = "Floating Window Lock"
TOOL_LABEL_JA = "フローティングウィンドウ固定"
ENABLE_LABEL = "Enable"
DISABLE_LABEL = "Disable"
ENABLED_LABEL = "Enabled"
DISABLED_LABEL = "Disabled"
TOOL_DESCRIPTION = (
    "Keeps detached/floating Blender window editor contents stable while switching workspace tabs. "
    "Use this when an auxiliary 3D View, Outliner, Image Editor, Node Editor, or similar floating window must not follow the active workspace layout."
)
ENABLE_DESCRIPTION = (
    "Enables Floating Window Lock. Detached windows are captured as plain values and restored only after Blender finishes the workspace transition. "
    "Window.workspace, Window.screen, context overrides, and UI operators are never forced. The setting is saved immediately."
)
DISABLE_DESCRIPTION = (
    "Disables Floating Window Lock and removes its workspace-change watcher, file-load handlers, and runtime timer. "
    "Use this when floating windows should follow Blender's normal workspace behavior or when the lightest possible idle state is required."
)

_TRANSLATIONS = {
    "ja_JP": {
        ("*", TOOL_LABEL): TOOL_LABEL_JA,
        ("*", ENABLE_LABEL): "有効",
        ("*", DISABLE_LABEL): "無効",
        ("*", ENABLED_LABEL): "有効",
        ("*", DISABLED_LABEL): "無効",
        (i18n_contexts.operator_default, ENABLE_LABEL): "有効",
        (i18n_contexts.operator_default, DISABLE_LABEL): "無効",
        ("*", TOOL_DESCRIPTION): (
            "ワークスペースタブを切り替えても、切り離したフローティングウィンドウのエディター内容を維持します。"
            "補助用の3Dビュー、アウトライナー、画像エディター、ノードエディターなどを、アクティブなワークスペースのレイアウトへ追従させたくない場合に使用します。"
        ),
        ("*", ENABLE_DESCRIPTION): (
            'フローティングウィンドウ固定を有効にします。切り離しウィンドウを通常の値として記録し、Blenderのワークスペース切替が完全に終了してから復元します。ウィンドウ.workspace、ウィンドウ.screen、コンテキスト上書き、UIオペレーターは使用しません。設定は即時保存されます。'
        ),
        ("*", DISABLE_DESCRIPTION): (
            "フローティングウィンドウ固定を無効にし、ワークスペース切替監視、ファイル読込ハンドラー、実行タイマーを解除します。"
            "フローティングウィンドウをBlender標準の挙動に戻す場合、または通常時の負荷を最小にしたい場合に使用します。"
        ),
    }
}

_REGISTERED_CLASSES: list[type] = []
_REGISTERED = False
_ORPHAN_FLOATING_CLEANUP_DONE = False
_MSG_OWNER = object()
_ENABLED = False
_MSGBUS_INSTALLED = False
_RUNTIME_TIMER_RUNNING = False
_HANDLERS_INSTALLED = False
_SHUTTING_DOWN = False
_LOAD_IN_PROGRESS = False
_RUNTIME_GENERATION = object()
_RUNTIME_NAMESPACE_KEY = "SMART_WORKSPACE_SUITE_FLOATING_WINDOW_LOCK_RUNTIME_V4"
_LEGACY_RUNTIME_NAMESPACE_KEYS = (
    "SMART_WORKSPACE_SUITE_FLOATING_WINDOW_LOCK_RUNTIME_V3",
    "SMART_WORKSPACE_SUITE_FLOATING_WINDOW_LOCK_RUNTIME_V2",
    "SMART_WORKSPACE_SUITE_FLOATING_WINDOW_LOCK_RUNTIME_V1",
)

# These dictionaries contain primitives/lists/tuples only.  They never contain
# Blender RNA wrappers, which can become invalid when a workspace swaps screens.
_WINDOW_STATES: dict[int, dict[str, Any]] = {}
_PRIMARY_WINDOW_PTR = 0

# Workspace-transition debounce state.  Workspace changes are detected only
# from the feature timer; no callback is registered inside Blender's native
# ``ED_workspace_change`` transaction.  The observed key contains integers and
# strings only and never retains RNA wrappers.
_OBSERVED_WINDOW_KEYS: tuple[Any, ...] | None = None
_WORKSPACE_EVENT_PENDING = False
_WORKSPACE_EVENT_TIME = 0.0
_WORKSPACE_EVENT_REVISION = 0
_RESTORE_PHASE = "IDLE"  # IDLE / WAIT_LAYOUT
_STABLE_SIGNATURE: tuple[Any, ...] | None = None
_STABLE_TICKS = 0
_LAST_CAPTURE_TIME = 0.0
_POST_RESTORE_UNTIL = 0.0

_RUNTIME_TICK = 0.12
_IDLE_CAPTURE_INTERVAL = 0.80
_WORKSPACE_SETTLE_DELAY = 1.00
_EDITOR_TYPE_SETTLE_DELAY = 0.60
_POST_RESTORE_DELAY = 0.50
_STABLE_TICKS_REQUIRED = 5

_REGION_ATTRS = (
    "show_region_header",
    "show_region_tool_header",
    "show_region_toolbar",
    "show_region_ui",
    "show_region_hud",
    "show_region_channels",
    "show_region_footer",
)
_VIEW3D_ATTRS = (
    "lens",
    "clip_start",
    "clip_end",
    "lock_camera",
    "show_gizmo",
    "show_gizmo_tool",
    "show_gizmo_navigate",
    "show_gizmo_context",
    "show_gizmo_object_translate",
    "show_gizmo_object_rotate",
    "show_gizmo_object_scale",
    "show_gizmo_empty",
    "show_gizmo_camera",
    "show_gizmo_light",
    "show_object_viewport_mesh",
    "show_object_viewport_curve",
    "show_object_viewport_surf",
    "show_object_viewport_meta",
    "show_object_viewport_font",
    "show_object_viewport_armature",
    "show_object_viewport_lattice",
    "show_object_viewport_empty",
    "show_object_viewport_light",
    "show_object_viewport_camera",
    "show_object_viewport_speaker",
    "show_object_viewport_light_probe",
)
_GENERIC_SPACE_ATTRS = (
    "show_region_toolbar",
    "show_region_ui",
    "show_region_header",
    "show_region_tool_header",
    "show_region_hud",
    "show_region_channels",
)
_SPACE_TYPE_ATTRS = {
    "IMAGE_EDITOR": ("ui_mode", "display_channels", "show_metadata", "show_repeat"),
    "NODE_EDITOR": ("tree_type", "shader_type", "texture_type", "pin"),
    "SEQUENCE_EDITOR": ("view_type", "display_type", "show_metadata"),
    "DOPESHEET_EDITOR": ("mode",),
    "GRAPH_EDITOR": ("mode",),
    "NLA_EDITOR": tuple(),
    "TEXT_EDITOR": ("show_line_numbers", "show_word_wrap", "show_syntax_highlight"),
    "CONSOLE": ("font_size",),
    "CLIP_EDITOR": ("mode", "view"),
    "PROPERTIES": ("context", "pin_id"),
}
_OUTLINER_ATTRS = (
    "display_mode",
    "filter_text",
    "use_filter_case_sensitive",
    "use_filter_complete",
    "use_filter_object",
    "use_filter_object_content",
    "use_filter_children",
    "use_filter_collection",
    "use_filter_id_type",
    "filter_id_type",
    "show_restrict_column_enable",
    "show_restrict_column_select",
    "show_restrict_column_hide",
    "show_restrict_column_viewport",
    "show_restrict_column_render",
    "show_restrict_column_holdout",
    "show_restrict_column_indirect_only",
)


def _iface(message: str) -> str:
    return pgettext_iface(message)


def _tip(message: str) -> str:
    return pgettext_tip(message)


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(context, "preferences", None) if context is not None else getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
        if getattr(view, "use_translate_interface", True) is False:
            return False
        lang = str(getattr(view, "language", "") or "").strip().lower()
        if lang and lang != "default":
            return lang.startswith("ja") or "japanese" in lang
    except Exception:
        pass
    try:
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "").strip().lower()
        return locale.startswith("ja")
    except Exception:
        return False


def ui_label(en: str, ja: str, context=None) -> str:
    return str(ja if _is_ja(context) else en)


def _settings(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    return getattr(wm, "nptl_settings", None) if wm is not None else None


def _driver_namespace():
    try:
        return bpy.app.driver_namespace
    except Exception:
        return None


def _runtime_quarantined() -> bool:
    """Block pre-fix workspace callbacks after a same-session ZIP update."""
    ns = _driver_namespace()
    if ns is None:
        return False
    try:
        return bool(ns.get(_RUNTIME_QUARANTINE_KEY, False))
    except Exception:
        return False


def _runtime_record_is_current() -> bool:
    if _SHUTTING_DOWN or _LOAD_IN_PROGRESS or not _ENABLED or _runtime_quarantined():
        return False
    ns = _driver_namespace()
    if ns is None:
        return False
    try:
        record = ns.get(_RUNTIME_NAMESPACE_KEY)
        return isinstance(record, dict) and record.get("generation") is _RUNTIME_GENERATION and bool(record.get("active", False))
    except Exception:
        return False


def _unregister_timer_ref(timer_fn: Any) -> None:
    if not callable(timer_fn):
        return
    try:
        if bpy.app.timers.is_registered(timer_fn):
            bpy.app.timers.unregister(timer_fn)
    except Exception:
        pass


def _clear_msgbus_owner(owner: Any) -> None:
    if owner is None:
        return
    try:
        bpy.msgbus.clear_by_owner(owner)
    except Exception:
        pass


def _cleanup_runtime_record(record: Any) -> None:
    """Never reclaim an unproven runtime record from another generation."""
    return None


def _cleanup_previous_runtime() -> None:
    """No-op; unproven generations require a Blender process restart."""
    return None

def _publish_runtime_record() -> None:
    ns = _driver_namespace()
    if ns is None:
        return
    try:
        ns[_RUNTIME_NAMESPACE_KEY] = {
            "generation": _RUNTIME_GENERATION,
            "module": __name__,
            "msg_owner": _MSG_OWNER,
            "runtime_timer": _runtime_timer,
            "active": bool(_ENABLED and not _SHUTTING_DOWN),
        }
    except Exception:
        pass


def _orphan_callback_noop(*_args: Any, **_kwargs: Any) -> None:
    return None


def _neutralize_stale_function(fn: Any) -> None:
    """Never mutate callback code or unregister an unproven generation."""
    return None


def _cleanup_orphan_floating_timers() -> None:
    """Compatibility no-op; old generations are never scanned or patched."""
    return None

def is_enabled(context=None) -> bool:
    st = _settings(context)
    if st is None or not hasattr(st, "floating_window_lock_enabled"):
        return False
    try:
        return bool(getattr(st, "floating_window_lock_enabled", False))
    except Exception:
        return False


def _rna_ptr(value: Any) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _window_ptr(window: Any) -> int:
    return _rna_ptr(window)


def _window_manager(context=None):
    try:
        ctx = context or getattr(bpy, "context", None)
        return getattr(ctx, "window_manager", None)
    except Exception:
        return None


def _safe_attr(obj: Any, attr: str, default: Any = None) -> Any:
    try:
        return getattr(obj, attr)
    except Exception:
        return default


def _safe_set(obj: Any, attr: str, value: Any) -> bool:
    if obj is None or value is None:
        return False
    try:
        setattr(obj, attr, value)
        return True
    except Exception:
        return False


def _as_float_list(value: Any) -> list[float]:
    try:
        return [float(v) for v in value]
    except Exception:
        return []


def _plain_scalar(value: Any) -> Any:
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _capture_simple_attrs(obj: Any, names: tuple[str, ...]) -> dict[str, Any]:
    data: dict[str, Any] = {}
    for name in names:
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        plain = _plain_scalar(value)
        if plain is not None or value is None:
            data[name] = plain
    return data


def _restore_simple_attrs(obj: Any, data: dict[str, Any]) -> None:
    if obj is None or not isinstance(data, dict):
        return
    for name, value in data.items():
        _safe_set(obj, str(name), value)


def _ui_region_category(area: Any) -> str:
    try:
        for region in tuple(getattr(area, "regions", ()) or ()):
            if getattr(region, "type", None) == "UI":
                return str(getattr(region, "active_panel_category", "") or "")
    except Exception:
        pass
    return ""


def _set_ui_region_category(area: Any, category: str) -> None:
    if not category:
        return
    try:
        for region in tuple(getattr(area, "regions", ()) or ()):
            if getattr(region, "type", None) != "UI":
                continue
            _safe_set(region, "active_panel_category", str(category))
            break
    except Exception:
        pass


def _capture_view3d(space: Any, area: Any) -> dict[str, Any]:
    data: dict[str, Any] = {
        "space_attrs": _capture_simple_attrs(space, _REGION_ATTRS + _VIEW3D_ATTRS),
        "ui_category": _ui_region_category(area),
    }
    try:
        overlay = getattr(space, "overlay", None)
        if overlay is not None:
            data["overlay"] = _capture_simple_attrs(
                overlay,
                (
                    "show_overlays", "show_floor", "show_axis_x", "show_axis_y", "show_axis_z",
                    "show_outline_selected", "show_relationship_lines", "show_text", "show_cursor",
                    "show_face_orientation", "show_extras", "show_bones", "show_motion_paths",
                ),
            )
    except Exception:
        pass
    try:
        shading = getattr(space, "shading", None)
        if shading is not None:
            data["shading"] = _capture_simple_attrs(
                shading,
                (
                    "type", "light", "color_type", "show_xray", "show_backface_culling",
                    "show_cavity", "show_object_outline", "show_specular_highlight", "show_shadows",
                    "background_type", "show_transparent", "use_scene_lights", "use_scene_world",
                    "use_scene_lights_render", "use_scene_world_render",
                ),
            )
    except Exception:
        pass
    try:
        region_3d = getattr(space, "region_3d", None)
        if region_3d is not None:
            data["region_3d"] = {
                "view_perspective": _safe_attr(region_3d, "view_perspective", None),
                "view_distance": _safe_attr(region_3d, "view_distance", None),
                "view_location": _as_float_list(_safe_attr(region_3d, "view_location", [])),
                "view_rotation": _as_float_list(_safe_attr(region_3d, "view_rotation", [])),
                "view_camera_offset": _as_float_list(_safe_attr(region_3d, "view_camera_offset", [])),
                "view_camera_zoom": _safe_attr(region_3d, "view_camera_zoom", None),
                "lock_rotation": _safe_attr(region_3d, "lock_rotation", None),
            }
    except Exception:
        pass
    return data


def _restore_view3d(space: Any, area: Any, data: dict[str, Any]) -> None:
    _restore_simple_attrs(space, data.get("space_attrs", {}))
    try:
        overlay = getattr(space, "overlay", None)
        if overlay is not None:
            _restore_simple_attrs(overlay, data.get("overlay", {}))
    except Exception:
        pass
    try:
        shading = getattr(space, "shading", None)
        if shading is not None:
            _restore_simple_attrs(shading, data.get("shading", {}))
    except Exception:
        pass
    try:
        region_3d = getattr(space, "region_3d", None)
        rd = data.get("region_3d", {}) if isinstance(data, dict) else {}
        if region_3d is not None and isinstance(rd, dict):
            _safe_set(region_3d, "view_perspective", rd.get("view_perspective"))
            _safe_set(region_3d, "view_distance", rd.get("view_distance"))
            _safe_set(region_3d, "view_camera_zoom", rd.get("view_camera_zoom"))
            _safe_set(region_3d, "lock_rotation", rd.get("lock_rotation"))
            loc = rd.get("view_location")
            rot = rd.get("view_rotation")
            offset = rd.get("view_camera_offset")
            if isinstance(loc, (list, tuple)) and len(loc) == 3:
                _safe_set(region_3d, "view_location", tuple(float(v) for v in loc))
            if isinstance(rot, (list, tuple)) and len(rot) == 4:
                _safe_set(region_3d, "view_rotation", tuple(float(v) for v in rot))
            if isinstance(offset, (list, tuple)) and len(offset) == 2:
                _safe_set(region_3d, "view_camera_offset", tuple(float(v) for v in offset))
    except Exception:
        pass
    _set_ui_region_category(area, str(data.get("ui_category") or ""))


def _capture_space(space: Any, area: Any) -> dict[str, Any]:
    stype = str(getattr(space, "type", "") or "")
    data: dict[str, Any] = {"type": stype}
    if stype == "VIEW_3D":
        data.update(_capture_view3d(space, area))
    elif stype == "OUTLINER":
        data["space_attrs"] = _capture_simple_attrs(space, _OUTLINER_ATTRS + _REGION_ATTRS)
    else:
        type_attrs = _SPACE_TYPE_ATTRS.get(stype, tuple())
        data["space_attrs"] = _capture_simple_attrs(space, _GENERIC_SPACE_ATTRS + tuple(type_attrs))
    return data


def _restore_space(space: Any, area: Any, data: dict[str, Any]) -> None:
    if not isinstance(data, dict):
        return
    stype = str(getattr(space, "type", "") or "")
    saved_type = str(data.get("type") or "")
    if saved_type and stype != saved_type:
        return
    if stype == "VIEW_3D":
        _restore_view3d(space, area, data)
    else:
        _restore_simple_attrs(space, data.get("space_attrs", {}))


def _area_bounds(area: Any) -> tuple[int, int, int, int]:
    try:
        return (int(area.x), int(area.y), int(area.width), int(area.height))
    except Exception:
        return (0, 0, 0, 0)


def _capture_area(area: Any, index: int) -> dict[str, Any]:
    # Only the editor family is required to keep a detached 3D View, Outliner,
    # Image Editor, Node Editor, and similar window from following workspace
    # layouts.  Space/Region properties are intentionally not retained or
    # restored: Blender 5.1 can invalidate those wrappers even after the visible
    # layout appears stable, causing a native crash in PyObject_SetAttr.
    return {
        "index": int(index),
        "type": str(getattr(area, "type", "") or ""),
        "bounds": _area_bounds(area),
    }


def _capture_window_content(window: Any) -> dict[str, Any]:
    screen = getattr(window, "screen", None)
    workspace = getattr(window, "workspace", None)
    data: dict[str, Any] = {
        "window_ptr": _window_ptr(window),
        "workspace_name": str(getattr(workspace, "name", "") or ""),
        "screen_name": str(getattr(screen, "name", "") or ""),
        "areas": [],
    }
    if screen is None:
        return data
    try:
        for index, area in enumerate(tuple(getattr(screen, "areas", ()) or ())):
            data["areas"].append(_capture_area(area, index))
    except Exception:
        pass
    return data


def _match_area(
    saved: dict[str, Any],
    current_areas: list[Any],
    used: set[int],
    saved_count: int,
) -> Any | None:
    """Resolve only an unambiguous live Area; never guess across layouts."""
    saved_bounds = tuple(saved.get("bounds") or ())
    for idx, area in enumerate(current_areas):
        if idx in used:
            continue
        if tuple(_area_bounds(area)) == saved_bounds:
            used.add(idx)
            return area

    if saved_count == 1 and len(current_areas) == 1 and 0 not in used:
        used.add(0)
        return current_areas[0]

    if saved_count == len(current_areas):
        try:
            idx = int(saved.get("index", -1))
        except Exception:
            idx = -1
        if 0 <= idx < len(current_areas) and idx not in used:
            used.add(idx)
            return current_areas[idx]

    # A same-type match is safe because it requires no RNA write.  It prevents
    # another saved area from consuming the already-correct editor.
    saved_type = str(saved.get("type") or "")
    if saved_type:
        for idx, area in enumerate(current_areas):
            if idx in used:
                continue
            try:
                if str(getattr(area, "type", "") or "") == saved_type:
                    used.add(idx)
                    return area
            except Exception:
                continue
    return None


def _restore_window_area_types(window: Any, state: dict[str, Any]) -> bool:
    """First restore pass: set Area.type only, then let Blender settle."""
    screen = getattr(window, "screen", None)
    saved_areas = state.get("areas") if isinstance(state, dict) else None
    if screen is None or not isinstance(saved_areas, list):
        return False
    try:
        current_areas = list(getattr(screen, "areas", ()) or ())
    except Exception:
        return False
    changed = False
    used: set[int] = set()
    for saved in saved_areas:
        if not isinstance(saved, dict):
            continue
        area = _match_area(saved, current_areas, used, len(saved_areas))
        if area is None:
            continue
        saved_type = str(saved.get("type") or "")
        if not saved_type:
            continue
        try:
            current_type = str(getattr(area, "type", "") or "")
        except Exception:
            continue
        if current_type == saved_type:
            continue
        if not _rna_ptr(area):
            continue
        try:
            area.type = saved_type
            # Setting Area.type rebuilds its Space/Region data.  Stop this pass
            # immediately so no stale Area from the pre-write list is touched.
            return True
        except Exception:
            continue
    return changed


def _restore_window_space_properties(window: Any, state: dict[str, Any]) -> None:
    """Deliberate no-op: never write Space/Region RNA during workspace changes."""
    del window, state
    return None


def _windows_snapshot(wm: Any) -> list[Any]:
    try:
        return list(getattr(wm, "windows", ()) or ())
    except Exception:
        return []


def _refresh_primary_window(windows: list[Any]) -> int:
    global _PRIMARY_WINDOW_PTR
    live = [_window_ptr(window) for window in windows]
    live = [ptr for ptr in live if ptr]
    if not live:
        _PRIMARY_WINDOW_PTR = 0
    elif _PRIMARY_WINDOW_PTR not in live:
        # Blender keeps the original application window first and appends
        # detached windows afterwards.  Never write workspace/screen pointers.
        _PRIMARY_WINDOW_PTR = live[0]
    return _PRIMARY_WINDOW_PTR


def _workspace_key_signature(windows: list[Any]) -> tuple[Any, ...]:
    """Return primitive window/workspace/screen identity without touching Areas.

    This is intentionally the first and only observation made on a timer tick
    that detects a workspace change.  The timer returns immediately afterwards,
    so Area/Space RNA is not inspected in the same event-loop turn that Blender
    swaps the active Screen.
    """
    result: list[tuple[Any, ...]] = []
    for window in windows:
        try:
            ptr = _window_ptr(window)
            workspace = getattr(window, "workspace", None)
            screen = getattr(window, "screen", None)
            result.append((
                ptr,
                _rna_ptr(workspace),
                str(getattr(workspace, "name", "") or ""),
                _rna_ptr(screen),
                str(getattr(screen, "name", "") or ""),
            ))
        except Exception:
            return tuple()
    return tuple(result)


def _layout_signature(windows: list[Any]) -> tuple[Any, ...]:
    signature: list[Any] = []
    for window in windows:
        try:
            ptr = _window_ptr(window)
            screen = getattr(window, "screen", None)
            workspace = getattr(window, "workspace", None)
            screen_ptr = _rna_ptr(screen)
            workspace_name = str(getattr(workspace, "name", "") or "")
            screen_name = str(getattr(screen, "name", "") or "")
            areas = tuple(
                (_area_bounds(area), str(getattr(area, "type", "") or ""))
                for area in tuple(getattr(screen, "areas", ()) or ())
            ) if screen is not None else tuple()
            signature.append((ptr, workspace_name, screen_ptr, screen_name, areas))
        except Exception:
            return tuple()
    return tuple(signature)


def _capture_secondary_windows(windows: list[Any]) -> None:
    global _LAST_CAPTURE_TIME
    primary = _refresh_primary_window(windows)
    live_secondary: set[int] = set()
    for window in windows:
        ptr = _window_ptr(window)
        if not ptr or ptr == primary:
            continue
        live_secondary.add(ptr)
        try:
            _WINDOW_STATES[ptr] = _capture_window_content(window)
        except Exception:
            pass
    for ptr in tuple(_WINDOW_STATES):
        if ptr not in live_secondary:
            _WINDOW_STATES.pop(ptr, None)
    _LAST_CAPTURE_TIME = time.monotonic()


def capture_now(context=None) -> None:
    """Capture detached windows immediately when no transition is underway."""
    global _OBSERVED_WINDOW_KEYS
    if not _runtime_record_is_current() or _WORKSPACE_EVENT_PENDING:
        return
    wm = _window_manager(context)
    if wm is None:
        return
    windows = _windows_snapshot(wm)
    keys = _workspace_key_signature(windows)
    if keys:
        _OBSERVED_WINDOW_KEYS = keys
    if len(windows) <= 1:
        _WINDOW_STATES.clear()
        _refresh_primary_window(windows)
        return
    _capture_secondary_windows(windows)


def _restore_secondary_types(windows: list[Any]) -> bool:
    primary = _refresh_primary_window(windows)
    for window in windows:
        ptr = _window_ptr(window)
        if not ptr or ptr == primary:
            continue
        state = _WINDOW_STATES.get(ptr)
        if not isinstance(state, dict):
            continue
        try:
            if _restore_window_area_types(window, state):
                # Area.type invalidates Space/Region wrappers for this screen.
                # Do not inspect any further window or area in the same tick.
                return True
        except Exception:
            continue
    return False


def _restore_secondary_properties(windows: list[Any]) -> None:
    """Compatibility no-op; editor Space/Region properties are never restored."""
    del windows
    return None


def _reset_stability() -> None:
    global _STABLE_SIGNATURE, _STABLE_TICKS
    _STABLE_SIGNATURE = None
    _STABLE_TICKS = 0


def _observe_stability(signature: tuple[Any, ...]) -> bool:
    global _STABLE_SIGNATURE, _STABLE_TICKS
    if not signature:
        _reset_stability()
        return False
    if signature == _STABLE_SIGNATURE:
        _STABLE_TICKS += 1
    else:
        _STABLE_SIGNATURE = signature
        _STABLE_TICKS = 1
    return _STABLE_TICKS >= _STABLE_TICKS_REQUIRED


def _mark_workspace_event() -> None:
    """Mark a transition from the polling timer without retaining RNA data."""
    global _WORKSPACE_EVENT_PENDING, _WORKSPACE_EVENT_TIME, _WORKSPACE_EVENT_REVISION, _RESTORE_PHASE
    global _STABLE_SIGNATURE, _STABLE_TICKS
    if _SHUTTING_DOWN or not _ENABLED:
        return
    _WORKSPACE_EVENT_PENDING = True
    _WORKSPACE_EVENT_TIME = time.monotonic()
    _WORKSPACE_EVENT_REVISION += 1
    _RESTORE_PHASE = "WAIT_LAYOUT"
    _STABLE_SIGNATURE = None
    _STABLE_TICKS = 0


def _workspace_changed_notify() -> None:
    """Legacy callback compatibility; current builds never subscribe it."""
    _mark_workspace_event()


def _runtime_timer():
    global _RUNTIME_TIMER_RUNNING, _OBSERVED_WINDOW_KEYS
    global _WORKSPACE_EVENT_PENDING, _WORKSPACE_EVENT_TIME
    global _RESTORE_PHASE, _POST_RESTORE_UNTIL

    if not _runtime_record_is_current():
        _RUNTIME_TIMER_RUNNING = False
        return None
    if _LOAD_IN_PROGRESS:
        return 0.25

    wm = _window_manager(getattr(bpy, "context", None))
    if wm is None:
        return 0.25
    windows = _windows_snapshot(wm)
    _refresh_primary_window(windows)

    # Poll only primitive Window/WorkSpace/Screen identities first.  When they
    # change, mark the event and return immediately.  This guarantees that no
    # Area/Space/Region lookup or write occurs in the same timer invocation that
    # first observes Blender's workspace swap.
    keys = _workspace_key_signature(windows)
    if not keys:
        return 0.25
    if _OBSERVED_WINDOW_KEYS is None:
        _OBSERVED_WINDOW_KEYS = keys
    elif keys != _OBSERVED_WINDOW_KEYS:
        _OBSERVED_WINDOW_KEYS = keys
        if len(windows) > 1:
            _mark_workspace_event()
        else:
            _WORKSPACE_EVENT_PENDING = False
            _RESTORE_PHASE = "IDLE"
            _reset_stability()
        return _RUNTIME_TICK

    if len(windows) <= 1:
        _WINDOW_STATES.clear()
        _WORKSPACE_EVENT_PENDING = False
        _RESTORE_PHASE = "IDLE"
        _reset_stability()
        return _IDLE_CAPTURE_INTERVAL

    now = time.monotonic()

    if _WORKSPACE_EVENT_PENDING:
        # A further workspace/screen change was already handled above and reset
        # the event time.  Do not inspect Areas until the primitive identity has
        # remained unchanged for the complete settle delay.
        if now - _WORKSPACE_EVENT_TIME < _WORKSPACE_SETTLE_DELAY:
            _reset_stability()
            return _RUNTIME_TICK

        signature = _layout_signature(windows)
        if not signature:
            _WORKSPACE_EVENT_TIME = now
            _reset_stability()
            return _RUNTIME_TICK
        if not _observe_stability(signature):
            return _RUNTIME_TICK

        if _RESTORE_PHASE == "WAIT_LAYOUT":
            changed_type = _restore_secondary_types(windows)
            _reset_stability()
            if changed_type:
                # Restore at most one Area.type per settled pass.  Blender may
                # rebuild the complete Space/Region tree for that window.
                _WORKSPACE_EVENT_TIME = now
                return _RUNTIME_TICK

        _WORKSPACE_EVENT_PENDING = False
        _RESTORE_PHASE = "IDLE"
        _POST_RESTORE_UNTIL = now + _POST_RESTORE_DELAY
        _reset_stability()
        return _RUNTIME_TICK

    if now < _POST_RESTORE_UNTIL:
        return _RUNTIME_TICK
    if now - _LAST_CAPTURE_TIME >= _IDLE_CAPTURE_INTERVAL:
        _capture_secondary_windows(windows)
    return _RUNTIME_TICK


def _ensure_runtime_timer(*, first_interval: float = 0.20) -> None:
    global _RUNTIME_TIMER_RUNNING
    if _SHUTTING_DOWN or _LOAD_IN_PROGRESS or not _ENABLED:
        return
    _publish_runtime_record()
    try:
        if bpy.app.timers.is_registered(_runtime_timer):
            _RUNTIME_TIMER_RUNNING = True
            return
    except Exception:
        pass
    try:
        bpy.app.timers.register(_runtime_timer, first_interval=max(0.05, float(first_interval)), persistent=False)
        _RUNTIME_TIMER_RUNNING = True
    except Exception:
        _RUNTIME_TIMER_RUNNING = False


def _stop_runtime_timer() -> None:
    global _RUNTIME_TIMER_RUNNING
    _unregister_timer_ref(_runtime_timer)
    _RUNTIME_TIMER_RUNNING = False


def _install_msgbus() -> None:
    """Clear stale owners; current runtime intentionally installs no msgbus."""
    global _MSGBUS_INSTALLED
    _clear_msgbus_owner(_MSG_OWNER)
    _MSGBUS_INSTALLED = False


def _remove_msgbus() -> None:
    global _MSGBUS_INSTALLED
    _clear_msgbus_owner(_MSG_OWNER)
    _MSGBUS_INSTALLED = False


@persistent
def _load_pre(_dummy=None) -> None:
    global _LOAD_IN_PROGRESS, _OBSERVED_WINDOW_KEYS, _WORKSPACE_EVENT_PENDING, _RESTORE_PHASE
    _LOAD_IN_PROGRESS = True
    _OBSERVED_WINDOW_KEYS = None
    _WORKSPACE_EVENT_PENDING = False
    _RESTORE_PHASE = "IDLE"
    _reset_stability()
    _stop_runtime_timer()
    _remove_msgbus()
    _WINDOW_STATES.clear()


@persistent
def _load_post(_dummy=None) -> None:
    global _LOAD_IN_PROGRESS, _OBSERVED_WINDOW_KEYS
    global _WORKSPACE_EVENT_PENDING, _WORKSPACE_EVENT_TIME, _RESTORE_PHASE
    if _SHUTTING_DOWN or not _ENABLED:
        _LOAD_IN_PROGRESS = False
        return
    _LOAD_IN_PROGRESS = False
    _OBSERVED_WINDOW_KEYS = None
    _WORKSPACE_EVENT_PENDING = False
    _RESTORE_PHASE = "IDLE"
    _WORKSPACE_EVENT_TIME = time.monotonic()
    _reset_stability()
    _remove_msgbus()
    # No immediate RNA capture from load_post.  Let Blender finish all screen,
    # mode, undo, and workspace initialization first.
    _ensure_runtime_timer(first_interval=1.0)


def _append_handler_once(handler_list: Any, fn: Any) -> None:
    try:
        if fn not in handler_list:
            handler_list.append(fn)
    except Exception:
        pass


def _remove_handler_all(handler_list: Any, fn: Any) -> None:
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass


def _install_handlers() -> None:
    global _HANDLERS_INSTALLED
    try:
        _append_handler_once(bpy.app.handlers.load_pre, _load_pre)
        _append_handler_once(bpy.app.handlers.load_post, _load_post)
        _HANDLERS_INSTALLED = True
    except Exception:
        _HANDLERS_INSTALLED = False


def _remove_handlers() -> None:
    global _HANDLERS_INSTALLED
    try:
        _remove_handler_all(bpy.app.handlers.load_pre, _load_pre)
        _remove_handler_all(bpy.app.handlers.load_post, _load_post)
    except Exception:
        pass
    _HANDLERS_INSTALLED = False


class SMART_WORKSPACE_OT_set_floating_window_lock_enabled(Operator):
    bl_idname = "smart_workspace.set_floating_window_lock_enabled"
    bl_label = ENABLE_LABEL
    bl_description = TOOL_DESCRIPTION
    bl_options = set()

    enabled: bpy.props.BoolProperty(default=True)

    @classmethod
    def description(cls, context, properties):
        try:
            return _tip(ENABLE_DESCRIPTION if bool(getattr(properties, "enabled", True)) else DISABLE_DESCRIPTION)
        except Exception:
            return _tip(TOOL_DESCRIPTION)

    def execute(self, context):
        desired = bool(getattr(self, "enabled", True))
        st = _settings(context)
        if st is not None and hasattr(st, "floating_window_lock_enabled"):
            try:
                setattr(st, "floating_window_lock_enabled", desired)
            except Exception:
                pass
        apply_enabled(desired, context=context, save=True)
        self.report({"INFO"}, ui_label("Floating Window Lock setting saved.", "フローティングウィンドウ固定の設定を保存しました。", context))
        return {"FINISHED"}


_CLASSES = (SMART_WORKSPACE_OT_set_floating_window_lock_enabled,)


def shutdown_runtime(*, clear_registry: bool = True) -> None:
    """Stop every callback before Blender RNA or classes begin teardown."""
    global _ENABLED, _SHUTTING_DOWN, _LOAD_IN_PROGRESS, _OBSERVED_WINDOW_KEYS
    global _WORKSPACE_EVENT_PENDING, _RESTORE_PHASE, _PRIMARY_WINDOW_PTR
    global _LAST_CAPTURE_TIME, _POST_RESTORE_UNTIL
    _SHUTTING_DOWN = True
    _ENABLED = False
    _LOAD_IN_PROGRESS = False
    _OBSERVED_WINDOW_KEYS = None
    _WORKSPACE_EVENT_PENDING = False
    _RESTORE_PHASE = "IDLE"
    _stop_runtime_timer()
    _remove_msgbus()
    _remove_handlers()
    _WINDOW_STATES.clear()
    _PRIMARY_WINDOW_PTR = 0
    _LAST_CAPTURE_TIME = 0.0
    _POST_RESTORE_UNTIL = 0.0
    _reset_stability()
    ns = _driver_namespace()
    if ns is not None:
        for key in (_RUNTIME_NAMESPACE_KEY,) + _LEGACY_RUNTIME_NAMESPACE_KEYS:
            try:
                record = ns.get(key)
            except Exception:
                record = None
            if isinstance(record, dict):
                _cleanup_runtime_record(record)
                if clear_registry:
                    try:
                        ns.pop(key, None)
                    except Exception:
                        pass


def apply_enabled(
    enabled: bool | None = None,
    *,
    context=None,
    save: bool = False,
    _defer_initial_capture: bool = False,
) -> bool:
    global _ENABLED, _SHUTTING_DOWN, _LOAD_IN_PROGRESS, _OBSERVED_WINDOW_KEYS
    global _WORKSPACE_EVENT_PENDING, _WORKSPACE_EVENT_TIME, _RESTORE_PHASE
    desired = is_enabled(context) if enabled is None else bool(enabled)
    quarantined = bool(desired and _runtime_quarantined())
    if quarantined:
        # Do not alter the persisted toggle.  Only the current Blender process is
        # quarantined; after restart the saved feature state starts the v5-safe
        # runtime with clean RNA and msgbus ownership.
        shutdown_runtime(clear_registry=True)
    elif desired:
        _cleanup_previous_runtime()
        _cleanup_orphan_floating_timers()
        _SHUTTING_DOWN = False
        _LOAD_IN_PROGRESS = False
        _ENABLED = True
        _OBSERVED_WINDOW_KEYS = None
        _WORKSPACE_EVENT_PENDING = False
        _RESTORE_PHASE = "IDLE"
        _WORKSPACE_EVENT_TIME = time.monotonic()
        _reset_stability()
        _publish_runtime_record()
        _install_handlers()
        _remove_msgbus()
        # A direct user toggle is outside a workspace transaction and can be
        # captured immediately.  Registration/settings restoration is deferred
        # so startup and file-load initialization never read screen RNA early.
        if not _defer_initial_capture:
            try:
                capture_now(context or getattr(bpy, "context", None))
            except Exception:
                pass
        _ensure_runtime_timer(first_interval=1.0 if _defer_initial_capture else 0.35)
    elif not desired:
        shutdown_runtime(clear_registry=True)
    if save:
        try:
            from .runtime import core as _core
            save_fn = getattr(_core, "save_config_to_file", None)
            if callable(save_fn):
                save_fn(context or getattr(bpy, "context", None))
        except Exception:
            try:
                from . import storage as _storage
                snapshot = getattr(_storage, "snapshot_json_storage_to_central", None)
                if callable(snapshot):
                    snapshot(force=True)
            except Exception:
                pass
    return bool(_ENABLED and not _SHUTTING_DOWN and not quarantined)


def sync_from_settings(context=None) -> bool:
    return apply_enabled(
        is_enabled(context),
        context=context,
        save=False,
        _defer_initial_capture=True,
    )


def draw_settings_ui(layout, context) -> None:
    enabled = is_enabled(context)
    col = layout.column(align=True)
    try:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context), icon="WINDOW")
    except Exception:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context))
    row = col.row(align=True)
    op = row.operator(SMART_WORKSPACE_OT_set_floating_window_lock_enabled.bl_idname, text=ui_label(ENABLED_LABEL, "有効", context), depress=enabled)
    try:
        op.enabled = True
    except Exception:
        pass
    op = row.operator(SMART_WORKSPACE_OT_set_floating_window_lock_enabled.bl_idname, text=ui_label(DISABLED_LABEL, "無効", context), depress=not enabled)
    try:
        op.enabled = False
    except Exception:
        pass
    try:
        status = ui_label("Current state: Enabled", "現在の状態: 有効", context) if enabled else ui_label("Current state: Disabled", "現在の状態: 無効", context)
        col.label(text=status, icon="CHECKMARK" if enabled else "X")
    except Exception:
        pass


def register() -> bool:
    global _SHUTTING_DOWN, _REGISTERED
    _cleanup_previous_runtime()
    _cleanup_orphan_floating_timers()
    _SHUTTING_DOWN = False
    if _REGISTERED:
        sync_from_settings(getattr(bpy, "context", None))
        return True
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(ADDON_ID, _TRANSLATIONS)
    except Exception:
        pass
    _REGISTERED_CLASSES.clear()
    for cls in _CLASSES:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='FLOATING_WINDOW_LOCK_CLASS',
        )
        if not success:
            _REGISTERED_CLASSES.clear()
            _REGISTERED = False
            raise RuntimeError('RESTART_REQUIRED: floating window lock class ownership mismatch')
        _REGISTERED_CLASSES.append(cls)
    _REGISTERED = len(_REGISTERED_CLASSES) == len(_CLASSES)
    if not _REGISTERED:
        return False
    sync_from_settings(getattr(bpy, "context", None))
    return True


def unregister() -> bool:
    global _REGISTERED
    shutdown_runtime(clear_registry=True)
    _cleanup_orphan_floating_timers()
    for cls in reversed(_REGISTERED_CLASSES):
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='FLOATING_WINDOW_LOCK_CLASS',
        ):
            return False
    _REGISTERED_CLASSES.clear()
    _REGISTERED = False
    try:
        bpy.app.translations.unregister(ADDON_ID)
    except Exception:
        pass
    return True


if __name__ == "__main__":
    register()
