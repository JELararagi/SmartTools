# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from .translation import ui_pair
from .bootstrap_common import safe_register_class as _safe_register_class_common
from .bootstrap_common import safe_unregister_class as _safe_unregister_class_common

_BOOTSTRAP_OPERATOR_ID = 'wm.smart_workspace_suite_bootstrap_open_window_v370'
_RUNTIME_OPEN_OPERATOR_ID = 'wm.smart_workspace_suite_open_window_v250'
_REGISTERED_CLASSES: list[type] = []


def _operator_exists(idname: str) -> bool:
    try:
        namespace, operator = str(idname or '').split('.', 1)
        getattr(getattr(bpy.ops, namespace), operator).get_rna_type()
        return True
    except Exception:
        return False


def has_any_smart_tools_window_menu_entry() -> bool:
    return False


def normalize_window_menu_entries(install_if_missing: bool = True) -> bool:
    return False


def remove_window_menu_entries() -> None:
    return None


def _tag_redraw_window_menu_areas() -> None:
    try:
        for window in getattr(bpy.context.window_manager, 'windows', ()):
            for area in getattr(window.screen, 'areas', ()):
                if getattr(area, 'type', None) in {'TOPBAR', 'VIEW_3D'}:
                    area.tag_redraw()
    except Exception:
        pass


class SMARTTOOLS_OT_bootstrap_open_window(bpy.types.Operator):
    bl_idname = _BOOTSTRAP_OPERATOR_ID
    bl_label = ui_pair('Open Smart Workspace', 'Smart Workspace を開く')
    bl_description = ui_pair(
        'Open Smart Workspace controls in the 3D View Sidebar N-panel.',
        'Smart Workspace の操作項目を3DビューのNパネルで開きます。',
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        if _operator_exists(_RUNTIME_OPEN_OPERATOR_ID):
            try:
                result = bpy.ops.wm.smart_workspace_suite_open_window_v250('INVOKE_DEFAULT')
                if 'CANCELLED' not in set(result or set()):
                    return {'FINISHED'}
            except Exception:
                pass
        try:
            self.report({'INFO'}, ui_pair(
                'Smart Workspace controls are available in the Smart Workspace N-panel tab.',
                'Smart Workspace の操作項目は Smart Workspace のNパネルタブにあります。',
            ))
        except Exception:
            pass
        return {'FINISHED'}


def register() -> None:
    if _safe_register_class_common(SMARTTOOLS_OT_bootstrap_open_window):
        _REGISTERED_CLASSES.append(SMARTTOOLS_OT_bootstrap_open_window)


def unregister() -> None:
    remove_window_menu_entries()
    while _REGISTERED_CLASSES:
        cls = _REGISTERED_CLASSES.pop()
        _safe_unregister_class_common(cls)
