"""Expose the historical operator ID as a route to Smart Workspace's sidebar."""

import bpy

from .bootstrap_common import safe_register_class, safe_unregister_class
from .translation import ui_pair


LEGACY_LAUNCH = "smart_workspace_suite_open_window_v250"


def has_any_smart_tools_window_menu_entry():
    return False


def normalize_window_menu_entries(install_if_missing=True):
    return False


def remove_window_menu_entries():
    """Keep the native Window menu exclusively under Blender's control."""


class SMARTTOOLS_OT_bootstrap_open_window(bpy.types.Operator):
    bl_idname = "wm.smart_workspace_suite_bootstrap_open_window_v370"
    bl_label = ui_pair("Open Smart Workspace", "Smart Workspace を開く")
    bl_description = ui_pair(
        "Open Smart Workspace controls in the 3D View Sidebar N-panel.",
        "Smart Workspace の操作項目を3DビューのNパネルで開きます。",
    )
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    def execute(self, context):
        try:
            target = getattr(bpy.ops.wm, LEGACY_LAUNCH)
            target.get_rna_type()
            answered = target("INVOKE_DEFAULT")
        except (AttributeError, KeyError, RuntimeError, TypeError, ValueError):
            answered = {"CANCELLED"}
        if not answered or "CANCELLED" in answered:
            self.report({"INFO"}, ui_pair(
                "Smart Workspace controls are available in the Smart Workspace N-panel tab.",
                "Smart Workspace の操作項目は Smart Workspace のNパネルタブにあります。",
            ))
        return {"FINISHED"}


def register():
    safe_register_class(SMARTTOOLS_OT_bootstrap_open_window)


def unregister():
    safe_unregister_class(SMARTTOOLS_OT_bootstrap_open_window)
