# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

TOOL_ORDER: tuple[str, ...] = (
    'runtime',
    'synchronize_workspaces',
    'floating_window_lock',
    'workspace_step_reorder',
)

TOOL_META: dict[str, dict[str, object]] = {
    'runtime': {
        'display_name_en': 'Smart Workspace',
        'display_name_ja': 'Smart Workspace',
        'overview_en': 'This is the core Smart Workspace runtime that builds the Smart Tools N-panel, the workspace launcher, floating panel flow, panel organization helpers, and project level workspace storage. It is the central hub that the bundled tools are migrated into.',
        'overview_ja': 'Smart Tools Nパネル、ワークスペースランチャー、フローティングパネル運用、パネル整理支援、プロジェクト単位の設定保存を構成する Smart Workspace 本体です。同梱ツールが集約される中核ランタイムとして動作します。',
        'usage_en': 'Open the Smart Workspace tab inside Smart Tools, then manage categories, tabs, floating tools, and workspace presets from there. For keyboard access, register the launcher or hotbox IDs shown below in Blender Preferences > Keymap.',
        'usage_ja': 'Smart Tools 内の Smart Workspace タブを開き、そこからカテゴリー、タブ、フローティングツール、ワークスペースプリセットを管理します。キーボードで直接開きたい場合は、下のランチャー ID またはホットボックス ID を Blender のプリファレンス > キーマップ に登録してください。',
        'keymap_note_en': 'Use the launcher or hotbox operator IDs below when you want to open Smart Workspace directly from the keyboard.',
        'keymap_note_ja': 'キーボードから Smart Workspace を直接開きたい場合は、下のランチャー ID またはホットボックス ID を使ってください。',        'always_available': True,
        'path_prefix': 'runtime/',
    },
    'synchronize_workspaces': {
        'display_name_en': 'Synchronize Workspaces',
        'display_name_ja': 'ワークスペース同期',
        'overview_en': 'Synchronize the 3D view state between workspaces so camera orientation, overlays, and selected viewport display settings can follow as you switch workspaces. This is useful when the same scene must stay visually aligned across multiple task layouts.',
        'overview_ja': 'ワークスペースを切り替えても、3D ビューの向きやオーバーレイ、必要な表示設定を連動させるツールです。同じシーンを複数の作業レイアウトで扱いながら、視点を揃えたい場合に便利です。',
        'usage_en': 'Turn on synchronization, then choose which workspaces participate and which viewport settings are copied. Use it when switching between modeling, shading, and review workspaces while keeping the same camera orientation.',
        'usage_ja': '同期を有効にしたあと、どのワークスペースを同期対象にするか、どのビューポート設定をコピーするかを選びます。モデリング、シェーディング、確認用ワークスペースを行き来しながら、同じ視点を保ちたいときに使います。',
        'keymap_note_en': 'This tool has no dedicated direct keymap entry. Toggle it from Smart Workspace > Other Tools > Synchronize Workspaces.',
        'keymap_note_ja': 'このツールには専用の直接キーマップ項目がありません。Smart Workspace > その他ツール > ワークスペース同期から操作してください。',
        'supports_runtime_info': True,
    },
    'floating_window_lock': {
        'display_name_en': 'Floating Window Lock',
        'display_name_ja': 'フローティングウィンドウ固定',
        'overview_en': 'Keeps detached or floating Blender window editor contents stable while switching workspace tabs. It protects auxiliary 3D View, Outliner, Image Editor, Node Editor, and similar windows from following the active workspace layout.',
        'overview_ja': 'ワークスペースタブを切り替えても、切り離し・フローティング表示している Blender ウィンドウのエディター内容を維持するツールです。補助用の 3D ビュー、アウトライナー、画像エディター、ノードエディターなどがアクティブワークスペースのレイアウトへ追従しないようにします。',
        'usage_en': 'Enable the tool from Other Tools, open or keep any detached windows you want to protect, then switch workspaces normally. Disable it when floating windows should follow Blender standard workspace behavior.',
        'usage_ja': 'その他ツールから有効化し、維持したい切り離しウィンドウを開いたまま通常通りワークスペースを切り替えます。フローティングウィンドウを Blender 標準のワークスペース追従挙動に戻したい場合は無効化します。',
        'keymap_note_en': 'This tool has no dedicated direct keymap entry. Toggle it from Smart Workspace > Other Tools > Floating Window Lock.',
        'keymap_note_ja': 'このツールには専用の直接キーマップ項目がありません。Smart Workspace > その他ツール > フローティングウィンドウ固定から操作してください。',
        'supports_runtime_info': True,
    },
    'workspace_step_reorder': {
        'display_name_en': 'Workspace Step Reorder',
        'display_name_ja': 'ワークスペース順序移動',
        "overview_en": "Adds one-step workspace tab movement commands to Blender\'s workspace tab right-click menu. It helps adjust workspace order without sending a tab all the way to the front or back.",
        'overview_ja': 'Blender のワークスペースタブ右クリックメニューに、ワークスペースを1つずつ前後へ移動するコマンドを追加します。タブを最前面や最後方へ一気に送らず、順番を少しだけ調整できます。',
        "usage_en": "Enable the tool from Other Tools, right-click a workspace tab, then choose Move Forward or Move Backward. Disable it when you want Blender\'s standard workspace menu unchanged.",
        'usage_ja': 'その他ツールから有効化し、ワークスペースタブを右クリックして「前側に移動」または「後ろ側に移動」を選びます。Blender 標準メニューのまま使う場合は無効にします。',
        'keymap_note_en': 'This tool uses the workspace tab context menu and has no default hotkey.',
        'keymap_note_ja': 'このツールはワークスペースタブの右クリックメニューから使うため、既定ホットキーはありません。',
        'supports_runtime_info': True,
    },
}


def tool_meta(alias: str) -> dict[str, object]:
    return dict(TOOL_META.get(str(alias or '').strip(), {}))


def display_name(alias: str, *, japanese: bool = False) -> str:
    meta = tool_meta(alias)
    if not meta:
        return str(alias or '').strip()
    key = 'display_name_ja' if japanese else 'display_name_en'
    return str(meta.get(key) or alias or '').strip()


def runtime_note(alias: str) -> str:
    return ''
