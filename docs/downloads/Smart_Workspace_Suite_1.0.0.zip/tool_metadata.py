# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

TOOL_ORDER: tuple[str, ...] = (
    'runtime',
    'icon_viewer',
    'keyboard_layout_emulation',
    'screencast_keys',
    'script_launcher',
    'synchronize_workspaces',
    'floating_window_lock',
    'viewport_pie_menus',
    'workspace_step_reorder',
)

TOOL_META: dict[str, dict[str, object]] = {
    'runtime': {
        'display_name_en': 'Smart Workspace',
        'display_name_ja': 'Smart Workspace',
        'overview_en': 'This is the core Smart Workspace runtime that builds the Smart Tools N-panel, the workspace launcher, floating panel flow, panel organization helpers, and project level workspace storage. It is the central hub that the bundled tools are migrated into.',
        'overview_ja': 'Smart Tools Nパネル、ワークスペースランチャー、フローティングパネル運用、パネル整理支援、プロジェクト単位の設定保存を構成する Smart Workspace 本体です。同梱ツールが集約される中核ランタイムとして動作します。',
        'usage_en': 'Open the Smart Workspace tab inside Smart Tools, then manage categories, tabs, floating tools, and workspace presets from there. For keyboard access, register the launcher or hotbox IDs shown below in Blender Preferences > Keymap.',
        'usage_ja': 'Smart Tools 内の Smart Workspace タブを開き、そこからカテゴリー、タブ、フローティングツール、ワークスペースプリセットを管理します。キーボードで直接開きたい場合は、下のランチャー ID またはホットボックス ID を Blender のプリファレンス > キーマップ に登録してください。',
        'keymap_note_en': 'Use the launcher or hotbox operator IDs below when you want to open Smart Workspace directly from the keyboard.',
        'keymap_note_ja': 'キーボードから Smart Workspace を直接開きたい場合は、下のランチャー ID またはホットボックス ID を使ってください。',        'always_available': True,
        'path_prefix': 'runtime/',
    },
    'icon_viewer': {
        'display_name_en': 'Icon Viewer',
        'display_name_ja': 'アイコンビューアー',
        'overview_en': 'Browse Blender built-in icons, filter them by name, preview categories such as matcaps and brushes, and copy icon identifiers for UI work. This is useful when you are building add-on panels or operators and need the exact icon name.',
        'overview_ja': 'Blender 内蔵アイコンを一覧表示し、名前で絞り込み、matcap や brush などの分類を確認しながら、UI 用のアイコン識別子をコピーできるツールです。アドオンのパネルやオペレーターを作る際に、正確なアイコン名を調べたいときに役立ちます。',
        'usage_en': 'Open the popup or the migrated Smart Tools panel, type a filter to narrow the list, then click an icon to inspect or copy its name. Enable history when you want to revisit recently used icon IDs quickly.',
        'usage_ja': 'ポップアップまたは Smart Tools へ移植されたパネルを開き、フィルターを入力して一覧を絞り込み、目的のアイコンをクリックして名前を確認またはコピーします。最近使ったアイコンをすぐ再利用したい場合は履歴表示を有効にしてください。',
        'keymap_note_en': 'You can register the popup operator in the Text Editor or Window keymap if you want a direct shortcut for the icon browser.',
        'keymap_note_ja': 'アイコンブラウザーをショートカットで直接開きたい場合は、ポップアップ用オペレーターを Text Editor または ウィンドウ のキーマップに登録できます。',
        'supports_runtime_info': True,
    },
    'keyboard_layout_emulation': {
        'display_name_en': 'Keyboard Layout Emulation',
        'display_name_ja': 'キーボード配列エミュレーション',
        'overview_en': 'Emulate QWERTY oriented Blender shortcuts on a non-QWERTY keyboard layout by remapping keymaps in a controlled way. It helps users keep Blender shortcut muscle memory while typing in another physical or language layout.',
        'overview_ja': '非 QWERTY キーボード環境でも、Blender の QWERTY 前提ショートカットを使いやすいようにキーマップを安全に再割り当てするツールです。別の物理配列や言語配列で文字入力しながら、Blender の既存ショートカット習慣を維持したい場合に役立ちます。',
        'usage_en': 'Choose the target and input layouts, verify the mapping preview, then apply the emulation only after confirming the layout is valid. Revert the emulation before manually editing shortcuts so your keymap changes are not remapped unexpectedly.',
        'usage_ja': '入力配列と変換先配列を選び、マッピング内容を確認してから、配列が正常であることを確かめたうえで適用します。手動でショートカットを編集する前には、予期しない再変換を避けるため、先にエミュレーションを解除してください。',
        'keymap_note_en': 'Register the apply, revert, import, or export operators in the Window keymap only if you need direct keyboard access to those commands.',
        'keymap_note_ja': '適用、解除、入出力などのコマンドをキーボードから直接呼びたい場合だけ、ウィンドウ キーマップへ各オペレーターを登録してください。',
        'supports_runtime_info': True,
    },
    'screencast_keys': {
        'display_name_en': 'Screencast Keys',
        'display_name_ja': 'Screencast Keys',
        'overview_en': 'Display the keys, mouse actions, and optional last operator names directly over the viewport. This is useful for tutorial recording, workflow demonstrations, and checking what inputs Blender is currently receiving.',
        'overview_ja': '押したキー、マウス操作、必要に応じて最後のオペレーター名をビューポート上に表示するツールです。チュートリアル録画、操作説明、Blender が現在どの入力を受けているかの確認に向いています。',
        'usage_en': 'Enable the overlay, set the screen origin, then adjust text, background, mouse display, and history settings until the on-screen readout is readable. Turn it off again after recording to keep the viewport clean.',
        'usage_ja': 'オーバーレイを有効にし、表示原点を設定したあと、文字、背景、マウス表示、履歴件数を調整して、見やすい表示に整えます。録画や説明が終わったら、ビューポートをすっきり保つため再び無効化してください。',
        'keymap_note_en': 'The toggle and origin operators can be assigned to a 3D View or Window shortcut when you need to start or reposition the overlay quickly.',
        'keymap_note_ja': '表示の有効化や原点設定を素早く行いたい場合は、切り替えオペレーターと原点設定オペレーターを3Dビューまたは ウィンドウ のショートカットに登録できます。',
        'supports_runtime_info': True,
    },
    'script_launcher': {
        'display_name_en': 'Script Launcher',
        'display_name_ja': 'スクリプトランチャー',
        'overview_en': 'Manage one or more root folders of Python scripts, show them in a navigable list, and run them from Smart Tools. This is useful when you keep reusable utility scripts outside the main add-on package.',
        'overview_ja': 'Python スクリプトのルートフォルダーを複数登録し、一覧から選んで Smart Tools 内で実行できるツールです。再利用する補助スクリプトをメインアドオン外に整理している場合に便利です。',
        'usage_en': 'Add one or more script root folders, select a script from the migrated list, then run it from Smart Tools. Keep labels organized so beginners can tell which script is safe to execute and what each folder contains.',
        'usage_ja': 'スクリプトのルートフォルダーを追加し、移植済み一覧から目的のスクリプトを選んで Smart Tools から実行します。初心者でも用途が分かるよう、フォルダー名やラベルは整理しておくと安全です。',
        'keymap_note_en': 'Register frequently used run or popup operators only for scripts that you execute repeatedly, then keep the rest inside the launcher list.',
        'keymap_note_ja': '頻繁に使う実行オペレーターやポップアップだけをショートカット登録し、それ以外のスクリプトはランチャー一覧から使う運用が整理しやすいです。',
        'supports_runtime_info': True,
    },
    'synchronize_workspaces': {
        'display_name_en': 'Synchronize Workspaces',
        'display_name_ja': 'ワークスペース同期',
        'overview_en': 'Synchronize the 3D view state between workspaces so camera orientation, overlays, and selected viewport display settings can follow as you switch workspaces. This is useful when the same scene must stay visually aligned across multiple task layouts.',
        'overview_ja': 'ワークスペースを切り替えても、3D ビューの向きやオーバーレイ、必要な表示設定を連動させるツールです。同じシーンを複数の作業レイアウトで扱いながら、視点を揃えたい場合に便利です。',
        'usage_en': 'Turn on synchronization, then choose which workspaces participate and which viewport settings are copied. Use it when switching between modeling, shading, and review workspaces while keeping the same camera orientation.',
        'usage_ja': '同期を有効にしたあと、どのワークスペースを同期対象にするか、どのビューポート設定をコピーするかを選びます。モデリング、シェーディング、確認用ワークスペースを行き来しながら、同じ視点を保ちたいときに使います。',
        'keymap_note_en': 'This tool has no dedicated direct keymap entry. Toggle it from Smart Workspace > Other Tools > Synchronize Workspaces.',
        'keymap_note_ja': 'このツールには専用の直接キーマップ項目がありません。Smart Workspace > その他ツール > ワークスペース同期から操作してください。',
        'supports_runtime_info': True,
    },
    'floating_window_lock': {
        'display_name_en': 'Floating Window Lock',
        'display_name_ja': 'フローティングウィンドウ固定',
        'overview_en': 'Keeps detached or floating Blender window editor contents stable while switching workspace tabs. It protects auxiliary 3D View, Outliner, Image Editor, Node Editor, and similar windows from following the active workspace layout.',
        'overview_ja': 'ワークスペースタブを切り替えても、切り離し・フローティング表示している Blender ウィンドウのエディター内容を維持するツールです。補助用の 3D ビュー、アウトライナー、画像エディター、ノードエディターなどがアクティブワークスペースのレイアウトへ追従しないようにします。',
        'usage_en': 'Enable the tool from Other Tools, open or keep any detached windows you want to protect, then switch workspaces normally. Disable it when floating windows should follow Blender standard workspace behavior.',
        'usage_ja': 'その他ツールから有効化し、維持したい切り離しウィンドウを開いたまま通常通りワークスペースを切り替えます。フローティングウィンドウを Blender 標準のワークスペース追従挙動に戻したい場合は無効化します。',
        'keymap_note_en': 'This tool has no dedicated direct keymap entry. Toggle it from Smart Workspace > Other Tools > Floating Window Lock.',
        'keymap_note_ja': 'このツールには専用の直接キーマップ項目がありません。Smart Workspace > その他ツール > フローティングウィンドウ固定から操作してください。',
        'supports_runtime_info': True,
    },
    'workspace_step_reorder': {
        'display_name_en': 'Workspace Step Reorder',
        'display_name_ja': 'ワークスペース順序移動',
        "overview_en": "Adds one-step workspace tab movement commands to Blender\'s workspace tab right-click menu. It helps adjust workspace order without sending a tab all the way to the front or back.",
        'overview_ja': 'Blender のワークスペースタブ右クリックメニューに、ワークスペースを1つずつ前後へ移動するコマンドを追加します。タブを最前面や最後方へ一気に送らず、順番を少しだけ調整できます。',
        "usage_en": "Enable the tool from Other Tools, right-click a workspace tab, then choose Move Forward or Move Backward. Disable it when you want Blender\'s standard workspace menu unchanged.",
        'usage_ja': 'その他ツールから有効化し、ワークスペースタブを右クリックして「前側に移動」または「後ろ側に移動」を選びます。Blender 標準メニューのまま使う場合は無効にします。',
        'keymap_note_en': 'This tool uses the workspace tab context menu and has no default hotkey.',
        'keymap_note_ja': 'このツールはワークスペースタブの右クリックメニューから使うため、既定ホットキーはありません。',
        'supports_runtime_info': True,
    },
    'viewport_pie_menus': {
        'display_name_en': '3D Viewport Pie Menus',
        'display_name_ja': '3Dビューのパイメニュー',
        'overview_en': 'Provides a broad set of radial pie menus for view control, object operations, mesh editing, editor switching, sculpt tools, and many other context specific actions. It is meant to speed up frequent viewport workflows through shortcut driven menus.',
        'overview_ja': 'ビュー操作、オブジェクト操作、メッシュ編集、エディター切り替え、スカルプトなど、多数の機能をラジアル型パイメニューで素早く呼び出せるツールです。ショートカット中心のビューポート作業を高速化することを目的としています。',
        'usage_en': 'Load the tool, then assign only the pie menus you actually need to the keymap areas that match your workflow. Start with a few core pies, such as view, selection, or object pies, and expand gradually to avoid shortcut conflicts.',
        'usage_ja': 'ツールを読み込んだあと、自分の作業に本当に必要なパイメニューだけを、対応するキーマップ領域へ登録します。最初は View、Selection、Object など基本的なパイから始め、ショートカット競合を避けながら少しずつ増やしてください。',
        'keymap_note_en': 'Most entries are menu calls. Register the listed menu call IDs in the matching 3D View or mode specific keymap sections, and keep the assignments focused to avoid overlapping shortcuts.',
        'keymap_note_ja': '多くの項目はメニュー呼び出しです。一覧にあるメニュー呼び出し ID を、対応する3Dビューやモード別キーマップ欄に登録し、競合を避けるため割り当ては必要なものだけに絞ってください。',
        'supports_runtime_info': True,
    },
}


def tool_meta(alias: str) -> dict[str, object]:
    return dict(TOOL_META.get(str(alias or '').strip(), {}))


def display_name(alias: str, *, japanese: bool = False) -> str:
    meta = tool_meta(alias)
    if not meta:
        return str(alias or '').strip()
    key = 'display_name_ja' if japanese else 'display_name_en'
    return str(meta.get(key) or alias or '').strip()


def runtime_note(alias: str) -> str:
    return ''
