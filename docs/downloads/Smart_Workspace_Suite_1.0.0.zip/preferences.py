# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import os
import sys
from typing import Any

import bpy
from bpy.props import BoolProperty, FloatProperty, PointerProperty, StringProperty

from . import storage as _suite_storage
from . import settings_vfs as _suite_vfs
from . import runtime_ledger as _runtime_ledger
from .translation import error_text, localized_layout, ui_pair
from . import ui_icons

_RUNTIME_STORAGE_ATTR = 'smart_workspace_suite_runtime_settings'
_RUNTIME_SETTINGS_LOADING = False
_RUNTIME_PREFERENCES_APPLYING = False
_RUNTIME_LAST_VALUES: dict[str, Any] = {}
_RUNTIME_SETTING_NAMES = (
    'pin_update_interval',
    'auto_restore_on_file_load',
    'live_pin_follow_enabled',
    'launcher_operator_id',
    'hotbox_operator_id',
    'store_in_blend',
    'prefer_blend_config',
)


def _root_addon_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return name or 'smart_workspace_suite'


def _settings_path() -> str:
    """Settings-layer key of the runtime settings (inside the one settings file)."""
    return _suite_vfs.RUNTIME_SETTINGS_KEY


def _atomic_write_json(path: str, data: dict[str, Any]) -> bool:
    return bool(_suite_storage.atomic_write_json(
        path, data, indent=2, ensure_ascii=False, sort_keys=True
    ))


def _serialize_runtime_settings(settings) -> dict[str, Any]:
    data: dict[str, Any] = {}
    for name in _RUNTIME_SETTING_NAMES:
        try:
            value = getattr(settings, name)
        except Exception:
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            data[name] = value
    return data


def _remember_runtime_values(settings) -> None:
    global _RUNTIME_LAST_VALUES
    try:
        _RUNTIME_LAST_VALUES = dict(_serialize_runtime_settings(settings))
    except Exception:
        _RUNTIME_LAST_VALUES = {}


def _runtime_value_changed(settings, name: str) -> bool:
    try:
        current = getattr(settings, name)
    except Exception:
        return False
    if name == 'pin_update_interval':
        try:
            current = float(current)
        except Exception:
            pass
    elif name in {'auto_restore_on_file_load', 'live_pin_follow_enabled', 'store_in_blend', 'prefer_blend_config'}:
        current = bool(current)
    else:
        current = str(current or '')
    previous = _RUNTIME_LAST_VALUES.get(name, None)
    if name == 'pin_update_interval':
        try:
            previous = float(previous)
        except Exception:
            pass
    elif name in {'auto_restore_on_file_load', 'live_pin_follow_enabled', 'store_in_blend', 'prefer_blend_config'}:
        previous = bool(previous)
    else:
        previous = str(previous or '')
    return current != previous


def _apply_runtime_settings(settings, data: dict[str, Any] | None) -> None:
    if settings is None or not isinstance(data, dict):
        return
    global _RUNTIME_SETTINGS_LOADING
    _RUNTIME_SETTINGS_LOADING = True
    try:
        for name in _RUNTIME_SETTING_NAMES:
            if name not in data or not hasattr(settings, name):
                continue
            value = data.get(name)
            try:
                if name == 'pin_update_interval':
                    value = max(0.1, min(5.0, float(value)))
                elif name in {'auto_restore_on_file_load', 'live_pin_follow_enabled', 'store_in_blend', 'prefer_blend_config'}:
                    value = bool(value)
                else:
                    value = str(value or '')
                setattr(settings, name, value)
            except Exception:
                pass
    finally:
        _RUNTIME_SETTINGS_LOADING = False


def get_runtime_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    return getattr(wm, _RUNTIME_STORAGE_ATTR, None) if wm is not None else None


def save_runtime_settings(
    context=None,
    *,
    force: bool = False,
    verified_restore: bool = False,
    verified_user_change: bool = False,
) -> bool:
    """Persist runtime settings and return verified success or ``False``.

    I/O failures are not converted into success.  The caller retains the dirty
    state whenever a transaction is blocked or fails.
    """
    if _RUNTIME_SETTINGS_LOADING:
        return False
    if not force:
        try:
            from . import persistence as _suite_persistence
            if _suite_persistence.runtime_sidecar_write_blocked(
                verified_user_change=verified_user_change,
            ):
                _suite_persistence.mark_deferred_settings_dirty()
                return False
        except Exception:
            return False
    settings = get_runtime_settings(context)
    if settings is None:
        return False
    if not force and not _suite_storage.n_panel_state_save_enabled(True):
        try:
            from . import persistence as _suite_persistence
            _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return False
    values = _serialize_runtime_settings(settings)
    try:
        from . import persistence as _suite_persistence
        transaction = getattr(_suite_persistence, 'save_runtime_settings_transaction', None)
    except Exception:
        transaction = None
    try:
        if callable(transaction):
            if force and _suite_storage.central_write_batch_active():
                success = _atomic_write_json(_settings_path(), values)
            else:
                success = bool(transaction(
                    context,
                    _settings_path(),
                    values,
                    force=force,
                    verified_restore=verified_restore,
                    verified_user_change=verified_user_change,
                ))
        else:
            if not (verified_restore or not runtime_settings_write_blocked()):
                return False
            success = _atomic_write_json(_settings_path(), values)
        if not success:
            try:
                from . import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
            except Exception:
                pass
            return False
        _remember_runtime_values(settings)
        return True
    except Exception:
        try:
            from . import persistence as _suite_persistence
            _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return False


def runtime_settings_write_blocked() -> bool:
    try:
        from . import persistence as _suite_persistence
        return bool(_suite_persistence.runtime_sidecar_write_blocked())
    except Exception:
        return False


def load_runtime_settings(context=None) -> bool:
    settings = get_runtime_settings(context)
    if settings is None:
        return False
    data = _suite_storage.read_json(_settings_path(), None)
    if data is None:
        _remember_runtime_values(settings)
        return False
    try:
        if not isinstance(data, dict):
            return False
        _apply_runtime_settings(settings, data)
        _remember_runtime_values(settings)
        return True
    except Exception:
        return False


def _apply_runtime_preferences(context=None) -> None:
    try:
        from . import runtime
        apply_fn = getattr(runtime, 'apply_preference_runtime_state', None)
        if callable(apply_fn):
            apply_fn(context=context)
    except Exception:
        pass


def _apply_tool_runtime_preferences(context=None) -> None:
    try:
        from . import tool_runtime
        apply_fn = getattr(tool_runtime, 'apply_preference_runtime_state', None)
        if callable(apply_fn):
            apply_fn(context=context)
    except Exception:
        pass


def _persist_runtime_user_change(context, source: str) -> bool:
    if _RUNTIME_SETTINGS_LOADING:
        return False
    try:
        from . import persistence as _suite_persistence
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def _on_runtime_settings_saved(self, context) -> None:
    del self
    _persist_runtime_user_change(context, 'runtime-settings-rna-update')


def _on_runtime_preferences_changed(self, context) -> None:
    global _RUNTIME_PREFERENCES_APPLYING

    changed_auto_restore = _runtime_value_changed(self, 'auto_restore_on_file_load')
    changed_live_pin_follow = _runtime_value_changed(self, 'live_pin_follow_enabled')
    _persist_runtime_user_change(context, 'runtime-preferences-rna-update')

    # Loading saved JSON and applying runtime state may set RNA values.  Do not
    # let those assignments recursively bootstrap the full runtime or reapply
    # every always-on toggle; that re-entry can lock Blender when the pin-follow
    # switch is changed from the N-panel.
    if _RUNTIME_SETTINGS_LOADING or _RUNTIME_PREFERENCES_APPLYING:
        return

    _RUNTIME_PREFERENCES_APPLYING = True
    try:
        # Both switches own real, gated runtime behavior.  Materialize the
        # runtime only when a feature is explicitly turned on; their OFF paths
        # can tear down an already-loaded runtime without creating one.
        should_materialize = (
            changed_auto_restore and bool(getattr(self, 'auto_restore_on_file_load', False))
        ) or (
            changed_live_pin_follow and bool(getattr(self, 'live_pin_follow_enabled', False))
        )
        if should_materialize:
            try:
                from . import ensure_full_runtime_loaded
                ensure_full_runtime_loaded(context=context, reason='runtime_setting_change', refresh_ui=False)
            except Exception:
                pass

        # Apply Smart Workspace runtime state only.  Reapplying all saved
        # always-on toggles from here can call back into this property update.
        if changed_auto_restore or changed_live_pin_follow:
            _apply_runtime_preferences(context)
    finally:
        _RUNTIME_PREFERENCES_APPLYING = False


def _draw_copy_button(row, text_value: str, report_label: str, context=None) -> None:
    op = row.operator('smart_workspace_suite.copy_text', text=ui_pair('Copy', 'コピー', context), icon='COPYDOWN')
    op.text = str(text_value or '')
    op.report_label = str(report_label or text_value or '')


def _draw_runtime_shortcut_ids(owner, layout, context=None, *, include_guide: bool = True) -> None:
    launcher_row = layout.row(align=True)
    launcher_row.label(text=ui_pair('Launcher', 'ランチャー', context))
    _draw_copy_button(launcher_row, owner.launcher_operator_id, f'Launcher ID {owner.launcher_operator_id}', context)

    hotbox_row = layout.row(align=True)
    hotbox_row.label(text=ui_pair('Hotbox', 'ホットボックス', context))
    _draw_copy_button(hotbox_row, owner.hotbox_operator_id, f'Hotbox ID {owner.hotbox_operator_id}', context)



class SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_OT_copy_text(bpy.types.Operator):
    bl_idname = 'smart_workspace_suite.copy_text'
    bl_label = ui_pair('Copy Text', 'テキストをコピー')
    bl_description = ui_pair('Copy the displayed text to the clipboard.', '表示中のテキストをクリップボードへコピーします。')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    text: StringProperty(options={'SKIP_SAVE'})
    report_label: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, ui_pair('Clipboard is not available.', 'クリップボードを利用できません。', context))
            return {'CANCELLED'}
        try:
            wm.clipboard = str(self.text or '')
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Copy failed', 'コピーに失敗しました', context))
            return {'CANCELLED'}
        label = str(self.report_label or self.text or '').strip()
        self.report({'INFO'}, f"{ui_pair('Copied', 'コピー', context)}: {label}")
        return {'FINISHED'}


class SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings(bpy.types.PropertyGroup):
    pin_update_interval: FloatProperty(
        name=ui_pair('Pin Interval', 'ピン追従間隔'),
        description=ui_pair('How often Smart Workspace checks and follows pinned panel tabs while you work. Lower values react faster but may use slightly more CPU, so beginners should usually keep the default unless they notice delayed tab changes.', 'ピン留めしたパネルタブの追従状態を Smart Workspace が確認する間隔です。値を小さくすると反応は速くなりますが少しだけ CPU 使用量が増えるため、初心者はタブ切り替えの遅れが気になる場合以外は既定値のままが安全です。'),
        default=0.5,
        min=0.1,
        max=5.0,
        update=_on_runtime_settings_saved,
    )

    auto_restore_on_file_load: BoolProperty(
        name=ui_pair('Auto Restore on File Load', '読込時に自動復元'),
        description=ui_pair('Enable Smart Workspace load_post restoration when Blender opens or when another .blend file is loaded. Turn this on only when you want profiles, panel lists, and saved Smart Workspace state to be restored automatically every time, because the automatic scan is heavier than manual refresh.', 'Blender 起動時や別の .blend を開いたときに、Smart Workspace の load_post 自動復元を有効にします。プロファイル、パネル一覧、保存済み状態を毎回自動で復元したい場合だけ ON にしてください。自動走査は手動更新より負荷が高いため、軽量運用では OFF を推奨します。'),
        default=False,
        update=_on_runtime_preferences_changed,
    )

    live_pin_follow_enabled: BoolProperty(
        name=ui_pair('Live Panel Pin Follow', 'パネルピン追従'),
        description=ui_pair('Keep the panels of pinned tabs visible on the other N-panel tabs, using Blender\'s standard panel pin. A panel is pinned the next time it is drawn open. Turning this off removes the pins.', 'ピンを付けたタブのパネルを、ほかのタブを開いている時も表示します。Blender 標準のパネルのピンを使い、パネルが開いた状態で描かれた時に付きます。無効にするとピンを外します。'),
        default=False,
        update=_on_runtime_preferences_changed,
    )

    launcher_operator_id: StringProperty(
        name=ui_pair('Launcher ID', 'ランチャーID'),
        description=ui_pair('Operator ID for the Smart Workspace quick launcher. Register this ID in Blender Preferences > Keymap when you want a shortcut that opens the launcher directly from the keyboard.', 'Smart Workspace のクイックランチャー用オペレーターIDです。キーボードから直接ランチャーを開きたい場合は、この ID を Blender のプリファレンス > キーマップ に登録します。'),
        default='nptl.launcher',
        update=_on_runtime_settings_saved,
    )

    hotbox_operator_id: StringProperty(
        name=ui_pair('Hotbox ID', 'ホットボックスID'),
        description=ui_pair('Operator ID for the Smart Workspace hotbox menu. Register this ID in Blender Preferences > Keymap when you want a shortcut that opens the hotbox or marking menu directly.', 'Smart Workspace の Hotbox メニュー用オペレーターIDです。ホットボックスやマーキングメニューを直接開くショートカットを作る場合は、この ID を Blender のプリファレンス > キーマップ に登録します。'),
        default='nptl.hotbox',
        update=_on_runtime_settings_saved,
    )

    store_in_blend: BoolProperty(
        name=ui_pair('Store Config in .blend', '.blend に設定保存'),
        description=ui_pair('Also save the Smart Workspace configuration into the current .blend file as internal text data. Turn this on when each project needs its own workspace layout, launcher categories, or floating panel setup.', 'Smart Workspace の設定を現在の .blend ファイル内にもテキストデータとして保存します。作品ごとにワークスペース構成やランチャーカテゴリー、フローティングパネル設定を持たせたいときに有効です。'),
        default=False,
        update=_on_runtime_settings_saved,
    )

    prefer_blend_config: BoolProperty(
        name=ui_pair('Prefer .blend Config on Load', '読込時は .blend 優先'),
        description=ui_pair('When a Smart Workspace configuration is stored in the opened .blend file, load that project specific data before the normal CONFIG configuration. Enable this when different files should restore different workspace layouts automatically.', '開いた .blend ファイル内に Smart Workspace の設定が保存されている場合、通常の CONFIG 設定より先にそのプロジェクト専用設定を読み込みます。ファイルごとに異なるワークスペース構成を自動復元したいときに有効です。'),
        default=False,
        update=_on_runtime_settings_saved,
    )


class SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_AddonPreferences(bpy.types.AddonPreferences):
    """Empty compatibility shell; runtime settings are stored on WindowManager."""

    bl_idname = _root_addon_id()

    def draw(self, context):
        return None


_ADDON_PREFERENCES_DRAW_ORIGINAL = getattr(SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_AddonPreferences, 'draw', (lambda self, context: None))
_USERPREF_ADDONS_DRAW_PREFS_ORIGINAL = None
_USERPREF_ADDONS_DRAW_PREFS_OWNER = None
_USERPREF_ADDONS_DRAW_PREFS_MARKER = '_smart_tools_hide_addon_preferences_patch'


def _is_our_addon_preferences_instance(addon_preferences) -> bool:
    if addon_preferences is None:
        return False
    addon_preferences_class = type(addon_preferences)
    if addon_preferences_class is SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_AddonPreferences:
        return True
    try:
        if str(getattr(addon_preferences_class, 'bl_idname', '') or '').strip() != str(_root_addon_id()).strip():
            return False
    except Exception:
        return False
    module_name = str(getattr(addon_preferences_class, '__module__', '') or '')
    package_name = str(__package__ or '').strip()
    return bool(module_name and package_name and module_name.startswith(package_name))


def _patch_userpref_addon_preferences_visibility() -> None:
    global _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL
    global _USERPREF_ADDONS_DRAW_PREFS_OWNER

    try:
        import bl_ui.space_userpref as space_userpref
    except Exception:
        return

    panel_cls = getattr(space_userpref, 'USERPREF_PT_addons', None)
    if panel_cls is None:
        return

    current_descriptor = panel_cls.__dict__.get('draw_addon_preferences')
    current_callable = getattr(current_descriptor, '__func__', current_descriptor)
    if getattr(current_callable, _USERPREF_ADDONS_DRAW_PREFS_MARKER, False):
        _USERPREF_ADDONS_DRAW_PREFS_OWNER = panel_cls
        return

    if current_descriptor is None:
        return

    _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL = current_descriptor
    _USERPREF_ADDONS_DRAW_PREFS_OWNER = panel_cls

    original_callable = getattr(current_descriptor, '__func__', current_descriptor)

    def _draw_addon_preferences_without_smart_tools(layout, context, addon_preferences):
        if _is_our_addon_preferences_instance(addon_preferences):
            return None
        return original_callable(layout, context, addon_preferences)

    setattr(_draw_addon_preferences_without_smart_tools, _USERPREF_ADDONS_DRAW_PREFS_MARKER, True)
    setattr(_draw_addon_preferences_without_smart_tools, '_smart_tools_raw_draw_addon_preferences', original_callable)
    panel_cls.draw_addon_preferences = staticmethod(_draw_addon_preferences_without_smart_tools)


def _unpatch_userpref_addon_preferences_visibility() -> None:
    global _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL
    global _USERPREF_ADDONS_DRAW_PREFS_OWNER

    panel_cls = _USERPREF_ADDONS_DRAW_PREFS_OWNER
    if panel_cls is None or _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL is None:
        _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL = None
        _USERPREF_ADDONS_DRAW_PREFS_OWNER = None
        return

    try:
        current_descriptor = panel_cls.__dict__.get('draw_addon_preferences')
        current_callable = getattr(current_descriptor, '__func__', current_descriptor)
        if getattr(current_callable, _USERPREF_ADDONS_DRAW_PREFS_MARKER, False):
            panel_cls.draw_addon_preferences = _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL
    except Exception:
        pass

    _USERPREF_ADDONS_DRAW_PREFS_ORIGINAL = None
    _USERPREF_ADDONS_DRAW_PREFS_OWNER = None


def _draw_help_button(layout, context, help_id: str, *, text: bool = True) -> None:
    del text, context
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = str(help_id or 'runtime')
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass

def draw_smart_tools_settings_ui(layout, context, owner=None) -> None:
    base_layout = getattr(layout, '_layout', layout)
    try:
        base_layout.use_property_split = False
        base_layout.use_property_decorate = False
    except Exception:
        pass
    layout = localized_layout(base_layout, context)

    if owner is None:
        owner = get_runtime_settings(context)
    if owner is None:
        layout.label(text=ui_pair('Settings are unavailable.', '設定を取得できません。', context), icon='ERROR')
        return

    header = layout.row(align=True)
    ui_icons.label(header, text=ui_pair('Smart Workspace Runtime Settings', 'Smart Workspace 実行設定', context), name='settings', fallback='PREFERENCES')
    _draw_help_button(header, context, 'smart_tools_settings', text=True)

    settings_box = layout.box()
    settings_box.prop(owner, 'store_in_blend')
    settings_box.prop(owner, 'prefer_blend_config')

    shortcut_box = layout.box()
    ui_icons.label(shortcut_box, text=ui_pair('Shortcut IDs', 'ショートカットID', context), name='keyboard', fallback='KEYINGSET')
    _draw_runtime_shortcut_ids(owner, shortcut_box, context, include_guide=False)


classes = (
    SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_OT_copy_text,
    SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings,
)

_REGISTERED_CLASSES: list[type] = []


def _duplicate_register_error(exc) -> bool:
    text_value = str(exc or '').lower()
    return 'already registered' in text_value or 'registered as a subclass' in text_value


def _runtime_rna_property_definition():
    try:
        wm_type = getattr(bpy.types, 'WindowManager', None)
        rna = getattr(wm_type, 'bl_rna', None)
        properties = getattr(rna, 'properties', None)
        getter = getattr(properties, 'get', None)
        if callable(getter):
            return getter(_RUNTIME_STORAGE_ATTR)
    except Exception:
        pass
    return None


def _runtime_pointer_exists() -> bool:
    return _runtime_rna_property_definition() is not None


def _runtime_pointer_is_suite_owned() -> bool:
    return _runtime_ledger.property_is_current(
        bpy.types.WindowManager,
        _RUNTIME_STORAGE_ATTR,
        SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings,
    )


def _runtime_pointer_teardown_unsafe() -> bool:
    try:
        from . import persistence as _suite_persistence
        if bool(
            getattr(_suite_persistence, '_FILE_LOAD_IN_PROGRESS', False)
            or getattr(_suite_persistence, '_RESTORING', False)
            or getattr(_suite_persistence, '_RESTORE_PENDING', False)
        ):
            return True
    except Exception:
        pass
    return bool(_suite_storage.registration_write_guard_active())


def _remove_runtime_settings_pointer() -> bool:
    """Remove only the exact descriptor created by this generation."""
    if not _runtime_pointer_exists():
        return True
    if not _runtime_pointer_is_suite_owned():
        return True
    if _runtime_pointer_teardown_unsafe():
        return False
    try:
        delattr(bpy.types.WindowManager, _RUNTIME_STORAGE_ATTR)
    except Exception:
        return False
    return _runtime_rna_property_definition() is None


def _ensure_runtime_settings_pointer(settings_cls=None) -> bool:
    owner = bpy.types.WindowManager
    if _runtime_pointer_exists():
        if _runtime_pointer_is_suite_owned():
            return True
        _runtime_ledger.mark_restart_required('FOREIGN_OR_OLD_RUNTIME_SETTINGS_POINTER')
        return False
    if not isinstance(settings_cls, type):
        return False
    if not _runtime_ledger.class_is_current(settings_cls):
        _runtime_ledger.mark_restart_required('RUNTIME_SETTINGS_CLASS_IDENTITY_UNPROVEN')
        return False
    created = False
    try:
        setattr(owner, _RUNTIME_STORAGE_ATTR, PointerProperty(type=settings_cls))
        created = True
        if not _runtime_ledger.record_property(
            owner,
            _RUNTIME_STORAGE_ATTR,
            settings_cls,
            remover=lambda _handle=None: delattr(owner, _RUNTIME_STORAGE_ATTR),
            newly_registered=True,
        ):
            raise RuntimeError('Unable to record runtime settings PointerProperty ownership')
        return _runtime_pointer_is_suite_owned()
    except Exception:
        if created:
            try:
                delattr(owner, _RUNTIME_STORAGE_ATTR)
            except Exception:
                pass
        _runtime_ledger.mark_restart_required('RUNTIME_SETTINGS_POINTER_REGISTRATION_FAILED')
        return False


def _safe_unregister_preferences_class(cls, *, broad: bool = False) -> None:
    del broad
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return
    _runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='PREFERENCES_CLASS',
    )


def _safe_register_preferences_class(cls) -> bool:
    if not isinstance(cls, type):
        return False
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='PREFERENCES_CLASS',
    )
    return bool(success)


def register() -> None:
    _REGISTERED_CLASSES.clear()
    newly_registered = []
    new_properties = []
    try:
        for cls in classes:
            was_active = _runtime_ledger.class_is_current(cls)
            if not _safe_register_preferences_class(cls):
                raise RuntimeError('RESTART_REQUIRED: preferences RNA identity mismatch')
            if not was_active:
                newly_registered.append(cls)
            _REGISTERED_CLASSES.append(cls)
        pointer_existed = _runtime_pointer_exists()
        if not _ensure_runtime_settings_pointer(
            SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings
        ):
            raise RuntimeError('RESTART_REQUIRED: runtime settings pointer ownership mismatch')
        if not pointer_existed:
            new_properties.append((bpy.types.WindowManager, _RUNTIME_STORAGE_ATTR))
        load_runtime_settings(getattr(bpy, 'context', None))
    except Exception:
        _runtime_ledger.rollback_new_items(newly_registered, new_properties)
        _REGISTERED_CLASSES.clear()
        raise


def unregister() -> None:
    persistence_module = None
    try:
        from . import persistence as persistence_module
    except Exception:
        try:
            if persistence_module is not None:
                persistence_module.mark_deferred_settings_dirty()
        except Exception:
            pass
    try:
        _unpatch_userpref_addon_preferences_visibility()
    except Exception:
        pass
    pointer_removed = _remove_runtime_settings_pointer()
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        if cls is SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings and not pointer_removed:
            continue
        _safe_unregister_preferences_class(cls)
    _REGISTERED_CLASSES.clear()
    try:
        if persistence_module is not None:
            persistence_module.release_teardown_runtime_write_barrier()
    except Exception:
        pass
