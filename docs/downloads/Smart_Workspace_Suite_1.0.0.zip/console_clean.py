# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Compatibility call sites for retired automatic console repairs.

Only the explicit, caller-owned copy operation may add a keymap entry.
"""


def repair_empty_view3d_active_tool(*args, **kwargs):
    return False


def clean_keymaps_and_preferences(*args, **kwargs):
    return dict(success=True, changed=False, reason="user-data-untouched")


def _unchanged(*args, **kwargs):
    return True


register_legacy_operator_compatibility = _unchanged
sanitize_panel_draws = _unchanged
install = _unchanged
uninstall = _unchanged


def _copy_keymap_item(dst_km, src_kmi):
    try:
        operator, key, event = (
            str(getattr(src_kmi, field, None) or "") for field in ("idname", "type", "value")
        )
        if not all((operator, key, event)):
            return None
        modifiers = {
            name: bool(getattr(src_kmi, name, False))
            for name in ("any", "shift", "ctrl", "alt", "oskey")
        }
        modifiers["key_modifier"] = str(getattr(src_kmi, "key_modifier", None) or "NONE")
        return dst_km.keymap_items.new(operator, key, event, **modifiers)
    except Exception:
        return None
