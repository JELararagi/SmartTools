# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Compatibility surface with no user-data mutation.

Historical builds edited keymaps, preferences, active tools, panel draw methods,
and addon entries.  Smart Workspace Suite 1.1.129 never changes those resources.
The function names remain for callers and public compatibility, but every path is
bounded, synchronous, and side-effect free.
"""

from __future__ import annotations

from typing import Any


def repair_empty_view3d_active_tool(*_args: Any, **_kwargs: Any) -> bool:
    return False


def clean_keymaps_and_preferences(*_args: Any, **_kwargs: Any) -> dict[str, Any]:
    return {"success": True, "changed": False, "reason": "user-data-untouched"}


def register_legacy_operator_compatibility(*_args: Any, **_kwargs: Any) -> bool:
    return True


def sanitize_panel_draws(*_args: Any, **_kwargs: Any) -> bool:
    return True


def install(*_args: Any, **_kwargs: Any) -> bool:
    return True


def uninstall(*_args: Any, **_kwargs: Any) -> bool:
    return True


def _copy_keymap_item(dst_km: Any, src_kmi: Any):
    """Compatibility helper retained for explicit, caller-owned migrations.

    Smart Workspace Suite never invokes this helper during register/load/unload.
    It preserves the historical callable surface without scanning, removing, or
    rewriting user keymaps automatically.
    """
    try:
        idname = str(getattr(src_kmi, "idname", "") or "")
        type_name = str(getattr(src_kmi, "type", "") or "")
        value = str(getattr(src_kmi, "value", "") or "")
        if not idname or not type_name or not value:
            return None
        kwargs = {
            "any": bool(getattr(src_kmi, "any", False)),
            "shift": bool(getattr(src_kmi, "shift", False)),
            "ctrl": bool(getattr(src_kmi, "ctrl", False)),
            "alt": bool(getattr(src_kmi, "alt", False)),
            "oskey": bool(getattr(src_kmi, "oskey", False)),
            "key_modifier": str(getattr(src_kmi, "key_modifier", "NONE") or "NONE"),
        }
        return dst_km.keymap_items.new(idname, type_name, value, **kwargs)
    except Exception:
        return None
