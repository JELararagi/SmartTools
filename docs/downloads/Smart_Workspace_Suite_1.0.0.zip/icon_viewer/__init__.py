# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Icon Viewer",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "Smart Tools > Icon Viewer",
    "description": "Browse Blender icon names and copy icon identifiers for UI work.",
    "category": "Interface",
}

import json
from pathlib import Path

import bpy
from .. import storage as _suite_storage
from .. import runtime_ledger as _runtime_ledger
from .. import ui_icons
from .. import persistence as _suite_persistence
from ..translation import localized_layout, ui_pair
import math
from bpy.props import (
    BoolProperty,
    StringProperty,
)

DPI = 72
POPUP_PADDING = 10
PANEL_PADDING = 44
WIN_PADDING = 32
ICON_SIZE = 20
HISTORY_SIZE = 100
HISTORY = []

_INTEGRATED_STORAGE_ATTR = "smart_workspace_suite_icon_viewer_prefs"
_INTEGRATED_STORAGE_CLS = None
_INTEGRATED_LAST_SNAPSHOT = ''
_INTEGRATED_AUTOSAVE_ENABLED = False
_INTEGRATED_LOADING = False
_INTEGRATED_UPDATES_PATCHED = False


def _is_integrated_mode() -> bool:
    package = str(__package__ or "").lower()
    return (
        ".smart_workspace_suite." in package
        or package.startswith("smart_workspace_suite.")
        or package.endswith(".smart_workspace_suite")
        or package == "smart_workspace_suite"
    )


def ui_scale():
    prefs = bpy.context.preferences.system
    return prefs.dpi / DPI




def _draw_suite_help_button(layout, context=None, help_id='runtime') -> None:
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = help_id
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass

def prefs():
    if _is_integrated_mode():
        wm = getattr(bpy.context, "window_manager", None)
        return getattr(wm, _INTEGRATED_STORAGE_ATTR, None) if wm is not None else None
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is not None:
        return addon.preferences
    return bpy.context.preferences.addons[__package__].preferences


class Icons:
    def __init__(self, is_popup=False):
        self._filtered_icons = None
        self._filter = ""
        self.filter = ""
        self.selected_icon = ""
        self.is_popup = is_popup

    @property
    def filter(self):
        return self._filter

    @filter.setter
    def filter(self, value):
        if self._filter == value:
            return

        self._filter = value
        self.update()

    @property
    def filtered_icons(self):
        if self._filtered_icons is None:
            self._filtered_icons = []
            icon_filter = self._filter.upper()
            self.filtered_icons.clear()
            pr = prefs()

            icons = bpy.types.UILayout.bl_rna.functions[
                "prop"].parameters["icon"].enum_items.keys()
            for icon in icons:
                if icon == 'NONE' or \
                        icon_filter and icon_filter not in icon or \
                        not pr.show_brush_icons and "BRUSH_" in icon and \
                        icon != 'BRUSH_DATA' or \
                        not pr.show_matcap_icons and "MATCAP_" in icon or \
                        not pr.show_event_icons and (
                            "EVENT_" in icon or "MOUSE_" in icon
                        ) or \
                        not pr.show_colorset_icons and "COLORSET_" in icon:
                    continue
                self._filtered_icons.append(icon)

        return self._filtered_icons

    @property
    def num_icons(self):
        return len(self.filtered_icons)

    def update(self):
        if self._filtered_icons is not None:
            self._filtered_icons.clear()
            self._filtered_icons = None

    def draw(self, layout, num_cols=0, icons=None):
        if icons:
            filtered_icons = reversed(icons)
        else:
            filtered_icons = self.filtered_icons

        column = layout.column(align=True)
        row = column.row(align=True)
        row.alignment = 'CENTER'
        row.scale_y = 1.65

        selected_icon = self.selected_icon if self.is_popup else \
            bpy.context.window_manager.clipboard
        col_idx = 0
        for i, icon in enumerate(filtered_icons):
            p = row.operator(
                IV_OT_icon_select.bl_idname, text="",
                icon=icon, emboss=icon == selected_icon)
            p.icon = icon
            p.force_copy_on_select = not self.is_popup

            col_idx += 1
            if col_idx > num_cols - 1:
                if icons:
                    break
                col_idx = 0
                if i < len(filtered_icons) - 1:
                    row = column.row(align=True)
                    row.alignment = 'CENTER'
                    row.scale_y = 1.65

        if col_idx != 0 and not icons and i >= num_cols:
            for _ in range(num_cols - col_idx):
                row.label(text="", icon='BLANK1')

        if not filtered_icons:
            row.label(text="No icons were found")


class IV_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    panel_icons = Icons()
    popup_icons = Icons(is_popup=True)

    def update_icons(self, context):
        self.panel_icons.update()
        self.popup_icons.update()

    def set_panel_filter(self, value):
        self.panel_icons.filter = value

    panel_filter: StringProperty(
        description="Filter",
        default="",
        get=lambda s: s.panel_icons.filter,
        set=set_panel_filter,
        options={'TEXTEDIT_UPDATE'})
    show_panel_icons: BoolProperty(
        name="Show Icons",
        description="Show icons", default=True)
    show_history: BoolProperty(
        name="Show History",
        description="Show history", default=True)
    show_brush_icons: BoolProperty(
        name="Show Brush Icons",
        description="Show brush icons", default=True,
        update=update_icons)
    show_matcap_icons: BoolProperty(
        name="Show Matcap Icons",
        description="Show matcap icons", default=True,
        update=update_icons)
    show_event_icons: BoolProperty(
        name="Show Event Icons",
        description="Show event icons", default=True,
        update=update_icons)
    show_colorset_icons: BoolProperty(
        name="Show Colorset Icons",
        description="Show colorset icons", default=True,
        update=update_icons)
    copy_on_select: BoolProperty(
        name="Copy Icon On Click",
        description="Copy icon on click", default=True)
    close_on_select: BoolProperty(
        name="Close Popup On Click",
        description=(
            "Close the popup on click.\n"
            "Not supported by some windows (User Preferences, Render)"
        ),
        default=False)
    auto_focus_filter: BoolProperty(
        name="Auto Focus Input Field",
        description="Auto focus input field", default=True)
    show_panel: BoolProperty(
        name="Show Panel",
        description="Show the panel in the Text Editor", default=True)
    show_header: BoolProperty(
        name="Show Header",
        description="Show the header in the Python Console",
        default=True)

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        row = layout.row()
        row.scale_y = 1.5
        row.operator(IV_OT_icons_show.bl_idname)

        row = layout.row()

        col = row.column(align=True)
        col.label(text="Icons:")
        col.prop(self, "show_matcap_icons")
        col.prop(self, "show_brush_icons")
        col.prop(self, "show_colorset_icons")
        col.prop(self, "show_event_icons")
        col.separator()
        col.prop(self, "show_history")

        col = row.column(align=True)
        col.label(text="Popup:")
        col.prop(self, "auto_focus_filter")
        col.prop(self, "copy_on_select")
        if self.copy_on_select:
            col.prop(self, "close_on_select")

        col = row.column(align=True)
        col.label(text="Panel:")
        col.prop(self, "show_panel")
        if self.show_panel:
            col.prop(self, "show_panel_icons")




def _integrated_prefs_filepath() -> Path:
    return _suite_storage.addon_storage_path('icon_viewer_preferences.json', 'icon_viewer')


def _integrated_prefs_dict(prefs_obj) -> dict:
    data = {}
    for name in getattr(IV_Preferences, '__annotations__', {}).keys():
        if name in {'panel_icons', 'popup_icons'} or not hasattr(prefs_obj, name):
            continue
        try:
            value = getattr(prefs_obj, name)
        except Exception:
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            data[str(name)] = value
    return data


def _apply_integrated_prefs_dict(prefs_obj, data: dict | None) -> None:
    if prefs_obj is None or not isinstance(data, dict):
        return
    global _INTEGRATED_LOADING
    _INTEGRATED_LOADING = True
    try:
        for name in getattr(IV_Preferences, '__annotations__', {}).keys():
            if name not in data or name in {'panel_icons', 'popup_icons'} or not hasattr(prefs_obj, name):
                continue
            try:
                setattr(prefs_obj, name, data.get(name))
            except Exception:
                pass
    finally:
        _INTEGRATED_LOADING = False


def save_integrated_preferences(context=None, *, force: bool = False) -> bool:
    if not _is_integrated_mode():
        return True
    if _INTEGRATED_LOADING:
        return False
    if not force:
        try:
            if not _suite_storage.n_panel_state_save_enabled(True):
                _suite_persistence.mark_deferred_settings_dirty()
                return False
        except Exception:
            return False
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    prefs_obj = getattr(wm, _INTEGRATED_STORAGE_ATTR, None) if wm is not None else None
    if prefs_obj is None:
        return True
    try:
        path = _integrated_prefs_filepath()
        return bool(_suite_storage.atomic_write_json(
            path, _integrated_prefs_dict(prefs_obj),
            indent=2, ensure_ascii=False, sort_keys=True,
        ))
    except Exception:
        return False

def load_integrated_preferences(context=None) -> None:
    if not _is_integrated_mode():
        return
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    prefs_obj = getattr(wm, _INTEGRATED_STORAGE_ATTR, None) if wm is not None else None
    if prefs_obj is None:
        return
    path = _integrated_prefs_filepath()
    if not path.exists():
        save_integrated_preferences(context)
        return
    try:
        data = _suite_storage.read_json(path, None)
    except Exception:
        data = None
    _apply_integrated_prefs_dict(prefs_obj, data if isinstance(data, dict) else None)
    global _INTEGRATED_LAST_SNAPSHOT
    _INTEGRATED_LAST_SNAPSHOT = _integrated_snapshot(context)


def _integrated_snapshot(context=None) -> str:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    prefs_obj = getattr(wm, _INTEGRATED_STORAGE_ATTR, None) if wm is not None else None
    if prefs_obj is None:
        return ''
    try:
        return json.dumps(_integrated_prefs_dict(prefs_obj), ensure_ascii=False, sort_keys=True)
    except Exception:
        return ''


def _persist_integrated_user_change(context=None, source: str = 'icon-viewer-rna-update') -> bool:
    if _INTEGRATED_LOADING:
        return False
    try:
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def _patch_integrated_property_updates(pref_cls) -> None:
    """Attach persistence to every Icon Viewer setting before registration."""
    global _INTEGRATED_UPDATES_PATCHED
    if _INTEGRATED_UPDATES_PATCHED:
        return

    update_factories = (
        bpy.props.BoolProperty,
        bpy.props.EnumProperty,
        bpy.props.FloatProperty,
        bpy.props.FloatVectorProperty,
        bpy.props.IntProperty,
        bpy.props.IntVectorProperty,
        bpy.props.StringProperty,
    )

    def make_event_update(old_update, name):
        def event_update(self, context):
            try:
                if callable(old_update):
                    old_update(self, context)
            finally:
                _persist_integrated_user_change(
                    context,
                    source=f'icon-viewer:{name}',
                )

        return event_update

    patched_keywords = []
    for name, deferred in getattr(pref_cls, '__annotations__', {}).items():
        if getattr(deferred, 'function', None) not in update_factories:
            continue
        keywords = getattr(deferred, 'keywords', None)
        if not isinstance(keywords, dict) or keywords.get('_sws_event_persistence'):
            continue
        old_update = keywords.get('update')
        keywords['update'] = make_event_update(old_update, str(name))
        keywords['_sws_event_persistence'] = True
        patched_keywords.append(keywords)
    for keywords in patched_keywords:
        keywords.pop('_sws_event_persistence', None)
    _INTEGRATED_UPDATES_PATCHED = True


def _integrated_autosave_timer():
    """Legacy callback retained only so prior generations can be unregistered."""
    return None


def _start_integrated_autosave() -> None:
    """Enable the event-driven compatibility lease without creating a timer."""
    global _INTEGRATED_AUTOSAVE_ENABLED, _INTEGRATED_LAST_SNAPSHOT
    _INTEGRATED_AUTOSAVE_ENABLED = True
    _INTEGRATED_LAST_SNAPSHOT = _integrated_snapshot(getattr(bpy, 'context', None))
    try:
        if bpy.app.timers.is_registered(_integrated_autosave_timer):
            bpy.app.timers.unregister(_integrated_autosave_timer)
    except Exception:
        pass


def _stop_integrated_autosave() -> None:
    global _INTEGRATED_AUTOSAVE_ENABLED
    _INTEGRATED_AUTOSAVE_ENABLED = False
    try:
        if bpy.app.timers.is_registered(_integrated_autosave_timer):
            bpy.app.timers.unregister(_integrated_autosave_timer)
    except Exception:
        pass


def _suite_always_on_enabled(action: str, default: bool = False) -> bool:
    if not _is_integrated_mode():
        return bool(default)
    try:
        from .. import ui_runtime as _suite_ui_runtime
        getter = getattr(_suite_ui_runtime, '_remembered_always_state', None)
        if callable(getter):
            return bool(getter(action, default))
    except Exception:
        pass
    return bool(default)


def _register_integrated_storage(pref_cls) -> bool:
    global _INTEGRATED_STORAGE_CLS
    if not _is_integrated_mode():
        return True
    if _INTEGRATED_STORAGE_CLS is None:
        _patch_integrated_property_updates(pref_cls)
        attrs = {
            '__module__': __name__,
            '__annotations__': dict(getattr(pref_cls, '__annotations__', {})),
            'panel_icons': getattr(pref_cls, 'panel_icons', Icons()),
            'popup_icons': getattr(pref_cls, 'popup_icons', Icons(is_popup=True)),
        }
        for name, value in pref_cls.__dict__.items():
            if name.startswith('__') or name in {'bl_rna', 'rna_type'}:
                continue
            if callable(value) or isinstance(value, (staticmethod, classmethod, property)):
                attrs[name] = value
        _INTEGRATED_STORAGE_CLS = type('IV_INTEGRATED_PREFERENCES', (bpy.types.PropertyGroup,), attrs)
    success, _newly_registered = _runtime_ledger.register_class_exact(
        _INTEGRATED_STORAGE_CLS,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='ICON_VIEWER_STORAGE_CLASS',
    )
    if not success:
        return False
    owner = bpy.types.WindowManager
    signature = _runtime_ledger.live_property_signature(owner, _INTEGRATED_STORAGE_ATTR)
    if signature[1]:
        if not _runtime_ledger.property_is_current(
            owner, _INTEGRATED_STORAGE_ATTR, _INTEGRATED_STORAGE_CLS
        ):
            _runtime_ledger.mark_restart_required('ICON_VIEWER_STORAGE_POINTER_CONFLICT')
            return False
    else:
        setattr(owner, _INTEGRATED_STORAGE_ATTR, bpy.props.PointerProperty(type=_INTEGRATED_STORAGE_CLS))
        if not _runtime_ledger.record_property(
            owner,
            _INTEGRATED_STORAGE_ATTR,
            _INTEGRATED_STORAGE_CLS,
            remover=lambda _handle=None: delattr(owner, _INTEGRATED_STORAGE_ATTR),
            newly_registered=True,
        ):
            try:
                delattr(owner, _INTEGRATED_STORAGE_ATTR)
            except Exception:
                pass
            return False
    load_integrated_preferences(getattr(bpy, 'context', None))
    _stop_integrated_autosave()
    return True


def _unregister_integrated_storage() -> bool:
    global _INTEGRATED_STORAGE_CLS
    save_integrated_preferences(getattr(bpy, 'context', None), force=True)
    _stop_integrated_autosave()
    owner = bpy.types.WindowManager
    if _runtime_ledger.live_property_signature(owner, _INTEGRATED_STORAGE_ATTR)[1]:
        if not _runtime_ledger.property_is_current(
            owner, _INTEGRATED_STORAGE_ATTR, _INTEGRATED_STORAGE_CLS
        ):
            return False
        try:
            delattr(owner, _INTEGRATED_STORAGE_ATTR)
        except Exception:
            return False
    if _INTEGRATED_STORAGE_CLS is not None:
        if not _runtime_ledger.unregister_class_exact(
            _INTEGRATED_STORAGE_CLS,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='ICON_VIEWER_STORAGE_CLASS',
        ):
            return False
        _INTEGRATED_STORAGE_CLS = None
    return True

class IV_PT_icons(bpy.types.Panel):
    bl_space_type = "TEXT_EDITOR"
    bl_region_type = "UI"
    bl_label = "Icon Viewer"
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}

    @staticmethod
    def tag_redraw():
        wm = bpy.context.window_manager
        if not wm:
            return

        for w in wm.windows:
            for a in w.screen.areas:
                if a.type == 'TEXT_EDITOR':
                    for r in a.regions:
                        if r.type == 'UI':
                            r.tag_redraw()

    def draw(self, context):
        pr = prefs()
        row = localized_layout(self.layout, context).row(align=True)
        if pr.show_panel_icons:
            ui_icons.prop(row, pr, "panel_filter", text="", name='search', fallback='VIEWZOOM')
        else:
            row.operator(IV_OT_icons_show.bl_idname)
        ui_icons.set_large_icon_scale(row, 1.25)
        ui_icons.operator(
            row, IV_OT_panel_menu_call.bl_idname, text="", name='menu', fallback='COLLAPSEMENU', emboss=False)
        _draw_suite_help_button(row, context, 'icon_viewer')

        _, y0 = context.region.view2d.region_to_view(0, 0)
        _, y1 = context.region.view2d.region_to_view(0, 10)
        region_scale = 10 / abs(y0 - y1)

        cell_size = max(1, math.ceil(ui_scale() * region_scale * ICON_SIZE))
        num_cols = max(1, (context.region.width - PANEL_PADDING) // cell_size)

        col = None
        if HISTORY and pr.show_history:
            col = localized_layout(self.layout, context).column(align=True)
            pr.panel_icons.draw(col.box(), num_cols, HISTORY)

        if pr.show_panel_icons:
            col = col or localized_layout(self.layout, context).column(align=True)
            pr.panel_icons.draw(col.box(), num_cols)

    @classmethod
    def poll(cls, context):
        return prefs().show_panel


class IV_OT_panel_menu_call(bpy.types.Operator):
    bl_idname = "iv.panel_menu_call"
    bl_label = ""
    bl_description = "Menu"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def menu(self, menu, context):
        pr = prefs()
        layout = menu.layout
        layout.prop(pr, "show_panel_icons")
        layout.prop(pr, "show_history")

        if not pr.show_panel_icons:
            return

        layout.separator()
        layout.prop(pr, "show_matcap_icons")
        layout.prop(pr, "show_brush_icons")
        layout.prop(pr, "show_colorset_icons")
        layout.prop(pr, "show_event_icons")

    def execute(self, context):
        context.window_manager.popup_menu(self.menu, title="Icon Viewer")
        return {'FINISHED'}


class IV_OT_icon_select(bpy.types.Operator):
    bl_idname = "iv.icon_select"
    bl_label = ""
    bl_description = "Select the icon"
    bl_options = {'INTERNAL', 'UNDO'}

    icon: StringProperty()
    force_copy_on_select: BoolProperty()

    def execute(self, context):
        pr = prefs()
        pr.popup_icons.selected_icon = self.icon
        if pr.copy_on_select or self.force_copy_on_select:
            context.window_manager.clipboard = self.icon
            self.report({'INFO'}, self.icon)

            if pr.close_on_select and IV_OT_icons_show.instance:
                IV_OT_icons_show.instance.close()

        if pr.show_history:
            if self.icon in HISTORY:
                HISTORY.remove(self.icon)
            if len(HISTORY) >= HISTORY_SIZE:
                HISTORY.pop(0)
            HISTORY.append(self.icon)
        return {'FINISHED'}


class IV_OT_icons_show(bpy.types.Operator):
    bl_idname = "iv.icons_show"
    bl_label = "Icon Viewer"
    bl_description = "Icon viewer"
    bl_options = {'UNDO'}
    bl_property = "filter_auto_focus"

    instance = None

    def set_filter(self, value):
        prefs().popup_icons.filter = value

    def set_selected_icon(self, value):
        if IV_OT_icons_show.instance:
            IV_OT_icons_show.instance.auto_focusable = False

    filter_auto_focus: StringProperty(
        description="Filter",
        get=lambda s: prefs().popup_icons.filter,
        set=set_filter,
        options={'TEXTEDIT_UPDATE', 'SKIP_SAVE'})
    filter: StringProperty(
        description="Filter",
        get=lambda s: prefs().popup_icons.filter,
        set=set_filter,
        options={'TEXTEDIT_UPDATE'})
    selected_icon: StringProperty(
        description="Selected Icon",
        get=lambda s: prefs().popup_icons.selected_icon,
        set=set_selected_icon)

    def get_num_cols(self, num_icons):
        return round(1.3 * math.sqrt(num_icons))

    def draw_header(self, layout):
        pr = prefs()
        header = layout.box()
        header = header.split(factor=0.75) if self.selected_icon else \
            header.row()
        row = header.row(align=True)
        row.prop(pr, "show_matcap_icons", text="", icon='SHADING_RENDERED')
        row.prop(pr, "show_brush_icons", text="", icon='BRUSH_DATA')
        row.prop(pr, "show_colorset_icons", text="", icon='COLOR')
        row.prop(pr, "show_event_icons", text="", icon='HAND')
        row.separator()

        ui_icons.prop(
            row, pr, "copy_on_select", text="",
            name='copy', fallback='COPYDOWN', toggle=True)
        if pr.copy_on_select:
            sub = row.row(align=True)
            if bpy.context.window.screen.name == "temp":
                sub.alert = True
            ui_icons.prop(
                sub, pr, "close_on_select", text="",
                name='close', fallback='RESTRICT_SELECT_OFF', toggle=True)
        ui_icons.prop(
            row, pr, "auto_focus_filter", text="",
            name='search', fallback='OUTLINER_DATA_FONT', toggle=True)
        row.separator()
        _draw_suite_help_button(row, bpy.context, 'icon_viewer')

        if self.auto_focusable and pr.auto_focus_filter:
            ui_icons.prop(row, self, "filter_auto_focus", text="", name='search', fallback='VIEWZOOM')
        else:
            ui_icons.prop(row, self, "filter", text="", name='search', fallback='VIEWZOOM')

        if self.selected_icon:
            row = header.row()
            row.prop(self, "selected_icon", text="", icon=self.selected_icon)

    def draw(self, context):
        pr = prefs()
        col = localized_layout(self.layout, context)
        self.draw_header(col)

        history_num_cols = int(
            (self.width - POPUP_PADDING) / (ui_scale() * ICON_SIZE))
        num_cols = min(
            self.get_num_cols(len(pr.popup_icons.filtered_icons)),
            history_num_cols)

        subcol = col.column(align=True)

        if HISTORY and pr.show_history:
            pr.popup_icons.draw(subcol.box(), history_num_cols, HISTORY)

        pr.popup_icons.draw(subcol.box(), num_cols)

    def close(self):
        bpy.context.window.screen = bpy.context.window.screen

    def check(self, context):
        return True

    def cancel(self, context):
        IV_OT_icons_show.instance = None
        IV_PT_icons.tag_redraw()

    def execute(self, context):
        if not IV_OT_icons_show.instance:
            return {'CANCELLED'}
        IV_OT_icons_show.instance = None

        pr = prefs()
        if self.selected_icon and not pr.copy_on_select:
            context.window_manager.clipboard = self.selected_icon
            self.report({'INFO'}, self.selected_icon)
        pr.popup_icons.selected_icon = ""

        IV_PT_icons.tag_redraw()
        return {'FINISHED'}

    def invoke(self, context, event):
        pr = prefs()
        pr.popup_icons.selected_icon = ""
        pr.popup_icons.filter = ""
        IV_OT_icons_show.instance = self
        self.auto_focusable = True

        num_cols = self.get_num_cols(len(pr.popup_icons.filtered_icons))
        self.width = int(min(
            ui_scale() * (num_cols * ICON_SIZE + POPUP_PADDING),
            context.window.width - WIN_PADDING))

        return context.window_manager.invoke_props_dialog(
            self, width=self.width)


def draw_console_header(self, context):
    if not prefs().show_header:
        return
    localized_layout(self.layout, context).operator(IV_OT_icons_show.bl_idname)


classes = (
    IV_PT_icons,
    IV_OT_panel_menu_call,
    IV_OT_icon_select,
    IV_OT_icons_show,
    IV_Preferences,
)

_HEADER_DRAW_APPENDED = False


def register():
    global _HEADER_DRAW_APPENDED
    if bpy.app.background:
        return

    classes_to_register = [
        cls for cls in classes
        if not (_is_integrated_mode() and cls is IV_Preferences)
    ]
    for cls in classes_to_register:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='ICON_VIEWER_CLASS',
        )
        if not success:
            raise RuntimeError('RESTART_REQUIRED: Icon Viewer class ownership mismatch')

    if not _register_integrated_storage(IV_Preferences):
        raise RuntimeError('RESTART_REQUIRED: Icon Viewer storage ownership mismatch')
    if _suite_always_on_enabled('icon_viewer_console_header', False) and not _HEADER_DRAW_APPENDED:
        try:
            bpy.types.CONSOLE_HT_header.append(draw_console_header)
            _HEADER_DRAW_APPENDED = True
        except Exception:
            _HEADER_DRAW_APPENDED = False
    elif not _suite_always_on_enabled('icon_viewer_console_header', False) and _HEADER_DRAW_APPENDED:
        try:
            bpy.types.CONSOLE_HT_header.remove(draw_console_header)
        except Exception:
            pass
        _HEADER_DRAW_APPENDED = False


def unregister():
    global _HEADER_DRAW_APPENDED
    if bpy.app.background:
        return

    if _HEADER_DRAW_APPENDED:
        try:
            bpy.types.CONSOLE_HT_header.remove(draw_console_header)
        except Exception:
            pass
        _HEADER_DRAW_APPENDED = False
    if not _unregister_integrated_storage():
        return False

    classes_to_unregister = [
        cls for cls in classes
        if not (_is_integrated_mode() and cls is IV_Preferences)
    ]
    for cls in reversed(classes_to_unregister):
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='ICON_VIEWER_CLASS',
        ):
            return False
    return True
