# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Resolve the workspace preferences in legacy and extension installations."""

from pathlib import Path

SUITE = "smart_workspace_suite"


def root_package_name(package="", module_name="", file_path=""):
    explicit = str(package or "").strip()
    if explicit:
        return explicit
    module = str(module_name or "").strip()
    head, separator, _ = module.partition(".")
    if separator:
        return head
    if file_path:
        try:
            return Path(file_path).resolve().parent.name or SUITE
        except (ValueError, OSError, RuntimeError):
            pass
    return SUITE


def preflight_cleanup(package="", module_name="", file_path=""):
    """The active registration generation owns cleanup."""


def get_addon_preferences(context=None, package="", module_name="", file_path=""):
    if context is None:
        try:
            import bpy
        except ImportError:
            return None
        context = bpy.context
    entries = getattr(getattr(context, "preferences", None), "addons", None)
    if entries is None:
        return None
    root = root_package_name(package, module_name, file_path)
    addon = entries.get(root)
    if addon is None and root != SUITE:
        addon = entries.get(SUITE)
    return addon.preferences if addon is not None else None
