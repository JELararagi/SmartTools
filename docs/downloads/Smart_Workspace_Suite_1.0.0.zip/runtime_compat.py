# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import sys
from pathlib import Path


_DEF_ROOT = 'smart_workspace_suite'
_LEGACY_TOP_LEVEL_MODULES = (
    'navigation_properties',
    'bootstrap',
    'bootstrap_common',
    'tool_runtime',
    'runtime',
)
_STALE_PACKAGE_MODULES = (
    'smart_tools_window_bridge',
)


def root_package_name(package: str = '', module_name: str = '', file_path: str = '') -> str:
    package = str(package or '').strip()
    if package:
        return package

    module_name = str(module_name or '').strip()
    if module_name:
        if '.' in module_name:
            return module_name.split('.', 1)[0]
        return module_name

    file_path = str(file_path or '').strip()
    if file_path:
        try:
            return Path(file_path).resolve().parent.name or _DEF_ROOT
        except Exception:
            pass
    return _DEF_ROOT


def _root_dir(file_path: str = '') -> Path | None:
    file_path = str(file_path or '').strip()
    if not file_path:
        return None
    try:
        return Path(file_path).resolve().parent
    except Exception:
        return None


def _path_is_inside(path: str | Path, parent: Path | None) -> bool:
    if parent is None:
        return False
    try:
        Path(path).resolve().relative_to(parent)
        return True
    except Exception:
        return False


def preflight_cleanup(package: str = '', module_name: str = '', file_path: str = '') -> None:
    """Compatibility no-op; exact generation ownership replaces module eviction."""
    del package, module_name, file_path
    return None




def get_addon_preferences(context=None, package: str = '', module_name: str = '', file_path: str = ''):
    try:
        import bpy  # pylint: disable=import-outside-toplevel
    except Exception:
        return None

    ctx = context or getattr(bpy, 'context', None)
    prefs_owner = getattr(ctx, 'preferences', None) if ctx is not None else None
    addons = getattr(prefs_owner, 'addons', None) if prefs_owner is not None else None
    if addons is None:
        return None

    root_name = root_package_name(package, module_name, file_path)
    candidates = []
    for value in (root_name, _DEF_ROOT):
        value = str(value or '').strip()
        if value and value not in candidates:
            candidates.append(value)

    for addon_name in candidates:
        try:
            addon_entry = addons.get(addon_name)
        except Exception:
            addon_entry = None
        if addon_entry is not None:
            return getattr(addon_entry, 'preferences', None)
    return None
