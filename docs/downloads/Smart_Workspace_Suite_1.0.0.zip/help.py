# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Help popup drawing for Smart Workspace.

The popup is drawn from the static bilingual help catalog plus a safe source-code
scan of property definitions.  The scan reads bundled Python files with ``ast``
and does not import or register the bundled tools.
"""

from __future__ import annotations

import ast
import functools
import unicodedata
from pathlib import Path
from typing import Any, Iterable

import bpy

from .translation import localized_layout, ui_pair, ui_text, is_japanese
from .tool_metadata import TOOL_META, display_name

_SETTING = tuple[str, str, str, str]

_COMMON_HELP_SETTINGS: tuple[_SETTING, ...] = (
    (
        'Help',
        'ヘルプ',
        'Opens this detailed help popup for the current section.',
        '現在のセクションの詳細ヘルプをポップアップ表示します。',
    ),
)

HELP_DOCS: dict[str, dict[str, Any]] = {
    'runtime': {
        'title_en': 'Smart Workspace',
        'title_ja': 'Smart Workspace',
        'overview_en': (
            'Smart Workspace is the central N-panel hub for organizing Sidebar tabs, building quick-launch categories, '
            'opening pseudo-floating N-panel windows from View3D, managing 2D Pan View, and exposing bundled tools without '
            'loading every tool at startup.'
        ),
        'overview_ja': (
            'Smart Workspace は、Nパネルタブの整理、クイックランチャーカテゴリーの作成、View3D を使った疑似フローティングNパネル、2Dパンビュー、同梱ツールの遅延表示をまとめて扱う中心ツールです。起動時に全ツールを読み込まず、必要な時だけ実行できるようにします。'
        ),
        'usage_en': (
            'Use the Smart Workspace N-panel to refresh detected tabs, add frequently used tabs to categories, pin or favorite entries, '
            'open categories from the launcher, and export or import presets. Ctrl-left-click a launcher N-panel entry when you want the '
            'entry in a separate pseudo-floating View3D window. N-panel settings and saved presets are written to '
            'CONFIG/Smart_Workspace_Suite, so they are restored after Blender restarts, after another .blend file is opened, '
            'and when the active Scene is switched. The Save Preferences button also flushes the same N-panel storage before requesting Blender to save user preferences.'
        ),
        'usage_ja': (
            'Smart Workspace のNパネルで検出タブを更新し、よく使うタブをカテゴリーへ追加し、ピン留めやお気に入りを設定します。'
            'ランチャーからカテゴリーを開き、プリセットの保存や読み込みも行えます。クイックランチャー内のNパネル項目を Ctrl＋左クリックすると、'
            'View3D を使った疑似フローティングウィンドウで開きます。Nパネル設定と保存済みプリセットは CONFIG/Smart_Workspace_Suite 配下へ書き込まれ、'
            'Blender 再起動後、別の .blend 読込後、アクティブシーン切替後にも復元されます。プリファレンスの保存ボタンも同じNパネル保存処理を実行してから、Blender 側のユーザープリファレンス保存を要求します。'
        ),
        'settings': (
            ('Workspace Selector', 'ワークスペース選択', 'Chooses which workspace profile is being edited or copied. Use it before editing categories when another workspace needs a different launcher layout.', '編集またはコピーするワークスペースプロファイルを選びます。ワークスペースごとに別のランチャー構成を作りたい場合、カテゴリー編集前に選択します。'),
            ('Paste Settings to Current Workspace', '現在のワークスペースに設定をペースト', 'Copies the selected workspace profile into the currently active workspace. Use it after preparing a profile you want to reuse.', '選択中のワークスペースプロファイルを現在アクティブなワークスペースへコピーします。再利用したい構成を作った後に使います。'),
            ('Quick Launcher Width', 'クイックランチャー幅', 'Controls the launcher popup width. Increase it when tab names are long or when more columns are displayed.', 'クイックランチャーポップアップの幅を調整します。タブ名が長い場合や列数を増やす場合は大きくします。'),
            ('Quick Launcher Columns', 'クイックランチャー列数', 'Controls how many columns the launcher uses. More columns reduce scrolling but need more popup width.', 'ランチャー内の列数を調整します。列を増やすとスクロールは減りますが、より広いポップアップ幅が必要です。'),
            ('Use Tab Layout in Popup', 'ポップアップ内タブ表示', 'Switches the launcher between a tabbed layout and a simple list layout.', 'ランチャー表示をタブ形式または単純な一覧形式へ切り替えます。'),
            ('Show Recent Tabs', '最近使ったタブを表示', 'Shows recently opened tabs in the launcher. Disable it when the launcher should only show curated categories.', 'ランチャーに最近使ったタブを表示します。整理済みカテゴリーだけを見せたい場合は無効化します。'),
            ('Create Category', 'カテゴリー新規作成', 'Adds a new launcher category. After creating it, add detected tabs or panel entries to the category.', '新しいランチャーカテゴリーを追加します。作成後、検出済みタブやパネル項目をカテゴリーに追加します。'),
            ('Category Name', 'カテゴリー名', 'Renames the selected launcher category. Use short names so they remain readable in the popup.', '選択中のランチャーカテゴリー名を変更します。ポップアップ内で読みやすい短い名前を推奨します。'),
            ('Add Selected to Category', '選択したタブをカテゴリーへ追加', 'Adds the selected detected N-panel tab to the active launcher category.', '選択中の検出済みNパネルタブを、アクティブなランチャーカテゴリーへ追加します。'),
            ('Remove', '削除', 'Removes the selected category entry from the launcher configuration. It does not delete the original add-on or Blender panel.', '選択中のカテゴリー項目をランチャー設定から外します。元のアドオンやBlenderパネルは削除されません。'),
            ('All Detected Tabs', '全タブ一覧', 'Lists the N-panel tabs detected from registered View3D Sidebar panels, including Smart Workspace itself and categories found through delayed panel scans.', '登録済みの View3D サイドバーパネルから検出したNパネルタブを一覧表示します。Smart Workspace 自身と、遅延パネル走査で見つかったカテゴリーも含みます。'),
            ('Panel Pool', 'パネル一覧', 'Lists detected individual panels when panel-level launching or organization is available.', 'パネル単位の起動や整理が利用できる場合に、検出済み個別パネルを一覧表示します。'),
            ('Pin', 'ピン留め', 'The pin mark on a launcher button keeps the panels of that tab visible on the other N-panel tabs. Pressing it also turns on Live Panel Pin Follow. A panel that is closed gets its pin when you open it. After a restart, the pin comes when you open that tab once.', 'ランチャーのボタンの左のピンの印です。押すと、そのタブのパネルがほかのタブを開いている時も表示されます。「パネルピン追従」も有効になります。閉じているパネルは、開いた時にピンが付きます。起動し直した後は、そのタブを一度開くと付きます。'),
            ('Favorite', 'お気に入り', 'Marks an entry as a favorite so it can be shown in the favorite launcher area.', '項目をお気に入りとして登録し、お気に入りランチャー領域に表示できるようにします。'),
            ('Floating Panel Width', 'フローティングパネル幅', 'Default width for pseudo-floating View3D windows opened from a launcher entry.', 'ランチャー項目から開く疑似フローティング View3D ウィンドウの既定幅です。'),
            ('Floating Panel Height', 'フローティングパネル高さ', 'Default height for pseudo-floating View3D windows. Increase it when the target panel is taller.', '疑似フローティング View3D ウィンドウの既定高さです。対象パネルが縦に長い場合は大きくします。'),
            ('Open Mode', '開き方', 'Chooses where a pseudo-floating window appears: mouse center, last position, pinned position, or follow mouse.', '疑似フローティングウィンドウをどこに出すか選びます。マウス中心、前回位置、固定位置、マウス追従を選択できます。'),
            ('Always On Top', '常に前面', 'Keeps a pseudo-floating window above other windows when the operating system allows it.', 'OSが許可する場合、疑似フローティングウィンドウを他ウィンドウより前面に維持します。'),
            ('Monitor Interval', '監視間隔', 'How often an open pseudo-floating window checks saved size and runtime options.', '開いている疑似フローティングウィンドウがサイズや実行時設定を確認する間隔です。'),
            ('Monitor Size', 'サイズ監視', 'Saves size changes made while the pseudo-floating window is open so the next open can reuse them.', '疑似フローティングウィンドウを開いている間のサイズ変更を保存し、次回開く時に再利用します。'),
            ('Monitor Settings', '設定監視', 'Keeps applying runtime settings such as Always On Top while the pseudo-floating window is open.', '疑似フローティングウィンドウが開いている間、常に前面などの実行時設定を維持します。'),
            ('Remember Position', '位置を記憶', 'Stores the last screen position of a pseudo-floating window and reuses it later.', '疑似フローティングウィンドウの最後の画面位置を保存し、次回以降に再利用します。'),
            ('Auto Restore on File Load / Scene Switch', '読込時・シーン切替時に自動復元', 'Restores saved Smart Workspace profiles and runtime state automatically when Blender starts, another .blend file is opened, or the active Scene changes.', 'Blender 起動時、別の .blend ファイルを開いた時、またはアクティブシーンを切り替えた時に、保存済みの Smart Workspace プロファイルと実行状態を自動復元します。'),
            ('Live Panel Pin Follow', 'パネルピン追従', 'Keeps the panels of pinned tabs visible on the other N-panel tabs, using Blender\'s standard panel pin. Turning it off removes the pins; a panel out of sight loses its pin when it is next shown.', 'ピンを付けたタブのパネルを、ほかのタブを開いている時も表示します。Blender 標準のパネルのピンを使います。無効にするとピンを外します。今見えていないパネルは、次に表示された時に外れます。'),
            ('Store Config in .blend', '.blend に設定保存', 'Also stores Smart Workspace configuration inside the current .blend file. Enable it when each project needs a separate layout.', 'Smart Workspace 設定を現在の .blend ファイル内にも保存します。プロジェクトごとに別の構成が必要な場合に使います。'),
            ('Prefer .blend Config on Load', '読込時は .blend 優先', 'Loads project-specific Smart Workspace configuration from the opened .blend before the normal CONFIG configuration.', '開いた .blend 内のプロジェクト専用 Smart Workspace 設定を、通常の CONFIG 設定より優先して読み込みます。'),
            ('Persistent CONFIG Storage', 'CONFIG 永続保存', 'All automatically generated suite settings, state files, and preset files are stored under CONFIG/Smart_Workspace_Suite. On Windows Blender 5.1 this resolves to C:\\Users\\<user>\\AppData\\Roaming\\Blender Foundation\\Blender\\5.1\\config\\Smart_Workspace_Suite. Manual export/import paths remain user-selected.', '自動生成される統合ツール設定、状態ファイル、プリセットファイルはすべて CONFIG/Smart_Workspace_Suite 配下に保存されます。Windows の Blender 5.1 では C:\\Users\\ユーザー名\\AppData\\Roaming\\Blender Foundation\\Blender\\5.1\\config\\Smart_Workspace_Suite に相当します。手動エクスポート/インポートの保存先だけはユーザー指定のままです。'),
            ('N-panel Only Settings', 'Nパネル集約設定', 'Editable suite properties are shown in the N-panel only. Add-on Preferences are not used as a settings UI or storage source in integrated mode.', '編集可能な統合ツール設定はNパネルのみに表示されます。統合モードではアドオンプリファレンスを設定UIや保存元として使用しません。'),
            ('Launcher ID', 'ランチャーID', 'Operator ID used when assigning a keyboard shortcut for the quick launcher.', 'クイックランチャーをキーボードショートカットに割り当てる時に使うオペレーターIDです。'),
            ('Hotbox ID', 'ホットボックスID', 'Operator ID used when assigning a keyboard shortcut for the hotbox or marking-menu style popup.', 'Hotbox またはマーキングメニュー形式ポップアップをショートカット登録する時に使うオペレーターIDです。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime', 'preferences.py'),
    },
    'always_on_toggles': {
        'title_en': 'Always-on Toggles',
        'title_ja': '常時機能切り替え',
        'overview_en': (
            'This group centralizes every feature that can keep running in the background, such as handlers, timers, message-bus watchers, '
            'draw overlays, header buttons, hotkeys, keymap emulation, automatic restore, and live synchronization. Items that are not enabled stay idle and are not loaded just to draw the UI.'
        ),
        'overview_ja': (
            'ハンドラー、タイマー、メッセージバス監視、描画オーバーレイ、ヘッダーボタン、キーマップエミュレーション、自動復元、'
            'ライブ同期など、バックグラウンドで動き続ける可能性がある項目をまとめて切り替えるグループです。有効ではない項目はUI表示だけに留め、機能実行のためだけには読み込みません。'
        ),
        'usage_en': (
            'Leave items disabled for the lightest startup and idle state. Enable only the features you actively need. The state is saved immediately '
            'and restored after Blender restarts or another file is loaded.'
        ),
        'usage_ja': (
            '起動時と待機時を軽くしたい場合は無効のままにし、実際に必要な機能だけ有効化します。状態は即時保存され、Blender再起動後や別ファイル読込後にも復元されます。'
        ),
        'settings': (
            ('Auto Restore on File Load', '読込時に自動復元', 'Restores Smart Workspace profiles, launcher categories, saved N-panel settings, and runtime state after Blender starts or another .blend file is loaded.', 'Blender 起動後や別の .blend 読込後に、Smart Workspace のプロファイル、ランチャーカテゴリー、保存済みNパネル設定、実行状態を復元します。'),
            ('2D Pan View Follow Active Camera', '2Dパンビューアクティブカメラ追従', 'Allows open 2D Pan View sessions to follow the scene active camera while the session is open. Enable it only during 2D Pan View work that needs camera-follow behavior.', '2Dパンビューセッション中に、開いているビューをシーンのアクティブカメラへ追従させます。カメラ追従が必要な2Dパンビュー作業中だけ有効化します。'),
            ('2D Pan View HUD', '2Dパンビュー HUD', 'Shows the small live hint HUD in active 2D Pan View sessions. Disable it for clean recording or capture.', 'アクティブな2Dパンビューに小さな操作ヒントHUDを表示します。録画やキャプチャをクリーンにしたい場合は無効化します。'),
            ('Icon Viewer Console Header Button', 'アイコンビューアーコンソールヘッダーボタン', 'Adds the Icon Viewer button to the Python Console header. Disable it to remove the persistent Console header draw callback.', 'Python コンソール ヘッダーにアイコンビューアーボタンを追加します。無効化すると常駐するコンソールヘッダー描画コールバックを外します。'),
            ('Icon Viewer Preference Save Timer', 'アイコンビューアー自動保存タイマー', 'Keeps Icon Viewer preferences saved by a lightweight timer while Icon Viewer is loaded. Disable it to stop the timer and keep Icon Viewer idle unless used.', 'アイコンビューアー読み込み中に、設定を軽量タイマーで自動保存します。無効化するとタイマーを停止し、使用時以外は待機状態にします。'),
            ('Script Launcher Restore on File Load', 'スクリプトランチャー読込時復元', 'Keeps the Script Launcher file-load handler active so registered roots and the visible script tree are restored after opening another .blend file.', '別の .blend ファイル読込後に、登録ルートと表示用スクリプトツリーを復元するスクリプトランチャーのロードハンドラーを有効にします。'),
            ('Screencast Keys Overlay', 'Screencast Keys オーバーレイ', 'Starts or stops the live overlay that draws keyboard and mouse input over the viewport. Disable it after recording or demonstrations.', 'キーボードとマウス入力をビューポート上へ描画するライブオーバーレイを開始または停止します。録画や説明が終わったら無効化します。'),
            ('Enable Screencast Keys on Startup', '起動時に Screencast Keys を有効化', 'Automatically starts the Screencast Keys overlay when Blender starts. Use it only when every session needs input display.', 'Blender 起動時に Screencast Keys オーバーレイを自動開始します。毎回入力表示が必要な場合だけ有効化します。'),
            ('Screencast Keys Auto Save', 'Screencast Keys 自動保存', 'Enables Screencast Keys experimental auto-save behavior during modal operation. Keep it off unless the compatibility behavior is needed.', 'モーダル操作中に Screencast Keys の実験的な自動保存処理を有効化します。互換動作が必要な場合以外は無効を推奨します。'),
            ('Screencast Keys Default Hotkey', 'Screencast Keys 既定ホットキー', 'Registers the default Screencast Keys shortcut keymap. Disable it to remove the shortcut and avoid conflicts.', 'Screencast Keys の既定ショートカットキーマップを登録します。無効化するとショートカットを外し、競合を避けます。'),
            ('Synchronize Workspaces', 'ワークスペース同期', 'Synchronizes 3D View state between workspaces and enables the required message-bus watcher and file-load hook only while this item is enabled.', 'ワークスペース間の3Dビュー状態を同期し、この項目が有効な間だけ必要なメッセージバス監視とファイル読込フックを動かします。'),
            ('Keyboard Layout Emulation', 'Keyboard Layout Emulation', 'Applies or reverts keyboard layout emulation. Enabling remaps Blender keymaps; disabling reverts the emulation.', 'キーボード配列エミュレーションを適用または解除します。有効化すると Blender キーマップを再割り当てし、無効化すると解除します。'),
            ('Reapply from Keymap Preferences', 'キーマップ設定で自動再適用', 'Automatically reapplies keyboard layout emulation when pending keymaps are detected in Keymap preferences.', 'キーマップ設定で未適用のキーマップが検出された場合、自動的にエミュレーションを再適用します。'),
            ('Reapply on Reload / Restart', '再読込 / 再起動時に再適用', 'Reapplies keyboard layout emulation after Blender restarts or a new file is loaded.', 'Blender 再起動後や新しいファイル読込後にキーボード配列エミュレーションを再適用します。'),
            ('Detect Add-on Changes', 'アドオン変更を検出', 'Watches add-on list changes in Preferences and reapplies keyboard layout emulation when needed.', 'プリファレンス内のアドオン一覧変化を監視し、必要に応じてキーボード配列エミュレーションを再適用します。'),
            ('Keyboard Emulation Logging', 'キーボードエミュレーションログ', 'Writes Keyboard Layout Emulation diagnostic logs to the system console. Use it for troubleshooting only.', 'キーボード配列エミュレーションの診断ログをシステムコンソールへ出力します。トラブル調査時だけ使います。'),
            ('3D Viewport Pie Menus Hotkeys', '3Dビューのパイメニュー ホットキー', 'Registers the default hotkeys for bundled 3D Viewport pie menus. Disable it to remove the keymaps and avoid shortcut conflicts.', '同梱3Dビューのパイメニューの既定ホットキーを登録します。無効化するとキーマップを外し、ショートカット競合を避けます。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('ui_runtime.py', 'feature_toggle.py'),
    },
    'panview': {
        'title_en': '2D Pan View',
        'title_ja': '2D Pan View',
        'overview_en': (
            '2D Pan View opens a camera-focused View3D window designed for 2D pan and zoom work, texture checking, composition guides, '
            'safe areas, presets, and quick window management.'
        ),
        'overview_ja': (
            '2Dパンビューは、カメラ表示を中心にした View3D ウィンドウを開き、2D パン/ズーム、テクスチャ確認、構図ガイド、セーフエリア、プリセット、ウィンドウ管理を行うためのツールです。'
        ),
        'usage_en': (
            'Select a target camera, choose launch and window settings, then press Launch View. Use 2D navigation controls to pan, zoom, fit, '
            'or close the view. Save presets when you need to reuse the same guide and display setup.'
        ),
        'usage_ja': (
            'ターゲットカメラを選択し、起動方法とウィンドウ設定を決めてから「ビューを起動」を押します。2Dナビゲーション操作でパン、ズーム、フィット、'
            'ウィンドウ終了を行います。同じガイドや表示設定を再利用する場合はプリセットへ保存します。'
        ),
        'settings': (
            ('Target Camera', 'ターゲットカメラ', 'Camera used for the launched 2D view. Select the camera you want to inspect or frame.', '起動する2Dビューで使うカメラです。確認または構図調整したいカメラを選びます。'),
            ('Launch Mode', '起動モード', 'Chooses whether to create a new window or use another supported launch method.', '新規ウィンドウ作成など、どの方式で2Dビューを開くかを選びます。'),
            ('Reuse Existing Window', '既存ウィンドウを再利用', 'Reuses an already open 2D Pan View for the same camera instead of creating another window.', '同じカメラ用の2Dパンビューがすでに開いている場合、新しいウィンドウを作らず再利用します。'),
            ('Follow Active Camera', 'アクティブカメラに追従', 'Lets opened views follow the scene active camera when enabled from Always-on Toggles.', '常時機能切り替えで有効化している場合、開いているビューをシーンのアクティブカメラへ追従させます。'),
            ('Size Mode', 'サイズ方式', 'Chooses whether window size is based on parent fraction, exact pixels, or render resolution.', 'ウィンドウサイズを親ウィンドウ比率、ピクセル指定、レンダー解像度のどれで決めるか選びます。'),
            ('Window Fraction', 'ウィンドウ比率', 'Fraction of the parent window used when Size Mode is Fraction of Parent.', 'サイズ方式が親ウィンドウ比率の場合に使う比率です。'),
            ('Window Width', 'ウィンドウ幅', 'Exact width used when Size Mode is Pixels.', 'サイズ方式がピクセル指定の場合に使う正確な幅です。'),
            ('Window Height', 'ウィンドウ高さ', 'Exact height used when Size Mode is Pixels.', 'サイズ方式がピクセル指定の場合に使う正確な高さです。'),
            ('Position Mode', '配置方式', 'Chooses where the 2D view window is placed on screen.', '2Dビューウィンドウを画面上のどこに配置するか選びます。'),
            ('Hide UI (Full Area)', 'UIを非表示（全面化）', 'Hides headers and panels inside the 2D view window for a cleaner viewing area.', '2Dビューウィンドウ内のヘッダーやパネルを隠し、表示領域を広くします。'),
            ('Show HUD', 'HUD表示', 'Shows a small on-screen hint overlay inside the active 2D view.', 'アクティブな2Dビュー内に小さなヒントHUDを表示します。'),
            ('Show Overlays', 'オーバーレイ表示', 'Controls whether viewport overlays are visible in the 2D view.', '2Dビュー内でビューポートオーバーレイを表示するかを切り替えます。'),
            ('Show Wireframes', 'ワイヤーフレーム表示', 'Controls whether wireframes are visible over objects.', 'オブジェクト上にワイヤーフレームを表示するかを切り替えます。'),
            ('Wireframe Opacity', 'ワイヤー不透明度', 'Adjusts the visibility strength of wireframes.', 'ワイヤーフレームの見え方の強さを調整します。'),
            ('Show X-Ray', '透過表示', 'Enables X-Ray style visibility for checking silhouettes and overlapping geometry.', 'シルエットや重なった形状を確認しやすくする透過表示を有効化します。'),
            ('X-Ray Alpha', '透過表示の不透明度', 'Controls X-Ray transparency.', '透過表示の不透明度を調整します。'),
            ('Wire Color', 'ワイヤーカラー', 'Chooses how wire colors are determined.', 'ワイヤーカラーの決め方を選びます。'),
            ('Object Color', 'オブジェクトカラー', 'Chooses how object display colors are determined.', 'オブジェクト表示色の決め方を選びます。'),
            ('Background', '背景', 'Chooses the background color source or custom background color.', '背景色の参照元またはカスタム背景色を選びます。'),
            ('Object Outline', 'オブジェクトアウトライン', 'Shows an outline around the selected or target object when supported.', '対応している場合、選択中または対象オブジェクトのアウトラインを表示します。'),
            ('Safe Areas', 'セーフエリア', 'Shows camera safe areas for composition and title/action safety.', '構図やタイトル/アクション安全範囲を確認するためのカメラセーフエリアを表示します。'),
            ('Passepartout', 'パスパートゥ', 'Shows the darkened area outside the camera frame.', 'カメラフレーム外側の暗い領域を表示します。'),
            ('Passepartout Alpha', 'パスパートゥ不透明度', 'Adjusts how dark the outside-camera area appears.', 'カメラ外側の暗い領域の濃さを調整します。'),
            ('Composition Guide', '構図ガイド', 'Chooses guide overlays such as thirds, center, golden ratio, or diagonals.', '三分割、中央、黄金比、対角線などの構図ガイドを選びます。'),
            ('Lock Rotation', 'ビューの回転をロック', 'Locks rotation so the view behaves like a 2D pan workspace.', 'ビュー回転をロックし、2Dパン作業向けの動きにします。'),
            ('Navigation Mode', 'ナビゲーション方式', 'Chooses pan-only or pan-plus-zoom navigation.', 'パンのみ、またはパン＋ズームの操作方式を選びます。'),
            ('Pan Sensitivity', 'パン感度', 'Adjusts drag sensitivity for panning.', 'パン操作のドラッグ感度を調整します。'),
            ('Zoom Sensitivity', 'ズーム感度', 'Adjusts zoom speed.', 'ズーム速度を調整します。'),
            ('Invert Zoom', 'ズーム反転', 'Reverses zoom direction.', 'ズーム方向を反転します。'),
            ('Lock Zoom', 'ズームをロック', 'Prevents zoom changes during navigation.', 'ナビゲーション中のズーム変更を防ぎます。'),
            ('Preset Slots', 'プリセットスロット', 'Stores named combinations of view, guide, color, and navigation settings and restores them from CONFIG storage after restart or file load.', 'ビュー、ガイド、カラー、ナビゲーション設定の組み合わせを名前付きで保存し、再起動後やファイル読込後も CONFIG 保存から復元します。'),
            ('Apply to Open Views', '開いているビューへ適用', 'Pushes the loaded preset or current settings to already tracked 2D view windows.', '読み込んだプリセットまたは現在設定を、追跡中の開いている2Dビューへ反映します。'),
            ('Window Manager', 'ウィンドウ管理', 'Lists tracked 2D view windows and provides refresh, focus, update, close, and close-all operations.', '追跡中の2Dビューウィンドウを一覧表示し、更新、フォーカス、ビュー更新、閉じる、全て閉じる操作を行います。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime/panview.py',),
    },
    'icon_viewer': {
        'settings': (
            ('Show Matcap Icons', 'Matcap アイコン表示', 'Includes material preview matcap icons in the popup list.', 'ポップアップ一覧に Matcap 用アイコンを含めます。'),
            ('Show Brush Icons', 'ブラシアイコン表示', 'Includes brush icons in the popup list.', 'ポップアップ一覧にブラシアイコンを含めます。'),
            ('Show Colorset Icons', 'カラーセットアイコン表示', 'Includes color-set icons in the popup list.', 'ポップアップ一覧にカラーセットアイコンを含めます。'),
            ('Show Event Icons', 'イベントアイコン表示', 'Includes keyboard and mouse event icons in the popup list.', 'ポップアップ一覧にキーボードやマウスイベント系アイコンを含めます。'),
            ('Show History', '履歴表示', 'Shows recently selected icon IDs for quick reuse.', '最近選択したアイコンIDを表示し、再利用しやすくします。'),
            ('Auto Focus Filter', 'フィルター自動フォーカス', 'Moves keyboard focus to the filter field when the icon popup opens.', 'アイコンポップアップを開いた時にフィルター欄へ自動フォーカスします。'),
            ('Copy on Select', '選択時にコピー', 'Copies the icon identifier when an icon is selected.', 'アイコンを選択した時にアイコン識別子をコピーします。'),
            ('Close on Select', '選択時に閉じる', 'Closes the popup after an icon is selected.', 'アイコン選択後にポップアップを閉じます。'),
            ('Panel Filter', 'パネルフィルター', 'Filters icons shown in the Smart Tools panel area.', 'Smart Tools パネル領域に表示するアイコンを絞り込みます。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('icon_viewer',),
    },
    'keyboard_layout_emulation': {
        'settings': (
            ('Input Layout', '入力配列', 'Physical or language keyboard layout that your system is currently using.', '現在システムで使っている物理配列または言語キーボード配列です。'),
            ('Target Layout', '変換先配列', 'Shortcut layout Blender should behave like after emulation is applied.', 'エミュレーション適用後に Blender がどのショートカット配列として動くかを指定します。'),
            ('Apply Emulation', 'エミュレーション適用', 'Applies the selected keyboard layout remapping to Blender keymaps.', '選択したキーボード配列の再割り当てを Blender キーマップへ適用します。'),
            ('Revert Emulation', 'エミュレーション解除', 'Restores keymaps changed by the emulation.', 'エミュレーションで変更したキーマップを元に戻します。'),
            ('Reapply from Keymap Preferences', 'キーマップ設定で自動再適用', 'Reapplies remapping when the Keymap preferences panel updates and pending keymaps are detected.', 'キーマップ設定パネル更新時に未適用キーマップが検出された場合、再割り当てを再適用します。'),
            ('Reapply on Reload / Restart', '再読込 / 再起動時に再適用', 'Reapplies layout emulation after Blender restarts or another file is loaded.', 'Blender 再起動後または別ファイル読込後に配列エミュレーションを再適用します。'),
            ('Detect Add-on Changes', 'アドオン変更を検出', 'Detects add-on registration changes that may add new keymaps and reapplies emulation when needed.', '新しいキーマップを追加する可能性があるアドオン登録変更を検出し、必要に応じて再適用します。'),
            ('Logging', 'ログ出力', 'Writes diagnostic information for troubleshooting keyboard layout remapping.', 'キーボード配列再割り当てのトラブル調査用情報を出力します。'),
            ('Import / Export', 'インポート / エクスポート', 'Saves or loads layout/emulation data so the same setup can be reused.', '配列やエミュレーション設定を保存または読み込み、同じ構成を再利用します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('keyboard_layout_emulation',),
    },
    'screencast_keys': {
        'settings': (
            ('Overlay Enable', 'オーバーレイ有効化', 'Starts or stops drawing pressed keys, mouse input, and optional operator information over the viewport. Use Smart Workspace > Always-on Toggles to enable or disable it.', '押下キー、マウス入力、必要に応じてオペレーター情報をビューポート上へ描画する処理を開始または停止します。有効 / 無効は Smart Workspace > 常時機能切り替えで操作します。'),
            ('Enable on Startup', '起動時に有効化', 'Automatically starts Screencast Keys when Blender starts.', 'Blender 起動時に Screencast Keys を自動開始します。'),
            ('Origin', '原点', 'Controls where the input display is placed on screen.', '入力表示を画面上のどこに配置するかを指定します。'),
            ('Text Size', '文字サイズ', 'Changes the size of displayed key and mouse labels.', '表示されるキーやマウスラベルの文字サイズを変更します。'),
            ('Text Color', '文字色', 'Changes the displayed text color.', '表示テキストの色を変更します。'),
            ('Background Color', '背景色', 'Changes the background behind displayed inputs.', '入力表示の背後に出る背景色を変更します。'),
            ('Background Alpha', '背景透明度', 'Controls the transparency of the input display background.', '入力表示背景の透明度を調整します。'),
            ('Mouse Display', 'マウス表示', 'Shows mouse buttons, wheel events, or custom mouse images depending on configuration.', '設定に応じてマウスボタン、ホイール操作、カスタムマウス画像を表示します。'),
            ('History', '履歴', 'Controls how many recent key events are retained and shown.', '最近のキー入力を何件保持して表示するかを調整します。'),
            ('Show Last Operator', '最後のオペレーター表示', 'Shows the last executed Blender operator when enabled.', '有効時に最後に実行された Blender オペレーターを表示します。'),
            ('Auto Save', '自動保存', 'Experimental behavior for saving while modal operations are active. Keep it disabled unless the workflow specifically requires it.', 'モーダル操作中の保存に関する実験的機能です。ワークフロー上必要な場合以外は無効を推奨します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('screencast_keys',),
    },
    'script_launcher': {
        'settings': (
            ('Script Root Folders', 'スクリプトルートフォルダー', 'Folders scanned for Python scripts that can be launched from Smart Tools.', 'Smart Tools から起動できる Python スクリプトを探すフォルダーです。'),
            ('Add Folder', 'フォルダー追加', 'Adds a folder to the script search list.', 'スクリプト検索対象へフォルダーを追加します。'),
            ('Remove Folder', 'フォルダー削除', 'Removes a folder from the script search list. It does not delete files from disk.', 'スクリプト検索対象からフォルダーを外します。ディスク上のファイルは削除しません。'),
            ('Refresh Script List', 'スクリプト一覧更新', 'Re-scans configured folders for available scripts.', '設定済みフォルダーを再走査して利用可能なスクリプト一覧を更新します。'),
            ('Run Script', 'スクリプト実行', 'Runs the selected Python script. Confirm the script source before executing it.', '選択した Python スクリプトを実行します。実行前にスクリプトの内容と出所を確認してください。'),
            ('Legacy Category', '旧カテゴリ', 'Keeps compatibility with the original Script Launcher panel category when needed.', '必要な場合に元のスクリプトランチャーパネルカテゴリーとの互換性を維持します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('script_launcher',),
    },
    'synchronize_workspaces': {
        'settings': (
            ('Synchronize Workspaces', 'ワークスペース同期', 'Master switch for copying 3D View state between workspaces.', 'ワークスペース間で3Dビュー状態をコピーするためのメイン切り替えです。'),
            ('Workspace Inclusion', '同期対象ワークスペース', 'Controls which workspaces participate in synchronization.', 'どのワークスペースを同期対象にするかを指定します。'),
            ('View Orientation', 'ビュー方向', 'Copies the view orientation so workspaces keep the same viewing direction.', 'ビュー方向をコピーし、ワークスペースを切り替えても同じ視線方向を保ちます。'),
            ('View Distance', 'ビュー距離', 'Copies the view distance or zoom-like framing where supported.', '対応している場合、ビュー距離やズーム相当のフレーミングをコピーします。'),
            ('View Location', 'ビュー位置', 'Copies the view center/location.', 'ビュー中心または位置をコピーします。'),
            ('Perspective / Camera State', '透視/カメラ状態', 'Copies whether the view is perspective, orthographic, or camera view when supported.', '対応している場合、透視表示、正投影、カメラビューの状態をコピーします。'),
            ('Overlay Synchronization', 'オーバーレイ同期', 'Copies selected overlay and viewport display options when enabled.', '有効時に選択されたオーバーレイやビューポート表示オプションをコピーします。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('synchronize_workspaces',),
    },
    'viewport_pie_menus': {
        'settings': (
            ('Pie Menu Keymaps', 'パイメニューキーマップ', 'Assigns radial menu calls to shortcuts in the correct Blender keymap section.', 'ラジアルメニュー呼び出しを、対応する Blender キーマップセクションのショートカットへ割り当てます。'),
            ('View Pie', 'ビュー用パイ', 'Provides camera, perspective, orthographic, and view navigation commands.', 'カメラ、透視/正投影、ビュー移動などのコマンドを提供します。'),
            ('Selection Pie', '選択用パイ', 'Provides selection-related commands for the active context.', '現在のコンテキストに応じた選択関連コマンドを提供します。'),
            ('Object Pie', 'オブジェクト用パイ', 'Provides object add, display, parenting, origin, transform, and relationship operations.', 'オブジェクト追加、表示、親子付け、原点、トランスフォーム、関係操作を提供します。'),
            ('Mesh Edit Pies', 'メッシュ編集パイ', 'Provides mesh delete, merge, flatten, and related edit-mode actions.', 'メッシュ削除、結合、平坦化などの編集モード操作を提供します。'),
            ('Editor Switch Pies', 'エディター切替パイ', 'Provides quick switching between Blender editor types and area operations.', 'Blender エディター種類やエリア操作を素早く切り替える機能を提供します。'),
            ('Built-in Pie Tweaks', '標準パイ調整', 'Optional tweaks for Blender built-in pie menus. Use carefully to avoid shortcut conflicts.', 'Blender 標準パイメニューの任意調整です。ショートカット競合を避けるため慎重に使います。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('viewport_pie_menus',),
    },
}

# Fill overview/usage for integrated tools from the lightweight metadata catalog.
for _alias, _meta in TOOL_META.items():
    _doc = HELP_DOCS.setdefault(_alias, {})
    _doc.setdefault('title_en', str(_meta.get('display_name_en') or display_name(_alias, japanese=False) or _alias))
    _doc.setdefault('title_ja', str(_meta.get('display_name_ja') or display_name(_alias, japanese=True) or _doc['title_en']))
    _doc.setdefault('overview_en', str(_meta.get('overview_en') or 'This bundled tool is available from Smart Workspace.'))
    _doc.setdefault('overview_ja', str(_meta.get('overview_ja') or 'この同梱ツールは Smart Workspace から利用できます。'))
    _doc.setdefault('usage_en', str(_meta.get('usage_en') or 'Open the tool panel, adjust settings, then run the desired command.'))
    _doc.setdefault('usage_ja', str(_meta.get('usage_ja') or 'ツールパネルを開き、設定を調整してから目的のコマンドを実行します。'))
    _doc.setdefault('settings', _COMMON_HELP_SETTINGS)
    _doc.setdefault('scan_roots', (_alias,))

# Dedicated N-panel group help.  This block stays inside the lazy help module,
# so none of these long texts are imported during Blender startup or normal UI redraw.
HELP_DOCS.update({
    'workspace_manager': {
        'title_en': 'Workspace Manager',
        'title_ja': 'ワークスペース管理',
        'overview_en': 'Saves the layout and editor settings of workspaces to files as named save states, and loads them back into the workspace you have open. No new workspace tab is created when saving or loading.',
        'overview_ja': 'ワークスペースのレイアウトとエディターの設定を、名前を付けたセーブステートとしてファイルに保存し、今開いているワークスペースへ読み込みます。保存でも読み込みでも、新しいワークスペースのタブは作りません。',
        'usage_en': 'Save the current workspace or save it under a new name, select a save state in the list, then load it. The load dialog lets you choose which information to load. When layout information is loaded, the saved split layout is rebuilt from the saved coordinates and each editor is assigned back to the same position. Exact resizing of the area splits is outside the safe range of Blender 5.1, so sizes can differ slightly.',
        'usage_ja': '今のワークスペースを保存するか、新しい名前で保存し、一覧でセーブステートを選んで読み込みます。読み込みのダイアログで、読み込む情報を選べます。レイアウトの情報を読み込むと、保存した座標から分割を作り直し、それぞれのエディターを同じ位置へ割り当てます。エリアの分割の大きさを厳密に変える操作は Blender 5.1 では安全に行えないので、大きさは少し変わることがあります。',
        'settings': _COMMON_HELP_SETTINGS,
        'scan_roots': ('workspace_manager.py',),
    },
    'workspace_launcher': {
        'title_en': 'Workspace & Launcher',
        'title_ja': 'ワークスペースとランチャー',
        'overview_en': 'Controls workspace profiles, the Smart Workspace quick launcher, launcher popup layout, recent-tab display, and pseudo-floating N-panel window behavior.',
        'overview_ja': 'ワークスペースプロファイル、Smart Workspace クイックランチャー、ランチャーポップアップの表示形式、最近使ったタブ表示、疑似フローティングNパネルの挙動を管理します。',
        'usage_en': 'Choose the workspace profile to edit, adjust launcher width and columns, then use launcher entries to switch Sidebar tabs. Ctrl-click opens supported entries in a separate pseudo-floating View3D Sidebar window.',
        'usage_ja': '編集するワークスペースプロファイルを選び、ランチャー幅と列数を調整してから、ランチャー項目でサイドバータブを切り替えます。対応項目は Ctrl＋クリックで疑似フローティング View3D サイドバーウィンドウとして開けます。',
        'settings': (
            ('Workspace Selector', 'ワークスペース選択', 'Chooses which workspace profile is edited or copied.', '編集またはコピーするワークスペースプロファイルを選びます。'),
            ('Paste Settings to Current Workspace', '現在のワークスペースに設定をペースト', 'Copies the selected workspace profile into the active workspace.', '選択中のワークスペースプロファイルを現在のワークスペースへコピーします。'),
            ('Quick Launcher Width', 'クイックランチャー幅', 'Sets the launcher popup width.', 'ランチャーポップアップの幅を設定します。'),
            ('Quick Launcher Columns', 'クイックランチャー列数', 'Sets how many columns the launcher popup uses.', 'ランチャーポップアップで使う列数を設定します。'),
            ('Use Tab Layout in Popup', 'ポップアップ内タブ表示', 'Switches the launcher between tabbed and simple-list layouts.', 'ランチャーをタブ形式または単純一覧形式へ切り替えます。'),
            ('Show Recent Tabs', '最近使ったタブを表示', 'Shows recently opened Sidebar tabs in the launcher.', 'ランチャー内に最近開いたサイドバータブを表示します。'),
            ('Floating Panel Width', 'フローティングパネル幅', 'Default width for pseudo-floating Sidebar windows.', '疑似フローティングサイドバーウィンドウの既定幅です。'),
            ('Floating Panel Height', 'フローティングパネル高さ', 'Default height for pseudo-floating Sidebar windows.', '疑似フローティングサイドバーウィンドウの既定高さです。'),
            ('Open Mode', '開き方', 'Chooses where and how a pseudo-floating window is placed.', '疑似フローティングウィンドウをどこにどの方式で開くかを選びます。'),
            ('Always On Top', '常に前面', 'Keeps the pseudo-floating window above other windows when supported by the OS.', 'OSが対応している場合、疑似フローティングウィンドウを他ウィンドウより前面に維持します。'),
            ('Remember Position', '位置を記憶', 'Stores the last pseudo-floating window position and reuses it later.', '疑似フローティングウィンドウの前回位置を保存し、次回以降に再利用します。'),
            ('Monitor Size', 'サイズ監視', 'Stores size changes made while the pseudo-floating window is open.', '疑似フローティングウィンドウを開いている間のサイズ変更を保存します。'),
            ('Monitor Settings', '設定監視', 'Keeps runtime window options applied while the pseudo-floating window is open.', '疑似フローティングウィンドウを開いている間、実行時ウィンドウ設定を維持します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime',),
    },
    'categories': {
        'title_en': 'Categories',
        'title_ja': 'カテゴリー',
        'overview_en': 'Edits Smart Workspace launcher categories. Categories are user-defined collections of detected Sidebar tabs or panel entries.',
        'overview_ja': 'Smart Workspace ランチャーのカテゴリーを編集します。カテゴリーは、検出済みサイドバータブまたはパネル項目をまとめるユーザー定義の集合です。',
        'usage_en': 'Create a category, rename it, select a detected tab or panel, then add it to the category. Reorder or remove entries to keep the launcher compact.',
        'usage_ja': 'カテゴリーを作成して名前を付け、検出済みタブまたはパネルを選択してカテゴリーへ追加します。項目は並べ替えや削除で整理できます。',
        'settings': (
            ('Create Category', 'カテゴリー新規作成', 'Adds a new launcher category.', '新しいランチャーカテゴリーを追加します。'),
            ('Category Name', 'カテゴリー名', 'Renames the selected category.', '選択中カテゴリーの名前を変更します。'),
            ('Category Contents', 'カテゴリー内容', 'Lists tabs or panel entries assigned to the selected category.', '選択中カテゴリーに登録されたタブまたはパネル項目を表示します。'),
            ('Add Selected to Category', '選択したタブをカテゴリーへ追加', 'Adds the selected detected tab or panel entry to the active category.', '選択中の検出済みタブまたはパネル項目をアクティブカテゴリーへ追加します。'),
            ('Remove', '削除', 'Removes the selected launcher entry from the category without deleting the original panel or add-on.', '元のパネルやアドオンを削除せず、選択中のランチャー項目だけをカテゴリーから外します。'),
            ('Move Up / Move Down', '上へ / 下へ', 'Changes the display order of categories or entries.', 'カテゴリーまたは項目の表示順を変更します。'),
            ('Entry Settings', '項目設定', 'Opens per-entry pseudo-floating panel options when available.', '利用できる場合、項目ごとの疑似フローティングパネル設定を開きます。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime',),
    },
    'panel_pool': {
        'title_en': 'Panel Pool',
        'title_ja': 'パネル一覧',
        'overview_en': 'Lists every detected Sidebar tab or individual panel that Smart Workspace can use as launcher sources.',
        'overview_ja': 'Smart Workspace がランチャー元として利用できる検出済みサイドバータブ、または個別パネルを一覧表示します。',
        'usage_en': 'Switch between tab and panel mode, refresh detection after enabling other add-ons, rename detected entries if needed, then add selected items to categories.',
        'usage_ja': 'タブ/パネルの表示モードを選び、他アドオンを有効化した後は検出を更新します。必要に応じて検出項目名を変更し、選択項目をカテゴリーへ追加します。',
        'settings': (
            ('Pool Mode', '一覧モード', 'Switches between detected Sidebar tabs and panel-level entries.', '検出済みサイドバータブとパネル単位項目の表示を切り替えます。'),
            ('All Detected Tabs', '全タブ一覧', 'Lists detected View3D Sidebar categories from registered panels, delayed scans, and the active Sidebar category.', '登録済みパネル、遅延走査、現在のアクティブサイドバーカテゴリーから検出した View3D サイドバータブを表示します。'),
            ('Panel Pool', 'パネル一覧', 'Lists individual panels when panel-level launching or organization is available.', 'パネル単位の起動や整理が利用できる場合に、個別パネルを表示します。'),
            ('Refresh', '更新', 'Runs detection again without forcing every bundled tool to load.', '同梱ツールを強制的に全読み込みせず、検出だけを再実行します。'),
            ('Cleanup Unused', '未使用整理', 'Removes stale references that no longer correspond to an available tab or panel.', '現在利用できないタブやパネルへの古い参照を整理します。'),
            ('Rename Tab', 'タブ名変更', 'Overrides the display name for the selected detected tab.', '選択中の検出済みタブの表示名を上書きします。'),
            ('Apply', '適用', 'Applies pending detected-tab display changes.', '検出タブ表示に関する変更を適用します。'),
            ('Apply Rename & Order', 'Nパネルにリネームと並び順を適用', 'Gives the real N-panel tabs the names and order of this list. Blender\'s own Item tab keeps its name and place. With Auto Restore on File Load, the layout comes back at the next start; otherwise press this again.', '実際の N パネルのタブを、この一覧の名前と並び順にします。Blender 本体の「アイテム」のタブは変わりません。「読込時に自動復元」が有効なら次の起動でも同じになり、無効ならもう一度押します。'),
            ('Reset N-panel', 'Nパネルを元に戻す/リセット', 'Puts the N-panel tab names and order back and removes this workspace\'s tab pins. The names in the list stay for the launcher.', 'N パネルのタブの名前と並び順を元に戻し、このワークスペースのタブのピンを外します。一覧に付けた名前はランチャー用に残ります。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime',),
    },
    'smart_tools_settings': {
        'title_en': 'Settings',
        'title_ja': '設定',
        'overview_en': 'Contains runtime-level Smart Workspace options that are not part of a single tool, such as project storage, and shortcut reference IDs.',
        'overview_ja': 'プロジェクト内保存、ショートカット用IDなど、単一ツールに属さない Smart Workspace 実行設定をまとめます。',
        'usage_en': 'Keep defaults unless you need per-project Smart Workspace configuration or want to assign launcher/hotbox operators in Blender keymaps. Settings are saved to CONFIG immediately. To add a shortcut, open Preferences > Keymap, add a new shortcut entry, paste the ID, and pick a key and the editor area that matches your workflow.',
        'usage_ja': 'プロジェクトごとの Smart Workspace 構成や、ランチャー/Hotbox のキーマップ登録が必要な場合だけ変更します。設定は CONFIG へ即時保存されます。ショートカットに登録するには、プリファレンス > キーマップ を開き、新しいショートカットを追加して ID を貼り付け、作業に合うキーとエディターの領域を設定します。',
        'settings': (
            ('Store Config in .blend', '.blend に設定保存', 'Also stores Smart Workspace configuration in the current .blend file.', 'Smart Workspace 設定を現在の .blend ファイル内にも保存します。'),
            ('Prefer .blend Config on Load', '読込時は .blend 優先', 'Loads project-specific Smart Workspace configuration before CONFIG configuration when present.', '存在する場合、CONFIG 設定より先に .blend 内のプロジェクト専用設定を読み込みます。'),
            ('Launcher ID', 'ランチャーID', 'Operator ID for assigning the Smart Workspace launcher to a keymap.', 'Smart Workspace ランチャーをキーマップに登録するためのオペレーターIDです。'),
            ('Hotbox ID', 'Hotbox ID', 'Operator ID for assigning the Hotbox-style popup to a keymap.', 'Hotbox形式ポップアップをキーマップに登録するためのオペレーターIDです。'),
            ('N-panel Only Settings', 'Nパネル集約設定', 'Editable suite settings are shown in the N-panel; Add-on Preferences are not used as the settings UI.', '編集可能な統合設定はNパネルに表示され、アドオンプリファレンスは設定UIとして使用しません。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('preferences.py', 'runtime'),
    },
    'presets_io': {
        'title_en': 'IO',
        'title_ja': '入出力',
        'overview_en': 'Saves and restores Smart Workspace presets and exports or imports configuration JSON files. Automatic preset storage remains inside CONFIG/Smart_Workspace_Suite.',
        'overview_ja': 'Smart Workspace の設定JSONをエクスポート/インポートします。ユーザー指定の外部ファイルへ保存し、必要な時に読み込みます。',
        'usage_en': 'Use Save Preset for the current launcher/workspace setup, Load Preset to restore a saved preset, Export for a user-selected backup file, and Import to bring a backup file back into Smart Workspace.',
        'usage_ja': '現在のランチャー/ワークスペース構成を外部保存する場合はエクスポート、保存済み構成を戻す場合はインポートを使います。',
        'settings': (
            ('Export Settings', '設定を書き出し', 'Writes configuration to a user-selected external JSON file.', '設定をユーザー指定の外部JSONファイルへ書き出します。'),
            ('Import Settings', '設定を読み込み', 'Reads configuration from a user-selected external JSON file.', 'ユーザー指定の外部JSONファイルから設定を読み込みます。'),
            ('Persistent Preset Storage', 'プリセット永続保存', 'Automatically managed preset files are stored under CONFIG/Smart_Workspace_Suite.', '自動管理されるプリセットファイルは CONFIG/Smart_Workspace_Suite 配下に保存されます。'),
            ('Manual Export / Import Paths', '手動エクスポート / インポート先', 'Manual external file paths remain user-selected and are not forced into CONFIG.', '手動の外部ファイル保存先/読み込み元はユーザー指定のままで、CONFIG へ強制しません。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime', 'storage.py', 'persistence.py'),
    },
    'local_ui_toggle': {
        'title_en': 'Viewport UI Toggle',
        'title_ja': 'ビューポートUI切替',
        'overview_en': 'Shows or hides the toolbar, Sidebar, and header for only the current 3D View area. It does not change other workspaces or other 3D View editors.',
        'overview_ja': '現在の3Dビュー領域だけを対象に、ツールバー、サイドバー、ヘッダーをまとめて表示または非表示にします。他のワークスペースや他の3Dビューエディターは変更しません。',
        'usage_en': 'Use the button when you want a cleaner local viewport. After hiding them, press N to show only the Sidebar and click the same button to bring all three back.',
        'usage_ja': '作業中のビューポートをすっきり表示したい時にボタンを押します。隠した後は、N キーでサイドバーだけを出し、同じ場所のボタンを押すと 3 つとも戻ります。',
        'settings': (
            ('Toggle Local UI Elements', 'ローカルUI表示切替', 'Toggles the toolbar, Sidebar, and header for the active 3D View area.', 'アクティブな3Dビュー領域のツールバー、サイドバー、ヘッダーをまとめて切り替えます。'),
            ('Local Area Only', '現在の領域のみ', 'The operation affects only the current 3D View area, not all screens.', '操作対象は現在の3Dビュー領域だけで、すべての画面を一括変更するものではありません。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime/ui_operators.py',),
    },
    'viewport_optimization': {
        'title_en': 'Viewport Optimization',
        'title_ja': 'ビューポート最適化',
        'overview_en': 'Smart Viewport Optimizer Plus temporarily applies viewport, overlay, object, modifier, particle, preference, and navigation settings while its optimizer toggle is ON, and restores the maintained baseline when the toggle is turned OFF.',
        'overview_ja': 'Smart Viewport Optimizer Plus を Smart Workspace Suite 内へ統合したセクションです。最適化トグルがONの間だけ、ビューポート、オーバーレイ、オブジェクト、モディファイア、パーティクル、プリファレンス、ナビゲーション関連の設定を一時適用し、OFFにすると保持中の基準状態へ復元します。',
        'usage_en': 'Choose a preset or detailed target values; the Optimized slot applies them. Switch back with Standard or the header icon. Use the header popover for detailed viewport optimization settings. Detailed settings reach the viewport immediately, and the settings file is written only while Auto-save Settings is ON. Settings apply only while the optimizer toggle is ON; turning it OFF restores the maintained baseline state. Detailed settings are stored per workspace, and the paste button copies the source workspace settings into the open workspace. The recommended keymap location is Preferences > Keymap > 3D View > 3D View (Global). Warmup timers are kept stopped.',
        'usage_ja': 'プリセットまたは詳細な対象値を選ぶと「最適化」スロットで適用されます。「標準」または3Dビューヘッダーのアイコンで元に戻せます。ヘッダーのポップオーバーから詳細設定を確認できます。詳細設定はすぐビューポートへ反映され、設定ファイルへの書き込みは「設定の自動保存」がオンの間だけ行います。設定が効くのは最適化のスイッチがオンの間だけで、オフにすると基準の状態へ戻ります。詳細設定はワークスペースごとに保存され、ペーストのボタンでコピー元のワークスペースの設定を今のワークスペースへコピーできます。ショートカットに登録する時のおすすめの場所は プリファレンス > キーマップ > 3Dビュー > 3Dビュー（グローバル）です。ウォームアップのタイマーは止めたままです。',
        'settings': (
            ('Optimizer Toggle', '最適化トグル', 'Switches between Standard and Optimized. Switching to Standard returns the display, viewport-disable, selectable, modifier and constraint values of each object, the selection, and Blender preferences such as Undo to their values from before optimization. Shading and overlays take the values of the Standard slot.', '「標準」と「最適化」を切り替えます。「標準」にすると、物ごとの表示方法・ビューポートの無効・選択可否・モディファイア・コンストレイントと、選択、アンドゥなどのプリファレンスが最適化の前の値に戻ります。シェーディングとオーバーレイは「標準」スロットの値になります。'),
            ('Preset Section', 'プリセットセクション', 'Selects and saves workspace-oriented optimization presets. Performance keeps meshes visible as flat solids, without overlays and modifiers. Empties, armatures and similar helper objects are hidden by its type filters and overlay setting until you return to Standard.', 'ワークスペース向けの最適化プリセットを選択・保存します。「パフォーマンス」でもメッシュは消えず、オーバーレイとモディファイアなしの平たいソリッドで表示されます。空やアーマチュアなどの補助的な物は、種類フィルターとオーバーレイ OFF で隠れ、「標準」に戻すと表示されます。'),
            ('Baseline Section', '基準状態セクション', 'Saves or loads the baseline state used as the restore target.', '復元先として使う基準状態を保存または読み込みます。'),
            ('Detailed Settings', '詳細設定', 'Shows the same detailed controls as the original Smart Viewport Optimizer Plus panel.', '元の Smart Viewport Optimizer Plus パネルと同じ詳細項目を表示します。'),
            ('Storage Folder', '保存フォルダー', 'Automatically generated optimizer backups, presets, baseline files, and override files are stored under Blender 5.1 config/Smart_WorkSpace_Suite/smart_viewport_optimizer_plus.', '自動生成される最適化バックアップ、プリセット、基準状態、上書きファイルは Blender 5.1 の config/Smart_WorkSpace_Suite/smart_viewport_optimizer_plus 配下に保存されます。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('smart_viewport_optimizer_plus/__init__.py',),
    },
    'workspace_step_reorder': {
        'title_en': 'Workspace Step Reorder',
        'title_ja': 'ワークスペース順序移動',
        "overview_en": "Adds one-step workspace tab movement commands to Blender\'s workspace tab right-click menu. It does not create scene data or modify objects; it only changes the display order of workspace tabs while enabled.",
        'overview_ja': 'Blenderのワークスペースタブ右クリックメニューに、ワークスペースを1つずつ前後へ移動するコマンドを追加します。シーンデータやオブジェクトは作成せず、有効時にワークスペースタブの表示順だけを変更します。',
        "usage_en": "Enable the tool, right-click a workspace tab, then use Move Forward or Move Backward to move the clicked workspace by exactly one position. Disable the tool when you want the standard Blender workspace menu with no added commands.",
        'usage_ja': 'ツールを有効にし、ワークスペースタブを右クリックして「前側に移動」または「後ろ側に移動」を選ぶと、クリックしたワークスペースを1つ分だけ移動できます。追加項目のないBlender標準メニューに戻したい場合は無効にします。',
        'settings': (
            ('Enable', '有効', 'Adds Move Forward and Move Backward to the workspace tab right-click menu. This setting is saved immediately and remains after Blender restarts or another scene is opened.', 'ワークスペースタブの右クリックメニューに「前側に移動」と「後ろ側に移動」を追加します。設定は即時保存され、Blender再起動後や別シーンを開いた後も維持されます。'),
            ("Disable", "無効", "Removes the added workspace step movement commands and leaves Blender\'s standard workspace menu unchanged.", '追加されたワークスペース1段階移動コマンドを外し、Blender標準のワークスペースメニューを変更しない状態に戻します。'),
            ('Move Forward', '前側に移動', 'Moves the clicked workspace one position toward the front of the workspace tabs without sending it all the way to the front.', 'クリックしたワークスペースを、最前面まで送らず、ワークスペースタブの並びで1つだけ前側へ移動します。'),
            ('Move Backward', '後ろ側に移動', 'Moves the clicked workspace one position toward the back of the workspace tabs without sending it all the way to the back.', 'クリックしたワークスペースを、最後方まで送らず、ワークスペースタブの並びで1つだけ後ろ側へ移動します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('workspace_step_reorder',),
    },
    'integrated_tools': {
        'title_en': 'Other Tools',
        'title_ja': 'その他ツール',
        'overview_en': 'Groups the retained utility panels: 2D Pan View, Viewport UI Toggle, Workspace Step Reorder, Synchronize Workspaces, and Floating Window Lock.',
        'overview_ja': '維持対象の補助機能である2Dパンビュー、ビューポートUI切替、ワークスペース順序移動、ワークスペース同期、フローティングウィンドウ固定をまとめたセクションです。',
        'usage_en': 'Open only the native child panel you need. Each child keeps its own saved open/closed state and exposes the complete retained controls for that utility. Synchronize Workspaces copies the state after the new workspace screen becomes stable. Floating Window Lock keeps detached window editor contents unchanged while switching workspace tabs; when disabled it has zero runtime load, and when enabled it restores only after the workspace layout is stable.',
        'usage_ja': '必要な子パネルだけを開いて使用します。各子パネルは個別の開閉状態を保存します。ワークスペース同期は、切り替え先のスクリーンが安定してから 3D ビューの状態を同期します。フローティングウィンドウ固定は、ワークスペースを切り替えても切り離したウィンドウの中身を保ちます。無効の時は負荷がなく、有効の時もレイアウトが安定してから復元します。',
        'settings': (
            ('2D Pan View', '2Dパンビュー', 'Opens and manages 2D navigation views and their presets.', '2Dナビゲーションビューとプリセットを開いて管理します。'),
            ('Viewport UI Toggle', 'ビューポートUI切替', 'Shows or hides local toolbar, Sidebar, and header UI in the active 3D View.', 'アクティブな3Dビューのツールバー、サイドバー、ヘッダーを表示または非表示にします。'),
            ('Workspace Step Reorder', 'ワークスペース順序移動', 'Moves workspace tabs one position at a time.', 'ワークスペースタブを1段階ずつ移動します。'),
            ('Synchronize Workspaces', 'ワークスペース同期', 'Synchronizes retained 3D View state between selected workspaces.', '選択したワークスペース間で維持対象の3Dビュー状態を同期します。'),
            ('Floating Window Lock', 'フローティングウィンドウ固定', 'Controls the retained floating-window lock behavior.', '維持対象のフローティングウィンドウ固定動作を制御します。'),
        ) + _COMMON_HELP_SETTINGS,
        'scan_roots': ('runtime/ui_operators.py', 'runtime/panview.py', 'workspace_step_reorder', 'synchronize_workspaces', 'floating_window_lock.py'),
    },
})

ALIASES = {
    'smart_workspace': 'runtime',
    'workspace': 'runtime',
    'runtime': 'runtime',
    'workspace_launcher': 'workspace_launcher',
    'launcher': 'workspace_launcher',
    'quick_launcher': 'workspace_launcher',
    'categories': 'categories',
    'category': 'categories',
    'panel_pool': 'panel_pool',
    'pool': 'panel_pool',
    'all_tabs': 'panel_pool',
    'smart_tools_settings': 'smart_tools_settings',
    'runtime_settings': 'smart_tools_settings',
    'settings_runtime': 'smart_tools_settings',
    'presets_io': 'presets_io',
    'io': 'presets_io',
    'presets': 'presets_io',
    'viewport_optimization': 'viewport_optimization',
    'viewport_optimizer': 'viewport_optimization',
    'view_optimizer': 'viewport_optimization',
    'smart_viewport_optimizer_plus': 'viewport_optimization',
    'integrated_tools': 'integrated_tools',
    'integrated': 'integrated_tools',
    'local_ui_toggle': 'local_ui_toggle',
    'viewport_ui_toggle': 'local_ui_toggle',
    'workspace_step_reorder': 'workspace_step_reorder',
    'workspace_reorder': 'workspace_step_reorder',
    'step_reorder': 'workspace_step_reorder',
    'always': 'always_on_toggles',
    'always_on': 'always_on_toggles',
    'always_on_toggles': 'always_on_toggles',
    '2d_pan_view': 'panview',
    'pan_view': 'panview',
    'panview': 'panview',
}


def _normalize_help_id(help_id: str) -> str:
    key = str(help_id or '').strip().lower().replace(' ', '_').replace('-', '_')
    return ALIASES.get(key, key or 'runtime')


def _package_root() -> Path:
    return Path(__file__).resolve().parent


HELP_POPUP_DEFAULT_WIDTH_PX = 760
_MIN_HELP_LABEL_WIDTH_PX = 240

# The active dialog width is supplied by the help operator when the popup is
# invoked. Keeping it in a tiny stack lets nested helper calls resolve the same
# width without passing a parameter through every draw function.
_HELP_POPUP_WIDTH_STACK: list[int] = []
_HELP_BLF_MODULE = None


def _ui_scale(context=None) -> float:
    try:
        prefs = getattr(context, 'preferences', None) or getattr(bpy.context, 'preferences', None)
        view = getattr(prefs, 'view', None)
        scale = float(getattr(view, 'ui_scale', 1.0) or 1.0)
        return max(0.5, min(scale, 4.0))
    except Exception:
        return 1.0


def _ui_font_size(context=None) -> int:
    # Blender's default UI label font is roughly 11 px at scale 1.0. Measuring
    # with this size keeps wrapping tied to rendered width rather than a fixed
    # character count.
    return max(8, int(round(11 * _ui_scale(context))))


@functools.lru_cache(maxsize=8192)
def _blf_text_width_cached(text: str, font_size: int) -> float:
    blf = _HELP_BLF_MODULE
    if blf is None:
        raise RuntimeError('BLF metrics were not prepared before help draw')
    font_id = 0
    try:
        blf.size(font_id, int(font_size))
    except TypeError:
        blf.size(font_id, int(font_size), 72)
    return float(blf.dimensions(font_id, str(text or ''))[0])


def _display_units(text: str) -> int:
    """Return a fallback display width when Blender font metrics are unavailable."""
    total = 0
    for ch in str(text or ''):
        if ch == '\t':
            total += 4
        elif unicodedata.east_asian_width(ch) in {'F', 'W'}:
            total += 2
        else:
            total += 1
    return total


def _text_width_px(text: str, context=None) -> float:
    value = str(text or '')
    if not value:
        return 0.0
    font_size = _ui_font_size(context)
    try:
        return _blf_text_width_cached(value, font_size)
    except Exception:
        # Conservative fallback used by static tests or unusual Blender builds
        # where the BLF module is not available from this drawing context.
        return float(_display_units(value)) * max(5.0, 5.8 * _ui_scale(context))


def _resolve_help_popup_width_px(context=None, requested_px: int | None = None) -> int:
    """Resolve the pixel width of the currently drawn help popup.

    Older code passed a character count such as ``72`` to the wrapping helper.
    That value is intentionally ignored here: wrapping must be driven by the
    popup pixel width, not by a fixed text column width.
    """
    if requested_px is not None:
        try:
            value = int(requested_px)
            if value >= _MIN_HELP_LABEL_WIDTH_PX:
                return value
        except Exception:
            pass
    if _HELP_POPUP_WIDTH_STACK:
        return max(_MIN_HELP_LABEL_WIDTH_PX, int(_HELP_POPUP_WIDTH_STACK[-1]))
    try:
        region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
        if region_width >= _MIN_HELP_LABEL_WIDTH_PX:
            return region_width
    except Exception:
        pass
    return HELP_POPUP_DEFAULT_WIDTH_PX


def _label_available_width_px(context=None, *, popup_width: int | None = None, icon: str = 'NONE') -> float:
    """Return the usable text width inside the help popup.

    Blender labels do not reflow by themselves. We therefore measure text in
    pixels and split only when the rendered text would exceed the popup's usable
    width. The deduction below accounts for dialog borders, nested boxes, label
    padding, scroll gutter, and an optional icon column. It is a pixel margin,
    not a fixed number of characters.
    """
    popup_px = _resolve_help_popup_width_px(context, popup_width)
    scale = _ui_scale(context)
    chrome_px = 118.0 * scale
    icon_px = 24.0 * scale if icon and icon != 'NONE' else 0.0
    return max(float(_MIN_HELP_LABEL_WIDTH_PX), float(popup_px) - chrome_px - icon_px)


def _split_by_pixel_width(text: str, max_px: float, context=None) -> list[str]:
    chunks: list[str] = []
    current: list[str] = []
    for ch in str(text or ''):
        candidate = ''.join(current) + ch
        if current and _text_width_px(candidate.rstrip(), context) > max_px:
            chunk = ''.join(current).rstrip()
            if chunk:
                chunks.append(chunk)
            current = [ch.lstrip()]
        else:
            current.append(ch)
    if current:
        chunk = ''.join(current).rstrip()
        if chunk:
            chunks.append(chunk)
    return chunks


def _wrap_paragraph_to_popup(paragraph: str, max_px: float, context=None) -> list[str]:
    """Wrap one paragraph only when it is wider than the help popup."""
    paragraph = ' '.join(str(paragraph or '').strip().split())
    if not paragraph:
        return []
    if _text_width_px(paragraph, context) <= max_px:
        return [paragraph]

    # Space-separated languages should wrap between words when possible.
    if ' ' in paragraph:
        lines: list[str] = []
        current = ''
        for word in paragraph.split(' '):
            if not word:
                continue
            word_parts = _split_by_pixel_width(word, max_px, context) if _text_width_px(word, context) > max_px else [word]
            for part in word_parts:
                candidate = part if not current else f'{current} {part}'
                if current and _text_width_px(candidate, context) > max_px:
                    lines.append(current.rstrip())
                    current = part
                else:
                    current = candidate
        if current:
            lines.append(current.rstrip())
        out: list[str] = []
        for line in lines:
            if _text_width_px(line, context) > max_px:
                out.extend(_split_by_pixel_width(line, max_px, context))
            else:
                out.append(line)
        return [line for line in out if line]

    # Japanese and other CJK text often has no spaces. Split by rendered pixel
    # width instead of by a fixed character count.
    return _split_by_pixel_width(paragraph, max_px, context)


def _wrap_labels(layout, text: str, *, width: int | None = None, icon: str = 'NONE', context=None, popup_width: int | None = None) -> None:
    value = str(text or '').strip()
    if not value:
        return
    if popup_width is None and width is not None:
        try:
            # Compatibility only: values below the minimum popup width are old
            # character-count hints and must not force a fixed wrap column.
            maybe_width = int(width)
            if maybe_width >= _MIN_HELP_LABEL_WIDTH_PX:
                popup_width = maybe_width
        except Exception:
            pass
    max_px = _label_available_width_px(context, popup_width=popup_width, icon=icon)
    first = True
    for paragraph in value.splitlines() or [value]:
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        lines = _wrap_paragraph_to_popup(paragraph, max_px, context) or [paragraph]
        for line in lines:
            layout.label(text=line, icon=icon if first else 'NONE')
            first = False


def _draw_section(layout, context, title_en: str, title_ja: str, body_en: str, body_ja: str, *, icon: str) -> None:
    box = layout.box()
    _wrap_labels(box, ui_pair(title_en, title_ja, context), icon=icon, context=context)
    _wrap_labels(box, ui_pair(body_en, body_ja, context), context=context)


def _literal(node: ast.AST, constants: dict[str, str] | None = None) -> str:
    constants = constants or {}
    try:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                return str(node.value).strip()
            if isinstance(node.value, (int, float, bool)) or node.value is None:
                return str(node.value)
        if isinstance(node, ast.JoinedStr):
            parts: list[str] = []
            for item in node.values:
                if isinstance(item, ast.Constant) and isinstance(item.value, str):
                    parts.append(str(item.value))
                else:
                    return ''
            return ''.join(parts).strip()
        if isinstance(node, ast.Name):
            return str(constants.get(node.id, '') or '').strip()
        if isinstance(node, ast.Attribute):
            try:
                return str(constants.get(ast.unparse(node), '') or '').strip()
            except Exception:
                return ''
        if isinstance(node, (ast.Tuple, ast.List)):
            values = [_literal(item, constants) for item in node.elts]
            values = [item for item in values if item]
            return ', '.join(values)
    except Exception:
        return ''
    return ''


def _call_name(node: ast.AST) -> str:
    try:
        if isinstance(node, ast.Name):
            return str(node.id)
        if isinstance(node, ast.Attribute):
            parts = []
            cur = node
            while isinstance(cur, ast.Attribute):
                parts.append(cur.attr)
                cur = cur.value
            if isinstance(cur, ast.Name):
                parts.append(cur.id)
            return '.'.join(reversed(parts))
    except Exception:
        pass
    return ''


def _target_name(target: ast.AST) -> str:
    try:
        if isinstance(target, ast.Name):
            return target.id
        if isinstance(target, ast.Attribute):
            return target.attr
        if isinstance(target, ast.Subscript):
            return _target_name(target.value)
    except Exception:
        pass
    return ''


def _collect_constants(tree: ast.AST) -> dict[str, str]:
    constants: dict[str, str] = {}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value_node = getattr(node, 'value', None)
        if value_node is None:
            continue
        value = _literal(value_node, constants)
        if not value:
            continue
        targets = list(getattr(node, 'targets', []) or []) if isinstance(node, ast.Assign) else [getattr(node, 'target', None)]
        for target in targets:
            name = _target_name(target)
            if name:
                constants[name] = value
    return constants


def _iter_python_files_for_help(help_id: str) -> Iterable[Path]:
    key = _normalize_help_id(help_id)
    doc = HELP_DOCS.get(key, {})
    roots = tuple(doc.get('scan_roots') or ())
    package = _package_root()
    for root in roots:
        rel = str(root or '').strip()
        if not rel:
            continue
        path = package / rel
        if path.is_file() and path.suffix == '.py':
            yield path
        elif path.is_dir():
            for item in sorted(path.rglob('*.py'), key=lambda p: str(p).lower()):
                if '__pycache__' in item.parts or item.name.startswith('.'):
                    continue
                yield item



def _class_bases_text(node: ast.ClassDef) -> str:
    parts: list[str] = []
    for base in getattr(node, 'bases', ()) or ():
        try:
            parts.append(ast.unparse(base))
        except Exception:
            try:
                parts.append(getattr(base, 'id', '') or getattr(base, 'attr', ''))
            except Exception:
                pass
    return ' '.join(parts).lower()


def _class_string_assignments(node: ast.ClassDef, constants: dict[str, str]) -> dict[str, str]:
    values: dict[str, str] = {}
    for stmt in getattr(node, 'body', ()) or ():
        target_name = ''
        value_node = None
        if isinstance(stmt, ast.Assign):
            value_node = stmt.value
            for target in stmt.targets:
                if isinstance(target, ast.Name) and target.id in {'bl_idname', 'bl_label', 'bl_description'}:
                    target_name = target.id
                    break
        elif isinstance(stmt, ast.AnnAssign):
            value_node = stmt.value
            target = stmt.target
            if isinstance(target, ast.Name) and target.id in {'bl_idname', 'bl_label', 'bl_description'}:
                target_name = target.id
        if target_name and value_node is not None:
            value = _literal(value_node, constants)
            if value:
                values[target_name] = value
    return values

def _property_entries_from_file(path: Path) -> list[dict[str, str]]:
    try:
        tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'), filename=str(path))
    except Exception:
        return []
    constants = _collect_constants(tree)
    entries: list[dict[str, str]] = []
    known = {
        'BoolProperty', 'IntProperty', 'FloatProperty', 'StringProperty', 'EnumProperty',
        'FloatVectorProperty', 'PointerProperty', 'CollectionProperty',
    }
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value = getattr(node, 'value', None)
        if not isinstance(value, ast.Call):
            continue
        fn_name = _call_name(value.func)
        tail = fn_name.rsplit('.', 1)[-1]
        if tail not in known:
            continue
        targets = list(getattr(node, 'targets', []) or []) if isinstance(node, ast.Assign) else [getattr(node, 'target', None)]
        prop_id = ''
        for target in targets:
            prop_id = _target_name(target)
            if prop_id:
                break
        if not prop_id:
            continue
        kwargs = {kw.arg: kw.value for kw in getattr(value, 'keywords', ()) if kw.arg}
        name = _literal(kwargs.get('name'), constants) if kwargs.get('name') is not None else ''
        desc = _literal(kwargs.get('description'), constants) if kwargs.get('description') is not None else ''
        default = _literal(kwargs.get('default'), constants) if kwargs.get('default') is not None else ''
        minimum = _literal(kwargs.get('min'), constants) if kwargs.get('min') is not None else ''
        maximum = _literal(kwargs.get('max'), constants) if kwargs.get('max') is not None else ''
        entries.append({
            'id': prop_id,
            'name': name,
            'description': desc,
            'default': default,
            'min': minimum,
            'max': maximum,
            'type': tail,
            'file': str(path.name),
        })
    return entries


def _function_entries_from_file(path: Path) -> list[dict[str, str]]:
    try:
        tree = ast.parse(path.read_text(encoding='utf-8', errors='ignore'), filename=str(path))
    except Exception:
        return []
    constants = _collect_constants(tree)
    entries: list[dict[str, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        values = _class_string_assignments(node, constants)
        bl_idname = str(values.get('bl_idname') or '').strip()
        if not bl_idname:
            continue
        base_text = _class_bases_text(node)
        class_text = f"{base_text} {node.name} {bl_idname}".lower()
        kind = ''
        if 'operator' in class_text or '.' in bl_idname:
            kind = 'operator'
        elif 'menu' in class_text:
            kind = 'menu'
        if not kind:
            continue
        label = str(values.get('bl_label') or node.name or bl_idname).strip()
        desc = str(values.get('bl_description') or '').strip()
        entries.append({
            'id': bl_idname,
            'label': label,
            'description': desc,
            'kind': kind,
            'file': str(path.name),
        })
    return entries


_HELP_FUNCTION_SNAPSHOT: dict[str, tuple[dict[str, str], ...]] = {}
_HELP_SETTING_SNAPSHOT: dict[str, tuple[dict[str, str], ...]] = {}
_HELP_SNAPSHOT_MAX_ENTRIES = 64


def _scanned_functions(help_id: str) -> tuple[dict[str, str], ...]:
    """Return the prepared memory snapshot; never scan files from popup draw."""
    return _HELP_FUNCTION_SNAPSHOT.get(_normalize_help_id(help_id), ())


def prepare_help_snapshot(help_id: str) -> bool:
    """Explicitly prepare source and font snapshots before popup draw."""
    global _HELP_BLF_MODULE
    if _HELP_BLF_MODULE is None:
        try:
            import blf as _blf
            _HELP_BLF_MODULE = _blf
        except Exception:
            _HELP_BLF_MODULE = None
    key = _normalize_help_id(help_id)
    function_entries: list[dict[str, str]] = []
    function_seen: set[str] = set()
    setting_entries: list[dict[str, str]] = []
    setting_seen: set[str] = set()
    for path in _iter_python_files_for_help(key):
        for item in _function_entries_from_file(path):
            item_key = str(item.get('id') or '')
            if not item_key or item_key in function_seen:
                continue
            function_seen.add(item_key)
            function_entries.append(item)
        for item in _property_entries_from_file(path):
            item_key = f"{item.get('file')}:{item.get('id')}"
            if not item.get('id') or item_key in setting_seen:
                continue
            setting_seen.add(item_key)
            setting_entries.append(item)
    function_entries.sort(
        key=lambda item: (
            str(item.get('kind') or ''),
            str(item.get('label') or '').lower(),
            str(item.get('id') or ''),
        )
    )
    setting_entries.sort(
        key=lambda item: (
            str(item.get('name') or '').lower(),
            str(item.get('id') or ''),
            str(item.get('file') or ''),
        )
    )
    _HELP_FUNCTION_SNAPSHOT[key] = tuple(function_entries)
    _HELP_SETTING_SNAPSHOT[key] = tuple(setting_entries)
    while len(_HELP_FUNCTION_SNAPSHOT) > _HELP_SNAPSHOT_MAX_ENTRIES:
        oldest = next(iter(_HELP_FUNCTION_SNAPSHOT))
        _HELP_FUNCTION_SNAPSHOT.pop(oldest, None)
        _HELP_SETTING_SNAPSHOT.pop(oldest, None)
    while len(_HELP_SETTING_SNAPSHOT) > _HELP_SNAPSHOT_MAX_ENTRIES:
        oldest = next(iter(_HELP_SETTING_SNAPSHOT))
        _HELP_SETTING_SNAPSHOT.pop(oldest, None)
        _HELP_FUNCTION_SNAPSHOT.pop(oldest, None)
    return True


def _is_internal_help_name(name: str) -> bool:
    """ソースの識別子そのものの名前（画面に出さない）か。"""
    text = str(name or '').strip()
    return not text or '_' in text or text.islower() or 'legacy' in text.lower()


def _draw_scanned_functions(layout, context, help_id: str) -> None:
    entries = tuple(
        item for item in _scanned_functions(_normalize_help_id(help_id))
        if not _is_internal_help_name(str(item.get('label') or ''))
    )
    if not entries:
        return
    box = layout.box()
    _wrap_labels(box, ui_pair('Detected Commands', '検出したコマンド', context), icon='TOOL_SETTINGS', context=context)
    _wrap_labels(
        box,
        ui_pair(
            'These operators and menus are detected from the bundled source only when this help popup is opened. They are listed here for reference without importing the owning tool during normal startup.',
            '以下のオペレーターとメニューは、このヘルプポップアップを開いた時だけ同梱ソースから検出します。通常起動時に所有ツールをインポートせず、参照用として表示します。',
            context,
        ),
        context=context,
    )
    for item in entries:
        sub = box.box()
        label = ui_text(str(item.get('label') or '').strip(), context)
        kind = str(item.get('kind') or '').strip()
        kind_label = ui_pair('Menu' if kind == 'menu' else 'Operator', 'メニュー' if kind == 'menu' else 'オペレーター', context)
        _wrap_labels(sub, f'{kind_label}: {label}', icon='DOT', context=context)
        desc = str(item.get('description') or '').strip()
        if not desc:
            desc = ui_pair(
                'Runs this command or opens this menu. Some entries require a suitable Blender mode, selection, or editor context.',
                'このコマンドを実行、またはこのメニューを開きます。項目によっては適切な Blender モード、選択状態、エディターコンテキストが必要です。',
                context,
            )
        _wrap_labels(sub, ui_text(desc, context), context=context)


def _scanned_settings(help_id: str) -> tuple[dict[str, str], ...]:
    """Return the prepared memory snapshot; never scan files from popup draw."""
    return _HELP_SETTING_SNAPSHOT.get(_normalize_help_id(help_id), ())


def _draw_setting_bullet(layout, context, name_en: str, name_ja: str, desc_en: str, desc_ja: str) -> None:
    box = layout.box()
    _wrap_labels(box, ui_pair(name_en, name_ja, context), icon='DOT', context=context)
    _wrap_labels(box, ui_pair(desc_en, desc_ja, context), context=context)


def _draw_static_settings(layout, context, settings: Iterable[_SETTING]) -> set[str]:
    seen: set[str] = set()
    for name_en, name_ja, desc_en, desc_ja in settings:
        key = str(name_en or name_ja or '').strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        _draw_setting_bullet(layout, context, name_en, name_ja, desc_en, desc_ja)
    return seen


def _draw_scanned_settings(layout, context, help_id: str, seen_names: set[str]) -> None:
    entries = []
    for item in _scanned_settings(_normalize_help_id(help_id)):
        raw_name = str(item.get('name') or '').strip()
        normalized = raw_name.lower()
        if normalized in seen_names or _is_internal_help_name(raw_name):
            continue
        seen_names.add(normalized)
        entries.append(item)
    if not entries:
        return
    sub = layout.box()
    _wrap_labels(sub, ui_pair('Source-defined Settings', 'ソース内で定義されている設定項目', context), icon='RNA', context=context)
    _wrap_labels(
        sub,
        ui_pair(
            'The following items are collected from the bundled source only when this help popup is opened. This avoids importing the tool during normal startup or N-panel drawing.',
            '以下の項目は、このヘルプポップアップを開いた時だけ同梱ソースから収集します。通常起動時やNパネル描画時に対象ツールをインポートしないため、待機時の負荷を増やしません。',
            context,
        ),
        context=context,
    )
    for item in entries:
        box = sub.box()
        title = ui_text(str(item.get('name') or '').strip(), context)
        _wrap_labels(box, title, icon='DOT', context=context)
        desc_raw = str(item.get('description') or '').strip()
        if not desc_raw:
            desc_raw = ui_pair(
                'This setting is defined in the bundled source, but the original code does not provide a dedicated tooltip. Change it only after checking the surrounding tool behavior.',
                'この設定は同梱ソース内で定義されていますが、元コードに専用ツールチップがありません。周辺の挙動を確認してから変更してください。',
                context,
            )
        _wrap_labels(box, ui_text(desc_raw, context), context=context)
        meta = []
        if item.get('default') not in ('', None):
            value = str(item.get('default'))
            if is_japanese(context):
                if value == 'True':
                    value = '有効'
                elif value == 'False':
                    value = '無効'
                elif value == 'None':
                    value = 'なし'
                else:
                    value = ui_text(value, context)
            else:
                value = ui_text(value, context)
            meta.append(f"{ui_pair('Default', '既定値', context)}: {value}")
        if item.get('min') not in ('', None):
            meta.append(f"{ui_pair('Min', '最小', context)}: {item.get('min')}")
        if item.get('max') not in ('', None):
            meta.append(f"{ui_pair('Max', '最大', context)}: {item.get('max')}")
        if meta:
            _wrap_labels(box, ' / '.join(meta), context=context)


def help_title(help_id: str, context=None) -> str:
    key = _normalize_help_id(help_id)
    doc = HELP_DOCS.get(key) or HELP_DOCS['runtime']
    return ui_pair(str(doc.get('title_en') or key), str(doc.get('title_ja') or doc.get('title_en') or key), context)


def _draw_help_contents(layout, context, help_id: str) -> None:
    key = _normalize_help_id(help_id)
    doc = HELP_DOCS.get(key) or HELP_DOCS['runtime']
    layout = localized_layout(layout, context)
    try:
        base = getattr(layout, '_layout', layout)
        base.use_property_split = False
        base.use_property_decorate = False
    except Exception:
        pass

    header = layout.box()
    _wrap_labels(header, f"{help_title(key, context)} {ui_pair('Help', 'ヘルプ', context)}", icon='QUESTION', context=context)

    _draw_section(
        layout,
        context,
        '1. Feature Overview',
        '1. 機能概要',
        str(doc.get('overview_en') or ''),
        str(doc.get('overview_ja') or doc.get('overview_en') or ''),
        icon='QUESTION',
    )
    _draw_section(
        layout,
        context,
        '2. Usage',
        '2. 使用方法',
        str(doc.get('usage_en') or ''),
        str(doc.get('usage_ja') or doc.get('usage_en') or ''),
        icon='QUESTION',
    )

    _draw_scanned_functions(layout, context, key)

    settings_box = layout.box()
    _wrap_labels(settings_box, ui_pair('3. Settings', '3. 設定項目', context), icon='PREFERENCES', context=context)
    _wrap_labels(
        settings_box,
        ui_pair(
            'Every visible or source-defined setting known to this tool is described below. Tooltips in the normal UI contain the short version; this popup provides the complete reference.',
            'このツールで確認できる表示設定およびソース内定義設定を以下にまとめています。通常UIのツールチップは短い説明、このポップアップは詳細リファレンスです。',
            context,
        ),
        context=context,
    )
    seen = _draw_static_settings(settings_box, context, tuple(doc.get('settings') or ()))
    _draw_scanned_settings(settings_box, context, key, seen)


def draw_help(layout, context, help_id: str, *, popup_width: int | None = None) -> None:
    resolved_width = _resolve_help_popup_width_px(context, popup_width)
    _HELP_POPUP_WIDTH_STACK.append(resolved_width)
    try:
        _draw_help_contents(layout, context, help_id)
    finally:
        try:
            _HELP_POPUP_WIDTH_STACK.pop()
        except Exception:
            pass


def open_help_dialog(context, help_id: str) -> set[str]:
    prepare_help_snapshot(help_id)
    # Kept as a small helper for callers that want to use wm.popup_menu instead
    # of the registered proxy operator.  The main UI uses invoke_props_dialog so
    # the proxy operator can provide the dialog title and size.
    def _draw(self, ctx):
        draw_help(self.layout, ctx, help_id, popup_width=HELP_POPUP_DEFAULT_WIDTH_PX)

    try:
        context.window_manager.popup_menu(_draw, title=help_title(help_id, context), icon='QUESTION')
        return {'FINISHED'}
    except Exception:
        return {'CANCELLED'}
