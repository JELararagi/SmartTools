# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

"""Crash-safe workspace View3D synchronization.

The original Synchronize Workspaces add-on runs directly inside a
``Window.workspace`` message-bus callback and retains an Area RNA object from
one workspace while Blender replaces the screen with another.  Blender 5.1 can
then enter invalid Area/Space data, context overrides, mode changes, and undo
code during the workspace transaction.

This integrated implementation keeps the user-visible behavior but uses a
strictly deferred plain-data pipeline:

* No Python callback is registered on ``Window.workspace``; the enabled
  feature timer detects a changed primitive workspace key only after Blender
  returns to its normal event loop.
* No Area, Space, Region, Screen, or Window RNA object is stored between ticks.
* The source 3D-view state is captured as primitive Python values while stable.
* The target is resolved fresh after a settle delay and repeated stable screen
  signatures.
* No context override, UI operator, workspace assignment, or mode change is
  used.

When disabled, no timer, handler, or msgbus subscription remains active.
"""

from __future__ import annotations

import gc
import json
import sys
import time
from dataclasses import dataclass, field
from types import FunctionType, ModuleType
from typing import Any, Iterable

import bpy
from bpy.app.handlers import persistent
from bpy.app.translations import contexts as i18n_contexts
from bpy.app.translations import pgettext_iface, pgettext_tip
from bpy.types import Operator, PropertyGroup

from .. import storage as _suite_storage

_WORKSPACE_RUNTIME_API_VERSION = 5
_RUNTIME_QUARANTINE_KEY = "SMART_WORKSPACE_SUITE_WORKSPACE_RUNTIME_QUARANTINE"

TOOL_LABEL = "Synchronize Workspaces"
TOOL_LABEL_JA = "ワークスペース同期"
ENABLE_LABEL = "Enabled"
DISABLE_LABEL = "Disabled"
TOOL_DESCRIPTION = (
    "Synchronizes the active 3D View state between workspaces when you switch workspace tabs. "
    "Enable this when the view angle, zoom, shading, and overlay state should follow across task layouts."
)
ENABLE_DESCRIPTION = (
    "Enables workspace View3D synchronization and starts its deferred workspace-stability watcher. "
    "The setting is saved immediately and restored after Blender restarts or another scene is opened."
)
DISABLE_DESCRIPTION = (
    "Disables workspace View3D synchronization and removes its deferred watcher. "
    "Use this when each workspace should keep its own independent 3D View state."
)

_SETTINGS_FILE = "smart_workspace_synchronize_workspaces_settings.json"
_LEGACY_SETTINGS_FILE = "synchronize_workspaces_settings.json"
_MSGBUS_OWNER = object()
_REGISTERED_CLASSES: list[type] = []
_REGISTERED = False
_LOAD_HANDLER_INSTALLED = False
_PERSISTENCE_LOADING = False
_LEGACY_COMPAT_CLASS_REGISTERED = False
_ORPHAN_SYNC_CLEANUP_DONE = False

_RUNTIME_KEY = "SMART_WORKSPACE_SUITE_SYNCHRONIZE_WORKSPACES_RUNTIME_V3"
_LEGACY_RUNTIME_KEYS = (
    "SMART_WORKSPACE_SUITE_SYNCHRONIZE_WORKSPACES_RUNTIME_V2",
    "SMART_WORKSPACE_SUITE_SYNCHRONIZE_WORKSPACES_RUNTIME_V1",
)
_RUNTIME_GENERATION = object()
_RUNTIME_ENABLED = False
_RUNTIME_TIMER_RUNNING = False
_SHUTTING_DOWN = False

_TIMER_INTERVAL = 0.15
_CAPTURE_INTERVAL = 0.75
_WORKSPACE_SETTLE_DELAY = 1.00
_STABLE_TICKS_REQUIRED = 5

_TRANSLATIONS = {
    "ja_JP": {
        ("*", TOOL_LABEL): TOOL_LABEL_JA,
        ("*", ENABLE_LABEL): "有効",
        ("*", DISABLE_LABEL): "無効",
        ("*", TOOL_DESCRIPTION): (
            "ワークスペースタブを切り替えた時に、アクティブな3Dビューの状態を別ワークスペースへ同期します。"
            "視点、ズーム、シェーディング、オーバーレイ状態を複数の作業レイアウトで揃えたい場合に有効化します。"
        ),
        ("*", ENABLE_DESCRIPTION): (
            'ワークスペースの3Dビュー同期を有効にし、遅延型のワークスペース安定監視を開始します。設定は即時保存され、Blender 再起動後や別シーン読込後も復元されます。'
        ),
        ("*", DISABLE_DESCRIPTION): (
            'ワークスペースの3Dビュー同期を無効にし、遅延監視を停止します。各ワークスペースで個別の3Dビュー状態を保ちたい場合に使用します。'
        ),
        (i18n_contexts.operator_default, "Set Synchronize Workspaces"): "ワークスペース同期を設定",
    }
}

# Explicit safe properties.  These cover the original feature's view, shading,
# and overlay behavior without generic RNA property walking.
_SPACE_ATTRS = (
    "lens",
    "clip_start",
    "clip_end",
    "lock_camera",
    "show_gizmo",
    "show_gizmo_tool",
    "show_gizmo_navigate",
    "show_gizmo_context",
    "show_gizmo_object_translate",
    "show_gizmo_object_rotate",
    "show_gizmo_object_scale",
    "show_gizmo_empty",
    "show_gizmo_camera",
    "show_gizmo_light",
    "show_object_viewport_mesh",
    "show_object_viewport_curve",
    "show_object_viewport_surf",
    "show_object_viewport_meta",
    "show_object_viewport_font",
    "show_object_viewport_armature",
    "show_object_viewport_lattice",
    "show_object_viewport_empty",
    "show_object_viewport_light",
    "show_object_viewport_camera",
    "show_object_viewport_speaker",
    "show_object_viewport_light_probe",
)
_REGION3D_ATTRS = (
    "view_distance",
    "view_perspective",
    "view_camera_zoom",
)
_SHADING_ATTRS = (
    "type",
    "light",
    "studio_light",
    "use_world_space_lighting",
    "color_type",
    "background_type",
    "background_alpha",
    "show_shadows",
    "show_cavity",
    "cavity_type",
    "curvature_ridge_factor",
    "curvature_valley_factor",
    "show_object_outline",
    "show_specular_highlight",
    "show_xray",
    "xray_alpha",
    "show_backface_culling",
    "show_transparent_back",
    "render_pass",
    "wireframe_color_type",
)
_OVERLAY_ATTRS = (
    "show_overlays",
    "show_floor",
    "show_axis_x",
    "show_axis_y",
    "show_axis_z",
    "show_ortho_grid",
    "show_text",
    "show_stats",
    "show_cursor",
    "show_annotation",
    "show_relationship_lines",
    "show_outline_selected",
    "show_bones",
    "show_motion_paths",
    "show_object_origins",
    "show_object_origins_all",
    "show_extras",
    "show_light_colors",
    "show_face_orientation",
    "show_wireframes",
    "show_viewer_attribute",
    "show_weight",
    "show_faces",
    "show_face_center",
    "show_edge_crease",
    "show_edge_sharp",
    "show_edge_bevel_weight",
    "show_edge_seams",
    "show_extra_edge_length",
    "show_extra_face_area",
    "show_extra_face_angle",
    "show_extra_indices",
    "show_freestyle_edge_marks",
    "show_freestyle_face_marks",
)


@dataclass
class _SyncRuntimeState:
    last_workspace: str = ""
    snapshot: dict[str, Any] | None = None
    # Primitive identity only; never retain Window/WorkSpace/Screen RNA.
    observed_key: tuple[Any, ...] | None = None
    pending: bool = False
    event_time: float = 0.0
    stable_signature: tuple[Any, ...] | None = None
    stable_ticks: int = 0
    idle_signature: tuple[Any, ...] | None = None
    idle_stable_ticks: int = 0
    last_capture_time: float = 0.0


_state = _SyncRuntimeState()


def _iface(message: str) -> str:
    return pgettext_iface(message)


def _tip(message: str) -> str:
    return pgettext_tip(message)


def _settings_path():
    return _suite_storage.addon_storage_path(_SETTINGS_FILE, "synchronize_workspaces")


def _legacy_settings_path():
    return _suite_storage.addon_storage_path(_LEGACY_SETTINGS_FILE, "synchronize_workspaces")


def _active_context(context=None):
    return context or getattr(bpy, "context", None)


def _scene_settings(context=None):
    ctx = _active_context(context)
    scene = getattr(ctx, "scene", None) if ctx is not None else None
    return getattr(scene, "sws_synchronize_workspaces_settings", None) if scene is not None else None


def _workspace_enabled(workspace) -> bool:
    if workspace is None:
        return False
    try:
        return bool(getattr(workspace, "sws_synchronize_workspaces_active", True))
    except Exception:
        return True


def _suite_settings(context=None):
    ctx = _active_context(context)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    return getattr(wm, "nptl_settings", None) if wm is not None else None


def _is_enabled(context=None) -> bool:
    scene_value = False
    settings = _scene_settings(context)
    if settings is not None:
        try:
            scene_value = bool(getattr(settings, "active", False))
        except Exception:
            scene_value = False
    st = _suite_settings(context)
    suite_value = False
    if st is not None and hasattr(st, "synchronize_workspaces_enabled"):
        try:
            suite_value = bool(getattr(st, "synchronize_workspaces_enabled", False))
        except Exception:
            suite_value = False
    return bool(scene_value or suite_value)


def is_enabled(context=None) -> bool:
    return _is_enabled(context)


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(context, "preferences", None) if context is not None else getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
        if getattr(view, "use_translate_interface", True) is False:
            return False
        lang = str(getattr(view, "language", "") or "").strip().lower()
        if lang and lang != "default":
            return lang.startswith("ja") or "japanese" in lang
    except Exception:
        pass
    try:
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "").strip().lower()
        return locale.startswith("ja")
    except Exception:
        return False


def ui_label(en: str, ja: str, context=None) -> str:
    return str(ja if _is_ja(context) else en)


def _rna_ptr(value: Any) -> int:
    if value is None:
        return 0
    try:
        return int(value.as_pointer())
    except Exception:
        return 0


def _driver_namespace():
    try:
        return bpy.app.driver_namespace
    except Exception:
        return None


def _unregister_timer_ref(fn: Any) -> None:
    if not callable(fn):
        return
    try:
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    except Exception:
        pass


def _clear_msgbus_owner(owner: Any) -> None:
    if owner is None:
        return
    try:
        bpy.msgbus.clear_by_owner(owner)
    except Exception:
        pass


def _cleanup_previous_runtime() -> None:
    """No-op; unproven generations require a Blender process restart."""
    return None

def _publish_runtime() -> None:
    ns = _driver_namespace()
    if ns is None:
        return
    try:
        ns[_RUNTIME_KEY] = {
            "generation": _RUNTIME_GENERATION,
            "timer": _sync_runtime_timer,
            "owner": _MSGBUS_OWNER,
            "active": bool(_RUNTIME_ENABLED and not _SHUTTING_DOWN),
        }
    except Exception:
        pass


def _runtime_quarantined() -> bool:
    """Block pre-fix workspace callbacks after a same-session ZIP update."""
    ns = _driver_namespace()
    if ns is None:
        return False
    try:
        return bool(ns.get(_RUNTIME_QUARANTINE_KEY, False))
    except Exception:
        return False


def _runtime_is_current() -> bool:
    if _SHUTTING_DOWN or not _RUNTIME_ENABLED or _runtime_quarantined():
        return False
    ns = _driver_namespace()
    if ns is None:
        return False
    try:
        record = ns.get(_RUNTIME_KEY)
        return isinstance(record, dict) and record.get("generation") is _RUNTIME_GENERATION and bool(record.get("active", False))
    except Exception:
        return False


def _values_equal(current: Any, value: Any) -> bool:
    try:
        if isinstance(current, (bool, int, float, str)) or current is None:
            return current == value
        if isinstance(value, (list, tuple)):
            return tuple(current) == tuple(value)
        return current == value
    except Exception:
        return False


def _safe_set(target: Any, attr: str, value: Any) -> bool:
    if target is None or value is None or _SHUTTING_DOWN or not _RUNTIME_ENABLED:
        return False
    # Never write through an invalidated RNA wrapper.  ``as_pointer`` is a
    # cheap C-side liveness check and avoids entering property lookup for a
    # wrapper whose owner was replaced during a workspace transaction.
    if hasattr(target, "as_pointer") and _rna_ptr(target) == 0:
        return False
    try:
        current = getattr(target, attr)
        if _values_equal(current, value):
            return False
    except Exception:
        pass
    try:
        setattr(target, attr, value)
        return True
    except Exception:
        return False


def _plain_value(value: Any) -> Any:
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        seq = tuple(value)
    except Exception:
        return None
    if 1 <= len(seq) <= 16:
        try:
            return [float(v) for v in seq]
        except Exception:
            return None
    return None


def _capture_attrs(target: Any, names: tuple[str, ...]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if target is None:
        return result
    for name in names:
        try:
            value = _plain_value(getattr(target, name))
        except Exception:
            continue
        if value is not None:
            result[name] = value
    return result


def _apply_attrs(target: Any, data: Any) -> None:
    if target is None or not isinstance(data, dict):
        return
    for name, value in data.items():
        if isinstance(value, list):
            value = tuple(value)
        _safe_set(target, str(name), value)


def _view3d_spaces(area) -> Iterable[Any]:
    try:
        for space in tuple(getattr(area, "spaces", ()) or ()):
            if str(getattr(space, "type", "") or "") == "VIEW_3D":
                yield space
    except Exception:
        return


def _window_uses_screen(screen) -> bool:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            if getattr(window, "screen", None) == screen:
                return True
    except Exception:
        pass
    return False


def get_biggest_area(workspace, area_type="VIEW_3D", checkscreen=False):
    """Compatibility helper; never retained across callbacks."""
    max_size = 0
    best = None
    if workspace is None:
        return None
    try:
        screens = tuple(getattr(workspace, "screens", ()) or ())
    except Exception:
        screens = ()
    for screen in screens:
        if checkscreen and not _window_uses_screen(screen):
            continue
        try:
            areas = tuple(getattr(screen, "areas", ()) or ())
        except Exception:
            areas = ()
        for area in areas:
            try:
                if str(getattr(area, "type", "") or "") != area_type:
                    continue
                size = int(getattr(area, "width", 0)) * int(getattr(area, "height", 0))
            except Exception:
                continue
            if size > max_size:
                max_size = size
                best = area
    return best


def _current_view3d_area(context=None):
    ctx = _active_context(context)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, "window", None)
        screen = getattr(window, "screen", None)
        areas = tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ()
    except Exception:
        areas = ()
    # ``bpy.context.area`` may still be the event area's old RNA wrapper while
    # Blender replaces a workspace screen.  Use it only when its pointer is
    # present in the freshly resolved live screen.
    try:
        context_area = getattr(ctx, "area", None)
        context_ptr = _rna_ptr(context_area)
        live_ptrs = {_rna_ptr(area) for area in areas}
        if (
            context_area is not None
            and context_ptr
            and context_ptr in live_ptrs
            and str(getattr(context_area, "type", "") or "") == "VIEW_3D"
        ):
            return context_area
    except Exception:
        pass
    best = None
    best_size = -1
    for area in areas:
        try:
            if str(getattr(area, "type", "") or "") != "VIEW_3D":
                continue
            size = int(getattr(area, "width", 0)) * int(getattr(area, "height", 0))
        except Exception:
            continue
        if size > best_size:
            best = area
            best_size = size
    return best


def _workspace_key(context=None) -> tuple[Any, ...] | None:
    """Return primitive active-window/workspace identity without reading Areas."""
    ctx = _active_context(context)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, "window", None)
        workspace = getattr(window, "workspace", None) if window is not None else None
        if window is None or workspace is None:
            return None
        return (
            _rna_ptr(window),
            _rna_ptr(workspace),
            str(getattr(workspace, "name", "") or ""),
        )
    except Exception:
        return None


def _screen_signature(context=None) -> tuple[Any, ...] | None:
    ctx = _active_context(context)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, "window", None)
        screen = getattr(window, "screen", None)
        workspace = getattr(window, "workspace", None)
        areas = tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ()
        area_sig = tuple(
            (
                _rna_ptr(area),
                str(getattr(area, "type", "") or ""),
                int(getattr(area, "x", 0)),
                int(getattr(area, "y", 0)),
                int(getattr(area, "width", 0)),
                int(getattr(area, "height", 0)),
            )
            for area in areas
        )
        return (_rna_ptr(window), _rna_ptr(screen), str(getattr(workspace, "name", "") or ""), area_sig)
    except Exception:
        return None


def _capture_snapshot(area, settings) -> dict[str, Any] | None:
    if area is None:
        return None
    space = next(iter(_view3d_spaces(area)), None)
    if space is None:
        return None
    region = getattr(space, "region_3d", None)
    if region is None:
        return None
    data: dict[str, Any] = {
        "space": _capture_attrs(space, _SPACE_ATTRS),
        "region": _capture_attrs(region, _REGION3D_ATTRS),
        "view_location": _plain_value(getattr(region, "view_location", None)),
        "view_rotation": _plain_value(getattr(region, "view_rotation", None)),
        "view_camera_offset": _plain_value(getattr(region, "view_camera_offset", None)),
    }
    try:
        if bool(getattr(settings, "shading_type", False)):
            shading = getattr(space, "shading", None)
            data["shading_type"] = _capture_attrs(shading, ("type",))
    except Exception:
        pass
    try:
        if bool(getattr(settings, "shading_settings", False)):
            data["shading"] = _capture_attrs(getattr(space, "shading", None), _SHADING_ATTRS)
    except Exception:
        pass
    try:
        if bool(getattr(settings, "overlays", False)):
            data["overlay"] = _capture_attrs(getattr(space, "overlay", None), _OVERLAY_ATTRS)
    except Exception:
        pass
    return data


def _apply_snapshot(area, snapshot: Any, settings) -> bool:
    if area is None or not isinstance(snapshot, dict):
        return False
    space = next(iter(_view3d_spaces(area)), None)
    if space is None:
        return False
    region = getattr(space, "region_3d", None)
    if region is None:
        return False
    _apply_attrs(space, snapshot.get("space"))
    _apply_attrs(region, snapshot.get("region"))
    location = snapshot.get("view_location")
    rotation = snapshot.get("view_rotation")
    camera_offset = snapshot.get("view_camera_offset")
    if isinstance(location, list) and len(location) == 3:
        _safe_set(region, "view_location", tuple(float(v) for v in location))
    if isinstance(rotation, list) and len(rotation) == 4:
        _safe_set(region, "view_rotation", tuple(float(v) for v in rotation))
    if isinstance(camera_offset, list) and len(camera_offset) == 2:
        _safe_set(region, "view_camera_offset", tuple(float(v) for v in camera_offset))
    try:
        if bool(getattr(settings, "shading_type", False)):
            _apply_attrs(getattr(space, "shading", None), snapshot.get("shading_type"))
    except Exception:
        pass
    try:
        if bool(getattr(settings, "shading_settings", False)):
            _apply_attrs(getattr(space, "shading", None), snapshot.get("shading"))
    except Exception:
        pass
    try:
        if bool(getattr(settings, "overlays", False)):
            _apply_attrs(getattr(space, "overlay", None), snapshot.get("overlay"))
    except Exception:
        pass
    # Property updates schedule their own redraw.  Calling RegionView3D.update
    # or Area.tag_redraw from a deferred workspace transaction is unnecessary
    # and widens the native-code surface during a sensitive transition.
    return True


def _capture_current(context=None) -> None:
    ctx = _active_context(context)
    if ctx is None:
        return
    workspace = getattr(ctx, "workspace", None)
    if workspace is None or not _workspace_enabled(workspace):
        _state.last_workspace = str(getattr(workspace, "name", "") or "") if workspace is not None else ""
        return
    settings = _scene_settings(ctx)
    if settings is None or not bool(getattr(settings, "active", False)):
        return
    area = _current_view3d_area(ctx)
    snapshot = _capture_snapshot(area, settings)
    if snapshot is None:
        return
    _state.snapshot = snapshot
    _state.last_workspace = str(getattr(workspace, "name", "") or "")
    _state.last_capture_time = time.monotonic()


def _mark_workspace_event() -> None:
    _state.pending = True
    _state.event_time = time.monotonic()
    _state.stable_signature = None
    _state.stable_ticks = 0
    _state.idle_signature = None
    _state.idle_stable_ticks = 0


def update_workspace(_args=None) -> None:
    """Legacy callback compatibility; current builds never subscribe it."""
    if _SHUTTING_DOWN or not _RUNTIME_ENABLED:
        return
    _mark_workspace_event()


def _sync_runtime_timer():
    global _RUNTIME_TIMER_RUNNING
    if not _runtime_is_current():
        _RUNTIME_TIMER_RUNNING = False
        return None

    now = time.monotonic()
    ctx = getattr(bpy, "context", None)

    # Detect a workspace change only from this app timer.  App timers are run by
    # Blender after control has returned to the event loop, unlike a
    # Window.workspace msgbus callback which executes inside ED_workspace_change.
    # On the first changed key, return immediately without resolving Areas.
    key = _workspace_key(ctx)
    if key is None:
        return _TIMER_INTERVAL
    if _state.observed_key is None:
        _state.observed_key = key
    elif key != _state.observed_key:
        _state.observed_key = key
        _mark_workspace_event()
        return _TIMER_INTERVAL

    if _state.pending:
        # Never touch Area/Space/Region RNA until the primitive workspace key has
        # remained unchanged for the complete settle delay.  A further change is
        # handled above and resets the event time before any Area lookup occurs.
        if now - _state.event_time < _WORKSPACE_SETTLE_DELAY:
            return _TIMER_INTERVAL
        signature = _screen_signature(ctx)
        if signature is None:
            _state.event_time = now
            _state.stable_signature = None
            _state.stable_ticks = 0
            return _TIMER_INTERVAL
        if signature == _state.stable_signature:
            _state.stable_ticks += 1
        else:
            _state.stable_signature = signature
            _state.stable_ticks = 1
        if _state.stable_ticks < _STABLE_TICKS_REQUIRED:
            return _TIMER_INTERVAL

        settings = _scene_settings(ctx)
        workspace = getattr(ctx, "workspace", None) if ctx is not None else None
        current_name = str(getattr(workspace, "name", "") or "") if workspace is not None else ""
        if (
            settings is not None
            and bool(getattr(settings, "active", False))
            and workspace is not None
            and _workspace_enabled(workspace)
            and isinstance(_state.snapshot, dict)
            and current_name != _state.last_workspace
        ):
            area = _current_view3d_area(ctx)
            _apply_snapshot(area, _state.snapshot, settings)
        _state.pending = False
        _state.stable_signature = None
        _state.stable_ticks = 0
        _capture_current(ctx)
        # Capture may resolve a refreshed context after the apply.  Keep the
        # observed key synchronized without retaining any RNA wrapper.
        current_key = _workspace_key(ctx)
        if current_key is not None:
            _state.observed_key = current_key
        return _TIMER_INTERVAL

    # Periodic source capture is also gated by a repeatedly identical live
    # screen signature.  This avoids reading view data until screen/area pointers
    # have remained unchanged for several event-loop turns.
    signature = _screen_signature(ctx)
    if signature is None:
        _state.idle_signature = None
        _state.idle_stable_ticks = 0
        return _TIMER_INTERVAL
    if signature == _state.idle_signature:
        _state.idle_stable_ticks += 1
    else:
        _state.idle_signature = signature
        _state.idle_stable_ticks = 1
        return _TIMER_INTERVAL
    if (
        _state.idle_stable_ticks >= _STABLE_TICKS_REQUIRED
        and now - _state.last_capture_time >= _CAPTURE_INTERVAL
    ):
        try:
            _capture_current(ctx)
        except Exception:
            pass
    return _TIMER_INTERVAL


def _ensure_runtime_timer(*, first_interval: float | None = None) -> None:
    global _RUNTIME_TIMER_RUNNING
    if _SHUTTING_DOWN or not _RUNTIME_ENABLED:
        return
    _publish_runtime()
    try:
        if bpy.app.timers.is_registered(_sync_runtime_timer):
            _RUNTIME_TIMER_RUNNING = True
            return
    except Exception:
        pass
    try:
        bpy.app.timers.register(
            _sync_runtime_timer,
            first_interval=max(_TIMER_INTERVAL, float(first_interval)) if first_interval is not None else _TIMER_INTERVAL,
            persistent=False,
        )
        _RUNTIME_TIMER_RUNNING = True
    except Exception:
        _RUNTIME_TIMER_RUNNING = False


def _stop_runtime_timer() -> None:
    global _RUNTIME_TIMER_RUNNING
    _unregister_timer_ref(_sync_runtime_timer)
    _RUNTIME_TIMER_RUNNING = False


def _data_to_save(context=None) -> dict[str, Any]:
    settings = _scene_settings(context)
    data: dict[str, Any] = {
        "active": bool(getattr(settings, "active", False)) if settings is not None else False,
        "shading_type": bool(getattr(settings, "shading_type", False)) if settings is not None else False,
        "shading_settings": bool(getattr(settings, "shading_settings", False)) if settings is not None else False,
        "overlays": bool(getattr(settings, "overlays", False)) if settings is not None else False,
        "workspace_active": {},
    }
    try:
        data["workspace_active"] = {
            str(workspace.name): bool(getattr(workspace, "sws_synchronize_workspaces_active", True))
            for workspace in getattr(bpy.data, "workspaces", ())
        }
    except Exception:
        data["workspace_active"] = {}
    return data


def _save_persistent_sync_settings(context=None, *, force: bool = False) -> bool:
    # Forced teardown saves are the authoritative last chance to persist the
    # already materialized runtime settings.  A transient load flag must not
    # turn that bounded flush into an unconditional False result.
    if _PERSISTENCE_LOADING and not force:
        return False
    if not force:
        try:
            if not _suite_storage.n_panel_state_save_enabled(True):
                from .. import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
                return False
        except Exception:
            return False
    try:
        return bool(_suite_storage.atomic_write_json(
            _settings_path(), _data_to_save(context),
            indent=2, ensure_ascii=False, sort_keys=True,
        ))
    except Exception:
        return False

def _read_settings_data() -> dict[str, Any]:
    for path in (_settings_path(), _legacy_settings_path()):
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            continue
    return {}


def _load_persistent_sync_settings(context=None) -> None:
    global _PERSISTENCE_LOADING
    data = _read_settings_data()
    if not isinstance(data, dict) or not data:
        return
    settings = _scene_settings(context)
    _PERSISTENCE_LOADING = True
    try:
        if settings is not None:
            for name in ("active", "shading_type", "shading_settings", "overlays"):
                if name in data:
                    try:
                        setattr(settings, name, bool(data.get(name)))
                    except Exception:
                        pass
        workspace_state = data.get("workspace_active", {})
        if isinstance(workspace_state, dict):
            for workspace in getattr(bpy.data, "workspaces", ()):
                if workspace.name in workspace_state:
                    try:
                        setattr(workspace, "sws_synchronize_workspaces_active", bool(workspace_state[workspace.name]))
                    except Exception:
                        pass
        st = _suite_settings(context)
        if st is not None and hasattr(st, "synchronize_workspaces_enabled"):
            try:
                setattr(st, "synchronize_workspaces_enabled", bool(data.get("active", False)))
            except Exception:
                pass
    finally:
        _PERSISTENCE_LOADING = False


def _register_msgbus() -> None:
    """Clear stale owners; current runtime intentionally installs no msgbus."""
    _clear_msgbus_owner(_MSGBUS_OWNER)


def _clear_msgbus() -> None:
    _clear_msgbus_owner(_MSGBUS_OWNER)


def _reset_runtime_state() -> None:
    _state.last_workspace = ""
    _state.snapshot = None
    _state.observed_key = None
    _state.pending = False
    _state.event_time = 0.0
    _state.stable_signature = None
    _state.stable_ticks = 0
    _state.idle_signature = None
    _state.idle_stable_ticks = 0
    _state.last_capture_time = 0.0


def _enable_sync_runtime(*, initial_capture: bool = True, first_interval: float | None = None) -> None:
    global _RUNTIME_ENABLED, _SHUTTING_DOWN
    _cleanup_previous_runtime()
    _SHUTTING_DOWN = False
    _RUNTIME_ENABLED = True
    _publish_runtime()
    _clear_msgbus()
    _install_load_handler()
    _reset_runtime_state()
    _state.observed_key = _workspace_key(getattr(bpy, "context", None))
    if initial_capture:
        try:
            _capture_current(getattr(bpy, "context", None))
        except Exception:
            pass
    else:
        # Startup/file-load path: wait until Blender has completed screen, mode,
        # undo, and workspace initialization before resolving any View3D RNA.
        _mark_workspace_event()
    _ensure_runtime_timer(first_interval=first_interval)


def _disable_sync_runtime() -> None:
    global _RUNTIME_ENABLED
    _RUNTIME_ENABLED = False
    _clear_msgbus()
    _stop_runtime_timer()
    _remove_load_handler()
    _reset_runtime_state()
    ns = _driver_namespace()
    if ns is not None:
        try:
            record = ns.get(_RUNTIME_KEY)
        except Exception:
            record = None
        if isinstance(record, dict) and record.get("generation") is _RUNTIME_GENERATION:
            try:
                record["active"] = False
            except Exception:
                pass
            try:
                ns.pop(_RUNTIME_KEY, None)
            except Exception:
                pass


def apply_enabled(
    enabled: bool | None = None,
    *,
    context=None,
    save: bool = False,
    _defer_initial_capture: bool = False,
) -> bool:
    desired = _is_enabled(context) if enabled is None else bool(enabled)
    quarantined = bool(desired and _runtime_quarantined())
    if desired and not quarantined and not _REGISTERED and not ensure_registered():
        return False
    settings = _scene_settings(context)
    if settings is not None:
        try:
            if bool(getattr(settings, "active", False)) != desired:
                setattr(settings, "active", desired)
        except Exception:
            pass
    st = _suite_settings(context)
    if st is not None and hasattr(st, "synchronize_workspaces_enabled"):
        try:
            if bool(getattr(st, "synchronize_workspaces_enabled", False)) != desired:
                setattr(st, "synchronize_workspaces_enabled", desired)
        except Exception:
            pass
    if quarantined:
        # Preserve the saved enable state but keep this process free of every
        # workspace callback until Blender restarts with clean RNA ownership.
        _disable_sync_runtime()
    elif desired:
        _enable_sync_runtime(
            initial_capture=not _defer_initial_capture,
            first_interval=1.0 if _defer_initial_capture else None,
        )
    else:
        _disable_sync_runtime()
    if save:
        _persist_sync_user_change(
            context or getattr(bpy, "context", None),
            'synchronize-workspaces-explicit-apply',
        )
    return bool(desired and not quarantined)


def sync_from_settings(context=None) -> bool:
    if not ensure_registered():
        return False
    _load_persistent_sync_settings(context)
    return apply_enabled(
        _is_enabled(context),
        context=context,
        save=False,
        _defer_initial_capture=True,
    )


@persistent
def load_handler(_dummy=None) -> None:
    ctx = getattr(bpy, "context", None)
    _load_persistent_sync_settings(ctx)
    try:
        _install_legacy_compatibility_shim()
    except Exception:
        pass
    if _is_enabled(ctx):
        _enable_sync_runtime(initial_capture=False, first_interval=1.0)
    else:
        _disable_sync_runtime()


def _install_load_handler() -> None:
    global _LOAD_HANDLER_INSTALLED
    try:
        if load_handler not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(load_handler)
        _LOAD_HANDLER_INSTALLED = True
    except Exception:
        _LOAD_HANDLER_INSTALLED = False


def _remove_load_handler() -> None:
    global _LOAD_HANDLER_INSTALLED
    try:
        while load_handler in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(load_handler)
    except Exception:
        pass
    _LOAD_HANDLER_INSTALLED = False


def _persist_sync_user_change(context, source: str) -> bool:
    if _PERSISTENCE_LOADING:
        return False
    try:
        from .. import persistence as _suite_persistence
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def _settings_update(self, context) -> None:
    if _PERSISTENCE_LOADING:
        return
    apply_enabled(bool(getattr(self, "active", False)), context=context, save=False)
    _persist_sync_user_change(context, 'synchronize-workspaces-enable')


def _workspace_update(_self, context) -> None:
    _persist_sync_user_change(context, 'synchronize-workspaces-profile')


def _option_update(_self, context) -> None:
    _persist_sync_user_change(context, 'synchronize-workspaces-options')


class SWS_SynchronizeWorkspacesSettings(PropertyGroup):
    active: bpy.props.BoolProperty(
        name="Synchronize Workspaces",
        description=TOOL_DESCRIPTION,
        default=False,
        update=_settings_update,
    )
    shading_type: bpy.props.BoolProperty(
        name="Synchronize Shading Type",
        description="Also copy the viewport shading mode, such as Wireframe, Solid, Material Preview, or Rendered, after a workspace switch.",
        default=False,
        update=_option_update,
    )
    shading_settings: bpy.props.BoolProperty(
        name="Synchronize Shading Settings",
        description="Also copy detailed viewport shading options, such as lighting, color, x-ray, background, cavity, and render-pass display settings, when supported by Blender.",
        default=False,
        update=_option_update,
    )
    overlays: bpy.props.BoolProperty(
        name="Synchronize Overlays",
        description="Also copy viewport overlay settings, such as grid, axes, outlines, relationship lines, edit-mesh marks, and related visibility options, after a workspace switch.",
        default=False,
        update=_option_update,
    )


# -----------------------------------------------------------------------------
# Legacy standalone add-on compatibility
# -----------------------------------------------------------------------------

def _legacy_bool_false(_self=None) -> bool:
    return False


def _legacy_bool_ignore(_self, _value) -> None:
    return None


_COMPAT_SCENE_PROP_NAME = "Smart Workspace Legacy Synchronize Compatibility"
_COMPAT_SCENE_PROP_DESCRIPTION = (
    "Smart Workspace Suite-owned disabled compatibility pointer for the legacy "
    "Synchronize Workspaces add-on."
)
_OWN_COMPAT_POINTER_TYPES = {
    "SWS_LegacySynchronizeWorkspacesSettings",
    "SWS_LegacySynchronizeWorkspacesDisabledSettings",
}


class SWS_LegacySynchronizeWorkspacesDisabledSettings(PropertyGroup):
    active: bpy.props.BoolProperty(
        name="Legacy Synchronize Workspaces Disabled",
        description="Compatibility placeholder for stale standalone Synchronize Workspaces callbacks. Smart Workspace Suite keeps the old runtime disabled.",
        get=_legacy_bool_false,
        set=_legacy_bool_ignore,
    )
    shading_type: bpy.props.BoolProperty(get=_legacy_bool_false, set=_legacy_bool_ignore)
    shading_settings: bpy.props.BoolProperty(get=_legacy_bool_false, set=_legacy_bool_ignore)
    overlays: bpy.props.BoolProperty(get=_legacy_bool_false, set=_legacy_bool_ignore)


def _iter_standalone_sync_modules():
    """Never enumerate or modify third-party synchronization modules."""
    return ()

def _safe_remove_header_callback(fn) -> None:
    if fn is None:
        return
    header = getattr(bpy.types, "VIEW3D_HT_header", None)
    if header is None:
        return
    for _index in range(16):
        try:
            header.remove(fn)
        except Exception:
            break


def _safe_remove_handler(handler_list, fn) -> None:
    if fn is None or handler_list is None:
        return
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass


def _legacy_noop(*_args, **_kwargs):
    return None


def _safe_external_unregister_factory(module: ModuleType):
    """Return an inert compatibility callable without patching the module."""
    del module
    def _safe_external_unregister(*_args, **_kwargs):
        return None
    _safe_external_unregister._sws_safe_wrapper = True
    return _safe_external_unregister

def _disable_standalone_sync_runtime() -> None:
    """Never patch, stop, unregister, or mutate a third-party add-on."""
    return None

def _install_legacy_compatibility_shim() -> None:
    """Install only missing legacy RNA; never replace a live external property."""
    _disable_standalone_sync_runtime()
    try:
        if not _scene_compat_property_exists():
            bpy.types.Scene.synch_settings = bpy.props.PointerProperty(
                type=SWS_LegacySynchronizeWorkspacesDisabledSettings,
                name=_COMPAT_SCENE_PROP_NAME,
                description=_COMPAT_SCENE_PROP_DESCRIPTION,
            )
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WorkSpace, "synch_active"):
            bpy.types.WorkSpace.synch_active = bpy.props.BoolProperty(
                name="Legacy Synchronize Workspaces Disabled",
                description="Compatibility placeholder for stale standalone Synchronize Workspaces callbacks.",
                default=False,
                get=_legacy_bool_false,
                set=_legacy_bool_ignore,
            )
    except Exception:
        pass
    _disable_standalone_sync_runtime()


class SMART_WORKSPACE_OT_set_synchronize_workspaces_enabled(Operator):
    bl_idname = "smart_workspace.set_synchronize_workspaces_enabled"
    bl_label = "Set Synchronize Workspaces"
    bl_description = "Enable or disable Synchronize Workspaces and save the setting immediately."
    bl_options = {"INTERNAL"}

    enabled: bpy.props.BoolProperty(default=True)

    @classmethod
    def description(cls, context, properties):
        try:
            return _tip(ENABLE_DESCRIPTION if bool(getattr(properties, "enabled", True)) else DISABLE_DESCRIPTION)
        except Exception:
            return _tip(TOOL_DESCRIPTION)

    def execute(self, context):
        desired = bool(getattr(self, "enabled", True))
        apply_enabled(desired, context=context, save=True)
        self.report({"INFO"}, ui_label("Synchronize Workspaces setting saved.", "ワークスペース同期の設定を保存しました。", context))
        return {"FINISHED"}


_CLASSES = (
    SWS_SynchronizeWorkspacesSettings,
    SWS_LegacySynchronizeWorkspacesDisabledSettings,
    SMART_WORKSPACE_OT_set_synchronize_workspaces_enabled,
)


def draw_settings_ui(layout, context) -> None:
    settings = _scene_settings(context)
    enabled = _is_enabled(context)
    col = layout.column(align=True)
    try:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context), icon="UV_SYNC_SELECT")
    except Exception:
        col.label(text=ui_label(TOOL_LABEL, TOOL_LABEL_JA, context))

    row = col.row(align=True)
    op = row.operator(SMART_WORKSPACE_OT_set_synchronize_workspaces_enabled.bl_idname, text=ui_label(ENABLE_LABEL, "有効", context), depress=enabled)
    op.enabled = True
    op = row.operator(SMART_WORKSPACE_OT_set_synchronize_workspaces_enabled.bl_idname, text=ui_label(DISABLE_LABEL, "無効", context), depress=not enabled)
    op.enabled = False
    try:
        status = ui_label("Current state: Enabled", "現在の状態: 有効", context) if enabled else ui_label("Current state: Disabled", "現在の状態: 無効", context)
        col.label(text=status, icon="CHECKMARK" if enabled else "X")
    except Exception:
        pass

    if settings is None:
        col.label(text=ui_label("Synchronization settings are unavailable.", "同期設定を取得できません。", context), icon="ERROR")
        return

    box = layout.box()
    box.label(text=ui_label("Synchronization Options", "同期オプション", context), icon="PREFERENCES")
    opt_col = box.column(align=True)
    opt_col.prop(settings, "shading_type", text=ui_label("Synchronize Shading Type", "シェーディングタイプも同期", context))
    opt_col.prop(settings, "shading_settings", text=ui_label("Synchronize Shading Settings", "シェーディング設定も同期", context))
    opt_col.prop(settings, "overlays", text=ui_label("Synchronize Overlays", "オーバーレイも同期", context))

    workspace_box = layout.box()
    workspace_box.label(text=ui_label("Workspace Inclusion", "同期対象ワークスペース", context), icon="WORKSPACE")
    for workspace in getattr(bpy.data, "workspaces", ()):
        try:
            workspace_box.prop(workspace, "sws_synchronize_workspaces_active", text=str(workspace.name), translate=False)
        except Exception:
            continue


def _orphan_sync_callback_noop(*_args, **_kwargs) -> None:
    return None


def _neutralize_stale_sync_function(fn) -> None:
    """Never mutate callback code or unregister an unproven generation."""
    return None


def _cleanup_orphan_sync_runtime() -> None:
    """Compatibility no-op; old generations are never scanned or patched."""
    return None

def _scene_compat_property_metadata() -> tuple[str, str, str]:
    """Inspect compatibility RNA at type level; never dereference Scene data."""
    try:
        scene_rna = getattr(bpy.types.Scene, "bl_rna", None)
        properties = getattr(scene_rna, "properties", None)
        prop = properties.get("synch_settings") if properties is not None else None
    except Exception:
        prop = None
    if prop is None:
        return "", "", ""
    try:
        fixed_type = getattr(prop, "fixed_type", None)
        fixed_identifier = str(getattr(fixed_type, "identifier", "") or "")
    except Exception:
        fixed_identifier = ""
    try:
        name = str(getattr(prop, "name", "") or "")
    except Exception:
        name = ""
    try:
        description = str(getattr(prop, "description", "") or "")
    except Exception:
        description = ""
    return fixed_identifier, name, description


def _scene_compat_property_exists() -> bool:
    fixed_identifier, name, description = _scene_compat_property_metadata()
    return bool(fixed_identifier or name or description)


def _compat_property_is_ours() -> bool:
    try:
        from .. import runtime_ledger as _runtime_ledger
        return bool(
            _runtime_ledger.property_recorded_current(bpy.types.Scene, 'synch_settings')
            and _runtime_ledger.property_recorded_current(bpy.types.WorkSpace, 'synch_active')
        )
    except Exception:
        return False

def ensure_registered() -> bool:
    """Register RNA/classes without loading settings or starting runtime work.

    The central Other Tools toggle can be changed before this optional module's
    section is opened.  Keeping registration separate from persistence loading
    prevents an older JSON value from overwriting the value the user just
    selected in that update callback.
    """
    global _LEGACY_COMPAT_CLASS_REGISTERED, _SHUTTING_DOWN, _REGISTERED
    _cleanup_orphan_sync_runtime()
    if _REGISTERED:
        return True
    _SHUTTING_DOWN = False
    _cleanup_previous_runtime()
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    try:
        bpy.app.translations.register(__name__, _TRANSLATIONS)
    except Exception:
        pass
    from .. import runtime_ledger as _runtime_ledger
    _REGISTERED_CLASSES.clear()
    for cls in _CLASSES:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='SYNCHRONIZE_WORKSPACES_CLASS',
        )
        if success:
            _REGISTERED_CLASSES.append(cls)
            if cls is SWS_LegacySynchronizeWorkspacesDisabledSettings:
                _LEGACY_COMPAT_CLASS_REGISTERED = True
        else:
            return False
    try:
        if not hasattr(bpy.types.WorkSpace, "sws_synchronize_workspaces_active"):
            bpy.types.WorkSpace.sws_synchronize_workspaces_active = bpy.props.BoolProperty(
                name="Synchronize This Workspace",
                description="Include this workspace in Smart Workspace Suite workspace synchronization. Disable it when this workspace should keep an independent 3D View state.",
                default=True,
                update=_workspace_update,
            )
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.Scene, "sws_synchronize_workspaces_settings"):
            bpy.types.Scene.sws_synchronize_workspaces_settings = bpy.props.PointerProperty(type=SWS_SynchronizeWorkspacesSettings)
    except Exception:
        pass
    try:
        _install_legacy_compatibility_shim()
    except Exception:
        pass
    _REGISTERED = bool(
        hasattr(bpy.types.Scene, "sws_synchronize_workspaces_settings")
        and hasattr(bpy.types.WorkSpace, "sws_synchronize_workspaces_active")
    )
    return _REGISTERED


def register() -> bool:
    global _SHUTTING_DOWN
    _SHUTTING_DOWN = False
    if not ensure_registered():
        return False
    _disable_sync_runtime()
    _load_persistent_sync_settings(getattr(bpy, "context", None))
    if _is_enabled(getattr(bpy, "context", None)):
        _enable_sync_runtime(initial_capture=False, first_interval=1.0)
    return True

def unregister() -> bool:
    global _SHUTTING_DOWN, _LEGACY_COMPAT_CLASS_REGISTERED, _REGISTERED
    _cleanup_orphan_sync_runtime()
    _SHUTTING_DOWN = True
    if _REGISTERED:
        _save_persistent_sync_settings(getattr(bpy, "context", None), force=True)
    _disable_standalone_sync_runtime()
    _disable_sync_runtime()
    try:
        from .. import runtime_ledger as _runtime_ledger
        if _runtime_ledger.property_recorded_current(bpy.types.Scene, "sws_synchronize_workspaces_settings"):
            del bpy.types.Scene.sws_synchronize_workspaces_settings
        if _runtime_ledger.property_recorded_current(bpy.types.WorkSpace, "sws_synchronize_workspaces_active"):
            del bpy.types.WorkSpace.sws_synchronize_workspaces_active
    except Exception:
        return False

    # Remove only the compatibility properties created by this module and only
    # when no standalone module remains.  Never replace/delete external RNA.
    if not list(_iter_standalone_sync_modules()) and _compat_property_is_ours():
        try:
            if _scene_compat_property_exists():
                del bpy.types.Scene.synch_settings
        except Exception:
            pass
        try:
            if hasattr(bpy.types.WorkSpace, "synch_active"):
                del bpy.types.WorkSpace.synch_active
        except Exception:
            pass

    for cls in reversed(_REGISTERED_CLASSES):
        if cls is SWS_LegacySynchronizeWorkspacesDisabledSettings and _compat_property_is_ours():
            continue
        if _runtime_ledger.class_recorded_current(cls):
            _runtime_ledger.unregister_class_exact(
                cls,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='SYNCHRONIZE_WORKSPACES_CLASS',
            )
    _REGISTERED_CLASSES.clear()
    _LEGACY_COMPAT_CLASS_REGISTERED = False
    _REGISTERED = False
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    return True


if __name__ == "__main__":
    register()
