# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import copy
import re

from mathutils import Vector


def safe_copy_settings(froms, to) -> None:
    """Copy writable RNA properties without operators or context overrides."""
    if froms is None or to is None:
        return
    try:
        props = getattr(getattr(froms, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        try:
            if bool(getattr(prop, 'is_readonly', False)):
                continue
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier in {'rna_type', 'type', 'show_locked_time'}:
                continue
            if re.match(r'^show_region_', identifier):
                continue
            value = getattr(froms, identifier)
            try:
                value = copy.copy(value)
            except Exception:
                pass
            setattr(to, identifier, value)
        except Exception:
            continue


# Backward-compatible helper name used by the original bundled code.
def copy_settings(froms, to) -> None:
    safe_copy_settings(froms, to)


def side_view_axis_from_rotation(rotation) -> str:
    """Return the nearest Blender side-view axis name for a view rotation."""
    axis = 'FRONT'
    try:
        back_vec = rotation @ Vector((0.0, 0.0, -1.0))
        if back_vec.y > 0.9:
            axis = 'FRONT'
        elif back_vec.y < -0.9:
            axis = 'BACK'
        elif back_vec.x > 0.9:
            axis = 'LEFT'
        elif back_vec.x < -0.9:
            axis = 'RIGHT'
        elif back_vec.z > 0.9:
            axis = 'BOTTOM'
        elif back_vec.z < -0.9:
            axis = 'TOP'
    except Exception:
        pass
    return axis


def apply_side_view_without_operator(region_3d, rotation) -> None:
    """Preserve the original side-view intent using only RNA assignments."""
    if region_3d is None:
        return
    try:
        region_3d.view_rotation = copy.copy(rotation)
    except Exception:
        pass
    try:
        region_3d.view_perspective = 'ORTHO'
    except Exception:
        pass


# Backward-compatible helper name.  It intentionally does not call bpy.ops.
def setView(area, rotation) -> None:
    try:
        for space in getattr(area, 'spaces', ()) or ():
            if getattr(space, 'type', None) == 'VIEW_3D':
                apply_side_view_without_operator(getattr(space, 'region_3d', None), rotation)
                return
    except Exception:
        return
