# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

"""Apply viewport settings through the editor's writable RNA surface."""
from copy import copy
from mathutils import Vector

_READONLY_BY_CONTRACT = {"rna_type", "type", "show_locked_time"}
_VIEW_AXES = ((1, 1, "FRONT"), (1, -1, "BACK"), (0, 1, "LEFT"),
              (0, -1, "RIGHT"), (2, 1, "BOTTOM"), (2, -1, "TOP"))


def safe_copy_settings(froms, to):
    if froms is None or to is None:
        return
    try:
        settings = froms.bl_rna.properties
    except Exception:
        return
    for setting in settings:
        try:
            name = setting.identifier
            if (setting.is_readonly or not name or name in _READONLY_BY_CONTRACT
                    or name.startswith("show_region_")):
                continue
            value = getattr(froms, name)
            try:
                value = copy(value)
            except Exception:
                pass
            setattr(to, name, value)
        except Exception:
            continue


def copy_settings(froms, to):
    safe_copy_settings(froms, to)


def side_view_axis_from_rotation(rotation):
    try:
        direction = rotation @ Vector((0.0, 0.0, -1.0))
        for index, sign, axis in _VIEW_AXES:
            if sign * direction[index] > 0.9:
                return axis
    except Exception:
        pass
    return "FRONT"


def apply_side_view_without_operator(region_3d, rotation):
    if region_3d is None:
        return
    try:
        region_3d.view_rotation = copy(rotation)
    except Exception:
        pass
    try:
        region_3d.view_perspective = "ORTHO"
    except Exception:
        pass


def setView(area, rotation):
    try:
        for space in area.spaces:
            if space.type == "VIEW_3D":
                apply_side_view_without_operator(space.region_3d, rotation)
                break
    except Exception:
        return
