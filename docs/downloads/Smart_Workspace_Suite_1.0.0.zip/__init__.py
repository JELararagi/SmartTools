# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.

# Add-on bootstrap: Smart Workspace
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Blender Extension policy compatibility:
# Do not expose this extension as a top-level Python module.  Blender imports
# user_default extensions under its extension namespace, and registering an
# additional top-level alias such as ``smart_workspace_suite`` is reported in
# Preferences as a policy violation.  Remove only a stale alias that points back
# to this package path, which may remain in a live session after updating from
# older builds.
import sys as _sys
try:
    # Import only.  Runtime installation is performed after the exact-generation
    # ownership gate succeeds; import/reload must not mutate live Blender state.
    import importlib as _sws_importlib
    _sws_crash_guard = _sws_importlib.import_module(f"{__package__}.crash_guard")
except Exception:
    _sws_crash_guard = None
# Do not evict aliases or cached modules during import.  The external exact-
# identity ledger decides whether this generation may register; a live older
# generation is retained unchanged and yields a restart-required state.
_sws_policy_alias = None


# Blender's add-on manager attaches this field when it owns the module.
# Defining it early prevents a transient name-collision warning if Blender
# inspects the extension module while it is already present in sys.modules.
if '__addon_enabled__' not in globals():
    __addon_enabled__ = False

import traceback

import bpy
# No RNA/handler/timer changes occur at import time.


def _sws_dispose_stale_safety_submodules() -> None:
    """No-op: generation ownership is handled only by runtime_ledger.

    Import/reload must not scan sys.modules, cancel unproven callbacks, clear
    another generation's msgbus owner, or mutate displayed RNA.
    """
    return None



_sws_dispose_stale_safety_submodules()

from . import persistence
from . import blend_proxy_cleanup as _sws_blend_proxy_cleanup
from . import external_sync_guard as _sws_external_sync_guard
from . import ui_icons as _suite_ui_icons


# --- Toolset stale nested extension payload quarantine START ---
def _safe_purge_stale_nested_extension_payload() -> None:
    """Leave legacy package payloads byte-for-byte intact.

    Extension install directories are immutable release artifacts. Older
    nested payloads are ignored by the current flat entry point and may still
    be useful as read-only migration sources, so importing the add-on must not
    remove them from disk.
    """
    try:
        return None
    except Exception:
        return None

_safe_purge_stale_nested_extension_payload()
# --- Toolset stale nested extension payload quarantine END ---





# --- Toolset console-clean compatibility import START ---
try:
    from . import console_clean as _safe_console_clean
except Exception:
    _safe_console_clean = None
# No cleanup, keymap, Preferences, RNA, or timer mutation occurs at import.
# --- Toolset console-clean compatibility import END ---

# --- Toolset Smart Tools stale preference cleanup v20 START ---
def _safe_smart_tools_cleanup_stale_external_addons_v20() -> None:
    """No-op: never alter another Suite, user preferences, keymaps, or modules."""
    return None


_safe_smart_tools_cleanup_stale_external_addons_v20()
# --- Toolset Smart Tools stale preference cleanup v20 END ---

# --- Toolset stale wrapper quarantine START ---
def _safe_purge_stale_wrapper_artifacts() -> None:
    """No-op: module identity is not proof of ownership and is never purged."""
    return None


_safe_purge_stale_wrapper_artifacts()
# --- Toolset stale wrapper quarantine END ---

from . import runtime_compat as _runtime
_SUITE_SMART_TOOLS_BOOT_KEY = 'smart_workspace_suite'


def _safe_boot_desired_enabled(default: bool = True) -> bool:
    return bool(default)


def _safe_boot_preflight_cleanup(runtime_module, package_name, module_name, module_file):
    if runtime_module is None:
        return None
    try:
        if not _safe_boot_desired_enabled(True):
            return None
    except Exception:
        pass
    try:
        return runtime_module.preflight_cleanup(package_name, module_name, module_file)
    except TypeError:
        try:
            return runtime_module.preflight_cleanup(package_name, module_name, module_file, force=False)
        except Exception:
            return None
    except Exception:
        return None


bl_info = {
    "name": 'Smart Workspace',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Workspace",
    "description": "Commercial-ready Smart Workspace toolset for Blender 5.1 N-panel management, workspace state control, and integrated utilities.",
    "category": 'Smart Workspace',
}


# ------------------------------------------------------------------------------
# Duplicate-registration guard:
# If both an old wrapped package and this flattened package are installed,
# only the first one that registers becomes the active owner to avoid
# duplicate keymaps, handlers, and UI registrations.
# ------------------------------------------------------------------------------
def _sws_get_owner():
    """Compatibility result derived from exact active-generation identity."""
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        return _package_name() if _sws_runtime_ledger.current_generation() else None
    except Exception:
        return None




def _sws_set_owner(owner):
    """Deprecated compatibility no-op; runtime_ledger owns generation state."""
    del owner
    return None



def _sws_clear_owner(owner):
    """Deprecated compatibility no-op; never clear another generation."""
    del owner
    return None



def _package_name() -> str:
    package = str(__package__ or "").strip()
    return package or "smart_workspace_suite"


def _sws_can_register():
    """The final exact-generation gate is the sole registration authority."""
    return True



# Remove stale legacy files and previously-loaded legacy modules as early as
# possible. The flattened extension build must stay inside the package
# namespace only, so older top-level compatibility modules are removed instead
# of being reintroduced as aliases.
try:
    _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
except Exception:
    pass


def _cleanup_legacy_bootstrap_menu() -> None:
    try:
        from . import bootstrap as _bootstrap
    except Exception:
        return

    try:
        unregister_fn = getattr(_bootstrap, 'unregister', None)
        if callable(unregister_fn):
            unregister_fn()
    except Exception:
        pass

    try:
        remove_fn = getattr(_bootstrap, 'remove_window_menu_entries', None)
        if callable(remove_fn):
            remove_fn()
    except Exception:
        pass


def _prime_preferences_subgroups(context=None):
    prefs = None
    try:
        from . import preferences as _suite_preferences
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None)
        if callable(get_settings):
            prefs = get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        prefs = None

    if prefs is None:
        return None

    for attr_name in (
        'pin_update_interval',
        'auto_restore_on_file_load',
        'live_pin_follow_enabled',
        'launcher_operator_id',
        'hotbox_operator_id',
        'store_in_blend',
        'prefer_blend_config',
    ):
        try:
            getattr(prefs, attr_name)
        except Exception:
            pass
    return prefs


_SWS_REPAIR_TIMER_ATTEMPTS = 0
_FULL_RUNTIME_REGISTERED = False
_PREFERENCES_REGISTERED = False
_TRANSLATIONS_REGISTERED = False


def _sws_integrated_tools_are_active(context=None) -> bool:
    # Startup/repair timers must not auto-load every bundled tool.  Keeping this
    # false prevents repeated registration churn while Blender is drawing the
    # standard N-panel.
    return False

def _sws_loader_has_records() -> bool:
    try:
        from . import loader as _loader
        get_records = getattr(_loader, 'get_records', None)
        if callable(get_records):
            return bool(get_records() or [])
    except Exception:
        pass
    return False


def _sws_has_existing_smart_tools_contexts() -> bool:
    try:
        from .runtime import navigation_properties as _navigation_properties
        has_contexts = getattr(_navigation_properties, '_has_existing_smart_tools_contexts', None)
        if callable(has_contexts):
            return bool(has_contexts())
    except Exception:
        pass
    return False


def _sws_launcher_bootstrap_ready() -> bool:
    try:
        from .runtime import navigation_properties as _navigation_properties
        registry_fn = getattr(_navigation_properties, '_registry', None)
        if not callable(registry_fn):
            return False
        reg = registry_fn() or {}
        addon_key = 'smart_workspace_suite'
        nav_entries = reg.get('nav_entries') or {}
        panel_sources = reg.get('panel_sources') or {}
        proxy_panels = reg.get('proxy_panels') or {}
        return bool(nav_entries.get(addon_key)) and addon_key in panel_sources and addon_key in proxy_panels and bool(reg.get('window_menu_installed'))
    except Exception:
        return False


def _sws_launcher_runtime_needs_refresh() -> bool:
    try:
        from .runtime import navigation_properties as _navigation_properties
        if (not _sws_has_existing_smart_tools_contexts()) and _sws_launcher_bootstrap_ready():
            return False
        runtime_needs_refresh = getattr(_navigation_properties, 'runtime_needs_refresh', None)
        if callable(runtime_needs_refresh):
            return bool(runtime_needs_refresh('smart_workspace_suite'))
    except Exception:
        return not _sws_launcher_bootstrap_ready()
    return not _sws_launcher_bootstrap_ready()


def _sws_runtime_needs_repair(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None or not hasattr(wm, 'nptl_settings'):
        return True
    if _sws_launcher_runtime_needs_refresh():
        return True
    if _sws_integrated_tools_are_active(ctx) and not _sws_loader_has_records():
        return True
    return False


def _register_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    if _TRANSLATIONS_REGISTERED:
        return
    translation_dict = getattr(translation, 'translation_dict', None)
    if not isinstance(translation_dict, dict) or not translation_dict:
        return
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    try:
        bpy.app.translations.register(__name__, translation_dict)
        _TRANSLATIONS_REGISTERED = True
    except Exception:
        _TRANSLATIONS_REGISTERED = False
        raise


def _unregister_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    if not _TRANSLATIONS_REGISTERED:
        return
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    _TRANSLATIONS_REGISTERED = False


def _repair_workspace_suite_launcher_entry(context=None, *, force_reinstall: bool = False) -> bool:
    try:
        from .runtime import navigation_properties as _navigation_properties
        from .runtime import ui_operators as _ui_operators
    except Exception:
        return False

    addon_key = 'smart_workspace_suite'
    has_entry = False

    try:
        _ui_operators.prepare_properties_pseudo_tab_panels()
    except Exception:
        pass

    registry_fn = getattr(_navigation_properties, '_registry', None)
    if callable(registry_fn):
        try:
            reg = registry_fn() or {}
            has_entry = bool((reg.get('nav_entries') or {}).get(addon_key))
        except Exception:
            has_entry = False

    reinstall = bool(force_reinstall or not has_entry)
    if reinstall:
        installed = False
        install_fn = getattr(_ui_operators, 'install_properties_pseudo_tab_hack', None)
        if callable(install_fn):
            try:
                install_fn()
                installed = True
            except Exception:
                installed = False
        if not installed:
            direct_install = getattr(_navigation_properties, 'install', None)
            if callable(direct_install):
                try:
                    direct_install(
                        addon_key,
                        'Smart_Workspace',
                        'WINDOW',
                        'nptl.toggle_properties_pseudo_tab',
                        getattr(_ui_operators, '_PROPERTIES_PSEUDO_PANEL_CLASSES', ()),
                        order=110,
                    )
                    installed = True
                except Exception:
                    installed = False
        if not installed:
            return False

    try:
        ensure_shared_fn = getattr(_navigation_properties, 'ensure_shared_nav_button_operators', None)
        if callable(ensure_shared_fn):
            ensure_shared_fn()
    except Exception:
        pass

    has_existing_contexts = _sws_has_existing_smart_tools_contexts()
    needs_runtime_refresh = bool(force_reinstall)
    if not needs_runtime_refresh:
        if has_existing_contexts:
            runtime_needs_refresh = getattr(_navigation_properties, 'runtime_needs_refresh', None)
            if callable(runtime_needs_refresh):
                try:
                    needs_runtime_refresh = bool(runtime_needs_refresh(addon_key))
                except Exception:
                    needs_runtime_refresh = True
            else:
                needs_runtime_refresh = True
        else:
            needs_runtime_refresh = not _sws_launcher_bootstrap_ready()

    if not needs_runtime_refresh:
        if callable(registry_fn):
            try:
                reg = registry_fn() or {}
                return bool((reg.get('nav_entries') or {}).get(addon_key))
            except Exception:
                return False
        return True

    refresh_fn = getattr(_ui_operators, 'refresh_properties_pseudo_tab_runtime', None)
    if callable(refresh_fn):
        try:
            refresh_fn(context=context or getattr(bpy, 'context', None), reinstall=False)
        except Exception:
            pass

    try:
        normalize_fn = getattr(_navigation_properties, 'normalize_window_menu_entries', None)
        if callable(normalize_fn):
            normalize_fn(install_if_missing=True)
    except Exception:
        pass

    try:
        force_refresh_fn = getattr(_navigation_properties, 'force_runtime_refresh', None)
        if callable(force_refresh_fn):
            try:
                force_refresh_fn(preferred_owner=addon_key)
            except TypeError:
                force_refresh_fn()
    except Exception:
        pass

    try:
        sync_runtime_fn = getattr(_navigation_properties, 'sync_live_runtime_from_prefs', None)
        if callable(sync_runtime_fn):
            sync_runtime_fn(context or getattr(bpy, 'context', None))
    except Exception:
        pass

    try:
        repair_live_hosts_fn = getattr(_navigation_properties, 'repair_live_hosts_and_menu', None)
        if callable(repair_live_hosts_fn):
            try:
                repair_live_hosts_fn(context=context or getattr(bpy, 'context', None), reopen_window=False)
            except TypeError:
                try:
                    repair_live_hosts_fn(context or getattr(bpy, 'context', None), False)
                except TypeError:
                    repair_live_hosts_fn(context or getattr(bpy, 'context', None))
    except Exception:
        pass

    if callable(registry_fn):
        try:
            reg = registry_fn() or {}
            return bool((reg.get('nav_entries') or {}).get(addon_key))
        except Exception:
            return False
    return True


def _safe_unregister_runtime_modules() -> None:
    global _FULL_RUNTIME_REGISTERED
    try:
        tool_runtime.unregister()
    except Exception:
        pass
    try:
        runtime.unregister()
    except Exception:
        pass
    _FULL_RUNTIME_REGISTERED = False


def _safe_unregister_preferences_module() -> None:
    global _PREFERENCES_REGISTERED
    if not _PREFERENCES_REGISTERED:
        return
    try:
        preferences.unregister()
    except Exception:
        pass
    _PREFERENCES_REGISTERED = False


def ensure_full_runtime_loaded(context=None, *, reason: str = '', refresh_ui: bool = False) -> dict[str, object]:
    global _FULL_RUNTIME_REGISTERED

    if not _FULL_RUNTIME_REGISTERED:
        registered_runtime = []
        failures: list[tuple[str, BaseException, str]] = []

        try:
            runtime.register()
            registered_runtime.append(runtime)
        except Exception as exc:
            failures.append(('Smart Workspace Runtime', exc, traceback.format_exc()))

        if not failures:
            try:
                tool_runtime.register()
                registered_runtime.append(tool_runtime)
            except Exception as exc:
                failures.append(('Integrated Workspace Tools', exc, traceback.format_exc()))

        if failures:
            for mod in reversed(registered_runtime):
                try:
                    mod.unregister()
                except Exception:
                    pass
            _FULL_RUNTIME_REGISTERED = False
            raise failures[0][1]

        _FULL_RUNTIME_REGISTERED = True

        try:
            apply_tool_state = getattr(tool_runtime, 'apply_preference_runtime_state', None)
            if callable(apply_tool_state):
                apply_tool_state(context=context or getattr(bpy, 'context', None))
        except Exception:
            pass

    try:
        prepare_fn = getattr(runtime, 'prepare_runtime_for_use', None)
        if callable(prepare_fn):
            prepare_fn(context=context, refresh_ui=refresh_ui)
    except Exception:
        pass

    try:
        _repair_workspace_suite_launcher_entry(context=context, force_reinstall=bool(refresh_ui))
    except Exception:
        pass

    return {
        'runtime': runtime,
        'tool_runtime': tool_runtime,
    }


def ensure_runtime_initialized(context=None, *, refresh_ui: bool = True):
    modules_map = ensure_full_runtime_loaded(
        context=context or getattr(bpy, 'context', None),
        reason='ensure_runtime_initialized',
        refresh_ui=refresh_ui,
    )
    try:
        _sws_repair_runtime(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return modules_map


def _sws_repair_runtime(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)

    _prime_preferences_subgroups(ctx)

    try:
        _cleanup_legacy_bootstrap_menu()
    except Exception:
        pass

    needs_runtime_repair = _sws_runtime_needs_repair(ctx)

    try:
        apply_fn = getattr(runtime, 'apply_preference_runtime_state', None)
        if callable(apply_fn):
            apply_fn(context=ctx, startup=True)
    except Exception:
        pass

    if needs_runtime_repair:
        try:
            prepare_fn = getattr(runtime, 'prepare_runtime_for_use', None)
            if callable(prepare_fn):
                prepare_fn(context=ctx, refresh_ui=True)
        except Exception:
            pass

    try:
        _repair_workspace_suite_launcher_entry(context=ctx, force_reinstall=False)
    except Exception:
        pass

    try:
        apply_fn = getattr(tool_runtime, 'apply_preference_runtime_state', None)
        if callable(apply_fn):
            apply_fn(context=ctx)
    except Exception:
        pass


def _sws_runtime_repair_timer():
    global _SWS_REPAIR_TIMER_ATTEMPTS
    try:
        _sws_repair_runtime(bpy.context)
    except Exception:
        pass

    _SWS_REPAIR_TIMER_ATTEMPTS -= 1
    if _SWS_REPAIR_TIMER_ATTEMPTS > 0:
        return 0.25
    return None


def _schedule_runtime_repair(attempts: int = 1) -> None:
    # Crash-safe mode: do not schedule background runtime repair timers.
    global _SWS_REPAIR_TIMER_ATTEMPTS
    _SWS_REPAIR_TIMER_ATTEMPTS = 0
    try:
        if bpy.app.timers.is_registered(_sws_runtime_repair_timer):
            bpy.app.timers.unregister(_sws_runtime_repair_timer)
    except Exception:
        pass
    return None


# Safe import order to avoid circular imports.
import importlib as _safe_lazy_importlib


class _SUITE_LazyModuleProxy:
    __slots__ = ('_alias', '_relative_name')

    def __init__(self, alias: str, relative_name: str):
        self._alias = str(alias or '').strip()
        self._relative_name = str(relative_name or '').strip().strip('.')

    def _load(self):
        current = globals().get(self._alias)
        if not isinstance(current, _SUITE_LazyModuleProxy):
            return current
        module = _safe_lazy_importlib.import_module(f"{__package__}.{self._relative_name}")
        globals()[self._alias] = module
        return module

    def __getattr__(self, name):
        return getattr(self._load(), name)

    def __dir__(self):
        try:
            return dir(self._load())
        except Exception:
            return []


def _safe_lazy_module_proxy(alias: str, relative_name: str):
    return _SUITE_LazyModuleProxy(alias, relative_name)


translation = _safe_lazy_module_proxy('translation', 'translation')
preferences = _safe_lazy_module_proxy('preferences', 'preferences')
runtime = _safe_lazy_module_proxy('runtime', 'runtime')
tool_runtime = _safe_lazy_module_proxy('tool_runtime', 'tool_runtime')

modules = [
    preferences,
    runtime,
    tool_runtime,
]



_SWS_STARTUP_LOAD_PENDING = False


def _sws_deferred_startup_load():
    # Crash-safe mode: no deferred startup load.
    global _SWS_STARTUP_LOAD_PENDING
    _SWS_STARTUP_LOAD_PENDING = False
    return None


def _queue_startup_runtime_load(delay: float = 0.35) -> None:
    # Crash-safe mode: never queue startup timers that touch workspace/UI state.
    global _SWS_STARTUP_LOAD_PENDING
    _SWS_STARTUP_LOAD_PENDING = False
    try:
        if bpy.app.timers.is_registered(_sws_deferred_startup_load):
            bpy.app.timers.unregister(_sws_deferred_startup_load)
    except Exception:
        pass
    return None


def register():
    global _PREFERENCES_REGISTERED

    if not _sws_can_register():
        return

    try:
        if _sws_crash_guard is not None:
            _sws_crash_guard.install_runtime()
    except Exception:
        pass

    try:
        _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
    except Exception:
        pass

    try:
        _suite_ui_icons.register()
    except Exception:
        pass

    failures: list[tuple[str, BaseException, str]] = []
    translations_registered = False

    try:
        _cleanup_legacy_bootstrap_menu()

        try:
            preferences.register()
            _PREFERENCES_REGISTERED = True
        except Exception as exc:
            failures.append(('Smart Workspace Preferences', exc, traceback.format_exc()))

        if not failures:
            try:
                if persistence.register() is False:
                    raise RuntimeError('Persistent Settings Handlers registration failed')
            except Exception as exc:
                failures.append(('Persistent Settings Handlers', exc, traceback.format_exc()))

        if not failures:
            try:
                _register_translations()
                translations_registered = True
            except Exception as exc:
                failures.append(('Translations', exc, traceback.format_exc()))

        if not failures:
            _prime_preferences_subgroups(bpy.context)
            # Register the native Smart Workspace N-panel immediately, but use the
            # lightweight path that does not install redraw/refresh timers. This
            # keeps the Sidebar visible while preserving the viewport-lag fixes.
            try:
                sidebar_register = getattr(runtime, 'register_sidebar_runtime', None)
                if callable(sidebar_register):
                    sidebar_register()
            except Exception as exc:
                failures.append(('Smart Workspace N-panel', exc, traceback.format_exc()))
    except Exception as exc:
        failures.append(('Register', exc, traceback.format_exc()))

    if failures:
        try:
            if bpy.app.timers.is_registered(_sws_runtime_repair_timer):
                bpy.app.timers.unregister(_sws_runtime_repair_timer)
        except Exception:
            pass
        try:
            if bpy.app.timers.is_registered(_sws_deferred_startup_load):
                bpy.app.timers.unregister(_sws_deferred_startup_load)
        except Exception:
            pass
        try:
            persistence.unregister()
        except Exception:
            pass
        _safe_unregister_runtime_modules()
        _safe_unregister_preferences_module()
        if translations_registered:
            _unregister_translations()
        else:
            try:
                _unregister_translations()
            except Exception:
                pass
        try:
            _cleanup_legacy_bootstrap_menu()
        except Exception:
            pass
        try:
            _suite_ui_icons.unregister()
        except Exception:
            pass
        _sws_clear_owner(_package_name())
        raise failures[0][1]


def unregister():
    if _sws_get_owner() not in (None, _package_name()):
        return
    try:
        persistence.unregister()
    except Exception:
        pass
    try:
        try:
            if bpy.app.timers.is_registered(_sws_runtime_repair_timer):
                bpy.app.timers.unregister(_sws_runtime_repair_timer)
        except Exception:
            pass

        try:
            _cleanup_legacy_bootstrap_menu()
        except Exception:
            pass

        _safe_unregister_runtime_modules()
        _safe_unregister_preferences_module()
        _unregister_translations()
        try:
            _suite_ui_icons.unregister()
        except Exception:
            pass
    finally:
        _sws_clear_owner(_package_name())


# SUITE_TOOLTIP_AUDIT_WRAPPER_START
_ENABLE_TOOLTIP_AUDIT_ON_REGISTER = False

if _ENABLE_TOOLTIP_AUDIT_ON_REGISTER:
    from .runtime import tooltip_audit as _tooltip_audit

    try:
        _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER = register
        _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER = unregister
    except Exception:
        pass
    else:
        def register():
            _tooltip_audit.begin_runtime_audit()
            try:
                result = _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER()
            except Exception:
                _tooltip_audit.abort_runtime_audit()
                raise
            _tooltip_audit.finish_runtime_audit()
            return result

        def unregister():
            try:
                return _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER()
            finally:
                _tooltip_audit.clear_runtime_audit()
# SUITE_TOOLTIP_AUDIT_WRAPPER_END


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()



# --- Toolset Smart Tools menu presence wrapper START ---
import importlib as _safe_smart_tools_importlib

_SUITE_SMART_TOOLS_SUITE_KEY = 'smart_workspace_suite'
_SUITE_SMART_TOOLS_SHARED_MODULE_CANDIDATES = ('.runtime.navigation_properties',)


def _safe_smart_tools_import_shared_menu_module():
    for module_name in _SUITE_SMART_TOOLS_SHARED_MODULE_CANDIDATES:
        try:
            return _safe_smart_tools_importlib.import_module(module_name, __package__)
        except Exception:
            continue
    return None


def _safe_smart_tools_sync_menu_presence(installed: bool) -> None:
    module = _safe_smart_tools_import_shared_menu_module()
    if module is None:
        return
    try:
        marker = getattr(module, 'mark_suite_presence', None)
        if callable(marker):
            marker(_SUITE_SMART_TOOLS_SUITE_KEY, bool(installed))
    except Exception:
        pass
    try:
        if bool(installed):
            ensured = False
            ensure_fn = getattr(module, 'ensure_shared_window_menu_button', None)
            if callable(ensure_fn):
                try:
                    ensured = bool(ensure_fn(force=False))
                except Exception:
                    ensured = False
            if not ensured:
                refresh_fn = getattr(module, 'schedule_shared_window_menu_button_refresh', None)
                if callable(refresh_fn):
                    refresh_fn()
        else:
            remove_fn = getattr(module, 'remove_shared_window_menu_button_if_unused', None)
            if callable(remove_fn):
                remove_fn()
    except Exception:
        pass


try:
    _SUITE_SMART_TOOLS_ORIG_REGISTER = register
    _SUITE_SMART_TOOLS_ORIG_UNREGISTER = unregister
except Exception:
    pass
else:
    def register():
        result = _SUITE_SMART_TOOLS_ORIG_REGISTER()
        _safe_smart_tools_sync_menu_presence(True)
        return result


    def unregister():
        try:
            return _SUITE_SMART_TOOLS_ORIG_UNREGISTER()
        finally:
            _safe_smart_tools_sync_menu_presence(False)
# --- Toolset Smart Tools menu presence wrapper END ---



# --- Toolset Smart Tools always-active runtime bridge START ---
# Copyright (C) 2026 JELararagi.
def _smart_tools_always_active_call(fn, *args, **kwargs):
    if not callable(fn):
        return None
    try:
        return fn(*args, **kwargs)
    except TypeError:
        try:
            return fn(*args)
        except TypeError:
            try:
                return fn()
            except Exception:
                return None
        except Exception:
            return None
    except Exception:
        return None


def _smart_tools_always_active_import_props_module():
    try:
        import importlib
    except Exception:
        return None
    rel_names = (
        'navigation_properties',
        'cloth_suite.navigation_properties',
        'suite_core.navigation_properties',
        'smart_sculpt_suite.navigation_properties',
        'runtime.navigation_properties',
        'sms_properties_pseudo',
        'ms_properties_pseudo',
    )
    for rel_name in rel_names:
        try:
            module = importlib.import_module(f"{__package__}.{rel_name}")
        except Exception:
            continue
        if module is not None:
            return module
    return None


def _smart_tools_always_active_package_key() -> str:
    for value in (globals().get('_SUITE_SMART_TOOLS_SUITE_KEY'), __package__, __name__, 'smart_tools'):
        text = str(value or '').strip().strip('.')
        if text:
            return text.rsplit('.', 1)[-1]
    return 'smart_tools'


def _smart_tools_runtime_active(context=None) -> bool:
    del context
    return True


def _smart_tools_runtime_activate(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    props_mod = _smart_tools_always_active_import_props_module()
    if props_mod is not None:
        for name in (
            'ensure_shared_nav_button_operators',
            'force_runtime_refresh',
            'refresh_ui_runtime',
            'sync_live_runtime_from_prefs',
            'flush_redraws',
            '_tag_redraws',
            '_tag_redraw_all_properties_areas',
        ):
            fn = getattr(props_mod, name, None)
            if not callable(fn):
                continue
            if name == 'force_runtime_refresh':
                try:
                    fn(preferred_owner=_smart_tools_always_active_package_key())
                    continue
                except TypeError:
                    pass
            _smart_tools_always_active_call(fn, ctx)
    for name, value in list(globals().items()):
        if callable(value) and str(name).endswith('_repair_runtime'):
            _smart_tools_always_active_call(value, ctx)
    return True


def _smart_tools_v26_import_props_module():
    return _smart_tools_always_active_import_props_module()


def _smart_tools_v27_import_props_module():
    return _smart_tools_always_active_import_props_module()


def _smart_tools_v29_import_props_module():
    return _smart_tools_always_active_import_props_module()


def _smart_tools_v34_props_module():
    return _smart_tools_always_active_import_props_module()


def _smart_tools_v34_suite_key() -> str:
    return _smart_tools_always_active_package_key()


try:
    _SMART_TOOLS_ALWAYS_ACTIVE_ORIG_REGISTER = register
except Exception:
    _SMART_TOOLS_ALWAYS_ACTIVE_ORIG_REGISTER = None
if callable(_SMART_TOOLS_ALWAYS_ACTIVE_ORIG_REGISTER) and not getattr(_SMART_TOOLS_ALWAYS_ACTIVE_ORIG_REGISTER, '_smart_tools_always_active_wrapped', False):
    def register():
        # Performance-first startup: do not auto-activate the Smart Tools runtime.
        # Full runtime repair/refresh imports several UI modules and can tag redraws
        # during viewport initialization, which increases first-drag latency.
        return _SMART_TOOLS_ALWAYS_ACTIVE_ORIG_REGISTER()
    register._smart_tools_always_active_wrapped = True
# --- Toolset Smart Tools always-active runtime bridge END ---

# --- Toolset Smart Tools canonical identity/nav bridge v430 START ---
# Copyright (C) 2026 JELararagi.
_SUITE_SMART_TOOLS_SUITE_KEY = 'smart_workspace_suite'
_SUITE_SMART_TOOLS_SUITE_LABEL = 'Smart Workspace'
_SUITE_SMART_TOOLS_SUITE_ICON = 'WINDOW'
_SUITE_SMART_TOOLS_SUITE_ORDER = 20
_SMART_TOOLS_V430_CANONICAL_SUITE_NAV = {
    'addon_key': _SUITE_SMART_TOOLS_SUITE_KEY,
    'label': _SUITE_SMART_TOOLS_SUITE_LABEL,
    'icon': _SUITE_SMART_TOOLS_SUITE_ICON,
    'order': _SUITE_SMART_TOOLS_SUITE_ORDER,
}


def _smart_tools_v430_nav_state(nav=None):
    state = dict(nav or {}) if isinstance(nav, dict) else {}
    state['addon_key'] = _SUITE_SMART_TOOLS_SUITE_KEY
    state['label'] = _SUITE_SMART_TOOLS_SUITE_LABEL
    state['icon'] = _SUITE_SMART_TOOLS_SUITE_ICON
    state['order'] = int(_SUITE_SMART_TOOLS_SUITE_ORDER)
    return state


def _smart_tools_v430_fix_props_registry_nav(context=None) -> bool:
    props_mod = None
    for fn_name in ('_smart_tools_v32_props_module', '_smart_tools_v34_props_module', '_smart_tools_v29_import_props_module', '_smart_tools_v26_import_props_module', '_smart_tools_v27_import_props_module'):
        fn = globals().get(fn_name)
        if callable(fn):
            try:
                props_mod = fn()
                if props_mod is not None:
                    break
            except Exception:
                props_mod = None
    if props_mod is None:
        return False
    try:
        canon = getattr(props_mod, '_smart_tools_v430_canonicalize_nav_entries', None)
        if callable(canon):
            canon()
    except Exception:
        pass
    reg = None
    try:
        reg_fn = globals().get('_smart_tools_v32_registry') or globals().get('_smart_tools_v29_registry')
        if callable(reg_fn):
            reg = reg_fn(props_mod)
    except Exception:
        reg = None
    if not isinstance(reg, dict):
        try:
            reg_fn = getattr(props_mod, '_registry', None)
            reg = reg_fn() if callable(reg_fn) else None
        except Exception:
            reg = None
    if not isinstance(reg, dict):
        return False
    nav_entries = reg.setdefault('nav_entries', {})
    if not isinstance(nav_entries, dict):
        nav_entries = {}
        reg['nav_entries'] = nav_entries
    # Merge stale module-id entries into the canonical key.
    for raw_key, raw_entry in list(nav_entries.items()):
        raw_text = str(raw_key or '')
        if raw_text != _SUITE_SMART_TOOLS_SUITE_KEY and _SUITE_SMART_TOOLS_SUITE_KEY in raw_text:
            entry = raw_entry if isinstance(raw_entry, dict) else {}
            merged = dict(nav_entries.get(_SUITE_SMART_TOOLS_SUITE_KEY) or {})
            merged.update(entry)
            nav_entries[_SUITE_SMART_TOOLS_SUITE_KEY] = merged
            try:
                del nav_entries[raw_key]
            except Exception:
                pass
    entry = nav_entries.get(_SUITE_SMART_TOOLS_SUITE_KEY)
    if not isinstance(entry, dict):
        entry = {}
        nav_entries[_SUITE_SMART_TOOLS_SUITE_KEY] = entry
    entry.update(_smart_tools_v430_nav_state(entry))
    try:
        factory = getattr(props_mod, '_shared_nav_button_operator_class', None)
        if callable(factory):
            cls = factory(_SUITE_SMART_TOOLS_SUITE_KEY, _SUITE_SMART_TOOLS_SUITE_LABEL)
            op_id = str(getattr(cls, 'bl_idname', '') or '').strip() if isinstance(cls, type) else ''
            if op_id:
                entry['button_operator_id'] = op_id
    except Exception:
        pass
    try:
        reg['preferred_owner'] = _SUITE_SMART_TOOLS_SUITE_KEY
    except Exception:
        pass
    return True

try:
    _SMART_TOOLS_V430_ORIG_V32_CAPTURE_NAV = _smart_tools_v32_capture_nav_snapshot
except Exception:
    _SMART_TOOLS_V430_ORIG_V32_CAPTURE_NAV = None
if callable(_SMART_TOOLS_V430_ORIG_V32_CAPTURE_NAV) and not getattr(_SMART_TOOLS_V430_ORIG_V32_CAPTURE_NAV, '_smart_tools_v430_wrapped', False):
    def _smart_tools_v32_capture_nav_snapshot(context=None):
        try:
            state = _SMART_TOOLS_V430_ORIG_V32_CAPTURE_NAV(context)
        except Exception:
            state = {}
        state = _smart_tools_v430_nav_state(state)
        globals()['_smart_tools_v32_cached_nav'] = state
        return state
    _smart_tools_v32_capture_nav_snapshot._smart_tools_v430_wrapped = True

try:
    _SMART_TOOLS_V430_ORIG_V33_INSTALL_MINIMAL = _smart_tools_v33_install_minimal_bootstrap
except Exception:
    _SMART_TOOLS_V430_ORIG_V33_INSTALL_MINIMAL = None
if callable(_SMART_TOOLS_V430_ORIG_V33_INSTALL_MINIMAL) and not getattr(_SMART_TOOLS_V430_ORIG_V33_INSTALL_MINIMAL, '_smart_tools_v430_wrapped', False):
    def _smart_tools_v33_install_minimal_bootstrap(context=None):
        globals()['_smart_tools_v32_cached_nav'] = _smart_tools_v430_nav_state(globals().get('_smart_tools_v32_cached_nav'))
        result = _SMART_TOOLS_V430_ORIG_V33_INSTALL_MINIMAL(context)
        try:
            _smart_tools_v430_fix_props_registry_nav(context)
        except Exception:
            pass
        return result
    _smart_tools_v33_install_minimal_bootstrap._smart_tools_v430_wrapped = True
    globals()['_smart_tools_v32_install_minimal_bootstrap'] = _smart_tools_v33_install_minimal_bootstrap

try:
    _SMART_TOOLS_V430_ORIG_V34_SUITE_KEY = _smart_tools_v34_suite_key
except Exception:
    _SMART_TOOLS_V430_ORIG_V34_SUITE_KEY = None
def _smart_tools_v34_suite_key() -> str:
    return _SUITE_SMART_TOOLS_SUITE_KEY

try:
    _SMART_TOOLS_V430_ORIG_REGISTER = register
except Exception:
    _SMART_TOOLS_V430_ORIG_REGISTER = None
if callable(_SMART_TOOLS_V430_ORIG_REGISTER) and not getattr(_SMART_TOOLS_V430_ORIG_REGISTER, '_smart_tools_v430_wrapped', False):
    def register():
        # Performance-first startup: skip canonical navigation registry repair on
        # add-on enable. It imports runtime navigation code and can force UI redraws.
        return _SMART_TOOLS_V430_ORIG_REGISTER()
    register._smart_tools_v430_wrapped = True
# --- Toolset Smart Tools canonical identity/nav bridge v430 END ---

# --- Toolset Smart Tools nav materializer/header safety v440 START ---
# Copyright (C) 2026 JELararagi.
_SUITE_SMART_TOOLS_SUITE_KEY = 'smart_workspace_suite'
_SUITE_SMART_TOOLS_SUITE_LABEL = 'Smart Workspace'
_SUITE_SMART_TOOLS_SUITE_ICON = 'WINDOW'
_SUITE_SMART_TOOLS_SUITE_ORDER = 20
_SUITE_SMART_TOOLS_SUITE_OPERATOR_ID = globals().get('_PROXY_OPERATOR_ID', '') or globals().get('_OPERATOR_ID', '') or ''


def _smart_tools_v440_import_props_candidates():
    try:
        import importlib as _st_v440_importlib
    except Exception:
        return []
    modules = []
    for _rel in ('navigation_properties', 'sms_properties_pseudo', 'ms_properties_pseudo', 'cloth_suite.navigation_properties', 'suite_core.navigation_properties', 'runtime.navigation_properties'):
        try:
            _mod = _st_v440_importlib.import_module(f"{__package__}.{_rel}")
        except Exception:
            continue
        if _mod is not None and _mod not in modules:
            modules.append(_mod)
    return modules


def _smart_tools_v440_nav_payload():
    return {
        'addon_key': _SUITE_SMART_TOOLS_SUITE_KEY,
        'label': _SUITE_SMART_TOOLS_SUITE_LABEL,
        'icon': _SUITE_SMART_TOOLS_SUITE_ICON,
        'order': int(_SUITE_SMART_TOOLS_SUITE_ORDER),
        'operator_id': str(_SUITE_SMART_TOOLS_SUITE_OPERATOR_ID or ''),
    }


def _smart_tools_v440_direct_registry_nav(_mod) -> bool:
    payload = _smart_tools_v440_nav_payload()
    reg = None
    try:
        reg_fn = getattr(_mod, '_registry', None) or getattr(_mod, '_v9_registry_prepare', None)
        reg = reg_fn() if callable(reg_fn) else None
    except Exception:
        reg = None
    if not isinstance(reg, dict):
        return False
    try:
        nav_entries = reg.setdefault('nav_entries', {})
        if not isinstance(nav_entries, dict):
            nav_entries = {}
            reg['nav_entries'] = nav_entries
        entry = nav_entries.get(_SUITE_SMART_TOOLS_SUITE_KEY)
        if not isinstance(entry, dict):
            entry = {}
            nav_entries[_SUITE_SMART_TOOLS_SUITE_KEY] = entry
        entry.update({
            'label': payload['label'],
            'icon': payload['icon'],
            'order': payload['order'],
            'operator_id': payload['operator_id'],
        })
        try:
            factory = getattr(_mod, '_shared_nav_button_operator_class', None)
            if callable(factory):
                _cls = factory(_SUITE_SMART_TOOLS_SUITE_KEY, _SUITE_SMART_TOOLS_SUITE_LABEL)
                _op_id = str(getattr(_cls, 'bl_idname', '') or '').strip() if isinstance(_cls, type) else ''
                if _op_id:
                    entry['button_operator_id'] = _op_id
        except Exception:
            pass
        reg.setdefault('panel_sources', {}).setdefault(_SUITE_SMART_TOOLS_SUITE_KEY, tuple())
        reg['preferred_owner'] = reg.get('preferred_owner') or _SUITE_SMART_TOOLS_SUITE_KEY
        return True
    except Exception:
        return False


def _smart_tools_v440_ensure_nav_entry(context=None) -> bool:
    payload = _smart_tools_v440_nav_payload()
    ok = False
    for _mod in _smart_tools_v440_import_props_candidates():
        try:
            canon = getattr(_mod, '_smart_tools_v440_canonicalize_existing_nav', None) or getattr(_mod, '_smart_tools_v430_canonicalize_nav_entries', None)
            if callable(canon):
                canon()
        except Exception:
            pass
        try:
            marker = getattr(_mod, 'mark_suite_presence', None)
            if callable(marker):
                marker(_SUITE_SMART_TOOLS_SUITE_KEY, True)
        except Exception:
            pass
        try:
            ensure_ops = getattr(_mod, 'ensure_shared_nav_button_operators', None)
            if callable(ensure_ops):
                ensure_ops()
        except Exception:
            pass
        # Direct registry materialization is used first so startup-safe shims that
        # do not expose install() can still show Modeling/Modifier nav buttons.
        try:
            ok = _smart_tools_v440_direct_registry_nav(_mod) or ok
        except Exception:
            pass
        # Public install/refresh APIs repair the shared UI surface when available.
        for _fn_name in ('install', 'refresh_runtime', 'refresh_entry'):
            _fn = getattr(_mod, _fn_name, None)
            if not callable(_fn):
                continue
            try:
                _fn(payload['addon_key'], payload['label'], payload['icon'], payload['operator_id'], tuple(), order=payload['order'])
                ok = True
                break
            except TypeError:
                try:
                    _fn(payload['addon_key'], payload['label'], payload['icon'], payload['operator_id'], tuple(), payload['order'])
                    ok = True
                    break
                except Exception:
                    pass
            except Exception:
                pass
        for _fn_name in ('_install_header_draw_wrapper', '_install_context_header_overlay', '_install_navigation_bar_draw_wrapper', '_install_foreign_panel_hider', 'force_runtime_refresh', 'flush_redraws'):
            _fn = getattr(_mod, _fn_name, None)
            if not callable(_fn):
                continue
            try:
                if _fn_name == 'force_runtime_refresh':
                    try:
                        _fn(preferred_owner=_SUITE_SMART_TOOLS_SUITE_KEY)
                    except TypeError:
                        _fn(_SUITE_SMART_TOOLS_SUITE_KEY)
                else:
                    _fn()
            except Exception:
                pass
    return bool(ok)


def _smart_tools_v440_preinstall_header_guard() -> None:
    for _mod in _smart_tools_v440_import_props_candidates():
        for _fn_name in ('_install_header_draw_wrapper', '_install_context_header_overlay'):
            try:
                _fn = getattr(_mod, _fn_name, None)
                if callable(_fn):
                    _fn()
            except Exception:
                pass

try:
    _SMART_TOOLS_V440_ORIG_REGISTER = register
except Exception:
    _SMART_TOOLS_V440_ORIG_REGISTER = None
if callable(_SMART_TOOLS_V440_ORIG_REGISTER) and not getattr(_SMART_TOOLS_V440_ORIG_REGISTER, '_smart_tools_v440_wrapped', False):
    def register():
        # Performance-first startup: do not materialize or refresh navigation/header
        # runtime at add-on enable. These repairs remain callable from explicit
        # runtime operations, but they must not run during viewport startup.
        try:
            if _SUITE_SMART_TOOLS_SUITE_KEY == 'smart_transform_suite':
                _smart_tools_v440_preinstall_header_guard()
        except Exception:
            pass
        return _SMART_TOOLS_V440_ORIG_REGISTER()
    register._smart_tools_v440_wrapped = True


for _smart_tools_v440_min_name in ('_smart_tools_v33_install_minimal_bootstrap', '_smart_tools_v32_install_minimal_bootstrap', '_smart_tools_v430_fix_props_registry_nav'):
    _smart_tools_v440_min_fn = globals().get(_smart_tools_v440_min_name)
    if callable(_smart_tools_v440_min_fn) and not getattr(_smart_tools_v440_min_fn, '_smart_tools_v440_wrapped', False):
        def _smart_tools_v440_make_min_wrapper(_orig):
            def _wrapped(*args, **kwargs):
                result = _orig(*args, **kwargs)
                try:
                    _smart_tools_v440_ensure_nav_entry(args[0] if args else kwargs.get('context', getattr(bpy, 'context', None)))
                except Exception:
                    pass
                return result
            _wrapped._smart_tools_v440_wrapped = True
            _wrapped._smart_tools_v440_original = _orig
            return _wrapped
        globals()[_smart_tools_v440_min_name] = _smart_tools_v440_make_min_wrapper(_smart_tools_v440_min_fn)

try:
    # Only Smart Transform needs the header guard before its original activation path.
    if _SUITE_SMART_TOOLS_SUITE_KEY == 'smart_transform_suite':
        _smart_tools_v440_preinstall_header_guard()
except Exception:
    pass
# --- Toolset Smart Tools nav materializer/header safety v440 END ---

# --- Toolset standard N-panel open-by-default wrapper START ---
# Copyright (C) 2026 JELararagi.

def _safe_npanel_open_default_context():
    try:
        return bpy.context
    except Exception:
        return None


def _safe_npanel_open_default_call(fn, context=None):
    if not callable(fn):
        return None
    ctx = context or _safe_npanel_open_default_context()
    for args, kwargs in (
        ((ctx,), {'force': False}),
        ((ctx,), {'refresh_ui': True}),
        ((ctx,), {}),
        ((), {'context': ctx}),
        ((), {}),
    ):
        try:
            return fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            return None
    return None


def _safe_npanel_open_default_activate(context=None):
    ctx = context or _safe_npanel_open_default_context()
    package_key = str(__package__ or __name__ or '').rsplit('.', 1)[-1]

    # Smart Render must not load the heavy integrated runtime at enable time.
    # Register only its lightweight settings UI so the N-panel is populated
    # immediately without the startup freeze caused by tools_runtime.
    if package_key == 'smart_render_suite':
        try:
            _reg = globals().get('registration')
            _register = getattr(_reg, 'register', None)
            if callable(_register):
                _register()
        except Exception:
            pass
        try:
            _repair = globals().get('_srs_repair_runtime')
            if callable(_repair):
                _repair(ctx)
        except Exception:
            pass
        try:
            _schedule = globals().get('_schedule_runtime_repair')
            if callable(_schedule):
                _schedule(attempts=2)
        except Exception:
            pass
        return True

    for _name in (
        'ensure_runtime_initialized',
        'ensure_full_runtime_loaded',
        '_sf_ensure_full_runtime_loaded',
        '_ensure_full_runtime_loaded',
    ):
        _fn = globals().get(_name)
        if callable(_fn):
            _safe_npanel_open_default_call(_fn, ctx)

    for _name, _fn in list(globals().items()):
        try:
            if callable(_fn) and str(_name).endswith('_repair_runtime'):
                _safe_npanel_open_default_call(_fn, ctx)
        except Exception:
            pass
    try:
        _schedule = globals().get('_schedule_runtime_repair')
        if callable(_schedule):
            _schedule(attempts=2)
    except Exception:
        pass
    return True


try:
    _SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER = register
    _SUITE_NPANEL_OPEN_DEFAULT_ORIG_UNREGISTER = unregister
except Exception:
    pass
else:
    if callable(_SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER) and not getattr(_SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER, '_safe_npanel_open_default_wrapped', False):
        def register():
            result = _SUITE_NPANEL_OPEN_DEFAULT_ORIG_REGISTER()
            # Performance mode: avoid synchronous full-runtime activation during
            # add-on enable. This prevents startup/install stalls and avoids
            # background handlers touching the 3D View before the user acts.
            return result
        register._safe_npanel_open_default_wrapped = True

# --- Toolset standard N-panel open-by-default wrapper END ---

# --- Toolset console-clean final wrapper v60 START ---
try:
    _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60
except NameError:
    _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60 = register
    _SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60 = unregister if 'unregister' in globals() else None

    def _safe_console_clean_install_v60():
        try:
            from . import console_clean as _safe_console_clean
            _safe_console_clean.install()
        except Exception:
            pass

    def register():
        _safe_console_clean_install_v60()
        result = _SUITE_CONSOLE_CLEAN_ORIG_REGISTER_V60()
        _safe_console_clean_install_v60()
        return result

    def unregister():
        try:
            from . import console_clean as _safe_console_clean
            _safe_console_clean.sanitize_panel_draws()
        except Exception:
            pass
        if callable(_SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60):
            return _SUITE_CONSOLE_CLEAN_ORIG_UNREGISTER_V60()
        return None
# --- Toolset console-clean final wrapper v60 END ---

# -----------------------------------------------------------------------------
# Toolset standard N-panel runtime guard
# -----------------------------------------------------------------------------
# The suite now uses ordinary 3D View Sidebar panels.  These late definitions
# neutralize legacy SmartTools/Properties host repair paths while keeping old
# function names available for compatibility.

def _sws_standard_npanel_ready(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None or not hasattr(wm, 'nptl_settings'):
        return False
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        from .runtime import core as _sws_runtime_core
        from .runtime import ui_operators as _sws_ui_operators
        root_cls = getattr(_sws_ui_operators, 'NPTL_PT_properties_root', None)
        return bool(
            isinstance(root_cls, type)
            and _sws_runtime_ledger.class_is_current(root_cls)
            and _sws_runtime_ledger.property_is_current(
                bpy.types.WindowManager,
                'nptl_settings',
                _sws_runtime_core.NPTL_Settings,
            )
        )
    except Exception:
        return False


def _sws_launcher_bootstrap_ready() -> bool:
    return _sws_standard_npanel_ready(getattr(bpy, 'context', None))


def _sws_launcher_runtime_needs_refresh() -> bool:
    return not _sws_launcher_bootstrap_ready()


def _repair_workspace_suite_launcher_entry(context=None, *, force_reinstall: bool = False) -> bool:
    del force_reinstall
    try:
        from .runtime import ui_operators as _ui_operators
        prep = getattr(_ui_operators, 'prepare_properties_pseudo_tab_panels', None)
        if callable(prep):
            prep()
        cleanup = getattr(_ui_operators, 'install_properties_pseudo_tab_hack', None)
        if callable(cleanup):
            cleanup()
    except Exception:
        pass
    return _sws_standard_npanel_ready(context or getattr(bpy, 'context', None))


def _smart_tools_v440_ensure_nav_entry(context=None) -> bool:
    return _repair_workspace_suite_launcher_entry(context or getattr(bpy, 'context', None), force_reinstall=False)


def _smart_tools_v440_preinstall_header_guard() -> None:
    return None

# --- Smart Workspace same-session registration cleanup START ---
def _sws_force_unregister_stale_core_classes() -> None:
    """No-op: old displayed RNA/classes require a process restart.

    Exact current-generation rollback is performed by runtime_ledger only for
    classes that this registration transaction actually created.
    """
    return None

# --- Smart Workspace same-session registration cleanup END ---

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')
_SWS_VIEWPORT_OPTIMIZER_REGISTERED = False
_SWS_WORKSPACE_STEP_REORDER_REGISTERED = False
_SWS_SYNCHRONIZE_WORKSPACES_REGISTERED = False
_SWS_TAB_REPAIR_ATTEMPTS = 0
_SWS_OPTIONAL_UI_PENDING_TAGS: set[str] = set()
_SWS_OPTIONAL_UI_WARNED_KEYS: set[str] = set()
_SWS_OPTIONAL_UI_RETRY_GENERATION = ''
_SWS_OPTIONAL_UI_RETRY_FEATURE = 'optional-ui-registration-retry'



def _sws_consolidate_smart_workspace_tab(*, retire_standalone: bool = True) -> None:
    """Validate current classes only; never patch/unregister live panels."""
    del retire_standalone
    try:
        from .runtime import purge_duplicate_smart_workspace_view3d_panels as _validate
        _validate()
    except Exception:
        pass
    return None



def _sws_tab_repair_timer():
    """Compatibility one-shot terminator; no repair polling is permitted."""
    global _SWS_TAB_REPAIR_ATTEMPTS
    _SWS_TAB_REPAIR_ATTEMPTS = 0
    return None



def _sws_schedule_tab_consolidation(attempts: int = 5) -> None:
    """Run one synchronous identity-safe validation; install no timer."""
    del attempts
    global _SWS_TAB_REPAIR_ATTEMPTS
    _SWS_TAB_REPAIR_ATTEMPTS = 0
    try:
        if bpy.app.timers.is_registered(_sws_tab_repair_timer):
            bpy.app.timers.unregister(_sws_tab_repair_timer)
    except Exception:
        pass
    _sws_consolidate_smart_workspace_tab(retire_standalone=False)
    return None


def _sws_register_viewport_optimizer() -> bool:
    global _SWS_VIEWPORT_OPTIMIZER_REGISTERED
    if _SWS_VIEWPORT_OPTIMIZER_REGISTERED:
        return True
    from . import smart_viewport_optimizer_plus as _viewport_optimizer
    register_fn = getattr(_viewport_optimizer, 'register', None)
    if not callable(register_fn):
        return False
    if register_fn() is False:
        return False
    _SWS_VIEWPORT_OPTIMIZER_REGISTERED = True
    return True

def _sws_unregister_viewport_optimizer() -> bool:
    global _SWS_VIEWPORT_OPTIMIZER_REGISTERED
    if not _SWS_VIEWPORT_OPTIMIZER_REGISTERED:
        return True
    from . import smart_viewport_optimizer_plus as _viewport_optimizer
    unregister_fn = getattr(_viewport_optimizer, 'unregister', None)
    if not callable(unregister_fn) or unregister_fn() is False:
        return False
    _SWS_VIEWPORT_OPTIMIZER_REGISTERED = False
    return True

def _sws_register_workspace_step_reorder() -> bool:
    global _SWS_WORKSPACE_STEP_REORDER_REGISTERED
    from . import workspace_step_reorder as _workspace_step_reorder
    if _SWS_WORKSPACE_STEP_REORDER_REGISTERED:
        sync_fn = getattr(_workspace_step_reorder, 'sync_from_settings', None)
        if callable(sync_fn):
            sync_fn(getattr(bpy, 'context', None))
        return True
    register_fn = getattr(_workspace_step_reorder, 'register', None)
    if not callable(register_fn) or register_fn() is False:
        return False
    _SWS_WORKSPACE_STEP_REORDER_REGISTERED = True
    return True

def _sws_unregister_workspace_step_reorder() -> bool:
    global _SWS_WORKSPACE_STEP_REORDER_REGISTERED
    if not _SWS_WORKSPACE_STEP_REORDER_REGISTERED:
        return True
    from . import workspace_step_reorder as _workspace_step_reorder
    unregister_fn = getattr(_workspace_step_reorder, 'unregister', None)
    if not callable(unregister_fn) or unregister_fn() is False:
        return False
    _SWS_WORKSPACE_STEP_REORDER_REGISTERED = False
    return True

def _sws_register_synchronize_workspaces() -> bool:
    global _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED
    from . import synchronize_workspaces as _synchronize_workspaces
    if _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED:
        sync_fn = getattr(_synchronize_workspaces, 'sync_from_settings', None)
        if callable(sync_fn):
            sync_fn(getattr(bpy, 'context', None))
        return True
    register_fn = getattr(_synchronize_workspaces, 'register', None)
    if not callable(register_fn) or register_fn() is False:
        return False
    _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED = True
    return True

def _sws_unregister_synchronize_workspaces() -> bool:
    global _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED
    if not _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED:
        return True
    from . import synchronize_workspaces as _synchronize_workspaces
    unregister_fn = getattr(_synchronize_workspaces, 'unregister', None)
    if not callable(unregister_fn) or unregister_fn() is False:
        return False
    _SWS_SYNCHRONIZE_WORKSPACES_REGISTERED = False
    return True

def _sws_optional_ui_warning_once(tag: str, detail: str) -> None:
    """Emit one tagged degradation notice per generation and feature."""
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        generation = str(_sws_runtime_ledger.current_generation() or 'NO_GENERATION')
    except Exception:
        generation = 'NO_GENERATION'
    key = f'{generation}:{str(tag or "UNKNOWN")}'
    if key in _SWS_OPTIONAL_UI_WARNED_KEYS:
        return
    _SWS_OPTIONAL_UI_WARNED_KEYS.add(key)
    message = ' '.join(str(detail or 'registration unavailable').split())
    print(f'[Smart Workspace Suite][OPTIONAL_UI_DEGRADED:{tag}] {message}')


def _sws_register_workspace_manager() -> bool:
    from . import workspace_manager as _workspace_manager
    ctx = getattr(bpy, 'context', None)
    if not _workspace_manager.ensure_registered(ctx, refresh=False, restore=False):
        return False
    # Panel drawing never scans files, and the context of add-on enable cannot
    # write the save-state list at startup.
    _workspace_manager.queue_initial_refresh()
    return True


def _sws_optional_ui_attempt(tag: str) -> tuple[bool, str]:
    """Attempt one optional native registration without propagating failure."""
    try:
        if tag == 'WORKSPACE_MANAGER':
            return bool(_sws_register_workspace_manager()), 'Workspace Manager native RNA is not ready'
        if tag == 'PANVIEW_RNA':
            runtime_module = _sws_importlib.import_module(f'{__package__}.runtime')
            register_fn = getattr(runtime_module, 'ensure_panview_runtime', None)
            if not callable(register_fn):
                return False, 'ensure_panview_runtime is unavailable'
            return bool(register_fn()), 'Pan View native RNA is not ready'
        if tag == 'VIEWPORT_OPTIMIZER_RNA':
            return bool(_sws_register_viewport_optimizer()), 'Viewport Optimizer native RNA is not ready'
        if tag == 'WORKSPACE_STEP_REORDER':
            return bool(_sws_register_workspace_step_reorder()), 'Workspace Step Reorder is not ready'
        if tag == 'SYNCHRONIZE_WORKSPACES':
            return bool(_sws_register_synchronize_workspaces()), 'Synchronize Workspaces is not ready'
        if tag == 'FLOATING_WINDOW_LOCK':
            floating = _sws_importlib.import_module(f'{__package__}.floating_window_lock')
            register_fn = getattr(floating, 'register', None)
            if not callable(register_fn):
                return False, 'Floating Window Lock register API is unavailable'
            return register_fn() is not False, 'Floating Window Lock is not ready'
        if tag == 'PROXY_SAVE_PRE_LEASE':
            return _sws_blend_proxy_cleanup.register() is not False, 'RNA-only proxy save_pre lease is not ready'
        return False, f'unknown optional registration tag: {tag}'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {exc}'


def _sws_remove_optional_ui_retry_handler(handle, handler_list) -> None:
    try:
        while handle in handler_list:
            handler_list.remove(handle)
    except Exception:
        pass


def _sws_cancel_optional_ui_retry(*, clear_pending: bool = False) -> None:
    global _SWS_OPTIONAL_UI_RETRY_GENERATION
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        _sws_runtime_ledger.remove_feature_leases(
            _SWS_OPTIONAL_UI_RETRY_FEATURE,
            any_generation=False,
        )
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
        if handlers is not None:
            _sws_remove_optional_ui_retry_handler(_sws_optional_ui_retry_event, handlers)
    except Exception:
        pass
    _SWS_OPTIONAL_UI_RETRY_GENERATION = ''
    if clear_pending:
        _SWS_OPTIONAL_UI_PENDING_TAGS.clear()


def _sws_optional_ui_retry_event(_scene=None, _depsgraph=None):
    """Consume exactly one safe event and retry only the degraded features."""
    global _SWS_OPTIONAL_UI_RETRY_GENERATION
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        generation = str(_SWS_OPTIONAL_UI_RETRY_GENERATION or '')
        pending = tuple(sorted(_SWS_OPTIONAL_UI_PENDING_TAGS))
        # Remove the native handler and lease before any registration work.
        _sws_cancel_optional_ui_retry(clear_pending=False)
        if not generation or not _sws_runtime_ledger.generation_matches(generation):
            _SWS_OPTIONAL_UI_PENDING_TAGS.clear()
            return None
        failed: set[str] = set()
        for tag in pending:
            ok, _detail = _sws_optional_ui_attempt(tag)
            if not ok:
                failed.add(tag)
        _SWS_OPTIONAL_UI_PENDING_TAGS.clear()
        _SWS_OPTIONAL_UI_PENDING_TAGS.update(failed)
    except Exception:
        # Degraded optional features remain disabled; the Suite stays enabled.
        pass
    return None


def _sws_schedule_optional_ui_retry() -> bool:
    """Arm one generation-owned depsgraph event; never install a timer/poll."""
    global _SWS_OPTIONAL_UI_RETRY_GENERATION
    if not _SWS_OPTIONAL_UI_PENDING_TAGS:
        _sws_cancel_optional_ui_retry(clear_pending=True)
        return True
    try:
        from . import runtime_ledger as _sws_runtime_ledger
        generation = str(_sws_runtime_ledger.current_generation() or '')
        if not generation or not _sws_runtime_ledger.generation_matches(generation):
            return False
        handlers = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
        if handlers is None:
            return False
        _sws_cancel_optional_ui_retry(clear_pending=False)
        handlers.append(_sws_optional_ui_retry_event)
        _SWS_OPTIONAL_UI_RETRY_GENERATION = generation
        if not _sws_runtime_ledger.register_lease(
            feature=_SWS_OPTIONAL_UI_RETRY_FEATURE,
            space='APP',
            region='DEPSGRAPH_UPDATE_POST',
            handle=_sws_optional_ui_retry_event,
            native_remover=_sws_remove_optional_ui_retry_handler,
            remove_args=(handlers,),
            is_registered=lambda handle: handle in handlers,
        ):
            _sws_remove_optional_ui_retry_handler(_sws_optional_ui_retry_event, handlers)
            _SWS_OPTIONAL_UI_RETRY_GENERATION = ''
            return False
        return True
    except Exception:
        _SWS_OPTIONAL_UI_RETRY_GENERATION = ''
        return False


def _sws_register_optional_ui_modules() -> bool:
    """Register optional UI/RNA with graceful degradation and one retry."""
    _SWS_OPTIONAL_UI_PENDING_TAGS.clear()
    for tag in (
        'WORKSPACE_MANAGER',
        'PANVIEW_RNA',
        'VIEWPORT_OPTIMIZER_RNA',
        'WORKSPACE_STEP_REORDER',
        'SYNCHRONIZE_WORKSPACES',
        'FLOATING_WINDOW_LOCK',
        'PROXY_SAVE_PRE_LEASE',
    ):
        ok, detail = _sws_optional_ui_attempt(tag)
        if ok:
            continue
        _SWS_OPTIONAL_UI_PENDING_TAGS.add(tag)
        _sws_optional_ui_warning_once(tag, detail)
    if _SWS_OPTIONAL_UI_PENDING_TAGS and not _sws_schedule_optional_ui_retry():
        _sws_optional_ui_warning_once(
            'ONE_SHOT_RETRY_UNAVAILABLE',
            'optional UI registration remains degraded; no timer or polling fallback was installed',
        )
    elif not _SWS_OPTIONAL_UI_PENDING_TAGS:
        _sws_cancel_optional_ui_retry(clear_pending=True)
    return not bool(_SWS_OPTIONAL_UI_PENDING_TAGS)


def _sws_open_standard_sidebar_for_smart_workspace() -> bool:
    """Startup-safe no-op.

    Blender 5.1 can crash during WM_init if an add-on writes SpaceView3D
    region visibility or Sidebar category properties before the active workspace
    is fully available. The panel is registered normally; the user opens the
    Sidebar with Blender's standard N key.
    """
    return False


def _sws_stop_idle_background_hooks() -> None:
    """Stop only periodic/continuous resources; preserve finite boundary handlers.

    Strict load_pre/load_post/save_pre/exit_pre handlers and the RNA-only proxy
    migration save_pre lease are event-bound and must remain installed.  This
    function never unregisters classes, PointerProperties, displayed panels, or
    optional feature modules during registration.
    """
    try:
        stop_watch = getattr(_sws_external_sync_guard, 'stop_watch_runtime', None)
        if callable(stop_watch):
            stop_watch()
    except Exception:
        pass
    try:
        if _SWS_VIEWPORT_OPTIMIZER_REGISTERED:
            from . import smart_viewport_optimizer_plus as _viewport_optimizer
            stop = getattr(_viewport_optimizer, 'stop_continuous_runtime', None)
            if callable(stop):
                stop()
    except Exception:
        pass
    try:
        from . import persistence as _sws_persistence
        stop = getattr(_sws_persistence, '_stop_continuous_autosave', None)
        if callable(stop):
            stop()
    except Exception:
        pass
    try:
        if _SMART_COMMON is not None:
            timer = getattr(_SMART_COMMON, '_autosave_timer', None)
            if timer is not None and bpy.app.timers.is_registered(timer):
                bpy.app.timers.unregister(timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_sws_tab_repair_timer):
            bpy.app.timers.unregister(_sws_tab_repair_timer)
    except Exception:
        pass




def _sws_restore_explicitly_enabled_workspace_runtimes() -> None:
    """Restart only workspace runtimes whose saved toggle is explicitly ON.

    During an in-session ZIP replacement the zero-idle cleanup unregisters old
    optional modules before the new files are imported.  Blender preserves the
    WindowManager property values, so an enabled toggle must start the current
    crash-safe runtime again without requiring the user to toggle it OFF/ON.
    Disabled toggles continue to load no timer, handler, or msgbus watcher.
    """
    try:
        _ctx = getattr(bpy, 'context', None)
        _wm = getattr(_ctx, 'window_manager', None) if _ctx is not None else None
        _settings = getattr(_wm, 'nptl_settings', None) if _wm is not None else None
    except Exception:
        _ctx = None
        _settings = None
    if _settings is None:
        return

    try:
        _floating_enabled = bool(getattr(_settings, 'floating_window_lock_enabled', False))
    except Exception:
        _floating_enabled = False
    if _floating_enabled:
        try:
            _module = _sws_importlib.import_module(f'{__package__}.floating_window_lock')
            _register = getattr(_module, 'register', None)
            if callable(_register):
                _register()
            _apply = getattr(_module, 'apply_enabled', None)
            if callable(_apply):
                _apply(True, context=_ctx, save=False, _defer_initial_capture=True)
        except Exception:
            pass

    try:
        _sync_enabled = bool(getattr(_settings, 'synchronize_workspaces_enabled', False))
    except Exception:
        _sync_enabled = False
    if _sync_enabled:
        try:
            _module = _sws_importlib.import_module(f'{__package__}.synchronize_workspaces')
            _ensure = getattr(_module, 'ensure_registered', None)
            if callable(_ensure):
                _ensure()
            _apply = getattr(_module, 'apply_enabled', None)
            if callable(_apply):
                _apply(True, context=_ctx, save=False, _defer_initial_capture=True)
        except Exception:
            pass


def register():
    try:
        if _sws_crash_guard is not None:
            _sws_crash_guard.install_runtime()
    except Exception:
        pass
    _sws_force_unregister_stale_core_classes()
    try:
        install_guard = getattr(_sws_external_sync_guard, 'install_zero_idle_guard', None)
        if callable(install_guard):
            install_guard()
        else:
            cleanup_once = getattr(_sws_external_sync_guard, 'cleanup_now', None)
            if callable(cleanup_once):
                cleanup_once()
    except Exception:
        pass
    if _SMART_COMMON is not None:
        _SMART_COMMON.begin_register()
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            original_result = _SMART_ORIGINAL_REGISTER()
            if original_result is False:
                raise RuntimeError('Smart Workspace core registration failed')
        try:
            if _sws_crash_guard is not None:
                _sws_crash_guard.install_runtime()
        except Exception:
            pass
        if _SMART_COMMON is not None and _SMART_COMMON.register() is False:
            raise RuntimeError('Smart Workspace common registration failed')
        _sws_consolidate_smart_workspace_tab(retire_standalone=False)
        try:
            cleanup_once = getattr(_sws_external_sync_guard, 'cleanup_now', None)
            if callable(cleanup_once):
                cleanup_once()
        except Exception:
            pass
        try:
            from . import storage as _sws_storage
            cleanup = getattr(_sws_storage, 'cleanup_legacy_storage_dirs', None)
            if callable(cleanup):
                cleanup()
        except Exception:
            pass
        _sws_stop_idle_background_hooks()
        _sws_register_optional_ui_modules()
        # Persisted runtime toggles are restored only after every native RNA
        # owner and N-panel root has finished registering.  The outer integrity
        # wrapper requests that one-shot restore after the write guard closes.
        return True
    finally:
        if _SMART_COMMON is not None:
            _SMART_COMMON.end_register()


def unregister():
    try:
        if _sws_crash_guard is not None and _sws_crash_guard.is_exit_in_progress():
            return False
    except Exception:
        pass
    _sws_cancel_optional_ui_retry(clear_pending=True)
    _SWS_OPTIONAL_UI_WARNED_KEYS.clear()
    global _SWS_TAB_REPAIR_ATTEMPTS
    _SWS_TAB_REPAIR_ATTEMPTS = 0
    success = True
    for module in (_sws_blend_proxy_cleanup, _sws_external_sync_guard):
        try:
            result = module.unregister()
            if result is False:
                success = False
        except Exception:
            success = False
    try:
        if bpy.app.timers.is_registered(_sws_tab_repair_timer):
            bpy.app.timers.unregister(_sws_tab_repair_timer)
    except Exception:
        pass
    _sws_unregister_synchronize_workspaces()
    _sws_unregister_workspace_step_reorder()
    try:
        import sys as _sws_sys
        _root_pkg = str(__package__ or __name__ or '').strip()
        _floating_mod = _sws_sys.modules.get(f'{_root_pkg}.floating_window_lock')
        if _floating_mod is not None:
            _fn = getattr(_floating_mod, 'unregister', None)
            if callable(_fn) and _fn() is False:
                success = False
    except Exception:
        success = False
    if _SMART_COMMON is not None:
        try:
            if _SMART_COMMON.unregister() is False:
                success = False
        except Exception:
            success = False
    if callable(_SMART_ORIGINAL_UNREGISTER):
        try:
            if _SMART_ORIGINAL_UNREGISTER() is False:
                success = False
        except Exception:
            success = False
    try:
        if _sws_unregister_viewport_optimizer() is False:
            success = False
    except Exception:
        success = False
    return bool(success)
# --- Smart common extension patch END ---

# SWS_AUDIT_INTEGRITY_WRAPPER_V1
# Registration integrity wrapper. It adds no idle callback.
_sws_register_impl = register
_sws_unregister_impl = unregister
_sws_registration_active = False
_sws_registration_started = False

def _sws_package_prefix():
    # Works for both legacy add-on and Blender Extension namespaces.
    return __package__ or __name__

def register():
    global _sws_registration_active, _sws_registration_started
    if _sws_registration_active:
        return True
    from . import _runtime_integrity
    from . import storage as _sws_storage
    _sws_storage.begin_registration_write_guard()
    _runtime_integrity.cleanup_stale_runtime(_sws_package_prefix())
    _sws_registration_started = True
    try:
        _sws_register_impl()
    except Exception:
        _runtime_integrity.cleanup_stale_runtime(_sws_package_prefix())
        _sws_registration_active = False
        _sws_registration_started = False
        raise
    finally:
        _sws_storage.end_registration_write_guard()

    # Registration-time RNA defaults are never read as authority.  Once the
    # complete native UI/RNA graph is available, restore validated primary /
    # backup / central state exactly once.  The persistence module applies
    # restored runtime toggles after RNA replay and uses no timer or poll.
    try:
        from . import persistence as _sws_persistence
        restore_status = str(_sws_persistence.request_startup_restore(
            getattr(bpy, 'context', None)
        ) or 'FAILED')
    except Exception:
        restore_status = 'FAILED'

    persistence_ok = restore_status in {
        'APPLIED',
        'PENDING_EVENT',
        'NO_VALID_AUTHORITY',
        'ALREADY_DONE',
    }
    globals()['_SWS_LAST_REGISTRATION_PERSISTENCE_OK'] = (
        True if restore_status in {'APPLIED', 'ALREADY_DONE'} else
        None if restore_status in {'PENDING_EVENT', 'NO_VALID_AUTHORITY'} else
        False
    )
    globals()['_SWS_LAST_REGISTRATION_PERSISTENCE_STATUS'] = restore_status
    if not persistence_ok:
        try:
            from . import persistence as _sws_persistence
            _sws_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
    _sws_registration_active = True
    return True



def unregister():
    global _sws_registration_active, _sws_registration_started
    from . import _runtime_integrity
    if not (_sws_registration_active or _sws_registration_started):
        _runtime_integrity.cleanup_stale_runtime(_sws_package_prefix())
        try:
            if _sws_crash_guard is not None:
                _sws_crash_guard.uninstall_runtime()
        except Exception:
            pass
        return True
    flush_ok = True
    try:
        from . import persistence as _sws_persistence
        flush_ok = bool(_sws_persistence._flush_pending_before_teardown())
    except Exception:
        flush_ok = False
    if not flush_ok:
        # Keep the current generation and all displayed RNA alive.  A failed
        # strict flush is not converted into a partially successful teardown.
        globals()['_SWS_LAST_UNREGISTER_FLUSH_OK'] = False
        return False
    teardown_ok = False
    try:
        result = _sws_unregister_impl()
        teardown_ok = result is not False
    except Exception:
        teardown_ok = False
    if teardown_ok:
        try:
            from . import console_clean as _safe_console_clean
            _safe_console_clean.uninstall()
        except Exception:
            pass
        try:
            from .runtime import navigation_properties as _navigation_properties
            _navigation_properties.shutdown_runtime()
        except Exception:
            pass
        _runtime_integrity.cleanup_stale_runtime(_sws_package_prefix())
        try:
            if _sws_crash_guard is not None:
                _sws_crash_guard.uninstall_runtime()
        except Exception:
            pass
        _sws_registration_active = False
        _sws_registration_started = False
    # A partial teardown remains owned by this generation and can be retried.
    success = bool(flush_ok and teardown_ok)
    globals()['_SWS_LAST_UNREGISTER_FLUSH_OK'] = bool(flush_ok)
    return success


# --- JELararagi shared single-slot status integration v2 ---
try:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = register
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = unregister
except Exception:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = None
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = None


def _jel_status_instrument_class_v2(cls):
    try:
        from . import status_runtime as _jel_status_runtime_v2
        return _jel_status_runtime_v2.instrument_operator_class(
            cls, 'smart_workspace_suite', 'Smart Workspace Suite'
        )
    except Exception:
        return cls


def register():
    """Status compatibility wrapper without global API or class patching."""
    if not callable(_JEL_STATUS_ORIGINAL_REGISTER_V2):
        return False
    return _JEL_STATUS_ORIGINAL_REGISTER_V2()


def unregister():
    """Status compatibility wrapper without global API or class patching."""
    if not callable(_JEL_STATUS_ORIGINAL_UNREGISTER_V2):
        return False
    return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()

# --- JELararagi shared single-slot status integration v2 --- END

# ---------------------------------------------------------------------------
# 1.1.129 exact generation ownership gate
# ---------------------------------------------------------------------------
_SWS_1129_REGISTER_IMPL = register
_SWS_1129_UNREGISTER_IMPL = unregister
_SWS_1129_ACTIVE_GENERATION = ''


_SWS_1129_PROPERTY_OWNER_IDENTITY = object()

_SWS_1129_PUBLIC_RNA_CLASS_SPECS = (
    ('bootstrap', 'SMARTTOOLS_OT_bootstrap_open_window', 'Operator'),
    ('common', 'SMART_WORKSPACE_OT_open_help', 'Operator'),
    ('common', 'SMART_WORKSPACE_OT_set_always_on', 'Operator'),
    ('common', 'SMART_WORKSPACE_OT_save_preferences', 'Operator'),
    ('common', 'SMART_WORKSPACE_PT_always_on', 'Panel'),
    ('external_sync_guard', 'SWS_LegacySynchronizeWorkspacesSettings', 'PropertyGroup'),
    ('feature_toggle', 'SMARTTOOLS_OT_toggle_persistent_feature', 'Operator'),
    ('floating_window_lock', 'SMART_WORKSPACE_OT_set_floating_window_lock_enabled', 'Operator'),
    ('preferences', 'SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_OT_copy_text', 'Operator'),
    ('preferences', 'SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_RuntimeSettings', 'PropertyGroup'),
    ('preferences', 'SMART_WORKSPACE_SUITE_179BED_SMARTTOOLS_AddonPreferences', 'AddonPreferences'),
    ('runtime.__init__', 'NPTL_Preferences', 'AddonPreferences'),
    ('runtime.core', 'NPTL_TabRef', 'PropertyGroup'),
    ('runtime.core', 'NPTL_RecentItem', 'PropertyGroup'),
    ('runtime.core', 'NPTL_FavoritePanel', 'PropertyGroup'),
    ('runtime.core', 'NPTL_DetectedPanel', 'PropertyGroup'),
    ('runtime.core', 'NPTL_FloatingPanelEntry', 'PropertyGroup'),
    ('runtime.core', 'NPTL_CategoryItem', 'PropertyGroup'),
    ('runtime.core', 'NPTL_DetectedTab', 'PropertyGroup'),
    ('runtime.core', 'NPTL_WorkspaceProfile', 'PropertyGroup'),
    ('runtime.core', 'NPTL_Settings', 'PropertyGroup'),
    ('runtime.panview', 'PANVIEW_PresetSlot', 'PropertyGroup'),
    ('runtime.panview', 'PANVIEW_TrackedWindow', 'PropertyGroup'),
    ('runtime.panview', 'PANVIEW_AddonPreferences', 'AddonPreferences'),
    ('runtime.panview', 'PANVIEW_OT_Start2DNav', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_FitCameraView', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_ZoomCamera1to1', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_ZoomCamera2to1', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_CloseWindow', 'Operator'),
    ('runtime.panview', 'PANVIEW_MT_Pie', 'Menu'),
    ('runtime.panview', 'PANVIEW_OT_OpenPie', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_InitPresets', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_PresetSave', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_PresetLoad', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_UpdateAllViews', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_RefreshWindows', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_CloseTrackedWindow', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_CloseAllTrackedWindows', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_FocusTrackedWindow', 'Operator'),
    ('runtime.panview', 'PANVIEW_OT_Create', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_manage_categories', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_manage_contents', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_manage_global_tabs', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_cleanup_unused_tabs', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_refresh_panel_pool', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_toggle_pin', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_fp_open', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_fp_edit_settings', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_panview_popup', 'Operator'),
    ('runtime.ui_operators', 'VIEW3D_OT_toggle_local_ui', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_toggle_favorite_tab', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_toggle_favorite_panel', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_call_panel', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_open_panel_popup', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_open_category_window', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_smart_toggle', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_set_popup_tab', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_launcher', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_hotbox', 'Operator'),
    ('runtime.ui_operators', 'NPTL_UL_category', 'UIList'),
    ('runtime.ui_operators', 'NPTL_UL_tab_content', 'UIList'),
    ('runtime.ui_operators', 'NPTL_UL_detected', 'UIList'),
    ('runtime.ui_operators', 'NPTL_UL_detected_panels', 'UIList'),
    ('runtime.ui_operators', 'NPTL_OT_select_workspace', 'Operator'),
    ('runtime.ui_operators', 'NPTL_MT_workspace_menu', 'Menu'),
    ('runtime.ui_operators', 'VIEW3D_PT_nptl_manager', 'Panel'),
    ('runtime.ui_operators', 'NPTL_OT_toggle_ui_section', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_toggle_properties_pseudo_tab', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_open_help', 'Operator'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_image_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_node_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_sequence_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_clip_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_dopesheet_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_graph_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_nla_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_text_editor', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_file_browser', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_root_spreadsheet', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_always_active', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_workspace', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_categories', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_pool', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_runtime', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_integrated_tools', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_panview', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_local_ui_toggle', 'Panel'),
    ('runtime.ui_operators', 'NPTL_PT_properties_io', 'Panel'),
    ('runtime.ui_operators', 'NPTL_OT_repair_workspace_manager_runtime', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_copy_workspace_profile', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_export_settings', 'Operator'),
    ('runtime.ui_operators', 'NPTL_OT_import_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'SVO_PLUS_PG_settings', 'PropertyGroup'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_apply_max_speed', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_apply_current', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_restore_snapshot', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_reset_options', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_clear_snapshot', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_toggle_optimizer', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_copy_keymap_id', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_navigation_guard', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_start_navigation_guard', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_stop_navigation_guard', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_capture_snapshot', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'SVO_MT_workspace_source_menu', 'Menu'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_set_workspace_source', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_paste_workspace_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_set_settings_slot', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_apply_selected_preset', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_save_standard_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_load_standard_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_save_optimized_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_load_optimized_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_reset_selected_preset', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_save_selected_preset_settings', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_load_settings_as_selected_preset', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_save_current_baseline_state', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_load_baseline_state', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_save_custom_preset', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_delete_custom_preset', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_capture_external_backup', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_restore_external_backup', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_open_backup_folder', 'Operator'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_PT_svo_plus_header_popover', 'Panel'),
    ('smart_viewport_optimizer_plus.__init__', 'VIEW3D_OT_svo_plus_sync_details_from_current_settings', 'Operator'),
    ('synchronize_workspaces.__init__', 'SWS_SynchronizeWorkspacesSettings', 'PropertyGroup'),
    ('synchronize_workspaces.__init__', 'SWS_LegacySynchronizeWorkspacesDisabledSettings', 'PropertyGroup'),
    ('synchronize_workspaces.__init__', 'SMART_WORKSPACE_OT_set_synchronize_workspaces_enabled', 'Operator'),
    ('ui_runtime', 'SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_always_toggle', 'Operator'),
    ('ui_runtime', 'SMART_WORKSPACE_SUITE_90F6B1_SMARTTOOLS_OT_n_panel_state_save_toggle', 'Operator'),
    ('workspace_manager', 'WMGR_SaveStateItem', 'PropertyGroup'),
    ('workspace_manager', 'WMGR_Settings', 'PropertyGroup'),
    ('workspace_manager', 'WMGR_UL_save_states', 'UIList'),
    ('workspace_manager', 'WMGR_OT_refresh_save_states', 'Operator'),
    ('workspace_manager', 'WMGR_OT_save_current_workspace', 'Operator'),
    ('workspace_manager', 'WMGR_OT_save_all_workspaces', 'Operator'),
    ('workspace_manager', 'WMGR_OT_save_custom_workspace', 'Operator'),
    ('workspace_manager', 'WMGR_OT_load_selected_to_current', 'Operator'),
    ('workspace_manager', 'WMGR_OT_delete_selected_save_state', 'Operator'),
    ('workspace_manager', 'WMGR_OT_rename_selected_save_state', 'Operator'),
    ('workspace_manager', 'WMGR_OT_move_save_state_up', 'Operator'),
    ('workspace_manager', 'WMGR_OT_move_save_state_down', 'Operator'),
    ('workspace_manager', 'WMGR_OT_repair_dopesheet', 'Operator'),
    ('workspace_manager', 'WMGR_OT_export_diagnostics', 'Operator'),
    ('workspace_step_reorder.__init__', 'WORKSPACE_OT_step_move_forward', 'Operator'),
    ('workspace_step_reorder.__init__', 'WORKSPACE_OT_step_move_backward', 'Operator'),
    ('workspace_step_reorder.__init__', 'SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled', 'Operator'),
)


_SWS_1129_STATIC_RNA_PROPERTIES = {
    'WindowManager': {
        'nptl_settings',
        'smart_workspace_suite_runtime_settings',
        'workspace_manager_settings',
        'panview_tracked_windows',
        'smart_workspace_suite_always_on_enabled',
    },
    'Scene': {
        'synch_settings',
        'sws_synchronize_workspaces_settings',
        'smart_viewport_optimizer_settings',
        'smart_viewport_optimizer_snapshot_json',
        'panview_camera_target',
        'panview_show_overlays',
        'panview_show_wireframes',
        'panview_wireframe_opacity',
        'panview_show_xray',
        'panview_wire_color_type',
        'panview_color_type',
        'panview_background_type',
        'panview_background_color',
        'panview_show_object_outline',
        'panview_object_outline_color',
        'panview_xray_alpha',
        'panview_lock_rotation',
        'panview_launch_mode',
        'panview_split_factor',
        'panview_reuse_existing',
        'panview_follow_active_camera',
        'panview_size_mode',
        'panview_window_fraction',
        'panview_window_w',
        'panview_window_h',
        'panview_position_mode',
        'panview_hide_ui_fullarea',
        'panview_show_hud',
        'panview_ui_show_window_settings',
        'panview_ui_show_view_settings',
        'panview_ui_show_camera_guides',
        'panview_ui_show_2d_navigation',
        'panview_ui_show_presets',
        'panview_ui_show_window_manager',
        'panview_show_safe_areas',
        'panview_show_passepartout',
        'panview_passepartout_alpha',
        'panview_composition_guide',
        'panview_nav_mode',
        'panview_pan_sens',
        'panview_zoom_sens',
        'panview_invert_zoom',
        'panview_lock_zoom',
        'panview_preset_slots',
        'panview_preset_index',
    },
    'WorkSpace': {
        'synch_active',
        'sws_synchronize_workspaces_active',
    },
    'Object': {
        'smart_viewport_optimizer_object_state',
    },
}


def _sws_1129_rna_owner_types():
    result = {}
    for type_name in ('WindowManager', 'Scene', 'WorkSpace', 'Object'):
        owner = getattr(bpy.types, type_name, None)
        if isinstance(owner, type):
            result[type_name] = owner
    return result


def _sws_1129_expected_rna_properties():
    expected = {key: set(value) for key, value in _SWS_1129_STATIC_RNA_PROPERTIES.items()}
    try:
        from . import ui_runtime as _sws_ui_runtime
        wm_names = expected.setdefault('WindowManager', set())
        for action in tuple(getattr(_sws_ui_runtime, '_ALWAYS_ON_ACTION_ORDER', ()) or ()):
            fn = getattr(_sws_ui_runtime, '_always_prop_name', None)
            if callable(fn):
                name = str(fn(action) or '')
                if name:
                    wm_names.add(name)
        entries = tuple(getattr(getattr(_sws_ui_runtime, 'feature_toggle', None), 'feature_entries', lambda: ())() or ())
        captured_name = getattr(_sws_ui_runtime, '_captured_prop_name', None)
        suppressed = set(getattr(_sws_ui_runtime, '_SUPPRESSED_CAPTURED_TOGGLES', ()) or ())
        if callable(captured_name):
            for item in entries:
                if not isinstance(item, dict):
                    continue
                alias = str(item.get('alias') or '').strip()
                feature_key = str(item.get('key') or '').strip()
                if alias and feature_key and (alias, feature_key) not in suppressed:
                    name = str(captured_name(alias, feature_key) or '')
                    if name:
                        wm_names.add(name)
    except Exception:
        pass
    return expected


def _sws_1129_rna_descriptor(owner, property_name):
    try:
        properties = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        getter = getattr(properties, 'get', None)
        return getter(str(property_name)) if callable(getter) else None
    except Exception:
        return None


def _sws_1129_snapshot_rna_descriptors():
    """Snapshot stable RNA metadata for this Suite's bounded declared surface."""
    from . import runtime_ledger as _sws_runtime_ledger
    snapshots = {}
    owners = _sws_1129_rna_owner_types()
    for type_name, names in _sws_1129_expected_rna_properties().items():
        owner = owners.get(type_name)
        values = {}
        if owner is not None:
            for name in tuple(sorted(set(names))):
                descriptor = _sws_1129_rna_descriptor(owner, name)
                if descriptor is not None:
                    values[str(name)] = _sws_runtime_ledger.rna_property_signature(descriptor)
        snapshots[type_name] = values
    return snapshots

def _sws_1129_preflight_rna_is_clean(runtime_ledger_module) -> bool:
    for type_name, names in _sws_1129_expected_rna_properties().items():
        owner = _sws_1129_rna_owner_types().get(type_name)
        if owner is None:
            continue
        for name in names:
            if _sws_1129_rna_descriptor(owner, name) is not None:
                runtime_ledger_module.mark_restart_required(
                    f'PREEXISTING_RNA_REQUIRES_RESTART:{type_name}.{name}'
                )
                return False
    return True


def _sws_1129_pointer_property_class(descriptor):
    """Resolve one current-generation PropertyGroup from the explicit ledger.

    The fixed StructRNA identifier narrows candidates but never proves ownership
    by itself.  Candidates come only from exact classes already recorded by the
    active generation; a conflicting published class is rejected.
    """
    from . import runtime_ledger as _sws_runtime_ledger
    try:
        fixed_type = getattr(descriptor, 'fixed_type', None)
        fixed_identifier = str(getattr(fixed_type, 'identifier', '') or '')
    except Exception:
        fixed_identifier = ''
    record = _sws_runtime_ledger.active_record()
    generation = _sws_runtime_ledger.current_generation()
    if not fixed_identifier or not isinstance(record, dict) or not generation:
        return None
    candidates = []
    for item in tuple(record.get('classes', {}).values()):
        if not isinstance(item, dict):
            continue
        cls = item.get('class_identity')
        if (
            not isinstance(cls, type)
            or str(item.get('generation') or '') != generation
            or item.get('revision') != record.get('revision')
            or not _sws_runtime_ledger.class_recorded_current(cls)
        ):
            continue
        try:
            class_identifier = _sws_runtime_ledger.class_rna_identifier(cls)
            if class_identifier != fixed_identifier:
                continue
            publication_state, _published = _sws_runtime_ledger.class_publication_state(cls)
            if publication_state not in {'ABSENT', 'EXACT'}:
                continue
            candidates.append(cls)
        except Exception:
            continue
    # Identifier metadata cannot select among ambiguous ledgered classes.
    return candidates[0] if len(candidates) == 1 else None

def _sws_1129_record_new_rna_properties(runtime_ledger_module, before) -> bool:
    """Record only slots absent before and created during this registration."""
    owners = _sws_1129_rna_owner_types()
    for type_name, names in _sws_1129_expected_rna_properties().items():
        owner = owners.get(type_name)
        if owner is None:
            continue
        before_values = before.get(type_name, {}) if isinstance(before, dict) else {}
        for name in tuple(sorted(set(names))):
            descriptor = _sws_1129_rna_descriptor(owner, name)
            if descriptor is None:
                continue
            signature = runtime_ledger_module.rna_property_signature(descriptor)
            previous_signature = before_values.get(name)
            if previous_signature is not None:
                if previous_signature != signature:
                    runtime_ledger_module.mark_restart_required(
                        f'RNA_SIGNATURE_REPLACED_DURING_REGISTER:{type_name}.{name}'
                    )
                    return False
                # Preflight rejects pre-existing declared slots.  Reaching this
                # branch means registration provenance is ambiguous.
                runtime_ledger_module.mark_restart_required(
                    f'RNA_PREEXISTED_REGISTRATION_TRANSACTION:{type_name}.{name}'
                )
                return False
            if runtime_ledger_module.property_recorded_current(owner, name, descriptor=descriptor):
                continue

            def _remove_exact_property(_handle=None, *, _owner=owner, _name=name, _signature=signature):
                live = _sws_1129_rna_descriptor(_owner, _name)
                if live is None:
                    return
                if runtime_ledger_module.rna_property_signature(live) != _signature:
                    raise RuntimeError(f'RNA signature changed: {_name}')
                delattr(_owner, _name)
                if _sws_1129_rna_descriptor(_owner, _name) is not None:
                    raise RuntimeError(f'RNA removal did not verify: {_name}')

            property_group_class = _sws_1129_pointer_property_class(descriptor)
            if property_group_class is not None:
                recorded = runtime_ledger_module.record_property(
                    owner,
                    name,
                    property_group_class,
                    remover=_remove_exact_property,
                    newly_registered=True,
                )
            else:
                recorded = runtime_ledger_module.record_scalar_property(
                    owner,
                    name,
                    _SWS_1129_PROPERTY_OWNER_IDENTITY,
                    remover=_remove_exact_property,
                    newly_registered=True,
                )
            if not recorded:
                try:
                    _remove_exact_property()
                finally:
                    runtime_ledger_module.mark_restart_required(
                        f'RNA_OWNERSHIP_RECORD_FAILED:{type_name}.{name}'
                    )
                return False
    return True

def _sws_1129_package_prefix():
    return str(__package__ or __name__ or '').strip()


def _sws_1129_live_package_classes():
    """Return exact live Suite classes from their class-owned StructRNA state.

    A valid Blender 5.1 Extension class need not be published as a same-name
    attribute on ``bpy.types``.  The class-owned RNA identifier is therefore the
    native liveness proof; a conflicting same-name publication is rejected.
    """
    import sys as _sws_sys
    from . import runtime_ledger as _sws_runtime_ledger
    prefix = _sws_1129_package_prefix()
    result = {}
    if not prefix:
        return result
    for module_name, module in tuple(_sws_sys.modules.items()):
        if module is None or not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        try:
            values = tuple(vars(module).values())
        except Exception:
            continue
        for candidate in values:
            if not isinstance(candidate, type) or getattr(candidate, '__module__', '') != module_name:
                continue
            class_name = str(getattr(candidate, '__name__', '') or '')
            if not class_name:
                continue
            if _sws_runtime_ledger.class_has_valid_registered_rna(candidate):
                publication_state, _published = _sws_runtime_ledger.class_publication_state(candidate)
                if publication_state not in {'ABSENT', 'EXACT'}:
                    continue
                key = f"{module_name}:{getattr(candidate, '__qualname__', class_name)}"
                result[key] = candidate
    return result


def _sws_1129_preflight_classes_are_clean(runtime_ledger_module) -> bool:
    """Reject foreign Python-name and base-canonical RNA occupancy.

    Blender does not require a registered class RNA identifier to equal the
    Python class name.  Loaded Suite classes are therefore preflighted through
    the same base-specific canonical resolver used by the exact generation
    ledger.  Missing modules are checked when their local register helper runs.
    No foreign or old class is adopted, unregistered, or mutated here.
    """
    import sys as _sws_sys

    prefix = _sws_1129_package_prefix()
    checked_names = set()
    checked_classes = set()
    for module_path, class_name, _kind in _SWS_1129_PUBLIC_RNA_CLASS_SPECS:
        if class_name not in checked_names:
            checked_names.add(class_name)
            try:
                live = getattr(bpy.types, class_name, None)
            except Exception:
                runtime_ledger_module.mark_restart_required(
                    f'CLASS_PUBLICATION_LOOKUP_FAILED:{class_name}'
                )
                return False
            if live is not None:
                runtime_ledger_module.mark_restart_required(
                    f'PREEXISTING_CLASS_REQUIRES_RESTART:{class_name}'
                )
                return False

        suffix = str(module_path or '').strip()
        if suffix.endswith('.__init__'):
            suffix = suffix[:-9]
        module_name = f'{prefix}.{suffix}' if suffix else prefix
        module = _sws_sys.modules.get(module_name)
        if module is None:
            continue
        try:
            candidate = getattr(module, class_name, None)
        except Exception:
            candidate = None
        if not isinstance(candidate, type) or candidate in checked_classes:
            continue
        checked_classes.add(candidate)
        state = runtime_ledger_module.class_registration_preflight(candidate)
        if state != 'CLEAN':
            runtime_ledger_module.mark_restart_required(
                f'PREEXISTING_CANONICAL_CLASS_REQUIRES_RESTART:{class_name}:{state}'
            )
            return False

    unledgered_live = _sws_1129_live_package_classes()
    if unledgered_live:
        runtime_ledger_module.mark_restart_required(
            'PREEXISTING_UNLEDGERED_PACKAGE_CLASS_REQUIRES_RESTART:'
            + ','.join(sorted(unledgered_live.keys()))
        )
        return False
    return True


def _sws_1129_record_new_package_classes(runtime_ledger_module, before) -> bool:
    """Record exact class deltas after/while a bounded registration transaction."""
    current = _sws_1129_live_package_classes()
    before = before if isinstance(before, dict) else {}
    native_remover = bpy.utils.unregister_class
    for key, cls in current.items():
        if before.get(key) is cls:
            continue
        if runtime_ledger_module.class_recorded_current(cls):
            continue
        if not runtime_ledger_module.record_class(
            cls,
            remover=native_remover,
            newly_registered=True,
        ):
            # The class may be removed only after this generation records the
            # exact object and Blender's actual canonical RNA identity in a
            # provisional ledger slot.  A foreign publication remains untouched.
            rolled_back = runtime_ledger_module.rollback_unrecorded_class_exact(
                cls,
                native_unregister=native_remover,
            )
            runtime_ledger_module.mark_restart_required(
                f'CLASS_OWNERSHIP_RECORD_FAILED:{key}:rollback={bool(rolled_back)}'
            )
            return False
    return True


def register():
    """Register one exact generation without patching global Blender APIs."""
    global _SWS_1129_ACTIVE_GENERATION
    from . import runtime_ledger as _sws_runtime_ledger

    decision = _sws_runtime_ledger.begin_registration()
    globals()['_SWS_LAST_GENERATION_DECISION'] = decision.status
    if not decision.allowed:
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = False
        return False
    generation = str(decision.generation or '')
    if decision.status == 'ALREADY_CURRENT':
        proven = bool(
            generation
            and _SWS_1129_ACTIVE_GENERATION == generation
            and globals().get('_sws_registration_active', False)
            and _sws_runtime_ledger.generation_matches(generation)
            and not _sws_runtime_ledger.current_ownership_conflicts()
        )
        if not proven:
            _sws_runtime_ledger.mark_restart_required('CURRENT_GENERATION_REGISTRATION_STATE_UNPROVEN')
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = proven
        return proven
    if not generation or not _sws_runtime_ledger.generation_matches(generation):
        _sws_runtime_ledger.mark_restart_required('GENERATION_PUBLICATION_FAILED')
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = False
        return False

    if not _sws_1129_preflight_classes_are_clean(_sws_runtime_ledger):
        _sws_runtime_ledger.abort_generation_after_rollback()
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = False
        return False
    if not _sws_1129_preflight_rna_is_clean(_sws_runtime_ledger):
        _sws_runtime_ledger.abort_generation_after_rollback()
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = False
        return False

    classes_before = _sws_1129_live_package_classes()
    rna_before = _sws_1129_snapshot_rna_descriptors()
    completed = False
    _SWS_1129_ACTIVE_GENERATION = generation
    try:
        result = _SWS_1129_REGISTER_IMPL()
        if result is False:
            raise RuntimeError('Smart Workspace registration transaction failed')
        if not _sws_1129_record_new_package_classes(_sws_runtime_ledger, classes_before):
            raise RuntimeError('Smart Workspace class registration ownership is unproven')
        if not _sws_1129_record_new_rna_properties(_sws_runtime_ledger, rna_before):
            raise RuntimeError('Smart Workspace RNA registration ownership is unproven')
        if not _sws_runtime_ledger.generation_matches(generation):
            raise RuntimeError('Smart Workspace generation changed during registration')
        conflicts = _sws_runtime_ledger.current_ownership_conflicts()
        if conflicts:
            raise RuntimeError('Smart Workspace registration identity conflict: ' + ';'.join(conflicts))
        completed = True
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = True
        return True
    except Exception:
        # Feature helpers may have raised after native registration.  Capture only
        # exact Suite class/RNA deltas before rolling back this new generation.
        try:
            _sws_1129_record_new_package_classes(_sws_runtime_ledger, classes_before)
        except Exception:
            _sws_runtime_ledger.mark_restart_required('FAILED_REGISTER_CLASS_DELTA_UNPROVEN')
        try:
            _sws_1129_record_new_rna_properties(_sws_runtime_ledger, rna_before)
        except Exception:
            _sws_runtime_ledger.mark_restart_required('FAILED_REGISTER_RNA_DELTA_UNPROVEN')
        rollback_ok = _sws_runtime_ledger.rollback_current_generation_new_items()
        abort_ok = _sws_runtime_ledger.abort_generation_after_rollback() if rollback_ok else False
        if not (rollback_ok and abort_ok):
            _sws_runtime_ledger.mark_restart_required('REGISTER_TRANSACTION_ROLLBACK_INCOMPLETE')
        _SWS_1129_ACTIVE_GENERATION = ''
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = False
        raise
    finally:
        globals()['_SWS_LAST_REGISTER_SUCCESS'] = bool(completed)


def unregister():
    """Flush first and release only exact identities owned by this generation."""
    global _SWS_1129_ACTIVE_GENERATION
    from . import runtime_ledger as _sws_runtime_ledger
    generation = _sws_runtime_ledger.current_generation()
    if not generation:
        return not bool(_SWS_1129_ACTIVE_GENERATION)
    if _SWS_1129_ACTIVE_GENERATION != generation:
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_GENERATION_IDENTITY_MISMATCH')
        return False
    conflicts = _sws_runtime_ledger.current_ownership_conflicts()
    if conflicts:
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_OWNERSHIP_CONFLICT:' + ';'.join(conflicts))
        globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
        return False
    try:
        from . import persistence as _sws_persistence
        if not bool(_sws_persistence._flush_pending_before_teardown()):
            _sws_runtime_ledger.mark_restart_required('UNREGISTER_STRICT_FLUSH_FAILED')
            globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
            return False
    except Exception:
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_STRICT_FLUSH_EXCEPTION')
        globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
        return False
    try:
        result = _SWS_1129_UNREGISTER_IMPL()
        completed = result is not False
    except Exception:
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_TRANSACTION_EXCEPTION')
        globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
        raise
    if not completed:
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_TRANSACTION_FAILED')
        globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
        return False
    if not _sws_runtime_ledger.finish_generation(release_rna=True):
        _sws_runtime_ledger.mark_restart_required('UNREGISTER_NATIVE_OR_RNA_RELEASE_FAILED')
        globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = False
        return False
    # The generation is released, but persistence's module-level dirty cache is
    # not generation-bound: the only site that rescopes it is the rollover
    # inside persistence._lifecycle_state(), which runs when the NEXT
    # generation's record is built.  After the FINAL unregister there is no next
    # generation, so that rollover never runs, and because
    # deferred_settings_dirty() reads the cache first and short-circuits, a mark
    # raised by any module teardown above -- all of which run after this
    # generation's strict flush already completed -- would stay asserted for the
    # rest of the process while naming no live unit of work.  Settle the pair
    # here, on the release path itself, so it is already correct when unregister
    # returns instead of waiting for a read that never comes.  This adds no
    # policy: it takes the rollover's own verdict, so a concrete pending payload
    # or an armed one-shot save survives and only a bare retired bit is dropped.
    _sws_persistence = None
    try:
        from . import persistence as _sws_persistence
        _sws_persistence.release_deferred_settings_dirty_scope()
    except Exception:
        pass
    # The three driver-namespace records are reload bridges only while a
    # generation, pending transaction, native lease, or exact timer slot exists.
    # After successful RNA release, remove only the exact module-owned objects
    # when each owner proves itself quiescent. Foreign/replaced objects and all
    # incomplete teardown diagnostics remain untouched and are reported.
    namespace_release = {}
    for name, owner, function in (
        ('persistence', _sws_persistence, 'release_quiescent_lifecycle_state'),
        ('timer_registry', __import__(f'{__package__}.storage', fromlist=['storage']), 'release_quiescent_timer_registry'),
        ('runtime_ledger', _sws_runtime_ledger, 'release_quiescent_ledger'),
    ):
        try:
            callback = getattr(owner, function, None)
            namespace_release[name] = callback() if callable(callback) else 'UNAVAILABLE'
        except Exception as exc:
            namespace_release[name] = f'EXCEPTION:{type(exc).__name__}:{exc}'
    globals()['_SWS_LAST_NAMESPACE_RELEASE'] = namespace_release
    _SWS_1129_ACTIVE_GENERATION = ''
    globals()['_SWS_LAST_UNREGISTER_SUCCESS'] = True
    return True

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
