# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
from typing import Iterable

import bpy

from .. import runtime_ledger as _runtime_ledger
from .translation import localized_layout
try:
    from ..translation import static_source_text, ui_pair
except Exception:
    def static_source_text(text):
        return str(text or '')
    def ui_pair(en, ja, context=None):
        return str(ja if False else en)

_CATEGORY_OVERRIDES = {
    'smart_animation_suite': 'Smart Animation',
    'smart_cloth_suite': 'Smart Cloth',
    'smart_file_suite': 'Smart File',
    'smart_modeling_suite': 'Smart Modeling',
    'smart_modifier_suite': 'Smart Modifier',
    'smart_overlay_suite': 'Smart Overlay',
    'smart_paint_suite': 'Smart Paint',
    'smart_render_suite': 'Smart Render',
    'smart_rig_suite': 'Smart Rig',
    'smart_sculpt_suite': 'Smart Sculpt',
    'smart_selector_suite': 'Smart Selector',
    'smart_shader_suite': 'Smart Shader',
    'smart_shapekey_suite': 'Smart Shapekey',
    'smart_transform_suite': 'Smart Transform',
    'smart_uv_suite': 'Smart UV',
    'smart_workspace_suite': 'Smart Workspace',
}

_LEGACY_OPEN_OPERATOR_IDS = {
    'smart_workspace_suite': (
        'wm.smart_workspace_suite_open_window_v250',
        'wm.smart_workspace_suite_bootstrap_open_window_v370',
    ),
}

_REGISTRY = {
    'nav_entries': {},
    'panel_sources': {},
    'proxy_panels': {},
    'original_panel_polls': {},
    'launcher_callbacks': {},
    'launcher_draw_callbacks': {},
    'legacy_operators': {},
    'popup_operators': {},
    'preferred_owner': None,
    'active_owner': None,
    'shutdown': False,
    'runtime_teardown': False,
    'window_menu_installed': True,
}

# Dynamic launcher operators are optional in the standard N-panel build.  Keep
# an explicit registry so hot-reload cleanup can always unregister them; older
# merged revisions referenced this mapping without defining it.
_DYNAMIC_OPERATOR_CLASSES: dict[str, type] = {}

_MISSING = object()
_STARTUP_SAFE_STUB = True


def _registry() -> dict:
    return _REGISTRY


def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip()


def _safe_name(value: object, fallback: str = 'smart_tools') -> str:
    text = str(value or fallback).strip().lower()
    out = ''.join(ch if ch.isalnum() else '_' for ch in text)
    out = '_'.join(part for part in out.split('_') if part)
    return out or fallback


def _operator_safe_name(op_idname: str) -> str:
    return _safe_name(str(op_idname or '').replace('.', '_'), 'smart_tools_operator')


def _clean_label(value: object) -> str:
    text = str(value or '').replace('_', ' ').strip()
    while '  ' in text:
        text = text.replace('  ', ' ')
    for suffix in (' Toolset', ' suite', '_Toolset', '_suite'):
        if text.endswith(suffix):
            text = text[: -len(suffix)].strip()
    return text


def _category_for(addon_key: str, label: object = '') -> str:
    addon_key = _normalize_owner(addon_key)
    if addon_key in _CATEGORY_OVERRIDES:
        return _CATEGORY_OVERRIDES[addon_key]
    label_text = _clean_label(label)
    if label_text:
        return label_text
    return _clean_label(addon_key) if addon_key else 'Smart Tools'


def _label_for(addon_key: str, label: object = '') -> str:
    return _category_for(addon_key, label)


def _is_registered_blender_class(cls: type) -> bool:
    return bool(isinstance(cls, type) and _runtime_ledger.class_is_current(cls))


def _safe_register_class(cls: type) -> bool:
    """Register only a new exact class in the active generation."""
    if not isinstance(cls, type) or not _runtime_ledger.current_generation():
        return False
    success, _newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='DYNAMIC_RNA_CLASS',
    )
    return bool(success)



def _safe_unregister_class(cls: type) -> None:
    """Unregister only the exact class owned by the active generation."""
    if not isinstance(cls, type) or not _runtime_ledger.class_recorded_current(cls):
        return None
    _runtime_ledger.unregister_class_exact(
        cls,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='DYNAMIC_RNA_CLASS',
    )
    return None



def _iter_valid_panel_classes(panel_classes) -> tuple[type, ...]:
    seen: set[type] = set()
    panels: list[type] = []
    base = getattr(bpy.types, 'Panel', None)
    for cls in tuple(panel_classes or ()):  # type: ignore[arg-type]
        if not isinstance(cls, type) or cls in seen:
            continue
        if base is not None:
            try:
                if not issubclass(cls, base):
                    continue
            except Exception:
                continue
        seen.add(cls)
        panels.append(cls)
    return tuple(panels)


def prepare_panel_classes(panel_classes, addon_key: str | None = None):
    del addon_key
    return _iter_valid_panel_classes(panel_classes)


def _call_poll(raw_poll, panel_cls, context, default: bool = True) -> bool:
    if raw_poll is None or raw_poll is _MISSING:
        return bool(default)
    for call in (
        lambda: raw_poll(context),
        lambda: raw_poll(panel_cls, context),
        lambda: raw_poll.__func__(panel_cls, context),
    ):
        try:
            return bool(call())
        except TypeError:
            continue
        except Exception:
            return bool(default)
    return bool(default)


def _call_draw(draw_fn, panel_instance, context) -> bool:
    if not callable(draw_fn):
        return False
    for call in (
        lambda: draw_fn(panel_instance, context),
        lambda: draw_fn(context),
    ):
        try:
            call()
            return True
        except TypeError:
            continue
        except Exception:
            raise
    return False


def _make_panel_draw_shim(panel_cls, layout):
    shim_name = f'_SMARTTOOLS_NPANEL_SHIM_{_safe_name(getattr(panel_cls, "__name__", "panel"))}'
    attrs = {}
    for name, value in getattr(panel_cls, '__dict__', {}).items():
        if name.startswith('__'):
            continue
        if callable(value):
            attrs[name] = value
    shim_cls = type(shim_name, (), attrs)
    shim = shim_cls()
    try:
        shim.layout = layout
    except Exception:
        pass
    for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options', 'bl_category'):
        try:
            setattr(shim, name, getattr(panel_cls, name))
        except Exception:
            pass
    return shim


def _panel_can_draw_in_context(panel_cls, context) -> bool:
    return _call_poll(getattr(panel_cls, 'poll', None), panel_cls, context, default=True)


def _draw_panel_class_fallback_contents(layout, context, panel_cls) -> bool:
    # Legacy SmartTools hosts re-entered arbitrary Panel.draw() methods through a
    # Python shim.  The attached crash occurs inside Blender's VIEW_3D panel draw
    # path, so this compatibility path is intentionally disabled.  Normal Smart
    # Workspace UI is drawn by its own registered N-panel classes instead.
    del layout, context, panel_cls
    return False


def _ordered_panel_sources(addon_key: str) -> tuple[type, ...]:
    panels = list(_iter_valid_panel_classes(_REGISTRY.get('panel_sources', {}).get(str(addon_key), ()) or ()))
    indexed = list(enumerate(panels))
    indexed.sort(key=lambda item: (0 if not str(getattr(item[1], 'bl_parent_id', '') or '') else 1, item[0]))
    return tuple(cls for _index, cls in indexed)


def _draw_launcher_fallback_contents(layout, context, addon_key: str) -> int:
    drawn = 0
    for panel_cls in _ordered_panel_sources(addon_key):
        if drawn:
            try:
                layout.separator()
            except Exception:
                pass
        if _draw_panel_class_fallback_contents(layout, context, panel_cls):
            drawn += 1
    return drawn


def _restore_original_panel_polls(addon_key: str) -> None:
    # Do not assign Panel.poll on live registered classes.  Older SmartTools host
    # builds stored/restored poll callbacks here; in standard N-panel mode we only
    # discard stale bookkeeping.
    _REGISTRY.get('original_panel_polls', {}).pop(str(addon_key), None)
    return None


def _release_proxy_panels(addon_key: str) -> None:
    for cls in reversed(tuple(_REGISTRY.get('proxy_panels', {}).pop(str(addon_key), ()) or ())) :
        _safe_unregister_class(cls)


def _purge_untracked_proxy_panels(addon_key: str) -> None:
    """Never scan bpy.types or remove untracked Panel RNA."""
    del addon_key
    return None



def _standard_cleanup(addon_key: str | None = None) -> None:
    keys = [addon_key] if addon_key else list((_REGISTRY.get('proxy_panels') or {}).keys())
    for key in [k for k in keys if k]:
        _release_proxy_panels(str(key))
        _purge_untracked_proxy_panels(str(key))
        _restore_original_panel_polls(str(key))
        _REGISTRY.setdefault('proxy_panels', {})[str(key)] = tuple()
    _tag_redraw_all_npanel_areas()


def _rebuild_proxy_panels(addon_key: str) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _standard_cleanup(addon_key)
    return True


def _ensure_legacy_open_operators(addon_key: str) -> None:
    addon_key = _normalize_owner(addon_key)
    operator_ids = tuple(_LEGACY_OPEN_OPERATOR_IDS.get(addon_key, ()))
    for operator_id in operator_ids:
        if operator_id in _REGISTRY.get('legacy_operators', {}):
            continue
        class_name = f'SMARTTOOLS_LEGACY_OT_{_operator_safe_name(operator_id)}'

        def _execute(self, context):
            open_smart_tools_window(context=context, preferred_owner=addon_key, reuse_existing=True)
            try:
                self.report({'INFO'}, ui_pair('Smart Workspace settings are available in the N-panel.', 'Smart Workspace 設定はNパネルに表示されています。', context))
            except Exception:
                pass
            return {'FINISHED'}

        cls = type(class_name, (bpy.types.Operator,), {
            '__module__': __name__,
            'bl_idname': operator_id,
            'bl_label': static_source_text(_category_for(addon_key)),
            'bl_description': 'Show Smart Workspace settings in the standard 3D View Sidebar N-panel.',
            'bl_options': {'INTERNAL'},
            '__annotations__': {
                'reuse_existing': bpy.props.BoolProperty(default=True, options={'HIDDEN'}),
            },
            'execute': _execute,
        })
        if _safe_register_class(cls):
            _REGISTRY.setdefault('legacy_operators', {})[operator_id] = cls


def _module_operator_prefix() -> str:
    package = str(__package__ or __name__ or 'smart_tools').strip('.')
    parts = [part for part in package.split('.') if part]
    if 'user_default' in parts:
        index = parts.index('user_default')
        if index + 1 < len(parts):
            return _safe_name(parts[index + 1])
    if parts and parts[0] == 'bl_ext' and len(parts) >= 3:
        return _safe_name(parts[2])
    if parts:
        return _safe_name(parts[0])
    return 'smart_tools'


def _ensure_popup_operators() -> None:
    if _REGISTRY.get('popup_operators'):
        return
    prefix = _module_operator_prefix()
    operator_id = f'wm.{prefix}_npanel_popup_menu'

    def _execute(self, context):
        open_smart_tools_window(context=context, preferred_owner=_REGISTRY.get('preferred_owner'), reuse_existing=True)
        return {'FINISHED'}

    cls = type(f'{prefix.upper()}_OT_npanel_popup_menu', (bpy.types.Operator,), {
        '__module__': __name__,
        'bl_idname': operator_id,
        'bl_label': static_source_text('Smart Workspace N-panel'),
        'bl_description': 'Show Smart Workspace controls in the standard 3D View Sidebar N-panel.',
        'bl_options': {'INTERNAL'},
        'execute': _execute,
    })
    if _safe_register_class(cls):
        _REGISTRY.setdefault('popup_operators', {})['menu'] = cls


def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    label = _label_for(addon_key, label)
    panels = tuple(prepare_panel_classes(panel_classes, addon_key))
    existing = tuple(_REGISTRY.get('panel_sources', {}).get(addon_key, ()) or ())
    _REGISTRY.setdefault('panel_sources', {})[addon_key] = panels or existing
    _REGISTRY.setdefault('nav_entries', {})[addon_key] = {
        'label': label,
        'icon': str(icon or ''),
        'operator_id': str(operator_id or ''),
        'button_operator_id': '',
        'order': int(order or 0),
        'category': _category_for(addon_key, label),
    }
    _REGISTRY.setdefault('proxy_panels', {})[addon_key] = tuple()
    _REGISTRY['window_menu_installed'] = True
    if not _REGISTRY.get('preferred_owner'):
        _REGISTRY['preferred_owner'] = addon_key
    _REGISTRY['active_owner'] = addon_key
    _REGISTRY['shutdown'] = False
    _REGISTRY['runtime_teardown'] = False
    _standard_cleanup(addon_key)
    _ensure_legacy_open_operators(addon_key)
    _ensure_popup_operators()
    return True


def refresh_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, reopen_window: bool = False, **kwargs) -> bool:
    del reopen_window
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def uninstall(addon_key: str, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _standard_cleanup(addon_key)
    _REGISTRY.get('nav_entries', {}).pop(addon_key, None)
    _REGISTRY.get('panel_sources', {}).pop(addon_key, None)
    _REGISTRY.get('launcher_callbacks', {}).pop(addon_key, None)
    _REGISTRY.get('launcher_draw_callbacks', {}).pop(addon_key, None)
    _REGISTRY.get('proxy_panels', {}).pop(addon_key, None)
    if _REGISTRY.get('preferred_owner') == addon_key:
        remaining = tuple(_REGISTRY.get('nav_entries', {}).keys())
        _REGISTRY['preferred_owner'] = remaining[0] if remaining else None
    if _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = _REGISTRY.get('preferred_owner')
    _tag_redraw_all_npanel_areas()
    return True


def set_launcher_draw_callback(addon_key: str, callback) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    if callable(callback):
        _REGISTRY.setdefault('launcher_callbacks', {})[addon_key] = callback
        _REGISTRY.setdefault('launcher_draw_callbacks', {})[addon_key] = callback
    else:
        _REGISTRY.setdefault('launcher_callbacks', {}).pop(addon_key, None)
        _REGISTRY.setdefault('launcher_draw_callbacks', {}).pop(addon_key, None)
    _standard_cleanup(addon_key)
    return True


def clear_launcher_draw_callback(addon_key: str) -> bool:
    return set_launcher_draw_callback(addon_key, None)


def is_active(context=None, addon_key: str = '') -> bool:
    del context, addon_key
    return True


def set_active_owner(context=None, addon_key: str | None = None) -> None:
    del context
    addon_key = _normalize_owner(addon_key)
    _REGISTRY['active_owner'] = addon_key or None
    if addon_key:
        _REGISTRY['preferred_owner'] = addon_key
    _tag_redraw_all_npanel_areas()


def clear_active_owner(addon_key: str = '') -> None:
    addon_key = _normalize_owner(addon_key)
    if not addon_key or _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    if addon_key and _REGISTRY.get('preferred_owner') == addon_key:
        _REGISTRY['preferred_owner'] = None
    _tag_redraw_all_npanel_areas()


def toggle_active(context=None, addon_key: str = '') -> None:
    set_active_owner(context, addon_key)


def runtime_needs_refresh(addon_key: str = '') -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return not bool(_REGISTRY.get('nav_entries'))
    return addon_key not in _REGISTRY.get('nav_entries', {})


def runtime_has_existing_host_candidates(addon_key: str = '') -> bool:
    addon_key = _normalize_owner(addon_key)
    return bool(addon_key and addon_key in _REGISTRY.get('nav_entries', {}))


def force_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    if preferred_owner:
        set_active_owner(getattr(bpy, 'context', None), preferred_owner)
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()):
        _standard_cleanup(owner)
    return True


def refresh_ui_runtime(context=None, addon_key: str | None = None, activate_if_properties: bool = False, **_kwargs) -> bool:
    del context, activate_if_properties
    if addon_key:
        set_active_owner(getattr(bpy, 'context', None), addon_key)
        _standard_cleanup(addon_key)
    else:
        force_runtime_refresh()
    return True


def sync_live_runtime_from_prefs(context=None) -> bool:
    del context
    return force_runtime_refresh()


def repair_live_hosts_and_menu(context=None, *, reopen_window: bool = False) -> bool:
    del context, reopen_window
    return force_runtime_refresh()


def ensure_shared_nav_button_operators() -> bool:
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()) or tuple(_CATEGORY_OVERRIDES.keys()):
        _ensure_legacy_open_operators(owner)
    _ensure_popup_operators()
    return True


def begin_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = True


def finish_addon_shutdown() -> None:
    _REGISTRY['shutdown'] = False


def _unregister_dynamic_operator_classes() -> None:
    for cls in reversed(tuple(_DYNAMIC_OPERATOR_CLASSES.values())):
        _safe_unregister_class(cls)
    _DYNAMIC_OPERATOR_CLASSES.clear()


def shutdown_runtime() -> None:
    """Release only dynamic classes tracked by this current generation."""
    _REGISTRY['shutdown'] = True
    for owner in tuple(_REGISTRY.get('nav_entries', {}).keys()):
        uninstall(owner)
    _unregister_dynamic_operator_classes()
    for key in ('popup_operators', 'legacy_operators'):
        classes = tuple((_REGISTRY.get(key, {}) or {}).values())
        for cls in reversed(classes):
            _safe_unregister_class(cls)
        _REGISTRY.setdefault(key, {}).clear()
    return None



def is_shutting_down() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def runtime_is_shutdown() -> bool:
    return bool(_REGISTRY.get('shutdown'))


def _set_runtime_teardown(value: bool = True) -> None:
    _REGISTRY['runtime_teardown'] = bool(value)
    _REGISTRY['shutdown'] = bool(value)


def _is_smart_tools_context(context=None) -> bool:
    context = context or getattr(bpy, 'context', None)
    area = getattr(context, 'area', None)
    if area is None:
        return True
    return str(getattr(area, 'type', '') or '') == 'VIEW_3D'


def is_smart_tools_context(context=None) -> bool:
    return _is_smart_tools_context(context)


def _tag_redraw_all_npanel_areas() -> None:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


def _tag_redraw_all_properties_areas() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_host_windows() -> None:
    _tag_redraw_all_npanel_areas()


def _tag_redraw_window_menu_areas() -> None:
    _tag_redraw_all_npanel_areas()


def flush_redraws() -> None:
    _tag_redraw_all_npanel_areas()


def _verified_host_window_keys() -> tuple:
    return ()


def _ensure_host_watch_timer() -> bool:
    return False


def _install_window_menu_entry(*_args, **_kwargs) -> bool:
    return False


def _remove_window_menu_entry_if_unused(*_args, **_kwargs) -> None:
    return None


def _schedule_window_menu_refresh(*_args, **_kwargs) -> None:
    return None


def schedule_shared_window_menu_button_refresh(*_args, **_kwargs) -> None:
    return None


def _install_header_draw_wrapper(*_args, **_kwargs):
    return False


def _install_context_header_overlay(*_args, **_kwargs):
    return False


def _install_navigation_bar_draw_wrapper(*_args, **_kwargs):
    return False


def _install_render_context_draw_wrapper(*_args, **_kwargs):
    return False


def _install_foreign_panel_hider(*_args, **_kwargs):
    return False


def _ensure_runtime_hooks(*_args, **_kwargs):
    return True


def _smart_tools_light_activate_runtime(context=None):
    del context
    return force_runtime_refresh()


def open_smart_tools_window(context=None, preferred_owner: str | None = None, reuse_existing: bool = True) -> bool:
    del reuse_existing
    if preferred_owner:
        set_active_owner(context, preferred_owner)
    try:
        if hasattr(bpy.ops, 'nptl'):
            bpy.ops.nptl.open_category_window(tab_id=_category_for(preferred_owner or _REGISTRY.get('preferred_owner') or 'smart_workspace_suite'))
    except Exception:
        pass
    _tag_redraw_all_npanel_areas()
    return True


def open_or_reuse_smart_tools_window(context=None, reuse_existing: bool = True, preferred_owner: str | None = None) -> bool:
    return open_smart_tools_window(context=context, preferred_owner=preferred_owner, reuse_existing=reuse_existing)


_open_or_reuse_smart_tools_window = open_or_reuse_smart_tools_window


def invoke_props_dialog_preferred_window(operator, context, width: int = 420):
    try:
        return context.window_manager.invoke_props_dialog(operator, width=int(width or 420))
    except Exception:
        return {'CANCELLED'}


def invoke_props_dialog_outside_smart_tools(operator, context, width: int = 420):
    return invoke_props_dialog_preferred_window(operator, context, width=width)


def invoke_popup_outside_smart_tools(operator, context, width: int = 280):
    try:
        return context.window_manager.invoke_popup(operator, width=int(width or 280))
    except Exception:
        return {'CANCELLED'}


def _ensure_host_window_popup_capacity(*_args, **_kwargs) -> bool:
    return True


def popup_menu_operator_id() -> str:
    _ensure_popup_operators()
    cls = _REGISTRY.get('popup_operators', {}).get('menu')
    return str(getattr(cls, 'bl_idname', '') or '') if cls is not None else ''


def popup_operator_enum_operator_id() -> str:
    return popup_menu_operator_id()


def popup_menu_pie_proxy_operator_id() -> str:
    return popup_menu_operator_id()


def _operator_enum_items(operator_idname: str, property_idname: str):
    del operator_idname, property_idname
    return []


def is_startup_safe_stub() -> bool:
    return True


def describe_startup_behavior() -> str:
    return 'Smart Workspace settings are hosted in the 3D View N-panel.'


def _has_existing_smart_tools_contexts() -> bool:
    return False


def mark_suite_presence(addon_key: str, present: bool = True) -> None:
    addon_key = _normalize_owner(addon_key)
    if addon_key and present:
        _REGISTRY.setdefault('nav_entries', {}).setdefault(addon_key, {
            'label': _category_for(addon_key),
            'icon': 'PREFERENCES',
            'operator_id': '',
            'button_operator_id': '',
            'order': 0,
            'category': _category_for(addon_key),
        })
        _REGISTRY.setdefault('panel_sources', {}).setdefault(addon_key, tuple())
        _REGISTRY.setdefault('proxy_panels', {}).setdefault(addon_key, tuple())


def ensure_shared_window_menu_button(force: bool = False) -> bool:
    del force
    _REGISTRY['window_menu_installed'] = True
    return True


def remove_shared_window_menu_button_if_unused(*_args, **_kwargs) -> None:
    return None


def normalize_window_menu_entries(install_if_missing: bool = False) -> bool:
    if install_if_missing:
        _REGISTRY['window_menu_installed'] = True
    return True


def _smart_tools_v430_canonicalize_nav_entries() -> bool:
    return True


def _v9_registry_prepare() -> dict:
    return _REGISTRY


def _shared_nav_button_operator_class(addon_key: str, label: str):
    addon_key = _normalize_owner(addon_key) or 'smart_tools'
    operator_id = f'wm.{_safe_name(addon_key)}_show_npanel_settings'
    existing_cls = _DYNAMIC_OPERATOR_CLASSES.get(operator_id)
    if isinstance(existing_cls, type) and _is_registered_blender_class(existing_cls):
        return existing_cls

    class_name = f'SMARTTOOLS_OT_{_safe_name(addon_key)}_show_npanel_settings_{hashlib.sha1(operator_id.encode()).hexdigest()[:8]}'

    def _execute(self, context):
        open_smart_tools_window(context=context, preferred_owner=addon_key, reuse_existing=True)
        return {'FINISHED'}

    cls = type(class_name, (bpy.types.Operator,), {
        '__module__': __name__,
        'bl_idname': operator_id,
        'bl_label': static_source_text(_label_for(addon_key, label)),
        'bl_description': 'Show settings in the 3D View N-panel.',
        'bl_options': {'INTERNAL'},
        'execute': _execute,
    })
    if _safe_register_class(cls):
        _DYNAMIC_OPERATOR_CLASSES[operator_id] = cls
    return cls


install_window_menu_entry = lambda *args, **kwargs: ()
remove_window_menu_entry = lambda *args, **kwargs: None
remove_window_menu_entry_if_unused = lambda *args, **kwargs: None
schedule_window_menu_refresh = lambda *args, **kwargs: None


__all__ = (
    '_call_poll', '_draw_launcher_fallback_contents', '_draw_panel_class_fallback_contents',
    '_ensure_host_watch_timer', '_ensure_host_window_popup_capacity', '_is_smart_tools_context',
    '_make_panel_draw_shim', '_open_or_reuse_smart_tools_window', '_registry',
    '_set_runtime_teardown', '_shared_nav_button_operator_class', '_smart_tools_light_activate_runtime',
    '_tag_redraw_all_properties_areas', '_tag_redraw_host_windows', '_verified_host_window_keys',
    'begin_addon_shutdown', 'clear_active_owner', 'clear_launcher_draw_callback',
    'describe_startup_behavior', 'ensure_shared_nav_button_operators', 'finish_addon_shutdown',
    'flush_redraws', 'force_runtime_refresh', 'install', 'invoke_popup_outside_smart_tools',
    'invoke_props_dialog_outside_smart_tools', 'invoke_props_dialog_preferred_window', 'is_active',
    'is_shutting_down', 'is_smart_tools_context', 'is_startup_safe_stub', 'mark_suite_presence',
    'normalize_window_menu_entries', 'open_or_reuse_smart_tools_window', 'open_smart_tools_window',
    'popup_menu_operator_id', 'popup_menu_pie_proxy_operator_id', 'popup_operator_enum_operator_id',
    'prepare_panel_classes', 'refresh_entry', 'refresh_runtime', 'refresh_ui_runtime',
    'remove_shared_window_menu_button_if_unused', 'repair_live_hosts_and_menu',
    'runtime_has_existing_host_candidates', 'runtime_is_shutdown', 'runtime_needs_refresh',
    'schedule_shared_window_menu_button_refresh', 'set_active_owner', 'set_launcher_draw_callback',
    'shutdown_runtime', 'sync_live_runtime_from_prefs', 'toggle_active', 'uninstall',
)
