# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy


import re

_JAPANESE_RE = re.compile(r"[぀-ヿ㐀-䶿一-鿿ｦ-ﾟ]")


def contains_japanese(text) -> bool:
    try:
        return bool(_JAPANESE_RE.search(str(text or "")))
    except Exception:
        return False


def ui_pair(en: str, ja: str, context=None) -> str:
    # Keep static RNA/class definitions in English and let Blender's translation
    # table switch them to Japanese only when the interface language is Japanese.
    if context is None:
        return str(en)
    return str(ja if is_japanese(context) else en)


def _split_bilingual_text(text: str):
    raw = str(text or "")
    cleaned = raw.strip()
    if not cleaned:
        return None

    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    # smarttools-ui-style: migration-alias
    if len(lines) == 2 and lines[0].upper().startswith('EN:') and lines[1].upper().startswith('JA:'):
        return lines[0][3:].strip(), lines[1][3:].strip()
    # smarttools-ui-style: migration-alias
    if len(lines) == 2 and lines[0].upper().startswith('JA:') and lines[1].upper().startswith('EN:'):
        return lines[1][3:].strip(), lines[0][3:].strip()

    if ' / ' not in raw:
        return None

    left, right = raw.split(' / ', 1)
    left = left.strip()
    right = right.strip()
    if not left or not right:
        return None

    left_is_ja = contains_japanese(left)
    right_is_ja = contains_japanese(right)
    if left_is_ja and not right_is_ja:
        return right, left
    if right_is_ja and not left_is_ja:
        return left, right

    # Treat only clear EN/JA pairs as bilingual. Plain slash-separated labels
    # such as translated Japanese-only text (e.g. 入出力) must stay
    # intact instead of being split into two pseudo-language halves.
    return None


def ui_text(text: str, context=None) -> str:
    raw = str(text or "")
    if not raw:
        return raw
    try:
        from ..translation import ui_text as _suite_ui_text
        return _suite_ui_text(raw, context=context)
    except Exception:
        pass
    pair = _split_bilingual_text(raw)
    effective_context = context or getattr(bpy, 'context', None)
    if pair is not None:
        en, ja = pair
        return str(ja if is_japanese(effective_context) else en)
    return raw


class LocalizedUILayout:
    _LAYOUT_METHODS = {
        'row', 'column', 'box', 'split', 'column_flow', 'grid_flow', 'menu_pie',
        'panel', 'panel_prop',
    }

    def __init__(self, layout, context=None):
        object.__setattr__(self, '_layout', layout)
        object.__setattr__(self, '_context', context)

    def __setattr__(self, name, value):
        if name in {'_layout', '_context'}:
            object.__setattr__(self, name, value)
            return
        setattr(self._layout, name, value)

    def _is_layout_instance(self, value) -> bool:
        try:
            layout_type = getattr(bpy.types, 'UILayout', None)
            return layout_type is not None and isinstance(value, layout_type)
        except Exception:
            return False

    def _wrap(self, result):
        if result is None:
            return result
        if isinstance(result, LocalizedUILayout):
            return result
        if isinstance(result, tuple):
            return tuple(self._wrap(item) for item in result)
        if isinstance(result, list):
            return [self._wrap(item) for item in result]
        if self._is_layout_instance(result):
            return LocalizedUILayout(result, self._context)
        return result

    def __bool__(self):
        return bool(self._layout)

    def _localize_kwargs(self, method_name: str, kwargs: dict):
        localized = dict(kwargs)
        for key in ('text', 'heading', 'placeholder'):
            if key in localized and localized[key] not in (None, ''):
                localized[key] = ui_text(localized[key], self._context)
        if method_name == 'prop':
            data = localized.pop('_smart_tools_prop_data', None)
            prop_name = localized.pop('_smart_tools_prop_name', None)
            # Preserve an explicit empty label. Blender UI code commonly uses
            # text="" for compact selectors, color swatches, preset indices,
            # and other fields where the label is drawn separately. Re-injecting
            # the RNA name here breaks those layouts, especially the 2D Pan View
            # settings panel. Only synthesize a localized label when the caller
            # omitted the text argument entirely.
            if 'text' not in localized:
                label = ''
                if data is not None and prop_name:
                    try:
                        label = str(data.bl_rna.properties[prop_name].name or '')
                    except Exception:
                        label = ''
                if label:
                    localized['text'] = ui_text(label, self._context)
        return localized

    def __getattr__(self, name):
        attr = getattr(self._layout, name)
        if not callable(attr):
            return attr

        def _wrapped(*args, **kwargs):
            local_kwargs = dict(kwargs)
            if name == 'prop' and len(args) >= 2:
                local_kwargs.setdefault('_smart_tools_prop_data', args[0])
                local_kwargs.setdefault('_smart_tools_prop_name', args[1])
            local_kwargs = self._localize_kwargs(name, local_kwargs)
            result = attr(*args, **local_kwargs)
            if name in self._LAYOUT_METHODS:
                return self._wrap(result)
            return result

        return _wrapped


def localized_layout(layout, context=None):
    if isinstance(layout, LocalizedUILayout):
        return layout
    try:
        layout_type = getattr(bpy.types, 'UILayout', None)
        if layout_type is not None and isinstance(layout, layout_type):
            return LocalizedUILayout(layout, context)
    except Exception:
        pass
    return layout



# =============================================================
# 定数・設定・翻訳辞書
# =============================================================

# Blenderネイティブの翻訳機能（ツールチップ等に自動適用されるもの）
translation_dict = {
    "ja_JP": {
        ("*", "Workspace launcher suite integrated into the standard 3D View Sidebar N-panel with bundled workspace utilities and floating panel tools."): "Blender標準の3DビューサイドバーNパネルへ統合され、同梱ユーティリティとフローティングパネル機能を備えたワークスペース起動ツールセット。",
        ("*", "Set the interval (in seconds) to check and follow pinned tabs. Shorter interval means faster following but slightly more CPU usage."): "ピン留めしたタブが他のタブへ追従する際の間隔(秒)です。短くすると追従が速くなりますが、わずかに処理負荷が上がります。",
        ("*", "The name of the tab in the Sidebar where this add-on's UI will be displayed."): "サイドバー内でこのアドオンのUIが表示されるタブの名前です。",
        ("*", "The identifier to use when setting up a hotkey for the popup launcher in Blender's Keymap preferences."): "Blenderのキーマップ設定で、ポップアップランチャーのショートカットキーを登録する際に使用するIDです。",
        ("*", "Workspace & Launcher"): "ワークスペースとランチャー",
        ("*", "Categories"): "カテゴリー",
        ("*", "Panel Pool"): "パネル一覧",
        ("*", "IO"): "入出力",
        ("*", "Show the Smart Workspace controls in the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルにSmart Workspace操作を表示します。",
    }
}

CONST_TEXT = {
    "OP_POPUP":             {"en": "Open Launcher",          "ja": "クイックランチャーを開く"},

    "LBL_FAVORITES":        {"en": "Favorites",               "ja": "お気に入り"},
    "LBL_RECENT":           {"en": "Recent",                  "ja": "最近使った"},
    "LBL_FAVORITE_PANELS":  {"en": "Favorite Panels",         "ja": "お気に入りパネル"},
    "TXT_NO_CATEGORIES":    {"en": "No categories defined.",  "ja": "カテゴリーが未設定です。"},
    "TXT_NO_PANELS":        {"en": "No panels found in this tab.", "ja": "このタブにパネルが見つかりません。"},
    "LBL_PRESET_NAME":      {"en": "Preset Name",             "ja": "プリセット名"},
    "LBL_PRESET_AVAILABLE": {"en": "Available Presets",       "ja": "利用可能なプリセット"},

    "LABEL_CATS":           {"en": "1. Category Organization", "ja": "1. カテゴリー構成の編集 (ランチャー用)"},
    "LABEL_CONTENTS":       {"en": "2. Category Contents",  "ja": "2. 選択中カテゴリーの中身"},
    "LABEL_POOL":           {"en": "3. All Detected Tabs",  "ja": "3. 全タブ一覧 (リネーム・結合・表示)"},
    "BTN_ADD_CAT":          {"en": "Create Category",       "ja": "カテゴリー新規作成"},
    "BTN_ADD_TAB":          {"en": "Add Selected to Category", "ja": "選択したタブを上に追加"},
    "BTN_REMOVE":           {"en": "Remove",                "ja": "削除"},
    "BTN_REFRESH":          {"en": "Refresh List",          "ja": "リスト更新"},
    
    "BTN_SAVE_EXT":         {"en": "Save Settings",         "ja": "設定を保存"},
    "BTN_LOAD_EXT":         {"en": "Load Settings",         "ja": "設定を読み込み"},
    "BTN_COPY_PROFILE":     {"en": "Paste Settings to Current Workspace", "ja": "現在開いているワークスペースに設定をペースト"},
    "MSG_COPIED":           {"en": "Settings pasted to current workspace", "ja": "現在のワークスペースに設定をペーストしました"},
    "DESC_COPY_PROFILE":    {"en": "Paste the selected workspace profile settings into the currently active workspace.", "ja": "選択中ワークスペースの設定を、現在開いているワークスペースへペーストします。"},
    "BTN_APPLY":            {"en": "Apply Rename & Order",  "ja": "Nパネルにリネームと並び順を適用"},
    "BTN_REPAIR":           {"en": "Reset N-panel",         "ja": "Nパネルを元に戻す/リセット"},
    
    "PROP_WIDTH":           {"en": "Popup Width",           "ja": "ポップアップの幅"},
    "PROP_COLUMNS":         {"en": "Popup Columns",         "ja": "ポップアップの列数"},
    "PROP_TAB_MODE":        {"en": "Use Tab Layout in Popup", "ja": "ポップアップ内をタブ分け表示"},
    "PROP_SHOW_RECENT":    {"en": "Show Recent Tabs", "ja": "最近使ったタブ（Recent）を表示"},
    "LABEL_RENAME_TAB":     {"en": "Rename Selected Tab",   "ja": "選択中のタブ名を変更"},
    "PREF_TAB_NAME":        {"en": "Sidebar Tab Name",      "ja": "このアドオンのタブ名"},
    
    "PREF_PIN_INTERVAL":    {"en": "Pin Update Interval (s)", "ja": "ピン留めの追従の更新間隔 (秒)"},
    "PREF_LAUNCHER_ID":     {"en": "Launcher ID",           "ja": "登録用ID:"},
    "PREF_HOTBOX_ID":       {"en": "Hotbox ID",             "ja": "ホットボックスID"},
    "PREF_STORE_IN_BLEND":  {"en": "Store Config in .blend", "ja": ".blendに設定を保存"},
    "PREF_PREFER_BLEND":    {"en": "Prefer .blend Config on Load", "ja": "起動時は.blend内設定を優先"},

    "PREF_KEYMAP_GUIDE_TITLE": {"en": "Quick Launcher Keymap Setup", "ja": "クイックランチャー キーマップ登録方法"},
    "PREF_KEYMAP_GUIDE_BODY": {
        "en": "Steps:\n1) Edit > Preferences > Keymap\n2) 3D View > 3D View (Global)\n3) Click Add New\n4) Set Operator to 'nptl.launcher'\n5) Assign your shortcut key (e.g. F4) and any modifiers\n6) Save Preferences", 
        "ja": "手順:\n1) [編集] > [プリファレンス] > [キーマップ]\n2) [3Dビュー] > [3Dビュー(グローバル)]\n3) [新規追加]\n4) オペレーターに 'nptl.launcher' を指定\n5) 任意のキー(例: F4) と修飾キーを割り当て\n6) [プリファレンスを保存]"
    },

    "DESC_CAT_ADD":         {"en": "Create a new category for the popup launcher.", "ja": "ポップアップランチャー用のカテゴリーを新規作成します。"},
    "DESC_CAT_REMOVE":      {"en": "Remove the selected category.", "ja": "選択中のカテゴリーを削除します。"},
    "DESC_CAT_UP":          {"en": "Move category up.", "ja": "カテゴリーを上に移動します。"},
    "DESC_CAT_DOWN":        {"en": "Move category down.", "ja": "カテゴリーを下に移動します。"},
    "DESC_CONT_ADD":        {"en": "Add the selected tab from 'All Detected Tabs' to this category.", "ja": "「全タブ一覧」で選択中のタブを、このカテゴリーに追加します。"},
    "DESC_CONT_REMOVE":     {"en": "Remove selected item from this category.", "ja": "このカテゴリーからアイテムを外します。"},
    "DESC_CONT_UP":         {"en": "Move item up.", "ja": "アイテムを上に移動します。"},
    "DESC_CONT_DOWN":       {"en": "Move item down.", "ja": "アイテムを下に移動します。"},
    "DESC_GLOB_REFRESH":    {"en": "Rescan the Sidebar and fully sync the tab list to the tabs that currently exist.", "ja": "現在のサイドバーを再スキャンし、実在しているタブだけに一覧を完全同期します。"},
    "DESC_GLOB_UP":         {"en": "Move tab up in the Sidebar order. Takes effect after Apply.", "ja": "サイドバーでの表示順を上に移動します (「適用」後に反映)。"},
    "DESC_GLOB_DOWN":       {"en": "Move tab down in the Sidebar order. Takes effect after Apply.", "ja": "サイドバーでの表示順を下に移動します (「適用」後に反映)。"},
    "DESC_GLOBAL_APPLY":    {"en": "Apply the renamed names and order to the actual N-panel.", "ja": "リネームした名前と並び順を、実際のNパネルに適用します。"},
    "DESC_GLOBAL_REPAIR":   {"en": "Reset the Sidebar to its default state.", "ja": "サイドバーを初期状態にリセットします。"},
    "DESC_SAVE":            {"en": "Save current settings to a JSON file.", "ja": "現在の設定をJSONファイルに書き出してバックアップします。"},
    "DESC_LOAD":            {"en": "Load settings from a JSON file and apply immediately.", "ja": "JSONファイルから設定を読み込み、即座に適用します。"},
    "DESC_PIN":             {"en": "Pin this tab so its panels stay visible on the other tabs.", "ja": "このタブのパネルを、ほかのタブを開いている時も表示します。"},
    "DESC_SMART_TOGGLE":    {"en": "Open the Sidebar on this tab when it is hidden, switch to this tab when another tab is active, or close the Sidebar when this tab is already active. Ctrl+Click opens it in a separate 3D View window using the standard Sidebar width. Alt+Click tries to open a panel from this tab directly.", "ja": "サイドバーが閉じている場合はこのタブを開き、別のタブが表示中の場合はこのタブへ切り替え、このタブがすでに表示中の場合はサイドバーを閉じます。Ctrl+クリックでは標準サイドバー幅のまま別3Dビューウィンドウで開きます。Alt+クリックではこのタブ内のパネルを直接開きます。"},
    "DESC_POPUP_TAB":       {"en": "Switch category tab in popup.", "ja": "ポップアップ内のカテゴリータブを切り替えます。"},
    "DESC_POPUP":           {"en": "Open the popup launcher.", "ja": "設定したカテゴリーから素早くアクセスできるランチャーを開きます。"},

    # --- N-panel Window 統合用 ---
    "PROP_FLOAT_HEIGHT":    {"en": "Floating Height",       "ja": "フローティングの高さ"},
    "ERR_WIN_ONLY":         {"en": "Floating window is a Windows-only feature.", "ja": "フローティングウィンドウはWindows専用の機能です。"},
    "MSG_WIN_FAIL":         {"en": "Failed to create new window.", "ja": "新規ウィンドウの作成に失敗しました。"},
    "MSG_APPLIED":          {"en": "Layout Applied!",       "ja": "レイアウトとリネームを適用しました"},
    "MSG_REPAIRED":         {"en": "N-panel tabs restored", "ja": "Nパネルのタブを元に戻しました"},
    "MSG_APPLY_FAILED":     {"en": "{count} tab(s) could not be applied", "ja": "{count} 個のタブを適用できませんでした"},
    "MSG_APPLY_FIXED":      {"en": "Applied. These tab names were kept: {names}", "ja": "適用しました。次のタブは名前を変えられません: {names}"},
    "MSG_SAVED":            {"en": "Settings Saved",        "ja": "設定を保存しました"},
    "MSG_LOADED":           {"en": "Settings Loaded",       "ja": "設定を読み込みました"},
}



CONST_TEXT.update({
    "DESC_REFRESH_PANEL_POOL": {
        "en": "Rescan the panels that belong to the detected tabs and rebuild the panel list. Use this after enabling, disabling, or installing add-ons so the panel list matches the current Blender state.",
        "ja": "検出済みタブに属するパネルを再スキャンし、パネル一覧を作り直します。アドオンの有効化・無効化・追加後に実行すると、現在のBlender状態に一覧を合わせられます。",
    },
    "DESC_FP_OPEN": {
        "en": "Open the selected floating panel entry in its own window. This is useful when you want to keep one tool visible while continuing to work in the main viewport.",
        "ja": "選択中のフローティングパネル項目を専用ウィンドウで開きます。メインのビューポートで作業を続けながら、特定ツールを常時表示しておきたいときに便利です。",
    },
    "DESC_FP_EDIT_SETTINGS": {
        "en": "Edit how the selected floating View3D panel opens and behaves. You can control its default size, placement rule, and whether the window remembers its last position.",
        "ja": "選択中のフローティングView3Dパネルの開き方と挙動を設定します。初期サイズ、表示位置のルール、前回位置の記憶などを調整できます。",
    },
    "DESC_PANVIEW_POPUP": {
        "en": "Open the 2D Pan View tool panel inside a popup. Use this when you want quick access to the 2D camera-view tools without changing the Smart Tools layout.",
        "ja": '2Dパンビューツールをポップアップで開きます。Smart Tools の配置を変えずに、2Dカメラビュー機能へすばやくアクセスしたいときに使います。',
    },
    "DESC_TOGGLE_FAVORITE_TAB": {
        "en": "Add or remove this tab from the Favorites section. Favorite tabs are shown first so you can reach your most-used tools faster.",
        "ja": "このタブを Favorites に追加または削除します。お気に入りに入れたタブは先頭側に表示され、よく使うツールへすばやくアクセスできます。",
    },
    "DESC_TOGGLE_FAVORITE_PANEL": {
        "en": "Add or remove this individual panel from Favorite Panels. Use this when you only need one specific panel instead of opening the whole tab every time.",
        "ja": "この個別パネルを Favorite Panels に追加または削除します。タブ全体ではなく、特定のパネルだけをすぐ開きたい場合に便利です。",
    },
    "DESC_CALL_PANEL": {
        "en": "Open this panel directly. Smart Tools will first make sure the correct Sidebar tab is visible, then open the selected panel for quick access.",
        "ja": "このパネルを直接開きます。Smart Tools が先に正しいサイドバータブを表示し、その後で選択パネルを開くため、目的の項目へすぐ移動できます。",
    },
    "DESC_OPEN_PANEL_POPUP": {
        "en": "Show all panels that belong to this tab. From the popup you can open a panel directly or mark specific panels as favorites.",
        "ja": "このタブに属するパネル一覧を表示します。ポップアップから個別パネルを直接開いたり、よく使うものをお気に入り登録したりできます。",
    },
    "DESC_SAVE_PRESET": {
        "en": "Save the current Smart Workspace setup as a named preset. This stores your category structure, launcher layout, favorites, and related workspace settings for reuse later.",
        "ja": "現在の Smart Workspace 設定を名前付きプリセットとして保存します。カテゴリー構成、ランチャー配置、お気に入り、関連ワークスペース設定をあとで再利用できます。",
    },
    "DESC_LOAD_PRESET": {
        "en": "Load a saved Smart Workspace preset into the current workspace profile and apply it immediately. Use this to switch layouts between projects or workflows.",
        "ja": "保存済みの Smart Workspace プリセットを現在のワークスペースプロファイルへ読み込み、すぐに適用します。案件や作業内容ごとにレイアウトを切り替えたいときに使います。",
    },
    "DESC_OPEN_CATEGORY_WINDOW": {
        "en": "Open the selected Sidebar tab in a separate 3D View window using Blender standard Sidebar behavior. The main 3D View, theme, transparency, native window size, and N-panel width are not modified.",
        "ja": "選択したサイドバータブを、Blender標準のサイドバー挙動のまま別3Dビューウィンドウで開きます。メインの3Dビュー、テーマ、透明度、ネイティブウィンドウサイズ、Nパネル幅は変更しません。",
    },
    "DESC_HOTBOX": {
        "en": "Open the radial hotbox built from favorites, recent tabs, and visible detected tabs. Move the mouse toward the target item and release to switch quickly.",
        "ja": "お気に入り、最近使ったタブ、表示中の検出タブから構成されたラジアル Hotbox を開きます。目的方向へマウスを動かして離すとすばやく切り替えられます。",
    },
    "DESC_SELECT_WORKSPACE": {
        "en": "Select which workspace profile Smart Tools should edit. Each Blender workspace can keep its own launcher categories and related settings.",
        "ja": "Smart Tools が編集対象にするワークスペースプロファイルを選びます。Blender の各ワークスペースごとに、別のランチャーカテゴリーや設定を持たせられます。",
    },
    "LBL_VIEW3D_SECTION": {"en": "View3D", "ja": "View3D"},
    "LBL_MONITOR_SECTION": {"en": "Monitor", "ja": "監視設定"},
})

translation_dict["ja_JP"].update({
    ("*", "Refresh Panel List"): "パネル一覧を更新",
    ("*", "Open Floating Panel"): "フローティングパネルを開く",
    ("*", "Edit View3D Settings"): "View3D設定を編集",
    ("*", "2D Pan View"): "2D Pan View",
    ("*", "Toggle Favorite Tab"): "お気に入りタブ切替",
    ("*", "Toggle Favorite Panel"): "お気に入りパネル切替",
    ("*", "Open Panel"): "パネルを開く",
    ("*", "Panels in Tab"): "タブ内パネル一覧",
    ("*", "Save Preset"): "プリセットを保存",
    ("*", "Load Preset"): "プリセットを読込",
    ("*", "Open N-panel"): "Nパネルを開く",
    ("*", "Open Floating N-panel"): "フローティングNパネルを開く",
    ("*", "Failed to create the floating N-panel window."): "フローティングNパネルウィンドウの作成に失敗しました。",
    ("*", "Select Workspace"): "ワークスペースを選択",
    ("*", "N-panel Hotbox"): "Nパネル Hotbox",
    ("*", "View3D"): "View3D",
    ("*", "Monitor"): "監視設定",
    ("*", "Column Width"): "列の幅",
    ("*", "Popup Columns"): "ポップアップ列数",
    ("*", "Tab Layout Mode"): "タブレイアウトモード",
    ("*", "Show Recent Tabs"): "最近使ったタブを表示",
    ("*", "Search"): "検索",
    ("*", "Pool"): "一覧表示",
    ("*", "All Tabs"): "全タブ",
    ("*", "Panel List"): "パネル一覧",
    ("*", "Apply Mode"): "適用モード",
    ("*", "Full (Category + Order + Hide)"): "完全適用（カテゴリー + 並び順 + 非表示）",
    ("*", "Category Only"): "カテゴリーのみ",
    ("*", "Order Only"): "並び順のみ",
    ("*", "Safe (Minimal)"): "安全モード（最小変更）",
    ("*", "Workspace"): "ワークスペース",
    ("*", "Default Width"): "初期幅",
    ("*", "Default Height"): "初期高さ",
    ("*", "Open Mode"): "開き方",
    ("*", "Mouse Center"): "マウス中央",
    ("*", "Last Position"): "前回位置",
    ("*", "Pinned Position"): "固定位置",
    ("*", "Follow Mouse"): "マウス追従",
    ("*", "Always On Top"): "常に手前に表示",
    ("*", "Monitor Interval (sec)"): "監視間隔（秒）",
    ("*", "Monitor Size"): "サイズを監視",
    ("*", "Monitor Settings"): "設定を監視",
    ("*", "Remember Position"): "位置を記憶",

    ("*", "Default width for a newly opened floating View3D window. Increase this when the panel feels cramped."):
        "新しく開くフローティングView3Dウィンドウの初期幅です。パネル内容が窮屈に感じる場合は大きくしてください。",
    ("*", "Default height for a newly opened floating View3D window. Increase this when the panel needs more vertical space."):
        "新しく開くフローティングView3Dウィンドウの初期高さです。縦方向の余白が足りない場合は大きくしてください。",
    ("*", "Choose where the floating View3D window appears when you open it. Mouse Center is easiest for beginners, Last Position reopens where you last left it, Pinned Position keeps a fixed spot, and Follow Mouse keeps chasing the cursor while open."):
        "フローティングView3Dウィンドウを開く位置ルールです。初心者にはマウス中央がわかりやすく、前回位置は最後に閉じた場所、固定位置は決まった場所、マウス追従は開いている間カーソルに追従します。",
    ("*", "Keep the floating View3D window above other application windows when possible. Useful for reference-style side panels."):
        "可能な場合、このフローティングView3Dウィンドウを他のアプリより手前に保ちます。参照用サイドパネルとして使うときに便利です。",
    ("*", "How often the floating window checks size, position, and always-on-top settings. Lower values react faster but check more often."):
        "フローティングウィンドウがサイズ、位置、常に手前設定などを確認する頻度です。値を小さくすると反応は速くなりますが、確認回数も増えます。",
    ("*", "Keep saving the floating window size while you resize it, so the next open can reuse the latest size."):
        "ウィンドウサイズ変更中もサイズを記録し、次回オープン時に最新サイズを再利用できるようにします。",
    ("*", "Keep applying runtime settings such as Always On Top while the floating window is open."):
        "フローティングウィンドウが開いている間、常に手前などの実行時設定を維持します。",
    ("*", "Remember the last screen position of the floating window so it can reopen in a familiar place."):
        "フローティングウィンドウの最後の画面位置を記憶し、次回も同じ場所付近に再表示します。",

    ("*", "Show or hide this detected Sidebar tab in the Smart Tools launcher. Turn this off when you want to keep the tab available in Blender but remove it from your curated launcher."):
        "検出したサイドバータブを Smart Tools ランチャーに表示するかを切り替えます。Blender 側には残したまま、ランチャーだけから外したいときはOFFにします。",
    ("*", "Rename the detected tab for the Smart Tools launcher. The real Sidebar tab takes this name when you press Apply Rename & Order. Leave empty to keep the original name."):
        "検出したタブにランチャー用の名前を付けます。「Nパネルにリネームと並び順を適用」を押すと、実際のサイドバーのタブもこの名前になります。空欄なら元の名前を使います。",
    ("*", "Keep this tab visible together with the currently active tab. Use this for tabs you want to access all the time while working."):
        "このタブを現在のアクティブタブと一緒に常時表示します。作業中いつでも見たいタブに使います。",

    ("*", "Choose what the lower management list shows. 'All Tabs' is for organizing detected Sidebar tabs, while 'Panel List' is for picking individual panels or creating floating panel entries."):
        "下部管理リストに何を表示するか選びます。『全タブ』は検出済みサイドバータブの整理用、『パネル一覧』は個別パネル選択やフローティング項目作成用です。",
    ("*", "Width of a single launcher column. Increase this when button labels are cut off or when you use long custom names."):
        "ランチャー1列分の幅です。ボタン名が切れる場合や、長いカスタム名を使う場合に広げてください。",
    ("*", "How many columns the popup launcher uses. More columns show more tools at once but make the popup wider."):
        "ポップアップランチャーの列数です。列を増やすと一度に多くのツールを表示できますが、ポップアップ幅は広くなります。",
    ("*", "Display categories as tabs across the top of the popup instead of separate boxes. Useful when you have many categories and want a cleaner compact launcher."):
        "カテゴリーを個別ボックスではなく、ポップアップ上部のタブとして表示します。カテゴリー数が多く、すっきりしたレイアウトにしたい場合に便利です。",
    ("*", "Show the Recent section in the launcher so you can quickly reopen tabs you used lately."):
        "ランチャーに Recent セクションを表示し、最近使ったタブをすばやく開き直せるようにします。",
    ("*", "Target height for the dedicated floating Sidebar window opened from Smart Tools. Increase this when tall panels are being clipped."):
        "Smart Tools から開く専用フローティングサイドバーウィンドウの目標高さです。背の高いパネルが切れる場合は大きくしてください。",
    ("*", "Default width used when Smart Tools creates a new floating View3D panel window."):
        "Smart Tools が新しいフローティングView3Dパネルウィンドウを作るときの初期幅です。",
    ("*", "Default height used when Smart Tools creates a new floating View3D panel window."):
        "Smart Tools が新しいフローティングView3Dパネルウィンドウを作るときの初期高さです。",
    ("*", "Choose the default placement rule for newly created floating View3D panel windows. Mouse Center is the simplest starting point."):
        "新しく作成するフローティングView3Dパネルウィンドウの既定配置ルールです。最初はマウス中央がもっとも扱いやすい設定です。",
    ("*", "Keep new floating View3D panel windows above other windows when possible."):
        "可能な場合、新しく開くフローティングView3Dパネルウィンドウを他ウィンドウより手前に保ちます。",
    ("*", "How often Smart Tools checks and updates floating View3D window state while it is open."):
        "フローティングView3Dウィンドウの状態を Smart Tools が確認・更新する頻度です。",
    ("*", "Save size changes made to floating View3D windows so future openings can reuse the latest size."):
        "フローティングView3Dウィンドウで行ったサイズ変更を保存し、次回オープン時に再利用します。",
    ("*", "Keep applying runtime window settings such as Always On Top while the floating View3D window is open."):
        "フローティングView3Dウィンドウが開いている間、常に手前などの実行時設定を継続して適用します。",
    ("*", "Save the last screen position of floating View3D windows and reuse it the next time they open."):
        "フローティングView3Dウィンドウの最後の画面位置を保存し、次回オープン時に再利用します。",
    ("*", "Filter items shown in the launcher or management lists. Type part of a tab or panel name to narrow the list."):
        "ランチャーや管理リストに表示する項目を絞り込みます。タブ名やパネル名の一部を入力して候補を減らせます。",
    ("*", "Choose how strongly Smart Tools changes the real N-panel. Use Full for complete control, and switch to safer modes if another add-on conflicts with tab renaming or ordering."):
        "Smart Tools が実際のNパネルをどこまで変更するか選びます。完全制御したい場合は Full、他アドオンとリネームや並び順が競合する場合は安全寄りモードに切り替えます。",
    ("*", "Workspace whose Smart Tools profile you want to inspect or edit."):
        "Smart Tools のプロファイルを確認・編集したい対象ワークスペースです。",

    ("*", "Default width for the floating View3D window opened from this entry. Increase it when the panel contents feel cramped."):
        "この項目から開くフローティングView3Dウィンドウの初期幅です。パネル内容が窮屈なら広げてください。",
    ("*", "Default height for the floating View3D window opened from this entry. Increase it when the panel is taller than the window."):
        "この項目から開くフローティングView3Dウィンドウの初期高さです。パネルがウィンドウより高い場合は大きくしてください。",
    ("*", "Choose where the floating View3D window appears. Mouse Center is easiest to understand, Last Position reopens where you left it, Pinned Position uses a fixed spot, and Follow Mouse tracks the cursor while open."):
        "フローティングView3Dウィンドウの表示位置ルールです。マウス中央は理解しやすく、前回位置は最後の場所、固定位置は決まった位置、マウス追従は開いている間カーソルに追従します。",
    ("*", "Keep this floating window above other application windows when possible."):
        "可能な場合、このフローティングウィンドウを他アプリより手前に保ちます。",
    ("*", "How often the floating window checks size, position, and other runtime settings while it is open."):
        "フローティングウィンドウが開いている間、サイズ・位置・その他実行時設定を確認する頻度です。",
    ("*", "Save size changes made while the window is open so the next open can reuse that size."):
        "ウィンドウが開いている間のサイズ変更を保存し、次回オープン時にそのサイズを再利用します。",
    ("*", "Remember the last screen position of this floating window and reuse it later."):
        "このフローティングウィンドウの最後の画面位置を記憶し、後で再利用します。",
    ("*", "Name used to save or load a Smart Tools preset. Use clear project-specific names so you can recognize them later."):
        "Smart Tools プリセットの保存・読込に使う名前です。後で見分けやすいように、案件名や用途名を含めるのがおすすめです。",
})



CONST_TEXT.update({
    "DESC_COPY_PROFILE": {
        "en": "Copy every supported Smart Tools setting from the selected workspace profile into the workspace you are currently viewing. This is useful when you want to reuse the same launcher setup without rebuilding it by hand.",
        "ja": "選択中ワークスペースプロファイルの Smart Workspace 設定を、現在表示中のワークスペースへまとめてコピーします。同じランチャー構成を手作業で作り直したくないときに便利です。",
    },
    "DESC_CAT_ADD": {
        "en": "Create a new launcher category. Categories are the top-level groups shown in the popup launcher, so use them to separate work by purpose such as modeling, shading, or utilities.",
        "ja": "新しいランチャーカテゴリーを作成します。カテゴリーはポップアップランチャーの最上位グループなので、モデリング、シェーダー、補助機能など目的別に分けると整理しやすくなります。",
    },
    "DESC_CAT_REMOVE": {
        "en": "Remove the selected launcher category. Tabs contained in it are only removed from that category and can be added elsewhere again later.",
        "ja": "選択中のランチャーカテゴリーを削除します。中に入っていたタブはそのカテゴリーから外れるだけで、あとで別のカテゴリーへ再追加できます。",
    },
    "DESC_CAT_UP": {
        "en": "Move the selected category upward in the launcher order. This changes where the category appears in the popup so you can keep important groups near the front.",
        "ja": "選択中カテゴリーをランチャー内で上へ移動します。ポップアップ内の表示位置を調整し、重要なグループを先頭付近に置けます。",
    },
    "DESC_CAT_DOWN": {
        "en": "Move the selected category downward in the launcher order. Use this to place less-used groups later in the popup.",
        "ja": "選択中カテゴリーをランチャー内で下へ移動します。使用頻度の低いグループを後ろ側へ回したいときに使います。",
    },
    "DESC_CONT_ADD": {
        "en": "Add the tab currently selected in All Detected Tabs to the active launcher category. This is how you build the contents of each category button group.",
        "ja": "『全タブ一覧』で選択中のタブを、現在のランチャーカテゴリーへ追加します。各カテゴリーの中身を組み立てる基本操作です。",
    },
    "DESC_CONT_REMOVE": {
        "en": "Remove the selected item from the current category only. The original detected tab itself is not deleted from Blender.",
        "ja": "選択中の項目を現在のカテゴリーからだけ外します。元の検出タブ自体が Blender から消えるわけではありません。",
    },
    "DESC_CONT_UP": {
        "en": "Move the selected item upward inside the current category. The new order is reflected in the launcher button arrangement.",
        "ja": "選択中項目を現在のカテゴリー内で上へ移動します。新しい順番はランチャーボタンの並びに反映されます。",
    },
    "DESC_CONT_DOWN": {
        "en": "Move the selected item downward inside the current category. Use this to fine-tune the order in which tools appear.",
        "ja": "選択中項目を現在のカテゴリー内で下へ移動します。ツールの表示順を細かく整えたいときに使います。",
    },
    "DESC_GLOB_REFRESH": {
        "en": "Rescan the real Blender Sidebar and synchronize the detected tab list with what currently exists. Run this after installing, disabling, or updating add-ons.",
        "ja": "実際の Blender サイドバーを再スキャンし、検出タブ一覧を現在存在する状態へ同期します。アドオンの追加・停止・更新後に実行すると確実です。",
    },
    "DESC_GLOB_UP": {
        "en": "Move the selected detected tab upward in Smart Tools' desired Sidebar order. The visible Sidebar changes after you apply the layout.",
        "ja": "選択中の検出タブを、Smart Tools が目指すサイドバー順の中で上へ移動します。実際の表示はレイアウト適用後に反映されます。",
    },
    "DESC_GLOB_DOWN": {
        "en": "Move the selected detected tab downward in Smart Tools' desired Sidebar order. Apply afterward if you want Blender's Sidebar to follow that order.",
        "ja": "選択中の検出タブを、Smart Tools が目指すサイドバー順の中で下へ移動します。Blender のサイドバーにも反映したい場合は後で適用してください。",
    },
    "DESC_GLOBAL_APPLY": {
        "en": "Give Blender's actual N-panel tabs the names and order of this list. Blender's own Item tab keeps its name and place. Use this after finishing your changes.",
        "ja": "実際の N パネルのタブを、この一覧の名前と並び順にします。Blender 本体の「アイテム」のタブは名前も位置も変わりません。変更が終わったあとに押します。",
    },
    "DESC_GLOBAL_REPAIR": {
        "en": "Put the N-panel tab names and order back as Blender and the add-ons made them, and remove this workspace's tab pins. The names in this list stay for the launcher.",
        "ja": "N パネルのタブの名前と並び順を、元の状態に戻します。このワークスペースのタブのピンも外します。一覧に付けた名前はランチャー用に残ります。",
    },
    "DESC_SAVE": {
        "en": "Export the current Smart Workspace settings to a JSON file. This is the safest way to back up your layout before large changes or before moving to another machine.",
        "ja": "現在の Smart Workspace 設定を JSON ファイルへ書き出します。大きな変更前や別マシンへ移す前のバックアップに最適です。",
    },
    "DESC_LOAD": {
        "en": "Import Smart Workspace settings from a JSON file and apply them immediately. Use this to restore a backup or to share the same setup between projects.",
        "ja": "JSON ファイルから Smart Workspace 設定を読み込み、すぐに適用します。バックアップ復元や、案件間で同じ設定を共有したいときに使います。",
    },
    "DESC_PIN": {
        "en": "Pin this tab using Blender's standard N-panel header pin behavior, the same pin available from a panel header right-click menu. Use this when you want the panels in this tab to stay visible with other tabs.",
        "ja": "Blender標準のNパネルヘッダー右クリックにあるパネル固定と同じ方式で、このタブをピン留めします。このタブ内のパネルを他のタブと一緒に表示したいときに使います。",
    },
    "DESC_SMART_TOGGLE": {
        "en": 'Open the Sidebar on this tab when it is hidden, switch to this tab when another tab is active, or close the Sidebar when this tab is already active. Ctrl+Click opens the category in a separate 3D View window using the standard Sidebar width. Alt+Click tries to open a panel from that tab directly.',
        "ja": "サイドバーが閉じている場合はこのタブを開き、別のタブが表示中の場合はこのタブへ切り替え、このタブがすでに表示中の場合はサイドバーを閉じます。Ctrl+クリックでは標準サイドバー幅のまま別3Dビューウィンドウでこのカテゴリーを開きます。Alt+クリックではこのタブ内のパネルを直接開きます。",
    },
    "DESC_POPUP_TAB": {
        "en": "Switch the category page shown inside the popup launcher when Tab Layout Mode is enabled.",
        "ja": "タブレイアウトモード有効時に、ポップアップランチャー内で表示するカテゴリーページを切り替えます。",
    },
    "DESC_POPUP": {
        "en": "Open the Smart Tools popup launcher. It shows the categories you configured so you can jump to tabs, floating panels, and related tools without searching manually.",
        "ja": "Smart Tools のポップアップランチャーを開きます。設定したカテゴリーから、タブ、フローティングパネル、関連ツールへ手作業で探さず移動できます。",
    },
})


_TRANSLATION_CONTEXTS = (
    '', '*', 'Operator', 'Property', 'Tooltip', 'UI', 'Panel', 'Menu', 'Addon',
    'WindowManager', 'Preferences', 'Button', 'Label', 'Info', 'Report',
)


def _merge_catalog_into_translation_dict() -> None:
    table = translation_dict.setdefault('ja_JP', {})

    def add(en: object, ja: object) -> None:
        en_text = str(en or '').strip()
        ja_text = str(ja or '').strip()
        if not en_text or not ja_text or en_text == ja_text:
            return
        for ctx in _TRANSLATION_CONTEXTS:
            table.setdefault((ctx, en_text), ja_text)

    try:
        from ..translation_catalog import TRANSLATIONS
    except Exception:
        try:
            from translation_catalog import TRANSLATIONS
        except Exception:
            TRANSLATIONS = ()
    for en, ja in TRANSLATIONS:
        add(en, ja)

    try:
        for item in CONST_TEXT.values():
            if isinstance(item, dict):
                add(item.get('en'), item.get('ja'))
    except Exception:
        pass


translation_dict.setdefault("ja_JP", {}).update({
    ("*", "Smart Workspace N-panel"): "Smart Workspace Nパネル",
    ("*", "Show the Smart Workspace controls in the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルにSmart Workspace操作を表示します。",
    ("*", "Show Smart Workspace controls in the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルにSmart Workspace操作を表示します。",
    ("*", "Show Smart Workspace settings in the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルにSmart Workspace設定を表示します。",
    ("*", "Open this menu from the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルからこのメニューを開きます。",
    ("*", "Open operator choices from the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルからオペレーター候補を開きます。",
    ("*", "Open this pie menu from the standard 3D View Sidebar N-panel."): "標準の3DビューサイドバーNパネルからこのパイメニューを開きます。",
    ("*", "No available 3D View Sidebar was found."): "利用できる3Dビューサイドバーがありません。",
})

_merge_catalog_into_translation_dict()

def get_blender_locale(context=None):
    """Return the actual Blender locale in use, respecting Automatic mode."""
    prefs = getattr(context, "preferences", None) or getattr(getattr(bpy, "context", None), "preferences", None)
    view = getattr(prefs, "view", None)

    try:
        if view is not None and hasattr(view, "use_translate_interface") and not view.use_translate_interface:
            return "en_US"
    except Exception:
        pass

    try:
        lang = str(getattr(view, "language", "") or "").strip()
        if lang and lang.upper() != "DEFAULT":
            return lang
    except Exception:
        pass

    try:
        locale_code = getattr(getattr(bpy.app, "translations", None), "locale", "") or ""
        if locale_code:
            return locale_code
    except Exception:
        pass

    return "en_US"


def is_japanese(context=None):
    try:
        return (get_blender_locale(context) or "").lower().startswith("ja")
    except Exception:
        return False


def _T(key):
    try:
        if is_japanese(getattr(bpy, "context", None)):
            val = CONST_TEXT.get(key, {}).get("ja", None)
            if val:
                return val
    except Exception:
        pass
    return CONST_TEXT.get(key, {}).get("en", key)


def _T_ctx(context, key):
    try:
        if is_japanese(context):
            val = CONST_TEXT.get(key, {}).get("ja", None)
            if val:
                return val
    except Exception:
        pass
    return CONST_TEXT.get(key, {}).get("en", key)

# -----------------------------------------------------------------------------
# Toolset-wide i18n bridge
# -----------------------------------------------------------------------------
# Keep this bridge at the end so legacy CONST_TEXT/_T lookups remain intact while
# every workspace-runtime draw path uses the same strict EN/JA language selector
# and exact/fragment fallback catalog as the rest of Smart Workspace.
try:
    from .. import translation as _SWS_I18N

    contains_japanese = _SWS_I18N.contains_japanese
    ui_pair = _SWS_I18N.ui_pair
    ui_text = _SWS_I18N.ui_text
    localized_layout = _SWS_I18N.localized_layout

    def is_japanese(context=None):
        return _SWS_I18N.is_japanese(context)

    try:
        translation_dict.setdefault("ja_JP", {}).update(_SWS_I18N.translation_dict.get("ja_JP", {}))
        translation_dict.setdefault("en_US", {}).update(_SWS_I18N.translation_dict.get("en_US", {}))
    except Exception:
        pass
except Exception:
    pass
