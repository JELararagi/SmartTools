# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
import json
import os
import sys
import shutil
import re
import datetime
import copy
import functools
import uuid
import hashlib
import time
import gpu
from typing import List, Optional, Set, Dict, Any
from .. import storage as _suite_storage
from .. import strict_json_contract as _strict_json
from bpy.types import PropertyGroup, Panel
from bpy.props import (
    CollectionProperty,
    IntProperty,
    StringProperty,
    BoolProperty,
    PointerProperty,
    FloatProperty,
)

# =============================================================
# 0. 定数・設定
# =============================================================

SWS_SECTION_UI_STATE_PROPS = (
    'n_panel_state_save_enabled',
    'show_always_on_toggles',
    'ui_show_section_always_on_toggles',
    'ui_show_section_workspace_manager',
    'ui_show_section_n_panel_manager',
    'ui_show_section_viewport_optimization',
    'ui_show_section_workspace_launcher',
    'ui_show_section_categories',
    'ui_show_section_panel_pool',
    'ui_show_section_smart_tools_settings',
    'ui_show_section_presets_io',
    'ui_show_section_integrated_tools',
    'ui_show_section_panview',
    'ui_show_section_local_ui_toggle',
    'ui_show_section_workspace_step_reorder',
    'workspace_step_reorder_enabled',
    'ui_show_section_synchronize_workspaces',
    'synchronize_workspaces_enabled',
    'ui_show_section_floating_window_lock',
    'floating_window_lock_enabled',
)


def _ui_state_to_dict(st) -> dict:
    data = {}
    for prop_name in SWS_SECTION_UI_STATE_PROPS:
        default = True if prop_name == 'n_panel_state_save_enabled' else False
        try:
            value = getattr(st, prop_name, default)
            data[prop_name] = value if isinstance(value, bool) else default
        except Exception:
            data[prop_name] = default
    return data


def _apply_ui_state(st, ui_state: dict) -> None:
    if st is None or not isinstance(ui_state, dict):
        return
    for prop_name in SWS_SECTION_UI_STATE_PROPS:
        if not hasattr(st, prop_name):
            continue
        default = True if prop_name == 'n_panel_state_save_enabled' else bool(getattr(st, prop_name, False))
        raw = ui_state.get(prop_name, default)
        # Strict JSON booleans only.  Strings/integers from damaged imports do
        # not silently become True/False and cannot overwrite a valid value.
        if not isinstance(raw, bool):
            raw = default
        try:
            setattr(st, prop_name, raw)
        except Exception:
            pass
    try:
        _suite_storage.set_n_panel_state_save_runtime_policy(
            bool(getattr(st, 'n_panel_state_save_enabled', True))
        )
    except Exception:
        pass


def save_ui_state_to_file(context, *, force: bool = False) -> bool:
    """Persist section state through the bounded live-state journal."""
    return bool(_schedule_live_state_write(
        context,
        include_profile=False,
        include_ui=True,
        allow_disabled=bool(force),
    ))


def _nptl_json_scalar(value: Any, default: Any = None) -> Any:
    try:
        if isinstance(value, (bool, int, float, str)) or value is None:
            return value
        return str(value)
    except Exception:
        return default


def _nptl_safe_get(obj: Any, attr: str, default: Any = None) -> Any:
    try:
        return getattr(obj, attr, default)
    except Exception:
        return default


def _nptl_safe_str(obj: Any, attr: str, default: str = "") -> str:
    try:
        return str(getattr(obj, attr, default) or "")
    except Exception:
        return default


def _nptl_safe_int(obj: Any, attr: str, default: int = 0) -> int:
    try:
        value = getattr(obj, attr, default)
        return int(default if value is None else value)
    except Exception:
        return int(default)


def _nptl_safe_float(obj: Any, attr: str, default: float = 0.0) -> float:
    try:
        value = getattr(obj, attr, default)
        return float(default if value is None else value)
    except Exception:
        return float(default)


def _nptl_safe_bool(obj: Any, attr: str, default: bool = False) -> bool:
    try:
        return bool(getattr(obj, attr, default))
    except Exception:
        return bool(default)


def _nptl_tab_ref_to_dict(item: Any) -> Dict[str, Any]:
    return {
        "id": _normalize_tab_identifier(_nptl_safe_str(item, "identifier", "")),
        "label": _display_tab_label(_nptl_safe_str(item, "custom_label", "")),
    }


def _nptl_recent_tab_to_dict(item: Any) -> Dict[str, Any]:
    return {
        "id": _normalize_tab_identifier(_nptl_safe_str(item, "identifier", "")),
        "label": _display_tab_label(_nptl_safe_str(item, "custom_label", "")),
        "ts": _nptl_safe_float(item, "last_used", 0.0),
    }


def _nptl_favorite_panel_to_dict(item: Any) -> Dict[str, Any]:
    return {
        "id": _nptl_safe_str(item, "panel_idname", ""),
        "label": _display_tab_label(_nptl_safe_str(item, "label", "")),
        "cat": _display_tab_identifier(_nptl_safe_str(item, "category", "")),
    }


def _nptl_detected_panel_to_dict(item: Any) -> Dict[str, Any]:
    return {
        "id": _nptl_safe_str(item, "panel_idname", ""),
        "label": _display_tab_label(_nptl_safe_str(item, "label", "")),
        "cat": _display_tab_identifier(_nptl_safe_str(item, "category", "")),
        "panview": _nptl_safe_bool(item, "is_panview", False),
    }


def _nptl_detected_tab_to_dict(item: Any) -> Dict[str, Any]:
    identifier = _normalize_tab_identifier(_nptl_safe_str(item, "identifier", ""))
    return {
        # Keep the compact legacy key for backward compatibility, while also
        # writing the exact RNA identifier used by the N-panel.  The exact key
        # makes every editable field independently attributable in the
        # canonical JSON contract.
        "id": identifier,
        "identifier": identifier,
        "name": _display_tab_label(_nptl_safe_str(item, "name", "")),
        "custom_name": _display_tab_label(_nptl_safe_str(item, "custom_name", "")),
        "show": _nptl_safe_bool(item, "show", True),
        "is_pinned": _nptl_safe_bool(item, "is_pinned", False),
        "original_category": _display_tab_identifier(_nptl_safe_str(item, "original_category", "")),
    }


def _nptl_category_to_dict(cat: Any) -> Dict[str, Any]:
    tabs = []
    try:
        for tab in getattr(cat, "tabs", []) or []:
            tabs.append(_nptl_tab_ref_to_dict(tab))
    except Exception:
        tabs = []
    active_tab_index = _nptl_safe_int(cat, "active_tab_index", 0)
    return {
        "name": _normalize_half_width_spaces(_nptl_safe_str(cat, "name", "New Category")),
        # ``active_idx`` is retained for existing user files; the exact RNA
        # spelling is the canonical field written by current versions.
        "active_idx": active_tab_index,
        "active_tab_index": active_tab_index,
        "tabs": tabs,
    }


def _nptl_floating_panel_to_dict(item: Any) -> Dict[str, Any]:
    return {
        "key": _nptl_safe_str(item, "key", ""),
        "panel": _nptl_safe_str(item, "panel_idname", ""),
        "label": _display_tab_label(_nptl_safe_str(item, "label", "")),
        "cat": _display_tab_identifier(_nptl_safe_str(item, "category", "")),
        "w": _nptl_safe_int(item, "default_w", 500),
        "h": _nptl_safe_int(item, "default_h", 800),
        "open_mode": _nptl_safe_str(item, "open_mode", "MOUSE"),
        "top": _nptl_safe_bool(item, "always_on_top", False),
        "ival": _nptl_safe_float(item, "monitor_interval", 0.5),
        "ms": _nptl_safe_bool(item, "monitor_size", True),
        "mset": _nptl_safe_bool(item, "monitor_settings", True),
        "rp": _nptl_safe_bool(item, "remember_position", True),
        "lx": _nptl_safe_int(item, "last_x", -1),
        "ly": _nptl_safe_int(item, "last_y", -1),
        "lw": _nptl_safe_int(item, "last_w", 0),
        "lh": _nptl_safe_int(item, "last_h", 0),
        "px": _nptl_safe_int(item, "pinned_x", -1),
        "py": _nptl_safe_int(item, "pinned_y", -1),
    }


_WORKSPACE_UUID_KEY = "_sws_workspace_uuid_v1"
_PROFILE_UUID_KEY = "_sws_workspace_profile_uuid_v1"
_MANAGER_RUNTIME_NAMESPACE_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1"
_MANAGER_WORKSPACE_KEYS = (
    "LAYOUT", "MODELING", "SCULPTING", "UV_EDITING", "TEXTURE_PAINT", "SHADING",
    "ANIMATION", "RENDERING", "COMPOSITING", "GEOMETRY_NODES", "SCRIPTING",
    "ANIMATION_2D", "FULL_CANVAS_2D", "MASKING", "MOTION_TRACKING", "VIDEO_EDITING",
)
_MANAGER_EDITOR_KEYS = (
    "VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR", "SHADER_EDITOR", "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR", "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR", "DOPE_SHEET", "GRAPH_EDITOR", "DRIVERS", "NLA_EDITOR",
    "TEXT_EDITOR", "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET",
)
_MANAGER_TOOL_KEYS = (
    "SMART_FILE", "SMART_WORKSPACE", "SMART_OVERLAY", "SMART_PAINT", "SMART_TRANSFORM",
    "SMART_CAMLIGHT", "SMART_GEOMETRY", "SMART_ID", "SMART_MODELING", "SMART_MODIFIER",
    "SMART_SCULPT", "SMART_SHAPEKEY", "SMART_UV", "SMART_RIG", "SMART_SHADER",
    "SMART_NODE", "SMART_CLOTH", "SMART_SELECTOR", "SMART_ANIMATION", "SMART_RENDER",
    "SMART_COMPOSITE",
)


def _normalize_workspace_identity_name(value: Any) -> str:
    try:
        text = str(value or "").casefold()
    except Exception:
        return ""
    return "".join(character for character in text if character.isalnum())


_WORKSPACE_NAME_ALIASES = {
    "LAYOUT": ("Layout", "\u30ec\u30a4\u30a2\u30a6\u30c8"),
    "MODELING": ("Modeling", "\u30e2\u30c7\u30ea\u30f3\u30b0"),
    "SCULPTING": ("Sculpting", "\u30b9\u30ab\u30eb\u30d7\u30c8"),
    "UV_EDITING": ("UV Editing", "UV\u30a8\u30c7\u30a3\u30c6\u30a3\u30f3\u30b0", "UV\u7de8\u96c6"),
    "TEXTURE_PAINT": ("Texture Paint", "\u30c6\u30af\u30b9\u30c1\u30e3\u30da\u30a4\u30f3\u30c8"),
    "SHADING": ("Shading", "\u30b7\u30a7\u30fc\u30c7\u30a3\u30f3\u30b0"),
    "ANIMATION": ("Animation", "\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3"),
    "RENDERING": ("Rendering", "\u30ec\u30f3\u30c0\u30ea\u30f3\u30b0"),
    "COMPOSITING": ("Compositing", "\u30b3\u30f3\u30dd\u30b8\u30c6\u30a3\u30f3\u30b0"),
    "GEOMETRY_NODES": ("Geometry Nodes", "Geometry Node", "\u30b8\u30aa\u30e1\u30c8\u30ea\u30ce\u30fc\u30c9"),
    "SCRIPTING": ("Scripting", "\u30b9\u30af\u30ea\u30d7\u30c6\u30a3\u30f3\u30b0", "\u30b9\u30af\u30ea\u30d7\u30c8\u4f5c\u6210"),
    "ANIMATION_2D": ("2D Animation", "2D\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3"),
    "FULL_CANVAS_2D": ("2D Full Canvas", "2D\u30d5\u30eb\u30ad\u30e3\u30f3\u30d0\u30b9"),
    "MASKING": ("Masking", "\u30de\u30b9\u30ad\u30f3\u30b0"),
    "MOTION_TRACKING": ("Motion Tracking", "\u30e2\u30fc\u30b7\u30e7\u30f3\u30c8\u30e9\u30c3\u30ad\u30f3\u30b0"),
    "VIDEO_EDITING": ("Video Editing", "\u30d3\u30c7\u30aa\u7de8\u96c6"),
}
_WORKSPACE_KEY_BY_NORMALIZED_NAME = {
    _normalize_workspace_identity_name(alias): workspace_key
    for workspace_key, aliases in _WORKSPACE_NAME_ALIASES.items()
    for alias in (workspace_key, *aliases)
    if _normalize_workspace_identity_name(alias)
}


def _workspace_semantic_key(value: Any) -> str:
    normalized = _normalize_workspace_identity_name(value)
    if not normalized:
        return ""
    return _WORKSPACE_KEY_BY_NORMALIZED_NAME.get(normalized, f"CUSTOM:{normalized}")


def _workspace_profile_payload_score(value: Any) -> int:
    if not isinstance(value, dict):
        return 0
    weighted_fields = (
        ("categories", 1000),
        ("detected_tabs", 20),
        ("detected", 20),
        ("detected_panels", 20),
        ("favorite_panels", 10),
        ("favorites_tabs", 10),
        ("floating_panels", 10),
        ("recent_tabs", 1),
    )
    score = 0
    for field, weight in weighted_fields:
        rows = value.get(field)
        if isinstance(rows, (list, tuple, dict)):
            score += len(rows) * weight
    for field, default in (
        ("popup_width", 200),
        ("pool_mode", "TABS"),
        ("apply_mode", "FULL"),
        ("search_query", ""),
    ):
        if value.get(field, default) != default:
            score += 1
    return score


def _payload_configuration_activity(value: Any) -> int:
    if not isinstance(value, dict):
        return 0
    profiles = value.get("workspace_profiles")
    if isinstance(profiles, dict):
        rows = list(profiles.values())
    elif isinstance(profiles, list):
        rows = profiles
    else:
        workspaces = value.get("workspaces")
        rows = list(workspaces.values()) if isinstance(workspaces, dict) else []
    templates = value.get("workspace_templates")
    if isinstance(templates, dict):
        rows.extend(templates.values())
    return sum(_workspace_profile_payload_score(row) for row in rows)


_NPTL_WORKSPACE_TEMPLATES: Dict[str, Any] = {}
_PERSISTED_MANAGER_RULE_MATRIX: Dict[str, Any] = {}
_LOADING_PROFILE_UUID_BY_NAME: Dict[str, str] = {}
_LAST_LOADED_N_PANEL_AUTHORITY: Dict[str, Any] = {}
_LAST_NPTL_LOAD_ERROR = ""
_LAST_NPTL_LOAD_INFO = ""
_LIVE_STATE_SCHEMA = "SMART_WORKSPACE_N_PANEL_LIVE_STATE_V1"
_LIVE_STATE_SESSION_ID = uuid.uuid4().hex
_LIVE_STATE_TIMER_SLOT = "runtime.core.n_panel_live_state"
_LIVE_STATE_DELAY = 0.5
_LIVE_STATE_LAST_HASH: Dict[str, str] = {}
_LIVE_STATE_DEADLINE = 0.0
_LIVE_STATE_CACHE: Optional[Dict[str, Any]] = None
_LIVE_STATE_PENDING_PROFILES: Set[str] = set()
_LIVE_STATE_PENDING_UI = False
_LIVE_STATE_RECOVERY_REASON = ""


def _loaded_bool(value: Any, default: bool) -> bool:
    """Accept only a real JSON/RNA Boolean; preserve explicit False."""
    return value if isinstance(value, bool) else bool(default)


def _loaded_int(value: Any, default: int) -> int:
    """Preserve explicit zero while rejecting Boolean-as-integer values."""
    if isinstance(value, bool):
        return int(default)
    if isinstance(value, int):
        return int(value)
    try:
        return int(value) if value is not None else int(default)
    except (TypeError, ValueError, OverflowError):
        return int(default)


def _loaded_float(value: Any, default: float) -> float:
    """Preserve explicit 0.0 while rejecting Boolean-as-number values."""
    if isinstance(value, bool):
        return float(default)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(value) if value is not None else float(default)
    except (TypeError, ValueError, OverflowError):
        return float(default)


def _loaded_str(value: Any, default: str = "") -> str:
    """Preserve an explicit empty string as an authoritative loaded value."""
    if isinstance(value, str):
        return value
    return str(default)


def _workspace_uuid(workspace: Any, *, create: bool) -> str:
    if workspace is None:
        return ""
    try:
        value = workspace.get(_WORKSPACE_UUID_KEY, "")
    except Exception:
        value = ""
    value = str(value or "").strip()
    try:
        uuid.UUID(value)
        return value
    except Exception:
        pass
    if not create:
        return ""
    value = str(uuid.uuid4())
    try:
        workspace[_WORKSPACE_UUID_KEY] = value
        return value
    except Exception:
        # A linked/read-only workspace receives an in-memory deterministic UUID
        # based on its current name.  It is never deleted or modified.
        name = str(getattr(workspace, 'name_full', getattr(workspace, 'name', '')) or '')
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"smart-workspace:{name}"))


def _profile_workspace_uuid(profile: Any) -> str:
    try:
        value = profile.get(_PROFILE_UUID_KEY, "")
    except Exception:
        value = ""
    return str(value or "")


def _set_profile_workspace_uuid(profile: Any, value: str) -> None:
    text = str(value or "").strip()
    if not text:
        return
    try:
        uuid.UUID(text)
    except Exception:
        return
    try:
        profile[_PROFILE_UUID_KEY] = text
    except Exception:
        pass


def _reconcile_workspace_profiles(st: Any) -> None:
    """Bound normal profiles to live Workspace UUIDs and names."""
    global _NPTL_WORKSPACE_TEMPLATES
    if st is None:
        return
    live_by_uuid: Dict[str, Any] = {}
    live_by_name: Dict[str, Any] = {}
    live_by_semantic: Dict[str, list[Any]] = {}
    try:
        for workspace in bpy.data.workspaces:
            identity = _workspace_uuid(workspace, create=True)
            name = str(getattr(workspace, 'name', '') or '')
            if identity:
                live_by_uuid[identity] = workspace
            live_by_name[name] = workspace
            semantic = _workspace_semantic_key(name)
            if semantic:
                live_by_semantic.setdefault(semantic, []).append(workspace)
    except Exception:
        return
    remove_indices = []
    matched = set()
    try:
        profiles = list(st.workspace_profiles)
    except Exception:
        profiles = []
    for index, profile in enumerate(profiles):
        identity = _profile_workspace_uuid(profile)
        name = str(getattr(profile, 'workspace_name', '') or '')
        workspace = live_by_uuid.get(identity) if identity else None
        # Workspace datablocks can be recreated with a new custom UUID on a
        # Blender restart or file load.  This configuration is global, so an
        # exact, still-live workspace name is the bounded recovery identity
        # when the saved UUID no longer exists.  UUID matches still take
        # precedence and continue to preserve settings across a rename.
        if workspace is None:
            workspace = live_by_name.get(name)
            if workspace is not None:
                identity = _workspace_uuid(workspace, create=True)
                _set_profile_workspace_uuid(profile, identity)
        if workspace is None:
            semantic = _workspace_semantic_key(name)
            for candidate in live_by_semantic.get(semantic, ()):
                candidate_identity = _workspace_uuid(candidate, create=True)
                if candidate_identity and candidate_identity not in matched:
                    workspace = candidate
                    identity = candidate_identity
                    _set_profile_workspace_uuid(profile, identity)
                    break
        if workspace is None or not identity or identity in matched:
            try:
                payload = _nptl_workspace_profile_to_dict(profile)
                template_key = _workspace_semantic_key(name) or identity or name
                if template_key:
                    payload['is_template'] = True
                    _NPTL_WORKSPACE_TEMPLATES[template_key] = payload
            except Exception:
                pass
            remove_indices.append(index)
            continue
        matched.add(identity)
        current_name = str(getattr(workspace, 'name', '') or '')
        if name != current_name:
            profile.workspace_name = current_name
    for index in reversed(remove_indices):
        try:
            st.workspace_profiles.remove(index)
        except Exception:
            pass
    for identity, workspace in live_by_uuid.items():
        if identity in matched:
            continue
        _get_or_create_profile(st, str(getattr(workspace, 'name', '') or ''), identity)
    _NPTL_WORKSPACE_TEMPLATES = dict(list(_NPTL_WORKSPACE_TEMPLATES.items())[-64:])


def _normalize_manager_matrix(value: Any) -> Dict[str, Any]:
    source = value if isinstance(value, dict) else {}
    result: Dict[str, Any] = {}
    for workspace_key in _MANAGER_WORKSPACE_KEYS:
        ws_source = source.get(workspace_key) if isinstance(source.get(workspace_key), dict) else {}
        ws_result: Dict[str, Any] = {}
        for editor_key in _MANAGER_EDITOR_KEYS:
            editor_source = ws_source.get(editor_key) if isinstance(ws_source.get(editor_key), dict) else {}
            ws_result[editor_key] = {
                tool_key: (editor_source.get(tool_key) if isinstance(editor_source.get(tool_key), bool) else False)
                for tool_key in _MANAGER_TOOL_KEYS
            }
        result[workspace_key] = ws_result
    return result


def _manager_runtime_record() -> Dict[str, Any] | None:
    try:
        record = bpy.app.driver_namespace.get(_MANAGER_RUNTIME_NAMESPACE_KEY)
    except Exception:
        return None
    if not isinstance(record, dict):
        return None
    if record.get('package_id') != 'smart_tools_manager' or record.get('status') != 'ACTIVE':
        return None
    if not isinstance(record.get('generation'), str) or not record.get('generation'):
        return None
    if record.get('runtime_identity') is None:
        return None
    revision = record.get('revision')
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 0:
        return None
    public_api = record.get('public_api')
    if not isinstance(public_api, dict):
        return None
    return record


def _manager_rule_matrix_snapshot() -> Dict[str, Any]:
    global _PERSISTED_MANAGER_RULE_MATRIX
    record = _manager_runtime_record()
    if record is not None:
        fn = record.get('public_api', {}).get('get_rule_matrix_snapshot')
        if callable(fn):
            try:
                snapshot = fn()
                if isinstance(snapshot, dict):
                    _PERSISTED_MANAGER_RULE_MATRIX = _normalize_manager_matrix(snapshot)
            except Exception:
                pass
    _PERSISTED_MANAGER_RULE_MATRIX = _normalize_manager_matrix(_PERSISTED_MANAGER_RULE_MATRIX)
    return copy.deepcopy(_PERSISTED_MANAGER_RULE_MATRIX)


def _prepare_loaded_workspace_payload(data: Dict[str, Any]) -> Dict[str, Any]:
    global _NPTL_WORKSPACE_TEMPLATES, _PERSISTED_MANAGER_RULE_MATRIX, _LOADING_PROFILE_UUID_BY_NAME
    result = copy.deepcopy(data)
    # ``workspace_selector`` is a transient UI cursor that follows Blender's
    # active workspace; it is not the identity of a saved profile.  Project it
    # to the current file before strict readback so a normal restart/file load
    # cannot roll back otherwise valid profile settings merely because the
    # previously active workspace differs.
    active_workspace_name = _get_active_workspace_name(getattr(bpy, 'context', None))
    if active_workspace_name:
        result['workspace_selector'] = _ws_key_from_name(active_workspace_name)
    templates = result.get('workspace_templates')
    _NPTL_WORKSPACE_TEMPLATES = dict(list(templates.items())[-64:]) if isinstance(templates, dict) else {}
    _PERSISTED_MANAGER_RULE_MATRIX = _normalize_manager_matrix(result.get('manager_rule_matrix'))
    result['manager_rule_matrix'] = copy.deepcopy(_PERSISTED_MANAGER_RULE_MATRIX)
    live_by_uuid: Dict[str, Any] = {}
    live_by_name: Dict[str, Any] = {}
    live_by_semantic: Dict[str, list[Any]] = {}
    live_order: list[str] = []
    try:
        for workspace in bpy.data.workspaces:
            identity = _workspace_uuid(workspace, create=True)
            name = str(getattr(workspace, 'name', '') or '')
            live_by_uuid[identity] = workspace
            live_by_name[name] = workspace
            live_order.append(identity)
            semantic = _workspace_semantic_key(name)
            if semantic:
                live_by_semantic.setdefault(semantic, []).append(workspace)
    except Exception:
        pass
    raw_profiles = result.get('workspace_profiles')
    if isinstance(raw_profiles, dict):
        raw_profiles = [dict(value, workspace_name=value.get('workspace_name', key)) for key, value in raw_profiles.items() if isinstance(value, dict)]
    if not isinstance(raw_profiles, list):
        raw_profiles = list(result.get('workspaces', {}).values()) if isinstance(result.get('workspaces'), dict) else []
    profile_sources = [
        (str(key), value)
        for key, value in _NPTL_WORKSPACE_TEMPLATES.items()
        if isinstance(value, dict)
    ]
    profile_sources.extend((None, value) for value in raw_profiles if isinstance(value, dict))
    selected: Dict[str, tuple[int, int, Dict[str, Any]]] = {}
    consumed_templates: Set[str] = set()
    name_map: Dict[str, str] = {}
    for order, (template_key, raw) in enumerate(profile_sources):
        profile = copy.deepcopy(raw)
        identity = str(profile.get('workspace_uuid') or '')
        name = str(profile.get('workspace_name', profile.get('display_name', '')) or '')
        legacy_identity = profile.get('workspace_uuid_legacy_migration') is True
        workspace = live_by_uuid.get(identity) if identity and not legacy_identity else None
        # The persistent manager state is global while Workspace datablocks are
        # file-owned.  A restart or .blend switch can therefore recreate every
        # workspace UUID.  Rebind only an exact unmatched name when the UUID is
        # absent; this keeps saved settings without weakening a live UUID match.
        if workspace is None:
            workspace = live_by_name.get(name)
        if workspace is None:
            semantic = _workspace_semantic_key(name)
            candidates = live_by_semantic.get(semantic, ())
            if len(candidates) == 1:
                workspace = candidates[0]
        if workspace is None:
            preserved_key = template_key or _workspace_semantic_key(name) or identity or str(uuid.uuid4())
            profile['is_template'] = True
            _NPTL_WORKSPACE_TEMPLATES[preserved_key] = profile
            continue
        identity = _workspace_uuid(workspace, create=True)
        current_name = str(getattr(workspace, 'name', '') or '')
        profile['workspace_uuid'] = identity
        profile.pop('workspace_uuid_legacy_migration', None)
        profile.pop('is_template', None)
        profile['workspace_name'] = current_name
        profile['display_name'] = current_name
        score = _workspace_profile_payload_score(profile)
        previous = selected.get(identity)
        if previous is None or score > previous[0] or (score == previous[0] and order > previous[1]):
            selected[identity] = (score, order, profile)
        if template_key:
            consumed_templates.add(template_key)
    for template_key in consumed_templates:
        _NPTL_WORKSPACE_TEMPLATES.pop(template_key, None)
    profiles = []
    for identity in live_order:
        entry = selected.get(identity)
        if entry is None:
            continue
        profile = entry[2]
        profiles.append(profile)
        name_map[str(profile.get('workspace_name') or '')] = identity
    _NPTL_WORKSPACE_TEMPLATES = dict(list(_NPTL_WORKSPACE_TEMPLATES.items())[-64:])
    result['workspace_profiles'] = profiles
    result['workspaces'] = {str(item.get('workspace_name', '')): copy.deepcopy(item) for item in profiles}
    result['workspace_templates'] = copy.deepcopy(_NPTL_WORKSPACE_TEMPLATES)
    _LOADING_PROFILE_UUID_BY_NAME = name_map
    return result


def _nptl_workspace_profile_to_dict(prof: Any) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "workspace_uuid": _profile_workspace_uuid(prof),
        "workspace_name": _nptl_safe_str(prof, "workspace_name", ""),
        "display_name": _nptl_safe_str(prof, "workspace_name", ""),
        "active_category_index": _nptl_safe_int(prof, "active_category_index", 0),
        "active_detected_index": _nptl_safe_int(prof, "active_detected_index", 0),
        "active_detected_panel_index": _nptl_safe_int(prof, "active_detected_panel_index", 0),
        "active_favorites_index": _nptl_safe_int(prof, "active_favorites_index", 0),
        "active_recent_index": _nptl_safe_int(prof, "active_recent_index", 0),
        "active_fav_panel_index": _nptl_safe_int(prof, "active_fav_panel_index", 0),
        "pool_mode": _nptl_safe_str(prof, "pool_mode", "TABS"),
        "popup_width": _nptl_safe_int(prof, "popup_width", 200),
        "popup_columns": _nptl_safe_int(prof, "popup_columns", 5),
        "popup_use_tab_layout": _nptl_safe_bool(prof, "popup_use_tab_layout", False),
        "popup_show_recent": _nptl_safe_bool(prof, "popup_show_recent", True),
        "popup_active_tab_index": _nptl_safe_int(prof, "popup_active_tab_index", 0),
        "floating_height": _nptl_safe_int(prof, "floating_height", 500),
        "apply_mode": _nptl_safe_str(prof, "apply_mode", "FULL"),
        "search_query": _nptl_safe_str(prof, "search_query", ""),
        "view3d_defaults": {
            "w": _nptl_safe_int(prof, "view3d_default_w", 500),
            "h": _nptl_safe_int(prof, "view3d_default_h", 800),
            "open_mode": _nptl_safe_str(prof, "view3d_open_mode", "MOUSE"),
            "always_on_top": _nptl_safe_bool(prof, "view3d_always_on_top", False),
            "monitor_interval": _nptl_safe_float(prof, "view3d_monitor_interval", 0.5),
            "monitor_size": _nptl_safe_bool(prof, "view3d_monitor_size", True),
            "monitor_settings": _nptl_safe_bool(prof, "view3d_monitor_settings", True),
            "remember_position": _nptl_safe_bool(prof, "view3d_remember_position", True),
        },
        "categories": [],
        "floating_panels": [],
        "favorites_tabs": [],
        "recent_tabs": [],
        "favorite_panels": [],
        "detected": [],
        "detected_panels": [],
    }
    try:
        data["categories"] = [_nptl_category_to_dict(cat) for cat in (getattr(prof, "categories", []) or [])]
    except Exception:
        pass
    try:
        data["floating_panels"] = [_nptl_floating_panel_to_dict(item) for item in (getattr(prof, "floating_panels", []) or [])]
    except Exception:
        pass
    try:
        data["favorites_tabs"] = [_nptl_tab_ref_to_dict(item) for item in (getattr(prof, "favorites_tabs", []) or [])]
    except Exception:
        pass
    try:
        data["recent_tabs"] = [_nptl_recent_tab_to_dict(item) for item in (getattr(prof, "recent_tabs", []) or [])]
    except Exception:
        pass
    try:
        data["favorite_panels"] = [_nptl_favorite_panel_to_dict(item) for item in (getattr(prof, "favorite_panels", []) or [])]
    except Exception:
        pass
    try:
        data["detected"] = [_nptl_detected_tab_to_dict(item) for item in (getattr(prof, "detected_tabs", []) or [])]
        # Preserve the original compact collection name and expose the exact
        # RNA collection name as a separate JSON list (not a shared alias).
        data["detected_tabs"] = [dict(item) for item in data["detected"]]
    except Exception:
        pass
    try:
        data["detected_panels"] = [_nptl_detected_panel_to_dict(item) for item in (getattr(prof, "detected_panels", []) or [])]
    except Exception:
        pass
    return data


def _nptl_current_payload(context) -> Dict[str, Any]:
    wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
    st = getattr(wm, 'nptl_settings', None) if wm is not None else None
    if st is None:
        return {}
    _reconcile_workspace_profiles(st)
    workspace_dict: Dict[str, Any] = {}
    workspace_profiles = []
    for prof in getattr(st, "workspace_profiles", []) or []:
        pdata = _nptl_workspace_profile_to_dict(prof)
        ws_name = str(pdata.get("workspace_name") or "")
        workspace_dict[ws_name] = pdata
        workspace_profiles.append(pdata)
    manager_matrix = _manager_rule_matrix_snapshot()
    return {
        "schema": _strict_json.CURRENT_SCHEMA,
        "schema_version": _strict_json.CURRENT_SCHEMA_VERSION,
        "addon": "smart_workspace_suite",
        "role": _strict_json.CURRENT_ROLE,
        # saved_at is diagnostic only; strict_json_contract assigns it during
        # commit and excludes it from authority/checksum decisions.
        "workspace_selector": _nptl_safe_str(st, "workspace_selector", ""),
        "workspace_ptr": ({
            "__smarttools_id__": True,
            "id_type": "WorkSpace",
            "name": str(getattr(getattr(st, 'workspace_ptr', None), 'name', '') or ''),
            "workspace_uuid": _workspace_uuid(getattr(st, 'workspace_ptr', None), create=False),
        } if getattr(st, 'workspace_ptr', None) is not None else None),
        "ui_state": _ui_state_to_dict(st),
        "workspaces": workspace_dict,
        "workspace_profiles": workspace_profiles,
        "workspace_templates": copy.deepcopy(_NPTL_WORKSPACE_TEMPLATES),
        "manager_rule_matrix": manager_matrix,
        "manager_matrix_shape": [len(_MANAGER_WORKSPACE_KEYS), len(_MANAGER_EDITOR_KEYS), len(_MANAGER_TOOL_KEYS)],
    }


def _live_state_path(*, create: bool = False):
    return _suite_storage.addon_storage_path(
        "live_state.json",
        "n_panel_manager",
        create=create,
    )


def _authority_identity(payload: Optional[Dict[str, Any]] = None) -> tuple[int, str]:
    source = payload if isinstance(payload, dict) else _LAST_LOADED_N_PANEL_AUTHORITY
    try:
        revision = source.get("revision", 0)
        revision = int(revision) if isinstance(revision, int) and not isinstance(revision, bool) else 0
    except Exception:
        revision = 0
    try:
        writer_id = str(source.get("writer_id", "") or "")
    except Exception:
        writer_id = ""
    return revision, writer_id


_AUTHORITY_DIGEST_METADATA_KEYS = (
    "revision",
    "writer_id",
    "payload_checksum",
    "saved_at",
    "authority",
    "contract",
    "contract_version",
)
_AUTHORITY_DIGEST_CACHE: Dict[str, Any] = {"key": None, "digest": ""}
# Content digest of the *disk* authority a restored startup snapshot was built
# on.  After a snapshot apply ``_LAST_LOADED_N_PANEL_AUTHORITY`` holds the
# journal-merged graph; the journal base must keep naming the on-disk content
# until a verified commit replaces it, or a failed flush followed by one more
# edit would re-bind the journal to content that exists nowhere on disk.
_LAST_LOADED_BASE_DIGEST = ""


def _authority_content_digest(payload: Optional[Dict[str, Any]] = None) -> str:
    """Return a metadata-independent digest of one validated N-panel graph.

    Every sidecar mirror re-commits ``current_settings.json`` through the
    strict contract with a new revision and this process's writer id even
    when the N-panel graph itself is unchanged.  The live journal must stay
    bound to the *content* it was recorded against, not to that churn, so the
    base identity carries this digest next to revision/writer.
    """
    if not isinstance(payload, dict) and _LAST_LOADED_BASE_DIGEST:
        return str(_LAST_LOADED_BASE_DIGEST)
    source = payload if isinstance(payload, dict) else _LAST_LOADED_N_PANEL_AUTHORITY
    if not isinstance(source, dict) or not source:
        return ""
    revision, writer_id = _authority_identity(source)
    key = (id(source), revision, writer_id, len(source))
    if _AUTHORITY_DIGEST_CACHE.get("key") == key:
        return str(_AUTHORITY_DIGEST_CACHE.get("digest") or "")
    try:
        detached = {
            name: value
            for name, value in source.items()
            if name not in _AUTHORITY_DIGEST_METADATA_KEYS
        }
        digest = hashlib.sha256(
            _strict_json.canonical_json_bytes(detached, pretty=False)
        ).hexdigest()
    except Exception:
        return ""
    _AUTHORITY_DIGEST_CACHE["key"] = key
    _AUTHORITY_DIGEST_CACHE["digest"] = digest
    return digest


def _live_state_base_matches(
    doc: Dict[str, Any],
    revision: int,
    writer_id: str,
    digest: str,
) -> bool:
    """Return whether a journal was recorded against this exact content base."""
    try:
        live_revision = int(doc.get("base_revision", 0) or 0)
    except Exception:
        return False
    live_writer = str(doc.get("base_writer_id", "") or "")
    live_digest = str(doc.get("base_content_digest", "") or "")
    if live_digest and digest and live_digest == digest:
        return True
    return bool(
        live_revision == revision
        and not (writer_id and live_writer and live_writer != writer_id)
    )


def _digestless_journal_base_matches(doc: Dict[str, Any], data: Dict[str, Any]) -> bool:
    """Bridge a journal written without ``base_content_digest`` (<= 1.1.173).

    Such a journal names its base only by revision/writer.  When the primary
    has since been re-stamped once by a sidecar mirror, the previous primary
    survives as ``current_settings.json.bak`` with exactly that identity; if
    its N-panel content equals the current primary's, the re-stamp was
    content-neutral and the journal still overlays the current authority.
    Anything else (no backup, older backup, different content) stays orphaned.
    """
    if not isinstance(doc, dict) or not isinstance(data, dict):
        return False
    if str(doc.get("base_content_digest", "") or ""):
        return False
    try:
        live_revision = int(doc.get("base_revision", 0) or 0)
    except Exception:
        return False
    live_writer = str(doc.get("base_writer_id", "") or "")
    if live_revision <= 0:
        return False
    try:
        primary = _refresh_config_file_path()
        backup = _strict_json.read_current_candidate(
            primary + ".bak",
            "backup",
            allow_legacy=False,
        )
    except Exception:
        return False
    if int(backup.revision) != live_revision:
        return False
    if live_writer and backup.writer_id and backup.writer_id != live_writer:
        return False
    # Backup first: the single-slot digest cache must end holding ``data``.
    backup_digest = _authority_content_digest(backup.payload)
    current_digest = _authority_content_digest(data)
    return bool(current_digest and backup_digest and current_digest == backup_digest)


def rebase_live_state_journal(revision: int, writer_id: str, digest: str) -> bool:
    """Re-bind an inherited journal to the authority it was just applied on.

    Called once after a startup snapshot has been applied.  The snapshot
    already contains the journal, so the journal's base becomes the snapshot's
    validated base (or the journal-recovery identity when no disk authority
    existed).  Later edits then append to it instead of resetting it; when the
    strict flush lands the journal is retired anyway.  A journal this process
    has already written to is left alone.
    """
    global _LIVE_STATE_CACHE
    try:
        path = _live_state_path(create=False)
        if not path.is_file():
            return False
        doc = _read_live_state_document(refresh=True)
    except Exception:
        return False
    if not isinstance(doc, dict) or doc.get("schema") != _LIVE_STATE_SCHEMA:
        return False
    if str(doc.get("session_id") or "") == _LIVE_STATE_SESSION_ID:
        return False
    doc["base_revision"] = int(revision or 0)
    doc["base_writer_id"] = str(writer_id or "")
    doc["base_content_digest"] = str(digest or "")
    try:
        _suite_storage.atomic_write_json(
            path,
            doc,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
            backup=False,
        )
        _LIVE_STATE_CACHE = doc
        return True
    except Exception:
        return False


def _new_live_state_document(payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    revision, writer_id = _authority_identity(payload)
    return {
        "schema": _LIVE_STATE_SCHEMA,
        "session_id": _LIVE_STATE_SESSION_ID,
        "base_revision": revision,
        "base_writer_id": writer_id,
        "base_content_digest": _authority_content_digest(payload),
        "ui_state": {},
        "workspace_profiles": {},
    }


def _read_live_state_document(*, refresh: bool = False) -> Dict[str, Any]:
    global _LIVE_STATE_CACHE
    if not refresh and isinstance(_LIVE_STATE_CACHE, dict):
        return _LIVE_STATE_CACHE
    try:
        value = _suite_storage.read_json(_live_state_path(create=False), default={})
    except Exception:
        value = {}
    if not isinstance(value, dict) or value.get("schema") != _LIVE_STATE_SCHEMA:
        value = _new_live_state_document()
    if not isinstance(value.get("ui_state"), dict):
        value["ui_state"] = {}
    if not isinstance(value.get("workspace_profiles"), dict):
        value["workspace_profiles"] = {}
    _LIVE_STATE_CACHE = value
    return value


def _live_state_for_current_authority() -> Dict[str, Any]:
    global _LIVE_STATE_CACHE
    revision, writer_id = _authority_identity()
    digest = _authority_content_digest()
    if revision <= 0 and not writer_id and not digest:
        try:
            from .. import persistence as _suite_persistence
            pending_base = _suite_persistence._pending_validated_n_panel_base()
        except Exception:
            pending_base = None
        if pending_base is not None:
            revision, writer_id, digest = pending_base
    doc = _read_live_state_document()
    if not _live_state_base_matches(doc, revision, writer_id, digest):
        doc = _new_live_state_document()
        doc["base_revision"] = revision
        doc["base_writer_id"] = writer_id
        doc["base_content_digest"] = digest
        _LIVE_STATE_CACHE = doc
    elif digest:
        # Same content base after a content-neutral re-stamp: keep the journal
        # and follow the current revision/writer so older readers still match.
        doc["base_revision"] = revision
        doc["base_writer_id"] = writer_id
        doc["base_content_digest"] = digest
    return doc


def _find_profile_by_name(st, workspace_name: str):
    target = str(workspace_name or "")
    if st is None or not target:
        return None
    try:
        for profile in st.workspace_profiles:
            if str(getattr(profile, "workspace_name", "") or "") == target:
                return profile
    except Exception:
        pass
    return None


def _live_state_write_suppressed() -> bool:
    """Return whether a journal write now would record an initialization event.

    Registration materialisation (``_get_or_create_profile`` sets
    ``workspace_name`` on a fresh row), strict replay, serializer normalisation
    and the startup restore request all run the same RNA update callbacks as
    a user edit while no authority has been loaded in this process yet.  Such
    a write must never reach ``_live_state_for_current_authority``: with an
    empty in-memory authority the journal inherited from the previous session
    never matches and is replaced by an empty base-0 document before
    ``_capture_authority_snapshot`` can merge it.  Persistence owns the
    classification: the rule ``persist_immediate_user_change`` applies plus
    the startup-restore request window (status NOT_REQUESTED/REQUESTED).
    """
    try:
        from .. import persistence as _suite_persistence
        return bool(_suite_persistence.live_journal_write_suppressed())
    except Exception:
        return False


def _write_live_state_now(
    context=None,
    *,
    profile_names: Optional[Set[str]] = None,
    include_ui: bool = True,
) -> bool:
    """Persist only the edited N-panel rows without rewriting central settings."""
    global _LIVE_STATE_CACHE
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    st = getattr(wm, "nptl_settings", None) if wm is not None else None
    if st is None:
        return False
    if _live_state_write_suppressed():
        return False
    doc = _live_state_for_current_authority()
    doc["session_id"] = _LIVE_STATE_SESSION_ID
    if include_ui:
        doc["ui_state"] = _ui_state_to_dict(st)
        doc["workspace_selector"] = _nptl_safe_str(st, "workspace_selector", "")
        pointer = getattr(st, "workspace_ptr", None)
        doc["workspace_ptr"] = str(getattr(pointer, "name", "") or "") if pointer is not None else ""
    profiles = doc.setdefault("workspace_profiles", {})
    if not isinstance(profiles, dict):
        profiles = {}
        doc["workspace_profiles"] = profiles
    for name in tuple(profile_names or ()):
        profile = _find_profile_by_name(st, name)
        if profile is None:
            continue
        pdata = _nptl_workspace_profile_to_dict(profile)
        key = str(pdata.get("workspace_uuid") or pdata.get("workspace_name") or name)
        if not key:
            continue
        # One row per workspace.  Every process binds live WorkSpaces to new
        # UUIDs, so a journal that survives a restart (failed strict flush)
        # already holds this workspace under the previous session's UUID or
        # under its bare name; the row written now is the newest state of the
        # same workspace and supersedes it.  Two rows for one display name
        # would fail the strict finalize of the merged graph.
        row_name = str(pdata.get("workspace_name") or "")
        for other_key in tuple(profiles):
            if other_key == key:
                continue
            other = profiles.get(other_key)
            if isinstance(other, dict) and row_name and str(other.get("workspace_name") or "") == row_name:
                profiles.pop(other_key, None)
        profiles[key] = pdata
    try:
        _lpath = _live_state_path(create=True)
        try:
            import hashlib as _hl
            _dig = _hl.sha1(json.dumps(doc, sort_keys=True, ensure_ascii=False, default=str).encode('utf-8')).hexdigest()
        except Exception:
            _dig = ''
        if _dig and _LIVE_STATE_LAST_HASH.get(str(_lpath)) == _dig and os.path.exists(str(_lpath)):
            _LIVE_STATE_CACHE = doc
            return True
        _suite_storage.atomic_write_json(
            _lpath,
            doc,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
            backup=False,
        )
        if _dig:
            _LIVE_STATE_LAST_HASH[str(_lpath)] = _dig
        _LIVE_STATE_CACHE = doc
        return True
    except Exception:
        return False


def _schedule_canonical_save_after_journal(context, written: bool) -> bool:
    """Coalesce one verified journal write into one finite canonical save."""
    if written is not True:
        return False
    try:
        from .. import persistence as _suite_persistence
        _suite_persistence.persist_immediate_user_change(
            context,
            source='n-panel-journal-flush',
        )
    except Exception:
        # The durable journal remains available to the file/exit boundary.
        pass
    return True


def has_current_session_live_state_changes() -> bool:
    """Return whether this process durably journaled a real N-panel edit."""
    try:
        path = _live_state_path(create=False)
        if not path.is_file():
            return False
        doc = _read_live_state_document(refresh=True)
        if doc.get("schema") != _LIVE_STATE_SCHEMA:
            return False
        if str(doc.get("session_id") or "") != _LIVE_STATE_SESSION_ID:
            return False
        base_revision, base_writer = _authority_identity()
        if not _live_state_base_matches(
            doc,
            base_revision,
            base_writer,
            _authority_content_digest(),
        ):
            return False
        return bool(
            doc.get("current_overlay")
            or doc.get("workspace_profiles")
            or doc.get("ui_state")
        )
    except Exception:
        return False


def write_imported_live_state(context, payload: Dict[str, Any]) -> bool:
    """Persist an imported N-panel graph without synchronously rebuilding central JSON."""
    global _LIVE_STATE_CACHE
    if not isinstance(payload, dict):
        return False
    allowed = (
        "workspace_selector",
        "workspace_ptr",
        "ui_state",
        "workspaces",
        "workspace_profiles",
        "workspace_templates",
        "manager_rule_matrix",
        "manager_matrix_shape",
    )
    doc = _new_live_state_document()
    doc["current_overlay"] = {
        key: copy.deepcopy(payload[key])
        for key in allowed
        if key in payload
    }
    try:
        _suite_storage.atomic_write_json(
            _live_state_path(create=True),
            doc,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            mirror=False,
            backup=False,
        )
        _LIVE_STATE_CACHE = doc
        from .. import persistence as _suite_persistence
        _suite_persistence.mark_deferred_settings_dirty()
        return True
    except Exception:
        return False


def flush_pending_live_state(context=None) -> bool:
    """Synchronously drain the finite edit journal before a file/exit boundary."""
    global _LIVE_STATE_DEADLINE, _LIVE_STATE_PENDING_UI
    names = set(_LIVE_STATE_PENDING_PROFILES)
    include_ui = bool(_LIVE_STATE_PENDING_UI)
    if not names and not include_ui:
        return True
    _suite_storage.unregister_timer_slot(
        _LIVE_STATE_TIMER_SLOT,
        globals().get("_flush_live_state_once"),
    )
    _LIVE_STATE_PENDING_PROFILES.clear()
    _LIVE_STATE_PENDING_UI = False
    _LIVE_STATE_DEADLINE = 0.0
    return bool(_write_live_state_now(
        context or getattr(bpy, "context", None),
        profile_names=names,
        include_ui=include_ui,
    ))


def flush_live_state_pending() -> bool:
    """保留中のジャーナル書き込みを今すぐ 1 回で書く（保存前・終了前・読み込み前）。"""
    global _LIVE_STATE_DEADLINE, _LIVE_STATE_PENDING_UI
    if not (_LIVE_STATE_PENDING_PROFILES or _LIVE_STATE_PENDING_UI):
        return True
    names = set(_LIVE_STATE_PENDING_PROFILES)
    include_ui = bool(_LIVE_STATE_PENDING_UI)
    _LIVE_STATE_PENDING_PROFILES.clear()
    _LIVE_STATE_PENDING_UI = False
    _LIVE_STATE_DEADLINE = 0.0
    try:
        _suite_storage.unregister_timer_slot(_LIVE_STATE_TIMER_SLOT, globals().get("_flush_live_state_once"))
    except Exception:
        pass
    return bool(_write_live_state_now(
        getattr(bpy, "context", None),
        profile_names=names,
        include_ui=include_ui,
    ))


def _cancel_live_state_write() -> bool:
    global _LIVE_STATE_DEADLINE, _LIVE_STATE_PENDING_UI
    ok = _suite_storage.unregister_timer_slot(
        _LIVE_STATE_TIMER_SLOT,
        globals().get("_flush_live_state_once"),
    )
    _LIVE_STATE_DEADLINE = 0.0
    _LIVE_STATE_PENDING_UI = False
    _LIVE_STATE_PENDING_PROFILES.clear()
    return bool(ok)


def _flush_live_state_once():
    global _LIVE_STATE_DEADLINE, _LIVE_STATE_PENDING_UI
    wm = getattr(getattr(bpy, "context", None), "window_manager", None)
    if bool(getattr(wm, "is_interface_locked", False)):
        return 0.1
    remaining = _LIVE_STATE_DEADLINE - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    names = set(_LIVE_STATE_PENDING_PROFILES)
    include_ui = bool(_LIVE_STATE_PENDING_UI)
    _LIVE_STATE_PENDING_PROFILES.clear()
    _LIVE_STATE_PENDING_UI = False
    _LIVE_STATE_DEADLINE = 0.0
    written = _write_live_state_now(
        getattr(bpy, "context", None),
        profile_names=names,
        include_ui=include_ui,
    )
    _schedule_canonical_save_after_journal(
        getattr(bpy, "context", None),
        written,
    )
    return None


def _schedule_live_state_write(
    context=None,
    *,
    include_profile: bool = True,
    profile_names: Optional[Set[str]] = None,
    include_ui: bool = True,
    allow_disabled: bool = False,
) -> bool:
    global _LIVE_STATE_DEADLINE, _LIVE_STATE_PENDING_UI
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    st = getattr(wm, "nptl_settings", None) if wm is not None else None
    if st is None:
        return False
    enabled = getattr(st, "n_panel_state_save_enabled", True)
    if not allow_disabled and enabled is not True:
        return False
    if _live_state_write_suppressed():
        # An initialization event (registration, replay, serializer, startup
        # restore window): not a user edit.  It neither touches the inherited
        # journal nor marks the session dirty, exactly like
        # persistence.persist_immediate_user_change treats the same callback.
        return False
    for name in tuple(profile_names or ()):
        normalized = str(name or "")
        if normalized:
            _LIVE_STATE_PENDING_PROFILES.add(normalized)
    if include_profile:
        profile = _active_profile(ctx)
        name = str(getattr(profile, "workspace_name", "") or "") if profile is not None else ""
        if name:
            _LIVE_STATE_PENDING_PROFILES.add(name)
    _LIVE_STATE_PENDING_UI = bool(_LIVE_STATE_PENDING_UI or include_ui)
    _LIVE_STATE_DEADLINE = 0.0
    try:
        from .. import persistence as _suite_persistence
        _suite_persistence.mark_deferred_settings_dirty()
    except Exception:
        pass

    # 操作の中では書かず印だけ付け、0.5 秒の 1 回きりのタイマーで 1 回にまとめて書く。
    # 保存・終了・ファイルを開く前には flush_live_state_pending() が残りを必ず書く。
    try:
        _LIVE_STATE_DEADLINE = time.monotonic() + _LIVE_STATE_DELAY
        if bpy.app.timers.is_registered(_flush_live_state_once):
            return True
        if _suite_storage.register_timer_slot(
            _LIVE_STATE_TIMER_SLOT,
            _flush_live_state_once,
            first_interval=_LIVE_STATE_DELAY,
            persistent=False,
        ):
            return True
    except Exception:
        pass
    _LIVE_STATE_DEADLINE = 0.0
    # タイマーが使えない文脈では従来どおり同期で書く。
    try:
        _suite_storage.unregister_timer_slot(
            _LIVE_STATE_TIMER_SLOT,
            globals().get("_flush_live_state_once"),
        )
    except Exception:
        pass
    names = set(_LIVE_STATE_PENDING_PROFILES)
    include_ui_now = bool(_LIVE_STATE_PENDING_UI)
    _LIVE_STATE_PENDING_PROFILES.clear()
    _LIVE_STATE_PENDING_UI = False
    written = _write_live_state_now(
        ctx,
        profile_names=names,
        include_ui=include_ui_now,
    )
    _schedule_canonical_save_after_journal(ctx, written)
    return bool(written)


def _stale_live_state_is_recoverable(
    data: Dict[str, Any],
    doc: Dict[str, Any],
    *,
    canonical_revision: int,
    live_revision: int,
) -> bool:
    """Recover only a nearby richer journal over an empty canonical graph."""
    if not (0 < live_revision < canonical_revision):
        return False
    if canonical_revision - live_revision > 128:
        return False
    if not str(doc.get("session_id") or ""):
        return False
    if _payload_configuration_activity(data) != 0:
        return False
    overlay = doc.get("current_overlay")
    if isinstance(overlay, dict):
        live_activity = _payload_configuration_activity(overlay)
    else:
        live_activity = _payload_configuration_activity({
            "workspace_profiles": doc.get("workspace_profiles", {}),
        })
    return live_activity > 0


def _fold_live_state_replacements(
    replacements: Dict[str, Dict[str, Any]],
    data: Dict[str, Any],
) -> Dict[str, Dict[str, Any]]:
    """Keep one journal row per workspace display name.

    A journal that outlived a restart (failed strict flush) can hold the same
    workspace under the previous session's UUID, under this session's UUID and
    under its bare name (rows written before the profile was bound).  The
    strict finalize rejects two rows with one display name, so the rows are
    folded: a UUID-keyed row wins over a name-keyed row; between UUID-keyed
    rows the one whose UUID is *not* bound in the base wins, because the base
    still carries the UUIDs of the session that committed it and the unbound
    row is the later session's edit.  A tie (no candidate bound, or all of
    them) keeps the lexically last key: the journal is serialized with
    ``sort_keys=True``, so key order carries no recency and the choice is
    deterministic but not provably the newest.  1.1.174 journals hold one
    row per workspace, so ties occur only for pre-1.1.174 documents.
    """
    if not isinstance(replacements, dict) or len(replacements) < 2:
        return replacements
    bound: Set[str] = set()
    profiles = data.get("workspace_profiles") if isinstance(data, dict) else None
    if isinstance(profiles, list):
        for item in profiles:
            if isinstance(item, dict):
                bound.add(str(item.get("workspace_uuid") or ""))
    groups: Dict[str, list] = {}
    for key, value in replacements.items():
        name = str(value.get("workspace_name") or "")
        groups.setdefault(name, []).append((str(key), value))
    folded: Dict[str, Dict[str, Any]] = {}
    for name, entries in groups.items():
        if not name or len(entries) == 1:
            for key, value in entries:
                folded[key] = value
            continue
        uuid_keyed = []
        for key, value in entries:
            try:
                uuid.UUID(key)
            except Exception:
                continue
            uuid_keyed.append((key, value))
        candidates = uuid_keyed or entries
        unbound = [(key, value) for key, value in candidates if key not in bound]
        key, value = (unbound or candidates)[-1]
        folded[key] = value
    return folded


def _merge_live_state_overlay(data: Dict[str, Any]) -> Dict[str, Any]:
    """Overlay a crash-safe live journal only on its exact canonical base."""
    global _LIVE_STATE_RECOVERY_REASON
    if not isinstance(data, dict):
        return data
    doc = _read_live_state_document(refresh=True)
    base_revision, base_writer = _authority_identity(data)
    try:
        live_revision = int(doc.get("base_revision", 0) or 0)
    except Exception:
        return data
    exact_base = _live_state_base_matches(
        doc,
        base_revision,
        base_writer,
        _authority_content_digest(data),
    )
    if not exact_base and _digestless_journal_base_matches(doc, data):
        # Pre-digest journal over a once re-stamped, content-identical primary.
        doc["base_content_digest"] = _authority_content_digest(data)
        exact_base = True
    if not exact_base:
        if not _stale_live_state_is_recoverable(
            data,
            doc,
            canonical_revision=base_revision,
            live_revision=live_revision,
        ):
            return data
        _LIVE_STATE_RECOVERY_REASON = (
            f"RECOVERED_RICH_JOURNAL_{live_revision}_OVER_EMPTY_{base_revision}"
        )
    result = copy.deepcopy(data)
    current_overlay = doc.get("current_overlay")
    if isinstance(current_overlay, dict):
        for key in (
            "workspace_selector",
            "workspace_ptr",
            "ui_state",
            "workspaces",
            "workspace_profiles",
            "workspace_templates",
            "manager_rule_matrix",
            "manager_matrix_shape",
        ):
            if key in current_overlay:
                result[key] = copy.deepcopy(current_overlay[key])
    ui_state = result.get("ui_state") if isinstance(result.get("ui_state"), dict) else {}
    live_ui = doc.get("ui_state") if isinstance(doc.get("ui_state"), dict) else {}
    for key in SWS_SECTION_UI_STATE_PROPS:
        value = live_ui.get(key)
        if isinstance(value, bool):
            ui_state[key] = value
    result["ui_state"] = ui_state
    if isinstance(doc.get("workspace_selector"), str):
        result["workspace_selector"] = doc.get("workspace_selector", "")
    if isinstance(doc.get("workspace_ptr"), str):
        result["workspace_ptr"] = doc.get("workspace_ptr", "")

    replacements = _fold_live_state_replacements(
        {
            str(key): copy.deepcopy(value)
            for key, value in (doc.get("workspace_profiles") or {}).items()
            if isinstance(key, str) and isinstance(value, dict)
        },
        data,
    )
    if not replacements:
        return result
    by_name = {
        str(value.get("workspace_name") or ""): value
        for value in replacements.values()
        if str(value.get("workspace_name") or "")
    }
    by_semantic = {
        _workspace_semantic_key(value.get("workspace_name")): value
        for value in replacements.values()
        if _workspace_semantic_key(value.get("workspace_name"))
    }
    workspaces = result.get("workspaces")
    if isinstance(workspaces, dict):
        for name, value in by_name.items():
            workspaces[name] = copy.deepcopy(value)
        for name in tuple(workspaces):
            replacement = by_semantic.get(_workspace_semantic_key(name))
            if replacement is not None:
                workspaces[name] = copy.deepcopy(replacement)
    profiles = result.get("workspace_profiles")
    if isinstance(profiles, list):
        merged = []
        consumed = set()
        for current in profiles:
            if not isinstance(current, dict):
                merged.append(current)
                continue
            uuid_key = str(current.get("workspace_uuid") or "")
            name_key = str(current.get("workspace_name") or "")
            replacement = (
                replacements.get(uuid_key)
                or by_name.get(name_key)
                or by_semantic.get(_workspace_semantic_key(name_key))
            )
            if replacement is None:
                merged.append(current)
                continue
            merged.append(copy.deepcopy(replacement))
            consumed.add(id(replacement))
        merged_names = {
            str(item.get("workspace_name") or "")
            for item in merged
            if isinstance(item, dict)
        }
        for replacement in replacements.values():
            if id(replacement) in consumed:
                continue
            # A row whose display name is already present would fail the
            # strict finalize ("workspace profile display name duplicated");
            # the present row is the one bound to this base.
            name = str(replacement.get("workspace_name") or "")
            if name and name in merged_names:
                continue
            merged.append(copy.deepcopy(replacement))
            if name:
                merged_names.add(name)
        result["workspace_profiles"] = merged
    elif isinstance(profiles, dict):
        for name, value in by_name.items():
            profiles[name] = copy.deepcopy(value)
    return result


def _live_state_recovery_document() -> Optional[Dict[str, Any]]:
    """Return the on-disk journal only when it is a structurally valid record.

    The journal is written solely by RNA update callbacks and explicit import
    (never by registration or strict replay, which run under update-suspend or
    the registration write guard), so a well-formed journal is a record of
    committed user edits.  Structural validation here; the merged graph is
    still finalized through the strict contract by the caller.
    """
    try:
        path = _live_state_path(create=False)
        if not path.is_file():
            return None
        doc = _read_live_state_document(refresh=True)
    except Exception:
        return None
    if not isinstance(doc, dict) or doc.get("schema") != _LIVE_STATE_SCHEMA:
        return None
    if not str(doc.get("session_id") or ""):
        return None
    try:
        base_revision = int(doc.get("base_revision", 0) or 0)
    except Exception:
        return None
    if base_revision < 0 or not isinstance(doc.get("base_writer_id", ""), str):
        return None
    ui_state = doc.get("ui_state")
    if not isinstance(ui_state, dict):
        return None
    for key in SWS_SECTION_UI_STATE_PROPS:
        if key in ui_state and not isinstance(ui_state.get(key), bool):
            return None
    profiles = doc.get("workspace_profiles")
    if not isinstance(profiles, dict):
        return None
    for key, value in profiles.items():
        if not isinstance(key, str) or not isinstance(value, dict):
            return None
        if not str(value.get("workspace_name") or ""):
            return None
    overlay = doc.get("current_overlay")
    if overlay is not None and not isinstance(overlay, dict):
        return None
    has_ui = any(key in ui_state for key in SWS_SECTION_UI_STATE_PROPS)
    if not (has_ui or profiles or isinstance(overlay, dict)):
        return None
    return copy.deepcopy(doc)


def recover_live_state_without_authority(context) -> Optional[Dict[str, Any]]:
    """Rebuild the user graph from the crash-safe journal when no authority exists.

    Used only when primary, backup and central all resolve to no candidate for
    this storage root (a fresh profile whose canonical commit never landed, or
    whose primary was lost).  The journal is then the only record of the user's
    edits.  The live graph is captured under update-suspend so building it can
    never rewrite the journal being recovered, and the journal is overlaid on
    its own declared base identity because that base no longer exists on disk.
    """
    global _LIVE_STATE_RECOVERY_REASON
    doc = _live_state_recovery_document()
    if doc is None:
        return None
    ctx = context or getattr(bpy, "context", None)
    _push_update_suspend()
    try:
        base = _nptl_current_payload(ctx)
    finally:
        _pop_update_suspend()
    if not isinstance(base, dict) or not base:
        return None
    base["revision"] = int(doc.get("base_revision", 0) or 0)
    base["writer_id"] = str(doc.get("base_writer_id", "") or "")
    merged = _merge_live_state_overlay(base)
    if not isinstance(merged, dict):
        return None
    merged.pop("revision", None)
    merged.pop("writer_id", None)
    _LIVE_STATE_RECOVERY_REASON = (
        f"RECOVERED_JOURNAL_WITHOUT_AUTHORITY_{int(doc.get('base_revision', 0) or 0)}"
    )
    return merged


def clear_live_state_journal() -> bool:
    """Retire a live journal after the complete canonical transaction succeeds."""
    global _LIVE_STATE_CACHE, _LIVE_STATE_RECOVERY_REASON
    _cancel_live_state_write()
    _LIVE_STATE_CACHE = None
    _LIVE_STATE_RECOVERY_REASON = ""
    try:
        path = _live_state_path(create=False)
        if path.exists():
            path.unlink()
        return not path.exists()
    except Exception:
        return False


def note_canonical_commit(payload: Dict[str, Any]) -> None:
    """Advance the live-journal base after a verified full transaction."""
    global _LAST_LOADED_N_PANEL_AUTHORITY, _LIVE_STATE_CACHE, _LIVE_STATE_RECOVERY_REASON
    global _LAST_LOADED_BASE_DIGEST
    if isinstance(payload, dict):
        _LAST_LOADED_N_PANEL_AUTHORITY = copy.deepcopy(payload)
        _LAST_LOADED_BASE_DIGEST = ""
    _LIVE_STATE_CACHE = None
    _LIVE_STATE_RECOVERY_REASON = ""


def _write_json_atomic(path: str, data: Dict[str, Any], suffix: str = ".tmp") -> bool:
    """Compatibility wrapper for non-transaction callers."""
    del suffix
    return bool(_suite_storage.atomic_write_json(
        path,
        data,
        indent=4,
        ensure_ascii=False,
        sort_keys=False,
        mirror=False,
        backup=True,
    ))


def save_n_panel_manager_current_settings(
    context,
    *,
    force: bool = False,
    verified_user_change: bool = False,
) -> bool:
    """Commit current_settings and central mirror as one strict revision.

    False is never displayed as success.  The persistence layer retains dirty
    state and retries at the next safe explicit boundary after any I/O failure.
    """
    wm = (
        getattr(context, 'window_manager', None)
        if context is not None
        else getattr(bpy.context, 'window_manager', None)
    )
    owner = getattr(wm, 'nptl_settings', None) if wm is not None else None
    enabled = True
    if owner is not None:
        raw = getattr(owner, 'n_panel_state_save_enabled', True)
        enabled = raw if isinstance(raw, bool) else True
    if not force and not enabled:
        try:
            from .. import persistence as _suite_persistence
            _suite_persistence.mark_deferred_settings_dirty()
        except Exception:
            pass
        return False
    _refresh_config_file_path()
    data = _nptl_current_payload(context)
    if not data:
        return False
    try:
        from .. import persistence as _suite_persistence
        transaction = getattr(_suite_persistence, 'save_n_panel_manager_transaction', None)
        if callable(transaction):
            return bool(transaction(
                context,
                CONFIG_FILE_PATH,
                data,
                force=force,
                verified_user_change=verified_user_change,
            ))
    except Exception:
        return False
    try:
        return bool(_suite_storage.commit_n_panel_current_settings(
            CONFIG_FILE_PATH,
            data,
            state_save_enabled=enabled,
        ))
    except Exception:
        return False


def _addon_root_module_name() -> str:
    try:
        text = str(__package__ or __name__ or '').strip()
    except Exception:
        text = ''
    if text:
        parts = [part for part in text.split('.') if part]
        lower_parts = [part.lower() for part in parts]
        if 'smart_workspace_suite' in lower_parts:
            idx = lower_parts.index('smart_workspace_suite')
            return '.'.join(parts[:idx + 1])
        lower_text = text.lower()
        if lower_text == 'smart_workspace_suite' or lower_text.startswith('smart_workspace_suite.'):
            return 'smart_workspace_suite'
    return 'smart_workspace_suite'


def _addon_package_name() -> str:
    root_name = _addon_root_module_name()
    parts = [part for part in str(root_name or '').split('.') if part]
    if 'smart_workspace_suite' in parts:
        return 'smart_workspace_suite'
    return 'smart_workspace_suite'


def _extension_user_root() -> str:
    package = _addon_package_name()
    return str(_suite_storage.user_default_root(package, create=True))


def _root_addon_module_name() -> str:
    return _addon_root_module_name()


def _addon_preferences(context=None):
    """Return the already loaded WindowManager runtime settings owner.

    The integrated suite intentionally does not read or write AddonPreferences
    properties; every editable option is exposed from the N-panel and persisted
    through CONFIG JSON storage.  This lookup never imports a module, so callers
    from Panel.draw cannot trigger source-file access.
    """
    try:
        root_package = str(__package__ or '').rsplit('.', 1)[0]
        _suite_preferences = sys.modules.get(f'{root_package}.preferences')
        get_settings = getattr(_suite_preferences, 'get_runtime_settings', None) if _suite_preferences is not None else None
        if callable(get_settings):
            return get_settings(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _n_panel_manager_settings_dir() -> str:
    """Return the central persistent directory for N-panel Manager settings.

    The user-facing storage contract is:
    Blender config/Smart_WorkSpace_Suite/n-panel_manager/current_settings.json
    """
    try:
        root = _suite_storage.central_settings_dir(create=True)
        path = os.path.join(str(root), 'n-panel_manager')
    except Exception:
        path = os.path.join(_extension_user_root(), 'n-panel_manager')
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def _config_file_path() -> str:
    return os.path.join(_n_panel_manager_settings_dir(), 'current_settings.json')


def _legacy_config_file_paths() -> tuple:
    paths = []
    try:
        paths.append(os.path.join(_extension_user_root(), 'smart_workspace_suite_config.json'))
    except Exception:
        pass
    try:
        paths.append(os.path.join(str(_suite_storage.central_settings_dir(create=True)), 'smart_workspace_suite_config.json'))
    except Exception:
        pass
    return tuple(dict.fromkeys([p for p in paths if p]))


def _migrate_legacy_n_panel_manager_config(target_path: str) -> bool:
    """Migrate recognized old main/backup/central data after strict failure only.

    This function is called from an explicit settings load, never from module
    import or RNA registration.  A malformed strict file (including checksum
    failure) remains excluded even when legacy migration is enabled.
    """
    target = str(target_path or '')
    if not target:
        return False
    try:
        result = _strict_json.migrate_legacy_current_authority(
            target,
            target + '.bak',
            _suite_storage.central_settings_path(create=False),
            _suite_storage.n_panel_current_settings_key(target),
            legacy_paths=_legacy_config_file_paths(),
        )
        return bool(getattr(result, 'valid', False) and getattr(result, 'repaired_primary', False))
    except Exception:
        return False


def _refresh_config_file_path() -> str:
    global CONFIG_FILE_PATH
    CONFIG_FILE_PATH = _config_file_path()
    # No registration/import-time write.  Legacy authority is considered only
    # after the ordinary strict main/backup/central resolver reports no valid
    # candidate during an explicit load lifecycle.
    return CONFIG_FILE_PATH


def _io_dir() -> str:
    d = os.path.join(_extension_user_root(), 'io')
    os.makedirs(d, exist_ok=True)
    return d


def default_export_filepath() -> str:
    return os.path.join(_io_dir(), 'smart_workspace_suite_settings.json')


def default_import_filepath() -> str:
    return default_export_filepath()


CONFIG_FILE_PATH = _refresh_config_file_path()
SCHEMA_VERSION = _strict_json.CURRENT_SCHEMA_VERSION
EMPTY_TAB_CAT = " " 
ANCHOR_PREFIX = "NPTL_PT_ANCHOR_" 
DEFAULT_CAT_NAME = "Item"
SMART_WORKSPACE_TAB_NAME = "Smart Workspace"
HIDDEN_TAB_LABEL_TOKENS = frozenset({"hidden", "[hidden]", "(hidden)", "__hidden__", "<hidden>"})


def _normalize_half_width_spaces(value: Any) -> str:
    """Normalize display-name spacing without changing the selected language."""
    try:
        return str(value or "").replace("\u3000", " ").strip()
    except Exception:
        return ""


def _is_hidden_tab_label(value: str) -> bool:
    text = _normalize_half_width_spaces(value)
    return bool(text) and text.lower() in HIDDEN_TAB_LABEL_TOKENS


def _display_tab_label(value: str) -> str:
    text = _normalize_half_width_spaces(value)
    if _is_hidden_tab_label(text):
        return ""
    return text

# Smart Workspace: Floating Panel & 2D Pan View integration
FP_PREFIX = "FP::"
PV_PREFIX = "PV::"
AREA_PREFIX = "AREA::"
LEGACY_HIDDEN_PANEL_IDS = {"PANVIEW_PT_Panel"}
HIDDEN_TAB_IDENTIFIERS = {"hidden", "__hidden__", "_hidden_"}


def _panel_owner_module_name(cls) -> str:
    return str(getattr(cls, "__module__", "") or "").strip()


def _is_blender_builtin_panel_class(cls) -> bool:
    owner = _panel_owner_module_name(cls)
    if not owner:
        return False
    return owner == "bl_ui" or owner.startswith("bl_ui.")


def _iter_panel_subclasses_recursive(panel_base):
    """Yield Panel subclasses that may not be exposed through dir(bpy.types).

    Some registered add-on panels are discoverable from Panel.__subclasses__()
    even when they are not returned by scanning bpy.types attributes.  The
    All Tabs list must use both sources; otherwise the last visible Sidebar
    category can be omitted depending on add-on registration order.
    """
    if panel_base is None:
        return
    stack = []
    try:
        stack.extend(panel_base.__subclasses__())
    except Exception:
        return
    seen = set()
    while stack:
        cls = stack.pop()
        if not isinstance(cls, type):
            continue
        cls_id = id(cls)
        if cls_id in seen:
            continue
        seen.add(cls_id)
        yield cls
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass


def _is_registered_panel_type(cls, *, from_bpy_types: bool = False) -> bool:
    if not isinstance(cls, type):
        return False
    if from_bpy_types:
        return True
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
    except Exception:
        pass
    try:
        rna = getattr(cls, "bl_rna", None)
    except Exception:
        rna = None
    if rna is None:
        return False
    try:
        identifier = str(getattr(rna, "identifier", "") or "").strip()
    except Exception:
        identifier = ""
    if not identifier or identifier == "Panel":
        return False
    cls_name = str(getattr(cls, "__name__", "") or "").strip()
    bl_idname = str(getattr(cls, "bl_idname", "") or "").strip()
    return identifier in {cls_name, bl_idname} or identifier.startswith(cls_name)


def _registered_panel_types():
    # Panel subclass scanning is expensive.  Keep an explicit-boundary cache;
    # UI drawing never expires it or performs a process-wide class scan.
    try:
        cached = _PANEL_TYPES_CACHE.get("items")
        if cached is not None:
            return tuple(cached)
    except Exception:
        pass
    panel_base = getattr(bpy.types, "Panel", None)
    if panel_base is None:
        return ()

    items = []
    seen = set()

    def _add(cls, *, from_bpy_types: bool = False):
        if not isinstance(cls, type):
            return
        try:
            if not issubclass(cls, panel_base):
                return
        except Exception:
            return
        cls_id = id(cls)
        if cls_id in seen:
            return
        if not _is_registered_panel_type(cls, from_bpy_types=from_bpy_types):
            return
        seen.add(cls_id)
        items.append(cls)

    for name in dir(bpy.types):
        try:
            _add(getattr(bpy.types, name), from_bpy_types=True)
        except Exception:
            continue

    for cls in _iter_panel_subclasses_recursive(panel_base):
        _add(cls, from_bpy_types=False)

    result = tuple(items)
    try:
        _PANEL_TYPES_CACHE["items"] = result
    except Exception:
        pass
    return result


def _invalidate_panel_discovery_cache() -> None:
    _PANEL_TYPES_CACHE["items"] = None
    _PANEL_CATEGORY_CACHE["tabs"] = None
    _PANEL_CATEGORY_CACHE["panels_by_cat"] = {}


def _call_panel_poll_direct(panel_cls, context) -> bool:
    poll_fn = getattr(panel_cls, "poll", None)
    if not callable(poll_fn):
        return True
    try:
        return bool(poll_fn(context))
    except TypeError:
        try:
            return bool(poll_fn(panel_cls, context))
        except Exception:
            return False
    except Exception:
        return False


def _find_window_for_area(context, area):
    if area is None:
        return getattr(context, "window", None)
    try:
        win = getattr(context, "window", None)
        if win is not None and getattr(win, "screen", None) is not None:
            try:
                if any(candidate is area for candidate in win.screen.areas):
                    return win
            except Exception:
                pass
    except Exception:
        pass
    wm = getattr(context, "window_manager", None)
    if wm is None:
        try:
            wm = bpy.context.window_manager
        except Exception:
            wm = None
    if wm is None:
        return getattr(context, "window", None)
    try:
        for win in wm.windows:
            screen = getattr(win, "screen", None)
            if screen is None:
                continue
            try:
                if any(candidate is area for candidate in screen.areas):
                    return win
            except Exception:
                continue
    except Exception:
        pass
    return getattr(context, "window", None)


def _panel_is_view3d_sidebar_candidate(cls) -> bool:
    if not isinstance(cls, type):
        return False
    if _is_hidden_internal_panel_class(cls):
        return False
    space = str(getattr(cls, "bl_space_type", "") or "")
    region = str(getattr(cls, "bl_region_type", "") or "")
    return space == "VIEW_3D" and region == "UI"


def _panel_is_sidebar_candidate(cls) -> bool:
    if not isinstance(cls, type) or _is_hidden_internal_panel_class(cls):
        return False
    space = str(getattr(cls, "bl_space_type", "") or "")
    region = str(getattr(cls, "bl_region_type", "") or "")
    return bool(space and region == "UI")


def _panel_is_visible_for_workspace_scan(cls, context=None) -> bool:
    if not _panel_is_view3d_sidebar_candidate(cls):
        return False
    if _is_blender_builtin_panel_class(cls):
        return True
    # Never enter temp_override from launcher/popup redraw.  Blender 5.1 Windows
    # can switch workspaces/modes while entering overrides for inactive areas and
    # crash in native undo code.  Direct poll on the current context is enough for
    # category discovery; the fallback pass still includes registered categories.
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return True
    return _call_panel_poll_direct(cls, ctx)


def _normalize_tab_identifier(value: str) -> str:
    return _normalize_half_width_spaces(value)


def _normalized_tab_identifier_key(value: str) -> str:
    return _normalize_tab_identifier(value).replace(' ', '').lower()


def _is_hidden_sidebar_tab_identifier(value: str) -> bool:
    ident = _normalized_tab_identifier_key(value)
    if not ident:
        return False
    if ident in HIDDEN_TAB_IDENTIFIERS:
        return True
    if ident.startswith('__hidden__') or ident.endswith('__hidden__'):
        return True
    return False


def _display_tab_identifier(value: str) -> str:
    ident = _normalize_tab_identifier(value)
    if _is_hidden_sidebar_tab_identifier(ident):
        return ""
    return ident


def _is_hidden_internal_panel_id(panel_id: str) -> bool:
    ident = _normalize_tab_identifier(panel_id)
    return ident in LEGACY_HIDDEN_PANEL_IDS


def _panel_type_id(cls) -> str:
    # A Panel without its own bl_idname is registered under its class name; the
    # class attribute then reads as an empty string, for every built-in sidebar panel.
    return str(getattr(cls, "bl_idname", "") or getattr(cls, "__name__", "") or "")


def _is_hidden_internal_panel_class(cls) -> bool:
    if getattr(cls, "nptl_skip_detection", False):
        return True
    if bool(getattr(cls, "_smart_workspace_panel_suppressed", False)):
        return True
    if _is_hidden_internal_panel_id(getattr(cls, "bl_idname", "")):
        return True
    if _is_hidden_sidebar_tab_identifier(getattr(cls, "bl_category", "")):
        return True
    return False


def _get_ui_region(area):
    if not area: return None
    for r in area.regions:
        if r.type == "UI": return r
    return None

# =============================================================
# Monkey Patch for smart_transform_tools (Draw Handler Hijack)
# =============================================================
_COMPAT_PATCHED = False
def _apply_compatibility_patches():
    # Legacy floating-host builds patched draw handlers for hidden custom
    # windows. The current implementation uses Blender's standard N-panel and
    # must not patch other add-ons' draw callbacks.
    global _COMPAT_PATCHED
    _COMPAT_PATCHED = True
    return None


# グローバル変数
_anchor_classes = []
_last_active_category = ""
_rename_timer = None 
_addon_keymaps = []
_last_workspace_name = ""
_workspace_switch_lock = 0
_last_view3d_area_ptr = 0
_update_suspend = 0
_panel_rebuild_lock = 0
_PANEL_TYPES_CACHE = {"items": None}
_PANEL_CATEGORY_CACHE = {"tabs": None, "panels_by_cat": {}}
_LAST_VIEW3D_REDRAW_TS = 0.0

def _push_update_suspend():
    global _update_suspend
    _update_suspend += 1

def _pop_update_suspend():
    global _update_suspend
    _update_suspend = max(0, _update_suspend - 1)

def _updates_suspended():
    return _update_suspend > 0

def _push_panel_rebuild_lock():
    global _panel_rebuild_lock
    _panel_rebuild_lock += 1

def _pop_panel_rebuild_lock():
    global _panel_rebuild_lock
    _panel_rebuild_lock = max(0, _panel_rebuild_lock - 1)

def _panel_rebuild_locked():
    return _panel_rebuild_lock > 0

def _remember_view3d_area(area):
    global _last_view3d_area_ptr
    try:
        if area and area.type == 'VIEW_3D':
            _last_view3d_area_ptr = area.as_pointer()
    except: pass

def _get_preferred_view3d_area(context):
    global _last_view3d_area_ptr
    try:
        a = getattr(context, 'area', None)
        if a and a.type == 'VIEW_3D':
            _remember_view3d_area(a)
            return a
    except: pass
    try:
        win = getattr(context, 'window', None)
        if win and win.screen:
            for a in win.screen.areas:
                if a.type == 'VIEW_3D' and _last_view3d_area_ptr and a.as_pointer() == _last_view3d_area_ptr:
                    return a
            for a in win.screen.areas:
                if a.type == 'VIEW_3D':
                    return a
    except: pass
    try:
        wm = context.window_manager
        if wm:
            for win in wm.windows:
                for a in win.screen.areas:
                    if a.type == 'VIEW_3D' and _last_view3d_area_ptr and a.as_pointer() == _last_view3d_area_ptr:
                        return a
            for win in wm.windows:
                for a in win.screen.areas:
                    if a.type == 'VIEW_3D':
                        return a
    except: pass
    return None

def _tag_redraw_all_view3d(context):
    global _LAST_VIEW3D_REDRAW_TS
    try:
        now = time.monotonic()
        if now - float(_LAST_VIEW3D_REDRAW_TS or 0.0) < 0.08:
            return
        _LAST_VIEW3D_REDRAW_TS = now
    except Exception:
        pass
    try:
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            area.tag_redraw()
            return
    except Exception:
        pass
    try:
        win = getattr(context, 'window', None)
        screen = getattr(win, 'screen', None) if win is not None else None
        if screen is not None:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
            return
    except Exception:
        pass
    try:
        wm = context.window_manager
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass



# =============================================================
# Workspace Profiles (per-workspace settings)
# =============================================================

def _get_active_workspace_name(context):
    try:
        win = getattr(context, 'window', None) or getattr(bpy.context, 'window', None)
        ws = getattr(win, 'workspace', None)
        if ws:
            return ws.name
    except:
        pass
    try:
        ws = getattr(context, 'workspace', None) or getattr(bpy.context, 'workspace', None)
        if ws:
            return ws.name
    except:
        pass
    return ""

def _ws_key_from_name(ws_name: str) -> str:
    try:
        if ws_name is None:
            ws_name = ""
        if not isinstance(ws_name, str):
            ws_name = str(ws_name)
        return "WS_" + ws_name.encode("utf-8").hex()
    except Exception:
        return "WS_"

def _ws_name_from_key(ws_key: str) -> str:
    if not ws_key:
        return ""
    if isinstance(ws_key, str) and ws_key.startswith("WS_"):
        hexpart = ws_key[3:]
        try:
            return bytes.fromhex(hexpart).decode("utf-8")
        except Exception:
            return ""
    return ws_key

def _workspace_enum_items(self, context):
    items = []
    try:
        for ws in bpy.data.workspaces:
            items.append((_ws_key_from_name(ws.name), ws.name, ""))
    except:
        pass
    if not items:
        items = [("", "", "")]
    return items

def _get_or_create_profile(st, ws_name, ws_uuid: str = ""):
    if not ws_name:
        try:
            ws_name = _get_active_workspace_name(bpy.context)
        except Exception:
            ws_name = ""
        if not ws_name:
            ws_name = "Workspace"
    ws_uuid = str(ws_uuid or _LOADING_PROFILE_UUID_BY_NAME.get(str(ws_name), '') or '')
    for profile in st.workspace_profiles:
        if ws_uuid and _profile_workspace_uuid(profile) == ws_uuid:
            if profile.workspace_name != ws_name:
                profile.workspace_name = ws_name
            return profile
    # Display-name matching is allowed only for an unbound legacy profile.  A
    # profile carrying a different stable UUID belongs to a deleted/different
    # Workspace and must never be adopted merely because a new Workspace reused
    # the same visible name.
    for profile in st.workspace_profiles:
        if profile.workspace_name != ws_name:
            continue
        existing_uuid = _profile_workspace_uuid(profile)
        if ws_uuid and existing_uuid:
            continue
        if ws_uuid and not existing_uuid:
            _set_profile_workspace_uuid(profile, ws_uuid)
        return profile
    profile = st.workspace_profiles.add()
    profile.workspace_name = ws_name
    if ws_uuid:
        _set_profile_workspace_uuid(profile, ws_uuid)
    try:
        source = None
        for other in st.workspace_profiles:
            if other is profile:
                continue
            if len(other.categories) > 0 or len(other.detected_tabs) > 0:
                source = other
                break
        if source:
            _copy_profile_data(source, profile)
    except Exception:
        pass
    return profile

def _copy_profile_data(src, dst):
    if (src is None) or (dst is None):
        return
    _push_update_suspend()
    try:
        dst.popup_width = int(getattr(src, "popup_width", getattr(dst, "popup_width", 200)) or getattr(dst, "popup_width", 200))
        dst.popup_columns = int(getattr(src, "popup_columns", getattr(dst, "popup_columns", 5)) or getattr(dst, "popup_columns", 5))
        dst.popup_use_tab_layout = bool(getattr(src, "popup_use_tab_layout", False))
        try:
            dst.popup_show_recent = bool(getattr(src, "popup_show_recent", True))
        except Exception:
            pass
        dst.popup_active_tab_index = int(getattr(src, "popup_active_tab_index", 0) or 0)
        dst.floating_height = int(getattr(src, "floating_height", getattr(dst, "floating_height", 500)) or getattr(dst, "floating_height", 500))

        try:
            dst.pool_mode = str(getattr(src, "pool_mode", getattr(dst, "pool_mode", "TABS")) or getattr(dst, "pool_mode", "TABS"))
        except Exception:
            pass
        try:
            dst.apply_mode = str(getattr(src, "apply_mode", getattr(dst, "apply_mode", "FULL")) or getattr(dst, "apply_mode", "FULL"))
        except Exception:
            pass

        try:
            dst.view3d_default_w = int(getattr(src, "view3d_default_w", getattr(dst, "view3d_default_w", 500)) or getattr(dst, "view3d_default_w", 500))
            dst.view3d_default_h = int(getattr(src, "view3d_default_h", getattr(dst, "view3d_default_h", 800)) or getattr(dst, "view3d_default_h", 800))
            dst.view3d_open_mode = str(getattr(src, "view3d_open_mode", getattr(dst, "view3d_open_mode", "MOUSE")) or getattr(dst, "view3d_open_mode", "MOUSE"))
            dst.view3d_always_on_top = bool(getattr(src, "view3d_always_on_top", False))
            dst.view3d_monitor_interval = float(getattr(src, "view3d_monitor_interval", getattr(dst, "view3d_monitor_interval", 0.5)) or getattr(dst, "view3d_monitor_interval", 0.5))
            dst.view3d_monitor_size = bool(getattr(src, "view3d_monitor_size", True))
            dst.view3d_monitor_settings = bool(getattr(src, "view3d_monitor_settings", True))
            dst.view3d_remember_position = bool(getattr(src, "view3d_remember_position", True))
        except Exception:
            pass

        try:
            dst.search_query = str(getattr(src, "search_query", "") or "")
        except Exception:
            pass

        dst.active_category_index = int(getattr(src, "active_category_index", 0) or 0)
        dst.active_detected_index = int(getattr(src, "active_detected_index", 0) or 0)
        try:
            dst.active_detected_panel_index = int(getattr(src, "active_detected_panel_index", 0) or 0)
        except Exception:
            pass
        try:
            dst.active_favorites_index = int(getattr(src, "active_favorites_index", 0) or 0)
        except Exception:
            pass
        try:
            dst.active_recent_index = int(getattr(src, "active_recent_index", 0) or 0)
        except Exception:
            pass
        try:
            dst.active_fav_panel_index = int(getattr(src, "active_fav_panel_index", 0) or 0)
        except Exception:
            pass

        dst.categories.clear()
        for sc in getattr(src, "categories", []):
            nc = dst.categories.add()
            nc.name = getattr(sc, "name", "")
            nc.active_tab_index = int(getattr(sc, "active_tab_index", 0) or 0)
            nc.tabs.clear()
            for tr in getattr(sc, "tabs", []):
                nt = nc.tabs.add()
                nt.identifier = getattr(tr, "identifier", "")
                nt.custom_label = getattr(tr, "custom_label", "")

        dst.detected_tabs.clear()
        for sd in getattr(src, "detected_tabs", []):
            nd = dst.detected_tabs.add()
            nd.identifier = getattr(sd, "identifier", "")
            nd.name = _display_tab_label(getattr(sd, "name", nd.identifier))
            nd.show = bool(getattr(sd, "show", True))
            nd.custom_name = _display_tab_label(getattr(sd, "custom_name", ""))
            nd.is_pinned = bool(getattr(sd, "is_pinned", False))
            nd.original_category = getattr(sd, "original_category", nd.identifier)

        if hasattr(dst, "detected_panels"):
            dst.detected_panels.clear()
            for sp in getattr(src, "detected_panels", []):
                np = dst.detected_panels.add()
                np.panel_idname = getattr(sp, "panel_idname", "")
                np.label = getattr(sp, "label", "")
                np.category = getattr(sp, "category", "")
                np.is_panview = bool(getattr(sp, "is_panview", False))

        if hasattr(dst, "floating_panels"):
            dst.floating_panels.clear()
            for se in getattr(src, "floating_panels", []):
                ne = dst.floating_panels.add()
                ne.key = getattr(se, "key", "")
                ne.panel_idname = getattr(se, "panel_idname", "")
                ne.label = getattr(se, "label", "")
                ne.category = getattr(se, "category", "")
                ne.default_w = int(getattr(se, "default_w", 500) or 500)
                ne.default_h = int(getattr(se, "default_h", 800) or 800)
                ne.open_mode = str(getattr(se, "open_mode", "MOUSE") or "MOUSE")
                ne.always_on_top = bool(getattr(se, "always_on_top", False))
                ne.monitor_interval = float(getattr(se, "monitor_interval", 0.5) or 0.5)
                ne.monitor_size = bool(getattr(se, "monitor_size", True))
                ne.monitor_settings = bool(getattr(se, "monitor_settings", True))
                ne.remember_position = bool(getattr(se, "remember_position", True))
                ne.last_x = int(getattr(se, "last_x", -1) or -1)
                ne.last_y = int(getattr(se, "last_y", -1) or -1)
                ne.last_w = int(getattr(se, "last_w", 0) or 0)
                ne.last_h = int(getattr(se, "last_h", 0) or 0)
                ne.pinned_x = int(getattr(se, "pinned_x", -1) or -1)
                ne.pinned_y = int(getattr(se, "pinned_y", -1) or -1)

        if hasattr(dst, "favorites_tabs"):
            dst.favorites_tabs.clear()
            for stf in getattr(src, "favorites_tabs", []):
                nt = dst.favorites_tabs.add()
                nt.identifier = getattr(stf, "identifier", "")
                nt.custom_label = getattr(stf, "custom_label", "")

        if hasattr(dst, "recent_tabs"):
            dst.recent_tabs.clear()
            for srt in getattr(src, "recent_tabs", []):
                nr = dst.recent_tabs.add()
                nr.identifier = getattr(srt, "identifier", "")
                nr.custom_label = getattr(srt, "custom_label", "")
                nr.last_used = float(getattr(srt, "last_used", 0.0) or 0.0)

        if hasattr(dst, "favorite_panels"):
            dst.favorite_panels.clear()
            for sfp in getattr(src, "favorite_panels", []):
                np = dst.favorite_panels.add()
                np.panel_idname = getattr(sfp, "panel_idname", "")
                np.label = getattr(sfp, "label", "")
                np.category = getattr(sfp, "category", "")

        try:
            dst.active_category_index = min(getattr(dst, "active_category_index", 0), max(0, len(dst.categories) - 1))
            dst.active_detected_index = min(getattr(dst, "active_detected_index", 0), max(0, len(dst.detected_tabs) - 1))
            if hasattr(dst, "detected_panels"):
                dst.active_detected_panel_index = min(getattr(dst, "active_detected_panel_index", 0), max(0, len(dst.detected_panels) - 1))
            if hasattr(dst, "favorites_tabs"):
                dst.active_favorites_index = min(getattr(dst, "active_favorites_index", 0), max(0, len(dst.favorites_tabs) - 1))
            if hasattr(dst, "recent_tabs"):
                dst.active_recent_index = min(getattr(dst, "active_recent_index", 0), max(0, len(dst.recent_tabs) - 1))
            if hasattr(dst, "favorite_panels"):
                dst.active_fav_panel_index = min(getattr(dst, "active_fav_panel_index", 0), max(0, len(dst.favorite_panels) - 1))
        except Exception:
            pass
    finally:
        _pop_update_suspend()

def _active_profile(context):
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None)
    if not st:
        return None
    ws_name = ""
    try:
        ws_key = st.workspace_selector
        ws_name = _ws_name_from_key(ws_key)
    except:
        ws_name = ""
    if not ws_name:
        ws_name = _get_active_workspace_name(context)
    return _get_or_create_profile(st, ws_name)


def _sidebar_uses_custom_tab_categories(profile) -> bool:
    mode = str(getattr(profile, "apply_mode", "FULL") or "FULL")
    return mode not in {"ORDER_ONLY", "SAFE"}


def _tab_display_name(profile, tab_identifier: str) -> str:
    ident = str(tab_identifier or "").strip()
    if not ident:
        return ""
    ident_display = _display_tab_label(ident)
    try:
        for item in getattr(profile, "detected_tabs", []):
            if getattr(item, "identifier", "") == ident:
                custom = _display_tab_label(getattr(item, "custom_name", ""))
                if custom:
                    return custom
                name = _display_tab_label(getattr(item, "name", ""))
                return name or ident_display
    except Exception:
        pass
    return ident_display


def _tab_has_custom_name(profile, tab_identifier: str) -> bool:
    """タブに利用者が付けた別名があるか（別名は訳さずに出す）。"""
    ident = str(tab_identifier or "").strip()
    try:
        for item in getattr(profile, "detected_tabs", []):
            if getattr(item, "identifier", "") == ident:
                return bool(_display_tab_label(getattr(item, "custom_name", "")))
    except Exception:
        pass
    return False


def _tab_target_category(profile, tab_identifier: str) -> str:
    ident = _normalize_tab_identifier(tab_identifier)
    if not ident:
        return DEFAULT_CAT_NAME
    if _is_hidden_sidebar_tab_identifier(ident):
        return EMPTY_TAB_CAT
    if _sidebar_uses_custom_tab_categories(profile):
        return _tab_display_name(profile, ident) or ident
    return ident


def _tab_category_candidates(profile, tab_identifier: str) -> List[str]:
    ident = _normalize_tab_identifier(tab_identifier)
    if _is_hidden_sidebar_tab_identifier(ident):
        return [EMPTY_TAB_CAT]
    candidates: List[str] = []
    for value in (_tab_target_category(profile, ident), _tab_display_name(profile, ident), ident):
        value = _display_tab_identifier(value)
        value = str(value or "").strip()
        if value and value not in candidates and not _is_hidden_sidebar_tab_identifier(value):
            candidates.append(value)
    if not candidates:
        candidates.append(DEFAULT_CAT_NAME)
    return candidates


def _resolve_existing_tab_category(profile, tab_identifier: str, existing: Optional[Set[str]] = None) -> str:
    if _is_hidden_sidebar_tab_identifier(tab_identifier):
        return EMPTY_TAB_CAT
    applied = _SIDEBAR_APPLIED_NAMES.get(_normalize_tab_identifier(tab_identifier))
    if applied:
        return applied
    candidates = _tab_category_candidates(profile, tab_identifier)
    try:
        existing_set = set(existing) if existing is not None else set(_scan_all_sidebar_tabs())
    except Exception:
        existing_set = set()
    for value in candidates:
        if value in existing_set:
            return value
    return candidates[0] if candidates else DEFAULT_CAT_NAME


def _tab_matches_category(profile, tab_identifier: str, category_name: str) -> bool:
    cat = _display_tab_identifier(category_name)
    cat = str(cat or "").strip()
    if not cat or _is_hidden_sidebar_tab_identifier(cat):
        return False
    if _SIDEBAR_APPLIED_NAMES.get(_normalize_tab_identifier(tab_identifier)) == cat:
        return True
    try:
        return cat in {str(_display_tab_identifier(value) or "").strip() for value in _tab_category_candidates(profile, tab_identifier)}
    except Exception:
        return False

def _sync_selector_to_active_workspace(context):
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None)
    if not st:
        return ""
    ws_name = _get_active_workspace_name(context)
    if not ws_name:
        return ""
    try:
        target_key = _ws_key_from_name(ws_name)
        # ``workspace_selector`` follows the active workspace, while
        # ``workspace_ptr`` is the user's explicit source/profile selection.
        # Older startup/runtime sync paths assigned both fields, so merely
        # enabling an unrelated always-on feature replaced a deliberately
        # cleared or selected pointer and persisted that side effect to CONFIG.
        if getattr(st, 'workspace_selector', "") != target_key:
            _push_update_suspend()
            try:
                st.workspace_selector = target_key
            finally:
                _pop_update_suspend()
    except:
        pass
    return ws_name

def _on_workspace_activated(context, ws_name, apply_layout=True):
    global _last_active_category
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None)
    if not st:
        return
    prof = _get_or_create_profile(st, ws_name)
    if len(prof.detected_tabs) == 0:
        _refresh_detected_tabs_logic(context, prof)
    try:
        if hasattr(prof, 'detected_panels') and len(prof.detected_panels) == 0:
            _refresh_detected_panels_logic(context, prof)
    except Exception:
        pass
    if apply_layout:
        _apply_sidebar_layout(context, prof)
        _last_active_category = ""

def _apply_pins_for_category(context, current_cat):
    # Pins follow through the draw wrapper; nothing moves between categories.
    return None





# =============================================================
# Blender standard Sidebar panel pin bridge
# =============================================================
# Blender exposes the built-in N-panel header "Pin" state as Panel.use_pin.
# The quick launcher uses that standard per-panel pin state instead of the old
# class-category relocation/pin-follow system.  This keeps the feature aligned
# with Blender's own right-click panel-header pin behavior while avoiding any
# Panel unregister/register operations during UI drawing.
_STANDARD_PIN_WRAPPED: Dict[type, tuple] = {}
_STANDARD_PIN_RELEASING = False
_STANDARD_PIN_APPLIED: Set[int] = set()  # Panel instances carrying a pin set here.
_STANDARD_PIN_ORIGINAL_DRAW = '_sws_standard_pin_original_draw'
_STANDARD_PIN_ORIGINAL_DRAW_HEADER = '_sws_standard_pin_original_draw_header'
_STANDARD_PIN_WRAPPER_MARK = '_sws_standard_pin_wrapper'
_STANDARD_PIN_MANAGED = '_sws_standard_pin_managed'
_STANDARD_PIN_DESIRED = '_sws_standard_pin_desired'
_STANDARD_PIN_FORCE_UNPIN = '_sws_standard_pin_force_unpin'
_STANDARD_PIN_LAST_STATE = '_sws_standard_pin_last_state'


def _standard_pin_panel_category(cls) -> str:
    try:
        cat = _get_panel_category(cls)
    except Exception:
        cat = ''
    cat = _display_tab_identifier(cat)
    if not cat or _is_hidden_sidebar_tab_identifier(cat):
        return ''
    return cat


def _standard_pin_profile(context=None, profile=None):
    if profile is not None:
        return profile
    try:
        return _active_profile(context or getattr(bpy, 'context', None))
    except Exception:
        return None


def _standard_pin_categories_for_tab(profile, tab_identifier: str) -> Set[str]:
    cats: Set[str] = set()
    ident = _normalize_tab_identifier(tab_identifier)
    if not profile or not ident or ident.startswith(FP_PREFIX) or ident.startswith(PV_PREFIX):
        return cats
    try:
        for value in _tab_category_candidates(profile, ident):
            cat = _display_tab_identifier(value)
            if cat and not _is_hidden_sidebar_tab_identifier(cat):
                cats.add(cat)
    except Exception:
        pass
    if not cats:
        cat = _display_tab_identifier(ident)
        if cat and not _is_hidden_sidebar_tab_identifier(cat):
            cats.add(cat)
    return cats


def _standard_pin_categories_from_profile(profile) -> Set[str]:
    cats: Set[str] = set()
    if not profile:
        return cats
    try:
        for item in getattr(profile, 'detected_tabs', []) or []:
            if not bool(getattr(item, 'is_pinned', False)):
                continue
            cats.update(_standard_pin_categories_for_tab(profile, getattr(item, 'identifier', '') or ''))
    except Exception:
        pass
    return cats


def _standard_pin_panel_classes_for_tab(context=None, tab_identifier: str = '', profile=None) -> List[type]:
    prof = _standard_pin_profile(context, profile)
    cats = _standard_pin_categories_for_tab(prof, tab_identifier)
    if not cats:
        return []
    out: List[type] = []
    seen: Set[int] = set()
    for cls in _get_all_registered_view3d_sidebar_panels():
        try:
            if _is_hidden_internal_panel_class(cls):
                continue
            cat = _standard_pin_panel_category(cls)
            if cat not in cats:
                continue
            ptr = id(cls)
            if ptr in seen:
                continue
            seen.add(ptr)
            out.append(cls)
        except Exception:
            continue
    return out


def _standard_pin_should_pin_class(cls, context=None, profile=None) -> bool:
    prof = _standard_pin_profile(context, profile)
    if not prof:
        return bool(getattr(cls, _STANDARD_PIN_DESIRED, False))
    cat = _standard_pin_panel_category(cls)
    if not cat:
        return False
    try:
        for item in getattr(prof, 'detected_tabs', []) or []:
            if not bool(getattr(item, 'is_pinned', False)):
                continue
            ident = getattr(item, 'identifier', '') or ''
            if _tab_matches_category(prof, ident, cat):
                return True
    except Exception:
        pass
    return False


def _standard_pin_desired_for_class(cls, context) -> bool:
    """Read-only lookup: this runs during Sidebar drawing and must not write IDs."""
    if _STANDARD_PIN_RELEASING:
        return False
    st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None)
    workspace = getattr(context, 'workspace', None)
    prof = _find_profile_by_name(st, getattr(workspace, 'name', ''))
    if prof is None:
        return False
    cat = _standard_pin_panel_category(cls)
    if not cat:
        return False
    for item in prof.detected_tabs:
        if item.is_pinned and item.identifier == cat:
            return True
    return False


def _standard_pin_redraw_timer():
    try:
        _tag_redraw_all_view3d(bpy.context)
    except Exception:
        pass
    return None


def _standard_pin_request_redraw() -> None:
    # The Sidebar has already chosen its panels for this redraw.
    if not bpy.app.timers.is_registered(_standard_pin_redraw_timer):
        bpy.app.timers.register(_standard_pin_redraw_timer, first_interval=0.05)


def _sync_standard_pin_for_panel_instance(panel, context=None, cls=None) -> None:
    desired = _standard_pin_desired_for_class(cls or type(panel), context)
    pointer = panel.as_pointer()
    if desired:
        _STANDARD_PIN_APPLIED.add(pointer)
    elif pointer in _STANDARD_PIN_APPLIED:
        _STANDARD_PIN_APPLIED.discard(pointer)
    else:
        # A pin this suite never set is the user's own header pin.
        return
    if bool(panel.use_pin) != desired:
        panel.use_pin = desired
        _standard_pin_request_redraw()
    if _STANDARD_PIN_RELEASING and not _STANDARD_PIN_APPLIED:
        _suite_storage.register_timer_slot(
            'runtime.core.standard_pin_release',
            _standard_pin_release_timer,
            first_interval=0.1,
            persistent=False,
        )


def _wrap_standard_pin_panel_class(cls) -> bool:
    if cls in _STANDARD_PIN_WRAPPED:
        return False
    leftover = getattr(vars(cls).get('draw'), '_sws_pin_leftover', None)
    if leftover:
        # Left behind by the previous shutdown of this add-on: take over from it.
        left_original, left_had_own, left_pending = leftover
        _STANDARD_PIN_APPLIED.update(left_pending)
        if left_had_own:
            cls.draw = left_original
        else:
            del cls.draw
    original = getattr(cls, 'draw', None)
    if not callable(original):
        return False
    had_own_draw = 'draw' in vars(cls)

    # wraps() keeps ``_draw_funcs``, so Panel.append()/prepend() still work.
    @functools.wraps(original)
    def draw(self, context):
        try:
            _sync_standard_pin_for_panel_instance(self, context, cls)
        except Exception:
            pass
        return original(self, context)

    cls.draw = draw
    _STANDARD_PIN_WRAPPED[cls] = (draw, original, had_own_draw)
    return True


def _standard_pin_root_classes(categories: Set[str]) -> List[type]:
    out: List[type] = []
    _invalidate_panel_discovery_cache()
    for cls in _get_all_registered_view3d_sidebar_panels():
        try:
            if getattr(cls, 'bl_parent_id', ''):
                continue
            if 'bl_rna' in vars(cls) and _standard_pin_panel_category(cls) in categories:
                out.append(cls)
        except Exception:
            continue
    return out


def install_standard_panel_pin_runtime(context=None) -> int:
    """Wrap the top-level panels of every tab pinned in any workspace profile."""
    global _STANDARD_PIN_RELEASING
    _STANDARD_PIN_RELEASING = False
    _suite_storage.unregister_timer_slot(
        'runtime.core.standard_pin_release',
        globals().get('_standard_pin_release_timer'),
    )
    st = getattr(getattr(context or getattr(bpy, 'context', None), 'window_manager', None), 'nptl_settings', None)
    categories: Set[str] = set()
    for prof in getattr(st, 'workspace_profiles', ()) or ():
        for item in prof.detected_tabs:
            if item.is_pinned:
                categories.add(item.identifier)
    count = 0
    for cls in _standard_pin_root_classes(categories):
        if _wrap_standard_pin_panel_class(cls):
            count += 1
    return count


def uninstall_standard_panel_pin_runtime() -> None:
    """Put every wrapped draw back; a panel somebody re-wrapped later stays theirs."""
    global _STANDARD_PIN_RELEASING
    _STANDARD_PIN_RELEASING = False
    _suite_storage.unregister_timer_slot(
        'runtime.core.standard_pin_release',
        globals().get('_standard_pin_release_timer'),
    )
    for cls, (wrapper, original, had_own_draw) in tuple(_STANDARD_PIN_WRAPPED.items()):
        try:
            if vars(cls).get('draw') is wrapper:
                if had_own_draw:
                    cls.draw = original
                else:
                    del cls.draw
        except Exception:
            pass
    _STANDARD_PIN_WRAPPED.clear()
    _STANDARD_PIN_APPLIED.clear()
    return None


def _standard_pin_release_timer():
    if not _STANDARD_PIN_APPLIED:
        uninstall_standard_panel_pin_runtime()
    return None


def release_standard_panel_pins(context=None) -> None:
    """Unpin each panel when it is next drawn; the wrappers go after the last one.

    Only a panel's own draw can reach its use_pin, so a panel that is out of
    sight now (closed Sidebar, another workspace, collapsed) keeps its wrapper
    until it is shown again.
    """
    global _STANDARD_PIN_RELEASING
    if not _STANDARD_PIN_WRAPPED:
        return None
    if not _STANDARD_PIN_APPLIED:
        uninstall_standard_panel_pin_runtime()
        return None
    _STANDARD_PIN_RELEASING = True
    try:
        _tag_redraw_all_view3d(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _standard_pin_leftover_draw(original, had_own_draw, pending, finish):
    @functools.wraps(original)
    def draw(self, context):
        try:
            pointer = self.as_pointer()
            if pointer in pending:
                pending.discard(pointer)
                self.use_pin = False
                _standard_pin_request_redraw()
                if not pending:
                    bpy.app.timers.register(finish, first_interval=0.1, persistent=True)
        except Exception:
            pass
        return original(self, context)

    draw._sws_pin_leftover = (original, had_own_draw, pending)
    return draw


def leave_standard_panel_pins_on_shutdown(context=None) -> None:
    """Add-on shutdown: panels this suite pinned must not stay pinned without it.

    Nothing but the panel's own draw can clear use_pin, so a small draw stays on
    those classes until each pinned panel has been drawn once, then removes itself.
    """
    pending = set(_STANDARD_PIN_APPLIED)
    if not pending:
        uninstall_standard_panel_pin_runtime()
        return None
    left = []

    def finish():
        for cls, draw, original, had_own_draw in left:
            try:
                if vars(cls).get('draw') is draw:
                    if had_own_draw:
                        cls.draw = original
                    else:
                        del cls.draw
            except Exception:
                pass
        left.clear()
        return None

    wrapped = tuple(_STANDARD_PIN_WRAPPED.items())
    uninstall_standard_panel_pin_runtime()
    for cls, (_wrapper, original, had_own_draw) in wrapped:
        try:
            draw = _standard_pin_leftover_draw(original, had_own_draw, pending, finish)
            cls.draw = draw
            left.append((cls, draw, original, had_own_draw))
        except Exception:
            pass
    try:
        _tag_redraw_all_view3d(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def standard_tab_pin_state(context=None, tab_identifier: str = '', profile=None) -> bool:
    prof = _standard_pin_profile(context, profile)
    ident = _normalize_tab_identifier(tab_identifier)
    if not prof or not ident:
        return False
    try:
        for item in getattr(prof, 'detected_tabs', []) or []:
            if getattr(item, 'identifier', '') == ident:
                return bool(getattr(item, 'is_pinned', False))
    except Exception:
        pass
    return False

def set_standard_tab_pin_state(context=None, tab_identifier: str = '', pinned: bool = True, profile=None, *, save: bool = True) -> bool:
    """Persist the launcher pin; the draw wrapper mirrors it to Panel.use_pin."""
    ctx = context or getattr(bpy, 'context', None)
    prof = _standard_pin_profile(ctx, profile)
    ident = _normalize_tab_identifier(tab_identifier)
    if not prof or not ident or ident.startswith(FP_PREFIX) or ident.startswith(PV_PREFIX):
        return False
    desired = bool(pinned)
    changed = False
    _push_update_suspend()
    try:
        for item in getattr(prof, 'detected_tabs', []) or []:
            if getattr(item, 'identifier', '') == ident:
                changed = bool(getattr(item, 'is_pinned', False)) != desired
                item.is_pinned = desired
                break
    finally:
        _pop_update_suspend()
    try:
        _tag_redraw_all_view3d(ctx)
    except Exception:
        pass
    if save and changed:
        try:
            save_config_to_file(ctx, verified_user_change=True)
        except Exception:
            return False
    return True

def apply_standard_pin_state_from_profile(context=None, profile=None) -> None:
    del profile
    install_standard_panel_pin_runtime(context)
    try:
        _tag_redraw_all_view3d(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return None

def save_config_to_file(
    context,
    *,
    force: bool = False,
    verified_user_change: bool = False,
    profile_names: Optional[Set[str]] = None,
) -> bool:
    """Save N-panel Manager state without blocking an interactive operation."""
    if verified_user_change and not force:
        return bool(_schedule_live_state_write(
            context,
            include_profile=not bool(profile_names),
            profile_names=profile_names,
            include_ui=True,
        ))
    return save_n_panel_manager_current_settings(
        context,
        force=force,
        verified_user_change=verified_user_change,
    )




def export_config(context) -> dict:
    """Return a detached strict-contract-ready configuration graph."""
    try:
        return copy.deepcopy(_nptl_current_payload(context) or {})
    except Exception:
        return {}


def import_config(context, data: dict):
    """Strictly validate, apply, and adopt one canonical N-panel import."""
    if not isinstance(data, dict):
        return False
    try:
        normalized, _legacy = _strict_json.validate_current_payload(
            data,
            allow_legacy=True,
            source='explicit-import',
        )
    except Exception:
        return False
    prepared = _prepare_loaded_workspace_payload(normalized)
    if not _apply_loaded_data(
        context,
        prepared,
        require_materialized_readback=False,
        use_live_overlay=False,
    ):
        return False
    try:
        from .. import persistence as _suite_persistence
        result = _suite_persistence.commit_explicit_settings_transaction(
            context,
            normalized,
            central_payload=None,
            state_save_enabled=None,
            stage_local_sidecars=False,
            source='n-panel-preset-import',
            allow_unmaterialized_n_panel=True,
        )
        return bool(isinstance(result, dict) and result.get('success') is True)
    except Exception:
        return False


def _apply_loaded_data_unchecked(context, data: dict) -> bool:
    """Apply one validated graph without collapsing empty/zero/False values."""
    global _LAST_NPTL_LOAD_ERROR
    if context is None or not hasattr(getattr(context, "window_manager", None), "nptl_settings"):
        _LAST_NPTL_LOAD_ERROR = "NPTL_SETTINGS_NOT_READY"
        return False
    success = False
    _push_update_suspend()
    try:
        st = context.window_manager.nptl_settings
        try:
            ui_state = data.get("ui_state", {}) if isinstance(data, dict) else {}
            _apply_ui_state(st, ui_state)
        except Exception:
            pass
        try:
            ws_selector = _loaded_str(data.get("workspace_selector"), "")
            if hasattr(st, "workspace_selector"):
                # Empty is an authoritative loaded value, not a request to keep
                # whichever workspace happened to be active during startup.
                st.workspace_selector = ws_selector
            ptr_payload = data.get('workspace_ptr') if isinstance(data, dict) else None
            ptr_name = (
                _loaded_str(ptr_payload.get('name'), '')
                if isinstance(ptr_payload, dict)
                else (_loaded_str(ptr_payload, '') if isinstance(ptr_payload, str) else '')
            )
            if hasattr(st, 'workspace_ptr'):
                # An empty persisted name is meaningful: it clears a pointer
                # that may have been populated by the startup workspace.
                st.workspace_ptr = bpy.data.workspaces.get(ptr_name) if ptr_name else None
        except Exception:
            pass
        st.workspace_profiles.clear()

        def _fill_profile_from_dict(prof, pdata):
            if isinstance(pdata, dict):
                _set_profile_workspace_uuid(prof, str(pdata.get("workspace_uuid", "") or ""))
            prof.categories.clear()
            for c_dict in pdata.get("categories", []):
                cat = prof.categories.add()
                cat.name = _normalize_half_width_spaces(c_dict.get("name", "New Category"))
                cat.active_tab_index = _loaded_int(c_dict.get("active_tab_index", c_dict.get("active_idx")), 0)
                for tab_entry in c_dict.get("tabs", []):
                    if isinstance(tab_entry, dict):
                        identifier = _normalize_tab_identifier(tab_entry.get("id", ""))
                        custom_label = _display_tab_identifier(tab_entry.get("label", ""))
                    else:
                        identifier = _normalize_tab_identifier(str(tab_entry))
                        custom_label = ""
                    if not identifier or _is_hidden_sidebar_tab_identifier(identifier):
                        continue
                    t = cat.tabs.add()
                    t.identifier = identifier
                    t.custom_label = custom_label

            prof.active_category_index = _loaded_int(pdata.get("active_category_index"), 0)
            prof.popup_width = _loaded_int(pdata.get("popup_width"), int(prof.popup_width))
            prof.popup_columns = _loaded_int(pdata.get("popup_columns"), int(prof.popup_columns))
            prof.popup_use_tab_layout = _loaded_bool(pdata.get("popup_use_tab_layout"), False)
            try:
                prof.popup_show_recent = _loaded_bool(pdata.get("popup_show_recent"), True)
            except Exception:
                pass
            prof.popup_active_tab_index = _loaded_int(pdata.get("popup_active_tab_index"), 0)
            prof.floating_height = _loaded_int(pdata.get("floating_height"), int(prof.floating_height))

            # New fields (vNext)
            try:
                prof.apply_mode = _loaded_str(pdata.get("apply_mode"), getattr(prof, "apply_mode", "FULL"))
            except Exception:
                pass



            # Smart Workspace: pool + floating panel defaults
            try:
                prof.pool_mode = _loaded_str(pdata.get("pool_mode"), getattr(prof, "pool_mode", "TABS"))
            except Exception:
                pass
            try:
                prof.active_detected_panel_index = _loaded_int(pdata.get("active_detected_panel_index"), 0)
            except Exception:
                pass
            for _idx_name in ("active_favorites_index", "active_recent_index", "active_fav_panel_index"):
                try:
                    setattr(prof, _idx_name, _loaded_int(pdata.get(_idx_name), 0))
                except Exception:
                    pass
            try:
                prof.search_query = _loaded_str(pdata.get("search_query"), "")
            except Exception:
                pass
            vd = pdata.get("view3d_defaults", {}) if isinstance(pdata.get("view3d_defaults", {}), dict) else {}
            try:
                prof.view3d_default_w = _loaded_int(vd.get("w"), int(getattr(prof, "view3d_default_w", 500)))
                prof.view3d_default_h = _loaded_int(vd.get("h"), int(getattr(prof, "view3d_default_h", 800)))
                prof.view3d_open_mode = _loaded_str(vd.get("open_mode"), getattr(prof, "view3d_open_mode", "MOUSE"))
                prof.view3d_always_on_top = _loaded_bool(vd.get("always_on_top"), bool(getattr(prof, "view3d_always_on_top", False)))
                prof.view3d_monitor_interval = _loaded_float(vd.get("monitor_interval"), float(getattr(prof, "view3d_monitor_interval", 0.5)))
                prof.view3d_monitor_size = _loaded_bool(vd.get("monitor_size"), bool(getattr(prof, "view3d_monitor_size", True)))
                prof.view3d_monitor_settings = _loaded_bool(vd.get("monitor_settings"), bool(getattr(prof, "view3d_monitor_settings", True)))
                prof.view3d_remember_position = _loaded_bool(vd.get("remember_position"), bool(getattr(prof, "view3d_remember_position", True)))
            except Exception:
                pass

            if hasattr(prof, "floating_panels"):
                prof.floating_panels.clear()
                for ent in pdata.get("floating_panels", []) or []:
                    if not isinstance(ent, dict):
                        continue
                    panel_idname = ent.get("panel", "")
                    if _is_hidden_internal_panel_id(panel_idname):
                        continue
                    e = prof.floating_panels.add()
                    e.key = _loaded_str(ent.get("key"), "")
                    e.panel_idname = _loaded_str(panel_idname, "")
                    e.label = _display_tab_label(ent.get("label", ""))
                    e.category = _display_tab_identifier(ent.get("cat", ""))
                    e.default_w = _loaded_int(ent.get("w"), 500)
                    e.default_h = _loaded_int(ent.get("h"), 800)
                    e.open_mode = _loaded_str(ent.get("open_mode"), "MOUSE")
                    e.always_on_top = _loaded_bool(ent.get("top"), False)
                    e.monitor_interval = _loaded_float(ent.get("ival"), 0.5)
                    e.monitor_size = _loaded_bool(ent.get("ms"), True)
                    e.monitor_settings = _loaded_bool(ent.get("mset"), True)
                    e.remember_position = _loaded_bool(ent.get("rp"), True)
                    e.last_x = _loaded_int(ent.get("lx"), -1)
                    e.last_y = _loaded_int(ent.get("ly"), -1)
                    e.last_w = _loaded_int(ent.get("lw"), 0)
                    e.last_h = _loaded_int(ent.get("lh"), 0)
                    e.pinned_x = _loaded_int(ent.get("px"), -1)
                    e.pinned_y = _loaded_int(ent.get("py"), -1)

            if hasattr(prof, "detected_panels"):
                prof.detected_panels.clear()
                for ent in pdata.get("detected_panels", []) or []:
                    if not isinstance(ent, dict):
                        continue
                    panel_idname = str(ent.get("id", "") or "")
                    category = _display_tab_identifier(ent.get("cat", ""))
                    if _is_hidden_internal_panel_id(panel_idname):
                        continue
                    panel = prof.detected_panels.add()
                    panel.panel_idname = panel_idname
                    panel.label = _display_tab_label(ent.get("label", ""))
                    panel.category = category
                    panel.is_panview = _loaded_bool(ent.get("panview"), False)

            if hasattr(prof, "favorites_tabs"):
                prof.favorites_tabs.clear()
                for ent in pdata.get("favorites_tabs", []):
                    identifier = _normalize_tab_identifier(ent.get("id", "") if isinstance(ent, dict) else str(ent))
                    if not identifier or _is_hidden_sidebar_tab_identifier(identifier):
                        continue
                    t = prof.favorites_tabs.add()
                    t.identifier = identifier
                    t.custom_label = _display_tab_identifier(ent.get("label", "") if isinstance(ent, dict) else "")
            if hasattr(prof, "recent_tabs"):
                prof.recent_tabs.clear()
                for ent in pdata.get("recent_tabs", []):
                    identifier = _normalize_tab_identifier(ent.get("id", "") if isinstance(ent, dict) else str(ent))
                    if not identifier or _is_hidden_sidebar_tab_identifier(identifier):
                        continue
                    r = prof.recent_tabs.add()
                    if isinstance(ent, dict):
                        r.identifier = identifier
                        r.custom_label = _display_tab_identifier(ent.get("label", ""))
                        r.last_used = _loaded_float(ent.get("ts"), 0.0)
                    else:
                        r.identifier = identifier
                        r.custom_label = ""
                        r.last_used = 0.0
            if hasattr(prof, "favorite_panels"):
                prof.favorite_panels.clear()
                for ent in pdata.get("favorite_panels", []):
                    panel_idname = ent.get("id", "") if isinstance(ent, dict) else str(ent)
                    category = ent.get("cat", "") if isinstance(ent, dict) else ""
                    if _is_hidden_internal_panel_id(panel_idname) or _is_hidden_sidebar_tab_identifier(category):
                        continue
                    p = prof.favorite_panels.add()
                    if isinstance(ent, dict):
                        p.panel_idname = panel_idname
                        p.label = _display_tab_label(ent.get("label", ""))
                        p.category = _display_tab_identifier(category)
                    else:
                        p.panel_idname = panel_idname
                        p.label = ""
                        p.category = ""

            prof.detected_tabs.clear()
            detected = pdata.get("detected_tabs", pdata.get("detected", []))
            for entry in detected:
                d = prof.detected_tabs.add()
                if isinstance(entry, dict):
                    d.identifier = _normalize_tab_identifier(entry.get("identifier", entry.get("id", "")))
                    d.name = _display_tab_label(entry.get("name", d.identifier))
                    d.custom_name = _display_tab_label(entry.get("custom_name", ""))
                    d.show = _loaded_bool(entry.get("show"), True)
                    d.is_pinned = _loaded_bool(entry.get("is_pinned", entry.get("pinned", False)), False)
                    d.original_category = _display_tab_identifier(entry.get("original_category", entry.get("orig_cat", d.identifier)))
                else:
                    d.identifier = _normalize_tab_identifier(str(entry))
                    d.name = _display_tab_label(d.identifier)
                    d.custom_name = ""
                    d.show = True
                    d.is_pinned = False
                    d.original_category = d.identifier

            prof.active_detected_index = _loaded_int(pdata.get("active_detected_index"), 0)

        workspaces_payload = data.get("workspaces") if isinstance(data, dict) else None
        profiles_payload = data.get("workspace_profiles") if isinstance(data, dict) else None
        if isinstance(workspaces_payload, dict) and workspaces_payload:
            # New schema
            for ws_name, pdata in workspaces_payload.items():
                prof = _get_or_create_profile(st, ws_name, str(pdata.get("workspace_uuid", "") or ""))
                _fill_profile_from_dict(prof, pdata)
        elif isinstance(profiles_payload, list):
            # Current schema
            for pdata in profiles_payload:
                ws_name = pdata.get("workspace_name", "Default")
                prof = _get_or_create_profile(st, ws_name, str(pdata.get("workspace_uuid", "") or ""))
                _fill_profile_from_dict(prof, pdata)
        elif isinstance(profiles_payload, dict):
            # Current schema variant used by some exported files
            for ws_name, pdata in profiles_payload.items():
                prof = _get_or_create_profile(st, ws_name, str(pdata.get("workspace_uuid", "") or ""))
                _fill_profile_from_dict(prof, pdata)
        elif isinstance(workspaces_payload, dict) and ("workspaces" in data or data.get("schema") == "NPTL_V1"):
            # New schema with no saved workspaces.
            pass
        elif isinstance(data, dict):
            # Legacy flat schema
            legacy = data
            legacy_profile = {
                "categories": legacy.get("categories", []),
                "detected": legacy.get("detected", legacy.get("detected_tabs", [])),
                "active_category_index": legacy.get("active_category_index", 0),
                "active_detected_index": legacy.get("active_detected_index", 0),
                "popup_width": legacy.get("popup_width", 200),
                "popup_columns": legacy.get("popup_columns", 5),
                "popup_use_tab_layout": legacy.get("popup_use_tab_layout", False),
                "popup_active_tab_index": legacy.get("popup_active_tab_index", 0),
                "floating_height": legacy.get("floating_height", 500),
            }
            try:
                for ws in bpy.data.workspaces:
                    prof = _get_or_create_profile(st, ws.name)
                    _fill_profile_from_dict(prof, legacy_profile)
            except Exception:
                prof = _get_or_create_profile(st, _get_active_workspace_name(context) or "Default")
                _fill_profile_from_dict(prof, legacy_profile)

        try:
            for ws in bpy.data.workspaces:
                _get_or_create_profile(st, ws.name, _workspace_uuid(ws, create=True))
        except Exception:
            pass
        _reconcile_workspace_profiles(st)

        _sync_selector_to_active_workspace(context)
        success = True
        _LAST_NPTL_LOAD_ERROR = ""
    except Exception as exc:
        _LAST_NPTL_LOAD_ERROR = f"{type(exc).__name__}: {exc}"
        success = False
    finally:
        _pop_update_suspend()
    try:
        from .. import workspace_step_reorder as _workspace_step_reorder
        sync_fn = getattr(_workspace_step_reorder, 'sync_from_settings', None)
        if callable(sync_fn):
            sync_fn(context)
    except Exception:
        pass
    try:
        from .. import floating_window_lock as _floating_window_lock
        sync_fn = getattr(_floating_window_lock, 'sync_from_settings', None)
        if callable(sync_fn):
            sync_fn(context)
    except Exception:
        pass
    return bool(success)



def _nptl_list(value: Any) -> list:
    return list(value) if isinstance(value, (list, tuple)) else []


def _nptl_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _nptl_tab_signature(value: Any) -> Dict[str, Any]:
    item = _nptl_dict(value)
    if item:
        identifier = item.get('id', item.get('identifier', ''))
        label = item.get('label', item.get('custom_label', ''))
    else:
        identifier = value if isinstance(value, str) else ''
        label = ''
    return {
        'identifier': _loaded_str(identifier, ''),
        'custom_label': _loaded_str(label, ''),
    }


def _nptl_recent_signature(value: Any) -> Dict[str, Any]:
    item = _nptl_dict(value)
    base = _nptl_tab_signature(value)
    base['last_used'] = _loaded_float(item.get('ts', item.get('last_used')), 0.0)
    return base


def _nptl_panel_signature(value: Any, *, detected: bool = False) -> Dict[str, Any]:
    item = _nptl_dict(value)
    result = {
        'panel_idname': _loaded_str(item.get('id', item.get('panel_idname', item.get('panel', ''))), ''),
        'label': _loaded_str(item.get('label'), ''),
        'category': _loaded_str(item.get('cat', item.get('category', '')), ''),
    }
    if detected:
        result['is_panview'] = _loaded_bool(item.get('panview', item.get('is_panview')), False)
    return result


def _nptl_detected_tab_signature(value: Any) -> Dict[str, Any]:
    item = _nptl_dict(value)
    identifier = _loaded_str(item.get('identifier', item.get('id', '')), '')
    return {
        'identifier': identifier,
        'name': _loaded_str(item.get('name'), identifier),
        'custom_name': _loaded_str(item.get('custom_name'), ''),
        'show': _loaded_bool(item.get('show'), True),
        'is_pinned': _loaded_bool(item.get('is_pinned', item.get('pinned')), False),
        'original_category': _loaded_str(
            item.get('original_category', item.get('orig_cat', identifier)),
            identifier,
        ),
    }


def _nptl_floating_panel_signature(value: Any) -> Dict[str, Any]:
    item = _nptl_dict(value)
    return {
        'key': _loaded_str(item.get('key'), ''),
        'panel_idname': _loaded_str(item.get('panel', item.get('panel_idname', '')), ''),
        'label': _loaded_str(item.get('label'), ''),
        'category': _loaded_str(item.get('cat', item.get('category', '')), ''),
        'default_w': _loaded_int(item.get('w', item.get('default_w')), 500),
        'default_h': _loaded_int(item.get('h', item.get('default_h')), 800),
        'open_mode': _loaded_str(item.get('open_mode'), 'MOUSE'),
        'always_on_top': _loaded_bool(item.get('top', item.get('always_on_top')), False),
        'monitor_interval': _loaded_float(item.get('ival', item.get('monitor_interval')), 0.5),
        'monitor_size': _loaded_bool(item.get('ms', item.get('monitor_size')), True),
        'monitor_settings': _loaded_bool(item.get('mset', item.get('monitor_settings')), True),
        'remember_position': _loaded_bool(item.get('rp', item.get('remember_position')), True),
        'last_x': _loaded_int(item.get('lx', item.get('last_x')), -1),
        'last_y': _loaded_int(item.get('ly', item.get('last_y')), -1),
        'last_w': _loaded_int(item.get('lw', item.get('last_w')), 0),
        'last_h': _loaded_int(item.get('lh', item.get('last_h')), 0),
        'pinned_x': _loaded_int(item.get('px', item.get('pinned_x')), -1),
        'pinned_y': _loaded_int(item.get('py', item.get('pinned_y')), -1),
    }


def _nptl_category_signature(value: Any) -> Dict[str, Any]:
    item = _nptl_dict(value)
    return {
        'name': _loaded_str(item.get('name'), 'New Category'),
        'active_tab_index': _loaded_int(item.get('active_tab_index', item.get('active_idx')), 0),
        'tabs': [_nptl_tab_signature(entry) for entry in _nptl_list(item.get('tabs'))],
    }


def _nptl_profile_signature(value: Any, *, include_uuid: bool) -> Dict[str, Any]:
    item = _nptl_dict(value)
    view = _nptl_dict(item.get('view3d_defaults'))
    detected_source = item.get('detected_tabs', item.get('detected', []))
    result: Dict[str, Any] = {
        'workspace_name': _loaded_str(item.get('workspace_name', item.get('display_name', '')), ''),
        'active_category_index': _loaded_int(item.get('active_category_index'), 0),
        'active_detected_index': _loaded_int(item.get('active_detected_index'), 0),
        'active_detected_panel_index': _loaded_int(item.get('active_detected_panel_index'), 0),
        'active_favorites_index': _loaded_int(item.get('active_favorites_index'), 0),
        'active_recent_index': _loaded_int(item.get('active_recent_index'), 0),
        'active_fav_panel_index': _loaded_int(item.get('active_fav_panel_index'), 0),
        'pool_mode': _loaded_str(item.get('pool_mode'), 'TABS'),
        'popup_width': _loaded_int(item.get('popup_width'), 200),
        'popup_columns': _loaded_int(item.get('popup_columns'), 5),
        'popup_use_tab_layout': _loaded_bool(item.get('popup_use_tab_layout'), False),
        'popup_show_recent': _loaded_bool(item.get('popup_show_recent'), True),
        'popup_active_tab_index': _loaded_int(item.get('popup_active_tab_index'), 0),
        'floating_height': _loaded_int(item.get('floating_height'), 500),
        'apply_mode': _loaded_str(item.get('apply_mode'), 'FULL'),
        'search_query': _loaded_str(item.get('search_query'), ''),
        'view3d_defaults': {
            'w': _loaded_int(view.get('w', item.get('view3d_default_w')), 500),
            'h': _loaded_int(view.get('h', item.get('view3d_default_h')), 800),
            'open_mode': _loaded_str(view.get('open_mode', item.get('view3d_open_mode')), 'MOUSE'),
            'always_on_top': _loaded_bool(view.get('always_on_top', item.get('view3d_always_on_top')), False),
            'monitor_interval': _loaded_float(view.get('monitor_interval', item.get('view3d_monitor_interval')), 0.5),
            'monitor_size': _loaded_bool(view.get('monitor_size', item.get('view3d_monitor_size')), True),
            'monitor_settings': _loaded_bool(view.get('monitor_settings', item.get('view3d_monitor_settings')), True),
            'remember_position': _loaded_bool(view.get('remember_position', item.get('view3d_remember_position')), True),
        },
        'categories': [_nptl_category_signature(entry) for entry in _nptl_list(item.get('categories'))],
        'floating_panels': [_nptl_floating_panel_signature(entry) for entry in _nptl_list(item.get('floating_panels'))],
        'favorites_tabs': [_nptl_tab_signature(entry) for entry in _nptl_list(item.get('favorites_tabs'))],
        'recent_tabs': [_nptl_recent_signature(entry) for entry in _nptl_list(item.get('recent_tabs'))],
        'favorite_panels': [_nptl_panel_signature(entry) for entry in _nptl_list(item.get('favorite_panels'))],
        'detected_tabs': [_nptl_detected_tab_signature(entry) for entry in _nptl_list(detected_source)],
        'detected_panels': [
            _nptl_panel_signature(entry, detected=True)
            for entry in _nptl_list(item.get('detected_panels'))
        ],
    }
    if include_uuid:
        result['workspace_uuid'] = _loaded_str(item.get('workspace_uuid'), '')
    return result


def _nptl_profile_source(payload: Dict[str, Any]) -> list:
    profiles = payload.get('workspace_profiles') if isinstance(payload, dict) else None
    if isinstance(profiles, dict):
        return [
            dict(value, workspace_name=value.get('workspace_name', key))
            for key, value in profiles.items()
            if isinstance(value, dict)
        ]
    if isinstance(profiles, list):
        return profiles
    workspaces = payload.get('workspaces') if isinstance(payload, dict) else None
    if isinstance(workspaces, dict):
        return [
            dict(value, workspace_name=value.get('workspace_name', key))
            for key, value in workspaces.items()
            if isinstance(value, dict)
        ]
    return []


def _nptl_loaded_graph_signature(
    payload: Dict[str, Any],
    *,
    include_uuid: bool = True,
    include_manager: bool = True,
) -> Dict[str, Any]:
    """Normalize current JSON or serialized NPTL RNA to one value contract."""
    source = payload if isinstance(payload, dict) else {}
    profiles = [
        _nptl_profile_signature(item, include_uuid=include_uuid)
        for item in _nptl_profile_source(source)
    ]
    profiles.sort(key=lambda item: (item.get('workspace_name', ''), item.get('workspace_uuid', '')))
    ui_source = source.get('ui_state') if isinstance(source.get('ui_state'), dict) else source
    ui_state = {
        name: _loaded_bool(
            ui_source.get(name),
            True if name == 'n_panel_state_save_enabled' else False,
        )
        for name in SWS_SECTION_UI_STATE_PROPS
    }
    ptr = source.get('workspace_ptr')
    if isinstance(ptr, dict):
        ptr_name = _loaded_str(ptr.get('name'), '')
    elif isinstance(ptr, str):
        ptr_name = ptr
    else:
        ptr_name = ''
    result: Dict[str, Any] = {
        'workspace_selector': _loaded_str(source.get('workspace_selector'), ''),
        'workspace_ptr_name': ptr_name,
        'ui_state': ui_state,
        'workspace_profiles': profiles,
    }
    if include_manager:
        result.update({
            'workspace_templates': copy.deepcopy(source.get('workspace_templates', {})),
            'manager_rule_matrix': _normalize_manager_matrix(source.get('manager_rule_matrix')),
            'manager_matrix_shape': list(_strict_json.MANAGER_MATRIX_SHAPE),
        })
    return result


def _nptl_rna_state_matches_current_payload(
    current_payload: Dict[str, Any],
    rna_settings_payload: Dict[str, Any],
) -> bool:
    """Verify current/runtime values and central serialized RNA are equivalent."""
    if not isinstance(current_payload, dict) or not isinstance(rna_settings_payload, dict):
        return False
    current_signature = _nptl_loaded_graph_signature(
        current_payload,
        include_uuid=False,
        include_manager=False,
    )
    rna_signature = _nptl_loaded_graph_signature(
        rna_settings_payload,
        include_uuid=False,
        include_manager=False,
    )
    return current_signature == rna_signature


def _verify_loaded_nptl_graph(context, expected: Dict[str, Any]) -> bool:
    try:
        actual = _nptl_current_payload(context)
    except Exception:
        return False
    # Manager state is owned by the Manager's generation-bound public API and is
    # read-only from Smart Workspace.  It is not part of this PropertyGroup
    # clear/repopulate transaction, so a concurrently active Manager must not
    # turn a successful N-panel profile import into a false rollback.
    if _nptl_loaded_graph_signature(
        actual, include_manager=False
    ) != _nptl_loaded_graph_signature(expected, include_manager=False):
        return False
    expected_templates = expected.get('workspace_templates', {}) if isinstance(expected, dict) else {}
    actual_templates = actual.get('workspace_templates', {}) if isinstance(actual, dict) else {}
    return actual_templates == expected_templates


def _apply_loaded_data(
    context,
    data: dict,
    *,
    require_materialized_readback: bool = True,
    use_live_overlay: bool = True,
) -> bool:
    """Transactionally replace the complete N-panel profile graph.

    Blender marks CollectionProperty containers read-only even though their
    items are mutable.  The persistence serializer captures those collections;
    this wrapper snapshots the complete live PropertyGroup before clear/add and
    restores it if any nested collection or readback verification fails.

    Explicit user import is allowed to commit a validated canonical graph that
    cannot be fully projected into the current Screen/Area configuration.  In
    that mode, successful RNA mutation is retained and the materialization gap
    is reported through ``_LAST_NPTL_LOAD_INFO`` instead of being treated as a
    transaction failure.  Startup/load restore keeps the strict readback gate.
    """
    global _NPTL_WORKSPACE_TEMPLATES, _PERSISTED_MANAGER_RULE_MATRIX
    global _LOADING_PROFILE_UUID_BY_NAME, _LAST_NPTL_LOAD_ERROR
    global _LAST_NPTL_LOAD_INFO
    _LAST_NPTL_LOAD_INFO = ''
    if context is None or not isinstance(data, dict):
        _LAST_NPTL_LOAD_ERROR = 'INVALID_LOAD_TRANSACTION_INPUT'
        return False
    if use_live_overlay:
        data = _merge_live_state_overlay(data)
    wm = getattr(context, 'window_manager', None)
    st = getattr(wm, 'nptl_settings', None) if wm is not None else None
    if st is None:
        _LAST_NPTL_LOAD_ERROR = 'NPTL_SETTINGS_NOT_READY'
        return False
    try:
        from .. import persistence as _suite_persistence
        before_rna = _suite_persistence._serialize_owner(st)
    except Exception:
        before_rna = None
    before_templates = copy.deepcopy(_NPTL_WORKSPACE_TEMPLATES)
    before_matrix = copy.deepcopy(_PERSISTED_MANAGER_RULE_MATRIX)
    before_name_map = copy.deepcopy(_LOADING_PROFILE_UUID_BY_NAME)
    try:
        if not _apply_loaded_data_unchecked(context, data):
            raise RuntimeError(_LAST_NPTL_LOAD_ERROR or 'N-panel apply failed')
        if not _verify_loaded_nptl_graph(context, data):
            if require_materialized_readback:
                raise RuntimeError('N-panel apply readback mismatch')
            _LAST_NPTL_LOAD_INFO = 'N_PANEL_RUNTIME_PROJECTION_PARTIAL'
        _LAST_NPTL_LOAD_ERROR = ''
        return True
    except Exception as exc:
        _LAST_NPTL_LOAD_INFO = ''
        _NPTL_WORKSPACE_TEMPLATES = before_templates
        _PERSISTED_MANAGER_RULE_MATRIX = before_matrix
        _LOADING_PROFILE_UUID_BY_NAME = before_name_map
        rollback_ok = False
        if isinstance(before_rna, dict):
            try:
                _push_update_suspend()
                rollback_ok = bool(_suite_persistence._apply_owner(st, before_rna))
            except Exception:
                rollback_ok = False
            finally:
                _pop_update_suspend()
        _LAST_NPTL_LOAD_ERROR = f'{type(exc).__name__}: {exc}'
        if not rollback_ok:
            _LAST_NPTL_LOAD_ERROR += '; rollback failed'
        return False

def load_config_from_file(context):
    """Load only a validated authority and never publish defaults on failure."""
    global _LAST_LOADED_N_PANEL_AUTHORITY, _LAST_LOADED_BASE_DIGEST
    main_path = _refresh_config_file_path()
    try:
        authority = _suite_storage.resolve_n_panel_current_settings(
            main_path,
            repair_primary=True,
        )
    except Exception:
        return False
    if not getattr(authority, 'valid', False) or not isinstance(authority.payload, dict):
        # Strict authority is absent.  Migrate only a recognized and validated
        # pre-contract/older-schema source, then run the strict resolver again.
        # All truly invalid candidates remain diagnostic and RNA defaults are
        # never mirrored or promoted.
        if not _migrate_legacy_n_panel_manager_config(main_path):
            return False
        try:
            _suite_storage.invalidate_central_cache()
            authority = _suite_storage.resolve_n_panel_current_settings(
                main_path,
                repair_primary=True,
            )
        except Exception:
            return False
        if not getattr(authority, 'valid', False) or not isinstance(authority.payload, dict):
            return False
    recovered = _merge_live_state_overlay(authority.payload)
    prepared = _prepare_loaded_workspace_payload(recovered)
    if not _apply_loaded_data(context, prepared, use_live_overlay=False):
        return False
    _LAST_LOADED_N_PANEL_AUTHORITY = copy.deepcopy(authority.payload)
    _LAST_LOADED_BASE_DIGEST = ""
    try:
        from .. import persistence as _suite_persistence
        note = getattr(_suite_persistence, 'note_authoritative_n_panel_load', None)
        if callable(note):
            note(authority.payload)
        else:
            _suite_persistence.mark_deferred_settings_dirty()
    except Exception:
        return False
    return True


def on_update_n_panel_state_save(self, context):
    if _updates_suspended():
        return
    enabled = getattr(self, 'n_panel_state_save_enabled', True)
    enabled = enabled if isinstance(enabled, bool) else True
    try:
        _suite_storage.set_n_panel_state_save_runtime_policy(enabled)
    except Exception:
        pass
    # This RNA callback must remain constant-time.  The complete 6+ MB central
    # graph is committed only at explicit save/file/exit boundaries.
    pending_profiles = set(_LIVE_STATE_PENDING_PROFILES)
    if not enabled:
        _cancel_live_state_write()
    if not _write_live_state_now(context, profile_names=pending_profiles, include_ui=True):
        return
    try:
        from .. import persistence as _suite_persistence
        _suite_persistence.mark_deferred_settings_dirty()
    except Exception:
        pass

    try:
        from .. import persistence as _suite_persistence
        sync_policy = getattr(_suite_persistence, 'sync_continuous_autosave_policy', None)
        if callable(sync_policy):
            sync_policy()
    except Exception:
        pass
    return


def _persist_user_setting_change(context) -> bool:
    """Persist one N-panel edit to a small profile journal."""
    return bool(_schedule_live_state_write(
        context,
        include_profile=True,
        include_ui=True,
    ))


def on_update_setting(self, context):
    del self
    if _updates_suspended():
        return
    _persist_user_setting_change(context)


def on_update_ui_section(self, context):
    del self
    if _updates_suspended():
        return
    _schedule_live_state_write(
        context,
        include_profile=False,
        include_ui=True,
    )


def on_update_workspace_step_reorder(self, context):
    if _updates_suspended():
        return
    try:
        from .. import workspace_step_reorder as _workspace_step_reorder
        sync_fn = getattr(_workspace_step_reorder, 'apply_enabled', None)
        if callable(sync_fn):
            sync_fn(bool(getattr(self, 'workspace_step_reorder_enabled', False)), context=context, save=False)
    except Exception:
        pass
    _persist_user_setting_change(context)


def on_update_synchronize_workspaces(self, context):
    if _updates_suspended():
        return
    desired = bool(getattr(self, 'synchronize_workspaces_enabled', False))
    try:
        from .. import synchronize_workspaces as _synchronize_workspaces
        # Blender may invoke an RNA update callback even when a caller assigns
        # the already-active value.  Reapplying the runtime in that case only
        # refreshes timestamps/JSON and violates ON -> ON idempotence.
        runtime_matches = bool(getattr(_synchronize_workspaces, '_RUNTIME_ENABLED', False)) == desired
        sync_fn = getattr(_synchronize_workspaces, 'apply_enabled', None)
        if callable(sync_fn) and not runtime_matches:
            sync_fn(desired, context=context, save=False)
    except Exception:
        pass
    _persist_user_setting_change(context)


def on_update_floating_window_lock(self, context):
    if _updates_suspended():
        return
    try:
        from .. import floating_window_lock as _floating_window_lock
        sync_fn = getattr(_floating_window_lock, 'apply_enabled', None)
        if callable(sync_fn):
            sync_fn(bool(getattr(self, 'floating_window_lock_enabled', False)), context=context, save=False)
    except Exception:
        pass
    _persist_user_setting_change(context)

def delayed_apply_rename():
    context = bpy.context
    if _panel_rebuild_locked():
        return 0.2
    if context.window_manager and hasattr(context.window_manager, "nptl_settings"):
        prof = _active_profile(context)
        _persist_user_setting_change(context)
        _apply_sidebar_layout(context, prof)
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    return None


def _runtime_core_module_name_matches(module_name: str) -> bool:
    return str(module_name or '') == __name__


def _purge_stale_rename_timers() -> None:
    """Remove only this package's bounded timer lease; never scan modules."""
    _suite_storage.unregister_timer_slot(
        'runtime.core.delayed_apply_rename',
        globals().get('_rename_timer'),
        globals().get('delayed_apply_rename'),
    )


def on_rename_update(self, context):
    if _updates_suspended():
        return

    current_name = str(getattr(self, 'custom_name', '') or '')
    if _is_hidden_tab_label(current_name):
        if current_name:
            self.custom_name = ""
            return

    normalized_name = _normalize_half_width_spaces(current_name)
    if not normalized_name:
        if self.custom_name != "":
            self.custom_name = ""
            return
    elif self.custom_name != normalized_name:
        self.custom_name = normalized_name
        return

    # Renaming must be durable before the delayed, potentially expensive
    # sidebar rebuild.  This keeps the JSON contract synchronous while the
    # actual Panel re-registration remains safely deferred.
    _persist_user_setting_change(context)

    global _rename_timer
    _purge_stale_rename_timers()
    _rename_timer = delayed_apply_rename
    if not _suite_storage.register_timer_slot(
        'runtime.core.delayed_apply_rename',
        _rename_timer,
        first_interval=0.8,
        persistent=False,
    ):
        _rename_timer = None

def on_workspace_select_update(self, context):
    if _updates_suspended():
        return
    ws_key = getattr(self, 'workspace_selector', "")
    ws_name = _ws_name_from_key(ws_key)
    if not ws_name:
        return

    global _workspace_switch_lock
    _workspace_switch_lock += 1
    try:
        _on_workspace_activated(context, ws_name, apply_layout=True)
        _persist_user_setting_change(context)
        _tag_redraw_all_view3d(context)
    finally:
        _workspace_switch_lock = max(0, _workspace_switch_lock - 1)

def on_workspace_ptr_update(self, context):
    if _updates_suspended():
        return
    ws = getattr(self, 'workspace_ptr', None)
    if not ws:
        # Clearing an ID pointer is a real setting change.  Persist the empty
        # stable ID immediately instead of leaving the previous workspace in
        # the canonical JSON snapshot.
        _persist_user_setting_change(context)
        _tag_redraw_all_view3d(context)
        return
    ws_name = getattr(ws, 'name', "")
    if not ws_name:
        return

    try:
        _push_update_suspend()
        try:
            self.workspace_selector = _ws_key_from_name(ws_name)
        finally:
            _pop_update_suspend()
    except:
        pass

    global _workspace_switch_lock
    _workspace_switch_lock += 1
    try:
        _on_workspace_activated(context, ws_name, apply_layout=True)
        _persist_user_setting_change(context)
        _tag_redraw_all_view3d(context)
    finally:
        _workspace_switch_lock = max(0, _workspace_switch_lock - 1)

# =============================================================
# 2. データ構造 (PropertyGroup)
# =============================================================

class NPTL_TabRef(PropertyGroup):
    identifier: StringProperty(update=on_update_setting)
    custom_label: StringProperty(update=on_update_setting)


class NPTL_RecentItem(PropertyGroup):
    identifier: StringProperty(update=on_update_setting)
    custom_label: StringProperty(update=on_update_setting)
    last_used: FloatProperty(default=0.0, update=on_update_setting)

class NPTL_FavoritePanel(PropertyGroup):
    panel_idname: StringProperty(update=on_update_setting)
    label: StringProperty(update=on_update_setting)
    category: StringProperty(update=on_update_setting)


class NPTL_DetectedPanel(PropertyGroup):
    panel_idname: StringProperty(update=on_update_setting)
    label: StringProperty(update=on_update_setting)
    category: StringProperty(update=on_update_setting)
    is_panview: BoolProperty(default=False, update=on_update_setting)


class NPTL_FloatingPanelEntry(PropertyGroup):
    key: StringProperty(update=on_update_setting)
    panel_idname: StringProperty(update=on_update_setting)
    label: StringProperty(update=on_update_setting)
    category: StringProperty(update=on_update_setting)

    default_w: IntProperty(
        name="Default Width",
        default=500,
        min=200,
        max=4000,
        description="Default width for a newly opened floating View3D window. Increase this when the panel feels cramped.",
        update=on_update_setting,
    )
    default_h: IntProperty(
        name="Default Height",
        default=800,
        min=200,
        max=4000,
        description="Default height for a newly opened floating View3D window. Increase this when the panel needs more vertical space.",
        update=on_update_setting,
    )

    open_mode: bpy.props.EnumProperty(
        name="Open Mode",
        description="Choose where the floating View3D window appears when you open it. Mouse Center is easiest for beginners, Last Position reopens where you last left it, Pinned Position keeps a fixed spot, and Follow Mouse keeps chasing the cursor while open.",
        items=[
            ('MOUSE', "Mouse Center", ""),
            ('LAST', "Last Position", ""),
            ('PIN', "Pinned Position", ""),
            ('FOLLOW', "Follow Mouse", ""),
        ],
        default='MOUSE',
        update=on_update_setting,
    )
    always_on_top: BoolProperty(
        name="Always On Top",
        default=False,
        description="Keep the floating View3D window above other application windows when possible. Useful for reference-style side panels.",
        update=on_update_setting,
    )
    monitor_interval: FloatProperty(
        name="Monitor Interval (sec)",
        default=0.5,
        min=0.1,
        max=5.0,
        description="How often the floating window checks size, position, and always-on-top settings. Lower values react faster but check more often.",
        update=on_update_setting,
    )
    monitor_size: BoolProperty(
        name="Monitor Size",
        default=True,
        description="Keep saving the floating window size while you resize it, so the next open can reuse the latest size.",
        update=on_update_setting,
    )
    monitor_settings: BoolProperty(
        name="Monitor Settings",
        default=True,
        description="Keep applying runtime settings such as Always On Top while the floating window is open.",
        update=on_update_setting,
    )
    remember_position: BoolProperty(
        name="Remember Position",
        default=True,
        description="Remember the last screen position of the floating window so it can reopen in a familiar place.",
        update=on_update_setting,
    )

    last_x: IntProperty(default=-1, update=on_update_setting)
    last_y: IntProperty(default=-1, update=on_update_setting)
    last_w: IntProperty(default=0, update=on_update_setting)
    last_h: IntProperty(default=0, update=on_update_setting)

    pinned_x: IntProperty(default=-1, update=on_update_setting)
    pinned_y: IntProperty(default=-1, update=on_update_setting)


class NPTL_CategoryItem(PropertyGroup):
    name: StringProperty(name="Name", default="New Category", update=on_update_setting)
    tabs: CollectionProperty(type=NPTL_TabRef)
    active_tab_index: IntProperty(default=0, update=on_update_setting)

class NPTL_DetectedTab(PropertyGroup):
    identifier: StringProperty(update=on_update_setting)
    name: StringProperty(update=on_update_setting)
    show: BoolProperty(
        name="Show", 
        default=True, 
        description="Show or hide this detected Sidebar tab in the Smart Tools launcher. Turn this off when you want to keep the tab available in Blender but remove it from your curated launcher.", 
        update=on_update_setting
    )
    custom_name: StringProperty(
        name="Rename", 
        default="", 
        description="Rename the detected tab for the Smart Tools launcher. The real Sidebar tab takes this name when you press Apply Rename & Order. Leave empty to keep the original name.", 
        update=on_rename_update 
    )
    is_pinned: BoolProperty(
        name="Pin", 
        default=False, 
        description="Pin this tab using Blender's standard N-panel header pin behavior, the same kind of pin available from a panel header right-click menu. Use this when you want the panels in this tab to remain visible with other tabs.", 
        update=on_update_setting
    )
    original_category: StringProperty(default="", update=on_update_setting)

class NPTL_WorkspaceProfile(PropertyGroup):
    workspace_name: StringProperty(default="", update=on_update_setting)
    categories: CollectionProperty(type=NPTL_CategoryItem)
    active_category_index: IntProperty(default=0, update=on_update_setting)
    detected_tabs: CollectionProperty(type=NPTL_DetectedTab)
    active_detected_index: IntProperty(default=0, update=on_update_setting)

    # Pool selector (All Tabs / Panel List)
    pool_mode: bpy.props.EnumProperty(
        name="Pool",
        description="Choose what the lower management list shows. 'All Tabs' is for organizing detected Sidebar tabs, while 'Panel List' is for picking individual panels or creating floating panel entries.",
        items=[('TABS', "All Tabs", ""), ('PANELS', "Panel List", "")],
        default='TABS',
        update=on_update_setting,
    )
    detected_panels: CollectionProperty(type=NPTL_DetectedPanel)
    active_detected_panel_index: IntProperty(default=0, update=on_update_setting)

    # Floating panel entries (View3D)
    floating_panels: CollectionProperty(type=NPTL_FloatingPanelEntry)
    popup_width: IntProperty(
        name="Column Width",
        default=200,
        min=50,
        max=800,
        description="Width of a single launcher column. Increase this when button labels are cut off or when you use long custom names.",
        update=on_update_setting,
    )
    popup_columns: IntProperty(
        name="Popup Columns",
        default=5,
        min=1,
        max=20,
        description="How many columns the popup launcher uses. More columns show more tools at once but make the popup wider.",
        update=on_update_setting,
    )
    popup_use_tab_layout: BoolProperty(
        name="Tab Layout Mode",
        default=False,
        description="Display categories as tabs across the top of the popup instead of separate boxes. Useful when you have many categories and want a cleaner compact launcher.",
        update=on_update_setting,
    )
    popup_show_recent: BoolProperty(
        name="Show Recent Tabs",
        default=True,
        description="Show the Recent section in the launcher so you can quickly reopen tabs you used lately.",
        update=on_update_setting,
    )
    popup_active_tab_index: IntProperty(default=0, update=on_update_setting)
    floating_height: IntProperty(
        name="Floating Height", default=500, min=50, max=2000, 
        description="Target height for the dedicated floating Sidebar window opened from Smart Tools. Increase this when tall panels are being clipped.",
        update=on_update_setting
    )


    # Template defaults for new Floating Panel entries (View3D)
    view3d_default_w: IntProperty(
        name="Default Width",
        default=500,
        min=200,
        max=4000,
        description="Default width used when Smart Tools creates a new floating View3D panel window.",
        update=on_update_setting,
    )
    view3d_default_h: IntProperty(
        name="Default Height",
        default=800,
        min=200,
        max=4000,
        description="Default height used when Smart Tools creates a new floating View3D panel window.",
        update=on_update_setting,
    )
    view3d_open_mode: bpy.props.EnumProperty(
        name="Open Mode",
        description="Choose the default placement rule for newly created floating View3D panel windows. Mouse Center is the simplest starting point.",
        items=[
            ('MOUSE', "Mouse Center", ""),
            ('LAST', "Last Position", ""),
            ('PIN', "Pinned Position", ""),
            ('FOLLOW', "Follow Mouse", ""),
        ],
        default='MOUSE',
        update=on_update_setting,
    )
    view3d_always_on_top: BoolProperty(
        name="Always On Top",
        default=False,
        description="Keep new floating View3D panel windows above other windows when possible.",
        update=on_update_setting,
    )
    view3d_monitor_interval: FloatProperty(
        name="Monitor Interval (sec)",
        default=0.5,
        min=0.1,
        max=5.0,
        description="How often Smart Tools checks and updates floating View3D window state while it is open.",
        update=on_update_setting,
    )
    view3d_monitor_size: BoolProperty(
        name="Monitor Size",
        default=True,
        description="Save size changes made to floating View3D windows so future openings can reuse the latest size.",
        update=on_update_setting,
    )
    view3d_monitor_settings: BoolProperty(
        name="Monitor Settings",
        default=True,
        description="Keep applying runtime window settings such as Always On Top while the floating View3D window is open.",
        update=on_update_setting,
    )
    view3d_remember_position: BoolProperty(
        name="Remember Position",
        default=True,
        description="Save the last screen position of floating View3D windows and reuse it the next time they open.",
        update=on_update_setting,
    )


    # --- Launcher enhancements ---
    search_query: StringProperty(
        name="Search",
        default="",
        description="Filter items shown in the launcher or management lists. Type part of a tab or panel name to narrow the list.",
        update=on_update_setting
    )
    favorites_tabs: CollectionProperty(type=NPTL_TabRef)
    active_favorites_index: IntProperty(default=0, update=on_update_setting)
    recent_tabs: CollectionProperty(type=NPTL_RecentItem)
    active_recent_index: IntProperty(default=0, update=on_update_setting)
    favorite_panels: CollectionProperty(type=NPTL_FavoritePanel)
    active_fav_panel_index: IntProperty(default=0, update=on_update_setting)

    # Safety / compatibility options
    apply_mode: bpy.props.EnumProperty(
        name="Apply Mode",
        description="Choose how strongly Smart Tools changes the real N-panel. Use Full for complete control, and switch to safer modes if another add-on conflicts with tab renaming or ordering.",
        items=[
            ('FULL', "Full (Category + Order + Hide)", "Apply all features: category remap, ordering anchors, and hide/show"),
            ('CAT_ONLY', "Category Only", "Only remap categories (no anchors for ordering)"),
            ('ORDER_ONLY', "Order Only", "Only reorder tabs via anchors (no category remap)"),
            ('SAFE', "Safe (Minimal)", "Minimal changes: only pin-follow + launcher navigation"),
        ],
        default='FULL',
        update=on_update_setting,
    )

class NPTL_Settings(PropertyGroup):
    n_panel_state_save_enabled: BoolProperty(
        name="N-panel State Save",
        description="When enabled, every Smart Workspace setting change and imported preset is written immediately through strict atomic JSON and restored once after Blender starts. No periodic timer or polling is used.",
        default=_suite_storage.n_panel_state_save_enabled(True),
        update=on_update_n_panel_state_save,
    )
    show_always_on_toggles: BoolProperty(
        name="Always-on Toggles",
        description="Open or close the centralized always-on toggle group at the top of the Smart Workspace N-panel. The group is closed by default and this UI state is saved immediately.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_always_on_toggles: BoolProperty(
        name="Always-on Toggles Section",
        description="Open or close the Always-on Toggles section in the Smart Workspace N-panel. This affects only the UI display state; it does not enable background tools.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_workspace_manager: BoolProperty(
        name="Workspace Manager Section",
        description="Open or close the bundled Workspace Manager section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_n_panel_manager: BoolProperty(
        name="N-panel Manager Section",
        description="Open or close the N-panel Manager section that contains workspace launcher, category, panel pool, settings, and preset I/O controls.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_viewport_optimization: BoolProperty(
        name="Viewport Optimization Section",
        description="Open or close the Viewport Optimization section in the Smart Workspace N-panel. This affects only the section display state; the optimizer itself is controlled by its own toggle.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_workspace_launcher: BoolProperty(
        name="Workspace & Launcher Section",
        description="Open or close the Workspace & Launcher section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_categories: BoolProperty(
        name="Categories Section",
        description="Open or close the Categories section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_panel_pool: BoolProperty(
        name="Panel Pool Section",
        description="Open or close the Panel Pool section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_smart_tools_settings: BoolProperty(
        name="Settings Section",
        description="Open or close the Settings section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_presets_io: BoolProperty(
        name="IO Section",
        description="Open or close the IO section in the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_integrated_tools: BoolProperty(
        name="Other Tools Section",
        description="Open or close the Other Tools group at the bottom of the Smart Workspace N-panel.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_panview: BoolProperty(
        name="2D Pan View Section",
        description="Open or close the 2D Pan View section inside Other Tools.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_local_ui_toggle: BoolProperty(
        name="Viewport UI Toggle Section",
        description="Open or close the Viewport UI Toggle section inside Other Tools.",
        default=False,
        update=on_update_ui_section,
    )
    ui_show_section_workspace_step_reorder: BoolProperty(
        name="Workspace Step Reorder Section",
        description="Open or close the Workspace Step Reorder section inside Other Tools. This only changes the section display; use the enable/disable buttons inside the section to add or remove the workspace tab menu commands.",
        default=False,
        update=on_update_ui_section,
    )
    workspace_step_reorder_enabled: BoolProperty(
        name="Workspace Step Reorder",
        description="Enable or disable the workspace tab right-click menu commands that move the clicked workspace one tab forward or backward. The setting is saved immediately and remains after Blender restarts or another scene is opened.",
        default=False,
        update=on_update_workspace_step_reorder,
    )
    ui_show_section_synchronize_workspaces: BoolProperty(
        name="Synchronize Workspaces Section",
        description="Open or close the Synchronize Workspaces section inside Other Tools. This only changes the section display; use the enable/disable buttons inside the section to start or stop workspace 3D View synchronization.",
        default=False,
        update=on_update_ui_section,
    )
    synchronize_workspaces_enabled: BoolProperty(
        name="Synchronize Workspaces",
        description="Enable or disable Smart Workspace Suite synchronization of 3D View state between workspace tabs. When enabled, the active 3D View angle, distance, shading, and optional overlay settings can follow as you switch workspaces; the setting is saved immediately and restored on restart or file load.",
        default=False,
        update=on_update_synchronize_workspaces,
    )
    ui_show_section_floating_window_lock: BoolProperty(
        name="Floating Window Lock Section",
        description="Open or close the Floating Window Lock section inside Other Tools. This only changes the section display; use the enable/disable buttons inside the section to keep detached/floating window editor contents stable while switching workspace tabs.",
        default=False,
        update=on_update_ui_section,
    )
    floating_window_lock_enabled: BoolProperty(
        name="Floating Window Lock",
        description="Enable or disable protection for detached/floating Blender windows. When enabled, non-active floating window editor contents such as 3D View, Outliner, Image Editor, and Node Editor are captured and restored after workspace tab switches so they do not follow the active workspace layout. The setting is saved immediately and restored after Blender restarts.",
        default=False,
        update=on_update_floating_window_lock,
    )
    workspace_ptr: PointerProperty(
        name="Workspace",
        type=bpy.types.WorkSpace,
        description="Workspace whose Smart Tools profile you want to inspect or edit.",
        update=on_workspace_ptr_update,
    )
    workspace_selector: StringProperty(default="", update=on_workspace_select_update)
    workspace_profiles: CollectionProperty(type=NPTL_WorkspaceProfile)



# =============================================================
# 2.5  Launcher data helpers (Favorites / Recent / Panels)
# =============================================================

_RECENT_MAX = 20
_PRESET_BACKUP_MAX = 10
_BLEND_TEXT_NAME = "NPTL_Config.json"

def _now_ts() -> float:
    import time
    return float(time.time())

def _touch_recent(context, tab_identifier: str, custom_label: str = ""):
    prof = _active_profile(context)
    if not prof:
        return
    ts = _now_ts()
    # remove existing
    for i, it in enumerate(list(prof.recent_tabs)):
        if it.identifier == tab_identifier:
            prof.recent_tabs.remove(i)
            break
    item = prof.recent_tabs.add()
    item.identifier = tab_identifier
    item.custom_label = custom_label or tab_identifier
    item.last_used = ts
    # keep sorted by last_used desc
    items = sorted(list(prof.recent_tabs), key=lambda x: x.last_used, reverse=True)
    prof.recent_tabs.clear()
    for it in items[:_RECENT_MAX]:
        ni = prof.recent_tabs.add()
        ni.identifier = it.identifier
        ni.custom_label = it.custom_label
        ni.last_used = it.last_used
    _persist_user_setting_change(context)



# =============================================================
#  Floating Panel pool helpers
# =============================================================

def _gen_fp_key() -> str:
    try:
        import time, random
        return f"{int(time.time()*1000):x}_{random.getrandbits(32):x}"
    except Exception:
        return "fp"

def _find_fp_entry(prof, key: str):
    if not prof or not key:
        return None
    for e in getattr(prof, 'floating_panels', []):
        if getattr(e, 'key', '') == key:
            return e
    return None

def _scan_view3d_panels_for_pool():
    seen = set()
    out = []
    for cls in _get_all_view3d_panels(getattr(bpy, "context", None)):
        pid = _panel_type_id(cls)
        if not pid or pid.startswith(ANCHOR_PREFIX):
            continue
        if pid in seen:
            continue
        seen.add(pid)
        label = getattr(cls, 'bl_label', '') or pid
        cat = _get_panel_category(cls)
        out.append((pid, label, cat))
    out.sort(key=lambda x: (x[1].lower(), x[0].lower()))
    return out


def _scan_floating_area_types_for_pool():
    # Blender editor/area types that make sense to float as a window.
    # Keep list conservative.
    return [
        ("VIEW_3D", "3D View"),
        ("OUTLINER", "Outliner"),
        ("PROPERTIES", "Properties"),
        ("NODE_EDITOR", "Node Editor"),
        ("IMAGE_EDITOR", "Image Editor"),
        ("TEXT_EDITOR", "Text Editor"),
        ("GRAPH_EDITOR", "Graph Editor"),
        ("DOPESHEET_EDITOR", "Dope Sheet"),
        ("NLA_EDITOR", "NLA Editor"),
        ("SEQUENCE_EDITOR", "Video Sequencer"),
        ("CLIP_EDITOR", "Movie Clip Editor"),
        ("SPREADSHEET", "Spreadsheet"),
        ("FILE_BROWSER", "File Browser"),
        ("CONSOLE", "Console"),
    ]

def _refresh_detected_panels_logic(context, profile=None, *, save: bool = False, verified_user_change: bool = False):
    if not hasattr(context.window_manager, 'nptl_settings'):
        return
    prof = profile or _active_profile(context)
    if not prof:
        return

    _push_update_suspend()
    try:
        prof.detected_panels.clear()
        # ⑤ Always show 2D_Pan_View at top
        pv = prof.detected_panels.add()
        pv.panel_idname = '2D_Pan_View'
        pv.label = '2D Pan View'
        pv.category = ''
        pv.is_panview = True

        for area_type, label in _scan_floating_area_types_for_pool():
            dp = prof.detected_panels.add()
            dp.panel_idname = AREA_PREFIX + area_type
            dp.label = label
            dp.category = ''
            dp.is_panview = False

        prof.active_detected_panel_index = min(prof.active_detected_panel_index, max(0, len(prof.detected_panels) - 1))
    finally:
        _pop_update_suspend()

    if save:
        save_config_to_file(context, verified_user_change=bool(verified_user_change))
def _is_favorite_tab(prof, tab_identifier: str) -> bool:
    for it in prof.favorites_tabs:
        if it.identifier == tab_identifier:
            return True
    return False

def _toggle_favorite_tab(context, tab_identifier: str, label: str = ""):
    prof = _active_profile(context)
    tab_identifier = _normalize_tab_identifier(tab_identifier)
    if not prof or _is_hidden_sidebar_tab_identifier(tab_identifier):
        return
    for i, it in enumerate(list(prof.favorites_tabs)):
        if it.identifier == tab_identifier:
            prof.favorites_tabs.remove(i)
            _persist_user_setting_change(context)
            return
    ni = prof.favorites_tabs.add()
    ni.identifier = tab_identifier
    ni.custom_label = label or tab_identifier
    _persist_user_setting_change(context)

def _get_panels_in_category(cat: str):
    cat = _display_tab_identifier(cat)
    if not cat or _is_hidden_sidebar_tab_identifier(cat):
        return []
    panels = []
    for cls in _get_all_view3d_panels(getattr(bpy, "context", None)):
        if _panel_type_id(cls).startswith(ANCHOR_PREFIX):
            continue
        if _get_panel_category(cls) == cat:
            pid = _panel_type_id(cls)
            lbl = getattr(cls, "bl_label", pid)
            if pid and not _is_hidden_internal_panel_id(pid):
                panels.append((pid, lbl))
    panels.sort(key=lambda x: (x[1].lower(), x[0].lower()))
    return panels

def _toggle_favorite_panel(context, panel_idname: str, label: str, category: str):
    prof = _active_profile(context)
    if not prof or _is_hidden_internal_panel_id(panel_idname) or _is_hidden_sidebar_tab_identifier(category):
        return
    for i, it in enumerate(list(prof.favorite_panels)):
        if it.panel_idname == panel_idname:
            prof.favorite_panels.remove(i)
            _persist_user_setting_change(context)
            return
    ni = prof.favorite_panels.add()
    ni.panel_idname = panel_idname
    ni.label = label
    ni.category = category
    _persist_user_setting_change(context)

# =============================================================
# 2.6  External storage helpers and optional .blend storage
# =============================================================

# N-panel preset save/load/delete was removed. The IO section now uses only
# explicit JSON export/import operators.
def _addon_config_dir():
    d = _extension_user_root()
    os.makedirs(d, exist_ok=True)
    return d


def _write_blend_text(data: dict):
    try:
        txt = bpy.data.texts.get(_BLEND_TEXT_NAME) or bpy.data.texts.new(_BLEND_TEXT_NAME)
        txt.clear()
        txt.write(json.dumps(data, ensure_ascii=False, indent=2))
    except Exception:
        pass

def _read_blend_text():
    try:
        txt = bpy.data.texts.get(_BLEND_TEXT_NAME)
        if not txt:
            return None
        return json.loads(txt.as_string())
    except Exception:
        return None

# =============================================================
# 3. コアロジック (Panel操作)
# =============================================================

def _get_all_view3d_panels(context=None):
    panels = []
    for cls in _registered_panel_types():
        if _panel_is_visible_for_workspace_scan(cls, context=context):
            panels.append(cls)
    return panels


def _get_all_registered_view3d_sidebar_panels():
    panels = []
    for cls in _registered_panel_types():
        if _panel_is_view3d_sidebar_candidate(cls):
            panels.append(cls)
    return panels


def _get_all_registered_sidebar_panels():
    """Return every registered editor Sidebar panel, without evaluating poll."""
    return [cls for cls in _registered_panel_types() if _panel_is_sidebar_candidate(cls)]


def _iter_view3d_ui_regions(context=None):
    ctx = context or getattr(bpy, "context", None)
    yielded = set()

    def _yield_from_window(win):
        try:
            screen = getattr(win, "screen", None)
            areas = getattr(screen, "areas", ()) if screen is not None else ()
        except Exception:
            areas = ()
        for area in areas:
            try:
                if getattr(area, "type", "") != "VIEW_3D":
                    continue
                region = _get_ui_region(area)
                if region is None:
                    continue
                key = (area.as_pointer(), region.as_pointer())
                if key in yielded:
                    continue
                yielded.add(key)
                yield region
            except Exception:
                continue

    if ctx is not None:
        try:
            win = getattr(ctx, "window", None)
            if win is not None:
                yield from _yield_from_window(win)
        except Exception:
            pass
        try:
            wm = getattr(ctx, "window_manager", None) or getattr(bpy.context, "window_manager", None)
            for win in getattr(wm, "windows", ()) or ():
                yield from _yield_from_window(win)
        except Exception:
            pass


def _iter_sidebar_ui_regions(context=None):
    ctx = context or getattr(bpy, "context", None)
    yielded = set()
    wm = getattr(ctx, "window_manager", None) if ctx is not None else None
    for win in tuple(getattr(wm, "windows", ()) or ()):
        screen = getattr(win, "screen", None)
        for area in tuple(getattr(screen, "areas", ()) or ()):
            try:
                region = _get_ui_region(area)
                if region is None:
                    continue
                key = (area.as_pointer(), region.as_pointer())
                if key in yielded:
                    continue
                yielded.add(key)
                yield region
            except Exception:
                continue


def _scan_active_sidebar_tab_categories(context=None) -> Set[str]:
    tabs = set()
    for region in _iter_sidebar_ui_regions(context):
        try:
            cat = _display_tab_identifier(getattr(region, "active_panel_category", ""))
        except Exception:
            cat = ""
        if cat in _SIDEBAR_APPLIED_NAMES.values():
            continue  # An applied name, listed under the tab's own identifier.
        if cat and not _is_hidden_sidebar_tab_identifier(cat):
            tabs.add(cat)
    return tabs


def _get_panel_category(cls):
    if _is_hidden_internal_panel_class(cls):
        return EMPTY_TAB_CAT
    if hasattr(cls, "nptl_original_category"):
        original = _display_tab_identifier(getattr(cls, "nptl_original_category", ""))
        return original or EMPTY_TAB_CAT
    cat = getattr(cls, "bl_category", "")
    if _is_hidden_sidebar_tab_identifier(cat):
        return EMPTY_TAB_CAT
    cat = _display_tab_identifier(cat)
    if not cat:
        return DEFAULT_CAT_NAME
    return cat

def _scan_all_sidebar_tabs(context=None):
    # Panel registration is mutable for the lifetime of Blender.  All Tabs is an
    # explicit inventory operation, so rebuild from the live RNA/Python class
    # registration surfaces instead of returning an earlier partial snapshot.
    _invalidate_panel_discovery_cache()
    tabs = set()

    def _add_panel_category(cls):
        if getattr(cls, "bl_idname", "").startswith(ANCHOR_PREFIX):
            return
        cat = _get_panel_category(cls)
        if not cat or cat == EMPTY_TAB_CAT or _is_hidden_sidebar_tab_identifier(cat):
            return
        tabs.add(cat)

    # Scan all registered editor Sidebar panels.  Poll is intentionally not
    # evaluated: All Tabs is an inventory, so categories hidden by the current
    # workspace, editor subtype, mode, or selection must still be available.
    for cls in _get_all_registered_sidebar_panels():
        _add_panel_category(cls)

    tabs.update(_scan_active_sidebar_tab_categories(context))
    tabs.add(SMART_WORKSPACE_TAB_NAME)
    result = sorted(list(tabs))
    try:
        _PANEL_CATEGORY_CACHE["tabs"] = tuple(result)
    except Exception:
        pass
    return result


def _tab_identifier_is_valid_for_profile(prof, ident: str, current_set: Set[str]) -> bool:
    ident = _normalize_tab_identifier(ident)
    if not ident or _is_hidden_sidebar_tab_identifier(ident):
        return False
    if ident == SMART_WORKSPACE_TAB_NAME:
        return True
    if ident.startswith(FP_PREFIX):
        key = ident[len(FP_PREFIX):]
        return _find_fp_entry(prof, key) is not None
    if ident.startswith(PV_PREFIX):
        return True
    return ident in current_set


def _is_custom_tab_name_value(custom_name: str, ident: str, name: str = "") -> bool:
    cn = (custom_name or "").strip()
    ident = (ident or "").strip()
    name = (name or "").strip()
    if not cn:
        return False
    return cn != ident and cn != name


def _snapshot_detected_tabs(prof):
    snapshots = {}
    ordered_ids = []
    deduped = 0

    for item in getattr(prof, "detected_tabs", []):
        ident = _normalize_tab_identifier(getattr(item, "identifier", "") or "")
        if not ident or _is_hidden_sidebar_tab_identifier(ident):
            continue

        # Refresh, Cleanup and the start-up / file-load rescan rebuild the list
        # from these snapshots, so the user's tab rename is carried over here;
        # dropping it erased every rename on each rescan and the next save wrote
        # the loss to disk.  name and original_category stay derived from the
        # stable identifier.
        name = _display_tab_label(ident)
        try:
            custom_name = _display_tab_label(getattr(item, "custom_name", "") or "")
        except Exception:
            custom_name = ""
        original_category = ident

        if ident not in snapshots:
            snapshots[ident] = {
                "identifier": ident,
                "name": name,
                "show": bool(getattr(item, "show", True)),
                "custom_name": custom_name,
                "is_pinned": bool(getattr(item, "is_pinned", False)),
                "original_category": original_category,
            }
            ordered_ids.append(ident)
            continue

        deduped += 1
        snap = snapshots[ident]
        snap["show"] = bool(snap.get("show", True)) or bool(getattr(item, "show", True))
        snap["is_pinned"] = bool(snap.get("is_pinned", False)) or bool(getattr(item, "is_pinned", False))

        # Keep the first stable duplicate snapshot; a rename found only on a
        # duplicate is still kept.
        if not snap.get("custom_name"):
            try:
                snap["custom_name"] = _display_tab_label(getattr(item, "custom_name", "") or "")
            except Exception:
                pass

    return snapshots, ordered_ids, deduped


def _rebuild_tabref_collection(tab_refs, entries):
    tab_refs.clear()
    for entry in entries:
        item = tab_refs.add()
        item.identifier = entry.get("identifier", "")
        item.custom_label = entry.get("custom_label", "")


def _rebuild_recent_collection(recent_refs, entries):
    recent_refs.clear()
    for entry in entries:
        item = recent_refs.add()
        item.identifier = entry.get("identifier", "")
        item.custom_label = entry.get("custom_label", "")
        item.last_used = float(entry.get("last_used", 0.0) or 0.0)


def _prune_profile_tab_references(prof, current_set: Set[str]):
    stats = {
        "pruned_category_refs": 0,
        "pruned_favorites": 0,
        "pruned_recent": 0,
    }

    for cat in getattr(prof, "categories", []):
        keep = []
        removed = 0
        for item in list(getattr(cat, "tabs", [])):
            ident = getattr(item, "identifier", "")
            if _tab_identifier_is_valid_for_profile(prof, ident, current_set):
                keep.append({
                    "identifier": ident,
                    "custom_label": getattr(item, "custom_label", ""),
                })
            else:
                removed += 1
        if removed:
            _rebuild_tabref_collection(cat.tabs, keep)
            stats["pruned_category_refs"] += removed
        try:
            cat.active_tab_index = min(getattr(cat, "active_tab_index", 0), max(0, len(cat.tabs) - 1))
        except Exception:
            pass

    fav_keep = []
    fav_removed = 0
    for item in list(getattr(prof, "favorites_tabs", [])):
        ident = getattr(item, "identifier", "")
        if _tab_identifier_is_valid_for_profile(prof, ident, current_set):
            fav_keep.append({
                "identifier": ident,
                "custom_label": getattr(item, "custom_label", ""),
            })
        else:
            fav_removed += 1
    if fav_removed and hasattr(prof, "favorites_tabs"):
        _rebuild_tabref_collection(prof.favorites_tabs, fav_keep)
        stats["pruned_favorites"] = fav_removed

    recent_keep = []
    recent_removed = 0
    for item in list(getattr(prof, "recent_tabs", [])):
        ident = getattr(item, "identifier", "")
        if _tab_identifier_is_valid_for_profile(prof, ident, current_set):
            recent_keep.append({
                "identifier": ident,
                "custom_label": getattr(item, "custom_label", ""),
                "last_used": getattr(item, "last_used", 0.0),
            })
        else:
            recent_removed += 1
    if recent_removed and hasattr(prof, "recent_tabs"):
        _rebuild_recent_collection(prof.recent_tabs, recent_keep)
        stats["pruned_recent"] = recent_removed

    return stats


def _refresh_detected_tabs_logic(context, profile=None, prune_references=False, save=False, verified_user_change=False, *, current_tabs=None):
    if not hasattr(context.window_manager, "nptl_settings"):
        return {"changed": False, "added": 0, "removed": 0, "deduped": 0, "pruned_category_refs": 0, "pruned_favorites": 0, "pruned_recent": 0}

    prof = profile or _active_profile(context)
    if not prof:
        return {"changed": False, "added": 0, "removed": 0, "deduped": 0, "pruned_category_refs": 0, "pruned_favorites": 0, "pruned_recent": 0}

    if current_tabs is None:
        current_tabs = _scan_all_sidebar_tabs(context)
    current_set = set(current_tabs)
    existing_map, previous_order, deduped = _snapshot_detected_tabs(prof)

    ordered_ids = []
    seen = set()
    removed = 0
    for ident in previous_order:
        if ident in current_set and ident not in seen:
            ordered_ids.append(ident)
            seen.add(ident)
        elif ident not in current_set:
            removed += 1

    added = 0
    for ident in current_tabs:
        if ident in seen:
            continue
        ordered_ids.append(ident)
        seen.add(ident)
        added += 1

    stats = {
        "changed": bool(added or removed or deduped),
        "added": added,
        "removed": removed,
        "deduped": deduped,
        "pruned_category_refs": 0,
        "pruned_favorites": 0,
        "pruned_recent": 0,
    }

    _push_update_suspend()
    try:
        prof.detected_tabs.clear()
        for ident in ordered_ids:
            snap = existing_map.get(ident, None)
            item = prof.detected_tabs.add()
            item.identifier = ident
            item.name = _display_tab_label((snap.get("name", ident) if snap else ident) or ident) or _display_tab_label(ident)
            item.show = bool(snap.get("show", True)) if snap else True
            item.custom_name = _display_tab_label((snap.get("custom_name", "") if snap else "") or "")
            item.is_pinned = bool(snap.get("is_pinned", False)) if snap else False
            item.original_category = ((snap.get("original_category", ident) if snap else ident) or ident).strip() or ident

        try:
            prof.active_detected_index = min(getattr(prof, "active_detected_index", 0), max(0, len(prof.detected_tabs) - 1))
        except Exception:
            pass

        if prune_references:
            pruned = _prune_profile_tab_references(prof, current_set)
            for key, value in pruned.items():
                stats[key] = int(value)
            if any(pruned.values()):
                stats["changed"] = True
    finally:
        _pop_update_suspend()

    if save and stats["changed"]:
        profile_name = str(getattr(prof, "workspace_name", "") or "")
        save_config_to_file(
            context,
            verified_user_change=bool(verified_user_change),
            profile_names={profile_name} if profile_name else None,
        )
    return stats


def _refresh_all_profiles_detected_tabs_logic(context, prune_references=False, save=False, verified_user_change=False):
    st = getattr(getattr(context, "window_manager", None), "nptl_settings", None)
    if not st:
        return {"changed": False, "added": 0, "removed": 0, "deduped": 0, "pruned_category_refs": 0, "pruned_favorites": 0, "pruned_recent": 0}

    try:
        for ws in bpy.data.workspaces:
            _get_or_create_profile(st, ws.name)
    except Exception:
        pass

    totals = {"changed": False, "added": 0, "removed": 0, "deduped": 0, "pruned_category_refs": 0, "pruned_favorites": 0, "pruned_recent": 0}
    # B58_17_SINGLE_INVENTORY_20261024: この更新中は全プロファイルで同じ登録状態を使う。
    current_tabs = tuple(_scan_all_sidebar_tabs(context)) if st.workspace_profiles else ()
    for prof in st.workspace_profiles:
        stats = _refresh_detected_tabs_logic(context, prof, prune_references=prune_references, save=False, current_tabs=current_tabs)
        if stats.get("changed"):
            totals["changed"] = True
        for key in ("added", "removed", "deduped", "pruned_category_refs", "pruned_favorites", "pruned_recent"):
            totals[key] += int(stats.get(key, 0) or 0)

    if save and totals["changed"]:
        changed_names = {
            str(getattr(prof, "workspace_name", "") or "")
            for prof in st.workspace_profiles
            if str(getattr(prof, "workspace_name", "") or "")
        }
        save_config_to_file(
            context,
            verified_user_change=bool(verified_user_change),
            profile_names=changed_names,
        )
    return totals

def _make_anchor_panel(cat_name, index):
    cls_name = f"{ANCHOR_PREFIX}{index:03d}"
    try:
        live = getattr(bpy.types, cls_name)
    except AttributeError:
        live = None
    except Exception:
        live = object()
    if live is not None:
        # Legacy anchors are disabled.  Never adopt a same-name live Panel from
        # another generation or third party.
        try:
            from .. import runtime_ledger as _runtime_ledger
            _runtime_ledger.mark_restart_required('LEGACY_ANCHOR_CLASS_CONFLICT:' + cls_name)
        except Exception:
            pass
        return None

    def draw(self, context): pass
    attrs = {
        "bl_idname": cls_name,
        "bl_label": "",
        "bl_space_type": "VIEW_3D",
        "bl_region_type": "UI",
        "bl_category": 'Smart Workspace',
        "bl_options": {'HIDE_HEADER'},
        "draw": draw
    }
    return type(cls_name, (Panel,), attrs)

def _purge_all_anchors():
    # No name/prefix scan and no live RNA unregister. Exact ledger owns cleanup.
    global _anchor_classes
    _anchor_classes = []
    return None

def _apply_sidebar_layout(context, profile=None):
    # Standard N-panel mode: never unregister/re-register Blender or third-party
    # Panel classes to force category order/renaming. That legacy SmartTools
    # behavior is unsafe during VIEW_3D sidebar layout and can crash Blender.
    try:
        _purge_all_anchors()
    except Exception:
        pass
    try:
        _tag_redraw_all_view3d(context)
    except Exception:
        pass
    return None


def _change_panel_category(panel_cls, new_category):
    # Disabled in standard N-panel mode. Changing a Panel category by
    # unregistering/re-registering live RNA classes is unsafe and was the main
    # source of N-panel draw crashes.
    return False



# =============================================================
# 3.5  Event-driven pin follow (msgbus) + fallback timer
# =============================================================

_MSGBUS_OWNER = object()
_msgbus_enabled = False

def _on_active_category_changed():
    # Called by msgbus when active_panel_category changes
    try:
        ctx = bpy.context
        area = _get_preferred_view3d_area(ctx)
        reg = _get_ui_region(area) if area else None
        cur = getattr(reg, 'active_panel_category', '') if reg else ''
        if not cur:
            cur = DEFAULT_CAT_NAME
        _apply_pins_for_category(ctx, cur)
    except Exception:
        pass

def setup_msgbus():
    # Pin-follow msgbus used to move panels between categories. Keep disabled in
    # standard N-panel mode.
    global _msgbus_enabled
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    _msgbus_enabled = False
    return None


def teardown_msgbus():
    global _msgbus_enabled
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    _msgbus_enabled = False

def pin_update_loop():
    # Lightweight compatibility timer only. It does not mutate Panel classes.
    try:
        context = bpy.context
        active_ws = _get_active_workspace_name(context)
        if active_ws:
            _sync_selector_to_active_workspace(context)
    except Exception:
        pass
    return 2.0


def _reset_pinned_tabs(context, profile=None):
    # Pinned tabs no longer rewrite panel categories. Kept as a compatibility
    # no-op for callers from older runtime paths.
    return None


# --- Smart Tools unified user_default path patch (2026-03-27) ---
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    default = str(default or "").strip()
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            manifest = os.path.join(current, "blender_manifest.toml")
            if os.path.isfile(manifest):
                with open(manifest, "r", encoding="utf-8") as handle:
                    for raw_line in handle:
                        line = raw_line.strip()
                        if not line.startswith("id"):
                            continue
                        _, _, value = line.partition("=")
                        value = str(value or "").strip().strip('"').strip("'")
                        if value:
                            return value
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        head = default.split(".", 1)[0].strip()
        if head:
            default = head
    return default

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    return str(_suite_storage.user_default_root(package_id or 'smart_workspace_suite', create=create))

def _smart_tools_workspace_package_candidates() -> tuple[str, ...]:
    values = [_addon_package_name(), 'smart_workspace_suite']
    out = []
    for value in values:
        value = _smart_tools_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or ('smart_workspace_suite',)

def _smart_tools_workspace_extension_user_root() -> str:
    for package_id in _smart_tools_workspace_package_candidates():
        path = _smart_tools_version_user_default_root(package_id, create=True)
        if path:
            return str(path)
    return _smart_tools_version_user_default_root('smart_workspace_suite', create=True)

_extension_user_root = _smart_tools_workspace_extension_user_root
CONFIG_FILE_PATH = _config_file_path()

# --- Smart Tools user_default migration patch (2026-03-27) ---
def _smart_tools_manifest_dir() -> str:
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            if os.path.isfile(os.path.join(current, "blender_manifest.toml")):
                return current
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    return os.path.dirname(os.path.abspath(__file__))

def _smart_tools_has_visible_entries(path: str) -> bool:
    try:
        return any(name not in {".DS_Store", "Thumbs.db"} for name in os.listdir(path))
    except Exception:
        return False

def _smart_tools_merge_tree(src: str, dst: str) -> None:
    import shutil
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if name in {".DS_Store", "Thumbs.db"}:
            continue
        src_path = os.path.join(src, name)
        dst_path = os.path.join(dst, name)
        if os.path.isdir(src_path):
            shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
        elif os.path.isfile(src_path) and not os.path.exists(dst_path):
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            shutil.copy2(src_path, dst_path)

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    package_id = _smart_tools_manifest_extension_id(package_id)
    target_path = str(_suite_storage.user_default_root(package_id or 'smart_workspace_suite', create=create))

    legacy_candidates = []
    try:
        config_dir = str(bpy.utils.user_resource('CONFIG') or '')
    except Exception:
        config_dir = ''
    try:
        scripts_dir = str(bpy.utils.user_resource('SCRIPTS') or '')
    except Exception:
        scripts_dir = ''
    if scripts_dir and package_id:
        legacy_candidates.append(os.path.join(scripts_dir, 'extensions', 'user_default', package_id))
        legacy_candidates.append(os.path.join(scripts_dir, 'extensions_user', package_id))
    if config_dir and package_id:
        legacy_candidates.append(os.path.join(os.path.normpath(config_dir), 'extensions', 'user_default', package_id))
    manifest_dir = _smart_tools_manifest_dir()
    if package_id:
        legacy_candidates.append(os.path.join(manifest_dir, 'user_default', package_id))

    if create:
        os.makedirs(target_path, exist_ok=True)

    target_norm = os.path.normcase(os.path.normpath(target_path))
    if not _smart_tools_has_visible_entries(target_path):
        for legacy in legacy_candidates:
            if not legacy:
                continue
            legacy_norm = os.path.normcase(os.path.normpath(legacy))
            if legacy_norm == target_norm:
                continue
            if _smart_tools_has_visible_entries(legacy):
                try:
                    _smart_tools_merge_tree(legacy, target_path)
                except Exception:
                    pass
                break
    return target_path


CONFIG_FILE_PATH = _config_file_path()


# --- Toolset standard N-panel crash guard overrides ---
# Blender 5.x can crash if an add-on unregisters/re-registers Panel classes
# while the Sidebar is being laid out. Keep these overrides at the end of the
# module so they replace every legacy SmartTools-host implementation above.
def _purge_all_anchors():
    # No name/prefix scan and no live RNA unregister. Exact ledger owns cleanup.
    global _anchor_classes
    _anchor_classes = []
    return None

def _apply_sidebar_layout(context, profile=None):
    del context, profile
    return None


def _apply_pins_for_category(context, current_cat):
    del context, current_cat
    return None


def _change_panel_category(panel_cls, new_category):
    del panel_cls, new_category
    return False


def setup_msgbus():
    global _msgbus_enabled
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        pass
    _msgbus_enabled = False
    return False


def pin_update_loop():
    return None


def _reset_pinned_tabs(context, profile=None):
    # Add-on shutdown passes no profile: the saved pins must survive that.
    if profile is None:
        return None
    _push_update_suspend()
    try:
        for item in profile.detected_tabs:
            item.is_pinned = False
    finally:
        _pop_update_suspend()
    try:
        _tag_redraw_all_view3d(context)
    except Exception:
        pass
    return None


# --- Real N-panel tab names and order ---
# A Panel's category and its tab position are fixed when the class registers, so
# the only way to change them is to register the class again.  Doing that while
# the Sidebar is laid out can crash Blender, so _apply_sidebar_layout() above
# stays a no-op for every implicit caller (rename, arrows, workspace switch) and
# this runs only from the explicit Apply/Reset buttons and the one start-up
# restore, which are all outside drawing.
_SIDEBAR_FIXED_TABS = frozenset({'Item'})  # Holds Blender's C panels (Transform).
_SIDEBAR_CATEGORY_BYTES_MAX = 63
_SIDEBAR_ORIGINALS: Dict[type, tuple] = {}
_SIDEBAR_APPLIED_NAMES: Dict[str, str] = {}
_SIDEBAR_LAYOUT_ACTIVE = False
_SIDEBAR_STARTUP_RESTORED = False


def _sidebar_layout_path() -> str:
    return os.path.join(_n_panel_manager_settings_dir(), 'sidebar_layout.json')


def _sidebar_panel_tree():
    """Top-level live Python panels in registration order, and children by parent."""
    panel_base = bpy.types.Panel
    definition_order: List[type] = []
    seen: Set[type] = set()

    def _walk(base):
        for sub in base.__subclasses__():
            if sub not in seen:
                seen.add(sub)
                definition_order.append(sub)
                _walk(sub)

    _walk(panel_base)
    live = [
        cls for cls in definition_order
        if 'bl_rna' in vars(cls)
        and getattr(cls, 'bl_space_type', '') == 'VIEW_3D'
        and getattr(cls, 'bl_region_type', '') == 'UI'
    ]
    module_rank: Dict[str, int] = {}
    for index, cls in enumerate(live):
        module_rank.setdefault(cls.__module__, index)

    def _key(item):
        index, cls = item
        declared = getattr(sys.modules.get(cls.__module__), 'classes', None)
        try:
            position = list(declared).index(cls) if declared else len(live)
        except Exception:
            position = len(live)
        return (module_rank[cls.__module__], position, index)

    ordered = [cls for _index, cls in sorted(enumerate(live), key=_key)]
    roots: List[type] = []
    children: Dict[str, List[type]] = {}
    for cls in ordered:
        parent = str(getattr(cls, 'bl_parent_id', '') or '')
        if parent:
            children.setdefault(parent, []).append(cls)
        else:
            roots.append(cls)
    return roots, children


def _sidebar_panel_chain(root, children) -> List[type]:
    chain = [root]
    for cls in children.get(str(getattr(root, 'bl_idname', '') or root.__name__), ()):
        chain.extend(_sidebar_panel_chain(cls, children))
    return chain


def _sidebar_set_category(cls, original_tab: str, category: str) -> None:
    if cls not in _SIDEBAR_ORIGINALS:
        had_own = 'bl_category' in vars(cls)
        _SIDEBAR_ORIGINALS[cls] = (had_own, vars(cls).get('bl_category'))
    if category == original_tab:
        had_own, value = _SIDEBAR_ORIGINALS[cls]
        if had_own:
            cls.bl_category = value
        elif 'bl_category' in vars(cls):
            del cls.bl_category
        if 'nptl_original_category' in vars(cls):
            del cls.nptl_original_category
    else:
        cls.nptl_original_category = original_tab
        cls.bl_category = category


def _sidebar_register_again(root, children, original_tab: str, category: str) -> bool:
    chain = _sidebar_panel_chain(root, children)
    ok = True
    removed: List[type] = []
    for cls in reversed(chain):
        try:
            bpy.utils.unregister_class(cls)
            removed.append(cls)
        except Exception:
            ok = False
    for cls in chain:
        if cls not in removed:
            continue
        try:
            _sidebar_set_category(cls, original_tab, category)
            bpy.utils.register_class(cls)
        except Exception:
            ok = False
            try:
                _sidebar_set_category(cls, original_tab, original_tab)
                bpy.utils.register_class(cls)
            except Exception:
                pass
    return ok


def _sidebar_active_categories(context) -> Dict[Any, str]:
    active: Dict[Any, str] = {}
    reverse = {name: tab for tab, name in _SIDEBAR_APPLIED_NAMES.items()}
    for region in _iter_view3d_ui_regions(context):
        try:
            current = str(region.active_panel_category or '')
        except Exception:
            continue
        if current:
            active[region] = reverse.get(current, current)
    return active


def _sidebar_show_categories(context, active: Dict[Any, str]) -> None:
    # A renamed tab must stay the open tab.  Blender adds the new name to its
    # list at the next layout, so a rejected write is retried once after that.
    pending = []
    for region, tab in active.items():
        target = _SIDEBAR_APPLIED_NAMES.get(tab, tab)
        try:
            region.active_panel_category = target
            if region.active_panel_category == target:
                continue
        except Exception:
            pass
        pending.append((region.as_pointer(), target))
    try:
        _tag_redraw_all_view3d(context)
    except Exception:
        pass
    if not pending:
        return

    def _retry():
        wanted = dict(pending)
        for region in _iter_view3d_ui_regions(bpy.context):
            target = wanted.get(region.as_pointer())
            if target:
                try:
                    region.active_panel_category = target
                except Exception:
                    pass
        _tag_redraw_all_view3d(bpy.context)
        return None

    bpy.app.timers.register(_retry, first_interval=0.1)


def _sidebar_layout_run(context, order, names) -> Dict[str, Any]:
    """Register the Sidebar's Python panels again in tab order under their names."""
    global _SIDEBAR_LAYOUT_ACTIVE
    stats: Dict[str, Any] = {'tabs': 0, 'renamed': 0, 'fixed': [], 'failed': 0}
    active = _sidebar_active_categories(context)
    roots, children = _sidebar_panel_tree()
    by_tab: Dict[str, List[type]] = {}
    for cls in roots:
        # The inventory hides this suite's own root panel, but its tab must move
        # with the others or it would end up in front of them.
        if getattr(cls, 'bl_category', '') == SMART_WORKSPACE_TAB_NAME:
            tab = SMART_WORKSPACE_TAB_NAME
        elif _is_hidden_internal_panel_class(cls):
            continue
        else:
            tab = _get_panel_category(cls)
        if not tab or tab == EMPTY_TAB_CAT:
            continue
        by_tab.setdefault(tab, []).append(cls)
    sequence = [tab for tab in dict.fromkeys(order) if tab in by_tab]
    sequence += [tab for tab in by_tab if tab not in sequence]
    applied: Dict[str, str] = {}
    _push_panel_rebuild_lock()
    try:
        for tab in sequence:
            if tab in _SIDEBAR_FIXED_TABS:
                # Its C panels can neither move nor be renamed, so leave it whole.
                if names.get(tab):
                    stats['fixed'].append(tab)
                continue
            name = str(names.get(tab) or tab)
            if (
                tab == SMART_WORKSPACE_TAB_NAME
                or len(name.encode('utf-8')) > _SIDEBAR_CATEGORY_BYTES_MAX
            ):
                if name != tab:
                    stats['fixed'].append(tab)
                name = tab
            ok = True
            for cls in by_tab[tab]:
                ok = _sidebar_register_again(cls, children, tab, name) and ok
            if ok:
                stats['tabs'] += 1
                if name != tab:
                    applied[tab] = name
                    stats['renamed'] += 1
            else:
                stats['failed'] += 1
    finally:
        _pop_panel_rebuild_lock()
    _SIDEBAR_APPLIED_NAMES.clear()
    _SIDEBAR_APPLIED_NAMES.update(applied)
    _SIDEBAR_LAYOUT_ACTIVE = True
    _invalidate_panel_discovery_cache()
    _sidebar_show_categories(context, active)
    return stats


def apply_sidebar_layout_now(context, profile) -> Dict[str, Any]:
    order: List[str] = []
    names: Dict[str, str] = {}
    use_names = _sidebar_uses_custom_tab_categories(profile)
    for item in profile.detected_tabs:
        ident = str(item.identifier or '')
        if not ident or ident.startswith(FP_PREFIX) or ident.startswith(PV_PREFIX):
            continue
        order.append(ident)
        custom = _display_tab_label(item.custom_name)
        if use_names and custom and custom != ident:
            names[ident] = custom
    stats = _sidebar_layout_run(context, order, names)
    try:
        path = _sidebar_layout_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump({'order': order, 'names': names}, handle, ensure_ascii=False, indent=1)
    except Exception:
        pass
    return stats


def restore_saved_sidebar_layout(context=None) -> bool:
    """Start-up only: bring back the last Apply until the Reset button is pressed."""
    global _SIDEBAR_STARTUP_RESTORED
    if _SIDEBAR_STARTUP_RESTORED or _SIDEBAR_LAYOUT_ACTIVE:
        return False
    _SIDEBAR_STARTUP_RESTORED = True
    try:
        with open(_sidebar_layout_path(), 'r', encoding='utf-8-sig') as handle:
            data = json.load(handle)
        order = [str(tab) for tab in data.get('order', ())]
        names = {str(tab): str(name) for tab, name in dict(data.get('names', {})).items()}
    except Exception:
        return False
    _sidebar_layout_run(context or bpy.context, order, names)
    return True


def _repair_reset(context, profile=None):
    """Button (with a profile): forget the layout.  Shutdown (none): keep it saved."""
    global _SIDEBAR_LAYOUT_ACTIVE, _SIDEBAR_STARTUP_RESTORED
    if profile is not None:
        try:
            os.remove(_sidebar_layout_path())
        except OSError:
            pass
    else:
        # Enabling the add-on again counts as a new start.
        _SIDEBAR_STARTUP_RESTORED = False
    if not _SIDEBAR_LAYOUT_ACTIVE:
        return None
    active = _sidebar_active_categories(context)
    roots, children = _sidebar_panel_tree()
    _push_panel_rebuild_lock()
    try:
        for cls in roots:
            if cls not in _SIDEBAR_ORIGINALS and 'nptl_original_category' not in vars(cls):
                # Registered after Apply, so it was never moved; keep it last.
                continue
            tab = str(getattr(cls, 'nptl_original_category', '') or getattr(cls, 'bl_category', ''))
            _sidebar_register_again(cls, children, tab, tab)
    finally:
        _pop_panel_rebuild_lock()
    _SIDEBAR_ORIGINALS.clear()
    _SIDEBAR_APPLIED_NAMES.clear()
    _SIDEBAR_LAYOUT_ACTIVE = False
    _invalidate_panel_discovery_cache()
    _sidebar_show_categories(context, active)
    return None
