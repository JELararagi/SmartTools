# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
import sys
from typing import Any, Dict, List, Optional

_IS_WIN = (sys.platform == "win32")

def _window_by_ptr(wm: bpy.types.WindowManager, ptr: int) -> Optional[bpy.types.Window]:
    for w in wm.windows:
        try:
            if int(w.as_pointer()) == int(ptr):
                return w
        except Exception:
            continue
    return None


# ------------------------------------------------------------
# Win32 helpers for ordinary floating editor/panel windows.
# Ctrl+Click pseudo-floating N-panels intentionally do not call these helpers
# to resize native windows, drag Sidebar separators, or force N-panel widths.
# These helpers intentionally do not use layered-window alpha, colorkey, or
# other UI transparency APIs.
# ------------------------------------------------------------
if _IS_WIN:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    GWL_STYLE = -16
    GWL_EXSTYLE = -20
    SW_RESTORE = 9

    SWP_NOSIZE = 0x0001
    SWP_NOMOVE = 0x0002
    SWP_NOZORDER = 0x0004
    SWP_NOACTIVATE = 0x0010
    SWP_FRAMECHANGED = 0x0020
    SWP_SHOWWINDOW = 0x0040


    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", ctypes.c_long),
            ("top", ctypes.c_long),
            ("right", ctypes.c_long),
            ("bottom", ctypes.c_long),
        ]


    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


    def _get_pid() -> int:
        return int(kernel32.GetCurrentProcessId())


    def _is_window_visible(hwnd: int) -> bool:
        try:
            return bool(user32.IsWindowVisible(hwnd))
        except Exception:
            return False


    def _get_hwnds_for_pid(pid: int) -> List[int]:
        hwnds: List[int] = []

        @EnumWindowsProc
        def enum_proc(hwnd, _lparam):
            try:
                wnd_pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(wnd_pid))
                if int(wnd_pid.value) != pid:
                    return True
                if not _is_window_visible(int(hwnd)):
                    return True
                hwnds.append(int(hwnd))
            except Exception:
                pass
            return True

        user32.EnumWindows(enum_proc, 0)
        return hwnds


    def _get_client_size(hwnd: int) -> Optional[tuple[int, int]]:
        r = RECT()
        if not user32.GetClientRect(int(hwnd), ctypes.byref(r)):
            return None
        return (int(r.right - r.left), int(r.bottom - r.top))


    def _resize_window_to_client(hwnd: int, client_w: int, client_h: int) -> bool:
        client_w = max(50, int(client_w))
        client_h = max(50, int(client_h))

        try:
            user32.ShowWindow(int(hwnd), SW_RESTORE)
        except Exception:
            pass

        style = user32.GetWindowLongW(int(hwnd), GWL_STYLE)
        exstyle = user32.GetWindowLongW(int(hwnd), GWL_EXSTYLE)

        rc = RECT(0, 0, client_w, client_h)
        user32.AdjustWindowRectEx(ctypes.byref(rc), style, False, exstyle)
        win_w = int(rc.right - rc.left)
        win_h = int(rc.bottom - rc.top)

        win_rc = RECT()
        if not user32.GetWindowRect(int(hwnd), ctypes.byref(win_rc)):
            return False
        x = int(win_rc.left)
        y = int(win_rc.top)

        return bool(user32.SetWindowPos(
            int(hwnd), 0, x, y, win_w, win_h,
            SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_SHOWWINDOW,
        ))


    def _validate_hwnd(hwnd: int) -> bool:
        # Non-mutating validation.  Older builds briefly resized candidate
        # windows to test them, but that can produce visible flicker and is not
        # needed now that callers pass the pre-existing window list.
        return bool(_get_client_size(int(hwnd)))


    def _find_hwnd_validated(before_hwnds: List[int]) -> Optional[int]:
        now = _get_hwnds_for_pid(_get_pid())
        before = set(before_hwnds or [])
        candidates = [h for h in now if h not in before] or now

        for hwnd in candidates:
            if _validate_hwnd(hwnd):
                return int(hwnd)
        for hwnd in now:
            if _validate_hwnd(hwnd):
                return int(hwnd)
        return int(candidates[0]) if candidates else None


    def _set_window_title(hwnd: int, title: str) -> None:
        try:
            user32.SetWindowTextW(int(hwnd), ctypes.c_wchar_p(str(title)))
        except Exception:
            pass


    def _get_window_rect(hwnd: int):
        try:
            rect = RECT()
            if user32.GetWindowRect(int(hwnd), ctypes.byref(rect)):
                x = int(rect.left)
                y = int(rect.top)
                w = int(rect.right - rect.left)
                h = int(rect.bottom - rect.top)
                return (x, y, w, h)
        except Exception:
            pass
        return None


    def _set_window_always_on_top(hwnd: int, on: bool) -> None:
        try:
            hwnd_topmost = ctypes.c_void_p(-1)
            hwnd_notopmost = ctypes.c_void_p(-2)
            insert_after = hwnd_topmost if bool(on) else hwnd_notopmost
            user32.SetWindowPos(
                int(hwnd), insert_after, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
            )
        except Exception:
            pass


    def _set_window_rect(hwnd: int, x: int, y: int, w: int, h: int, topmost=None) -> None:
        try:
            hwnd_topmost = ctypes.c_void_p(-1)
            hwnd_notopmost = ctypes.c_void_p(-2)
            if topmost is None:
                insert_after = 0
                flags = SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_SHOWWINDOW
            else:
                insert_after = hwnd_topmost if bool(topmost) else hwnd_notopmost
                flags = SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_SHOWWINDOW
            user32.SetWindowPos(int(hwnd), insert_after, int(x), int(y), int(w), int(h), flags)
        except Exception:
            pass




    def _get_cursor_pos() -> tuple[int, int]:
        pt = POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)

