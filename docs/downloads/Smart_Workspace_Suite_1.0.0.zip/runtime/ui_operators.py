# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
import os
import sys
import shutil
from pathlib import Path
from typing import Optional, Dict, Any
from bpy.types import Operator, Panel, UIList, Menu
from bpy.props import EnumProperty, StringProperty, IntProperty, BoolProperty, FloatProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .translation import _T, _T_ctx, is_japanese, localized_layout, ui_pair
from ..translation import error_text
from .. import ui_icons

ADDON_TAB_NAME = "Smart Workspace"
from . import core
from . import win32_utils

_UI_OPS_RUNTIME_ENABLED = True

_SIDEBAR_CATEGORY_REQUESTS: Dict[int, Dict[str, Any]] = {}
_SIDEBAR_CATEGORY_TIMER_REGISTERED = False
_SIDEBAR_CATEGORY_RETRY_INTERVAL = 0.05
_SIDEBAR_CATEGORY_MAX_ATTEMPTS = 24


_PANVIEW_MODULE = None


def _panview_module():
    global _PANVIEW_MODULE
    if _PANVIEW_MODULE is None:
        from . import panview as _panview
        _PANVIEW_MODULE = _panview
    return _PANVIEW_MODULE


def _draw_runtime_module(relative_name: str):
    """Return an already loaded Suite module without importing from draw."""
    try:
        root_package = str(__package__ or '').rsplit('.', 1)[0]
        return sys.modules.get(f'{root_package}.{str(relative_name or "").strip(".")}')
    except Exception:
        return None


def _draw_help_button(layout, context, help_id: str, *, text: bool = True):
    # Compact Smart Transform style help trigger.
    # Do not use ui_icons.operator here because icon-only controls deliberately
    # enlarge their row for toolbar buttons. Section headers need the normal
    # Blender row height.
    del text, context
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = row.operator('smart_workspace_suite.open_help', text='', icon='QUESTION', emboss=True)
        op.help_id = str(help_id or 'runtime')
        return op
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass
        return None

def _panview_display_label(value: str = "", context=None) -> str:
    text = core._display_tab_label(value)
    if text.replace('_', ' ').strip().lower() == '2d pan view':
        return '2D Pan View'
    return text or '2D Pan View'


def _panview_label_translates(label: str) -> bool:
    """既定の名前だけ訳す。利用者が付けた名前はそのまま出す。"""
    return label == '2D Pan View'


def _view3d_space_from_context(context):
    """Return the active SpaceView3D for the current area, if available."""
    try:
        space = getattr(context, 'space_data', None)
        if getattr(space, 'type', None) == 'VIEW_3D':
            return space
    except Exception:
        pass
    try:
        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) in _SMART_WORKSPACE_PANEL_SPACE_TYPE_SET:
            spaces = getattr(area, 'spaces', None)
            active = getattr(spaces, 'active', None) if spaces is not None else None
            if getattr(active, 'type', None) == 'VIEW_3D':
                return active
    except Exception:
        pass
    try:
        screen = getattr(context, 'screen', None)
        for area in getattr(screen, 'areas', ()):  # fallback for rare redraw contexts
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            spaces = getattr(area, 'spaces', None)
            active = getattr(spaces, 'active', None) if spaces is not None else None
            if getattr(active, 'type', None) == 'VIEW_3D':
                return active
    except Exception:
        pass
    return None


def _active_category_tab_identifier(context) -> str:
    prof = core._active_profile(context)
    if not prof or not prof.categories:
        return ""
    cat_index = getattr(prof, 'active_category_index', 0)
    if not (0 <= cat_index < len(prof.categories)):
        return ""
    cat = prof.categories[cat_index]
    tab_index = getattr(cat, 'active_tab_index', 0)
    if not (0 <= tab_index < len(cat.tabs)):
        return ""
    return str(getattr(cat.tabs[tab_index], 'identifier', '') or '')


def _open_panview_settings_popup(context):
    try:
        from . import ensure_panview_runtime as _ensure_panview_runtime
        _ensure_panview_runtime()
    except Exception:
        pass
    try:
        return bpy.ops.nptl.panview_popup('INVOKE_DEFAULT')
    except Exception:
        return {'CANCELLED'}


def restore_runtime():
    global _UI_OPS_RUNTIME_ENABLED
    _stop_sidebar_category_timer()
    _UI_OPS_RUNTIME_ENABLED = True
    try:
        _restore = globals().get('_restore_smart_workspace_root_panel_classes')
        if callable(_restore):
            _restore()
    except Exception:
        pass


def shutdown_runtime():
    global _UI_OPS_RUNTIME_ENABLED, _hotbox_handle, _hotbox_state
    _UI_OPS_RUNTIME_ENABLED = False
    clear_draw_runtime_snapshots()
    _stop_sidebar_category_timer()
    try:
        for ptr in list(globals().get('_FLOATING_NPANEL_PENDING', {}).keys()):
            try:
                _finish_floating_npanel_window(int(ptr), mouse_up=True)
            except Exception:
                pass
    except Exception:
        pass
    try:
        if _hotbox_handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(_hotbox_handle, 'WINDOW')
    except Exception:
        pass
    _hotbox_handle = None
    _hotbox_state = {}

# =============================================================
# Standard 3D View N-panel integration
# =============================================================

def _hide_everything_except_sidebar(area):
    """Compatibility name: keep the normal Sidebar visible only.

    Older builds used this hook to alter headers, tools, overlays, and other
    View3D regions in a temporary host window. Standard N-panel UI must not
    do that, so this function now only opens the regular Sidebar region.
    """
    try:
        space = area.spaces.active
    except Exception:
        return
    try:
        space.show_region_ui = True
    except Exception:
        pass


def _find_standard_view3d_area(context) -> Optional[bpy.types.Area]:
    """Return a normal 3D View area used for standard Sidebar/N-panel drawing.

    This intentionally avoids creating a SmartTools/Properties host window,
    creating custom host windows or resizing the Blender UI.
    """
    area = getattr(context, 'area', None)
    if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
        try:
            core._remember_view3d_area(area)
        except Exception:
            pass
        return area

    try:
        area = core._get_preferred_view3d_area(context)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            return area
    except Exception:
        pass

    wm = getattr(context, 'window_manager', None) or getattr(getattr(bpy, 'context', None), 'window_manager', None)
    for win in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(win, 'screen', None)
        for candidate in getattr(screen, 'areas', ()) if screen is not None else ():
            if getattr(candidate, 'type', None) == 'VIEW_3D':
                try:
                    core._remember_view3d_area(candidate)
                except Exception:
                    pass
                return candidate
    return None


def _find_window_and_area_by_pointer(window_ptr: int, area_ptr: int):
    """Reacquire a live window and area without retaining Blender RNA objects."""
    try:
        wm = getattr(bpy.context, 'window_manager', None)
    except Exception:
        wm = None
    if wm is None:
        return None, None

    for win in getattr(wm, 'windows', ()) or ():
        try:
            if window_ptr and int(win.as_pointer()) != int(window_ptr):
                continue
        except Exception:
            continue
        screen = getattr(win, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if int(area.as_pointer()) == int(area_ptr):
                    return win, area
            except Exception:
                continue
    return None, None


def _sidebar_owner_window_pointer(context, area) -> int:
    area_ptr = 0
    try:
        area_ptr = int(area.as_pointer())
    except Exception:
        return 0

    try:
        win = getattr(context, 'window', None)
        screen = getattr(win, 'screen', None) if win is not None else None
        if screen is not None:
            for candidate in getattr(screen, 'areas', ()) or ():
                if int(candidate.as_pointer()) == area_ptr:
                    return int(win.as_pointer())
    except Exception:
        pass

    try:
        wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
    except Exception:
        wm = None
    for win in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(win, 'screen', None)
        for candidate in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if int(candidate.as_pointer()) == area_ptr:
                    return int(win.as_pointer())
            except Exception:
                continue
    return 0


def _stop_sidebar_category_timer() -> None:
    global _SIDEBAR_CATEGORY_TIMER_REGISTERED
    _SIDEBAR_CATEGORY_REQUESTS.clear()
    try:
        if bpy.app.timers.is_registered(_sidebar_category_apply_timer):
            bpy.app.timers.unregister(_sidebar_category_apply_timer)
    except Exception:
        pass
    _SIDEBAR_CATEGORY_TIMER_REGISTERED = False


def _cancel_sidebar_category_request(area) -> None:
    global _SIDEBAR_CATEGORY_TIMER_REGISTERED
    try:
        area_ptr = int(area.as_pointer())
    except Exception:
        return
    _SIDEBAR_CATEGORY_REQUESTS.pop(area_ptr, None)
    if _SIDEBAR_CATEGORY_REQUESTS:
        return
    try:
        if bpy.app.timers.is_registered(_sidebar_category_apply_timer):
            bpy.app.timers.unregister(_sidebar_category_apply_timer)
    except Exception:
        pass
    _SIDEBAR_CATEGORY_TIMER_REGISTERED = False


def _schedule_sidebar_category_apply(context, area, target_name: str) -> None:
    """Apply a category after Blender finishes opening the Sidebar region.

    Immediately after ``show_region_ui`` changes from false to true, Blender can
    temporarily expose ``Region.active_panel_category`` as read-only with the
    value ``UNSUPPORTED``.  Store only integer pointers and text, then reacquire
    live RNA objects from a short-lived one-shot timer.  No timer remains after
    the category is applied or the request expires.
    """
    global _SIDEBAR_CATEGORY_TIMER_REGISTERED
    try:
        area_ptr = int(area.as_pointer())
    except Exception:
        return
    _SIDEBAR_CATEGORY_REQUESTS[area_ptr] = {
        'window_ptr': _sidebar_owner_window_pointer(context, area),
        'area_ptr': area_ptr,
        'target': str(target_name or '').strip(),
        'attempts': 0,
    }
    try:
        already_registered = bpy.app.timers.is_registered(_sidebar_category_apply_timer)
    except Exception:
        already_registered = False
    if not already_registered:
        try:
            bpy.app.timers.register(
                _sidebar_category_apply_timer,
                first_interval=_SIDEBAR_CATEGORY_RETRY_INTERVAL,
            )
            _SIDEBAR_CATEGORY_TIMER_REGISTERED = True
        except Exception:
            _SIDEBAR_CATEGORY_REQUESTS.pop(area_ptr, None)


def _sidebar_category_apply_timer():
    global _SIDEBAR_CATEGORY_TIMER_REGISTERED
    if not _UI_OPS_RUNTIME_ENABLED:
        _SIDEBAR_CATEGORY_REQUESTS.clear()
        _SIDEBAR_CATEGORY_TIMER_REGISTERED = False
        return None

    for key, request in list(_SIDEBAR_CATEGORY_REQUESTS.items()):
        request['attempts'] = int(request.get('attempts', 0)) + 1
        if request['attempts'] > _SIDEBAR_CATEGORY_MAX_ATTEMPTS:
            _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
            continue

        _win, area = _find_window_and_area_by_pointer(
            int(request.get('window_ptr', 0) or 0),
            int(request.get('area_ptr', 0) or 0),
        )
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
            continue

        space = getattr(getattr(area, 'spaces', None), 'active', None)
        if space is None or getattr(space, 'type', None) != 'VIEW_3D':
            _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
            continue
        try:
            if not bool(getattr(space, 'show_region_ui', False)):
                # The user closed the Sidebar before the deferred activation.
                _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
                continue
        except Exception:
            _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
            continue

        region = core._get_ui_region(area)
        if region is None:
            continue
        target_name = str(request.get('target', '') or '').strip()
        if not target_name:
            _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)
            continue

        try:
            if str(getattr(region, 'active_panel_category', '') or '').strip() != target_name:
                region.active_panel_category = target_name
            applied = str(getattr(region, 'active_panel_category', '') or '').strip() == target_name
        except Exception:
            applied = False
        if not applied:
            continue

        try:
            region.tag_redraw()
        except Exception:
            try:
                area.tag_redraw()
            except Exception:
                pass
        _SIDEBAR_CATEGORY_REQUESTS.pop(key, None)

    if _SIDEBAR_CATEGORY_REQUESTS:
        return _SIDEBAR_CATEGORY_RETRY_INTERVAL
    _SIDEBAR_CATEGORY_TIMER_REGISTERED = False
    return None


def _resolve_sidebar_category_for_tab(context, tab_id: str = '', profile=None) -> str:
    """Resolve a launcher tab id to the real Blender Sidebar category name.

    The popup buttons represent actual Sidebar/N-panel tabs.  Earlier builds
    forced every selection back to Smart Workspace to avoid empty legacy
    categories, but that made all non-Smart-Workspace buttons activate the
    wrong tab.  This resolver now selects the requested real category when it
    exists and falls back to Smart Workspace only for hidden or unresolved ids.
    """
    ident = str(tab_id or '').strip()
    if not ident:
        return _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY

    try:
        if core._is_hidden_sidebar_tab_identifier(ident):
            return _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY
    except Exception:
        pass

    prof = profile
    if prof is None:
        try:
            prof = core._active_profile(context)
        except Exception:
            prof = None

    try:
        existing = set(core._scan_all_sidebar_tabs(context))
    except Exception:
        existing = set()

    candidates = []
    if prof is not None:
        try:
            candidates.extend(core._tab_category_candidates(prof, ident))
        except Exception:
            pass
    candidates.append(ident)

    try:
        display = core._display_tab_identifier(ident)
        if display:
            candidates.append(display)
    except Exception:
        pass

    for value in candidates:
        cat = str(value or '').strip()
        if not cat:
            continue
        try:
            cat = str(core._display_tab_identifier(cat) or '').strip()
        except Exception:
            pass
        if not cat:
            continue
        try:
            if core._is_hidden_sidebar_tab_identifier(cat):
                continue
        except Exception:
            pass
        if not existing or cat in existing:
            return cat

    return _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY


def _open_standard_npanel_category(
    context,
    tab_id: str = '',
    *,
    toggle_if_active: bool = False,
) -> bool:
    """Open Blender's normal 3D View Sidebar and switch to the requested tab.

    Crash-safe path: only direct RNA assignments are used.  Do not call operators,
    do not enter ``context.temp_override``, and do not touch inactive workspaces.
    This prevents the Blender 5.1 Windows workspace/mode/undo access-violation
    path seen when using the N-panel manager quick launcher.  When
    ``toggle_if_active`` is enabled, clicking the already active category closes
    the Sidebar, while clicking it with the Sidebar hidden opens the Sidebar.
    """
    target_name = _resolve_sidebar_category_for_tab(context, tab_id)

    area = _find_standard_view3d_area(context)
    if area is None or getattr(area, 'type', None) != 'VIEW_3D':
        return False

    space = getattr(getattr(area, 'spaces', None), 'active', None)
    if space is None:
        return False

    try:
        core._remember_view3d_area(area)
    except Exception:
        pass

    region = core._get_ui_region(area)
    sidebar_visible = False
    current_name = ''
    try:
        sidebar_visible = bool(getattr(space, 'show_region_ui', False))
    except Exception:
        sidebar_visible = False
    if region is not None:
        try:
            current_name = str(getattr(region, 'active_panel_category', '') or '').strip()
        except Exception:
            current_name = ''

    pending_same_category = False
    try:
        area_ptr = int(area.as_pointer())
        pending = _SIDEBAR_CATEGORY_REQUESTS.get(area_ptr)
        pending_same_category = bool(
            pending and str(pending.get('target', '') or '').strip() == target_name
        )
    except Exception:
        pending_same_category = False

    if toggle_if_active and sidebar_visible:
        is_same_category = current_name == target_name or pending_same_category
        if not is_same_category:
            try:
                prof = core._active_profile(context)
                is_same_category = bool(
                    prof and core._tab_matches_category(prof, str(tab_id or ''), current_name)
                )
            except Exception:
                is_same_category = False
        if is_same_category:
            # Do not access the UI region again after hiding it.  Blender may
            # rebuild region internals immediately, so the safe path is a single
            # direct SpaceView3D RNA assignment followed by redraw.
            _cancel_sidebar_category_request(area)
            try:
                space.show_region_ui = False
            except Exception:
                return False
            try:
                area.tag_redraw()
            except Exception:
                pass
            return True

    if not sidebar_visible:
        try:
            space.show_region_ui = True
        except Exception:
            return False

    # Reacquire the UI region after opening the Sidebar.  This avoids retaining
    # a stale Region reference across Blender's region visibility update.
    region = core._get_ui_region(area)
    category_applied = False
    if region is not None:
        try:
            if str(getattr(region, 'active_panel_category', '') or '').strip() != target_name:
                region.active_panel_category = target_name
            category_applied = (
                str(getattr(region, 'active_panel_category', '') or '').strip() == target_name
            )
        except Exception:
            category_applied = False

    if category_applied:
        _cancel_sidebar_category_request(area)
    else:
        # Blender can report the just-opened UI region as ``UNSUPPORTED`` and
        # temporarily reject writes.  Complete only this user-requested action
        # on the next UI ticks; the one-shot timer removes itself immediately.
        _schedule_sidebar_category_apply(context, area, target_name)

    try:
        core._apply_pins_for_category(context, target_name)
    except Exception:
        pass

    try:
        area.tag_redraw()
    except Exception:
        pass
    return True



# =============================================================
# Floating N-panel window integration (Ctrl+Click from launcher)
# =============================================================

_FLOATING_NPANEL_PENDING: Dict[int, Dict[str, Any]] = {}


def _find_view3d_area_by_screen(screen: bpy.types.Screen) -> Optional[bpy.types.Area]:
    """Return the largest 3D View area in a screen, or the largest area.

    The Ctrl+Click pseudo-floating N-panel uses only Blender's normal window
    and 3D View/N-panel APIs.  It intentionally does not use platform-native
    window resizing, forced Sidebar-width dragging, cursor warping, or other
    Win32-only tricks to widen the N-panel.
    """
    if not screen:
        return None
    try:
        view_areas = [area for area in screen.areas if getattr(area, 'type', None) == 'VIEW_3D']
        if view_areas:
            return max(view_areas, key=lambda area: int(getattr(area, 'width', 1)) * int(getattr(area, 'height', 1)))
        if screen.areas:
            return max(screen.areas, key=lambda area: int(getattr(area, 'width', 1)) * int(getattr(area, 'height', 1)))
    except Exception:
        pass
    return None


def _configure_floating_view3d_sidebar(win, category: str) -> bool:
    """Configure a new Blender window as a standard View3D Sidebar host.

    Only the newly created window is touched.  The user's main 3D View, theme,
    transparency, native window size, and Sidebar width are left unchanged.
    """
    screen = getattr(win, 'screen', None)
    area = _find_view3d_area_by_screen(screen) if screen is not None else None
    if area is None:
        return False

    try:
        if getattr(area, 'type', None) != 'VIEW_3D':
            area.type = 'VIEW_3D'
    except Exception:
        return False

    space = getattr(getattr(area, 'spaces', None), 'active', None)
    if space is None:
        return False

    # Keep this as a normal 3D View window, but reduce visual noise only inside
    # the auxiliary window.  No native window API and no Sidebar-width forcing.
    for attr, value in (
        ('show_region_ui', True),
        ('show_region_toolbar', False),
        ('show_region_header', False),
        ('show_region_tool_header', False),
        ('show_region_hud', False),
    ):
        try:
            setattr(space, attr, value)
        except Exception:
            pass

    for attr in (
        'show_gizmo',
        'show_gizmo_tool',
        'show_gizmo_navigate',
        'show_gizmo_context',
        'show_gizmo_object_translate',
        'show_gizmo_object_rotate',
        'show_gizmo_object_scale',
        'show_gizmo_empty',
        'show_gizmo_camera',
        'show_gizmo_light',
    ):
        try:
            if hasattr(space, attr):
                setattr(space, attr, False)
        except Exception:
            pass
    try:
        space.overlay.show_overlays = False
    except Exception:
        pass

    ui_region = core._get_ui_region(area)
    if ui_region is None:
        try:
            space.show_region_ui = False
            space.show_region_ui = True
        except Exception:
            pass
        ui_region = core._get_ui_region(area)

    if ui_region is None:
        return False

    desired = str(category or _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY).strip() or _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY
    # Crash-safe path for Blender 5.1: do not enter temp_override for auxiliary
    # windows. Direct RNA keeps the selected Sidebar category without triggering
    # workspace/mode/undo transitions in Blender's native window manager.
    try:
        space.show_region_ui = True
    except Exception:
        pass
    try:
        ui_region.active_panel_category = desired
    except Exception:
        pass
    try:
        core._apply_pins_for_category(bpy.context, desired)
    except Exception:
        pass

    try:
        area.tag_redraw()
    except Exception:
        pass
    return True


def _finish_floating_npanel_window(ptr: int, *, mouse_up: bool = False):
    # ``mouse_up`` is accepted for compatibility with older timer callbacks.
    # The current pseudo-floating N-panel path does not simulate mouse input.
    _FLOATING_NPANEL_PENDING.pop(int(ptr), None)
    return None


def _safe_configure_floating_npanel_window(ptr: int):
    try:
        return _configure_floating_npanel_window(ptr)
    except Exception:
        return _finish_floating_npanel_window(ptr)


def _configure_floating_npanel_window(ptr: int):
    """Finish configuring a newly-created pseudo-floating N-panel window.

    This timer is intentionally small and deterministic.  It waits until
    Blender exposes the new window/area, then opens the standard Sidebar tab.
    It never calls platform-native resize APIs and never drags the Sidebar
    separator to force a custom N-panel width.
    """
    if not _UI_OPS_RUNTIME_ENABLED:
        return _finish_floating_npanel_window(ptr)

    st = _FLOATING_NPANEL_PENDING.get(int(ptr))
    wm = getattr(bpy.context, 'window_manager', None)
    win = win32_utils._window_by_ptr(wm, ptr) if wm else None
    if not st or win is None:
        return _finish_floating_npanel_window(ptr)

    st['_tries_total'] = int(st.get('_tries_total', 0)) + 1
    if st['_tries_total'] > 80:
        return _finish_floating_npanel_window(ptr)

    category = str(st.get('category') or _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY).strip() or _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY
    if _configure_floating_view3d_sidebar(win, category):
        try:
            from .. import floating_window_lock as _floating_window_lock
            capture_fn = getattr(_floating_window_lock, 'capture_now', None)
            if callable(capture_fn):
                capture_fn(bpy.context)
        except Exception:
            pass
        return _finish_floating_npanel_window(ptr)
    return 0.1


def _open_floating_npanel_category(context, tab_id: str = '') -> bool:
    prof = core._active_profile(context)
    if not prof:
        return False
    target_name = _resolve_sidebar_category_for_tab(context, tab_id, prof)

    try:
        before_ptrs = {int(window.as_pointer()) for window in context.window_manager.windows}
    except Exception:
        before_ptrs = set()

    try:
        bpy.ops.wm.window_new()
    except Exception:
        return False

    try:
        new_windows = [window for window in context.window_manager.windows if int(window.as_pointer()) not in before_ptrs]
    except Exception:
        new_windows = []
    if not new_windows:
        return False

    win = new_windows[-1]
    ptr = int(win.as_pointer())
    _FLOATING_NPANEL_PENDING[ptr] = {
        'category': target_name,
        '_tries_total': 0,
    }
    bpy.app.timers.register(lambda: _safe_configure_floating_npanel_window(ptr), first_interval=0.05)
    return True

# =============================================================
# Operators
# =============================================================

class NPTL_OT_manage_categories(Operator):
    bl_idname = "nptl.manage_cats"
    bl_label = "Manage Categories"
    bl_options = set()
    action: EnumProperty(items=[('ADD','',''),('REMOVE','',''),('UP','',''),('DOWN','','')])
    
    @classmethod
    def description(cls, context, properties):
        act = getattr(properties, "action", "")
        if act == 'ADD': return _T_ctx(context, "DESC_CAT_ADD")
        if act == 'REMOVE': return _T_ctx(context, "DESC_CAT_REMOVE")
        if act == 'UP': return _T_ctx(context, "DESC_CAT_UP")
        if act == 'DOWN': return _T_ctx(context, "DESC_CAT_DOWN")
        return ""

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        core._remember_view3d_area(getattr(context, 'area', None))
        idx = prof.active_category_index
        if self.action == 'ADD':
            prof.categories.add().name = "New Category"
            prof.active_category_index = len(prof.categories) - 1
        elif self.action == 'REMOVE':
            if 0 <= idx < len(prof.categories):
                prof.categories.remove(idx)
                prof.active_category_index = max(0, idx - 1)
        elif self.action == 'UP':
            if idx > 0: prof.categories.move(idx, idx - 1); prof.active_category_index -= 1
        elif self.action == 'DOWN':
            if idx < len(prof.categories)-1: prof.categories.move(idx, idx + 1); prof.active_category_index += 1
        core.save_config_to_file(context, verified_user_change=True)
        return {'FINISHED'}

class NPTL_OT_manage_contents(Operator):
    bl_idname = "nptl.manage_contents"
    bl_label = "Manage Content"
    bl_options = set()
    action: EnumProperty(items=[('ADD_FROM_POOL','',''),('REMOVE','',''),('UP','',''),('DOWN','','')])

    # Floating Panel settings (used when adding from Panel List)
    fp_panel_idname: StringProperty(default="")
    fp_label: StringProperty(default="")
    fp_category: StringProperty(default="")

    default_w: IntProperty(
        name="Default Width",
        default=500,
        min=200,
        max=4000,
        description="Default width for the floating View3D window opened from this entry. Increase it when the panel contents feel cramped."
    )
    default_h: IntProperty(
        name="Default Height",
        default=800,
        min=200,
        max=4000,
        description="Default height for the floating View3D window opened from this entry. Increase it when the panel is taller than the window."
    )
    open_mode: EnumProperty(
        name="Open Mode",
        description="Choose where the floating View3D window appears. Mouse Center is easiest to understand, Last Position reopens where you left it, Pinned Position uses a fixed spot, and Follow Mouse tracks the cursor while open.",
        items=[
            ('MOUSE', "Mouse Center", ""),
            ('LAST', "Last Position", ""),
            ('PIN', "Pinned Position", ""),
            ('FOLLOW', "Follow Mouse", ""),
        ],
        default='MOUSE',
    )
    always_on_top: BoolProperty(
        name="Always On Top",
        default=False,
        description="Keep this floating window above other application windows when possible."
    )
    monitor_interval: FloatProperty(
        name="Monitor Interval (sec)",
        default=0.5,
        min=0.1,
        max=5.0,
        description="How often the floating window checks size, position, and other runtime settings while it is open."
    )
    monitor_size: BoolProperty(
        name="Monitor Size",
        default=True,
        description="Save size changes made while the window is open so the next open can reuse that size."
    )
    monitor_settings: BoolProperty(
        name="Monitor Settings",
        default=True,
        description="Keep applying runtime settings such as Always On Top while the floating window remains open."
    )
    remember_position: BoolProperty(
        name="Remember Position",
        default=True,
        description="Remember the last screen position of this floating window and reuse it later."
    )

    @classmethod
    def description(cls, context, properties):
        act = getattr(properties, "action", "")
        if act == 'ADD_FROM_POOL': return _T_ctx(context, "DESC_CONT_ADD")
        if act == 'REMOVE': return _T_ctx(context, "DESC_CONT_REMOVE")
        if act == 'UP': return _T_ctx(context, "DESC_CONT_UP")
        if act == 'DOWN': return _T_ctx(context, "DESC_CONT_DOWN")
        return ""

    def invoke(self, context, event):
        # ② Panel List: show View3D settings popup before adding
        if self.action != 'ADD_FROM_POOL':
            return self.execute(context)

        prof = core._active_profile(context)
        if not prof or not prof.categories:
            return {'CANCELLED'}

        if getattr(prof, 'pool_mode', 'TABS') != 'PANELS':
            return self.execute(context)

        if not (0 <= getattr(prof, 'active_detected_panel_index', 0) < len(getattr(prof, 'detected_panels', []))):
            return {'CANCELLED'}

        dp = prof.detected_panels[prof.active_detected_panel_index]
        # ⑤/⑦: 2D_Pan_View does not show View3D settings
        if getattr(dp, 'is_panview', False):
            return self.execute(context)

        # prepare settings from profile defaults
        self.fp_panel_idname = dp.panel_idname
        self.fp_label = dp.label
        self.fp_category = dp.category

        self.default_w = int(getattr(prof, 'view3d_default_w', 500))
        self.default_h = int(getattr(prof, 'view3d_default_h', 800))
        self.open_mode = getattr(prof, 'view3d_open_mode', 'MOUSE')
        self.always_on_top = bool(getattr(prof, 'view3d_always_on_top', False))
        self.monitor_interval = float(getattr(prof, 'view3d_monitor_interval', 0.5))
        self.monitor_size = bool(getattr(prof, 'view3d_monitor_size', True))
        self.monitor_settings = bool(getattr(prof, 'view3d_monitor_settings', True))
        self.remember_position = bool(getattr(prof, 'view3d_remember_position', True))

        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        # ② View3D settings popup
        layout = localized_layout(self.layout, context)
        box = layout.box()
        box.label(text="View3D", icon='VIEW3D')
        if self.fp_label:
            box.label(text=self.fp_label)
        row = box.row(align=True)
        row.prop(self, 'default_w')
        row.prop(self, 'default_h')
        box.prop(self, 'open_mode')
        box.prop(self, 'always_on_top')

        mbox = box.box()
        mbox.label(text="Monitor")
        mbox.prop(self, 'monitor_interval')
        r = mbox.row(align=True)
        r.prop(self, 'monitor_size')
        r.prop(self, 'monitor_settings')
        mbox.prop(self, 'remember_position')

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof or not prof.categories:
            return {'CANCELLED'}

        cat = prof.categories[prof.active_category_index]

        if self.action == 'ADD_FROM_POOL':
            if getattr(prof, 'pool_mode', 'TABS') == 'PANELS':
                # add from panel pool
                if not (0 <= getattr(prof, 'active_detected_panel_index', 0) < len(getattr(prof, 'detected_panels', []))):
                    return {'CANCELLED'}
                dp = prof.detected_panels[prof.active_detected_panel_index]

                if getattr(dp, 'is_panview', False):
                    # ⑤ add 2D_Pan_View
                    item = cat.tabs.add()
                    item.identifier = core.PV_PREFIX + '2D_Pan_View'
                    item.custom_label = '2D Pan View'
                else:
                    # create floating panel entry
                    key = core._gen_fp_key()
                    ent = prof.floating_panels.add()
                    ent.key = key
                    ent.panel_idname = self.fp_panel_idname or dp.panel_idname
                    ent.label = self.fp_label or dp.label or ent.panel_idname
                    ent.category = self.fp_category or dp.category

                    ent.default_w = int(self.default_w)
                    ent.default_h = int(self.default_h)
                    ent.open_mode = self.open_mode
                    ent.always_on_top = bool(self.always_on_top)
                    ent.monitor_interval = float(self.monitor_interval)
                    ent.monitor_size = bool(self.monitor_size)
                    ent.monitor_settings = bool(self.monitor_settings)
                    ent.remember_position = bool(self.remember_position)

                    # also update profile defaults (so next add uses last settings)
                    try:
                        prof.view3d_default_w = ent.default_w
                        prof.view3d_default_h = ent.default_h
                        prof.view3d_open_mode = ent.open_mode
                        prof.view3d_always_on_top = ent.always_on_top
                        prof.view3d_monitor_interval = ent.monitor_interval
                        prof.view3d_monitor_size = ent.monitor_size
                        prof.view3d_monitor_settings = ent.monitor_settings
                        prof.view3d_remember_position = ent.remember_position
                    except Exception:
                        pass

                    item = cat.tabs.add()
                    item.identifier = core.FP_PREFIX + key
                    item.custom_label = ent.label

            else:
                # add from detected tabs pool
                if 0 <= prof.active_detected_index < len(prof.detected_tabs):
                    src = prof.detected_tabs[prof.active_detected_index]
                    item = cat.tabs.add()
                    item.identifier = src.identifier
                    item.custom_label = ""

        elif self.action == 'REMOVE':
            if 0 <= cat.active_tab_index < len(cat.tabs):
                # if removing floating panel entry, also remove its settings
                tid = cat.tabs[cat.active_tab_index].identifier or ""
                if tid.startswith(core.FP_PREFIX):
                    key = tid[len(core.FP_PREFIX):]
                    for i, e in enumerate(list(getattr(prof, 'floating_panels', []))):
                        if getattr(e, 'key', '') == key:
                            prof.floating_panels.remove(i)
                            break
                cat.tabs.remove(cat.active_tab_index)
                cat.active_tab_index = max(0, cat.active_tab_index - 1)

        elif self.action == 'UP':
            if cat.active_tab_index > 0:
                cat.tabs.move(cat.active_tab_index, cat.active_tab_index-1)
                cat.active_tab_index -= 1

        elif self.action == 'DOWN':
            if cat.active_tab_index < len(cat.tabs)-1:
                cat.tabs.move(cat.active_tab_index, cat.active_tab_index+1)
                cat.active_tab_index += 1

        core.save_config_to_file(context, verified_user_change=True)
        return {'FINISHED'}


class NPTL_OT_manage_global_tabs(Operator):
    bl_idname = "nptl.manage_global_tabs"
    bl_label = "Global Tabs"
    bl_options = set()
    action: EnumProperty(items=[('UP','',''),('DOWN','',''),('REFRESH','',''),('APPLY','',''),('REPAIR','','')])

    @classmethod
    def description(cls, context, properties):
        act = getattr(properties, "action", "")
        if act == 'APPLY': return _T_ctx(context, "DESC_GLOBAL_APPLY")
        if act == 'REPAIR': return _T_ctx(context, "DESC_GLOBAL_REPAIR")
        if act == 'REFRESH': return _T_ctx(context, "DESC_GLOB_REFRESH")
        if act == 'UP': return _T_ctx(context, "DESC_GLOB_UP")
        if act == 'DOWN': return _T_ctx(context, "DESC_GLOB_DOWN")
        return ""

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        idx = prof.active_detected_index
        if self.action == 'REFRESH': 
            # Refresh is non-destructive.  Only the explicit Cleanup operator
            # removes saved category/favorite/recent references.
            core._invalidate_panel_discovery_cache()
            core._refresh_detected_tabs_logic(context, prof, prune_references=False, save=False)
        elif self.action == 'UP':
            if idx > 0: prof.detected_tabs.move(idx, idx - 1); prof.active_detected_index -= 1
            core._apply_sidebar_layout(context, prof)
        elif self.action == 'DOWN':
            if idx < len(prof.detected_tabs) - 1: prof.detected_tabs.move(idx, idx + 1); prof.active_detected_index += 1
            core._apply_sidebar_layout(context, prof)
        elif self.action == 'APPLY':
            stats = core.apply_sidebar_layout_now(context, prof)
            if stats.get('failed'):
                self.report({'WARNING'}, _T("MSG_APPLY_FAILED").format(count=stats['failed']))
            elif stats.get('fixed'):
                names = ", ".join(core._tab_display_name(prof, tab) for tab in stats['fixed'])
                self.report({'WARNING'}, _T("MSG_APPLY_FIXED").format(names=names))
            else:
                self.report({'INFO'}, _T("MSG_APPLIED"))
        elif self.action == 'REPAIR':
            core._reset_pinned_tabs(context, prof)
            core._repair_reset(context, prof)
            self.report({'INFO'}, _T("MSG_REPAIRED"))
        core.save_config_to_file(context, verified_user_change=True)
        return {'FINISHED'}



class NPTL_OT_cleanup_unused_tabs(Operator):
    bl_idname = "nptl.cleanup_unused_tabs"
    bl_label = "Cleanup Unused Tabs"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        # 未使用（無効化されたアドオン由来など）のタブを Global Tabs から削除
        return "実在しないNパネルタブや古い参照をGlobal Tabsから整理します" if is_japanese(context) else "Remove stale N-panel tabs and old references from the Global Tabs list."

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}

        core._invalidate_panel_discovery_cache()
        stats = core._refresh_detected_tabs_logic(
            context,
            prof,
            prune_references=True,
            save=True,
            verified_user_change=True,
        )
        total_removed = int(stats.get("removed", 0) or 0) + int(stats.get("deduped", 0) or 0)
        if total_removed or stats.get("pruned_category_refs") or stats.get("pruned_favorites") or stats.get("pruned_recent"):
            msg = f"{total_removed} stale tabs / refs removed"
            if is_japanese(context):
                msg = f"古いタブ/参照を {total_removed} 件整理しました"
            self.report({'INFO'}, msg)
        return {'FINISHED'}


class NPTL_OT_refresh_panel_pool(Operator):
    bl_idname = "nptl.refresh_panel_pool"
    bl_label = "Refresh Panel List"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_REFRESH_PANEL_POOL")

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        core._refresh_detected_panels_logic(
            context,
            prof,
            save=True,
            verified_user_change=True,
        )
        try:
            categories = tuple(
                str(getattr(item, 'category', '') or '').strip()
                for item in getattr(prof, 'detected_panels', ())
            )
            refresh_panel_category_ui_snapshot(context, categories)
        except Exception:
            pass
        return {'FINISHED'}

def _pin_follow_is_on(context) -> bool:
    try:
        from .. import ui_runtime as _ui_runtime
        return bool(_ui_runtime._manual_toggle_get('workspace_live_pin_follow', context))
    except Exception:
        return False


def _ensure_pin_follow_for_toggle(context) -> None:
    """A pin the user just pressed must work, so it switches the follow on."""
    try:
        from .. import ui_runtime as _ui_runtime
        action = 'workspace_live_pin_follow'
        if not _ui_runtime._manual_toggle_get(action, context):
            _ui_runtime._manual_toggle_set(action, context, enabled=True)
    except Exception:
        pass


class NPTL_OT_toggle_pin(Operator):
    bl_idname = "nptl.toggle_pin"
    bl_label = "Toggle Pin"
    bl_options = set()
    tab_id: StringProperty()
    
    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_PIN")

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        target = None
        for t in prof.detected_tabs:
            if t.identifier == self.tab_id:
                target = t
                break
        if target:
            desired = not bool(getattr(target, 'is_pinned', False))
            if desired:
                # Switching the follow on can replay the saved settings, which
                # rebuilds the profile, so it goes first and the tab is found again.
                _ensure_pin_follow_for_toggle(context)
                prof = core._active_profile(context)
                target = next((t for t in prof.detected_tabs if t.identifier == self.tab_id), None)
                if target is None:
                    return {'CANCELLED'}
            # Use Blender's standard N-panel header pin mechanism (Panel.use_pin)
            # instead of the old Smart Workspace category relocation method.
            # Opening the real Sidebar category helps Blender create the panel
            # instances whose standard pin state is then synchronized by the
            # lightweight draw wrapper in core.py.
            try:
                core.set_standard_tab_pin_state(context, self.tab_id, desired, prof, save=False)
            except Exception:
                try:
                    target.is_pinned = desired
                except Exception:
                    pass
            if _pin_follow_is_on(context):
                core.install_standard_panel_pin_runtime(context)
            core._last_active_category = ""
            try:
                _open_standard_npanel_category(context, self.tab_id)
            except Exception:
                pass
            try:
                core.save_config_to_file(context, verified_user_change=True)
            except Exception:
                pass
            try:
                for window in context.window_manager.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
            except Exception:
                pass
        return {'FINISHED'}




# =============================================================
# Floating Panel (View3D) runtime
# =============================================================

_FP_WINDOWS: Dict[int, Dict[str, Any]] = {}


def _fp_monitor(ptr: int):
    if not _UI_OPS_RUNTIME_ENABLED:
        _FP_WINDOWS.pop(ptr, None)
        return None
    st = _FP_WINDOWS.get(ptr)
    wm = bpy.context.window_manager
    win = win32_utils._window_by_ptr(wm, ptr) if wm else None
    if not st or not win:
        _FP_WINDOWS.pop(ptr, None)
        return None

    prof = core._active_profile(bpy.context)
    ent = core._find_fp_entry(prof, st.get('key', '')) if prof else None
    if not ent:
        _FP_WINDOWS.pop(ptr, None)
        return None

    if not win32_utils._IS_WIN:
        return float(ent.monitor_interval)

    hwnd = st.get('hwnd')
    if not hwnd:
        return float(ent.monitor_interval)

    geometry_changed = False
    try:
        if ent.open_mode == 'FOLLOW':
            mx, my = win32_utils._get_cursor_pos()
            w = int(ent.last_w or ent.default_w)
            h = int(ent.last_h or ent.default_h)
            x = int(mx - w/2)
            y = int(my - h/2)
            win32_utils._set_window_rect(hwnd, x, y, w, h, topmost=bool(ent.always_on_top) if ent.monitor_settings else None)

        if ent.remember_position:
            r = win32_utils._get_window_rect(hwnd)
            if r:
                new_x, new_y = int(r[0]), int(r[1])
                geometry_changed = geometry_changed or (
                    int(getattr(ent, 'last_x', 0)) != new_x
                    or int(getattr(ent, 'last_y', 0)) != new_y
                )
                ent.last_x, ent.last_y = new_x, new_y

        if ent.monitor_size:
            cs = win32_utils._get_client_size(hwnd)
            if cs:
                new_w, new_h = int(cs[0]), int(cs[1])
                geometry_changed = geometry_changed or (
                    int(getattr(ent, 'last_w', 0)) != new_w
                    or int(getattr(ent, 'last_h', 0)) != new_h
                )
                ent.last_w, ent.last_h = new_w, new_h

        if ent.monitor_settings:
            win32_utils._set_window_always_on_top(hwnd, bool(ent.always_on_top))
    except Exception:
        pass

    if geometry_changed:
        try:
            core.save_config_to_file(bpy.context, verified_user_change=True)
        except Exception:
            try:
                from .. import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
            except Exception:
                pass

    return float(ent.monitor_interval)



class NPTL_OT_fp_open(Operator):
    bl_idname = "nptl.fp_open"
    bl_label = "Open Floating Panel"
    bl_options = set()

    fp_key: StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_FP_OPEN")

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        ent = core._find_fp_entry(prof, self.fp_key)
        if not ent:
            return {'CANCELLED'}

        before_ptrs = {int(w.as_pointer()) for w in context.window_manager.windows}
        before_hwnds = []
        if win32_utils._IS_WIN:
            try:
                before_hwnds = win32_utils._get_hwnds_for_pid(win32_utils._get_pid())
            except Exception:
                before_hwnds = []

        bpy.ops.wm.window_new()
        new_wins = [w for w in context.window_manager.windows if int(w.as_pointer()) not in before_ptrs]
        if not new_wins:
            return {'CANCELLED'}
        win = new_wins[-1]
        ptr = int(win.as_pointer())

        # configure floating editor (AREA::) or legacy View3D panel
        screen = win.screen
        area = screen.areas[0] if screen.areas else None

        panel_id = (ent.panel_idname or "")
        is_area = panel_id.startswith(core.AREA_PREFIX)
        area_type = panel_id[len(core.AREA_PREFIX):] if is_area else "VIEW_3D"

        if area:
            if is_area:
                try:
                    area.type = area_type
                except Exception:
                    pass
            else:
                try:
                    area.type = 'VIEW_3D'
                except Exception:
                    pass
                try:
                    _hide_everything_except_sidebar(area)
                except Exception:
                    pass
                try:
                    ui_region = next((r for r in area.regions if r.type == 'UI'), None)
                    if ui_region:
                        ui_region.active_panel_category = _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY
                except Exception:
                    pass

        # win32 positioning
        hwnd = None
        if win32_utils._IS_WIN:
            try:
                hwnd = win32_utils._find_hwnd_validated(before_hwnds)
                if hwnd:
                    win32_utils._set_window_title(hwnd, ent.label or ent.panel_idname)
            except Exception:
                hwnd = None

        if win32_utils._IS_WIN and hwnd:
            w = int(ent.last_w if ent.open_mode == 'LAST' and ent.last_w > 0 else ent.default_w)
            h = int(ent.last_h if ent.open_mode == 'LAST' and ent.last_h > 0 else ent.default_h)

            try:
                win32_utils._resize_window_to_client(hwnd, w, h)
            except Exception:
                pass

            try:
                if ent.open_mode == 'LAST' and ent.last_x >= 0 and ent.last_y >= 0:
                    x, y = int(ent.last_x), int(ent.last_y)
                elif ent.open_mode == 'PIN':
                    if ent.pinned_x >= 0 and ent.pinned_y >= 0:
                        x, y = int(ent.pinned_x), int(ent.pinned_y)
                    else:
                        mx, my = win32_utils._get_cursor_pos()
                        x, y = int(mx - w/2), int(my - h/2)
                        ent.pinned_x, ent.pinned_y = int(x), int(y)
                else:
                    mx, my = win32_utils._get_cursor_pos()
                    x, y = int(mx - w/2), int(my - h/2)

                win32_utils._set_window_rect(hwnd, x, y, w, h, topmost=bool(ent.always_on_top))
                if ent.remember_position:
                    ent.last_x, ent.last_y = int(x), int(y)
                ent.last_w, ent.last_h = int(w), int(h)
            except Exception:
                pass

        # Crash-safe Blender 5.1 path: avoid wm.call_panel/temp_override in newly
        # spawned windows. The window is configured to show the target Sidebar
        # category through direct RNA above.

        # monitor
        if win32_utils._IS_WIN and hwnd and (ent.monitor_size or ent.remember_position or ent.open_mode == 'FOLLOW' or ent.monitor_settings):
            _FP_WINDOWS[ptr] = {"hwnd": int(hwnd), "key": self.fp_key, "tick": 0}
            bpy.app.timers.register(lambda: _fp_monitor(ptr), first_interval=float(ent.monitor_interval))

        try:
            from .. import floating_window_lock as _floating_window_lock
            capture_fn = getattr(_floating_window_lock, 'capture_now', None)
            if callable(capture_fn):
                capture_fn(context)
        except Exception:
            pass

        try:
            core.save_config_to_file(context, verified_user_change=True)
        except Exception:
            pass

        return {'FINISHED'}


class NPTL_OT_fp_edit_settings(Operator):
    bl_idname = "nptl.fp_edit_settings"
    bl_label = "Edit View3D Settings"
    bl_options = set()

    fp_key: StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_FP_EDIT_SETTINGS")

    default_w: IntProperty(
        name="Default Width",
        default=500,
        min=200,
        max=4000,
        description="Default width for the floating View3D window opened from this entry. Increase it when the panel contents feel cramped."
    )
    default_h: IntProperty(
        name="Default Height",
        default=800,
        min=200,
        max=4000,
        description="Default height for the floating View3D window opened from this entry. Increase it when the panel is taller than the window."
    )
    open_mode: EnumProperty(
        name="Open Mode",
        description="Choose where the floating View3D window appears. Mouse Center is easiest to understand, Last Position reopens where you left it, Pinned Position uses a fixed spot, and Follow Mouse tracks the cursor while open.",
        items=[
            ('MOUSE', "Mouse Center", ""),
            ('LAST', "Last Position", ""),
            ('PIN', "Pinned Position", ""),
            ('FOLLOW', "Follow Mouse", ""),
        ],
        default='MOUSE',
    )
    always_on_top: BoolProperty(
        name="Always On Top",
        default=False,
        description="Keep this floating window above other application windows when possible."
    )
    monitor_interval: FloatProperty(
        name="Monitor Interval (sec)",
        default=0.5,
        min=0.1,
        max=5.0,
        description="How often the floating window checks size, position, and other runtime settings while it is open."
    )
    monitor_size: BoolProperty(
        name="Monitor Size",
        default=True,
        description="Save size changes made while the window is open so the next open can reuse that size."
    )
    monitor_settings: BoolProperty(
        name="Monitor Settings",
        default=True,
        description="Keep applying runtime settings such as Always On Top while the floating window remains open."
    )
    remember_position: BoolProperty(
        name="Remember Position",
        default=True,
        description="Remember the last screen position of this floating window and reuse it later."
    )
    edit_panview: BoolProperty(default=False, options={'SKIP_SAVE'})

    def _draw_panview_settings(self, context):
        try:
            panview = _draw_runtime_module('runtime.panview') or _PANVIEW_MODULE
            if panview is None:
                raise RuntimeError('prepared 2D Pan View module is unavailable')
            panview.draw_panview_ui(
                self.layout,
                context,
                show_launch_button=True,
                show_runtime_controls=False,
                show_window_manager=True,
            )
        except Exception as exc:
            layout = localized_layout(self.layout, context)
            layout.label(text=error_text(exc, '2D Pan View settings could not be drawn', '2Dパンビュー設定を描画できませんでした', context), icon='ERROR')

    def invoke(self, context, event):
        prof = core._active_profile(context)
        if not prof or not prof.categories:
            return {'CANCELLED'}
        cat = prof.categories[prof.active_category_index]
        if not (0 <= cat.active_tab_index < len(cat.tabs)):
            return {'CANCELLED'}

        tid = cat.tabs[cat.active_tab_index].identifier or ""
        if tid.startswith(core.PV_PREFIX):
            self.fp_key = "__PANVIEW__"
            self.edit_panview = True
            try:
                from . import ensure_panview_runtime as _ensure_panview_runtime
                _ensure_panview_runtime()
            except Exception:
                pass
            return _invoke_popup_in_preferred_view3d(context, self, width=460)

        self.edit_panview = False
        if not tid.startswith(core.FP_PREFIX):
            return {'CANCELLED'}

        self.fp_key = tid[len(core.FP_PREFIX):]
        ent = core._find_fp_entry(prof, self.fp_key)
        if not ent:
            return {'CANCELLED'}

        self.default_w = int(ent.default_w)
        self.default_h = int(ent.default_h)
        self.open_mode = ent.open_mode
        self.always_on_top = bool(ent.always_on_top)
        self.monitor_interval = float(ent.monitor_interval)
        self.monitor_size = bool(ent.monitor_size)
        self.monitor_settings = bool(ent.monitor_settings)
        self.remember_position = bool(ent.remember_position)

        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        if bool(getattr(self, 'edit_panview', False)) or str(getattr(self, 'fp_key', '')) == "__PANVIEW__":
            self._draw_panview_settings(context)
            return

        layout = localized_layout(self.layout, context)
        box = layout.box()
        box.label(text=_T_ctx(context, "LBL_VIEW3D_SECTION"), icon='VIEW3D')
        row = box.row(align=True)
        row.prop(self, 'default_w')
        row.prop(self, 'default_h')
        box.prop(self, 'open_mode')
        box.prop(self, 'always_on_top')

        mbox = box.box()
        mbox.label(text=_T_ctx(context, "LBL_MONITOR_SECTION"))
        mbox.prop(self, 'monitor_interval')
        r = mbox.row(align=True)
        r.prop(self, 'monitor_size')
        r.prop(self, 'monitor_settings')
        mbox.prop(self, 'remember_position')

    def execute(self, context):
        if bool(getattr(self, 'edit_panview', False)) or str(getattr(self, 'fp_key', '')) == "__PANVIEW__":
            return {'FINISHED'}
        if not self.fp_key:
            tid = _active_category_tab_identifier(context)
            if tid.startswith(core.PV_PREFIX):
                return {'FINISHED'}

        prof = core._active_profile(context)
        ent = core._find_fp_entry(prof, self.fp_key) if prof else None
        if not ent:
            return {'CANCELLED'}

        ent.default_w = int(self.default_w)
        ent.default_h = int(self.default_h)
        ent.open_mode = self.open_mode
        ent.always_on_top = bool(self.always_on_top)
        ent.monitor_interval = float(self.monitor_interval)
        ent.monitor_size = bool(self.monitor_size)
        ent.monitor_settings = bool(self.monitor_settings)
        ent.remember_position = bool(self.remember_position)

        # Update profile defaults
        try:
            prof.view3d_default_w = ent.default_w
            prof.view3d_default_h = ent.default_h
            prof.view3d_open_mode = ent.open_mode
            prof.view3d_always_on_top = ent.always_on_top
            prof.view3d_monitor_interval = ent.monitor_interval
            prof.view3d_monitor_size = ent.monitor_size
            prof.view3d_monitor_settings = ent.monitor_settings
            prof.view3d_remember_position = ent.remember_position
        except Exception:
            pass

        core.save_config_to_file(context, verified_user_change=True)
        return {'FINISHED'}


def _window_for_area(context, target_area):
    if target_area is None:
        return getattr(context, "window", None)
    wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
    if wm is not None:
        try:
            target_ptr = int(target_area.as_pointer())
        except Exception:
            target_ptr = None
        if target_ptr is not None:
            for window in getattr(wm, 'windows', ()):
                for area in getattr(getattr(window, 'screen', None), 'areas', ()):
                    try:
                        if int(area.as_pointer()) == target_ptr:
                            return window
                    except Exception:
                        continue
    return getattr(context, "window", None)


def _window_region_for_area(area):
    if area is None:
        return None
    for region in getattr(area, 'regions', ()):
        if getattr(region, 'type', None) == 'WINDOW':
            return region
    return None


def _invoke_popup_in_preferred_view3d(context, operator, width):
    target_area = core._get_preferred_view3d_area(context)
    if target_area is not None:
        try:
            if getattr(target_area, 'type', None) == 'VIEW_3D':
                core._remember_view3d_area(target_area)
        except Exception:
            pass
    # Do not use context.temp_override for popup invocation. Blender 5.1 Windows
    # can enter workspace/mode/undo code from the override path; invoking from the
    # current safe context is slightly less specific but avoids native crashes.
    return _invoke_popup_best_fit(operator, context, width=int(width))


def _pick_best_popup_host_override(context, requested_width: int = 0):
    """Return a standard VIEW_3D host override for popups when available.

    Only ordinary 3D View areas are considered. Custom host-window paths are
    deliberately not used.
    """
    area = getattr(context, 'area', None)
    if getattr(area, 'type', None) != 'VIEW_3D':
        return None

    wm = getattr(context, 'window_manager', None) or getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return None

    current_window = getattr(context, 'window', None)
    current_area = getattr(context, 'area', None)
    current_scene = getattr(context, 'scene', None)
    current_ws_name = ''
    try:
        current_ws_name = str(getattr(getattr(current_window, 'workspace', None), 'name', '') or '')
    except Exception:
        current_ws_name = ''

    candidates = []
    for window in getattr(wm, 'windows', ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        ws_name = ''
        try:
            ws_name = str(getattr(getattr(window, 'workspace', None), 'name', '') or '')
        except Exception:
            ws_name = ''
        same_workspace = (not current_ws_name) or (ws_name == current_ws_name)
        for candidate_area in getattr(screen, 'areas', ()):
            if getattr(candidate_area, 'type', None) != 'VIEW_3D':
                continue
            region = next((r for r in getattr(candidate_area, 'regions', ()) if getattr(r, 'type', None) == 'WINDOW'), None)
            if region is None:
                continue
            width = int(getattr(candidate_area, 'width', 0) or 0)
            height = int(getattr(candidate_area, 'height', 0) or 0)
            fits = width >= max(0, int(requested_width or 0))
            is_current = (window == current_window and candidate_area == current_area)
            score = (
                1 if same_workspace else 0,
                1 if fits else 0,
                0 if is_current else 1,
                width * height,
            )
            candidates.append((score, window, candidate_area, region))

    if not candidates:
        return None

    _score, window, area, region = max(candidates, key=lambda item: item[0])
    override = {"window": window, "area": area, "region": region}
    if current_scene is not None:
        override["scene"] = current_scene
    return override


def _invoke_popup_best_fit(operator, context, width: int):
    width = max(200, int(width or 200))
    # No temp_override here. The popup is UI-only and can be safely opened from
    # the current context while the preferred View3D area is remembered separately.
    return context.window_manager.invoke_popup(operator, width=width)


class NPTL_OT_panview_popup(Operator):
    bl_idname = "nptl.panview_popup"
    bl_label = "2D Pan View"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_PANVIEW_POPUP")

    def invoke(self, context, event):
        try:
            from . import ensure_panview_runtime as _ensure_panview_runtime
            _ensure_panview_runtime()
        except Exception:
            pass
        return _invoke_popup_in_preferred_view3d(context, self, width=460)

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        ui_icons.label(header, text='2D Pan View', name='camera', fallback='VIEW_CAMERA')
        _draw_help_button(header, context, 'panview', text=True)
        try:
            panview = _draw_runtime_module('runtime.panview') or _PANVIEW_MODULE
            if panview is None:
                raise RuntimeError('prepared 2D Pan View module is unavailable')
            panview.draw_panview_ui(
                layout,
                context,
                show_launch_button=True,
                show_runtime_controls=False,
                show_window_manager=False,
            )
        except Exception as exc:
            layout = localized_layout(self.layout, context)
            layout.label(text=error_text(exc, '2D Pan View settings could not be drawn', '2Dパンビュー設定を描画できませんでした', context), icon='ERROR')

    def execute(self, context):
        return {'FINISHED'}

class VIEW3D_OT_toggle_local_ui(Operator):
    """Toggle the toolbar, Sidebar, and header in the current 3D View."""
    bl_idname = "view3d.toggle_local_ui"
    bl_label = "Toggle Local UI Elements"
    bl_description = "Toggle the toolbar, Sidebar, and header in the current 3D View area."
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _view3d_space_from_context(context) is not None

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            "Toggle this 3D View area\'s toolbar, Sidebar, and header together. It affects only the current 3D View. After hiding them, press N to show only the Sidebar and click the same button to bring all three back.",
            '現在の3Dビュー領域だけを対象に、ツールバー、サイドバー、ヘッダーをまとめて表示または非表示にします。隠した後は、N キーでサイドバーだけを出し、同じ場所のボタンを押すと 3 つとも戻ります。',
            context,
        )

    def execute(self, context):
        space = _view3d_space_from_context(context)
        if space is None:
            self.report({'WARNING'}, ui_pair('No active 3D View was found.', 'アクティブな3Dビューが見つかりません。', context))
            return {'CANCELLED'}

        current = bool(getattr(space, 'show_region_toolbar', True))
        target_state = not current
        for attr in ('show_region_toolbar', 'show_region_ui', 'show_region_header'):
            try:
                if hasattr(space, attr):
                    setattr(space, attr, target_state)
            except Exception:
                pass

        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class NPTL_OT_toggle_favorite_tab(Operator):
    bl_idname = "nptl.toggle_favorite_tab"
    bl_label = "Toggle Favorite Tab"
    bl_options = set()
    tab_id: StringProperty()
    tab_label: StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_TOGGLE_FAVORITE_TAB")

    def execute(self, context):
        try:
            core._toggle_favorite_tab(context, self.tab_id, self.tab_label)
        except Exception:
            pass
        return {'FINISHED'}


class NPTL_OT_toggle_favorite_panel(Operator):
    bl_idname = "nptl.toggle_favorite_panel"
    bl_label = "Toggle Favorite Panel"
    bl_options = set()
    panel_idname: StringProperty()
    panel_label: StringProperty(default="")
    category: StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_TOGGLE_FAVORITE_PANEL")

    def execute(self, context):
        try:
            core._toggle_favorite_panel(context, self.panel_idname, self.panel_label, self.category)
        except Exception:
            pass
        return {'FINISHED'}


class NPTL_OT_call_panel(Operator):
    bl_idname = "nptl.call_panel"
    bl_label = "Open Panel"
    bl_options = set()
    panel_idname: StringProperty()
    category: StringProperty(default="")
    tab_id: StringProperty(default="")

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_CALL_PANEL")

    def execute(self, context):
        # Ensure the sidebar is visible and the correct category is selected,
        # without toggling the current category closed.
        target_tab_id = str(self.tab_id or self.category or "").strip()
        if target_tab_id:
            area = core._get_preferred_view3d_area(context) or getattr(context, "area", None)
            if area and getattr(area, "type", None) == 'VIEW_3D':
                try:
                    core._remember_view3d_area(area)
                except Exception:
                    pass
                space = getattr(area, "spaces", None).active if getattr(area, "spaces", None) else None
                region = core._get_ui_region(area)
                target_name = _resolve_sidebar_category_for_tab(context, target_tab_id)
                try:
                    if space and not getattr(space, "show_region_ui", False):
                        space.show_region_ui = True
                except Exception:
                    pass
                try:
                    if region:
                        region.active_panel_category = target_name
                except Exception:
                    pass
                try:
                    core._tag_redraw_all_view3d(context)
                except Exception:
                    pass
        # Opening the Sidebar category is sufficient for launcher buttons. Avoid
        # wm.call_panel because in Blender 5.1 it may push undo or enter an unsafe
        # context while the N-panel manager popup is active.
        return {'FINISHED'}


class NPTL_OT_open_panel_popup(Operator):
    bl_idname = "nptl.open_panel_popup"
    bl_label = "Panels in Tab"
    bl_options = set()
    tab_id: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_OPEN_PANEL_POPUP")

    def invoke(self, context, event):
        del event
        prof = _nptl_profile(context)
        candidates = core._tab_category_candidates(prof, self.tab_id) if prof else [self.tab_id]
        refresh_panel_category_ui_snapshot(context, candidates)
        return _invoke_popup_in_preferred_view3d(context, self, width=360)

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        prof = _nptl_profile(context)
        label = core._tab_display_name(prof, self.tab_id) if prof else self.tab_id
        layout.label(text=label, translate=not (prof and core._tab_has_custom_name(prof, self.tab_id)))

        panels = ()
        candidates = core._tab_category_candidates(prof, self.tab_id) if prof else [self.tab_id]
        snapshot = _PANEL_CATEGORY_UI_SNAPSHOT
        for cat_name in candidates:
            panels = snapshot.get(str(cat_name or '').strip(), ())
            if panels:
                break
        if not panels:
            layout.label(text=_T_ctx(context, "TXT_NO_PANELS"))
            return

        for pid, plbl in panels:
            row = layout.row(align=True)
            try:
                row.scale_y = 1.0
            except Exception:
                pass
            fav_on = False
            if prof:
                for fp in getattr(prof, "favorite_panels", []):
                    if fp.panel_idname == pid:
                        fav_on = True
                        break
            fav_icon = 'SOLO_ON' if fav_on else 'SOLO_OFF'
            opf = row.operator("nptl.toggle_favorite_panel", text="", icon=fav_icon, emboss=False)
            opf.panel_idname = pid
            opf.panel_label = plbl
            opf.category = self.tab_id

            op = row.operator("nptl.call_panel", text=plbl, icon='MENU_PANEL')
            op.panel_idname = pid
            op.category = self.tab_id
            op.tab_id = self.tab_id

    def execute(self, context):
        return {'FINISHED'}


# N-panel preset save/load/delete operators were removed.
# The IO section now exposes only external settings export/import.

class NPTL_OT_open_category_window(Operator):
    bl_idname = "nptl.open_category_window"
    bl_label = "Open Smart Workspace N-panel"
    bl_options = set()

    tab_id: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            'Open the standard Blender Sidebar and show the Smart Workspace N-panel. It does not create a floating window or switch to legacy internal categories.',
            '標準のBlenderサイドバーを開き、Smart WorkspaceのNパネルを表示します。フローティングウィンドウを作成したり、旧内部カテゴリーへ切り替えたりしません。',
            context,
        )

    def execute(self, context):
        target_id = str(self.tab_id or _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY).strip()
        if _open_standard_npanel_category(context, target_id):
            return {'FINISHED'}
        self.report({'ERROR'}, ui_pair('Failed to open the Smart Workspace N-panel.', 'Smart Workspace Nパネルを開けませんでした。', context))
        return {'CANCELLED'}

class NPTL_OT_smart_toggle(Operator):
    bl_idname = "nptl.smart_toggle"
    bl_label = "Smart Toggle Tab"
    bl_options = set()
    tab_id: StringProperty() 
    
    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_SMART_TOGGLE")

    def invoke(self, context, event):
        if event.ctrl:
            bpy.ops.nptl.open_category_window(tab_id=self.tab_id)
            return {'FINISHED'}
        if event.alt:
            prof = core._active_profile(context)
            if not prof:
                return {'CANCELLED'}
            candidate_cats = core._tab_category_candidates(prof, self.tab_id)
            # Pick a panel to open: favorite panel in this category -> first panel in category
            pid = None
            try:
                for fp in getattr(prof, 'favorite_panels', []):
                    if str(getattr(fp, 'category', '') or '').strip() in candidate_cats or str(getattr(fp, 'category', '') or '').strip() == self.tab_id:
                        pid = fp.panel_idname
                        break
            except Exception:
                pid = None
            if not pid:
                try:
                    panels = []
                    for cat_name in candidate_cats:
                        panels = core._get_panels_in_category(cat_name)
                        if panels:
                            break
                    if panels:
                        pid = panels[0][0]
                except Exception:
                    pid = None
            if not pid:
                self.report({'WARNING'}, _T_ctx(context, "TXT_NO_PANELS"))
                return {'CANCELLED'}
            try:
                bpy.ops.nptl.call_panel(panel_idname=pid, tab_id=self.tab_id, category=self.tab_id)
            except Exception:
                _open_standard_npanel_category(context, self.tab_id)
            return {'FINISHED'}
        return self.execute(context)

    def execute(self, context):
        # A normal launcher click follows Blender-style Sidebar toggling:
        # hidden Sidebar -> open the selected category; different category ->
        # switch to it; already active visible category -> close the Sidebar.
        if _open_standard_npanel_category(context, self.tab_id, toggle_if_active=True):
            return {'FINISHED'}
        return {'CANCELLED'}

class NPTL_OT_set_popup_tab(Operator):
    bl_idname = "nptl.set_popup_tab"
    bl_label = "Switch Popup Tab"
    bl_options = set()
    index: IntProperty()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_POPUP_TAB")

    def execute(self, context):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        prof.popup_active_tab_index = self.index
        core.save_config_to_file(context, verified_user_change=True)
        try:
            if getattr(context, 'area', None):
                context.area.tag_redraw()
        except:
            pass
        try:
            wm = getattr(context, 'window_manager', None)
            if wm:
                for window in wm.windows:
                    for area in window.screen.areas:
                        area.tag_redraw()
        except:
            pass
        return {'FINISHED'}

class NPTL_OT_launcher(Operator):
    bl_idname = "nptl.launcher"
    bl_label = "Smart Workspace Launcher"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            return True
        return core._get_preferred_view3d_area(context) is not None

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_POPUP")

    def invoke(self, context, event):
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}
        count = len(prof.categories) or 1
        used_cols = min(prof.popup_columns, count)
        return _invoke_popup_in_preferred_view3d(context, self, width=int(prof.popup_width * used_cols))

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        prof = _nptl_profile(context)
        if not prof or len(prof.categories) == 0:
            layout.label(text=_T_ctx(context, "TXT_NO_CATEGORIES"))
            return

        current_cat = ""
        area = core._get_preferred_view3d_area(context)
        if area and area.spaces.active and area.spaces.active.show_region_ui:
            region = core._get_ui_region(area)
            if region:
                current_cat = getattr(region, "active_panel_category", "")

        def get_tab_info(orig_id):
            for t in prof.detected_tabs:
                if t.identifier == orig_id:
                    cname = core._tab_display_name(prof, orig_id)
                    return cname, t.is_pinned
            return core._tab_display_name(prof, orig_id), False

        hidden_tabs = {t.identifier for t in prof.detected_tabs if not t.show}

        def draw_popup_items(box_or_col, tabs):
            for tab_ref in tabs:
                ident = tab_ref.identifier or ""

                # Floating Panel entry
                if ident.startswith(core.FP_PREFIX):
                    key = ident[len(core.FP_PREFIX):]
                    ent = core._find_fp_entry(prof, key)
                    if not ent:
                        continue
                    label = core._display_tab_label(tab_ref.custom_label) or ent.label or ent.panel_idname
                    row = box_or_col.row(align=True)
                    op = row.operator("nptl.fp_open", text=label, translate=not core._display_tab_label(tab_ref.custom_label), icon='WINDOW')
                    op.fp_key = key
                    continue

                # 2D Pan View entry
                if ident.startswith(core.PV_PREFIX):
                    label = _panview_display_label(tab_ref.custom_label, context)
                    row = box_or_col.row(align=True)
                    row.operator_context = 'INVOKE_DEFAULT'
                    row.operator("nptl.panview_popup", text=label, translate=_panview_label_translates(label), icon='CAMERA_DATA')
                    continue

                # Normal tab
                if ident in hidden_tabs:
                    continue
                cname, is_pinned = get_tab_info(ident)
                try:
                    is_pinned = core.standard_tab_pin_state(context, ident, prof)
                except Exception:
                    pass
                custom_label = core._display_tab_label(tab_ref.custom_label)
                label = custom_label or cname
                is_user_name = bool(custom_label) or core._tab_has_custom_name(prof, ident)

                row = box_or_col.row(align=True)
                row.operator_context = 'INVOKE_DEFAULT'
                try:
                    row.scale_y = 1.0
                except Exception:
                    pass
                pin_icon = 'PINNED' if is_pinned else 'UNPINNED'
                op_pin = row.operator("nptl.toggle_pin", text="", icon=pin_icon, emboss=False)
                op_pin.tab_id = ident

                is_active_panel = core._tab_matches_category(prof, ident, current_cat)
                op = row.operator("nptl.smart_toggle", text=label, translate=not is_user_name, depress=is_active_panel)
                op.tab_id = ident

        # Layout mode
        if prof.popup_use_tab_layout:
            row = layout.grid_flow(row_major=True, columns=prof.popup_columns, even_columns=True, even_rows=True)
            for i, cat in enumerate(prof.categories):
                is_active = (i == prof.popup_active_tab_index)
                icon_state = 'CHECKBOX_HLT' if is_active else 'CHECKBOX_DEHLT'
                op = row.operator("nptl.set_popup_tab", text=cat.name, translate=False, icon=icon_state, emboss=True, depress=is_active)
                op.index = i
            layout.separator()
            if 0 <= prof.popup_active_tab_index < len(prof.categories):
                cat = prof.categories[prof.popup_active_tab_index]
                grid = layout.grid_flow(row_major=True, columns=prof.popup_columns, even_columns=True, even_rows=False)
                for tab_ref in cat.tabs:
                    col = grid.column(align=True)
                    draw_popup_items(col, [tab_ref])
        else:
            grid = layout.grid_flow(row_major=True, columns=prof.popup_columns, even_columns=True, even_rows=False)
            for cat in prof.categories:
                col = grid.column(align=True)
                box = col.box()
                box.label(text=cat.name, translate=False)
                draw_popup_items(box, cat.tabs)

    def execute(self, context):
        return {'FINISHED'}

# -------------------------------------------------------------
# Hotbox / Marking Menu (minimal radial)
# -------------------------------------------------------------
import os
import math
import blf
import gpu
from gpu_extras.batch import batch_for_shader

_hotbox_handle = None
_hotbox_state = {}

def _hotbox_draw():
    if (not _UI_OPS_RUNTIME_ENABLED) or (not _hotbox_state):
        return
    try:
        font_id = 0
        x, y = _hotbox_state.get("mx", 0), _hotbox_state.get("my", 0)
        items = _hotbox_state.get("items", [])
        sel = _hotbox_state.get("sel", -1)
        # draw labels around cursor
        r = 90
        for i, it in enumerate(items):
            ang = (math.pi * 2.0) * (i / max(1, len(items))) - math.pi/2.0
            tx = x + math.cos(ang) * r
            ty = y + math.sin(ang) * r
            blf.position(font_id, tx, ty, 0)
            blf.size(font_id, 14)
            lbl = it.get("label","")
            if i == sel:
                lbl = "> " + lbl
            blf.draw(font_id, lbl)
    except Exception:
        pass

class NPTL_OT_hotbox(Operator):
    bl_idname = "nptl.hotbox"
    bl_label = "N-panel Hotbox"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_HOTBOX")

    def invoke(self, context, event):
        global _hotbox_handle, _hotbox_state
        if not _UI_OPS_RUNTIME_ENABLED:
            return {'CANCELLED'}
        prof = core._active_profile(context)
        if not prof:
            return {'CANCELLED'}

        # Build up to 8 items: favorites -> recent -> detected (shown)
        items = []
        seen = set()

        def _add(tab_id, label):
            if tab_id in seen:
                return
            seen.add(tab_id)
            items.append({"id": tab_id, "label": label})

        for ft in getattr(prof, "favorites_tabs", []):
            _add(ft.identifier, core._display_tab_label(ft.custom_label or ft.identifier))
        for rt in sorted(list(getattr(prof, "recent_tabs", [])), key=lambda x: x.last_used, reverse=True):
            _add(rt.identifier, core._display_tab_label(rt.custom_label or rt.identifier))
        for dt in prof.detected_tabs:
            if not dt.show:
                continue
            label = core._display_tab_label(dt.custom_name.strip() if dt.custom_name.strip() else dt.identifier)
            _add(dt.identifier, label)

        items = items[:8]
        if not items:
            return {'CANCELLED'}

        _hotbox_state = {
            "items": items,
            "mx": event.mouse_region_x,
            "my": event.mouse_region_y,
            "sx": event.mouse_region_x,
            "sy": event.mouse_region_y,
            "sel": -1,
        }

        if _hotbox_handle is None:
            _hotbox_handle = bpy.types.SpaceView3D.draw_handler_add(_hotbox_draw, (), 'WINDOW', 'POST_PIXEL')

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global _hotbox_handle, _hotbox_state
        if not _UI_OPS_RUNTIME_ENABLED:
            self._finish()
            return {'CANCELLED'}
        if event.type in {'ESC'}:
            self._finish()
            return {'CANCELLED'}

        if event.type == 'MOUSEMOVE':
            _hotbox_state["mx"] = event.mouse_region_x
            _hotbox_state["my"] = event.mouse_region_y
            dx = event.mouse_region_x - _hotbox_state.get("sx", event.mouse_region_x)
            dy = event.mouse_region_y - _hotbox_state.get("sy", event.mouse_region_y)
            ang = math.atan2(dy, dx)
            items = _hotbox_state.get("items", [])
            if items:
                # map angle to index
                a = (ang + math.pi*2.0) % (math.pi*2.0)
                idx = int((a / (math.pi*2.0)) * len(items))
                _hotbox_state["sel"] = max(0, min(len(items)-1, idx))
            for area in context.window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
            return {'RUNNING_MODAL'}

        # confirm on release (LMB / key release)
        if event.type in {'LEFTMOUSE', 'RET', 'SPACE'} and event.value in {'RELEASE', 'PRESS'}:
            items = _hotbox_state.get("items", [])
            sel = _hotbox_state.get("sel", -1)
            if 0 <= sel < len(items):
                tab_id = items[sel]["id"]
                try:
                    bpy.ops.nptl.smart_toggle(tab_id=tab_id)
                except Exception:
                    pass
            self._finish()
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def _finish(self):
        global _hotbox_handle, _hotbox_state
        try:
            if _hotbox_handle is not None:
                bpy.types.SpaceView3D.draw_handler_remove(_hotbox_handle, 'WINDOW')
        except Exception:
            pass
        _hotbox_handle = None
        _hotbox_state = {}
        try:
            for area in bpy.context.window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass

class NPTL_UL_category(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "name", text="", emboss=False, icon='COLLECTION_NEW')

class NPTL_UL_tab_content(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        prof = _nptl_profile(context)
        ident = item.identifier or ""

        # Floating Panel entry
        if ident.startswith(core.FP_PREFIX):
            key = ident[len(core.FP_PREFIX):]
            ent = core._find_fp_entry(prof, key) if prof else None
            label = core._display_tab_label(item.custom_label) or (ent.label if ent else "Floating Panel")
            layout.label(text=label, translate=not core._display_tab_label(item.custom_label))
            return

        # 2D Pan View entry
        if ident.startswith(core.PV_PREFIX):
            label = _panview_display_label(item.custom_label, context)
            layout.label(text=label, translate=_panview_label_translates(label))
            return

        disp_name = core._tab_display_name(prof, ident) if prof else core._display_tab_label(ident)

        custom_label = core._display_tab_label(item.custom_label)
        if custom_label:
            layout.label(text=f"{custom_label} ({disp_name})", translate=False)
        else:
            layout.label(text=disp_name, translate=not (prof and core._tab_has_custom_name(prof, ident)))


class NPTL_UL_detected(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "show", text="", icon='HIDE_OFF' if item.show else 'HIDE_ON', emboss=False)
        ident_label = core._display_tab_label(getattr(item, 'identifier', ''))
        cname = core._display_tab_label(getattr(item, 'custom_name', ''))
        label_txt = ident_label
        if cname and cname != ident_label:
            label_txt = f"{ident_label} -> {cname}" if ident_label else cname
        row.label(text=label_txt, translate=not cname)
        if item.is_pinned: ui_icons.label(row, text="", name='pin', fallback='PINNED')




class NPTL_UL_detected_panels(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        if getattr(item, 'is_panview', False):
            ui_icons.label(row, text=_panview_display_label(item.label, context), name='camera', fallback='CAMERA_DATA')
        else:
            ui_icons.label(row, text=item.label or item.panel_idname, name='window', fallback='WINDOW')
            # show category hint
            cat = core._display_tab_label(getattr(item, 'category', ''))
            if cat:
                row.label(text=f"[{cat}]")
class NPTL_OT_select_workspace(Operator):
    bl_idname = "nptl.select_workspace"
    bl_label = "Select Workspace"
    bl_options = set()
    ws_name: StringProperty()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_SELECT_WORKSPACE")

    def execute(self, context):
        try:
            st = context.window_manager.nptl_settings
            ws = bpy.data.workspaces.get(self.ws_name)
            if ws:
                st.workspace_ptr = ws
        except:
            pass
        return {'FINISHED'}

_WORKSPACE_UI_ORDER_NAMES: tuple[str, ...] = ()
_WORKSPACE_UI_ORDER_REVISION = 0
_WORKSPACE_UI_ORDER_MAX_ENTRIES = 4096
_PANEL_CATEGORY_UI_SNAPSHOT: dict[str, tuple[tuple[str, str], ...]] = {}
_PANEL_CATEGORY_UI_REVISION = 0
_PANEL_CATEGORY_UI_MAX_ENTRIES = 128


def refresh_panel_category_ui_snapshot(context=None, categories=None) -> dict[str, tuple[tuple[str, str], ...]]:
    """Capture panel/category discovery only at an explicit operator boundary."""
    del context
    global _PANEL_CATEGORY_UI_SNAPSHOT, _PANEL_CATEGORY_UI_REVISION
    requested = []
    for value in tuple(categories or ()):
        try:
            category = str(value or '').strip()
        except Exception:
            category = ''
        if category and category not in requested:
            requested.append(category)
    snapshot = dict(_PANEL_CATEGORY_UI_SNAPSHOT)
    for category in requested:
        try:
            values = core._get_panels_in_category(category)
        except Exception:
            values = ()
        clean = []
        seen = set()
        for item in tuple(values or ()):
            try:
                panel_id = str(item[0] or '').strip()
                label = str(item[1] or panel_id).strip()
            except Exception:
                continue
            if not panel_id or panel_id in seen:
                continue
            seen.add(panel_id)
            clean.append((panel_id, label or panel_id))
        snapshot[category] = tuple(clean)
    if len(snapshot) > _PANEL_CATEGORY_UI_MAX_ENTRIES:
        priority = requested + [key for key in snapshot if key not in requested]
        snapshot = {
            key: snapshot[key]
            for key in priority[:_PANEL_CATEGORY_UI_MAX_ENTRIES]
            if key in snapshot
        }
    _PANEL_CATEGORY_UI_SNAPSHOT = snapshot
    _PANEL_CATEGORY_UI_REVISION += 1
    return dict(snapshot)


def refresh_workspace_ui_order_cache(context=None) -> tuple[str, ...]:
    """Rebuild the bounded workspace order snapshot outside Menu.draw().

    Blender's private workspace-hook layout can require a depth-limited RNA
    discovery pass on some builds.  That pass is allowed only from explicit
    registration/load/operator events.  Menu drawing consumes the immutable
    tuple produced here and never scans RNA or reads files.
    """
    global _WORKSPACE_UI_ORDER_NAMES, _WORKSPACE_UI_ORDER_REVISION
    try:
        all_ws = list(bpy.data.workspaces)
    except Exception:
        all_ws = []

    def _dedup(ws_list):
        out = []
        seen = set()
        for workspace in ws_list:
            try:
                name = str(workspace.name or '')
            except Exception:
                continue
            if not name or name in seen:
                continue
            seen.add(name)
            out.append(workspace)
        return out

    def _extract_from_collection(collection):
        out = []
        try:
            workspace_type = getattr(getattr(bpy, 'types', None), 'WorkSpace', None)
            for item in collection:
                if workspace_type is not None and isinstance(item, workspace_type):
                    out.append(item)
                    continue
                workspace = getattr(item, 'workspace', None)
                if workspace_type is not None and workspace is not None and isinstance(workspace, workspace_type):
                    out.append(workspace)
        except Exception:
            return []
        return _dedup(out)

    def _scan_obj(obj, depth=2, visited=None):
        if obj is None or depth < 0:
            return []
        if visited is None:
            visited = set()
        try:
            pointer = obj.as_pointer() if hasattr(obj, 'as_pointer') else id(obj)
            key = (type(obj), pointer)
        except Exception:
            key = (type(obj), id(obj))
        if key in visited:
            return []
        visited.add(key)

        for attr in ('workspaces', 'workspace_list', 'workspace_tabs'):
            try:
                collection = getattr(obj, attr, None)
                workspaces = _extract_from_collection(collection) if collection is not None else []
            except Exception:
                workspaces = []
            if workspaces:
                return workspaces

        rna = getattr(obj, 'bl_rna', None)
        properties = tuple(getattr(rna, 'properties', ()) or ()) if rna is not None else ()
        for prop in properties:
            if getattr(prop, 'type', '') != 'COLLECTION':
                continue
            try:
                collection = getattr(obj, prop.identifier)
            except Exception:
                continue
            workspaces = _extract_from_collection(collection)
            if workspaces:
                return workspaces
        for prop in properties:
            if getattr(prop, 'type', '') != 'POINTER':
                continue
            identifier = str(getattr(prop, 'identifier', '') or '')
            if 'workspace' not in identifier and identifier not in {
                'screen', 'workspace_hook', 'workspace_instance', 'workspace_instance_hook',
            }:
                continue
            try:
                child = getattr(obj, identifier)
            except Exception:
                continue
            workspaces = _scan_obj(child, depth - 1, visited)
            if workspaces:
                return workspaces
        return []

    found = []
    try:
        ctx = context or getattr(bpy, 'context', None)
        window = getattr(ctx, 'window', None) if ctx is not None else None
        hook = getattr(window, 'workspace_hook', None) if window is not None else None
        if hook is None and window is not None:
            hook = getattr(getattr(window, 'screen', None), 'workspace_hook', None)
        if hook is not None:
            found = _extract_from_collection(getattr(hook, 'workspaces', ()))
        if not found and window is not None:
            found = _scan_obj(window, depth=3)
            if not found:
                found = _scan_obj(getattr(window, 'screen', None), depth=3)
    except Exception:
        found = []

    ordered = _dedup(found)
    seen = {str(getattr(workspace, 'name', '') or '') for workspace in ordered}
    for workspace in all_ws:
        try:
            name = str(workspace.name or '')
        except Exception:
            continue
        if name and name not in seen:
            ordered.append(workspace)
            seen.add(name)
    names = tuple(str(getattr(workspace, 'name', '') or '') for workspace in ordered)
    names = tuple(name for name in names if name)
    _WORKSPACE_UI_ORDER_NAMES = names[:_WORKSPACE_UI_ORDER_MAX_ENTRIES]
    _WORKSPACE_UI_ORDER_REVISION += 1
    return names


def _get_workspaces_in_ui_order(context):
    """Return only the immutable in-memory workspace order snapshot.

    This function is called by ``NPTL_MT_workspace_menu.draw``.  It deliberately
    performs no workspace-hook discovery, RNA traversal, disk access, Manager
    API call, registration, or mutation.  A transient empty cache falls back to
    the already available active workspace only.
    """
    names = _WORKSPACE_UI_ORDER_NAMES
    if not names:
        try:
            active = getattr(context, 'workspace', None) or getattr(getattr(context, 'window', None), 'workspace', None)
            return (active,) if active is not None else ()
        except Exception:
            return ()
    try:
        collection = bpy.data.workspaces
    except Exception:
        return ()
    result = []
    for name in names:
        try:
            workspace = collection.get(name)
        except Exception:
            workspace = None
        if workspace is not None:
            result.append(workspace)
    return tuple(result)

class NPTL_MT_workspace_menu(Menu):
    bl_label = "Workspace"

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        for ws in _get_workspaces_in_ui_order(context):
            op = layout.operator("nptl.select_workspace", text=ws.name, translate=False)
            op.ws_name = ws.name

class VIEW3D_PT_nptl_manager(Panel):
    """Legacy hidden View3D sidebar panel kept only for compatibility."""
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Workspace'
    bl_label = ADDON_TAB_NAME
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        pass


# -------------------------------------------------------------
# Standard N-panel helpers
# -------------------------------------------------------------

_PROPERTIES_PSEUDO_TAB_ICON = 'PREFERENCES'
_PSEUDO_TAB_PANELS_PREPARED = False

# The real Blender Sidebar category used by the native Smart Workspace panel.
# Legacy Smart Tools code still has workflow/category names such as "Item";
# those are internal launcher categories and must never be written to
# region.active_panel_category, otherwise selecting/opening the tab can switch
# the Sidebar to an empty category and make the N-panel look missing.
_SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY = 'Smart Workspace'


def _nptl_settings(context):
    wm = getattr(context, "window_manager", None)
    return getattr(wm, "nptl_settings", None) if wm else None


def _nptl_profile(context):
    """Return an existing profile without creating or mutating RNA."""
    try:
        st = getattr(getattr(context, 'window_manager', None), 'nptl_settings', None)
    except Exception:
        st = None
    if st is None:
        return None
    workspace_name = ''
    try:
        workspace_name = core._ws_name_from_key(str(getattr(st, 'workspace_selector', '') or ''))
    except Exception:
        workspace_name = ''
    if not workspace_name:
        try:
            workspace_name = str(getattr(getattr(context, 'workspace', None), 'name', '') or '')
        except Exception:
            workspace_name = ''
    if not workspace_name:
        try:
            workspace_name = str(getattr(getattr(getattr(context, 'window', None), 'workspace', None), 'name', '') or '')
        except Exception:
            workspace_name = ''
    try:
        profiles = getattr(st, 'workspace_profiles', ())
        for profile in profiles:
            if str(getattr(profile, 'workspace_name', '') or '') == workspace_name:
                return profile
    except Exception:
        return None
    return None

_SMART_WORKSPACE_PANEL_SPACE_TYPES: tuple[str, ...] = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
)

_SMART_WORKSPACE_PANEL_SPACE_TYPE_SET = set(_SMART_WORKSPACE_PANEL_SPACE_TYPES)
_SMART_TOOLS_MANAGER_RUNTIME_NAMESPACE_KEY = 'JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1'


def _smart_workspace_panel_area_type(context) -> str:
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            value = str(getattr(area, 'type', '') or '').strip()
            if value:
                return value
    except Exception:
        pass
    try:
        space = getattr(context, 'space_data', None)
        value = str(getattr(space, 'type', '') or '').strip()
        if value:
            return value
    except Exception:
        pass
    return ''


def _smart_tools_manager_module():
    """Return the single validated Manager runtime record, never sys.modules."""
    try:
        record = bpy.app.driver_namespace.get(_SMART_TOOLS_MANAGER_RUNTIME_NAMESPACE_KEY)
    except Exception:
        return None
    if not isinstance(record, dict):
        return None
    if record.get('package_id') != 'smart_tools_manager' or record.get('status') != 'ACTIVE':
        return None
    generation = record.get('generation')
    revision = record.get('revision')
    if not isinstance(generation, str) or not generation:
        return None
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 0:
        return None
    if record.get('runtime_identity') is None or not isinstance(record.get('public_api'), dict):
        return None
    return record


_SMART_TOOLS_MANAGER_TOOL_KEY = 'SMART_WORKSPACE'
# Panel.poll consumes this immutable process-local snapshot only.  Manager API
# calls are confined to refresh_smart_tools_manager_decision_snapshot(), which
# is invoked by explicit registration/load/refresh events and never by draw.
_SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT: dict[str, Any] = {
    'active': False,
    'generation': '',
    'revision': -1,
    'decisions': {},
}
_SMART_TOOLS_MANAGER_SNAPSHOT_MAX_CELLS = 16 * 17


def clear_draw_runtime_snapshots() -> None:
    """Release process-local draw/poll snapshots owned by this runtime."""
    global _WORKSPACE_UI_ORDER_NAMES, _WORKSPACE_UI_ORDER_REVISION
    global _PANEL_CATEGORY_UI_SNAPSHOT, _PANEL_CATEGORY_UI_REVISION
    global _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT
    _WORKSPACE_UI_ORDER_NAMES = ()
    _WORKSPACE_UI_ORDER_REVISION = 0
    _PANEL_CATEGORY_UI_SNAPSHOT = {}
    _PANEL_CATEGORY_UI_REVISION = 0
    _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT = {
        'active': False, 'generation': '', 'revision': -1, 'decisions': {},
    }

_SMART_TOOLS_MANAGER_WORKSPACE_ALIASES = {
    'LAYOUT': ('Layout', 'レイアウト'),
    'MODELING': ('Modeling', 'モデリング'),
    'SCULPTING': ('Sculpting', 'スカルプト'),
    'UV_EDITING': ('UV Editing', 'UVエディティング', 'UV編集'),
    'TEXTURE_PAINT': ('Texture Paint', 'テクスチャペイント'),
    'SHADING': ('Shading', 'シェーディング'),
    'ANIMATION': ('Animation', 'アニメーション'),
    'RENDERING': ('Rendering', 'レンダリング'),
    'COMPOSITING': ('Compositing', 'コンポジティング'),
    'GEOMETRY_NODES': ('Geometry Nodes', 'Geometry Node', 'ジオメトリノード'),
    'SCRIPTING': ('Scripting', 'スクリプティング'),
    'ANIMATION_2D': ('2D Animation', '2Dアニメーション'),
    'FULL_CANVAS_2D': ('2D Full Canvas', '2Dフルキャンバス'),
    'MASKING': ('Masking', 'マスキング'),
    'MOTION_TRACKING': ('Motion Tracking', 'モーショントラッキング'),
    'VIDEO_EDITING': ('Video Editing', 'ビデオ編集'),
}


def _smart_tools_manager_normalize_name(value) -> str:
    try:
        text = str(value or '').casefold()
    except Exception:
        return ''
    return ''.join(ch for ch in text if ch.isalnum())


_SMART_TOOLS_MANAGER_WORKSPACE_KEY_BY_NORMALIZED_NAME = {
    _smart_tools_manager_normalize_name(alias): workspace_key
    for workspace_key, aliases in _SMART_TOOLS_MANAGER_WORKSPACE_ALIASES.items()
    for alias in (workspace_key, *aliases)
    if _smart_tools_manager_normalize_name(alias)
}


def _smart_tools_manager_workspace_key(context) -> str:
    """Resolve one workspace through a precomputed memory-only alias map."""
    for source in (
        getattr(context, 'workspace', None),
        getattr(getattr(context, 'window', None), 'workspace', None),
    ):
        try:
            raw_name = str(getattr(source, 'name', '') or '')
        except Exception:
            raw_name = ''
        normalized = _smart_tools_manager_normalize_name(raw_name)
        if normalized:
            workspace_key = _SMART_TOOLS_MANAGER_WORKSPACE_KEY_BY_NORMALIZED_NAME.get(normalized)
            if workspace_key:
                return workspace_key
    return ''


def _smart_tools_manager_enum_text(value) -> str:
    try:
        return str(value or '').strip().upper()
    except Exception:
        return ''


def _smart_tools_manager_attr_text(obj, *names: str) -> str:
    for name in names:
        try:
            value = getattr(obj, name, None)
        except Exception:
            value = None
        text = _smart_tools_manager_enum_text(value)
        if text:
            return text
    return ''


def _smart_tools_manager_editor_key_for_context(context) -> str:
    try:
        area = getattr(context, 'area', None)
    except Exception:
        area = None
    try:
        space = getattr(getattr(area, 'spaces', None), 'active', None) if area is not None else None
    except Exception:
        space = getattr(context, 'space_data', None)
    area_type = _smart_tools_manager_attr_text(area, 'type')
    area_ui_type = _smart_tools_manager_attr_text(area, 'ui_type')
    space_type = _smart_tools_manager_attr_text(space, 'type')
    actual = space_type or area_type
    tree_type = _smart_tools_manager_attr_text(space, 'tree_type') or area_ui_type
    mode = _smart_tools_manager_attr_text(space, 'mode')
    sequence_view = _smart_tools_manager_attr_text(space, 'view_type', 'display_mode')
    browse_mode = _smart_tools_manager_attr_text(space, 'browse_mode')
    try:
        if not browse_mode:
            browse_mode = _smart_tools_manager_attr_text(getattr(space, 'params', None), 'browse_mode')
    except Exception:
        pass

    if actual == 'VIEW_3D':
        return 'VIEW_3D'
    if actual == 'IMAGE_EDITOR':
        uv_modes = {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'}
        return 'UV_EDITOR' if mode in uv_modes or area_ui_type in uv_modes else 'IMAGE_EDITOR'
    if actual == 'NODE_EDITOR':
        node_type = tree_type or area_ui_type
        if node_type in {'COMPOSITORNODETREE', 'COMPOSITOR', 'COMPOSITOR_NODE_TREE'}:
            return 'COMPOSITOR'
        if node_type in {'GEOMETRYNODETREE', 'GEOMETRY', 'GEOMETRY_NODE_TREE'}:
            return 'GEOMETRY_NODE_EDITOR'
        if node_type in {'TEXTURENODETREE', 'TEXTURE', 'TEXTURE_NODE_TREE'}:
            return 'TEXTURE_NODE_EDITOR'
        return 'SHADER_EDITOR'
    if actual == 'SEQUENCE_EDITOR':
        return 'VIDEO_SEQUENCER'
    if actual == 'CLIP_EDITOR':
        return 'MOVIE_CLIP_EDITOR'
    if actual == 'DOPESHEET_EDITOR':
        if area_ui_type in {'TIMELINE'} or mode in {'TIMELINE'}:
            return ''
        return 'DRIVERS' if area_ui_type in {'DRIVERS', 'DRIVER'} or mode in {'DRIVERS', 'DRIVER'} else 'DOPE_SHEET'
    if actual == 'GRAPH_EDITOR':
        return 'DRIVERS' if area_ui_type in {'DRIVERS', 'DRIVER'} or mode in {'DRIVERS', 'DRIVER'} else 'GRAPH_EDITOR'
    if actual == 'NLA_EDITOR':
        return 'NLA_EDITOR'
    if actual == 'TEXT_EDITOR':
        return 'TEXT_EDITOR'
    if actual == 'FILE_BROWSER':
        asset_modes = {'ASSETS', 'ASSET_BROWSER'}
        return 'ASSET_BROWSER' if browse_mode in asset_modes or area_ui_type in asset_modes else 'FILE_BROWSER'
    if actual == 'SPREADSHEET':
        return 'SPREADSHEET'
    return ''


def _smart_tools_manager_enabled_in_preferences() -> bool:
    """Return the last explicit Manager snapshot state without API access."""
    return bool(_SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT.get('active'))


def _smart_tools_manager_settings_paths() -> tuple[Path, ...]:
    """Retired compatibility API: Panel decisions perform no file discovery."""
    return ()


def _smart_tools_manager_read_settings_payload():
    """Return a detached copy of the already captured in-memory rule snapshot."""
    snapshot = _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT
    decisions = snapshot.get('decisions')
    if not snapshot.get('active') or not isinstance(decisions, dict):
        return None
    return {
        'generation': str(snapshot.get('generation') or ''),
        'revision': int(snapshot.get('revision') or 0),
        'decisions': dict(decisions),
    }


def _smart_tools_manager_rule_value_from_rules(rules, workspace_key: str, editor_key: str):
    if not isinstance(rules, dict) or not workspace_key or not editor_key:
        return None
    workspace_rules = rules.get(workspace_key)
    if not isinstance(workspace_rules, dict):
        return None
    editor_rules = workspace_rules.get(editor_key)
    if not isinstance(editor_rules, dict):
        return None
    value = editor_rules.get(_SMART_TOOLS_MANAGER_TOOL_KEY)
    return value if isinstance(value, bool) else None


def _smart_tools_manager_rule_value_from_payload(payload, workspace_key: str, editor_key: str):
    if not isinstance(payload, dict):
        return None
    n_panel = payload.get('n_panel')
    if isinstance(n_panel, dict):
        value = _smart_tools_manager_rule_value_from_rules(n_panel.get('rules'), workspace_key, editor_key)
        if value is not None:
            return value
    for key in ('rules', 'manager_rule_matrix', 'matrix'):
        value = _smart_tools_manager_rule_value_from_rules(payload.get(key), workspace_key, editor_key)
        if value is not None:
            return value
    # Some Manager builds return the rule matrix itself.
    return _smart_tools_manager_rule_value_from_rules(payload, workspace_key, editor_key)


def _smart_tools_manager_authoritative_cell(value, generation: str, revision: int):
    if not isinstance(value, dict):
        return None
    status = str(value.get('status') or '').upper()
    returned_generation = str(value.get('generation') or '')
    returned_revision = value.get('revision')
    enabled = value.get('enabled')
    if (
        status in {'READY', 'CURRENT', 'AUTHORITATIVE'}
        and returned_generation == generation
        and returned_revision == revision
        and isinstance(enabled, bool)
    ):
        return enabled
    return None


def refresh_smart_tools_manager_decision_snapshot(context=None) -> bool:
    """Capture one bounded Manager rule matrix outside draw/poll.

    The Manager's generation-bound public API may internally validate JSON, so
    this routine is called only from registration, load_post, and explicit UI
    refresh operations.  The native Panel.poll path performs one local mapping
    lookup and never invokes Manager code.  A missing or incomplete rule remains
    fail-open; bare legacy ``False`` is never authoritative.
    """
    del context
    global _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT
    record = _smart_tools_manager_module()
    if record is None:
        _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT = {
            'active': False, 'generation': '', 'revision': -1, 'decisions': {},
        }
        return True
    generation = str(record.get('generation') or '')
    revision = int(record.get('revision') or 0)
    api = record.get('public_api', {})
    decisions: dict[tuple[str, str], bool] = {}

    raw_snapshot = None
    snapshot_fn = api.get('get_rule_matrix_snapshot')
    if callable(snapshot_fn):
        try:
            candidate = snapshot_fn()
        except Exception:
            candidate = None
        if isinstance(candidate, dict):
            returned_generation = candidate.get('generation')
            returned_revision = candidate.get('revision')
            status = str(candidate.get('status') or '').upper()
            generation_ok = returned_generation in {None, '', generation}
            revision_ok = returned_revision in {None, revision}
            status_ok = not status or status in {'READY', 'CURRENT', 'AUTHORITATIVE', 'ACTIVE'}
            if generation_ok and revision_ok and status_ok:
                raw_snapshot = candidate

    editor_keys = (
        'VIEW_3D', 'IMAGE_EDITOR', 'UV_EDITOR', 'SHADER_EDITOR', 'COMPOSITOR',
        'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR', 'VIDEO_SEQUENCER',
        'MOVIE_CLIP_EDITOR', 'DOPE_SHEET', 'GRAPH_EDITOR', 'DRIVERS',
        'NLA_EDITOR', 'TEXT_EDITOR', 'ASSET_BROWSER', 'FILE_BROWSER', 'SPREADSHEET',
    )
    if isinstance(raw_snapshot, dict):
        for workspace_key in _SMART_TOOLS_MANAGER_WORKSPACE_ALIASES:
            for editor_key in editor_keys:
                value = _smart_tools_manager_rule_value_from_payload(
                    raw_snapshot, workspace_key, editor_key
                )
                if isinstance(value, bool):
                    decisions[(workspace_key, editor_key)] = value

    # Current-cell fallback remains explicit and bounded.  It is never reached
    # from Panel.poll and accepts only a generation/revision-bearing response.
    cell_fn = api.get('get_current_cell_rule') or api.get('current_cell_rule')
    if callable(cell_fn) and len(decisions) < _SMART_TOOLS_MANAGER_SNAPSHOT_MAX_CELLS:
        for workspace_key in _SMART_TOOLS_MANAGER_WORKSPACE_ALIASES:
            for editor_key in editor_keys:
                cell_key = (workspace_key, editor_key)
                if cell_key in decisions:
                    continue
                try:
                    value = cell_fn(workspace_key, editor_key, _SMART_TOOLS_MANAGER_TOOL_KEY)
                except Exception:
                    value = None
                enabled = _smart_tools_manager_authoritative_cell(value, generation, revision)
                if isinstance(enabled, bool):
                    decisions[cell_key] = enabled

    if len(decisions) > _SMART_TOOLS_MANAGER_SNAPSHOT_MAX_CELLS:
        decisions = dict(list(decisions.items())[:_SMART_TOOLS_MANAGER_SNAPSHOT_MAX_CELLS])
    _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT = {
        'active': True,
        'generation': generation,
        'revision': revision,
        'decisions': decisions,
    }
    return True


def _smart_tools_manager_allows_context(context) -> bool:
    """Return the current-cell decision from a local immutable snapshot only."""
    snapshot = _SMART_TOOLS_MANAGER_LOCAL_SNAPSHOT
    if not snapshot.get('active'):
        return True
    workspace_key = _smart_tools_manager_workspace_key(context)
    editor_key = _smart_tools_manager_editor_key_for_context(context)
    if not workspace_key or not editor_key:
        return True
    decisions = snapshot.get('decisions')
    if not isinstance(decisions, dict):
        return True
    value = decisions.get((workspace_key, editor_key))
    return value if isinstance(value, bool) else True



def _safe_nptl_panel_context(context):
    if context is None:
        return False
    if getattr(context, 'window_manager', None) is None:
        return False
    # Do not require context.scene here. During editor switches, file-browser
    # interaction, or same-session extension reloads Blender may evaluate Panel
    # poll with a transient context. Requiring a scene can leave the "Smart
    # Workspace" category selected but with no drawable panel. The draw code is
    # fully guarded and shows a recovery UI until normal settings are available.
    area_type = _smart_workspace_panel_area_type(context)
    if area_type and area_type not in _SMART_WORKSPACE_PANEL_SPACE_TYPE_SET:
        return False
    return True


def _pseudo_tab_active(context):
    del context
    return True


def _tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
        return
    except Exception:
        pass
    for region in getattr(area, "regions", ()):
        try:
            region.tag_redraw()
        except Exception:
            pass


def tag_redraw_all_properties_areas(context=None):
    # Compatibility name retained for callers. All supported Smart Workspace N-panel areas are redrawn; no alternate editor is patched or used as a host.
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    if wm is None:
        return
    for window in getattr(wm, 'windows', ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()):
            if getattr(area, 'type', None) in _SMART_WORKSPACE_PANEL_SPACE_TYPE_SET:
                _tag_redraw_area(area)


def _set_pseudo_tab_active(context, active: bool):
    del active
    try:
        _open_standard_npanel_category(context, _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY)
    except Exception:
        pass


def _toggle_pseudo_tab_active(context):
    _set_pseudo_tab_active(context, True)


def prepare_properties_pseudo_tab_panels():
    global _PSEUDO_TAB_PANELS_PREPARED
    _PSEUDO_TAB_PANELS_PREPARED = True
    return tuple(_PROPERTIES_PSEUDO_PANEL_CLASSES)


def install_properties_pseudo_tab_hack():
    prepare_properties_pseudo_tab_panels()
    tag_redraw_all_properties_areas(getattr(bpy, 'context', None))


def uninstall_properties_pseudo_tab_hack():
    tag_redraw_all_properties_areas(getattr(bpy, 'context', None))


def _draw_workspace_source_block(layout, context, st):
    active_ws_name = core._get_active_workspace_name(context) or '-'
    ws_label = '今のワークスペース' if is_japanese(context) else 'Current Workspace'

    cur_row = layout.split(factor=0.6, align=True)
    cur_row.label(text=ws_label)
    cur_row.label(text=active_ws_name, translate=False)

    src_row = layout.split(factor=0.6, align=True)
    src_row.label(text=('ペースト元' if is_japanese(context) else 'Paste Source'))

    src_name = ''
    try:
        src_name = st.workspace_ptr.name if st.workspace_ptr else ''
    except Exception:
        src_name = ''
    if not src_name:
        src_name = active_ws_name
    src_row.menu('NPTL_MT_workspace_menu', text=src_name, translate=False)



def _draw_quick_launcher_block(layout, context, prof):
    box = layout.box()
    ui_icons.label(box, text=('クイックアクセス' if is_japanese(context) else 'Quick Access'), name='launch', fallback='PLAY')

    row = box.row(align=True)
    row.scale_y = 1.35
    ui_icons.operator(row, 'nptl.launcher', text=_T('OP_POPUP'), name='launch', fallback='WINDOW')

    if prof is not None:
        box.label(
            text=(
                f"カテゴリー: {len(prof.categories)} / 検出タブ: {len(prof.detected_tabs)}"
                if is_japanese(context)
                else f"Categories: {len(prof.categories)} / Detected Tabs: {len(prof.detected_tabs)}"
            ),
            translate=False,
        )



def _smart_tools_region_width(context) -> int:
    try:
        region = getattr(context, 'region', None)
        return max(0, int(getattr(region, 'width', 0) or 0))
    except Exception:
        return 0



def _smart_tools_is_compact_width(context, *, threshold: int = 360) -> bool:
    width = _smart_tools_region_width(context)
    return bool(width) and width <= int(threshold)



def _draw_stacked_prop(layout, owner, prop_name: str, label: str) -> None:
    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    col.label(text=label)
    col.prop(owner, prop_name, text='')



def _compact_label(context, full_text: str, *, short_ja: str = '', short_en: str = '', threshold: int = 360) -> str:
    if not _smart_tools_is_compact_width(context, threshold=threshold):
        return str(full_text or '')
    if is_japanese(context):
        short = str(short_ja or '').strip()
        if short:
            return short
    short = str(short_en or '').strip()
    if short:
        return short
    return str(full_text or '')



def _draw_launcher_settings_block(layout, context, prof):
    if prof is None:
        layout.label(text='No profile')
        return
    _draw_stacked_prop(layout, prof, 'popup_width', ('ポップアップの幅（1列）' if is_japanese(context) else _T('PROP_WIDTH')))
    _draw_stacked_prop(layout, prof, 'popup_columns', ('ポップアップの列数' if is_japanese(context) else _T('PROP_COLUMNS')))
    _draw_stacked_prop(layout, prof, 'floating_height', _T('PROP_FLOAT_HEIGHT'))
    tab_layout_col = layout.column(align=True)
    try:
        tab_layout_col.use_property_split = False
        tab_layout_col.use_property_decorate = False
    except Exception:
        pass
    tab_layout_col.prop(prof, 'popup_use_tab_layout', text=('ランチャー内のタブ分け表示' if is_japanese(context) else _T('PROP_TAB_MODE')))



def _draw_category_editor_block(layout, context, prof):
    if prof is None:
        layout.label(text='No profile')
        return

    box = layout.box()

    row = box.row()
    row.template_list('NPTL_UL_category', '', prof, 'categories', prof, 'active_category_index', rows=4)
    col = row.column(align=True)
    ui_icons.set_large_icon_scale(col, 1.35)
    ui_icons.operator(col, 'nptl.manage_cats', name='plus', fallback='ADD', text='', emboss=False).action = 'ADD'
    ui_icons.operator(col, 'nptl.manage_cats', name='minus', fallback='REMOVE', text='', emboss=False).action = 'REMOVE'
    col.separator()
    ui_icons.operator(col, 'nptl.manage_cats', name='up', fallback='TRIA_UP', text='', emboss=False).action = 'UP'
    ui_icons.operator(col, 'nptl.manage_cats', name='down', fallback='TRIA_DOWN', text='', emboss=False).action = 'DOWN'

    if len(prof.categories) > 0 and 0 <= prof.active_category_index < len(prof.categories):
        active_cat = prof.categories[prof.active_category_index]
        sub = layout.box()
        header = sub.row(align=True)
        ui_icons.label(header, text=f"{_T('LABEL_CONTENTS')}:", name='panel', fallback='OUTLINER_COLLECTION')
        header.prop(active_cat, 'name', text='')

        row = sub.row()
        row.template_list('NPTL_UL_tab_content', '', active_cat, 'tabs', active_cat, 'active_tab_index', rows=4)
        col = row.column(align=True)
        ui_icons.set_large_icon_scale(col, 1.35)
        ui_icons.operator(col, 'nptl.manage_contents', name='minus', fallback='REMOVE', text='', emboss=False).action = 'REMOVE'
        col.separator()
        ui_icons.operator(col, 'nptl.manage_contents', name='up', fallback='TRIA_UP', text='', emboss=False).action = 'UP'
        ui_icons.operator(col, 'nptl.manage_contents', name='down', fallback='TRIA_DOWN', text='', emboss=False).action = 'DOWN'
        col.separator()
        settings_col = col.column(align=True)
        settings_col.operator_context = 'INVOKE_DEFAULT'
        settings_col.enabled = 0 <= active_cat.active_tab_index < len(active_cat.tabs)
        ui_icons.set_large_icon_scale(settings_col, 1.35)
        ui_icons.operator(settings_col, 'nptl.fp_edit_settings', name='settings', fallback='PREFERENCES', text='', emboss=False)

    add_row = layout.row()
    add_row.scale_y = 1.1
    add_row.operator(
        'nptl.manage_contents',
        text=_compact_label(context, _T('BTN_ADD_TAB'), short_ja='選択タブを追加', short_en='Add Selected Tab', threshold=360),
        **ui_icons.icon_kwargs('up', 'TRIA_UP'),
    ).action = 'ADD_FROM_POOL'



def _draw_pool_editor_block(layout, context, prof):
    if prof is None:
        layout.label(text='No profile')
        return

    box = layout.box()
    try:
        box.prop(prof, 'pool_mode', expand=True)
    except Exception:
        pass

    row = box.row()
    if getattr(prof, 'pool_mode', 'TABS') == 'PANELS':
        row.template_list('NPTL_UL_detected_panels', '', prof, 'detected_panels', prof, 'active_detected_panel_index', rows=8)
        col = row.column(align=True)
        ui_icons.set_large_icon_scale(col, 1.35)
        ui_icons.operator(col, 'nptl.refresh_panel_pool', name='refresh', fallback='FILE_REFRESH', text='', emboss=False)
    else:
        row.template_list('NPTL_UL_detected', '', prof, 'detected_tabs', prof, 'active_detected_index', rows=8)
        col = row.column(align=True)
        ui_icons.set_large_icon_scale(col, 1.35)
        ui_icons.operator(col, 'nptl.cleanup_unused_tabs', name='trash', fallback='TRASH', text='', emboss=False)
        col.separator()
        ui_icons.operator(col, 'nptl.manage_global_tabs', name='refresh', fallback='FILE_REFRESH', text='', emboss=False).action = 'REFRESH'
        col.separator()
        ui_icons.operator(col, 'nptl.manage_global_tabs', name='up', fallback='TRIA_UP', text='', emboss=False).action = 'UP'
        ui_icons.operator(col, 'nptl.manage_global_tabs', name='down', fallback='TRIA_DOWN', text='', emboss=False).action = 'DOWN'

        if len(prof.detected_tabs) > 0 and prof.active_detected_index < len(prof.detected_tabs):
            active_dt = prof.detected_tabs[prof.active_detected_index]
            subbox = box.box()
            r_row = subbox.row()
            r_row.label(text=_T('LABEL_RENAME_TAB'))
            r_row.prop(active_dt, 'custom_name', text='')

        row2 = box.row(align=True)
        row2.scale_y = 1.2
        ui_icons.operator(row2, 'nptl.manage_global_tabs', text=_T('BTN_APPLY'), name='check', fallback='CHECKMARK').action = 'APPLY'
        ui_icons.operator(row2, 'nptl.manage_global_tabs', text=_T('BTN_REPAIR'), name='repair', fallback='LOOP_BACK').action = 'REPAIR'



def _draw_io_block(layout, context):
    io_col = layout.column(align=True)
    io_col.operator_context = 'INVOKE_DEFAULT'
    ui_icons.operator(io_col, 'nptl.export_settings', text=_T('BTN_SAVE_EXT'), name='export', fallback='EXPORT')
    io_col.operator(
        'nptl.import_settings',
        text=_compact_label(context, _T('BTN_LOAD_EXT'), short_ja='設定読込', short_en='Load Settings', threshold=360),
        **ui_icons.icon_kwargs('import', 'IMPORT'),
    )



def _nptl_section_state_get(st, prop_name: str, default: bool = False) -> bool:
    try:
        if st is not None and hasattr(st, prop_name):
            return bool(getattr(st, prop_name))
    except Exception:
        pass
    return bool(default)


def _nptl_section_state_set(context, prop_name: str, value: bool) -> None:
    st = _nptl_settings(context)
    if st is None or not hasattr(st, prop_name):
        return
    try:
        setattr(st, prop_name, bool(value))
    except Exception:
        return
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass


class NPTL_OT_toggle_ui_section(Operator):
    bl_idname = 'nptl.toggle_ui_section'
    bl_label = 'Toggle UI Section'
    bl_options = {'INTERNAL'}

    prop_name: StringProperty(options={'SKIP_SAVE'})
    label: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or '').strip() or ui_pair('section', 'セクション', context)
        return ui_pair(
            f'Open or close the {label} section in the Smart Workspace N-panel. This only changes the display state of the section and does not execute the tools inside it.',
            f'Smart Workspace Nパネルの「{label}」セクションを開閉します。これは表示状態だけを切り替える操作で、セクション内のツールは実行しません。',
            context,
        )

    def execute(self, context):
        prop = str(self.prop_name or '').strip()
        st = _nptl_settings(context)
        if not prop or st is None or not hasattr(st, prop):
            return {'CANCELLED'}
        new_state = not bool(getattr(st, prop))
        _nptl_section_state_set(context, prop, new_state)
        return {'FINISHED'}


def _nptl_section_toggle_operator(row, prop_name: str, label: str, icon: str, *, text: str = '', emboss: bool = True, depress: bool = False):
    """Draw a section toggle, falling back to a static label if the operator is unavailable."""
    try:
        op = row.operator(
            'nptl.toggle_ui_section',
            text=text,
            icon=icon,
            emboss=emboss,
            depress=depress,
        )
        op.prop_name = str(prop_name)
        op.label = str(label)
        return op
    except Exception:
        try:
            row.label(text=(text if text else str(label or '')), icon=icon)
        except Exception:
            try:
                row.label(text=(text if text else str(label or '')))
            except Exception:
                pass
        return None


def _nptl_draw_section(layout, context, st, *, prop_name: str, label: str, icon: str, help_id: str, body_fn, default: bool = False):
    _nptl_force_enabled_layout(layout)
    expanded = _nptl_section_state_get(st, prop_name, default)
    box = layout.box()
    _nptl_force_enabled_layout(box)
    try:
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        pass
    header = box.row(align=True)
    try:
        header.use_property_split = False
        header.use_property_decorate = False
        header.scale_y = 1.0
    except Exception:
        pass

    _nptl_section_toggle_operator(
        header,
        prop_name,
        label,
        'TRIA_DOWN' if expanded else 'TRIA_RIGHT',
        text='',
        emboss=True,
        depress=expanded,
    )

    # Smart Transform format: the section icon is not a separate framed button.
    # It is drawn as the icon of the frameless text operator so the row reads:
    # foldout button / icon + section name / compact help button.
    _nptl_section_toggle_operator(
        header,
        prop_name,
        label,
        icon,
        text=label,
        emboss=False,
        depress=False,
    )
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    _draw_help_button(header, context, help_id, text=False)

    if not expanded:
        return False

    body = box.column(align=True)
    _nptl_force_enabled_layout(body)
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    try:
        body_fn(body, context)
    except Exception as exc:
        body.label(text=error_text(exc, 'Section draw failed', 'セクション描画に失敗', context), icon='ERROR')
    return True



def _draw_floating_window_lock_fallback_toggle(layout, context):
    """Always-available fallback UI for Floating Window Lock.

    This is used if the optional module draw function is unavailable.  It still
    exposes the core saved BoolProperty so the user can enable/disable the
    feature from the Floating Window Lock item instead of only seeing an error.
    """
    st = _nptl_settings(context)
    if st is None or not hasattr(st, 'floating_window_lock_enabled'):
        layout.label(text=ui_pair('Floating Window Lock setting is unavailable.', 'フローティングウィンドウ固定の設定を取得できません。', context), icon='ERROR')
        return
    col = layout.column(align=True)
    try:
        col.label(text=ui_pair('Floating Window Lock', 'フローティングウィンドウ固定', context), icon='WINDOW')
    except Exception:
        col.label(text=ui_pair('Floating Window Lock', 'フローティングウィンドウ固定', context))
    row = col.row(align=True)
    try:
        row.prop(st, 'floating_window_lock_enabled', text=ui_pair('Enable Floating Window Lock', 'フローティングウィンドウ固定を有効化', context), toggle=True)
    except Exception:
        row.prop(st, 'floating_window_lock_enabled', text=ui_pair('Enabled', '有効', context))
    try:
        enabled = bool(getattr(st, 'floating_window_lock_enabled', False))
        status = ui_pair('Current state: Enabled', '現在の状態: 有効', context) if enabled else ui_pair('Current state: Disabled', '現在の状態: 無効', context)
        col.label(text=status, icon='CHECKMARK' if enabled else 'X')
    except Exception:
        pass


def _nptl_draw_standard_child_section(layout, context, st, *, prop_name: str, label: str, help_id: str, body_fn, default: bool = False, header_fn=None):
    """Draw every non-top-level section with Blender's native panel API.

    ``panel_prop`` is the authoritative path because it binds the native thin
    chevron directly to the existing BoolProperty.  Blender therefore invokes
    the property's update callback when the user opens or closes the section,
    preserving the strict immediate-save and restart-restore contract.  The
    native ``panel`` fallback is used only when the bound RNA property is not
    available; custom disclosure icons and operator-emulated foldouts are never
    drawn here.
    """
    header = None
    body = None

    panel_prop = getattr(layout, 'panel_prop', None)
    if callable(panel_prop) and st is not None and hasattr(st, prop_name):
        try:
            header, body = layout.panel_prop(st, prop_name)
        except Exception:
            header = None
            body = None

    if header is None:
        panel = getattr(layout, 'panel', None)
        if callable(panel):
            try:
                panel_id = f"smart_workspace_suite_child_{prop_name}"
                default_open = _nptl_section_state_get(st, prop_name, default)
                header, body = layout.panel(
                    idname=panel_id,
                    default_closed=not bool(default_open),
                )
            except Exception:
                header = None
                body = None

    if header is None:
        try:
            layout.label(
                text=ui_pair(
                    f'{label} section is unavailable.',
                    f'{label} セクションを表示できません。',
                    context,
                ),
                icon='ERROR',
            )
        except Exception:
            pass
        return False

    try:
        header.label(text=label)
        if callable(header_fn):
            try:
                header_fn(header, context, st)
            except Exception:
                pass
        header.separator(factor=0.35)
        _draw_help_button(header, context, help_id, text=False)
    except Exception:
        pass

    if body is None:
        return False

    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    try:
        body_fn(body, context)
    except Exception as exc:
        body.label(text=error_text(exc, 'Section draw failed', 'セクション描画に失敗', context), icon='ERROR')
    return True


def _draw_always_on_toggles_body(layout, context):
    try:
        _ui_runtime = _draw_runtime_module('ui_runtime')
        draw_fn = getattr(_ui_runtime, 'draw_always_active_panel_body', None) if _ui_runtime is not None else None
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Always-on Toggles UI could not be drawn', '常時機能切り替えUIを描画できませんでした', context), icon='ERROR')
        return
    layout.label(text=ui_pair('Always-on Toggles UI is unavailable.', '常時機能切り替えUIを取得できません。', context), icon='ERROR')


def _draw_workspace_launcher_body(layout, context):
    st = _nptl_settings(context)
    prof = _nptl_profile(context)
    box = layout.box()
    _draw_workspace_source_block(box, context, st)
    copy_row = box.row()
    copy_row.operator('nptl.copy_workspace_profile', text=_T('BTN_COPY_PROFILE'), icon='DUPLICATE')
    quick = layout.box()
    _draw_quick_launcher_block(quick, context, prof)
    _draw_launcher_settings_block(layout, context, prof)


def _draw_categories_section_body(layout, context):
    _draw_category_editor_block(layout, context, _nptl_profile(context))


def _draw_panel_pool_section_body(layout, context):
    _draw_pool_editor_block(layout, context, _nptl_profile(context))


def _draw_smart_tools_settings_body(layout, context):
    prefs = core._addon_preferences(context)
    if prefs is None:
        layout.label(text=ui_pair('Settings are unavailable.', '設定を取得できません。', context), icon='ERROR')
        return
    try:
        preferences = _draw_runtime_module('preferences')
        draw_fn = getattr(preferences, 'draw_smart_tools_settings_ui', None) if preferences is not None else None
        if callable(draw_fn):
            draw_fn(layout, context, prefs)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Settings could not be drawn', '設定を描画できませんでした', context), icon='ERROR')
        return
    layout.label(text=ui_pair('Settings are unavailable.', '設定を取得できません。', context), icon='ERROR')


def _draw_presets_io_body(layout, context):
    _draw_io_block(layout, context)



def _draw_workspace_manager_section_body(layout, context):
    try:
        _workspace_manager = _draw_runtime_module('workspace_manager')
        if not hasattr(getattr(bpy, 'types', None).WindowManager, 'workspace_manager_settings'):
            layout.label(text=ui_pair('Workspace Manager is not initialized.', 'ワークスペース管理が初期化されていません。', context), icon='ERROR')
            layout.operator('nptl.repair_workspace_manager_runtime', text=ui_pair('Repair Workspace Manager', 'ワークスペース管理を修復', context), icon='FILE_REFRESH')
            return
        draw_fn = getattr(_workspace_manager, 'draw_workspace_manager_ui', None)
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Workspace Manager could not be drawn', 'ワークスペース管理を描画できませんでした', context), icon='ERROR')
        layout.operator('nptl.repair_workspace_manager_runtime', text=ui_pair('Repair Workspace Manager', 'ワークスペース管理を修復', context), icon='FILE_REFRESH')
        return
    layout.label(text=ui_pair('Workspace Manager is unavailable.', 'ワークスペース管理を取得できません。', context), icon='ERROR')


def _draw_n_panel_manager_body(layout, context):
    st = _nptl_settings(context)
    sections = (
        ('ui_show_section_workspace_launcher', ui_pair('Workspace & Launcher', 'ワークスペースとランチャー', context), ui_icons.fallback_icon('workspace', 'WORKSPACE'), 'workspace_launcher', _draw_workspace_launcher_body),
        ('ui_show_section_categories', ui_pair('Categories', 'カテゴリー', context), ui_icons.fallback_icon('folder', 'OUTLINER'), 'categories', _draw_categories_section_body),
        ('ui_show_section_panel_pool', ui_pair('Panel Pool', 'パネル一覧', context), ui_icons.fallback_icon('panel', 'MENU_PANEL'), 'panel_pool', _draw_panel_pool_section_body),
        ('ui_show_section_smart_tools_settings', ui_pair('Settings', '設定', context), ui_icons.fallback_icon('settings', 'PREFERENCES'), 'smart_tools_settings', _draw_smart_tools_settings_body),
        ('ui_show_section_presets_io', ui_pair('IO', '入出力', context), ui_icons.fallback_icon('folder', 'FILE_FOLDER'), 'presets_io', _draw_presets_io_body),
    )
    for prop_name, label, icon, help_id, body_fn in sections:
        _nptl_draw_standard_child_section(
            layout,
            context,
            st,
            prop_name=prop_name,
            label=label,
            help_id=help_id,
            body_fn=body_fn,
            default=False,
        )


def _ensure_viewport_optimizer_runtime_for_ui(context=None) -> bool:
    del context
    try:
        scene_type = getattr(getattr(bpy, 'types', None), 'Scene', None)
        return bool(scene_type is not None and hasattr(scene_type, 'smart_viewport_optimizer_settings'))
    except Exception:
        return False


def _ensure_workspace_step_reorder_runtime_for_ui(context=None) -> bool:
    del context
    try:
        return bool(hasattr(getattr(bpy, 'types', None), 'SMART_WORKSPACE_OT_set_workspace_step_reorder_enabled'))
    except Exception:
        return False


def _ensure_synchronize_workspaces_runtime_for_ui(context=None) -> bool:
    del context
    try:
        scene_type = getattr(getattr(bpy, 'types', None), 'Scene', None)
        return bool(scene_type is not None and hasattr(scene_type, 'sws_synchronize_workspaces_settings'))
    except Exception:
        return False


def _ensure_floating_window_lock_runtime_for_ui(context=None) -> bool:
    del context
    try:
        return bool(hasattr(getattr(bpy, 'types', None), 'SMART_WORKSPACE_OT_set_floating_window_lock_enabled'))
    except Exception:
        return False


def _draw_viewport_optimizer_section_body(layout, context):
    try:
        if not _ensure_viewport_optimizer_runtime_for_ui(context):
            layout.label(text=ui_pair('Viewport Optimization is not initialized.', 'ビューポート最適化が初期化されていません。', context), icon='ERROR')
            return
        _viewport_optimizer = _draw_runtime_module('smart_viewport_optimizer_plus')
        draw_fn = getattr(_viewport_optimizer, 'draw_smart_workspace_section', None) if _viewport_optimizer is not None else None
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Viewport Optimization could not be drawn', 'ビューポート最適化を描画できませんでした', context), icon='ERROR')
        return
    layout.label(text=ui_pair('Viewport Optimization is unavailable.', 'ビューポート最適化を取得できません。', context), icon='ERROR')


def _draw_panview_section_body(layout, context):
    try:
        panview = _draw_runtime_module('runtime.panview') or _PANVIEW_MODULE
        if panview is None or not bool(getattr(panview, '_PANVIEW_RUNTIME_ENABLED', False)):
            layout.label(text=ui_pair('2D Pan View is not initialized.', '2Dパンビューが初期化されていません。', context), icon='ERROR')
            return
        panview.draw_panview_ui(
            layout,
            context,
            show_launch_button=True,
            show_runtime_controls=False,
            show_window_manager=True,
        )
    except Exception as exc:
        layout.label(text=error_text(exc, '2D Pan View settings could not be drawn', '2Dパンビュー設定を描画できませんでした', context), icon='ERROR')


def _draw_local_ui_toggle_body(layout, context):
    space = _view3d_space_from_context(context)
    if space is None:
        layout.label(text=ui_pair('No active 3D View was found.', 'アクティブな3Dビューが見つかりません。', context), icon='ERROR')
        return
    is_visible = bool(getattr(space, 'show_region_toolbar', True))
    text_value = ui_pair('Hide Toolbar, Sidebar, and Header', 'ツールバー、サイドバー、ヘッダーを非表示', context) if is_visible else ui_pair('Show Toolbar, Sidebar, and Header', 'ツールバー、サイドバー、ヘッダーを表示', context)
    icon_key = 'hidden' if is_visible else 'eye'
    fallback = 'HIDE_ON' if is_visible else 'HIDE_OFF'
    row = layout.row(align=True)
    row.scale_y = 1.15
    ui_icons.operator(row, 'view3d.toggle_local_ui', text=text_value, name=icon_key, fallback=fallback)


def _draw_workspace_step_reorder_body(layout, context):
    try:
        if not _ensure_workspace_step_reorder_runtime_for_ui(context):
            layout.label(text=ui_pair('Workspace Step Reorder is not initialized.', 'ワークスペース順序移動が初期化されていません。', context), icon='ERROR')
            return
        _workspace_step_reorder = _draw_runtime_module('workspace_step_reorder')
        draw_fn = getattr(_workspace_step_reorder, 'draw_settings_ui', None) if _workspace_step_reorder is not None else None
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Workspace Step Reorder settings could not be drawn', 'ワークスペース順序移動設定を描画できませんでした', context), icon='ERROR')
        return
    layout.label(text=ui_pair('Workspace Step Reorder is unavailable.', 'ワークスペース順序移動を取得できません。', context), icon='ERROR')


def _draw_synchronize_workspaces_body(layout, context):
    try:
        if not _ensure_synchronize_workspaces_runtime_for_ui(context):
            layout.label(text=ui_pair('Synchronize Workspaces is not initialized.', 'ワークスペース同期が初期化されていません。', context), icon='ERROR')
            return
        _synchronize_workspaces = _draw_runtime_module('synchronize_workspaces')
        draw_fn = getattr(_synchronize_workspaces, 'draw_settings_ui', None) if _synchronize_workspaces is not None else None
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Synchronize Workspaces settings could not be drawn', 'ワークスペース同期設定を描画できませんでした', context), icon='ERROR')
        return
    layout.label(text=ui_pair('Synchronize Workspaces is unavailable.', 'ワークスペース同期を取得できません。', context), icon='ERROR')


def _draw_floating_window_lock_body(layout, context):
    try:
        if not _ensure_floating_window_lock_runtime_for_ui(context):
            layout.label(text=ui_pair('Floating Window Lock is not initialized.', 'フローティングウィンドウ固定が初期化されていません。', context), icon='ERROR')
            return
        _floating_window_lock = _draw_runtime_module('floating_window_lock')
        draw_fn = getattr(_floating_window_lock, 'draw_settings_ui', None) if _floating_window_lock is not None else None
        if callable(draw_fn):
            draw_fn(layout, context)
            return
    except Exception as exc:
        layout.label(text=error_text(exc, 'Floating Window Lock settings could not be drawn', 'フローティングウィンドウ固定設定を描画できませんでした', context), icon='ERROR')
        _draw_floating_window_lock_fallback_toggle(layout, context)
        return
    _draw_floating_window_lock_fallback_toggle(layout, context)


def _draw_integrated_tools_body(layout, context):
    st = _nptl_settings(context)
    sections = (
        ('ui_show_section_panview', ui_pair('2D Pan View', '2Dパンビュー', context), 'panview', _draw_panview_section_body, None, False),
        ('ui_show_section_local_ui_toggle', ui_pair('Viewport UI Toggle', 'ビューポートUI切替', context), 'local_ui_toggle', _draw_local_ui_toggle_body, None, False),
        ('ui_show_section_workspace_step_reorder', ui_pair('Workspace Step Reorder', 'ワークスペース順序移動', context), 'workspace_step_reorder', _draw_workspace_step_reorder_body, None, False),
        ('ui_show_section_synchronize_workspaces', ui_pair('Synchronize Workspaces', 'ワークスペース同期', context), 'synchronize_workspaces', _draw_synchronize_workspaces_body, None, False),
        ('ui_show_section_floating_window_lock', ui_pair('Floating Window Lock', 'フローティングウィンドウ固定', context), 'floating_window_lock', _draw_floating_window_lock_body, None, False),
    )
    for prop_name, label, help_id, body_fn, header_fn, default_open in sections:
        _nptl_draw_standard_child_section(
            layout,
            context,
            st,
            prop_name=prop_name,
            label=label,
            help_id=help_id,
            body_fn=body_fn,
            default=default_open,
            header_fn=header_fn,
        )



def _nptl_force_enabled_layout(layout):
    """Ensure Smart Workspace UI is drawn with the normal opaque Blender style."""
    try:
        layout.enabled = True
    except Exception:
        pass
    try:
        layout.active = True
    except Exception:
        pass
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _draw_smart_workspace_inline_header(layout, context):
    """Draw a stable in-body title so the visible UI never becomes header-only."""
    try:
        header = layout.row(align=True)
        try:
            header.scale_y = 1.12
            header.use_property_split = False
            header.use_property_decorate = False
        except Exception:
            pass
        try:
            ui_icons.label(header, text='Smart Workspace', name='workspace', fallback='WORKSPACE')
        except Exception:
            try:
                header.label(text='Smart Workspace', icon='WORKSPACE')
            except Exception:
                header.label(text='Smart Workspace')
        try:
            header.separator(factor=0.35)
        except Exception:
            pass
        try:
            _draw_help_button(header, context, 'runtime', text=False)
        except Exception:
            pass
        try:
            layout.separator(factor=0.45)
        except Exception:
            pass
    except Exception:
        try:
            layout.label(text='Smart Workspace', icon='WORKSPACE')
        except Exception:
            pass


def _draw_smart_workspace_recovery_ui(layout, context, exc=None):
    _nptl_force_enabled_layout(layout)
    try:
        layout = localized_layout(layout, context)
    except Exception:
        pass
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    try:
        box = layout.box()
        box.label(text=ui_pair('Smart Workspace UI recovery', 'Smart Workspace UI復旧表示', context), icon='ERROR')
        row = box.row(align=True)
        try:
            op = row.operator('nptl.toggle_ui_section', text=ui_pair('Open N-panel Manager', 'Nパネル管理を開く', context), icon='MENU_PANEL')
            op.prop_name = 'ui_show_section_n_panel_manager'
            op.label = 'N-panel Manager'
        except Exception:
            row.label(text=ui_pair('N-panel Manager', 'Nパネル管理', context), icon='MENU_PANEL')
        try:
            op = row.operator('nptl.toggle_ui_section', text=ui_pair('Open Viewport Optimization', 'ビューポート最適化を開く', context), icon='VIEW3D')
            op.prop_name = 'ui_show_section_viewport_optimization'
            op.label = 'Viewport Optimization'
        except Exception:
            row.label(text=ui_pair('Viewport Optimization', 'ビューポート最適化', context), icon='VIEW3D')
    except Exception:
        try:
            layout.label(text=ui_pair('Smart Workspace UI recovery', 'Smart Workspace UI復旧表示', context), icon='ERROR')
        except Exception:
            pass


def _draw_smart_workspace_static_section(layout, context, *, label: str, icon: str = 'NONE', message: str = '', help_id: str = ''):
    _nptl_force_enabled_layout(layout)
    """Draw a minimal section shell that never depends on add-on RNA state.

    Blender may keep a panel handler alive while a same-session extension update is
    replacing classes.  If a full section draw fails, this shell still produces a
    visible body so the Sidebar never degrades to a title-only panel.
    """
    try:
        box = layout.box()
    except Exception:
        try:
            layout.label(text=str(label or 'Smart Workspace'))
        except Exception:
            pass
        return
    try:
        row = box.row(align=True)
        try:
            row.label(text=str(label or 'Smart Workspace'), icon=str(icon or 'NONE'))
        except Exception:
            row.label(text=str(label or 'Smart Workspace'))
        if help_id:
            _draw_help_button(row, context, help_id, text=False)
        if message:
            try:
                box.label(text=str(message)[:180], icon='ERROR')
            except Exception:
                pass
    except Exception:
        try:
            box.label(text=str(label or 'Smart Workspace'))
        except Exception:
            pass


def _nptl_draw_section_guarded(layout, context, st, *, prop_name: str, label: str, icon: str, help_id: str, body_fn, default: bool = False):
    try:
        return _nptl_draw_section(
            layout,
            context,
            st,
            prop_name=prop_name,
            label=label,
            icon=icon,
            help_id=help_id,
            body_fn=body_fn,
            default=default,
        )
    except Exception as exc:
        try:
            _msg_head = ui_pair('Section draw failed', 'セクション描画に失敗', context)
        except Exception:
            _msg_head = 'Section draw failed'
        _draw_smart_workspace_static_section(
            layout,
            context,
            label=label,
            icon=icon,
            message=_msg_head,
            help_id=help_id,
        )
        return False


def _draw_smart_workspace_grouped_ui(layout, context):
    layout = localized_layout(layout, context)
    _nptl_force_enabled_layout(layout)
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    def _icon(name, fallback):
        try:
            return ui_icons.fallback_icon(name, fallback)
        except Exception:
            return fallback

    sections = (
        ('show_always_on_toggles', ui_pair('Always-on Toggles', '常時機能切り替え', context), _icon('clock', 'TIME'), 'always_on_toggles', _draw_always_on_toggles_body),
        ('ui_show_section_viewport_optimization', ui_pair('Viewport Optimization', 'ビューポート最適化', context), _icon('viewport', 'VIEW3D'), 'viewport_optimization', _draw_viewport_optimizer_section_body),
        ('ui_show_section_workspace_manager', ui_pair('Workspace Manager', 'ワークスペース管理', context), _icon('workspace', 'WORKSPACE'), 'workspace_manager', _draw_workspace_manager_section_body),
        ('ui_show_section_n_panel_manager', ui_pair('N-panel Manager', 'Nパネル管理', context), _icon('panel', 'MENU_PANEL'), 'n_panel_manager', _draw_n_panel_manager_body),
        ('ui_show_section_integrated_tools', ui_pair('Other Tools', 'その他ツール', context), _icon('tool', 'TOOL_SETTINGS'), 'integrated_tools', _draw_integrated_tools_body),
    )

    st = _nptl_settings(context)
    if st is None:
        try:
            layout.label(text=ui_pair('Smart Workspace settings are initializing.', 'Smart Workspace 設定を初期化中です。', context))
        except Exception:
            pass
        for _prop_name, label, icon, _help_id, _body_fn in sections:
            _draw_smart_workspace_static_section(layout, context, label=label, icon=icon, help_id=_help_id)
        return

    for prop_name, label, icon, help_id, body_fn in sections:
        _nptl_draw_section_guarded(
            layout,
            context,
            st,
            prop_name=prop_name,
            label=label,
            icon=icon,
            help_id=help_id,
            body_fn=body_fn,
            default=False,
        )


class NPTL_OT_toggle_properties_pseudo_tab(Operator):
    bl_idname = 'nptl.toggle_properties_pseudo_tab'
    bl_label = ADDON_TAB_NAME
    bl_description = 'Show the Smart Workspace controls in the standard 3D View Sidebar N-panel.'
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        return area is not None and getattr(area, 'type', None) == 'VIEW_3D'

    def execute(self, context):
        try:
            from . import prepare_runtime_for_use as _prepare_runtime_for_use
            _prepare_runtime_for_use(context, refresh_ui=True)
        except Exception:
            pass
        _toggle_pseudo_tab_active(context)
        return {'FINISHED'}


class NPTL_OT_open_help(Operator):
    bl_idname = 'smart_workspace_suite.open_help'
    bl_label = ui_pair('Help', 'ヘルプ')
    bl_description = ui_pair(
        'Open the detailed help popup for the selected Smart Workspace tool.',
        '選択した Smart Workspace ツールの詳細ヘルプをポップアップ表示します。',
    )
    bl_options = {'INTERNAL'}

    help_id: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            'Open a popup containing the function overview, usage, and detailed setting explanations for this tool.',
            'このツールの機能概要、使用方法、設定項目の詳細説明をポップアップで開きます。',
            context,
        )

    def invoke(self, context, event):
        del event
        try:
            from .. import help as _help
            prepare = getattr(_help, 'prepare_help_snapshot', None)
            if callable(prepare):
                prepare(str(self.help_id or 'runtime'))
            popup_width = int(getattr(_help, 'HELP_POPUP_DEFAULT_WIDTH_PX', 760) or 760)
        except Exception:
            popup_width = 760
        try:
            return context.window_manager.invoke_props_dialog(self, width=popup_width)
        except Exception:
            return self.execute(context)

    def draw(self, context):
        try:
            _help = _draw_runtime_module('help')
            if _help is None:
                raise RuntimeError('prepared help module is unavailable')
            popup_width = int(getattr(_help, 'HELP_POPUP_DEFAULT_WIDTH_PX', 760) or 760)
            _help.draw_help(self.layout, context, str(self.help_id or 'runtime'), popup_width=popup_width)
        except Exception as exc:
            layout = localized_layout(self.layout, context)
            layout.label(text=error_text(exc, 'Help could not be drawn', 'ヘルプを描画できませんでした', context), icon='ERROR')

    def execute(self, context):
        try:
            from .. import help as _help
            return _help.open_help_dialog(context, str(self.help_id or 'runtime'))
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Help could not be opened', 'ヘルプを開けませんでした', context))
            return {'CANCELLED'}


class _NPTLPropertiesRootPanelMixin:
    def draw_header_preset(self, context):
        _draw_help_button(self.layout, context, 'runtime', text=False)

    bl_label = ADDON_TAB_NAME
    bl_ui_units_x = 18
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    nptl_skip_detection = True
    _smart_workspace_panel_revision = '1.1.154'
    # Smart Tools Manager is consulted through a generation-bound snapshot
    # captured outside draw/poll. Smart Workspace registers native roots for
    # every supported physical editor space, so no cross-editor proxy is needed.
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_tools_manager_tool_key = _SMART_TOOLS_MANAGER_TOOL_KEY

    @classmethod
    def poll(cls, context):
        # The root panel is guarded for transient Blender contexts, but must also
        # obey Smart Tools Manager workspace/editor/window rules. If that Manager
        # marks Smart Workspace OFF for the current area, this native panel polls
        # false so the Smart Workspace N-panel tab is not shown there.
        return _safe_nptl_panel_context(context) and _smart_tools_manager_allows_context(context)

    def draw(self, context):
        try:
            layout = localized_layout(self.layout, context)
        except Exception:
            layout = self.layout
        try:
            # Keep the native Blender Sidebar panel appearance.  The previous
            # hidden-header + duplicate in-body title path could make the N-panel
            # body look disabled/semi-transparent on Blender 5.1 themes.
            try:
                layout.enabled = True
                layout.active = True
                layout.use_property_split = False
                layout.use_property_decorate = False
            except Exception:
                pass
            _draw_smart_workspace_grouped_ui(layout, context)
        except Exception as exc:
            try:
                _draw_smart_workspace_recovery_ui(layout, context, exc)
            except Exception:
                try:
                    layout.label(text=ui_pair('Smart Workspace UI could not be drawn.', 'Smart Workspace UIを描画できませんでした。', context), icon='ERROR')
                except Exception:
                    pass
        return None


class NPTL_PT_properties_root(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root'
    bl_space_type = 'VIEW_3D'


class NPTL_PT_properties_root_image_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_image_editor'
    bl_space_type = 'IMAGE_EDITOR'


class NPTL_PT_properties_root_node_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_node_editor'
    bl_space_type = 'NODE_EDITOR'


class NPTL_PT_properties_root_sequence_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_sequence_editor'
    bl_space_type = 'SEQUENCE_EDITOR'


class NPTL_PT_properties_root_clip_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_clip_editor'
    bl_space_type = 'CLIP_EDITOR'


class NPTL_PT_properties_root_dopesheet_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_dopesheet_editor'
    bl_space_type = 'DOPESHEET_EDITOR'


class NPTL_PT_properties_root_graph_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_graph_editor'
    bl_space_type = 'GRAPH_EDITOR'


class NPTL_PT_properties_root_nla_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_nla_editor'
    bl_space_type = 'NLA_EDITOR'


class NPTL_PT_properties_root_text_editor(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_text_editor'
    bl_space_type = 'TEXT_EDITOR'


class NPTL_PT_properties_root_file_browser(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_file_browser'
    bl_space_type = 'FILE_BROWSER'


class NPTL_PT_properties_root_spreadsheet(_NPTLPropertiesRootPanelMixin, Panel):
    bl_idname = 'NPTL_PT_properties_root_spreadsheet'
    bl_space_type = 'SPREADSHEET'


_SMART_WORKSPACE_ROOT_PANEL_REVISION = '1.1.154'
_SMART_WORKSPACE_ROOT_PANEL_DRAW = _NPTLPropertiesRootPanelMixin.draw
try:
    _SMART_WORKSPACE_ROOT_PANEL_DRAW._smart_workspace_draw_revision = _SMART_WORKSPACE_ROOT_PANEL_REVISION
except Exception:
    pass


def _restore_smart_workspace_root_panel_classes():
    """Validate static root declarations without mutating registered Panel RNA."""
    expected = (
        NPTL_PT_properties_root,
        NPTL_PT_properties_root_image_editor,
        NPTL_PT_properties_root_node_editor,
        NPTL_PT_properties_root_sequence_editor,
        NPTL_PT_properties_root_clip_editor,
        NPTL_PT_properties_root_dopesheet_editor,
        NPTL_PT_properties_root_graph_editor,
        NPTL_PT_properties_root_nla_editor,
        NPTL_PT_properties_root_text_editor,
        NPTL_PT_properties_root_file_browser,
        NPTL_PT_properties_root_spreadsheet,
    )
    valid = True
    for cls in expected:
        if (
            getattr(cls, 'bl_label', None) != ADDON_TAB_NAME
            or getattr(cls, 'bl_region_type', None) != 'UI'
            or getattr(cls, 'bl_category', None) != 'Smart Workspace'
            or getattr(cls, 'draw', None) is not _SMART_WORKSPACE_ROOT_PANEL_DRAW
        ):
            valid = False
            break
    if not valid:
        try:
            from .. import runtime_ledger as _runtime_ledger
            _runtime_ledger.mark_restart_required('ROOT_PANEL_STATIC_IDENTITY_MISMATCH')
        except Exception:
            pass
    return valid


_restore_smart_workspace_root_panel_classes()


class NPTL_PT_properties_always_active(Panel):
    bl_label = ui_pair('Always-on Toggles', '常時機能切り替え')
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_always_active'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        # The always-on group is drawn inside the root panel so it can follow
        # Smart Render's compact collapsible-box format.  Keep this class only
        # as a stale-registration guard for older sessions.
        return False

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            'Centralized enable/disable switches for Smart Workspace features that keep running in the background, such as handlers, timers, message-bus watchers, keymaps, draw overlays, live synchronization, and automatic restore behavior.',
            'ハンドラー、タイマー、メッセージバス監視、キーマップ、描画オーバーレイ、ライブ同期、自動復元など、バックグラウンドで動き続ける Smart Workspace 機能をまとめて有効 / 無効にします。',
            context,
        )

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        try:
            _ui_runtime = _draw_runtime_module('ui_runtime')
            draw_fn = getattr(_ui_runtime, 'draw_always_active_panel', None) if _ui_runtime is not None else None
            if callable(draw_fn):
                draw_fn(layout, context)
                return
        except Exception as exc:
            layout.label(text=error_text(exc, 'Always-on Toggles UI could not be drawn', '常時機能切り替えUIを描画できませんでした', context), icon='ERROR')
            return
        layout.label(text=ui_pair('Always-on Toggles UI is unavailable.', '常時機能切り替えUIを取得できません。', context), icon='ERROR')


class NPTL_PT_properties_workspace(Panel):
    bl_label = 'Workspace & Launcher'
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_workspace'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 10
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        st = _nptl_settings(context)
        prof = _nptl_profile(context)

        header = layout.row(align=True)
        ui_icons.label(header, text=ui_pair('Workspace & Launcher', 'ワークスペースとランチャー', context), name='workspace', fallback='WORKSPACE')
        _draw_help_button(header, context, 'workspace_launcher', text=True)

        box = layout.box()
        _draw_workspace_source_block(box, context, st)
        copy_row = box.row()
        copy_row.operator('nptl.copy_workspace_profile', text=_T('BTN_COPY_PROFILE'), icon='DUPLICATE')

        quick = layout.box()
        _draw_quick_launcher_block(quick, context, prof)
        _draw_launcher_settings_block(layout, context, prof)


class NPTL_PT_properties_categories(Panel):
    bl_label = 'Categories'
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_categories'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        ui_icons.label(header, text=ui_pair('Categories', 'カテゴリー', context), name='folder', fallback='OUTLINER')
        _draw_help_button(header, context, 'categories', text=True)
        _draw_category_editor_block(layout, context, _nptl_profile(context))


class NPTL_PT_properties_pool(Panel):
    bl_label = 'Panel Pool'
    bl_idname = 'NPTL_PT_properties_pool'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 30
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        ui_icons.label(header, text=ui_pair('Panel Pool', 'パネル一覧', context), name='panel', fallback='MENU_PANEL')
        _draw_help_button(header, context, 'panel_pool', text=True)
        _draw_pool_editor_block(layout, context, _nptl_profile(context))


class NPTL_PT_properties_runtime(Panel):
    bl_label = ui_pair('Settings', '設定')
    bl_idname = 'NPTL_PT_properties_runtime'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 35
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        prefs = core._addon_preferences(context)
        if prefs is None:
            layout.label(text=ui_pair('Settings are unavailable.', '設定を取得できません。', context), icon='ERROR')
            return
        try:
            preferences = _draw_runtime_module('preferences')
            draw_fn = getattr(preferences, 'draw_smart_tools_settings_ui', None) if preferences is not None else None
            if callable(draw_fn):
                draw_fn(layout, context, prefs)
                return
        except Exception as exc:
            layout.label(text=error_text(exc, 'Settings could not be drawn', '設定を描画できませんでした', context), icon='ERROR')
            return
        layout.label(text=ui_pair('Settings are unavailable.', '設定を取得できません。', context), icon='ERROR')



class NPTL_PT_properties_integrated_tools(Panel):
    bl_label = 'Other Tools'
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_integrated_tools'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 100
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            'Group for bundled Smart Workspace utility tools. 2D Pan View and local viewport UI controls are organized here at the bottom of the N-panel.',
            'Smart Workspace に同梱されたユーティリティをまとめるグループです。2DパンビューとローカルのビューポートUI操作を、Nパネル最下部でまとめて管理します。',
            context,
        )

    def draw(self, context):
        return None


class NPTL_PT_properties_panview(Panel):
    bl_label = '2D Pan View'
    bl_idname = 'NPTL_PT_properties_panview'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        ui_icons.label(header, text=ui_pair('2D Pan View', '2Dパンビュー', context), name='camera', fallback='VIEW_CAMERA')
        _draw_help_button(header, context, 'panview', text=True)
        try:
            panview = _draw_runtime_module('runtime.panview') or _PANVIEW_MODULE
            if panview is None:
                raise RuntimeError('prepared 2D Pan View module is unavailable')
            panview.draw_panview_ui(
                layout,
                context,
                show_launch_button=True,
                show_runtime_controls=False,
                show_window_manager=True,
            )
        except Exception as exc:
            layout.label(text=error_text(exc, '2D Pan View settings could not be drawn', '2Dパンビュー設定を描画できませんでした', context), icon='ERROR')



class NPTL_PT_properties_local_ui_toggle(Panel):
    bl_label = 'Viewport UI Toggle'
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_local_ui_toggle'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    @classmethod
    def description(cls, context, properties):
        return ui_pair(
            "Show or hide this 3D View area\'s toolbar, Sidebar, and header together. Use it when you want a cleaner local viewport without changing other workspaces or other 3D View areas.",
            '現在の3Dビュー領域のツールバー、サイドバー、ヘッダーをまとめて表示または非表示にします。他のワークスペースや他の3Dビュー領域を変えずに、作業中のビューポートだけをすっきり表示したい時に使います。',
            context,
        )

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        space = _view3d_space_from_context(context)
        if space is None:
            layout.label(text=ui_pair('No active 3D View was found.', 'アクティブな3Dビューが見つかりません。', context), icon='ERROR')
            return
        is_visible = bool(getattr(space, 'show_region_toolbar', True))
        text_value = ui_pair('Hide Toolbar, Sidebar, and Header', 'ツールバー、サイドバー、ヘッダーを非表示', context) if is_visible else ui_pair('Show Toolbar, Sidebar, and Header', 'ツールバー、サイドバー、ヘッダーを表示', context)
        icon_key = 'hidden' if is_visible else 'eye'
        fallback = 'HIDE_ON' if is_visible else 'HIDE_OFF'
        row = layout.row(align=True)
        row.scale_y = 1.15
        ui_icons.operator(row, 'view3d.toggle_local_ui', text=text_value, name=icon_key, fallback=fallback)


class NPTL_PT_properties_io(Panel):
    bl_label = 'IO'
    bl_ui_units_x = 18
    bl_idname = 'NPTL_PT_properties_io'
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Workspace'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 40
    nptl_skip_detection = True

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        header = layout.row(align=True)
        ui_icons.label(header, text=ui_pair('IO', '入出力', context), name='folder', fallback='FILE_FOLDER')
        _draw_help_button(header, context, 'presets_io', text=True)
        _draw_io_block(layout, context)


_PROPERTIES_PSEUDO_PANEL_CLASSES = [
    NPTL_PT_properties_root,
]


class NPTL_OT_repair_workspace_manager_runtime(Operator):
    bl_idname = 'nptl.repair_workspace_manager_runtime'
    bl_label = 'Repair Workspace Manager'
    bl_description = 'Explicitly rebuild Workspace Manager RNA, restore its saved state, and refresh its save-state list. This work is never performed from N-panel drawing.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            from .. import workspace_manager as _workspace_manager
            if not _workspace_manager.ensure_registered(context, refresh=True, restore=True):
                raise RuntimeError(ui_pair('Workspace Manager could not be registered. Restart Blender.', 'ワークスペース管理を登録できませんでした。Blender を再起動してください。', context))
            if not _workspace_manager.validate_runtime_ownership():
                raise RuntimeError(ui_pair('Workspace Manager registration is out of date. Restart Blender.', 'ワークスペース管理の登録が最新ではありません。Blender を再起動してください。', context))
            for _window in context.window_manager.windows:
                for _area in _window.screen.areas:
                    _area.tag_redraw()
            self.report({'INFO'}, ui_pair('Workspace Manager has been repaired.', 'ワークスペース管理を修復しました。', context))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'Workspace Manager validation failed', 'ワークスペース管理の検証に失敗しました', context))
            return {'CANCELLED'}


class NPTL_OT_copy_workspace_profile(Operator):
    bl_idname = "nptl.copy_workspace_profile"
    bl_label = "Paste to Current Workspace"
    bl_options = set()

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_COPY_PROFILE")

    def execute(self, context):
        if not hasattr(context.window_manager, "nptl_settings"):
            return {'CANCELLED'}
        st = context.window_manager.nptl_settings

        src_name = ""
        try:
            src_name = st.workspace_ptr.name if st.workspace_ptr else ""
        except:
            src_name = ""
        if not src_name:
            src_name = core._ws_name_from_key(getattr(st, "workspace_selector", ""))

        dst_name = core._get_active_workspace_name(context)
        if not src_name or not dst_name:
            return {'CANCELLED'}

        if src_name == dst_name:
            return {'FINISHED'}

        src_prof = core._get_or_create_profile(st, src_name)
        dst_prof = core._get_or_create_profile(st, dst_name)
        core._copy_profile_data(src_prof, dst_prof)

        core.save_config_to_file(
            context,
            verified_user_change=True,
            profile_names={dst_name},
        )

        core._on_workspace_activated(context, dst_name, apply_layout=True)
        core._sync_selector_to_active_workspace(context)

        self.report({'INFO'}, _T("MSG_COPIED"))
        core._tag_redraw_all_view3d(context)
        return {'FINISHED'}

class NPTL_OT_export_settings(Operator, ExportHelper):
    bl_idname = "nptl.export_settings"
    bl_label = "Export"
    bl_options = set()
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_SAVE")

    def invoke(self, context, event):
        if not str(getattr(self, "filepath", "") or "").strip():
            self.filepath = core.default_export_filepath()
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = str(getattr(self, 'filepath', '') or '').strip()
        if not filepath:
            filepath = core.default_export_filepath()
            self.filepath = filepath
        try:
            from .. import storage as _suite_storage
            live_current = core._nptl_current_payload(context)
            if not isinstance(live_current, dict) or not live_current:
                raise RuntimeError('N-panel settings are not available for export')
            base_revision, _base_writer = core._authority_identity(live_current)
            payload = _suite_storage._strict_json.finalize_current_payload(
                live_current,
                revision=max(1, int(base_revision or 0)),
                writer_id=_suite_storage._strict_json.new_writer_id('smart-workspace-export'),
                authority='memory',
            )
            directory = os.path.dirname(filepath)
            if directory:
                os.makedirs(directory, exist_ok=True)
            if _suite_storage._strict_json.durable_write_json(
                filepath,
                payload,
                validator=_suite_storage._strict_json.validate_current_payload,
                backup=True,
                expected_revision=int(payload['revision']),
                expected_writer_id=str(payload['writer_id']),
                expected_checksum=str(payload['payload_checksum']),
            ) is not True:
                raise OSError('Export atomic write did not verify')
            exported = _suite_storage._strict_json.read_json_document(filepath)
            exported, _legacy = _suite_storage._strict_json.validate_current_payload(
                exported,
                allow_legacy=False,
                source='explicit-export-readback',
            )
            for field in ('revision', 'writer_id', 'payload_checksum'):
                if exported.get(field) != payload.get(field):
                    raise OSError(f'Export readback {field} mismatch')
            self.report({'INFO'}, _T("MSG_SAVED"))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, error_text(exc, 'The settings file could not be processed', '設定ファイルを処理できませんでした', context))
            return {'CANCELLED'}

class NPTL_OT_import_settings(Operator, ImportHelper):
    bl_idname = "nptl.import_settings"
    bl_label = "Import"
    bl_options = set()
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        return _T_ctx(context, "DESC_LOAD")

    def invoke(self, context, event):
        if not str(getattr(self, "filepath", "") or "").strip():
            self.filepath = core.default_import_filepath()
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = str(getattr(self, 'filepath', '') or '').strip()
        if not filepath:
            default_path = core.default_import_filepath()
            if default_path and os.path.exists(default_path):
                filepath = default_path
                self.filepath = filepath
            else:
                self.report({'ERROR'}, ui_pair('Import file is not selected.', '読み込むファイルが選択されていません。', context))
                return {'CANCELLED'}
        committed = False
        before_current = None
        runtime_notices = []
        try:
            if not os.path.exists(filepath):
                raise FileNotFoundError(f'Import file not found: {filepath}')
            from .. import storage as _suite_storage
            document = _suite_storage._strict_json.read_json_document(filepath)
            parsed = _suite_storage.parse_explicit_settings_import(document)
            imported_current = parsed.get('current_payload')
            enabled = parsed.get('state_save_enabled')
            if not isinstance(imported_current, dict):
                raise ValueError('Imported settings contain no validated N-panel payload')

            before_current = core._nptl_current_payload(context)
            prepared = core._prepare_loaded_workspace_payload(imported_current)
            if not core._apply_loaded_data(
                context,
                prepared,
                require_materialized_readback=False,
                use_live_overlay=False,
            ):
                reason = str(getattr(core, '_LAST_NPTL_LOAD_ERROR', '') or 'N-panel import apply failed')
                raise RuntimeError(reason)
            if str(getattr(core, '_LAST_NPTL_LOAD_INFO', '') or ''):
                runtime_notices.append('n-panel-runtime-projection')

            if isinstance(enabled, bool):
                core._push_update_suspend()
                try:
                    context.window_manager.nptl_settings.n_panel_state_save_enabled = enabled
                finally:
                    core._pop_update_suspend()
                _suite_storage.set_n_panel_state_save_runtime_policy(enabled)
            committed_current = core._nptl_current_payload(context)
            if not isinstance(committed_current, dict) or not committed_current:
                raise RuntimeError('Imported N-panel settings did not materialize')
            from .. import persistence as _suite_persistence
            commit_result = _suite_persistence.commit_explicit_settings_transaction(
                context,
                committed_current,
                central_payload=None,
                state_save_enabled=enabled if isinstance(enabled, bool) else None,
                stage_local_sidecars=False,
                source='n-panel-ui-import',
                allow_unmaterialized_n_panel=True,
            )
            if not isinstance(commit_result, dict) or commit_result.get('success') is not True:
                raise OSError('Imported N-panel settings canonical commit failed')
            committed = True
            # Renaming and reordering no longer move the real Sidebar tabs by
            # themselves (_apply_sidebar_layout is a no-op for crash safety), so
            # the loaded arrangement reaches the N-panel only through the same
            # explicit Apply the button uses.  It also becomes the layout that
            # comes back after a restart.
            try:
                applied_profile = core._active_profile(context)
                if applied_profile is not None:
                    apply_stats = core.apply_sidebar_layout_now(context, applied_profile)
                    if apply_stats.get('failed'):
                        runtime_notices.append(f"sidebar-apply-failed:{apply_stats['failed']}")
            except Exception as apply_exc:
                runtime_notices.append(f'sidebar-apply:{type(apply_exc).__name__}:{apply_exc}')
            try:
                refresh_smart_tools_manager_decision_snapshot(context)
                refresh_workspace_ui_order_cache(context)
            except Exception as refresh_exc:
                runtime_notices.append(
                    f'ui-snapshot:{type(refresh_exc).__name__}:{refresh_exc}'
                )
            try:
                core._tag_redraw_all_view3d(context)
            except Exception as redraw_exc:
                runtime_notices.append(
                    f'workspace-redraw:{type(redraw_exc).__name__}:{redraw_exc}'
                )
            self.report({'INFO'}, _T("MSG_LOADED"))
            if runtime_notices:
                self.report(
                    {'INFO'},
                    ui_pair(
                        'Settings were committed. Controls unavailable in the current workspace or editor will materialize when that UI becomes available.',
                        '設定は正本へ保存されました。現在のワークスペースまたはエディターに存在しない項目は、そのUIが利用可能になった時点で反映されます。',
                        context,
                    ),
                )
            return {'FINISHED'}
        except Exception as exc:
            # Once strict primary/central adoption has verified, UI projection
            # cannot downgrade the user operation to CANCELLED.  Any remaining
            # post-commit issue is deferred until that workspace/editor exists.
            if committed:
                try:
                    self.report(
                        {'INFO'},
                        ui_pair(
                            'Settings were committed. Remaining UI projection was deferred.',
                            '設定は正本へ保存されました。残りのUI反映は利用可能になるまで延期されました。',
                            context,
                        ),
                    )
                except Exception:
                    pass
                return {'FINISHED'}
            try:
                if isinstance(before_current, dict) and before_current:
                    core._apply_loaded_data(
                        context,
                        core._prepare_loaded_workspace_payload(before_current),
                        require_materialized_readback=False,
                    )
            except Exception:
                pass
            try:
                from .. import persistence as _suite_persistence
                _suite_persistence.mark_deferred_settings_dirty()
            except Exception:
                pass
            self.report({'ERROR'}, error_text(exc, 'The settings file could not be processed', '設定ファイルを処理できませんでした', context))
            return {'CANCELLED'}

def update_category_event(self, context):
    # Compatibility no-op: Smart Workspace is drawn directly in the normal 3D View N-panel.
    return None


# -----------------------------------------------------------------------------
# Standard 3D View N-panel compatibility bridge
# -----------------------------------------------------------------------------
# Legacy API names are retained so old startup wrappers/keymaps do not fail, but
# they no longer create a custom host, clone panels, hide original panels,
# or create a floating Sidebar-only window.
from . import navigation_properties as _navigation_properties

_NPTL_ADDON_KEY = 'smart_workspace_suite'
_NPTL_TAB_LABEL = 'Smart Workspace'
_NPTL_TAB_TOOLTIP = "Show the Smart Workspace controls in the standard 3D View Sidebar N-panel."


def _standard_npanel_panel_classes():
    return tuple(cls for cls in tuple(_PROPERTIES_PSEUDO_PANEL_CLASSES or ()) if isinstance(cls, type))


def _standardize_npanel_panel_class(cls):
    """Compatibility no-op; never rewrite a Panel class at runtime.

    The eleven physical Blender editor Panel classes retain their declared
    space types and collectively expose the full body in all seventeen logical
    editors.  Live class field mutation is intentionally prohibited.
    """
    return cls if isinstance(cls, type) else None


def prepare_properties_pseudo_tab_panels():
    # Compatibility name.  Registration uses the statically declared native
    # Panel classes; no draw/poll/category/space/module attributes are changed.
    return _standard_npanel_panel_classes()


def _ordered_properties_pseudo_tab_panels():
    panels = []
    for index, cls in enumerate(_standard_npanel_panel_classes()):
        panels.append((index, cls))
    panels.sort(key=lambda item: (
        0 if not str(getattr(item[1], 'bl_parent_id', '') or '') else 1,
        int(getattr(item[1], 'bl_order', item[0]) or item[0]),
        item[0],
    ))
    return tuple(cls for _index, cls in panels)


def smart_tools_window_panel_classes():
    # Compatibility accessor; returns the direct N-panel classes.
    return _ordered_properties_pseudo_tab_panels()


def _pseudo_tab_active(context):
    del context
    return True


def _set_pseudo_tab_active(context, active: bool):
    del active
    try:
        _open_standard_npanel_category(context, _SMART_WORKSPACE_NATIVE_SIDEBAR_CATEGORY)
    except Exception:
        pass
    return None


def _toggle_pseudo_tab_active(context):
    _set_pseudo_tab_active(context, True)
    return None


def draw_smart_tools_window_contents(layout, context):
    # Compatibility fallback for external callers that pass an existing layout.
    # Drawing happens inside that layout only; no host window or UI styling is
    # created or modified.
    draw_panel_fn = getattr(_navigation_properties, '_draw_panel_class_fallback_contents', None)
    if not callable(draw_panel_fn):
        return 0
    drawn = 0
    for panel_cls in smart_tools_window_panel_classes():
        if drawn:
            try:
                layout.separator()
            except Exception:
                pass
        try:
            if bool(draw_panel_fn(layout, context, panel_cls)):
                drawn += 1
        except Exception:
            continue
    return drawn


def _register_direct_npanel_nav_entry() -> None:
    try:
        _navigation_properties.install(
            _NPTL_ADDON_KEY,
            _NPTL_TAB_LABEL,
            'PREFERENCES',
            'nptl.toggle_properties_pseudo_tab',
            (),
            order=110,
        )
    except Exception:
        pass


def refresh_properties_pseudo_tab_runtime(context=None, *, reinstall: bool = False):
    del reinstall
    prepare_properties_pseudo_tab_panels()
    _register_direct_npanel_nav_entry()
    try:
        tag_redraw_all_properties_areas(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return True


def install_properties_pseudo_tab_hack():
    prepare_properties_pseudo_tab_panels()
    _register_direct_npanel_nav_entry()
    try:
        tag_redraw_all_properties_areas(getattr(bpy, 'context', None))
    except Exception:
        pass
    return True


def uninstall_properties_pseudo_tab_hack():
    try:
        _navigation_properties.uninstall(_NPTL_ADDON_KEY)
    except Exception:
        pass
    try:
        tag_redraw_all_properties_areas(getattr(bpy, 'context', None))
    except Exception:
        pass
    return True


try:
    NPTL_OT_toggle_properties_pseudo_tab.bl_label = ADDON_TAB_NAME
    NPTL_OT_toggle_properties_pseudo_tab.bl_description = _NPTL_TAB_TOOLTIP
except Exception:
    pass
