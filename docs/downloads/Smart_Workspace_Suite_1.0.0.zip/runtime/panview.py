# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import bpy
from .. import storage as _suite_storage
from .. import runtime_ledger as _runtime_ledger
from .. import ui_icons
from .. import translation as _suite_translation
import json
from math import sqrt
import os
from .translation import localized_layout
import sys
import time
import webbrowser

# License
# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi.
# Licensed under the GNU General Public License v3.0 or later.
# ------------------------------------------------------------------------------

# =============================================================
# 0. Windows API 定義 (Windows環境でのみサイズ・位置変更機能を使用)
# =============================================================
if sys.platform == "win32":
    import ctypes

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


# =============================================================
# 0.5. 翻訳辞書 (Translation Dictionary)
# =============================================================
translation_dict = {
    "ja_JP": {
        ("*", "Launch a new 2D pan view. Includes 2D Pan/Zoom navigation, window management, presets, and camera guides."):
            "新規2Dパンビューを立ち上げるツール。2Dパン/ズーム操作、ウィンドウ管理、プリセット、カメラガイドを搭載。",
        ("*", "2D Pan View Launcher"): "2D Pan View Launcher",
        ("*", "Launch a dedicated camera window with 2D navigation and texture shading."):
            "2Dナビゲーションに最適化したカメラ専用ウィンドウを起動します。",

        # Core
        ("*", "Target Camera"): "ターゲットカメラ",
        ("*", "Select the camera to view."): "表示するカメラを選択してください。",
        ("*", "Launch View"): "ビューを起動",
        ("*", "Open a new window for the selected camera."): "選択したカメラのビューを起動します。",
        ("*", "Please select a camera."): "カメラを選択してください。",
        ("*", "View Launched."): "ビューを起動しました。",

        # Preferences
        ("*", "Tab Category"): "タブカテゴリー",
        ("*", "Change the N-panel tab name (Default: 2D Pan View Launcher)"):
            'Nパネルのタブ名を変更します (デフォルト: 2Dパンビュー Launcher)',
        ("*", "Enable Pie Hotkey"): "パイメニューのホットキーを有効化",
        ("*", "Register a default hotkey for the 2D Pan pie menu."): "2Dパン用パイメニューのデフォルトホットキーを登録します。",

        # Sections
        ("*", "View Settings"): "ビュー設定",
        ("*", "Window Settings"): "ウィンドウ設定",
        ("*", "Camera Guides"): "カメラガイド",
        ("*", "2D Navigation"): "2Dナビゲーション",
        ("*", "Presets"): "プリセット",
        ("*", "Window Manager"): "ウィンドウ管理",
        ("*", "2D Pan View is not available."): '2Dパンビューを使用できません。',
        ("*", "Wire Color"): "ワイヤーカラー",
        ("*", "Object Color"): "オブジェクトカラー",
        ("*", "Background"): "背景",

        # Window settings
        ("*", "Launch Mode"): "起動モード",
        ("*", "New Window"): "新規ウィンドウ",
        ("*", "Split Area"): "エリア分割",
        ("*", "Reuse Existing Window"): "既存ウィンドウを再利用",
        ("*", "If a window for this camera is already open, reuse it instead of creating a new one."):
            "同じカメラのウィンドウが既に開いている場合は新規作成せず再利用します。",
        ("*", "Follow Active Camera"): "アクティブカメラに追従",
        ("*", "When enabled, launched views follow the scene's active camera."):
            "ONのとき、起動したビューはシーンのアクティブカメラに追従します。",
        ("*", "Size Mode"): "サイズ方式",
        ("*", "Fraction of Parent"): "親ウィンドウ比率",
        ("*", "Pixels"): "ピクセル指定",
        ("*", "Render Resolution"): "レンダー解像度",
        ("*", "Window Fraction"): "ウィンドウ比率",
        ("*", "Window Width"): "ウィンドウ幅",
        ("*", "Window Height"): "ウィンドウ高さ",
        ("*", "Position Mode"): "配置方式",
        ("*", "Cursor Center"): "カーソル中心",
        ("*", "Parent Center"): "親ウィンドウ中央",
        ("*", "Screen Center"): "画面中央",
        ("*", "Top Left"): "左上",
        ("*", "Top Right"): "右上",
        ("*", "Bottom Left"): "左下",
        ("*", "Bottom Right"): "右下",
        ("*", "Hide UI (Full Area)"): "UIを非表示（全面化）",
        ("*", "Hide headers/panels and switch to full area like Ctrl+Alt+Space."):
            "ヘッダー/パネルを非表示にし、Ctrl+Alt+Space相当の全面化を行います。",
        ("*", "Show HUD (Active View)"): "HUD表示（アクティブビュー）",
        ("*", "Show a small on-screen hint overlay in the active 2D view."):
            "アクティブな2Dビューに小さなヒントHUDを表示します。",

        # Camera guides
        ("*", "Safe Areas"): "セーフエリア",
        ("*", "Toggle camera safe areas."): "カメラのセーフエリア表示を切り替えます。",
        ("*", "Passepartout"): "パスパートゥ",
        ("*", "Toggle camera passepartout."): "カメラのパスパートゥ表示を切り替えます。",
        ("*", "Passepartout Alpha"): "パスパートゥ不透明度",
        ("*", "Composition Guide"): "構図ガイド",
        ("*", "None"): "なし",
        ("*", "Thirds"): "三分割",
        ("*", "Center"): "センター",
        ("*", "Golden Ratio"): "黄金比",
        ("*", "Diagonals"): "対角線",

        # 2D navigation
        ("*", "Lock Rotation"): "ビューの回転をロック",
        ("*", "Lock the view rotation. Used to restrict to 2D panning."): "ビューの回転をロックします。2Dパン操作に制限するために使用します。",
        ("*", "Navigation Mode"): "ナビゲーション方式",
        ("*", "Pan Only"): "パンのみ",
        ("*", "Pan + Zoom"): "パン＋ズーム",
        ("*", "Pan Sensitivity"): "パン感度",
        ("*", "Zoom Sensitivity"): "ズーム感度",
        ("*", "Invert Zoom"): "ズーム反転",
        ("*", "Lock Zoom"): "ズームをロック",
        ("*", "Start 2D Nav"): "2Dナビ開始",
        ("*", "Fit"): "フィット",
        ("*", "1:1"): "1:1",
        ("*", "2:1"): "2:1",
        ("*", "Close Window"): "ウィンドウを閉じる",
        ("*", "Open Pie Menu"): "パイメニューを開く",

        # Presets
        ("*", "Save"): "保存",
        ("*", "Load"): "読込",
        ("*", "Apply to Open Views"): "開いているビューへ適用",

        # Manager
        ("*", "Refresh"): "更新",
        ("*", "Close"): "閉じる",
        ("*", "Close All"): "全て閉じる",
        ("*", "Update View"): "ビュー更新",
        ("*", "Focus"): "フォーカス",
        ("*", "No tracked windows."): "追跡中のウィンドウはありません。",
    }
}



translation_dict["ja_JP"].update({
    ("*", "Camera view is required."): "カメラビューが必要です。",
    ("*", "Could not focus the 2D View window. Use the operating-system window switcher."): "2Dビューのウィンドウにフォーカスできませんでした。OSのウィンドウ切替機能を使用してください。",
    ("*", "Reused existing window."): "既存のウィンドウを再利用しました。",
    ("*", "Run from a 3D View area."): "3Dビューエリアから実行してください。",
    ("*", "No VIEW_3D window region found."): "VIEW_3DのWINDOWリージョンが見つかりません。",
    ("*", "Area split failed."): "エリアの分割に失敗しました。",
    ("*", "No areas found in new window."): "新しいウィンドウにエリアが見つかりません。",
})
translation_dict["ja_JP"].update({
    ("*", "Initialize Presets"): "プリセットを初期化",
    ("*", "Name"): "名前",
    ("*", "Theme"): "テーマ",
    ("*", "Object"): "オブジェクト",
    ("*", "Random"): "ランダム",
    ("*", "Attribute"): "属性",
    ("*", "Texture"): "テクスチャ",
    ("*", "Custom"): "カスタム",
    ("*", "Background Color"): "背景色",
    ("*", "Outline Color"): "アウトライン色",
    ("*", "Wireframe Opacity"): "ワイヤー不透明度",
    ("*", "X-Ray Alpha"): "透過表示の不透明度",
    ("*", "Size Mode"): "サイズ方式",
    ("*", "Window Fraction"): "ウィンドウ比率",
    ("*", "Window Width"): "ウィンドウ幅",
    ("*", "Window Height"): "ウィンドウ高さ",
    ("*", "Parent Center"): "親ウィンドウ中央",

    ("*", "Start modal 2D navigation inside the active camera view. Drag to pan, and when zoom is enabled you can adjust framing without leaving the dedicated 2D view workflow."):
        "アクティブなカメラビュー内でモーダル2Dナビゲーションを開始します。ドラッグでパンし、ズーム有効時は専用2Dビューのまま画角調整できます。",
    ("*", "Reset the camera view offset and zoom as closely as Blender allows. Use this when the view drifted away from the camera frame and you want a clean fit again."):
        "Blenderが許す範囲でカメラビューのオフセットとズームを初期状態へ戻します。フレームからずれたときに整え直す用途です。",
    ("*", "Set the camera view close to a 1:1 zoom level when the current Blender version supports it. Useful for texture inspection and pixel-aligned checks."):
        "現在のBlenderが対応している場合、カメラビューを1:1に近いズームへ設定します。テクスチャ確認やピクセル単位のチェックに便利です。",
    ("*", "Zoom the camera view in further to an approximately 2:1 level. Useful when you want to inspect small texture details without manually adjusting the view."):
        "カメラビューをおよそ2:1相当まで拡大します。小さなテクスチャディテールを手動調整なしで確認したいときに便利です。",
    ("*", "Close the currently active 2D Pan View window. Use this when you are done with the detached view and want to clean up your workspace."):
        '現在アクティブな2Dパンビューウィンドウを閉じます。分離ビューが不要になったときの片付け用です。',
    ("*", "Open the 2D Pan pie menu for quick access to the most common navigation commands. This is handy when you prefer radial menus over the panel buttons."):
        '主要なナビゲーション操作へ素早くアクセスできる2Dパンパイメニューを開きます。パネルボタンよりラジアル操作を好む場合に便利です。',
    ("*", "Create the default set of preset slots. Do this once before saving preset configurations if the preset area is still empty."):
        "既定のプリセットスロット一式を作成します。プリセット領域が空のままなら、最初に一度これを実行してから保存します。",
    ("*", "Save the current 2D Pan View settings into the selected preset slot. This stores your view, guide, and navigation preferences for quick reuse."):
        '現在の2Dパンビュー設定を選択中プリセットへ保存します。ビュー、ガイド、ナビゲーション設定をまとめて再利用できます。',
    ("*", "Load the settings stored in the selected preset slot. You can also choose to push the loaded settings to currently open tracked 2D views."):
        "選択中プリセットに保存された設定を読み込みます。必要に応じて、現在開いている追跡中の2Dビューにも反映できます。",
    ("*", "Send the current scene settings to all tracked 2D view windows. Use this after changing overlays, guides, or navigation preferences and you want every open view to match."):
        "現在のシーン設定をすべての追跡中2Dビューへ送ります。オーバーレイ、ガイド、ナビ設定を変更したあと、全ウィンドウを揃えたいときに使います。",
    ("*", "Refresh the tracked window list and remove entries for windows that are no longer available. Use this when the window manager list looks out of date."):
        "追跡ウィンドウ一覧を更新し、すでに存在しないウィンドウ項目を取り除きます。管理リストが古そうなときに使います。",
    ("*", "Close the selected tracked 2D view window from the manager list. This is the per-window cleanup command."):
        "管理リストで選択した追跡中2Dビューウィンドウを閉じます。個別に片付けたいときのコマンドです。",
    ("*", "Close every tracked 2D view window at once. Useful when you want to reset your layout or finish a session quickly."):
        "追跡中の2Dビューウィンドウをすべて一度に閉じます。レイアウトをリセットしたいときや作業終了時に便利です。",
    ("*", "Try to bring the selected tracked 2D view window to the front and focus it. Use this to jump back to a detached view without searching for it manually."):
        "選択した追跡中2Dビューウィンドウを前面に出してフォーカスしようとします。分離ビューを手で探さず戻りたいときに使います。",
    ("*", "Create a dedicated 2D Pan View for the selected camera using the current launch, size, guide, and navigation settings."):
        '現在の起動、サイズ、ガイド、ナビゲーション設定を使って、選択カメラ用の専用2Dパンビューを作成します。',

    ("*", "Name of this preset slot. Give it a descriptive label so you can tell what setup it stores."):
        "このプリセットスロットの名前です。どんな設定を保存しているか分かる名前にすると管理しやすくなります。",
    ("*", "Choose how the new 2D view window size is calculated. Fraction uses part of the parent window, Pixels uses exact width and height, and Render Resolution matches the current output resolution."):
        "新しい2Dビューウィンドウのサイズ計算方法です。親比率は親ウィンドウの一部、ピクセル指定は正確な幅高さ、レンダー解像度は現在の出力解像度に合わせます。",
    ("*", "Fraction of the parent window used when Size Mode is set to Fraction of Parent. For example, 0.5 creates a window about half the parent size."):
        "サイズ方式が『親ウィンドウ比率』のときに使う比率です。たとえば0.5なら親ウィンドウの約半分サイズになります。",
    ("*", "Exact width of the new 2D view window when Size Mode is set to Pixels."):
        "サイズ方式が『ピクセル指定』のときに使う新規2Dビューウィンドウの幅です。",
    ("*", "Exact height of the new 2D view window when Size Mode is set to Pixels."):
        "サイズ方式が『ピクセル指定』のときに使う新規2Dビューウィンドウの高さです。",
    ("*", "Choose where the new 2D view window appears on screen. Cursor Center is the most direct option, while the corner modes are useful for repeatable layouts."):
        "新しい2Dビューウィンドウを画面のどこへ出すか選びます。カーソル中央は直感的で、四隅配置は毎回同じレイアウトにしたい場合に便利です。",
    ("*", "Opacity of the dark area outside the camera frame. Increase it to focus more strongly on the visible frame area."):
        "カメラフレーム外側の暗い領域の不透明度です。大きくすると、見えているフレーム範囲へより集中しやすくなります。",
    ("*", "Overlay a composition guide on the camera view. This helps with framing and layout while you work inside the 2D window."):
        "カメラビューに構図ガイドを重ねて表示します。2Dウィンドウ内で構図や配置を確認しながら作業しやすくなります。",
    ("*", "Choose whether the 2D navigation tool allows only panning or both panning and zooming."):
        "2Dナビゲーションツールでパンのみ許可するか、パンとズームの両方を許可するか選びます。",
    ("*", "How strongly mouse movement affects panning in the 2D navigation mode."):
        "2Dナビゲーション時に、マウス移動がパン量へどれだけ影響するかを調整します。",
    ("*", "How strongly mouse movement affects zooming in the 2D navigation mode."):
        "2Dナビゲーション時に、マウス移動がズーム量へどれだけ影響するかを調整します。",
    ("*", "Reverse the zoom direction in 2D navigation if the default motion feels backwards to you."):
        "標準のズーム方向が逆に感じる場合、2Dナビゲーション時のズーム方向を反転します。",
    ("*", "Prevent zoom changes during 2D navigation. This is useful when you only want to pan the framing."):
        "2Dナビゲーション中のズーム変更を禁止します。構図をパンだけで調整したい場合に便利です。",
    ("*", "Index of the currently selected preset slot. This is managed automatically by the preset UI."):
        "現在選択中のプリセットスロット番号です。通常はプリセットUIから自動的に管理されます。",
})

# =============================================================
# 1. 共通ヘルパー
# =============================================================

_ADDON_KEYMAPS = []
_follow_handler_registered = False
_follow_last_time = 0.0
_PANVIEW_RUNTIME_ENABLED = False


_suite_translation.add_ui_pairs(translation_dict["ja_JP"])

# Blender's catalog answers before add-on tables in its default context.  These
# choices use their own context so the table above decides their wording.
_PANVIEW_ENUM_CONTEXT = "SmartWorkspacePanView"
translation_dict["ja_JP"].update({
    (_PANVIEW_ENUM_CONTEXT, key[1]): value
    for key, value in tuple(translation_dict["ja_JP"].items())
})


def pgettext(text: str) -> str:
    try:
        # Blender's own catalog is consulted before add-on tables, so this
        # feature's wording is looked up first.
        if _suite_translation.is_japanese():
            own = translation_dict['ja_JP'].get(('*', text))
            if own:
                return own
        return bpy.app.translations.pgettext(text)
    except Exception:
        return text


def safe_set(obj, attr, val):
    try:
        if hasattr(obj, attr):
            setattr(obj, attr, val)
    except Exception:
        pass


def get_view3d_area_region(window):
    """Return (area, region_window) for first VIEW_3D area in a window."""
    if not window or not window.screen:
        return None, None
    for area in window.screen.areas:
        if area.type == 'VIEW_3D':
            region = None
            for r in area.regions:
                if r.type == 'WINDOW':
                    region = r
                    break
            return area, region
    return None, None


def get_parent_rect_win32():
    if sys.platform != "win32":
        return None
    try:
        user32 = ctypes.windll.user32
        hwnd_parent = user32.GetActiveWindow()
        rect = RECT()
        user32.GetWindowRect(hwnd_parent, ctypes.byref(rect))
        return rect
    except Exception:
        return None


def get_cursor_pos_win32():
    if sys.platform != "win32":
        return None
    try:
        user32 = ctypes.windll.user32
        pt = POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y
    except Exception:
        return None


def get_screen_size_win32():
    if sys.platform != "win32":
        return None
    try:
        user32 = ctypes.windll.user32
        w = user32.GetSystemMetrics(0)
        h = user32.GetSystemMetrics(1)
        return int(w), int(h)
    except Exception:
        return None


# Blender の Window から OS の窓を引く API が無いので、作った時の窓ハンドルを控える。
_PANVIEW_WINDOW_HWNDS: dict[str, int] = {}


def _focus_native_window(window_ptr) -> bool:
    if sys.platform != "win32":
        return False
    hwnd = _PANVIEW_WINDOW_HWNDS.get(str(window_ptr))
    if not hwnd:
        return False
    user32 = ctypes.windll.user32
    if not user32.IsWindow(hwnd):
        _PANVIEW_WINDOW_HWNDS.pop(str(window_ptr), None)
        return False
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.BringWindowToTop(hwnd)
    return bool(user32.SetForegroundWindow(hwnd))


def set_window_pos_win32(hwnd, x, y, w, h):
    if sys.platform != "win32":
        return
    try:
        user32 = ctypes.windll.user32
        # SWP_NOZORDER(0x0004) | SWP_SHOWWINDOW(0x0040)
        user32.SetWindowPos(hwnd, 0, int(x), int(y), int(w), int(h), 0x0004 | 0x0040)
    except Exception:
        pass


def find_new_window(pre_ptrs):
    wm = bpy.context.window_manager
    for w in wm.windows:
        ptr = w.as_pointer()
        if ptr not in pre_ptrs:
            return w
    return None


def cleanup_tracked_windows(wm):
    valid_ptrs = {str(w.as_pointer()) for w in wm.windows}
    for ptr in tuple(_PANVIEW_WINDOW_HWNDS):
        if ptr not in valid_ptrs:
            del _PANVIEW_WINDOW_HWNDS[ptr]
    removed = False
    for i in range(len(wm.panview_tracked_windows) - 1, -1, -1):
        if wm.panview_tracked_windows[i].window_ptr not in valid_ptrs:
            wm.panview_tracked_windows.remove(i)
            removed = True
    if removed:
        try:
            _refresh_runtime_hooks(getattr(bpy, 'context', None))
        except Exception:
            pass
    return removed


def camera_apply_guides(cam_obj, scene):
    if not cam_obj or cam_obj.type != 'CAMERA':
        return
    cam = cam_obj.data

    safe_set(cam, "show_safe_areas", scene.panview_show_safe_areas)
    safe_set(cam, "show_passepartout", scene.panview_show_passepartout)
    safe_set(cam, "passepartout_alpha", scene.panview_passepartout_alpha)

    # Reset known composition guides safely, then enable selected
    guide = scene.panview_composition_guide
    # These exist in modern Blender; safe_set protects older changes.
    for attr in (
        "show_composition_thirds",
        "show_composition_center",
        "show_composition_golden",
        "show_composition_diagonal",
    ):
        safe_set(cam, attr, False)

    if guide == 'THIRDS':
        safe_set(cam, "show_composition_thirds", True)
    elif guide == 'CENTER':
        safe_set(cam, "show_composition_center", True)
    elif guide == 'GOLDEN':
        safe_set(cam, "show_composition_golden", True)
    elif guide == 'DIAGONALS':
        safe_set(cam, "show_composition_diagonal", True)


def apply_space_settings(space, scene, camera_obj):
    """Apply overlay/shading/camera view settings to a SpaceView3D."""
    if not space or space.type != 'VIEW_3D':
        return

    # Camera view
    safe_set(space, "use_local_camera", True)
    safe_set(space, "camera", camera_obj)
    safe_set(space.region_3d, "view_perspective", 'CAMERA')
    safe_set(space.region_3d, "lock_rotation", scene.panview_lock_rotation)

    # Overlay
    safe_set(space.overlay, "show_overlays", scene.panview_show_overlays)
    safe_set(space.overlay, "show_wireframes", scene.panview_show_wireframes)
    safe_set(space.overlay, "wireframe_opacity", scene.panview_wireframe_opacity)

    # Shading
    safe_set(space.shading, "type", 'SOLID')
    safe_set(space.shading, "show_xray", scene.panview_show_xray)
    safe_set(space.shading, "xray_alpha", scene.panview_xray_alpha)
    safe_set(space.shading, "wire_color_type", scene.panview_wire_color_type)
    safe_set(space.shading, "color_type", scene.panview_color_type)
    safe_set(space.shading, "background_type", scene.panview_background_type)
    if scene.panview_background_type == 'VIEWPORT':
        safe_set(space.shading, "background_color", scene.panview_background_color)
    safe_set(space.shading, "show_object_outline", scene.panview_show_object_outline)
    safe_set(space.shading, "object_outline_color", scene.panview_object_outline_color)


def resolve_panview_camera(scene, tracked_entry=None):
    """Resolve the camera Smart Tools should use.

    Explicit Target Camera selection always has priority so the launched / updated
    2D view matches the camera chosen in the UI. When no explicit target is set,
    Follow Active Camera continues to use the scene camera.
    """
    if scene is None:
        return None

    target = getattr(scene, 'panview_camera_target', None)
    if target is not None and getattr(target, 'type', None) == 'CAMERA':
        return target

    if bool(getattr(scene, 'panview_follow_active_camera', False)):
        active = getattr(scene, 'camera', None)
        if active is not None and getattr(active, 'type', None) == 'CAMERA':
            return active

    if tracked_entry is not None:
        try:
            name = str(getattr(tracked_entry, 'camera_name', '') or '')
        except Exception:
            name = ''
        if name:
            cam = bpy.data.objects.get(name)
            if cam is not None and getattr(cam, 'type', None) == 'CAMERA':
                return cam

    active = getattr(scene, 'camera', None)
    if active is not None and getattr(active, 'type', None) == 'CAMERA':
        return active
    return None


def deferred_window_setup_for(window_ptr, scene_name="", camera_name="", attempts=0):
    """Finalize a newly created detached Pan View window after Blender has finished
    creating its regions. This reapplies the intended camera and optional UI hiding.
    """
    if not _PANVIEW_RUNTIME_ENABLED:
        return None
    wm = getattr(bpy.context, 'window_manager', None)
    target_window = None
    for w in getattr(wm, 'windows', ()):
        if w.as_pointer() == window_ptr:
            target_window = w
            break
    if not target_window:
        return None

    scene = None
    if scene_name:
        try:
            scene = bpy.data.scenes.get(scene_name)
        except Exception:
            scene = None
    if scene is None:
        scene = getattr(getattr(target_window, 'screen', None), 'scene', None) or getattr(bpy.context, 'scene', None)

    camera_obj = None
    if camera_name:
        try:
            camera_obj = bpy.data.objects.get(camera_name)
        except Exception:
            camera_obj = None
    if camera_obj is None:
        camera_obj = resolve_panview_camera(scene)

    area, _region = get_view3d_area_region(target_window)
    if not area:
        if attempts < 20:
            return 0.05
        return None

    if camera_obj is not None:
        try:
            apply_settings_to_window(target_window, scene, camera_obj)
        except Exception:
            if attempts < 20:
                return 0.05

    try:
        for space in area.spaces:
            if space.type == 'VIEW_3D' and scene is not None and bool(getattr(scene, 'panview_hide_ui_fullarea', False)):
                space.show_region_header = False
                space.show_region_ui = False
                space.show_region_toolbar = False
    except Exception:
        pass

    return None

# =============================================================
# 2. HUD (アクティブビューのみ)
# =============================================================

_hud_handle = None
_HUD_BLF_MODULE = None


def _prepare_hud_draw_runtime() -> bool:
    """Load the Blender font module before installing the draw callback."""
    global _HUD_BLF_MODULE
    if _HUD_BLF_MODULE is not None:
        return True
    try:
        import blf as _blf
    except Exception:
        return False
    _HUD_BLF_MODULE = _blf
    return True


def _draw_hud():
    if not _PANVIEW_RUNTIME_ENABLED:
        return
    # Active context only (simple, robust)
    try:
        ctx = bpy.context
        if not ctx or not ctx.area or ctx.area.type != 'VIEW_3D':
            return
        if not ctx.region or ctx.region.type != 'WINDOW':
            return
        scene = ctx.scene
        if not scene or not _hud_allowed(ctx, scene):
            return
        space = ctx.space_data
        if not space or space.type != 'VIEW_3D':
            return
        rv3d = ctx.region_data
        if not rv3d or rv3d.view_perspective != 'CAMERA':
            return
        if not getattr(space, "use_local_camera", False):
            return

        # Immutable draw replay only.  blf is prepared by hud_enable().
        blf = _HUD_BLF_MODULE
        if blf is None:
            return
        font_id = 0
        # Bottom left: the top left already holds Blender's view name.
        x, y = 16, 16
        for region in ctx.area.regions:
            if region.type == 'TOOLS':
                x += region.width
        blf.position(font_id, x, y, 0)
        blf.size(font_id, 12)
        blf.draw(font_id, _suite_translation.ui_pair(
            "2D Pan View  |  MMB:Pan  Wheel:Zoom  |  Pie: Panel Button",
            "2Dパンビュー  |  中ボタン：移動  ホイール：ズーム  |  パイ：パネルのボタン",
            ctx,
        ))

    except Exception:
        return


def _hud_allowed(context, scene) -> bool:
    # The always-on toggle decides.  The Scene value differs per Scene and can be
    # left over from a saved file or preset.
    del scene
    wm = getattr(context, 'window_manager', None)
    return bool(getattr(wm, 'sws_always_panview_show_hud', False))


def hud_enable():
    global _hud_handle
    if _hud_handle is not None:
        return
    if not _prepare_hud_draw_runtime():
        return
    try:
        _hud_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_hud, (), 'WINDOW', 'POST_PIXEL')
    except Exception:
        _hud_handle = None


def hud_disable():
    global _hud_handle
    if _hud_handle is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_hud_handle, 'WINDOW')
    except Exception:
        pass
    _hud_handle = None


def _has_live_panview_spaces(context=None) -> bool:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        try:
            wm = getattr(bpy.context, 'window_manager', None)
        except Exception:
            wm = None
    if wm is None:
        return False
    for window in getattr(wm, 'windows', ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            try:
                space = area.spaces.active
            except Exception:
                space = None
            if space is None or getattr(space, 'type', None) != 'VIEW_3D':
                continue
            rv3d = getattr(space, 'region_3d', None)
            if rv3d is None:
                continue
            if getattr(rv3d, 'view_perspective', '') != 'CAMERA':
                continue
            if bool(getattr(space, 'use_local_camera', False)):
                return True
    return False


def _refresh_runtime_hooks(context=None) -> None:
    global _follow_handler_registered
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    tracked_count = 0
    if wm is not None:
        try:
            tracked_count = len(getattr(wm, 'panview_tracked_windows', ()) or ())
        except Exception:
            tracked_count = 0
    session_active = bool(tracked_count) or _has_live_panview_spaces(ctx)
    should_hud = bool(_PANVIEW_RUNTIME_ENABLED and session_active and scene is not None and _hud_allowed(ctx, scene))
    should_follow = bool(_PANVIEW_RUNTIME_ENABLED and session_active and scene is not None and getattr(scene, 'panview_follow_active_camera', False))

    if should_hud:
        hud_enable()
    else:
        hud_disable()

    if should_follow and not _follow_handler_registered:
        try:
            bpy.app.handlers.depsgraph_update_post.append(_depsgraph_follow_handler)
            _follow_handler_registered = True
        except Exception:
            _follow_handler_registered = False
    elif (not should_follow) and _follow_handler_registered:
        try:
            bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_follow_handler)
        except Exception:
            pass
        _follow_handler_registered = False


def _on_panview_runtime_toggle(self, context):
    _refresh_runtime_hooks(context)


_PANVIEW_PERSISTING = False
_PANVIEW_PERSISTENT_SCENE_PROPS = (
    'panview_show_overlays', 'panview_show_wireframes', 'panview_wireframe_opacity',
    'panview_show_xray', 'panview_wire_color_type', 'panview_color_type',
    'panview_background_type', 'panview_background_color',
    'panview_show_object_outline', 'panview_object_outline_color',
    'panview_xray_alpha', 'panview_lock_rotation',
    'panview_launch_mode', 'panview_split_factor', 'panview_reuse_existing',
    'panview_follow_active_camera', 'panview_size_mode', 'panview_window_fraction',
    'panview_window_w', 'panview_window_h', 'panview_position_mode',
    'panview_hide_ui_fullarea', 'panview_show_hud',
    'panview_ui_show_window_settings', 'panview_ui_show_view_settings',
    'panview_ui_show_camera_guides', 'panview_ui_show_2d_navigation',
    'panview_ui_show_presets', 'panview_ui_show_window_manager',
    'panview_show_safe_areas', 'panview_show_passepartout',
    'panview_passepartout_alpha', 'panview_composition_guide',
    'panview_nav_mode', 'panview_pan_sens', 'panview_zoom_sens',
    'panview_invert_zoom', 'panview_lock_zoom', 'panview_preset_index',
)

_PANVIEW_PRESET_SLOT_PROPS = (
    'name',
    'show_overlays', 'show_wireframes', 'wireframe_opacity',
    'show_xray', 'xray_alpha', 'wire_color_type', 'color_type',
    'background_type', 'background_color',
    'show_object_outline', 'object_outline_color', 'lock_rotation',
    'show_safe_areas', 'show_passepartout', 'passepartout_alpha',
    'composition_guide', 'nav_mode', 'pan_sens', 'zoom_sens',
    'invert_zoom', 'lock_zoom',
)
_PANVIEW_PRESET_SLOTS_KEY = 'panview_preset_slots'


def _panview_settings_path() -> str:
    try:
        return str(_suite_storage.addon_storage_path('panview_settings.json', 'panview'))
    except Exception:
        root = str(_suite_storage.user_default_root('smart_workspace_suite', create=True))
        return os.path.join(root, 'panview_settings.json')


def _json_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        if isinstance(value, bpy.types.ID):
            return {
                '__smarttools_id__': True,
                'id_type': str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or type(value).__name__),
                'name': str(getattr(value, 'name', '') or ''),
            }
    except Exception:
        pass
    try:
        return list(value)
    except Exception:
        return value


def _resolve_json_value(value):
    """Resolve a stable Blender ID record without retaining live pointers."""
    if not isinstance(value, dict) or 'id_type' not in value:
        return value
    name = str(value.get('name') or '')
    id_type = str(value.get('id_type') or '')
    mapping = {
        'Object': getattr(bpy.data, 'objects', None),
        'Collection': getattr(bpy.data, 'collections', None),
        'WorkSpace': getattr(bpy.data, 'workspaces', None),
        'Scene': getattr(bpy.data, 'scenes', None),
        'Image': getattr(bpy.data, 'images', None),
        'Material': getattr(bpy.data, 'materials', None),
        'Camera': getattr(bpy.data, 'cameras', None),
    }
    collection = mapping.get(id_type)
    try:
        return collection.get(name) if collection is not None and name else None
    except Exception:
        return None


def _window_scene(context=None):
    """Return Window.scene during scene-switch callbacks, with a safe fallback."""
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        if scene is not None:
            return scene
    except Exception:
        pass
    return getattr(ctx, 'scene', None)


def _panview_preset_slot_to_dict(slot) -> dict:
    data = {}
    for prop in _PANVIEW_PRESET_SLOT_PROPS:
        try:
            if hasattr(slot, prop):
                data[prop] = _json_value(getattr(slot, prop))
        except Exception:
            pass
    return data


def _apply_panview_preset_slots(scene, entries) -> None:
    if not isinstance(entries, list) or not hasattr(scene, 'panview_preset_slots'):
        return
    slots = scene.panview_preset_slots
    try:
        slots.clear()
    except Exception:
        return
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        try:
            slot = slots.add()
        except Exception:
            break
        for prop in _PANVIEW_PRESET_SLOT_PROPS:
            if prop not in entry or not hasattr(slot, prop):
                continue
            try:
                setattr(slot, prop, entry.get(prop))
            except Exception:
                pass
    try:
        if len(slots) > 0 and hasattr(scene, 'panview_preset_index'):
            scene.panview_preset_index = max(0, min(int(getattr(scene, 'panview_preset_index', 0) or 0), len(slots) - 1))
    except Exception:
        pass


def save_persistent_panview_settings(context=None, *, force: bool = False) -> bool:
    global _PANVIEW_PERSISTING
    if _PANVIEW_PERSISTING:
        return False
    try:
        from .. import persistence as _suite_persistence
        if _suite_persistence.runtime_sidecar_write_blocked():
            _suite_persistence.mark_deferred_settings_dirty()
            return False
    except Exception:
        pass
    if not force:
        try:
            if not _suite_storage.n_panel_state_save_enabled(True):
                try:
                    from .. import persistence as _suite_persistence
                    _suite_persistence.mark_deferred_settings_dirty()
                except Exception:
                    pass
                return False
        except Exception:
            return False
    ctx = context or getattr(bpy, 'context', None)
    scene = _window_scene(ctx)
    if scene is None:
        return True
    data = {}
    for prop in _PANVIEW_PERSISTENT_SCENE_PROPS:
        try:
            if hasattr(scene, prop):
                data[prop] = _json_value(getattr(scene, prop))
        except Exception:
            pass
    try:
        if hasattr(scene, 'panview_preset_slots'):
            data[_PANVIEW_PRESET_SLOTS_KEY] = [
                _panview_preset_slot_to_dict(slot)
                for slot in getattr(scene, 'panview_preset_slots', ())
            ]
    except Exception:
        pass
    try:
        path = _panview_settings_path()
        return bool(_suite_storage.atomic_write_json(
            path, data, indent=2, ensure_ascii=False, sort_keys=True
        ))
    except Exception:
        return False

def apply_persistent_panview_settings(context=None) -> None:
    global _PANVIEW_PERSISTING
    ctx = context or getattr(bpy, 'context', None)
    scene = _window_scene(ctx)
    if scene is None:
        return
    try:
        with open(_panview_settings_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
    except Exception:
        return
    if not isinstance(data, dict):
        return
    _PANVIEW_PERSISTING = True
    try:
        for prop, value in data.items():
            if prop not in _PANVIEW_PERSISTENT_SCENE_PROPS or not hasattr(scene, prop):
                continue
            try:
                setattr(scene, prop, _resolve_json_value(value))
            except Exception:
                pass
        try:
            _apply_panview_preset_slots(scene, data.get(_PANVIEW_PRESET_SLOTS_KEY))
        except Exception:
            pass
    finally:
        _PANVIEW_PERSISTING = False
    _refresh_runtime_hooks(ctx)


def _persist_panview_user_change(context, source: str) -> bool:
    if _PANVIEW_PERSISTING:
        return False
    try:
        from .. import persistence as _suite_persistence
        ok = bool(_suite_persistence.persist_immediate_user_change(
            context,
            source=source,
        ))
        if not ok:
            _suite_persistence.mark_deferred_settings_dirty()
        return ok
    except Exception:
        return False


def _on_panview_setting_update(self, context):
    # Applying a saved profile sets many RNA properties in sequence.  Those
    # assignments must not be mistaken for user edits or publish an
    # intermediate state.  The enclosing restore commits once after all values
    # are applied.
    del self
    _persist_panview_user_change(context, 'panview-rna-update')


def _on_panview_runtime_setting_update(self, context):
    if _PANVIEW_PERSISTING:
        return
    _on_panview_runtime_toggle(self, context)
    _persist_panview_user_change(context, 'panview-runtime-rna-update')


# =============================================================
# 3. プリセット・ウィンドウ追跡用 PropertyGroup
# =============================================================

class PANVIEW_PresetSlot(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Name", default="Preset", description="Name of this preset slot. Give it a descriptive label so you can tell what setup it stores.", update=_on_panview_setting_update)

    # View settings
    show_overlays: bpy.props.BoolProperty(default=True, description="Store whether overlays are visible in this preset.")
    show_wireframes: bpy.props.BoolProperty(default=True, description="Store whether wireframes are shown in this preset.")
    wireframe_opacity: bpy.props.FloatProperty(default=1.0, min=0.0, max=1.0, description="Store the wireframe opacity value in this preset.")
    show_xray: bpy.props.BoolProperty(default=True, description="Store whether X-Ray display is enabled in this preset.")
    xray_alpha: bpy.props.FloatProperty(default=0.8, min=0.0, max=1.0, description="Store the X-Ray transparency level in this preset.")
    wire_color_type: bpy.props.EnumProperty(
        items=[('THEME', "Theme", ""), ('OBJECT', "Object", ""), ('RANDOM', "Random", "")],
        default='THEME'
    )
    color_type: bpy.props.EnumProperty(
        items=[
            ('MATERIAL', "Material", ""), ('OBJECT', "Object", ""),
            ('RANDOM', "Random", ""), ('ATTRIBUTE', "Attribute", ""),
            ('TEXTURE', "Texture", ""), ('SINGLE', "Custom", "")
        ],
        default='TEXTURE'
    )
    background_type: bpy.props.EnumProperty(
        items=[('THEME', "Theme", ""), ('WORLD', "World", ""), ('VIEWPORT', "Custom", "")],
        default='VIEWPORT'
    )
    background_color: bpy.props.FloatVectorProperty(subtype='COLOR', size=3, default=(0.087, 0.087, 0.087), min=0.0, max=1.0)
    show_object_outline: bpy.props.BoolProperty(default=True, description="Store whether object outlines are visible in this preset.")
    object_outline_color: bpy.props.FloatVectorProperty(subtype='COLOR', size=3, default=(0.0, 1.0, 1.0), min=0.0, max=1.0)
    lock_rotation: bpy.props.BoolProperty(default=True, description="Store whether view rotation is locked for 2D-style navigation in this preset.")

    # Guides
    show_safe_areas: bpy.props.BoolProperty(default=True, description="Store whether safe areas are visible in this preset.")
    show_passepartout: bpy.props.BoolProperty(default=True, description="Store whether camera passepartout is visible in this preset.")
    passepartout_alpha: bpy.props.FloatProperty(default=0.5, min=0.0, max=1.0, description="Store the passepartout opacity used by this preset.")
    composition_guide: bpy.props.EnumProperty(
        items=[('NONE', "None", ""), ('THIRDS', "Thirds", ""), ('CENTER', "Center", ""), ('GOLDEN', "Golden Ratio", ""), ('DIAGONALS', "Diagonals", "")],
        default='THIRDS'
    )

    # 2D Nav
    nav_mode: bpy.props.EnumProperty(
        items=[('PAN', "Pan Only", ""), ('PAN_ZOOM', "Pan + Zoom", "")],
        default='PAN_ZOOM'
    )
    pan_sens: bpy.props.FloatProperty(default=1.0, min=0.01, max=10.0, description="Store the pan sensitivity used by this preset.")
    zoom_sens: bpy.props.FloatProperty(default=1.0, min=0.01, max=10.0, description="Store the zoom sensitivity used by this preset.")
    invert_zoom: bpy.props.BoolProperty(default=False, description="Store whether zoom direction is inverted in this preset.")
    lock_zoom: bpy.props.BoolProperty(default=False, description="Store whether zoom is locked in this preset.")


class PANVIEW_TrackedWindow(bpy.types.PropertyGroup):
    window_ptr: bpy.props.StringProperty(default="")
    camera_name: bpy.props.StringProperty(default="")
    created_time: bpy.props.StringProperty(default="")


# =============================================================
# 4. プリファレンス (設定画面)
# =============================================================

def update_panel_category(self, context):
    # Popup-only UI in Smart Workspace. Keep as a no-op for legacy compatibility.
    return None


class PANVIEW_AddonPreferences(bpy.types.AddonPreferences):
    """Compatibility shell; 2D Pan View settings are exposed only from the N-panel."""

    bl_idname = __name__

    def draw(self, context):
        return None


# =============================================================
# 5. 2D ナビゲーション / ビュー操作
# =============================================================

class PANVIEW_OT_Start2DNav(bpy.types.Operator):
    bl_idname = "view3d.panview_start_2d_nav"
    bl_label = "Start 2D Nav"
    bl_description = "Start modal 2D navigation inside the active camera view. Drag to pan, and when zoom is enabled you can adjust framing without leaving the dedicated 2D view workflow."
    bl_options = set()
    _sms_no_undo = True

    _panning = False
    _start_x = 0
    _start_y = 0
    _start_off = None
    _start_zoom = 0

    def modal(self, context, event):
        scene = context.scene
        space = context.space_data
        rv3d = context.region_data
        region = context.region

        if event.type in {'ESC', 'RIGHTMOUSE'}:
            self._panning = False
            return {'CANCELLED'}

        if not space or space.type != 'VIEW_3D' or not rv3d or rv3d.view_perspective != 'CAMERA':
            return {'CANCELLED'}

        nav_mode = scene.panview_nav_mode
        pan_sens = scene.panview_pan_sens
        zoom_sens = scene.panview_zoom_sens
        invert_zoom = scene.panview_invert_zoom
        lock_zoom = scene.panview_lock_zoom

        if event.type == 'MIDDLEMOUSE':
            if event.value == 'PRESS':
                self._panning = True
                self._start_x = event.mouse_region_x
                self._start_y = event.mouse_region_y
                self._start_off = (rv3d.view_camera_offset[0], rv3d.view_camera_offset[1])
                self._start_zoom = rv3d.view_camera_zoom
                return {'RUNNING_MODAL'}
            elif event.value == 'RELEASE':
                self._panning = False
                return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE' and self._panning:
            dx = (event.mouse_region_x - self._start_x)
            dy = (event.mouse_region_y - self._start_y)

            # Normalized pan (simple, stable)
            if region and region.width > 0 and region.height > 0:
                nx = dx / region.width
                ny = dy / region.height
            else:
                nx, ny = 0.0, 0.0

            # Convert to camera offset space (drag feels natural)
            rv3d.view_camera_offset[0] = self._start_off[0] - nx * 2.0 * pan_sens
            rv3d.view_camera_offset[1] = self._start_off[1] - ny * 2.0 * pan_sens
            return {'RUNNING_MODAL'}

        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} and nav_mode == 'PAN_ZOOM' and not lock_zoom:
            step = int(120 * zoom_sens)
            if step < 1:
                step = 1
            direction = 1 if event.type == 'WHEELUPMOUSE' else -1
            if invert_zoom:
                direction *= -1
            rv3d.view_camera_zoom = int(rv3d.view_camera_zoom + direction * step)
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        space = context.space_data
        rv3d = context.region_data
        if not space or space.type != 'VIEW_3D' or not rv3d or rv3d.view_perspective != 'CAMERA':
            self.report({'WARNING'}, pgettext("Camera view is required."))
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class PANVIEW_OT_FitCameraView(bpy.types.Operator):
    bl_idname = "view3d.panview_fit_camera_view"
    bl_label = "Fit"
    bl_description = "Reset the camera view offset and zoom as closely as Blender allows. Use this when the view drifted away from the camera frame and you want a clean fit again."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        rv3d = context.region_data
        if rv3d:
            rv3d.view_camera_offset = (0.0, 0.0)
            rv3d.view_camera_zoom = 0
        try:
            bpy.ops.view3d.view_center_camera()
        except Exception:
            pass
        return {'FINISHED'}


class PANVIEW_OT_ZoomCamera1to1(bpy.types.Operator):
    bl_idname = "view3d.panview_zoom_camera_1to1"
    bl_label = "1:1"
    bl_description = "Set the camera view close to a 1:1 zoom level when the current Blender version supports it. Useful for texture inspection and pixel-aligned checks."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        try:
            bpy.ops.view3d.zoom_camera_1_to_1()
            return {'FINISHED'}
        except Exception:
            # fallback: neutral zoom
            rv3d = context.region_data
            if rv3d:
                rv3d.view_camera_zoom = 0
            return {'FINISHED'}


class PANVIEW_OT_ZoomCamera2to1(bpy.types.Operator):
    bl_idname = "view3d.panview_zoom_camera_2to1"
    bl_label = "2:1"
    bl_description = "Zoom the camera view in further to an approximately 2:1 level. Useful when you want to inspect small texture details without manually adjusting the view."
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        view = context.region_data
        return bool(view and view.view_perspective == 'CAMERA'
                    and bpy.ops.view3d.zoom_camera_1_to_1.poll())

    def execute(self, context):
        result = bpy.ops.view3d.zoom_camera_1_to_1()
        if 'FINISHED' not in result:
            return result
        view = context.region_data
        # Blender camera scale is proportional to (sqrt(2) + zoom / 50) squared.
        root_two = sqrt(2.0)
        view.view_camera_zoom = root_two * view.view_camera_zoom + 100.0 - 50.0 * root_two
        return {'FINISHED'}


class PANVIEW_OT_CloseWindow(bpy.types.Operator):
    bl_idname = "wm.panview_close_window"
    bl_label = "Close Window"
    bl_description = "Close the currently active 2D Pan View window. Use this when you are done with the detached view and want to clean up your workspace."
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def poll(cls, context):
        window = context.window
        if window is None:
            return False
        ptr = str(window.as_pointer())
        return any(entry.window_ptr == ptr for entry in context.window_manager.panview_tracked_windows)

    def execute(self, context):
        # 2Dパンビューの窓だけを閉じる。本体の窓を閉じると Blender ごと終わる。
        wm = context.window_manager
        try:
            bpy.ops.wm.window_close()
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        cleanup_tracked_windows(wm)
        return {'FINISHED'}


# =============================================================
# 6. パイメニュー
# =============================================================

class PANVIEW_MT_Pie(bpy.types.Menu):
    bl_label = "2D Pan View Pie"
    bl_idname = "PANVIEW_MT_pie"

    def draw(self, context):
        layout = localized_layout(self.layout, context)
        pie = layout.menu_pie()

        pie.operator("view3d.panview_fit_camera_view", text=pgettext("Fit"), icon='FULLSCREEN_ENTER')
        pie.operator("view3d.panview_zoom_camera_1to1", text=pgettext("1:1"), icon='ZOOM_IN')
        pie.operator("view3d.panview_zoom_camera_2to1", text=pgettext("2:1"), icon='ZOOM_IN')
        pie.operator("view3d.panview_start_2d_nav", text=pgettext("Start 2D Nav"), icon='HAND')
        pie.operator("wm.panview_close_window", text=pgettext("Close Window"), icon='PANEL_CLOSE')


class PANVIEW_OT_OpenPie(bpy.types.Operator):
    bl_idname = "wm.panview_open_pie"
    bl_label = "Open Pie Menu"
    bl_description = "Open the 2D Pan pie menu for quick access to the most common navigation commands. This is handy when you prefer radial menus over the panel buttons."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        bpy.ops.wm.call_menu_pie(name="PANVIEW_MT_pie")
        return {'FINISHED'}


# =============================================================
# 7. プリセット操作
# =============================================================

def ensure_preset_slots(scene, count=5):
    slots = scene.panview_preset_slots
    while len(slots) < count:
        s = slots.add()
        s.name = f"Preset {len(slots)}"
    if len(slots) == 0:
        scene.panview_preset_index = 0
        return
    try:
        idx = int(getattr(scene, "panview_preset_index", 0) or 0)
    except Exception:
        idx = 0
    scene.panview_preset_index = max(0, min(idx, len(slots) - 1))



class PANVIEW_OT_InitPresets(bpy.types.Operator):
    bl_idname = "view3d.panview_init_presets"
    bl_label = "Initialize Presets"
    bl_description = "Create the default set of preset slots. Do this once before saving preset configurations if the preset area is still empty."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        ensure_preset_slots(context.scene, count=5)
        _persist_panview_user_change(context, 'panview-preset-initialize')
        return {'FINISHED'}

def preset_store_from_scene(slot, scene):
    slot.show_overlays = scene.panview_show_overlays
    slot.show_wireframes = scene.panview_show_wireframes
    slot.wireframe_opacity = scene.panview_wireframe_opacity
    slot.show_xray = scene.panview_show_xray
    slot.xray_alpha = scene.panview_xray_alpha
    slot.wire_color_type = scene.panview_wire_color_type
    slot.color_type = scene.panview_color_type
    slot.background_type = scene.panview_background_type
    slot.background_color = scene.panview_background_color
    slot.show_object_outline = scene.panview_show_object_outline
    slot.object_outline_color = scene.panview_object_outline_color
    slot.lock_rotation = scene.panview_lock_rotation

    slot.show_safe_areas = scene.panview_show_safe_areas
    slot.show_passepartout = scene.panview_show_passepartout
    slot.passepartout_alpha = scene.panview_passepartout_alpha
    slot.composition_guide = scene.panview_composition_guide

    slot.nav_mode = scene.panview_nav_mode
    slot.pan_sens = scene.panview_pan_sens
    slot.zoom_sens = scene.panview_zoom_sens
    slot.invert_zoom = scene.panview_invert_zoom
    slot.lock_zoom = scene.panview_lock_zoom


def preset_apply_to_scene(slot, scene):
    scene.panview_show_overlays = slot.show_overlays
    scene.panview_show_wireframes = slot.show_wireframes
    scene.panview_wireframe_opacity = slot.wireframe_opacity
    scene.panview_show_xray = slot.show_xray
    scene.panview_xray_alpha = slot.xray_alpha
    scene.panview_wire_color_type = slot.wire_color_type
    scene.panview_color_type = slot.color_type
    scene.panview_background_type = slot.background_type
    scene.panview_background_color = slot.background_color
    scene.panview_show_object_outline = slot.show_object_outline
    scene.panview_object_outline_color = slot.object_outline_color
    scene.panview_lock_rotation = slot.lock_rotation

    scene.panview_show_safe_areas = slot.show_safe_areas
    scene.panview_show_passepartout = slot.show_passepartout
    scene.panview_passepartout_alpha = slot.passepartout_alpha
    scene.panview_composition_guide = slot.composition_guide

    scene.panview_nav_mode = slot.nav_mode
    scene.panview_pan_sens = slot.pan_sens
    scene.panview_zoom_sens = slot.zoom_sens
    scene.panview_invert_zoom = slot.invert_zoom
    scene.panview_lock_zoom = slot.lock_zoom


class PANVIEW_OT_PresetSave(bpy.types.Operator):
    bl_idname = "view3d.panview_preset_save"
    bl_label = "Save"
    bl_description = "Save the current 2D Pan View settings into the selected preset slot. This stores your view, guide, and navigation preferences for quick reuse."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        scene = context.scene
        ensure_preset_slots(scene)
        idx = max(0, min(int(scene.panview_preset_index), len(scene.panview_preset_slots) - 1))
        scene.panview_preset_index = idx
        slot = scene.panview_preset_slots[idx]
        preset_store_from_scene(slot, scene)
        _persist_panview_user_change(context, 'panview-preset-save')
        return {'FINISHED'}


class PANVIEW_OT_PresetLoad(bpy.types.Operator):
    bl_idname = "view3d.panview_preset_load"
    bl_label = "Load"
    bl_description = "Load the settings stored in the selected preset slot. You can also choose to push the loaded settings to currently open tracked 2D views."
    bl_options = set()
    _sms_no_undo = True

    apply_to_open_views: bpy.props.BoolProperty(
        name="Apply to Open Views",
        default=True,
        description="Apply loaded settings to currently tracked views."
    )

    def execute(self, context):
        scene = context.scene
        ensure_preset_slots(scene)
        idx = max(0, min(int(scene.panview_preset_index), len(scene.panview_preset_slots) - 1))
        scene.panview_preset_index = idx
        slot = scene.panview_preset_slots[idx]
        preset_apply_to_scene(slot, scene)

        if self.apply_to_open_views:
            bpy.ops.view3d.panview_update_all_views()
        _persist_panview_user_change(context, 'panview-preset-load')
        return {'FINISHED'}


# =============================================================
# 8. ウィンドウ管理
# =============================================================

def compute_target_size(scene):
    """Return (w,h) target based on scene settings, best effort."""
    # Defaults
    w, h = 800, 600
    size_mode = scene.panview_size_mode

    # Render
    if size_mode == 'RENDER':
        r = scene.render
        rx = int(r.resolution_x * (r.resolution_percentage / 100.0))
        ry = int(r.resolution_y * (r.resolution_percentage / 100.0))
        w, h = max(64, rx), max(64, ry)

    # Pixels
    elif size_mode == 'PIXELS':
        w, h = max(64, scene.panview_window_w), max(64, scene.panview_window_h)

    # Fraction (of parent if possible)
    else:
        frac = max(0.1, min(1.0, scene.panview_window_fraction))
        if sys.platform == "win32":
            rect = get_parent_rect_win32()
            if rect:
                w = int((rect.right - rect.left) * frac)
                h = int((rect.bottom - rect.top) * frac)
            else:
                w = int(1600 * frac)
                h = int(900 * frac)
        else:
            w = int(1600 * frac)
            h = int(900 * frac)

    return int(w), int(h)


def compute_target_pos(scene, w, h):
    """Return (x,y) for top-left of window, win32 only. Else None."""
    if sys.platform != "win32":
        return None

    mode = scene.panview_position_mode

    if mode == 'CURSOR':
        pos = get_cursor_pos_win32()
        if pos:
            cx, cy = pos
            return int(cx - w // 2), int(cy - h // 2)

    if mode == 'PARENT':
        rect = get_parent_rect_win32()
        if rect:
            cx = int((rect.left + rect.right) // 2)
            cy = int((rect.top + rect.bottom) // 2)
            return int(cx - w // 2), int(cy - h // 2)

    if mode == 'SCREEN':
        ss = get_screen_size_win32()
        if ss:
            sw, sh = ss
            return int(sw // 2 - w // 2), int(sh // 2 - h // 2)

    # Corners
    ss = get_screen_size_win32() or (1920, 1080)
    sw, sh = ss
    if mode == 'TL':
        return 0, 0
    if mode == 'TR':
        return int(sw - w), 0
    if mode == 'BL':
        return 0, int(sh - h)
    if mode == 'BR':
        return int(sw - w), int(sh - h)

    return None


def track_window(wm, window, camera_obj):
    entry = wm.panview_tracked_windows.add()
    entry.window_ptr = str(window.as_pointer())
    entry.camera_name = camera_obj.name if camera_obj else ""
    entry.created_time = time.strftime("%Y-%m-%d %H:%M:%S")
    try:
        _refresh_runtime_hooks(getattr(bpy, 'context', None))
    except Exception:
        pass
    return entry


def apply_settings_to_window(window, scene, camera_obj):
    """Apply settings to the first VIEW_3D area inside `window` (no temp screen override).

    NOTE (Blender 5.0): overriding with a temporary screen is not supported, so we avoid
    screen overrides and rely on direct data access wherever possible.
    """
    area, _region = get_view3d_area_region(window)
    if not area:
        return False

    # Ensure this area is a 3D View
    if area.type != 'VIEW_3D':
        try:
            area.type = 'VIEW_3D'
        except Exception:
            return False

    space = area.spaces.active if area.spaces else None
    if not space or getattr(space, "type", None) != 'VIEW_3D':
        return False

    # Apply settings directly (no operators required)
    apply_space_settings(space, scene, camera_obj)
    camera_apply_guides(camera_obj, scene)

    # Hide UI regions (without fullscreen operator for stability)
    if scene.panview_hide_ui_fullarea:
        try:
            space.show_region_header = False
            space.show_region_ui = False
            space.show_region_toolbar = False
        except Exception:
            pass

    return True



def _window_by_pointer(window_ptr):
    wm = getattr(bpy.context, "window_manager", None)
    for window in getattr(wm, 'windows', ()):
        try:
            if int(window.as_pointer()) == int(window_ptr):
                return window
        except Exception:
            continue
    return None


def _area_by_pointer(window, area_ptr):
    if not window or not getattr(window, 'screen', None) or not area_ptr:
        return None
    for area in getattr(window.screen, 'areas', ()):
        try:
            if int(area.as_pointer()) == int(area_ptr):
                return area
        except Exception:
            continue
    return None


def force_camera_view(window, scene, camera_obj, area=None):
    if not window or not scene or not camera_obj:
        return False

    if area is None:
        area, _region = get_view3d_area_region(window)
    else:
        _region = next((r for r in getattr(area, 'regions', ()) if getattr(r, 'type', None) == 'WINDOW'), None)

    if not area:
        return False

    try:
        if area.type != 'VIEW_3D':
            area.type = 'VIEW_3D'
    except Exception:
        return False

    space = area.spaces.active if getattr(area, 'spaces', None) else None
    if not space or getattr(space, 'type', None) != 'VIEW_3D':
        return False

    # Avoid bpy.ops.view3d.view_camera() here.
    # That operator toggles camera view, so calling it from launch-time timers
    # can make the new Pan View jump in/out of the camera and visibly twitch.
    # Data-only assignment keeps the framing stable while still forcing the
    # dedicated window into camera view.
    apply_space_settings(space, scene, camera_obj)
    camera_apply_guides(camera_obj, scene)

    rv3d = getattr(space, 'region_3d', None)
    if rv3d is not None:
        try:
            rv3d.view_perspective = 'CAMERA'
        except Exception:
            pass

    if scene.panview_hide_ui_fullarea:
        try:
            space.show_region_header = False
            space.show_region_ui = False
            space.show_region_toolbar = False
        except Exception:
            pass

    try:
        area.tag_redraw()
    except Exception:
        pass

    rv3d = getattr(space, 'region_3d', None)
    return bool(getattr(space, 'camera', None) == camera_obj and getattr(rv3d, 'view_perspective', None) == 'CAMERA')


def schedule_force_camera_view(window, scene, camera_obj, area=None, retries=10, interval=0.12):
    if (not _PANVIEW_RUNTIME_ENABLED) or (not window) or (not scene) or (not camera_obj):
        return

    try:
        window_ptr = int(window.as_pointer())
    except Exception:
        return

    try:
        area_ptr = int(area.as_pointer()) if area is not None else 0
    except Exception:
        area_ptr = 0

    scene_name = str(getattr(scene, 'name', '') or '')
    camera_name = str(getattr(camera_obj, 'name', '') or '')
    state = {'attempts': 0}

    def _timer():
        if not _PANVIEW_RUNTIME_ENABLED:
            return None
        target_window = _window_by_pointer(window_ptr)
        if target_window is None:
            return None

        target_scene = bpy.data.scenes.get(scene_name) if scene_name else getattr(target_window, 'scene', None)
        if target_scene is None:
            target_scene = getattr(bpy.context, 'scene', None)

        target_camera = bpy.data.objects.get(camera_name) if camera_name else None
        if target_scene is None or target_camera is None:
            return None

        target_area = _area_by_pointer(target_window, area_ptr)
        ok = force_camera_view(target_window, target_scene, target_camera, area=target_area)
        state['attempts'] += 1
        if ok or state['attempts'] >= max(1, int(retries)):
            return None
        return float(interval)

    bpy.app.timers.register(_timer, first_interval=0.05)


def update_all_tracked_views(context):
    wm = context.window_manager
    scene = context.scene
    cleanup_tracked_windows(wm)

    for entry in wm.panview_tracked_windows:
        target_window = None
        for w in wm.windows:
            if str(w.as_pointer()) == entry.window_ptr:
                target_window = w
                break
        if not target_window:
            continue

        cam = resolve_panview_camera(scene, entry)
        if cam is None:
            continue

        try:
            entry.camera_name = cam.name
        except Exception:
            pass

        if not force_camera_view(target_window, scene, cam):
            apply_settings_to_window(target_window, scene, cam)
        schedule_force_camera_view(target_window, scene, cam)


class PANVIEW_OT_UpdateAllViews(bpy.types.Operator):
    bl_idname = "view3d.panview_update_all_views"
    bl_label = "Update View"
    bl_description = "Send the current scene settings to all tracked 2D view windows. Use this after changing overlays, guides, or navigation preferences and you want every open view to match."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        update_all_tracked_views(context)
        return {'FINISHED'}


def _wm_operator_exists(name: str) -> bool:
    try:
        getattr(bpy.ops.wm, str(name)).get_rna_type()
        return True
    except Exception:
        return False


class PANVIEW_OT_RefreshWindows(bpy.types.Operator):
    bl_idname = "view3d.panview_refresh_windows"
    bl_label = "Refresh"
    bl_description = "Refresh the tracked window list and remove entries for windows that are no longer available. Use this when the window manager list looks out of date."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        cleanup_tracked_windows(context.window_manager)
        return {'FINISHED'}


class PANVIEW_OT_CloseTrackedWindow(bpy.types.Operator):
    bl_idname = "view3d.panview_close_tracked_window"
    bl_label = "Close"
    bl_description = "Close the selected tracked 2D view window from the manager list. This is the per-window cleanup command."
    bl_options = set()
    _sms_no_undo = True

    window_ptr: bpy.props.StringProperty(default="")

    def execute(self, context):
        wm = context.window_manager
        target = None
        for w in wm.windows:
            if str(w.as_pointer()) == self.window_ptr:
                target = w
                break
        if target:
            try:
                # Close target window (best effort). Avoid screen override in Blender 5.0+.
                with bpy.context.temp_override(window=target):
                    bpy.ops.wm.window_close()
            except Exception:
                pass

        cleanup_tracked_windows(wm)
        return {'FINISHED'}


class PANVIEW_OT_CloseAllTrackedWindows(bpy.types.Operator):
    bl_idname = "view3d.panview_close_all_tracked_windows"
    bl_label = "Close All"
    bl_description = "Close every tracked 2D view window at once. Useful when you want to reset your layout or finish a session quickly."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        ptrs = [e.window_ptr for e in wm.panview_tracked_windows]
        for ptr in ptrs:
            bpy.ops.view3d.panview_close_tracked_window(window_ptr=ptr)
        cleanup_tracked_windows(wm)
        return {'FINISHED'}


class PANVIEW_OT_FocusTrackedWindow(bpy.types.Operator):
    bl_idname = "view3d.panview_focus_tracked_window"
    bl_label = "Focus"
    bl_description = "Try to bring the selected tracked 2D view window to the front and focus it. Use this to jump back to a detached view without searching for it manually."
    bl_options = set()
    _sms_no_undo = True

    window_ptr: bpy.props.StringProperty(default="")

    def execute(self, context):
        wm = context.window_manager
        target = None
        for w in wm.windows:
            if str(w.as_pointer()) == self.window_ptr:
                target = w
                break
        if not target:
            return {'CANCELLED'}

        # Blender 5.1 does not register wm.window_set_active.  Do not rely on
        # hasattr(bpy.ops, ...), because bpy.ops creates dynamic proxies for
        # unknown names as well.  Future builds can use the operator when its
        # RNA type is genuinely present.
        if _wm_operator_exists("window_set_active"):
            try:
                focus_op = getattr(bpy.ops.wm, "window_set_active")
                result = focus_op(window=target)
                if 'FINISHED' in set(result or set()):
                    return {'FINISHED'}
            except Exception:
                pass

        if _focus_native_window(self.window_ptr):
            return {'FINISHED'}

        self.report({'WARNING'}, pgettext("Could not focus the 2D View window. Use the operating-system window switcher."))
        return {'CANCELLED'}


# =============================================================
# 9. 起動オペレーター
# =============================================================

class PANVIEW_OT_Create(bpy.types.Operator):
    bl_idname = "view3d.create_2d_pan_view"
    bl_label = "Launch View"
    bl_description = "Create a dedicated 2D Pan View for the selected camera using the current launch, size, guide, and navigation settings."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        launch_cam = resolve_panview_camera(scene)

        if not launch_cam:
            self.report({'WARNING'}, pgettext("Please select a camera."))
            return {'CANCELLED'}

        # Reuse existing window
        cleanup_tracked_windows(wm)
        if scene.panview_reuse_existing and len(wm.panview_tracked_windows) > 0:
            if scene.panview_follow_active_camera and scene.camera:
                # When following active camera, any existing tracked window is valid to reuse.
                for entry in wm.panview_tracked_windows:
                    for w in wm.windows:
                        if str(w.as_pointer()) == entry.window_ptr:
                            apply_settings_to_window(w, scene, launch_cam)
                            schedule_force_camera_view(w, scene, launch_cam)
                            try:
                                bpy.ops.view3d.panview_focus_tracked_window(window_ptr=entry.window_ptr)
                            except Exception:
                                pass
                            self.report({'INFO'}, pgettext("Reused existing window."))
                            return {'FINISHED'}
            else:
                # Match by stored camera name
                for entry in wm.panview_tracked_windows:
                    if entry.camera_name == launch_cam.name:
                        for w in wm.windows:
                            if str(w.as_pointer()) == entry.window_ptr:
                                apply_settings_to_window(w, scene, launch_cam)
                                schedule_force_camera_view(w, scene, launch_cam)
                                try:
                                    bpy.ops.view3d.panview_focus_tracked_window(window_ptr=entry.window_ptr)
                                except Exception:
                                    pass
                                self.report({'INFO'}, pgettext("Reused existing window."))
                                return {'FINISHED'}

        # Launch mode
        if scene.panview_launch_mode == 'SPLIT':
            # Split current area (cross-platform stable)
            area = context.area
            if not area or area.type != 'VIEW_3D':
                self.report({'WARNING'}, pgettext("Run from a 3D View area."))
                return {'CANCELLED'}

            win_region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if not win_region:
                self.report({'WARNING'}, pgettext("No VIEW_3D window region found."))
                return {'CANCELLED'}

            screen = context.window.screen
            pre_areas = {a.as_pointer() for a in screen.areas}

            # Create split
            override = bpy.context.temp_override(window=context.window, area=area, region=win_region)
            with override:
                try:
                    bpy.ops.screen.area_split(direction='VERTICAL', factor=scene.panview_split_factor)
                except Exception:
                    try:
                        bpy.ops.screen.area_split(direction='HORIZONTAL', factor=scene.panview_split_factor)
                    except Exception:
                        self.report({'WARNING'}, pgettext("Area split failed."))
                        return {'CANCELLED'}

            post_areas = {a.as_pointer(): a for a in screen.areas}
            new_area = None
            for ptr, a in post_areas.items():
                if ptr not in pre_areas:
                    new_area = a
                    break
            if not new_area:
                new_area = area

            new_area.type = 'VIEW_3D'
            new_region = next((r for r in new_area.regions if r.type == 'WINDOW'), None)

            override2 = bpy.context.temp_override(window=context.window, area=new_area, region=new_region) if new_region else bpy.context.temp_override(window=context.window, area=new_area)
            with override2:
                space = new_area.spaces.active
                apply_space_settings(space, scene, launch_cam)
                camera_apply_guides(launch_cam, scene)

                # Hide UI regions (without fullscreen)
                if scene.panview_hide_ui_fullarea and space.type == 'VIEW_3D':
                    space.show_region_header = False
                    space.show_region_ui = False
                    space.show_region_toolbar = False

            schedule_force_camera_view(context.window, scene, launch_cam, area=new_area)
            try:
                _refresh_runtime_hooks(context)
            except Exception:
                pass
            self.report({'INFO'}, pgettext("View Launched."))
            return {'FINISHED'}

        # NEW WINDOW
        pre_ptrs = {w.as_pointer() for w in wm.windows}

        # size/pos
        target_w, target_h = compute_target_size(scene)

        bpy.ops.wm.window_new()

        new_window = find_new_window(pre_ptrs)
        if not new_window:
            # Fallback: last window
            new_window = wm.windows[-1]

        # Win32: resize + position
        if sys.platform == "win32":
            try:
                user32 = ctypes.windll.user32
                hwnd_new = user32.GetActiveWindow()
                _PANVIEW_WINDOW_HWNDS[str(new_window.as_pointer())] = int(hwnd_new)
                pos = compute_target_pos(scene, target_w, target_h)
                if pos:
                    x, y = pos
                else:
                    # default cursor center
                    cp = get_cursor_pos_win32() or (target_w // 2, target_h // 2)
                    x, y = int(cp[0] - target_w // 2), int(cp[1] - target_h // 2)
                set_window_pos_win32(hwnd_new, x, y, target_w, target_h)
            except Exception:
                pass

        # Make sure first area is VIEW_3D
        if new_window.screen.areas:
            target_area = new_window.screen.areas[0]
            target_area.type = 'VIEW_3D'
        else:
            self.report({'WARNING'}, pgettext("No areas found in new window."))
            return {'CANCELLED'}

        # Apply settings
        apply_settings_to_window(new_window, scene, launch_cam)
        schedule_force_camera_view(new_window, scene, launch_cam)

        # Track
        track_window(wm, new_window, launch_cam)

        # Optional UI hide (fullscreen)
        if scene.panview_hide_ui_fullarea:
            bpy.app.timers.register(lambda: deferred_window_setup_for(new_window.as_pointer(), scene.name, launch_cam.name), first_interval=0.1)

        self.report({'INFO'}, pgettext("View Launched."))
        return {'FINISHED'}


# =============================================================
# 10. UI helper (popup-only; no N-panel registration)
# =============================================================

def _panview_fold_box(layout, scene, prop_name, title, icon_main):
    box = layout.box()
    is_open = getattr(scene, prop_name, True)
    tri = 'TRIA_DOWN' if is_open else 'TRIA_RIGHT'
    header = box.row(align=True)
    ui_icons.prop(header, scene, prop_name, text=title, name='down' if is_open else 'right', fallback=tri, emboss=False)
    ui_icons.label(header, text="", name={'WINDOW':'window','PREFERENCES':'settings','CAMERA_DATA':'camera','HAND':'tool','PRESET':'preset'}.get(icon_main, 'panel'), fallback=icon_main)
    return box, is_open


_PANVIEW_REQUIRED_SCENE_PROPS = (
    "panview_camera_target",
    "panview_show_overlays",
    "panview_show_wireframes",
    "panview_wireframe_opacity",
    "panview_show_xray",
    "panview_wire_color_type",
    "panview_color_type",
    "panview_background_type",
    "panview_background_color",
    "panview_show_object_outline",
    "panview_object_outline_color",
    "panview_xray_alpha",
    "panview_lock_rotation",
    "panview_launch_mode",
    "panview_split_factor",
    "panview_reuse_existing",
    "panview_follow_active_camera",
    "panview_size_mode",
    "panview_window_fraction",
    "panview_window_w",
    "panview_window_h",
    "panview_position_mode",
    "panview_hide_ui_fullarea",
    "panview_show_hud",
    "panview_ui_show_window_settings",
    "panview_ui_show_view_settings",
    "panview_ui_show_camera_guides",
    "panview_ui_show_2d_navigation",
    "panview_ui_show_presets",
    "panview_ui_show_window_manager",
    "panview_show_safe_areas",
    "panview_show_passepartout",
    "panview_passepartout_alpha",
    "panview_composition_guide",
    "panview_nav_mode",
    "panview_pan_sens",
    "panview_zoom_sens",
    "panview_invert_zoom",
    "panview_lock_zoom",
    "panview_preset_slots",
    "panview_preset_index",
)


def _panview_type_property_ready(owner_type, name: str) -> bool:
    """Return whether Blender published one dynamic RNA property on a type.

    Registration readiness must be proven from ``bpy.types`` and class-owned
    RNA, not from whichever Scene/WindowManager instance happens to be exposed
    by the current context.  A user-preferences cold start can validly have no
    Scene or WindowManager instance while native RNA registration succeeds.
    """
    if owner_type is None or not str(name or ''):
        return False
    try:
        properties = getattr(getattr(owner_type, 'bl_rna', None), 'properties', None)
        getter = getattr(properties, 'get', None)
        if callable(getter):
            return getter(name) is not None
    except Exception:
        return False
    try:
        return hasattr(owner_type, name)
    except Exception:
        return False


def _panview_classes_rna_ready() -> bool:
    try:
        return all(_runtime_ledger.class_is_current(cls) for cls in classes)
    except Exception:
        return False


def _panview_scene_rna_ready() -> bool:
    scene_type = getattr(getattr(bpy, 'types', None), 'Scene', None)
    return bool(
        scene_type is not None
        and all(_panview_type_property_ready(scene_type, name) for name in _PANVIEW_REQUIRED_SCENE_PROPS)
    )


def _panview_wm_rna_ready() -> bool:
    wm_type = getattr(getattr(bpy, 'types', None), 'WindowManager', None)
    return bool(
        wm_type is not None
        and _panview_type_property_ready(wm_type, 'panview_tracked_windows')
    )


def panview_rna_registration_ready() -> bool:
    """Validate native class/property registration without reading bpy.context."""
    return bool(
        _panview_classes_rna_ready()
        and _panview_scene_rna_ready()
        and _panview_wm_rna_ready()
    )


def _panview_scene_props_ready(scene) -> bool:
    return bool(scene is not None and _panview_scene_rna_ready())


def _panview_wm_props_ready(wm) -> bool:
    return bool(wm is not None and _panview_wm_rna_ready())


def ensure_panview_runtime_ready(context=None, *, require_window_manager=True) -> bool:
    """Check 2D Pan View readiness without registering from UI draw code.

    runtime.register() initializes this runtime before the N-panel is
    drawn.  Panel.draw must never register classes or add RNA properties.
    """
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None)
    wm = getattr(ctx, 'window_manager', None)
    return bool(_PANVIEW_RUNTIME_ENABLED) and _panview_scene_props_ready(scene) and ((not require_window_manager) or _panview_wm_props_ready(wm))


def draw_panview_ui(layout, context, *, show_launch_button=True, show_runtime_controls=True, show_window_manager=True):
    # Draw is a pure replay of already registered in-memory RNA.  Registration
    # readiness and type-level RNA scans are performed by runtime registration,
    # never while the N-panel is redrawn.
    scene = getattr(context, "scene", None)
    wm = getattr(context, "window_manager", None)
    if (
        (not _PANVIEW_RUNTIME_ENABLED)
        or scene is None
        or not hasattr(scene, "panview_camera_target")
    ):
        layout.label(text=pgettext("2D Pan View is not available."), icon='ERROR')
        return

    # ---------------------------------------------------------
    # Target camera + Launch
    # ---------------------------------------------------------
    layout.label(text=pgettext("Target Camera") + ":")
    layout.prop(scene, "panview_camera_target", text="")

    if show_launch_button:
        row = layout.row()
        # Allow launch when follow-active is ON and a scene camera exists.
        if (scene.panview_camera_target is None) and (not scene.panview_follow_active_camera or scene.camera is None):
            row.enabled = False
        ui_icons.operator(row, "view3d.create_2d_pan_view", name='camera', fallback='PLAY', text=pgettext("Launch View"))
        layout.separator()

    # Window settings
    box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_window_settings", pgettext("Window Settings"), 'WINDOW')
    if is_open:
        col = box.column(align=True)
        col.prop(scene, "panview_launch_mode")
        if scene.panview_launch_mode == 'SPLIT':
            col.prop(scene, "panview_split_factor")
        col.separator()
        col.prop(scene, "panview_reuse_existing")
        col.separator()
        col.prop(scene, "panview_size_mode")
        if scene.panview_size_mode == 'FRACTION':
            col.prop(scene, "panview_window_fraction")
        elif scene.panview_size_mode == 'PIXELS':
            row = col.row(align=True)
            row.prop(scene, "panview_window_w")
            row.prop(scene, "panview_window_h")
        col.separator()
        col.prop(scene, "panview_position_mode")
        col.separator()
        col.prop(scene, "panview_hide_ui_fullarea")

    # View settings
    box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_view_settings", pgettext("View Settings"), 'PREFERENCES')
    if is_open:
        col = box.column(align=True)
        col.prop(scene, "panview_lock_rotation")
        col.separator()
        col.prop(scene, "panview_show_overlays")
        col.prop(scene, "panview_show_wireframes")
        col.prop(scene, "panview_wireframe_opacity")
        col.separator()
        col.prop(scene, "panview_show_xray")
        col.prop(scene, "panview_xray_alpha")
        col.separator()
        col.prop(scene, "panview_wire_color_type", text=pgettext("Wire Color"))
        col.prop(scene, "panview_color_type", text=pgettext("Object Color"))
        col.separator()
        col.prop(scene, "panview_background_type", text=pgettext("Background"))
        if scene.panview_background_type == 'VIEWPORT':
            col.prop(scene, "panview_background_color", text="")
        col.separator()
        col.prop(scene, "panview_show_object_outline")
        col.prop(scene, "panview_object_outline_color", text="")

    # Camera guides
    box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_camera_guides", pgettext("Camera Guides"), 'CAMERA_DATA')
    if is_open:
        col = box.column(align=True)
        col.prop(scene, "panview_show_safe_areas")
        col.prop(scene, "panview_show_passepartout")
        col.prop(scene, "panview_passepartout_alpha")
        col.separator()
        col.prop(scene, "panview_composition_guide")

    # 2D navigation settings
    box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_2d_navigation", pgettext("2D Navigation"), 'HAND')
    if is_open:
        col = box.column(align=True)
        col.prop(scene, "panview_nav_mode")
        col.prop(scene, "panview_pan_sens")
        col.prop(scene, "panview_zoom_sens")
        col.prop(scene, "panview_invert_zoom")
        col.prop(scene, "panview_lock_zoom")

        if show_runtime_controls:
            col.separator()
            row = col.row(align=True)
            ui_icons.operator(row, "view3d.panview_start_2d_nav", text=pgettext("Start 2D Nav"), name='tool', fallback='HAND')
            ui_icons.operator(row, "view3d.panview_fit_camera_view", text=pgettext("Fit"), name='window', fallback='FULLSCREEN_ENTER')
            row = col.row(align=True)
            row.operator("view3d.panview_zoom_camera_1to1", text=pgettext("1:1"), icon='ZOOM_IN')
            row.operator("view3d.panview_zoom_camera_2to1", text=pgettext("2:1"), icon='ZOOM_IN')
            col.separator()
            ui_icons.operator(col, "wm.panview_open_pie", text=pgettext("Open Pie Menu"), name='pie', fallback='MENU_PANEL')

    # Presets
    box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_presets", pgettext("Presets"), 'PRESET')
    if is_open:
        if len(scene.panview_preset_slots) == 0:
            ui_icons.operator(box, "view3d.panview_init_presets", name='plus', fallback='ADD', text=pgettext("Initialize Presets"))
        else:
            idx = max(0, min(int(scene.panview_preset_index), len(scene.panview_preset_slots) - 1))
            col = box.column(align=True)
            col.prop(scene, "panview_preset_index", text="")
            slot = scene.panview_preset_slots[idx]
            col.prop(slot, "name", text="")
            row = col.row(align=True)
            ui_icons.operator(row, "view3d.panview_preset_save", text=pgettext("Save"), name='preset', fallback='FILE_TICK')
            op = ui_icons.operator(row, "view3d.panview_preset_load", text=pgettext("Load"), name='refresh', fallback='FILE_REFRESH')
            op.apply_to_open_views = bool(show_window_manager)

    # Window manager
    if show_window_manager and wm is not None and hasattr(wm, "panview_tracked_windows"):
        box, is_open = _panview_fold_box(layout, scene, "panview_ui_show_window_manager", pgettext("Window Manager"), 'WINDOW')
        if is_open:
            col = box.column(align=True)
            ui_icons.operator(col, "view3d.panview_refresh_windows", text=pgettext("Refresh"), name='refresh', fallback='FILE_REFRESH')
            ui_icons.operator(col, "view3d.panview_update_all_views", text=pgettext("Update View"), name='check', fallback='FILE_TICK')
            ui_icons.operator(col, "view3d.panview_close_all_tracked_windows", text=pgettext("Close All"), name='close', fallback='PANEL_CLOSE')

            # The explicit Refresh/launch/close operators own stale-entry
            # reconciliation.  Draw replays the bounded RNA collection without
            # rescanning every Blender window for every N-panel repaint.
            valid_entries = tuple(wm.panview_tracked_windows)
            if not valid_entries:
                box.label(text=pgettext("No tracked windows."))
            else:
                for entry in valid_entries:
                    row = box.row(align=True)
                    row.label(text=f"{entry.camera_name}", translate=False)
                    ui_icons.set_large_icon_scale(row, 1.25)
                    ui_icons.operator(row, "view3d.panview_focus_tracked_window", text="", name='eye', fallback='RESTRICT_VIEW_OFF', emboss=False).window_ptr = entry.window_ptr
                    ui_icons.operator(row, "view3d.panview_close_tracked_window", text="", name='close', fallback='PANEL_CLOSE', emboss=False).window_ptr = entry.window_ptr


# =============================================================
# 11. Follow Active Camera handler
# =============================================================

def _apply_follow_update():
    if not _PANVIEW_RUNTIME_ENABLED:
        return None
    ctx = bpy.context
    scene = getattr(ctx, 'scene', None)
    if scene is not None and scene.panview_follow_active_camera and ctx.window_manager:
        update_all_tracked_views(ctx)
    return None


def _depsgraph_follow_handler(scene, depsgraph):
    global _follow_last_time
    if not _PANVIEW_RUNTIME_ENABLED:
        return
    now = time.time()
    if now - _follow_last_time < 0.2:
        return
    _follow_last_time = now

    # Closing a tracked window can run the depsgraph callback inside
    # wm.window_close. Its temporary window context is being torn down.
    # Apply viewport and region changes once Blender has settled that context.
    if scene.panview_follow_active_camera and not bpy.app.timers.is_registered(_apply_follow_update):
        bpy.app.timers.register(_apply_follow_update, first_interval=0.0)


# =============================================================
# 12. 登録処理
# =============================================================

PANVIEW_PROPERTY_GROUP_CLASSES = (
    PANVIEW_PresetSlot,
    PANVIEW_TrackedWindow,
)

PANVIEW_RUNTIME_CLASSES = (
    PANVIEW_OT_Start2DNav,
    PANVIEW_OT_FitCameraView,
    PANVIEW_OT_ZoomCamera1to1,
    PANVIEW_OT_ZoomCamera2to1,
    PANVIEW_OT_CloseWindow,
    PANVIEW_MT_Pie,
    PANVIEW_OT_OpenPie,

    PANVIEW_OT_InitPresets,
    PANVIEW_OT_PresetSave,
    PANVIEW_OT_PresetLoad,

    PANVIEW_OT_UpdateAllViews,
    PANVIEW_OT_RefreshWindows,
    PANVIEW_OT_CloseTrackedWindow,
    PANVIEW_OT_CloseAllTrackedWindows,
    PANVIEW_OT_FocusTrackedWindow,

    PANVIEW_OT_Create,
)

classes = PANVIEW_PROPERTY_GROUP_CLASSES + PANVIEW_RUNTIME_CLASSES


def poll_cameras(self, obj):
    return obj.type == 'CAMERA'


def _register_keymaps():
    return


def _unregister_keymaps():
    for km, kmi in _ADDON_KEYMAPS:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _ADDON_KEYMAPS.clear()


def register():
    global _follow_handler_registered, _PANVIEW_RUNTIME_ENABLED
    # Native registration is context-independent.  In particular, Blender's
    # user-preferences cold-start context may expose neither Scene nor
    # WindowManager even though bpy.types and class RNA are fully available.
    # Reuse only exact current-generation classes and published type properties.
    if panview_rna_registration_ready():
        _PANVIEW_RUNTIME_ENABLED = True
        return True
    _PANVIEW_RUNTIME_ENABLED = False

    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        bpy.app.translations.unregister(__name__)
        bpy.app.translations.register(__name__, translation_dict)

    for cls in classes:
        success, _newly_registered = _runtime_ledger.register_class_exact(
            cls,
            native_register=bpy.utils.register_class,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='PANVIEW_CLASS',
        )
        if not success:
            raise RuntimeError('RESTART_REQUIRED: Pan View class ownership mismatch')

    # Keep bl_info as the English source string; Blender translations supply Japanese display text.
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Launch a new 2D pan view. Includes 2D Pan/Zoom navigation, window management, presets, and camera guides."
                break
    except Exception:
        pass

    # Scene properties (existing + new)
    bpy.types.Scene.panview_camera_target = bpy.props.PointerProperty(
        name="Target Camera",
        type=bpy.types.Object,
        poll=poll_cameras,
        description="Select the camera to view.",
        update=_on_panview_setting_update,
    )

    # View settings (existing defaults preserved)
    bpy.types.Scene.panview_show_overlays = bpy.props.BoolProperty(
        name="Show Overlays", default=True,
        description="Toggle the visibility of viewport overlays.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_show_wireframes = bpy.props.BoolProperty(
        name="Wireframe", default=True,
        description="Toggle the display of wireframes over faces in the viewport.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_wireframe_opacity = bpy.props.FloatProperty(
        name="Wireframe Opacity", default=1.0, min=0.0, max=1.0,
        description="Set the opacity of wireframes in the viewport.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_show_xray = bpy.props.BoolProperty(
        name="X-Ray", default=True,
        description="Toggle X-Ray (transparent) display in the viewport.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_wire_color_type = bpy.props.EnumProperty(
        name="Wire Color",
        items=[('THEME', "Theme", ""), ('OBJECT', "Object", ""), ('RANDOM', "Random", "")],
        default='THEME',
        description="Set the wireframe color type for viewport shading.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_color_type = bpy.props.EnumProperty(
        name="Object Color",
        items=[
            ('MATERIAL', "Material", ""), ('OBJECT', "Object", ""),
            ('RANDOM', "Random", ""), ('ATTRIBUTE', "Attribute", ""),
            ('TEXTURE', "Texture", ""), ('SINGLE', "Custom", "")
        ],
        default='TEXTURE',
        description="Set the object color type for viewport shading.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_background_type = bpy.props.EnumProperty(
        name="Background",
        items=[('THEME', "Theme", ""), ('WORLD', "World", ""), ('VIEWPORT', "Custom", "")],
        default='VIEWPORT',
        description="Set the background type for viewport shading.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_background_color = bpy.props.FloatVectorProperty(
        name="Background Color", subtype='COLOR', size=3,
        default=(0.087, 0.087, 0.087), min=0.0, max=1.0,
        description="Set the custom background color. (Default: #555555)",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_show_object_outline = bpy.props.BoolProperty(
        name="Outline", default=True,
        description="Toggle the display of object outlines in the viewport.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_object_outline_color = bpy.props.FloatVectorProperty(
        name="Outline Color", subtype='COLOR', size=3,
        default=(0.0, 1.0, 1.0), min=0.0, max=1.0,
        description="Set the object outline color. (Default: #00FFFF)",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_xray_alpha = bpy.props.FloatProperty(
        name="X-Ray Alpha", default=0.8, min=0.0, max=1.0,
        description="Set the transparency level for X-Ray display.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_lock_rotation = bpy.props.BoolProperty(
        name="Lock Rotation", default=True,
        description="Lock the view rotation. Used to restrict to 2D panning.",
        update=_on_panview_setting_update)

    # New: window settings
    bpy.types.Scene.panview_launch_mode = bpy.props.EnumProperty(
        name="Launch Mode",
        translation_context=_PANVIEW_ENUM_CONTEXT,
        items=[('NEW', "New Window", ""), ('SPLIT', "Split Area", "")],
        default='NEW',
        description="Choose how to create the 2D view.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_split_factor = bpy.props.FloatProperty(
        name="Split Factor",
        default=0.5, min=0.1, max=0.9,
        description="Area split ratio when using Split Area mode.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_reuse_existing = bpy.props.BoolProperty(
        name="Reuse Existing Window",
        default=True,
        description="If a window for this camera is already open, reuse it instead of creating a new one.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_follow_active_camera = bpy.props.BoolProperty(
        name="Follow Active Camera",
        default=True,
        description="When enabled, launched views follow the scene's active camera.",
        update=_on_panview_runtime_setting_update,
    )
    bpy.types.Scene.panview_size_mode = bpy.props.EnumProperty(
        name="Size Mode",
        translation_context=_PANVIEW_ENUM_CONTEXT,
        items=[('FRACTION', "Fraction of Parent", ""), ('PIXELS', "Pixels", ""), ('RENDER', "Render Resolution", "")],
        default='FRACTION',
        description="Choose how the new 2D view window size is calculated. Fraction uses part of the parent window, Pixels uses exact width and height, and Render Resolution matches the current output resolution.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_window_fraction = bpy.props.FloatProperty(
        name="Window Fraction", default=0.5, min=0.1, max=1.0,
        description="Fraction of the parent window used when Size Mode is set to Fraction of Parent. For example, 0.5 creates a window about half the parent size.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_window_w = bpy.props.IntProperty(
        name="Window Width", default=800, min=64, max=10000,
        description="Exact width of the new 2D view window when Size Mode is set to Pixels.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_window_h = bpy.props.IntProperty(
        name="Window Height", default=600, min=64, max=10000,
        description="Exact height of the new 2D view window when Size Mode is set to Pixels.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_position_mode = bpy.props.EnumProperty(
        name="Position Mode",
        translation_context=_PANVIEW_ENUM_CONTEXT,
        items=[
            ('CURSOR', "Cursor Center", ""),
            ('PARENT', "Parent Center", ""),
            ('SCREEN', "Screen Center", ""),
            ('TL', "Top Left", ""),
            ('TR', "Top Right", ""),
            ('BL', "Bottom Left", ""),
            ('BR', "Bottom Right", ""),
        ],
        default='CURSOR',
        description="Choose where the new 2D view window appears on screen. Cursor Center is the most direct option, while the corner modes are useful for repeatable layouts.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_hide_ui_fullarea = bpy.props.BoolProperty(
        name="Hide UI (Full Area)",
        default=True,
        description="Hide headers/panels and switch to full area like Ctrl+Alt+Space.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_show_hud = bpy.props.BoolProperty(
        name="Show HUD (Active View)",
        default=False,
        description="Show a small on-screen hint overlay in the active 2D view.",
        update=_on_panview_runtime_setting_update,
    )

    # UI folding (to reduce N-panel height)
    bpy.types.Scene.panview_ui_show_window_settings = bpy.props.BoolProperty(
        name="UI: Window Settings", default=True,
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_ui_show_view_settings = bpy.props.BoolProperty(
        name="UI: View Settings", default=False,
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_ui_show_camera_guides = bpy.props.BoolProperty(
        name="UI: Camera Guides", default=False,
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_ui_show_2d_navigation = bpy.props.BoolProperty(
        name="UI: 2D Navigation", default=True,
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_ui_show_presets = bpy.props.BoolProperty(
        name="UI: Presets", default=True,
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_ui_show_window_manager = bpy.props.BoolProperty(
        name="UI: Window Manager", default=False,
        update=_on_panview_setting_update)


    # New: camera guides
    bpy.types.Scene.panview_show_safe_areas = bpy.props.BoolProperty(
        name="Safe Areas", default=True,
        description="Toggle camera safe areas.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_show_passepartout = bpy.props.BoolProperty(
        name="Passepartout", default=True,
        description="Toggle camera passepartout.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_passepartout_alpha = bpy.props.FloatProperty(
        name="Passepartout Alpha", default=0.5, min=0.0, max=1.0,
        description="Opacity of the dark area outside the camera frame. Increase it to focus more strongly on the visible frame area.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_composition_guide = bpy.props.EnumProperty(
        name="Composition Guide",
        items=[('NONE', "None", ""), ('THIRDS', "Thirds", ""), ('CENTER', "Center", ""), ('GOLDEN', "Golden Ratio", ""), ('DIAGONALS', "Diagonals", "")],
        default='THIRDS',
        description="Overlay a composition guide on the camera view. This helps with framing and layout while you work inside the 2D window.",
        update=_on_panview_setting_update)

    # New: 2D nav tuning
    bpy.types.Scene.panview_nav_mode = bpy.props.EnumProperty(
        name="Navigation Mode",
        items=[('PAN', "Pan Only", ""), ('PAN_ZOOM', "Pan + Zoom", "")],
        default='PAN_ZOOM',
        description="Choose whether the 2D navigation tool allows only panning or both panning and zooming.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_pan_sens = bpy.props.FloatProperty(
        name="Pan Sensitivity", default=1.0, min=0.01, max=10.0,
        description="How strongly mouse movement affects panning in the 2D navigation mode.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_zoom_sens = bpy.props.FloatProperty(
        name="Zoom Sensitivity", default=1.0, min=0.01, max=10.0,
        description="How strongly mouse movement affects zooming in the 2D navigation mode.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_invert_zoom = bpy.props.BoolProperty(
        name="Invert Zoom", default=False,
        description="Reverse the zoom direction in 2D navigation if the default motion feels backwards to you.",
        update=_on_panview_setting_update)
    bpy.types.Scene.panview_lock_zoom = bpy.props.BoolProperty(
        name="Lock Zoom", default=False,
        description="Prevent zoom changes during 2D navigation. This is useful when you only want to pan the framing.",
        update=_on_panview_setting_update)

    # Presets
    bpy.types.Scene.panview_preset_slots = bpy.props.CollectionProperty(type=PANVIEW_PresetSlot)
    bpy.types.Scene.panview_preset_index = bpy.props.IntProperty(
        default=0,
        min=0,
        description="Index of the currently selected preset slot. This is managed automatically by the preset UI.",
        update=_on_panview_setting_update)

    # Window tracking in WindowManager
    bpy.types.WindowManager.panview_tracked_windows = bpy.props.CollectionProperty(type=PANVIEW_TrackedWindow)

    # Keymaps
    _register_keymaps()

    # Scene/WindowManager instances are intentionally not inspected here.
    # The validated Suite authority restores registered RNA after the complete
    # package transaction, and the existing load_post path applies Pan View's
    # sidecar and runtime hooks once Blender exposes live context owners.
    _PANVIEW_RUNTIME_ENABLED = True
    return panview_rna_registration_ready()


def unregister() -> bool:
    global _follow_handler_registered, _PANVIEW_RUNTIME_ENABLED
    _PANVIEW_RUNTIME_ENABLED = False

    # Restore bl_info description
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Launch a new 2D pan view. Includes 2D Pan/Zoom navigation, window management, presets, and camera guides."
                break
    except Exception:
        pass

    # Handlers
    if _follow_handler_registered:
        try:
            bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_follow_handler)
        except Exception:
            pass
        _follow_handler_registered = False

    # Keymaps first so they never keep references to operators being removed.
    _unregister_keymaps()

    # Runtime draw handlers before class/property teardown.
    hud_disable()

    # Unregister runtime/operator classes before deleting RNA properties used by the UI.
    for cls in reversed(PANVIEW_RUNTIME_CLASSES):
        if not _runtime_ledger.class_recorded_current(cls):
            return False
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='PANVIEW_RUNTIME_CLASS',
        ):
            return False

    # Remove props after runtime/UI classes are gone.
    props_scene = [
        "panview_camera_target",
        "panview_show_overlays", "panview_show_wireframes", "panview_wireframe_opacity",
        "panview_show_xray", "panview_wire_color_type", "panview_color_type",
        "panview_background_type", "panview_background_color",
        "panview_show_object_outline", "panview_object_outline_color",
        "panview_xray_alpha", "panview_lock_rotation",

        "panview_launch_mode", "panview_split_factor", "panview_reuse_existing", "panview_follow_active_camera",
        "panview_size_mode", "panview_window_fraction", "panview_window_w", "panview_window_h",
        "panview_position_mode", "panview_hide_ui_fullarea", "panview_show_hud",

        "panview_ui_show_window_settings", "panview_ui_show_view_settings", "panview_ui_show_camera_guides",
        "panview_ui_show_2d_navigation", "panview_ui_show_presets", "panview_ui_show_window_manager",

        "panview_show_safe_areas", "panview_show_passepartout", "panview_passepartout_alpha", "panview_composition_guide",

        "panview_nav_mode", "panview_pan_sens", "panview_zoom_sens", "panview_invert_zoom", "panview_lock_zoom",

        "panview_preset_slots", "panview_preset_index",
    ]
    for p in props_scene:
        if _runtime_ledger.property_recorded_current(bpy.types.Scene, p):
            delattr(bpy.types.Scene, p)

    if _runtime_ledger.property_recorded_current(bpy.types.WindowManager, "panview_tracked_windows"):
        delattr(bpy.types.WindowManager, "panview_tracked_windows")

    # PropertyGroup classes last, after their owner properties are deleted.
    for cls in reversed(PANVIEW_PROPERTY_GROUP_CLASSES):
        if not _runtime_ledger.class_recorded_current(cls):
            return False
        if not _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='PANVIEW_PROPERTY_GROUP_CLASS',
        ):
            return False

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    return True


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()
