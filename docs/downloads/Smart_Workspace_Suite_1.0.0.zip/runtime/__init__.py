# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
# Blender Extension / user_default compatible package

import os
import sys

import bpy
from .translation import localized_layout
from bpy.types import AddonPreferences
from bpy.props import PointerProperty
from bpy.app.handlers import persistent

from . import translation
from .translation import _T
from .. import storage as _suite_storage
from .. import runtime_ledger as _runtime_ledger

ADDON_TAB_NAME = "Smart Workspace"
_WORKSPACE_MANAGER_MODULE = None
from . import core
from . import ui_operators

_PANVIEW_MODULE = None


def _workspace_manager_module():
    global _WORKSPACE_MANAGER_MODULE
    if _WORKSPACE_MANAGER_MODULE is None:
        try:
            from .. import workspace_manager as _workspace_manager
            _WORKSPACE_MANAGER_MODULE = _workspace_manager
        except Exception:
            _WORKSPACE_MANAGER_MODULE = False
    return _WORKSPACE_MANAGER_MODULE if _WORKSPACE_MANAGER_MODULE is not False else None


def _panview_module():
    global _PANVIEW_MODULE
    if _PANVIEW_MODULE is None:
        from . import panview as _panview
        _PANVIEW_MODULE = _panview
    return _PANVIEW_MODULE


bl_info = {
    "name": "Smart Workspace",
    "author": "JELararagi",
    "version": (1, 1, 154),
    "blender": (5, 1, 0),
    "location": "Smart Tools > Smart Workspace",
    "description": "Workspace launcher suite integrated into the Smart Tools N-panel tab with bundled workspace utilities and floating panel tools.",
    "category": "Interface",
}


# =============================================================
# Preferences & Handlers
# =============================================================

def update_category_event(self, context):
    # Compatibility no-op: the manager UI now lives in the standard 3D View N-panel.
    return None


class NPTL_Preferences(AddonPreferences):
    """Compatibility shell; Smart Workspace runtime settings live in the N-panel storage."""

    bl_idname = __package__ if __package__ else __name__

    def draw(self, context):
        return None


_runtime_refresh_generation = 0
_runtime_refresh_timers = set()
_runtime_state_flags = {
    'load_post_enabled': False,
    'live_pin_follow_enabled': False,
}


def _runtime_module_key(module_name: str) -> str:
    text = str(module_name or '').strip().lower()
    parts = [part for part in text.split('.') if part]
    if 'smart_workspace_suite' in parts:
        idx = parts.index('smart_workspace_suite')
        return '.'.join(parts[idx:])
    return text


def _runtime_callback_key(fn):
    if not callable(fn):
        return ('', '')
    return (
        _runtime_module_key(getattr(fn, '__module__', '')),
        str(getattr(fn, '__name__', '') or ''),
    )


def _runtime_callbacks_equivalent(left, right) -> bool:
    if left is right:
        return True
    left_key = _runtime_callback_key(left)
    right_key = _runtime_callback_key(right)
    return bool(left_key[0] and left_key[1] and left_key == right_key)


def _runtime_refresh_timer_slot(timer_fn) -> str:
    module_name, function_name = _runtime_callback_key(timer_fn)
    return f'runtime.refresh.{module_name}.{function_name}'


def _iter_loaded_runtime_modules():
    """Yield only this exact imported module; never scan stale generations."""
    module = sys.modules.get(__name__)
    if module is not None:
        yield module


def _purge_runtime_timer_functions(*names: str) -> None:
    wanted = {str(name or '') for name in names if name}
    for name in wanted:
        try:
            _suite_storage.unregister_timer_slot(
                f'runtime.{name}',
                globals().get(name),
            )
        except Exception:
            pass
    candidates = set()
    for module in _iter_loaded_runtime_modules():
        try:
            candidates.update(fn for fn in tuple(getattr(module, '_runtime_refresh_timers', ()) or ()) if callable(fn))
        except Exception:
            pass
        for name in wanted:
            try:
                fn = getattr(module, name, None)
            except Exception:
                fn = None
            if callable(fn):
                candidates.add(fn)
    for timer_fn in tuple(candidates):
        try:
            _suite_storage.unregister_timer_slot(
                _runtime_refresh_timer_slot(timer_fn),
                timer_fn,
            )
        except Exception:
            # Never unregister a callback outside the captured package slot.
            pass


def _register_runtime_refresh_timer(timer_fn, *, first_interval: float):
    try:
        _runtime_refresh_timers.add(timer_fn)
    except Exception:
        pass
    if not _suite_storage.register_timer_slot(
        _runtime_refresh_timer_slot(timer_fn),
        timer_fn,
        first_interval=max(0.01, float(first_interval)),
        persistent=False,
    ):
        raise RuntimeError('Unable to register Smart Workspace runtime refresh timer')


def _clear_runtime_refresh_timers():
    _purge_runtime_timer_functions('delayed_startup_apply', 'delayed_sidebar_layout_restore')
    for module in _iter_loaded_runtime_modules():
        try:
            getattr(module, '_runtime_refresh_timers', set()).clear()
        except Exception:
            pass
    _runtime_refresh_timers.clear()


def schedule_runtime_icon_refresh(reinstall_first: bool = False, *, attempts: int = 3, first_interval: float = 0.08):
    """Request a cheap redraw after an already-completed runtime refresh."""
    del reinstall_first, attempts, first_interval
    global _runtime_refresh_generation
    _runtime_refresh_generation += 1
    try:
        ui_operators.tag_redraw_all_properties_areas(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def schedule_detected_tab_refresh(*, attempts: int = 6, first_interval: float = 0.12, interval: float = 0.55) -> None:
    """Redraw after the caller's synchronous tab discovery; never rescan here."""
    del attempts, first_interval, interval
    try:
        ui_operators.tag_redraw_all_properties_areas(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def _addon_preferences(context=None):
    try:
        return core._addon_preferences(context)
    except Exception:
        return None


def _pref_enabled(name: str, default: bool = False, context=None) -> bool:
    prefs = _addon_preferences(context)
    if prefs is None:
        return bool(default)
    try:
        return bool(getattr(prefs, name, default))
    except Exception:
        return bool(default)


def _auto_restore_on_file_load(context=None) -> bool:
    return _pref_enabled('auto_restore_on_file_load', False, context)


def _restore_applied_sidebar_layout_on_start(context=None) -> bool:
    """The last N-panel Apply survives a restart until Reset forgets it.

    It follows N-panel State Save ("restored once after Blender starts"), not
    the heavier load_post rescan behind Auto Restore on File Load, which is
    off by default and used to be the only way to bring the Apply back.
    """
    if _auto_restore_on_file_load(context):
        return True
    try:
        if not _suite_storage.n_panel_state_save_enabled(True):
            return False
        return os.path.isfile(core._sidebar_layout_path())
    except Exception:
        return False


def _live_pin_follow_enabled(context=None) -> bool:
    return _pref_enabled('live_pin_follow_enabled', False, context)


def _has_live_smart_tools_contexts() -> bool:
    try:
        from . import navigation_properties as _navigation_properties
        has_contexts = getattr(_navigation_properties, '_has_existing_smart_tools_contexts', None)
        if callable(has_contexts):
            return bool(has_contexts())
    except Exception:
        pass
    return False


def _lightweight_startup_sync(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None or not hasattr(getattr(ctx, 'window_manager', None), 'nptl_settings'):
        return
    try:
        core.load_config_from_file(ctx)
    except Exception:
        pass
    try:
        core._sync_selector_to_active_workspace(ctx)
    except Exception:
        pass
    try:
        ui_operators.tag_redraw_all_properties_areas(ctx)
    except Exception:
        pass


def _remove_equivalent_handler_callbacks(handler_list, fn) -> None:
    for candidate in tuple(handler_list or ()):
        if not _runtime_callbacks_equivalent(candidate, fn):
            continue
        try:
            handler_list.remove(candidate)
        except Exception:
            pass


def _ensure_load_post_handler(enabled: bool) -> None:
    enabled = bool(enabled)
    handlers = bpy.app.handlers.load_post
    _remove_equivalent_handler_callbacks(handlers, nptl_load_post)
    if enabled:
        try:
            handlers.append(nptl_load_post)
        except Exception:
            pass
    else:
        _purge_runtime_timer_functions('delayed_startup_apply', 'delayed_sidebar_layout_restore')
    _runtime_state_flags['load_post_enabled'] = enabled


def _ensure_live_follow_runtime(enabled: bool, context=None) -> None:
    """Enable the Blender 5.x-safe, draw-event pin-follow bridge on demand.

    The retired implementation moved registered Panel classes from a msgbus
    callback and timer.  The current implementation only mirrors saved pin
    state through Blender's native ``Panel.use_pin`` during an existing panel
    draw.  OFF removes the timer and msgbus owner at once, and each wrapper as
    soon as the panels it pinned have been drawn unpinned.
    """
    enabled = bool(enabled)
    ctx = context or getattr(bpy, 'context', None)
    try:
        core.teardown_msgbus()
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(core.pin_update_loop):
            bpy.app.timers.unregister(core.pin_update_loop)
    except Exception:
        pass
    if enabled:
        try:
            profile = core._active_profile(ctx)
        except Exception:
            profile = None
        try:
            core.apply_standard_pin_state_from_profile(ctx, profile)
        except Exception:
            # A missing UI Area during background startup is not a partially
            # enabled runtime.  Install the wrappers without forcing redraw.
            try:
                core.install_standard_panel_pin_runtime(ctx)
            except Exception:
                enabled = False
    else:
        try:
            core.release_standard_panel_pins(ctx)
        except Exception:
            pass
    _runtime_state_flags['live_pin_follow_enabled'] = enabled

def prepare_runtime_for_use(context=None, *, refresh_ui: bool = False) -> None:
    ctx = context or getattr(bpy, 'context', None)
    _lightweight_startup_sync(ctx)
    try:
        from .. import tool_runtime as _tool_runtime
        ensure_ui = getattr(_tool_runtime, 'ensure_ui_runtime', None)
        if callable(ensure_ui):
            ensure_ui()
    except Exception:
        pass
    if refresh_ui:
        # Explicit refresh boundary: expensive Manager API and private workspace
        # hook discovery are captured once here, never from Panel.poll/draw.
        try:
            ui_operators.refresh_smart_tools_manager_decision_snapshot(ctx)
        except Exception:
            pass
        try:
            ui_operators.refresh_workspace_ui_order_cache(ctx)
        except Exception:
            pass
        try:
            ui_operators.refresh_properties_pseudo_tab_runtime(ctx, reinstall=False)
        except Exception:
            pass


def ensure_panview_runtime() -> bool:
    """Ensure Pan View native RNA without requiring a live context instance.

    Blender 5.1 can call add-on registration from a restricted Preferences
    context where ``bpy.context.scene`` and ``window_manager`` are unavailable.
    Native registration is therefore validated solely from exact generation
    class ownership and properties published on ``bpy.types``.  Scene-bound
    sidecar replay remains in the load_post path.
    """
    panview = _panview_module()
    ready_fn = getattr(panview, 'panview_rna_registration_ready', None)
    if callable(ready_fn) and bool(ready_fn()):
        return True
    register_fn = getattr(panview, 'register', None)
    if not callable(register_fn):
        return False
    try:
        result = register_fn()
    except Exception:
        return False
    return bool(result is not False and callable(ready_fn) and ready_fn())

def apply_preference_runtime_state(context=None, *, startup: bool = False) -> None:
    ctx = context or getattr(bpy, 'context', None)
    restore_enabled = _auto_restore_on_file_load(ctx)
    live_follow_enabled = _live_pin_follow_enabled(ctx)
    previous_restore = bool(_runtime_state_flags.get('load_post_enabled', False))

    _ensure_load_post_handler(restore_enabled)
    _ensure_live_follow_runtime(live_follow_enabled, ctx)

    # Startup RNA has already been replayed once by persistence.load_all_settings.
    # Activate leases only; never invoke a second configuration restore that can
    # overwrite the canonical graph after registration.
    if startup:
        if restore_enabled or _restore_applied_sidebar_layout_on_start(ctx):
            # delayed_startup_apply does not reliably survive the start-up file
            # load, and this replay is what knows the saved switch is on.
            _suite_storage.register_timer_slot(
                'runtime.delayed_sidebar_layout_restore',
                delayed_sidebar_layout_restore,
                first_interval=0.25,
                persistent=True,
            )
        return

    if restore_enabled and not previous_restore:
        try:
            nptl_load_post(None)
        except Exception:
            pass
        return

    if restore_enabled or live_follow_enabled or _has_live_smart_tools_contexts():
        prepare_runtime_for_use(ctx, refresh_ui=True)


def delayed_sidebar_layout_restore():
    ctx = bpy.context
    if _restore_applied_sidebar_layout_on_start(ctx):
        try:
            core.restore_saved_sidebar_layout(ctx)
        except Exception:
            pass
    return None


def delayed_startup_apply():
    ctx = bpy.context
    if hasattr(ctx.window_manager, "nptl_settings"):
        try:
            # Startup refresh is non-destructive.  Smart Tools panels can appear
            # after Workspace itself registers.  The timer runs after add-on
            # startup, so discard the early partial inventory exactly once.
            core._invalidate_panel_discovery_cache()
            core._refresh_all_profiles_detected_tabs_logic(ctx, prune_references=False, save=False)
        except Exception:
            pass
        ws = core._sync_selector_to_active_workspace(ctx)
        core._on_workspace_activated(ctx, ws, apply_layout=True)
        if _restore_applied_sidebar_layout_on_start(ctx):
            try:
                core.restore_saved_sidebar_layout(ctx)
            except Exception:
                pass
        if _live_pin_follow_enabled(ctx):
            try:
                core.install_standard_panel_pin_runtime(ctx)
            except Exception:
                pass
        try:
            ui_operators.refresh_properties_pseudo_tab_runtime(ctx, reinstall=False)
        except Exception:
            pass
    try:
        schedule_detected_tab_refresh(attempts=4, first_interval=0.20, interval=0.65)
    except Exception:
        pass
    try:
        schedule_runtime_icon_refresh(reinstall_first=False, attempts=2, first_interval=0.08)
    except Exception:
        pass
    return None


@persistent
def nptl_load_post(dummy):
    try:
        ctx = bpy.context
        if hasattr(ctx.window_manager, "nptl_settings"):
            core.load_config_from_file(ctx)
            try:
                panview = _panview_module()
                apply_panview = getattr(panview, 'apply_persistent_panview_settings', None)
                if callable(apply_panview):
                    # Context-bound sidecar replay is deliberately delayed to
                    # load_post; registration itself never requires Scene/WM.
                    apply_panview(ctx)
            except Exception:
                pass
            try:
                from .. import tool_runtime as _tool_runtime
                apply_tools = getattr(_tool_runtime, 'apply_preference_runtime_state', None)
                if callable(apply_tools):
                    apply_tools(ctx)
            except Exception:
                pass
            ws = core._sync_selector_to_active_workspace(ctx)
            prof = core._active_profile(ctx)
            if prof and len(prof.detected_tabs) == 0:
                core._refresh_detected_tabs_logic(ctx, prof)

            try:
                if hasattr(prof, 'detected_panels') and len(prof.detected_panels) == 0:
                    core._refresh_detected_panels_logic(ctx, prof)
            except Exception:
                pass

            _purge_runtime_timer_functions('delayed_startup_apply')
            _suite_storage.register_timer_slot(
                'runtime.delayed_startup_apply',
                delayed_startup_apply,
                first_interval=0.10,
                persistent=False,
            )

        try:
            ui_operators.refresh_smart_tools_manager_decision_snapshot(ctx)
        except Exception:
            pass
        try:
            ui_operators.refresh_workspace_ui_order_cache(ctx)
        except Exception:
            pass
        try:
            ui_operators.tag_redraw_all_properties_areas(ctx)
        except Exception:
            pass

        try:
            schedule_detected_tab_refresh(attempts=5, first_interval=0.18, interval=0.70)
        except Exception:
            pass

        try:
            schedule_runtime_icon_refresh(reinstall_first=True, attempts=3, first_interval=0.08)
        except Exception:
            pass

        # Standard N-panel mode: do not stamp or mutate Blender Panel classes
        # during load_post. Older builds stored nptl_original_category on every
        # VIEW_3D panel and later re-registered panels to reorder tabs; that
        # path is intentionally disabled for Blender 5.x draw stability.

    except Exception as e:
        _nptl_warn_once("init", e)


_NPTL_WARNED = set()


def _nptl_warn_once(key, exc):
    if key not in _NPTL_WARNED:
        _NPTL_WARNED.add(key)
        print(f"[Smart Workspace] NPTL {key}: {exc}")


# =============================================================
# Registration
# =============================================================

MAIN_PROPERTY_GROUP_CLASSES = (
    core.NPTL_TabRef,
    core.NPTL_RecentItem,
    core.NPTL_FavoritePanel,
    core.NPTL_DetectedPanel,
    core.NPTL_FloatingPanelEntry,
    core.NPTL_CategoryItem,
    core.NPTL_DetectedTab,
    core.NPTL_WorkspaceProfile,
    core.NPTL_Settings,
)

MAIN_RUNTIME_CLASSES = (
    ui_operators.NPTL_OT_manage_categories,
    ui_operators.NPTL_OT_manage_contents,
    ui_operators.NPTL_OT_manage_global_tabs,
    ui_operators.NPTL_OT_cleanup_unused_tabs,
    ui_operators.NPTL_OT_refresh_panel_pool,
    ui_operators.NPTL_OT_toggle_pin,
    ui_operators.NPTL_OT_toggle_favorite_tab,
    ui_operators.NPTL_OT_toggle_favorite_panel,
    ui_operators.NPTL_OT_call_panel,
    ui_operators.NPTL_OT_open_panel_popup,
    ui_operators.NPTL_OT_smart_toggle,
    ui_operators.NPTL_OT_launcher,
    ui_operators.NPTL_OT_hotbox,
    ui_operators.NPTL_OT_set_popup_tab,
    ui_operators.NPTL_OT_select_workspace,
    ui_operators.NPTL_MT_workspace_menu,
    # The suite-level common operator owns smart_workspace_suite.open_help so it
    # remains available before and after deferred runtime loading without a
    # duplicate bl_idname registration attempt.
    ui_operators.NPTL_OT_copy_workspace_profile,
    ui_operators.NPTL_OT_repair_workspace_manager_runtime,
    ui_operators.NPTL_OT_export_settings,
    ui_operators.NPTL_OT_import_settings,
    ui_operators.NPTL_OT_open_category_window,
    ui_operators.NPTL_OT_fp_open,
    ui_operators.NPTL_OT_fp_edit_settings,
    ui_operators.NPTL_OT_panview_popup,
    ui_operators.VIEW3D_OT_toggle_local_ui,
    ui_operators.NPTL_OT_toggle_ui_section,
    ui_operators.NPTL_OT_toggle_properties_pseudo_tab,
    ui_operators.NPTL_UL_category,
    ui_operators.NPTL_UL_tab_content,
    ui_operators.NPTL_UL_detected,
    ui_operators.NPTL_UL_detected_panels,
    ui_operators.NPTL_PT_properties_root,
    ui_operators.NPTL_PT_properties_root_image_editor,
    ui_operators.NPTL_PT_properties_root_node_editor,
    ui_operators.NPTL_PT_properties_root_sequence_editor,
    ui_operators.NPTL_PT_properties_root_clip_editor,
    ui_operators.NPTL_PT_properties_root_dopesheet_editor,
    ui_operators.NPTL_PT_properties_root_graph_editor,
    ui_operators.NPTL_PT_properties_root_nla_editor,
    ui_operators.NPTL_PT_properties_root_text_editor,
    ui_operators.NPTL_PT_properties_root_file_browser,
    ui_operators.NPTL_PT_properties_root_spreadsheet,
)

classes = MAIN_PROPERTY_GROUP_CLASSES + MAIN_RUNTIME_CLASSES


_OBSOLETE_NPTL_OPERATOR_CLASS_NAMES = (
    'NPTL_OT_save_preset',
    'NPTL_OT_load_preset',
    'NPTL_OT_delete_preset',
)

_OBSOLETE_NPTL_PANEL_CLASS_NAMES = (
    'VIEW3D_PT_nptl_manager',
    'NPTL_PT_properties_always_active',
    'NPTL_PT_properties_workspace',
    'NPTL_PT_properties_categories',
    'NPTL_PT_properties_pool',
    'NPTL_PT_properties_runtime',
    'NPTL_PT_properties_integrated_tools',
    'NPTL_PT_properties_panview',
    'NPTL_PT_properties_local_ui_toggle',
    'NPTL_PT_properties_io',
)

_CURRENT_NPTL_PANEL_CLASS_NAMES = (
    'NPTL_PT_properties_root',
    'NPTL_PT_properties_root_image_editor',
    'NPTL_PT_properties_root_node_editor',
    'NPTL_PT_properties_root_sequence_editor',
    'NPTL_PT_properties_root_clip_editor',
    'NPTL_PT_properties_root_dopesheet_editor',
    'NPTL_PT_properties_root_graph_editor',
    'NPTL_PT_properties_root_nla_editor',
    'NPTL_PT_properties_root_text_editor',
    'NPTL_PT_properties_root_file_browser',
    'NPTL_PT_properties_root_spreadsheet',
)


def _unregister_bpy_type_class_name(name: str) -> None:
    """Compatibility hook; never unregister a class without exact ledger proof."""
    target_name = str(name or '')
    cls = next(
        (candidate for candidate in MAIN_RUNTIME_CLASSES
         if isinstance(candidate, type) and getattr(candidate, '__name__', '') == target_name),
        None,
    )
    if isinstance(cls, type) and _runtime_ledger.class_recorded_current(cls):
        _runtime_ledger.unregister_class_exact(
            cls,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='RUNTIME_COMPAT_CLASS',
        )


def _purge_stale_nptl_panel_classes() -> None:
    """No-op by design: old/foreign Panel RNA is never adopted or deleted."""
    return None


def _sws_category_key(value: object) -> str:
    try:
        text = str(value or '').casefold()
    except Exception:
        return ''
    return ''.join(ch for ch in text if ch.isalnum())


def _iter_registered_smart_workspace_panel_candidates():
    """Return only exact current-generation classes already in the ledger."""
    for cls in MAIN_RUNTIME_CLASSES:
        if _runtime_ledger.class_is_current(cls):
            yield cls


def _sws_current_root_panel_class():
    return getattr(ui_operators, 'NPTL_PT_properties_root', None)


def _sws_is_current_smart_workspace_root(cls) -> bool:
    root_cls = _sws_current_root_panel_class()
    return isinstance(root_cls, type) and cls is root_cls


def _sws_is_registered_panel_class(cls) -> bool:
    return isinstance(cls, type) and _runtime_ledger.class_is_current(cls)


def _sws_is_manager_owned_panel(cls) -> bool:
    del cls
    return False


def _sws_retire_sidebar_panel_class(cls) -> None:
    # Registration/reload repair cannot mutate displayed RNA.  A class identity
    # mismatch is handled by the generation gate as RESTART_REQUIRED.
    if isinstance(cls, type) and not _runtime_ledger.class_is_current(cls):
        _runtime_ledger.mark_restart_required('PANEL_IDENTITY_MISMATCH')


def purge_duplicate_smart_workspace_view3d_panels() -> None:
    """Validate exact native Panel identities without mutating foreign RNA."""
    for cls in MAIN_RUNTIME_CLASSES:
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
            state, _published = _runtime_ledger.class_publication_state(cls)
            if state in {'FOREIGN', 'ERROR'}:
                _runtime_ledger.mark_restart_required('PANEL_IDENTITY_MISMATCH')
        except Exception:
            continue
    return None


_SIDEBAR_RUNTIME_REGISTERED = False


_RUNTIME_REGISTERED_CLASSES = []
_RUNTIME_NEWLY_REGISTERED_CLASSES = []
_RUNTIME_NEW_PROPERTIES = []


def _rna_property_definition(owner_type, property_name: str):
    try:
        properties = getattr(getattr(owner_type, 'bl_rna', None), 'properties', None)
        getter = getattr(properties, 'get', None)
        return getter(property_name) if callable(getter) else None
    except Exception:
        return None


def _nptl_pointer_exists() -> bool:
    return _rna_property_definition(bpy.types.WindowManager, 'nptl_settings') is not None


def _nptl_pointer_is_suite_owned() -> bool:
    return _runtime_ledger.property_is_current(
        bpy.types.WindowManager,
        'nptl_settings',
        core.NPTL_Settings,
    )


def _nptl_pointer_teardown_unsafe() -> bool:
    try:
        from .. import persistence as _suite_persistence
        if bool(
            getattr(_suite_persistence, '_FILE_LOAD_IN_PROGRESS', False)
            or getattr(_suite_persistence, '_RESTORING', False)
            or getattr(_suite_persistence, '_RESTORE_PENDING', False)
        ):
            return True
    except Exception:
        pass
    return bool(_suite_storage.registration_write_guard_active())


def _registered_runtime_class(name: str):
    try:
        candidate = getattr(bpy.types, str(name or ''), None)
        return candidate if isinstance(candidate, type) else None
    except Exception:
        return None


def _register_runtime_class_idempotent(cls) -> bool:
    """Register exact class identity or stop with RESTART_REQUIRED."""
    if not isinstance(cls, type):
        return False
    success, newly_registered = _runtime_ledger.register_class_exact(
        cls,
        native_register=bpy.utils.register_class,
        native_unregister=bpy.utils.unregister_class,
        reason_prefix='RUNTIME_CLASS',
    )
    if not success:
        raise RuntimeError('RESTART_REQUIRED: runtime class identity mismatch')
    if cls not in _RUNTIME_REGISTERED_CLASSES:
        _RUNTIME_REGISTERED_CLASSES.append(cls)
    if newly_registered and cls not in _RUNTIME_NEWLY_REGISTERED_CLASSES:
        _RUNTIME_NEWLY_REGISTERED_CLASSES.append(cls)
    return bool(newly_registered)


def _ensure_nptl_settings_pointer() -> bool:
    owner = bpy.types.WindowManager
    if _nptl_pointer_exists():
        if _nptl_pointer_is_suite_owned():
            return True
        _runtime_ledger.mark_restart_required('NPTL_POINTER_IDENTITY_MISMATCH')
        return False
    if not _runtime_ledger.class_is_current(core.NPTL_Settings):
        _runtime_ledger.mark_restart_required('NPTL_SETTINGS_CLASS_IDENTITY_UNPROVEN')
        return False
    created = False
    try:
        owner.nptl_settings = PointerProperty(type=core.NPTL_Settings)
        created = True
        if not _runtime_ledger.record_property(
            owner, 'nptl_settings', core.NPTL_Settings,
            remover=lambda _handle=None: delattr(owner, 'nptl_settings'),
            newly_registered=True,
        ):
            raise RuntimeError('NPTL pointer ledger failed')
        if (owner, 'nptl_settings') not in _RUNTIME_NEW_PROPERTIES:
            _RUNTIME_NEW_PROPERTIES.append((owner, 'nptl_settings'))
        return _nptl_pointer_is_suite_owned()
    except Exception:
        if created:
            try:
                delattr(owner, 'nptl_settings')
            except Exception:
                pass
        _runtime_ledger.mark_restart_required('NPTL_POINTER_REGISTRATION_FAILED')
        return False


def _remove_nptl_settings_pointer() -> bool:
    if not _nptl_pointer_exists():
        return True
    if not _nptl_pointer_is_suite_owned():
        return True
    if _nptl_pointer_teardown_unsafe():
        return False
    try:
        del bpy.types.WindowManager.nptl_settings
    except Exception:
        return False
    return _rna_property_definition(bpy.types.WindowManager, 'nptl_settings') is None


def _rollback_runtime_registration() -> None:
    _runtime_ledger.rollback_new_items(
        list(_RUNTIME_NEWLY_REGISTERED_CLASSES),
        list(_RUNTIME_NEW_PROPERTIES),
    )
    _RUNTIME_NEWLY_REGISTERED_CLASSES.clear()
    _RUNTIME_NEW_PROPERTIES.clear()


def _register_runtime_translations_idempotent() -> None:
    try:
        bpy.app.translations.register(__name__, translation.translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation.translation_dict)
        except Exception:
            pass
    except Exception:
        pass


def _ensure_nptl_settings_pointer() -> bool:
    """Publish only the exact PropertyGroup owned by this active generation."""
    owner = bpy.types.WindowManager
    if _nptl_pointer_exists():
        if _nptl_pointer_is_suite_owned():
            return True
        _runtime_ledger.mark_restart_required('NPTL_POINTER_IDENTITY_MISMATCH')
        return False
    if not _runtime_ledger.class_is_current(core.NPTL_Settings):
        _runtime_ledger.mark_restart_required('NPTL_SETTINGS_CLASS_IDENTITY_UNPROVEN')
        return False
    created = False
    try:
        owner.nptl_settings = PointerProperty(type=core.NPTL_Settings)
        created = True
        if not _runtime_ledger.record_property(
            owner, 'nptl_settings', core.NPTL_Settings,
            remover=lambda _handle=None: delattr(owner, 'nptl_settings'),
            newly_registered=True,
        ):
            raise RuntimeError('NPTL pointer ledger failed')
        if (owner, 'nptl_settings') not in _RUNTIME_NEW_PROPERTIES:
            _RUNTIME_NEW_PROPERTIES.append((owner, 'nptl_settings'))
        if not _nptl_pointer_is_suite_owned():
            raise RuntimeError('NPTL pointer exact-identity verification failed')
        return True
    except Exception:
        if created:
            try:
                delattr(owner, 'nptl_settings')
            except Exception:
                pass
        _runtime_ledger.mark_restart_required('NPTL_POINTER_REGISTRATION_FAILED')
        return False


def _remove_nptl_settings_pointer() -> bool:
    """Remove only this generation's exact pointer at a safe boundary."""
    if not _nptl_pointer_exists():
        return True
    if not _nptl_pointer_is_suite_owned():
        return True
    if _nptl_pointer_teardown_unsafe():
        return False
    descriptor = _rna_property_definition(bpy.types.WindowManager, 'nptl_settings')
    if descriptor is None or not _runtime_ledger.property_is_current(
        bpy.types.WindowManager, 'nptl_settings', core.NPTL_Settings, descriptor=descriptor
    ):
        return True
    try:
        del bpy.types.WindowManager.nptl_settings
    except Exception:
        return False
    return _rna_property_definition(bpy.types.WindowManager, 'nptl_settings') is None


def _stop_startup_runtime_timers_and_handlers() -> None:
    try:
        _clear_runtime_refresh_timers()
    except Exception:
        pass
    try:
        _ensure_load_post_handler(False)
    except Exception:
        pass
    try:
        _ensure_live_follow_runtime(False, getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        purge_rename = getattr(core, '_purge_stale_rename_timers', None)
        if callable(purge_rename):
            purge_rename()
        elif core._rename_timer and bpy.app.timers.is_registered(core._rename_timer):
            bpy.app.timers.unregister(core._rename_timer)
    except Exception:
        pass


def register_sidebar_runtime() -> None:
    """Register the native Smart Workspace N-panel without startup timers.

    This path restores the visible N-panel tab at add-on enable, but avoids the
    heavier startup refresh jobs that were responsible for viewport first-drag
    latency.  Full runtime features can still be initialized explicitly later.
    """
    global _SIDEBAR_RUNTIME_REGISTERED
    _root_cls = getattr(ui_operators, 'NPTL_PT_properties_root', None)
    if (
        _SIDEBAR_RUNTIME_REGISTERED
        and isinstance(_root_cls, type)
        and _runtime_ledger.class_is_current(_root_cls)
        and _nptl_pointer_is_suite_owned()
    ):
        try:
            _draw = getattr(_root_cls, 'draw', None) if isinstance(_root_cls, type) else None
            _mod = str(getattr(_root_cls, '__module__', '') or '') if isinstance(_root_cls, type) else ''
            _revision = str(getattr(_root_cls, '_smart_workspace_panel_revision', '') or '') if isinstance(_root_cls, type) else ''
            _draw_revision = str(getattr(_draw, '_smart_workspace_draw_revision', '') or '')
            if callable(_draw) and _revision in {'1.1.154'} and _draw_revision in {'1.1.154'} and _mod.startswith(str(__package__).rsplit('.', 1)[0]):
                purge_duplicate_smart_workspace_view3d_panels()
                _stop_startup_runtime_timers_and_handlers()
                return
        except Exception:
            pass
        _SIDEBAR_RUNTIME_REGISTERED = False
    _purge_stale_nptl_panel_classes()
    # A clean registration has not added any current runtime Panel yet.  The
    # stale-id purge above removes colliding root classes, and the single pass
    # after all runtime classes are registered retires category-only legacy
    # panels.  Scanning every registered Panel here duplicated that final pass.
    try:
        ui_operators.restore_runtime()
    except Exception:
        pass
    _register_runtime_translations_idempotent()
    try:
        from .. import tool_runtime as _tool_runtime
        ensure_ui = getattr(_tool_runtime, 'ensure_ui_runtime', None)
        if callable(ensure_ui):
            ensure_ui()
    except Exception:
        pass
    try:
        ui_operators.prepare_properties_pseudo_tab_panels()
    except Exception:
        pass
    try:
        for c in classes:
            _register_runtime_class_idempotent(c)
        if not _ensure_nptl_settings_pointer():
            raise RuntimeError('RESTART_REQUIRED: NPTL pointer identity mismatch')
    except Exception:
        _rollback_runtime_registration()
        _SIDEBAR_RUNTIME_REGISTERED = False
        _stop_startup_runtime_timers_and_handlers()
        raise
    # The outer package register() performs the only startup restore after
    # all native roots and bundled RNA owners are available.  This lightweight
    # path must not replay a partial graph or write any settings.
    # Zero-idle-load policy: do not scan panels, register optional helpers,
    # apply pins, or write JSON files during add-on enable.
    purge_duplicate_smart_workspace_view3d_panels()
    _stop_startup_runtime_timers_and_handlers()
    _SIDEBAR_RUNTIME_REGISTERED = True


def register():
    global _SIDEBAR_RUNTIME_REGISTERED
    _purge_stale_nptl_panel_classes()
    purge_duplicate_smart_workspace_view3d_panels()
    try:
        ui_operators.restore_runtime()
    except Exception:
        pass

    try:
        bpy.app.translations.register(__name__, translation.translation_dict)
    except ValueError:
        bpy.app.translations.unregister(__name__)
        bpy.app.translations.register(__name__, translation.translation_dict)

    try:
        from .. import tool_runtime as _tool_runtime
        ensure_ui = getattr(_tool_runtime, 'ensure_ui_runtime', None)
        if callable(ensure_ui):
            ensure_ui()
    except Exception:
        pass

    ui_operators.prepare_properties_pseudo_tab_panels()

    try:
        for c in classes:
            _register_runtime_class_idempotent(c)
        if not _ensure_nptl_settings_pointer():
            raise RuntimeError('RESTART_REQUIRED: NPTL pointer identity mismatch')
    except Exception:
        _rollback_runtime_registration()
        _SIDEBAR_RUNTIME_REGISTERED = False
        _stop_startup_runtime_timers_and_handlers()
        raise
    # Canonical startup restore is deferred to the outer package register()
    # after Pan View, Workspace Manager, native roots, and all RNA owners have
    # finished registration.
    purge_duplicate_smart_workspace_view3d_panels()
    # Full runtime registration shares the same visible Sidebar base.
    _SIDEBAR_RUNTIME_REGISTERED = True

    # Register 2D Pan View runtime up front. Registering classes or RNA
    # properties from inside Panel.draw() is unsafe in Blender 5.x and can crash
    # inside panel_draw; Panel drawing now only reads already-registered data.
    try:
        ensure_panview_runtime()
    except Exception:
        pass

    try:
        _wm = _workspace_manager_module()
        if _wm is not None:
            _wm.register()
    except Exception:
        pass

    # Registration is an explicit, finite refresh boundary.  Any Manager JSON
    # validation or private workspace-order discovery happens once here and is
    # never repeated by native panel callbacks.
    try:
        ui_operators.refresh_smart_tools_manager_decision_snapshot(getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        ui_operators.refresh_workspace_ui_order_cache(getattr(bpy, 'context', None))
    except Exception:
        pass

    # Remove only legacy anchor panels from very old sessions before normal UI
    # drawing starts. This does not touch Blender's built-in or third-party
    # panels.
    try:
        core._purge_all_anchors()
    except Exception:
        pass

    try:
        ui_operators.install_properties_pseudo_tab_hack()
    except Exception:
        pass

    # Runtime leases are activated by persistence only after the one canonical
    # startup restore.  Activating them here could consume default RNA before
    # the validated JSON graph has been replayed.

    try:
        _purge_runtime_timer_functions('delayed_startup_apply')
        if not _suite_storage.register_timer_slot(
            'runtime.delayed_startup_apply',
            delayed_startup_apply,
            first_interval=0.10,
            persistent=False,
        ):
            raise RuntimeError('Unable to schedule the finite Sidebar inventory refresh')
    except Exception:
        # Registration itself remains usable if Blender is shutting down before
        # its timer system accepts work; the explicit Refresh operator is still
        # available and performs the same cache invalidation synchronously.
        pass

    # Keep bl_info in English as Blender's translation source. The registered
    # translation table supplies Japanese only when the interface language is Japanese.
    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Workspace launcher suite integrated into the Smart Tools N-panel tab with bundled workspace utilities and floating panel tools."
                break
    except Exception:
        pass



def _remove_addon_keymaps():
    for km, kmi in list(core._addon_keymaps):
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    core._addon_keymaps.clear()


def unregister():
    global _runtime_refresh_generation
    _runtime_refresh_generation += 1

    try:
        from .. import persistence as _suite_persistence
        _suite_persistence.save_all_settings(getattr(bpy, 'context', None), force_central=True)
    except Exception:
        pass

    _clear_runtime_refresh_timers()

    try:
        ui_operators.shutdown_runtime()
    except Exception:
        pass
    try:
        from . import navigation_properties as _navigation_properties
        _navigation_properties.shutdown_runtime()
    except Exception:
        pass

    try:
        core.leave_standard_panel_pins_on_shutdown(getattr(bpy, 'context', None))
    except Exception:
        pass

    _ensure_load_post_handler(False)
    _ensure_live_follow_runtime(False, getattr(bpy, 'context', None))

    try:
        purge_rename = getattr(core, '_purge_stale_rename_timers', None)
        if callable(purge_rename):
            purge_rename()
        elif core._rename_timer and bpy.app.timers.is_registered(core._rename_timer):
            bpy.app.timers.unregister(core._rename_timer)
    except Exception:
        pass

    _remove_addon_keymaps()

    try:
        ui_operators.uninstall_properties_pseudo_tab_hack()
    except Exception:
        pass

    try:
        _wm = _workspace_manager_module()
        if _wm is not None:
            _wm.unregister()
    except Exception:
        pass

    try:
        _panview_module().unregister()
    except Exception:
        pass

    try:
        core._reset_pinned_tabs(bpy.context)
    except Exception:
        pass

    try:
        core._repair_reset(bpy.context)
    except Exception:
        pass

    try:
        import addon_utils
        for mod in addon_utils.modules():
            if mod.__name__ == __name__:
                mod.bl_info["description"] = "Workspace launcher suite integrated into the Smart Tools N-panel tab with bundled workspace utilities and floating panel tools."
                break
    except Exception:
        pass

    for c in reversed(MAIN_RUNTIME_CLASSES):
        if not _runtime_ledger.class_recorded_current(c):
            continue
        _runtime_ledger.unregister_class_exact(
            c,
            native_unregister=bpy.utils.unregister_class,
            reason_prefix='RUNTIME_MAIN_CLASS',
        )

    property_groups_safe = _remove_nptl_settings_pointer()

    if property_groups_safe:
        for c in reversed(MAIN_PROPERTY_GROUP_CLASSES):
            if not _runtime_ledger.class_recorded_current(c):
                continue
            _runtime_ledger.unregister_class_exact(
                c,
                native_unregister=bpy.utils.unregister_class,
                reason_prefix='RUNTIME_PROPERTY_GROUP_CLASS',
            )
    _RUNTIME_REGISTERED_CLASSES.clear()
    _RUNTIME_NEWLY_REGISTERED_CLASSES.clear()
    _RUNTIME_NEW_PROPERTIES.clear()

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


# SUITE_TOOLTIP_AUDIT_WRAPPER_START
_ENABLE_TOOLTIP_AUDIT_ON_REGISTER = False

if _ENABLE_TOOLTIP_AUDIT_ON_REGISTER:
    from . import tooltip_audit as _tooltip_audit

    try:
        _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER = register
        _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER = unregister
    except Exception:
        pass
    else:
        def register():
            _tooltip_audit.begin_runtime_audit()
            try:
                result = _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER()
            except Exception:
                _tooltip_audit.abort_runtime_audit()
                raise
            _tooltip_audit.finish_runtime_audit()
            return result

        def unregister():
            try:
                return _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER()
            finally:
                _tooltip_audit.clear_runtime_audit()
# SUITE_TOOLTIP_AUDIT_WRAPPER_END

if __name__ == "__main__":
    register()
