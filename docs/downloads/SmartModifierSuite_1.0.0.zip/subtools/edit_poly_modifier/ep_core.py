# =============================================================================
# Smart Modifier
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# =============================================================================

import sys 
import types 

import bpy 
import bmesh 
import time 
import uuid 
import re 
import json 
from array import array 
from mathutils import Vector ,Matrix 
iface_ = getattr(getattr(bpy.app, "translations", None), "pgettext_iface", lambda msg: msg)
from .translation import translation_dict as _EP_TRANSLATIONS 

try :
    import numpy as np 
    import gpu 
    from gpu_extras .batch import batch_for_shader 
except ImportError :
    np =None ;gpu =None ;batch_for_shader =None 


    # ------------------------------------------------------------
    # Add-on module name helper (supports modular package layout)
    # ------------------------------------------------------------
def _ep_addon_id ():
    """Return the full module key for legacy standalone identifiers."""

    pkg =(__package__ or "").strip ()
    if pkg :
        return pkg 

        # Fallback for unusual execution contexts.
    name =(__name__ or "").strip ()
    return name .split (".",1 )[0 ]if name else "edit_poly_modifier"

EP_ADDON_ID =_ep_addon_id ()
MODSYS_ROOT_COLLECTION ="Modifier_System_Collection"
MODSYS_EP_COLLECTION ="EditPoly_Collection"
MODSYS_SL_COLLECTION ="SmartLattice_Collection"


def _ep_should_translate_interface ()->bool :
    """Respect Blender's interface translation setting.

    The bundled add-on must follow Blender's current language behavior automatically.
    When interface translation is disabled, do not force dictionary-based Japanese/English
    output from our own fallback table.
    """
    try :
        view =getattr (getattr (bpy .context ,"preferences",None ),"view",None )
        if view is None :
            return True 
        return bool (getattr (view ,"use_translate_interface",True ))
    except Exception :
        return True 


def t (msgid :str )->str :
    """Translate UI strings while respecting Blender's language settings."""
    if not _ep_should_translate_interface ():
        return msgid 

    try :
        translated =iface_ (msgid )
        if translated and translated !=msgid :
            return translated 
    except Exception :
        pass 

    lang =""
    try :
        lang =getattr (bpy .app .translations ,"locale","")or ""
    except Exception :
        lang =""
    if not lang :
        try :
            lang =getattr (getattr (bpy .context .preferences ,"view",None ),"language","")or ""
        except Exception :
            lang =""

    candidates =[]
    if lang :
        candidates .append (lang )
        if lang .startswith ("ja"):
            candidates .append ("ja_JP")
        elif lang .startswith ("en"):
            candidates .append ("en_US")

    for key in candidates :
        table =_EP_TRANSLATIONS .get (key )
        if isinstance (table ,dict ):
            translated =table .get (("*",msgid ))
            if translated :
                return translated 
    return msgid 


def _ep_default_layer_name(context=None) -> str:
    """Default visible stack name for the consolidated editable polygon layer."""
    try:
        name = t("Edit Polygon")
    except Exception:
        name = "Edit Polygon"
    try:
        return str(name or "Edit Polygon")
    except Exception:
        return "Edit Polygon"


# Blender REPLACES bpy.app.driver_namespace on every file load, so
# ``driver_namespace.get("_MS_API_V1") or {}`` returned an empty dict for the
# rest of the session and every Smart Modifier call below became a silent
# no-op.  The re-arm entry point is anchored in a synthetic sys.modules entry by
# runtime._ensure_driver_namespace_api, which survives file loads and the
# live-update submodule purge, so any consumer can heal the namespace on first
# touch instead of waiting for the load_post handler.
_EP_NS_ANCHOR_MODULE_NAME = "jelararagi_smart_modifier_ns_anchor_v1"
_EP_NS_ANCHOR_ATTR = "SMS_NS_VALUES"
_EP_NS_REARM_KEY = "_MS_REARM_NS_API_V1"


def _ep_ns_anchor_store ():
    """Smart Modifier's process-lifetime driver_namespace anchor.  Never raises."""
    try :
        module =sys .modules .get (_EP_NS_ANCHOR_MODULE_NAME )
        if not isinstance (module ,types .ModuleType ):
            module =types .ModuleType (_EP_NS_ANCHOR_MODULE_NAME )
            module .__doc__ =("Smart Modifier Suite driver_namespace anchor.  "
            "Not an importable module.")
            setattr (module ,_EP_NS_ANCHOR_ATTR ,{})
            sys .modules [_EP_NS_ANCHOR_MODULE_NAME ]=module
        store =getattr (module ,_EP_NS_ANCHOR_ATTR ,None )
        if not isinstance (store ,dict ):
            store ={}
            setattr (module ,_EP_NS_ANCHOR_ATTR ,store )
        return store
    except Exception :
        return {}


def _ep_ns_rearm ():
    """Ask the anchored re-arm entry point to republish the API.  Never raises."""
    try :
        fn =_ep_ns_anchor_store ().get (_EP_NS_REARM_KEY )
        if callable (fn ):
            fn ()
            return True
    except Exception :
        pass
    return False


def _ep_ms_api (key ="_MS_API_V1"):
    """Read a Smart Modifier API table, healing a namespace wiped by a file load."""
    try :
        dn =bpy .app .driver_namespace
        value =dn .get (key )
        if value is None :
            _ep_ns_rearm ()
            value =dn .get (key )
        return value if isinstance (value ,dict )else {}
    except Exception :
        return {}


def _ep_ms_plugin_registry (dn ):
    """Return the shared stack-plugin registry, adopting the anchored one.

    Minting an empty dict over a wiped namespace here would strand the 160
    plugins the rest of the suite already registered.
    """
    store =_ep_ns_anchor_store ()
    try :
        reg =dn .get ("_MS_MODIFIER_STACK_PLUGINS_V1")
    except Exception :
        reg =None
    if not isinstance (reg ,dict ):
        anchored =store .get ("_MS_MODIFIER_STACK_PLUGINS_V1")
        reg =anchored if isinstance (anchored ,dict )else {}
        try :
            dn ["_MS_MODIFIER_STACK_PLUGINS_V1"]=reg
        except Exception :
            pass
    store ["_MS_MODIFIER_STACK_PLUGINS_V1"]=reg
    return reg


def _ep_runtime_api ():
    return _ep_ms_api ("_MS_RUNTIME_API_V1")


def _ep_request_live_runtime ():
    # Always-on Edit Poly sync is controlled only from the N-panel
    # 常時起動切り替え.  Tool execution must not turn it on implicitly.
    try :
        api =_ep_runtime_api ()
        enabled =api .get ("edit_poly_live_enabled")
        if callable (enabled )and not bool (enabled ()):return
        sync =api .get ("sync_runtime_services")
        if callable (sync ):sync ()
    except Exception :
        pass 


def _modsys__children_names (col ):
    try :return {c .name for c in col .children }
    except Exception :return set ()

def _modsys_get_or_create_root (scene =None ):
    scn =scene or bpy .context .scene 
    root =bpy .data .collections .get (MODSYS_ROOT_COLLECTION )
    if not root :root =bpy .data .collections .new (MODSYS_ROOT_COLLECTION )
    try :
        if root .name not in {c .name for c in scn .collection .children }:
            scn .collection .children .link (root )
    except Exception :pass 
    return root 

def _modsys_get_or_create_child (child_name ,scene =None ):
    root =_modsys_get_or_create_root (scene =scene )
    child =bpy .data .collections .get (child_name )
    if not child :child =bpy .data .collections .new (child_name )
    try :
        if child .name not in _modsys__children_names (root ):
            root .children .link (child )
    except Exception :pass 
    return child 

def modsys_get_ep_collection (scene =None ):
    return _modsys_get_or_create_child (MODSYS_EP_COLLECTION ,scene =scene )

def ep_iter_helpers_for_main (main_obj_name =None ):
    out =[]
    try :
        col =bpy .data .collections .get (MODSYS_EP_COLLECTION )
        if col :
            for ob in list (getattr (col ,"objects",[])):
                try :
                    if not ob :continue 
                    if "ep_main_target"not in ob :continue 
                    if main_obj_name and ob .get ("ep_main_target")!=main_obj_name :continue 
                    out .append (ob )
                except Exception :continue 
            return out 
    except Exception :pass 

    try :
        for ob in bpy .data .objects :
            try :
                if not ob :continue 
                if "ep_main_target"not in ob :continue 
                if main_obj_name and ob .get ("ep_main_target")!=main_obj_name :continue 
                out .append (ob )
            except Exception :continue 
    except Exception :pass 
    return out 

def modsys_link_object (obj ,target_col ):
    if not obj or not target_col :return 
    try :
        if target_col not in obj .users_collection :target_col .objects .link (obj )
    except Exception :pass 
    try :
        for c in list (getattr (obj ,"users_collection",[])):
            if c !=target_col :
                try :c .objects .unlink (obj )
                except Exception :pass 
    except Exception :pass 

def _modsys_unlink_object_from_collection (obj ,col =None ):
    if not obj :return 
    # Edit Polygon helper objects are referenced by Geometry Nodes Object Info nodes.
    # They must remain linked to an enabled scene collection even when hidden; otherwise
    # the modifier evaluates against stale/base geometry and topology edits can appear
    # collapsed or disappear after switching stack levels.
    try :
        if obj .get ('ep_main_target',None )is not None :
            try :obj .select_set (False )
            except Exception :pass 
            try :_ep_set_obj_hidden (obj ,True ,True )
            except Exception :pass 
            return 
    except Exception :pass 
    try :
        targets =[]
        if col :targets =[col ]
        else :targets =list (getattr (obj ,"users_collection",[])or [])
        for c in list (targets ):
            try :c .objects .unlink (obj )
            except Exception :pass 
    except Exception :pass 

def _ep_active_edit_helper_keep_names (context =None ):
    """Return EP helper object names that must stay linked right now.

    EditPoly helper objects are kept as datablocks because Geometry Nodes object
    references need them, but the visible system collection should exist only
    while an EditPoly helper is actually being edited or a deterministic
    EditPoly-enter transition is in progress.
    """
    keep =set ()
    ctx =context or bpy .context 
    try :mode =str (getattr (ctx ,'mode','')or '')
    except Exception :mode =''
    if mode =='EDIT_MESH':
        objs =[]
        try :objs =list (getattr (ctx ,'objects_in_mode',None )or [])
        except Exception :objs =[]
        if not objs :
            try :
                eo =getattr (ctx ,'edit_object',None )
                if eo :objs =[eo ]
            except Exception :objs =[]
        for eo in objs :
            try :
                if not eo or getattr (eo ,'type','')!='MESH':continue 
                main_name =str (eo .get ('ep_main_target','')or '')
                if not main_name :continue 
                keep .add (eo .name )
                main_obj =bpy .data .objects .get (main_name )
                if main_obj :
                    for m in list (getattr (main_obj ,'modifiers',[])or []):
                        try :
                            if not is_ep_layer (m ):continue 
                            en ,fn =get_ep_mesh_names (m )
                            if en ==eo .name and fn :keep .add (fn )
                        except Exception :continue 
            except Exception :continue 
    try :
        dn =bpy .app .driver_namespace 
        req =dn .get ('_MS_LEVEL_SWITCH_STATE_V1')or dn .get ('_MS_LEVEL_SWITCH_REQ_V1')
        if isinstance (req ,dict )and bool (req .get ('want_edit',False )):
            main_obj =bpy .data .objects .get (str (req .get ('main','')or ''))
            clicked =str (req .get ('clicked','')or '')
            if main_obj :
                # During a deterministic edit-enter transition the clicked row can be
                # a standard modifier whose editable carrier is an EditPoly layer.
                # Keep all EP helpers for that main linked until the transition
                # settles; the next cleanup pass will reduce it to the actual edit target.
                for mod in list (getattr (main_obj ,'modifiers',[])or []):
                    try :
                        if not is_ep_layer (mod ):continue 
                        en ,fn =get_ep_mesh_names (mod )
                        if en :keep .add (en )
                        if fn :keep .add (fn )
                    except Exception :continue 
    except Exception :pass 
    return keep 

def _ep_is_force_edit_target_requested (main_obj ,mod_name =None )->bool :
    try :
        if not main_obj :return False 
        dn =bpy .app .driver_namespace 
        now =time .time ()
        for key in ('_MS_LEVEL_SWITCH_STATE_V1','_MS_LEVEL_SWITCH_REQ_V1'):
            req =dn .get (key )
            if not isinstance (req ,dict ):continue 
            if str (req .get ('main','')or '')!=main_obj .name :continue 
            if not bool (req .get ('want_edit',False )):continue 
            clicked =str (req .get ('clicked','')or '')
            if mod_name and clicked !=str (mod_name ):continue 
            if clicked and clicked !='BASE':
                m =main_obj .modifiers .get (clicked )
                if m and is_ep_layer (m ):return True 
        req =dn .get ('_EP_FORCE_EDIT_TARGET_V1')
        if isinstance (req ,dict ):
            if float (req .get ('until',0.0 )or 0.0 )>=now and str (req .get ('main','')or '')==main_obj .name :
                if (not mod_name )or str (req .get ('mod','')or '')==str (mod_name ):return True 
    except Exception :pass 
    return False 

def _ep_link_layer_helpers_for_edit (main_obj ,mod ,context =None ):
    if not main_obj or not mod or not is_ep_layer (mod ):return (None ,None )
    en ,fn =get_ep_mesh_names (mod )
    e_obj =bpy .data .objects .get (en )if en else None 
    f_obj =bpy .data .objects .get (fn )if fn else None 
    try :
        ep_col =modsys_get_ep_collection (scene =(getattr (context ,'scene',None )if context else bpy .context .scene ))
    except Exception :
        ep_col =None 
    try :
        if ep_col and e_obj :modsys_link_object (e_obj ,ep_col )
        if ep_col and f_obj :modsys_link_object (f_obj ,ep_col )
    except Exception :pass 
    return e_obj ,f_obj 

def _ep_unlink_inactive_helpers_from_collection (context =None ):
    keep =_ep_active_edit_helper_keep_names (context )
    try :col =bpy .data .collections .get (MODSYS_EP_COLLECTION )
    except Exception :col =None 
    if not col :return 
    try :objects =list (getattr (col ,'objects',[])or [])
    except Exception :objects =[]
    for ob in objects :
        try :
            if not ob :continue 
            if ob .name in keep :continue 
            if ob .get ('ep_main_target',None )is None :continue 
            try :ob .select_set (False )
            except Exception :pass 
            try :_ep_set_obj_hidden (ob ,True ,True )
            except Exception :pass 
            _modsys_unlink_object_from_collection (ob ,col )
        except Exception :continue 

def _modsys_is_empty_collection (col ):
    try :return (len (col .objects )==0 )and (len (col .children )==0 )
    except Exception :return False 

def _modsys_cleanup_now ():
    dn =bpy .app .driver_namespace 
    if dn .get ("_MODSYS_CLEANUP_LOCK"):return None 
    dn ["_MODSYS_CLEANUP_LOCK"]=True 
    try :
        try :_ep_unlink_inactive_helpers_from_collection (bpy .context )
        except Exception :pass 
        for child_name in (MODSYS_EP_COLLECTION ,MODSYS_SL_COLLECTION ):
            col =bpy .data .collections .get (child_name )
            if col and _modsys_is_empty_collection (col ):
                try :
                    for parent in list (getattr (col ,"users_collection",[])):
                        try :parent .children .unlink (col )
                        except Exception :pass 
                    bpy .data .collections .remove (col )
                except Exception :pass 
        legacy =bpy .data .collections .get ("EditPoly_System_Collection")
        if legacy and _modsys_is_empty_collection (legacy ):
            try :
                for parent in list (getattr (legacy ,"users_collection",[])):
                    try :parent .children .unlink (legacy )
                    except Exception :pass 
                bpy .data .collections .remove (legacy )
            except Exception :pass 
        root =bpy .data .collections .get (MODSYS_ROOT_COLLECTION )
        if root and _modsys_is_empty_collection (root ):
            try :
                for scn in bpy .data .scenes :
                    try :
                        if root .name in {c .name for c in scn .collection .children }:
                            scn .collection .children .unlink (root )
                    except Exception :pass 
                bpy .data .collections .remove (root )
            except Exception :pass 
    finally :
        dn ["_MODSYS_CLEANUP_LOCK"]=False 
    return None 

def _modsys_cleanup_timer ():
    bpy .app .driver_namespace ["_MODSYS_CLEANUP_PENDING"]=False 
    return _modsys_cleanup_now ()

def modsys_request_cleanup (delay =0.2 ):
    dn =bpy .app .driver_namespace 
    if dn .get ("_MODSYS_CLEANUP_PENDING"):return 
    dn ["_MODSYS_CLEANUP_PENDING"]=True 
    try :bpy .app .timers .register (_modsys_cleanup_timer ,first_interval =max (0.0 ,float (delay )))
    except Exception :pass 

EP_NG_VERSION =11 
_EP_LAST_EDIT_HELPER_DN_KEY ="_EP_LAST_EDIT_HELPER_NAME_V2"
_EP_TOPO_SIG_CACHE_DN_KEY ="_EP_TOPO_SIG_CACHE_V2"

def _ms__get_dn_dict (name ):
    try :ns =bpy .app .driver_namespace 
    except :return {}
    d =ns .get (name )
    if d is None :
        d ={};ns [name ]=d 
    return d 

def ms_sel_cache (main_obj ):
    if not main_obj :return {}
    root =_ms__get_dn_dict ("_MS_SEL_CACHE")
    key =main_obj .name 
    d =root .get (key )
    if d is None :
        d ={};root [key ]=d 
    return d 

def ms_sel_set (main_obj ,layer_key ,sel ):
    if not main_obj or not layer_key or not sel :return 
    cache =ms_sel_cache (main_obj )
    cache [layer_key ]={
    "v":list (sel .get ("v",[])or []),
    "e":list (sel .get ("e",[])or []),
    "f":list (sel .get ("f",[])or []),
    }

def ms_sel_get (main_obj ,layer_key ):
    if not main_obj or not layer_key :return None 
    return ms_sel_cache (main_obj ).get (layer_key )

_EP_MS_INSTANCE_KEY ="ms_instance_id"
_EP_MS_INST_MAP_KEY ="ms_instance_map"
_EP_NAME_SUFFIX_RE =re .compile (r"^(.*?)(?:\.(\d{3}))?$")

def _ep_ms_mapping_like (value ):
    try :return value is not None and callable (getattr (value ,"keys",None ))and callable (getattr (value ,"get",None ))
    except Exception :return False 

def ms_modifier_type_display_name (mod_type :str )->str :
    try :
        label =bpy .types .Modifier .bl_rna .properties ["type"].enum_items [mod_type ].name 
        return t (label )
    except Exception :return mod_type or ""

def _ep_unique_modifier_name_for_object (obj ,desired_name :str )->str :
    if not obj or not desired_name :return _ep_default_layer_name()
    try :desired_name =str (desired_name )
    except :desired_name =_ep_default_layer_name()
    try :
        if obj .modifiers .get (desired_name )is None :return desired_name 
    except :return desired_name 

    m =_EP_NAME_SUFFIX_RE .match (desired_name )
    base =(m .group (1 )or desired_name ).strip ()if m else desired_name 
    start_i =1 
    try :
        if m and m .group (2 ):start_i =int (m .group (2 ))+1 
    except :pass 
    if not base :base =desired_name 

    i =max (1 ,start_i )
    while True :
        cand =f"{base }.{i :03d}"
        try :
            if obj .modifiers .get (cand )is None :return cand 
        except :return cand 
        i +=1 

def _ep_next_shared_modifier_name (objects ,base_name =None)->str :
    base_name = str(base_name or _ep_default_layer_name() or "Edit Polygon")
    used =set ()
    try :
        for o in objects or []:
            if not o :continue 
            for m in getattr (o ,"modifiers",[]):
                try :used .add (m .name )
                except :pass 
    except :pass 
    if base_name not in used :return base_name 
    i =1 
    while True :
        cand =f"{base_name }.{i :03d}"
        if cand not in used :return cand 
        i +=1 

def _ep_suffix_from_mod_name (mod_name :str )->str :
    m =_EP_NAME_SUFFIX_RE .match (mod_name or "")
    if not m :return "000"
    suf =m .group (2 )
    return suf if suf else "000"

def _ep_get_instance_id (mod ,obj =None )->str :
    if not mod :return ""
    try :
        if hasattr (mod ,"keys"):
            keys =mod .keys ()
            if _EP_MS_INSTANCE_KEY in keys :
                return str (mod [_EP_MS_INSTANCE_KEY ])
    except Exception :pass 
    if obj :
        try :
            items =getattr (obj ,"ms_instance_map_items",None )
            if items is not None :
                for it in items :
                    if str (getattr (it ,"mod_name","")or "")==mod .name :
                        iid =str (getattr (it ,"instance_id","")or "")
                        if iid :return iid 
        except Exception :pass 
        try :
            m =obj .get (_EP_MS_INST_MAP_KEY )
            if _ep_ms_mapping_like (m ):
                v =m .get (mod .name )
                if v :return str (v )
        except Exception :pass 
    return ""

def _ep_set_instance_id (obj ,mod_name :str ,instance_id :str ,disp_name :str |None =None ):
    if not obj or not mod_name or not instance_id :return 
    iid =str (instance_id )
    try :
        mod =obj .modifiers .get (mod_name )
        if mod and hasattr (mod ,"keys"):
            mod [_EP_MS_INSTANCE_KEY ]=iid 
    except Exception :pass 
    try :
        items =getattr (obj ,"ms_instance_map_items",None )
        if items is not None :
            found =next ((it for it in items if str (getattr (it ,"mod_name",""))==mod_name ),None )
            if found is None :
                found =items .add ()
                found .mod_name =mod_name 
            if found is not None :
                found .instance_id =iid 
                if disp_name is not None and hasattr (found ,"disp_name"):
                    found .disp_name =str (disp_name )
    except Exception :pass 
    try :
        m =obj .get (_EP_MS_INST_MAP_KEY )
        if not _ep_ms_mapping_like (m ):
            try :
                if _EP_MS_INST_MAP_KEY in obj .keys ():del obj [_EP_MS_INST_MAP_KEY ]
            except Exception :pass 
            obj [_EP_MS_INST_MAP_KEY ]={}
            m =obj .get (_EP_MS_INST_MAP_KEY )
        if _ep_ms_mapping_like (m ):m [mod_name ]=iid 
    except Exception :pass 

def is_ep_layer (mod ):
    if not mod :return False 
    en ,fn =get_ep_mesh_names (mod )
    return bool (en and fn )

def _ep_find_nearest_ep_key_before_index (main_obj ,insert_index :int )->str :
    if not main_obj :return "BASE"
    try :mods =list (getattr (main_obj ,"modifiers",[])or [])
    except Exception :mods =[]
    cut =int (insert_index )if insert_index is not None else 0 
    cut =max (0 ,min (cut ,len (mods )))
    for i in range (cut -1 ,-1 ,-1 ):
        try :
            m =mods [i ]
            if is_ep_layer (m ):return m .name 
        except Exception :continue 
    return "BASE"

def _ep_pick_inherit_selection_key (main_obj )->str :
    if not main_obj :return "BASE"
    active_id ="BASE"
    try :active_id =str (main_obj .get ("ui_active_item","BASE")or "BASE")
    except Exception :active_id ="BASE"
    try :
        if active_id !="BASE"and main_obj .modifiers .get (active_id )is None :active_id ="BASE"
    except Exception :active_id ="BASE"
    if active_id =="BASE":return "BASE"
    try :
        am =main_obj .modifiers .get (active_id )
        if am and is_ep_layer (am ):return am .name 
    except Exception :pass 
    try :idx =main_obj .modifiers .find (active_id )
    except Exception :idx =-1 
    if idx <0 :return "BASE"
    try :
        for j in range (idx -1 ,-1 ,-1 ):
            mm =main_obj .modifiers [j ]
            if is_ep_layer (mm ):return mm .name 
    except Exception :pass 
    return "BASE"

def _ep_iter_instance_members (instance_id :str ):
    iid =str (instance_id or "")
    if not iid :return 
    for o in list (getattr (bpy .data ,"objects",[])):
        if not o or getattr (o ,"type","")!='MESH':continue 
        try :
            for m in getattr (o ,"modifiers",[]):
                if is_ep_layer (m )and _ep_get_instance_id (m ,o )==iid :
                    yield (o ,m )
        except Exception :continue 

def _ep_unique_node_group_name (obj ,mod_name :str )->str :
    base =f"GN_{obj .name }_{mod_name }"
    name =base 
    i =1 
    while name in bpy .data .node_groups :
        name =f"{base }_{i :03d}"
        i +=1 
    return name 

def _ep_get_selected_main_meshes (context ):
    objs =[]
    try :sel =list (getattr (context ,"selected_objects",[])or [])
    except :sel =[]
    try :
        ao =getattr (context ,"active_object",None )
        if ao and ao not in sel :sel .append (ao )
    except :pass 
    seen =set ()
    for o in sel :
        mo =get_main_object (o )
        if not mo or getattr (mo ,"type","")!='MESH':continue 
        if mo .name in seen :continue 
        seen .add (mo .name )
        objs .append (mo )
    return objs 

def _ep_calc_insert_index_bottom (main_obj ,target_obj =None ,context =None ):
    """Compatibility wrapper: insert directly below the active Smart Modifier row."""
    if not main_obj :return 0 
    if target_obj is None :target_obj =main_obj 
    try :
        api =_ep_ms_api ()
        fn =api .get ("calc_target_insert_index")
        if callable (fn ):
            return int (fn (main_obj ,target_obj ,context ))
    except Exception :pass 
    try :
        active_id =main_obj .get ("ui_active_item","BASE")
        if active_id =="BASE":return 0 
        aidx =target_obj .modifiers .find (active_id )
        if aidx >=0 :return min (len (target_obj .modifiers ),aidx +1 )
    except Exception :pass 
    try :return len (target_obj .modifiers )
    except Exception :return 0 

_EP_MAIN_DISP_KEY ="_EP_MAIN_PREV_DISPLAY_TYPE_V1"
_EP_PREVIEW_DISP_KEY ="_EP_PREVIEW_PREV_DISPLAY_TYPE_V1"
_EP_TOUCHED_MAINS_KEY ="_EP_TOUCHED_MAINS_V1"
_EP_TOUCHED_RESTORE_PENDING_KEY ="_EP_TOUCHED_RESTORE_PENDING_V1"
_EP_TOUCHED_RESTORE_REASON_KEY ="_EP_TOUCHED_RESTORE_REASON_V1"

def _ep_get_ms_preview_obj (main_obj ):
    """Get Smart Modifier end-result preview object for the given main object.

    Primary: main_obj['_MS_END_PREVIEW_OBJ_V1'] -> object name.
    Fallback: scan objects for obj['ms_end_preview_main'] == main_obj.name and cache back to main_obj.
    This function is used ONLY for locking/deselecting the preview safely (to keep MS UI stable).
    """
    if not main_obj :
        return None 

        # Fast path: cached name on main
    try :
        name =str (main_obj .get ('_MS_END_PREVIEW_OBJ_V1','')or '')
        if name :
            pobj =bpy .data .objects .get (name )
            if pobj :
                try :
                    _ep_ensure_ms_preview_obj (main_obj ,pobj )
                except Exception :
                    pass 
                return pobj 
    except Exception :
        pass 

        # Fallback: find by reverse link property (rare; keep it light and cache once)
    try :
        main_name =getattr (main_obj ,"name",None )
        if not main_name :
            return None 
        best =None 
        for o in bpy .data .objects :
            try :
                if o .get ("ms_end_preview_main")!=main_name :
                    continue 
                    # Prefer the canonical naming if present
                if getattr (o ,"name","").endswith ("_EndPreview")or getattr (o ,"name","").endswith ("_MS_EndPreview"):
                    best =o 
                    break 
                if best is None :
                    best =o 
            except Exception :
                continue 
        if best :
            try :
                main_obj ['_MS_END_PREVIEW_OBJ_V1']=best .name 
            except Exception :
                pass 
            try :
                _ep_ensure_ms_preview_obj (main_obj ,best )
            except Exception :
                pass 
            return best 
    except Exception :
        pass 

    return None 


def _ep_ensure_ms_preview_obj (main_obj ,pobj ):
    """Ensure MS preview object uses the requested naming.
    NOTE: Collection placement is managed by Smart Modifier (general feature)."""
    if not main_obj or not pobj :
        return 
        # Rename legacy '<Main>_MS_EndPreview' -> '<Main>_EndPreview' and update main's reference key
    try :
        if str (pobj .name ).endswith ("_MS_EndPreview"):
            new_name =f"{main_obj .name }_EndPreview"
            if bpy .data .objects .get (new_name )is None :
                try :
                    pobj .name =new_name 
                except Exception :
                    pass 
            try :
                main_obj ["_MS_END_PREVIEW_OBJ_V1"]=new_name 
            except Exception :
                pass 
    except Exception :
        pass 


def _ep_set_preview_display (pobj ,display_type :str ):
    if not pobj :return 
    try :
        if _EP_PREVIEW_DISP_KEY not in pobj :
            pobj [_EP_PREVIEW_DISP_KEY ]=getattr (pobj ,'display_type','SOLID')
    except Exception :pass 
    try :pobj .display_type =str (display_type )
    except Exception :pass 

def _ep_restore_preview_display (pobj ):
    if not pobj :return 
    prev =None 
    try :prev =pobj .get (_EP_PREVIEW_DISP_KEY )
    except Exception :prev =None 
    if prev :
        try :pobj .display_type =prev 
        except Exception :pass 
        try :del pobj [_EP_PREVIEW_DISP_KEY ]
        except Exception :pass 

def _ep_hide_main_object_mesh (main_obj ,show_end =False ):
    if not main_obj :return 
    try :
        if _EP_MAIN_DISP_KEY not in main_obj :
            main_obj [_EP_MAIN_DISP_KEY ]=getattr (main_obj ,'display_type','TEXTURED')
    except Exception :pass 
    try :main_obj .display_type ='WIRE'if bool (show_end )else 'BOUNDS'
    except Exception :pass 
    try :
        pobj =_ep_get_ms_preview_obj (main_obj )
        if pobj :
            _ep_set_preview_display (pobj ,'WIRE')
            try :
                pobj .hide_select =True 
                pobj .hide_render =True 
                pobj .show_in_front =False 
            except Exception :pass 
    except Exception :pass 

    # Track this main so we can reliably restore its display in OBJECT mode (prevents sticky WIRE/BOUNDS).
    try :
        _ep_mark_touched_main (main_obj )
    except Exception :
        pass 

def _ep_restore_main_object_mesh (main_obj ):
    if not main_obj :return 
    prev =None 
    try :prev =main_obj .get (_EP_MAIN_DISP_KEY )
    except Exception :prev =None 
    if prev :
        try :main_obj .display_type =prev 
        except Exception :pass 
        try :del main_obj [_EP_MAIN_DISP_KEY ]
        except Exception :pass 
    try :
        pobj =_ep_get_ms_preview_obj (main_obj )
        if pobj :_ep_restore_preview_display (pobj )
    except Exception :pass 

def _ep_force_deselect_all (context ):
    """Deselect only currently selected objects (NO bpy.ops) for stability & speed."""
    if not context :
        return 
    vl =getattr (context ,"view_layer",None )
    if not vl :
        return 
    try :
        cur_sel =list (getattr (context ,"selected_objects",[])or [])
    except Exception :
        cur_sel =[]
        # Fallback: if selected_objects is unreliable, check active.
    try :
        ao =vl .objects .active 
        if ao and ao not in cur_sel :
            cur_sel .append (ao )
    except Exception :
        pass 

    for o in cur_sel :
        try :
            if not o :
                continue 
                # Helper objects may be hide_select; temporarily lift it to deselect safely.
            was_hide_select =bool (getattr (o ,"hide_select",False ))
            is_ep_helper =bool (getattr (o ,"get",None )and o .get ("ep_main_target"))
            if was_hide_select and is_ep_helper :
                try :
                    o .hide_select =False 
                except Exception :
                    pass 
            try :
                o .select_set (False )
            except Exception :
                pass 
            if was_hide_select and is_ep_helper :
                try :
                    o .hide_select =True 
                except Exception :
                    pass 
        except Exception :
            pass 


            # ---------------------------------------------------------------------------
            # Object-selection snapshot & guard (EditPoly-specific).
            # Fixes: selection becomes empty / single on helper switching (EditMesh <-> Object),
            # and prevents "main + GN preview both visible + nothing selected" state.
            #
            # Blender algorithm notes:
            # - depsgraph_update_post runs during evaluation; do NOT call bpy.ops from it.
            # - mode/visibility/active object can change within one UI tick; schedule restore
            #   via bpy.app.timers so it runs after Blender finishes the current operator.
            # ---------------------------------------------------------------------------

_EP_OBJSEL_NAMES_KEY ="_EP_OBJSEL_NAMES_V1"
_EP_OBJSEL_ACTIVE_KEY ="_EP_OBJSEL_ACTIVE_V1"
_EP_OBJSEL_TS_KEY ="_EP_OBJSEL_TS_V1"
_EP_OBJSEL_PIN_KEY ="_EP_OBJSEL_PIN_V1"
_EP_OBJSEL_PENDING_KEY ="_EP_OBJSEL_PENDING_V1"
_EP_OBJSEL_LOCK_KEY ="_EP_OBJSEL_LOCK_V1"
_EP_OBJSEL_TRIES_KEY ="_EP_OBJSEL_TRIES_V1"
_EP_OBJSEL_REASON_KEY ="_EP_OBJSEL_REASON_V1"
_EP_OBJSEL_STATE_KEY ="_EP_OBJSEL_STATE_V1"
_EP_LAST_MODE_KEY ="_EP_LAST_MODE_V1"
_EP_LAST_HELPER_ACTIVE_KEY ="_EP_LAST_HELPER_ACTIVE_V1"

def _ep_dn ():
    try :
        return bpy .app .driver_namespace 
    except Exception :
        return {}

def _ep_obj_hide_get (obj ):
    try :
        return bool (obj .hide_get ())
    except Exception :
        try :
            return bool (getattr (obj ,"hide_viewport",False ))
        except Exception :
            return False 

def _ep_set_obj_hidden (obj ,hide :bool ,hide_select :bool =None ):
    """Fast hide setter: avoid redundant hide_set/property writes.

    Edit Polygon helper objects are Geometry Nodes Object Info inputs.  They may
    be hidden from the user's viewport with hide_set(), but hide_viewport must
    stay False so Blender continues to evaluate their mesh datablocks for the
    modifier stack.
    """
    if not obj :
        return 
    try :
        keep_eval =bool (obj .get ('ep_main_target',None )is not None )
    except Exception :
        keep_eval =False 
    try :
        is_helper_like =bool (obj .get ('ep_main_target',None )is not None or obj .get ('ms_end_preview_main',None )is not None)
    except Exception :
        is_helper_like =False
    try :
        if is_helper_like and hasattr (obj ,"hide_viewport"):
            # Keep helper datablocks evaluatable and avoid toggling the Outliner
            # viewport-disable flag on user edit targets.
            want_hv =False
            cur =bool (obj .hide_viewport )
            if cur !=want_hv :
                obj .hide_viewport =want_hv 
    except Exception :
        pass 
    try :
        cur_h =_ep_obj_hide_get (obj )
        if cur_h !=bool (hide ):
            try :
                obj .hide_set (bool (hide ))
            except Exception :
                pass 
    except Exception :
        pass 
    if hide_select is not None and is_helper_like :
        try :
            if hasattr (obj ,"hide_select"):
                cur =bool (obj .hide_select )
                if cur !=bool (hide_select ):
                    obj .hide_select =bool (hide_select )
        except Exception :
            pass 



def _ep_obj_state_pack (o ):
    """Pack minimal viewport/selection state for recovery (lightweight & JSON-safe)."""
    st ={}
    try :
        st ["hide_viewport"]=bool (getattr (o ,"hide_viewport",False ))
    except Exception :
        st ["hide_viewport"]=False 
    try :
        st ["hide_select"]=bool (getattr (o ,"hide_select",False ))
    except Exception :
        st ["hide_select"]=False 
    try :
        st ["hide_get"]=bool (o .hide_get ())
    except Exception :
        st ["hide_get"]=st .get ("hide_viewport",False )
    return st 

def _ep_objsel_capture (context =None ,*,force :bool =False ,pin :bool =False ,reason :str =""):
    ctx =context or bpy .context 
    try :
        vl =ctx .view_layer 
    except Exception :
        return 
    try :
        dn =_ep_dn ()
        if (not force )and bool (dn .get (_EP_OBJSEL_PIN_KEY )):
            return 
    except Exception :
        dn =_ep_dn ()

        # If we're already in a pinned EP edit-session, NEVER overwrite the pinned main selection
        # while Blender is in a non-OBJECT mode (helpers may be the only selected objects).
        # Overwriting here is the main cause of:
        #  - multi-selection collapsing to single on return
        #  - restoring hide_select/hide_viewport from a post-switch state (main becomes unselectable/hidden)
    try :
        already_pinned =bool (dn .get (_EP_OBJSEL_PIN_KEY ))
    except Exception :
        already_pinned =False 
    try :
        cur_mode =getattr (ctx ,"mode","OBJECT")
    except Exception :
        cur_mode ="OBJECT"

    if already_pinned and cur_mode !='OBJECT':
        try :
            prev_names =dn .get (_EP_OBJSEL_NAMES_KEY )or []
            if isinstance (prev_names ,(list ,tuple ))and prev_names :
            # Update active name only (keep names/state)
                try :
                    ao =vl .objects .active 
                    amo =get_main_object (ao )if ao else None 
                    dn [_EP_OBJSEL_ACTIVE_KEY ]=(amo .name if amo else (ao .name if ao else str (prev_names [0 ])))
                except Exception :
                    pass 
                try :
                    dn [_EP_OBJSEL_TS_KEY ]=time .time ()
                except Exception :
                    pass 
                if pin :
                    try :
                        dn [_EP_OBJSEL_PIN_KEY ]=True 
                    except Exception :
                        pass 
                if reason :
                    try :
                        dn [_EP_OBJSEL_REASON_KEY ]=str (reason )
                    except Exception :
                        pass 
                return 
        except Exception :
            pass 

    try :
        sel =list (getattr (ctx ,"selected_objects",[])or [])
    except Exception :
        sel =[]
    try :
        ao =vl .objects .active 
        if ao and ao not in sel :
            sel .append (ao )
    except Exception :
        pass 

    names =[]
    for o in sel :
        try :
            if not o :
                continue 
            mo =get_main_object (o )or o 
            if mo and getattr (mo ,"name",None )and mo .name not in names :
                names .append (mo .name )
        except Exception :
            continue 

    if not names :
        return 

    try :
        dn [_EP_OBJSEL_NAMES_KEY ]=names 
        try :
            amo =get_main_object (vl .objects .active )if vl .objects .active else None 
            dn [_EP_OBJSEL_ACTIVE_KEY ]=(amo .name if amo else (vl .objects .active .name if vl .objects .active else names [0 ]))
        except Exception :
            dn [_EP_OBJSEL_ACTIVE_KEY ]=names [0 ]
        dn [_EP_OBJSEL_TS_KEY ]=time .time ()


        # Capture per-object viewport/select state for reliable restore (prevents stuck hidden/locked objects).
        try :
            st ={"mains":{},"helpers":{}}
            for n in names :
                o =bpy .data .objects .get (n )
                if o :
                    st ["mains"][n ]=_ep_obj_state_pack (o )
                try :
                    for h in ep_iter_helpers_for_main (n ):
                        if h :
                            st ["helpers"][h .name ]=_ep_obj_state_pack (h )
                except Exception :
                    pass 
            dn [_EP_OBJSEL_STATE_KEY ]=st 
        except Exception :
            pass 

        if pin :
            dn [_EP_OBJSEL_PIN_KEY ]=True 
        if reason :
            dn [_EP_OBJSEL_REASON_KEY ]=str (reason )
    except Exception :
        pass 


def _ep_objsel_capture_names_only (context =None ,*,pin :bool =False ,reason :str =""):
    """Capture ONLY selected main object names & active main name.
    Does NOT overwrite the per-object state map. This is used for mode-transition detection
    where the selection may already be helper-only and main objects may be temporarily hidden/locked.
    """
    ctx =context or bpy .context 
    try :
        vl =ctx .view_layer 
    except Exception :
        return 
    dn =_ep_dn ()
    try :
        sel =list (getattr (ctx ,"selected_objects",[])or [])
    except Exception :
        sel =[]
    try :
        ao =vl .objects .active 
        if ao and ao not in sel :
            sel .append (ao )
    except Exception :
        pass 

    names =[]
    for o in sel :
        try :
            if not o :
                continue 
            mo =get_main_object (o )or o 
            if mo and getattr (mo ,"name",None )and mo .name not in names :
                names .append (mo .name )
        except Exception :
            continue 

    if not names :
        return 

    try :
        dn [_EP_OBJSEL_NAMES_KEY ]=names 
        try :
            amo =get_main_object (vl .objects .active )if vl .objects .active else None 
            dn [_EP_OBJSEL_ACTIVE_KEY ]=(amo .name if amo else (vl .objects .active .name if vl .objects .active else names [0 ]))
        except Exception :
            dn [_EP_OBJSEL_ACTIVE_KEY ]=names [0 ]
        dn [_EP_OBJSEL_TS_KEY ]=time .time ()
        if pin :
            dn [_EP_OBJSEL_PIN_KEY ]=True 
        if reason :
            dn [_EP_OBJSEL_REASON_KEY ]=str (reason )
    except Exception :
        pass 

def _ep_objsel_snapshot ():
    dn =_ep_dn ()
    names =dn .get (_EP_OBJSEL_NAMES_KEY )or []
    active =dn .get (_EP_OBJSEL_ACTIVE_KEY )or ""
    if not isinstance (names ,(list ,tuple )):
        names =[]
    return [str (n )for n in names if n ],str (active )

def _ep_objsel_schedule_restore (*,delay :float =0.0 ,reason :str ="",force :bool =False ):
    dn =_ep_dn ()
    # Always keep the latest reason (debug aid)
    if reason :
        try :
            dn [_EP_OBJSEL_REASON_KEY ]=str (reason )
        except Exception :
            pass 
            # Debounce
    if dn .get (_EP_OBJSEL_PENDING_KEY ):
        return 
    dn [_EP_OBJSEL_PENDING_KEY ]=True 
    # Reset tries if force requested
    if force :
        dn [_EP_OBJSEL_TRIES_KEY ]=0 
    try :
        bpy .app .timers .register (_ep_objsel_restore_timer ,first_interval =float (delay or 0.0 ))
    except Exception :
        dn [_EP_OBJSEL_PENDING_KEY ]=False 


def _ep_is_helper_obj (o ):
    """Return True if object is an EP helper or MS end-preview object."""
    if not o :
        return False 
    try :
        if getattr (o ,"get",None ):
            if o .get ("ep_main_target"):
                return True 
            if o .get ("ms_end_preview_main"):
                return True 
    except Exception :
        pass 
    try :
        n =getattr (o ,"name","")or ""
        if n .endswith ("_MS_EndPreview"):
            return True 
    except Exception :
        pass 
    return False 


def _ep_safe_deselect (o ):
    """Deselect object even if hide_select is True (no bpy.ops)."""
    if not o :
        return 
    was_hs =False 
    try :
        was_hs =bool (getattr (o ,"hide_select",False ))
    except Exception :
        was_hs =False 
    if was_hs :
        try :
            o .hide_select =False 
        except Exception :
            pass 
    try :
        o .select_set (False )
    except Exception :
        pass 
    if was_hs :
        try :
            o .hide_select =True 
        except Exception :
            pass 


def _ep_is_ep_edit_active (main_obj ):
    """Return True if the main object is currently in an EditPoly editing session (active layer is EP & enabled)."""
    if not main_obj :
        return False 
    try :
        active_id =str (main_obj .get ("ui_active_item")or "BASE")
    except Exception :
        active_id ="BASE"
    if (not active_id )or (active_id =="BASE"):
        return False 
    try :
        am =main_obj .modifiers .get (active_id )
    except Exception :
        am =None 
    if not am or (not is_ep_layer (am )):
        return False 
    try :
        return bool (_ms_mod_is_enabled (main_obj ,am ))
    except Exception :
        return True 


def _ep_ensure_ep_targets_visible_for_main (main_obj ):
    """During transient OBJECT-mode windows while EP is active, ensure at least the EP edit target remains visible/selectable."""
    if not main_obj :
        return 
    try :
        active_id =str (main_obj .get ("ui_active_item")or "BASE")
    except Exception :
        active_id ="BASE"
    if (not active_id )or (active_id =="BASE"):
        return 
    try :
        am =main_obj .modifiers .get (active_id )
    except Exception :
        am =None 
    if (not am )or (not is_ep_layer (am )):
        return 

    try :
        en ,fn =get_ep_mesh_names (am )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 
    except Exception :
        e_obj =None 
        f_obj =None 

        # Frozen is never visible/selectable.
    if f_obj :
        try :
            _ep_set_obj_hidden (f_obj ,True ,True )
        except Exception :
            pass 

    if e_obj :
        try :
            _ep_set_obj_hidden (e_obj ,False ,False )
        except Exception :
            pass 
        try :
            e_obj .display_type ='SOLID'
        except Exception :
            pass 
        try :
            pass 
        except Exception :
            pass 
        try :
            set_edit_object_modifier_visibility (e_obj ,False )
        except Exception :
            pass 

            # Ensure preview naming/collection consistency if it exists (do NOT force visibility here).
    try :
        pobj =_ep_get_ms_preview_obj (main_obj )
        if pobj :
            _ep_ensure_ms_preview_obj (main_obj ,pobj )
    except Exception :
        pass 

        # If nothing is selected/active, make EP target the active object (so Smart Modifier UI won't go blank).
    try :
        ctx =bpy .context 
        if getattr (ctx ,"mode","")=='OBJECT':
            vl =getattr (ctx ,"view_layer",None )
            if vl :
                cur_act =None 
                try :
                    cur_act =vl .objects .active 
                except Exception :
                    cur_act =None 
                cur_sel =list (getattr (ctx ,"selected_objects",[])or [])
                if (not cur_sel )and e_obj :
                    try :
                        e_obj .select_set (True )
                    except Exception :
                        pass 
                if (cur_act is None )and e_obj :
                    try :
                        vl .objects .active =e_obj 
                    except Exception :
                        pass 
    except Exception :
        pass 


def _ep_lock_helpers_object_mode_for_main (main_obj ):
    """In OBJECT mode, keep selection stable without ever ending up with EVERYTHING hidden/unselectable.

    Key rule:
      - If EditPoly is currently the active layer (or main is hidden by MS during an EP session),
        do NOT hide/lock the EP edit target or MS EndPreview here.
      - Otherwise (normal OBJECT mode), hide/lock EP helpers and MS preview so only the main object remains.
    """
    if not main_obj :
        return 

        # If EP is active, we may pass through transient OBJECT mode (ms__safe_mode_set). Do not fight it.
    try :
        if _ep_is_ep_edit_active (main_obj )or bool (getattr (main_obj ,"hide_viewport",False )and getattr (main_obj ,"hide_select",False )):
            _ep_ensure_ep_targets_visible_for_main (main_obj )
            return 
    except Exception :
        pass 

        # Normal OBJECT mode: hide & lock EP helpers
    try :
        for h in ep_iter_helpers_for_main (main_obj .name ):
            if not h :
                continue 
            try :
                if h .get ("ep_main_target")!=main_obj .name :
                    continue 
            except Exception :
                continue 
            try :
                _ep_safe_deselect (h )
            except Exception :
                pass 
            try :
                h .hide_select =True 
            except Exception :
                pass 
            try :
                h .hide_viewport =False 
            except Exception :
                pass 
            try :
                h .hide_set (True )
            except Exception :
                pass 
    except Exception :
        pass 

        # MS end-result preview: in OBJECT mode, show ONLY the main object.
    try :
        pobj =_ep_get_ms_preview_obj (main_obj )
        if pobj :
            try :
                _ep_safe_deselect (pobj )
            except Exception :
                pass 
            try :
                pobj .hide_select =True 
            except Exception :
                pass 
            try :
                if bool (getattr (pobj ,"hide_viewport",False )):
                    pobj .hide_viewport =False
            except Exception :
                pass 
            try :
                pobj .hide_set (True )
            except Exception :
                pass 
            try :
                pobj .hide_render =True 
            except Exception :
                pass 
    except Exception :
        pass 

        # Preserve the real edit target's view-layer hidden state as well as
        # hide_select / hide_viewport.  Only add-on helper objects are managed
        # here; user objects must not be unhidden or unlocked implicitly.

def _ep_mark_touched_main (main_obj ):
    if not main_obj :
        return 
    try :
        dn =_ep_dn ()
        lst =dn .get (_EP_TOUCHED_MAINS_KEY )
        if not isinstance (lst ,list ):
            lst =[]
        nm =str (main_obj .name )
        if nm and nm not in lst :
        # Keep it short to stay lightweight
            if len (lst )>24 :
                lst =lst [-24 :]
            lst .append (nm )
        dn [_EP_TOUCHED_MAINS_KEY ]=lst 
    except Exception :
        pass 

def _ep_schedule_touched_restore (*,delay :float =0.0 ,reason :str =""):
    dn =_ep_dn ()
    if reason :
        try :
            dn [_EP_TOUCHED_RESTORE_REASON_KEY ]=str (reason )
        except Exception :
            pass 
    if dn .get (_EP_TOUCHED_RESTORE_PENDING_KEY ):
        return 
    dn [_EP_TOUCHED_RESTORE_PENDING_KEY ]=True 
    try :
        bpy .app .timers .register (_ep_touched_restore_timer ,first_interval =float (delay or 0.0 ))
    except Exception :
        dn [_EP_TOUCHED_RESTORE_PENDING_KEY ]=False 

def _ep_touched_restore_timer ():
    dn =_ep_dn ()
    dn [_EP_TOUCHED_RESTORE_PENDING_KEY ]=False 

    # Only restore in OBJECT mode (never fight during edit-mode transitions)
    try :
        if getattr (bpy .context ,"mode","")!='OBJECT':
            return None 
    except Exception :
        return None 

    try :
        lst =dn .get (_EP_TOUCHED_MAINS_KEY )
        if not isinstance (lst ,list ):
            return None 

        remain =[]
        for nm in lst :
            try :
                main_obj =bpy .data .objects .get (str (nm ))
            except Exception :
                main_obj =None 
            if not main_obj or getattr (main_obj ,"type","")!='MESH':
                continue 

                # Restore only if EP actually overrode the display state on this main.
            try :
                if _EP_MAIN_DISP_KEY in main_obj :
                    _ep_restore_main_object_mesh (main_obj )
            except Exception :
                pass 

                # Ensure helper/preview objects are hidden/locked in OBJECT mode.
            try :
                _ep_lock_helpers_object_mode_for_main (main_obj )
            except Exception :
                pass 

                # If the override key is still present, keep it for the next triggered restore.
            try :
                if _EP_MAIN_DISP_KEY in main_obj :
                    remain .append (main_obj .name )
            except Exception :
                pass 

        dn [_EP_TOUCHED_MAINS_KEY ]=remain 
    except Exception :
        pass 
    return None 


def _ep_objsel_restore_timer ():
    """Restore main-object selection after EP helper switching / mode transitions.

    IMPORTANT:
      - Never call bpy.ops.* here (can be invoked during sensitive state transitions).
      - Use a timer to run in OBJECT mode once the view-layer state is stable.
      - Prefer restoring the original main-object selection; keep it lightweight and robust.
    """
    dn =_ep_dn ()
    dn [_EP_OBJSEL_PENDING_KEY ]=False 

    # Basic retry budget (handles the case where mode switch hasn't finalized yet)
    tries =int (dn .get (_EP_OBJSEL_TRIES_KEY )or 0 )
    if tries >24 :
    # Give up retrying; just ensure helpers are locked/hidden in OBJECT mode and clear the pending pin.
        try :
            names0 =dn .get (_EP_OBJSEL_NAMES_KEY )or []
            if isinstance (names0 ,(list ,tuple )):
                for n0 in names0 :
                    o0 =bpy .data .objects .get (str (n0 ))
                    if o0 :
                        _ep_lock_helpers_object_mode_for_main (o0 )
        except Exception :
            pass 
        try :
            dn [_EP_OBJSEL_PIN_KEY ]=False 
        except Exception :
            pass 
        dn [_EP_OBJSEL_TRIES_KEY ]=0 
        return None 

        # Re-entrancy lock
    if dn .get (_EP_OBJSEL_LOCK_KEY ):
        dn [_EP_OBJSEL_TRIES_KEY ]=tries +1 
        return 0.05 
    dn [_EP_OBJSEL_LOCK_KEY ]=True 

    try :
        ctx =bpy .context 
        if getattr (ctx ,"mode","")!='OBJECT':
            dn [_EP_OBJSEL_TRIES_KEY ]=tries +1 
            return 0.05 

        vl =getattr (ctx ,"view_layer",None )
        if not vl :
            dn [_EP_OBJSEL_TRIES_KEY ]=tries +1 
            return 0.05 

        names =dn .get (_EP_OBJSEL_NAMES_KEY )or []
        if not isinstance (names ,(list ,tuple )):
            names =[]
        names =[n for n in names if isinstance (n ,str )]

        if not names :
            dn [_EP_OBJSEL_TRIES_KEY ]=0 
            return None 

        active_name =dn .get (_EP_OBJSEL_ACTIVE_KEY )
        if not isinstance (active_name ,str ):
            active_name =""

            # Determine whether to prefer unlocking mains (avoid restoring temporary helper-induced hidden/locked states)
        reason =""
        try :
            reason =str (dn .get (_EP_OBJSEL_REASON_KEY )or "")
        except Exception :
            reason =""
        pin =bool (dn .get (_EP_OBJSEL_PIN_KEY ))
        prefer_unlock =pin or ("enter_edit"in reason )or ("leave_edit"in reason )or ("seed_from_helper"in reason )

        st_map =dn .get (_EP_OBJSEL_STATE_KEY )or {}
        mains_state ={}
        if isinstance (st_map ,dict ):
            mains_state =st_map .get ("mains")or {}
            if not isinstance (mains_state ,dict ):
                mains_state ={}

                # Collect main objects (must exist and be in view layer)
        objs =[]
        for n in names :
            o =bpy .data .objects .get (n )
            if not o :
                continue 
            try :
                if vl .objects .get (o .name )is None :
                    continue 
            except Exception :
                pass 
            objs .append (o )

        if not objs :
            dn [_EP_OBJSEL_TRIES_KEY ]=0 
            return None 


            # If EditPoly is currently the active editing layer on any of these mains,
            # do not perform OBJECT-mode selection restoration/locking that could hide BOTH main and EP targets.
            # This can occur during transient OBJECT-mode windows (e.g. ms__safe_mode_set).
        try :
            for mo in objs :
                if _ep_is_ep_edit_active (mo )or bool (getattr (mo ,"hide_viewport",False )and getattr (mo ,"hide_select",False )):
                    _ep_ensure_ep_targets_visible_for_main (mo )
                    dn [_EP_OBJSEL_TRIES_KEY ]=0 
                    try :
                        dn [_EP_OBJSEL_PIN_KEY ]=False 
                    except Exception :
                        pass 
                    return None 
        except Exception :
            pass 

            # If the user has already made a new non-helper selection in OBJECT mode,
            # do NOT override it by restoring an older snapshot (prevents 'selecting one object selects others').
        try :
            cur_sel =list (getattr (ctx ,"selected_objects",[])or [])
            cur_mains =[]
            any_helper =False 
            for so in cur_sel :
                if _ep_is_helper_obj (so ):
                    any_helper =True 
                mo =get_main_object (so )or so 
                if mo and getattr (mo ,"name",None )and mo .name not in cur_mains :
                    cur_mains .append (mo .name )
            try :
                act0 =vl .objects .active 
                if act0 and _ep_is_helper_obj (act0 ):
                    any_helper =True 
            except Exception :
                pass 
            try :
                ts0 =float (dn .get (_EP_OBJSEL_TS_KEY )or 0.0 )
            except Exception :
                ts0 =0.0 
            dt0 =(time .time ()-ts0 )if ts0 else 999.0 
            snap_set0 =set (names )
            cur_set0 =set (cur_mains )
            # If the current selection is a different main-set (and no helper is involved),
            # respect it once the immediate post-switch window has passed.
            if cur_set0 and (cur_set0 !=snap_set0 )and (not any_helper )and dt0 >0.25 :
                dn [_EP_OBJSEL_TRIES_KEY ]=0 
                try :
                    dn [_EP_OBJSEL_PIN_KEY ]=False 
                except Exception :
                    pass 
                return None 
        except Exception :
            pass 
            # Restore visibility/selection flags (conservatively)
        for o in objs :
            st =mains_state .get (o .name )if isinstance (mains_state ,dict )else None 
            restore_restrictions =isinstance (st ,dict )and (not prefer_unlock )
            if restore_restrictions :
                want_hide =bool (st .get ("hide_get"))
                want_hv =bool (st .get ("hide_viewport",want_hide ))
                want_hs =bool (st .get ("hide_select"))
                try :
                    o .hide_set (bool (want_hide ))
                except Exception :
                    pass 
                try :
                    o .hide_viewport =bool (want_hv )
                except Exception :
                    pass 
                try :
                    o .hide_select =bool (want_hs )
                except Exception :
                    pass 
            else :
                # No reliable snapshot or this is a transient helper-driven
                # restore.  Do not invent or force any real-object visibility /
                # selectability state.
                pass 

                # Ensure main objects are selected (do NOT deselect others; avoid user-visible selection loss)
        for o in objs :
            try :
                o .select_set (True )
            except Exception :
                pass 

                # Set active main object (avoid helper remaining active)
        act_obj =bpy .data .objects .get (active_name )if active_name else None 
        if act_obj and (act_obj in objs ):
            try :
                vl .objects .active =act_obj 
            except Exception :
                pass 
        else :
            try :
                cur =vl .objects .active 
            except Exception :
                cur =None 
            if (not cur )or (cur .name not in names ):
                try :
                    vl .objects .active =objs [0 ]
                except Exception :
                    pass 

                    # Emergency unstick: if every main is non-selectable / hidden, unlock them.
        any_selectable =False 
        for o in objs :
            try :
                if (not o .hide_select )and (not o .hide_viewport ):
                    any_selectable =True 
                    break 
            except Exception :
                pass 
        if not any_selectable :
            # Preserve user restriction and visibility states on real objects.
            # Helper objects are locked/hidden below; real edit targets are not
            # force-unhidden or force-unlocked by Smart Modifier Suite.
            pass 


                # In OBJECT mode, ensure helpers/previews are never visible/selectable/selected.
        try :
            for mo in objs :
                _ep_lock_helpers_object_mode_for_main (mo )
        except Exception :
            pass 

            # Clear pin after a successful restore so later user selections won't be overridden.
        try :
            dn [_EP_OBJSEL_PIN_KEY ]=False 
        except Exception :
            pass 
        dn [_EP_OBJSEL_TRIES_KEY ]=0 
        return None 

    finally :
        dn [_EP_OBJSEL_LOCK_KEY ]=False 

def _ep_ensure_collection_not_excluded (context ):
    """Ensure the system collections are active in the view layer before entering edit mode."""
    if not context :return 
    vl =getattr (context ,"view_layer",None )
    if not vl :return 
    try :
        root_lc =vl .layer_collection .children .get (MODSYS_ROOT_COLLECTION )
        if root_lc and getattr (root_lc ,'exclude',False ):
            root_lc .exclude =False 
            # EP collection can also be excluded independently; ensure it's visible too.
        if root_lc :
            ep_lc =root_lc .children .get (MODSYS_EP_COLLECTION )
            if ep_lc and getattr (ep_lc ,'exclude',False ):
                ep_lc .exclude =False 
    except Exception :
        pass 

def _ep_enter_edit_mode_for_layer (context ,main_obj ,mod_name :str ):
    if not context or not main_obj or not mod_name :return 
    try :mod =main_obj .modifiers .get (mod_name )
    except Exception :mod =None 
    if not mod or not is_ep_layer (mod ):return 
    # Capture & pin object selection BEFORE helper switching (prevents empty/single selection on return)
    try :_ep_objsel_capture (context ,force =True ,pin =True ,reason ='enter_edit')
    except Exception :pass 


    try :_ep_ensure_unique_layer_assets (main_obj ,mod ,context )
    except Exception :pass 

    en ,fn =get_ep_mesh_names (mod )
    e_obj =bpy .data .objects .get (en )if en else None 
    f_obj =bpy .data .objects .get (fn )if fn else None 
    try :e_obj ,f_obj =_ep_link_layer_helpers_for_edit (main_obj ,mod ,context )
    except Exception :pass 
    if not e_obj :return 

    # Restore any temporary display overrides (prevents sticky black wireframe).
    try :_ep_restore_main_object_mesh (main_obj )
    except Exception :pass 

    # Hide the main object while editing EP (do not force display_type to WIRE/BOUNDS).
    try :
        _ep_set_obj_hidden (main_obj ,True ,True )
    except Exception :pass 
    try :
        if f_obj :
            _ep_set_obj_hidden (f_obj ,True ,True )
    except Exception :pass 
    try :
        _ep_set_obj_hidden (e_obj ,False ,False )
        e_obj .display_type ='SOLID'
        try :e_obj .show_wire =True 
        except Exception :pass 
        try :e_obj .show_all_edges =True 
        except Exception :pass 
        pass 
        set_edit_object_modifier_visibility (e_obj ,False )
    except Exception :pass 

    try :
        for ob in ep_iter_helpers_for_main (main_obj .name ):
            if ob ==e_obj :continue 
            if ob .get ("ep_main_target")==main_obj .name :
                try :
                    try :ob .select_set (False )
                    except Exception :pass 
                    _ep_set_obj_hidden (ob ,True ,True )
                except Exception :pass 
    except Exception :pass 

    vl =getattr (context ,"view_layer",None )
    if vl is None :return 

    try :
        if getattr (context ,"mode","OBJECT")!='OBJECT':
            if bpy .ops .object .mode_set .poll ():
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
    except Exception :pass 

    _ep_force_deselect_all (context )
    _ep_ensure_collection_not_excluded (context )

    try :
        e_obj .select_set (True )
        vl .objects .active =e_obj 
    except Exception :pass 

    try :
        if bpy .ops .object .mode_set .poll ():
            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
    except Exception :pass 

    # If entering edit mode failed, restore main visibility to avoid an empty/hidden state.
    try :
        if getattr (context ,"mode","")!='EDIT_MESH':
            try :
                _ep_set_obj_hidden (main_obj ,False ,False )
            except Exception :pass 
            try :_ep_restore_main_object_mesh (main_obj )
            except Exception :pass 
            return 
    except Exception :pass 
    try :
        sel =ms_sel_get (main_obj ,mod_name )or ms_sel_get (main_obj ,"BASE")
        if sel and ((sel .get ('v')or [])or (sel .get ('e')or [])or (sel .get ('f')or [])):
            _ms_apply_edit_mesh_selection (e_obj ,sel )
    except Exception :pass 

def _ep_enter_edit_mode_for_layer_multi (context ,main_objs ,mod_name :str ,active_main =None ):
    if not context or not main_objs or not mod_name :return 
    vl =getattr (context ,"view_layer",None )
    if vl is None :return 
    # Capture & pin object selection BEFORE helper switching (multi)
    try :_ep_objsel_capture (context ,force =True ,pin =True ,reason ='enter_edit_multi')
    except Exception :pass 


    edit_objs =[]
    active_edit =None 

    try :
        if getattr (context ,"mode","OBJECT")!='OBJECT':
            if bpy .ops .object .mode_set .poll ():
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
    except Exception :pass 

    for main_obj in list (main_objs ):
        if not main_obj or getattr (main_obj ,"type","")!='MESH':continue 
        try :mod =main_obj .modifiers .get (mod_name )
        except Exception :mod =None 
        if not mod or not is_ep_layer (mod ):continue 

        en ,fn =get_ep_mesh_names (mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 
        try :e_obj ,f_obj =_ep_link_layer_helpers_for_edit (main_obj ,mod ,context )
        except Exception :pass 
        if not e_obj :continue 

        # Restore any temporary display overrides (prevents sticky black wireframe).
        try :_ep_restore_main_object_mesh (main_obj )
        except Exception :pass 

        # Hide the main object while editing EP (do not force display_type to WIRE/BOUNDS).
        try :
            _ep_set_obj_hidden (main_obj ,True ,True )
        except Exception :pass 
        try :
            if f_obj :
                try :f_obj .select_set (False )
                except Exception :pass 
                _ep_set_obj_hidden (f_obj ,True ,True )
        except Exception :pass 

        try :
            _ep_set_obj_hidden (e_obj ,False ,False )
            e_obj .display_type ='SOLID'
            try :e_obj .show_wire =True 
            except Exception :pass 
            try :e_obj .show_all_edges =True 
            except Exception :pass 
            pass 
            set_edit_object_modifier_visibility (e_obj ,False )
        except Exception :pass 

        edit_objs .append (e_obj )
        if active_main and main_obj ==active_main :
            active_edit =e_obj 

        try :
            for ob in ep_iter_helpers_for_main (main_obj .name ):
                if ob ==e_obj :continue 
                if ob .get ("ep_main_target")==main_obj .name :
                    try :ob .select_set (False )
                    except Exception :pass 
                    try :
                        _ep_set_obj_hidden (ob ,True ,True )
                    except Exception :pass 
        except Exception :pass 

    if not edit_objs :return 

    _ep_force_deselect_all (context )
    _ep_ensure_collection_not_excluded (context )

    try :
        for eo in edit_objs :eo .select_set (True )
    except Exception :pass 
    try :vl .objects .active =active_edit or edit_objs [0 ]
    except Exception :pass 

    try :
        if bpy .ops .object .mode_set .poll ():
            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
    except Exception :pass 

    # If entering edit mode failed, restore main visibility to avoid an empty/hidden state.
    try :
        if getattr (context ,"mode","")!='EDIT_MESH':
            try :
                _ep_set_obj_hidden (main_obj ,False ,False )
            except Exception :pass 
            try :_ep_restore_main_object_mesh (main_obj )
            except Exception :pass 
            return 
    except Exception :pass 
    try :
        for eo in edit_objs :
            try :eo .select_set (True )
            except Exception :pass 
        try :vl .objects .active =active_edit or (edit_objs [0 ]if edit_objs else None )
        except Exception :pass 
    except Exception :pass 

    try :
        for eo in edit_objs :
            try :
                mobj =get_main_object (eo )
                if not mobj :continue 
                sel =ms_sel_get (mobj ,mod_name )or ms_sel_get (mobj ,"BASE")
                if sel and ((sel .get ('v')or [])or (sel .get ('e')or [])or (sel .get ('f')or [])):
                    _ms_apply_edit_mesh_selection (eo ,sel )
            except Exception :continue 
    except Exception :pass 

def _ep_enter_edit_mode_for_layer_multi_map (context ,pairs ,active_main =None ):
    if not context or not pairs :return 
    vl =getattr (context ,"view_layer",None )
    if vl is None :return 

    try :
        if getattr (context ,"mode","OBJECT")!='OBJECT':
            if bpy .ops .object .mode_set .poll ():
                bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
    except Exception :pass 

    edit_objs =[]
    active_edit =None 

    for main_obj ,mod_name in list (pairs ):
        if not main_obj or getattr (main_obj ,"type","")!='MESH'or not mod_name :continue 
        try :mod =main_obj .modifiers .get (mod_name )
        except Exception :mod =None 
        if not mod or not is_ep_layer (mod ):continue 

        try :_ep_ensure_unique_layer_assets (main_obj ,mod ,context )
        except Exception :pass 

        en ,fn =get_ep_mesh_names (mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 
        try :e_obj ,f_obj =_ep_link_layer_helpers_for_edit (main_obj ,mod ,context )
        except Exception :pass 
        if not e_obj :continue 

        # Restore any temporary display overrides (prevents sticky black wireframe).
        try :_ep_restore_main_object_mesh (main_obj )
        except Exception :pass 

        # Hide the main object while editing EP (do not force display_type to WIRE/BOUNDS).
        try :
            _ep_set_obj_hidden (main_obj ,True ,True )
        except Exception :pass 
        try :
            if f_obj :
                try :f_obj .select_set (False )
                except Exception :pass 
                _ep_set_obj_hidden (f_obj ,True ,True )
        except Exception :pass 

        try :
            _ep_set_obj_hidden (e_obj ,False ,False )
            e_obj .display_type ='SOLID'
            try :e_obj .show_wire =True 
            except Exception :pass 
            try :e_obj .show_all_edges =True 
            except Exception :pass 
            pass 
            set_edit_object_modifier_visibility (e_obj ,False )
        except Exception :pass 

        edit_objs .append (e_obj )
        if active_main and main_obj ==active_main :
            active_edit =e_obj 

        try :
            for ob in ep_iter_helpers_for_main (main_obj .name ):
                if ob ==e_obj :continue 
                if ob .get ("ep_main_target")==main_obj .name :
                    try :ob .select_set (False )
                    except Exception :pass 
                    try :
                        _ep_set_obj_hidden (ob ,True ,True )
                    except Exception :pass 
        except Exception :pass 

    if not edit_objs :return 

    _ep_force_deselect_all (context )
    _ep_ensure_collection_not_excluded (context )

    try :
        for eo in edit_objs :eo .select_set (True )
    except Exception :pass 
    try :vl .objects .active =active_edit or edit_objs [0 ]
    except Exception :pass 

    try :
        if bpy .ops .object .mode_set .poll ():
            bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='EDIT')
    except Exception :pass 

    # If entering edit mode failed, restore main visibility to avoid an empty/hidden state.
    try :
        if getattr (context ,"mode","")!='EDIT_MESH':
            try :
                _ep_set_obj_hidden (main_obj ,False ,False )
            except Exception :pass 
            try :_ep_restore_main_object_mesh (main_obj )
            except Exception :pass 
            return 
    except Exception :pass 
    try :
        for eo in edit_objs :
            try :eo .select_set (True )
            except Exception :pass 
        try :vl .objects .active =active_edit or (edit_objs [0 ]if edit_objs else None )
        except Exception :pass 
    except Exception :pass 

    for main_obj ,mod_name in list (pairs ):
        try :
            mod =main_obj .modifiers .get (mod_name )
            if not mod or not is_ep_layer (mod ):continue 
            en ,_fn =get_ep_mesh_names (mod )
            eo =bpy .data .objects .get (en )if en else None 
            if not eo :continue 
            sel =ms_sel_get (main_obj ,mod_name )or ms_sel_get (main_obj ,"BASE")
            if sel and ((sel .get ('v')or [])or (sel .get ('e')or [])or (sel .get ('f')or [])):
                _ms_apply_edit_mesh_selection (eo ,sel )
        except Exception :continue 

_EP_MS_EN_CACHE_KEY ="_EP_MS_ENABLED_CACHE_V1"

def _ms__enabled_cache ():
    try :
        dn =bpy .app .driver_namespace 
    except Exception :
        return {}
    d =dn .get (_EP_MS_EN_CACHE_KEY )
    if not isinstance (d ,dict ):
        d ={}
        dn [_EP_MS_EN_CACHE_KEY ]=d 
    return d 

def _ms_enabled_map (main_obj ):
    mods =list (getattr (main_obj ,"modifiers",[])or [])
    # Read stable "enabled" states from Smart Modifier backup map if available.
    # IMPORTANT: never use Modifier.show_viewport here, because Smart Modifier may toggle show_viewport
    # during level-view / preview updates (which would incorrectly look like "disabled").
    try :
        raw =main_obj .get ("ms_mod_enabled_bak","{}")
        if raw is None :
            raw ="{}"
    except Exception :
        raw ="{}"

        # Cache parsed JSON per-object to keep this lightweight.
    d ={}
    try :
        cache =_ms__enabled_cache ()
        key =main_obj .name 
        ent =cache .get (key )
        if isinstance (ent ,tuple )and len (ent )==2 and ent [0 ]==raw and isinstance (ent [1 ],dict ):
            d =ent [1 ]
        else :
            try :
                d =json .loads (raw or "{}")
                if not isinstance (d ,dict ):
                    d ={}
            except Exception :
                d ={}
            cache [key ]=(raw ,d )
    except Exception :
        try :
            d =json .loads (raw or "{}")
            if not isinstance (d ,dict ):
                d ={}
        except Exception :
            d ={}

    try :
        return {m .name :bool (d .get (m .name ,True ))for m in mods }
    except Exception :
    # Fallback: default enabled
        return {m .name :True for m in mods }

def _ms_mod_is_enabled (main_obj ,mod ):
    if not main_obj or not mod :
        return True 
    try :
        raw =main_obj .get ("ms_mod_enabled_bak","{}")
        if raw is None :
            raw ="{}"
        d =None 
        try :
            cache =_ms__enabled_cache ()
            key =main_obj .name 
            ent =cache .get (key )
            if isinstance (ent ,tuple )and len (ent )==2 and ent [0 ]==raw and isinstance (ent [1 ],dict ):
                d =ent [1 ]
        except Exception :
            d =None 
        if d is None :
            try :
                d =json .loads (raw or "{}")
                if not isinstance (d ,dict ):
                    d ={}
            except Exception :
                d ={}
            try :
                cache =_ms__enabled_cache ()
                cache [main_obj .name ]=(raw ,d )
            except Exception :
                pass 
        return bool (d .get (mod .name ,True ))
    except Exception :
        return True 

def get_carrier_key_for_effective (main_obj ,effective_id ):
    if not main_obj or not effective_id or effective_id =="BASE":return "BASE"
    idx =main_obj .modifiers .find (effective_id )
    if idx <0 :return "BASE"
    mods =list (main_obj .modifiers )

    try :
        m0 =mods [idx ]
        if is_ep_layer (m0 )and _ms_mod_is_enabled (main_obj ,m0 ):return m0 .name 
    except Exception :pass 

    for i in range (idx -1 ,-1 ,-1 ):
        try :
            m =mods [i ]
            if is_ep_layer (m )and _ms_mod_is_enabled (main_obj ,m ):return m .name 
        except Exception :continue 
    return "BASE"

def find_inherit_key_for_carrier (main_obj ,carrier_key ):
    if not main_obj or carrier_key =="BASE":return "BASE"
    idx =main_obj .modifiers .find (carrier_key )
    if idx <0 :return "BASE"
    mods =list (main_obj .modifiers )

    try :
        for i in range (idx +1 ,len (mods )):
            m =mods [i ]
            if is_ep_layer (m )and _ms_mod_is_enabled (main_obj ,m ):
                if ms_sel_get (main_obj ,m .name ):return m .name 

        for i in range (idx -1 ,-1 ,-1 ):
            m =mods [i ]
            if is_ep_layer (m )and _ms_mod_is_enabled (main_obj ,m ):
                if ms_sel_get (main_obj ,m .name ):return m .name 

        if ms_sel_get (main_obj ,"BASE"):return "BASE"
    except Exception :pass 
    return "BASE"

def _ep_fixup_instance_mesh_sharing (instance_id :str ,prefer_obj_name :str |None =None ,prefer_mod_name :str |None =None ):
    return False 

def _ep_schedule_instance_fixup (instance_id :str ,prefer_obj_name :str |None =None ,prefer_mod_name :str |None =None ):
    return 

def _sock (sockets ,*names ,fallback_index =None ):
    for n in names :
        for s in sockets :
            try :
                if s .name ==n :return s 
            except :pass 
    if fallback_index is not None :
        try :return sockets [fallback_index ]
        except :return None 
    return None 

def _safe_link (links ,out_socket ,in_socket ):
    if not out_socket or not in_socket :return 
    try :links .new (out_socket ,in_socket )
    except :pass 


def _ep_mesh_topology_signature (mesh_obj ):
    """Return a topology-only signature for Edit Polygon topology change detection."""
    if not mesh_obj or getattr (mesh_obj ,'type','')!='MESH':
        return None 
    try :
        me =getattr (mesh_obj ,'data',None )
        if not me :return None 
    except Exception :return None 

    try :
        if getattr (mesh_obj ,'mode','')=='EDIT':
            bm =bmesh .from_edit_mesh (me )
            try :
                bm .verts .ensure_lookup_table ();bm .edges .ensure_lookup_table ();bm .faces .ensure_lookup_table ()
                bm .verts .index_update ();bm .edges .index_update ();bm .faces .index_update ()
            except Exception :pass 
            edges =tuple (sorted (tuple (sorted ((int (v .index )for v in e .verts )))for e in bm .edges ))
            faces =tuple (tuple (int (v .index )for v in f .verts )for f in bm .faces )
            return (len (bm .verts ),len (bm .edges ),len (bm .faces ),edges ,faces )
    except Exception :
        pass 

    try :
        edges =tuple (sorted (tuple (sorted ((int (v )for v in e .vertices )))for e in me .edges ))
        faces =tuple (tuple (int (v )for v in p .vertices )for p in me .polygons )
        return (len (me .vertices ),len (me .edges ),len (me .polygons ),edges ,faces )
    except Exception :
        return None 


def _ep_layer_has_topology_delta (edit_obj ,frozen_obj )->bool :
    try :
        es =_ep_mesh_topology_signature (edit_obj )
        fs =_ep_mesh_topology_signature (frozen_obj )
        if es is None or fs is None :return False 
        return es !=fs 
    except Exception :
        return False 


def _ep_sanitize_exact_output_mesh (mesh_obj ,*,destructive =False ):
    """Refresh the Edit Polygon helper mesh after topology edits.

    Face/edge/vertex deletion while an upstream deformer such as Smart Lattice is
    present can leave the helper mesh and the Geometry Nodes Object Info output
    one dependency update behind.  This makes the modifier's displacement-index
    layout sample stale loops for a frame, which appears as broken polygons around
    the deleted area.  The helper mesh itself must remain the authoritative output
    for topology edits, so this routine only validates/refreshes mesh data and
    never changes the user's topology.
    """
    try :
        if not mesh_obj or getattr (mesh_obj ,'type','')!='MESH':return False
        me =getattr (mesh_obj ,'data',None )
        if not me :return False
    except Exception :return False
    changed =False
    try :
        if getattr (mesh_obj ,'mode','')=='EDIT':
            bm =bmesh .from_edit_mesh (me )
            try :
                bm .verts .ensure_lookup_table ();bm .edges .ensure_lookup_table ();bm .faces .ensure_lookup_table ()
                bm .verts .index_update ();bm .edges .index_update ();bm .faces .index_update ()
                bm .normal_update ()
            except Exception :pass
            try :
                bmesh .update_edit_mesh (me ,loop_triangles =True ,destructive =bool (destructive ))
                changed =True
            except TypeError :
                try :bmesh .update_edit_mesh (me ,True )
                except Exception :pass
            except Exception :pass
        else :
            try :me .validate (clean_customdata =False );changed =True
            except TypeError :
                try :me .validate ();changed =True
                except Exception :pass
            except Exception :pass
            try :me .update (calc_edges =True );changed =True
            except TypeError :
                try :me .update ();changed =True
                except Exception :pass
            except Exception :pass
            try :me .polygons .foreach_set ('use_smooth',[bool (p .use_smooth )for p in me .polygons ])
            except Exception :pass
    except Exception :pass
    try :me .update_tag ()
    except Exception :pass
    try :mesh_obj .update_tag ()
    except Exception :pass
    return bool (changed )


def _ep_force_depsgraph_refresh_for_layer (main_obj ,mod ,edit_obj =None ,frozen_obj =None ,ng =None ):
    """Tag all objects/datablocks used by an Edit Polygon layer for immediate redraw/evaluation."""
    for datablock in (edit_obj ,frozen_obj ,main_obj ,getattr (edit_obj ,'data',None ),getattr (frozen_obj ,'data',None ),getattr (main_obj ,'data',None ),ng ,getattr (mod ,'node_group',None )):
        try :
            if datablock :datablock .update_tag ()
        except Exception :pass
    try :
        if main_obj :main_obj .update_tag ()
    except Exception :pass
    # Do not call view_layer.update() here. This function is often called from
    # depsgraph handlers/timers, and forcing an update from inside those paths can
    # recurse into unrelated add-on handlers. Tagging the datablocks is sufficient;
    # Blender will evaluate them on the next normal dependency update.


def _ep_find_layer_for_edit_helper (edit_obj ):
    """Return (main_obj, ep_modifier) for a live Edit Polygon helper mesh."""
    if not edit_obj or getattr (edit_obj ,'type','')!='MESH':return (None ,None )
    try :main_name =str (edit_obj .get ('ep_main_target','')or '')
    except Exception :main_name =''
    if not main_name :return (None ,None )
    try :main_obj =bpy .data .objects .get (main_name )
    except Exception :main_obj =None 
    if not main_obj :return (None ,None )
    try :mods =list (getattr (main_obj ,'modifiers',[])or [])
    except Exception :mods =[]
    for m in mods :
        try :
            if not is_ep_layer (m ):continue 
            en ,_fn =get_ep_mesh_names (m )
            if en ==edit_obj .name :return (main_obj ,m )
        except Exception :continue 
    return (main_obj ,None )


def _ep_topology_cache ():
    try :
        dn =bpy .app .driver_namespace 
        cache =dn .get (_EP_TOPO_SIG_CACHE_DN_KEY )
        if not isinstance (cache ,dict ):
            cache ={}
            dn [_EP_TOPO_SIG_CACHE_DN_KEY ]=cache 
        return cache 
    except Exception :
        return {}


def _ep_topology_cache_key (main_obj ,mod ,edit_obj ):
    try :mn =getattr (main_obj ,'name','')or ''
    except Exception :mn =''
    try :modn =getattr (mod ,'name','')or ''
    except Exception :modn =''
    try :en =getattr (edit_obj ,'name','')or ''
    except Exception :en =''
    return f"{mn}\0{modn}\0{en}"


def _ep_update_helper_topology_state (edit_obj =None ,context =None ,force =False ):
    """Synchronize Edit Polygon output layout with live helper topology.

    Element deletion/addition in Edit Mesh can keep the same object/selection
    signature, so the stack must check the helper mesh topology directly.
    When topology changes, the EP node group is switched from index-offset output
    to direct edited-geometry output immediately, preventing collapsed/broken
    polygons after Smart Lattice/FFD layers.
    """
    ctx =context or bpy .context 
    if edit_obj is None :
        try :edit_obj =getattr (ctx ,'edit_object',None )
        except Exception :edit_obj =None 
        if edit_obj is None :
            try :edit_obj =getattr (getattr (ctx ,'view_layer',None ),'objects',None ).active 
            except Exception :edit_obj =None 
    if not edit_obj or getattr (edit_obj ,'type','')!='MESH':return False 
    try :
        if 'ep_main_target'not in edit_obj :return False 
    except Exception :return False 

    main_obj ,mod =_ep_find_layer_for_edit_helper (edit_obj )
    if not main_obj or not mod :return False 

    try :bpy .app .driver_namespace [_EP_LAST_EDIT_HELPER_DN_KEY ]=edit_obj .name 
    except Exception :pass 

    try :sig =_ep_mesh_topology_signature (edit_obj )
    except Exception :sig =None 

    current =False ;desired =False ;ver =0 
    try :
        ng =getattr (mod ,'node_group',None )
        current =bool (ng .get ('ep_topology_mode',False ))if ng else False 
        ver =int (ng .get ('ep_ng_version',0 )or 0 )if ng else 0 
    except Exception :
        current =False ;ver =0 
    try :
        _en ,fn =get_ep_mesh_names (mod )
        f_obj =bpy .data .objects .get (fn )if fn else None 
        desired =_ep_layer_has_topology_delta (edit_obj ,f_obj )
    except Exception :
        desired =False 

    cache =_ep_topology_cache ()
    key =_ep_topology_cache_key (main_obj ,mod ,edit_obj )
    try :last_sig =cache .get (key )
    except Exception :last_sig =None 

    if (not force )and last_sig ==sig and current ==desired and ver >=EP_NG_VERSION :
        return False 

    try :cache [key ]=sig 
    except Exception :pass 

    try :return bool (_ep_update_topology_mode_for_mod (main_obj ,mod ,ctx ,edit_obj_override =edit_obj ))
    except Exception :return False 


def _ep_update_helper_topology_state_by_name (helper_name ,context =None ,force =True ):
    if not helper_name :return False 
    try :edit_obj =bpy .data .objects .get (str (helper_name ))
    except Exception :edit_obj =None 
    if not edit_obj :return False 
    return _ep_update_helper_topology_state (edit_obj ,context ,force =force )


def _ep_set_object_info_target (node ,obj ):
    if not node :return 
    try :node .name =node .name or ''
    except Exception :pass 
    try :node .transform_space ='ORIGINAL'
    except Exception :pass 
    try :
        if obj and getattr (node ,'inputs',None )and len (node .inputs )>0 :
            node .inputs [0 ].default_value =obj 
    except Exception :pass 
    try :
        sock =_sock (node .inputs ,'As Instance','Instance',fallback_index =None )
        if sock is not None and hasattr (sock ,'default_value'):
            sock .default_value =False 
    except Exception :pass 


def _ep_rebuild_node_group_layout (ng ,edit_obj ,frozen_obj ,topology_mode =False ):
    if not ng :return False 
    try :topology_mode =bool (topology_mode )
    except Exception :topology_mode =False 
    try :
        inputs =[s .name for s in ng .interface .items_tree if getattr (s ,'in_out','')=='INPUT']
        outputs =[s .name for s in ng .interface .items_tree if getattr (s ,'in_out','')=='OUTPUT']
        if 'Geometry'not in inputs :
            ng .interface .new_socket (name ='Geometry',in_out ='INPUT',socket_type ='NodeSocketGeometry')
        if 'Geometry'not in outputs :
            ng .interface .new_socket (name ='Geometry',in_out ='OUTPUT',socket_type ='NodeSocketGeometry')
    except Exception :pass 

    nodes ,links =ng .nodes ,ng .links 
    try :
        nodes .clear ();links .clear ()
    except Exception :pass 

    group_in =nodes .new ('NodeGroupInput')
    group_out =nodes .new ('NodeGroupOutput')

    info_edit =nodes .new ('GeometryNodeObjectInfo')
    info_edit .name ='EP_INFO_EDIT'
    _ep_set_object_info_target (info_edit ,edit_obj )

    info_froz =nodes .new ('GeometryNodeObjectInfo')
    info_froz .name ='EP_INFO_FROZ'
    _ep_set_object_info_target (info_froz ,frozen_obj )

    if topology_mode :
        # Exact topology mode: output the edited helper mesh itself.
        # Realize Instances is harmless for normal mesh Object Info output and prevents
        # stale/instanced geometry display artifacts when the layer sits above FFD/Smart Lattice.
        try :
            realize =nodes .new ('GeometryNodeRealizeInstances')
            _safe_link (links ,_sock (info_edit .outputs ,'Geometry',fallback_index =0 ),_sock (realize .inputs ,'Geometry',fallback_index =0 ))
            _safe_link (links ,_sock (realize .outputs ,'Geometry',fallback_index =0 ),_sock (group_out .inputs ,'Geometry',fallback_index =0 ))
        except Exception :
            _safe_link (links ,_sock (info_edit .outputs ,'Geometry',fallback_index =0 ),_sock (group_out .inputs ,'Geometry',fallback_index =0 ))
    else :
        pos_node =nodes .new ('GeometryNodeInputPosition')
        idx_node =nodes .new ('GeometryNodeInputIndex')

        sample_f =nodes .new ('GeometryNodeSampleIndex')
        sample_f .data_type ='FLOAT_VECTOR'
        _safe_link (links ,_sock (info_froz .outputs ,'Geometry',fallback_index =0 ),_sock (sample_f .inputs ,'Geometry',fallback_index =0 ))
        _safe_link (links ,_sock (pos_node .outputs ,'Position',fallback_index =0 ),_sock (sample_f .inputs ,'Value',fallback_index =1 ))
        _safe_link (links ,_sock (idx_node .outputs ,'Index',fallback_index =0 ),_sock (sample_f .inputs ,'Index',fallback_index =2 ))

        sample_e =nodes .new ('GeometryNodeSampleIndex')
        sample_e .data_type ='FLOAT_VECTOR'
        _safe_link (links ,_sock (info_edit .outputs ,'Geometry',fallback_index =0 ),_sock (sample_e .inputs ,'Geometry',fallback_index =0 ))
        _safe_link (links ,_sock (pos_node .outputs ,'Position',fallback_index =0 ),_sock (sample_e .inputs ,'Value',fallback_index =1 ))
        _safe_link (links ,_sock (idx_node .outputs ,'Index',fallback_index =0 ),_sock (sample_e .inputs ,'Index',fallback_index =2 ))

        sub =nodes .new ('ShaderNodeVectorMath')
        sub .operation ='SUBTRACT'
        _safe_link (links ,_sock (sample_e .outputs ,'Value',fallback_index =0 ),sub .inputs [0 ])
        _safe_link (links ,_sock (sample_f .outputs ,'Value',fallback_index =0 ),sub .inputs [1 ])

        set_pos =nodes .new ('GeometryNodeSetPosition')
        _safe_link (links ,_sock (group_in .outputs ,'Geometry',fallback_index =0 ),_sock (set_pos .inputs ,'Geometry',fallback_index =0 ))
        _safe_link (links ,sub .outputs [0 ],_sock (set_pos .inputs ,'Offset',fallback_index =3 ))
        _safe_link (links ,_sock (set_pos .outputs ,'Geometry',fallback_index =0 ),_sock (group_out .inputs ,'Geometry',fallback_index =0 ))

    try :ng ['ep_ng_version']=EP_NG_VERSION 
    except Exception :pass 
    try :ng ['ep_topology_mode']=bool (topology_mode )
    except Exception :pass 
    try :
        if edit_obj :ng ['ep_edit_mesh']=edit_obj .name 
        if frozen_obj :ng ['ep_frozen_mesh']=frozen_obj .name 
    except Exception :pass 
    return True 


def _ep_update_topology_mode_for_mod (main_obj ,mod ,context =None ,edit_obj_override =None )->bool :
    if not mod or not is_ep_layer (mod )or getattr (mod ,'type','')!='NODES':return False 
    ng =getattr (mod ,'node_group',None )
    if not ng :return False 
    en ,fn =get_ep_mesh_names (mod )
    e_obj =edit_obj_override if edit_obj_override is not None else (bpy .data .objects .get (en )if en else None )
    f_obj =bpy .data .objects .get (fn )if fn else None 
    if not e_obj or not f_obj :return False 
    try :_ep_sanitize_exact_output_mesh (e_obj ,destructive =False )
    except Exception :pass
    try :_ep_sanitize_exact_output_mesh (f_obj ,destructive =False )
    except Exception :pass
    try :desired =_ep_layer_has_topology_delta (e_obj ,f_obj )
    except Exception :desired =False 
    try :current =bool (ng .get ('ep_topology_mode',False ))
    except Exception :current =False 
    try :ver =int (ng .get ('ep_ng_version',0 )or 0 )
    except Exception :ver =0 
    if current !=desired or ver <EP_NG_VERSION :
        rebuilt =_ep_rebuild_node_group_layout (ng ,e_obj ,f_obj ,topology_mode =desired )
        try :_ep_force_depsgraph_refresh_for_layer (main_obj ,mod ,e_obj ,f_obj ,ng )
        except Exception :pass
        return rebuilt 
    try :_ep_patch_node_group_refs (mod ,e_obj ,f_obj )
    except Exception :pass 
    if desired :
        try :_ep_force_depsgraph_refresh_for_layer (main_obj ,mod ,e_obj ,f_obj ,ng )
        except Exception :pass
    return False 



_EP_TOPO_SYNC_QUEUE_KEY = "_EP_TOPO_SYNC_QUEUE_V1"
_EP_TOPO_SYNC_TIMER_KEY = "_EP_TOPO_SYNC_TIMER_V1"
_EP_TOPO_SYNC_SIG_PREFIX = "_ep_topology_sig_"


def _ep_find_layer_for_edit_object (edit_obj ):
    """Return (main_obj, modifier) for an Edit Polygon edit helper object."""
    if not edit_obj or getattr (edit_obj ,'type','')!='MESH':return (None ,None )
    try :main_name =edit_obj .get ("ep_main_target")or ""
    except Exception :main_name =""
    if not main_name :return (None ,None )
    main_obj =bpy .data .objects .get (main_name )
    if not main_obj :return (None ,None )
    try :mods =list (getattr (main_obj ,'modifiers',[])or [])
    except Exception :mods =[]
    for mod in mods :
        try :
            if not is_ep_layer (mod ):continue
            en ,_fn =get_ep_mesh_names (mod )
            if en ==edit_obj .name :return (main_obj ,mod )
        except Exception :continue
    return (main_obj ,None )


def _ep_topology_signature_changed (edit_obj )->bool :
    """Track topology-only changes on the live Edit helper without treating vertex moves as topology edits."""
    if not edit_obj :return False
    try :sig =_ep_mesh_topology_signature (edit_obj )
    except Exception :sig =None
    if sig is None :return False
    try :key =_EP_TOPO_SYNC_SIG_PREFIX +str (edit_obj .name )
    except Exception :key =_EP_TOPO_SYNC_SIG_PREFIX
    try :dn =bpy .app .driver_namespace
    except Exception :dn ={}
    old =None
    try :old =dn .get (key )
    except Exception :old =None
    try :dn [key ]=sig
    except Exception :pass
    return old is not None and old !=sig


def _ep_sync_layer_topology_now (main_obj ,mod ,context =None ,edit_obj_override =None )->bool :
    """Immediately synchronize the node layout for one Edit Polygon layer.

    Topology edits (delete/add/dissolve/fill) must switch the modifier from the
    displacement-offset node layout to the direct edited-mesh output layout as
    soon as the helper mesh changes. Otherwise Geometry Nodes keeps sampling by
    stale vertex indices and the visible polygon result appears collapsed.
    """
    if not main_obj or not mod or not is_ep_layer (mod ):return False
    e_obj =edit_obj_override
    if e_obj is None :
        try :
            en ,_fn =get_ep_mesh_names (mod )
            e_obj =bpy .data .objects .get (en )if en else None
        except Exception :e_obj =None
    try :_ep_sanitize_exact_output_mesh (e_obj ,destructive =True )
    except Exception :pass
    try :changed =_ep_update_topology_mode_for_mod (main_obj ,mod ,context or bpy .context ,edit_obj_override =e_obj )
    except Exception :changed =False
    try :
        en ,fn =get_ep_mesh_names (mod )
        f_obj =bpy .data .objects .get (fn )if fn else None
        ng =getattr (mod ,'node_group',None )
        if ng and bool (ng .get ('ep_topology_mode',False )):
            _ep_force_depsgraph_refresh_for_layer (main_obj ,mod ,e_obj ,f_obj ,ng )
    except Exception :pass
    return bool (changed )


def _ep_sync_topology_modes_for_main (main_obj ,context =None )->bool :
    """Synchronize all Edit Polygon topology/output modes for a main object."""
    if not main_obj or getattr (main_obj ,'type','')!='MESH':return False
    did =False
    try :mods =list (getattr (main_obj ,'modifiers',[])or [])
    except Exception :mods =[]
    for mod in mods :
        try :
            if not is_ep_layer (mod ):continue
            en ,_fn =get_ep_mesh_names (mod )
            e_obj =bpy .data .objects .get (en )if en else None
            did =_ep_sync_layer_topology_now (main_obj ,mod ,context ,e_obj )or did
        except Exception :continue
    return did


def _ep_queue_following_rebake_if_possible (main_obj ,mod ,context =None ):
    """Rebake downstream Edit Polygon layers after a topology-edit layer, but never force mode changes while editing."""
    if not main_obj or not mod :return
    ctx =context or bpy .context
    try :mode =getattr (ctx ,'mode','')or getattr (bpy .context ,'mode','')
    except Exception :mode =''
    if mode !='OBJECT':return
    try :mods =list (getattr (main_obj ,'modifiers',[])or [])
    except Exception :mods =[]
    try :idx =mods .index (mod )
    except Exception :idx =-1
    if idx <0 :return
    try :
        if any (is_ep_layer (m )for m in mods [(idx +1 ):]):
            rebake_edit_polys_from_index (main_obj ,ctx ,start_index =idx +1 )
    except Exception :pass


def _ep_topology_sync_timer ():
    try :dn =bpy .app .driver_namespace
    except Exception :return None
    try :queue =list (dn .get (_EP_TOPO_SYNC_QUEUE_KEY )or [])
    except Exception :queue =[]
    try :dn [_EP_TOPO_SYNC_QUEUE_KEY ]=[]
    except Exception :pass
    try :dn [_EP_TOPO_SYNC_TIMER_KEY ]=False
    except Exception :pass
    seen =set ()
    for item in queue :
        try :main_name ,mod_name ,edit_name =item [:3]
        except Exception :continue
        key =(main_name ,mod_name ,edit_name )
        if key in seen :continue
        seen .add (key )
        main_obj =bpy .data .objects .get (main_name )if main_name else None
        if not main_obj :continue
        try :mod =main_obj .modifiers .get (mod_name )if mod_name else None
        except Exception :mod =None
        if not mod or not is_ep_layer (mod ):continue
        edit_obj =bpy .data .objects .get (edit_name )if edit_name else None
        try :desired =False
        except Exception :desired =False
        try :
            _en ,fn =get_ep_mesh_names (mod )
            f_obj =bpy .data .objects .get (fn )if fn else None
            desired =bool (edit_obj and f_obj and _ep_layer_has_topology_delta (edit_obj ,f_obj ))
        except Exception :desired =False
        try :_ep_sync_layer_topology_now (main_obj ,mod ,bpy .context ,edit_obj )
        except Exception :pass
        if desired :
            try :_ep_queue_following_rebake_if_possible (main_obj ,mod ,bpy .context )
            except Exception :pass
    return None


def _ep_schedule_topology_sync_for_edit_object (edit_obj ,delay =0.0 ,reason ="" ):
    """Synchronize topology-output mode for the Edit Polygon helper being edited.

    Deleting/adding/dissolving elements while the Edit helper is still in Edit
    Mode must switch the main modifier away from the index-sampled displacement
    layout immediately.  Waiting for a timer leaves one or more viewport frames
    using stale vertex indices, which is especially visible when an upstream FFD
    / Smart Lattice layer already deforms the evaluated base mesh.
    """
    main_obj ,mod =_ep_find_layer_for_edit_object (edit_obj )
    if not main_obj or not mod :return False
    try :
        en ,fn =get_ep_mesh_names (mod )
        f_obj =bpy .data .objects .get (fn )if fn else None
        has_delta =bool (f_obj and _ep_layer_has_topology_delta (edit_obj ,f_obj ))
    except Exception :has_delta =False
    # If the layer already uses direct topology output, vertex moves do not require a rebuild.
    # If no topology delta exists and the live topology signature did not change, skip the timer.
    try :topo_sig_changed =_ep_topology_signature_changed (edit_obj )
    except Exception :topo_sig_changed =False
    if not has_delta and not topo_sig_changed :return False

    # Critical path: topology edits must update the node layout synchronously so
    # the visible stack result never evaluates with stale Sample Index offsets.
    immediate_changed =False
    if has_delta :
        try :immediate_changed =_ep_sync_layer_topology_now (main_obj ,mod ,bpy .context ,edit_obj )
        except Exception :immediate_changed =False
        try :
            if immediate_changed :
                main_obj .update_tag ()
                edit_obj .update_tag ()
                if f_obj :f_obj .update_tag ()
                try :bpy .context .view_layer .update ()
                except Exception :pass
        except Exception :pass

    try :dn =bpy .app .driver_namespace
    except Exception :return bool (immediate_changed )
    item =(main_obj .name ,mod .name ,edit_obj .name )
    try :queue =list (dn .get (_EP_TOPO_SYNC_QUEUE_KEY )or [])
    except Exception :queue =[]
    if item not in queue :queue .append (item )
    try :dn [_EP_TOPO_SYNC_QUEUE_KEY ]=queue
    except Exception :pass
    try :running =bool (dn .get (_EP_TOPO_SYNC_TIMER_KEY ))
    except Exception :running =False
    if not running :
        try :
            dn [_EP_TOPO_SYNC_TIMER_KEY ]=True
            bpy .app .timers .register (_ep_topology_sync_timer ,first_interval =float (delay or 0.0 ))
        except Exception :
            try :dn [_EP_TOPO_SYNC_TIMER_KEY ]=False
            except Exception :pass
            try :_ep_topology_sync_timer ()
            except Exception :pass
    return True


_EP_TOPO_POLL_RUNNING_KEY = "_EP_TOPO_POLL_RUNNING_V1"

def _ep_live_topology_poll_timer ():
    """Poll active Edit Polygon edit meshes for topology changes.

    Some mesh edit operations do not produce a depsgraph tick quickly enough for
    the main stack to switch away from the index-difference layout before the
    viewport redraws.  This timer is only armed while Edit Polygon runtime is
    enabled and does not use bpy.ops.
    """
    try :dn =bpy .app .driver_namespace
    except Exception :return None
    try :
        api =_ep_runtime_api ()
        enabled =api .get ("edit_poly_live_enabled")
        if callable (enabled )and not bool (enabled (bpy .context )):
            dn [_EP_TOPO_POLL_RUNNING_KEY ]=False
            return None
    except TypeError :
        try :
            if callable (enabled )and not bool (enabled ()):
                dn [_EP_TOPO_POLL_RUNNING_KEY ]=False
                return None
        except Exception :pass
    except Exception :
        pass
    try :
        if getattr (bpy .context ,'mode','')=='EDIT_MESH':
            eo =getattr (bpy .context ,'edit_object',None )
            if eo and getattr (eo ,'type','')=='MESH'and eo .get ('ep_main_target'):
                try :_ep_schedule_topology_sync_for_edit_object (eo ,delay =0.0 ,reason ='edit_topology_poll')
                except Exception :pass
                return 0.05
    except Exception :
        pass
    return 0.25

def _ep_arm_live_topology_poll ():
    try :dn =bpy .app .driver_namespace
    except Exception :return False
    try :
        if bool (dn .get (_EP_TOPO_POLL_RUNNING_KEY )):
            return True
    except Exception :pass
    try :dn [_EP_TOPO_POLL_RUNNING_KEY ]=True
    except Exception :pass
    try :
        bpy .app .timers .register (_ep_live_topology_poll_timer ,first_interval =0.05 )
        return True
    except Exception :
        try :dn [_EP_TOPO_POLL_RUNNING_KEY ]=False
        except Exception :pass
        return False

def _ep_disarm_live_topology_poll ():
    try :bpy .app .driver_namespace [_EP_TOPO_POLL_RUNNING_KEY ]=False
    except Exception :pass


_EP_NG_TEMPLATE_NAME =f"EP_NodeGroup_Template_v{EP_NG_VERSION }"

_EP_NG_TEMPLATE_DN_KEY ="_EP_NG_TEMPLATE_REALNAME_V1"
_EP_NG_GC_QUEUE =set ()
_EP_NG_GC_RUNNING =False 


def _ep_ng_gc_timer ():
    global _EP_NG_GC_RUNNING 
    try :
        names =list (_EP_NG_GC_QUEUE )
        _EP_NG_GC_QUEUE .clear ()
        for nm in names :
            try :
                ng =bpy .data .node_groups .get (str (nm ))
            except Exception :
                ng =None 
            if not ng :
                continue 
            try :
                if getattr (ng ,"users",0 )==0 :
                # NOTE: disabled runtime node group removal for stability
                #bpy.data.node_groups.remove(ng)
                    pass 
            except Exception :
                pass 
    finally :
        _EP_NG_GC_RUNNING =False 
    return None 


def _ep_schedule_ng_gc (name_or_ng ):
    """Defer node-group removal to avoid depsgraph-time crashes."""
    global _EP_NG_GC_RUNNING 
    nm =""
    try :
        nm =name_or_ng .name if hasattr (name_or_ng ,"name")else str (name_or_ng or "")
    except Exception :
        nm =""
    if not nm :
        return 
    try :
        _EP_NG_GC_QUEUE .add (nm )
    except Exception :
        return 
    if _EP_NG_GC_RUNNING :
        return 
    _EP_NG_GC_RUNNING =True 
    try :
        bpy .app .timers .register (_ep_ng_gc_timer ,first_interval =0.1 )
    except Exception :
        _EP_NG_GC_RUNNING =False 


def _ep_get_or_create_ng_template ():
# Fast path: driver_namespace cached template name (avoids name-collision edge cases)
    try :
        dn =bpy .app .driver_namespace 
        cached =dn .get (_EP_NG_TEMPLATE_DN_KEY )
        if cached :
            ng =bpy .data .node_groups .get (str (cached ))
            if ng and bool (ng .get ("ep_is_template"))and int (ng .get ("ep_ng_version",0 )or 0 )>=EP_NG_VERSION :
                return ng 
    except Exception :
        pass 

        # Standard lookup by expected name
    try :
        ng =bpy .data .node_groups .get (_EP_NG_TEMPLATE_NAME )
        if ng and bool (ng .get ("ep_is_template"))and int (ng .get ("ep_ng_version",0 )or 0 )>=EP_NG_VERSION :
            try :bpy .app .driver_namespace [_EP_NG_TEMPLATE_DN_KEY ]=ng .name 
            except Exception :pass 
            return ng 
    except Exception :
        ng =None 

        # IMPORTANT:
        # Never remove a node group here. Removing a node group that is still referenced can crash Blender
        # during depsgraph rebuild (EXCEPTION_ACCESS_VIOLATION). Instead, rename conflicts away.
    try :
        old =bpy .data .node_groups .get (_EP_NG_TEMPLATE_NAME )
        if old :
            need_rename =True 
            try :
                if bool (old .get ("ep_is_template"))and int (old .get ("ep_ng_version",0 )or 0 )>=EP_NG_VERSION :
                    need_rename =False 
            except Exception :
                need_rename =True 
            if need_rename :
                try :
                    base =_EP_NG_TEMPLATE_NAME +"_LEGACY"
                    new_name =base 
                    i =1 
                    while bpy .data .node_groups .get (new_name )is not None :
                        new_name =f"{base }_{i :03d}"
                        i +=1 
                    old .name =new_name 
                    try :old ["ep_template_renamed_from"]=_EP_NG_TEMPLATE_NAME 
                    except Exception :pass 
                except Exception :
                    pass 
    except Exception :
        pass 

        # Create a fresh template (Blender may auto-rename if name is still taken; handle via dn cache)
    ng =bpy .data .node_groups .new (name =_EP_NG_TEMPLATE_NAME ,type ='GeometryNodeTree')
    try :
        ng ["ep_ng_version"]=EP_NG_VERSION 
        ng ["ep_is_template"]=True 
    except Exception :
        pass 

    try :
        inputs =[s .name for s in ng .interface .items_tree if getattr (s ,"in_out","")=='INPUT']
        outputs =[s .name for s in ng .interface .items_tree if getattr (s ,"in_out","")=='OUTPUT']
        if "Geometry"not in inputs :
            ng .interface .new_socket (name ="Geometry",in_out ='INPUT',socket_type ='NodeSocketGeometry')
        if "Geometry"not in outputs :
            ng .interface .new_socket (name ="Geometry",in_out ='OUTPUT',socket_type ='NodeSocketGeometry')
    except Exception :
        pass 

    nodes ,links =ng .nodes ,ng .links 
    try :
        nodes .clear ()
        links .clear ()
    except Exception :
        pass 

    group_in =nodes .new ('NodeGroupInput')
    group_out =nodes .new ('NodeGroupOutput')

    info_edit =nodes .new ('GeometryNodeObjectInfo')
    info_edit .name ="EP_INFO_EDIT"
    try :info_edit .transform_space ='ORIGINAL'
    except Exception :pass 

    info_froz =nodes .new ('GeometryNodeObjectInfo')
    info_froz .name ="EP_INFO_FROZ"
    try :info_froz .transform_space ='ORIGINAL'
    except Exception :pass 

    pos_node =nodes .new ('GeometryNodeInputPosition')
    idx_node =nodes .new ('GeometryNodeInputIndex')

    sample_f =nodes .new ('GeometryNodeSampleIndex')
    sample_f .data_type ='FLOAT_VECTOR'
    _safe_link (links ,_sock (info_froz .outputs ,"Geometry",fallback_index =0 ),_sock (sample_f .inputs ,"Geometry",fallback_index =0 ))
    _safe_link (links ,_sock (pos_node .outputs ,"Position",fallback_index =0 ),_sock (sample_f .inputs ,"Value",fallback_index =1 ))
    _safe_link (links ,_sock (idx_node .outputs ,"Index",fallback_index =0 ),_sock (sample_f .inputs ,"Index",fallback_index =2 ))

    sample_e =nodes .new ('GeometryNodeSampleIndex')
    sample_e .data_type ='FLOAT_VECTOR'
    _safe_link (links ,_sock (info_edit .outputs ,"Geometry",fallback_index =0 ),_sock (sample_e .inputs ,"Geometry",fallback_index =0 ))
    _safe_link (links ,_sock (pos_node .outputs ,"Position",fallback_index =0 ),_sock (sample_e .inputs ,"Value",fallback_index =1 ))
    _safe_link (links ,_sock (idx_node .outputs ,"Index",fallback_index =0 ),_sock (sample_e .inputs ,"Index",fallback_index =2 ))

    sub =nodes .new ('ShaderNodeVectorMath')
    sub .operation ='SUBTRACT'
    _safe_link (links ,_sock (sample_e .outputs ,"Value",fallback_index =0 ),sub .inputs [0 ])
    _safe_link (links ,_sock (sample_f .outputs ,"Value",fallback_index =0 ),sub .inputs [1 ])

    set_pos =nodes .new ('GeometryNodeSetPosition')
    _safe_link (links ,_sock (group_in .outputs ,"Geometry",fallback_index =0 ),_sock (set_pos .inputs ,"Geometry",fallback_index =0 ))
    _safe_link (links ,sub .outputs [0 ],_sock (set_pos .inputs ,"Offset",fallback_index =3 ))
    _safe_link (links ,_sock (set_pos .outputs ,"Geometry",fallback_index =0 ),_sock (group_out .inputs ,"Geometry",fallback_index =0 ))

    try :ng ["ep_ng_version"]=EP_NG_VERSION 
    except Exception :pass 

    try :bpy .app .driver_namespace [_EP_NG_TEMPLATE_DN_KEY ]=ng .name 
    except Exception :pass 
    return ng 

def _ep_create_node_group_for_layer (main_obj ,mod_name ,edit_obj ,frozen_obj ):
    if not main_obj or not mod_name or not edit_obj or not frozen_obj :return None 
    try :
        tpl =_ep_get_or_create_ng_template ()
        ng =tpl .copy ()if tpl else None 
    except Exception :ng =None 

    if not ng :
        try :
            ng_name =_ep_unique_node_group_name (main_obj ,mod_name )
            ng =bpy .data .node_groups .new (name =ng_name ,type ='GeometryNodeTree')
        except Exception :return None 

    try :ng .name =_ep_unique_node_group_name (main_obj ,mod_name )
    except Exception :pass 

    try :
        ng ["ep_edit_mesh"]=edit_obj .name 
        ng ["ep_frozen_mesh"]=frozen_obj .name 
        ng ["ep_ng_version"]=EP_NG_VERSION 
        ng ["ep_topology_mode"]=False 
    except Exception :pass 

    try :
        n_edit =ng .nodes .get ("EP_INFO_EDIT")
        if n_edit and n_edit .inputs and len (n_edit .inputs )>0 :
            n_edit .inputs [0 ].default_value =edit_obj 
            try :n_edit .transform_space ='ORIGINAL'
            except Exception :pass 
    except Exception :pass 
    try :
        n_froz =ng .nodes .get ("EP_INFO_FROZ")
        if n_froz and n_froz .inputs and len (n_froz .inputs )>0 :
            n_froz .inputs [0 ].default_value =frozen_obj 
            try :n_froz .transform_space ='ORIGINAL'
            except Exception :pass 
    except Exception :pass 

    return ng 

def _ep_release_ng_template ():
# Defer template cleanup to avoid depsgraph-time crashes.
    try :
        dn =bpy .app .driver_namespace 
        nm =dn .get (_EP_NG_TEMPLATE_DN_KEY )or _EP_NG_TEMPLATE_NAME 
    except Exception :
        nm =_EP_NG_TEMPLATE_NAME 

    try :
        ng =bpy .data .node_groups .get (str (nm ))if nm else None 
    except Exception :
        ng =None 

    try :
        if ng and bool (ng .get ("ep_is_template"))and int (ng .get ("ep_ng_version",0 )or 0 )>=EP_NG_VERSION :
            if getattr (ng ,"users",0 )==0 :
                _ep_schedule_ng_gc (ng )
    except Exception :
        pass 

def ensure_ep_node_group_layout (ep_mod ):
    if not ep_mod or ep_mod .type !='NODES'or not ep_mod .node_group :return 
    ng =ep_mod .node_group 
    en ,fn =ng .get ('ep_edit_mesh'),ng .get ('ep_frozen_mesh')
    edit_obj =bpy .data .objects .get (en )if en else None 
    frozen_obj =bpy .data .objects .get (fn )if fn else None 

    if edit_obj :edit_obj .hide_viewport =False 
    if frozen_obj :frozen_obj .hide_viewport =False 
    if not edit_obj or not frozen_obj :return 

    try :desired_topology =_ep_layer_has_topology_delta (edit_obj ,frozen_obj )
    except Exception :desired_topology =False 
    try :cur_topology =bool (ng .get ('ep_topology_mode',False ))
    except Exception :cur_topology =False 
    try :ver =int (ng .get ('ep_ng_version',0 )or 0 )
    except Exception :ver =0 

    if ver >=EP_NG_VERSION and cur_topology ==desired_topology :
        try :_ep_patch_node_group_refs (ep_mod ,edit_obj ,frozen_obj )
        except Exception :pass 
        return 

    _ep_rebuild_node_group_layout (ng ,edit_obj ,frozen_obj ,topology_mode =desired_topology )

def get_current_mode ():
    mode =bpy .context .mode 
    return 'EDIT'if mode in ('EDIT_MESH','EDIT_CURVE','EDIT_SURFACE','EDIT_TEXT','EDIT_ARMATURE','EDIT_METABALL','EDIT_LATTICE')else mode 

def safe_remove_mesh (mesh ):
    """No-op: avoid removing Mesh datablocks at runtime (stability)."""
    return 

def _ep_sync_ref_object_transform (main_obj ,ref_obj ):
    if not main_obj or not ref_obj :return 
    try :
        if ref_obj .parent !=main_obj :ref_obj .parent =main_obj 
        try :ref_obj .matrix_parent_inverse =Matrix .Identity (4 )
        except :pass 
        try :ref_obj .matrix_basis =Matrix .Identity (4 )
        except :
            ref_obj .location ,ref_obj .rotation_euler ,ref_obj .scale =(0.0 ,0.0 ,0.0 ),(0.0 ,0.0 ,0.0 ),(1.0 ,1.0 ,1.0 )
    except :
        try :
            ref_obj .parent =None 
            ref_obj .matrix_world =main_obj .matrix_world .copy ()
        except :pass 

def get_main_object (obj ):
    """Resolve helper/preview objects back to the real 'main' mesh object.
    - EP helpers: obj['ep_main_target']
    - MS end-result preview: obj['ms_end_preview_main'] (preferred)
      Fallback: object name endswith '_MS_EndPreview' -> try strip suffix.
    """
    if obj is None :
        return None 

        # EP helper objects
    try :
        if "ep_main_target"in obj :
            main_name =obj .get ("ep_main_target")
            if main_name and main_name in bpy .data .objects :
                return bpy .data .objects [main_name ]
    except Exception :
        pass 

        # Smart Modifier end-result preview objects
    try :
        main_name =obj .get ("ms_end_preview_main")if getattr (obj ,"get",None )else None 
        if main_name and main_name in bpy .data .objects :
            return bpy .data .objects [main_name ]
    except Exception :
        pass 

        # Fallback by naming convention (kept conservative)
    try :
        n =getattr (obj ,"name","")or ""
        suf ="_MS_EndPreview"
        if n .endswith (suf ):
            base =n [:-len (suf )]
            if base and base in bpy .data .objects :
                return bpy .data .objects [base ]
    except Exception :
        pass 

    return obj 
def get_ep_mesh_names (mod ):
    if hasattr (mod ,"node_group")and mod .node_group :
        return mod .node_group .get ("ep_edit_mesh"),mod .node_group .get ("ep_frozen_mesh")
    return None ,None 

def _ep_is_ep_node_group (ng ):
    try :
        return bool (ng and (ng .get ('ep_edit_mesh')or ng .get ('ep_frozen_mesh')or ng .get ('ep_ng_version')is not None ))
    except Exception :return False 

def _ep_patch_node_group_refs (mod ,edit_obj ,frozen_obj ):
    if not mod or getattr (mod ,'type','')!='NODES':return 
    ng =getattr (mod ,'node_group',None )
    if not ng :return 
    try :
        if edit_obj :ng ['ep_edit_mesh']=edit_obj .name 
        if frozen_obj :ng ['ep_frozen_mesh']=frozen_obj .name 
    except Exception :pass 
    try :
        n_edit =ng .nodes .get ('EP_INFO_EDIT')if hasattr (ng ,'nodes')else None 
        if n_edit and getattr (n_edit ,'inputs',None )and len (n_edit .inputs )>0 and edit_obj :
            n_edit .inputs [0 ].default_value =edit_obj 
            try :n_edit .transform_space ='ORIGINAL'
            except Exception :pass 
    except Exception :pass 
    try :
        n_froz =ng .nodes .get ('EP_INFO_FROZ')if hasattr (ng ,'nodes')else None 
        if n_froz and getattr (n_froz ,'inputs',None )and len (n_froz .inputs )>0 and frozen_obj :
            n_froz .inputs [0 ].default_value =frozen_obj 
            try :n_froz .transform_space ='ORIGINAL'
            except Exception :pass 
    except Exception :pass 

def _ep_ensure_unique_layer_assets (main_obj ,mod ,context =None ):
    if not main_obj or not mod or not is_ep_layer (mod ):return 
    if getattr (mod ,'type','')!='NODES':return 
    ng =getattr (mod ,'node_group',None )
    if ng and _ep_is_ep_node_group (ng ):
        try :
            if getattr (ng ,'users',1 )>1 :
                ng2 =ng .copy ()
                try :ng2 .name =_ep_unique_node_group_name (main_obj ,mod .name )+'_U'
                except Exception :pass 
                mod .node_group =ng2 
                ng =ng2 
        except Exception :pass 

    en ,fn =get_ep_mesh_names (mod )
    e_obj =bpy .data .objects .get (en )if en else None 
    f_obj =bpy .data .objects .get (fn )if fn else None 

    ep_col =None 
    try :
        _keep_now =_ep_active_edit_helper_keep_names (context )
        if _ep_is_force_edit_target_requested (main_obj ,mod .name )or (en and en in _keep_now )or (fn and fn in _keep_now ):
            ep_col =modsys_get_ep_collection (scene =(getattr (context ,'scene',None )if context else bpy .context .scene ))
    except Exception :ep_col =None 

    def _clone_helper (src_obj ,kind ):
        if not src_obj or not getattr (src_obj ,'data',None ):return None 
        suf =_ep_suffix_from_mod_name (mod .name )
        base_name =f"{main_obj .name }_{'Edit'if kind =='edit'else 'Frozen'}_{suf }"
        new_name =base_name 
        if bpy .data .objects .get (new_name ):
            new_name =f"{base_name }_{uuid .uuid4 ().hex [:6 ]}"
        try :new_data =src_obj .data .copy ()
        except Exception :return None 
        try :new_obj =bpy .data .objects .new (new_name ,new_data )
        except Exception :
            try :
                src_obj .data =new_data 
                return src_obj 
            except Exception :return None 
        try :new_obj ['ep_main_target']=main_obj .name 
        except Exception :pass 
        try :
            if ep_col :modsys_link_object (new_obj ,ep_col )
            else :bpy .context .scene .collection .objects .link (new_obj )
        except Exception :pass 
        try :new_obj .hide_set (True );new_obj .hide_select =True ;new_obj .hide_viewport =False 
        except Exception :pass 
        try :_ep_sync_ref_object_transform (main_obj ,new_obj )
        except Exception :pass 
        return new_obj 

    try :
        if e_obj and str (e_obj .get ('ep_main_target','')or '')!=main_obj .name :
            e_obj =_clone_helper (e_obj ,'edit')or e_obj 
    except Exception :pass 
    try :
        if f_obj and str (f_obj .get ('ep_main_target','')or '')!=main_obj .name :
            f_obj =_clone_helper (f_obj ,'frozen')or f_obj 
    except Exception :pass 

    try :
        if e_obj and getattr (e_obj ,'data',None )and getattr (e_obj .data ,'users',1 )>1 :
            e_obj .data =e_obj .data .copy ()
    except Exception :pass 
    try :
        if f_obj and getattr (f_obj ,'data',None )and getattr (f_obj .data ,'users',1 )>1 :
            f_obj .data =f_obj .data .copy ()
    except Exception :pass 

    try :
        if e_obj :e_obj ['ep_main_target']=main_obj .name 
        if f_obj :f_obj ['ep_main_target']=main_obj .name 
    except Exception :pass 

    try :_ep_patch_node_group_refs (mod ,e_obj ,f_obj )
    except Exception :pass 

def _ms_capture_edit_mesh_selection (context ):
    try :
        ctx =context or bpy .context 
        if getattr (ctx ,"mode","")!='EDIT_MESH':
            return None 
        ao =getattr (ctx ,"edit_object",None )or ctx .view_layer .objects .active 
        if not ao or ao .type !='MESH'or not getattr (ao ,"data",None ):
            return None 

        me =ao .data 
        try :
            tv =int (getattr (me ,"total_vert_sel",0 )or 0 )
            te =int (getattr (me ,"total_edge_sel",0 )or 0 )
            tf =int (getattr (me ,"total_face_sel",0 )or 0 )
        except Exception :
            tv =te =tf =-1 

        bm =bmesh .from_edit_mesh (me )

        # Prefer select_history (fast) but accept ONLY when it matches totals (accuracy)
        try :
            hist =list (getattr (bm ,"select_history",[])or [])
        except Exception :
            hist =[]
        if hist :
            vs ,es ,fs =set (),set (),set ()
            for elem in hist :
                try :
                    if not getattr (elem ,"select",False ):
                        continue 
                    tn =elem .__class__ .__name__ 
                    if tn =="BMVert":
                        vs .add (int (elem .index ))
                    elif tn =="BMEdge":
                        es .add (int (elem .index ))
                    elif tn =="BMFace":
                        fs .add (int (elem .index ))
                except Exception :
                    continue 

            if (tv >=0 and te >=0 and tf >=0 ):
                if len (vs )==tv and len (es )==te and len (fs )==tf :
                    return {"v":sorted (vs ),"e":sorted (es ),"f":sorted (fs )}
            else :
                if vs or es or fs :
                    return {"v":sorted (vs ),"e":sorted (es ),"f":sorted (fs )}

                    # Fallback full scan (accurate)
        try :
            bm .verts .ensure_lookup_table ()
            bm .edges .ensure_lookup_table ()
            bm .faces .ensure_lookup_table ()
        except Exception :
            pass 
        return {
        "v":[v .index for v in bm .verts if v .select ],
        "e":[e .index for e in bm .edges if e .select ],
        "f":[f .index for f in bm .faces if f .select ],
        }
    except Exception :
        return None 

def _ms_apply_edit_mesh_selection (obj ,sel ):
    if not obj or obj .type !='MESH'or not sel :return 
    try :
        if bpy .context .mode !='EDIT_MESH':return 
        me =getattr (obj ,"data",None )
        if not me :return 
        bm =bmesh .from_edit_mesh (me )
        bm .verts .ensure_lookup_table ()
        bm .edges .ensure_lookup_table ()
        bm .faces .ensure_lookup_table ()
        for v in bm .verts :v .select =False 
        for e in bm .edges :e .select =False 
        for f in bm .faces :f .select =False 
        for i in (sel .get ("v",[])or []):
            try :
                if 0 <=int (i )<len (bm .verts ):bm .verts [int (i )].select =True 
            except :pass 
        for i in (sel .get ("e",[])or []):
            try :
                if 0 <=int (i )<len (bm .edges ):bm .edges [int (i )].select =True 
            except :pass 
        for i in (sel .get ("f",[])or []):
            try :
                if 0 <=int (i )<len (bm .faces ):bm .faces [int (i )].select =True 
            except :pass 
        bmesh .update_edit_mesh (me ,loop_triangles =False ,destructive =False )
    except :pass 

def _ep_throttle_ok (key ="_EP_SEL_CAP_T",interval =0.16 ):
    try :
        ns =bpy .app .driver_namespace 
        now =time .time ()
        last =float (ns .get (key ,0.0 )or 0.0 )
        if now -last <interval :return False 
        ns [key ]=now 
        return True 
    except Exception :return True 

def _ep_capture_current_edit_selection_to_cache (context =None ):
    try :
        ctx =context or bpy .context 
        if getattr (ctx ,"mode","")!='EDIT_MESH':return 
        eo =getattr (ctx ,"edit_object",None )
        if not eo or eo .type !='MESH':return 
        main_obj =get_main_object (eo )
        if not main_obj or main_obj .type !='MESH':return 

        carrier_key ="BASE"
        try :
        # Cache carrier key on the edit object to avoid scanning modifiers on every selection tick
            ck =eo .get ("_ep_carrier_key","")
            if ck and ck =="BASE":
                carrier_key ="BASE"
            elif ck and main_obj .modifiers .get (ck )is not None :
                carrier_key =ck 
            else :
            # Resolve carrier key once
                if eo !=main_obj and "ep_main_target"in eo :
                    for m in main_obj .modifiers :
                        if is_ep_layer (m ):
                            en ,_fn =get_ep_mesh_names (m )
                            if en ==eo .name :
                                carrier_key =m .name 
                                break 
                else :
                    carrier_key ="BASE"
                try :
                    eo ["_ep_carrier_key"]=carrier_key 
                except Exception :
                    pass 
        except Exception :
            carrier_key ="BASE"

            # Fast path (fixed): countsだけだと"同数の別頂点"変化を拾えないので、
            # select_history.active の型/インデックスも含めたシグネチャで判定する。
        try :
            me =eo .data 
            tv =int (getattr (me ,'total_vert_sel',0 )or 0 )
            te =int (getattr (me ,'total_edge_sel',0 )or 0 )
            tf =int (getattr (me ,'total_face_sel',0 )or 0 )

            act_t =""
            act_i =-1 
            try :
                bm =bmesh .from_edit_mesh (me )
                act =getattr (getattr (bm ,"select_history",None ),"active",None )
                if act is not None and getattr (act ,"select",False ):
                    act_t =act .__class__ .__name__ 
                    act_i =int (getattr (act ,"index",-1 ))
            except Exception :
                pass 

            sig =(tv ,te ,tf ,act_t ,act_i )
            last_sig =eo .get ('_ep_last_sel_sig',None )
            if last_sig ==list (sig )or last_sig ==tuple (sig ):
                try :_ep_update_helper_topology_state (eo ,ctx ,force =False )
                except Exception :pass 
                return 
            eo ['_ep_last_sel_sig']=list (sig )
        except Exception :
            pass 
        sel =_ms_capture_edit_mesh_selection (ctx )
        if sel :ms_sel_set (main_obj ,carrier_key ,sel )
        try :
            if carrier_key and carrier_key !='BASE':
                mtop =main_obj .modifiers .get (carrier_key )
                if mtop and is_ep_layer (mtop ):
                    _ep_update_helper_topology_state (eo ,ctx ,force =False )
        except Exception :pass 
        try :
            if _ep_throttle_ok (key ="_MODSYS_CLEANUP_T",interval =1.0 ):
                modsys_request_cleanup (delay =0.1 )
        except Exception :pass 
    except Exception :pass 

def set_edit_object_modifier_visibility (edit_obj ,show_end ):
    if not edit_obj :return 
    for m in edit_obj .modifiers :
        try :m .show_viewport =bool (show_end )
        except :pass 

def _ep_compute_displacement_on_frozen (frozen_mesh ,edit_mesh ):
    if not frozen_mesh or not edit_mesh :return ([],0 )

    f_len =len (frozen_mesh .vertices )
    e_len =len (edit_mesh .vertices )
    n =min (f_len ,e_len )
    if n <=0 :return ([],0 )

    if np is not None :
        f_arr =np .empty (f_len *3 ,dtype =np .float32 )
        e_arr =np .empty (e_len *3 ,dtype =np .float32 )
        frozen_mesh .vertices .foreach_get ("co",f_arr )
        edit_mesh .vertices .foreach_get ("co",e_arr )
        disp =e_arr [:n *3 ]-f_arr [:n *3 ]
        return (disp ,n )

    f =array ('f',[0.0 ])*(f_len *3 )
    e =array ('f',[0.0 ])*(e_len *3 )
    frozen_mesh .vertices .foreach_get ("co",f )
    edit_mesh .vertices .foreach_get ("co",e )
    disp =array ('f',[0.0 ])*(n *3 )
    for i in range (n *3 ):disp [i ]=e [i ]-f [i ]
    return (disp ,n )

def _ep_apply_displacement_to_new_base (new_mesh ,old_frozen_mesh ,frozen_disp ):
    if not new_mesh or not frozen_disp :return 
    try :disp ,n =frozen_disp 
    except Exception :return 
    if disp is None or n <=0 :return 

    m_len =len (new_mesh .vertices )
    nn =min (m_len ,int (n ))

    if np is not None and isinstance (disp ,np .ndarray ):
        coords =np .empty (m_len *3 ,dtype =np .float32 )
        new_mesh .vertices .foreach_get ("co",coords )
        coords [:nn *3 ]+=disp [:nn *3 ]
        new_mesh .vertices .foreach_set ("co",coords )
        return 

    if hasattr (disp ,"typecode")and getattr (disp ,"typecode","")=='f':
        coords =array ('f',[0.0 ])*(m_len *3 )
        new_mesh .vertices .foreach_get ("co",coords )
        lim =min (len (coords ),len (disp ),nn *3 )
        for i in range (lim ):coords [i ]+=disp [i ]
        new_mesh .vertices .foreach_set ("co",coords )
        return 

    for i in range (min (nn ,len (disp ))):
        new_mesh .vertices [i ].co +=disp [i ]

def rebake_edit_polys_from_index (main_obj ,context ,start_index =0 ):
    if not main_obj :return 
    if context is None :context =bpy .context 
    prev_mode =get_current_mode ()
    if prev_mode !='OBJECT':
        try :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
        except Exception :pass 

    vl =context .view_layer 
    prev_active =vl .objects .active 
    mods_list =list (main_obj .modifiers )
    nmods =len (mods_list )
    try :si =int (start_index or 0 )
    except Exception :si =0 
    if si <0 :si =0 
    try :
        if not any (is_ep_layer (m )for m in mods_list [si :]):
            if prev_mode !='OBJECT':
                try :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode =prev_mode )
                except Exception :pass 
            return 
    except Exception :pass 
    orig_viewport =[bool (getattr (m ,'show_viewport',True ))for m in mods_list ]
    enabled_map =_ms_enabled_map (main_obj )
    enabled =[bool (enabled_map .get (m .name ,True ))for m in mods_list ]

    cur_cut =None 

    def _set_cut_full (cut ):
        changed =False 
        for i ,mod2 in enumerate (mods_list ):
            want =(i <cut )and enabled [i ]
            try :
                if bool (getattr (mod2 ,'show_viewport',True ))!=want :
                    mod2 .show_viewport =want 
                    changed =True 
            except Exception :pass 
        return changed 

    def _advance_cut (prev_cut ,new_cut ):
        changed =False 
        for i in range (prev_cut ,new_cut ):
            if i <0 or i >=nmods :continue 
            want =bool (enabled [i ])
            try :
                mod2 =mods_list [i ]
                if bool (getattr (mod2 ,'show_viewport',True ))!=want :
                    mod2 .show_viewport =want 
                    changed =True 
            except Exception :pass 
        return changed 

    for idx ,m in enumerate (mods_list ):
        if idx <int (start_index or 0 ):continue 
        if not is_ep_layer (m ):continue 

        try :ensure_ep_node_group_layout (m )
        except Exception :pass 

        en ,fn =get_ep_mesh_names (m )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 

        try :
            _keep_now =_ep_active_edit_helper_keep_names (context )
            if _ep_is_force_edit_target_requested (main_obj ,m .name )or (en and en in _keep_now )or (fn and fn in _keep_now ):
                _ep_col =modsys_get_ep_collection (scene =context .scene )
                if e_obj :modsys_link_object (e_obj ,_ep_col )
                if f_obj :modsys_link_object (f_obj ,_ep_col )
        except Exception :pass 

        if (not e_obj )or (not f_obj )or (not getattr (e_obj ,"data",None ))or (not getattr (f_obj ,"data",None )):
            continue 

        try :
            _ep_sync_ref_object_transform (main_obj ,e_obj )
            _ep_sync_ref_object_transform (main_obj ,f_obj )
        except Exception :pass 

        old_edit_mesh =e_obj .data 
        old_frozen_mesh =f_obj .data 

        topology_mode =False 
        try :topology_mode =_ep_layer_has_topology_delta (e_obj ,f_obj )
        except Exception :topology_mode =False 
        try :_ep_update_topology_mode_for_mod (main_obj ,m ,context ,edit_obj_override =e_obj )
        except Exception :pass 

        frozen_disp =([],0 )
        if not topology_mode :
            try :frozen_disp =_ep_compute_displacement_on_frozen (old_frozen_mesh ,old_edit_mesh )
            except Exception :frozen_disp =([],0 )

        target_idx =idx 
        changed =False 
        if cur_cut is None :
            cur_cut =target_idx 
            changed =_set_cut_full (cur_cut )
        elif target_idx >cur_cut :
            changed =_advance_cut (cur_cut ,target_idx )
            cur_cut =target_idx 
        else :
            cur_cut =target_idx 
            changed =_set_cut_full (cur_cut )

        if changed :
            try :context .view_layer .update ()
            except Exception :pass 

        eval_obj =None 
        try :
            dg_local =context .evaluated_depsgraph_get ()
            eval_obj =main_obj .evaluated_get (dg_local )
            eval_mesh =eval_obj .to_mesh (preserve_all_data_layers =True ,depsgraph =dg_local )
        except Exception :eval_mesh =None 

        if not eval_mesh :
            try :
                if eval_obj :eval_obj .to_mesh_clear ()
            except Exception :pass 
            continue 

        try :
            new_base_mesh =None 
            try :
                new_base_mesh =eval_mesh .copy ()
                try :new_base_mesh .name =f"{main_obj .name }_rebake_base"
                except Exception :pass 
            except Exception :
                new_base_mesh =bpy .data .meshes .new (f"{main_obj .name }_rebake_base")
                bm =bmesh .new ()
                bm .from_mesh (eval_mesh )
                bm .to_mesh (new_base_mesh )
                bm .free ()

            if topology_mode :
                new_base_mesh .update ()
                f_obj .data =new_base_mesh 
                try :_ep_rebuild_node_group_layout (getattr (m ,'node_group',None ),e_obj ,f_obj ,topology_mode =True )
                except Exception :pass 
                safe_remove_mesh (old_frozen_mesh )
            else :
                new_edit_mesh =new_base_mesh .copy ()
                try :_ep_apply_displacement_to_new_base (new_edit_mesh ,old_frozen_mesh ,frozen_disp )
                except Exception :pass 

                new_base_mesh .update ()
                new_edit_mesh .update ()

                e_obj .data =new_edit_mesh 
                f_obj .data =new_base_mesh 
                try :_ep_rebuild_node_group_layout (getattr (m ,'node_group',None ),e_obj ,f_obj ,topology_mode =False )
                except Exception :pass 
                safe_remove_mesh (old_edit_mesh )
                safe_remove_mesh (old_frozen_mesh )
        except Exception :pass 
        finally :
            try :eval_obj .to_mesh_clear ()
            except Exception :pass 

    changed_back =False 
    for mod2 ,st in zip (mods_list ,orig_viewport ):
        try :
            if bool (getattr (mod2 ,'show_viewport',True ))!=bool (st ):
                mod2 .show_viewport =bool (st )
                changed_back =True 
        except Exception :pass 

    try :
        if prev_active and prev_active .name in bpy .data .objects :
            vl .objects .active =prev_active 
    except Exception :pass 
    if prev_mode !='OBJECT':
        try :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode =prev_mode )
        except Exception :pass 

    if changed_back :
        try :vl .update ()
        except Exception :pass 

def rebake_edit_polys_upto (main_obj ,context ,upto_mod_name =None ):
    global _ep_bypass 
    if not main_obj or main_obj .type !='MESH':return False 
    if context is None :context =bpy .context 
    if bpy .context .mode !='OBJECT':return False 
    _ep_bypass +=1 
    try :
        vl =context .view_layer 
        mods_list =list (main_obj .modifiers )
        nmods =len (mods_list )
        orig_viewport =[bool (getattr (m ,'show_viewport',True ))for m in mods_list ]
        enabled_map =_ms_enabled_map (main_obj )
        enabled =[bool (enabled_map .get (m .name ,True ))for m in mods_list ]

        cur_cut =None 
        def _set_cut_full (cut ):
            changed =False 
            for i ,mod2 in enumerate (mods_list ):
                want =(i <cut )and enabled [i ]
                try :
                    if bool (getattr (mod2 ,'show_viewport',True ))!=want :
                        mod2 .show_viewport =want 
                        changed =True 
                except Exception :pass 
            return changed 

        def _advance_cut (prev_cut ,new_cut ):
            changed =False 
            for i in range (prev_cut ,new_cut ):
                if i <0 or i >=nmods :continue 
                want =bool (enabled [i ])
                try :
                    mod2 =mods_list [i ]
                    if bool (getattr (mod2 ,'show_viewport',True ))!=want :
                        mod2 .show_viewport =want 
                        changed =True 
                except Exception :pass 
            return changed 

        for idx ,m in enumerate (mods_list ):
            if not is_ep_layer (m ):continue 
            ensure_ep_node_group_layout (m )
            en ,fn =get_ep_mesh_names (m )
            e_obj =bpy .data .objects .get (en )if en else None 
            f_obj =bpy .data .objects .get (fn )if fn else None 
            if not e_obj or not f_obj or not getattr (e_obj ,"data",None )or not getattr (f_obj ,"data",None ):
                continue 

            _ep_sync_ref_object_transform (main_obj ,e_obj )
            _ep_sync_ref_object_transform (main_obj ,f_obj )

            old_edit_mesh =e_obj .data 
            old_frozen_mesh =f_obj .data 
            topology_mode =False 
            try :topology_mode =_ep_layer_has_topology_delta (e_obj ,f_obj )
            except Exception :topology_mode =False 
            try :_ep_update_topology_mode_for_mod (main_obj ,m ,context ,edit_obj_override =e_obj )
            except Exception :pass 
            frozen_disp =([],0 )
            if not topology_mode :
                frozen_disp =_ep_compute_displacement_on_frozen (old_frozen_mesh ,old_edit_mesh )

            target_idx =idx 
            changed =False 
            if cur_cut is None :
                cur_cut =target_idx 
                changed =_set_cut_full (cur_cut )
            elif target_idx >cur_cut :
                changed =_advance_cut (cur_cut ,target_idx )
                cur_cut =target_idx 
            else :
                cur_cut =target_idx 
                changed =_set_cut_full (cur_cut )

            if changed :
                try :context .view_layer .update ()
                except Exception :pass 

            eval_obj =None 
            try :
                dg_local =context .evaluated_depsgraph_get ()
                eval_obj =main_obj .evaluated_get (dg_local )
                eval_mesh =eval_obj .to_mesh (preserve_all_data_layers =True ,depsgraph =dg_local )
            except Exception :eval_mesh =None 

            if not eval_mesh :
                try :eval_obj .to_mesh_clear ()
                except Exception :pass 
                continue 

            try :
                new_base_mesh =None 
                try :
                    new_base_mesh =eval_mesh .copy ()
                    try :new_base_mesh .name =f"{main_obj .name }_ep_base_{m .name }"
                    except Exception :pass 
                except Exception :
                    new_base_mesh =bpy .data .meshes .new (f"{main_obj .name }_ep_base_{m .name }")
                    bm =bmesh .new ()
                    bm .from_mesh (eval_mesh )
                    bm .to_mesh (new_base_mesh )
                    bm .free ()

                if topology_mode :
                    new_base_mesh .update ()
                    f_obj .data =new_base_mesh 
                    try :_ep_rebuild_node_group_layout (getattr (m ,'node_group',None ),e_obj ,f_obj ,topology_mode =True )
                    except Exception :pass 
                    safe_remove_mesh (old_frozen_mesh )
                else :
                    new_edit_mesh =new_base_mesh .copy ()
                    _ep_apply_displacement_to_new_base (new_edit_mesh ,old_frozen_mesh ,frozen_disp )

                    new_base_mesh .update ()
                    new_edit_mesh .update ()

                    e_obj .data =new_edit_mesh 
                    f_obj .data =new_base_mesh 
                    try :_ep_rebuild_node_group_layout (getattr (m ,'node_group',None ),e_obj ,f_obj ,topology_mode =False )
                    except Exception :pass 
                    safe_remove_mesh (old_edit_mesh )
                    safe_remove_mesh (old_frozen_mesh )
            finally :
                try :eval_obj .to_mesh_clear ()
                except Exception :pass 

            if upto_mod_name and m .name ==upto_mod_name :break 

        changed_back =False 
        for mod2 ,st in zip (mods_list ,orig_viewport ):
            try :
                if bool (getattr (mod2 ,'show_viewport',True ))!=bool (st ):
                    mod2 .show_viewport =bool (st )
                    changed_back =True 
            except Exception :pass 

        if changed_back :
            try :vl .update ()
            except Exception :pass 

        return True 
    finally :
        _ep_bypass -=1 

_ep_bypass =0 

def _ep_context_signature (ctx ):
    try :
        mode =str (getattr (ctx ,"mode","")or "")
        vl =getattr (ctx ,"view_layer",None )
        active_obj =getattr (getattr (vl ,"objects",None ),"active",None )
        active_name =getattr (active_obj ,"name","")if active_obj else ""
        edit_name =getattr (getattr (ctx ,"edit_object",None ),"name","")or ""
        sel_names =tuple (sorted (
        getattr (obj ,"name","")
        for obj in (getattr (ctx ,"selected_objects",[])or [])
        if getattr (obj ,"name","")
        ))
        return (mode ,active_name ,edit_name ,sel_names )
    except Exception :
        return ("","","",())


def _ep_has_pending_runtime_work ():
    try :
        dn =_ep_dn ()
        return bool (
        dn .get (_EP_OBJSEL_PIN_KEY )or
        dn .get (_EP_OBJSEL_PENDING_KEY )or
        dn .get ("_EP_PENDING_SYNC")or
        dn .get ("_EP_PENDING_TIMER")
        )
    except Exception :
        return False 


def _ep_has_relevant_depsgraph_update (ctx ,depsgraph ):
    try :
        updates =getattr (depsgraph ,"updates",None )
        if not updates :
            return False 
    except Exception :
        return False 

    try :
        vl =getattr (ctx ,"view_layer",None )
        active_obj =getattr (getattr (vl ,"objects",None ),"active",None )
    except Exception :
        active_obj =None 
    try :
        main_obj =get_main_object (active_obj )if active_obj else None 
    except Exception :
        main_obj =None 
    if main_obj is None :
        main_obj =active_obj 

    try :
        active_data =getattr (active_obj ,"data",None )if active_obj else None 
    except Exception :
        active_data =None 
    try :
        main_data =getattr (main_obj ,"data",None )if main_obj else None 
    except Exception :
        main_data =None 

    for update in updates :
        try :candidate =update .id 
        except Exception :candidate =None 
        if candidate is active_obj or candidate is active_data or candidate is main_obj or candidate is main_data :
            return True 
        try :
            if isinstance (candidate ,bpy .types .Object )and _ep_is_helper_obj (candidate ):
                if main_obj is None or get_main_object (candidate )==main_obj :
                    return True 
        except Exception :
            pass 
    return False 

@bpy .app .handlers .persistent 
def ep_selection_handler (scene ,depsgraph ):
    """Lightweight depsgraph handler.
    - In EDIT_MESH: throttled capture of edit selection.
    - On EDIT_MESH -> OBJECT transition: schedule object-selection restore (prevents empty/single selection).
    - In OBJECT with helper active: schedule restore and then run the existing pending-sync logic.
    NOTE: Never call bpy.ops here. Use timers.
    """
    global _ep_bypass 

    try :
        _rt =_ep_runtime_api ()
        _fn =_rt .get ("edit_poly_live_enabled")
        if callable (_fn )and not bool (_fn ()):
            return 
    except Exception :
        pass 

        # Even during bypass/locks, we still track mode transitions & can schedule a restore.
    try :
        dn =bpy .app .driver_namespace 
        active =dn .get ("_EP_ACTIVE_MODULE")
        if active is not None and active !=EP_ADDON_ID :
            return 
    except Exception :
        return 

    try :
        _ms_dn =bpy .app .driver_namespace 
        ms_lock =bool (_ms_dn .get ("_MS_MODIFIER_STACK_SYNC_LOCK"))
        # Smart Modifier intentionally passes through transient OBJECT windows while
        # switching stack levels. EP must not treat those windows as a real
        # edit-exit/object-mode restore trigger, or the two addons can fight and
        # cause persistent OBJECT/EDIT flicker.
        ms_transition =bool (_ms_dn .get ("_MS_TRANSITION_ACTIVE_V1"))or bool (_ms_dn .get ("_MS_ALLOW_MODESET_V1"))
    except Exception :
        ms_lock =False 
        ms_transition =False 

        # Track mode transitions (EDIT_MESH -> OBJECT) regardless of locks.
    try :
        cur_mode =getattr (bpy .context ,"mode","")
        last_mode =bpy .app .driver_namespace .get (_EP_LAST_MODE_KEY )
        if last_mode =='OBJECT'and cur_mode =='EDIT_MESH':
        # Entering edit: pin the current object selection snapshot so EP helper switching cannot
        # overwrite it with helper-only selection.
            try :
                _ep_objsel_capture_names_only (bpy .context ,pin =True ,reason ="enter_edit_detected")
            except Exception :
                pass 
        if last_mode =='EDIT_MESH'and cur_mode =='OBJECT':
            try :
                _last_ep_helper =bpy .app .driver_namespace .get (_EP_LAST_EDIT_HELPER_DN_KEY ,'')
                if _last_ep_helper :
                    _ep_update_helper_topology_state_by_name (_last_ep_helper ,bpy .context ,force =True )
            except Exception :
                pass 
        # Leaving edit: only restore for a real user/object-mode exit.
        # Ignore transient OBJECT windows created by Smart Modifier while it
        # deterministically switches the active edit target.
            if not ms_transition :
                _ep_objsel_schedule_restore (delay =0.0 ,reason ="leave_edit_detected",force =True )
                try :
                    _ep_schedule_touched_restore (delay =0.0 ,reason ='leave_edit_detected')
                except Exception :
                    pass 
                try :
                    eo_leave =getattr (bpy .context ,'edit_object',None )or getattr (bpy .context ,'object',None )
                    if eo_leave and getattr (eo_leave ,'type','')=='MESH'and eo_leave .get ('ep_main_target'):
                        _ep_schedule_topology_sync_for_edit_object (eo_leave ,delay =0.0 ,reason ='leave_edit_detected')
                except Exception :
                    pass 
                try :modsys_request_cleanup (delay =0.1 )
                except Exception :pass 
        bpy .app .driver_namespace [_EP_LAST_MODE_KEY ]=cur_mode 
    except Exception :
        pass 

        # If we're inside EP operations, or Smart Modifier is in a controlled
        # transition, skip heavy OBJECT-mode restore logic for this tick.
    if _ep_bypass >0 :
        return 
    if ms_transition and getattr (bpy .context ,"mode","")=='OBJECT':
        return 

    try :
        if getattr (bpy .context ,"mode","")=='EDIT_MESH':
            try :
                bpy .app .driver_namespace [_EP_LAST_MODE_KEY ]='EDIT_MESH'
            except Exception :
                pass 
            try :_ep_update_helper_topology_state (context =bpy .context ,force =False )
            except Exception :pass 
            try :
                if _ep_throttle_ok (): _ep_capture_current_edit_selection_to_cache (bpy .context )
            except Exception :pass 
            return 
    except Exception :
        pass 

    try :
        if getattr (bpy .context ,"mode","")=='OBJECT':
            _act_ep =None 
            try :_act_ep =getattr (getattr (bpy .context ,"view_layer",None ),"objects",None ).active 
            except Exception :_act_ep =None 
            try :
                if _act_ep and getattr (_act_ep ,"type","")=='MESH'and ('ep_main_target'in _act_ep):
                    _ep_update_helper_topology_state (_act_ep ,bpy .context ,force =True )
            except Exception :pass 
    except Exception :
        pass 

    try :
        ctx =bpy .context 
        dn =_ep_dn ()
        quick_sig =_ep_context_signature (ctx )
        relevant_update =_ep_has_relevant_depsgraph_update (ctx ,depsgraph )
        if quick_sig ==dn .get ("_EP_QUICK_SIG_V1")and (not relevant_update )and (not _ep_has_pending_runtime_work ()):
            return 
        dn ["_EP_QUICK_SIG_V1"]=quick_sig 
    except Exception :
        pass 

        # In edit-mesh: capture element selection (existing behavior)
    try :
        if bpy .context .mode =='EDIT_MESH':
            try :
                bpy .app .driver_namespace [_EP_LAST_MODE_KEY ]='EDIT_MESH'
            except Exception :
                pass 
            try :
                if _ep_throttle_ok ():
                    _ep_capture_current_edit_selection_to_cache (bpy .context )
                    try :
                        eo_live =getattr (bpy .context ,'edit_object',None )
                        if eo_live and getattr (eo_live ,'type','')=='MESH'and eo_live .get ('ep_main_target'):
                            _ep_schedule_topology_sync_for_edit_object (eo_live ,delay =0.0 ,reason ='edit_mesh_live')
                    except Exception :
                        pass 
            except Exception :
                pass 
            return 
    except Exception :
        pass 

        # Only proceed in OBJECT mode below
    try :
        if bpy .context .mode !='OBJECT':
            return 
    except Exception :
        return 


        # If user deselects right after EP editing, the main object can remain in WIRE/BOUNDS.
        # Restore touched main display states in OBJECT mode (debounced).
    try :
        sel_now =list (getattr (bpy .context ,"selected_objects",[])or [])
        act_now =None 
        try :
            act_now =bpy .context .view_layer .objects .active 
        except Exception :
            act_now =None 
        if (not sel_now )and (act_now is None ):
            _ep_schedule_touched_restore (delay =0.0 ,reason ="deselect_all_object_mode")
    except Exception :
        pass 

        # If selection collapses to empty right after EP operation (rare timing window),
        # restore from the pinned snapshot (does not interfere with user intent because it's time-gated).
    try :
        dn =bpy .app .driver_namespace 
        names ,_a =_ep_objsel_snapshot ()
        if names :
            try :
                ts =float (dn .get (_EP_OBJSEL_TS_KEY )or 0.0 )
            except Exception :
                ts =0.0 
            cur_sel =list (getattr (bpy .context ,"selected_objects",[])or [])
            if dn .get (_EP_OBJSEL_PIN_KEY )and (time .time ()-ts )<2.0 :
            # During a pinned EP session window, selection can temporarily become empty OR collapse to a subset
            # when helper/preview objects are hidden/locked. Restore in both cases.
                try :
                    cur_main =[]
                    for o in (getattr (bpy .context ,"selected_objects",[])or []):
                        mo =get_main_object (o )or o 
                        if mo and mo .name not in cur_main :
                            cur_main .append (mo .name )
                    snap_set =set (names )
                    cur_set =set (cur_main )
                    if (not cur_sel ):
                        _ep_objsel_schedule_restore (delay =0.0 ,reason ="selection_collapse_timegate",force =True )
                except Exception :
                    pass 
    except Exception :
        pass 


        # If any helper/preview object is selected in OBJECT mode (even if active is main),
        # schedule a restore so only main objects remain selected and MS UI stays stable.
    try :
        sel =list (getattr (bpy .context ,"selected_objects",[])or [])
        if sel :
            for so in sel :
                if _ep_is_helper_obj (so ):
                    try :
                        names ,_a =_ep_objsel_snapshot ()
                        if not names :
                            _ep_objsel_capture (bpy .context ,force =True ,pin =True ,reason ="seed_from_helper_selected")
                        else :
                            _ep_dn ()[_EP_OBJSEL_PIN_KEY ]=True 
                        _ep_objsel_schedule_restore (delay =0.0 ,reason ="helper_selected_object_mode",force =True )
                    except Exception :
                        pass 
                        # Do not run heavy logic in this tick.
                    return 
    except Exception :
        pass 

        # If a helper/preview object is active in OBJECT mode, schedule selection restore.
        # EP helpers carry 'ep_main_target'; MS end-result preview carries 'ms_end_preview_main'.
    try :
        active_obj =bpy .context .view_layer .objects .active 
        if not active_obj :
            return 
        main_name =None 
        try :
            main_name =active_obj .get ("ep_main_target")or active_obj .get ("ms_end_preview_main")
        except Exception :
            main_name =None 
        if not main_name :
            return 
        main_obj =scene .objects .get (main_name )if scene else bpy .data .objects .get (main_name )
        if not main_obj :
            return 

        try :
            names ,_a =_ep_objsel_snapshot ()
            if not names :
                _ep_objsel_capture (bpy .context ,force =True ,pin =True ,reason ="seed_from_helper_active")
            else :
                _ep_dn ()[_EP_OBJSEL_PIN_KEY ]=True 
            _ep_objsel_schedule_restore (delay =0.0 ,reason ="helper_active_object_mode",force =True )
            # When Smart Modifier is performing a locked sync, avoid triggering heavy rebake/sync here.
            if ms_lock :
                return 
        except Exception :
            pass 

            # Existing: when helper becomes active in OBJECT mode, sync stack active item and rebake
        for mod in main_obj .modifiers :
            if is_ep_layer (mod ):
                en ,_ =get_ep_mesh_names (mod )
                if en ==active_obj .name :
                    if main_obj .get ("ui_active_item")!=mod .name :
                        dn =bpy .app .driver_namespace 
                        dn ["_EP_PENDING_SYNC"]=(main_obj .name ,mod .name )
                        if not dn .get ("_EP_PENDING_TIMER"):
                            dn ["_EP_PENDING_TIMER"]=True 
                            try :
                                bpy .app .timers .register (_ep_run_pending_sync ,first_interval =0.03 )
                            except Exception :
                                dn ["_EP_PENDING_TIMER"]=False 
                    return 
    except Exception :
        pass 
def _ep_run_pending_sync ():
    dn =bpy .app .driver_namespace 
    dn ["_EP_PENDING_TIMER"]=False 
    if dn .get ("_EP_SYNC_LOCK"):return 0.05 
    pending =dn .get ("_EP_PENDING_SYNC")
    if not pending :return None 
    main_name ,mod_name =pending 
    dn .pop ("_EP_PENDING_SYNC",None )
    main_obj =bpy .data .objects .get (main_name )
    if not main_obj :return None 
    dn ["_EP_SYNC_LOCK"]=True 
    global _ep_bypass 
    _ep_bypass +=1 
    try :
        try :
            if main_obj .get ("ui_active_item")!=mod_name :main_obj ["ui_active_item"]=mod_name 
        except Exception :pass 
        try :rebake_edit_polys_upto (main_obj ,bpy .context ,mod_name )
        except Exception :pass 
        try :_ep_ms_sync_objects (main_obj ,bpy .context ,mod_name ,mod_name ,True ,False )
        except Exception :pass 
    finally :
        _ep_bypass -=1 
        dn ["_EP_SYNC_LOCK"]=False 
    return None 

class EP_OT_rebake_all (bpy .types .Operator ):
    bl_idname ="ep.rebake_all"
    bl_label ='Rebake All'
    bl_description ="Recompute all EditPoly layers. After stack changes, it rebuilds consistency between each layer's Frozen base and Edit mesh."
    bl_options = {'UNDO'}
    def execute (self ,context ):
        _ep_request_live_runtime ()
        global _ep_bypass 
        _ep_bypass +=1 
        # Capture selection snapshot early to keep user's object selection stable across EP helper switching.
        try :
            pin =(getattr (context ,'mode','OBJECT')!='OBJECT')
            _ep_objsel_capture (context ,force =True ,pin =pin ,reason ='switch_level')
        except Exception :
            pass 
        main_obj =get_main_object (context .active_object )
        if main_obj :
            rebake_edit_polys_from_index (main_obj ,context ,start_index =0 )
        _ep_bypass -=1 
        return {'FINISHED'}

class EP_OT_switch_level_hijack (bpy .types .Operator ):
    bl_idname ="ep.switch_level_hijack"
    bl_label ='Sync Level Switch'
    bl_description ='Sync EditPoly edit state safely when Smart Modifier switches the active level.'
    bl_options = {'UNDO'}
    target_mod_name :bpy .props .StringProperty ()
    def execute (self ,context ):
        _ep_request_live_runtime ()
        global _ep_bypass 
        _ep_bypass +=1 
        # Capture & pin the user's object selection immediately.
        # This operator can be invoked while Blender is toggling modes/visibility; the actual restore
        # is deferred via timers to run after the state is stable.
        try :
            _ep_objsel_capture (context ,force =True ,pin =True ,reason ='switch_level')
            _ep_objsel_schedule_restore (delay =0.0 ,reason ='switch_level_post',force =True )
        except Exception :
            pass 
        try :
            try :
                _sel =_ms_capture_edit_mesh_selection (context )
                if _sel :
                    try :main_obj =get_main_object (context .active_object )
                    except :main_obj =None 
                    if main_obj :
                        try :main_obj ["_ms_last_sel"]=_sel 
                        except :pass 
            except :pass 
            main_obj =get_main_object (context .active_object )
            if main_obj :
                target =self .target_mod_name 
                if target !="BASE"and main_obj .modifiers .get (target )is None :target ="BASE"
                main_obj ["ui_active_item"]=target 
                if target !="BASE":
                    try :rebake_edit_polys_upto (main_obj ,context ,target )
                    except :pass 
        finally :
            try :_ep_release_ng_template ()
            except Exception :pass 
            _ep_bypass -=1 
        return {'FINISHED'}

class EP_OT_add_layer (bpy .types .Operator ):
    bl_idname ="ep.add_layer"
    bl_label ='Add Edit Polygon Layer'
    bl_description =(
    "Add an Edit Polygon layer to selected objects. You edit by adding a displacement offset on top of the evaluated result of the modifiers above. With multiple selection, it adds as an instance (same name/settings) and immediately enters multi-object Edit Mode."
    )
    bl_options ={'UNDO'}
    force_single :bpy .props .BoolProperty (default =False ,options ={'HIDDEN'})
    requested_name :bpy .props .StringProperty (default ="",options ={'HIDDEN'})
    auto_enter_edit :bpy .props .BoolProperty (default =True ,options ={'HIDDEN'})
    insert_index_override :bpy .props .IntProperty (default =-1 ,options ={'HIDDEN'})

    def execute (self ,context ):
        _ep_request_live_runtime ()
        global _ep_bypass 
        _ep_bypass +=1 
        try :
            targets =_ep_get_selected_main_meshes (context )
            if not targets :return {'CANCELLED'}
            active_main =get_main_object (getattr (context ,"active_object",None ))
            if not active_main or active_main not in targets :active_main =targets [0 ]

            if self .force_single or len (targets )<=1 :
                return self ._add_single (context ,active_main ,desired_name =(self .requested_name or "").strip ())

            shared_name =_ep_next_shared_modifier_name (targets ,base_name =_ep_default_layer_name(context))
            iid =uuid .uuid4 ().hex 
            ep_col =modsys_get_ep_collection (scene =context .scene )
            created =[]
            suf =_ep_suffix_from_mod_name (shared_name )

            try :_ep_capture_current_edit_selection_to_cache (context )
            except Exception :pass 

            try :
                if getattr (context ,"mode","OBJECT")!='OBJECT':
                    if bpy .ops .object .mode_set .poll ():
                        bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :pass 

            for obj in targets :
                if not obj or getattr (obj ,"type","")!='MESH':continue 
                target_idx =_ep_calc_insert_index_bottom (active_main ,obj ,context )

                ref_key =_ep_pick_inherit_selection_key (obj )
                inherit_sel =ms_sel_get (obj ,ref_key )or (ms_sel_get (obj ,"BASE")if ref_key !="BASE"else None )

                # Fetch fresh evaluation to avoid stale pointer crash in loop
                eval_mesh =self ._eval_mesh_below_cut (obj ,context ,target_idx )
                if not eval_mesh :continue 

                frozen_data =eval_mesh 
                try :frozen_data .name =f"{obj .name }_mesh_data_INST_{suf }"
                except Exception :pass 
                edit_data =frozen_data .copy ()
                try :edit_data .name =f"{obj .name }_mesh_data_EDIT_INST_{suf }"
                except Exception :pass 

                frozen_name =f"{obj .name }_Frozen_{suf }"
                edit_name =f"{obj .name }_Edit_{suf }"
                frozen_obj =bpy .data .objects .new (frozen_name ,frozen_data )
                edit_obj =bpy .data .objects .new (edit_name ,edit_data )
                edit_obj ["ep_main_target"]=frozen_obj ["ep_main_target"]=obj .name 

                modsys_link_object (frozen_obj ,ep_col )
                modsys_link_object (edit_obj ,ep_col )
                frozen_obj .hide_set (True );frozen_obj .hide_select =True 
                edit_obj .hide_set (True );edit_obj .hide_select =True 
                _ep_sync_ref_object_transform (obj ,frozen_obj )
                _ep_sync_ref_object_transform (obj ,edit_obj )

                mod =obj .modifiers .new (name =shared_name ,type ='NODES')
                try :
                    api =_ep_ms_api ()
                    mv =api .get ("safe_move_modifier")
                    if callable (mv ):
                        mv (obj ,mod .name ,int (max (0 ,target_idx )))
                    else :
                        cur =obj .modifiers .find (mod .name )
                        if hasattr (obj .modifiers ,"move")and cur >=0 and int (target_idx )!=cur :
                            obj .modifiers .move (cur ,int (max (0 ,min (int (target_idx ),len (obj .modifiers )-1 ))))
                except Exception :pass 

                try :
                    if inherit_sel and ((inherit_sel .get ('v')or [])or (inherit_sel .get ('e')or [])or (inherit_sel .get ('f')or [])):
                        ms_sel_set (obj ,mod .name ,inherit_sel )
                except Exception :pass 

                ng =_ep_create_node_group_for_layer (obj ,mod .name ,edit_obj ,frozen_obj )
                if ng :
                    mod .node_group =ng 
                    try :ensure_ep_node_group_layout (mod )
                    except Exception :pass 
                else :continue 

                try :_ep_set_instance_id (obj ,mod .name ,iid ,disp_name =shared_name )
                except Exception :pass 
                obj ["ui_active_item"]=mod .name 
                try :obj .modifiers .active =mod 
                except Exception :pass 
                created .append ((obj ,mod ))

            try :modsys_request_cleanup ()
            except Exception :pass 

            for obj ,mod in created :
                try :
                    new_idx =obj .modifiers .find (mod .name )
                    mods_list =list (obj .modifiers )
                    if any (is_ep_layer (mm )for mm in mods_list [(new_idx +1 ):]):
                        rebake_edit_polys_from_index (obj ,context ,start_index =(new_idx +1 ))
                except Exception :pass 

            if self .auto_enter_edit :
                pairs =[(o ,m .name )for (o ,m )in created if o and m ]
                prefer_mod =None 
                try :
                    for o ,mn in pairs :
                        if o ==active_main :
                            prefer_mod =mn 
                            break 
                except Exception :prefer_mod =None 
                try :_ep_enter_edit_mode_for_layer_multi_map (context ,pairs ,active_main =active_main )
                except Exception :
                    try :_ep_enter_edit_mode_for_layer (context ,active_main ,prefer_mod or (pairs [0 ][1 ]if pairs else (shared_name or _ep_default_layer_name(context))))
                    except Exception :pass 
            return {'FINISHED'}
        finally :
            try :_ep_release_ng_template ()
            except Exception :pass 
            _ep_bypass -=1 

    def _calc_insert_index_above_active (self ,main_obj ):
        if not main_obj :return 0 
        try :return _ep_calc_insert_index_bottom (main_obj ,main_obj ,bpy .context )
        except Exception :pass 
        return 0 

    def _add_single (self ,context ,main_obj ,desired_name =""):
        try :_ep_capture_current_edit_selection_to_cache (context )
        except Exception :pass 
        try :
            target_idx =int (self .insert_index_override )if int (self .insert_index_override )>=0 else _ep_calc_insert_index_bottom (main_obj ,main_obj ,context )
        except Exception :
            target_idx =_ep_calc_insert_index_bottom (main_obj ,main_obj ,context )
        ref_key =_ep_pick_inherit_selection_key (main_obj )
        inherit_sel =ms_sel_get (main_obj ,ref_key )or (ms_sel_get (main_obj ,"BASE")if ref_key !="BASE"else None )

        if bpy .context .mode !='OBJECT':
            try :bpy .ops .object .mode_set ('EXEC_DEFAULT', False, mode ='OBJECT')
            except Exception :pass 

        if desired_name :layer_name =_ep_unique_modifier_name_for_object (main_obj ,desired_name )
        else :layer_name =_ep_unique_modifier_name_for_object (main_obj ,_ep_default_layer_name(context))

        suf =_ep_suffix_from_mod_name (layer_name )
        frozen_name =f"{main_obj .name }_Frozen_{suf }"
        edit_name =f"{main_obj .name }_Edit_{suf }"

        eval_mesh =self ._eval_mesh_below_cut (main_obj ,context ,target_idx )
        if not eval_mesh :return {'CANCELLED'}

        clean_mesh =eval_mesh 
        try :clean_mesh .name =f"{main_obj .name }_mesh_data_{suf }"
        except Exception :pass 

        frozen_obj =bpy .data .objects .new (frozen_name ,clean_mesh )
        edit_obj =bpy .data .objects .new (edit_name ,clean_mesh .copy ())
        edit_obj ["ep_main_target"]=frozen_obj ["ep_main_target"]=main_obj .name 

        ep_col =modsys_get_ep_collection (scene =context .scene )
        modsys_link_object (frozen_obj ,ep_col )
        modsys_link_object (edit_obj ,ep_col )
        try :modsys_request_cleanup ()
        except Exception :pass 

        frozen_obj .hide_set (True );frozen_obj .hide_select =True 
        edit_obj .hide_set (True );edit_obj .hide_select =True 
        _ep_sync_ref_object_transform (main_obj ,frozen_obj )
        _ep_sync_ref_object_transform (main_obj ,edit_obj )

        mod =main_obj .modifiers .new (name =layer_name ,type ='NODES')
        try :
            api =_ep_ms_api ()
            mv =api .get ("safe_move_modifier")
            if callable (mv ):mv (main_obj ,mod .name ,int (target_idx ))
            else :
                cur =main_obj .modifiers .find (mod .name )
                if hasattr (main_obj .modifiers ,"move")and cur >=0 :
                    main_obj .modifiers .move (cur ,max (0 ,min (int (target_idx ),len (main_obj .modifiers )-1 )))
        except Exception :pass 
        mod .show_in_editmode =True 
        mod .show_on_cage =True 

        try :
            if inherit_sel and ((inherit_sel .get ('v')or [])or (inherit_sel .get ('e')or [])or (inherit_sel .get ('f')or [])):
                ms_sel_set (main_obj ,mod .name ,inherit_sel )
        except Exception :pass 

        ng =_ep_create_node_group_for_layer (main_obj ,mod .name ,edit_obj ,frozen_obj )
        if ng :
            mod .node_group =ng 
            try :ensure_ep_node_group_layout (mod )
            except Exception :pass 
        else :return {'CANCELLED'}

        try :
            new_idx =main_obj .modifiers .find (mod .name )
            mods_list =list (main_obj .modifiers )
            if any (is_ep_layer (mm )for mm in mods_list [(new_idx +1 ):]):
                rebake_edit_polys_from_index (main_obj ,context ,start_index =(new_idx +1 ))
        except Exception :pass 

        main_obj ["ui_active_item"]=mod .name 
        try :main_obj .modifiers .active =mod 
        except Exception :pass 

        if self .auto_enter_edit :
            try :_ep_enter_edit_mode_for_layer (context ,main_obj ,mod .name )
            except Exception :pass 

        return {'FINISHED'}

    def _eval_mesh_below_cut (self ,main_obj ,context ,cut_index ):
        if not main_obj :return None 
        mods =list (main_obj .modifiers )
        orig_viewport =[bool (getattr (m ,'show_viewport',True ))for m in mods ]

        enabled_map =_ms_enabled_map (main_obj )
        cut =int (cut_index )if cut_index is not None else 0 

        changed =False 
        try :
            for i ,m in enumerate (mods ):
                want_show =(i <cut )and bool (enabled_map .get (m .name ,True ))
                cur =bool (getattr (m ,'show_viewport',True ))
                if cur !=want_show :
                    m .show_viewport =want_show 
                    changed =True 
        except Exception :pass 

        if changed :
            try :context .view_layer .update ()
            except Exception :pass 

        eval_obj =None 
        mesh_copy =None 
        try :
            dg2 =context .evaluated_depsgraph_get ()
            eval_obj =main_obj .evaluated_get (dg2 )
            eval_mesh_tmp =None 
            try :
                eval_mesh_tmp =eval_obj .to_mesh (preserve_all_data_layers =True ,depsgraph =dg2 )
            except TypeError :
                try :eval_mesh_tmp =eval_obj .to_mesh (preserve_all_data_layers =True )
                except Exception :eval_mesh_tmp =None 

            if eval_mesh_tmp :
                try :mesh_copy =eval_mesh_tmp .copy ()
                except Exception :
                    mesh_copy =bpy .data .meshes .new (f"{main_obj .name }_EP_EVAL_TMP")
                    bm =bmesh .new ()
                    bm .from_mesh (eval_mesh_tmp )
                    bm .to_mesh (mesh_copy )
                    bm .free ()
        except Exception :mesh_copy =None 
        finally :
            try :
                for m ,st in zip (mods ,orig_viewport ):
                    cur =bool (getattr (m ,'show_viewport',True ))
                    if cur !=bool (st ):m .show_viewport =bool (st )
            except Exception :pass 
            try :
                if eval_obj :eval_obj .to_mesh_clear ()
            except Exception :pass 
        return mesh_copy 

def _ep_ms_match_modifier (mod ):
    try :return bool (mod )and is_ep_layer (mod )
    except Exception :return False 

def _ep_is_edit_source (main_obj ,mod ):
    return is_ep_layer (mod )

def _ep_get_skip_copy_props (mod ):
    ng =getattr (mod ,'node_group',None )
    if ng and (ng .get ('ep_edit_mesh')or ng .get ('ep_frozen_mesh')or ng .get ('ep_ng_version')):
        return {"node_group"}
    return set ()

def _ep_ms_get_main_object (active_obj ):
    try :
        if active_obj and active_obj .type =='MESH'and "ep_main_target"in active_obj :
            return bpy .data .objects .get (active_obj ["ep_main_target"])
    except Exception :pass 
    return None 

def _ep_ms_layer_key_from_active_object (active_obj ):
    if not active_obj or active_obj .type !='MESH'or "ep_main_target"not in active_obj :return None 
    try :
        main_obj =bpy .data .objects .get (active_obj ["ep_main_target"])
        if not main_obj :return None 
        for m in main_obj .modifiers :
            if is_ep_layer (m )and _ms_mod_is_enabled (main_obj ,m ):
                en ,_ =get_ep_mesh_names (m )
                if en ==active_obj .name :return (main_obj ,m .name )
    except Exception :pass 
    return None 

def _ep_ui_active_from_object (main_obj ,active_obj ):
    try :
        if not main_obj or not active_obj or active_obj .type !='MESH':return None 
        if "ep_main_target"not in active_obj :return None 
        if active_obj .get ("ep_main_target")!=main_obj .name :return None 
        for m in main_obj .modifiers :
            if is_ep_layer (m )and _ms_mod_is_enabled (main_obj ,m ):
                en ,_ =get_ep_mesh_names (m )
                if en ==active_obj .name :return m .name 
    except Exception :pass 
    return None 

def _ep_ms_sync_objects (main_obj ,context ,effective_active_id ,carrier_key ,show_end ,interactive ):
    """
    Smart Modifier plugin hook.
    Keep this VERY light: only ensure/repair assets for the active EP layer (carrier_key),
    hide all other EP helper objects, and request hiding the main object while editing EP.
    """
    if not main_obj :
        return {}

    try :
        _ep_sync_topology_modes_for_main (main_obj ,context )
    except Exception :
        pass 

        # In OBJECT mode (non-interactive), EP helper objects must stay hidden.
        # This prevents 'main + node both visible' right after adding EditPoly and stabilizes object-mode display.
    try :
        _ctx_mode =getattr (context ,'mode','')if context else ''
    except Exception :
        _ctx_mode =''
    if not _ctx_mode :
        try :
            _ctx_mode =getattr (bpy .context ,'mode','')
        except Exception :
            _ctx_mode =''
    object_mode_editpoly_enter =False 
    try :
        for _candidate in (carrier_key ,effective_active_id ) :
            if not _candidate or _candidate =='BASE':continue 
            _mchk =main_obj .modifiers .get (str (_candidate ))
            if _mchk and is_ep_layer (_mchk )and _ep_is_force_edit_target_requested (main_obj ,None ):
                object_mode_editpoly_enter =True 
                break 
    except Exception :object_mode_editpoly_enter =False 
    if (_ctx_mode =='OBJECT')and (not bool (interactive ))and (not object_mode_editpoly_enter ):
        try :
            mods0 =list (getattr (main_obj ,'modifiers',[])or [])
        except Exception :
            mods0 =[]
        for m0 in mods0 :
            try :
                if not is_ep_layer (m0 ):
                    continue 
                en0 ,fn0 =get_ep_mesh_names (m0 )
                eo0 =bpy .data .objects .get (en0 )if en0 else None 
                fo0 =bpy .data .objects .get (fn0 )if fn0 else None 
                if fo0 :
                    try :
                        _ep_set_obj_hidden (fo0 ,True ,True )
                        _modsys_unlink_object_from_collection (fo0 ,bpy .data .collections .get (MODSYS_EP_COLLECTION ))
                    except Exception :
                        pass 
                if eo0 :
                    try :
                        _ep_set_obj_hidden (eo0 ,True ,True )
                        set_edit_object_modifier_visibility (eo0 ,False )
                        _modsys_unlink_object_from_collection (eo0 ,bpy .data .collections .get (MODSYS_EP_COLLECTION ))
                    except Exception :
                        pass 
            except Exception :
                continue 
        try :
            _ep_restore_main_object_mesh (main_obj )
        except Exception :
            pass 
        try :modsys_request_cleanup (delay =0.2 )
        except Exception :pass 
        return {}

        # Normalize effective_active_id / carrier_key for EP in transient states.
        # Smart Modifier can briefly pass carrier_key as BASE/None right after add/switch.
    try :
        if (not effective_active_id )or (effective_active_id =="BASE"):
            aid =str (main_obj .get ("ui_active_item","")or "")
            if aid and aid !="BASE":
                am =main_obj .modifiers .get (aid )
                if am and is_ep_layer (am ):
                    effective_active_id =aid 
        if (not effective_active_id )or (effective_active_id =="BASE"):
            am =getattr (getattr (main_obj ,"modifiers",None ),"active",None )
            if am and is_ep_layer (am ):
                effective_active_id =am .name 
    except Exception :
        pass 

    try :
        if (not carrier_key or carrier_key =="BASE")and effective_active_id and effective_active_id !="BASE":
            am0 =main_obj .modifiers .get (effective_active_id )
            if am0 and is_ep_layer (am0 ):
                carrier_key =effective_active_id 
    except Exception :
        pass 

        # Ensure EP system collections are not excluded in the current view layer.
        # If excluded, the edit helper exists but will not draw, and MS may hide the main -> "nothing visible".
    try :
        _ep_ensure_collection_not_excluded (context )
    except Exception :
        pass 

    target_obj =None 

    # Determine visible instance group for the current carrier (if any) so we can hide the previous group's helpers.
    edit_iid =""
    try :
        cm =main_obj .modifiers .get (carrier_key )if (carrier_key and carrier_key !="BASE")else None 
        if cm and is_ep_layer (cm )and _ms_mod_is_enabled (main_obj ,cm ):
            edit_iid =_ep_get_instance_id (cm ,main_obj )or ""
    except Exception :
        edit_iid =""

        # Hide previous instance group's edit helpers (only when the active iid changes).
    try :
        dn =bpy .app .driver_namespace 
        prev =str (dn .get ("_EP_VISIBLE_EDIT_IID_V1","")or "")
        if prev and prev !=edit_iid :
            for o2 ,m2 in _ep_iter_instance_members (prev ):
                try :
                    en2 ,_ =get_ep_mesh_names (m2 )
                    eo2 =bpy .data .objects .get (en2 )if en2 else None 
                    if eo2 :
                        _ep_set_obj_hidden (eo2 ,True ,True )
                except Exception :
                    pass 
        dn ["_EP_VISIBLE_EDIT_IID_V1"]=edit_iid 
    except Exception :
        pass 

    mods =[]
    try :
        mods =list (main_obj .modifiers )
    except Exception :
        mods =[]

        # Main pass: hide all EP helpers except the active carrier layer.
    for mod in mods :
        if not is_ep_layer (mod ):
            continue 

        en ,fn =get_ep_mesh_names (mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 

        # Repair assets ONLY for the active carrier layer (or when its objects are missing).
        if (mod .name ==carrier_key )and (carrier_key !="BASE")and (
        (e_obj is None )or (f_obj is None )or (getattr (e_obj ,"data",None )is None )or (getattr (f_obj ,"data",None )is None )
        ):
            try :
                _ep_ensure_unique_layer_assets (main_obj ,mod ,context )
            except Exception :
                pass 
            en ,fn =get_ep_mesh_names (mod )
            e_obj =bpy .data .objects .get (en )if en else None 
            f_obj =bpy .data .objects .get (fn )if fn else None 

            # Keep transforms in sync (cheap).
        try :
            if e_obj :_ep_sync_ref_object_transform (main_obj ,e_obj )
            if f_obj :_ep_sync_ref_object_transform (main_obj ,f_obj )
        except Exception :
            pass 

        is_edit_target =(carrier_key !="BASE")and (mod .name ==carrier_key )and _ms_mod_is_enabled (main_obj ,mod )

            # Keep the active EditPoly helper linked only while the user is entering/using EditPoly edit mode.
        if is_edit_target or (object_mode_editpoly_enter and mod .name ==carrier_key ) :
            try :
                e_obj ,f_obj =_ep_link_layer_helpers_for_edit (main_obj ,mod ,context )
            except Exception :pass 

            # Frozen objects are never directly visible/selectable.
        if f_obj :
            try :
                _ep_set_obj_hidden (f_obj ,True ,True )
            except Exception :
                pass 

        if e_obj :
            if is_edit_target :
            # Show ONLY the EP edit mesh itself.
                try :
                    _ep_set_obj_hidden (e_obj ,False ,False )
                    e_obj .display_type ='SOLID'
                    try :e_obj .show_wire =True 
                    except Exception :pass 
                    try :e_obj .show_all_edges =True 
                    except Exception :pass 
                    pass 

                    # IMPORTANT: never show main-object modifiers on the EP edit mesh.
                    set_edit_object_modifier_visibility (e_obj ,False )

                    target_obj =e_obj 
                except Exception :
                    pass 
            else :
                try :
                    _ep_set_obj_hidden (e_obj ,True ,True )
                    set_edit_object_modifier_visibility (e_obj ,False )
                    _modsys_unlink_object_from_collection (e_obj ,bpy .data .collections .get (MODSYS_EP_COLLECTION ))
                    if f_obj :_modsys_unlink_object_from_collection (f_obj ,bpy .data .collections .get (MODSYS_EP_COLLECTION ))
                except Exception :
                    pass 

                    # Safety (EDIT mode): if Smart Modifier passes transient keys and we couldn't resolve the carrier target,
                    # keep the currently edited EP helper visible/active to avoid "nothing visible" state.
    try :
        if (not target_obj )and (_ctx_mode =='EDIT_MESH'):
            eo_cur =None 
            try :
                eo_cur =getattr (context ,"edit_object",None )if context else None 
            except Exception :
                eo_cur =None 
            if eo_cur is None :
                try :
                    eo_cur =getattr (bpy .context ,"edit_object",None )
                except Exception :
                    eo_cur =None 
            if eo_cur and getattr (eo_cur ,"type","")=='MESH':
                try :
                    if eo_cur .get ("ep_main_target")==main_obj .name :
                        target_obj =eo_cur 
                        try :
                            _ep_set_obj_hidden (target_obj ,False ,False )
                        except Exception :
                            pass 
                        try :
                            target_obj .display_type ='SOLID'
                        except Exception :
                            pass 
                        try :
                            pass 
                        except Exception :
                            pass 
                        try :
                            target_obj .show_wire =True 
                        except Exception :
                            pass 
                        try :
                            target_obj .show_all_edges =True 
                        except Exception :
                            pass 
                        try :
                            set_edit_object_modifier_visibility (target_obj ,False )
                        except Exception :
                            pass 
                except Exception :
                    pass 
    except Exception :
        pass 

    if target_obj :
    # Make sure the target helper remains visible/selectable BEFORE MS switches modes.
    # ms__safe_mode_set() restores previous hide flags after switching, so "previous" must be unhidden.
        try :
            _ep_ensure_collection_not_excluded (context )
        except Exception :
            pass 
        try :
            _ep_set_obj_hidden (target_obj ,False ,False )
        except Exception :
            pass 
            # Let Smart Modifier hide the main object via hide_main. Avoid additional per-tick changes here.
        return {"target_obj":target_obj ,"priority":50 ,"hide_main":True }

    try :
        _ep_restore_main_object_mesh (main_obj )
    except Exception :
        pass 
    return {}


def _ep_ms_cleanup_before_apply (main_obj ,context ,obj ,mod ):
    if not mod or not is_ep_layer (mod ):return 
    try :
        en ,fn =get_ep_mesh_names (mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 

        vl =getattr (context ,'view_layer',None )if context else None 
        try :
            if vl and getattr (vl ,'objects',None ):
                act =vl .objects .active 
                if act in (e_obj ,f_obj ):
                    vl .objects .active =main_obj or obj 
        except Exception :pass 

        for ho in (e_obj ,f_obj ):
            if not ho :continue 
            try :ho .hide_select =False 
            except Exception :pass 
            try :ho .select_set (False )
            except Exception :pass 

        if e_obj and e_obj .name in bpy .data .objects :
            bpy .data .objects .remove (e_obj ,do_unlink =True )
        if f_obj and f_obj .name in bpy .data .objects :
            bpy .data .objects .remove (f_obj ,do_unlink =True )
    except Exception :pass 

def _ep_ms_cleanup_before_remove (main_obj ,context ,obj ,mod ):
    _ep_ms_cleanup_before_apply (main_obj ,context ,obj ,mod )

def _ep_ms_clipboard_copy (main_obj ,context ,obj ,mod ):
    if not mod or not is_ep_layer (mod ):return {}
    payload ={"mesh_names":[]}
    try :
        en ,fn =get_ep_mesh_names (mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 

        if e_obj and getattr (e_obj ,"data",None ):
            nm =bpy .data .meshes .new ("ms_clip_edit")
            bm =bmesh .new ()
            bm .from_mesh (e_obj .data )
            bm .to_mesh (nm )
            bm .free ()
            payload ["edit_mesh_name"]=nm .name 
            payload ["mesh_names"].append (nm .name )

        if f_obj and getattr (f_obj ,"data",None ):
            nm =bpy .data .meshes .new ("ms_clip_frozen")
            bm =bmesh .new ()
            bm .from_mesh (f_obj .data )
            bm .to_mesh (nm )
            bm .free ()
            payload ["frozen_mesh_name"]=nm .name 
            payload ["mesh_names"].append (nm .name )
    except Exception :pass 
    return payload 

def _ep_ms_safe_move_modifier (obj ,mod_name ,target_idx ):
    if not obj or not mod_name :return 
    try :
        mod =obj .modifiers .get (mod_name )
        if not mod :return 
        mods =list (obj .modifiers )
        current_idx =mods .index (mod )
        target_idx =max (0 ,min (int (target_idx ),len (mods )-1 ))
        if current_idx ==target_idx :return 
        if hasattr (obj .modifiers ,"move"):
            obj .modifiers .move (current_idx ,target_idx )
            return 
    except Exception :pass 

def _ep_ms_clipboard_paste (main_obj ,context ,obj ,insert_idx ,clipboard ):
    if not main_obj or obj !=main_obj :return None 
    payload =(clipboard or {}).get ("payload")or {}
    c_edit =bpy .data .meshes .get (payload .get ("edit_mesh_name",""))if payload else None 
    c_froz =bpy .data .meshes .get (payload .get ("frozen_mesh_name",""))if payload else None 

    try :
        if not (hasattr (bpy .ops ,"ep")and hasattr (bpy .ops .ep ,"add_layer")):return None 
        desired =str ((clipboard or {}).get ("name","")or "").strip ()
        if not desired :desired =_ep_default_layer_name(context)

        vl =context .view_layer 
        prev_active =vl .objects .active 
        pre_names =set ()
        try :pre_names ={m .name for m in main_obj .modifiers }
        except Exception :pre_names =set ()

        try :vl .objects .active =main_obj 
        except Exception :pass 
        try :_ep_capture_current_edit_selection_to_cache (context )
        except Exception :pass 

        bpy .ops .ep .add_layer ('EXEC_DEFAULT', False,force_single =True ,requested_name =desired ,auto_enter_edit =False ,insert_index_override =(int (insert_idx )if insert_idx is not None and int (insert_idx )>=0 else -1 ) )
        try :vl .objects .active =prev_active 
        except Exception :pass 

        post_names =set ()
        try :post_names ={m .name for m in main_obj .modifiers }
        except Exception :post_names =set ()

        added =list (post_names -pre_names )
        new_mod_name =added [0 ]if added else (main_obj .modifiers [-1 ].name if len (main_obj .modifiers )else None )
        if not new_mod_name :return None 

        new_mod =main_obj .modifiers .get (new_mod_name )
        if not new_mod or not is_ep_layer (new_mod ):return new_mod_name 

        en ,fn =get_ep_mesh_names (new_mod )
        e_obj =bpy .data .objects .get (en )if en else None 
        f_obj =bpy .data .objects .get (fn )if fn else None 

        if e_obj and c_edit :
            old_d =getattr (e_obj ,"data",None )
            try :e_obj .data =c_edit .copy ()
            except Exception :pass 
            try :
            # NOTE: do not remove mesh datablocks here (stability)

                pass 

                # # NOTE: do not remove mesh datablocks here (stability)
                # if old_d and old_d.users == 0: bpy.data.meshes.remove(old_d)
            except Exception :pass 

        if f_obj and c_froz :
            old_d =getattr (f_obj ,"data",None )
            try :f_obj .data =c_froz .copy ()
            except Exception :pass 
            try :
            # NOTE: do not remove mesh datablocks here (stability)

                pass 

                # # NOTE: do not remove mesh datablocks here (stability)
                # if old_d and old_d.users == 0: bpy.data.meshes.remove(old_d)
            except Exception :pass 

        try :
            paste_idx =int (insert_idx )if insert_idx is not None and int (insert_idx )>=0 else _ep_calc_insert_index_bottom (main_obj ,main_obj ,context )
            _ep_ms_safe_move_modifier (main_obj ,new_mod .name ,paste_idx )
        except Exception :pass 

        return new_mod .name 
    except Exception :return None 


    # ------------------------------------------------------------
    # Object Mode Cleanup (ensure only main object is visible/selectable)
    # ------------------------------------------------------------

_EP_OBJMODE_CLEANUP_QUEUE =set ()
_EP_OBJMODE_CLEANUP_TIMER_RUNNING =False 

def _ep_is_helper_object (obj ):
    try :
        if not obj :
            return False 
        if obj .get ("ep_main_target",None )is not None :
            return True 
        if obj .get ("ms_end_preview_main",None )is not None :
            return True 
    except Exception :
        pass 
    return False 

def _ep_force_object_mode_single_display (main_obj ):
    """In OBJECT mode, ensure only the main object is visible/selectable for EditPoly workflow."""
    if not main_obj :
        return 
        # Restore any temporary main-mesh display overrides (prevents 'black wireframe only' after deselect).
    try :
        _ep_restore_main_object_mesh (main_obj )
    except Exception :
        pass 
        # Unhide main (never touch selection except helper cleanup)
    try :
        _ep_set_obj_hidden (main_obj ,False ,False )
    except Exception :
        pass 

        # Hide/deselect EP helper objects for this main
    try :
        col =bpy .data .collections .get (MODSYS_EP_COLLECTION )
    except Exception :
        col =None 
    if col :
        for ob in list (getattr (col ,"objects",[])):
            try :
                if not ob or ob ==main_obj :
                    continue 
                if ob .get ("ep_main_target")!=main_obj .name :
                    continue 
                try :
                    ob .select_set (False )
                except Exception :
                    pass 
                try :
                    ob .hide_select =True 
                    ob .hide_viewport =False 
                    ob .hide_set (True )
                    _modsys_unlink_object_from_collection (ob ,bpy .data .collections .get (MODSYS_EP_COLLECTION ))
                except Exception :
                    pass 
            except Exception :
                continue 

                # Hide/deselect Smart Modifier end-preview object for this main (if present)
    try :
    # Prefer the explicit pointer on main object
        prev_name =str (main_obj .get ("_MS_END_PREVIEW_OBJ_V1","")or "")
        pobj =bpy .data .objects .get (prev_name )if prev_name else None 
        if not pobj :
        # Fallback: any object tagged to this main
            for cand in bpy .data .objects :
                try :
                    if cand .get ("ms_end_preview_main")==main_obj .name :
                        pobj =cand 
                        break 
                except Exception :
                    continue 
        if pobj :
            try :
                pobj .select_set (False )
            except Exception :
                pass 
            try :
                pobj .hide_select =True 
                if bool (getattr (pobj ,"hide_viewport",False )):
                    pobj .hide_viewport =False
                pobj .hide_set (True )
            except Exception :
                pass 
    except Exception :
        pass 

def _ep_objmode_cleanup_timer ():
    global _EP_OBJMODE_CLEANUP_TIMER_RUNNING 
    try :
    # Only act in OBJECT mode; if not, retry shortly.
        try :
            if bpy .context .mode !='OBJECT':
                return None 
        except Exception :
            return None 

        names =list (_EP_OBJMODE_CLEANUP_QUEUE )
        _EP_OBJMODE_CLEANUP_QUEUE .clear ()

        for nm in names :
            try :
                mo =bpy .data .objects .get (nm )
            except Exception :
                mo =None 
            if not mo or mo .type !='MESH':
                continue 
            _ep_force_object_mode_single_display (mo )
        try :modsys_request_cleanup (delay =0.1 )
        except Exception :pass 
    finally :
        _EP_OBJMODE_CLEANUP_TIMER_RUNNING =False 
    return None 

def _ep_schedule_objmode_cleanup (main_obj ):
    global _EP_OBJMODE_CLEANUP_TIMER_RUNNING 
    if not main_obj :
        return 
    try :
        _EP_OBJMODE_CLEANUP_QUEUE .add (main_obj .name )
    except Exception :
        return 
    if _EP_OBJMODE_CLEANUP_TIMER_RUNNING :
        return 
    _EP_OBJMODE_CLEANUP_TIMER_RUNNING =True 
    try :
        bpy .app .timers .register (_ep_objmode_cleanup_timer ,first_interval =0.08 )
    except Exception :
        _EP_OBJMODE_CLEANUP_TIMER_RUNNING =False 

def _ep_ms_post_object_mode (main_obj ,context ,effective_active_id ):
# Ensure in OBJECT mode only the main object remains visible/selectable (helpers are hidden)
# NOTE:
#   When EditPoly is the effective active modifier, Smart Modifier will immediately enter EDIT mode
#   on the EP edit helper (target_obj). If we hide helpers here, ms__safe_mode_set() will restore
#   the helper's hide_select/hide_viewport flags after switching modes, leaving BOTH main+helper
#   hidden/unselectable. Therefore, skip object-mode helper cleanup in that specific transition.
    try :
        skip_cleanup =False 
        try :
            if main_obj and effective_active_id and effective_active_id !="BASE":
                am =main_obj .modifiers .get (effective_active_id )
                if am and is_ep_layer (am )and _ep_is_force_edit_target_requested (main_obj ,None ):
                    skip_cleanup =True 
        except Exception :
            skip_cleanup =False 

        if main_obj and bpy .context .mode =='OBJECT':

        # If we are about to enter EditPoly editing (effective_active_id is an EP layer),
        # make sure the EP edit helper is already visible/selectable in OBJECT mode.
        # ms__safe_mode_set() restores previous hide flags after switching modes, so the "previous" state must be unhidden.
            if skip_cleanup :
                try :
                    am1 =main_obj .modifiers .get (effective_active_id )if (effective_active_id and effective_active_id !="BASE")else None 
                    if am1 and is_ep_layer (am1 ):
                        en1 ,fn1 =get_ep_mesh_names (am1 )
                        eo1 =bpy .data .objects .get (en1 )if en1 else None 
                        fo1 =bpy .data .objects .get (fn1 )if fn1 else None 
                        # Frozen is never visible/selectable
                        if fo1 :
                            try :
                                _ep_set_obj_hidden (fo1 ,True ,True )
                            except Exception :
                                pass 
                        if eo1 :
                            try :
                                _ep_set_obj_hidden (eo1 ,False ,False )
                                # Ensure stable display defaults (do not touch overlays)
                                try :eo1 .display_type ='SOLID'
                                except Exception :pass 
                                try :pass 
                                except Exception :pass 
                                try :eo1 .show_wire =True 
                                except Exception :pass 
                                try :eo1 .show_all_edges =True 
                                except Exception :pass 
                                try :set_edit_object_modifier_visibility (eo1 ,False )
                                except Exception :pass 
                            except Exception :
                                pass 
                except Exception :
                    pass 

            if not skip_cleanup :
                _ep_schedule_objmode_cleanup (main_obj )
            try :
                _ep_schedule_touched_restore (delay =0.0 ,reason ='ms_post_object_mode')
            except Exception :
                pass 
            try :modsys_request_cleanup (delay =0.25 )
            except Exception :pass 
    except Exception :
        pass 

        # Keep original behavior (rebake when EditPoly is the effective active modifier)
    try :
        if effective_active_id and effective_active_id !="BASE":
            am =main_obj .modifiers .get (effective_active_id )
            if am and is_ep_layer (am ):
                rebake_edit_polys_upto (main_obj ,context ,effective_active_id )
    except Exception :
        pass 

def _ep_ms_on_stack_change (main_obj ,context ,interactive ):
    if not main_obj :return False 
    try :
        if bpy .context .mode !='OBJECT':return False 
    except Exception :return False 
    last =None 
    try :
        for m in main_obj .modifiers :
            if is_ep_layer (m ):last =m .name 
    except Exception :last =None 
    if not last :return False 

    try :dn =bpy .app .driver_namespace 
    except Exception :dn ={}
    cache =dn .get ("_EP_STACK_SIG_CACHE_V1")
    if not isinstance (cache ,dict ):
        cache ={}
        try :dn ["_EP_STACK_SIG_CACHE_V1"]=cache 
        except Exception :pass 

        # NOTE: Smart Modifier toggles modifier.show_viewport temporarily during interactive level switching.
        #       Using show_viewport here causes false-positive 'stack change' detection and heavy rebakes.
        #       Therefore, in interactive mode we prefer ms_mod_enabled_bak (if present) and otherwise assume enabled.
    try :
        raw_en =main_obj .get ("ms_mod_enabled_bak",None )
        en_dict =None 
        if raw_en is not None :
            try :en_dict =json .loads (raw_en or "{}")
            except Exception :en_dict =None 
        use_viewport =(not bool (interactive ))and (en_dict is None )
        def _ep__enabled (m ):
            try :
                if isinstance (en_dict ,dict ):
                    return bool (en_dict .get (m .name ,True ))
            except Exception :
                pass 
            if use_viewport :
                try :return bool (getattr (m ,"show_viewport",True ))
                except Exception :return True 
            return True 
        cur =[(m .type ,m .name ,1 if _ep__enabled (m )else 0 )for m in main_obj .modifiers ]
    except Exception :
        cur =[]

    prev =cache .get (main_obj .name )
    if prev ==cur :return False 

    diff =0 
    try :
        nmin =min (len (cur ),len (prev )if prev else 0 )
        while diff <nmin and cur [diff ]==prev [diff ]:diff +=1 
    except Exception :diff =0 

    try :rebake_edit_polys_from_index (main_obj ,context ,start_index =diff )
    except Exception :pass 

    cache [main_obj .name ]=cur 
    return True 

def _ep_ms_suppress_properties (mod ):
    return True 

def _ep_ms_draw_add_menu (layout ,context ):
    try :
        layout .operator ("ep.add_layer",text =t ("Edit Polygon"),icon ='MESH_DATA')
    except Exception :pass 

def _ep_ms_build_plugin ():
    return {
    "id":"edit_poly",
    "label":"Edit Polygon",
    "label_ja":"編集ポリゴン",
    "operator_id":"ep.add_layer",
    "icon":"MESH_DATA",
    "group":"edit_selection",
    "priority":84 ,
    "description_en":"Add a stack-managed Edit Polygon layer for Max-style editable polygon stages inside Smart Modifier.",
    "description_ja":"Smart Modifier 内で 3ds Max 風の編集段階を作れる、スタック管理付き編集ポリゴンレイヤーを追加します。",
    "usage_en":"Use Object Mode or Edit Mesh on the active mesh object, then run Edit Polygon to insert an editable stack layer.",
    "usage_ja":"オブジェクトモードまたは編集メッシュでアクティブメッシュを対象に実行し、編集ポリゴン用スタックレイヤーを挿入します。",
    "match_modifier":_ep_ms_match_modifier ,
    "is_edit_source":_ep_is_edit_source ,
    "get_skip_copy_props":_ep_get_skip_copy_props ,
    "get_main_object":_ep_ms_get_main_object ,
    "layer_key_from_active_object":_ep_ms_layer_key_from_active_object ,
    "ui_active_from_object":_ep_ui_active_from_object ,
    "carrier_key_for_effective":get_carrier_key_for_effective ,
    "inherit_key_for_carrier":find_inherit_key_for_carrier ,
    "sync_objects":_ep_ms_sync_objects ,
    "cleanup_before_apply":_ep_ms_cleanup_before_apply ,
    "cleanup_before_remove":_ep_ms_cleanup_before_remove ,
    "clipboard_copy":_ep_ms_clipboard_copy ,
    "clipboard_paste":_ep_ms_clipboard_paste ,
    "post_object_mode":_ep_ms_post_object_mode ,
    "on_stack_change":_ep_ms_on_stack_change ,
    "suppress_properties":_ep_ms_suppress_properties ,
    "draw_add_menu":_ep_ms_draw_add_menu ,
    }

def _ep_ms_register_plugin ():
    try :
        dn =bpy .app .driver_namespace 
        plugin =_ep_ms_build_plugin ()
        reg =_ep_ms_plugin_registry (dn )
        reg ["edit_poly"]=plugin 

        fn =dn .get ("_MS_REGISTER_PLUGIN_V1")
        if callable (fn ):
            try :fn ("edit_poly",plugin )
            except Exception :pass 
    except Exception :pass 

def _delayed_register_plugin ():
    _ep_ms_register_plugin ()
    return None 

def _ep_ms_unregister_plugin ():
    try :
        dn =bpy .app .driver_namespace 
        reg =_ep_ms_plugin_registry (dn )
        reg .pop ("edit_poly",None )
        fn =dn .get ("_MS_UNREGISTER_PLUGIN_V1")
        if callable (fn ):
            try :fn ("edit_poly")
            except Exception :pass 
    except Exception :pass 

class VIEW3D_PT_edit_poly_standalone (bpy .types .Panel ):
    bl_space_type ='VIEW_3D'
    bl_region_type ='UI'
    bl_category = 'Smart Modifier'
    bl_label ='Edit Polygon (Standalone)'
    @classmethod 
    def poll (cls ,context ):
        return False 
    def draw (self ,context ):
        layout =self .layout 
        if not context .active_object or context .active_object .type !='MESH':
            layout .label (text =t ('Please select a mesh object.'),icon='NONE')
            return 
        layout .operator ("ep.add_layer",text =t ('Add Edit Polygon'),icon ='ADD')
        layout .label (text =t ('* Please use Smart Modifier for layer management.'),icon='NONE')


        # --- Tooltip completion ---
VIEW3D_PT_edit_poly_standalone .bl_description ='Standalone panel for Edit Polygon Modifier when it is used outside the main Smart Modifier stack.'


# -----------------------------------------------------------------------------
# Standalone-reference behavior patch
# - Arm Edit Poly runtime on demand so bundled Smart Modifier behaves like the
#   standalone Edit Poly add-on while it is actively used.
# - Keep the global N-panel runtime toggle semantics intact when the user has
#   explicitly enabled them.
# -----------------------------------------------------------------------------
import importlib as _ep_importlib


def _ep_runtime_api():
    try:
        base_api = bpy.app.driver_namespace.get("_MS_RUNTIME_API_V1") or {}
    except Exception:
        base_api = {}
    try:
        api = dict(base_api)
    except Exception:
        api = {}

    base_enabled = base_api.get("edit_poly_live_enabled") if isinstance(base_api, dict) else None

    def _ep_enabled_proxy(context=None):
        user_enabled = False
        try:
            if callable(base_enabled):
                try:
                    user_enabled = bool(base_enabled(context))
                except TypeError:
                    user_enabled = bool(base_enabled())
        except Exception:
            user_enabled = False
        try:
            module_enabled = bool(bpy.app.driver_namespace.get("_EP_RUNTIME_ENABLED_V1", False))
        except Exception:
            module_enabled = False
        return bool(user_enabled or module_enabled)

    api["edit_poly_live_enabled"] = _ep_enabled_proxy
    return api


def _ep_request_live_runtime():
    """Arm Edit Poly live behavior when the tool is actually used.

    The standalone Edit Poly add-on always keeps its depsgraph sync active.
    Smart Modifier bundles it behind runtime toggles for idle performance, but
    when the user explicitly starts using Edit Poly, the bundled tool must still
    become fully functional without requiring a separate toggle step.
    """
    # Respect the explicit Smart Modifier runtime toggle when it is already on.
    try:
        api = bpy.app.driver_namespace.get("_MS_RUNTIME_API_V1") or {}
    except Exception:
        api = {}
    enabled_fn = api.get("edit_poly_live_enabled") if isinstance(api, dict) else None
    user_enabled = False
    try:
        if callable(enabled_fn):
            try:
                user_enabled = bool(enabled_fn())
            except TypeError:
                user_enabled = bool(enabled_fn(None))
    except Exception:
        user_enabled = False
    if user_enabled:
        try:
            sync = api.get("sync_runtime_services")
            if callable(sync):
                sync()
        except Exception:
            pass
        try:
            _ep_arm_live_topology_poll()
        except Exception:
            pass
        return

    # Otherwise arm the bundled module directly so Edit Poly matches the
    # standalone reference behavior once the user begins interacting with it.
    try:
        pkg = (__package__ or "").strip()
        if pkg:
            mod = _ep_importlib.import_module(pkg)
            fn = getattr(mod, "set_runtime_enabled", None)
            if callable(fn):
                fn(True)
                return
    except Exception:
        pass
